// Numerical checks of the library against the identities and bounds stated in the Vocabucapillary
// papers. Every check is deterministic. Exit code 0 means all passed.
using System.Collections.Immutable;
using System.Globalization;
using Vocabucapillary;
using Vector = System.Collections.Immutable.ImmutableArray<double>;

CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
int passed = 0, failed = 0;

void Section(string title) => Console.WriteLine($"\n== {title} ==");
void Check(string name, bool ok, string detail = "")
{
    if (ok) passed++; else failed++;
    Console.WriteLine($"  [{(ok ? "pass" : "FAIL")}] {name}{(detail.Length > 0 ? "  (" + detail + ")" : "")}");
}
void Near(string name, double actual, double expected, double tol = 1e-10) =>
    Check(name, Math.Abs(actual - expected) <= tol, $"error {Math.Abs(actual - expected):E1}");
void AtMost(string name, double value, double bound) =>
    Check(name, value <= bound + 1e-12, $"{value:G5} <= {bound:G5}");

SparseCode RandomCode(Random r, int width, int support) =>
    SparseCode.Normalize(width, Enumerable.Range(0, width).OrderBy(_ => r.Next()).Take(support).Select(j => (j, 0.05 + r.NextDouble())));
Vector RandomVector(Random r, int n, double scale = 1) => Vec.Create(n, _ => scale * (2 * r.NextDouble() - 1));
Transport RandomTransport(Random r, int inWidth, int outWidth, int columnSupport) =>
    Transport.FromColumns(Enumerable.Range(0, inWidth).Select(_ => RandomCode(r, outWidth, columnSupport)));
double MaxDiff(Vector a, Vector b) => Vec.NormInf(Vec.Subtract(a, b));

// ------------------------------------------------------------------ 1
Section("Codes, dictionaries and Vocabuquantization");
{
    var r = new Random(1);
    var d = new AtomDictionary(Matrix.Random(8, 20, seed: 11), "d1");
    var c = RandomCode(r, 20, 7);
    Near("code has unit mass", Vec.Sum(c.Values), 1, 1e-15);
    Near("sparse decode equals dense D c", MaxDiff(d.Decode(c), d.Atoms.Multiply(c.ToDense())), 0, 1e-14);

    var c2 = RandomCode(r, 20, 5);
    var mix = Codes.Mix(new[] { (0.3, c), (0.7, c2) });
    Check("mixture support is the union of supports (Prop. 5)", mix.Indices.SequenceEqual(c.Indices.Union(c2.Indices).OrderBy(j => j)));

    var t = Vocabuquantizer.Truncate(c, 3);
    Near("truncation: TV equals discarded mass (VQ Thm 1)", Codes.TotalVariation(c, t.Code), t.DiscardedMass, 1e-14);
    AtMost("truncation: decoded error <= eta * diameter (VQ Cor. 1.1)", Vec.Distance(d.Decode(c), d.Decode(t.Code)), t.DecodedErrorBound(d.Diameter()));

    bool sums = true, tvOk = true, decOk = true;
    double diameter = d.Diameter();
    for (int trial = 0; trial < 300; trial++)
    {
        var code = RandomCode(r, 20, 2 + r.Next(10));
        int s = 1 + r.Next(6), j = new[] { 3, 7, 15, 255 }[r.Next(4)];
        var q = Vocabuquantizer.Quantize(code, s, j);
        sums &= q.Quantized.Counts.Sum() == j && q.Quantized.Counts.All(n => n > 0);
        double tv = Codes.TotalVariation(code, q.Quantized.Decode());
        tvOk &= tv <= q.TotalVariationBound + 1e-12;
        decOk &= Vec.Distance(d.Decode(code), d.Decode(q.Quantized.Decode())) <= diameter * (q.DiscardedMass + q.RetainedSupport / (2.0 * j)) + 1e-12;
    }
    Check("rounding: positive counts sum exactly to J (300 trials)", sums);
    Check("quantizer: TV <= min{1, eta + s/(2J)} (VQ Thm 2, 300 trials)", tvOk);
    Check("quantizer: decoded error <= diameter * (eta + s/(2J)) (300 trials)", decOk);
    Near("codebook size log2[C(5,2) C(3,1)] (VQ Prop. 3)", Vocabuquantizer.CodebookLog2Size(5, 2, 4), Math.Log2(30), 1e-12);
    var res = new Resolution(Atoms: 32768, Support: 8, Precision: 255, MemoryRows: 1024);
    Check("record bits s(ceil log2 N + b) = 8 (15 + 8)", res.RecordBits == 8 * 23);
    Check("codes compare structurally", SparseCode.OneHot(5, 2).Equals(SparseCode.Create(5, new[] { (2, 1.0) })));
}

// ------------------------------------------------------------------ 2
Section("Sparse positive maps and their reverse rules");
{
    var r = new Random(2);
    var p = SimplexMaps.Sparsemax(new[] { 0.5, 0.3, -1.0 });
    Near("sparsemax(0.5, 0.3, -1) = (0.6, 0.4, 0)", MaxDiff(p.ToDense(), Vec.Of(0.6, 0.4, 0)), 0, 1e-15);

    IEnumerable<int[]> Subsets(int n, int maxSize) =>
        Enumerable.Range(1, (1 << n) - 1).Select(m => Enumerable.Range(0, n).Where(i => (m & (1 << i)) != 0).ToArray()).Where(a => a.Length <= maxSize);
    double worstProjection = 0, worstEntropic = 0;
    for (int trial = 0; trial < 40; trial++)
    {
        var z = RandomVector(r, 6, 1.5);
        int s = 1 + r.Next(3);
        double Objective(SparseCode code) => 0.5 * Math.Pow(Vec.Distance(code.ToDense(), z), 2);
        double best = Subsets(6, s).Min(a => Objective(SimplexMaps.Sparsemax(6, a.Select(i => (i, z[i])))));
        worstProjection = Math.Max(worstProjection, Math.Abs(Objective(SimplexMaps.CappedSparsemax(z, s)) - best));

        double tau = 0.7;
        double Entropic(SparseCode code) => Codes.Expect(code, j => z[j]) + tau * code.Entropy();
        double bestEntropic = Subsets(6, s).Max(a => Entropic(SimplexMaps.TopSoftmax(6, a.Select(i => (i, z[i])), a.Length, tau)));
        worstEntropic = Math.Max(worstEntropic, Math.Abs(Entropic(SimplexMaps.TopSoftmax(z, s, tau)) - bestEntropic));
    }
    Near("capped projection matches exhaustive support search (SPCS Thm 7)", worstProjection, 0, 1e-12);
    Near("top-k softmax maximises the entropic objective (MM Thm 4)", worstEntropic, 0, 1e-12);

    var scores = Vec.Of(0.9, 0.2, 0.6, -0.4, 0.1);
    var u = RandomVector(r, 5);
    double h = 1e-6;
    Vector Bump(Vector v, int i, double e) => v.SetItem(i, v[i] + e);
    var soft = SimplexMaps.TopSoftmax(scores, 5, 0.8);
    var softBack = SimplexMaps.SoftmaxPullback(soft, u, 0.8);
    double softErr = Enumerable.Range(0, 5).Max(i => Math.Abs(softBack[i] -
        (Vec.Dot(u, SimplexMaps.TopSoftmax(Bump(scores, i, h), 5, 0.8).ToDense()) - Vec.Dot(u, SimplexMaps.TopSoftmax(Bump(scores, i, -h), 5, 0.8).ToDense())) / (2 * h)));
    Near("softmax pullback matches finite differences (BP Thm 3)", softErr, 0, 1e-8);

    var sparse = SimplexMaps.CappedSparsemax(scores, 3);
    var uA = Vec.Create(sparse.Support, k => u[sparse.Indices[k]]);
    var sparseBack = SimplexMaps.SparsemaxPullback(sparse, uA);
    double sparseErr = Enumerable.Range(0, sparse.Support).Max(k => Math.Abs(sparseBack[k] -
        (Vec.Dot(u, SimplexMaps.CappedSparsemax(Bump(scores, sparse.Indices[k], h), 3).ToDense()) - Vec.Dot(u, SimplexMaps.CappedSparsemax(Bump(scores, sparse.Indices[k], -h), 3).ToDense())) / (2 * h)));
    Near("sparsemax pullback matches finite differences on a stable support (SPCS Lemma 8)", sparseErr, 0, 1e-8);
    Near("singleton support has zero score derivative (BP Cor. 3.1)", Vec.NormInf(SimplexMaps.SparsemaxPullback(SparseCode.OneHot(5, 0), Vec.Of(3.0))), 0, 0);
    Check("top-support stability needs gap > 2 * perturbation (BP Lemma 2)",
        SparseAdjoints.TopSupportIsStable(scores, 2, 0.19) && !SparseAdjoints.TopSupportIsStable(scores, 2, 0.21));
    Check("candidate certificate (SPCS 5.2)", SimplexMaps.CandidateSetIsExact(new[] { 0.9, 0.6, 0.2 }, 2, 0.5) && !SimplexMaps.CandidateSetIsExact(new[] { 0.9, 0.6 }, 2, 0.7));
}

// ------------------------------------------------------------------ 3
Section("Transports, residuals and the vocabulary hierarchy");
{
    var r = new Random(3);
    var t = RandomTransport(r, 12, 9, 3);
    var c = RandomCode(r, 12, 4);
    Near("T c equals the matrix product", MaxDiff(t.Apply(c).ToDense(), t.ToMatrix().Multiply(c.ToDense())), 0, 1e-14);
    Check("support of T c <= b * support of c (SPCS Thm 3)", t.Apply(c).Support <= t.MaxColumnSupport * c.Support);
    Check("matrix round trip is structurally equal", Transport.FromMatrix(t.ToMatrix()).Then(Transport.Identity(9)).ToMatrix().MaxAbsDifference(t.ToMatrix()) < 1e-14);

    double eta = t.ContractionCoefficient();
    bool contraction = true;
    for (int trial = 0; trial < 200; trial++)
    {
        var p = RandomCode(r, 12, 1 + r.Next(6));
        var q = RandomCode(r, 12, 1 + r.Next(6));
        contraction &= Codes.L1Distance(t.Apply(p), t.Apply(q)) <= eta * Codes.L1Distance(p, q) + 1e-12;
    }
    Check("||Tp - Tq||_1 <= eta(T) ||p - q||_1 with eta(T) <= 1 (SPCS 6.2, 200 trials)", contraction && eta <= 1);

    var d = new AtomDictionary(Matrix.Random(6, 12, seed: 31), "d");
    var w = Matrix.Random(4, 6, seed: 32);
    var e = d.Mapped(w, "wd");
    Near("E = W D with T = I intertwines exactly (SPCS Thm 3)", Transport.Identity(12).IntertwiningResidual(d, e, w), 0, 1e-14);
    Near("E c = W (D c)", MaxDiff(e.Decode(c), w.Multiply(d.Decode(c))), 0, 1e-13);

    var wide = new AtomDictionary(Matrix.Create(6, 15, (i, j) => j < 12 ? d.Atoms[i, j] : 0.1 * (i + j)), "wide");
    var embed = Transport.Embedding(12, 15);
    Near("zero-padding preserves the decoded state (SPCS Thm 12)", embed.IntertwiningResidual(d, wide), 0, 0);
    Near("padded code decodes to the same vector", MaxDiff(wide.Decode(embed.Apply(c)), d.Decode(c)), 0, 1e-15);

    var z = RandomCode(r, 12, 5);
    var residual = CoefficientLayer.Residual(c, z, gate: 0.25, support: 6);
    Check("residual stays a capped code and reports its discarded mass (SPCS Eq. 14)", residual.Code.Support <= 6 && residual.DiscardedMass >= 0 && residual.DiscardedMass < 1);
    var joined = CoefficientLayer.Concatenate(c, z, 0.25);
    Check("concatenation widens the namespace to M + P", joined.Width == 24 && joined.Support == c.Support + z.Support);
    Near("residual contraction bound 1 - g + g eta(T)", CoefficientLayer.ResidualContraction(0.25, t), 0.75 + 0.25 * eta, 1e-15);

    var hierarchy = VocabularyHierarchy.Uniform(branching: 4, depth: 2);
    var prior = SparseCode.Normalize(16, Enumerable.Range(0, 16).Select(j => (j, 1.0 + j % 5))).ToDense();
    var d16 = new AtomDictionary(Matrix.Random(5, 16, seed: 33), "d16");
    var coarse = hierarchy.CoarseDictionary(d16, prior, 1);
    double decodeErr = 0, tvErr = 0;
    for (int j = 0; j < 16; j++)
    {
        var code = hierarchy.ResolutionCode(prior, 1, j);
        decodeErr = Math.Max(decodeErr, MaxDiff(d16.Decode(code), coarse.Atom(hierarchy.GroupOf[1][j])));
        tvErr = Math.Max(tvErr, Math.Abs(Codes.TotalVariation(SparseCode.OneHot(16, j), code) - (1 - code[j])));
    }
    Near("resolution code decodes to the prior-weighted group atom (VTD Prop. 1)", decodeErr, 0, 1e-14);
    Near("TV(e_j, R_k(j)) = 1 - b_j / b(group)", tvErr, 0, 1e-14);
    Near("root code equals the prior", MaxDiff(hierarchy.ResolutionCode(prior, 2, 5).ToDense(), prior), 0, 1e-15);
    Check("hierarchy shape", hierarchy.Depth == 2 && hierarchy.GroupCount.SequenceEqual(new[] { 16, 4, 1 }));
}

// ------------------------------------------------------------------ 4
Section("Coefficient attention and the feedforward block");
{
    var r = new Random(4);
    var dq = new AtomDictionary(Matrix.Random(6, 10, seed: 41), "q");
    var dk = new AtomDictionary(Matrix.Random(6, 14, seed: 42), "k");
    var dv = new AtomDictionary(Matrix.Random(5, 12, seed: 43), "v");
    var g = CoefficientLayer.InducedCompatibility(dq, dk, Math.Sqrt(6));
    var a = RandomCode(r, 10, 3);
    var records = Enumerable.Range(0, 9).Select(_ => (Key: RandomCode(r, 14, 3), Value: RandomCode(r, 12, 2))).ToImmutableArray();
    var bias = RandomVector(r, 9, 0.5);
    var read = CoefficientLayer.Attend(a, g, records, bias);

    var q = dq.Decode(a);
    var z = records.Select((rec, j) => Vec.Dot(q, dk.Decode(rec.Key)) / Math.Sqrt(6) + bias[j]).ToArray();
    double lse = Vec.LogSumExp(z);
    var alpha = z.Select(v => Math.Exp(v - lse)).ToArray();
    var direct = records.Select((rec, j) => (alpha[j], dv.Decode(rec.Value))).Aggregate(Vec.Zero(5), (acc, x) => Vec.AddScaled(acc, x.Item1, x.Item2));
    Near("coefficient attention equals decoded vector attention (SPCS Thm 4)", MaxDiff(dv.Decode(read.Read), direct), 0, 1e-13);
    Check("the induced compatibility has negative entries", !g.IsNonnegative);
    Check("the read support is the union of value supports (Prop. 5)",
        read.Read.Indices.SequenceEqual(records.SelectMany(rec => rec.Value.Indices).Distinct().OrderBy(j => j)));

    var ffn = new CoefficientFeedForward(Matrix.Random(40, 12, 44), RandomVector(r, 40, 0.1), 6, Matrix.Random(12, 40, 45), RandomVector(r, 12, 0.1), 3);
    var outCode = ffn.Apply(read.Read);
    Check("feedforward block returns capped simplex codes (SPCS Eq. 13)", ffn.Hidden(read.Read).Support <= 6 && outCode.Support <= 3 && Math.Abs(Vec.Sum(outCode.Values) - 1) < 1e-12);
}

// ------------------------------------------------------------------ 5
Section("Bounded coefficient memory");
{
    var r = new Random(5);
    int n = 15, dk = 6, dv = 4, steps = 40;
    var kernel = new ResponseKernel(Matrix.Random(dk, n, seed: 51), Temperature: 0.9);
    var history = Enumerable.Range(0, steps).Select(_ => (Code: RandomCode(r, n, 3), Value: RandomVector(r, dv), Weight: 0.2 + r.NextDouble())).ToImmutableArray();
    var memory = history.Aggregate(CoefficientMemory.Empty(n, dv), (m, x) => m.Write(x.Code, x.Value, x.Weight));
    var query = RandomVector(r, dk);

    Vector Tokenwise(IEnumerable<(SparseCode Code, Vector Value, double Weight)> records)
    {
        var w = records.Select(x => (x.Value, LogW: Math.Log(x.Weight) + kernel.LogKernel(query, x.Code))).ToArray();
        double z = Vec.LogSumExp(w.Select(x => x.LogW).ToArray());
        return w.Aggregate(Vec.Zero(dv), (acc, x) => Vec.AddScaled(acc, Math.Exp(x.LogW - z), x.Value));
    }
    var read = memory.Read(kernel, query);
    Near("aggregate read equals the tokenwise read (CT Thm 6)", MaxDiff(read.Output, Tokenwise(history)), 0, 1e-12);
    Check("state does not grow with the prefix", memory.OccupiedRows <= n);
    Near("total mass equals total exposure", memory.TotalMass, history.Sum(x => x.Weight), 1e-12);
    Near("response masses sum to one", read.ResponseMass.Values.Sum(), 1, 1e-13);
    Check("a write returns a new memory and leaves the old one unchanged", CoefficientMemory.Empty(n, dv).Write(history[0].Code, history[0].Value).OccupiedRows == 3 && CoefficientMemory.Empty(n, dv).IsEmpty);

    double lambda = 0.93;
    var recent = history.Aggregate(CoefficientMemory.Empty(n, dv), (m, x) => m.Step(x.Code, x.Value, lambda));
    var explicitWeights = history.Select((x, i) => (x.Code, x.Value, Math.Pow(lambda, steps - 1 - i)));
    Near("exponential recency equals explicit weights lambda^(t-i) (CT Prop. 12)", MaxDiff(recent.Read(kernel, query).Output, Tokenwise(explicitWeights)), 0, 1e-12);
    Near("common decay leaves the current read unchanged", MaxDiff(memory.Decay(0.01).Read(kernel, query).Output, read.Output), 0, 1e-13);
    var underflow = Enumerable.Range(0, 400).Aggregate(memory, (m, _) => m.Decay(0.1));
    Check("repeated decay stays finite", underflow.TotalMass >= 0 && !double.IsNaN(underflow.TotalMass));

    bool jensen = history.All(x => { double gap = kernel.JensenGap(query, x.Code); return gap >= -1e-13 && gap <= kernel.JensenGapBound(query, x.Code) + 1e-13; });
    Check("Jensen gap lies in [0, R^2/8] (CT Lemma 5)", jensen);

    var p = RandomTransport(r, n, 6, 2);
    var fine = memory.Decay(0.8).Write(history[3].Code, history[3].Value, 1.7).Coarsen(p);
    var coarse = memory.Coarsen(p).Decay(0.8).Write(p.Apply(history[3].Code), history[3].Value, 1.7);
    double commute = fine.Rows.Max(kv => Math.Max(Math.Abs(kv.Value.Mass - coarse.Rows[kv.Key].Mass), MaxDiff(kv.Value.ValueSum, coarse.Rows[kv.Key].ValueSum)));
    Near("coarsening commutes with linear writes (VQ Thm 20)", commute, 0, 1e-12);
    Near("coarsening preserves total exposure", memory.Coarsen(p).TotalMass, memory.TotalMass, 1e-12);

    var split = Transport.FromColumns(Enumerable.Range(0, n).Select(j => SparseCode.Create(2 * n, new[] { (2 * j, 0.3), (2 * j + 1, 0.7) })));
    var childKernel = new ResponseKernel(Matrix.Create(dk, 2 * n, (i, j) => kernel.KeyAtoms[i, j / 2]), kernel.Temperature);
    Near("refinement with identical child atoms preserves the read (BP Thm 15)", MaxDiff(memory.Refine(split).Read(childKernel, query).Output, read.Output), 0, 1e-12);

    var group = read.ResponseMass.Keys.Take(4).ToArray();
    var effect = ReadExplanation.Delete(read, group);
    var actual = memory.Delete(group).Read(kernel, query).Output;
    Near("deletion formula equals rereading the deleted memory (INT Thm 8)", MaxDiff(effect.ReadWithoutGroup, actual), 0, 1e-12);
    AtMost("deletion error <= value diameter * response mass (VQ Thm 7)", Vec.Norm(effect.Change), effect.Bound(ReadExplanation.ValueDiameter(read)));
    var readout = RandomVector(r, dv);
    var beta = ReadExplanation.GateSensitivities(read, readout);
    Near("gate sensitivities sum to zero (INT Thm 7)", beta.Values.Sum(), 0, 1e-13);
    Near("scalar deletion effect = sum of beta / (1 - pi_G)", Vec.Dot(readout, effect.Change), group.Sum(j => beta[j]) / (1 - effect.ResponseMass), 1e-12);
    Check("top response rows are ordered by response mass", ReadExplanation.TopResponseRows(read, 3).SequenceEqual(read.ResponseMass.OrderByDescending(kv => kv.Value).Take(3).Select(kv => kv.Key)));

    var state = Categorical.Occupancy(memory);
    var updated = Categorical.Update(state, history[5].Code, 0.8, 1.7);
    var reference = Categorical.Occupancy(memory.Decay(0.8).Write(history[5].Code, history[5].Value, 1.7));
    Near("probability-form write matches the memory (PV Lemma 1)", Codes.L1Distance(updated.Occupancy, reference.Occupancy) + Math.Abs(updated.TotalMass - reference.TotalMass), 0, 1e-12);
}

// ------------------------------------------------------------------ 6
Section("Association memory for the bilinear positive kernel");
{
    var r = new Random(6);
    int mq = 7, mk = 9, mv = 8;
    var h = Matrix.Random(mq, mk, seed: 61, lo: 0.05, hi: 1);
    var history = Enumerable.Range(0, 30).Select(_ => (Key: RandomCode(r, mk, 2), Value: RandomCode(r, mv, 3))).ToImmutableArray();
    var memory = history.Aggregate(AssociationMemory.Empty(mk, mv), (m, x) => m.Write(x.Key, x.Value));
    var a = RandomCode(r, mq, 2);
    var weights = history.Select(x => CoefficientLayer.Score(a, h, x.Key)).ToArray();
    var direct = Codes.Mix(history.Select((x, j) => (weights[j], x.Value)));
    var read = memory.Read(h, a);
    Near("recurrent read equals the explicit kernel average (SPCS Thm 13)", Codes.L1Distance(read, direct), 0, 1e-12);
    Check("association entries are bounded by M_K * M_V", memory.OccupiedEntries <= mk * mv);

    var e1 = SparseCode.OneHot(2, 0); var e2 = SparseCode.OneHot(2, 1);
    var same = AssociationMemory.Empty(2, 2).Write(e1, e1).Write(e2, e2);
    var swapped = AssociationMemory.Empty(2, 2).Write(e1, e2).Write(e2, e1);
    Check("equal key and value totals, different reads (SPCS Prop. 14)",
        same.KeyMass(0) == swapped.KeyMass(0) && same.Read(Matrix.Identity(2), e1).Equals(e1) && swapped.Read(Matrix.Identity(2), e1).Equals(e2));

    var tq = RandomTransport(r, mq, 10, 2); var tk = RandomTransport(r, mk, 11, 2); var tv = RandomTransport(r, mv, 12, 2);
    var hNew = Matrix.Random(10, 11, seed: 62, lo: 0.05, hi: 1);
    var hOld = tq.ToMatrix().Transpose().Multiply(hNew).Multiply(tk.ToMatrix());
    var before = memory.Read(hOld, a);
    var after = memory.Migrate(tk, tv).Read(hNew, tq.Apply(a));
    Near("migrated read equals T_V applied to the old read (SPCS Thm 15)", Codes.L1Distance(after, tv.Apply(before)), 0, 1e-12);

    var (pruned, removed) = memory.Prune(0.2, h, a);
    AtMost("pruned read moves by at most 2 tau in l1 (SPCS Eq. 17)", Codes.L1Distance(pruned.Read(h, a), read), 2 * removed);
}

// ------------------------------------------------------------------ 7
Section("Explanations: paths, modalities and Shapley values");
{
    var r = new Random(7);
    var quad = Matrix.Random(10, 10, seed: 71); var lin = RandomVector(r, 10);
    double F(Vector c) => Vec.Dot(c, quad.Multiply(c)) + Vec.Dot(lin, c);
    Vector Gradient(Vector c) => Vec.Add(Vec.Add(quad.Multiply(c), quad.MultiplyTransposed(c)), lin);
    var c0 = RandomCode(r, 10, 4); var c1 = RandomCode(r, 10, 4);
    var shares = AnchoredPath.Attribute(Gradient, c0, c1, anchor: c0.Indices[0], steps: 8);
    Near("anchored path shares sum to f(c1) - f(c0) (INT Thm 11)", shares.Values.Sum(), F(c1.ToDense()) - F(c0.ToDense()), 1e-12);
    Vector ShiftedGradient(Vector c) => Vec.Create(10, j => Gradient(c)[j] + 5 * (Vec.Sum(c) - 1) + 3);
    var shifted = AnchoredPath.Attribute(ShiftedGradient, c0, c1, c0.Indices[0], 8);
    Near("shares do not depend on the off-simplex extension", shares.Max(kv => Math.Abs(kv.Value - shifted[kv.Key])), 0, 1e-12);

    var modal = new ModalityCode(SparseCode.Create(3, new[] { (0, 0.5), (1, 0.2), (2, 0.3) }),
        ImmutableArray.Create(RandomCode(r, 6, 3), RandomCode(r, 4, 2), RandomCode(r, 5, 4)));
    var global = modal.Global();
    var (balance, detail) = modal.EntropyParts();
    Near("H(p) = H(rho) + sum rho_m H(pi_m) (MM Lemma 1)", global.Entropy(), balance + detail, 1e-13);
    var back = ModalityCode.FromGlobal(global, new[] { 6, 4, 5 });
    Near("modality factorisation round trip", Codes.L1Distance(back.Global(), global) + Codes.L1Distance(back.Mass, modal.Mass), 0, 1e-13);

    var players = Enumerable.Range(0, 9).Select(_ => (Weight: 0.1 + r.NextDouble(), Value: 2 * r.NextDouble() - 1)).ToImmutableArray();
    var game = new ReadGame(BackgroundWeight: 0.4, BackgroundValue: 0.15, players);
    var phi = game.ShapleyExact();
    Near("Shapley efficiency: sum phi = v(N) - v(empty) (SH Lemma 1)", Vec.Sum(phi), game.Value(Enumerable.Range(0, 9)) - game.Value(Array.Empty<int>()), 1e-12);
    Near("constant-time marginal equals the coalition difference (SH Lemma 6)",
        game.Marginal(4, 0.4 + players[0].Weight + players[2].Weight, game.Value(new[] { 0, 2 })), game.Value(new[] { 0, 2, 4 }) - game.Value(new[] { 0, 2 }), 1e-14);
    Check("marginal range bound (SH Prop. 7)", Enumerable.Range(0, 9).All(i => Math.Abs(phi[i]) <= game.MarginalBound(i, 1) + 1e-12));
    var equal = new ReadGame(0.4, 0.15, players.Select(p => (0.35, p.Value)).ToImmutableArray());
    Near("equal-weight closed form equals enumeration (SH Thm 8)", MaxDiff(equal.ShapleyEqualWeights(), equal.ShapleyExact()), 0, 1e-12);
    Near("permutation sampling approaches the exact values", MaxDiff(game.ShapleySampled(20000, seed: 72), phi), 0, 0.01);
}

// ------------------------------------------------------------------ 8
Section("Sparse adjoints");
{
    var r = new Random(8);
    int n = 12, dk = 5, dv = 4;
    double h = 1e-6;
    var d = new AtomDictionary(Matrix.Random(6, n, seed: 81), "d");
    var c = RandomCode(r, n, 4);
    var target = RandomVector(r, 6);
    var g = Vec.Subtract(d.Decode(c), target);
    var adj = SparseAdjoints.Decoding(d, c, g);
    double Loss(Vector dense) => 0.5 * Math.Pow(Vec.Distance(d.Atoms.Multiply(dense), target), 2);
    var dense = c.ToDense();
    double coefErr = Enumerable.Range(0, c.Support).Max(k =>
    {
        int j = c.Indices[k];
        return Math.Abs(adj.Coefficients[k] - (Loss(dense.SetItem(j, dense[j] + h)) - Loss(dense.SetItem(j, dense[j] - h))) / (2 * h));
    });
    Near("decoding pullback D_A^T g matches finite differences (BP Thm 1)", coefErr, 0, 1e-8);
    Near("atom derivative is g c_j", MaxDiff(adj.Atoms[1], Vec.Scale(g, c.Values[1])), 0, 0);

    var kernel = new ResponseKernel(Matrix.Random(dk, n, seed: 82), 0.8);
    var memory = Enumerable.Range(0, 20).Aggregate(CoefficientMemory.Empty(n, dv), (m, _) => m.Write(RandomCode(r, n, 3), RandomVector(r, dv), 0.5 + r.NextDouble()));
    var q = RandomVector(r, dk); var up = RandomVector(r, dv);
    var wc = RandomCode(r, n, 3); var wv = RandomVector(r, dv); double ww = 1.3;
    double L(CoefficientMemory m, ResponseKernel k, Vector query) => Vec.Dot(up, m.Read(k, query).Output);
    var written = memory.Write(wc, wv, ww);
    var readAdj = SparseAdjoints.Read(written, kernel, q, up);
    double qErr = Enumerable.Range(0, dk).Max(i => Math.Abs(readAdj.Query[i] - (L(written, kernel, q.SetItem(i, q[i] + h)) - L(written, kernel, q.SetItem(i, q[i] - h))) / (2 * h)));
    Near("read adjoint: query derivative (BP Thm 5)", qErr, 0, 1e-8);
    double tauFd = (L(written, kernel with { Temperature = 0.8 + h }, q) - L(written, kernel with { Temperature = 0.8 - h }, q)) / (2 * h);
    Near("read adjoint: temperature derivative", readAdj.Temperature, tauFd, 1e-8);

    var writeAdj = SparseAdjoints.Write(wc, wv, ww, j => readAdj.Mass[j], j => readAdj.ValueSum[j]);
    double vErr = Enumerable.Range(0, dv).Max(i => Math.Abs(writeAdj.Value[i] -
        (L(memory.Write(wc, wv.SetItem(i, wv[i] + h), ww), kernel, q) - L(memory.Write(wc, wv.SetItem(i, wv[i] - h), ww), kernel, q)) / (2 * h)));
    Near("write adjoint: value derivative through the read (BP Thm 6)", vErr, 0, 1e-8);
    Near("write adjoint: exposure-weight derivative", writeAdj.Weight, (L(memory.Write(wc, wv, ww + h), kernel, q) - L(memory.Write(wc, wv, ww - h), kernel, q)) / (2 * h), 1e-8);
    int a0 = wc.Indices[0];
    double cFd = (L(written.Write(SparseCode.OneHot(n, a0), wv, ww * h), kernel, q) - L(written, kernel, q)) / h;
    Near("write adjoint: ambient coefficient derivative", writeAdj.Code[0], cFd, 1e-5);
}

// ------------------------------------------------------------------ 9
Section("Categorical geometry");
{
    var r = new Random(9);
    var theta = RandomVector(r, 8);
    var p = Categorical.Softmax(theta);
    var x = RandomVector(r, 8);
    var fx = Categorical.FisherProduct(p, x);
    Near("Fisher product annihilates constants and sums to zero (PV Prop. 8)", Vec.NormInf(Categorical.FisherProduct(p, Vec.Create(8, _ => 1.0))) + Math.Abs(Vec.Sum(fx)), 0, 1e-14);
    var solved = Categorical.FisherSolve(p, fx);
    double mean = Vec.Sum(x) / 8;
    Near("Fisher solve recovers x up to a constant", MaxDiff(solved, Vec.Create(8, k => x[k] - mean)), 0, 1e-11);

    var steps = Enumerable.Range(0, 5).Select(_ => (StepSize: 0.1 + r.NextDouble(), Cost: RandomVector(r, 8))).ToImmutableArray();
    var iterated = steps.Aggregate(p, (code, s) => Categorical.EntropicStep(code, j => s.Cost[j], s.StepSize));
    var collapsed = Categorical.EntropicCollapse(theta, steps);
    Near("K entropic steps collapse to softmax(theta - sum alpha a) (PV Thm 9)", Codes.L1Distance(iterated, collapsed), 0, 1e-13);
    var query = RandomVector(r, 8);
    var meta = Categorical.CollapsedMetaGradient(collapsed, query);
    double h = 1e-6;
    double metaErr = Enumerable.Range(0, 8).Max(i => Math.Abs(meta[i] -
        (Vec.Dot(query, Categorical.EntropicCollapse(theta.SetItem(i, theta[i] + h), steps).ToDense()) - Vec.Dot(query, Categorical.EntropicCollapse(theta.SetItem(i, theta[i] - h), steps).ToDense())) / (2 * h)));
    Near("collapsed meta-gradient F_z(p_K) grad Q matches finite differences (PV Eq. 15)", metaErr, 0, 1e-8);

    var psi = Enumerable.Range(0, 8).Select(_ => RandomVector(r, 3)).ToImmutableArray();
    var exact = Enumerable.Range(0, 8).Aggregate(Vec.Zero(3), (acc, j) => Vec.AddScaled(acc, p[j], psi[j]));
    Near("head covering the support is exact", MaxDiff(Categorical.HeadTailEstimate(p, j => psi[j], Enumerable.Range(0, 8), 1, 0), exact), 0, 1e-15);
    var head = p.Entries.OrderByDescending(e => e.Value).Take(3).Select(e => e.Index).ToArray();
    var average = Enumerable.Range(0, 4000).Aggregate(Vec.Zero(3), (acc, seed) => Vec.AddScaled(acc, 1.0 / 4000, Categorical.HeadTailEstimate(p, j => psi[j], head, 4, seed)));
    Near("head-and-tail estimator is unbiased (PV Thm 13, 4000 seeds)", MaxDiff(average, exact), 0, 0.01);
}

// ------------------------------------------------------------------ 10
Section("Certificates and allocation");
{
    var r = new Random(10);
    var eps = new[] { 0.01, 0.03, 0.02, 0.005 }; var lip = new[] { 1.0, 1.4, 0.8, 1.1 };
    double manual = 0.01 * 1.4 * 0.8 * 1.1 + 0.03 * 0.8 * 1.1 + 0.02 * 1.1 + 0.005;
    Near("layerwise error = sum eps_l prod L_j (VQ Thm 12, SPCS Thm 16)", Certificates.LayerwiseError(eps, lip), manual, 1e-15);
    Near("recurrent error geometric sum (VQ Cor. 12.1)", Certificates.RecurrentError(0.1, 0.5, 3), 0.1 * 1.75, 1e-15);

    bool tvOk = true, nextOk = true, greedyOk = true, readOk = true;
    for (int trial = 0; trial < 300; trial++)
    {
        var z = RandomVector(r, 9, 2); double e = 0.4 * r.NextDouble();
        var z2 = Vec.Create(9, j => z[j] + e * (2 * r.NextDouble() - 1));
        var p = Categorical.Softmax(z); var p2 = Categorical.Softmax(z2);
        nextOk &= Codes.TotalVariation(p, p2) <= Certificates.NextTokenTotalVariation(e) + 1e-12;
        if (Certificates.GreedyTokenIsPreserved(z, e)) greedyOk &= z.IndexOf(z.Max()) == z2.IndexOf(z2.Max());
        var logRatio = RandomVector(r, 9, 1.2);
        var reweighted = SparseCode.Normalize(9, p.Entries.Select(x => (x.Index, x.Value * Math.Exp(logRatio[x.Index]))));
        tvOk &= Codes.TotalVariation(p, reweighted) <= Certificates.ReweightingTotalVariation(logRatio.Max() - logRatio.Min()) + 1e-12;

        int d = 6, t = 7;
        var q = RandomVector(r, d); var dq = RandomVector(r, d, 0.05);
        var keys = Enumerable.Range(0, t).Select(_ => RandomVector(r, d)).ToArray(); var dkeys = keys.Select(_ => RandomVector(r, d, 0.05)).ToArray();
        var vals = Enumerable.Range(0, t).Select(_ => RandomVector(r, 4)).ToArray(); var dvals = vals.Select(_ => RandomVector(r, 4, 0.05)).ToArray();
        Vector Attend(Vector qq, Vector[] kk, Vector[] vv)
        {
            var a = Categorical.Softmax(kk.Select(k => Vec.Dot(qq, k) / Math.Sqrt(d)).ToArray());
            return Enumerable.Range(0, t).Aggregate(Vec.Zero(4), (acc, j) => Vec.AddScaled(acc, a[j], vv[j]));
        }
        double actual = Vec.Distance(Attend(q, keys, vals), Attend(Vec.Add(q, dq), keys.Zip(dkeys, Vec.Add).ToArray(), vals.Zip(dvals, Vec.Add).ToArray()));
        readOk &= actual <= Certificates.SoftmaxReadPerturbation(Vec.Norm(q), keys.Max(Vec.Norm), vals.Max(Vec.Norm), Vec.Norm(dq), dkeys.Max(Vec.Norm), dvals.Max(Vec.Norm), d) + 1e-12;
    }
    Check("reweighting: TV <= tanh(omega/4) (VQ Lemma 6, 300 trials)", tvOk);
    Check("next-token TV <= tanh(eps/2) (VQ Thm 13, 300 trials)", nextOk);
    Check("margin > 2 eps preserves the greedy token (300 trials)", greedyOk);
    Check("softmax read perturbation bound (SPCS Thm 2, 300 trials)", readOk);
    Near("two-point case attains tanh(omega/4)", Codes.TotalVariation(
        SparseCode.Create(2, new[] { (0, 1 / (1 + Math.Exp(-0.6))), (1, 1 - 1 / (1 + Math.Exp(-0.6))) }),
        SparseCode.Normalize(2, new[] { (0, 1 / (1 + Math.Exp(-0.6))), (1, (1 - 1 / (1 + Math.Exp(-0.6))) * Math.Exp(1.2)) })), Certificates.ReweightingTotalVariation(1.2), 1e-13);
    Near("response amplification example 0.50025 (INT Lemma 9)", Certificates.ResponseAmplification(0.001, 1, 1000), 0.50025, 1e-5);
    Near("search stopping bound U / (Z_A + U) (VQ Prop. 21)", Certificates.OmittedResponseBound(3, 1), 0.25, 0);

    var a = new[] { 1.0, 4.0, 0.5 }; var cost = new[] { 1.0, 2.0, 0.5 };
    var s = SupportAllocation.InverseSquareRoot(a, cost, budget: 60);
    Near("inverse-square-root allocation spends the budget (VQ Thm 15)", s.Zip(cost, (x, c) => x * c).Sum(), 60, 1e-12);
    var multipliers = Enumerable.Range(0, 3).Select(l => a[l] / (2 * cost[l] * Math.Pow(s[l], 1.5))).ToArray();
    Near("  and equalises marginal benefit per cost", multipliers.Max() - multipliers.Min(), 0, 1e-15);
    var s2 = SupportAllocation.InversePower(a, cost, exponent: 0.7, errorBudget: 0.9);
    Near("inverse-power allocation meets the error budget exactly (MAML Thm 12)", Enumerable.Range(0, 3).Sum(k => a[k] * Math.Pow(s2[k], -0.7)), 0.9, 1e-12);
    var m2 = Enumerable.Range(0, 3).Select(k => cost[k] / (0.7 * a[k] * Math.Pow(s2[k], -1.7))).ToArray();
    Near("  with one common multiplier", m2.Max() - m2.Min(), 0, 1e-10);
}

// ------------------------------------------------------------------ 11
Section("Resolution diffusion");
{
    var hierarchy = VocabularyHierarchy.Uniform(4, 2);
    var parity = SequenceLaw.FromWeights(16, 3, x => Enumerable.Range(0, 3).All(i => x[i] % 4 == Enumerable.Range(0, 3).Where(j => j != i).Sum(j => x[j] / 4) % 4) ? 1 : 0);
    double ln4 = Math.Log(4);
    Near("parity: level-synchronous gap is zero (VTD Prop. 3)", ResolutionDiffusion.FactorisationGap(parity, hierarchy, ResolutionSchedule.LevelSynchronous(3, 2)), 0, 1e-12);
    double bestMasked = (from s1 in new[] { 1, 2 } from s2 in new[] { 1, 2 } from s3 in new[] { 1, 2 }
                         select ResolutionDiffusion.FactorisationGap(parity, hierarchy, ResolutionSchedule.Masked(new[] { s1, s2, s3 }, 2))).Min();
    Near("parity: best two-step masked gap is log B", bestMasked, ln4, 1e-12);
    Near("parity: total correlation is 3 log B", ResolutionDiffusion.TotalCorrelation(parity, hierarchy), 3 * ln4, 1e-12);
    Near("one position per step has zero gap (VTD Thm 2)", ResolutionDiffusion.FactorisationGap(parity, hierarchy, ResolutionSchedule.Masked(new[] { 1, 2, 3 }, 2)), 0, 1e-12);

    var r = new Random(11);
    var table = Enumerable.Range(0, 16 * 16 * 16).Select(_ => r.NextDouble() < 0.4 ? 0 : r.NextDouble()).ToArray();
    var law = SequenceLaw.FromWeights(16, 3, x => table[(x[0] * 16 + x[1]) * 16 + x[2]]);
    double tc = ResolutionDiffusion.TotalCorrelation(law, hierarchy), cri = ResolutionDiffusion.CrossResolutionInformation(law, hierarchy);
    Near("level-synchronous gap = TC - CRI on a random law (VTD Thm 3)", ResolutionDiffusion.FactorisationGap(law, hierarchy, ResolutionSchedule.LevelSynchronous(3, 2)), tc - cri, 1e-11);
    Near("the one-shot gap equals TC", ResolutionDiffusion.FactorisationGap(law, hierarchy, ResolutionSchedule.Masked(new[] { 1, 1, 1 }, 2)), tc, 1e-11);
    Near("cell sampler bound: 32 children at 8 bits", ResolutionDiffusion.CellSamplerBound(32, 255), 32 / 510.0, 1e-15);
    Check("schedule classification", ResolutionSchedule.Masked(new[] { 1, 2 }, 3).IsMasked && !ResolutionSchedule.LevelSynchronous(2, 3).IsMasked);
}

// ------------------------------------------------------------------ 12
Section("Harness contracts");
{
    var d = new AtomDictionary(Matrix.Random(4, 10, seed: 121), "tok-v3");
    var resolution = new Resolution(Atoms: 10, Support: 3, Precision: 255, MemoryRows: 10);
    var good = new CodeRecord(SparseCode.Uniform(10, new[] { 1, 4 }), "tok-v3", Layer: 2, Modality: "text", Sources: ImmutableArray.Create("doc-17"));
    Check("a valid record has no violations", StateContract.Check(good, d, resolution).IsEmpty);
    var bad = good with { DictionaryVersion = "tok-v2", Code = SparseCode.Uniform(10, new[] { 0, 1, 2, 3 }), Sources = ImmutableArray<string>.Empty };
    Check("version, support and provenance violations are all reported", StateContract.Check(bad, d, resolution).Length == 3);
    Check("raw state is rejected, not silently repaired", StateContract.CheckRaw(new[] { 0.5, -0.1, 0.7 }).Length == 2 && StateContract.CheckRaw(new[] { 0.25, 0.75 }).IsEmpty);
    bool threw = false;
    try { SparseCode.Create(3, new[] { (0, 0.5), (1, 0.4) }); } catch (ArgumentException) { threw = true; }
    Check("a code without unit mass cannot be constructed", threw);
}

Console.WriteLine($"\n{passed} passed, {failed} failed.");
return failed == 0 ? 0 : 1;
