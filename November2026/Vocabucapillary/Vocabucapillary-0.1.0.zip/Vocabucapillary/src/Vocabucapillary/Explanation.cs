namespace Vocabucapillary;

/// <summary>Exact effect of deleting a row group from a fixed read.</summary>
public sealed record DeletionEffect(double ResponseMass, Vector Change, Vector ReadWithoutGroup)
{
    /// <summary>‖o − o₋G‖ ≤ Δᵤ·π_G, with Δᵤ the diameter of the value means (Vocabuquantization, Theorem 7).</summary>
    public double Bound(double valueDiameter) => valueDiameter * ResponseMass;
}

/// <summary>
/// Explanations of a fixed coefficient-memory read. They concern a matched change to the memory
/// representation with the query held fixed, which is a different intervention from deleting a word
/// from the prompt and recomputing the model.
/// </summary>
public static class ReadExplanation
{
    /// <summary>
    /// Signed sensitivity of the scalar readout f = bᵀo to a matched gate exp(θⱼ) on row j:
    /// βⱼ = πⱼ(bᵀuⱼ − f), with Σⱼβⱼ = 0 (Interpretability, Theorem 7). Large participation πⱼ does not
    /// imply large sensitivity, and a positive coefficient can have a negative effect.
    /// </summary>
    public static ImmutableSortedDictionary<int, double> GateSensitivities(MemoryRead read, Vector readout)
    {
        double f = Vec.Dot(readout, read.Output);
        return read.ResponseMass.ToImmutableSortedDictionary(kv => kv.Key, kv => kv.Value * (Vec.Dot(readout, read.Means[kv.Key]) - f));
    }

    /// <summary>
    /// o − o₋G = Σ_{j∈G} πⱼ(uⱼ − o) / (1 − π_G), computed from the read alone without rereading
    /// (Interpretability, Theorem 8). Requires π_G &lt; 1.
    /// </summary>
    public static DeletionEffect Delete(MemoryRead read, IEnumerable<int> group)
    {
        var g = group.Where(read.ResponseMass.ContainsKey).Distinct().ToArray();
        double mass = g.Sum(j => read.ResponseMass[j]);
        if (!(mass < 1)) throw new ArgumentException("The group carries the whole response; the remaining read is undefined.");
        var change = g.Aggregate(Vec.Zero(read.Output.Length),
            (acc, j) => Vec.AddScaled(acc, read.ResponseMass[j] / (1 - mass), Vec.Subtract(read.Means[j], read.Output)));
        return new DeletionEffect(mass, change, Vec.Subtract(read.Output, change));
    }

    /// <summary>Diameter of the contextual value means, Δᵤ.</summary>
    public static double ValueDiameter(MemoryRead read)
    {
        var u = read.Means.Values.ToArray();
        double best = 0;
        for (int a = 0; a < u.Length; a++)
            for (int b = a + 1; b < u.Length; b++) best = Math.Max(best, Vec.Distance(u[a], u[b]));
        return best;
    }

    /// <summary>
    /// The rows to keep under a row budget for this query: those of largest response mass, which
    /// minimises the deletion certificate. Keeping the largest stored masses optimises something else.
    /// </summary>
    public static ImmutableArray<int> TopResponseRows(MemoryRead read, int rows) =>
        read.ResponseMass.OrderByDescending(kv => kv.Value).ThenBy(kv => kv.Key).Take(rows).Select(kv => kv.Key).ToImmutableArray();
}

/// <summary>
/// Anchored path attribution on a simplex face (Interpretability, Theorem 11):
/// Aⱼ = (c¹ⱼ − c⁰ⱼ)∫₀¹[∂ⱼf − ∂ₐf](c(t))dt along the straight path, for a reference address a.
/// The shares sum to f(c¹) − f(c⁰) and do not depend on how f is extended off the simplex. They do
/// depend on the baseline, the anchor and the path, and are an accounting identity, not a causal claim.
/// </summary>
public static class AnchoredPath
{
    /// <param name="gradient">Gradient of any differentiable extension of f, evaluated on a dense coefficient vector.</param>
    /// <param name="baseline">The starting code c⁰.</param>
    /// <param name="endpoint">The final code c¹.</param>
    /// <param name="anchor">The reference address a, inside the face.</param>
    /// <param name="steps">Midpoint-rule nodes. The rule is exact when the gradient is affine along the path.</param>
    public static ImmutableSortedDictionary<int, double> Attribute(Func<Vector, Vector> gradient, SparseCode baseline, SparseCode endpoint, int anchor, int steps = 64)
    {
        if (baseline.Width != endpoint.Width) throw new ArgumentException("Baseline and endpoint must share one dictionary width.");
        if (steps < 1) throw new ArgumentOutOfRangeException(nameof(steps));
        Vector c0 = baseline.ToDense(), c1 = endpoint.ToDense(), delta = Vec.Subtract(c1, c0);
        var face = baseline.Indices.Union(endpoint.Indices).Where(j => j != anchor).OrderBy(j => j).ToArray();
        var integral = new double[face.Length];
        for (int k = 0; k < steps; k++)
        {
            var g = gradient(Vec.AddScaled(c0, (k + 0.5) / steps, delta));
            for (int i = 0; i < face.Length; i++) integral[i] += (g[face[i]] - g[anchor]) / steps;
        }
        return face.Select((j, i) => KeyValuePair.Create(j, delta[j] * integral[i])).ToImmutableSortedDictionary();
    }
}

/// <summary>
/// A multimodal code p_{mj} = ρ_m·π_{mj}: modality mass ρ and a conditional code per modality over a
/// disjoint tagged union of address sets (Multimodal Explainability, Definition 1).
/// </summary>
public sealed record ModalityCode(SparseCode Mass, ImmutableArray<SparseCode> Conditionals)
{
    public int Modalities => Conditionals.Length;

    /// <summary>The flat code over the tagged union, modality m occupying a contiguous address block.</summary>
    public SparseCode Global()
    {
        if (Mass.Width != Modalities) throw new ArgumentException("One mass entry per modality is required.");
        var offsets = Offsets();
        return SparseCode.Normalize(offsets[^1], Mass.Entries.SelectMany(m =>
            Conditionals[m.Index].Entries.Select(e => (offsets[m.Index] + e.Index, m.Value * e.Value))));
    }

    /// <summary>Recovers (ρ, π) from a flat code, given the modality widths. Absent modalities get a uniform placeholder.</summary>
    public static ModalityCode FromGlobal(SparseCode global, IReadOnlyList<int> widths)
    {
        var offsets = widths.Aggregate(ImmutableArray.Create(0), (acc, w) => acc.Add(acc[^1] + w));
        if (offsets[^1] != global.Width) throw new ArgumentException("Modality widths do not sum to the code width.");
        int Modality(int address) => Enumerable.Range(0, widths.Count).First(m => address < offsets[m + 1]);
        var mass = SparseCode.Normalize(widths.Count, global.Entries.Select(e => (Modality(e.Index), e.Value)));
        var conditionals = Enumerable.Range(0, widths.Count).Select(m => mass[m] > 0
            ? SparseCode.Normalize(widths[m], global.Entries.Where(e => Modality(e.Index) == m).Select(e => (e.Index - offsets[m], e.Value)))
            : SparseCode.Uniform(widths[m], Enumerable.Range(0, widths[m]))).ToImmutableArray();
        return new ModalityCode(mass, conditionals);
    }

    /// <summary>
    /// H(p) = H(ρ) + Σ_m ρ_m H(π_m) (Lemma 1): modality balance and within-modality detail, in nats.
    /// </summary>
    public (double Balance, double Detail) EntropyParts() =>
        (Mass.Entropy(), Mass.Entries.Sum(m => m.Value * Conditionals[m.Index].Entropy()));

    private ImmutableArray<int> Offsets() =>
        Conditionals.Aggregate(ImmutableArray.Create(0), (acc, c) => acc.Add(acc[^1] + c.Width));
}

/// <summary>
/// The boundary game of a normalised read (Shapley Explanations, Eq. 7):
/// v(S) = (b₀ + Σ_{i∈S} aᵢyᵢ) / (a₀ + Σ_{i∈S} aᵢ) with a positive background weight a₀.
/// The background is part of the declared intervention baseline; it makes the empty coalition defined.
/// </summary>
public sealed record ReadGame(double BackgroundWeight, double BackgroundValue, ImmutableArray<(double Weight, double Value)> Players)
{
    public int Count => Players.Length;

    /// <summary>
    /// Players are the occupied rows of a read, with aⱼ ∝ mⱼφⱼ(q) and yⱼ = bᵀuⱼ. Weights are
    /// normalised so that they sum to one, and the background weight is stated on that scale.
    /// </summary>
    public static (ReadGame Game, ImmutableArray<int> Addresses) FromRead(MemoryRead read, Vector readout, double backgroundWeight, double backgroundValue)
    {
        var addresses = read.ResponseMass.Keys.ToImmutableArray();
        var players = addresses.Select(j => (read.ResponseMass[j], Vec.Dot(readout, read.Means[j]))).ToImmutableArray();
        return (new ReadGame(backgroundWeight, backgroundValue, players), addresses);
    }

    public double Value(IEnumerable<int> coalition)
    {
        double d = BackgroundWeight, b = BackgroundWeight * BackgroundValue;
        foreach (int i in coalition.Distinct()) { d += Players[i].Weight; b += Players[i].Weight * Players[i].Value; }
        return b / d;
    }

    /// <summary>Constant-time marginal Δᵢv(S) = aᵢ(yᵢ − v(S)) / (D_S + aᵢ) from the running sums (Lemma 6).</summary>
    public double Marginal(int player, double coalitionWeight, double coalitionValue) =>
        Players[player].Weight * (Players[player].Value - coalitionValue) / (coalitionWeight + Players[player].Weight);

    /// <summary>|Δᵢv(S)| ≤ 2R·aᵢ / (a₀ + aᵢ) when every value is bounded by R (Proposition 7).</summary>
    public double MarginalBound(int player, double valueBound) =>
        2 * valueBound * Players[player].Weight / (BackgroundWeight + Players[player].Weight);

    /// <summary>Exact Shapley values by coalition enumeration: O(2ⁿ·n) time, O(2ⁿ) memory, n ≤ 20.</summary>
    public Vector ShapleyExact()
    {
        int n = Count;
        if (n > 20) throw new InvalidOperationException("Exact enumeration is limited to 20 players; use ShapleyEqualWeights or ShapleySampled.");
        var weight = new double[1 << n];
        var numerator = new double[1 << n];
        weight[0] = BackgroundWeight; numerator[0] = BackgroundWeight * BackgroundValue;
        for (int s = 1; s < weight.Length; s++)
        {
            int low = int.TrailingZeroCount(s), rest = s & (s - 1);
            weight[s] = weight[rest] + Players[low].Weight;
            numerator[s] = numerator[rest] + Players[low].Weight * Players[low].Value;
        }
        // Coalition-size weights |S|!(n−|S|−1)!/n!
        var sizeWeight = new double[n + 1]; // the entry for the full coalition is never used and stays zero
        for (int k = 0; k < n; k++)
            sizeWeight[k] = Math.Exp(-Vocabuquantizer.Log2Binomial(n - 1, k) * Math.Log(2)) / n;
        var phi = new double[n];
        for (int s = 0; s < weight.Length; s++)
        {
            double v = numerator[s] / weight[s], w = sizeWeight[int.PopCount(s)];
            for (int i = 0; i < n; i++)
                if ((s & (1 << i)) == 0) phi[i] += w * Marginal(i, weight[s], v);
        }
        return Vec.Seal(phi);
    }

    /// <summary>
    /// Exact Shapley values in O(n) when all player weights are equal: φᵢ = A·yᵢ − B·y₀ − (A − B)·ȳ₋ᵢ
    /// (Theorem 8). Equal attention weights are a stronger condition than equal support or equal mass.
    /// </summary>
    public Vector ShapleyEqualWeights(double tolerance = 1e-12)
    {
        int n = Count;
        if (n == 0) return Vector.Empty;
        double a = Players[0].Weight;
        if (Players.Any(p => Math.Abs(p.Weight - a) > tolerance * a)) throw new InvalidOperationException("Player weights are not equal.");
        double q = BackgroundWeight / a;
        if (n == 1) return Vec.Of((Players[0].Value - BackgroundValue) / (q + 1));
        double bigA = Enumerable.Range(0, n).Sum(k => 1 / (q + k + 1)) / n, bigB = 1 / (q + n), total = Players.Sum(p => p.Value);
        return Vec.Create(n, i => bigA * Players[i].Value - bigB * BackgroundValue - (bigA - bigB) * (total - Players[i].Value) / (n - 1));
    }

    /// <summary>
    /// Unbiased permutation-sampling estimate with O(n) work per permutation, using the running sums.
    /// Deterministic for a given seed.
    /// </summary>
    public Vector ShapleySampled(int permutations, int seed)
    {
        var rng = new Random(seed);
        var phi = new double[Count];
        var order = Enumerable.Range(0, Count).ToArray();
        for (int p = 0; p < permutations; p++)
        {
            rng.Shuffle(order);
            double d = BackgroundWeight, b = BackgroundWeight * BackgroundValue;
            foreach (int i in order)
            {
                phi[i] += Marginal(i, d, b / d) / permutations;
                d += Players[i].Weight; b += Players[i].Weight * Players[i].Value;
            }
        }
        return Vec.Seal(phi);
    }
}
