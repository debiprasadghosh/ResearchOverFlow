namespace Vocabucapillary;

/// <summary>
/// A nonnegative column-stochastic map between coefficient spaces, stored as one code per input
/// address. It preserves the simplex, is nonexpansive in ℓ₁, and maps a code of support s to one of
/// support at most b·s when every column has at most b nonzeros
/// (Sparse Positive Coefficient Spaces, Theorems 3 and 11).
/// </summary>
public sealed record Transport
{
    public int OutputWidth { get; }
    public ImmutableArray<SparseCode> Columns { get; }
    public int InputWidth => Columns.Length;

    private Transport(int outputWidth, ImmutableArray<SparseCode> columns) => (OutputWidth, Columns) = (outputWidth, columns);

    public static Transport FromColumns(IEnumerable<SparseCode> columns)
    {
        var cols = columns.ToImmutableArray();
        if (cols.IsEmpty) throw new ArgumentException("A transport needs at least one column.");
        int width = cols[0].Width;
        if (cols.Any(c => c.Width != width)) throw new ArgumentException("All columns must lie in the same target simplex.");
        return new Transport(width, cols);
    }

    public static Transport Identity(int width) =>
        FromColumns(Enumerable.Range(0, width).Select(j => SparseCode.OneHot(width, j)));

    /// <summary>Zero-padding into a wider dictionary that keeps every old atom at its old address.</summary>
    public static Transport Embedding(int width, int newWidth) =>
        FromColumns(Enumerable.Range(0, width).Select(j => SparseCode.OneHot(newWidth, j)));

    /// <summary>Deterministic merging: address j is sent to its representative g(j).</summary>
    public static Transport Merge(IReadOnlyList<int> representative, int outputWidth) =>
        FromColumns(representative.Select(g => SparseCode.OneHot(outputWidth, g)));

    /// <summary>Reads a column-stochastic matrix (rows = outputs, columns = inputs).</summary>
    public static Transport FromMatrix(Matrix t) =>
        FromColumns(Enumerable.Range(0, t.Cols).Select(j => SparseCode.Create(t.Rows, Enumerable.Range(0, t.Rows).Select(i => (i, t[i, j])))));

    /// <summary>T c, a mixture of the active columns.</summary>
    public SparseCode Apply(SparseCode c)
    {
        if (c.Width != InputWidth) throw new ArgumentException($"Code width {c.Width} does not match transport input width {InputWidth}.");
        return Codes.Mix(c.Entries.Select(e => (e.Value, Columns[e.Index])));
    }

    /// <summary>T x for a nonnegative mass vector that need not be normalised.</summary>
    public Vector Apply(Vector x)
    {
        if (x.Length != InputWidth) throw new ArgumentException("Vector length must equal the transport input width.");
        var r = new double[OutputWidth];
        for (int j = 0; j < x.Length; j++)
            if (x[j] != 0) foreach (var (i, v) in Columns[j].Entries) r[i] += v * x[j];
        return Vec.Seal(r);
    }

    /// <summary>The composition next ∘ this.</summary>
    public Transport Then(Transport next) => FromColumns(Columns.Select(next.Apply));

    public int MaxColumnSupport => Columns.Max(c => c.Support);

    public bool Equals(Transport? other) =>
        other is not null && OutputWidth == other.OutputWidth && Columns.SequenceEqual(other.Columns);

    public override int GetHashCode() => Columns.Aggregate(OutputWidth, (h, c) => HashCode.Combine(h, c));

    /// <summary>
    /// Dobrushin coefficient η(T) = maxᵢⱼ TV(Teᵢ, Teⱼ), so that ‖Tp − Tq‖₁ ≤ η(T)‖p − q‖₁ on the simplex.
    /// A value well below one warns of oversmoothing under repetition. O(M²·b).
    /// </summary>
    public double ContractionCoefficient()
    {
        double best = 0;
        for (int a = 0; a < Columns.Length; a++)
            for (int b = a + 1; b < Columns.Length; b++) best = Math.Max(best, Codes.TotalVariation(Columns[a], Columns[b]));
        return best;
    }

    public Matrix ToMatrix() => Matrix.Create(OutputWidth, InputWidth, (i, j) => Columns[j][i]);

    /// <summary>
    /// maxⱼ ‖E T eⱼ − W dⱼ‖: zero exactly when the transport realises the linear map W between the two
    /// dictionaries, E T = W D, which requires every W dⱼ to lie in the convex hull of E's atoms
    /// (Theorem 3). Pass <c>null</c> for W to test function-preserving extension, E T = D (Theorem 12).
    /// </summary>
    public double IntertwiningResidual(AtomDictionary source, AtomDictionary target, Matrix? w = null)
    {
        if (source.Width != InputWidth || target.Width != OutputWidth) throw new ArgumentException("Dictionary widths do not match the transport.");
        return Enumerable.Range(0, InputWidth).Max(j =>
        {
            var mapped = w is null ? source.Atom(j) : w.Multiply(source.Atom(j));
            return Vec.Distance(target.Decode(Columns[j]), mapped);
        });
    }
}

/// <summary>
/// A nested vocabulary hierarchy: level 0 is the tokens, level <see cref="Depth"/> is the root.
/// Lowering resolution replaces a token by the prior restricted to its group, which decodes to the
/// prior-weighted group atom (Vocabucapillary Text Diffusion, Definition 1 and Proposition 1).
/// </summary>
public sealed record VocabularyHierarchy
{
    /// <summary>GroupOf[k][token] is the group label of the token at level k.</summary>
    public ImmutableArray<ImmutableArray<int>> GroupOf { get; }
    public ImmutableArray<int> GroupCount { get; }
    public int Width => GroupOf[0].Length;
    public int Depth => GroupOf.Length - 1;

    private VocabularyHierarchy(ImmutableArray<ImmutableArray<int>> groupOf)
    {
        GroupOf = groupOf;
        GroupCount = groupOf.Select(level => level.Max() + 1).ToImmutableArray();
    }

    /// <summary>
    /// Builds a hierarchy from the intermediate levels 1..K−1, each a group label per token. The token
    /// level and the root are added. Each level must coarsen the one below it.
    /// </summary>
    public static VocabularyHierarchy FromLevels(int width, IReadOnlyList<IReadOnlyList<int>> intermediateLevels)
    {
        var levels = new List<ImmutableArray<int>> { Enumerable.Range(0, width).ToImmutableArray() };
        foreach (var raw in intermediateLevels)
        {
            if (raw.Count != width) throw new ArgumentException("Every level needs one label per token.");
            var labels = raw.Distinct().OrderBy(v => v).ToList();
            var level = raw.Select(v => labels.IndexOf(v)).ToImmutableArray();
            var below = levels[^1];
            var parentOf = new Dictionary<int, int>();
            for (int t = 0; t < width; t++)
                if (parentOf.TryGetValue(below[t], out int parent) ? parent != level[t] : !parentOf.TryAdd(below[t], level[t]))
                    throw new ArgumentException("Levels are not nested: a group is split across two parents.");
            levels.Add(level);
        }
        levels.Add(Enumerable.Repeat(0, width).ToImmutableArray());
        return new VocabularyHierarchy(levels.ToImmutableArray());
    }

    /// <summary>The balanced hierarchy with N = branching^depth tokens.</summary>
    public static VocabularyHierarchy Uniform(int branching, int depth)
    {
        int width = (int)Math.Pow(branching, depth);
        return FromLevels(width, Enumerable.Range(1, depth - 1)
            .Select(k => (IReadOnlyList<int>)Enumerable.Range(0, width).Select(t => t / (int)Math.Pow(branching, k)).ToArray()).ToArray());
    }

    public IEnumerable<int> Members(int level, int group) => Enumerable.Range(0, Width).Where(t => GroupOf[level][t] == group);

    /// <summary>R_k(j): the prior restricted to the level-k group of token j, renormalised.</summary>
    public SparseCode ResolutionCode(Vector prior, int level, int token)
    {
        if (prior.Length != Width) throw new ArgumentException("The prior needs one weight per token.");
        return SparseCode.Normalize(Width, Members(level, GroupOf[level][token]).Select(t => (t, prior[t])));
    }

    /// <summary>The group masses of a code at a level, as a code over that level's groups.</summary>
    public SparseCode Coarsen(SparseCode c, int level) => MergeTransport(level).Apply(c);

    /// <summary>The merging transport from tokens to the groups of a level.</summary>
    public Transport MergeTransport(int level) => Transport.Merge(GroupOf[level], GroupCount[level]);

    /// <summary>The coarse dictionary of a level: one prior-weighted mean atom per group.</summary>
    public AtomDictionary CoarseDictionary(AtomDictionary d, Vector prior, int level) =>
        new(Matrix.FromColumns(Enumerable.Range(0, GroupCount[level])
            .Select(g => d.Decode(SparseCode.Normalize(Width, Members(level, g).Select(t => (t, prior[t]))))).ToArray()),
            $"{d.Version}/level{level}");
}
