namespace Vocabucapillary;

/// <summary>
/// Closed-form certificates from the papers. Each is a sufficient bound under its stated assumptions,
/// which the caller must justify (norm bounds, Lipschitz constants, a fixed query). None is a
/// measured property of a trained model.
/// </summary>
public static class Certificates
{
    /// <summary>
    /// TV(p, p′) ≤ tanh(ω/4) when p is reweighted by positive factors whose logarithms span at most ω
    /// (Vocabuquantization, Lemma 6; Memory and AI Harness, Theorem 7). The bound is attained.
    /// </summary>
    public static double ReweightingTotalVariation(double logRange) => Math.Tanh(RequireNonnegative(logRange) / 4);

    /// <summary>
    /// ‖o − ô‖ ≤ 2V·tanh(Δ/4) + ε_v for two normalised reads over the same values of norm at most V
    /// whose log responses differ by amounts spanning Δ across records (Memory and AI Harness, Theorem 7).
    /// </summary>
    public static double NormalizedReadBound(double valueNorm, double logResponseSpread, double valueError = 0) =>
        2 * valueNorm * ReweightingTotalVariation(logResponseSpread) + valueError;

    /// <summary>
    /// The conservative spread Δ ≤ 2Qε/τ + R*²/8 from a key residual bound ε, a query norm bound Q and
    /// an active score range R* (Memory and AI Harness, Corollary 7.1). Exact reconstruction removes
    /// the first term and leaves the Jensen term.
    /// </summary>
    public static double ConversionSpread(double queryNorm, double keyResidual, double temperature, double activeScoreRange) =>
        2 * queryNorm * keyResidual / temperature + activeScoreRange * activeScoreRange / 8;

    /// <summary>‖o − õ‖ ≤ 2V·tanh(Qδ/(2τ)) after merging atoms that move by at most δ (Vocabuquantization, Theorem 9).</summary>
    public static double AtomMergingBound(double valueNorm, double queryNorm, double atomDisplacement, double temperature) =>
        2 * valueNorm * Math.Tanh(queryNorm * atomDisplacement / (2 * temperature));

    /// <summary>
    /// Largest response mass a group holding fraction η of stored mass can have when responses lie in
    /// [a, b], a &gt; 0: ηb / (ηb + (1 − η)a) (Interpretability, Lemma 9). Small stored mass does not
    /// imply small query influence.
    /// </summary>
    public static double ResponseAmplification(double storedFraction, double minResponse, double maxResponse) =>
        storedFraction * maxResponse / (storedFraction * maxResponse + (1 - storedFraction) * minResponse);

    /// <summary>
    /// Omitted response probability is at most U/(Z_A + U) when retained candidates contribute Z_A &gt; 0
    /// to the denominator and all omitted rows at most U; multiply by the value diameter for the
    /// fixed-read error (Vocabuquantization, Proposition 21).
    /// </summary>
    public static double OmittedResponseBound(double retainedDenominator, double omittedUpperBound) =>
        retainedDenominator > 0 ? omittedUpperBound / (retainedDenominator + omittedUpperBound)
                                : throw new ArgumentException("The retained denominator must be positive.");

    /// <summary>
    /// ‖o(qᵢ) − vᵢ‖ ≤ 2V·ρ/(1 + ρ) for interference ratio ρ = Σⱼ≠ᵢ bᵢⱼ / bᵢᵢ (Memory and AI Harness, Theorem 9).
    /// </summary>
    public static double InterferenceBound(double valueNorm, double interferenceRatio) =>
        2 * valueNorm * interferenceRatio / (1 + interferenceRatio);

    /// <summary>
    /// Perturbation of one softmax attention read under reconstructed queries, keys and values
    /// (Sparse Positive Coefficient Spaces, Theorem 2): δ = (Qε_k + Kε_q + ε_qε_k)/√d_h and
    /// ‖o − ô‖ ≤ ε_v + R·min(2, δ). It certifies one read, not a generation trajectory.
    /// </summary>
    public static double SoftmaxReadPerturbation(double queryNorm, double keyNorm, double valueNorm,
        double queryError, double keyError, double valueError, int headDimension)
    {
        double delta = (queryNorm * keyError + keyNorm * queryError + queryError * keyError) / Math.Sqrt(headDimension);
        return valueError + valueNorm * Math.Min(2, delta);
    }

    /// <summary>
    /// E_L ≤ Σₗ εₗ Πⱼ₌ₗ₊₁ᴸ Lⱼ for layers with Lipschitz constants Lₗ and local errors εₗ
    /// (Vocabuquantization, Theorem 12; Sparse Positive Coefficient Spaces, Theorem 16). For pure
    /// truncation in ℓ₁, εₗ = 2τₗ. Hard support switches and softmax attention do not give Lₗ ≤ 1 for free.
    /// </summary>
    public static double LayerwiseError(IReadOnlyList<double> localErrors, IReadOnlyList<double> lipschitz)
    {
        if (localErrors.Count != lipschitz.Count) throw new ArgumentException("One error and one Lipschitz constant per layer are required.");
        return localErrors.Zip(lipschitz).Aggregate(0.0, (e, layer) => layer.Second * e + layer.First);
    }

    /// <summary>E_T ≤ ε Σₜ₌₀ᵀ⁻¹ λᵗ for a recurrent update with Lipschitz constant λ (Vocabuquantization, Corollary 12.1).</summary>
    public static double RecurrentError(double stepError, double lipschitz, int steps) =>
        lipschitz == 1 ? steps * stepError : stepError * (1 - Math.Pow(lipschitz, steps)) / (1 - lipschitz);

    /// <summary>
    /// Read stability under numerator and denominator perturbations with |δz| &lt; z and ‖n/z‖ ≤ V:
    /// (‖δn‖ + V|δz|) / (z − |δz|) (Memory and AI Harness, Theorem 17).
    /// </summary>
    public static double ReadDriftBound(double numeratorError, double denominatorError, double denominator, double valueNorm) =>
        Math.Abs(denominatorError) < denominator
            ? (numeratorError + valueNorm * Math.Abs(denominatorError)) / (denominator - Math.Abs(denominatorError))
            : double.PositiveInfinity;

    /// <summary>TV between softmax distributions whose logits differ by at most ε in maximum norm: tanh(ε/2) (Vocabuquantization, Theorem 13).</summary>
    public static double NextTokenTotalVariation(double logitError) => Math.Tanh(RequireNonnegative(logitError) / 2);

    /// <summary>
    /// True when the largest logit exceeds the second largest by more than 2ε, which guarantees the
    /// same greedy token (Theorem 13). It says nothing about sampled text, later states or correctness.
    /// </summary>
    public static bool GreedyTokenIsPreserved(IEnumerable<double> logits, double logitError)
    {
        var top = logits.OrderByDescending(v => v).Take(2).ToArray();
        return top.Length < 2 || top[0] - top[1] > 2 * logitError;
    }

    /// <summary>
    /// Sufficient argmax certificate from a coefficient error bound e and an ℓ₁→ℓ∞ logit Lipschitz
    /// constant K: the reference margin must exceed 2Ke (Sparse Positive Coefficient Spaces, Section 9.2).
    /// </summary>
    public static bool GreedyTokenIsPreserved(IEnumerable<double> referenceLogits, double coefficientError, double logitLipschitz) =>
        GreedyTokenIsPreserved(referenceLogits, logitLipschitz * coefficientError);

    private static double RequireNonnegative(double v) => v >= 0 ? v : throw new ArgumentOutOfRangeException(nameof(v), "A nonnegative bound is required.");
}

/// <summary>
/// Continuous support allocations for a validated error surrogate. They are conditional on that
/// surrogate: no inverse-power error law is established for language models. Real supports are
/// integers and need feasible rounding and rechecking.
/// </summary>
public static class SupportAllocation
{
    /// <summary>
    /// Minimises Σ aₗ/√sₗ subject to Σ cₗsₗ = B: sₗ ∝ (aₗ/cₗ)^(2/3) (Vocabuquantization, Theorem 15).
    /// </summary>
    public static Vector InverseSquareRoot(IReadOnlyList<double> sensitivity, IReadOnlyList<double> cost, double budget)
    {
        RequirePositive(sensitivity, cost);
        var shape = sensitivity.Zip(cost, (a, c) => Math.Pow(a / c, 2.0 / 3)).ToArray();
        double scale = budget / shape.Zip(cost, (s, c) => s * c).Sum();
        return Vec.Create(shape.Length, l => scale * shape[l]);
    }

    /// <summary>
    /// Minimises cost Σ cₖsₖ subject to Σ wₖsₖ^(−ν) ≤ ε: sₖ ∝ (wₖ/cₖ)^(1/(ν+1)) with the constraint
    /// active (Resolution Adaptive MAML, Theorem 12, with wₖbₖ supplied as one weight).
    /// </summary>
    public static Vector InversePower(IReadOnlyList<double> weight, IReadOnlyList<double> cost, double exponent, double errorBudget)
    {
        RequirePositive(weight, cost);
        if (!(exponent > 0) || !(errorBudget > 0)) throw new ArgumentException("The exponent and the error budget must be positive.");
        var shape = weight.Zip(cost, (w, c) => Math.Pow(w / c, 1 / (exponent + 1))).ToArray();
        double scale = Math.Pow(weight.Zip(shape, (w, t) => w * Math.Pow(t, -exponent)).Sum() / errorBudget, 1 / exponent);
        return Vec.Create(shape.Length, k => scale * shape[k]);
    }

    private static void RequirePositive(IReadOnlyList<double> a, IReadOnlyList<double> c)
    {
        if (a.Count != c.Count || a.Count == 0) throw new ArgumentException("One sensitivity and one cost per layer are required.");
        if (a.Any(v => !(v > 0)) || c.Any(v => !(v > 0))) throw new ArgumentException("Sensitivities and costs must be positive.");
    }
}
