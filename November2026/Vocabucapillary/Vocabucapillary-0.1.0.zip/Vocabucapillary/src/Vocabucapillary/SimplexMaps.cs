namespace Vocabucapillary;

/// <summary>
/// Maps from signed scores to sparse positive codes, and their exact reverse rules on a stable support.
/// Weights may be signed; positivity is enforced at the state boundary. At support-changing
/// boundaries the hard-capped maps are nonsmooth, and with a support of one they have zero derivative.
/// </summary>
public static class SimplexMaps
{
    /// <summary>Euclidean projection of z onto the simplex: pᵢ = max(zᵢ − θ, 0) with θ chosen so the sum is one.</summary>
    public static SparseCode Sparsemax(IReadOnlyList<double> scores) =>
        Sparsemax(scores.Count, scores.Select((z, i) => (i, z)));

    /// <summary>Sparsemax over a declared candidate set; addresses outside it receive zero.</summary>
    public static SparseCode Sparsemax(int width, IEnumerable<(int Index, double Score)> candidates)
    {
        var sorted = candidates.OrderByDescending(c => c.Score).ThenBy(c => c.Index).ToArray();
        if (sorted.Length == 0) throw new ArgumentException("At least one candidate is required.");
        double cumulative = 0, theta = 0;
        for (int k = 1; k <= sorted.Length; k++)
        {
            cumulative += sorted[k - 1].Score;
            if (1 + k * sorted[k - 1].Score > cumulative) theta = (cumulative - 1) / k; else break;
        }
        return SparseCode.Normalize(width, sorted.Select(c => (c.Index, Math.Max(c.Score - theta, 0))));
    }

    /// <summary>
    /// A minimiser of ½‖p − z‖² over simplex codes with at most s nonzeros: keep the s largest scores,
    /// project that subvector onto its simplex, set the rest to zero
    /// (Sparse Positive Coefficient Spaces, Theorem 7). The feasible set is nonconvex; ties are broken
    /// towards the smaller address.
    /// </summary>
    public static SparseCode CappedSparsemax(IReadOnlyList<double> scores, int support) =>
        CappedSparsemax(scores.Count, scores.Select((z, i) => (i, z)), support);

    public static SparseCode CappedSparsemax(int width, IEnumerable<(int Index, double Score)> candidates, int support) =>
        Sparsemax(width, Top(candidates, support));

    /// <summary>
    /// Maximiser of Σ πⱼzⱼ + τH(π) under a support quota k: softmax restricted to the k largest scores
    /// (Multimodal Explainability, Theorem 4).
    /// </summary>
    public static SparseCode TopSoftmax(IReadOnlyList<double> scores, int support, double temperature = 1) =>
        TopSoftmax(scores.Count, scores.Select((z, i) => (i, z)), support, temperature);

    public static SparseCode TopSoftmax(int width, IEnumerable<(int Index, double Score)> candidates, int support, double temperature = 1)
    {
        if (!(temperature > 0)) throw new ArgumentOutOfRangeException(nameof(temperature), "Temperature must be positive.");
        var top = Top(candidates, support);
        double max = top.Max(c => c.Score);
        return SparseCode.Normalize(width, top.Select(c => (c.Index, Math.Exp((c.Score - max) / temperature))));
    }

    /// <summary>
    /// Reverse rule of restricted softmax on its fixed support A: z̄ⱼ = (cⱼ/τ)(uⱼ − Σₖ cₖuₖ)
    /// (Sparse Backpropagation, Theorem 3). Input and output are aligned with <c>code.Indices</c>. O(s).
    /// </summary>
    public static Vector SoftmaxPullback(SparseCode code, Vector upstreamOnSupport, double temperature = 1)
    {
        RequireAligned(code, upstreamOnSupport);
        double mean = Vec.Dot(code.Values, upstreamOnSupport);
        return Vec.Create(code.Support, k => code.Values[k] / temperature * (upstreamOnSupport[k] - mean));
    }

    /// <summary>
    /// Reverse rule of sparsemax, and of the capped projection, on a stable positive support A:
    /// z̄ⱼ = uⱼ − |A|⁻¹Σₖ uₖ, i.e. the Jacobian I − 11ᵀ/|A|
    /// (Sparse Backpropagation, Theorem 3; Sparse Positive Coefficient Spaces, Lemma 8).
    /// For |A| = 1 the result is zero: singleton routing blocks score learning.
    /// </summary>
    public static Vector SparsemaxPullback(SparseCode code, Vector upstreamOnSupport)
    {
        RequireAligned(code, upstreamOnSupport);
        double mean = Vec.Sum(upstreamOnSupport) / code.Support;
        return Vec.Create(code.Support, k => upstreamOnSupport[k] - mean);
    }

    /// <summary>
    /// Sufficient certificate that a candidate set contains a global top-s set: it has at least s
    /// members and no omitted score can exceed its s-th largest (Section 5.2).
    /// </summary>
    public static bool CandidateSetIsExact(IEnumerable<double> candidateScores, int support, double omittedScoreUpperBound)
    {
        var top = candidateScores.OrderByDescending(z => z).Take(support).ToArray();
        return top.Length == support && omittedScoreUpperBound <= top[^1];
    }

    private static (int Index, double Score)[] Top(IEnumerable<(int Index, double Score)> candidates, int support)
    {
        if (support < 1) throw new ArgumentOutOfRangeException(nameof(support), "The support cap must be at least 1.");
        var top = candidates.OrderByDescending(c => c.Score).ThenBy(c => c.Index).Take(support).ToArray();
        return top.Length > 0 ? top : throw new ArgumentException("At least one candidate is required.");
    }

    private static void RequireAligned(SparseCode code, Vector v)
    {
        if (v.Length != code.Support) throw new ArgumentException("The upstream vector must be aligned with the code's support.");
    }
}
