namespace Vocabucapillary;

/// <summary>
/// A positive Vocabucapillary code: a point of the vocabulary simplex stored on its support
/// (Cacheless Transformer, Definition 1; Memory and AI Harness, Definition 1).
/// Invariants, enforced at construction: indices strictly increasing inside [0, Width),
/// every stored value strictly positive, values summing to one.
/// The code is a representation, not a calibrated predictive distribution.
/// </summary>
public sealed record SparseCode
{
    /// <summary>Largest deviation from unit mass accepted by <see cref="Create"/> before it rejects the input.</summary>
    public const double MassTolerance = 1e-9;

    public int Width { get; }
    public ImmutableArray<int> Indices { get; }
    public Vector Values { get; }

    private SparseCode(int width, ImmutableArray<int> indices, Vector values) =>
        (Width, Indices, Values) = (width, indices, values);

    /// <summary>Number of occupied addresses, |supp(c)|.</summary>
    public int Support => Indices.Length;

    /// <summary>Coefficient at an address; zero off the support.</summary>
    public double this[int address]
    {
        get
        {
            int k = Indices.BinarySearch(address);
            return k >= 0 ? Values[k] : 0;
        }
    }

    public IEnumerable<(int Index, double Value)> Entries => Indices.Zip(Values, (i, v) => (i, v));

    /// <summary>
    /// Builds a code from entries that already have unit mass (within <see cref="MassTolerance"/>).
    /// Duplicate addresses are summed and zeros dropped. The declared repair rule is a single exact
    /// renormalisation of the accepted input; anything further from unit mass is rejected.
    /// </summary>
    public static SparseCode Create(int width, IEnumerable<(int Index, double Value)> entries)
    {
        var (idx, val, total) = Collect(width, entries);
        if (Math.Abs(total - 1) > MassTolerance)
            throw new ArgumentException($"A code must have unit mass; received {total:R}. Use Normalize for unnormalised weights.");
        return new SparseCode(width, idx, Rescale(val, total));
    }

    /// <summary>Builds a code from nonnegative weights of positive total by dividing by that total.</summary>
    public static SparseCode Normalize(int width, IEnumerable<(int Index, double Value)> weights)
    {
        var (idx, val, total) = Collect(width, weights);
        if (!(total > 0) || double.IsInfinity(total))
            throw new ArgumentException("Weights must have a positive finite total. A zero state needs an explicit fallback such as a null atom.");
        return new SparseCode(width, idx, Rescale(val, total));
    }

    public static SparseCode OneHot(int width, int address) => Create(width, new[] { (address, 1.0) });

    public static SparseCode FromDense(IReadOnlyList<double> p) =>
        Create(p.Count, p.Select((v, i) => (i, v)));

    public static SparseCode Uniform(int width, IEnumerable<int> support)
    {
        var s = support.Distinct().ToArray();
        return Normalize(width, s.Select(i => (i, 1.0)));
    }

    public Vector ToDense()
    {
        var a = new double[Width];
        for (int k = 0; k < Indices.Length; k++) a[Indices[k]] = Values[k];
        return Vec.Seal(a);
    }

    /// <summary>
    /// Shannon entropy in nats. This is representational entropy: it changes under duplicate
    /// refinement without any change in behaviour and is not the model's uncertainty.
    /// </summary>
    public double Entropy() => -Values.Sum(v => v * Math.Log(v));

    public bool Equals(SparseCode? other) =>
        other is not null && Width == other.Width
        && Indices.AsSpan().SequenceEqual(other.Indices.AsSpan())
        && Values.AsSpan().SequenceEqual(other.Values.AsSpan());

    public override int GetHashCode()
    {
        var h = new HashCode();
        h.Add(Width);
        foreach (var i in Indices) h.Add(i);
        foreach (var v in Values) h.Add(v);
        return h.ToHashCode();
    }

    public override string ToString() =>
        $"SparseCode(N={Width}, s={Support}: {string.Join(", ", Entries.Take(8).Select(e => $"{e.Index}:{e.Value:G4}"))}{(Support > 8 ? ", …" : "")})";

    private static (ImmutableArray<int>, double[], double) Collect(int width, IEnumerable<(int Index, double Value)> entries)
    {
        if (width <= 0) throw new ArgumentOutOfRangeException(nameof(width), "Width must be positive.");
        var acc = new SortedDictionary<int, double>();
        foreach (var (i, v) in entries)
        {
            if (i < 0 || i >= width) throw new ArgumentOutOfRangeException(nameof(entries), $"Address {i} is outside [0, {width}).");
            if (double.IsNaN(v) || v < 0) throw new ArgumentException($"Coefficient {v} at address {i} is not a nonnegative number.");
            if (v == 0) continue;
            acc[i] = acc.GetValueOrDefault(i) + v;
        }
        var val = acc.Values.ToArray();
        double total = 0;
        foreach (var v in val) total += v;
        return (acc.Keys.ToImmutableArray(), val, total);
    }

    private static Vector Rescale(double[] values, double total)
    {
        for (int k = 0; k < values.Length; k++) values[k] /= total;
        return Vec.Seal(values);
    }
}

/// <summary>Pure operations on codes.</summary>
public static class Codes
{
    /// <summary>
    /// Convex mixture Σ wᵢ cᵢ / Σ wᵢ. The result stays in the simplex and its support is exactly the
    /// union of the supports with positive weight, because positive terms cannot cancel
    /// (Sparse Positive Coefficient Spaces, Proposition 5).
    /// </summary>
    public static SparseCode Mix(IEnumerable<(double Weight, SparseCode Code)> terms)
    {
        var list = terms.Where(t => t.Weight != 0).ToArray();
        if (list.Length == 0) throw new ArgumentException("A mixture needs at least one positive weight.");
        if (list.Any(t => t.Weight < 0 || double.IsNaN(t.Weight))) throw new ArgumentException("Mixture weights must be nonnegative.");
        int width = list[0].Code.Width;
        if (list.Any(t => t.Code.Width != width)) throw new ArgumentException("Codes in a mixture must share one dictionary width.");
        return SparseCode.Normalize(width, list.SelectMany(t => t.Code.Entries.Select(e => (e.Index, t.Weight * e.Value))));
    }

    public static double L1Distance(SparseCode a, SparseCode b)
    {
        if (a.Width != b.Width) throw new ArgumentException("Codes must share one dictionary width.");
        double s = 0;
        int i = 0, j = 0;
        while (i < a.Support || j < b.Support)
        {
            int ia = i < a.Support ? a.Indices[i] : int.MaxValue, ib = j < b.Support ? b.Indices[j] : int.MaxValue;
            if (ia == ib) { s += Math.Abs(a.Values[i] - b.Values[j]); i++; j++; }
            else if (ia < ib) { s += a.Values[i]; i++; }
            else { s += b.Values[j]; j++; }
        }
        return Math.Min(s, 2); // two unit-mass codes are at most 2 apart; the cap removes rounding excess
    }

    /// <summary>Total variation, TV(a, b) = ‖a − b‖₁ / 2.</summary>
    public static double TotalVariation(SparseCode a, SparseCode b) => L1Distance(a, b) / 2;

    /// <summary>Σⱼ cⱼ f(j): the expectation of an address function under the code.</summary>
    public static double Expect(SparseCode c, Func<int, double> f) => c.Entries.Sum(e => e.Value * f(e.Index));

    /// <summary>Zero-padding into a wider coordinate namespace; addresses keep their numbers.</summary>
    public static SparseCode Embed(SparseCode c, int newWidth) =>
        newWidth >= c.Width ? SparseCode.Create(newWidth, c.Entries)
                            : throw new ArgumentException("The new width must not be smaller than the old one.");
}

/// <summary>
/// A dictionary of vocabulary-associated atoms: column j is the decoded atom of address j.
/// The version string travels with every state that depends on the dictionary.
/// </summary>
public sealed record AtomDictionary(Matrix Atoms, string Version = "v0")
{
    public int Dimension => Atoms.Rows;
    public int Width => Atoms.Cols;

    public Vector Atom(int address) => Atoms.Column(address);

    /// <summary>h = D c in O(d·s) arithmetic.</summary>
    public Vector Decode(SparseCode c)
    {
        RequireWidth(c);
        var h = new double[Dimension];
        foreach (var (j, v) in c.Entries)
            for (int i = 0; i < h.Length; i++) h[i] += v * Atoms[i, j];
        return Vec.Seal(h);
    }

    /// <summary>Decoding with a separate amplitude, h = m·D c, which extends the hull to a cone.</summary>
    public Vector Decode(SparseCode c, double amplitude) =>
        amplitude >= 0 ? Vec.Scale(Decode(c), amplitude) : throw new ArgumentException("Amplitude must be nonnegative.");

    /// <summary>Diameter maxᵢⱼ‖dᵢ − dⱼ‖ of all atoms. O(N²d): compute once and reuse.</summary>
    public double Diameter() => DiameterOn(Enumerable.Range(0, Width));

    /// <summary>Diameter of a subset of atoms, which gives a tighter certificate for a code supported there.</summary>
    public double DiameterOn(IEnumerable<int> addresses)
    {
        var cols = addresses.Distinct().Select(Atom).ToArray();
        double best = 0;
        for (int a = 0; a < cols.Length; a++)
            for (int b = a + 1; b < cols.Length; b++) best = Math.Max(best, Vec.Distance(cols[a], cols[b]));
        return best;
    }

    /// <summary>
    /// The dictionary E = W·D. With the identity transport it carries every code unchanged through the
    /// linear map W: E c = W (D c) (Sparse Positive Coefficient Spaces, Theorem 3, special case).
    /// </summary>
    public AtomDictionary Mapped(Matrix w, string version) => new(w.Multiply(Atoms), version);

    internal void RequireWidth(SparseCode c)
    {
        if (c.Width != Width) throw new ArgumentException($"Code width {c.Width} does not match dictionary width {Width}.");
    }
}

/// <summary>
/// A resolution (Resolution Adaptive MAML, Definition 1): available atoms, current-code support cap,
/// coefficient precision J and persistent-memory row cap. Support restricts the code to a union of
/// simplex faces; it does not reduce the ambient width.
/// </summary>
public sealed record Resolution(int Atoms, int Support, int Precision, int MemoryRows)
{
    /// <summary>Leading bits of an index-and-count record: s(⌈log₂N⌉ + b) with J = 2ᵇ − 1 (Cacheless Transformer, Eq. 3).</summary>
    public int RecordBits => Support * (IndexBits + CountBits);
    public int IndexBits => (int)Math.Ceiling(Math.Log2(Atoms));
    public int CountBits => (int)Math.Ceiling(Math.Log2(Precision + 1.0));

    /// <summary>True when the sparse record is smaller than a dense key–value record of (dₖ + dᵥ)·b bits.</summary>
    public bool BeatsDenseRecord(int keyDim, int valueDim, int bitsPerScalar) =>
        RecordBits < (long)(keyDim + valueDim) * bitsPerScalar;
}
