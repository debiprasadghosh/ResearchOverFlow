using System.Text;

namespace Vocabucapillary;

/// <summary>
/// A deterministic resolution schedule (Vocabucapillary Text Diffusion, Definition 2).
/// Step[i][r] is the generation step, in 1..Steps, at which position i makes its (r+1)-th refinement,
/// from level K − r to level K − r − 1. Each position's steps are nondecreasing.
/// </summary>
public sealed class ResolutionSchedule
{
    public ImmutableArray<ImmutableArray<int>> Step { get; }
    public int Steps { get; }
    public int Length => Step.Length;
    public int Depth => Step[0].Length;

    private ResolutionSchedule(ImmutableArray<ImmutableArray<int>> step, int steps) => (Step, Steps) = (step, steps);

    public static ResolutionSchedule Create(IEnumerable<IEnumerable<int>> step)
    {
        var s = step.Select(p => p.ToImmutableArray()).ToImmutableArray();
        if (s.IsEmpty || s[0].IsEmpty) throw new ArgumentException("A schedule needs at least one position and one refinement.");
        if (s.Any(p => p.Length != s[0].Length)) throw new ArgumentException("Every position needs one step per hierarchy level.");
        if (s.Any(p => p[0] < 1 || p.Zip(p.Skip(1), (a, b) => a > b).Any(x => x)))
            throw new ArgumentException("Refinement steps must start at 1 and be nondecreasing for each position.");
        return new ResolutionSchedule(s, s.Max(p => p[^1]));
    }

    /// <summary>Every position moves one level per step; Steps = Depth.</summary>
    public static ResolutionSchedule LevelSynchronous(int length, int depth) =>
        Create(Enumerable.Range(0, length).Select(_ => Enumerable.Range(1, depth)));

    /// <summary>A masked schedule: position i goes from root to token in one step. This is fixed-order masked diffusion (Proposition 2).</summary>
    public static ResolutionSchedule Masked(IEnumerable<int> revealStep, int depth) =>
        Create(revealStep.Select(t => Enumerable.Repeat(t, depth)));

    public bool IsMasked => Step.All(p => p.All(t => t == p[0]));

    /// <summary>The level of every position after generation step t; t = 0 is the all-root state.</summary>
    public ImmutableArray<int> Levels(int t) => Step.Select(p => Depth - p.Count(s => s <= t)).ToImmutableArray();

    public override string ToString() => string.Join(" ", Step.Select(p => "(" + string.Join(",", p) + ")"));
}

/// <summary>An exact probability law over token sequences of one length, stored on its support.</summary>
public sealed class SequenceLaw
{
    public ImmutableArray<(ImmutableArray<int> Tokens, double Probability)> Atoms { get; }
    public int Length => Atoms[0].Tokens.Length;

    private SequenceLaw(ImmutableArray<(ImmutableArray<int>, double)> atoms) => Atoms = atoms;

    /// <summary>Builds a law from nonnegative weights on distinct sequences and normalises it.</summary>
    public static SequenceLaw Create(IEnumerable<(IReadOnlyList<int> Tokens, double Weight)> weights)
    {
        var kept = weights.Where(w => w.Weight > 0).Select(w => (w.Tokens.ToImmutableArray(), w.Weight)).ToImmutableArray();
        if (kept.IsEmpty) throw new ArgumentException("A law needs positive total weight.");
        if (kept.Any(k => k.Item1.Length != kept[0].Item1.Length)) throw new ArgumentException("All sequences must have one length.");
        double total = kept.Sum(k => k.Weight);
        return new SequenceLaw(kept.Select(k => (k.Item1, k.Weight / total)).ToImmutableArray());
    }

    /// <summary>Enumerates all width^length sequences. Intended for small exact studies.</summary>
    public static SequenceLaw FromWeights(int width, int length, Func<ImmutableArray<int>, double> weight)
    {
        double count = Math.Pow(width, length);
        if (count > 1 << 22) throw new ArgumentException("Exact enumeration is limited to about four million sequences.");
        return Create(Enumerable.Range(0, (int)count).Select(x =>
        {
            var tokens = Enumerable.Range(0, length).Select(i => x / (int)Math.Pow(width, length - 1 - i) % width).ToImmutableArray();
            return ((IReadOnlyList<int>)tokens, weight(tokens));
        }));
    }
}

/// <summary>
/// Exact quantities of resolution diffusion for a known sequence law (Vocabucapillary Text Diffusion).
/// All entropies are in nats. Reverse models are the Bayes-optimal conditional marginals, so the gap
/// is the irreducible error of parallel decoding, not a learning error.
/// </summary>
public static class ResolutionDiffusion
{
    /// <summary>Entropy of the view in which position i shows its group label at level <c>levels[i]</c>.</summary>
    public static double ViewEntropy(SequenceLaw law, VocabularyHierarchy hierarchy, IReadOnlyList<int> levels)
    {
        if (levels.Count != law.Length) throw new ArgumentException("One level per position is required.");
        var mass = new Dictionary<string, double>();
        var key = new StringBuilder();
        foreach (var (tokens, p) in law.Atoms)
        {
            key.Clear();
            for (int i = 0; i < tokens.Length; i++) key.Append(hierarchy.GroupOf[levels[i]][tokens[i]]).Append(',');
            string k = key.ToString();
            mass[k] = mass.GetValueOrDefault(k) + p;
        }
        return -mass.Values.Sum(v => v * Math.Log(v));
    }

    /// <summary>
    /// The factorisation gap Γ(σ) = Σₜ [Σ_{i∈Uₜ} H(Sₜ,ᵢ | Sₜ₋₁) − H(Sₜ | Sₜ₋₁)]: the minimum of
    /// KL(p ‖ q) over reverse models that refine positions independently within a step (Theorem 1).
    /// Zero when every step refines conditionally independent cells.
    /// </summary>
    public static double FactorisationGap(SequenceLaw law, VocabularyHierarchy hierarchy, ResolutionSchedule schedule)
    {
        if (schedule.Length != law.Length || schedule.Depth != hierarchy.Depth)
            throw new ArgumentException("The schedule must match the sequence length and the hierarchy depth.");
        return Enumerable.Range(1, schedule.Steps).Sum(t =>
        {
            var previous = schedule.Levels(t - 1);
            var current = schedule.Levels(t);
            double basis = ViewEntropy(law, hierarchy, previous);
            double joint = ViewEntropy(law, hierarchy, current) - basis;
            double marginals = Enumerable.Range(0, law.Length).Where(i => current[i] < previous[i])
                .Sum(i => ViewEntropy(law, hierarchy, previous.SetItem(i, current[i])) - basis);
            return marginals - joint;
        });
    }

    /// <summary>TC(X) = Σᵢ H(Xᵢ) − H(X), the gap of deciding every token in one step.</summary>
    public static double TotalCorrelation(SequenceLaw law, VocabularyHierarchy hierarchy)
    {
        int root = hierarchy.Depth, n = law.Length;
        return Enumerable.Range(0, n).Sum(i => ViewEntropy(law, hierarchy, Enumerable.Range(0, n).Select(j => j == i ? 0 : root).ToArray()))
             - ViewEntropy(law, hierarchy, Enumerable.Repeat(0, n).ToArray());
    }

    /// <summary>
    /// Cross-resolution information CRI = Σₖ Σᵢ I(G₍ₖ₋₁,ᵢ₎ ; G₍ₖ,₋ᵢ₎ | G₍ₖ,ᵢ₎) (Definition 4).
    /// The level-synchronous gap equals TC(X) − CRI (Theorem 3); when CRI = 0, level-synchronous
    /// decoding is no better than one-shot decoding.
    /// </summary>
    public static double CrossResolutionInformation(SequenceLaw law, VocabularyHierarchy hierarchy)
    {
        int root = hierarchy.Depth, n = law.Length;
        double H(Func<int, int> level) => ViewEntropy(law, hierarchy, Enumerable.Range(0, n).Select(level).ToArray());
        return (from k in Enumerable.Range(1, root)
                from i in Enumerable.Range(0, n)
                let alone = H(j => j == i ? k - 1 : root) - H(j => j == i ? k : root)
                let withOthers = H(j => j == i ? k - 1 : k) - H(_ => k)
                select alone - withOthers).Sum();
    }

    /// <summary>
    /// Worst-case total variation added by storing the reverse distribution of one refined cell with
    /// at most <paramref name="children"/> entries at precision J and discarded mass η:
    /// min{1, η + children/(2J)} (Theorem 5). Sum over refined cells for a sequence-level bound.
    /// It scales with branching width, not vocabulary size.
    /// </summary>
    public static double CellSamplerBound(int children, int resolution, double discardedMass = 0) =>
        Vocabuquantizer.TotalVariationBound(discardedMass, children, resolution);
}
