namespace Vocabucapillary;

/// <summary>A memory occupancy written as a probability code p = m/M together with its total mass M.</summary>
public sealed record MassState(SparseCode Occupancy, double TotalMass);

/// <summary>
/// Categorical geometry on the active support (Probabilistic Vocabucapillary for Meta Learning).
/// Vectors named "on support" are aligned with <c>code.Indices</c>, so every rule costs O(s).
/// </summary>
public static class Categorical
{
    /// <summary>softmax(θ) as a code. Entries whose exponential underflows to zero leave the support.</summary>
    public static SparseCode Softmax(IReadOnlyList<double> logits, double temperature = 1)
    {
        if (!(temperature > 0)) throw new ArgumentOutOfRangeException(nameof(temperature));
        double max = logits.Max();
        return SparseCode.Normalize(logits.Count, logits.Select((z, j) => (j, Math.Exp((z - max) / temperature))));
    }

    /// <summary>The occupancy p = m/M and total mass M of a coefficient memory. M is needed for future writes.</summary>
    public static MassState Occupancy(CoefficientMemory memory) =>
        new(SparseCode.Normalize(memory.Width, memory.Rows.Select(kv => (kv.Key, kv.Value.Mass))), memory.TotalMass);

    /// <summary>
    /// The write m′ = γm + w·c in probability form: M′ = γM + w and p′ a mixture of p and c with
    /// weights γM/M′ and w/M′ (Lemma 1). Two memories with equal p and different M react differently.
    /// </summary>
    public static MassState Update(MassState state, SparseCode code, double gamma, double weight)
    {
        if (gamma < 0 || weight < 0) throw new ArgumentException("The forgetting scalar and the write weight must be nonnegative.");
        double total = gamma * state.TotalMass + weight;
        if (!(total > 0)) throw new ArgumentException("The updated mass must be positive.");
        return new MassState(Codes.Mix(new[] { (gamma * state.TotalMass, state.Occupancy), (weight, code) }), total);
    }

    /// <summary>F_z x = p⊙x − p(pᵀx) for the logit Fisher F_z = diag(p) − ppᵀ (Proposition 8). F_z·1 = 0.</summary>
    public static Vector FisherProduct(SparseCode p, Vector onSupport)
    {
        RequireAligned(p, onSupport);
        double mean = Vec.Dot(p.Values, onSupport);
        return Vec.Create(p.Support, k => p.Values[k] * (onSupport[k] - mean));
    }

    /// <summary>
    /// The zero-sum solution of F_z x = g for 1ᵀg = 0: xⱼ = gⱼ/pⱼ + c (Proposition 8). Very small
    /// probabilities make the solve ill-conditioned; damping would change it and must be declared.
    /// </summary>
    public static Vector FisherSolve(SparseCode p, Vector onSupport, double tolerance = 1e-9)
    {
        RequireAligned(p, onSupport);
        if (Math.Abs(Vec.Sum(onSupport)) > tolerance * Math.Max(1, Vec.Norm1(onSupport)))
            throw new ArgumentException("F_z x = g is solvable only when the entries of g sum to zero.");
        var raw = Vec.Create(p.Support, k => onSupport[k] / p.Values[k]);
        double shift = Vec.Sum(raw) / p.Support;
        return Vec.Create(p.Support, k => raw[k] - shift);
    }

    /// <summary>
    /// The natural-gradient direction p⊙(g − E_p g) for a coefficient loss with Euclidean gradient g.
    /// It conserves mass infinitesimally; a finite step still needs a positivity rule.
    /// </summary>
    public static Vector NaturalGradient(SparseCode p, Vector gradientOnSupport) => FisherProduct(p, gradientOnSupport);

    /// <summary>
    /// One entropic mirror step, the minimiser of α·aᵀp + KL(p ‖ pₖ): pⱼ ∝ pₖⱼ exp(−α·aⱼ).
    /// A zero probability stays zero, so support expansion needs positive seeding.
    /// </summary>
    public static SparseCode EntropicStep(SparseCode p, Func<int, double> cost, double stepSize)
    {
        var exponent = p.Indices.Select(j => -stepSize * cost(j)).ToArray();
        double max = exponent.Max();
        return SparseCode.Normalize(p.Width, p.Indices.Select((j, k) => (j, p.Values[k] * Math.Exp(exponent[k] - max))));
    }

    /// <summary>
    /// The collapsed result of K entropic steps with costs fixed in advance: p_K = softmax(θ − Σαₖaₖ)
    /// (Theorem 9). The identity fails when a cost depends on earlier iterates.
    /// </summary>
    public static SparseCode EntropicCollapse(Vector logits, IEnumerable<(double StepSize, Vector Cost)> steps) =>
        Softmax(steps.Aggregate(logits, (theta, s) => Vec.AddScaled(theta, -s.StepSize, s.Cost)));

    /// <summary>Meta-gradient ∇θ Q = F_z(p_K)·∇p Q of a query loss through the collapsed adaptation (Theorem 9, Eq. 15).</summary>
    public static Vector CollapsedMetaGradient(SparseCode adapted, Vector queryGradientOnSupport) =>
        FisherProduct(adapted, queryGradientOnSupport);

    /// <summary>
    /// Unbiased estimate of T = Σⱼ pⱼψⱼ that enumerates a head exactly and samples the tail from
    /// q = p/ε, ε the tail mass (Theorem 13, Corollary 13.1). Its mean squared error is at most
    /// ε²B²/m when ‖ψⱼ‖ ≤ B on the tail; dropping the tail instead errs by at most εB.
    /// Deterministic for a given seed.
    /// </summary>
    public static Vector HeadTailEstimate(SparseCode p, Func<int, Vector> contribution, IEnumerable<int> head, int draws, int seed)
    {
        if (draws < 1) throw new ArgumentOutOfRangeException(nameof(draws));
        var inHead = head.ToHashSet();
        var headEntries = p.Entries.Where(e => inHead.Contains(e.Index)).ToArray();
        var tail = p.Entries.Where(e => !inHead.Contains(e.Index)).ToArray();
        if (headEntries.Length + tail.Length == 0) throw new ArgumentException("The code is empty.");
        int dimension = contribution(p.Indices[0]).Length;
        var exact = headEntries.Aggregate(Vec.Zero(dimension), (acc, e) => Vec.AddScaled(acc, e.Value, contribution(e.Index)));
        if (tail.Length == 0) return exact;
        double epsilon = tail.Sum(e => e.Value);
        var rng = new Random(seed);
        var sampled = Enumerable.Range(0, draws).Aggregate(Vec.Zero(dimension), (acc, _) =>
        {
            double u = rng.NextDouble() * epsilon, cumulative = 0;
            int pick = tail[^1].Index;
            foreach (var e in tail) { cumulative += e.Value; if (u < cumulative) { pick = e.Index; break; } }
            return Vec.Add(acc, contribution(pick));
        });
        return Vec.AddScaled(exact, epsilon / draws, sampled);
    }

    private static void RequireAligned(SparseCode p, Vector v)
    {
        if (v.Length != p.Support) throw new ArgumentException("The vector must be aligned with the code's support.");
    }
}
