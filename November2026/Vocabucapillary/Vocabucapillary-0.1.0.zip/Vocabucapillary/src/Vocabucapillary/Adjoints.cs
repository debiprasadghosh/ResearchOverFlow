namespace Vocabucapillary;

/// <summary>Reverse derivatives of h = D_A c_A: one coefficient derivative and one atom derivative per active address.</summary>
public sealed record DecodingAdjoint(Vector Coefficients, ImmutableArray<Vector> Atoms);

/// <summary>Reverse derivatives of one aggregate read with respect to its independent inputs.</summary>
public sealed record ReadAdjoint(
    ImmutableSortedDictionary<int, double> Mass,
    ImmutableSortedDictionary<int, Vector> ValueSum,
    ImmutableSortedDictionary<int, Vector> KeyAtoms,
    Vector Query,
    double Temperature);

/// <summary>Reverse derivatives of one memory write; <c>Code</c> is aligned with the written code's support.</summary>
public sealed record WriteAdjoint(Vector Code, Vector Value, double Weight);

/// <summary>
/// Exact local reverse rules on the active face (Sparse Backpropagation and Progressive Capacity).
/// They are shortcuts for the executed operator with its support held fixed; they say nothing about
/// support changes, candidate search or parameters that are used elsewhere in a model.
/// </summary>
public static class SparseAdjoints
{
    /// <summary>
    /// ∇c_A L = D_Aᵀ g and ∇D_A L = g c_Aᵀ for g = ∇h L (Theorem 1). O(d·s) arithmetic, with no
    /// length-N gradient. The coefficient derivative is the ambient one: apply a simplex
    /// parameterisation such as <see cref="SimplexMaps.SoftmaxPullback"/> to obtain a feasible one.
    /// </summary>
    public static DecodingAdjoint Decoding(AtomDictionary dictionary, SparseCode code, Vector upstream)
    {
        dictionary.RequireWidth(code);
        return new DecodingAdjoint(
            Vec.Create(code.Support, k => dictionary.Atoms.ColumnDot(code.Indices[k], upstream)),
            code.Values.Select(v => Vec.Scale(upstream, v)).ToImmutableArray());
    }

    /// <summary>
    /// Sufficient condition for the selected top-s set to survive a score perturbation: the gap
    /// Δ = z₍ₛ₎ − z₍ₛ₊₁₎ exceeds twice the perturbation's maximum norm (Lemma 2).
    /// </summary>
    public static bool TopSupportIsStable(IEnumerable<double> scores, int support, double perturbationMaxNorm)
    {
        var z = scores.OrderByDescending(v => v).ToArray();
        if (support < 1) throw new ArgumentOutOfRangeException(nameof(support));
        return z.Length <= support || perturbationMaxNorm < (z[support - 1] - z[support]) / 2;
    }

    /// <summary>
    /// Adjoint of the read o = Sᵀφ(q)/mᵀφ(q) for upstream g = ō (Theorem 5):
    /// S̄ⱼ = (φⱼ/Z)g, m̄ⱼ = −(φⱼ/Z)gᵀo, and with bⱼ = πⱼ gᵀ(uⱼ − o): q̄ = τ⁻¹Σbⱼaⱼ, āⱼ = (bⱼ/τ)q,
    /// τ̄ = −τ⁻²Σbⱼqᵀaⱼ. Evaluated from response masses, so no raw exponential is formed.
    /// O(r(d_k + d_v)) for r occupied rows; the memory adjoints are dense over those rows.
    /// </summary>
    public static ReadAdjoint Read(CoefficientMemory memory, ResponseKernel kernel, Vector query, Vector upstream)
    {
        var read = memory.Read(kernel, query);
        var rows = memory.Rows;
        double go = Vec.Dot(upstream, read.Output);
        var phiOverZ = read.ResponseMass.ToImmutableSortedDictionary(kv => kv.Key, kv => kv.Value / rows[kv.Key].Mass);
        var b = read.ResponseMass.ToImmutableSortedDictionary(kv => kv.Key, kv => kv.Value * (Vec.Dot(upstream, read.Means[kv.Key]) - go));
        double tau = kernel.Temperature;
        return new ReadAdjoint(
            phiOverZ.ToImmutableSortedDictionary(kv => kv.Key, kv => -kv.Value * go),
            phiOverZ.ToImmutableSortedDictionary(kv => kv.Key, kv => Vec.Scale(upstream, kv.Value)),
            b.ToImmutableSortedDictionary(kv => kv.Key, kv => Vec.Scale(query, kv.Value / tau)),
            b.Aggregate(Vec.Zero(query.Length), (acc, kv) => Vec.AddScaled(acc, kv.Value / tau, kernel.KeyAtoms.Column(kv.Key))),
            -b.Sum(kv => kv.Value * kernel.Score(query, kv.Key)) / tau);
    }

    /// <summary>
    /// Adjoint of the write (m, S) ← (γm + w·c, γS + w·c vᵀ) given the total incoming adjoints p = m̄
    /// and R = S̄ of the updated state (Theorem 6): c̄ⱼ = w(pⱼ + Rⱼᵀv), v̄ = wΣcⱼRⱼ,
    /// w̄ = Σcⱼ(pⱼ + Rⱼᵀv). The previous-memory adjoints are γp and γR. O(s·d_v).
    /// </summary>
    public static WriteAdjoint Write(SparseCode code, Vector value, double weight, Func<int, double> massAdjoint, Func<int, Vector> valueSumAdjoint)
    {
        var r = code.Indices.Select(valueSumAdjoint).ToImmutableArray();
        var share = Vec.Create(code.Support, k => massAdjoint(code.Indices[k]) + Vec.Dot(r[k], value));
        return new WriteAdjoint(
            Vec.Scale(share, weight),
            Enumerable.Range(0, code.Support).Aggregate(Vec.Zero(value.Length), (acc, k) => Vec.AddScaled(acc, weight * code.Values[k], r[k])),
            Vec.Dot(code.Values, share));
    }
}
