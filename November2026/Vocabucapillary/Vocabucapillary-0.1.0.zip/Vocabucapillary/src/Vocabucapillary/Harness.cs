namespace Vocabucapillary;

/// <summary>
/// A typed coefficient record for a harness (Sparse Positive Coefficient Spaces, Section 11).
/// A record is unusable when its coordinate system is unknown, even if its numbers are well formed,
/// so the dictionary version, layer, modality, source ancestry and amplitude convention travel with it.
/// </summary>
public sealed record CodeRecord(
    SparseCode Code,
    string DictionaryVersion,
    int Layer,
    string Modality,
    ImmutableArray<string> Sources,
    double Amplitude = 1,
    int? Precision = null);

/// <summary>Runtime contracts for coefficient state. A check returns the violations; an empty result means the state is valid.</summary>
public static class StateContract
{
    /// <summary>
    /// State-validity and compatibility check of a record against the dictionary and resolution it
    /// claims to use. Unit mass, nonnegativity and address range are already enforced by <see cref="SparseCode"/>.
    /// </summary>
    public static ImmutableArray<string> Check(CodeRecord record, AtomDictionary dictionary, Resolution resolution)
    {
        var problems = ImmutableArray.CreateBuilder<string>();
        if (record.DictionaryVersion != dictionary.Version)
            problems.Add($"Dictionary version '{record.DictionaryVersion}' does not match '{dictionary.Version}': migrate, replay or start a new epoch.");
        if (record.Code.Width != dictionary.Width)
            problems.Add($"Code width {record.Code.Width} does not match dictionary width {dictionary.Width}.");
        if (dictionary.Width != resolution.Atoms)
            problems.Add($"Dictionary width {dictionary.Width} does not match the resolution's {resolution.Atoms} atoms.");
        if (record.Code.Support > resolution.Support)
            problems.Add($"Support {record.Code.Support} exceeds the cap {resolution.Support}.");
        if (!(record.Amplitude >= 0) || double.IsInfinity(record.Amplitude))
            problems.Add("Amplitude must be finite and nonnegative.");
        if (record.Precision is int j && j != resolution.Precision)
            problems.Add($"Record precision J = {j} differs from the resolution's J = {resolution.Precision}.");
        if (record.Sources.IsDefaultOrEmpty)
            problems.Add("No source ancestry: a vocabulary label alone cannot justify a citation.");
        return problems.ToImmutable();
    }

    /// <summary>
    /// Validates raw dense coefficients before they become a code: every entry finite and nonnegative
    /// and the mass within tolerance of one. Returns the violations instead of repairing silently.
    /// </summary>
    public static ImmutableArray<string> CheckRaw(IReadOnlyList<double> coefficients, double massTolerance = SparseCode.MassTolerance)
    {
        var problems = ImmutableArray.CreateBuilder<string>();
        if (coefficients.Any(v => double.IsNaN(v) || double.IsInfinity(v))) problems.Add("Non-finite coefficient.");
        if (coefficients.Any(v => v < 0)) problems.Add("Negative coefficient.");
        double mass = coefficients.Where(double.IsFinite).Sum();
        if (Math.Abs(mass - 1) > massTolerance) problems.Add($"Mass {mass:R} is not one.");
        return problems.ToImmutable();
    }
}
