global using System.Collections.Immutable;
global using Vector = System.Collections.Immutable.ImmutableArray<double>;

using System.Runtime.InteropServices;

namespace Vocabucapillary;

/// <summary>Pure functions on immutable dense vectors (<see cref="ImmutableArray{Double}"/>).</summary>
public static class Vec
{
    /// <summary>Wraps a freshly built local array without copying. The array must not escape its builder.</summary>
    internal static Vector Seal(double[] local) => ImmutableCollectionsMarshal.AsImmutableArray(local);

    public static Vector Of(params double[] values) => ImmutableArray.Create(values);

    public static Vector Zero(int n) => Seal(new double[n]);

    public static Vector Create(int n, Func<int, double> f)
    {
        var a = new double[n];
        for (int i = 0; i < n; i++) a[i] = f(i);
        return Seal(a);
    }

    internal static void RequireSameLength(Vector a, Vector b)
    {
        if (a.Length != b.Length) throw new ArgumentException($"Vector lengths differ: {a.Length} and {b.Length}.");
    }

    public static double Dot(Vector a, Vector b)
    {
        RequireSameLength(a, b);
        double s = 0;
        for (int i = 0; i < a.Length; i++) s += a[i] * b[i];
        return s;
    }

    /// <summary>a + w·b.</summary>
    public static Vector AddScaled(Vector a, double w, Vector b)
    {
        RequireSameLength(a, b);
        var r = new double[a.Length];
        for (int i = 0; i < r.Length; i++) r[i] = a[i] + w * b[i];
        return Seal(r);
    }

    public static Vector Add(Vector a, Vector b) => AddScaled(a, 1, b);
    public static Vector Subtract(Vector a, Vector b) => AddScaled(a, -1, b);
    public static Vector Scale(Vector a, double w) => Create(a.Length, i => w * a[i]);

    public static double Norm(Vector a) => Math.Sqrt(Dot(a, a));
    public static double Norm1(Vector a) { double s = 0; foreach (var x in a) s += Math.Abs(x); return s; }
    public static double NormInf(Vector a) { double s = 0; foreach (var x in a) s = Math.Max(s, Math.Abs(x)); return s; }
    public static double Sum(Vector a) { double s = 0; foreach (var x in a) s += x; return s; }
    public static double Distance(Vector a, Vector b) => Norm(Subtract(a, b));

    /// <summary>log Σ exp(xᵢ), evaluated stably.</summary>
    public static double LogSumExp(IEnumerable<double> x)
    {
        var a = x as IReadOnlyCollection<double> ?? x.ToArray();
        if (a.Count == 0) return double.NegativeInfinity;
        double max = a.Max();
        if (double.IsNegativeInfinity(max)) return max;
        return max + Math.Log(a.Sum(v => Math.Exp(v - max)));
    }
}

/// <summary>An immutable dense real matrix in row-major storage, with structural equality.</summary>
public sealed record Matrix
{
    private readonly Vector _data;

    public int Rows { get; }
    public int Cols { get; }

    private Matrix(int rows, int cols, Vector data) => (Rows, Cols, _data) = (rows, cols, data);

    public double this[int row, int col] => _data[row * Cols + col];

    public static Matrix Create(int rows, int cols, Func<int, int, double> f)
    {
        if (rows < 0 || cols < 0) throw new ArgumentOutOfRangeException(nameof(rows));
        var a = new double[rows * cols];
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++) a[i * cols + j] = f(i, j);
        return new Matrix(rows, cols, Vec.Seal(a));
    }

    public static Matrix Zero(int rows, int cols) => Create(rows, cols, (_, _) => 0);
    public static Matrix Identity(int n) => Create(n, n, (i, j) => i == j ? 1 : 0);

    public static Matrix FromRows(IReadOnlyList<IReadOnlyList<double>> rows)
    {
        int c = rows.Count == 0 ? 0 : rows[0].Count;
        if (rows.Any(r => r.Count != c)) throw new ArgumentException("Rows have unequal lengths.");
        return Create(rows.Count, c, (i, j) => rows[i][j]);
    }

    /// <summary>Builds a matrix whose columns are the given vectors, e.g. dictionary atoms.</summary>
    public static Matrix FromColumns(IReadOnlyList<Vector> columns)
    {
        int r = columns.Count == 0 ? 0 : columns[0].Length;
        if (columns.Any(col => col.Length != r)) throw new ArgumentException("Columns have unequal lengths.");
        return Create(r, columns.Count, (i, j) => columns[j][i]);
    }

    /// <summary>Entries i.i.d. uniform on [lo, hi) from a seeded generator; deterministic for a given seed.</summary>
    public static Matrix Random(int rows, int cols, int seed, double lo = -1, double hi = 1)
    {
        var rng = new Random(seed);
        var a = new double[rows * cols];
        for (int i = 0; i < a.Length; i++) a[i] = lo + (hi - lo) * rng.NextDouble();
        return new Matrix(rows, cols, Vec.Seal(a));
    }

    public Vector Row(int i) => Vec.Create(Cols, j => this[i, j]);
    public Vector Column(int j) => Vec.Create(Rows, i => this[i, j]);

    /// <summary>xᵀ(column j), without materialising the column.</summary>
    public double ColumnDot(int j, Vector x)
    {
        if (x.Length != Rows) throw new ArgumentException("Vector length must equal the row count.");
        double s = 0;
        for (int i = 0; i < Rows; i++) s += x[i] * this[i, j];
        return s;
    }

    /// <summary>A x.</summary>
    public Vector Multiply(Vector x)
    {
        if (x.Length != Cols) throw new ArgumentException("Vector length must equal the column count.");
        var r = new double[Rows];
        for (int i = 0; i < Rows; i++)
        {
            double s = 0;
            for (int j = 0; j < Cols; j++) s += this[i, j] * x[j];
            r[i] = s;
        }
        return Vec.Seal(r);
    }

    /// <summary>Aᵀ y.</summary>
    public Vector MultiplyTransposed(Vector y) => Vec.Create(Cols, j => ColumnDot(j, y));

    public Matrix Multiply(Matrix b)
    {
        if (Cols != b.Rows) throw new ArgumentException("Inner dimensions differ.");
        var a = new double[Rows * b.Cols];
        for (int i = 0; i < Rows; i++)
            for (int k = 0; k < Cols; k++)
            {
                double v = this[i, k];
                if (v == 0) continue;
                for (int j = 0; j < b.Cols; j++) a[i * b.Cols + j] += v * b[k, j];
            }
        return new Matrix(Rows, b.Cols, Vec.Seal(a));
    }

    public Matrix Transpose() => Create(Cols, Rows, (i, j) => this[j, i]);
    public Matrix Scale(double w) => Create(Rows, Cols, (i, j) => w * this[i, j]);
    public Matrix Add(Matrix b) => Create(Rows, Cols, (i, j) => this[i, j] + b[i, j]);

    public bool IsNonnegative => _data.All(v => v >= 0);
    public double MaxAbs => Vec.NormInf(_data);
    public double MaxAbsDifference(Matrix b) =>
        Rows == b.Rows && Cols == b.Cols ? Vec.NormInf(Vec.Subtract(_data, b._data)) : double.PositiveInfinity;

    public bool Equals(Matrix? other) =>
        other is not null && Rows == other.Rows && Cols == other.Cols && _data.AsSpan().SequenceEqual(other._data.AsSpan());

    public override int GetHashCode()
    {
        var h = new HashCode();
        h.Add(Rows); h.Add(Cols);
        foreach (var v in _data) h.Add(v);
        return h.ToHashCode();
    }
}
