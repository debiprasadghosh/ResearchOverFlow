namespace Vocabucapillary;

/// <summary>
/// The positive response family φⱼ(q) = exp(qᵀaⱼ/τ) over fixed key atoms aⱼ, and the coefficient
/// kernel κ(q, c) = Σⱼ cⱼφⱼ(q) (Cacheless Transformer, Eq. 4). This is a declared attention operator:
/// it differs from ordinary attention on the reconstructed key by a nonnegative Jensen gap.
/// </summary>
public sealed record ResponseKernel(Matrix KeyAtoms, double Temperature = 1)
{
    public int Width => KeyAtoms.Cols;

    /// <summary>log φⱼ(q) = qᵀaⱼ/τ.</summary>
    public double Score(Vector q, int address) => KeyAtoms.ColumnDot(address, q) / Temperature;

    /// <summary>log κ(q, c), evaluated stably.</summary>
    public double LogKernel(Vector q, SparseCode c) =>
        Vec.LogSumExp(c.Entries.Select(e => Math.Log(e.Value) + Score(q, e.Index)).ToArray());

    /// <summary>
    /// J(q) = log κ(q, c) − qᵀ(Ac)/τ, the gap between the coefficient response and ordinary attention
    /// on the reconstructed key. Satisfies 0 ≤ J ≤ R²/8 with R the range of active scores (Lemma 5).
    /// </summary>
    public double JensenGap(Vector q, SparseCode c) => LogKernel(q, c) - Codes.Expect(c, j => Score(q, j));

    /// <summary>The Hoeffding-type bound R²/8 on the Jensen gap.</summary>
    public double JensenGapBound(Vector q, SparseCode c)
    {
        var scores = c.Indices.Select(j => Score(q, j)).ToArray();
        double range = scores.Max() - scores.Min();
        return range * range / 8;
    }
}

/// <summary>One occupied memory row: accumulated mass mⱼ and value sum Sⱼ.</summary>
public sealed record MemoryRow(double Mass, Vector ValueSum)
{
    /// <summary>The contextual value mean uⱼ = Sⱼ / mⱼ.</summary>
    public Vector Mean => Vec.Scale(ValueSum, 1 / Mass);
}

/// <summary>
/// Result of a read: the output o(q), the response mass πⱼ(q) of every occupied row, the row value
/// means and the log of the denominator mᵀφ(q).
/// </summary>
public sealed record MemoryRead(
    Vector Output,
    ImmutableSortedDictionary<int, double> ResponseMass,
    ImmutableSortedDictionary<int, Vector> Means,
    double LogDenominator);

/// <summary>
/// Bounded coefficient memory: the sufficient statistics m = Σ wᵢcᵢ and S = Σ wᵢcᵢvᵢᵀ of the
/// coefficient kernel, with read o(q) = Sᵀφ(q) / mᵀφ(q) (Cacheless Transformer, Theorem 6).
/// State is N(1 + p) scalars per head, independent of prefix length; only occupied rows are stored.
/// It is exact for the declared kernel and for dictionary and value semantics held fixed.
/// Every operation returns a new memory.
/// </summary>
public sealed record CoefficientMemory
{
    private const double RescaleBelow = 1e-150;

    // True state = _scale × _rows, so that forgetting costs O(1).
    private readonly ImmutableSortedDictionary<int, MemoryRow> _rows;
    private readonly double _scale;

    public int Width { get; }
    public int ValueDimension { get; }

    private CoefficientMemory(int width, int valueDimension, ImmutableSortedDictionary<int, MemoryRow> rows, double scale) =>
        (Width, ValueDimension, _rows, _scale) = (width, valueDimension, rows, scale);

    public static CoefficientMemory Empty(int width, int valueDimension) =>
        new(width, valueDimension, ImmutableSortedDictionary<int, MemoryRow>.Empty, 1);

    public int OccupiedRows => _rows.Count;
    public bool IsEmpty => _rows.IsEmpty;
    public IEnumerable<int> Addresses => _rows.Keys;

    /// <summary>The occupied rows with their true masses and value sums.</summary>
    public ImmutableSortedDictionary<int, MemoryRow> Rows =>
        _scale == 1 ? _rows : _rows.ToImmutableSortedDictionary(kv => kv.Key, kv => Scaled(kv.Value, _scale));

    /// <summary>Total exposure mass Σⱼ mⱼ, equal to Σᵢ wᵢ when every written code has unit mass.</summary>
    public double TotalMass => _scale * _rows.Values.Sum(r => r.Mass);

    /// <summary>The write (m, S) ← (m + w·c, S + w·c vᵀ). Touches s rows.</summary>
    public CoefficientMemory Write(SparseCode code, Vector value, double weight = 1)
    {
        if (code.Width != Width) throw new ArgumentException($"Code width {code.Width} does not match memory width {Width}.");
        if (value.Length != ValueDimension) throw new ArgumentException("Value dimension does not match the memory.");
        if (!(weight >= 0) || double.IsInfinity(weight)) throw new ArgumentException("Exposure weight must be nonnegative and finite.");
        if (weight == 0) return this;
        var builder = _rows.ToBuilder();
        foreach (var (j, c) in code.Entries)
        {
            double w = weight * c / _scale;
            builder[j] = builder.TryGetValue(j, out var row)
                ? new MemoryRow(row.Mass + w, Vec.AddScaled(row.ValueSum, w, value))
                : new MemoryRow(w, Vec.Scale(value, w));
        }
        return new CoefficientMemory(Width, ValueDimension, builder.ToImmutable(), _scale);
    }

    /// <summary>Common forgetting (m, S) ← γ(m, S) with 0 ≤ γ ≤ 1. O(1) except for rare rescaling.</summary>
    public CoefficientMemory Decay(double gamma)
    {
        if (!(gamma >= 0 && gamma <= 1)) throw new ArgumentOutOfRangeException(nameof(gamma), "The forgetting scalar must lie in [0, 1].");
        if (gamma == 1 || IsEmpty) return this;
        if (gamma == 0) return Empty(Width, ValueDimension);
        double scale = _scale * gamma;
        return scale >= RescaleBelow
            ? new CoefficientMemory(Width, ValueDimension, _rows, scale)
            : new CoefficientMemory(Width, ValueDimension,
                _rows.Select(kv => KeyValuePair.Create(kv.Key, Scaled(kv.Value, scale))).Where(kv => kv.Value.Mass > 0).ToImmutableSortedDictionary(), 1);
    }

    /// <summary>
    /// Exponential recency: mₜ = λmₜ₋₁ + cₜ, Sₜ = λSₜ₋₁ + cₜvₜᵀ, which computes the read exactly for
    /// weights wᵢ = λ^(t−i) (Cacheless Transformer, Proposition 12).
    /// </summary>
    public CoefficientMemory Step(SparseCode code, Vector value, double gamma, double weight = 1) =>
        Decay(gamma).Write(code, value, weight);

    /// <summary>The read for the exponential response kernel.</summary>
    public MemoryRead Read(ResponseKernel kernel, Vector q)
    {
        if (kernel.Width != Width) throw new ArgumentException("Kernel width does not match the memory.");
        return Read(j => kernel.Score(q, j));
    }

    /// <summary>
    /// The read o = Σⱼ φⱼSⱼ / Σⱼ φⱼmⱼ for any positive response given by its logarithm. Evaluated in
    /// the log domain. An empty memory has no read: it needs an explicit initial state.
    /// </summary>
    public MemoryRead Read(Func<int, double> logResponse)
    {
        if (IsEmpty) throw new InvalidOperationException("An empty memory has no read; supply an explicit initial state or background row.");
        var logWeight = _rows.ToDictionary(kv => kv.Key, kv => Math.Log(kv.Value.Mass) + logResponse(kv.Key));
        double logZ = Vec.LogSumExp(logWeight.Values.ToArray());
        if (double.IsNegativeInfinity(logZ)) throw new InvalidOperationException("The read denominator is zero for this query.");
        var pi = logWeight.ToImmutableSortedDictionary(kv => kv.Key, kv => Math.Exp(kv.Value - logZ));
        var means = _rows.ToImmutableSortedDictionary(kv => kv.Key, kv => kv.Value.Mean);
        var output = new double[ValueDimension];
        foreach (var (j, p) in pi)
            for (int i = 0; i < output.Length; i++) output[i] += p * means[j][i];
        return new MemoryRead(Vec.Seal(output), pi, means, logZ + Math.Log(_scale));
    }

    /// <summary>
    /// Deletes both masses and value sums of a row group. Exposure mass is lost, not redistributed.
    /// The read changes by exactly π_G(o_G − o₋G) (Interpretability, Theorem 8).
    /// </summary>
    public CoefficientMemory Delete(IEnumerable<int> addresses) =>
        new(Width, ValueDimension, _rows.RemoveRange(addresses), _scale);

    public CoefficientMemory Keep(IEnumerable<int> addresses)
    {
        var keep = addresses.ToHashSet();
        return Delete(_rows.Keys.Where(j => !keep.Contains(j)).ToArray());
    }

    /// <summary>
    /// Coarsening C_P(m, S) = (Pm, PS) by a column-stochastic map; deterministic merging is the special
    /// case. Preserves total exposure and the sum of contextual values, and commutes with linear writes:
    /// coarsening after a write of c equals writing P c into the coarse state (Vocabuquantization,
    /// Theorem 20). It is an exact write identity, not an exact read identity.
    /// </summary>
    public CoefficientMemory Coarsen(Transport p)
    {
        if (p.InputWidth != Width) throw new ArgumentException("Transport input width does not match the memory.");
        var acc = new SortedDictionary<int, MemoryRow>();
        foreach (var (j, row) in _rows)
            foreach (var (k, share) in p.Columns[j].Entries)
                acc[k] = acc.TryGetValue(k, out var old)
                    ? new MemoryRow(old.Mass + share * row.Mass, Vec.AddScaled(old.ValueSum, share, row.ValueSum))
                    : Scaled(row, share);
        return new CoefficientMemory(p.OutputWidth, ValueDimension, acc.ToImmutableSortedDictionary(), _scale);
    }

    /// <summary>
    /// Function-preserving refinement: splits each row among child addresses with fractions summing
    /// to one. When the children carry the parent's key atom the read is unchanged
    /// (Sparse Backpropagation, Theorem 15). Expressed as a transport from old to new addresses.
    /// </summary>
    public CoefficientMemory Refine(Transport split) => Coarsen(split);

    private static MemoryRow Scaled(MemoryRow row, double w) => new(row.Mass * w, Vec.Scale(row.ValueSum, w));
}

/// <summary>
/// Association memory for the bilinear positive kernel w = aᵀHb between query, key and value codes:
/// C = Σ bⱼuⱼᵀ, with read r = CᵀHᵀa / nᵀHᵀa and n = C·1
/// (Sparse Positive Coefficient Spaces, Theorem 13). The read is itself a value code. Separate key and
/// value totals would not determine it, so the joint association is kept (Proposition 14).
/// </summary>
public sealed record AssociationMemory
{
    private readonly ImmutableSortedDictionary<int, ImmutableSortedDictionary<int, double>> _rows;

    public int KeyWidth { get; }
    public int ValueWidth { get; }

    private AssociationMemory(int keyWidth, int valueWidth, ImmutableSortedDictionary<int, ImmutableSortedDictionary<int, double>> rows) =>
        (KeyWidth, ValueWidth, _rows) = (keyWidth, valueWidth, rows);

    public static AssociationMemory Empty(int keyWidth, int valueWidth) =>
        new(keyWidth, valueWidth, ImmutableSortedDictionary<int, ImmutableSortedDictionary<int, double>>.Empty);

    /// <summary>Number of stored association entries; at most M_K·M_V whatever the sequence length.</summary>
    public int OccupiedEntries => _rows.Values.Sum(r => r.Count);

    public double this[int key, int value] => _rows.TryGetValue(key, out var row) ? row.GetValueOrDefault(value) : 0;

    /// <summary>n = C·1: the accumulated key mass at an address.</summary>
    public double KeyMass(int key) => _rows.TryGetValue(key, out var row) ? row.Values.Sum() : 0;

    /// <summary>C ← C + w·b uᵀ. Touches s_K·s_V entries.</summary>
    public AssociationMemory Write(SparseCode key, SparseCode value, double weight = 1)
    {
        if (key.Width != KeyWidth || value.Width != ValueWidth) throw new ArgumentException("Code widths do not match the memory.");
        if (!(weight > 0)) throw new ArgumentException("Exposure weight must be positive.");
        var rows = _rows.ToBuilder();
        foreach (var (k, b) in key.Entries)
        {
            var row = (rows.TryGetValue(k, out var old) ? old : ImmutableSortedDictionary<int, double>.Empty).ToBuilder();
            foreach (var (v, u) in value.Entries) row[v] = row.GetValueOrDefault(v) + weight * b * u;
            rows[k] = row.ToImmutable();
        }
        return new AssociationMemory(KeyWidth, ValueWidth, rows.ToImmutable());
    }

    /// <summary>
    /// The read for query code a under an entrywise nonnegative compatibility H (M_Q × M_K).
    /// Throws when query and stored key supports do not interact, since the denominator is then zero;
    /// the declared remedies are H = H₀ + λ11ᵀ or an explicit background key and value.
    /// </summary>
    public SparseCode Read(Matrix h, SparseCode query)
    {
        if (h.Cols != KeyWidth || h.Rows != query.Width) throw new ArgumentException("Compatibility shape does not match query and key widths.");
        if (!h.IsNonnegative) throw new ArgumentException("The recurrent kernel needs an entrywise nonnegative compatibility matrix.");
        var acc = new SortedDictionary<int, double>();
        foreach (var (k, row) in _rows)
        {
            double w = query.Entries.Sum(e => e.Value * h[e.Index, k]);
            if (w == 0) continue;
            foreach (var (v, c) in row) acc[v] = acc.GetValueOrDefault(v) + w * c;
        }
        if (acc.Count == 0) throw new InvalidOperationException("The read denominator is zero: query and stored key supports do not interact under H.");
        return SparseCode.Normalize(ValueWidth, acc.Select(kv => (kv.Key, kv.Value)));
    }

    /// <summary>
    /// Migration C_new = T_K C T_Vᵀ. If H_old = T_Qᵀ H_new T_K and the query is moved by T_Q, the new
    /// read equals T_V applied to the old read (Theorem 15). Without that identity the stored
    /// coefficients silently change meaning: rebuild from evidence or start a new memory epoch.
    /// </summary>
    public AssociationMemory Migrate(Transport keyTransport, Transport valueTransport)
    {
        if (keyTransport.InputWidth != KeyWidth || valueTransport.InputWidth != ValueWidth) throw new ArgumentException("Transport widths do not match the memory.");
        var acc = new SortedDictionary<int, SortedDictionary<int, double>>();
        foreach (var (k, row) in _rows)
            foreach (var (k2, tk) in keyTransport.Columns[k].Entries)
            {
                if (!acc.TryGetValue(k2, out var target)) acc[k2] = target = new SortedDictionary<int, double>();
                foreach (var (v, c) in row)
                    foreach (var (v2, tv) in valueTransport.Columns[v].Entries)
                        target[v2] = target.GetValueOrDefault(v2) + tk * c * tv;
            }
        return new AssociationMemory(keyTransport.OutputWidth, valueTransport.OutputWidth,
            acc.ToImmutableSortedDictionary(kv => kv.Key, kv => kv.Value.ToImmutableSortedDictionary()));
    }

    /// <summary>
    /// Removes entries below a threshold and reports, for a fixed query, the removed fraction τ of read
    /// mass; the normalised read then moves by at most 2τ in ℓ₁ (Eq. 17). The certificate is
    /// query-specific.
    /// </summary>
    public (AssociationMemory Pruned, double RemovedReadFraction) Prune(double threshold, Matrix h, SparseCode query)
    {
        double total = 0, removed = 0;
        var rows = ImmutableSortedDictionary.CreateBuilder<int, ImmutableSortedDictionary<int, double>>();
        foreach (var (k, row) in _rows)
        {
            double w = query.Entries.Sum(e => e.Value * h[e.Index, k]);
            total += w * row.Values.Sum();
            removed += w * row.Values.Where(c => c < threshold).Sum();
            var kept = row.Where(kv => kv.Value >= threshold).ToImmutableSortedDictionary();
            if (!kept.IsEmpty) rows[k] = kept;
        }
        return (new AssociationMemory(KeyWidth, ValueWidth, rows.ToImmutable()), total > 0 ? removed / total : 0);
    }
}
