namespace Vocabucapillary;

/// <summary>Result of support reduction: the conditional code on the retained support and the mass η that was discarded.</summary>
public sealed record Truncation(SparseCode Code, double DiscardedMass)
{
    /// <summary>‖D c − D c̃‖ ≤ η·diam(D) (Vocabuquantization, Corollary 1.1; Cacheless Transformer, Lemma 10).</summary>
    public double DecodedErrorBound(double dictionaryDiameter) => DiscardedMass * dictionaryDiameter;
}

/// <summary>
/// A finite-precision code: integer counts nⱼ summing exactly to the resolution J, decoded as nⱼ / J.
/// Unit mass is exact for the integers as rationals.
/// </summary>
public sealed record QuantizedCode(int Width, ImmutableArray<int> Indices, ImmutableArray<int> Counts, int Resolution)
{
    public SparseCode Decode() => SparseCode.Normalize(Width, Indices.Zip(Counts, (i, n) => (i, (double)n)));

    public bool Equals(QuantizedCode? other) =>
        other is not null && Width == other.Width && Resolution == other.Resolution
        && Indices.SequenceEqual(other.Indices) && Counts.SequenceEqual(other.Counts);

    public override int GetHashCode() =>
        Indices.Zip(Counts).Aggregate(HashCode.Combine(Width, Resolution), (h, e) => HashCode.Combine(h, e.First, e.Second));

    /// <summary>Bits of the plain index-and-count layout, s(⌈log₂N⌉ + ⌈log₂(J+1)⌉), before headers.</summary>
    public int LayoutBits =>
        Indices.Length * ((int)Math.Ceiling(Math.Log2(Width)) + (int)Math.Ceiling(Math.Log2(Resolution + 1.0)));
}

/// <summary>Outcome of a complete quantizer: truncation followed by mass-preserving rounding.</summary>
public sealed record Quantization(QuantizedCode Quantized, double DiscardedMass, int RetainedSupport)
{
    /// <summary>TV(c, p̂) ≤ min{1, η + s/(2J)} (Vocabuquantization, Theorem 2).</summary>
    public double TotalVariationBound => Vocabuquantizer.TotalVariationBound(DiscardedMass, RetainedSupport, Quantized.Resolution);
}

/// <summary>
/// Vocabuquantization (Definition 1): a support compressor plus a finite-precision rule and a decoding rule.
/// Every function is pure and uses a deterministic tie rule (larger value first, then smaller address).
/// </summary>
public static class Vocabuquantizer
{
    /// <summary>
    /// Keeps the s largest coefficients and renormalises. Among supports of size at most s this
    /// minimises total variation, which equals the discarded mass η exactly (Theorem 1). It minimises
    /// that certificate, not necessarily the decoded error.
    /// </summary>
    public static Truncation Truncate(SparseCode c, int support)
    {
        if (support < 1) throw new ArgumentOutOfRangeException(nameof(support), "At least one address must be retained.");
        if (c.Support <= support) return new Truncation(c, 0);
        var ordered = c.Entries.OrderByDescending(e => e.Value).ThenBy(e => e.Index).ToArray();
        double discarded = ordered.Skip(support).Sum(e => e.Value);
        return new Truncation(SparseCode.Normalize(c.Width, ordered.Take(support)), discarded);
    }

    /// <summary>Conditional code on a chosen support A, with η the mass outside A. A must carry positive mass.</summary>
    public static Truncation Restrict(SparseCode c, IEnumerable<int> retained)
    {
        var keep = retained.ToHashSet();
        var kept = c.Entries.Where(e => keep.Contains(e.Index)).ToArray();
        if (kept.Length == 0) throw new ArgumentException("The retained support carries no mass.");
        double discarded = c.Entries.Where(e => !keep.Contains(e.Index)).Sum(e => e.Value);
        return new Truncation(SparseCode.Normalize(c.Width, kept), discarded);
    }

    /// <summary>
    /// Largest-remainder rounding to counts summing to J: floor J·pⱼ, then give the remaining counts to
    /// the largest fractional parts. Preserves nonnegativity and unit sum, with every coordinate error
    /// below 1/J (Section 3.2). Rounding may remove further tiny coefficients.
    /// </summary>
    public static QuantizedCode Round(SparseCode p, int resolution)
    {
        if (resolution < 1) throw new ArgumentOutOfRangeException(nameof(resolution), "Resolution J must be at least 1.");
        var scaled = p.Entries.Select(e => (e.Index, Target: resolution * e.Value)).ToArray();
        var floors = scaled.Select(e => (e.Index, Count: (int)Math.Floor(e.Target), Fraction: e.Target - Math.Floor(e.Target))).ToArray();
        int rest = Math.Max(0, resolution - floors.Sum(f => f.Count));
        var bonus = floors.OrderByDescending(f => f.Fraction).ThenBy(f => f.Index).Take(rest).Select(f => f.Index).ToHashSet();
        var counted = floors.Select(f => (f.Index, Count: f.Count + (bonus.Contains(f.Index) ? 1 : 0))).Where(f => f.Count > 0).ToArray();
        return new QuantizedCode(p.Width, counted.Select(f => f.Index).ToImmutableArray(), counted.Select(f => f.Count).ToImmutableArray(), resolution);
    }

    /// <summary>The complete quantizer: keep s addresses, then round to J counts.</summary>
    public static Quantization Quantize(SparseCode c, int support, int resolution)
    {
        var t = Truncate(c, support);
        return new Quantization(Round(t.Code, resolution), t.DiscardedMass, t.Code.Support);
    }

    public static Quantization Quantize(SparseCode c, Resolution r) => Quantize(c, r.Support, r.Precision);

    /// <summary>min{1, η + s/(2J)} (Theorem 2).</summary>
    public static double TotalVariationBound(double discardedMass, int support, int resolution) =>
        Math.Min(1, discardedMass + support / (2.0 * resolution));

    /// <summary>Smallest J for which rounding s coefficients contributes at most ε of total variation: J ≥ s/(2ε).</summary>
    public static int ResolutionFor(int support, double roundingBudget) =>
        (int)Math.Ceiling(support / (2 * roundingBudget));

    /// <summary>
    /// log₂ of the number of codes with exactly s occupied addresses and positive counts summing to J,
    /// C(N, s)·C(J−1, s−1): a lower bound in bits for any fixed-length lossless layout (Proposition 3).
    /// </summary>
    public static double CodebookLog2Size(int atoms, int support, int resolution)
    {
        if (support < 1 || support > atoms || resolution < support) throw new ArgumentException("Need 1 ≤ s ≤ N and J ≥ s.");
        return Log2Binomial(atoms, support) + Log2Binomial(resolution - 1, support - 1);
    }

    internal static double Log2Binomial(int n, int k)
    {
        k = Math.Min(k, n - k);
        double s = 0;
        for (int i = 1; i <= k; i++) s += Math.Log2((n - k + i) / (double)i);
        return s;
    }
}
