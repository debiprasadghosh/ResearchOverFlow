namespace Vocabucapillary;

/// <summary>Attention weights over the retained records and the resulting coefficient read.</summary>
public sealed record AttentionRead(Vector Weights, SparseCode Read);

/// <summary>
/// The sparse coefficient feedforward block h = P_s(W₁c + b₁), f(c) = P_s(W₂h + b₂) with signed
/// weights and capped simplex projections at both boundaries (Sparse Positive Coefficient Spaces,
/// Eq. 13). It provides nonlinear competition; it is not an exact rewrite of GELU or SwiGLU.
/// </summary>
public sealed record CoefficientFeedForward(Matrix W1, Vector B1, int HiddenSupport, Matrix W2, Vector B2, int OutputSupport)
{
    public SparseCode Hidden(SparseCode c) => SimplexMaps.CappedSparsemax(CoefficientLayer.Logits(W1, B1, c), HiddenSupport);
    public SparseCode Apply(SparseCode c) => SimplexMaps.CappedSparsemax(CoefficientLayer.Logits(W2, B2, Hidden(c)), OutputSupport);
}

/// <summary>Operators of a coefficient-native layer. All are pure functions of their arguments.</summary>
public static class CoefficientLayer
{
    /// <summary>The induced compatibility G = D_QᵀD_K / scale, which may contain negative entries.</summary>
    public static Matrix InducedCompatibility(AtomDictionary queryDictionary, AtomDictionary keyDictionary, double scale = 1) =>
        queryDictionary.Atoms.Transpose().Multiply(keyDictionary.Atoms).Scale(1 / scale);

    /// <summary>The bilinear score aᵀGb, using only the s_Q·s_K active entries of G.</summary>
    public static double Score(SparseCode a, Matrix g, SparseCode b) =>
        a.Entries.Sum(x => x.Value * b.Entries.Sum(y => g[x.Index, y.Index] * y.Value));

    /// <summary>
    /// Softmax attention directly between coefficient states: zⱼ = aᵀGbⱼ + βⱼ, r = Σ αⱼuⱼ.
    /// With the induced G it reproduces decoded vector attention exactly, D_V r = Σ αⱼvⱼ (Theorem 4).
    /// The read lies in the simplex but its support is the union of the value supports (Proposition 5),
    /// so truncate it explicitly. One record per token is still retained.
    /// </summary>
    public static AttentionRead Attend(SparseCode query, Matrix g, IReadOnlyList<(SparseCode Key, SparseCode Value)> records, IReadOnlyList<double>? bias = null)
    {
        if (records.Count == 0) throw new ArgumentException("Attention needs at least one unmasked record.");
        var z = records.Select((r, j) => Score(query, g, r.Key) + (bias?[j] ?? 0)).ToArray();
        double max = z.Max();
        var e = z.Select(v => Math.Exp(v - max)).ToArray();
        double total = e.Sum();
        var alpha = Vec.Create(e.Length, j => e[j] / total);
        return new AttentionRead(alpha, Codes.Mix(records.Select((r, j) => (alpha[j], r.Value))));
    }

    /// <summary>W c + b computed from the active columns only: O(M_out·s_in) arithmetic.</summary>
    public static Vector Logits(Matrix w, Vector bias, SparseCode c)
    {
        if (w.Cols != c.Width || bias.Length != w.Rows) throw new ArgumentException("Router shape does not match the code or the bias.");
        var z = bias.ToArray();
        foreach (var (j, v) in c.Entries)
            for (int i = 0; i < z.Length; i++) z[i] += v * w[i, j];
        return Vec.Seal(z);
    }

    /// <summary>A sparse positive router a = P_s(W c + b).</summary>
    public static SparseCode Route(Matrix w, Vector bias, SparseCode c, int support) =>
        SimplexMaps.CappedSparsemax(Logits(w, bias, c), support);

    /// <summary>
    /// The mass-preserving residual r = (1 − g)·J c + g·T z followed by truncation to s addresses
    /// (Eq. 14). Before truncation r lies in the target simplex and the map is nonexpansive in ℓ₁ for
    /// a fixed gate (Theorem 11); the truncation is controlled by its discarded mass, not by a
    /// Lipschitz bound. Normalising c + η z is the same mixture with g = η/(1 + η).
    /// </summary>
    public static Truncation Residual(SparseCode c, SparseCode branch, double gate, int support, Transport? skip = null, Transport? transport = null)
    {
        if (!(gate >= 0 && gate <= 1)) throw new ArgumentOutOfRangeException(nameof(gate), "The gate must lie in [0, 1].");
        var left = skip is null ? c : skip.Apply(c);
        var right = transport is null ? branch : transport.Apply(branch);
        if (left.Width != right.Width) throw new ArgumentException("Residual branches must be aligned to one dictionary before they are combined.");
        return Vocabuquantizer.Truncate(Codes.Mix(new[] { (1 - gate, left), (gate, right) }), support);
    }

    /// <summary>
    /// Branch-preserving concatenation [(1 − g)c ; g z] in a simplex of width M + P: an explicit
    /// increase of the coordinate namespace, distinct from summing in one coordinate system.
    /// </summary>
    public static SparseCode Concatenate(SparseCode c, SparseCode z, double gate) =>
        SparseCode.Normalize(c.Width + z.Width,
            c.Entries.Select(e => (e.Index, (1 - gate) * e.Value)).Concat(z.Entries.Select(e => (c.Width + e.Index, gate * e.Value))));

    /// <summary>
    /// Contraction bound 1 − g + g·η(T) for the residual R = (1 − g)I + gT with a fixed stochastic T.
    /// Repeating a block with a bound below one shrinks differences geometrically.
    /// </summary>
    public static double ResidualContraction(double gate, Transport t) => 1 - gate + gate * t.ContractionCoefficient();
}
