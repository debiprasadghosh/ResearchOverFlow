# Vocabucapillary — immutable C# reference library

A reference implementation of the Vocabucapillary papers (Ghosh, 2026a–j, and the two follow-ups on
sparse positive coefficient spaces and text diffusion). It implements the objects and the exact
identities, bounds and certificates the papers state, so that their numerical support can be
computed in one place.

It is a reference implementation: it favours clarity and checkable correctness over speed, and it
contains no trained model.

## Layout

```
Vocabucapillary.sln
src/Vocabucapillary/            the library (no dependencies beyond the .NET base library)
checks/Vocabucapillary.Checks/  108 numerical checks of the papers' identities and bounds
examples/Quickstart/            a short end-to-end tour
```

```
dotnet build -c Release
dotnet run -c Release --project checks/Vocabucapillary.Checks    # prints pass/FAIL per check; exit code 0 = all pass
dotnet run -c Release --project examples/Quickstart
```

Built and tested with the .NET 10 SDK. The code uses only C# 12 and .NET 8 APIs, so changing
`<TargetFramework>` to `net8.0` or `net9.0` in the three project files should work, but that has not
been tested.

## What is in the library

| File | Main types | Source |
|---|---|---|
| `Numerics.cs` | `Vec`, `Matrix` | — |
| `SparseCode.cs` | `SparseCode`, `Codes`, `AtomDictionary`, `Resolution` | CT Def. 1; MAML Def. 1 |
| `SimplexMaps.cs` | `SimplexMaps`: sparsemax, capped projection, top-k softmax, pullbacks | SPCS Thm 7, Lemma 8; MM Thm 4; BP Thm 3 |
| `Vocabuquantization.cs` | `Vocabuquantizer`, `Truncation`, `QuantizedCode`, `Quantization` | VQ Thm 1, 2, Prop. 3 |
| `Transport.cs` | `Transport`, `VocabularyHierarchy` | SPCS Thm 3, 11, 12; VTD Def. 1 |
| `CoefficientLayer.cs` | `CoefficientLayer`, `CoefficientFeedForward`, `AttentionRead` | SPCS Thm 4, Prop. 5, Eq. 13–14 |
| `CoefficientMemory.cs` | `CoefficientMemory`, `ResponseKernel`, `AssociationMemory` | CT Thm 6, Lemma 5, Prop. 12; VQ Thm 20; SPCS Thm 13, 15 |
| `Explanation.cs` | `ReadExplanation`, `AnchoredPath`, `ModalityCode`, `ReadGame` | INT Thm 7, 8, 11; MM Lemma 1; SH Lemma 6, Thm 8 |
| `Adjoints.cs` | `SparseAdjoints` | BP Thm 1, 5, 6, Lemma 2 |
| `Probabilistic.cs` | `Categorical`, `MassState` | PV Lemma 1, Prop. 8, Thm 9, 13 |
| `Certificates.cs` | `Certificates`, `SupportAllocation` | VQ Lemma 6, Thm 9, 12, 13, 15; MH Thm 7, 9, 17; MAML Thm 12 |
| `ResolutionDiffusion.cs` | `ResolutionSchedule`, `SequenceLaw`, `ResolutionDiffusion` | VTD Thm 1, 3, 5 |
| `Harness.cs` | `CodeRecord`, `StateContract` | SPCS Section 11 |

Abbreviations: CT = Cacheless Transformer; MH = Memory and AI Harness; VQ = Vocabuquantization;
INT = Interpretability; BP = Sparse Backpropagation; MAML = Resolution Adaptive MAML;
PV = Probabilistic Vocabucapillary; MM = Multimodal Explainability; SH = Shapley Explanations;
SPCS = Attention in Sparse Positive Coefficient Spaces; VTD = Vocabucapillary Text Diffusion.
Every public member's XML comment names the statement it implements.

## Conventions

- **Immutability.** Every type is a sealed record or class with get-only state held in
  `ImmutableArray` / `ImmutableSortedDictionary`. Every operation is a pure function that returns a
  new value: `memory.Write(...)` returns a new memory and leaves `memory` unchanged. Arrays appear
  only as local accumulators inside a function and never escape it.
- **Invariants at construction.** A `SparseCode` cannot exist without strictly increasing in-range
  addresses, strictly positive values and unit mass. `SparseCode.Create` rejects input whose mass is
  not one; `SparseCode.Normalize` is the explicit way to normalise weights. Nothing is repaired
  silently.
- **Determinism.** Ties are broken by larger value first, then smaller address. Anything random
  takes a seed.
- **Equality.** `SparseCode`, `Matrix`, `QuantizedCode` and `Transport` compare by content. Other
  records that hold collections (`CoefficientMemory`, `MemoryRead`, `ModalityCode`, `ReadGame`, …)
  use the default record equality, which compares those collections by reference.
- **Units.** Entropies and the diffusion gap are in nats. Addresses are zero-based.
- **Vectors "on support".** Reverse rules take and return vectors aligned with `code.Indices`, so
  they cost O(s) and never build a length-N gradient.

## What the checks establish, and what they do not

The 108 checks confirm, on synthetic inputs, that the code satisfies the stated identities to
rounding error (for example the aggregate read against the tokenwise read, exact memory migration,
the capped projection against exhaustive support search, Shapley closed form against enumeration,
adjoints against finite differences) and that every stated bound holds over random trials.

They do not establish anything about trained language models, natural text, speed or memory use on
real hardware. Each certificate in `Certificates` is conditional on inputs the caller must justify
(norm bounds, Lipschitz constants, a fixed query), and the allocation rules are conditional on a
validated error surrogate.

Known limits: `Matrix` is dense, so a 32 768-atom compatibility table is not practical here;
`ReadGame.ShapleyExact` is limited to 20 players; `SequenceLaw.FromWeights` enumerates at most about
four million sequences; candidate search for routers is not implemented, only its exactness
certificate.
