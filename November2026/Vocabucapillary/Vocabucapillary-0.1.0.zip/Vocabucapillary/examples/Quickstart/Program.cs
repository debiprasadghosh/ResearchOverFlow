// A short tour: code -> quantize -> bounded memory -> read -> explain -> certify.
using System.Collections.Immutable;
using Vocabucapillary;

// A dictionary of 1 000 vocabulary atoms in 16 dimensions, and a router that produces a sparse code.
var dictionary = new AtomDictionary(Matrix.Random(rows: 16, cols: 1000, seed: 1), Version: "demo-v1");
var router = Matrix.Random(rows: 1000, cols: 1000, seed: 2);
var token = SparseCode.OneHot(width: 1000, address: 42);
SparseCode code = CoefficientLayer.Route(router, Vec.Zero(1000), token, support: 8);
Console.WriteLine($"code: {code}");

// Vocabuquantization: keep 4 addresses at 8-bit precision, with a certificate.
Quantization q = Vocabuquantizer.Quantize(code, support: 4, resolution: 255);
Console.WriteLine($"quantized to {q.Quantized.LayoutBits} bits; TV bound {q.TotalVariationBound:F4}; " +
                  $"actual TV {Codes.TotalVariation(code, q.Quantized.Decode()):F4}");

// Bounded coefficient memory: 5 000 writes, state independent of the prefix length.
var kernel = new ResponseKernel(KeyAtoms: Matrix.Random(8, 1000, seed: 3), Temperature: 1.0);
var rng = new Random(4);
var memory = Enumerable.Range(0, 5000).Aggregate(CoefficientMemory.Empty(width: 1000, valueDimension: 6), (m, t) =>
{
    var write = CoefficientLayer.Route(router, Vec.Zero(1000), SparseCode.OneHot(1000, rng.Next(50)), support: 3);
    return m.Step(write, value: Vec.Create(6, _ => rng.NextDouble()), gamma: 0.999);
});
var query = Vec.Create(8, i => 0.1 * (i + 1));
MemoryRead read = memory.Read(kernel, query);
Console.WriteLine($"memory: {memory.OccupiedRows} occupied rows after 5 000 writes; read = [{string.Join(", ", read.Output.Select(v => v.ToString("F3")))}]");

// Explain the read: which rows matter for the first output coordinate, and what deleting them does.
var readout = Vec.Create(6, i => i == 0 ? 1.0 : 0.0);
ImmutableArray<int> top = ReadExplanation.TopResponseRows(read, rows: 3);
var beta = ReadExplanation.GateSensitivities(read, readout);
DeletionEffect deletion = ReadExplanation.Delete(read, top);
Console.WriteLine($"top rows {string.Join(", ", top.Select(j => $"{j} (pi={read.ResponseMass[j]:F3}, beta={beta[j]:+0.000;-0.000})"))}");
Console.WriteLine($"deleting them moves the read by {Vec.Norm(deletion.Change):F4} (bound {deletion.Bound(ReadExplanation.ValueDiameter(read)):F4})");

// A decision certificate: is the greedy token safe under a logit error of 0.05?
var logits = new[] { 2.1, 1.7, 0.3, -1.0 };
Console.WriteLine($"greedy token preserved under |dz| <= 0.05: {Certificates.GreedyTokenIsPreserved(logits, 0.05)}; " +
                  $"next-token TV <= {Certificates.NextTokenTotalVariation(0.05):F4}");
