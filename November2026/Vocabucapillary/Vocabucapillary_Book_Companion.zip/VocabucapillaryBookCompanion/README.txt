Vocabucapillary book companion
==============================
Numbers/   computes every number printed in the workdowns and in Appendix A
           (dotnet run -c Release --project Numbers -- numbers.json)
Listings/  every code listing of the book, in order, as one compilable program
           (dotnet run -c Release --project Listings)

Unpack this folder next to the unpacked library folder "Vocabucapillary"
(from Vocabucapillary-0.1.0.zip), so that both sit in one parent folder.
Built and tested with the .NET 10 SDK.
