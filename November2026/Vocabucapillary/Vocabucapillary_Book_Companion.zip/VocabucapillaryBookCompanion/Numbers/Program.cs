// Computes every number quoted in the book's workdowns and numericals, using the library.
using System.Collections.Immutable;
using System.Globalization;
using System.Text.Json;
using Vocabucapillary;
using Vector = System.Collections.Immutable.ImmutableArray<double>;

CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
var N = new SortedDictionary<string, string>(StringComparer.Ordinal);
string F(double v, int dp = 4) { var s = Math.Round(v, dp).ToString("F" + dp); return s.StartsWith("-0.") && double.Parse(s) == 0 ? s[1..] : s.Replace("-", "−"); }
void Put(string k, double v, int dp = 4) { N[k] = F(v, dp); Console.WriteLine($"{k} = {N[k]}"); }
void PutS(string k, string v) { N[k] = v; Console.WriteLine($"{k} = {v}"); }
string V(IEnumerable<double> v, int dp = 4) => "(" + string.Join(", ", v.Select(x => F(x, dp))) + ")";
void PutV(string k, IEnumerable<double> v, int dp = 4) => PutS(k, V(v, dp));
void PutC(string k, SparseCode c, int dp = 4) => PutV(k, c.ToDense(), dp);
SparseCode C(int width, params (int, double)[] e) => SparseCode.Create(width, e);

var D = new AtomDictionary(Matrix.FromColumns(new[] { Vec.Of(1, 0), Vec.Of(0, 1), Vec.Of(-1, 0), Vec.Of(1, 1) }), "toy-v1");

// ---------------- P1 vectors
{
    var u = Vec.Of(3, -4, 0); var v = Vec.Of(1, 2, 2);
    Put("p1.w1.dot", Vec.Dot(u, v), 0); Put("p1.w1.nu", Vec.Norm(u), 0); Put("p1.w1.nv", Vec.Norm(v), 0);
    Put("p1.w1.n1", Vec.Norm1(u), 0); Put("p1.w1.ninf", Vec.NormInf(u), 0); Put("p1.w1.cos", Vec.Dot(u, v) / (Vec.Norm(u) * Vec.Norm(v)));
    PutV("p1.w2.Dc", D.Atoms.Multiply(Vec.Of(0.5, 0.3, 0, 0.2)), 2);
    var a = Vec.Of(1, -2, 2); var b = Vec.Of(2, 1, -2);
    Put("p1.n1.dot", Vec.Dot(a, b), 0); Put("p1.n1.norm", Vec.Norm(a), 0); Put("p1.n1.l1", Vec.Norm1(Vec.Subtract(a, b)), 0);
    PutV("p1.n2", D.Atoms.MultiplyTransposed(Vec.Of(2, -1)), 0);
    Put("p1.n3", D.Diameter());
    Put("p1.n4", Enumerable.Range(0, 4).Max(j => Vec.Norm(D.Atom(j))));
    PutV("p1.n5", Matrix.FromRows(new[] { new[] { 1.0, 2 }, new[] { 0.0, 1 }, new[] { 3.0, -1 } }).Multiply(Vec.Of(2, -1)), 0);
}
// ---------------- P2 probability
{
    var p = SparseCode.FromDense(new[] { 0.5, 0.25, 0.25 });
    Put("p2.w1.nats", p.Entropy()); Put("p2.w1.bits", p.Entropy() / Math.Log(2), 2); Put("p2.w1.eff", Math.Exp(p.Entropy()));
    var a = SparseCode.FromDense(new[] { 0.5, 0.3, 0.2 }); var b = SparseCode.FromDense(new[] { 0.4, 0.4, 0.2 });
    Put("p2.w2.tv", Codes.TotalVariation(a, b)); Put("p2.w2.kl", a.Entries.Sum(e => e.Value * Math.Log(e.Value / b[e.Index])));
    Put("p2.w2.t1", 0.5 * Math.Log(1.25)); Put("p2.w2.t2", 0.3 * Math.Log(0.75));
    Put("p2.n1", Math.Log(8));
    var x = SparseCode.FromDense(new[] { 0.7, 0.2, 0.1 }); var y = SparseCode.FromDense(new[] { 0.1, 0.2, 0.7 });
    Put("p2.n2", Codes.TotalVariation(x, y)); Put("p2.n3.H", x.Entropy()); Put("p2.n3", Math.Log(3) - x.Entropy());
    PutC("p2.n4", Codes.Mix(new[] { (0.25, SparseCode.OneHot(3, 0)), (0.75, SparseCode.FromDense(new[] { 0.2, 0.3, 0.5 })) }), 3);
    Put("p2.n5", Math.Exp(SparseCode.FromDense(new[] { 0.4, 0.4, 0.1, 0.1 }).Entropy()));
}
// ---------------- P3 softmax and attention
{
    PutC("p3.w1.a", Categorical.Softmax(new[] { 2.0, 1, 0 })); PutC("p3.w1.b", Categorical.Softmax(new[] { 2.0, 1, 0 }, 2));
    Put("p3.w1.e2", Math.Exp(2), 3); Put("p3.w1.e1", Math.E, 3); Put("p3.w1.sum", Math.Exp(2) + Math.E + 1, 3);
    Vector Attend(Vector q, double tau)
    {
        var keys = new[] { Vec.Of(1, 0), Vec.Of(0, 1), Vec.Of(-1, 0) }; var vals = new[] { Vec.Of(1, 0), Vec.Of(0, 1), Vec.Of(1, 1) };
        var al = Categorical.Softmax(keys.Select(k => Vec.Dot(q, k)).ToArray(), tau).ToDense();
        return Enumerable.Range(0, 3).Aggregate(Vec.Zero(2), (acc, j) => Vec.AddScaled(acc, al[j], vals[j]));
    }
    PutV("p3.w2.o", Attend(Vec.Of(1, 0), 1));
    PutC("p3.n1", Categorical.Softmax(new[] { 0.0, Math.Log(3) }), 2);
    Put("p3.n2", Vec.LogSumExp(new[] { 1000.0, 1000.0 }));
    long bytes = 24L * 16 * 64 * 4096 * 2 * 2; PutS("p3.n3.bytes", bytes.ToString("N0", CultureInfo.InvariantCulture)); Put("p3.n3.mib", bytes / 1048576.0, 0);
    PutC("p3.n4.a", Categorical.Softmax(new[] { 1.0, 0, -1 }, 0.5)); PutV("p3.n4.o", Attend(Vec.Of(1, 0), 0.5));
    PutV("p3.n5.o", Attend(Vec.Of(0, 1), 1));
}
// ---------------- P4 C#
{
    Put("p4.n1", Vec.Dot(Vec.Of(1, 2, 3), Vec.Of(4, 5, 6)), 0);
    PutS("p4.n2", SparseCode.Normalize(5, new[] { (1, 2.0), (3, 6.0) }).ToString());
    Put("p4.n3", Enumerable.Range(1, 5).Aggregate(0, (a, x) => a + x * x), 0);
    var c = C(4, (0, 0.5), (1, 0.3), (3, 0.2));
    PutS("p4.n4", $"{c.Support}, {c[2]}, {c[3]}");
    PutS("p4.w1.eq", (SparseCode.OneHot(4, 2) == C(4, (2, 1.0))).ToString());
    var m0 = CoefficientMemory.Empty(3, 1); var m1 = m0.Write(SparseCode.OneHot(3, 0), Vec.Of(2.0)); var m2 = m1.Write(C(3, (0, 0.5), (1, 0.5)), Vec.Of(4.0));
    PutS("p4.w2", $"{m0.OccupiedRows}, {m1.OccupiedRows}, {m2.OccupiedRows}; masses {F(m2.Rows[0].Mass, 1)}, {F(m2.Rows[1].Mass, 1)}; total {F(m2.TotalMass, 1)}");
    PutS("p4.n5", string.Join(", ", Enumerable.Range(0, 6).Where(i => i % 2 == 0).Select(i => i * i)));
}
// ---------------- C1 codes
{
    var c = SparseCode.Normalize(4, new[] { (0, 3.0), (1, 1.0), (3, 1.0) });
    PutC("c1.w1.c", c, 1); PutV("c1.w1.h", D.Decode(c), 1); Put("c1.w1.H", c.Entropy()); Put("c1.w1.eff", Math.Exp(c.Entropy()), 3);
    Put("c1.w1.t1", -0.6 * Math.Log(0.6)); Put("c1.w1.t2", -0.2 * Math.Log(0.2));
    var r = new Resolution(32768, 8, 255, 1024);
    Put("c1.w2.bits", r.RecordBits, 0); Put("c1.w2.dense", 768 * 16, 0); Put("c1.w2.ratio", 768 * 16.0 / r.RecordBits, 1);
    Put("c1.w2.mem", 1024 * 65, 0); Put("c1.w2.kv", 4096 * 2 * 64, 0); Put("c1.w2.kvratio", 4096 * 2 * 64 / (1024 * 65.0), 1);
    PutV("c1.n1", D.Decode(C(4, (1, 0.5), (2, 0.5))), 1);
    var mix = Codes.Mix(new[] { (0.4, SparseCode.OneHot(4, 0)), (0.6, C(4, (1, 0.5), (3, 0.5))) });
    PutC("c1.n2", mix, 1); Put("c1.n2.s", mix.Support, 0);
    Put("c1.n3", new Resolution(50000, 4, 15, 1).RecordBits, 0);
    PutV("c1.n4", D.Decode(C(4, (0, 0.5), (1, 0.2), (2, 0.3))), 1);
    Put("c1.n5", Codes.TotalVariation(c, C(4, (0, 0.5), (1, 0.3), (3, 0.2))), 2);
    PutS("c1.code", c.ToString());
}
// ---------------- C2 simplex maps
{
    PutC("c2.w1", SimplexMaps.Sparsemax(new[] { 0.5, 0.3, -1.0 }), 1);
    var z = new[] { 1.2, 0.9, 0.8, -0.5 };
    PutC("c2.w2.cap", SimplexMaps.CappedSparsemax(z, 2), 2); PutC("c2.w2.full", SimplexMaps.Sparsemax(z)); PutC("c2.w2.soft", SimplexMaps.TopSoftmax(z, 2));
    PutC("c2.w2.softall", Categorical.Softmax(z));
    PutC("c2.n1", SimplexMaps.Sparsemax(new[] { 2.0, 0, 0 }), 0);
    PutC("c2.n2", SimplexMaps.Sparsemax(new[] { 0.6, 0.5, 0.4 }));
    PutC("c2.n3", SimplexMaps.TopSoftmax(z, 3, 0.5));
    PutV("c2.n4", SimplexMaps.SparsemaxPullback(SparseCode.FromDense(new[] { 0.5, 0.3, 0.2 }), Vec.Of(3, 0, 0)), 0);
    PutV("c2.n5", SimplexMaps.SoftmaxPullback(SparseCode.FromDense(new[] { 0.5, 0.3, 0.2 }), Vec.Of(1, 0, 0)), 2);
    PutS("c2.n6", $"{SimplexMaps.CandidateSetIsExact(new[] { 0.9, 0.6, 0.2 }, 2, 0.5)}, {SimplexMaps.CandidateSetIsExact(new[] { 0.9, 0.6, 0.2 }, 2, 0.7)}");
}
// ---------------- C3 quantization
{
    var c = SparseCode.FromDense(new[] { 0.42, 0.33, 0.15, 0.10 });
    var t = Vocabuquantizer.Truncate(c, 3);
    Put("c3.w1.eta", t.DiscardedMass, 2); PutC("c3.w1.trunc", t.Code);
    var q = Vocabuquantizer.Quantize(c, 3, 7);
    PutS("c3.w1.counts", string.Join(", ", q.Quantized.Counts)); PutC("c3.w1.dec", q.Quantized.Decode());
    PutV("c3.w1.scaled", t.Code.Values.Select(v => 7 * v), 3);
    Put("c3.w1.tv", Codes.TotalVariation(c, q.Quantized.Decode())); Put("c3.w1.bound", q.TotalVariationBound);
    Put("c3.w2.log2", Vocabuquantizer.CodebookLog2Size(4, 3, 7), 3); Put("c3.w2.layout", q.Quantized.LayoutBits, 0);
    Put("c3.w2.big", Vocabuquantizer.CodebookLog2Size(32768, 8, 255), 1); Put("c3.w2.biglayout", new Resolution(32768, 8, 255, 1).RecordBits, 0);
    var c3 = SparseCode.FromDense(new[] { 0.5, 0.3, 0.2, 0 });
    var t1 = Vocabuquantizer.Truncate(c3, 1); Put("c3.n1.eta", t1.DiscardedMass, 1); Put("c3.n1.bound", t1.DecodedErrorBound(D.Diameter()));
    Put("c3.n1.actual", Vec.Distance(D.Decode(c3), D.Decode(t1.Code)));
    var q2 = Vocabuquantizer.Quantize(c3, 3, 3); PutS("c3.n2.counts", string.Join(", ", q2.Quantized.Counts)); PutC("c3.n2.dec", q2.Quantized.Decode()); Put("c3.n2.tv", Codes.TotalVariation(c3, q2.Quantized.Decode()));
    Put("c3.n3.J", Vocabuquantizer.ResolutionFor(8, 0.01), 0);
    Put("c3.n4", Vocabuquantizer.TotalVariationBound(0.05, 8, 255));
    var q5 = Vocabuquantizer.Quantize(c, 2, 15); PutS("c3.n5.counts", string.Join(", ", q5.Quantized.Counts)); Put("c3.n5.eta", q5.DiscardedMass, 2); Put("c3.n5.bound", q5.TotalVariationBound); Put("c3.n5.tv", Codes.TotalVariation(c, q5.Quantized.Decode()));
}
// ---------------- C4 transports
{
    var T = Transport.FromColumns(new[] { C(2, (0, 1.0)), C(2, (0, 0.5), (1, 0.5)), C(2, (1, 1.0)) });
    var c = SparseCode.FromDense(new[] { 0.2, 0.5, 0.3 });
    PutC("c4.w1.Tc", T.Apply(c), 2); Put("c4.w1.eta", T.ContractionCoefficient(), 1);
    var T2 = Transport.FromColumns(new[] { C(2, (0, 0.8), (1, 0.2)), C(2, (0, 0.5), (1, 0.5)), C(2, (0, 0.3), (1, 0.7)) });
    Put("c4.w1.eta2", T2.ContractionCoefficient(), 1);
    Put("c4.w1.dist", Codes.L1Distance(T2.Apply(SparseCode.OneHot(3, 0)), T2.Apply(SparseCode.OneHot(3, 2))), 1);
    var cc = C(4, (0, 0.6), (1, 0.4)); var zz = C(4, (1, 0.5), (2, 0.5));
    var pre = Codes.Mix(new[] { (0.75, cc), (0.25, zz) }); PutC("c4.w2.pre", pre, 3);
    var res = CoefficientLayer.Residual(cc, zz, 0.25, 2); PutC("c4.w2.post", res.Code); Put("c4.w2.eta", res.DiscardedMass, 3);
    PutC("c4.n1", T2.Apply(c), 2);
    Put("c4.n2", CoefficientLayer.ResidualContraction(0.25, T2), 3);
    var wide = new AtomDictionary(Matrix.FromColumns(new[] { Vec.Of(1, 0), Vec.Of(0, 1), Vec.Of(-1, 0), Vec.Of(1, 1) }), "wide");
    var narrow = new AtomDictionary(Matrix.FromColumns(new[] { Vec.Of(1, 0), Vec.Of(0, 1) }), "narrow");
    var e = Transport.Embedding(2, 4); var c2 = C(2, (0, 0.6), (1, 0.4));
    PutV("c4.n3", wide.Decode(e.Apply(c2)), 1); Put("c4.n3.res", e.IntertwiningResidual(narrow, wide), 0);
    Put("c4.n4", Math.Pow(0.875, 6));
    PutC("c4.n5", CoefficientLayer.Concatenate(C(2, (0, 0.6), (1, 0.4)), C(2, (1, 1.0)), 0.25), 2);
    var merge = Transport.Merge(new[] { 0, 0, 1, 1 }, 2); PutC("c4.n6", merge.Apply(C(4, (0, 0.5), (1, 0.3), (3, 0.2))), 1);
}
// ---------------- C5 attention
{
    var G = CoefficientLayer.InducedCompatibility(D, D, Math.Sqrt(2));
    PutS("c5.w1.G", string.Join(" ; ", Enumerable.Range(0, 4).Select(i => string.Join(", ", Enumerable.Range(0, 4).Select(j => F(G[i, j], 3))))));
    var a = SparseCode.OneHot(4, 0);
    var recs = new[] { (Key: SparseCode.OneHot(4, 0), Value: SparseCode.OneHot(4, 1)), (Key: SparseCode.OneHot(4, 2), Value: SparseCode.OneHot(4, 2)), (Key: C(4, (1, 0.5), (3, 0.5)), Value: C(4, (0, 0.5), (3, 0.5))) };
    PutV("c5.w1.scores", recs.Select(r => CoefficientLayer.Score(a, G, r.Key)));
    var read = CoefficientLayer.Attend(a, G, recs);
    PutV("c5.w1.alpha", read.Weights); PutC("c5.w1.r", read.Read); PutV("c5.w1.dec", D.Decode(read.Read));
    var t = Vocabuquantizer.Truncate(read.Read, 2); Put("c5.w2.eta", t.DiscardedMass); PutC("c5.w2.trunc", t.Code); Put("c5.w2.s", read.Read.Support, 0);
    Put("c5.w2.err", Vec.Distance(D.Decode(read.Read), D.Decode(t.Code))); Put("c5.w2.bound", t.DecodedErrorBound(D.Diameter()));
    Put("c5.n1", CoefficientLayer.Score(C(4, (0, 0.5), (1, 0.5)), G, SparseCode.OneHot(4, 3)));
    var two = CoefficientLayer.Attend(SparseCode.OneHot(4, 1), G, recs.Take(2).Append(recs[2]).Skip(1).ToArray());
    PutV("c5.n2.alpha", two.Weights); PutC("c5.n2.r", two.Read);
    var W = Matrix.FromRows(new[] { new[] { 1.0, 0 }, new[] { 0.0, 1 }, new[] { 1.0, 1 } });
    PutV("c5.n3.logits", CoefficientLayer.Logits(W, Vec.Zero(3), C(2, (0, 0.6), (1, 0.4))), 1);
    PutC("c5.n3", CoefficientLayer.Route(W, Vec.Zero(3), C(2, (0, 0.6), (1, 0.4)), 2), 1);
    Put("c5.n4", Math.Min(4096, 12 * 4), 0);
    var biased = CoefficientLayer.Attend(a, G, recs, new[] { 0.0, 0, 1.0 }); PutV("c5.n5", biased.Weights);
}
// ---------------- C6 memory (also used by C8 and C10)
var kernel = new ResponseKernel(Matrix.FromColumns(new[] { Vec.Of(1, 0), Vec.Of(0, 1), Vec.Of(-1, 0) }), 1.0);
var hist = new[] { (Code: SparseCode.OneHot(3, 0), Value: Vec.Of(2.0)), (Code: C(3, (0, 0.5), (1, 0.5)), Value: Vec.Of(4.0)), (Code: SparseCode.OneHot(3, 2), Value: Vec.Of(-1.0)) };
var mem = hist.Aggregate(CoefficientMemory.Empty(3, 1), (m, x) => m.Write(x.Code, x.Value));
var q0 = Vec.Of(1, 0);
var rd = mem.Read(kernel, q0);
{
    PutV("c6.w1.m", mem.Rows.Values.Select(r => r.Mass), 1); PutV("c6.w1.S", mem.Rows.Values.Select(r => r.ValueSum[0]), 0);
    PutV("c6.w1.phi", Enumerable.Range(0, 3).Select(j => Math.Exp(kernel.Score(q0, j)))); Put("c6.w1.Z", Math.Exp(rd.LogDenominator));
    Put("c6.w1.num", rd.Output[0] * Math.Exp(rd.LogDenominator)); Put("c6.w1.o", rd.Output[0]);
    Put("c6.w1.kappa2", Math.Exp(kernel.LogKernel(q0, hist[1].Code)));
    PutV("c6.w1.pi", rd.ResponseMass.Values); PutV("c6.w1.u", rd.Means.Values.Select(v => v[0]));
    Put("c6.w2.gap", kernel.JensenGap(q0, hist[1].Code)); Put("c6.w2.bound", kernel.JensenGapBound(q0, hist[1].Code), 3); Put("c6.w2.soft", Math.Exp(0.5));
    var smAttn = Categorical.Softmax(hist.Select(h => Vec.Dot(q0, kernel.KeyAtoms.Multiply(h.Code.ToDense()))).ToArray()).ToDense();
    Put("c6.w2.softread", Enumerable.Range(0, 3).Sum(i => smAttn[i] * hist[i].Value[0]));
    var rec = hist.Aggregate(CoefficientMemory.Empty(3, 1), (m, x) => m.Step(x.Code, x.Value, 0.5));
    PutV("c6.w3.m", rec.Rows.Values.Select(r => r.Mass), 3); Put("c6.w3.o", rec.Read(kernel, q0).Output[0]); Put("c6.w3.total", rec.TotalMass, 2);
    var r2 = mem.Read(kernel, Vec.Of(0, 1)); Put("c6.n1", r2.Output[0]); PutV("c6.n1.pi", r2.ResponseMass.Values);
    Put("c6.n2", mem.Delete(new[] { 2 }).Read(kernel, q0).Output[0]);
    Put("c6.n3", 4096 * (1 + 64), 0); Put("c6.n3.kv", 100000L * 2 * 64, 0);
    var coarse = mem.Coarsen(Transport.Merge(new[] { 0, 0, 1 }, 2)); PutV("c6.n4.m", coarse.Rows.Values.Select(r => r.Mass), 1); PutV("c6.n4.S", coarse.Rows.Values.Select(r => r.ValueSum[0]), 0);
    Put("c6.n5", mem.Read(new ResponseKernel(kernel.KeyAtoms, 0.5), q0).Output[0]);
    Put("c6.n6", mem.Write(SparseCode.OneHot(3, 1), Vec.Of(10.0), 2).Read(kernel, q0).Output[0]);
}
// ---------------- C7 association memory
{
    var H = Matrix.FromRows(new[] { new[] { 1.0, 0.2 }, new[] { 0.2, 1.0 } });
    var e0 = SparseCode.OneHot(2, 0); var e1 = SparseCode.OneHot(2, 1); var half = C(2, (0, 0.5), (1, 0.5));
    var am = AssociationMemory.Empty(2, 2).Write(e0, e0).Write(e1, e1).Write(half, e1);
    PutS("c7.w2.C", $"{F(am[0, 0], 1)}, {F(am[0, 1], 1)} ; {F(am[1, 0], 1)}, {F(am[1, 1], 1)}"); PutS("c7.w2.n", $"({F(am.KeyMass(0), 1)}, {F(am.KeyMass(1), 1)})");
    PutC("c7.w2.r", am.Read(H, e0)); PutV("c7.w2.w", new[] { CoefficientLayer.Score(e0, H, e0), CoefficientLayer.Score(e0, H, e1), CoefficientLayer.Score(e0, H, half) }, 1);
    var same = AssociationMemory.Empty(2, 2).Write(e0, e0).Write(e1, e1); var swap = AssociationMemory.Empty(2, 2).Write(e0, e1).Write(e1, e0);
    PutC("c7.w1.same", same.Read(Matrix.Identity(2), e0), 0); PutC("c7.w1.swap", swap.Read(Matrix.Identity(2), e0), 0);
    PutC("c7.n1", am.Read(H, e1)); PutC("c7.n1b", am.Read(H, half));
    Put("c7.n2", 4096.0 * 4096 + 4096, 0);
    double g = 2.0; Put("c7.n3.a", Math.Exp(0.5 * g + 0.5 * 0)); Put("c7.n3.b", 0.5 * Math.Exp(g) + 0.5 * 1);
    var (pruned, removed) = am.Prune(0.6, H, e0); Put("c7.n4.tau", removed); PutC("c7.n4.r", pruned.Read(H, e0)); Put("c7.n4.l1", Codes.L1Distance(pruned.Read(H, e0), am.Read(H, e0)));
    Put("c7.n5", 12 * 8 + 12, 0);
    var lam = H.Add(Matrix.Create(2, 2, (_, _) => 0.5)); PutC("c7.n6", am.Read(lam, e0));
}
// ---------------- C8 backprop
{
    var c = C(4, (0, 0.5), (1, 0.3), (3, 0.2));
    var h = D.Decode(c); PutV("c8.w1.h", h, 1); var g = Vec.Subtract(h, Vec.Of(1, 0)); PutV("c8.w1.g", g, 1);
    var adj = SparseAdjoints.Decoding(D, c, g); PutV("c8.w1.gc", adj.Coefficients, 1);
    Put("c8.w1.mean", Vec.Dot(c.Values, adj.Coefficients), 2); PutV("c8.w1.zbar", SimplexMaps.SoftmaxPullback(c, adj.Coefficients), 3);
    PutV("c8.w1.atom0", adj.Atoms[0], 2);
    var ra = SparseAdjoints.Read(mem, kernel, q0, Vec.Of(1.0));
    PutV("c8.w2.phiZ", ra.ValueSum.Values.Select(v => v[0])); PutV("c8.w2.mbar", ra.Mass.Values); PutV("c8.w2.qbar", ra.Query); Put("c8.w2.taubar", ra.Temperature);
    PutV("c8.w2.b", rd.ResponseMass.Select(kv => kv.Value * (rd.Means[kv.Key][0] - rd.Output[0])));
    PutS("c8.n1", $"{SparseAdjoints.TopSupportIsStable(new[] { 0.9, 0.6, 0.2, 0.1 }, 2, 0.15)}, {SparseAdjoints.TopSupportIsStable(new[] { 0.9, 0.6, 0.2, 0.1 }, 2, 0.25)}");
    PutV("c8.n2", SparseAdjoints.Decoding(D, C(4, (1, 0.5), (2, 0.5)), Vec.Of(2, -1)).Coefficients, 0);
    Put("c8.n3.sparse", 8 * 768, 0); Put("c8.n3.dense", 32768L * 768, 0); Put("c8.n3.ratio", 32768.0 / 8, 0);
    PutV("c8.n4", SimplexMaps.SparsemaxPullback(c, Vec.Of(-0.3, 0.5, 0.2)), 4);
    var wa = SparseAdjoints.Write(SparseCode.OneHot(3, 1), Vec.Of(4.0), 1.0, j => ra.Mass[j], j => ra.ValueSum[j]); Put("c8.n5.v", wa.Value[0]); Put("c8.n5.w", wa.Weight);
    double hh = 1e-6; Put("c8.w2.fd", (mem.Read(kernel, Vec.Of(1 + hh, 0)).Output[0] - mem.Read(kernel, Vec.Of(1 - hh, 0)).Output[0]) / (2 * hh));
}
// ---------------- C9 probabilistic
{
    var st = new MassState(C(2, (0, 0.5), (1, 0.5)), 4); var up = Categorical.Update(st, SparseCode.OneHot(2, 0), 0.5, 1);
    PutC("c9.w1.p", up.Occupancy); Put("c9.w1.M", up.TotalMass, 0);
    var up2 = Categorical.Update(st with { TotalMass = 40 }, SparseCode.OneHot(2, 0), 0.5, 1); PutC("c9.w1.p2", up2.Occupancy); Put("c9.w1.M2", up2.TotalMass, 0);
    var steps = new[] { (1.0, Vec.Of(1, 0, 2)), (0.5, Vec.Of(0, 1, 0)) };
    var col = Categorical.EntropicCollapse(Vec.Of(0, 0, 0), steps); PutC("c9.w2.p", col);
    var s1 = Categorical.EntropicStep(Categorical.Softmax(new[] { 0.0, 0, 0 }), j => steps[0].Item2[j], 1.0); PutC("c9.w2.step1", s1);
    PutC("c9.w2.step2", Categorical.EntropicStep(s1, j => steps[1].Item2[j], 0.5));
    var p = SparseCode.FromDense(new[] { 0.5, 0.3, 0.2 });
    PutV("c9.n1", Categorical.FisherProduct(p, Vec.Of(1, 0, 0)), 2);
    PutV("c9.n2", Categorical.FisherSolve(p, Vec.Of(0.25, -0.15, -0.10)), 4);
    Put("c9.n3.mse", 0.1 * 0.1 * 4 / 4, 2); Put("c9.n3.rmse", Math.Sqrt(0.01), 1); Put("c9.n3.drop", 0.1 * 2, 1);
    PutV("c9.n4", SupportAllocation.InverseSquareRoot(new[] { 1.0, 4, 0.5 }, new[] { 1.0, 2, 0.5 }, 60), 2);
    PutV("c9.n5", SupportAllocation.InversePower(new[] { 1.0, 4, 0.5 }, new[] { 1.0, 2, 0.5 }, 1.0, 0.5), 2);
    PutV("c9.n6", Categorical.CollapsedMetaGradient(col, Vec.Of(1, 0, 0)));
    var occ = Categorical.Occupancy(mem); PutC("c9.n7", occ.Occupancy); Put("c9.n7.M", occ.TotalMass, 1);
}
// ---------------- C10 interpretation
{
    var del = ReadExplanation.Delete(rd, new[] { 2 });
    Put("c10.w1.new", del.ReadWithoutGroup[0]); Put("c10.w1.change", del.Change[0]); Put("c10.w1.diam", ReadExplanation.ValueDiameter(rd), 0); Put("c10.w1.bound", del.Bound(ReadExplanation.ValueDiameter(rd)));
    var beta = ReadExplanation.GateSensitivities(rd, Vec.Of(1.0)); PutV("c10.w1.beta", beta.Values); Put("c10.w1.betasum", beta.Values.Sum(), 4);
    var w = Vec.Of(3, 1, 0);
    var c0 = SparseCode.OneHot(3, 0); var c1 = SparseCode.FromDense(new[] { 0.2, 0.5, 0.3 });
    var s2 = AnchoredPath.Attribute(_ => w, c0, c1, 2); PutS("c10.w2.a2", string.Join(", ", s2.Select(kv => $"A{kv.Key} = {F(kv.Value, 1)}")));
    var s0 = AnchoredPath.Attribute(_ => w, c0, c1, 0); PutS("c10.w2.a0", string.Join(", ", s0.Select(kv => $"A{kv.Key} = {F(kv.Value, 1)}")));
    Put("c10.w2.total", Vec.Dot(w, c1.ToDense()) - Vec.Dot(w, c0.ToDense()), 1);
    Put("c10.n1", Certificates.ResponseAmplification(0.001, 1, 1000), 5);
    var del01 = ReadExplanation.Delete(rd, new[] { 1, 2 }); Put("c10.n2", del01.ReadWithoutGroup[0]); Put("c10.n2.pi", del01.ResponseMass);
    PutS("c10.n3", string.Join(", ", ReadExplanation.TopResponseRows(rd, 2)));
    var s1 = AnchoredPath.Attribute(_ => w, c0, c1, 1); PutS("c10.n4", string.Join(", ", s1.Select(kv => $"A{kv.Key} = {F(kv.Value, 1)}")));
    var quad = AnchoredPath.Attribute(c => Vec.Of(c[1], c[0], 0), SparseCode.OneHot(3, 2), SparseCode.FromDense(new[] { 0.5, 0.5, 0 }), 2);
    PutS("c10.n5", string.Join(", ", quad.Select(kv => $"A{kv.Key} = {F(kv.Value, 3)}")));
    Put("c10.n6", Certificates.ResponseAmplification(0.01, 1, 20));
}
// ---------------- C11 multimodal + shapley
{
    var mc = new ModalityCode(C(2, (0, 0.6), (1, 0.4)), ImmutableArray.Create(C(2, (0, 0.5), (1, 0.5)), C(2, (0, 0.25), (1, 0.75))));
    PutC("c11.w1.global", mc.Global(), 1); var (bal, det) = mc.EntropyParts(); Put("c11.w1.bal", bal); Put("c11.w1.det", det); Put("c11.w1.H", mc.Global().Entropy());
    Put("c11.w1.Himg", C(2, (0, 0.25), (1, 0.75)).Entropy());
    var game = new ReadGame(1, 0, ImmutableArray.Create((1.0, 1.0), (2.0, 4.0)));
    Put("c11.w2.v1", game.Value(new[] { 0 }), 4); Put("c11.w2.v2", game.Value(new[] { 1 })); Put("c11.w2.v12", game.Value(new[] { 0, 1 }), 2);
    PutV("c11.w2.phi", game.ShapleyExact());
    var eq = new ReadGame(1, 0, ImmutableArray.Create((1.0, 3.0), (1.0, 0.0), (1.0, -3.0)));
    PutV("c11.n1", eq.ShapleyEqualWeights()); Put("c11.n1.vN", eq.Value(new[] { 0, 1, 2 }), 2);
    var g3 = new ReadGame(0.5, 1, ImmutableArray.Create((1.0, 2.0), (0.5, 6.0), (2.0, 0.0)));
    PutV("c11.n2", g3.ShapleyExact()); Put("c11.n2.vN", g3.Value(new[] { 0, 1, 2 })); Put("c11.n2.v0", g3.Value(Array.Empty<int>()), 0);
    var back = ModalityCode.FromGlobal(SparseCode.FromDense(new[] { 0.1, 0.3, 0.0, 0.6 }), new[] { 2, 2 });
    PutC("c11.n3.rho", back.Mass, 1); PutC("c11.n3.p0", back.Conditionals[0], 2); PutC("c11.n3.p1", back.Conditionals[1], 0);
    Put("c11.n4", game.MarginalBound(1, 4));
    PutV("c11.n5", game.ShapleySampled(2000, 7), 3);
    var (rg, addr) = ReadGame.FromRead(rd, Vec.Of(1.0), 0.1, 0); PutV("c11.n6", rg.ShapleyExact()); Put("c11.n6.vN", rg.Value(new[] { 0, 1, 2 }));
}
// ---------------- C12 certificates
{
    var eps = new[] { 0.01, 0.03, 0.02, 0.005 }; var lip = new[] { 1.0, 1.4, 0.8, 1.1 };
    Put("c12.w1", Certificates.LayerwiseError(eps, lip), 5); Put("c12.w1.t1", 0.01 * 1.4 * 0.8 * 1.1, 5); Put("c12.w1.t2", 0.03 * 0.8 * 1.1, 4); Put("c12.w1.t3", 0.02 * 1.1, 3);
    var logits = new[] { 2.1, 1.7, 0.3, -1.0 };
    PutS("c12.w2.a", Certificates.GreedyTokenIsPreserved(logits, 0.05).ToString()); PutS("c12.w2.b", Certificates.GreedyTokenIsPreserved(logits, 0.25).ToString());
    Put("c12.w2.tv", Certificates.NextTokenTotalVariation(0.05)); Put("c12.w2.tv2", Certificates.NextTokenTotalVariation(0.25));
    Put("c12.n1", Certificates.ReweightingTotalVariation(1.2));
    Put("c12.n2", Certificates.SoftmaxReadPerturbation(2, 3, 1.5, 0.05, 0.1, 0.02, 64));
    Put("c12.n3", Certificates.RecurrentError(0.01, 0.9, 20)); Put("c12.n3.inf", 0.01 / 0.1, 1);
    Put("c12.n4", Certificates.ReadDriftBound(0.02, 0.01, 2, 3));
    Put("c12.n5", Certificates.InterferenceBound(1, 0.25), 1);
    Put("c12.n6", Certificates.NormalizedReadBound(2, Certificates.ConversionSpread(1.5, 0.1, 1, 1)), 4); Put("c12.n6.spread", Certificates.ConversionSpread(1.5, 0.1, 1, 1), 3);
    var dict = new AtomDictionary(D.Atoms, "toy-v1"); var res = new Resolution(4, 2, 15, 4);
    var rec = new CodeRecord(C(4, (0, 0.5), (1, 0.3), (3, 0.2)), "toy-v0", 1, "text", ImmutableArray<string>.Empty);
    var v = StateContract.Check(rec, dict, res); Put("c12.n7", v.Length, 0); PutS("c12.n7.list", string.Join(" | ", v));
    Put("c12.n8", Certificates.OmittedResponseBound(3, 1), 2);
}
// ---------------- C13 diffusion
{
    var h = VocabularyHierarchy.Uniform(2, 2); var prior = Vec.Of(0.4, 0.1, 0.3, 0.2);
    PutC("c13.w1.r1", h.ResolutionCode(prior, 1, 0), 1); Put("c13.w1.tv", Codes.TotalVariation(SparseCode.OneHot(4, 0), h.ResolutionCode(prior, 1, 0)), 1);
    PutC("c13.w1.r1b", h.ResolutionCode(prior, 1, 3), 1); PutC("c13.w1.root", h.ResolutionCode(prior, 2, 0), 1);
    var d4 = new AtomDictionary(D.Atoms, "toy"); PutV("c13.w1.atom", h.CoarseDictionary(d4, prior, 1).Atom(0), 1);
    var parity = SequenceLaw.FromWeights(4, 3, x => Enumerable.Range(0, 3).All(i => x[i] % 2 == Enumerable.Range(0, 3).Where(j => j != i).Sum(j => x[j] / 2) % 2) ? 1 : 0);
    Put("c13.w2.count", parity.Atoms.Length, 0);
    Put("c13.w2.tc", ResolutionDiffusion.TotalCorrelation(parity, h)); Put("c13.w2.ls", ResolutionDiffusion.FactorisationGap(parity, h, ResolutionSchedule.LevelSynchronous(3, 2)));
    double best = (from a in new[] { 1, 2 } from b in new[] { 1, 2 } from c in new[] { 1, 2 } select ResolutionDiffusion.FactorisationGap(parity, h, ResolutionSchedule.Masked(new[] { a, b, c }, 2))).Min();
    Put("c13.w2.masked", best); Put("c13.w2.ln2", Math.Log(2)); Put("c13.w2.cri", ResolutionDiffusion.CrossResolutionInformation(parity, h));
    Put("c13.w2.m122", ResolutionDiffusion.FactorisationGap(parity, h, ResolutionSchedule.Masked(new[] { 1, 2, 2 }, 2)));
    var copy = SequenceLaw.FromWeights(4, 3, x => x[0] == x[1] && x[1] == x[2] ? prior[x[0]] : 0);
    Put("c13.n1.tc", ResolutionDiffusion.TotalCorrelation(copy, h)); Put("c13.n1.ls", ResolutionDiffusion.FactorisationGap(copy, h, ResolutionSchedule.LevelSynchronous(3, 2)));
    Put("c13.n1.cri", ResolutionDiffusion.CrossResolutionInformation(copy, h)); Put("c13.n1.m", ResolutionDiffusion.FactorisationGap(copy, h, ResolutionSchedule.Masked(new[] { 1, 2, 2 }, 2)));
    Put("c13.n2", ResolutionDiffusion.CellSamplerBound(32, 255)); Put("c13.n2.mask", Math.Min(1, 32768 / 510.0), 0); Put("c13.n2.total", 3 * 32 / 510.0);
    Put("c13.n3", Codes.TotalVariation(SparseCode.OneHot(4, 1), h.ResolutionCode(prior, 1, 1)), 1);
    var indep = SequenceLaw.FromWeights(4, 2, x => prior[x[0]] * prior[x[1]]);
    Put("c13.n4", ResolutionDiffusion.FactorisationGap(indep, h, ResolutionSchedule.Masked(new[] { 1, 1 }, 2)), 4);
    PutS("c13.n5", string.Join(" → ", Enumerable.Range(0, 3).Select(t => "(" + string.Join(",", ResolutionSchedule.Create(new[] { new[] { 1, 1 }, new[] { 1, 2 }, new[] { 2, 2 } }).Levels(t)) + ")")));
    Put("c13.n6", ResolutionDiffusion.ViewEntropy(parity, h, new[] { 1, 1, 1 }));
}
// ---------------- C14 library
{
    var dictionary = new AtomDictionary(Matrix.Random(16, 1000, 1), "demo-v1");
    var router = Matrix.Random(1000, 1000, 2);
    var code = CoefficientLayer.Route(router, Vec.Zero(1000), SparseCode.OneHot(1000, 42), 8);
    PutS("c14.w1.code", code.ToString());
    var q = Vocabuquantizer.Quantize(code, 4, 255);
    PutS("c14.w1.q", $"{q.Quantized.LayoutBits} bits; bound {F(q.TotalVariationBound)}; actual {F(Codes.TotalVariation(code, q.Quantized.Decode()))}");
    PutS("c14.n1", SparseCode.Uniform(6, new[] { 1, 4 }).ToString());
    Put("c14.n2", Codes.Mix(new[] { (1.0, SparseCode.OneHot(3, 0)), (3.0, SparseCode.OneHot(3, 2)) })[2], 2);
    Put("c14.n3", Transport.Identity(3).Then(Transport.Merge(new[] { 0, 0, 1 }, 2)).ContractionCoefficient(), 0);
    Put("c14.n4", CoefficientMemory.Empty(5, 2).Write(SparseCode.Uniform(5, new[] { 0, 1, 2 }), Vec.Of(1, 1), 3).Decay(0.5).TotalMass, 1);
    PutS("c14.n5", StateContract.CheckRaw(new[] { 0.5, 0.6 }).Length + " violation(s)");
}

File.WriteAllText(args.Length > 0 ? args[0] : "numbers.json", JsonSerializer.Serialize(N, new JsonSerializerOptions { WriteIndented = true, Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping }));
Console.WriteLine($"{N.Count} values written.");
