// Codes.cs — Vocabucapillary concept codes, bounded concept memory and a ridge-logistic learner.
using System.Collections.Immutable;

namespace Vocabucapillary.ConceptBottleneck;

/// <summary>A positive Vocabucapillary code: unit mass on at most s concept addresses.</summary>
public sealed record SimplexCode(ImmutableArray<double> Coefficients)
{
    public int Support => Coefficients.Count(x => x > 0);
    public double Mass => Coefficients.Sum();
}

public static class Coding
{
    /// <summary>
    /// Entropic coding with a hard support cap: keep the s largest scores and apply softmax on them.
    /// This is the exact minimiser of  -z'c/τ + Σ c log c  on the simplex face of the top-s addresses.
    /// </summary>
    public static SimplexCode TopSEntropic(IReadOnlyList<double> scores, int s, double tau)
    {
        var keep = scores.Select((z, j) => (z, j)).OrderByDescending(t => t.z).Take(s).ToImmutableArray();
        var w = V.Softmax(keep.Select(t => t.z / tau).ToImmutableArray());
        var c = Enumerable.Range(0, scores.Count)
                          .Select(j => keep.Select((t, k) => t.j == j ? w[k] : 0.0).Sum())
                          .ToImmutableArray();
        return new SimplexCode(c);
    }

    /// <summary>Scores of a feature vector against unit dictionary atoms (columns of D).</summary>
    public static ImmutableArray<double> Scores(IReadOnlyList<ImmutableArray<double>> atoms, IReadOnlyList<double> z) =>
        atoms.Select(a => V.Dot(a, z)).ToImmutableArray();
}

/// <summary>
/// Bounded concept memory over the P patch records of one image (KV Coefficient aggregation, Theorem 6 of
/// the cacheless paper with values = patch locations): m = Σ_i c_i / P and  S_j(i) = c_ij / P.
/// Centroids use the 2-D value v_i = (row, col): K_j = Σ_i c_ij v_i / Σ_i c_ij.
/// </summary>
public sealed record ConceptMemory(ImmutableArray<double> Mass, ImmutableArray<ImmutableArray<double>> Location,
                                   ImmutableArray<(double Row, double Col)> Centroid)
{
    public static ConceptMemory FromCodes(IReadOnlyList<SimplexCode> codes, int gridWidth)
    {
        int p = codes.Count, n = codes[0].Coefficients.Length;
        var loc = Enumerable.Range(0, n)
            .Select(j => codes.Select(c => c.Coefficients[j] / p).ToImmutableArray()).ToImmutableArray();
        var mass = loc.Select(row => row.Sum()).ToImmutableArray();
        var cen = Enumerable.Range(0, n).Select(j =>
        {
            double mj = loc[j].Sum();
            if (mj <= 0) return (double.NaN, double.NaN);
            double r = loc[j].Select((x, i) => x * (i / gridWidth)).Sum() / mj;
            double c = loc[j].Select((x, i) => x * (i % gridWidth)).Sum() / mj;
            return (r, c);
        }).ToImmutableArray();
        return new ConceptMemory(mass, loc, cen);
    }
}

/// <summary>Standardised ridge-logistic model. Logit = b + Σ_k w_k (x_k - μ_k)/σ_k.</summary>
public sealed record LogisticModel(double Bias, ImmutableArray<double> W, ImmutableArray<double> Mu, ImmutableArray<double> Sd)
{
    public double Logit(IReadOnlyList<double> x) => Bias + x.Select((v, k) => W[k] * (v - Mu[k]) / Sd[k]).Sum();
    public bool Predict(IReadOnlyList<double> x) => Logit(x) > 0;

    /// <summary>Effective raw-feature weight w_k/σ_k: logit is affine in x, so contributions decompose exactly.</summary>
    public double RawWeight(int k) => W[k] / Sd[k];

    /// <summary>
    /// Newton/IRLS fit. penalty[k] is the ridge strength on standardised coordinate k (bias unpenalised).
    /// A large penalty on off-home addresses implements the address-locking regulariser.
    /// </summary>
    public static LogisticModel Fit(IReadOnlyList<ImmutableArray<double>> x, IReadOnlyList<bool> y,
                                    IReadOnlyList<double> penalty, int iterations = 30)
    {
        int n = x.Count, p = x[0].Length;
        var mu = Enumerable.Range(0, p).Select(k => x.Average(r => r[k])).ToImmutableArray();
        var sd = Enumerable.Range(0, p).Select(k =>
        {
            double v = x.Average(r => (r[k] - mu[k]) * (r[k] - mu[k]));
            return Math.Sqrt(v) + 1e-9;
        }).ToImmutableArray();
        // design rows with leading 1 for the bias
        var z = x.Select(r => r.Select((v, k) => (v - mu[k]) / sd[k]).Prepend(1.0).ToImmutableArray()).ToImmutableArray();
        var lam = penalty.Prepend(1e-8).ToImmutableArray();

        var theta = Enumerable.Range(0, iterations).Aggregate(V.Zeros(p + 1), (th, _) =>
        {
            var pr = z.Select(r => V.Sigmoid(V.Dot(r, th))).ToImmutableArray();
            var grad = Enumerable.Range(0, p + 1)
                .Select(a => z.Select((r, i) => r[a] * ((y[i] ? 1.0 : 0.0) - pr[i])).Sum() - lam[a] * th[a])
                .ToImmutableArray();
            var hess = Enumerable.Range(0, p + 1).Select(a => Enumerable.Range(0, p + 1)
                .Select(b => z.Select((r, i) => r[a] * r[b] * pr[i] * (1 - pr[i])).Sum() + (a == b ? lam[a] : 0.0))
                .ToImmutableArray()).ToImmutableArray();
            return V.Add(th, V.Solve(hess, grad));
        });
        return new LogisticModel(theta[0], theta.Skip(1).ToImmutableArray(), mu, sd);
    }
}
