// Program.cs — runs the four studies and writes CSV results (all computation in immutable C#).
using System.Collections.Immutable;
using System.Diagnostics;
using Vocabucapillary.ConceptBottleneck;

var root = new Rng(20261108UL);
var outDir = args.Length > 0 ? args[0] : "results";
Directory.CreateDirectory(outDir);
var sw = Stopwatch.StartNew();

// E1 — pooling erases localisation
var pool = PoolingExperiment.Run(root.Fork(1));
Csv.Write(Path.Combine(outDir, "e1_pooling.csv"), [pool]);
Console.WriteLine($"E1 pairs={pool.Pairs} max|Δpooled z|={pool.MaxPooledFeatureDiff:E2} max|Δm|={pool.MaxPooledMassDiff:E2} " +
                  $"mean L1 ΔS={pool.MeanLocationL1Change:F3} mean head::gray centroid shift={pool.MeanHeadGrayCentroidShift:F3}");
Console.WriteLine("   native centroid rows: " + string.Join(", ", pool.NativeCentroidRow.Select((r, j) => $"{WorldSpec.Names[j]}={r:F2}")));

// E2 — spurious shortcut, trustworthiness, address locking
var trust = TrustExperiment.Run(root.Fork(2), rhos: [0.5, 0.8, 0.95], headAmps: [0.35, 0.6, 1.0], lambdas: [0, 10, 100, 1000]);
Csv.Write(Path.Combine(outDir, "e2_trust.csv"), trust);
Console.WriteLine($"E2 rows={trust.Length}  ({sw.Elapsed.TotalSeconds:F0}s)");
foreach (var g in trust.Where(r => r.Concept <= 1).GroupBy(r => (r.HeadAmp, r.Rho, r.Model, r.Lambda)))
    Console.WriteLine($"   amp={g.Key.HeadAmp} rho={g.Key.Rho} {g.Key.Model,-17} λ={g.Key.Lambda,5}  accIn={g.Average(r => r.AccIn):F3} accShift={g.Average(r => r.AccShift):F3} " +
                      $"trust={g.Average(r => r.Trust):F3} dropSurv={g.Average(r => r.DropSurvival):F3} leak={g.Average(r => r.Leakage):F3}");

// E3 — V2C-form class codes
var head = ClassCodeExperiment.MakeHead(root.Fork(3), classes: 50, concepts: 500, ownPerClass: 10);
var (a, y) = ClassCodeExperiment.Samples(head, root.Fork(4), 2000, 500);
ImmutableArray<int> supports = [5, 10, 20, 50, 100, 200, 300, 400];
var prune = ClassCodeExperiment.Prune(head, a, y, supports);
Csv.Write(Path.Combine(outDir, "e3_prune.csv"), prune);
foreach (var p in prune) Console.WriteLine($"E3 boost5 {p}");
var headSharp = ClassCodeExperiment.MakeHead(root.Fork(3), classes: 50, concepts: 500, ownPerClass: 10, ownBoost: 7.0);
var pruneSharp = ClassCodeExperiment.Prune(headSharp, a, y, supports);
Csv.Write(Path.Combine(outDir, "e3_prune_sharp.csv"), pruneSharp);
foreach (var p in pruneSharp) Console.WriteLine($"E3 boost7 {p}");
var tcav = ClassCodeExperiment.Tcav(head, a, y, logitScale: 100);
Csv.Write(Path.Combine(outDir, "e3_tcav.csv"), [tcav]);
Console.WriteLine($"E3 {tcav}");

// E4 — duplicate concepts
var dup = DuplicateExperiment.Run(root.Fork(5), [0.8, 0.4, 0.2, 0.1, 0.05, 0.02]);
Csv.Write(Path.Combine(outDir, "e4_duplicates.csv"), dup);
foreach (var d in dup) Console.WriteLine($"E4 {d}");
// export one duplicate dictionary for an independent NumPy cross-check of κ
var exportAtoms = DuplicateExperiment.Atoms(root.Fork(5), 0.1);
File.WriteAllLines(Path.Combine(outDir, "e4_atoms_delta0.1.csv"), exportAtoms.Select(r => string.Join(",", r.Select(Csv.F))));
Console.WriteLine($"κ2={DuplicateExperiment.Kappa2(exportAtoms):R} κ4={DuplicateExperiment.Kappa4(exportAtoms):R}");
Console.WriteLine($"done in {sw.Elapsed.TotalSeconds:F1}s");
