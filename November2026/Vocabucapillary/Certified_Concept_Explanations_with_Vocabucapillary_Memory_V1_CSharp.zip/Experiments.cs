// Experiments.cs — four numerical studies supporting the Vocabucapillary concept-bottleneck paper.
using System.Collections.Immutable;
using System.Globalization;

namespace Vocabucapillary.ConceptBottleneck;

// ───────────────────────────── Synthetic part-structured world (CUB-like) ─────────────────────────────
// Addresses: 0 head::gray 1 head::black 2 wing::grey 3 wing::brown 4 belly::white 5 belly::pattern 6 background
public sealed record WorldSpec(int Grid, int Dim, double HeadAmplitude, double Noise, double Occupancy,
                               ImmutableArray<ImmutableArray<double>> Atoms)
{
    public const int Concepts = 6, Background = 6, Addresses = 7;
    public int Patches => Grid * Grid;
    public int RegionOfPatch(int i) => (i / Grid) * 3 / Grid;         // 0 head, 1 wing, 2 belly
    public static int HomeRegion(int address) => address / 2;           // background → 3 (no region)
    public static readonly ImmutableArray<string> Names =
        ["head::gray", "head::black", "wing::grey", "wing::brown", "belly::white", "belly::pattern", "background"];

    public static WorldSpec Create(Rng rng, double headAmplitude, int grid = 6, int dim = 16, double noise = 0.6, double occupancy = 0.75)
    {
        var atoms = Enumerable.Range(0, Addresses).Select(j => V.Normalize(rng.Fork(100 + (ulong)j).Gaussians(dim).Values))
                              .ToImmutableArray();
        return new WorldSpec(grid, dim, headAmplitude, noise, occupancy, atoms);
    }
}

public sealed record Img(ImmutableArray<ImmutableArray<double>> Patches, ImmutableArray<int> Source, ImmutableArray<bool> Labels);

public static class World
{
    static (ImmutableArray<double> Z, Rng R) Emit(WorldSpec w, int address, Rng r)
    {
        double amp = address is 0 or 1 ? w.HeadAmplitude : 1.0;
        var (eps, r1) = r.Gaussians(w.Dim);
        return (V.Add(V.Scale(w.Atoms[address], amp), V.Scale(eps, w.Noise)), r1);
    }

    /// <summary>Head attribute uniform; belly is white with probability rho when head is gray (else 1-rho).</summary>
    public static (Img Image, Rng Next) Sample(WorldSpec w, double rho, Rng r0)
    {
        var (u1, r1) = r0.NextDouble(); int head = u1 < 0.5 ? 0 : 1;
        var (u2, r2) = r1.NextDouble(); int wing = u2 < 0.5 ? 2 : 3;
        var (u3, r3) = r2.NextDouble();
        double pWhite = head == 0 ? rho : 1 - rho;
        int belly = u3 < pWhite ? 4 : 5;
        var attr = ImmutableArray.Create(head, wing, belly);
        var patches = ImmutableArray.CreateBuilder<ImmutableArray<double>>(w.Patches);
        var source = ImmutableArray.CreateBuilder<int>(w.Patches);
        var r = r3;
        for (int i = 0; i < w.Patches; i++)
        {
            var (u, rr) = r.NextDouble();
            int a = u < w.Occupancy ? attr[w.RegionOfPatch(i)] : WorldSpec.Background;
            var (z, rz) = Emit(w, a, rr);
            patches.Add(z); source.Add(a); r = rz;
        }
        var labels = Enumerable.Range(0, WorldSpec.Concepts).Select(j => attr.Contains(j)).ToImmutableArray();
        return (new Img(patches.MoveToImmutable(), source.MoveToImmutable(), labels), r);
    }

    public static ImmutableArray<Img> Dataset(WorldSpec w, double rho, int n, Rng r) =>
        Enumerable.Range(0, n).Aggregate((List: ImmutableList<Img>.Empty, R: r), (acc, _) =>
        {
            var (img, nr) = Sample(w, rho, acc.R);
            return (acc.List.Add(img), nr);
        }).List.ToImmutableArray();

    /// <summary>Patch-drop intervention: every patch of a region is re-emitted as background.</summary>
    public static Img DropRegion(WorldSpec w, Img x, int region, Rng r0)
    {
        var acc = Enumerable.Range(0, w.Patches).Aggregate((P: ImmutableList<ImmutableArray<double>>.Empty, R: r0), (s, i) =>
        {
            if (w.RegionOfPatch(i) != region) return (s.P.Add(x.Patches[i]), s.R);
            var (z, nr) = Emit(w, WorldSpec.Background, s.R);
            return (s.P.Add(z), nr);
        });
        return x with { Patches = acc.P.ToImmutableArray() };
    }

    public static ImmutableArray<SimplexCode> Codes(WorldSpec w, Img x, int s, double tau) =>
        x.Patches.Select(z => Coding.TopSEntropic(Coding.Scores(w.Atoms, z), s, tau)).ToImmutableArray();
}

// ───────────────────────────── Concept predictors under comparison ─────────────────────────────
public enum Kind { PooledCbm, VcAddressLocked, VcLearnedReadout }

public sealed record ConceptPredictor(Kind Kind, int Concept, LogisticModel Model)
{
    public ImmutableArray<double> Features(WorldSpec w, Img x, ConceptMemory mem) => Kind switch
    {
        Kind.PooledCbm => V.Mean(x.Patches),
        Kind.VcAddressLocked => [mem.Mass[Concept]],
        _ => mem.Mass,
    };

    /// <summary>Exact per-patch logit contribution (the logit is affine in each feature family).</summary>
    public ImmutableArray<double> PatchContributions(WorldSpec w, Img x, IReadOnlyList<SimplexCode> codes) => Kind switch
    {
        Kind.PooledCbm => x.Patches.Select(z => z.Select((v, k) => Model.RawWeight(k) * v).Sum() / w.Patches).ToImmutableArray(),
        Kind.VcAddressLocked => codes.Select(c => Model.RawWeight(0) * c.Coefficients[Concept] / w.Patches).ToImmutableArray(),
        _ => codes.Select(c => c.Coefficients.Select((v, k) => Model.RawWeight(k) * v).Sum() / w.Patches).ToImmutableArray(),
    };

    /// <summary>Address-level decomposition (Vocabucapillary learned readout only): share from off-region addresses.</summary>
    public double Leakage(ConceptMemory mem)
    {
        if (Kind != Kind.VcLearnedReadout) return double.NaN;
        int home = WorldSpec.HomeRegion(Concept);
        var parts = mem.Mass.Select((m, k) => Math.Abs(Model.RawWeight(k) * m)).ToImmutableArray();
        double off = parts.Where((_, k) => WorldSpec.HomeRegion(k) != home).Sum();
        return off / Math.Max(parts.Sum(), 1e-300);
    }
}

public sealed record TrustRow(string Model, double Rho, double HeadAmp, double Lambda, int Concept,
                              double AccIn, double AccShift, double Trust, double DropSurvival, double Leakage);

public static class TrustExperiment
{
    const int CodeSupport = 2; const double Tau = 0.25;

    sealed record Prepared(Img Image, ImmutableArray<SimplexCode> Codes, ConceptMemory Memory);

    static ImmutableArray<Prepared> Prepare(WorldSpec w, IEnumerable<Img> xs) =>
        xs.Select(x => { var c = World.Codes(w, x, CodeSupport, Tau); return new Prepared(x, c, ConceptMemory.FromCodes(c, w.Grid)); })
          .ToImmutableArray();

    static ConceptPredictor Train(WorldSpec w, Kind kind, int concept, ImmutableArray<Prepared> train, double lambda)
    {
        var shell = new ConceptPredictor(kind, concept, null!);
        var x = train.Select(p => shell.Features(w, p.Image, p.Memory)).ToImmutableArray();
        var y = train.Select(p => p.Image.Labels[concept]).ToImmutableArray();
        int home = WorldSpec.HomeRegion(concept);
        var pen = Enumerable.Range(0, x[0].Length)
            .Select(k => kind == Kind.VcLearnedReadout && WorldSpec.HomeRegion(k) != home ? 1.0 + lambda : 1.0)
            .ToImmutableArray();
        return shell with { Model = LogisticModel.Fit(x, y, pen) };
    }

    static TrustRow Evaluate(WorldSpec w, ConceptPredictor f, double rho, double lambda,
                             ImmutableArray<Prepared> testIn, ImmutableArray<Prepared> testShift, Rng dropRng)
    {
        int j = f.Concept, home = WorldSpec.HomeRegion(j);
        double Acc(ImmutableArray<Prepared> t) => t.Average(p => f.Model.Predict(f.Features(w, p.Image, p.Memory)) == p.Image.Labels[j] ? 1.0 : 0.0);

        var hits = testIn.Where(p => p.Image.Labels[j] && f.Model.Predict(f.Features(w, p.Image, p.Memory))).ToImmutableArray();
        double trust = hits.Average(p =>
        {
            var contrib = f.PatchContributions(w, p.Image, p.Codes);
            int arg = Enumerable.Range(0, contrib.Length).MaxBy(i => contrib[i]);
            return w.RegionOfPatch(arg) == home ? 1.0 : 0.0;
        });
        var positives = testIn.Where(p => p.Image.Labels[j]).ToImmutableArray();
        double survival = positives.Select((p, k) =>
        {
            var dropped = World.DropRegion(w, p.Image, home, dropRng.Fork((ulong)k));
            var codes = World.Codes(w, dropped, CodeSupport, Tau);
            var mem = ConceptMemory.FromCodes(codes, w.Grid);
            return f.Model.Predict(f.Features(w, dropped, mem)) ? 1.0 : 0.0;
        }).Average();
        double leak = f.Kind == Kind.VcLearnedReadout ? hits.Average(p => f.Leakage(p.Memory)) : double.NaN;
        return new TrustRow(f.Kind.ToString(), rho, w.HeadAmplitude, lambda, j, Acc(testIn), Acc(testShift), trust, survival, leak);
    }

    public static ImmutableArray<TrustRow> Run(Rng root, IReadOnlyList<double> rhos, IReadOnlyList<double> headAmps,
                                               IReadOnlyList<double> lambdas, int nTrain = 2000, int nTest = 2000)
    {
        var rows = ImmutableList.CreateBuilder<TrustRow>();
        foreach (var amp in headAmps)
        {
            var w = WorldSpec.Create(root.Fork(7), amp);
            var shift = Prepare(w, World.Dataset(w, 0.5, nTest, root.Fork(31)));
            foreach (var rho in rhos)
            {
                var train = Prepare(w, World.Dataset(w, rho, nTrain, root.Fork(11 + (ulong)(rho * 1000))));
                var testIn = Prepare(w, World.Dataset(w, rho, nTest, root.Fork(23 + (ulong)(rho * 1000))));
                for (int j = 0; j < WorldSpec.Concepts; j++)
                {
                    var dropRng = root.Fork(5000 + (ulong)j);
                    rows.Add(Evaluate(w, Train(w, Kind.PooledCbm, j, train, 0), rho, 0, testIn, shift, dropRng));
                    rows.Add(Evaluate(w, Train(w, Kind.VcAddressLocked, j, train, 0), rho, 0, testIn, shift, dropRng));
                    foreach (var lam in lambdas)
                        rows.Add(Evaluate(w, Train(w, Kind.VcLearnedReadout, j, train, lam), rho, lam, testIn, shift, dropRng));
                }
            }
        }
        return rows.ToImmutableArray();
    }
}

// ───────────────────────────── E1: pooling erases localisation ─────────────────────────────
public sealed record PoolingRow(int Pairs, double MaxPooledFeatureDiff, double MaxPooledMassDiff,
                                double MeanLocationL1Change, double MeanHeadGrayCentroidShift,
                                ImmutableArray<double> NativeCentroidRow);

public static class PoolingExperiment
{
    public static PoolingRow Run(Rng root, int pairs = 300)
    {
        var w = WorldSpec.Create(root.Fork(7), 0.6);
        var xs = World.Dataset(w, 0.8, pairs, root.Fork(41));
        var res = xs.Select((x, k) =>
        {
            var (perm, _) = root.Fork(900 + (ulong)k).Permutation(w.Patches);
            var y = x with { Patches = perm.Select(i => x.Patches[i]).ToImmutableArray(), Source = perm.Select(i => x.Source[i]).ToImmutableArray() };
            var cx = World.Codes(w, x, 2, 0.25); var cy = World.Codes(w, y, 2, 0.25);
            var mx = ConceptMemory.FromCodes(cx, w.Grid); var my = ConceptMemory.FromCodes(cy, w.Grid);
            double dz = V.Sub(V.Mean(x.Patches), V.Mean(y.Patches)).Max(Math.Abs);
            double dm = V.Sub(mx.Mass, my.Mass).Max(Math.Abs);
            double dS = Enumerable.Range(0, WorldSpec.Addresses).Sum(j => V.Sub(mx.Location[j], my.Location[j]).Sum(Math.Abs));
            double shift = Math.Abs(mx.Centroid[0].Row - my.Centroid[0].Row) + Math.Abs(mx.Centroid[0].Col - my.Centroid[0].Col);
            return (dz, dm, dS, shift, mem: mx);
        }).ToImmutableArray();
        var cen = Enumerable.Range(0, WorldSpec.Addresses).Select(j =>
            res.Where((r, k) => j == WorldSpec.Background || xs[k].Labels[j]).Average(r => r.mem.Centroid[j].Row)).ToImmutableArray();
        return new PoolingRow(pairs, res.Max(r => r.dz), res.Max(r => r.dm), res.Average(r => r.dS),
                              res.Where(r => !double.IsNaN(r.shift)).Average(r => r.shift), cen);
    }
}

// ───────────────────────────── E3: V2C-form class codes — pruning certificate & TCAV degeneracy ─────────────────────────────
public sealed record PruneRow(int Support, double MeanEta, double MaxEta, double MaxRatioToBound, double MaxIdentityError,
                              double CertifiedFraction, double AgreementFraction, double AccFull, double AccPruned);
public sealed record TcavRow(double RawPositiveFraction, double ProbOwnAbove50, double ProbOtherAbove50, double MeanSignedOwn, double MeanSignedOther);

public static class ClassCodeExperiment
{
    public sealed record Head(ImmutableArray<ImmutableArray<double>> Sigma, ImmutableArray<ImmutableArray<int>> Own);

    public static Head MakeHead(Rng r, int classes, int concepts, int ownPerClass, double ownBoost = 5.0)
    {
        var own = Enumerable.Range(0, classes).Select(k => Enumerable.Range(0, ownPerClass).Select(t => k * ownPerClass + t).ToImmutableArray()).ToImmutableArray();
        var sigma = Enumerable.Range(0, classes).Select(k =>
        {
            var (g, _) = r.Fork(300 + (ulong)k).Gaussians(concepts);
            var logits = g.Select((x, j) => 0.5 * x + (own[k].Contains(j) ? ownBoost : 0.0)).ToImmutableArray();
            return V.Softmax(logits);
        }).ToImmutableArray();
        return new Head(sigma, own);
    }

    public static (ImmutableArray<ImmutableArray<double>> A, ImmutableArray<int> Y) Samples(Head h, Rng r, int n, int concepts)
    {
        int k = h.Sigma.Length;
        var list = Enumerable.Range(0, n).Select(i =>
        {
            var ri = r.Fork(10_000 + (ulong)i);
            var (cls, r1) = ri.NextInt(k);
            var (g, r2) = r1.Gaussians(concepts);
            var (u, _) = r2.Gaussians(concepts);
            var a = Enumerable.Range(0, concepts)
                .Select(j => 0.20 + 0.03 * u[j] + 0.02 * g[j] + (h.Own[cls].Contains(j) ? 0.08 : 0.0)).ToImmutableArray();
            return (a, cls);
        }).ToImmutableArray();
        return (list.Select(t => t.a).ToImmutableArray(), list.Select(t => t.cls).ToImmutableArray());
    }

    public static ImmutableArray<double> Scores(IReadOnlyList<ImmutableArray<double>> sigma, IReadOnlyList<double> a) =>
        sigma.Select(row => V.Dot(row, a)).ToImmutableArray();

    /// <summary>Keep the s largest coefficients, renormalise; returns code and discarded mass η.</summary>
    public static (ImmutableArray<double> Code, double Eta) Prune(IReadOnlyList<double> c, int s)
    {
        var keep = c.Select((x, j) => (x, j)).OrderByDescending(t => t.x).Take(s).Select(t => t.j).ToImmutableHashSet();
        double kept = keep.Sum(j => c[j]);
        return (c.Select((x, j) => keep.Contains(j) ? x / kept : 0.0).ToImmutableArray(), 1 - kept);
    }

    public static ImmutableArray<PruneRow> Prune(Head h, ImmutableArray<ImmutableArray<double>> a, ImmutableArray<int> y, IReadOnlyList<int> supports)
    {
        var full = a.Select(x => Scores(h.Sigma, x)).ToImmutableArray();
        return supports.Select(s =>
        {
            var pr = h.Sigma.Select(c => Prune(c, s)).ToImmutableArray();
            var codes = pr.Select(p => p.Code).ToImmutableArray();
            var eta = pr.Select(p => p.Eta).ToImmutableArray();
            var per = a.Select((x, i) =>
            {
                var yt = Scores(codes, x);
                double range = x.Max() - x.Min();
                var dif = full[i].Select((v, k) => v - yt[k]).ToImmutableArray();
                double ratio = dif.Select((d, k) => eta[k] > 0 ? Math.Abs(d) / (eta[k] * range) : 0.0).Max();
                // exact identity: ŷ_k − ỹ_k = η_k (ā_D − ā_R)
                double idErr = Enumerable.Range(0, h.Sigma.Length).Max(k =>
                {
                    if (eta[k] <= 0) return Math.Abs(dif[k]);
                    double aD = h.Sigma[k].Select((c, j) => codes[k][j] == 0 ? c * x[j] : 0.0).Sum() / eta[k];
                    return Math.Abs(dif[k] - eta[k] * (aD - yt[k]));
                });
                // Operational certificate: uses only the pruned scores ỹ, the discarded masses η and min/max of A(x).
                // ŷ_k = (1-η_k) ỹ_k + η_k ā_D  with  ā_D ∈ [min A, max A].
                double lo(int k) => (1 - eta[k]) * yt[k] + eta[k] * x.Min();
                double hi(int k) => (1 - eta[k]) * yt[k] + eta[k] * x.Max();
                int top = Enumerable.Range(0, full[i].Length).MaxBy(k => full[i][k]);
                int topP = Enumerable.Range(0, yt.Length).MaxBy(k => yt[k]);
                bool cert = Enumerable.Range(0, yt.Length).Where(k => k != topP).All(k => lo(topP) > hi(k));
                return (ratio, idErr, cert, agree: top == topP, accF: top == y[i], accP: topP == y[i]);
            }).ToImmutableArray();
            return new PruneRow(s, eta.Average(), eta.Max(), per.Max(p => p.ratio), per.Max(p => p.idErr),
                per.Average(p => p.cert ? 1.0 : 0.0), per.Average(p => p.agree ? 1.0 : 0.0),
                per.Average(p => p.accF ? 1.0 : 0.0), per.Average(p => p.accP ? 1.0 : 0.0));
        }).ToImmutableArray();
    }

    /// <summary>TCAV-style sign fractions for raw class scores vs the softmax class probability.</summary>
    public static TcavRow Tcav(Head h, ImmutableArray<ImmutableArray<double>> a, ImmutableArray<int> y, double logitScale)
    {
        int k = h.Sigma.Length, n = h.Sigma[0].Length;
        var probs = a.Select(x => V.Softmax(Scores(h.Sigma, x).Select(v => v * logitScale).ToImmutableArray())).ToImmutableArray();
        // ∂ŷ_k/∂A_j = σ_kj (>0 always);  ∂p_k/∂A_j = s p_k (σ_kj − Σ_l p_l σ_lj)
        double rawPos = h.Sigma.SelectMany(r => r).Average(v => v > 0 ? 1.0 : 0.0);
        var tc = Enumerable.Range(0, k).SelectMany(c =>
        {
            var idx = Enumerable.Range(0, a.Length).Where(i => y[i] == c).ToImmutableArray();
            return Enumerable.Range(0, n).Select(j =>
            {
                var d = idx.Select(i => logitScale * probs[i][c] * (h.Sigma[c][j] - Enumerable.Range(0, k).Sum(l => probs[i][l] * h.Sigma[l][j]))).ToImmutableArray();
                return (own: h.Own[c].Contains(j), frac: d.Average(v => v > 0 ? 1.0 : 0.0), mean: d.Average());
            });
        }).ToImmutableArray();
        return new TcavRow(rawPos,
            tc.Where(t => t.own).Average(t => t.frac > 0.5 ? 1.0 : 0.0), tc.Where(t => !t.own).Average(t => t.frac > 0.5 ? 1.0 : 0.0),
            tc.Where(t => t.own).Average(t => t.mean), tc.Where(t => !t.own).Average(t => t.mean));
    }
}

// ───────────────────────────── E4: duplicate concepts — identifiability, tokenizer flips, merging ─────────────────────────────
public sealed record DuplicateRow(double Delta, double AtomGap, double Kappa2, double Kappa4, double Kappa4Merged,
                                  double TokenizerFlipRate, double PredictedFlipRate, double MergedFlipRate);

public static class DuplicateExperiment
{
    static readonly ImmutableArray<ImmutableArray<double>> ZeroSumBasis4 =
    [
        V.Normalize([1, -1, 0, 0]),
        V.Normalize([1, 1, -2, 0]),
        V.Normalize([1, 1, 1, -3]),
    ];

    /// <summary>κ_2s(D) for 2s = 4: min over 4-subsets of the smallest singular value on the zero-sum subspace.</summary>
    public static double Kappa4(IReadOnlyList<ImmutableArray<double>> atoms)
    {
        int n = atoms.Count;
        var quads = from a in Enumerable.Range(0, n) from b in Enumerable.Range(a + 1, n - a - 1)
                    from c in Enumerable.Range(b + 1, n - b - 1) from d in Enumerable.Range(c + 1, n - c - 1)
                    select ImmutableArray.Create(a, b, c, d);
        return quads.Min(q =>
        {
            var cols = ZeroSumBasis4.Select(z => Enumerable.Range(0, atoms[0].Length)
                .Select(r => Enumerable.Range(0, 4).Sum(t => atoms[q[t]][r] * z[t])).ToImmutableArray()).ToImmutableArray();
            double g(int i, int j) => V.Dot(cols[i], cols[j]);
            return Math.Sqrt(Math.Max(0, V.MinEig3(g(0, 0), g(1, 1), g(2, 2), g(0, 1), g(0, 2), g(1, 2))));
        });
    }

    public static double Kappa2(IReadOnlyList<ImmutableArray<double>> atoms) =>
        (from i in Enumerable.Range(0, atoms.Count) from j in Enumerable.Range(i + 1, atoms.Count - i - 1)
         select V.Norm(V.Sub(atoms[i], atoms[j])) / Math.Sqrt(2)).Min();

    public static ImmutableArray<ImmutableArray<double>> Atoms(Rng root, double delta, int baseAtoms = 30, int dim = 24)
    {
        var baseD = Enumerable.Range(0, baseAtoms).Select(j => V.Normalize(root.Fork(700 + (ulong)j).Gaussians(dim).Values)).ToImmutableArray();
        var xi = V.Normalize(root.Fork(999).Gaussians(dim).Values);
        return baseD.Add(V.Normalize(V.Add(baseD[0], V.Scale(xi, delta))));
    }

    public static ImmutableArray<DuplicateRow> Run(Rng root, IReadOnlyList<double> deltas, int baseAtoms = 30, int dim = 24,
                                                   double obsNoise = 0.05, int trials = 4000)
    {
        var baseD = Enumerable.Range(0, baseAtoms).Select(j => V.Normalize(root.Fork(700 + (ulong)j).Gaussians(dim).Values)).ToImmutableArray();
        double k4Merged = Kappa4(baseD);
        return deltas.Select(delta =>
        {
            var xi = V.Normalize(root.Fork(999).Gaussians(dim).Values);
            var dup = V.Normalize(V.Add(baseD[0], V.Scale(xi, delta)));
            var atoms = baseD.Add(dup);
            // V2C/ACE-style hard tokenizer: nearest atom in Euclidean distance; target = atom 0 + noise
            var flips = Enumerable.Range(0, trials).Select(t =>
            {
                var (e, _) = root.Fork(20_000 + (ulong)t).Gaussians(dim);
                var h = V.Add(baseD[0], V.Scale(e, obsNoise));
                int tok = Enumerable.Range(0, atoms.Length).MinBy(j => V.Norm(V.Sub(h, atoms[j])));
                int tokMerged = Enumerable.Range(0, baseD.Length).MinBy(j => V.Norm(V.Sub(h, baseD[j])));
                return (dup: tok == baseAtoms ? 1.0 : 0.0, merged: tokMerged != 0 ? 1.0 : 0.0);
            }).ToImmutableArray();
            return new DuplicateRow(delta, V.Norm(V.Sub(baseD[0], dup)), Kappa2(atoms), Kappa4(atoms), k4Merged,
                                    flips.Average(f => f.dup), V.GaussianTail(V.Norm(V.Sub(baseD[0], dup)) / (2 * obsNoise)), flips.Average(f => f.merged));
        }).ToImmutableArray();
    }
}

public static class Csv
{
    static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
    public static string F(double x) => double.IsNaN(x) ? "" : x.ToString("G10", Inv);
    public static void Write<T>(string path, IEnumerable<T> rows)
    {
        var props = typeof(T).GetProperties();
        var lines = rows.Select(r => string.Join(",", props.Select(p => p.GetValue(r) switch
        {
            double d => F(d),
            ImmutableArray<double> a => string.Join(";", a.Select(F)),
            var o => Convert.ToString(o, Inv) ?? "",
        })));
        File.WriteAllLines(path, lines.Prepend(string.Join(",", props.Select(p => p.Name))));
    }
}
