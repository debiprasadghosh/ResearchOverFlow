// Core.cs — immutable numerical primitives for the Vocabucapillary concept-bottleneck study.
// Style: records, ImmutableArray / IReadOnlyList, pure static functions, no shared mutable state.
using System.Collections.Immutable;

namespace Vocabucapillary.ConceptBottleneck;

/// <summary>Pure SplitMix64 generator: every draw returns the value and the successor state.</summary>
public readonly record struct Rng(ulong State)
{
    public (ulong Value, Rng Next) NextUInt64()
    {
        ulong s = State + 0x9E3779B97F4A7C15UL;
        ulong z = s;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
        return (z ^ (z >> 31), new Rng(s));
    }

    public (double Value, Rng Next) NextDouble()
    {
        var (u, n) = NextUInt64();
        return ((u >> 11) * (1.0 / (1UL << 53)), n);
    }

    public (double Value, Rng Next) NextGaussian()
    {
        var (u1, r1) = NextDouble();
        var (u2, r2) = r1.NextDouble();
        double g = Math.Sqrt(-2.0 * Math.Log(Math.Max(u1, 1e-300))) * Math.Cos(2.0 * Math.PI * u2);
        return (g, r2);
    }

    public (int Value, Rng Next) NextInt(int exclusiveMax)
    {
        var (u, n) = NextDouble();
        return (Math.Min((int)(u * exclusiveMax), exclusiveMax - 1), n);
    }

    /// <summary>Independent stream derived from a label, so experiments never share a mutable source.</summary>
    public Rng Fork(ulong label) => new(State ^ (label * 0xD1B54A32D192ED03UL));

    public (ImmutableArray<double> Values, Rng Next) Gaussians(int n)
    {
        var b = ImmutableArray.CreateBuilder<double>(n);
        var r = this;
        for (int i = 0; i < n; i++) { var (g, nr) = r.NextGaussian(); b.Add(g); r = nr; }
        return (b.MoveToImmutable(), r);
    }

    public (ImmutableArray<int> Perm, Rng Next) Permutation(int n)
    {
        var a = Enumerable.Range(0, n).ToArray();      // local scratch, never escapes
        var r = this;
        for (int i = n - 1; i > 0; i--) { var (j, nr) = r.NextInt(i + 1); (a[i], a[j]) = (a[j], a[i]); r = nr; }
        return (a.ToImmutableArray(), r);
    }
}

/// <summary>Pure vector and small dense linear-algebra helpers.</summary>
public static class V
{
    public static double Dot(IReadOnlyList<double> a, IReadOnlyList<double> b)
    {
        double s = 0; for (int i = 0; i < a.Count; i++) s += a[i] * b[i]; return s;
    }
    public static double Norm(IReadOnlyList<double> a) => Math.Sqrt(Dot(a, a));
    public static ImmutableArray<double> Scale(IReadOnlyList<double> a, double k) => a.Select(x => x * k).ToImmutableArray();
    public static ImmutableArray<double> Add(IReadOnlyList<double> a, IReadOnlyList<double> b) => a.Select((x, i) => x + b[i]).ToImmutableArray();
    public static ImmutableArray<double> Sub(IReadOnlyList<double> a, IReadOnlyList<double> b) => a.Select((x, i) => x - b[i]).ToImmutableArray();
    public static ImmutableArray<double> Normalize(IReadOnlyList<double> a) => Scale(a, 1.0 / Norm(a));
    public static ImmutableArray<double> Zeros(int n) => ImmutableArray.CreateRange(Enumerable.Repeat(0.0, n));
    public static ImmutableArray<double> OneHot(int n, int k) => Enumerable.Range(0, n).Select(i => i == k ? 1.0 : 0.0).ToImmutableArray();

    public static ImmutableArray<double> Mean(IReadOnlyList<ImmutableArray<double>> rows) =>
        Enumerable.Range(0, rows[0].Length).Select(j => rows.Average(r => r[j])).ToImmutableArray();

    public static ImmutableArray<double> Softmax(IReadOnlyList<double> z)
    {
        double mx = z.Max();
        var e = z.Select(x => Math.Exp(x - mx)).ToImmutableArray();
        double s = e.Sum();
        return e.Select(x => x / s).ToImmutableArray();
    }

    public static double Sigmoid(double x) => x >= 0 ? 1.0 / (1.0 + Math.Exp(-x)) : Math.Exp(x) / (1.0 + Math.Exp(x));

    /// <summary>Solves A x = b by Gaussian elimination with partial pivoting on a private copy.</summary>
    public static ImmutableArray<double> Solve(IReadOnlyList<ImmutableArray<double>> a, IReadOnlyList<double> b)
    {
        int n = b.Count;
        var m = Enumerable.Range(0, n).Select(i => a[i].Append(b[i]).ToArray()).ToArray(); // private scratch
        for (int c = 0; c < n; c++)
        {
            int p = Enumerable.Range(c, n - c).MaxBy(r => Math.Abs(m[r][c]));
            (m[c], m[p]) = (m[p], m[c]);
            for (int r = c + 1; r < n; r++)
            {
                double f = m[r][c] / m[c][c];
                for (int k = c; k <= n; k++) m[r][k] -= f * m[c][k];
            }
        }
        var x = new double[n];
        for (int r = n - 1; r >= 0; r--)
        {
            double s = m[r][n];
            for (int k = r + 1; k < n; k++) s -= m[r][k] * x[k];
            x[r] = s / m[r][r];
        }
        return x.ToImmutableArray();
    }

    /// <summary>Upper Gaussian tail Q(x) = P(N(0,1) > x) via the Chebyshev erfc fit (|rel. error| &lt; 1.2e-7).</summary>
    public static double GaussianTail(double x)
    {
        double z = Math.Abs(x / Math.Sqrt(2)), t = 1.0 / (1.0 + 0.5 * z);
        double erfc = t * Math.Exp(-z * z - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (0.09678418 + t * (-0.18628806 +
                      t * (0.27886807 + t * (-1.13520398 + t * (1.48851587 + t * (-0.82215223 + t * 0.17087277)))))))));
        return 0.5 * (x >= 0 ? erfc : 2 - erfc);
    }

    /// <summary>Smallest eigenvalue of a symmetric 3x3 matrix (closed-form trigonometric method).</summary>
    public static double MinEig3(double a11, double a22, double a33, double a12, double a13, double a23)
    {
        double p1 = a12 * a12 + a13 * a13 + a23 * a23;
        if (p1 < 1e-300) return Math.Min(a11, Math.Min(a22, a33));
        double q = (a11 + a22 + a33) / 3.0;
        double p2 = (a11 - q) * (a11 - q) + (a22 - q) * (a22 - q) + (a33 - q) * (a33 - q) + 2 * p1;
        double p = Math.Sqrt(p2 / 6.0);
        double b11 = (a11 - q) / p, b22 = (a22 - q) / p, b33 = (a33 - q) / p, b12 = a12 / p, b13 = a13 / p, b23 = a23 / p;
        double detB = b11 * (b22 * b33 - b23 * b23) - b12 * (b12 * b33 - b23 * b13) + b13 * (b12 * b23 - b22 * b13);
        double r = Math.Clamp(detB / 2.0, -1.0, 1.0);
        double phi = Math.Acos(r) / 3.0;
        return q + 2 * p * Math.Cos(phi + 2.0 * Math.PI / 3.0);
    }
}
