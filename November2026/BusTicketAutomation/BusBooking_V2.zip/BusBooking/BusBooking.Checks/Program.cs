// Plain console checks for the rules, the JSON files and the view-models.
// Run: dotnet run --project BusBooking.Checks
using BusBooking.Core.Domain;
using BusBooking.Core.ViewModels;

if (args is ["--write-sample", var samplePath]) { ConfigRepository.Save(samplePath, OperatorConfig.Sample); return 0; }

var failures = 0;
void Check(string name, bool ok) { Console.WriteLine($"{(ok ? "ok  " : "FAIL")}  {name}"); if (!ok) failures++; }

var cfg = OperatorConfig.Sample;
var t = cfg.Tariff;
BusConfig b1 = cfg.Buses[0], b2 = cfg.Buses[1];          // B1: 2+2, fare 240; B2: 2+3, fare 220
var now = new DateTime(2026, 11, 10, 9, 0, 0);
Trip TripOf(BusConfig b, DateOnly d, TimeOnly at) => new(b.Id, b.Name, $"{b.Layout.Left}+{b.Layout.Right}", d, at);
var trip = TripOf(b1, new DateOnly(2026, 11, 12), new TimeOnly(5, 30));
BookingRequest Req(int seat, int from, int to, AddOns? a = null, Trip? tr = null, OffStopBoarding? off = null) =>
    new(tr ?? trip, seat, from, to, "Test Passenger", "98300 12345", PayMode.UPI, a ?? AddOns.None, off);
var seats1 = BusRules.Seats(b1); var seats2 = BusRules.Seats(b2);

Console.WriteLine("-- configuration");
Check("sample configuration is valid", ConfigRules.Validate(cfg).Count == 0);
Check("2+2 x 10 = 40 seats, 20 window", seats1.Count == 40 && seats1.Count(s => s.IsWindow) == 20);
Check("2+3 x 10 = 50 seats, 20 window, E is a window", seats2.Count == 50 && seats2.Count(s => s.IsWindow) == 20 && seats2[4] is { Label: "1E", IsWindow: true, IsLeftBlock: false });
Check("2+3: C and D are not windows", !seats2[2].IsWindow && !seats2[3].IsWindow);
Check("arrival at Arambagh is +1:40", BusRules.MinutesTo(b1, 3) == 100 && BusRules.TimeAt(b1, trip, 3) == new DateTime(2026, 11, 12, 7, 10, 0));
bool Bad(OperatorConfig c) => ConfigRules.Validate(c).Count > 0;
OperatorConfig With(Func<BusConfig, BusConfig> f) => cfg with { Buses = new[] { f(b1), b2 } };
Check("3+2 layout refused", Bad(With(b => b with { Layout = new SeatLayout(3, 2, 10) })));
Check("zero rows refused", Bad(With(b => b with { Layout = new SeatLayout(2, 2, 0) })));
Check("duplicate bus ID refused", Bad(With(b => b with { Id = "b2" })));
Check("stops out of order refused", Bad(With(b => b with { Stops = b.Stops.Select((s, i) => i == 2 ? s with { Km = 5 } : s).ToList() })));
Check("paid request stop with zero fee refused", Bad(With(b => b with { Stops = b.Stops.Select((s, i) => i == 4 ? s with { RequestFee = 0 } : s).ToList() })));
Check("9-digit mobile refused", Bad(With(b => b with { EmergencyCell = new[] { new Contact("A", "B", "983001234") } })));
Check("empty grievance cell refused", Bad(With(b => b with { GrievanceCell = Array.Empty<Contact>() })));
Check("no departures refused", Bad(With(b => b with { Departures = Array.Empty<TimeOnly>() })));
Check("waiting limit above 5 minutes refused", Bad(cfg with { Tariff = t with { MaxWaitingMinutes = 6 } }));

Console.WriteLine("-- pricing");
Check("full fare bus 1 = 240, bus 2 = 220", Pricing.SectionFare(b1, 0, 6, t) == 240 && Pricing.SectionFare(b2, 0, 6, t) == 220);
Check("window seat adds surcharge", Pricing.Quote(b1, seats1[0], 0, 6, AddOns.None, null, t).Total == 250);
Check("aisle seat has no surcharge", Pricing.Quote(b1, seats1[1], 0, 6, AddOns.None, null, t).Total == 240);
Check("luggage and tea", Pricing.Quote(b1, seats1[1], 0, 6, new AddOns(3, 2, 3), null, t).Total == 240 + 40 + 60 + 45);
Check("free request stop adds nothing (Joypur)", Pricing.Quote(b1, seats1[1], 1, 6, AddOns.None, null, t).Total == Pricing.SectionFare(b1, 1, 6, t));
Check("paid request stop, boarding (Champadanga +10)", Pricing.Quote(b1, seats1[1], 4, 6, AddOns.None, null, t).Total == Pricing.SectionFare(b1, 4, 6, t) + 10);
Check("paid request stop, alighting (+10)", Pricing.Quote(b1, seats1[1], 0, 4, AddOns.None, null, t).Total == Pricing.SectionFare(b1, 0, 4, t) + 10);
var share = new OffStopBoarding("Petrol pump", true, "22.88, 87.79"); var noShare = new OffStopBoarding("Petrol pump", false, "");
Check("off-stop with location +30", Pricing.Quote(b1, seats1[1], 3, 6, AddOns.None, share, t).Total == Pricing.SectionFare(b1, 3, 6, t) + 30);
Check("off-stop without location +50", Pricing.Quote(b1, seats1[1], 3, 6, AddOns.None, noShare, t).Total == Pricing.SectionFare(b1, 3, 6, t) + 50);
Check("off-stop after a paid request stop: no request fee", Pricing.Quote(b1, seats1[1], 4, 6, AddOns.None, share, t).Total == Pricing.SectionFare(b1, 4, 6, t) + 30);
Check("waiting 5 min = 100; 6 and 0 refused", Pricing.WaitingCharge(5, t).Value == 100 && !Pricing.WaitingCharge(6, t).Ok && !Pricing.WaitingCharge(0, t).Ok);

Console.WriteLine("-- booking");
var r1 = BookingBook.Empty.Book(Req(1, 0, 3), b1, now, t);
Check("book seat 1 Bishnupur-Arambagh", r1.Ok && r1.Value!.Bookings[0] is { SeatLabel: "1A", FromName: "Bishnupur", ToName: "Arambagh" });
Check("overlap refused", !r1.Value!.Book(Req(1, 2, 6), b1, now, t).Ok);
Check("same seat resold from Arambagh onward", r1.Value!.Book(Req(1, 3, 6), b1, now, t).Ok);
Check("same seat number on another bus is separate", r1.Value!.Book(Req(1, 0, 6, tr: TripOf(b2, trip.Date, new TimeOnly(7, 0))), b2, now, t).Ok);
Check("seat 45 exists on 2+3 only", BookingBook.Empty.Book(Req(45, 0, 6, tr: TripOf(b2, trip.Date, new TimeOnly(7, 0))), b2, now, t).Ok && !BookingBook.Empty.Book(Req(45, 0, 6), b1, now, t).Ok);
Check("trip of another bus refused", !BookingBook.Empty.Book(Req(1, 0, 3), b2, now, t).Ok);
Check("bad phone / empty name refused", !BookingBook.Empty.Book(Req(1, 0, 3) with { Phone = "123" }, b1, now, t).Ok && !BookingBook.Empty.Book(Req(1, 0, 3) with { PassengerName = " " }, b1, now, t).Ok);
Check("31 days ahead refused, 30 allowed", !BookingBook.Empty.Book(Req(1, 0, 3, tr: trip with { Date = new DateOnly(2026, 12, 11) }), b1, now, t).Ok
    && BookingBook.Empty.Book(Req(1, 0, 3, tr: trip with { Date = new DateOnly(2026, 12, 10) }), b1, now, t).Ok);
var today0530 = trip with { Date = new DateOnly(2026, 11, 10) };            // left Bishnupur 05:30; Dankuni at 09:45
Check("bus already past Bishnupur refused", !BookingBook.Empty.Book(Req(1, 0, 6, tr: today0530), b1, now, t).Ok);
Check("same bus can still be boarded at Dankuni", BookingBook.Empty.Book(Req(1, 5, 6, tr: today0530), b1, now, t).Ok);
Check("off-stop needs a landmark", !BookingBook.Empty.Book(Req(1, 3, 6, off: share with { Landmark = "" }), b1, now, t).Ok);
Check("off-stop with sharing needs a location", !BookingBook.Empty.Book(Req(1, 3, 6, off: share with { Location = " " }), b1, now, t).Ok);
Check("off-stop refused on a bus that does not allow it", !BookingBook.Empty.Book(Req(1, 3, 6, off: share), b1 with { AllowOffStopBoarding = false }, now, t).Ok);
var off = BookingBook.Empty.Book(Req(1, 3, 6, off: noShare with { Location = "ignored" }), b1, now, t);
Check("off-stop booked; location dropped when not shared", off.Ok && off.Value!.Bookings[0].OffStop is { Landmark: "Petrol pump", Location: "" } && off.Value!.Bookings[0].Fare.Total == 145 + 10 + 50);

Console.WriteLine("-- cancellation and later charges");
var book = BookingBook.Empty.Book(Req(1, 0, 6), b1, now, t).Value!;             // total 250, boards 12 Nov 05:30
var id = book.Bookings[0].Id; var boardAt = book.Bookings[0].BoardingAt;
Check("cancel 44 h before: 90%", book.Cancel(id, now, t).Value!.Find(id)!.RefundAmount == 225);
Check("cancel 10 h before: 50%", book.Cancel(id, boardAt.AddHours(-10), t).Value!.Find(id)!.RefundAmount == 125);
Check("cancel 1 h before: 0%", book.Cancel(id, boardAt.AddHours(-1), t).Value!.Find(id)!.RefundAmount == 0);
Check("cancel after boarding time refused", !book.Cancel(id, boardAt.AddMinutes(1), t).Ok);
var cancelled = book.Cancel(id, now, t).Value!;
Check("double cancel refused; seat free again", !cancelled.Cancel(id, now, t).Ok && cancelled.IsFree(trip.Id, 1, 0, 6));
var w = book.AddWaiting(id, 3, now, t).Value!;
Check("waiting 3 min, then 3 more refused, 2 more allowed", w.Find(id)!.ExtrasTotal == 60 && !w.AddWaiting(id, 3, now, t).Ok && w.AddWaiting(id, 2, now, t).Value!.Find(id)!.ExtrasTotal == 100);
var lf = w.AddLostAndFound(id, "umbrella", now, t).Value!;
Check("lost and found fee added; needs a description", lf.Find(id)!.ExtrasTotal == 110 && !w.AddLostAndFound(id, "", now, t).Ok);
Check("extras are not refunded", lf.Cancel(id, now, t).Value!.Find(id)!.RefundAmount == 225);
Check("no waiting on a cancelled booking", !cancelled.AddWaiting(id, 1, now, t).Ok);

Console.WriteLine("-- JSON files");
var dir = Path.Combine(Path.GetTempPath(), $"busbooking-{Guid.NewGuid():N}");
string configPath = AppPaths.Config(new[] { dir }), bookingsPath = AppPaths.Bookings(new[] { dir });
Check("missing config gives the sample with a note", ConfigRepository.Load(configPath) is { Problem: not null, Config.Buses.Count: 2 });
ConfigRepository.Save(configPath, cfg);
var back = ConfigRepository.Load(configPath);
Check("config round trip", back.Problem is null && back.Config.Buses[1].Layout == b2.Layout && back.Config.Buses[0].Stops[4] == b1.Stops[4]
    && back.Config.Buses[0].Departures.SequenceEqual(b1.Departures) && back.Config.Buses[0].EmergencyCell.SequenceEqual(b1.EmergencyCell)
    && back.Config.Tariff.RefundTiers.SequenceEqual(t.RefundTiers) && back.Config.Tariff.OffStopFeeWithLocation == 30);
Check("config file is readable text with named stop kinds", File.ReadAllText(configPath).Contains("\"RequestPaid\"") && File.ReadAllText(configPath).Contains("\"05:30:00\""));
BookingRepository.Save(bookingsPath, lf);
var loaded = BookingRepository.Load(bookingsPath);
Check("bookings round trip", loaded.NextSerial == lf.NextSerial && loaded.Find(id) is { ExtrasTotal: 110, SeatLabel: "1A" } lb && lb.Fare.Total == 250 && !loaded.IsFree(trip.Id, 1, 0, 6));
File.WriteAllText(bookingsPath, "{ not json");
Check("damaged bookings file gives empty register and is kept", BookingRepository.Load(bookingsPath).Bookings.Count == 0 && File.Exists(bookingsPath + ".unreadable"));
File.Delete(bookingsPath);

Console.WriteLine("-- configurator");
var liveBook = BookingBook.Empty;
var cvm = new ConfiguratorViewModel(configPath, () => ConfigRepository.LoadForEditing(configPath), c => ConfigRepository.Save(configPath, c), () => liveBook, () => now);
Check("configurator loads two buses", cvm.Buses.Count == 2 && cvm.SelectedBus!.Stops.Count == 7 && cvm.SelectedBus.Stops[3].FromStart == "+1:40");
var ed = cvm.SelectedBus!;
ed.IsTwoPlusThree = true; ed.Rows = 12;
Check("layout switch updates seat summary", ed.SeatSummary.StartsWith("60 seats") && !ed.IsTwoPlusTwo);
ed.Stops[1].MinutesFromPrevious = 35;
Check("running times follow an edit", ed.Stops[3].FromStart == "+1:50");
ed.SelectedStop = ed.Stops[3]; ed.AddStopCommand.Execute(null);
Check("stop inserted after the selected one", ed.Stops.Count == 8 && ed.Stops[4].Name == "New stop");
cvm.SaveCommand.Execute(null);
Check("save refused: new stop is not further along the road", cvm.StatusIsError && cvm.Problems.Count > 0);
ed.Stops[4].Name = "Mayapur"; ed.Stops[4].Km = 66; ed.Stops[4].MinutesFromPrevious = 20;
ed.Stops[4].Kind = StopKindOption.All[2]; ed.Stops[4].RequestFee = 15;
ed.DeparturesText = "5:30, 25:00";
cvm.SaveCommand.Execute(null);
Check("save refused: bad departure time", cvm.StatusIsError && cvm.Problems.Any(p => p.Contains("25:00")));
ed.DeparturesText = "13:30, 5:30";
ed.AddEmergencyCommand.Execute(null); ed.SelectedEmergency!.Name = "Driver"; ed.SelectedEmergency.Mobile = "98300 11111";
cvm.Tariff.TeaPerCup = 12; cvm.Tariff.OffStopFeeWithoutLocation = 60; cvm.OperatorName = "Test Operator";
cvm.SaveCommand.Execute(null);
var saved = ConfigRepository.Load(configPath);
Check("save succeeds and file holds the edits", !cvm.StatusIsError && saved.Problem is null && saved.Config.OperatorName == "Test Operator"
    && saved.Config.Buses[0] is { Layout: { Right: 3, Rows: 12 }, Stops.Count: 8, EmergencyCell.Count: 3 }
    && saved.Config.Buses[0].Stops[4] is { Name: "Mayapur", Kind: StopKind.RequestPaid, RequestFee: 15 }
    && saved.Config.Buses[0].Departures.SequenceEqual(new[] { new TimeOnly(5, 30), new TimeOnly(13, 30) }) && saved.Config.Tariff.TeaPerCup == 12);
cvm.AddBusCommand.Execute(null);
Check("new bus gets a free ID and fails validation until contacts are added", cvm.SelectedBus!.Id == "B3" && cvm.Build().Config is null);
cvm.RemoveBusCommand.Execute(null); cvm.DuplicateBusCommand.Execute(null);
Check("duplicate bus is valid as it stands", cvm.Buses.Count == 3 && cvm.Build().Config is not null);
cvm.ReloadCommand.Execute(null);
Check("reload discards unsaved buses", cvm.Buses.Count == 2);
File.WriteAllText(configPath + ".bak", File.ReadAllText(configPath)); File.WriteAllText(configPath, "{ broken");
cvm.ReloadCommand.Execute(null);
Check("broken file is reported, screen kept", cvm.StatusIsError && cvm.Buses.Count == 2);
Check("booking app falls back to sample on a broken file", ConfigRepository.Load(configPath) is { Problem: not null, Config.OperatorName: "Sample operator" });
File.Copy(configPath + ".bak", configPath, true);

Console.WriteLine("-- booking app view-model");
ConfigRepository.Save(configPath, cfg);                                   // back to the sample
BookingBook? savedBook = null;
var vm = new MainViewModel(() => ConfigRepository.Load(configPath), BookingBook.Empty, () => now, bk => savedBook = bk);
Check("today 09:00: all three buses can still be boarded somewhere", vm.Trips.Select(x => x.Departure.Hour).SequenceEqual(new[] { 5, 7, 13 }));
var lateVm = new MainViewModel(() => ConfigRepository.Load(configPath), BookingBook.Empty, () => now.AddHours(1), _ => { });
Check("today 10:00: the 05:30 bus has passed Dankuni and is gone", lateVm.Trips.Select(x => x.Departure.Hour).SequenceEqual(new[] { 7, 13 }));
vm.TravelDate = new DateTime(2026, 11, 12);
Check("later date offers three trips", vm.Trips.Count == 3 && vm.SelectedTrip!.BusId == "B1");
Check("date beyond window is clamped", (vm.TravelDate = new DateTime(2027, 1, 1)) is not null && vm.TravelDate == vm.MaxDate);
vm.TravelDate = new DateTime(2026, 11, 12);
Check("2+2 bus: 10 rows of 2 | 2; stop list shows time and request fee", vm.SeatRows.Count == 10 && vm.SeatRows[0].Left.Count == 2 && vm.SeatRows[0].Right.Count == 2
    && vm.FromStops.Count == 6 && vm.FromStops[4].Text == "08:00  Champadanga · on request, ₹10" && vm.ToStop!.Name == "Esplanade");
vm.SelectedTrip = vm.Trips.First(x => x.BusId == "B2");
Check("switching to the 2+3 bus redraws 10 rows of 2 | 3", vm.SeatRows.Count == 10 && vm.SeatRows[0].Right.Count == 3 && vm.BusText.Contains("50 seats"));
vm.SelectedTrip = vm.Trips.First(x => x.BusId == "B1");
vm.PickWindowSeatCommand.Execute(null);
Check("picks window seat 1A at ₹250", vm.SelectedSeat?.Label == "1A" && vm.Total == "₹250");
vm.Tea = 2; vm.Hold = 1;
Check("quote follows add-ons", vm.Total == "₹310");
vm.BookCommand.Execute(null);
Check("booking without name shows error", vm.StatusIsError && savedBook is null);
vm.PassengerName = "Asha"; vm.Phone = "9830012345";
vm.BookCommand.Execute(null);
Check("booked and saved", !vm.StatusIsError && savedBook?.Bookings.Count == 1 && vm.Bookings.Count == 1);
Check("seat now taken, selection cleared", vm.SeatRows[0].Left[0].IsTaken && vm.SelectedSeat is null && !vm.CanBook);
vm.FromStop = vm.FromStops[3];
Check("changing boarding stop keeps a valid destination", vm.ToStop!.Index == 6 && vm.ToStops.Count == 3 && vm.SeatRows[0].Left[0].IsTaken);
vm.OffStop = true; vm.ShareLocation = false;
vm.SeatRows[1].Left[1].SelectCommand.Execute(null);
Check("off-stop quote adds ₹50, label changes", vm.Total == "₹195" && vm.BoardingLabel.Contains("on the road") && vm.JourneyNote.Contains("passes Arambagh at 07:10"));
vm.ShareLocation = true;
Check("sharing location lowers it to ₹30", vm.Total == "₹175");
vm.PassengerName = "Bimal"; vm.Phone = "9830099999";
vm.BookCommand.Execute(null);
Check("off-stop booking without landmark refused", vm.StatusIsError && vm.Bookings.Count == 1);
vm.Landmark = "Opposite the rice mill"; vm.Location = "22.8805, 87.7910";
vm.BookCommand.Execute(null);
Check("off-stop booking made; form reset", !vm.StatusIsError && vm.Bookings.Count == 2 && !vm.OffStop && vm.Landmark == ""
    && vm.Bookings[0].Journey == "after Arambagh → Esplanade");
vm.SelectedBooking = vm.Bookings[0];
Check("booking note shows landmark and location", vm.BookingNote.Contains("rice mill") && vm.BookingNote.Contains("22.8805"));
vm.FromStop = vm.FromStops[0];
vm.WindowOnly = true;
Check("window filter dims aisle seats", vm.SeatRows[0].Left[1].IsDimmed && !vm.SeatRows[0].Right[1].IsDimmed && !vm.SeatRows[0].Left[1].CanSelect);
vm.SelectedBooking = vm.Bookings[1];
vm.WaitingMinutes = 5; vm.AddWaitingCommand.Execute(null); vm.AddWaitingCommand.Execute(null);
Check("second 5-minute wait refused", vm.StatusIsError && vm.SelectedBooking!.Booking.ExtrasTotal == 100);
vm.LostItem = "tiffin box"; vm.AddLostAndFoundCommand.Execute(null);
Check("lost and found added, box cleared", vm.SelectedBooking!.Booking.ExtrasTotal == 150 && vm.LostItem == "");
vm.CancelCommand.Execute(null);
Check("cancel frees the seat and shows refund", !vm.SeatRows[0].Left[0].IsTaken && vm.SelectedBooking!.Status == "Cancelled" && vm.RefundPreview.Contains("₹279"));
Check("contacts shown for the first bus", vm.ContactBus?.Id == "B1" && vm.GrievanceCell.Count == 1 && vm.EmergencyCell.Count == 2);

Console.WriteLine("-- configurator to booking app, through the file");
liveBook = savedBook!;                                                     // one confirmed off-stop booking on B1 remains
var cvm2 = new ConfiguratorViewModel(configPath, () => ConfigRepository.LoadForEditing(configPath), c => ConfigRepository.Save(configPath, c), () => liveBook, () => now);
cvm2.Buses[0].IsTwoPlusThree = true;
cvm2.SaveCommand.Execute(null);
Check("seating change refused while the bus has an upcoming booking", cvm2.StatusIsError && cvm2.Problems.Any(p => p.Contains("upcoming booking") && p.Contains("seating")));
cvm2.Buses[0].IsTwoPlusTwo = true; cvm2.Buses[0].Stops[2].Name = "Kotulpur Bazar";
cvm2.SaveCommand.Execute(null);
Check("stop rename refused while the bus has an upcoming booking", cvm2.StatusIsError && cvm2.Problems.Any(p => p.Contains("stops")));
cvm2.Buses[0].Stops[2].Name = "Kotulpur";
cvm2.SelectedBus = cvm2.Buses[0]; cvm2.RemoveBusCommand.Execute(null);
Check("removing a bus with an upcoming booking refused", cvm2.Build().Config is null);
cvm2.ReloadCommand.Execute(null);
cvm2.Buses[1].IsTwoPlusTwo = true; cvm2.Buses[1].Rows = 8;                 // B2 has no bookings: free to change
cvm2.Buses[0].AllowOffStopBoarding = false; cvm2.Buses[0].Stops[4].RequestFee = 25;
cvm2.Buses[0].AddGrievanceCommand.Execute(null); cvm2.Buses[0].SelectedGrievance!.Name = "Stand manager"; cvm2.Buses[0].SelectedGrievance!.Mobile = "9830022222";
cvm2.Tariff.TeaPerCup = 20; cvm2.Tariff.MaxWaitingMinutes = 3;
cvm2.SaveCommand.Execute(null);
Check("fees, contacts, off-stop switch and an unbooked bus's seating can be changed", !cvm2.StatusIsError);
vm.WindowOnly = false; vm.OffStop = true;
vm.ReloadConfigCommand.Execute(null);
Check("reload: off-stop switched off for bus 1", !vm.StatusIsError && !vm.OffStopAllowed && !vm.OffStop);
Check("reload: new request fee in the stop list", vm.FromStops[4].Text.EndsWith("₹25"));
Check("reload: new tariff and limits", vm.TariffNote.Contains("tea ₹20") && vm.WaitingOptions.Count == 3 && vm.WaitingMinutes == 3);
Check("reload: new grievance member visible", vm.GrievanceCell.Count == 2 && vm.GrievanceCell[1].Mobile == "9830022222");
Check("reload: earlier bookings still listed with their own details", vm.Bookings.Count == 2 && vm.Bookings[1].Seat == "1A");
vm.SelectedTrip = vm.Trips.First(x => x.BusId == "B2");
Check("reload: bus 2 now 8 rows of 2 | 2", vm.SeatRows.Count == 8 && vm.SeatRows[0].Right.Count == 2);
Directory.Delete(dir, true);

Console.WriteLine(failures == 0 ? "\nAll checks passed." : $"\n{failures} check(s) FAILED.");
return failures == 0 ? 0 : 1;
