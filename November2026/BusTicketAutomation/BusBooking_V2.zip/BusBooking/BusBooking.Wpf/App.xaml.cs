using System.Windows;
using BusBooking.Core.Domain;
using BusBooking.Core.ViewModels;

namespace BusBooking.Wpf;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        // Both files live in %LOCALAPPDATA%\BusBooking unless a folder is given on the command line.
        // config.json is written by the configurator; bookings.json is written here.
        string configPath = AppPaths.Config(e.Args), bookingsPath = AppPaths.Bookings(e.Args);
        var viewModel = new MainViewModel(
            () => ConfigRepository.Load(configPath), BookingRepository.Load(bookingsPath),
            () => DateTime.Now, book => BookingRepository.Save(bookingsPath, book));
        new MainWindow { DataContext = viewModel }.Show();
    }
}
