using System.Windows;
using BusBooking.Core.Domain;
using BusBooking.Core.ViewModels;

namespace BusBooking.Configurator;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        // Writes config.json in %LOCALAPPDATA%\BusBooking (or the folder given on the command line),
        // the same folder the booking app reads. bookings.json is only read, to protect upcoming bookings.
        string configPath = AppPaths.Config(e.Args), bookingsPath = AppPaths.Bookings(e.Args);
        var viewModel = new ConfiguratorViewModel(
            configPath, () => ConfigRepository.LoadForEditing(configPath), config => ConfigRepository.Save(configPath, config),
            () => BookingRepository.Load(bookingsPath), () => DateTime.Now);
        new MainWindow { DataContext = viewModel }.Show();
    }
}
