using System.Windows;

namespace BusBooking.Configurator;

public partial class MainWindow : Window
{
    public MainWindow() => InitializeComponent();
}
