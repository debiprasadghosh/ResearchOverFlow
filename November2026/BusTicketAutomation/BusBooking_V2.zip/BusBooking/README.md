# Bus Seat Booking (WPF, .NET 8)

Two desktop apps that talk through one JSON file.

| App | Project | For | Writes |
|---|---|---|---|
| Bus Configurator | `BusBooking.Configurator` | the operator | `config.json` |
| Bus Seat Booking | `BusBooking.Wpf` | the passenger / counter | `bookings.json` |

Both files sit in `%LOCALAPPDATA%\BusBooking`. To use another folder (a shared drive, say),
pass it as the first command-line argument to both apps.

## Run

Requires Windows and the .NET 8 SDK.

    dotnet run --project BusBooking.Configurator
    dotnet run --project BusBooking.Wpf

or open `BusBooking.sln` in Visual Studio 2022.

The booking app reads `config.json` when it starts and again when "Reload configuration" is
pressed. If the file is missing or broken it shows two sample buses and says so.

Rule checks (any OS): `dotnet run --project BusBooking.Checks`

## Configurator

Per bus:
- **Bus** — ID, name, registration, full-route fare, seating (2 + 2 or 2 + 3, number of rows),
  departure times, and whether passengers may board on the road between stops.
- **Stops and timings** — stops in road order, distance, running time from the previous stop
  (arrival times follow from it), and the kind of stop: regular, on request (free), or on
  request with a fee.
- **Grievance cell** and **Emergency cell** — name, role and mobile number of each member.

For all buses:
- **Charges** — window seat, boarding on the road (with and without a shared location),
  luggage, tea, emergency waiting, lost and found, advance-booking days, cancellation refunds.

Save checks everything and lists what to fix. It also refuses to change the seating or the list
of stops of a bus that has upcoming bookings, or to remove such a bus: a booking holds a seat
number and stop numbers, so those changes would move passengers to the wrong seat. Add the new
arrangement as a new bus instead. Fees, timings, contacts and departures can be changed freely.

`sample-config.json` shows the file format.

## Booking app

- Travel date up to the configured number of days ahead; every departure of every bus.
- Boarding and alighting stop with scheduled times. A seat is sold stop to stop.
  A bus that has left its first stop can still be booked from stops it has not reached.
- Seat map drawn from the bus's own layout; window seats tinted; window-only filter.
- **Boarding on the road**: tick "I will board on the road, not at a stop", choose the stop the
  bus passes just before you, give a landmark, and optionally paste a map link or coordinates.
  The charge is lower when a location is shared. The app has no GPS of its own; the location is
  whatever the passenger pastes.
- Request-stop fees, luggage, tea and the window charge appear as separate fare lines.
- My bookings: cancel with the refund shown first, add emergency waiting (1 to 5 minutes),
  add a lost-and-found charge.
- Help and contacts: the emergency and grievance cells of each bus.

## Layout of the code

- `BusBooking.Core/Domain` — immutable records (`Config.cs`, `Model.cs`), pure rules (`Rules.cs`),
  JSON files (`Storage.cs`).
- `BusBooking.Core/ViewModels` — view-models for both apps; no WPF dependency.
- `BusBooking.Wpf`, `BusBooking.Configurator` — XAML only; no logic in code-behind.
- `BusBooking.Checks` — console checks of rules, files and view-models.

No payment is taken; "Paying by" is recorded only.
