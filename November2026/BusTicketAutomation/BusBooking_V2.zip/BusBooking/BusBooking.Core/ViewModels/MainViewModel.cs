using System.Collections.ObjectModel;
using System.Windows.Input;
using BusBooking.Core.Domain;

namespace BusBooking.Core.ViewModels;

/// A stop as offered in the boarding / alighting lists, with its scheduled time on the chosen trip.
public sealed record StopOption(int Index, string Name, string Text)
{
    public override string ToString() => Text;
}

/// One row of the "My bookings" list.
public sealed record BookingRow(Booking Booking)
{
    public string Id => Booking.Id;
    public string When => $"{Booking.BoardingAt:ddd dd MMM, HH:mm}";
    public string Bus => Booking.BusName;
    public string Seat => Booking.SeatLabel;
    public string Journey => (Booking.OffStop is null ? "" : "after ") + $"{Booking.FromName} → {Booking.ToName}";
    public string Passenger => Booking.PassengerName;
    public string Paid => Money.Text(Booking.Fare.Total + Booking.ExtrasTotal);
    public string Status => Booking.Status == BookingStatus.Cancelled ? "Cancelled" : "Confirmed";
}

public sealed class MainViewModel : ObservableObject
{
    readonly Func<ConfigLoad> _loadConfig;
    readonly Func<DateTime> _now;
    readonly Action<BookingBook> _save;
    OperatorConfig _config;
    BookingBook _book;
    BusConfig? _bus;
    IReadOnlyList<SeatViewModel> _seats = Array.Empty<SeatViewModel>();
    bool _rebuilding;

    DateTime? _travelDate;
    Trip? _selectedTrip;
    StopOption? _fromStop, _toStop;
    bool _windowOnly, _offStop, _shareLocation, _statusIsError;
    SeatViewModel? _selectedSeat;
    string _passengerName = "", _phone = "", _status = "", _lostItem = "", _refundPreview = "", _total = "", _landmark = "", _location = "", _bookingNote = "";
    PayMode _payMode = PayMode.UPI;
    int _carryOn, _hold, _tea, _waitingMinutes = 1;
    BookingRow? _selectedBooking;
    BusConfig? _contactBus;

    public MainViewModel(Func<ConfigLoad> loadConfig, BookingBook book, Func<DateTime> now, Action<BookingBook> save)
    {
        (_loadConfig, _book, _now, _save) = (loadConfig, book, now, save);
        PayModes = Enum.GetValues<PayMode>();
        BookCommand = new RelayCommand(Book);
        CancelCommand = new RelayCommand(Cancel);
        AddWaitingCommand = new RelayCommand(AddWaiting);
        AddLostAndFoundCommand = new RelayCommand(AddLostAndFound);
        PickWindowSeatCommand = new RelayCommand(PickWindowSeat);
        ReloadConfigCommand = new RelayCommand(() => ApplyConfig(announce: true));
        _config = OperatorConfig.Sample;
        ApplyConfig(announce: false);
        RefreshBookings(null);
    }

    Tariff Tariff => _config.Tariff;

    // ---------- choices offered
    public ObservableCollection<SeatRowViewModel> SeatRows { get; } = new();
    public ObservableCollection<Trip> Trips { get; } = new();
    public ObservableCollection<StopOption> FromStops { get; } = new();
    public ObservableCollection<StopOption> ToStops { get; } = new();
    public ObservableCollection<int> CarryOnOptions { get; } = new();
    public ObservableCollection<int> HoldOptions { get; } = new();
    public ObservableCollection<int> TeaOptions { get; } = new();
    public ObservableCollection<int> WaitingOptions { get; } = new();
    public IReadOnlyList<PayMode> PayModes { get; }
    public ObservableCollection<FareLine> QuoteLines { get; } = new();
    public ObservableCollection<BookingRow> Bookings { get; } = new();
    public ObservableCollection<FareLine> DetailLines { get; } = new();
    public ObservableCollection<BusConfig> ContactBuses { get; } = new();

    public ICommand BookCommand { get; }
    public ICommand CancelCommand { get; }
    public ICommand AddWaitingCommand { get; }
    public ICommand AddLostAndFoundCommand { get; }
    public ICommand PickWindowSeatCommand { get; }
    public ICommand ReloadConfigCommand { get; }

    public string OperatorName => _config.OperatorName;
    public DateTime MinDate => _now().Date;
    public DateTime MaxDate => _now().Date.AddDays(Tariff.AdvanceBookingDays);
    public string TariffNote =>
        $"Window seat {Money.Text(Tariff.WindowSurcharge)} · carry-on: first {Tariff.FreeCarryOnPieces} free, then {Money.Text(Tariff.CarryOnExtraPerPiece)} each · " +
        $"hold luggage {Money.Text(Tariff.HoldLuggagePerPiece)} a piece · tea {Money.Text(Tariff.TeaPerCup)} a cup";
    public string RefundPolicy => "Cancellation: " + string.Join(", ", Tariff.RefundTiers
        .OrderByDescending(r => r.MinHoursBeforeDeparture)
        .Select(r => r.Percent == 0 ? "no refund after that" : $"{r.Percent}% back up to {r.MinHoursBeforeDeparture:0} h before boarding"));
    public string WaitingNote => $"{Money.Text(Tariff.WaitingPerMinute)} a minute, {Tariff.MaxWaitingMinutes} minutes at most per booking";
    public string LostAndFoundNote => $"{Money.Text(Tariff.LostAndFoundFee)} handling charge per item";
    public string OffStopNote =>
        $"{Money.Text(Tariff.OffStopFeeWithLocation)} if you share your location, {Money.Text(Tariff.OffStopFeeWithoutLocation)} if you do not. " +
        "The bus halts once, on the road after the stop you choose.";

    // ---------- the journey being booked
    public DateTime? TravelDate
    {
        get => _travelDate;
        set
        {
            var clamped = value is null ? MinDate : value.Value.Date < MinDate ? MinDate : value.Value.Date > MaxDate ? MaxDate : value.Value.Date;
            if (Set(ref _travelDate, clamped)) RebuildTrips();
        }
    }

    public Trip? SelectedTrip
    {
        get => _selectedTrip;
        set { if (!_rebuilding && Set(ref _selectedTrip, value)) OnTripChanged(); }
    }

    public StopOption? FromStop
    {
        get => _fromStop;
        set
        {
            if (_rebuilding || value is null || !Set(ref _fromStop, value)) return;
            RebuildToStops(_toStop?.Index ?? -1);
            RefreshSeats();
        }
    }

    public StopOption? ToStop
    {
        get => _toStop;
        set { if (!_rebuilding && value is not null && Set(ref _toStop, value)) RefreshSeats(); }
    }

    public bool WindowOnly { get => _windowOnly; set { if (Set(ref _windowOnly, value)) RefreshSeats(); } }

    /// Boarding on the road instead of at a designated stop.
    public bool OffStop { get => _offStop; set { if (Set(ref _offStop, value)) { Raise(nameof(BoardingLabel)); RefreshSeats(); } } }
    public bool OffStopAllowed => _bus?.AllowOffStopBoarding == true;
    public string BoardingLabel => OffStop ? "Boarding on the road after" : "Boarding at";
    public string Landmark { get => _landmark; set => Set(ref _landmark, value); }
    public bool ShareLocation { get => _shareLocation; set { if (Set(ref _shareLocation, value)) RefreshQuote(); } }
    public string Location { get => _location; set => Set(ref _location, value); }

    public SeatViewModel? SelectedSeat
    {
        get => _selectedSeat;
        private set { if (Set(ref _selectedSeat, value)) { Raise(nameof(SelectedSeatText)); Raise(nameof(CanBook)); } }
    }
    public string SelectedSeatText => SelectedSeat is null ? "No seat chosen"
        : $"Seat {SelectedSeat.Label}" + (SelectedSeat.IsWindow ? " (window)" : "");
    public string FreeSeatsText { get; private set; } = "";
    public string JourneyNote { get; private set; } = "";
    public string BusText => _bus is null ? "" : $"{_bus.Name} · {_bus.Registration} · {_bus.Layout.SeatCount} seats";

    // ---------- passenger and add-ons
    public string PassengerName { get => _passengerName; set => Set(ref _passengerName, value); }
    public string Phone { get => _phone; set => Set(ref _phone, value); }
    public PayMode PayMode { get => _payMode; set => Set(ref _payMode, value); }
    public int CarryOn { get => _carryOn; set { if (Set(ref _carryOn, value)) RefreshQuote(); } }
    public int Hold { get => _hold; set { if (Set(ref _hold, value)) RefreshQuote(); } }
    public int Tea { get => _tea; set { if (Set(ref _tea, value)) RefreshQuote(); } }
    public string Total { get => _total; private set => Set(ref _total, value); }
    public bool CanBook => SelectedSeat is not null && SelectedTrip is not null;

    // ---------- status line
    public string Status { get => _status; private set => Set(ref _status, value); }
    public bool StatusIsError { get => _statusIsError; private set => Set(ref _statusIsError, value); }

    // ---------- existing bookings
    public BookingRow? SelectedBooking
    {
        get => _selectedBooking;
        set { if (Set(ref _selectedBooking, value)) { RefreshDetail(); Raise(nameof(HasSelectedBooking)); } }
    }
    public bool HasSelectedBooking => SelectedBooking is not null;
    public int WaitingMinutes { get => _waitingMinutes; set => Set(ref _waitingMinutes, value); }
    public string LostItem { get => _lostItem; set => Set(ref _lostItem, value); }
    public string RefundPreview { get => _refundPreview; private set => Set(ref _refundPreview, value); }
    public string BookingNote { get => _bookingNote; private set => Set(ref _bookingNote, value); }

    // ---------- contacts
    public BusConfig? ContactBus
    {
        get => _contactBus;
        set { if (!_rebuilding && Set(ref _contactBus, value)) { Raise(nameof(GrievanceCell)); Raise(nameof(EmergencyCell)); } }
    }
    public IReadOnlyList<Contact> GrievanceCell => _contactBus?.GrievanceCell ?? Array.Empty<Contact>();
    public IReadOnlyList<Contact> EmergencyCell => _contactBus?.EmergencyCell ?? Array.Empty<Contact>();

    AddOns CurrentAddOns => new(CarryOn, Hold, Tea);
    OffStopBoarding? CurrentOffStop => OffStop && OffStopAllowed ? new OffStopBoarding(Landmark, ShareLocation, Location) : null;

    void Say(string message, bool error = false) { StatusIsError = error; Status = message; }

    static void Fill<T>(ObservableCollection<T> target, IEnumerable<T> items)
    {
        target.Clear();
        foreach (var i in items) target.Add(i);
    }

    /// Read config.json again and rebuild everything that depends on it.
    void ApplyConfig(bool announce)
    {
        var load = _loadConfig();
        _config = load.Config;
        _rebuilding = true;
        Fill(CarryOnOptions, Enumerable.Range(0, Tariff.MaxCarryOnPieces + 1));
        Fill(HoldOptions, Enumerable.Range(0, Tariff.MaxHoldPieces + 1));
        Fill(TeaOptions, Enumerable.Range(0, Tariff.MaxTeaCups + 1));
        Fill(WaitingOptions, Enumerable.Range(1, Tariff.MaxWaitingMinutes));
        var contactId = _contactBus?.Id;
        Fill(ContactBuses, _config.Buses);
        _contactBus = _config.Bus(contactId ?? "") ?? _config.Buses.FirstOrDefault();
        _rebuilding = false;
        _carryOn = Math.Min(_carryOn, Tariff.MaxCarryOnPieces); _hold = Math.Min(_hold, Tariff.MaxHoldPieces);
        _tea = Math.Min(_tea, Tariff.MaxTeaCups); _waitingMinutes = Math.Clamp(_waitingMinutes, 1, Tariff.MaxWaitingMinutes);
        foreach (var n in new[] { nameof(CarryOn), nameof(Hold), nameof(Tea), nameof(WaitingMinutes), nameof(ContactBus), nameof(GrievanceCell),
                     nameof(EmergencyCell), nameof(OperatorName), nameof(MinDate), nameof(MaxDate), nameof(TariffNote), nameof(RefundPolicy),
                     nameof(WaitingNote), nameof(LostAndFoundNote), nameof(OffStopNote) }) Raise(n);
        _bus = null;                                    // force stops and seats to be rebuilt
        if (_travelDate is null) TravelDate = MinDate; else RebuildTrips();
        RefreshDetail();
        if (load.Problem is not null) Say(load.Problem, error: true);
        else if (announce) Say("Configuration reloaded.");
    }

    void RebuildTrips()
    {
        var keep = _selectedTrip?.Id;
        var date = DateOnly.FromDateTime(_travelDate ?? MinDate);
        // a trip stays on offer while it can still be boarded somewhere along the road
        var open = BusRules.TripsOn(_config, date).Where(t => _config.Bus(t.BusId) is { } b
            && BusRules.TimeAt(b, t, BusRules.LastStop(b) - 1) > _now()).ToList();
        _rebuilding = true;
        Fill(Trips, open);
        _selectedTrip = open.FirstOrDefault(t => t.Id == keep) ?? open.FirstOrDefault();
        _rebuilding = false;
        Raise(nameof(SelectedTrip));
        OnTripChanged();
        if (open.Count == 0) Say("No more buses on that day. Choose a later date.", error: true);
    }

    void OnTripChanged()
    {
        var bus = _selectedTrip is null ? null : _config.Bus(_selectedTrip.BusId);
        var busChanged = !ReferenceEquals(bus, _bus);
        _bus = bus;
        int fromIndex = _fromStop?.Index ?? 0, toIndex = _toStop?.Index ?? int.MaxValue;
        _rebuilding = true;
        if (bus is null || _selectedTrip is null) { FromStops.Clear(); ToStops.Clear(); _fromStop = _toStop = null; }
        else
        {
            Fill(FromStops, Enumerable.Range(0, BusRules.LastStop(bus)).Select(i => Option(bus, _selectedTrip, i)));
            _fromStop = FromStops[fromIndex < FromStops.Count && !busChanged ? fromIndex : 0];
        }
        _rebuilding = false;
        Raise(nameof(FromStop));
        RebuildToStops(busChanged ? -1 : toIndex);
        if (busChanged)
        {
            SelectedSeat = null;
            _seats = bus is null ? Array.Empty<SeatViewModel>() : BusRules.Seats(bus).Select(s => new SeatViewModel(s, SelectSeat)).ToList();
            Fill(SeatRows, _seats.GroupBy(s => s.Seat.Row).Select(g => new SeatRowViewModel(
                g.Where(s => s.Seat.IsLeftBlock).ToList(), g.Where(s => !s.Seat.IsLeftBlock).ToList())));
            if (!OffStopAllowed) OffStop = false;
            Raise(nameof(OffStopAllowed)); Raise(nameof(BusText));
        }
        RefreshSeats();
    }

    static StopOption Option(BusConfig bus, Trip trip, int i)
    {
        var s = bus.Stops[i];
        var kind = s.Kind switch
        {
            StopKind.RequestFree => " · on request",
            StopKind.RequestPaid => $" · on request, {Money.Text(s.RequestFee)}",
            _ => "",
        };
        return new StopOption(i, s.Name, $"{BusRules.TimeAt(bus, trip, i):HH\\:mm}  {s.Name}{kind}");
    }

    void RebuildToStops(int preferredIndex)
    {
        _rebuilding = true;
        if (_bus is null || _selectedTrip is null || _fromStop is null) { ToStops.Clear(); _toStop = null; }
        else
        {
            Fill(ToStops, Enumerable.Range(_fromStop.Index + 1, BusRules.LastStop(_bus) - _fromStop.Index).Select(i => Option(_bus, _selectedTrip, i)));
            _toStop = ToStops.FirstOrDefault(s => s.Index == preferredIndex) ?? ToStops[^1];
        }
        _rebuilding = false;
        Raise(nameof(ToStop));
    }

    void SelectSeat(SeatViewModel seat)
    {
        if (SelectedSeat is not null) SelectedSeat.IsSelected = false;
        seat.IsSelected = true;
        SelectedSeat = seat;
        RefreshQuote();
    }

    void PickWindowSeat()
    {
        var seat = _seats.FirstOrDefault(s => s.IsWindow && !s.IsTaken);
        if (seat is null) { Say("No window seat is free for this journey.", error: true); return; }
        SelectSeat(seat);
    }

    void RefreshSeats()
    {
        var ready = _selectedTrip is not null && _fromStop is not null && _toStop is not null;
        foreach (var s in _seats)
        {
            s.IsTaken = !ready || !_book.IsFree(_selectedTrip!.Id, s.Number, _fromStop!.Index, _toStop!.Index);
            s.IsDimmed = WindowOnly && !s.IsWindow;
            if (s.IsSelected && !s.CanSelect) { s.IsSelected = false; SelectedSeat = null; }
        }
        FreeSeatsText = !ready ? "" : $"{_seats.Count(s => !s.IsTaken)} of {_seats.Count} seats free for this journey, {_seats.Count(s => !s.IsTaken && s.IsWindow)} by the window";
        JourneyNote = !ready || _bus is null ? "" :
            (OffStop ? $"The bus passes {_fromStop!.Name} at {BusRules.TimeAt(_bus, _selectedTrip!, _fromStop.Index):HH\\:mm}; be on the road after it."
                     : $"Be at {_fromStop!.Name} by {BusRules.TimeAt(_bus, _selectedTrip!, _fromStop.Index):HH\\:mm}.")
            + $" Reaches {_toStop!.Name} about {BusRules.TimeAt(_bus, _selectedTrip!, _toStop.Index):HH\\:mm}.";
        Raise(nameof(FreeSeatsText)); Raise(nameof(JourneyNote)); Raise(nameof(CanBook));
        RefreshQuote();
    }

    void RefreshQuote()
    {
        QuoteLines.Clear();
        if (SelectedSeat is null || _bus is null || _fromStop is null || _toStop is null) { Total = ""; return; }
        var quote = Pricing.Quote(_bus, SelectedSeat.Seat, _fromStop.Index, _toStop.Index, CurrentAddOns, CurrentOffStop, Tariff);
        foreach (var l in quote.Lines) QuoteLines.Add(l);
        Total = Money.Text(quote.Total);
    }

    void RefreshBookings(string? selectId)
    {
        Fill(Bookings, _book.Bookings.OrderByDescending(b => b.BookedAt).ThenByDescending(b => b.Id).Select(b => new BookingRow(b)));
        SelectedBooking = Bookings.FirstOrDefault(r => r.Id == selectId);
        RefreshDetail();
    }

    void RefreshDetail()
    {
        DetailLines.Clear();
        var b = SelectedBooking?.Booking;
        if (b is null) { RefundPreview = ""; BookingNote = ""; return; }
        foreach (var l in b.Fare.Lines) DetailLines.Add(l);
        foreach (var e in b.Extras) DetailLines.Add(new FareLine(e.Note, e.Amount));
        BookingNote = b.OffStop is null ? $"Boarding at {b.FromName}, {b.BoardingAt:HH\\:mm}."
            : $"Boarding on the road after {b.FromName} (bus passes {b.BoardingAt:HH\\:mm}). Waiting at: {b.OffStop.Landmark}."
              + (b.OffStop.LocationShared ? $" Location: {b.OffStop.Location}" : " No location shared.");
        if (b.Status == BookingStatus.Cancelled)
        {
            DetailLines.Add(new FareLine("Refund on cancellation", -b.RefundAmount));
            RefundPreview = $"Cancelled on {b.CancelledAt:dd MMM, HH:mm}. Refund {Money.Text(b.RefundAmount)}.";
        }
        else if (b.BoardingAt <= _now()) RefundPreview = "The boarding time has passed; this booking can no longer be cancelled.";
        else
        {
            var (percent, amount) = Pricing.Refund(b, _now(), Tariff);
            RefundPreview = $"Cancelling now returns {percent}% of the booking amount: {Money.Text(amount)}.";
        }
    }

    /// Apply a register operation; on success keep, save and redraw.
    bool Apply(Result<BookingBook> result, string? selectId, string success)
    {
        if (!result.Ok) { Say(result.Error!, error: true); return false; }
        _book = result.Value!;
        try { _save(_book); Say(success); }
        catch (Exception e) when (JsonFiles.IsFileProblem(e))
        { Say($"{success} It could not be saved to disk: {e.Message}", error: true); }
        RefreshBookings(selectId);
        RefreshSeats();
        return true;
    }

    void Book()
    {
        if (SelectedTrip is null || SelectedSeat is null || _bus is null || _fromStop is null || _toStop is null)
        { Say("Choose a bus and a seat first.", error: true); return; }
        var request = new BookingRequest(SelectedTrip, SelectedSeat.Number, _fromStop.Index, _toStop.Index, PassengerName, Phone, PayMode, CurrentAddOns, CurrentOffStop);
        var id = $"BK{_book.NextSerial:D5}"; var label = SelectedSeat.Label; var total = Total;
        if (!Apply(_book.Book(request, _bus, _now(), Tariff), id, $"Booked {id}: seat {label}, {total}.")) return;
        if (SelectedSeat is not null) { SelectedSeat.IsSelected = false; SelectedSeat = null; }
        PassengerName = ""; Phone = ""; CarryOn = 0; Hold = 0; Tea = 0; Landmark = ""; Location = ""; ShareLocation = false; OffStop = false;
        RefreshQuote();
    }

    void Cancel()
    {
        if (SelectedBooking is not { } row) { Say("Select a booking first.", error: true); return; }
        var refund = Pricing.Refund(row.Booking, _now(), Tariff).Amount;
        Apply(_book.Cancel(row.Id, _now(), Tariff), row.Id, $"Cancelled {row.Id}. Refund {Money.Text(refund)}.");
    }

    void AddWaiting()
    {
        if (SelectedBooking is not { } row) { Say("Select a booking first.", error: true); return; }
        Apply(_book.AddWaiting(row.Id, WaitingMinutes, _now(), Tariff), row.Id,
            $"Waiting of {WaitingMinutes} min added to {row.Id}: {Money.Text(WaitingMinutes * Tariff.WaitingPerMinute)}.");
    }

    void AddLostAndFound()
    {
        if (SelectedBooking is not { } row) { Say("Select a booking first.", error: true); return; }
        if (Apply(_book.AddLostAndFound(row.Id, LostItem, _now(), Tariff), row.Id,
                $"Lost and found charge added to {row.Id}: {Money.Text(Tariff.LostAndFoundFee)}."))
            LostItem = "";
    }
}
