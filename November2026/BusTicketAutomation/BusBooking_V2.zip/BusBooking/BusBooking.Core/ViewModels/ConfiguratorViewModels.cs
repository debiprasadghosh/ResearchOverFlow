using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Globalization;
using System.Windows.Input;
using BusBooking.Core.Domain;

namespace BusBooking.Core.ViewModels;

// Editable copies of the configuration. The immutable records are rebuilt from these on Save.

public sealed record StopKindOption(StopKind Kind, string Text)
{
    public static readonly IReadOnlyList<StopKindOption> All = new[]
    {
        new StopKindOption(StopKind.Regular, "Regular stop"),
        new StopKindOption(StopKind.RequestFree, "On request, free"),
        new StopKindOption(StopKind.RequestPaid, "On request, with fee"),
    };
    public override string ToString() => Text;
}

public sealed class StopRowViewModel : ObservableObject
{
    string _name = ""; double _km; int _minutes, _fee; StopKindOption _kind = StopKindOption.All[0]; string _fromStart = "";

    public StopRowViewModel() { }
    public StopRowViewModel(StopConfig s)
    {
        (_name, _km, _minutes, _fee) = (s.Name, s.Km, s.MinutesFromPrevious, s.RequestFee);
        _kind = StopKindOption.All.First(k => k.Kind == s.Kind);
    }

    public IReadOnlyList<StopKindOption> KindOptions => StopKindOption.All;
    public string Name { get => _name; set => Set(ref _name, value ?? ""); }
    public double Km { get => _km; set => Set(ref _km, value); }
    public int MinutesFromPrevious { get => _minutes; set => Set(ref _minutes, value); }
    public StopKindOption Kind { get => _kind; set { if (value is not null) Set(ref _kind, value); } }
    public int RequestFee { get => _fee; set => Set(ref _fee, value); }
    /// Filled in by the bus editor: running time from the first stop.
    public string FromStart { get => _fromStart; set => Set(ref _fromStart, value); }

    public StopConfig ToConfig() => new(Name.Trim(), Km, MinutesFromPrevious, Kind.Kind, Kind.Kind == StopKind.RequestPaid ? RequestFee : 0);
}

public sealed class ContactRowViewModel : ObservableObject
{
    string _name = "", _role = "", _mobile = "";
    public ContactRowViewModel() { }
    public ContactRowViewModel(Contact c) => (_name, _role, _mobile) = (c.Name, c.Role, c.Mobile);
    public string Name { get => _name; set => Set(ref _name, value ?? ""); }
    public string Role { get => _role; set => Set(ref _role, value ?? ""); }
    public string Mobile { get => _mobile; set => Set(ref _mobile, value ?? ""); }
    public Contact ToConfig() => new(Name.Trim(), Role.Trim(), Mobile.Trim());
}

public sealed class BusEditorViewModel : ObservableObject
{
    string _id, _name, _registration, _departures; int _fullFare, _right, _rows; bool _allowOffStop;
    StopRowViewModel? _selectedStop; ContactRowViewModel? _selectedGrievance, _selectedEmergency;

    public BusEditorViewModel(BusConfig b)
    {
        (_id, _name, _registration, _fullFare, _right, _rows, _allowOffStop) =
            (b.Id, b.Name, b.Registration, b.FullFare, b.Layout.Right, b.Layout.Rows, b.AllowOffStopBoarding);
        _departures = string.Join(", ", b.Departures.Select(d => d.ToString("HH\\:mm", CultureInfo.InvariantCulture)));
        Stops = new ObservableCollection<StopRowViewModel>(b.Stops.Select(s => new StopRowViewModel(s)));
        Grievance = new ObservableCollection<ContactRowViewModel>(b.GrievanceCell.Select(c => new ContactRowViewModel(c)));
        Emergency = new ObservableCollection<ContactRowViewModel>(b.EmergencyCell.Select(c => new ContactRowViewModel(c)));
        foreach (var s in Stops) s.PropertyChanged += StopChanged;
        Stops.CollectionChanged += StopsChanged;
        RefreshRunningTimes();

        AddStopCommand = new RelayCommand(() =>
        {
            var last = Stops.LastOrDefault();
            var row = new StopRowViewModel { Name = "New stop", Km = (last?.Km ?? -10) + 10, MinutesFromPrevious = last is null ? 0 : 20 };
            Stops.Insert(SelectedStop is null ? Stops.Count : Stops.IndexOf(SelectedStop) + 1, row);
            SelectedStop = row;
        });
        RemoveStopCommand = new RelayCommand(() => { if (SelectedStop is not null) Stops.Remove(SelectedStop); });
        MoveStopUpCommand = new RelayCommand(() => MoveStop(-1));
        MoveStopDownCommand = new RelayCommand(() => MoveStop(+1));
        AddGrievanceCommand = new RelayCommand(() => { var r = new ContactRowViewModel(); Grievance.Add(r); SelectedGrievance = r; });
        RemoveGrievanceCommand = new RelayCommand(() => { if (SelectedGrievance is not null) Grievance.Remove(SelectedGrievance); });
        AddEmergencyCommand = new RelayCommand(() => { var r = new ContactRowViewModel(); Emergency.Add(r); SelectedEmergency = r; });
        RemoveEmergencyCommand = new RelayCommand(() => { if (SelectedEmergency is not null) Emergency.Remove(SelectedEmergency); });
    }

    public ObservableCollection<StopRowViewModel> Stops { get; }
    public ObservableCollection<ContactRowViewModel> Grievance { get; }
    public ObservableCollection<ContactRowViewModel> Emergency { get; }
    public ICommand AddStopCommand { get; }
    public ICommand RemoveStopCommand { get; }
    public ICommand MoveStopUpCommand { get; }
    public ICommand MoveStopDownCommand { get; }
    public ICommand AddGrievanceCommand { get; }
    public ICommand RemoveGrievanceCommand { get; }
    public ICommand AddEmergencyCommand { get; }
    public ICommand RemoveEmergencyCommand { get; }

    public string Id { get => _id; set { if (Set(ref _id, value ?? "")) Raise(nameof(Title)); } }
    public string Name { get => _name; set { if (Set(ref _name, value ?? "")) Raise(nameof(Title)); } }
    public string Title => $"{(string.IsNullOrWhiteSpace(Name) ? "(unnamed bus)" : Name)}  [{Id}]";
    public string Registration { get => _registration; set => Set(ref _registration, value ?? ""); }
    public int FullFare { get => _fullFare; set => Set(ref _fullFare, value); }
    public bool AllowOffStopBoarding { get => _allowOffStop; set => Set(ref _allowOffStop, value); }
    /// Departure times from the first stop, e.g. "05:30, 13:30".
    public string DeparturesText { get => _departures; set => Set(ref _departures, value ?? ""); }

    public bool IsTwoPlusTwo { get => _right == 2; set { if (value) SetRight(2); } }
    public bool IsTwoPlusThree { get => _right == 3; set { if (value) SetRight(3); } }
    public int Rows { get => _rows; set { if (Set(ref _rows, value)) Raise(nameof(SeatSummary)); } }
    public string SeatSummary => _rows is >= 1 and <= ConfigRules.MaxRows
        ? $"{(2 + _right) * _rows} seats, {2 * _rows} of them by the window" : $"Rows must be between 1 and {ConfigRules.MaxRows}";

    public StopRowViewModel? SelectedStop { get => _selectedStop; set => Set(ref _selectedStop, value); }
    public ContactRowViewModel? SelectedGrievance { get => _selectedGrievance; set => Set(ref _selectedGrievance, value); }
    public ContactRowViewModel? SelectedEmergency { get => _selectedEmergency; set => Set(ref _selectedEmergency, value); }

    void SetRight(int right)
    {
        if (_right == right) return;
        _right = right;
        Raise(nameof(IsTwoPlusTwo)); Raise(nameof(IsTwoPlusThree)); Raise(nameof(SeatSummary));
    }

    void MoveStop(int by)
    {
        if (SelectedStop is null) return;
        int i = Stops.IndexOf(SelectedStop), j = i + by;
        if (j < 0 || j >= Stops.Count) return;
        var row = SelectedStop;
        Stops.Move(i, j);
        SelectedStop = row;
    }

    void StopsChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        if (e.OldItems is not null) foreach (StopRowViewModel s in e.OldItems) s.PropertyChanged -= StopChanged;
        if (e.NewItems is not null) foreach (StopRowViewModel s in e.NewItems) { s.PropertyChanged -= StopChanged; s.PropertyChanged += StopChanged; }
        RefreshRunningTimes();
    }

    void StopChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(StopRowViewModel.MinutesFromPrevious)) RefreshRunningTimes();
    }

    void RefreshRunningTimes()
    {
        var total = 0;
        for (var i = 0; i < Stops.Count; i++)
        {
            if (i > 0) total += Math.Max(0, Stops[i].MinutesFromPrevious);
            Stops[i].FromStart = i == 0 ? "start" : $"+{total / 60}:{total % 60:D2}";
        }
    }

    public static Result<IReadOnlyList<TimeOnly>> ParseDepartures(string text)
    {
        var times = new List<TimeOnly>();
        foreach (var part in (text ?? "").Split(new[] { ',', ';', '\n' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            if (!TimeOnly.TryParseExact(part, new[] { "H:mm", "HH:mm", "H.mm", "HH.mm" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out var t))
                return Result<IReadOnlyList<TimeOnly>>.Fail($"“{part}” is not a time. Write departures like 05:30, 13:30.");
            times.Add(t);
        }
        return Result<IReadOnlyList<TimeOnly>>.Success(times.OrderBy(t => t).ToList());
    }

    public Result<BusConfig> ToConfig()
    {
        var departures = ParseDepartures(DeparturesText);
        if (!departures.Ok) return Result<BusConfig>.Fail($"{Title}: {departures.Error}");
        var stops = Stops.Select(s => s.ToConfig()).ToList();
        if (stops.Count > 0) stops[0] = stops[0] with { MinutesFromPrevious = 0 };
        return Result<BusConfig>.Success(new BusConfig(Id.Trim(), Name.Trim(), Registration.Trim(), FullFare, new SeatLayout(2, _right, Rows),
            departures.Value!, stops, Grievance.Select(c => c.ToConfig()).ToList(), Emergency.Select(c => c.ToConfig()).ToList(), AllowOffStopBoarding));
    }
}

public sealed class TariffEditorViewModel : ObservableObject
{
    public TariffEditorViewModel(Tariff t)
    {
        (MinimumFare, WindowSurcharge, FreeCarryOnPieces, CarryOnExtraPerPiece, MaxCarryOnPieces) =
            (t.MinimumFare, t.WindowSurcharge, t.FreeCarryOnPieces, t.CarryOnExtraPerPiece, t.MaxCarryOnPieces);
        (HoldLuggagePerPiece, MaxHoldPieces, TeaPerCup, MaxTeaCups, WaitingPerMinute, MaxWaitingMinutes) =
            (t.HoldLuggagePerPiece, t.MaxHoldPieces, t.TeaPerCup, t.MaxTeaCups, t.WaitingPerMinute, t.MaxWaitingMinutes);
        (LostAndFoundFee, OffStopFeeWithLocation, OffStopFeeWithoutLocation, AdvanceBookingDays) =
            (t.LostAndFoundFee, t.OffStopFeeWithLocation, t.OffStopFeeWithoutLocation, t.AdvanceBookingDays);
        var tiers = t.RefundTiers.Where(r => r.Percent > 0).OrderByDescending(r => r.MinHoursBeforeDeparture).ToList();
        (EarlyHours, EarlyPercent) = tiers.Count > 0 ? (tiers[0].MinHoursBeforeDeparture, tiers[0].Percent) : (24, 0);
        (LateHours, LatePercent) = tiers.Count > 1 ? (tiers[1].MinHoursBeforeDeparture, tiers[1].Percent) : (2, 0);
    }

    // Plain properties: each is typed once and read on Save.
    public int MinimumFare { get; set; }
    public int WindowSurcharge { get; set; }
    public int FreeCarryOnPieces { get; set; }
    public int CarryOnExtraPerPiece { get; set; }
    public int MaxCarryOnPieces { get; set; }
    public int HoldLuggagePerPiece { get; set; }
    public int MaxHoldPieces { get; set; }
    public int TeaPerCup { get; set; }
    public int MaxTeaCups { get; set; }
    public int WaitingPerMinute { get; set; }
    public int MaxWaitingMinutes { get; set; }
    public int LostAndFoundFee { get; set; }
    public int OffStopFeeWithLocation { get; set; }
    public int OffStopFeeWithoutLocation { get; set; }
    public int AdvanceBookingDays { get; set; }
    public double EarlyHours { get; set; }
    public int EarlyPercent { get; set; }
    public double LateHours { get; set; }
    public int LatePercent { get; set; }

    public Result<Tariff> ToConfig() => EarlyHours <= LateHours
        ? Result<Tariff>.Fail("Refunds: the first cancellation period must be longer than the second.")
        : Result<Tariff>.Success(new Tariff
        {
            MinimumFare = MinimumFare, WindowSurcharge = WindowSurcharge, FreeCarryOnPieces = FreeCarryOnPieces,
            CarryOnExtraPerPiece = CarryOnExtraPerPiece, MaxCarryOnPieces = MaxCarryOnPieces, HoldLuggagePerPiece = HoldLuggagePerPiece,
            MaxHoldPieces = MaxHoldPieces, TeaPerCup = TeaPerCup, MaxTeaCups = MaxTeaCups, WaitingPerMinute = WaitingPerMinute,
            MaxWaitingMinutes = MaxWaitingMinutes, LostAndFoundFee = LostAndFoundFee, OffStopFeeWithLocation = OffStopFeeWithLocation,
            OffStopFeeWithoutLocation = OffStopFeeWithoutLocation, AdvanceBookingDays = AdvanceBookingDays,
            RefundTiers = new[] { new RefundTier(EarlyHours, EarlyPercent), new RefundTier(LateHours, LatePercent), new RefundTier(0, 0) },
        });
}

public sealed class ConfiguratorViewModel : ObservableObject
{
    readonly Func<Result<OperatorConfig>> _load;
    readonly Action<OperatorConfig> _save;
    readonly Func<BookingBook> _bookings;
    readonly Func<DateTime> _now;
    OperatorConfig? _onDisk;
    string _operatorName = "", _status = ""; bool _statusIsError;
    BusEditorViewModel? _selectedBus;
    TariffEditorViewModel _tariff = new(new Tariff());

    public ConfiguratorViewModel(string filePath, Func<Result<OperatorConfig>> load, Action<OperatorConfig> save,
        Func<BookingBook> bookings, Func<DateTime> now)
    {
        (FilePath, _load, _save, _bookings, _now) = (filePath, load, save, bookings, now);
        AddBusCommand = new RelayCommand(AddBus);
        DuplicateBusCommand = new RelayCommand(DuplicateBus);
        RemoveBusCommand = new RelayCommand(() => { if (SelectedBus is not null) { Buses.Remove(SelectedBus); SelectedBus = Buses.FirstOrDefault(); } });
        SaveCommand = new RelayCommand(Save);
        ReloadCommand = new RelayCommand(() => Load(announce: true));
        Load(announce: false);
    }

    public string FilePath { get; }
    public ObservableCollection<BusEditorViewModel> Buses { get; } = new();
    public ObservableCollection<string> Problems { get; } = new();
    public ICommand AddBusCommand { get; }
    public ICommand DuplicateBusCommand { get; }
    public ICommand RemoveBusCommand { get; }
    public ICommand SaveCommand { get; }
    public ICommand ReloadCommand { get; }

    public string OperatorName { get => _operatorName; set => Set(ref _operatorName, value ?? ""); }
    public TariffEditorViewModel Tariff { get => _tariff; private set => Set(ref _tariff, value); }
    public BusEditorViewModel? SelectedBus { get => _selectedBus; set { if (Set(ref _selectedBus, value)) Raise(nameof(HasSelectedBus)); } }
    public bool HasSelectedBus => SelectedBus is not null;
    public string Status { get => _status; private set => Set(ref _status, value); }
    public bool StatusIsError { get => _statusIsError; private set => Set(ref _statusIsError, value); }

    void Say(string message, bool error = false) { StatusIsError = error; Status = message; }

    void Show(OperatorConfig c)
    {
        OperatorName = c.OperatorName;
        Tariff = new TariffEditorViewModel(c.Tariff);
        Buses.Clear();
        foreach (var b in c.Buses) Buses.Add(new BusEditorViewModel(b));
        SelectedBus = Buses.FirstOrDefault();
        Problems.Clear();
    }

    void Load(bool announce)
    {
        var loaded = _load();
        if (!loaded.Ok)
        {
            if (Buses.Count == 0) Show(OperatorConfig.Sample);
            Say($"{loaded.Error} Nothing has been changed on disk; saving will replace the file.", error: true);
            return;
        }
        Show(loaded.Value!);
        _onDisk = loaded.Value;
        if (announce) Say("Loaded from file.");
        else Say("");
    }

    string NextBusId()
    {
        for (var n = Buses.Count + 1; ; n++)
            if (Buses.All(b => !string.Equals(b.Id.Trim(), $"B{n}", StringComparison.OrdinalIgnoreCase))) return $"B{n}";
    }

    void AddBus()
    {
        var template = OperatorConfig.Sample.Buses[0];
        var bus = new BusEditorViewModel(template with { Id = NextBusId(), Name = "New bus", Registration = "",
            GrievanceCell = Array.Empty<Contact>(), EmergencyCell = Array.Empty<Contact>() });
        Buses.Add(bus); SelectedBus = bus;
    }

    void DuplicateBus()
    {
        if (SelectedBus is null) return;
        var copy = SelectedBus.ToConfig();
        if (!copy.Ok) { Say(copy.Error!, error: true); return; }
        var bus = new BusEditorViewModel(copy.Value! with { Id = NextBusId(), Name = copy.Value!.Name + " (copy)", Registration = "" });
        Buses.Add(bus); SelectedBus = bus;
    }

    /// Build the immutable configuration from what is on screen, or the list of reasons it cannot be built.
    public (OperatorConfig? Config, IReadOnlyList<string> Problems) Build()
    {
        var problems = new List<string>();
        var tariff = Tariff.ToConfig();
        if (!tariff.Ok) problems.Add(tariff.Error!);
        var buses = Buses.Select(b => b.ToConfig()).ToList();
        problems.AddRange(buses.Where(b => !b.Ok).Select(b => b.Error!));
        if (problems.Count > 0) return (null, problems);
        var config = new OperatorConfig(1, OperatorName.Trim(), tariff.Value!, buses.Select(b => b.Value!).ToList());
        var invalid = ConfigRules.Validate(config).Concat(BookingConflicts(config)).ToList();
        return invalid.Count > 0 ? (null, invalid) : (config, problems);
    }

    /// A booking holds a seat number and stop numbers. Changing a bus's seating or its list of stops,
    /// or removing the bus, while passengers are still to travel would put them in the wrong place.
    IReadOnlyList<string> BookingConflicts(OperatorConfig next)
    {
        if (_onDisk is null) return Array.Empty<string>();
        var upcoming = _bookings().Bookings.Where(b => b.Status == BookingStatus.Confirmed && b.BoardingAt > _now()).ToList();
        var problems = new List<string>();
        foreach (var old in _onDisk.Buses)
        {
            var count = upcoming.Count(b => b.BusId == old.Id);
            if (count == 0) continue;
            var now = next.Bus(old.Id);
            var what = now is null ? "cannot be removed"
                : now.Layout != old.Layout ? "cannot have its seating changed"
                : !now.Stops.Select(s => s.Name).SequenceEqual(old.Stops.Select(s => s.Name)) ? "cannot have stops added, removed, renamed or reordered"
                : null;
            if (what is not null)
                problems.Add($"{old.Name} [{old.Id}] has {count} upcoming booking(s) and {what}. Add the new arrangement as a new bus instead, or wait until those trips are over.");
        }
        return problems;
    }

    void Save()
    {
        var (config, problems) = Build();
        Problems.Clear();
        foreach (var p in problems) Problems.Add(p);
        if (config is null) { Say($"Not saved. {problems.Count} thing(s) to fix, listed below.", error: true); return; }
        try { _save(config); _onDisk = config; Say($"Saved {config.Buses.Count} bus(es). The booking app picks this up on start, or with its Reload button."); }
        catch (Exception e) when (JsonFiles.IsFileProblem(e)) { Say($"Could not write the file: {e.Message}", error: true); }
    }
}
