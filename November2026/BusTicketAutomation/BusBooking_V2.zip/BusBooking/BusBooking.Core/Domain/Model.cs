namespace BusBooking.Core.Domain;

/// A physical seat. Column 0 is the left window; the last column is the right window.
public sealed record Seat(int Number, int Row, int Column, bool IsWindow, bool IsLeftBlock, string Label);

/// One run of one bus on one day.
public sealed record Trip(string BusId, string BusName, string LayoutText, DateOnly Date, TimeOnly Departure)
{
    public string Id => $"{BusId}-{Date:yyyyMMdd}-{Departure:HHmm}";
    public DateTime DepartureAt => Date.ToDateTime(Departure);
    public override string ToString() => $"{Departure:HH\\:mm}  {BusName} ({LayoutText})";
}

public sealed record AddOns(int CarryOnPieces, int HoldPieces, int TeaCups)
{
    public static AddOns None => new(0, 0, 0);
}

/// Boarding on the road, after the passenger's "from" stop and before the next one.
public sealed record OffStopBoarding(string Landmark, bool LocationShared, string Location);

public sealed record FareLine(string Label, int Amount)
{
    public string AmountText => Money.Text(Amount);
}

public sealed record FareBreakdown(IReadOnlyList<FareLine> Lines)
{
    public int Total => Lines.Sum(l => l.Amount);
}

public enum PayMode { UPI, Cash }
public enum BookingStatus { Confirmed, Cancelled }
public enum ChargeKind { EmergencyWaiting, LostAndFound }

/// A charge raised after booking. Never refunded.
public sealed record ExtraCharge(ChargeKind Kind, int Amount, string Note, DateTime At);

/// A booking keeps its own copy of names, seat label and times, so it still reads correctly
/// after the configuration is changed.
public sealed record Booking(
    string Id, string TripId, string BusId, string BusName,
    int SeatNumber, string SeatLabel, int From, int To, string FromName, string ToName,
    DateTime BoardingAt, OffStopBoarding? OffStop,
    string PassengerName, string Phone, PayMode Mode,
    AddOns AddOns, FareBreakdown Fare, IReadOnlyList<ExtraCharge> Extras,
    BookingStatus Status, int RefundAmount, DateTime BookedAt, DateTime? CancelledAt)
{
    public int ExtrasTotal => Extras.Sum(e => e.Amount);
    public int WaitingMinutesUsed(Tariff t) =>
        Extras.Where(e => e.Kind == ChargeKind.EmergencyWaiting).Sum(e => e.Amount) / Math.Max(1, t.WaitingPerMinute);
}

public sealed record BookingRequest(
    Trip Trip, int SeatNumber, int From, int To,
    string PassengerName, string Phone, PayMode Mode, AddOns AddOns, OffStopBoarding? OffStop);

public sealed record Result<T>(T? Value, string? Error)
{
    public bool Ok => Error is null;
    public static Result<T> Success(T value) => new(value, null);
    public static Result<T> Fail(string error) => new(default, error);
}

public static class Money
{
    public static string Text(int rupees) => rupees < 0 ? $"−₹{-rupees:N0}" : $"₹{rupees:N0}";
}
