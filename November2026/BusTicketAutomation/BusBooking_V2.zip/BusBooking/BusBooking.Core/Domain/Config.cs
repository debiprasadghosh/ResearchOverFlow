using System.Collections.Immutable;

namespace BusBooking.Core.Domain;

// Everything in this file is written by the configurator to config.json and read by the booking app.

public enum StopKind { Regular, RequestFree, RequestPaid }

/// One stop of a bus. MinutesFromPrevious is the running time from the stop before (0 for the first stop).
/// A request stop is one where the bus halts only when asked, free or for RequestFee rupees.
public sealed record StopConfig(string Name, double Km, int MinutesFromPrevious, StopKind Kind, int RequestFee);

/// Seats per row left and right of the aisle (2 + 2 or 2 + 3) and the number of rows.
public sealed record SeatLayout(int Left, int Right, int Rows)
{
    public int PerRow => Left + Right;
    public int SeatCount => PerRow * Rows;
    public override string ToString() => $"{Left} + {Right}, {Rows} rows";
}

public sealed record Contact(string Name, string Role, string Mobile);

public sealed record BusConfig(
    string Id, string Name, string Registration, int FullFare, SeatLayout Layout,
    IReadOnlyList<TimeOnly> Departures, IReadOnlyList<StopConfig> Stops,
    IReadOnlyList<Contact> GrievanceCell, IReadOnlyList<Contact> EmergencyCell,
    bool AllowOffStopBoarding)
{
    public override string ToString() => $"{Name} ({Layout.Left}+{Layout.Right})";
}

public sealed record RefundTier(double MinHoursBeforeDeparture, int Percent);

/// Charges and limits common to all buses.
public sealed record Tariff
{
    public int MinimumFare { get; init; } = 20;
    public int WindowSurcharge { get; init; } = 10;
    public int FreeCarryOnPieces { get; init; } = 1;
    public int CarryOnExtraPerPiece { get; init; } = 20;
    public int MaxCarryOnPieces { get; init; } = 3;
    public int HoldLuggagePerPiece { get; init; } = 30;
    public int MaxHoldPieces { get; init; } = 4;
    public int TeaPerCup { get; init; } = 15;
    public int MaxTeaCups { get; init; } = 4;
    public int WaitingPerMinute { get; init; } = 20;
    public int MaxWaitingMinutes { get; init; } = 5;
    public int LostAndFoundFee { get; init; } = 50;
    public int OffStopFeeWithLocation { get; init; } = 30;
    public int OffStopFeeWithoutLocation { get; init; } = 50;
    public int AdvanceBookingDays { get; init; } = 30;
    public IReadOnlyList<RefundTier> RefundTiers { get; init; } = ImmutableArray.Create(
        new RefundTier(24, 90), new RefundTier(2, 50), new RefundTier(0, 0));
}

public sealed record OperatorConfig(int Version, string OperatorName, Tariff Tariff, IReadOnlyList<BusConfig> Buses)
{
    public BusConfig? Bus(string id) => Buses.FirstOrDefault(b => b.Id == id);

    /// A starting point so both apps open with something to show. Names and numbers are placeholders.
    public static OperatorConfig Sample
    {
        get
        {
            var stops = ImmutableArray.Create(
                new StopConfig("Bishnupur", 0, 0, StopKind.Regular, 0),
                new StopConfig("Joypur", 14, 25, StopKind.RequestFree, 0),
                new StopConfig("Kotulpur", 30, 30, StopKind.Regular, 0),
                new StopConfig("Arambagh", 54, 45, StopKind.Regular, 0),
                new StopConfig("Champadanga", 82, 50, StopKind.RequestPaid, 10),
                new StopConfig("Dankuni", 120, 65, StopKind.Regular, 0),
                new StopConfig("Esplanade", 140, 40, StopKind.Regular, 0));
            var grievance = ImmutableArray.Create(new Contact("Sample name", "Stand desk, Bishnupur", "9000000001"));
            var emergency = ImmutableArray.Create(new Contact("Sample name", "Owner's office", "9000000002"),
                                                  new Contact("Sample name", "Conductor", "9000000003"));
            return new OperatorConfig(1, "Sample operator", new Tariff(), ImmutableArray.Create(
                new BusConfig("B1", "Morning Express", "WB-00-A-0001", 240, new SeatLayout(2, 2, 10),
                    ImmutableArray.Create(new TimeOnly(5, 30), new TimeOnly(13, 30)), stops, grievance, emergency, true),
                new BusConfig("B2", "Day Service", "WB-00-A-0002", 220, new SeatLayout(2, 3, 10),
                    ImmutableArray.Create(new TimeOnly(7, 0)), stops, grievance, emergency, true)));
        }
    }
}

public static class ConfigRules
{
    public const int MaxStops = 30;      // sections are held in a 32-bit mask
    public const int MaxRows = 20;

    static bool IsMobile(string? s) => s is not null && s.Count(char.IsDigit) == 10 && s.All(c => char.IsDigit(c) || c is ' ' or '-');

    /// Every problem that should stop a configuration being saved, in plain words. Empty means valid.
    public static IReadOnlyList<string> Validate(OperatorConfig c)
    {
        var e = new List<string>();
        var t = c.Tariff;
        if (c.Buses.Count == 0) e.Add("Add at least one bus.");
        foreach (var dup in c.Buses.GroupBy(b => b.Id.Trim(), StringComparer.OrdinalIgnoreCase).Where(g => g.Count() > 1))
            e.Add($"Bus ID “{dup.Key}” is used more than once.");
        if (new[] { t.MinimumFare, t.WindowSurcharge, t.FreeCarryOnPieces, t.CarryOnExtraPerPiece, t.MaxCarryOnPieces, t.HoldLuggagePerPiece,
                    t.MaxHoldPieces, t.TeaPerCup, t.MaxTeaCups, t.WaitingPerMinute, t.LostAndFoundFee, t.OffStopFeeWithLocation,
                    t.OffStopFeeWithoutLocation }.Any(v => v < 0))
            e.Add("Charges and limits cannot be negative.");
        if (t.MaxWaitingMinutes is < 1 or > 5) e.Add("Emergency waiting must be limited to between 1 and 5 minutes.");
        if (t.AdvanceBookingDays is < 0 or > 365) e.Add("Advance booking must be between 0 and 365 days.");
        if (t.RefundTiers.Any(r => r.Percent is < 0 or > 100 || r.MinHoursBeforeDeparture < 0)) e.Add("Refund percentages must be between 0 and 100.");

        foreach (var b in c.Buses)
        {
            var who = string.IsNullOrWhiteSpace(b.Name) ? $"Bus {b.Id}" : b.Name;
            if (string.IsNullOrWhiteSpace(b.Id)) e.Add($"{who}: give the bus an ID.");
            if (string.IsNullOrWhiteSpace(b.Name)) e.Add($"Bus {b.Id}: give the bus a name.");
            if (b.FullFare <= 0) e.Add($"{who}: the full-route fare must be more than zero.");
            if (b.Layout.Left != 2 || b.Layout.Right is not (2 or 3)) e.Add($"{who}: seating must be 2 + 2 or 2 + 3.");
            if (b.Layout.Rows is < 1 or > MaxRows) e.Add($"{who}: rows must be between 1 and {MaxRows}.");
            if (b.Departures.Count == 0) e.Add($"{who}: add at least one departure time.");
            if (b.Departures.Distinct().Count() != b.Departures.Count) e.Add($"{who}: a departure time is repeated.");
            if (b.Stops.Count is < 2 or > MaxStops) e.Add($"{who}: a bus needs between 2 and {MaxStops} stops.");
            for (var i = 0; i < b.Stops.Count; i++)
            {
                var s = b.Stops[i]; var name = string.IsNullOrWhiteSpace(s.Name) ? $"stop {i + 1}" : s.Name;
                if (string.IsNullOrWhiteSpace(s.Name)) e.Add($"{who}: stop {i + 1} has no name.");
                if (i == 0 && s.Km != 0) e.Add($"{who}: the first stop must be at 0 km.");
                if (i > 0 && s.Km <= b.Stops[i - 1].Km) e.Add($"{who}: {name} must be further along the road than the stop before it.");
                if (i > 0 && s.MinutesFromPrevious < 1) e.Add($"{who}: {name} needs a running time from the previous stop.");
                if (s.RequestFee < 0) e.Add($"{who}: {name} has a negative request fee.");
                if (s.Kind == StopKind.RequestPaid && s.RequestFee <= 0) e.Add($"{who}: {name} is a request stop with a fee, but the fee is zero.");
            }
            foreach (var dup in b.Stops.GroupBy(s => s.Name.Trim(), StringComparer.OrdinalIgnoreCase).Where(g => g.Key != "" && g.Count() > 1))
                e.Add($"{who}: stop “{dup.Key}” appears more than once.");
            foreach (var (cell, label) in new[] { (b.GrievanceCell, "grievance cell"), (b.EmergencyCell, "emergency cell") })
            {
                if (cell.Count == 0) e.Add($"{who}: the {label} needs at least one member.");
                foreach (var m in cell)
                {
                    if (string.IsNullOrWhiteSpace(m.Name)) e.Add($"{who}: a {label} member has no name.");
                    if (!IsMobile(m.Mobile)) e.Add($"{who}: {label} member {m.Name} needs a 10-digit mobile number.");
                }
            }
        }
        return e;
    }
}
