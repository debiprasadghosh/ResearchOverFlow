using System.Collections.Immutable;

namespace BusBooking.Core.Domain;

/// Facts derived from one bus's configuration.
public static class BusRules
{
    public static IReadOnlyList<Seat> Seats(BusConfig bus)
    {
        var l = bus.Layout;
        return Enumerable.Range(0, l.SeatCount).Select(i =>
        {
            int row = i / l.PerRow, col = i % l.PerRow;
            return new Seat(i + 1, row, col, col == 0 || col == l.PerRow - 1, col < l.Left, $"{row + 1}{(char)('A' + col)}");
        }).ToImmutableArray();
    }

    public static int LastStop(BusConfig bus) => bus.Stops.Count - 1;

    /// Bitmask of the road sections occupied by a journey from stop `from` to stop `to`.
    public static int Mask(int from, int to) => (int)(((1u << to) - 1) & ~((1u << from) - 1));

    public static int MinutesTo(BusConfig bus, int stop) => bus.Stops.Take(stop + 1).Skip(1).Sum(s => s.MinutesFromPrevious);

    /// Scheduled time of this trip at a stop.
    public static DateTime TimeAt(BusConfig bus, Trip trip, int stop) => trip.DepartureAt.AddMinutes(MinutesTo(bus, stop));

    public static IReadOnlyList<Trip> TripsOn(OperatorConfig config, DateOnly date) =>
        config.Buses.SelectMany(b => b.Departures.Select(d => new Trip(b.Id, b.Name, $"{b.Layout.Left}+{b.Layout.Right}", date, d)))
              .OrderBy(t => t.Departure).ThenBy(t => t.BusName).ToImmutableArray();
}

public static class Pricing
{
    public static int SectionFare(BusConfig bus, int from, int to, Tariff t)
    {
        var km = bus.Stops[to].Km - bus.Stops[from].Km;
        var total = bus.Stops[BusRules.LastStop(bus)].Km;
        return Math.Max(t.MinimumFare, 5 * (int)Math.Round(bus.FullFare * km / total / 5.0));
    }

    public static int OffStopFee(OffStopBoarding o, Tariff t) => o.LocationShared ? t.OffStopFeeWithLocation : t.OffStopFeeWithoutLocation;

    /// Everything payable at the time of booking, line by line.
    public static FareBreakdown Quote(BusConfig bus, Seat seat, int from, int to, AddOns a, OffStopBoarding? offStop, Tariff t)
    {
        var lines = ImmutableArray.CreateBuilder<FareLine>();
        StopConfig f = bus.Stops[from], d = bus.Stops[to];
        lines.Add(new FareLine($"Seat fare, {f.Name} to {d.Name}", SectionFare(bus, from, to, t)));
        if (seat.IsWindow) lines.Add(new FareLine("Window seat", t.WindowSurcharge));
        if (offStop is not null)
            lines.Add(new FareLine($"Boarding on the road after {f.Name} ({(offStop.LocationShared ? "location shared" : "no location shared")})", OffStopFee(offStop, t)));
        else if (f.Kind == StopKind.RequestPaid)
            lines.Add(new FareLine($"Request stop, {f.Name}", f.RequestFee));
        if (d.Kind == StopKind.RequestPaid)
            lines.Add(new FareLine($"Request stop, {d.Name}", d.RequestFee));
        var paidCarryOn = Math.Max(0, a.CarryOnPieces - t.FreeCarryOnPieces);
        if (a.CarryOnPieces > 0)
            lines.Add(new FareLine($"Carry-on luggage × {a.CarryOnPieces} (first {t.FreeCarryOnPieces} free)", paidCarryOn * t.CarryOnExtraPerPiece));
        if (a.HoldPieces > 0)
            lines.Add(new FareLine($"Luggage in the hold × {a.HoldPieces}", a.HoldPieces * t.HoldLuggagePerPiece));
        if (a.TeaCups > 0)
            lines.Add(new FareLine($"Tea × {a.TeaCups}", a.TeaCups * t.TeaPerCup));
        return new FareBreakdown(lines.ToImmutable());
    }

    public static Result<int> WaitingCharge(int minutes, Tariff t) =>
        minutes < 1 || minutes > t.MaxWaitingMinutes
            ? Result<int>.Fail($"The bus can wait between 1 and {t.MaxWaitingMinutes} minutes.")
            : Result<int>.Success(minutes * t.WaitingPerMinute);

    /// Refund on cancellation: a percentage of what was paid at booking, by time left before the
    /// passenger's own boarding time. Later charges are not refunded.
    public static (int Percent, int Amount) Refund(Booking b, DateTime now, Tariff t)
    {
        var hours = (b.BoardingAt - now).TotalHours;
        var tier = t.RefundTiers.OrderByDescending(r => r.MinHoursBeforeDeparture)
            .FirstOrDefault(r => hours >= r.MinHoursBeforeDeparture);
        var percent = tier?.Percent ?? 0;
        return (percent, b.Fare.Total * percent / 100);
    }
}

/// The whole booking register as one immutable value. Every operation returns a new register or an error.
public sealed record BookingBook(ImmutableList<Booking> Bookings, int NextSerial)
{
    public static BookingBook Empty => new(ImmutableList<Booking>.Empty, 1);

    /// Sections of this seat already sold on this trip.
    public int OccupiedMask(string tripId, int seatNumber) =>
        Bookings.Where(b => b.Status == BookingStatus.Confirmed && b.TripId == tripId && b.SeatNumber == seatNumber)
                .Aggregate(0, (m, b) => m | BusRules.Mask(b.From, b.To));

    public bool IsFree(string tripId, int seatNumber, int from, int to) =>
        (OccupiedMask(tripId, seatNumber) & BusRules.Mask(from, to)) == 0;

    public Booking? Find(string id) => Bookings.FirstOrDefault(b => b.Id == id);

    public Result<BookingBook> Book(BookingRequest r, BusConfig bus, DateTime now, Tariff t)
    {
        var phone = new string((r.Phone ?? "").Where(char.IsDigit).ToArray());
        var today = DateOnly.FromDateTime(now);
        var validStops = r.From >= 0 && r.To <= BusRules.LastStop(bus) && r.From < r.To;
        var error =
            r.Trip.BusId != bus.Id ? "This trip does not belong to that bus."
            : string.IsNullOrWhiteSpace(r.PassengerName) ? "Enter the passenger's name."
            : phone.Length != 10 ? "Enter a 10-digit mobile number."
            : !validStops ? "Choose a boarding stop before the alighting stop."
            : r.SeatNumber < 1 || r.SeatNumber > bus.Layout.SeatCount ? "Choose a seat."
            : r.Trip.Date < today || r.Trip.Date > today.AddDays(t.AdvanceBookingDays) ? $"Booking is open from today up to {t.AdvanceBookingDays} days ahead."
            : BusRules.TimeAt(bus, r.Trip, r.From) <= now ? $"This bus has already passed {bus.Stops[r.From].Name}."
            : r.OffStop is not null && !bus.AllowOffStopBoarding ? "This bus takes passengers only at its stops."
            : r.OffStop is not null && string.IsNullOrWhiteSpace(r.OffStop.Landmark) ? "Say where on the road you will be waiting (a landmark)."
            : r.OffStop is { LocationShared: true } && string.IsNullOrWhiteSpace(r.OffStop.Location) ? "Paste your location, or untick location sharing."
            : r.AddOns.CarryOnPieces < 0 || r.AddOns.CarryOnPieces > t.MaxCarryOnPieces ? $"Carry-on is limited to {t.MaxCarryOnPieces} pieces."
            : r.AddOns.HoldPieces < 0 || r.AddOns.HoldPieces > t.MaxHoldPieces ? $"Hold luggage is limited to {t.MaxHoldPieces} pieces."
            : r.AddOns.TeaCups < 0 || r.AddOns.TeaCups > t.MaxTeaCups ? $"Tea is limited to {t.MaxTeaCups} cups."
            : !IsFree(r.Trip.Id, r.SeatNumber, r.From, r.To) ? "That seat is already taken on part of this journey."
            : null;
        if (error is not null) return Result<BookingBook>.Fail(error);

        var seat = BusRules.Seats(bus)[r.SeatNumber - 1];
        var offStop = r.OffStop is null ? null
            : r.OffStop with { Landmark = r.OffStop.Landmark.Trim(), Location = r.OffStop.LocationShared ? r.OffStop.Location.Trim() : "" };
        var booking = new Booking(
            $"BK{NextSerial:D5}", r.Trip.Id, bus.Id, bus.Name, r.SeatNumber, seat.Label, r.From, r.To,
            bus.Stops[r.From].Name, bus.Stops[r.To].Name, BusRules.TimeAt(bus, r.Trip, r.From), offStop,
            r.PassengerName.Trim(), phone, r.Mode, r.AddOns,
            Pricing.Quote(bus, seat, r.From, r.To, r.AddOns, offStop, t),
            ImmutableArray<ExtraCharge>.Empty, BookingStatus.Confirmed, 0, now, null);
        return Result<BookingBook>.Success(new BookingBook(Bookings.Add(booking), NextSerial + 1));
    }

    public Result<BookingBook> Cancel(string id, DateTime now, Tariff t) => Find(id) switch
    {
        null => Result<BookingBook>.Fail("Booking not found."),
        { Status: BookingStatus.Cancelled } => Result<BookingBook>.Fail("This booking is already cancelled."),
        var b when b.BoardingAt <= now => Result<BookingBook>.Fail("The boarding time has passed; this booking can no longer be cancelled."),
        var b => Replace(b, b with { Status = BookingStatus.Cancelled, CancelledAt = now, RefundAmount = Pricing.Refund(b, now, t).Amount }),
    };

    public Result<BookingBook> AddWaiting(string id, int minutes, DateTime now, Tariff t)
    {
        var b = Find(id);
        if (b is null) return Result<BookingBook>.Fail("Booking not found.");
        if (b.Status != BookingStatus.Confirmed) return Result<BookingBook>.Fail("Only a confirmed booking can ask the bus to wait.");
        var charge = Pricing.WaitingCharge(minutes, t);
        if (!charge.Ok) return Result<BookingBook>.Fail(charge.Error!);
        var used = b.WaitingMinutesUsed(t);
        if (used + minutes > t.MaxWaitingMinutes)
            return Result<BookingBook>.Fail($"Only {t.MaxWaitingMinutes - used} more minute(s) of waiting can be added to this booking.");
        return AddExtra(b, new ExtraCharge(ChargeKind.EmergencyWaiting, charge.Value, $"Emergency waiting, {minutes} min", now));
    }

    public Result<BookingBook> AddLostAndFound(string id, string item, DateTime now, Tariff t)
    {
        var b = Find(id);
        if (b is null) return Result<BookingBook>.Fail("Booking not found.");
        if (b.Status != BookingStatus.Confirmed) return Result<BookingBook>.Fail("Lost and found needs a confirmed booking.");
        if (string.IsNullOrWhiteSpace(item)) return Result<BookingBook>.Fail("Describe the lost item.");
        return AddExtra(b, new ExtraCharge(ChargeKind.LostAndFound, t.LostAndFoundFee, $"Lost and found: {item.Trim()}", now));
    }

    Result<BookingBook> AddExtra(Booking b, ExtraCharge e) =>
        Replace(b, b with { Extras = b.Extras.Append(e).ToImmutableArray() });

    Result<BookingBook> Replace(Booking old, Booking updated) =>
        Result<BookingBook>.Success(this with { Bookings = Bookings.Replace(old, updated) });
}
