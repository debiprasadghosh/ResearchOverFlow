using System.Text.Json;
using System.Text.Json.Serialization;

namespace BusBooking.Core.Domain;

/// Where the two JSON files live. Both apps use the same folder, so the configurator's
/// config.json is the one the booking app reads. A folder given on the command line wins.
public static class AppPaths
{
    public static string Folder(IReadOnlyList<string> args) => args.Count > 0 && !string.IsNullOrWhiteSpace(args[0])
        ? Path.GetFullPath(args[0])
        : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BusBooking");
    public static string Config(IReadOnlyList<string> args) => Path.Combine(Folder(args), "config.json");
    public static string Bookings(IReadOnlyList<string> args) => Path.Combine(Folder(args), "bookings.json");
}

public static class JsonFiles
{
    public static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        Converters = { new JsonStringEnumConverter() },
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    };

    public static bool IsFileProblem(Exception e) =>
        e is JsonException or IOException or NotSupportedException or UnauthorizedAccessException or ArgumentException;

    /// Write to a temporary file first, then swap, so a reader never sees half a file.
    public static void Write<T>(string path, T value)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))!);
        var temp = path + ".tmp";
        File.WriteAllText(temp, JsonSerializer.Serialize(value, Options));
        File.Move(temp, path, overwrite: true);
    }
}

/// What came back from reading config.json: a configuration to use, and a note if something was wrong.
public sealed record ConfigLoad(OperatorConfig Config, string? Problem);

public static class ConfigRepository
{
    public static ConfigLoad Load(string path)
    {
        if (!File.Exists(path))
            return new ConfigLoad(OperatorConfig.Sample, "No configuration file yet; showing the sample buses. Save from the configurator to create one.");
        try
        {
            var config = JsonSerializer.Deserialize<OperatorConfig>(File.ReadAllText(path), JsonFiles.Options);
            if (config is null || config.Buses is null || config.Tariff is null)
                return new ConfigLoad(OperatorConfig.Sample, "The configuration file is incomplete; showing the sample buses.");
            var errors = ConfigRules.Validate(config);
            return errors.Count == 0 ? new ConfigLoad(config, null)
                : new ConfigLoad(OperatorConfig.Sample, $"The configuration file has a problem ({errors[0]}); showing the sample buses.");
        }
        catch (Exception e) when (JsonFiles.IsFileProblem(e) || e is NullReferenceException)
        {
            return new ConfigLoad(OperatorConfig.Sample, "The configuration file could not be read; showing the sample buses.");
        }
    }

    /// Reads the file for editing: a broken file is reported, not replaced.
    public static Result<OperatorConfig> LoadForEditing(string path)
    {
        if (!File.Exists(path)) return Result<OperatorConfig>.Success(OperatorConfig.Sample);
        try
        {
            var config = JsonSerializer.Deserialize<OperatorConfig>(File.ReadAllText(path), JsonFiles.Options);
            return config is null || config.Buses is null || config.Tariff is null
                ? Result<OperatorConfig>.Fail("The configuration file is incomplete.")
                : Result<OperatorConfig>.Success(config);
        }
        catch (Exception e) when (JsonFiles.IsFileProblem(e))
        {
            return Result<OperatorConfig>.Fail($"The configuration file could not be read: {e.Message}");
        }
    }

    public static void Save(string path, OperatorConfig config) => JsonFiles.Write(path, config);
}

/// Saves the booking register as one JSON file. A missing or unreadable file gives an empty register.
public static class BookingRepository
{
    public static BookingBook Load(string path)
    {
        try
        {
            return File.Exists(path)
                ? JsonSerializer.Deserialize<BookingBook>(File.ReadAllText(path), JsonFiles.Options) is { Bookings: not null } book ? book : BookingBook.Empty
                : BookingBook.Empty;
        }
        catch (Exception e) when (JsonFiles.IsFileProblem(e))
        {
            if (File.Exists(path)) File.Copy(path, path + ".unreadable", overwrite: true);   // keep the damaged file
            return BookingBook.Empty;
        }
    }

    public static void Save(string path, BookingBook book) => JsonFiles.Write(path, book);
}
