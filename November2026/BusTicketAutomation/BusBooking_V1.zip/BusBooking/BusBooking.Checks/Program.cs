// Plain console checks for the booking rules and the view-model. Run: dotnet run --project BusBooking.Checks
using BusBooking.Core.Domain;
using BusBooking.Core.ViewModels;

var failures = 0;
void Check(string name, bool ok) { Console.WriteLine($"{(ok ? "ok  " : "FAIL")}  {name}"); if (!ok) failures++; }

var t = new Tariff();
var now = new DateTime(2026, 11, 10, 9, 0, 0);
var trip = new Trip(new DateOnly(2026, 11, 12), new TimeOnly(7, 0), "Day Service");      // 46 h ahead
BookingRequest Req(int seat, int from, int to, AddOns? a = null, Trip? tr = null) =>
    new(tr ?? trip, seat, from, to, "Test Passenger", "98300 12345", PayMode.UPI, a ?? AddOns.None);

// pricing
Check("full fare is 240", Pricing.SectionFare(0, 6, t) == 240);
Check("window seat adds surcharge", Pricing.Quote(Route.Seat(1), 0, 6, AddOns.None, t).Total == 250);
Check("aisle seat has no surcharge", Pricing.Quote(Route.Seat(2), 0, 6, AddOns.None, t).Total == 240);
Check("first carry-on free, 2 extra + 2 hold + 3 tea", Pricing.Quote(Route.Seat(2), 0, 6, new AddOns(3, 2, 3), t).Total == 240 + 40 + 60 + 45);
Check("waiting 5 min = 100", Pricing.WaitingCharge(5, t).Value == 100);
Check("waiting 6 min refused", !Pricing.WaitingCharge(6, t).Ok);
Check("waiting 0 min refused", !Pricing.WaitingCharge(0, t).Ok);

// booking and section reuse
var b1 = BookingBook.Empty.Book(Req(1, 0, 3), now, t);
Check("book seat 1 Bishnupur-Arambagh", b1.Ok);
Check("overlap refused", !b1.Value!.Book(Req(1, 2, 6), now, t).Ok);
var b2 = b1.Value!.Book(Req(1, 3, 6), now, t);
Check("same seat resold from Arambagh onward", b2.Ok);
Check("bad phone refused", !BookingBook.Empty.Book(Req(1, 0, 3) with { Phone = "123" }, now, t).Ok);
Check("empty name refused", !BookingBook.Empty.Book(Req(1, 0, 3) with { PassengerName = " " }, now, t).Ok);
Check("31 days ahead refused", !BookingBook.Empty.Book(Req(1, 0, 3, tr: trip with { Date = new DateOnly(2026, 12, 11) }), now, t).Ok);
Check("30 days ahead allowed", BookingBook.Empty.Book(Req(1, 0, 3, tr: trip with { Date = new DateOnly(2026, 12, 10) }), now, t).Ok);
Check("departed bus refused", !BookingBook.Empty.Book(Req(1, 0, 3, tr: trip with { Date = new DateOnly(2026, 11, 10) }), now, t).Ok);
Check("too much hold luggage refused", !BookingBook.Empty.Book(Req(1, 0, 3, new AddOns(0, 9, 0)), now, t).Ok);

// cancellation tiers (booking total 250: window, full route)
var book = BookingBook.Empty.Book(Req(1, 0, 6), now, t).Value!;
var id = book.Bookings[0].Id;
Check("cancel 46 h before: 90%", book.Cancel(id, now, t).Value!.Find(id)!.RefundAmount == 225);
Check("cancel 10 h before: 50%", book.Cancel(id, trip.DepartureAt.AddHours(-10), t).Value!.Find(id)!.RefundAmount == 125);
Check("cancel 1 h before: 0%", book.Cancel(id, trip.DepartureAt.AddHours(-1), t).Value!.Find(id)!.RefundAmount == 0);
Check("cancel after departure refused", !book.Cancel(id, trip.DepartureAt.AddMinutes(1), t).Ok);
var cancelled = book.Cancel(id, now, t).Value!;
Check("double cancel refused", !cancelled.Cancel(id, now, t).Ok);
Check("cancelled seat is free again", cancelled.IsFree(trip.Id, 1, 0, 6));

// later charges
var w = book.AddWaiting(id, 3, now, t).Value!;
Check("waiting 3 min recorded", w.Find(id)!.ExtrasTotal == 60);
Check("waiting 3 + 3 refused (cap 5)", !w.AddWaiting(id, 3, now, t).Ok);
Check("waiting 3 + 2 allowed", w.AddWaiting(id, 2, now, t).Value!.Find(id)!.ExtrasTotal == 100);
var lf = w.AddLostAndFound(id, "umbrella", now, t).Value!;
Check("lost and found fee added", lf.Find(id)!.ExtrasTotal == 110);
Check("lost and found needs a description", !w.AddLostAndFound(id, "", now, t).Ok);
Check("extras are not refunded", lf.Cancel(id, now, t).Value!.Find(id)!.RefundAmount == 225);
Check("no waiting on a cancelled booking", !cancelled.AddWaiting(id, 1, now, t).Ok);

// persistence round trip
var path = Path.Combine(Path.GetTempPath(), $"busbooking-{Guid.NewGuid():N}.json");
BookingRepository.Save(path, lf);
var loaded = BookingRepository.Load(path);
Check("save and load round trip", loaded.NextSerial == lf.NextSerial && loaded.Find(id)!.ExtrasTotal == 110
    && loaded.Find(id)!.Fare.Total == 250 && !loaded.IsFree(trip.Id, 1, 0, 6));
File.WriteAllText(path, "{ not json");
Check("damaged file gives empty register", BookingRepository.Load(path).Bookings.Count == 0);
File.Delete(path); File.Delete(path + ".unreadable");

// view-model
BookingBook? saved = null;
var vm = new MainViewModel(BookingBook.Empty, t, () => now, bk => saved = bk);
Check("vm: today 09:00 offers only the 13:30 bus", vm.Trips.Count == 1 && vm.SelectedTrip!.Departure == new TimeOnly(13, 30));
vm.TravelDate = new DateTime(2026, 11, 12);
Check("vm: later date offers three buses", vm.Trips.Count == 3);
Check("vm: date beyond window is clamped", (vm.TravelDate = new DateTime(2027, 1, 1)) is not null && vm.TravelDate == vm.MaxDate);
vm.TravelDate = new DateTime(2026, 11, 12);
vm.PickWindowSeatCommand.Execute(null);
Check("vm: picks window seat 1A", vm.SelectedSeat?.Label == "1A" && vm.Total == "₹250");
vm.Tea = 2; vm.Hold = 1;
Check("vm: quote follows add-ons", vm.Total == "₹310");
vm.BookCommand.Execute(null);
Check("vm: booking without name shows error", vm.StatusIsError && saved is null);
vm.PassengerName = "Asha"; vm.Phone = "9830012345";
vm.BookCommand.Execute(null);
Check("vm: booked and saved", !vm.StatusIsError && saved?.Bookings.Count == 1 && vm.Bookings.Count == 1);
Check("vm: seat now shown taken, selection cleared", vm.Seats[0].IsTaken && vm.SelectedSeat is null && !vm.CanBook);
vm.FromStop = Route.Stops[3];
Check("vm: changing boarding stop keeps a valid destination", vm.ToStop.Index == 6 && vm.ToStops.Count == 3 && vm.Seats[0].IsTaken);
vm.FromStop = Route.Stops[0]; vm.ToStop = Route.Stops[6];
vm.WindowOnly = true;
Check("vm: window filter dims aisle seats", vm.Seats[1].IsDimmed && !vm.Seats[3].IsDimmed && !vm.Seats[1].CanSelect);
vm.SelectedBooking = vm.Bookings[0];
vm.WaitingMinutes = 5; vm.AddWaitingCommand.Execute(null);
vm.AddWaitingCommand.Execute(null);
Check("vm: second 5-minute wait refused", vm.StatusIsError && vm.SelectedBooking!.Booking.ExtrasTotal == 100);
vm.LostItem = "tiffin box"; vm.AddLostAndFoundCommand.Execute(null);
Check("vm: lost and found added, box cleared", vm.SelectedBooking!.Booking.ExtrasTotal == 150 && vm.LostItem == "");
vm.CancelCommand.Execute(null);
Check("vm: cancel frees the seat and shows refund", !vm.Seats[0].IsTaken && vm.SelectedBooking!.Status == "Cancelled" && vm.RefundPreview.Contains("₹279"));

Console.WriteLine(failures == 0 ? "\nAll checks passed." : $"\n{failures} check(s) FAILED.");
return failures == 0 ? 0 : 1;
