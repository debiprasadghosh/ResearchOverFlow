using System.Collections.Immutable;

namespace BusBooking.Core.Domain;

public sealed record Stop(int Index, string Name, double Km)
{
    public override string ToString() => Name;
}

/// A physical seat. Layout is 2 + 2: columns A B | aisle | C D. A and D are window seats.
public sealed record Seat(int Number, int Row, int Column)
{
    public bool IsWindow => Column is 0 or 3;
    public string Label => $"{Row + 1}{"ABCD"[Column]}";
}

public sealed record Trip(DateOnly Date, TimeOnly Departure, string BusName)
{
    public string Id => $"{Date:yyyyMMdd}-{Departure:HHmm}";
    public DateTime DepartureAt => Date.ToDateTime(Departure);
    public override string ToString() => $"{Departure:HH\\:mm}  {BusName}";
}

public sealed record RefundTier(double MinHoursBeforeDeparture, int Percent);

/// Every price and limit in one place. Change the numbers here, not in the logic.
public sealed record Tariff
{
    public int FullFare { get; init; } = 240;
    public int MinimumFare { get; init; } = 20;
    public int WindowSurcharge { get; init; } = 10;
    public int FreeCarryOnPieces { get; init; } = 1;
    public int CarryOnExtraPerPiece { get; init; } = 20;
    public int MaxCarryOnPieces { get; init; } = 3;
    public int HoldLuggagePerPiece { get; init; } = 30;
    public int MaxHoldPieces { get; init; } = 4;
    public int TeaPerCup { get; init; } = 15;
    public int MaxTeaCups { get; init; } = 4;
    public int WaitingPerMinute { get; init; } = 20;
    public int MaxWaitingMinutes { get; init; } = 5;
    public int LostAndFoundFee { get; init; } = 50;
    public int AdvanceBookingDays { get; init; } = 30;
    /// Highest tier whose threshold is met applies. Listed from most to least generous.
    public IReadOnlyList<RefundTier> RefundTiers { get; init; } = ImmutableArray.Create(
        new RefundTier(24, 90), new RefundTier(2, 50), new RefundTier(0, 0));
}

public sealed record AddOns(int CarryOnPieces, int HoldPieces, int TeaCups)
{
    public static AddOns None => new(0, 0, 0);
}

public sealed record FareLine(string Label, int Amount)
{
    public string AmountText => Money.Text(Amount);
}

public sealed record FareBreakdown(IReadOnlyList<FareLine> Lines)
{
    public int Total => Lines.Sum(l => l.Amount);
}

public enum PayMode { UPI, Cash }
public enum BookingStatus { Confirmed, Cancelled }
public enum ChargeKind { EmergencyWaiting, LostAndFound }

/// A charge raised after booking. Never refunded.
public sealed record ExtraCharge(ChargeKind Kind, int Amount, string Note, DateTime At);

public sealed record Booking(
    string Id, string TripId, DateTime DepartureAt, string BusName,
    int SeatNumber, int From, int To,
    string PassengerName, string Phone, PayMode Mode,
    AddOns AddOns, FareBreakdown Fare, IReadOnlyList<ExtraCharge> Extras,
    BookingStatus Status, int RefundAmount, DateTime BookedAt, DateTime? CancelledAt)
{
    public int ExtrasTotal => Extras.Sum(e => e.Amount);
    public int WaitingMinutesUsed(Tariff t) =>
        Extras.Where(e => e.Kind == ChargeKind.EmergencyWaiting).Sum(e => e.Amount) / Math.Max(1, t.WaitingPerMinute);
}

public sealed record BookingRequest(
    Trip Trip, int SeatNumber, int From, int To,
    string PassengerName, string Phone, PayMode Mode, AddOns AddOns);

public sealed record Result<T>(T? Value, string? Error)
{
    public bool Ok => Error is null;
    public static Result<T> Success(T value) => new(value, null);
    public static Result<T> Fail(string error) => new(default, error);
}

public static class Money
{
    public static string Text(int rupees) => rupees < 0 ? $"−₹{-rupees:N0}" : $"₹{rupees:N0}";
}
