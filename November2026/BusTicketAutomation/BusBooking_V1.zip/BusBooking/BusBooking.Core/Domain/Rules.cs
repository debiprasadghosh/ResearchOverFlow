using System.Collections.Immutable;

namespace BusBooking.Core.Domain;

public static class Route
{
    // Illustrative stop list and distances; replace with the operator's own chart.
    public static readonly IReadOnlyList<Stop> Stops = ImmutableArray.Create(
        new Stop(0, "Bishnupur", 0), new Stop(1, "Joypur", 14), new Stop(2, "Kotulpur", 30),
        new Stop(3, "Arambagh", 54), new Stop(4, "Champadanga", 82), new Stop(5, "Dankuni", 120),
        new Stop(6, "Esplanade", 140));

    public const int Rows = 10;
    public static readonly IReadOnlyList<Seat> Seats =
        Enumerable.Range(0, Rows * 4).Select(i => new Seat(i + 1, i / 4, i % 4)).ToImmutableArray();

    public static readonly IReadOnlyList<(TimeOnly Departure, string Bus)> DailyDepartures = ImmutableArray.Create(
        (new TimeOnly(5, 30), "Morning Express"), (new TimeOnly(7, 0), "Day Service"), (new TimeOnly(13, 30), "Afternoon Service"));

    public static Seat Seat(int number) => Seats[number - 1];
    public static int LastStop => Stops.Count - 1;

    /// Bitmask of the road sections occupied by a journey from stop `from` to stop `to`.
    public static int Mask(int from, int to) => ((1 << to) - 1) & ~((1 << from) - 1);

    public static IReadOnlyList<Trip> TripsOn(DateOnly date) =>
        DailyDepartures.Select(d => new Trip(date, d.Departure, d.Bus)).ToImmutableArray();
}

public static class Pricing
{
    public static int SectionFare(int from, int to, Tariff t)
    {
        var km = Route.Stops[to].Km - Route.Stops[from].Km;
        var total = Route.Stops[Route.LastStop].Km;
        return Math.Max(t.MinimumFare, 5 * (int)Math.Round(t.FullFare * km / total / 5.0));
    }

    /// Everything payable at the time of booking, line by line.
    public static FareBreakdown Quote(Seat seat, int from, int to, AddOns a, Tariff t)
    {
        var lines = ImmutableArray.CreateBuilder<FareLine>();
        lines.Add(new FareLine($"Seat fare, {Route.Stops[from].Name} to {Route.Stops[to].Name}", SectionFare(from, to, t)));
        if (seat.IsWindow) lines.Add(new FareLine("Window seat", t.WindowSurcharge));
        var paidCarryOn = Math.Max(0, a.CarryOnPieces - t.FreeCarryOnPieces);
        if (a.CarryOnPieces > 0)
            lines.Add(new FareLine($"Carry-on luggage × {a.CarryOnPieces} (first {t.FreeCarryOnPieces} free)", paidCarryOn * t.CarryOnExtraPerPiece));
        if (a.HoldPieces > 0)
            lines.Add(new FareLine($"Luggage in the hold × {a.HoldPieces}", a.HoldPieces * t.HoldLuggagePerPiece));
        if (a.TeaCups > 0)
            lines.Add(new FareLine($"Tea × {a.TeaCups}", a.TeaCups * t.TeaPerCup));
        return new FareBreakdown(lines.ToImmutable());
    }

    public static Result<int> WaitingCharge(int minutes, Tariff t) =>
        minutes < 1 || minutes > t.MaxWaitingMinutes
            ? Result<int>.Fail($"The bus can wait between 1 and {t.MaxWaitingMinutes} minutes.")
            : Result<int>.Success(minutes * t.WaitingPerMinute);

    /// Refund on cancellation: a percentage of what was paid at booking. Later charges are not refunded.
    public static (int Percent, int Amount) Refund(Booking b, DateTime now, Tariff t)
    {
        var hours = (b.DepartureAt - now).TotalHours;
        var tier = t.RefundTiers.OrderByDescending(r => r.MinHoursBeforeDeparture)
            .FirstOrDefault(r => hours >= r.MinHoursBeforeDeparture);
        var percent = tier?.Percent ?? 0;
        return (percent, b.Fare.Total * percent / 100);
    }
}

/// The whole booking register as one immutable value. Every operation returns a new register or an error.
public sealed record BookingBook(ImmutableList<Booking> Bookings, int NextSerial)
{
    public static BookingBook Empty => new(ImmutableList<Booking>.Empty, 1);

    /// Sections of this seat already sold on this trip.
    public int OccupiedMask(string tripId, int seatNumber) =>
        Bookings.Where(b => b.Status == BookingStatus.Confirmed && b.TripId == tripId && b.SeatNumber == seatNumber)
                .Aggregate(0, (m, b) => m | Route.Mask(b.From, b.To));

    public bool IsFree(string tripId, int seatNumber, int from, int to) =>
        (OccupiedMask(tripId, seatNumber) & Route.Mask(from, to)) == 0;

    public Booking? Find(string id) => Bookings.FirstOrDefault(b => b.Id == id);

    public Result<BookingBook> Book(BookingRequest r, DateTime now, Tariff t)
    {
        var phone = new string((r.Phone ?? "").Where(char.IsDigit).ToArray());
        var today = DateOnly.FromDateTime(now);
        var error =
            string.IsNullOrWhiteSpace(r.PassengerName) ? "Enter the passenger's name."
            : phone.Length != 10 ? "Enter a 10-digit mobile number."
            : r.From < 0 || r.To > Route.LastStop || r.From >= r.To ? "Choose a boarding stop before the alighting stop."
            : r.SeatNumber < 1 || r.SeatNumber > Route.Seats.Count ? "Choose a seat."
            : r.Trip.Date < today || r.Trip.Date > today.AddDays(t.AdvanceBookingDays) ? $"Booking is open from today up to {t.AdvanceBookingDays} days ahead."
            : r.Trip.DepartureAt <= now ? "This bus has already left."
            : r.AddOns.CarryOnPieces < 0 || r.AddOns.CarryOnPieces > t.MaxCarryOnPieces ? $"Carry-on is limited to {t.MaxCarryOnPieces} pieces."
            : r.AddOns.HoldPieces < 0 || r.AddOns.HoldPieces > t.MaxHoldPieces ? $"Hold luggage is limited to {t.MaxHoldPieces} pieces."
            : r.AddOns.TeaCups < 0 || r.AddOns.TeaCups > t.MaxTeaCups ? $"Tea is limited to {t.MaxTeaCups} cups."
            : !IsFree(r.Trip.Id, r.SeatNumber, r.From, r.To) ? "That seat is already taken on part of this journey."
            : null;
        if (error is not null) return Result<BookingBook>.Fail(error);

        var booking = new Booking(
            $"BK{NextSerial:D5}", r.Trip.Id, r.Trip.DepartureAt, r.Trip.BusName, r.SeatNumber, r.From, r.To,
            r.PassengerName.Trim(), phone, r.Mode, r.AddOns,
            Pricing.Quote(Route.Seat(r.SeatNumber), r.From, r.To, r.AddOns, t),
            ImmutableArray<ExtraCharge>.Empty, BookingStatus.Confirmed, 0, now, null);
        return Result<BookingBook>.Success(new BookingBook(Bookings.Add(booking), NextSerial + 1));
    }

    public Result<BookingBook> Cancel(string id, DateTime now, Tariff t) => Find(id) switch
    {
        null => Result<BookingBook>.Fail("Booking not found."),
        { Status: BookingStatus.Cancelled } => Result<BookingBook>.Fail("This booking is already cancelled."),
        var b when b.DepartureAt <= now => Result<BookingBook>.Fail("The bus has left; this booking can no longer be cancelled."),
        var b => Replace(b, b with { Status = BookingStatus.Cancelled, CancelledAt = now, RefundAmount = Pricing.Refund(b, now, t).Amount }),
    };

    public Result<BookingBook> AddWaiting(string id, int minutes, DateTime now, Tariff t)
    {
        var b = Find(id);
        if (b is null) return Result<BookingBook>.Fail("Booking not found.");
        if (b.Status != BookingStatus.Confirmed) return Result<BookingBook>.Fail("Only a confirmed booking can ask the bus to wait.");
        var charge = Pricing.WaitingCharge(minutes, t);
        if (!charge.Ok) return Result<BookingBook>.Fail(charge.Error!);
        var used = b.WaitingMinutesUsed(t);
        if (used + minutes > t.MaxWaitingMinutes)
            return Result<BookingBook>.Fail($"Only {t.MaxWaitingMinutes - used} more minute(s) of waiting can be added to this booking.");
        return AddExtra(b, new ExtraCharge(ChargeKind.EmergencyWaiting, charge.Value, $"Emergency waiting, {minutes} min", now));
    }

    public Result<BookingBook> AddLostAndFound(string id, string item, DateTime now, Tariff t)
    {
        var b = Find(id);
        if (b is null) return Result<BookingBook>.Fail("Booking not found.");
        if (b.Status != BookingStatus.Confirmed) return Result<BookingBook>.Fail("Lost and found needs a confirmed booking.");
        if (string.IsNullOrWhiteSpace(item)) return Result<BookingBook>.Fail("Describe the lost item.");
        return AddExtra(b, new ExtraCharge(ChargeKind.LostAndFound, t.LostAndFoundFee, $"Lost and found: {item.Trim()}", now));
    }

    Result<BookingBook> AddExtra(Booking b, ExtraCharge e) =>
        Replace(b, b with { Extras = b.Extras.Append(e).ToImmutableArray() });

    Result<BookingBook> Replace(Booking old, Booking updated) =>
        Result<BookingBook>.Success(this with { Bookings = Bookings.Replace(old, updated) });
}
