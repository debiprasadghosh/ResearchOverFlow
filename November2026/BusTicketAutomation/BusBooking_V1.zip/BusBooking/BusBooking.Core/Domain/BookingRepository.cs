using System.Text.Json;

namespace BusBooking.Core.Domain;

/// Saves the register as one JSON file. A missing or unreadable file gives an empty register.
public static class BookingRepository
{
    static readonly JsonSerializerOptions Options = new() { WriteIndented = true };

    public static BookingBook Load(string path)
    {
        try
        {
            return File.Exists(path)
                ? JsonSerializer.Deserialize<BookingBook>(File.ReadAllText(path), Options) ?? BookingBook.Empty
                : BookingBook.Empty;
        }
        catch (Exception e) when (e is JsonException or IOException or NotSupportedException)
        {
            if (File.Exists(path)) File.Copy(path, path + ".unreadable", overwrite: true);   // keep the damaged file
            return BookingBook.Empty;
        }
    }

    public static void Save(string path, BookingBook book)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))!);
        var temp = path + ".tmp";
        File.WriteAllText(temp, JsonSerializer.Serialize(book, Options));
        File.Move(temp, path, overwrite: true);
    }
}
