using System.Windows.Input;
using BusBooking.Core.Domain;

namespace BusBooking.Core.ViewModels;

public sealed class SeatViewModel : ObservableObject
{
    bool _isTaken, _isSelected, _isDimmed;

    public SeatViewModel(Seat seat, Action<SeatViewModel> onSelect)
    {
        Seat = seat;
        SelectCommand = new RelayCommand(() => { if (CanSelect) onSelect(this); });
    }

    public Seat Seat { get; }
    public int Number => Seat.Number;
    public string Label => Seat.Label;
    public bool IsWindow => Seat.IsWindow;
    public int Row => Seat.Row;
    /// Column in the seat grid; column 2 is the aisle.
    public int GridColumn => Seat.Column < 2 ? Seat.Column : Seat.Column + 1;
    public ICommand SelectCommand { get; }

    /// Sold on at least one section of the journey being looked at.
    public bool IsTaken { get => _isTaken; set { if (Set(ref _isTaken, value)) { Raise(nameof(CanSelect)); Raise(nameof(ToolTip)); } } }
    public bool IsSelected { get => _isSelected; set => Set(ref _isSelected, value); }
    /// Hidden by the "window seats only" filter.
    public bool IsDimmed { get => _isDimmed; set { if (Set(ref _isDimmed, value)) Raise(nameof(CanSelect)); } }
    public bool CanSelect => !IsTaken && !IsDimmed;
    public string ToolTip => $"Seat {Label}" + (IsWindow ? ", window" : ", aisle") + (IsTaken ? ", taken" : ", free");
}
