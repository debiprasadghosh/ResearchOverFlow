using System.Collections.ObjectModel;
using System.Windows.Input;
using BusBooking.Core.Domain;

namespace BusBooking.Core.ViewModels;

/// One row of the "My bookings" list.
public sealed record BookingRow(Booking Booking)
{
    public string Id => Booking.Id;
    public string When => $"{Booking.DepartureAt:ddd dd MMM, HH:mm}";
    public string Seat => Route.Seat(Booking.SeatNumber).Label;
    public string Journey => $"{Route.Stops[Booking.From].Name} → {Route.Stops[Booking.To].Name}";
    public string Passenger => Booking.PassengerName;
    public string Paid => Money.Text(Booking.Fare.Total + Booking.ExtrasTotal);
    public string Status => Booking.Status == BookingStatus.Cancelled ? "Cancelled" : "Confirmed";
}

public sealed class MainViewModel : ObservableObject
{
    readonly Tariff _tariff;
    readonly Func<DateTime> _now;
    readonly Action<BookingBook> _save;
    BookingBook _book;

    DateTime? _travelDate;
    Trip? _selectedTrip;
    Stop _fromStop, _toStop;
    bool _windowOnly;
    SeatViewModel? _selectedSeat;
    string _passengerName = "", _phone = "", _status = "", _lostItem = "", _refundPreview = "", _total = "";
    PayMode _payMode = PayMode.UPI;
    int _carryOn, _hold, _tea, _waitingMinutes = 1;
    BookingRow? _selectedBooking;
    bool _statusIsError;

    public MainViewModel(BookingBook book, Tariff tariff, Func<DateTime> now, Action<BookingBook> save)
    {
        (_book, _tariff, _now, _save) = (book, tariff, now, save);
        Seats = new ObservableCollection<SeatViewModel>(Route.Seats.Select(s => new SeatViewModel(s, SelectSeat)));
        FromStops = Route.Stops.Take(Route.LastStop).ToList();
        _fromStop = Route.Stops[0]; _toStop = Route.Stops[Route.LastStop];
        ToStops = new ObservableCollection<Stop>(Route.Stops.Skip(1));
        CarryOnOptions = Enumerable.Range(0, tariff.MaxCarryOnPieces + 1).ToList();
        HoldOptions = Enumerable.Range(0, tariff.MaxHoldPieces + 1).ToList();
        TeaOptions = Enumerable.Range(0, tariff.MaxTeaCups + 1).ToList();
        WaitingOptions = Enumerable.Range(1, tariff.MaxWaitingMinutes).ToList();
        PayModes = Enum.GetValues<PayMode>();
        BookCommand = new RelayCommand(Book);
        CancelCommand = new RelayCommand(Cancel);
        AddWaitingCommand = new RelayCommand(AddWaiting);
        AddLostAndFoundCommand = new RelayCommand(AddLostAndFound);
        PickWindowSeatCommand = new RelayCommand(PickWindowSeat);
        TravelDate = MinDate;
        RefreshBookings(null);
    }

    // ---------- choices offered
    public ObservableCollection<SeatViewModel> Seats { get; }
    public ObservableCollection<Trip> Trips { get; } = new();
    public IReadOnlyList<Stop> FromStops { get; }
    public ObservableCollection<Stop> ToStops { get; }
    public IReadOnlyList<int> CarryOnOptions { get; }
    public IReadOnlyList<int> HoldOptions { get; }
    public IReadOnlyList<int> TeaOptions { get; }
    public IReadOnlyList<int> WaitingOptions { get; }
    public IReadOnlyList<PayMode> PayModes { get; }
    public ObservableCollection<FareLine> QuoteLines { get; } = new();
    public ObservableCollection<BookingRow> Bookings { get; } = new();
    public ObservableCollection<FareLine> DetailLines { get; } = new();

    public ICommand BookCommand { get; }
    public ICommand CancelCommand { get; }
    public ICommand AddWaitingCommand { get; }
    public ICommand AddLostAndFoundCommand { get; }
    public ICommand PickWindowSeatCommand { get; }

    public DateTime MinDate => _now().Date;
    public DateTime MaxDate => _now().Date.AddDays(_tariff.AdvanceBookingDays);
    public string TariffNote =>
        $"Window seat {Money.Text(_tariff.WindowSurcharge)} · carry-on: first {_tariff.FreeCarryOnPieces} free, then {Money.Text(_tariff.CarryOnExtraPerPiece)} each · " +
        $"hold luggage {Money.Text(_tariff.HoldLuggagePerPiece)} a piece · tea {Money.Text(_tariff.TeaPerCup)} a cup";
    public string RefundPolicy => "Cancellation: " + string.Join(", ", _tariff.RefundTiers
        .Select(r => r.Percent == 0 ? "no refund after that"
            : $"{r.Percent}% back up to {r.MinHoursBeforeDeparture:0} h before departure"));
    public string WaitingNote => $"{Money.Text(_tariff.WaitingPerMinute)} a minute, {_tariff.MaxWaitingMinutes} minutes at most per booking";
    public string LostAndFoundNote => $"{Money.Text(_tariff.LostAndFoundFee)} handling charge per item";

    // ---------- the journey being booked
    public DateTime? TravelDate
    {
        get => _travelDate;
        set
        {
            var clamped = value is null ? MinDate : value.Value.Date < MinDate ? MinDate : value.Value.Date > MaxDate ? MaxDate : value.Value.Date;
            if (!Set(ref _travelDate, clamped)) return;
            Trips.Clear();
            foreach (var t in Route.TripsOn(DateOnly.FromDateTime(clamped)).Where(t => t.DepartureAt > _now())) Trips.Add(t);
            SelectedTrip = Trips.FirstOrDefault();
            if (Trips.Count == 0) Say("No more buses on that day. Choose a later date.", error: true);
        }
    }

    public Trip? SelectedTrip
    {
        get => _selectedTrip;
        set { if (Set(ref _selectedTrip, value)) RefreshSeats(); }
    }

    public Stop FromStop
    {
        get => _fromStop;
        set
        {
            if (value is null || !Set(ref _fromStop, value)) return;
            var keep = _toStop.Index > value.Index ? _toStop : Route.Stops[Route.LastStop];
            ToStops.Clear();
            foreach (var s in Route.Stops.Where(s => s.Index > value.Index)) ToStops.Add(s);
            _toStop = keep; Raise(nameof(ToStop));
            RefreshSeats();
        }
    }

    public Stop ToStop
    {
        get => _toStop;
        set { if (value is not null && Set(ref _toStop, value)) RefreshSeats(); }   // null arrives while the list is rebuilt
    }

    public bool WindowOnly
    {
        get => _windowOnly;
        set { if (Set(ref _windowOnly, value)) RefreshSeats(); }
    }

    public SeatViewModel? SelectedSeat
    {
        get => _selectedSeat;
        private set { if (Set(ref _selectedSeat, value)) { Raise(nameof(SelectedSeatText)); Raise(nameof(CanBook)); } }
    }
    public string SelectedSeatText => SelectedSeat is null ? "No seat chosen"
        : $"Seat {SelectedSeat.Label} ({(SelectedSeat.IsWindow ? "window" : "aisle")})";
    public string FreeSeatsText { get; private set; } = "";

    // ---------- passenger and add-ons
    public string PassengerName { get => _passengerName; set => Set(ref _passengerName, value); }
    public string Phone { get => _phone; set => Set(ref _phone, value); }
    public PayMode PayMode { get => _payMode; set => Set(ref _payMode, value); }
    public int CarryOn { get => _carryOn; set { if (Set(ref _carryOn, value)) RefreshQuote(); } }
    public int Hold { get => _hold; set { if (Set(ref _hold, value)) RefreshQuote(); } }
    public int Tea { get => _tea; set { if (Set(ref _tea, value)) RefreshQuote(); } }
    public string Total { get => _total; private set => Set(ref _total, value); }
    public bool CanBook => SelectedSeat is not null && SelectedTrip is not null;

    // ---------- status line
    public string Status { get => _status; private set => Set(ref _status, value); }
    public bool StatusIsError { get => _statusIsError; private set => Set(ref _statusIsError, value); }

    // ---------- existing bookings
    public BookingRow? SelectedBooking
    {
        get => _selectedBooking;
        set { if (Set(ref _selectedBooking, value)) { RefreshDetail(); Raise(nameof(HasSelectedBooking)); } }
    }
    public bool HasSelectedBooking => SelectedBooking is not null;
    public int WaitingMinutes { get => _waitingMinutes; set => Set(ref _waitingMinutes, value); }
    public string LostItem { get => _lostItem; set => Set(ref _lostItem, value); }
    public string RefundPreview { get => _refundPreview; private set => Set(ref _refundPreview, value); }

    AddOns CurrentAddOns => new(CarryOn, Hold, Tea);

    void Say(string message, bool error = false) { StatusIsError = error; Status = message; }

    void SelectSeat(SeatViewModel seat)
    {
        if (SelectedSeat is not null) SelectedSeat.IsSelected = false;
        seat.IsSelected = true;
        SelectedSeat = seat;
        RefreshQuote();
    }

    void PickWindowSeat()
    {
        var seat = Seats.FirstOrDefault(s => s.IsWindow && !s.IsTaken);
        if (seat is null) { Say("No window seat is free for this journey.", error: true); return; }
        if (seat.IsDimmed) seat.IsDimmed = false;
        SelectSeat(seat);
    }

    void RefreshSeats()
    {
        foreach (var s in Seats)
        {
            s.IsTaken = SelectedTrip is null || !_book.IsFree(SelectedTrip.Id, s.Number, FromStop.Index, ToStop.Index);
            s.IsDimmed = WindowOnly && !s.IsWindow;
            if (s.IsSelected && !s.CanSelect) { s.IsSelected = false; SelectedSeat = null; }
        }
        var free = Seats.Count(s => !s.IsTaken);
        FreeSeatsText = SelectedTrip is null ? "" : $"{free} of {Seats.Count} seats free for this journey, {Seats.Count(s => !s.IsTaken && s.IsWindow)} by the window";
        Raise(nameof(FreeSeatsText)); Raise(nameof(CanBook));
        RefreshQuote();
    }

    void RefreshQuote()
    {
        QuoteLines.Clear();
        if (SelectedSeat is null) { Total = ""; return; }
        var quote = Pricing.Quote(SelectedSeat.Seat, FromStop.Index, ToStop.Index, CurrentAddOns, _tariff);
        foreach (var l in quote.Lines) QuoteLines.Add(l);
        Total = Money.Text(quote.Total);
    }

    void RefreshBookings(string? selectId)
    {
        Bookings.Clear();
        foreach (var b in _book.Bookings.OrderByDescending(b => b.BookedAt)) Bookings.Add(new BookingRow(b));
        SelectedBooking = Bookings.FirstOrDefault(r => r.Id == selectId);
        RefreshDetail();
    }

    void RefreshDetail()
    {
        DetailLines.Clear();
        var b = SelectedBooking?.Booking;
        if (b is null) { RefundPreview = ""; return; }
        foreach (var l in b.Fare.Lines) DetailLines.Add(l);
        foreach (var e in b.Extras) DetailLines.Add(new FareLine(e.Note, e.Amount));
        if (b.Status == BookingStatus.Cancelled)
        {
            DetailLines.Add(new FareLine("Refund on cancellation", -b.RefundAmount));
            RefundPreview = $"Cancelled on {b.CancelledAt:dd MMM, HH:mm}. Refund {Money.Text(b.RefundAmount)}.";
        }
        else if (b.DepartureAt <= _now()) RefundPreview = "The bus has left; this booking can no longer be cancelled.";
        else
        {
            var (percent, amount) = Pricing.Refund(b, _now(), _tariff);
            RefundPreview = $"Cancelling now returns {percent}% of the booking amount: {Money.Text(amount)}.";
        }
    }

    /// Apply a register operation; on success keep, save and redraw.
    bool Apply(Result<BookingBook> result, string? selectId, string success)
    {
        if (!result.Ok) { Say(result.Error!, error: true); return false; }
        _book = result.Value!;
        try { _save(_book); Say(success); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException)
        { Say($"{success} It could not be saved to disk: {e.Message}", error: true); }
        RefreshBookings(selectId);
        RefreshSeats();
        return true;
    }

    void Book()
    {
        if (SelectedTrip is null || SelectedSeat is null) { Say("Choose a bus and a seat first.", error: true); return; }
        var request = new BookingRequest(SelectedTrip, SelectedSeat.Number, FromStop.Index, ToStop.Index, PassengerName, Phone, PayMode, CurrentAddOns);
        var id = $"BK{_book.NextSerial:D5}"; var label = SelectedSeat.Label; var total = Total;
        if (!Apply(_book.Book(request, _now(), _tariff), id, $"Booked {id}: seat {label}, {total}.")) return;
        if (SelectedSeat is not null) { SelectedSeat.IsSelected = false; SelectedSeat = null; }
        PassengerName = ""; Phone = ""; CarryOn = 0; Hold = 0; Tea = 0;
        RefreshQuote();
    }

    void Cancel()
    {
        if (SelectedBooking is not { } row) { Say("Select a booking first.", error: true); return; }
        var refund = Pricing.Refund(row.Booking, _now(), _tariff).Amount;
        Apply(_book.Cancel(row.Id, _now(), _tariff), row.Id, $"Cancelled {row.Id}. Refund {Money.Text(refund)}.");
    }

    void AddWaiting()
    {
        if (SelectedBooking is not { } row) { Say("Select a booking first.", error: true); return; }
        Apply(_book.AddWaiting(row.Id, WaitingMinutes, _now(), _tariff), row.Id,
            $"Waiting of {WaitingMinutes} min added to {row.Id}: {Money.Text(WaitingMinutes * _tariff.WaitingPerMinute)}.");
    }

    void AddLostAndFound()
    {
        if (SelectedBooking is not { } row) { Say("Select a booking first.", error: true); return; }
        if (Apply(_book.AddLostAndFound(row.Id, LostItem, _now(), _tariff), row.Id,
                $"Lost and found charge added to {row.Id}: {Money.Text(_tariff.LostAndFoundFee)}."))
            LostItem = "";
    }
}
