using System.IO;
using System.Windows;
using BusBooking.Core.Domain;
using BusBooking.Core.ViewModels;

namespace BusBooking.Wpf;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        // Bookings are kept in %LOCALAPPDATA%\BusBooking\bookings.json
        var path = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BusBooking", "bookings.json");
        var viewModel = new MainViewModel(
            BookingRepository.Load(path), new Tariff(), () => DateTime.Now, book => BookingRepository.Save(path, book));
        new MainWindow { DataContext = viewModel }.Show();
    }
}
