using System.Windows;

namespace BusBooking.Wpf;

public partial class MainWindow : Window
{
    public MainWindow() => InitializeComponent();
}
