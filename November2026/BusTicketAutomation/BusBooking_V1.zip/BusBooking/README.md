# Bus Seat Booking (WPF, .NET 8)

A desktop booking screen for one bus route, in the manner of an airline seat picker.

## Run

Requires Windows and the .NET 8 SDK.

    dotnet run --project BusBooking.Wpf

or open `BusBooking.sln` in Visual Studio 2022 and start `BusBooking.Wpf`.

To run the rule checks (any OS):

    dotnet run --project BusBooking.Checks

## What it does

**Book a seat**
- Travel date from today up to 30 days ahead (advance booking), three buses a day.
- Boarding and alighting stop. A seat is sold stop to stop, so one seat can carry
  several passengers over different parts of the road.
- Seat map, 10 rows of 2 + 2. Window seats (A and D) are tinted. "Show window seats only"
  and "Pick a window seat for me" are on the left.
- Extras chosen at booking: carry-on luggage, luggage in the hold, tea.
- Fare shown line by line before booking.

**My bookings**
- Every booking with its charges.
- Cancel, with the refund shown before you confirm.
- Emergency waiting: ask the bus to wait 1 to 5 minutes; 5 minutes is the limit per booking.
- Lost and found: a handling charge against a booking, with a description of the item.

## Prices and limits

All in `BusBooking.Core/Domain/Model.cs`, record `Tariff`. Defaults:

| Item | Default |
|---|---|
| Full-route fare | ₹240 (section fares by distance, rounded to ₹5, minimum ₹20) |
| Window seat | ₹10 |
| Carry-on luggage | first piece free, then ₹20 a piece, 3 at most |
| Luggage in the hold | ₹30 a piece, 4 at most |
| Tea | ₹15 a cup, 4 at most |
| Emergency waiting | ₹20 a minute, 5 minutes at most |
| Lost and found | ₹50 an item |
| Cancellation | 90% back up to 24 h before departure, 50% up to 2 h, nothing after |
| Advance booking | 30 days |

Waiting and lost-and-found charges are not refunded on cancellation.
Stops, distances and departure times are in `Route` in `Rules.cs`.

## Layout

- `BusBooking.Core` — records and pure rules (`Domain`), view-models (`ViewModels`). No WPF dependency.
- `BusBooking.Wpf` — XAML only; no logic in code-behind.
- `BusBooking.Checks` — console checks of the rules and view-models.

Bookings are saved to `%LOCALAPPDATA%\BusBooking\bookings.json`.
No payment is taken; "Paying by" is recorded only.
