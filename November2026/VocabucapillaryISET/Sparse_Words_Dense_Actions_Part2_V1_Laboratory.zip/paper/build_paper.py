"""Assembles the Part 2 paper (sparse word records, dense ISET chunks and counted association atoms in one cache) from
the laboratory outputs and converts it to Word with pandoc and the docxfix repair step."""
import csv, json, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT, FIG = ROOT / "out", ROOT / "figs"
sys.path.insert(0, str(HERE))
import docxfix

H = json.load(open(OUT / "headlines.json"))
def g(k): return H[k]
def rd(n): return list(csv.DictReader(open(OUT / f"{n}.csv")))
def m(s): return s.replace("-", "−")
def f1(x): return m(f"{x:.1f}")
def f2(x): return m(f"{x:.2f}")
def f3(x): return m(f"{x:.3f}")
def f4(x): return m(f"{x:.4f}")
def pc(x, d=0): return m(f"{100 * x:.{d}f}%")
def n0(x): return f"{x:,.0f}"
def c1(x): return m(f"{x:,.1f}")
def kb(x, d=1): return f"{x / 1000:,.{d}f}"
SUP = str.maketrans("0123456789-", "⁰¹²³⁴⁵⁶⁷⁸⁹⁻")
def p10(x, d=1):
    mant, ex = f"{x:.{d}e}".split("e")
    return f"{mant} × 10{str(int(ex)).translate(SUP)}"
def fl(x): return float(x)

def md_table(header, rows, caption, widths=None):
    lens = [max(min(len(str(h)), 14), 9, *(len(str(r[i])) for r in rows)) for i, h in enumerate(header)]
    dashes = widths if widths else [max(9, min(60, l)) for l in lens]
    out = [f"Table: {caption}", "", "| " + " | ".join(header) + " |", "|" + "|".join("-" * w for w in dashes) + "|"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out) + "\n"

# ---------------- lookups ----------------
st = rd("V00_storage"); qm = rd("V00_query_macs"); hp = rd("V00_heaps")
idt = rd("V01_identities")
exa = rd("V02_exact_scores"); uo = rd("V02_uncertain_observation"); chn = rd("V02_channel"); exm = rd("V02_examples")
lh = rd("V03_long_history"); dep = rd("V03_depth"); agg = rd("V03_cacheless")
aex = rd("V04_experience"); ain = rd("V04_interaction"); ath = rd("V04_threshold"); amx = rd("V04_misspellings")
ach = rd("V05_atom_choice"); ainv = rd("V05_inventory")
py = list(csv.DictReader(open(OUT / "PY_crosscheck.csv")))
py_agree = f"{sum(r['agree'] == 'True' for r in py)} of {len(py)}"

def sv(h, heads, scheme, col): return fl(next(r[col] for r in st if r["horizon"] == h and r["heads"] == str(heads) and r["word_scheme"] == scheme))
DW, R1, R4 = "dense word keys (Part 1)", "records s = 1", "records s = 4"
def qv(M, col): return fl(next(r[col] for r in qm if r["word_tokens_M"] == str(M)))
def uv(v, e, col): return fl(next(r[col] for r in uo if r["stored_as"] == v and fl(r["letter_error_eps"]) == e))
def cv(e, col): return fl(next(r[col] for r in chn if fl(r["letter_error_eps"]) == e))
def lv(M, col): return fl(next(r[col] for r in lh if r["tokens_M"] == str(M)))
def dv(b, col): return fl(next(r[col] for r in dep if fl(r["context_mass_ratio_beta"]) == b))
def av(tau, reader, col): return fl(next(r[col] for r in agg if fl(r["temperature_tau"]) == tau and r["reader"].startswith(reader)))
def ev(E, meth, col): return fl(next(r[col] for r in aex if r["executions_per_pair_E"] == str(E) and r["method"].startswith(meth)))
def iv(iota, meth, col): return fl(next(r[col] for r in ain if fl(r["interaction_share_iota"]) == iota and r["method"].startswith(meth)))
def tv(theta, meth, col): return fl(next(r[col] for r in ath if fl(r["threshold_theta"]) == theta and r["method"].startswith(meth)))
def cc(task, reader, col): return fl(next(r[col] for r in ach if r["task"] == task and r["reader"] == reader))
VOB, VMAP, VT2, VT4, VQ4, VFULL, VSOFT = ("observed letters (one new atom)", "MAP word (s = 1)", "top 2 (s = 2)", "top 4 (s = 4)", "top 4, 4-bit coefficients", "full posterior", "slot marginals (one new soft atom)")
EPS = (0.1, 0.2, 0.3)
Es = (1, 2, 4, 8, 16, 32)

# ---------------- tables ----------------
t_forms = md_table(["Memory", "Stored per item", "Read by", "Names what it holds", "Grows with"], [
    ["Dense word key (Part 1)", "key and value of width 128 in BF16, per head and layer", "dot or distance score", "no: must be unbound", "word tokens"],
    ["Word record (this paper)", "s pairs of a 16-bit atom index and an 8-bit coefficient, shared by all heads", "one primitive table per query, then lookups", "yes: atoms and weights", "word tokens, 3 bytes each"],
    ["Word atom", "a spelling: one sparse dictionary over 28 primitives per slot", "lookups in the primitive table", "yes: letters by slot", "distinct words"],
    ["Soft atom", "one new atom whose slots hold several letters", "lookups in the primitive table", "letters by slot, not their combinations", "distinct uncertain observations"],
    ["Per-atom aggregate", "mass and value sum for each atom", "KV coefficient law", "yes", "distinct atoms"],
    ["Slot–primitive aggregate", "mass and value sum for each of 16 × 28 slot–letter pairs", "KV coefficient law", "no: which letters went together is lost", "nothing (fixed size)"],
    ["Product atom", "word codes for its roles, mean ISET code, count, variance", "code match or primitive table; nearest mean", "yes", "distinct word tuples and action modes"],
    ["Role slots (Part 1)", "three dense vectors per execution", "summed role scores", "no", "executions"],
], "Table 1. The memories compared in this paper.", [18, 30, 22, 18, 16])

def idval(r):
    v = fl(r["value"])
    if r["check"].startswith(("argmax lost although", "attention outputs whose", "mixed records whose")): return n0(v)
    return p10(v) if 0 < abs(v) < 1e-3 else f4(v) if v != 0 else "0"
t_ident = md_table(["Check", "Value", "Requirement"], [[r["check"].replace("c̄", "ō"), idval(r), r["requirement"]] for r in idt],
    f"Table 2. Exact properties checked on 2,500 atoms (2,000 lexicon words and 500 soft atoms), 5,000 records of support 1–8 and 20 random queries, plus the cases named in each row. Width 128.", [62, 14, 20])

store_rows = []
for h_, lab in (("one minute", "1 minute"), ("one hour", "1 hour")):
    for heads in (1, 8):
        base = sv(h_, heads, DW, "total_bytes")
        for sc, sl in ((DW, "dense word keys (Part 1)"), (R1, "records, s = 1"), (R4, "records, s = 4")):
            wb = sv(h_, heads, sc, "word_bytes") + sv(h_, heads, sc, "atom_inventory_bytes")
            store_rows.append([lab, str(heads), sl, kb(wb), kb(sv(h_, heads, sc, "chunk_bytes"), 0), kb(sv(h_, heads, sc, "total_bytes"), 0), pc(sv(h_, heads, sc, "word_share"), 2), pc(sv(h_, heads, sc, "total_bytes") / base, 1)])
t_store = md_table(["Horizon", "Heads", "Words stored as", "Word bytes (kB)", "Chunk bytes (kB)", "Total (kB)", "Word share", "Total against Part 1"], store_rows,
    f"Table 3. Cache bytes for speech at 2.5 words per second beside a seven-joint body at 50 steps per second in 8-step chunks ({n0(g('V00.minute_chunk_tokens'))} chunks a minute). Dense keys and values have width 128 in BF16; a chunk also keeps 28 bytes of raw characters. Word bytes include the letter slots kept beside dense keys (Part 1) or the spellings of the distinct atoms ({f1(g('V00.minute_distinct_words'))} a minute, {n0(g('V00.hour_distinct_words'))} an hour). Records are counted once for all heads.", [10, 8, 24, 12, 12, 11, 10, 13])

t_macs = md_table(["Word tokens M", "Distinct words G", "Dense scan M·d", "Atom-key table G·d + M", "Primitive table 448·d + 16·G + M", "Dense over primitive table"],
    [[n0(fl(r["word_tokens_M"])), c1(fl(r["distinct_words_G"])), n0(fl(r["dense_scan"])), n0(fl(r["atom_key_table"])), n0(fl(r["primitive_table"])), f2(fl(r["dense_over_primitive"]))] for r in qm],
    f"Table 4. Multiply-adds of one word query at width d = 128 for frequency-sampled English word tokens (records with s = 1). The atom-key table needs a dictionary of atom keys per head and layer, {n0(g('V00.atom_key_dictionary_bytes_head') / 1e6)} MB for the 50,000-word lexicon; the primitive table needs 28 vectors per head.", [12, 14, 14, 18, 22, 14])

t_exact = md_table(["Reader", "Stored per word", "Multiply-adds per query", "Target found exactly"],
    [[r["reader"], r["stored per word"], n0(fl(r["multiply_adds_per_query"])), f3(fl(r["target_found_exactly"]))] for r in exa],
    f"Table 5. Exact word retrieval in 1,000 Step 1 histories of 256 tokens ({f1(g('V02.mean_distinct_words'))} distinct words on average) at width 128, with query noise σ = 0.5. The bound layout uses the distance score, with each atom's key norm stored once. Table and dense scores differed by at most {p10(g('V02.A_max_abs_diff'))}.", [34, 16, 16, 14])

obs_rows = []
for v, lab in ((VOB, "observed letters (one new atom)"), (VMAP, "MAP word, s = 1"), (VT2, "top 2, s = 2"), (VT4, "top 4, s = 4"), (VQ4, "top 4, 4-bit coefficients"), (VFULL, "full posterior"), (VSOFT, "slot marginals (one new soft atom)")):
    obs_rows.append([lab, " / ".join(f3(uv(v, e, "target_found")) for e in EPS), f3(uv(v, 0.2, "token_read_correctly")), f3(uv(v, 0.2, "true_word_retained")),
                     f2(uv(v, 0.2, "entries_per_token")), f1(uv(v, 0.2, "new_atoms_per_history"))])
t_obs = md_table(["Word token stored as", "Target found, ε = 0.1 / 0.2 / 0.3", "Token read correctly", "True word kept", "Entries per token", "New atoms per history"], obs_rows,
    "Table 6. Word tokens observed through the letter-confusion channel (1,000 histories of 256 tokens; columns 3–6 at ε = 0.2). Entries are record pairs, or letter candidates for the two kinds of new atom. A record over lexicon atoms adds no atom.", [30, 22, 12, 11, 11, 12])

t_ex = md_table(["True word", "Observed", "Observation is", "Record (top 3 of the posterior)", "Candidates", "MAP right"],
    [[r["true_word"], r["observed"], r["observation_is"], r["record_top3"].replace("; ", ", "), r["posterior_support"], r["map_is_true_word"]] for r in exm],
    "Table 7. Records that keep real uncertainty: misread tokens whose most likely word has a posterior below 0.9 (ε = 0.2, the first histories).", [12, 11, 13, 40, 12, 9])

long_rows = [[n0(lv(M, "tokens_M")), n0(lv(M, "word_tokens")), c1(lv(M, "distinct_words")), f2(lv(M, "word_exact_primitive_table")), f"{f2(lv(M, 'chunk_exact_screen_only'))} / {f2(lv(M, 'chunk_exact_screen_rerank'))}",
              f"{n0(lv(M, 'mac_word_query'))} / {n0(lv(M, 'mac_word_query_part1'))}", f"{n0(lv(M, 'mac_chunk_query'))} / {n0(lv(M, 'mac_chunk_query_part1'))}",
              f"{kb(lv(M, 'cache_bytes_head_layer'), 0)} / {kb(lv(M, 'cache_bytes_head_layer_part1'), 0)}"] for M in (256, 1024, 4096, 16384)]
t_long = md_table(["Tokens M", "Word tokens", "Distinct words", "Word found exactly", "Chunk exact: screen only / with rerank", "Multiply-adds per word query: Part 2 / Part 1", "Per chunk query: Part 2 / Part 1", "Cache kB per head and layer: Part 2 / Part 1"], long_rows,
    "Table 8. Mixed histories with two words in every seven tokens (200 histories per length, width 128, query noise σ = 0.5). Part 2 scores every word record through the primitive table and screens only chunk tokens before the per-step rerank of eight. The Part 1 reader screened one vector per distinct word and per chunk, then reranked eight entries of the query's type.", [10, 9, 10, 9, 15, 18, 16, 17])

depth_rows = [[f2(b).rstrip("0").rstrip(".") if b < 1 else n0(b), f2(dv(b, "decoded_context_to_self_l2")), f3(dv(b, "guarantee_beta_max_cbar_below_1")), f3(dv(b, "record_identity_argmax")),
               f3(dv(b, "dense_key_spelled_by_unbinding")), f3(dv(b, "retrieval_full_record")), f"{f2(dv(b, 's4_pruned_mass_tv'))} / {f3(dv(b, 's4_retrieval'))}", f"{f3(dv(b, 's16_pruned_mass_tv'))} / {f3(dv(b, 's16_retrieval'))}"]
              for b in (0, 0.25, 0.5, 1, 2, 4, 8, 16)]
t_depth = md_table(["Context mass β", "Decoded norm ratio", "Share with β·max ō < 1", "Record: identity by argmax", "Dense key: spelled by unbinding", "Retrieval (record = dense key)", "Top 4: pruned mass / retrieval", "Top 16: pruned mass / retrieval"], depth_rows,
    f"Table 9. A word position in a deeper layer: its record mixed with the mean record of the previous 16 tokens at context mass β (Equation 4), against the decoded dense bound key of the same mixture ({n0(g('V03.depth_b0_positions'))} positions whose word occurs once, in 200 histories of 256 tokens, width 128). The decoded norm ratio is ‖β k(ō)‖ / ‖k(c)‖. Retrieval uses the distance score and query noise σ = 0.5.", [9, 10, 10, 11, 11, 11, 15, 15])

agg_rows = []
for tau in (0.25, 1.0):
    for reader, lab in (("KV cache", "KV cache, softmax over 256 tokens"), ("per-atom", "per-atom aggregate"), ("slot", "slot–primitive aggregate")):
        auc = av(tau, reader, "presence_auc_vs_recombination_probes")
        agg_rows.append([f2(tau), lab, f3(av(tau, reader, "value_of_present_word_found")), "–" if auc != auc else f3(auc), n0(av(tau, reader, "state_floats"))])
t_agg = md_table(["Temperature τ", "State", "Value of a present word found", "Present against recombined: AUC", "State size (floats)"], agg_rows,
    "Table 10. Cacheless reading (1,000 histories of 256 tokens; values are random unit vectors of width 64, one per token). A read is correct when its nearest per-word mean value, by cosine, is the target's. The AUC separates the evidence log Σ φ m of present targets from that of recombination probes made of the first half of one present word and the second half of another.", [12, 30, 16, 18, 14])

exp_rows = [[str(E), f4(g(f"V04.exp_E{E}_execution_floor")), f"{n0(ev(E, 'product', 'inventory_entries'))} / {kb(ev(E, 'product', 'inventory_bytes'))} / {f4(ev(E, 'product', 'plan_rms_vs_prototype'))}",
             f"{kb(ev(E, 'densified', 'inventory_bytes'))} / {f4(ev(E, 'densified', 'plan_rms_vs_prototype'))}",
             f"{n0(ev(E, 'role', 'inventory_entries'))} / {kb(ev(E, 'role', 'inventory_bytes'), 0)} / {f4(ev(E, 'role', 'plan_rms_vs_prototype'))}"] for E in Es]
t_exp = md_table(["Executions per pair E", "One execution against its prototype (rad)", "Product atoms: atoms / kB / planning RMS", "Densified atoms: kB / planning RMS", "Role slots: entries / kB / planning RMS"], exp_rows,
    f"Table 11. Association inventories for 256 verb–object actions (ι = 0.5, threshold θ = 1). Planning RMS (rad) is the error of the planned 8-step chunk against the pair's prototype. Every method planned the right pair and described every fresh execution by both of its words.", [12, 15, 26, 20, 26])

int_rows = [[f1(i), f"{f4(iv(i, 'product', 'plan_rms_vs_prototype'))} / {f3(iv(i, 'product', 'describe_both_words'))}", f"{f4(iv(i, 'role', 'plan_rms_vs_prototype'))} / {f3(iv(i, 'role', 'describe_both_words'))}",
             f"{f4(iv(i, 'linear', 'plan_rms_vs_prototype'))} / {f3(iv(i, 'linear', 'describe_both_words'))}"] for i in (0.0, 0.5, 1.0)]
t_int = md_table(["Interaction share ι", "Product atoms: planning RMS / description", "Role slots: planning RMS / description", "Linear map: planning RMS / description"], int_rows,
    "Table 12. Planning and description against the share of verb–object interaction, four executions per pair.", [12, 26, 26, 26])

th_rows = [[f2(t).rstrip("0").rstrip("."), f"{n0(tv(t, 'product', 'inventory_entries'))} / {f3(tv(t, 'product', 'describe_both_words'))}",
            f"{n0(tv(t, 'densified', 'inventory_entries'))} / {f3(tv(t, 'densified', 'purity'))} / {f3(tv(t, 'densified', 'describe_both_words'))}"] for t in (0.1, 0.25, 0.5, 1.0, 1.5, 2.0, 3.0)]
t_th = md_table(["Threshold θ", "Product atoms: atoms / description", "Densified atoms: atoms / purity / description"], th_rows,
    "Table 13. The clustering threshold (ι = 0.5, four executions per pair). Purity is the share of executions whose atom belongs to their own pair.", [12, 30, 36])

def readers(task):
    rows_ = []
    for name, lab in (("soft read over atoms", "soft read over atoms"), ("arg-max count", "arg-max count"), ("atom sampled by count", "atom sampled by count"), ("sampled atom plus residual", "sampled atom plus residual"),
                      ("dense soft read, β = 30", "dense: soft read, β = 30 (Part 1)"), ("dense hard top-1", "dense: hard top-1 (Part 1)"), ("dense sampled mode, then soft within", "dense: sampled mode, soft within (Part 1)")):
        rows_.append([lab, f3(cc(task, name, "collision_rate")), f3(cc(task, name, "off_manifold_rms")), f2(cc(task, name, "nearest_stored_over_spacing")), f3(cc(task, name, "share_mode0_left")), f3(cc(task, name, "mode_share_tv")), n0(cc(task, name, "distinct_outputs_of_1000"))])
    return rows_
t_choice = md_table(["Reader", "Collision rate", "Off-manifold RMS", "Nearest stored / spacing", "Share of mode +1", "Mode shares: TV", "Distinct outputs"],
    [["**Two modes (stored share of +1: " + f3(g('V05.two_stored_share_mode0')) + ")**", "", "", "", "", "", ""]] + readers("two modes") +
    [["**Three modes +1 / −1 / +2 (stored " + f2(g('V05.three_stored_share_mode0')) + " / " + f2(g('V05.three_stored_share_mode1')) + " / " + f2(g('V05.three_stored_share_mode2')) + ")**", "", "", "", "", "", ""]] + readers("three unequal modes"),
    f"Table 14. Reading an action from product atoms and from the dense cache of Part 1 (512 stored executions under one cue, 1,000 queries). Collision: the path comes within 0.3 of the centre line in steps 5–10. Novelty is the distance to the nearest stored execution over their mean spacing ({f3(g('V05.two_spacing'))}). TV is the total variation between the modes of the reads and of the stored executions.", [34, 10, 10, 11, 10, 10, 10])

# ---------------- derived numbers ----------------
min_dense, min_rec, min_rec4 = sv("one minute", 1, DW, "total_bytes"), sv("one minute", 1, R1, "total_bytes"), sv("one minute", 1, R4, "total_bytes")
min_wd = sv("one minute", 1, DW, "word_bytes"); min_wr = sv("one minute", 1, R1, "word_bytes") + sv("one minute", 1, R1, "atom_inventory_bytes")
min_wr4 = sv("one minute", 1, R4, "word_bytes") + sv("one minute", 1, R4, "atom_inventory_bytes")
min_inv = sv("one minute", 1, R1, "atom_inventory_bytes")
ratio_min = min_rec / min_dense
chunk_share = 1 - sv("one minute", 1, R1, "word_share")
l8 = sv("one minute", 8, R1, "total_bytes") / sv("one minute", 8, DW, "total_bytes")
best_tv3 = cc("three unequal modes", "atom sampled by count", "mode_share_tv")
gain = {e: uv(VFULL, e, "target_found") - uv(VMAP, e, "target_found") for e in EPS}
miss_ex = ", ".join(f"*{r['verb']}* → *{r['misspelled_cue_example']}*" for r in amx[:3])

md = f"""---
title: "Sparse Words, Dense Actions: Word-Vocabucapillary Records, ISET Chunk Tokens and Counted Association Atoms in One Key–Value Cache"
author: "Debi Prasad Ghosh"
date: "November 2026"
abstract: |
  Part 1 of this hybrid design stored words and ISET action chunks as dense vectors in one key–value cache. This paper, Part 2, keeps the chunks dense and replaces each word entry by a word-Vocabucapillary record: a sparse positive code over a dynamic vocabulary of word atoms, each spelled by sparse dictionaries over 28 fixed primitives. Association between words and actions moves into a counted vocabulary of product atoms trained on mixed tuples, and choosing an atom becomes the discrete choice of an action mode. An immutable C# laboratory tests the design, and an independent Python program reproduced {py_agree} of its quantities. A record scored through one table of primitive scores gave the dense score of its decoded key to within {p10(g('V01.score_identity_concat_max_abs'))}, so retrieval decisions are unchanged, while it costs 3 bytes per entry against 512 bytes per head and layer. Over one minute of speech beside a 50 Hz body stream, word storage fell from {kb(min_wd, 0)} kB to {kb(min_wr)} kB per head and layer, yet the whole cache shrank only to {pc(ratio_min)} of Part 1, because chunk tokens now hold {pc(chunk_share, 1)} of it. The table beat a dense scan once a history held {n0(g('V00.break_even_tokens_primitive_table'))} word tokens, and at 16,384 mixed tokens it found the exact word with {n0(lv(16384, 'mac_word_query_part1') / lv(16384, 'mac_word_query'))} times fewer multiply-adds than Part 1's reader. With letters misread at a rate of 0.2, records that kept the lexicon posterior found the target in {pc(uv(VFULL, 0.2, 'target_found'), 1)} of histories, the most likely word alone in {pc(uv(VMAP, 0.2, 'target_found'), 1)} and the observed letters in {pc(uv(VOB, 0.2, 'target_found'), 1)}. In deeper layers a record kept its identity readable by argmax with context of twice its own mass, where unbinding the decoded dense key spelled only {pc(dv(2, 'dense_key_spelled_by_unbinding'), 1)} of words. Per-atom cacheless aggregates read values exactly and told present words from recombinations (AUC {f3(av(0.25, 'per-atom', 'presence_auc_vs_recombination_probes'))}); slot–primitive aggregates could not (AUC {f2(av(0.25, 'slot', 'presence_auc_vs_recombination_probes'))}). Product atoms held 256 verb–object actions in about {kb(ev(32, 'product', 'inventory_bytes'), 0)} kB at any amount of experience, and their planning error fell from {f3(ev(1, 'product', 'plan_rms_vs_prototype'))} to {f3(ev(32, 'product', 'plan_rms_vs_prototype'))} rad as executions accumulated, while Part 1's role slots grew to {kb(ev(32, 'role', 'inventory_bytes') / 1000)} MB and stayed near {f3(ev(32, 'role', 'plan_rms_vs_prototype'))} rad. Sampling an atom in proportion to its count matched the frequencies of three unequal modes (total variation {f3(best_tv3)}); taking the arg-max always chose the commonest mode.
---

# 1 Introduction

The Vocabucapillary series represents language and action with two-level vocabularies: a small fixed set of primitives and a dynamic vocabulary of units built from them (Ghosh, 2026a, 2026b). For text the primitives are letters and the units are words. For the body the primitives are motor characters and the units are chunks of control steps, which an invertible sequence embedding (ISET) turns into compact codes (Ghosh, 2024, 2026e). The hybrid design uses ISET only for the character-level body modes and keeps word-level vocabularies for language and the other word modes.

Part 1 stored both kinds of token as dense vectors in one key–value cache (Ghosh, 2026g). It showed that one softmax can serve both encoders under a per-type normalized distance score, that a learned linear ISET decodes chunks within a motor tolerance, and that choosing an action mode before reading prevents valid modes from being averaged. It also left three gaps. A dense cache shares nothing between related words. Explicit association needs one or three vectors per episode, so its memory grows with experience and offers no inventory of what has been learned. And the discrete choice that prevents mode averaging had to be added from outside, by clustering stored codes.

This paper is Part 2. It replaces every word entry by a word-Vocabucapillary record, a sparse positive code over dynamic word atoms, and keeps chunk entries as dense ISET vectors. Queries remain vectors and the cache stores coefficients, the route the cacheless paper calls Route A (Ghosh, 2026b). Association moves into a counted vocabulary of product atoms trained on mixed tuples of word records and chunk codes, as the series proposed for association atoms (Ghosh, 2026c), and choosing an atom becomes the discrete choice of an action. Five questions organise the study.

1. What do word records save, and what does reading them cost? (Section 5)
2. Do records reproduce dense scores exactly, and what do they add when a word is observed uncertainly? (Sections 4 and 6)
3. How do records behave over long mixed histories, in deeper layers and in cacheless states? (Section 7)
4. Can a counted inventory of product atoms replace explicit episode memories for association? (Section 8)
5. Does choosing an atom solve the choice of an action mode? (Section 9)

Section 4 states six exact properties that frame the answers, and Section 10 assembles a Part 2 design. All numbers come from the immutable C# laboratory of Appendix B. Part 3, the last of the series, will take up the neuroscience. Figure 1 summarises the design.

![Figure 1. Sparse word records and dense ISET chunk tokens in one cache, with counted association atoms.](FIG/fig1_hybrid_cache.png){{width=6.5in}}

# 2 Related work

Sparsity in attention usually means sparse attention weights, as with sparsemax, which projects scores onto the simplex and returns exact zeros (Martins & Astudillo, 2016). Here the sparsity is in what is stored: each token keeps a few coefficients over a vocabulary of atoms, and attention remains a softmax. Coding vectors by short codes and scoring them with precomputed tables is the idea of product quantization, which splits a vector into sub-vectors, quantizes each and computes distances by table lookups (Jégou et al., 2011). The primitive table of Section 3 does the same at the level of letters: one small table per query, then lookups per stored item. Transformer-VQ quantizes keys to a codebook and keeps cached aggregates of values per code, so that attention runs in linear time (Lingle, 2024). The per-atom aggregate of Section 7 is that mechanism with sparse positive codes over word atoms in place of single codewords. Within this series, the coefficient score and the KV coefficient law with its Jensen gap come from the KV coefficient and cacheless papers (Ghosh, 2026a, 2026b), attention in sparse positive coefficient spaces from Ghosh (2026h), and the separation of support size from coefficient precision from Vocabuquantization (Ghosh, 2026i).

Product atoms are clustered in one pass with a distance threshold. This is the online form of DP-means, which Kulis and Jordan (2012) derived from the small-variance limit of a Dirichlet-process mixture: a point farther than the threshold from every centre starts a new cluster. Choosing a discrete action mode and then refining it is how Behavior Transformers keep several modes of demonstrations (Shafiullah et al., 2022), and VQ-BeT does the same with vector-quantized codes of chunks (Lee et al., 2024). Product atoms are the memory counterpart: the mode is an inventory entry with a count, not a predicted bin. The number of distinct words grows sublinearly with the number of tokens (Heaps, 1978), which is why a vocabulary of atoms grows much more slowly than a cache of tokens. Step 1 of the word-level programme compared slot-aligned and pooled word keys in a dense cache (Ghosh, 2026f), and the character paper showed that compact codes can address text well and still spell it poorly (Ghosh, 2026d).

{t_forms}
# 3 Formulation

## 3.1 A two-level word vocabulary

The primitives are the 26 letters, a padding symbol PAD and an end-of-word symbol EOS, each with a vector e(p) of width d in every head; E = [e(0), …, e(27)]. A word atom a is defined by its spelling S(a) = (D₁(a), …, D₁₆(a)), one sparse positive dictionary over the primitives for each of 16 slots. An exact word has one-hot slots, letters first and PAD after; a soft atom keeps several letters in a slot. The primitives are fixed, and the atoms form a dynamic vocabulary that grows as new spellings appear. A word token is stored as a record c, a code on the simplex over atoms with at most s non-zero entries, each kept as a 16-bit atom index and an 8-bit coefficient. Its keys are decoded through the atoms:

$$k(a) = [E D_1(a);\\ \\dots;\\ E D_{{16}}(a)], \\qquad k_b(a) = \\sum_{{j<n}} R_j E D_j(a) + R_n\\, e(\\mathrm{{EOS}}), \\qquad k(c) = \\sum_a c_a\\, k(a), \\quad\\quad\\quad (1)$$

where k is the concatenated layout of width 16d, $k_b$ the bound layout of width d used in Part 1 with signed permutations Rⱼ, and n the word length.

## 3.2 Scoring records through primitive tables

A query in the concatenated layout, q = [q₁; …; q₁₆], is first turned into a table of 16 × 28 primitive scores, and every atom and record is then scored by lookups:

$$U_{{jp}} = q_j^{{\\top}} e(p), \\qquad s(a) = \\sum_{{j=1}}^{{16}} \\sum_p D_{{jp}}(a)\\, U_{{jp}}, \\qquad s(c) = \\sum_a c_a\\, s(a). \\quad\\quad\\quad (2)$$

The table costs 16 · 28 · d = 448d multiply-adds once per query and head, each atom 16 lookups for an exact spelling, and each record s more. The bound layout uses $U^{{b}}_{{jp}} = (R_j^{{\\top}} q)^{{\\top}} e(p)$ over 17 slots. The distance score of Part 1 also needs each key's norm, which is stored once per atom or computed through the Gram matrix Γ = EᵀE of the primitives.

## 3.3 Aggregation, pruning and mixing in coefficient space

The KV coefficient law reads a history of records cₜ with values vₜ from two aggregates (Ghosh, 2026a, 2026b):

$$m = \\sum_t c_t, \\qquad S = \\sum_t c_t\\, v_t^{{\\top}}, \\qquad \\tilde o(q) = \\frac{{S^{{\\top}} \\varphi(q)}}{{m^{{\\top}} \\varphi(q)}}, \\qquad \\varphi_a(q) = \\exp(s(a)/\\tau). \\quad\\quad\\quad (3)$$

The state has one mass and one value sum per atom, whatever the length of the history. A slot–primitive aggregate applies the same law to the 448 pairs of a slot and a primitive, each token giving a coefficient of 1/16 to each of its 16 pairs; its state has a fixed size. Pruning keeps the largest coefficients of a record and renormalizes them; η is the pruned mass. Quantization stores coefficients in b bits, apportioned so that they still sum to one. In a deeper layer, attention adds the context to a position. In coefficient space the attention output ō is itself a record, here the mean of the previous 16 records, and the position's record becomes

$$c' = \\frac{{c + \\beta\\, \\bar o}}{{1 + \\beta}}, \\quad\\quad\\quad (4)$$

so that β is the mass of context relative to the token's own.

## 3.4 Counted association atoms

An episode arrives as a mixed tuple (u, w, z): a verb record u, an object record w and the dense ISET code z of the chunk that did it. A product atom holds (uₘ, wₘ, μₘ, nₘ, σₘ²): the word codes of its roles, the mean action code, a count and the variance of the codes. Training is one pass over the stream. Among the atoms with the tuple's word codes, the nearest mean is found, and

$$\\lVert z - \\mu_{{m}} \\rVert \\le \\theta \\ \\Rightarrow\\ n_m \\leftarrow n_m + 1,\\ \\ \\mu_m \\leftarrow \\mu_m + (z - \\mu_m)/n_m, \\quad\\quad\\quad (5)$$

with the variance updated by Welford's rule; otherwise the tuple starts a new atom (u, w, z) with a count of one. Different word codes never share an atom, so the threshold θ only separates action modes of the same words. A densified atom runs the same clustering on one dense joint vector $[\\hat k_u;\\ \\hat k_w;\\ z/s_z]$ of unit bound word keys and the scaled action code, as a dense codebook would. Planning finds the atoms whose word codes match the cue and decodes a mean; a cue spelled as a new atom is first resolved through the primitive table. Description finds the nearest mean to a fresh code and reads that atom's word codes.

## 3.5 Choosing an atom

Several atoms can share a cue, one for each way of doing the action. A soft read over them returns the count-weighted mean of their means. The arg-max read takes the atom with the largest count. A sampled read draws an atom with probability proportional to its count and may add a residual from its variance:

$$P(m) = \\frac{{n_m}}{{\\sum_{{m'}} n_{{m'}}}}, \\qquad z = \\mu_m + \\sigma_m \\odot g, \\quad g \\sim N(0, I). \\quad\\quad\\quad (6)$$

The decoded chunk goes to the body, whose fast loop corrects the residual at actuator rate.

# 4 Exact properties

**Proposition 1 (coefficient score).** For every query and record, Equation 2 equals $q^{{\\top}} k(c)$, the dense score of the decoded key, in the concatenated layout, and the bound table gives $q^{{\\top}} k_b(c)$. Norms follow from the primitive Gram matrix, $\\lVert k(c) \\rVert^2 = \\sum_{{a,b}} c_a c_b \\sum_j D_j(a)^{{\\top}} \\Gamma D_j(b)$. Every decision that depends only on scores, including Part 1's one softmax over word and chunk keys under the per-type normalized distance, is therefore unchanged when word keys become records.

**Proposition 2 (count implementation and Jensen gap).** Equation 3 weights token t by $\\sum_a c_{{ta}} \\varphi_a$. For a one-hot record this is $\\exp(q^{{\\top}} k(c_t)/\\tau)$, so the coefficient read equals softmax attention over the tokens. For a mixed record the weight is $\\exp(q^{{\\top}} k(c_t)/\\tau + J_t)$ with

$$0 \\le J_t = \\log \\sum_a c_{{ta}}\\, e^{{s(a)/\\tau}} - \\sum_a c_{{ta}}\\, s(a)/\\tau \\le \\frac{{R_t^2}}{{8}}, \\quad\\quad\\quad (7)$$

where Rₜ is the range of s(a)/τ over the record's support. A mixed record is weighted up by at most $e^{{R_t^2/8}}$.

**Proposition 3 (pruning and precision).** Pruning mass η and renormalizing moves a record by total variation exactly η and its decoded key by at most ηD*, where D* is the largest distance between keys of the support. Any change of coefficients, such as quantization, changes the score by at most the total variation times the range R of the atom scores on the support.

**Proposition 4 (support union and identity under mixing).** A positive combination of records is supported on the union of their supports. If a position's own record is one-hot on atom a*, then a* remains the largest coefficient of Equation 4 whenever $\\beta \\max_b \\bar o_b < 1$.

**Proposition 5 (conjunction blindness of slot–primitive masses).** The slot–primitive masses depend only on which letters occur in which slots. Two histories that place the same letters in the same slots, such as {{cat, dog}} and {{cog, dat}}, have identical masses, and every function of them, including the evidence $\\log m^{{\\top}}\\varphi(q)$ for any query, has the same value for both. Per-atom masses tell them apart.

**Proposition 6 (posterior record and soft atom).** Let P be a posterior over candidate words of one length, stored either as the record $\\sum_w P(w)\\, e_w$ over lexicon atoms or as one soft atom whose slots hold the marginals $D_j = \\sum_w P(w)\\, e_{{w_j}}$. Both decode to the same key in either layout, so they give the same score against every query. They differ in what they name: the record names candidate words with their joint probabilities, the soft atom only letters by slot, and the product of its marginals also weights recombinations that are not candidates.

{t_ident}
Table 2 confirms the properties numerically. Table and dense scores agreed to {p10(g('V01.score_identity_concat_max_abs'))} in the concatenated layout and {p10(g('V01.score_identity_bound_max_abs'))} in the bound layout, for scores up to {f1(g('V01.score_scale_max'))}. The Jensen gap stayed inside its bound in all {n0(g('V01.jensen_cases'))} mixed records tested, and the largest ratio to R²/8 was {f4(g('V01.jensen_max_ratio'))}: the bound is tight for narrow score ranges. The guarantee of Proposition 4 held in all {n0(g('V01.mix_guaranteed_cases'))} cases where it applied, and where β·max ō ≥ 1 the argmax was lost in {pc(g('V01.mix_outside_flip_share'))} of cases, so the condition is not idle. For the query *cat*, the concatenated score of *dat* is {f2(g('V01.conj_cat_score_dat'))} and of *cog* {f2(g('V01.conj_cat_score_cog'))} against {f2(g('V01.conj_cat_score_cat'))} for *cat* itself, so per-atom evidence separates the two histories by {f2(g('V01.conj_atom_evidence_diff'))} nats at τ = 0.25, while slot–primitive evidence cannot separate them at all.

# 5 Accounting

The laboratory takes English word frequencies from the wordfreq list (Speer, 2022). Distinct words grow sublinearly with tokens: {f1(g('V00.heaps_M150_distinct'))} distinct words in 150 tokens ({pc(g('V00.heaps_M150_distinct_share'))}), {n0(g('V00.heaps_M10000_distinct'))} in 10,000 ({pc(g('V00.heaps_M10000_distinct_share'))}) and {n0(g('V00.heaps_M1000000_distinct'))} in a million ({pc(g('V00.heaps_M1000000_distinct_share'), 1)}), with a local exponent falling from {f2(g('V00.heaps_M1000_local_exponent'))} to {f2(g('V00.heaps_M1000000_local_exponent'))} as the 50,000-word lexicon saturates.

{t_store}
![Figure 2. Cache bytes for one minute, and the work of one word query against the number of word tokens.](FIG/fig2_accounting.png){{width=6.5in}}

Records make words almost free to store (Table 3, Figure 2). In one minute, the words of Part 1 took {kb(min_wd)} kB per head and layer, their keys and values plus the letter slots kept for reranking. As records with s = 1 they took {kb(min_wr)} kB, of which {f2(min_inv / 1000)} kB were the spellings of the {f1(g('V00.minute_distinct_words'))} distinct atoms, and {kb(min_wr4)} kB with s = 4. A record matches the bytes of one dense key and value at s = {f1(g('V00.break_even_support_head'))} per head and layer, and at s = {n0(g('V00.break_even_support_layer8'))} for a layer of eight heads, because one record serves every head. The whole cache, however, shrank only to {pc(ratio_min, 1)} of Part 1 in one head and to {pc(l8, 1)} in eight, because the {n0(g('V00.minute_chunk_tokens'))} chunk tokens of a minute now hold {pc(chunk_share, 1)} of it. Once words are sparse, the dense chunks are what remains to be compressed.

{t_macs}
Reading has a fixed price (Table 4). The primitive table costs {n0(g('V00.primitive_table_fixed_macs'))} multiply-adds before any record is read, so for 64 word tokens it is {f1(1 / qv(64, 'dense_over_primitive'))} times dearer than a dense scan of their keys. It breaks even at {n0(g('V00.break_even_tokens_primitive_table'))} word tokens ({f1(g('V00.break_even_tokens_all_distinct'))} if every word were distinct), and beyond that the advantage grows with the history: {f1(qv(16384, 'dense_over_primitive'))} times fewer multiply-adds at 16,384 word tokens and {f1(qv(65536, 'dense_over_primitive'))} times at 65,536. A table of precomputed atom keys is cheaper still for short histories, but it stores {n0(g('V00.atom_key_dictionary_bytes_head') / 1e6)} MB per head and layer for the lexicon, while the primitive table needs 28 vectors.

# 6 Word tokens as records

Study V02 uses the histories of Step 1: a target word of 3–12 letters, up to eight near-duplicates (anagrams, affix relatives and words one edit away) and frequency-sampled fillers, 256 tokens in all ({f1(g('V02.mean_distinct_words'))} distinct words on average). Queries are the target's key with relative noise σ = 0.5.

{t_exact}
With exact spellings, records reproduce dense retrieval exactly (Table 5), as Proposition 1 requires: the target was found in every history in both layouts, and the top-ranked word was the same in all of them. The cost differs by layout. A dense concatenated cache reads 16 vectors per word, and the table did the same work with {f1(g('V02.A_mac_dense_concat') / g('V02.A_mac_table_concat'))} times fewer multiply-adds. A dense bound key is a single vector, so for {f1(g('V02.mean_distinct_words'))} distinct words a dense scan was {f1(g('V02.A_mac_table_bound') / g('V02.A_mac_dense_bound'))} times cheaper than the bound table, in line with the break-even of Section 5.

Records earn their keep when a word is not observed cleanly. Each token is observed through a letter channel that keeps a letter with probability 1 − ε and otherwise replaces it by another member of its confusion set: {{a, o, u}}, {{b, d, p}}, {{c, e, s}}, {{f, h, k}}, {{g, q, y}}, {{i, j, l}}, {{m, n, r}}, {{t, x, z}} or {{v, w}}. The posterior over lexicon words of the same length and confusion pattern is $P(w \\mid o) \\propto P(w) \\prod_j P(o_j \\mid w_j)$, and the true word is always among its {f1(cv(0.2, 'posterior_support'))} candidates on average. The token is then stored in one of seven ways (Table 6).

{t_obs}
{t_ex}
![Figure 3. Word tokens observed through the letter channel: retrieval of the target, reading of each token, and atoms added to the vocabulary.](FIG/fig3_word_records.png){{width=6.5in}}

The lexicon carried most of the gain (Tables 6 and 7, Figure 3). At ε = 0.1, 0.2 and 0.3 the observation was wrong for {pc(cv(0.1, 'observation_wrong'))}, {pc(cv(0.2, 'observation_wrong'))} and {pc(cv(0.3, 'observation_wrong'))} of tokens. The most likely word corrected {pc(cv(0.1, 'map_corrects_wrong_observation'), 1)}, {pc(cv(0.2, 'map_corrects_wrong_observation'), 1)} and {pc(cv(0.3, 'map_corrects_wrong_observation'), 1)} of wrong observations, and overrode {pc(cv(0.1, 'map_overrides_right_observation'), 1)}, {pc(cv(0.2, 'map_overrides_right_observation'), 1)} and {pc(cv(0.3, 'map_overrides_right_observation'), 1)} of right ones, when a rarer word seen correctly lost to a commoner neighbour. Storing the observed letters, as a dense cache that encodes what it sees would, found the target in {pc(uv(VOB, 0.1, 'target_found'), 1)}, {pc(uv(VOB, 0.2, 'target_found'), 1)} and {pc(uv(VOB, 0.3, 'target_found'), 1)} of histories. Storing the most likely word raised this to {pc(uv(VMAP, 0.1, 'target_found'), 1)}, {pc(uv(VMAP, 0.2, 'target_found'), 1)} and {pc(uv(VMAP, 0.3, 'target_found'), 1)}.

Keeping the uncertainty added more as the channel got worse: the full posterior found the target in {pc(uv(VFULL, 0.1, 'target_found'), 1)}, {pc(uv(VFULL, 0.2, 'target_found'), 1)} and {pc(uv(VFULL, 0.3, 'target_found'), 1)} of histories, {f1(100 * gain[0.1])}, {f1(100 * gain[0.2])} and {f1(100 * gain[0.3])} points above the most likely word. When the most likely word is wrong, the true word still carries part of the record's mass, so the token scores between the target and a stored near-duplicate. Two atoms were enough: the top two kept the true word for {pc(uv(VT2, 0.2, 'true_word_retained'), 1)} of tokens at ε = 0.2 and matched the full posterior, which needed {f1(uv(VFULL, 0.2, 'entries_per_token'))} entries per token. Precision and support are separate controls, as Vocabuquantization proposes: with 4-bit coefficients the top four lost at most {f1(100 * max(uv(VT4, e, 'target_found') - uv(VQ4, e, 'target_found') for e in EPS))} points of retrieval, and because small coefficients round to zero they kept only {f2(uv(VQ4, 0.1, 'entries_per_token'))} to {f2(uv(VQ4, 0.3, 'entries_per_token'))} entries per token.

The soft atom matched the full posterior in every history, as Proposition 6 requires, but at a different price. It adds an atom to the vocabulary for every observation whose marginals are not one-hot, {f1(uv(VSOFT, 0.1, 'new_atoms_per_history'))} to {f1(uv(VSOFT, 0.3, 'new_atoms_per_history'))} per history of 256 tokens, and the product of its marginals put {pc(uv(VSOFT, 0.1, 'product_mass_off_candidates'), 1)} to {pc(uv(VSOFT, 0.3, 'product_mass_off_candidates'), 1)} of its mass on strings that were not candidates; its letter-by-letter reading was not a word for {pc(uv(VSOFT, 0.1, 'reading_not_a_word'), 2)} to {pc(uv(VSOFT, 0.3, 'reading_not_a_word'), 2)} of tokens. The observed letters added {f1(uv(VOB, 0.1, 'new_atoms_per_history'))} to {f1(uv(VOB, 0.3, 'new_atoms_per_history'))} non-word atoms per history. Records over lexicon atoms added none.

# 7 The hybrid cache

## 7.1 Long mixed histories

{t_long}
In long mixed histories the word side became exact and cheap at once (Table 8). Every word query found the exact word in every history at every length, without a screen, because the primitive table scores every record exactly. At 16,384 tokens this took {n0(lv(16384, 'mac_word_query'))} multiply-adds against {n0(lv(16384, 'mac_word_query_part1'))} for Part 1's screen and rerank, {f1(lv(16384, 'mac_word_query_part1') / lv(16384, 'mac_word_query'))} times fewer. At 256 tokens the fixed table cost more than Part 1's screen ({n0(lv(256, 'mac_word_query'))} against {n0(lv(256, 'mac_word_query_part1'))}). Chunk queries kept Part 1's two stages, a metric screen and a categorical rerank. The screen alone found the exact chunk in only {pc(lv(256, 'chunk_exact_screen_only'), 1)} to {pc(lv(16384, 'chunk_exact_screen_only'), 1)} of queries, because executions of one skill lie close together, and the rerank of eight made every query exact. The typed screen skips word tokens, so chunk queries also became cheaper, by {pc(1 - lv(16384, 'mac_chunk_query') / lv(16384, 'mac_chunk_query_part1'))} at 16,384 tokens. The cache was {pc(1 - lv(16384, 'cache_bytes_head_layer') / lv(16384, 'cache_bytes_head_layer_part1'))} smaller per head and layer. The chunk tokens now dominate both the work and the memory.

## 7.2 Deeper layers

{t_depth}
![Figure 4. Left: a word position in a deeper layer, read from its record and from the decoded dense key. Right: cacheless states.](FIG/fig4_depth_cacheless.png){{width=6.5in}}

Part 1 found that context mixed into a dense key soon makes it unreadable. In coefficient space the same mixing leaves the identity in plain view (Table 9, Figure 4). Up to a context mass of β = 2, where the decoded context is {f2(dv(2, 'decoded_context_to_self_l2'))} of the key's own norm, the record's largest coefficient was its own atom at every one of the {n0(g('V03.depth_b0_positions'))} positions, and the spelling is then read from that atom. Unbinding the decoded dense key spelled {pc(dv(1, 'dense_key_spelled_by_unbinding'), 1)} of words at β = 1, {pc(dv(2, 'dense_key_spelled_by_unbinding'), 1)} at β = 2 and {pc(dv(4, 'dense_key_spelled_by_unbinding'), 1)} at β = 4; even without context it spelled {pc(dv(0, 'dense_key_spelled_by_unbinding'), 1)}, because long words exceed what a bound key of width 128 can hold. Beyond β = 2 the record's identity followed Proposition 4 exactly: it held for {pc(dv(4, 'record_identity_argmax'), 1)} of positions at β = 4 and {pc(dv(8, 'record_identity_argmax'), 1)} at β = 8, the shares for which β·max ō < 1, and for none at β = 16, where every context atom weighs at least as much as the position's own.

Retrieval is the same for the record and its decoded key (Proposition 1): {pc(dv(2, 'retrieval_full_record'), 1)} of queries found the exact position at β = 2, {pc(dv(4, 'retrieval_full_record'), 1)} at β = 4 and {pc(dv(8, 'retrieval_full_record'), 1)} at β = 8. Mixing grew the support to {f1(dv(1, 'record_support'))} atoms, the union of Proposition 4. Truncating it to the top four removed {f2(dv(1, 's4_pruned_mass_tv'))} of the mass at β = 1 and {f2(dv(8, 's4_pruned_mass_tv'))} at β = 8, never the position's own atom while the guarantee held, and it raised retrieval to {pc(dv(4, 's4_retrieval'), 1)} at β = 4 and {pc(dv(8, 's4_retrieval'), 1)} at β = 8, because what it discards is the context. Truncating to 16 atoms removed at most {pc(dv(16, 's16_pruned_mass_tv'), 1)}.

## 7.3 Cacheless states

{t_agg}
The cacheless state must be kept per word atom (Table 10, Figure 4). With one-hot records the per-atom aggregate read exactly what softmax attention over the 256 tokens read (largest difference {p10(g('V03.agg_tau0.25_kv_minus_atom_max_abs'))}), found the value of the target in {pc(av(0.25, 'per-atom', 'value_of_present_word_found'), 1)} of histories at τ = 0.25, and needed {n0(av(0.25, 'per-atom', 'state_floats'))} floats against {n0(av(0.25, 'KV cache', 'state_floats'))} for the cache. Its evidence told present words from recombination probes with an AUC of {f3(av(0.25, 'per-atom', 'presence_auc_vs_recombination_probes'))}, but only at a sharp temperature: at τ = 1 the same evidence gave {f3(av(1.0, 'per-atom', 'presence_auc_vs_recombination_probes'))}. The slot–primitive aggregate, a fixed state of {n0(av(0.25, 'slot', 'state_floats'))} floats, found the target's value in only {pc(av(0.25, 'slot', 'value_of_present_word_found'), 1)} of histories, and its evidence did no better than chance at telling present words from recombinations (AUC {f3(av(0.25, 'slot', 'presence_auc_vs_recombination_probes'))}). This is Proposition 5 at work: the masses of slot–letter pairs do not record which letters belonged to one word.

# 8 Counted association atoms

Study V04 uses the 256 verb–object actions of Part 1: sixteen verbs (*grasp*, *push*, *pull*, …) and sixteen objects (*cup*, *box*, *door*, …), with prototype chunks that mix a verb pattern, an object pattern and a pair-specific pattern carrying a share ι of the variance. Executions of every pair arrive in a shuffled stream as mixed tuples of two exact word records and the learned linear ISET code (rank 56) of the 8-step chunk. Product atoms use the threshold θ = 1 in code space; executions of one pair lie about 0.3 apart and different pairs more than 2.

{t_exp}
![Figure 5. Association atoms: planning error and inventory against experience, and description against the clustering threshold.](FIG/fig5_association_atoms.png){{width=6.5in}}

A counted inventory turned experience into accuracy instead of memory (Table 11, Figure 5). Product atoms held {n0(ev(1, 'product', 'inventory_entries'))} to {n0(max(ev(E, 'product', 'inventory_entries') for E in Es))} atoms whatever the number of executions per pair, about {kb(ev(4, 'product', 'inventory_bytes'), 0)} kB at 120 bytes per atom; the few atoms beyond 256 were started by executions that arrived far from their pair's running mean, and planning reads the most counted atom. Their planning error fell from {f4(ev(1, 'product', 'plan_rms_vs_prototype'))} rad with one execution per pair to {f4(ev(4, 'product', 'plan_rms_vs_prototype'))} with four and {f4(ev(32, 'product', 'plan_rms_vs_prototype'))} with 32, well below the {f3(g('V04.exp_E4_execution_floor'))} rad by which a single execution differs from its prototype, because the mean of a pair's executions averages out amplitude jitter, sensor noise and contact transients. Role slots stored every execution, {kb(ev(1, 'role', 'inventory_bytes'), 0)} kB with one per pair and {kb(ev(32, 'role', 'inventory_bytes') / 1000)} MB with 32, and their planning error stayed at the level of one execution ({f4(ev(32, 'role', 'plan_rms_vs_prototype'))} rad at E = 32). Densified atoms matched the product atoms in error at θ = 1, but their dense word parts made each atom 624 bytes, {kb(ev(4, 'densified', 'inventory_bytes'), 0)} kB in all.

{t_int}
Like role slots, product atoms do not care how much of an action depends on the pair (Table 12): their planning error was {f4(iv(0.0, 'product', 'plan_rms_vs_prototype'))}, {f4(iv(0.5, 'product', 'plan_rms_vs_prototype'))} and {f4(iv(1.0, 'product', 'plan_rms_vs_prototype'))} rad for ι = 0, 0.5 and 1, and description was always perfect. The linear map of Part 1 was the best planner without interaction ({f4(iv(0.0, 'linear', 'plan_rms_vs_prototype'))} rad) and failed with it ({f3(iv(1.0, 'linear', 'plan_rms_vs_prototype'))} rad, description {pc(iv(1.0, 'linear', 'describe_both_words'), 1)}), because it keeps only the additive part.

{t_th}
Exact word codes make the threshold harmless (Table 13). Product atoms planned and described correctly at every threshold from 0.1 to 3; a small θ only split the executions of a pair into more atoms ({n0(tv(0.1, 'product', 'inventory_entries'))} at θ = 0.1), and from θ = 1.5 on there was exactly one atom per pair. Densified atoms put word and action distances under one threshold, so the same threshold that merges a pair's executions also merges different pairs: at θ = 1.5 only {pc(tv(1.5, 'densified', 'purity'), 1)} of executions sat in an atom of their own pair, at θ = 2 the inventory collapsed to {n0(tv(2.0, 'densified', 'inventory_entries'))} atoms, and at θ = 3 to one.

Exact codes have one weakness. A cue with one letter substituted in the verb ({miss_ex}, …) matched no atom in any of the 256 cases, because a misspelled word is a new atom that no product atom contains. Scoring the misspelled cue through the primitive table against the 16 verb atoms found the right verb, and then the right pair, in {pc(g('V04.miss_table_plan'))} of cases, as did role slots, whose dense bound keys tolerate the change ({pc(g('V04.miss_slots_plan'))}). The primitive table is therefore part of the association read: cues are matched by spelling before they are matched by identity.

# 9 Choosing an atom

Study V05 stores 512 executions of the two-way obstacle task of Part 1 under one cue, and a three-mode variant with amplitudes +1, −1 and +2 and frequencies 0.6, 0.3 and 0.1. Product atoms formed {n0(g('V05.two_atoms'))} atoms for the two-way task ({n0(g('V05.two_atom0_count'))} executions passing left and {n0(g('V05.two_atom1_count'))} right) and {n0(g('V05.three_atoms'))} for the three-mode task, where the wide mode +2, whose executions spread twice as far, split into atoms of {n0(g('V05.three_atom2_count'))} and {n0(g('V05.three_atom3_count'))}. The same {n0(g('V05.two_atoms'))} atoms held from 16 executions to 512, {n0(fl(ainv[0]['atom_bytes']))} bytes against {kb(fl(ainv[5]['dense_kv_bytes_head_layer']), 0)} kB of dense keys and values per head and layer for 512 entries.

{t_choice}
![Figure 6. Left: decoded reads of the two-way task for one query, with eight sampled reads. Right: mode shares in the three-mode task.](FIG/fig6_atom_choice.png){{width=6.5in}}

Choosing an atom is the discrete choice that Part 1 had to add from outside (Table 14, Figure 6). The soft read over atoms is the count-weighted mean of their means: in the two-way task it ran along the centre line and every read collided, as the dense soft read of Part 1 did at β = 30; in the three-mode task it did not collide but passed at an amplitude no mode has ({f3(cc('three unequal modes', 'soft read over atoms', 'off_manifold_rms'))} off the manifold). The arg-max of counts never collided, but it chose the commonest mode every time, so the three-mode shares were off by a total variation of {f3(cc('three unequal modes', 'arg-max count', 'mode_share_tv'))}. Sampling an atom in proportion to its count matched the three stored shares to {f3(cc('three unequal modes', 'atom sampled by count', 'mode_share_tv'))} and sent {pc(cc('two modes', 'atom sampled by count', 'share_mode0_left'), 1)} of two-way reads to the left against {pc(g('V05.two_stored_share_mode0'), 1)} stored, without collisions. Its outputs were the atom means themselves, on the manifold ({f4(cc('two modes', 'atom sampled by count', 'off_manifold_rms'))}) but only {n0(cc('two modes', 'atom sampled by count', 'distinct_outputs_of_1000'))} distinct paths. Adding a residual drawn from the atom's variance produced {n0(cc('two modes', 'sampled atom plus residual', 'distinct_outputs_of_1000'))} distinct paths, none colliding, {f3(cc('two modes', 'sampled atom plus residual', 'off_manifold_rms'))} from the manifold and {f2(cc('two modes', 'sampled atom plus residual', 'nearest_stored_over_spacing'))} of the spacing from the nearest stored execution. Part 1's best dense reader, a mode sampled from the attention mass and a soft read within it, did as well ({f3(cc('two modes', 'dense sampled mode, then soft within', 'mode_share_tv'))} and {f3(cc('three unequal modes', 'dense sampled mode, then soft within', 'mode_share_tv'))} in total variation) but needed 512 cache entries and a clustering step. The dense hard top-1 read copied stored executions ({f2(cc('two modes', 'dense hard top-1', 'nearest_stored_over_spacing'))} of the spacing) and favoured one side ({pc(cc('two modes', 'dense hard top-1', 'share_mode0_left'), 1)} left).

# 10 A Part 2 design, and what remains

The results suggest a design for the hybrid with sparse words.

1. **Word entries:** records over a dynamic vocabulary of word atoms; s = 1 for clean text, and two to four entries with 4-bit coefficients when a word is observed uncertainly. Spellings live once in the atom inventory, and new atoms are added only for words the lexicon lacks.
2. **Word reading:** one primitive table per query and head scores every record exactly. Below about 500 word tokens a dense scan of decoded keys is cheaper.
3. **Chunk entries:** dense learned linear ISET codes with a raw-character pointer, as in Part 1, read by a typed screen and a per-step rerank. They now hold almost all of the cache.
4. **Depth:** identity and spelling are read from the largest coefficient wherever β·max ō < 1. Truncating the grown support keeps identity and discards context, so it belongs to memory layers.
5. **Cacheless state:** per-atom aggregates, never slot–primitive ones, with a sharp temperature when presence must be judged.
6. **Association:** product atoms keyed by exact word codes, with an action threshold above the spread of one pair's executions; cues are resolved through the primitive table before codes are matched.
7. **Acting:** sample an atom by its count, add a residual from its variance for variety, decode, and let the fast loop correct.

The chunk tokens are now the bottleneck: they hold {pc(chunk_share, 1)} of a minute's cache and most of the work of a long history. Part 3 of the series turns to the neuroscience of the hybrid.

# 11 Limitations

The letter channel substitutes letters within fixed confusion sets and never inserts or deletes one, so every candidate has the observed length; real misreadings and mishearings are richer. Primitive vectors and word keys are random rather than trained, queries are noisy copies of keys, and no model was trained end to end. The deeper-layer model mixes in a plain mean of the previous 16 records. Cacheless states were tested with one-hot records and random values. Product atoms come from one-pass leader clustering, which depends on the order of arrival, as the split mode of Section 9 shows. The motions are synthetic, the association has 256 pairs, and the obstacle task has one cue. Byte counts ignore indexing structures, and no latency was measured.

# 12 Conclusion

Replacing dense word entries by word-Vocabucapillary records changes what the cache stores, not what it retrieves: through one table of primitive scores a record gives exactly the score of its decoded key. What changes is everything around the score. Words cost 3 bytes per entry and a few bytes of spelling per distinct atom, so a minute of speech takes {kb(min_wr)} kB instead of {kb(min_wd, 0)} kB per head and layer. A record keeps the uncertainty of an observation as candidates of the lexicon, which found the target {f1(100 * gain[0.3])} points more often than the most likely word alone when letters were misread at a rate of 0.3. It names its atoms in deeper layers, keeps cacheless states exact when they are kept per atom, and feeds a counted association vocabulary whose atoms improve with experience instead of growing with it and whose sampling is the choice of an action mode. The dense ISET chunks remain, and they are now most of the memory.

# Appendix A Proofs

**Proposition 1.** Equation 1 is linear in the coefficients and in the slot dictionaries, so $q^{{\\top}} k(c) = \\sum_a c_a \\sum_j q_j^{{\\top}} E D_j(a) = \\sum_a c_a \\sum_j \\sum_p D_{{jp}}(a)\\, q_j^{{\\top}} e(p)$, which is Equation 2. In the bound layout $q^{{\\top}} R_j E D_j(a) = (R_j^{{\\top}} q)^{{\\top}} E D_j(a)$. For the norm, $k(a)^{{\\top}} k(b) = \\sum_j D_j(a)^{{\\top}} E^{{\\top}} E D_j(b)$.

**Proposition 2.** For a one-hot record the sum has one term. Otherwise $\\sum_a c_{{ta}} e^{{x_a}}$ with $x_a = s(a)/\\tau$ is the expectation of $e^X$ for a variable X that takes the value $x_a$ with probability $c_{{ta}}$; Jensen's inequality gives J ≥ 0, and Hoeffding's lemma, $\\log E e^{{X}} - E X \\le (b - a)^2/8$ for X in [a, b], gives the upper bound (Hoeffding, 1963).

**Proposition 3.** Let K be the kept atoms and $\\tilde c_a = c_a/(1 - \\eta)$ on K. The total variation is $\\tfrac{{1}}{{2}}[\\eta + (1 - \\eta)\\eta/(1 - \\eta)] = \\eta$, and $k(c) - k(\\tilde c) = \\eta\\,(\\bar k_{{\\mathrm{{pruned}}}} - \\bar k_{{\\mathrm{{kept}}}})$, a difference of two points in the convex hull of the support's keys. For any change δ of coefficients with Σδ = 0, $\\sum_a \\delta_a s(a) = \\sum_a \\delta_a (s(a) - \\bar s)$ with $\\bar s$ the midpoint of the scores, which is at most $\\lVert \\delta \\rVert_1 R/2$, the total variation times R.

**Proposition 4.** A positive combination has a non-zero coefficient exactly where some term has one. With c one-hot on a*, $c'_{{a^\\ast}} \\ge 1/(1 + \\beta)$ and $c'_b = \\beta \\bar o_b/(1 + \\beta)$ for b ≠ a*.

**Proposition 5.** The mass of a slot–letter pair counts the tokens with that letter in that slot, so it depends only on the multiset of slot–letter pairs; the evidence depends on the query and the masses alone.

**Proposition 6.** $E D_j = \\sum_w P(w)\\, e(w_j)$ in every slot, and with one common length the EOS term of the bound layout is the same for all candidates, so both layouts decode to $\\sum_w P(w)\\, k(w)$. The product of the marginals gives a positive weight to every string whose slots each take some candidate's letter.

# Appendix B The immutable C# laboratory

The laboratory is a .NET 8 console project without external packages. Domain state lives in sealed records and read-only lists, every computation is a pure static function, and randomness comes from a SplitMix64 generator implemented as a readonly record struct whose draws return the value and the successor generator. It reuses the core of Part 1 (the MessagePack reader of the wordfreq English list, data under CC BY-SA 4.0; bound keys; the motor stream; the ISET encoders with a Jacobi eigen-solver; ridge regression, k-means and BF16 rounding) and adds word atoms with primitive tables, records with truncation, quantization and mixing, the letter channel with its lexicon posterior, product atoms with one-pass leader clustering, and the chunk bank of the hybrid. One output boundary writes CSV tables and a JSON file of headline values.

A separate Python program decodes the word list with its own reader. With line-for-line ports of the generator it regenerates the counts of distinct words, the break-even length, the Step 1 histories, the letter channel, its posteriors and the retrieval of the most-likely-word and full-posterior records, the identities of records in deeper layers, the association executions and the obstacle trajectories with their atoms; with numpy it tests the exact properties on independent draws. {py_agree} quantities agreed. Running `dotnet run -c Release` executes all six studies in about two minutes on two cores.

Table: Table 15. Studies of the laboratory.

| Study | Sections | Question | Kind of result |
|----------|----------|----------------------------------------------|--------------------|
| V00 | 5 | Bytes and work of word records beside dense chunks; distinct words against tokens | Accounting |
| V01 | 4 | Coefficient score, Gram norms, count implementation, Jensen gap, pruning, quantization, support union, mixing, conjunction blindness | Exact |
| V02 | 6 | Records against dense keys; uncertain observation through a letter channel | Exact and Monte Carlo |
| V03 | 7 | Long mixed histories, deeper layers and cacheless states | Monte Carlo and accounting |
| V04 | 8 | Product atoms, densified atoms, role slots and a linear map for association | Exact counts |
| V05 | 9 | Soft, arg-max and sampled atom choice against the dense readers of Part 1 | Monte Carlo |

# References

Ghosh, D. P. (2024). *ISET: Invertible sequence embedding from Transformer* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.36457.67684

Ghosh, D. P. (2026a). *KV coefficient memory for Attentionlet* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.31586.70088

Ghosh, D. P. (2026b). *Vocabucapillary for cacheless transformer* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.36209.44648

Ghosh, D. P. (2026c). *Vocabucapillary memory for cooperative AI* (2nd ed.). Debias Parametric Guru.

Ghosh, D. P. (2026d). *Character vocabularies and ISET span memory: Spelling, order and linear-time reading in Vocabucapillary models* [Manuscript].

Ghosh, D. P. (2026e). *The cerebellum as a character-level ISET: Fine-resolution Vocabucapillary memory for physical AI* [Manuscript].

Ghosh, D. P. (2026f). *Words as sequences in self-attention: Slot-aligned, hierarchical and alignment scores over a dense word-level key–value cache* [Manuscript].

Ghosh, D. P. (2026g). *Words and action chunks in one dense key–value cache: ISET chunk tokens, bound word keys and mixed-modal attention* [Manuscript].

Ghosh, D. P. (2026h). *Vocabucapillary attention in sparse positive coefficient spaces* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.22633.66404

Ghosh, D. P. (2026i). *Vocabuquantization for memory efficient Vocabucapillary language models* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.21571.98085

Heaps, H. S. (1978). *Information retrieval: Computational and theoretical aspects*. Academic Press.

Hoeffding, W. (1963). Probability inequalities for sums of bounded random variables. *Journal of the American Statistical Association, 58*(301), 13–30. https://doi.org/10.1080/01621459.1963.10500830

Jégou, H., Douze, M., & Schmid, C. (2011). Product quantization for nearest neighbor search. *IEEE Transactions on Pattern Analysis and Machine Intelligence, 33*(1), 117–128. https://doi.org/10.1109/TPAMI.2010.57

Kulis, B., & Jordan, M. I. (2012). Revisiting k-means: New algorithms via Bayesian nonparametrics. *Proceedings of the 29th International Conference on Machine Learning*. arXiv:1111.0352.

Lee, S., Wang, Y., Etukuru, H., Kim, H. J., Shafiullah, N. M. M., & Pinto, L. (2024). Behavior generation with latent actions. *Proceedings of the 41st International Conference on Machine Learning*, PMLR 235, 26991–27008.

Lingle, L. D. (2024). Transformer-VQ: Linear-time transformers via vector quantization. *The Twelfth International Conference on Learning Representations*. arXiv:2309.16354.

Martins, A. F. T., & Astudillo, R. F. (2016). From softmax to sparsemax: A sparse model of attention and multi-label classification. *Proceedings of the 33rd International Conference on Machine Learning*, PMLR 48, 1614–1623.

Shafiullah, N. M. M., Cui, Z. J., Altanzaya, A., & Pinto, L. (2022). Behavior Transformers: Cloning k modes with one stone. *Advances in Neural Information Processing Systems, 35*. arXiv:2206.11251.

Speer, R. (2022). *wordfreq: Access a database of word frequencies, in various natural languages* (Version 3.1.1) [Software and data]. https://github.com/rspeer/wordfreq
"""
md = md.replace("FIG/", str(FIG) + "/")
(HERE / "paper.md").write_text(md, encoding="utf8")
subprocess.run(["pandoc", str(HERE / "paper.md"), "-o", str(HERE / "raw.docx"), "--reference-doc", str(HERE / "ref.docx")], check=True)
docxfix.repair(HERE / "raw.docx", HERE / "paper.docx")
(HERE / "raw.docx").unlink()
print("paper written:", len(md.split()), "words")
