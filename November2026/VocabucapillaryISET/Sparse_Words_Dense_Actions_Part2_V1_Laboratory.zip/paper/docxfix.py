"""Repairs pandoc's OOXML element-order quirks so the Word file validates."""
import re, zipfile

# Repair pandoc's element-order quirks so the file validates against the OOXML schema.
SETTINGS = ("writeProtection view zoom removePersonalInformation removeDateAndTime doNotDisplayPageBoundaries displayBackgroundShape "
 "printPostScriptOverText printFractionalCharacterWidth printFormsData embedTrueTypeFonts embedSystemFonts saveSubsetFonts saveFormsData "
 "mirrorMargins alignBordersAndEdges bordersDoNotSurroundHeader bordersDoNotSurroundFooter gutterAtTop hideSpellingErrors hideGrammaticalErrors "
 "activeWritingStyle proofState formsDesign attachedTemplate linkStyles stylePaneFormatFilter stylePaneSortMethod documentType mailMerge "
 "revisionView trackRevisions doNotTrackMoves doNotTrackFormatting documentProtection autoFormatOverride styleLockTheme styleLockQFSet "
 "defaultTabStop autoHyphenation consecutiveHyphenLimit hyphenationZone doNotHyphenateCaps showEnvelope summaryLength clickAndTypeStyle "
 "defaultTableStyle evenAndOddHeaders bookFoldRevPrinting bookFoldPrinting bookFoldPrintingSheets drawingGridHorizontalSpacing "
 "drawingGridVerticalSpacing displayHorizontalDrawingGridEvery displayVerticalDrawingGridEvery doNotUseMarginsForDrawingGridOrigin "
 "drawingGridHorizontalOrigin drawingGridVerticalOrigin doNotShadeFormData noPunctuationKerning characterSpacingControl printTwoOnOne "
 "strictFirstAndLastChars noLineBreaksAfter noLineBreaksBefore savePreviewPicture doNotValidateAgainstSchema saveInvalidXml ignoreMixedContent "
 "alwaysShowPlaceholderText doNotDemarcateInvalidXml saveXmlDataOnly useXSLTWhenSaving saveThroughXslt showXMLTags alwaysMergeEmptyNamespace "
 "updateFields hdrShapeDefaults footnotePr endnotePr compat docVars rsids mathPr attachedSchema themeFontLang clrSchemeMapping "
 "doNotIncludeSubdocsInStats doNotAutoCompressPictures forceUpgrade captions readModeInkLockDown smartTagType schemaLibrary shapeDefaults "
 "doNotEmbedSmartTags decimalSymbol listSeparator").split()

def top_children(body):
    kids, pos = [], 0
    pat = re.compile(r"<(w|m|sl|o|v|w10):([A-Za-z]+)\b[^>]*?(/>|>)")
    while True:
        mt = pat.search(body, pos)
        if not mt: return kids
        pre, name, end = mt.groups()
        if end == "/>": e = mt.end()
        else:
            close, depth, k = f"</{pre}:{name}>", 1, mt.end()
            while depth:
                o = re.compile(rf"<{pre}:{name}\b[^>]*?(/?)>|{re.escape(close)}").search(body, k)
                depth += -1 if o.group(0) == close else (0 if o.group(1) == "/" else 1); k = o.end()
            e = k
        kids.append((name, body[mt.start():e])); pos = e


def repair(raw, dest):
    src = zipfile.ZipFile(raw)
    out = zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED)
    for info in src.infolist():
        data = src.read(info.filename); n = info.filename
        if n.endswith("/"): continue
        t = None
        if n == "[Content_Types].xml":
            t = data.decode()
            if 'Extension="png"' not in t: t = t.replace("<Default ", '<Default Extension="png" ContentType="image/png" /><Default ', 1)
        elif n == "word/document.xml":
            t = data.decode()
            t = re.sub(r"(<m:begChr [^>]*/>)(<m:endChr [^>]*/>)(<m:sepChr [^>]*/>)", r"\1\3\2", t)
            t = re.sub(r'(<w:tblLook [^>]*/>)<w:jc w:val="start" />', r'<w:jc w:val="left" />\1', t)
            t = re.sub(r"<w:pPr>(<w:numPr>.*?</w:numPr>)(<w:pStyle [^>]*/>)", r"<w:pPr>\2\1", t)
            # Keep every table row on one page.
            t = t.replace("<w:tr><w:trPr>", "<w:tr><w:trPr><w:cantSplit />").replace("<w:tr><w:tc>", "<w:tr><w:trPr><w:cantSplit /></w:trPr><w:tc>")
        elif n == "word/numbering.xml":
            t = re.sub(r'w:nsid w:val="([0-9A-F]+)"', lambda mm: f'w:nsid w:val="{mm.group(1).zfill(8)[-8:]}"', data.decode())
        elif n == "word/styles.xml":
            t = data.decode().replace("/>&gt;", "/>")
            t = re.sub(r"(<w:vAlign [^>]*/>)(\s*)(<w:tcBorders>.*?</w:tcBorders>)", r"\3\2\1", t, flags=re.S)
            t = re.sub(r"(<w:pPr>\s*<w:spacing [^>]*/>\s*</w:pPr>)(\s*)(<w:qFormat />)", r"\3\2\1", t)
            t = re.sub(r'(<w:jc w:val="center" />)(\s*)(<w:spacing [^>]*/>)', r"\3\2\1", t)
        elif n == "word/settings.xml":
            t = data.decode()
            hm = re.match(r"(.*?<w:settings [^>]*>)(.*)(</w:settings>)\s*$", t, re.S)
            kids = sorted(top_children(hm.group(2)), key=lambda x: SETTINGS.index(x[0]) if x[0] in SETTINGS else 999)
            t = hm.group(1) + "".join(k for _, k in kids) + hm.group(3)
        out.writestr(info, t.encode() if t is not None else data)
    out.close()
