namespace VxLab.Core;

/// <summary>
/// Operations on sparse positive records (codes on the simplex over word atoms): truncation to a support size,
/// coefficient quantization, distances, and the bound and table forms of the coefficient score.
/// </summary>
public static class Rec
{
    /// <summary>Normalizes positive weights to a code, dropping zero entries and keeping the given order.</summary>
    public static Code FromWeights(IReadOnlyList<int> atoms, IReadOnlyList<double> weights)
    {
        double s = weights.Sum();
        var keep = Enumerable.Range(0, atoms.Count).Where(i => weights[i] > 0).ToArray();
        return new Code(keep.Select(i => atoms[i]).ToArray(), keep.Select(i => weights[i] / s).ToArray());
    }

    /// <summary>Keeps the s largest coefficients (lower atom index first on ties) and renormalizes.</summary>
    public static Code TopS(Code c, int s)
    {
        if (c.Support <= s) return c;
        var order = Enumerable.Range(0, c.Support).OrderByDescending(i => c.Coef[i]).ThenBy(i => c.Atom[i]).Take(s).ToArray();
        return FromWeights(order.Select(i => c.Atom[i]).ToArray(), order.Select(i => c.Coef[i]).ToArray());
    }

    /// <summary>
    /// Quantizes coefficients to multiples of 1/(2^bits − 1) by largest-remainder apportionment, so the quantized code
    /// still sums to one; entries that receive no unit are dropped (lower atom index first on equal remainders).
    /// </summary>
    public static Code Quantize(Code c, int bits)
    {
        int units = (1 << bits) - 1;
        var raw = c.Coef.Select(x => x * units).ToArray();
        var q = raw.Select(x => (int)Math.Floor(x)).ToArray();
        int left = units - q.Sum();
        var order = Enumerable.Range(0, c.Support).OrderByDescending(i => raw[i] - q[i]).ThenBy(i => c.Atom[i]).ToArray();
        for (int k = 0; k < left; k++) q[order[k]]++;
        return FromWeights(c.Atom, q.Select(x => (double)x).ToArray());
    }

    public static double Tv(Code a, Code b)
    {
        var m = new Dictionary<int, double>();
        for (int i = 0; i < a.Support; i++) m[a.Atom[i]] = m.GetValueOrDefault(a.Atom[i]) + a.Coef[i];
        for (int i = 0; i < b.Support; i++) m[b.Atom[i]] = m.GetValueOrDefault(b.Atom[i]) - b.Coef[i];
        return 0.5 * m.Values.Sum(Math.Abs);
    }

    /// <summary>Coefficient score Σ_a c_a s_a for precomputed atom scores.</summary>
    public static double Score(Code c, Func<int, double> atomScore)
    {
        double s = 0;
        for (int i = 0; i < c.Support; i++) s += c.Coef[i] * atomScore(c.Atom[i]);
        return s;
    }

    /// <summary>Decoded key Σ_a c_a k(a) for a function giving the dense key of an atom.</summary>
    public static double[] Decode(Code c, Func<int, IReadOnlyList<double>> key)
    {
        double[]? v = null;
        for (int i = 0; i < c.Support; i++)
        {
            var k = key(c.Atom[i]);
            v ??= new double[k.Count];
            for (int j = 0; j < k.Count; j++) v[j] += c.Coef[i] * k[j];
        }
        return v ?? Array.Empty<double>();
    }

    public static int Argmax(Code c)
    {
        int best = 0;
        for (int i = 1; i < c.Support; i++) if (c.Coef[i] > c.Coef[best] || (c.Coef[i] == c.Coef[best] && c.Atom[i] < c.Atom[best])) best = i;
        return c.Atom[best];
    }

    /// <summary>Convex combination Σ_t w_t c_t of records; the support is the union of the supports (Proposition 5 of the cacheless paper).</summary>
    public static Code Mix(IReadOnlyList<Code> codes, IReadOnlyList<double> w)
    {
        var m = new SortedDictionary<int, double>();
        for (int t = 0; t < codes.Count; t++)
            for (int i = 0; i < codes[t].Support; i++) m[codes[t].Atom[i]] = m.GetValueOrDefault(codes[t].Atom[i]) + w[t] * codes[t].Coef[i];
        return FromWeights(m.Keys.ToArray(), m.Values.ToArray());
    }

    /// <summary>Bound-layout primitive table U_b[j, p] = (R_jᵀ q) · e(p) for slots 0..16; scores bound keys by lookups.</summary>
    public static double[,] BoundTable(IReadOnlyList<double> q, CharCode e, Binder b)
    {
        var u = new double[Sym.L + 1, Sym.Count];
        for (int j = 0; j <= Sym.L; j++)
        {
            var r = b.Inverse(j, q);
            for (int p = 0; p < Sym.Count; p++) u[j, p] = Lin.Dot(r, e.Vectors[p]);
        }
        return u;
    }

    public static double BoundScore(double[,] u, WordAtom a)
    {
        int n = Math.Min(a.Text.Length, Sym.L);
        double s = 0;
        for (int j = 0; j < n; j++) { var sd = a.Slots[j]; for (int k = 0; k < sd.Index.Count; k++) s += sd.Coef[k] * u[j, sd.Index[k]]; }
        return s + u[n, Sym.Eos];
    }
}
