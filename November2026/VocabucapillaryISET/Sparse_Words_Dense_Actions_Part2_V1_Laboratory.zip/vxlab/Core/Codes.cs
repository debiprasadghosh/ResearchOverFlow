namespace VxLab.Core;

/// <summary>Primitive symbols: 26 letters, a padding symbol for unused slots and an end-of-word symbol.</summary>
public static class Sym
{
    public const int Pad = 26, Eos = 27, Count = 28, L = 16;
    public static int Of(char c) => c - 'a';

    /// <summary>Left-aligned slots: letters from slot 0, padding after the word.</summary>
    public static IReadOnlyList<int> Left(string w) => Enumerable.Range(0, L).Select(j => j < w.Length ? Of(w[j]) : Pad).ToArray();

    /// <summary>Right-aligned slots: padding first, the last letter in slot L-1.</summary>
    public static IReadOnlyList<int> Right(string w) => Enumerable.Range(0, L).Select(j => j >= L - w.Length ? Of(w[j - (L - w.Length)]) : Pad).ToArray();
}

/// <summary>Seeded unit vectors for the primitive symbols, or orthonormal (one-hot) vectors when the width allows.</summary>
public sealed record CharCode(int Width, bool Orthonormal, IReadOnlyList<IReadOnlyList<double>> Vectors)
{
    public static CharCode Random(int width, Rng rng)
    {
        var r = rng;
        var vecs = new IReadOnlyList<double>[Sym.Count];
        for (int s = 0; s < Sym.Count; s++)
        {
            var (g, nr) = Lin.Gaussians(r, width); r = nr;
            double n = Math.Sqrt(Lin.Norm2(g));
            vecs[s] = g.Select(x => x / n).ToArray();
        }
        return new CharCode(width, false, vecs);
    }

    public static CharCode OneHot(int width) => width < Sym.Count
        ? throw new ArgumentException("width below alphabet size")
        : new CharCode(width, true, Enumerable.Range(0, Sym.Count).Select(s => (IReadOnlyList<double>)Enumerable.Range(0, width).Select(i => i == s ? 1.0 : 0.0).ToArray()).ToArray());
}

/// <summary>Exactly orthogonal slot operators R_j: a random permutation with random signs per slot.</summary>
public sealed record Binder(int Width, IReadOnlyList<IReadOnlyList<int>> Perm, IReadOnlyList<IReadOnlyList<double>> Sign)
{
    public static Binder Create(int width, int slots, Rng rng)
    {
        var r = rng;
        var perms = new IReadOnlyList<int>[slots];
        var signs = new IReadOnlyList<double>[slots];
        for (int j = 0; j < slots; j++)
        {
            var p = Enumerable.Range(0, width).ToArray();
            for (int i = width - 1; i > 0; i--) { var (k, nr) = r.NextInt(i + 1); r = nr; (p[i], p[k]) = (p[k], p[i]); }
            var (s, nr2) = Lin.Signs(r, width); r = nr2;
            perms[j] = p; signs[j] = s;
        }
        return new Binder(width, perms, signs);
    }

    public double[] Apply(int slot, IReadOnlyList<double> x)
    {
        var y = new double[Width];
        var p = Perm[slot]; var s = Sign[slot];
        for (int i = 0; i < Width; i++) y[p[i]] = s[i] * x[i];
        return y;
    }

    public double[] Inverse(int slot, IReadOnlyList<double> y)
    {
        var x = new double[Width];
        var p = Perm[slot]; var s = Sign[slot];
        for (int i = 0; i < Width; i++) x[i] = s[i] * y[p[i]];
        return x;
    }
}

/// <summary>Word-level cache layouts. Each maps a spelled word to the vector stored for it.</summary>
public static class Layout
{
    /// <summary>Pooled bag: the sum of the letter vectors (computed from counts, so anagrams give identical vectors).</summary>
    public static double[] Bag(string w, CharCode c)
    {
        var v = new double[c.Width];
        var counts = new int[26];
        foreach (char ch in w) counts[Sym.Of(ch)]++;
        for (int s = 0; s < 26; s++) if (counts[s] > 0) for (int i = 0; i < c.Width; i++) v[i] += counts[s] * c.Vectors[s][i];
        return v;
    }

    /// <summary>Pooled with position binding: Σ_j R_j e(c_j) + R_n e(EOS), one vector of the code width.</summary>
    public static double[] Bound(string w, CharCode c, Binder b)
    {
        var v = new double[c.Width];
        for (int j = 0; j <= w.Length && j <= Sym.L; j++)
        {
            int s = j < w.Length ? Sym.Of(w[j]) : Sym.Eos;
            var y = b.Apply(j, c.Vectors[s]);
            for (int i = 0; i < c.Width; i++) v[i] += y[i];
        }
        return v;
    }

    /// <summary>Slot blocks: the width split into L blocks, block j holding the (narrow) vector of slot j.</summary>
    public static double[] Blocks(string w, CharCode blockCode) => Slots(Sym.Left(w), blockCode);

    /// <summary>Concatenation: L full-width slot vectors (L times the memory of one vector).</summary>
    public static double[] Concat(string w, CharCode c) => Slots(Sym.Left(w), c);

    private static double[] Slots(IReadOnlyList<int> sym, CharCode c)
    {
        var v = new double[Sym.L * c.Width];
        for (int j = 0; j < Sym.L; j++) for (int i = 0; i < c.Width; i++) v[j * c.Width + i] = c.Vectors[sym[j]][i];
        return v;
    }

    /// <summary>Adds isotropic Gaussian noise of total energy sigma² per stored symbol.</summary>
    public static (double[] Value, Rng Next) Noisy(IReadOnlyList<double> v, double sigma, int symbols, Rng rng)
    {
        var (g, next) = Lin.Gaussians(rng, v.Count);
        double scale = sigma * Math.Sqrt(symbols / (double)v.Count);
        return (v.Select((x, i) => x + scale * g[i]).ToArray(), next);
    }

    public static int SymbolsStored(string layout, string w) => layout switch
    {
        "bag" => w.Length,
        "bound" => Math.Min(w.Length + 1, Sym.L + 1),
        _ => Sym.L,
    };

    /// <summary>Per-slot nearest-symbol decoding of a slot layout; returns the decoded left-aligned slots.</summary>
    public static IReadOnlyList<int> DecodeSlots(IReadOnlyList<double> v, CharCode c)
    {
        var outp = new int[Sym.L];
        for (int j = 0; j < Sym.L; j++)
        {
            int best = 0; double bv = double.NegativeInfinity;
            for (int s = 0; s < Sym.Eos; s++)                                 // letters and padding
            {
                double d = 0;
                for (int i = 0; i < c.Width; i++) d += c.Vectors[s][i] * v[j * c.Width + i];
                if (d > bv) { bv = d; best = s; }
            }
            outp[j] = best;
        }
        return outp;
    }

    /// <summary>Unbinds a bound vector slot by slot with successive cancellation until it reads EOS.</summary>
    public static string DecodeBound(IReadOnlyList<double> v, CharCode c, Binder b)
    {
        var r = v.ToArray();
        var chars = new List<char>();
        for (int j = 0; j <= Sym.L; j++)
        {
            var u = b.Inverse(j, r);
            int best = 0; double bv = double.NegativeInfinity;
            for (int s = 0; s < Sym.Count; s++)
            {
                if (s == Sym.Pad) continue;
                double d = Lin.Dot(u, c.Vectors[s]);
                if (d > bv) { bv = d; best = s; }
            }
            if (best == Sym.Eos) break;
            chars.Add((char)('a' + best));
            var y = b.Apply(j, c.Vectors[best]);
            for (int i = 0; i < r.Length; i++) r[i] -= y[i];
        }
        return new string(chars.ToArray());
    }

    public static string FromSlots(IReadOnlyList<int> slots) => new(slots.TakeWhile(s => s < 26).Select(s => (char)('a' + s)).ToArray());
}
