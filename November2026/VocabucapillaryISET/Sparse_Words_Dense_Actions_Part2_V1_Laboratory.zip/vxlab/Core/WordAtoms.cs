namespace VxLab.Core;

/// <summary>A sparse positive dictionary over the 28 fixed primitives (letters, PAD, EOS); coefficients sum to one.</summary>
public sealed record SlotDict(IReadOnlyList<int> Index, IReadOnlyList<double> Coef)
{
    public static SlotDict One(int p) => new(new[] { p }, new[] { 1.0 });

    /// <summary>The primitive with the largest coefficient (lowest index on ties).</summary>
    public int Argmax
    {
        get
        {
            int best = 0;
            for (int k = 1; k < Index.Count; k++)
                if (Coef[k] > Coef[best] || (Coef[k] == Coef[best] && Index[k] < Index[best])) best = k;
            return Index[best];
        }
    }

    public double Of(int p) { for (int k = 0; k < Index.Count; k++) if (Index[k] == p) return Coef[k]; return 0; }
}

/// <summary>
/// A word atom of the dynamic vocabulary: its spelling S(w) = (D₁, …, D₁₆), one sparse slot dictionary per slot in the
/// left layout (letters, then PAD). Exact words have one-hot slots; observed words may keep several candidates.
/// </summary>
public sealed record WordAtom(string Text, IReadOnlyList<SlotDict> Slots)
{
    public static WordAtom Exact(string w) => new(w, Sym.Left(w).Select(SlotDict.One).ToArray());

    /// <summary>Reading the spelling: the most likely primitive of every slot, up to the first PAD.</summary>
    public string Spelling => Layout.FromSlots(Slots.Select(s => s.Argmax).ToArray());

    public int Entries => Slots.Sum(s => s.Index.Count);
}

/// <summary>A cache record of a word token: a sparse positive code over word atoms (indices into an inventory).</summary>
public sealed record Code(IReadOnlyList<int> Atom, IReadOnlyList<double> Coef)
{
    public static Code One(int a) => new(new[] { a }, new[] { 1.0 });
    public int Support => Atom.Count;
}

/// <summary>
/// Scoring word atoms and records through tables over the fixed primitives. For a concatenated query (16 slot vectors)
/// the primitive table U[j, p] = q_j · e(p) costs 16 × 28 × d multiply-adds once per query; every atom is then scored by
/// Σ_j Σ_p D_jp(a) U[j, p], and every record by Σ_a c_a score(a). The decoded key of an atom is Σ_p D_jp(a) e(p) per slot.
/// </summary>
public static class Atoms
{
    public const int Slots = Sym.L, Primitives = Sym.Count;

    public static double[] Concat(WordAtom a, CharCode e)
    {
        int d = e.Width;
        var v = new double[Slots * d];
        for (int j = 0; j < Slots; j++)
        {
            var s = a.Slots[j];
            for (int k = 0; k < s.Index.Count; k++)
            {
                var ep = e.Vectors[s.Index[k]]; double c = s.Coef[k];
                for (int i = 0; i < d; i++) v[j * d + i] += c * ep[i];
            }
        }
        return v;
    }

    /// <summary>Pooled bound key of an atom: Σ_j R_j (Σ_p D_jp e(p)) over the letter slots and R_n e(EOS), n = word length.</summary>
    public static double[] Bound(WordAtom a, CharCode e, Binder b)
    {
        int d = e.Width, n = Math.Min(a.Text.Length, Sym.L);
        var v = new double[d];
        for (int j = 0; j < n; j++)
        {
            var s = a.Slots[j];
            var mix = new double[d];
            for (int k = 0; k < s.Index.Count; k++) { var ep = e.Vectors[s.Index[k]]; double c = s.Coef[k]; for (int i = 0; i < d; i++) mix[i] += c * ep[i]; }
            var y = b.Apply(j, mix);
            for (int i = 0; i < d; i++) v[i] += y[i];
        }
        if (n < Sym.L + 1) { var y = b.Apply(n, e.Vectors[Sym.Eos]); for (int i = 0; i < d; i++) v[i] += y[i]; }
        return v;
    }

    public static double[,] Table(IReadOnlyList<double> qConcat, CharCode e)
    {
        int d = e.Width;
        var u = new double[Slots, Primitives];
        for (int j = 0; j < Slots; j++)
            for (int p = 0; p < Primitives; p++)
            {
                var ep = e.Vectors[p]; double s = 0;
                for (int i = 0; i < d; i++) s += qConcat[j * d + i] * ep[i];
                u[j, p] = s;
            }
        return u;
    }

    public static double Score(double[,] u, WordAtom a)
    {
        double s = 0;
        for (int j = 0; j < Slots; j++) { var sd = a.Slots[j]; for (int k = 0; k < sd.Index.Count; k++) s += sd.Coef[k] * u[j, sd.Index[k]]; }
        return s;
    }

    /// <summary>Gram matrix Γ = EᵀE of the primitive atoms (28 × 28).</summary>
    public static double[,] Gram(CharCode e)
    {
        var g = new double[Primitives, Primitives];
        for (int p = 0; p < Primitives; p++) for (int r = 0; r < Primitives; r++) g[p, r] = Lin.Dot(e.Vectors[p], e.Vectors[r]);
        return g;
    }

    /// <summary>Inner product of two decoded concatenated atom keys through Γ: Σ_j D_j(a)ᵀ Γ D_j(b).</summary>
    public static double Inner(WordAtom a, WordAtom b, double[,] g)
    {
        double s = 0;
        for (int j = 0; j < Slots; j++)
        {
            var x = a.Slots[j]; var y = b.Slots[j];
            for (int k = 0; k < x.Index.Count; k++) for (int l = 0; l < y.Index.Count; l++) s += x.Coef[k] * y.Coef[l] * g[x.Index[k], y.Index[l]];
        }
        return s;
    }

    /// <summary>The fraction of letter slots that agree when two spellings are aligned at the start or at the end (the larger).</summary>
    public static double SpellingSimilarity(string a, string b)
    {
        int n = Math.Max(a.Length, b.Length), m = Math.Min(a.Length, b.Length);
        int left = 0, right = 0;
        for (int i = 0; i < m; i++) { if (a[i] == b[i]) left++; if (a[a.Length - 1 - i] == b[b.Length - 1 - i]) right++; }
        return Math.Max(left, right) / (double)n;
    }
}
