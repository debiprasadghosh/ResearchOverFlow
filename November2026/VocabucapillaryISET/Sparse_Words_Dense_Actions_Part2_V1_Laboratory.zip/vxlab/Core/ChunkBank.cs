namespace VxLab.Core;

/// <summary>
/// The dense ISET side of the hybrid, as in Part 1: 64 skills, 8-step chunks, a learned linear ISET (principal
/// components of 4,096 training executions) whose BF16 codes padded to width 128 are the chunk keys, per-step slots for
/// the typed rerank (computed from the chunk's raw motor characters), and mixed histories of chunk indices.
/// </summary>
public sealed record ChunkBank(int L, IReadOnlyList<Motor.Skill> Lib, IReadOnlyList<Motor.Chunk> Chunks, IReadOnlyList<IReadOnlyList<double>> Keys, LinearIset Pca, StepSlots Slots, int PerSkill)
{
    public const int Skills = 64, TrainPerSkill = 64, NearDup = 8;

    public static ChunkBank Make(int L, int perSkill, int width, ulong seed)
    {
        var lib = Motor.Library(Skills, seed);
        var train = Enumerable.Range(0, Skills * TrainPerSkill).AsParallel().AsOrdered()
            .Select(i => Motor.Execute(lib[i / TrainPerSkill], L, Rng.Derive(seed, 1_000_000_000UL + (ulong)(L * 100_000 + i))).Value).ToArray();
        var pca = LinearIset.Fit(train.Select(c => c.X).ToArray(), Math.Min(width, Motor.Dof * L));
        var chunks = Enumerable.Range(0, Skills * perSkill).AsParallel().AsOrdered()
            .Select(i => Motor.Execute(lib[i / perSkill], L, Rng.Derive(seed, 3_000_000_000UL + (ulong)i)).Value).ToArray();
        var keys = chunks.AsParallel().AsOrdered().Select(c => Bf16.Round(Mat.Pad(pca.Encode(c.X), width))).ToArray();
        return new ChunkBank(L, lib, chunks, keys, pca, StepSlots.Create(width, Rng.Derive(seed, 21)), perSkill);
    }

    public IReadOnlyList<double> StepSlotKey(Motor.Chunk c) => Bf16.Round(Slots.Encode(Motor.Characters(c.X, L).Symbols, L));

    /// <summary>History of chunk indices: the target, eight other executions of its skill, the rest from other skills.</summary>
    public IReadOnlyList<int> History(int count, Rng rng)
    {
        int n = Chunks.Count;
        var (target, r) = rng.NextInt(n);
        int skill = Chunks[target].Skill;
        var hist = new List<int> { target };
        var used = new HashSet<int> { target };
        while (hist.Count < 1 + NearDup)
        {
            var (k, nr) = r.NextInt(PerSkill); r = nr;
            int idx = skill * PerSkill + k;
            if (used.Add(idx)) hist.Add(idx);
        }
        while (hist.Count < count)
        {
            var (k, nr) = r.NextInt(n); r = nr;
            if (Chunks[k].Skill == skill || !used.Add(k)) continue;
            hist.Add(k);
        }
        return hist;
    }
}
