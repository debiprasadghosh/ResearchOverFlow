namespace VxLab.Core;

/// <summary>
/// Immutable SplitMix64 generator. Every draw returns the sampled value together with the
/// successor generator, so no hidden state is mutated. The Python cross-check ports it line for line.
/// </summary>
public readonly record struct Rng(ulong State)
{
    private const ulong Gamma = 0x9E3779B97F4A7C15UL;

    /// <summary>Independent stream for a named experiment (seed, stream id).</summary>
    public static Rng Derive(ulong seed, ulong stream)
    {
        unchecked
        {
            var start = new Rng(seed ^ (stream * 0xD1B54A32D192ED03UL));
            return start.NextUInt64().Next;
        }
    }

    public (ulong Value, Rng Next) NextUInt64()
    {
        unchecked
        {
            ulong s = State + Gamma;
            ulong z = s;
            z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
            z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
            z ^= z >> 31;
            return (z, new Rng(s));
        }
    }

    /// <summary>Uniform double in [0,1) with 53 random bits.</summary>
    public (double Value, Rng Next) NextDouble()
    {
        var (u, next) = NextUInt64();
        return ((u >> 11) * (1.0 / 9007199254740992.0), next);
    }

    public (int Value, Rng Next) NextInt(int maxExclusive)
    {
        var (d, next) = NextDouble();
        int v = (int)(d * maxExclusive);
        return (v >= maxExclusive ? maxExclusive - 1 : v, next);
    }

    public (double Value, Rng Next) NextUniform(double lo, double hi)
    {
        var (d, next) = NextDouble();
        return (lo + (hi - lo) * d, next);
    }

    /// <summary>Box-Muller (cosine branch only, two uniforms per draw).</summary>
    public (double Value, Rng Next) NextGaussian()
    {
        var (u1, r1) = NextDouble();
        var (u2, r2) = r1.NextDouble();
        double radius = Math.Sqrt(-2.0 * Math.Log(1.0 - u1));
        return (radius * Math.Cos(2.0 * Math.PI * u2), r2);
    }

    public (bool Value, Rng Next) NextBernoulli(double p)
    {
        var (d, next) = NextDouble();
        return (d < p, next);
    }

    public (int Value, Rng Next) NextCategorical(IReadOnlyList<double> weights)
    {
        double total = 0.0;
        for (int i = 0; i < weights.Count; i++) total += weights[i];
        var (d, next) = NextDouble();
        double target = d * total, acc = 0.0;
        for (int i = 0; i < weights.Count; i++)
        {
            acc += weights[i];
            if (target < acc) return (i, next);
        }
        return (weights.Count - 1, next);
    }

    /// <summary>Uniform choice of an integer in [0,n) different from 'exclude'.</summary>
    public (int Value, Rng Next) NextIntExcept(int n, int exclude)
    {
        var (v, next) = NextInt(n - 1);
        return (v >= exclude ? v + 1 : v, next);
    }

    /// <summary>Gamma(shape,1) for shape &gt; 0 via Marsaglia-Tsang; used for Dirichlet draws.</summary>
    public (double Value, Rng Next) NextGamma(double shape)
    {
        if (shape < 1.0)
        {
            var (g, r1) = NextGamma(shape + 1.0);
            var (u, r2) = r1.NextDouble();
            return (g * Math.Pow(1.0 - u, 1.0 / shape), r2);
        }
        double d = shape - 1.0 / 3.0, c = 1.0 / Math.Sqrt(9.0 * d);
        var rng = this;
        while (true)
        {
            var (x, r1) = rng.NextGaussian();
            double v = 1.0 + c * x;
            if (v <= 0) { rng = r1; continue; }
            v = v * v * v;
            var (u, r2) = r1.NextDouble();
            rng = r2;
            if (Math.Log(1.0 - u) < 0.5 * x * x + d - d * v + d * Math.Log(v)) return (d * v, rng);
        }
    }

    public (IReadOnlyList<double> Value, Rng Next) NextDirichlet(int k, double alpha)
    {
        var g = new double[k];
        var rng = this;
        double sum = 0;
        for (int i = 0; i < k; i++) { (g[i], rng) = rng.NextGamma(alpha); sum += g[i]; }
        for (int i = 0; i < k; i++) g[i] /= sum;
        return (g, rng);
    }
}
