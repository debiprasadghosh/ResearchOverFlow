namespace VxLab.Core;

/// <summary>
/// A counted association atom for a mixed tuple: sparse word codes for its roles (here one atom index per role), the
/// running mean of the dense ISET action codes assigned to it, their running sum of squared deviations (Welford) and
/// the count.
/// </summary>
public sealed record ProductAtom(IReadOnlyList<int> Words, IReadOnlyList<double> Mean, IReadOnlyList<double> M2, int Count)
{
    public static ProductAtom Start(IReadOnlyList<int> words, IReadOnlyList<double> z) => new(words, z.ToArray(), new double[z.Count], 1);

    public ProductAtom Absorb(IReadOnlyList<double> z)
    {
        int n = Count + 1;
        var mean = new double[z.Count]; var m2 = new double[z.Count];
        for (int i = 0; i < z.Count; i++)
        {
            double delta = z[i] - Mean[i];
            mean[i] = Mean[i] + delta / n;
            m2[i] = M2[i] + delta * (z[i] - mean[i]);
        }
        return new ProductAtom(Words, mean, m2, n);
    }

    public IReadOnlyList<double> Variance => M2.Select(x => Count > 1 ? x / (Count - 1) : 0.0).ToArray();
}

/// <summary>
/// One-pass leader clustering, the online form of DP-means: a point joins the nearest centre within the threshold θ
/// (Euclidean) and moves it as a running mean; otherwise it starts a new centre. Product atoms run it separately inside
/// each tuple of word atoms, so different words never share an atom.
/// </summary>
public static class Leader
{
    public sealed record Result(IReadOnlyList<IReadOnlyList<double>> Centres, IReadOnlyList<int> Counts, IReadOnlyList<int> Assign);

    public static Result Cluster(IReadOnlyList<IReadOnlyList<double>> points, double theta)
    {
        var centres = new List<double[]>(); var counts = new List<int>(); var assign = new int[points.Count];
        double t2 = theta * theta;
        for (int i = 0; i < points.Count; i++)
        {
            var x = points[i];
            int best = -1; double bd = double.PositiveInfinity;
            for (int c = 0; c < centres.Count; c++)
            {
                double d2 = 0; var m = centres[c];
                for (int k = 0; k < x.Count; k++) { double e = x[k] - m[k]; d2 += e * e; }
                if (d2 < bd) { bd = d2; best = c; }
            }
            if (best >= 0 && bd <= t2)
            {
                int n = ++counts[best]; var m = centres[best];
                for (int k = 0; k < x.Count; k++) m[k] += (x[k] - m[k]) / n;
                assign[i] = best;
            }
            else { centres.Add(x.ToArray()); counts.Add(1); assign[i] = centres.Count - 1; }
        }
        return new Result(centres.Select(c => (IReadOnlyList<double>)c.ToArray()).ToArray(), counts.ToArray(), assign);
    }

    /// <summary>Product atoms from tuples (word atoms, action code), in the order given.</summary>
    public static IReadOnlyList<ProductAtom> Train(IReadOnlyList<(IReadOnlyList<int> Words, IReadOnlyList<double> Z)> tuples, double theta)
    {
        var atoms = new List<ProductAtom>();
        var byKey = new Dictionary<string, List<int>>();
        double t2 = theta * theta;
        foreach (var (words, z) in tuples)
        {
            string key = string.Join(",", words);
            if (!byKey.TryGetValue(key, out var ids)) { ids = new List<int>(); byKey[key] = ids; }
            int best = -1; double bd = double.PositiveInfinity;
            foreach (int a in ids)
            {
                double d2 = 0; var m = atoms[a].Mean;
                for (int k = 0; k < z.Count; k++) { double e = z[k] - m[k]; d2 += e * e; }
                if (d2 < bd) { bd = d2; best = a; }
            }
            if (best >= 0 && bd <= t2) atoms[best] = atoms[best].Absorb(z);
            else { atoms.Add(ProductAtom.Start(words, z)); ids.Add(atoms.Count - 1); }
        }
        return atoms.ToArray();
    }
}
