namespace VxLab.Core;

/// <summary>
/// Synthetic body stream: a library of smooth motor skills for seven joints, executions with amplitude jitter, sensor
/// noise and contact transients, and closed-loop delta motor characters (16 symbols, step 0.04 rad) as in the
/// cerebellum paper of the series. A chunk is L control steps of all joints, stored joint-major as X[j·L + t].
/// </summary>
public static class Motor
{
    public const int Dof = 7, Freqs = 4, Period = 32, Alphabet = 16, Offset = 7;
    public const double Step = 0.04, AmpSd = 0.3, Jitter = 0.1, Noise = 0.005, ContactRate = 1.0 / 32, ContactSize = 0.08;

    public sealed record Skill(int Id, IReadOnlyList<double> Amp, IReadOnlyList<double> Phase);
    public sealed record Chunk(int Skill, int Length, IReadOnlyList<double> X, int Contacts);
    public sealed record Chars(IReadOnlyList<int> Symbols, IReadOnlyList<double> Recon);

    /// <summary>Skill id: for each joint and frequency f = 1..4 an amplitude N(0, 0.3²) and a phase U(0, 2π).</summary>
    public static Skill MakeSkill(int id, ulong seed)
    {
        var r = Rng.Derive(seed, 10_000 + (ulong)id);
        var amp = new double[Dof * Freqs];
        var ph = new double[Dof * Freqs];
        for (int i = 0; i < Dof * Freqs; i++)
        {
            var (g, r1) = r.NextGaussian();
            var (p, r2) = r1.NextUniform(0, 2 * Math.PI);
            r = r2; amp[i] = AmpSd * g; ph[i] = p;
        }
        return new Skill(id, amp, ph);
    }

    public static IReadOnlyList<Skill> Library(int count, ulong seed) => Enumerable.Range(0, count).Select(k => MakeSkill(k, seed)).ToArray();

    /// <summary>x_j(t) = Σ_f (a_jf / f)(sin(2π f t / 32 + φ_jf) − sin φ_jf): smooth, zero at the chunk start.</summary>
    public static IReadOnlyList<double> Prototype(Skill s, int L)
    {
        var x = new double[Dof * L];
        for (int j = 0; j < Dof; j++)
            for (int t = 0; t < L; t++)
            {
                double v = 0;
                for (int f = 1; f <= Freqs; f++)
                {
                    double a = s.Amp[j * Freqs + f - 1], p = s.Phase[j * Freqs + f - 1];
                    v += a / f * (Math.Sin(2 * Math.PI * f * t / Period + p) - Math.Sin(p));
                }
                x[j * L + t] = v;
            }
        return x;
    }

    /// <summary>
    /// One execution: the prototype scaled by 1 + 0.1·N(0,1), sensor noise 0.005·N(0,1) per value, and contact events
    /// (probability 1/32 per step) that add to every joint a transient of size 0.08·N(0,1) held two steps then decaying
    /// with time constant 4 steps. Draw order: amplitude, noise (joint-major), then per step a uniform and, on contact,
    /// one Gaussian per joint.
    /// </summary>
    public static (Chunk Value, Rng Next) Execute(Skill s, int L, Rng rng) => Execute(s.Id, Prototype(s, L), L, rng);

    public static (Chunk Value, Rng Next) Execute(int skillId, IReadOnlyList<double> proto, int L, Rng rng)
    {
        var (g, r) = rng.NextGaussian();
        double a = 1 + Jitter * g;
        var x = new double[Dof * L];
        for (int i = 0; i < x.Length; i++) { var (n, nr) = r.NextGaussian(); r = nr; x[i] = a * proto[i] + Noise * n; }
        int contacts = 0;
        for (int t = 0; t < L; t++)
        {
            var (u, r1) = r.NextDouble(); r = r1;
            if (u >= ContactRate) continue;
            contacts++;
            for (int j = 0; j < Dof; j++)
            {
                var (sz, r2) = r.NextGaussian(); r = r2;
                for (int tt = t; tt < L; tt++) x[j * L + tt] += ContactSize * sz * (tt - t < 2 ? 1.0 : Math.Exp(-(tt - t - 2) / 4.0));
            }
        }
        return (new Chunk(skillId, L, x, contacts), r);
    }

    /// <summary>Closed-loop delta characters per joint: c = clamp(round((x − x̂)/δ), −7, 8), x̂ += cδ; symbol = c + 7.</summary>
    public static Chars Characters(IReadOnlyList<double> x, int L)
    {
        var sym = new int[x.Count];
        var rec = new double[x.Count];
        for (int j = 0; j < Dof; j++)
        {
            double prev = 0;
            for (int t = 0; t < L; t++)
            {
                int c = (int)Math.Clamp(Math.Round((x[j * L + t] - prev) / Step), -Offset, Alphabet - 1 - Offset);
                prev += c * Step;
                sym[j * L + t] = c + Offset;
                rec[j * L + t] = prev;
            }
        }
        return new Chars(sym, rec);
    }

    /// <summary>Integrates decoded characters back into joint positions (errors persist for the rest of the chunk).</summary>
    public static IReadOnlyList<double> FromCharacters(IReadOnlyList<int> sym, int L)
    {
        var x = new double[sym.Count];
        for (int j = 0; j < Dof; j++)
        {
            double prev = 0;
            for (int t = 0; t < L; t++) { prev += (sym[j * L + t] - Offset) * Step; x[j * L + t] = prev; }
        }
        return x;
    }

    public static double Rms(IReadOnlyList<double> a, IReadOnlyList<double> b)
    {
        double s = 0;
        for (int i = 0; i < a.Count; i++) { double e = a[i] - b[i]; s += e * e; }
        return Math.Sqrt(s / a.Count);
    }
}

/// <summary>Round-to-nearest-even conversion to bfloat16 (8 exponent bits, 7 stored mantissa bits) and back.</summary>
public static class Bf16
{
    public static double Round(double x)
    {
        uint bits = BitConverter.SingleToUInt32Bits((float)x);
        uint lsb = (bits >> 16) & 1u;
        bits = unchecked(bits + 0x7FFFu + lsb) & 0xFFFF0000u;
        return BitConverter.UInt32BitsToSingle(bits);
    }

    public static IReadOnlyList<double> Round(IReadOnlyList<double> v) => v.Select(Round).ToArray();
}
