namespace VxLab.Core;

/// <summary>Corpus statistics of the full English word-frequency list, before the lexicon is cut to its top entries.</summary>
public sealed record LexiconStats(
    int AllTypes, double AllMass, int AlphaTypes, double AlphaMass, double AlphaUpTo16Mass,
    double MeanLettersAllAlpha, double KeptMassShareOfAlpha);

/// <summary>
/// An English lexicon from wordfreq's large English list (centibel buckets; bucket i has frequency 10^(-i/100)).
/// Only lowercase alphabetic words of 1 to 16 letters are kept, most frequent first.
/// </summary>
public sealed record Lexicon(
    IReadOnlyList<string> Words, IReadOnlyList<double> Freq, IReadOnlyList<double> Prob, IReadOnlyList<double> Cdf,
    IReadOnlyDictionary<string, int> Index, IReadOnlyDictionary<string, IReadOnlyList<int>> AnagramClasses, LexiconStats Stats)
{
    public const int MaxLen = 16;
    public static readonly IReadOnlyList<string> Prefixes = new[] { "re", "un", "dis", "pre", "mis", "over", "out", "sub", "inter", "non" };
    public static readonly IReadOnlyList<string> Suffixes = new[] { "s", "es", "ed", "d", "ing", "er", "ers", "est", "ly", "ness", "ment", "able", "ful", "less" };

    public static bool IsAlpha(string w) => w.Length > 0 && w.All(c => c >= 'a' && c <= 'z');

    public static string SortedKey(string w) { var a = w.ToCharArray(); Array.Sort(a); return new string(a); }

    public static Lexicon Load(string path, int maxWords)
    {
        var root = (object?[])MsgPack.ReadGzip(path)!;
        var header = (Dictionary<string, object?>)root[0]!;
        if ((string?)header["format"] != "cB") throw new InvalidDataException("Not a cBpack file");
        var all = new List<(string Word, double Freq)>();
        for (int i = 1; i < root.Length; i++)
        {
            double f = Math.Pow(10.0, -(i - 1) / 100.0);
            foreach (var o in (object?[])root[i]!) all.Add(((string)o!, f));
        }
        double allMass = all.Sum(x => x.Freq);
        var alpha = all.Where(x => IsAlpha(x.Word)).ToArray();
        var alpha16 = alpha.Where(x => x.Word.Length <= MaxLen).ToArray();
        double alphaMass = alpha.Sum(x => x.Freq), alpha16Mass = alpha16.Sum(x => x.Freq);
        double meanLetters = alpha16.Sum(x => x.Freq * x.Word.Length) / alpha16Mass;
        var kept = alpha16.Take(maxWords).ToArray();                       // buckets are already in descending frequency
        double keptMass = kept.Sum(x => x.Freq);
        var prob = kept.Select(x => x.Freq / keptMass).ToArray();
        var cdf = new double[prob.Length];
        double acc = 0;
        for (int i = 0; i < prob.Length; i++) { acc += prob[i]; cdf[i] = acc; }
        var words = kept.Select(x => x.Word).ToArray();
        var index = words.Select((w, i) => (w, i)).ToDictionary(x => x.w, x => x.i);
        var anagrams = words.Select((w, i) => (key: SortedKey(w), i)).GroupBy(x => x.key)
            .ToDictionary(g => g.Key, g => (IReadOnlyList<int>)g.Select(x => x.i).ToArray());
        var stats = new LexiconStats(all.Count, allMass, alpha.Length, alphaMass, alpha16Mass, meanLetters, keptMass / alpha16Mass);
        return new Lexicon(words, kept.Select(x => x.Freq).ToArray(), prob, cdf, index, anagrams, stats);
    }

    public bool Contains(string w) => Index.ContainsKey(w);

    /// <summary>Draws a word index with probability proportional to its corpus frequency.</summary>
    public (int Word, Rng Next) Sample(Rng rng)
    {
        var (u, next) = rng.NextDouble();
        double target = u * Cdf[^1];
        int lo = 0, hi = Cdf.Count - 1;
        while (lo < hi) { int mid = (lo + hi) / 2; if (Cdf[mid] > target) hi = mid; else lo = mid + 1; }
        return (lo, next);
    }

    public IReadOnlyList<string> AnagramsOf(string w) =>
        AnagramClasses.TryGetValue(SortedKey(w), out var ids) ? ids.Select(i => Words[i]).Where(x => x != w).ToArray() : Array.Empty<string>();

    /// <summary>Lexicon words one substitution, deletion, insertion or adjacent transposition away, most frequent first.</summary>
    public IReadOnlyList<string> OneEdit(string w)
    {
        var found = new HashSet<string>();
        for (int i = 0; i < w.Length; i++)
        {
            Try(w.Remove(i, 1));
            for (char c = 'a'; c <= 'z'; c++) if (c != w[i]) Try(w[..i] + c + w[(i + 1)..]);
            if (i + 1 < w.Length && w[i] != w[i + 1]) Try(w[..i] + w[i + 1] + w[i] + w[(i + 2)..]);
        }
        for (int i = 0; i <= w.Length; i++) for (char c = 'a'; c <= 'z'; c++) Try(w[..i] + c + w[i..]);
        return found.OrderBy(x => Index[x]).ToArray();
        void Try(string s) { if (s.Length > 0 && s != w && Index.ContainsKey(s)) found.Add(s); }
    }

    /// <summary>Lexicon words that add or remove one listed prefix or suffix (plain concatenation).</summary>
    public IReadOnlyList<string> AffixRelatives(string w)
    {
        var found = new HashSet<string>();
        foreach (var s in Suffixes)
        {
            if (Contains(w + s)) found.Add(w + s);
            if (w.EndsWith(s) && w.Length - s.Length >= 3 && Contains(w[..^s.Length])) found.Add(w[..^s.Length]);
        }
        foreach (var p in Prefixes)
        {
            if (Contains(p + w)) found.Add(p + w);
            if (w.StartsWith(p) && w.Length - p.Length >= 3 && Contains(w[p.Length..])) found.Add(w[p.Length..]);
        }
        found.Remove(w);
        return found.Where(x => x.Length <= MaxLen).OrderBy(x => Index[x]).ToArray();
    }

    /// <summary>Near-duplicates of a word: anagrams, affix relatives and one-edit neighbours, in that order, capped.</summary>
    public IReadOnlyList<string> Neighbours(string w, int cap) =>
        AnagramsOf(w).Concat(AffixRelatives(w)).Concat(OneEdit(w)).Distinct().Where(x => x != w).Take(cap).ToArray();

    public (IReadOnlyList<string> Suffixed, IReadOnlyList<string> Prefixed) Family(string stem) =>
        (Suffixes.Select(s => stem + s).Where(Contains).Distinct().ToArray(),
         Prefixes.Select(p => p + stem).Where(x => x.Length <= MaxLen && Contains(x)).Distinct().ToArray());
}
