namespace VxLab.Core;

/// <summary>
/// An uncertain observation of a word: each letter is kept with probability 1 − ε or replaced by another member of its
/// confusion set, chosen uniformly. The lexicon posterior P(w | o) ∝ P(w) Π_j P(o_j | w_j) runs over the words that share
/// the observation's length and confusion pattern; the true word is always among them.
/// </summary>
public static class Channel
{
    public static readonly string[] Sets = { "aou", "bdp", "ces", "fhk", "gqy", "ijl", "mnr", "txz", "vw" };
    public static readonly IReadOnlyList<int> SetOf = Enumerable.Range(0, 26).Select(c => Array.FindIndex(Sets, s => s.Contains((char)('a' + c)))).ToArray();

    public static string Pattern(string w) => new(w.Select(ch => (char)('A' + SetOf[ch - 'a'])).ToArray());

    /// <summary>Draw order: per letter one uniform for the error and, on error, one integer for the replacement.</summary>
    public static (string Value, Rng Next) Observe(string w, double eps, Rng rng)
    {
        var o = w.ToCharArray();
        var r = rng;
        for (int j = 0; j < o.Length; j++)
        {
            var (u, r1) = r.NextDouble(); r = r1;
            if (u >= eps) continue;
            string set = Sets[SetOf[o[j] - 'a']];
            int self = set.IndexOf(o[j]);
            var (k, r2) = r.NextIntExcept(set.Length, self); r = r2;
            o[j] = set[k];
        }
        return (new string(o), r);
    }

    public static IReadOnlyDictionary<string, IReadOnlyList<int>> PatternIndex(Lexicon lex) =>
        lex.Words.Select((w, i) => (p: Pattern(w), i)).GroupBy(x => x.p).ToDictionary(g => g.Key, g => (IReadOnlyList<int>)g.Select(x => x.i).ToArray());

    public static double Likelihood(string obs, string w, double eps)
    {
        double l = 1;
        for (int j = 0; j < obs.Length; j++)
            l *= obs[j] == w[j] ? 1 - eps : eps / (Sets[SetOf[w[j] - 'a']].Length - 1);
        return l;
    }

    /// <summary>The posterior over lexicon words as a record, largest coefficient first (lower word index on ties).</summary>
    public static Code Posterior(string obs, double eps, Lexicon lex, IReadOnlyDictionary<string, IReadOnlyList<int>> index)
    {
        var cand = index[Pattern(obs)];
        var w = cand.Select(i => lex.Prob[i] * Likelihood(obs, lex.Words[i], eps)).ToArray();
        var order = Enumerable.Range(0, cand.Count).Where(i => w[i] > 0).OrderByDescending(i => w[i]).ThenBy(i => cand[i]).ToArray();
        return Rec.FromWeights(order.Select(i => cand[i]).ToArray(), order.Select(i => w[i]).ToArray());
    }

    /// <summary>One dynamic word atom holding the slot marginals Σ_w P(w | o)[w_j = p] of a posterior; padding after the word.</summary>
    public static WordAtom SlotMarginals(Code post, string obs, Lexicon lex)
    {
        var slots = new SlotDict[Sym.L];
        for (int j = 0; j < Sym.L; j++)
        {
            if (j >= obs.Length) { slots[j] = SlotDict.One(Sym.Pad); continue; }
            var m = new SortedDictionary<int, double>();
            for (int i = 0; i < post.Support; i++) { int p = Sym.Of(lex.Words[post.Atom[i]][j]); m[p] = m.GetValueOrDefault(p) + post.Coef[i]; }
            slots[j] = new SlotDict(m.Keys.ToArray(), m.Values.ToArray());
        }
        return new WordAtom(obs, slots);
    }
}
