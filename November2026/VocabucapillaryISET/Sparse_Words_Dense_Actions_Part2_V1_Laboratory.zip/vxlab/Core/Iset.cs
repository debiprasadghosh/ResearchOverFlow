namespace VxLab.Core;

/// <summary>
/// Chunk encoders that turn an action chunk into dense cache vectors of width d.
/// BoundChunk: training-free and invertible (the analytic ISET stand-in of the series), Σ R_(t·7+j) e(c_jt) in one vector.
/// StepSlots: one bound vector per control step (L vectors), the analogue of concatenated word slots.
/// LinearIset: learned linear encoder (principal components of training chunks), r coefficients padded to width d.
/// DctIset: training-free linear encoder keeping the lowest k DCT-II coefficients of every joint.
/// </summary>
public sealed record BoundChunk(int Width, CharCode Symbols, Binder Bind, IReadOnlyList<IReadOnlyList<IReadOnlyList<double>>> Table)
{
    /// <summary>Seeded symbol vectors and slot operators; Table[slot][symbol] = R_slot e(symbol) is precomputed.</summary>
    public static BoundChunk Create(int width, int maxSteps, Rng rng)
    {
        var symbols = CharCode.Random(width, Rng.Derive(rng.State, 1));
        var bind = Binder.Create(width, maxSteps * Motor.Dof, Rng.Derive(rng.State, 2));
        var table = Enumerable.Range(0, maxSteps * Motor.Dof).Select(slot => (IReadOnlyList<IReadOnlyList<double>>)Enumerable.Range(0, Motor.Alphabet)
            .Select(s => (IReadOnlyList<double>)bind.Apply(slot, symbols.Vectors[s])).ToArray()).ToArray();
        return new BoundChunk(width, symbols, bind, table);
    }

    public static int Slot(int j, int t) => t * Motor.Dof + j;

    public IReadOnlyList<double> Encode(IReadOnlyList<int> sym, int L)
    {
        var v = new double[Width];
        for (int t = 0; t < L; t++)
            for (int j = 0; j < Motor.Dof; j++)
            {
                var y = Table[Slot(j, t)][sym[j * L + t]];
                for (int i = 0; i < Width; i++) v[i] += y[i];
            }
        return v;
    }

    /// <summary>
    /// Unbinding slot by slot (time-major): the symbol score e(s)·R⁻¹r equals (R e(s))·r. With successive cancellation
    /// the chosen symbol's bound vector is subtracted before the next slot is read.
    /// </summary>
    public IReadOnlyList<int> Decode(IReadOnlyList<double> code, int L, bool cancel = true)
    {
        var r = code.ToArray();
        var sym = new int[Motor.Dof * L];
        for (int t = 0; t < L; t++)
            for (int j = 0; j < Motor.Dof; j++)
            {
                var row = Table[Slot(j, t)];
                int best = 0; double bv = double.NegativeInfinity;
                for (int s = 0; s < Motor.Alphabet; s++) { double d = Lin.Dot(row[s], r); if (d > bv) { bv = d; best = s; } }
                sym[j * L + t] = best;
                if (!cancel) continue;
                var y = row[best];
                for (int i = 0; i < Width; i++) r[i] -= y[i];
            }
        return sym;
    }
}

public sealed record StepSlots(int Width, CharCode Symbols, Binder Bind, IReadOnlyList<IReadOnlyList<IReadOnlyList<double>>> Table)
{
    public static StepSlots Create(int width, Rng rng)
    {
        var symbols = CharCode.Random(width, Rng.Derive(rng.State, 1));
        var bind = Binder.Create(width, Motor.Dof, Rng.Derive(rng.State, 2));
        var table = Enumerable.Range(0, Motor.Dof).Select(j => (IReadOnlyList<IReadOnlyList<double>>)Enumerable.Range(0, Motor.Alphabet)
            .Select(s => (IReadOnlyList<double>)bind.Apply(j, symbols.Vectors[s])).ToArray()).ToArray();
        return new StepSlots(width, symbols, bind, table);
    }

    /// <summary>L vectors of width d laid end to end: step t holds Σ_j R_j e(c_jt).</summary>
    public IReadOnlyList<double> Encode(IReadOnlyList<int> sym, int L)
    {
        var v = new double[L * Width];
        for (int t = 0; t < L; t++)
            for (int j = 0; j < Motor.Dof; j++)
            {
                var y = Table[j][sym[j * L + t]];
                for (int i = 0; i < Width; i++) v[t * Width + i] += y[i];
            }
        return v;
    }

    public IReadOnlyList<int> Decode(IReadOnlyList<double> code, int L)
    {
        var sym = new int[Motor.Dof * L];
        for (int t = 0; t < L; t++)
        {
            var r = code.Skip(t * Width).Take(Width).ToArray();
            for (int j = 0; j < Motor.Dof; j++)
            {
                var row = Table[j];
                int best = 0; double bv = double.NegativeInfinity;
                for (int s = 0; s < Motor.Alphabet; s++) { double d = Lin.Dot(row[s], r); if (d > bv) { bv = d; best = s; } }
                sym[j * L + t] = best;
                var y = row[best];
                for (int i = 0; i < Width; i++) r[i] -= y[i];
            }
        }
        return sym;
    }
}

public sealed record LinearIset(int Dim, IReadOnlyList<double> Mean, IReadOnlyList<IReadOnlyList<double>> Basis, IReadOnlyList<double> Eigen)
{
    public int Rank => Basis.Count;

    /// <summary>Principal components of the training chunks (covariance about the mean), keeping the top r.</summary>
    public static LinearIset Fit(IReadOnlyList<IReadOnlyList<double>> data, int r)
    {
        int n = data.Count, dim = data[0].Count;
        var mean = new double[dim];
        foreach (var x in data) for (int i = 0; i < dim; i++) mean[i] += x[i] / n;
        var c = new double[dim, dim];
        foreach (var x in data)
            for (int i = 0; i < dim; i++)
            {
                double xi = x[i] - mean[i];
                for (int j = 0; j <= i; j++) c[i, j] += xi * (x[j] - mean[j]);
            }
        for (int i = 0; i < dim; i++) for (int j = 0; j <= i; j++) { c[i, j] /= n; c[j, i] = c[i, j]; }
        var (vals, vecs) = Mat.SymmetricEigen(c);
        int k = Math.Min(r, dim);
        // Sign convention: the largest-magnitude component of each basis vector is positive.
        var basis = vecs.Take(k).Select(v => { int a = Enumerable.Range(0, dim).OrderByDescending(i => Math.Abs(v[i])).First(); double s = v[a] < 0 ? -1 : 1; return (IReadOnlyList<double>)v.Select(x => s * x).ToArray(); }).ToArray();
        return new LinearIset(dim, mean, basis, vals);
    }

    public LinearIset Truncate(int r) => this with { Basis = Basis.Take(Math.Min(r, Basis.Count)).ToArray() };

    public IReadOnlyList<double> Encode(IReadOnlyList<double> x)
    {
        var z = new double[Rank];
        for (int k = 0; k < Rank; k++) { double s = 0; var b = Basis[k]; for (int i = 0; i < Dim; i++) s += b[i] * (x[i] - Mean[i]); z[k] = s; }
        return z;
    }

    public IReadOnlyList<double> Decode(IReadOnlyList<double> z)
    {
        var x = Mean.ToArray();
        for (int k = 0; k < Math.Min(Rank, z.Count); k++) { double c = z[k]; var b = Basis[k]; for (int i = 0; i < Dim; i++) x[i] += c * b[i]; }
        return x;
    }
}

public sealed record DctIset(int Length, int K)
{
    public int Rank => Motor.Dof * K;

    public IReadOnlyList<double> Encode(IReadOnlyList<double> x)
    {
        var z = new double[Rank];
        for (int j = 0; j < Motor.Dof; j++)
            for (int k = 0; k < K; k++)
            {
                double s = 0;
                for (int t = 0; t < Length; t++) s += x[j * Length + t] * Math.Cos(Math.PI / Length * (t + 0.5) * k);
                z[j * K + k] = s * Math.Sqrt((k == 0 ? 1.0 : 2.0) / Length);
            }
        return z;
    }

    public IReadOnlyList<double> Decode(IReadOnlyList<double> z)
    {
        var x = new double[Motor.Dof * Length];
        for (int j = 0; j < Motor.Dof; j++)
            for (int t = 0; t < Length; t++)
            {
                double s = 0;
                for (int k = 0; k < K; k++) s += z[j * K + k] * Math.Sqrt((k == 0 ? 1.0 : 2.0) / Length) * Math.Cos(Math.PI / Length * (t + 0.5) * k);
                x[j * Length + t] = s;
            }
        return x;
    }
}
