using System.Diagnostics;
using VxLab.Core;
using VxLab.Experiments;

// Composition root: loads the lexicon once, schedules the studies and performs the only file writes.
string data = Environment.GetEnvironmentVariable("VX_DATA") ?? Path.Combine("..", "data", "large_en.msgpack.gz");
string outDir = Environment.GetEnvironmentVariable("VX_OUT") ?? Path.Combine("..", "out");
var swLoad = Stopwatch.StartNew();
var lexicon = Lexicon.Load(data, 50_000);
Console.WriteLine($"lexicon: {lexicon.Words.Count} words loaded in {swLoad.Elapsed.TotalSeconds:F1} s");
var registry = new (string Id, Func<Lexicon, ExperimentResult> Run)[]
{
    ("V00", V00_Accounting.Run),
    ("V01", V01_Exact.Run),
    ("V02", V02_WordRecords.Run),
    ("V03", V03_HybridCache.Run),
    ("V04", V04_AssociationAtoms.Run),
    ("V05", V05_AtomChoice.Run),
};
var selected = args.Length == 0 ? registry : registry.Where(r => args.Contains(r.Id)).ToArray();
var results = new List<ExperimentResult>();
foreach (var (id, run) in selected)
{
    var sw = Stopwatch.StartNew();
    var r = run(lexicon);
    sw.Stop();
    results.Add(r);
    Console.WriteLine($"{id} {r.Title}: {sw.Elapsed.TotalSeconds:F1} s");
    foreach (var kv in r.Headlines) Console.WriteLine($"   {kv.Key} = {kv.Value:G6}");
}
Output.Write(outDir, results);
