using VxLab.Core;

namespace VxLab.Experiments;

/// <summary>
/// The hybrid cache with sparse word records beside dense ISET chunk tokens. (a) Long mixed histories of 256–16,384
/// tokens, two words in seven: every word record is scored exactly through one primitive table, chunks by a typed screen
/// and per-step rerank; work and bytes are compared with the dense Part 1 reader. (b) Deeper layers: a word position's
/// record mixed with the mean record of the previous 16 tokens, against the decoded dense key of the same mixture;
/// identity, spelling and retrieval, and truncation of the grown support. (c) Cacheless aggregates: per word atom against
/// per slot and primitive, for reading values of present words and for telling present words from recombinations.
/// </summary>
public static class V03_HybridCache
{
    private const ulong Seed = 703;
    public const int D = 128, L = 8, LongTrials = 200, BankPerSkill = 200, K = 8, Window = 16, DepthTrials = 200, DepthPositions = 8, AggTrials = 1000, Dv = 64;
    public const double Sigma = 0.5, Tie = 1e-9;
    public static readonly double[] Betas = { 0, 0.25, 0.5, 1, 2, 4, 8, 16 };

    static bool StrictTop(IReadOnlyList<double> s, Func<int, bool> isTarget)
    {
        double best = s.Max();
        return Enumerable.Range(0, s.Count).Where(k => s[k] >= best - Tie).All(isTarget);
    }

    static double Auc(IReadOnlyList<double> pos, IReadOnlyList<double> neg)
    {
        double wins = 0;
        foreach (var p in pos) foreach (var n in neg) wins += p > n ? 1 : p == n ? 0.5 : 0;
        return wins / (pos.Count * (double)neg.Count);
    }

    public static ExperimentResult Run(Lexicon lex)
    {
        var h = new Dictionary<string, double>();
        var bank = ChunkBank.Make(L, BankPerSkill, D, Seed);
        var e = CharCode.Random(D, Rng.Derive(Seed, 1));
        var bind = Binder.Create(D, Sym.L + 1, Rng.Derive(Seed, 2));
        double nc = Math.Sqrt(bank.Keys.Average(Lin.Norm2));
        double lettersPerWord = lex.Words.Select((w, i) => lex.Prob[i] * w.Length).Sum();
        h["chunk_key_rms_norm"] = nc;

        // ---------- (a) long mixed histories ----------
        var longRows = new List<object[]>();
        foreach (int m in new[] { 256, 1024, 4096, 16384 })
        {
            int mw = (int)Math.Round(2.0 * m / 7), mc = m - mw;
            var trials = WordHistory.MakeTrials(lex, mw, LongTrials, Seed + 1000 + (ulong)m);
            var outs = Enumerable.Range(0, LongTrials).AsParallel().AsOrdered().Select(i =>
            {
                var t = trials[i];
                var r = Rng.Derive(Seed, 100_000UL + (ulong)(m * 1000 + i));
                var (qw, r1) = Mat.RelNoise(Layout.Concat(t.Target, e), Sigma, r);
                var u = Atoms.Table(qw, e);
                var atoms = t.Distinct.Select(WordAtom.Exact).ToArray();
                var sw = atoms.Select(a => Atoms.Score(u, a)).ToArray();
                bool wordOk = StrictTop(sw, k => t.Distinct[k] == t.Target);
                var hist = bank.History(mc, r1);
                var ck = hist.Select(k => Mat.Scale(bank.Keys[k], 1 / nc)).ToArray();
                var r2 = Rng.Derive(Seed, 200_000UL + (ulong)(m * 1000 + i));
                var (qc, r3) = Mat.RelNoise(ck[0], Sigma, r2);
                var (qcs, _) = Mat.RelNoise(bank.StepSlotKey(bank.Chunks[hist[0]]), Sigma, r3);
                var sc = ck.Select(k => Lin.Dot(qc, k) - 0.5 * Lin.Norm2(k)).ToArray();
                bool screenOnly = StrictTop(sc, k => k == 0);
                var cand = Lin.TopIndices(sc, Enumerable.Range(0, mc).ToArray(), K);
                var rr = cand.Select(k => { var s = bank.StepSlotKey(bank.Chunks[hist[k]]); return Lin.Dot(qcs, s) - 0.5 * Lin.Norm2(s); }).ToArray();
                bool chunkOk = cand.Contains(0) && StrictTop(rr, k => cand[k] == 0);
                return (wordOk, chunkOk, screenOnly, recall: cand.Contains(0), g: (double)atoms.Length, letters: (double)t.Distinct.Sum(w => w.Length));
            }).ToArray();
            double g = outs.Average(o => o.g), lettersG = outs.Average(o => o.letters);
            double macWord = Sym.L * Sym.Count * D + Sym.L * g + mw, macChunk = mc * D + K * L * D;
            double p1Word = (g + mc) * D + K * Sym.L * D, p1Chunk = (g + mc) * D + K * L * D;
            double bytesP1 = (mw + mc) * V00_Accounting.DenseKvBytes + mw * (lettersPerWord + 1) + mc * V00_Accounting.RawChunkBytes;
            double bytesP2 = mw * V00_Accounting.RecordBytes(1) + lettersG + mc * (V00_Accounting.DenseKvBytes + V00_Accounting.RawChunkBytes);
            double wAcc = outs.Average(o => o.wordOk ? 1.0 : 0), cAcc = outs.Average(o => o.chunkOk ? 1.0 : 0), cScreen = outs.Average(o => o.screenOnly ? 1.0 : 0), rec = outs.Average(o => o.recall ? 1.0 : 0);
            longRows.Add(new object[] { m, mw, g, mc, wAcc, cScreen, rec, cAcc, macWord, p1Word, macChunk, p1Chunk, bytesP2, bytesP1 });
            string key = $"long_M{m}";
            h[$"{key}_word_exact"] = wAcc; h[$"{key}_chunk_exact"] = cAcc; h[$"{key}_chunk_screen_only"] = cScreen; h[$"{key}_chunk_recall"] = rec;
            h[$"{key}_mac_word"] = macWord; h[$"{key}_mac_word_part1"] = p1Word; h[$"{key}_mac_chunk"] = macChunk; h[$"{key}_mac_chunk_part1"] = p1Chunk;
            h[$"{key}_bytes"] = bytesP2; h[$"{key}_bytes_part1"] = bytesP1; h[$"{key}_distinct"] = g;
        }
        var tLong = Table.Of("long_history", new[] { "tokens_M", "word_tokens", "distinct_words", "chunk_tokens", "word_exact_primitive_table", "chunk_exact_screen_only", "chunk_screen_recall_K8", "chunk_exact_screen_rerank",
            "mac_word_query", "mac_word_query_part1", "mac_chunk_query", "mac_chunk_query_part1", "cache_bytes_head_layer", "cache_bytes_head_layer_part1" }, longRows);

        // ---------- (b) deeper layers: mixing in coefficient space ----------
        var depthTrials = WordHistory.MakeTrials(lex, 256, DepthTrials, Seed + 11);
        var depthRows = new List<object[]>();
        foreach (double beta in Betas)
        {
            var outs = Enumerable.Range(0, DepthTrials).AsParallel().AsOrdered().Select(i =>
            {
                var t = depthTrials[i];
                var tok = t.Tokens;
                var distinct = t.Distinct.ToArray();
                var id = distinct.Select((w, k) => (w, k)).ToDictionary(x => x.w, x => x.k);
                var keys = distinct.Select(w => (IReadOnlyList<double>)Layout.Bound(w, e, bind)).ToArray();
                var a = tok.Select(w => id[w]).ToArray();
                var counts = a.GroupBy(x => x).ToDictionary(gq => gq.Key, gq => gq.Count());
                // Mixed records and their decoded keys for every position.
                var mixed = new Code[tok.Count]; var cbarMax = new double[tok.Count]; var ratio = new double[tok.Count];
                for (int p = 0; p < tok.Count; p++)
                {
                    int lo = Math.Max(0, p - Window), n = p - lo;
                    if (n == 0 || beta == 0) { mixed[p] = Code.One(a[p]); continue; }
                    var cb = Enumerable.Range(lo, n).GroupBy(s => a[s]).OrderBy(gq => gq.Key).ToArray();
                    var cbar = new Code(cb.Select(gq => gq.Key).ToArray(), cb.Select(gq => gq.Count() / (double)n).ToArray());
                    cbarMax[p] = cbar.Coef.Max();
                    mixed[p] = Rec.Mix(new[] { Code.One(a[p]), cbar }, new[] { 1 / (1 + beta), beta / (1 + beta) });
                    var kb = Rec.Decode(cbar, x => keys[x]);
                    ratio[p] = beta * Math.Sqrt(Lin.Norm2(kb) / Lin.Norm2(keys[a[p]]));
                }
                var variants = new[] { mixed, mixed.Select(c => Rec.TopS(c, 4)).ToArray(), mixed.Select(c => Rec.TopS(c, 16)).ToArray() };
                var dec = variants.Select(v => v.Select(c => (IReadOnlyList<double>)Rec.Decode(c, x => keys[x])).ToArray()).ToArray();
                var norms = dec.Select(v => v.Select(Lin.Norm2).ToArray()).ToArray();
                // Positions whose word occurs once, at least Window tokens in.
                var cand = Enumerable.Range(Window, tok.Count - Window).Where(p => counts[a[p]] == 1).ToArray();
                var rr = Rng.Derive(Seed, 300_000UL + (ulong)i);
                for (int k = cand.Length - 1; k > 0; k--) { var (j, nr) = rr.NextInt(k + 1); rr = nr; (cand[k], cand[j]) = (cand[j], cand[k]); }
                var res = new List<double[]>();
                foreach (int p in cand.Take(DepthPositions))
                {
                    var (q, nr) = Mat.RelNoise(keys[a[p]], Sigma, rr); rr = nr;
                    var row = new List<double> { ratio[p], beta * cbarMax[p] < 1 ? 1 : 0, Rec.Argmax(mixed[p]) == a[p] ? 1 : 0,
                        Layout.DecodeBound(Mat.Scale(dec[0][p], 1 + beta), e, bind) == tok[p] ? 1 : 0, mixed[p].Support };
                    for (int v = 0; v < 3; v++)
                    {
                        var s = Enumerable.Range(0, tok.Count).Select(x => Lin.Dot(q, dec[v][x]) - 0.5 * norms[v][x]).ToArray();
                        row.Add(StrictTop(s, x => x == p) ? 1 : 0);
                        if (v > 0) { row.Add(Rec.Argmax(variants[v][p]) == a[p] ? 1 : 0); row.Add(Rec.Tv(mixed[p], variants[v][p])); }
                    }
                    res.Add(row.ToArray());
                }
                return res;
            }).SelectMany(x => x).ToArray();
            double A(int c) => outs.Average(o => o[c]);
            depthRows.Add(new object[] { beta, A(0), A(1), A(2), A(3), A(4), A(5), A(7), A(8), A(6), A(10), A(11), A(9) });
            string key = $"depth_b{beta}";
            h[$"{key}_l2_ratio"] = A(0); h[$"{key}_guaranteed"] = A(1); h[$"{key}_identity"] = A(2); h[$"{key}_dense_spelled"] = A(3); h[$"{key}_support"] = A(4);
            h[$"{key}_retrieval"] = A(5); h[$"{key}_s4_identity"] = A(7); h[$"{key}_s4_pruned"] = A(8); h[$"{key}_s4_retrieval"] = A(6);
            h[$"{key}_s16_identity"] = A(10); h[$"{key}_s16_pruned"] = A(11); h[$"{key}_s16_retrieval"] = A(9);
            h[$"{key}_positions"] = outs.Length;
        }
        var tDepth = Table.Of("depth", new[] { "context_mass_ratio_beta", "decoded_context_to_self_l2", "guarantee_beta_max_cbar_below_1", "record_identity_argmax", "dense_key_spelled_by_unbinding", "record_support",
            "retrieval_full_record", "s4_identity", "s4_pruned_mass_tv", "s4_retrieval", "s16_identity", "s16_pruned_mass_tv", "s16_retrieval" }, depthRows);

        // ---------- (c) cacheless aggregates ----------
        var aggTrials = WordHistory.MakeTrials(lex, 256, AggTrials, Seed + 12);
        var aggRows = new List<object[]>();
        foreach (double tau in new[] { 0.25, 1.0 })
        {
            var outs = Enumerable.Range(0, AggTrials).AsParallel().AsOrdered().Select(i =>
            {
                var t = aggTrials[i];
                var tok = t.Tokens;
                var r = Rng.Derive(Seed, 400_000UL + (ulong)i);
                var vals = new IReadOnlyList<double>[tok.Count];
                for (int k = 0; k < tok.Count; k++) { var (v, nr) = Lin.Gaussians(r, Dv); r = nr; vals[k] = Mat.Normalize(v); }
                var distinct = t.Distinct.ToArray();
                var id = distinct.Select((w, k) => (w, k)).ToDictionary(x => x.w, x => x.k);
                int G = distinct.Length;
                var m = new double[G]; var S = new double[G, Dv];
                var ms = new double[Sym.L, Sym.Count]; var Ss = new double[Sym.L, Sym.Count, Dv];
                for (int k = 0; k < tok.Count; k++)
                {
                    int a = id[tok[k]]; m[a] += 1;
                    for (int x = 0; x < Dv; x++) S[a, x] += vals[k][x];
                    var sl = Sym.Left(tok[k]);
                    for (int j = 0; j < Sym.L; j++) { ms[j, sl[j]] += 1.0 / Sym.L; for (int x = 0; x < Dv; x++) Ss[j, sl[j], x] += vals[k][x] / Sym.L; }
                }
                var meanVal = Enumerable.Range(0, G).Select(a => (IReadOnlyList<double>)Enumerable.Range(0, Dv).Select(x => S[a, x] / m[a]).ToArray()).ToArray();
                (double[] Atom, double[] Slot, double EvAtom, double EvSlot, double[] Kv) Read(string w, Rng rq)
                {
                    var (q, _) = Mat.RelNoise(Layout.Concat(w, e), Sigma, rq);
                    var u = Atoms.Table(q, e);
                    var sa = distinct.Select(x => Atoms.Score(u, WordAtom.Exact(x)) / tau).ToArray();
                    double mx = sa.Max(), za = 0; var oa = new double[Dv];
                    for (int a = 0; a < G; a++) { double phi = Math.Exp(sa[a] - mx); za += phi * m[a]; for (int x = 0; x < Dv; x++) oa[x] += phi * S[a, x]; }
                    for (int x = 0; x < Dv; x++) oa[x] /= za;
                    // KV softmax over tokens with logits score/τ (equals the per-atom read for one-hot records).
                    var lt = tok.Select(x => sa[id[x]]).ToArray();
                    var wt = Lin.Softmax(lt); var okv = new double[Dv];
                    for (int k = 0; k < tok.Count; k++) for (int x = 0; x < Dv; x++) okv[x] += wt[k] * vals[k][x];
                    double ms_ = double.NegativeInfinity;
                    for (int j = 0; j < Sym.L; j++) for (int p = 0; p < Sym.Count; p++) if (ms[j, p] > 0) ms_ = Math.Max(ms_, Sym.L * u[j, p] / tau);
                    double zs = 0; var os = new double[Dv];
                    for (int j = 0; j < Sym.L; j++)
                        for (int p = 0; p < Sym.Count; p++)
                        {
                            if (ms[j, p] == 0) continue;
                            double phi = Math.Exp(Sym.L * u[j, p] / tau - ms_);
                            zs += phi * ms[j, p];
                            for (int x = 0; x < Dv; x++) os[x] += phi * Ss[j, p, x];
                        }
                    for (int x = 0; x < Dv; x++) os[x] /= zs;
                    return (oa, os, mx + Math.Log(za), ms_ + Math.Log(zs), okv);
                }
                int tgt = id[t.Target];
                bool Nearest(double[] o) { var c = meanVal.Select(v => Mat.Cosine(o, v)).ToArray(); return Array.IndexOf(c, c.Max()) == tgt; }
                var rt = Read(t.Target, Rng.Derive(Seed, 500_000UL + (ulong)i));
                double kvGap = rt.Atom.Zip(rt.Kv).Max(z => Math.Abs(z.First - z.Second));
                // A recombination probe: the first half of one present word joined to the second half of another of equal length.
                string? probe = null;
                var rp = Rng.Derive(Seed, 600_000UL + (ulong)i);
                for (int tries = 0; tries < 200 && probe is null; tries++)
                {
                    var (x1, n1) = rp.NextInt(G); var (x2, n2) = n1.NextInt(G); rp = n2;
                    string w1 = distinct[x1], w2 = distinct[x2];
                    if (x1 == x2 || w1.Length != w2.Length || w1.Length < 3) continue;
                    int half = (w1.Length + 1) / 2;
                    string s = w1[..half] + w2[half..];
                    if (!id.ContainsKey(s)) probe = s;
                }
                var rprobe = probe is null ? default : Read(probe, Rng.Derive(Seed, 700_000UL + (ulong)i));
                return (atomOk: Nearest(rt.Atom), slotOk: Nearest(rt.Slot), kvOk: Nearest(rt.Kv), kvGap, evA: rt.EvAtom, evS: rt.EvSlot,
                    hasProbe: probe is not null, pA: rprobe.EvAtom, pS: rprobe.EvSlot, g: (double)G);
            }).ToArray();
            var withProbe = outs.Where(o => o.hasProbe).ToArray();
            double aucA = Auc(outs.Select(o => o.evA).ToArray(), withProbe.Select(o => o.pA).ToArray());
            double aucS = Auc(outs.Select(o => o.evS).ToArray(), withProbe.Select(o => o.pS).ToArray());
            double g = outs.Average(o => o.g);
            void Add(string reader, double acc, double auc, double floats)
            {
                aggRows.Add(new object[] { tau, reader, acc, auc, floats });
                string key = $"agg_tau{tau:0.00}_{reader.Split(' ')[0]}";
                h[$"{key}_value_found"] = acc; if (!double.IsNaN(auc)) h[$"{key}_presence_auc"] = auc; h[$"{key}_state_floats"] = floats;
            }
            Add("KV cache softmax over 256 tokens", outs.Average(o => o.kvOk ? 1.0 : 0), double.NaN, 256.0 * (D + Dv));
            Add("per-atom aggregate (coefficient law)", outs.Average(o => o.atomOk ? 1.0 : 0), aucA, g * (1 + Dv));
            Add("slot–primitive aggregate (coefficient law)", outs.Average(o => o.slotOk ? 1.0 : 0), aucS, Sym.L * Sym.Count * (1 + Dv));
            h[$"agg_tau{tau:0.00}_kv_minus_atom_max_abs"] = outs.Max(o => o.kvGap);
            h[$"agg_tau{tau:0.00}_probes"] = withProbe.Length;
        }
        var tAgg = Table.Of("cacheless", new[] { "temperature_tau", "reader", "value_of_present_word_found", "presence_auc_vs_recombination_probes", "state_floats" }, aggRows);
        return new ExperimentResult("V03", "The hybrid cache with sparse word records", new[] { tLong, tDepth, tAgg }, h);
    }
}
