using VxLab.Core;

namespace VxLab.Experiments;

/// <summary>
/// Word tokens as word-Vocabucapillary records. Part A: in the histories of Step 1 (a target, up to eight near-duplicates
/// and frequency-sampled fillers, 256 tokens) the record scored through primitive tables gives the same scores as dense
/// concatenated or bound keys at a fraction of the work. Part B: every token is observed through a letter-confusion
/// channel and stored either as its observed letters (one new atom, as a dense cache would encode it), as a record over
/// lexicon atoms (MAP word, top 2, top 4, top 4 with 4-bit coefficients, full posterior), or as one new soft atom holding
/// the slot marginals of the posterior. A noisy query for the target must find a token whose true word is the target.
/// </summary>
public static class V02_WordRecords
{
    private const ulong Seed = 702;
    public const int D = 128, History = 256, Trials = 1000;
    public const double Sigma = 0.5, Tie = 1e-9;
    public static readonly double[] Eps = { 0.1, 0.2, 0.3 };
    public static readonly string[] Variants = { "observed letters (one new atom)", "MAP word (s = 1)", "top 2 (s = 2)", "top 4 (s = 4)", "top 4, 4-bit coefficients", "full posterior", "slot marginals (one new soft atom)" };

    /// <summary>A stored token: either a record over lexicon atoms or one dynamic atom.</summary>
    sealed record Stored(Code? Lexical, WordAtom? Dynamic);

    public static ExperimentResult Run(Lexicon lex)
    {
        var h = new Dictionary<string, double>();
        var e = CharCode.Random(D, Rng.Derive(Seed, 1));
        var bind = Binder.Create(D, Sym.L + 1, Rng.Derive(Seed, 2));
        var trials = WordHistory.MakeTrials(lex, History, Trials, Seed + 11);
        var index = Channel.PatternIndex(lex);
        h["mean_distinct_words"] = trials.Average(t => (double)t.Distinct.Count);
        h["mean_target_length"] = trials.Average(t => (double)t.Target.Length);

        // ---------- Part A: exact scores and cost without observation noise ----------
        var partA = Enumerable.Range(0, Trials).AsParallel().AsOrdered().Select(i =>
        {
            var t = trials[i];
            var (qc, r1) = Mat.RelNoise(Layout.Concat(t.Target, e), Sigma, Rng.Derive(Seed, 1_000_000UL + (ulong)i));
            var (qb, _) = Mat.RelNoise(Layout.Bound(t.Target, e, bind), Sigma, r1);
            var u = Atoms.Table(qc, e); var ub = Rec.BoundTable(qb, e, bind);
            var atoms = t.Distinct.Select(WordAtom.Exact).ToArray();
            var tc = atoms.Select(a => Atoms.Score(u, a)).ToArray();
            var dc = t.Distinct.Select(w => Lin.Dot(qc, Layout.Concat(w, e))).ToArray();
            var nb = t.Distinct.Select(w => Lin.Norm2(Layout.Bound(w, e, bind))).ToArray();       // atom norms, stored once per atom
            var tb = atoms.Select((a, k) => Rec.BoundScore(ub, a) - 0.5 * nb[k]).ToArray();
            var db = t.Distinct.Select((w, k) => Lin.Dot(qb, Layout.Bound(w, e, bind)) - 0.5 * nb[k]).ToArray();
            int target = Array.IndexOf(t.Distinct.ToArray(), t.Target);
            bool Strict(double[] s) { double best = s.Max(); return s.Count(v => v >= best - Tie) == 1 && s[target] >= best - Tie; }
            double dmax = Math.Max(tc.Zip(dc).Max(z => Math.Abs(z.First - z.Second)), tb.Zip(db).Max(z => Math.Abs(z.First - z.Second)));
            bool same = Array.IndexOf(tc, tc.Max()) == Array.IndexOf(dc, dc.Max()) && Array.IndexOf(tb, tb.Max()) == Array.IndexOf(db, db.Max());
            int letters = t.Distinct.Sum(w => w.Length);
            return (dmax, same, concat: Strict(tc), bound: Strict(tb), g: atoms.Length, letters);
        }).ToArray();
        double g = partA.Average(o => (double)o.g), lettersG = partA.Average(o => (double)o.letters);
        h["A_max_abs_diff"] = partA.Max(o => o.dmax);
        h["A_same_top1"] = partA.Average(o => o.same ? 1.0 : 0);
        h["A_concat_exact"] = partA.Average(o => o.concat ? 1.0 : 0);
        h["A_bound_exact"] = partA.Average(o => o.bound ? 1.0 : 0);
        var aRows = new List<object[]>
        {
            new object[] { "dense concatenated keys", "16·d per word", g * Sym.L * D, partA.Average(o => o.concat ? 1.0 : 0) },
            new object[] { "record, concatenated primitive table", "3 bytes per token", Sym.L * Sym.Count * D + Sym.L * g, partA.Average(o => o.concat ? 1.0 : 0) },
            new object[] { "dense bound keys", "d per word", g * D, partA.Average(o => o.bound ? 1.0 : 0) },
            new object[] { "record, bound primitive table", "3 bytes per token", (Sym.L + 1) * Sym.Count * D + lettersG + g, partA.Average(o => o.bound ? 1.0 : 0) },
        };
        h["A_mac_dense_concat"] = g * Sym.L * D; h["A_mac_table_concat"] = Sym.L * Sym.Count * D + Sym.L * g;
        h["A_mac_dense_bound"] = g * D; h["A_mac_table_bound"] = (Sym.L + 1) * Sym.Count * D + lettersG + g;
        var tA = Table.Of("exact_scores", new[] { "reader", "stored per word", "multiply_adds_per_query", "target_found_exactly" }, aRows);

        // ---------- Part B: uncertain observation ----------
        var bRows = new List<object[]>();
        var chRows = new List<object[]>();
        foreach (double eps in Eps)
        {
            var outs = Enumerable.Range(0, Trials).AsParallel().AsOrdered().Select(i =>
            {
                var t = trials[i];
                var tok = t.Tokens;
                var r = Rng.Derive(Seed, 2_000_000UL + (ulong)(eps * 1000) * 10_000UL + (ulong)i);
                var obs = new string[tok.Count];
                for (int k = 0; k < tok.Count; k++) { var (o, nr) = Channel.Observe(tok[k], eps, r); r = nr; obs[k] = o; }
                var post = obs.Select(o => Channel.Posterior(o, eps, lex, index)).ToArray();
                var soft = new Dictionary<string, WordAtom>();
                foreach (var (o, p) in obs.Zip(post)) if (!soft.ContainsKey(o)) soft[o] = Channel.SlotMarginals(p, o, lex);
                var stored = new Stored[Variants.Length][];
                stored[0] = obs.Select(o => new Stored(null, WordAtom.Exact(o))).ToArray();
                stored[1] = post.Select(p => new Stored(Rec.TopS(p, 1), null)).ToArray();
                stored[2] = post.Select(p => new Stored(Rec.TopS(p, 2), null)).ToArray();
                stored[3] = post.Select(p => new Stored(Rec.TopS(p, 4), null)).ToArray();
                stored[4] = post.Select(p => new Stored(Rec.Quantize(Rec.TopS(p, 4), 4), null)).ToArray();
                stored[5] = post.Select(p => new Stored(p, null)).ToArray();
                stored[6] = obs.Select(o => new Stored(null, soft[o])).ToArray();

                var (qc, _) = Mat.RelNoise(Layout.Concat(t.Target, e), Sigma, Rng.Derive(Seed, 3_000_000UL + (ulong)i));
                var u = Atoms.Table(qc, e);
                var cache = new Dictionary<int, double>();
                double Lex(int w) { if (!cache.TryGetValue(w, out double v)) { v = Atoms.Score(u, WordAtom.Exact(lex.Words[w])); cache[w] = v; } return v; }
                var res = new double[Variants.Length, 7];
                var truthIdx = tok.Select(w => lex.Index[w]).ToArray();
                for (int vi = 0; vi < Variants.Length; vi++)
                {
                    var st = stored[vi];
                    var s = st.Select(x => x.Lexical is not null ? Rec.Score(x.Lexical, Lex) : Atoms.Score(u, x.Dynamic!)).ToArray();
                    double best = s.Max();
                    bool ok = Enumerable.Range(0, s.Length).Where(k => s[k] >= best - Tie).All(k => tok[k] == t.Target);   // mathematically tied scores count as ties
                    double spelled = 0, retained = 0, entries = 0, nonword = 0, offMass = 0;
                    for (int k = 0; k < st.Length; k++)
                    {
                        if (st[k].Lexical is { } c)
                        {
                            spelled += Rec.Argmax(c) == truthIdx[k] ? 1 : 0;
                            retained += c.Atom.Contains(truthIdx[k]) ? 1 : 0;
                            entries += c.Support;
                        }
                        else
                        {
                            var a = st[k].Dynamic!;
                            string read = a.Spelling;
                            spelled += read == tok[k] ? 1 : 0;
                            retained += read == tok[k] ? 1 : 0;
                            entries += a.Slots.Take(a.Text.Length).Sum(x => x.Index.Count);
                            nonword += lex.Contains(read) ? 0 : 1;
                            if (vi == 6)
                            {
                                // Mass that the product of the slot marginals puts on strings outside the posterior's support.
                                var pk = post[k]; double inside = 0;
                                for (int ci = 0; ci < pk.Support; ci++) { string w = lex.Words[pk.Atom[ci]]; double pr = 1; for (int j = 0; j < w.Length; j++) pr *= a.Slots[j].Of(Sym.Of(w[j])); inside += pr; }
                                offMass += 1 - inside;
                            }
                        }
                    }
                    int n = st.Length;
                    res[vi, 0] = ok ? 1 : 0; res[vi, 1] = spelled / n; res[vi, 2] = retained / n; res[vi, 3] = entries / n; res[vi, 4] = nonword / n;
                    // New atoms: observations that are not words (observed letters) or whose slot marginals are not one-hot (soft atoms).
                    res[vi, 5] = vi == 0 ? obs.Distinct().Count(o => !lex.Contains(o)) : vi == 6 ? obs.Distinct().Count(o => soft[o].Slots.Any(x => x.Index.Count > 1)) : 0;
                    res[vi, 6] = offMass / n;
                }
                // Channel statistics.
                double wrongObs = 0, fixedByMap = 0, brokenByMap = 0, top2 = 0, support = 0;
                for (int k = 0; k < tok.Count; k++)
                {
                    bool obsOk = obs[k] == tok[k], mapOk = post[k].Atom[0] == truthIdx[k];
                    if (!obsOk) { wrongObs++; if (mapOk) fixedByMap++; } else if (!mapOk) brokenByMap++;
                    top2 += post[k].Atom.Take(2).Contains(truthIdx[k]) ? 1 : 0;
                    support += post[k].Support;
                }
                return (res, wrongObs, fixedByMap, brokenByMap, top2, support, n: tok.Count);
            }).ToArray();
            double tokens = outs.Sum(o => (double)o.n);
            double wrong = outs.Sum(o => o.wrongObs), fixd = outs.Sum(o => o.fixedByMap), broke = outs.Sum(o => o.brokenByMap);
            chRows.Add(new object[] { eps, wrong / tokens, fixd / wrong, broke / (tokens - wrong), outs.Sum(o => o.top2) / tokens, outs.Sum(o => o.support) / tokens });
            string ek = $"eps{eps:0.0}";
            h[$"{ek}_obs_wrong"] = wrong / tokens; h[$"{ek}_map_fixes"] = fixd / wrong; h[$"{ek}_map_breaks"] = broke / (tokens - wrong);
            h[$"{ek}_truth_top2"] = outs.Sum(o => o.top2) / tokens; h[$"{ek}_posterior_support"] = outs.Sum(o => o.support) / tokens;
            for (int vi = 0; vi < Variants.Length; vi++)
            {
                double ret = outs.Average(o => o.res[vi, 0]), sp = outs.Average(o => o.res[vi, 1]), rt = outs.Average(o => o.res[vi, 2]);
                double en = outs.Average(o => o.res[vi, 3]), nw = outs.Average(o => o.res[vi, 4]), newAtoms = outs.Average(o => o.res[vi, 5]), off = outs.Average(o => o.res[vi, 6]);
                double bytes = vi switch
                {
                    0 => 3 + 0,                                   // the record pointing to the new atom; the atom itself is counted under new atoms
                    4 => en * 2.5,                                // 16-bit index and a 4-bit coefficient
                    6 => 3,
                    _ => en * 3,
                };
                bRows.Add(new object[] { eps, Variants[vi], ret, sp, rt, en, bytes, newAtoms, nw, off });
                string vk = $"{ek}_v{vi}";
                h[$"{vk}_retrieval"] = ret; h[$"{vk}_spelled"] = sp; h[$"{vk}_retained"] = rt; h[$"{vk}_entries"] = en; h[$"{vk}_new_atoms"] = newAtoms; h[$"{vk}_nonword"] = nw; if (vi == 6) h[$"{vk}_off_candidate_mass"] = off;
            }
        }
        var tB = Table.Of("uncertain_observation", new[] { "letter_error_eps", "stored_as", "target_found", "token_read_correctly", "true_word_retained", "entries_per_token", "record_bytes_per_token", "new_atoms_per_history", "reading_not_a_word", "product_mass_off_candidates" }, bRows);
        var tC = Table.Of("channel", new[] { "letter_error_eps", "observation_wrong", "map_corrects_wrong_observation", "map_overrides_right_observation", "true_word_in_top2", "posterior_support" }, chRows);
        // Examples: misread tokens of the first histories at ε = 0.2, with their records.
        var exRows = new List<object[]>();
        for (int i = 0; i < Trials && exRows.Count < 12; i++)
        {
            var tok = trials[i].Tokens;
            var r = Rng.Derive(Seed, 2_000_000UL + 200UL * 10_000UL + (ulong)i);
            for (int k = 0; k < tok.Count && exRows.Count < 12; k++)
            {
                var (o, nr) = Channel.Observe(tok[k], 0.2, r); r = nr;
                if (o == tok[k]) continue;
                var post = Channel.Posterior(o, 0.2, lex, index);
                if (post.Coef[0] > 0.9) continue;                                              // keep the records that hold real uncertainty
                string top = string.Join("; ", Enumerable.Range(0, Math.Min(3, post.Support)).Select(c => $"{lex.Words[post.Atom[c]]} {post.Coef[c]:0.00}"));
                exRows.Add(new object[] { tok[k], o, lex.Contains(o) ? "word" : "not a word", top, post.Support, Channel.SlotMarginals(post, o, lex).Spelling, lex.Words[post.Atom[0]] == tok[k] ? "yes" : "no" });
            }
        }
        var tEx = Table.Of("examples", new[] { "true_word", "observed", "observation_is", "record_top3", "posterior_support", "soft_atom_reading", "map_is_true_word" }, exRows);
        return new ExperimentResult("V02", "Word tokens as records", new[] { tA, tB, tC, tEx }, h);
    }
}
