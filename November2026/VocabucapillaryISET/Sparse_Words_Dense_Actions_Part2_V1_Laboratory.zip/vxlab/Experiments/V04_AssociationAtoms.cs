using VxLab.Core;

namespace VxLab.Experiments;

/// <summary>
/// A counted association vocabulary trained on mixed tuples. The 256 verb–object actions of Part 1 (same prototypes,
/// interaction share ι) are executed E times each and arrive as tuples (verb record, object record, dense ISET code) in
/// a shuffled stream. Product atoms keep the word codes exact and cluster only the action codes (one-pass DP-means inside
/// each word tuple). They are compared with densified atoms (the same clustering on a dense joint vector of bound word
/// keys and the scaled action code), with role slots (Part 1: three dense vectors per execution) and with a linear map.
/// Planning (words → action), description (fresh action → words), misspelled cues, inventory size and bytes.
/// </summary>
public static class V04_AssociationAtoms
{
    private const ulong Seed = 704, PatternSeed = 404;
    public const int L = 8, D = 128, Rank = 56, TrainPerPair = 4;
    public const double Theta = 1.0, SignalRms = 0.26;
    public static readonly string[] Verbs = { "grasp", "push", "pull", "lift", "lower", "turn", "twist", "press", "slide", "pour", "shake", "wipe", "open", "close", "place", "drop" };
    public static readonly string[] Objects = { "cup", "box", "door", "lid", "bottle", "handle", "drawer", "knob", "block", "ball", "plate", "bowl", "pen", "key", "cloth", "valve" };

    static IReadOnlyList<double> UnitPattern(int id)
    {
        var p = Motor.Prototype(Motor.MakeSkill(id, PatternSeed), L);
        double rms = Math.Sqrt(p.Average(v => v * v));
        return p.Select(v => v / rms).ToArray();
    }

    /// <summary>x_p = s₀ [√((1 − ι)/2)(u_v + u_o) + √ι u_p], the prototypes of Part 1.</summary>
    public static IReadOnlyList<IReadOnlyList<double>> Prototypes(double iota)
    {
        var uv = Enumerable.Range(0, 16).Select(v => UnitPattern(1000 + v)).ToArray();
        var uo = Enumerable.Range(0, 16).Select(o => UnitPattern(2000 + o)).ToArray();
        var up = Enumerable.Range(0, 256).Select(p => UnitPattern(3000 + p)).ToArray();
        double a = Math.Sqrt((1 - iota) / 2), b = Math.Sqrt(iota);
        return Enumerable.Range(0, 256).Select(p => (IReadOnlyList<double>)Enumerable.Range(0, Motor.Dof * L)
            .Select(i => SignalRms * (a * (uv[p / 16][i] + uo[p % 16][i]) + b * up[p][i])).ToArray()).ToArray();
    }

    public sealed record World(double Iota, IReadOnlyList<IReadOnlyList<double>> Protos, LinearIset Pca, IReadOnlyList<Motor.Chunk> Stored, IReadOnlyList<IReadOnlyList<double>> Z,
        IReadOnlyList<int> Order, IReadOnlyList<IReadOnlyList<double>> VKeys, IReadOnlyList<IReadOnlyList<double>> OKeys, CharCode Code, Binder Bind, double ZScale);

    public static World Make(Lexicon lex, double iota, int perPair, ulong stream)
    {
        var protos = Prototypes(iota);
        var train = Enumerable.Range(0, 256 * TrainPerPair).Select(i => Motor.Execute(i / TrainPerPair, protos[i / TrainPerPair], L, Rng.Derive(Seed, stream + 10_000UL + (ulong)i)).Value).ToArray();
        var pca = LinearIset.Fit(train.Select(c => c.X).ToArray(), Rank);
        var stored = Enumerable.Range(0, 256 * perPair).Select(i => Motor.Execute(i / perPair, protos[i / perPair], L, Rng.Derive(Seed, stream + 1_000_000UL + (ulong)i)).Value).ToArray();
        var z = stored.Select(c => Bf16.Round(pca.Encode(c.X))).ToArray();
        var order = Enumerable.Range(0, stored.Length).ToArray();
        var r = Rng.Derive(Seed, stream + 5);
        for (int k = order.Length - 1; k > 0; k--) { var (j, nr) = r.NextInt(k + 1); r = nr; (order[k], order[j]) = (order[j], order[k]); }
        var code = CharCode.Random(D, Rng.Derive(Seed, stream + 1));
        var bind = Binder.Create(D, Sym.L + 1, Rng.Derive(Seed, stream + 2));
        var vk = Verbs.Select(w => Mat.Normalize(Layout.Bound(w, code, bind))).ToArray();
        var ok = Objects.Select(w => Mat.Normalize(Layout.Bound(w, code, bind))).ToArray();
        double zs = Math.Sqrt(z.Average(Lin.Norm2));
        return new World(iota, protos, pca, stored, z, order, vk, ok, code, bind, zs);
    }

    static double Dist2(IReadOnlyList<double> a, IReadOnlyList<double> b) { double s = 0; for (int i = 0; i < a.Count; i++) { double e = a[i] - b[i]; s += e * e; } return s; }

    public sealed record Outcome(string Method, double Entries, double Bytes, double PlanPair, double PlanRms, double Describe, double Purity, double AtomsPerPair);

    static IReadOnlyList<Motor.Chunk> Fresh(World w, ulong stream) => Enumerable.Range(0, 256).Select(p => Motor.Execute(p, w.Protos[p], L, Rng.Derive(Seed, stream + 3_000_000UL + (ulong)p)).Value).ToArray();

    /// <summary>Product atoms: exact word codes, one-pass DP-means on the action codes inside each word tuple.</summary>
    public static (Outcome Result, IReadOnlyList<ProductAtom> Atoms) Product(World w, double theta, ulong stream)
    {
        var tuples = w.Order.Select(i => ((IReadOnlyList<int>)new[] { w.Stored[i].Skill / 16, 16 + w.Stored[i].Skill % 16 }, w.Z[i])).ToArray();
        var atoms = Leader.Train(tuples, theta);
        double planOk = 0, se = 0;
        for (int p = 0; p < 256; p++)
        {
            var cand = atoms.Where(a => a.Words[0] == p / 16 && a.Words[1] == 16 + p % 16).ToArray();
            var best = cand.OrderByDescending(a => a.Count).First();
            planOk += 1;
            double e = Motor.Rms(w.Pca.Decode(best.Mean), w.Protos[p]); se += e * e;
        }
        var fresh = Fresh(w, stream);
        double desc = 0;
        for (int p = 0; p < 256; p++)
        {
            var zf = Bf16.Round(w.Pca.Encode(fresh[p].X));
            var nearest = atoms.OrderBy(a => Dist2(zf, a.Mean)).First();
            desc += nearest.Words[0] == p / 16 && nearest.Words[1] == 16 + p % 16 ? 1 : 0;
        }
        double bytes = atoms.Count * (2 * 2 + Rank * 2 + 4);
        return (new Outcome("product atoms", atoms.Count, bytes, planOk / 256, Math.Sqrt(se / 256), desc / 256, 1.0, atoms.Count / 256.0), atoms);
    }

    /// <summary>Densified atoms: the same clustering on [k̂_v; k̂_o; ẑ/s_z]; words are read back by the nearest verb and object key.</summary>
    public static Outcome Densified(World w, double theta, ulong stream)
    {
        IReadOnlyList<double> Joint(int skill, IReadOnlyList<double> z) => w.VKeys[skill / 16].Concat(w.OKeys[skill % 16]).Concat(z.Select(x => x / w.ZScale)).ToArray();
        var pts = w.Order.Select(i => Joint(w.Stored[i].Skill, w.Z[i])).ToArray();
        var res = Leader.Cluster(pts, theta);
        int nA = res.Centres.Count;
        var pairCounts = new Dictionary<(int, int), int>();
        for (int k = 0; k < pts.Length; k++) { var key = (res.Assign[k], w.Stored[w.Order[k]].Skill); pairCounts[key] = pairCounts.GetValueOrDefault(key) + 1; }
        double purity = Enumerable.Range(0, nA).Sum(a => pairCounts.Where(kv => kv.Key.Item1 == a).Max(kv => kv.Value)) / (double)pts.Length;
        int Verb(IReadOnlyList<double> c) => Enumerable.Range(0, 16).OrderByDescending(v => Lin.Dot(c.Take(D).ToArray(), w.VKeys[v])).First();
        int Obj(IReadOnlyList<double> c) => Enumerable.Range(0, 16).OrderByDescending(o => Lin.Dot(c.Skip(D).Take(D).ToArray(), w.OKeys[o])).First();
        double planOk = 0, se = 0;
        for (int p = 0; p < 256; p++)
        {
            var cue = w.VKeys[p / 16].Concat(w.OKeys[p % 16]).ToArray();
            int best = Enumerable.Range(0, nA).OrderBy(a => Dist2(cue, res.Centres[a].Take(2 * D).ToArray())).ThenByDescending(a => res.Counts[a]).First();
            var c = res.Centres[best];
            planOk += Verb(c) == p / 16 && Obj(c) == p % 16 ? 1 : 0;
            var z = c.Skip(2 * D).Select(x => x * w.ZScale).ToArray();
            double e = Motor.Rms(w.Pca.Decode(z), w.Protos[p]); se += e * e;
        }
        var fresh = Fresh(w, stream);
        double desc = 0;
        for (int p = 0; p < 256; p++)
        {
            var zf = Bf16.Round(w.Pca.Encode(fresh[p].X)).Select(x => x / w.ZScale).ToArray();
            int best = Enumerable.Range(0, nA).OrderBy(a => Dist2(zf, res.Centres[a].Skip(2 * D).ToArray())).First();
            desc += Verb(res.Centres[best]) == p / 16 && Obj(res.Centres[best]) == p % 16 ? 1 : 0;
        }
        double bytes = nA * ((2 * D + Rank) * 2 + 4);
        return new Outcome("densified atoms", nA, bytes, planOk / 256, Math.Sqrt(se / 256), desc / 256, purity, nA / 256.0);
    }

    /// <summary>Role slots of Part 1: [k̂_v; k̂_o; ẑ] per execution; planning by the summed role scores, description by the nearest action slot.</summary>
    public static Outcome RoleSlots(World w, ulong stream)
    {
        var zs = w.Z.Select(Mat.Normalize).ToArray();
        double planOk = 0, se = 0;
        for (int p = 0; p < 256; p++)
        {
            var s = w.Stored.Select(c => Lin.Dot(w.VKeys[p / 16], w.VKeys[c.Skill / 16]) + Lin.Dot(w.OKeys[p % 16], w.OKeys[c.Skill % 16])).ToArray();
            int top = Array.IndexOf(s, s.Max());
            planOk += w.Stored[top].Skill == p ? 1 : 0;
            double e = Motor.Rms(w.Pca.Decode(w.Z[top]), w.Protos[p]); se += e * e;
        }
        var fresh = Fresh(w, stream);
        double desc = 0;
        for (int p = 0; p < 256; p++)
        {
            var zf = Mat.Normalize(Bf16.Round(w.Pca.Encode(fresh[p].X)));
            var s = zs.Select(k => Lin.Dot(zf, k)).ToArray();
            desc += w.Stored[Array.IndexOf(s, s.Max())].Skill == p ? 1 : 0;
        }
        double bytes = w.Stored.Count * 3.0 * D * 2;
        return new Outcome("role slots (Part 1)", w.Stored.Count, bytes, planOk / 256, Math.Sqrt(se / 256), desc / 256, 1.0, w.Stored.Count / 256.0);
    }

    /// <summary>Ridge maps between [k̂_v; k̂_o] and the action code, as in Part 1.</summary>
    public static Outcome Linear(World w, ulong stream)
    {
        var x = w.Stored.Select(c => (IReadOnlyList<double>)w.VKeys[c.Skill / 16].Concat(w.OKeys[c.Skill % 16]).ToArray()).ToArray();
        var plan = Mat.Ridge(x, w.Z, 1e-3);
        var describe = Mat.Ridge(w.Z, x, 1e-3);
        double se = 0;
        for (int p = 0; p < 256; p++) { double e = Motor.Rms(w.Pca.Decode(plan(w.VKeys[p / 16].Concat(w.OKeys[p % 16]).ToArray())), w.Protos[p]); se += e * e; }
        var fresh = Fresh(w, stream);
        double desc = 0;
        for (int p = 0; p < 256; p++)
        {
            var pred = describe(Bf16.Round(w.Pca.Encode(fresh[p].X)));
            int v = Enumerable.Range(0, 16).OrderByDescending(i => Lin.Dot(pred.Take(D).ToArray(), w.VKeys[i])).First();
            int o = Enumerable.Range(0, 16).OrderByDescending(i => Lin.Dot(pred.Skip(D).ToArray(), w.OKeys[i])).First();
            desc += v == p / 16 && o == p % 16 ? 1 : 0;
        }
        return new Outcome("linear map", 0, (2.0 * D * Rank + Rank * 2.0 * D) * 2, double.NaN, Math.Sqrt(se / 256), desc / 256, double.NaN, 0);
    }

    /// <summary>One letter of the verb substituted (never giving one of the 32 words); returns the misspelled verbs per pair.</summary>
    static IReadOnlyList<string> Misspell(ulong stream)
    {
        var r = Rng.Derive(Seed, stream + 7);
        var outp = new string[256];
        var known = new HashSet<string>(Verbs.Concat(Objects));
        for (int p = 0; p < 256; p++)
        {
            string v = Verbs[p / 16];
            while (true)
            {
                var (j, r1) = r.NextInt(v.Length); var (c, r2) = r1.NextIntExcept(26, v[j] - 'a'); r = r2;
                string s = v[..j] + (char)('a' + c) + v[(j + 1)..];
                if (!known.Contains(s)) { outp[p] = s; break; }
            }
        }
        return outp;
    }

    public static ExperimentResult Run(Lexicon lex)
    {
        foreach (var x in Verbs.Concat(Objects)) if (!lex.Contains(x)) throw new InvalidOperationException($"{x} not in lexicon");
        var h = new Dictionary<string, double>();
        object[] Row(double a, double b, Outcome o) => new object[] { a, b, o.Method, o.Entries, o.Bytes, o.PlanPair, o.PlanRms, o.Describe, o.Purity, o.AtomsPerPair };
        void Put(string key, Outcome o)
        {
            h[$"{key}_entries"] = o.Entries; h[$"{key}_bytes"] = o.Bytes; if (!double.IsNaN(o.PlanPair)) h[$"{key}_plan_pair"] = o.PlanPair;
            h[$"{key}_plan_rms"] = o.PlanRms; h[$"{key}_describe"] = o.Describe; if (!double.IsNaN(o.Purity)) h[$"{key}_purity"] = o.Purity;
        }
        string[] header = { "a", "b", "method", "inventory_entries", "inventory_bytes", "plan_right_pair", "plan_rms_vs_prototype", "describe_both_words", "purity", "entries_per_pair" };

        // Experience: executions per pair at ι = 0.5.
        var expRows = new List<object[]>();
        foreach (int e in new[] { 1, 2, 4, 8, 16, 32 })
        {
            ulong st = 100_000_000UL * (ulong)e;
            var w = Make(lex, 0.5, e, st);
            double floor = Math.Sqrt(w.Stored.Average(c => { double x = Motor.Rms(c.X, w.Protos[c.Skill]); return x * x; }));
            h[$"exp_E{e}_execution_floor"] = floor;
            var (pa, atomsE) = Product(w, Theta, st);
            // Which executions sit in the smaller atoms of split pairs (nearest atom of their pair)?
            int inMinor = 0, minorContact = 0;
            for (int i = 0; i < w.Stored.Count; i++)
            {
                int pr = w.Stored[i].Skill;
                var mine = atomsE.Where(a => a.Words[0] == pr / 16 && a.Words[1] == 16 + pr % 16).ToArray();
                if (mine.Length < 2) continue;
                var near = mine.OrderBy(a => Dist2(w.Z[i], a.Mean)).First();
                if (near.Count == mine.Max(a => a.Count)) continue;
                inMinor++; minorContact += w.Stored[i].Contacts > 0 ? 1 : 0;
            }
            h[$"exp_E{e}_minor_atom_executions"] = inMinor; h[$"exp_E{e}_minor_atom_with_contact"] = minorContact;
            h[$"exp_E{e}_contact_share"] = w.Stored.Average(c => c.Contacts > 0 ? 1.0 : 0);
            var da = Densified(w, Theta, st);
            var rs = RoleSlots(w, st);
            foreach (var o in new[] { pa, da, rs }) { expRows.Add(Row(e, floor, o)); Put($"exp_E{e}_{o.Method.Split(' ')[0]}", o); }
        }
        var tExp = Table.Of("experience", new[] { "executions_per_pair_E", "execution_floor_rms" }.Concat(header.Skip(2)).ToArray(), expRows);

        // Interaction share at E = 4.
        var intRows = new List<object[]>();
        foreach (double iota in new[] { 0.0, 0.5, 1.0 })
        {
            ulong st = 10_000_000_000UL + (ulong)(iota * 1000) * 1_000_000UL;
            var w = Make(lex, iota, 4, st);
            var (pa, _) = Product(w, Theta, st);
            var rs = RoleSlots(w, st);
            var lm = Linear(w, st);
            foreach (var o in new[] { pa, rs, lm }) { intRows.Add(Row(iota, 4, o)); Put($"int_iota{iota:0.0}_{o.Method.Split(' ')[0]}", o); }
        }
        var tInt = Table.Of("interaction", new[] { "interaction_share_iota", "executions_per_pair_E" }.Concat(header.Skip(2)).ToArray(), intRows);

        // Threshold θ at ι = 0.5, E = 4.
        var thRows = new List<object[]>();
        var w4 = Make(lex, 0.5, 4, 20_000_000_000UL);
        foreach (double theta in new[] { 0.1, 0.25, 0.5, 1.0, 1.5, 2.0, 3.0 })
        {
            var (pa, _) = Product(w4, theta, 20_000_000_000UL);
            var da = Densified(w4, theta, 20_000_000_000UL);
            foreach (var o in new[] { pa, da }) { thRows.Add(Row(theta, 4, o)); Put($"th{theta:0.00}_{o.Method.Split(' ')[0]}", o); }
        }
        var tTh = Table.Of("threshold", new[] { "threshold_theta", "executions_per_pair_E" }.Concat(header.Skip(2)).ToArray(), thRows);

        // Misspelled verbs in the planning cue (ι = 0.5, E = 4).
        var miss = Misspell(20_000_000_000UL);
        var (pa4, atoms4) = Product(w4, Theta, 20_000_000_000UL);
        double exactOk = 0, tableVerb = 0, tablePlan = 0, slotPlan = 0, denseVerb = 0;
        for (int p = 0; p < 256; p++)
        {
            // Exact code match: the misspelled string is a new atom that no association atom contains.
            exactOk += Verbs.Contains(miss[p]) ? 1 : 0;
            // Table-scored cue: the misspelled string is scored against the verb atoms through the primitive table.
            var u = Atoms.Table(Layout.Concat(miss[p], w4.Code), w4.Code);
            var sv = Verbs.Select(v => Atoms.Score(u, WordAtom.Exact(v))).ToArray();
            int vbest = Array.IndexOf(sv, sv.Max());
            tableVerb += vbest == p / 16 ? 1 : 0;
            var cand = atoms4.Where(a => a.Words[0] == vbest && a.Words[1] == 16 + p % 16).OrderByDescending(a => a.Count).FirstOrDefault();
            tablePlan += cand is not null && vbest == p / 16 ? 1 : 0;
            // Role slots with the bound key of the misspelled verb.
            var mk = Mat.Normalize(Layout.Bound(miss[p], w4.Code, w4.Bind));
            var s = w4.Stored.Select(c => Lin.Dot(mk, w4.VKeys[c.Skill / 16]) + Lin.Dot(w4.OKeys[p % 16], w4.OKeys[c.Skill % 16])).ToArray();
            slotPlan += w4.Stored[Array.IndexOf(s, s.Max())].Skill == p ? 1 : 0;
            var dv = Enumerable.Range(0, 16).Select(v => Lin.Dot(mk, w4.VKeys[v])).ToArray();
            denseVerb += Array.IndexOf(dv, dv.Max()) == p / 16 ? 1 : 0;
        }
        var missRows = new List<object[]>
        {
            new object[] { "product atoms, exact code match", exactOk / 256, exactOk / 256 },
            new object[] { "product atoms, cue scored through the primitive table", tableVerb / 256, tablePlan / 256 },
            new object[] { "role slots, bound key of the misspelled verb", denseVerb / 256, slotPlan / 256 },
        };
        h["miss_exact_plan"] = exactOk / 256; h["miss_table_verb"] = tableVerb / 256; h["miss_table_plan"] = tablePlan / 256; h["miss_slots_plan"] = slotPlan / 256; h["miss_slots_verb"] = denseVerb / 256;
        var tMiss = Table.Of("misspelled_cue", new[] { "method", "right_verb", "plan_right_pair" }, missRows);
        var tEx = Table.Of("misspellings", new[] { "verb", "misspelled_cue_example" }, Enumerable.Range(0, 16).Select(v => (IReadOnlyList<object>)new object[] { Verbs[v], miss[v * 16] }));
        return new ExperimentResult("V04", "Counted association atoms", new[] { tExp, tInt, tTh, tMiss, tEx }, h);
    }
}
