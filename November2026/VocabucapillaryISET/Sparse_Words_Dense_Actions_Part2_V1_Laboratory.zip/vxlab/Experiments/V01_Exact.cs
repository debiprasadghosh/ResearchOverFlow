using VxLab.Core;

namespace VxLab.Experiments;

/// <summary>
/// Exact properties of word-Vocabucapillary records, checked numerically: the coefficient score through primitive tables
/// equals the dense score of the decoded key (concatenated and bound layouts); norms through the primitive Gram matrix;
/// the count implementation of the KV coefficient law; the Jensen gap of mixed records and its R²/8 bound; pruning and
/// quantization bounds; support union; the argmax guarantee under contextual mixing; and the conjunction blindness of
/// slot–primitive masses.
/// </summary>
public static class V01_Exact
{
    private const ulong Seed = 701;
    public const int D = 128, Inventory = 2000, SoftAtoms = 500, Records = 5000, Queries = 20;

    static (WordAtom Atom, Rng Next) SoftAtom(string w, Rng rng)
    {
        var slots = new SlotDict[Sym.L];
        var r = rng;
        for (int j = 0; j < Sym.L; j++)
        {
            if (j >= w.Length) { slots[j] = SlotDict.One(Sym.Pad); continue; }
            var (k, r1) = r.NextInt(3); r = r1;
            var idx = new List<int> { Sym.Of(w[j]) };
            while (idx.Count < k + 1) { var (p, r2) = r.NextInt(26); r = r2; if (!idx.Contains(p)) idx.Add(p); }
            var (c, r3) = r.NextDirichlet(idx.Count, 1.0); r = r3;
            slots[j] = new SlotDict(idx.ToArray(), c);
        }
        return (new WordAtom(w, slots), r);
    }

    static (Code Value, Rng Next) RandomCode(int atoms, int maxSupport, Rng rng)
    {
        var (s, r) = rng.NextInt(maxSupport); s += 1;
        var idx = new List<int>();
        while (idx.Count < s) { var (a, r1) = r.NextInt(atoms); r = r1; if (!idx.Contains(a)) idx.Add(a); }
        var (c, r2) = r.NextDirichlet(s, 1.0);
        return (new Code(idx.ToArray(), c), r2);
    }

    public static ExperimentResult Run(Lexicon lex)
    {
        var h = new Dictionary<string, double>();
        var rows = new List<object[]>();
        void Check(string name, double value, string requirement) { rows.Add(new object[] { name, value, requirement }); }

        var e = CharCode.Random(D, Rng.Derive(Seed, 1));
        var bind = Binder.Create(D, Sym.L + 1, Rng.Derive(Seed, 2));
        var r = Rng.Derive(Seed, 3);
        var atoms = new List<WordAtom>();
        for (int i = 0; i < Inventory; i++) { var (k, nr) = r.NextInt(20_000); r = nr; atoms.Add(WordAtom.Exact(lex.Words[k])); }
        for (int i = 0; i < SoftAtoms; i++) { var (k, nr) = r.NextInt(20_000); var (a, nr2) = SoftAtom(lex.Words[k], nr); r = nr2; atoms.Add(a); }
        var concat = atoms.Select(a => (IReadOnlyList<double>)Atoms.Concat(a, e)).ToArray();
        var bound = atoms.Select(a => (IReadOnlyList<double>)Atoms.Bound(a, e, bind)).ToArray();
        var codes = new List<Code>();
        for (int i = 0; i < Records; i++) { var (c, nr) = RandomCode(atoms.Count, 8, r); r = nr; codes.Add(c); }

        // 1. Coefficient score through primitive tables equals the dense score of the decoded key.
        double maxConcat = 0, maxBound = 0, maxScale = 0;
        for (int qi = 0; qi < Queries; qi++)
        {
            var (qc, r1) = Lin.Gaussians(Rng.Derive(Seed, 100 + (ulong)qi), Sym.L * D);
            var (qb, _) = Lin.Gaussians(r1, D);
            var u = Atoms.Table(qc, e); var ub = Rec.BoundTable(qb, e, bind);
            var sa = atoms.Select(a => Atoms.Score(u, a)).ToArray();
            var sb = atoms.Select(a => Rec.BoundScore(ub, a)).ToArray();
            foreach (var c in codes)
            {
                double t1 = Rec.Score(c, a => sa[a]), d1 = Lin.Dot(qc, Rec.Decode(c, a => concat[a]));
                double t2 = Rec.Score(c, a => sb[a]), d2 = Lin.Dot(qb, Rec.Decode(c, a => bound[a]));
                maxConcat = Math.Max(maxConcat, Math.Abs(t1 - d1)); maxBound = Math.Max(maxBound, Math.Abs(t2 - d2));
                maxScale = Math.Max(maxScale, Math.Max(Math.Abs(d1), Math.Abs(d2)));
            }
        }
        Check("concatenated layout: largest gap between table and dense scores", maxConcat, "rounding only");
        Check("bound layout: largest gap between table and dense scores", maxBound, "rounding only");
        h["score_identity_concat_max_abs"] = maxConcat; h["score_identity_bound_max_abs"] = maxBound; h["score_scale_max"] = maxScale;

        // 2. Norms through the primitive Gram matrix.
        var gram = Atoms.Gram(e);
        double maxNorm = 0;
        foreach (var c in codes.Take(1000))
        {
            double direct = Lin.Norm2(Rec.Decode(c, a => concat[a])), viaGram = 0;
            for (int i = 0; i < c.Support; i++) for (int j = 0; j < c.Support; j++) viaGram += c.Coef[i] * c.Coef[j] * Atoms.Inner(atoms[c.Atom[i]], atoms[c.Atom[j]], gram);
            maxNorm = Math.Max(maxNorm, Math.Abs(direct - viaGram) / direct);
        }
        Check("squared key norm through the primitive Gram matrix: largest relative error", maxNorm, "rounding only");
        h["norm_gram_max_rel"] = maxNorm;

        // 3. Count implementation of the KV coefficient law for one-hot records, and 4. the Jensen gap of mixed records.
        double maxCount = 0, maxJRatio = 0, sumJ = 0, maxJ = 0; int nJ = 0, jViol = 0;
        const int dv = 32, hist = 256;
        for (int qi = 0; qi < 200; qi++)
        {
            var rr = Rng.Derive(Seed, 1000 + (ulong)qi);
            var (q, r1) = Lin.Gaussians(rr, Sym.L * D);
            var u = Atoms.Table(q, e);
            double tau = 2.0;
            var sAtom = new Dictionary<int, double>();
            double S(int a) { if (!sAtom.TryGetValue(a, out double v)) { v = Atoms.Score(u, atoms[a]) / tau; sAtom[a] = v; } return v; }
            var oneHot = new Code[hist]; var values = new IReadOnlyList<double>[hist];
            var rq = r1;
            for (int t = 0; t < hist; t++) { var (a, n1) = rq.NextInt(Inventory); var (v, n2) = Lin.Gaussians(n1, dv); rq = n2; oneHot[t] = Code.One(a); values[t] = v; }
            // Softmax attention over tokens.
            var logits = oneHot.Select(c => Rec.Score(c, S)).ToArray();
            var w = Lin.Softmax(logits);
            var o = new double[dv];
            for (int t = 0; t < hist; t++) for (int k = 0; k < dv; k++) o[k] += w[t] * values[t][k];
            // Coefficient law: masses m_a = Σ_t c_ta, sums S_a = Σ_t c_ta v_t, read Σ_a φ_a S_a / Σ_a φ_a m_a.
            var m = new Dictionary<int, double>(); var sv = new Dictionary<int, double[]>();
            for (int t = 0; t < hist; t++)
                for (int i = 0; i < oneHot[t].Support; i++)
                {
                    int a = oneHot[t].Atom[i]; double c = oneHot[t].Coef[i];
                    m[a] = m.GetValueOrDefault(a) + c;
                    if (!sv.TryGetValue(a, out var acc)) { acc = new double[dv]; sv[a] = acc; }
                    for (int k = 0; k < dv; k++) acc[k] += c * values[t][k];
                }
            double mx = m.Keys.Max(S), num = 0; var o2 = new double[dv];
            foreach (var a in m.Keys) { double phi = Math.Exp(S(a) - mx); num += phi * m[a]; for (int k = 0; k < dv; k++) o2[k] += phi * sv[a][k]; }
            for (int k = 0; k < dv; k++) maxCount = Math.Max(maxCount, Math.Abs(o[k] - o2[k] / num));
            // Mixed records: log Σ c φ − Σ c log φ.
            for (int t = 0; t < 32; t++)
            {
                var (c, n3) = RandomCode(Inventory, 8, rq); rq = n3;
                if (c.Support < 2) continue;
                var sc = c.Atom.Select(S).ToArray();
                double lin = Enumerable.Range(0, c.Support).Sum(i => c.Coef[i] * sc[i]);
                double smax = sc.Max();
                double lse = smax + Math.Log(Enumerable.Range(0, c.Support).Sum(i => c.Coef[i] * Math.Exp(sc[i] - smax)));
                double J = lse - lin, R = sc.Max() - sc.Min(), bound_ = R * R / 8;
                if (J < -1e-12 || J > bound_ + 1e-12) jViol++;
                maxJRatio = Math.Max(maxJRatio, bound_ > 0 ? J / bound_ : 0); sumJ += J; maxJ = Math.Max(maxJ, J); nJ++;
            }
        }
        Check("one-hot records: largest gap between the coefficient read and softmax attention", maxCount, "rounding only");
        Check("mixed records whose Jensen gap J lies outside [0, R²/8]", jViol, "0 cases");
        Check("Jensen gap: largest J / (R²/8)", maxJRatio, "≤ 1");
        Check("Jensen gap: mean J (τ = 2, supports 2–8)", sumJ / nJ, "–");
        h["count_impl_max_abs"] = maxCount; h["jensen_violations"] = jViol; h["jensen_max_ratio"] = maxJRatio; h["jensen_mean"] = sumJ / nJ; h["jensen_max"] = maxJ; h["jensen_cases"] = nJ;

        // 5. Pruning: TV = η and ‖k(c) − k(c̃)‖ ≤ η D*; 6. quantization: |Δ score| ≤ TV · R.
        double maxTv = 0, maxPrune = 0, maxQuant = 0; int nPrune = 0;
        var u0 = Atoms.Table(Lin.Gaussians(Rng.Derive(Seed, 5000), Sym.L * D).Values, e);
        var s0 = atoms.Select(a => Atoms.Score(u0, a)).ToArray();
        foreach (var c in codes.Where(c => c.Support >= 3))
        {
            var order = Enumerable.Range(0, c.Support).OrderBy(i => c.Coef[i]).ToArray();
            int drop = c.Support / 2;
            var kept = order.Skip(drop).ToArray();
            double eta = order.Take(drop).Sum(i => c.Coef[i]);
            var ct = Rec.FromWeights(kept.Select(i => c.Atom[i]).ToArray(), kept.Select(i => c.Coef[i]).ToArray());
            maxTv = Math.Max(maxTv, Math.Abs(Rec.Tv(c, ct) - eta));
            var diff = Mat.Add(Rec.Decode(c, a => concat[a]), Rec.Decode(ct, a => concat[a]), -1);
            double dstar = 0;
            for (int i = 0; i < c.Support; i++) for (int j = i + 1; j < c.Support; j++) dstar = Math.Max(dstar, Math.Sqrt(Lin.Norm2(Mat.Add(concat[c.Atom[i]], concat[c.Atom[j]], -1))));
            maxPrune = Math.Max(maxPrune, Math.Sqrt(Lin.Norm2(diff)) / (eta * dstar));
            var cq = Rec.Quantize(c, 4);
            var sc = c.Atom.Select(a => s0[a]).ToArray();
            double R = sc.Max() - sc.Min();
            double dq = Math.Abs(Rec.Score(c, a => s0[a]) - Rec.Score(cq, a => s0[a]));
            if (R > 0) maxQuant = Math.Max(maxQuant, dq / (Rec.Tv(c, cq) * R + 1e-300));
            nPrune++;
        }
        Check("pruning: largest gap between TV(c, c̃) and η", maxTv, "rounding only");
        Check("pruning: largest ‖k(c) − k(c̃)‖ / (η D*)", maxPrune, "≤ 1");
        Check("4-bit coefficients: largest score change over TV · R", maxQuant, "≤ 1");
        h["prune_tv_max_abs"] = maxTv; h["prune_ratio_max"] = maxPrune; h["quant_ratio_max"] = maxQuant; h["prune_cases"] = nPrune;

        // 7. Support union under attention.
        int unionViol = 0;
        for (int i = 0; i + 8 <= 4000; i += 8)
        {
            var group = codes.Skip(i).Take(8).ToArray();
            var mix = Rec.Mix(group, Enumerable.Repeat(1.0 / 8, 8).ToArray());
            var union = group.SelectMany(c => c.Atom).Distinct().Count();
            if (mix.Support != union) unionViol++;
        }
        Check("attention outputs whose support is not the union of the supports", unionViol, "0 of 500 groups");
        h["support_union_violations"] = unionViol;

        // 8. Argmax under contextual mixing c' = (e_a + β c̄)/(1 + β): preserved whenever β max c̄ < 1.
        int guaranteed = 0, guaranteedViol = 0, outside = 0, outsideFlip = 0;
        var rm = Rng.Derive(Seed, 7000);
        foreach (double beta in new[] { 0.5, 1, 2, 4, 8, 16, 32 })
            for (int t = 0; t < 2000; t++)
            {
                var (self, n1) = rm.NextInt(64); rm = n1;
                var ctx = new int[16];
                for (int k = 0; k < 16; k++) { var (a, n2) = rm.NextInt(64); rm = n2; ctx[k] = a; }
                var cbar = ctx.GroupBy(a => a).ToDictionary(g => g.Key, g => g.Count() / 16.0);
                var mixed = Rec.Mix(new[] { Code.One(self), new Code(cbar.Keys.ToArray(), cbar.Values.ToArray()) }, new[] { 1 / (1 + beta), beta / (1 + beta) });
                bool kept = Rec.Argmax(mixed) == self;
                if (beta * cbar.Values.Max() < 1) { guaranteed++; if (!kept) guaranteedViol++; }
                else { outside++; if (!kept) outsideFlip++; }
            }
        Check("argmax lost although β·max ō < 1", guaranteedViol, $"0 of {guaranteed:N0}");
        Check("share of cases with β·max ō ≥ 1 where the argmax was lost (16 context atoms drawn from 64)", outside == 0 ? 0 : outsideFlip / (double)outside, "–");
        h["mix_guaranteed_cases"] = guaranteed; h["mix_guaranteed_violations"] = guaranteedViol; h["mix_outside_flip_share"] = outside == 0 ? 0 : outsideFlip / (double)outside;

        // 9. Conjunction blindness: slot–primitive masses of {cat, dog} and {cog, dat} coincide; per-atom masses do not.
        string[] A = { "cat", "dog" }, B = { "cog", "dat" };
        double[,] Masses(string[] ws) { var mm = new double[Sym.L, Sym.Count]; foreach (var w in ws) { var s = Sym.Left(w); for (int j = 0; j < Sym.L; j++) mm[j, s[j]] += 1; } return mm; }
        var ma = Masses(A); var mb = Masses(B);
        double maxDm = 0;
        for (int j = 0; j < Sym.L; j++) for (int p = 0; p < Sym.Count; p++) maxDm = Math.Max(maxDm, Math.Abs(ma[j, p] - mb[j, p]));
        var qcat = Layout.Concat("cat", e);
        var ucat = Atoms.Table(qcat, e);
        double tauc = 0.25;
        double SlotEvidence(double[,] mm) { double z = 0; for (int j = 0; j < Sym.L; j++) for (int p = 0; p < Sym.Count; p++) z += mm[j, p] * Math.Exp(ucat[j, p] / tauc); return Math.Log(z); }
        double AtomEvidence(string[] ws) => Math.Log(ws.Sum(w => Math.Exp(Atoms.Score(ucat, WordAtom.Exact(w)) / tauc)));
        Check("slot–primitive masses of {cat, dog} and {cog, dat}: largest difference", maxDm, "0 (identical states)");
        Check("slot–primitive evidence for the query 'cat': {cat, dog} minus {cog, dat}", SlotEvidence(ma) - SlotEvidence(mb), "0 (blind)");
        Check("per-atom evidence for the query 'cat': {cat, dog} minus {cog, dat}", AtomEvidence(A) - AtomEvidence(B), "> 0");
        h["conj_slot_mass_maxdiff"] = maxDm; h["conj_slot_evidence_diff"] = SlotEvidence(ma) - SlotEvidence(mb); h["conj_atom_evidence_diff"] = AtomEvidence(A) - AtomEvidence(B);
        h["conj_cat_score_cat"] = Atoms.Score(ucat, WordAtom.Exact("cat")); h["conj_cat_score_dat"] = Atoms.Score(ucat, WordAtom.Exact("dat")); h["conj_cat_score_cog"] = Atoms.Score(ucat, WordAtom.Exact("cog"));

        var table = Table.Of("identities", new[] { "check", "value", "requirement" }, rows);
        return new ExperimentResult("V01", "Exact properties of word records", new[] { table }, h);
    }
}
