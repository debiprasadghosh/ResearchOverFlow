using VxLab.Core;

namespace VxLab.Experiments;

/// <summary>
/// Exact accounting for the hybrid cache when word entries become word-Vocabucapillary records and chunk entries stay
/// dense ISET vectors. Distinct words against word tokens (frequency-sampled English); cache bytes per head and layer
/// and per eight-head layer for a minute and an hour of speech beside a 50 Hz body stream in 8-step chunks; the support
/// at which a record costs as much as a dense key and value; and the multiply-adds of a word query read by a dense scan,
/// by an atom-key table and by a primitive table.
/// </summary>
public static class V00_Accounting
{
    private const ulong Seed = 700;
    public const int D = 128, BytesPerValue = 2, IndexBytes = 2, CoefBytes = 1, L = 8, Rate = 50, Heads = 8;
    public const double WordsPerSecond = 2.5, RawChunkBytes = Motor.Dof * L * 4 / 8.0;
    public static readonly int[] HeapsTokens = { 150, 1_000, 10_000, 100_000, 1_000_000 };
    public static readonly int[] QueryTokens = { 64, 256, 1_024, 4_096, 16_384, 65_536 };

    public static int RecordBytes(int s) => s * (IndexBytes + CoefBytes);
    public const int DenseKvBytes = 2 * D * BytesPerValue;

    /// <summary>Mean number of distinct words, and mean letters of those distinct words, in reps samples of m tokens.</summary>
    public static (double Distinct, double Letters) Distinct(Lexicon lex, int m, int reps, ulong stream)
    {
        double g = 0, letters = 0;
        for (int r = 0; r < reps; r++)
        {
            var tok = WordHistory.SampleTokens(lex, m, Rng.Derive(Seed, stream + (ulong)r));
            var set = tok.Distinct().ToArray();
            g += set.Length; letters += set.Sum(w => w.Length);
        }
        return (g / reps, letters / reps);
    }

    static int Reps(int m) => m <= 1_000 ? 100 : m <= 10_000 ? 20 : m <= 100_000 ? 4 : 1;

    public static double MacDense(double m) => m * D;
    public static double MacAtomTable(double m, double g, int s = 1) => g * D + m * s;
    public static double MacPrimitiveTable(double m, double g, int s = 1) => Sym.L * Sym.Count * D + Sym.L * g + m * s;

    public static ExperimentResult Run(Lexicon lex)
    {
        var h = new Dictionary<string, double>();
        double lettersPerWord = lex.Words.Select((w, i) => lex.Prob[i] * w.Length).Sum();
        h["letters_per_word"] = lettersPerWord;
        h["dense_kv_bytes"] = DenseKvBytes;
        h["record_entry_bytes"] = RecordBytes(1);
        h["break_even_support_head"] = DenseKvBytes / (double)RecordBytes(1);
        h["break_even_support_layer8"] = Heads * DenseKvBytes / (double)RecordBytes(1);
        h["atom_key_dictionary_bytes_head"] = (double)lex.Words.Count * D * BytesPerValue;

        // Distinct words against tokens (Heaps).
        var heapsRows = new List<object[]>();
        double prevM = 0, prevG = 0;
        foreach (int m in HeapsTokens)
        {
            var (g, letters) = Distinct(lex, m, Reps(m), 1_000_000UL * (ulong)(Array.IndexOf(HeapsTokens, m) + 1));
            double local = prevM > 0 ? Math.Log(g / prevG) / Math.Log(m / prevM) : double.NaN;
            heapsRows.Add(new object[] { m, Reps(m), g, g / m, letters / g, local });
            h[$"heaps_M{m}_distinct"] = g; h[$"heaps_M{m}_distinct_share"] = g / m;
            if (!double.IsNaN(local)) h[$"heaps_M{m}_local_exponent"] = local;
            prevM = m; prevG = g;
        }
        var heaps = Table.Of("heaps", new[] { "word_tokens_M", "samples", "distinct_words_G", "distinct_share", "letters_per_distinct_word", "local_exponent_vs_previous" }, heapsRows);

        // Cache bytes for a minute and an hour.
        var storeRows = new List<object[]>();
        foreach (var (label, seconds) in new[] { ("one minute", 60.0), ("one hour", 3600.0) })
        {
            int mw = (int)Math.Round(WordsPerSecond * seconds), mc = (int)Math.Round(Rate * seconds / L);
            var (g, letters) = Distinct(lex, mw, mw <= 1000 ? 100 : 10, 9_000_000UL + (ulong)mw);
            double letterBytes = mw * (lettersPerWord + 1);                       // letter slots kept beside dense keys for the rerank
            double chunkHead = mc * (DenseKvBytes + RawChunkBytes);
            foreach (int heads in new[] { 1, Heads })
            {
                double denseWords = mw * DenseKvBytes * heads + letterBytes, chunks = mc * DenseKvBytes * heads + mc * RawChunkBytes;
                void Add(string scheme, double words, double inventory)
                {
                    double total = words + inventory + chunks;
                    storeRows.Add(new object[] { label, heads, scheme, mw, g, mc, words, inventory, chunks, total, (words + inventory) / total, total / (denseWords + chunks) });
                    string key = $"{(seconds == 60 ? "minute" : "hour")}_h{heads}_{scheme.Split(',')[0].Replace(" ", "_").Replace("(", "").Replace(")", "").Replace("=", "")}";
                    h[$"{key}_word_bytes"] = words + inventory; h[$"{key}_total_bytes"] = total; h[$"{key}_word_share"] = (words + inventory) / total;
                }
                Add("dense word keys (Part 1)", denseWords, 0);
                Add("records s = 1", mw * RecordBytes(1), letters);
                Add("records s = 4", mw * RecordBytes(4), letters);
            }
            h[$"{(seconds == 60 ? "minute" : "hour")}_word_tokens"] = mw; h[$"{(seconds == 60 ? "minute" : "hour")}_distinct_words"] = g;
            h[$"{(seconds == 60 ? "minute" : "hour")}_chunk_tokens"] = mc;
        }
        var store = Table.Of("storage", new[] { "horizon", "heads", "word_scheme", "word_tokens", "distinct_words", "chunk_tokens", "word_bytes", "atom_inventory_bytes", "chunk_bytes", "total_bytes", "word_share", "total_over_dense" }, storeRows);

        // Multiply-adds of one word query.
        var macRows = new List<object[]>();
        foreach (int m in QueryTokens)
        {
            var (g, _) = Distinct(lex, m, m <= 4096 ? 20 : 4, 20_000_000UL + (ulong)m);
            double dense = MacDense(m), atom = MacAtomTable(m, g), prim = MacPrimitiveTable(m, g);
            macRows.Add(new object[] { m, g, dense, atom, prim, dense / prim, dense / atom });
            h[$"mac_M{m}_dense"] = dense; h[$"mac_M{m}_atom_table"] = atom; h[$"mac_M{m}_primitive_table"] = prim; h[$"mac_M{m}_distinct"] = g;
        }
        var macs = Table.Of("query_macs", new[] { "word_tokens_M", "distinct_words_G", "dense_scan", "atom_key_table", "primitive_table", "dense_over_primitive", "dense_over_atom_table" }, macRows);

        // Break-even length of the primitive table against a dense scan (first M on a grid of 8 where the table is cheaper).
        int breakEven = -1;
        for (int m = 256; m <= 1024 && breakEven < 0; m += 8)
        {
            var (g, _) = Distinct(lex, m, 40, 30_000_000UL + (ulong)m);
            if (MacPrimitiveTable(m, g) <= MacDense(m)) breakEven = m;
        }
        h["break_even_tokens_primitive_table"] = breakEven;
        h["break_even_tokens_all_distinct"] = Sym.L * Sym.Count * D / (double)(D - Sym.L - 1);
        h["primitive_table_fixed_macs"] = Sym.L * Sym.Count * D;
        return new ExperimentResult("V00", "Accounting for sparse word records beside dense chunks", new[] { heaps, store, macs }, h);
    }
}
