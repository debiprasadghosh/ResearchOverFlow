using VxLab.Core;

namespace VxLab.Experiments;

/// <summary>
/// Choosing an association atom is the discrete choice of an action mode. The two-way obstacle task of Part 1 (512
/// executions under one cue, half passing left) and an unequal three-mode variant (amplitudes +1, −1, +2 with
/// frequencies 0.6, 0.3, 0.1) are trained into product atoms (cue record, mean ISET code, count, variance). Readers: a
/// soft read over atoms, the arg-max count, an atom sampled in proportion to its count, and a sampled atom plus a residual
/// drawn from its stored variance; and, for reference, the dense readers of Part 1 over 512 cache entries.
/// </summary>
public static class V05_AtomChoice
{
    private const ulong Seed = 705;
    public const int T = 16, Stored = 512, Queries = 1000, D = 128;
    public const double Theta = 1.5, Sigma = 0.5, WithinBeta = 10.0;
    static readonly double[] Shape = Enumerable.Range(0, T).Select(t => Math.Sin(Math.PI * (t + 1) / (T + 1))).ToArray();

    public static (IReadOnlyList<double> Y, int Mode) Trajectory(Rng rng, IReadOnlyList<double> amps, IReadOnlyList<double> freq)
    {
        var (mode, r1) = rng.NextCategorical(freq);
        var (ga, r2) = r1.NextGaussian();
        double amp = amps[mode] * (1 + 0.1 * ga);
        var y = new double[T];
        var r = r2;
        for (int t = 0; t < T; t++) { var (g, nr) = r.NextGaussian(); r = nr; y[t] = amp * Shape[t] + 0.02 * g; }
        return (y, mode);
    }

    public static bool Collides(IReadOnlyList<double> y) => Enumerable.Range(5, 6).Any(t => Math.Abs(y[t]) < 0.3);

    /// <summary>RMS distance to the nearest valid trajectory: a mode's shape with amplitude within 0.7–1.3 of that mode's.</summary>
    public static double OffManifold(IReadOnlyList<double> y, IReadOnlyList<double> amps)
    {
        double ss = Shape.Sum(v => v * v), proj = Lin.Dot(y, Shape) / ss;
        return amps.Min(A =>
        {
            double lo = Math.Min(0.7 * A, 1.3 * A), hi = Math.Max(0.7 * A, 1.3 * A);
            double a = Math.Clamp(proj, lo, hi);
            return Math.Sqrt(y.Select((v, t) => (v - a * Shape[t]) * (v - a * Shape[t])).Sum() / T);
        });
    }

    public static int ModeOf(IReadOnlyList<double> y, IReadOnlyList<double> amps)
    {
        double proj = Lin.Dot(y, Shape) / Shape.Sum(v => v * v);
        return Enumerable.Range(0, amps.Count).OrderBy(k => Math.Abs(proj - amps[k])).First();
    }

    static double Dist(IReadOnlyList<double> a, IReadOnlyList<double> b) => Math.Sqrt(a.Select((v, t) => (v - b[t]) * (v - b[t])).Sum());

    sealed record Task(string Name, IReadOnlyList<double> Amps, IReadOnlyList<double> Freq);

    public static ExperimentResult Run(Lexicon lex)
    {
        var h = new Dictionary<string, double>();
        var rows = new List<object[]>();
        var tasks = new[] { new Task("two modes", new[] { 1.0, -1.0 }, new[] { 0.5, 0.5 }), new Task("three unequal modes", new[] { 1.0, -1.0, 2.0 }, new[] { 0.6, 0.3, 0.1 }) };
        var growRows = new List<object[]>();
        var exampleRows = new List<IReadOnlyList<object>>();
        foreach (var task in tasks)
        {
            string tk = task.Amps.Count == 2 ? "two" : "three";
            var data = Enumerable.Range(0, Stored).Select(i => Trajectory(Rng.Derive(Seed, (ulong)(task.Amps.Count * 1_000_000 + i)), task.Amps, task.Freq)).ToArray();
            var ys = data.Select(x => x.Y).ToArray();
            var modes = data.Select(x => x.Mode).ToArray();
            var pca = LinearIset.Fit(ys, T);
            var z = ys.Select(y => Bf16.Round(pca.Encode(y))).ToArray();
            IReadOnlyList<double> Decode(IReadOnlyList<double> c) => pca.Decode(c);
            double spacing = ys.Take(200).Select((a, i) => ys.Where((b, j) => j != i).Min(b => Dist(a, b))).Average();
            var share = Enumerable.Range(0, task.Amps.Count).Select(k => modes.Count(m => m == k) / (double)Stored).ToArray();
            h[$"{tk}_spacing"] = spacing;
            for (int k = 0; k < share.Length; k++) h[$"{tk}_stored_share_mode{k}"] = share[k];

            // Product atoms for the cue word (atom 0), in arrival order.
            var atoms = Leader.Train(z.Select(c => ((IReadOnlyList<int>)new[] { 0 }, c)).ToArray(), Theta);
            h[$"{tk}_atoms"] = atoms.Count;
            var atomMode = atoms.Select(a => ModeOf(Decode(a.Mean), task.Amps)).ToArray();
            h[$"{tk}_atom_purity"] = Enumerable.Range(0, Stored).Count(i => atomMode[Enumerable.Range(0, atoms.Count).OrderBy(a => Lin.Dot(Mat.Add(z[i], atoms[a].Mean, -1), Mat.Add(z[i], atoms[a].Mean, -1))).First()] == modes[i]) / (double)Stored;
            var counts = atoms.Select(a => (double)a.Count).ToArray();
            for (int a = 0; a < atoms.Count; a++)
            {
                h[$"{tk}_atom{a}_count"] = atoms[a].Count;
                h[$"{tk}_atom{a}_amplitude"] = Lin.Dot(Decode(atoms[a].Mean), Shape) / Shape.Sum(v => v * v);
                h[$"{tk}_atom{a}_mode"] = atomMode[a];
            }

            // Dense cache of Part 1: keys are the cue as written in each episode's context; values are the codes.
            var code = CharCode.Random(D, Rng.Derive(Seed, 1_000_001));
            var bind = Binder.Create(D, Sym.L + 1, Rng.Derive(Seed, 1_000_002));
            var cue = Mat.Normalize(Layout.Bound("around", code, bind));
            var keys = Enumerable.Range(0, Stored).Select(i => Bf16.Round(Mat.RelNoise(cue, Sigma, Rng.Derive(Seed, 4_000_000UL + (ulong)i)).Value)).ToArray();
            var (cent, asg) = Mat.KMeans(z, task.Amps.Count, Rng.Derive(Seed, 2_000_000UL + (ulong)task.Amps.Count));

            var perQuery = Enumerable.Range(0, Queries).AsParallel().AsOrdered().Select(qi =>
            {
                var r = Rng.Derive(Seed, (ulong)(task.Amps.Count * 10_000_000 + 3_000_000 + qi));
                var outs = new List<(string Name, IReadOnlyList<double> Y)>();
                // Atom readers.
                var mix = new double[T];
                double tot = counts.Sum();
                for (int a = 0; a < atoms.Count; a++) for (int k = 0; k < T; k++) mix[k] += counts[a] / tot * atoms[a].Mean[k];
                outs.Add(("soft read over atoms", Decode(mix)));
                int big = Array.IndexOf(counts, counts.Max());
                outs.Add(("arg-max count", Decode(atoms[big].Mean)));
                var (pick, r1) = r.NextCategorical(counts);
                outs.Add(("atom sampled by count", Decode(atoms[pick].Mean)));
                var (g, r2) = Lin.Gaussians(r1, T);
                var v = atoms[pick].Variance;
                outs.Add(("sampled atom plus residual", Decode(atoms[pick].Mean.Select((m, k) => m + Math.Sqrt(v[k]) * g[k]).ToArray())));
                // Dense readers of Part 1.
                var (q, r3) = Mat.RelNoise(cue, Sigma, r2);
                var s = keys.Select(k => Lin.Dot(q, k)).ToArray();
                IReadOnlyList<double> Blend(IReadOnlyList<double> w, IEnumerable<int> idx)
                {
                    var ids = idx.ToArray(); double tw = ids.Sum(i => w[i]);
                    var m = new double[T];
                    foreach (int i in ids) for (int k = 0; k < T; k++) m[k] += w[i] / tw * z[i][k];
                    return Decode(m);
                }
                var w30 = Lin.Softmax(s.Select(x => 30.0 * x).ToArray());
                outs.Add(("dense soft read, β = 30", Blend(w30, Enumerable.Range(0, Stored))));
                outs.Add(("dense hard top-1", Decode(z[Array.IndexOf(s, s.Max())])));
                var wb = Lin.Softmax(s.Select(x => WithinBeta * x).ToArray());
                var mass = Enumerable.Range(0, task.Amps.Count).Select(c => Enumerable.Range(0, Stored).Where(i => asg[i] == c).Sum(i => wb[i])).ToArray();
                var (mpick, _) = r3.NextCategorical(mass);
                outs.Add(("dense sampled mode, then soft within", Blend(wb, Enumerable.Range(0, Stored).Where(i => asg[i] == mpick))));
                return outs;
            }).ToArray();

            if (task.Amps.Count == 2)
            {
                // Decoded outputs for the figure: one stored execution of each mode, the first query's reads, eight sampled reads.
                int li = Array.IndexOf(modes, 0), ri = Array.IndexOf(modes, 1);
                string[] show = { "soft read over atoms", "arg-max count", "dense soft read, β = 30" };
                exampleRows.AddRange(Enumerable.Range(0, T).Select(t => (IReadOnlyList<object>)new object[] { t, ys[li][t], ys[ri][t] }
                    .Concat(show.Select(n => (object)perQuery[0].First(o => o.Name == n).Y[t]))
                    .Concat(Enumerable.Range(0, 8).Select(qi => (object)perQuery[qi].First(o => o.Name == "sampled atom plus residual").Y[t])).ToArray()));
            }
            foreach (var name in perQuery[0].Select(o => o.Name))
            {
                var outY = perQuery.Select(o => o.First(x => x.Name == name).Y).ToArray();
                double coll = outY.Average(y => Collides(y) ? 1.0 : 0);
                double off = Math.Sqrt(outY.Average(y => { double e = OffManifold(y, task.Amps); return e * e; }));
                double nov = outY.Take(200).Average(y => ys.Min(b => Dist(y, b))) / spacing;
                var outShare = Enumerable.Range(0, task.Amps.Count).Select(k => outY.Count(y => ModeOf(y, task.Amps) == k) / (double)Queries).ToArray();
                double tv = 0.5 * outShare.Zip(share).Sum(x => Math.Abs(x.First - x.Second));
                double distinct = outY.Select(y => string.Join(",", y.Select(x => Math.Round(x, 9)))).Distinct().Count();
                rows.Add(new object[] { task.Name, name, coll, off, nov, outShare[0], tv, distinct });
                string key = $"{tk}_{name.Replace(" ", "_").Replace(",", "").Replace("=", "").Replace("-", "")}";
                h[$"{key}_collision"] = coll; h[$"{key}_offmanifold"] = off; h[$"{key}_novelty"] = nov; h[$"{key}_mode0_share"] = outShare[0]; h[$"{key}_mode_tv"] = tv; h[$"{key}_distinct_outputs"] = distinct;
            }

            // Inventory against the number of executions.
            foreach (int n in new[] { 16, 32, 64, 128, 256, 512 })
            {
                var a = Leader.Train(z.Take(n).Select(c => ((IReadOnlyList<int>)new[] { 0 }, c)).ToArray(), Theta);
                double atomBytes = a.Count * (2 + 2 * T * 2 + 4);
                growRows.Add(new object[] { task.Name, n, a.Count, atomBytes, n, n * 2.0 * D * 2 });
                h[$"{tk}_grow_N{n}_atoms"] = a.Count;
            }
        }
        var table = Table.Of("atom_choice", new[] { "task", "reader", "collision_rate", "off_manifold_rms", "nearest_stored_over_spacing", "share_mode0_left", "mode_share_tv", "distinct_outputs_of_1000" }, rows);
        var grow = Table.Of("inventory", new[] { "task", "executions", "atoms", "atom_bytes", "dense_entries", "dense_kv_bytes_head_layer" }, growRows);
        var examples = Table.Of("examples", new[] { "step", "stored_left", "stored_right", "soft_over_atoms", "argmax_count", "dense_soft_beta30" }.Concat(Enumerable.Range(0, 8).Select(k => $"sampled_residual_{k}")).ToArray(), exampleRows);
        return new ExperimentResult("V05", "Choosing an atom", new[] { table, grow, examples }, h);
    }
}
