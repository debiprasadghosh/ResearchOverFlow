"""Line-for-line Python ports of the laboratory's generator, lexicon sampling, Step 1 histories, letter channel, leader
clustering and motor stream (for the cross-check). The MessagePack reader is independent of the C# one."""
import gzip, math
M64 = (1 << 64) - 1


class Rng:
    G = 0x9E3779B97F4A7C15

    def __init__(self, s): self.s = s & M64

    @staticmethod
    def derive(seed, stream):
        r = Rng((seed ^ ((stream * 0xD1B54A32D192ED03) & M64)) & M64)
        r.u64(); return r

    def u64(self):
        self.s = (self.s + Rng.G) & M64
        z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return z ^ (z >> 31)

    def double(self): return (self.u64() >> 11) * (1.0 / 9007199254740992.0)

    def int(self, n):
        v = int(self.double() * n); return n - 1 if v >= n else v

    def int_except(self, n, exclude):
        v = self.int(n - 1); return v + 1 if v >= exclude else v

    def uniform(self, lo, hi): return lo + (hi - lo) * self.double()

    def gauss(self):
        u1 = self.double(); u2 = self.double()
        return math.sqrt(-2.0 * math.log(1.0 - u1)) * math.cos(2.0 * math.pi * u2)

    def categorical(self, w):
        total = 0.0
        for x in w: total += x
        target = self.double() * total; acc = 0.0
        for i, x in enumerate(w):
            acc += x
            if target < acc: return i
        return len(w) - 1


# ---------------- MessagePack (minimal, independent) and the lexicon ----------------
def unpack(b):
    def rdv(i):
        t = b[i]
        if t <= 0x7f: return t, i + 1
        if 0x80 <= t <= 0x8f: return rmap(i + 1, t & 0x0f)
        if 0x90 <= t <= 0x9f: return rarr(i + 1, t & 0x0f)
        if 0xa0 <= t <= 0xbf: n = t & 0x1f; return b[i + 1:i + 1 + n].decode(), i + 1 + n
        if t == 0xd9: n = b[i + 1]; return b[i + 2:i + 2 + n].decode(), i + 2 + n
        if t == 0xda: n = int.from_bytes(b[i + 1:i + 3], "big"); return b[i + 3:i + 3 + n].decode(), i + 3 + n
        if t == 0xdc: return rarr(i + 3, int.from_bytes(b[i + 1:i + 3], "big"))
        if t == 0xdd: return rarr(i + 5, int.from_bytes(b[i + 1:i + 5], "big"))
        if t == 0xcc: return b[i + 1], i + 2
        if t == 0xcd: return int.from_bytes(b[i + 1:i + 3], "big"), i + 3
        raise ValueError(hex(t))

    def rarr(i, n):
        out = []
        for _ in range(n):
            v, i = rdv(i); out.append(v)
        return out, i

    def rmap(i, n):
        out = {}
        for _ in range(n):
            k, i = rdv(i); v, i = rdv(i); out[k] = v
        return out, i
    return rdv(0)[0]


PREFIXES = ["re", "un", "dis", "pre", "mis", "over", "out", "sub", "inter", "non"]
SUFFIXES = ["s", "es", "ed", "d", "ing", "er", "ers", "est", "ly", "ness", "ment", "able", "ful", "less"]


class Lexicon:
    def __init__(self, path, max_words=50000):
        root = unpack(gzip.open(path).read())
        allw = [(w, 10.0 ** (-(i - 1) / 100.0)) for i in range(1, len(root)) for w in root[i]]
        kept = [x for x in allw if len(x[0]) > 0 and all("a" <= c <= "z" for c in x[0]) and len(x[0]) <= 16][:max_words]
        mass = 0.0
        for _, f in kept: mass += f
        self.words = [w for w, _ in kept]
        self.prob = [f / mass for _, f in kept]
        self.cdf = []
        acc = 0.0
        for p in self.prob: acc += p; self.cdf.append(acc)
        self.index = {w: i for i, w in enumerate(self.words)}
        self.anagrams = {}
        for i, w in enumerate(self.words): self.anagrams.setdefault("".join(sorted(w)), []).append(i)

    def sample(self, r):
        target = r.double() * self.cdf[-1]
        lo, hi = 0, len(self.cdf) - 1
        while lo < hi:
            mid = (lo + hi) // 2
            if self.cdf[mid] > target: hi = mid
            else: lo = mid + 1
        return lo

    def anagrams_of(self, w): return [self.words[i] for i in self.anagrams.get("".join(sorted(w)), []) if self.words[i] != w]

    def one_edit(self, w):
        found = set()
        def tr(s):
            if len(s) > 0 and s != w and s in self.index: found.add(s)
        for i in range(len(w)):
            tr(w[:i] + w[i + 1:])
            for c in "abcdefghijklmnopqrstuvwxyz":
                if c != w[i]: tr(w[:i] + c + w[i + 1:])
            if i + 1 < len(w) and w[i] != w[i + 1]: tr(w[:i] + w[i + 1] + w[i] + w[i + 2:])
        for i in range(len(w) + 1):
            for c in "abcdefghijklmnopqrstuvwxyz": tr(w[:i] + c + w[i:])
        return sorted(found, key=self.index.get)

    def affix_relatives(self, w):
        found = set()
        for s in SUFFIXES:
            if w + s in self.index: found.add(w + s)
            if w.endswith(s) and len(w) - len(s) >= 3 and w[:-len(s)] in self.index: found.add(w[:-len(s)])
        for p in PREFIXES:
            if p + w in self.index: found.add(p + w)
            if w.startswith(p) and len(w) - len(p) >= 3 and w[len(p):] in self.index: found.add(w[len(p):])
        found.discard(w)
        return sorted([x for x in found if len(x) <= 16], key=self.index.get)

    def neighbours(self, w, cap):
        out = []
        for x in self.anagrams_of(w) + self.affix_relatives(w) + self.one_edit(w):
            if x != w and x not in out: out.append(x)
        return out[:cap]


def sample_tokens(lex, n, r): return [lex.words[lex.sample(r)] for _ in range(n)]


def make_trials(lex, history, count, seed, max_rank=20000):
    trials = []
    r = Rng.derive(seed, 1)
    while len(trials) < count:
        w = lex.words[r.int(min(max_rank, len(lex.words)))]
        if len(w) < 3 or len(w) > 12: continue
        nb = lex.neighbours(w, 8)
        if len(nb) < 2: continue
        tokens = [w] + nb
        rr = Rng.derive(seed, 100 + len(trials))
        while len(tokens) < history: tokens.append(lex.words[lex.sample(rr)])
        trials.append((w, nb, list(dict.fromkeys(tokens)), tokens))
    return trials


# ---------------- letter-confusion channel ----------------
SETS = ["aou", "bdp", "ces", "fhk", "gqy", "ijl", "mnr", "txz", "vw"]
SET_OF = {c: k for k, s in enumerate(SETS) for c in s}


def pattern(w): return "".join(chr(65 + SET_OF[c]) for c in w)


def observe(w, eps, r):
    o = list(w)
    for j in range(len(o)):
        if r.double() >= eps: continue
        s = SETS[SET_OF[o[j]]]
        o[j] = s[r.int_except(len(s), s.index(o[j]))]
    return "".join(o)


def posterior(obs, eps, lex, index):
    cand = index[pattern(obs)]
    def lik(w):
        l = 1.0
        for a, b in zip(obs, w): l *= (1 - eps) if a == b else eps / (len(SETS[SET_OF[b]]) - 1)
        return l
    w = [lex.prob[i] * lik(lex.words[i]) for i in cand]
    order = sorted([k for k in range(len(cand)) if w[k] > 0], key=lambda k: (-w[k], cand[k]))
    s = 0.0
    for k in order: s += w[k]
    return [cand[k] for k in order], [w[k] / s for k in order]


# ---------------- one-pass leader clustering (online DP-means) inside word tuples ----------------
def leader_train(tuples, theta):
    atoms = []                    # [key, mean(list), count]
    by_key = {}
    t2 = theta * theta
    for key, z in tuples:
        ids = by_key.setdefault(key, [])
        best, bd = -1, float("inf")
        for a in ids:
            m = atoms[a][1]
            d2 = sum((z[k] - m[k]) ** 2 for k in range(len(z)))
            if d2 < bd: bd, best = d2, a
        if best >= 0 and bd <= t2:
            n = atoms[best][2] + 1
            atoms[best][1] = [atoms[best][1][k] + (z[k] - atoms[best][1][k]) / n for k in range(len(z))]
            atoms[best][2] = n
        else:
            atoms.append([key, list(z), 1]); ids.append(len(atoms) - 1)
    return atoms


# ---------------- motor stream (as in Part 1) ----------------
DOF, FREQS, PERIOD = 7, 4, 32
JITTER, NOISE, CRATE, CSIZE, AMPSD = 0.1, 0.005, 1.0 / 32, 0.08, 0.3


def make_skill(k, seed):
    r = Rng.derive(seed, 10000 + k); amp = []; ph = []
    for _ in range(DOF * FREQS):
        g = r.gauss(); p = r.uniform(0, 2 * math.pi); amp.append(AMPSD * g); ph.append(p)
    return amp, ph


def prototype(skill, L):
    amp, ph = skill; x = [0.0] * (DOF * L)
    for j in range(DOF):
        for t in range(L):
            v = 0.0
            for f in range(1, FREQS + 1):
                a = amp[j * FREQS + f - 1]; p = ph[j * FREQS + f - 1]
                v += a / f * (math.sin(2 * math.pi * f * t / PERIOD + p) - math.sin(p))
            x[j * L + t] = v
    return x


def execute(proto, L, r):
    g = r.gauss(); a = 1 + JITTER * g
    x = [a * proto[i] + NOISE * r.gauss() for i in range(DOF * L)]
    contacts = 0
    for t in range(L):
        if r.double() >= CRATE: continue
        contacts += 1
        for j in range(DOF):
            sz = r.gauss()
            for tt in range(t, L):
                x[j * L + tt] += CSIZE * sz * (1.0 if tt - t < 2 else math.exp(-(tt - t - 2) / 4.0))
    return x, contacts


def rms(a, b): return math.sqrt(sum((p - q) ** 2 for p, q in zip(a, b)) / len(a))
