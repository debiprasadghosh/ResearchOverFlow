"""Figures for the Part 2 paper, drawn from the C# laboratory outputs (plotting only, no computation)."""
import csv, json, os
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle
from matplotlib.ticker import NullFormatter, NullLocator

_ROOT = Path(__file__).resolve().parent.parent
OUT = os.environ.get("VX_OUT", str(_ROOT / "out")); FIG = os.environ.get("VX_FIGS", str(_ROOT / "figs"))
os.makedirs(FIG, exist_ok=True)
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, VIOLET = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6"
INK, INK2, MUTED, GRID = "#1f1f1f", "#52514e", "#8a8984", "#e4e3df"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9, "axes.edgecolor": MUTED,
    "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": GRID,
    "grid.linewidth": 0.6, "axes.axisbelow": True, "axes.spines.top": False, "axes.spines.right": False,
    "legend.frameon": False, "savefig.dpi": 220, "lines.linewidth": 2, "text.color": INK})
H = json.load(open(f"{OUT}/headlines.json"))
def rd(n): return list(csv.DictReader(open(f"{OUT}/{n}.csv")))
def fl(x): return float(x)
def save(f, n):
    for a in f.axes:
        if a.get_xscale() == "log": a.xaxis.set_minor_locator(NullLocator()); a.xaxis.set_minor_formatter(NullFormatter())
        if a.get_yscale() == "log": a.yaxis.set_minor_formatter(NullFormatter())
    f.savefig(f"{FIG}/{n}.png", bbox_inches="tight"); plt.close(f)

# ---------------- Figure 1: the hybrid cache with sparse word records ----------------
fig, ax = plt.subplots(figsize=(7.0, 3.9)); ax.set_axis_off(); ax.set_xlim(0, 13.2); ax.set_ylim(0.15, 7.45)
def box(x, y, w, h, title, lines, ec=INK2, fc="white", lw=1.1):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.12", fc=fc, ec=ec, lw=lw))
    ax.text(x + w / 2, y + h - 0.33, title, ha="center", va="center", fontsize=7.6, weight="bold", color=INK)
    for i, s_ in enumerate(lines):
        ax.text(x + w / 2, y + h - 0.72 - 0.33 * i, s_, ha="center", va="center", fontsize=6.4, color=INK2)
def arrow(x0, y0, x1, y1, col=MUTED):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0), arrowprops=dict(arrowstyle="-|>", color=col, lw=1.1, shrinkA=0, shrinkB=0))
box(0.1, 5.55, 3.0, 1.75, "Fixed primitives", ["26 letters, PAD, EOS", "one vector e(p) each", "(28 vectors per head)"], ec=BLUE)
box(0.1, 3.25, 3.0, 2.0, "Dynamic word atoms", ["S(a) = (D₁, …, D₁₆)", "Dⱼ sparse over primitives", "exact word: one-hot slots", "soft atom: several letters"], ec=BLUE)
box(3.4, 4.45, 3.0, 2.85, "Word token: record", ["sparse code c over atoms", "s entries × 3 bytes", "(atom index, coefficient)", "shared by all heads", "identity = argmax c"], ec=BLUE)
box(0.1, 0.95, 3.0, 2.0, "Body modes", ["7 joints at 50 steps/s", "motor characters", "chunks of 8 steps"], ec=ORANGE)
box(3.4, 0.95, 3.0, 3.15, "Chunk token: ISET", ["linear ISET code (d = 128)", "dense: 512 B per head", "and layer", "+ raw characters (28 B)", "+ version, write error"], ec=ORANGE)
arrow(3.1, 6.4, 3.4, 6.4); arrow(3.1, 4.3, 3.4, 5.2); arrow(3.1, 1.95, 3.4, 1.95)
ax.text(7.6, 7.2, "One cache", ha="center", va="center", fontsize=7.6, weight="bold")
ax.add_patch(FancyBboxPatch((6.7, 0.95), 1.8, 5.95, boxstyle="round,pad=0.02,rounding_size=0.12", fc="#f7f6f3", ec=INK2, lw=1.1))
seq = "WBBWBBBWBBWBBBWBBWBB"
for i, c in enumerate(seq):
    x0, y0 = 6.86 + (i % 4) * 0.39, 6.25 - (i // 4) * 0.98
    if c == "W": ax.add_patch(Rectangle((x0 + 0.08, y0 + 0.36), 0.16, 0.2, fc=BLUE, ec="white", lw=0.8))
    else: ax.add_patch(Rectangle((x0, y0), 0.31, 0.62, fc=ORANGE, ec="white", lw=1.0, alpha=0.88))
ax.add_patch(Rectangle((6.86, 1.2), 0.16, 0.16, fc=BLUE, ec="none")); ax.text(7.07, 1.28, "record", va="center", fontsize=6.0, color=INK2)
ax.add_patch(Rectangle((7.8, 1.14), 0.14, 0.28, fc=ORANGE, ec="none")); ax.text(7.99, 1.28, "chunk", va="center", fontsize=6.0, color=INK2)
arrow(6.4, 5.9, 6.7, 5.9); arrow(6.4, 2.5, 6.7, 2.5)
box(8.85, 5.15, 4.3, 2.15, "Read", ["words: table U[j, p] = qⱼ · e(p), then", "every record exactly by lookups", "chunks: typed screen, step-slot rerank", "per-type normalized distance"], ec=VIOLET)
box(8.85, 2.95, 4.3, 1.95, "Associate", ["counted product atoms from mixed", "tuples: verb code, object code,", "mean ISET code μ, count n, variance"], ec=VIOLET)
box(8.85, 0.95, 4.3, 1.75, "Act", ["choose an atom: sample ∝ n", "decode μ (+ residual); the fast", "loop corrects at actuator rate"], ec=VIOLET)
arrow(8.5, 6.2, 8.85, 6.2); arrow(8.5, 3.9, 8.85, 3.9); arrow(8.5, 1.8, 8.85, 1.8)
ax.text(6.6, 0.42, "Part 2: word entries become sparse word-Vocabucapillary records; chunk entries stay dense ISET vectors.", ha="center", va="center", fontsize=6.6, color=INK2, style="italic")
save(fig, "fig1_hybrid_cache")

# ---------------- Figure 2: accounting ----------------
st = rd("V00_storage"); qm = rd("V00_query_macs")
fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.6), gridspec_kw={"width_ratios": [1, 1.25]})
ax = axes[0]
rowsm = [r for r in st if r["horizon"] == "one minute" and r["heads"] == "1"]
labs = ["dense word keys\n(Part 1)", "records\ns = 1", "records\ns = 4"]
wb = [(fl(r["word_bytes"]) + fl(r["atom_inventory_bytes"])) / 1000 for r in rowsm]; cb = [fl(r["chunk_bytes"]) / 1000 for r in rowsm]
ax.bar(range(3), cb, color=ORANGE, width=0.6, label="chunk tokens", edgecolor="white", linewidth=2)
ax.bar(range(3), wb, bottom=cb, color=BLUE, width=0.6, label="word tokens", edgecolor="white", linewidth=2)
for i in range(3): ax.text(i, cb[i] + wb[i] + 6, f"{wb[i]:.1f} kB" if wb[i] < 10 else f"{wb[i]:.0f} kB", ha="center", va="bottom", fontsize=7, color=INK2)
ax.set_xticks(range(3)); ax.set_xticklabels(labs, fontsize=7.2); ax.set_ylabel("kB per head and layer"); ax.set_ylim(0, 320)
ax.set_title("one minute: 150 words, 375 chunks"); ax.legend(loc="upper right", fontsize=7)
ax = axes[1]
M = [fl(r["word_tokens_M"]) for r in qm]
for col, lab, c, ls in (("dense_scan", "dense scan, one key per token", MAGENTA, "-"), ("atom_key_table", "atom-key table (G·d + M)", AQUA, (0, (4, 2))), ("primitive_table", "primitive table (448·d + 16·G + M)", BLUE, "-")):
    ax.plot(M, [fl(r[col]) for r in qm], marker="o", ms=3.4, color=c, ls=ls, label=lab)
be = H["V00.break_even_tokens_primitive_table"]
ax.axvline(be, color=MUTED, ls=":", lw=1.2); ax.text(be * 1.12, 2.2e6, f"break-even\n{be:.0f} tokens", fontsize=6.8, color=INK2, va="center")
ax.set_xscale("log", base=2); ax.set_yscale("log"); ax.set_xticks(M); ax.set_xticklabels(["64", "256", "1K", "4K", "16K", "64K"])
ax.set_xlabel("word tokens in the history M"); ax.set_ylabel("multiply-adds per word query"); ax.set_title("cost of one word query (d = 128)")
ax.legend(loc="lower right", fontsize=6.4)
fig.tight_layout(); save(fig, "fig2_accounting")

# ---------------- Figure 3: word records under uncertain observation ----------------
uo = rd("V02_uncertain_observation")
eps = [0.1, 0.2, 0.3]
def uv(v, e, col): return fl(next(r[col] for r in uo if r["stored_as"] == v and fl(r["letter_error_eps"]) == e))
V = ["observed letters (one new atom)", "MAP word (s = 1)", "top 2 (s = 2)", "top 4, 4-bit coefficients", "full posterior", "slot marginals (one new soft atom)"]
lines = [(V[0], "observed letters", MAGENTA, "-", "s"), (V[1], "MAP word, s = 1", YELLOW, "-", "o"), (V[2], "top 2, s = 2", AQUA, "-", "o"),
         (V[3], "top 4, 4-bit coefficients", VIOLET, (0, (4, 2)), "^"), (V[4], "full posterior (= soft atom)", BLUE, "-", "o")]
fig, axes = plt.subplots(1, 3, figsize=(6.9, 2.55))
for v, lab, c, ls, mk in lines:
    axes[0].plot(eps, [uv(v, e, "target_found") for e in eps], marker=mk, ms=3.6, color=c, ls=ls, label=lab)
axes[0].set_title("target found in 256 tokens"); axes[0].set_ylim(0.45, 1.0)
for v, lab, c, ls, mk in ((V[0], "observed letters", MAGENTA, "-", "s"), (V[1], "records (argmax atom)", BLUE, "-", "o"), (V[5], "soft atom (slot argmax)", AQUA, (0, (4, 2)), "^")):
    axes[1].plot(eps, [uv(v, e, "token_read_correctly") for e in eps], marker=mk, ms=3.6, color=c, ls=ls, label=lab)
axes[1].set_title("token read correctly"); axes[1].set_ylim(0.2, 1.02); axes[1].legend(loc="lower left", fontsize=6.6)
w = 0.035
for k, (v, lab, c) in enumerate(((V[0], "observed letters (non-words)", MAGENTA), (V[5], "soft atoms (not one-hot)", AQUA))):
    vals = [uv(v, e, "new_atoms_per_history") for e in eps]
    axes[2].bar([e + (k - 0.5) * w for e in eps], vals, width=w * 0.9, color=c, label=lab)
axes[2].text(0.2, 158, "records over lexicon atoms: none", ha="center", fontsize=6.4, color=INK2)
axes[2].set_title("new atoms per 256-token history"); axes[2].legend(loc="upper left", fontsize=6.4); axes[2].set_ylim(0, 200)
for a in axes: a.set_xticks(eps); a.set_xlabel("letter error rate ε")
fig.tight_layout()
h0, l0 = axes[0].get_legend_handles_labels()
fig.legend(h0, l0, loc="upper center", ncol=5, fontsize=6.8, bbox_to_anchor=(0.5, 0.02))
save(fig, "fig3_word_records")

# ---------------- Figure 4: depth and cacheless aggregates ----------------
dep = rd("V03_depth"); agg = rd("V03_cacheless")
betas = [fl(r["context_mass_ratio_beta"]) for r in dep]
xs = list(range(len(betas))); xl = ["0", "¼", "½", "1", "2", "4", "8", "16"]
fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.7), gridspec_kw={"width_ratios": [1.45, 1]})
ax = axes[0]
ax.plot(xs, [fl(r["record_identity_argmax"]) for r in dep], color=BLUE, marker="o", ms=3.6, label="record: identity by argmax")
ax.plot(xs, [fl(r["dense_key_spelled_by_unbinding"]) for r in dep], color=MAGENTA, marker="s", ms=3.6, label="decoded dense key: spelled by unbinding")
ax.plot(xs, [fl(r["retrieval_full_record"]) for r in dep], color=AQUA, marker="o", ms=3.6, label="retrieval (record = decoded key)")
ax.plot(xs, [fl(r["s4_retrieval"]) for r in dep], color=VIOLET, ls=(0, (4, 2)), marker="^", ms=3.6, label="retrieval after truncation to s = 4")
ax.set_xticks(xs); ax.set_xticklabels(xl); ax.set_ylim(-0.03, 1.05)
ax.set_xlabel("context mass mixed into the record, β")

sec = [fl(r["decoded_context_to_self_l2"]) for r in dep]
ax2 = ax.twiny(); ax2.set_xlim(ax.get_xlim()); ax2.set_xticks(xs); ax2.set_xticklabels([f"{v:.2f}".rstrip("0").rstrip(".") for v in sec], fontsize=6.4)
ax2.set_xlabel("decoded context-to-self norm ratio", fontsize=7); ax2.grid(False); ax2.spines["top"].set_visible(True); ax2.spines["top"].set_color(MUTED)
ax.legend(loc="lower left", fontsize=6.4, bbox_to_anchor=(0.0, 0.02))
ax = axes[1]
a25 = [r for r in agg if r["temperature_tau"] == "0.25"]
names = ["KV cache\n(256 tokens)", "per-atom\naggregate", "slot–primitive\naggregate"]
vals = [fl(r["value_of_present_word_found"]) for r in a25]
aucs = [float("nan") if r["presence_auc_vs_recombination_probes"] == "NaN" else fl(r["presence_auc_vs_recombination_probes"]) for r in a25]
ax.bar([i - 0.18 for i in range(3)], vals, width=0.34, color=BLUE, label="value of the word found")
ax.bar([i + 0.18 for i in (1, 2)], aucs[1:], width=0.34, color=AQUA, label="present vs recombined: AUC")
ax.axhline(0.5, color=MUTED, ls=":", lw=1.1)
for i, v in enumerate(vals): ax.text(i - 0.18, v + 0.02, f"{v:.2f}", ha="center", fontsize=6.6, color=INK2)
for i in (1, 2): ax.text(i + 0.18, aucs[i] + 0.02, f"{aucs[i]:.2f}", ha="center", fontsize=6.6, color=INK2)
ax.set_xticks(range(3)); ax.set_xticklabels(names, fontsize=7); ax.set_ylim(0, 1.42); ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0]); ax.set_title("cacheless states (τ = 0.25)")
ax.legend(loc="upper center", fontsize=6.4)
fig.tight_layout(); save(fig, "fig4_depth_cacheless")

# ---------------- Figure 5: association atoms ----------------
ex = rd("V04_experience"); th = rd("V04_threshold")
Es = [1, 2, 4, 8, 16, 32]
def ev(m, E, col): return fl(next(r[col] for r in ex if r["method"] == m and r["executions_per_pair_E"] == str(E)))
fig, axes = plt.subplots(1, 3, figsize=(6.9, 2.5))
for m, lab, c, ls, mk in (("product atoms", "product atoms", BLUE, "-", "o"), ("densified atoms", "densified atoms", AQUA, (0, (4, 2)), "^"), ("role slots (Part 1)", "role slots (Part 1)", MAGENTA, "-", "s")):
    axes[0].plot(Es, [ev(m, E, "plan_rms_vs_prototype") for E in Es], color=c, ls=ls, marker=mk, ms=3.4, label=lab)
    axes[1].plot(Es, [ev(m, E, "inventory_bytes") / 1000 for E in Es], color=c, ls=ls, marker=mk, ms=3.4, label=lab)
axes[0].plot(Es, [H[f"V04.exp_E{E}_execution_floor"] for E in Es], color=MUTED, ls=":", lw=1.4, label="one execution vs prototype")
axes[0].set_title("planning error (rad RMS)"); axes[0].set_ylim(0, 0.045)
axes[1].set_yscale("log"); axes[1].set_title("inventory (kB)"); axes[1].set_yticks([10, 100, 1000, 10000]); axes[1].set_yticklabels(["10", "100", "1,000", "10,000"])
for a in axes[:2]: a.set_xscale("log", base=2); a.set_xticks(Es); a.set_xticklabels([str(E) for E in Es]); a.set_xlabel("executions per pair E")
thetas = sorted({fl(r["threshold_theta"]) for r in th})
for m, lab, c, ls, mk in (("product atoms", "product atoms", BLUE, "-", "o"), ("densified atoms", "densified atoms", AQUA, (0, (4, 2)), "^")):
    axes[2].plot(thetas, [fl(next(r["describe_both_words"] for r in th if r["method"] == m and fl(r["threshold_theta"]) == t)) for t in thetas], color=c, ls=ls, marker=mk, ms=3.4, label=lab)
axes[2].set_title("description vs threshold θ"); axes[2].set_xlabel("clustering threshold θ"); axes[2].set_ylim(-0.03, 1.05)
fig.tight_layout()
h0, l0 = axes[0].get_legend_handles_labels()
fig.legend(h0, l0, loc="upper center", ncol=4, fontsize=6.8, bbox_to_anchor=(0.5, 0.02))
save(fig, "fig5_association_atoms")

# ---------------- Figure 6: choosing an atom ----------------
exm = rd("V05_examples"); ch = rd("V05_atom_choice")
t = [int(r["step"]) for r in exm]
fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.6), gridspec_kw={"width_ratios": [1.2, 1]})
ax = axes[0]
ax.add_patch(Rectangle((5, -0.3), 5, 0.6, fc="#f3d9cf", ec="none", alpha=0.8)); ax.text(7.5, 0, "obstacle band", ha="center", va="center", fontsize=6.4, color=INK2)
for k in range(8): ax.plot(t, [fl(r[f"sampled_residual_{k}"]) for r in exm], color=BLUE, lw=0.9, alpha=0.75, label="sampled atom + residual (8 reads)" if k == 0 else None)
ax.plot(t, [fl(r["stored_left"]) for r in exm], color=INK2, lw=1.0, ls=":", label="stored executions")
ax.plot(t, [fl(r["stored_right"]) for r in exm], color=INK2, lw=1.0, ls=":")
ax.plot(t, [fl(r["soft_over_atoms"]) for r in exm], color=MAGENTA, lw=2, label="soft read over atoms")
ax.plot(t, [fl(r["argmax_count"]) for r in exm], color=YELLOW, lw=2, ls=(0, (4, 2)), label="arg-max count")
ax.set_xlabel("step"); ax.set_ylabel("lateral position"); ax.set_title("two-way obstacle: decoded reads"); ax.set_ylim(-1.45, 2.25); ax.set_xticks([0, 5, 10, 15]); ax.set_yticks([-1, 0, 1])
ax.legend(loc="upper center", fontsize=6.2, ncol=2)
ax = axes[1]
three = [r for r in ch if r["task"] == "three unequal modes"]
stored = [H["V05.three_stored_share_mode0"], H["V05.three_stored_share_mode1"], H["V05.three_stored_share_mode2"]]
# Mode shares of reads are derived from the share of mode 0 and the total variation in the table; plot mode 0 share and TV.
readers = [("arg-max count", "arg-max\ncount", YELLOW), ("atom sampled by count", "sampled\nby count", BLUE), ("dense sampled mode, then soft within", "dense, mode\nsampled", AQUA), ("soft read over atoms", "soft over\natoms", MAGENTA)]
tvs = [fl(next(r["mode_share_tv"] for r in three if r["reader"] == n)) for n, _, _ in readers]
ax.bar(range(len(readers)), tvs, color=[c for _, _, c in readers], width=0.6)
for i, v in enumerate(tvs): ax.text(i, v + 0.012, f"{v:.3f}", ha="center", fontsize=6.8, color=INK2)
ax.set_xticks(range(len(readers))); ax.set_xticklabels([l for _, l, _ in readers], fontsize=6.8)
ax.set_ylim(0, 0.5); ax.set_title("three modes, shares 0.6 / 0.3 / 0.1"); ax.set_ylabel("mode shares: total variation")
fig.tight_layout(); save(fig, "fig6_atom_choice")
print("figures written to", FIG)
