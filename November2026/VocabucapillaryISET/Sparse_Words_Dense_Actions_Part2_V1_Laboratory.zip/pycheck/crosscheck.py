"""Independent Python cross-check of the Part 2 laboratory (sparse word records, dense ISET chunks, association atoms).

Decodes the wordfreq file with its own MessagePack reader; regenerates with line-for-line ports of the generator the
Heaps counts, the break-even length, the Step 1 histories, the letter-confusion channel and its posteriors, the retrieval
of the MAP and full-posterior records, the record identities under contextual mixing, the association executions and
the obstacle trajectories; and verifies the exact identities (table scores, Jensen bound, pruning, conjunction
blindness) with numpy on independent random draws.
Usage: python3 crosscheck.py [out_folder] [data_file]
"""
import csv, json, math, sys
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import vxport as V

ROOT = Path(__file__).resolve().parent.parent
OUT = sys.argv[1] if len(sys.argv) > 1 else str(ROOT / "out")
DATA = sys.argv[2] if len(sys.argv) > 2 else str(ROOT / "data" / "large_en.msgpack.gz")
H = json.load(open(f"{OUT}/headlines.json"))
rows = []
def check(name, cs, py, tol):
    rows.append((name, cs, py, abs(cs - py), abs(cs - py) <= tol))
    print(f"{'ok ' if abs(cs - py) <= tol else 'BAD'} {name}: C# {cs:.10g}  Py {py:.10g}", flush=True)

lex = V.Lexicon(DATA)
letters = 0.0
for w, p in zip(lex.words, lex.prob): letters += p * len(w)
check("V00 letters per word (frequency-weighted)", H["V00.letters_per_word"], letters, 1e-12)

# ---------- V00: Heaps counts, storage and the break-even length ----------
def distinct(m, reps, stream, seed=700):
    g = lt = 0
    for r in range(reps):
        s = set(V.sample_tokens(lex, m, V.Rng.derive(seed, stream + r)))
        g += len(s); lt += sum(len(w) for w in s)
    return g / reps, lt / reps
for k, (m, reps) in enumerate(((150, 100), (1000, 100), (10000, 20))):
    g, _ = distinct(m, reps, 1_000_000 * (k + 1))
    check(f"V00 distinct words in {m:,} tokens", H[f"V00.heaps_M{m}_distinct"], g, 0)
g, lt = distinct(150, 100, 9_000_000 + 150)
check("V00 distinct words in one minute (150 tokens)", H["V00.minute_distinct_words"], g, 0)
chunks = 375 * (512 + 28.0)
check("V00 one minute, records s = 1: total bytes per head and layer", H["V00.minute_h1_records_s__1_total_bytes"], 150 * 3 + lt + chunks, 1e-6)
check("V00 one minute, dense words: word share", H["V00.minute_h1_dense_word_keys_Part_1_word_share"],
      (150 * 512 + 150 * (letters + 1)) / (150 * 512 + 150 * (letters + 1) + chunks), 1e-12)
be = -1
for m in range(256, 1025, 8):
    g, _ = distinct(m, 40, 30_000_000 + m)
    if 16 * 28 * 128 + 16 * g + m <= 128 * m: be = m; break
check("V00 break-even word tokens, primitive table against a dense scan", H["V00.break_even_tokens_primitive_table"], be, 0)
check("V00 break-even if every word is distinct, 448·d/(d − 17)", H["V00.break_even_tokens_all_distinct"], 448 * 128 / 111, 1e-12)

# ---------- V01: exact identities on independent numpy draws ----------
rng = np.random.default_rng(20261125)
d = 128
E = rng.standard_normal((28, d)); E /= np.linalg.norm(E, axis=1, keepdims=True)
gap = 0.0
for _ in range(200):
    nat = rng.integers(1, 6)
    atoms = []
    for _ in range(nat):
        D_ = np.zeros((16, 28))
        for j in range(16):
            k = rng.integers(1, 4); idx = rng.choice(28, k, replace=False); D_[j, idx] = rng.dirichlet(np.ones(k))
        atoms.append(D_)
    c = rng.dirichlet(np.ones(nat))
    q = rng.standard_normal((16, d))
    U = q @ E.T
    table = sum(ci * np.sum(Da * U) for ci, Da in zip(c, atoms))
    dense = np.sum(q * sum(ci * (Da @ E) for ci, Da in zip(c, atoms)))
    gap = max(gap, abs(table - dense))
check("V01 table score equals dense score (numpy draws, max abs gap below 1e-11)", 0.0, gap if gap > 1e-11 else 0.0, 0)
worst = 0.0; viol = 0
for _ in range(20000):
    k = rng.integers(2, 9); s = rng.uniform(-6, 6, k); c = rng.dirichlet(np.ones(k))
    J = math.log(np.sum(c * np.exp(s))) - float(c @ s); R = s.max() - s.min()
    viol += J < -1e-12 or J > R * R / 8 + 1e-12; worst = max(worst, J / (R * R / 8))
check("V01 Jensen gap inside [0, R²/8] (numpy draws, violations)", H["V01.jensen_violations"], viol, 0)
check("V01 Jensen gap: largest J/(R²/8) at most 1 (C# value)", 1.0, 1.0 if H["V01.jensen_max_ratio"] <= 1 else 0.0, 0)
tvgap = 0.0
for _ in range(5000):
    k = rng.integers(3, 9); c = rng.dirichlet(np.ones(k)); o = np.argsort(c); drop = k // 2
    eta = c[o[:drop]].sum(); ct = np.zeros(k); ct[o[drop:]] = c[o[drop:]] / (1 - eta)
    tvgap = max(tvgap, abs(0.5 * np.abs(c - ct).sum() - eta))
check("V01 pruning: TV(c, c̃) = η (numpy draws, max gap)", 0.0, tvgap if tvgap > 1e-12 else 0.0, 0)
def masses(ws):
    m = np.zeros((16, 28))
    for w in ws:
        for j in range(16): m[j, ord(w[j]) - 97 if j < len(w) else 26] += 1
    return m
check("V01 slot–primitive masses of {cat, dog} and {cog, dat} coincide", H["V01.conj_slot_mass_maxdiff"], float(np.abs(masses(["cat", "dog"]) - masses(["cog", "dat"])).max()), 0)

# ---------- V02: the channel, posteriors and record retrieval ----------
index = {}
for i, w in enumerate(lex.words): index.setdefault(V.pattern(w), []).append(i)
trials = V.make_trials(lex, 256, 1000, 702 + 11)
check("V02 mean distinct words per history", H["V02.mean_distinct_words"], np.mean([len(t[2]) for t in trials]), 1e-12)
def char_code(width, r):
    vecs = []
    for _ in range(28):
        g = [r.gauss() for _ in range(width)]
        n = 0.0
        for x in g: n += x * x
        n = math.sqrt(n); vecs.append([x / n for x in g])
    return np.array(vecs)
Ec = char_code(128, V.Rng.derive(702, 1))
def left(w): return [ord(c) - 97 for c in w] + [26] * (16 - len(w))
for eps in (0.2,):
    wrong = fixd = broke = top2 = supp = ntok = 0
    found_map = found_full = 0
    for i, (target, nb, dist, tok) in enumerate(trials):
        r = V.Rng.derive(702, 2_000_000 + int(eps * 1000) * 10_000 + i)
        obs = [V.observe(w, eps, r) for w in tok]
        post = [V.posterior(o, eps, lex, index) for o in obs]
        truth = [lex.index[w] for w in tok]
        for k in range(len(tok)):
            ok_obs, ok_map = obs[k] == tok[k], post[k][0][0] == truth[k]
            if not ok_obs:
                wrong += 1; fixd += ok_map
            elif not ok_map: broke += 1
            top2 += truth[k] in post[k][0][:2]; supp += len(post[k][0]); ntok += 1
        # Query: the target's concatenated slots with relative noise 0.5.
        rq = V.Rng.derive(702, 3_000_000 + i)
        v = Ec[left(target)].reshape(-1)
        g = np.array([rq.gauss() for _ in range(v.size)])
        q = (v + 0.5 * math.sqrt(float(v @ v) / v.size) * g).reshape(16, 128)
        U = q @ Ec.T
        cache = {}
        def score(w):
            if w not in cache: cache[w] = float(sum(U[j, s] for j, s in enumerate(left(lex.words[w]))))
            return cache[w]
        for full, counter in ((False, "map"), (True, "full")):
            s = np.array([sum(c * score(a) for a, c in zip(*p)) if full else score(p[0][0]) for p in post])
            best = s.max(); ok = all(tok[k] == target for k in np.nonzero(s >= best - 1e-9)[0])
            if counter == "map": found_map += ok
            else: found_full += ok
    ek = f"V02.eps{eps:.1f}"
    check(f"V02 ε = {eps}: observation wrong", H[f"{ek}_obs_wrong"], wrong / ntok, 1e-12)
    check(f"V02 ε = {eps}: MAP corrects a wrong observation", H[f"{ek}_map_fixes"], fixd / wrong, 1e-12)
    check(f"V02 ε = {eps}: MAP overrides a right observation", H[f"{ek}_map_breaks"], broke / (ntok - wrong), 1e-12)
    check(f"V02 ε = {eps}: true word in the top 2", H[f"{ek}_truth_top2"], top2 / ntok, 1e-12)
    check(f"V02 ε = {eps}: posterior support", H[f"{ek}_posterior_support"], supp / ntok, 1e-12)
    check(f"V02 ε = {eps}: target found, MAP record", H[f"{ek}_v1_retrieval"], found_map / len(trials), 0)
    check(f"V02 ε = {eps}: target found, full posterior record", H[f"{ek}_v5_retrieval"], found_full / len(trials), 0)
check("V02 soft atom and full posterior: identical retrieval at every ε (linearity)", 1.0,
      float(all(H[f"V02.eps{e:.1f}_v5_retrieval"] == H[f"V02.eps{e:.1f}_v6_retrieval"] for e in (0.1, 0.2, 0.3))), 0)

# ---------- V03: record identity under contextual mixing ----------
dtr = V.make_trials(lex, 256, 200, 703 + 11)
for beta in (1, 2, 4, 8, 16):
    ok = gu = n = 0
    for i, (target, nb, dist, tok) in enumerate(dtr):
        idx = {w: k for k, w in enumerate(dist)}; a = [idx[w] for w in tok]
        counts = {}
        for x in a: counts[x] = counts.get(x, 0) + 1
        cand = [p for p in range(16, 256) if counts[a[p]] == 1]
        rr = V.Rng.derive(703, 300_000 + i)
        for k in range(len(cand) - 1, 0, -1):
            j = rr.int(k + 1); cand[k], cand[j] = cand[j], cand[k]
        for p in cand[:8]:
            win = {}
            for s_ in range(p - 16, p): win[a[s_]] = win.get(a[s_], 0) + 1
            m = {a[p]: (1 / (1 + beta)) * 1.0}
            for x in sorted(win): m[x] = m.get(x, 0.0) + (beta / (1 + beta)) * (win[x] / 16)
            keys = sorted(m); top = keys[0]
            for x in keys[1:]:
                if m[x] > m[top]: top = x
            ok += top == a[p]; gu += beta * max(win.values()) / 16 < 1; n += 1
    check(f"V03 depth β = {beta}: record identity by argmax", H[f"V03.depth_b{beta}_identity"], ok / n, 1e-12)
    check(f"V03 depth β = {beta}: share with β·max c̄ < 1", H[f"V03.depth_b{beta}_guaranteed"], gu / n, 1e-12)
agg = V.make_trials(lex, 256, 1000, 703 + 12)
check("V03 per-atom cacheless state, floats (G·(1 + 64))", H["V03.agg_tau0.25_per-atom_state_floats"], np.mean([len(t[2]) for t in agg]) * 65, 1e-9)

# ---------- V04: association executions ----------
def unit_pattern(k):
    p = np.array(V.prototype(V.make_skill(k, 404), 8)); return p / math.sqrt(np.mean(p ** 2))
uv = [unit_pattern(1000 + v) for v in range(16)]; uo = [unit_pattern(2000 + o) for o in range(16)]; up = [unit_pattern(3000 + p) for p in range(256)]
def protos(iota):
    a, b = math.sqrt((1 - iota) / 2), math.sqrt(iota)
    return [0.26 * (a * (uv[p // 16] + uo[p % 16]) + b * up[p]) for p in range(256)]
P5 = protos(0.5)
for E in (4, 32):
    st = 100_000_000 * E
    X = [np.array(V.execute(list(P5[i // E]), 8, V.Rng.derive(704, st + 1_000_000 + i))[0]) for i in range(256 * E)]
    floor = math.sqrt(np.mean([V.rms(X[i], P5[i // E]) ** 2 for i in range(len(X))]))
    check(f"V04 E = {E}: execution floor RMS", H[f"V04.exp_E{E}_execution_floor"], floor, 1e-12)
    mean_rms = math.sqrt(np.mean([V.rms(np.mean(X[p * E:(p + 1) * E], axis=0), P5[p]) ** 2 for p in range(256)]))
    check(f"V04 E = {E}: product-atom plan ≈ mean of the pair's executions (relative gap ≤ 5%)", 0.0, abs(H[f"V04.exp_E{E}_product_plan_rms"] / mean_rms - 1), 0.05)
    first_rms = math.sqrt(np.mean([V.rms(X[p * E], P5[p]) ** 2 for p in range(256)]))
    check(f"V04 E = {E}: role-slot plan = first stored execution (relative gap ≤ 1%)", 0.0, abs(H[f"V04.exp_E{E}_role_plan_rms"] / first_rms - 1), 0.01)
for iota in (0.5, 1.0):
    Pa = np.array(protos(iota)).reshape(16, 16, -1)
    add = Pa.mean(axis=1, keepdims=True) + Pa.mean(axis=0, keepdims=True) - Pa.mean(axis=(0, 1), keepdims=True)
    fl = math.sqrt(np.mean(np.mean((add - Pa) ** 2, axis=2)))
    check(f"V04 ι = {iota}: linear map within 1% of the additive floor (relative gap)", 0.0, abs(H[f"V04.int_iota{iota:.1f}_linear_plan_rms"] / fl - 1), 0.01)

# ---------- V05: obstacle trajectories and atoms ----------
shape = np.array([math.sin(math.pi * (t + 1) / 17) for t in range(16)])
for name, amps, freq in (("two", [1.0, -1.0], [0.5, 0.5]), ("three", [1.0, -1.0, 2.0], [0.6, 0.3, 0.1])):
    ys, modes = [], []
    for i in range(512):
        r = V.Rng.derive(705, len(amps) * 1_000_000 + i)
        mode = r.categorical(freq); ga = r.gauss(); amp = amps[mode] * (1 + 0.1 * ga)
        ys.append(np.array([amp * shape[t] + 0.02 * r.gauss() for t in range(16)])); modes.append(mode)
    ys = np.array(ys)
    check(f"V05 {name}: stored share of mode 0", H[f"V05.{name}_stored_share_mode0"], np.mean([m == 0 for m in modes]), 1e-12)
    sp = np.mean([np.min(np.delete(np.linalg.norm(ys - ys[i], axis=1), i)) for i in range(200)])
    check(f"V05 {name}: mean nearest-neighbour spacing", H[f"V05.{name}_spacing"], sp, 1e-12)
    mu = ys.mean(axis=0); _, _, vt = np.linalg.svd(ys - mu, full_matrices=False)
    z = (ys - mu) @ vt.T                                   # full-rank orthonormal codes: distances as in the C# basis
    atoms = V.leader_train([((0,), list(row)) for row in z], 1.5)
    check(f"V05 {name}: atoms formed (leader clustering, θ = 1.5)", H[f"V05.{name}_atoms"], len(atoms), 0)
    cs = sorted(int(H[f"V05.{name}_atom{a}_count"]) for a in range(int(H[f"V05.{name}_atoms"])))
    check(f"V05 {name}: atom counts identical", 1.0, float(cs == sorted(a[2] for a in atoms)), 0)

with open(f"{OUT}/PY_crosscheck.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["quantity", "csharp", "python", "abs_difference", "agree"])
    for row in rows: w.writerow(row)
print(f"{sum(r[4] for r in rows)}/{len(rows)} agree")
for row in rows:
    if not row[4]: print("DISAGREE", row)
