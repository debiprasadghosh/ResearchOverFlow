using NxLab.Core;

namespace NxLab.Experiments;

/// <summary>
/// The phonological loop with and without the cerebellum. Short (one-syllable) and long (three-syllable) English words
/// are articulated by the self-paced loop of N02 with the learned forward model (intact) and without it (lesion); those
/// articulation times pace covert rehearsal in a decay-and-rehearsal model of verbal span. Hypotheses about how a
/// cerebellar lesion enters verbal memory: none (A), slower covert rehearsal (U), weaker encoding of items into the
/// phonological store (E), shorter-lived phonological traces (S), or slower rehearsal with shorter-lived traces (C); each
/// under quiet rehearsal and under articulatory suppression. Two read-outs:
/// span (the list length recalled perfectly half the time) and the share of items recalled at a fixed list length.
/// Storage-side variants (encoding loss of several sizes, shorter trace lifetimes) and the trace lifetime itself are
/// swept to show which parts of the pattern are robust.
/// </summary>
public static class N03_PhonologicalLoop
{
    private const ulong Seed = 803;
    public const int PoolSize = 60, NMin = 2, NMax = 10, Trials = 2000, TopWords = 5000, NFixed = 5;
    public const double EncodeFail = 0.08, Lifetime = 0.8;
    public static readonly double[] DecaySweep = { 3.0, 3.5, 4.0 };

    public sealed record Hypothesis(string Key, string Label, string Durations, double EncodeFail, double Lifetime);

    public static readonly IReadOnlyList<Hypothesis> Main = new[]
    {
        new Hypothesis("intact", "intact (hypothesis A predicts no lesion effect)", "intact", 0.0, 1.0),
        new Hypothesis("U", "U: covert rehearsal slowed", "lesion", 0.0, 1.0),
        new Hypothesis("E", $"E: encoding weakened ({EncodeFail:0.00} of items lost)", "intact", EncodeFail, 1.0),
        new Hypothesis("S", $"S: phonological traces shorter-lived (lifetime x{Lifetime:0.0})", "intact", 0.0, Lifetime),
        new Hypothesis("C", "C: U and S together", "lesion", 0.0, Lifetime),
    };

    public static readonly IReadOnlyList<Hypothesis> StorageVariants = new[]
    {
        new Hypothesis("E04", "E, encoding loss 0.04", "intact", 0.04, 1.0),
        new Hypothesis("E12", "E, encoding loss 0.12", "intact", 0.12, 1.0),
        new Hypothesis("S90", "S, trace lifetime x0.9", "intact", 0.0, 0.9),
        new Hypothesis("S70", "S, trace lifetime x0.7", "intact", 0.0, 0.7),
        new Hypothesis("UE", "U with encoding loss 0.08", "lesion", 0.08, 1.0),
        new Hypothesis("US90", "U with trace lifetime x0.9", "lesion", 0.0, 0.9),
    };

    static IReadOnlyList<string> Pool(Context ctx, Func<IReadOnlyList<string>, bool> keep) =>
        ctx.Lex.Words.Take(TopWords).Where(w => ctx.Cmu.Has(w) && w.Length >= 3 && keep(ctx.Cmu.Primary(w))).Take(PoolSize).ToArray();

    /// <summary>Spans and item shares of one hypothesis in the four cells (pool × condition).</summary>
    public sealed record Cells(IReadOnlyDictionary<(string Pool, bool Quiet), double> Span, IReadOnlyDictionary<(string Pool, bool Quiet), double> Items,
        IReadOnlyDictionary<(string Pool, bool Quiet), IReadOnlyList<PhonoLoop.RecallStats>> Curves)
    {
        public double Wle(bool items) => (items ? Items : Span)[("short", true)] - (items ? Items : Span)[("long", true)];
        public double Supp(bool items) => (items ? Items : Span)[("short", true)] - (items ? Items : Span)[("short", false)];
    }

    /// <summary>Common random numbers: the stream depends on pool, condition and list length only, never on the hypothesis.</summary>
    public static ulong Stream(string pool, bool quiet, int n) => 100_000UL * (pool == "short" ? 1UL : 2UL) + (quiet ? 0UL : 50_000UL) + (ulong)n;

    public static Cells Evaluate(Hypothesis hy, IReadOnlyDictionary<(string Pool, string Cond), IReadOnlyList<double>> durations, LoopParams lp)
    {
        var span = new Dictionary<(string, bool), double>(); var items = new Dictionary<(string, bool), double>();
        var curves = new Dictionary<(string, bool), IReadOnlyList<PhonoLoop.RecallStats>>();
        foreach (var pool in new[] { "short", "long" })
            foreach (bool quiet in new[] { true, false })
            {
                var curve = Enumerable.Range(NMin, NMax - NMin + 1)
                    .Select(n => PhonoLoop.Recall(durations[(pool, hy.Durations)], n, Trials, lp, quiet, hy.EncodeFail, Rng.Derive(Seed, Stream(pool, quiet, n)), hy.Lifetime))
                    .ToArray();
                curves[(pool, quiet)] = curve;
                span[(pool, quiet)] = PhonoLoop.Span(curve.Select(c => c.Perfect).ToArray(), NMin);
                items[(pool, quiet)] = curve[NFixed - NMin].Items;
            }
        return new Cells(span, items, curves);
    }

    public static ExperimentResult Run(Context ctx)
    {
        var h = new Dictionary<string, double>();
        var art = Effector.Articulators; var phones = Recipes.PhoneTargets(); var plan = Pacing.Default;
        var granule = Recipes.Model(art, Recipes.Cells);
        var gInt = Recipes.Tuned(art, granule, Recipes.RefDelay); var gLes = Recipes.Tuned(art, null, Recipes.RefDelay);
        var pools = new (string Name, IReadOnlyList<string> Words)[]
        {
            ("short", Pool(ctx, p => Pronouncing.Syllables(p) == 1)),
            ("long", Pool(ctx, p => Pronouncing.Syllables(p) == 3)),
        };
        var durRows = new List<object[]>();
        var durations = new Dictionary<(string Pool, string Cond), IReadOnlyList<double>>();
        foreach (var (name, words) in pools)
        {
            var di = words.Select((w, k) => Loop.Paced(art, granule, Recipes.RefDelay, gInt, Loop.Utter(new[] { w }, ctx.Cmu, phones, art.Dof), plan, Noise.Default, Rng.Derive(Seed, 1000 + (ulong)k)).Total).ToArray();
            var dl = words.Select((w, k) => Loop.Paced(art, null, Recipes.RefDelay, gLes, Loop.Utter(new[] { w }, ctx.Cmu, phones, art.Dof), plan, Noise.Default, Rng.Derive(Seed, 2000 + (ulong)k)).Total).ToArray();
            durations[(name, "intact")] = di; durations[(name, "lesion")] = dl;
            for (int k = 0; k < words.Count; k++) durRows.Add(new object[] { name, words[k], string.Join(" ", ctx.Cmu.Primary(words[k])), ctx.Cmu.Primary(words[k]).Count, di[k], dl[k] });
            h[$"{name}_phonemes"] = words.Average(w => (double)ctx.Cmu.Primary(w).Count);
            h[$"{name}_dur_intact"] = di.Average(); h[$"{name}_dur_lesion"] = dl.Average(); h[$"{name}_dur_ratio"] = dl.Average() / di.Average();
        }
        var tDur = Table.Of("word_durations", new[] { "pool", "word", "phonemes", "phoneme_count", "articulation_s_intact", "articulation_s_lesion" }, durRows);

        var lp = LoopParams.Default;
        var res = Main.ToDictionary(hy => hy.Key, hy => Evaluate(hy, durations, lp));
        var spanRows = new List<object[]>(); var itemRows = new List<object[]>(); var curveRows = new List<object[]>();
        var I = res["intact"];
        foreach (var hy in Main)
        {
            var c = res[hy.Key];
            foreach (bool items in new[] { false, true })
            {
                var m = items ? c.Items : c.Span; var mi = items ? I.Items : I.Span;
                double dq = mi[("short", true)] - m[("short", true)], ds = mi[("short", false)] - m[("short", false)];
                var row = new object[] { hy.Label, m[("short", true)], m[("long", true)], m[("short", false)], m[("long", false)], c.Wle(items), c.Supp(items), dq, ds };
                (items ? itemRows : spanRows).Add(row);
                string tag = items ? "items" : "span";
                h[$"{tag}_{hy.Key}_short_quiet"] = m[("short", true)]; h[$"{tag}_{hy.Key}_long_quiet"] = m[("long", true)];
                h[$"{tag}_{hy.Key}_short_supp"] = m[("short", false)]; h[$"{tag}_{hy.Key}_long_supp"] = m[("long", false)];
                h[$"{tag}_wle_{hy.Key}_quiet"] = c.Wle(items);
                h[$"{tag}_wle_{hy.Key}_supp"] = m[("short", false)] - m[("long", false)];
                h[$"{tag}_supp_effect_{hy.Key}"] = c.Supp(items);
                h[$"{tag}_deficit_{hy.Key}_quiet"] = dq; h[$"{tag}_deficit_{hy.Key}_supp"] = ds;
            }
            foreach (var ((pool, quiet), curve) in c.Curves)
                for (int k = 0; k < curve.Count; k++)
                    curveRows.Add(new object[] { hy.Key, pool, quiet ? "quiet" : "suppression", NMin + k, curve[k].Perfect, curve[k].Items });
        }
        string[] cols = { "hypothesis", "short_quiet", "long_quiet", "short_suppressed", "long_suppressed", "word_length_effect_quiet", "suppression_effect_short", "deficit_quiet_short", "deficit_suppressed_short" };
        var tSpan = Table.Of("spans", cols, spanRows);
        var tItems = Table.Of("item_share", cols, itemRows);

        // Storage-side variants, and slowed rehearsal combined with a larger encoding loss.
        var varRows = new List<object[]>();
        foreach (var hy in StorageVariants)
        {
            var c = Evaluate(hy, durations, lp);
            double dqS = I.Span[("short", true)] - c.Span[("short", true)], dsS = I.Span[("short", false)] - c.Span[("short", false)];
            double dqI = I.Items[("short", true)] - c.Items[("short", true)], dsI = I.Items[("short", false)] - c.Items[("short", false)];
            varRows.Add(new object[] { hy.Label, dqS, dsS, c.Wle(false), c.Supp(false), dqI, dsI, c.Wle(true), c.Supp(true) });
            h[$"var_{hy.Key}_span_deficit_quiet"] = dqS; h[$"var_{hy.Key}_span_deficit_supp"] = dsS; h[$"var_{hy.Key}_span_wle"] = c.Wle(false); h[$"var_{hy.Key}_span_supp_effect"] = c.Supp(false);
            h[$"var_{hy.Key}_items_deficit_quiet"] = dqI; h[$"var_{hy.Key}_items_deficit_supp"] = dsI; h[$"var_{hy.Key}_items_wle"] = c.Wle(true); h[$"var_{hy.Key}_items_supp_effect"] = c.Supp(true);
        }
        var tVar = Table.Of("storage_variants", new[] { "variant", "span_deficit_quiet", "span_deficit_suppressed", "span_word_length_effect", "span_suppression_effect", "items_deficit_quiet", "items_deficit_suppressed", "items_word_length_effect", "items_suppression_effect" }, varRows);

        // Robustness of the main pattern to the trace lifetime.
        var decayRows = new List<object[]>();
        foreach (double dec in DecaySweep)
        {
            var lpd = lp with { Decay = dec };
            var rd = Main.ToDictionary(hy => hy.Key, hy => Evaluate(hy, durations, lpd));
            foreach (var hy in Main)
            {
                var c = rd[hy.Key]; var i0 = rd["intact"];
                double dq = i0.Items[("short", true)] - c.Items[("short", true)], ds = i0.Items[("short", false)] - c.Items[("short", false)];
                decayRows.Add(new object[] { dec, hy.Key, c.Span[("short", true)], c.Span[("long", true)], c.Span[("short", false)], c.Wle(true), c.Supp(true), dq, ds });
                h[$"sweepD{dec:0.0}_{hy.Key}_span_short_quiet"] = c.Span[("short", true)];
                h[$"sweepD{dec:0.0}_{hy.Key}_items_wle"] = c.Wle(true); h[$"sweepD{dec:0.0}_{hy.Key}_items_supp_effect"] = c.Supp(true);
                h[$"sweepD{dec:0.0}_{hy.Key}_items_deficit_quiet"] = dq; h[$"sweepD{dec:0.0}_{hy.Key}_items_deficit_supp"] = ds;
            }
        }
        var tDecay = Table.Of("decay_sweep", new[] { "decay_s", "hypothesis", "span_short_quiet", "span_long_quiet", "span_short_suppressed", "items_word_length_effect", "items_suppression_effect", "items_deficit_quiet", "items_deficit_suppressed" }, decayRows);
        var tCurve = Table.Of("recall_curves", new[] { "hypothesis", "pool", "condition", "list_length", "perfect_recall", "item_share" }, curveRows);
        h["decay_s"] = lp.Decay; h["presentation_s"] = lp.Presentation; h["output_s"] = lp.OutputTime; h["fixed_list_length"] = NFixed;
        return new ExperimentResult("N03", "The phonological loop with and without the cerebellum", new[] { tDur, tSpan, tItems, tVar, tDecay, tCurve }, h);
    }
}
