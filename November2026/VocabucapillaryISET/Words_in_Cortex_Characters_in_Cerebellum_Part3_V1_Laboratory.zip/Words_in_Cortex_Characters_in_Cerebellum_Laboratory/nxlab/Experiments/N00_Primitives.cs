using NxLab.Core;

namespace NxLab.Experiments;

/// <summary>
/// Exact accounting of the primitive systems of English words: phonemes (CMU Pronouncing Dictionary) against letters
/// (the bytes an LLM reads) for the 50,000 most frequent words of the wordfreq list. Units per word and per second of
/// speech; homophones and words with several listed pronunciations; phonemic and orthographic uniqueness points; the
/// rate at which a word-level vocabulary meets new words as exposure grows (the open-vocabulary demand that a fixed
/// primitive level serves); and causal attention pairs per minute at word, syllable, phoneme and control-step resolution.
/// </summary>
public static class N00_Primitives
{
    private const ulong Seed = 800;
    public const double WordsPerSecond = 2.5;
    public static readonly long[] Exposures = { 1_000, 10_000, 100_000, 1_000_000, 10_000_000 };

    static (double TokenShareNotUnique, double MeanUpFraction, double MeanAfterUp, double TypeShareNotUnique) Uniqueness(IReadOnlyList<(string[] Units, double P)> items)
    {
        var count = new Dictionary<string, int>();
        foreach (var (u, _) in items)
            for (int k = 1; k <= u.Length; k++) { string key = string.Join("\u0001", u.Take(k)); count[key] = count.GetValueOrDefault(key) + 1; }
        double mass = items.Sum(x => x.P), notUnique = 0, upFrac = 0, after = 0, uniqMass = 0; int notUniqTypes = 0;
        foreach (var (u, p) in items)
        {
            int up = -1;
            for (int k = 1; k <= u.Length; k++) if (count[string.Join("\u0001", u.Take(k))] == 1) { up = k; break; }
            if (up < 0) { notUnique += p; notUniqTypes++; continue; }
            upFrac += p * up / (double)u.Length; after += p * (u.Length - up); uniqMass += p;
        }
        return (notUnique / mass, upFrac / uniqMass, after / uniqMass, notUniqTypes / (double)items.Count);
    }

    public static ExperimentResult Run(Context ctx)
    {
        var lex = ctx.Lex; var cmu = ctx.Cmu;
        var h = new Dictionary<string, double>();
        var covered = Enumerable.Range(0, lex.Words.Count).Where(i => cmu.Has(lex.Words[i])).ToArray();
        double cmass = covered.Sum(i => lex.Prob[i]);
        h["words"] = lex.Words.Count; h["covered_words"] = covered.Length; h["covered_token_share"] = cmass;
        h["phonemes"] = Pronouncing.Phones.Count; h["letters"] = 26;

        // Units per word and per second.
        double L = 0, Ph = 0, Sy = 0, Lt = 0, Pt = 0, St = 0;
        foreach (int i in covered)
        {
            var pr = cmu.Primary(lex.Words[i]); double w = lex.Prob[i] / cmass;
            L += w * lex.Words[i].Length; Ph += w * pr.Count; Sy += w * Pronouncing.Syllables(pr);
            Lt += lex.Words[i].Length; Pt += pr.Count; St += Pronouncing.Syllables(pr);
        }
        Lt /= covered.Length; Pt /= covered.Length; St /= covered.Length;
        var unitRows = new List<object[]>
        {
            new object[] { "letters (bytes an LLM reads, without the space)", L, Lt, WordsPerSecond * L, WordsPerSecond * (L + 1) },
            new object[] { "phonemes", Ph, Pt, WordsPerSecond * Ph, double.NaN },
            new object[] { "syllables", Sy, St, WordsPerSecond * Sy, double.NaN },
        };
        h["letters_per_word"] = L; h["phonemes_per_word"] = Ph; h["syllables_per_word"] = Sy;
        h["letters_per_type"] = Lt; h["phonemes_per_type"] = Pt; h["syllables_per_type"] = St;
        h["phonemes_per_second"] = WordsPerSecond * Ph; h["syllables_per_second"] = WordsPerSecond * Sy; h["bytes_per_second"] = WordsPerSecond * (L + 1);
        h["phonemes_per_syllable"] = Ph / Sy;
        var tUnits = Table.Of("units", new[] { "unit", "per_word_token_weighted", "per_word_type", "per_second_at_2.5_words", "bytes_per_second_with_space" }, unitRows);

        // Homophones (one pronunciation, several spellings) and words with several listed pronunciations.
        var byPron = covered.GroupBy(i => Pronouncing.Key(cmu.Primary(lex.Words[i]))).Where(g => g.Count() > 1).ToArray();
        double homMass = byPron.Sum(g => g.Sum(i => lex.Prob[i])) / cmass;
        h["homophone_sets"] = byPron.Length; h["homophone_words"] = byPron.Sum(g => g.Count()); h["homophone_token_share"] = homMass;
        var multi = covered.Where(i => cmu.Entries[lex.Words[i]].Select(Pronouncing.Key).Distinct().Count() > 1).ToArray();
        h["multi_pron_words"] = multi.Length; h["multi_pron_token_share"] = multi.Sum(i => lex.Prob[i]) / cmass;
        var homRows = byPron.OrderByDescending(g => g.Sum(i => lex.Prob[i])).Take(14)
            .Select(g => new object[] { string.Join(" / ", g.OrderBy(i => i).Select(i => lex.Words[i])), g.Key, g.Sum(i => lex.Prob[i]) / cmass }).ToList();
        var tHom = Table.Of("homophones", new[] { "spellings", "pronunciation", "token_share" }, homRows);

        // Uniqueness points among the covered words, by phonemes and by letters.
        var phonItems = covered.Select(i => (cmu.Primary(lex.Words[i]).ToArray(), lex.Prob[i])).ToArray();
        var letItems = covered.Select(i => (lex.Words[i].Select(c => c.ToString()).ToArray(), lex.Prob[i])).ToArray();
        var up1 = Uniqueness(phonItems); var up2 = Uniqueness(letItems);
        var upRows = new List<object[]>
        {
            new object[] { "phonemes (spoken word)", up1.TokenShareNotUnique, up1.TypeShareNotUnique, up1.MeanUpFraction, up1.MeanAfterUp },
            new object[] { "letters (written word)", up2.TokenShareNotUnique, up2.TypeShareNotUnique, up2.MeanUpFraction, up2.MeanAfterUp },
        };
        h["up_phon_not_unique_tokens"] = up1.TokenShareNotUnique; h["up_phon_not_unique_types"] = up1.TypeShareNotUnique; h["up_phon_fraction"] = up1.MeanUpFraction; h["up_phon_after"] = up1.MeanAfterUp;
        h["up_let_not_unique_tokens"] = up2.TokenShareNotUnique; h["up_let_not_unique_types"] = up2.TypeShareNotUnique; h["up_let_fraction"] = up2.MeanUpFraction; h["up_let_after"] = up2.MeanAfterUp;
        var tUp = Table.Of("uniqueness", new[] { "units", "tokens_not_unique_by_word_end", "types_not_unique_by_word_end", "uniqueness_point_over_length", "units_after_uniqueness_point" }, upRows);

        // New words met as exposure grows (the full alphabetic list, up to 16 letters).
        var full = Lexicon.Load(ctx.DataPath, int.MaxValue);
        h["full_list_words"] = full.Words.Count;
        var seen = new bool[full.Words.Count];
        double seenMass = 0; long draws = 0; int distinct = 0;
        var r = Rng.Derive(Seed, 1);
        var oovRows = new List<object[]>();
        foreach (long target in Exposures)
        {
            while (draws < target) { var (k, nr) = full.Sample(r); r = nr; draws++; if (!seen[k]) { seen[k] = true; seenMass += full.Prob[k]; distinct++; } }
            double oov = 1 - seenMass;
            oovRows.Add(new object[] { target, distinct, oov, 1000 * oov });
            h[$"oov_N{target}"] = oov; h[$"distinct_N{target}"] = distinct;
        }
        var tOov = Table.Of("open_vocabulary", new[] { "tokens_heard", "distinct_words_known", "probability_next_token_is_new", "new_words_per_1000_tokens" }, oovRows);

        // Causal attention pairs per minute at four resolutions.
        double minute = 60;
        var res = new (string Name, double PerSecond)[] { ("words", WordsPerSecond), ("syllables", WordsPerSecond * Sy), ("phonemes", WordsPerSecond * Ph), ("articulatory control steps (5 ms)", 1 / Effector.Dt) };
        var pairRows = res.Select(x => { double n = x.PerSecond * minute; return new object[] { x.Name, n, n * (n + 1) / 2 }; }).ToList();
        foreach (var row in pairRows) h[$"pairs_{((string)row[0]).Split(' ')[0]}"] = (double)row[2];
        var tPairs = Table.Of("attention_pairs", new[] { "resolution", "tokens_per_minute", "causal_pairs_per_minute" }, pairRows);
        return new ExperimentResult("N00", "Primitives of the spoken and the written word", new[] { tUnits, tHom, tUp, tOov, tPairs }, h);
    }
}
