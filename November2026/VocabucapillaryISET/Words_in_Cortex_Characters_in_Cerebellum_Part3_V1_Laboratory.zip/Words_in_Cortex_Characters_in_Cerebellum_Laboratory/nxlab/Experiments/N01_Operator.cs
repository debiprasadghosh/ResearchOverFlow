using NxLab.Core;

namespace NxLab.Experiments;

/// <summary>
/// One cerebellar operator for every loop. The same microzone recipe (granule expansion with K inputs per cell and a
/// coding level f, a nuclear linear pathway and a Purkinje readout) learns the forward models of the limb and of the
/// articulators from exploration data. Accuracy of the predicted accelerations and of the 60 ms state prediction a
/// Smith predictor needs, against the nuclear pathway alone and against no prediction; granule-layer size, inputs per
/// cell and coding level; the climbing-fibre delta rule against its least-squares fixed point.
/// </summary>
public static class N01_Operator
{
    private const ulong Seed = 801;
    public const int Train = 30_000, Test = 6_000, Cells = 1024, K = 4, Delay = 12, Windows = 1000;
    public const double Coding = 0.1, Alpha = 1e-6;

    static double ZoneError(ForwardModel m, Excitation test, int zone)
    {
        int n = test.E.Dof; var a = new double[n]; double se = 0, s1 = 0, s2 = 0;
        for (int t = 0; t < test.Steps; t++) { m.Accel(test.P[t], test.V[t], test.U[t], a); double y = test.A[t][zone]; se += (a[zone] - y) * (a[zone] - y); s1 += y; s2 += y * y; }
        double mean = s1 / test.Steps; return Math.Sqrt(se / test.Steps / (s2 / test.Steps - mean * mean));
    }

    public static ExperimentResult Run(Context ctx)
    {
        var h = new Dictionary<string, double>();
        var rows = new List<object[]>(); var sweepRows = new List<object[]>();
        GranuleModel? artRef = null; Excitation? artTrain = null, artTest = null;
        foreach (var (e, ei) in new[] { (Effector.Limb, 0), (Effector.Articulators, 1) })
        {
            var train = Excitation.Make(e, Train, Rng.Derive(Seed, 10 + (ulong)ei));
            var test = Excitation.Make(e, Test, Rng.Derive(Seed, 20 + (ulong)ei));
            string ek = e.Name;
            double none = Cerebellum.RolloutError(null, test, Delay, Windows);
            double exact = Cerebellum.RolloutError(new ExactModel(e), test, Delay, Windows);
            rows.Add(new object[] { ek, "no prediction (delayed observation)", 0, double.NaN, none });
            rows.Add(new object[] { ek, "exact equations", 0, 0.0, exact });
            h[$"{ek}_rollout_none"] = none; h[$"{ek}_rollout_exact"] = exact;
            foreach (int m in new[] { 0, 128, 256, 512, 1024 })
            {
                var model = Cerebellum.Fit(m == 0 ? "nuclear pathway" : $"granule {m}", train, m, K, Coding, Alpha, Seed + 1000 * (ulong)ei + (ulong)m);
                double err = Cerebellum.NormalizedError(model, test), roll = Cerebellum.RolloutError(model, test, Delay, Windows);
                rows.Add(new object[] { ek, m == 0 ? "nuclear pathway only (linear)" : $"granule layer, {m} cells per microzone", m, err, roll });
                h[$"{ek}_m{m}_acc_error"] = err; h[$"{ek}_m{m}_rollout"] = roll;
                if (m == Cells)
                {
                    var xs = Enumerable.Range(0, 2000).Select(t => test.Inputs(t * 3, 2)).ToArray();
                    h[$"{ek}_active_share"] = model.ActiveShare(xs, 2);
                    if (ei == 1) { artRef = model; artTrain = train; artTest = test; }
                }
            }
            h[$"{ek}_train_steps"] = Train;
        }
        var tModels = Table.Of("forward_models", new[] { "effector", "model", "granule_cells_per_microzone", "acceleration_error_over_sd", "position_error_60ms_rad" }, rows);

        // Sweeps on the articulators: inputs per granule cell and coding level.
        foreach (int k in new[] { 1, 2, 3, 4, 5 })
        {
            var model = Cerebellum.Fit($"K{k}", artTrain!, Cells, k, Coding, Alpha, Seed + 5000 + (ulong)k);
            double err = Cerebellum.NormalizedError(model, artTest!), roll = Cerebellum.RolloutError(model, artTest!, Delay, Windows);
            sweepRows.Add(new object[] { "inputs per granule cell K", k, err, roll });
            h[$"sweep_K{k}_acc_error"] = err; h[$"sweep_K{k}_rollout"] = roll;
        }
        foreach (double f in new[] { 0.02, 0.05, 0.1, 0.2, 0.5 })
        {
            var model = Cerebellum.Fit($"f{f}", artTrain!, Cells, K, f, Alpha, Seed + 6000 + (ulong)(f * 1000));
            double err = Cerebellum.NormalizedError(model, artTest!), roll = Cerebellum.RolloutError(model, artTest!, Delay, Windows);
            sweepRows.Add(new object[] { "coding level f", f, err, roll });
            h[$"sweep_f{f:0.00}_acc_error"] = err; h[$"sweep_f{f:0.00}_rollout"] = roll;
        }
        var tSweep = Table.Of("granule_sweeps", new[] { "parameter", "value", "acceleration_error_over_sd", "position_error_60ms_rad" }, sweepRows);

        // The climbing-fibre delta rule on one microzone against the least-squares readout.
        const int zone = 2;
        var curve = Cerebellum.DeltaRuleCurve(artTrain!, artTest!, artRef!.Zones[zone], zone, 8, 0.5, Seed + 9000);
        double ridge = ZoneError(artRef, artTest!, zone);
        var linZone = Cerebellum.Fit("lin", artTrain!, 0, K, Coding, Alpha, Seed + 9100);
        double lin = ZoneError(linZone, artTest!, zone);
        var dRows = curve.Select((c, i) => new object[] { i + 1, c, ridge, lin }).ToList();
        for (int i = 0; i < curve.Count; i++) h[$"delta_epoch{i + 1}"] = curve[i];
        h["delta_ridge"] = ridge; h["delta_linear"] = lin;
        var tDelta = Table.Of("delta_rule", new[] { "epoch", "delta_rule_error", "least_squares_error", "nuclear_pathway_error" }, dRows);
        return new ExperimentResult("N01", "One cerebellar operator for every loop", new[] { tModels, tSweep, tDelta }, h);
    }
}
