using NxLab.Core;

namespace NxLab.Experiments;

/// <summary>
/// Reaching and utterance with delayed feedback, with and without the cerebellar forward model. A posture-holding
/// feedforward and proportional–derivative feedback act on the estimated state; the gains are tuned for each loop
/// (the best each can do). (a) Tracking of point-to-point reaches against feedback delay for the limb and the
/// articulators, with the exact forward model and with none. (b) At 60 ms, the learned granule model and the nuclear
/// pathway alone. (c) Self-paced utterances of frequency-sampled English words (phonemes from the CMU dictionary mapped
/// to articulator targets): rate, duration variability, the dependence of durations on articulatory distance, accuracy.
/// (d) Speaking rate against delay.
/// </summary>
public static class N02_Loops
{
    private const ulong Seed = 802;
    public static readonly int[] Delays = { 0, 4, 8, 12, 16, 20, 24 };
    public const int Utterances = 30, WordsPerUtterance = 10;

    static (double End, double Over, double HoldSd) ReachMetrics(TrackResult tr, IReadOnlyList<double[]> R, int steps, Effector e)
    {
        int n = e.Dof, reaches = R.Count / steps;
        int holdSteps = (int)Math.Round(0.2 / e.Lambda / Effector.Dt);
        double end = 0, over = 0, sd = 0; int overCount = 0;
        for (int k = 0; k < reaches; k++)
        {
            int s0 = k * steps, s1 = s0 + steps - 1;
            double e2 = 0, sdSum = 0;
            for (int i = 0; i < n; i++)
            {
                double a = R[s0][i], b = R[s1][i], disp = b - a;
                e2 += (tr.P[s1][i] - b) * (tr.P[s1][i] - b);
                if (Math.Abs(disp) > 0.3)
                {
                    double mx = 0;
                    for (int s = s0; s <= s1; s++) mx = Math.Max(mx, (tr.P[s][i] - b) * Math.Sign(disp));
                    over += mx / Math.Abs(disp); overCount++;
                }
                int h0 = s1 - holdSteps / 2;
                double m = 0, m2 = 0; int c = 0;
                for (int s = h0; s <= s1; s++) { m += tr.P[s][i]; m2 += tr.P[s][i] * tr.P[s][i]; c++; }
                m /= c; sdSum += Math.Max(0, m2 / c - m * m);
            }
            end += Math.Sqrt(e2 / n); sd += Math.Sqrt(sdSum / n);
        }
        return (end / reaches, overCount > 0 ? over / overCount : 0, sd / reaches);
    }

    /// <summary>
    /// Rate (gestures per second), mean and coefficient of variation of gesture durations, their correlation with the
    /// planned distance, the duration contrast (mean duration of the longest-distance quarter of gestures over that of
    /// the shortest-distance quarter; 1 means durations are equalized), the share of gestures on target when they ended,
    /// the mean true error then, and the share that timed out.
    /// </summary>
    public sealed record PacedStats(double Rate, double MeanMs, double Cv, double Corr, double Contrast, double Hit, double ErrMean, double Timeouts, int Gestures);

    public static PacedStats Stats(IReadOnlyList<PacedResult> rs, Pacing plan)
    {
        var d = rs.SelectMany(r => r.Durations).ToArray(); var dist = rs.SelectMany(r => r.Distances).ToArray(); var err = rs.SelectMany(r => r.Errors).ToArray();
        double mean = d.Average(), sd = Math.Sqrt(d.Average(x => (x - mean) * (x - mean)));
        var order = Enumerable.Range(0, d.Length).OrderBy(i => dist[i]).ThenBy(i => i).ToArray();
        int q = d.Length / 4;
        double low = order.Take(q).Average(i => d[i]), high = order.Skip(d.Length - q).Average(i => d[i]);
        return new PacedStats(d.Length / d.Sum(), 1000 * mean, sd / mean, Mat.Pearson(d, dist), high / low, err.Average(x => x <= plan.HitTol ? 1.0 : 0), err.Average(), d.Average(x => x > plan.Timeout ? 1.0 : 0), d.Length);
    }

    public static ExperimentResult Run(Context ctx)
    {
        var h = new Dictionary<string, double>();
        var rows = new List<object[]>();
        var gainsRef = new Dictionary<string, Gains>();
        var gainsByDelay = new Dictionary<(string, int), Gains>();
        var models = new Dictionary<(string, string), ForwardModel?>();
        foreach (var e in new[] { Effector.Limb, Effector.Articulators })
        {
            models[(e.Name, "exact")] = new ExactModel(e);
            models[(e.Name, "granule")] = Recipes.Model(e, Recipes.Cells);
            models[(e.Name, "nuclear")] = Recipes.Model(e, 0);
            models[(e.Name, "none")] = null;
            var (R, Rv, steps) = Recipes.EvalReaches(e);
            foreach (int D in Delays)
                foreach (var cond in D == Recipes.RefDelay ? new[] { "exact", "granule", "nuclear", "none" } : new[] { "exact", "none" })
                {
                    var m = models[(e.Name, cond)];
                    var g = Recipes.Tuned(e, m, D);
                    var tr = Loop.Track(e, m, D, g, R, Rv, Noise.Default, Rng.Derive(Seed, 60 + (ulong)(Recipes.Index(e) * 100 + D)));
                    var (end, over, holdSd) = tr.Stable ? ReachMetrics(tr, R, steps, e) : (double.NaN, double.NaN, double.NaN);
                    rows.Add(new object[] { e.Name, D * Effector.Dt * 1000, cond, g.Bandwidth, g.Damping, tr.Rms, end, over, holdSd });
                    string key = $"{e.Name}_D{D * 5}_{cond}";
                    h[$"{key}_rms"] = tr.Rms; h[$"{key}_end"] = end; h[$"{key}_over"] = over; h[$"{key}_holdsd"] = holdSd; h[$"{key}_bandwidth"] = g.Bandwidth;
                    if (e == Effector.Articulators) gainsByDelay[(cond, D)] = g;
                    if (D == Recipes.RefDelay) gainsRef[$"{e.Name}_{cond}"] = g;
                }
        }
        var tTrack = Table.Of("tracking", new[] { "effector", "delay_ms", "forward_model", "bandwidth", "damping", "tracking_rms", "end_error", "overshoot_fraction", "hold_sd" }, rows);

        // Self-paced utterances.
        var art = Effector.Articulators; var phones = Recipes.PhoneTargets(); var plan = Pacing.Default;
        var r = Rng.Derive(Seed, 1);
        var utts = new List<Utterance>();
        for (int k = 0; k < Utterances; k++) { var (ws, nr) = Recipes.SampleWords(ctx.Lex, ctx.Cmu, WordsPerUtterance, r); r = nr; utts.Add(Loop.Utter(ws, ctx.Cmu, phones, art.Dof)); }
        var pacedRows = new List<object[]>();
        PacedStats Speak(ForwardModel? m, Gains g, int D, ulong stream) =>
            Stats(utts.Select((u, k) => Loop.Paced(art, m, D, g, u, plan, Noise.Default, Rng.Derive(Seed, stream + (ulong)k))).ToArray(), plan);
        foreach (var cond in new[] { "exact", "granule", "nuclear", "none" })
        {
            var st = Speak(models[("articulators", cond)], gainsRef[$"articulators_{cond}"], Recipes.RefDelay, 10_000);
            pacedRows.Add(new object[] { Recipes.RefDelay * 5, cond, st.Rate, st.MeanMs, st.Cv, st.Corr, st.Contrast, st.Hit, st.ErrMean, st.Timeouts, st.Gestures });
            string key = $"paced_{cond}";
            h[$"{key}_rate"] = st.Rate; h[$"{key}_mean_ms"] = st.MeanMs; h[$"{key}_cv"] = st.Cv; h[$"{key}_corr"] = st.Corr; h[$"{key}_contrast"] = st.Contrast;
            h[$"{key}_hit"] = st.Hit; h[$"{key}_err"] = st.ErrMean; h[$"{key}_timeouts"] = st.Timeouts; h[$"{key}_gestures"] = st.Gestures;
        }
        h["natural_phoneme_rate"] = N00_Primitives.WordsPerSecond * ctx.Lex.Words.Select((w, i) => (w, i)).Where(x => ctx.Cmu.Has(x.w)).Sum(x => ctx.Lex.Prob[x.i] * ctx.Cmu.Primary(x.w).Count) / ctx.Lex.Words.Select((w, i) => (w, i)).Where(x => ctx.Cmu.Has(x.w)).Sum(x => ctx.Lex.Prob[x.i]);
        var tPaced = Table.Of("utterance", new[] { "delay_ms", "forward_model", "phonemes_per_second", "mean_gesture_ms", "duration_cv", "duration_distance_correlation", "duration_contrast", "on_target_share", "mean_error_at_end", "timeout_share", "gestures" }, pacedRows);

        // Speaking rate against delay, with the exact forward model and with none.
        var delayRows = new List<object[]>();
        foreach (int D in Delays)
        {
            var se = Speak(models[("articulators", "exact")], gainsByDelay[("exact", D)], D, 20_000 + (ulong)D * 100);
            var sn = Speak(null, gainsByDelay[("none", D)], D, 30_000 + (ulong)D * 100);
            delayRows.Add(new object[] { D * 5, D * 5 / se.MeanMs, se.Rate, sn.Rate, se.Rate / sn.Rate, se.Corr, sn.Corr, se.Contrast, sn.Contrast, sn.Hit, sn.Cv });
            h[$"delay_over_gesture_D{D * 5}"] = D * 5 / se.MeanMs;
            h[$"rate_D{D * 5}_exact"] = se.Rate; h[$"rate_D{D * 5}_none"] = sn.Rate; h[$"rate_D{D * 5}_ratio"] = se.Rate / sn.Rate;
            h[$"corr_D{D * 5}_none"] = sn.Corr; h[$"contrast_D{D * 5}_none"] = sn.Contrast; h[$"hit_D{D * 5}_none"] = sn.Hit;
        }
        var tDelay = Table.Of("rate_vs_delay", new[] { "delay_ms", "delay_over_gesture_duration", "rate_exact_model", "rate_no_model", "slowing_factor", "corr_exact", "corr_none", "contrast_exact", "contrast_none", "on_target_none", "cv_none" }, delayRows);

        // Example trajectories: the first four words of the first utterance, first articulator.
        var (exWords, _) = Recipes.SampleWords(ctx.Lex, ctx.Cmu, 4, Rng.Derive(Seed, 1));
        var exUtt = Loop.Utter(exWords, ctx.Cmu, phones, art.Dof);
        var exRows = new List<object[]>();
        foreach (var cond in new[] { "granule", "none" })
        {
            var res = Loop.Paced(art, models[("articulators", cond)], Recipes.RefDelay, gainsRef[$"articulators_{cond}"], exUtt, plan, Noise.Default, Rng.Derive(Seed, 40_000));
            for (int s = 0; s < res.P.Count; s++) exRows.Add(new object[] { cond, (s + 1) * Effector.Dt, res.Gesture[s], exUtt.Targets[res.Gesture[s]][0], res.P[s][0] });
        }
        var tEx = Table.Of("example", new[] { "forward_model", "time_s", "gesture", "target_dof0", "position_dof0" }, exRows);
        h["example_words"] = exWords.Count;
        var tWords = Table.Of("example_words", new[] { "word", "phonemes" }, exWords.Select(w => (IReadOnlyList<object>)new object[] { w, string.Join(" ", ctx.Cmu.Primary(w)) }));
        return new ExperimentResult("N02", "Loops with delayed feedback", new[] { tTrack, tPaced, tDelay, tEx, tWords }, h);
    }
}
