namespace NxLab.Core;

/// <summary>
/// The CMU Pronouncing Dictionary (ARPAbet, 39 phonemes). Pronunciations are kept per word in file order, stress digits
/// removed; a syllable is a vowel phoneme. Only lower-case alphabetic headwords are kept, so every word maps onto the
/// letters of the wordfreq lexicon.
/// </summary>
public sealed record Pronouncing(IReadOnlyDictionary<string, IReadOnlyList<IReadOnlyList<string>>> Entries)
{
    public static readonly IReadOnlyList<string> Vowels = new[] { "AA", "AE", "AH", "AO", "AW", "AY", "EH", "ER", "EY", "IH", "IY", "OW", "OY", "UH", "UW" };
    public static readonly IReadOnlyList<string> Consonants = new[] { "B", "CH", "D", "DH", "F", "G", "HH", "JH", "K", "L", "M", "N", "NG", "P", "R", "S", "SH", "T", "TH", "V", "W", "Y", "Z", "ZH" };
    public static readonly IReadOnlyList<string> Phones = Vowels.Concat(Consonants).ToArray();
    private static readonly HashSet<string> VowelSet = new(Vowels);
    private static readonly Dictionary<string, int> PhoneIndex = Phones.Select((p, i) => (p, i)).ToDictionary(x => x.p, x => x.i);

    public static bool IsVowel(string ph) => VowelSet.Contains(ph);
    public static int IndexOf(string ph) => PhoneIndex[ph];

    public static Pronouncing Load(string path)
    {
        var map = new Dictionary<string, List<IReadOnlyList<string>>>();
        foreach (var raw in File.ReadLines(path))
        {
            string line = raw;
            int hash = line.IndexOf('#');
            if (hash >= 0) line = line[..hash];
            var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length < 2) continue;
            string head = parts[0];
            int paren = head.IndexOf('(');
            if (paren > 0) head = head[..paren];
            if (!Lexicon.IsAlpha(head)) continue;
            var phones = parts.Skip(1).Select(p => p.TrimEnd('0', '1', '2')).ToArray();
            if (phones.Any(p => !PhoneIndex.ContainsKey(p))) continue;
            if (!map.TryGetValue(head, out var list)) { list = new List<IReadOnlyList<string>>(); map[head] = list; }
            list.Add(phones);
        }
        return new Pronouncing(map.ToDictionary(kv => kv.Key, kv => (IReadOnlyList<IReadOnlyList<string>>)kv.Value.ToArray()));
    }

    public bool Has(string w) => Entries.ContainsKey(w);
    public IReadOnlyList<string> Primary(string w) => Entries[w][0];
    public static int Syllables(IReadOnlyList<string> phones) => phones.Count(IsVowel);
    public static string Key(IReadOnlyList<string> phones) => string.Join(" ", phones);
}
