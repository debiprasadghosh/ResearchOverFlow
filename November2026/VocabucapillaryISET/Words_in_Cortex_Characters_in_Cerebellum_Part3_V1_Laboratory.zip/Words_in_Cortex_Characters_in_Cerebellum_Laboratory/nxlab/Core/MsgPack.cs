using System.IO.Compression;
using System.Text;

namespace NxLab.Core;

/// <summary>
/// A minimal MessagePack reader, sufficient for the word-frequency files of wordfreq (Speer, 2022): arrays, maps,
/// strings, integers, booleans and nil. Each call returns the decoded value and the index after it.
/// </summary>
public static class MsgPack
{
    public static object? ReadGzip(string path)
    {
        using var gz = new GZipStream(File.OpenRead(path), CompressionMode.Decompress);
        using var ms = new MemoryStream();
        gz.CopyTo(ms);
        return ReadAt(ms.ToArray(), 0).Value;
    }

    public static (object? Value, int Next) ReadAt(byte[] b, int i)
    {
        byte t = b[i];
        if (t <= 0x7f) return ((long)t, i + 1);
        if (t >= 0x80 && t <= 0x8f) return ReadMap(b, i + 1, t & 0x0f);
        if (t >= 0x90 && t <= 0x9f) return ReadArray(b, i + 1, t & 0x0f);
        if (t >= 0xa0 && t <= 0xbf) return ReadStr(b, i + 1, t & 0x1f);
        if (t >= 0xe0) return ((long)(sbyte)t, i + 1);
        return t switch
        {
            0xc0 => (null, i + 1),
            0xc2 => (false, i + 1),
            0xc3 => (true, i + 1),
            0xcc => ((long)b[i + 1], i + 2),
            0xcd => ((long)Be16(b, i + 1), i + 3),
            0xce => ((long)Be32(b, i + 1), i + 5),
            0xd9 => ReadStr(b, i + 2, b[i + 1]),
            0xda => ReadStr(b, i + 3, Be16(b, i + 1)),
            0xdb => ReadStr(b, i + 5, (int)Be32(b, i + 1)),
            0xdc => ReadArray(b, i + 3, Be16(b, i + 1)),
            0xdd => ReadArray(b, i + 5, (int)Be32(b, i + 1)),
            0xde => ReadMap(b, i + 3, Be16(b, i + 1)),
            _ => throw new InvalidDataException($"Unsupported MessagePack type 0x{t:x2} at {i}"),
        };
    }

    private static int Be16(byte[] b, int i) => (b[i] << 8) | b[i + 1];
    private static uint Be32(byte[] b, int i) => ((uint)b[i] << 24) | ((uint)b[i + 1] << 16) | ((uint)b[i + 2] << 8) | b[i + 3];

    private static (object? Value, int Next) ReadStr(byte[] b, int i, int n) => (Encoding.UTF8.GetString(b, i, n), i + n);

    private static (object? Value, int Next) ReadArray(byte[] b, int i, int n)
    {
        var items = new object?[n];
        int p = i;
        for (int k = 0; k < n; k++) { var (v, next) = ReadAt(b, p); items[k] = v; p = next; }
        return (items, p);
    }

    private static (object? Value, int Next) ReadMap(byte[] b, int i, int n)
    {
        var map = new Dictionary<string, object?>();
        int p = i;
        for (int k = 0; k < n; k++)
        {
            var (key, p1) = ReadAt(b, p);
            var (val, p2) = ReadAt(b, p1);
            map[key?.ToString() ?? ""] = val;
            p = p2;
        }
        return (map, p);
    }
}
