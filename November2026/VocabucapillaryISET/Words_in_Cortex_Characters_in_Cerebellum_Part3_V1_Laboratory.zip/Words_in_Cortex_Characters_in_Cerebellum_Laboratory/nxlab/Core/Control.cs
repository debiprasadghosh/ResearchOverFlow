namespace NxLab.Core;

/// <summary>Feedback gains as a bandwidth (rad/s in limb time, multiplied by λ) and a damping ratio.</summary>
public sealed record Gains(double Bandwidth, double Damping)
{
    public double Kp(Effector e) => Math.Pow(Bandwidth * e.Lambda, 2);
    public double Kd(Effector e) => 2 * Damping * Bandwidth * e.Lambda;
    public static readonly IReadOnlyList<double> Bandwidths = new[] { 2.0, 3, 4, 6, 8, 12, 16, 24, 32 };
    public static readonly IReadOnlyList<double> Dampings = new[] { 0.5, 0.8, 1.0 };
}

/// <summary>Motor noise (multiplicative on the command) and sensory noise on observed position and velocity.</summary>
public sealed record Noise(double Motor, double SensorP, double SensorV)
{
    public static Noise Default { get; } = new(0.02, 0.002, 0.02);
}

/// <summary>A planned utterance: phoneme targets in articulator space, starting from rest at the first target.</summary>
public sealed record Utterance(IReadOnlyList<double[]> Targets, IReadOnlyList<int> Phones);

/// <summary>
/// Planned duration of a gesture, T = (Ta + Tb·d)/λ, where d is the RMS distance between successive targets; a gesture
/// ends when the controller's estimate of the position is within Tol of the target and the planned time has passed.
/// </summary>
public sealed record Pacing(double Ta, double Tb, double Tol, double HitTol, double Timeout)
{
    public static Pacing Default { get; } = new(0.12, 0.45, 0.08, 0.12, 1.0);
}

public sealed record TrackResult(double Rms, IReadOnlyList<double[]> P, bool Stable);
public sealed record PacedResult(IReadOnlyList<double> Durations, IReadOnlyList<double> Distances, IReadOnlyList<double> Errors, double Total, IReadOnlyList<double[]> P, IReadOnlyList<int> Gesture);

/// <summary>
/// The control loop of the hybrid's character level: a posture-holding feedforward command plus proportional–derivative
/// feedback on an estimate of the current state. With a forward model the estimate is the delayed observation rolled
/// forward through the commands sent since (a Smith predictor); without one it is the delayed observation itself.
/// Per step the draws are: n motor-noise Gaussians, then n position-noise and n velocity-noise Gaussians.
/// </summary>
public static class Loop
{
    public static double MinJerk(double a, double b, double s, out double ds)
    {
        s = Math.Clamp(s, 0, 1);
        double f = 10 * s * s * s - 15 * s * s * s * s + 6 * s * s * s * s * s;
        ds = (b - a) * (30 * s * s - 60 * s * s * s + 30 * s * s * s * s);
        return a + (b - a) * f;
    }

    /// <summary>Point-to-point reaches with minimum-jerk profiles (movement T, hold H, targets uniform in ±amp), from rest at zero.</summary>
    public static (IReadOnlyList<double[]> R, IReadOnlyList<double[]> Rv, int StepsPerReach) Reaches(Effector e, int count, double moveT, double hold, double amp, Rng rng)
    {
        int n = e.Dof; double dt = Effector.Dt;
        var tg = new List<double[]> { new double[n] };
        var r = rng;
        for (int k = 0; k < count; k++) { var t = new double[n]; for (int i = 0; i < n; i++) { var (x, nr) = r.NextUniform(-amp, amp); r = nr; t[i] = x; } tg.Add(t); }
        double T = moveT / e.Lambda, Hd = hold / e.Lambda;
        int steps = (int)Math.Round((T + Hd) / dt);
        var R = new List<double[]>(); var Rv = new List<double[]>();
        for (int k = 0; k < count; k++)
            for (int s = 0; s < steps; s++)
            {
                var p = new double[n]; var v = new double[n];
                for (int i = 0; i < n; i++) { p[i] = MinJerk(tg[k][i], tg[k + 1][i], s * dt / T, out double ds); v[i] = ds / T; }
                R.Add(p); Rv.Add(v);
            }
        return (R, Rv, steps);
    }

    static void Estimate(Effector e, ForwardModel? model, int delay, int t, List<double[]> hp, List<double[]> hv, List<double[]> hu,
        Noise noise, ref Rng r, double[] pe, double[] ve, double[] acc)
    {
        int n = e.Dof, j = Math.Max(0, t - delay);
        for (int i = 0; i < n; i++)
        {
            var (g1, r1) = r.NextGaussian(); var (g2, r2) = r1.NextGaussian(); r = r2;
            pe[i] = hp[j][i] + noise.SensorP * g1;
            ve[i] = hv[j][i] + noise.SensorV * e.Lambda * g2;
        }
        if (model is null) return;
        for (int s = j; s < t; s++)
        {
            model.Accel(pe, ve, hu[s], acc);
            for (int i = 0; i < n; i++) { ve[i] += Effector.Dt * acc[i]; pe[i] += Effector.Dt * ve[i]; }
        }
    }

    static void Step(Effector e, double[] p, double[] v, double[] u, Noise noise, ref Rng r, double[] acc)
    {
        int n = e.Dof;
        var un = new double[n];
        for (int i = 0; i < n; i++) { var (g, nr) = r.NextGaussian(); r = nr; un[i] = u[i] * (1 + noise.Motor * g); }
        e.Accel(p, v, un, acc);
        for (int i = 0; i < n; i++) { v[i] += Effector.Dt * acc[i]; p[i] += Effector.Dt * v[i]; }
    }

    public static TrackResult Track(Effector e, ForwardModel? model, int delay, Gains gains, IReadOnlyList<double[]> R, IReadOnlyList<double[]> Rv, Noise noise, Rng rng)
    {
        int n = e.Dof; double kp = gains.Kp(e), kd = gains.Kd(e);
        var p = new double[n]; var v = new double[n]; var pe = new double[n]; var ve = new double[n]; var acc = new double[n]; var ff = new double[n];
        var hp = new List<double[]> { p.ToArray() }; var hv = new List<double[]> { v.ToArray() }; var hu = new List<double[]>();
        var P = new List<double[]>(R.Count);
        var r = rng; double se = 0;
        for (int t = 0; t < R.Count; t++)
        {
            Estimate(e, model, delay, t, hp, hv, hu, noise, ref r, pe, ve, acc);
            e.Feedforward(R[t], ff);
            var u = new double[n];
            for (int i = 0; i < n; i++) u[i] = e.Clip(ff[i] + kp * (R[t][i] - pe[i]) + kd * (Rv[t][i] - ve[i]));
            hu.Add(u);
            Step(e, p, v, u, noise, ref r, acc);
            for (int i = 0; i < n; i++)
            {
                if (!double.IsFinite(p[i]) || Math.Abs(p[i]) > 20) return new TrackResult(double.PositiveInfinity, P, false);
                se += (p[i] - R[t][i]) * (p[i] - R[t][i]);
            }
            hp.Add(p.ToArray()); hv.Add(v.ToArray()); P.Add(p.ToArray());
        }
        return new TrackResult(Math.Sqrt(se / (R.Count * (double)n)), P, true);
    }

    /// <summary>The gains (from the grid) that minimize tracking RMS on a tuning reference; this is the best a given loop can do.</summary>
    public static (Gains Best, double Rms) Tune(Effector e, ForwardModel? model, int delay, IReadOnlyList<double[]> R, IReadOnlyList<double[]> Rv, Noise noise, Rng rng)
    {
        var grid = Gains.Bandwidths.SelectMany(w => Gains.Dampings.Select(z => new Gains(w, z))).ToArray();
        var res = grid.AsParallel().AsOrdered().Select(g => (g, rms: Track(e, model, delay, g, R, Rv, noise, rng).Rms)).ToArray();
        var best = res.OrderBy(x => x.rms).ThenBy(x => x.g.Bandwidth).First();
        return (best.g, best.rms);
    }

    public static double Distance(IReadOnlyList<double> a, IReadOnlyList<double> b)
    {
        double s = 0; for (int i = 0; i < a.Count; i++) s += (a[i] - b[i]) * (a[i] - b[i]);
        return Math.Sqrt(s / a.Count);
    }

    /// <summary>
    /// A self-paced utterance: each gesture follows a minimum-jerk reference over its planned duration and ends when the
    /// estimated position is within the tolerance of its target (or after the timeout). Returns per-gesture durations,
    /// planned distances and the true position error when the gesture ended.
    /// </summary>
    public static PacedResult Paced(Effector e, ForwardModel? model, int delay, Gains gains, Utterance utt, Pacing plan, Noise noise, Rng rng)
    {
        int n = e.Dof; double kp = gains.Kp(e), kd = gains.Kd(e), dt = Effector.Dt;
        var tg = utt.Targets;
        var p = tg[0].ToArray(); var v = new double[n]; var pe = new double[n]; var ve = new double[n]; var acc = new double[n]; var ff = new double[n];
        var rr = new double[n];
        var hp = new List<double[]> { p.ToArray() }; var hv = new List<double[]> { v.ToArray() }; var hu = new List<double[]>();
        var durs = new List<double>(); var dists = new List<double>(); var errs = new List<double>();
        var traj = new List<double[]>(); var gest = new List<int>();
        var r = rng; int t = 0, k = 1; double start = 0;
        double Planned(int kk) => (plan.Ta + plan.Tb * Distance(tg[kk], tg[kk - 1])) / e.Lambda;
        double T = tg.Count > 1 ? Planned(1) : 0;
        while (k < tg.Count)
        {
            var rv = new double[n];
            for (int i = 0; i < n; i++) { rr[i] = MinJerk(tg[k - 1][i], tg[k][i], (t * dt - start) / T, out double ds); rv[i] = ds / T; }
            Estimate(e, model, delay, t, hp, hv, hu, noise, ref r, pe, ve, acc);
            e.Feedforward(rr, ff);
            var u = new double[n];
            for (int i = 0; i < n; i++) u[i] = e.Clip(ff[i] + kp * (rr[i] - pe[i]) + kd * (rv[i] - ve[i]));
            hu.Add(u);
            Step(e, p, v, u, noise, ref r, acc);
            hp.Add(p.ToArray()); hv.Add(v.ToArray()); t++;
            traj.Add(p.ToArray()); gest.Add(k);
            double el = t * dt - start;
            if ((el >= T && Distance(pe, tg[k]) <= plan.Tol) || el > plan.Timeout)
            {
                durs.Add(el); dists.Add(Distance(tg[k], tg[k - 1])); errs.Add(Distance(p, tg[k]));
                k++; start = t * dt;
                if (k < tg.Count) T = Planned(k);
            }
        }
        return new PacedResult(durs, dists, errs, t * dt, traj, gest);
    }

    /// <summary>A fixed random target in articulator space for each of the 39 phonemes (uniform in ±0.6).</summary>
    public static IReadOnlyList<double[]> PhoneTargets(int dof, Rng rng)
    {
        var r = rng; var outp = new double[Pronouncing.Phones.Count][];
        for (int k = 0; k < outp.Length; k++) { outp[k] = new double[dof]; for (int i = 0; i < dof; i++) { var (x, nr) = r.NextUniform(-0.6, 0.6); r = nr; outp[k][i] = x; } }
        return outp;
    }

    /// <summary>An utterance from words: rest posture (zeros) then the phoneme targets of each word in turn.</summary>
    public static Utterance Utter(IEnumerable<string> words, Pronouncing cmu, IReadOnlyList<double[]> phoneTargets, int dof)
    {
        var tg = new List<double[]> { new double[dof] }; var ph = new List<int> { -1 };
        foreach (var w in words)
            foreach (var x in cmu.Primary(w)) { int k = Pronouncing.IndexOf(x); tg.Add(phoneTargets[k]); ph.Add(k); }
        return new Utterance(tg, ph);
    }
}
