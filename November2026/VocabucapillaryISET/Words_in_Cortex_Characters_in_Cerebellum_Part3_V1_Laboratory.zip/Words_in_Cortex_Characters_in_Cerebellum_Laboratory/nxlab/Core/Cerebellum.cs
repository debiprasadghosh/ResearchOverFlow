using System.Collections.Immutable;

namespace NxLab.Core;

/// <summary>
/// One cerebellar microzone: the forward model of one degree of freedom. Its mossy-fibre inputs are the standardized
/// position, velocity and command of its own degree of freedom and the position and velocity of the neighbouring one.
/// Each granule cell sums K randomly chosen inputs with random weights and fires above a threshold set so that it is
/// active on a fraction f of the calibration inputs (a sparse positive code). The output is a nuclear pathway linear in
/// the mossy inputs plus a Purkinje pathway linear in the granule code: a record over granule cells read by a vector.
/// </summary>
public sealed record Microzone(int K, ImmutableArray<int> Idx, ImmutableArray<double> W, ImmutableArray<double> Theta,
    ImmutableArray<double> GScale, ImmutableArray<double> InScale, ImmutableArray<double> Readout)
{
    public const int Inputs = 5;
    public int Cells => Theta.Length;

    public static void MossyInputs(ReadOnlySpan<double> p, ReadOnlySpan<double> v, ReadOnlySpan<double> u, int i, Span<double> x)
    {
        x[0] = p[i]; x[1] = v[i]; x[2] = u[i];
        x[3] = i > 0 ? p[i - 1] : 0.0; x[4] = i > 0 ? v[i - 1] : 0.0;
    }

    /// <summary>Granule activity of every cell for standardized inputs z (0 for silent cells).</summary>
    public void Granule(ReadOnlySpan<double> z, Span<double> act)
    {
        for (int j = 0; j < Cells; j++)
        {
            double h = 0;
            for (int k = 0; k < K; k++) h += W[j * K + k] * z[Idx[j * K + k]];
            double a = h - Theta[j];
            act[j] = a > 0 ? a / GScale[j] : 0.0;
        }
    }

    public double Predict(ReadOnlySpan<double> x)
    {
        Span<double> z = stackalloc double[Inputs];
        for (int k = 0; k < Inputs; k++) z[k] = x[k] / InScale[k];
        double y = Readout[Inputs];                                          // bias
        for (int k = 0; k < Inputs; k++) y += Readout[k] * z[k];             // nuclear pathway
        for (int j = 0; j < Cells; j++)
        {
            double h = 0;
            for (int k = 0; k < K; k++) h += W[j * K + k] * z[Idx[j * K + k]];
            double a = h - Theta[j];
            if (a > 0) y += Readout[Inputs + 1 + j] * a / GScale[j];         // Purkinje pathway over active granule cells
        }
        return y;
    }
}

/// <summary>A learned forward model: one microzone per degree of freedom. With zero granule cells it is the nuclear (linear) pathway alone.</summary>
public sealed record GranuleModel(string Label, Effector E, IReadOnlyList<Microzone> Zones) : ForwardModel(Label)
{
    public override void Accel(ReadOnlySpan<double> p, ReadOnlySpan<double> v, ReadOnlySpan<double> u, Span<double> a)
    {
        Span<double> x = stackalloc double[Microzone.Inputs];
        for (int i = 0; i < E.Dof; i++) { Microzone.MossyInputs(p, v, u, i, x); a[i] = Zones[i].Predict(x); }
    }

    public double ActiveShare(IReadOnlyList<double[]> xs, int zone)
    {
        var z = Zones[zone]; var act = new double[z.Cells]; Span<double> s = stackalloc double[Microzone.Inputs];
        double on = 0;
        foreach (var x in xs)
        {
            for (int k = 0; k < Microzone.Inputs; k++) s[k] = x[k] / z.InScale[k];
            z.Granule(s, act);
            on += act.Count(a => a > 0);
        }
        return on / (xs.Count * (double)Math.Max(1, z.Cells));
    }
}

/// <summary>Exploration data for learning forward models: mossy inputs per degree of freedom and the true accelerations.</summary>
public sealed record Excitation(Effector E, IReadOnlyList<double[]> P, IReadOnlyList<double[]> V, IReadOnlyList<double[]> U, IReadOnlyList<double[]> A)
{
    public int Steps => P.Count;

    public double[] Inputs(int t, int i)
    {
        var x = new double[Microzone.Inputs];
        Microzone.MossyInputs(P[t], V[t], U[t], i, x);
        return x;
    }

    /// <summary>
    /// The effector is driven towards random targets that change every 0.25 s of its own time, by a proportional–derivative
    /// command whose bandwidth changes with each target (6, 12, 24 or 36 rad/s times λ), plus Ornstein–Uhlenbeck noise;
    /// the command is bounded. Draw order per segment: targets, then the bandwidth; per step: one Gaussian per degree of freedom.
    /// </summary>
    public static Excitation Make(Effector e, int steps, Rng rng)
    {
        int n = e.Dof; double lam = e.Lambda, dt = Effector.Dt;
        var p = new double[n]; var v = new double[n]; var tgt = new double[n]; var ou = new double[n]; var a = new double[n]; var u = new double[n];
        var P = new double[steps][]; var V = new double[steps][]; var U = new double[steps][]; var A = new double[steps][];
        int seg = (int)Math.Round(0.25 / lam / dt);
        double w = 10 * lam;
        double[] bands = { 6, 12, 24, 36 };
        var r = rng;
        for (int t = 0; t < steps; t++)
        {
            if (t % seg == 0)
            {
                for (int i = 0; i < n; i++) { var (x, r1) = r.NextUniform(-0.8, 0.8); r = r1; tgt[i] = x; }
                var (b, r2) = r.NextInt(bands.Length); r = r2; w = bands[b] * lam;
            }
            for (int i = 0; i < n; i++)
            {
                var (g, r3) = r.NextGaussian(); r = r3;
                ou[i] += -ou[i] * dt * 20 * lam + Math.Sqrt(dt) * g * 80 * lam * lam;
                u[i] = e.Clip(w * w * (tgt[i] - p[i]) - 2 * 0.6 * w * v[i] + ou[i]);
            }
            e.Accel(p, v, u, a);
            P[t] = p.ToArray(); V[t] = v.ToArray(); U[t] = u.ToArray(); A[t] = a.ToArray();
            for (int i = 0; i < n; i++) { v[i] += dt * a[i]; p[i] += dt * v[i]; }
        }
        return new Excitation(e, P, V, U, A);
    }
}

public static class Cerebellum
{
    /// <summary>Granule wiring and thresholds of one microzone; draw order per cell: K distinct inputs, then K weights.</summary>
    static (int[] Idx, double[] W, double[] Theta, double[] Scale) Wire(int cells, int k, double coding, double[][] zCal, Rng rng)
    {
        var idx = new int[cells * k]; var w = new double[cells * k];
        var r = rng;
        for (int j = 0; j < cells; j++)
        {
            var chosen = new List<int>();
            while (chosen.Count < k) { var (c, r1) = r.NextInt(Microzone.Inputs); r = r1; if (!chosen.Contains(c)) chosen.Add(c); }
            for (int q = 0; q < k; q++) { var (g, r2) = r.NextGaussian(); r = r2; idx[j * k + q] = chosen[q]; w[j * k + q] = g; }
        }
        var theta = new double[cells]; var scale = new double[cells];
        var h = new double[zCal.Length];
        for (int j = 0; j < cells; j++)
        {
            for (int t = 0; t < zCal.Length; t++) { double s = 0; for (int q = 0; q < k; q++) s += w[j * k + q] * zCal[t][idx[j * k + q]]; h[t] = s; }
            var sorted = h.OrderBy(x => x).ToArray();
            theta[j] = sorted[(int)Math.Floor((1 - coding) * (sorted.Length - 1))];
            double ss = 0; foreach (var x in h) { double a = Math.Max(0, x - theta[j]); ss += a * a; }
            scale[j] = Math.Sqrt(ss / h.Length) + 1e-9;
        }
        return (idx, w, theta, scale);
    }

    static double[] InputScale(Excitation data, int i)
    {
        var s = new double[Microzone.Inputs];
        for (int k = 0; k < Microzone.Inputs; k++)
        {
            double m = 0, m2 = 0;
            for (int t = 0; t < data.Steps; t++) { var x = data.Inputs(t, i)[k]; m += x; m2 += x * x; }
            m /= data.Steps; double var = m2 / data.Steps - m * m;
            s[k] = var > 1e-18 ? Math.Sqrt(var) : 1.0;
        }
        return s;
    }

    /// <summary>
    /// Fits a forward model: granule wiring from the generator, thresholds from the first 5,000 samples, and the readout by
    /// regularized least squares (ridge α·N), the fixed point of the climbing-fibre delta rule with weight decay. The normal
    /// equations are accumulated over active granule cells only.
    /// </summary>
    public static GranuleModel Fit(string label, Excitation data, int cells, int k, double coding, double alpha, ulong seed)
    {
        int n = data.E.Dof;
        var zones = Enumerable.Range(0, n).AsParallel().AsOrdered().Select(i =>
        {
            var inScale = InputScale(data, i);
            double[] Z(int t) { var x = data.Inputs(t, i); for (int q = 0; q < Microzone.Inputs; q++) x[q] /= inScale[q]; return x; }
            var zCal = Enumerable.Range(0, Math.Min(5000, data.Steps)).Select(Z).ToArray();
            var (idx, w, theta, gscale) = cells > 0 ? Wire(cells, k, coding, zCal, Rng.Derive(seed, 100 + (ulong)i)) : (Array.Empty<int>(), Array.Empty<double>(), Array.Empty<double>(), Array.Empty<double>());
            var tmp = new Microzone(k, idx.ToImmutableArray(), w.ToImmutableArray(), theta.ToImmutableArray(), gscale.ToImmutableArray(), inScale.ToImmutableArray(), new double[Microzone.Inputs + 1 + cells].ToImmutableArray());
            int dim = Microzone.Inputs + 1 + cells;
            var g = new double[dim, dim]; var b = new double[dim, 1];
            var act = new double[cells]; var f = new List<(int Col, double Val)>(64);
            for (int t = 0; t < data.Steps; t++)
            {
                var z = Z(t);
                f.Clear();
                for (int q = 0; q < Microzone.Inputs; q++) f.Add((q, z[q]));
                f.Add((Microzone.Inputs, 1.0));
                if (cells > 0) { tmp.Granule(z, act); for (int j = 0; j < cells; j++) if (act[j] > 0) f.Add((Microzone.Inputs + 1 + j, act[j])); }
                double y = data.A[t][i];
                foreach (var (c1, v1) in f) { b[c1, 0] += v1 * y; foreach (var (c2, v2) in f) if (c2 <= c1) g[c1, c2] += v1 * v2; }
            }
            for (int r = 0; r < dim; r++) for (int c = 0; c < r; c++) g[c, r] = g[r, c];
            var sol = Mat.CholeskySolve(g, alpha * data.Steps, b);
            var readout = Enumerable.Range(0, dim).Select(r => sol[r, 0]).ToArray();
            return tmp with { Readout = readout.ToImmutableArray() };
        }).ToArray();
        return new GranuleModel(label, data.E, zones);
    }

    /// <summary>RMS of the prediction error over all degrees of freedom divided by the SD of the true accelerations.</summary>
    public static double NormalizedError(ForwardModel model, Excitation test)
    {
        int n = test.E.Dof; var a = new double[n];
        double se = 0, s1 = 0, s2 = 0; long cnt = 0;
        for (int t = 0; t < test.Steps; t++)
        {
            model.Accel(test.P[t], test.V[t], test.U[t], a);
            for (int i = 0; i < n; i++) { double y = test.A[t][i]; se += (a[i] - y) * (a[i] - y); s1 += y; s2 += y * y; cnt++; }
        }
        double mean = s1 / cnt, var = s2 / cnt - mean * mean;
        return Math.Sqrt(se / cnt / var);
    }

    /// <summary>
    /// Position error after rolling a model D steps from the true state with the true commands (RMS over degrees of freedom
    /// and windows); a null model holds the delayed observation, which is the error of acting on delayed feedback.
    /// </summary>
    public static double RolloutError(ForwardModel? model, Excitation test, int delay, int windows)
    {
        int n = test.E.Dof; double dt = Effector.Dt;
        var pe = new double[n]; var ve = new double[n]; var a = new double[n];
        double se = 0; long cnt = 0;
        int step = Math.Max(1, (test.Steps - delay - 1) / windows);
        for (int t0 = 0; t0 + delay < test.Steps; t0 += step)
        {
            Array.Copy(test.P[t0], pe, n); Array.Copy(test.V[t0], ve, n);
            if (model is not null)
                for (int s = t0; s < t0 + delay; s++)
                {
                    model.Accel(pe, ve, test.U[s], a);
                    for (int i = 0; i < n; i++) { ve[i] += dt * a[i]; pe[i] += dt * ve[i]; }
                }
            for (int i = 0; i < n; i++) { double d = pe[i] - test.P[t0 + delay][i]; se += d * d; cnt++; }
        }
        return Math.Sqrt(se / cnt);
    }

    /// <summary>
    /// The climbing-fibre delta rule on one microzone: normalized LMS on the standardized acceleration, step η/(1 + epoch),
    /// samples in a shuffled order per epoch; returns the normalized test error after each epoch.
    /// </summary>
    public static IReadOnlyList<double> DeltaRuleCurve(Excitation train, Excitation test, Microzone wiring, int zone, int epochs, double eta, ulong seed)
    {
        int dim = Microzone.Inputs + 1 + wiring.Cells;
        double ym = train.A.Average(x => x[zone]), ys = Math.Sqrt(train.A.Average(x => (x[zone] - ym) * (x[zone] - ym)));
        double[] Features(Excitation d, int t)
        {
            var x = d.Inputs(t, zone); var f = new double[dim];
            for (int q = 0; q < Microzone.Inputs; q++) f[q] = x[q] / wiring.InScale[q];
            f[Microzone.Inputs] = 1.0;
            var act = new double[wiring.Cells];
            wiring.Granule(f.AsSpan(0, Microzone.Inputs), act);
            Array.Copy(act, 0, f, Microzone.Inputs + 1, wiring.Cells);
            return f;
        }
        var ftr = Enumerable.Range(0, train.Steps).Select(t => Features(train, t)).ToArray();
        var fte = Enumerable.Range(0, test.Steps).Select(t => Features(test, t)).ToArray();
        var w = new double[dim]; var curve = new List<double>();
        var order = Enumerable.Range(0, train.Steps).ToArray();
        var r = Rng.Derive(seed, 77);
        double tm = test.A.Average(x => x[zone]), tv = test.A.Average(x => (x[zone] - tm) * (x[zone] - tm));
        for (int ep = 0; ep < epochs; ep++)
        {
            for (int k = order.Length - 1; k > 0; k--) { var (j, nr) = r.NextInt(k + 1); r = nr; (order[k], order[j]) = (order[j], order[k]); }
            double step = eta / (1 + ep);
            foreach (int t in order)
            {
                var f = ftr[t]; double pred = 0, nn = 1.0;
                for (int q = 0; q < dim; q++) { pred += w[q] * f[q]; nn += f[q] * f[q]; }
                double err = (train.A[t][zone] - ym) / ys - pred;
                for (int q = 0; q < dim; q++) if (f[q] != 0) w[q] += step * err * f[q] / nn;
            }
            double se = 0;
            for (int t = 0; t < test.Steps; t++) { double pred = 0; for (int q = 0; q < dim; q++) pred += w[q] * fte[t][q]; double d = pred * ys + ym - test.A[t][zone]; se += d * d; }
            curve.Add(Math.Sqrt(se / test.Steps / tv));
        }
        return curve;
    }
}
