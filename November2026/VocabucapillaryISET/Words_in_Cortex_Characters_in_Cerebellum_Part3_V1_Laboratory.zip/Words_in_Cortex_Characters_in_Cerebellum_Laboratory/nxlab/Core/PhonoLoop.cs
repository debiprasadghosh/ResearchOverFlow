namespace NxLab.Core;

/// <summary>
/// Parameters of the phonological loop: one item every Presentation seconds; a trace survives Decay seconds after its
/// last refresh (scaled per trial by exp(DecaySd·g)); covert rehearsal cycles through the items presented so far,
/// restarting from the first item after each new item, and each rehearsal takes the item's articulation time plus Gap;
/// recall is by a non-spoken response taking OutputTime per item, in order. Under articulatory suppression there is no
/// rehearsal. An encoding failure loses an item at presentation.
/// </summary>
public sealed record LoopParams(double Presentation, double Decay, double DecaySd, double OutputTime, double Gap)
{
    public static LoopParams Default { get; } = new(1.0, 3.5, 0.25, 0.5, 0.05);
}

public static class PhonoLoop
{
    /// <summary>One list. Draw order: the decay scale, then one uniform per item for encoding.</summary>
    public static (bool AllCorrect, int Correct, Rng Next) Trial(IReadOnlyList<double> durations, LoopParams lp, bool rehearse, double encodeFail, Rng rng)
    {
        int n = durations.Count;
        var (g, r1) = rng.NextGaussian();
        double decay = lp.Decay * Math.Exp(lp.DecaySd * g);
        var r = r1;
        var last = new double[n]; var alive = new bool[n];
        for (int i = 0; i < n; i++) { var (u, nr) = r.NextDouble(); r = nr; alive[i] = u >= encodeFail; last[i] = i * lp.Presentation; }
        bool Alive(int i, double time) => alive[i] && time - last[i] <= decay;
        double recallStart = n * lp.Presentation;
        if (rehearse)
        {
            // Event loop: the rehearser works between the first presentation and the start of recall.
            double time = 0; int presented = 1, next = 0;
            while (time < recallStart)
            {
                double nextPresentation = presented < n ? presented * lp.Presentation : double.PositiveInfinity;
                if (time >= nextPresentation) { presented++; next = 0; continue; }
                // Skip items already lost; if none is alive, wait for the next presentation.
                int tries = 0;
                while (tries < presented && !Alive(next, time)) { next = (next + 1) % presented; tries++; }
                if (tries == presented) { time = Math.Min(nextPresentation, recallStart); continue; }
                double end = time + durations[next] + lp.Gap;
                if (end > recallStart) break;
                if (Alive(next, time)) last[next] = end;
                time = end;
                next = (next + 1) % presented;
                if (time >= nextPresentation) { presented++; next = 0; }
            }
        }
        int correct = 0; bool all = true;
        for (int i = 0; i < n; i++)
        {
            double tr = recallStart + i * lp.OutputTime;
            if (Alive(i, tr)) correct++; else all = false;
        }
        return (all, correct, r);
    }

    /// <summary>Recall of lists of one length: the share of lists recalled perfectly and the mean share of items recalled.</summary>
    public sealed record RecallStats(double Perfect, double Items);

    /// <summary>
    /// Recall of lists of length n over the given trials (items drawn from the pool without replacement by a partial
    /// Fisher–Yates shuffle per trial; trace lifetimes multiplied by lifetimeFactor).
    /// </summary>
    public static RecallStats Recall(IReadOnlyList<double> pool, int n, int trials, LoopParams lp, bool rehearse, double encodeFail, Rng rng, double lifetimeFactor = 1.0)
    {
        var r = rng; int ok = 0; long items = 0;
        var lpx = lp with { Decay = lp.Decay * lifetimeFactor };
        var idx = Enumerable.Range(0, pool.Count).ToArray();
        for (int t = 0; t < trials; t++)
        {
            for (int k = 0; k < n; k++) { var (j, nr) = r.NextInt(pool.Count - k); r = nr; (idx[k], idx[k + j]) = (idx[k + j], idx[k]); }
            var durs = idx.Take(n).Select(i => pool[i]).ToArray();
            var (all, correct, nr2) = Trial(durs, lpx, rehearse, encodeFail, r); r = nr2;
            if (all) ok++;
            items += correct;
        }
        return new RecallStats(ok / (double)trials, items / ((double)trials * n));
    }

    /// <summary>Span: the list length at which perfect recall falls to one half, interpolated linearly between lengths.</summary>
    public static double Span(IReadOnlyList<double> perfect, int nMin)
    {
        for (int k = 0; k < perfect.Count; k++)
            if (perfect[k] < 0.5)
            {
                if (k == 0) return nMin - 0.5;
                double p0 = perfect[k - 1], p1 = perfect[k];
                return nMin + k - 1 + (p0 - 0.5) / (p0 - p1);
            }
        return nMin + perfect.Count - 1;
    }
}
