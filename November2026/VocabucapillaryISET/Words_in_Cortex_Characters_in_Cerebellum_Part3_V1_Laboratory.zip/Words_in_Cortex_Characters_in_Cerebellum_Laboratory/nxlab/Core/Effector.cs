namespace NxLab.Core;

/// <summary>
/// A chain of n degrees of freedom driven by bounded commands. Per degree of freedom i, in the effector's own time scale:
/// a = u / (1 + |v| / (V₀λ)) − 2ζωv − ω²p − γω² sin p − cω² p_{i−1}² p,  with ω = 2πλ.
/// The first term is a Hill-type force–velocity relation (force falls with speed), then damping, passive stiffness, a
/// gravity-like term and an interaction term with the neighbouring degree of freedom. The limb has λ = 1 and seven
/// degrees of freedom; the articulators are the same dynamics run λ = 10/3 times faster, with six degrees of freedom.
/// Integration is semi-implicit Euler with a 5 ms step.
/// </summary>
public sealed record Effector(string Name, int Dof, double Lambda)
{
    public const double W0 = 2 * Math.PI, Zeta = 0.3, Gamma = 0.5, Coupling = 0.8, UMax = 400.0, V0 = 2.0, Dt = 0.005;

    public static Effector Limb { get; } = new("limb", 7, 1.0);
    public static Effector Articulators { get; } = new("articulators", 6, 10.0 / 3.0);

    public double Omega => W0 * Lambda;
    public double ULimit => UMax * Lambda * Lambda;
    public double Clip(double u) => Math.Clamp(u, -ULimit, ULimit);

    public double Passive(double p, double v, double pPrev)
    {
        double w = Omega;
        return -2 * Zeta * w * v - w * w * p - Gamma * w * w * Math.Sin(p) - Coupling * w * w * pPrev * pPrev * p;
    }

    public double ForceVelocity(double v) => 1.0 / (1.0 + Math.Abs(v) / (V0 * Lambda));

    /// <summary>True accelerations of every degree of freedom.</summary>
    public void Accel(ReadOnlySpan<double> p, ReadOnlySpan<double> v, ReadOnlySpan<double> u, Span<double> a)
    {
        for (int i = 0; i < Dof; i++)
            a[i] = u[i] * ForceVelocity(v[i]) + Passive(p[i], v[i], i > 0 ? p[i - 1] : 0.0);
    }

    /// <summary>The posture-holding command at a reference position: it cancels the passive forces at rest.</summary>
    public void Feedforward(ReadOnlySpan<double> r, Span<double> ff)
    {
        for (int i = 0; i < Dof; i++) ff[i] = -Passive(r[i], 0.0, i > 0 ? r[i - 1] : 0.0);
    }
}

/// <summary>A forward model: predicted accelerations from the state and the efference copy of the command.</summary>
public abstract record ForwardModel(string Name)
{
    public abstract void Accel(ReadOnlySpan<double> p, ReadOnlySpan<double> v, ReadOnlySpan<double> u, Span<double> a);
}

/// <summary>The ideal forward model: the effector's own equations.</summary>
public sealed record ExactModel(Effector E) : ForwardModel("exact")
{
    public override void Accel(ReadOnlySpan<double> p, ReadOnlySpan<double> v, ReadOnlySpan<double> u, Span<double> a) => E.Accel(p, v, u, a);
}
