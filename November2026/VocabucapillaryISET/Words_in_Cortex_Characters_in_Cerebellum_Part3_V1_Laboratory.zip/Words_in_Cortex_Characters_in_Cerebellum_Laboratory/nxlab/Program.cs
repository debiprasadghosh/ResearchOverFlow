using System.Diagnostics;
using NxLab.Core;
using NxLab.Experiments;

// Composition root: loads the word list and the pronouncing dictionary once, schedules the studies and performs the only file writes.
string data = Environment.GetEnvironmentVariable("NX_DATA") ?? Path.Combine("..", "data", "large_en.msgpack.gz");
string cmuPath = Environment.GetEnvironmentVariable("NX_CMU") ?? Path.Combine("..", "data", "cmudict.dict");
string outDir = Environment.GetEnvironmentVariable("NX_OUT") ?? Path.Combine("..", "out");
var swLoad = Stopwatch.StartNew();
var ctx = new Context(Lexicon.Load(data, 50_000), Pronouncing.Load(cmuPath), data);
Console.WriteLine($"lexicon: {ctx.Lex.Words.Count} words, pronouncing dictionary: {ctx.Cmu.Entries.Count} headwords, loaded in {swLoad.Elapsed.TotalSeconds:F1} s");
var registry = new (string Id, Func<Context, ExperimentResult> Run)[]
{
    ("N00", N00_Primitives.Run),
    ("N01", N01_Operator.Run),
    ("N02", N02_Loops.Run),
    ("N03", N03_PhonologicalLoop.Run),
};
var selected = args.Length == 0 ? registry : registry.Where(r => args.Contains(r.Id)).ToArray();
var results = new List<ExperimentResult>();
foreach (var (id, run) in selected)
{
    var sw = Stopwatch.StartNew();
    var r = run(ctx);
    sw.Stop();
    results.Add(r);
    Console.WriteLine($"{id} {r.Title}: {sw.Elapsed.TotalSeconds:F1} s");
    foreach (var kv in r.Headlines) Console.WriteLine($"   {kv.Key} = {kv.Value:G6}");
}
Output.Write(outDir, results);

namespace NxLab.Experiments
{
    /// <summary>What every study receives: the 50,000-word lexicon, the pronouncing dictionary and the word-list path.</summary>
    public sealed record Context(Lexicon Lex, Pronouncing Cmu, string DataPath);
}
