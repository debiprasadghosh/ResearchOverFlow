"""Independent Python cross-check of the Part 3 laboratory (words in cortex, characters in the cerebellum).

Decodes the wordfreq file with its own MessagePack reader and the CMU Pronouncing Dictionary with its own loader, and
recomputes: the N00 accounting (coverage, units per word, homophones, uniqueness points, the open-vocabulary curve with
a vectorized generator, attention pairs); the N01 exploration data, the delayed-observation and exact rollouts, and the
granule forward models refitted with numpy; the N02 gain tuning, tracking and self-paced utterances for the exact model
and for no model; the N03 word pools, lesioned articulation times, intact articulation times with the refitted granule
model, and every span and item share from the C# articulation times.
Usage: python3 crosscheck.py [out_folder] [data_folder]
"""
import bisect, csv, json, math, sys, time
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nxport as X

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "out"
DATA = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / "data"
H = json.load(open(OUT / "headlines.json"))
rows = []
T0 = time.time()


def check(name, cs, py, tol, rel=False):
    d = abs(cs - py) if not (math.isinf(cs) and math.isinf(py)) else 0.0
    lim = tol * max(1.0, abs(cs)) if rel else tol
    ok = d <= lim
    rows.append((name, cs, py, d, tol, "relative" if rel else "absolute", ok))
    print(f"{'ok ' if ok else 'BAD'} {name}: C# {cs:.10g}  Py {py:.10g}  ({time.time() - T0:.0f} s)", flush=True)


def table(name):
    with open(OUT / f"{name}.csv") as fh: return list(csv.DictReader(fh))


root = X.Lexicon.root(DATA / "large_en.msgpack.gz")
lex = X.Lexicon(root, 50000)
cmu = X.load_cmu(DATA / "cmudict.dict")

# ---------- N00 ----------
covered = [i for i, w in enumerate(lex.words) if w in cmu]
cmass = 0.0
for i in covered: cmass += lex.prob[i]
check("N00 covered words", H["N00.covered_words"], len(covered), 0)
check("N00 covered token share", H["N00.covered_token_share"], cmass, 1e-12)
L = Ph = Sy = 0.0
for i in covered:
    pr = cmu[lex.words[i]][0]; w = lex.prob[i] / cmass
    L += w * len(lex.words[i]); Ph += w * len(pr); Sy += w * X.syllables(pr)
check("N00 letters per word (token-weighted)", H["N00.letters_per_word"], L, 1e-12)
check("N00 phonemes per word (token-weighted)", H["N00.phonemes_per_word"], Ph, 1e-12)
check("N00 syllables per word (token-weighted)", H["N00.syllables_per_word"], Sy, 1e-12)
check("N00 phonemes per type", H["N00.phonemes_per_type"], np.mean([len(cmu[lex.words[i]][0]) for i in covered]), 1e-12)
check("N00 phonemes per second at 2.5 words/s", H["N00.phonemes_per_second"], 2.5 * Ph, 1e-12)
groups = {}
for i in covered: groups.setdefault(" ".join(cmu[lex.words[i]][0]), []).append(i)
hom = [g for g in groups.values() if len(g) > 1]
check("N00 homophone sets", H["N00.homophone_sets"], len(hom), 0)
check("N00 words in homophone sets", H["N00.homophone_words"], sum(len(g) for g in hom), 0)
check("N00 homophone token share", H["N00.homophone_token_share"], sum(lex.prob[i] for g in hom for i in g) / cmass, 1e-12)
multi = [i for i in covered if len({" ".join(p) for p in cmu[lex.words[i]]}) > 1]
check("N00 words with several pronunciations", H["N00.multi_pron_words"], len(multi), 0)


def uniqueness(items):
    count = {}
    for u, _ in items:
        for k in range(1, len(u) + 1): count[tuple(u[:k])] = count.get(tuple(u[:k]), 0) + 1
    mass = sum(p for _, p in items); nu = up_frac = after = umass = 0.0; nut = 0
    for u, p in items:
        up = next((k for k in range(1, len(u) + 1) if count[tuple(u[:k])] == 1), -1)
        if up < 0: nu += p; nut += 1; continue
        up_frac += p * up / len(u); after += p * (len(u) - up); umass += p
    return nu / mass, up_frac / umass, after / umass, nut / len(items)


for tag, items in (("phon", [(cmu[lex.words[i]][0], lex.prob[i]) for i in covered]), ("let", [(list(lex.words[i]), lex.prob[i]) for i in covered])):
    a, b, c, d = uniqueness(items)
    check(f"N00 uniqueness ({tag}): tokens not unique by the word's end", H[f"N00.up_{tag}_not_unique_tokens"], a, 1e-10)
    check(f"N00 uniqueness ({tag}): uniqueness point over length", H[f"N00.up_{tag}_fraction"], b, 1e-10)
    check(f"N00 uniqueness ({tag}): units after the uniqueness point", H[f"N00.up_{tag}_after"], c, 1e-10)
    check(f"N00 uniqueness ({tag}): types not unique", H[f"N00.up_{tag}_not_unique_types"], d, 1e-12)
full = X.Lexicon(root, 10 ** 9)
check("N00 full alphabetic list (words up to 16 letters)", H["N00.full_list_words"], len(full.words), 0)
cdf = np.array(full.cdf); prob = np.array(full.prob)
u = X.doubles_vectorized(X.Rng.derive(800, 1), 10_000_000)
draw = np.minimum(np.searchsorted(cdf, u * cdf[-1], side="right"), len(cdf) - 1)
uniq, first = np.unique(draw, return_index=True)
order = np.argsort(first); first_sorted = first[order]; seen_mass = np.cumsum(prob[uniq[order]])
for N in (1_000, 10_000, 100_000, 1_000_000, 10_000_000):
    m = int(np.searchsorted(first_sorted, N))
    check(f"N00 distinct words after {N:,} tokens", H[f"N00.distinct_N{N}"], m, 0)
    check(f"N00 probability the next token is new after {N:,} tokens", H[f"N00.oov_N{N}"], 1 - seen_mass[m - 1], 1e-12)
check("N00 causal pairs per minute, phonemes", H["N00.pairs_phonemes"], (2.5 * Ph * 60) * (2.5 * Ph * 60 + 1) / 2, 1e-6)

# ---------- N01 ----------
for e, ei in ((X.LIMB, 0), (X.ARTICULATORS, 1)):
    test = X.excitation(e, 6000, X.Rng.derive(801, 20 + ei))
    check(f"N01 {e.name}: 60 ms error of the delayed observation", H[f"N01.{e.name}_rollout_none"], X.rollout_error(None, test, 12, 1000), 1e-12)
    check(f"N01 {e.name}: 60 ms error of the exact equations", H[f"N01.{e.name}_rollout_exact"], X.rollout_error(X.Exact(e), test, 12, 1000), 1e-12)
    if ei == 1:
        train = X.excitation(e, 30000, X.Rng.derive(801, 10 + ei))
        for m in (0, 256, 1024):
            model = X.fit(train, m, 4, 0.1, 1e-6, 801 + 1000 * ei + m)
            check(f"N01 articulators, {m} granule cells: acceleration error", H[f"N01.articulators_m{m}_acc_error"], X.normalized_error(model, test), 1e-6, rel=True)
            if m == 256:
                check(f"N01 articulators, {m} granule cells: 60 ms rollout", H[f"N01.articulators_m{m}_rollout"], X.rollout_error(model, test, 12, 1000), 1e-6, rel=True)
        model = X.fit(train, 1024, 2, 0.1, 1e-6, 801 + 5000 + 2)
        check("N01 sweep K = 2: acceleration error", H["N01.sweep_K2_acc_error"], X.normalized_error(model, test), 1e-6, rel=True)

# ---------- N02 ----------
art = X.ARTICULATORS
Rt, Rvt, _ = X.reaches(art, 8, 0.4, 0.2, 0.8, X.Rng.derive(8200, 31))
g_exact = X.tune(art, X.Exact(art), 12, Rt, Rvt, X.Rng.derive(8200, 51))
g_none = X.tune(art, None, 12, Rt, Rvt, X.Rng.derive(8200, 51))
trk = {(r["effector"], r["delay_ms"], r["forward_model"]): r for r in table("N02_tracking")}
check("N02 tuned bandwidth at 60 ms, exact model", float(trk[("articulators", "60", "exact")]["bandwidth"]), g_exact[0], 0)
check("N02 tuned damping at 60 ms, exact model", float(trk[("articulators", "60", "exact")]["damping"]), g_exact[1], 0)
check("N02 tuned bandwidth at 60 ms, no model", float(trk[("articulators", "60", "none")]["bandwidth"]), g_none[0], 0)
check("N02 tuned damping at 60 ms, no model", float(trk[("articulators", "60", "none")]["damping"]), g_none[1], 0)
Re, Rve, _ = X.reaches(art, 12, 0.4, 0.2, 0.8, X.Rng.derive(8200, 41))
check("N02 articulators tracking RMS at 60 ms, exact model", H["N02.articulators_D60_exact_rms"], X.track(art, X.Exact(art), 12, g_exact, Re, Rve, X.Rng.derive(802, 60 + 100 + 12)), 1e-12)
check("N02 articulators tracking RMS at 60 ms, no model", H["N02.articulators_D60_none_rms"], X.track(art, None, 12, g_none, Re, Rve, X.Rng.derive(802, 60 + 100 + 12)), 1e-12)
limb = X.LIMB
gl = (float(trk[("limb", "60", "none")]["bandwidth"]), float(trk[("limb", "60", "none")]["damping"]))
Rl, Rvl, _ = X.reaches(limb, 12, 0.4, 0.2, 0.8, X.Rng.derive(8200, 40))
check("N02 limb tracking RMS at 60 ms, no model (C# gains)", H["N02.limb_D60_none_rms"], X.track(limb, None, 12, gl, Rl, Rvl, X.Rng.derive(802, 60 + 12)), 1e-12)
ph = X.phone_targets(art.dof, X.Rng.derive(8300, 1))
r = X.Rng.derive(802, 1); utts = []
for _ in range(30): utts.append(X.utter(X.sample_words(lex, cmu, 10, r), cmu, ph, art.dof))


def stats(res):
    d = [x for rr in res for x in rr[0]]; dist = [x for rr in res for x in rr[1]]; err = [x for rr in res for x in rr[2]]
    order = sorted(range(len(d)), key=lambda i: (dist[i], i)); q = len(d) // 4
    return dict(rate=len(d) / sum(d), corr=float(np.corrcoef(d, dist)[0, 1]),
                contrast=np.mean([d[i] for i in order[-q:]]) / np.mean([d[i] for i in order[:q]]),
                hit=np.mean([1.0 if x <= 0.12 else 0.0 for x in err]), err=float(np.mean(err)), n=len(d))


for cond, model, g in (("none", None, g_none), ("exact", X.Exact(art), g_exact)):
    st = stats([X.paced(art, model, 12, g, u_, X.Rng.derive(802, 10_000 + k)) for k, u_ in enumerate(utts)])
    check(f"N02 self-paced, {cond}: gestures", H[f"N02.paced_{cond}_gestures"], st["n"], 0)
    check(f"N02 self-paced, {cond}: phonemes per second", H[f"N02.paced_{cond}_rate"], st["rate"], 1e-12)
    check(f"N02 self-paced, {cond}: duration-distance correlation", H[f"N02.paced_{cond}_corr"], st["corr"], 1e-10)
    check(f"N02 self-paced, {cond}: duration contrast", H[f"N02.paced_{cond}_contrast"], st["contrast"], 1e-12)
    check(f"N02 self-paced, {cond}: on-target share", H[f"N02.paced_{cond}_hit"], st["hit"], 1e-12)
    check(f"N02 self-paced, {cond}: mean error at the end", H[f"N02.paced_{cond}_err"], st["err"], 1e-12)

# ---------- N03 ----------
top = lex.words[:5000]
pools = {"short": [w for w in top if w in cmu and len(w) >= 3 and X.syllables(cmu[w][0]) == 1][:60],
         "long": [w for w in top if w in cmu and len(w) >= 3 and X.syllables(cmu[w][0]) == 3][:60]}
wd = table("N03_word_durations")
dur = {(p, c): [float(r_["articulation_s_" + c]) for r_ in wd if r_["pool"] == p] for p in pools for c in ("intact", "lesion")}
for p in pools:
    check(f"N03 {p} pool identical to C#", 1, 1 if pools[p] == [r_["word"] for r_ in wd if r_["pool"] == p] else 0, 0)
    les = [X.paced(art, None, 12, g_none, X.utter([w], cmu, ph, art.dof), X.Rng.derive(803, 2000 + k))[3] for k, w in enumerate(pools[p])]
    check(f"N03 {p} words: lesioned articulation times, largest difference", 0.0, max(abs(a - b) for a, b in zip(les, dur[(p, "lesion")])), 1e-12)
rec = X.excitation(art, 30000, X.Rng.derive(8100, 11))
gm = X.fit(rec, 1024, 4, 0.1, 1e-6, 8100 + 1000 + 1024)
g_gran = X.tune(art, gm, 12, Rt, Rvt, X.Rng.derive(8200, 51))
check("N02 tuned bandwidth at 60 ms, refitted granule model", float(trk[("articulators", "60", "granule")]["bandwidth"]), g_gran[0], 0)
for p in pools:
    ints = [X.paced(art, gm, 12, g_gran, X.utter([w], cmu, ph, art.dof), X.Rng.derive(803, 1000 + k))[3] for k, w in enumerate(pools[p])]
    check(f"N03 {p} words: intact articulation times with the refitted granule model, mean", H[f"N03.{p}_dur_intact"], float(np.mean(ints)), 1e-9)
LP = dict(X.LOOP)
hyps = {"intact": ("intact", 0.0, 1.0), "U": ("lesion", 0.0, 1.0), "E": ("intact", 0.08, 1.0), "S": ("intact", 0.0, 0.8), "C": ("lesion", 0.0, 0.8)}
cells = {}
for key, (dc, q, life) in hyps.items():
    for p in ("short", "long"):
        for quiet in (True, False):
            curve = [X.recall(dur[(p, dc)], n, 2000, LP, quiet, q, X.Rng.derive(803, 100_000 * (1 if p == "short" else 2) + (0 if quiet else 50_000) + n), life) for n in range(2, 11)]
            cells[(key, p, quiet)] = (X.span([c[0] for c in curve], 2), curve[5 - 2][1])
    for p in ("short", "long"):
        for quiet, cname in ((True, "quiet"), (False, "supp")):
            check(f"N03 span, {key}, {p}, {cname}", H[f"N03.span_{key}_{p}_{cname}"], cells[(key, p, quiet)][0], 1e-12)
            check(f"N03 item share at 5, {key}, {p}, {cname}", H[f"N03.items_{key}_{p}_{cname}"], cells[(key, p, quiet)][1], 1e-12)

passed = sum(1 for x in rows if x[-1])
with open(OUT / "PY_crosscheck.csv", "w", newline="") as fh:
    wr = csv.writer(fh); wr.writerow(["check", "csharp", "python", "abs_difference", "tolerance", "tolerance_kind", "pass"])
    for x in rows: wr.writerow([x[0], repr(x[1]), repr(x[2]), repr(x[3]), x[4], x[5], "true" if x[6] else "false"])
print(f"{passed}/{len(rows)} checks passed in {time.time() - T0:.0f} s")
sys.exit(0 if passed == len(rows) else 1)
