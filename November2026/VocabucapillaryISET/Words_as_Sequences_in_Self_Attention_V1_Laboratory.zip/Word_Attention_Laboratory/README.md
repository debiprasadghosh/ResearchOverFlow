# Word-level attention over sequence-valued keys: laboratory (immutable C#)

Companion to *Words as Sequences in Self-Attention: Slot-Aligned, Hierarchical and Alignment Scores over a Dense
Word-Level Key–Value Cache* (Ghosh, 2026), Step 1 of the word-Vocabucapillary programme. Every number in the paper
comes from `sqlab/`.

| Folder | Contents |
|---|---|
| `sqlab/` | .NET 8 console project, no packages. `Core/` holds the SplitMix64 generator, a minimal MessagePack reader, the lexicon (neighbours, anagram classes, affix families), cache layouts and decoders, and the score rules. `Experiments/S00`–`S04`; `Program.cs` loads the lexicon once and is the only code that writes files. |
| `data/` | `large_en.msgpack.gz`, the English word-frequency file of wordfreq 3.1.1 (see Data below). |
| `out/` | CSV tables, `headlines.json`, `run_log.txt`, `PY_crosscheck.csv` (41 of 41 agree). `S00_lexicon.csv` is the 50,000-word lexicon; `S03_cases.csv` holds every morphology case. |
| `pycheck/` | `crosscheck.py` (independent MessagePack reader, square counter, rule implementations, generator port, numpy identity check) and `figures.py` (plots only). |
| `figs/`, `paper/` | Figures; `build_paper.py` rebuilds the Word file from the outputs (needs pandoc), `docxfix.py` repairs pandoc's OOXML order quirks, `ref.docx` holds the styles. |

## Running

```
cd sqlab
dotnet run -c Release              # all five studies, about two minutes on two cores; reads ../data, writes ../out
dotnet run -c Release -- S03       # one study (writes a partial headlines.json; set SQ_OUT to write elsewhere)
cd ../pycheck && python3 crosscheck.py && python3 figures.py
cd ../paper && python3 build_paper.py
```

`SQ_DATA` and `SQ_OUT` override the data file and the output folder. On 25 November 2026 the package was rebuilt in a
clean folder and all 15 outputs (14 CSV files and `headlines.json`) were byte-identical to those in `out/`.

| Study | Question | Kind |
|---|---|---|
| S00 | English word lengths; positions, pairs, cache bytes and score work per word for each layout | Accounting |
| S01 | Crosstalk of position binding; log-sum-exp identity; anagram invariance; 2×2 conjunction squares | Exact and Monte Carlo |
| S02 | Exact-word retrieval and spelling for bag, bound, block and concatenated layouts against width and noise | Monte Carlo |
| S03 | Twelve score rules on 200 English word families: identity and family retrieval | Exact counts |
| S04 | Pooled screens with slot reranks over histories of 256–16,384 words; distinct-word grouping | Monte Carlo and accounting |

## Data

`data/large_en.msgpack.gz` is taken unchanged from wordfreq 3.1.1 by Robyn Speer
(https://github.com/rspeer/wordfreq). The wordfreq code is licensed under Apache 2.0 and its data files under the
Creative Commons Attribution-ShareAlike 4.0 licence (https://creativecommons.org/licenses/by-sa/4.0/); the data include
material derived from Google Books Ngrams and other sources listed in the wordfreq documentation. The derived files
`out/S00_lexicon.csv` and `out/S03_cases.csv` are shared under the same CC BY-SA 4.0 licence.
