"""Figures for the paper, drawn from the C# laboratory outputs (plotting only, no computation)."""
import csv, os
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle

_ROOT = Path(__file__).resolve().parent.parent
OUT = os.environ.get("SQ_OUT", str(_ROOT / "out")); FIG = os.environ.get("SQ_FIGS", str(_ROOT / "figs"))
os.makedirs(FIG, exist_ok=True)
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, VIOLET = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6"
SER = [BLUE, ORANGE, AQUA, YELLOW, MAGENTA, VIOLET]
INK, INK2, MUTED, GRID = "#1f1f1f", "#52514e", "#8a8984", "#e4e3df"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9, "axes.edgecolor": MUTED,
    "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": GRID,
    "grid.linewidth": 0.6, "axes.axisbelow": True, "axes.spines.top": False, "axes.spines.right": False,
    "legend.frameon": False, "savefig.dpi": 220, "lines.linewidth": 2, "text.color": INK})
def rd(n): return list(csv.DictReader(open(f"{OUT}/{n}.csv")))
def save(f, n): f.savefig(f"{FIG}/{n}.png", bbox_inches="tight"); plt.close(f)

# Figure 1: cache layouts and score rules for one word ("walked").
fig, ax = plt.subplots(figsize=(6.8, 3.9)); ax.set_axis_off(); ax.set_xlim(0, 11); ax.set_ylim(0, 6.6)
word = "walked"
def cells(x, y, n, w, h, labels, fc, ec=INK2):
    for i in range(n):
        ax.add_patch(Rectangle((x + i * w, y), w, h, fc=fc, ec=ec, lw=0.8))
        if labels and i < len(labels): ax.text(x + i * w + w / 2, y + h / 2, labels[i], ha="center", va="center", fontsize=7, color=INK)
ax.text(0.1, 6.3, "Cache layouts for one word", fontsize=8.5, weight="bold")
ax.text(0.1, 5.75, "pooled bag  Σ e(cⱼ)", fontsize=7.4, color=INK2); cells(3.5, 5.6, 1, 1.6, 0.35, ["1 vector"], "#eef4fc")
ax.text(5.4, 5.73, "order lost: anagrams share one vector", fontsize=7, color=ORANGE)
ax.text(0.1, 5.15, "pooled, bound  Σ Rⱼ e(cⱼ)", fontsize=7.4, color=INK2); cells(3.5, 5.0, 1, 1.6, 0.35, ["1 vector"], "#eef4fc")
ax.text(5.4, 5.13, "order kept, crosstalk √(L(L−1)/d)", fontsize=7, color=INK2)
ax.text(0.1, 4.55, "slot blocks (d/16 each)", fontsize=7.4, color=INK2); cells(3.5, 4.4, 16, 0.1, 0.35, None, "#eaf7f1")
ax.text(5.4, 4.53, "one vector; narrow slots", fontsize=7, color=INK2)
ax.text(0.1, 3.95, "concatenated slots (16 × d)", fontsize=7.4, color=INK2); cells(3.5, 3.8, 8, 0.45, 0.35, list(word) + ["·", "·"], "#eaf7f1")
ax.text(7.25, 3.93, "… 16 vectors per word", fontsize=7, color=INK2)
ax.text(0.1, 3.15, "Word scores over the slots of a key", fontsize=8.5, weight="bold")
rules = [("slot-aligned (AND)", "exp(Σⱼ qⱼ·kⱼ) = Πⱼ exp(qⱼ·kⱼ): every slot must agree", BLUE),
         ("hierarchical (OR)", "log Σⱼ exp(q·kⱼ): any slot may agree; equals character attention", ORANGE),
         ("alignment", "best monotone matching of query and key slots, with shifts and gaps", AQUA)]
for i, (name, desc, col) in enumerate(rules):
    y = 2.55 - i * 0.62
    ax.add_patch(FancyBboxPatch((0.1, y - 0.2), 2.6, 0.42, boxstyle="round,pad=0.02,rounding_size=0.08", fc="white", ec=col, lw=1.3))
    ax.text(1.4, y, name, ha="center", va="center", fontsize=7.6, color=INK)
    ax.text(2.95, y, desc, va="center", fontsize=7.2, color=INK2)
ax.text(0.1, 0.45, "Outer softmax over word positions t;  value read y = Σₜ πₜ Σⱼ Uⱼ vₜⱼ", fontsize=7.4, color=INK2)
save(fig, "fig1_layouts_scores")

# Figure 2: layout and width.
lay = rd("S02_layouts")
fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.9))
names = [("bag", "pooled bag"), ("bag-cos", "pooled bag, cosine"), ("bound", "pooled, bound"), ("blocks", "slot blocks"), ("concat", "concatenated slots")]
ds = [32, 64, 128, 256]
for i, (k, lab) in enumerate(names):
    acc = [float(next(r["exact_word_top1"] for r in lay if r["layout"] == k and r["width_d"] == str(d) and r["noise_sigma"] == "0.5")) for d in ds]
    axes[0].plot(ds, acc, marker="o", ms=3.5, color=SER[i], label=lab)
for i, (k, lab) in enumerate(names):
    if k not in ("bound", "blocks", "concat"): continue
    sp = [float(next(r["spelling_exact"] for r in lay if r["layout"] == k and r["width_d"] == str(d) and r["noise_sigma"] == "0.5")) for d in ds]
    axes[1].plot(ds, sp, marker="o", ms=3.5, color=SER[i], label=lab)
for ax, t in zip(axes, ["exact word ranked first", "spelling read back exactly"]):
    ax.set_xscale("log", base=2); ax.set_xticks(ds); ax.set_xticklabels([str(d) for d in ds]); ax.set_ylim(-0.03, 1.05)
    ax.set_title(t); ax.set_xlabel("width d")
fig.tight_layout()
fig.legend(*axes[0].get_legend_handles_labels(), loc="upper center", ncol=3, fontsize=7.2, bbox_to_anchor=(0.5, 0.0))
save(fig, "fig2_layout_width")

# Figure 3: identity against family retrieval for each score rule.
ru = rd("S03_rules")
fig, ax = plt.subplots(figsize=(6.4, 4.2))
y = list(range(len(ru)))
ax.barh([i - 0.19 for i in y], [float(r["identity_top1"]) for r in ru], height=0.36, color=BLUE, label="identity: exact word ranked first")
ax.barh([i + 0.19 for i in y], [float(r["family_map"]) for r in ru], height=0.36, color=ORANGE, label="family: mean average precision")
ax.set_yticks(y); ax.set_yticklabels([r["rule"] for r in ru]); ax.invert_yaxis(); ax.set_xlim(0, 1.05)
ax.legend(fontsize=7.2, loc="lower center", ncol=2, bbox_to_anchor=(0.4, 1.0))
save(fig, "fig3_rules")

# Figure 4: long histories.
lh = rd("S04_readers")
ms = [256, 1024, 4096, 16384]
fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.9))
for i, (k, lab) in enumerate([("bound pooled scan only", "bound pooled scan"), ("bag pooled scan only", "bag pooled scan"),
                              ("bag screen → slot rerank, K=32", "bag screen → slot rerank (K = 32)"),
                              ("bound screen → slot rerank, K=8", "bound screen → slot rerank (K = 8)")]):
    axes[0].plot(ms, [float(next(r["exact_word_top1"] for r in lh if r["reader"] == k and r["history_words_M"] == str(m))) for m in ms], marker="o", ms=3.5, color=SER[i], label=lab)
axes[0].set_title("exact word ranked first"); axes[0].set_ylim(-0.03, 1.05)
for i, (k, col, lab) in enumerate([("dense character attention", "mac_per_query_tokens", "dense character attention"),
                                   ("full slot-aligned scan", "mac_per_query_grouped", "slot-aligned scan, grouped"),
                                   ("bound screen → slot rerank, K=8", "mac_per_query_tokens", "two stages, every token"),
                                   ("bound screen → slot rerank, K=8", "mac_per_query_grouped", "two stages, grouped")]):
    axes[1].plot(ms, [float(next(r[col] for r in lh if r["reader"] == k and r["history_words_M"] == str(m))) for m in ms], marker="o", ms=3.5, color=SER[i], label=lab)
axes[1].set_yscale("log"); axes[1].set_title("multiply-adds per query")
for ax in axes: ax.set_xscale("log", base=2); ax.set_xticks(ms); ax.set_xticklabels(["256", "1,024", "4,096", "16,384"]); ax.set_xlabel("words in history")
axes[1].legend(fontsize=6.8, loc="upper left")
fig.tight_layout()
axes[0].legend(fontsize=6.8, loc="upper center", ncol=2, bbox_to_anchor=(0.5, -0.24))
save(fig, "fig4_long_history")
print("figures written")
