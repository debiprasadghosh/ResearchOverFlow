"""Independent Python cross-check of the word-attention laboratory.

Decodes the wordfreq file with its own MessagePack reader, rebuilds the lexicon, recounts anagram classes and 2x2
slot squares with a different algorithm, re-scores every morphology case with independent rule implementations,
regenerates the history trials with a port of the SplitMix64 generator, and checks the log-sum-exp identity in numpy.
Usage: python3 crosscheck.py [out_folder] [data_file]
"""
import csv, gzip, json, math, sys
from collections import Counter, defaultdict
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
OUT = sys.argv[1] if len(sys.argv) > 1 else str(ROOT / "out")
DATA = sys.argv[2] if len(sys.argv) > 2 else str(ROOT / "data" / "large_en.msgpack.gz")
H = json.load(open(f"{OUT}/headlines.json"))
rows = []
def check(name, cs, py, tol):
    rows.append((name, cs, py, abs(cs - py), abs(cs - py) <= tol))


# ---------- MessagePack (independent minimal reader) ----------
def unpack(b):
    stack_pos = [0]
    def rd(i):
        t = b[i]
        if t <= 0x7f: return t, i + 1
        if 0x80 <= t <= 0x8f: return rmap(i + 1, t & 0x0f)
        if 0x90 <= t <= 0x9f: return rarr(i + 1, t & 0x0f)
        if 0xa0 <= t <= 0xbf: n = t & 0x1f; return b[i + 1:i + 1 + n].decode(), i + 1 + n
        if t == 0xd9: n = b[i + 1]; return b[i + 2:i + 2 + n].decode(), i + 2 + n
        if t == 0xda: n = int.from_bytes(b[i + 1:i + 3], "big"); return b[i + 3:i + 3 + n].decode(), i + 3 + n
        if t == 0xdc: return rarr(i + 3, int.from_bytes(b[i + 1:i + 3], "big"))
        if t == 0xdd: return rarr(i + 5, int.from_bytes(b[i + 1:i + 5], "big"))
        if t == 0xcc: return b[i + 1], i + 2
        if t == 0xcd: return int.from_bytes(b[i + 1:i + 3], "big"), i + 3
        raise ValueError(hex(t))
    def rarr(i, n):
        out = []
        for _ in range(n):
            v, i = rd(i); out.append(v)
        return out, i
    def rmap(i, n):
        out = {}
        for _ in range(n):
            k, i = rd(i); v, i = rd(i); out[k] = v
        return out, i
    return rd(0)[0]

root = unpack(gzip.open(DATA).read())
assert root[0]["format"] == "cB"
allw = [(w, 10.0 ** (-(i - 1) / 100.0)) for i in range(1, len(root)) for w in root[i]]
def is_alpha(w): return len(w) > 0 and all("a" <= c <= "z" for c in w)
alpha = [x for x in allw if is_alpha(x[0])]
alpha16 = [x for x in alpha if len(x[0]) <= 16]
kept = alpha16[:50000]
words = [w for w, _ in kept]
kmass = 0.0
for _, f in kept: kmass += f
prob = [f / kmass for _, f in kept]
cdf = []
acc = 0.0
for p in prob: acc += p; cdf.append(acc)
index = {w: i for i, w in enumerate(words)}
check("S00 word types in the list", H["S00.all_types"], len(allw), 0)
check("S00 alphabetic types", H["S00.alpha_types"], len(alpha), 0)
m16 = sum(f for _, f in alpha16)
check("S00 mean letters, all alphabetic tokens", H["S00.mean_letters_all_alpha"], sum(f * len(w) for w, f in alpha16) / m16, 1e-9)  # 289k-term sums; .NET 8 vectorizes Sum, so rounding order differs
check("S00 mean letters, lexicon", H["S00.mean_letters_lexicon"], sum(p * len(w) for w, p in zip(words, prob)), 1e-12)
lexcsv = [r["word"] for r in csv.DictReader(open(f"{OUT}/S00_lexicon.csv"))]
check("S00 exported lexicon identical (mismatching entries)", 0, sum(a != b for a, b in zip(lexcsv, words)) + abs(len(lexcsv) - len(words)), 0)

# ---------- S01: anagram classes and 2x2 squares (different algorithm) ----------
classes = defaultdict(list)
for w in words: classes["".join(sorted(w))].append(w)
multi = [c for c in classes.values() if len(c) >= 2]
check("S01 anagram classes", H["S01.anagram_classes"], len(multi), 0)
check("S01 words with an anagram", H["S01.anagram_words"], sum(len(c) for c in multi), 0)
squares, involved = 0, set()
for n in range(3, 11):
    ws = [w for w in words if len(w) == n]
    for i in range(n):
        for j in range(i + 1, n):
            groups = defaultdict(lambda: defaultdict(set))
            for w in ws: groups[w[:i] + w[i + 1:j] + w[j + 1:]][w[i]].add(w[j])
            for k, g in groups.items():
                xs = sorted(g)
                for a in range(len(xs)):
                    for c in range(a + 1, len(xs)):
                        common = g[xs[a]] & g[xs[c]]          # letters at j shared by both letters at i
                        if len(common) >= 2:
                            squares += len(common) * (len(common) - 1) // 2
                            for y in common:
                                for x in (xs[a], xs[c]):
                                    involved.add(k[:i] + x + k[i:j - 1] + y + k[j - 1:])
check("S01 2x2 slot squares", H["S01.xor_squares"], squares, 0)
check("S01 words in a square", H["S01.xor_words_involved"], len(involved), 0)

# ---------- S01: log-sum-exp identity (independent numpy) ----------
rng = np.random.default_rng(7)
gap_m = gap_v = 0.0
for _ in range(100):
    lens = rng.integers(1, 17, size=30); n = lens.sum()
    K = rng.normal(size=(n, 64)); V = rng.normal(size=(n, 32)); q = rng.normal(size=64)
    s = K @ q / 8.0; p = np.exp(s - s.max()); p /= p.sum(); y_char = p @ V
    bounds = np.concatenate([[0], np.cumsum(lens)])
    ws = np.array([np.log(np.exp(s[a:b] - s.max()).sum()) + s.max() for a, b in zip(bounds[:-1], bounds[1:])])
    pi = np.exp(ws - ws.max()); pi /= pi.sum()
    y_word = sum(pi[t] * (np.exp(s[a:b] - s[a:b].max()) / np.exp(s[a:b] - s[a:b].max()).sum()) @ V[a:b] for t, (a, b) in enumerate(zip(bounds[:-1], bounds[1:])))
    mass = np.array([p[a:b].sum() for a, b in zip(bounds[:-1], bounds[1:])])
    gap_m = max(gap_m, np.abs(mass - pi).max()); gap_v = max(gap_v, np.abs(y_word - y_char).max())
check("S01 log-sum-exp word mass identity (numpy)", 0.0, float(gap_m), 1e-13)
check("S01 nested read equals character attention (numpy)", 0.0, float(gap_v), 1e-13)

# ---------- S03: independent rule implementations on the exported cases ----------
PAD, L = "_", 16
def left(w): return list(w) + [PAD] * (L - len(w))
def right(w): return [PAD] * (L - len(w)) + list(w)
def slots(a, b, pw): return sum((pw if x == PAD else 1.0) for x, y in zip(a, b) if x == y)
def bag(q, k):
    cq, ck = Counter(q), Counter(k); return float(sum(cq[c] * ck[c] for c in cq))
def maxsim(q, k): return float(sum(1 for c in q if c in k))
def shift(q, k):
    return float(max(sum(1 for i in range(len(q)) if 0 <= i + d < len(k) and q[i] == k[i + d]) for d in range(-len(q) + 1, len(k))))
def sw(q, k):
    prev = [0] * (len(k) + 1); best = 0
    for i in range(1, len(q) + 1):
        cur = [0] * (len(k) + 1)
        for j in range(1, len(k) + 1):
            cur[j] = max(0, prev[j - 1] + (1 if q[i - 1] == k[j - 1] else -1), prev[j] - 1, cur[j - 1] - 1)
            best = max(best, cur[j])
        prev = cur
    return float(best)
def dice(s, q, k): return 2.0 * s / (len(q) + len(k))
RULES = {
    "bag_of_letters": bag,
    "slots_from_start_padding_counted": lambda q, k: slots(left(q), left(k), 1.0),
    "slots_from_start_letters_only": lambda q, k: slots(left(q), left(k), 0.0),
    "slots_from_end_letters_only": lambda q, k: slots(right(q), right(k), 0.0),
    "two_anchors_maximum": lambda q, k: max(slots(left(q), left(k), 0.0), slots(right(q), right(k), 0.0)),
    "two_anchors_maximum_padding_counted": lambda q, k: max(slots(left(q), left(k), 1.0), slots(right(q), right(k), 1.0)),
    "two_anchors_sum": lambda q, k: slots(left(q), left(k), 0.0) + slots(right(q), right(k), 0.0),
    "late_interaction_MaxSim": maxsim,
    "best_common_shift": shift,
    "best_common_shift_length_normalised": lambda q, k: dice(shift(q, k), q, k),
    "local_alignment": sw,
    "local_alignment_length_normalised": lambda q, k: dice(sw(q, k), q, k),
}
cases = list(csv.DictReader(open(f"{OUT}/S03_cases.csv")))
byq = defaultdict(list)
for c in cases: byq[int(c["query_id"])].append(c)
for name, fn in RULES.items():
    ident, fam_ap = [], []
    for qid, cs in byq.items():
        sc = [(fn(c["query"], c["candidate"]), int(c["order"]), c) for c in cs]
        if cs[0]["task"] == "identity":
            best = max(s for s, _, _ in sc)
            top = [c for s, _, c in sc if s == best]
            ident.append(1.0 if len(top) == 1 and top[0]["relevant"] == "1" else 0.0)
        else:
            ranked = sorted(sc, key=lambda x: (-x[0], x[1]))
            nrel = sum(1 for _, _, c in ranked if c["relevant"] == "1"); hits = 0; ap = 0.0
            for i, (_, _, c) in enumerate(ranked):
                if c["relevant"] == "1": hits += 1; ap += hits / (i + 1)
            fam_ap.append(ap / nrel)
    check(f"S03 {name}: identity top-1", H[f"S03.{name}_identity"], sum(ident) / len(ident), 1e-12)
    check(f"S03 {name}: family MAP", H[f"S03.{name}_family_map"], sum(fam_ap) / len(fam_ap), 1e-12)

# ---------- S02/S04: regenerate history trials with the SplitMix64 port ----------
M64 = (1 << 64) - 1
class Rng:
    def __init__(self, s): self.s = s & M64
    @staticmethod
    def derive(seed, stream):
        r = Rng(seed ^ ((stream * 0xD1B54A32D192ED03) & M64)); r.u64(); return r
    def u64(self):
        self.s = (self.s + 0x9E3779B97F4A7C15) & M64
        z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return z ^ (z >> 31)
    def double(self): return (self.u64() >> 11) * (1.0 / 9007199254740992.0)
    def int(self, n):
        v = int(self.double() * n); return n - 1 if v >= n else v

PREFIXES = ["re", "un", "dis", "pre", "mis", "over", "out", "sub", "inter", "non"]
SUFFIXES = ["s", "es", "ed", "d", "ing", "er", "ers", "est", "ly", "ness", "ment", "able", "ful", "less"]
cls_index = defaultdict(list)
for i, w in enumerate(words): cls_index["".join(sorted(w))].append(i)
def anagrams(w): return [words[i] for i in cls_index.get("".join(sorted(w)), []) if words[i] != w]
def affix(w):
    f = set()
    for s in SUFFIXES:
        if w + s in index: f.add(w + s)
        if w.endswith(s) and len(w) - len(s) >= 3 and w[:-len(s)] in index: f.add(w[:-len(s)])
    for p in PREFIXES:
        if p + w in index: f.add(p + w)
        if w.startswith(p) and len(w) - len(p) >= 3 and w[len(p):] in index: f.add(w[len(p):])
    f.discard(w)
    return sorted((x for x in f if len(x) <= 16), key=index.get)
def one_edit(w):
    f = set()
    def t(s):
        if s and s != w and s in index: f.add(s)
    for i in range(len(w)):
        t(w[:i] + w[i + 1:])
        for c in "abcdefghijklmnopqrstuvwxyz":
            if c != w[i]: t(w[:i] + c + w[i + 1:])
        if i + 1 < len(w) and w[i] != w[i + 1]: t(w[:i] + w[i + 1] + w[i] + w[i + 2:])
    for i in range(len(w) + 1):
        for c in "abcdefghijklmnopqrstuvwxyz": t(w[:i] + c + w[i:])
    return sorted(f, key=index.get)
def neighbours(w, cap):
    out, seen = [], set()
    for x in anagrams(w) + affix(w) + one_edit(w):
        if x != w and x not in seen: seen.add(x); out.append(x)
    return out[:cap]
def sample(r):
    target = r.double() * cdf[-1]; lo, hi = 0, len(cdf) - 1
    while lo < hi:
        mid = (lo + hi) // 2
        if cdf[mid] > target: hi = mid
        else: lo = mid + 1
    return lo
def make_trials(history, count, seed, max_rank=20000):
    out = []; r = Rng.derive(seed, 1)
    while len(out) < count:
        w = words[r.int(min(max_rank, len(words)))]
        if len(w) < 3 or len(w) > 12: continue
        nb = neighbours(w, 8)
        if len(nb) < 2: continue
        tokens = [w] + nb; rr = Rng.derive(seed, 100 + len(out))
        while len(tokens) < history: tokens.append(words[sample(rr)])
        out.append((len(dict.fromkeys(tokens)), sum(len(x) + 1 for x in tokens), len(nb)))
    return out
t02 = make_trials(256, 1000, 202)
check("S02 mean distinct words per history", H["S02.mean_distinct_words"], sum(t[0] for t in t02) / len(t02), 1e-9)
check("S02 mean neighbours per target", H["S02.mean_neighbours"], sum(t[2] for t in t02) / len(t02), 1e-9)
for m in (256, 1024):
    tr = make_trials(m, 200, 404 + m)
    check(f"S04 distinct words, history {m}", H[f"S04.M{m}_distinct"], sum(t[0] for t in tr) / len(tr), 1e-9)
    check(f"S04 character slots, history {m}", H[f"S04.M{m}_chars"], sum(t[1] for t in tr) / len(tr), 1e-9)

with open(f"{OUT}/PY_crosscheck.csv", "w", newline="") as fh:
    wtr = csv.writer(fh); wtr.writerow(["quantity", "csharp", "python", "abs_difference", "agree"])
    for row in rows: wtr.writerow(row)
print(f"{sum(r[4] for r in rows)}/{len(rows)} agree")
for row in rows:
    if not row[4]: print("DISAGREE", row)
