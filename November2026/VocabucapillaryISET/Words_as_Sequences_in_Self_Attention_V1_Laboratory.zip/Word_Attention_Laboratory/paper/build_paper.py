"""Assembles the Step 1 paper (dense word-level KV cache) from the laboratory outputs and converts it to Word."""
import csv, json, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT, FIG = ROOT / "out", ROOT / "figs"
sys.path.insert(0, str(HERE))
import docxfix

H = json.load(open(OUT / "headlines.json"))
def g(k): return H[k]
def rd(n): return list(csv.DictReader(open(OUT / f"{n}.csv")))
def m(s): return s.replace("-", "−")
def f2(x): return m(f"{x:.2f}")
def f3(x): return m(f"{x:.3f}")
def pc(x, d=0): return m(f"{100 * x:.{d}f}%")
def n0(x): return f"{x:,.0f}"
def sci(x): return m(f"{x:.1e}")

def md_table(header, rows, caption):
    lens = [max(min(len(str(h)), 14), 9, *(len(str(r[i])) for r in rows)) for i, h in enumerate(header)]
    out = [f"Table: {caption}", "", "| " + " | ".join(header) + " |", "|" + "|".join("-" * max(9, min(60, l)) for l in lens) + "|"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out) + "\n"

# ---------------- tables ----------------
t_related = md_table(["Approach", "Higher-level unit", "What the higher-level cache holds per unit", "How a unit is scored"], [
    ["Hierarchical autoregressive transformer (Neitemeier et al., 2025)", "word", "one vector from a character encoder", "dense dot product"],
    ["SpaceByte (Slagle, 2024)", "word boundary", "one global position", "dense dot product"],
    ["Block Transformer (Ho et al., 2024)", "fixed block of tokens", "one block vector", "dense dot product"],
    ["MEGABYTE (Yu et al., 2023)", "fixed byte patch", "concatenated byte embeddings as input to one position", "dense dot product"],
    ["Byte Latent Transformer (Pagnoni et al., 2024)", "dynamic byte patch", "one vector pooled by cross-attention", "dense dot product"],
    ["Native Sparse Attention (Yuan et al., 2025)", "fixed block of tokens", "compressed block key plus all token keys", "block score selects blocks; tokens scored singly"],
    ["DeepSeek-V4 (DeepSeek-AI, 2026)", "4 or 128 tokens", "one compressed entry per group", "top-k or dense over entries"],
    ["ColBERT (Khattab & Zaharia, 2020)", "retrieved passage", "all token vectors", "sum of maxima over tokens"],
    ["This paper", "word", "slot sequence (dense) plus one pooled bound key", "slot-aligned, anchored or aligned word scores in an outer word softmax"],
], "Table 1. How related architectures represent and score a higher-level unit. None keeps a word's slot sequence as its cache entry and scores it as one unit inside a word-level causal softmax.")

t_rules_def = md_table(["Score", "Definition", "Logic over slots", "Work per key word"], [
    ["Pooled bag", "q̄·Σⱼ e(cⱼ)", "order-free", "O(d)"],
    ["Pooled, bound", "q̄·(Σⱼ Rⱼ e(cⱼ) + R₍ₙ₊₁₎ e(EOS))", "order kept with crosstalk", "O(d)"],
    ["Slot-aligned", "Σⱼ qⱼ·kₜⱼ, padding weighted by ω", "AND: every slot contributes a factor", "O(Ld), or O(d) with blocks"],
    ["Two anchors", "max of left- and right-aligned slot scores", "AND within an anchor, OR across anchors", "O(2Ld)"],
    ["Hierarchical", "log Σⱼ exp(q·kₜⱼ)", "OR: any slot may match", "O(Ld)"],
    ["Late interaction", "Σᵢ maxⱼ qᵢ·kₜⱼ", "OR per query slot, order-free", "O(L²d)"],
    ["Best common shift", "max over δ of Σᵢ qᵢ·kₜ,ᵢ₊δ", "AND under one shift", "O(L²d)"],
    ["Local alignment", "Smith–Waterman over slot similarities", "AND along a monotone path with gaps", "O(L²d + L²)"],
], "Table 2. Word scores for a query against the slots of a cached word. L is the number of slots, d the width of a slot vector.")

cross = rd("S01_crosstalk")
t_cross = md_table(["Width d", "Measured standard deviation", "Theory √(L(L−1)/d)", "Ratio", "Relative to an exact match (score 16)"],
    [[r["width_d"], f3(float(r["measured_sd"])), f3(float(r["theory_sqrt_L(L-1)/d"])), f3(float(r["ratio"])), pc(float(r["sd_relative_to_exact_match_score"]), 1)] for r in cross],
    "Table 3. Crosstalk between the bound pooled score and the slot-aligned score for 16 slots of independent unit vectors (2,000 samples per width).")

idt = rd("S01_identities")
t_ident = md_table(["Check", "Value", "Requirement"],
    [[r["check"], "0" if float(r["value"]) == 0 else (sci(float(r["value"])) if float(r["value"]) < 1e-3 else f3(float(r["value"]))), r["requirement"]] for r in idt],
    "Table 4. Exact identities, checked over 200 random histories of 40 words (log-sum-exp) and all anagram classes of the lexicon (pooled codes, width 128).")

pw = rd("S00_per_word")
t_pw = md_table(["Layout", "Vectors per word", "Cache bytes per word", "Score multiply-adds per query and word", "Note"],
    [[r["layout"], f2(float(r["vectors_per_word"])), n0(float(r["cache_bytes_per_word"])), n0(float(r["score_mac_per_query_word"])), r["note"]] for r in pw],
    "Table 5. Per-word cost for one attention head of width 128 in one layer (BF16 keys and values), with English word lengths weighted by frequency.")
ps = rd("S00_passages")
t_ps = md_table(["Words M", "Character positions N", "Dense pairs, characters", "Dense pairs, words", "Ratio"],
    [[n0(float(r["words_M"])), n0(float(r["character_positions_N"])), sci(float(r["dense_pairs_characters"])), sci(float(r["dense_pairs_words"])), f2(float(r["ratio"]))] for r in ps],
    "Table 6. Causal query–key pairs for passages of English at word and at character level (one separator per word).")

lay = rd("S02_layouts")
def lv(layout, d, sigma, col):
    v = next(r[col] for r in lay if r["layout"] == layout and r["width_d"] == str(d) and r["noise_sigma"] == sigma)
    return float(v)
names = [("bag", "Pooled bag"), ("bag-cos", "Pooled bag, cosine"), ("bound", "Pooled, bound"), ("blocks", "Slot blocks"), ("concat", "Concatenated slots")]
def cellrow(layout, col, sigma="0.5"):
    vals = [lv(layout, d, sigma, col) for d in (32, 64, 128, 256)]
    return " / ".join("–" if v != v else f2(v) for v in vals)
t_lay = md_table(["Layout", "Floats per word", "Exact word first, d = 32 / 64 / 128 / 256", "Spelling exact, d = 32 / 64 / 128 / 256"],
    [[lab, "16d" if k == "concat" else "d", cellrow(k, "exact_word_top1"), cellrow(k, "spelling_exact")] for k, lab in names],
    f"Table 7. Cache layout against width with query and value noise σ = 0.5 (1,000 trials; histories of 256 tokens with {f2(g('S02.mean_distinct_words'))} distinct words, including {f2(g('S02.mean_neighbours'))} near-duplicates of the target on average).")
def sweep(layout, col): return " / ".join("–" if (v := lv(layout, 128, s, col)) != v else f2(v) for s in ("0.25", "0.5", "1", "1.5"))
t_sweep = md_table(["Layout (d = 128)", "Exact word first, σ = 0.25 / 0.5 / 1.0 / 1.5", "Spelling exact, σ = 0.25 / 0.5 / 1.0 / 1.5"],
    [[lab, sweep(k, "exact_word_top1"), sweep(k, "spelling_exact")] for k, lab in names],
    "Table 8. Noise sweep at width 128.")

ru = rd("S03_rules")
t_rules = md_table(["Score rule", "Work", "Identity: exact word first", "Identity: tied", "Family: MAP", "Family: suffixed recall", "Family: prefixed recall"],
    [[r["rule"], r["cost_per_comparison"], f3(float(r["identity_top1"])), f3(float(r["identity_tied"])), f3(float(r["family_map"])), f3(float(r["family_recall_suffixed"])), f3(float(r["family_recall_prefixed"]))] for r in ru],
    f"Table 9. Score rules on {n0(g('S03.families'))} English word families ({n0(g('S03.identity_queries'))} identity queries with {f2(g('S03.mean_identity_candidates'))} candidates each; {n0(g('S03.family_queries'))} family queries with {f2(g('S03.mean_family_candidates'))} candidates each). Character vectors are orthonormal. Recall is measured within the top R, where R is the number of relevant forms.")

lh = rd("S04_readers")
def hv(reader, mm, col): return float(next(r[col] for r in lh if r["reader"] == reader and r["history_words_M"] == str(mm)))
readers = ["dense character attention", "full slot-aligned scan", "bound pooled scan only", "bag pooled scan only",
           "bound screen → slot rerank, K=8", "bound screen → slot rerank, K=32", "bag screen → slot rerank, K=8", "bag screen → slot rerank, K=32"]
t_long = md_table(["Reader", "Exact word first, M = 256 / 1,024 / 4,096 / 16,384", "Multiply-adds per query at 16,384 words, every token", "Same, grouped by word"],
    [[r, " / ".join(f2(hv(r, mm, "exact_word_top1")) for mm in (256, 1024, 4096, 16384)), n0(hv(r, 16384, "mac_per_query_tokens")), n0(hv(r, 16384, "mac_per_query_grouped"))] for r in readers],
    "Table 10. Word retrieval over long histories (200 trials per length, width 128, noise σ = 0.5). Dense character attention is exact by construction; its cost is the character keys one query reads.")
dist = rd("S04_distinct")
t_dist = md_table(["Words in history M", "Distinct words G", "G / M", "Character slots N", "N / M"],
    [[n0(float(r["history_words_M"])), n0(float(r["distinct_words_G"])), f2(float(r["G_over_M"])), n0(float(r["character_slots_N"])), f2(float(r["N_over_M"]))] for r in dist],
    "Table 11. Distinct words and character slots in the histories of Table 10.")

py = list(csv.DictReader(open(OUT / "PY_crosscheck.csv")))
py_agree = f"{sum(r['agree'] == 'True' for r in py)} of {len(py)}"
def rule(name, col): return float(next(r[col] for r in ru if r["rule"] == name))
pooled_key_share = 256 / g("S00.char_bytes_per_word")

# ---------------- text ----------------
md = f"""---
title: "Words as Sequences in Self-Attention: Slot-Aligned, Hierarchical and Alignment Scores over a Dense Word-Level Key–Value Cache"
author: "Debi Prasad Ghosh"
date: "November 2026"
abstract: |
  A two-level vocabulary keeps a fixed set of primitives, such as characters or actions, and treats every word as an ordered sequence of them, so the word vocabulary can grow without new embeddings. Self-attention can then run at word level, but each cached key and value becomes a sequence of vectors rather than one vector. This paper studies that setting with an ordinary dense key–value cache, before any sparse Vocabucapillary memory is introduced. It formulates the cache layouts (pooled bag, pooled with position binding, slot blocks and concatenated slots) and the word scores (slot-aligned, hierarchical, anchored and alignment), and tests them in an immutable C# laboratory on the English word-frequency list of wordfreq, with an independent Python check that agreed on {py_agree} quantities. Four results are exact. A slot-aligned word score is ordinary attention on concatenated slot vectors and behaves as a logical AND over slots. A hierarchical log-sum-exp word score reproduces character attention to {sci(g('S01.lse_value_max_gap'))}, so it saves nothing without pruning. Pooled bags cannot separate anagrams, which affect {pc(g('S01.anagram_word_share'))} of the 50,000-word lexicon. No slot-additive score can prefer *get* and *lot* over *got* and *let*, and {n0(g('S01.xor_squares'))} such squares occur among English words. Numerically, a single pooled bound key of width 128 ranked the exact word first in {pc(lv('bound', 128, '0.5', 'exact_word_top1'), 1)} of noisy queries among near-duplicates. No fixed score served both identity and family retrieval: two-anchor slot scores reached a family MAP of {f3(rule('two anchors, maximum', 'family_map'))}, matching local alignment at lower cost, while identity required a padding term. A pooled bound screen followed by a slot-aligned rerank of eight words found the exact word in every trial up to 16,384 words, at {n0(hv('bound screen → slot rerank, K=8', 16384, 'mac_per_query_grouped'))} multiply-adds per query against {n0(hv('dense character attention', 16384, 'mac_per_query_tokens'))} for dense character attention.
---

# 1 Introduction

Language models read through a vocabulary that fixes their units. Subword vocabularies compress text but hide spelling, while character and byte models keep spelling at the price of longer sequences (Clark et al., 2022; Xue et al., 2022; Tay et al., 2022). A middle course is a two-level vocabulary. The primitive vocabulary is small and fixed: the 26 letters, punctuation, or a set of motor primitives. The word vocabulary is dynamic, because a word is simply an ordered sequence of primitives, S(w) = (c₁, …, cₙ). New words need no new embeddings and nothing is ever out of vocabulary.

Self-attention can then run over words instead of characters. Each cached word is no longer one key and one value, however, but a sequence of slot vectors, one per character position. The central question of this paper is how a query should score such a sequence-valued key, how the sequence should be stored, and what each choice can and cannot distinguish.

This paper is Step 1 of a two-step programme. It keeps an ordinary dense key–value cache, so that the logic of word-level attention over sequences can be examined on its own. Step 2 will replace each dense slot vector with a sparse dictionary over the fixed primitive vocabulary, the word-Vocabucapillary, which carries the coefficient memory of the earlier papers of this series to word level (Ghosh, 2026a, 2026b). Every structure tested here is meant to survive that replacement.

The contributions are as follows.

1. A formulation of word-level attention over sequence-valued keys: four cache layouts, four families of word scores, and the padding weight that controls whether a score demands an exact word or a word family (Section 3).
2. Five exact properties, with numerical confirmation: slot-aligned scores are concatenated attention with AND semantics; hierarchical scores are character attention in disguise; pooled bags are permutation-invariant; slot-additive scores cannot express conjunctions; and keys that depend only on the word can be grouped exactly (Section 4).
3. Accounting from English word statistics (Section 5), and three numerical studies: cache layout against width (Section 6), score rules on English word families (Section 7), and two-stage word retrieval over histories up to 16,384 words (Section 8).
4. A recommended Step 1 design and its implications for the word-Vocabucapillary (Section 9).

All numbers come from an immutable C# laboratory described in Appendix B. The word statistics come from the English word-frequency list of wordfreq (Speer, 2022), which the laboratory reads directly.

# 2 Related work

Table 1 places the proposal among architectures that work above the character or byte level. Hierarchical autoregressive transformers encode each word with a small character encoder, run a word-level backbone over the resulting embeddings and spell outputs with a character decoder (Neitemeier et al., 2025). SpaceByte runs larger global blocks only at word boundaries (Slagle, 2024). The Block Transformer embeds fixed blocks of tokens as single vectors for a global decoder and decodes locally within each block (Ho et al., 2024). MEGABYTE forms the global input for a patch by concatenating its byte embeddings (Yu et al., 2023), and the Byte Latent Transformer pools bytes into dynamic patches with cross-attention (Pagnoni et al., 2024). In all of these the higher level attends over one vector per unit, so the unit's internal sequence is not available when the higher level computes attention.

Sparse and compressed attention methods keep fine tokens and add a summary per block. Native Sparse Attention compresses each block of keys into one key with an MLP that uses positions inside the block, ranks blocks by the query's attention to these compressed keys, and then reads the selected blocks at full resolution together with a sliding window (Yuan et al., 2025). DeepSeek-V4 compresses every 4 tokens into one entry for top-k selection and every 128 tokens for dense attention (DeepSeek-AI, 2026). Quest bounds the scores of cache pages (Tang et al., 2024), MoBA routes queries to blocks (Lu et al., 2025), and landmark tokens summarise blocks (Mohtashami & Jaggi, 2023). These groups are fixed runs of tokens, and the final scores remain per token.

Scoring one sequence against another is established in retrieval and time series. ColBERT sums, over query tokens, the best match among document tokens (Khattab & Zaharia, 2020); soft-DTW is a differentiable alignment cost (Cuturi & Blondel, 2017); and local alignment goes back to Smith and Waterman (1981). Hierarchical attention networks attend to words and then sentences for classification (Yang et al., 2016). Binding a sequence into one vector by position-specific operators is the basis of holographic reduced representations and hyperdimensional computing (Plate, 1995; Kanerva, 2009). The combination examined here, in which the cache entry for a word is its slot sequence and a word-level causal softmax scores that sequence as one unit, did not appear in this survey of the literature.

{t_related}
# 3 Formulation

## 3.1 Words, slots and the cache

A word w of n ≤ L primitives is placed into L = 16 slots. In a left-aligned layout, slot j holds cⱼ for j ≤ n and a padding symbol otherwise; a right-aligned layout pads first. Each primitive has a fixed vector e(c) ∈ ℝᵈ. In a word-level transformer, the cache entry for the word at position t of a layer holds slot keys and values,

$$K_t = (k_{{t1}}, \\ldots, k_{{tL}}), \\qquad V_t = (v_{{t1}}, \\ldots, v_{{tL}}). \\quad\\quad\\quad (1)$$

In the first layer kₜⱼ is a projection of e(cⱼ); in deeper layers it is a projection of a contextual state for that slot.

## 3.2 Cache layouts

Four layouts store the sequence differently (Figure 1):

$$k^{{\\mathrm{{bag}}}}(w) = \\sum_{{j=1}}^{{n}} e(c_j), \\qquad k^{{\\mathrm{{bound}}}}(w) = \\sum_{{j=1}}^{{n}} R_j\\, e(c_j) + R_{{n+1}}\\, e(\\mathrm{{EOS}}). \\quad\\quad\\quad (2)$$

The pooled bag is one vector without order. The bound layout applies an orthogonal operator Rⱼ to each slot before summing, as in holographic reduced representations; here each Rⱼ is a random signed permutation, so it is exactly orthogonal and costs O(d) to apply. Slot blocks split one vector of width d into L blocks of width d/L, one per slot. Concatenated slots keep L full vectors, which costs L times the memory of one vector, or (n + 1) vectors when stored ragged without padding.

![Figure 1. Word-level cache layouts and the three families of word scores.](FIG/fig1_layouts_scores.png){{width=6.3in}}

## 3.3 Word scores

The **slot-aligned** score adds slot-wise dot products,

$$s_{{\\wedge}}(q,t) = \\sum_{{j=1}}^{{L}} q_j^{{\\top}} k_{{tj}}, \\qquad e^{{s_\\wedge(q,t)}} = \\prod_{{j=1}}^{{L}} e^{{q_j^{{\\top}} k_{{tj}}}}. \\quad\\quad\\quad (3)$$

Its exponential is a product over slots, so a word is attended only if every slot agrees: the score behaves as a logical AND. The query's padding slots set how much an agreement on padding counts. Writing ω for the score of padding against padding, ω = 1 rewards words of the same extent and ω = 0 ignores length. Section 7 shows that ω switches the same score between identity and family retrieval.

The **hierarchical** score uses one query vector and lets any slot match,

$$s_{{\\vee}}(q,t) = \\log \\sum_{{j}} e^{{q^{{\\top}} k_{{tj}}}}, \\qquad s_{{\\mathrm{{LI}}}}(q,t) = \\sum_{{i}} \\tau \\log \\sum_{{j}} e^{{q_i^{{\\top}} k_{{tj}}/\\tau}} \\;\\to\\; \\sum_i \\max_j q_i^{{\\top}} k_{{tj}}. \\quad\\quad\\quad (4)$$

The left form is a logical OR over slots. When the query is itself a word with slots, the right form is late interaction in the style of ColBERT, which tends to a sum of maxima as τ → 0.

**Anchored** scores compute the slot-aligned score from both ends and take the larger, $s = \\max(s_{{\\wedge}}^{{\\rightarrow}}, s_{{\\wedge}}^{{\\leftarrow}})$, so that a stem can match its suffixed forms from the left and its prefixed forms from the right. A **best common shift** takes the maximum of the slot-aligned score over all relative offsets. **Local alignment** finds the best monotone matching with gaps, using the Smith–Waterman recursion

$$H_{{ij}} = \\max\\{{0,\\; H_{{i-1,j-1}} + \\mu(q_i, k_j),\\; H_{{i-1,j}} - \\gamma,\\; H_{{i,j-1}} - \\gamma\\}}, \\quad\\quad\\quad (5)$$

with match score μ and gap penalty γ; its score is the largest entry of H. Length-normalised versions divide a score s by $(n_q + n_k)/2$, the mean length of the two words. Table 2 summarises the rules and their costs.

{t_rules_def}
## 3.4 Outer softmax, values and positions

Whatever the score, the outer softmax runs over word positions with a causal mask, and the value read mixes the slot values of the attended words:

$$\\pi_t = \\frac{{e^{{s(q,t)}}}}{{\\sum_{{t' \\le T}} e^{{s(q,t')}}}}, \\qquad y = \\sum_{{t}} \\pi_t \\sum_{{j}} U_j\\, v_{{tj}}. \\quad\\quad\\quad (6)$$

Two position systems coexist: the inner position j says where a primitive sits in the word, and the outer position t says where the word sits in the text. The outer position should be a relative bias rather than a rotation of keys, because rotated keys can no longer be shared between occurrences of the same word (Section 4).

# 4 Exact properties

**Proposition 1 (concatenation and crosstalk).** The slot-aligned score of Equation 3 equals the dot product of the concatenated vectors $[q_1; \\ldots; q_L]$ and $[k_{{t1}}; \\ldots; k_{{tL}}]$. With slot blocks the same holds inside one vector of width d. If the slots are instead superposed with orthogonal operators Rⱼ, the bound score equals the slot-aligned score plus $\\sum_{{j \\ne j'}} (R_j q_j)^{{\\top}} (R_{{j'}} k_{{j'}})$; for independent unit slot vectors this crosstalk has mean zero and variance L(L − 1)/d.

Table 3 confirms the variance to within the sampling error at every width. At width 128, the crosstalk standard deviation is {f3(g('S01.crosstalk_sd_d128'))}, about 9% of the score of an exact match of 16 slots, which is why bound keys need a moderate width to separate near-duplicates (Section 6).

{t_cross}
**Proposition 2 (hierarchical scores are character attention).** Let pₜⱼ be the weights of ordinary character attention over all slots of all words. With the hierarchical score of Equation 4, the outer word weight πₜ equals Σⱼ pₜⱼ, and if the value read uses the inner softmax weights within each word, the word-level output equals the character-attention output exactly.

The OR score is therefore not a cheaper form of attention: it reads the same keys as character attention and produces the same result. Its value lies in reorganising character attention by word, so that whole words can be selected or skipped, which is how Native Sparse Attention uses block scores. Table 4 confirms both identities to rounding error.

**Proposition 3 (bags cannot see order).** Any function of a pooled bag Σⱼ e(cⱼ) gives the same value for all permutations of a word, however the vectors are learned. In the 50,000-word lexicon, {n0(g('S01.anagram_words'))} words ({pc(g('S01.anagram_word_share'))}) belong to {n0(g('S01.anagram_classes'))} anagram classes, and these words account for {pc(g('S01.anagram_token_mass'))} of running-text tokens, largely because short frequent words have rare anagram partners in the list. The bag vectors of all anagram pairs were bitwise identical, while the closest pair of bound vectors was {f3(g('S01.bound_anagram_min_distance'))} apart.

**Proposition 4 (slot-additive scores cannot express conjunctions).** Let s(w) = Σⱼ fⱼ(σⱼ(w)) be any score that adds per-slot contributions, which includes every slot-aligned score for a fixed query. For four words that differ only in slots i and j, with letters A or D in slot i and B or C in slot j, s(AB) + s(DC) = s(AC) + s(DB). No such score can rank both AB and DC above both AC and DB. One pairwise term t(σᵢ, σⱼ) is enough to do so.

Such 2×2 squares are common. Among lexicon words of 3 to 10 letters there are {n0(g('S01.xor_squares'))} of them, involving {n0(g('S01.xor_words_involved'))} words ({pc(g('S01.xor_words_share'))}). The most frequent three-letter example is *get* and *lot* against *got* and *let*: a query that should attend to *get* or *lot* but not to *got* or *let* cannot be written as a slot-additive score. The best of 100,000 random additive score tables reached a margin of {f3(g('S01.additive_best_margin'))}, never above zero, while one pairwise term reached a margin of 1. In a trained model, keys of deeper layers mix neighbouring characters and can carry such pairwise evidence; slot keys that each encode only their own character cannot.

**Proposition 5 (grouping by word).** If keys and values in a layer depend only on the word, all occurrences of a word share one score. Keeping for each distinct word g its occurrence count $n_g$ and value sum $S_g$ gives the exact softmax read as $\\sum_g e^{{s_g}} S_g / \\sum_g n_g e^{{s_g}}$, with work proportional to the number of distinct words G instead of the number of word tokens M. The same identity was verified for characters in the preceding paper of the series (Ghosh, 2026c). It holds for lexical layers and for relative position biases, but not for keys rotated by absolute position or made contextual.

{t_ident}
# 5 Accounting from English word statistics

The English list of wordfreq contains {n0(g('S00.all_types'))} word types, of which {n0(g('S00.alpha_types'))} are lowercase alphabetic and carry {pc(g('S00.alpha_mass_share'), 1)} of the token mass. Alphabetic tokens average {f2(g('S00.mean_letters_all_alpha'))} letters when weighted by frequency, and only {m(f"{100 * g('S00.alpha_over16_share'):.4f}")}% of their mass lies in words longer than 16 letters, so 16 slots suffice. The laboratory keeps the 50,000 most frequent alphabetic words of up to 16 letters, which cover {pc(g('S00.kept_mass_share'), 1)} of that mass and average {f2(g('S00.mean_letters_lexicon'))} letters, or {f2(g('S00.mean_slots'))} slots with one separator.

{t_ps}
Moving from characters to words therefore cuts dense causal pairs by a factor of about {f2(g('S00.pairs_ratio_1000'))} (Table 6). Table 5 shows what each layout costs per word. A pooled or block layout stores one key and one value, {n0(g('S00.pooled_bytes'))} bytes per head and layer, {f2(g('S00.char_bytes_per_word') / g('S00.pooled_bytes'))} times less than a character cache. A ragged concatenation stores exactly the character cache, so the saving of concatenated slots lies in the word-level softmax and in grouping, not in memory. Padding to 16 slots costs {n0(g('S00.concat_padded_bytes'))} bytes per word. Late interaction and alignment multiply query slots by key slots, about {f2(g('S00.mean_slots') ** 2)} slot pairs per comparison on average.

{t_pw}
# 6 Cache layout and width

Study S02 asks whether a query for a word can find that exact word among its near-duplicates, and whether the stored entry can spell the word back. Each of 1,000 trials draws a target word of 3 to 12 letters from the 20,000 most frequent words, adds up to eight near-duplicates (anagrams, affix relatives and words one edit away), and fills a history of 256 tokens by sampling words in proportion to their frequency. Character vectors are random unit vectors. The query is the target's own key with isotropic Gaussian noise of energy σ² per stored symbol, standing for contextual variation between query and key; the value used for spelling receives independent noise of the same size. A query succeeds only if the target scores strictly highest.

{t_lay}
![Figure 2. Exact-word retrieval and exact spelling against width, noise σ = 0.5.](FIG/fig2_layout_width.png){{width=6.3in}}

Order and width decide the result (Table 7, Figure 2). The raw pooled bag ranked the exact word first in only {pc(lv('bag', 128, '0.5', 'exact_word_top1'))} of trials at width 128: anagrams tie with it, and raw dot products also favour longer words. Cosine scoring removed the length bias and raised it to {pc(lv('bag-cos', 128, '0.5', 'exact_word_top1'))}, but the remaining third were ties with anagrams, which no width can break. The bound pooled key kept order in one vector: {pc(lv('bound', 32, '0.5', 'exact_word_top1'))} at width 32, {pc(lv('bound', 128, '0.5', 'exact_word_top1'), 1)} at 128 and all trials at 256, and it spelled the word exactly in {pc(lv('bound', 128, '0.5', 'spelling_exact'))} of trials at width 128. Slot blocks retrieved as well as bound keys, {pc(lv('blocks', 128, '0.5', 'exact_word_top1'), 1)} at width 128, but spelled poorly at small widths ({pc(lv('blocks', 64, '0.5', 'spelling_exact'), 1)} at 64), because a block of 4 dimensions cannot keep 27 symbols apart under noise. Concatenated slots were exact in every trial at every width, at sixteen times the memory.

{t_sweep}
The noise sweep (Table 8) separates retrieval from spelling. Retrieval aggregates evidence over all slots and degrades gradually: at σ = 1.5 the bound key still ranked the exact word first in {pc(lv('bound', 128, '1.5', 'exact_word_top1'))} of trials. Spelling must get every slot right and fails first: {pc(lv('bound', 128, '1.5', 'spelling_exact'))} for bound keys and none for blocks at the same noise. A single pooled vector can therefore address a word reliably long before it can reproduce the word, which echoes the finding of the character-span paper that exact spelling is best read from stored text (Ghosh, 2026c).

# 7 Alignment, anchors and word families

Study S03 compares the score rules on real English word families. A family is a stem with at least two suffixed forms and at least one prefixed form in the lexicon, built by plain concatenation from fixed affix lists; {n0(g('S03.eligible_families'))} stems qualified and {n0(g('S03.families'))} were drawn at random. Character vectors are orthonormal, so each character dot product is 1 for the same symbol and 0 otherwise, and only the logic of each rule differs. Two tasks are posed. In the identity task, every form of a family must outscore the other forms, its near-duplicates and 48 frequency-sampled fillers. In the family task, the stem must rank its suffixed and prefixed forms above its near-duplicates and fillers.

{t_rules}
![Figure 3. Identity and family retrieval for each score rule.](FIG/fig3_rules.png){{width=6.1in}}

No fixed rule served both tasks (Table 9, Figure 3).

- **Padding decides identity.** Left-aligned slots with padding counted ranked the exact word first in every query, because padding agreement encodes length. The same slots with letters only tied the stem with its suffixed forms in {pc(rule('slots from start, letters only', 'identity_tied'))} of queries.
- **Anchors decide families.** Left-aligned slots found suffixed forms (recall {f3(rule('slots from start, letters only', 'family_recall_suffixed'))}) but almost no prefixed ones ({f3(rule('slots from start, letters only', 'family_recall_prefixed'))}); right-aligned slots did the reverse. Taking the larger of the two anchored scores found both, with a family MAP of {f3(rule('two anchors, maximum', 'family_map'))}, equal to the best common shift and to local alignment ({f3(rule('local alignment', 'family_map'))}) at O(2Ld) instead of O(L²d) work.
- **Adding anchors double-counts.** The sum of the two anchored scores lets a same-length word one edit away, such as *talk* for *walk*, collect evidence from both ends; its family MAP fell to {f3(rule('two anchors, sum', 'family_map'))}.
- **Order-free rules are weak at identity.** The bag of letters and late interaction both reached a family MAP of about {f3(rule('bag of letters', 'family_map'))} but ranked the exact word first in only {pc(rule('bag of letters', 'identity_top1'))} and {pc(rule('late interaction (MaxSim)', 'identity_top1'))} of identity queries.
- **Normalisation trades one task for the other.** Length-normalised alignment was exact at identity but its family MAP dropped to {f3(rule('local alignment, length-normalised', 'family_map'))}, mostly because prefixed forms, being longer, lose to same-length neighbours.

The two tasks differ only in whether length should count, which is exactly what the padding weight ω of Equation 3 controls. With ω = 1, two-anchor slots were exact at identity ({f3(rule('two anchors, maximum, padding counted', 'identity_top1'))}); with ω = 0 they reached the best family MAP. In a trained model ω is not a hyperparameter but part of the query: the components of the query's padding slots set it per head and per position. Two anchored slot-aligned scores with a query-controlled padding weight therefore cover both tasks at linear cost in the number of slots.

# 8 Long histories: screening and grouping

Study S04 asks how word-level attention scales. Histories of M = 256 to 16,384 word tokens are built as in Section 6, with the target and its near-duplicates inserted once. Each cached word holds a pooled key (bound or bag) and concatenated slot keys, all of width 128, and queries carry noise σ = 0.5. Readers either scan all slot keys, scan only the pooled keys, or screen with the pooled key and rerank the K best words with the slot-aligned score.

{t_long}
![Figure 4. Exact-word retrieval and multiply-adds per query as the history grows.](FIG/fig4_long_history.png){{width=6.3in}}

A bound screen with a slot-aligned rerank of eight words found the exact word in every trial at every length, and the target was always among the eight screened words (Table 10). The bound key alone was nearly as good ({pc(hv('bound pooled scan only', 16384, 'exact_word_top1'), 1)} at 16,384 words), so the rerank serves to make the decision exact. Bag screens collapsed as the history grew: with K = 32, the target survived the screen in {pc(hv('bag screen → slot rerank, K=32', 16384, 'stage1_recall'))} of trials at 16,384 words.

The work per query fell accordingly. At 16,384 words, dense character attention reads {n0(hv('dense character attention', 16384, 'mac_per_query_tokens'))} multiply-adds per query. The two-stage reader needs {n0(hv('bound screen → slot rerank, K=8', 16384, 'mac_per_query_tokens'))} when it screens every token, {f2(hv('dense character attention', 16384, 'mac_per_query_tokens') / hv('bound screen → slot rerank, K=8', 16384, 'mac_per_query_tokens'))} times fewer, and {n0(hv('bound screen → slot rerank, K=8', 16384, 'mac_per_query_grouped'))} when it screens distinct words only, {f2(hv('dense character attention', 16384, 'mac_per_query_tokens') / hv('bound screen → slot rerank, K=8', 16384, 'mac_per_query_grouped'))} times fewer. Grouping helps more as histories grow, because distinct words grow more slowly than tokens, in line with Heaps' law (Heaps, 1978): the share of distinct words fell from {f2(float(dist[0]['G_over_M']))} at 256 tokens to {f2(float(dist[-1]['G_over_M']))} at 16,384 (Table 11).

{t_dist}
# 9 A Step 1 design, and what Step 2 must keep

The results suggest a concrete dense design for word-level attention.

1. **Cache per word:** one pooled bound key for screening plus ragged slot keys and values. The pooled key adds 256 bytes per word, head and layer at width 128 in BF16, {pc(pooled_key_share, 1)} of the character cache, while the slot vectors are the character cache itself.
2. **Read:** screen words with the pooled key (over distinct words wherever keys are shared), rerank the K best with two anchored slot-aligned scores whose padding weight comes from the query, and take the outer softmax over the K selected words.
3. **Values:** read the slot values of the selected words, so the attended output is itself a sequence of slots, a soft word that later layers can spell or project.
4. **Positions:** use a relative bias for the outer position and the slot index for the inner position, so that lexical keys can be shared and grouped.
5. **Pairwise evidence:** where conjunctions over slots matter, as for codes and part numbers, let slot keys carry neighbouring characters or add adjacent-pair terms; slot-additive scores alone cannot express them.

Step 2 replaces each dense slot vector with a sparse dictionary over the fixed primitive vocabulary, the word-Vocabucapillary. Each property found here carries over unchanged, because it concerns the structure of the score, not the density of its vectors. The AND, OR and anchor logic, the role of the padding weight, the conjunction limit, the invariance of bags and the exactness of grouping all remain. What changes is the arithmetic: slot dot products become table lookups over the fixed primitives, and the value mixture becomes an accumulator of slot-by-primitive coefficients.

# 10 Limitations

The character vectors are random or orthonormal rather than learned, and the queries are noisy copies of keys rather than outputs of a trained model, so the studies measure what each layout and score can represent, not what training would find. Proposition 3 and Proposition 4 hold whatever is learned; the width and noise results of Sections 6 and 8 depend on the geometry that training would produce. The families use plain concatenation affixes, so spelling changes such as *make* and *making* are missed, and the lexicon contains names and rare tokens that inflate the anagram counts. Only English letters were tested. No model was trained end to end, the subword baseline was not run, and no latency was measured on hardware.

# 11 Conclusion

Word-level self-attention over sequence-valued keys is possible with an ordinary dense cache, and its behaviour is governed by a few exact facts. Slot-aligned scores are concatenated attention with AND semantics; hierarchical scores are character attention regrouped by word; bags lose order; and slot-additive scores cannot express conjunctions, which are common among English words. Under noise, a single bound key per word addresses words reliably at moderate width, but spelling needs the slots themselves. No fixed score serves both identity and family retrieval, yet two anchored slot scores with a query-controlled padding weight cover both at linear cost. A bound screen with a slot rerank keeps retrieval exact up to 16,384 words at a small fraction of the work of character attention. These structures define what the word-Vocabucapillary of Step 2 must preserve.

# Appendix A Proofs

**Proposition 1.** The slot-aligned score $\\sum_j q_j^{{\\top}} k_{{tj}}$ is the inner product of the stacked vectors by definition, and disjoint blocks are a special case. For superposed slots,

$$\\Big(\\sum_j R_j q_j\\Big)^{{\\top}}\\Big(\\sum_{{j'}} R_{{j'}} k_{{j'}}\\Big) = \\sum_j q_j^{{\\top}} R_j^{{\\top}} R_j\\, k_j + \\sum_{{j \\ne j'}} (R_j q_j)^{{\\top}} (R_{{j'}} k_{{j'}}),$$

and $R_j^{{\\top}} R_j = I$. For a cross term with independent unit vectors, $R_j q_j$ and $R_{{j'}} k_{{j'}}$ are independent and isotropic, so the term has mean zero and variance $1/d$. The $L(L-1)$ cross terms are uncorrelated, giving variance $L(L-1)/d$.

**Proposition 2.** Write $a_{{tj}} = q^{{\\top}} k_{{tj}}$ and $s_t = \\log \\sum_j e^{{a_{{tj}}}}$. Then

$$\\pi_t = \\frac{{e^{{s_t}}}}{{\\sum_{{t'}} e^{{s_{{t'}}}}}} = \\frac{{\\sum_j e^{{a_{{tj}}}}}}{{\\sum_{{t',j'}} e^{{a_{{t'j'}}}}}} = \\sum_j p_{{tj}}.$$

With inner weights $\\alpha_{{tj}} = e^{{a_{{tj}}}} / \\sum_{{j''}} e^{{a_{{tj''}}}}$, the product $\\pi_t \\alpha_{{tj}}$ equals $p_{{tj}}$, so $\\sum_t \\pi_t \\sum_j \\alpha_{{tj}} v_{{tj}} = \\sum_{{t,j}} p_{{tj}} v_{{tj}}$.

**Proposition 3.** A sum is invariant to the order of its terms, so any function of it is.

**Proposition 4.** The other slots contribute equally to all four words, so

$$s(AB) + s(DC) = f_i(A) + f_j(B) + f_i(D) + f_j(C) = s(AC) + s(DB).$$

If both preferred words exceeded both others by a margin $\\mu > 0$, then $s(AB) + s(DC) \\ge s(AC) + s(DB) + 2\\mu$, a contradiction. With a pairwise term $t(A,B) = t(D,C) = 1$ and zero otherwise, the preferred words gain a margin of 1.

**Proposition 5.** Grouping equal terms gives $\\sum_i e^{{s_i}} v_i = \\sum_g e^{{s_g}} S_g$ and $\\sum_i e^{{s_i}} = \\sum_g n_g e^{{s_g}}$.

# Appendix B The immutable C# laboratory

The laboratory is a .NET 8 console project without external packages. Domain state is held in sealed records and read-only lists, every computation is a pure static function, and randomness comes from a SplitMix64 generator implemented as a readonly record struct whose draws return the value and the successor generator. A minimal MessagePack reader decodes the English frequency file of wordfreq 3.1.1 (Speer, 2022; data under CC BY-SA 4.0), whose centibel buckets give each word in bucket i the frequency $10^{{-i/100}}$. One output boundary writes CSV tables and a JSON file of headline values; the 50,000-word lexicon and every morphology case are exported for checking.

A separate Python program decodes the same file with its own MessagePack reader, rebuilds the lexicon, recounts anagram classes and 2×2 squares with a different algorithm, re-scores all morphology cases with independent implementations of every rule, regenerates the history trials with a port of the generator, and checks the log-sum-exp identity with numpy; {py_agree} quantities agreed. Running `dotnet run -c Release` executes all studies in about two minutes on two cores.

Table: Table 12. Studies of the laboratory.

| Study | Sections | Question | Kind of result |
|----------|----------|----------------------------------------------|--------------------|
| S00 | 5 | What do words, characters and layouts cost in English? | Accounting |
| S01 | 4 | Crosstalk, the hierarchical identity, bag invariance and the conjunction limit | Exact and Monte Carlo |
| S02 | 6 | Which layout finds and spells the exact word, at which width and noise? | Monte Carlo |
| S03 | 7 | Which score rules serve identity and family retrieval on English words? | Exact counts |
| S04 | 8 | How do screening and grouping scale to 16,384 words? | Monte Carlo and accounting |

# References

Clark, J. H., Garrette, D., Turc, I., & Wieting, J. (2022). CANINE: Pre-training an efficient tokenization-free encoder for language representation. *Transactions of the Association for Computational Linguistics, 10*, 73–91. https://doi.org/10.1162/tacl_a_00448

Cuturi, M., & Blondel, M. (2017). Soft-DTW: A differentiable loss function for time-series. *Proceedings of the 34th International Conference on Machine Learning*. arXiv:1703.01541.

DeepSeek-AI. (2026). *DeepSeek-V4: Towards highly efficient million-token context intelligence* [Preprint]. arXiv:2606.19348.

Ghosh, D. P. (2026a). *KV coefficient memory for Attentionlet* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.31586.70088

Ghosh, D. P. (2026b). *Vocabucapillary for cacheless transformer* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.36209.44648

Ghosh, D. P. (2026c). *Character vocabularies and ISET span memory: Spelling, order and linear-time reading in Vocabucapillary models* [Manuscript].

Heaps, H. S. (1978). *Information retrieval: Computational and theoretical aspects*. Academic Press.

Ho, N., Bae, S., Kim, T., Jo, H., Kim, Y., Schuster, T., Fisch, A., Thorne, J., & Yun, S.-Y. (2024). Block Transformer: Global-to-local language modeling for fast inference. *Advances in Neural Information Processing Systems, 37*. arXiv:2406.02657.

Kanerva, P. (2009). Hyperdimensional computing: An introduction to computing in distributed representation with high-dimensional random vectors. *Cognitive Computation, 1*(2), 139–159. https://doi.org/10.1007/s12559-009-9009-8

Khattab, O., & Zaharia, M. (2020). ColBERT: Efficient and effective passage search via contextualized late interaction over BERT. *Proceedings of the 43rd International ACM SIGIR Conference*, 39–48. https://doi.org/10.1145/3397271.3401075

Lu, E., et al. (2025). *MoBA: Mixture of block attention for long-context LLMs* [Preprint]. arXiv:2502.13189.

Mohtashami, A., & Jaggi, M. (2023). Landmark attention: Random-access infinite context length for transformers. *Advances in Neural Information Processing Systems, 36*. arXiv:2305.16300.

Neitemeier, P., Deiseroth, B., Eichenberg, C., & Balles, L. (2025). Hierarchical autoregressive transformers: Combining byte- and word-level processing for robust, adaptable language models. *International Conference on Learning Representations*. arXiv:2501.10322.

Pagnoni, A., et al. (2024). *Byte latent transformer: Patches scale better than tokens* [Preprint]. arXiv:2412.09871.

Plate, T. A. (1995). Holographic reduced representations. *IEEE Transactions on Neural Networks, 6*(3), 623–641. https://doi.org/10.1109/72.377968

Slagle, K. (2024). SpaceByte: Towards deleting tokenization from large language modeling. *Advances in Neural Information Processing Systems, 37*. arXiv:2404.14408.

Smith, T. F., & Waterman, M. S. (1981). Identification of common molecular subsequences. *Journal of Molecular Biology, 147*(1), 195–197. https://doi.org/10.1016/0022-2836(81)90087-5

Speer, R. (2022). *wordfreq: Access a database of word frequencies, in various natural languages* (Version 3.1.1) [Software and data]. https://github.com/rspeer/wordfreq

Tang, J., Zhao, Y., Zhu, K., Xiao, G., Kasikci, B., & Han, S. (2024). Quest: Query-aware sparsity for efficient long-context LLM inference. *Proceedings of the 41st International Conference on Machine Learning*. arXiv:2406.10774.

Tay, Y., Tran, V. Q., Ruder, S., Gupta, J., Chung, H. W., Bahri, D., Qin, Z., Baumgartner, S., Yu, C., & Metzler, D. (2022). Charformer: Fast character transformers via gradient-based subword tokenization. *International Conference on Learning Representations*. arXiv:2106.12672.

Xue, L., Barua, A., Constant, N., Al-Rfou, R., Narang, S., Kale, M., Roberts, A., & Raffel, C. (2022). ByT5: Towards a token-free future with pre-trained byte-to-byte models. *Transactions of the Association for Computational Linguistics, 10*, 291–306. https://doi.org/10.1162/tacl_a_00461

Yang, Z., Yang, D., Dyer, C., He, X., Smola, A., & Hovy, E. (2016). Hierarchical attention networks for document classification. *Proceedings of NAACL-HLT 2016*, 1480–1489. https://doi.org/10.18653/v1/N16-1174

Yu, L., Simig, D., Flaherty, C., Aghajanyan, A., Zettlemoyer, L., & Lewis, M. (2023). MEGABYTE: Predicting million-byte sequences with multiscale transformers. *Advances in Neural Information Processing Systems, 36*. arXiv:2305.07185.

Yuan, J., Gao, H., Dai, D., Luo, J., Zhao, L., Zhang, Z., Xie, Z., Wei, Y. X., Wang, L., Xiao, Z., Wang, Y., Ruan, C., Zhang, M., Liang, W., & Zeng, W. (2025). Native sparse attention: Hardware-aligned and natively trainable sparse attention. *Proceedings of the 63rd Annual Meeting of the Association for Computational Linguistics*. arXiv:2502.11089.
"""
md = md.replace("FIG/", str(FIG) + "/")
(HERE / "paper.md").write_text(md, encoding="utf8")
subprocess.run(["pandoc", str(HERE / "paper.md"), "-o", str(HERE / "raw.docx"), "--reference-doc", str(HERE / "ref.docx")], check=True)
docxfix.repair(HERE / "raw.docx", HERE / "paper.docx")
(HERE / "raw.docx").unlink()
print("paper written:", len(md.split()), "words")
