using SqLab.Core;

namespace SqLab.Experiments;

/// <summary>
/// Cache layout against width: can a noisy query for a word find that exact word among its near-duplicates in a
/// 256-word history, and can the word's spelling be read back from its noisy value? Layouts: pooled bag, pooled with
/// position binding, slot blocks (one vector) and concatenated slots (sixteen vectors).
/// </summary>
public static class S02_Layouts
{
    private const ulong Seed = 202;
    public const int History = 256, Trials = 1000, NeighbourCap = 8;
    public static readonly string[] Layouts = { "bag", "bag-cos", "bound", "bound-cos", "blocks", "concat" };

    public sealed record Trial(string Target, IReadOnlyList<string> Neighbours, IReadOnlyList<string> Distinct, double TokenSlots);
    public sealed record Outcome(bool Correct, bool Tie, bool NeighbourWon, bool Spelled);

    public static IReadOnlyList<Trial> MakeTrials(Lexicon lex, int history, int count, ulong seed, int maxRank = 20000)
    {
        var trials = new List<Trial>();
        var r = Rng.Derive(seed, 1);
        while (trials.Count < count)
        {
            var (idx, r1) = r.NextInt(Math.Min(maxRank, lex.Words.Count)); r = r1;
            string w = lex.Words[idx];
            if (w.Length < 3 || w.Length > 12) continue;
            var nb = lex.Neighbours(w, NeighbourCap);
            if (nb.Count < 2) continue;
            var tokens = new List<string> { w };
            tokens.AddRange(nb);
            var rr = Rng.Derive(seed, 100 + (ulong)trials.Count);
            while (tokens.Count < history) { var (k, nr) = lex.Sample(rr); rr = nr; tokens.Add(lex.Words[k]); }
            trials.Add(new Trial(w, nb, tokens.Distinct().ToArray(), tokens.Sum(x => x.Length + 1.0)));
        }
        return trials;
    }

    public static ExperimentResult Run(Lexicon lex)
    {
        var trials = MakeTrials(lex, History, Trials, Seed);
        var rows = new List<object[]>();
        var h = new Dictionary<string, double>();
        void Evaluate(int d, double sigma)
        {
            var code = CharCode.Random(d, Rng.Derive(Seed, (ulong)(10 + d)));
            var blockCode = CharCode.Random(d / Sym.L, Rng.Derive(Seed, (ulong)(20 + d)));
            var binder = Binder.Create(d, Sym.L + 1, Rng.Derive(Seed, (ulong)(30 + d)));
            foreach (var layout in Layouts)
            {
                string baseLayout = layout.Replace("-cos", "");
                bool cosine = layout.EndsWith("-cos");
                double[] Key(string w) => baseLayout switch
                {
                    "bag" => Layout.Bag(w, code),
                    "bound" => Layout.Bound(w, code, binder),
                    "blocks" => Layout.Blocks(w, blockCode),
                    _ => Layout.Concat(w, code),
                };
                var outcomes = trials.AsParallel().AsOrdered().Select((t, ti) =>
                {
                    var rng = Rng.Derive(Seed, (ulong)(1_000_000 + ti * 37 + d * 7 + (int)(sigma * 100)));
                    var keys = t.Distinct.Select(Key).ToArray();
                    int target = Array.IndexOf(t.Distinct.ToArray(), t.Target);
                    var (q, r1) = Layout.Noisy(keys[target], sigma, Layout.SymbolsStored(baseLayout, t.Target), rng);
                    var scores = keys.Select(k => cosine ? Lin.Dot(q, k) / Math.Sqrt(Lin.Norm2(k)) : Lin.Dot(q, k)).ToArray();
                    double best = scores.Max();
                    int winners = scores.Count(s => s == best);
                    int arg = Array.IndexOf(scores, best);
                    bool correct = arg == target && winners == 1;
                    bool tie = winners > 1 && scores[target] == best;
                    bool nbWon = !correct && t.Neighbours.Contains(t.Distinct[arg]);
                    var (v, _) = Layout.Noisy(keys[target], sigma, Layout.SymbolsStored(baseLayout, t.Target), r1);
                    bool spelled = layout switch
                    {
                        "bag" or "bag-cos" or "bound-cos" => false,
                        "bound" => Layout.DecodeBound(v, code, binder) == t.Target,
                        "blocks" => Layout.DecodeSlots(v, blockCode).SequenceEqual(Sym.Left(t.Target)),
                        _ => Layout.DecodeSlots(v, code).SequenceEqual(Sym.Left(t.Target)),
                    };
                    return new Outcome(correct, tie, nbWon, spelled);
                }).ToArray();
                double acc = outcomes.Average(o => o.Correct ? 1.0 : 0);
                double ties = outcomes.Average(o => o.Tie ? 1.0 : 0);
                double nb = outcomes.Average(o => o.NeighbourWon ? 1.0 : 0);
                double sp = outcomes.Average(o => o.Spelled ? 1.0 : 0);
                int floats = layout == "concat" ? Sym.L * d : d;
                bool spells = layout is "bound" or "blocks" or "concat";
                rows.Add(new object[] { d, sigma, layout, floats, acc, nb, ties, spells ? sp : double.NaN });
                string key = $"d{d}_s{sigma:0.00}_{layout}";
                h[$"{key}_acc"] = acc; h[$"{key}_neighbour"] = nb; h[$"{key}_tie"] = ties;
                if (spells) h[$"{key}_spelled"] = sp;
            }
        }
        foreach (int d in new[] { 32, 64, 128, 256 }) Evaluate(d, 0.5);
        foreach (double sigma in new[] { 0.25, 1.0, 1.5 }) Evaluate(128, sigma);
        h["mean_distinct_words"] = trials.Average(t => t.Distinct.Count);
        h["mean_neighbours"] = trials.Average(t => t.Neighbours.Count);
        var table = Table.Of("layouts", new[] { "width_d", "noise_sigma", "layout", "floats_per_word", "exact_word_top1", "neighbour_won", "tied_with_target", "spelling_exact" }, rows);
        var sample = Table.Of("sample_trials", new[] { "target", "neighbours" }, trials.Take(30).Select(t => new object[] { t.Target, string.Join(" ", t.Neighbours) }));
        return new ExperimentResult("S02", "Cache layout and width", new[] { table, sample }, h);
    }
}
