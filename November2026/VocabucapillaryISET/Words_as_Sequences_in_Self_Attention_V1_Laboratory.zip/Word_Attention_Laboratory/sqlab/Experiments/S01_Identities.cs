using SqLab.Core;

namespace SqLab.Experiments;

/// <summary>
/// Exact properties of word scores over sequence-valued keys: crosstalk of position binding, the identity between the
/// hierarchical (log-sum-exp) word score and character attention, the permutation invariance of pooled bags, and the
/// impossibility of conjunctive preferences for slot-additive scores, with their frequency in the English lexicon.
/// </summary>
public static class S01_Identities
{
    private const ulong Seed = 11;

    public static ExperimentResult Run(Lexicon lex)
    {
        var h = new Dictionary<string, double>();

        // (1) Crosstalk of a bound pooled key against the slot-aligned score, unit slot vectors, L = 16 slots.
        var cross = new List<object[]>();
        foreach (int d in new[] { 64, 128, 256, 512, 1024 })
        {
            var b = Binder.Create(d, Sym.L, Rng.Derive(Seed, (ulong)d));
            var r = Rng.Derive(Seed, 1000 + (ulong)d);
            var diffs = new double[2000];
            for (int n = 0; n < diffs.Length; n++)
            {
                double direct = 0;
                var qb = new double[d]; var kb = new double[d];
                for (int j = 0; j < Sym.L; j++)
                {
                    var (gq, r1) = Lin.Gaussians(r, d); var (gk, r2) = Lin.Gaussians(r1, d); r = r2;
                    double nq = Math.Sqrt(Lin.Norm2(gq)), nk = Math.Sqrt(Lin.Norm2(gk));
                    var q = gq.Select(x => x / nq).ToArray(); var k = gk.Select(x => x / nk).ToArray();
                    direct += Lin.Dot(q, k);
                    var bq = b.Apply(j, q); var bk = b.Apply(j, k);
                    for (int i = 0; i < d; i++) { qb[i] += bq[i]; kb[i] += bk[i]; }
                }
                diffs[n] = Lin.Dot(qb, kb) - direct;
            }
            double sd = Math.Sqrt(diffs.Select(x => x * x).Average());
            double theory = Math.Sqrt(Sym.L * (Sym.L - 1.0) / d);
            cross.Add(new object[] { d, sd, theory, sd / theory, sd / Sym.L });
            h[$"crosstalk_sd_d{d}"] = sd;
            h[$"crosstalk_theory_d{d}"] = theory;
        }
        var crossTable = Table.Of("crosstalk", new[] { "width_d", "measured_sd", "theory_sqrt_L(L-1)/d", "ratio", "sd_relative_to_exact_match_score" }, cross);

        // (2) Hierarchical word score: word softmax with log-sum-exp scores equals character attention grouped by word.
        double maxMass = 0, maxValue = 0;
        var rr = Rng.Derive(Seed, 2);
        for (int c = 0; c < 200; c++)
        {
            int words = 40, dk = 64, dv = 32;
            var lengths = new int[words];
            for (int t = 0; t < words; t++) { var (l, nr) = rr.NextInt(Sym.L); lengths[t] = l + 1; rr = nr; }
            int n = lengths.Sum();
            var (kk, r1) = Lin.Gaussians(rr, n * dk); var (vv, r2) = Lin.Gaussians(r1, n * dv); var (qq, r3) = Lin.Gaussians(r2, dk); rr = r3;
            var logits = Enumerable.Range(0, n).Select(i => Lin.Dot(qq, kk.Skip(i * dk).Take(dk).ToArray()) / Math.Sqrt(dk)).ToArray();
            var p = Lin.Softmax(logits);
            var yChar = new double[dv];
            for (int i = 0; i < n; i++) for (int j = 0; j < dv; j++) yChar[j] += p[i] * vv[i * dv + j];
            var wordScore = new double[words];
            var yWord = new double[dv];
            int off = 0;
            var inner = new List<double[]>();
            for (int t = 0; t < words; t++)
            {
                var seg = logits.Skip(off).Take(lengths[t]).ToArray();
                double mx = seg.Max();
                wordScore[t] = mx + Math.Log(seg.Sum(x => Math.Exp(x - mx)));
                inner.Add(Lin.Softmax(seg).ToArray());
                off += lengths[t];
            }
            var pi = Lin.Softmax(wordScore);
            off = 0;
            for (int t = 0; t < words; t++)
            {
                double mass = p.Skip(off).Take(lengths[t]).Sum();
                maxMass = Math.Max(maxMass, Math.Abs(mass - pi[t]));
                for (int j = 0; j < lengths[t]; j++) for (int z = 0; z < dv; z++) yWord[z] += pi[t] * inner[t][j] * vv[(off + j) * dv + z];
                off += lengths[t];
            }
            for (int z = 0; z < dv; z++) maxValue = Math.Max(maxValue, Math.Abs(yWord[z] - yChar[z]));
        }
        h["lse_word_mass_max_gap"] = maxMass;
        h["lse_value_max_gap"] = maxValue;

        // (3) Bags cannot separate anagrams; bound pooled keys can.
        var classes = lex.AnagramClasses.Values.Where(c => c.Count >= 2).ToArray();
        int anagramWords = classes.Sum(c => c.Count);
        double anagramMass = classes.Sum(c => c.Sum(i => lex.Prob[i]));
        var code = CharCode.Random(128, Rng.Derive(Seed, 3));
        var binder = Binder.Create(128, Sym.L + 1, Rng.Derive(Seed, 4));
        double maxBagGap = 0, minBoundGap = double.PositiveInfinity;
        foreach (var cl in classes)
        {
            var bag0 = Layout.Bag(lex.Words[cl[0]], code);
            var bnd0 = Layout.Bound(lex.Words[cl[0]], code, binder);
            foreach (int i in cl.Skip(1))
            {
                var bag = Layout.Bag(lex.Words[i], code);
                var bnd = Layout.Bound(lex.Words[i], code, binder);
                maxBagGap = Math.Max(maxBagGap, bag.Select((x, z) => Math.Abs(x - bag0[z])).Max());
                minBoundGap = Math.Min(minBoundGap, Math.Sqrt(bnd.Select((x, z) => (x - bnd0[z]) * (x - bnd0[z])).Sum()));
            }
        }
        h["anagram_classes"] = classes.Length;
        h["anagram_words"] = anagramWords;
        h["anagram_word_share"] = anagramWords / (double)lex.Words.Count;
        h["anagram_token_mass"] = anagramMass;
        h["bag_anagram_max_gap"] = maxBagGap;
        h["bound_anagram_min_distance"] = minBoundGap;

        // (4) Slot-additive scores cannot prefer {AB, DC} over {AC, DB}: count such 2×2 squares among lexicon words.
        long squares = 0;
        var involved = new HashSet<string>();
        string example = "";
        double exampleRank = double.PositiveInfinity;
        foreach (var group in lex.Words.Where(w => w.Length >= 3 && w.Length <= 10).GroupBy(w => w.Length))
        {
            var words = group.ToArray();
            int len = group.Key;
            for (int i = 0; i < len; i++)
                for (int j = i + 1; j < len; j++)
                {
                    var buckets = words.GroupBy(w => w.Remove(j, 1).Remove(i, 1)).Where(g => g.Count() >= 4);
                    foreach (var bk in buckets)
                    {
                        var set = bk.ToHashSet();
                        var list = bk.ToArray();
                        for (int a = 0; a < list.Length; a++)
                            for (int c = a + 1; c < list.Length; c++)
                            {
                                var w1 = list[a]; var w2 = list[c];
                                if (string.CompareOrdinal(w1, w2) > 0) (w1, w2) = (w2, w1);
                                if (w1[i] == w2[i] || w1[j] == w2[j]) continue;
                                string x = Swap(w1, j, w2[j]), y = Swap(w2, j, w1[j]);
                                if (!set.Contains(x) || !set.Contains(y)) continue;
                                if (string.CompareOrdinal(w1, x) > 0 || string.CompareOrdinal(w1, y) > 0) continue;  // count each square once, from its smallest word
                                squares++;
                                involved.UnionWith(new[] { w1, w2, x, y });
                                double rank = new[] { w1, w2, x, y }.Max(z => (double)lex.Index[z]);
                                if (len == 3 && rank < exampleRank) { exampleRank = rank; example = $"{w1} {w2} | {x} {y}"; }
                            }
                    }
                }
        }
        h["xor_squares"] = squares;
        h["xor_words_involved"] = involved.Count;
        h["xor_words_share"] = involved.Count / (double)lex.Words.Count(w => w.Length >= 3 && w.Length <= 10);
        // Random additive tables never achieve a positive margin; a pairwise term does.
        double bestAdditive = double.NegativeInfinity;
        var ra = Rng.Derive(Seed, 5);
        for (int n = 0; n < 100_000; n++)
        {
            var (t, nr) = Lin.Gaussians(ra, 4); ra = nr;               // a_A, a_D, b_B, b_C
            double sAB = t[0] + t[2], sDC = t[1] + t[3], sAC = t[0] + t[3], sDB = t[1] + t[2];
            double margin = new[] { sAB - sAC, sAB - sDB, sDC - sAC, sDC - sDB }.Min();
            bestAdditive = Math.Max(bestAdditive, margin);
        }
        h["additive_best_margin"] = bestAdditive;
        h["pairwise_margin"] = 1.0;                                       // t(A,B) = t(D,C) = 1, others 0
        var xor = Table.Of("conjunction", new[] { "quantity", "value" }, new[]
        {
            new object[] { "2×2 slot squares among 3–10 letter lexicon words", squares },
            new object[] { "words in at least one square", involved.Count },
            new object[] { "example square (prefer first pair over second)", example },
            new object[] { "best margin of 100,000 random slot-additive tables", bestAdditive },
            new object[] { "margin with one adjacent-pair term", 1.0 },
        });
        var identities = Table.Of("identities", new[] { "check", "value", "requirement" }, new[]
        {
            new object[] { "word mass from log-sum-exp scores minus grouped character mass (max)", maxMass, "rounding only" },
            new object[] { "nested word read minus character attention read (max)", maxValue, "rounding only" },
            new object[] { "bag vectors of anagram pairs (max abs difference)", maxBagGap, "exactly 0" },
            new object[] { "bound vectors of anagram pairs (min distance)", minBoundGap, "> 0" },
        });
        return new ExperimentResult("S01", "Exact properties of sequence-valued word scores", new[] { crossTable, identities, xor }, h);
    }

    private static string Swap(string w, int pos, char c) => w[..pos] + c + w[(pos + 1)..];
}
