using SqLab.Core;

namespace SqLab.Experiments;

/// <summary>
/// Word-level retrieval over long histories with a dense cache: a full slot-aligned scan, a pooled scan alone, and two
/// stages in which a pooled word key (bound or bag) selects K words for a slot-aligned rerank, as the history doubles.
/// Also counts distinct words (grouping) and the work of each reader against dense character attention.
/// </summary>
public static class S04_LongHistory
{
    private const ulong Seed = 404;
    public const int D = 128, Trials = 200;
    public const double Sigma = 0.5;
    public static readonly int[] Ks = { 8, 32 };

    public sealed record Outcome(bool Full, bool Bound, bool Bag, IReadOnlyList<bool> TwoBound, IReadOnlyList<bool> TwoBag,
        IReadOnlyList<bool> RecallBound, IReadOnlyList<bool> RecallBag, int Distinct, double Chars, double DistinctSlots);

    public static ExperimentResult Run(Lexicon lex)
    {
        var code = CharCode.Random(D, Rng.Derive(Seed, 1));
        var binder = Binder.Create(D, Sym.L + 1, Rng.Derive(Seed, 2));
        var rows = new List<object[]>();
        var heaps = new List<object[]>();
        var h = new Dictionary<string, double>();
        foreach (int m in new[] { 256, 1024, 4096, 16384 })
        {
            var trials = S02_Layouts.MakeTrials(lex, m, Trials, Seed + (ulong)m);
            var outs = trials.AsParallel().AsOrdered().Select((t, ti) =>
            {
                var rng = Rng.Derive(Seed, (ulong)(m * 1000 + ti));
                var words = t.Distinct;
                var concat = words.Select(w => Layout.Concat(w, code)).ToArray();
                var bound = words.Select(w => Layout.Bound(w, code, binder)).ToArray();
                var bag = words.Select(w => Layout.Bag(w, code)).ToArray();
                const int target = 0;
                var (qc, r1) = Layout.Noisy(concat[target], Sigma, Sym.L, rng);
                var (qb, r2) = Layout.Noisy(bound[target], Sigma, Layout.SymbolsStored("bound", t.Target), r1);
                var (qg, _) = Layout.Noisy(bag[target], Sigma, Layout.SymbolsStored("bag", t.Target), r2);
                var sc = concat.Select(k => Lin.Dot(qc, k)).ToArray();
                var sb = bound.Select(k => Lin.Dot(qb, k)).ToArray();
                var sg = bag.Select(k => Lin.Dot(qg, k)).ToArray();
                bool Strict(IReadOnlyList<double> s, IReadOnlyList<int> among)
                {
                    double best = among.Max(i => s[i]);
                    var top = among.Where(i => s[i] == best).ToArray();
                    return top.Length == 1 && top[0] == target;
                }
                var all = Enumerable.Range(0, words.Count).ToArray();
                var twoBound = new List<bool>(); var twoBag = new List<bool>(); var recB = new List<bool>(); var recG = new List<bool>();
                foreach (int k in Ks)
                {
                    var selB = Lin.TopIndices(sb, all, k); var selG = Lin.TopIndices(sg, all, k);
                    recB.Add(selB.Contains(target)); recG.Add(selG.Contains(target));
                    twoBound.Add(Strict(sc, selB)); twoBag.Add(Strict(sc, selG));
                }
                return new Outcome(Strict(sc, all), Strict(sb, all), Strict(sg, all), twoBound, twoBag, recB, recG,
                    words.Count, t.TokenSlots, words.Sum(w => w.Length + 1.0));
            }).ToArray();
            double nChars = trials.Average(t => t.TokenSlots);
            double G = outs.Average(o => (double)o.Distinct);
            double gSlots = outs.Average(o => o.DistinctSlots);
            void Add(string method, double acc, double recall, double opsTokens, double opsGrouped)
            {
                rows.Add(new object[] { m, method, acc, recall, opsTokens, opsGrouped });
                string key = $"M{m}_{method.Replace(" ", "_").Replace(",", "").Replace("=", "").Replace("→", "to")}";
                h[$"{key}_acc"] = acc;
                if (!double.IsNaN(recall)) h[$"{key}_recall"] = recall;
                h[$"{key}_ops_tokens"] = opsTokens;
                h[$"{key}_ops_grouped"] = opsGrouped;
            }
            Add("dense character attention", 1.0, double.NaN, nChars * D, nChars * D);
            Add("full slot-aligned scan", outs.Average(o => o.Full ? 1.0 : 0), double.NaN, nChars * D, gSlots * D);
            Add("bound pooled scan only", outs.Average(o => o.Bound ? 1.0 : 0), double.NaN, (double)m * D, G * D);
            Add("bag pooled scan only", outs.Average(o => o.Bag ? 1.0 : 0), double.NaN, (double)m * D, G * D);
            for (int i = 0; i < Ks.Length; i++)
            {
                int k = Ks[i];
                Add($"bound screen → slot rerank, K={k}", outs.Average(o => o.TwoBound[i] ? 1.0 : 0), outs.Average(o => o.RecallBound[i] ? 1.0 : 0), (double)m * D + k * Sym.L * D, G * D + k * Sym.L * D);
                Add($"bag screen → slot rerank, K={k}", outs.Average(o => o.TwoBag[i] ? 1.0 : 0), outs.Average(o => o.RecallBag[i] ? 1.0 : 0), (double)m * D + k * Sym.L * D, G * D + k * Sym.L * D);
            }
            heaps.Add(new object[] { m, G, G / m, nChars, nChars / m });
            h[$"M{m}_distinct"] = G;
            h[$"M{m}_chars"] = nChars;
        }
        var table = Table.Of("readers", new[] { "history_words_M", "reader", "exact_word_top1", "stage1_recall", "mac_per_query_tokens", "mac_per_query_grouped" }, rows);
        var heapTable = Table.Of("distinct", new[] { "history_words_M", "distinct_words_G", "G_over_M", "character_slots_N", "N_over_M" }, heaps);
        return new ExperimentResult("S04", "Word attention over long histories", new[] { table, heapTable }, h);
    }
}
