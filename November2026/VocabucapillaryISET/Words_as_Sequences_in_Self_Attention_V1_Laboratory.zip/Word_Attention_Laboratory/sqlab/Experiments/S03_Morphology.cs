using SqLab.Core;

namespace SqLab.Experiments;

/// <summary>
/// Score rules on real English word families. Task 1 (identity): a word must outscore its own family, its
/// near-duplicates and fillers. Task 2 (family): a stem must rank its suffixed and prefixed forms above near-duplicates
/// and fillers. Character vectors are orthonormal, so only the logic of each rule differs.
/// </summary>
public static class S03_Morphology
{
    private const ulong Seed = 303;
    public const int MaxFamilies = 200, Fillers = 48, NeighbourCap = 8, StemRankLimit = 30000;

    public sealed record Case(string Task, int QueryId, string Query, string Candidate, int Order, bool Relevant, string Type);

    public static ExperimentResult Run(Lexicon lex)
    {
        // Families: stems with at least two suffixed and one prefixed form in the lexicon.
        var families = lex.Words.Take(StemRankLimit).Where(w => w.Length >= 3 && w.Length <= 10)
            .Select(w => (Stem: w, F: lex.Family(w))).Where(x => x.F.Suffixed.Count >= 2 && x.F.Prefixed.Count >= 1).ToArray();
        int eligible = families.Length;
        var r = Rng.Derive(Seed, 1);
        var order = Enumerable.Range(0, families.Length).ToArray();
        for (int i = order.Length - 1; i > 0; i--) { var (j, nr) = r.NextInt(i + 1); r = nr; (order[i], order[j]) = (order[j], order[i]); }
        var chosen = order.Take(MaxFamilies).Select(i => families[i]).ToArray();

        var cases = new List<Case>();
        int qid = 0;
        foreach (var (stem, (suf, pre)) in chosen)
        {
            var forms = new[] { stem }.Concat(suf).Concat(pre).Distinct().ToArray();
            var formSet = forms.ToHashSet();
            // Task 1: every form is a query.
            foreach (var x in forms)
            {
                var nbList = lex.Neighbours(x, NeighbourCap);
                var nbSet = nbList.ToHashSet();
                var cands = forms.Concat(nbList).Distinct().ToList();
                AddFillers(cands, formSet, x, ref r, lex);
                var shuffled = Shuffle(cands, ref r);
                for (int o = 0; o < shuffled.Count; o++)
                {
                    string c = shuffled[o];
                    string type = c == x ? "target" : c == stem ? "stem" : suf.Contains(c) ? "suffixed" : pre.Contains(c) ? "prefixed" : nbSet.Contains(c) ? "neighbour" : "filler";
                    cases.Add(new Case("identity", qid, x, c, o, c == x, type));
                }
                qid++;
            }
            // Task 2: the stem retrieves its forms.
            {
                var rel = suf.Concat(pre).ToHashSet();
                var nbList = lex.Neighbours(stem, NeighbourCap);
                var nbSet = nbList.ToHashSet();
                var cands = suf.Concat(pre).Concat(nbList).Where(c => c != stem).Distinct().ToList();
                AddFillers(cands, formSet, stem, ref r, lex);
                var shuffled = Shuffle(cands, ref r);
                for (int o = 0; o < shuffled.Count; o++)
                {
                    string c = shuffled[o];
                    string type = suf.Contains(c) ? "suffixed" : pre.Contains(c) ? "prefixed" : nbSet.Contains(c) ? "neighbour" : "filler";
                    cases.Add(new Case("family", qid, stem, c, o, rel.Contains(c), type));
                }
                qid++;
            }
        }

        var rows = new List<object[]>();
        var h = new Dictionary<string, double> { ["eligible_families"] = eligible, ["families"] = chosen.Length };
        foreach (var rule in Rules.All)
        {
            var scored = cases.AsParallel().AsOrdered().Select(c => (c, s: rule.Score(c.Query, c.Candidate))).ToArray();
            var byQuery = scored.GroupBy(x => x.c.QueryId).ToArray();
            var id = byQuery.Where(g => g.First().c.Task == "identity").Select(g =>
            {
                double best = g.Max(x => x.s);
                var top = g.Where(x => x.s == best).ToArray();
                bool ok = top.Length == 1 && top[0].c.Relevant;
                bool tie = top.Length > 1 && top.Any(x => x.c.Relevant);
                return (ok, tie);
            }).ToArray();
            var fam = byQuery.Where(g => g.First().c.Task == "family").Select(g =>
            {
                var ranked = g.OrderByDescending(x => x.s).ThenBy(x => x.c.Order).ToArray();
                int nRel = ranked.Count(x => x.c.Relevant), hits = 0;
                double ap = 0;
                for (int i = 0; i < ranked.Length; i++) if (ranked[i].c.Relevant) { hits++; ap += hits / (i + 1.0); }
                var topR = ranked.Take(nRel).ToArray();
                double RecallOf(string type)
                {
                    int total = ranked.Count(x => x.c.Type == type);
                    return total == 0 ? double.NaN : topR.Count(x => x.c.Type == type) / (double)total;
                }
                return (ap: ap / nRel, suf: RecallOf("suffixed"), pre: RecallOf("prefixed"));
            }).ToArray();
            double t1 = id.Average(x => x.ok ? 1.0 : 0), t1tie = id.Average(x => x.tie ? 1.0 : 0);
            double map = fam.Average(x => x.ap);
            double rs = fam.Where(x => !double.IsNaN(x.suf)).Average(x => x.suf), rp = fam.Where(x => !double.IsNaN(x.pre)).Average(x => x.pre);
            rows.Add(new object[] { rule.Name, rule.Family, rule.Cost, t1, t1tie, map, rs, rp });
            string key = rule.Name.Replace(" ", "_").Replace(",", "").Replace("(", "").Replace(")", "").Replace("-", "_");
            h[$"{key}_identity"] = t1; h[$"{key}_identity_tie"] = t1tie; h[$"{key}_family_map"] = map;
            h[$"{key}_family_suffixed"] = rs; h[$"{key}_family_prefixed"] = rp;
        }
        h["identity_queries"] = cases.Where(c => c.Task == "identity").Select(c => c.QueryId).Distinct().Count();
        h["family_queries"] = cases.Where(c => c.Task == "family").Select(c => c.QueryId).Distinct().Count();
        h["mean_identity_candidates"] = cases.Where(c => c.Task == "identity").GroupBy(c => c.QueryId).Average(g => g.Count());
        h["mean_family_candidates"] = cases.Where(c => c.Task == "family").GroupBy(c => c.QueryId).Average(g => g.Count());
        var table = Table.Of("rules", new[] { "rule", "family", "cost_per_comparison", "identity_top1", "identity_tied", "family_map", "family_recall_suffixed", "family_recall_prefixed" }, rows);
        var caseTable = Table.Of("cases", new[] { "task", "query_id", "query", "candidate", "order", "relevant", "type" },
            cases.Select(c => new object[] { c.Task, c.QueryId, c.Query, c.Candidate, c.Order, c.Relevant ? 1 : 0, c.Type }));
        var famTable = Table.Of("families", new[] { "stem", "suffixed", "prefixed" }, chosen.Select(f => new object[] { f.Stem, string.Join(" ", f.F.Suffixed), string.Join(" ", f.F.Prefixed) }));
        return new ExperimentResult("S03", "Score rules on English word families", new[] { table, famTable, caseTable }, h);
    }

    private static void AddFillers(List<string> cands, HashSet<string> exclude, string query, ref Rng r, Lexicon lex)
    {
        int target = cands.Count + Fillers;
        while (cands.Count < target)
        {
            var (k, nr) = lex.Sample(r); r = nr;
            string w = lex.Words[k];
            if (w == query || exclude.Contains(w) || cands.Contains(w)) continue;
            cands.Add(w);
        }
    }

    private static List<string> Shuffle(List<string> items, ref Rng r)
    {
        var a = items.ToArray();
        for (int i = a.Length - 1; i > 0; i--) { var (j, nr) = r.NextInt(i + 1); r = nr; (a[i], a[j]) = (a[j], a[i]); }
        return a.ToList();
    }
}
