using SqLab.Core;

namespace SqLab.Experiments;

/// <summary>
/// Exact accounting from English word statistics: word lengths, positions and pairwise work for characters against
/// words, and cache memory and score work per word for each word-level layout (one attention head of width 128, BF16).
/// </summary>
public static class S00_Accounting
{
    public const int Dh = 128, BytesPerValue = 2;

    public static ExperimentResult Run(Lexicon lex)
    {
        var st = lex.Stats;
        double meanKept = lex.Words.Select((w, i) => lex.Prob[i] * w.Length).Sum();
        double meanSlots = meanKept + 1;                                     // letters plus one separator or end slot
        double meanSlotsSq = lex.Words.Select((w, i) => lex.Prob[i] * (w.Length + 1.0) * (w.Length + 1.0)).Sum();
        double over16 = 1 - st.AlphaUpTo16Mass / st.AlphaMass;
        var corpus = Table.Of("corpus", new[] { "quantity", "value" }, new[]
        {
            new object[] { "word types in the English list", st.AllTypes },
            new object[] { "lowercase alphabetic types", st.AlphaTypes },
            new object[] { "alphabetic share of token mass", st.AlphaMass / st.AllMass },
            new object[] { "alphabetic token mass longer than 16 letters", over16 },
            new object[] { "mean letters per alphabetic token (all, up to 16)", st.MeanLettersAllAlpha },
            new object[] { "lexicon size kept", lex.Words.Count },
            new object[] { "kept share of alphabetic token mass (up to 16 letters)", st.KeptMassShareOfAlpha },
            new object[] { "mean letters per token in the lexicon", meanKept },
            new object[] { "mean slots per word (letters + 1)", meanSlots },
        });

        double vecBytes = 2.0 * Dh * BytesPerValue;                           // one key and one value vector
        var layouts = new List<object[]>
        {
            new object[] { "characters, dense cache", meanSlots, meanSlots * vecBytes, meanSlots * Dh, "character positions in the outer softmax" },
            new object[] { "word, pooled (bag or bound)", 1.0, vecBytes, (double)Dh, "one vector per word" },
            new object[] { "word, slot blocks (width/16 per slot)", 1.0, vecBytes, (double)Dh, "one vector per word" },
            new object[] { "word, concatenated slots, ragged", meanSlots, meanSlots * vecBytes, meanSlots * Dh, "same vectors as characters, word softmax" },
            new object[] { "word, concatenated slots, padded to 16", (double)Sym.L, Sym.L * vecBytes, (double)(Sym.L * Dh), "fixed slots" },
            new object[] { "word, late interaction or alignment", meanSlots, meanSlots * vecBytes, meanSlots * meanSlots * Dh, "query slots × key slots" },
        };
        var perWord = Table.Of("per_word", new[] { "layout", "vectors_per_word", "cache_bytes_per_word", "score_mac_per_query_word", "note" }, layouts);

        var passages = new List<object[]>();
        foreach (int m in new[] { 1000, 4096, 16384 })
        {
            double n = m * meanSlots;
            double pairsChar = n * (n + 1) / 2, pairsWord = m * (m + 1.0) / 2;
            passages.Add(new object[] { m, n, pairsChar, pairsWord, pairsChar / pairsWord });
        }
        var passage = Table.Of("passages", new[] { "words_M", "character_positions_N", "dense_pairs_characters", "dense_pairs_words", "ratio" }, passages);

        var lexTable = Table.Of("lexicon", new[] { "rank", "word", "frequency" },
            lex.Words.Select((w, i) => new object[] { i + 1, w, lex.Freq[i] }));

        var h = new Dictionary<string, double>
        {
            ["all_types"] = st.AllTypes,
            ["alpha_types"] = st.AlphaTypes,
            ["alpha_mass_share"] = st.AlphaMass / st.AllMass,
            ["alpha_over16_share"] = over16,
            ["mean_letters_all_alpha"] = st.MeanLettersAllAlpha,
            ["lexicon_size"] = lex.Words.Count,
            ["kept_mass_share"] = st.KeptMassShareOfAlpha,
            ["mean_letters_lexicon"] = meanKept,
            ["mean_slots"] = meanSlots,
            ["mean_slots_sq"] = meanSlotsSq,
            ["pairs_ratio_1000"] = (double)passages[0][4],
            ["concat_padded_bytes"] = Sym.L * vecBytes,
            ["pooled_bytes"] = vecBytes,
            ["char_bytes_per_word"] = meanSlots * vecBytes,
        };
        return new ExperimentResult("S00", "Accounting from English word statistics", new[] { corpus, perWord, passage, lexTable }, h);
    }
}
