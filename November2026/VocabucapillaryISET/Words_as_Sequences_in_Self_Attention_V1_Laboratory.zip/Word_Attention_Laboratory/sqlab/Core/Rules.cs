namespace SqLab.Core;

/// <summary>
/// Word-to-word score rules with orthonormal (one-hot) character vectors, so that every character dot product is 1 for
/// the same symbol and 0 otherwise. This isolates the logic of each rule from embedding crosstalk.
/// </summary>
public sealed record Rule(string Name, string Family, string Cost, Func<string, string, double> Score);

public static class Rules
{
    public static double Bag(string q, string k)
    {
        var a = new int[26]; var b = new int[26];
        foreach (char c in q) a[c - 'a']++;
        foreach (char c in k) b[c - 'a']++;
        double s = 0;
        for (int i = 0; i < 26; i++) s += a[i] * b[i];
        return s;
    }

    /// <summary>Slot-aligned score: sum over the L slots of matches; padding-to-padding matches count with weight padWeight.</summary>
    public static double Slot(IReadOnlyList<int> q, IReadOnlyList<int> k, double padWeight)
    {
        double s = 0;
        for (int j = 0; j < Sym.L; j++)
            if (q[j] == k[j]) s += q[j] == Sym.Pad ? padWeight : 1.0;
        return s;
    }

    public static double SlotStart(string q, string k, double padWeight) => Slot(Sym.Left(q), Sym.Left(k), padWeight);
    public static double SlotEnd(string q, string k, double padWeight) => Slot(Sym.Right(q), Sym.Right(k), padWeight);

    /// <summary>Late interaction with a hard maximum: the number of query letters that occur anywhere in the key word.</summary>
    public static double MaxSim(string q, string k) => q.Count(c => k.Contains(c));

    /// <summary>Best common shift: max over offsets δ of the letters that match at i and i+δ.</summary>
    public static double ShiftMax(string q, string k)
    {
        int best = 0;
        for (int delta = -q.Length + 1; delta < k.Length; delta++)
        {
            int s = 0;
            for (int i = 0; i < q.Length; i++) { int j = i + delta; if (j >= 0 && j < k.Length && q[i] == k[j]) s++; }
            best = Math.Max(best, s);
        }
        return best;
    }

    /// <summary>Smith–Waterman local alignment: match +1, mismatch -1, gap -1.</summary>
    public static double LocalAlign(string q, string k)
    {
        var prev = new int[k.Length + 1];
        int best = 0;
        for (int i = 1; i <= q.Length; i++)
        {
            var cur = new int[k.Length + 1];
            for (int j = 1; j <= k.Length; j++)
            {
                int diag = prev[j - 1] + (q[i - 1] == k[j - 1] ? 1 : -1);
                cur[j] = Math.Max(0, Math.Max(diag, Math.Max(prev[j] - 1, cur[j - 1] - 1)));
                best = Math.Max(best, cur[j]);
            }
            prev = cur;
        }
        return best;
    }

    public static double Dice(double s, string q, string k) => 2.0 * s / (q.Length + k.Length);

    public static readonly IReadOnlyList<Rule> All = new Rule[]
    {
        new("bag of letters", "pooled, order-free", "O(d)", Bag),
        new("slots from start, padding counted", "slot-aligned (AND)", "O(Ld)", (q, k) => SlotStart(q, k, 1.0)),
        new("slots from start, letters only", "slot-aligned (AND)", "O(Ld)", (q, k) => SlotStart(q, k, 0.0)),
        new("slots from end, letters only", "slot-aligned (AND)", "O(Ld)", (q, k) => SlotEnd(q, k, 0.0)),
        new("two anchors, maximum", "slot-aligned (AND), anchors combined by OR", "O(2Ld)", (q, k) => Math.Max(SlotStart(q, k, 0.0), SlotEnd(q, k, 0.0))),
        new("two anchors, maximum, padding counted", "slot-aligned (AND), anchors combined by OR", "O(2Ld)", (q, k) => Math.Max(SlotStart(q, k, 1.0), SlotEnd(q, k, 1.0))),
        new("two anchors, sum", "slot-aligned (AND), anchors added", "O(2Ld)", (q, k) => SlotStart(q, k, 0.0) + SlotEnd(q, k, 0.0)),
        new("late interaction (MaxSim)", "hierarchical (OR over positions)", "O(L²d)", MaxSim),
        new("best common shift", "slot-aligned over shifts", "O(L²d)", ShiftMax),
        new("best common shift, length-normalised", "slot-aligned over shifts", "O(L²d)", (q, k) => Dice(ShiftMax(q, k), q, k)),
        new("local alignment", "alignment (monotone, gaps)", "O(L²d + L²)", LocalAlign),
        new("local alignment, length-normalised", "alignment (monotone, gaps)", "O(L²d + L²)", (q, k) => Dice(LocalAlign(q, k), q, k)),
    };
}
