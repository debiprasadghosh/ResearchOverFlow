using System.Globalization;
using System.Text;
using System.Text.Json;

namespace SqLab.Core;

public sealed record Table(string Name, IReadOnlyList<string> Header, IReadOnlyList<IReadOnlyList<string>> Rows)
{
    public static Table Of(string name, IReadOnlyList<string> header, IEnumerable<IReadOnlyList<object>> rows) =>
        new(name, header, rows.Select(r => (IReadOnlyList<string>)r.Select(Fmt.Cell).ToArray()).ToArray());
}

public sealed record ExperimentResult(
    string Id,
    string Title,
    IReadOnlyList<Table> Tables,
    IReadOnlyDictionary<string, double> Headlines);

public static class Fmt
{
    public static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

    public static string Cell(object o) => o switch
    {
        double d when double.IsNaN(d) => "NaN",
        double d => d.ToString("R", Inv),
        float f => ((double)f).ToString("R", Inv),
        int i => i.ToString(Inv),
        long l => l.ToString(Inv),
        bool b => b ? "true" : "false",
        null => "",
        _ => Convert.ToString(o, Inv) ?? ""
    };

    public static string F(double x, int digits) => x.ToString("F" + digits, Inv);
}

/// <summary>Side-effecting output boundary: writes CSV tables and a JSON headline file.</summary>
public static class Output
{
    public static void Write(string dir, IReadOnlyList<ExperimentResult> results)
    {
        Directory.CreateDirectory(dir);
        foreach (var r in results)
        {
            foreach (var t in r.Tables)
            {
                var sb = new StringBuilder();
                sb.AppendLine(string.Join(",", t.Header.Select(Escape)));
                foreach (var row in t.Rows) sb.AppendLine(string.Join(",", row.Select(Escape)));
                File.WriteAllText(Path.Combine(dir, $"{r.Id}_{t.Name}.csv"), sb.ToString());
            }
        }
        var headlines = results
            .SelectMany(r => r.Headlines.Select(kv => (Key: $"{r.Id}.{kv.Key}", kv.Value)))
            .ToDictionary(x => x.Key, x => x.Value);
        var json = JsonSerializer.Serialize(headlines, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(Path.Combine(dir, "headlines.json"), json);
    }

    private static string Escape(string s) => s.Contains(',') || s.Contains('"') ? "\"" + s.Replace("\"", "\"\"") + "\"" : s;
}
