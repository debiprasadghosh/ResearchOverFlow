using System.Diagnostics;
using SqLab.Core;
using SqLab.Experiments;

// Composition root: loads the lexicon once, schedules the studies and performs the only file writes.
string data = Environment.GetEnvironmentVariable("SQ_DATA") ?? Path.Combine("..", "data", "large_en.msgpack.gz");
string outDir = Environment.GetEnvironmentVariable("SQ_OUT") ?? Path.Combine("..", "out");
var swLoad = Stopwatch.StartNew();
var lexicon = Lexicon.Load(data, 50_000);
Console.WriteLine($"lexicon: {lexicon.Words.Count} words loaded in {swLoad.Elapsed.TotalSeconds:F1} s");
var registry = new (string Id, Func<Lexicon, ExperimentResult> Run)[]
{
    ("S00", S00_Accounting.Run),
    ("S01", S01_Identities.Run),
    ("S02", S02_Layouts.Run),
    ("S03", S03_Morphology.Run),
    ("S04", S04_LongHistory.Run),
};
var selected = args.Length == 0 ? registry : registry.Where(r => args.Contains(r.Id)).ToArray();
var results = new List<ExperimentResult>();
foreach (var (id, run) in selected)
{
    var sw = Stopwatch.StartNew();
    var r = run(lexicon);
    sw.Stop();
    results.Add(r);
    Console.WriteLine($"{id} {r.Title}: {sw.Elapsed.TotalSeconds:F1} s");
    foreach (var kv in r.Headlines) Console.WriteLine($"   {kv.Key} = {kv.Value:G6}");
}
Output.Write(outDir, results);
