using NxLab.Core;

namespace NxLab.Experiments;

/// <summary>
/// The test that separates hypothesis C (cerebellar loops serve the character level only) from B (they also serve word
/// or conceptual records), as simulated patient studies. Semantic relatedness judgements follow the exponential
/// speed–accuracy function d′(t) = λ(1 − exp(−β(t − δ))): the asymptote λ is the quality of the semantic records, the
/// intercept δ collects encoding, the key press and, for words side by side, the fixation of the first word and the
/// saccade to the second. Under C a cerebellar lesion lengthens the key press and the word acquisition (N04) and
/// shortens phonological traces (N03, lifetime ×0.8 at full severity); B adds a loss of asymptote, λ(1 − ε·s), for word
/// pairs (B-lexical) or also for picture pairs (B-conceptual). Patients have severity s ~ U(0.2, 1), controls s = 0.
/// Six designs; group studies with n patients and n controls, 60 trials each, one-sided Welch tests at α = 0.05.
/// </summary>
public static class N05_Test
{
    private const ulong Seed = 805;
    public const int Trials = 60, Studies = 4000, ExpectedDraws = 200_000, MainN = 20;
    public const double Alpha = 0.05, Beta = 4.0, Encode = 0.30, FirstWord = 0.20, Deadline = 1.0, AsymSd = 0.35;
    public const double Gap = 2.0, Lifetime = 3.5, LifetimeFactor = 0.8, LifetimeSd = 0.25, PhonWeight = 0.5;
    public const double DecMean = 0.70, DecSubjectSd = 0.12, DecCv = 0.4, SevLo = 0.2, SevHi = 1.0, MainEffect = 0.2;
    public const double ControlAccuracy = 0.85, CeilingAccuracy = 0.95;
    public static readonly int[] GroupSizes = { 12, 20, 40 };
    public static readonly double[] Effects = { 0.0, 0.1, 0.2, 0.3 };
    public static readonly double[] PhonWeights = { 0.0, 0.5, 1.0 };
    public static readonly double[] Deadlines = { 0.9, 1.0, 1.2, 1.5 };

    public enum Hyp { C, BLexical, BConceptual }
    public static string Name(Hyp h) => h switch { Hyp.C => "C", Hyp.BLexical => "B-lexical", _ => "B-conceptual" };

    public sealed record Design(string Key, string Label, bool Speeded, bool Saccade, bool Sequential, bool Pictures, bool Rt);
    public static readonly IReadOnlyList<Design> Designs = new[]
    {
        new Design("D1", "speeded (1.0 s deadline), words side by side, accuracy", true, true, false, false, false),
        new Design("D2", "untimed, words side by side, response time", false, true, false, false, true),
        new Design("D3", "untimed, words side by side, accuracy", false, true, false, false, false),
        new Design("D4", "untimed, words one after the other at fixation (2 s gap), articulatory suppression, accuracy", false, false, true, false, false),
        new Design("D5", "untimed, both words at fixation, articulatory suppression, accuracy", false, false, false, false, false),
        new Design("D6", "untimed, picture pairs at fixation, accuracy", false, false, false, true, false),
    };

    public sealed record Setup(double AsymMean, double Effect, double PhonWeight, double Deadline, N04_Reading.Costs Costs);

    static double Lerp(double a, double b, double s) => a + (b - a) * s;
    public static double Intercept(Design d, double s, N04_Reading.Costs c) =>
        Encode + Lerp(c.KeyIntact, c.KeyLesion, s) + (d.Saccade ? FirstWord + Lerp(c.AcquireIntact, c.AcquireLesion, s) : 0);
    public static double TraceLoss(double s, double phonWeight) =>
        phonWeight * (1 - Stats.Phi(Math.Log(Lifetime * (1 - (1 - LifetimeFactor) * s) / Gap) / LifetimeSd));
    static bool Semantic(Design d, Hyp h) => h == Hyp.BConceptual || (h == Hyp.BLexical && !d.Pictures);

    /// <summary>Probability of a correct judgement for asymptote λ and severity s (no trial noise).</summary>
    public static double PCorrect(Design d, Hyp h, Setup su, double lam, double s)
    {
        if (Semantic(d, h)) lam *= 1 - su.Effect * s;
        double dp = d.Speeded ? lam * Math.Max(0, 1 - Math.Exp(-Beta * (su.Deadline - Intercept(d, s, su.Costs)))) : lam;
        double p = Stats.Phi(dp / 2);
        if (d.Sequential) { double lost = TraceLoss(s, su.PhonWeight); p = (1 - lost) * p + lost * 0.5; }
        return p;
    }

    /// <summary>One subject's score: accuracy over the trials, or mean response time (s) in a response-time design.</summary>
    public static double Score(Design d, Hyp h, Setup su, double s, ref Rng r)
    {
        var (g, r1) = r.NextGaussian(); r = r1;
        double lam = Math.Max(0.2, su.AsymMean + AsymSd * g);
        if (d.Rt)
        {
            var (g2, r2) = r.NextGaussian(); r = r2;
            double dec = Math.Max(0.2, DecMean + DecSubjectSd * g2);
            double sig = Math.Sqrt(Math.Log(1 + DecCv * DecCv)), mu = Math.Log(dec) - sig * sig / 2, icpt = Intercept(d, s, su.Costs), sum = 0;
            for (int t = 0; t < Trials; t++) { var (z, nr) = r.NextGaussian(); r = nr; sum += icpt + Math.Exp(mu + sig * z); }
            return sum / Trials;
        }
        double p = PCorrect(d, h, su, lam, s);
        int correct = 0;
        for (int t = 0; t < Trials; t++) { var (u, nr) = r.NextDouble(); r = nr; if (u < p) correct++; }
        return correct / (double)Trials;
    }

    /// <summary>One group study: n controls then n patients from the same generator; one-sided Welch test of the deficit.</summary>
    public static (bool Reject, double Deficit) Study(Design d, Hyp h, Setup su, int n, Rng rng)
    {
        var r = rng; var ctl = new double[n]; var pat = new double[n];
        for (int i = 0; i < n; i++) ctl[i] = Score(d, h, su, 0.0, ref r);
        for (int i = 0; i < n; i++) { var (s, nr) = r.NextUniform(SevLo, SevHi); r = nr; pat[i] = Score(d, h, su, s, ref r); }
        var w = d.Rt ? Stats.WelchGreater(pat, ctl) : Stats.WelchGreater(ctl, pat);
        return (w.P < Alpha, w.MeanA - w.MeanB);
    }

    /// <summary>Share of simulated studies that find a significant deficit; the streams depend on design, variant and n only.</summary>
    public static double RejectionRate(Design d, Hyp h, Setup su, int n, ulong streamBase) =>
        Enumerable.Range(0, Studies).AsParallel().AsOrdered().Select(rep => Study(d, h, su, n, Rng.Derive(Seed, streamBase + (ulong)rep)).Reject ? 1 : 0).Sum() / (double)Studies;

    static ulong StreamBase(int designIdx, int variant, int nIdx) => 10_000_000UL + 1_000_000UL * (ulong)designIdx + 100_000UL * (ulong)variant + 10_000UL * (ulong)nIdx;

    /// <summary>Population means of the score for controls and patients (Monte Carlo over asymptote and severity).</summary>
    public static (double Control, double Patient) Expected(Design d, Hyp h, Setup su, Rng rng)
    {
        var r = rng; double c = 0, p = 0;
        for (int i = 0; i < ExpectedDraws; i++)
        {
            var (g, r1) = r.NextGaussian(); var (s, r2) = r1.NextUniform(SevLo, SevHi); r = r2;
            double lam = Math.Max(0.2, su.AsymMean + AsymSd * g);
            if (d.Rt) { c += Intercept(d, 0, su.Costs) + DecMean; p += Intercept(d, s, su.Costs) + DecMean; }
            else { c += PCorrect(d, h, su, lam, 0); p += PCorrect(d, h, su, lam, s); }
        }
        return (c / ExpectedDraws, p / ExpectedDraws);
    }

    public static ExperimentResult Run(Context ctx)
    {
        var h = new Dictionary<string, double>();
        var costs = N04_Reading.ComputeCosts(ctx.Lex);
        double asym = 2 * Stats.InvPhi(ControlAccuracy), asymCeil = 2 * Stats.InvPhi(CeilingAccuracy);
        var main = new Setup(asym, MainEffect, PhonWeight, Deadline, costs);
        var hyps = new[] { Hyp.C, Hyp.BLexical, Hyp.BConceptual };
        h["asymptote_main"] = asym; h["asymptote_ceiling"] = asymCeil;
        h["acquire_intact_ms"] = 1000 * costs.AcquireIntact; h["acquire_lesion_ms"] = 1000 * costs.AcquireLesion;
        h["key_intact_ms"] = 1000 * costs.KeyIntact; h["key_lesion_ms"] = 1000 * costs.KeyLesion;

        // Components of the intercept and of trace loss.
        double mid = 0.5 * (SevLo + SevHi);
        var compRows = new List<object[]>
        {
            new object[] { "visual encoding (s)", Encode, Encode, Encode },
            new object[] { "key press (s)", costs.KeyIntact, Lerp(costs.KeyIntact, costs.KeyLesion, mid), costs.KeyLesion },
            new object[] { "fixation of the first word, side by side (s)", FirstWord, FirstWord, FirstWord },
            new object[] { "saccade to and acquisition of the second word (s)", costs.AcquireIntact, Lerp(costs.AcquireIntact, costs.AcquireLesion, mid), costs.AcquireLesion },
            new object[] { "intercept, both words at fixation (s)", Intercept(Designs[4], 0, costs), Intercept(Designs[4], mid, costs), Intercept(Designs[4], 1, costs) },
            new object[] { "intercept, words side by side (s)", Intercept(Designs[0], 0, costs), Intercept(Designs[0], mid, costs), Intercept(Designs[0], 1, costs) },
            new object[] { "phonological trace lifetime (s)", Lifetime, Lifetime * (1 - (1 - LifetimeFactor) * mid), Lifetime * LifetimeFactor },
            new object[] { "first word lost after a 2 s gap, if held phonologically", TraceLoss(0, 1), TraceLoss(mid, 1), TraceLoss(1, 1) },
        };
        var tComp = Table.Of("components", new[] { "component", "control", "patient_mean_severity", "patient_full_severity" }, compRows);
        h["intercept_fixation_control"] = Intercept(Designs[4], 0, costs); h["intercept_side_control"] = Intercept(Designs[0], 0, costs);
        h["intercept_side_patient_mid"] = Intercept(Designs[0], mid, costs); h["intercept_side_patient_full"] = Intercept(Designs[0], 1, costs);
        h["trace_loss_control"] = TraceLoss(0, 1); h["trace_loss_full"] = TraceLoss(1, 1);

        // Expected scores and deficits under each hypothesis.
        var expRows = new List<object[]>();
        for (int di = 0; di < Designs.Count; di++)
        {
            var d = Designs[di];
            foreach (var hy in hyps)
            {
                var (c, p) = Expected(d, hy, main, Rng.Derive(Seed, 100 + (ulong)di));
                double deficit = d.Rt ? 1000 * (p - c) : 100 * (c - p);
                expRows.Add(new object[] { d.Key, d.Label, Name(hy), d.Rt ? 1000 * c : c, d.Rt ? 1000 * p : p, deficit, d.Rt ? "ms slower" : "points less accurate" });
                h[$"expected_{d.Key}_{Name(hy)}_deficit"] = deficit;
            }
        }
        var tExp = Table.Of("expected", new[] { "design", "label", "hypothesis", "control", "patient", "deficit", "unit" }, expRows);

        // Rejection rates of the six designs under each hypothesis and group size.
        var rejRows = new List<object[]>();
        for (int di = 0; di < Designs.Count; di++)
            for (int ni = 0; ni < GroupSizes.Length; ni++)
            {
                var row = new List<object> { Designs[di].Key, Designs[di].Label, GroupSizes[ni] };
                foreach (var hy in hyps)
                {
                    double rate = RejectionRate(Designs[di], hy, main, GroupSizes[ni], StreamBase(di, 0, ni));
                    row.Add(rate); h[$"reject_{Designs[di].Key}_{Name(hy)}_n{GroupSizes[ni]}"] = rate;
                }
                rejRows.Add(row.ToArray());
            }
        var tRej = Table.Of("rejection", new[] { "design", "label", "patients_per_group", "C", "B_lexical", "B_conceptual" }, rejRows);

        // Power of the two clean designs against the size of the B effect, group size and difficulty.
        var powRows = new List<object[]>();
        foreach (var (di, hy) in new[] { (4, Hyp.BLexical), (5, Hyp.BConceptual) })
            foreach (var (ci, acc) in new[] { (0, ControlAccuracy), (1, CeilingAccuracy) })
                foreach (double eff in Effects)
                    for (int ni = 0; ni < GroupSizes.Length; ni++)
                    {
                        var su = main with { AsymMean = 2 * Stats.InvPhi(acc), Effect = eff };
                        double rate = RejectionRate(Designs[di], hy, su, GroupSizes[ni], StreamBase(di, ci, ni));
                        powRows.Add(new object[] { Designs[di].Key, Name(hy), acc, eff, GroupSizes[ni], rate });
                        h[$"power_{Designs[di].Key}_acc{acc:0.00}_e{eff:0.0}_n{GroupSizes[ni]}"] = rate;
                    }
        var tPow = Table.Of("power", new[] { "design", "hypothesis", "control_untimed_accuracy", "effect_at_full_severity", "patients_per_group", "rejection_rate" }, powRows);

        // The sequential design under C: how much of the first word is held phonologically.
        var seqRows = new List<object[]>();
        for (int wi = 0; wi < PhonWeights.Length; wi++)
        {
            var su = main with { PhonWeight = PhonWeights[wi] };
            var (c, p) = Expected(Designs[3], Hyp.C, su, Rng.Derive(Seed, 200 + (ulong)wi));
            // The central value reuses the streams of the main table, so the two report the same studies.
            double rate = RejectionRate(Designs[3], Hyp.C, su, MainN, StreamBase(3, PhonWeights[wi] == PhonWeight ? 0 : 2 + wi, 1));
            seqRows.Add(new object[] { PhonWeights[wi], 100 * (c - p), rate });
            h[$"seq_w{PhonWeights[wi]:0.0}_deficit"] = 100 * (c - p); h[$"seq_w{PhonWeights[wi]:0.0}_reject"] = rate;
        }
        var tSeq = Table.Of("sequential", new[] { "share_held_phonologically", "deficit_points_under_C", "rejection_rate_under_C_n20" }, seqRows);

        // The speeded design under C: the deadline.
        var ddlRows = new List<object[]>();
        for (int ti = 0; ti < Deadlines.Length; ti++)
        {
            var su = main with { Deadline = Deadlines[ti] };
            var (c, p) = Expected(Designs[0], Hyp.C, su, Rng.Derive(Seed, 300 + (ulong)ti));
            double rate = RejectionRate(Designs[0], Hyp.C, su, MainN, StreamBase(0, Deadlines[ti] == Deadline ? 0 : 5 + ti, 1));
            ddlRows.Add(new object[] { Deadlines[ti], c, 100 * (c - p), rate });
            h[$"deadline_{Deadlines[ti]:0.0}_deficit"] = 100 * (c - p); h[$"deadline_{Deadlines[ti]:0.0}_reject"] = rate;
        }
        var tDdl = Table.Of("deadline", new[] { "deadline_s", "control_accuracy", "deficit_points_under_C", "rejection_rate_under_C_n20" }, ddlRows);
        h["trials"] = Trials; h["studies"] = Studies;
        return new ExperimentResult("N05", "The C-versus-B test as simulated patient studies", new[] { tComp, tExp, tRej, tPow, tSeq, tDdl }, h);
    }
}
