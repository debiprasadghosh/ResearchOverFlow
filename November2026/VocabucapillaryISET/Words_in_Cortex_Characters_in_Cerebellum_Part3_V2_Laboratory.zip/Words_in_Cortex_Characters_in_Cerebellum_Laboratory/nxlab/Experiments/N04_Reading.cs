using NxLab.Core;

namespace NxLab.Experiments;

/// <summary>
/// Reading saccades with and without the cerebellar cortex, and the key press that ends a trial. A one-degree-of-freedom
/// eye (λ = 5) makes the inter-word saccades of lines of frequency-sampled English words (one character = 0.01 position
/// units, each saccade aimed at the centre of the next word) with 60 ms of visual feedback delay. Internal models: the
/// exact equations, the learned granule model (intact cerebellum), the linear model alone (cerebellar cortex lesioned,
/// the brainstem's and nuclei's internal model left) and none. Per saccade: duration, gain, landing error and whether the
/// eye landed outside the word; the time to acquire the word, adding a corrective saccade after a 150 ms latency when the
/// landing misses; the time per word with 200 ms of lexical processing. The limb's key press (one gesture of about 0.2
/// rad RMS that must end within 0.02 of the key) is timed with the granule model, the linear model and none.
/// </summary>
public static class N04_Reading
{
    private const ulong Seed = 804;
    public const int Lines = 40, WordsPerLine = 11, KeyPresses = 40;
    public const double Char = 0.01, LineStart = -0.3, Fixation = 0.2, CorrectionLatency = 0.15, KeyAmp = 0.35;
    public static readonly Pacing EyePacing = new(0.12, 0.45, 0.005, 0.01, 0.5);
    /// <summary>A key press must end on the key: tolerance 0.02 (about a tenth of the movement).</summary>
    public static readonly Pacing KeyPacing = new(0.12, 0.45, 0.02, 0.04, 1.0);
    public static readonly string[] EyeModels = { "exact", "granule", "linear", "none" };
    public static readonly string[] KeyModels = { "granule", "linear", "none" };

    public sealed record Saccade(int Line, int Index, string Word, double Amplitude, double HalfWidth, double Duration, double Landing, double Gain, double Error, bool Miss, double Acquire);
    public sealed record Summary(string Model, Gains Gains, double DurationMs, double GainMean, double GainSd, double ErrorSd, double Miss, double AcquireMs, double WordMs, double WordsPerMinute, int Saccades);
    /// <summary>The costs the C-versus-B study needs: word acquisition per saccade and key-press time, intact and lesioned.</summary>
    public sealed record Costs(double AcquireIntact, double AcquireLesion, double KeyIntact, double KeyLesion);

    static ForwardModel? Model(Effector e, string name) => name switch
    {
        "exact" => new ExactModel(e),
        "granule" => Recipes.Model(e, Recipes.Cells),
        "linear" => Recipes.Model(e, 0),
        "none" => null,
        _ => throw new ArgumentException(name),
    };

    /// <summary>Lines of frequency-sampled words: centres and acceptance half-widths (letters plus half a space each side).</summary>
    public static IReadOnlyList<(IReadOnlyList<string> Words, IReadOnlyList<double> Centres, IReadOnlyList<double> HalfWidths)> Text(Lexicon lex)
    {
        var r = Rng.Derive(Seed, 1);
        var lines = new List<(IReadOnlyList<string>, IReadOnlyList<double>, IReadOnlyList<double>)>();
        for (int l = 0; l < Lines; l++)
        {
            var words = new List<string>(); var centres = new List<double>(); var half = new List<double>();
            for (int k = 0; k < WordsPerLine; k++)
            {
                var (idx, nr) = lex.Sample(r); r = nr;
                string w = lex.Words[idx];
                double c = k == 0 ? LineStart + w.Length * Char / 2 : centres[k - 1] + (words[k - 1].Length + w.Length) * Char / 2 + Char;
                words.Add(w); centres.Add(c); half.Add((w.Length + 1) * Char / 2);
            }
            lines.Add((words, centres, half));
        }
        return lines;
    }

    public static IReadOnlyList<Saccade> ReadText(Effector eye, ForwardModel? model, Gains g, IReadOnlyList<(IReadOnlyList<string> Words, IReadOnlyList<double> Centres, IReadOnlyList<double> HalfWidths)> text)
    {
        var jobs = new List<(int l, int k, int j)>();
        for (int l = 0; l < text.Count; l++) for (int k = 1; k < text[l].Words.Count; k++) jobs.Add((l, k, jobs.Count));
        return jobs.AsParallel().AsOrdered().Select(job =>
        {
            var (words, c, h) = text[job.l];
            double a = c[job.k - 1], b = c[job.k];
            var utt = new Utterance(new[] { new[] { a }, new[] { b } }, new[] { -1, -1 });
            var res = Loop.Paced(eye, model, Recipes.RefDelay, g, utt, EyePacing, Noise.Default, Rng.Derive(Seed, 1000 + (ulong)job.j));
            double landing = res.P[^1][0], err = landing - b;
            bool miss = Math.Abs(err) > h[job.k];
            double acquire = res.Durations[0] + (miss ? CorrectionLatency + (EyePacing.Ta + EyePacing.Tb * Math.Abs(err)) / eye.Lambda : 0);
            return new Saccade(job.l, job.k, words[job.k], b - a, h[job.k], res.Durations[0], landing, (landing - a) / (b - a), err, miss, acquire);
        }).ToArray();
    }

    public static Summary Summarise(string model, Gains g, IReadOnlyList<Saccade> s)
    {
        double gm = s.Average(x => x.Gain), gsd = Math.Sqrt(s.Average(x => (x.Gain - gm) * (x.Gain - gm)));
        double em = s.Average(x => x.Error), esd = Math.Sqrt(s.Average(x => (x.Error - em) * (x.Error - em)));
        double word = s.Average(x => x.Acquire) + Fixation;
        return new Summary(model, g, 1000 * s.Average(x => x.Duration), gm, gsd, esd, s.Average(x => x.Miss ? 1.0 : 0), 1000 * s.Average(x => x.Acquire), 1000 * word, 60.0 / word, s.Count);
    }

    /// <summary>Key presses with the limb: one gesture from rest to a target uniform in ±KeyAmp per degree of freedom.</summary>
    public static IReadOnlyList<double> KeyPressTimes(string model)
    {
        var limb = Effector.Limb; var m = Model(limb, model); var g = Recipes.Tuned(limb, m, Recipes.RefDelay);
        var r = Rng.Derive(Seed, 2); var targets = new List<double[]>();
        for (int i = 0; i < KeyPresses; i++) { var t = new double[limb.Dof]; for (int d = 0; d < limb.Dof; d++) { var (x, nr) = r.NextUniform(-KeyAmp, KeyAmp); r = nr; t[d] = x; } targets.Add(t); }
        return targets.Select((t, i) => Loop.Paced(limb, m, Recipes.RefDelay, g, new Utterance(new[] { new double[limb.Dof], t }, new[] { -1, -1 }), KeyPacing, Noise.Default, Rng.Derive(Seed, 5000 + (ulong)i)).Durations[0]).ToArray();
    }

    /// <summary>
    /// Full-severity endpoints for the patient model of N05: the eye keeps the linear internal model of the brainstem and
    /// nuclei, while the limb, like the articulators of N02 and N03, is left with no forward model.
    /// </summary>
    public static Costs ComputeCosts(Lexicon lex)
    {
        var eye = Effector.Eye; var text = Text(lex);
        double Acquire(string name) { var m = Model(eye, name); var g = Recipes.Tuned(eye, m, Recipes.RefDelay); return ReadText(eye, m, g, text).Average(x => x.Acquire); }
        return new Costs(Acquire("granule"), Acquire("linear"), KeyPressTimes("granule").Average(), KeyPressTimes("none").Average());
    }

    public static ExperimentResult Run(Context ctx)
    {
        var h = new Dictionary<string, double>();
        var eye = Effector.Eye; var text = Text(ctx.Lex);
        var sumRows = new List<object[]>(); var sacRows = new List<object[]>();
        var summaries = new Dictionary<string, Summary>();
        foreach (var name in EyeModels)
        {
            var m = Model(eye, name); var (R, Rv, _) = Recipes.TuneReaches(eye);
            var (g, rms) = Loop.Tune(eye, m, Recipes.RefDelay, R, Rv, Noise.Default, Rng.Derive(Recipes.TuneSeed, 50 + (ulong)Recipes.Index(eye)));
            var s = ReadText(eye, m, g, text);
            var sm = Summarise(name, g, s); summaries[name] = sm;
            sumRows.Add(new object[] { name, g.Bandwidth, g.Damping, rms, sm.DurationMs, sm.GainMean, sm.GainSd, sm.ErrorSd / Char, sm.Miss, sm.AcquireMs, sm.WordMs, sm.WordsPerMinute, sm.Saccades });
            foreach (var x in s) sacRows.Add(new object[] { name, x.Line, x.Index, x.Word, x.Amplitude / Char, x.Duration * 1000, x.Gain, x.Error / Char, x.Miss ? 1 : 0, x.Acquire * 1000 });
            string k = $"eye_{name}";
            h[$"{k}_bandwidth"] = g.Bandwidth; h[$"{k}_tune_rms"] = rms; h[$"{k}_duration_ms"] = sm.DurationMs; h[$"{k}_gain_mean"] = sm.GainMean; h[$"{k}_gain_sd"] = sm.GainSd;
            h[$"{k}_error_sd_chars"] = sm.ErrorSd / Char; h[$"{k}_miss"] = sm.Miss; h[$"{k}_acquire_ms"] = sm.AcquireMs; h[$"{k}_word_ms"] = sm.WordMs; h[$"{k}_wpm"] = sm.WordsPerMinute;
        }
        h["eye_gain_sd_ratio_linear"] = summaries["linear"].GainSd / summaries["granule"].GainSd;
        h["eye_saccades"] = summaries["granule"].Saccades;
        h["eye_mean_amplitude_chars"] = text.SelectMany(l => l.Centres.Zip(l.Centres.Skip(1), (a, b) => (b - a) / Char)).Average();
        var tSum = Table.Of("eye_models", new[] { "internal_model", "bandwidth", "damping", "tuning_rms", "saccade_ms", "gain_mean", "gain_sd", "landing_error_sd_chars", "landing_outside_word", "acquire_ms", "time_per_word_ms", "words_per_minute", "saccades" }, sumRows);
        var tSac = Table.Of("saccades", new[] { "internal_model", "line", "index", "word", "amplitude_chars", "duration_ms", "gain", "error_chars", "outside_word", "acquire_ms" }, sacRows);

        var keyRows = new List<object[]>();
        foreach (var name in KeyModels)
        {
            var times = KeyPressTimes(name);
            double mean = times.Average(), sd = Math.Sqrt(times.Average(x => (x - mean) * (x - mean)));
            keyRows.Add(new object[] { name, 1000 * mean, 1000 * sd, times.Count });
            h[$"key_{name}_ms"] = 1000 * mean; h[$"key_{name}_sd_ms"] = 1000 * sd;
        }
        var tKey = Table.Of("key_press", new[] { "forward_model", "mean_ms", "sd_ms", "presses" }, keyRows);
        h["char_units"] = Char; h["fixation_ms"] = 1000 * Fixation; h["correction_latency_ms"] = 1000 * CorrectionLatency;
        return new ExperimentResult("N04", "Reading saccades and the key press", new[] { tSum, tSac, tKey }, h);
    }
}
