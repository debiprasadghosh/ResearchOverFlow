namespace NxLab.Core;

/// <summary>
/// Special functions and the Welch test used by the study simulations: the log-gamma function (Lanczos), the regularized
/// incomplete gamma and beta functions (series and continued fractions), the normal and Student t distribution functions.
/// Algorithms follow Numerical Recipes (3rd edition).
/// </summary>
public static class Stats
{
    const double Eps = 2.220446049250313e-16, FpMin = 2.2250738585072014e-308 / 2.220446049250313e-16;
    static readonly double[] Cof = { 57.1562356658629235, -59.5979603554754912, 14.1360979747417471, -0.491913816097620199,
        .339946499848118887e-4, .465236289270485756e-4, -.983744753048795646e-4, .158088703224912494e-3, -.210264441724104883e-3,
        .217439618115212643e-3, -.164318106536763890e-3, .844182239838527433e-4, -.261908384015814087e-4, .368991826595316234e-5 };

    public static double LogGamma(double xx)
    {
        if (xx <= 0) throw new ArgumentOutOfRangeException(nameof(xx));
        double x = xx, y = xx, tmp = x + 5.24218750000000000;
        tmp = (x + 0.5) * Math.Log(tmp) - tmp;
        double ser = 0.999999999999997092;
        for (int j = 0; j < 14; j++) ser += Cof[j] / ++y;
        return tmp + Math.Log(2.5066282746310005 * ser / x);
    }

    /// <summary>Upper regularized incomplete gamma Q(a, x).</summary>
    public static double GammaQ(double a, double x)
    {
        if (x < 0 || a <= 0) throw new ArgumentOutOfRangeException(nameof(x));
        if (x == 0) return 1.0;
        double gln = LogGamma(a);
        if (x < a + 1.0)
        {
            double ap = a, sum = 1.0 / a, del = sum;
            for (int n = 0; n < 100_000; n++) { ap += 1; del *= x / ap; sum += del; if (Math.Abs(del) < Math.Abs(sum) * Eps) break; }
            return 1.0 - sum * Math.Exp(-x + a * Math.Log(x) - gln);
        }
        double b = x + 1.0 - a, c = 1.0 / FpMin, d = 1.0 / b, h = d;
        for (int i = 1; i < 100_000; i++)
        {
            double an = -i * (i - a);
            b += 2.0;
            d = an * d + b; if (Math.Abs(d) < FpMin) d = FpMin;
            c = b + an / c; if (Math.Abs(c) < FpMin) c = FpMin;
            d = 1.0 / d;
            double del = d * c;
            h *= del;
            if (Math.Abs(del - 1.0) <= Eps) break;
        }
        return Math.Exp(-x + a * Math.Log(x) - gln) * h;
    }

    /// <summary>The standard normal distribution function Φ(x) = erfc(−x/√2)/2, with erfc(z) = Q(1/2, z²) for z ≥ 0.</summary>
    public static double Phi(double x)
    {
        double z = -x / Math.Sqrt(2.0);
        double erfc = z >= 0 ? GammaQ(0.5, z * z) : 2.0 - GammaQ(0.5, z * z);
        return 0.5 * erfc;
    }

    /// <summary>Φ⁻¹(p) by bisection (deterministic, to about 1e-15).</summary>
    public static double InvPhi(double p)
    {
        double lo = -40, hi = 40;
        for (int i = 0; i < 200; i++) { double mid = 0.5 * (lo + hi); if (Phi(mid) < p) lo = mid; else hi = mid; }
        return 0.5 * (lo + hi);
    }

    static double BetaCf(double a, double b, double x)
    {
        double qab = a + b, qap = a + 1.0, qam = a - 1.0, c = 1.0, d = 1.0 - qab * x / qap;
        if (Math.Abs(d) < FpMin) d = FpMin;
        d = 1.0 / d;
        double h = d;
        for (int m = 1; m < 10_000; m++)
        {
            int m2 = 2 * m;
            double aa = m * (b - m) * x / ((qam + m2) * (a + m2));
            d = 1.0 + aa * d; if (Math.Abs(d) < FpMin) d = FpMin;
            c = 1.0 + aa / c; if (Math.Abs(c) < FpMin) c = FpMin;
            d = 1.0 / d; h *= d * c;
            aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2));
            d = 1.0 + aa * d; if (Math.Abs(d) < FpMin) d = FpMin;
            c = 1.0 + aa / c; if (Math.Abs(c) < FpMin) c = FpMin;
            d = 1.0 / d;
            double del = d * c;
            h *= del;
            if (Math.Abs(del - 1.0) <= Eps) break;
        }
        return h;
    }

    /// <summary>Regularized incomplete beta I_x(a, b).</summary>
    public static double BetaI(double a, double b, double x)
    {
        if (a <= 0 || b <= 0 || x < 0 || x > 1) throw new ArgumentOutOfRangeException(nameof(x));
        if (x == 0 || x == 1) return x;
        double bt = Math.Exp(LogGamma(a + b) - LogGamma(a) - LogGamma(b) + a * Math.Log(x) + b * Math.Log(1.0 - x));
        return x < (a + 1.0) / (a + b + 2.0) ? bt * BetaCf(a, b, x) / a : 1.0 - bt * BetaCf(b, a, 1.0 - x) / b;
    }

    /// <summary>Student t distribution function with ν degrees of freedom (ν need not be an integer).</summary>
    public static double StudentT(double t, double nu)
    {
        double tail = 0.5 * BetaI(nu / 2.0, 0.5, nu / (nu + t * t));
        return t >= 0 ? 1.0 - tail : tail;
    }

    public sealed record Welch(double MeanA, double MeanB, double T, double Df, double P);

    /// <summary>One-sided Welch test of mean(a) > mean(b): t, Welch–Satterthwaite degrees of freedom and p.</summary>
    public static Welch WelchGreater(IReadOnlyList<double> a, IReadOnlyList<double> b)
    {
        double ma = a.Average(), mb = b.Average();
        double va = a.Sum(x => (x - ma) * (x - ma)) / (a.Count - 1), vb = b.Sum(x => (x - mb) * (x - mb)) / (b.Count - 1);
        double qa = va / a.Count, qb = vb / b.Count, se2 = qa + qb;
        if (se2 <= 0) return new Welch(ma, mb, 0, double.NaN, ma > mb ? 0.0 : (ma == mb ? 0.5 : 1.0));
        double t = (ma - mb) / Math.Sqrt(se2);
        double df = se2 * se2 / (qa * qa / (a.Count - 1) + qb * qb / (b.Count - 1));
        return new Welch(ma, mb, t, df, 1.0 - StudentT(t, df));
    }
}
