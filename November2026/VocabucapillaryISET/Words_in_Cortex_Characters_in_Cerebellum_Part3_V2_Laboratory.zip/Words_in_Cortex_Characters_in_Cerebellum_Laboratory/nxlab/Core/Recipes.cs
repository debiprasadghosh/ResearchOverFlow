namespace NxLab.Core;

/// <summary>Shared recipes so that every study builds the same cerebellar models, gains and utterances from the same seeds.</summary>
public static class Recipes
{
    public const int TrainSteps = 30_000, Cells = 1024, K = 4, RefDelay = 12;
    public const double Coding = 0.1, Alpha = 1e-6;
    public const ulong ModelSeed = 8_100, TuneSeed = 8_200, PhoneSeed = 8_300;

    public static int Index(Effector e) => e.Name switch { "limb" => 0, "articulators" => 1, "eye" => 2, _ => throw new ArgumentException(e.Name) };

    /// <summary>The learned forward model (granule layer) or, with zero cells, the nuclear pathway alone.</summary>
    public static GranuleModel Model(Effector e, int cells)
    {
        var data = Excitation.Make(e, TrainSteps, Rng.Derive(ModelSeed, 10 + (ulong)Index(e)));
        return Cerebellum.Fit(cells == 0 ? "nuclear pathway" : "granule layer", data, cells, K, Coding, Alpha, ModelSeed + 1000 * (ulong)Index(e) + (ulong)cells);
    }

    public static (IReadOnlyList<double[]> R, IReadOnlyList<double[]> Rv, int Steps) TuneReaches(Effector e) => Loop.Reaches(e, 8, 0.4, 0.2, 0.8, Rng.Derive(TuneSeed, 30 + (ulong)Index(e)));
    public static (IReadOnlyList<double[]> R, IReadOnlyList<double[]> Rv, int Steps) EvalReaches(Effector e) => Loop.Reaches(e, 12, 0.4, 0.2, 0.8, Rng.Derive(TuneSeed, 40 + (ulong)Index(e)));

    public static Gains Tuned(Effector e, ForwardModel? m, int delay)
    {
        var (R, Rv, _) = TuneReaches(e);
        return Loop.Tune(e, m, delay, R, Rv, Noise.Default, Rng.Derive(TuneSeed, 50 + (ulong)Index(e))).Best;
    }

    public static IReadOnlyList<double[]> PhoneTargets() => Loop.PhoneTargets(Effector.Articulators.Dof, Rng.Derive(PhoneSeed, 1));

    /// <summary>Frequency-sampled words that have a pronunciation (draws are repeated until a pronounced word comes up).</summary>
    public static (IReadOnlyList<string> Words, Rng Next) SampleWords(Lexicon lex, Pronouncing cmu, int count, Rng rng)
    {
        var r = rng; var outp = new List<string>();
        while (outp.Count < count) { var (k, nr) = lex.Sample(r); r = nr; if (cmu.Has(lex.Words[k])) outp.Add(lex.Words[k]); }
        return (outp, r);
    }
}
