# Words in cortex, characters in the cerebellum: laboratory (immutable C#)

Companion to *Words in Cortex, Characters in the Cerebellum: Utterance, Inner Speech and the Character Level of
Language in the Hybrid Vocabucapillary Design* (Ghosh, 2026), Part 3 of the hybrid design in which ISET is used only
for the character-level action modes and word-level vocabularies are kept for the other modes. Part 3 maps the design
onto the brain in four tiers (front ends, orienting maps, character level, word records, with the thalamus, basal
ganglia, hippocampus and cerebellum as control roles) and tests hypotheses about cerebellar loops: action only (A),
utterance only (U), the character level in both directions (C), and every level including words (B, lexical or
conceptual). The second version adds reading saccades (N04) and the C-versus-B test as simulated patient studies (N05).
Every number in the paper comes from `nxlab/`.

| Folder | Contents |
|---|---|
| `nxlab/` | .NET 8 console project, no packages. `Core/` holds the SplitMix64 generator, the MessagePack reader and lexicon of Parts 1 and 2, the CMU Pronouncing Dictionary loader (`Phonology.cs`), the effectors and forward-model interface (`Effector.cs`), granule forward models, exploration data, rollouts and the delta rule (`Cerebellum.cs`), delayed-feedback loops, gain tuning and self-paced utterance (`Control.cs`), the phonological loop (`PhonoLoop.cs`), special functions and the Welch test (`Stats.cs`) and shared seeds and recipes (`Recipes.cs`). `Experiments/N00`–`N05`; `Program.cs` loads the data once and is the only code that writes files. |
| `data/` | `large_en.msgpack.gz` (wordfreq 3.1.1), `cmudict.dict` and `cmudict_LICENSE.txt` (CMU Pronouncing Dictionary); see Data below. |
| `out/` | 28 CSV tables, `headlines.json`, `run_log.txt`, `PY_crosscheck.csv`. |
| `pycheck/` | `nxport.py` (line-for-line ports of the generator, lexicon, dictionary loader, effectors, exploration data, loops, utterance, reading saccades, phonological loop, special functions and the test simulation; granule models refitted with numpy), `crosscheck.py` (independent checks) and `figures.py` (plots only). |
| `figs/`, `paper/` | Figures; `build_paper.py` rebuilds the Word file from the outputs (needs pandoc), `docxfix.py` repairs pandoc's OOXML order quirks, `ref.docx` holds the styles. |

## Running

```
cd nxlab
dotnet run -c Release              # all six studies, about five minutes on two cores; reads ../data, writes ../out
dotnet run -c Release -- N02       # one study (writes a partial headlines.json; set NX_OUT to write elsewhere)
cd ../pycheck && python3 crosscheck.py && python3 figures.py
cd ../paper && python3 build_paper.py
```

`NX_DATA`, `NX_CMU` and `NX_OUT` override the word list, the dictionary and the output folder. On 25 November 2026
the package was rebuilt in a clean folder and all 29 outputs (28 CSV files and `headlines.json`) were byte-identical
to those in `out/`. The Python check (`pycheck/crosscheck.py`) passed 147 of 147 checks in under three minutes, and the
figures and the paper text it feeds were reproduced unchanged.

| Study | Question | Kind |
|---|---|---|
| N00 | Letters, phonemes and syllables per word and per second; homophones and multiple pronunciations; uniqueness points of phoneme and letter strings; new words against tokens heard; causal attention pairs per minute at four resolutions | Exact counts |
| N01 | Granule forward models of a 7-joint limb and 6 articulators (λ = 10/3): model size, inputs per cell, coding level, the climbing-fibre delta rule against its least-squares fixed point | Fitted models |
| N02 | Reaching with delayed feedback (0–120 ms) with the exact model, the learned granule model, the nuclear pathway or none; self-paced speech of frequency-sampled English words: rate, duration contrast, accuracy; rate against delay | Simulation |
| N03 | Verbal span and item recall in a decay-and-rehearsal loop paced by the articulation times of N02, under lesion models U (slowed rehearsal), E (encoding loss), S (shorter-lived traces) and C (U and S), in quiet and under articulatory suppression; storage-side variants and a trace-lifetime sweep | Monte Carlo |
| N04 | Reading saccades of a one-degree-of-freedom eye (λ = 5, 60 ms visual delay) between frequency-sampled words with the exact model, the learned granule model, the linear model alone and none: duration, gain, landing error, words leaving their target, time per word; key-press times of the limb | Simulation |
| N05 | The C-versus-B test: an exponential speed–accuracy model of semantic judgements with intercept costs from N04 and trace loss from N03; six designs; expected deficits; rejection rates of 4,000 simulated studies per cell for 12–40 patients per group; power against the B effect and item difficulty; deadline and phonological-holding sweeps | Monte Carlo |

## Data

`data/large_en.msgpack.gz` is taken unchanged from wordfreq 3.1.1 by Robyn Speer
(https://github.com/rspeer/wordfreq). The wordfreq code is licensed under Apache 2.0 and its data files under the
Creative Commons Attribution-ShareAlike 4.0 licence (https://creativecommons.org/licenses/by-sa/4.0/); the data include
material derived from Google Books Ngrams and other sources listed in the wordfreq documentation.

`data/cmudict.dict` is the CMU Pronouncing Dictionary as distributed with the Python package cmudict, copyright
1993–2015 Carnegie Mellon University, redistributed unchanged under the BSD-style licence in
`data/cmudict_LICENSE.txt` (http://www.speech.cs.cmu.edu/cgi-bin/cmudict). The effectors, phoneme targets,
exploration data and phonological-loop lists are synthetic and generated by the laboratory.
