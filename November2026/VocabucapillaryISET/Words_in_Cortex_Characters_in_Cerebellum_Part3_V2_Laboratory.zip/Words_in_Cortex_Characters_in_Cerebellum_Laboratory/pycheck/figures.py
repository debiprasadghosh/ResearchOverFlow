"""Figures for the Part 3 paper, drawn from the C# laboratory outputs (plotting only, no computation)."""
import csv, json, os
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.ticker import NullFormatter, NullLocator, FixedLocator, FuncFormatter

_ROOT = Path(__file__).resolve().parent.parent
OUT = os.environ.get("NX_OUT", str(_ROOT / "out")); FIG = os.environ.get("NX_FIGS", str(_ROOT / "figs"))
os.makedirs(FIG, exist_ok=True)
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, VIOLET = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6"
INK, INK2, MUTED, GRID = "#1f1f1f", "#52514e", "#8a8984", "#e4e3df"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9, "axes.edgecolor": MUTED,
    "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": GRID,
    "grid.linewidth": 0.6, "axes.axisbelow": True, "axes.spines.top": False, "axes.spines.right": False,
    "legend.frameon": False, "savefig.dpi": 220, "lines.linewidth": 2, "text.color": INK})
H = json.load(open(f"{OUT}/headlines.json"))
def rd(n): return list(csv.DictReader(open(f"{OUT}/{n}.csv")))
def fl(x): return float(x)
def save(f, n):
    for a in f.axes:
        if a.get_xscale() == "log": a.xaxis.set_minor_locator(NullLocator()); a.xaxis.set_minor_formatter(NullFormatter())
        if a.get_yscale() == "log": a.yaxis.set_minor_formatter(NullFormatter())
    f.savefig(f"{FIG}/{n}.png", bbox_inches="tight"); plt.close(f)
def title(ax, s): ax.set_title(s, loc="left", fontsize=8.6, color=INK)

# ---------------- Figure 1: the mapping in four tiers ----------------
fig, ax = plt.subplots(figsize=(7.3, 4.75)); ax.set_axis_off(); ax.set_xlim(0, 14.6); ax.set_ylim(0, 9.5)
SOLID, DASHED = "-", (0, (3, 2))
def box(x, y, w, h, head, lines, ec=INK2, ls=SOLID, fc="white", lw=1.2, hs=6.8, fs=5.9, step=0.26):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.1", fc=fc, ec=ec, lw=lw, linestyle=ls))
    top = y + h - 0.27
    ax.text(x + w / 2, top, head, ha="center", va="center", fontsize=hs, weight="bold", color=INK)
    for i, s_ in enumerate(lines):
        ax.text(x + w / 2, top - 0.32 - step * i, s_, ha="center", va="center", fontsize=fs, color=INK2)
W = 3.35; X0 = 1.45; cols = [X0, X0 + W + 0.1, X0 + 2 * (W + 0.1)]; XC = X0 + 3 * W + 0.35; WC = 14.55 - XC
for x, hd in zip(cols, ("Hearing and speech", "Vision and reading", "Action")): ax.text(x + W / 2, 9.15, hd, ha="center", fontsize=7.4, weight="bold")
ax.text(XC + WC / 2, 9.15, "Control roles", ha="center", fontsize=7.4, weight="bold")
rows = {3: (6.75, 1.75), 2: (4.45, 2.1), 1: (2.3, 1.95), 0: (0.7, 1.4)}
labels = {3: ["word level", "≈ 400 ms"], 2: ["character", "level", "≈ 100 ms"], 1: ["orienting", "maps", "tens of ms"], 0: ["front ends", "fixed", "primitives"]}
for t, (y, h_) in rows.items():
    ax.text(0.7, y + h_ - 0.3, f"Tier {t}", ha="center", fontsize=7.0, weight="bold")
    for i, s_ in enumerate(labels[t]): ax.text(0.7, y + h_ - 0.65 - 0.27 * i, s_, ha="center", fontsize=5.9, color=INK2)
y, h_ = rows[3]
box(X0, y, 3 * W + 0.2, h_, "Word records, no fixed primitives",
    ["the hybrid's word-level Vocabucapillary records: lexical–semantic and combinatorial,",
     "in temporal cortex and the inferior frontal gyrus; comprehension is largely bilateral",
     "(Hickok & Poeppel 2007). Cerebellar loop: open; Section 5.6 simulates the deciding test"], ec=BLUE, ls=DASHED, fs=6.0)
y, h_ = rows[2]
for x, (hd, ls_, st) in zip(cols, (("Phoneme strings", ["superior temporal gyrus, both", "sides; the dorsal stream to", "articulation is left-dominant;", "left insula (Dronkers 1996)"], SOLID),
                                    ("Letter strings", ["visual word form area:", "cultural recycling of", "ventral visual cortex", "(Dehaene & Cohen 2007)"], DASHED),
                                    ("Motor plans", ["articulatory gestures (DIVA;", "Guenther 2016), handwriting", "strokes, reaches, key presses"], SOLID))):
    box(x, y, W, h_, hd, ls_, ec=ORANGE, ls=st)
y, h_ = rows[1]
for x, (hd, ls_, st, ec) in zip(cols, (("Inferior colliculus", ["relay for nearly all ascending", "auditory input; sound location", "(Gruters & Groh 2012)"], DASHED, ORANGE),
                                        ("Superior colliculus", ["selects saccade targets and", "covert attention; deep layers", "multisensory", "(Krauzlis et al. 2013)"], SOLID, INK2),
                                        ("Brainstem generators", ["saccade burst generator with", "its own internal model,", "calibrated by the vermis", "(Takagi et al. 1998)"], SOLID, ORANGE))):
    box(x, y, W, h_, hd, ls_, ec=ec, ls=st)
y, h_ = rows[0]
for x, (hd, ls_) in zip(cols, (("Cochlea", ["fixed frequency channels"]), ("Retina and V1", ["fixed sampling; V1 filters", "learned once (Olshausen &", "Field 1996)"]), ("Muscles and receptors", ["spindles, tendon organs"]))):
    box(x, y, W, h_, hd, ls_, ec=MUTED)
for (yy, hh), hd, ls_, ec in (((6.75, 1.75), "Thalamus", ["shifts and sustains", "cortical interactions", "(Halassa & Kastner,", "2017): the router"], INK2),
                             ((5.0, 1.55), "Basal ganglia", ["central selection", "(Redgrave et al. 1999):", "choosing an atom", "or a chunk"], INK2),
                             ((3.25, 1.55), "Hippocampus", ["fast learning of", "new words (Davis &", "Gaskell 2009):", "adding an atom"], INK2),
                             ((0.7, 2.35), "Cerebellum", ["one predictor in closed", "loops with orange boxes;", "taught by the inferior", "olive; serves units that", "are fast relative to", "the loop delay"], ORANGE)):
    box(XC, yy, WC, hh, hd, ls_, ec=ec, fc="#fbf7f1" if hd == "Cerebellum" else "white", fs=5.8)
for x0, col, st, txt in ((1.5, ORANGE, SOLID, "loop supported (Section 2)"), (5.6, ORANGE, DASHED, "predicted by the time-scale rule"), (10.2, BLUE, DASHED, "open: B against C")):
    ax.plot([x0, x0 + 0.5], [0.28, 0.28], color=col, lw=1.4, ls=st); ax.text(x0 + 0.6, 0.28, txt, va="center", fontsize=5.9, color=INK2)
save(fig, "fig1_mapping")

# ---------------- Figure 2: primitives of speech and text ----------------
fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.55), gridspec_kw=dict(wspace=0.95, width_ratios=[1.1, 0.85, 0.95]))
ov = rd("N00_open_vocabulary")
N = [fl(r["tokens_heard"]) for r in ov]; P = [fl(r["probability_next_token_is_new"]) for r in ov]
ax = axs[0]; ax.plot(N, P, color=BLUE, marker="o", ms=4.5)
for n_, p_, r in zip(N, P, ov): ax.annotate(f"{int(fl(r['distinct_words_known'])):,}", (n_, p_), textcoords="offset points", xytext=(4, 5), fontsize=6.2, color=INK2)
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel("word tokens heard"); ax.set_ylabel("P(next token is a new word)")
ax.set_ylim(0.003, 0.9); ax.set_xlim(500, 4e7)
title(ax, "a  The vocabulary never closes")
ax.text(0.04, 0.05, "labels: distinct words known", transform=ax.transAxes, fontsize=6.1, color=MUTED)
ax = axs[1]
units = [("words", 2.5), ("syllables", H["N00.syllables_per_second"]), ("phonemes", H["N00.phonemes_per_second"]), ("bytes", H["N00.bytes_per_second"])]
ax.barh(range(4), [u[1] for u in units], color=[BLUE, ORANGE, ORANGE, MUTED], height=0.55)
for i, (nm, v) in enumerate(units): ax.text(v + 0.3, i, f"{v:.1f}", va="center", fontsize=6.8, color=INK2)
ax.set_yticks(range(4)); ax.set_yticklabels([u[0] for u in units]); ax.set_xlabel("units per second"); ax.set_xlim(0, 17.5)
ax.grid(axis="y", visible=False)
title(ax, "b  At 2.5 words per second")
ax = axs[2]
amb = [("homophones", H["N00.homophone_token_share"]), ("2+ pronunciations", H["N00.multi_pron_token_share"]),
       ("phonemes: open at end", H["N00.up_phon_not_unique_tokens"]), ("letters: open at end", H["N00.up_let_not_unique_tokens"])]
ax.barh(range(4), [100 * a[1] for a in amb], color=[ORANGE, ORANGE, ORANGE, BLUE], height=0.55)
for i, (nm, v) in enumerate(amb): ax.text(100 * v + 2, i, f"{100 * v:.1f}%", va="center", fontsize=6.8, color=INK2)
ax.set_yticks(range(4)); ax.set_yticklabels([a[0] for a in amb], fontsize=6.9); ax.set_xlabel("share of word tokens (%)"); ax.set_xlim(0, 105)
ax.grid(axis="y", visible=False); ax.invert_yaxis()
title(ax, "c  Ambiguity below the word")
save(fig, "fig2_primitives")

# ---------------- Figure 3: one cerebellar operator ----------------
fig, axs = plt.subplots(1, 4, figsize=(7.5, 2.45), gridspec_kw=dict(wspace=0.42))
fm = rd("N01_forward_models")
ax = axs[0]
for eff, col, lab in (("limb", BLUE, "limb"), ("articulators", ORANGE, "articulators")):
    rr = [r for r in fm if r["effector"] == eff and r["granule_cells_per_microzone"] != "0" and r["acceleration_error_over_sd"] != "NaN" and fl(r["acceleration_error_over_sd"]) > 0]
    ax.plot([fl(r["granule_cells_per_microzone"]) for r in rr], [fl(r["acceleration_error_over_sd"]) for r in rr], color=col, marker="o", ms=4, label=lab)
    ax.axhline(H[f"N01.{eff}_m0_acc_error"], color=col, lw=1, ls=(0, (3, 2)))
ax.text(128, 0.455, "dashed: nuclear pathway alone", fontsize=5.9, color=INK2)
ax.set_xscale("log", base=2); ax.xaxis.set_major_locator(FixedLocator([128, 256, 512, 1024])); ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{int(v)}"))
ax.tick_params(axis="x", labelsize=7)
ax.set_xlabel("granule cells"); ax.set_ylabel("acceleration error / SD"); ax.set_ylim(0, 0.5); ax.legend(fontsize=6.4, loc="center right")
title(ax, "a  Model size")
gs = rd("N01_granule_sweeps")
ax = axs[1]; kk = [r for r in gs if r["parameter"].startswith("inputs")]
ax.plot([fl(r["value"]) for r in kk], [fl(r["acceleration_error_over_sd"]) for r in kk], color=ORANGE, marker="o", ms=4)
ax.set_xlabel("inputs per cell K"); ax.set_ylim(0, 0.5); ax.set_xticks([1, 2, 3, 4, 5]); title(ax, "b  Inputs per cell")
ax = axs[2]; ff = [r for r in gs if r["parameter"].startswith("coding")]
ax.plot([fl(r["value"]) for r in ff], [fl(r["acceleration_error_over_sd"]) for r in ff], color=ORANGE, marker="o", ms=4)
ax.set_xscale("log"); ax.xaxis.set_major_locator(FixedLocator([0.02, 0.1, 0.5])); ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
ax.set_xlabel("coding level f"); ax.set_ylim(0, 0.5); title(ax, "c  Sparseness")
dr = rd("N01_delta_rule"); ax = axs[3]
ep = [fl(r["epoch"]) for r in dr]
ax.plot(ep, [fl(r["delta_rule_error"]) for r in dr], color=VIOLET, marker="o", ms=3.5)
ax.axhline(H["N01.delta_ridge"], color=ORANGE, lw=1.2); ax.axhline(H["N01.delta_linear"], color=MUTED, lw=1.2, ls=(0, (3, 2)))
ax.text(1, fl(dr[0]["delta_rule_error"]) + 0.03, "delta rule", fontsize=6.2, color=INK2)
ax.text(1, H["N01.delta_ridge"] - 0.045, "least squares", fontsize=6.2, color=INK2)
ax.text(1, H["N01.delta_linear"] + 0.017, "nuclear pathway only", fontsize=6.2, color=INK2)
ax.set_xlabel("epochs"); ax.set_ylim(0, 0.5); ax.set_xticks([1, 2, 4, 6, 8])
title(ax, "d  Climbing-fibre learning")
save(fig, "fig3_operator")

# ---------------- Figure 4: loops with delayed feedback ----------------
fig, axs = plt.subplots(2, 2, figsize=(7.2, 5.0), gridspec_kw=dict(wspace=0.36, hspace=0.55))
tr = rd("N02_tracking"); ax = axs[0, 0]
for eff, col in (("limb", BLUE), ("articulators", ORANGE)):
    for cond, ls_ in (("exact", "-"), ("none", (0, (3, 2)))):
        rr = [r for r in tr if r["effector"] == eff and r["forward_model"] == cond]
        ax.plot([fl(r["delay_ms"]) for r in rr], [fl(r["tracking_rms"]) for r in rr], color=col, ls=ls_, lw=1.6, label=f"{eff}, {'exact model' if cond == 'exact' else 'no model'}")
    for cond, mk in (("granule", "o"), ("nuclear", "s")):
        r = next(r for r in tr if r["effector"] == eff and r["forward_model"] == cond)
        ax.plot([fl(r["delay_ms"])], [fl(r["tracking_rms"])], color=col, marker=mk, ms=4.5, ls="none")
ax.set_xlabel("feedback delay (ms)"); ax.set_ylabel("tracking RMS (rad)"); ax.set_yscale("log"); ax.set_ylim(0.008, 1.2)
ax.yaxis.set_major_locator(FixedLocator([0.01, 0.03, 0.1, 0.3, 1.0])); ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
from matplotlib.lines import Line2D
hs, ls2 = ax.get_legend_handles_labels()
hs += [Line2D([], [], marker="o", color=INK2, ls="none", ms=4.5), Line2D([], [], marker="s", color=INK2, ls="none", ms=4.5)]
ls2 += ["granule model, 60 ms", "nuclear only, 60 ms"]
ax.legend(hs, ls2, fontsize=5.7, loc="upper left", handlelength=2.4, ncol=2, columnspacing=0.8)
title(ax, "a  Reaching with delayed feedback")
ex = rd("N02_example"); words = rd("N02_example_words"); ax = axs[1, 0]
for cond, col, lab in (("granule", ORANGE, "learned forward model"), ("none", MUTED, "no forward model")):
    rr = [r for r in ex if r["forward_model"] == cond]
    ax.plot([fl(r["time_s"]) for r in rr], [fl(r["position_dof0"]) for r in rr], color=col, lw=1.4, label=lab)
rr = [r for r in ex if r["forward_model"] == "granule"]
ax.step([fl(r["time_s"]) for r in rr], [fl(r["target_dof0"]) for r in rr], where="pre", color=INK, lw=0.8, alpha=0.6, label="phoneme targets")
ax.set_xlabel("time (s)"); ax.set_ylabel("articulator 1 position"); ax.legend(fontsize=6.0, loc="upper right", ncol=1)
ax.set_ylim(-0.75, 0.95)
title(ax, "c  Four words at 60 ms delay")
rv = rd("N02_rate_vs_delay"); ax = axs[0, 1]
d_ = [fl(r["delay_ms"]) for r in rv]
ax.plot(d_, [fl(r["rate_exact_model"]) for r in rv], color=ORANGE, lw=1.6, label="exact model")
ax.plot(d_, [fl(r["rate_no_model"]) for r in rv], color=ORANGE, lw=1.6, ls=(0, (3, 2)), label="no model")
ax.axhline(H["N02.natural_phoneme_rate"], color=INK2, lw=0.9, ls=":")
ax.text(122, H["N02.natural_phoneme_rate"] - 0.95, "English at\n2.5 words/s", fontsize=5.9, color=INK2, ha="right", va="top")
ax.set_xlabel("feedback delay (ms)"); ax.set_ylabel("phonemes per second"); ax.set_ylim(0, 11.5); ax.legend(fontsize=6.2, loc="lower left")
title(ax, "b  Self-paced speaking rate")
ax = axs[1, 1]
ax.plot(d_, [fl(r["contrast_exact"]) for r in rv], color=ORANGE, lw=1.6, label="exact model")
ax.plot(d_, [fl(r["contrast_none"]) for r in rv], color=ORANGE, lw=1.6, ls=(0, (3, 2)), label="no model")
ax.axhline(1, color=INK2, lw=0.9, ls=":"); ax.text(2, 1.02, "equal durations", fontsize=5.9, color=INK2)
ax.set_xlabel("feedback delay (ms)"); ax.set_ylabel("long / short gesture duration"); ax.set_ylim(0.9, 1.7); ax.legend(fontsize=6.2, loc="center right")
title(ax, "d  Duration contrast")
save(fig, "fig4_loops")

# ---------------- Figure 5: the phonological loop ----------------
fig, axs = plt.subplots(1, 3, figsize=(7.6, 2.75), gridspec_kw=dict(wspace=0.42, width_ratios=[1.55, 1.15, 0.95]))
sp = rd("N03_spans"); ax = axs[0]
keys = ["intact (A)", "U", "E", "S", "C"]; cols = [BLUE, ORANGE, AQUA, YELLOW, MAGENTA]
cells_ = [("short_quiet", "short\nquiet"), ("long_quiet", "long\nquiet"), ("short_suppressed", "short\nsuppr."), ("long_suppressed", "long\nsuppr.")]
w = 0.16
for j, (r, col) in enumerate(zip(sp, cols)):
    ax.bar([i + (j - 2) * w for i in range(4)], [fl(r[c]) for c, _ in cells_], width=w - 0.02, color=col, label=keys[j])
ax.set_xticks(range(4)); ax.set_xticklabels([l for _, l in cells_], fontsize=6.2); ax.set_ylabel("span (items)"); ax.set_ylim(0, 6.6)
ax.grid(axis="x", visible=False); ax.legend(fontsize=6.0, ncol=5, loc="upper center", bbox_to_anchor=(0.5, 1.0), columnspacing=0.7, handlelength=1.1)
title(ax, "a  Span by hypothesis")
it = {r["hypothesis"].split(":")[0].split(" ")[0]: r for r in rd("N03_item_share")}
vr = {r["variant"]: r for r in rd("N03_storage_variants")}
base = fl(it["intact"]["word_length_effect_quiet"])
ax = axs[1]
def pt(dq, ds, wle, col, lab, mk, off, bold=False):
    x = ds / dq; y = 100 * (wle - base)
    ax.plot([x], [y], marker=mk, color=col, ms=6 if mk == "o" else 5, ls="none")
    ax.annotate(lab, (x, y), textcoords="offset points", xytext=off, fontsize=6.4 if bold else 5.9, color=INK if bold else INK2, weight="bold" if bold else "normal")
for k, col, off in (("U", ORANGE, (6, -2)), ("E", AQUA, (6, -3)), ("S", YELLOW, (6, -2)), ("C", MAGENTA, (5, 3))):
    r = it[k]; pt(fl(r["deficit_quiet_short"]), fl(r["deficit_suppressed_short"]), fl(r["word_length_effect_quiet"]), col, k, "o", off, bold=True)
for key, lab, col, off in (("E, encoding loss 0.04", "E 0.04", AQUA, (6, -1)), ("E, encoding loss 0.12", "E 0.12", AQUA, (6, -4)),
                           ("S, trace lifetime x0.9", "S ×0.9", YELLOW, (6, -3)), ("S, trace lifetime x0.7", "S ×0.7", YELLOW, (-30, 3)),
                           ("U with encoding loss 0.08", "U+E", MAGENTA, (6, -4)), ("U with trace lifetime x0.9", "U+S×0.9", MAGENTA, (-38, -10))):
    r = vr[key]; pt(fl(r["items_deficit_quiet"]), fl(r["items_deficit_suppressed"]), fl(r["items_word_length_effect"]), col, lab, "^", off)
ax.axvline(1, color=INK2, lw=0.8, ls=":"); ax.axhline(0, color=INK2, lw=0.8, ls=":")
ax.set_xlabel("deficit suppressed / deficit quiet"); ax.set_ylabel("change in word-length effect (points)"); ax.set_xlim(-0.12, 2.1); ax.set_ylim(-3.5, 8)
title(ax, "b  Diagnostic plane")
ds = rd("N03_decay_sweep"); ax = axs[2]
for k, col in zip(["U", "E", "S", "C"], [ORANGE, AQUA, YELLOW, MAGENTA]):
    rr = [r for r in ds if r["hypothesis"] == k]
    ax.plot([fl(r["decay_s"]) for r in rr], [fl(r["items_deficit_suppressed"]) / fl(r["items_deficit_quiet"]) for r in rr], color=col, marker="o", ms=4, label=k)
ax.axhline(1, color=INK2, lw=0.8, ls=":")
ax.set_xlabel("trace lifetime (s)"); ax.set_ylabel("deficit suppressed / deficit quiet"); ax.set_xticks([3.0, 3.5, 4.0]); ax.set_ylim(-0.1, 2.4)
ax.legend(fontsize=6.0, ncol=2, loc="upper left")
title(ax, "c  Lifetime sweep")
save(fig, "fig5_phonological_loop")

# ---------------- Figure 6: reading saccades ----------------
fig, axs = plt.subplots(1, 3, figsize=(7.5, 2.6), gridspec_kw=dict(wspace=0.5, width_ratios=[1.35, 1.15, 0.85]))
sac = rd("N04_saccades"); em = {r["internal_model"]: r for r in rd("N04_eye_models")}
ax = axs[0]
import numpy as _np
bins = _np.arange(-16, 16.01, 0.5)
for name, col, lab in (("exact", MUTED, "exact equations"), ("granule", ORANGE, "learned granule model"), ("linear", VIOLET, "linear model only")):
    e = [fl(r["error_chars"]) for r in sac if r["internal_model"] == name]
    hgt, edges = _np.histogram(_np.clip(e, -15.9, 15.9), bins=bins)
    ax.step(edges[:-1], hgt / len(e), where="post", color=col, lw=1.4, label=lab)
ax.axvspan(-3, 3, color=GRID, alpha=0.6, lw=0)
ax.set_xlabel("landing error (characters)"); ax.set_ylabel("share of saccades"); ax.set_xlim(-16, 16); ax.set_ylim(0, 0.55)
ax.legend(fontsize=6.0, loc="upper right")
title(ax, "a  Where the eye lands")
ax = axs[1]
names = ["exact", "granule", "linear", "none"]; labs = ["exact", "granule", "linear", "none"]
sacc = [fl(em[n]["saccade_ms"]) for n in names]; acq = [fl(em[n]["acquire_ms"]) for n in names]
corr = [a - s_ for a, s_ in zip(acq, sacc)]
x = range(4)
ax.bar(x, sacc, color=ORANGE, width=0.6, label="saccade")
ax.bar(x, corr, bottom=sacc, color=VIOLET, width=0.6, label="correction")
ax.bar(x, [H["N04.fixation_ms"]] * 4, bottom=acq, color=MUTED, width=0.6, label="lexical fixation")
for i, n in enumerate(names): ax.text(i, fl(em[n]["time_per_word_ms"]) + 8, f"{fl(em[n]['words_per_minute']):.0f}\nwpm", ha="center", fontsize=5.8, color=INK2)
ax.set_xticks(list(x)); ax.set_xticklabels(labs, fontsize=6.6); ax.set_ylabel("time per word (ms)"); ax.set_ylim(0, 470)
ax.grid(axis="x", visible=False); ax.legend(fontsize=5.8, loc="upper center", bbox_to_anchor=(0.5, -0.16), ncol=3, columnspacing=0.8, handlelength=1.2)
title(ax, "b  Time per word")
kp = {r["forward_model"]: r for r in rd("N04_key_press")}; ax = axs[2]
kn = ["granule", "linear", "none"]
ax.bar(range(3), [fl(kp[n]["mean_ms"]) for n in kn], yerr=[fl(kp[n]["sd_ms"]) for n in kn], color=[ORANGE, VIOLET, MUTED], width=0.6, error_kw=dict(ecolor=INK2, lw=0.8, capsize=2))
ax.set_xticks(range(3)); ax.set_xticklabels(kn, fontsize=6.6); ax.set_ylabel("key press (ms)"); ax.set_ylim(0, 300); ax.grid(axis="x", visible=False)
title(ax, "c  Key press")
save(fig, "fig6_reading")

# ---------------- Figure 7: the C-versus-B test ----------------
fig, axs = plt.subplots(1, 3, figsize=(7.5, 2.7), gridspec_kw=dict(wspace=0.42, width_ratios=[1.45, 1.1, 0.9]))
rj = [r for r in rd("N05_rejection") if r["patients_per_group"] == "20"]
ax = axs[0]; w = 0.26
for j, (col, hk, lab) in enumerate(((INK2, "C", "C"), (ORANGE, "B_lexical", "B-lexical"), (VIOLET, "B_conceptual", "B-conceptual"))):
    ax.bar([i + (j - 1) * w for i in range(len(rj))], [fl(r[hk]) for r in rj], width=w - 0.03, color=col, label=lab)
ax.axhline(0.05, color=INK, lw=0.8, ls=":"); ax.text(-0.55, 0.07, "α", fontsize=7, color=INK2)
ax.set_xticks(range(len(rj))); ax.set_xticklabels([r["design"] for r in rj]); ax.set_ylabel("studies finding a deficit"); ax.set_ylim(0, 1.05)
ax.grid(axis="x", visible=False); ax.legend(fontsize=6.0, loc="upper right")
title(ax, "a  Six designs, 20 patients, ε = 0.2")
pw = rd("N05_power"); ax = axs[1]
for eff, col in (("0.1", YELLOW), ("0.2", ORANGE), ("0.3", MAGENTA)):
    for acc, ls_ in (("0.85", "-"), ("0.95", (0, (3, 2)))):
        rr = [r for r in pw if r["design"] == "D5" and r["effect_at_full_severity"] == eff and r["control_untimed_accuracy"] == acc]
        ax.plot([fl(r["patients_per_group"]) for r in rr], [fl(r["rejection_rate"]) for r in rr], color=col, ls=ls_, marker="o", ms=3.5, lw=1.5,
                label=f"ε = {eff}" if acc == "0.85" else None)
rr = [r for r in pw if r["design"] == "D5" and r["effect_at_full_severity"] == "0" and r["control_untimed_accuracy"] == "0.85"]
ax.plot([fl(r["patients_per_group"]) for r in rr], [fl(r["rejection_rate"]) for r in rr], color=INK2, marker="o", ms=3.5, lw=1.2, label="C (ε = 0)")
ax.axhline(0.8, color=INK, lw=0.6, ls=":")
ax.set_xlabel("patients per group"); ax.set_ylabel("power of design D5"); ax.set_ylim(0, 1.05); ax.set_xticks([12, 20, 40])
ax.legend(fontsize=5.9, loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=2, columnspacing=0.8)
title(ax, "b  Power of the clean test")
dl = rd("N05_deadline"); ax = axs[2]
ax.plot([fl(r["deadline_s"]) for r in dl], [fl(r["rejection_rate_under_C_n20"]) for r in dl], color=INK2, marker="o", ms=4, lw=1.6)
ax.axhline(0.05, color=INK, lw=0.8, ls=":")
ax.set_xlabel("deadline (s)"); ax.set_ylabel("false positives under C (D1)"); ax.set_ylim(0, 1.05); ax.set_xticks([0.9, 1.2, 1.5])
title(ax, "c  Time pressure")
save(fig, "fig7_test")
print("figures written to", FIG)
