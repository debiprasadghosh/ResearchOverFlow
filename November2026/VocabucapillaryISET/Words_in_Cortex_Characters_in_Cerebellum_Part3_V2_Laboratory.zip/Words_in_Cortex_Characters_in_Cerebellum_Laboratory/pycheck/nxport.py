"""Line-for-line Python ports of the Part 3 laboratory (generator, lexicon, pronouncing dictionary, effector, excitation,
granule forward model, delayed-feedback loops, self-paced utterance and the phonological loop) for the cross-check.
The MessagePack reader is independent of the C# one; the granule readout is solved with numpy instead of the C#
Cholesky routine, so learned models agree to rounding, not bit for bit."""
import gzip, math
import numpy as np

M64 = (1 << 64) - 1
G64 = 0x9E3779B97F4A7C15
C1, C2 = 0xBF58476D1CE4E5B9, 0x94D049BB133111EB


class Rng:
    def __init__(self, s): self.s = s & M64

    @staticmethod
    def derive(seed, stream):
        r = Rng((seed ^ ((stream * 0xD1B54A32D192ED03) & M64)) & M64)
        r.u64(); return r

    def u64(self):
        self.s = (self.s + G64) & M64
        z = self.s
        z = ((z ^ (z >> 30)) * C1) & M64
        z = ((z ^ (z >> 27)) * C2) & M64
        return z ^ (z >> 31)

    def double(self): return (self.u64() >> 11) * (1.0 / 9007199254740992.0)

    def int(self, n):
        v = int(self.double() * n); return n - 1 if v >= n else v

    def uniform(self, lo, hi): return lo + (hi - lo) * self.double()

    def gauss(self):
        u1 = self.double(); u2 = self.double()
        return math.sqrt(-2.0 * math.log(1.0 - u1)) * math.cos(2.0 * math.pi * u2)


def doubles_vectorized(rng, count):
    """The next `count` uniform doubles of a generator, computed with numpy (independent of the scalar port)."""
    k = np.arange(1, count + 1, dtype=np.uint64)
    s = np.uint64(rng.s) + k * np.uint64(G64)
    z = s
    z = (z ^ (z >> np.uint64(30))) * np.uint64(C1)
    z = (z ^ (z >> np.uint64(27))) * np.uint64(C2)
    z = z ^ (z >> np.uint64(31))
    return (z >> np.uint64(11)).astype(np.float64) * (1.0 / 9007199254740992.0)


# ---------------- MessagePack (minimal, independent) and the lexicon ----------------
def unpack(b):
    def rdv(i):
        t = b[i]
        if t <= 0x7f: return t, i + 1
        if 0x80 <= t <= 0x8f: return rmap(i + 1, t & 0x0f)
        if 0x90 <= t <= 0x9f: return rarr(i + 1, t & 0x0f)
        if 0xa0 <= t <= 0xbf: n = t & 0x1f; return b[i + 1:i + 1 + n].decode(), i + 1 + n
        if t == 0xd9: n = b[i + 1]; return b[i + 2:i + 2 + n].decode(), i + 2 + n
        if t == 0xda: n = int.from_bytes(b[i + 1:i + 3], "big"); return b[i + 3:i + 3 + n].decode(), i + 3 + n
        if t == 0xdc: return rarr(i + 3, int.from_bytes(b[i + 1:i + 3], "big"))
        if t == 0xdd: return rarr(i + 5, int.from_bytes(b[i + 1:i + 5], "big"))
        if t == 0xcc: return b[i + 1], i + 2
        if t == 0xcd: return int.from_bytes(b[i + 1:i + 3], "big"), i + 3
        raise ValueError(hex(t))

    def rarr(i, n):
        out = []
        for _ in range(n):
            v, i = rdv(i); out.append(v)
        return out, i

    def rmap(i, n):
        out = {}
        for _ in range(n):
            k, i = rdv(i); v, i = rdv(i); out[k] = v
        return out, i
    return rdv(0)[0]


def is_alpha(w): return len(w) > 0 and all("a" <= c <= "z" for c in w)


class Lexicon:
    def __init__(self, root, max_words=50000):
        allw = [(w, 10.0 ** (-(i - 1) / 100.0)) for i in range(1, len(root)) for w in root[i]]
        kept = [x for x in allw if is_alpha(x[0]) and len(x[0]) <= 16][:max_words]
        mass = 0.0
        for _, f in kept: mass += f
        self.words = [w for w, _ in kept]
        self.prob = [f / mass for _, f in kept]
        self.cdf = []
        acc = 0.0
        for p in self.prob: acc += p; self.cdf.append(acc)

    @staticmethod
    def root(path): return unpack(gzip.open(path).read())

    def sample(self, r):
        target = r.double() * self.cdf[-1]
        lo, hi = 0, len(self.cdf) - 1
        while lo < hi:
            mid = (lo + hi) // 2
            if self.cdf[mid] > target: hi = mid
            else: lo = mid + 1
        return lo


# ---------------- CMU Pronouncing Dictionary ----------------
VOWELS = ["AA", "AE", "AH", "AO", "AW", "AY", "EH", "ER", "EY", "IH", "IY", "OW", "OY", "UH", "UW"]
CONSONANTS = ["B", "CH", "D", "DH", "F", "G", "HH", "JH", "K", "L", "M", "N", "NG", "P", "R", "S", "SH", "T", "TH", "V", "W", "Y", "Z", "ZH"]
PHONES = VOWELS + CONSONANTS
PHONE_INDEX = {p: i for i, p in enumerate(PHONES)}


def load_cmu(path):
    m = {}
    with open(path, encoding="utf-8") as fh:
        for raw in fh:
            line = raw.rstrip("\n")
            h = line.find("#")
            if h >= 0: line = line[:h]
            parts = [x for x in line.split(" ") if x]
            if len(parts) < 2: continue
            head = parts[0]
            paren = head.find("(")
            if paren > 0: head = head[:paren]
            if not is_alpha(head): continue
            phones = [p.rstrip("012") for p in parts[1:]]
            if any(p not in PHONE_INDEX for p in phones): continue
            m.setdefault(head, []).append(phones)
    return m


def syllables(phones): return sum(1 for p in phones if p in VOWELS)


# ---------------- Effector and forward models ----------------
W0, ZETA, GAMMA, COUPLING, UMAX, V0, DT = 2 * math.pi, 0.3, 0.5, 0.8, 400.0, 2.0, 0.005


class Effector:
    def __init__(self, name, dof, lam):
        self.name, self.dof, self.lam = name, dof, lam
        self.omega = W0 * lam
        self.ulim = UMAX * lam * lam

    def clip(self, u):
        if u < -self.ulim: return -self.ulim
        if u > self.ulim: return self.ulim
        return u

    def passive(self, p, v, pp):
        w = self.omega
        return -2 * ZETA * w * v - w * w * p - GAMMA * w * w * math.sin(p) - COUPLING * w * w * pp * pp * p

    def fv(self, v): return 1.0 / (1.0 + abs(v) / (V0 * self.lam))

    def accel(self, p, v, u):
        return [u[i] * self.fv(v[i]) + self.passive(p[i], v[i], p[i - 1] if i > 0 else 0.0) for i in range(self.dof)]

    def feedforward(self, r):
        return [-self.passive(r[i], 0.0, r[i - 1] if i > 0 else 0.0) for i in range(self.dof)]


LIMB = Effector("limb", 7, 1.0)
ARTICULATORS = Effector("articulators", 6, 10.0 / 3.0)
EYE = Effector("eye", 1, 5.0)


class Exact:
    def __init__(self, e): self.e = e
    def accel(self, p, v, u): return self.e.accel(p, v, u)


def excitation(e, steps, rng):
    n, lam = e.dof, e.lam
    p = [0.0] * n; v = [0.0] * n; tgt = [0.0] * n; ou = [0.0] * n; u = [0.0] * n
    P, V, U, A = [], [], [], []
    seg = round(0.25 / lam / DT)
    w = 10 * lam
    bands = [6, 12, 24, 36]
    r = rng
    for t in range(steps):
        if t % seg == 0:
            for i in range(n): tgt[i] = r.uniform(-0.8, 0.8)
            w = bands[r.int(len(bands))] * lam
        for i in range(n):
            g = r.gauss()
            ou[i] += -ou[i] * DT * 20 * lam + math.sqrt(DT) * g * 80 * lam * lam
            u[i] = e.clip(w * w * (tgt[i] - p[i]) - 2 * 0.6 * w * v[i] + ou[i])
        a = e.accel(p, v, u)
        P.append(p[:]); V.append(v[:]); U.append(u[:]); A.append(a[:])
        for i in range(n): v[i] += DT * a[i]; p[i] += DT * v[i]
    return {"e": e, "P": np.array(P), "V": np.array(V), "U": np.array(U), "A": np.array(A)}


def mossy(P, V, U, i):
    """Mossy inputs of degree of freedom i for every row: p_i, v_i, u_i, p_{i-1}, v_{i-1}."""
    z = np.zeros((P.shape[0], 5))
    z[:, 0] = P[:, i]; z[:, 1] = V[:, i]; z[:, 2] = U[:, i]
    if i > 0: z[:, 3] = P[:, i - 1]; z[:, 4] = V[:, i - 1]
    return z


class Zone:
    def __init__(self, idx, w, theta, scale, inscale, readout):
        self.idx, self.w, self.theta, self.scale, self.inscale, self.readout = idx, w, theta, scale, inscale, readout

    def granule(self, Z):
        if self.idx.shape[0] == 0: return np.zeros((Z.shape[0], 0))
        H = np.zeros((Z.shape[0], self.idx.shape[0]))
        for q in range(self.idx.shape[1]): H = H + self.w[:, q] * Z[:, self.idx[:, q]]
        return np.maximum(H - self.theta, 0.0) / self.scale

    def predict_rows(self, X):
        Z = X / self.inscale
        return self.readout[5] + Z @ self.readout[:5] + self.granule(Z) @ self.readout[6:]


class GranuleModel:
    def __init__(self, e, zones): self.e, self.zones = e, zones

    def accel(self, p, v, u):
        out = []
        for i in range(self.e.dof):
            x = np.array([[p[i], v[i], u[i], p[i - 1] if i > 0 else 0.0, v[i - 1] if i > 0 else 0.0]])
            out.append(float(self.zones[i].predict_rows(x)[0]))
        return out


def fit(data, cells, k, coding, alpha, seed):
    e = data["e"]; zones = []
    N = data["P"].shape[0]
    for i in range(e.dof):
        X = mossy(data["P"], data["V"], data["U"], i)
        m = X.mean(axis=0); var = (X * X).mean(axis=0) - m * m
        inscale = np.where(var > 1e-18, np.sqrt(np.maximum(var, 0)), 1.0)
        Z = X / inscale
        if cells > 0:
            r = Rng.derive(seed, 100 + i)
            idx = np.zeros((cells, k), dtype=int); w = np.zeros((cells, k))
            for j in range(cells):
                chosen = []
                while len(chosen) < k:
                    c = r.int(5)
                    if c not in chosen: chosen.append(c)
                for q in range(k): w[j, q] = r.gauss(); idx[j, q] = chosen[q]
            zc = Z[:min(5000, N)]
            H = np.zeros((zc.shape[0], cells))
            for q in range(k): H = H + w[:, q] * zc[:, idx[:, q]]
            Hs = np.sort(H, axis=0)
            theta = Hs[int(math.floor((1 - coding) * (zc.shape[0] - 1)))]
            scale = np.sqrt((np.maximum(H - theta, 0.0) ** 2).mean(axis=0)) + 1e-9
        else:
            idx = np.zeros((0, k), dtype=int); w = np.zeros((0, k)); theta = np.zeros(0); scale = np.zeros(0)
        zone = Zone(idx, w, theta, scale, inscale, None)
        dim = 6 + cells; G = alpha * N * np.eye(dim); b = np.zeros(dim)
        for c0 in range(0, N, 5000):                     # normal equations accumulated in row blocks to bound memory
            Zc = Z[c0:c0 + 5000]
            F = np.hstack([Zc, np.ones((Zc.shape[0], 1)), zone.granule(Zc)])
            G += F.T @ F; b += F.T @ data["A"][c0:c0 + 5000, i]
        zone.readout = np.linalg.solve(G, b)
        zones.append(zone)
    return GranuleModel(e, zones)


def normalized_error(model, test):
    e = test["e"]
    pred = np.column_stack([model.zones[i].predict_rows(mossy(test["P"], test["V"], test["U"], i)) for i in range(e.dof)])
    y = test["A"]
    return math.sqrt(((pred - y) ** 2).mean() / y.var())


def rollout_error(model, test, delay, windows):
    e = test["e"]; n = e.dof; P, V, U = test["P"], test["V"], test["U"]; steps = P.shape[0]
    se = 0.0; cnt = 0
    stride = max(1, (steps - delay - 1) // windows)
    for t0 in range(0, steps - delay, stride):
        pe = list(P[t0]); ve = list(V[t0])
        if model is not None:
            for s in range(t0, t0 + delay):
                a = model.accel(pe, ve, list(U[s]))
                for i in range(n): ve[i] += DT * a[i]; pe[i] += DT * ve[i]
        for i in range(n):
            d = pe[i] - P[t0 + delay][i]; se += d * d; cnt += 1
    return math.sqrt(se / cnt)


# ---------------- Loops ----------------
NOISE = (0.02, 0.002, 0.02)              # motor, sensor position, sensor velocity
PACING = (0.12, 0.45, 0.08, 0.12, 1.0)   # Ta, Tb, Tol, HitTol, Timeout
BANDWIDTHS = [2.0, 3, 4, 6, 8, 12, 16, 24, 32]
DAMPINGS = [0.5, 0.8, 1.0]


def min_jerk(a, b, s):
    s = min(max(s, 0.0), 1.0)
    f = 10 * s * s * s - 15 * s * s * s * s + 6 * s * s * s * s * s
    ds = (b - a) * (30 * s * s - 60 * s * s * s + 30 * s * s * s * s)
    return a + (b - a) * f, ds


def reaches(e, count, move_t, hold, amp, rng):
    n = e.dof; r = rng
    tg = [[0.0] * n]
    for _ in range(count): tg.append([r.uniform(-amp, amp) for _ in range(n)])
    T, Hd = move_t / e.lam, hold / e.lam
    steps = round((T + Hd) / DT)
    R, Rv = [], []
    for k in range(count):
        for s in range(steps):
            pv = [min_jerk(tg[k][i], tg[k + 1][i], s * DT / T) for i in range(n)]
            R.append([x for x, _ in pv]); Rv.append([d / T for _, d in pv])
    return R, Rv, steps


def estimate(e, model, delay, t, hp, hv, hu, r):
    n = e.dof; j = max(0, t - delay)
    pe = [0.0] * n; ve = [0.0] * n
    for i in range(n):
        g1 = r.gauss(); g2 = r.gauss()
        pe[i] = hp[j][i] + NOISE[1] * g1
        ve[i] = hv[j][i] + NOISE[2] * e.lam * g2
    if model is not None:
        for s in range(j, t):
            a = model.accel(pe, ve, hu[s])
            for i in range(n): ve[i] += DT * a[i]; pe[i] += DT * ve[i]
    return pe, ve


def step(e, p, v, u, r):
    un = [u[i] * (1 + NOISE[0] * r.gauss()) for i in range(e.dof)]
    a = e.accel(p, v, un)
    for i in range(e.dof): v[i] += DT * a[i]; p[i] += DT * v[i]


def gains_kp_kd(e, g): return math.pow(g[0] * e.lam, 2), 2 * g[1] * g[0] * e.lam


def track(e, model, delay, g, R, Rv, rng):
    n = e.dof; kp, kd = gains_kp_kd(e, g)
    p = [0.0] * n; v = [0.0] * n
    hp = [p[:]]; hv = [v[:]]; hu = []
    r = Rng(rng.s); se = 0.0
    for t in range(len(R)):
        pe, ve = estimate(e, model, delay, t, hp, hv, hu, r)
        ff = e.feedforward(R[t])
        u = [e.clip(ff[i] + kp * (R[t][i] - pe[i]) + kd * (Rv[t][i] - ve[i])) for i in range(n)]
        hu.append(u)
        step(e, p, v, u, r)
        for i in range(n):
            if not math.isfinite(p[i]) or abs(p[i]) > 20: return math.inf
            d = p[i] - R[t][i]; se += d * d
        hp.append(p[:]); hv.append(v[:])
    return math.sqrt(se / (len(R) * float(n)))


def tune(e, model, delay, R, Rv, rng):
    grid = [(w, z) for w in BANDWIDTHS for z in DAMPINGS]
    res = [(g, track(e, model, delay, g, R, Rv, rng)) for g in grid]
    return min(res, key=lambda x: (x[1], x[0][0]))[0]


def distance(a, b):
    s = 0.0
    for i in range(len(a)): s += (a[i] - b[i]) * (a[i] - b[i])
    return math.sqrt(s / len(a))


def paced(e, model, delay, g, targets, rng, pacing=None):
    ta, tb, tol, _, timeout = PACING if pacing is None else pacing
    n = e.dof; kp, kd = gains_kp_kd(e, g)
    tg = targets
    p = tg[0][:]; v = [0.0] * n
    hp = [p[:]]; hv = [v[:]]; hu = []
    durs, dists, errs = [], [], []
    r = Rng(rng.s); t = 0; k = 1; start = 0.0
    def planned(kk): return (ta + tb * distance(tg[kk], tg[kk - 1])) / e.lam
    T = planned(1) if len(tg) > 1 else 0
    while k < len(tg):
        rr = [0.0] * n; rv = [0.0] * n
        for i in range(n):
            x, ds = min_jerk(tg[k - 1][i], tg[k][i], (t * DT - start) / T)
            rr[i] = x; rv[i] = ds / T
        pe, ve = estimate(e, model, delay, t, hp, hv, hu, r)
        ff = e.feedforward(rr)
        u = [e.clip(ff[i] + kp * (rr[i] - pe[i]) + kd * (rv[i] - ve[i])) for i in range(n)]
        hu.append(u)
        step(e, p, v, u, r)
        hp.append(p[:]); hv.append(v[:]); t += 1
        el = t * DT - start
        if (el >= T and distance(pe, tg[k]) <= tol) or el > timeout:
            durs.append(el); dists.append(distance(tg[k], tg[k - 1])); errs.append(distance(p, tg[k]))
            k += 1; start = t * DT
            if k < len(tg): T = planned(k)
    return durs, dists, errs, t * DT, p[:]


def phone_targets(dof, rng):
    r = rng
    return [[r.uniform(-0.6, 0.6) for _ in range(dof)] for _ in range(len(PHONES))]


def utter(words, cmu, ph, dof):
    tg = [[0.0] * dof]
    for w in words:
        for x in cmu[w][0]: tg.append(ph[PHONE_INDEX[x]])
    return tg


def sample_words(lex, cmu, count, r):
    out = []
    while len(out) < count:
        k = lex.sample(r)
        if lex.words[k] in cmu: out.append(lex.words[k])
    return out


# ---------------- Phonological loop ----------------
LOOP = dict(presentation=1.0, decay=3.5, decay_sd=0.25, output=0.5, gap=0.05)


def trial(durs, lp, rehearse, encode_fail, r):
    n = len(durs)
    g = r.gauss()
    decay = lp["decay"] * math.exp(lp["decay_sd"] * g)
    last = [0.0] * n; alive = [False] * n
    for i in range(n): alive[i] = r.double() >= encode_fail; last[i] = i * lp["presentation"]
    def ok(i, time): return alive[i] and time - last[i] <= decay
    recall_start = n * lp["presentation"]
    if rehearse:
        time = 0.0; presented = 1; nxt = 0
        while time < recall_start:
            next_pres = presented * lp["presentation"] if presented < n else math.inf
            if time >= next_pres: presented += 1; nxt = 0; continue
            tries = 0
            while tries < presented and not ok(nxt, time): nxt = (nxt + 1) % presented; tries += 1
            if tries == presented: time = min(next_pres, recall_start); continue
            end = time + durs[nxt] + lp["gap"]
            if end > recall_start: break
            if ok(nxt, time): last[nxt] = end
            time = end
            nxt = (nxt + 1) % presented
            if time >= next_pres: presented += 1; nxt = 0
    correct = 0; all_ok = True
    for i in range(n):
        if ok(i, recall_start + i * lp["output"]): correct += 1
        else: all_ok = False
    return all_ok, correct


def recall(pool, n, trials, lp, rehearse, encode_fail, rng, lifetime=1.0):
    r = Rng(rng.s); ok = 0; items = 0
    lpx = dict(lp); lpx["decay"] = lp["decay"] * lifetime
    idx = list(range(len(pool)))
    for _ in range(trials):
        for k in range(n):
            j = r.int(len(pool) - k)
            idx[k], idx[k + j] = idx[k + j], idx[k]
        a, c = trial([pool[i] for i in idx[:n]], lpx, rehearse, encode_fail, r)
        ok += 1 if a else 0; items += c
    return ok / trials, items / (trials * n)


def span(perfect, n_min):
    for k, p in enumerate(perfect):
        if p < 0.5:
            if k == 0: return n_min - 0.5
            p0, p1 = perfect[k - 1], p
            return n_min + k - 1 + (p0 - 0.5) / (p0 - p1)
    return n_min + len(perfect) - 1


# ---------------- Special functions and the Welch test (Numerical Recipes algorithms, as in Stats.cs) ----------------
EPS = 2.220446049250313e-16
FPMIN = 2.2250738585072014e-308 / 2.220446049250313e-16
COF = [57.1562356658629235, -59.5979603554754912, 14.1360979747417471, -0.491913816097620199,
       .339946499848118887e-4, .465236289270485756e-4, -.983744753048795646e-4, .158088703224912494e-3, -.210264441724104883e-3,
       .217439618115212643e-3, -.164318106536763890e-3, .844182239838527433e-4, -.261908384015814087e-4, .368991826595316234e-5]


def log_gamma(xx):
    x = y = xx
    tmp = x + 5.24218750000000000
    tmp = (x + 0.5) * math.log(tmp) - tmp
    ser = 0.999999999999997092
    for j in range(14):
        y += 1
        ser += COF[j] / y
    return tmp + math.log(2.5066282746310005 * ser / x)


def gamma_q(a, x):
    if x == 0: return 1.0
    gln = log_gamma(a)
    if x < a + 1.0:
        ap = a; sm = 1.0 / a; de = sm
        for _ in range(100000):
            ap += 1; de *= x / ap; sm += de
            if abs(de) < abs(sm) * EPS: break
        return 1.0 - sm * math.exp(-x + a * math.log(x) - gln)
    b = x + 1.0 - a; c = 1.0 / FPMIN; d = 1.0 / b; h = d
    for i in range(1, 100000):
        an = -i * (i - a)
        b += 2.0
        d = an * d + b
        if abs(d) < FPMIN: d = FPMIN
        c = b + an / c
        if abs(c) < FPMIN: c = FPMIN
        d = 1.0 / d
        de = d * c
        h *= de
        if abs(de - 1.0) <= EPS: break
    return math.exp(-x + a * math.log(x) - gln) * h


def phi(x):
    z = -x / math.sqrt(2.0)
    erfc = gamma_q(0.5, z * z) if z >= 0 else 2.0 - gamma_q(0.5, z * z)
    return 0.5 * erfc


def inv_phi(p):
    lo, hi = -40.0, 40.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if phi(mid) < p: lo = mid
        else: hi = mid
    return 0.5 * (lo + hi)


def beta_cf(a, b, x):
    qab = a + b; qap = a + 1.0; qam = a - 1.0; c = 1.0; d = 1.0 - qab * x / qap
    if abs(d) < FPMIN: d = FPMIN
    d = 1.0 / d; h = d
    for m in range(1, 10000):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN: d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN: c = FPMIN
        d = 1.0 / d; h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN: d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN: c = FPMIN
        d = 1.0 / d
        de = d * c; h *= de
        if abs(de - 1.0) <= EPS: break
    return h


def beta_i(a, b, x):
    if x == 0 or x == 1: return x
    bt = math.exp(log_gamma(a + b) - log_gamma(a) - log_gamma(b) + a * math.log(x) + b * math.log(1.0 - x))
    return bt * beta_cf(a, b, x) / a if x < (a + 1.0) / (a + b + 2.0) else 1.0 - bt * beta_cf(b, a, 1.0 - x) / b


def student_t(t, nu):
    tail = 0.5 * beta_i(nu / 2.0, 0.5, nu / (nu + t * t))
    return 1.0 - tail if t >= 0 else tail


def nsum(xs):
    """Naive left-to-right summation, as LINQ Sum and Average do (Python's sum is compensated since 3.12)."""
    acc = 0.0
    for x in xs: acc += x
    return acc


def welch_greater(a, b):
    ma = nsum(a) / len(a); mb = nsum(b) / len(b)
    va = nsum((x - ma) * (x - ma) for x in a) / (len(a) - 1); vb = nsum((x - mb) * (x - mb) for x in b) / (len(b) - 1)
    qa = va / len(a); qb = vb / len(b); se2 = qa + qb
    if se2 <= 0: return ma, mb, 0.0 if ma > mb else (0.5 if ma == mb else 1.0)
    t = (ma - mb) / math.sqrt(se2)
    df = se2 * se2 / (qa * qa / (len(a) - 1) + qb * qb / (len(b) - 1))
    return ma, mb, 1.0 - student_t(t, df)


# ---------------- N04: reading text ----------------
CHAR, LINE_START, FIXATION, CORR_LAT = 0.01, -0.3, 0.2, 0.15
EYE_PACING = (0.12, 0.45, 0.005, 0.01, 0.5)
KEY_PACING = (0.12, 0.45, 0.02, 0.04, 1.0)


def reading_text(lex, lines=40, per_line=11):
    r = Rng.derive(804, 1); out = []
    for _ in range(lines):
        words, centres, half = [], [], []
        for k in range(per_line):
            w = lex.words[lex.sample(r)]
            c = LINE_START + len(w) * CHAR / 2 if k == 0 else centres[k - 1] + (len(words[k - 1]) + len(w)) * CHAR / 2 + CHAR
            words.append(w); centres.append(c); half.append((len(w) + 1) * CHAR / 2)
        out.append((words, centres, half))
    return out


def read_saccades(eye, model, g, text):
    res = []; j = 0
    for words, c, h in text:
        for k in range(1, len(words)):
            durs, _, _, _, pend = paced(eye, model, 12, g, [[c[k - 1]], [c[k]]], Rng.derive(804, 1000 + j), EYE_PACING)
            landing = pend[0]; err = landing - c[k]; miss = abs(err) > h[k]
            acq = durs[0] + ((CORR_LAT + (EYE_PACING[0] + EYE_PACING[1] * abs(err)) / eye.lam) if miss else 0)
            res.append((durs[0], landing, err, miss, acq)); j += 1
    return res


# ---------------- N05: the C-versus-B test ----------------
N05 = dict(trials=60, alpha=0.05, beta=4.0, encode=0.30, first=0.20, deadline=1.0, asym_sd=0.35, gap=2.0, life=3.5,
           life_factor=0.8, life_sd=0.25, phon=0.5, dec_mean=0.70, dec_sd=0.12, dec_cv=0.4, sev_lo=0.2, sev_hi=1.0)
DESIGNS = {"D1": (True, True, False, False, False), "D2": (False, True, False, False, True), "D3": (False, True, False, False, False),
           "D4": (False, False, True, False, False), "D5": (False, False, False, False, False), "D6": (False, False, False, True, False)}


def lerp(a, b, s): return a + (b - a) * s


def intercept(d, s, costs):
    sp, sac, seq, pic, rt = DESIGNS[d]
    return N05["encode"] + lerp(costs["key_i"], costs["key_l"], s) + ((N05["first"] + lerp(costs["acq_i"], costs["acq_l"], s)) if sac else 0)


def trace_loss(s, w):
    return w * (1 - phi(math.log(N05["life"] * (1 - (1 - N05["life_factor"]) * s) / N05["gap"]) / N05["life_sd"]))


def p_correct(d, h, su, lam, s):
    sp, sac, seq, pic, rt = DESIGNS[d]
    if h == "B-conceptual" or (h == "B-lexical" and not pic): lam *= 1 - su["effect"] * s
    dp = lam * max(0.0, 1 - math.exp(-N05["beta"] * (su["deadline"] - intercept(d, s, su["costs"])))) if sp else lam
    p = phi(dp / 2)
    if seq:
        lost = trace_loss(s, su["phon"]); p = (1 - lost) * p + lost * 0.5
    return p


def score(d, h, su, s, r):
    g = r.gauss()
    lam = max(0.2, su["asym"] + N05["asym_sd"] * g)
    if DESIGNS[d][4]:
        g2 = r.gauss(); dec = max(0.2, N05["dec_mean"] + N05["dec_sd"] * g2)
        sig = math.sqrt(math.log(1 + N05["dec_cv"] * N05["dec_cv"])); mu = math.log(dec) - sig * sig / 2
        icpt = intercept(d, s, su["costs"]); sm = 0.0
        for _ in range(N05["trials"]): sm += icpt + math.exp(mu + sig * r.gauss())
        return sm / N05["trials"]
    p = p_correct(d, h, su, lam, s); c = 0
    for _ in range(N05["trials"]):
        if r.double() < p: c += 1
    return c / N05["trials"]


def study(d, h, su, n, rng):
    r = Rng(rng.s)
    ctl = [score(d, h, su, 0.0, r) for _ in range(n)]
    pat = []
    for _ in range(n):
        s = r.uniform(N05["sev_lo"], N05["sev_hi"]); pat.append(score(d, h, su, s, r))
    ma, mb, p = welch_greater(pat, ctl) if DESIGNS[d][4] else welch_greater(ctl, pat)
    return p < N05["alpha"]


def rejection_rate(d, h, su, n, stream_base, studies=4000):
    return sum(1 for rep in range(studies) if study(d, h, su, n, Rng.derive(805, stream_base + rep))) / studies


def expected(d, h, su, rng, draws=200000):
    r = Rng(rng.s); c = p = 0.0
    for _ in range(draws):
        g = r.gauss(); s = r.uniform(N05["sev_lo"], N05["sev_hi"])
        lam = max(0.2, su["asym"] + N05["asym_sd"] * g)
        if DESIGNS[d][4]:
            c += intercept(d, 0, su["costs"]) + N05["dec_mean"]; p += intercept(d, s, su["costs"]) + N05["dec_mean"]
        else:
            c += p_correct(d, h, su, lam, 0); p += p_correct(d, h, su, lam, s)
    return c / draws, p / draws
