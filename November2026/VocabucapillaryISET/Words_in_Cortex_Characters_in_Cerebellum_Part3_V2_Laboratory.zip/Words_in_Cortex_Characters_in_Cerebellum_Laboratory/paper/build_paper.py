"""Assembles the Part 3 paper (words in cortex, characters in the cerebellum) from the laboratory outputs and converts it
to Word with pandoc and the docxfix repair step."""
import csv, json, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT, FIG = ROOT / "out", ROOT / "figs"
sys.path.insert(0, str(HERE))
import docxfix

H = json.load(open(OUT / "headlines.json"))
def g(k): return H[k]
def rd(n): return list(csv.DictReader(open(OUT / f"{n}.csv")))
def m(s): return s.replace("-", "−")
def f1(x): return m(f"{x:.1f}")
def f2(x): return m(f"{x:.2f}")
def f3(x): return m(f"{x:.3f}")
def f4(x): return m(f"{x:.4f}")
def pc(x, d=0): return m(f"{100 * x:.{d}f}%")
def n0(x): return f"{x:,.0f}"
def fl(x): return float(x)
def sg(x, d=2): return ("+" if x > 0.0005 else "") + m(f"{x:.{d}f}")

def md_table(header, rows, caption, widths=None):
    lens = [max(min(len(str(h)), 14), 9, *(len(str(r[i])) for r in rows)) for i, h in enumerate(header)]
    dashes = widths if widths else [max(9, min(60, l)) for l in lens]
    out = [f"Table: {caption}", "", "| " + " | ".join(header) + " |", "|" + "|".join("-" * w for w in dashes) + "|"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out) + "\n"

py = list(csv.DictReader(open(OUT / "PY_crosscheck.csv")))
py_pass = sum(r["pass"] == "true" for r in py)
py_agree = f"{py_pass} of {len(py)}"

# ---------------- lookups ----------------
units = rd("N00_units"); ov = rd("N00_open_vocabulary"); hom = rd("N00_homophones"); pairs = rd("N00_attention_pairs")
fm = rd("N01_forward_models"); gs = rd("N01_granule_sweeps"); dr = rd("N01_delta_rule")
trk = rd("N02_tracking"); utt = rd("N02_utterance"); rvd = rd("N02_rate_vs_delay"); exw = rd("N02_example_words")
wd = rd("N03_word_durations"); sp = rd("N03_spans"); it = rd("N03_item_share"); var = rd("N03_storage_variants"); dsw = rd("N03_decay_sweep")

def fmv(eff, model, col): return fl(next(r[col] for r in fm if r["effector"] == eff and r["model"].startswith(model)))
def tv(eff, d, cond, col): return fl(next(r[col] for r in trk if r["effector"] == eff and r["delay_ms"] == str(d) and r["forward_model"] == cond))
def uv(cond, col): return fl(next(r[col] for r in utt if r["forward_model"] == cond))
def rv(d, col): return fl(next(r[col] for r in rvd if r["delay_ms"] == str(d)))
def hyp(rows, key):
    for r in rows:
        h_ = r["hypothesis"]
        if (key == "intact" and h_.startswith("intact")) or h_.startswith(key + ":"): return r
    raise KeyError(key)
def vv(label, col): return fl(next(r[col] for r in var if r["variant"] == label))
def ratio(r): return fl(r["deficit_suppressed_short"]) / fl(r["deficit_quiet_short"])

I_sp, I_it = hyp(sp, "intact"), hyp(it, "intact")
lin_limb, lin_art = fmv("limb", "nuclear", "acceleration_error_over_sd"), fmv("articulators", "nuclear", "acceleration_error_over_sd")
g_limb, g_art = fmv("limb", "granule layer, 1024", "acceleration_error_over_sd"), fmv("articulators", "granule layer, 1024", "acceleration_error_over_sd")
none60_l, none60_a = tv("limb", 60, "none", "tracking_rms"), tv("articulators", 60, "none", "tracking_rms")
ex60_l, ex60_a = tv("limb", 60, "exact", "tracking_rms"), tv("articulators", 60, "exact", "tracking_rms")
gr60_l, gr60_a = tv("limb", 60, "granule", "tracking_rms"), tv("articulators", 60, "granule", "tracking_rms")
nu60_l, nu60_a = tv("limb", 60, "nuclear", "tracking_rms"), tv("articulators", 60, "nuclear", "tracking_rms")
limb_at_667 = tv("limb", 60, "none", "tracking_rms") + (66.667 - 60) / 20 * (tv("limb", 80, "none", "tracking_rms") - tv("limb", 60, "none", "tracking_rms"))
slow20, slow40, slow60 = rv(20, "slowing_factor"), rv(40, "slowing_factor"), rv(60, "slowing_factor")
ratio20, ratio60 = rv(20, "delay_over_gesture_duration"), rv(60, "delay_over_gesture_duration")
word_ratio = 60 / 400
short_i, short_l = g("N03.short_dur_intact"), g("N03.short_dur_lesion")
long_i, long_l = g("N03.long_dur_intact"), g("N03.long_dur_lesion")
oov7 = g("N00.oov_N10000000")

# ---------------- tables ----------------
t_hyp = md_table(["Hyp.", "Cerebellar loops serve", "Overt speech", "Verbal memory under articulatory suppression", "Word-length effect after a lesion", "Untimed word semantics", "Untimed picture semantics"], [
    ["A", "action modes only, overt articulation and eye movements included", "impaired", "no deficit (no deficit in quiet either)", "normal", "spared", "spared"],
    ["U", "utterance: articulatory units of either hemisphere, overt or covert", "impaired", "no deficit: the quiet deficit comes from rehearsal alone", "reduced", "spared", "spared"],
    ["C", "fast units of every modality, among them the character level of language in both directions", "impaired", "deficit persists", "normal or larger", "spared", "spared"],
    ["B-lexical", "as C, plus word records", "impaired", "deficit persists", "normal or larger", "impaired", "spared"],
    ["B-conceptual", "as C, plus all semantic records", "impaired", "deficit persists", "normal or larger", "impaired", "impaired"],
], "Table 1. Hypotheses about cerebellar loops in the hybrid design and what each predicts after a cerebellar lesion. U is the hypothesis put forward before this paper; C refines it; B comes in a lexical and a conceptual form.", [13, 23, 10, 18, 12, 12, 12])

unit_rows = [[r["unit"].replace(" (bytes an LLM reads, without the space)", " (bytes an LLM reads)"), f2(fl(r["per_word_token_weighted"])), f2(fl(r["per_word_type"])), f2(fl(r["per_second_at_2.5_words"]))] for r in units]
unit_rows.append(["bytes with the separating space", f2(g("N00.letters_per_word") + 1), "–", f2(g("N00.bytes_per_second"))])
unit_rows.append(["words", "1", "1", "2.50"])
t_units = md_table(["Unit", "Per word token (frequency-weighted)", "Per word type", "Per second at 2.5 words per second"], unit_rows,
    f"Table 2. Units of the spoken and the written word for the {n0(g('N00.covered_words'))} of the 50,000 most frequent English words that the CMU Pronouncing Dictionary lists ({pc(g('N00.covered_token_share'), 1)} of word tokens), using each word's first listed pronunciation.", [34, 20, 14, 20])

ov_rows = [[n0(fl(r["tokens_heard"])), n0(fl(r["distinct_words_known"])), f4(fl(r["probability_next_token_is_new"])), f1(fl(r["new_words_per_1000_tokens"]))] for r in ov]
t_ov = md_table(["Word tokens heard", "Distinct words known", "Probability that the next token is new", "New words per 1,000 tokens"], ov_rows,
    f"Table 3. The open vocabulary. Word tokens drawn by frequency from the full alphabetic word list ({n0(g('N00.full_list_words'))} words of up to 16 letters); a word is known once it has been heard. A word-level vocabulary keeps meeting new words, which only a level of primitives below the word can spell or pronounce.", [18, 18, 24, 18])

amb_rows = [
    ["Homophones: tokens whose pronunciation another word shares", f"{n0(g('N00.homophone_sets'))} sets, {n0(g('N00.homophone_words'))} words", pc(g("N00.homophone_token_share"), 1), "–"],
    ["Several listed pronunciations", f"{n0(g('N00.multi_pron_words'))} words", pc(g("N00.multi_pron_token_share"), 1), "–"],
    ["Not unique by the end of the word (another word extends it)", f"{pc(g('N00.up_phon_not_unique_types'), 1)} of types", pc(g("N00.up_phon_not_unique_tokens"), 1), pc(g("N00.up_let_not_unique_tokens"), 1)],
    ["Uniqueness point over word length (unique words)", "–", f2(g("N00.up_phon_fraction")), f2(g("N00.up_let_fraction"))],
    ["Units left after the uniqueness point", "–", f2(g("N00.up_phon_after")), f2(g("N00.up_let_after"))],
]
t_amb = md_table(["Measure", "Count", "Phonemes (share of tokens or value)", "Letters"], amb_rows,
    f"Table 4. Ambiguity of the strings below the word. The largest homophone set by frequency is {hom[0]['spellings']} ({hom[0]['pronunciation']}); the dictionary's reduced forms put *and* with *und* and *a* with *uh*.", [40, 18, 18, 12])

pair_rows = [[r["resolution"], n0(fl(r["tokens_per_minute"])), n0(fl(r["causal_pairs_per_minute"])), f1(fl(r["causal_pairs_per_minute"]) / g("N00.pairs_words"))] for r in pairs]
t_pairs = md_table(["Resolution of one token", "Tokens per minute", "Causal attention pairs per minute", "Against words"], pair_rows,
    "Table 5. Work of causal self-attention over one minute of speech at four resolutions (n(n + 1)/2 pairs for n tokens).", [32, 16, 20, 12])

fm_rows = []
for eff in ("limb", "articulators"):
    for r in fm:
        if r["effector"] != eff: continue
        acc = "–" if r["acceleration_error_over_sd"] == "NaN" else f3(fl(r["acceleration_error_over_sd"]))
        fm_rows.append([eff, r["model"], acc, f4(fl(r["position_error_60ms_rad"]))])
t_fm = md_table(["Effector", "Forward model", "Acceleration error / SD", "State error after 60 ms (rad)"], fm_rows,
    f"Table 6. One cerebellar operator learns both forward models (30,000 training steps of exploration, 6,000 test steps). The state error is the RMS position error after rolling the model 12 steps (60 ms) from the true state with the commands actually sent, over 1,000 windows; without a model the controller holds the delayed observation. Four inputs per granule cell, coding level 0.1. Active granule cells per sample: {pc(g('N01.limb_active_share'), 1)} (limb) and {pc(g('N01.articulators_active_share'), 1)} (articulators).", [14, 40, 16, 18])

sw_rows = [[r["parameter"], r["value"] if r["parameter"].startswith("inputs") else m(f"{fl(r['value']):g}"), f3(fl(r["acceleration_error_over_sd"])), f4(fl(r["position_error_60ms_rad"]))] for r in gs]
t_sw = md_table(["Parameter (articulators, 1,024 cells)", "Value", "Acceleration error / SD", "State error after 60 ms (rad)"], sw_rows,
    "Table 7. Inputs per granule cell and coding level (the share of calibration samples on which a cell is active).", [34, 10, 18, 18])

trk_rows = []
for eff in ("limb", "articulators"):
    for cond, lab in (("exact", "exact equations"), ("granule", "learned granule model"), ("nuclear", "nuclear pathway only"), ("none", "none (delayed observation)")):
        r = next(r for r in trk if r["effector"] == eff and r["delay_ms"] == "60" and r["forward_model"] == cond)
        trk_rows.append([eff, lab, f"{m(f'{fl(r['bandwidth']):g}')} / {fl(r['damping']):.1f}", f4(fl(r["tracking_rms"])), f4(fl(r["end_error"])), f3(fl(r["overshoot_fraction"])), f4(fl(r["hold_sd"]))])
t_trk = md_table(["Effector", "Forward model", "Tuned bandwidth / damping", "Tracking RMS (rad)", "End error (rad)", "Overshoot / distance", "Jitter while holding (rad)"], trk_rows,
    "Table 8. Point-to-point reaching with 60 ms of feedback delay (12 minimum-jerk reaches between random targets in ±0.8 rad). Gains were tuned for each loop on a separate set of reaches, so each row is the best its loop can do. The bandwidth is in rad/s of the effector's own time.", [12, 24, 14, 12, 11, 12, 12])

utt_rows = []
for cond, lab in (("exact", "exact equations"), ("granule", "learned granule model"), ("nuclear", "nuclear pathway only"), ("none", "none (delayed observation)")):
    utt_rows.append([lab, f2(uv(cond, "phonemes_per_second")), f1(uv(cond, "mean_gesture_ms")), f2(uv(cond, "duration_cv")), f3(uv(cond, "duration_distance_correlation")), f2(uv(cond, "duration_contrast")), f3(uv(cond, "on_target_share")), f3(uv(cond, "mean_error_at_end"))])
t_utt = md_table(["Forward model", "Phonemes per second", "Mean gesture (ms)", "CV", "Duration–distance correlation", "Duration contrast", "On target at the end", "Error at the end"], utt_rows,
    f"Table 9. Self-paced speech at 60 ms of feedback delay: 30 utterances of 10 frequency-sampled English words ({n0(uv('none', 'gestures'))} phoneme gestures). The contrast is the mean duration of the quarter of gestures with the longest articulatory distance over that of the quarter with the shortest. On target: error at most 0.12 when the gesture ended. CV: coefficient of variation of gesture durations. English at 2.5 words per second carries {f2(g('N02.natural_phoneme_rate'))} phonemes per second.", [22, 12, 11, 7, 14, 11, 11, 10])

rv_rows = [[r["delay_ms"], f2(fl(r["delay_over_gesture_duration"])), f2(fl(r["rate_exact_model"])), f2(fl(r["rate_no_model"])), f2(fl(r["slowing_factor"])), f3(fl(r["corr_none"])), f2(fl(r["contrast_none"])), f3(fl(r["on_target_none"]))] for r in rvd]
t_rv = md_table(["Delay (ms)", "Delay / gesture duration", "Rate, exact model", "Rate, no model", "Slowing", "Duration–distance correlation, no model", "Contrast, no model", "On target, no model"], rv_rows,
    f"Table 10. Speaking rate against feedback delay (phonemes per second). Gains were retuned at every delay. The gesture duration is the intact mean, {f1(uv('exact', 'mean_gesture_ms'))} ms.", [9, 12, 11, 11, 9, 18, 12, 12])

dur_rows = []
for pool, lab in (("short", "one syllable"), ("long", "three syllables")):
    rr = [r for r in wd if r["pool"] == pool]
    ex = ", ".join(r["word"] for r in rr[:6])
    dur_rows.append([lab, ex, f2(g(f"N03.{pool}_phonemes")), f"{1000 * g(f'N03.{pool}_dur_intact'):.0f}", f"{1000 * g(f'N03.{pool}_dur_lesion'):.0f}", f2(g(f"N03.{pool}_dur_ratio"))])
t_dur = md_table(["Words", "First words of the pool", "Phonemes", "Articulation, intact (ms)", "Articulation, no forward model (ms)", "Ratio"], dur_rows,
    "Table 11. The word pools of the memory study: the first 60 words of the 5,000 most frequent with one and with three syllables (at least three letters), each articulated alone by the loop of Table 9.", [14, 34, 12, 14, 18, 8])

def spanrow(r, label):
    return [label, f2(fl(r["short_quiet"])), f2(fl(r["long_quiet"])), f2(fl(r["short_suppressed"])), f2(fl(r["long_suppressed"])), f2(fl(r["word_length_effect_quiet"])), f2(fl(r["suppression_effect_short"])), f2(fl(r["deficit_quiet_short"])), f2(fl(r["deficit_suppressed_short"]))]
labels = [("intact", "intact (A: no lesion effect)"), ("U", "U: covert rehearsal slowed"), ("E", "E: 8% of items not encoded"), ("S", "S: traces live 0.8 as long"), ("C", "C: U and S together")]
sp_rows = [spanrow(hyp(sp, k), lab) for k, lab in labels]
t_sp = md_table(["Lesion model", "Short, quiet", "Long, quiet", "Short, suppr.", "Long, suppr.", "Word-length effect", "Suppr. effect", "Deficit, quiet", "Deficit, suppr."], sp_rows,
    "Table 12. Verbal span (the list length recalled perfectly half the time, from 2,000 lists per length) under five lesion models, in quiet and under articulatory suppression (suppr.). Effects and deficits are for short words. Every model uses the same random lists (common random numbers).", [26, 8, 8, 9, 9, 10, 9, 9, 9])
def itrow(r, label):
    return [label, f3(fl(r["short_quiet"])), f3(fl(r["long_quiet"])), f3(fl(r["short_suppressed"])), f3(fl(r["word_length_effect_quiet"])), f3(fl(r["suppression_effect_short"])), f3(fl(r["deficit_quiet_short"])), f3(fl(r["deficit_suppressed_short"])), f2(ratio(r)) if fl(r["deficit_quiet_short"]) > 0 else "–"]
it_rows = [itrow(hyp(it, k), lab) for k, lab in labels]
t_it = md_table(["Lesion model", "Short, quiet", "Long, quiet", "Short, suppr.", "Word-length effect", "Suppr. effect", "Deficit, quiet", "Deficit, suppr.", "Deficit ratio"], it_rows,
    "Table 13. The same simulations read as the share of items recalled from lists of five words. The deficit ratio is the deficit under suppression over the deficit in quiet: 0 when the lesion acts only through rehearsal, 1 when suppression leaves the deficit unchanged.", [26, 8, 8, 10, 10, 10, 9, 10, 9])

var_rows = [[r["variant"], f2(fl(r["span_deficit_quiet"])), f2(fl(r["span_deficit_suppressed"])), f2(fl(r["span_word_length_effect"])), f3(fl(r["items_deficit_quiet"])), f3(fl(r["items_deficit_suppressed"])), f2(fl(r["items_deficit_suppressed"]) / fl(r["items_deficit_quiet"])), f3(fl(r["items_word_length_effect"]))] for r in var]
t_var = md_table(["Variant", "Span deficit, quiet", "Span deficit, suppressed", "Span word-length effect", "Item deficit, quiet", "Item deficit, suppressed", "Deficit ratio", "Item word-length effect"], var_rows,
    f"Table 14. Storage-side variants of several sizes and mixtures with slowed rehearsal. Intact values: span word-length effect {f2(fl(I_sp['word_length_effect_quiet']))}, item word-length effect {f3(fl(I_it['word_length_effect_quiet']))}.", [30, 10, 11, 11, 10, 11, 9, 11])

ds_rows = []
for dec in ("3", "3.5", "4"):
    for k in ("intact", "U", "E", "S", "C"):
        r = next(r for r in dsw if r["decay_s"] == dec and r["hypothesis"] == k)
        dq, ds_ = fl(r["items_deficit_quiet"]), fl(r["items_deficit_suppressed"])
        ds_rows.append([m(f"{fl(dec):.1f}"), k, f2(fl(r["span_short_quiet"])), f2(fl(r["span_short_suppressed"])), f3(fl(r["items_word_length_effect"])), f3(dq), f3(ds_), f2(ds_ / dq) if dq > 0 else "–"])
t_ds = md_table(["Trace lifetime (s)", "Model", "Span, short, quiet", "Span, short, suppressed", "Item word-length effect", "Item deficit, quiet", "Item deficit, suppressed", "Deficit ratio"], ds_rows,
    "Table 15. The pattern of Tables 12 and 13 at three trace lifetimes.", [12, 8, 12, 14, 14, 12, 14, 10])

S_it, U_it, E_it, C_it = hyp(it, "S"), hyp(it, "U"), hyp(it, "E"), hyp(it, "C")
S_sp, U_sp, E_sp, C_sp = hyp(sp, "S"), hyp(sp, "U"), hyp(sp, "E"), hyp(sp, "C")
def dsr(k): return [fl(r["items_deficit_suppressed"]) / fl(r["items_deficit_quiet"]) for r in dsw if r["hypothesis"] == k]
def vr_(lab): return vv(lab, "items_deficit_suppressed") / vv(lab, "items_deficit_quiet")
S_ratios = dsr("S") + [vr_("S, trace lifetime x0.9"), vr_("S, trace lifetime x0.7")]
E_ratios = dsr("E") + [vr_("E, encoding loss 0.04"), vr_("E, encoding loss 0.12")]
UX_ratios = dsr("C") + [vr_("U with encoding loss 0.08"), vr_("U with trace lifetime x0.9")]
assert all(x == 0 for x in dsr("U"))

t_ev = md_table(["Observation", "A", "U", "C", "B", "Model result in this paper"], [
    ["Ataxic dysarthria: segments prolonged, syllable durations tending to equality (Kent et al., 1979)", "✓", "✓", "✓", "✓", f"no forward model: gestures {f2(uv('none', 'mean_gesture_ms') / uv('granule', 'mean_gesture_ms'))} times longer, contrast {f2(uv('granule', 'duration_contrast'))} → {f2(uv('none', 'duration_contrast'))}"],
    ["Cerebellar activation steps up above about 3 syllables per second (Riecker et al., 2005)", "✓", "✓", "✓", "✓", f"the cost of no forward model grows with delay over unit duration (slowing {f2(slow20)} at {f2(ratio20)}, {f2(slow60)} at {f2(ratio60)})"],
    ["Superior HVI and HVIIA active in silent rehearsal without a memory load (Desmond et al., 1997)", "✗", "✓", "✓", "✓", "covert articulation uses the same forward model"],
    ["Right inferior HVIIB active only with a memory load (Desmond et al., 1997)", "✗", "✗", "✓", "✓", "a storage-side component distinct from rehearsal (S or E)"],
    ["Verbal span lower; word-length and suppression effects comparable to controls; deficit not removed by suppression (Ravizza et al., 2006)", "✗", "✗", "✓", "✓", f"S: deficit ratio {f2(ratio(S_it))}, word-length effect {sg(fl(S_it['word_length_effect_quiet']) - fl(I_it['word_length_effect_quiet']), 3)}; U: ratio 0, {sg(fl(U_it['word_length_effect_quiet']) - fl(I_it['word_length_effect_quiet']), 3)}"],
    ["Phonological similarity effect reduced (Justus et al., 2005)", "✗", "✗", "✓", "✓", "not modelled: the store is not phonologically structured here"],
    ["A single case with a deficit at the phonological output buffer of rehearsal (Silveri et al., 1998)", "✗", "✓", "✓", "✓", "U: the deficit is confined to rehearsal"],
    ["Right cerebellar rTMS slows predictive looks during sentences (Lesage et al., 2012); concurrent syllable production removes the prediction effect (Martin et al., 2018)", "✗", "✓", "✓", "✓", "prediction through the production forward model; the test that separates C from B is in Section 6"],
    ["Excellent standard language tests, impaired practice-related learning and error detection (Fiez et al., 1992)", "✗", "–", "partly", "✓", "the climbing-fibre update is the learning rule; C does not predict the learning deficit"],
    ["Vermal lesions sparing the nuclei: saccades hypometric, 2–5 times more variable, adaptation lost (Takagi et al., 1998)", "✓", "–", "✓", "✓", f"linear model only: gain SD ×{f2(g('N04.eye_gain_sd_ratio_linear'))}, but overshoot instead of undershoot"],
    ["Cerebellar patients impaired in timing taps and judging durations, not loudness (Ivry & Keele, 1989)", "✗", "–", "✓", "✓", "the time-scale rule (Section 4.4) covers perception"],
], "Table 20. The hypotheses against the evidence reviewed in Section 2 (B stands for both of its forms). ✓ consistent, ✗ contradicted, – silent.", [40, 5, 5, 9, 5, 34])

# ---------------- N04 and N05 ----------------
em = {r["internal_model"]: r for r in rd("N04_eye_models")}
kp = {r["forward_model"]: r for r in rd("N04_key_press")}
comp = rd("N05_components"); expd = rd("N05_expected"); rejt = rd("N05_rejection"); pwt = rd("N05_power"); seqt = rd("N05_sequential"); ddlt = rd("N05_deadline")
def emv(n, col): return fl(em[n][col])
def rej(d, h, n=20): return fl(next(r[{"C": "C", "B-lexical": "B_lexical", "B-conceptual": "B_conceptual"}[h]] for r in rejt if r["design"] == d and r["patients_per_group"] == str(n)))
def exd(d, h): return fl(next(r["deficit"] for r in expd if r["design"] == d and r["hypothesis"] == h))
def pwr(d, acc, eff, n): return fl(next(r["rejection_rate"] for r in pwt if r["design"] == d and r["control_untimed_accuracy"] == acc and r["effect_at_full_severity"] == eff and r["patients_per_group"] == str(n)))
def seqv(w, col): return fl(next(r[col] for r in seqt if fl(r["share_held_phonologically"]) == w))
def ddlv(t, col): return fl(next(r[col] for r in ddlt if fl(r["deadline_s"]) == t))
wpm_g, wpm_l = emv("granule", "words_per_minute"), emv("linear", "words_per_minute")
key_g, key_l, key_n = fl(kp["granule"]["mean_ms"]), fl(kp["linear"]["mean_ms"]), fl(kp["none"]["mean_ms"])

eye_rows = []
for n_, lab in (("exact", "exact equations"), ("granule", "learned granule model (intact)"), ("linear", "linear model only (cortex lesioned)"), ("none", "none (delayed observation)")):
    bw = m(f"{emv(n_, 'bandwidth'):g}")
    eye_rows.append([lab, f"{bw} / {emv(n_, 'damping'):.1f}", f1(emv(n_, "saccade_ms")), f2(emv(n_, "gain_mean")), f2(emv(n_, "gain_sd")), f2(emv(n_, "landing_error_sd_chars")), pc(emv(n_, "landing_outside_word"), 1), f"{emv(n_, 'acquire_ms'):.0f}", f"{emv(n_, 'time_per_word_ms'):.0f}", f"{emv(n_, 'words_per_minute'):.0f}"])
t_eye = md_table(["Internal model", "Gains", "Saccade, ms", "Gain", "Gain SD", "Landing SD, chars", "Missed the word", "Acquired, ms", "Per word, ms", "Words / min"], eye_rows,
    f"Table 16. Reading saccades with 60 ms of visual feedback delay: {n0(g('N04.eye_saccades'))} saccades between frequency-sampled words (mean amplitude {f1(g('N04.eye_mean_amplitude_chars'))} characters). Gains are the tuned bandwidth and damping. Gain is the distance travelled over the distance to the target. A saccade that lands outside its word (the letters plus half a space on each side) is followed by a corrective saccade after 150 ms; each word is then fixated for 200 ms.", [18, 9, 10, 7, 7, 10, 9, 10, 9, 8])

comp_rows = [[r["component"], f3(fl(r["control"])), f3(fl(r["patient_mean_severity"])), f3(fl(r["patient_full_severity"]))] for r in comp]
t_comp = md_table(["Component", "Control", "Patient, mean severity (0.6)", "Patient, full severity"], comp_rows,
    "Table 17. What a cerebellar lesion adds under every hypothesis in the test simulation. Times are in seconds. The key press and the acquisition of the second word come from Section 5.5; the trace lifetime is the S component of Section 5.4.", [46, 12, 20, 16])

des = [("D1", "speeded (1.0 s deadline), words side by side"), ("D2", "untimed, words side by side; response time"), ("D3", "untimed, words side by side"),
       ("D4", "untimed, one word then the other at fixation 2 s later, under suppression"), ("D5", "untimed, both words at fixation, under suppression"), ("D6", "untimed, picture pairs at fixation")]
def dfmt(d, h): return f"{exd(d, h):.0f} ms" if d == "D2" else f1(exd(d, h))
des_rows = [[k, lab, dfmt(k, "C"), pc(rej(k, "C"), 1), dfmt(k, "B-lexical"), pc(rej(k, "B-lexical"), 1), dfmt(k, "B-conceptual"), pc(rej(k, "B-conceptual"), 1)] for k, lab in des]
t_des = md_table(["Design", "Task and measure", "C deficit", "C rate", "B-lex. deficit", "B-lex. rate", "B-con. deficit", "B-con. rate"], des_rows,
    "Table 18. The six designs under each hypothesis: the expected deficit of patients against controls (accuracy points, or milliseconds for D2) and the share of 4,000 simulated studies with 20 patients and 20 controls that find a significant deficit (one-sided Welch test, α = 0.05). Rate: share of studies finding the deficit; B-lex. and B-con.: B-lexical and B-conceptual. B effect ε = 0.2 at full severity; controls 85% correct untimed.", [9, 33, 9, 8, 10, 8, 10, 8])

pw_rows = []
for eff in ("0", "0.1", "0.2", "0.3"):
    pw_rows.append([("0 (hypothesis C)" if eff == "0" else eff)] + [pc(pwr("D5", acc, eff, n_), 1) for acc in ("0.85", "0.95") for n_ in (12, 20, 40)])
t_pw = md_table(["ε at full severity", "12 per group, 85%", "20, 85%", "40, 85%", "12 per group, 95%", "20, 95%", "40, 95%"], pw_rows,
    "Table 19. Power of design D5 (both words at fixation, untimed, under suppression) against the B-lexical loss of asymptote ε, for 12, 20 and 40 patients per group, with controls 85% or 95% correct untimed. The row ε = 0 is hypothesis C, where the rate is the false-positive rate. Design D6 under B-conceptual gave the same figures within simulation error.", [20, 13, 10, 10, 13, 10, 10])

# ---------------- text ----------------
md = f"""---
title: "Words in Cortex, Characters in the Cerebellum: Utterance, Inner Speech and the Character Level of Language in the Hybrid Vocabucapillary Design"
subtitle: "Part 3 of 3 (second version: four tiers and the C-versus-B test)"
author: "Debi Prasad Ghosh"
date: "November 2026"
abstract: |
  Parts 1 and 2 of this series built a hybrid design in which language and the other word modes use word-level Vocabucapillary vocabularies and only the action modes use character-level ISET codes. This last part asks where the brain draws the same line. It maps the design onto four tiers: fixed front ends (cochlea, retina), fast orienting maps (the inferior and superior colliculi and brainstem generators), a character level of phoneme and letter strings and motor plans, and word records in cortex, with the thalamus, basal ganglia, hippocampus and cerebellum in control roles. Four hypotheses about cerebellar loops are compared: action only (A), utterance only (U), the character level in both directions (C), or every level including words (B). An immutable C# laboratory supplies the numbers, and an independent Python program reproduced {py_agree} of its checks. English never closes its vocabulary: after ten million word tokens the next token is still new with probability {pc(oov7, 2)}, so a level of primitives below the word is unavoidable. One cerebellar operator learned the forward models of a limb and of articulators running 10/3 times faster. With 60 ms of feedback delay and no forward model, self-paced speech slowed from {f1(uv('granule', 'phonemes_per_second'))} to {f1(uv('none', 'phonemes_per_second'))} phonemes per second and its durations equalized, as in ataxic dysarthria. The cost grows with delay over unit duration, which gives a time-scale rule for where prediction is needed. Reading saccades obey it: with only a linear internal model, landing variability doubled and reading slowed from {wpm_g:.0f} to {wpm_l:.0f} words per minute. In a model of verbal span, slowed covert rehearsal left no deficit under articulatory suppression, whereas shorter-lived phonological traces kept the deficit with an undiminished word-length effect, the pattern reported for cerebellar patients. A is rejected, U holds for utterance but not for verbal memory, and C fits. The test that separates C from B was then simulated as patient studies. Under C, a speeded design found a spurious semantic deficit in {pc(rej('D1', 'C'))} of studies with 20 patients per group and a response-time design in {pc(rej('D2', 'C'))}, while untimed accuracy with both words at fixation kept false positives at {pc(rej('D5', 'C'), 1)}. A B-lexical loss of 20% of the semantic asymptote at full severity was then found in {pc(pwr('D5', '0.85', '0.2', 20))} of studies with 20 patients and {pc(pwr('D5', '0.85', '0.2', 40))} with 40 ({pc(pwr('D5', '0.95', '0.2', 20))} and {pc(pwr('D5', '0.95', '0.2', 40))} with easier items). The bytes of a language model play the role of phonology: an open-vocabulary string level beneath the word.
---

# 1 Introduction

The Vocabucapillary series represents language and action with two-level vocabularies: a small set of fixed primitives and a dynamic vocabulary of units built from them (Ghosh, 2026a, 2026b, 2026h, 2026i). For the body the primitives are motor characters and the units are chunks of control steps, which an invertible sequence embedding (ISET) turns into compact codes (Ghosh, 2024, 2026d). An earlier paper proposed that the cerebellum is such a character-level encoder (Ghosh, 2026e). The hybrid design keeps ISET for the character-level action modes and uses word-level vocabularies for language and the other word modes. Part 1 put both kinds of token into one dense key–value cache (Ghosh, 2026g), building on the word-level study of Ghosh (2026f). Part 2 replaced the dense word entries by sparse word records and moved association into counted product atoms (Ghosh, 2026j), the association atoms proposed by Ghosh (2026c). Records of this kind are trained by sparse backpropagation, in which only the active coordinates of a code receive gradient (Ghosh, 2026k). Parts 1 and 2 left the brain aside. This last part takes it up.

Two questions organise it. The first is whether the non-action modes have no cerebellum or are bound to it in both directions. The second is a refinement put forward in the discussion that led to this paper. Speech does not need spelling. What speech needs is utterance: phonemes or articulatory units, sent from either hemisphere, and these need the cerebellum. The language hemisphere, usually the left, may hold an extra part of language that is unrelated to utterance and does not need the cerebellum. A third question follows from the second. Large language models read characters, in fact bytes. Why should a model of language need a character level at all, if the brain's language does not spell?

This version of the paper adds two things. The mapping now reaches beyond the cerebellum: the cochlea and retina, the inferior and superior colliculi, the thalamus, the basal ganglia and the hippocampus each get a place in a four-tier version of the design (Figure 1, Section 2.1). And the test that the first version proposed for separating C from B is simulated, so that its predictions are numbers.

These questions become hypotheses (Section 3), and a laboratory provides six kinds of numbers for them.

1. What do the primitives below the word buy, and what do they cost? (Section 5.1)
2. Can one cerebellar operator serve both the limb and the articulators? (Section 5.2)
3. What does a missing forward model do to reaching and to self-paced speech, and why does speech suffer more? (Section 5.3)
4. Where should a cerebellar lesion show in verbal working memory, under each hypothesis? (Section 5.4)
5. Does the same rule hold for the eyes during reading? (Section 5.5)
6. What would a patient study that separates C from B find under each hypothesis, and how large must it be? (Section 5.6)

Section 6 sets the hypotheses against the evidence, Section 7 answers the question about characters, and Section 8 draws the consequences for the hybrid design. Figure 1 summarises the mapping that the paper argues for.

![Figure 1. The hybrid design mapped onto the brain in four tiers. Tier 0 front ends supply fixed primitives; Tier 1 orienting maps choose where to look or listen next; Tier 2 holds phoneme and letter strings and motor plans; Tier 3 holds word records. Control roles are on the right. Orange outlines mark cerebellar loops that the evidence of Section 2 supports (solid) or that the time-scale rule of Section 4.4 predicts (dashed). The word level's loop (blue, dashed) is the open question that Section 5.6 turns into a test.](FIG/fig1_mapping.png){{width=6.5in}}

# 2 Evidence: where words and characters live

## 2.1 Four tiers and four control roles

The first version of this paper drew two levels, words and characters. A closer look at the sensory and motor periphery gives four tiers (Figure 1). Tier 0 holds the front ends. The cochlea splits sound into fixed frequency channels, and the retina samples the image through fixed arrays of receptors. The filters of primary visual cortex are learned, but early, and resemble those of a sparse code for natural images (Olshausen & Field, 1996). These are fixed primitives in the strict sense.

Tier 1 holds fast maps that choose where to listen or look. The inferior colliculus is a necessary relay for nearly all ascending and descending auditory information, and it also carries non-auditory signals that serve orienting to sounds (Gruters & Groh, 2012). The superior colliculus selects targets for orienting movements and is needed for covert attention as well (Krauzlis, Lovejoy & Zénon, 2013). Brainstem generators turn the chosen target into a saccade. These maps are pointers, not stores: they decide where the next sample comes from, not what it means. Tier 2 is the character level of this paper: phoneme strings, letter strings and motor plans. Tier 3 holds word records.

Four structures play control roles across the tiers. Beyond relaying, the thalamus shifts and sustains functional interactions within and across cortical areas (Halassa & Kastner, 2017), which is the job of a router between modules. The basal ganglia have been proposed as a central device that settles competition between systems for a limited resource (Redgrave, Prescott & Gurney, 1999); in the hybrid design that is the discrete choice of an atom or a chunk (Part 2). In the speech study of Riecker and colleagues (2005), striatal activity fell as the syllable rate rose while cerebellar activity stepped up, a division between choosing and timing. The hippocampus supports the fast first learning of new words, which cortex consolidates over sleep (Davis & Gaskell, 2009); a dynamic vocabulary needs the same step to add an atom. The cerebellum is the predictor in closed loops (Section 2.6).

## 2.2 Speech in cortex

Hickok and Poeppel (2007) organise speech processing into two streams. A ventral stream maps sound onto meaning for comprehension and is largely bilateral, although the two hemispheres compute differently. A dorsal stream maps sound onto the articulatory networks of the frontal lobe and is strongly left-dominant. The left-dominant part of speech is therefore the sensorimotor route between heard and spoken phonological forms, not comprehension as such. Articulatory planning has its own critical region: all 25 of Dronkers' (1996) patients with apraxia of speech had lesions of the left precentral gyrus of the insula, which was spared in all 19 patients without it. In the DIVA model (Guenther, 2016), speech is driven by learned feedforward commands that auditory and somatosensory feedback correct, and the cerebellum contributes to the feedforward path. The articulators themselves are midline organs driven from both motor cortices.

In the terms of this series, the ventral stream links phonological strings to word records, and the dorsal stream links the same strings to articulatory units. The strings, about ten phonemes per second, form the character level of speech. The word records, about 2.5 words per second, form the word level.

## 2.3 The cerebellum in speech and timing

Cerebellar disease produces ataxic dysarthria. In the acoustic study of Kent, Netsell and Abbs (1979) the most consistent abnormality was timing: many segments were prolonged and syllable durations tended toward equality, and the more severe the dysarthria, the more segments were lengthened. In fMRI, Riecker and colleagues (2005) had participants repeat syllables at 2 to 6 Hz. Cortical motor areas rose linearly with rate, whereas both cerebellar hemispheres showed a step-like increase at about 3 Hz, a rate the authors related to the clinical observation that syllable repetition in cerebellar disorders does not fall below about 3 Hz. Ackermann (2008) reviews these and other cerebellar contributions to speech production and perception. Timing extends beyond speech. In Ivry and Keele's (1989) study, patients with cerebellar lesions were the only group impaired both in the regularity of repetitive tapping and in judging the duration of intervals, while their judgements of loudness were normal.

## 2.4 The cerebellum in eye movements

Saccades last a few tens of milliseconds, less than the delay of visual feedback, so brainstem circuits steer them with internal feedback and the cerebellum keeps them accurate. After ablation of the oculomotor vermis (lobules VI and VII) with the deep nuclei spared, monkeys made hypometric saccades whose amplitude varied two to five times more from trial to trial, and they could no longer adapt saccade amplitude (Takagi, Zee & Tamargo, 1998). Reading is a sequence of such saccades. The eyes move from word to word in saccades of about seven to nine letters, with fixations of about a quarter of a second, and tend to land between the beginning and the middle of a word (Rayner, 1998). Oculomotor control is an action mode whose units are about the size of a word.

## 2.5 The cerebellum beyond articulation

Desmond and colleagues (1997) compared a verbal working-memory task with a task in which participants silently repeated letters at the same rate without remembering them. The superior cerebellum (HVI and superior HVIIA) showed the load effect in both tasks. The right inferior hemisphere (HVIIB) showed it only in the memory task. The authors related the superior regions to the frontal articulatory system and HVIIB to the phonological store in temporal and parietal cortex. Covert articulation therefore engages the cerebellum, and so does something in verbal memory that is not articulation.

Lesion studies point the same way. Ravizza and colleagues (2006) tested 15 patients with cerebellar lesions. Verbal span was lower than in controls while spatial span was not. On immediate serial recall the patients showed word-length and articulatory-suppression effects comparable to those of controls, and their deficit was not eliminated by suppression. The verbal deficit was larger after a 6 s delay and scaled with symptom and dysarthria severity. The authors concluded that the cerebellum contributes to phonological encoding, or strengthens traces against decay, rather than supporting covert rehearsal directly. Justus and colleagues (2005) found a reduced phonological similarity effect in cerebellar patients, again pointing at the phonological store or phonetic encoding. A single case points the other way. After removal of the right cerebellar hemisphere, the patient of Silveri and colleagues (1998) had a transient, selective verbal short-term memory deficit that the authors placed in the phonological output buffer of rehearsal.

Prediction in comprehension also involves the cerebellum. Repetitive TMS over the right cerebellum slowed the predictive looks that listeners make toward the object a verb predicts (Lesage et al., 2012). Prediction may run through production (Pickering & Garrod, 2013). When readers repeatedly said the syllable /ta/, the N400 expectation effect on the article before a predictable noun disappeared, while tongue tapping and listening to the syllable left it intact (Martin et al., 2018). Beyond language, cerebellar lesions can produce a cerebellar cognitive affective syndrome (Schmahmann & Sherman, 1998). The patient of Fiez and colleagues (1992) performed excellently on standard tests of memory, intelligence, frontal function and language after right cerebellar damage, but showed profound deficits in practice-related learning and error detection.

## 2.6 One operator in many closed loops

The cerebellum holds about 80% of the brain's neurons (Azevedo et al., 2009). Its circuit is the same across its surface. Mossy fibres from the pontine nuclei drive a vast, sparse granule-cell layer; Purkinje cells read the granule code through parallel fibres; climbing fibres carry an error signal that changes the parallel-fibre synapses of active cells (Marr, 1969; Albus, 1971). In the monkey, cerebellar regions form closed loops with the cortical areas that project to them, motor and prefrontal alike (Kelly & Strick, 2003). The circuit can learn forward models, which predict the consequence of a command, and inverse models (Wolpert, Miall & Kawato, 1998). A forward model can act as a Smith predictor, which removes a feedback delay from a control loop by predicting the current state from the commands already sent (Smith, 1957; Miall et al., 1993). Ito (2008) extended the idea to thought: internal models of mental objects that the prefrontal cortex manipulates.

In Vocabucapillary terms, the granule layer forms a sparse positive record over a large fixed vocabulary of cells, each of which sums a few mossy inputs. The Purkinje readout is a coefficient score of that record, and the climbing-fibre update touches only the weights of active cells, which is the sparse pullback on the active support of Ghosh (2026k). Theory places the best number of inputs per granule cell at a few, close to the anatomical four (Litwin-Kumar et al., 2017; Billings et al., 2014).

## 2.7 Text is a cultural layer

Reading is too recent for evolution to have shaped circuits for it. It recycles a region of left ventral occipitotemporal cortex, the visual word form area, whose prior function suits it (Dehaene & Cohen, 2007). Letters therefore sit beside the phonological strings as a second character level, learned rather than evolved and mapped onto phonology. Writing is an action mode of the hand.

# 3 Four hypotheses

Table 1 states the hypotheses and what each predicts after a cerebellar lesion. All agree on overt speech, so overt speech cannot separate them. They differ on covert articulation, on verbal memory once articulation is blocked, and on semantics without time pressure. U is the hypothesis put forward before this paper. C keeps U's claim about utterance and adds the strings that are heard and held. In the hybrid design, C says that one predictor serves the character level in both directions, while word records go without one. B says that word records also have cerebellar partners. It comes in two forms: B-lexical gives loops to word records only, and B-conceptual gives them to all semantic records, so that judgements about pictures would suffer too.

The four tiers suggest a rule through which all the hypotheses can be read. Section 5.3 shows that the cost of losing a forward model grows with the feedback delay measured in units of the movement's own duration. Prediction is therefore needed wherever units are short relative to the loop: phonemes, saccades and fine timing. Generalised in this way, C says that the cerebellum serves the fast units of every modality and not word records, which last several hundred milliseconds.

{t_hyp}
The laboratory tests the parts of these hypotheses that can be computed. Sections 5.2 and 5.3 test what a forward model does for utterance, which all the hypotheses share. Section 5.4 tests the verbal-memory predictions that separate A, U and C. Section 5.5 applies the time-scale rule to reading saccades. Section 5.6 simulates the patient studies that would separate C from B.

# 4 Formulation

## 4.1 Effectors and loops

Each effector is a chain of degrees of freedom. Degree i has position $p_i$, velocity $v_i$ and a bounded command $u_i$, and obeys

$$\\dot v_i = \\frac{{u_i}}{{1 + |v_i| / (V_0 \\lambda)}} - 2\\zeta\\omega v_i - \\omega^2 p_i - \\gamma\\omega^2 \\sin p_i - c\\,\\omega^2 p_{{i-1}}^2 p_i, \\qquad \\omega = 2\\pi\\lambda. \\quad\\quad\\quad (1)$$

The first term is a Hill-type force–velocity relation. It is followed by damping, passive stiffness, a gravity-like term and an interaction with the neighbouring degree of freedom (ζ = 0.3, γ = 0.5, c = 0.8, $V_0$ = 2). The limb has seven degrees of freedom and time scale λ = 1. The articulators have six and λ = 10/3, so the same dynamics run 10/3 times faster. Commands are bounded by 400λ², and integration is semi-implicit Euler with a 5 ms step.

The controller sends a posture-holding feedforward command plus proportional–derivative feedback on its estimate of the state:

$$u = -P(r) + K_p\\,(r - \\hat p) + K_d\\,(\\dot r - \\hat v), \\qquad K_p = (w\\lambda)^2, \\quad K_d = 2\\zeta_c w\\lambda, \\quad\\quad\\quad (2)$$

where P(r) is the passive force of Equation 1 at rest at the reference r, so that −P(r) holds the posture. Observations arrive D steps late with sensory noise, and commands carry 2% multiplicative motor noise. Without a forward model, the estimate is the delayed observation. With one, the estimate is the delayed observation rolled forward D steps through the model with the commands sent since, which makes the controller a Smith predictor. The bandwidth w and damping $\\zeta_c$ are chosen from a grid of 27 pairs to minimise tracking error on a separate set of reaches, so every loop is compared at its best.

## 4.2 The cerebellar operator

A forward model has one microzone per degree of freedom. Its mossy inputs are $x = (p_i, v_i, u_i, p_{{i-1}}, v_{{i-1}})$, standardised as $z_k = x_k / s_k$. Granule cell j sums K of them with random weights and fires above a threshold $\\theta_j$, set so that the cell is active on a fraction f of calibration samples:

$$a_j = \\max\\Big(0,\\ \\sum_{{k=1}}^{{K}} W_{{jk}}\\, z_{{\\pi_j(k)}} - \\theta_j\\Big) \\big/ g_j, \\qquad \\hat a_i = b + \\beta^{{\\top}} z + \\gamma^{{\\top}} a. \\quad\\quad\\quad (3)$$

Here $g_j$ is the RMS of the cell's rectified activity. The term $\\beta^{{\\top}} z$ is the nuclear pathway, linear in the mossy inputs. The term $\\gamma^{{\\top}} a$ is the Purkinje pathway, a coefficient score of the sparse positive record a. The readout (b, β, γ) minimises squared error plus αN times its squared norm (α = 10⁻⁶, N training samples). This ridge solution is the fixed point of the climbing-fibre delta rule with weight decay (Appendix A). The delta rule itself,

$$\\gamma_j \\leftarrow \\gamma_j + \\eta_e\\, e\\, a_j / (1 + \\lVert(z, 1, a)\\rVert^2), \\quad\\quad\\quad (4)$$

changes only the weights of active cells. Training data come from exploration: the effector is driven toward random targets that change every 0.25 time units, with feedback of random bandwidth plus Ornstein–Uhlenbeck noise.

## 4.3 Self-paced utterance

Each of the 39 ARPAbet phonemes of the CMU Pronouncing Dictionary is a fixed random target in the six-dimensional articulator space, drawn uniformly in ±0.6. A word is the sequence of targets of its first listed pronunciation. Gesture k moves along a minimum-jerk path from target k−1 to target k over a planned time

$$T_k = (T_a + T_b\\, d_k) / \\lambda, \\quad\\quad\\quad (5)$$

where $d_k$ is the RMS distance between the two targets, $T_a$ = 0.12 and $T_b$ = 0.45. The speaker moves on to the next gesture when the planned time has passed and the estimated position is within 0.08 of the target, or after 1 s. The pacing is set so that the intact loop speaks at about the phoneme rate of English. A speaker without a forward model knows the target only from delayed feedback, so it waits.

## 4.4 Time scale

Equation 1 is invariant under a change of time scale. Write τ = λt and $\\tilde u = u/\\lambda^2$. Then the articulators in τ obey the limb's equations, and the gains, command bound, sensory noise and pacing of Equations 2 and 5 transform the same way. A delay of D seconds for an effector with time scale λ is therefore equivalent to a delay of λD for the limb (Appendix A, Proposition 1). What matters is delay measured in the effector's own time, or equivalently delay over the duration of its units. Speech at 10 phonemes per second with a 60 ms loop has a ratio near 0.6. A word-level process at 2.5 words per second with the same loop has a ratio of {f2(word_ratio)}.

## 4.5 The phonological loop

Verbal span is modelled with decay and rehearsal in the spirit of Baddeley, Thomson and Buchanan (1975). Words arrive one per second. A trace survives L·exp(0.25g) seconds after its last refresh, with L = 3.5 s and g a standard normal draw per list. Rehearsal is cumulative: after each new word the rehearser starts again from the first item, refreshing each living item at the end of its rehearsal. One rehearsal takes the word's articulation time plus 50 ms. Recall starts one second after the last word and takes 0.5 s per item in order, by a non-spoken response, and an item is recalled if its trace is alive when its turn comes. Under articulatory suppression there is no rehearsal. The articulation times come from the loop of Section 4.3, with the learned forward model (intact) or without one (lesioned).

A lesion can enter this loop in four ways:

- U: covert rehearsal runs at the lesioned articulation times, assuming, as the account of Baddeley and colleagues does, that covert rehearsal runs at the overt rate.
- E: 8% of words fail to enter the store.
- S: traces live 0.8 times as long.
- C: U and S together.

Hypothesis A predicts no change. Two read-outs are reported. Span is the list length recalled perfectly half the time, interpolated, from 2,000 lists per length between 2 and 10. The item share is the share of words recalled from lists of five, which is closer to the immediate serial recall measure of Ravizza and colleagues. All models use the same random lists.

## 4.6 Reading saccades

The eye has one degree of freedom and time scale λ = 5, so that a saccade of five characters lasts about 30 ms under Equation 5, with one character equal to 0.01 position units. The visual feedback delay is 60 ms, longer than a saccade. Lines of eleven words are drawn by frequency from the lexicon and set with one space between words, and each saccade aims at the centre of the next word. A saccade ends by the rule of Section 4.3, with a tolerance of half a character on the estimated position. It lands outside its word when its error exceeds half the word's length plus half a space. The eye then makes a corrective saccade after a latency of 150 ms. The time to acquire a word is the saccade's duration, plus the latency and the corrective saccade after a miss; each word is then fixated for 200 ms of lexical processing.

Four internal models are compared: the exact equations; the learned granule model, standing for an intact cerebellum; the linear model alone, standing for the internal model of the brainstem and the cerebellar nuclei once the cerebellar cortex is lost, as in the vermal lesions of Section 2.4; and none. Gains are tuned for each, as in Section 4.1. A key press is a limb gesture of about 0.2 rad RMS that must end within 0.02 of the key.

## 4.7 The test that separates C from B

A semantic relatedness judgement follows the exponential speed–accuracy function of the response-signal literature (Wickelgren, 1977; McElree & Dosher, 1989):

$$d'(t) = d'_{{\\infty}}\\,\\big(1 - e^{{-\\beta (t - \\delta)}}\\big), \\quad\\quad\\quad (6)$$

where the asymptote $d'_{{\\infty}}$ is the quality of the semantic records, β the rate and δ the intercept, before which d′ is zero. With two equally likely answers, accuracy is Φ(d′/2). The intercept collects visual encoding (0.30 s), the key press, and, when the two words are side by side, a 0.20 s fixation of the first word and the acquisition of the second. Controls are 85% correct without time pressure (an asymptote of {f2(g('N05.asymptote_main'))}; 95% in a second set, {f2(g('N05.asymptote_ceiling'))}), with a between-subject SD of 0.35 in the asymptote and β = 4 per second. Response times add a decision time with subject mean 0.70 s (SD 0.12 s across subjects) and a trial-to-trial coefficient of variation of 0.4.

A patient has a severity s, uniform between 0.2 and 1, and every cerebellar cost moves linearly with s from its intact value to its full lesion value. These are the key press without a forward model (the smaller of the limb's two lesion costs in Section 5.5), the eye with its linear model alone, and phonological traces living 0.8 times as long (S of Section 5.4). Hypothesis C stops there. B also multiplies the asymptote by (1 − εs), for word pairs under B-lexical and for word and picture pairs under B-conceptual. The size of ε is unknown, so it is swept from 0 to 0.3.

Six designs are compared (Table 18).

- D1 is speeded, with a 1.0 s deadline and the words side by side.
- D2 is untimed with the words side by side, and response time is the measure.
- D3 is the same with accuracy as the measure.
- D4 shows one word at fixation and the other 2 s later, under articulatory suppression. Half of the first words are held phonologically and are lost if their trace dies.
- D5 shows both words at fixation, untimed, under articulatory suppression.
- D6 shows picture pairs at fixation, untimed.

Each subject does 60 trials. A simulated study compares 20 patients with 20 controls (also 12 and 40) by a one-sided Welch test at α = 0.05, and 4,000 studies give each rate. All hypotheses share their random numbers, so their differences are not sampling noise.

# 5 Results

## 5.1 Primitives of the spoken and the written word

Table 2 counts the units. A frequency-weighted English word has {f2(g('N00.letters_per_word'))} letters, {f2(g('N00.phonemes_per_word'))} phonemes and {f2(g('N00.syllables_per_word'))} syllables. At 2.5 words per second, speech carries {f2(g('N00.phonemes_per_second'))} phonemes per second, and the same words as text {f2(g('N00.bytes_per_second'))} bytes per second.

{t_units}
Table 3 shows why a level below the word cannot be avoided. Words drawn by frequency from the full list kept bringing new words. After a thousand tokens almost half the next tokens were new. After ten million tokens, about 1,100 hours of continuous speech, a listener knew {n0(g('N00.distinct_N10000000'))} words and one token in {n0(1 / oov7)} was still new. Because the list stops at its rarest entries, these rates are lower bounds. A vocabulary of word units alone would fail at every new word. A fixed set of primitives can spell or pronounce any word, including words never met before: 39 phonemes for speech and 26 letters for text.

{t_ov}
Table 4 shows the other side. The strings below the word do not identify it on their own. More than a third of word tokens share their phoneme string with another word ({pc(g('N00.homophone_token_share'), 1)}), and {pc(g('N00.up_phon_not_unique_tokens'), 1)} are still not unique when their last phoneme ends, because a longer word continues them: *in* continues as *inside*. Letters are hardly better by this measure ({pc(g('N00.up_let_not_unique_tokens'), 1)}), although they do separate many homophones (*to*, *two*, *too*). Listeners resolve this with the word level and the context that follows, as cohort models of word recognition require (Marslen-Wilson & Welsh, 1978). The two levels therefore need each other in both directions. Word records need strings for the open vocabulary, and strings need word records to be resolved.

{t_amb}
Table 5 counts the work of attention at each resolution. One minute of speech is {n0(g('N00.pairs_words'))} causal pairs at word resolution, {n0(g('N00.pairs_phonemes'))} at phoneme resolution and {n0(g('N00.pairs_articulatory'))} at the 5 ms resolution of articulatory control. This is why the hybrid design attends over words and leaves the fine resolution to local predictors.

{t_pairs}
![Figure 2. Primitives below the word. (a) The probability that the next word token is new against the number of tokens heard; labels give the number of distinct words known. (b) Units per second at 2.5 words per second. (c) Ambiguity of phoneme and letter strings as a share of word tokens.](FIG/fig2_primitives.png){{width=6.5in}}

## 5.2 One cerebellar operator for every loop

The same microzone recipe learned the forward models of both effectors (Table 6, Figure 3). The nuclear pathway alone, a linear model, left an acceleration error of {f2(lin_limb)} (limb) and {f2(lin_art)} (articulators) of the acceleration SD. With 1,024 granule cells per microzone the error fell to {f2(g_limb)} and {f2(g_art)}, and the state predicted 60 ms ahead improved {f1(fmv('limb', 'no prediction', 'position_error_60ms_rad') / fmv('limb', 'granule layer, 1024', 'position_error_60ms_rad'))}-fold (limb) and {f1(fmv('articulators', 'no prediction', 'position_error_60ms_rad') / fmv('articulators', 'granule layer, 1024', 'position_error_60ms_rad'))}-fold (articulators) over holding the delayed observation. The gain from 512 to 1,024 cells was small. Granule cells were active on about {pc(g('N01.articulators_active_share'))} of samples, the coding level that was set.

{t_fm}
Table 7 varies the two structural parameters. One input per cell gave almost no gain over the linear pathway ({f3(g('N01.sweep_K1_acc_error'))}). Two to five inputs were all good, with the best at three ({f3(g('N01.sweep_K3_acc_error'))}) and four close behind ({f3(g('N01.sweep_K4_acc_error'))}). A sparse code was needed: active fractions of 0.1 to 0.2 worked best ({f3(g('N01.sweep_f0.10_acc_error'))} and {f3(g('N01.sweep_f0.20_acc_error'))}), whereas half the cells active gave back most of the gain ({f3(g('N01.sweep_f0.50_acc_error'))}). The climbing-fibre delta rule (Equation 4) on one microzone reduced the error from {f3(g('N01.delta_epoch1'))} after one epoch to {f3(g('N01.delta_epoch8'))} after eight, below the nuclear pathway ({f3(g('N01.delta_linear'))}) but still above the least-squares fixed point ({f3(g('N01.delta_ridge'))}) that it approaches.

{t_sw}
![Figure 3. One cerebellar operator. (a) Acceleration error of learned forward models against granule cells per microzone; dashed lines show the nuclear pathway alone. (b) Inputs per granule cell and (c) coding level, for the articulators. (d) The climbing-fibre delta rule against its least-squares fixed point.](FIG/fig3_operator.png){{width=6.5in}}

## 5.3 Loops with delayed feedback

At 60 ms of delay, the exact forward model kept both effectors within {pc(max(ex60_l / tv('limb', 0, 'exact', 'tracking_rms'), ex60_a / tv('articulators', 0, 'exact', 'tracking_rms')) - 1)} of their no-delay accuracy (Table 8). Without a forward model, the best tuned loop tracked the limb with {f4(none60_l)} rad, {f1(none60_l / ex60_l)} times the error with the exact model, and the articulators with {f4(none60_a)} rad, {f1(none60_a / ex60_a)} times. The learned granule model recovered most of the loss for the limb ({f4(gr60_l)}) and much of it for the articulators ({f4(gr60_a)}); the nuclear pathway alone recovered less ({f4(nu60_l)} and {f4(nu60_a)}). The articulators suffer more because their 60 ms is 200 ms of limb time (Section 4.4). The laboratory confirms the scaling: the articulators at 20 ms tracked with {f4(tv('articulators', 20, 'none', 'tracking_rms'))} rad, and the limb at 60 and 80 ms with {f4(tv('limb', 60, 'none', 'tracking_rms'))} and {f4(tv('limb', 80, 'none', 'tracking_rms'))}, which bracket the equivalent 66.7 ms (interpolated: {f4(limb_at_667)}).

{t_trk}
In self-paced speech (Table 9, Figure 4) the intact loop spoke at {f2(uv('granule', 'phonemes_per_second'))} phonemes per second, within {pc(uv('granule', 'phonemes_per_second') / g('N02.natural_phoneme_rate') - 1)} of English at 2.5 words per second. Its gesture durations followed the articulatory distance (correlation {f3(uv('granule', 'duration_distance_correlation'))}), so long gestures took {f2(uv('granule', 'duration_contrast'))} times as long as short ones. The learned model ended gestures with a larger error than the exact equations ({f3(uv('granule', 'mean_error_at_end'))} against {f3(uv('exact', 'mean_error_at_end'))}), but always within tolerance, so its timing was the same. Without a forward model the speaker slowed to {f2(uv('none', 'phonemes_per_second'))} phonemes per second, and its gestures became {f2(uv('none', 'mean_gesture_ms') / uv('granule', 'mean_gesture_ms'))} times longer. Their durations no longer followed the distance (correlation {f3(uv('none', 'duration_distance_correlation'))}) and nearly equalized (contrast {f2(uv('none', 'duration_contrast'))}), and {pc(1 - uv('none', 'on_target_share'))} of gestures ended off target. The model thus reproduces the two timing signs of ataxic dysarthria in Kent and colleagues' (1979) description, prolonged segments and syllable durations tending toward equality. It does not reproduce lower variability: the coefficient of variation rose slightly ({f2(uv('granule', 'duration_cv'))} to {f2(uv('none', 'duration_cv'))}), so the durations equalize in their dependence on content, not in their spread.

{t_utt}
Table 10 retunes both loops at every delay. With the exact model the rate never changed. Without one, the slowing grew with delay: {f2(slow20)} at 20 ms, {f2(slow40)} at 40 ms and {f2(slow60)} at 60 ms. Beyond 60 ms the tuned bandwidth halved again, each approach became slower, and the dependence of duration on distance partly returned (contrast {f2(min(rv(d, 'contrast_none') for d in (80, 100, 120)))}–{f2(max(rv(d, 'contrast_none') for d in (80, 100, 120)))}, correlation {f2(min(rv(d, 'corr_none') for d in (80, 100, 120)))}–{f2(max(rv(d, 'corr_none') for d in (80, 100, 120)))}). Expressed as delay over gesture duration, the slowing was {pc(slow20 - 1)} at a ratio of {f2(ratio20)}. A word-level loop at 2.5 words per second with the same 60 ms delay has a ratio of {f2(word_ratio)}, below that point. If word-level processing were a closed loop of this kind, a forward model would buy it less than a tenth in speed, whereas the phoneme level at the same delay loses nearly half its rate without one. This is a reason, not a proof, for the line the hybrid design draws: prediction is indispensable where units are short relative to the loop.

{t_rv}
![Figure 4. Loops with delayed feedback. (a) Tracking error against delay for the limb and the articulators, with the exact model and with none; markers show the learned granule model and the nuclear pathway at 60 ms. (b) Self-paced speaking rate against delay. (c) The first articulator during the first four words of the first utterance (“{" ".join(w["word"] for w in exw)}”) at 60 ms; targets are drawn on the time base of the run with the learned model. (d) Contrast between long and short gesture durations.](FIG/fig4_loops.png){{width=6.5in}}

## 5.4 The phonological loop with and without the cerebellum

The word pools and their articulation times are in Table 11. Without a forward model, articulation took {f2(g('N03.short_dur_ratio'))} times as long for one-syllable words and {f2(g('N03.long_dur_ratio'))} times for three-syllable words.

{t_dur}
The intact loop produced a span of {f2(fl(I_sp['short_quiet']))} short and {f2(fl(I_sp['long_quiet']))} long words, a word-length effect of {f2(fl(I_sp['word_length_effect_quiet']))} items (Table 12, Figure 5). Under articulatory suppression span fell to {f2(fl(I_sp['short_suppressed']))} and the word-length effect vanished ({f2(fl(I_sp['short_suppressed']) - fl(I_sp['long_suppressed']))}), as in the classic findings with visual presentation (Baddeley et al., 1975) that the model was built to reproduce.

{t_sp}
The four lesion models separate cleanly (Tables 12 and 13). Slowed rehearsal (U) lowered span in quiet by {f2(fl(U_sp['deficit_quiet_short']))} and left it untouched under suppression, because a lesion that acts only through rehearsal has nothing to act on when rehearsal is blocked. U also shrank the word-length effect, from {f2(fl(I_sp['word_length_effect_quiet']))} to {f2(fl(U_sp['word_length_effect_quiet']))} in span and from {f3(fl(I_it['word_length_effect_quiet']))} to {f3(fl(U_it['word_length_effect_quiet']))} in items, and shrank the suppression effect from {f2(fl(I_sp['suppression_effect_short']))} to {f2(fl(U_sp['suppression_effect_short']))}. Shorter-lived traces (S) did the opposite. The deficit stayed under suppression ({f2(fl(S_sp['deficit_suppressed_short']))} in span, against {f2(fl(S_sp['deficit_quiet_short']))} in quiet), and in items it was even larger there (deficit ratio {f2(ratio(S_it))}). The word-length effect grew to {f3(fl(S_it['word_length_effect_quiet']))} in items, while in span it was nearly unchanged ({f2(fl(S_sp['word_length_effect_quiet']))}), and the suppression effect was {f2(fl(S_sp['suppression_effect_short']))} in span and {f3(fl(S_it['suppression_effect_short']))} in items, against {f2(fl(I_sp['suppression_effect_short']))} and {f3(fl(I_it['suppression_effect_short']))} intact. Encoding loss (E) fell between the two: its deficit persisted but halved under suppression (ratio {f2(ratio(E_it))}), and its word-length effect shrank slightly. C, which combines U and S, kept a deficit under suppression (ratio {f2(ratio(C_it))}) and an item word-length effect at the intact value ({f3(fl(C_it['word_length_effect_quiet']))}), but halved the span word-length effect and reduced the suppression effect.

{t_it}
The pattern did not depend on the size of the storage-side change (Table 14) or on the trace lifetime (Table 15). Across both tables every S model kept a deficit ratio of at least {f2(min(S_ratios))} with an item word-length effect at or above the intact value, every E model a ratio between {f2(min(E_ratios))} and {f2(max(E_ratios))}, and U a ratio of exactly zero. Mixing U into a storage-side change always pulled the ratio below one (at most {f2(max(UX_ratios))}).

{t_var}
{t_ds}
![Figure 5. The phonological loop. (a) Span under five lesion models for short and long words, in quiet and under articulatory suppression (suppr.). (b) The diagnostic plane for lists of five: the deficit under suppression over the deficit in quiet against the change in the word-length effect; triangles are variants of Table 14. The upper right quadrant is the pattern Ravizza and colleagues (2006) reported, in which the deficit persists under suppression and the word-length effect is not reduced. (c) The deficit ratio across trace lifetimes.](FIG/fig5_phonological_loop.png){{width=6.5in}}

## 5.5 Reading saccades

Table 16 and Figure 6 show the eye. With the exact equations the eye landed within {f2(emv('exact', 'landing_error_sd_chars'))} characters (SD) of the word centre and never left its word. The learned granule model, trained on generic exploration rather than on reading, landed with an SD of {f2(emv('granule', 'landing_error_sd_chars'))} characters and left its word on {pc(emv('granule', 'landing_outside_word'))} of saccades. Human landing sites for a given launch site and word length are close to normal, with SDs of about 1.3 to 1.6 letters (McConkie et al., 1988); the model's spread, pooled over all saccades, is about one and a half times as large. With the corrections a word took {emv('granule', 'time_per_word_ms'):.0f} ms, or {wpm_g:.0f} words per minute.

With the linear model alone, saccades took slightly longer ({f1(emv('linear', 'saccade_ms'))} against {f1(emv('granule', 'saccade_ms'))} ms) and their gain rose from {f2(emv('granule', 'gain_mean'))} to {f2(emv('linear', 'gain_mean'))}. The gain also varied {f2(g('N04.eye_gain_sd_ratio_linear'))} times as much, {pc(emv('linear', 'landing_outside_word'))} of saccades left their word, and reading fell to {wpm_l:.0f} words per minute. The increase in variability lies within the two- to five-fold range after the vermal lesions of Takagi and colleagues, but the bias does not match: their saccades became hypometric, whereas the model's overshoot.

Without any internal model the eye waited for vision, so each saccade took {f1(emv('none', 'saccade_ms'))} ms. It left its word less often ({pc(emv('none', 'landing_outside_word'))}) but read barely faster ({emv('none', 'words_per_minute'):.0f} against {wpm_l:.0f} words per minute). The key press took {key_g:.0f} ms with the granule model, {key_l:.0f} ms with the linear model alone and {key_n:.0f} ms without a forward model. Saccades, like phonemes, are units short enough relative to their loop that losing the cerebellar model costs both time and accuracy.

{t_eye}
![Figure 6. Reading saccades. (a) Landing error relative to the centre of the target word for the exact equations, the learned granule model and the linear model alone; the shaded band is ±3 characters, about half a typical word, and the exact model's narrow peak is cut off. (b) Time per word, split into the saccade, the corrections after landing outside the word and the 200 ms lexical fixation, with words per minute above each bar. (c) Key-press time (mean and SD).](FIG/fig6_reading.png){{width=6.5in}}

## 5.6 The test that separates C from B

Table 17 lists what a cerebellar lesion adds under every hypothesis. At full severity the key press is {g('N05.key_lesion_ms') - g('N05.key_intact_ms'):.0f} ms longer and the second word of a side-by-side pair is acquired {g('N05.acquire_lesion_ms') - g('N05.acquire_intact_ms'):.0f} ms later. A first word held phonologically for 2 s is lost {pc(g('N05.trace_loss_full'), 1)} of the time instead of {pc(g('N05.trace_loss_control'), 1)}.

{t_comp}
Table 18 gives the expected deficits and the share of studies that find one. Under C, the speeded design D1 loses {f1(exd('D1', 'C'))} points of accuracy, because the patients' longer intercept leaves them less time before the deadline. With 20 patients per group, {pc(rej('D1', 'C'))} of studies find a significant deficit, which a reader would take as evidence for B. The response-time design D2 finds patients {exd('D2', 'C'):.0f} ms slower, and does so in {pc(rej('D2', 'C'))} of studies under every hypothesis, because response time does not depend on the asymptote at all. The sequential design D4 raises false positives to {pc(rej('D4', 'C'), 1)} through the trace component. The untimed accuracy designs with the words or pictures in view, D3, D5 and D6, keep C at the nominal rate ({pc(rej('D3', 'C'), 1)}, {pc(rej('D5', 'C'), 1)} and {pc(rej('D6', 'C'), 1)}). In this model the display matters less than the measure: D3, with a saccade between the words, leaks nothing into untimed accuracy. Showing both words at fixation under suppression guards against leaks the model does not contain, such as misreading after a misplaced fixation or phonological recoding.

{t_des}
Under B-lexical with ε = 0.2, the untimed designs show a deficit of {f1(exd('D5', 'B-lexical'))} points, which D5 detects in {pc(rej('D5', 'B-lexical'))} of studies with 20 patients per group. D6 separates the two forms of B. It finds the deficit under B-conceptual ({pc(rej('D6', 'B-conceptual'))} of studies) and stays at the nominal rate under B-lexical ({pc(rej('D6', 'B-lexical'), 1)}).

Table 19 gives the power of D5. With controls at 85% correct, ε = 0.2 reaches {pc(pwr('D5', '0.85', '0.2', 40))} power with 40 patients per group, short of the usual 80%. ε = 0.3 reaches {pc(pwr('D5', '0.85', '0.3', 20))} with 20 patients and {pc(pwr('D5', '0.85', '0.3', 40))} with 40. Easier items help in this model. With controls at 95%, ε = 0.2 reaches {pc(pwr('D5', '0.95', '0.2', 40))} with 40 patients and ε = 0.3 reaches {pc(pwr('D5', '0.95', '0.3', 20))} with 20, because binomial noise falls faster than the deficit as accuracy approaches the ceiling.

Both confounds depend on the design's settings. D1's false-positive rate falls from {pc(ddlv(0.9, 'rejection_rate_under_C_n20'))} at a 0.9 s deadline to {pc(ddlv(1.5, 'rejection_rate_under_C_n20'), 1)} at 1.5 s, still above the nominal 5%, and D4's from {pc(seqv(1.0, 'rejection_rate_under_C_n20'), 1)} when every first word is held phonologically to {pc(seqv(0.0, 'rejection_rate_under_C_n20'), 1)} when none is.

{t_pw}
![Figure 7. The test that separates C from B. (a) Share of simulated studies with 20 patients per group that find a significant deficit, for the six designs under C, B-lexical and B-conceptual (ε = 0.2); the dotted line is α. (b) Power of design D5 against the number of patients per group for three sizes of the B-lexical effect (solid: controls 85% correct; dashed: 95%), and its false-positive rate under C. (c) False-positive rate of the speeded design D1 under C against the deadline.](FIG/fig7_test.png){{width=6.5in}}

# 6 The hypotheses against the evidence

Table 20 sets the hypotheses against the evidence of Section 2, with the model results that bear on each line.

{t_ev}
**A is rejected.** Silent rehearsal without a memory load engages the superior cerebellum, and cerebellar lesions lower verbal span. Neither would happen if the cerebellum served only overt action.

**U holds for utterance and fails for verbal memory.** Everything U says about utterance is supported. Speech at ten phonemes per second with a 60 ms loop needs a forward model (Section 5.3). Without one, speech slows and its durations equalize as in ataxic dysarthria, and the cerebellum's engagement steps up at rates where prediction starts to matter. Silent rehearsal engages the same superior regions as articulation. The single case of Silveri and colleagues fits U. But U predicts that the memory deficit disappears under articulatory suppression and that the word-length effect shrinks. The group of Ravizza and colleagues showed neither, and the right inferior HVIIB of Desmond and colleagues responded to memory load and not to silent repetition.

**C fits.** The storage-side component S produced the group pattern. The articulatory component U produced the single case. The two map onto the inferior and superior regions that Desmond and colleagues separated. C therefore predicts that lesions confined to superior HVI and HVIIA give the U signature (a deficit removed by suppression, a smaller word-length effect, more dysarthria), while lesions of right inferior HVIIB give the S signature (a deficit that persists under suppression, a word-length effect at least as large and, because traces decay faster, a deficit that grows with the retention interval). Ravizza and colleagues' finding that the deficit grew after a 6 s delay agrees with S, though a longer delay also strains rehearsal, so it does not by itself exclude U.

**B is not needed by any of this evidence, and it is not excluded.** Lesage and colleagues' prediction effect involves the meaning of the verb, a word-level matter. But it is timed: the prediction must beat the speech. Martin and colleagues found that lexical prediction disappeared when the production system was occupied. A forward model of production can therefore explain the effect without a cerebellar loop for word records. Fiez and colleagues' patient had excellent standard language but impaired practice-related learning, which B predicts and C, as stated, does not. Section 5.6 turns the decisive test into numbers. It must measure untimed accuracy with the stimuli in view. Under C, speeded and response-time designs find a deficit in most studies, and a delay between the words lets the phonological trace in. With a clean design, C predicts no deficit at all. A B-lexical loss of 20% of the semantic asymptote at full severity then needs about 40 patients per group with easy items ({pc(pwr('D5', '0.95', '0.2', 40))} power), more than any group study of Section 2 tested. Picture pairs then decide between B-lexical and B-conceptual. A second test is to repeat the rTMS prediction study under concurrent syllable production: if cerebellar prediction runs through production, as C requires, suppression should remove the rTMS effect along with the prediction.

What does this say about the hypothesis put forward before this paper? Three of its parts stand. Utterance needs the cerebellum. Speech does not need spelling: utterance and rehearsal run on phoneme strings, and in the model articulation times, not spellings, pace rehearsal. And an extra part of language, the word records, may do without the cerebellum. Two parts need revision. The strongly left-dominant part of speech is the dorsal sensorimotor stream (Hickok & Poeppel, 2007), which serves utterance, whereas comprehension is largely bilateral. More importantly, the cerebellum's role is not limited to utterance: it extends to the phonological strings that are heard and held. The character level of language, not utterance alone, is what has cerebellar partners. Through the time-scale rule the same holds beyond language, for saccades and the timing of intervals.

# 7 Why language models read characters

A speaker can say any word, including one never heard before, because words are built from a closed set of phonemes. A reader can do the same with letters. Table 3 shows why this matters. A word-level vocabulary never closes, and after ten million tokens one token in {n0(1 / oov7)} is still new. A model that only had word units would have no representation for these tokens, for names, or for misspellings. Language models solve the problem as speech does, with a fixed set of primitives below the word. Subword vocabularies are built from characters by merging (Sennrich, Haddow & Birch, 2016). Byte-level vocabularies start from the 256 byte values, so no input is out of vocabulary (Radford et al., 2019), and byte models drop the merged vocabulary altogether (Xue et al., 2022).

The byte level of a language model is therefore not spelling in the sense of the hand that writes. It is the text-world counterpart of the phonological string, the open-vocabulary level beneath the word. The rates are comparable: {f2(g('N00.bytes_per_second'))} bytes per second against {f2(g('N00.phonemes_per_second'))} phonemes per second at the same speaking rate, about {f2(g('N00.bytes_per_second') / g('N00.phonemes_per_second'))} bytes per phoneme. A model trained only on text has no other character level to learn from. Letters are a cultural layer on recycled visual cortex (Dehaene & Cohen, 2007). In the brain, the same open-vocabulary role is played by phonology, which is older than writing. In the terms of Figure 1, a language model has no Tier 0 or Tier 1 for text: its input arrives already as characters, so its byte vocabulary is a fixed Tier 2 alphabet.

Two consequences follow for the hybrid design. First, the string level must be bound to the word level in both directions: strings for new words, and the word level and context to resolve strings that are ambiguous ({pc(g('N00.homophone_token_share'), 1)} of tokens share their pronunciation with another word, and most are not unique when they end). Second, the string level is where the cost of fine resolution sits. A minute of speech is {f1(g('N00.pairs_phonemes') / g('N00.pairs_words'))} times as many attention pairs at phoneme resolution as at word resolution, and {n0(g('N00.pairs_articulatory') / g('N00.pairs_words'))} times as many at 5 ms control resolution. The design should therefore attend over words and leave strings and control to local predictors, which is what the cerebellum appears to do for the brain.

# 8 Consequences for the hybrid design

The neuroscience supports five design rules.

1. **Word records attend; the character level predicts.** Word-level Vocabucapillary records (Part 2) carry meaning and attention. Phonological strings, byte strings and the control streams of the action modes are handled by one kind of local predictor, the operator of Section 4.2: a sparse positive record over fixed random cells, read by a coefficient score and trained by error.
2. **Allocate prediction by delay over unit duration.** A forward model is needed where the loop delay is a sizeable fraction of a unit (Section 5.3): for articulation, for fast limb movement and for the string level during fluent speech or reading. It buys little for units of several hundred milliseconds.
3. **Bind the two levels in both directions.** Production goes from word records to strings to articulatory units. Comprehension and verbal memory go from strings to word records. The predictor serves both, keeping strings alive in memory (the S component) as well as driving articulation (the U component).
4. **Learn by sparse updates.** The climbing-fibre rule changes only active cells, the sparse update that the series proposes for training records (Ghosh, 2026k). Like the delta rule of Section 5.2, it approaches the least-squares readout slowly. A deployed system would solve the readout exactly where it can and keep the online rule for adaptation.
5. **Give each tier and control role its own machinery.** Front ends are fixed encoders, such as filter banks or patch and byte embeddings, learned once if at all. Orienting maps are pointers, not stores: a router that picks where to read next, as the superior colliculus picks the next fixation. Between modules, a thalamus-like router changes which modules talk to each other. A basal-ganglia-like selector makes the discrete choice of an atom or a chunk (Part 2). A hippocampus-like store holds new atoms until they are consolidated into the dynamic vocabulary, which is where a criterion for introducing new atoms (Ghosh, 2026k) would act.

# 9 Limitations

The effectors are toys: a chain with simple dynamics, six articulators standing for the vocal tract, and random phoneme targets with no coarticulation, prosody or auditory feedback. Sensory delays, noise and the pacing rule were chosen, not measured, and the pacing was set so that the intact loop speaks at the English phoneme rate. The phonological loop is a simple decay-and-rehearsal model. Its lesion models U, E and S are parameter changes, not consequences of the cerebellar model, and covert rehearsal is assumed to run at the overt rate. The model's numbers are compared with published group results qualitatively, not fitted to them. The phonological similarity effect, reading beyond the targeting of saccades (word skipping, refixation strategy and parafoveal preview) and the right hemisphere's contributions to prosody are not modelled. Some of the evidence in Section 2 comes from single cases and small groups, and the review was taken from abstracts and the papers named, not from a systematic search. The time-scale argument for word-level processing assumes a closed loop of the same kind, which is itself a hypothesis. The eye has one degree of freedom, and its learned model was trained on generic exploration rather than on reading saccades. The intact landing spread is therefore the model's own, about one and a half times that of human readers, and the bias after the simulated lesion is an overshoot, against the undershoot of vermal lesions. The acceptance window, the correction latency and the fixation time are assumptions. In the test simulation, the speed–accuracy parameters, the single severity that scales every cost linearly, the B effect as a loss of asymptote only, the matched groups and the 60 trials per subject are assumptions. General slowing, attention deficits and fixation instability were not modelled. Power depends on these choices; which designs leak under C depends only on where the cerebellar costs enter. English, one dictionary and one word list were used.

# 10 Conclusion

The brain appears to draw the hybrid design's line one level lower than "action against everything else", inside a four-tier frame of fixed front ends, orienting maps, strings and word records. Word records, the meaning-bearing units of language, live in cortex and may do without the cerebellum. The character level, meaning phonological strings that are planned, articulated, heard and held, has cerebellar partners in both directions. Utterance needs the cerebellum because speech is fast relative to its feedback loop. A missing forward model slows speech by almost half and equalizes its durations. One operator, a sparse positive record read by a coefficient score and trained by error, can serve the limb and the articulators alike. Verbal memory needs the cerebellum beyond rehearsal: only a storage-side component reproduces a deficit that survives articulatory suppression with an undiminished word-length effect. Saccades follow the same rule as phonemes. The test that would decide whether word records also need the cerebellum is now specified with numbers: untimed accuracy with both words in view, which under C finds no deficit and under B-lexical needs about forty patients per group for a 20% loss of semantic asymptote. Spelling is a cultural layer on this character level. A language model's bytes are its counterpart in text: the open-vocabulary level below words that every system of language needs, whether it speaks or reads.

# Appendix A Proofs

**Proposition 1 (time scale).** Let p(t) solve Equation 1 with time scale λ under commands u(t), and define τ = λt, $\\tilde p(\\tau) = p(\\tau/\\lambda)$ and $\\tilde u(\\tau) = u(\\tau/\\lambda)/\\lambda^2$. Then $d\\tilde p/d\\tau = v/\\lambda$ and $d^2\\tilde p/d\\tau^2 = \\dot v/\\lambda^2$. Dividing Equation 1 by λ² gives the same equation with λ = 1 for $\\tilde p$ and $\\tilde u$. The force–velocity term becomes $\\tilde u/(1 + |d\\tilde p/d\\tau|/V_0)$, and each passive term loses its factor λ². The bound 400λ² on u becomes 400 on $\\tilde u$. In Equation 2, dividing by λ² gives the λ = 1 law with the same w and $\\zeta_c$, because $K_p/\\lambda^2 = w^2$ and $K_d/\\lambda^2 \\cdot \\lambda = 2\\zeta_c w$ when velocities are measured in τ. Sensory noise on velocity is scaled by λ, so it is unchanged in τ, and the planned times of Equation 5 are $T_a + T_b d_k$ in τ. A delay D becomes λD in τ. Only the integration step (5 ms in t, 5λ ms in τ), the 1 s timeout of Section 4.3 and the number of degrees of freedom break the equivalence. ∎

**Proposition 2 (the delta rule and its fixed point).** For features $f_t = (z_t, 1, a_t)$, readout θ and error $e_t = y_t - \\theta^{{\\top}} f_t$, the delta rule with weight decay, $\\theta \\leftarrow \\theta + \\eta(e_t f_t - \\alpha\\theta)$, has expected increment $\\eta(\\sum_t f_t y_t - (\\sum_t f_t f_t^{{\\top}} + \\alpha N I)\\theta)/N$ over a pass through N samples. This is zero exactly at the ridge solution $\\theta^\\ast = (F^{{\\top}}F + \\alpha N I)^{{-1}}F^{{\\top}}y$. Since $a_{{tj}} = 0$ for silent cells, each step changes only the coefficients of the active cells and the nuclear and bias terms. ∎

# Appendix B The immutable C# laboratory

The laboratory is a .NET 8 console project without external packages. Domain state lives in sealed records and immutable arrays, every computation is a pure static function, and randomness comes from a SplitMix64 generator implemented as a readonly record struct whose draws return the value and the successor generator. It reuses the core of Parts 1 and 2: the MessagePack reader of the wordfreq English list (Speer, 2022), lexicon sampling and a Cholesky solver. It adds the CMU Pronouncing Dictionary loader, the effectors of Equation 1 (limb, articulators and eye), the granule forward models of Equation 3 with the delta rule, the delayed-feedback loops with Smith-predictor estimation and gain tuning, self-paced utterance and reading saccades, the phonological loop, the speed–accuracy simulation of patient studies, and the special functions behind the Welch test (log-gamma, the incomplete gamma and beta functions). One output boundary writes CSV tables and a JSON file of headline values. Running `dotnet run -c Release` executes the six studies in about five minutes on two cores.

A separate Python program decodes the word list with its own reader and the dictionary with its own loader. With line-for-line ports of the generator it regenerates the N00 accounting, including a vectorized open-vocabulary curve; the exploration data and delayed-observation rollouts; the gain tuning, tracking and self-paced speech with the exact model and without one; the word pools and lesioned articulation times; and every span and item share of the main lesion models. It regenerates the reading text, the eye's gains and every saccade with the exact model and with none, the key presses without a forward model, and the expected deficits and rejection rates of six design cells of the test simulation. The special functions were checked against scipy. With numpy it refits the granule forward models of the limb, the articulators and the eye, whose errors, articulation times and word-acquisition times agreed to rounding. {py_agree} checks passed.

Table: Table 21. Studies of the laboratory.

| Study | Section | Question | Kind of result |
|----------|----------|----------------------------------------------|--------------------|
| N00 | 5.1 | Units per word and per second, homophones, uniqueness points, open vocabulary, attention pairs | Exact counts |
| N01 | 5.2 | Granule forward models of the limb and the articulators; inputs per cell, coding level, delta rule | Fitted models |
| N02 | 5.3 | Reaching and self-paced speech with delayed feedback, with and without forward models | Simulation |
| N03 | 5.4 | Verbal span and item recall under five lesion models, quiet and with articulatory suppression | Monte Carlo |
| N04 | 5.5 | Reading saccades and the key press with four internal models | Simulation |
| N05 | 5.6 | Six designs of the C-versus-B test as simulated patient studies; power and confounds | Monte Carlo |

# References

Ackermann, H. (2008). Cerebellar contributions to speech production and speech perception: Psycholinguistic and neurobiological perspectives. *Trends in Neurosciences, 31*(6), 265–272. https://doi.org/10.1016/j.tins.2008.02.011

Albus, J. S. (1971). A theory of cerebellar function. *Mathematical Biosciences, 10*(1–2), 25–61.

Azevedo, F. A. C., Carvalho, L. R. B., Grinberg, L. T., Farfel, J. M., Ferretti, R. E. L., Leite, R. E. P., Jacob Filho, W., Lent, R., & Herculano-Houzel, S. (2009). Equal numbers of neuronal and nonneuronal cells make the human brain an isometrically scaled-up primate brain. *Journal of Comparative Neurology, 513*(5), 532–541. https://doi.org/10.1002/cne.21974

Baddeley, A. D., Thomson, N., & Buchanan, M. (1975). Word length and the structure of short-term memory. *Journal of Verbal Learning and Verbal Behavior, 14*(6), 575–589.

Billings, G., Piasini, E., Lőrincz, A., Nusser, Z., & Silver, R. A. (2014). Network structure within the cerebellar input layer enables lossless sparse encoding. *Neuron, 83*(4), 960–974.

Carnegie Mellon University. (2015). *The CMU Pronouncing Dictionary* [Data set; copyright 1993–2015, distributed with the Python package cmudict]. http://www.speech.cs.cmu.edu/cgi-bin/cmudict

Davis, M. H., & Gaskell, M. G. (2009). A complementary systems account of word learning: Neural and behavioural evidence. *Philosophical Transactions of the Royal Society B, 364*(1536), 3773–3800. https://doi.org/10.1098/rstb.2009.0111

Dehaene, S., & Cohen, L. (2007). Cultural recycling of cortical maps. *Neuron, 56*(2), 384–398. https://doi.org/10.1016/j.neuron.2007.10.004

Desmond, J. E., Gabrieli, J. D. E., Wagner, A. D., Ginier, B. L., & Glover, G. H. (1997). Lobular patterns of cerebellar activation in verbal working-memory and finger-tapping tasks as revealed by functional MRI. *Journal of Neuroscience, 17*(24), 9675–9685. https://doi.org/10.1523/JNEUROSCI.17-24-09675.1997

Dronkers, N. F. (1996). A new brain region for coordinating speech articulation. *Nature, 384*(6605), 159–161. https://doi.org/10.1038/384159a0

Fiez, J. A., Petersen, S. E., Cheney, M. K., & Raichle, M. E. (1992). Impaired non-motor learning and error detection associated with cerebellar damage. *Brain, 115*(1), 155–178. https://doi.org/10.1093/brain/115.1.155

Ghosh, D. P. (2024). *ISET: Invertible sequence embedding from Transformer* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.36457.67684

Ghosh, D. P. (2026a). *KV coefficient memory for Attentionlet* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.31586.70088

Ghosh, D. P. (2026b). *Vocabucapillary for cacheless transformer* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.36209.44648

Ghosh, D. P. (2026c). *Vocabucapillary memory for cooperative AI* (2nd ed.). Debias Parametric Guru.

Ghosh, D. P. (2026d). *Character vocabularies and ISET span memory: Spelling, order and linear-time reading in Vocabucapillary models* [Manuscript].

Ghosh, D. P. (2026e). *The cerebellum as a character-level ISET: Fine-resolution Vocabucapillary memory for physical AI* [Manuscript].

Ghosh, D. P. (2026f). *Words as sequences in self-attention: Slot-aligned, hierarchical and alignment scores over a dense word-level key–value cache* [Manuscript].

Ghosh, D. P. (2026g). *Words and action chunks in one dense key–value cache: ISET chunk tokens, bound word keys and mixed-modal attention* [Manuscript].

Ghosh, D. P. (2026h). *Vocabucapillary attention in sparse positive coefficient spaces* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.22633.66404

Ghosh, D. P. (2026i). *Vocabuquantization for memory efficient Vocabucapillary language models* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.21571.98085

Ghosh, D. P. (2026j). *Sparse words, dense actions: Word-Vocabucapillary records, ISET chunk tokens and counted association atoms in one key–value cache* [Manuscript].

Ghosh, D. P. (2026k). *Sparse backpropagation and progressive capacity in Vocabucapillary language models* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.17692.24960

Gruters, K. G., & Groh, J. M. (2012). Sounds and beyond: Multisensory and other non-auditory signals in the inferior colliculus. *Frontiers in Neural Circuits, 6*, 96. https://doi.org/10.3389/fncir.2012.00096

Guenther, F. H. (2016). *Neural control of speech*. MIT Press. https://mitpress.mit.edu/9780262034715/neural-control-of-speech/

Halassa, M. M., & Kastner, S. (2017). Thalamic functions in distributed cognitive control. *Nature Neuroscience, 20*(12), 1669–1679. https://doi.org/10.1038/s41593-017-0020-1

Hickok, G., & Poeppel, D. (2007). The cortical organization of speech processing. *Nature Reviews Neuroscience, 8*(5), 393–402. https://doi.org/10.1038/nrn2113

Ito, M. (2008). Control of mental activities by internal models in the cerebellum. *Nature Reviews Neuroscience, 9*(4), 304–313. https://doi.org/10.1038/nrn2332

Ivry, R. B., & Keele, S. W. (1989). Timing functions of the cerebellum. *Journal of Cognitive Neuroscience, 1*(2), 136–152. https://doi.org/10.1162/jocn.1989.1.2.136

Justus, T., Ravizza, S. M., Fiez, J. A., & Ivry, R. B. (2005). Reduced phonological similarity effects in patients with damage to the cerebellum. *Brain and Language, 95*, 304–318.

Kelly, R. M., & Strick, P. L. (2003). Cerebellar loops with motor cortex and prefrontal cortex of a nonhuman primate. *Journal of Neuroscience, 23*(23), 8432–8444. https://doi.org/10.1523/JNEUROSCI.23-23-08432.2003

Kent, R. D., Netsell, R., & Abbs, J. H. (1979). Acoustic characteristics of dysarthria associated with cerebellar disease. *Journal of Speech and Hearing Research, 22*(3), 627–648. https://doi.org/10.1044/jshr.2203.627

Krauzlis, R. J., Lovejoy, L. P., & Zénon, A. (2013). Superior colliculus and visual spatial attention. *Annual Review of Neuroscience, 36*, 165–182.

Lesage, E., Morgan, B. E., Olson, A. C., Meyer, A. S., & Miall, R. C. (2012). Cerebellar rTMS disrupts predictive language processing. *Current Biology, 22*(18), R794–R795.

Litwin-Kumar, A., Harris, K. D., Axel, R., Sompolinsky, H., & Abbott, L. F. (2017). Optimal degrees of synaptic connectivity. *Neuron, 93*(5), 1153–1164.

Marr, D. (1969). A theory of cerebellar cortex. *The Journal of Physiology, 202*(2), 437–470.

Marslen-Wilson, W. D., & Welsh, A. (1978). Processing interactions and lexical access during word recognition in continuous speech. *Cognitive Psychology, 10*(1), 29–63.

Martin, C. D., Branzi, F. M., & Bar, M. (2018). Prediction is production: The missing link between language production and comprehension. *Scientific Reports, 8*, 1079. https://doi.org/10.1038/s41598-018-19499-4

McConkie, G. W., Kerr, P. W., Reddix, M. D., & Zola, D. (1988). Eye movement control during reading: I. The location of initial eye fixations on words. *Vision Research, 28*(10), 1107–1118.

McElree, B., & Dosher, B. A. (1989). Serial position and set size in short-term memory: The time course of recognition. *Journal of Experimental Psychology: General, 118*(4), 346–373.

Miall, R. C., Weir, D. J., Wolpert, D. M., & Stein, J. F. (1993). Is the cerebellum a Smith predictor? *Journal of Motor Behavior, 25*(3), 203–216.

Olshausen, B. A., & Field, D. J. (1996). Emergence of simple-cell receptive field properties by learning a sparse code for natural images. *Nature, 381*(6583), 607–609.

Pickering, M. J., & Garrod, S. (2013). An integrated theory of language production and comprehension. *Behavioral and Brain Sciences, 36*(4), 329–347.

Radford, A., Wu, J., Child, R., Luan, D., Amodei, D., & Sutskever, I. (2019). *Language models are unsupervised multitask learners* [Technical report]. OpenAI.

Ravizza, S. M., McCormick, C. A., Schlerf, J. E., Justus, T., Ivry, R. B., & Fiez, J. A. (2006). Cerebellar damage produces selective deficits in verbal working memory. *Brain, 129*(2), 306–320.

Rayner, K. (1998). Eye movements in reading and information processing: 20 years of research. *Psychological Bulletin, 124*(3), 372–422.

Redgrave, P., Prescott, T. J., & Gurney, K. (1999). The basal ganglia: A vertebrate solution to the selection problem? *Neuroscience, 89*(4), 1009–1023. https://doi.org/10.1016/S0306-4522(98)00319-4

Riecker, A., Mathiak, K., Wildgruber, D., Erb, M., Hertrich, I., Grodd, W., & Ackermann, H. (2005). fMRI reveals two distinct cerebral networks subserving speech motor control. *Neurology, 64*, 700–706.

Schmahmann, J. D., & Sherman, J. C. (1998). The cerebellar cognitive affective syndrome. *Brain, 121*(4), 561–579. https://doi.org/10.1093/brain/121.4.561

Sennrich, R., Haddow, B., & Birch, A. (2016). Neural machine translation of rare words with subword units. In *Proceedings of the 54th Annual Meeting of the Association for Computational Linguistics* (pp. 1715–1725). https://doi.org/10.18653/v1/P16-1162

Silveri, M. C., Di Betta, A. M., Filippini, V., Leggio, M. G., & Molinari, M. (1998). Verbal short-term store-rehearsal system and the cerebellum: Evidence from a patient with a right cerebellar lesion. *Brain, 121*(11), 2175–2187. https://doi.org/10.1093/brain/121.11.2175

Smith, O. J. M. (1957). Closer control of loops with dead time. *Chemical Engineering Progress, 53*(5), 217–219.

Speer, R. (2022). *wordfreq: Access a database of word frequencies, in various natural languages* (Version 3.1.1) [Software and data]. https://github.com/rspeer/wordfreq

Takagi, M., Zee, D. S., & Tamargo, R. J. (1998). Effects of lesions of the oculomotor vermis on eye movements in primate: Saccades. *Journal of Neurophysiology, 80*(4), 1911–1931. https://doi.org/10.1152/jn.1998.80.4.1911

Wickelgren, W. A. (1977). Speed-accuracy tradeoff and information processing dynamics. *Acta Psychologica, 41*(1), 67–85.

Wolpert, D. M., Miall, R. C., & Kawato, M. (1998). Internal models in the cerebellum. *Trends in Cognitive Sciences, 2*(9), 338–347.

Xue, L., Barua, A., Constant, N., Al-Rfou, R., Narang, S., Kale, M., Roberts, A., & Raffel, C. (2022). ByT5: Towards a token-free future with pre-trained byte-to-byte models. *Transactions of the Association for Computational Linguistics, 10*, 291–306.
"""
md = md.replace("FIG/", str(FIG) + "/")
(HERE / "paper.md").write_text(md, encoding="utf8")
subprocess.run(["pandoc", str(HERE / "paper.md"), "-o", str(HERE / "raw.docx"), "--reference-doc", str(HERE / "ref.docx")], check=True)
docxfix.repair(HERE / "raw.docx", HERE / "paper.docx")
(HERE / "raw.docx").unlink()
print("paper written:", len(md.split()), "words")
