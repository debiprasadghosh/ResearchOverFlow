"""Figures for the paper, drawn from the C# laboratory outputs (plotting only, no computation)."""
import csv, os
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, Polygon

_ROOT = Path(__file__).resolve().parent.parent
OUT = os.environ.get("MX_OUT", str(_ROOT / "out")); FIG = os.environ.get("MX_FIGS", str(_ROOT / "figs"))
os.makedirs(FIG, exist_ok=True)
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, VIOLET = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6"
INK, INK2, MUTED, GRID = "#1f1f1f", "#52514e", "#8a8984", "#e4e3df"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9, "axes.edgecolor": MUTED,
    "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": GRID,
    "grid.linewidth": 0.6, "axes.axisbelow": True, "axes.spines.top": False, "axes.spines.right": False,
    "legend.frameon": False, "savefig.dpi": 220, "lines.linewidth": 2, "text.color": INK})
def rd(n): return list(csv.DictReader(open(f"{OUT}/{n}.csv")))
from matplotlib.ticker import NullFormatter, NullLocator
def save(f, n):
    for a in f.axes:                                    # log axes: keep only the ticks set explicitly
        if a.get_xscale() == "log": a.xaxis.set_minor_locator(NullLocator()); a.xaxis.set_minor_formatter(NullFormatter())
        if a.get_yscale() == "log": a.yaxis.set_minor_formatter(NullFormatter())
    f.savefig(f"{FIG}/{n}.png", bbox_inches="tight"); plt.close(f)
def fl(x): return float(x)

# ---------------- Figure 1: the dense mixed cache ----------------
fig, ax = plt.subplots(figsize=(7.0, 3.7)); ax.set_axis_off(); ax.set_xlim(0, 13.2); ax.set_ylim(0.3, 7.3)
def box(x, y, w, h, title, lines, ec=INK2, fc="white", lw=1.1):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.12", fc=fc, ec=ec, lw=lw))
    ax.text(x + w / 2, y + h - 0.33, title, ha="center", va="center", fontsize=7.6, weight="bold", color=INK)
    for i, s_ in enumerate(lines):
        ax.text(x + w / 2, y + h - 0.72 - 0.34 * i, s_, ha="center", va="center", fontsize=6.4, color=INK2)
def arrow(x0, y0, x1, y1):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0), arrowprops=dict(arrowstyle="-|>", color=MUTED, lw=1.1, shrinkA=0, shrinkB=0))
box(0.1, 5.0, 2.4, 1.75, "Word modes", ["language", "visual objects", "audio words"], ec=BLUE)
box(2.95, 4.65, 3.1, 2.1, "Word token", ["bound key of the letters", "Σ Rⱼ e(cⱼ) + R e(EOS)", "one vector of width d", "+ letter slots for rerank"], ec=BLUE)
box(0.1, 1.75, 2.4, 1.75, "Body modes", ["7 joints", "50 control steps/s", "motor characters"], ec=ORANGE)
box(2.95, 1.05, 3.1, 2.45, "Chunk token (ISET)", ["L steps → linear ISET code", "one vector of width d", "+ per-step slots for rerank", "+ raw characters (28 B)", "+ code version, write error"], ec=ORANGE)
arrow(2.5, 5.87, 2.95, 5.87); arrow(2.5, 2.62, 2.95, 2.62)
ax.text(7.65, 7.05, "One dense KV cache", ha="center", va="center", fontsize=7.6, weight="bold")
ax.add_patch(FancyBboxPatch((6.5, 1.05), 2.3, 5.7, boxstyle="round,pad=0.02,rounding_size=0.12", fc="#f7f6f3", ec=INK2, lw=1.1))
seq = "WBBWBBBWBBWBBBWBBWBB"
for i, c in enumerate(seq):
    col = BLUE if c == "W" else ORANGE
    ax.add_patch(Rectangle((6.72 + (i % 4) * 0.48, 6.05 - (i // 4) * 0.95), 0.38, 0.62, fc=col, ec="white", lw=1.2, alpha=0.88))
ax.add_patch(Rectangle((6.78, 1.3), 0.22, 0.22, fc=BLUE, ec="none")); ax.text(7.06, 1.41, "word", va="center", fontsize=6.4, color=INK2)
ax.add_patch(Rectangle((7.72, 1.3), 0.22, 0.22, fc=ORANGE, ec="none")); ax.text(8.0, 1.41, "chunk", va="center", fontsize=6.4, color=INK2)
arrow(6.05, 5.87, 6.5, 5.87); arrow(6.05, 2.62, 6.5, 2.62)
box(9.25, 5.0, 3.85, 1.75, "Read", ["per-type normalized distance", "one causal softmax", "pooled screen → typed rerank"], ec=VIOLET)
box(9.25, 3.0, 3.85, 1.75, "Associate", ["role slots [â; ô; ẑ]", "or a bound tuple R₁â + R₂ô + R₃ẑ", "(a linear map is additive only)"], ec=VIOLET)
box(9.25, 1.0, 3.85, 1.75, "Act", ["choose a mode, read within it", "decode the ISET code", "fast loop corrects the residual"], ec=VIOLET)
arrow(8.8, 5.87, 9.25, 5.87); arrow(8.8, 3.87, 9.25, 3.87); arrow(8.8, 1.87, 9.25, 1.87)
ax.text(6.6, 0.5, "Every entry is a dense vector; Part 2 replaces the word entries by sparse word-Vocabucapillary records.", ha="center", va="center", fontsize=6.6, color=INK2, style="italic")
save(fig, "fig1_mixed_cache")

# ---------------- Figure 2: chunk tokens ----------------
ret = rd("M02_retrieval"); rec = rd("M02_reconstruction")
Ls = [4, 8, 16, 32]
encs = [("bound characters", "bound motor characters", MAGENTA, "-", 2.4, "s"), ("per-step slots", "per-step slots (L vectors)", YELLOW, (0, (4, 2)), 1.6, "o"),
        ("learned linear ISET", "learned linear ISET", BLUE, "-", 2.4, "o"), ("DCT", "DCT (training-free)", AQUA, (0, (4, 2)), 1.6, "^")]
def rv(enc, L, col): return fl(next(r[col] for r in ret if r["encoder"] == enc and r["steps_L"] == str(L) and r["width_d"] == "128" and r["noise_sigma"] == "0.5"))
def cv(enc, L, col): return fl(next(r[col] for r in rec if r["encoder"] == enc and r["steps_L"] == str(L) and r["width_d"] == "128"))
fig, axes = plt.subplots(1, 3, figsize=(6.9, 2.6))
for k, lab, col, ls, lw, mk in encs:
    axes[0].plot(Ls, [rv(k, L, "address_exact") for L in Ls], marker=mk, ms=3.6, color=col, ls=ls, lw=lw, label=lab)
    axes[1].plot(Ls, [rv(k, L, "similar_nearest_l2") for L in Ls], marker=mk, ms=3.6, color=col, ls=ls, lw=lw)
    axes[2].plot(Ls, [cv(k, L, "pass_0.04_all") for L in Ls], marker=mk, ms=3.6, color=col, ls=ls, lw=lw)
axes[1].plot(Ls, [rv("learned linear ISET", L, "similar_nearest_cosine") for L in Ls], ls=":", lw=1.6, color=BLUE, label="learned linear ISET, cosine score")
for ax, t in zip(axes, ["address: exact chunk first", "similar motion: nearest found", "reconstructed within 0.04 rad"]):
    ax.set_xscale("log", base=2); ax.set_xticks(Ls); ax.set_xticklabels([str(L) for L in Ls]); ax.set_ylim(-0.03, 1.05)
    ax.set_title(t); ax.set_xlabel("steps per chunk L")
fig.tight_layout()
h0, l0 = axes[0].get_legend_handles_labels(); h1, l1 = axes[1].get_legend_handles_labels()
fig.legend(h0 + h1, l0 + l1, loc="upper center", ncol=3, fontsize=7.0, bbox_to_anchor=(0.5, 0.02))
save(fig, "fig2_chunk_tokens")

# ---------------- Figure 3: one softmax over two encoders ----------------
cal = rd("M03_calibration"); dil = rd("M03_dilution")
rhos = [0.125, 0.5, 1, 2, 8]
def calv(rule, rho, col): return fl(next(r[col] for r in cal if r["score_rule"] == rule and fl(r["chunk_to_word_norm_ratio"]) == rho))
fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.75))
for rule, ls, tag in [("raw dot product", "-", "raw dot product"), ("per-type normalized distance", "--", "per-type normalized distance")]:
    axes[0].plot(rhos, [calv(rule, r, "word_exact") for r in rhos], ls=ls, marker="o", ms=3.3, color=BLUE, label=f"word query, {tag}")
    axes[0].plot(rhos, [calv(rule, r, "chunk_address_within_tolerance") for r in rhos], ls=ls, marker="o", ms=3.3, color=ORANGE, label=f"chunk query, {tag}")
axes[0].set_xscale("log", base=2); axes[0].set_xticks(rhos); axes[0].set_xticklabels(["1/8", "1/2", "1", "2", "8"])
axes[0].set_ylim(-0.03, 1.05); axes[0].set_xlabel("chunk key norm / word key norm"); axes[0].set_title("right entry found (chunk: within tolerance)")
pws = [1.25, 2.5, 20]
for beta, col in [(4, ORANGE), (8, BLUE), (16, AQUA)]:
    for bias, ls in [("none", "-"), ("log-count bias", "--")]:
        ys = [fl(next(r["mass_on_body_tokens"] for r in dil if fl(r["body_tokens_per_word"]) == pw and fl(r["inverse_temperature_beta"]) == beta and r["bias"] == bias)) for pw in pws]
        axes[1].plot(pws, ys, ls=ls, marker="o", ms=3.3, color=col, label=f"β = {beta}" + (", log-count bias" if bias != "none" else ""))
axes[1].set_xscale("log"); axes[1].set_xticks(pws); axes[1].set_xticklabels(["1.25", "2.5", "20"]); axes[1].set_ylim(-0.03, 1.0)
axes[1].set_xlabel("body tokens per word"); axes[1].set_title("word query: attention mass on body tokens")
fig.tight_layout()
axes[0].legend(fontsize=6.6, loc="upper center", bbox_to_anchor=(0.5, -0.27), ncol=1)
axes[1].legend(fontsize=6.6, loc="upper center", bbox_to_anchor=(0.5, -0.27), ncol=2)
save(fig, "fig3_one_softmax")

# ---------------- Figure 4: deeper layers and long histories ----------------
dep = rd("M03_depth"); lh = rd("M03_long_history")
bs = [fl(r["context_to_self_ratio"]) for r in dep]
fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.75))
for col, lab, c in [("word_exact", "word found (exact)", BLUE), ("word_spelled_from_key", "word spelled from key", VIOLET),
                    ("chunk_address_within_tolerance", "chunk found (within tolerance)", ORANGE), ("chunk_reconstruction_pass_0.04", "chunk decoded within 0.04 rad", MAGENTA)]:
    axes[0].plot(bs, [fl(r[col]) for r in dep], marker="o", ms=3.3, color=c, label=lab)
axes[0].set_xlabel("context mixed into the key (ratio to self)"); axes[0].set_ylim(-0.03, 1.05); axes[0].set_title("what a deeper-layer key still carries")
ms = [256, 1024, 4096, 16384]
def lv(reader, m, col): return fl(next(r[col] for r in lh if r["reader"] == reader and r["tokens_M"] == str(m)))
for reader, col, lab, c in [("dense character-level attention", "mac_per_word_query", "letters and control steps, dense", MUTED),
                            ("pooled scan only", "mac_per_word_query", "pooled scan", AQUA),
                            ("pooled screen → typed slot rerank, K=8", "mac_per_word_query", "screen → rerank, word query", BLUE),
                            ("pooled screen → typed slot rerank, K=8", "mac_per_chunk_query", "screen → rerank, chunk query", ORANGE)]:
    axes[1].plot(ms, [lv(reader, m, col) for m in ms], marker="o", ms=3.3, color=c, label=lab, ls="--" if c == ORANGE else "-")
axes[1].set_xscale("log", base=2); axes[1].set_yscale("log"); axes[1].set_xticks(ms); axes[1].set_xticklabels(["256", "1,024", "4,096", "16,384"])
axes[1].set_xlabel("tokens in the mixed history"); axes[1].set_title("multiply-adds per query")
fig.tight_layout()
axes[0].legend(fontsize=6.6, loc="upper center", bbox_to_anchor=(0.5, -0.27), ncol=1)
axes[1].legend(fontsize=6.6, loc="upper center", bbox_to_anchor=(0.5, -0.27), ncol=1)
save(fig, "fig4_depth_long")

# ---------------- Figure 5: association ----------------
asc = [r for r in rd("M04_association") if r["width_d"] == "128"]
io = [fl(r["interaction_share_iota"]) for r in asc]
fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.75))
axes[0].plot(io, [fl(r["plan_linear_map_rms"]) for r in asc], marker="o", ms=3.3, color=BLUE, label="linear map (ridge)")
axes[0].plot(io, [fl(r["additive_floor_rms"]) for r in asc], ls=":", lw=1.4, color=BLUE, label="best additive fit")
axes[0].plot(io, [fl(r["plan_tuple_top1_rms"]) for r in asc], marker="o", ms=3.3, color=ORANGE, label="bound tuple, top-1")
axes[0].plot(io, [fl(r["plan_role_slots_rms"]) for r in asc], marker="o", ms=3.3, color=AQUA, label="role slots, top-1")
axes[0].plot(io, [fl(r["execution_floor_rms"]) for r in asc], ls="--", lw=1.2, color=MUTED, label="executions vs prototype")
axes[0].set_xlabel("interaction share ι"); axes[0].set_title("planning error, RMS (rad)"); axes[0].set_ylim(0, 0.27)
axes[1].plot(io, [fl(r["describe_linear_both"]) for r in asc], marker="o", ms=3.3, color=BLUE, label="linear map")
axes[1].plot(io, [fl(r["describe_tuple_both"]) for r in asc], marker="o", ms=3.3, color=ORANGE, label="bound tuple")
axes[1].plot(io, [fl(r["describe_role_slots_both"]) for r in asc], marker="o", ms=3.3, color=AQUA, label="role slots")
axes[1].set_xlabel("interaction share ι"); axes[1].set_title("description: verb and object right"); axes[1].set_ylim(-0.03, 1.05)
fig.tight_layout()
axes[0].legend(fontsize=6.6, loc="upper center", bbox_to_anchor=(0.5, -0.27), ncol=2)
axes[1].legend(fontsize=6.6, loc="upper center", bbox_to_anchor=(0.5, -0.27), ncol=3)
save(fig, "fig5_association")

# ---------------- Figure 6: choosing a mode ----------------
ex = rd("M05_examples"); mc = rd("M05_mode_choice")
t = [int(r["step"]) for r in ex]
fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.75), gridspec_kw={"width_ratios": [1.25, 1]})
axes[0].add_patch(Rectangle((4.5, -0.3), 6, 0.6, fc="#f3d9cf", ec="none"))
axes[0].text(7.5, 0.17, "obstacle", ha="center", va="center", fontsize=7, color=ORANGE)
axes[0].plot(t, [fl(r["stored_left"]) for r in ex], color=MUTED, lw=1.0, label="stored executions")
axes[0].plot(t, [fl(r["stored_right"]) for r in ex], color=MUTED, lw=1.0)
axes[0].plot(t, [fl(r["soft_beta10"]) for r in ex], color=ORANGE, label="soft read, β = 10")
axes[0].plot(t, [fl(r["soft_beta100"]) for r in ex], color=MAGENTA, label="soft read, β = 100")
axes[0].plot(t, [fl(r["hard_top1"]) for r in ex], color=VIOLET, ls="--", label="hard top-1 read")
axes[0].plot(t, [fl(r["mode_first_k2"]) for r in ex], color=BLUE, label="mode first, then soft within")
axes[0].set_xlabel("step"); axes[0].set_title("decoded action for one query"); axes[0].set_ylim(-1.3, 1.3)
betas = [10, 30, 100, 300]
def mv(name, col): return fl(next(r[col] for r in mc if r["reader"] == name))
axes[1].plot(betas, [mv(f"soft read, β = {b}.0" if False else f"soft read, β = {b}", "collision_rate") for b in betas], marker="o", ms=3.3, color=ORANGE, label="soft read")
axes[1].plot([10], [mv("mode first (K = 2), then soft within", "collision_rate")], marker="o", ms=6, ls="none", color=BLUE, label="mode first, then soft within (β = 10)")
axes[1].text(290, 0.5, "hard top-1 read: no collisions", ha="right", va="center", fontsize=6.8, color=VIOLET)
axes[1].set_xscale("log"); axes[1].set_xticks(betas); axes[1].set_xticklabels([str(b) for b in betas]); axes[1].set_ylim(-0.03, 1.05)
axes[1].set_xlabel("inverse temperature β"); axes[1].set_title("collision rate")
fig.tight_layout()
axes[0].legend(fontsize=6.6, loc="upper center", bbox_to_anchor=(0.5, -0.27), ncol=2)
axes[1].legend(fontsize=6.6, loc="upper center", bbox_to_anchor=(0.5, -0.27), ncol=1)
save(fig, "fig6_mode_choice")
print("figures written")
