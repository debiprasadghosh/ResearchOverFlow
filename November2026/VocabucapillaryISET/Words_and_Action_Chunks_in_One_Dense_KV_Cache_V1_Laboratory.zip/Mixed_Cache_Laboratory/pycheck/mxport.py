"""Line-for-line Python ports of the laboratory's generator and motor stream (for the cross-check)."""
import math
M64 = (1 << 64) - 1
class Rng:
    G = 0x9E3779B97F4A7C15
    def __init__(self, s): self.s = s & M64
    @staticmethod
    def derive(seed, stream):
        r = Rng((seed ^ ((stream * 0xD1B54A32D192ED03) & M64)) & M64)
        r.u64(); return r
    def u64(self):
        self.s = (self.s + Rng.G) & M64
        z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return z ^ (z >> 31)
    def double(self): return (self.u64() >> 11) * (1.0 / 9007199254740992.0)
    def int(self, n):
        v = int(self.double() * n); return n - 1 if v >= n else v
    def uniform(self, lo, hi): return lo + (hi - lo) * self.double()
    def gauss(self):
        u1 = self.double(); u2 = self.double()
        return math.sqrt(-2.0 * math.log(1.0 - u1)) * math.cos(2.0 * math.pi * u2)

DOF, FREQS, PERIOD, ALPHA, OFFSET = 7, 4, 32, 16, 7
STEP, JITTER, NOISE, CRATE, CSIZE = 0.04, 0.1, 0.005, 1.0 / 32, 0.08
AMPSD = 0.3

def make_skill(k, seed, ampsd=None):
    ampsd = AMPSD if ampsd is None else ampsd
    r = Rng.derive(seed, 10000 + k); amp = []; ph = []
    for i in range(DOF * FREQS):
        g = r.gauss(); p = r.uniform(0, 2 * math.pi); amp.append(ampsd * g); ph.append(p)
    return amp, ph

def prototype(skill, L):
    amp, ph = skill; x = [0.0] * (DOF * L)
    for j in range(DOF):
        for t in range(L):
            v = 0.0
            for f in range(1, FREQS + 1):
                a = amp[j * FREQS + f - 1]; p = ph[j * FREQS + f - 1]
                v += a / f * (math.sin(2 * math.pi * f * t / PERIOD + p) - math.sin(p))
            x[j * L + t] = v
    return x

def execute(proto, L, r):
    g = r.gauss(); a = 1 + JITTER * g
    x = [a * proto[i] + NOISE * r.gauss() for i in range(DOF * L)]
    contacts = 0
    for t in range(L):
        u = r.double()
        if u >= CRATE: continue
        contacts += 1
        for j in range(DOF):
            sz = r.gauss()
            for tt in range(t, L):
                x[j * L + tt] += CSIZE * sz * (1.0 if tt - t < 2 else math.exp(-(tt - t - 2) / 4.0))
    return x, contacts

def characters(x, L):
    sym = [0] * len(x); rec = [0.0] * len(x)
    for j in range(DOF):
        prev = 0.0
        for t in range(L):
            v = (x[j * L + t] - prev) / STEP
            c = int(round_half_even(v)); c = max(-OFFSET, min(ALPHA - 1 - OFFSET, c))
            prev += c * STEP; sym[j * L + t] = c + OFFSET; rec[j * L + t] = prev
    return sym, rec

def round_half_even(v):
    # .NET Math.Round default is banker's rounding, as is Python's round()
    return round(v)

def rms(a, b): return math.sqrt(sum((p - q) ** 2 for p, q in zip(a, b)) / len(a))
