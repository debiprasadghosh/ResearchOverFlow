"""Independent Python cross-check of the mixed-cache laboratory.

Decodes the wordfreq file with its own MessagePack reader and recomputes the accounting; repeats the crosstalk Monte
Carlo with numpy's generator; integrates the readout approximation with scipy; regenerates the motor chunks, the obstacle
trajectories and the association prototypes with line-for-line ports of the generator; recomputes principal-component
and DCT reconstruction errors with numpy's SVD and scipy's DCT; and verifies two invariances in the C# tables.
Usage: python3 crosscheck.py [out_folder] [data_file]
"""
import csv, gzip, json, math, sys
from pathlib import Path
import numpy as np
from scipy import integrate, fft
from scipy.stats import norm

sys.path.insert(0, str(Path(__file__).resolve().parent))
import mxport as M

ROOT = Path(__file__).resolve().parent.parent
OUT = sys.argv[1] if len(sys.argv) > 1 else str(ROOT / "out")
DATA = sys.argv[2] if len(sys.argv) > 2 else str(ROOT / "data" / "large_en.msgpack.gz")
H = json.load(open(f"{OUT}/headlines.json"))
rows = []
def check(name, cs, py, tol):
    rows.append((name, cs, py, abs(cs - py), abs(cs - py) <= tol))
def rd(n): return list(csv.DictReader(open(f"{OUT}/{n}.csv")))

# ---------- MessagePack (independent minimal reader) and lexicon ----------
def unpack(b):
    def rdv(i):
        t = b[i]
        if t <= 0x7f: return t, i + 1
        if 0x80 <= t <= 0x8f: return rmap(i + 1, t & 0x0f)
        if 0x90 <= t <= 0x9f: return rarr(i + 1, t & 0x0f)
        if 0xa0 <= t <= 0xbf: n = t & 0x1f; return b[i + 1:i + 1 + n].decode(), i + 1 + n
        if t == 0xd9: n = b[i + 1]; return b[i + 2:i + 2 + n].decode(), i + 2 + n
        if t == 0xda: n = int.from_bytes(b[i + 1:i + 3], "big"); return b[i + 3:i + 3 + n].decode(), i + 3 + n
        if t == 0xdc: return rarr(i + 3, int.from_bytes(b[i + 1:i + 3], "big"))
        if t == 0xdd: return rarr(i + 5, int.from_bytes(b[i + 1:i + 5], "big"))
        if t == 0xcc: return b[i + 1], i + 2
        if t == 0xcd: return int.from_bytes(b[i + 1:i + 3], "big"), i + 3
        raise ValueError(hex(t))
    def rarr(i, n):
        out = []
        for _ in range(n):
            v, i = rdv(i); out.append(v)
        return out, i
    def rmap(i, n):
        out = {}
        for _ in range(n):
            k, i = rdv(i); v, i = rdv(i); out[k] = v
        return out, i
    return rdv(0)[0]

root = unpack(gzip.open(DATA).read())
allw = [(w, 10.0 ** (-(i - 1) / 100.0)) for i in range(1, len(root)) for w in root[i]]
kept = [x for x in allw if len(x[0]) > 0 and all("a" <= c <= "z" for c in x[0]) and len(x[0]) <= 16][:50000]
kmass = sum(f for _, f in kept)
letters = sum(f / kmass * len(w) for w, f in kept)
check("M00 letters per word (lexicon, frequency-weighted)", H["M00.letters_per_word"], letters, 1e-12)

# ---------- M00: accounting ----------
def pairs(n): return n * (n + 1) / 2
words, steps = 2.5 * 60, 50 * 60
slots = letters + 1
base = pairs(words * slots + steps * 7)
check("M00 causal pairs, characters + motor characters", H["M00.characters_motor_characters_one_token_per_joint_and_step_pairs"], base, 1e-3)
for L in (4, 8, 16, 32):
    n = words + steps / L
    check(f"M00 pair reduction, words + chunks of {L}", H[f"M00.words_chunks_of_{L}_steps_pair_ratio"], base / pairs(n), 1e-9)
    check(f"M00 body-body pair reduction, L = {L}", H[f"M00.body_pair_reduction_L{L}"], pairs(steps) / pairs(steps / L), 1e-9)
check("M00 body share, 50 Hz, chunks of 8", H["M00.hz50_L8_body_share"], 6.25 / 8.75, 1e-12)

# ---------- M01: crosstalk (numpy generator) and readout approximation (scipy) ----------
rng = np.random.default_rng(20261125)
def bound_cross(d, s, n=3000):
    perms = [rng.permutation(d) for _ in range(s)]; signs = [rng.choice([-1.0, 1.0], d) for _ in range(s)]
    out = np.empty(n)
    for i in range(n):
        a = rng.standard_normal((s, d)); a /= np.linalg.norm(a, axis=1, keepdims=True)
        b = rng.standard_normal((s, d)); b /= np.linalg.norm(b, axis=1, keepdims=True)
        q = np.zeros(d); k = np.zeros(d)
        for j in range(s):
            q[perms[j]] += signs[j] * a[j]; k[perms[j]] += signs[j] * b[j]
        out[i] = q @ k - np.sum(a * b)
    return out.std(ddof=1)
for d, s in ((128, 3), (128, 56), (64, 28), (256, 112)):
    check(f"M01 crosstalk sd, d = {d}, S = {s} (relative gap)", 0.0, abs(H[f"M01.cross_d{d}_S{s}_sd"] / bound_cross(d, s) - 1), 0.07)
def p_correct(s, d, a=16):
    sc, sw = math.sqrt((s - 1) / d), math.sqrt(s / d)
    f = lambda z: norm.pdf(z) * norm.cdf((1 + sc * z) / sw) ** (a - 1)
    return integrate.quad(f, -12, 12, limit=400)[0]
for d, L in ((64, 4), (128, 1), (128, 8), (256, 4), (256, 16)):
    check(f"M01 readout error approximation, d = {d}, L = {L}", H[f"M01.read_d{d}_L{L}_theory"], 1 - p_correct(7 * L, d), 2e-4)
ms = min(math.sin(math.pi * (t + 1) / 17) for t in range(5, 11))
check("M01 blend band, lower edge", H["M01.blend_band_low"], 0.5 - 0.3 / (2 * ms), 1e-12)

# ---------- M02: regenerated chunks, characters, PCA (SVD) and DCT ----------
def gen(L, per, stream, seed=202):
    lib = [M.make_skill(k, seed) for k in range(64)]
    protos = [M.prototype(s, L) for s in lib]
    out = []
    for i in range(64 * per):
        x, c = M.execute(protos[i // per], L, M.Rng.derive(seed, stream + L * 100_000 + i))
        out.append((i // per, np.array(x), c))
    return out
def bf16(a):
    f = np.asarray(a, dtype=np.float32).view(np.uint32).astype(np.uint64)
    lsb = (f >> 16) & 1
    r = ((f + 0x7FFF + lsb) & 0xFFFF0000).astype(np.uint32)
    return r.view(np.float32).astype(np.float64)
for L in (8, 16):
    pool = gen(L, 32, 2_000_000_000)
    check(f"M02 contact share, L = {L}", H[f"M02.L{L}_contact_share"], np.mean([c > 0 for _, _, c in pool]), 1e-12)
    check(f"M02 signal RMS, L = {L}", H[f"M02.L{L}_signal_rms"], math.sqrt(np.mean([np.mean(x ** 2) for _, x, _ in pool])), 1e-12)
    floor = [M.rms(list(x), M.characters(list(x), L)[1]) for _, x, _ in pool]
    check(f"M02 motor-character floor RMS, L = {L}", H[f"M02.L{L}_char_floor_rms"], math.sqrt(np.mean(np.square(floor))), 1e-12)
train16 = np.array([x for _, x, _ in gen(16, 64, 1_000_000_000)])
pool16 = gen(16, 32, 2_000_000_000)
X = np.array([x for _, x, _ in pool16])
mu = train16.mean(axis=0)
_, _, vt = np.linalg.svd(train16 - mu, full_matrices=False)
for r in (28, 56):
    U = vt[:r]
    rec = mu + bf16((X - mu) @ U.T) @ U
    e = np.sqrt(np.mean((rec - X) ** 2, axis=1))
    check(f"M02 learned linear ISET RMS, L = 16, rank {r}", H[f"M02.rank{r}_pca_rms"], math.sqrt(np.mean(e ** 2)), 1e-6)
    check(f"M02 learned linear ISET pass share, L = 16, rank {r}", H[f"M02.rank{r}_pca_pass"], np.mean(e <= 0.04), 1e-9)
    k = r // 7
    Xj = X.reshape(-1, 7, 16)
    c = fft.dct(Xj, type=2, norm="ortho", axis=2)[:, :, :k]
    recd = fft.idct(np.concatenate([bf16(c), np.zeros((len(X), 7, 16 - k))], axis=2), type=2, norm="ortho", axis=2).reshape(len(X), -1)
    ed = np.sqrt(np.mean((recd - X) ** 2, axis=1))
    check(f"M02 DCT RMS, L = 16, rank {r}", H[f"M02.rank{r}_dct_rms"], math.sqrt(np.mean(ed ** 2)), 1e-6)

# ---------- M04: additive floor of the association prototypes ----------
def unit_pattern(i):
    p = np.array(M.prototype(M.make_skill(i, 404), 8)); return p / math.sqrt(np.mean(p ** 2))
uv = [unit_pattern(1000 + v) for v in range(16)]; uo = [unit_pattern(2000 + o) for o in range(16)]; up = [unit_pattern(3000 + p) for p in range(256)]
for iota in (0.25, 0.5, 1.0):
    a, b = math.sqrt((1 - iota) / 2), math.sqrt(iota)
    P = np.array([0.26 * (a * (uv[p // 16] + uo[p % 16]) + b * up[p]) for p in range(256)]).reshape(16, 16, -1)
    add = P.mean(axis=1, keepdims=True) + P.mean(axis=0, keepdims=True) - P.mean(axis=(0, 1), keepdims=True)
    floor = math.sqrt(np.mean(np.mean((add - P) ** 2, axis=2)))
    check(f"M04 additive floor RMS, iota = {iota}", H[f"M04.iota{iota:g}_additive_floor"], floor, 1e-12)
    check(f"M04 linear map within 0.5% of the additive floor, iota = {iota} (relative gap)", 0.0, abs(H[f"M04.iota{iota:g}_plan_linear_rms"] / floor - 1), 0.005)

# ---------- M05: obstacle trajectories ----------
def trajectory(r):
    u = r.double(); ga = r.gauss(); mode = 1 if u < 0.5 else -1; amp = 1 + 0.1 * ga
    return np.array([mode * amp * math.sin(math.pi * (t + 1) / 17) + 0.02 * r.gauss() for t in range(16)]), mode
data = [trajectory(M.Rng.derive(505, i)) for i in range(512)]
ys = np.array([y for y, _ in data])
spacing = np.mean([np.min(np.delete(np.linalg.norm(ys - ys[i], axis=1), i)) for i in range(200)])
check("M05 mean nearest-neighbour spacing of stored trajectories", H["M05.spacing"], spacing, 1e-12)
check("M05 share of stored trajectories passing on the left", H["M05.left_share_stored"], np.mean([m == 1 for _, m in data]), 1e-12)

# ---------- invariances visible in the C# tables ----------
cal = rd("M03_calibration")
cols = ["word_exact", "chunk_address_within_tolerance", "chunk_similar_nearest"]
for rule in ("key-normalized (cosine)", "per-type normalized dot product", "per-type normalized distance"):
    vals = {tuple(r[c] for c in cols) for r in cal if r["score_rule"] == rule}
    check(f"M03 {rule}: identical results at every norm ratio (distinct rows)", 1, len(vals), 0)

with open(f"{OUT}/PY_crosscheck.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["quantity", "csharp", "python", "abs_difference", "agree"])
    for row in rows: w.writerow(row)
print(f"{sum(r[4] for r in rows)}/{len(rows)} agree")
for row in rows:
    if not row[4]: print("DISAGREE", row)
