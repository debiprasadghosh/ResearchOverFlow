using MxLab.Core;

namespace MxLab.Experiments;

/// <summary>
/// Association without association atoms. Sixteen verbs × sixteen objects name 256 actions; each action's 8-step chunk
/// prototype mixes a verb pattern, an object pattern and a pair-specific (interaction) pattern with share ι. Four
/// executions per pair are stored as role-bound tuple keys R₁â + R₂ô + R₃ẑ with the action code as value. Planning
/// (words → action) and description (fresh action → words) are compared for the explicit tuple memory and for implicit
/// association by a linear map (ridge regression), whose additive form cannot express the interaction.
/// </summary>
public static class M04_Association
{
    private const ulong Seed = 404;
    public const int L = 8, PerPair = 4, Rank = 56;
    public const double Beta = 8.0, SignalRms = 0.26;
    public static readonly string[] Verbs = { "grasp", "push", "pull", "lift", "lower", "turn", "twist", "press", "slide", "pour", "shake", "wipe", "open", "close", "place", "drop" };
    public static readonly string[] Objects = { "cup", "box", "door", "lid", "bottle", "handle", "drawer", "knob", "block", "ball", "plate", "bowl", "pen", "key", "cloth", "valve" };

    static IReadOnlyList<double> UnitPattern(int id)
    {
        var p = Motor.Prototype(Motor.MakeSkill(id, Seed), L);
        double rms = Math.Sqrt(p.Average(v => v * v));
        return p.Select(v => v / rms).ToArray();
    }

    /// <summary>x_p = s₀ [√((1 − ι)/2)(u_v + u_o) + √ι u_p] with unit-RMS smooth patterns u.</summary>
    public static IReadOnlyList<IReadOnlyList<double>> Prototypes(double iota)
    {
        var uv = Enumerable.Range(0, 16).Select(v => UnitPattern(1000 + v)).ToArray();
        var uo = Enumerable.Range(0, 16).Select(o => UnitPattern(2000 + o)).ToArray();
        var up = Enumerable.Range(0, 256).Select(p => UnitPattern(3000 + p)).ToArray();
        double a = Math.Sqrt((1 - iota) / 2), b = Math.Sqrt(iota);
        return Enumerable.Range(0, 256).Select(p => (IReadOnlyList<double>)Enumerable.Range(0, Motor.Dof * L)
            .Select(i => SignalRms * (a * (uv[p / 16][i] + uo[p % 16][i]) + b * up[p][i])).ToArray()).ToArray();
    }

    /// <summary>The best additive fit f(v) + g(o) of the prototypes (two-way decomposition): what any linear map of [â; ô] can reach.</summary>
    public static IReadOnlyList<IReadOnlyList<double>> AdditivePart(IReadOnlyList<IReadOnlyList<double>> x)
    {
        int n = x[0].Count;
        var grand = Enumerable.Range(0, n).Select(i => x.Average(p => p[i])).ToArray();
        var row = Enumerable.Range(0, 16).Select(v => Enumerable.Range(0, n).Select(i => Enumerable.Range(0, 16).Average(o => x[v * 16 + o][i])).ToArray()).ToArray();
        var col = Enumerable.Range(0, 16).Select(o => Enumerable.Range(0, n).Select(i => Enumerable.Range(0, 16).Average(v => x[v * 16 + o][i])).ToArray()).ToArray();
        return Enumerable.Range(0, 256).Select(p => (IReadOnlyList<double>)Enumerable.Range(0, n).Select(i => row[p / 16][i] + col[p % 16][i] - grand[i]).ToArray()).ToArray();
    }

    public sealed record Outcome(double PlanTopRms, double PlanTopPair, double PlanSoftRms, double PlanSlotRms, double PlanSlotPair, double PlanLinearRms, double AdditiveFloorRms,
        double ExecutionFloorRms, double DescTuple, double DescTupleVerb, double DescTupleObject, double DescSlot, double DescLinear, double DescLinearVerb, double DescLinearObject);

    public static Outcome Evaluate(Lexicon lex, double iota, int d, ulong stream)
    {
        var code = CharCode.Random(d, Rng.Derive(Seed, stream + 1));
        var bind = Binder.Create(d, Sym.L + 1, Rng.Derive(Seed, stream + 2));
        var roles = Binder.Create(d, 3, Rng.Derive(Seed, stream + 3));
        var vKeys = Verbs.Select(w => Mat.Normalize(Layout.Bound(w, code, bind))).ToArray();
        var oKeys = Objects.Select(w => Mat.Normalize(Layout.Bound(w, code, bind))).ToArray();
        var protos = Prototypes(iota);
        var train = Enumerable.Range(0, 256 * PerPair).Select(i => Motor.Execute(i / PerPair, protos[i / PerPair], L, Rng.Derive(Seed, stream + 10_000UL + (ulong)i)).Value).ToArray();
        var pca = LinearIset.Fit(train.Select(c => c.X).ToArray(), Math.Min(Rank, d));
        var stored = Enumerable.Range(0, 256 * PerPair).Select(i => Motor.Execute(i / PerPair, protos[i / PerPair], L, Rng.Derive(Seed, stream + 20_000UL + (ulong)i)).Value).ToArray();
        var z = stored.Select(c => Bf16.Round(Mat.Pad(pca.Encode(c.X), d))).ToArray();
        IReadOnlyList<double> Tuple(int pair, IReadOnlyList<double> zc)
        {
            var a = roles.Apply(0, vKeys[pair / 16]); var b = roles.Apply(1, oKeys[pair % 16]); var c = roles.Apply(2, Mat.Normalize(zc));
            return Enumerable.Range(0, d).Select(i => a[i] + b[i] + c[i]).ToArray();
        }
        var keys = stored.Select((c, i) => Bf16.Round(Tuple(c.Skill, z[i]))).ToArray();
        IReadOnlyList<double> Decode(IReadOnlyList<double> code_) => pca.Decode(code_.Take(pca.Rank).ToArray());

        // Implicit association: ridge maps between [â; ô] and the action code.
        var wordIn = stored.Select(c => (IReadOnlyList<double>)vKeys[c.Skill / 16].Concat(oKeys[c.Skill % 16]).ToArray()).ToArray();
        var codeOut = z.Select(v => (IReadOnlyList<double>)v.Take(pca.Rank).ToArray()).ToArray();
        var plan = Mat.Ridge(wordIn, codeOut, 1e-3);
        var describe = Mat.Ridge(codeOut, wordIn, 1e-3);

        var planTop = new double[256]; var planPair = new double[256]; var planSoft = new double[256]; var planLin = new double[256];
        var planSlot = new double[256]; var planSlotPair = new double[256];
        // Role slots: three separate vectors per tuple [â; ô; ẑ] (3d floats), so a partial cue meets no crosstalk.
        var slotV = stored.Select(c => vKeys[c.Skill / 16]).ToArray();
        var slotO = stored.Select(c => oKeys[c.Skill % 16]).ToArray();
        var slotZ = z.Select(v => Mat.Normalize(v)).ToArray();
        for (int p = 0; p < 256; p++)
        {
            var a = roles.Apply(0, vKeys[p / 16]); var b = roles.Apply(1, oKeys[p % 16]);
            var q = Enumerable.Range(0, d).Select(i => a[i] + b[i]).ToArray();
            var s = keys.Select(k => Lin.Dot(q, k)).ToArray();
            int top = Array.IndexOf(s, s.Max());
            planTop[p] = Motor.Rms(Decode(z[top]), protos[p]);
            planPair[p] = stored[top].Skill == p ? 1 : 0;
            var w = Lin.Softmax(s.Select(v => Beta * v).ToArray());
            var mix = new double[d];
            for (int t = 0; t < keys.Length; t++) for (int i = 0; i < d; i++) mix[i] += w[t] * z[t][i];
            planSoft[p] = Motor.Rms(Decode(mix), protos[p]);
            planLin[p] = Motor.Rms(Decode(plan(vKeys[p / 16].Concat(oKeys[p % 16]).ToArray())), protos[p]);
            var ss = Enumerable.Range(0, stored.Length).Select(t => Lin.Dot(vKeys[p / 16], slotV[t]) + Lin.Dot(oKeys[p % 16], slotO[t])).ToArray();
            int st = Array.IndexOf(ss, ss.Max());
            planSlot[p] = Motor.Rms(Decode(z[st]), protos[p]);
            planSlotPair[p] = stored[st].Skill == p ? 1 : 0;
        }
        var add = AdditivePart(protos);
        double addFloor = Math.Sqrt(Enumerable.Range(0, 256).Average(p => { double e = Motor.Rms(add[p], protos[p]); return e * e; }));
        double execFloor = Math.Sqrt(stored.Average(c => { double e = Motor.Rms(c.X, protos[c.Skill]); return e * e; }));

        // Description of fresh executions.
        int ok = 0, okV = 0, okO = 0, lok = 0, lokV = 0, lokO = 0, sok = 0;
        for (int p = 0; p < 256; p++)
        {
            var fresh = Motor.Execute(p, protos[p], L, Rng.Derive(Seed, stream + 30_000UL + (ulong)p)).Value;
            var zf = Bf16.Round(Mat.Pad(pca.Encode(fresh.X), d));
            var q = roles.Apply(2, Mat.Normalize(zf));
            var s = keys.Select(k => Lin.Dot(q, k)).ToArray();
            int top = Array.IndexOf(s, s.Max());
            var uVerb = roles.Inverse(0, keys[top]); var uObj = roles.Inverse(1, keys[top]);
            int v = Enumerable.Range(0, 16).OrderByDescending(i => Lin.Dot(uVerb, vKeys[i])).First();
            int o = Enumerable.Range(0, 16).OrderByDescending(i => Lin.Dot(uObj, oKeys[i])).First();
            okV += v == p / 16 ? 1 : 0; okO += o == p % 16 ? 1 : 0; ok += v == p / 16 && o == p % 16 ? 1 : 0;
            var zfn = Mat.Normalize(zf);
            var sz = slotZ.Select(k => Lin.Dot(zfn, k)).ToArray();
            int stp = Array.IndexOf(sz, sz.Max());
            sok += stored[stp].Skill == p ? 1 : 0;
            var pred = describe(zf.Take(pca.Rank).ToArray());
            var pv = pred.Take(d).ToArray(); var po = pred.Skip(d).ToArray();
            int lv = Enumerable.Range(0, 16).OrderByDescending(i => Lin.Dot(pv, vKeys[i])).First();
            int lo = Enumerable.Range(0, 16).OrderByDescending(i => Lin.Dot(po, oKeys[i])).First();
            lokV += lv == p / 16 ? 1 : 0; lokO += lo == p % 16 ? 1 : 0; lok += lv == p / 16 && lo == p % 16 ? 1 : 0;
        }
        double R(double[] e) => Math.Sqrt(e.Average(x => x * x));
        return new Outcome(R(planTop), planPair.Average(), R(planSoft), R(planSlot), planSlotPair.Average(), R(planLin), addFloor, execFloor,
            ok / 256.0, okV / 256.0, okO / 256.0, sok / 256.0, lok / 256.0, lokV / 256.0, lokO / 256.0);
    }

    public static ExperimentResult Run(Lexicon lex)
    {
        foreach (var w in Verbs.Concat(Objects)) if (!lex.Contains(w)) throw new InvalidOperationException($"{w} not in lexicon");
        var h = new Dictionary<string, double>();
        var rows = new List<object[]>();
        foreach (double iota in new[] { 0.0, 0.25, 0.5, 1.0 })
        {
            var o = Evaluate(lex, iota, 128, (ulong)(iota * 1000) * 100_000UL);
            rows.Add(new object[] { iota, 128, o.ExecutionFloorRms, o.PlanTopRms, o.PlanTopPair, o.PlanSoftRms, o.PlanSlotRms, o.PlanSlotPair, o.PlanLinearRms, o.AdditiveFloorRms, o.DescTuple, o.DescTupleVerb, o.DescTupleObject, o.DescSlot, o.DescLinear, o.DescLinearVerb, o.DescLinearObject });
            string k = $"iota{iota}";
            h[$"{k}_exec_floor"] = o.ExecutionFloorRms; h[$"{k}_plan_top_rms"] = o.PlanTopRms; h[$"{k}_plan_top_pair"] = o.PlanTopPair; h[$"{k}_plan_soft_rms"] = o.PlanSoftRms;
            h[$"{k}_plan_linear_rms"] = o.PlanLinearRms; h[$"{k}_additive_floor"] = o.AdditiveFloorRms;
            h[$"{k}_plan_slot_rms"] = o.PlanSlotRms; h[$"{k}_plan_slot_pair"] = o.PlanSlotPair; h[$"{k}_desc_slot"] = o.DescSlot;
            h[$"{k}_desc_tuple"] = o.DescTuple; h[$"{k}_desc_linear"] = o.DescLinear; h[$"{k}_desc_linear_verb"] = o.DescLinearVerb; h[$"{k}_desc_linear_object"] = o.DescLinearObject;
        }
        foreach (int d in new[] { 32, 64, 256 })
        {
            var o = Evaluate(lex, 0.5, d, 7_000_000UL + (ulong)d);
            rows.Add(new object[] { 0.5, d, o.ExecutionFloorRms, o.PlanTopRms, o.PlanTopPair, o.PlanSoftRms, o.PlanSlotRms, o.PlanSlotPair, o.PlanLinearRms, o.AdditiveFloorRms, o.DescTuple, o.DescTupleVerb, o.DescTupleObject, o.DescSlot, o.DescLinear, o.DescLinearVerb, o.DescLinearObject });
            h[$"d{d}_desc_slot"] = o.DescSlot; h[$"d{d}_plan_slot_pair"] = o.PlanSlotPair;
            h[$"d{d}_plan_top_pair"] = o.PlanTopPair; h[$"d{d}_desc_tuple"] = o.DescTuple; h[$"d{d}_plan_top_rms"] = o.PlanTopRms;
        }
        var table = Table.Of("association", new[] { "interaction_share_iota", "width_d", "execution_floor_rms", "plan_tuple_top1_rms", "plan_tuple_top1_right_pair", "plan_tuple_soft_rms", "plan_role_slots_rms", "plan_role_slots_right_pair", "plan_linear_map_rms", "additive_floor_rms",
            "describe_tuple_both", "describe_tuple_verb", "describe_tuple_object", "describe_role_slots_both", "describe_linear_both", "describe_linear_verb", "describe_linear_object" }, rows);
        return new ExperimentResult("M04", "Association between words and actions", new[] { table }, h);
    }
}
