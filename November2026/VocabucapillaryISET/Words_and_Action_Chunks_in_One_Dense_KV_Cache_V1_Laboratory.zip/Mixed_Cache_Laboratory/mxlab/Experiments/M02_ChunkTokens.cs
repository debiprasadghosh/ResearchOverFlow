using MxLab.Core;

namespace MxLab.Experiments;

/// <summary>
/// One dense token per action chunk. A library of 64 skills for seven joints; chunks of L = 4–32 control steps.
/// Encoders: bound motor characters (training-free, invertible), per-step slots (L vectors), a learned linear ISET
/// (principal components of 4,096 training chunks) and a training-free DCT encoder. Retrieval of the exact chunk among
/// eight executions of the same skill and 247 others under query noise; reconstruction from the stored BF16 code against
/// a motor tolerance (the write-time confidence check); key smoothness; rank; and encoder staleness.
/// </summary>
public static class M02_ChunkTokens
{
    private const ulong Seed = 202;
    public const int Skills = 64, TrainPerSkill = 64, PoolPerSkill = 32, History = 256, NearDup = 8, Trials = 1000;
    public const double Tol = 0.04, TightTol = 0.02;
    public static readonly string[] Encoders = { "bound characters", "per-step slots", "learned linear ISET", "DCT" };

    public sealed record Data(int L, IReadOnlyList<Motor.Skill> Lib, IReadOnlyList<Motor.Chunk> Train, IReadOnlyList<Motor.Chunk> Pool, IReadOnlyList<Motor.Chars> PoolChars);
    public sealed record Encoded(string Name, int Floats, int Rank, IReadOnlyList<IReadOnlyList<double>> Keys, IReadOnlyList<IReadOnlyList<double>> Recon,
        IReadOnlyList<bool>? Spelled, Func<Motor.Chunk, IReadOnlyList<double>> Key);
    public sealed record ReconStats(double Rms, double RmsClean, double RmsContact, double Pass, double PassClean, double PassContact, double PassTight, double Spelled);

    public static Data Make(int L, ulong seed = Seed)
    {
        var lib = Motor.Library(Skills, seed);
        IReadOnlyList<Motor.Chunk> Gen(int perSkill, ulong stream) => Enumerable.Range(0, Skills * perSkill).AsParallel().AsOrdered()
            .Select(i => Motor.Execute(lib[i / perSkill], L, Rng.Derive(seed, stream + (ulong)(L * 100_000 + i))).Value).ToArray();
        var train = Gen(TrainPerSkill, 1_000_000_000UL);
        var pool = Gen(PoolPerSkill, 2_000_000_000UL);
        return new Data(L, lib, train, pool, pool.Select(c => Motor.Characters(c.X, L)).ToArray());
    }

    /// <summary>The four encoders at width d; every stored code is rounded to BF16 before it is scored or decoded.</summary>
    public static IReadOnlyList<Encoded> Encode(Data data, int d, ulong seed = Seed)
    {
        int L = data.L;
        var bound = BoundChunk.Create(d, L, Rng.Derive(seed, (ulong)(10 + d)));
        var slots = StepSlots.Create(d, Rng.Derive(seed, (ulong)(20 + d)));
        var pca = LinearIset.Fit(data.Train.Select(c => c.X).ToArray(), Math.Min(d, Motor.Dof * L));
        var dct = new DctIset(L, Math.Min(L, d / Motor.Dof));
        Func<Motor.Chunk, IReadOnlyList<double>> bKey = c => Bf16.Round(bound.Encode(Motor.Characters(c.X, L).Symbols, L));
        Func<Motor.Chunk, IReadOnlyList<double>> sKey = c => Bf16.Round(slots.Encode(Motor.Characters(c.X, L).Symbols, L));
        Func<Motor.Chunk, IReadOnlyList<double>> pKey = c => Bf16.Round(Mat.Pad(pca.Encode(c.X), d));
        Func<Motor.Chunk, IReadOnlyList<double>> cKey = c => Bf16.Round(Mat.Pad(dct.Encode(c.X), d));
        var bKeys = data.Pool.AsParallel().AsOrdered().Select(bKey).ToArray();
        var bDec = bKeys.AsParallel().AsOrdered().Select(k => bound.Decode(k, L)).ToArray();
        var sKeys = data.Pool.AsParallel().AsOrdered().Select(sKey).ToArray();
        var sDec = sKeys.AsParallel().AsOrdered().Select(k => slots.Decode(k, L)).ToArray();
        var pKeys = data.Pool.AsParallel().AsOrdered().Select(pKey).ToArray();
        var cKeys = data.Pool.AsParallel().AsOrdered().Select(cKey).ToArray();
        return new[]
        {
            new Encoded(Encoders[0], d, d, bKeys, bDec.Select(s => Motor.FromCharacters(s, L)).ToArray(), bDec.Select((s, i) => s.SequenceEqual(data.PoolChars[i].Symbols)).ToArray(), bKey),
            new Encoded(Encoders[1], L * d, L * d, sKeys, sDec.Select(s => Motor.FromCharacters(s, L)).ToArray(), sDec.Select((s, i) => s.SequenceEqual(data.PoolChars[i].Symbols)).ToArray(), sKey),
            new Encoded(Encoders[2], d, pca.Rank, pKeys, pKeys.Select(k => pca.Decode(k.Take(pca.Rank).ToArray())).ToArray(), null, pKey),
            new Encoded(Encoders[3], d, dct.Rank, cKeys, cKeys.Select(k => dct.Decode(k.Take(dct.Rank).ToArray())).ToArray(), null, cKey),
        };
    }

    public static ReconStats Recon(IReadOnlyList<Motor.Chunk> truth, IReadOnlyList<IReadOnlyList<double>> recon, IReadOnlyList<bool>? spelled)
    {
        var e = truth.Select((c, i) => Motor.Rms(c.X, recon[i])).ToArray();
        var clean = Enumerable.Range(0, e.Length).Where(i => truth[i].Contacts == 0).ToArray();
        var contact = Enumerable.Range(0, e.Length).Where(i => truth[i].Contacts > 0).ToArray();
        double Rms(IEnumerable<int> idx) { var a = idx.ToArray(); return a.Length == 0 ? double.NaN : Math.Sqrt(a.Average(i => e[i] * e[i])); }
        double Pass(IEnumerable<int> idx, double tol) { var a = idx.ToArray(); return a.Length == 0 ? double.NaN : a.Average(i => e[i] <= tol ? 1.0 : 0.0); }
        var all = Enumerable.Range(0, e.Length);
        return new ReconStats(Rms(all), Rms(clean), Rms(contact), Pass(all, Tol), Pass(clean, Tol), Pass(contact, Tol), Pass(all, TightTol),
            spelled is null ? double.NaN : spelled.Average(s => s ? 1.0 : 0.0));
    }

    /// <summary>A history of 256 pool indices: the target, eight other executions of its skill, 247 chunks of other skills.</summary>
    public static IReadOnlyList<int> MakeHistory(Data data, Rng rng)
    {
        int n = data.Pool.Count;
        var (target, r) = rng.NextInt(n);
        int skill = data.Pool[target].Skill;
        var same = Enumerable.Range(skill * PoolPerSkill, PoolPerSkill).Where(i => i != target).ToArray();
        for (int i = 0; i < NearDup; i++) { var (k, nr) = r.NextInt(same.Length - i); r = nr; (same[i], same[i + k]) = (same[i + k], same[i]); }
        var hist = new List<int> { target };
        hist.AddRange(same.Take(NearDup));
        var used = new HashSet<int>(hist);
        while (hist.Count < History)
        {
            var (k, nr) = r.NextInt(n); r = nr;
            if (data.Pool[k].Skill == skill || !used.Add(k)) continue;
            hist.Add(k);
        }
        return hist;
    }

    public sealed record Retrieval(double AddressExact, double AddressWithin, double SimilarNearest, double SimilarWithin, double SimilarNearestCosine, double SimilarSkill);

    /// <summary>Distance score q·k − ‖k‖²/2 (nearest key in Euclidean distance; one extra key dimension in a transformer).</summary>
    public static double L2Score(IReadOnlyList<double> q, IReadOnlyList<double> k) => Lin.Dot(q, k) - 0.5 * Lin.Norm2(k);

    public static double CosScore(IReadOnlyList<double> q, IReadOnlyList<double> k) => Lin.Dot(q, k) / Math.Sqrt(Lin.Norm2(k));

    static int Top(IReadOnlyList<double> s, out bool unique)
    {
        double best = s.Max();
        unique = s.Count(v => v == best) == 1;
        return s.ToList().IndexOf(best);
    }

    /// <summary>
    /// Address task: the query is the target's own stored code plus relative noise σ; success is the exact target.
    /// Similar-motion task: the query is the code of a fresh execution of the target's skill; success is the stored chunk
    /// nearest to that execution in joint space (RMS), or any chunk within the tolerance of it.
    /// </summary>
    public static Retrieval Retrieve(Data data, Encoded enc, double sigma, int trials, ulong stream)
    {
        var outs = Enumerable.Range(0, trials).AsParallel().AsOrdered().Select(i =>
        {
            var hist = MakeHistory(data, Rng.Derive(Seed, stream + (ulong)i));
            int target = hist[0];
            var keys = hist.Select(k => enc.Keys[k]).ToArray();
            var (q, _) = Mat.RelNoise(enc.Keys[target], sigma, Rng.Derive(Seed, stream + 7_000_000UL + (ulong)i));
            int a = Top(keys.Select(k => L2Score(q, k)).ToArray(), out bool ua);
            var fresh = Motor.Execute(data.Lib[data.Pool[target].Skill], data.L, Rng.Derive(Seed, stream + 9_000_000UL + (ulong)i)).Value;
            var qf = enc.Key(fresh);
            var dist = hist.Select(k => Motor.Rms(data.Pool[k].X, fresh.X)).ToArray();
            int nearest = Array.IndexOf(dist, dist.Min());
            int b = Top(keys.Select(k => L2Score(qf, k)).ToArray(), out _);
            int c = Top(keys.Select(k => CosScore(qf, k)).ToArray(), out _);
            return (aExact: a == 0 && ua, aWithin: Motor.Rms(data.Pool[hist[a]].X, data.Pool[target].X) <= Tol,
                bNear: b == nearest, bWithin: dist[b] <= Tol, cNear: c == nearest, bSkill: data.Pool[hist[b]].Skill == data.Pool[target].Skill);
        }).ToArray();
        double Avg(Func<(bool aExact, bool aWithin, bool bNear, bool bWithin, bool cNear, bool bSkill), bool> f) => outs.Average(o => f(o) ? 1.0 : 0.0);
        return new Retrieval(Avg(o => o.aExact), Avg(o => o.aWithin), Avg(o => o.bNear), Avg(o => o.bWithin), Avg(o => o.cNear), Avg(o => o.bSkill));
    }

    public static ExperimentResult Run(Lexicon _)
    {
        var h = new Dictionary<string, double>();
        var main = new List<object[]>();
        var recRows = new List<object[]>();
        var datasets = new Dictionary<int, Data>();
        void Setting(int L, int d, IReadOnlyList<double> sigmas)
        {
            if (!datasets.TryGetValue(L, out var data)) datasets[L] = data = Make(L);
            var encs = Encode(data, d);
            foreach (var enc in encs)
            {
                var rs = Recon(data.Pool, enc.Recon, enc.Spelled);
                recRows.Add(new object[] { L, d, enc.Name, enc.Floats, enc.Rank, rs.Rms, rs.RmsClean, rs.RmsContact, rs.Pass, rs.PassClean, rs.PassContact, rs.PassTight, rs.Spelled });
                string key = $"L{L}_d{d}_{enc.Name.Replace(" ", "_").Replace("-", "")}";
                h[$"{key}_rms"] = rs.Rms; h[$"{key}_pass"] = rs.Pass; h[$"{key}_pass_clean"] = rs.PassClean; h[$"{key}_pass_contact"] = rs.PassContact; h[$"{key}_pass_tight"] = rs.PassTight;
                if (!double.IsNaN(rs.Spelled)) h[$"{key}_spelled"] = rs.Spelled;
                foreach (double sigma in sigmas)
                {
                    var rt = Retrieve(data, enc, sigma, Trials, (ulong)(40_000_000 + L * 100_000 + d * 10 + (int)(sigma * 100) * 1000));
                    main.Add(new object[] { L, d, sigma, enc.Name, enc.Floats, rt.AddressExact, rt.AddressWithin, rt.SimilarNearest, rt.SimilarWithin, rt.SimilarNearestCosine, rt.SimilarSkill });
                    string ks = $"{key}_s{sigma:0.00}";
                    h[$"{ks}_address_exact"] = rt.AddressExact; h[$"{ks}_address_within"] = rt.AddressWithin;
                    h[$"{ks}_similar_nearest"] = rt.SimilarNearest; h[$"{ks}_similar_within"] = rt.SimilarWithin; h[$"{ks}_similar_nearest_cos"] = rt.SimilarNearestCosine; h[$"{ks}_similar_skill"] = rt.SimilarSkill;
                }
            }
            h[$"L{L}_contact_share"] = data.Pool.Average(c => c.Contacts > 0 ? 1.0 : 0);
            h[$"L{L}_char_floor_rms"] = Math.Sqrt(data.Pool.Average(c => { double e = Motor.Rms(c.X, Motor.Characters(c.X, L).Recon); return e * e; }));
            h[$"L{L}_char_floor_pass"] = data.Pool.Average(c => Motor.Rms(c.X, Motor.Characters(c.X, L).Recon) <= Tol ? 1.0 : 0);
            h[$"L{L}_signal_rms"] = Math.Sqrt(data.Pool.Average(c => c.X.Average(v => v * v)));
            h[$"L{L}_neardup_rms"] = data.Pool.Take(400).Average(c => data.Pool.Where(o => o.Skill == c.Skill && !ReferenceEquals(o, c)).Average(o => Motor.Rms(o.X, c.X)));
            h[$"L{L}_neardup_within_share"] = data.Pool.Take(400).Average(c => data.Pool.Where(o => o.Skill == c.Skill && !ReferenceEquals(o, c)).Average(o => Motor.Rms(o.X, c.X) <= Tol ? 1.0 : 0));
        }
        foreach (int L in new[] { 4, 8, 16, 32 }) Setting(L, 128, L == 8 ? new[] { 0.25, 0.5, 1.0 } : new[] { 0.5 });
        foreach (int d in new[] { 64, 256 }) Setting(16, d, new[] { 0.5 });

        // Rank: reconstruction of 16-step chunks (112 values) from r learned or DCT coefficients.
        var rankRows = new List<object[]>();
        var d16 = datasets[16];
        var full = LinearIset.Fit(d16.Train.Select(c => c.X).ToArray(), 112);
        foreach (int k in new[] { 2, 4, 8, 16 })
        {
            int r = Motor.Dof * k;
            var pca = full.Truncate(r);
            var dct = new DctIset(16, k);
            var pr = Recon(d16.Pool, d16.Pool.Select(c => pca.Decode(Bf16.Round(pca.Encode(c.X)))).ToArray(), null);
            var cr = Recon(d16.Pool, d16.Pool.Select(c => dct.Decode(Bf16.Round(dct.Encode(c.X)))).ToArray(), null);
            rankRows.Add(new object[] { r, "learned linear ISET", pr.Rms, pr.RmsClean, pr.RmsContact, pr.Pass, pr.PassClean, pr.PassContact, pr.PassTight });
            rankRows.Add(new object[] { r, "DCT", cr.Rms, cr.RmsClean, cr.RmsContact, cr.Pass, cr.PassClean, cr.PassContact, cr.PassTight });
            h[$"rank{r}_pca_rms"] = pr.Rms; h[$"rank{r}_pca_pass"] = pr.Pass; h[$"rank{r}_pca_pass_clean"] = pr.PassClean; h[$"rank{r}_pca_pass_contact"] = pr.PassContact;
            h[$"rank{r}_dct_rms"] = cr.Rms; h[$"rank{r}_dct_pass"] = cr.Pass; h[$"rank{r}_dct_pass_clean"] = cr.PassClean; h[$"rank{r}_dct_pass_contact"] = cr.PassContact;
        }
        double energy = full.Eigen.Sum();
        foreach (int r in new[] { 7, 14, 28, 56 }) h[$"pca_energy_top{r}"] = full.Eigen.Take(r).Sum() / energy;

        // Staleness and coverage: encoders fitted on skills 0–31 (v1) and refitted on all 64 (v2), at ranks 28 and 56;
        // codes written by v1 and read by v2 without re-encoding.
        var oldTrain = d16.Train.Where(c => c.Skill < Skills / 2).Select(c => c.X).ToArray();
        var allTrain = d16.Train.Select(c => c.X).ToArray();
        var oldPool = d16.Pool.Where(c => c.Skill < Skills / 2).ToArray();
        var newPool = d16.Pool.Where(c => c.Skill >= Skills / 2).ToArray();
        var stale = new List<object[]>();
        foreach (int rank in new[] { 28, 56 })
        {
            var v1 = LinearIset.Fit(oldTrain, rank);
            var v2 = LinearIset.Fit(allTrain, rank);
            var dct = new DctIset(16, rank / Motor.Dof);
            void S(string label, string tag, IReadOnlyList<Motor.Chunk> set, Func<Motor.Chunk, IReadOnlyList<double>> codec)
            {
                var rs = Recon(set, set.Select(codec).ToArray(), null);
                stale.Add(new object[] { rank, label, rs.Rms, rs.Pass, rs.PassClean, rs.PassContact });
                h[$"stale_r{rank}_{tag}_rms"] = rs.Rms; h[$"stale_r{rank}_{tag}_pass"] = rs.Pass;
            }
            S("v1 (skills 0–31), chunks of those skills", "v1_old", oldPool, c => v1.Decode(Bf16.Round(v1.Encode(c.X))));
            S("v1, chunks of the 32 new skills", "v1_new", newPool, c => v1.Decode(Bf16.Round(v1.Encode(c.X))));
            S("v2 (all 64 skills), old chunks re-encoded", "v2_old", oldPool, c => v2.Decode(Bf16.Round(v2.Encode(c.X))));
            S("v2, new chunks", "v2_new", newPool, c => v2.Decode(Bf16.Round(v2.Encode(c.X))));
            S("old codes written by v1, read by v2", "stale", oldPool, c => v2.Decode(Bf16.Round(v1.Encode(c.X))));
            S("DCT (training-free), old chunks", "dct_old", oldPool, c => dct.Decode(Bf16.Round(dct.Encode(c.X))));
            S("DCT (training-free), new chunks", "dct_new", newPool, c => dct.Decode(Bf16.Round(dct.Encode(c.X))));
            h[$"stale_r{rank}_basis_overlap"] = Enumerable.Range(0, rank).Average(i => Math.Abs(Lin.Dot(v1.Basis[i], v2.Basis[i])));
        }

        var tMain = Table.Of("retrieval", new[] { "steps_L", "width_d", "noise_sigma", "encoder", "floats_per_chunk", "address_exact", "address_within_tolerance", "similar_nearest_l2", "similar_within_tolerance_l2", "similar_nearest_cosine", "similar_same_skill_l2" }, main);
        var tRec = Table.Of("reconstruction", new[] { "steps_L", "width_d", "encoder", "floats_per_chunk", "code_rank", "rms_all", "rms_no_contact", "rms_contact", "pass_0.04_all", "pass_0.04_no_contact", "pass_0.04_contact", "pass_0.02_all", "spelled_exactly" }, recRows);
        var tRank = Table.Of("rank", new[] { "code_rank_r", "encoder", "rms_all", "rms_no_contact", "rms_contact", "pass_0.04_all", "pass_0.04_no_contact", "pass_0.04_contact", "pass_0.02_all" }, rankRows);
        var tStale = Table.Of("staleness", new[] { "code_rank_r", "case", "rms", "pass_0.04_all", "pass_0.04_no_contact", "pass_0.04_contact" }, stale);
        return new ExperimentResult("M02", "Dense tokens for action chunks", new[] { tMain, tRec, tRank, tStale }, h);
    }
}
