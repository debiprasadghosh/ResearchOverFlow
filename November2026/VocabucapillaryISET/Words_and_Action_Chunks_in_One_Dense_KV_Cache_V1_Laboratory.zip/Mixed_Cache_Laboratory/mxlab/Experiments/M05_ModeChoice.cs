using MxLab.Core;

namespace MxLab.Experiments;

/// <summary>
/// Passing an obstacle on the left or the right (the two-way task of the cerebellum paper) read from a dense cache. 512
/// stored executions share one cue: each key is the cue as written in its episode's context, each value the action code
/// (learned linear ISET).
/// A soft attention read blends the two modes and collides unless it is effectively hard; choosing a mode first and then
/// reading softly within it never collides and still produces new trajectories.
/// </summary>
public static class M05_ModeChoice
{
    private const ulong Seed = 505;
    public const int T = 16, Stored = 512, Queries = 1000, D = 128;
    public const double Sigma = 0.5, WithinBeta = 10.0;

    public static (IReadOnlyList<double> Y, int Mode) Trajectory(Rng rng)
    {
        var (u, r1) = rng.NextDouble();
        var (ga, r2) = r1.NextGaussian();
        int mode = u < 0.5 ? 1 : -1;
        double amp = 1 + 0.1 * ga;
        var y = new double[T];
        var r = r2;
        for (int t = 0; t < T; t++) { var (g, nr) = r.NextGaussian(); r = nr; y[t] = mode * amp * Math.Sin(Math.PI * (t + 1) / (T + 1)) + 0.02 * g; }
        return (y, mode);
    }

    static readonly double[] Shape = Enumerable.Range(0, T).Select(t => Math.Sin(Math.PI * (t + 1) / (T + 1))).ToArray();
    public static bool Collides(IReadOnlyList<double> y) => Enumerable.Range(5, 6).Any(t => Math.Abs(y[t]) < 0.3);

    public static double OffManifold(IReadOnlyList<double> y)
    {
        double ss = Shape.Sum(v => v * v), proj = Lin.Dot(y, Shape) / ss;
        return new[] { 1.0, -1.0 }.Min(mode =>
        {
            double a = mode * Math.Clamp(mode * proj, 0.7, 1.3);
            return y.Select((v, t) => (v - a * Shape[t]) * (v - a * Shape[t])).Sum() / T;
        });
    }

    static double Dist(IReadOnlyList<double> a, IReadOnlyList<double> b) => Math.Sqrt(a.Select((v, t) => (v - b[t]) * (v - b[t])).Sum());

    public static ExperimentResult Run(Lexicon lex)
    {
        var h = new Dictionary<string, double>();
        var data = Enumerable.Range(0, Stored).Select(i => Trajectory(Rng.Derive(Seed, (ulong)i))).ToArray();
        var ys = data.Select(x => x.Y).ToArray();
        var modes = data.Select(x => x.Mode).ToArray();
        var pca = LinearIset.Fit(ys, T);
        var z = ys.Select(y => Bf16.Round(Mat.Pad(pca.Encode(y), D))).ToArray();
        IReadOnlyList<double> Decode(IReadOnlyList<double> c) => pca.Decode(c.Take(T).ToArray());
        var code = CharCode.Random(D, Rng.Derive(Seed, 1_000_001));
        var bind = Binder.Create(D, Sym.L + 1, Rng.Derive(Seed, 1_000_002));
        var roles = Binder.Create(D, 2, Rng.Derive(Seed, 1_000_003));
        var cue = Mat.Normalize(Layout.Bound("around", code, bind));
        var cueBound = roles.Apply(0, cue);
        // Keys hold the cue as written in each episode's context (relative variation σ at write time); values hold the
        // action code. The key carries no information about the action, so neither mode is favoured.
        var keys = Enumerable.Range(0, Stored).Select(i => Bf16.Round(Mat.RelNoise(cueBound, Sigma, Rng.Derive(Seed, 4_000_000UL + (ulong)i)).Value)).ToArray();
        double spacing = ys.Take(200).Select((a, i) => ys.Where((b, j) => j != i).Min(b => Dist(a, b))).Average();
        var unpadded = z.Select(c => (IReadOnlyList<double>)c.Take(T).ToArray()).ToArray();
        var (cent2, asg2) = Mat.KMeans(unpadded, 2, Rng.Derive(Seed, 2_000_002));
        var (cent8, asg8) = Mat.KMeans(unpadded, 8, Rng.Derive(Seed, 2_000_008));
        h["cluster2_purity"] = Enumerable.Range(0, 2).Sum(c => Math.Max(Enumerable.Range(0, Stored).Count(i => asg2[i] == c && modes[i] == 1), Enumerable.Range(0, Stored).Count(i => asg2[i] == c && modes[i] == -1))) / (double)Stored;
        h["cluster8_purity"] = Enumerable.Range(0, 8).Sum(c => Math.Max(Enumerable.Range(0, Stored).Count(i => asg8[i] == c && modes[i] == 1), Enumerable.Range(0, Stored).Count(i => asg8[i] == c && modes[i] == -1))) / (double)Stored;
        h["spacing"] = spacing;
        h["left_share_stored"] = modes.Average(m => m == 1 ? 1.0 : 0);

        // Per query: scores, then every reader.
        var readers = new List<string>();
        var perQuery = Enumerable.Range(0, Queries).AsParallel().AsOrdered().Select(qi =>
        {
            var (q, r1) = Mat.RelNoise(cueBound, Sigma, Rng.Derive(Seed, 3_000_000UL + (ulong)qi));
            var s = keys.Select(k => Lin.Dot(q, k)).ToArray();
            var outs = new List<(string Name, IReadOnlyList<double> Y, double Minor)>();
            IReadOnlyList<double> Blend(IReadOnlyList<double> w, IEnumerable<int> idx)
            {
                var ids = idx.ToArray(); double tot = ids.Sum(i => w[i]);
                var m = new double[D];
                foreach (int i in ids) for (int k = 0; k < D; k++) m[k] += w[i] / tot * z[i][k];
                return Decode(m);
            }
            double MinorMass(IReadOnlyList<double> w) { double left = Enumerable.Range(0, Stored).Where(i => modes[i] == 1).Sum(i => w[i]); return Math.Min(left, 1 - left); }
            var uniform = Enumerable.Repeat(1.0 / Stored, Stored).ToArray();
            outs.Add(("overall mean (β = 0)", Blend(uniform, Enumerable.Range(0, Stored)), 0.5));
            foreach (double beta in new[] { 10.0, 30.0, 100.0, 300.0 })
            {
                var w = Lin.Softmax(s.Select(v => beta * v).ToArray());
                outs.Add(($"soft read, β = {beta}", Blend(w, Enumerable.Range(0, Stored)), MinorMass(w)));
            }
            int top = Array.IndexOf(s, s.Max());
            outs.Add(("hard top-1 read", Decode(z[top]), 0));
            var wb = Lin.Softmax(s.Select(v => WithinBeta * v).ToArray());
            foreach (var (k, asg, cents) in new[] { (2, asg2, cent2), (8, asg8, cent8) })
            {
                var mass = Enumerable.Range(0, k).Select(c => Enumerable.Range(0, Stored).Where(i => asg[i] == c).Sum(i => wb[i])).ToArray();
                int best = Array.IndexOf(mass, mass.Max());
                outs.Add(($"mode first (K = {k}), then soft within", Blend(wb, Enumerable.Range(0, Stored).Where(i => asg[i] == best)), 0));
                var (pick, _) = r1.NextCategorical(mass);
                outs.Add(($"sampled mode (K = {k}), then soft within", Blend(wb, Enumerable.Range(0, Stored).Where(i => asg[i] == pick)), 0));
                outs.Add(($"prototype only (K = {k})", Decode(Mat.Pad(cents[best], D)), 0));
            }
            return outs;
        }).ToArray();
        var names = perQuery[0].Select(o => o.Name).ToArray();
        var rows = new List<object[]>();
        foreach (var name in names)
        {
            var ysOut = perQuery.Select(o => o.First(x => x.Name == name)).ToArray();
            double coll = ysOut.Average(o => Collides(o.Y) ? 1.0 : 0);
            double off = Math.Sqrt(ysOut.Average(o => OffManifold(o.Y)));
            double nov = ysOut.Take(200).Average(o => ys.Min(b => Dist(o.Y, b))) / spacing;
            double left = ysOut.Average(o => Lin.Dot(o.Y, Shape) > 0 ? 1.0 : 0);
            rows.Add(new object[] { name, coll, off, nov, left });
            string key = name.Replace(" ", "_").Replace(",", "").Replace("=", "").Replace("(", "").Replace(")", "").Replace("-", "");
            h[$"{key}_collision"] = coll; h[$"{key}_offmanifold"] = off; h[$"{key}_novelty"] = nov; h[$"{key}_left"] = left;
            if (name.StartsWith("soft read"))
            {
                var collided = ysOut.Where(o => Collides(o.Y)).Select(o => o.Minor).ToArray();
                var clear = ysOut.Where(o => !Collides(o.Y)).Select(o => o.Minor).ToArray();
                if (collided.Length > 0) h[$"{key}_min_minor_mass_collided"] = collided.Min();
                if (clear.Length > 0) h[$"{key}_max_minor_mass_clear"] = clear.Max();
                h[$"{key}_mean_minor_mass"] = ysOut.Average(o => o.Minor);
            }
        }
        var table = Table.Of("mode_choice", new[] { "reader", "collision_rate", "off_manifold_rms", "nearest_stored_over_spacing", "left_share" }, rows);
        // Example outputs for the first query, beside one stored execution of each mode, for the figure.
        int li = Array.IndexOf(modes, 1), ri = Array.IndexOf(modes, -1);
        var show = new[] { "soft read, β = 10", "soft read, β = 100", "hard top-1 read", "mode first (K = 2), then soft within" };
        var ex = Enumerable.Range(0, T).Select(t => (IReadOnlyList<object>)new object[] { t, ys[li][t], ys[ri][t] }
            .Concat(show.Select(n => (object)perQuery[0].First(o => o.Name == n).Y[t])).ToArray()).ToArray();
        var examples = Table.Of("examples", new[] { "step", "stored_left", "stored_right", "soft_beta10", "soft_beta100", "hard_top1", "mode_first_k2" }, ex);
        return new ExperimentResult("M05", "Choosing a mode before reading", new[] { table, examples }, h);
    }
}
