using MxLab.Core;

namespace MxLab.Experiments;

/// <summary>
/// Exact accounting for one minute of a mixed stream: speech at 2.5 words per second (English word lengths from the
/// lexicon) beside a seven-joint body stream at 50, 200 or 1,000 control steps per second. Positions, body share of the
/// softmax, causal query–key pairs and cache bytes per head and layer (width 128, BF16 key and value) for character,
/// step, word and chunk tokens; and the storage of one chunk as vectors or as raw motor characters.
/// </summary>
public static class M00_Accounting
{
    public const int D = 128, BytesPerValue = 2, BitsPerMotorChar = 4;
    public const double WordsPerSecond = 2.5, Seconds = 60;
    public static readonly int[] Rates = { 50, 200, 1000 };
    public static readonly int[] ChunkLengths = { 4, 8, 16, 32 };

    public static double Pairs(double n) => n * (n + 1) / 2;

    public static ExperimentResult Run(Lexicon lex)
    {
        double letters = lex.Words.Select((w, i) => lex.Prob[i] * w.Length).Sum();
        double slots = letters + 1;
        double words = WordsPerSecond * Seconds;
        double vecBytes = 2.0 * D * BytesPerValue;
        var h = new Dictionary<string, double> { ["letters_per_word"] = letters, ["slots_per_word"] = slots, ["words_per_minute"] = words, ["bytes_per_token"] = vecBytes };

        // One minute at 50 Hz under each tokenization.
        const int rate = 50;
        double steps = rate * Seconds;
        var schemes = new List<(string Word, double NWord, string Body, double NBody)>
        {
            ("characters", words * slots, "motor characters (one token per joint and step)", steps * Motor.Dof),
            ("characters", words * slots, "one token per control step", steps),
            ("words", words, "one token per control step", steps),
        };
        foreach (int L in ChunkLengths) schemes.Add(("words", words, $"chunks of {L} steps", steps / L));
        double basePairs = Pairs(schemes[0].NWord + schemes[0].NBody);
        var rows = new List<object[]>();
        foreach (var s in schemes)
        {
            double n = s.NWord + s.NBody;
            rows.Add(new object[] { s.Word, s.Body, s.NWord, s.NBody, s.NBody / n, Pairs(n), basePairs / Pairs(n), n * vecBytes });
            string key = $"{s.Word}_{s.Body.Replace(" ", "_").Replace("(", "").Replace(")", "")}";
            h[$"{key}_tokens"] = n; h[$"{key}_body_share"] = s.NBody / n; h[$"{key}_pairs"] = Pairs(n); h[$"{key}_pair_ratio"] = basePairs / Pairs(n); h[$"{key}_bytes"] = n * vecBytes;
        }
        var minute = Table.Of("minute", new[] { "word_scheme", "body_scheme", "word_positions", "body_positions", "body_share", "causal_pairs", "pair_reduction_vs_characters", "kv_bytes_per_head_layer" }, rows);

        // Rates: body tokens per word.
        var rateRows = new List<object[]>();
        foreach (int hz in Rates)
        {
            foreach (int L in new[] { 1, 8, 16 })
            {
                double perSecond = hz / (double)L;
                rateRows.Add(new object[] { hz, L, perSecond, perSecond / WordsPerSecond, perSecond / (perSecond + WordsPerSecond), 1000.0 * L / hz });
                h[$"hz{hz}_L{L}_body_per_word"] = perSecond / WordsPerSecond;
                h[$"hz{hz}_L{L}_body_share"] = perSecond / (perSecond + WordsPerSecond);
            }
        }
        var rates = Table.Of("rates", new[] { "control_rate_hz", "steps_per_token", "body_tokens_per_second", "body_tokens_per_word", "body_share", "token_duration_ms" }, rateRows);

        // Body-body pairs fall by L² when L steps share one token.
        double stepPairs = Pairs(steps);
        foreach (int L in ChunkLengths) h[$"body_pair_reduction_L{L}"] = stepPairs / Pairs(steps / L);

        // Storage of one chunk: vectors against raw characters.
        var store = ChunkLengths.Select(L => new object[] { L, vecBytes, L * vecBytes, Motor.Dof * L * BitsPerMotorChar / 8.0, vecBytes / (Motor.Dof * L * BitsPerMotorChar / 8.0) }).ToArray();
        foreach (int L in ChunkLengths) h[$"raw_chunk_bytes_L{L}"] = Motor.Dof * L * BitsPerMotorChar / 8.0;
        var storage = Table.Of("chunk_storage", new[] { "steps_L", "pooled_vector_kv_bytes", "step_slots_kv_bytes", "raw_motor_character_bytes", "pooled_over_raw" }, store);
        return new ExperimentResult("M00", "Accounting for a mixed stream", new[] { minute, rates, storage }, h);
    }
}
