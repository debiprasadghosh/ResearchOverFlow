using MxLab.Core;

namespace MxLab.Experiments;

/// <summary>
/// Exact and Monte Carlo checks: (1) crosstalk of S symbols bound into one vector by signed permutations, variance
/// S(S − 1)/d, for word keys (S ≈ 5–6), role-bound tuples (S = 3) and action chunks (S = 7L); (2) the per-slot readout
/// error of a bound chunk code against a Gaussian approximation; (3) identities of a mixed softmax: modality mass,
/// log-count bias, norm scaling as temperature; (4) the blend band of two mirror-image action modes.
/// </summary>
public static class M01_Exact
{
    private const ulong Seed = 101;
    public const int Samples = 2000;
    public static readonly int[] Symbols = { 3, 7, 28, 56, 112 };
    public static readonly int[] Widths = { 64, 128, 256 };

    public static ExperimentResult Run(Lexicon lex)
    {
        var h = new Dictionary<string, double>();
        var crossRows = new List<object[]>();
        foreach (int d in Widths)
            foreach (int s in Symbols)
            {
                var binder = Binder.Create(d, s, Rng.Derive(Seed, (ulong)(d * 1000 + s)));
                var diffs = Enumerable.Range(0, Samples).AsParallel().AsOrdered().Select(i =>
                {
                    var r = Rng.Derive(Seed, (ulong)(1_000_000 + d * 100_000 + s * 1000 + i));
                    var q = new double[d]; var k = new double[d]; double aligned = 0;
                    for (int j = 0; j < s; j++)
                    {
                        var (a, r1) = Lin.Gaussians(r, d); var (b, r2) = Lin.Gaussians(r1, d); r = r2;
                        var an = Mat.Normalize(a); var bn = Mat.Normalize(b);
                        aligned += Lin.Dot(an, bn);
                        var ra = binder.Apply(j, an); var rb = binder.Apply(j, bn);
                        for (int t = 0; t < d; t++) { q[t] += ra[t]; k[t] += rb[t]; }
                    }
                    return Lin.Dot(q, k) - aligned;
                }).ToArray();
                double mean = diffs.Average();
                double sd = Math.Sqrt(diffs.Sum(x => (x - mean) * (x - mean)) / (diffs.Length - 1));
                double theory = Math.Sqrt(s * (s - 1.0) / d);
                crossRows.Add(new object[] { d, s, mean, sd, theory, sd / theory });
                h[$"cross_d{d}_S{s}_sd"] = sd; h[$"cross_d{d}_S{s}_ratio"] = sd / theory;
            }
        var cross = Table.Of("crosstalk", new[] { "width_d", "bound_symbols_S", "measured_mean", "measured_sd", "theory_sqrt_S(S-1)/d", "ratio" }, crossRows);

        // Per-slot readout of a bound chunk of S random symbols from 16, with and without successive cancellation.
        var readRows = new List<object[]>();
        foreach (int d in Widths)
            foreach (int L in new[] { 1, 4, 8, 16 })
            {
                int s = Motor.Dof * L;
                var code = BoundChunk.Create(d, 32, Rng.Derive(Seed, (ulong)(77_000 + d * 10 + L)));
                var errs = Enumerable.Range(0, 400).AsParallel().AsOrdered().Select(i =>
                {
                    var r = Rng.Derive(Seed, (ulong)(5_000_000 + d * 10_000 + L * 1000 + i));
                    var sym = new int[s];
                    for (int t = 0; t < s; t++) { var (c, nr) = r.NextInt(Motor.Alphabet); r = nr; sym[t] = c; }
                    var z = code.Encode(sym, L);
                    var plain = code.Decode(z, L, cancel: false);
                    var sic = code.Decode(z, L, cancel: true);
                    return (Plain: plain.Zip(sym).Count(p => p.First != p.Second) / (double)s, Sic: sic.Zip(sym).Count(p => p.First != p.Second) / (double)s,
                        Exact: sic.SequenceEqual(sym) ? 1.0 : 0.0);
                }).ToArray();
                double theory = 1 - CorrectProbability(s, d, Motor.Alphabet);
                double plainErr = errs.Average(e => e.Plain), sicErr = errs.Average(e => e.Sic), exact = errs.Average(e => e.Exact);
                readRows.Add(new object[] { d, L, s, plainErr, theory, sicErr, exact });
                h[$"read_d{d}_L{L}_plain"] = plainErr; h[$"read_d{d}_L{L}_theory"] = theory; h[$"read_d{d}_L{L}_sic"] = sicErr; h[$"read_d{d}_L{L}_exact"] = exact;
            }
        var read = Table.Of("readout", new[] { "width_d", "steps_L", "bound_symbols_S", "symbol_error_plain", "symbol_error_gaussian_theory", "symbol_error_successive_cancellation", "chunk_spelled_exactly" }, readRows);

        // Identities of a mixed softmax.
        double massGap = 0, biasGap = 0, scaleGap = 0;
        for (int it = 0; it < 1000; it++)
        {
            var r = Rng.Derive(Seed, (ulong)(9_000_000 + it));
            int nw = 256, nb = 640, dup = 5;
            var (sw, r1) = Lin.Gaussians(r, nw); var (sb, r2) = Lin.Gaussians(r1, nb);
            var (bw, r3) = r2.NextGaussian(); var (bb, r4) = r3.NextGaussian(); var (u, _) = r4.NextUniform(0.25, 4);
            double beta = 3.0, c = u;
            // Direct mass on the body tokens against Z_b e^{b_b} / (Z_w e^{b_w} + Z_b e^{b_b}).
            var logits = sw.Select(x => beta * x + bw).Concat(sb.Select(x => beta * x + bb)).ToArray();
            var p = Lin.Softmax(logits);
            double direct = p.Skip(nw).Sum();
            double mx = logits.Max();
            double zw = sw.Sum(x => Math.Exp(beta * x + bw - mx)), zb = sb.Sum(x => Math.Exp(beta * x + bb - mx));
            massGap = Math.Max(massGap, Math.Abs(direct - zb / (zw + zb)));
            // Each body token repeated five times with bias −log 5 gives the same body mass.
            var rep = sw.Select(x => beta * x + bw).Concat(sb.SelectMany(x => Enumerable.Repeat(beta * x + bb - Math.Log(dup), dup))).ToArray();
            biasGap = Math.Max(biasGap, Math.Abs(Lin.Softmax(rep).Skip(nw).Sum() - direct));
            // Scaling every body key by c equals multiplying the body inverse temperature by c.
            var scaled = sw.Select(x => beta * x).Concat(sb.Select(x => beta * (c * x))).ToArray();
            var temp = sw.Select(x => beta * x).Concat(sb.Select(x => (c * beta) * x)).ToArray();
            scaleGap = Math.Max(scaleGap, Lin.Softmax(scaled).Zip(Lin.Softmax(temp)).Max(q => Math.Abs(q.First - q.Second)));
        }
        // Blend band: y = (2π − 1)·A·shape(t) collides when |y| < 0.3 somewhere in steps 5–10 (A = 1).
        double minShape = Enumerable.Range(5, 6).Min(t => Math.Sin(Math.PI * (t + 1) / 17.0));
        double half = 0.3 / (2 * minShape);
        h["mass_identity_gap"] = massGap; h["log_count_bias_gap"] = biasGap; h["norm_scale_temperature_gap"] = scaleGap;
        h["blend_band_low"] = 0.5 - half; h["blend_band_high"] = 0.5 + half; h["blend_min_shape"] = minShape;
        var ident = Table.Of("identities", new[] { "check", "value", "requirement" }, new[]
        {
            new object[] { "modality mass: direct softmax against Z_m e^{b_m} / Σ Z e^b (max abs gap, 1,000 histories)", massGap, "rounding only" },
            new object[] { "each body token repeated 5 times with bias −log 5: body mass gap", biasGap, "rounding only" },
            new object[] { "body keys scaled by c against body inverse temperature × c: weight gap", scaleGap, "rounding only" },
            new object[] { "mirror modes, equal amplitude: blend weights that collide, lower edge", 0.5 - half, "π between the edges collides" },
            new object[] { "mirror modes, equal amplitude: blend weights that collide, upper edge", 0.5 + half, "π between the edges collides" },
        });
        return new ExperimentResult("M01", "Exact properties of a dense mixed cache", new[] { cross, read, ident }, h);
    }

    /// <summary>
    /// Gaussian approximation of the probability that unbinding one slot of S bound symbols picks the right one of A
    /// random unit symbol vectors: ∫ φ(z) Φ((1 + s z)/s_w)^(A−1) dz with s² = (S − 1)/d and s_w² = S/d.
    /// </summary>
    public static double CorrectProbability(int s, int d, int a)
    {
        double sc = Math.Sqrt((s - 1.0) / d), sw = Math.Sqrt((double)s / d);
        if (sc == 0) sc = 1e-12;
        double sum = 0, dz = 0.001;
        for (double z = -9; z <= 9; z += dz) sum += Math.Exp(-0.5 * z * z) / Math.Sqrt(2 * Math.PI) * Math.Pow(Phi((1 + sc * z) / sw), a - 1) * dz;
        return sum;
    }

    public static double Phi(double x) => 0.5 * Erfc(-x / Math.Sqrt(2));

    /// <summary>Complementary error function (Numerical Recipes erfcc, fractional error below 1.2e−7).</summary>
    public static double Erfc(double x)
    {
        double z = Math.Abs(x), t = 1 / (1 + 0.5 * z);
        double ans = t * Math.Exp(-z * z - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (0.09678418 + t * (-0.18628806 + t * (0.27886807 + t * (-1.13520398 + t * (1.48851587 + t * (-0.82215223 + t * 0.17087277)))))))));
        return x >= 0 ? ans : 2 - ans;
    }
}
