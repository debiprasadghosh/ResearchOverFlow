using MxLab.Core;

namespace MxLab.Experiments;

/// <summary>
/// One causal softmax over word keys and chunk keys. Words: training-free bound keys of width 128 (Step 1). Chunks:
/// learned linear ISET codes of 8-step chunks (Study M02), per-step slots for reranking. Four questions: (a) how the
/// relative scale of the two encoders and the score rule cause cross-modal intrusions; (b) how many body tokens per word
/// dilute a word query, with and without a log-count bias; (c) whether a pooled screen with a typed slot rerank keeps
/// exact retrieval over mixed histories of up to 16,384 tokens; (d) how contextual mixing in deeper layers erodes the
/// identity, spelling and reconstruction carried by a key.
/// </summary>
public static class M03_MixedCache
{
    private const ulong Seed = 303;
    public const int D = 128, L = 8, Trials = 1000, LongTrials = 200, Window = 16, BankPerSkill = 200;
    public const double Sigma = 0.5, Tol = 0.04;

    public sealed record Bank(M02_ChunkTokens.Data Data, IReadOnlyList<Motor.Chunk> Chunks, IReadOnlyList<IReadOnlyList<double>> Keys, LinearIset Pca, StepSlots Slots);
    public sealed record Words(CharCode Code, Binder Bind, IReadOnlyList<IReadOnlyList<double>> Keys);

    public static Bank MakeBank()
    {
        var data = M02_ChunkTokens.Make(L, Seed);
        var pca = LinearIset.Fit(data.Train.Select(c => c.X).ToArray(), Motor.Dof * L);
        var chunks = Enumerable.Range(0, M02_ChunkTokens.Skills * BankPerSkill).AsParallel().AsOrdered()
            .Select(i => Motor.Execute(data.Lib[i / BankPerSkill], L, Rng.Derive(Seed, 3_000_000_000UL + (ulong)i)).Value).ToArray();
        var keys = chunks.AsParallel().AsOrdered().Select(c => Bf16.Round(Mat.Pad(pca.Encode(c.X), D))).ToArray();
        return new Bank(data, chunks, keys, pca, StepSlots.Create(D, Rng.Derive(Seed, 21)));
    }

    public static Words MakeWords(Lexicon lex)
    {
        var code = CharCode.Random(D, Rng.Derive(Seed, 1));
        var bind = Binder.Create(D, Sym.L + 1, Rng.Derive(Seed, 2));
        var keys = lex.Words.AsParallel().AsOrdered().Select(w => (IReadOnlyList<double>)Layout.Bound(w, code, bind)).ToArray();
        return new Words(code, bind, keys);
    }

    public static IReadOnlyList<double> ChunkSlots(Bank b, Motor.Chunk c) => Bf16.Round(b.Slots.Encode(Motor.Characters(c.X, L).Symbols, L));

    /// <summary>History of chunk indices into the bank: the target, eight executions of its skill, the rest from other skills.</summary>
    public static IReadOnlyList<int> ChunkHistory(Bank b, int count, Rng rng)
    {
        int n = b.Chunks.Count;
        var (target, r) = rng.NextInt(n);
        int skill = b.Chunks[target].Skill;
        var hist = new List<int> { target };
        var used = new HashSet<int> { target };
        while (hist.Count < 1 + M02_ChunkTokens.NearDup)
        {
            var (k, nr) = r.NextInt(BankPerSkill); r = nr;
            int idx = skill * BankPerSkill + k;
            if (used.Add(idx)) hist.Add(idx);
        }
        while (hist.Count < count)
        {
            var (k, nr) = r.NextInt(n); r = nr;
            if (b.Chunks[k].Skill == skill || !used.Add(k)) continue;
            hist.Add(k);
        }
        return hist;
    }

    static double Rms(IEnumerable<IReadOnlyList<double>> v) => Math.Sqrt(v.Average(Lin.Norm2));

    public static ExperimentResult Run(Lexicon lex)
    {
        var bank = MakeBank();
        var words = MakeWords(lex);
        var h = new Dictionary<string, double>();
        var sampleWords = WordHistory.SampleTokens(lex, 5000, Rng.Derive(Seed, 5));
        double nw = Rms(sampleWords.Select(w => words.Keys[lex.Index[w]]));
        double nc = Rms(bank.Keys);
        h["word_key_rms_norm"] = nw; h["chunk_key_rms_norm"] = nc;

        // ---------- (a) encoder scale and score rule ----------
        var calRows = new List<object[]>();
        var wTrials = WordHistory.MakeTrials(lex, 256, Trials, Seed + 11);
        h["cal_mean_distinct_words"] = wTrials.Average(t => (double)t.Distinct.Count);
        foreach (double rho in new[] { 0.125, 0.5, 1.0, 2.0, 8.0 })
        {
            double scale = rho * nw / nc;                                   // raw chunk keys rescaled to RMS norm ρ·n_w
            foreach (string scheme in new[] { "raw dot product", "key-normalized (cosine)", "per-type normalized dot product", "per-type normalized distance" })
            {
                var outs = Enumerable.Range(0, Trials).AsParallel().AsOrdered().Select(i =>
                {
                    var t = wTrials[i];
                    var wk = t.Distinct.Select(w => words.Keys[lex.Index[w]]).ToArray();
                    var hist = ChunkHistory(bank, 256, Rng.Derive(Seed, 100_000UL + (ulong)i));
                    var ck = hist.Select(k => Mat.Scale(bank.Keys[k], scale)).ToArray();
                    var keys = wk.Concat(ck).ToArray();
                    var isWord = keys.Select((_, j) => j < wk.Length).ToArray();
                    double Typ(int j) => isWord[j] ? nw : nw * rho;            // per-type RMS norm of the rescaled keys
                    double Score(IReadOnlyList<double> q, int j, bool qWord) => scheme switch
                    {
                        "raw dot product" => Lin.Dot(q, keys[j]),
                        "key-normalized (cosine)" => Lin.Dot(q, keys[j]) / Math.Sqrt(Lin.Norm2(keys[j])),
                        "per-type normalized dot product" => Lin.Dot(q, keys[j]) / ((qWord ? nw : nw * rho) * Typ(j)),
                        _ => Lin.Dot(q, keys[j]) / ((qWord ? nw : nw * rho) * Typ(j)) - 0.5 * Lin.Norm2(keys[j]) / (Typ(j) * Typ(j)),
                    };
                    int Top(IReadOnlyList<double> q, bool qWord, out bool unique)
                    {
                        var s = Enumerable.Range(0, keys.Length).Select(j => Score(q, j, qWord)).ToArray();
                        double best = s.Max(); unique = s.Count(v => v == best) == 1; return Array.IndexOf(s, best);
                    }
                    int wTarget = Array.IndexOf(t.Distinct.ToArray(), t.Target);
                    var (qw, r1) = Mat.RelNoise(wk[wTarget], Sigma, Rng.Derive(Seed, 200_000UL + (ulong)i));
                    int tw = Top(qw, true, out bool uw);
                    int cTarget = wk.Length;
                    var (qc, _) = Mat.RelNoise(ck[0], Sigma, r1);
                    int tc = Top(qc, false, out _);
                    var fresh = Motor.Execute(bank.Data.Lib[bank.Chunks[hist[0]].Skill], L, Rng.Derive(Seed, 300_000UL + (ulong)i)).Value;
                    var qf = Mat.Scale(Bf16.Round(Mat.Pad(bank.Pca.Encode(fresh.X), D)), scale);
                    var dist = hist.Select(k => Motor.Rms(bank.Chunks[k].X, fresh.X)).ToArray();
                    int nearest = wk.Length + Array.IndexOf(dist, dist.Min());
                    int tf = Top(qf, false, out _);
                    return (wExact: tw == wTarget && uw, wIntr: !isWord[tw],
                        cWithin: !isWord[tc] && Motor.Rms(bank.Chunks[hist[tc - wk.Length]].X, bank.Chunks[hist[0]].X) <= Tol, cIntr: isWord[tc],
                        fNear: tf == nearest, fIntr: isWord[tf]);
                }).ToArray();
                double A(Func<(bool wExact, bool wIntr, bool cWithin, bool cIntr, bool fNear, bool fIntr), bool> f) => outs.Average(o => f(o) ? 1.0 : 0.0);
                calRows.Add(new object[] { rho, scheme, A(o => o.wExact), A(o => o.wIntr), A(o => o.cWithin), A(o => o.cIntr), A(o => o.fNear), A(o => o.fIntr) });
                string key = $"cal_rho{rho}_{(scheme.EndsWith("distance") ? "distance" : scheme.Split(' ')[0].Replace("-", "") + (scheme.Contains("normalized dot") ? "dot" : ""))}";
                h[$"{key}_word_exact"] = A(o => o.wExact); h[$"{key}_word_intrusion"] = A(o => o.wIntr);
                h[$"{key}_chunk_within"] = A(o => o.cWithin); h[$"{key}_chunk_intrusion"] = A(o => o.cIntr);
                h[$"{key}_similar_nearest"] = A(o => o.fNear); h[$"{key}_similar_intrusion"] = A(o => o.fIntr);
            }
        }
        var tCal = Table.Of("calibration", new[] { "chunk_to_word_norm_ratio", "score_rule", "word_exact", "word_query_chunk_intrusion", "chunk_address_within_tolerance", "chunk_query_word_intrusion", "chunk_similar_nearest", "similar_query_word_intrusion" }, calRows);

        // ---------- (b) dilution of a word query by body tokens ----------
        var dilRows = new List<object[]>();
        foreach (double perWord in new[] { 1.25, 2.5, 20.0 })
            foreach (double beta in new[] { 4.0, 8.0, 16.0 })
                foreach (bool bias in new[] { false, true })
                {
                    var outs = Enumerable.Range(0, 400).AsParallel().AsOrdered().Select(i =>
                    {
                        var t = wTrials[i];
                        var wk = t.Distinct.Select(w => Mat.Scale(words.Keys[lex.Index[w]], 1 / nw)).ToArray();
                        int nb = (int)Math.Round(perWord * wk.Length);
                        var r = Rng.Derive(Seed, 400_000UL + (ulong)i);
                        var bk = new IReadOnlyList<double>[nb];
                        for (int j = 0; j < nb; j++) { var (k, nr) = r.NextInt(bank.Keys.Count); r = nr; bk[j] = Mat.Scale(bank.Keys[k], 1 / nc); }
                        int wTarget = Array.IndexOf(t.Distinct.ToArray(), t.Target);
                        var (q, _) = Mat.RelNoise(wk[wTarget], Sigma, Rng.Derive(Seed, 500_000UL + (ulong)i));
                        double b = bias ? -Math.Log(nb / (double)wk.Length) : 0;
                        var logits = wk.Select(k => beta * (Lin.Dot(q, k) - 0.5 * Lin.Norm2(k)))
                            .Concat(bk.Select(k => beta * (Lin.Dot(q, k) - 0.5 * Lin.Norm2(k)) + b)).ToArray();
                        var p = Lin.Softmax(logits);
                        return (target: p[wTarget], words: p.Take(wk.Length).Sum() - p[wTarget], body: p.Skip(wk.Length).Sum());
                    }).ToArray();
                    double mt = outs.Average(o => o.target), mw = outs.Average(o => o.words), mb = outs.Average(o => o.body);
                    dilRows.Add(new object[] { perWord, beta, bias ? "log-count bias" : "none", mt, mw, mb });
                    string key = $"dil_pw{perWord}_b{beta}_{(bias ? "bias" : "none")}";
                    h[$"{key}_target"] = mt; h[$"{key}_body"] = mb;
                }
        var tDil = Table.Of("dilution", new[] { "body_tokens_per_word", "inverse_temperature_beta", "bias", "mass_on_target_word", "mass_on_other_words", "mass_on_body_tokens" }, dilRows);

        // ---------- (c) long mixed histories: pooled screen, typed slot rerank ----------
        var longRows = new List<object[]>();
        foreach (int m in new[] { 256, 1024, 4096, 16384 })
        {
            int mw = (int)Math.Round(2.0 * m / 7), mc = m - mw;
            var lt = WordHistory.MakeTrials(lex, mw, LongTrials, Seed + 1000 + (ulong)m);
            var outs = Enumerable.Range(0, LongTrials).AsParallel().AsOrdered().Select(i =>
            {
                var t = lt[i];
                var wk = t.Distinct.Select(w => Mat.Scale(words.Keys[lex.Index[w]], 1 / nw)).ToArray();
                var hist = ChunkHistory(bank, mc, Rng.Derive(Seed, 600_000UL + (ulong)(m * 1000 + i)));
                var ck = hist.Select(k => Mat.Scale(bank.Keys[k], 1 / nc)).ToArray();
                var keys = wk.Concat(ck).ToArray();
                int nW = wk.Length;
                var all = Enumerable.Range(0, keys.Length).ToArray();
                int wTarget = Array.IndexOf(t.Distinct.ToArray(), t.Target), cTarget = nW;
                var r = Rng.Derive(Seed, 700_000UL + (ulong)(m * 1000 + i));
                var (qw, r1) = Mat.RelNoise(wk[wTarget], Sigma, r);
                var (qc, r2) = Mat.RelNoise(ck[0], Sigma, r1);
                var wSlotsTarget = Layout.Concat(t.Target, words.Code);
                var (qws, r3) = Mat.RelNoise(wSlotsTarget, Sigma, r2);
                var cSlotsTarget = ChunkSlots(bank, bank.Chunks[hist[0]]);
                var (qcs, _) = Mat.RelNoise(cSlotsTarget, Sigma, r3);
                double S(IReadOnlyList<double> q, int j) => Lin.Dot(q, keys[j]) - 0.5 * Lin.Norm2(keys[j]);
                var sw = all.Select(j => S(qw, j)).ToArray();
                var sc = all.Select(j => S(qc, j)).ToArray();
                bool Strict(IReadOnlyList<double> s, IReadOnlyList<int> among, int target)
                {
                    double best = among.Max(j => s[j]); var top = among.Where(j => s[j] == best).ToArray(); return top.Length == 1 && top[0] == target;
                }
                var res = new List<double> { Strict(sw, all, wTarget) ? 1 : 0, Strict(sc, all, cTarget) ? 1 : 0 };
                foreach (int k in new[] { 8, 32 })
                {
                    var selW = Lin.TopIndices(sw, all, k); var selC = Lin.TopIndices(sc, all, k);
                    var candW = selW.Where(j => j < nW).ToArray(); var candC = selC.Where(j => j >= nW).ToArray();
                    var rw = new double[keys.Length]; var rc = new double[keys.Length];
                    foreach (int j in candW) { var s = Layout.Concat(t.Distinct[j], words.Code); rw[j] = Lin.Dot(qws, s) - 0.5 * Lin.Norm2(s); }
                    foreach (int j in candC) { var s = ChunkSlots(bank, bank.Chunks[hist[j - nW]]); rc[j] = Lin.Dot(qcs, s) - 0.5 * Lin.Norm2(s); }
                    res.Add(selW.Contains(wTarget) ? 1 : 0); res.Add(candW.Length > 0 && Strict(rw, candW, wTarget) ? 1 : 0); res.Add(selW.Count(j => j >= nW) / (double)k);
                    res.Add(selC.Contains(cTarget) ? 1 : 0); res.Add(candC.Length > 0 && Strict(rc, candC, cTarget) ? 1 : 0); res.Add(selC.Count(j => j < nW) / (double)k);
                }
                res.Add(nW); res.Add(t.TokenSlots);
                return res.ToArray();
            }).ToArray();
            double Av(int col) => outs.Average(o => o[col]);
            double nWords = Av(14), letters = Av(15);
            double denseChar = (letters + (double)mc * L) * D;                // letters + separators for words, one token per control step
            void Add(string reader, double wAcc, double cAcc, double wRecall, double cRecall, double wOther, double cOther, double macW, double macC)
            {
                longRows.Add(new object[] { m, reader, wAcc, cAcc, wRecall, cRecall, wOther, cOther, macW, macC });
                string key = $"long_M{m}_{reader.Replace(" ", "_").Replace(",", "").Replace("=", "").Replace("→", "to")}";
                h[$"{key}_word"] = wAcc; h[$"{key}_chunk"] = cAcc; h[$"{key}_mac_word"] = macW; h[$"{key}_mac_chunk"] = macC;
                if (!double.IsNaN(wRecall)) { h[$"{key}_word_recall"] = wRecall; h[$"{key}_chunk_recall"] = cRecall; }
            }
            Add("dense character-level attention", 1, 1, double.NaN, double.NaN, double.NaN, double.NaN, denseChar, denseChar);
            Add("pooled scan only", Av(0), Av(1), double.NaN, double.NaN, double.NaN, double.NaN, (nWords + mc) * D, (nWords + mc) * D);
            Add("pooled screen → typed slot rerank, K=8", Av(3), Av(6), Av(2), Av(5), Av(4), Av(7), (nWords + mc) * D + 8 * Sym.L * D, (nWords + mc) * D + 8 * L * D);
            Add("pooled screen → typed slot rerank, K=32", Av(9), Av(12), Av(8), Av(11), Av(10), Av(13), (nWords + mc) * D + 32 * Sym.L * D, (nWords + mc) * D + 32 * L * D);
            h[$"long_M{m}_distinct_words"] = nWords; h[$"long_M{m}_chunks"] = mc;
        }
        var tLong = Table.Of("long_history", new[] { "tokens_M", "reader", "word_exact", "chunk_address_exact", "word_stage1_recall", "chunk_stage1_recall", "word_topK_other_type_share", "chunk_topK_other_type_share", "mac_per_word_query", "mac_per_chunk_query" }, longRows);

        // ---------- (d) contextual mixing in deeper layers ----------
        var depthRows = new List<object[]>();
        foreach (double betaCtx in new[] { 0.0, 0.25, 0.5, 1.0, 2.0 })
        {
            var outs = Enumerable.Range(0, Trials).AsParallel().AsOrdered().Select(i =>
            {
                var t = wTrials[i];
                var r = Rng.Derive(Seed, 800_000UL + (ulong)i);
                var wordsTok = new List<string> { t.Target };
                wordsTok.AddRange(t.Neighbours);
                var (fill, r1) = (WordHistory.SampleTokens(lex, 256 - wordsTok.Count, r), Rng.Derive(Seed, 810_000UL + (ulong)i));
                wordsTok.AddRange(fill);
                var hist = ChunkHistory(bank, 256, r1);
                // Interleave: a seeded shuffle of 512 slots; the two targets are moved to positions ≥ Window.
                var order = Enumerable.Range(0, 512).ToArray();
                var rr = Rng.Derive(Seed, 820_000UL + (ulong)i);
                for (int k = order.Length - 1; k > 0; k--) { var (j, nr) = rr.NextInt(k + 1); rr = nr; (order[k], order[j]) = (order[j], order[k]); }
                foreach (int tgt in new[] { 0, 256 })
                {
                    int pos = Array.IndexOf(order, tgt);
                    if (pos >= Window) continue;
                    int swap = Enumerable.Range(Window, order.Length - Window).First(p => order[p] != 0 && order[p] != 256);
                    (order[pos], order[swap]) = (order[swap], order[pos]);
                }
                IReadOnlyList<double> Base(int item) => item < 256 ? Mat.Scale(words.Keys[lex.Index[wordsTok[item]]], 1 / nw) : Mat.Scale(bank.Keys[hist[item - 256]], 1 / nc);
                var seq = order.Select(Base).ToArray();
                var deep = new IReadOnlyList<double>[seq.Length];
                for (int p = 0; p < seq.Length; p++)
                {
                    var c = new double[D];
                    for (int s = Math.Max(0, p - Window); s < p; s++) for (int k = 0; k < D; k++) c[k] += seq[s][k];
                    double cn = Math.Sqrt(Lin.Norm2(c));
                    double hn = Math.Sqrt(Lin.Norm2(seq[p]));
                    deep[p] = cn == 0 ? seq[p] : Mat.Add(seq[p], c, betaCtx * hn / cn);
                }
                int pw = Array.IndexOf(order, 0), pc = Array.IndexOf(order, 256);
                var (qw, r2) = Mat.RelNoise(seq[pw], Sigma, Rng.Derive(Seed, 830_000UL + (ulong)i));
                var (qc, _) = Mat.RelNoise(seq[pc], Sigma, r2);
                int Top(IReadOnlyList<double> q, out bool unique)
                {
                    var s = deep.Select(k => Lin.Dot(q, k) - 0.5 * Lin.Norm2(k)).ToArray();
                    double best = s.Max(); unique = s.Count(v => v == best) == 1; return Array.IndexOf(s, best);
                }
                int tw = Top(qw, out bool uw), tc = Top(qc, out bool uc);
                bool cWithin = order[tc] >= 256 && Motor.Rms(bank.Chunks[hist[order[tc] - 256]].X, bank.Chunks[hist[0]].X) <= Tol;
                string spelled = Layout.DecodeBound(Mat.Scale(deep[pw], nw), words.Code, words.Bind);
                var recon = bank.Pca.Decode(Mat.Scale(deep[pc], nc).Take(bank.Pca.Rank).ToArray());
                double err = Motor.Rms(recon, bank.Chunks[hist[0]].X);
                return (wExact: tw == pw && uw, cExact: tc == pc && uc, cWithin, spelled: spelled == t.Target, err);
            }).ToArray();
            double wE = outs.Average(o => o.wExact ? 1.0 : 0), cE = outs.Average(o => o.cExact ? 1.0 : 0), cW = outs.Average(o => o.cWithin ? 1.0 : 0);
            double sp = outs.Average(o => o.spelled ? 1.0 : 0), er = Math.Sqrt(outs.Average(o => o.err * o.err)), pass = outs.Average(o => o.err <= Tol ? 1.0 : 0);
            depthRows.Add(new object[] { betaCtx, wE, sp, cE, cW, er, pass });
            string key = $"depth_b{betaCtx}";
            h[$"{key}_word_exact"] = wE; h[$"{key}_spelled"] = sp; h[$"{key}_chunk_exact"] = cE; h[$"{key}_chunk_within"] = cW; h[$"{key}_recon_rms"] = er; h[$"{key}_recon_pass"] = pass;
        }
        var tDepth = Table.Of("depth", new[] { "context_to_self_ratio", "word_exact", "word_spelled_from_key", "chunk_address_exact", "chunk_address_within_tolerance", "chunk_reconstruction_rms", "chunk_reconstruction_pass_0.04" }, depthRows);
        return new ExperimentResult("M03", "One softmax over words and chunks", new[] { tCal, tDil, tLong, tDepth }, h);
    }
}
