using System.Diagnostics;
using MxLab.Core;
using MxLab.Experiments;

// Composition root: loads the lexicon once, schedules the studies and performs the only file writes.
string data = Environment.GetEnvironmentVariable("MX_DATA") ?? Path.Combine("..", "data", "large_en.msgpack.gz");
string outDir = Environment.GetEnvironmentVariable("MX_OUT") ?? Path.Combine("..", "out");
var swLoad = Stopwatch.StartNew();
var lexicon = Lexicon.Load(data, 50_000);
Console.WriteLine($"lexicon: {lexicon.Words.Count} words loaded in {swLoad.Elapsed.TotalSeconds:F1} s");
var registry = new (string Id, Func<Lexicon, ExperimentResult> Run)[]
{
    ("M00", M00_Accounting.Run),
    ("M01", M01_Exact.Run),
    ("M02", M02_ChunkTokens.Run),
    ("M03", M03_MixedCache.Run),
    ("M04", M04_Association.Run),
    ("M05", M05_ModeChoice.Run),
};
var selected = args.Length == 0 ? registry : registry.Where(r => args.Contains(r.Id)).ToArray();
var results = new List<ExperimentResult>();
foreach (var (id, run) in selected)
{
    var sw = Stopwatch.StartNew();
    var r = run(lexicon);
    sw.Stop();
    results.Add(r);
    Console.WriteLine($"{id} {r.Title}: {sw.Elapsed.TotalSeconds:F1} s");
    foreach (var kv in r.Headlines) Console.WriteLine($"   {kv.Key} = {kv.Value:G6}");
}
Output.Write(outDir, results);
