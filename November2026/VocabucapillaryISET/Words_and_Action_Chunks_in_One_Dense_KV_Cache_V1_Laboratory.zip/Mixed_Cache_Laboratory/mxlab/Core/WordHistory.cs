namespace MxLab.Core;

/// <summary>
/// Word histories as in Step 1 of the series: a target word of 3–12 letters from the 20,000 most frequent words, up to
/// eight near-duplicates (anagrams, affix relatives, one-edit words) and frequency-sampled fillers. The word key is the
/// training-free bound key Σ_j R_j e(c_j) + R_(n+1) e(EOS) of width d.
/// </summary>
public static class WordHistory
{
    public const int NeighbourCap = 8;

    public sealed record Trial(string Target, IReadOnlyList<string> Neighbours, IReadOnlyList<string> Distinct, double TokenSlots);

    public static IReadOnlyList<Trial> MakeTrials(Lexicon lex, int history, int count, ulong seed, int maxRank = 20000)
    {
        var trials = new List<Trial>();
        var r = Rng.Derive(seed, 1);
        while (trials.Count < count)
        {
            var (idx, r1) = r.NextInt(Math.Min(maxRank, lex.Words.Count)); r = r1;
            string w = lex.Words[idx];
            if (w.Length < 3 || w.Length > 12) continue;
            var nb = lex.Neighbours(w, NeighbourCap);
            if (nb.Count < 2) continue;
            var tokens = new List<string> { w };
            tokens.AddRange(nb);
            var rr = Rng.Derive(seed, 100 + (ulong)trials.Count);
            while (tokens.Count < history) { var (k, nr) = lex.Sample(rr); rr = nr; tokens.Add(lex.Words[k]); }
            trials.Add(new Trial(w, nb, tokens.Distinct().ToArray(), tokens.Sum(x => x.Length + 1.0)));
        }
        return trials;
    }

    /// <summary>A frequency-sampled list of word tokens (repeats allowed), used to fill mixed histories.</summary>
    public static IReadOnlyList<string> SampleTokens(Lexicon lex, int count, Rng rng)
    {
        var outp = new string[count];
        var r = rng;
        for (int i = 0; i < count; i++) { var (k, nr) = lex.Sample(r); r = nr; outp[i] = lex.Words[k]; }
        return outp;
    }
}
