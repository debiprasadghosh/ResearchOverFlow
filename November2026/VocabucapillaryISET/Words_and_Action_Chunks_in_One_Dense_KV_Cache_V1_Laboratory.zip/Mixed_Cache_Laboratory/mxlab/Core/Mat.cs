namespace MxLab.Core;

/// <summary>Dense linear algebra and statistics helpers. Work buffers are local; results leave as read-only lists.</summary>
public static class Mat
{
    public static IReadOnlyList<double> Normalize(IReadOnlyList<double> v)
    {
        double n = Math.Sqrt(Lin.Norm2(v));
        return n == 0 ? v.ToArray() : v.Select(x => x / n).ToArray();
    }

    public static IReadOnlyList<double> Pad(IReadOnlyList<double> v, int width)
    {
        var y = new double[width];
        for (int i = 0; i < v.Count; i++) y[i] = v[i];
        return y;
    }

    public static IReadOnlyList<double> Scale(IReadOnlyList<double> v, double c) => v.Select(x => c * x).ToArray();

    public static IReadOnlyList<double> Add(IReadOnlyList<double> a, IReadOnlyList<double> b, double cb = 1.0)
    {
        var y = new double[a.Count];
        for (int i = 0; i < y.Length; i++) y[i] = a[i] + cb * b[i];
        return y;
    }

    public static double Cosine(IReadOnlyList<double> a, IReadOnlyList<double> b)
    {
        double na = Lin.Norm2(a), nb = Lin.Norm2(b);
        return na == 0 || nb == 0 ? 0 : Lin.Dot(a, b) / Math.Sqrt(na * nb);
    }

    /// <summary>Adds isotropic Gaussian noise whose total energy is σ² times the energy of v (relative noise).</summary>
    public static (IReadOnlyList<double> Value, Rng Next) RelNoise(IReadOnlyList<double> v, double sigma, Rng rng)
    {
        var (g, next) = Lin.Gaussians(rng, v.Count);
        double scale = sigma * Math.Sqrt(Lin.Norm2(v) / v.Count);
        return (v.Select((x, i) => x + scale * g[i]).ToArray(), next);
    }

    /// <summary>Cyclic Jacobi eigen-decomposition of a symmetric matrix; eigenpairs sorted by decreasing eigenvalue.</summary>
    public static (IReadOnlyList<double> Values, IReadOnlyList<IReadOnlyList<double>> Vectors) SymmetricEigen(double[,] input)
    {
        int n = input.GetLength(0);
        var a = (double[,])input.Clone();
        var v = new double[n, n];
        for (int i = 0; i < n; i++) v[i, i] = 1;
        for (int sweep = 0; sweep < 100; sweep++)
        {
            double off = 0, diag = 0;
            for (int p = 0; p < n; p++) { diag += a[p, p] * a[p, p]; for (int q = p + 1; q < n; q++) off += a[p, q] * a[p, q]; }
            if (off <= 1e-26 * (diag + 1e-300)) break;
            for (int p = 0; p < n - 1; p++)
                for (int q = p + 1; q < n; q++)
                {
                    double apq = a[p, q];
                    if (Math.Abs(apq) < 1e-300) continue;
                    double theta = (a[q, q] - a[p, p]) / (2 * apq);
                    double t = (theta >= 0 ? 1.0 : -1.0) / (Math.Abs(theta) + Math.Sqrt(theta * theta + 1));
                    double c = 1 / Math.Sqrt(t * t + 1), s = t * c;
                    for (int k = 0; k < n; k++) { double akp = a[k, p], akq = a[k, q]; a[k, p] = c * akp - s * akq; a[k, q] = s * akp + c * akq; }
                    for (int k = 0; k < n; k++) { double apk = a[p, k], aqk = a[q, k]; a[p, k] = c * apk - s * aqk; a[q, k] = s * apk + c * aqk; }
                    for (int k = 0; k < n; k++) { double vkp = v[k, p], vkq = v[k, q]; v[k, p] = c * vkp - s * vkq; v[k, q] = s * vkp + c * vkq; }
                }
        }
        var order = Enumerable.Range(0, n).OrderByDescending(i => a[i, i]).ThenBy(i => i).ToArray();
        var values = order.Select(i => a[i, i]).ToArray();
        var vectors = order.Select(i => (IReadOnlyList<double>)Enumerable.Range(0, n).Select(k => v[k, i]).ToArray()).ToArray();
        return (values, vectors);
    }

    /// <summary>Solves (G + λI) W = B for symmetric positive definite G by Cholesky; B has one column per output.</summary>
    public static double[,] CholeskySolve(double[,] g, double lambda, double[,] b)
    {
        int n = g.GetLength(0), m = b.GetLength(1);
        var L = new double[n, n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j <= i; j++)
            {
                double s = g[i, j] + (i == j ? lambda : 0);
                for (int k = 0; k < j; k++) s -= L[i, k] * L[j, k];
                L[i, j] = i == j ? Math.Sqrt(Math.Max(s, 1e-300)) : s / L[j, j];
            }
        var w = new double[n, m];
        for (int c = 0; c < m; c++)
        {
            var y = new double[n];
            for (int i = 0; i < n; i++) { double s = b[i, c]; for (int k = 0; k < i; k++) s -= L[i, k] * y[k]; y[i] = s / L[i, i]; }
            for (int i = n - 1; i >= 0; i--) { double s = y[i]; for (int k = i + 1; k < n; k++) s -= L[k, i] * w[k, c]; w[i, c] = s / L[i, i]; }
        }
        return w;
    }

    /// <summary>Ridge regression without intercept: W = (XᵀX + λI)⁻¹ XᵀY, returned as a function x ↦ xW.</summary>
    public static Func<IReadOnlyList<double>, IReadOnlyList<double>> Ridge(IReadOnlyList<IReadOnlyList<double>> x, IReadOnlyList<IReadOnlyList<double>> y, double lambda)
    {
        int p = x[0].Count, q = y[0].Count, n = x.Count;
        var g = new double[p, p];
        var b = new double[p, q];
        for (int r = 0; r < n; r++)
        {
            var xr = x[r]; var yr = y[r];
            for (int i = 0; i < p; i++)
            {
                double xi = xr[i];
                if (xi == 0) continue;
                for (int j = 0; j <= i; j++) g[i, j] += xi * xr[j];
                for (int c = 0; c < q; c++) b[i, c] += xi * yr[c];
            }
        }
        for (int i = 0; i < p; i++) for (int j = 0; j < i; j++) g[j, i] = g[i, j];
        var w = CholeskySolve(g, lambda, b);
        return v =>
        {
            var o = new double[q];
            for (int i = 0; i < p; i++) { double vi = v[i]; if (vi == 0) continue; for (int c = 0; c < q; c++) o[c] += vi * w[i, c]; }
            return o;
        };
    }

    /// <summary>Lloyd's k-means with k-means++ seeding from the given generator; returns centroids and assignments.</summary>
    public static (IReadOnlyList<IReadOnlyList<double>> Centroids, IReadOnlyList<int> Assign) KMeans(IReadOnlyList<IReadOnlyList<double>> pts, int k, Rng rng, int iters = 100)
    {
        int n = pts.Count, dim = pts[0].Count;
        double D2(IReadOnlyList<double> a, IReadOnlyList<double> b) { double s = 0; for (int i = 0; i < dim; i++) { double e = a[i] - b[i]; s += e * e; } return s; }
        var cents = new List<IReadOnlyList<double>>();
        var (first, r) = rng.NextInt(n);
        cents.Add(pts[first]);
        while (cents.Count < k)
        {
            var w = pts.Select(p => cents.Min(c => D2(p, c))).ToArray();
            var (pick, nr) = r.NextCategorical(w); r = nr;
            cents.Add(pts[pick]);
        }
        var assign = new int[n];
        for (int it = 0; it < iters; it++)
        {
            bool changed = false;
            for (int i = 0; i < n; i++)
            {
                int best = 0; double bv = double.PositiveInfinity;
                for (int c = 0; c < k; c++) { double dd = D2(pts[i], cents[c]); if (dd < bv) { bv = dd; best = c; } }
                if (assign[i] != best || it == 0) { changed |= assign[i] != best; assign[i] = best; }
            }
            var next = new List<IReadOnlyList<double>>();
            for (int c = 0; c < k; c++)
            {
                var members = Enumerable.Range(0, n).Where(i => assign[i] == c).ToArray();
                if (members.Length == 0) { next.Add(cents[c]); continue; }
                var m = new double[dim];
                foreach (int i in members) for (int t = 0; t < dim; t++) m[t] += pts[i][t];
                next.Add(m.Select(x => x / members.Length).ToArray());
            }
            cents = next;
            if (!changed && it > 0) break;
        }
        return (cents, assign);
    }

    public static IReadOnlyList<double> Ranks(IReadOnlyList<double> x)
    {
        var idx = Enumerable.Range(0, x.Count).OrderBy(i => x[i]).ThenBy(i => i).ToArray();
        var r = new double[x.Count];
        int a = 0;
        while (a < idx.Length)
        {
            int b = a;
            while (b + 1 < idx.Length && x[idx[b + 1]] == x[idx[a]]) b++;
            double avg = (a + b) / 2.0 + 1;
            for (int i = a; i <= b; i++) r[idx[i]] = avg;
            a = b + 1;
        }
        return r;
    }

    public static double Pearson(IReadOnlyList<double> x, IReadOnlyList<double> y)
    {
        double mx = x.Average(), my = y.Average(), sxy = 0, sxx = 0, syy = 0;
        for (int i = 0; i < x.Count; i++) { double a = x[i] - mx, b = y[i] - my; sxy += a * b; sxx += a * a; syy += b * b; }
        return sxy / Math.Sqrt(sxx * syy);
    }

    public static double Spearman(IReadOnlyList<double> x, IReadOnlyList<double> y) => Pearson(Ranks(x), Ranks(y));
}
