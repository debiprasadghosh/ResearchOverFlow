"""Assembles the Part 1 paper (words and ISET action chunks in one dense KV cache) from the laboratory outputs and
converts it to Word with pandoc and the docxfix repair step."""
import csv, json, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT, FIG = ROOT / "out", ROOT / "figs"
sys.path.insert(0, str(HERE))
import docxfix

H = json.load(open(OUT / "headlines.json"))
def g(k): return H[k]
def rd(n): return list(csv.DictReader(open(OUT / f"{n}.csv")))
def m(s): return s.replace("-", "−")
def f2(x): return m(f"{x:.2f}")
def f3(x): return m(f"{x:.3f}")
def f4(x): return m(f"{x:.4f}")
def pc(x, d=0): return m(f"{100 * x:.{d}f}%")
def n0(x): return f"{x:,.0f}"
def sci(x): return m(f"{x:.1e}")
SUP = str.maketrans("0123456789-", "⁰¹²³⁴⁵⁶⁷⁸⁹⁻")
def p10(x):
    mant, ex = f"{x:.1e}".split("e")
    return f"{mant} × 10{str(int(ex)).translate(SUP)}"
def fl(x): return float(x)

def md_table(header, rows, caption, widths=None):
    lens = [max(min(len(str(h)), 14), 9, *(len(str(r[i])) for r in rows)) for i, h in enumerate(header)]
    dashes = widths if widths else [max(9, min(60, l)) for l in lens]
    out = [f"Table: {caption}", "", "| " + " | ".join(header) + " |", "|" + "|".join("-" * w for w in dashes) + "|"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out) + "\n"

# ---------------- lookups ----------------
mn = rd("M00_minute"); rates = rd("M00_rates"); store = rd("M00_chunk_storage")
cross = rd("M01_crosstalk"); readout = rd("M01_readout"); ident = rd("M01_identities")
ret = rd("M02_retrieval"); rec = rd("M02_reconstruction"); rank = rd("M02_rank"); stale = rd("M02_staleness")
cal = rd("M03_calibration"); dil = rd("M03_dilution"); lh = rd("M03_long_history"); dep = rd("M03_depth")
asc = rd("M04_association"); mc = rd("M05_mode_choice")
py = list(csv.DictReader(open(OUT / "PY_crosscheck.csv")))
py_agree = f"{sum(r['agree'] == 'True' for r in py)} of {len(py)}"

def mrow(body): return next(r for r in mn if r["body_scheme"] == body and (r["word_scheme"] == "words" or body.startswith("motor")))
def rv(enc, L, col, d=128, s="0.5"): return fl(next(r[col] for r in ret if r["encoder"] == enc and r["steps_L"] == str(L) and r["width_d"] == str(d) and r["noise_sigma"] == s))
def cv(enc, L, col, d=128): return fl(next(r[col] for r in rec if r["encoder"] == enc and r["steps_L"] == str(L) and r["width_d"] == str(d)))
def kv(r_, enc, col): return fl(next(x[col] for x in rank if x["code_rank_r"] == str(r_) and x["encoder"] == enc))
def sv(r_, case, col): return fl(next(x[col] for x in stale if x["code_rank_r"] == str(r_) and x["case"].startswith(case)))
def calv(rule, rho, col): return fl(next(r[col] for r in cal if r["score_rule"] == rule and fl(r["chunk_to_word_norm_ratio"]) == rho))
def dv(pw, beta, bias, col): return fl(next(r[col] for r in dil if fl(r["body_tokens_per_word"]) == pw and fl(r["inverse_temperature_beta"]) == beta and r["bias"] == bias))
def lv(reader, mm, col): return fl(next(r[col] for r in lh if r["reader"] == reader and r["tokens_M"] == str(mm)))
def depv(b, col): return fl(next(r[col] for r in dep if fl(r["context_to_self_ratio"]) == b))
def av(iota, col, d=128): return fl(next(r[col] for r in asc if fl(r["interaction_share_iota"]) == iota and r["width_d"] == str(d)))
def mv(name, col): return fl(next(r[col] for r in mc if r["reader"] == name))
def rdv(d, L, col): return fl(next(r[col] for r in readout if r["width_d"] == str(d) and r["steps_L"] == str(L)))

ENC = ["bound characters", "per-step slots", "learned linear ISET", "DCT"]
ENCLAB = {"bound characters": "Bound motor characters", "per-step slots": "Per-step slots", "learned linear ISET": "Learned linear ISET", "DCT": "DCT"}
Ls = [4, 8, 16, 32]
K8 = "pooled screen → typed slot rerank, K=8"; K32 = "pooled screen → typed slot rerank, K=32"
cross_ratios = [fl(r["ratio"]) for r in cross]

# ---------------- tables ----------------
t_related = md_table(["Approach", "Body unit", "What is stored or predicted per unit", "How one of several valid actions is chosen"], [
    ["RT-2 (Zitkovich et al., 2023)", "one step", "per-dimension bins written as text tokens", "softmax over bins, dimension by dimension"],
    ["Gato (Reed et al., 2022)", "one step", "μ-law bins as tokens in one sequence with text and images", "softmax over bins"],
    ["FAST (Pertsch et al., 2025)", "chunk", "quantized DCT coefficients compressed into tokens", "softmax over compressed tokens"],
    ["BeT (Shafiullah et al., 2022)", "one step", "k-means action bin plus a continuous offset", "categorical bin, then offset"],
    ["VQ-BeT (Lee et al., 2024)", "chunk", "hierarchical vector-quantized code plus an offset", "categorical codes, coarse to fine"],
    ["ACT (Zhao et al., 2023)", "chunk", "continuous chunk from a conditional VAE decoder", "VAE latent, set to its mean at test time; temporal ensembling"],
    ["Diffusion Policy, π0 (Chi et al., 2023; Black et al., 2024)", "chunk", "continuous chunk generated by diffusion or flow matching", "iterative sampling"],
    ["This paper (Part 1)", "chunk", "one ISET vector per chunk, cached beside word keys and read by attention", "choose a mode from attention mass, then read within it"],
], "Table 1. How related work represents body actions. None stores chunk tokens as cache entries that word queries and action queries both read in one softmax.", [34, 10, 44, 40])

t_enc = md_table(["Chunk encoder", "Training", "Floats per chunk", "Decodable", "Geometry of keys"], [
    ["Bound motor characters Σ R e(c)", "none", "d", "only while 7L is small against d", "categorical: a one-step change of a character is as far as any change"],
    ["Per-step slots", "none", "L·d", "yes, at moderate d", "categorical"],
    ["Learned linear ISET (principal components)", "fitted to chunks", "d (rank r ≤ d)", "when r reaches the chunks' intrinsic dimension", "Euclidean: distances between codes equal distances between motions"],
    ["DCT, k coefficients per joint", "none", "d (rank 7k ≤ d)", "when 7k ≥ 7L, or the motion is smooth", "Euclidean"],
], "Table 2. Encoders for a chunk of L control steps of seven joints. All keys are stored in BF16.", [26, 12, 12, 26, 34])

t_rules = md_table(["Score rule", "Score s(q, t)", "Invariant to the scale of an encoder", "Ranks keys of one type by"], [
    ["Raw dot product", "qᵀkₜ", "no", "projection, favouring long keys"],
    ["Key-normalized (cosine)", "qᵀkₜ / ‖kₜ‖", "yes", "direction only; amplitude is lost"],
    ["Per-type normalized dot product", "q̃ᵀk̃ₜ, where x̃ is x divided by its type's key norm", "yes", "projection, favouring long keys"],
    ["Per-type normalized distance", "q̃ᵀk̃ₜ − ½‖k̃ₜ‖²", "yes", "Euclidean distance to the query"],
], "Table 3. Score rules for one softmax over word and chunk keys. The key norm of a type is the root-mean-square norm of its keys.", [22, 28, 16, 26])

t_cross = md_table(["Bound symbols S", "Typical use", "Measured sd (d = 128)", "Theory √(S(S−1)/d)", "Ratio"],
    [[r["bound_symbols_S"], {"3": "role-bound tuple", "7": "one control step", "28": "chunk of 4 steps", "56": "chunk of 8 steps", "112": "chunk of 16 steps"}[r["bound_symbols_S"]],
      f3(fl(r["measured_sd"])), f3(fl(r["theory_sqrt_S(S-1)/d"])), f3(fl(r["ratio"]))] for r in cross if r["width_d"] == "128"],
    f"Table 4. Crosstalk between the bound score and the slot-aligned score for S independent unit vectors bound into one vector of width 128 (2,000 samples). Across widths 64, 128 and 256 the measured-to-theory ratio ranged from {f3(min(cross_ratios))} to {f3(max(cross_ratios))}.")

t_read = md_table(["Width d", "Steps L", "Symbols S", "Symbol error, plain unbinding", "Gaussian approximation", "With successive cancellation", "Chunk decoded exactly"],
    [[r["width_d"], r["steps_L"], r["bound_symbols_S"], f3(fl(r["symbol_error_plain"])), f3(fl(r["symbol_error_gaussian_theory"])), f3(fl(r["symbol_error_successive_cancellation"])), pc(fl(r["chunk_spelled_exactly"]), 1)]
     for r in readout if r["width_d"] in ("128", "256")],
    "Table 5. Reading a bound chunk code slot by slot (400 chunks of random symbols from an alphabet of 16 per setting).")

t_ident = md_table(["Check", "Value", "Requirement"],
    [[r["check"].replace("direct softmax against Z_m e^{b_m} / Σ Z e^b", "direct softmax against Equation 9"), sci(fl(r["value"])) if fl(r["value"]) < 1e-3 else f3(fl(r["value"])), r["requirement"]] for r in ident],
    "Table 6. Identities of a mixed softmax (256 word and 640 body scores per history) and the blend band of Proposition 5.")

def mins(r): return n0(fl(r["word_positions"])), n0(fl(r["body_positions"]))
t_minute = md_table(["Words as", "Body as", "Word positions", "Body positions", "Body share", "Causal pairs", "Reduction", "KV bytes per head and layer"],
    [[r["word_scheme"], r["body_scheme"], n0(fl(r["word_positions"])), n0(fl(r["body_positions"])), pc(fl(r["body_share"]), 1), p10(fl(r["causal_pairs"])), n0(fl(r["pair_reduction_vs_characters"])) + "×", n0(fl(r["kv_bytes_per_head_layer"]))] for r in mn],
    f"Table 7. One minute of a mixed stream: speech at 2.5 words per second ({f2(g('M00.letters_per_word'))} letters per word plus a separator) beside seven joints at 50 control steps per second. Keys and values of width 128 in BF16, 512 bytes per position, head and layer.", [12, 30, 10, 10, 9, 13, 11, 14])

t_rates = md_table(["Control rate", "Steps per body token", "Body tokens per second", "Body tokens per word", "Body share"],
    [[r["control_rate_hz"] + " Hz", r["steps_per_token"], f2(fl(r["body_tokens_per_second"])), f2(fl(r["body_tokens_per_word"])), pc(fl(r["body_share"]), 1)] for r in rates],
    "Table 8. Body tokens per word at three control rates, with one token per step or per chunk of 8 or 16 steps.")

def cell(enc, col, src="ret"):
    vals = [rv(enc, L, col) if src == "ret" else cv(enc, L, col) for L in Ls]
    return " / ".join("–" if v != v else f2(v) for v in vals)
t_chunks = md_table(["Encoder", "Floats per chunk", "Address: exact chunk first", "Similar motion: nearest found", "Reconstructed within 0.04 rad", "Characters decoded exactly"],
    [[ENCLAB[e], "L·128" if e == "per-step slots" else "128", cell(e, "address_exact"), cell(e, "similar_nearest_l2"), cell(e, "pass_0.04_all", "rec"),
      cell(e, "spelled_exactly", "rec") if e in ("bound characters", "per-step slots") else "–"] for e in ENC],
    f"Table 9. Chunk tokens against chunk length, L = 4 / 8 / 16 / 32 steps, at width 128 (1,000 histories per cell for retrieval; 2,048 chunks for reconstruction). Address queries carry relative noise σ = 0.5; similar-motion queries are fresh executions of the target's skill. Scores use the distance rule.", [16, 9, 22, 22, 22, 22])

def wcell(enc, col, src="ret"):
    vals = [rv(enc, 16, col, d) if src == "ret" else cv(enc, 16, col, d) for d in (64, 128, 256)]
    return " / ".join("–" if v != v else f2(v) for v in vals)
t_width = md_table(["Encoder", "Address: exact first", "Similar: nearest found", "Within 0.04 rad", "Characters decoded exactly"],
    [[ENCLAB[e], wcell(e, "address_exact"), wcell(e, "similar_nearest_l2"), wcell(e, "pass_0.04_all", "rec"), wcell(e, "spelled_exactly", "rec") if e in ("bound characters", "per-step slots") else "–"] for e in ENC],
    "Table 10. Chunks of 16 steps (112 values) at widths d = 64 / 128 / 256.", [20, 18, 18, 18, 18])

t_rank = md_table(["Code rank r", "Learned linear ISET: RMS (rad)", "Learned: within 0.04, no contact / contact", "DCT: RMS (rad)", "DCT: within 0.04, no contact / contact"],
    [[str(r_), f4(kv(r_, "learned linear ISET", "rms_all")), f"{f2(kv(r_, 'learned linear ISET', 'pass_0.04_no_contact'))} / {f2(kv(r_, 'learned linear ISET', 'pass_0.04_contact'))}",
      f4(kv(r_, "DCT", "rms_all")), f"{f2(kv(r_, 'DCT', 'pass_0.04_no_contact'))} / {f2(kv(r_, 'DCT', 'pass_0.04_contact'))}"] for r_ in (14, 28, 56, 112)],
    f"Table 11. Reconstruction of 16-step chunks from r coefficients, and the write-time confidence check at a tolerance of 0.04 rad ({pc(g('M02.L16_contact_share'))} of these chunks contain a contact).")

cases = [("v1 (skills 0–31), chunks of those skills", "v1 on its own skills"), ("v1, chunks of the 32 new skills", "v1 on 32 new skills"),
         ("v2 (all 64 skills), old chunks re-encoded", "v2 on old skills, re-encoded"), ("v2, new chunks", "v2 on new skills"),
         ("old codes written by v1, read by v2", "codes written by v1, read by v2"), ("DCT (training-free), old chunks", "DCT, old skills"), ("DCT (training-free), new chunks", "DCT, new skills")]
t_stale = md_table(["Case", "Rank 28: RMS (rad)", "Rank 28: within 0.04", "Rank 56: RMS (rad)", "Rank 56: within 0.04"],
    [[lab, f4(sv(28, c, "rms")), f2(sv(28, c, "pass_0.04_all")), f4(sv(56, c, "rms")), f2(sv(56, c, "pass_0.04_all"))] for c, lab in cases],
    "Table 12. Coverage and staleness of a learned encoder. v1 is fitted to the first 32 skills, v2 is refitted to all 64; the DCT encoder needs no fitting.")

cal_rows = [[f"raw dot product, ratio {lab}", f3(calv("raw dot product", r_, "word_exact")), f3(calv("raw dot product", r_, "word_query_chunk_intrusion")),
             f3(calv("raw dot product", r_, "chunk_address_within_tolerance")), f3(calv("raw dot product", r_, "chunk_query_word_intrusion")), f3(calv("raw dot product", r_, "chunk_similar_nearest"))]
            for r_, lab in ((0.125, "1/8"), (0.5, "1/2"), (1, "1"), (2, "2"), (8, "8"))]
for rule in ("key-normalized (cosine)", "per-type normalized dot product", "per-type normalized distance"):
    cal_rows.append([f"{rule}, any ratio", f3(calv(rule, 1, "word_exact")), f3(calv(rule, 1, "word_query_chunk_intrusion")), f3(calv(rule, 1, "chunk_address_within_tolerance")),
                     f3(calv(rule, 1, "chunk_query_word_intrusion")), f3(calv(rule, 1, "chunk_similar_nearest"))])
t_cal = md_table(["Score rule and chunk-to-word norm ratio", "Word query: exact word first", "Word query: a chunk wins", "Chunk address: within tolerance", "Chunk query: a word wins", "Similar motion: nearest found"],
    cal_rows, f"Table 13. One softmax over the distinct words of a 256-token history ({g('M03.cal_mean_distinct_words'):.0f} on average) and 256 chunks (1,000 histories). The chunk encoder's output is rescaled so that its root-mean-square key norm is a given multiple of the word keys'. The three normalized rules gave identical results at all five ratios.")

t_dil = md_table(["Body tokens per word", "Bias on body tokens", "Mass on the target word", "Mass on other words", "Mass on body tokens"],
    [[str(pw).rstrip("0").rstrip("."), bias, f3(dv(pw, 8, bias, "mass_on_target_word")), f3(dv(pw, 8, bias, "mass_on_other_words")), f3(dv(pw, 8, bias, "mass_on_body_tokens"))]
     for pw in (1.25, 2.5, 20.0) for bias in ("none", "log-count bias")],
    "Table 14. Where the attention of a word query goes at inverse temperature β = 8 (distance rule, 400 histories). 1.25 and 2.5 body tokens per word correspond to chunks of 16 and 8 steps at 50 Hz; 20 to one token per step.")

readers = ["dense character-level attention", "pooled scan only", K8, K32]
t_long = md_table(["Reader", "Word query: exact, M = 256 / 1,024 / 4,096 / 16,384", "Chunk address: exact, same M", "Multiply-adds per word query at 16,384", "Per chunk query at 16,384"],
    [[r.replace("dense character-level attention", "dense attention over letters and control steps"), " / ".join(f2(lv(r, mm, "word_exact")) for mm in (256, 1024, 4096, 16384)),
      " / ".join(f2(lv(r, mm, "chunk_address_exact")) for mm in (256, 1024, 4096, 16384)), n0(lv(r, 16384, "mac_per_word_query")), n0(lv(r, 16384, "mac_per_chunk_query"))] for r in readers],
    f"Table 15. Mixed histories of M tokens, two in seven of them words (200 histories per length, width 128, query noise σ = 0.5). The rerank compares slots only within the query's type. Pooled scans read one vector per distinct word ({n0(g('M03.long_M16384_distinct_words'))} of the {n0(round(2 * 16384 / 7))} word tokens at 16,384) and per chunk; dense attention reads every letter and separator of every word token and every control step.", [24, 22, 22, 13, 13])

t_depth = md_table(["Context mixed into the key (ratio to self)", "Word found exactly", "Word spelled from the key", "Chunk found exactly", "Chunk found within tolerance", "Chunk decoded: RMS (rad)", "Chunk decoded within 0.04"],
    [[f2(fl(r["context_to_self_ratio"])), f3(fl(r["word_exact"])), f3(fl(r["word_spelled_from_key"])), f3(fl(r["chunk_address_exact"])), f3(fl(r["chunk_address_within_tolerance"])),
      f3(fl(r["chunk_reconstruction_rms"])), f3(fl(r["chunk_reconstruction_pass_0.04"]))] for r in dep],
    "Table 16. A deeper-layer key: the token's own vector plus the mean of the previous 16 tokens, scaled to a given ratio of its norm (1,000 mixed histories of 512 tokens).")

t_assoc = md_table(["Interaction share ι", "Bound tuple: right pair / RMS", "Role slots: right pair / RMS", "Linear map: RMS", "Best additive fit: RMS", "Describe: bound tuple", "Describe: role slots", "Describe: linear map"],
    [[f2(i), f"{f3(av(i, 'plan_tuple_top1_right_pair'))} / {f3(av(i, 'plan_tuple_top1_rms'))}", f"{f3(av(i, 'plan_role_slots_right_pair'))} / {f3(av(i, 'plan_role_slots_rms'))}",
      f3(av(i, "plan_linear_map_rms")), f3(av(i, "additive_floor_rms")), f3(av(i, "describe_tuple_both")), f3(av(i, "describe_role_slots_both")), f3(av(i, "describe_linear_both"))] for i in (0.0, 0.25, 0.5, 1.0)],
    f"Table 17. Planning (verb and object → action) and description (fresh action → verb and object) for 256 pairs with four stored executions each, width 128. RMS is the error of the planned 8-step chunk against the pair's prototype; stored executions themselves differ from it by about {f3(av(0.5, 'execution_floor_rms'))} rad.", [10, 14, 14, 10, 11, 11, 11, 11])

mc_names = ["overall mean (β = 0)", "soft read, β = 10", "soft read, β = 30", "soft read, β = 100", "soft read, β = 300", "hard top-1 read",
            "mode first (K = 2), then soft within", "sampled mode (K = 2), then soft within", "prototype only (K = 2)", "mode first (K = 8), then soft within", "sampled mode (K = 8), then soft within"]
t_mode = md_table(["Reader", "Collision rate", "Off-manifold RMS", "Nearest stored / spacing", "Share passing left"],
    [[n, f3(mv(n, "collision_rate")), f3(mv(n, "off_manifold_rms")), f2(mv(n, "nearest_stored_over_spacing")), f3(mv(n, "left_share"))] for n in mc_names],
    f"Table 18. Reading a two-mode action from 512 stored executions with one cue (1,000 queries). Collision: the trajectory comes within 0.3 of the centre line in steps 5–10. Novelty is the distance to the nearest stored execution divided by their mean spacing ({f3(g('M05.spacing'))}). Within-mode reads use β = 10.")

# ---------------- derived numbers ----------------
chars_row = next(r for r in mn if r["body_scheme"].startswith("motor"))
w8 = next(r for r in mn if r["body_scheme"] == "chunks of 8 steps")
step_row = next(r for r in mn if r["body_scheme"] == "one token per control step" and r["word_scheme"] == "words")
red8 = fl(w8["pair_reduction_vs_characters"])
bytes_ratio = fl(chars_row["kv_bytes_per_head_layer"]) / fl(w8["kv_bytes_per_head_layer"])
lin_add_gap = max(abs(av(i, "plan_linear_map_rms") / av(i, "additive_floor_rms") - 1) for i in (0.25, 0.5, 1.0))
read_gap = max(abs(fl(r["symbol_error_plain"]) / fl(r["symbol_error_gaussian_theory"]) - 1) for r in readout if fl(r["symbol_error_gaussian_theory"]) > 0.2)

md = f"""---
title: "Words and Action Chunks in One Dense Key–Value Cache: ISET Chunk Tokens, Bound Word Keys and Mixed-Modal Attention"
author: "Debi Prasad Ghosh"
date: "November 2026"
abstract: |
  An embodied agent reads words but acts through motor characters, many joint commands per second. The hybrid design of this series keeps word-level vocabularies for language and the other word modes, and uses an invertible sequence embedding (ISET) only for the body, where each action chunk becomes one token. This paper studies Part 1 of that design, in which word tokens and ISET chunk tokens are both stored as dense vectors in one key–value cache, before any sparse Vocabucapillary memory. It formulates the two kinds of token, one softmax over both, a two-stage reader, association between words and actions, and a read-out that chooses an action mode, and it tests them in an immutable C# laboratory whose key quantities an independent Python check reproduced ({py_agree} agreed). Chunking a seven-joint stream at 50 steps per second into 8-step tokens cut causal query–key pairs per minute {n0(red8)}-fold against character-level attention, and left 2.5 body tokens per word instead of 20. One dense vector per chunk served either as an address or as a metric, not both. Bound motor characters found the exact stored chunk in every trial, yet could not be decoded beyond one control step at width 128, as a Gaussian crosstalk approximation predicted. A learned linear ISET decoded every chunk within 0.04 rad and found the nearest motion in {pc(rv('learned linear ISET', 8, 'similar_nearest_l2'), 1)} of queries, but as an address it often returned a near-duplicate execution. In one softmax, raw dot products let chunk keys win {pc(calv('raw dot product', 8, 'word_query_chunk_intrusion'), 1)} of word queries when their norm was eight times larger. Per-type normalization with a distance score made retrieval independent of encoder scale. Context mixed into a key at a quarter of its norm left only {pc(depv(0.25, 'chunk_reconstruction_pass_0.04'), 1)} of chunks decodable within tolerance. A linear map from words to actions reached exactly the best additive fit and missed every verb–object interaction, while role slots retrieved the right action for all 256 pairs. A soft attention read of a two-mode action collided with the obstacle in {pc(mv('soft read, β = 30', 'collision_rate'), 1)} of queries at β = 30; choosing the mode first never collided.
---

# 1 Introduction

A language model chooses among a few tens of thousands of tokens, and a few thousand tokens describe a page. A robot arm must specify every joint many times a second, and its useful resolution is a fraction of a degree. The Vocabucapillary series treats both with two-level vocabularies: a small fixed set of primitives, and a dynamic vocabulary of units built as sequences of them (Ghosh, 2026a, 2026b). For text the primitives are letters and the units are words. For the body the primitives are motor characters, the quantized increments of each joint, and the natural units are chunks of control steps.

Step 1 of the word-level programme kept an ordinary dense key–value cache and asked how word-level attention should score a word stored as a sequence of letter slots (Ghosh, 2026f). The cerebellum paper argued that the body needs a different route, a character-level ISET that turns short spans of fine motor characters into compact codes (Ghosh, 2024, 2026e). The hybrid design brings the two together: ISET is used only for the character-level body modes, where it chunks actions, and word-level coding is kept for language, visual objects and audio words. The cache then holds two kinds of entry, and an association vocabulary must learn tuples that mix them.

This paper is Part 1 of that hybrid. Every entry is a dense vector: a word becomes the training-free bound key of Step 1, and an action chunk becomes one ISET vector. Part 2 will replace the word entries by sparse word-Vocabucapillary records. Part 1 shows what the dense version can do on its own, and therefore what Part 2 must add. Six questions organise it.

1. What does chunking buy in positions, pairs and memory when a body stream runs beside speech? (Section 5)
2. Can one dense vector per chunk find the exact stored chunk, find the nearest motion, and be decoded back into joint commands? (Section 6)
3. Can one softmax serve two encoders whose keys differ in scale and geometry? (Section 7)
4. Does retrieval stay exact over long mixed histories, and what does a deeper-layer key still carry? (Section 8)
5. Without association atoms, how can words and actions be associated in both directions? (Section 9)
6. How can an action be read from the cache without averaging two valid ways of doing it? (Section 10)

Section 4 states five exact properties that frame the answers, and Section 11 assembles a Part 1 design. All numbers come from the immutable C# laboratory described in Appendix B. Figure 1 summarises the design.

![Figure 1. Words and ISET action chunks in one dense key–value cache.](FIG/fig1_mixed_cache.png){{width=6.5in}}

# 2 Related work

Table 1 places the proposal among ways of representing robot actions. Vision–language–action models first wrote each action dimension as a bin among text tokens (Zitkovich et al., 2023), as did the generalist agent Gato, which serialised text, images and μ-law-binned actions into one token sequence (Reed et al., 2022). FAST compresses a chunk with a discrete cosine transform before tokenization (Pertsch et al., 2025). Behavior Transformers predict a k-means bin and a continuous offset, which lets them keep several modes of human demonstrations (Shafiullah et al., 2022), and VQ-BeT replaces the bins with hierarchical vector-quantized codes of chunks (Lee et al., 2024). Action chunking with transformers predicts whole chunks and smooths them by temporal ensembling (Zhao et al., 2023), while Diffusion Policy and π0 generate continuous chunks by diffusion or flow matching, which handles multimodal action distributions by iterative sampling (Chi et al., 2023; Black et al., 2024). In all of these, actions are predicted outputs. None of them keeps past chunks as cache entries that word queries and action queries both read.

Mixing modalities in one softmax is known to be delicate. In the Chameleon models, where all weights are shared across modalities, the authors report that each modality tends to compete with the others by increasing its norms, and query–key normalization was needed for stable training (Chameleon Team, 2024; Henry et al., 2020). Kim et al. (2021) replaced the dot-product logit by a negative squared distance to make self-attention Lipschitz. Section 7 shows why a per-type form of that distance score suits a cache that holds both categorical word codes and metric action codes.

Binding fillers to roles with orthogonal operators is the basis of tensor product representations, holographic reduced representations and hyperdimensional computing (Smolensky, 1990; Plate, 1995; Kanerva, 2009), and linear associative memories store pairs in one matrix (Kohonen, 1972). Section 9 compares a bound tuple, separate role slots and a linear map as forms of association in a dense cache. Within the series, the character paper showed that compact span codes address text well but spell it poorly (Ghosh, 2026d), and the cerebellum paper modelled the cerebellum as a character-level ISET and showed that mean regression collides in a two-way obstacle task (Ghosh, 2026e).

{t_related}
# 3 Formulation

The design of Figure 1 has two kinds of token, one cache with one softmax, and three ways of reading it: retrieval, association and action.

## 3.1 Two kinds of token

**Words.** A word of n ≤ 16 letters is stored, as in Step 1, by the training-free bound key

$$k^{{\\mathrm{{w}}}}(w) = \\sum_{{j=1}}^{{n}} R_j\\, e(c_j) + R_{{n+1}}\\, e(\\mathrm{{EOS}}), \\quad\\quad\\quad (1)$$

where e(c) are seeded unit vectors of width d and each Rⱼ is a random signed permutation. The concatenated letter slots are kept beside it for reranking.

**Action chunks.** The body has seven joints. A chunk is L control steps of all joints, $x \\in ℝ^{{7L}}$, and its motor characters $c_{{jt}}$ are closed-loop increments of 0.04 rad from an alphabet of 16, as in the cerebellum paper. An ISET encoder E maps the chunk to one vector z of width d, a decoder D maps codes back to joint positions, and the write-time error

$$\\epsilon(x) = \\lVert D(E(x)) - x \\rVert / \\sqrt{{7L}} \\quad\\quad\\quad (2)$$

is stored with the token. Table 2 lists four encoders. The bound encoder is the analytic, invertible stand-in for ISET used earlier in the series, $\\sum_{{t,j}} R_{{7(t-1)+j}}\\, e(c_{{jt}})$. Per-step slots keep one bound vector per step. The learned linear ISET keeps the top r principal components of training chunks,

$$z = U_r^{{\\top}}(x - \\mu), \\qquad D(z) = \\mu + U_r z, \\quad\\quad\\quad (3)$$

and the DCT encoder keeps the lowest k cosine coefficients of every joint. A chunk record also carries the encoder's version and, for exact replay, a pointer to its raw characters.

{t_enc}
## 3.2 One cache, one softmax

Each cache entry holds a key kₜ, a value vₜ and a type mₜ, word or chunk. A query q of either type scores every entry with one of the rules of Table 3 and reads

$$\\pi_t = \\frac{{\\exp(\\beta\\, s(q,t) + b_{{m_t}})}}{{\\sum_{{t' \\le T}} \\exp(\\beta\\, s(q,t') + b_{{m_{{t'}}}})}}, \\qquad y = \\sum_t \\pi_t\\, v_t, \\quad\\quad\\quad (4)$$

with an inverse temperature β and an optional bias $b_m$ per type. The per-type normalized distance rule divides every key and query by the root-mean-square key norm $n_m$ of its type and scores

$$s(q,t) = \\tilde q^{{\\top}} \\tilde k_t - \\tfrac{{1}}{{2}} \\lVert \\tilde k_t \\rVert^2 = \\tfrac{{1}}{{2}}\\lVert \\tilde q \\rVert^2 - \\tfrac{{1}}{{2}}\\lVert \\tilde q - \\tilde k_t \\rVert^2. \\quad\\quad\\quad (5)$$

In a transformer this needs one extra key component holding $-\\tfrac{{1}}{{2}}\\lVert \\tilde k_t \\rVert^2$ and a matching query component equal to one.

{t_rules}
## 3.3 Two-stage reading

Over long histories a pooled screen scores every entry by its one vector, keeps the best K, and reranks those of the query's own type with their slots: letter slots for words, per-step slots for chunks. The rerank is typed because a word's sixteen letter slots and a chunk's L step slots cannot be compared with each other.

## 3.4 Association without atoms

An episode pairs a verb â, an object ô and the code ẑ of the chunk that did it (all unit vectors). Three forms of association are compared:

$$k^{{\\mathrm{{tuple}}}} = R_1 \\hat a + R_2 \\hat o + R_3 \\hat z, \\qquad k^{{\\mathrm{{slots}}}} = [\\hat a;\\ \\hat o;\\ \\hat z], \\qquad \\hat z \\approx W [\\hat a;\\ \\hat o]. \\quad\\quad\\quad (6)$$

The bound tuple stores one vector of width d per episode. Role slots store three. The linear map stores no episodes, only a matrix fitted by ridge regression, which is how attention projections would hold the association implicitly. Planning cues the tuple with the words and reads the action from the value. Description cues it with a chunk and reads the words, by unbinding for the tuple or directly for the slots.

## 3.5 Reading an action

A soft read returns $y = \\sum_t \\pi_t z_t$ and decodes D(y). A hard read decodes the single best entry. A mode-first read groups the stored codes into K clusters $C_m$ beforehand, sums the attention mass of each cluster, picks one, and reads softly inside it:

$$P_m = \\sum_{{t \\in C_m}} \\pi_t, \\qquad m^\\ast = \\arg\\max_m P_m \\ \\mathrm{{or}}\\ m^\\ast \\sim P, \\qquad y = \\frac{{1}}{{P_{{m^\\ast}}}} \\sum_{{t \\in C_{{m^\\ast}}}} \\pi_t\\, z_t. \\quad\\quad\\quad (7)$$

The fast loop of the body then corrects the residual at actuator rate.

# 4 Exact properties

**Proposition 1 (crosstalk of bound codes).** If S independent unit vectors are bound into one vector of width d by orthogonal operators, the bound score of two such codes equals their slot-aligned score plus crosstalk of mean zero and variance S(S − 1)/d. Unbinding one slot meets noise of variance (S − 1)/d, so with an alphabet of A random unit vectors the probability of reading the slot correctly is approximately

$$P \\approx \\int \\varphi(u)\\, \\Phi\\!\\left(\\frac{{1 + s_c u}}{{s_w}}\\right)^{{A-1}} du, \\qquad s_c^2 = \\frac{{S-1}}{{d}}, \\quad s_w^2 = \\frac{{S}}{{d}}. \\quad\\quad\\quad (8)$$

The variance formula is Step 1's, with the S = 7L characters of a chunk in place of the letters of a word, and with S = 3 for a tuple of three roles. Table 4 confirms it. Table 5 shows that Equation 8 predicts the measured symbol error of plain unbinding to within {pc(read_gap, 1)} wherever more than a fifth of the symbols are wrong; at light load it slightly overestimates the error. The consequence is stark. At width 128 a single control step (S = 7) is read back exactly in {pc(rdv(128, 1, 'chunk_spelled_exactly'), 1)} of cases, but a chunk of 4 steps in only {pc(rdv(128, 4, 'chunk_spelled_exactly'), 1)}, and longer chunks never. Successive cancellation does not rescue it: once about half the symbols are wrong, subtracting wrong symbols adds errors ({f3(rdv(128, 8, 'symbol_error_successive_cancellation'))} against {f3(rdv(128, 8, 'symbol_error_plain'))} at L = 8).

{t_cross}
{t_read}
**Proposition 2 (modality mass and count).** In Equation 4 the attention mass on type m is

$$\\Pi_m = \\frac{{e^{{b_m}} Z_m}}{{\\sum_{{m'}} e^{{b_{{m'}}}} Z_{{m'}}}}, \\qquad Z_m = \\sum_{{t:\\, m_t = m}} e^{{\\beta s(q,t)}}. \\quad\\quad\\quad (9)$$

If every token of type m were repeated n times, $Z_m$ would grow n-fold. A bias $b_m = -\\log n$ undoes this exactly, so a log-count bias removes the effect of the token rate on the mass of a type, without changing the weights within it.

**Proposition 3 (encoder scale).** Multiplying every key of one type by c multiplies the logits β s(q, t) of that type's entries by c under the dot-product rule, which is the same as giving that type its own inverse temperature cβ. An encoder's arbitrary output scale therefore acts as a hidden temperature, the competition between modalities that Chameleon met in training. Per-type normalization removes the dependence exactly, and so does key normalization, but key normalization also removes each key's norm, which carries the amplitude of a motion. The distance rule of Equation 5 keeps it: within a type, it ranks keys by Euclidean distance to the query.

**Proposition 4 (additive association).** Any linear map of the concatenated word vectors gives $W[\\hat a; \\hat o] = f(\\hat a) + g(\\hat o)$, a sum of a verb term and an object term. For a table of actions $x_{{vo}}$, the best such fit in squared error is the two-way additive decomposition $\\bar x_{{v\\cdot}} + \\bar x_{{\\cdot o}} - \\bar x_{{\\cdot\\cdot}}$, and its error is the interaction part of the table. This is Step 1's conjunction limit in another guise: a sum over roles cannot express what depends on the pair.

**Proposition 5 (blending and choosing).** Let two mirror-image modes ±A φ(t) be read with mass $\\pi_L$ on the left mode and $1 - \\pi_L$ on the right. The read is $(2\\pi_L - 1) A \\varphi(t)$, and it enters a band |y| < 0.3 around the centre line during steps 5–10 exactly when

$$|2\\pi_L - 1| < \\frac{{0.3}}{{A \\min_{{t \\in [5,10]}} \\varphi(t)}}. \\quad\\quad\\quad (10)$$

For A = 1 this is ${f3(g('M01.blend_band_low'))} < \\pi_L < {f3(g('M01.blend_band_high'))}$. A read inside one mode stays inside it whenever the set of valid actions of that mode is convex, which is why a mode-first read cannot collide.

{t_ident}
# 5 Accounting for a mixed stream

The laboratory takes English word lengths from the wordfreq list (Speer, 2022): {f2(g('M00.letters_per_word'))} letters per word in the 50,000-word lexicon. At 2.5 words per second, one minute of speech is 150 words, or {n0(fl(w8['word_positions']) * (g('M00.slots_per_word')))} character positions with separators. A body of seven joints at 50 control steps per second produces 3,000 steps and 21,000 motor characters in the same minute.

{t_minute}
Table 7 shows what each tokenization costs. Character-level attention over letters and motor characters has {p10(fl(chars_row['causal_pairs']))} causal pairs per minute, and the body holds {pc(fl(chars_row['body_share']))} of the positions. Words and one token per step cut this {n0(fl(step_row['pair_reduction_vs_characters']))}-fold, and words with chunks of 8 steps cut it {n0(red8)}-fold, to {n0(fl(w8['causal_pairs']))} pairs. Body–body pairs fall by a factor close to L², {n0(g('M00.body_pair_reduction_L8'))} for L = 8. The key–value cache shrinks {n0(bytes_ratio)}-fold, to {n0(fl(w8['kv_bytes_per_head_layer']))} bytes per head and layer.

{t_rates}
Chunking also restores balance in the softmax. At 50 Hz with one token per step, 20 body tokens follow every word and the body holds 95% of positions; with chunks of 8 steps it is 2.5 tokens per word, and with 16 steps 1.25 (Table 8). Faster control loops need longer chunks for the same balance: at 1,000 Hz even 16-step chunks leave 25 body tokens per word.

Raw motor characters are cheap to keep. An 8-step chunk is 56 characters of 4 bits, {n0(g('M00.raw_chunk_bytes_L8'))} bytes, against {n0(g('M00.bytes_per_token'))} bytes for its key and value in one head and layer. A pointer to raw characters for exact replay therefore costs little; what costs is every vector that attention must read.

# 6 Dense tokens for action chunks

Study M02 builds a library of 64 skills. Each skill moves every joint by a sum of four sinusoids with random amplitudes and phases; an execution scales the skill by 1 + 0.1 N(0, 1), adds sensor noise of 0.005 rad, and adds contact transients of 0.08 N(0, 1) rad at a rate of one per 32 steps. Motor characters follow every motion with an error of {f4(g('M02.L8_char_floor_rms'))} rad RMS. The learned linear ISET is fitted to 4,096 training executions and tested on 2,048 others. Two kinds of query are posed in histories of 256 chunks that contain the target, eight other executions of its skill and 247 chunks of other skills. An address query is the target's own code with relative noise σ = 0.5, as in Step 1, and must find that exact chunk. A similar-motion query is a fresh execution of the target's skill and should find the stored chunk nearest to it in joint space.

{t_chunks}
![Figure 2. Chunk tokens against chunk length: address retrieval, similar-motion retrieval and reconstruction.](FIG/fig2_chunk_tokens.png){{width=6.5in}}

The encoders split cleanly into addresses and metrics (Table 9, Figure 2).

- **Bound motor characters are addresses.** They found the exact chunk in every trial from L = 8 on ({pc(rv('bound characters', 4, 'address_exact'), 1)} at L = 4), because one wrong character changes the code as much as any other change. For the same reason they ordered motions poorly: the nearest motion was found in only {pc(rv('bound characters', 8, 'similar_nearest_l2'))} of similar-motion queries at L = 8. They could not be decoded at all beyond one control step, as Proposition 1 predicts: {pc(cv('bound characters', 4, 'pass_0.04_all'), 1)} of 4-step chunks and none longer came back within tolerance.
- **Per-step slots are addresses that decode.** With one bound vector per step they were also exact addresses, and they decoded {pc(cv('per-step slots', 8, 'pass_0.04_all'))} of 8-step chunks within tolerance, but at L times the memory.
- **Linear ISETs are metrics that decode.** The learned linear ISET found the nearest motion in {pc(rv('learned linear ISET', 8, 'similar_nearest_l2'), 1)} of queries and reconstructed every chunk within tolerance at all lengths, with a residual of {f4(cv('learned linear ISET', 8, 'rms_all'))} rad at L = 8 that is mostly BF16 rounding. As an address it found the exact chunk in only {pc(rv('learned linear ISET', 8, 'address_exact'))} of queries at L = 8, because executions of one skill lie close together in joint space. Most misses were harmless: the returned chunk was within tolerance of the target in {pc(rv('learned linear ISET', 8, 'address_within_tolerance'), 1)} of queries.
- **Amplitude needs the distance rule.** Scored by cosine, the learned ISET found the nearest motion in only {pc(rv('learned linear ISET', 8, 'similar_nearest_cosine'))} of queries, because the norm of a code carries the amplitude of the motion and cosine discards it.

The DCT encoder behaved like the learned one wherever both kept all the information. Width matters most for the categorical codes (Table 10). Per-step slots of width 64 decoded only {pc(cv('per-step slots', 16, 'spelled_exactly', 64), 1)} of 16-step chunks exactly, and of width 256 all of them. The learned ISET stayed within tolerance even at width 64, because it needs only as many dimensions as the motions really have. Address noise hurt the metric codes and not the categorical ones: at L = 8, the learned ISET's exact-address rate fell from {pc(rv('learned linear ISET', 8, 'address_exact', 128, '0.25'))} at σ = 0.25 to {pc(rv('learned linear ISET', 8, 'address_exact', 128, '1'))} at σ = 1, while bound characters stayed above 99%.

{t_width}
How many dimensions the motions have is what the learned encoder exploits (Table 11). For 16-step chunks, the top 28 principal components carry {pc(g('M02.pca_energy_top28'), 2)} of the variance, and 28 learned coefficients kept {pc(kv(28, 'learned linear ISET', 'pass_0.04_all'), 1)} of chunks within tolerance, against {pc(kv(28, 'DCT', 'pass_0.04_all'), 1)} for 28 DCT coefficients. At rank 56 both passed every chunk. When the rank is too small, contact chunks fail first: at rank 28 the learned encoder passed {pc(kv(28, 'learned linear ISET', 'pass_0.04_no_contact'), 1)} of chunks without contact and {pc(kv(28, 'learned linear ISET', 'pass_0.04_contact'), 1)} with one. The write-time check of Equation 2 therefore flags exactly the chunks that should keep their raw characters.

{t_rank}
A learned encoder is fitted to the skills it has seen, and its codes belong to its version (Table 12). At rank 28, an encoder fitted to 32 skills reconstructed their chunks within tolerance in {pc(sv(28, 'v1 (skills', 'pass_0.04_all'), 1)} of cases, but chunks of 32 new skills in only {pc(sv(28, 'v1, chunks of the 32 new', 'pass_0.04_all'), 1)}. Refitting on all 64 skills restored both, {pc(sv(28, 'v2 (all', 'pass_0.04_all'), 1)} and {pc(sv(28, 'v2, new', 'pass_0.04_all'), 1)}. Old codes read with the refitted decoder, however, were useless at either rank, {f3(sv(28, 'old codes', 'rms'))} rad RMS and nothing within tolerance, because a refit rotates the basis (mean overlap of matched components {f2(g('M02.stale_r28_basis_overlap'))}). A cache of learned codes needs either a frozen encoder or a version tag and re-encoding. The training-free DCT never goes stale, at the price of twice the rank.

{t_stale}
# 7 One softmax over two encoders

Study M03 puts word keys and chunk keys in one cache. Words are bound keys of width 128 drawn as in Step 1: a target word, up to eight near-duplicates (anagrams, affix relatives and words one edit away) and frequency-sampled fillers. Chunks are learned linear ISET codes of 8-step chunks with the structure of Section 6. The root-mean-square key norms are {f2(g('M03.word_key_rms_norm'))} for words and {f2(g('M03.chunk_key_rms_norm'))} for chunks. To expose the effect of scale, the chunk encoder's output is multiplied so that its norm is a given multiple of the word keys' norm, as if two separately trained encoders had arrived at different scales. Table 13 compares the four rules of Table 3.

{t_cal}
![Figure 3. One softmax over two encoders: retrieval against the norm ratio of the encoders, and the attention mass that body tokens take from a word query.](FIG/fig3_one_softmax.png){{width=6.5in}}

The rule decides everything (Table 13, Figure 3).

- **Raw dot products fail at both extremes.** When chunk keys were eight times longer than word keys, a chunk won {pc(calv('raw dot product', 8, 'word_query_chunk_intrusion'), 1)} of word queries. When they were eight times shorter, a word won {pc(calv('raw dot product', 0.125, 'chunk_query_word_intrusion'), 1)} of chunk queries. Even at equal scale, raw dot products favoured long keys within the chunk type: the address was within tolerance in only {pc(calv('raw dot product', 1, 'chunk_address_within_tolerance'), 1)} of queries.
- **Normalization removes the intrusions.** All three normalized rules gave the same result at every ratio, as Proposition 3 requires, and no query was captured by the other type.
- **Only the distance rule keeps the metric.** Key normalization lost the amplitude of motions (nearest motion {pc(calv('key-normalized (cosine)', 1, 'chunk_similar_nearest'), 1)}), and the per-type normalized dot product still favoured long chunk keys ({pc(calv('per-type normalized dot product', 1, 'chunk_similar_nearest'), 1)}). The per-type normalized distance found the exact word in every query, kept chunk addresses within tolerance in {pc(calv('per-type normalized distance', 1, 'chunk_address_within_tolerance'), 1)} and found the nearest motion in {pc(calv('per-type normalized distance', 1, 'chunk_similar_nearest'), 1)}.

{t_dil}
Even with the right rule, many body tokens dilute a word query (Table 14). At β = 8, body tokens took {pc(dv(1.25, 8, 'none', 'mass_on_body_tokens'), 1)} of the mass with 1.25 body tokens per word, {pc(dv(2.5, 8, 'none', 'mass_on_body_tokens'), 1)} with 2.5 and {pc(dv(20.0, 8, 'none', 'mass_on_body_tokens'), 1)} with 20, and the mass on the target word fell from {f3(dv(1.25, 8, 'none', 'mass_on_target_word'))} to {f3(dv(20.0, 8, 'none', 'mass_on_target_word'))}. A log-count bias held the body share at {pc(dv(20.0, 8, 'log-count bias', 'mass_on_body_tokens'), 1)} whatever the rate, as Proposition 2 predicts. The temperature matters as much as the count: at β = 4 the read was diffuse at every rate, and at β = 16 the leak stayed below {pc(dv(20.0, 16, 'none', 'mass_on_body_tokens'), 0)} even at 20 body tokens per word.

# 8 Long mixed histories and deeper layers

Over long histories, the two-stage reader of Step 1 carries over to a mixed cache (Table 15, Figure 4). Histories of 256 to 16,384 tokens held two words for every five chunks, the balance of 8-step chunks at 50 Hz. A pooled screen with the distance rule and a typed slot rerank of eight entries found the exact word and the exact chunk in every trial at every length. The pooled scan alone was exact for words but found the exact chunk in only {pc(lv('pooled scan only', 16384, 'chunk_address_exact'), 1)} of queries at 16,384 tokens: the metric screen brings the near-duplicate executions forward, and the categorical step slots then separate them. With the screen reading one vector per distinct word and per chunk, the work per query was {n0(lv(K8, 16384, 'mac_per_word_query'))} multiply-adds for a word query against {n0(lv('dense character-level attention', 16384, 'mac_per_word_query'))} for dense attention over letters and control steps, {f2(lv('dense character-level attention', 16384, 'mac_per_word_query') / lv(K8, 16384, 'mac_per_word_query'))} times fewer.

{t_long}
![Figure 4. What a deeper-layer key still carries, and the work per query over long mixed histories.](FIG/fig4_depth_long.png){{width=6.5in}}

These results hold for keys written directly by the encoders. In a transformer, the keys of deeper layers are projections of contextual states, so a word position also carries its neighbours. Table 16 models this by adding the mean of the previous 16 tokens to each key at a given ratio of its own norm. Identity is robust: words were still found exactly with context at half the key's norm ({f3(depv(0.5, 'word_exact'))}). Spelling degrades sooner ({f3(depv(0.5, 'word_spelled_from_key'))} at half), and decoding of actions fails first: with context at a quarter of the key's norm, only {pc(depv(0.25, 'chunk_reconstruction_pass_0.04'), 1)} of chunks decoded within tolerance, and at half none did. The decoding error grew in proportion to the context, {f3(depv(0.25, 'chunk_reconstruction_rms'))} rad at a quarter and {f3(depv(0.5, 'chunk_reconstruction_rms'))} at half. Anything read back from a key, a spelling or a joint trajectory, should therefore be read from a memory layer whose keys and values the encoders write, not from arbitrary layers.

{t_depth}
# 9 Association between words and actions

Study M04 names 256 actions by sixteen verbs (*grasp*, *push*, *pull*, …) and sixteen objects (*cup*, *box*, *door*, …), all in the lexicon. The prototype chunk of each verb–object pair mixes a verb pattern, an object pattern and a pair-specific pattern, with the pair-specific part carrying a share ι of the variance: ι = 0 makes every action a sum of a verb motion and an object motion, and ι = 1 makes every pair different. Four executions of each pair are stored, 1,024 episodes in all.

{t_assoc}
![Figure 5. Planning error and description accuracy against the share of verb–object interaction.](FIG/fig5_association.png){{width=6.5in}}

The linear map behaved exactly as Proposition 4 says (Table 17, Figure 5). Its planning error equalled the best additive fit to within {pc(lin_add_gap, 1)} at every ι, {f3(av(0.25, 'plan_linear_map_rms'))}, {f3(av(0.5, 'plan_linear_map_rms'))} and {f3(av(1.0, 'plan_linear_map_rms'))} rad for ι = 0.25, 0.5 and 1. With no interaction it was the best planner of all ({f3(av(0.0, 'plan_linear_map_rms'))} rad), because it averages the four executions of each pair, and it described actions by their verb and object in {pc(av(0.0, 'describe_linear_both'), 1)} of cases. With full interaction it described only {pc(av(1.0, 'describe_linear_both'), 1)}.

Explicit memories do not depend on ι. Role slots retrieved an execution of the right pair for every planning cue at every ι, with errors at the level of the executions themselves ({f3(av(0.5, 'plan_role_slots_rms'))} rad at ι = 0.5), and described every fresh action correctly. The single bound tuple, a third of the memory, was close behind for planning (right pair in {pc(min(av(i, 'plan_tuple_top1_right_pair') for i in (0.0, 0.25, 0.5, 1.0)), 1)} to {pc(max(av(i, 'plan_tuple_top1_right_pair') for i in (0.0, 0.25, 0.5, 1.0)))} of cues) but weaker for description ({pc(min(av(i, 'describe_tuple_both') for i in (0.0, 0.25, 0.5, 1.0)), 1)} to {pc(max(av(i, 'describe_tuple_both') for i in (0.0, 0.25, 0.5, 1.0)), 1)}). A description cue names one role, so the two uncued roles of every stored tuple add crosstalk, and with 1,024 tuples the largest of it can overtake the right one. Width decides: at ι = 0.5 the bound tuple described {pc(g('M04.d32_desc_tuple'), 1)}, {pc(g('M04.d64_desc_tuple'), 1)}, {pc(av(0.5, 'describe_tuple_both'), 1)} and {pc(g('M04.d256_desc_tuple'), 1)} of actions at widths 32, 64, 128 and 256, while role slots described all of them at every width.

# 10 Choosing a mode before reading

Study M05 stores 512 executions of the two-way obstacle task of the cerebellum paper, half passing on the left and half on the right, all under one cue. Each key is the cue as written in its own episode's context, so the key carries no hint of the action, and each value is the learned linear ISET code of the trajectory.

{t_mode}
![Figure 6. Decoded actions for one query, and the collision rate of soft reads against the inverse temperature.](FIG/fig6_mode_choice.png){{width=6.5in}}

A soft read blends the two modes until it is sharp enough to be a hard read (Table 18, Figure 6). At β = 10 and β = 30 nearly every read collided ({pc(mv('soft read, β = 10', 'collision_rate'), 1)} and {pc(mv('soft read, β = 30', 'collision_rate'), 1)}); at β = 100 and β = 300 collisions fell to {pc(mv('soft read, β = 100', 'collision_rate'), 1)} and {pc(mv('soft read, β = 300', 'collision_rate'), 1)}, as the reads came to depend on a few entries. Collisions followed the band of Proposition 5. At β = 30, every colliding read had at least {f3(g('M05.soft_read_β__30_min_minor_mass_collided'))} of its mass on the minor mode and every clear read at most {f3(g('M05.soft_read_β__30_max_minor_mass_clear'))}, around the edge of {f3(g('M01.blend_band_low'))} predicted for equal amplitudes. At β = 100, where only a few executions of unequal amplitude are blended, the edge blurred to between {f3(g('M05.soft_read_β__100_min_minor_mass_collided'))} and {f3(g('M05.soft_read_β__100_max_minor_mass_clear'))}. A hard top-1 read never collided, but it copied a stored execution (novelty {f2(mv('hard top-1 read', 'nearest_stored_over_spacing'))} of the spacing). Sharp reads were also lopsided: the few executions whose keys happened to lie closest to the cue won most queries, so only {pc(mv('hard top-1 read', 'left_share'), 1)} of hard reads passed on the left.

Choosing the mode first removed the dilemma. With two clusters and a soft read at β = 10 inside the chosen one, no read collided, the decoded trajectories lay on the manifold of valid motions ({f3(mv('mode first (K = 2), then soft within', 'off_manifold_rms'))} rad off it), and they were new, {f2(mv('mode first (K = 2), then soft within', 'nearest_stored_over_spacing'))} of the spacing from the nearest stored execution. Sampling the mode from its attention mass kept both ways in use ({pc(mv('sampled mode (K = 2), then soft within', 'left_share'), 1)} passed on the left). One caution concerns deterministic choice among unequal clusters. With eight clusters, the arg-max always picked the cluster with the most members, because a diffuse read gives each cluster mass in proportion to its size, and every read passed on the same side. Sampling restored the balance ({pc(mv('sampled mode (K = 8), then soft within', 'left_share'), 1)} left).

# 11 A Part 1 design, and what Part 2 must add

The results suggest a dense design for the hybrid.

1. **Word entries:** one training-free bound key per word, with letter slots for reranking and spelling, as in Step 1.
2. **Chunk entries:** one learned linear ISET vector per chunk of 8–16 steps at 50 Hz, with per-step slots, or a pointer to the raw characters, for exact addressing and replay. The record keeps the encoder version and the write-time error; chunks that fail the tolerance, mostly contact chunks, keep their raw characters.
3. **Scoring:** per-type normalized distance with a per-type temperature, and a log-count bias wherever body tokens outnumber words.
4. **Reading:** a pooled screen with a typed slot rerank; spelling and decoding only from a memory layer written by the encoders.
5. **Association:** role slots where memory allows, a bound tuple where it does not, sized by the crosstalk of Proposition 1; never a linear map alone, which keeps only the additive part.
6. **Acting:** choose a mode from the attention mass, by sampling when the clusters differ in size, read within it, decode, and let the fast loop correct the residual.

Three gaps remain that Part 2 must close. The dense cache stores every occurrence of a word as a full vector, so nothing is shared between related words beyond what the score rules recover. Explicit association needs one or three vectors per episode, so its memory grows with experience, and it has no inspectable inventory of associations. And the discrete choice that prevents mode averaging had to be added from outside, by clustering the stored codes. Word-Vocabucapillary supplies all three: sparse dictionaries share atoms between related words, association atoms bind mixed tuples into a counted inventory (Ghosh, 2026c), and choosing an atom is itself the discrete choice.

# 12 Limitations

The motions are synthetic. Each skill is a sum of four sinusoids per joint, so a rank of 56 captures a 16-step chunk almost exactly; real motion will have more dimensions, sharper contacts and correlated joints. The learned ISET is linear, and the word keys and character vectors are random rather than trained, so the studies measure what each code can represent, not what training would find. Queries are noisy copies of keys or fresh executions, not outputs of a trained network. Address noise is isotropic in the d dimensions of a key, so a code of lower rank meets only part of it; this favours the linear encoders in the address task, which the categorical codes still won. The tolerance of 0.04 rad equals one motor-character step. The deeper-layer model mixes in a plain average of earlier tokens. Association was tested with 256 actions and four executions each. No model was trained end to end, no robot was driven, and no latency was measured.

# 13 Conclusion

Words and action chunks can share one dense key–value cache, but only with a few deliberate choices. Chunking the body stream cuts the causal pairs of a minute of speech and motion from {p10(fl(chars_row['causal_pairs']))} to {p10(fl(w8['causal_pairs']))} and balances the softmax. One vector per chunk can be an address or a metric: categorical bound codes address exactly but cannot be decoded beyond a control step, and a learned linear ISET decodes and finds similar motions but blurs near-duplicate executions, so a chunk record needs a metric key and an exact handle. One softmax over two encoders needs per-type normalization and a distance score, or the encoder with the larger keys captures the queries. Decoding works only from keys the encoders wrote. A linear map cannot hold verb–object interactions, explicit role slots can, and a soft attention read averages valid modes unless a mode is chosen first. These are the properties that a word-Vocabucapillary Part 2 must preserve while it replaces dense word entries with sparse ones.

# Appendix A Proofs

**Proposition 1.** For codes $\\sum_j R_j a_j$ and $\\sum_{{j'}} R_{{j'}} b_{{j'}}$, the product expands into the aligned terms $a_j^{{\\top}} b_j$, since $R_j^{{\\top}} R_j = I$, and $S(S-1)$ cross terms $(R_j a_j)^{{\\top}} (R_{{j'}} b_{{j'}})$. Each cross term is a product of two independent isotropic unit vectors, with mean zero and variance 1/d, and the cross terms are uncorrelated. Unbinding slot i gives $a_i + \\sum_{{j \\ne i}} R_i^{{\\top}} R_j a_j$, whose noise has variance (S − 1)/d along any fixed unit vector. The correct symbol scores 1 plus noise of variance (S − 1)/d; a wrong symbol scores its overlap with the correct one, of variance 1/d, plus noise, in total S/d. Treating the A − 1 wrong scores as independent Gaussians gives Equation 8.

**Proposition 2.** Grouping the terms of the softmax denominator by type gives Equation 9. Repeating every token of type m n times multiplies $Z_m$ by n, and $e^{{-\\log n}} n = 1$.

**Proposition 3.** Under the dot-product rule, $\\beta\\, q^{{\\top}}(c k_t) = (c\\beta)\\, q^{{\\top}} k_t$. Dividing keys of type m by their root-mean-square norm cancels any factor c applied to them, and dividing each key by its own norm cancels it too. Completing the square gives the second form of Equation 5, in which the query term is common to all entries.

**Proposition 4.** A linear map is additive over the blocks of its input. In a two-way table, the additive part and the interaction part are orthogonal, so the additive part is the best additive approximation and the remaining error is the interaction.

**Proposition 5.** The read is linear in the weights, so two mirror modes give $(2\\pi_L - 1) A \\varphi(t)$, and the condition |y| < 0.3 on [5, 10] is Equation 10. A convex combination of members of a convex set lies in the set.

# Appendix B The immutable C# laboratory

The laboratory is a .NET 8 console project without external packages. Domain state lives in sealed records and read-only lists, every computation is a pure static function, and randomness comes from a SplitMix64 generator implemented as a readonly record struct whose draws return the value and the successor generator. It reuses the core of the Step 1 laboratory, including its MessagePack reader for the wordfreq English list (Speer, 2022; data under CC BY-SA 4.0), and adds a motor stream, four chunk encoders, a Jacobi eigen-solver for the learned linear ISET, ridge regression, k-means and BF16 rounding. One output boundary writes CSV tables and a JSON file of headline values.

A separate Python program decodes the word list with its own reader and recomputes the accounting, repeats the crosstalk Monte Carlo with numpy's generator, integrates Equation 8 with scipy, regenerates the motor chunks, the association prototypes and the obstacle trajectories with line-for-line ports of the generator, recomputes the principal-component and DCT reconstructions with numpy's SVD and scipy's DCT, and checks the invariance of the normalized rules; {py_agree} quantities agreed. Running `dotnet run -c Release` executes all six studies in about four minutes on two cores.

Table: Table 19. Studies of the laboratory.

| Study | Sections | Question | Kind of result |
|----------|----------|----------------------------------------------|--------------------|
| M00 | 5 | What do speech and a body stream cost per minute under each tokenization? | Accounting |
| M01 | 4 | Crosstalk and readout of bound codes; identities of a mixed softmax; the blend band | Exact and Monte Carlo |
| M02 | 6 | Can one vector per chunk address, find similar motions and decode? Rank, width, noise, staleness | Monte Carlo |
| M03 | 7, 8 | Encoder scale and score rules, dilution, long mixed histories, deeper layers | Monte Carlo and accounting |
| M04 | 9 | Planning and description with bound tuples, role slots and a linear map | Exact counts |
| M05 | 10 | Soft, hard and mode-first reads of a two-mode action | Monte Carlo |

# References

Black, K., et al. (2024). *π0: A vision-language-action flow model for general robot control* [Preprint]. arXiv:2410.24164.

Chameleon Team. (2024). *Chameleon: Mixed-modal early-fusion foundation models* [Preprint]. arXiv:2405.09818.

Chi, C., Feng, S., Du, Y., Xu, Z., Cousineau, E., Burchfiel, B., & Song, S. (2023). Diffusion policy: Visuomotor policy learning via action diffusion. *Robotics: Science and Systems*. arXiv:2303.04137.

Ghosh, D. P. (2024). *ISET: Invertible sequence embedding from Transformer* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.36457.67684

Ghosh, D. P. (2026a). *KV coefficient memory for Attentionlet* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.31586.70088

Ghosh, D. P. (2026b). *Vocabucapillary for cacheless transformer* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.36209.44648

Ghosh, D. P. (2026c). *Vocabucapillary memory for cooperative AI* (2nd ed.). Debias Parametric Guru.

Ghosh, D. P. (2026d). *Character vocabularies and ISET span memory: Spelling, order and linear-time reading in Vocabucapillary models* [Manuscript].

Ghosh, D. P. (2026e). *The cerebellum as a character-level ISET: Fine-resolution Vocabucapillary memory for physical AI* [Manuscript].

Ghosh, D. P. (2026f). *Words as sequences in self-attention: Slot-aligned, hierarchical and alignment scores over a dense word-level key–value cache* [Manuscript].

Henry, A., Dachapally, P. R., Pawar, S. S., & Chen, Y. (2020). Query-key normalization for transformers. *Findings of the Association for Computational Linguistics: EMNLP 2020*, 4246–4253. https://doi.org/10.18653/v1/2020.findings-emnlp.379

Kanerva, P. (2009). Hyperdimensional computing: An introduction to computing in distributed representation with high-dimensional random vectors. *Cognitive Computation, 1*(2), 139–159. https://doi.org/10.1007/s12559-009-9009-8

Kim, H., Papamakarios, G., & Mnih, A. (2021). The Lipschitz constant of self-attention. *Proceedings of the 38th International Conference on Machine Learning*, PMLR 139, 5562–5571.

Kohonen, T. (1972). Correlation matrix memories. *IEEE Transactions on Computers, C-21*(4), 353–359. https://doi.org/10.1109/TC.1972.5008975

Lee, S., Wang, Y., Etukuru, H., Kim, H. J., Shafiullah, N. M. M., & Pinto, L. (2024). Behavior generation with latent actions. *Proceedings of the 41st International Conference on Machine Learning*, PMLR 235, 26991–27008.

Pertsch, K., Stachowicz, K., Ichter, B., Driess, D., Nair, S., Vuong, Q., Mees, O., Finn, C., & Levine, S. (2025). *FAST: Efficient action tokenization for vision-language-action models* [Preprint]. arXiv:2501.09747.

Plate, T. A. (1995). Holographic reduced representations. *IEEE Transactions on Neural Networks, 6*(3), 623–641. https://doi.org/10.1109/72.377968

Reed, S., Zolna, K., Parisotto, E., et al. (2022). A generalist agent. *Transactions on Machine Learning Research*. arXiv:2205.06175.

Shafiullah, N. M. M., Cui, Z. J., Altanzaya, A., & Pinto, L. (2022). Behavior Transformers: Cloning k modes with one stone. *Advances in Neural Information Processing Systems, 35*. arXiv:2206.11251.

Smolensky, P. (1990). Tensor product variable binding and the representation of symbolic structures in connectionist systems. *Artificial Intelligence, 46*(1–2), 159–216. https://doi.org/10.1016/0004-3702(90)90007-M

Speer, R. (2022). *wordfreq: Access a database of word frequencies, in various natural languages* (Version 3.1.1) [Software and data]. https://github.com/rspeer/wordfreq

Zhao, T. Z., Kumar, V., Levine, S., & Finn, C. (2023). Learning fine-grained bimanual manipulation with low-cost hardware. *Robotics: Science and Systems*. arXiv:2304.13705.

Zitkovich, B., et al. (2023). RT-2: Vision-language-action models transfer web knowledge to robotic control. *Conference on Robot Learning*. arXiv:2307.15818.
"""
md = md.replace("FIG/", str(FIG) + "/")
(HERE / "paper.md").write_text(md, encoding="utf8")
subprocess.run(["pandoc", str(HERE / "paper.md"), "-o", str(HERE / "raw.docx"), "--reference-doc", str(HERE / "ref.docx")], check=True)
docxfix.repair(HERE / "raw.docx", HERE / "paper.docx")
(HERE / "raw.docx").unlink()
print("paper written:", len(md.split()), "words")
