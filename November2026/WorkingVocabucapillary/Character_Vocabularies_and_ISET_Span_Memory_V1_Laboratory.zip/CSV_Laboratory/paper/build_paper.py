"""Assembles the paper from the laboratory outputs (Markdown + LaTeX math), converts it with pandoc and repairs
pandoc's schema-order quirks so the Word file validates."""
import csv, json, re, subprocess, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT, FIG, HERE = ROOT / "out", ROOT / "figs", Path(__file__).resolve().parent
H = json.load(open(OUT / "headlines.json"))
def g(k): return H[k]
def rd(n): return list(csv.DictReader(open(OUT / f"{n}.csv")))
def m(s): return s.replace("-", "−")
def f2(x): return m(f"{x:.2f}")
def f3(x): return m(f"{x:.3f}")
def pc(x, d=0): return m(f"{100 * x:.{d}f}%")
def n0(x): return f"{x:,.0f}"
def sci(x): return m(f"{x:.1e}")

def md_table(header, rows, caption):
    lens = [max(min(len(str(h)), 14), 9, *(len(str(r[i])) for r in rows)) for i, h in enumerate(header)]
    out = [f"Table: {caption}", "", "| " + " | ".join(header) + " |", "|" + "|".join("-" * max(9, min(60, l)) for l in lens) + "|"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out) + "\n"

sc = rd("C00_scaling")
t_scale = md_table(["Notes", "Characters N", "Subwords", "Characters per subword", "Spans M", "Dense pairs, characters", "Dense pairs, subwords", "Span scan pairs", "NL + MK"],
    [[r["notes"], n0(float(r["characters_N"])), n0(float(r["subwords_T"])), f2(float(r["chars_per_subword"])), n0(float(r["spans_M"])),
      sci(float(r["dense_char_pairs"])), sci(float(r["dense_subword_pairs"])), sci(float(r["span_scan_pairs"])), sci(float(r["linear_total"]))] for r in sc],
    "Table 1. Work on maintenance logs of doubling length. NL + MK counts within-span pairs plus MK index candidates with K = 128 "
    "(four atom lists capped at 32 entries).")

sp = rd("C02_spelling")
t_spell = md_table(["Width", "Atoms per record", "Bits per record", "Exact, string types", "Exact, occurrences", "Tags exact", "Lexicon-assisted exact"],
    [[r["width"], r["atoms_s"], r["bits_per_record"], f3(float(r["exact_types"])),
      "–" if r["exact_occurrences"] == "NaN" else f3(float(r["exact_occurrences"])),
      "–" if r["tag_exact"] == "NaN" else f3(float(r["tag_exact"])), "–" if r["lexicon_assisted_exact"] == "NaN" else f3(float(r["lexicon_assisted_exact"]))] for r in sp],
    f"Table 2. Spelling recovered from a stored span record ({n0(g('C02.distinct_strings'))} distinct strings, {n0(g('C02.span_occurrences'))} "
    "occurrences). Records hold atom IDs (9 bits each), 8-bit coefficients and one 16-bit scale. The last row of each width decodes the "
    "unquantized, unsparsified code.")

sel = rd("C02_order_selectivity")
t_sel = md_table(["Code", "Cosine with transposed tag", "Cosine with another tag", "Order selectivity"],
    [[r["code"], f3(float(r["cos_with_transposition"])), f3(float(r["cos_with_other_tag"])), f3(float(r["order_selectivity_1_minus_cos"]))] for r in sel],
    "Table 3. Similarity of a tag such as B-17 to its transposition B-71 under three span codes of width 256, averaged over the 72 "
    "ordered digit pairs. Order selectivity is one minus the cosine with the transposition.")

gr = rd("C01_groups")
t_groups = md_table(["Notes", "Characters", "Character keys", "Bigram keys", "Span-string keys", "Span occurrences"],
    [[r["notes"], n0(float(r["characters"])), r["G_character_keys"], r["G_bigram_keys"], r["G_span_string_keys"], n0(float(r["spans"]))] for r in gr],
    "Table 4. Distinct key groups G as the log grows. Keys that also encode absolute position are all distinct (G = N).")

rr = rd("C03_readers")
readers = [("subword, dense attention", "Subwords, dense attention"), ("direct character, dense attention", "Characters, dense attention"),
           ("order span, 4 atoms, capped index", "Order code, 4 atoms, capped index"), ("order span, 16 atoms, capped index", "Order code, 16 atoms, capped index"),
           ("order span, 32 atoms, capped index", "Order code, 32 atoms, capped index"), ("order span, 16 atoms, full postings", "Order code, 16 atoms, full lists"),
           ("order span, 4 atoms + source pointer", "Order code, 4 atoms + source pointer"), ("bag span, 16 atoms, capped index", "Bag code, 16 atoms, capped index")]
def rv(n, rdname, col): return float(next(r[col] for r in rr if r["notes"] == str(n) and r["reader"] == rdname))
t_bear = md_table(["Reader", "Memory, bits per character", "Exact tag, 64 / 2,048 notes", "Transposed, 64 / 2,048", "Positions examined, 64 / 2,048"],
    [[lab, f"{rv(2048, k, 'memory_bits_per_char'):.1f}", f"{f2(rv(64, k, 'exact_tag'))} / {f2(rv(2048, k, 'exact_tag'))}",
      f"{f2(rv(64, k, 'transposed_tag'))} / {f2(rv(2048, k, 'transposed_tag'))}",
      f"{n0(rv(64, k, 'candidates_per_query'))} / {n0(rv(2048, k, 'candidates_per_query'))}"] for k, lab in readers],
    "Table 5. Which bearing failed? Forty logs per length. Subword and character readers are exact by construction; their "
    "examined positions are the positions one dense attention query reads. Subword memory counts 17-bit token IDs; character "
    "memory counts 21-bit code points; span memory counts the record, its offset and, for the pointer reader, the source text.")

c64 = lambda k, c: rv(64, k, c); c2k = lambda k, c: rv(2048, k, c)
O16, O32, O4P, BAG, O16F, O4 = ("order span, 16 atoms, capped index", "order span, 32 atoms, capped index", "order span, 4 atoms + source pointer",
                                "bag span, 16 atoms, capped index", "order span, 16 atoms, full postings", "order span, 4 atoms, capped index")
first, last = sc[0], sc[-1]
ratio_lin = float(last["linear_total"]) / float(first["linear_total"])
ratio_n = float(last["characters_N"]) / float(first["characters_N"])
ratio_scan = float(last["span_scan_pairs"]) / float(first["span_scan_pairs"])
py = list(csv.DictReader(open(OUT / "PY_crosscheck.csv")))
py_agree = f"{sum(r['agree'] == 'True' for r in py)} of {len(py)}"

md = f"""---
title: "Character Vocabularies and ISET Span Memory: Spelling, Order and Linear-Time Reading in Vocabucapillary Models"
author: "Debi Prasad Ghosh"
date: "November 2026"
abstract: |
  Subword vocabularies hide spelling, so a model can confuse bearing B-17 with B-71 or lose a part number split across tokens. Characters keep the spelling but lengthen the sequence: a passage of 4,096 subwords of four characters becomes 16,384 positions, about sixteen times the pairwise work of dense causal attention. This paper examines two remedies built on Vocabucapillary long-term memory. The first stores every Unicode code point directly, with a seed per character type and contextual coefficients per occurrence. The second closes character spans online, encodes each span with an invertible sequence embedding in the spirit of ISET, and stores a sparse mixture of seeded atoms with the original offsets. All numbers come from an immutable C# laboratory of four studies, with an independent Python check that agreed on {py_agree} quantities. Exact results come first. Within-span attention plus a capped atom index costs O(NL + MK), so its work grew {ratio_lin:.0f}-fold while the history grew {ratio_n:.0f}-fold, whereas scanning all earlier spans grew {ratio_scan:.0f}-fold. Grouped attention over G distinct keys reproduced the full softmax to {sci(g('C01.grouped_max_abs_gap'))} with {f2(g('C01.grouped_reads_per_query'))} reads per query instead of {n0(g('C01.full_reads_per_query'))}. The cost lies in spelling. Ten bits suffice to name each of the {n0(g('C02.distinct_strings'))} span strings, but a code that must spell its span unaided needed {n0(g('C02.w256_s32_bits'))} bits per record to spell {pc(g('C02.w256_s32_exact_types'), 1)} of them, while a 21-bit pointer to the stored text spells all of them. On the bearing test at 2,048 notes, an order-sensitive span reader with a source pointer returned the exact tag in every case while examining {n0(c2k(O4P, 'candidates_per_query'))} positions per query, against {n0(c2k('direct character, dense attention', 'candidates_per_query'))} for dense character attention. A bag-of-characters reader returned the transposed tag in {pc(c2k(BAG, 'transposed_tag'))} of cases. Order is cheap to keep and spelling is cheapest to keep as text.
---

# 1 Introduction

Tokenization fixes the units in which a language model reads and writes. Subword vocabularies of 30,000 to 256,000 entries compress text into fewer positions, but they hide spelling: a tag such as B-17 may become one token or three, and its transposition B-71 shares every character. Character and byte models restore spelling at the price of longer sequences (Clark et al., 2022; Xue et al., 2022; Tay et al., 2022), and recent work groups bytes into dynamic patches to recover the lost length (Yu et al., 2023; Pagnoni et al., 2024).

Vocabucapillary memory changes the balance. It stores each past occurrence as a sparse coefficient record over a shared atom dictionary instead of a dense key–value pair (Ghosh, 2026a, 2026b), and an Attentionlet read retrieves a few hundred records rather than attending to the whole history (Ghosh et al., 2025). If retrieval keeps attention linear in history length, characters become affordable, and the meaning that a single character lacks can be carried by the memory instead of the vocabulary.

This paper examines two designs. Direct character memory stores every Unicode code point, including punctuation and combining marks, with a seed per character type and contextual coefficients per occurrence. ISET span memory closes contiguous character spans online, encodes each span with an invertible sequence embedding following ISET (Ghosh, 2024), fits the embedding as a sparse mixture of atoms regenerated from shared seeds, and stores the mixture with its key code and original offsets in one occurrence record. If 256 selected spans average four characters, the final attention read covers 1,024 original character positions.

The paper asks four questions and answers each with exact identities, Monte Carlo estimates or accounting. What does a character vocabulary cost, and when does a span reader make the cost linear (Sections 2 and 6)? Can a stored span code spell its span, and how many bits does that take (Section 5)? When is attention over a long history exact at constant cost per query (Section 7)? And on an engineering test with near-duplicate inspection notes, which reader returns the exact failed bearing tag at what memory and work (Section 8)? Section 9 states the cortical prediction, Section 10 the revised design and Section 11 the limitations.

# 2 What characters cost

Suppose a passage takes 4,096 subwords averaging four characters each, so the same text needs 16,384 character positions. Dense causal attention over n positions forms n(n+1)/2 query–key pairs, so the character model does {f3(g('C00.example_dense_pair_ratio'))} times the pairwise work of the subword model at equal width. A reader with fixed work per position does {n0(g('C00.example_fixed_work_ratio'))} times the work, and generating the passage one character at a time takes {n0(g('C00.example_decode_step_ratio'))} times as many decoding steps. The decoding factor is not removed by any memory; it calls for predicting several characters per step, which Section 5 addresses through span prediction.

The test material of this paper is a synthetic maintenance log in four languages. Each note has a date, a line, a part, a bearing tag, a status, a cross-reference to another tag and a drawing number, for example "2026-03-14 línea 4 — bearing B-17 worn; cf. B-71, drawing D-412." Exactly one note in each log records the failed bearing, and other notes mention the same tag, its digit transposition and nearby tags. Because the text is dense with digits and punctuation, it averages only {f2(float(first['chars_per_subword']))} characters per subword under the tokenizer of Appendix B, against about four for English prose; Table 1 therefore understates the character penalty for ordinary text.

{t_scale}
![Figure 1. Pairwise or candidate work against history length. Dense attention grows quadratically; the span reader with a capped index grows linearly.](FIG/fig1_work.png){{width=5.4in}}

# 3 Direct character memory

Direct character memory keeps the original Unicode code points. Each character type c receives a seed from which its vector e(c) is regenerated, and each occurrence receives its position and contextual coefficients in the Vocabucapillary record. A single digit identifies little about a bearing, and B-17 and B-71 contain the same characters. A reader that ignores order cannot separate them; a reader that composes characters in order can, and the surrounding inspection note then identifies which bearing a drawing shows.

Table 3 measures how much order a span code keeps. A bag of character vectors gives B-17 and B-71 identical codes. One local composition step that binds each character to its successor reduces their cosine to {f3(g('C02.selectivity_adjacent_transposed_cos'))}, and a full position code, in which the j-th character is permuted j times before summation (Plate, 1995; Kanerva, 2009), reduces it to {f3(g('C02.selectivity_full_transposed_cos'))}. Order selectivity therefore grows with successive local steps, which is the property Section 9 tests in cortex.

{t_sel}
# 4 ISET over character spans

ISET encodes a sentence of word vectors into one vector and trains a decoder to recover the ordered input (Ghosh, 2024). Here the sequence is a contiguous span of code points. A span closes when a delimiter arrives (space, punctuation or a dash) or when it reaches eight characters, so a boundary depends only on characters already observed, and the unfinished prefix stays in local working memory until it closes.

A pretrained ISET encoder was not available in this workspace, so the laboratory uses an analytic invertible stand-in with the same interface. A span $s = (c_0, \\ldots, c_{{\\ell-1}})$ is encoded as

$$v(s) = \\sum_{{j=0}}^{{\\ell}} P^j e(c_j), \\qquad c_\\ell = \\mathrm{{EOS}}, \\quad\\quad\\quad (1)$$

where P is a fixed random permutation of the width-W coordinates and e(c) the seeded character vector. Each span vector is then fitted by orthogonal matching pursuit as a mixture of s atoms from a book of 512 seeded atoms, and the coefficients are quantized to 8 bits with one 16-bit scale. A new string needs no new atoms: it reuses the shared book. The occurrence record stores the value mixture, a contextual key code and the original character offsets.

# 5 Spelling and meaning

A record of b bits can distinguish at most $2^b$ strings on its own, so naming the {n0(g('C02.distinct_strings'))} distinct strings of a 1,024-note log needs only {n0(g('C02.min_bits_to_distinguish'))} bits. Spelling a string from its code alone is a different task, because the decoder must recover each character in order without a list of candidates. The laboratory decodes by successive unbinding: at position j it compares $P^{{-j}} \\hat v$ with every character vector, takes the best match, subtracts it and continues until it reads EOS.

{t_spell}
![Figure 2. Spans spelled exactly from the stored record, by bits per record. The dotted line marks the bits that name every string; the dashed line a pointer to the source text.](FIG/fig2_spelling.png){{width=5.8in}}

Table 2 separates three forms of recovery, as the brief requires. Code-only spelling at width 256 needs {n0(g('C02.w256_s32_bits'))} bits per record to spell {pc(g('C02.w256_s32_exact_types'), 1)} of string types and {n0(g('C02.w256_s64_bits'))} bits to spell all of them; at {n0(g('C02.w256_s16_bits'))} bits it spells {pc(g('C02.w256_s16_exact_types'))}. Width 64 cannot spell reliably even from the exact code ({pc(g('C02.w64_exact_code_decoder'))}), because eight positions crowd one another in 64 coordinates. Lexicon-assisted recovery, which picks the nearest stored string, reaches {pc(g('C02.w256_s8_lexicon'))} at {n0(g('C02.w256_s8_bits'))} bits but must count the lexicon itself. Pointer-assisted recovery stores {n0(g('C02.pointer_bits'))} bits of offset and length and reads the source text, which is exact whenever the text is kept.

Meaning and spelling therefore call for different stores. The value mixture should carry what the span means in context, which a few atoms can hold, and exact spelling should come from the source text through the offsets. The brief's coupled training, in which an inverse decoder is trained on the stored, quantized value mixture and the next span's decoded characters are scored, remains the right objective for the meaning code; the measurements here show that it should not be asked to carry exact spelling unaided.

# 6 Linear attention over retrieved spans

**Proposition 1.** Let N characters form M nonoverlapping spans of at most L characters. Dense attention within each span costs at most NL pairs. If a bounded-time index returns at most K candidates per span, for example by reading lists capped at C entries for a fixed number a of atom IDs (K = aC), and index updates are bounded, the total attention and lookup work is O(NL + MK), linear in N for fixed L and K. Comparing every span with every earlier span, even at 64 coordinates, costs Θ(M²).

Table 1 and Figure 1 confirm the scaling on logs from 128 to 4,096 notes. The linear total grew {ratio_lin:.1f}-fold while N grew {ratio_n:.1f}-fold, and the span scan grew {ratio_scan:.0f}-fold. At 4,096 notes, dense character attention would form {sci(float(last['dense_char_pairs']))} pairs and the span reader {sci(float(last['linear_total']))}.

The bound has a price that Section 8 measures: a capped list forgets old entries. When many spans share an atom, the oldest occurrences fall out of its list, and a query can no longer reach them through that atom.

# 7 Exact attention for shared keys

**Proposition 2.** In causal dot-product attention, suppose every past occurrence uses one of G distinct keys $k_g$. Keep for each key its occurrence count $n_g$ and the sum $S_g$ of its value vectors. Then for any query q,

$$\\sum_i \\frac{{e^{{q \\cdot k_i}}}}{{\\sum_j e^{{q \\cdot k_j}}}} \\, v_i = \\frac{{\\sum_g e^{{q \\cdot k_g}} S_g}}{{\\sum_g n_g \\, e^{{q \\cdot k_g}}}}, \\quad\\quad\\quad (2)$$

which reads G groups instead of the whole history. The proof groups equal terms (Appendix A).

Study C01 checked Equation 2 on a log of {n0(g('C01.full_reads_per_query'))} characters with keys determined by the character type. The grouped read matched the full softmax to {sci(g('C01.grouped_max_abs_gap'))} while reading {f2(g('C01.grouped_reads_per_query'))} groups per query on average. Table 4 shows when the saving survives. Keys fixed by the character type give G = {g('C01.alphabet_size'):.0f} for the whole log, and keys fixed by the previous and current character saturate near 250. Keys fixed by the span string keep growing slowly, to {n0(g('C01.notes2048_G_span'))} at 2,048 notes, against {n0(g('C01.notes2048_spans'))} occurrences. Keys that encode absolute position, as rotary position embeddings do, are all distinct, so the identity saves nothing. Grouping also discards which occurrence contributed, so retrieving a source span still requires occurrence addresses.

{t_groups}
![Figure 3. Distinct key groups as the log grows, by key scheme.](FIG/fig4_groups.png){{width=5.2in}}

# 8 Which bearing failed?

Study C03 gives every reader the same log and asks which bearing failed, requiring the exact tag. Span readers retrieve the record most similar to the span "failed" through a capped atom index (four atoms per record, lists capped at 32 entries) or through full lists, then read the tag record that precedes it in the same note. Order-code readers spell the tag from its code, the pointer reader reads the stored source text, and the bag reader returns the stored string whose bag code is closest. Subword and character readers with dense attention are exact by construction; for them the table reports the positions one query reads.

{t_bear}
![Figure 4. Left: exact and transposed answers at 2,048 notes. Right: positions examined per query as the log doubles.](FIG/fig3_bearing.png){{width=6.3in}}

Four results stand out. First, order prevents transpositions: no order-code reader with full lists returned a transposed tag, while the bag reader did so in {pc(c64(BAG, 'transposed_tag'))} of logs at 64 notes and {pc(c2k(BAG, 'transposed_tag'))} at 2,048. Second, code-only spelling limits accuracy: with 16 atoms ({c2k(O16, 'memory_bits_per_char'):.0f} bits per character) the reader spelled the right tag in {pc(c2k(O16, 'exact_tag'))} of logs at 2,048 notes, and with four atoms, the budget closest to raw code points, it never did. Third, the capped index bounds the work, at {n0(c2k(O16, 'candidates_per_query'))} positions per query at 2,048 notes against {n0(c2k(O16F, 'candidates_per_query'))} for full lists and {n0(c2k('direct character, dense attention', 'candidates_per_query'))} for dense character attention, but it can forget: with 32 atoms the failed record was retrieved in only {pc(c2k(O32, 'failed_record_retrieved'))} of logs at 2,048 notes, and every miss returned a near-duplicate note whose tag was the transposition. Fourth, the pointer reader was exact at every length while examining {n0(c2k(O4P, 'candidates_per_query'))} positions, at {c2k(O4P, 'memory_bits_per_char'):.0f} bits per character: retrieval by a short code and spelling from the source text.

Timing is reported in the laboratory outputs but is not used for conclusions, because it varied with just-in-time compilation and cache state between runs.

# 9 A cortical prediction

Human imaging found increasing selectivity for word-like letter strings along the left ventral occipitotemporal reading pathway (Vinckier et al., 2007), consistent with a hierarchy of local combination detectors for letters, bigrams and larger units (Dehaene et al., 2005). Readers also tolerate many letter transpositions (Grainger & Whitney, 2004), so order coding in reading is graded rather than absolute. Table 3 gives the corresponding engineering curve: transposition similarity fell from {f3(g('C02.selectivity_characters_transposed_cos'))} for a character bag to {f3(g('C02.selectivity_adjacent_transposed_cos'))} after one local step and {f3(g('C02.selectivity_full_transposed_cos'))} for a full position code.

The prediction is that transposition sensitivity should rise along the pathway in the same ordered way. Representational similarity between a string and its transposition, such as B-17 and B-71, should be near one in early visual areas, lower in intermediate areas and lowest in the most anterior word-selective region, with tag strings matched for letter content. A flat profile would count against a hierarchy of local recurrent composition.

# 10 Revised design

1. **Store characters, retrieve spans.** Keep every code point in the source store and close spans online; index span records, not characters.
2. **Separate meaning from spelling.** Let the value mixture carry contextual meaning with a few atoms, and recover exact spelling through the stored offsets. Code-only spelling needs roughly 560 bits per record at width 256 in this test, more than a pointer and the text together.
3. **Use order-sensitive codes for keys.** Position binding removes the transpositions that a bag code makes.
4. **Bound the index, but protect rare evidence.** Capped lists make work linear but forget; give rarely used atoms (such as those of "failed") longer lists, or keep a small uncapped list for spans marked consequential.
5. **Group keys where they repeat.** Character-type and bigram keys give exact attention at constant cost per query; position-adjusted keys do not.
6. **Predict spans, not single characters.** Decoding character by character takes four times as many steps; predicting the next span and scoring its decoded characters, as ISET's coupled training suggests, could remove much of that factor. This was not tested here.

# 11 Limitations

The span encoder is an analytic stand-in for ISET, not a trained ISET model, so spelling capacity may differ for learned encoders, which can exploit the statistics of real strings. The log is synthetic and digit-heavy, and the readers are deliberately simple: one retrieval step, no learned query and a fixed decision rule. Subword and character readers were credited with exact answers rather than trained, so the test measures memory and work, not the accuracy of trained dense models. Timing depends on implementation and is not used for conclusions. The cortical prediction is stated but not tested.

# 12 Conclusion

Character vocabularies are affordable when long-term memory keeps attention linear: within-span attention with a capped index costs O(NL + MK), and grouped keys give exact attention at constant cost when keys repeat. Order-sensitive span codes remove the transposition errors that bags of characters make. Exact spelling is the expensive part. A span code that must spell unaided needs hundreds of bits per record, whereas a pointer to the stored text costs 21 bits and is always right. The resulting design retrieves by meaning and spells from the source: the B-17 that failed is found by its note and read from the text.

# Appendix A Proofs

**Proposition 1.** Each character attends to at most L characters of its own span, so within-span work is at most NL. Each span performs one index lookup that returns at most K candidates, and its own insertion touches a fixed number of capped lists, so lookup work is at most MK plus O(M) updates. Since M ≤ N, the total is O(NL + MK). Comparing each span with all earlier spans performs M(M − 1)/2 comparisons.

**Proposition 2.** Group the history by key: $\\sum_i e^{{q \\cdot k_i}} v_i = \\sum_g e^{{q \\cdot k_g}} \\sum_{{i: k_i = k_g}} v_i = \\sum_g e^{{q \\cdot k_g}} S_g$, and $\\sum_j e^{{q \\cdot k_j}} = \\sum_g n_g e^{{q \\cdot k_g}}$. Dividing gives Equation 2. Updating n_g and S_g for a new occurrence costs one addition at fixed width.

**Counting.** A deterministic decoder maps each b-bit record to one string, so at most $2^b$ strings can be recovered from records alone.

# Appendix B The immutable C# laboratory

The laboratory is a .NET 8 console project without external packages. Domain state is held in sealed records and read-only lists, and every computation is a pure static function; the SplitMix64 generator is a readonly record struct whose draws return the value and the successor generator. Parallel evaluation over strings and logs is safe because no state is shared. One output boundary writes CSV tables and a JSON file of headline values.

Table: Table 6. Studies of the laboratory.

| Study | Sections | Question | Kind of result |
|-----|-----------|----------------------------------------------|--------------------|
| C00 | 2, 6 | What do characters, subwords and span readers cost as the history doubles? | Accounting |
| C01 | 7 | Is grouped attention exact, and how fast does G grow? | Exact and accounting |
| C02 | 3, 5 | How many bits must a span record carry to spell its span? | Exact and Monte Carlo |
| C03 | 8 | Which bearing failed, under four reader designs? | Monte Carlo |

The subword tokenizer used for accounting keeps letter runs of up to eight characters whole, splits longer runs into chunks of four, groups digits in pairs and counts every other non-space symbol separately. Running `dotnet run -c Release` executes all studies in about two and a half minutes on two cores. The Python cross-check ports the generator, the log generator, the segmenter, the tokenizer and the position code with its decoder, and recomputes grouped attention with numpy; all {py_agree} quantities agreed.

# References

Clark, J. H., Garrette, D., Turc, I., & Wieting, J. (2022). CANINE: Pre-training an efficient tokenization-free encoder for language representation. *Transactions of the Association for Computational Linguistics, 10*, 73–91. https://doi.org/10.1162/tacl_a_00448

Dehaene, S., Cohen, L., Sigman, M., & Vinckier, F. (2005). The neural code for written words: A proposal. *Trends in Cognitive Sciences, 9*(7), 335–341. https://doi.org/10.1016/j.tics.2005.05.004

Ghosh, D. P. (2024). *ISET: Invertible sequence embedding from Transformer* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.36457.67684

Ghosh, D., Ghosh, D., & Ghosh, D. P. (2025). *Attentionlet is all you need!* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.35155.90404

Ghosh, D. P. (2026a). *KV coefficient memory for Attentionlet* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.31586.70088

Ghosh, D. P. (2026b). *Vocabucapillary for cacheless transformer* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.36209.44648

Grainger, J., & Whitney, C. (2004). Does the huamn mnid raed wrods as a wlohe? *Trends in Cognitive Sciences, 8*(2), 58–59. https://doi.org/10.1016/j.tics.2003.11.006

Kanerva, P. (2009). Hyperdimensional computing: An introduction to computing in distributed representation with high-dimensional random vectors. *Cognitive Computation, 1*(2), 139–159. https://doi.org/10.1007/s12559-009-9009-8

Pagnoni, A., et al. (2024). *Byte latent transformer: Patches scale better than tokens* [Preprint]. arXiv:2412.09871.

Plate, T. A. (1995). Holographic reduced representations. *IEEE Transactions on Neural Networks, 6*(3), 623–641. https://doi.org/10.1109/72.377968

Tay, Y., Tran, V. Q., Ruder, S., Gupta, J., Chung, H. W., Bahri, D., Qin, Z., Baumgartner, S., Yu, C., & Metzler, D. (2022). Charformer: Fast character transformers via gradient-based subword tokenization. *International Conference on Learning Representations*. arXiv:2106.12672.

Vinckier, F., Dehaene, S., Jobert, A., Dubus, J. P., Sigman, M., & Cohen, L. (2007). Hierarchical coding of letter strings in the ventral stream: Dissecting the inner organization of the visual word-form system. *Neuron, 55*(1), 143–156. https://doi.org/10.1016/j.neuron.2007.05.031

Xue, L., Barua, A., Constant, N., Al-Rfou, R., Narang, S., Kale, M., Roberts, A., & Raffel, C. (2022). ByT5: Towards a token-free future with pre-trained byte-to-byte models. *Transactions of the Association for Computational Linguistics, 10*, 291–306. https://doi.org/10.1162/tacl_a_00461

Yu, L., Simig, D., Flaherty, C., Aghajanyan, A., Zettlemoyer, L., & Lewis, M. (2023). MEGABYTE: Predicting million-byte sequences with multiscale transformers. *Advances in Neural Information Processing Systems, 36*. arXiv:2305.07185.
"""
md = md.replace("FIG/", str(FIG) + "/")
(HERE / "paper.md").write_text(md, encoding="utf8")
subprocess.run(["pandoc", str(HERE / "paper.md"), "-o", str(HERE / "raw.docx"), "--reference-doc", str(HERE / "ref.docx")], check=True)

# Repair pandoc's element-order quirks so the file validates against the OOXML schema.
SETTINGS = ("writeProtection view zoom removePersonalInformation removeDateAndTime doNotDisplayPageBoundaries displayBackgroundShape "
 "printPostScriptOverText printFractionalCharacterWidth printFormsData embedTrueTypeFonts embedSystemFonts saveSubsetFonts saveFormsData "
 "mirrorMargins alignBordersAndEdges bordersDoNotSurroundHeader bordersDoNotSurroundFooter gutterAtTop hideSpellingErrors hideGrammaticalErrors "
 "activeWritingStyle proofState formsDesign attachedTemplate linkStyles stylePaneFormatFilter stylePaneSortMethod documentType mailMerge "
 "revisionView trackRevisions doNotTrackMoves doNotTrackFormatting documentProtection autoFormatOverride styleLockTheme styleLockQFSet "
 "defaultTabStop autoHyphenation consecutiveHyphenLimit hyphenationZone doNotHyphenateCaps showEnvelope summaryLength clickAndTypeStyle "
 "defaultTableStyle evenAndOddHeaders bookFoldRevPrinting bookFoldPrinting bookFoldPrintingSheets drawingGridHorizontalSpacing "
 "drawingGridVerticalSpacing displayHorizontalDrawingGridEvery displayVerticalDrawingGridEvery doNotUseMarginsForDrawingGridOrigin "
 "drawingGridHorizontalOrigin drawingGridVerticalOrigin doNotShadeFormData noPunctuationKerning characterSpacingControl printTwoOnOne "
 "strictFirstAndLastChars noLineBreaksAfter noLineBreaksBefore savePreviewPicture doNotValidateAgainstSchema saveInvalidXml ignoreMixedContent "
 "alwaysShowPlaceholderText doNotDemarcateInvalidXml saveXmlDataOnly useXSLTWhenSaving saveThroughXslt showXMLTags alwaysMergeEmptyNamespace "
 "updateFields hdrShapeDefaults footnotePr endnotePr compat docVars rsids mathPr attachedSchema themeFontLang clrSchemeMapping "
 "doNotIncludeSubdocsInStats doNotAutoCompressPictures forceUpgrade captions readModeInkLockDown smartTagType schemaLibrary shapeDefaults "
 "doNotEmbedSmartTags decimalSymbol listSeparator").split()

def top_children(body):
    kids, pos = [], 0
    pat = re.compile(r"<(w|m|sl|o|v|w10):([A-Za-z]+)\b[^>]*?(/>|>)")
    while True:
        mt = pat.search(body, pos)
        if not mt: return kids
        pre, name, end = mt.groups()
        if end == "/>": e = mt.end()
        else:
            close, depth, k = f"</{pre}:{name}>", 1, mt.end()
            while depth:
                o = re.compile(rf"<{pre}:{name}\b[^>]*?(/?)>|{re.escape(close)}").search(body, k)
                depth += -1 if o.group(0) == close else (0 if o.group(1) == "/" else 1); k = o.end()
            e = k
        kids.append((name, body[mt.start():e])); pos = e

src = zipfile.ZipFile(HERE / "raw.docx")
out = zipfile.ZipFile(HERE / "paper.docx", "w", zipfile.ZIP_DEFLATED)
for info in src.infolist():
    data = src.read(info.filename); n = info.filename
    if n.endswith("/"): continue
    t = None
    if n == "[Content_Types].xml":
        t = data.decode()
        if 'Extension="png"' not in t: t = t.replace("<Default ", '<Default Extension="png" ContentType="image/png" /><Default ', 1)
    elif n == "word/document.xml":
        t = data.decode()
        t = re.sub(r"(<m:begChr [^>]*/>)(<m:endChr [^>]*/>)(<m:sepChr [^>]*/>)", r"\1\3\2", t)
        t = re.sub(r'(<w:tblLook [^>]*/>)<w:jc w:val="start" />', r'<w:jc w:val="left" />\1', t)
        t = re.sub(r"<w:pPr>(<w:numPr>.*?</w:numPr>)(<w:pStyle [^>]*/>)", r"<w:pPr>\2\1", t)
    elif n == "word/numbering.xml":
        t = re.sub(r'w:nsid w:val="([0-9A-F]+)"', lambda mm: f'w:nsid w:val="{mm.group(1).zfill(8)[-8:]}"', data.decode())
    elif n == "word/styles.xml":
        t = data.decode().replace("/>&gt;", "/>")
        t = re.sub(r"(<w:vAlign [^>]*/>)(\s*)(<w:tcBorders>.*?</w:tcBorders>)", r"\3\2\1", t, flags=re.S)
        t = re.sub(r"(<w:pPr>\s*<w:spacing [^>]*/>\s*</w:pPr>)(\s*)(<w:qFormat />)", r"\3\2\1", t)
        t = re.sub(r'(<w:jc w:val="center" />)(\s*)(<w:spacing [^>]*/>)', r"\3\2\1", t)
    elif n == "word/settings.xml":
        t = data.decode()
        hm = re.match(r"(.*?<w:settings [^>]*>)(.*)(</w:settings>)\s*$", t, re.S)
        kids = sorted(top_children(hm.group(2)), key=lambda x: SETTINGS.index(x[0]) if x[0] in SETTINGS else 999)
        t = hm.group(1) + "".join(k for _, k in kids) + hm.group(3)
    out.writestr(info, t.encode() if t is not None else data)
out.close()
(HERE / "raw.docx").unlink()
print("paper written:", len(md.split()), "words")
