using CsLab.Core;

namespace CsLab.Experiments;

/// <summary>Exact work counts: subwords against characters, and span readers against dense and scanning readers.</summary>
public static class C00_Accounting
{
    private const ulong Seed = 4096;
    public const int Cap = 32, QueryAtoms = 4;

    /// <summary>A deterministic subword tokenizer for the log: words of up to 8 letters whole, longer ones in chunks
    /// of 4, digit runs in groups of up to 2, every other non-space symbol alone.</summary>
    public static int SubwordCount(IReadOnlyList<int> cps)
    {
        int count = 0, i = 0;
        while (i < cps.Count)
        {
            int c = cps[i];
            if (c == ' ') { i++; continue; }
            if (char.IsLetter(char.ConvertFromUtf32(c), 0))
            {
                int j = i; while (j < cps.Count && char.IsLetter(char.ConvertFromUtf32(cps[j]), 0)) j++;
                int len = j - i; count += len <= 8 ? 1 : (len + 3) / 4; i = j;
            }
            else if (c is >= '0' and <= '9')
            {
                int j = i; while (j < cps.Count && cps[j] is >= '0' and <= '9') j++;
                count += (j - i + 1) / 2; i = j;
            }
            else { count++; i++; }
        }
        return count;
    }

    public static ExperimentResult Run()
    {
        var h = new Dictionary<string, double>();
        // The brief's example: 4,096 subwords of four characters each.
        long T = 4096, N = 16384;
        double densePairs(long n) => n * (n + 1) / 2.0;
        h["example_dense_pair_ratio"] = densePairs(N) / densePairs(T);
        h["example_fixed_work_ratio"] = N / (double)T;
        h["example_decode_step_ratio"] = N / (double)T;
        h["example_spans_256x4_chars"] = 256 * 4;

        var rows = new List<object[]>();
        foreach (int notes in new[] { 128, 256, 512, 1024, 2048, 4096 })
        {
            var log = LogText.Generate(notes, Rng.Derive(Seed, (ulong)notes));
            long n = log.CodePoints.Count, m = log.Spans.Count, t = SubwordCount(log.CodePoints);
            double meanL = log.Spans.Average(s => s.Length);
            int maxL = log.Spans.Max(s => s.Length);
            double within = log.Spans.Sum(s => s.Length * (s.Length + 1) / 2.0);
            double index = m * (double)(Cap * QueryAtoms);
            double scan = m * (m - 1) / 2.0;
            rows.Add(new object[] { notes, n, t, n / (double)t, m, meanL, maxL, densePairs(n), densePairs(t), within, index, within + index, scan });
            h[$"notes{notes}_chars"] = n;
            h[$"notes{notes}_chars_per_subword"] = n / (double)t;
            h[$"notes{notes}_span_plus_index_work"] = within + index;
            h[$"notes{notes}_scan_pairs"] = scan;
            h[$"notes{notes}_dense_char_pairs"] = densePairs(n);
        }
        var table = Table.Of("scaling", new[]
        {
            "notes", "characters_N", "subwords_T", "chars_per_subword", "spans_M", "mean_span_len", "max_span_len",
            "dense_char_pairs", "dense_subword_pairs", "within_span_pairs", "index_candidates_MK", "linear_total", "span_scan_pairs",
        }, rows);
        return new ExperimentResult("C00", "Work accounting for characters, subwords and spans", new[] { table }, h);
    }
}
