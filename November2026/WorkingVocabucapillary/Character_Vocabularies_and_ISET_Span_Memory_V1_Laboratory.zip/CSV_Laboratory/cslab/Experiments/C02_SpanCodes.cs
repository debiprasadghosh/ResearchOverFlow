using CsLab.Core;

namespace CsLab.Experiments;

/// <summary>
/// How many bits must a stored span mixture carry to spell its span from the code alone? Sparse mixtures of seeded
/// atoms fitted to order-sensitive span vectors are quantized and decoded; lexicon and pointer recovery are counted apart.
/// </summary>
public static class C02_SpanCodes
{
    private const ulong Seed = 9157;
    public const int Atoms = 512, CoefBits = 8;

    public static ExperimentResult Run()
    {
        var log = LogText.Generate(1024, Rng.Derive(Seed, 1));
        var strings = log.Spans.Select(s => s.Text).Distinct().OrderBy(s => s, StringComparer.Ordinal).ToArray();
        var cpsOf = strings.ToDictionary(s => s, s => LogText.ToCodePoints(s));
        var freq = log.Spans.GroupBy(s => s.Text).ToDictionary(g => g.Key, g => g.Count());
        var alphabet = log.Spans.SelectMany(s => LogText.ToCodePoints(s.Text)).Distinct().OrderBy(c => c).ToArray();
        var h = new Dictionary<string, double>
        {
            ["distinct_strings"] = strings.Length,
            ["min_bits_to_distinguish"] = Math.Ceiling(Math.Log2(strings.Length)),
            ["alphabet"] = alphabet.Length,
            ["span_occurrences"] = log.Spans.Count,
            ["pointer_bits"] = Math.Ceiling(Math.Log2(log.CodePoints.Count)) + Math.Ceiling(Math.Log2(LogText.MaxSpan + 1)),
        };
        var tags = strings.Where(s => s.Length == 4 && s.StartsWith("B-")).ToArray();
        var rows = new List<object[]>();
        foreach (int width in new[] { 64, 256 })
        {
            var coder = SpanCoder.Create(width, Seed);
            var table = alphabet.Append(SpanCoder.Eos).ToDictionary(c => c, c => coder.Char(c));
            var book = AtomBook.Create(width, Atoms, Seed + (ulong)width);
            var exact = strings.ToDictionary(s => s, s => coder.Order(cpsOf[s]));
            foreach (int s in new[] { 4, 8, 16, 32, 64 }.Where(k => k <= width / 4))
            {
                var results = strings.AsParallel().AsOrdered().Select(str =>
                {
                    var code = book.Fit(exact[str], s, CoefBits);
                    var rec = book.Reconstruct(code);
                    var dec = LogText.FromCodePoints(coder.Decode(rec, alphabet, table));
                    // Lexicon-assisted: nearest stored exact code by cosine.
                    string lex = strings.OrderByDescending(o => Lin.Dot(rec, exact[o]) / Math.Sqrt(Lin.Norm2(exact[o]))).First();
                    return (str, dec, lex, bits: code.Bits(book.AtomBits, CoefBits));
                }).ToArray();
                double wExact = results.Sum(x => freq[x.str] * (x.dec == x.str ? 1.0 : 0)) / log.Spans.Count;
                double typeExact = results.Average(x => x.dec == x.str ? 1.0 : 0);
                double charAcc = results.Average(x => CharAcc(x.str, x.dec));
                double lexAcc = results.Average(x => x.lex == x.str ? 1.0 : 0);
                var tagRes = results.Where(x => tags.Contains(x.str)).ToArray();
                double tagExact = tagRes.Average(x => x.dec == x.str ? 1.0 : 0);
                double tagTransposed = tagRes.Average(x => x.dec.Length == 4 && x.dec != x.str && x.dec[..2] == "B-" && x.dec[2] == x.str[3] && x.dec[3] == x.str[2] ? 1.0 : 0);
                int bits = results[0].bits;
                rows.Add(new object[] { width, s, bits, typeExact, wExact, charAcc, tagExact, tagTransposed, lexAcc });
                h[$"w{width}_s{s}_bits"] = bits;
                h[$"w{width}_s{s}_exact_types"] = typeExact;
                h[$"w{width}_s{s}_exact_occurrences"] = wExact;
                h[$"w{width}_s{s}_tag_exact"] = tagExact;
                h[$"w{width}_s{s}_lexicon"] = lexAcc;
            }
            // Unquantized, unsparsified code (the ceiling of the decoder itself).
            double full = strings.AsParallel().Average(str => LogText.FromCodePoints(coder.Decode(exact[str], alphabet, table)) == str ? 1.0 : 0);
            h[$"w{width}_exact_code_decoder"] = full;
            rows.Add(new object[] { width, "exact float code", width * 32, full, double.NaN, double.NaN, double.NaN, double.NaN, double.NaN });
        }
        var spelling = Table.Of("spelling", new[] { "width", "atoms_s", "bits_per_record", "exact_types", "exact_occurrences", "char_accuracy", "tag_exact", "tag_transposed", "lexicon_assisted_exact" }, rows);

        // Order selectivity after successive local composition steps.
        var c256 = SpanCoder.Create(256, Seed);
        double Cos(IReadOnlyList<double> a, IReadOnlyList<double> b) => Lin.Dot(a, b) / Math.Sqrt(Lin.Norm2(a) * Lin.Norm2(b));
        var pairs = Enumerable.Range(1, 9).SelectMany(a => Enumerable.Range(1, 9).Where(b => b != a).Select(b => ($"B-{a}{b}", $"B-{b}{a}"))).ToArray();
        var rnd = Rng.Derive(Seed, 3);
        var sel = new List<object[]>();
        foreach (var (name, f) in new (string, Func<IReadOnlyList<int>, IReadOnlyList<double>>)[]
                 { ("characters only (bag)", c256.Bag), ("adjacent pairs (one local step)", c256.Bigram), ("full position code", c256.Order) })
        {
            double trans = pairs.Average(p => Cos(f(LogText.ToCodePoints(p.Item1)), f(LogText.ToCodePoints(p.Item2))));
            double unrelated = pairs.Average(p => Cos(f(LogText.ToCodePoints(p.Item1)), f(LogText.ToCodePoints($"D-{p.Item1[3]}{p.Item1[2]}0"))));
            double self = 1.0;
            sel.Add(new object[] { name, trans, unrelated, self - trans });
            h[$"selectivity_{name.Split(' ')[0]}_transposed_cos"] = trans;
        }
        var selTable = Table.Of("order_selectivity", new[] { "code", "cos_with_transposition", "cos_with_other_tag", "order_selectivity_1_minus_cos" }, sel);
        return new ExperimentResult("C02", "Spelling from stored span codes", new[] { spelling, selTable }, h);
    }

    private static double CharAcc(string a, string b)
    {
        var x = LogText.ToCodePoints(a); var y = LogText.ToCodePoints(b);
        int n = Math.Max(x.Count, y.Count);
        if (n == 0) return 1;
        int same = 0;
        for (int i = 0; i < Math.Min(x.Count, y.Count); i++) if (x[i] == y[i]) same++;
        return same / (double)n;
    }
}
