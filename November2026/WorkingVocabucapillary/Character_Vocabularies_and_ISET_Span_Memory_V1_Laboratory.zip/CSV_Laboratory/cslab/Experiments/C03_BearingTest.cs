using System.Collections.Concurrent;
using System.Diagnostics;
using CsLab.Core;

namespace CsLab.Experiments;

/// <summary>
/// The engineering test of the brief: among near-duplicate inspection notes, which bearing failed? Readers must return
/// the exact tag. Subword, direct-character, order-sensitive span and bag-of-characters span readers are compared on the
/// same logs, with candidate counts and time per 1,000 original characters as the history doubles.
/// </summary>
public static class C03_BearingTest
{
    private const ulong Seed = 3141;
    public const int Width = 256, AtomCount = 512, CoefBits = 8, IndexAtoms = 4, Cap = 32, Trials = 40;

    public sealed record Reader(string Name, bool Order, int Sparsity, bool Capped, bool Pointer = false);
    public sealed record Answer(string Tag, long Candidates, double Bits, bool Retrieved);

    public static ExperimentResult Run()
    {
        var coder = SpanCoder.Create(Width, Seed);
        var book = AtomBook.Create(Width, AtomCount, Seed + 1);
        var cache = new ConcurrentDictionary<(string, bool, int), SparseCode>();
        SparseCode Code(string s, bool order, int k) => cache.GetOrAdd((s, order, k), key =>
        {
            var cps = LogText.ToCodePoints(key.Item1);
            return book.Fit(key.Item2 ? coder.Order(cps) : coder.Bag(cps), key.Item3, CoefBits);
        });
        var readers = new[]
        {
            new Reader("order span, 4 atoms, capped index", true, 4, true),
            new Reader("order span, 16 atoms, capped index", true, 16, true),
            new Reader("order span, 32 atoms, capped index", true, 32, true),
            new Reader("order span, 16 atoms, full postings", true, 16, false),
            new Reader("order span, 4 atoms + source pointer", true, 4, true, true),
            new Reader("bag span, 16 atoms, capped index", false, 16, true),
        };
        var rows = new List<object[]>();
        var h = new Dictionary<string, double>();
        foreach (int notes in new[] { 64, 128, 256, 512, 1024, 2048 })
        {
            var logs = Enumerable.Range(0, Trials).Select(t => LogText.Generate(notes, Rng.Derive(Seed, (ulong)(notes * 100 + t)))).ToArray();
            double chars = logs.Average(l => l.CodePoints.Count);
            // Subword and direct-character readers: exact by construction; report their work.
            double subwords = logs.Average(l => C00_Accounting.SubwordCount(l.CodePoints));
            rows.Add(new object[] { notes, chars, "subword, dense attention", 1.0, 0.0, subwords, 17.0 * subwords / chars, double.NaN, 1.0 });
            rows.Add(new object[] { notes, chars, "direct character, dense attention", 1.0, 0.0, chars, 21.0, double.NaN, 1.0 });
            foreach (var rd in readers)
                logs.SelectMany(l => l.Spans.Select(x => x.Text)).Append("failed").Distinct().AsParallel().ForAll(t => Code(t, rd.Order, rd.Sparsity));
            foreach (var rd in readers)
            {
                var sw = Stopwatch.StartNew();
                var ans = logs.Select(l => Ask(l, rd, Code, coder, book)).ToArray();
                sw.Stop();
                double acc = ans.Zip(logs).Average(x => x.First.Tag == x.Second.FailedTag ? 1.0 : 0);
                double trans = ans.Zip(logs).Average(x => x.First.Tag == x.Second.TransposedTag ? 1.0 : 0);
                double cand = ans.Average(a => (double)a.Candidates);
                double recall = ans.Average(a => a.Retrieved ? 1.0 : 0);
                double bitsPerChar = ans.Average(a => a.Bits);
                double msPer1k = sw.Elapsed.TotalMilliseconds / logs.Sum(l => l.CodePoints.Count) * 1000;
                rows.Add(new object[] { notes, chars, rd.Name, acc, trans, cand, bitsPerChar, msPer1k, recall });
                string key = $"n{notes}_{rd.Name.Replace(" ", "_").Replace(",", "")}";
                h[$"{key}_retrieved"] = recall;
                h[$"{key}_acc"] = acc;
                h[$"{key}_transposed"] = trans;
                h[$"{key}_candidates"] = cand;
                h[$"{key}_bits_per_char"] = bitsPerChar;
            }
            h[$"n{notes}_chars"] = chars;
            h[$"n{notes}_subwords"] = subwords;
        }
        var table = Table.Of("readers", new[] { "notes", "characters", "reader", "exact_tag", "transposed_tag", "candidates_per_query", "memory_bits_per_char", "ms_per_1000_chars", "failed_record_retrieved" }, rows);
        return new ExperimentResult("C03", "Which bearing failed? Readers at doubling history", new[] { table }, h);
    }

    private static Answer Ask(Log log, Reader rd, Func<string, bool, int, SparseCode> code, SpanCoder coder, AtomBook book)
    {
        var spans = log.Spans;
        var codes = spans.Select(s => code(s.Text, rd.Order, rd.Sparsity)).ToArray();
        // Build the index online: each record is appended to the lists of its IndexAtoms largest coefficients.
        var lists = new Dictionary<int, LinkedList<int>>();
        for (int i = 0; i < spans.Count; i++)
        {
            foreach (int a in Top(codes[i]))
            {
                if (!lists.TryGetValue(a, out var l)) lists[a] = l = new LinkedList<int>();
                l.AddLast(i);
                if (rd.Capped && l.Count > Cap) l.RemoveFirst();
            }
        }
        var qc = code("failed", rd.Order, rd.Sparsity);
        var qv = book.Reconstruct(qc);
        var cand = Top(qc).SelectMany(a => lists.TryGetValue(a, out var l) ? l : Enumerable.Empty<int>()).Distinct().ToArray();
        int best = -1; double bv = double.NegativeInfinity;
        foreach (int i in cand)
        {
            var v = book.Reconstruct(codes[i]);
            double s = Lin.Dot(v, qv) / Math.Sqrt(Lin.Norm2(v) * Lin.Norm2(qv) + 1e-300);
            if (s > bv) { bv = s; best = i; }
        }
        string tag = "";
        if (best > 0)
        {
            var tv = book.Reconstruct(codes[best - 1]);
            if (rd.Pointer) tag = spans[best - 1].Text;                       // assisted: read the stored source text
            else if (rd.Order)
            {
                var alphabet = log.CodePoints.Distinct().Where(c => !LogText.IsDelimiter(c)).OrderBy(c => c).ToArray();
                var table = alphabet.Append(SpanCoder.Eos).ToDictionary(c => c, c => coder.Char(c));
                tag = LogText.FromCodePoints(coder.Decode(tv, alphabet, table));
            }
            else
            {
                // A bag code cannot be spelled; the reader returns the closest string it has stored.
                var lex = spans.Select(s => s.Text).Distinct().ToArray();
                tag = lex.OrderByDescending(o => { var e = book.Reconstruct(code(o, false, rd.Sparsity)); return Lin.Dot(e, tv) / Math.Sqrt(Lin.Norm2(e) + 1e-300); })
                         .ThenBy(o => spans.Last(s => s.Text == o).Start).First();
            }
        }
        int offsetBits = (int)Math.Ceiling(Math.Log2(log.CodePoints.Count)) + 4;
        double bits = spans.Count * (double)(codes[0].Bits(book.AtomBits, CoefBits) + offsetBits) / log.CodePoints.Count
                      + (rd.Pointer ? 21.0 : 0.0);                                   // source code points kept for assisted recovery
        return new Answer(tag, cand.Length, bits, best >= 0 && spans[best].Text == "failed");
    }

    private static IEnumerable<int> Top(SparseCode c) =>
        c.Atoms.Zip(c.Coefs).OrderByDescending(x => Math.Abs(x.Second)).Take(IndexAtoms).Select(x => x.First);
}
