using CsLab.Core;

namespace CsLab.Experiments;

/// <summary>
/// Exact causal softmax attention when past keys take G distinct values: keep, per key, the occurrence count and the
/// sum of value vectors. Also measures how G grows under four key schemes on the maintenance log.
/// </summary>
public static class C01_GroupedAttention
{
    private const ulong Seed = 7781;
    public const int Width = 64, Dv = 32;

    public static ExperimentResult Run()
    {
        var h = new Dictionary<string, double>();
        var log = LogText.Generate(256, Rng.Derive(Seed, 1));
        var cps = log.CodePoints;
        int n = cps.Count;
        // Keys depend on the character type only; values carry per-occurrence content.
        var alphabet = cps.Distinct().OrderBy(c => c).ToArray();
        var keyOf = alphabet.ToDictionary(c => c, c => Lin.Gaussians(Rng.Derive(Seed, 10 + (ulong)c), Width).Values);
        var (vals, r1) = Lin.Gaussians(Rng.Derive(Seed, 2), n * Dv);
        var (qs, _) = Lin.Gaussians(r1, n * Width);
        double scale = 1.0 / Math.Sqrt(Width);
        double maxGap = 0; long fullWork = 0, groupWork = 0;
        var count = new Dictionary<int, double>();
        var sum = new Dictionary<int, double[]>();
        for (int t = 0; t < n; t++)
        {
            int c = cps[t];
            if (!count.ContainsKey(c)) { count[c] = 0; sum[c] = new double[Dv]; }
            count[c] += 1;
            for (int j = 0; j < Dv; j++) sum[c][j] += vals[t * Dv + j];
            if (t % 97 != 0) continue;                                   // check every 97th query exactly
            var q = qs.Skip(t * Width).Take(Width).ToArray();
            // Full history read.
            var logits = Enumerable.Range(0, t + 1).Select(i => Lin.Dot(q, keyOf[cps[i]]) * scale).ToArray();
            var p = Lin.Softmax(logits);
            var yFull = new double[Dv];
            for (int i = 0; i <= t; i++) for (int j = 0; j < Dv; j++) yFull[j] += p[i] * vals[i * Dv + j];
            fullWork += t + 1;
            // Grouped read.
            var groups = count.Keys.ToArray();
            var gl = groups.Select(g => Lin.Dot(q, keyOf[g]) * scale).ToArray();
            double mx = gl.Max(), den = 0;
            var yG = new double[Dv];
            for (int k = 0; k < groups.Length; k++)
            {
                double w = Math.Exp(gl[k] - mx);
                den += w * count[groups[k]];
                for (int j = 0; j < Dv; j++) yG[j] += w * sum[groups[k]][j];
            }
            for (int j = 0; j < Dv; j++) maxGap = Math.Max(maxGap, Math.Abs(yG[j] / den - yFull[j]));
            groupWork += groups.Length;
        }
        h["grouped_max_abs_gap"] = maxGap;
        h["full_reads_per_query"] = fullWork / (double)(n / 97 + 1);
        h["grouped_reads_per_query"] = groupWork / (double)(n / 97 + 1);
        h["alphabet_size"] = alphabet.Length;

        // Growth of G under four key schemes.
        var rows = new List<object[]>();
        foreach (int notes in new[] { 128, 256, 512, 1024, 2048, 4096 })
        {
            var lg = LogText.Generate(notes, Rng.Derive(Seed, 100 + (ulong)notes));
            var c = lg.CodePoints;
            int gChar = c.Distinct().Count();
            int gBigram = Enumerable.Range(0, c.Count).Select(i => (i > 0 ? c[i - 1] : -1, c[i])).Distinct().Count();
            int gSpan = lg.Spans.Select(s => s.Text).Distinct().Count();
            int gPos = c.Count;                                          // absolute-position-adjusted keys are all distinct
            rows.Add(new object[] { notes, c.Count, gChar, gBigram, gSpan, lg.Spans.Count, gPos });
            h[$"notes{notes}_G_char"] = gChar;
            h[$"notes{notes}_G_bigram"] = gBigram;
            h[$"notes{notes}_G_span"] = gSpan;
            h[$"notes{notes}_spans"] = lg.Spans.Count;
        }
        var table = Table.Of("groups", new[] { "notes", "characters", "G_character_keys", "G_bigram_keys", "G_span_string_keys", "spans", "G_absolute_position_keys" }, rows);
        return new ExperimentResult("C01", "Exact grouped attention and the growth of distinct keys", new[] { table }, h);
    }
}
