using System.Text;

namespace CsLab.Core;

/// <summary>A contiguous span of Unicode code points, closed online at a delimiter or at the length cap.</summary>
public sealed record Span(int Start, int Length, string Text, int Note);

/// <summary>A synthetic maintenance log with one failed bearing among near-duplicate notes.</summary>
public sealed record Log(string Text, IReadOnlyList<int> CodePoints, IReadOnlyList<Span> Spans, string FailedTag, string TransposedTag, int Notes);

public static class LogText
{
    public const int MaxSpan = 8;
    private static readonly string[] Statuses = { "ok", "worn", "noisy", "greased", "filed", "fails?", "ok-ish" };
    private static readonly string[] Lines = { "line", "Linie", "ligne", "línea" };
    private static readonly string[] Parts = { "bearing", "Lager", "roulement", "cojinete" };

    public static bool IsDelimiter(int cp) => cp is ' ' or ';' or ',' or '.' or ':' or '\n' or 0x2014;

    /// <summary>
    /// Builds a log of n notes. Exactly one note says the target bearing failed; others mention the target, its digit
    /// transposition and nearby tags with other statuses, so order and exact spelling decide the answer.
    /// </summary>
    public static Log Generate(int notes, Rng rng)
    {
        var r = rng;
        int Pick(int n) { var (v, nr) = r.NextInt(n); r = nr; return v; }
        int d1 = 1 + Pick(9), d2 = 1 + Pick(9);
        if (d2 == d1) d2 = d1 % 9 + 1;
        string target = $"B-{d1}{d2}", transposed = $"B-{d2}{d1}";
        int failedAt = Pick(notes);
        var sb = new StringBuilder();
        for (int i = 0; i < notes; i++)
        {
            string tag = i == failedAt ? target : Pick(3) switch
            {
                0 => target,
                1 => transposed,
                _ => $"B-{1 + Pick(9)}{1 + Pick(9)}",
            };
            if (i != failedAt && tag == target && Pick(2) == 0) tag = transposed;
            string status = i == failedAt ? "failed" : Statuses[Pick(Statuses.Length)];
            string other = Pick(2) == 0 ? transposed : $"B-{1 + Pick(9)}{1 + Pick(9)}";
            sb.Append($"{2026}-{1 + Pick(12):00}-{1 + Pick(28):00} {Lines[Pick(4)]} {1 + Pick(9)} — {Parts[Pick(4)]} {tag} {status}; cf. {other}, drawing D-{100 + Pick(900)}. ");
        }
        var text = sb.ToString();
        var cps = ToCodePoints(text);
        return new Log(text, cps, Segment(cps), target, transposed, notes);
    }

    public static IReadOnlyList<int> ToCodePoints(string s)
    {
        var list = new List<int>();
        for (int i = 0; i < s.Length; i += char.IsSurrogatePair(s, i) ? 2 : 1) list.Add(char.ConvertToUtf32(s, i));
        return list;
    }

    public static string FromCodePoints(IEnumerable<int> cps) => string.Concat(cps.Select(char.ConvertFromUtf32));

    /// <summary>
    /// Online segmentation: a span closes when a delimiter arrives (the delimiter is not stored) or when it reaches
    /// MaxSpan code points. Only characters already observed decide a boundary. Notes end at ". " after a drawing number.
    /// </summary>
    public static IReadOnlyList<Span> Segment(IReadOnlyList<int> cps)
    {
        var spans = new List<Span>();
        int start = -1, note = 0;
        for (int i = 0; i < cps.Count; i++)
        {
            bool delim = IsDelimiter(cps[i]);
            if (!delim && start < 0) start = i;
            bool full = start >= 0 && i - start + 1 == MaxSpan;
            if (start >= 0 && (delim || full))
            {
                int end = delim ? i : i + 1;
                spans.Add(new Span(start, end - start, FromCodePoints(cps.Skip(start).Take(end - start)), note));
                start = -1;
            }
            if (cps[i] == '.' && i + 1 < cps.Count && cps[i + 1] == ' ' && i > 0 && char.IsDigit((char)cps[i - 1])) note++;
        }
        if (start >= 0) spans.Add(new Span(start, cps.Count - start, FromCodePoints(cps.Skip(start)), note));
        return spans;
    }
}
