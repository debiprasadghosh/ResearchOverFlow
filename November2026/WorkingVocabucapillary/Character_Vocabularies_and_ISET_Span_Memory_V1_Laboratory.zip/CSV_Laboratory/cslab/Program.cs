using System.Diagnostics;
using CsLab.Core;
using CsLab.Experiments;

// Composition root: schedules the studies and performs the only file writes.
var registry = new (string Id, Func<ExperimentResult> Run)[]
{
    ("C00", C00_Accounting.Run),
    ("C01", C01_GroupedAttention.Run),
    ("C02", C02_SpanCodes.Run),
    ("C03", C03_BearingTest.Run),
};
var selected = args.Length == 0 ? registry : registry.Where(r => args.Contains(r.Id)).ToArray();
string outDir = Environment.GetEnvironmentVariable("CS_OUT") ?? Path.Combine("..", "out");
var results = new List<ExperimentResult>();
foreach (var (id, run) in selected)
{
    var sw = Stopwatch.StartNew();
    var r = run();
    sw.Stop();
    results.Add(r);
    Console.WriteLine($"{id} {r.Title}: {sw.Elapsed.TotalSeconds:F1} s");
    foreach (var kv in r.Headlines) Console.WriteLine($"   {kv.Key} = {kv.Value:G8}");
}
Output.Write(outDir, results);
