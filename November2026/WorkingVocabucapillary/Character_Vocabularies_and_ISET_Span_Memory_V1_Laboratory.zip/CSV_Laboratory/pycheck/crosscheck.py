"""Independent Python cross-check of the character-span laboratory.

Ports the SplitMix64 generator, the maintenance-log generator, the online segmenter, the subword counter and the
order-sensitive span code with its code-only decoder; recomputes grouped attention exactly with numpy.
Usage: python3 crosscheck.py [out_folder]
"""
import csv, json, math, sys
from pathlib import Path
import numpy as np

OUT = sys.argv[1] if len(sys.argv) > 1 else str(Path(__file__).resolve().parent.parent / "out")
H = json.load(open(f"{OUT}/headlines.json"))
M64 = (1 << 64) - 1


class Rng:
    def __init__(self, s): self.s = s & M64
    @staticmethod
    def derive(seed, stream):
        r = Rng(seed ^ ((stream * 0xD1B54A32D192ED03) & M64)); r.u64(); return r
    def u64(self):
        self.s = (self.s + 0x9E3779B97F4A7C15) & M64
        z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return z ^ (z >> 31)
    def double(self): return (self.u64() >> 11) * (1.0 / 9007199254740992.0)
    def int(self, n):
        v = int(self.double() * n); return n - 1 if v >= n else v
    def gauss(self):
        u1 = self.double(); u2 = self.double()
        return math.sqrt(-2.0 * math.log(1.0 - u1)) * math.cos(2.0 * math.pi * u2)


STATUSES = ["ok", "worn", "noisy", "greased", "filed", "fails?", "ok-ish"]
LINES = ["line", "Linie", "ligne", "línea"]
PARTS = ["bearing", "Lager", "roulement", "cojinete"]
MAXSPAN = 8


def generate(notes, r):
    d1 = 1 + r.int(9); d2 = 1 + r.int(9)
    if d2 == d1: d2 = d1 % 9 + 1
    target, transposed = f"B-{d1}{d2}", f"B-{d2}{d1}"
    failed_at = r.int(notes)
    out = []
    for i in range(notes):
        if i == failed_at: tag = target
        else:
            k = r.int(3)
            tag = target if k == 0 else transposed if k == 1 else f"B-{1 + r.int(9)}{1 + r.int(9)}"
        if i != failed_at and tag == target and r.int(2) == 0: tag = transposed
        status = "failed" if i == failed_at else STATUSES[r.int(len(STATUSES))]
        other = transposed if r.int(2) == 0 else f"B-{1 + r.int(9)}{1 + r.int(9)}"
        month = 1 + r.int(12); day = 1 + r.int(28); line = LINES[r.int(4)]; num = 1 + r.int(9); part = PARTS[r.int(4)]
        # C# draws tag, status and other first, then the interpolated fields from left to right.
        drawing = 100 + r.int(900)
        out.append(f"2026-{month:02d}-{day:02d} {line} {num} — {part} {tag} {status}; cf. {other}, drawing D-{drawing}. ")
    return "".join(out), target, transposed


def is_delim(c): return c in " ;,.:\n—"


def segment(text):
    spans, start = [], -1
    for i, c in enumerate(text):
        d = is_delim(c)
        if not d and start < 0: start = i
        full = start >= 0 and i - start + 1 == MAXSPAN
        if start >= 0 and (d or full):
            end = i if d else i + 1
            spans.append(text[start:end]); start = -1
    if start >= 0: spans.append(text[start:])
    return spans


def subwords(text):
    n, i = 0, 0
    while i < len(text):
        c = text[i]
        if c == " ": i += 1; continue
        if c.isalpha():
            j = i
            while j < len(text) and text[j].isalpha(): j += 1
            L = j - i; n += 1 if L <= 8 else (L + 3) // 4; i = j
        elif "0" <= c <= "9":
            j = i
            while j < len(text) and "0" <= text[j] <= "9": j += 1
            n += (j - i + 1) // 2; i = j
        else: n += 1; i += 1
    return n


rows = []
def check(name, cs, py, tol):
    rows.append((name, cs, py, abs(cs - py), abs(cs - py) <= tol))

check("C00 dense pair ratio 16,384 vs 4,096", H["C00.example_dense_pair_ratio"], 16384 * 16385 / (4096 * 4097), 1e-12)
for notes in [128, 1024, 4096]:
    text, _, _ = generate(notes, Rng.derive(4096, notes))
    check(f"C00 characters, {notes} notes", H[f"C00.notes{notes}_chars"], len(text), 0)
    check(f"C00 characters per subword, {notes} notes", H[f"C00.notes{notes}_chars_per_subword"], len(text) / subwords(text), 1e-12)
    sp = segment(text)
    within = sum(len(s) * (len(s) + 1) / 2 for s in sp)
    check(f"C00 span work plus index, {notes} notes", H[f"C00.notes{notes}_span_plus_index_work"], within + len(sp) * 128, 1e-6)
for notes in [128, 2048]:
    text, _, _ = generate(notes, Rng.derive(7781, 100 + notes))
    sp = segment(text)
    check(f"C01 distinct span strings, {notes} notes", H[f"C01.notes{notes}_G_span"], len(set(sp)), 0)
    check(f"C01 distinct bigram keys, {notes} notes", H[f"C01.notes{notes}_G_bigram"], len({(text[i - 1] if i else None, text[i]) for i in range(len(text))}), 0)

# Grouped attention identity, independent numpy implementation.
rng = np.random.default_rng(5)
G, n, w, dv = 40, 3000, 64, 32
keys = rng.normal(size=(G, w)); ids = rng.integers(0, G, size=n); vals = rng.normal(size=(n, dv)); q = rng.normal(size=w)
s = keys[ids] @ q / 8.0; p = np.exp(s - s.max()); full = (p[:, None] * vals).sum(0) / p.sum()
cnt = np.bincount(ids, minlength=G); vs = np.zeros((G, dv)); np.add.at(vs, ids, vals)
gs = np.exp(keys @ q / 8.0 - s.max()); grouped = (gs[:, None] * vs).sum(0) / (gs * cnt).sum()
check("Grouped attention identity (numpy, independent)", 0.0, float(np.abs(full - grouped).max()), 1e-12)

# Code-only decoder of the exact order code, widths 64 and 256 (Study C02).
text, _, _ = generate(1024, Rng.derive(9157, 1))
strings = sorted(set(segment(text)))
alphabet = sorted({ord(c) for s_ in strings for c in s_})
EOS = 0x110000
for width in [64, 256]:
    r = Rng.derive(9157, 7)
    perm = list(range(width))
    for i in range(width - 1, 0, -1):
        j = r.int(i + 1); perm[i], perm[j] = perm[j], perm[i]
    powers = [list(range(width))]
    for _ in range(MAXSPAN + 1):
        prev = powers[-1]; powers.append([perm[prev[i]] for i in range(width)])
    powers = [np.array(pw) for pw in powers]
    def char(cp):
        rr = Rng.derive(9157, 1000 + cp); g = np.array([rr.gauss() for _ in range(width)]); return g / np.sqrt((g * g).sum())
    table = {c: char(c) for c in alphabet + [EOS]}
    def shift(x, j): y = np.zeros(width); y[powers[j]] = x; return y
    def unshift(y, j): return y[powers[j]]
    def order(s_):
        v = np.zeros(width); cps = [ord(c) for c in s_]
        for j in range(len(cps) + 1): v += shift(table[cps[j]] if j < len(cps) else table[EOS], j)
        return v
    def decode(v):
        v = v.copy(); outp = []
        for j in range(MAXSPAN + 1):
            u = unshift(v, j); best, bv = EOS, -np.inf
            for c in alphabet + [EOS]:
                sc = float(u @ table[c])
                if sc > bv: bv, best = sc, c
            if best == EOS: break
            outp.append(best); v -= shift(table[best], j)
        return "".join(chr(c) for c in outp)
    acc = np.mean([decode(order(s_)) == s_ for s_ in strings])
    check(f"C02 code-only decoder on exact codes, width {width}", H[f"C02.w{width}_exact_code_decoder"], acc, 1e-12)

with open(f"{OUT}/PY_crosscheck.csv", "w", newline="") as fh:
    wtr = csv.writer(fh); wtr.writerow(["quantity", "csharp", "python", "abs_difference", "agree"])
    for row in rows: wtr.writerow(row)
print(f"{sum(r[4] for r in rows)}/{len(rows)} agree")
for row in rows:
    if not row[4]: print("DISAGREE", row)
