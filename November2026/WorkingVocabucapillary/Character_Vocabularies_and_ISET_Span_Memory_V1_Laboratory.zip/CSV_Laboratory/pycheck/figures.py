"""Figures for the paper, drawn from the C# laboratory outputs (plotting only)."""
import csv, os
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

_ROOT = Path(__file__).resolve().parent.parent
OUT = os.environ.get("CS_OUT", str(_ROOT / "out")); FIG = os.environ.get("CS_FIGS", str(_ROOT / "figs"))
os.makedirs(FIG, exist_ok=True)
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, VIOLET = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6"
SER = [BLUE, ORANGE, AQUA, YELLOW, MAGENTA, VIOLET]
INK, INK2, MUTED, GRID = "#1f1f1f", "#52514e", "#8a8984", "#e4e3df"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9, "axes.edgecolor": MUTED,
    "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": GRID,
    "grid.linewidth": 0.6, "axes.axisbelow": True, "axes.spines.top": False, "axes.spines.right": False,
    "legend.frameon": False, "savefig.dpi": 220, "lines.linewidth": 2, "text.color": INK})
def rd(n): return list(csv.DictReader(open(f"{OUT}/{n}.csv")))
def save(f, n): f.savefig(f"{FIG}/{n}.png", bbox_inches="tight"); plt.close(f)

# Figure 1: work against characters.
c = rd("C00_scaling"); N = [float(r["characters_N"]) for r in c]
fig, ax = plt.subplots(figsize=(5.6, 3.2))
for i, (col, lab) in enumerate([("dense_char_pairs", "dense attention over characters"), ("dense_subword_pairs", "dense attention over subwords"),
                                ("span_scan_pairs", "scan of all earlier spans"), ("linear_total", "within-span attention + capped index (NL + MK)")]):
    ax.plot(N, [float(r[col]) for r in c], marker="o", ms=3, color=SER[i], label=lab)
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel("characters in history, N"); ax.set_ylabel("pairwise or candidate work")
ax.legend(fontsize=7.4, loc="upper left")
save(fig, "fig1_work")

# Figure 2: exact spelling from the stored code against bits per record.
s = rd("C02_spelling")
fig, ax = plt.subplots(figsize=(5.6, 3.1))
for i, w in enumerate(["64", "256"]):
    pts = [(float(r["bits_per_record"]), float(r["exact_types"]), float(r["lexicon_assisted_exact"])) for r in s if r["width"] == w and r["atoms_s"] != "exact float code"]
    ax.plot([p[0] for p in pts], [p[1] for p in pts], marker="o", ms=3.5, color=SER[i], label=f"code only, width {w}")
    ax.plot([p[0] for p in pts], [p[2] for p in pts], marker="s", ms=3, ls="--", lw=1.4, color=SER[i], label=f"with stored lexicon, width {w}")
ax.axvline(10, color=MUTED, ls=":", lw=1); ax.text(11, 0.55, "10 bits name\nevery string", fontsize=7, color=INK2)
ax.axvline(21, color=MUTED, ls="--", lw=1); ax.text(23, 0.3, "21-bit pointer\nto source", fontsize=7, color=INK2)
ax.set_xscale("log", base=2); ax.set_ylim(-0.03, 1.05); ax.set_xlabel("bits per stored span record"); ax.set_ylabel("spans spelled exactly")
ax.legend(fontsize=7, loc="center left", bbox_to_anchor=(1.01, 0.5))
save(fig, "fig2_spelling")

# Figure 3: readers on the bearing test.
t = rd("C03_readers")
readers = ["order span, 4 atoms, capped index", "order span, 16 atoms, capped index", "order span, 32 atoms, capped index",
           "order span, 4 atoms + source pointer", "bag span, 16 atoms, capped index"]
labels = ["order code, 4 atoms", "order code, 16 atoms", "order code, 32 atoms", "4 atoms + source pointer", "bag code, 16 atoms"]
fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.9))
ax = axes[0]
ex = [float(next(r["exact_tag"] for r in t if r["notes"] == "2048" and r["reader"] == rr)) for rr in readers]
tr = [float(next(r["transposed_tag"] for r in t if r["notes"] == "2048" and r["reader"] == rr)) for rr in readers]
y = range(len(readers))
ax.barh([i - 0.19 for i in y], ex, height=0.36, color=BLUE, label="exact tag")
ax.barh([i + 0.19 for i in y], tr, height=0.36, color=ORANGE, label="transposed tag")
ax.set_yticks(list(y)); ax.set_yticklabels(labels); ax.invert_yaxis(); ax.set_xlim(0, 1.05)
ax.set_title("answers at 2,048 notes (40 logs)", pad=16); ax.legend(fontsize=7, loc="lower center", ncol=2, bbox_to_anchor=(0.45, 0.99))
ax = axes[1]
notes = sorted({int(r["notes"]) for r in t})
for i, (rr, lab) in enumerate([("direct character, dense attention", "dense characters"), ("subword, dense attention", "dense subwords"),
                               ("order span, 16 atoms, full postings", "span index, full lists"), ("order span, 16 atoms, capped index", "span index, capped lists")]):
    ax.plot(notes, [float(next(r["candidates_per_query"] for r in t if r["notes"] == str(n) and r["reader"] == rr)) for n in notes], marker="o", ms=3, color=SER[i], label=lab)
ax.set_xscale("log", base=2); ax.set_yscale("log"); ax.set_xlabel("notes in log"); ax.set_title("positions examined per query")
ax.legend(fontsize=7, loc="upper left")
fig.tight_layout()
save(fig, "fig3_bearing")

# Figure 4: distinct keys as the log grows.
g = rd("C01_groups")
fig, ax = plt.subplots(figsize=(5.4, 3.0))
chars = [float(r["characters"]) for r in g]
for i, (col, lab) in enumerate([("G_character_keys", "character-type keys"), ("G_bigram_keys", "previous + current character"),
                                ("G_span_string_keys", "span strings"), ("spans", "span occurrences (reference)"), ("G_absolute_position_keys", "absolute-position keys")]):
    ax.plot(chars, [float(r[col]) for r in g], marker="o", ms=3, color=SER[i], label=lab)
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel("characters in history"); ax.set_ylabel("distinct groups G")
ax.legend(fontsize=7.2, loc="center left", bbox_to_anchor=(1.01, 0.5))
save(fig, "fig4_groups")
print("figures written")
