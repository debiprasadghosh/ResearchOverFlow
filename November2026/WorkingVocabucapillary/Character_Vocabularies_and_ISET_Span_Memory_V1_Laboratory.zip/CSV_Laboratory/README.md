# Character vocabularies and ISET span memory: laboratory (immutable C#)

Companion to *Character Vocabularies and ISET Span Memory* (Ghosh, 2026). Every number in the paper comes from `cslab/`.

| Folder | Contents |
|---|---|
| `cslab/` | .NET 8 console project, no packages. `Core/` holds the generator, the maintenance-log generator and online segmenter, the order/bag span codes with the code-only decoder, and the seeded atom book with sparse fitting. `Experiments/C00`–`C03`. `Program.cs` is the only code that writes files. |
| `out/` | CSV tables, `headlines.json`, `run_log.txt`, `PY_crosscheck.csv` (17 of 17 agree). |
| `pycheck/` | `crosscheck.py` (independent port of the generator, log, segmenter, tokenizer and span decoder) and `figures.py`. |
| `figs/`, `paper/` | Figures; `build_paper.py` rebuilds the Word file from the outputs (needs pandoc) using `ref.docx`. |

```
cd cslab && dotnet run -c Release          # all studies, about 2.5 minutes on two cores; writes ../out
cd ../pycheck && python3 crosscheck.py && python3 figures.py
cd ../paper && python3 build_paper.py
```

| Study | Question |
|---|---|
| C00 | Work of dense character, dense subword, span-scan and span-index readers as the history doubles |
| C01 | Exact grouped attention over G distinct keys; growth of G under four key schemes |
| C02 | Bits per span record needed to spell a span from its code alone; lexicon and pointer recovery; order selectivity |
| C03 | Which bearing failed? Exact tag, transpositions and positions examined for six reader designs |

Conventions: sealed records and read-only lists, pure static functions, `Rng` is a readonly record struct (SplitMix64)
whose draws return `(Value, Next)`. Timing in C03 is reported but not used for conclusions.
