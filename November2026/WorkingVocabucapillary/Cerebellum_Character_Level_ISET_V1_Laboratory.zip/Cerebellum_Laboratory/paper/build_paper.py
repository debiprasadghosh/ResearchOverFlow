"""Assembles the cerebellum paper from the laboratory outputs and converts it to a validated Word file."""
import csv, json, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT, FIG = ROOT / "out", ROOT / "figs"
sys.path.insert(0, str(HERE))
import docxfix

H = json.load(open(OUT / "headlines.json"))
def g(k): return H[k]
def rd(n): return list(csv.DictReader(open(OUT / f"{n}.csv")))
def m(s): return s.replace("-", "−")
def f2(x): return m(f"{x:.2f}")
def f3(x): return m(f"{x:.3f}")
def f4(x): return m(f"{x:.4f}")
def pc(x, d=0): return m(f"{100 * x:.{d}f}%")
def n0(x): return f"{x:,.0f}"

def md_table(header, rows, caption):
    lens = [max(min(len(str(h)), 14), 9, *(len(str(r[i])) for r in rows)) for i, h in enumerate(header)]
    out = [f"Table: {caption}", "", "| " + " | ".join(header) + " |", "|" + "|".join("-" * max(9, min(60, l)) for l in lens) + "|"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out) + "\n"

status = md_table(["Brain component", "Role in the Vocabucapillary analogy", "Numerical status", "Main open question"], [
    ["Neocortex", "Long-term banks of native and association vocabularies", "Supported: exact read identity; nightly bank 186× smaller than a KV log by day 30", "Revision of stale evidence"],
    ["Cortical microcolumn", "Local recurrent expander of compact cues", "Revised: a 96-bit four-state cell cannot carry a 4,096-wide row; a continuing drive keeps seed identity", "Whether minicolumns are computational units"],
    ["Ventral reading pathway", "Order-sensitive composition of characters into spans", "Supported in the model: transposition similarity 1.00 → 0.72 → 0.59 with local steps", "Imaging test of graded order selectivity"],
    ["Hippocampus", "Working memory and nightly replay", "Supported: decoupled forward–backward consolidation is exact", "Replay selection at scale"],
    ["Thalamus", "Coefficient operator; drivers and modulators; sleep pairing", "Specified: mispairing harms beyond λw ≈ 0.5; gating removes it", "Direct test of coefficient pairing"],
    ["Basal ganglia", "Go / no-go margin gate over candidate reads", "Supported: exact answers with 40% lower latency", "Learning the margin online"],
    ["Amygdala", "Ordered store of important short sequences", "Supported in the model: 64 bytes, full detection", "Decay and interference"],
    ["Prefrontal cortex", "Harness cache, context gating, mature vs juvenile memory", "Proposed: context gating keeps the first task at 72%", "Cache governance across agents"],
    ["Cerebellum", "Character-level ISET: fine spans expanded and corrected", "This paper: expansion helps fine corrections; character residuals give the best resolution per bit", "Real robot data; learned ISET"],
], "Table 1. The brain analogy of the Vocabucapillary series and its numerical status. Rows other than the cerebellum summarise earlier studies of the series (Ghosh, 2026c, 2026d, 2026e).")

neu = rd("E00_neurons")
t_neu = md_table(["Region", "Neurons (billions)", "Share"], [[r["region"], r["neurons_billion"], pc(float(r["share"]), 1)] for r in neu],
    "Table 2. Neurons in the human brain (Azevedo et al., 2009).")
ch = rd("E00_chunk")
t_chunk = md_table(["Representation of one second of 7-DoF control at 50 Hz", "Bits per chunk", "Symbols or steps", "Sequential network calls"],
    [[r["representation"], n0(float(r["bits_per_chunk"])), r["symbols_or_steps"], r["sequential_network_calls"]] for r in ch],
    "Table 3. Accounting for one control chunk of 350 values. Flow matching emits 16-bit values after its integration steps.")

e1 = rd("E01_expansion")
def ev(w, M, K): return float(next(r["test_rel_mse"] for r in e1 if r["target_frequency"] == w and r["granule_cells_M"] == str(M) and r["inputs_per_granule_K"] == str(K)))
t_exp = md_table(["Target frequency", "Linear readout of 8 inputs", "64 granule cells", "256", "1,024", "512 cells, K = 1", "K = 2", "K = 4", "K = 8"],
    [[w, f3(ev(w, 0, 0)), f3(ev(w, 64, 4)), f3(ev(w, 256, 4)), f3(ev(w, 1024, 4)), f3(ev(w, 512, 1)), f3(ev(w, 512, 2)), f3(ev(w, 512, 4)), f3(ev(w, 512, 8))] for w in ["0.5", "1", "2"]],
    "Table 4. Test error (relative mean squared error) of a learned fine correction from 8 mossy-fibre inputs, by granule-cell count and inputs per granule cell K (3,000 training samples).")

e2 = rd("E02_resolution")
t_res = md_table(["Representation", "Setting", "Bits per chunk", "RMS error"],
    [[r["representation"], r["setting"], n0(float(r["bits_per_chunk"])), f4(float(r["rms_error"]))] for r in e2 if r["representation"] != "motor characters, raw"],
    f"Table 5. Resolution of 200 one-second chunks (7 joints × 64 steps; signal RMS {f2(g('E02.signal_rms'))}) with smooth motion and sharp contact corrections. Character bits are entropy-coded.")
e2s = rd("E02_iset_spans")
t_iset = md_table(["Atoms per span record", "Bits per 8-character span", "Spans spelled exactly", "Code-only bits per chunk", "Raw character bits per chunk"],
    [[r["atoms_s"], r["bits_per_8_char_span"], f3(float(r["exact_spelling"])), n0(float(r["code_only_bits_per_chunk"])), n0(float(r["raw_character_bits_per_chunk"]))] for r in e2s],
    "Table 6. Storing motor-character spans as ISET-style sparse codes (width 256, 512 seeded atoms) and spelling them back from the code alone.")

e3 = rd("E03_multimodal")
order = ["training data (reference)", "mean regression", "flow, S=1", "flow, S=2", "flow, S=4", "flow, S=8", "flow, S=32",
         "increment characters, order 1", "increment characters, order 4", "position characters, order 1", "position characters, order 2", "position characters, order 4"]
def mv(n, meth, col): return float(next(r[col] for r in e3 if r["training_trajectories"] == str(n) and r["method"] == meth))
t_mm = md_table(["Method", "Sequential calls", "Collision, 64 / 4,096 examples", "Off-path RMS, 64 / 4,096", "Novelty, 4,096"],
    [[o, n0(mv(4096, o, "sequential_calls")) if o != "training data (reference)" else "–", f"{f3(mv(64, o, 'collision_rate'))} / {f3(mv(4096, o, 'collision_rate'))}",
      f"{f3(mv(64, o, 'off_manifold_rms'))} / {f3(mv(4096, o, 'off_manifold_rms'))}", "–" if o == "training data (reference)" else f2(mv(4096, o, "nearest_train_over_spacing"))] for o in order],
    "Table 7. Passing an obstacle on the left or right (1,000 samples per method). Collision means passing within 0.3 of the centre line mid-path. Off-path RMS is the distance to the nearest valid path of either side. Novelty is the distance to the nearest training example divided by the typical spacing between training examples (values near or below one indicate copies).")

py = list(csv.DictReader(open(OUT / "PY_crosscheck.csv")))
py_agree = f"{sum(r['agree'] == 'True' for r in py)} of {len(py)}"
def ri(rep, setting): return float(next(r["rms_error"] for r in e2 if r["representation"] == rep and r["setting"] == setting))
def rb(rep, setting): return float(next(r["bits_per_chunk"] for r in e2 if r["representation"] == rep and r["setting"] == setting))
split = "coarse DCT-8 + character residual"

md = f"""---
title: "The Cerebellum as a Character-Level ISET: Fine-Resolution Vocabucapillary Memory for Physical AI"
author: "Debi Prasad Ghosh"
date: "November 2026"
abstract: |
  Language models choose among discrete tokens, while robots must act at fine continuous resolution, and physical AI has largely turned to diffusion and flow matching to get there. This paper proposes a different route grounded in the brain analogy of the Vocabucapillary series. The neocortex holds coarse long-term vocabularies; the cerebellum, which contains {pc(g('E00.cerebellum_neuron_share'))} of human neurons, is modelled as a character-level invertible sequence embedding (ISET). Mossy fibres carry short spans of fine motor or linguistic characters together with cortical context, granule cells expand them into a sparse high-dimensional code, Purkinje cells read out the next correction, and climbing fibres supply its error. The paper first summarises the status of every brain component in the analogy, then tests the cerebellar role numerically in an immutable C# laboratory with an independent Python check ({py_agree} quantities agreed). Granule expansion lowered the error of a learned fine correction from {f3(ev('1', 0, 0))} to {f3(ev('1', 1024, 4))} at moderate resolution, but helped little at the finest resolution with 3,000 examples. A coarse cortical plan of eight DCT coefficients per joint plus a character-level residual reached an RMS error of {f4(ri(split, 'step 0.02'))} at {n0(rb(split, 'step 0.02'))} bits per second of 7-joint control, against {f4(ri('DCT, 8-bit coefficients', '64 coefficients per joint'))} for all 64 DCT coefficients and {f4(ri('per-value bins', '8 bits per value'))} for 8-bit bins at {n0(rb('per-value bins', '8 bits per value'))} bits. On a two-way obstacle task, mean regression always collided, a flow sampler needed four integration steps to avoid collisions, and position-character models with sixteen sequential steps avoided collisions while staying within {f3(mv(4096, 'position characters, order 2', 'off_manifold_rms'))} of a valid path. Spelling motor-character spans back from a compact ISET code was expensive, however: {pc(g('E02.iset_s32_exact'))} exact at 560 bits per 8-character span. The cerebellum is therefore modelled as computing fine corrections online, not as storing exact strings.
---

# 1 Introduction

A language model reads and writes tokens from a fixed vocabulary, and a few thousand tokens describe a page. A robot arm must specify joint commands many times a second, and a millimetre of error can separate a grasp from a collision. Physical AI has followed two routes to this resolution. One discretizes actions into tokens, first as per-value bins (Zitkovich et al., 2023) and then as compressed frequency coefficients (Pertsch et al., 2025). The other generates continuous action chunks with diffusion or flow matching (Chi et al., 2023; Lipman et al., 2023; Black et al., 2024; Physical Intelligence et al., 2025), often after predicting chunks rather than single steps (Zhao et al., 2023). Recent work combines the two by refining discrete action tokens with discrete flow matching (Chen et al., 2026).

The Vocabucapillary series has developed a brain analogy for language models built around long-term coefficient memory (Ghosh, 2026a, 2026c). The cerebellum has been missing from it, although it holds most of the brain's neurons, learns fine corrections to movement, and also responds to language (Casto et al., 2026). This paper adds it in a specific role: a character-level invertible sequence embedding in the sense of ISET (Ghosh, 2024), operating on fine spans of motor or linguistic characters and returning corrections to a coarse cortical plan.

Section 2 summarises the status of every component of the analogy. Section 3 sets out the cerebellar mapping. Sections 4 to 6 test it: whether granule-cell expansion helps learn fine corrections, whether a coarse plan with a character-level residual gives better resolution per bit than tokens or frequency codes, and how character models compare with flow sampling on a two-way choice. Section 7 places the result among current physical-AI methods, Section 8 lists predictions, and Sections 9 and 10 give limitations and conclusions.

# 2 The brain analogy so far

{status}
![Figure 1. The brain analogy of the Vocabucapillary series with the cerebellum added.](FIG/fig1_brain_map.png){{width=6.2in}}

The earlier studies leave three patterns. Components that select or gate (basal ganglia, thalamus, amygdala) translate cleanly into exact algorithms with measurable savings. Components that store (neocortex, hippocampus) are supported where storage is a sum of coefficients and revised where a tiny generator was asked to recreate rich content. Order-sensitive composition, from the reading pathway to the span codes of the character study, is cheap to keep, but exact spelling is expensive to regenerate from a compact code and cheap to read from stored text. The cerebellum has to fit within these constraints.

# 3 The cerebellum as a character-level ISET

The cerebellum contains about four-fifths of human neurons, almost all of them small granule cells (Table 2). Mossy fibres from the pons and spinal cord bring a modest number of inputs; each granule cell receives only about four of them, so the granular layer expands the input into a very high-dimensional, sparse code (Marr, 1969; Albus, 1971; Litwin-Kumar et al., 2017). Purkinje cells read that code linearly, and climbing fibres from the inferior olive deliver an error signal that adjusts the parallel-fibre synapses (Raymond & Medina, 2018). The cerebellum is widely modelled as learning forward and inverse models that predict and correct the consequences of commands (Wolpert et al., 1998; Ito, 2008), and four regions of the human cerebellum respond to language, one of them selectively (Casto et al., 2026).

{t_neu}
The proposed mapping is as follows. A character is the smallest unit of a modality: a quantized joint increment or position for movement, a Unicode code point for text, a short audio frame for speech. Mossy fibres deliver the most recent span of characters together with the cortical context, which in the series is a Vocabucapillary coefficient record. The granular layer computes the encoder half of an ISET, an order-sensitive expansion of the span,

$$h_i = \\left[ \\sum_{{k=1}}^{{K}} J_{{ik}} \\, x_{{\\pi_i(k)}} - \\theta_i \\right]_+, \\quad\\quad\\quad (1)$$

where each granule cell i reads K inputs chosen by π_i and its threshold θ_i fixes a sparse coding level. Purkinje cells compute the decoder half, a linear readout y = w·h of the next correction or the next characters, and the climbing fibre supplies the error e that drives the delta rule

$$\\Delta w = \\eta \\, e \\, h. \\quad\\quad\\quad (2)$$

The deep cerebellar nuclei return the result through the thalamus to the cortex, where it adjusts the coarse plan. The cortex thus keeps a few coefficients per span and the cerebellum supplies the fine detail at the timescale of control. This is a computing role rather than a storage role, which matters for Section 5.

# 4 Granule expansion for fine corrections

Study E01 asks whether expansion helps learn a fine correction. Eight mossy-fibre inputs, such as joint angles and a phase signal, determine a target correction built from random Fourier features whose frequency sets the required resolution. Granule cells sum K random inputs, threshold them to a coding level of 10%, and a Purkinje readout is fitted to 3,000 examples. The climbing-fibre delta rule converges to the least-squares readout, which is computed directly here with a small ridge penalty chosen on held-out data.

{t_exp}
![Figure 2. Test error of a learned fine correction against granule-cell count. Dotted lines show a linear readout of the eight inputs.](FIG/fig2_expansion.png){{width=5.6in}}

Expansion pays at moderate resolution. At frequency 1, the test error fell from {f3(ev('1', 0, 0))} for a linear readout to {f3(ev('1', 1024, 4))} with 1,024 granule cells, and at frequency 0.5 from {f3(ev('0.5', 0, 0))} to {f3(ev('0.5', 1024, 4))}. Too few cells hurt: 64 granule cells did worse than the linear readout. Granule cells that read a single input were poor ({f3(ev('1', 512, 1))} at frequency 1), and four or more inputs per cell were needed, consistent with the sparse connectivity of real granule cells (Litwin-Kumar et al., 2017). At the finest resolution tested, expansion barely helped ({f3(ev('2', 0, 0))} to {f3(ev('2', 1024, 4))}): 3,000 examples cannot pin down a correction that fine. A cerebellar character model therefore needs abundant error signals, which movement provides at every step.

# 5 Motor characters and resolution per bit

Study E02 encodes one second of 7-joint motion at 64 steps. Each joint combines smooth motion with three sharp contact corrections. Four representations are compared at matched bits. Per-value bins quantize every sample. DCT codes keep the leading 8-bit frequency coefficients, the core of the FAST action tokenizer before its byte-pair stage (Pertsch et al., 2025). Motor characters code each step as one of 16 increments relative to the running reconstruction. The cortex–cerebellum split keeps eight DCT coefficients per joint as the coarse plan and codes the residual with motor characters.

{t_res}
![Figure 3. RMS error against bits per one-second chunk.](FIG/fig3_resolution.png){{width=6.0in}}

The split gives the best resolution per bit. With residual characters of step 0.02 it reached {f4(ri(split, 'step 0.02'))} at {n0(rb(split, 'step 0.02'))} bits, while all 64 DCT coefficients stopped at {f4(ri('DCT, 8-bit coefficients', '64 coefficients per joint'))} because 8-bit coefficients smear the contact steps, and per-value bins needed 8 bits per value ({n0(rb('per-value bins', '8 bits per value'))} bits) to reach {f4(ri('per-value bins', '8 bits per value'))}. Motor characters alone did poorly: with 16 symbols a small step cannot follow fast motion (slope overload), so the error grew as the step shrank, to {f4(ri('motor characters, entropy-coded', 'step 0.01'))} at step 0.01. Characters work as a residual on top of a coarse plan, which is the division of labour the analogy assigns to cortex and cerebellum. The residual characters were cheap because they are mostly zero, at {f2(g('E02.split_d0.02_entropy'))} bits per symbol.

{t_iset}
Storing those character spans as ISET-style codes and spelling them back is expensive. Table 6 shows that an 8-character span needs 560 bits to be recovered exactly {pc(g('E02.iset_s32_exact'))} of the time and 1,104 bits for {pc(g('E02.iset_s64_exact'), 1)}, against 32 bits as raw characters. The same result appeared for text in the character-span study of this series. A cerebellar ISET should therefore compute residuals from the current context and pass them on, while any exact motor sequence that must be kept is stored as characters with pointers, not regenerated from a compact code.

# 6 Two-way choices: regression, flow and characters

Study E03 tests the property that made diffusion and flow attractive for robots: representing several valid actions. An arm passes an obstacle on the left or on the right with equal probability, following a 16-step path of slightly varying amplitude. Mean regression averages the two sides. The flow sampler integrates the exact marginal velocity of the linear noise-to-data path for the training set with S Euler steps; it stands for a perfectly trained flow model. Character models sample increments or positions at a step of 0.1 from counts conditioned on the step index and the previous o characters.

{t_mm}
![Figure 4. Collision rate and distance from a valid path, 4,096 training paths.](FIG/fig4_multimodal.png){{width=6.2in}}

Mean regression and one-step flow drove straight through the obstacle every time. Flow needed four integration steps to avoid collisions and reached the smallest path error with eight. It also copied its training examples: with 4,096 paths the samples lay within {f2(mv(4096, 'flow, S=8', 'nearest_train_over_spacing'))} of the typical spacing of the nearest training path, a known property of an exactly fitted flow that learned networks soften by smoothing. Character models never averaged the two sides, because the first characters commit to one. Position characters stayed within {f3(mv(4096, 'position characters, order 2', 'off_manifold_rms'))} of a valid path with 4,096 examples, near the quantization floor of 0.029 for step 0.1. Increment characters drifted ({f3(mv(4096, 'increment characters, order 4', 'off_manifold_rms'))}), because each sampled step adds to the errors of the steps before it. The cost structure differs: flow made S full-chunk passes, while characters made 16 sequential but small decisions.

# 7 Where an ISET-based Vocabucapillary fits in physical AI

The results suggest a hybrid rather than a replacement. Diffusion and flow models give smooth, multimodal action chunks from a few network passes, and discrete flow matching now allows tokens to be revised during refinement (Chen et al., 2026). Token-based models inherit language-model machinery but pay many sequential steps per second of control. The cerebellar route adds three things.

1. **A coarse plan plus a fine residual.** A cortical model, which may itself be a flow or token model, emits a few coefficients per joint; a cerebellar character model adds a sparse residual that captures contacts and corrections cheaply (Section 5).
2. **Commitment without averaging.** Characters choose a side early and keep it, like flow with enough steps but without integrating a whole chunk at once (Section 6).
3. **Memory of motor spans.** Vocabucapillary memory can store motor-character spans with their context and offsets, so that a skill can be retrieved and replayed exactly by pointer, while new situations are handled by the online residual.

Training follows the climbing-fibre rule: the residual model learns from the error between the corrected and the observed movement at every step, which supplies the abundant signal that Section 4 showed fine corrections require.

# 8 Predictions and tests

For physical AI: a policy that adds a character-level residual to a coarse flow or DCT plan should reduce contact errors at a fixed bit or latency budget, most visibly in insertion and wiping tasks where sharp corrections dominate. A character model should reproduce two-way choices without averaging at sixteen small sequential steps per chunk. Exact replay of stored skills should use pointers to stored characters rather than regenerating them from a compact code.

For neuroscience: if the cerebellum computes span-level corrections, cerebellar language regions should respond more to local sequence violations within a word or short phrase than to violations of meaning across phrases, with the language-selective region identified by Casto et al. (2026) showing the strongest effect. Granule-layer activity should expand short motor and linguistic spans into sparse codes in which transposed spans are less similar than in mossy-fibre input.

# 9 Limitations

All studies are small and synthetic. The expansion study uses random target functions; the motion study uses synthetic joints without dynamics or contact physics; the obstacle task is one-dimensional. The flow sampler is the exact flow for the training set, not a learned network, so it overstates sample sharpness and memorization. The ISET encoder is the analytic position code of the character study, not a trained ISET. Neuron counts come from one study, and the anatomical mapping is a hypothesis to test, not a claim about how the cerebellum works.

# 10 Conclusion

The cerebellum fits the Vocabucapillary analogy as a character-level ISET that computes fine corrections: granule cells expand short spans with cortical context, Purkinje cells read out the correction, and climbing fibres teach it. Numerically, expansion helps learn moderate-resolution corrections when examples are plentiful, a coarse plan with a character residual gives the best resolution per bit of the codes tested, and character models commit to one of several valid actions without the averaging that defeats regression. Regenerating exact character spans from compact codes remains expensive, so the cerebellum computes and the cortex, through Vocabucapillary memory, stores. For physical AI this points to a hybrid: a coarse continuous or token plan, a cerebellar residual at character resolution, and a pointer-addressed memory of skills.

# Appendix A The immutable C# laboratory

The laboratory is a .NET 8 console project without external packages. Domain state is held in sealed records and read-only lists, every computation is a pure static function, and the SplitMix64 generator is a readonly record struct whose draws return the value and the successor. One output boundary writes CSV tables and a JSON file of headline values. A Python program ports the generator, regenerates the trajectories of Studies E02 and E03 and recomputes quantization, DCT, motor-character and regression results; {py_agree} quantities agreed.

Table: Table 8. Studies of the laboratory.

| Study | Section | Question | Kind of result |
|-----|-----------|----------------------------------------------|--------------------|
| E00 | 3, 7 | Neuron budgets and the cost of action representations per chunk | Accounting |
| E01 | 4 | Does granule expansion help learn fine corrections? | Fitted readouts |
| E02 | 5 | Which representation gives the best resolution per bit? | Exact codecs |
| E03 | 6 | How do regression, flow and character models handle a two-way choice? | Monte Carlo |

# References

Albus, J. S. (1971). A theory of cerebellar function. *Mathematical Biosciences, 10*(1–2), 25–61. https://doi.org/10.1016/0025-5564(71)90051-4

Azevedo, F. A. C., Carvalho, L. R. B., Grinberg, L. T., Farfel, J. M., Ferretti, R. E. L., Leite, R. E. P., Jacob Filho, W., Lent, R., & Herculano-Houzel, S. (2009). Equal numbers of neuronal and nonneuronal cells make the human brain an isometrically scaled-up primate brain. *Journal of Comparative Neurology, 513*(5), 532–541. https://doi.org/10.1002/cne.21974

Black, K., et al. (2024). *π0: A vision-language-action flow model for general robot control* [Preprint]. arXiv:2410.24164.

Casto, C., Poliak, M., Tuckute, G., Small, H., Sherlock, P., Wolna, A., Lipkin, B., D'Mello, A. M., & Fedorenko, E. (2026). Language-responsive regions of the human cerebellum. *Neuron*. https://www.cell.com/neuron/fulltext/S0896-6273(25)00986-9

Chen, J., Song, W., Fang, J., et al. (2026). *DFM-VLA: Iterative action refinement for robot manipulation via discrete flow matching* [Preprint]. arXiv:2603.26320.

Chi, C., Feng, S., Du, Y., Xu, Z., Cousineau, E., Burchfiel, B., & Song, S. (2023). Diffusion policy: Visuomotor policy learning via action diffusion. *Robotics: Science and Systems*. arXiv:2303.04137.

Ghosh, D. P. (2024). *ISET: Invertible sequence embedding from Transformer* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.36457.67684

Ghosh, D. P. (2026a). *KV coefficient memory for Attentionlet* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.31586.70088

Ghosh, D. P. (2026b). *Vocabucapillary for cacheless transformer* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.36209.44648

Ghosh, D. P. (2026c). *Vocabucapillary memory for cooperative AI* (2nd ed.). Debias Parametric Guru.

Ghosh, D. P. (2026d). *Localised recurrent Vocabucapillary: What a seed-generated vocabulary can carry, and how multistage Attentionlet meets context rot* [Manuscript].

Ghosh, D. P. (2026e). *Character vocabularies and ISET span memory: Spelling, order and linear-time reading in Vocabucapillary models* [Manuscript].

Ito, M. (2008). Control of mental activities by internal models in the cerebellum. *Nature Reviews Neuroscience, 9*(4), 304–313. https://doi.org/10.1038/nrn2332

Lipman, Y., Chen, R. T. Q., Ben-Hamu, H., Nickel, M., & Le, M. (2023). Flow matching for generative modeling. *International Conference on Learning Representations*. arXiv:2210.02747.

Litwin-Kumar, A., Harris, K. D., Axel, R., Sompolinsky, H., & Abbott, L. F. (2017). Optimal degrees of synaptic connectivity. *Neuron, 93*(5), 1153–1164. https://doi.org/10.1016/j.neuron.2017.01.030

Marr, D. (1969). A theory of cerebellar cortex. *Journal of Physiology, 202*(2), 437–470. https://doi.org/10.1113/jphysiol.1969.sp008820

Pertsch, K., Stachowicz, K., Ichter, B., Driess, D., Nair, S., Vuong, Q., Mees, O., Finn, C., & Levine, S. (2025). *FAST: Efficient action tokenization for vision-language-action models* [Preprint]. arXiv:2501.09747.

Physical Intelligence, Black, K., et al. (2025). *π0.5: A vision-language-action model with open-world generalization* [Preprint]. arXiv:2504.16054.

Raymond, J. L., & Medina, J. F. (2018). Computational principles of supervised learning in the cerebellum. *Annual Review of Neuroscience, 41*, 233–253. https://doi.org/10.1146/annurev-neuro-080317-061948

Wolpert, D. M., Miall, R. C., & Kawato, M. (1998). Internal models in the cerebellum. *Trends in Cognitive Sciences, 2*(9), 338–347. https://doi.org/10.1016/S1364-6613(98)01221-2

Zhao, T. Z., Kumar, V., Levine, S., & Finn, C. (2023). Learning fine-grained bimanual manipulation with low-cost hardware. *Robotics: Science and Systems*. arXiv:2304.13705.

Zitkovich, B., et al. (2023). RT-2: Vision-language-action models transfer web knowledge to robotic control. *Conference on Robot Learning*. arXiv:2307.15818.
"""
md = md.replace("FIG/", str(FIG) + "/")
(HERE / "paper.md").write_text(md, encoding="utf8")
subprocess.run(["pandoc", str(HERE / "paper.md"), "-o", str(HERE / "raw.docx"), "--reference-doc", str(HERE / "ref.docx")], check=True)
docxfix.repair(HERE / "raw.docx", HERE / "paper.docx")
(HERE / "raw.docx").unlink()
print("paper written:", len(md.split()), "words")
