"""Independent Python cross-check of the cerebellum laboratory.

Ports the SplitMix64 generator, regenerates the joint trajectories of Study E02 and the bimodal trajectories of
Study E03, and recomputes quantization, DCT, motor-character and regression results with numpy.
Usage: python3 crosscheck.py [out_folder]
"""
import csv, json, math, sys
from pathlib import Path
import numpy as np

OUT = sys.argv[1] if len(sys.argv) > 1 else str(Path(__file__).resolve().parent.parent / "out")
H = json.load(open(f"{OUT}/headlines.json"))
M64 = (1 << 64) - 1


class Rng:
    def __init__(self, s): self.s = s & M64
    @staticmethod
    def derive(seed, stream):
        r = Rng(seed ^ ((stream * 0xD1B54A32D192ED03) & M64)); r.u64(); return r
    def u64(self):
        self.s = (self.s + 0x9E3779B97F4A7C15) & M64
        z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return z ^ (z >> 31)
    def double(self): return (self.u64() >> 11) * (1.0 / 9007199254740992.0)
    def int(self, n):
        v = int(self.double() * n); return n - 1 if v >= n else v
    def uniform(self, lo, hi): return lo + (hi - lo) * self.double()
    def gauss(self):
        u1 = self.double(); u2 = self.double()
        return math.sqrt(-2.0 * math.log(1.0 - u1)) * math.cos(2.0 * math.pi * u2)


rows = []
def check(name, cs, py, tol):
    rows.append((name, cs, py, abs(cs - py), abs(cs - py) <= tol))

total = 16.34 + 69.03 + 0.69
check("E00 cerebellum share of neurons", H["E00.cerebellum_neuron_share"], 69.03 / total, 1e-12)

# Study E02: joint trajectories.
T, DOF = 64, 7
def chunk(r):
    joints = []
    for _ in range(DOF):
        x = np.zeros(T)
        for f in range(1, 5):
            a = r.gauss(); p = r.uniform(0, 2 * math.pi)
            x += a / f * np.sin(math.pi * f * np.arange(T) / T + p)
        for _ in range(3):
            t0 = r.int(T); s = r.gauss()
            for t in range(t0, T):
                x[t] += 0.08 * s * (1.0 if t - t0 < 2 else math.exp(-(t - t0 - 2) / 4.0))
        joints.append(x)
    return joints
data = [j for i in range(200) for j in chunk(Rng.derive(2025, i))]
X = np.array(data)
n = np.arange(T)
C = np.array([[math.sqrt((1 if k == 0 else 2) / T) * math.cos(math.pi / T * (t + 0.5) * k) for t in range(T)] for k in range(T)])
def rms(Y): return float(np.sqrt(((X - Y) ** 2).mean()))
def bins(b):
    step = 8.0 / (1 << b); return np.clip(np.round(X / step), -(1 << (b - 1)), (1 << (b - 1)) - 1) * step
check("E02 per-value bins, 8 bits", H["E02.bins_b8_rms"], rms(bins(8)), 1e-12)
def dstep(i): return (16.0 if i == 0 else 8.0) / 128.0
steps = np.array([dstep(i) for i in range(T)])
def dct_k(k, Z=X):
    c = Z @ C.T; c = np.round(c / steps) * steps; c[:, k:] = 0; return c @ C
check("E02 DCT, 8 coefficients", H["E02.dct_k8_rms"], rms(dct_k(8)), 1e-10)
def chars(Z, delta):
    sym = np.zeros(Z.shape, dtype=int); rec = np.zeros(Z.shape)
    for i in range(Z.shape[0]):
        prev = 0.0
        for t in range(T):
            c = int(min(max(round((Z[i, t] - prev) / delta), -7), 8)); prev += c * delta; rec[i, t] = prev; sym[i, t] = c
    return sym, rec
def entropy(sym):
    _, cnt = np.unique(sym, return_counts=True); p = cnt / cnt.sum(); return float(-(p * np.log2(p)).sum())
s08, r08 = chars(X, 0.08)
check("E02 motor characters, step 0.08", H["E02.chars_d0.08_rms"], rms(r08), 1e-10)
check("E02 character entropy, step 0.08", H["E02.chars_d0.08_entropy_bits_per_symbol"], entropy(s08), 1e-10)
coarse = dct_k(8); s02, r02 = chars(X - coarse, 0.02)
check("E02 coarse DCT-8 + residual characters, step 0.02", H["E02.split_d0.02_rms"], rms(coarse + r02), 1e-10)

# Study E03: bimodal trajectories, mean regression.
T3 = 16
def traj(r):
    u = r.double(); ga = r.gauss(); mode = 1 if u < 0.5 else -1; amp = 1 + 0.1 * ga
    return np.array([mode * amp * math.sin(math.pi * (t + 1) / (T3 + 1)) + 0.02 * r.gauss() for t in range(T3)])
train = np.array([traj(Rng.derive(1729, i)) for i in range(512)])
mean = train.mean(0)
shape = np.sin(math.pi * (np.arange(T3) + 1) / (T3 + 1))
proj = mean @ shape / (shape @ shape)
off = min(((mean - m * min(max(m * proj, 0.7), 1.3) * shape) ** 2).mean() for m in (1, -1)) ** 0.5
check("E03 mean regression off-manifold error, 512 trajectories", H["E03.n512_mean_regression_offmanifold"], off, 1e-10)
coll = float(any(abs(mean[t]) < 0.3 for t in range(5, 11)))
check("E03 mean regression collision, 512 trajectories", H["E03.n512_mean_regression_collision"], coll, 0)

with open(f"{OUT}/PY_crosscheck.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["quantity", "csharp", "python", "abs_difference", "agree"])
    for row in rows: w.writerow(row)
print(f"{sum(r[4] for r in rows)}/{len(rows)} agree")
for row in rows:
    if not row[4]: print("DISAGREE", row)
