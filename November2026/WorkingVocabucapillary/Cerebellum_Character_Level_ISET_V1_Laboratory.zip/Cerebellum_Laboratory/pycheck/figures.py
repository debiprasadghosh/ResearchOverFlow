"""Figures for the paper, drawn from the C# laboratory outputs (plotting only)."""
import csv, os
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

_ROOT = Path(__file__).resolve().parent.parent
OUT = os.environ.get("CE_OUT", str(_ROOT / "out")); FIG = os.environ.get("CE_FIGS", str(_ROOT / "figs"))
os.makedirs(FIG, exist_ok=True)
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, VIOLET = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6"
SER = [BLUE, ORANGE, AQUA, YELLOW, MAGENTA, VIOLET]
INK, INK2, MUTED, GRID = "#1f1f1f", "#52514e", "#8a8984", "#e4e3df"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9, "axes.edgecolor": MUTED,
    "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": GRID,
    "grid.linewidth": 0.6, "axes.axisbelow": True, "axes.spines.top": False, "axes.spines.right": False,
    "legend.frameon": False, "savefig.dpi": 220, "lines.linewidth": 2, "text.color": INK})
def rd(n): return list(csv.DictReader(open(f"{OUT}/{n}.csv")))
def save(f, n): f.savefig(f"{FIG}/{n}.png", bbox_inches="tight"); plt.close(f)

# Figure 1: the brain analogy.
fig, ax = plt.subplots(figsize=(6.6, 3.6)); ax.set_axis_off(); ax.set_xlim(0, 10); ax.set_ylim(0, 6)
def box(x, y, w, h, title, body, fc):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.1", fc=fc, ec=INK2, lw=1))
    ax.text(x + w / 2, y + h - 0.22, title, ha="center", va="top", fontsize=7.6, weight="bold", color=INK)
    ax.text(x + w / 2, y + h / 2 - 0.18, body, ha="center", va="center", fontsize=6.6, color=INK2)
box(3.0, 4.3, 4.0, 1.5, "Neocortex", "long-term Vocabucapillary banks\nnative and association vocabularies", "#eef4fc")
box(0.1, 4.3, 2.5, 1.5, "Prefrontal cortex", "harness cache, context\ngating, mature vs juvenile", "#f3effc")
box(7.4, 4.3, 2.5, 1.5, "Hippocampus", "working memory,\nnightly replay to banks", "#eef4fc")
box(3.6, 2.2, 2.8, 1.5, "Thalamus", "coefficient operator: drives\nand modulators, sleep pairing", "#fdf0ea")
box(0.1, 2.2, 2.5, 1.5, "Basal ganglia", "go / no-go margin gate\nover candidate reads", "#fdf0ea")
box(7.4, 2.2, 2.5, 1.5, "Amygdala", "ordered motif store for\nimportant short sequences", "#fdf0ea")
box(2.9, 0.1, 5.6, 1.6, "Cerebellum (this paper)", "character-level ISET: granule expansion of fine spans,\nPurkinje readout of corrections, climbing-fibre error", "#eaf7f1")
for (x1, y1, x2, y2) in [(5.0, 4.3, 5.0, 3.7), (2.6, 2.95, 3.6, 2.95), (6.4, 2.95, 7.4, 2.95), (2.6, 5.05, 3.0, 5.05), (7.0, 5.05, 7.4, 5.05), (5.0, 2.2, 5.0, 1.7)]:
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="<->", color=INK2, lw=0.9))
ax.annotate("", xy=(3.4, 1.7), xytext=(3.4, 4.3), arrowprops=dict(arrowstyle="<->", color=AQUA, lw=1.1, connectionstyle="arc3,rad=0.35"))
ax.text(1.3, 1.0, "pontine and thalamic\nloops with cortex", fontsize=6.4, color=AQUA, ha="center")
save(fig, "fig1_brain_map")

# Figure 2: expansion and resolution.
e = rd("E01_expansion")
fig, ax = plt.subplots(figsize=(5.4, 3.0))
for i, w in enumerate(["0.5", "1", "2"]):
    pts = sorted((int(r["granule_cells_M"]), float(r["test_rel_mse"])) for r in e if r["target_frequency"] == w and r["inputs_per_granule_K"] in ("4", "0"))
    lin = [p for p in pts if p[0] == 0][0][1]
    exp = [p for p in pts if p[0] > 0]
    ax.plot([p[0] for p in exp], [p[1] for p in exp], marker="o", ms=3.5, color=SER[i], label=f"target frequency {w}")
    ax.axhline(lin, color=SER[i], ls=":", lw=1.2)
ax.set_xscale("log", base=2); ax.set_xlabel("granule cells M (K = 4 inputs each)"); ax.set_ylabel("test error (relative MSE)")
ax.text(70, 1.02, "dotted: linear readout of the 8 mossy inputs", fontsize=7, color=INK2)
ax.set_ylim(0, 1.1); ax.legend(fontsize=7.4, loc="center left", bbox_to_anchor=(1.01, 0.5))
save(fig, "fig2_expansion")

# Figure 3: resolution against bits.
r3 = rd("E02_resolution")
fig, ax = plt.subplots(figsize=(5.6, 3.2))
for i, (rep, lab) in enumerate([("per-value bins", "per-value bins (token-like)"), ("DCT, 8-bit coefficients", "DCT coefficients (FAST-like)"),
                                ("motor characters, entropy-coded", "motor characters alone"), ("coarse DCT-8 + character residual", "coarse DCT plan + character residual")]):
    pts = sorted((float(r["bits_per_chunk"]), float(r["rms_error"])) for r in r3 if r["representation"] == rep)
    ls = "-" if i < 2 else "none"
    ax.plot([p[0] for p in pts], [p[1] for p in pts], marker="o", ms=4.5 if i >= 2 else 3.5, ls=ls, color=SER[i], label=lab)
ax.set_xscale("log"); ax.set_yscale("log"); ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter()); ax.set_xlabel("bits per one-second chunk (7 joints × 64 steps)"); ax.set_ylabel("RMS error")
ax.legend(fontsize=7.2, loc="center left", bbox_to_anchor=(1.01, 0.5))
save(fig, "fig3_resolution")

# Figure 4: bimodal actions.
m = rd("E03_multimodal")
rows = [r for r in m if r["training_trajectories"] == "4096"]
order = ["mean regression", "flow, S=1", "flow, S=2", "flow, S=4", "flow, S=8", "flow, S=32",
         "increment characters, order 4", "position characters, order 1", "position characters, order 4"]
lab = ["mean regression", "flow, 1 step", "flow, 2 steps", "flow, 4 steps", "flow, 8 steps", "flow, 32 steps",
       "increment chars, order 4", "position chars, order 1", "position chars, order 4"]
fig, axes = plt.subplots(1, 2, figsize=(6.6, 3.0), sharey=True)
col = [float(next(r["collision_rate"] for r in rows if r["method"] == o)) for o in order]
off = [float(next(r["off_manifold_rms"] for r in rows if r["method"] == o)) for o in order]
cols = [MUTED] + [BLUE] * 5 + [ORANGE] * 3
axes[0].barh(range(len(order)), col, color=cols, height=0.62); axes[0].set_title("collision rate"); axes[0].set_xlim(0, 1.05)
axes[1].barh(range(len(order)), off, color=cols, height=0.62); axes[1].set_title("distance from a valid path (RMS)")
axes[0].set_yticks(range(len(order))); axes[0].set_yticklabels(lab); axes[0].invert_yaxis()
fig.tight_layout()
save(fig, "fig4_multimodal")
print("figures written")
