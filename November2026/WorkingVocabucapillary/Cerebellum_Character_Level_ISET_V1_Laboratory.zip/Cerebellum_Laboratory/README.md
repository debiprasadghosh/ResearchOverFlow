# Cerebellum as a character-level ISET: laboratory (immutable C#)

Companion to *The Cerebellum as a Character-Level ISET: Fine-Resolution Vocabucapillary Memory for Physical AI* (Ghosh, 2026).

| Folder | Contents |
|---|---|
| `celab/` | .NET 8 console project, no packages. `Experiments/E00`–`E03`; `Program.cs` is the only code that writes files. |
| `out/` | CSV tables, `headlines.json`, `run_log.txt`, `PY_crosscheck.csv` (8 of 8 agree). |
| `pycheck/` | `crosscheck.py` (independent port of the generator and trajectories) and `figures.py`. |
| `paper/` | `build_paper.py` rebuilds the Word file from the outputs (needs pandoc); `docxfix.py` repairs pandoc's OOXML order quirks. |

```
cd celab && dotnet run -c Release          # all studies, about 6 minutes on two cores; writes ../out
cd ../pycheck && python3 crosscheck.py && python3 figures.py
cd ../paper && python3 build_paper.py
```

| Study | Question |
|---|---|
| E00 | Neuron budgets by region; bits and sequential calls per one-second action chunk |
| E01 | Does granule-cell expansion help learn fine corrections (by cell count, inputs per cell, resolution)? |
| E02 | Resolution per bit: per-value bins, DCT, motor characters, coarse DCT plan + character residual; ISET span storage cost |
| E03 | Two-way obstacle choice: mean regression, exact-velocity flow with S steps, increment and position character models |
