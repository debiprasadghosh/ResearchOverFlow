using CeLab.Core;

namespace CeLab.Experiments;

/// <summary>
/// Resolution against bits for joint trajectories with smooth motion and sharp contact corrections. Per-value bins,
/// DCT coefficients, closed-loop motor characters, a coarse DCT plan with a character-level residual (the proposed
/// cortex–cerebellum split), and the cost of storing motor-character spans as ISET-style codes.
/// </summary>
public static class E02_MotorCharacters
{
    private const ulong Seed = 2025;
    public const int T = 64, Dof = 7, Chunks = 200, Alphabet = 16;

    public static IReadOnlyList<IReadOnlyList<double>> Chunk(Rng rng)
    {
        var r = rng;
        var joints = new IReadOnlyList<double>[Dof];
        for (int j = 0; j < Dof; j++)
        {
            var x = new double[T];
            for (int f = 1; f <= 4; f++)
            {
                var (a, r1) = r.NextGaussian(); var (p, r2) = r1.NextUniform(0, 2 * Math.PI); r = r2;
                for (int t = 0; t < T; t++) x[t] += a / f * Math.Sin(Math.PI * f * t / T + p);
            }
            for (int e = 0; e < 3; e++)                                    // contact corrections: sharp steps with fast decay
            {
                var (t0, r1) = r.NextInt(T); var (s, r2) = r1.NextGaussian(); r = r2;
                for (int t = t0; t < T; t++) x[t] += 0.08 * s * (t - t0 < 2 ? 1.0 : Math.Exp(-(t - t0 - 2) / 4.0));
            }
            joints[j] = x;
        }
        return joints;
    }

    public static ExperimentResult Run()
    {
        var data = Enumerable.Range(0, Chunks).Select(i => Chunk(Rng.Derive(Seed, (ulong)i))).ToArray();
        double Rms(Func<IReadOnlyList<double>, IReadOnlyList<double>> codec) =>
            Math.Sqrt(data.SelectMany(c => c).AsParallel().Sum(x => { var y = codec(x); return x.Select((v, t) => (v - y[t]) * (v - y[t])).Sum(); }) / (Chunks * Dof * T));
        double signal = Math.Sqrt(data.SelectMany(c => c).SelectMany(x => x).Average(v => v * v));
        var rows = new List<object[]>();
        var h = new Dictionary<string, double> { ["signal_rms"] = signal };

        foreach (int b in new[] { 3, 4, 5, 6, 8, 10 })
        {
            double step = 8.0 / (1 << b);
            double e = Rms(x => x.Select(v => Math.Clamp(Math.Round(v / step), -(1 << (b - 1)), (1 << (b - 1)) - 1) * step).ToArray());
            rows.Add(new object[] { "per-value bins", $"{b} bits per value", T * Dof * b, e });
            h[$"bins_b{b}_rms"] = e;
        }
        foreach (int k in new[] { 4, 8, 16, 32, 64 })
        {
            double e = Rms(x => Idct(Dct(x).Select((c, i) => i < k ? Math.Round(c / DctStep(i)) * DctStep(i) : 0.0).ToArray()));
            rows.Add(new object[] { "DCT, 8-bit coefficients", $"{k} coefficients per joint", Dof * k * 8, e });
            h[$"dct_k{k}_rms"] = e;
        }
        foreach (double delta in new[] { 0.08, 0.04, 0.02, 0.01 })
        {
            var codes = data.SelectMany(c => c).Select(x => Characters(x, delta)).ToArray();
            double e = Math.Sqrt(data.SelectMany(c => c).Zip(codes).Sum(p => p.First.Select((v, t) => (v - p.Second.Recon[t]) * (v - p.Second.Recon[t])).Sum()) / (Chunks * Dof * T));
            double entropy = Entropy(codes.SelectMany(c => c.Symbols));
            rows.Add(new object[] { "motor characters, raw", $"step {delta}", T * Dof * 4, e });
            rows.Add(new object[] { "motor characters, entropy-coded", $"step {delta}", T * Dof * entropy, e });
            h[$"chars_d{delta}_rms"] = e;
            h[$"chars_d{delta}_entropy_bits_per_symbol"] = entropy;
        }
        // Coarse cortical plan (8 DCT coefficients) plus a character-level cerebellar residual.
        foreach (double delta in new[] { 0.04, 0.02, 0.01 })
        {
            var parts = data.SelectMany(c => c).Select(x =>
            {
                var coarse = Idct(Dct(x).Select((c, i) => i < 8 ? Math.Round(c / DctStep(i)) * DctStep(i) : 0.0).ToArray());
                var resid = x.Select((v, t) => v - coarse[t]).ToArray();
                var ch = Characters(resid, delta);
                return (x, recon: coarse.Select((v, t) => v + ch.Recon[t]).ToArray(), ch.Symbols);
            }).ToArray();
            double e = Math.Sqrt(parts.Sum(p => p.x.Select((v, t) => (v - p.recon[t]) * (v - p.recon[t])).Sum()) / (Chunks * Dof * T));
            double entropy = Entropy(parts.SelectMany(p => p.Symbols));
            rows.Add(new object[] { "coarse DCT-8 + character residual", $"step {delta}", Dof * 8 * 8 + T * Dof * entropy, e });
            h[$"split_d{delta}_rms"] = e;
            h[$"split_d{delta}_bits"] = Dof * 8 * 8 + T * Dof * entropy;
            h[$"split_d{delta}_entropy"] = entropy;
        }
        var table = Table.Of("resolution", new[] { "representation", "setting", "bits_per_chunk", "rms_error" }, rows);

        // ISET-style storage of motor-character spans: bits for code-only spelling.
        var coder = SpanCoder.Create(256, Seed);
        var book = AtomBook.Create(256, 512, Seed + 1);
        var spans = data.Take(40).SelectMany(c => c).SelectMany(x =>
        {
            var s = Characters(x, 0.02).Symbols;
            return Enumerable.Range(0, T / 8).Select(i => s.Skip(i * 8).Take(8).Select(v => 'a' + v + 7).ToArray());
        }).Select(a => (IReadOnlyList<int>)a).ToArray();
        var alphabet = Enumerable.Range('a', Alphabet).ToArray();
        var tableC = alphabet.Append(SpanCoder.Eos).ToDictionary(c => c, c => coder.Char(c));
        var srows = new List<object[]>();
        foreach (int s in new[] { 16, 32, 48, 64 })
        {
            var ok = spans.AsParallel().Select(sp =>
            {
                var code = book.Fit(coder.Order(sp), s, 8);
                var dec = coder.Decode(book.Reconstruct(code), alphabet, tableC);
                return dec.SequenceEqual(sp) ? 1.0 : 0.0;
            }).Average();
            int bits = s * (book.AtomBits + 8) + 16;
            srows.Add(new object[] { s, bits, ok, bits * (T / 8) * Dof, T * Dof * 4 });
            h[$"iset_s{s}_exact"] = ok;
            h[$"iset_s{s}_bits_per_span"] = bits;
        }
        var stab = Table.Of("iset_spans", new[] { "atoms_s", "bits_per_8_char_span", "exact_spelling", "code_only_bits_per_chunk", "raw_character_bits_per_chunk" }, srows);
        return new ExperimentResult("E02", "Motor characters and resolution", new[] { table, stab }, h);
    }

    public sealed record CharCode(IReadOnlyList<int> Symbols, IReadOnlyList<double> Recon);

    /// <summary>Closed-loop delta coding: each character quantizes the gap between the target and the running reconstruction.</summary>
    public static CharCode Characters(IReadOnlyList<double> x, double delta)
    {
        var sym = new int[x.Count]; var rec = new double[x.Count];
        double prev = 0;
        for (int t = 0; t < x.Count; t++)
        {
            int c = (int)Math.Clamp(Math.Round((x[t] - prev) / delta), -Alphabet / 2 + 1, Alphabet / 2);   // [-7, 8]
            prev += c * delta;
            rec[t] = prev;
            sym[t] = c;
        }
        return new CharCode(sym, rec);
    }

    public static double Entropy(IEnumerable<int> symbols)
    {
        var counts = symbols.GroupBy(s => s).Select(g => (double)g.Count()).ToArray();
        double n = counts.Sum();
        return -counts.Sum(c => c / n * Math.Log2(c / n));
    }

    public static double DctStep(int i) => (i == 0 ? 16.0 : 8.0) / 128.0;

    public static double[] Dct(IReadOnlyList<double> x)
    {
        int n = x.Count; var c = new double[n];
        for (int k = 0; k < n; k++)
        {
            double s = 0;
            for (int t = 0; t < n; t++) s += x[t] * Math.Cos(Math.PI / n * (t + 0.5) * k);
            c[k] = s * Math.Sqrt((k == 0 ? 1.0 : 2.0) / n);
        }
        return c;
    }

    public static double[] Idct(IReadOnlyList<double> c)
    {
        int n = c.Count; var x = new double[n];
        for (int t = 0; t < n; t++)
        {
            double s = 0;
            for (int k = 0; k < n; k++) s += c[k] * Math.Sqrt((k == 0 ? 1.0 : 2.0) / n) * Math.Cos(Math.PI / n * (t + 0.5) * k);
            x[t] = s;
        }
        return x;
    }
}
