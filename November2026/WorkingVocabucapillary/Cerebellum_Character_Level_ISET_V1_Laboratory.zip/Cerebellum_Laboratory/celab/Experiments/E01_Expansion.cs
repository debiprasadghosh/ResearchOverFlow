using CeLab.Core;

namespace CeLab.Experiments;

/// <summary>
/// Marr–Albus expansion: low-dimensional mossy-fibre input is expanded into many sparse granule-cell responses, and a
/// Purkinje readout learns a fine correction by a climbing-fibre delta rule. Test error is measured against expansion
/// size, granule in-degree K and the spatial frequency (resolution) of the target correction.
/// </summary>
public static class E01_Expansion
{
    private const ulong Seed = 1971;
    public const int N = 8, Features = 40, TrainN = 3000, TestN = 2000, Epochs = 25;
    public const double Coding = 0.1;

    public static ExperimentResult Run()
    {
        var rows = new List<object[]>();
        var h = new Dictionary<string, double>();
        var configs = new List<(double omega, int m, int k)>();
        foreach (double omega in new[] { 0.5, 1.0, 2.0 })
        {
            configs.Add((omega, 0, 0));
            foreach (int m in new[] { 64, 256, 1024 }) configs.Add((omega, m, 4));
            foreach (int k in new[] { 1, 2, 8 }) configs.Add((omega, 512, k));
            configs.Add((omega, 512, 4));
        }
        var results = configs.Select(c => (c, err: Trial(c.omega, c.m, c.k))).ToArray();
        foreach (var (c, err) in results)
        {
            rows.Add(new object[] { c.omega, c.m == 0 ? "linear on mossy input" : "granule expansion", c.m, c.k, err.Train, err.Test });
            h[$"w{c.omega:0.0}_M{c.m}_K{c.k}_test"] = err.Test;
        }
        var table = Table.Of("expansion", new[] { "target_frequency", "readout", "granule_cells_M", "inputs_per_granule_K", "train_rel_mse", "test_rel_mse" }, rows);
        return new ExperimentResult("E01", "Cerebellar expansion and fine corrections", new[] { table }, h);
    }

    public sealed record Errors(double Train, double Test);

    private static double[] Readout(IReadOnlyList<IReadOnlyList<double>> Fr, IReadOnlyList<double> Y)
    {
        var F = Fr.Select(r => r.ToArray()).ToArray();
        int n = F.Length, nFit = n * 9 / 10, d = F[0].Length;
        (double[,] A, double[] b) Gram(int from, int to)
        {
            var A = new double[d, d]; var b = new double[d];
            Enumerable.Range(0, d).AsParallel().ForAll(i =>
            {
                for (int j = 0; j <= i; j++)
                {
                    double s = 0;
                    for (int r = from; r < to; r++) s += F[r][i] * F[r][j];
                    A[i, j] = s; A[j, i] = s;
                }
                double sb = 0;
                for (int r = from; r < to; r++) sb += F[r][i] * Y[r];
                b[i] = sb;
            });
            return (A, b);
        }
        double[] Solve(double[,] A0, double[] b, double lam)
        {
            double tr = Enumerable.Range(0, d).Average(i => A0[i, i]);
            var L = new double[d, d];
            for (int i = 0; i < d; i++)
                for (int j = 0; j <= i; j++)
                {
                    double s = A0[i, j] + (i == j ? lam * tr : 0.0);
                    for (int k = 0; k < j; k++) s -= L[i, k] * L[j, k];
                    L[i, j] = i == j ? Math.Sqrt(Math.Max(s, 1e-300)) : s / L[j, j];
                }
            var y = new double[d];
            for (int i = 0; i < d; i++) { double s = b[i]; for (int k = 0; k < i; k++) s -= L[i, k] * y[k]; y[i] = s / L[i, i]; }
            var x = new double[d];
            for (int i = d - 1; i >= 0; i--) { double s = y[i]; for (int k = i + 1; k < d; k++) s -= L[k, i] * x[k]; x[i] = s / L[i, i]; }
            return x;
        }
        var (Af, bf) = Gram(0, nFit);
        var (Ar, br) = Gram(nFit, n);
        double best = double.PositiveInfinity, bestLam = 1e-3;
        foreach (double lam in new[] { 1e-6, 1e-4, 1e-3, 1e-2, 1e-1 })
        {
            var w = Solve(Af, bf, lam);
            double err = 0;
            for (int r = nFit; r < n; r++) { double p = 0; for (int j = 0; j < d; j++) p += w[j] * F[r][j]; err += (Y[r] - p) * (Y[r] - p); }
            if (err < best) { best = err; bestLam = lam; }
        }
        var Aall = new double[d, d]; var ball = new double[d];
        for (int i = 0; i < d; i++) { ball[i] = bf[i] + br[i]; for (int j = 0; j < d; j++) Aall[i, j] = Af[i, j] + Ar[i, j]; }
        return Solve(Aall, ball, bestLam);
    }

    private static Errors Trial(double omega, int m, int k)
    {
        var r = Rng.Derive(Seed, 1);
        // Target: a smooth random function whose spatial frequency scales with omega.
        var (wf, r1) = Lin.Gaussians(r, Features * N);
        var phases = new double[Features];
        var rr = r1;
        for (int i = 0; i < Features; i++) { var (u, nr) = rr.NextUniform(0, 2 * Math.PI); phases[i] = u; rr = nr; }
        double Target(IReadOnlyList<double> x)
        {
            double s = 0;
            for (int f = 0; f < Features; f++)
            {
                double d = 0;
                for (int j = 0; j < N; j++) d += wf[f * N + j] * x[j];
                s += Math.Cos(omega * d + phases[f]);
            }
            return s / Math.Sqrt(Features);
        }
        IReadOnlyList<double>[] Sample(int n, Rng g)
        {
            var xs = new IReadOnlyList<double>[n];
            var gg = g;
            for (int i = 0; i < n; i++)
            {
                var x = new double[N];
                for (int j = 0; j < N; j++) { var (u, ng) = gg.NextUniform(-1, 1); x[j] = u; gg = ng; }
                xs[i] = x;
            }
            return xs;
        }
        var train = Sample(TrainN, Rng.Derive(Seed, 2));
        var test = Sample(TestN, Rng.Derive(Seed, 3));
        var ytr = train.Select(Target).ToArray();
        var yte = test.Select(Target).ToArray();

        // Granule layer: each cell sums K random mossy inputs with Gaussian weights; threshold fixes the coding level.
        Func<IReadOnlyList<double>, IReadOnlyList<double>> features;
        if (m == 0) features = x => x.Append(1.0).ToArray();
        else
        {
            var g = Rng.Derive(Seed, (ulong)(100 + m * 10 + k));
            var idx = new int[m][]; var wts = new double[m][];
            for (int i = 0; i < m; i++)
            {
                idx[i] = new int[k]; wts[i] = new double[k];
                var chosen = new HashSet<int>();
                for (int j = 0; j < k; j++)
                {
                    int c; do { var (v, ng) = g.NextInt(N); c = v; g = ng; } while (chosen.Contains(c) && chosen.Count < N);
                    chosen.Add(c); idx[i][j] = c;
                    var (w, ng2) = g.NextGaussian(); wts[i][j] = w; g = ng2;
                }
            }
            var theta = Enumerable.Range(0, m).Select(i =>
            {
                var pre = train.Select(x => { double s = 0; for (int j = 0; j < k; j++) s += wts[i][j] * x[idx[i][j]]; return s; }).OrderBy(v => v).ToArray();
                return pre[(int)((1 - Coding) * (pre.Length - 1))];
            }).ToArray();
            features = x =>
            {
                var hcell = new double[m + 1];
                for (int i = 0; i < m; i++)
                {
                    double s = 0;
                    for (int j = 0; j < k; j++) s += wts[i][j] * x[idx[i][j]];
                    hcell[i] = Math.Max(0, s - theta[i]);
                }
                hcell[m] = 1.0;
                return hcell;
            };
        }
        var ftr = train.Select(features).ToArray();
        var fte = test.Select(features).ToArray();
        // Purkinje readout. The climbing-fibre delta rule converges to the least-squares readout; it is computed
        // directly here with a small ridge chosen on a held-out tenth of the training set.
        var w8 = Readout(ftr, ytr);
        double Rel(IReadOnlyList<IReadOnlyList<double>> F, IReadOnlyList<double> Y)
        {
            double num = 0, den = 0, mean = Y.Average();
            for (int i = 0; i < Y.Count; i++) { double p = Lin.Dot(w8, F[i]); num += (Y[i] - p) * (Y[i] - p); den += (Y[i] - mean) * (Y[i] - mean); }
            return num / den;
        }
        return new Errors(Rel(ftr, ytr), Rel(fte, yte));
    }
}
