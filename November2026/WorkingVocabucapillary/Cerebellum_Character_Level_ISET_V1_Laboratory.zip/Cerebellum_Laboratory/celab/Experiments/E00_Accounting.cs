using CeLab.Core;

namespace CeLab.Experiments;

/// <summary>Exact accounting: neuron budgets of brain regions and the cost of action representations per control chunk.</summary>
public static class E00_Accounting
{
    public static ExperimentResult Run()
    {
        // Azevedo et al. (2009): billions of neurons.
        var regions = new (string, double)[] { ("cerebral cortex", 16.34), ("cerebellum", 69.03), ("rest of brain", 0.69) };
        double total = regions.Sum(r => r.Item2);
        var brain = Table.Of("neurons", new[] { "region", "neurons_billion", "share" }, regions.Select(r => new object[] { r.Item1, r.Item2, r.Item2 / total }));

        // One control chunk: 1 s at 50 Hz for a 7-DoF arm (350 values).
        int hz = 50, dof = 7, values = hz * dof;
        var rows = new List<object[]>
        {
            new object[] { "per-value bins, 256 levels (autoregressive tokens)", values * 8, values, values, "sequential tokens" },
            new object[] { "DCT + quantization, 10 coefficients per joint, 8 bits", dof * 10 * 8, dof * 10, dof * 10, "sequential tokens (FAST-like, before BPE)" },
            new object[] { "flow matching, 10 integration steps", values * 16, 10, 10, "full-chunk network passes" },
            new object[] { "motor characters, 16-letter alphabet, pointer recall", values * 4, values / 8, 1, "one retrieval + local unrolling per 8-step span" },
        };
        var chunk = Table.Of("chunk", new[] { "representation", "bits_per_chunk", "symbols_or_steps", "sequential_network_calls", "notes" }, rows);
        var h = new Dictionary<string, double>
        {
            ["cerebellum_neuron_share"] = 69.03 / total,
            ["cortex_neuron_share"] = 16.34 / total,
            ["chunk_values"] = values,
            ["token_steps_per_second"] = values,
            ["flow_passes_per_chunk"] = 10,
        };
        return new ExperimentResult("E00", "Neuron budgets and action-chunk accounting", new[] { brain, chunk }, h);
    }
}
