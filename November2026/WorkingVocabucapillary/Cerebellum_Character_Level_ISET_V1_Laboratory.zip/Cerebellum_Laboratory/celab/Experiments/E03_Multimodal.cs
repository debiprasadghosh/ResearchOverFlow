using CeLab.Core;

namespace CeLab.Experiments;

/// <summary>
/// Passing an obstacle on the left or the right: a bimodal action distribution. Mean regression, an exact-velocity flow
/// sampler with S integration steps, and character-level autoregressive models of order o are compared on collisions,
/// off-manifold error (resolution), novelty and sequential network calls.
/// </summary>
public static class E03_Multimodal
{
    private const ulong Seed = 1729;
    public const int T = 16, Samples = 1000;
    public const double Delta = 0.1;
    public const int Half = 16;                                         // characters take values -15..16

    public sealed record Quality(double Collision, double OffManifold, double NearestTrain, int Calls);

    public static ExperimentResult Run()
    {
        var rows = new List<object[]>();
        var h = new Dictionary<string, double>();
        foreach (int n in new[] { 64, 512, 4096 })
        {
            var train = Enumerable.Range(0, n).Select(i => Trajectory(Rng.Derive(Seed, (ulong)i))).ToArray();
            double spacing = train.Take(200).Select((a, i) => train.Where((b, j) => j != i).Min(b => Dist(a, b))).Average();
            void Add(string method, Quality q)
            {
                rows.Add(new object[] { n, method, q.Collision, q.OffManifold, q.NearestTrain / spacing, q.Calls });
                string key = $"n{n}_{method.Replace(" ", "_").Replace(",", "").Replace("=", "")}";
                h[$"{key}_collision"] = q.Collision; h[$"{key}_offmanifold"] = q.OffManifold; h[$"{key}_novelty"] = q.NearestTrain / spacing;
            }
            Add("training data (reference)", Evaluate(train.Take(Samples).ToArray(), train.Skip(Samples).Concat(train.Take(0)).DefaultIfEmpty(train[0]).ToArray(), 0));
            var mean = Enumerable.Range(0, T).Select(t => train.Average(y => y[t])).ToArray();
            Add("mean regression", Evaluate(Enumerable.Repeat((IReadOnlyList<double>)mean, Samples).ToArray(), train, 1));
            foreach (int steps in new[] { 1, 2, 4, 8, 32 })
            {
                var samples = Enumerable.Range(0, Samples).AsParallel().AsOrdered().Select(i => Flow(train, steps, Rng.Derive(Seed, (ulong)(900000 + n * 100 + i * 7 + steps)))).ToArray();
                Add($"flow, S={steps}", Evaluate(samples, train, steps));
            }
            foreach (bool absolute in new[] { false, true })
            {
                var chars = train.Select(y => Encode(y, absolute)).ToArray();
                foreach (int order in new[] { 1, 2, 4 })
                {
                    var model = Fit(chars, order);
                    var samples = Enumerable.Range(0, Samples).Select(i => Decode(SampleChars(model, order, Rng.Derive(Seed, (ulong)(500000 + n * 10 + order * 100000 + i + (absolute ? 7_000_000 : 0)))), absolute)).ToArray();
                    Add($"{(absolute ? "position" : "increment")} characters, order {order}", Evaluate(samples, train, T));
                }
            }
            h[$"n{n}_spacing"] = spacing;
        }
        var table = Table.Of("multimodal", new[] { "training_trajectories", "method", "collision_rate", "off_manifold_rms", "nearest_train_over_spacing", "sequential_calls" }, rows);
        return new ExperimentResult("E03", "Bimodal actions: regression, flow and characters", new[] { table }, h);
    }

    public static IReadOnlyList<double> Trajectory(Rng rng)
    {
        var (u, r1) = rng.NextDouble();
        var (ga, r2) = r1.NextGaussian();
        double mode = u < 0.5 ? 1 : -1, amp = 1 + 0.1 * ga;
        var y = new double[T];
        var r = r2;
        for (int t = 0; t < T; t++) { var (g, nr) = r.NextGaussian(); r = nr; y[t] = mode * amp * Math.Sin(Math.PI * (t + 1) / (T + 1)) + 0.02 * g; }
        return y;
    }

    private static double Dist(IReadOnlyList<double> a, IReadOnlyList<double> b) => Math.Sqrt(a.Select((v, t) => (v - b[t]) * (v - b[t])).Sum());

    private static Quality Evaluate(IReadOnlyList<IReadOnlyList<double>> samples, IReadOnlyList<IReadOnlyList<double>> train, int calls)
    {
        var shape = Enumerable.Range(0, T).Select(t => Math.Sin(Math.PI * (t + 1) / (T + 1))).ToArray();
        double ss = shape.Sum(v => v * v);
        double collide = samples.Average(y => Enumerable.Range(5, 6).Any(t => Math.Abs(y[t]) < 0.3) ? 1.0 : 0.0);
        double off = Math.Sqrt(samples.Average(y =>
        {
            // Distance to the nearest valid trajectory: either mode, amplitude within the training range.
            double proj = Lin.Dot(y, shape) / ss;
            return new[] { 1.0, -1.0 }.Min(mode =>
            {
                double a = mode * Math.Clamp(mode * proj, 0.7, 1.3);
                return y.Select((v, t) => (v - a * shape[t]) * (v - a * shape[t])).Sum() / T;
            });
        }));
        double nearest = samples.Take(200).AsParallel().Average(y => train.Min(b => Dist(y, b)));
        return new Quality(collide, off, nearest, calls);
    }

    /// <summary>Euler integration of the exact marginal velocity of the linear noise-to-data path for the training set.</summary>
    private static IReadOnlyList<double> Flow(IReadOnlyList<IReadOnlyList<double>> train, int steps, Rng rng)
    {
        var (z, _) = Lin.Gaussians(rng, T);
        var x = z.ToArray();
        for (int k = 0; k < steps; k++)
        {
            double s = k / (double)steps, ds = 1.0 / steps, sig = Math.Max(1 - s, 1e-6);
            var logw = train.Select(y => { double d = 0; for (int t = 0; t < T; t++) { double e = x[t] - s * y[t]; d += e * e; } return -d / (2 * sig * sig); }).ToArray();
            double mx = logw.Max();
            var w = logw.Select(v => Math.Exp(v - mx)).ToArray();
            double sw = w.Sum();
            var v = new double[T];
            for (int i = 0; i < train.Count; i++)
            {
                if (w[i] == 0) continue;
                double c = w[i] / sw;
                for (int t = 0; t < T; t++) v[t] += c * (train[i][t] - x[t]) / sig;
            }
            for (int t = 0; t < T; t++) x[t] += ds * v[t];
        }
        return x;
    }

    /// <summary>Increment characters quantize the step from the running reconstruction; position characters quantize the value itself.</summary>
    private static IReadOnlyList<int> Encode(IReadOnlyList<double> y, bool absolute)
    {
        var s = new int[T]; double prev = 0;
        for (int t = 0; t < T; t++)
        {
            double target = absolute ? y[t] : y[t] - prev;
            int c = (int)Math.Clamp(Math.Round(target / Delta), -Half + 1, Half);
            s[t] = c; prev = absolute ? c * Delta : prev + c * Delta;
        }
        return s;
    }

    private static IReadOnlyList<double> Decode(IReadOnlyList<int> s, bool absolute)
    {
        var y = new double[T]; double prev = 0;
        for (int t = 0; t < T; t++) { prev = absolute ? s[t] * Delta : prev + s[t] * Delta; y[t] = prev; }
        return y;
    }

    /// <summary>Counts of the next character given position and up to `order` previous characters.</summary>
    private static IReadOnlyDictionary<string, IReadOnlyList<double>> Fit(IReadOnlyList<IReadOnlyList<int>> data, int order)
    {
        var counts = new Dictionary<string, double[]>();
        foreach (var s in data)
            for (int t = 0; t < T; t++)
                for (int o = 0; o <= Math.Min(order, t); o++)
                {
                    string key = Key(s, t, o);
                    if (!counts.TryGetValue(key, out var c)) counts[key] = c = new double[2 * Half];
                    c[s[t] + Half - 1] += 1;
                }
        return counts.ToDictionary(kv => kv.Key, kv => (IReadOnlyList<double>)kv.Value);
    }

    private static string Key(IReadOnlyList<int> s, int t, int o) => $"{t}|{o}|{string.Join(",", Enumerable.Range(t - o, o).Select(i => s[i]))}";

    private static IReadOnlyList<int> SampleChars(IReadOnlyDictionary<string, IReadOnlyList<double>> model, int order, Rng rng)
    {
        var s = new int[T]; var r = rng;
        for (int t = 0; t < T; t++)
        {
            IReadOnlyList<double>? c = null;
            for (int o = Math.Min(order, t); o >= 0 && c is null; o--)       // back off to shorter contexts when unseen
                if (model.TryGetValue(Key(s, t, o), out var cc)) c = cc;
            var (k, nr) = r.NextCategorical(c!.Select(v => v + 1e-3).ToArray()); r = nr;
            s[t] = k - Half + 1;
        }
        return s;
    }
}
