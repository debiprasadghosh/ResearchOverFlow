namespace CeLab.Core;

/// <summary>
/// An order-sensitive invertible span code standing in for ISET span vectors: v(s) = Σ_j P^j e(c_j) + P^len e(EOS),
/// with seeded character vectors e and a fixed random permutation P. The bag code drops the positions.
/// </summary>
public sealed record SpanCoder(int Width, ulong Seed, IReadOnlyList<IReadOnlyList<int>> Powers)
{
    public const int Eos = 0x110000;                                    // outside the Unicode range

    public static SpanCoder Create(int width, ulong seed)
    {
        var r = Rng.Derive(seed, 7);
        var perm = Enumerable.Range(0, width).ToArray();
        for (int i = width - 1; i > 0; i--) { var (j, nr) = r.NextInt(i + 1); r = nr; (perm[i], perm[j]) = (perm[j], perm[i]); }
        var powers = new List<IReadOnlyList<int>> { Enumerable.Range(0, width).ToArray() };
        for (int p = 1; p <= LogText.MaxSpan + 1; p++)
        {
            var prev = powers[^1];
            powers.Add(Enumerable.Range(0, width).Select(i => perm[prev[i]]).ToArray());
        }
        return new SpanCoder(width, seed, powers);
    }

    public IReadOnlyList<double> Char(int cp)
    {
        var (g, _) = Lin.Gaussians(Rng.Derive(Seed, 1000 + (ulong)cp), Width);
        double n = Math.Sqrt(Lin.Norm2(g));
        return g.Select(x => x / n).ToArray();
    }

    /// <summary>Applies P^j: output[Powers[j][i]] = x[i].</summary>
    public IReadOnlyList<double> Shift(IReadOnlyList<double> x, int j)
    {
        var y = new double[Width];
        var p = Powers[j];
        for (int i = 0; i < Width; i++) y[p[i]] = x[i];
        return y;
    }

    public IReadOnlyList<double> Unshift(IReadOnlyList<double> y, int j)
    {
        var x = new double[Width];
        var p = Powers[j];
        for (int i = 0; i < Width; i++) x[i] = y[p[i]];
        return x;
    }

    public IReadOnlyList<double> Order(IReadOnlyList<int> cps)
    {
        var v = new double[Width];
        for (int j = 0; j <= cps.Count; j++)
        {
            var s = Shift(Char(j < cps.Count ? cps[j] : Eos), j);
            for (int i = 0; i < Width; i++) v[i] += s[i];
        }
        return v;
    }

    public IReadOnlyList<double> Bag(IReadOnlyList<int> cps)
    {
        var v = new double[Width];
        foreach (int c in cps.Append(Eos)) { var e = Char(c); for (int i = 0; i < Width; i++) v[i] += e[i]; }
        return v;
    }

    /// <summary>Bag of adjacent pairs: one local recurrent step that sees order only within each pair.</summary>
    public IReadOnlyList<double> Bigram(IReadOnlyList<int> cps)
    {
        var v = new double[Width];
        var seq = cps.Append(Eos).ToArray();
        for (int j = 0; j + 1 < seq.Length; j++)
        {
            var a = Char(seq[j]); var b = Shift(Char(seq[j + 1]), 1);
            for (int i = 0; i < Width; i++) v[i] += a[i] + b[i] * 1.0 + a[i] * b[i] * Math.Sqrt(Width);
        }
        return v;
    }

    /// <summary>
    /// Code-only spelling recovery by successive unbinding: at position j, pick the alphabet symbol whose vector best
    /// matches P^-j v, subtract it, and stop at EOS or the length cap.
    /// </summary>
    public IReadOnlyList<int> Decode(IReadOnlyList<double> code, IReadOnlyList<int> alphabet, IReadOnlyDictionary<int, IReadOnlyList<double>> table)
    {
        var v = code.ToArray();
        var outp = new List<int>();
        for (int j = 0; j <= LogText.MaxSpan; j++)
        {
            var u = Unshift(v, j);
            int best = Eos; double bv = double.NegativeInfinity;
            foreach (int c in alphabet.Append(Eos))
            {
                double s = Lin.Dot(u, table[c]);
                if (s > bv) { bv = s; best = c; }
            }
            if (best == Eos) break;
            outp.Add(best);
            var sh = Shift(table[best], j);
            for (int i = 0; i < Width; i++) v[i] -= sh[i];
        }
        return outp;
    }
}

/// <summary>A sparse code over seeded atoms: atom IDs and quantized coefficients with one 16-bit scale.</summary>
public sealed record SparseCode(IReadOnlyList<int> Atoms, IReadOnlyList<double> Coefs)
{
    public int Bits(int atomBits, int coefBits) => Atoms.Count * (atomBits + coefBits) + 16;
}

public sealed record AtomBook(int Width, IReadOnlyList<IReadOnlyList<double>> Atoms)
{
    public int AtomBits => (int)Math.Ceiling(Math.Log2(Atoms.Count));

    public static AtomBook Create(int width, int count, ulong seed) => new(width, Enumerable.Range(0, count).Select(a =>
    {
        var (g, _) = Lin.Gaussians(Rng.Derive(seed, 50_000 + (ulong)a), width);
        double n = Math.Sqrt(Lin.Norm2(g));
        return (IReadOnlyList<double>)g.Select(x => x / n).ToArray();
    }).ToArray());

    /// <summary>Orthogonal matching pursuit with s atoms, then uniform quantization of the coefficients to q bits.</summary>
    public SparseCode Fit(IReadOnlyList<double> x, int s, int q)
    {
        var chosen = new List<int>();
        var resid = x.ToArray();
        double[] coef = Array.Empty<double>();
        for (int k = 0; k < s; k++)
        {
            int best = -1; double bv = -1;
            for (int a = 0; a < Atoms.Count; a++)
            {
                if (chosen.Contains(a)) continue;
                double c = Math.Abs(Lin.Dot(resid, Atoms[a]));
                if (c > bv) { bv = c; best = a; }
            }
            chosen.Add(best);
            coef = LeastSquares(chosen, x);
            for (int i = 0; i < Width; i++)
            {
                double s2 = x[i];
                for (int j = 0; j < chosen.Count; j++) s2 -= coef[j] * Atoms[chosen[j]][i];
                resid[i] = s2;
            }
        }
        double scale = coef.Max(Math.Abs);
        int levels = (1 << (q - 1)) - 1;
        var qc = coef.Select(c => scale == 0 ? 0 : Math.Round(c / scale * levels) * scale / levels).ToArray();
        return new SparseCode(chosen.ToArray(), qc);
    }

    public IReadOnlyList<double> Reconstruct(SparseCode c)
    {
        var v = new double[Width];
        for (int k = 0; k < c.Atoms.Count; k++) for (int i = 0; i < Width; i++) v[i] += c.Coefs[k] * Atoms[c.Atoms[k]][i];
        return v;
    }

    private double[] LeastSquares(IReadOnlyList<int> idx, IReadOnlyList<double> x)
    {
        int n = idx.Count;
        var A = new double[n, n]; var b = new double[n];
        for (int i = 0; i < n; i++)
        {
            b[i] = Lin.Dot(Atoms[idx[i]], x);
            for (int j = 0; j <= i; j++) { double d = Lin.Dot(Atoms[idx[i]], Atoms[idx[j]]); A[i, j] = d; A[j, i] = d; }
            A[i, i] += 1e-10;
        }
        // Cholesky solve
        var L = new double[n, n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j <= i; j++)
            {
                double s = A[i, j];
                for (int k = 0; k < j; k++) s -= L[i, k] * L[j, k];
                L[i, j] = i == j ? Math.Sqrt(Math.Max(s, 1e-300)) : s / L[j, j];
            }
        var y = new double[n];
        for (int i = 0; i < n; i++) { double s = b[i]; for (int k = 0; k < i; k++) s -= L[i, k] * y[k]; y[i] = s / L[i, i]; }
        var z = new double[n];
        for (int i = n - 1; i >= 0; i--) { double s = y[i]; for (int k = i + 1; k < n; k++) s -= L[k, i] * z[k]; z[i] = s / L[i, i]; }
        return z;
    }
}
