using System.Diagnostics;
using CeLab.Core;
using CeLab.Experiments;

// Composition root: schedules the studies and performs the only file writes.
var registry = new (string Id, Func<ExperimentResult> Run)[]
{
    ("E00", E00_Accounting.Run),
    ("E01", E01_Expansion.Run),
    ("E02", E02_MotorCharacters.Run),
    ("E03", E03_Multimodal.Run),
};
var selected = args.Length == 0 ? registry : registry.Where(r => args.Contains(r.Id)).ToArray();
string outDir = Environment.GetEnvironmentVariable("CE_OUT") ?? Path.Combine("..", "out");
var results = new List<ExperimentResult>();
foreach (var (id, run) in selected)
{
    var sw = Stopwatch.StartNew();
    var r = run();
    sw.Stop();
    results.Add(r);
    Console.WriteLine($"{id} {r.Title}: {sw.Elapsed.TotalSeconds:F1} s");
    foreach (var kv in r.Headlines) Console.WriteLine($"   {kv.Key} = {kv.Value:G6}");
}
Output.Write(outDir, results);
