# Vocabucapillary numerical laboratory (immutable C#)

Companion to *Vocabucapillary Memory for Cooperative AI*, second edition: Part V (Chapters 15–20) and Appendix D.
Every number, table and chart in Part V comes from the C# program in `vclab/`. Python is used only to
cross-check a subset of the results independently and to draw the figures from the CSV files.

## Contents

| Folder | What it holds |
|---|---|
| `vclab/` | .NET 8 console project with no external packages. `Core/` holds the generator, probability and statistics helpers and the result records; `Experiments/` holds one static class per study; `Program.cs` is the composition root and the only code that writes files. |
| `out/` | The outputs used in the book: 32 CSV tables, `headlines.json` (every headline number, keyed `Study.name`), `run_log.txt` (console log of the run) and `PY_crosscheck.csv`. |
| `pycheck/` | `crosscheck.py` (independent re-implementation), `figures.py` (charts drawn from the CSV files, no computation) and `diagrams.py` (the two schematic figures). |
| `figs/` | The 16 PNG figures embedded in Part V. |

## Requirements

- .NET 8 SDK (tested with 8.0.134). `vclab/nuget.config` clears all package sources, so restore works offline; the project needs no packages.
- For the cross-check and figures only: Python 3.10 or later with numpy and matplotlib (tested with Python 3.13, numpy 2.5 and matplotlib 3.11).

## Running

```
cd vclab
dotnet run -c Release                    # all 15 studies, about two minutes on one core; writes ../out
dotnet run -c Release -- A02 A08         # a subset
```

Results go to `../out` relative to `vclab/`; set `VCLAB_OUT` to write elsewhere. A subset run rewrites
`headlines.json` with only the studies it ran, so write subsets to a separate folder:

```
VCLAB_OUT=/tmp/subset dotnet run -c Release -- A02 A08                       # bash
$env:VCLAB_OUT="C:\temp\subset"; dotnet run -c Release -- A02 A08            # PowerShell
```

Then, from `pycheck/`:

```
python3 crosscheck.py      # writes ../out/PY_crosscheck.csv (29 comparisons)
python3 figures.py         # 14 charts into ../figs
python3 diagrams.py        # 2 schematics into ../figs
```

`crosscheck.py` accepts an output folder as its first argument; `figures.py` and `diagrams.py` honour
`VCLAB_OUT` and `VCLAB_FIGS`.

## Reproducibility check

On 24 November 2026 the project was rebuilt from this folder in a clean directory. All 33 C# outputs
(32 CSV files and `headlines.json`) were byte-identical to those in `out/`. The cross-check reproduced
`PY_crosscheck.csv` exactly, with 29 of 29 comparisons within tolerance, and the figure scripts reproduced
all 16 PNG files byte for byte. The studies took 112 s in total on one core; A11 (55 s), A03 (28 s) and
A06 (12 s) account for most of it.

Runs are deterministic on a given platform. Library functions such as `Math.Exp` and `Math.Log` can differ
in the last bit between operating systems or processors, so another platform may change trailing digits.

## Studies

| Study | Chapter | Question | Kind of result | Output files |
|---|---|---|---|---|
| A00 | 15 | Do the worked values of Chapters 3–13 recompute? | Exact | `A00_audit` |
| A01 | 17 | Does a nightly bank replace the KV record list? | Simulation | `A01_daily` |
| A02 | 16 | Is decoupled consolidation exact; which fusion; which importance? | Exact and Monte Carlo | `A02_policies`, `A02_position`, `A02_budget`, `A02_importance_corr`, `A02_skip` |
| A03 | 16 | When does middle-layer mixing identify the better direction? | Monte Carlo | `A03_grid`, `A03_detail` |
| A05 | 16, 20 | What do sleep and communication cost at scale? | Accounting | `A05_compute`, `A05_sleep_fraction`, `A05_crossover`, `A05_communication` |
| A06 | 17 | Can softmax participation cluster events before sleep? | Monte Carlo | `A06_ari` |
| A07 | 17 | What do NREM and REM each contribute; why is late sleep REM-heavy? | Simulation and closed form | `A07_conditions`, `A07_cycles` |
| A08 | 17 | How much does mispairing forward and backward codes cost? | Closed form and Monte Carlo | `A08_pairing` |
| A09 | 18 | Do driver and modulator coefficients need different algebras? | Monte Carlo and accounting | `A09_feedback`, `A09_accounting` |
| A10 | 18 | Do ordered motifs and a margin gate earn their place? | Monte Carlo | `A10_motifs`, `A10_gate` |
| A11 | 19 | Does a two-stage association vocabulary meet the counting bound? | Trained model | `A11_vq` |
| A12 | 19 | What does freezing native vocabularies preserve and cost? | Simulation | `A12_mature_series`, `A12_juvenile_movement`, `A12_gating` |
| A13 | 20 | When does retirement beat repair; how large can a team be? | Exact and simulation | `A13_retirement`, `A13_repair`, `A13_team` |
| A14 | 19 | Can weight-space conversion be verified without training? | Exact and Monte Carlo | `A14_affine`, `A14_attention` |
| A15 | 16 | Is directional asymmetry about information or computation? | Exact and Monte Carlo | `A15_mechanisms`, `A15_anm` |

The numbering has no A04; the fifteen studies above are the complete set used in the book.

## Figures

| File | Book figure | Source |
|---|---|---|
| `fig18_night_pipeline.png` | Figure 3 | Schematic (Chapter 16) |
| `fig04_position_profile.png` | Figure 4 | A02 |
| `fig05_shortcut_heatmaps.png` | Figure 5 | A03 |
| `fig06_replay_budget.png` | Figure 6 | A02 |
| `fig16_directional_asymmetry.png` | Figure 7 | A15 |
| `fig03_memory_systems.png` | Figure 8 | A01 |
| `fig07_event_clustering.png` | Figure 9 | A06 |
| `fig08_two_stage_sleep.png` | Figure 10 | A07 |
| `fig09_thalamic_pairing.png` | Figure 11 | A08 |
| `fig17_laminar_column.png` | Figure 12 | Schematic (Chapter 18) |
| `fig10_driver_modulator.png` | Figure 13 | A09 |
| `fig11_basal_ganglia_gate.png` | Figure 14 | A10 |
| `fig12_association_vocabulary.png` | Figure 15 | A11 |
| `fig13_maturation.png` | Figure 16 | A12 |
| `fig15_attention_kernel.png` | Figure 17 | A14 |
| `fig14_harness.png` | Figure 18 | A13 |

## Conventions

- Domain state is held in sealed records and read-only lists. Every update is a pure static function that
  returns a new value: a bank update returns a new bank, and an optimizer step returns new parameters
  together with a new optimizer state.
- `Rng` is a `readonly record struct` implementing SplitMix64. Each draw returns `(Value, Next)`, and each
  study derives its own stream with `Rng.Derive(seed, stream)`.
- Array buffers are created, filled and returned within one function and are exposed only as
  `IReadOnlyList<T>`.
- `Output.Write` in `Core/Results.cs` is the single side-effecting boundary.

## Adding a study

Add one static class with `public static ExperimentResult Run()` to `Experiments/` and one line to the
registry in `Program.cs`. State the seed and stream, return every number you report as a headline, and
include the rule the new one is expected to beat together with at least one setting in which it should
lose (Appendix D4 of the book).
