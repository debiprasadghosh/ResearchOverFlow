using VcLab.Core;

namespace VcLab.Experiments;

/// <summary>
/// (i) Ordered motif memory versus order-free pooled memory for life-saving short sequences.
/// (ii) A basal-ganglia-like gate that releases a prepared response early only when unread memory cannot change it.
/// </summary>
public static class A10_AmygdalaBasalGanglia
{
    public const ulong Seed = 20261201UL;
    private const int Types = 64, Motifs = 8, Length = 60, Gap = 4;

    private sealed record Episode(IReadOnlyList<int> Events, bool Harm);

    private static (Episode Ep, Rng Next) MakeEpisode(Rng rng, IReadOnlyList<(int A, int B)> motifs, IReadOnlyList<double> motifWeights)
    {
        var ev = new int[Length];
        for (int t = 0; t < Length; t++) { int x; (x, rng) = rng.NextInt(Types - 2 * Motifs); ev[t] = 2 * Motifs + x; }
        bool fwd, rev; (fwd, rng) = rng.NextBernoulli(0.3); (rev, rng) = rng.NextBernoulli(0.3);
        void Insert(bool ordered, ref Rng r)
        {
            int k; (k, r) = r.NextCategorical(motifWeights);
            int start; (start, r) = r.NextInt(Length - Gap - 1);
            int gap; (gap, r) = r.NextInt(Gap); gap += 1;
            ev[start] = ordered ? motifs[k].A : motifs[k].B;
            ev[start + gap] = ordered ? motifs[k].B : motifs[k].A;
        }
        if (fwd) Insert(true, ref rng);
        if (rev) Insert(false, ref rng);
        return (new Episode(ev, OrderedMatch(ev, motifs, Enumerable.Range(0, Motifs).ToHashSet()) >= 0), rng);
    }

    /// <summary>Time index of the first ordered match among the allowed motifs, or -1.</summary>
    private static int OrderedMatch(IReadOnlyList<int> ev, IReadOnlyList<(int A, int B)> motifs, ISet<int> allowed)
    {
        for (int t = 0; t < ev.Count; t++)
            for (int k = 0; k < motifs.Count; k++)
            {
                if (!allowed.Contains(k) || ev[t] != motifs[k].B) continue;
                for (int s = Math.Max(0, t - Gap); s < t; s++) if (ev[s] == motifs[k].A) return t;
            }
        return -1;
    }

    private static int UnorderedMatch(IReadOnlyList<int> ev, IReadOnlyList<(int A, int B)> motifs, ISet<int> allowed)
    {
        for (int t = 0; t < ev.Count; t++)
            for (int k = 0; k < motifs.Count; k++)
            {
                if (!allowed.Contains(k)) continue;
                bool isA = ev[t] == motifs[k].A, isB = ev[t] == motifs[k].B;
                if (!isA && !isB) continue;
                int other = isA ? motifs[k].B : motifs[k].A;
                for (int s = Math.Max(0, t - Gap); s < t; s++) if (ev[s] == other) return t;
            }
        return -1;
    }

    public static ExperimentResult Run()
    {
        var head = new Dictionary<string, double>();
        var motifs = Enumerable.Range(0, Motifs).Select(k => (A: 2 * k, B: 2 * k + 1)).ToArray();
        // Unequal motif frequencies so that a small store must prioritise.
        var weights = Enumerable.Range(0, Motifs).Select(k => 1.0 / (k + 1)).ToArray();
        var rng = Rng.Derive(Seed, 1);
        var train = new List<Episode>(); var test = new List<Episode>();
        for (int i = 0; i < 1000; i++) { Episode e; (e, rng) = MakeEpisode(rng, motifs, weights); train.Add(e); }
        for (int i = 0; i < 4000; i++) { Episode e; (e, rng) = MakeEpisode(rng, motifs, weights); test.Add(e); }

        // Salience-driven admission: count harms attributable to each ordered motif in training.
        var harmCount = new int[Motifs];
        foreach (var e in train.Where(e => e.Harm))
            for (int k = 0; k < Motifs; k++)
                if (OrderedMatch(e.Events, motifs, new HashSet<int> { k }) >= 0) harmCount[k]++;
        var bySalience = Enumerable.Range(0, Motifs).OrderByDescending(k => harmCount[k]).ThenBy(k => k).ToArray();
        // Pooled memory learns unordered pairs whose co-occurrence predicts harm above 0.3.
        var pooledAllowed = new HashSet<int>();
        for (int k = 0; k < Motifs; k++)
        {
            var co = train.Where(e => UnorderedMatch(e.Events, motifs, new HashSet<int> { k }) >= 0).ToArray();
            if (co.Length > 0 && co.Count(e => e.Harm) / (double)co.Length > 0.3) pooledAllowed.Add(k);
        }

        var rows = new List<IReadOnlyList<object>>();
        void Evaluate(string name, Func<IReadOnlyList<int>, int> detector, double bytes)
        {
            int harmful = 0, harmless = 0, hits = 0, fa = 0; double lead = 0;
            foreach (var e in test)
            {
                int t = detector(e.Events);
                if (e.Harm) { harmful++; if (t >= 0) { hits++; lead += Length - t; } }
                else { harmless++; if (t >= 0) fa++; }
            }
            rows.Add(new object[] { name, (double)hits / harmful, (double)fa / harmless, hits > 0 ? lead / hits : 0.0, bytes });
            string key = new string(name.Where(char.IsLetterOrDigit).ToArray());
            head[$"hit_{key}"] = (double)hits / harmful; head[$"fa_{key}"] = (double)fa / harmless; head[$"bytes_{key}"] = bytes;
        }
        Evaluate("Pooled order-free memory", ev => UnorderedMatch(ev, motifs, pooledAllowed), Types * Types * 4.0);
        foreach (var cap in new[] { 2, 4, 8 })
        {
            var allowed = bySalience.Take(cap).ToHashSet();
            Evaluate($"Ordered motif store, capacity {cap}", ev => OrderedMatch(ev, motifs, allowed), cap * 8.0);
        }
        Evaluate("Full event log", ev => OrderedMatch(ev, motifs, Enumerable.Range(0, Motifs).ToHashSet()), Length * 1.0 * 1000);

        // Basal ganglia gate.
        const int queries = 50000, actions = 4;
        const double gateMs = 2, fullMs = 20, amygMs = 1, emergencyRate = 0.02;
        var g = Rng.Derive(Seed, 2);
        var qs = new List<(int Truth, double[] Fast, double[] Bank, double E, bool Emergency)>();
        for (int i = 0; i < queries; i++)
        {
            int y; (y, g) = g.NextInt(actions);
            var fast = new double[actions]; var bank = new double[actions];
            double e; (e, g) = g.NextUniform(0.05, 0.6);
            for (int k = 0; k < actions; k++)
            {
                double z; (z, g) = g.NextGaussian();
                fast[k] = (k == y ? 1.0 : 0.0) + 0.6 * z;
                double u; (u, g) = g.NextDouble();
                bank[k] = e * ((k == y ? 0.6 : 0.0) + 0.4 * (2 * u - 1));
            }
            bool em; (em, g) = g.NextBernoulli(emergencyRate);
            qs.Add((y, fast, bank, e, em));
        }
        var gateRows = new List<IReadOnlyList<object>>();
        void Gate(string name, Func<double[], double, bool> release, bool amygdala)
        {
            int agree = 0, correct = 0, released = 0, normal = 0; double latency = 0, emLatency = 0; int emN = 0;
            foreach (var q in qs)
            {
                if (q.Emergency)
                {
                    emN++;
                    double l = amygdala ? amygMs : gateMs + fullMs;
                    emLatency += l; latency += l; correct++;
                    continue;
                }
                normal++;
                var full = q.Fast.Select((v, k) => v + q.Bank[k]).ToArray();
                int fullDecision = Prob.Argmax(full);
                bool rel = release(q.Fast, q.E);
                int decision = rel ? Prob.Argmax(q.Fast) : fullDecision;
                if (rel) released++;
                if (decision == fullDecision) agree++;
                if (decision == q.Truth) correct++;
                latency += (amygdala ? amygMs : 0) + gateMs + (rel ? 0 : fullMs);
            }
            gateRows.Add(new object[] { name, (double)agree / normal, (double)correct / queries, latency / queries, (double)released / normal, emLatency / emN });
            string key = new string(name.Where(char.IsLetterOrDigit).ToArray());
            head[$"agree_{key}"] = (double)agree / normal; head[$"latency_{key}"] = latency / queries; head[$"release_{key}"] = (double)released / normal;
            head[$"acc_{key}"] = (double)correct / queries; head[$"emlat_{key}"] = emLatency / emN;
        }
        Gate("Always read long-term memory", (_, _) => false, false);
        Gate("Margin gate (margin > 2E)", (f, e) => Prob.Margin(f) > 2 * e, true);
        foreach (var theta in new[] { 0.5, 0.7, 0.9 })
            Gate($"Confidence gate, p > {theta:F1}", (f, _) => Prob.Max(Prob.Softmax(f, 3.0)) > theta, true);

        return new ExperimentResult("A10", "Amygdala motif memory and basal ganglia gating",
            new[]
            {
                Table.Of("motifs", new[] { "memory", "hit_rate", "false_alarm_rate", "mean_lead_steps", "bytes" }, rows),
                Table.Of("gate", new[] { "policy", "agreement_with_full_read", "accuracy", "mean_latency_ms", "released_early", "emergency_latency_ms" }, gateRows)
            }, head);
    }
}
