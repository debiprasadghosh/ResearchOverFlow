using VcLab.Core;

namespace VcLab.Experiments;

/// <summary>
/// Separates information symmetry (exact) from computational asymmetry (model-class dependent),
/// and shows when directional asymmetry identifies a causal mechanism.
/// </summary>
public static class A15_DirectionalAsymmetry
{
    public const ulong Seed = 20261126UL;

    private static double[] Stationary(double[][] p)
    {
        int k = p.Length;
        var pi = Enumerable.Repeat(1.0 / k, k).ToArray();
        for (int it = 0; it < 20000; it++)
        {
            var nx = new double[k];
            for (int i = 0; i < k; i++) for (int j = 0; j < k; j++) nx[j] += pi[i] * p[i][j];
            double diff = 0; for (int j = 0; j < k; j++) diff += Math.Abs(nx[j] - pi[j]);
            pi = nx;
            if (diff < 1e-15) break;
        }
        return pi;
    }

    private static (double Forward, double Backward) ConditionalEntropies(double[][] p, double[] pi)
    {
        int k = p.Length;
        double hf = 0;
        for (int x = 0; x < k; x++) hf += pi[x] * Prob.EntropyBits(p[x]);
        double hb = 0;
        for (int y = 0; y < k; y++)
        {
            var post = new double[k];
            for (int x = 0; x < k; x++) post[x] = pi[x] * p[x][y];
            double py = post.Sum();
            if (py <= 0) continue;
            hb += py * Prob.EntropyBits(post.Select(v => v / py).ToArray());
        }
        return (hf, hb);
    }

    /// <summary>Best log loss (bits) of a single-valued predictor with uniform smoothing.</summary>
    private static (double Forward, double Backward) SingleValuedLoss(double[][] p, double[] pi)
    {
        int k = p.Length;
        double aF = 0;
        for (int x = 0; x < k; x++) aF += pi[x] * p[x].Max();
        double aB = 0;
        for (int y = 0; y < k; y++)
        {
            double best = 0; for (int x = 0; x < k; x++) best = Math.Max(best, pi[x] * p[x][y]);
            aB += best;
        }
        static double Loss(double a, int k) => -(a * Math.Log2(a) + (1 - a) * Math.Log2((1 - a) / (k - 1)));
        return (Loss(aF, k), Loss(aB, k));
    }

    private static double[] SolveLinear(double[,] a, double[] b)
    {
        int n = b.Length;
        var m = new double[n, n + 1];
        for (int i = 0; i < n; i++) { for (int j = 0; j < n; j++) m[i, j] = a[i, j]; m[i, n] = b[i]; }
        for (int c = 0; c < n; c++)
        {
            int piv = c; for (int r = c + 1; r < n; r++) if (Math.Abs(m[r, c]) > Math.Abs(m[piv, c])) piv = r;
            for (int j = 0; j <= n; j++) (m[c, j], m[piv, j]) = (m[piv, j], m[c, j]);
            for (int r = 0; r < n; r++)
            {
                if (r == c) continue;
                double f = m[r, c] / m[c, c];
                for (int j = c; j <= n; j++) m[r, j] -= f * m[c, j];
            }
        }
        return Enumerable.Range(0, n).Select(i => m[i, n] / m[i, i]).ToArray();
    }

    private static IReadOnlyList<double> PolyResiduals(IReadOnlyList<double> x, IReadOnlyList<double> y, int degree)
    {
        double mx = x.Average(), sx = Math.Sqrt(x.Sum(v => (v - mx) * (v - mx)) / x.Count);
        var z = x.Select(v => (v - mx) / sx).ToArray();
        int d = degree + 1;
        var ata = new double[d, d]; var aty = new double[d];
        for (int i = 0; i < z.Length; i++)
        {
            var row = Enumerable.Range(0, d).Select(p => Math.Pow(z[i], p)).ToArray();
            for (int a = 0; a < d; a++) { aty[a] += row[a] * y[i]; for (int b = 0; b < d; b++) ata[a, b] += row[a] * row[b]; }
        }
        var coef = SolveLinear(ata, aty);
        return z.Select((v, i) => y[i] - Enumerable.Range(0, d).Sum(p => coef[p] * Math.Pow(v, p))).ToArray();
    }

    private static double[,] CenteredGaussianKernel(IReadOnlyList<double> x)
    {
        int n = x.Count;
        var dists = new List<double>();
        for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++) dists.Add(Math.Abs(x[i] - x[j]));
        dists.Sort();
        double sigma = Math.Max(dists[dists.Count / 2], 1e-9);
        var k = new double[n, n];
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) k[i, j] = Math.Exp(-(x[i] - x[j]) * (x[i] - x[j]) / (2 * sigma * sigma));
        var rowMean = new double[n]; double all = 0;
        for (int i = 0; i < n; i++) { for (int j = 0; j < n; j++) rowMean[i] += k[i, j]; all += rowMean[i]; rowMean[i] /= n; }
        all /= (double)n * n;
        var c = new double[n, n];
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) c[i, j] = k[i, j] - rowMean[i] - rowMean[j] + all;
        return c;
    }

    private static double Hsic(double[,] kc, double[,] lc, IReadOnlyList<int> perm)
    {
        int n = perm.Count; double s = 0;
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) s += kc[i, j] * lc[perm[i], perm[j]];
        return s / ((double)n * n);
    }

    private static (double Stat, double P) HsicTest(IReadOnlyList<double> a, IReadOnlyList<double> b, int perms, Rng rng)
    {
        var ka = CenteredGaussianKernel(a); var kb = CenteredGaussianKernel(b);
        int n = a.Count;
        var id = Enumerable.Range(0, n).ToArray();
        double stat = Hsic(ka, kb, id);
        int exceed = 0;
        for (int p = 0; p < perms; p++)
        {
            var perm = id.ToArray();
            for (int i = n - 1; i > 0; i--) { int j; (j, rng) = rng.NextInt(i + 1); (perm[i], perm[j]) = (perm[j], perm[i]); }
            if (Hsic(ka, kb, perm) >= stat) exceed++;
        }
        return (stat, (exceed + 1.0) / (perms + 1.0));
    }

    public static ExperimentResult Run()
    {
        var head = new Dictionary<string, double>();
        var rng = Rng.Derive(Seed, 1);

        // Part 1: random stationary chain, exact symmetry of conditional entropies.
        const int k8 = 8;
        var p8 = new double[k8][];
        for (int i = 0; i < k8; i++) { IReadOnlyList<double> row; (row, rng) = rng.NextDirichlet(k8, 0.7); p8[i] = row.ToArray(); }
        var pi8 = Stationary(p8);
        var (hf8, hb8) = ConditionalEntropies(p8, pi8);
        head["random_chain_H_forward"] = hf8; head["random_chain_H_backward"] = hb8; head["random_chain_abs_diff"] = Math.Abs(hf8 - hb8);

        // Part 2: many-to-one mechanisms with noise; single-valued predictors.
        const int k = 16; const double eps = 0.1;
        var mechRows = new List<IReadOnlyList<object>>();
        foreach (var image in new[] { 16, 12, 8, 6, 4, 2 })
        {
            var g = new int[k];
            var perm = Enumerable.Range(0, k).ToArray();
            for (int i = k - 1; i > 0; i--) { int j; (j, rng) = rng.NextInt(i + 1); (perm[i], perm[j]) = (perm[j], perm[i]); }
            for (int i = 0; i < k; i++)
            {
                if (i < image) g[perm[i]] = i;
                else { int t; (t, rng) = rng.NextInt(image); g[perm[i]] = t; }
            }
            var p = new double[k][];
            for (int x = 0; x < k; x++) { p[x] = Enumerable.Repeat(eps / k, k).ToArray(); p[x][g[x]] += 1 - eps; }
            var pi = Stationary(p);
            var (hf, hb) = ConditionalEntropies(p, pi);
            var (lf, lb) = SingleValuedLoss(p, pi);
            mechRows.Add(new object[] { image, hf, hb, hf - hb, lf, lb, lb - lf });
            head[$"image{image}_exact_diff"] = hf - hb;
            head[$"image{image}_restricted_asym"] = lb - lf;
        }

        // Part 3: additive-noise identifiability with HSIC on regression residuals.
        const int n = 400; const int perms = 200;
        var anmRows = new List<IReadOnlyList<object>>();
        foreach (var model in new[] { "Nonlinear, uniform noise", "Linear, Gaussian noise" })
        {
            var x = new double[n]; var y = new double[n];
            for (int i = 0; i < n; i++)
            {
                if (model.StartsWith("Nonlinear"))
                {
                    (x[i], rng) = rng.NextUniform(-2, 2);
                    double e; (e, rng) = rng.NextUniform(-0.6, 0.6);
                    y[i] = x[i] + 0.35 * x[i] * x[i] * x[i] + e;
                }
                else
                {
                    (x[i], rng) = rng.NextGaussian();
                    double e; (e, rng) = rng.NextGaussian();
                    y[i] = 0.8 * x[i] + 0.6 * e;
                }
            }
            var resF = PolyResiduals(x, y, 3);
            var resB = PolyResiduals(y, x, 3);
            var (sF, pF) = HsicTest(x, resF, perms, Rng.Derive(Seed, 50));
            var (sB, pB) = HsicTest(y, resB, perms, Rng.Derive(Seed, 51));
            anmRows.Add(new object[] { model, sF, pF, sB, pB });
            string key = model.StartsWith("Nonlinear") ? "anm" : "lingauss";
            head[$"{key}_hsic_f"] = sF; head[$"{key}_p_f"] = pF; head[$"{key}_hsic_b"] = sB; head[$"{key}_p_b"] = pB;
        }

        return new ExperimentResult("A15", "Information symmetry and computational asymmetry",
            new[]
            {
                Table.Of("mechanisms", new[] { "image_size", "H_forward", "H_backward", "exact_difference", "restricted_forward_loss", "restricted_backward_loss", "restricted_asymmetry" }, mechRows),
                Table.Of("anm", new[] { "model", "hsic_forward", "p_forward", "hsic_backward", "p_backward" }, anmRows)
            }, head);
    }
}
