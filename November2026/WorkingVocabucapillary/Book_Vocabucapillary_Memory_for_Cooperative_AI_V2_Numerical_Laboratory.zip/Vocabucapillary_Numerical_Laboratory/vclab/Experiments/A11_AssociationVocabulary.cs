using VcLab.Core;

namespace VcLab.Experiments;

/// <summary>
/// Two-stage learning of an association vocabulary (Chapter 3): stage one trains a continuous relation
/// encoder by backpropagation; stage two installs a finite vocabulary with straight-through vector
/// quantization (Eqs. 3.1-3.2). The counting bound of Appendix A1 predicts the accuracy ceiling.
/// </summary>
public static class A11_AssociationVocabulary
{
    public const ulong Seed = 20261202UL;
    private const int Tok = 16, In = 3 * Tok, Hid = 64, Z = 8;
    private static readonly int[] HeadSizes = { 2, 4, 2 };

    public sealed record Example(int V, int A, int T, IReadOnlyList<int> Answers, int AnswerId);

    /// <summary>Immutable parameter set; arrays are never modified after construction.</summary>
    public sealed record Mlp(IReadOnlyList<double> W1, IReadOnlyList<double> B1, IReadOnlyList<double> W2, IReadOnlyList<double> B2,
        IReadOnlyList<IReadOnlyList<double>> Wh, IReadOnlyList<IReadOnlyList<double>> Bh)
    {
        public IEnumerable<IReadOnlyList<double>> All() => new[] { W1, B1, W2, B2 }.Concat(Wh).Concat(Bh);

        public static Mlp FromAll(IReadOnlyList<IReadOnlyList<double>> a) =>
            new(a[0], a[1], a[2], a[3], a.Skip(4).Take(3).ToArray(), a.Skip(7).Take(3).ToArray());
    }

    public sealed record Adam(IReadOnlyList<IReadOnlyList<double>> M, IReadOnlyList<IReadOnlyList<double>> V, int Step);

    public static IReadOnlyList<Example> AllExamples()
    {
        var list = new List<Example>();
        for (int v = 0; v < Tok; v++)
            for (int a = 0; a < Tok; a++)
                for (int t = 0; t < Tok; t++)
                {
                    int same = (v / 4 == a / 4 && a / 4 == t / 4) ? 1 : 0;
                    int anomaly = a % 4;
                    int severity = (v % 4) + (t % 4) >= 4 ? 1 : 0;
                    list.Add(new Example(v, a, t, new[] { same, anomaly, severity }, same * 8 + anomaly * 2 + severity));
                }
        return list;
    }

    private static (IReadOnlyList<double> Values, Rng Next) RandomArray(int n, double scale, Rng rng)
    {
        var a = new double[n];
        for (int i = 0; i < n; i++) { double z; (z, rng) = rng.NextGaussian(); a[i] = scale * z; }
        return (a, rng);
    }

    public static (Mlp Net, Rng Next) Init(Rng rng)
    {
        IReadOnlyList<double> w1, w2; (w1, rng) = RandomArray(Hid * In, Math.Sqrt(2.0 / 3.0), rng);
        (w2, rng) = RandomArray(Z * Hid, Math.Sqrt(1.0 / Hid), rng);
        var wh = new IReadOnlyList<double>[3];
        for (int h = 0; h < 3; h++) (wh[h], rng) = RandomArray(HeadSizes[h] * Z, Math.Sqrt(1.0 / Z), rng);
        return (new Mlp(w1, new double[Hid], w2, new double[Z], wh, HeadSizes.Select(s => (IReadOnlyList<double>)new double[s]).ToArray()), rng);
    }

    public static (double[] Pre, double[] H, double[] Zv) Encode(Mlp n, Example e)
    {
        var pre = new double[Hid]; var h = new double[Hid]; var z = new double[Z];
        for (int i = 0; i < Hid; i++)
        {
            pre[i] = n.B1[i] + n.W1[i * In + e.V] + n.W1[i * In + Tok + e.A] + n.W1[i * In + 2 * Tok + e.T];
            h[i] = Math.Max(0, pre[i]);
        }
        for (int j = 0; j < Z; j++) { double s = n.B2[j]; for (int i = 0; i < Hid; i++) s += n.W2[j * Hid + i] * h[i]; z[j] = s; }
        return (pre, h, z);
    }

    public static IReadOnlyList<IReadOnlyList<double>> Heads(Mlp n, IReadOnlyList<double> z) =>
        Enumerable.Range(0, 3).Select(hd =>
        {
            var logits = new double[HeadSizes[hd]];
            for (int c = 0; c < HeadSizes[hd]; c++) { double s = n.Bh[hd][c]; for (int j = 0; j < Z; j++) s += n.Wh[hd][c * Z + j] * z[j]; logits[c] = s; }
            return Prob.Softmax(logits);
        }).ToArray();

    private static int NearestCode(IReadOnlyList<double> z, IReadOnlyList<IReadOnlyList<double>> codes)
    {
        int best = 0; double bd = double.PositiveInfinity;
        for (int c = 0; c < codes.Count; c++) { double d = 0; for (int j = 0; j < Z; j++) { double t = z[j] - codes[c][j]; d += t * t; } if (d < bd) { bd = d; best = c; } }
        return best;
    }

    /// <summary>One gradient computation over a batch; codes == null means stage one (continuous).</summary>
    private static (IReadOnlyList<IReadOnlyList<double>> Grads, IReadOnlyList<IReadOnlyList<double>>? CodeGrads, double Loss) Gradients(
        Mlp n, IReadOnlyList<Example> batch, IReadOnlyList<IReadOnlyList<double>>? codes, double beta)
    {
        var g = n.All().Select(a => new double[a.Count]).ToArray();
        var cg = codes?.Select(c => new double[Z]).ToArray();
        double loss = 0; double inv = 1.0 / batch.Count;
        foreach (var e in batch)
        {
            var (pre, h, z) = Encode(n, e);
            int code = codes is null ? -1 : NearestCode(z, codes);
            IReadOnlyList<double> zq = codes is null ? z : codes[code];
            var probs = Heads(n, zq);
            var dzq = new double[Z];
            for (int hd = 0; hd < 3; hd++)
            {
                int y = e.Answers[hd];
                loss -= Math.Log(Math.Max(probs[hd][y], 1e-12)) * inv;
                for (int c = 0; c < HeadSizes[hd]; c++)
                {
                    double d = (probs[hd][c] - (c == y ? 1 : 0)) * inv;
                    g[7 + hd][c] += d;
                    for (int j = 0; j < Z; j++) { g[4 + hd][c * Z + j] += d * zq[j]; dzq[j] += d * n.Wh[hd][c * Z + j]; }
                }
            }
            var dz = dzq.ToArray();
            if (codes is not null)
            {
                for (int j = 0; j < Z; j++)
                {
                    double diff = z[j] - codes[code][j];
                    loss += (1 + beta) * diff * diff * inv;
                    dz[j] += 2 * beta * diff * inv;          // commitment term
                    cg![code][j] += -2 * diff * inv;         // dictionary term pulls the atom toward z
                }
            }
            var dh = new double[Hid];
            for (int j = 0; j < Z; j++)
            {
                g[3][j] += dz[j];
                for (int i = 0; i < Hid; i++) { g[2][j * Hid + i] += dz[j] * h[i]; dh[i] += dz[j] * n.W2[j * Hid + i]; }
            }
            for (int i = 0; i < Hid; i++)
            {
                if (pre[i] <= 0) continue;
                g[1][i] += dh[i];
                g[0][i * In + e.V] += dh[i]; g[0][i * In + Tok + e.A] += dh[i]; g[0][i * In + 2 * Tok + e.T] += dh[i];
            }
        }
        return (g, cg, loss);
    }

    private static (IReadOnlyList<IReadOnlyList<double>> Params, Adam State) AdamStep(IReadOnlyList<IReadOnlyList<double>> p,
        IReadOnlyList<IReadOnlyList<double>> grad, Adam s, double lr)
    {
        const double b1 = 0.9, b2 = 0.999, eps = 1e-8;
        int t = s.Step + 1;
        var np = new IReadOnlyList<double>[p.Count]; var nm = new IReadOnlyList<double>[p.Count]; var nv = new IReadOnlyList<double>[p.Count];
        for (int k = 0; k < p.Count; k++)
        {
            var a = new double[p[k].Count]; var m = new double[p[k].Count]; var v = new double[p[k].Count];
            for (int i = 0; i < a.Length; i++)
            {
                m[i] = b1 * s.M[k][i] + (1 - b1) * grad[k][i];
                v[i] = b2 * s.V[k][i] + (1 - b2) * grad[k][i] * grad[k][i];
                double mh = m[i] / (1 - Math.Pow(b1, t)), vh = v[i] / (1 - Math.Pow(b2, t));
                a[i] = p[k][i] - lr * mh / (Math.Sqrt(vh) + eps);
            }
            np[k] = a; nm[k] = m; nv[k] = v;
        }
        return (np, new Adam(nm, nv, t));
    }

    private static Adam Zeros(IEnumerable<IReadOnlyList<double>> p)
    {
        var shapes = p.Select(a => (IReadOnlyList<double>)new double[a.Count]).ToArray();
        return new Adam(shapes, shapes.Select(a => (IReadOnlyList<double>)new double[a.Count]).ToArray(), 0);
    }

    private static (IReadOnlyList<Example> Batch, Rng Next) Sample(IReadOnlyList<Example> data, int size, Rng rng)
    {
        var b = new Example[size];
        for (int i = 0; i < size; i++) { int j; (j, rng) = rng.NextInt(data.Count); b[i] = data[j]; }
        return (b, rng);
    }

    public static double ExactAccuracy(Mlp n, IReadOnlyList<Example> data, IReadOnlyList<IReadOnlyList<double>>? codes) =>
        data.Average(e =>
        {
            var z = Encode(n, e).Zv;
            IReadOnlyList<double> zq = codes is null ? z : codes[NearestCode(z, codes)];
            var p = Heads(n, zq);
            return Enumerable.Range(0, 3).All(h => Prob.Argmax(p[h]) == e.Answers[h]) ? 1.0 : 0.0;
        });

    private static IReadOnlyList<IReadOnlyList<double>> KMeansInit(IReadOnlyList<IReadOnlyList<double>> zs, int m, Rng rng)
    {
        static double D2(IReadOnlyList<double> a, IReadOnlyList<double> b) { double s = 0; for (int i = 0; i < a.Count; i++) { double t = a[i] - b[i]; s += t * t; } return s; }
        var centers = new List<IReadOnlyList<double>>();
        int first; (first, rng) = rng.NextInt(zs.Count); centers.Add(zs[first]);
        while (centers.Count < m)
        {
            var w = zs.Select(z => centers.Min(c => D2(z, c))).ToArray();
            int pick; (pick, rng) = rng.NextCategorical(w); centers.Add(zs[pick]);
        }
        for (int it = 0; it < 30; it++)
        {
            var sums = Enumerable.Range(0, m).Select(_ => new double[Z]).ToArray(); var counts = new int[m];
            foreach (var z in zs)
            {
                int c = NearestCode(z, centers); counts[c]++;
                for (int j = 0; j < Z; j++) sums[c][j] += z[j];
            }
            centers = Enumerable.Range(0, m).Select(c => counts[c] > 0 ? (IReadOnlyList<double>)sums[c].Select(v => v / counts[c]).ToArray() : centers[c]).ToList();
        }
        return centers;
    }

    public static ExperimentResult Run()
    {
        var rng = Rng.Derive(Seed, 1);
        var all = AllExamples();
        var order = Enumerable.Range(0, all.Count).ToArray();
        for (int i = order.Length - 1; i > 0; i--) { int j; (j, rng) = rng.NextInt(i + 1); (order[i], order[j]) = (order[j], order[i]); }
        var train = order.Take(3072).Select(i => all[i]).ToArray();
        var test = order.Skip(3072).Select(i => all[i]).ToArray();

        // Stage one: continuous relation vectors.
        Mlp net; (net, rng) = Init(rng);
        var adam = Zeros(net.All());
        for (int step = 0; step < 2500; step++)
        {
            IReadOnlyList<Example> batch; (batch, rng) = Sample(train, 256, rng);
            var (g, _, _) = Gradients(net, batch, null, 0);
            IReadOnlyList<IReadOnlyList<double>> p; (p, adam) = AdamStep(net.All().ToArray(), g, adam, 0.01);
            net = Mlp.FromAll(p);
        }
        double stage1Train = ExactAccuracy(net, train, null), stage1Test = ExactAccuracy(net, test, null);

        // Answer-vector frequencies on the test set give the counting-bound ceiling for M codes.
        var freq = test.GroupBy(e => e.AnswerId).Select(g => g.Count() / (double)test.Length).OrderByDescending(x => x).ToArray();
        int distinct = freq.Length;

        var rows = new List<IReadOnlyList<object>>();
        var head = new Dictionary<string, double> { ["stage1_train"] = stage1Train, ["stage1_test"] = stage1Test, ["distinct_answer_vectors"] = distinct };
        foreach (var m in new[] { 2, 4, 8, 12, 16, 24, 32 })
        {
            var stage = net;
            var zs = train.Select(e => (IReadOnlyList<double>)Encode(stage, e).Zv).ToArray();
            var codes = KMeansInit(zs, m, Rng.Derive(Seed, 100 + (ulong)m));
            double initAcc = ExactAccuracy(stage, test, codes);
            var a2 = Zeros(stage.All());
            var codeAdam = Zeros(codes);
            var r2 = Rng.Derive(Seed, 200 + (ulong)m);
            for (int step = 0; step < 2500; step++)
            {
                IReadOnlyList<Example> batch; (batch, r2) = Sample(train, 256, r2);
                var (g, cg, _) = Gradients(stage, batch, codes, 0.25);
                IReadOnlyList<IReadOnlyList<double>> p; (p, a2) = AdamStep(stage.All().ToArray(), g, a2, 0.005);
                stage = Mlp.FromAll(p);
                (codes, codeAdam) = AdamStep(codes, cg!, codeAdam, 0.005);
                if (step % 300 == 299)
                {
                    // Re-seed unused atoms at encoder outputs (split/merge maintenance before addresses become durable).
                    var used = new HashSet<int>(train.Select(e => NearestCode(Encode(stage, e).Zv, codes)));
                    var fresh = codes.ToArray();
                    for (int c = 0; c < m; c++)
                        if (!used.Contains(c)) { int j; (j, r2) = r2.NextInt(train.Length); fresh[c] = Encode(stage, train[j]).Zv; }
                    codes = fresh;
                }
            }
            double acc = ExactAccuracy(stage, test, codes);
            int usedCodes = new HashSet<int>(test.Select(e => NearestCode(Encode(stage, e).Zv, codes))).Count;
            double ceiling = freq.Take(Math.Min(m, distinct)).Sum();
            rows.Add(new object[] { m, initAcc, acc, ceiling, usedCodes });
            head[$"vq_M{m}"] = acc; head[$"ceiling_M{m}"] = ceiling; head[$"init_M{m}"] = initAcc;
        }

        // Bits accounting: toy and deployment-scale illustrations of Eq. 3.3.
        double tupleBits = 3 * 8 * (16 + 8), assocBits = 16, side = 32;
        double dict = 65536.0 * 256 * 16;
        double breakEven = Math.Floor(dict / (tupleBits - assocBits - side)) + 1;
        head["tuple_bits"] = tupleBits; head["assoc_bits_with_side"] = assocBits + side; head["break_even_occurrences"] = breakEven;
        head["toy_tuple_bits"] = 12; head["toy_assoc_bits_M16"] = 4;

        return new ExperimentResult("A11", "Two-stage association vocabulary",
            new[] { Table.Of("vq", new[] { "codebook_M", "kmeans_init_accuracy", "finetuned_accuracy", "counting_ceiling", "codes_used" }, rows) }, head);
    }
}
