using VcLab.Core;

namespace VcLab.Experiments;

/// <summary>
/// Harness-level numerics: (i) retirement versus context rot with transition costs, compared with the
/// renewal optimum sqrt(2K/beta) of Appendix A7; (ii) prefrontal harness cache capacity and effective team
/// size when partner records are dense vectors, text summaries or sparse coefficients.
/// </summary>
public static class A13_Harness
{
    public const ulong Seed = 20261204UL;
    private const double Rho = 0.002, W = 1.0, L0 = 0.02, K = 40.0, RepairCost = 8.0, RepairKeep = 0.15;

    public static double Loss(double stale) => L0 + (1 - L0) * stale / (W + stale);

    /// <summary>Expected cost per task when a curated successor replaces the worker every A tasks.</summary>
    public static double RetireCost(int a)
    {
        double s = K; for (int t = 0; t < a; t++) s += Loss(Rho * t);
        return s / a;
    }

    /// <summary>Expected cost per task with local repair every A tasks (steady-state sawtooth of stale mass).</summary>
    public static double RepairCostPerTask(int a)
    {
        double d = 0;
        for (int cycle = 0; cycle < 200; cycle++) d = RepairKeep * (d + Rho * a);   // converge to fixed point
        double s = RepairCost; double start = d;
        for (int t = 0; t < a; t++) s += Loss(start + Rho * t);
        return s / a;
    }

    public static ExperimentResult Run()
    {
        var head = new Dictionary<string, double>();
        double beta = (1 - L0) * Rho / W;
        double theory = Math.Sqrt(2 * K / beta);
        var curve = new List<IReadOnlyList<object>>();
        int bestA = 0; double bestCost = double.PositiveInfinity;
        int bestR = 0; double bestRepair = double.PositiveInfinity;
        var rng = Rng.Derive(Seed, 1);
        for (int a = 25; a <= 1500; a += 25)
        {
            double c = RetireCost(a), r = RepairCostPerTask(a);
            // Stochastic check of the curated policy over 200,000 tasks.
            int tasks = 200000; double errors = 0; int age = 0; double transitions = 0;
            for (int t = 0; t < tasks; t++)
            {
                bool err; (err, rng) = rng.NextBernoulli(Loss(Rho * age));
                if (err) errors++;
                age++;
                if (age == a) { age = 0; transitions += K; }
            }
            double sim = (errors + transitions) / tasks;
            curve.Add(new object[] { a, c, sim, r });
            if (c < bestCost) { bestCost = c; bestA = a; }
            if (r < bestRepair) { bestRepair = r; bestR = a; }
        }
        // Finer search for the exact optimum.
        for (int a = Math.Max(1, bestA - 25); a <= bestA + 25; a++) { double c = RetireCost(a); if (c < bestCost) { bestCost = c; bestA = a; } }
        double never = Enumerable.Range(0, 200000).Average(t => Loss(Rho * t));
        double cloneCost = never + K / theory;
        head["theory_optimum"] = theory; head["exact_optimum"] = bestA; head["retire_cost_at_optimum"] = bestCost;
        head["retire_cost_at_theory"] = RetireCost((int)Math.Round(theory));
        head["never_retire_cost_200k"] = never; head["clone_cost_200k"] = cloneCost;
        head["repair_best_interval"] = bestR; head["repair_best_cost"] = bestRepair; head["beta"] = beta;

        // Repair efficiency sweep: where does replacement become preferable to local repair?
        var repairRows = new List<IReadOnlyList<object>>();
        foreach (var keep in new[] { 0.15, 0.3, 0.5, 0.7, 0.85 })
        {
            double best = double.PositiveInfinity; int bestInt = 0;
            for (int a = 10; a <= 1500; a += 10)
            {
                double d = 0;
                for (int cycle = 0; cycle < 400; cycle++) d = keep * (d + Rho * a);
                double s2 = RepairCost; for (int t = 0; t < a; t++) s2 += Loss(d + Rho * t);
                double c = s2 / a;
                if (c < best) { best = c; bestInt = a; }
            }
            repairRows.Add(new object[] { keep, bestInt, best, bestCost, best < bestCost ? "repair" : "replace" });
            head[$"repair_keep{keep}_cost"] = best;
        }

        // Prefrontal cache capacity and team size: steady-state LRU miss rate for one worker (workers are independent).
        const double budget = 256 * 1024;
        var reps = new (string Name, double Bytes)[] { ("Dense FP16 vector", 8256), ("Text summary", 2048), ("Sparse coefficients", 84) };
        var teamRows = new List<IReadOnlyList<object>>();
        foreach (var n in new[] { 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192 })
        {
            var weights = Enumerable.Range(1, n - 1).Select(r => 1.0 / Math.Pow(r, 0.8)).ToArray();
            var cdf = new double[weights.Length];
            for (int i = 0; i < weights.Length; i++) cdf[i] = (i == 0 ? 0 : cdf[i - 1]) + weights[i];
            foreach (var (name, bytes) in reps)
            {
                int capacity = (int)Math.Floor(budget / bytes);
                var lru = new LinkedList<int>(); var index = new Dictionary<int, LinkedListNode<int>>();
                var er = Rng.Derive(Seed, (ulong)(n * 10 + bytes));
                const int accesses = 300000, warmup = 100000;
                long misses = 0, missedAcks = 0; double traffic = 0;
                for (int e = 0; e < accesses; e++)
                {
                    double u; (u, er) = er.NextDouble();
                    int partner = Array.BinarySearch(cdf, u * cdf[^1]);
                    if (partner < 0) partner = ~partner;
                    if (partner >= weights.Length) partner = weights.Length - 1;
                    bool ack; (ack, er) = er.NextBernoulli(0.3);
                    bool counted = e >= warmup;
                    if (index.TryGetValue(partner, out var node)) { lru.Remove(node); lru.AddFirst(node); if (counted) traffic += 64; }
                    else
                    {
                        if (counted) { misses++; if (ack) missedAcks++; traffic += bytes + 64; }
                        index[partner] = lru.AddFirst(partner);
                        if (lru.Count > capacity) { index.Remove(lru.Last!.Value); lru.RemoveLast(); }
                    }
                }
                double denom = accesses - warmup;
                teamRows.Add(new object[] { n, name, capacity, misses / denom, missedAcks / denom, traffic / denom });
                head[$"miss_{new string(name.Where(char.IsLetterOrDigit).ToArray())}_n{n}"] = misses / denom;
                head[$"capacity_{new string(name.Where(char.IsLetterOrDigit).ToArray())}"] = capacity;
            }
        }

        return new ExperimentResult("A13", "Retirement, context rot and harness cache capacity",
            new[]
            {
                Table.Of("retirement", new[] { "retirement_age", "expected_cost_curated", "simulated_cost_curated", "expected_cost_local_repair" }, curve),
                Table.Of("repair", new[] { "repair_keep_fraction", "best_interval", "best_repair_cost", "best_retire_cost", "preferred" }, repairRows),
                Table.Of("team", new[] { "team_size", "representation", "cache_capacity_records", "miss_rate", "missed_ack_rate", "bytes_per_event" }, teamRows)
            }, head);
    }
}
