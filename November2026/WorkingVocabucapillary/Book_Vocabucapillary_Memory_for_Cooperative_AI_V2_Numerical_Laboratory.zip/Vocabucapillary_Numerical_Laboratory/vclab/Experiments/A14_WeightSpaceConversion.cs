using VcLab.Core;

namespace VcLab.Experiments;

/// <summary>
/// Verifiable gradient-free conversion checks for weight-space Vocabucapillary programming (Chapter 12):
/// affine maps by simplex coefficient columns, the nonlinear boundary, and the attention-kernel change.
/// </summary>
public static class A14_WeightSpaceConversion
{
    public const ulong Seed = 20261205UL;

    private static (double[][] M, Rng Next) Gaussian(int rows, int cols, double scale, Rng rng)
    {
        var m = new double[rows][];
        for (int i = 0; i < rows; i++) { m[i] = new double[cols]; for (int j = 0; j < cols; j++) { double z; (z, rng) = rng.NextGaussian(); m[i][j] = scale * z; } }
        return (m, rng);
    }

    private static double[] Column(double[][] m, int j) => m.Select(r => r[j]).ToArray();
    private static double[] MatVec(double[][] m, IReadOnlyList<double> v) => m.Select(r => r.Zip(v, (a, b) => a * b).Sum()).ToArray();
    private static double Norm(IReadOnlyList<double> v) => Math.Sqrt(v.Sum(x => x * x));

    private static double[] SolveSymmetric(double[,] a, double[] b)
    {
        int n = b.Length;
        var m = new double[n, n + 1];
        for (int i = 0; i < n; i++) { for (int j = 0; j < n; j++) m[i, j] = a[i, j]; m[i, n] = b[i]; }
        for (int c = 0; c < n; c++)
        {
            int piv = c; for (int r = c + 1; r < n; r++) if (Math.Abs(m[r, c]) > Math.Abs(m[piv, c])) piv = r;
            for (int j = 0; j <= n; j++) (m[c, j], m[piv, j]) = (m[piv, j], m[c, j]);
            for (int r = 0; r < n; r++)
            {
                if (r == c || m[c, c] == 0) continue;
                double f = m[r, c] / m[c, c];
                for (int j = c; j <= n; j++) m[r, j] -= f * m[c, j];
            }
        }
        return Enumerable.Range(0, n).Select(i => m[i, i] != 0 ? m[i, n] / m[i, i] : 0.0).ToArray();
    }

    /// <summary>
    /// Lawson-Hanson active-set NNLS on the augmented system [E; w 1^T] t = [y; w], which enforces the
    /// simplex constraint to within O(1/w^2). Returns the coefficient column t (renormalised to unit mass).
    /// </summary>
    private static IReadOnlyList<double> SimplexLeastSquares(double[][] e, IReadOnlyList<double> y, int maxIter)
    {
        const double wRow = 1e3, tol = 1e-12;
        int rows = e.Length + 1, n = e[0].Length;
        var a = new double[rows][];
        for (int i = 0; i < e.Length; i++) a[i] = e[i];
        a[rows - 1] = Enumerable.Repeat(wRow, n).ToArray();
        var b = y.Concat(new[] { wRow }).ToArray();
        var x = new double[n];
        var passive = new bool[n];
        double[] Grad(double[] xx)
        {
            var r = new double[rows];
            for (int i = 0; i < rows; i++) { double s2 = b[i]; for (int j = 0; j < n; j++) s2 -= a[i][j] * xx[j]; r[i] = s2; }
            var g = new double[n];
            for (int j = 0; j < n; j++) { double s2 = 0; for (int i = 0; i < rows; i++) s2 += a[i][j] * r[i]; g[j] = s2; }
            return g;
        }
        double[] LeastSquaresOnPassive()
        {
            var idx = Enumerable.Range(0, n).Where(j => passive[j]).ToArray();
            var ata = new double[idx.Length, idx.Length]; var atb = new double[idx.Length];
            for (int p = 0; p < idx.Length; p++)
            {
                for (int q = 0; q < idx.Length; q++) { double s2 = 0; for (int i = 0; i < rows; i++) s2 += a[i][idx[p]] * a[i][idx[q]]; ata[p, q] = s2; }
                double t2 = 0; for (int i = 0; i < rows; i++) t2 += a[i][idx[p]] * b[i]; atb[p] = t2;
            }
            var sol = SolveSymmetric(ata, atb);
            var z = new double[n];
            for (int p = 0; p < idx.Length; p++) z[idx[p]] = sol[p];
            return z;
        }
        for (int iter = 0; iter < maxIter; iter++)
        {
            var w = Grad(x);
            int jBest = -1; double wBest = tol * wRow * wRow;
            for (int j = 0; j < n; j++) if (!passive[j] && w[j] > wBest) { wBest = w[j]; jBest = j; }
            if (jBest < 0) break;
            passive[jBest] = true;
            var z = LeastSquaresOnPassive();
            int guard = 0;
            while (Enumerable.Range(0, n).Any(j => passive[j] && z[j] <= tol) && guard++ < 4 * n)
            {
                double alpha = Enumerable.Range(0, n).Where(j => passive[j] && z[j] <= tol).Min(j => x[j] / (x[j] - z[j]));
                for (int j = 0; j < n; j++) x[j] += alpha * (z[j] - x[j]);
                for (int j = 0; j < n; j++) if (passive[j] && x[j] <= tol) { passive[j] = false; x[j] = 0; }
                z = LeastSquaresOnPassive();
            }
            x = z;
        }
        double sum = x.Sum();
        return x.Select(v => Math.Max(v, 0) / sum).ToArray();
    }

    public static ExperimentResult Run()
    {
        var head = new Dictionary<string, double>();
        var rng = Rng.Derive(Seed, 1);
        const int dIn = 16, mIn = 32, dOut = 12, mOut = 64;
        double[][] dIn_, w, bM, eRand;
        (dIn_, rng) = Gaussian(dIn, mIn, 1.0 / Math.Sqrt(dIn), rng);
        (w, rng) = Gaussian(dOut, dIn, 1.0 / Math.Sqrt(dIn), rng);
        (bM, rng) = Gaussian(dOut, 1, 0.1, rng);
        var b = bM.Select(r => r[0]).ToArray();
        (eRand, rng) = Gaussian(dOut, mOut, 0.6, rng);
        var targets = Enumerable.Range(0, mIn).Select(j => MatVec(w, Column(dIn_, j)).Select((x, i) => x + b[i]).ToArray()).ToArray();

        var rows = new List<IReadOnlyList<object>>();
        foreach (var scenario in new[] { "Exact targets in output dictionary", "Generic output dictionary" })
        {
            double[][] e = scenario.StartsWith("Exact")
                ? Enumerable.Range(0, dOut).Select(i => targets.Select(t => t[i]).Concat(eRand[i].Take(mOut - mIn)).ToArray()).ToArray()
                : eRand;
            var tCols = Enumerable.Range(0, mIn).Select(j => SimplexLeastSquares(e, targets[j], 200)).ToArray();
            var eps = tCols.Select((t, j) => Norm(MatVec(e, t).Select((x, i) => x - targets[j][i]).ToArray())).ToArray();
            double epsMax = eps.Max();
            double maxRatio = 0, maxErr = 0, meanSupport = 0; int violations = 0;
            var r2 = Rng.Derive(Seed, scenario.StartsWith("Exact") ? 2UL : 3UL);
            const int samples = 10000;
            for (int s = 0; s < samples; s++)
            {
                IReadOnlyList<double> a; (a, r2) = r2.NextDirichlet(mIn, 0.3);
                var x = MatVec(dIn_, a);
                var yTrue = MatVec(w, x).Select((v, i) => v + b[i]).ToArray();
                var ta = new double[mOut];
                for (int j = 0; j < mIn; j++) for (int k = 0; k < mOut; k++) ta[k] += tCols[j][k] * a[j];
                var yConv = MatVec(e, ta);
                double err = Norm(yConv.Select((v, i) => v - yTrue[i]).ToArray());
                double bound = Enumerable.Range(0, mIn).Sum(j => a[j] * eps[j]);
                maxErr = Math.Max(maxErr, err);
                if (epsMax > 0) maxRatio = Math.Max(maxRatio, err / epsMax);
                if (err > bound + 1e-12) violations++;
                meanSupport += ta.Count(v => v > 1e-9);
            }
            rows.Add(new object[] { scenario, epsMax, maxErr, maxRatio, violations, meanSupport / samples, tCols.Average(t => t.Count(v => v > 1e-9)) });
            string key = scenario.StartsWith("Exact") ? "exact" : "generic";
            head[$"{key}_eps_max"] = epsMax; head[$"{key}_max_err"] = maxErr; head[$"{key}_violations"] = violations;
            head[$"{key}_mean_support_Ta"] = meanSupport / samples; head[$"{key}_mean_column_support"] = tCols.Average(t => t.Count(v => v > 1e-9));
        }

        // Nonlinear boundary: ReLU of a mixture versus mixture of ReLUs.
        {
            var r3 = Rng.Derive(Seed, 4);
            var rel = new List<double>();
            for (int s = 0; s < 10000; s++)
            {
                IReadOnlyList<double> a; (a, r3) = r3.NextDirichlet(mIn, 0.3);
                var x = MatVec(dIn_, a);
                var reluMix = x.Select(v => Math.Max(0, v)).ToArray();
                var mixRelu = new double[dIn];
                for (int j = 0; j < mIn; j++) for (int i = 0; i < dIn; i++) mixRelu[i] += a[j] * Math.Max(0, dIn_[i][j]);
                rel.Add(Norm(reluMix.Zip(mixRelu, (p, q) => p - q).ToArray()) / Math.Max(Norm(reluMix), 1e-12));
            }
            var sorted = rel.OrderBy(v => v).ToArray();
            head["relu_rel_err_mean"] = rel.Average(); head["relu_rel_err_p95"] = sorted[(int)(0.95 * sorted.Length)];
        }

        // Attention kernel change as a function of code support and temperature.
        var attRows = new List<IReadOnlyList<object>>();
        {
            const int d = 16, atoms = 32, records = 64, queries = 2000;
            double[][] keys; var r4 = Rng.Derive(Seed, 5);
            (keys, r4) = Gaussian(d, atoms, 1.0 / Math.Sqrt(d), r4);
            foreach (var support in new[] { 1, 2, 4, 8 })
                foreach (var tau in new[] { 0.5, 1.0, 2.0 })
                {
                    var codes = new List<(int[] Idx, double[] W, double V)>();
                    var r5 = Rng.Derive(Seed, (ulong)(100 * support + tau * 10));
                    for (int i = 0; i < records; i++)
                    {
                        var idx = new HashSet<int>();
                        while (idx.Count < support) { int j; (j, r5) = r5.NextInt(atoms); idx.Add(j); }
                        IReadOnlyList<double> wts; (wts, r5) = r5.NextDirichlet(support, 1.0);
                        double val; (val, r5) = r5.NextGaussian();
                        codes.Add((idx.ToArray(), wts.ToArray(), val));
                    }
                    double absDiff = 0; int topAgree = 0, signAgree = 0;
                    for (int qn = 0; qn < queries; qn++)
                    {
                        var q = new double[d]; for (int i = 0; i < d; i++) { double z; (z, r5) = r5.NextGaussian(); q[i] = 2.0 * z; }
                        var atomScore = Enumerable.Range(0, atoms).Select(j => Enumerable.Range(0, d).Sum(i => q[i] * keys[i][j])).ToArray();
                        var wOrd = codes.Select(c => Math.Exp(c.Idx.Select((j, k) => c.W[k] * atomScore[j]).Sum() / tau)).ToArray();
                        var wCoef = codes.Select(c => c.Idx.Select((j, k) => c.W[k] * Math.Exp(atomScore[j] / tau)).Sum()).ToArray();
                        double rOrd = wOrd.Zip(codes, (x, c) => x * c.V).Sum() / wOrd.Sum();
                        double rCoef = wCoef.Zip(codes, (x, c) => x * c.V).Sum() / wCoef.Sum();
                        absDiff += Math.Abs(rOrd - rCoef);
                        if (Prob.Argmax(wOrd) == Prob.Argmax(wCoef)) topAgree++;
                        if (Math.Sign(rOrd) == Math.Sign(rCoef)) signAgree++;
                    }
                    attRows.Add(new object[] { support, tau, absDiff / queries, (double)topAgree / queries, (double)signAgree / queries });
                    head[$"att_s{support}_tau{tau}_absdiff"] = absDiff / queries;
                    head[$"att_s{support}_tau{tau}_sign"] = (double)signAgree / queries;
                }
        }

        return new ExperimentResult("A14", "Weight-space conversion checks",
            new[]
            {
                Table.Of("affine", new[] { "scenario", "max_column_residual", "max_decoded_error", "max_error_over_bound", "bound_violations", "mean_support_Ta", "mean_column_support" }, rows),
                Table.Of("attention", new[] { "code_support", "temperature", "mean_abs_read_difference", "top_record_agreement", "decision_sign_agreement" }, attRows)
            }, head);
    }
}
