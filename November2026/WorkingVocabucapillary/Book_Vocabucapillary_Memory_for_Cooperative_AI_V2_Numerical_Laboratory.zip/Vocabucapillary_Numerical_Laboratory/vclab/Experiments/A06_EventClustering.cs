using VcLab.Core;

namespace VcLab.Experiments;

/// <summary>Pre-sleep event clustering of working memory from softmax participation vectors.</summary>
public static class A06_EventClustering
{
    public const ulong Seed = 20261128UL;
    private const int Events = 5, PerEvent = 40, Probes = 32;

    public sealed record Token(int Event, int Position, IReadOnlyList<double> Participation);

    public static (IReadOnlyList<Token> Tokens, Rng Next) Generate(double hub, Rng rng)
    {
        var tokens = new List<Token>();
        var hubPattern = new double[Probes]; hubPattern[0] = 0.5; hubPattern[1] = 0.5;
        int pos = 0;
        for (int block = 0; block < Events; block++)
            for (int i = 0; i < PerEvent; i++)
            {
                int e = block;
                bool intrude; (intrude, rng) = rng.NextBernoulli(0.10);
                if (intrude) (e, rng) = rng.NextIntExcept(Events, block);
                var logits = new double[Probes];
                for (int j = 0; j < Probes; j++) { double z; (z, rng) = rng.NextGaussian(); logits[j] = 0.8 * z; }
                for (int t = 0; t < 3; t++) logits[2 + 3 * e + t] += 1.2;
                var p = Prob.Softmax(logits, 1.5);
                var mixed = new double[Probes];
                for (int j = 0; j < Probes; j++) mixed[j] = (1 - hub) * p[j] + hub * hubPattern[j];
                tokens.Add(new Token(e, pos++, mixed));
            }
        return (tokens, rng);
    }

    private static double[] Unit(IEnumerable<double> x)
    {
        var a = x.ToArray(); double n = Math.Sqrt(a.Sum(v => v * v));
        return a.Select(v => v / n).ToArray();
    }

    public static IReadOnlyList<IReadOnlyList<double>> Features(IReadOnlyList<Token> tokens, string method)
    {
        var mean = new double[Probes];
        foreach (var t in tokens) for (int j = 0; j < Probes; j++) mean[j] += t.Participation[j] / tokens.Count;
        int n = tokens.Count;
        return tokens.Select(t =>
        {
            IEnumerable<double> f = method == "raw" ? t.Participation : t.Participation.Select((v, j) => v / mean[j]);
            var u = Unit(f);
            if (method == "idf+time") return (IReadOnlyList<double>)u.Append(0.6 * (double)t.Position / n * 2.0).ToArray();
            return u;
        }).ToArray();
    }

    public static (IReadOnlyList<int> Labels, double Inertia) KMeans(IReadOnlyList<IReadOnlyList<double>> x, int k, int restarts, Rng rng)
    {
        int n = x.Count, d = x[0].Count;
        static double D2(IReadOnlyList<double> a, IReadOnlyList<double> b) { double s = 0; for (int i = 0; i < a.Count; i++) { double t = a[i] - b[i]; s += t * t; } return s; }
        IReadOnlyList<int> bestLabels = Array.Empty<int>(); double bestInertia = double.PositiveInfinity;
        for (int r = 0; r < restarts; r++)
        {
            var centers = new List<double[]>();
            int first; (first, rng) = rng.NextInt(n);
            centers.Add(x[first].ToArray());
            while (centers.Count < k)
            {
                var w = x.Select(p => centers.Min(c => D2(p, c))).ToArray();
                int pick; (pick, rng) = rng.NextCategorical(w);
                centers.Add(x[pick].ToArray());
            }
            var labels = new int[n];
            for (int it = 0; it < 100; it++)
            {
                bool changed = false;
                for (int i = 0; i < n; i++)
                {
                    int best = 0; double bd = double.PositiveInfinity;
                    for (int c = 0; c < k; c++) { double dd = D2(x[i], centers[c]); if (dd < bd) { bd = dd; best = c; } }
                    if (labels[i] != best || it == 0) { changed |= labels[i] != best; labels[i] = best; }
                }
                var sums = Enumerable.Range(0, k).Select(_ => new double[d]).ToArray(); var counts = new int[k];
                for (int i = 0; i < n; i++) { counts[labels[i]]++; for (int j = 0; j < d; j++) sums[labels[i]][j] += x[i][j]; }
                for (int c = 0; c < k; c++) if (counts[c] > 0) centers[c] = sums[c].Select(v => v / counts[c]).ToArray();
                if (!changed && it > 0) break;
            }
            double inertia = 0; for (int i = 0; i < n; i++) inertia += D2(x[i], centers[labels[i]]);
            if (inertia < bestInertia) { bestInertia = inertia; bestLabels = labels.ToArray(); }
        }
        return (bestLabels, bestInertia);
    }

    public static ExperimentResult Run()
    {
        var rows = new List<IReadOnlyList<object>>();
        var head = new Dictionary<string, double>();
        foreach (var hub in new[] { 0.0, 0.5, 0.8, 0.9 })
            foreach (var method in new[] { "raw", "idf", "idf+time" })
            {
                var aris = new List<double>();
                for (int rep = 0; rep < 20; rep++)
                {
                    var rng = Rng.Derive(Seed, (ulong)(rep + 1));
                    var (tokens, r2) = Generate(hub, rng);
                    var feats = Features(tokens, method);
                    var (labels, _) = KMeans(feats, Events, 10, r2);
                    aris.Add(Stats.AdjustedRand(tokens.Select(t => t.Event).ToArray(), labels));
                }
                double mean = aris.Average(), sd = Stats.Std(aris);
                rows.Add(new object[] { hub, method, mean, sd });
                head[$"ari_h{hub}_{method}"] = mean;
            }
        return new ExperimentResult("A06", "Event clustering by softmax participation",
            new[] { Table.Of("ari", new[] { "hub_weight", "method", "ari_mean", "ari_sd" }, rows) }, head);
    }
}
