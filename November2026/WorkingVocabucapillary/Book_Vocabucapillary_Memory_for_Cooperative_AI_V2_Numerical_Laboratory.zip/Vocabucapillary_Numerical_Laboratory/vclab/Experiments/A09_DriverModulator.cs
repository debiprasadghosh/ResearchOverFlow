using VcLab.Core;

namespace VcLab.Experiments;

/// <summary>
/// Driver coefficients (content, convex mixtures) versus modulator coefficients (gains, multiplicative).
/// Top-down context resolves an ambiguous driver code. Additive feedback can place the winner on an atom
/// the driver never reported; multiplicative modulation cannot (support preservation).
/// </summary>
public static class A09_DriverModulator
{
    public const ulong Seed = 20261130UL;
    private const int K = 16;

    public static readonly string[] Policies = { "No feedback", "Additive, lambda=0.25", "Additive, lambda=0.50", "Multiplicative gain", "Multiplicative gain, exponent 0.5" };

    public static IReadOnlyList<double> Apply(string policy, IReadOnlyList<double> a, IReadOnlyList<double> t) => policy switch
    {
        "No feedback" => a,
        "Additive, lambda=0.25" => Prob.Linear(t, a, 0.25),
        "Additive, lambda=0.50" => Prob.Linear(t, a, 0.50),
        "Multiplicative gain" => Prob.Normalize(a.Select((x, i) => x * t[i]).ToArray()),
        "Multiplicative gain, exponent 0.5" => Prob.Normalize(a.Select((x, i) => x * Math.Sqrt(t[i])).ToArray()),
        _ => throw new ArgumentException(policy)
    };

    public static ExperimentResult Run()
    {
        const int n = 50000;
        var rows = new List<IReadOnlyList<object>>();
        var head = new Dictionary<string, double>();
        foreach (var validity in new[] { 0.0, 0.25, 0.5, 0.75, 1.0 })
        {
            var rng = Rng.Derive(Seed, (ulong)(validity * 100) + 1);
            var acc = Policies.ToDictionary(p => p, _ => 0.0);
            var hall = Policies.ToDictionary(p => p, _ => 0.0);
            var outside = Policies.ToDictionary(p => p, _ => 0.0);
            for (int trial = 0; trial < n; trial++)
            {
                int i, j, k; (i, rng) = rng.NextInt(K); (j, rng) = rng.NextIntExcept(K, i);
                do { (k, rng) = rng.NextInt(K); } while (k == i || k == j);
                double delta; (delta, rng) = rng.NextUniform(-0.1, 0.1);
                var a = new double[K]; a[i] = 0.475 + delta; a[j] = 0.475 - delta; a[k] = 0.05;
                bool valid; (valid, rng) = rng.NextBernoulli(validity);
                int c = i;
                if (!valid) (c, rng) = rng.NextIntExcept(K, i);
                var t = Enumerable.Repeat(0.2 / K, K).ToArray(); t[c] += 0.8;
                foreach (var p in Policies)
                {
                    var alpha = Apply(p, a, t);
                    int win = Prob.Argmax(alpha);
                    if (win == i) acc[p]++;
                    if (a[win] == 0) hall[p]++;
                    double outMass = 0; for (int q = 0; q < K; q++) if (a[q] == 0) outMass += alpha[q];
                    outside[p] += outMass;
                }
            }
            foreach (var p in Policies)
            {
                rows.Add(new object[] { validity, p, acc[p] / n, hall[p] / n, outside[p] / n });
                head[$"acc_v{validity}_{new string(p.Where(char.IsLetterOrDigit).ToArray())}"] = acc[p] / n;
                head[$"hall_v{validity}_{new string(p.Where(char.IsLetterOrDigit).ToArray())}"] = hall[p] / n;
            }
        }

        // Storage and wiring accounting for a six-modality system (illustrative sizes).
        double modalities = 6, nativeAtoms = 65536, dNative = 1024, bytes = 2;
        double assocAtoms = 1 << 20, dAssoc = 1024, mapK = 8;
        double pairwise = modalities * (modalities - 1) / 2 * nativeAtoms * nativeAtoms * bytes;
        double nativeVocab = modalities * nativeAtoms * dNative * bytes;
        double assocVocab = assocAtoms * dAssoc * bytes;
        double maps = modalities * nativeAtoms * mapK * Math.Ceiling((Math.Log2(assocAtoms) + 8) / 8.0);
        double areas = modalities + 1;
        double routes = 2 * areas;
        double operatorBytes = routes * 256 * bytes;
        var acct = new List<IReadOnlyList<object>>
        {
            new object[] { "Pairwise cross-modal tables at a hub", pairwise, modalities * (modalities - 1) },
            new object[] { "Native vocabularies kept in modality areas", nativeVocab, 0.0 },
            new object[] { "Shared association vocabulary (association cortex)", assocVocab, 0.0 },
            new object[] { "Sparse native-to-association maps", maps, 0.0 },
            new object[] { "Hub routing operator: 256 gains per route", operatorBytes, routes },
            new object[] { "Direct all-to-all cortico-cortical routes", 0.0, areas * (areas - 1) }
        };
        head["pairwise_GiB"] = pairwise / Math.Pow(2, 30);
        head["native_vocab_MiB"] = nativeVocab / Math.Pow(2, 20);
        head["assoc_vocab_GiB"] = assocVocab / Math.Pow(2, 30);
        head["maps_MiB"] = maps / Math.Pow(2, 20);
        head["operator_KiB"] = operatorBytes / 1024.0;
        head["routes_hub"] = routes; head["routes_direct"] = areas * (areas - 1);
        head["cortex_neurons_billion"] = 16.34; head["rest_of_brain_neurons_billion"] = 0.69;

        return new ExperimentResult("A09", "Driver and modulator coefficients",
            new[]
            {
                Table.Of("feedback", new[] { "context_validity", "policy", "accuracy", "hallucination_rate", "mass_outside_driver_support" }, rows),
                Table.Of("accounting", new[] { "component", "bytes", "routes" }, acct)
            }, head);
    }
}
