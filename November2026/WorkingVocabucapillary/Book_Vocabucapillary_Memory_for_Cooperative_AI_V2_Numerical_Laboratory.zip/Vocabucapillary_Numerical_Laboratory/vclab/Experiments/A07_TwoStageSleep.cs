using VcLab.Core;

namespace VcLab.Experiments;

/// <summary>
/// NREM replay decodes episodes with the native modality vocabularies and writes association links.
/// REM integration operates on association coefficients only (two-hop linking), without native decoding.
/// </summary>
public static class A07_TwoStageSleep
{
    public const ulong Seed = 20261129UL;
    private const int Concepts = 60, Chains = 12, ChainLength = 5, NativeAtoms = 256, Dim = 32, Repeats = 2;
    private const double Noise = 0.24, Lambda = 0.5;

    public sealed record Episode(int Chain, int A, int B, IReadOnlyList<double> Vision, IReadOnlyList<double> Audio);

    public sealed record Memory(IReadOnlyList<IReadOnlyList<double>> W, IReadOnlyList<IReadOnlyList<double>> Integrated)
    {
        public static Memory Empty => new(Zero(), Zero());
        private static IReadOnlyList<IReadOnlyList<double>> Zero() => Enumerable.Range(0, Concepts).Select(_ => (IReadOnlyList<double>)new double[Concepts]).ToArray();
    }

    private static IReadOnlyList<IReadOnlyList<double>> RowNormalize(IReadOnlyList<IReadOnlyList<double>> w) =>
        w.Select(row => { double s = row.Sum(); return (IReadOnlyList<double>)row.Select(v => s > 0 ? v / s : 0.0).ToArray(); }).ToArray();

    private static int Decode(IReadOnlyList<double> x, IReadOnlyList<IReadOnlyList<double>> dict)
    {
        int best = 0; double bd = double.NegativeInfinity;
        for (int a = 0; a < dict.Count; a++)
        {
            double s = 0; for (int i = 0; i < Dim; i++) s += dict[a][i] * x[i];
            if (s > bd) { bd = s; best = a; }
        }
        return best;
    }

    /// <summary>NREM: replay with native-vocabulary decoding; writes direct association links.</summary>
    public static (Memory Next, long Macs, int DecodeErrors) Nrem(Memory mem, IEnumerable<Episode> episodes,
        IReadOnlyList<IReadOnlyList<double>> visionDict, IReadOnlyList<IReadOnlyList<double>> audioDict)
    {
        var w = mem.W.Select(r => r.ToArray()).ToArray();
        long macs = 0; int errors = 0;
        foreach (var e in episodes)
        {
            int a = Decode(e.Vision, visionDict), b = Decode(e.Audio, audioDict);
            macs += 2L * NativeAtoms * Dim;
            if (a != e.A || b != e.B) errors++;
            if (a < Concepts && b < Concepts && a != b) { w[a][b] += 1; w[b][a] += 1; }
        }
        return (new Memory(w, mem.Integrated), macs, errors);
    }

    /// <summary>REM: association-only integration I = offdiag(P P) of the current consolidated links.</summary>
    public static (Memory Next, long Macs) Rem(Memory mem)
    {
        var p = RowNormalize(mem.W);
        var i2 = new double[Concepts][];
        for (int a = 0; a < Concepts; a++)
        {
            i2[a] = new double[Concepts];
            for (int c = 0; c < Concepts; c++)
            {
                if (a == c) continue;
                double s = 0; for (int b = 0; b < Concepts; b++) s += p[a][b] * p[b][c];
                i2[a][c] = s;
            }
        }
        return (new Memory(mem.W, i2), (long)Concepts * Concepts * Concepts);
    }

    private static double Score(Memory m, int a, int b)
    {
        var p = RowNormalize(m.W);
        return 0.5 * (p[a][b] + p[b][a]) + Lambda * 0.5 * (m.Integrated[a][b] + m.Integrated[b][a]);
    }

    public static ExperimentResult Run()
    {
        var rng = Rng.Derive(Seed, 1);
        IReadOnlyList<IReadOnlyList<double>> MakeDict(ref Rng r)
        {
            var d = new IReadOnlyList<double>[NativeAtoms];
            for (int a = 0; a < NativeAtoms; a++)
            {
                var v = new double[Dim];
                for (int i = 0; i < Dim; i++) (v[i], r) = r.NextGaussian();
                double n = Math.Sqrt(v.Sum(x => x * x));
                d[a] = v.Select(x => x / n).ToArray();
            }
            return d;
        }
        var vision = MakeDict(ref rng); var audio = MakeDict(ref rng);

        // Chains of concepts; each adjacent pair is experienced in several episodes.
        var order = Enumerable.Range(0, Concepts).ToArray();
        for (int i = Concepts - 1; i > 0; i--) { int j; (j, rng) = rng.NextInt(i + 1); (order[i], order[j]) = (order[j], order[i]); }
        var chains = Enumerable.Range(0, Chains).Select(c => order.Skip(c * ChainLength).Take(ChainLength).ToArray()).ToArray();
        var episodes = new List<Episode>();
        foreach (var (chain, ci) in chains.Select((c, i) => (c, i)))
            for (int k = 0; k + 1 < ChainLength; k++)
                for (int rep = 0; rep < Repeats; rep++)
                {
                    bool flip; (flip, rng) = rng.NextBernoulli(0.5);
                    int a = flip ? chain[k + 1] : chain[k], b = flip ? chain[k] : chain[k + 1];
                    var vx = new double[Dim]; var ax = new double[Dim];
                    for (int i = 0; i < Dim; i++)
                    {
                        double z1, z2; (z1, rng) = rng.NextGaussian(); (z2, rng) = rng.NextGaussian();
                        vx[i] = vision[a][i] + Noise * z1; ax[i] = audio[b][i] + Noise * z2;
                    }
                    episodes.Add(new Episode(ci, a, b, vx, ax));
                }

        var direct = chains.SelectMany(c => Enumerable.Range(0, ChainLength - 1).Select(k => (c[k], c[k + 1]))).ToArray();
        var inferential = chains.SelectMany(c => Enumerable.Range(0, ChainLength - 2).Select(k => (c[k], c[k + 2]))).ToArray();
        var chainOf = new int[Concepts];
        for (int c = 0; c < Chains; c++) foreach (var x in chains[c]) chainOf[x] = c;
        var negatives = new List<(int, int)>();
        while (negatives.Count < 400)
        {
            int a, b; (a, rng) = rng.NextInt(Concepts); (b, rng) = rng.NextInt(Concepts);
            if (chainOf[a] != chainOf[b]) negatives.Add((a, b));
        }

        double Auc(Memory m, IEnumerable<(int, int)> pos) =>
            Stats.Auc(pos.Select(p => Score(m, p.Item1, p.Item2)).ToArray(), negatives.Select(p => Score(m, p.Item1, p.Item2)).ToArray());

        var rows = new List<IReadOnlyList<object>>();
        var head = new Dictionary<string, double>();
        void Report(string name, Memory m, long macs, int errs)
        {
            double ad = Auc(m, direct), ai = Auc(m, inferential);
            rows.Add(new object[] { name, ad, ai, macs, errs });
            string key = new string(name.Where(char.IsLetterOrDigit).ToArray());
            head[$"direct_{key}"] = ad; head[$"infer_{key}"] = ai; head[$"macs_{key}"] = macs;
        }

        var empty = Memory.Empty;
        Report("No sleep", empty, 0, 0);
        var (nOnly, nMacs, nErr) = Nrem(empty, episodes, vision, audio);
        Report("NREM only", nOnly, nMacs, nErr);
        var (rOnly, rMacs) = Rem(empty);
        Report("REM only", rOnly, rMacs, 0);
        var (nr, rm2) = Rem(nOnly);
        Report("NREM then REM", nr, nMacs + rm2, nErr);
        var (rFirst, rm3) = Rem(empty);
        var (rn, nm3, ne3) = Nrem(rFirst, episodes, vision, audio);
        Report("REM then NREM", rn, rm3 + nm3, ne3);
        // Two cycles: half of the chains per cycle; with and without REM in the second cycle.
        var firstHalf = episodes.Where(e => e.Chain < Chains / 2).ToArray();
        var secondHalf = episodes.Where(e => e.Chain >= Chains / 2).ToArray();
        var (c1n, m1, e1) = Nrem(empty, firstHalf, vision, audio);
        var (c1, m1r) = Rem(c1n);
        var (c2n, m2, e2) = Nrem(c1, secondHalf, vision, audio);
        var (c2, m2r) = Rem(c2n);
        Report("Two cycles, REM in both", c2, m1 + m1r + m2 + m2r, e1 + e2);
        Report("Two cycles, no REM in cycle 2", c2n, m1 + m1r + m2, e1 + e2);
        // Inference restricted to second-half chains when cycle 2 lacks REM.
        var infer2 = inferential.Where(p => chainOf[p.Item1] >= Chains / 2).ToArray();
        head["infer_secondhalf_noREM2"] = Auc(c2n, infer2);
        head["infer_secondhalf_REM2"] = Auc(c2, infer2);
        head["nrem_macs_per_episode"] = 2.0 * NativeAtoms * Dim;
        head["rem_macs_per_pass"] = Concepts * Concepts * Concepts;
        head["decode_error_rate"] = (double)nErr / episodes.Count;

        // Workload model for multi-cycle nights: REM share rises when each cycle integrates with everything consolidated so far.
        var cycleRows = new List<IReadOnlyList<object>>();
        foreach (var load in new[] { 10000.0, 20000.0 })
        {
            double nativeAtoms = 65536, dNative = 1024, dAssoc = 1024;
            double cumulative = 0;
            for (int c = 1; c <= 5; c++)
            {
                cumulative += load;
                double nremWork = load * nativeAtoms * dNative;
                double remWork = load * cumulative * dAssoc;
                double share = remWork / (remWork + nremWork);
                cycleRows.Add(new object[] { load, c, nremWork, remWork, share });
                head[$"remshare_load{load}_c{c}"] = share;
            }
        }

        return new ExperimentResult("A07", "Two-stage sleep: NREM native replay and REM association integration",
            new[]
            {
                Table.Of("conditions", new[] { "condition", "direct_auc", "inferential_auc", "multiply_adds", "decode_errors" }, rows),
                Table.Of("cycles", new[] { "items_per_cycle", "cycle", "nrem_work", "rem_work", "rem_share" }, cycleRows)
            }, head);
    }
}
