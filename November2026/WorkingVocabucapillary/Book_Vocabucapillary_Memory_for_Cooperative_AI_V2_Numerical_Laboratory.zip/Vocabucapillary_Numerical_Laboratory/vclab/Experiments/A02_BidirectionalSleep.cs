using VcLab.Core;

namespace VcLab.Experiments;

/// <summary>Chain-structured span model: latent association atoms grouped into answer classes.</summary>
public sealed record HmmModel(
    int Classes, int AtomsPerClass, int Vocabulary,
    IReadOnlyList<IReadOnlyList<double>> Transition,
    IReadOnlyList<IReadOnlyList<double>> Emission,
    IReadOnlyList<int> AtomClass)
{
    public int K => Classes * AtomsPerClass;

    public static HmmModel Default(double atomCue = 0.22, double atomErr = 0.06, double classCue = 0.20, double classErr = 0.06)
    {
        const int L = 4, r = 3, K = L * r, V = K + L + 8;
        var atomClass = Enumerable.Range(0, K).Select(z => z / r).ToArray();
        var A = new double[K][];
        for (int z = 0; z < K; z++)
        {
            A[z] = new double[K];
            for (int w = 0; w < K; w++)
                A[z][w] = w == z ? 0.85 : atomClass[w] == atomClass[z] ? 0.10 / (r - 1) : 0.05 / (K - r);
        }
        double generic = 1.0 - atomCue - atomErr - classCue - classErr;
        var E = new double[K][];
        for (int z = 0; z < K; z++)
        {
            E[z] = new double[V];
            for (int a = 0; a < K; a++) E[z][a] = a == z ? atomCue : atomErr / (K - 1);
            for (int c = 0; c < L; c++) E[z][K + c] = c == atomClass[z] ? classCue : classErr / (L - 1);
            for (int g = 0; g < 8; g++) E[z][K + L + g] = generic / 8.0;
        }
        return new HmmModel(L, r, V, A, E, atomClass);
    }
}

/// <summary>One observation of a closed span with its directional codes.</summary>
public sealed record SpanObs(
    int Span, int Pos, int TrueAtom, int TrueClass,
    IReadOnlyList<double> F, IReadOnlyList<double> B, IReadOnlyList<double> Local, IReadOnlyList<double> Exact);

public static class Hmm
{
    public static (IReadOnlyList<int> Z, IReadOnlyList<int> X, Rng Next) Sample(HmmModel m, int T, Rng rng)
    {
        var z = new int[T]; var x = new int[T];
        var uniform = Enumerable.Repeat(1.0 / m.K, m.K).ToArray();
        (z[0], rng) = rng.NextCategorical(uniform);
        (x[0], rng) = rng.NextCategorical(m.Emission[z[0]]);
        for (int t = 1; t < T; t++)
        {
            (z[t], rng) = rng.NextCategorical(m.Transition[z[t - 1]]);
            (x[t], rng) = rng.NextCategorical(m.Emission[z[t]]);
        }
        return (z, x, rng);
    }

    /// <summary>Causal filter f_t = P(z_t | x_1..x_t): the wake computation that sleep may reuse.</summary>
    public static IReadOnlyList<IReadOnlyList<double>> Forward(HmmModel m, IReadOnlyList<int> x)
    {
        int T = x.Count, K = m.K;
        var f = new IReadOnlyList<double>[T];
        var prev = Enumerable.Repeat(1.0 / K, K).ToArray();
        for (int t = 0; t < T; t++)
        {
            var pred = new double[K];
            if (t == 0) Array.Copy(prev, pred, K);
            else
                for (int z = 0; z < K; z++)
                {
                    double s = 0; for (int w = 0; w < K; w++) s += f[t - 1][w] * m.Transition[w][z];
                    pred[z] = s;
                }
            for (int z = 0; z < K; z++) pred[z] *= m.Emission[z][x[t]];
            f[t] = Prob.Normalize(pred);
        }
        return f;
    }

    /// <summary>Reverse-causal messages beta_t(z) proportional to P(x_{t+1..T} | z_t).</summary>
    public static IReadOnlyList<IReadOnlyList<double>> BackwardMessages(HmmModel m, IReadOnlyList<int> x)
    {
        int T = x.Count, K = m.K;
        var beta = new IReadOnlyList<double>[T];
        beta[T - 1] = Enumerable.Repeat(1.0, K).ToArray();
        for (int t = T - 2; t >= 0; t--)
        {
            var nb = new double[K];
            for (int z = 0; z < K; z++)
            {
                double s = 0;
                for (int w = 0; w < K; w++) s += m.Transition[z][w] * m.Emission[w][x[t + 1]] * beta[t + 1][w];
                nb[z] = s;
            }
            beta[t] = Prob.Normalize(nb);
        }
        return beta;
    }

    /// <summary>Directional codes for a span: f (reused), b = P(z_t | x_t..x_T), local = P(z_t | x_t), exact smoothing.</summary>
    public static IReadOnlyList<SpanObs> Codes(HmmModel m, int span, IReadOnlyList<int> z, IReadOnlyList<int> x)
    {
        var f = Forward(m, x);
        var beta = BackwardMessages(m, x);
        int K = m.K;
        var list = new SpanObs[x.Count];
        for (int t = 0; t < x.Count; t++)
        {
            var local = new double[K];
            var b = new double[K];
            var g = new double[K];
            for (int q = 0; q < K; q++)
            {
                local[q] = m.Emission[q][x[t]];      // uniform marginal prior at every position
                b[q] = local[q] * beta[t][q];
                g[q] = f[t][q] * beta[t][q];         // standard forward-backward smoothing
            }
            list[t] = new SpanObs(span, t, z[t], m.AtomClass[z[t]], f[t], Prob.Normalize(b), Prob.Normalize(local), Prob.Normalize(g));
        }
        return list;
    }

    public static IReadOnlyList<SpanObs> Generate(HmmModel m, int spans, int T, ulong seed)
    {
        var rng = Rng.Derive(seed, 2);
        var all = new List<SpanObs>(spans * T);
        for (int s = 0; s < spans; s++)
        {
            var (z, x, next) = Sample(m, T, rng);
            rng = next;
            all.AddRange(Codes(m, s, z, x));
        }
        return all;
    }

    /// <summary>Brute-force posterior marginals by enumerating every latent path (small T only).</summary>
    public static IReadOnlyList<IReadOnlyList<double>> Enumerate(HmmModel m, IReadOnlyList<int> x)
    {
        int T = x.Count, K = m.K;
        var post = new double[T, K];
        var path = new int[T];
        long total = (long)Math.Pow(K, T);
        double norm = 0;
        for (long code = 0; code < total; code++)
        {
            long c = code;
            for (int t = 0; t < T; t++) { path[t] = (int)(c % K); c /= K; }
            double p = 1.0 / K * m.Emission[path[0]][x[0]];
            for (int t = 1; t < T; t++) p *= m.Transition[path[t - 1]][path[t]] * m.Emission[path[t]][x[t]];
            norm += p;
            for (int t = 0; t < T; t++) post[t, path[t]] += p;
        }
        return Enumerable.Range(0, T).Select(t => (IReadOnlyList<double>)Enumerable.Range(0, K).Select(q => post[t, q] / norm).ToArray()).ToArray();
    }
}

public static class A02_BidirectionalSleep
{
    public const ulong Seed = 20261124UL;

    public sealed record PolicyScore(string Policy, double ClassAcc, double AtomAcc, double LogLossBits, double Misfiled, double Brier);

    /// <summary>Consolidated atom-level code for each policy.</summary>
    public static IReadOnlyList<double> Fuse(string policy, SpanObs o, HmmModel m)
    {
        int K = m.K, L = m.Classes;
        var fC = Prob.Aggregate(o.F, m.AtomClass, L); var bC = Prob.Aggregate(o.B, m.AtomClass, L);
        double u = Prob.Mixing(o.F, K) - Prob.Mixing(o.B, K);
        double v = Prob.Sharpness(fC, L) - Prob.Sharpness(bC, L);
        return policy switch
        {
            "Forward only" => o.F,
            "Backward only" => o.B,
            "Equal linear" => Prob.Linear(o.F, o.B, 0.5),
            "Sharpness-only linear" => Prob.Linear(o.F, o.B, Prob.SharpnessShare(v)),
            "Joint score linear (Eq. 9.2)" => Prob.Linear(o.F, o.B, Prob.ForwardShare(u, v)),
            "Product, no local correction" => Prob.Product(o.F, o.B),
            "Tempered product, joint share" => Prob.TemperedProduct(o.F, o.B, o.Local, Prob.ForwardShare(u, v)),
            "Exact decoupled (Prop. 16.1)" => Prob.CorrectedProduct(o.F, o.B, o.Local),
            _ => throw new ArgumentException(policy)
        };
    }

    public static readonly string[] Policies =
    {
        "Forward only", "Backward only", "Equal linear", "Sharpness-only linear", "Joint score linear (Eq. 9.2)",
        "Product, no local correction", "Tempered product, joint share", "Exact decoupled (Prop. 16.1)"
    };

    public static PolicyScore Score(string policy, IReadOnlyList<SpanObs> data, HmmModel m)
    {
        double acc = 0, atomAcc = 0, ll = 0, mis = 0, brier = 0;
        foreach (var o in data)
        {
            var a = Fuse(policy, o, m);
            var c = Prob.Aggregate(a, m.AtomClass, m.Classes);
            if (Prob.Argmax(c) == o.TrueClass) acc++;
            if (Prob.Argmax(a) == o.TrueAtom) atomAcc++;
            ll += Prob.LogLossBits(c, o.TrueClass);
            mis += 1 - c[o.TrueClass];
            brier += Prob.Brier(c, o.TrueClass);
        }
        int n = data.Count;
        return new PolicyScore(policy, acc / n, atomAcc / n, ll / n, mis / n, brier / n);
    }

    public static ExperimentResult Run()
    {
        var m = HmmModel.Default();
        const int spans = 4000, T = 32;
        var data = Hmm.Generate(m, spans, T, Seed);

        // 1. Exactness: brute force versus decoupled rule on short spans.
        var rng = Rng.Derive(Seed, 99);
        double maxErr = 0, maxErrFb = 0;
        double maxDecVsFb = data.Max(o => Prob.CorrectedProduct(o.F, o.B, o.Local).Zip(o.Exact, (p, q) => Math.Abs(p - q)).Max());
        for (int rep = 0; rep < 4; rep++)
        {
            var (z, x, next) = Hmm.Sample(m, 6, rng); rng = next;
            var codes = Hmm.Codes(m, rep, z, x);
            var brute = Hmm.Enumerate(m, x);
            for (int t = 0; t < 6; t++)
            {
                var dec = Prob.CorrectedProduct(codes[t].F, codes[t].B, codes[t].Local);
                for (int q = 0; q < m.K; q++)
                {
                    maxErr = Math.Max(maxErr, Math.Abs(dec[q] - brute[t][q]));
                    maxErrFb = Math.Max(maxErrFb, Math.Abs(codes[t].Exact[q] - brute[t][q]));
                }
            }
        }

        // 2. Policy comparison.
        var scores = Policies.Select(p => Score(p, data, m)).ToArray();
        var policyRows = scores.Select(s => (IReadOnlyList<object>)new object[] { s.Policy, s.ClassAcc, s.AtomAcc, s.LogLossBits, s.Misfiled, s.Brier }).ToArray();

        // 3. Does each criterion track which direction is more reliable?
        var uList = new List<double>(); var vList = new List<double>(); var dList = new List<double>();
        int contested = 0, jointRight = 0, sharpRight = 0, jointWrong = 0, jointNeutral = 0, agreeSign = 0, agreeSignRight = 0;
        foreach (var o in data)
        {
            var fC = Prob.Aggregate(o.F, m.AtomClass, m.Classes); var bC = Prob.Aggregate(o.B, m.AtomClass, m.Classes);
            double u = Prob.Mixing(o.F, m.K) - Prob.Mixing(o.B, m.K);
            double v = Prob.Sharpness(fC, m.Classes) - Prob.Sharpness(bC, m.Classes);
            double d = Math.Log2(Math.Max(fC[o.TrueClass], 1e-12)) - Math.Log2(Math.Max(bC[o.TrueClass], 1e-12));
            uList.Add(u); vList.Add(v); dList.Add(d);
            bool fRight = Prob.Argmax(fC) == o.TrueClass, bRight = Prob.Argmax(bC) == o.TrueClass;
            if (fRight != bRight)
            {
                contested++;
                double sj = Prob.ForwardShare(u, v), ss = Prob.SharpnessShare(v);
                if ((sj > 0.5 && fRight) || (sj < 0.5 && bRight)) jointRight++;
                else if (sj == 0.5) jointNeutral++;
                else jointWrong++;
                if ((ss > 0.5 && fRight) || (ss < 0.5 && bRight)) sharpRight++;
                if (Math.Sign(u) != 0 && Math.Sign(u) == Math.Sign(v))
                {
                    agreeSign++;
                    if ((sj > 0.5 && fRight) || (sj < 0.5 && bRight)) agreeSignRight++;
                }
            }
        }
        double rhoU = Stats.Spearman(uList, dList), rhoV = Stats.Spearman(vList, dList);

        // 4. Position profile: forward and backward class accuracy along the span.
        var posRows = Enumerable.Range(0, T).Select(t =>
        {
            var at = data.Where(o => o.Pos == t).ToArray();
            double fa = at.Average(o => Prob.Argmax(Prob.Aggregate(o.F, m.AtomClass, m.Classes)) == o.TrueClass ? 1.0 : 0.0);
            double ba = at.Average(o => Prob.Argmax(Prob.Aggregate(o.B, m.AtomClass, m.Classes)) == o.TrueClass ? 1.0 : 0.0);
            double ea = at.Average(o => Prob.Argmax(Prob.Aggregate(o.Exact, m.AtomClass, m.Classes)) == o.TrueClass ? 1.0 : 0.0);
            double ja = at.Average(o => Prob.Argmax(Prob.Aggregate(Fuse("Joint score linear (Eq. 9.2)", o, m), m.AtomClass, m.Classes)) == o.TrueClass ? 1.0 : 0.0);
            return (IReadOnlyList<object>)new object[] { t + 1, fa, ba, ja, ea };
        }).ToArray();

        // 5. Importance: which pre- or post-sleep quantity predicts the realized gain of consolidation?
        var gains = new double[data.Count];
        var hF = new double[data.Count]; var js = new double[data.Count]; var kl = new double[data.Count]; var tv = new double[data.Count];
        var asym = new double[data.Count];
        for (int i = 0; i < data.Count; i++)
        {
            var o = data[i];
            var fC = Prob.Aggregate(o.F, m.AtomClass, m.Classes); var bC = Prob.Aggregate(o.B, m.AtomClass, m.Classes);
            var gC = Prob.Aggregate(o.Exact, m.AtomClass, m.Classes);
            gains[i] = Math.Log2(Math.Max(gC[o.TrueClass], 1e-12)) - Math.Log2(Math.Max(fC[o.TrueClass], 1e-12));
            hF[i] = Prob.EntropyBits(fC);
            js[i] = Prob.JsBits(fC, bC);
            kl[i] = Prob.KlBits(gC, fC);
            tv[i] = Prob.TotalVariation(fC, bC);
            asym[i] = Math.Abs(Prob.ForwardShare(Prob.Mixing(o.F, m.K) - Prob.Mixing(o.B, m.K), Prob.Sharpness(fC, m.Classes) - Prob.Sharpness(bC, m.Classes)) - 0.5);
        }
        var shuffleRng = Rng.Derive(Seed, 7);
        var randomPriority = new double[data.Count];
        for (int i = 0; i < data.Count; i++) (randomPriority[i], shuffleRng) = shuffleRng.NextDouble();

        var priorities = new (string Name, double[] P)[]
        {
            ("Random", randomPriority),
            ("Forward entropy (pre-sleep)", hF),
            ("|s - 1/2| from Eq. 9.2", asym),
            ("Directional TV", tv),
            ("Directional JS", js),
            ("KL(posterior || forward)", kl),
            ("Oracle realized gain", gains)
        };
        double totalGain = gains.Sum();
        var budgets = Enumerable.Range(1, 20).Select(i => i * 0.05).ToArray();
        var budgetRows = new List<IReadOnlyList<object>>();
        var corrRows = new List<IReadOnlyList<object>>();
        var captured30 = new Dictionary<string, double>();
        foreach (var (name, p) in priorities)
        {
            var order = Enumerable.Range(0, data.Count).OrderByDescending(i => p[i]).ThenBy(i => i).ToArray();
            var cum = new double[order.Length + 1];
            for (int k = 0; k < order.Length; k++) cum[k + 1] = cum[k] + gains[order[k]];
            foreach (var b in budgets)
            {
                int n = (int)Math.Round(b * order.Length);
                double share = cum[n] / totalGain;
                budgetRows.Add(new object[] { name, b, share });
                if (Math.Abs(b - 0.30) < 1e-9) captured30[name] = share;
            }
            corrRows.Add(new object[] { name, name == "Oracle realized gain" ? 1.0 : Stats.Spearman(p, gains) });
        }

        // 6. Skip rewrites whose consolidated change is small.
        var exactLoss = data.Average(o => Prob.LogLossBits(Prob.Aggregate(o.Exact, m.AtomClass, m.Classes), o.TrueClass));
        var skipRows = new List<IReadOnlyList<object>>();
        foreach (var theta in new[] { 0.0, 0.01, 0.02, 0.05, 0.10, 0.20 })
        {
            int skipped = 0; double loss = 0;
            foreach (var o in data)
            {
                var fC = Prob.Aggregate(o.F, m.AtomClass, m.Classes); var gC = Prob.Aggregate(o.Exact, m.AtomClass, m.Classes);
                bool skip = Prob.TotalVariation(gC, fC) < theta;
                if (skip) skipped++;
                loss += Prob.LogLossBits(skip ? fC : gC, o.TrueClass);
            }
            skipRows.Add(new object[] { theta, (double)skipped / data.Count, loss / data.Count, loss / data.Count - exactLoss });
        }

        var head = new Dictionary<string, double>
        {
            ["observations"] = data.Count,
            ["max_abs_error_decoupled_vs_enumeration"] = maxErr,
            ["max_abs_error_forward_backward_vs_enumeration"] = maxErrFb,
            ["spearman_u_reliability"] = rhoU,
            ["spearman_v_reliability"] = rhoV,
            ["contested"] = contested,
            ["contested_joint_right"] = (double)jointRight / contested,
            ["contested_sharpness_right"] = (double)sharpRight / contested,
            ["contested_joint_wrong"] = (double)jointWrong / contested,
            ["contested_joint_neutral"] = (double)jointNeutral / contested,
            ["contested_sign_agree_fraction"] = (double)agreeSign / contested,
            ["contested_sign_agree_right"] = agreeSign > 0 ? (double)agreeSignRight / agreeSign : double.NaN,
            ["max_abs_decoupled_vs_forward_backward"] = maxDecVsFb,
            ["total_gain_bits_per_obs"] = totalGain / data.Count,
            ["exact_logloss"] = exactLoss
        };
        foreach (var s in scores)
        {
            string key = new string(s.Policy.Where(char.IsLetterOrDigit).ToArray());
            head[$"acc_{key}"] = s.ClassAcc; head[$"atomacc_{key}"] = s.AtomAcc; head[$"ll_{key}"] = s.LogLossBits; head[$"mis_{key}"] = s.Misfiled;
        }
        foreach (var kv in captured30) head[$"captured30_{new string(kv.Key.Where(char.IsLetterOrDigit).ToArray())}"] = kv.Value;
        foreach (var row in corrRows) head[$"rho_{new string(((string)row[0]).Where(char.IsLetterOrDigit).ToArray())}"] = (double)row[1];

        return new ExperimentResult("A02", "Decoupled bidirectional consolidation on chain-structured spans",
            new[]
            {
                Table.Of("policies", new[] { "policy", "class_accuracy", "atom_accuracy", "logloss_bits", "misfiled_mass", "brier" }, policyRows),
                Table.Of("position", new[] { "position", "forward_acc", "backward_acc", "joint_linear_acc", "exact_acc" }, posRows),
                Table.Of("budget", new[] { "priority", "budget", "captured_gain_share" }, budgetRows),
                Table.Of("importance_corr", new[] { "priority", "spearman_with_gain" }, corrRows),
                Table.Of("skip", new[] { "theta", "fraction_skipped", "logloss_bits", "increase_vs_exact" }, skipRows)
            }, head);
    }
}
