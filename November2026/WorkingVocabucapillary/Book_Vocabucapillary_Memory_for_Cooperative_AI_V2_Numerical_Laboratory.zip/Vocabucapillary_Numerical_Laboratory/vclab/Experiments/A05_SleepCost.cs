using VcLab.Core;

namespace VcLab.Experiments;

/// <summary>Deterministic compute, memory and communication accounting for bidirectional sleep at scale.</summary>
public static class A05_SleepCost
{
    /// <summary>Per-layer FLOPs: projections 8Td^2, MLP 16Td^2, attention 4T^2 d (full) or 2T^2 d (causal).</summary>
    public static double PassFlops(double t, double d, double layers, bool joint) =>
        layers * (24.0 * t * d * d + (joint ? 4.0 : 2.0) * t * t * d);

    public static ExperimentResult Run()
    {
        var head = new Dictionary<string, double>();
        var computeRows = new List<IReadOnlyList<object>>();
        foreach (var (d, layers) in new[] { (4096.0, 32.0), (8192.0, 80.0) })
            foreach (var t in new[] { 4096.0, 32768.0, 262144.0, 1048576.0 })
            {
                double rev = PassFlops(t, d, layers, false);
                double joint = PassFlops(t, d, layers, true);
                double save = (joint - rev) / joint;
                double kvSpanGiB = 2 * layers * t * d * 2 / Math.Pow(2, 30);
                computeRows.Add(new object[] { d, layers, t, rev, joint, save, t / (12 * d + 2 * t), kvSpanGiB });
                head[$"save_d{d}_T{t}"] = save;
            }

        var crossoverRows = new List<IReadOnlyList<object>>();
        const double dk = 128, dv = 128;
        foreach (var m in new[] { 4096.0, 16384.0, 65536.0 })
        {
            double bank = m * (dv + 1) * 4;
            double perToken = (dk + dv) * 2;
            double tc = bank / perToken;
            crossoverRows.Add(new object[] { m, bank, perToken, tc });
            head[$"crossover_M{m}"] = tc;
        }

        var commRows = new List<IReadOnlyList<object>>();
        const double atoms = 1 << 20, q = 8;
        foreach (var d in new[] { 16384.0, 32768.0, 65536.0 })
            foreach (var kk in new[] { 16.0, 32.0, 64.0 })
            {
                double dense = 2 * d;
                double sparse = Math.Ceiling(kk * (Math.Ceiling(Math.Log2(atoms)) + q) / 8.0);
                commRows.Add(new object[] { d, kk, dense, sparse, dense / sparse });
                head[$"comm_ratio_d{d}_k{kk}"] = dense / sparse;
            }

        // Fraction of total compute spent asleep for selective replay and clustered spans.
        var fracRows = new List<IReadOnlyList<object>>();
        {
            double d = 8192, layers = 80, t = 32768;
            double wake = PassFlops(t, d, layers, false);
            foreach (var budget in new[] { 1.0, 0.5, 0.3, 0.1 })
                foreach (var clusters in new[] { 1.0, 4.0, 16.0 })
                {
                    double perCluster = PassFlops(t / clusters, d, layers, false) * clusters;
                    double sleep = budget * perCluster;
                    double frac = sleep / (wake + sleep);
                    fracRows.Add(new object[] { budget, clusters, sleep / wake, frac });
                    head[$"sleepfrac_b{budget}_c{clusters}"] = frac;
                }
        }

        // Illustrative storage arithmetic for a 120-trillion-parameter network.
        double parameters = 1.2e14, nodeBytes = 288e9;
        head["nodes_for_120T_fp8"] = Math.Ceiling(parameters / nodeBytes);

        return new ExperimentResult("A05", "Compute, memory and communication accounting",
            new[]
            {
                Table.Of("compute", new[] { "d", "layers", "span_tokens", "reverse_pass_flops", "joint_pass_flops", "saving_vs_joint", "closed_form", "kv_span_GiB" }, computeRows),
                Table.Of("crossover", new[] { "atoms_M", "bank_bytes_per_head_layer", "kv_bytes_per_token", "crossover_tokens" }, crossoverRows),
                Table.Of("communication", new[] { "d", "k", "dense_bytes", "coefficient_bytes", "ratio" }, commRows),
                Table.Of("sleep_fraction", new[] { "replay_budget", "clusters", "sleep_over_wake", "sleep_fraction" }, fracRows)
            }, head);
    }
}
