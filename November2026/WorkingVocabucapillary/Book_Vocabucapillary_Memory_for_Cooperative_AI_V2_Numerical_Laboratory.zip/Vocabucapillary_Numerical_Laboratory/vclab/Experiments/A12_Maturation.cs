using VcLab.Core;

namespace VcLab.Experiments;

/// <summary>
/// Juvenile and mature caches. Freezing the native vocabulary keeps stored coefficients meaningful;
/// continued native plasticity re-interprets them. A frozen native vocabulary cannot separate a new
/// distinction (Eq. 11.1), which a juvenile successor can. Context gating limits association interference.
/// </summary>
public static class A12_Maturation
{
    public const ulong Seed = 20261203UL;
    private const int D = 16, Classes = 24, Atoms = 24, Juvenile = 20000, Mature = 40000, Stored = 2000;

    public sealed record Dict(IReadOnlyList<IReadOnlyList<double>> Atoms, IReadOnlyList<int> Counts);

    private static double Dist2(IReadOnlyList<double> a, IReadOnlyList<double> b) { double s = 0; for (int i = 0; i < a.Count; i++) { double t = a[i] - b[i]; s += t * t; } return s; }

    private static int Nearest(Dict d, IReadOnlyList<double> x)
    {
        int best = 0; double bd = double.PositiveInfinity;
        for (int j = 0; j < d.Atoms.Count; j++) { double dd = Dist2(d.Atoms[j], x); if (dd < bd) { bd = dd; best = j; } }
        return best;
    }

    /// <summary>Online k-means update; returns a new dictionary (count-based or constant rate).</summary>
    private static Dict Update(Dict d, IReadOnlyList<double> x, double? constantRate)
    {
        int j = Nearest(d, x);
        var atoms = d.Atoms.ToArray(); var counts = d.Counts.ToArray();
        counts[j]++;
        double eta = constantRate ?? 1.0 / (counts[j] + 1);
        atoms[j] = d.Atoms[j].Select((v, i) => v + eta * (x[i] - v)).ToArray();
        return new Dict(atoms, counts);
    }

    /// <summary>Native simplex code over the two nearest atoms.</summary>
    public static IReadOnlyList<double> Code(Dict d, IReadOnlyList<double> x)
    {
        var dist = d.Atoms.Select(a => Dist2(a, x)).ToArray();
        var idx = Enumerable.Range(0, dist.Length).OrderBy(i => dist[i]).Take(2).ToArray();
        var w = idx.Select(i => Math.Exp(-(dist[i] - dist[idx[0]]) / 1.0)).ToArray();
        double s = w.Sum();
        var code = new double[d.Atoms.Count];
        for (int k = 0; k < 2; k++) code[idx[k]] = w[k] / s;
        return code;
    }

    private static IReadOnlyList<double> Decode(Dict d, IReadOnlyList<double> code)
    {
        var x = new double[D];
        for (int j = 0; j < code.Count; j++) if (code[j] > 0) for (int i = 0; i < D; i++) x[i] += code[j] * d.Atoms[j][i];
        return x;
    }

    private static (IReadOnlyList<double> X, Rng Next) Observe(IReadOnlyList<double> center, Rng rng)
    {
        var x = new double[D];
        for (int i = 0; i < D; i++) { double z; (z, rng) = rng.NextGaussian(); x[i] = center[i] + 0.3 * z; }
        return (x, rng);
    }

    private static (IReadOnlyList<double> V, Rng Next) RandomCenter(Rng rng)
    {
        var v = new double[D];
        for (int i = 0; i < D; i++) (v[i], rng) = rng.NextGaussian();
        double n = Math.Sqrt(v.Sum(t => t * t));
        return (v.Select(t => 2.0 * t / n).ToArray(), rng);
    }

    private static IReadOnlyList<IReadOnlyList<double>> Prototypes(IEnumerable<(IReadOnlyList<double> Code, int Label)> data, int classes, int atoms)
    {
        var sums = Enumerable.Range(0, classes).Select(_ => new double[atoms]).ToArray(); var counts = new int[classes];
        foreach (var (c, l) in data) { counts[l]++; for (int j = 0; j < atoms; j++) sums[l][j] += c[j]; }
        return sums.Select((s, l) => (IReadOnlyList<double>)s.Select(v => counts[l] > 0 ? v / counts[l] : 0.0).ToArray()).ToArray();
    }

    private static int Classify(IReadOnlyList<IReadOnlyList<double>> protos, IReadOnlyList<double> code)
    {
        int best = 0; double bd = double.PositiveInfinity;
        for (int k = 0; k < protos.Count; k++) { double d = 0; for (int j = 0; j < code.Count; j++) d += Math.Abs(protos[k][j] - code[j]); if (d < bd) { bd = d; best = k; } }
        return best;
    }

    public static ExperimentResult Run()
    {
        var rng = Rng.Derive(Seed, 1);
        var centers = new IReadOnlyList<double>[Classes + 1];
        for (int k = 0; k <= Classes; k++) (centers[k], rng) = RandomCenter(rng);

        // Juvenile phase: learn the native vocabulary.
        var init = new IReadOnlyList<double>[Atoms];
        for (int j = 0; j < Atoms; j++) (init[j], rng) = Observe(centers[j], rng);
        var dict = new Dict(init, new int[Atoms]);
        var movement = new List<IReadOnlyList<object>>();
        var snapshot = dict;
        for (int t = 1; t <= Juvenile; t++)
        {
            int k; (k, rng) = rng.NextInt(Classes);
            IReadOnlyList<double> x; (x, rng) = Observe(centers[k], rng);
            dict = Update(dict, x, null);
            if (t % 1000 == 0)
            {
                double mv = Enumerable.Range(0, Atoms).Average(j => Math.Sqrt(Dist2(dict.Atoms[j], snapshot.Atoms[j])));
                movement.Add(new object[] { t, mv });
                snapshot = dict;
            }
        }
        var juvenileDict = dict;
        // Stored long-term memories: coefficients only, with their source vectors kept for evaluation.
        var stored = new List<(IReadOnlyList<double> X, IReadOnlyList<double> Code, int Label)>();
        for (int i = 0; i < Stored; i++)
        {
            int k; (k, rng) = rng.NextInt(Classes);
            IReadOnlyList<double> x; (x, rng) = Observe(centers[k], rng);
            stored.Add((x, Code(juvenileDict, x), k));
        }
        var juvenileProtos = Prototypes(stored.Select(s => (s.Code, s.Label)), Classes, Atoms);

        // Mature phase with drift and a novel distinction.
        var plastic = juvenileDict;
        var drifting = centers.ToArray();
        var series = new List<IReadOnlyList<object>>();
        var matureObs = new List<(IReadOnlyList<double> X, int Label)>();
        for (int t = 1; t <= Mature; t++)
        {
            if (t % 1000 == 0)
                for (int k = 0; k < Classes; k++)
                {
                    var c = drifting[k].ToArray();
                    for (int i = 0; i < D; i++) { double z; (z, rng) = rng.NextGaussian(); c[i] += 0.03 * z; }
                    drifting[k] = c;
                }
            int label;
            bool novel = false;
            if (t > 10000) (novel, rng) = rng.NextBernoulli(1.0 / (Classes + 1));
            if (novel) label = Classes; else (label, rng) = rng.NextInt(Classes);
            IReadOnlyList<double> x; (x, rng) = Observe(drifting[label], rng);
            matureObs.Add((x, label));
            plastic = Update(plastic, x, 0.02);
            if (t % 2000 == 0)
            {
                double errPlastic = stored.Average(s => Dist2(Decode(plastic, s.Code), Decode(juvenileDict, s.Code)));
                double errFrozen = 0.0;   // frozen vocabulary: stored coefficients keep their juvenile-time meaning exactly
                var recent = matureObs.Skip(Math.Max(0, matureObs.Count - 2000)).Where(o => o.Label < Classes).ToArray();
                double accPlastic = recent.Average(o => Classify(juvenileProtos, Code(plastic, o.X)) == o.Label ? 1.0 : 0.0);
                double accFrozen = recent.Average(o => Classify(juvenileProtos, Code(juvenileDict, o.X)) == o.Label ? 1.0 : 0.0);
                series.Add(new object[] { t, errPlastic, errFrozen, accPlastic, accFrozen });
            }
        }

        // Novel distinction: association prototypes retrained on recent labelled data for three native choices.
        var labelled = matureObs.Skip(Mature - 15000).ToArray();
        var trainSet = labelled.Take(10000).ToArray(); var evalSet = labelled.Skip(10000).ToArray();
        // Juvenile successor: a fresh native vocabulary learned from current data; atom identities are arbitrary.
        var permRng = Rng.Derive(Seed, 12);
        var permuted = Enumerable.Range(0, Classes + 1).ToArray();
        for (int i = permuted.Length - 1; i > 0; i--) { int j; (j, permRng) = permRng.NextInt(i + 1); (permuted[i], permuted[j]) = (permuted[j], permuted[i]); }
        var successor = new Dict(permuted.Select(c => drifting[c]).ToArray(), new int[Atoms + 1]);
        foreach (var (x, _) in trainSet) successor = Update(successor, x, null);
        (double Novel, double Old) NovelAcc(Dict d)
        {
            var protos = Prototypes(trainSet.Select(o => (Code(d, o.X), o.Label)), Classes + 1, d.Atoms.Count);
            var novelEval = evalSet.Where(o => o.Label == Classes).ToArray();
            var oldEval = evalSet.Where(o => o.Label < Classes).ToArray();
            double novelAcc = novelEval.Average(o => Classify(protos, Code(d, o.X)) == o.Label ? 1.0 : 0.0);
            double oldAcc = oldEval.Average(o => Classify(protos, Code(d, o.X)) == o.Label ? 1.0 : 0.0);
            return (novelAcc, oldAcc);
        }
        double successorDrift = stored.Average(s => Dist2(Decode(successor, s.Code.Concat(new[] { 0.0 }).ToArray()), Decode(juvenileDict, s.Code)));
        double noiseFloor = stored.Average(s => Dist2(Decode(juvenileDict, s.Code), s.X));
        var recentOld = matureObs.Skip(Mature - 2000).Where(o => o.Label < Classes).ToArray();
        double successorOldReadout = recentOld.Average(o => Classify(juvenileProtos, Code(successor, o.X).Take(Atoms).ToArray()) == o.Label ? 1.0 : 0.0);
        var (novelFrozen, oldFrozenRetrained) = NovelAcc(juvenileDict);
        var (novelPlastic, oldPlasticRetrained) = NovelAcc(plastic);
        var (novelSuccessor, oldSuccessor) = NovelAcc(successor);
        // Nearest old class to the novel centre, as a collision diagnostic.
        double nearest = Enumerable.Range(0, Classes).Min(k => Math.Sqrt(Dist2(drifting[k], drifting[Classes])));

        // Context gating of association plasticity (prefrontal selection of writable coefficients).
        var gateRows = new List<IReadOnlyList<object>>();
        var proj = new double[64][];
        var gr = Rng.Derive(Seed, 9);
        for (int u = 0; u < 64; u++) { proj[u] = new double[Atoms]; for (int j = 0; j < Atoms; j++) { double z; (z, gr) = gr.NextGaussian(); proj[u][j] = z; } }
        IReadOnlyList<double> Features(IReadOnlyList<double> code) => proj.Select(p => Math.Max(0, p.Zip(code, (a, b) => a * b).Sum())).ToArray();
        var gateData = stored.Select(s => (F: Features(s.Code), s.Label)).ToArray();
        int Task1(int l) => l < Classes / 2 ? 1 : 0;
        int Task2(int l) => l % 2;
        foreach (var mode in new[] { "No gating", "Context gating, 50% of units", "Separate readouts" })
        {
            var mask1 = new bool[64]; var mask2 = new bool[64];
            var mr = Rng.Derive(Seed, 10);
            for (int u = 0; u < 64; u++)
            {
                if (mode == "No gating") { mask1[u] = mask2[u] = true; continue; }
                if (mode == "Separate readouts") { mask1[u] = mask2[u] = true; continue; }
                (mask1[u], mr) = mr.NextBernoulli(0.5); (mask2[u], mr) = mr.NextBernoulli(0.5);
            }
            var w = new double[2][] { new double[65], new double[65] };
            int head2 = mode == "Separate readouts" ? 1 : 0;
            double Predict(double[] wt, IReadOnlyList<double> f, bool[] mask)
            {
                double s = wt[64]; for (int u = 0; u < 64; u++) if (mask[u]) s += wt[u] * f[u];
                return 1.0 / (1.0 + Math.Exp(-s));
            }
            void Train(double[] wt, Func<int, int> task, bool[] mask, int steps, ref Rng r)
            {
                for (int s = 0; s < steps; s++)
                {
                    int i; (i, r) = r.NextInt(gateData.Length);
                    var (f, l) = gateData[i];
                    double g = Predict(wt, f, mask) - task(l);
                    for (int u = 0; u < 64; u++) if (mask[u]) wt[u] -= 0.05 * g * f[u];
                    wt[64] -= 0.05 * g;
                }
            }
            double Acc(double[] wt, Func<int, int> task, bool[] mask) => gateData.Average(d => (Predict(wt, d.F, mask) > 0.5 ? 1 : 0) == task(d.Label) ? 1.0 : 0.0);
            var tr = Rng.Derive(Seed, 11);
            Train(w[0], Task1, mask1, 20000, ref tr);
            double t1Before = Acc(w[0], Task1, mask1);
            Train(w[head2], Task2, mask2, 20000, ref tr);
            double t1After = Acc(w[0], Task1, mask1), t2After = Acc(w[head2], Task2, mask2);
            gateRows.Add(new object[] { mode, t1Before, t1After, t2After });
        }

        var last = series[^1];
        var head = new Dictionary<string, double>
        {
            ["juvenile_movement_first"] = (double)movement[0][1], ["juvenile_movement_last"] = (double)movement[^1][1],
            ["decode_err_plastic_end"] = (double)last[1], ["decode_err_frozen_end"] = (double)last[2],
            ["old_acc_plastic_end"] = (double)last[3], ["old_acc_frozen_end"] = (double)last[4],
            ["novel_acc_frozen"] = novelFrozen, ["novel_acc_plastic"] = novelPlastic, ["novel_acc_successor"] = novelSuccessor,
            ["successor_meaning_drift"] = successorDrift, ["noise_floor"] = noiseFloor, ["successor_old_readout_acc"] = successorOldReadout,
            ["old_acc_retrained_frozen"] = oldFrozenRetrained, ["old_acc_retrained_plastic"] = oldPlasticRetrained, ["old_acc_successor"] = oldSuccessor,
            ["novel_nearest_old_distance"] = nearest
        };
        foreach (var r in gateRows)
        {
            string key = new string(((string)r[0]).Where(char.IsLetterOrDigit).ToArray());
            head[$"gate_{key}_t1before"] = (double)r[1]; head[$"gate_{key}_t1after"] = (double)r[2]; head[$"gate_{key}_t2"] = (double)r[3];
        }
        return new ExperimentResult("A12", "Juvenile and mature caches",
            new[]
            {
                Table.Of("juvenile_movement", new[] { "tokens", "mean_atom_movement" }, movement),
                Table.Of("mature_series", new[] { "mature_tokens", "meaning_drift_plastic", "meaning_drift_frozen", "old_class_acc_plastic", "old_class_acc_frozen" }, series),
                Table.Of("gating", new[] { "mode", "task1_before", "task1_after_task2", "task2" }, gateRows)
            }, head);
    }
}
