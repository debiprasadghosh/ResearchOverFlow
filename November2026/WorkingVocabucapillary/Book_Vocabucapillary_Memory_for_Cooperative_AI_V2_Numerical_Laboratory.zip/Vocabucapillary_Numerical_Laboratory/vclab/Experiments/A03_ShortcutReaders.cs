using VcLab.Core;

namespace VcLab.Experiments;

/// <summary>
/// Two-layer attention readers in each direction. A salient shortcut token can capture attention,
/// narrowing the middle-layer mixture while the overconfident final layer remains sharp.
/// Tests when the middle-mixing term of Eq. 9.2 adds information beyond final sharpness.
/// </summary>
public static class A03_ShortcutReaders
{
    public const ulong Seed = 20261125UL;
    private const int L = 4, R = 3, K = L * R, Window = 8;

    public sealed record ReaderOut(IReadOnlyList<double> Middle, IReadOnlyList<double> Final);

    public sealed record Setting(double ShortcutReliability, double Beta, double SalientProb = 0.5, double InformativeProb = 0.45,
        double CueReliability = 0.7, double SalientLogit = 3.0, double GenericLogit = -0.5, bool NoisyDirection = false);

    private static readonly int[] AtomClass = Enumerable.Range(0, K).Select(z => z / R).ToArray();

    private static (int Value, Rng Next) PointClass(int truth, double reliability, Rng rng)
    {
        var (ok, r1) = rng.NextBernoulli(reliability);
        if (ok) return (truth, r1);
        return r1.NextIntExcept(L, truth);
    }

    public static (ReaderOut Out, Rng Next) Read(int truth, Setting s, bool noisy, Rng rng)
    {
        var codes = new List<double[]>(); var logits = new List<double>();
        bool salient; (salient, rng) = rng.NextBernoulli(s.SalientProb);
        for (int j = 0; j < Window; j++)
        {
            if (j == 0 && salient)
            {
                int c; (c, rng) = PointClass(truth, s.ShortcutReliability, rng);
                int a; (a, rng) = rng.NextInt(R);
                var code = new double[K]; code[c * R + a] = 1.0;
                codes.Add(code); logits.Add(s.SalientLogit);
                continue;
            }
            bool inf; (inf, rng) = rng.NextBernoulli(noisy ? 0.15 : s.InformativeProb);
            if (inf)
            {
                int c; (c, rng) = PointClass(truth, s.CueReliability, rng);
                var code = new double[K]; for (int a = 0; a < R; a++) code[c * R + a] = 1.0 / R;
                codes.Add(code); logits.Add(0.0);
            }
            else
            {
                codes.Add(Enumerable.Repeat(1.0 / K, K).ToArray());
                logits.Add(noisy ? 1.0 : s.GenericLogit);
            }
        }
        var w = Prob.Softmax(logits);
        var middle = new double[K];
        for (int j = 0; j < codes.Count; j++) for (int q = 0; q < K; q++) middle[q] += w[j] * codes[j][q];
        var classMass = Prob.Aggregate(middle, AtomClass, L);
        var final = Prob.Softmax(classMass, s.Beta);
        return (new ReaderOut(middle, final), rng);
    }

    public static readonly string[] Policies =
    {
        "Forward only", "Backward only", "Equal linear", "Sharpness-only linear", "Mixing-only linear", "Joint score linear (Eq. 9.2)",
        "Learned share from (u, v)", "Product", "Tempered product, joint share", "Oracle direction"
    };

    public sealed record ShareModel(double A, double B, double C)
    {
        public double Share(double u, double v) => 1.0 / (1.0 + Math.Exp(-(A * u + B * v + C)));
    }

    public static IReadOnlyList<double> Fuse(string policy, ReaderOut f, ReaderOut b, int truth, ShareModel? learned = null)
    {
        double u = Prob.Mixing(f.Middle, K) - Prob.Mixing(b.Middle, K);
        double v = Prob.Sharpness(f.Final, L) - Prob.Sharpness(b.Final, L);
        return policy switch
        {
            "Mixing-only linear" => Prob.Linear(f.Final, b.Final, 0.5 * (1.0 + u)),
            "Learned share from (u, v)" => Prob.Linear(f.Final, b.Final, (learned ?? new ShareModel(0, 0, 0)).Share(u, v)),
            "Forward only" => f.Final,
            "Backward only" => b.Final,
            "Equal linear" => Prob.Linear(f.Final, b.Final, 0.5),
            "Sharpness-only linear" => Prob.Linear(f.Final, b.Final, Prob.SharpnessShare(v)),
            "Joint score linear (Eq. 9.2)" => Prob.Linear(f.Final, b.Final, Prob.ForwardShare(u, v)),
            "Product" => Prob.Product(f.Final, b.Final),
            "Tempered product, joint share" => Prob.TemperedProduct(f.Final, b.Final, null, Prob.ForwardShare(u, v)),
            "Oracle direction" => f.Final[truth] >= b.Final[truth] ? f.Final : b.Final,
            _ => throw new ArgumentException(policy)
        };
    }

    /// <summary>Fit s = sigmoid(a u + b v + c) on a development stream by minimising log loss (Adam).</summary>
    public static ShareModel FitShare(Setting s, int n, ulong stream)
    {
        var rng = Rng.Derive(Seed, stream + 50000);
        var data = new List<(double U, double V, double Fy, double By)>();
        for (int i = 0; i < n; i++)
        {
            int truth; (truth, rng) = rng.NextInt(L);
            bool noisyForward = false;
            if (s.NoisyDirection) (noisyForward, rng) = rng.NextBernoulli(0.5);
            ReaderOut f, b;
            (f, rng) = Read(truth, s, s.NoisyDirection && noisyForward, rng);
            (b, rng) = Read(truth, s, s.NoisyDirection && !noisyForward, rng);
            data.Add((Prob.Mixing(f.Middle, K) - Prob.Mixing(b.Middle, K), Prob.Sharpness(f.Final, L) - Prob.Sharpness(b.Final, L), f.Final[truth], b.Final[truth]));
        }
        var theta = new double[3]; var m = new double[3]; var v2 = new double[3];
        for (int it = 1; it <= 400; it++)
        {
            var g = new double[3];
            foreach (var d in data)
            {
                double z = theta[0] * d.U + theta[1] * d.V + theta[2];
                double sh = 1.0 / (1.0 + Math.Exp(-z));
                double alpha = Math.Max(sh * d.Fy + (1 - sh) * d.By, 1e-12);
                double dLds = -(d.Fy - d.By) / alpha;
                double ds = sh * (1 - sh);
                g[0] += dLds * ds * d.U / n; g[1] += dLds * ds * d.V / n; g[2] += dLds * ds / n;
            }
            for (int k = 0; k < 3; k++)
            {
                m[k] = 0.9 * m[k] + 0.1 * g[k]; v2[k] = 0.999 * v2[k] + 0.001 * g[k] * g[k];
                double mh = m[k] / (1 - Math.Pow(0.9, it)), vh = v2[k] / (1 - Math.Pow(0.999, it));
                theta[k] -= 0.05 * mh / (Math.Sqrt(vh) + 1e-8);
            }
        }
        return new ShareModel(theta[0], theta[1], theta[2]);
    }

    public static IReadOnlyDictionary<string, (double Acc, double Ll)> Evaluate(Setting s, int n, ulong stream, ShareModel? learned = null)
    {
        var rng = Rng.Derive(Seed, stream);
        var acc = Policies.ToDictionary(p => p, _ => 0.0);
        var ll = Policies.ToDictionary(p => p, _ => 0.0);
        for (int i = 0; i < n; i++)
        {
            int truth; (truth, rng) = rng.NextInt(L);
            bool noisyForward = false;
            if (s.NoisyDirection) (noisyForward, rng) = rng.NextBernoulli(0.5);
            ReaderOut f, b;
            (f, rng) = Read(truth, s, s.NoisyDirection && noisyForward, rng);
            (b, rng) = Read(truth, s, s.NoisyDirection && !noisyForward, rng);
            foreach (var p in Policies)
            {
                var a = Fuse(p, f, b, truth, learned);
                if (Prob.Argmax(a) == truth) acc[p] += 1;
                ll[p] += Prob.LogLossBits(a, truth);
            }
        }
        return Policies.ToDictionary(p => p, p => (acc[p] / n, ll[p] / n));
    }

    public static ExperimentResult Run()
    {
        const int n = 20000;
        var reliabilities = new[] { 0.25, 0.40, 0.55, 0.70, 0.85, 1.00 };
        var betas = new[] { 2.0, 4.0, 8.0, 16.0, 32.0 };
        var gridRows = new List<IReadOnlyList<object>>();
        ulong stream = 1;
        double minDiff = double.PositiveInfinity, maxDiff = double.NegativeInfinity;
        foreach (var rs in reliabilities)
            foreach (var beta in betas)
            {
                var setting = new Setting(rs, beta);
                var learned = FitShare(setting, 8000, stream);
                var res = Evaluate(setting, n, stream++, learned);
                double diff = res["Joint score linear (Eq. 9.2)"].Acc - res["Sharpness-only linear"].Acc;
                minDiff = Math.Min(minDiff, diff); maxDiff = Math.Max(maxDiff, diff);
                gridRows.Add(new object[]
                {
                    rs, beta, res["Sharpness-only linear"].Acc, res["Joint score linear (Eq. 9.2)"].Acc, diff,
                    res["Equal linear"].Acc, res["Product"].Acc, res["Tempered product, joint share"].Acc, res["Oracle direction"].Acc,
                    res["Mixing-only linear"].Acc, res["Learned share from (u, v)"].Acc, res["Forward only"].Acc, learned.A, learned.B
                });
            }

        // Representative settings with all policies.
        var settings = new (string Name, Setting S)[]
        {
            ("Unreliable shortcut (r_s=0.40, beta=16)", new Setting(0.40, 16)),
            ("Reliable shortcut (r_s=1.00, beta=16)", new Setting(1.00, 16)),
            ("Calibrated-ish reader (r_s=0.40, beta=2)", new Setting(0.40, 2)),
            ("Noise-inflated mixing (r_s=0.85, beta=16)", new Setting(0.85, 16, NoisyDirection: true))
        };
        var detailRows = new List<IReadOnlyList<object>>();
        var head = new Dictionary<string, double> { ["min_joint_minus_sharp"] = minDiff, ["max_joint_minus_sharp"] = maxDiff, ["n_per_cell"] = n };
        int si = 0;
        foreach (var (name, s) in settings)
        {
            var learned = FitShare(s, 20000, 1000 + (ulong)si);
            var res = Evaluate(s, 40000, 1000 + (ulong)si, learned);
            foreach (var p in Policies) detailRows.Add(new object[] { name, p, res[p].Acc, res[p].Ll });
            head[$"s{si}_joint"] = res["Joint score linear (Eq. 9.2)"].Acc;
            head[$"s{si}_sharp"] = res["Sharpness-only linear"].Acc;
            head[$"s{si}_equal"] = res["Equal linear"].Acc;
            head[$"s{si}_product"] = res["Product"].Acc;
            head[$"s{si}_tempered"] = res["Tempered product, joint share"].Acc;
            head[$"s{si}_oracle"] = res["Oracle direction"].Acc;
            head[$"s{si}_forward"] = res["Forward only"].Acc;
            head[$"s{si}_mixing"] = res["Mixing-only linear"].Acc;
            head[$"s{si}_learned"] = res["Learned share from (u, v)"].Acc;
            head[$"s{si}_learned_a"] = learned.A; head[$"s{si}_learned_b"] = learned.B; head[$"s{si}_learned_c"] = learned.C;
            head[$"s{si}_ll_equal"] = res["Equal linear"].Ll;
            head[$"s{si}_ll_learned"] = res["Learned share from (u, v)"].Ll;
            head[$"s{si}_ll_joint"] = res["Joint score linear (Eq. 9.2)"].Ll;
            head[$"s{si}_ll_sharp"] = res["Sharpness-only linear"].Ll;
            head[$"s{si}_ll_tempered"] = res["Tempered product, joint share"].Ll;
            head[$"s{si}_ll_product"] = res["Product"].Ll;
            si++;
        }

        return new ExperimentResult("A03", "Shortcut readers and the middle-mixing term",
            new[]
            {
                Table.Of("grid", new[] { "shortcut_reliability", "beta", "sharpness_only", "joint", "joint_minus_sharpness", "equal", "product", "tempered_joint", "oracle", "mixing_only", "learned", "forward_only", "learned_a_u", "learned_b_v" }, gridRows),
                Table.Of("detail", new[] { "setting", "policy", "accuracy", "logloss_bits" }, detailRows)
            }, head);
    }
}
