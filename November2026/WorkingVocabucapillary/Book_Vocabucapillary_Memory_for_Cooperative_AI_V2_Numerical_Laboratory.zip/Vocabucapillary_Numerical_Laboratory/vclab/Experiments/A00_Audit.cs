using VcLab.Core;

namespace VcLab.Experiments;

/// <summary>Recomputes every worked numerical value stated in Chapters 3-13 and Appendix A.</summary>
public static class A00_Audit
{
    private sealed record Item(string Chapter, string Quantity, string Book, double Value, int Digits);

    private static double H(params double[] p) => Prob.EntropyBits(p);

    public static ExperimentResult Run()
    {
        var items = new List<Item>();
        void Add(string ch, string q, string book, double v, int digits) => items.Add(new Item(ch, q, book, v, digits));

        // Readiness check and prerequisites
        Add("Readiness", "Entropy of (0.5,0.5,0,0) in bits", "1", H(0.5, 0.5, 0, 0), 0);

        // Chapter 3, Exercise 3
        double saving = 256 - 16 - 64 - 48;
        Add("Ch 3", "Saving per occurrence (bits)", "128", saving, 0);
        Add("Ch 3", "Smallest occurrence count with strict saving", "8193", Math.Floor(1048576.0 / saving) + 1, 0);
        Add("Ch 3", "Coded occurrence cost with 192 residual bits", "272", 16 + 64 + 192, 0);

        // Chapter 4
        Add("Ch 4", "Average of exp(-1) and exp(+1)", "1.543", Math.Cosh(1.0), 3);
        double read = (6 * 0.8 + 3 * 0.2) / 9.0;
        Add("Ch 4", "Visited-row read", "0.6", read, 1);
        Add("Ch 4", "Omitted response fraction bound", "0.1", 1.0 / (9.0 + 1.0), 1);
        Add("Ch 4", "Observed margin for actions r and -r", "1.2", 2 * read, 1);
        Add("Ch 4", "Sufficient margin 2L(2V rho)", "0.4", 2 * 1 * (2 * 1 * 0.1), 1);
        Add("Ch 4", "HOLD/RELEASE mass", "2", 1 + 1, 0);
        Add("Ch 4", "HOLD/RELEASE payload sum", "0", -1 + 1, 0);

        // Chapter 6
        double eta = 8.0 / 255.0;
        double er = 1.0 * (0.010 + 1.0 * eta) + 0.005;
        Add("Ch 6", "Sufficient margin 2E_r", "0.092745", 2 * er, 6);
        var (last, dedup, rev) = Orders();
        Add("Ch 6", "Orders ending on revision 17, keep last arrival", "4", last, 0);
        Add("Ch 6", "Orders ending on revision 17, deduplicate only", "2", dedup, 0);
        Add("Ch 6", "Orders ending on revision 17, deduplicate and check revision", "0", rev, 0);

        // Chapter 7
        double dense = 64 + Math.Ceiling(4096 * 16 / 8.0);
        double sparse = 64 + Math.Ceiling(8 * (Math.Ceiling(Math.Log2(4096)) + 8) / 8.0);
        Add("Ch 7", "Dense application record (bytes)", "8,256", dense, 0);
        Add("Ch 7", "Sparse application record (bytes)", "84", sparse, 0);
        Add("Ch 7", "Dense-to-sparse size ratio", "98.3", dense / sparse, 1);
        Add("Ch 7", "Dense, resend every read (bytes)", "8,256,000", 1000 * dense, 0);
        Add("Ch 7", "Sparse, resend every read (bytes)", "84,000", 1000 * sparse, 0);
        Add("Ch 7", "Dense with cache (bytes)", "826,240", 100 * dense + 10 * 64, 0);
        Add("Ch 7", "Sparse with cache (bytes)", "9,040", 100 * sparse + 10 * 64, 0);
        double dict = 4096.0 * 4096.0 * 2.0;
        Add("Ch 7", "Full FP16 dictionary (bytes)", "33,554,432", dict, 0);
        Add("Ch 7", "Saving per sparse fill (bytes)", "8,172", dense - sparse, 0);
        Add("Ch 7", "Fills for strict dictionary amortization", "4,107", Math.Floor(dict / (dense - sparse)) + 1, 0);
        Add("Ch 7", "Replica storage for 10,000 recipients (GiB)", "312.5", 10000 * dict / Math.Pow(2, 30), 1);
        Add("Ch 7", "Exercise 7 sparse traffic (bytes)", "18,080", 200 * sparse + 20 * 64, 0);
        Add("Ch 7", "Exercise 7 saving of 4,000 fills (bytes)", "32,688,000", 4000 * (dense - sparse), 0);

        // Chapter 9
        double mf = Prob.Mixing(new[] { 0.25, 0.25, 0.25, 0.25 }, 4), mb = Prob.Mixing(new[] { 0.5, 0.5, 0, 0 }, 4);
        double cf = Prob.Sharpness(new[] { 0.95, 0.05 }, 2), cb = Prob.Sharpness(new[] { 0.40, 0.60 }, 2);
        double u = mf - mb, v = cf - cb, s = Prob.ForwardShare(u, v);
        double layout = s * 0.95 + (1 - s) * 0.40;
        Add("Ch 9", "Forward mixing score", "1", mf, 0);
        Add("Ch 9", "Backward mixing score", "0.5", mb, 1);
        Add("Ch 9", "Forward sharpness", "0.713603", cf, 6);
        Add("Ch 9", "Backward sharpness", "0.029049", cb, 6);
        Add("Ch 9", "Sharpness advantage v", "0.684554", v, 6);
        Add("Ch 9", "Forward share s", "0.792522", s, 6);
        Add("Ch 9", "Fused layout probability", "0.835887", layout, 6);
        Add("Ch 9", "Fused detail probability", "0.164113", 1 - layout, 6);
        Add("Ch 9", "Layout contribution (observation-days)", "8.35887", 10 * layout, 5);
        Add("Ch 9", "New layout mean (days)", "7.179", (12 + 10 * layout) / (2 + layout), 3);
        Add("Ch 9", "Total variation A", "0.55", Prob.TotalVariation(new[] { 0.95, 0.05 }, new[] { 0.40, 0.60 }), 2);
        Add("Ch 9", "Mass moved by sleep (1-s)A", "0.114113", (1 - s) * 0.55, 6);
        Add("Ch 9", "Squared error of fused layout if truth is detail", "0.6987", layout * layout, 4);
        Add("Ch 9", "Squared error of equal fusion", "0.4556", 0.675 * 0.675, 4);
        Add("Ch 9", "Break-even true layout frequency", "0.7554", 0.5 * (layout + 0.675), 4);
        Add("Ch 9", "Exercise 9 share at u=v=0.6", "0.8", Prob.ForwardShare(0.6, 0.6), 1);
        Add("Ch 9", "Exercise 9 share at u=0.6, v=-0.6", "0.5", Prob.ForwardShare(0.6, -0.6), 1);

        // Chapter 10
        static double Loss(double p, double a) => 2 * (p * (1 - a) * (1 - a) + (1 - p) * a * a);
        static double Gain(double p, double a) => (2 * a - 1) * (2 * p - a - 0.5);
        Add("Ch 10", "Pairing accuracy for zero gain at a=0.9", "0.70", (0.9 + 0.5) / 2, 2);
        Add("Ch 10", "Writer loss at p=0.8, a=0.9", "0.34", Loss(0.8, 0.9), 2);
        Add("Ch 10", "Writer loss at p=0.6, a=0.9", "0.66", Loss(0.6, 0.9), 2);
        Add("Ch 10", "Identity check G = 0.5 - loss at p=0.73, a=0.81", "0", Math.Abs(Gain(0.73, 0.81) - (0.5 - Loss(0.73, 0.81))), 0);
        Add("Ch 10", "Exercise 10 zero-gain pairing accuracy at a=0.8", "0.65", (0.8 + 0.5) / 2, 2);
        Add("Ch 10", "Exercise 10 expected latency (ms)", "19", 2 + 0.85 * 20, 0);

        // Chapter 11
        Add("Ch 11", "Cold successor readiness time (h)", "22", 2e6 / 1e5 + 2, 0);
        Add("Ch 11", "Latest incumbent exposure to start (millions)", "6.24", (8e6 - 22 * 8e4) / 1e6, 2);
        Add("Ch 11", "Service gap when starting at 6.40 million (h)", "2", 22 - (8e6 - 6.4e6) / 8e4, 0);
        Add("Ch 11", "Juvenile exposure per mature position J/(R-J)", "0.333", 2.0 / 6.0, 3);
        Add("Ch 11", "Diluted read with nine stale copies", "0.25", 3.0 / 12.0, 2);
        Add("Ch 11", "Read after deduplication", "0.75", 3.0 / 4.0, 2);
        Add("Ch 11", "Exercise 11 readiness slack (h)", "2", 1.2e6 / 6e4 - (1.5e6 / 1e5 + 3), 0);
        Add("Appendix A7", "Grid optimum of renewal cost, K=10, beta=0.2", "10", GridOptimum(10, 0.2), 2);

        // Chapter 12
        double w0 = Math.Exp(-Math.Log(2)), w1 = 1, w2 = 2;
        Add("Ch 12", "Ordinary attention read", "2.428571", (w0 * 1 + w1 * 2 + w2 * 3) / (w0 + w1 + w2), 6);
        double kmid = 0.5 * w0 + 0.5 * w2;
        Add("Ch 12", "Coefficient-kernel weight of middle record", "1.25", kmid, 2);
        Add("Ch 12", "Coefficient-kernel read", "2.4", (w0 * 1 + kmid * 2 + w2 * 3) / (w0 + kmid + w2), 1);
        Add("Ch 12", "ReLU of mixture versus mixture of ReLUs", "0.5", 0.5 * Math.Max(-1, 0) + 0.5 * Math.Max(1, 0) - Math.Max(0, 0), 1);
        Add("Ch 12", "Exercise 12 read at q=0", "2", (1 + 2 + 3) / 3.0, 0);

        // Chapter 13, Table 3
        Add("Ch 13", "Procurement quotation score (counts)", "230", 153 + 77, 0);
        Add("Ch 13", "Site survey score (counts)", "178", 153 + 25, 0);

        var rows = items.Select(it =>
        {
            string computed = Fmt.F(it.Value, it.Digits);
            string book = it.Book.Replace(",", "");
            int bookDigits = book.Contains('.') ? book.Length - book.IndexOf('.') - 1 : 0;
            double tol = 0.5 * Math.Pow(10, -bookDigits) + 1e-12;
            bool ok = Math.Abs(it.Value - double.Parse(book, Fmt.Inv)) <= tol;
            return (IReadOnlyList<object>)new object[] { it.Chapter, it.Quantity, it.Book, computed, ok };
        }).ToArray();

        int matches = rows.Count(r => (bool)r[4]);
        return new ExperimentResult("A00", "Audit of worked values",
            new[] { Table.Of("audit", new[] { "chapter", "quantity", "book", "recomputed", "match" }, rows) },
            new Dictionary<string, double> { ["items"] = rows.Length, ["matches"] = matches });
    }

    /// <summary>Enumerate the six arrival orders of A (rev 17), A' (relay of A, rev 17) and B (rev 18).</summary>
    private static (int Last, int Dedup, int Revision) Orders()
    {
        var msgs = new[] { (Id: "A", Event: "e17", Rev: 17), (Id: "A'", Event: "e17", Rev: 17), (Id: "B", Event: "e18", Rev: 18) };
        var perms = Permute(new[] { 0, 1, 2 }).ToArray();
        int last = 0, dedup = 0, rev = 0;
        foreach (var p in perms)
        {
            var seq = p.Select(i => msgs[i]).ToArray();
            if (seq[^1].Rev == 17) last++;
            var seen = new HashSet<string>(); int stateDedup = 0, stateRev = 0;
            foreach (var m in seq)
            {
                if (!seen.Add(m.Event)) continue;
                stateDedup = m.Rev;
                stateRev = Math.Max(stateRev, m.Rev);
            }
            if (stateDedup == 17) dedup++;
            if (stateRev == 17) rev++;
        }
        return (last, dedup, rev);
    }

    private static IEnumerable<int[]> Permute(int[] xs) =>
        xs.Length <= 1 ? new[] { xs } :
        xs.SelectMany((x, i) => Permute(xs.Where((_, j) => j != i).ToArray()).Select(rest => new[] { x }.Concat(rest).ToArray()));

    private static double GridOptimum(double k, double beta)
    {
        // cost(A) = l0 + K/A + beta A / 2, l0 irrelevant for the argmin
        double best = 0, bestCost = double.PositiveInfinity;
        for (int i = 1; i <= 100000; i++)
        {
            double a = i * 0.001;
            double c = k / a + beta * a / 2.0;
            if (c < bestCost) { bestCost = c; best = a; }
        }
        return best;
    }
}
