using VcLab.Core;

namespace VcLab.Experiments;

/// <summary>
/// Working memory (KV records) versus a nightly consolidated Vocabucapillary bank over thirty simulated days.
/// The bank read equals the all-record coefficient-kernel read (Eq. 4.2) at a fixed footprint.
/// </summary>
public static class A01_MemorySystems
{
    public const ulong Seed = 20261127UL;
    private const int M = 64, Days = 30, PerDay = 400, WindowRecords = 400, RevisionDay = 15;
    private const double Beta = 10.0, Sigma = 0.2, Decay = 0.9, NeighborMass = 0.05;
    private const double KvBytesPerRecord = (128 + 128) * 2, BankBytes = M * (128 + 1) * 4;

    public sealed record Obs(int Day, int Concept, IReadOnlyList<int> Atoms, IReadOnlyList<double> Coef, double Payload);

    public sealed record Bank(IReadOnlyList<double> Mass, IReadOnlyList<double> Sum)
    {
        public static Bank Empty => new(new double[M], new double[M]);

        public Bank Add(IEnumerable<Obs> obs, double decay = 1.0)
        {
            var m = Mass.Select(x => x * decay).ToArray();
            var s = Sum.Select(x => x * decay).ToArray();
            foreach (var o in obs)
                for (int k = 0; k < o.Atoms.Count; k++) { m[o.Atoms[k]] += o.Coef[k]; s[o.Atoms[k]] += o.Coef[k] * o.Payload; }
            return new Bank(m, s);
        }
    }

    private static double Phi(int atom, int query) => atom == query ? 1.0 : Math.Exp(-Beta);

    /// <summary>Bank read r(q) = sum_j phi_j S_j / sum_j phi_j m_j (Eq. 4.2).</summary>
    public static double ReadBank(Bank b, int q)
    {
        double num = 0, den = 0;
        for (int j = 0; j < M; j++) { num += Phi(j, q) * b.Sum[j]; den += Phi(j, q) * b.Mass[j]; }
        return den > 1e-9 ? num / den : 0.5;
    }

    /// <summary>Record-level read with the coefficient kernel kappa(q,a) = sum_j a_j phi_j(q).</summary>
    public static double ReadRecords(IReadOnlyList<Obs> recs, int q, int from = 0)
    {
        double num = 0, den = 0;
        for (int i = from; i < recs.Count; i++)
        {
            var o = recs[i];
            double kappa = 0; for (int k = 0; k < o.Atoms.Count; k++) kappa += o.Coef[k] * Phi(o.Atoms[k], q);
            num += kappa * o.Payload; den += kappa;
        }
        return den > 1e-9 ? num / den : 0.5;
    }

    private static int IntroducedBy(int day) => Math.Min(M, 16 + 2 * (day - 1));

    public static ExperimentResult Run()
    {
        var rng = Rng.Derive(Seed, 1);
        var mu = new double[M];
        for (int j = 0; j < M; j++) (mu[j], rng) = rng.NextDouble();
        var revised = new bool[M];
        var records = new List<Obs>();
        var bank = Bank.Empty; var decayed = Bank.Empty;
        var rows = new List<IReadOnlyList<object>>();
        double maxExactGap = 0;

        for (int day = 1; day <= Days; day++)
        {
            if (day == RevisionDay)
            {
                int n = IntroducedBy(day);
                for (int j = 0; j < n; j++)
                {
                    bool rev; (rev, rng) = rng.NextBernoulli(0.25);
                    if (rev) { revised[j] = true; double nv; (nv, rng) = rng.NextDouble(); mu[j] = nv; }
                }
            }
            int introduced = IntroducedBy(day);
            int recentFrom = day <= 3 ? 0 : IntroducedBy(day - 3);
            if (introduced - recentFrom < 6) recentFrom = Math.Max(0, introduced - 6);
            var today = new List<Obs>();
            for (int i = 0; i < PerDay; i++)
            {
                bool recent; (recent, rng) = rng.NextBernoulli(0.6);
                int c;
                if (recent) { int span = introduced - recentFrom; int r; (r, rng) = rng.NextInt(span); c = recentFrom + r; }
                else (c, rng) = rng.NextInt(introduced);
                double noise; (noise, rng) = rng.NextGaussian();
                var atoms = new[] { c, (c + 1) % M, (c + M - 1) % M };
                var coef = new[] { 1 - 2 * NeighborMass, NeighborMass, NeighborMass };
                today.Add(new Obs(day, c, atoms, coef, mu[c] + Sigma * noise));
            }
            records.AddRange(today);
            bank = bank.Add(today);                 // nightly consolidation of the trailing working memory
            decayed = decayed.Add(today, Decay);

            double maeAll = 0, maeWin = 0, maeBank = 0, maeDecay = 0, maeOldWin = 0, maeOldBank = 0;
            double maeRevBank = 0, maeRevDecay = 0, maeRevWin = 0; int nRev = 0;
            for (int q = 0; q < introduced; q++)
            {
                double rAll = ReadRecords(records, q);
                double rWin = ReadRecords(records, q, Math.Max(0, records.Count - WindowRecords));
                double rBank = ReadBank(bank, q);
                double rDec = ReadBank(decayed, q);
                maxExactGap = Math.Max(maxExactGap, Math.Abs(rAll - rBank));
                maeAll += Math.Abs(rAll - mu[q]); maeWin += Math.Abs(rWin - mu[q]);
                maeBank += Math.Abs(rBank - mu[q]); maeDecay += Math.Abs(rDec - mu[q]);
                if (q < 16) { maeOldWin += Math.Abs(rWin - mu[q]); maeOldBank += Math.Abs(rBank - mu[q]); }
                if (revised[q]) { nRev++; maeRevBank += Math.Abs(rBank - mu[q]); maeRevDecay += Math.Abs(rDec - mu[q]); maeRevWin += Math.Abs(rWin - mu[q]); }
            }
            rows.Add(new object[]
            {
                day, records.Count, records.Count * KvBytesPerRecord, Math.Min(records.Count, WindowRecords) * KvBytesPerRecord, BankBytes,
                maeAll / introduced, maeWin / introduced, maeBank / introduced, maeDecay / introduced,
                maeOldWin / 16, maeOldBank / 16,
                nRev > 0 ? maeRevBank / nRev : double.NaN, nRev > 0 ? maeRevDecay / nRev : double.NaN, nRev > 0 ? maeRevWin / nRev : double.NaN
            });
        }

        var last = rows[^1]; var day14 = rows[13]; var day16 = rows[15];
        var head = new Dictionary<string, double>
        {
            ["max_abs_gap_bank_vs_all_records"] = maxExactGap,
            ["kv_bytes_day30"] = (double)last[2], ["window_bytes"] = (double)last[3], ["bank_bytes"] = BankBytes,
            ["mae_bank_day14"] = (double)day14[7], ["mae_window_day14"] = (double)day14[6],
            ["mae_old_window_day14"] = (double)day14[9], ["mae_old_bank_day14"] = (double)day14[10],
            ["mae_old_window_day30"] = (double)last[9], ["mae_old_bank_day30"] = (double)last[10],
            ["mae_rev_bank_day16"] = (double)day16[11], ["mae_rev_decay_day16"] = (double)day16[12], ["mae_rev_window_day16"] = (double)day16[13],
            ["mae_rev_bank_day30"] = (double)last[11], ["mae_rev_decay_day30"] = (double)last[12],
            ["mae_bank_day30"] = (double)last[7], ["mae_decay_day30"] = (double)last[8], ["mae_window_day30"] = (double)last[6],
            ["kv_over_bank_day30"] = (double)last[2] / BankBytes
        };
        return new ExperimentResult("A01", "Working memory and nightly consolidation over thirty days",
            new[]
            {
                Table.Of("daily", new[] { "day", "records", "kv_all_bytes", "window_bytes", "bank_bytes", "mae_all_records", "mae_window", "mae_bank", "mae_decayed_bank", "mae_old_window", "mae_old_bank", "mae_revised_bank", "mae_revised_decayed", "mae_revised_window" }, rows)
            }, head);
    }
}
