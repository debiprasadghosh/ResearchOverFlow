using VcLab.Core;

namespace VcLab.Experiments;

/// <summary>
/// The forward code saved at wake and the backward code computed in sleep must be paired for the same
/// observation. Concurrent replay inside a coincidence window causes mispairing; gating removes it at a time cost.
/// </summary>
public static class A08_ThalamicPairing
{
    /// <summary>Probability of a wrong pairing when other events arrive as a Poisson process within the window.</summary>
    public static double MispairProbability(double x) => x <= 0 ? 0.0 : 1.0 - (1.0 - Math.Exp(-x)) / x;

    public static ExperimentResult Run()
    {
        var m = HmmModel.Default();
        var data = Hmm.Generate(m, 1500, 32, A02_BidirectionalSleep.Seed + 8);
        var bySpan = data.GroupBy(o => o.Span).ToDictionary(g => g.Key, g => g.ToArray());
        double forwardAcc = data.Average(o => Prob.Argmax(Prob.Aggregate(o.F, m.AtomClass, m.Classes)) == o.TrueClass ? 1.0 : 0.0);
        double exactAcc = data.Average(o => Prob.Argmax(Prob.Aggregate(o.Exact, m.AtomClass, m.Classes)) == o.TrueClass ? 1.0 : 0.0);

        var rows = new List<IReadOnlyList<object>>();
        var head = new Dictionary<string, double> { ["forward_only_acc"] = forwardAcc, ["exact_acc"] = exactAcc };
        foreach (var x in new[] { 0.0, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 4.0 })
        {
            double pm = MispairProbability(x);
            var rng = Rng.Derive(A02_BidirectionalSleep.Seed, 800 + (ulong)(x * 100));
            double accWithin = 0, accCross = 0, llWithin = 0, llCross = 0;
            foreach (var o in data)
            {
                bool mis; (mis, rng) = rng.NextBernoulli(pm);
                var bWithin = o.B; var bCross = o.B;
                if (mis)
                {
                    var span = bySpan[o.Span];
                    int j; (j, rng) = rng.NextIntExcept(span.Length, o.Pos);
                    bWithin = span[j].B;
                    int s2; (s2, rng) = rng.NextIntExcept(bySpan.Count, o.Span);
                    int j2; (j2, rng) = rng.NextInt(bySpan[s2].Length);
                    bCross = bySpan[s2][j2].B;
                }
                var cw = Prob.Aggregate(Prob.CorrectedProduct(o.F, bWithin, o.Local), m.AtomClass, m.Classes);
                var cc = Prob.Aggregate(Prob.CorrectedProduct(o.F, bCross, o.Local), m.AtomClass, m.Classes);
                if (Prob.Argmax(cw) == o.TrueClass) accWithin++;
                if (Prob.Argmax(cc) == o.TrueClass) accCross++;
                llWithin += Prob.LogLossBits(cw, o.TrueClass); llCross += Prob.LogLossBits(cc, o.TrueClass);
            }
            int n = data.Count;
            rows.Add(new object[] { x, pm, accWithin / n, accCross / n, llWithin / n, llCross / n, exactAcc, Math.Max(1.0, x) });
            head[$"pm_x{x}"] = pm; head[$"within_x{x}"] = accWithin / n; head[$"cross_x{x}"] = accCross / n;
        }
        return new ExperimentResult("A08", "Thalamic pairing of forward and backward codes",
            new[] { Table.Of("pairing", new[] { "load_lambda_w", "mispair_prob", "acc_within_cluster_mispair", "acc_cross_cluster_mispair", "ll_within", "ll_cross", "acc_gated", "gated_relative_duration" }, rows) },
            head);
    }
}
