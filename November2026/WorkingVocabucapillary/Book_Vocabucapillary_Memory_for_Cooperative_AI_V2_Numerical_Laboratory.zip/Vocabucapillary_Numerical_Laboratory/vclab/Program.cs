using System.Diagnostics;
using VcLab.Core;
using VcLab.Experiments;

// Composition root: the only place where experiments are scheduled and results written to disk.
var registry = new (string Id, Func<ExperimentResult> Run)[]
{
    ("A00", A00_Audit.Run),
    ("A01", A01_MemorySystems.Run),
    ("A02", A02_BidirectionalSleep.Run),
    ("A03", A03_ShortcutReaders.Run),
    ("A05", A05_SleepCost.Run),
    ("A06", A06_EventClustering.Run),
    ("A07", A07_TwoStageSleep.Run),
    ("A08", A08_ThalamicPairing.Run),
    ("A09", A09_DriverModulator.Run),
    ("A10", A10_AmygdalaBasalGanglia.Run),
    ("A11", A11_AssociationVocabulary.Run),
    ("A12", A12_Maturation.Run),
    ("A13", A13_Harness.Run),
    ("A14", A14_WeightSpaceConversion.Run),
    ("A15", A15_DirectionalAsymmetry.Run),
};

var selected = args.Length == 0 ? registry : registry.Where(r => args.Contains(r.Id)).ToArray();
string outDir = Environment.GetEnvironmentVariable("VCLAB_OUT") ?? Path.Combine("..", "out");
var results = new List<ExperimentResult>();
foreach (var (id, run) in selected)
{
    var sw = Stopwatch.StartNew();
    var r = run();
    sw.Stop();
    results.Add(r);
    Console.WriteLine($"{id} {r.Title}: {sw.Elapsed.TotalSeconds:F1} s");
    foreach (var kv in r.Headlines.Take(60)) Console.WriteLine($"   {kv.Key} = {kv.Value:G8}");
}
Output.Write(outDir, results);
