namespace VcLab.Core;

public static class Stats
{
    public static double Mean(IReadOnlyList<double> x) => x.Count == 0 ? double.NaN : x.Sum() / x.Count;

    public static double Std(IReadOnlyList<double> x)
    {
        double m = Mean(x);
        return Math.Sqrt(x.Sum(v => (v - m) * (v - m)) / Math.Max(1, x.Count - 1));
    }

    /// <summary>Standard error of a proportion.</summary>
    public static double SeProp(double p, int n) => Math.Sqrt(Math.Max(p * (1 - p), 0) / Math.Max(n, 1));

    /// <summary>Average ranks with ties (1-based).</summary>
    public static IReadOnlyList<double> Ranks(IReadOnlyList<double> x)
    {
        var idx = Enumerable.Range(0, x.Count).OrderBy(i => x[i]).ToArray();
        var r = new double[x.Count];
        int k = 0;
        while (k < idx.Length)
        {
            int j = k;
            while (j + 1 < idx.Length && x[idx[j + 1]] == x[idx[k]]) j++;
            double avg = (k + j) / 2.0 + 1.0;
            for (int t = k; t <= j; t++) r[idx[t]] = avg;
            k = j + 1;
        }
        return r;
    }

    public static double Pearson(IReadOnlyList<double> x, IReadOnlyList<double> y)
    {
        double mx = Mean(x), my = Mean(y), sxy = 0, sxx = 0, syy = 0;
        for (int i = 0; i < x.Count; i++)
        {
            double a = x[i] - mx, b = y[i] - my;
            sxy += a * b; sxx += a * a; syy += b * b;
        }
        return sxy / Math.Sqrt(sxx * syy);
    }

    public static double Spearman(IReadOnlyList<double> x, IReadOnlyList<double> y) => Pearson(Ranks(x), Ranks(y));

    /// <summary>Area under the ROC curve via the Mann-Whitney statistic.</summary>
    public static double Auc(IReadOnlyList<double> positives, IReadOnlyList<double> negatives)
    {
        var all = positives.Select(v => (v, 1)).Concat(negatives.Select(v => (v, 0))).ToArray();
        var ranks = Ranks(all.Select(a => a.v).ToArray());
        double sumPos = 0;
        for (int i = 0; i < all.Length; i++) if (all[i].Item2 == 1) sumPos += ranks[i];
        double nP = positives.Count, nN = negatives.Count;
        return (sumPos - nP * (nP + 1) / 2.0) / (nP * nN);
    }

    /// <summary>Adjusted Rand index between two labelings.</summary>
    public static double AdjustedRand(IReadOnlyList<int> a, IReadOnlyList<int> b)
    {
        int n = a.Count;
        var ka = a.Distinct().ToArray(); var kb = b.Distinct().ToArray();
        var ia = ka.Select((v, i) => (v, i)).ToDictionary(t => t.v, t => t.i);
        var ib = kb.Select((v, i) => (v, i)).ToDictionary(t => t.v, t => t.i);
        var table = new long[ka.Length, kb.Length];
        for (int i = 0; i < n; i++) table[ia[a[i]], ib[b[i]]]++;
        static double C2(double x) => x * (x - 1) / 2.0;
        double sumIj = 0, sumA = 0, sumB = 0;
        for (int i = 0; i < ka.Length; i++)
        {
            long row = 0;
            for (int j = 0; j < kb.Length; j++) { sumIj += C2(table[i, j]); row += table[i, j]; }
            sumA += C2(row);
        }
        for (int j = 0; j < kb.Length; j++)
        {
            long col = 0; for (int i = 0; i < ka.Length; i++) col += table[i, j];
            sumB += C2(col);
        }
        double expected = sumA * sumB / C2(n);
        double max = 0.5 * (sumA + sumB);
        return (sumIj - expected) / (max - expected);
    }
}
