namespace VcLab.Core;

/// <summary>Pure functions on probability vectors (simplex codes). Inputs are never modified.</summary>
public static class Prob
{
    public const double Tiny = 1e-300;

    public static IReadOnlyList<double> Normalize(IReadOnlyList<double> x)
    {
        double s = 0; for (int i = 0; i < x.Count; i++) s += x[i];
        var y = new double[x.Count];
        if (s <= 0) { for (int i = 0; i < y.Length; i++) y[i] = 1.0 / y.Length; return y; }
        for (int i = 0; i < y.Length; i++) y[i] = x[i] / s;
        return y;
    }

    public static double EntropyBits(IReadOnlyList<double> p)
    {
        double h = 0;
        for (int i = 0; i < p.Count; i++) if (p[i] > 0) h -= p[i] * Math.Log2(p[i]);
        return h;
    }

    /// <summary>Middle-layer mixing M = H(m)/log2 K with a fixed capacity K (Eq. 9.1).</summary>
    public static double Mixing(IReadOnlyList<double> m, int capacity) => EntropyBits(m) / Math.Log2(capacity);

    /// <summary>Final-layer sharpness C = 1 - H(p)/log2 L (Eq. 9.1).</summary>
    public static double Sharpness(IReadOnlyList<double> p, int classes) => 1.0 - EntropyBits(p) / Math.Log2(classes);

    /// <summary>Forward share of Eq. 9.2: s = 1/2 + (sgn u + sgn v)/4 * sqrt(|uv|).</summary>
    public static double ForwardShare(double u, double v) =>
        0.5 + (Math.Sign(u) + Math.Sign(v)) / 4.0 * Math.Sqrt(Math.Abs(u * v));

    /// <summary>Sharpness-only baseline share s = (1+v)/2.</summary>
    public static double SharpnessShare(double v) => 0.5 * (1.0 + v);

    public static double TotalVariation(IReadOnlyList<double> a, IReadOnlyList<double> b)
    {
        double s = 0; for (int i = 0; i < a.Count; i++) s += Math.Abs(a[i] - b[i]);
        return 0.5 * s;
    }

    public static double KlBits(IReadOnlyList<double> p, IReadOnlyList<double> q)
    {
        double s = 0;
        for (int i = 0; i < p.Count; i++) if (p[i] > 0) s += p[i] * Math.Log2(p[i] / Math.Max(q[i], Tiny));
        return s;
    }

    public static double JsBits(IReadOnlyList<double> p, IReadOnlyList<double> q)
    {
        var m = new double[p.Count];
        for (int i = 0; i < m.Length; i++) m[i] = 0.5 * (p[i] + q[i]);
        return 0.5 * KlBits(p, m) + 0.5 * KlBits(q, m);
    }

    public static int Argmax(IReadOnlyList<double> x)
    {
        int best = 0;
        for (int i = 1; i < x.Count; i++) if (x[i] > x[best]) best = i;
        return best;
    }

    public static double Max(IReadOnlyList<double> x)
    {
        double m = double.NegativeInfinity; for (int i = 0; i < x.Count; i++) if (x[i] > m) m = x[i];
        return m;
    }

    /// <summary>Margin between the largest and second largest entry.</summary>
    public static double Margin(IReadOnlyList<double> x)
    {
        double a = double.NegativeInfinity, b = double.NegativeInfinity;
        for (int i = 0; i < x.Count; i++)
        {
            if (x[i] > a) { b = a; a = x[i]; } else if (x[i] > b) b = x[i];
        }
        return a - b;
    }

    public static IReadOnlyList<double> Softmax(IReadOnlyList<double> logits, double beta = 1.0)
    {
        double mx = double.NegativeInfinity;
        for (int i = 0; i < logits.Count; i++) mx = Math.Max(mx, beta * logits[i]);
        var y = new double[logits.Count];
        double s = 0;
        for (int i = 0; i < y.Length; i++) { y[i] = Math.Exp(beta * logits[i] - mx); s += y[i]; }
        for (int i = 0; i < y.Length; i++) y[i] /= s;
        return y;
    }

    /// <summary>Linear opinion pool s f + (1-s) b (Eq. 9.3).</summary>
    public static IReadOnlyList<double> Linear(IReadOnlyList<double> f, IReadOnlyList<double> b, double s)
    {
        var y = new double[f.Count];
        for (int i = 0; i < y.Length; i++) y[i] = s * f[i] + (1.0 - s) * b[i];
        return y;
    }

    /// <summary>Normalized product f ⊙ b (logarithmic pool without local correction).</summary>
    public static IReadOnlyList<double> Product(IReadOnlyList<double> f, IReadOnlyList<double> b)
    {
        var y = new double[f.Count];
        for (int i = 0; i < y.Length; i++) y[i] = f[i] * b[i];
        return Normalize(y);
    }

    /// <summary>Exact decoupled consolidation f ⊙ b ⊘ l (Proposition 16.1).</summary>
    public static IReadOnlyList<double> CorrectedProduct(IReadOnlyList<double> f, IReadOnlyList<double> b, IReadOnlyList<double> local)
    {
        var y = new double[f.Count];
        for (int i = 0; i < y.Length; i++) y[i] = local[i] > 0 ? f[i] * b[i] / local[i] : 0.0;
        return Normalize(y);
    }

    /// <summary>Tempered product f^{2s} b^{2(1-s)} / l; s = 1/2 gives the exact rule.</summary>
    public static IReadOnlyList<double> TemperedProduct(IReadOnlyList<double> f, IReadOnlyList<double> b, IReadOnlyList<double>? local, double s)
    {
        var logy = new double[f.Count];
        double mx = double.NegativeInfinity;
        for (int i = 0; i < logy.Length; i++)
        {
            double l = local is null ? 1.0 : local[i];
            logy[i] = 2 * s * Math.Log(Math.Max(f[i], Tiny)) + 2 * (1 - s) * Math.Log(Math.Max(b[i], Tiny)) - Math.Log(Math.Max(l, Tiny));
            mx = Math.Max(mx, logy[i]);
        }
        var y = new double[f.Count];
        for (int i = 0; i < y.Length; i++) y[i] = Math.Exp(logy[i] - mx);
        return Normalize(y);
    }

    /// <summary>Sum atom probabilities into answer classes.</summary>
    public static IReadOnlyList<double> Aggregate(IReadOnlyList<double> atoms, IReadOnlyList<int> atomClass, int classes)
    {
        var y = new double[classes];
        for (int i = 0; i < atoms.Count; i++) y[atomClass[i]] += atoms[i];
        return y;
    }

    public static double LogLossBits(IReadOnlyList<double> p, int truth) => -Math.Log2(Math.Max(p[truth], 1e-12));

    public static double Brier(IReadOnlyList<double> p, int truth)
    {
        double s = 0; for (int i = 0; i < p.Count; i++) { double t = i == truth ? 1 : 0; s += (p[i] - t) * (p[i] - t); }
        return s;
    }

    /// <summary>Euclidean projection onto the probability simplex (sort-based algorithm).</summary>
    public static IReadOnlyList<double> ProjectToSimplex(IReadOnlyList<double> v)
    {
        var u = v.OrderByDescending(x => x).ToArray();
        double css = 0, theta = 0; int rho = 0;
        for (int i = 0; i < u.Length; i++)
        {
            css += u[i];
            double t = (css - 1.0) / (i + 1);
            if (u[i] - t > 0) { rho = i + 1; theta = t; }
        }
        var w = new double[v.Count];
        for (int i = 0; i < w.Length; i++) w[i] = Math.Max(v[i] - theta, 0.0);
        return w;
    }
}
