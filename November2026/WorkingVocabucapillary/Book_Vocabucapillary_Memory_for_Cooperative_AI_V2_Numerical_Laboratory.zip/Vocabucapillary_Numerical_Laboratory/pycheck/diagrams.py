"""Schematic figures for Part V (drawn, not computed)."""
import os
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.lines import Line2D

FIG = os.environ.get("VCLAB_FIGS", str(Path(__file__).resolve().parent.parent / "figs"))
os.makedirs(FIG, exist_ok=True)
BLUE, ORANGE, AQUA, VIOLET = "#2a78d6", "#eb6834", "#1baf7a", "#6250d6"
INK, INK2, MUTED = "#1f1f1f", "#52514e", "#8a8984"
FILL_COL, FILL_THAL, FILL_SUB, FILL_SLEEP = "#eef4fc", "#fdf0ea", "#f2f1ee", "#eaf7f1"
plt.rcParams.update({"font.family": "DejaVu Sans", "savefig.dpi": 220})

def box(ax, x, y, w, h, text, fc, ec=MUTED, fs=7.6, weight="normal", ha="center"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.006,rounding_size=0.012", fc=fc, ec=ec, lw=0.9))
    tx = x + w / 2 if ha == "center" else x + 0.012
    ax.text(tx, y + h / 2, text, ha=ha, va="center", fontsize=fs, color=INK, fontweight=weight, linespacing=1.25)

def arrow(ax, p, q, kind="driver", rad=0.0, color=None, lw=1.3):
    style = "-" if kind == "driver" else (0, (4, 2.5))
    c = color or (BLUE if kind == "driver" else ORANGE)
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=9, lw=lw, color=c, linestyle=style,
                                 connectionstyle=f"arc3,rad={rad}", shrinkA=1, shrinkB=1))

# ---------------- Figure 17: laminar Vocabucapillary microcolumn ----------------
fig, ax = plt.subplots(figsize=(7.0, 5.3)); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
cx, cw = 0.275, 0.385
layers = [("L1", "Modulator input: top-down gains g\non shared addresses (higher\ncolumns, matrix thalamus)", 0.775, 0.11),
          ("L2/3", "Association vocabulary: convex\nmixing of driver codes; coefficients\nsent to other columns", 0.655, 0.115),
          ("L4", "Driver input: native coefficients\nfrom first-order (core) thalamus", 0.555, 0.095),
          ("L5", "Driver output: coefficients to\nhigher-order thalamus, basal\nganglia and brainstem", 0.44, 0.11),
          ("L6", "Modulator output: corticothalamic\ngains that set the thalamic routing\noperator", 0.325, 0.11)]
ax.text(cx + cw / 2, 0.915, "Neocortical column: local vocabularies are stored here", ha="center", fontsize=8.2, color=INK, fontweight="bold")
for name, text, y, h in layers:
    box(ax, cx, y, cw, h, "", FILL_COL)
    ax.text(cx + 0.012, y + h / 2, name, ha="left", va="center", fontsize=8.2, fontweight="bold", color=BLUE)
    ax.text(cx + 0.075, y + h / 2, text, ha="left", va="center", fontsize=6.6, color=INK, linespacing=1.2)
L = 0.005; LW = 0.215; R = 0.715; RW = 0.28
box(ax, L, 0.79, LW, 0.085, "Sensors and native\nencoders", FILL_SUB, fs=6.7)
box(ax, L, 0.555, LW, 0.10, "First-order (core)\nthalamus: relays\nnative coefficients", FILL_THAL, fs=6.7)
box(ax, L, 0.345, LW, 0.085, "Reticular nucleus and\nthalamic gain control", FILL_THAL, fs=6.7)
box(ax, L, 0.12, LW, 0.085, "Hippocampus: working\nmemory (KV), replay", FILL_SLEEP, fs=6.7)
box(ax, R, 0.79, RW, 0.085, "Higher column or prefrontal\ntask state (feedback gains)", FILL_COL, fs=6.7)
box(ax, R, 0.62, RW, 0.10, "Next column, layer 4\n(transthalamic and cortico-\ncortical driver input)", FILL_COL, fs=6.7)
box(ax, R, 0.43, RW, 0.10, "Higher-order thalamus\n(pulvinar, mediodorsal):\nroutes coefficients", FILL_THAL, fs=6.7)
box(ax, R, 0.22, RW, 0.085, "Basal ganglia: go / no-go\nselection by disinhibition", FILL_SUB, fs=6.7)
box(ax, 0.36, 0.12, 0.215, 0.085, "Amygdala: ordered short\nmotifs, salience gains", FILL_SUB, fs=6.7)
# drivers (solid blue)
arrow(ax, (L + LW / 2, 0.79), (L + LW / 2, 0.655), "driver")
arrow(ax, (L + LW, 0.605), (cx, 0.6025), "driver")
arrow(ax, (cx + cw, 0.7125), (R, 0.68), "driver")
arrow(ax, (cx + cw, 0.495), (R, 0.48), "driver")
arrow(ax, (R + RW / 2, 0.53), (R + RW / 2, 0.62), "driver")
arrow(ax, (cx + cw, 0.455), (R + 0.04, 0.305), "driver", rad=-0.12)
# modulators (dashed orange)
arrow(ax, (R, 0.8325), (cx + cw, 0.83), "modulator")
arrow(ax, (cx, 0.38), (L + LW, 0.3875), "modulator")
arrow(ax, (L + LW / 2, 0.43), (L + LW / 2, 0.555), "modulator")
arrow(ax, (R + RW * 0.75, 0.305), (R + RW * 0.75, 0.43), "modulator")
ax.text(R + RW * 0.75 - 0.012, 0.365, "disinhibition", fontsize=6.4, color=ORANGE, va="center", ha="right")
arrow(ax, (0.4675, 0.205), (0.4675, 0.325), "modulator")
ax.text(0.477, 0.262, "salience gains", fontsize=6.4, color=ORANGE, va="center")
# replay (solid aqua)
arrow(ax, (L + LW, 0.17), (cx + 0.03, 0.325), "driver", color=AQUA, rad=0.2)
ax.text(0.318, 0.222, "sleep replay", fontsize=6.4, color=AQUA, rotation=55, va="center", ha="center")
arrow(ax, (L + LW / 2, 0.205), (L + LW / 2, 0.345), "driver", color=AQUA)
ax.text(L + LW / 2 + 0.01, 0.275, "spindle\u2013ripple\ntiming", fontsize=6.2, color=AQUA, va="center")
leg = [Line2D([0], [0], color=BLUE, lw=1.5, label="Driver coefficients: content on the simplex, combined by convex mixing"),
       Line2D([0], [0], color=ORANGE, lw=1.5, ls=(0, (4, 2.5)), label="Modulator coefficients: gains, combined multiplicatively (support-preserving)"),
       Line2D([0], [0], color=AQUA, lw=1.5, label="Offline routes: hippocampal replay and its timing")]
ax.legend(handles=leg, loc="lower center", bbox_to_anchor=(0.5, -0.04), ncol=1, fontsize=7, frameon=False)
fig.savefig(f"{FIG}/fig17_laminar_column.png", bbox_inches="tight", facecolor="white"); plt.close(fig)

# ---------------- Figure 18: one night of decoupled bidirectional consolidation ----------------
import textwrap
fig, ax = plt.subplots(figsize=(7.0, 4.6)); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
stages = [
    ("Wake", "causal segments", FILL_COL, "The forward pass writes the KV cache and saves the forward code f\u209c and the local code \u2113\u209c for every observation. Each output stays attached to the memory version it used."),
    ("Lucid preparation", "before sleep", FILL_SUB, "Cluster the trailing working memory by softmax participation (frequency-reweighted, with time). Order clusters by forward entropy so weakly interpreted events are replayed first."),
    ("NREM", "one cluster per cycle", FILL_THAL, "A reverse-causal pass computes b\u209c for the cluster only. A thalamic window pairs each b\u209c with its own f\u209c. Native vocabularies decode the replayed episodes into association links."),
    ("Fuse and publish", "consolidation", FILL_SLEEP, "\u03b1\u209c \u221d f\u209c \u2299 b\u209c \u2298 \u2113\u209c when the readers are calibrated, or a learned linear share when they are not. Rewrite only if TV(\u03b1\u209c, f\u209c) > \u03b8, publish version M\u1d9c\u207a\u00b9, and carry open motif prefixes in the ordered store."),
    ("REM", "association only", FILL_COL, "Integrate the new cluster with everything consolidated earlier, without native decoding. This work grows with the consolidated total, so later cycles are REM-heavier."),
]
top, h, gap = 0.97, 0.155, 0.04
for i, (title, sub, fc, text) in enumerate(stages):
    y = top - (i + 1) * h - i * gap
    box(ax, 0.03, y, 0.86, h, "", fc)
    ax.text(0.05, y + h * 0.62, title, ha="left", va="center", fontsize=8.2, fontweight="bold", color=INK)
    ax.text(0.05, y + h * 0.32, sub, ha="left", va="center", fontsize=6.9, color=INK2, style="italic")
    ax.text(0.30, y + h / 2, "\n".join(textwrap.wrap(text, 64)), ha="left", va="center", fontsize=6.9, color=INK, linespacing=1.3)
    if i < len(stages) - 1:
        arrow(ax, (0.14, y), (0.14, y - gap), "driver", color=MUTED)
y3 = top - 3 * h - 2 * gap; y5 = top - 5 * h - 4 * gap
arrow(ax, (0.89, y5 + h / 2), (0.89, y3 + h / 2), "driver", color=MUTED, rad=0.45)
ax.text(0.955, (y3 + y5) / 2 + h / 2, "next\ncluster", fontsize=6.6, color=INK2, ha="left", va="center")
fig.savefig(f"{FIG}/fig18_night_pipeline.png", bbox_inches="tight", facecolor="white"); plt.close(fig)
print("diagrams written")
