"""Figures for Part V, drawn from the C# laboratory CSV outputs (no computation beyond plotting)."""
import csv, json, os
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm

_ROOT = Path(__file__).resolve().parent.parent
OUT = os.environ.get("VCLAB_OUT", str(_ROOT / "out")); FIG = os.environ.get("VCLAB_FIGS", str(_ROOT / "figs"))
os.makedirs(FIG, exist_ok=True)
H = json.load(open(f"{OUT}/headlines.json"))
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, GREEN, VIOLET, RED = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"
INK, INK2, MUTED, GRID = "#1f1f1f", "#52514e", "#8a8984", "#e4e3df"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9, "axes.labelsize": 8.5,
    "axes.edgecolor": MUTED, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
    "grid.linewidth": 0.6, "axes.axisbelow": True, "legend.frameon": False, "legend.fontsize": 7.8,
    "lines.linewidth": 1.8, "lines.markersize": 4.5, "savefig.dpi": 220, "figure.dpi": 110,
})

def rd(name):
    with open(f"{OUT}/{name}.csv") as fh: return list(csv.DictReader(fh))
def col(rows, k, f=float): return [f(r[k]) for r in rows]
def save(fig, name):
    fig.savefig(f"{FIG}/{name}.png", bbox_inches="tight", facecolor="white"); plt.close(fig)
def endlabel(ax, x, y, text, color, dy=0, dx=0.6):
    ax.annotate(text, (x, y), xytext=(4 + dx, dy), textcoords="offset points", color=INK2, fontsize=7.6, va="center")
    ax.plot([x], [y], "o", color=color, ms=3.5, zorder=4)

# ---------------- Figure 3: memory systems over thirty days (A01) ----------------
d = rd("A01_daily"); day = col(d, "day")
fig, axs = plt.subplots(1, 3, figsize=(7.0, 2.9), gridspec_kw={"wspace": 0.42})
ax = axs[0]
for k, c, lab in (("kv_all_bytes", BLUE, "All KV records"), ("window_bytes", ORANGE, "One-day KV window"), ("bank_bytes", AQUA, "Consolidated bank")):
    ax.plot(day, col(d, k), color=c, label=lab)
ax.set_yscale("log"); ax.set_xlabel("Day"); ax.set_ylabel("Bytes per head and layer"); ax.set_title("Memory footprint", loc="left")
ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.24), fontsize=7)
ax = axs[1]
ax.plot(day, col(d, "mae_old_window"), color=ORANGE, label="KV window")
ax.plot(day, col(d, "mae_old_bank"), color=AQUA, label="Bank")
ax.axvline(15, color=MUTED, lw=0.8, ls=":"); ax.text(15.5, 0.022, "revision", color=MUTED, fontsize=7)
ax.set_xlabel("Day"); ax.set_ylabel("Mean absolute error"); ax.set_title("Concepts first seen on day 1", loc="left"); ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.24), fontsize=7)
ax = axs[2]
rv = [r for r in d if r["mae_revised_bank"] != "NaN"]
dd = col(rv, "day")
ax.plot(dd, col(rv, "mae_revised_bank"), color=AQUA, label="Bank")
ax.plot(dd, col(rv, "mae_revised_decayed"), color=BLUE, label="Bank, decay 0.9/night")
ax.plot(dd, col(rv, "mae_revised_window"), color=ORANGE, label="KV window")
ax.set_xlabel("Day"); ax.set_ylabel("Mean absolute error"); ax.set_title("Concepts revised on day 15", loc="left"); ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.24), fontsize=7)
save(fig, "fig03_memory_systems")

# ---------------- Figure 4: accuracy along the span (A02) ----------------
d = rd("A02_position"); pos = col(d, "position")
fig, ax = plt.subplots(figsize=(6.0, 2.9))
series = (("forward_acc", BLUE, "Forward only (wake code)"), ("backward_acc", ORANGE, "Backward only"),
          ("joint_linear_acc", AQUA, "Joint-score linear fusion"), ("exact_acc", VIOLET, "Exact decoupled fusion"))
for k, c, lab in series: ax.plot(pos, col(d, k), color=c, label=lab)
ax.set_xlabel("Position of the observation within a 32-step closed span"); ax.set_ylabel("Class accuracy")
ax.set_xlim(0.5, 32.5); ax.legend(loc="lower center", ncol=2, bbox_to_anchor=(0.5, -0.02))
save(fig, "fig04_position_profile")

# ---------------- Figure 5: shortcut readers heatmaps (A03) ----------------
g = rd("A03_grid")
rs = sorted(set(col(g, "shortcut_reliability"))); bs = sorted(set(col(g, "beta")))
def grid(key):
    M = np.zeros((len(rs), len(bs)))
    for r in g: M[rs.index(float(r["shortcut_reliability"])), bs.index(float(r["beta"]))] = 100 * (float(r[key]) - float(r["sharpness_only"]))
    return M
cmap = LinearSegmentedColormap.from_list("bgr", ["#1c5cab", "#86b6ef", "#f0efec", "#f1a7a0", "#b8302f"])
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.9), gridspec_kw={"wspace": 0.28})
for ax, key, title in ((axs[0], "mixing_only", "Mixing-only share minus sharpness-only"), (axs[1], "learned", "Learned share minus sharpness-only")):
    M = grid(key); lim = max(15, np.abs(M).max())
    im = ax.imshow(M, cmap=cmap, norm=TwoSlopeNorm(0, -lim, lim), aspect="auto", origin="lower")
    for i in range(len(rs)):
        for j in range(len(bs)):
            ax.text(j, i, f"{M[i,j]:+.1f}", ha="center", va="center", fontsize=6.8, color=INK if abs(M[i,j]) < 0.6*lim else "white")
    ax.set_xticks(range(len(bs)), [f"{b:g}" for b in bs]); ax.set_yticks(range(len(rs)), [f"{r:.2f}" for r in rs])
    ax.set_xlabel("Final-layer sharpness scale β"); ax.set_ylabel("Shortcut reliability rₛ"); ax.set_title(title, loc="left"); ax.grid(False)
cb = fig.colorbar(im, ax=axs, fraction=0.025, pad=0.02); cb.set_label("Accuracy difference (percentage points)", color=INK2); cb.outline.set_visible(False)
save(fig, "fig05_shortcut_heatmaps")

# ---------------- Figure 6: replay budget and captured gain (A02) ----------------
b = rd("A02_budget")
fig, ax = plt.subplots(figsize=(6.0, 3.0))
order = (("Oracle realized gain", MUTED, "Oracle (realized gain)"), ("KL(posterior || forward)", VIOLET, "KL(posterior ‖ forward), after sleep"),
         ("Forward entropy (pre-sleep)", BLUE, "Forward entropy, before sleep"), ("Directional TV", AQUA, "Directional total variation"),
         ("Random", ORANGE, "Random order"), ("|s - 1/2| from Eq. 9.2", RED, "|s − 1/2| from Eq. 9.2"))
for key, c, lab in order:
    rr = [r for r in b if r["priority"] == key]
    ax.plot([0] + col(rr, "budget"), [0] + col(rr, "captured_gain_share"), color=c, label=lab, ls="--" if key.startswith("Oracle") else "-")
ax.axvline(0.3, color=MUTED, lw=0.8, ls=":")
ax.set_xlabel("Fraction of observations given a backward pass"); ax.set_ylabel("Share of total consolidation gain")
ax.set_xlim(0, 1); ax.legend(loc="lower right", fontsize=7.2)
save(fig, "fig06_replay_budget")

# ---------------- Figure 7: event clustering (A06) ----------------
a = rd("A06_ari"); hubs = sorted(set(col(a, "hub_weight")))
fig, ax = plt.subplots(figsize=(5.6, 2.7))
for m, c, lab in (("raw", ORANGE, "Raw participation"), ("idf", BLUE, "Frequency-reweighted"), ("idf+time", AQUA, "Reweighted plus time")):
    rr = [r for r in a if r["method"] == m]
    ax.errorbar(col(rr, "hub_weight"), col(rr, "ari_mean"), yerr=col(rr, "ari_sd"), color=c, marker="o", capsize=2.5, lw=1.8, label=lab)
ax.set_xlabel("Weight of the shared generic (hub) participation pattern"); ax.set_ylabel("Adjusted Rand index"); ax.set_ylim(0, 1)
ax.legend(loc="lower left")
save(fig, "fig07_event_clustering")

# ---------------- Figure 8: two-stage sleep (A07) ----------------
c = rd("A07_conditions"); cy = rd("A07_cycles")
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.8), gridspec_kw={"wspace": 0.55, "width_ratios": [1.35, 1]})
ax = axs[0]
names = [r["condition"] for r in c]; y = np.arange(len(names))
ax.barh(y - 0.19, col(c, "direct_auc"), height=0.36, color=BLUE, label="Direct links")
ax.barh(y + 0.19, col(c, "inferential_auc"), height=0.36, color=ORANGE, label="Two-step inference")
ax.set_yticks(y, names); ax.invert_yaxis(); ax.set_xlim(0.4, 1.0); ax.axvline(0.5, color=MUTED, lw=0.8, ls=":")
ax.set_xlabel("Area under the ROC curve"); ax.legend(loc="lower left", bbox_to_anchor=(0.0, 1.0), ncol=2, fontsize=7); ax.grid(axis="y", visible=False)
ax = axs[1]
for load, colr, lab in ((10000.0, BLUE, "10,000 items per cycle"), (20000.0, ORANGE, "20,000 items per cycle")):
    rr = [r for r in cy if float(r["items_per_cycle"]) == load]
    ax.plot(col(rr, "cycle"), [100 * v for v in col(rr, "rem_share")], color=colr, marker="o", label=lab)
ax.set_xlabel("Sleep cycle"); ax.set_ylabel("REM share of cycle work (%)"); ax.set_xticks([1, 2, 3, 4, 5]); ax.legend(loc="upper left", fontsize=7)
save(fig, "fig08_two_stage_sleep")

# ---------------- Figure 9: thalamic pairing (A08) ----------------
p = rd("A08_pairing"); x = col(p, "load_lambda_w")
fig, ax = plt.subplots(figsize=(6.0, 2.8))
ax.plot(x, col(p, "acc_within_cluster_mispair"), color=BLUE, marker="o", label="Mispairs within the same span")
ax.plot(x, col(p, "acc_cross_cluster_mispair"), color=ORANGE, marker="o", label="Mispairs across spans")
ax.axhline(H["A08.exact_acc"], color=AQUA, lw=1.6, label="Gated pairing (one event per window)")
ax.axhline(H["A08.forward_only_acc"], color=MUTED, lw=1.2, ls="--", label="No sleep (forward code only)")
ax.set_xscale("symlog", linthresh=0.05); ax.set_xlim(0, 4.6); ax.set_xticks([0, 0.05, 0.1, 0.2, 0.5, 1, 2, 4], ["0", "0.05", "0.1", "0.2", "0.5", "1", "2", "4"])
ax.set_xlabel("Concurrent replay load λw (events per coincidence window)"); ax.set_ylabel("Class accuracy after consolidation")
ax.legend(loc="lower left", fontsize=7.2)
save(fig, "fig09_thalamic_pairing")

# ---------------- Figure 10: drivers and modulators (A09) ----------------
f = rd("A09_feedback")
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.7), gridspec_kw={"wspace": 0.32})
pol = (("No feedback", MUTED, "No feedback"), ("Additive, lambda=0.50", ORANGE, "Additive feedback, λ = 0.5"), ("Multiplicative gain", BLUE, "Multiplicative gain"))
for key, colr, lab in pol:
    rr = [r for r in f if r["policy"] == key]
    axs[0].plot(col(rr, "context_validity"), col(rr, "accuracy"), color=colr, marker="o", label=lab)
    axs[1].plot(col(rr, "context_validity"), col(rr, "hallucination_rate"), color=colr, marker="o", label=lab)
axs[0].set_xlabel("Probability that top-down context is valid"); axs[0].set_ylabel("Accuracy"); axs[0].legend(loc="upper left", fontsize=7)
axs[1].set_xlabel("Probability that top-down context is valid"); axs[1].set_ylabel("Winner outside the driver support")
save(fig, "fig10_driver_modulator")

# ---------------- Figure 11: basal ganglia gate (A10) ----------------
gt = rd("A10_gate")
fig, ax = plt.subplots(figsize=(5.8, 2.8))
labels = {"Always read long-term memory": "Always read long-term memory", "Margin gate (margin > 2E)": "Margin gate (margin > 2E)",
          "Confidence gate, p > 0.5": "Confidence gate p > 0.5", "Confidence gate, p > 0.7": "Confidence gate p > 0.7", "Confidence gate, p > 0.9": "Confidence gate p > 0.9"}
for r in gt:
    colr = BLUE if r["policy"].startswith("Margin") else (MUTED if r["policy"].startswith("Always") else ORANGE)
    xx, yy = float(r["mean_latency_ms"]), 100 * float(r["agreement_with_full_read"])
    ax.plot([xx], [yy], "o", color=colr, ms=6)
    off, ha = {"Confidence gate, p > 0.7": ((-4, -13), "left"), "Confidence gate, p > 0.9": ((4, -13), "left"),
               "Margin gate (margin > 2E)": ((-6, 8), "right"), "Always read long-term memory": ((0, 8), "center"),
               "Confidence gate, p > 0.5": ((7, -3), "left")}[r["policy"]]
    ax.annotate(labels[r["policy"]], (xx, yy), xytext=off, textcoords="offset points", fontsize=7.4, color=INK2, ha=ha)
ax.set_xlabel("Mean latency (ms), including emergency queries"); ax.set_ylabel("Agreement with the full read (%)")
ax.set_xlim(0, 27); ax.set_ylim(95.5, 100.9)
save(fig, "fig11_basal_ganglia_gate")

# ---------------- Figure 12: association vocabulary (A11) ----------------
v = rd("A11_vq"); M = col(v, "codebook_M")
fig, ax = plt.subplots(figsize=(5.8, 2.8))
ax.step(M, col(v, "counting_ceiling"), where="post", color=MUTED, lw=1.4, ls="--", label="Counting ceiling (Appendix A1)")
ax.plot(M, col(v, "kmeans_init_accuracy"), color=ORANGE, marker="o", label="Stage two, k-means initialization")
ax.plot(M, col(v, "finetuned_accuracy"), color=BLUE, marker="o", label="Stage two after straight-through training")
ax.axhline(H["A11.stage1_test"], color=AQUA, lw=1.4, label="Stage one continuous relation")
ax.axvline(16, color=MUTED, lw=0.8, ls=":")
ax.set_xscale("log", base=2); ax.set_xticks(M, [f"{int(m)}" for m in M]); ax.set_xlabel("Association vocabulary size M"); ax.set_ylabel("Exact answer-vector accuracy")
ax.legend(loc="lower right", fontsize=7.2)
save(fig, "fig12_association_vocabulary")

# ---------------- Figure 13: maturation (A12) ----------------
s = rd("A12_mature_series")
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.7), gridspec_kw={"wspace": 0.35, "width_ratios": [1.4, 1]})
ax = axs[0]
ax.plot(col(s, "mature_tokens"), col(s, "meaning_drift_plastic"), color=ORANGE, marker="o", ms=3, label="Native vocabulary kept plastic")
ax.plot(col(s, "mature_tokens"), col(s, "meaning_drift_frozen"), color=BLUE, marker="o", ms=3, label="Native vocabulary frozen")
ax.set_xlabel("Tokens after maturity"); ax.set_ylabel("Squared change in decoded memory"); ax.legend(loc="upper left", fontsize=7.2)
ax = axs[1]
vals = [H["A12.novel_acc_frozen"], H["A12.novel_acc_plastic"], H["A12.novel_acc_successor"]]
ax.bar([0, 1, 2], vals, color=[BLUE, ORANGE, AQUA], width=0.6)
for i, val in enumerate(vals): ax.text(i, val + 0.02, f"{val:.2f}", ha="center", fontsize=7.6, color=INK2)
ax.set_xticks([0, 1, 2], ["Frozen\nnative", "Plastic\nnative", "Juvenile\nsuccessor"]); ax.set_ylim(0, 1.1); ax.set_ylabel("Accuracy on the new distinction")
ax.grid(axis="x", visible=False)
save(fig, "fig13_maturation")

# ---------------- Figure 14: retirement and team size (A13) ----------------
rt = rd("A13_retirement"); tm = rd("A13_team")
fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.2), gridspec_kw={"wspace": 0.32})
ax = axs[0]
ax.plot(col(rt, "retirement_age"), col(rt, "expected_cost_curated"), color=BLUE, label="Curated successor, expected")
ax.plot(col(rt, "retirement_age"), col(rt, "simulated_cost_curated"), "o", color=BLUE, ms=2.5, alpha=0.6, label="Curated successor, simulated")
ax.plot(col(rt, "retirement_age"), col(rt, "expected_cost_local_repair"), color=AQUA, label="Local repair (keeps 15% of stale mass)")
ax.axvline(H["A13.theory_optimum"], color=MUTED, lw=0.9, ls="--"); ax.axvline(H["A13.exact_optimum"], color=ORANGE, lw=0.9, ls=":")
ax.text(H["A13.theory_optimum"] + 8, 0.163, "\u221a(2K/\u03b2)", color=MUTED, fontsize=7, ha="left")
ax.text(H["A13.exact_optimum"] + 10, 0.675, "exact optimum", color=ORANGE, fontsize=7, ha="left")
ax.set_ylim(0.15, 0.7); ax.set_xlabel("Tasks served before replacement or repair"); ax.set_ylabel("Cost per task"); ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.2), fontsize=6.8)
ax = axs[1]
for rep, colr in (("Dense FP16 vector", ORANGE), ("Text summary", YELLOW), ("Sparse coefficients", BLUE)):
    rr = [r for r in tm if r["representation"] == rep]
    short = {"Dense FP16 vector": "Dense vector", "Text summary": "Text summary", "Sparse coefficients": "Sparse coefficients"}[rep]
    ax.plot(col(rr, "team_size"), [100 * x for x in col(rr, "miss_rate")], color=colr, marker="o", ms=3.5, label=f"{short}, {int(float(rr[0]['cache_capacity_records'])):,} records")
ax.set_xscale("log", base=2); ax.set_xlabel("Team size"); ax.set_ylabel("Partner-record misses (%)"); ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.2), fontsize=6.8)
save(fig, "fig14_harness")

# ---------------- Figure 15: attention kernel change (A14) ----------------
at = rd("A14_attention")
fig, ax = plt.subplots(figsize=(5.6, 2.6))
for tau, colr in ((0.5, ORANGE), (1.0, BLUE), (2.0, AQUA)):
    rr = [r for r in at if float(r["temperature"]) == tau]
    ax.plot(col(rr, "code_support"), [100 * x for x in col(rr, "decision_sign_agreement")], color=colr, marker="o", label=f"temperature {tau:g}")
ax.set_xscale("log", base=2); ax.set_xticks([1, 2, 4, 8], ["1", "2", "4", "8"]); ax.set_ylim(60, 102)
ax.set_xlabel("Atoms per historical key code"); ax.set_ylabel("Sign agreement of the read (%)"); ax.legend(loc="lower left")
save(fig, "fig15_attention_kernel")

# ---------------- Figure 16: computational asymmetry (A15) ----------------
mc = rd("A15_mechanisms")
fig, ax = plt.subplots(figsize=(5.6, 2.5))
img = [int(float(x)) for x in col(mc, "image_size")]
ax.bar(range(len(img)), col(mc, "restricted_asymmetry"), color=BLUE, width=0.6)
for i, val in enumerate(col(mc, "restricted_asymmetry")): ax.text(i, val + 0.012, f"{abs(val) if abs(val) < 5e-3 else val:.2f}", ha="center", fontsize=7.4, color=INK2)
ax.set_xticks(range(len(img)), [str(i) for i in img]); ax.set_xlabel("Image size of the forward mechanism (16 = bijection)")
ax.set_ylabel("Backward minus forward loss (bits)"); ax.grid(axis="x", visible=False); ax.set_ylim(0, 0.62)
save(fig, "fig16_directional_asymmetry")
print("figures written")
