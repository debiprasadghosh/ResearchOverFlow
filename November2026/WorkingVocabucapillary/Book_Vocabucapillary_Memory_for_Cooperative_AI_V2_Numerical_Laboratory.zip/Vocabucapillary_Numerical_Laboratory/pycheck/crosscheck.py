"""Independent Python re-implementation of selected C# experiments (Vocabucapillary numerical laboratory).
Ports the immutable SplitMix64 stream so that sampled data are identical, then recomputes headline values."""
import csv, json, math, sys
from pathlib import Path
import numpy as np

MASK = (1 << 64) - 1
GAMMA = 0x9E3779B97F4A7C15

class Rng:
    __slots__ = ("state",)
    def __init__(self, state): self.state = state & MASK
    @staticmethod
    def derive(seed, stream):
        start = Rng(seed ^ ((stream * 0xD1B54A32D192ED03) & MASK))
        return start.next_u64()[1]
    def next_u64(self):
        s = (self.state + GAMMA) & MASK
        z = s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & MASK
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & MASK
        z ^= z >> 31
        return z, Rng(s)
    def next_double(self):
        u, n = self.next_u64()
        return (u >> 11) * (1.0 / 9007199254740992.0), n
    def next_categorical(self, w):
        total = 0.0
        for x in w: total += x
        d, n = self.next_double()
        target = d * total; acc = 0.0
        for i, x in enumerate(w):
            acc += x
            if target < acc: return i, n
        return len(w) - 1, n

OUT = sys.argv[1] if len(sys.argv) > 1 else str(Path(__file__).resolve().parent.parent / "out")
H = json.load(open(f"{OUT}/headlines.json"))
rows = []
def check(name, csharp, python, tol):
    rows.append((name, csharp, python, abs(csharp - python), abs(csharp - python) <= tol))

# ---------- A02: chain-structured spans, identical sampling ----------
L, r = 4, 3; K = L * r; V = K + L + 8
atom_class = np.array([z // r for z in range(K)])
A = np.zeros((K, K))
for z in range(K):
    for w in range(K):
        A[z, w] = 0.85 if w == z else (0.10 / (r - 1) if atom_class[w] == atom_class[z] else 0.05 / (K - r))
atomCue, atomErr, classCue, classErr = 0.22, 0.06, 0.20, 0.06
generic = 1 - atomCue - atomErr - classCue - classErr
E = np.zeros((K, V))
for z in range(K):
    for a in range(K): E[z, a] = atomCue if a == z else atomErr / (K - 1)
    for c in range(L): E[z, K + c] = classCue if c == atom_class[z] else classErr / (L - 1)
    for g in range(8): E[z, K + L + g] = generic / 8
A_rows = [list(A[z]) for z in range(K)]; E_rows = [list(E[z]) for z in range(K)]
uniform = [1.0 / K] * K

def sample(T, rng):
    z = [0] * T; x = [0] * T
    z[0], rng = rng.next_categorical(uniform)
    x[0], rng = rng.next_categorical(E_rows[z[0]])
    for t in range(1, T):
        z[t], rng = rng.next_categorical(A_rows[z[t - 1]])
        x[t], rng = rng.next_categorical(E_rows[z[t]])
    return z, x, rng

def codes(x):
    T = len(x)
    f = np.zeros((T, K)); beta = np.zeros((T, K))
    prev = np.full(K, 1.0 / K)
    for t in range(T):
        # same summation order as the C# loops, so near-ties resolve identically
        if t == 0: pred = [1.0 / K] * K
        else:
            pred = []
            for zz in range(K):
                acc = 0.0
                for ww in range(K): acc += f[t - 1][ww] * A_rows[ww][zz]
                pred.append(acc)
        pred = [pred[zz] * E_rows[zz][x[t]] for zz in range(K)]
        tot = 0.0
        for q in pred: tot += q
        f[t] = [q / tot for q in pred]
    beta[T - 1] = 1.0
    for t in range(T - 2, -1, -1):
        nb = A @ (E[:, x[t + 1]] * beta[t + 1])
        beta[t] = nb / nb.sum()
    local = E[:, x].T
    b = local * beta; b = b / b.sum(axis=1, keepdims=True)
    loc = local / local.sum(axis=1, keepdims=True)
    exact = f * beta; exact = exact / exact.sum(axis=1, keepdims=True)
    return f, b, loc, exact

def H2(p):
    p = p[p > 0]; return float(-(p * np.log2(p)).sum())
def agg(p):
    out = [0.0] * L
    for i in range(K): out[atom_class[i]] += p[i]
    return np.array(out)

rng = Rng.derive(20261124, 2)
stats = {k: [0.0, 0.0] for k in ["fwd", "eq", "joint", "exact", "prod"]}
n = 0; max_dec = 0.0
for s in range(4000):
    z, x, rng = sample(32, rng)
    f, b, loc, exact = codes(x)
    for t in range(32):
        y = atom_class[z[t]]
        fc, bc = agg(f[t]), agg(b[t])
        u = H2(f[t]) / math.log2(K) - H2(b[t]) / math.log2(K)
        v = (1 - H2(fc) / math.log2(L)) - (1 - H2(bc) / math.log2(L))
        sj = 0.5 + (np.sign(u) + np.sign(v)) / 4.0 * math.sqrt(abs(u * v))
        dec = f[t] * b[t] / loc[t]; dec = dec / dec.sum()
        max_dec = max(max_dec, float(np.abs(dec - exact[t]).max()))
        prod = f[t] * b[t]; prod = prod / prod.sum()
        for key, code in (("fwd", f[t]), ("eq", 0.5 * f[t] + 0.5 * b[t]), ("joint", sj * f[t] + (1 - sj) * b[t]), ("exact", dec), ("prod", prod)):
            c = agg(code)
            stats[key][0] += 1.0 if int(np.argmax(c)) == y else 0.0
            stats[key][1] += -math.log2(max(c[y], 1e-12))
        n += 1
names = {"fwd": "Forwardonly", "eq": "Equallinear", "joint": "JointscorelinearEq92", "exact": "ExactdecoupledProp161", "prod": "Productnolocalcorrection"}
for key, nm in names.items():
    check(f"A02 class accuracy, {nm}", H[f"A02.acc_{nm}"], stats[key][0] / n, 1e-9)
    check(f"A02 log loss (bits), {nm}", H[f"A02.ll_{nm}"], stats[key][1] / n, 1e-9)
check("A02 max |decoupled - forward-backward|", H["A02.max_abs_decoupled_vs_forward_backward"], max_dec, 1e-12)

# ---------- A00: Chapter 9 worked example ----------
def ent(p): return -sum(q * math.log2(q) for q in p if q > 0)
mf, mb = ent([0.25] * 4) / 2, ent([0.5, 0.5, 0, 0]) / 2
cf, cb = 1 - ent([0.95, 0.05]), 1 - ent([0.4, 0.6])
u, v = mf - mb, cf - cb
s = 0.5 + (1 + 1) / 4 * math.sqrt(u * v)
check("A00 forward share s (Ch. 9)", 0.792522, s, 5e-7)
check("A00 fused layout probability", 0.835887, s * 0.95 + (1 - s) * 0.4, 5e-7)

# ---------- A05: closed-form saving of forward reuse ----------
for d, T in ((4096, 4096), (8192, 32768), (8192, 1048576)):
    check(f"A05 saving vs joint pass, d={d}, T={T}", H[f"A05.save_d{d}_T{T}"], T / (12 * d + 2 * T), 1e-12)

# ---------- A07: REM share closed form ----------
for load in (10000, 20000):
    for c in (1, 3, 5):
        rem = load * (c * load) * 1024; nrem = load * 65536 * 1024
        check(f"A07 REM share, load {load}, cycle {c}", H[f"A07.remshare_load{load}_c{c}"], rem / (rem + nrem), 1e-12)

# ---------- A08: mispairing formula versus Poisson Monte Carlo (independent RNG) ----------
g = np.random.default_rng(7)
for x in (0.2, 1.0, 2.0):
    k = g.poisson(x, size=400000)
    mc = float(np.mean(k / (k + 1.0)))
    check(f"A08 mispair probability, lambda*w={x} (Monte Carlo)", H[{0.2:"A08.pm_x0.2",1.0:"A08.pm_x1",2.0:"A08.pm_x2"}[x]], mc, 3e-3)

# ---------- A13: renewal costs ----------
rho, W, l0, Kc = 0.002, 1.0, 0.02, 40.0
loss = lambda st: l0 + (1 - l0) * st / (W + st)
cum = np.cumsum([loss(rho * t) for t in range(3000)])
cost = lambda a: (Kc + cum[a - 1]) / a
best = min(range(1, 3000), key=cost)
check("A13 exact retirement optimum (tasks)", H["A13.exact_optimum"], best, 0.5)
check("A13 renewal approximation sqrt(2K/beta)", H["A13.theory_optimum"], math.sqrt(2 * Kc / ((1 - l0) * rho / W)), 1e-9)
check("A13 cost per task at optimum", H["A13.retire_cost_at_optimum"], cost(best), 1e-12)

# ---------- A15: information symmetry for an independent random chain ----------
g2 = np.random.default_rng(11)
P = g2.dirichlet([0.7] * 8, size=8)
w_, vec = np.linalg.eig(P.T); pi = np.real(vec[:, np.argmin(np.abs(w_ - 1))]); pi = pi / pi.sum()
hf = sum(pi[i] * ent(P[i]) for i in range(8))
joint = pi[:, None] * P; py = joint.sum(axis=0)
hb = sum(py[j] * ent(joint[:, j] / py[j]) for j in range(8))
check("A15 |H(X_t+1|X_t) - H(X_t|X_t+1)| (independent chain)", 0.0, abs(hf - hb), 1e-12)

with open(f"{OUT}/PY_crosscheck.csv", "w", newline="") as fh:
    wr = csv.writer(fh); wr.writerow(["quantity", "csharp", "python", "abs_difference", "agree"])
    for row in rows: wr.writerow(row)
print(f"{sum(r[4] for r in rows)}/{len(rows)} agree; max abs diff on exact-match items = {max(r[3] for r in rows if 'Monte Carlo' not in r[0]):.3e}")
for row in rows: print(row)
