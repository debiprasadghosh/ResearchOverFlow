using System.Diagnostics;
using LrvLab.Core;
using LrvLab.Experiments;

// Composition root: schedules the studies and performs the only file writes.
var registry = new (string Id, Func<ExperimentResult> Run)[]
{
    ("B00", B00_Accounting.Run),
    ("B01", B01_Bounds.Run),
    ("B02", B02_FitCell.Run),
    ("B03", B03_Downstream.Run),
    ("B04", B04_PrefixScreen.Run),
    ("B05", B05_ContextRot.Run),
    ("B06", B06_ExactChecks.Run),
};
var selected = args.Length == 0 ? registry : registry.Where(r => args.Contains(r.Id)).ToArray();
string outDir = Environment.GetEnvironmentVariable("LRV_OUT") ?? Path.Combine("..", "out");
var results = new List<ExperimentResult>();
foreach (var (id, run) in selected)
{
    var sw = Stopwatch.StartNew();
    var r = run();
    sw.Stop();
    results.Add(r);
    Console.WriteLine($"{id} {r.Title}: {sw.Elapsed.TotalSeconds:F1} s");
    foreach (var kv in r.Headlines) Console.WriteLine($"   {kv.Key} = {kv.Value:G8}");
}
Output.Write(outDir, results);
