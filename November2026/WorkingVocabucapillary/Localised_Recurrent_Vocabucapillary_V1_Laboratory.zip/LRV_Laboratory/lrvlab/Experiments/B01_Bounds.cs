using LrvLab.Core;

namespace LrvLab.Experiments;

/// <summary>
/// Exact limits on what a four-number seed can carry: the affine rank identity, the Cayley–Hamilton recurrence,
/// spectral and rate–distortion bounds across teacher spectra, and the long-run dynamics of deployed 96-bit cells.
/// </summary>
public static class B01_Bounds
{
    private const ulong Seed = 20261124;

    public static ExperimentResult Run()
    {
        var h = new Dictionary<string, double>();

        // (1) Affine cell: no clipping is reached, no state rounding. Rows must equal G0 + z·G exactly.
        var rng = Rng.Derive(Seed, 1);
        var (a, r1) = Lin.Gaussians(rng, 16);
        var (b, r2) = Lin.Gaussians(r1, 16);
        var (c, r3) = Lin.Gaussians(r2, 4);
        var A = a.Select(x => 0.18 * x).ToArray();
        var affine = new CellParams(A, b.Select(x => 0.05 * x).ToArray(), c.Select(x => 0.05 * x).ToArray(), 1.0);
        int d = 4096, v = 256;
        var basis = Enumerable.Range(0, 5).Select(j =>
        {
            var z = new double[4];
            if (j < 4) z[j] = 1.0;
            return Cell.Run(affine, z, d, false).Output;
        }).ToArray();                              // basis[4] = response to z = 0 (the offset G0)
        double maxGap = 0, maxState = 0, chResidual = 0;
        var cp = CharPoly(A);
        var rr = r3;
        for (int i = 0; i < v; i++)
        {
            var (z, nr) = Lin.Gaussians(rr, 4); rr = nr;
            var tr = Cell.Run(affine, z, d, false);
            maxState = Math.Max(maxState, tr.States.Max(Math.Abs));
            for (int t = 0; t < d; t++)
            {
                double pred = basis[4][t] + Enumerable.Range(0, 4).Sum(j => z[j] * (basis[j][t] - basis[4][t]));
                maxGap = Math.Max(maxGap, Math.Abs(pred - tr.Output[t]) / (1 + Math.Abs(tr.Output[t])));
            }
            // Differences D(t) = y(t+1) - y(t) obey D(t+4) + c3 D(t+3) + c2 D(t+2) + c1 D(t+1) + c0 D(t) = 0 for t >= 1.
            var y = tr.Output;
            double d0 = Math.Abs(y[2] - y[1]);
            for (int t = 1; t + 5 < 64; t++)
            {
                double D(int s) => y[s + 1] - y[s];
                double scale = Enumerable.Range(t, 5).Max(s => Math.Abs(D(s)));
                if (scale < 1e-6 * d0) break;                          // stop once differences reach rounding level
                double res = D(t + 4) + cp[3] * D(t + 3) + cp[2] * D(t + 2) + cp[1] * D(t + 1) + cp[0] * D(t);
                chResidual = Math.Max(chResidual, Math.Abs(res) / scale);
            }
        }
        h["affine_max_relative_gap"] = maxGap;
        h["affine_max_abs_state"] = maxState;
        h["cayley_hamilton_max_relative_residual"] = chResidual;

        // (2) Spectral and rate–distortion bounds by teacher spectrum (exact for the Gaussian teacher model).
        var bounds = new List<object[]>();
        foreach (int dd in new[] { 1024, 4096 })
            foreach (double alpha in new[] { 0.0, 0.5, 1.0, 1.5 })
            {
                var lam = Lin.PowerSpectrum(dd, alpha);
                double tot = lam.Sum();
                double Rd(double bits) => Lin.GaussianDistortion(lam, bits) / tot;
                bounds.Add(new object[]
                {
                    dd, alpha,
                    1 - lam.Take(2).Sum() / tot, 1 - lam.Take(4).Sum() / tot,
                    Rd(16), Rd(32), Rd(64), Rd(256),
                    Lin.GaussianBitsFor(lam, 0.5), Lin.GaussianBitsFor(lam, 0.2), Lin.GaussianBitsFor(lam, 0.1), Lin.GaussianBitsFor(lam, 0.01),
                    Lin.GaussianBitsFor(lam, 0.1) / (16.0 * dd),
                });
            }
        foreach (var row in bounds.Where(x => (int)x[0] == 4096))
        {
            string al = ((double)row[1]).ToString("0.0", Fmt.Inv);
            h[$"d4096_a{al}_affine_k4_floor"] = (double)row[3];
            h[$"d4096_a{al}_rd_32bits"] = (double)row[5];
            h[$"d4096_a{al}_bits_for_0.1"] = (double)row[10];
        }
        var curve = new List<object[]>();
        foreach (double alpha in new[] { 0.0, 0.5, 1.0, 1.5 })
        {
            var lam = Lin.PowerSpectrum(4096, alpha);
            double tot = lam.Sum();
            foreach (double bits in new[] { 8.0, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536 })
                curve.Add(new object[] { alpha, bits, Lin.GaussianDistortion(lam, bits) / tot });
        }
        var curveTable = Table.Of("rd_curve_d4096", new[] { "alpha", "bits_per_row", "min_relative_error" }, curve);
        var boundTable = Table.Of("bounds", new[]
        {
            "d", "alpha", "affine_k2_floor", "affine_k4_floor", "rd_rel_16bits", "rd_rel_32bits", "rd_rel_64bits", "rd_rel_256bits",
            "bits_for_rel_0.5", "bits_for_rel_0.2", "bits_for_rel_0.1", "bits_for_rel_0.01", "bits_0.1_over_bf16_row",
        }, bounds);

        // (3) Dynamics of random deployed cells: cycles and loss of seed identity over 4096 outputs.
        int rules = 200, seeds = 512;
        var dyn = Enumerable.Range(0, rules).AsParallel().AsOrdered().Select(ri =>
        {
            var g = Rng.Derive(Seed, 1000 + (ulong)ri);
            var (aa, g1) = Lin.Gaussians(g, 16);
            var (bb, g2) = Lin.Gaussians(g1, 16);
            var (cc, g3) = Lin.Gaussians(g2, 4);
            var rule = new CellParams(aa.Select(x => 0.5 * x).ToArray(), bb.ToArray(), cc.Select(x => 0.3 * x).ToArray(), 1.0).Deployed();
            int fixedPt = 0, shortCycle = 0, noRepeat = 0; double periodSum = 0; int periodCount = 0;
            var cueOnly = rule with { B = new double[16] };
            var tails = new HashSet<string>();
            var cueTails = new HashSet<string>();
            var gg = g3;
            for (int s = 0; s < seeds; s++)
            {
                var z = new double[4];
                for (int j = 0; j < 4; j++) { var (u, ng) = gg.NextUniform(-2, 2); z[j] = CellParams.Q8Seed(u); gg = ng; }
                var tr = Cell.Run(rule, z, 4096, true);
                int period = Period(tr.States, 4096);
                if (period > 0) { periodSum += period; periodCount++; }
                if (period == 1) fixedPt++; else if (period > 1 && period <= 64) shortCycle++; else if (period < 0) noRepeat++;
                tails.Add(string.Join(",", tr.Output.Skip(4064).Select(x => x.ToString("R", Fmt.Inv))));
                var tc = Cell.Run(cueOnly, z, 4096, true);
                cueTails.Add(string.Join(",", tc.Output.Skip(4064).Select(x => x.ToString("R", Fmt.Inv))));
            }
            return new object[] { ri, fixedPt / (double)seeds, shortCycle / (double)seeds, noRepeat / (double)seeds, tails.Count / (double)seeds, periodCount > 0 ? periodSum / periodCount : double.NaN, tails.Count, cueTails.Count };
        }).ToArray();
        var dynTable = Table.Of("dynamics", new[] { "rule", "fixed_point", "cycle_2_to_64", "no_repeat_4096", "distinct_tails_fraction", "mean_period", "distinct_tails", "distinct_tails_cue_only" }, dyn);
        h["dyn_fixed_point"] = dyn.Average(x => (double)x[1]);
        h["dyn_short_cycle"] = dyn.Average(x => (double)x[2]);
        h["dyn_no_repeat"] = dyn.Average(x => (double)x[3]);
        h["dyn_distinct_tails"] = dyn.Average(x => (double)x[4]);
        h["dyn_median_distinct_tails_of_512"] = dyn.Select(x => (double)(int)x[6]).OrderBy(x => x).ElementAt(rules / 2);
        h["dyn_median_distinct_tails_cue_only"] = dyn.Select(x => (double)(int)x[7]).OrderBy(x => x).ElementAt(rules / 2);
        h["dyn_mean_period"] = dyn.Where(x => !double.IsNaN((double)x[5])).Average(x => (double)x[5]);
        h["dyn_rules_all_tails_identical"] = dyn.Count(x => (double)x[4] <= 1.0 / seeds + 1e-12) / (double)rules;

        return new ExperimentResult("B01", "Rank, spectral and rate-distortion limits; cell dynamics", new[] { boundTable, curveTable, dynTable }, h);
    }

    /// <summary>Coefficients c0..c3 of the monic characteristic polynomial of a 4×4 matrix (Faddeev–LeVerrier).</summary>
    public static IReadOnlyList<double> CharPoly(IReadOnlyList<double> a)
    {
        const int n = 4;
        var M = new double[n, n];
        var coeff = new double[n + 1];
        coeff[n] = 1.0;
        var AM = new double[n, n];
        for (int k = 1; k <= n; k++)
        {
            // AM = A * M_{k-1}, with M_0 = 0 → AM = A·M + c_{n-k+1} A ; standard recursion M_k = A M_{k-1} + c_{n-k+1} I
            var Mk = new double[n, n];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                {
                    double s = 0;
                    for (int l = 0; l < n; l++) s += a[i * n + l] * M[l, j];
                    Mk[i, j] = s + (i == j ? coeff[n - k + 1] : 0.0);
                }
            double tr = 0;
            for (int i = 0; i < n; i++)
                for (int l = 0; l < n; l++) tr += a[i * n + l] * Mk[l, i];
            coeff[n - k] = -tr / k;
            M = Mk;
        }
        return coeff.Take(n).ToArray();
    }

    /// <summary>Period of the eventual cycle of a quantized trajectory, or -1 if no state repeats within the horizon.</summary>
    private static int Period(IReadOnlyList<double> states, int steps)
    {
        var seen = new Dictionary<(double, double, double, double), int>();
        for (int t = 0; t <= steps; t++)
        {
            var key = (states[4 * t], states[4 * t + 1], states[4 * t + 2], states[4 * t + 3]);
            if (seen.TryGetValue(key, out int first)) return t - first;
            seen[key] = t;
        }
        return -1;
    }
}
