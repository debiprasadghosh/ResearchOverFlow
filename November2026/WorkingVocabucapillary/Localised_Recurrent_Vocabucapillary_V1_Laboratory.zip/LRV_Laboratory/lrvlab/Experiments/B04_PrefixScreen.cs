using LrvLab.Core;

namespace LrvLab.Experiments;

/// <summary>
/// Does a short key prefix find the positions that full-width attention would weight? Width 1,024 stands in for 4,096
/// with the same fractions: prefixes of 16, 64 and 256 coordinates (1/64, 1/16, 1/4), 4,096 past positions and 256 survivors.
/// </summary>
public static class B04_PrefixScreen
{
    private const ulong Seed = 1618;
    public const int D = 1024, N = 4096, Keep = 256, Relevant = 8, Trials = 100;
    public const double Gamma = 0.35;

    public sealed record Condition(string Name, double Alpha, bool EnergyOrdered);

    public static ExperimentResult Run()
    {
        var conditions = new[]
        {
            new Condition("isotropic keys", 0.0, true),
            new Condition("power-law keys, energy-ordered emission", 1.0, true),
            new Condition("power-law keys, arbitrary coordinate order", 1.0, false),
        };
        var policies = new[] { "direct r=16", "direct r=64", "direct r=256", "cascade 16/64/256" };
        var rows = new List<object[]>();
        var h = new Dictionary<string, double>();
        foreach (var (c, ci) in conditions.Select((c, i) => (c, i)))
        {
            var lam = Lin.PowerSpectrum(D, c.Alpha).Select(l => l * D).ToArray();
            var sd = lam.Select(Math.Sqrt).ToArray();
            var trials = Enumerable.Range(0, Trials).AsParallel().AsOrdered().Select(t => Trial(c, sd, Rng.Derive(Seed, (ulong)(ci * 10000 + t)))).ToArray();
            for (int p = 0; p < policies.Length; p++)
            {
                double relRecall = trials.Average(x => x[p].RelevantRecall);
                double topRecall = trials.Average(x => x[p].Top8Recall);
                double delta = trials.Average(x => x[p].OmittedMass);
                double deltaBest = trials.Average(x => x[p].BestOmittedMass);
                rows.Add(new object[] { c.Name, policies[p], relRecall, topRecall, delta, deltaBest });
                string key = $"c{ci}_{policies[p].Replace(" ", "_").Replace("/", "-")}";
                h[$"{key}_relevant_recall"] = relRecall;
                h[$"{key}_top8_recall"] = topRecall;
                h[$"{key}_omitted_mass"] = delta;
            }
            h[$"c{ci}_prefix16_energy_share"] = lam.Take(16).Sum() / lam.Sum();
            h[$"c{ci}_best256_omitted_mass"] = trials.Average(x => x[0].BestOmittedMass);
        }
        var table = Table.Of("screen", new[] { "keys", "selector", "relevant_recall", "full_top8_recall", "omitted_mass", "omitted_mass_of_best_256" }, rows);
        return new ExperimentResult("B04", "Prefix screening and cascades", new[] { table }, h);
    }

    public sealed record Score(double RelevantRecall, double Top8Recall, double OmittedMass, double BestOmittedMass);

    private static IReadOnlyList<Score> Trial(Condition c, IReadOnlyList<double> sd, Rng rng)
    {
        var signs = Lin.Signs(Rng.Derive(Seed, 99), D).Values;                  // fixed basis per study
        var (gq, r) = Lin.Gaussians(rng, D);
        var q = gq.Select((g, j) => g * sd[j]).ToArray();
        var keys = new IReadOnlyList<double>[N];
        double qn = Math.Sqrt(Lin.Norm2(q));
        for (int i = 0; i < N; i++)
        {
            var (g, nr) = Lin.Gaussians(r, D); r = nr;
            var k = g.Select((x, j) => x * sd[j]).ToArray();
            if (i < Relevant)                                                  // relevant positions lean towards the query
            {
                double kn = Math.Sqrt(Lin.Norm2(k));
                for (int j = 0; j < D; j++) k[j] = Gamma * q[j] * kn / qn + Math.Sqrt(1 - Gamma * Gamma) * k[j];
            }
            keys[i] = c.EnergyOrdered ? k : Lin.Hadamard(k, signs);
        }
        var qq = c.EnergyOrdered ? (IReadOnlyList<double>)q : Lin.Hadamard(q, signs);
        // Prefix scores for every width that any selector uses (cumulative sums).
        var widths = new[] { 16, 64, 256, D };
        var score = widths.ToDictionary(w => w, w => (IReadOnlyList<double>)keys.Select(k => Lin.Dot(qq, k, 0, w) / Math.Sqrt(D)).ToArray());
        var full = score[D];
        var p = Lin.Softmax(full);
        var all = Enumerable.Range(0, N).ToArray();
        var top8 = Lin.TopIndices(full, all, 8).ToHashSet();
        var best = Lin.TopIndices(full, all, Keep);
        double bestDelta = 1 - best.Sum(i => p[i]);
        Score Eval(IReadOnlyList<int> kept)
        {
            var set = kept.ToHashSet();
            return new Score(Enumerable.Range(0, Relevant).Count(set.Contains) / (double)Relevant,
                top8.Count(set.Contains) / 8.0, 1 - kept.Sum(i => p[i]), bestDelta);
        }
        var direct16 = Lin.TopIndices(score[16], all, Keep);
        var direct64 = Lin.TopIndices(score[64], all, Keep);
        var direct256 = Lin.TopIndices(score[256], all, Keep);
        var s1 = Lin.TopIndices(score[16], all, 1024);
        var s2 = Lin.TopIndices(score[64], s1, 512);
        var s3 = Lin.TopIndices(score[256], s2, Keep);
        return new[] { Eval(direct16), Eval(direct64), Eval(direct256), Eval(s3) };
    }
}
