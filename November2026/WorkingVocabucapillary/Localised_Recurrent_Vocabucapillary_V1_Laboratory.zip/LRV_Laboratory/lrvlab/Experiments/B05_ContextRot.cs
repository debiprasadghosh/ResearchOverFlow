using LrvLab.Core;

namespace LrvLab.Experiments;

/// <summary>
/// A context-rot model for one attention head (width 128). The history holds one current record, obsolete near-duplicates
/// whose number grows with the history, and filler. Each value votes for an answer; the read is correct when the attended
/// value is closest to the current record's answer. Retention policies are compared at equal final budget.
/// </summary>
public static class B05_ContextRot
{
    private const ulong Seed = 5772;
    public const int D = 128, Dv = 64, Answers = 64, Keep = 256, Trials = 300;
    public const double MuCurrent = 6.0, MuObsolete = 4.0, SdObsolete = 0.5, ObsoleteRate = 1.0 / 256;

    public static readonly string[] Policies =
    {
        "full attention", "recent 256", "direct cut r=16", "cascade 16/32/64", "cascade + validity gain", "full + validity gain",
    };

    public static ExperimentResult Run()
    {
        var lengths = new[] { 256, 1024, 4096, 16384 };
        var rows = new List<object[]>();
        var h = new Dictionary<string, double>();
        var lam = Lin.PowerSpectrum(D, 1.0).Select(l => l * D).ToArray();                // energy-ordered keys
        double c = Math.Sqrt(lam.Sum(l => l * l) / lam.Sum());                         // unit noise along a typical query
        var sd = lam.Select(l => Math.Sqrt(l) / c).ToArray();
        h["noise_scale_c"] = c;
        var (pool, _) = Lin.Gaussians(Rng.Derive(Seed, 1), Answers * Dv);
        var answers = Enumerable.Range(0, Answers).Select(a =>
        {
            var v = pool.Skip(a * Dv).Take(Dv).ToArray();
            double n = Math.Sqrt(Lin.Norm2(v));
            return (IReadOnlyList<double>)v.Select(x => x / n).ToArray();
        }).ToArray();
        foreach (int n in lengths)
        {
            var res = Enumerable.Range(0, Trials).AsParallel().AsOrdered()
                .Select(t => Trial(n, sd, answers, Rng.Derive(Seed, (ulong)(n * 1000 + t)))).ToArray();
            for (int p = 0; p < Policies.Length; p++)
            {
                double acc = res.Average(x => x.Outcomes[p] == 0 ? 1.0 : 0.0);
                double wrongRev = res.Average(x => x.Outcomes[p] == 1 ? 1.0 : 0.0);
                double kept = res.Average(x => x.CurrentKept[p] ? 1.0 : 0.0);
                rows.Add(new object[] { n, Policies[p], acc, wrongRev, 1 - acc - wrongRev, kept });
                h[$"N{n}_{Policies[p].Replace(" ", "_").Replace("/", "-").Replace("=", "")}_acc"] = acc;
                h[$"N{n}_{Policies[p].Replace(" ", "_").Replace("/", "-").Replace("=", "")}_wrong_revision"] = wrongRev;
            }
            h[$"N{n}_switch_recall_strict_store"] = res.Average(x => x.SwitchStrict ? 1.0 : 0.0);
            h[$"N{n}_switch_recall_addressable"] = res.Average(x => x.SwitchAddressable ? 1.0 : 0.0);
            rows.Add(new object[] { n, "query switch: strict 256 store", h[$"N{n}_switch_recall_strict_store"], double.NaN, double.NaN, double.NaN });
            rows.Add(new object[] { n, "query switch: addressable history", h[$"N{n}_switch_recall_addressable"], double.NaN, double.NaN, double.NaN });
        }
        var table = Table.Of("policies", new[] { "history", "policy", "correct", "wrong_revision", "other_wrong", "current_record_retained" }, rows);
        return new ExperimentResult("B05", "Context rot and multistage retention", new[] { table }, h);
    }

    public sealed record TrialResult(IReadOnlyList<int> Outcomes, IReadOnlyList<bool> CurrentKept, bool SwitchStrict, bool SwitchAddressable);

    private static TrialResult Trial(int n, IReadOnlyList<double> sd, IReadOnlyList<IReadOnlyList<double>> answers, Rng rng)
    {
        var r = rng;
        (double, Rng) U(Rng x) => x.NextDouble();
        var (gq, r1) = Lin.Gaussians(r, D); r = r1;
        var q = gq.Select((g, j) => g * sd[j]).ToArray();
        var (gq2, r2) = Lin.Gaussians(r, D); r = r2;
        var q2 = gq2.Select((g, j) => g * sd[j]).ToArray();                // the later, switched query
        double qn = Math.Sqrt(Lin.Norm2(q)), q2n = Math.Sqrt(Lin.Norm2(q2));
        int nObs = Math.Max(1, (int)Math.Round(n * ObsoleteRate));
        // Roles: 0 current, 1..nObs obsolete, nObs+1 withdrawal notice (relevant to q2), rest filler; positions shuffled.
        var role = new int[n];
        var answer = new int[n];
        var mu = new double[n];
        var mu2 = new double[n];
        for (int i = 0; i < n; i++)
        {
            if (i == 0) { role[i] = 0; answer[i] = 0; mu[i] = MuCurrent; }
            else if (i <= nObs) { role[i] = 1; answer[i] = 1; var (g, nr) = r.NextGaussian(); r = nr; mu[i] = MuObsolete + SdObsolete * g; }
            else
            {
                role[i] = i == nObs + 1 ? 3 : 2;
                var (a, nr) = r.NextInt(Answers - 2); r = nr; answer[i] = 2 + a;
                if (role[i] == 3) mu2[i] = MuCurrent;
            }
        }
        var pos = Enumerable.Range(0, n).ToArray();                          // pos[record] = position in history
        for (int i = n - 1; i > 0; i--) { var (j, nr) = r.NextInt(i + 1); r = nr; (pos[i], pos[j]) = (pos[j], pos[i]); }
        var keys = new double[n][];
        for (int i = 0; i < n; i++)
        {
            var (g, nr) = Lin.Gaussians(r, D); r = nr;
            var k = new double[D];
            for (int j = 0; j < D; j++) k[j] = g[j] * sd[j] + mu[i] * q[j] / qn + mu2[i] * q2[j] / q2n;
            keys[i] = k;
        }
        double[] Scores(double[] qv, int w) => keys.Select(k => Lin.Dot(qv, k, 0, w) / Math.Sqrt(D) * Math.Sqrt(D) / Math.Sqrt(Lin.Norm2(qv))).ToArray();
        var full = Scores(q, D);
        var all = Enumerable.Range(0, n).ToArray();
        var recent = all.Where(i => pos[i] >= n - Keep).ToArray();
        var p16 = Scores(q, 16); var p32 = Scores(q, 32); var p64 = Scores(q, 64);
        var direct = Lin.TopIndices(p16, all, Keep);
        var c1 = Lin.TopIndices(p16, all, Math.Min(n, 1024));
        var c2 = Lin.TopIndices(p32, c1, 512);
        var cascade = Lin.TopIndices(p64, c2, Keep);
        var valid = all.Where(i => role[i] != 1).ToArray();                   // validity metadata removes superseded records
        var cascadeValid = Lin.TopIndices(p64, Lin.TopIndices(p32, Lin.TopIndices(p16, valid, Math.Min(valid.Length, 1024)), 512), Keep);
        var sets = new IReadOnlyList<int>[] { all, recent, direct, cascade, cascadeValid, valid };
        int Decide(IReadOnlyList<int> set)
        {
            var w = Lin.Softmax(set.Select(i => full[i]).ToArray());
            var y = new double[Dv];
            for (int s = 0; s < set.Count; s++) { var a = answers[answer[set[s]]]; for (int j = 0; j < Dv; j++) y[j] += w[s] * a[j]; }
            int best = 0; double bv = double.NegativeInfinity;
            for (int a = 0; a < Answers; a++) { double v = Lin.Dot(y, answers[a]); if (v > bv) { bv = v; best = a; } }
            return best == 0 ? 0 : best == 1 ? 1 : 2;
        }
        var outcomes = sets.Select(Decide).ToArray();
        var kept = sets.Select(s => s.Contains(0)).ToArray();
        // Query switch: is the withdrawal notice reachable for q2?
        int notice = nObs + 1;
        bool strict = cascade.Contains(notice);
        var s16 = Scores(q2, 16); var s32 = Scores(q2, 32); var s64 = Scores(q2, 64);
        var again = Lin.TopIndices(s64, Lin.TopIndices(s32, Lin.TopIndices(s16, all, Math.Min(n, 1024)), 512), Keep);
        return new TrialResult(outcomes, kept, strict, again.Contains(notice));
    }
}
