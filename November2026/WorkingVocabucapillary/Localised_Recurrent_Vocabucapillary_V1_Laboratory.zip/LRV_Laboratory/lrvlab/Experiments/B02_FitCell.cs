using LrvLab.Core;

namespace LrvLab.Experiments;

/// <summary>
/// Fits the 96-bit four-state cell to teacher tables and compares it with low-rank codes of equal seed size, with
/// more seed numbers, and with the Gaussian rate–distortion bound. Also fits seeds of withheld entries with the rule frozen.
/// </summary>
public static class B02_FitCell
{
    private const ulong Seed = 31415;
    public const int V = 512, D = 1024, Epochs = 400, Held = 64;

    public static ExperimentResult Run()
    {
        var rows = new List<object[]>();
        var h = new Dictionary<string, double>();
        var teachers = new List<TeacherTable>
        {
            TeacherTable.Synthetic(V + Held, D, 0.5, Seed, 1),
            TeacherTable.Synthetic(V + Held, D, 1.0, Seed, 2),
        };
        var real = Environment.GetEnvironmentVariable("LRV_TEACHER");
        if (!string.IsNullOrEmpty(real) && File.Exists(real)) teachers.Add(TeacherTable.Load(real, V + Held));

        foreach (var t in teachers)
        {
            var train = t.Rows.Take(V).ToArray();
            var held = t.Rows.Skip(V).Take(Held).ToArray();
            string tag = double.IsNaN(t.Alpha) ? "real" : $"a{t.Alpha:0.0}";
            void Add(string method, double bitsPerRow, IReadOnlyList<IReadOnlyList<double>> recon, double? trainLoss = null)
            {
                var f = Metrics.Compare(train, recon);
                rows.Add(new object[] { t.Name, method, bitsPerRow, f.RelativeError, f.MeanCosine, f.NeighbourOverlap });
                h[$"{tag}_{method}_rel"] = f.RelativeError;
                h[$"{tag}_{method}_cos"] = f.MeanCosine;
                h[$"{tag}_{method}_nn10"] = f.NeighbourOverlap;
            }

            var fits = new[] { (k: 4, q: true, name: "cell96_k4"), (k: 4, q: false, name: "cellfloat_k4"), (k: 2, q: true, name: "cell96_k2") }
                .Select(c => (c, fit: Cell.Fit(train, c.k, c.q, Epochs, Rng.Derive(Seed, 10 + (ulong)c.k + (c.q ? 100UL : 0UL)))))
                .ToArray();
            foreach (var (c, fit) in fits) Add(c.name, c.k * 8, fit.Table(V, D));

            if (t.Lambda.Count > 0)
            {
                foreach (int k in new[] { 2, 4, 16, 64 }) Add($"pca{k}_8bit", k * 8, LowRank(t, train, k));
                double tot = t.Lambda.Sum();
                foreach (int bits in new[] { 16, 32, 128, 512 })
                {
                    double rd = Lin.GaussianDistortion(t.Lambda, bits) / tot;
                    rows.Add(new object[] { t.Name, $"rd_bound_{bits}bits", bits, rd, double.NaN, double.NaN });
                    h[$"{tag}_rd_bound_{bits}"] = rd;
                }
                h[$"{tag}_affine_k4_floor"] = 1 - t.Lambda.Take(4).Sum() / tot;
            }

            // New entries: freeze the deployed rule and fit only the seeds of withheld rows.
            var best = fits[0].fit;
            var frozen = Cell.Fit(held, 4, true, Epochs, Rng.Derive(Seed, 77), best.Latent);
            var heldRecon = frozen.Table(Held, D);
            var fh = Metrics.Compare(held, heldRecon);
            var trainOnHeld = Metrics.Compare(train.Take(Held).ToArray(), best.Table(Held, D));
            h[$"{tag}_new_entry_rel"] = fh.RelativeError;
            h[$"{tag}_seen_entry_rel"] = trainOnHeld.RelativeError;
            rows.Add(new object[] { t.Name, "cell96_k4_new_entries_frozen_rule", 32, fh.RelativeError, fh.MeanCosine, double.NaN });
            h[$"{tag}_cell96_k4_loss_first"] = best.LossHistory[0];
            h[$"{tag}_cell96_k4_loss_last"] = best.LossHistory[^1];
        }
        var table = Table.Of("fidelity", new[] { "teacher", "method", "seed_bits_per_row", "relative_sq_error", "mean_cosine", "knn10_overlap" }, rows);
        return new ExperimentResult("B02", "Fitting the 96-bit cell to teacher tables", new[] { table }, h);
    }

    /// <summary>Projection on the k leading principal directions with each coefficient on an 8-bit grid over ±4σ.</summary>
    public static IReadOnlyList<IReadOnlyList<double>> LowRank(TeacherTable t, IReadOnlyList<IReadOnlyList<double>> rows, int k) =>
        rows.AsParallel().AsOrdered().Select(r =>
        {
            var p = t.Principal(r);
            var c = new double[t.D];
            for (int j = 0; j < k; j++)
            {
                double sigma = Math.Sqrt(t.Lambda[j]), step = 8 * sigma / 256;
                c[j] = Math.Clamp(Math.Round(p[j] / step), -128, 127) * step;
            }
            return t.FromPrincipal(c);
        }).ToArray();
}
