using LrvLab.Core;

namespace LrvLab.Experiments;

/// <summary>Exact accounting: table sizes, decode traffic, regeneration work, seed capacity and screening products.</summary>
public static class B00_Accounting
{
    public sealed record Model(string Name, long V, long D, bool Tied, double TotalParams);

    public static readonly IReadOnlyList<Model> Models = new Model[]
    {
        new("BERT-base", 30522, 768, true, 110e6),
        new("GPT-2 small", 50257, 768, true, 124e6),
        new("Llama 2 7B", 32000, 4096, false, 6.74e9),
        new("Mistral 7B", 32000, 4096, false, 7.24e9),
        new("Llama 3 8B", 128256, 4096, false, 8.03e9),
        new("Llama 3.2 1B", 128256, 2048, true, 1.24e9),
        new("Gemma 2B", 256000, 2048, true, 2.51e9),
        new("Gemma 7B", 256000, 3072, true, 8.54e9),
    };

    /// <summary>Operations per emitted coordinate of the four-state cell: 16 multiply-adds, 4 clips, 4 roundings (drive Bz+c is per row).</summary>
    public const double OpsPerCoordinate = 2 * 16 + 4 + 4;

    public static ExperimentResult Run()
    {
        var rows = Models.Select(m =>
        {
            double emb = m.V * m.D * (m.Tied ? 1 : 2);
            double denseBytes = m.V * m.D * 2.0;                       // one BF16 table
            double seedBytes = m.V * 4.0 + 12.0;                       // four 8-bit numbers per entry + 96-bit rule
            double weightBytes = m.TotalParams * 2.0;                 // all weights in BF16, read once per decode step
            double headBytes = m.V * m.D * 2.0;                       // output projection read per step
            double regenOps = m.V * m.D * OpsPerCoordinate;           // regenerate every output row per step
            double backboneFlops = 2.0 * m.TotalParams;               // ≈ 2 FLOPs per parameter per token
            return new object[]
            {
                m.Name, m.V, m.D, m.Tied ? "tied" : "untied", emb / 1e6, emb / m.TotalParams,
                denseBytes / (1 << 20), seedBytes / 1024.0, denseBytes / seedBytes,
                2.0 * m.D / weightBytes, headBytes / weightBytes, regenOps / 1e9, regenOps / backboneFlops,
                Math.Ceiling(Math.Log2(m.V)),
            };
        }).ToArray();
        var models = Table.Of("models", new[]
        {
            "model", "V", "d", "output_head", "embedding_params_M", "embedding_share_of_params", "dense_table_MiB",
            "seed_table_KiB", "dense_to_seed_ratio", "input_row_share_of_decode_bytes", "output_head_share_of_decode_bytes",
            "regenerate_head_Gops_per_token", "regenerate_over_backbone_flops", "min_seed_bits",
        }, rows);

        // Screening products for one query (N = 4096 eligible positions, d = 4096, survivors 256).
        long N = 4096, d = 4096;
        long full = N * d;
        long direct = N * 64 + 256 * (d - 64);
        long cascade = 4096 * 64 + 1024 * (256 - 64) + 512 * (1024 - 256) + 256 * (4096 - 1024);
        var stages = Table.Of("screen_products", new[] { "read", "products", "fraction_of_full" }, new[]
        {
            new object[] { "full width on all 4096", full, 1.0 },
            new object[] { "direct cut: 64 then 256 survivors", direct, direct / (double)full },
            new object[] { "cascade 64/256/1024/4096 with 1024/512/256", cascade, cascade / (double)full },
        });

        long llama3Bytes = 128256L * 4096 * 2;
        var lstm = 4 * 4 * (4 + 4 + 1);
        var h = new Dictionary<string, double>
        {
            ["llama3_dense_bytes"] = llama3Bytes,
            ["llama3_seed_bytes"] = 128256 * 4 + 12,
            ["row_payload_ratio"] = 4096 * 2 / 4.0,
            ["cell_bits"] = CellParams.LearnedBits,
            ["lstm_gate_scalars"] = lstm,
            ["two_8bit_seeds_capacity"] = Math.Pow(2, 16),
            ["llama3_min_seed_bits"] = Math.Ceiling(Math.Log2(128256)),
            ["products_full"] = full,
            ["products_direct"] = direct,
            ["products_cascade"] = cascade,
            ["direct_saving"] = 1 - direct / (double)full,
            ["odds_multiplier_0.9_0.1"] = 0.9 / 0.1,
        };
        foreach (var r in rows)
        {
            string key = ((string)r[0]).Replace(" ", "_").Replace(".", "").Replace("-", "_");
            h[$"{key}_embedding_share"] = (double)r[5];
            h[$"{key}_head_share_decode"] = (double)r[10];
            h[$"{key}_regen_over_backbone"] = (double)r[12];
        }
        return new ExperimentResult("B00", "Accounting of tables, traffic and screening", new[] { models, stages }, h);
    }
}
