using LrvLab.Core;

namespace LrvLab.Experiments;

/// <summary>Exact identities behind reusing one coefficient memory for every Attentionlet stage.</summary>
public static class B06_ExactChecks
{
    private const ulong Seed = 1414;

    public static ExperimentResult Run()
    {
        var h = new Dictionary<string, double>();
        var rng = Rng.Derive(Seed, 1);
        var (a, r1) = Lin.Gaussians(rng, 16);
        var (b, r2) = Lin.Gaussians(r1, 16);
        var (c, r3) = Lin.Gaussians(r2, 4);
        var rule = new CellParams(a.Select(x => 0.5 * x).ToArray(), b.ToArray(), c.Select(x => 0.3 * x).ToArray(), 0.7).Deployed();
        int atoms = 64, d = 4096, r = 64;
        var r4 = r3;
        var seeds = new IReadOnlyList<double>[atoms];
        for (int i = 0; i < atoms; i++)
        {
            var z = new double[4];
            for (int j = 0; j < 4; j++) { var (u, nr) = r4.NextUniform(-2, 2); z[j] = CellParams.Q8Seed(u); r4 = nr; }
            seeds[i] = z;
        }
        var fullRows = seeds.Select(z => Cell.Run(rule, z, d, true).Output).ToArray();
        var prefixRows = seeds.Select(z => Cell.Run(rule, z, r, true).Output).ToArray();
        // (1) A prefix run of r updates reproduces the first r outputs of the full run bit for bit.
        int mismatches = 0;
        for (int i = 0; i < atoms; i++) for (int t = 0; t < r; t++) if (fullRows[i][t] != prefixRows[i][t]) mismatches++;
        h["prefix_bit_mismatches"] = mismatches;
        h["atom0_output_sum"] = fullRows[0].Sum();
        h["all_atoms_abs_output_sum"] = fullRows.Sum(x => x.Sum(Math.Abs));
        h["atom5_output_t4095"] = fullRows[5][4095];

        // (2) Prefix of a coefficient mixture equals the mixture of prefixes (Equation 4 of the paper).
        double maxMix = 0, maxBoundRatio = 0, maxShortlistRatio = 0, maxOddsGap = 0, seedAvgGap = 0;
        var rr = r4;
        for (int trial = 0; trial < 200; trial++)
        {
            var ids = new int[8]; var w = new double[8];
            for (int k = 0; k < 8; k++) { var (id, n1) = rr.NextInt(atoms); var (u, n2) = n1.NextDouble(); rr = n2; ids[k] = id; w[k] = u; }
            double ws = w.Sum();
            for (int k = 0; k < 8; k++) w[k] /= ws;
            for (int t = 0; t < r; t++)
            {
                double mixFull = Enumerable.Range(0, 8).Sum(k => w[k] * fullRows[ids[k]][t]);
                double mixPrefix = Enumerable.Range(0, 8).Sum(k => w[k] * prefixRows[ids[k]][t]);
                maxMix = Math.Max(maxMix, Math.Abs(mixFull - mixPrefix));
            }
            // (3) Row errors bound mixture error: ||sum w (x - xhat)|| <= eps * sum |w|.
            var err = Enumerable.Range(0, 8).Select(_ => { var (g, n3) = Lin.Gaussians(rr, 32); rr = n3; return g; }).ToArray();
            double eps = err.Max(e => Math.Sqrt(Lin.Norm2(e)));
            var mixErr = Enumerable.Range(0, 32).Select(j => Enumerable.Range(0, 8).Sum(k => w[k] * err[k][j])).ToArray();
            maxBoundRatio = Math.Max(maxBoundRatio, Math.Sqrt(Lin.Norm2(mixErr)) / (eps * w.Sum(Math.Abs)));
            // (4) Shortlist bound ||y - y_S|| <= 2 B delta.
            int n = 64;
            var (logits, n4) = Lin.Gaussians(rr, n); rr = n4;
            var p = Lin.Softmax(logits.Select(x => 2 * x).ToArray());
            var vals = Enumerable.Range(0, n).Select(_ => { var (g, n5) = Lin.Gaussians(rr, 16); rr = n5; return g; }).ToArray();
            double B = vals.Max(v => Math.Sqrt(Lin.Norm2(v)));
            var S = Lin.TopIndices(p, Enumerable.Range(0, n).ToArray(), 16);
            double delta = 1 - S.Sum(i => p[i]);
            var y = Enumerable.Range(0, 16).Select(j => Enumerable.Range(0, n).Sum(i => p[i] * vals[i][j])).ToArray();
            var yS = Enumerable.Range(0, 16).Select(j => S.Sum(i => p[i] * vals[i][j]) / (1 - delta)).ToArray();
            double gap = Math.Sqrt(y.Select((v, j) => (v - yS[j]) * (v - yS[j])).Sum());
            maxShortlistRatio = Math.Max(maxShortlistRatio, gap / (2 * B * delta));
            // (5) Renormalising a shortlist multiplies evidence-to-distractor odds by rE / rD.
            var evidence = Enumerable.Range(0, 8).ToArray(); var distract = Enumerable.Range(8, n - 8).ToArray();
            var set = S.ToHashSet();
            double mE = evidence.Sum(i => p[i]), mD = distract.Sum(i => p[i]);
            double sE = evidence.Where(set.Contains).Sum(i => p[i]), sD = distract.Where(set.Contains).Sum(i => p[i]);
            if (sE > 0 && sD > 0)
            {
                double before = mE / mD, after = (sE / (sE + sD)) / (sD / (sE + sD));
                maxOddsGap = Math.Max(maxOddsGap, Math.Abs(after / before - (sE / mE) / (sD / mD)));
            }
            // (6) Decoding the average seed is not the average of decodes (the cell is nonlinear).
            var zAvg = Enumerable.Range(0, 4).Select(j => Enumerable.Range(0, 8).Sum(k => w[k] * seeds[ids[k]][j])).ToArray();
            var dAvg = Cell.Run(rule, zAvg, r, true).Output;
            double num = 0, den = 0;
            for (int t = 0; t < r; t++)
            {
                double mix = Enumerable.Range(0, 8).Sum(k => w[k] * prefixRows[ids[k]][t]);
                num += (dAvg[t] - mix) * (dAvg[t] - mix); den += mix * mix;
            }
            seedAvgGap += Math.Sqrt(num / den) / 200;
        }
        h["prefix_mixture_max_abs_gap"] = maxMix;
        h["mixture_bound_max_ratio"] = maxBoundRatio;
        h["shortlist_bound_max_ratio"] = maxShortlistRatio;
        h["odds_multiplier_max_gap"] = maxOddsGap;
        h["average_seed_relative_gap"] = seedAvgGap;
        var table = Table.Of("checks", new[] { "check", "value", "requirement" }, new[]
        {
            new object[] { "prefix run equals first r outputs (mismatching values)", mismatches, "0" },
            new object[] { "prefix of mixture minus mixture of prefixes (max abs)", maxMix, "rounding only" },
            new object[] { "mixture error / (eps * sum|w|) (max)", maxBoundRatio, "<= 1" },
            new object[] { "||y - y_S|| / (2 B delta) (max)", maxShortlistRatio, "<= 1" },
            new object[] { "odds multiplier minus rE/rD (max abs)", maxOddsGap, "rounding only" },
            new object[] { "decode(average seed) vs average of decodes (mean relative gap)", seedAvgGap, "> 0 for a nonlinear cell" },
        });
        return new ExperimentResult("B06", "Exact identities for one shared memory", new[] { table }, h);
    }
}
