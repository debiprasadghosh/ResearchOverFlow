using LrvLab.Core;

namespace LrvLab.Experiments;

/// <summary>
/// Can later network weights absorb what a compact seed does not carry? A synthetic next-token task whose true
/// conditional distributions follow the teacher geometry is learned by the same small backbone from different input
/// codes, with equal data and equal optimisation budget.
/// </summary>
public static class B03_Downstream
{
    private const ulong Seed = 2718;
    public const int V = 512, D = 128, H = 64, Pre = 128, Epochs = 300, Corpus = 100_000;
    public const double Beta = 8.0;

    public sealed record Variant(string Name, IReadOnlyList<IReadOnlyList<double>> Codes, bool TrainCodes, bool PreLayer);
    public sealed record Outcome(string Name, int CodeWidth, double TrainBits, double ExcessBits, double ExcessFrequent, double ExcessRare);

    public static ExperimentResult Run()
    {
        var teacher = TeacherTable.Synthetic(V, D, 1.0, Seed, 1);
        var e = teacher.Rows;
        // Token frequencies: Zipf over a random ranking of entries.
        var rng = Rng.Derive(Seed, 2);
        var order = Enumerable.Range(0, V).ToArray();
        for (int i = V - 1; i > 0; i--) { var (j, nr) = rng.NextInt(i + 1); rng = nr; (order[i], order[j]) = (order[j], order[i]); }
        var pi = new double[V];
        for (int r = 0; r < V; r++) pi[order[r]] = 1.0 / (r + 1);
        double zs = pi.Sum();
        for (int i = 0; i < V; i++) pi[i] /= zs;
        var norm = e.Select(x => Math.Sqrt(Lin.Norm2(x))).ToArray();
        var P = Enumerable.Range(0, V).Select(v =>
            Lin.Softmax(Enumerable.Range(0, V).Select(w => 0.5 * Math.Log(pi[w]) + Beta * Lin.Dot(e[v], e[w]) / (norm[v] * norm[w])).ToArray())).ToArray();
        double entropy = Enumerable.Range(0, V).Sum(v => pi[v] * -P[v].Where(p => p > 0).Sum(p => p * Math.Log2(p)));

        // Finite corpus of (current, next) pairs.
        var counts = new double[V, V];
        var cdfPi = Cumulative(pi);
        var cdfs = P.Select(Cumulative).ToArray();
        for (int n = 0; n < Corpus; n++)
        {
            var (u1, a) = rng.NextDouble(); var (u2, b) = a.NextDouble(); rng = b;
            int v = Search(cdfPi, u1), w = Search(cdfs[v], u2);
            counts[v, w] += 1;
        }
        var countRows = Enumerable.Range(0, V).Select(v => (IReadOnlyList<double>)Enumerable.Range(0, V).Select(w => counts[v, w]).ToArray()).ToArray();
        var rank = order.Select((tok, r) => (tok, r)).ToDictionary(x => x.tok, x => x.r);
        var frequent = Enumerable.Range(0, V).Where(v => rank[v] < V / 10).ToArray();
        var rare = Enumerable.Range(0, V).Where(v => rank[v] >= V / 2).ToArray();

        // Input codes.
        var cell = Cell.Fit(e, 4, true, 400, Rng.Derive(Seed, 3));
        var cellTable = cell.Table(V, D);
        var seeds = Enumerable.Range(0, V).Select(cell.Seed).ToArray();
        var (rand, _) = Lin.Gaussians(Rng.Derive(Seed, 4), V * D);
        var randomCodes = Enumerable.Range(0, V).Select(v => (IReadOnlyList<double>)rand.Skip(v * D).Take(D).ToArray()).ToArray();
        var (init, _) = Lin.Gaussians(Rng.Derive(Seed, 5), V * D);
        var learnedInit = Enumerable.Range(0, V).Select(v => (IReadOnlyList<double>)init.Skip(v * D).Take(D).ToArray()).ToArray();
        var variants = new[]
        {
            new Variant("dense_learned", learnedInit, true, false),
            new Variant("teacher_frozen", e, false, false),
            new Variant("pca64_frozen", B02_FitCell.LowRank(teacher, e, 64), false, false),
            new Variant("pca16_frozen", B02_FitCell.LowRank(teacher, e, 16), false, false),
            new Variant("pca4_frozen", B02_FitCell.LowRank(teacher, e, 4), false, false),
            new Variant("cell96_frozen", cellTable, false, false),
            new Variant("random_unique_frozen", randomCodes, false, false),
            new Variant("seed4_frozen", seeds, false, false),
            new Variant("seed4_plus_layer", seeds, false, true),
        };
        var fidelity = Metrics.Compare(e, cellTable);

        var outcomes = variants.AsParallel().AsOrdered().Select((vr, i) => Train(vr, countRows, P, pi, frequent, rare, entropy, Rng.Derive(Seed, 100 + (ulong)i))).ToArray();
        var table = Table.Of("variants", new[] { "input_code", "code_width", "train_bits", "excess_bits_all", "excess_bits_frequent_10pct", "excess_bits_rare_50pct" },
            outcomes.Select(o => new object[] { o.Name, o.CodeWidth, o.TrainBits, o.ExcessBits, o.ExcessFrequent, o.ExcessRare }));
        var h = new Dictionary<string, double> { ["true_conditional_entropy_bits"] = entropy, ["cell_rel_error"] = fidelity.RelativeError };
        foreach (var o in outcomes)
        {
            h[$"{o.Name}_excess"] = o.ExcessBits;
            h[$"{o.Name}_excess_rare"] = o.ExcessRare;
        }
        return new ExperimentResult("B03", "Downstream compensation by the backbone", new[] { table }, h);
    }

    private static Outcome Train(Variant vr, IReadOnlyList<IReadOnlyList<double>> counts, IReadOnlyList<IReadOnlyList<double>> P,
        IReadOnlyList<double> pi, IReadOnlyList<int> frequent, IReadOnlyList<int> rare, double entropy, Rng rng)
    {
        int m0 = vr.Codes[0].Count, m1 = vr.PreLayer ? Pre : m0;
        // parameter layout: codes (if trained) | Pw (Pre×m0) pb (Pre) | W (H×m1) b (H) | U (V×H) u0 (V)
        int oCodes = 0, nCodes = vr.TrainCodes ? V * m0 : 0;
        int oP = oCodes + nCodes, nP = vr.PreLayer ? Pre * m0 + Pre : 0;
        int oW = oP + nP, oB = oW + H * m1, oU = oB + H, oU0 = oU + V * H, n = oU0 + V;
        var th = new double[n];
        var r = rng;
        void Init(int start, int count, double sd) { for (int i = 0; i < count; i++) { var (g, nr) = r.NextGaussian(); th[start + i] = sd * g; r = nr; } }
        if (vr.TrainCodes) for (int v = 0; v < V; v++) for (int j = 0; j < m0; j++) th[v * m0 + j] = vr.Codes[v][j];
        if (vr.PreLayer) Init(oP, Pre * m0, Math.Sqrt(2.0 / m0));
        // Input scale: frozen codes are standardised so every variant sees unit average energy per coordinate.
        double codeScale = vr.TrainCodes ? 1.0 : 1.0 / Math.Sqrt(vr.Codes.Average(c => Lin.Norm2(c)) / m0);
        Init(oW, H * m1, Math.Sqrt(2.0 / m1));
        Init(oU, V * H, Math.Sqrt(1.0 / H));
        double total = counts.Sum(c => c.Sum());
        var m = new double[n]; var s2 = new double[n];
        double trainBits = 0;
        for (int ep = 1; ep <= Epochs + 1; ep++)
        {
            var snapshot = (double[])th.Clone();
            const int Chunks = 16;
            var parts = Enumerable.Range(0, Chunks).AsParallel().AsOrdered().Select(ch =>
            {
                var g = new double[n];
                double loss = 0;
                for (int v = ch; v < V; v += Chunks)
                {
                    var row = counts[v];
                    double cnt = row.Sum();
                    if (cnt == 0) continue;
                    loss += Forward(snapshot, vr, v, codeScale, m0, m1, oP, oW, oB, oU, oU0, row, cnt / total, g, true);
                }
                return (loss, g);
            }).ToArray();
            trainBits = parts.Sum(p => p.loss) / Math.Log(2);
            if (ep > Epochs) break;
            var grad = new double[n];
            foreach (var p in parts) for (int j = 0; j < n; j++) grad[j] += p.g[j];
            double lr = 0.01 * (ep > Epochs * 0.7 ? 0.3 : 1.0);
            for (int j = 0; j < n; j++)
            {
                m[j] = 0.9 * m[j] + 0.1 * grad[j];
                s2[j] = 0.999 * s2[j] + 0.001 * grad[j] * grad[j];
                double mh = m[j] / (1 - Math.Pow(0.9, ep)), vh = s2[j] / (1 - Math.Pow(0.999, ep));
                th[j] -= lr * mh / (Math.Sqrt(vh) + 1e-8);
            }
        }
        // Expected excess cross-entropy under the true distributions.
        var excess = new double[V];
        for (int v = 0; v < V; v++)
        {
            var q = Logits(th, vr, v, codeScale, m0, m1, oP, oW, oB, oU, oU0);
            var lq = LogSoftmax(q);
            excess[v] = P[v].Select((p, w) => p > 0 ? p * (Math.Log(p) - lq[w]) : 0.0).Sum() / Math.Log(2);
        }
        double Weighted(IEnumerable<int> set) { var s = set.ToArray(); return s.Sum(v => pi[v] * excess[v]) / s.Sum(v => pi[v]); }
        return new Outcome(vr.Name, m0, trainBits, Weighted(Enumerable.Range(0, V)), Weighted(frequent), Weighted(rare));
    }

    private static double[] Logits(IReadOnlyList<double> th, Variant vr, int v, double cs, int m0, int m1, int oP, int oW, int oB, int oU, int oU0)
    {
        var (x1, _, hid) = Hidden(th, vr, v, cs, m0, m1, oP, oW, oB);
        var q = new double[V];
        for (int w = 0; w < V; w++) { double s = th[oU0 + w]; for (int k = 0; k < H; k++) s += th[oU + w * H + k] * hid[k]; q[w] = s; }
        return q;
    }

    private static (double[] X1, double[] X0, double[] Hid) Hidden(IReadOnlyList<double> th, Variant vr, int v, double cs, int m0, int m1, int oP, int oW, int oB)
    {
        var x0 = new double[m0];
        for (int j = 0; j < m0; j++) x0[j] = vr.TrainCodes ? th[v * m0 + j] : vr.Codes[v][j] * cs;
        var x1 = x0;
        if (vr.PreLayer)
        {
            x1 = new double[Pre];
            for (int i = 0; i < Pre; i++) { double s = th[oP + Pre * m0 + i]; for (int j = 0; j < m0; j++) s += th[oP + i * m0 + j] * x0[j]; x1[i] = Math.Max(0, s); }
        }
        var hid = new double[H];
        for (int k = 0; k < H; k++) { double s = th[oB + k]; for (int j = 0; j < m1; j++) s += th[oW + k * m1 + j] * x1[j]; hid[k] = Math.Max(0, s); }
        return (x1, x0, hid);
    }

    private static double Forward(IReadOnlyList<double> th, Variant vr, int v, double cs, int m0, int m1, int oP, int oW, int oB, int oU, int oU0,
        IReadOnlyList<double> row, double weight, double[] g, bool _)
    {
        var (x1, x0, hid) = Hidden(th, vr, v, cs, m0, m1, oP, oW, oB);
        var q = new double[V];
        for (int w = 0; w < V; w++) { double s = th[oU0 + w]; for (int k = 0; k < H; k++) s += th[oU + w * H + k] * hid[k]; q[w] = s; }
        var lq = LogSoftmax(q);
        double cnt = row.Sum(), loss = 0;
        var gq = new double[V];
        for (int w = 0; w < V; w++)
        {
            double emp = row[w] / cnt;
            loss -= weight * emp * lq[w];
            gq[w] = weight * (Math.Exp(lq[w]) - emp);
        }
        var gh = new double[H];
        for (int w = 0; w < V; w++)
        {
            g[oU0 + w] += gq[w];
            for (int k = 0; k < H; k++) { g[oU + w * H + k] += gq[w] * hid[k]; gh[k] += gq[w] * th[oU + w * H + k]; }
        }
        var gx1 = new double[m1];
        for (int k = 0; k < H; k++)
        {
            if (hid[k] <= 0) continue;
            g[oB + k] += gh[k];
            for (int j = 0; j < m1; j++) { g[oW + k * m1 + j] += gh[k] * x1[j]; gx1[j] += gh[k] * th[oW + k * m1 + j]; }
        }
        var gx0 = gx1;
        if (vr.PreLayer)
        {
            gx0 = new double[m0];
            for (int i = 0; i < Pre; i++)
            {
                if (x1[i] <= 0) continue;
                g[oP + Pre * m0 + i] += gx1[i];
                for (int j = 0; j < m0; j++) { g[oP + i * m0 + j] += gx1[i] * x0[j]; gx0[j] += gx1[i] * th[oP + i * m0 + j]; }
            }
        }
        if (vr.TrainCodes) for (int j = 0; j < m0; j++) g[v * m0 + j] += gx0[j];
        return loss;
    }

    private static double[] LogSoftmax(IReadOnlyList<double> q)
    {
        double mx = q.Max();
        double lse = mx + Math.Log(q.Sum(x => Math.Exp(x - mx)));
        return q.Select(x => x - lse).ToArray();
    }

    private static double[] Cumulative(IReadOnlyList<double> p)
    {
        var c = new double[p.Count]; double s = 0;
        for (int i = 0; i < p.Count; i++) { s += p[i]; c[i] = s; }
        return c;
    }

    private static int Search(IReadOnlyList<double> cdf, double u)
    {
        double target = u * cdf[^1];
        int lo = 0, hi = cdf.Count - 1;
        while (lo < hi) { int mid = (lo + hi) / 2; if (cdf[mid] > target) hi = mid; else lo = mid + 1; }
        return lo;
    }
}
