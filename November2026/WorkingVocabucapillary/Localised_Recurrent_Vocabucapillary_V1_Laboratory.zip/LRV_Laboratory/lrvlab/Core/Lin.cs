namespace LrvLab.Core;

/// <summary>Pure numerical helpers. Buffers are local to each call and leave only as read-only lists.</summary>
public static class Lin
{
    public static (IReadOnlyList<double> Values, Rng Next) Gaussians(Rng rng, int n)
    {
        var x = new double[n];
        var r = rng;
        for (int i = 0; i < n; i++) { var (g, nr) = r.NextGaussian(); x[i] = g; r = nr; }
        return (x, r);
    }

    public static (IReadOnlyList<double> Values, Rng Next) Signs(Rng rng, int n)
    {
        var x = new double[n];
        var r = rng;
        for (int i = 0; i < n; i++) { var (u, nr) = r.NextUInt64(); x[i] = (u & 1UL) == 0 ? 1.0 : -1.0; r = nr; }
        return (x, r);
    }

    public static double Dot(IReadOnlyList<double> a, IReadOnlyList<double> b, int start = 0, int count = -1)
    {
        int end = count < 0 ? a.Count : start + count;
        double s = 0.0;
        for (int i = start; i < end; i++) s += a[i] * b[i];
        return s;
    }

    public static double Norm2(IReadOnlyList<double> a) => Dot(a, a);

    /// <summary>Orthonormal randomized Hadamard transform H = WHT·diag(signs)/sqrt(d); d must be a power of two.</summary>
    public static IReadOnlyList<double> Hadamard(IReadOnlyList<double> x, IReadOnlyList<double> signs)
    {
        int d = x.Count;
        var y = new double[d];
        for (int i = 0; i < d; i++) y[i] = x[i] * signs[i];
        for (int h = 1; h < d; h <<= 1)
            for (int i = 0; i < d; i += h << 1)
                for (int j = i; j < i + h; j++)
                {
                    double a = y[j], b = y[j + h];
                    y[j] = a + b; y[j + h] = a - b;
                }
        double s = 1.0 / Math.Sqrt(d);
        for (int i = 0; i < d; i++) y[i] *= s;
        return y;
    }

    /// <summary>Inverse of <see cref="Hadamard"/>: diag(signs)·WHT/sqrt(d).</summary>
    public static IReadOnlyList<double> HadamardInverse(IReadOnlyList<double> y, IReadOnlyList<double> signs)
    {
        var ones = Enumerable.Repeat(1.0, y.Count).ToArray();
        var t = Hadamard(y, ones);
        var x = new double[y.Count];
        for (int i = 0; i < x.Length; i++) x[i] = t[i] * signs[i];
        return x;
    }

    /// <summary>Indices of the m largest values (ties broken by lower index), in descending order of value.</summary>
    public static IReadOnlyList<int> TopIndices(IReadOnlyList<double> score, IReadOnlyList<int> candidates, int m)
    {
        if (candidates.Count <= m) return candidates.OrderByDescending(i => score[i]).ThenBy(i => i).ToArray();
        var keys = candidates.Select(i => score[i]).ToArray();
        var idx = candidates.ToArray();
        Array.Sort(keys, idx);                                   // ascending
        return idx.Skip(idx.Length - m).Reverse().ToArray();
    }

    public static IReadOnlyList<double> Softmax(IReadOnlyList<double> logits)
    {
        double mx = logits.Max();
        var e = logits.Select(v => Math.Exp(v - mx)).ToArray();
        double s = e.Sum();
        return e.Select(v => v / s).ToArray();
    }

    /// <summary>Gaussian rate-distortion by reverse water-filling: minimum mean squared error per row at R bits.</summary>
    public static double GaussianDistortion(IReadOnlyList<double> lambda, double bits)
    {
        double lo = 0.0, hi = lambda.Max();
        double Rate(double th) => lambda.Where(l => l > th).Sum(l => 0.5 * Math.Log2(l / th));
        for (int it = 0; it < 200; it++)
        {
            double mid = 0.5 * (lo + hi);
            if (Rate(mid) > bits) lo = mid; else hi = mid;
        }
        double theta = hi;
        return lambda.Sum(l => Math.Min(theta, l));
    }

    /// <summary>Bits per row needed by a Gaussian source to reach a relative distortion D/sum(lambda).</summary>
    public static double GaussianBitsFor(IReadOnlyList<double> lambda, double relDistortion)
    {
        double total = lambda.Sum();
        double lo = 0.0, hi = 1e6;
        for (int it = 0; it < 200; it++)
        {
            double mid = 0.5 * (lo + hi);
            if (GaussianDistortion(lambda, mid) / total > relDistortion) lo = mid; else hi = mid;
        }
        return hi;
    }

    public static IReadOnlyList<double> PowerSpectrum(int d, double alpha)
    {
        var l = Enumerable.Range(1, d).Select(j => Math.Pow(j, -alpha)).ToArray();
        double s = l.Sum();
        return l.Select(v => v / s).ToArray();
    }
}
