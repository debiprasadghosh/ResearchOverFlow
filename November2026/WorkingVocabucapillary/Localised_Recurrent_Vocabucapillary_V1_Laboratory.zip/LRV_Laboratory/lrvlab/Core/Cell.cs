namespace LrvLab.Core;

/// <summary>
/// The four-state recurrent cell of the proposal: h0 = z (seed padded to four), h(t+1) = Q(A h(t) + B z + c),
/// output y(t) = g · h(t+1)[0]. In the deployed form A and c are 4-bit values on a 1/8 grid, B holds signs scaled by
/// 1/4 (20·4 + 16 = 96 bits), the state is clipped to ±4 and rounded to a signed 16-bit grid (step 2^-12), seeds are
/// 8-bit on a 1/64 grid and g is one 16-bit output gain per dictionary.
/// </summary>
public sealed record CellParams(IReadOnlyList<double> A, IReadOnlyList<double> B, IReadOnlyList<double> C, double Gain)
{
    public const int S = 4;
    public const double Clip = 4.0, StateStep = 1.0 / 4096.0;

    public CellParams Deployed() => new(
        A.Select(Q4).ToArray(), B.Select(x => x >= 0 ? 0.25 : -0.25).ToArray(), C.Select(Q4).ToArray(), Gain);

    public static double Q4(double x) => Math.Clamp(Math.Round(x * 8.0), -8.0, 7.0) / 8.0;
    public static double Q8Seed(double x) => Math.Clamp(Math.Round(x * 64.0), -128.0, 127.0) / 64.0;

    /// <summary>Counts the learned bits of the deployed rule (excluding the output gain).</summary>
    public static int LearnedBits => 16 * 4 + 4 * 4 + 16 * 1;
}

public sealed record CellFit(CellParams Latent, IReadOnlyList<IReadOnlyList<double>> SeedsLatent, bool Quantized, int K,
    IReadOnlyList<double> LossHistory)
{
    public CellParams Rule => Quantized ? Latent.Deployed() : Latent;
    public IReadOnlyList<double> Seed(int v) => Quantized ? SeedsLatent[v].Select(CellParams.Q8Seed).ToArray() : SeedsLatent[v];
    public IReadOnlyList<double> Generate(int v, int d) => Cell.Run(Rule, Seed(v), d, Quantized).Output;
    public IReadOnlyList<IReadOnlyList<double>> Table(int v, int d) =>
        Enumerable.Range(0, v).AsParallel().AsOrdered().Select(i => Generate(i, d)).ToArray();
}

public static class Cell
{
    public sealed record Trajectory(IReadOnlyList<double> Output, IReadOnlyList<double> States);

    /// <summary>Runs the cell for d outputs. States holds h(0..d) flattened (4 per step).</summary>
    public static Trajectory Run(CellParams p, IReadOnlyList<double> seed, int d, bool quantizeState)
    {
        const int S = CellParams.S;
        var z = new double[S];
        for (int j = 0; j < seed.Count; j++) z[j] = seed[j];
        var drive = new double[S];
        for (int i = 0; i < S; i++)
        {
            double s = p.C[i];
            for (int j = 0; j < S; j++) s += p.B[i * S + j] * z[j];
            drive[i] = s;
        }
        var h = new double[(d + 1) * S];
        Array.Copy(z, h, S);
        var y = new double[d];
        for (int t = 0; t < d; t++)
        {
            int o = t * S, n = o + S;
            for (int i = 0; i < S; i++)
            {
                double s = drive[i];
                for (int j = 0; j < S; j++) s += p.A[i * S + j] * h[o + j];
                s = Math.Clamp(s, -CellParams.Clip, CellParams.Clip);
                h[n + i] = quantizeState ? Math.Round(s / CellParams.StateStep) * CellParams.StateStep : s;
            }
            y[t] = p.Gain * h[n];
        }
        return new Trajectory(y, h);
    }

    /// <summary>
    /// Fits one shared rule and one seed per row by backpropagation through time with Adam. When quantized is true the
    /// forward pass uses the deployed rule, seeds and state grid, and gradients pass straight through to the latent values.
    /// </summary>
    public static CellFit Fit(IReadOnlyList<IReadOnlyList<double>> rows, int k, bool quantized, int epochs, Rng rng, CellParams? fixedRule = null)
    {
        const int S = CellParams.S;
        int v = rows.Count, d = rows[0].Count;
        // latent parameter vector: A(16) B(16) C(4) gain(1) then seeds v*k
        int np = 16 + 16 + 4 + 1, n = np + v * k;
        var theta = new double[n];
        var r = rng;
        for (int i = 0; i < 16; i++) { var (g, nr) = r.NextGaussian(); theta[i] = 0.35 * g; r = nr; }
        for (int i = 16; i < 32; i++) { var (g, nr) = r.NextGaussian(); theta[i] = 0.5 * g; r = nr; }
        theta[36] = 1.0;
        if (fixedRule is not null)
        {
            for (int i = 0; i < 16; i++) { theta[i] = fixedRule.A[i]; theta[16 + i] = fixedRule.B[i]; }
            for (int i = 0; i < 4; i++) theta[32 + i] = fixedRule.C[i];
            theta[36] = fixedRule.Gain;
        }
        for (int i = np; i < n; i++) { var (g, nr) = r.NextGaussian(); theta[i] = 0.8 * g; r = nr; }
        double den = rows.Sum(x => Lin.Norm2(x));

        var m1 = new double[n]; var m2 = new double[n];
        double b1 = 0.9, b2 = 0.999, eps = 1e-8;
        var history = new List<double>();
        for (int ep = 1; ep <= epochs; ep++)
        {
            double lrP = 0.02 * Math.Min(1.0, ep / 20.0) * (ep > epochs * 0.7 ? 0.3 : 1.0);
            double lrZ = 2.5 * lrP;
            var latent = Unpack(theta, v, k, quantized);
            var rule = quantized ? latent.Rule : latent.Latent;
            var grads = Enumerable.Range(0, v).AsParallel().AsOrdered()
                .Select(i => RowGradient(rule, latent.Seed(i), rows[i], quantized, den)).ToArray();
            var grad = new double[n];
            double loss = 0;
            for (int i = 0; i < v; i++)
            {
                var (lv, gp, gz) = grads[i];
                loss += lv;
                for (int j = 0; j < np; j++) grad[j] += gp[j];
                for (int j = 0; j < k; j++) grad[np + i * k + j] += gz[j];
            }
            history.Add(loss);
            for (int j = fixedRule is null ? 0 : np; j < n; j++)
            {
                double gj = grad[j];
                m1[j] = b1 * m1[j] + (1 - b1) * gj;
                m2[j] = b2 * m2[j] + (1 - b2) * gj * gj;
                double mh = m1[j] / (1 - Math.Pow(b1, ep)), vh = m2[j] / (1 - Math.Pow(b2, ep));
                theta[j] -= (j >= np ? lrZ : lrP) * mh / (Math.Sqrt(vh) + eps);
                if (quantized && j >= 16 && j < 32) theta[j] = Math.Clamp(theta[j], -1.0, 1.0);
            }
        }
        return Unpack(theta, v, k, quantized) with { LossHistory = history };
    }

    private static CellFit Unpack(IReadOnlyList<double> theta, int v, int k, bool quantized)
    {
        var p = new CellParams(theta.Take(16).ToArray(), theta.Skip(16).Take(16).ToArray(), theta.Skip(32).Take(4).ToArray(), theta[36]);
        var seeds = Enumerable.Range(0, v).Select(i => (IReadOnlyList<double>)theta.Skip(37 + i * k).Take(k).ToArray()).ToArray();
        return new CellFit(p, seeds, quantized, k, Array.Empty<double>());
    }

    /// <summary>Relative squared loss of one row and its gradient with respect to the rule and the row's seed.</summary>
    private static (double Loss, double[] GradRule, double[] GradSeed) RowGradient(
        CellParams p, IReadOnlyList<double> seed, IReadOnlyList<double> x, bool quantized, double den)
    {
        const int S = CellParams.S;
        int d = x.Count, k = seed.Count;
        var tr = Run(p, seed, d, quantized);
        var h = tr.States;
        var z = new double[S];
        for (int j = 0; j < k; j++) z[j] = seed[j];
        var gRule = new double[37];
        var gz = new double[S];
        var gh = new double[S];
        double loss = 0;
        for (int t = d - 1; t >= 0; t--)
        {
            int o = t * S, nn = o + S;
            double e = tr.Output[t] - x[t];
            loss += e * e / den;
            double gy = 2 * e / den;
            gh[0] += gy * p.Gain;
            gRule[36] += gy * h[nn];
            var gpre = new double[S];
            for (int i = 0; i < S; i++)
                gpre[i] = Math.Abs(h[nn + i]) < CellParams.Clip ? gh[i] : 0.0;      // clip blocks the gradient
            var ghPrev = new double[S];
            for (int i = 0; i < S; i++)
            {
                if (gpre[i] == 0.0) continue;
                for (int j = 0; j < S; j++)
                {
                    gRule[i * S + j] += gpre[i] * h[o + j];
                    gRule[16 + i * S + j] += gpre[i] * z[j];
                    gz[j] += gpre[i] * p.B[i * S + j];
                    ghPrev[j] += gpre[i] * p.A[i * S + j];
                }
                gRule[32 + i] += gpre[i];
            }
            gh = ghPrev;
        }
        for (int j = 0; j < S; j++) gz[j] += gh[j];                              // h0 = z
        return (loss, gRule, gz.Take(k).ToArray());
    }
}
