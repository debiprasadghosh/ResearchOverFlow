namespace LrvLab.Core;

/// <summary>
/// A teacher embedding table. Synthetic tables have rows x_v = H(sqrt(lambda) ⊙ g_v) with g_v standard Gaussian,
/// a power-law spectrum lambda_j ∝ j^(-alpha) and a randomized Hadamard basis H, so principal directions are known
/// exactly and every coordinate carries mixed energy, as in a trained dense table.
/// </summary>
public sealed record TeacherTable(
    string Name, int V, int D, double Alpha,
    IReadOnlyList<IReadOnlyList<double>> Rows,
    IReadOnlyList<double> Lambda,
    IReadOnlyList<double> Signs)
{
    /// <summary>Coordinates of a row in the principal basis (exact for synthetic tables).</summary>
    public IReadOnlyList<double> Principal(IReadOnlyList<double> row) => Lin.HadamardInverse(row, Signs);

    public IReadOnlyList<double> FromPrincipal(IReadOnlyList<double> coords) => Lin.Hadamard(coords, Signs);

    public static TeacherTable Synthetic(int v, int d, double alpha, ulong seed, ulong stream)
    {
        var rng = Rng.Derive(seed, stream);
        var lambda = Lin.PowerSpectrum(d, alpha);
        var (signs, r1) = Lin.Signs(rng, d);
        var rows = new IReadOnlyList<double>[v];
        var r = r1;
        double scale = Math.Sqrt(d);                        // unit variance per coordinate on average
        for (int i = 0; i < v; i++)
        {
            var (g, nr) = Lin.Gaussians(r, d);
            r = nr;
            var c = new double[d];
            for (int j = 0; j < d; j++) c[j] = Math.Sqrt(lambda[j]) * g[j] * scale;
            rows[i] = Lin.Hadamard(c, signs);
        }
        return new TeacherTable($"synthetic a={alpha:0.##}", v, d, alpha, rows, lambda.Select(l => l * d).ToArray(), signs);
    }

    /// <summary>
    /// Loads a real table exported as little-endian int32 V, int32 d, then V·d float32 values (row major), keeps the
    /// first maxRows rows, centres them and pads d to the next power of two with zeros. The spectrum is then unknown
    /// (Lambda empty), so studies that need it skip the bound.
    /// </summary>
    public static TeacherTable Load(string path, int maxRows)
    {
        using var br = new BinaryReader(File.OpenRead(path));
        int v = br.ReadInt32(), d = br.ReadInt32();
        int n = Math.Min(v, maxRows), dp = 1;
        while (dp < d) dp <<= 1;
        var raw = new double[n][];
        for (int i = 0; i < n; i++)
        {
            raw[i] = new double[dp];
            for (int j = 0; j < d; j++) raw[i][j] = br.ReadSingle();
        }
        var mean = Enumerable.Range(0, dp).Select(j => raw.Average(r => r[j])).ToArray();
        double var = raw.Sum(r => r.Select((x, j) => (x - mean[j]) * (x - mean[j])).Sum()) / (n * (double)d);
        double s = 1.0 / Math.Sqrt(var);
        var rows = raw.Select(r => (IReadOnlyList<double>)r.Select((x, j) => j < d ? (x - mean[j]) * s : 0.0).ToArray()).ToArray();
        return new TeacherTable(Path.GetFileName(path), n, dp, double.NaN, rows, Array.Empty<double>(), Enumerable.Repeat(1.0, dp).ToArray());
    }
}

/// <summary>Reconstruction quality of a generated table against its teacher.</summary>
public sealed record Fidelity(double RelativeError, double MeanCosine, double NeighbourOverlap);

public static class Metrics
{
    public static Fidelity Compare(IReadOnlyList<IReadOnlyList<double>> teacher, IReadOnlyList<IReadOnlyList<double>> recon, int k = 10)
    {
        double num = 0, den = 0, cos = 0;
        for (int i = 0; i < teacher.Count; i++)
        {
            var t = teacher[i]; var r = recon[i];
            for (int j = 0; j < t.Count; j++) { double e = t[j] - r[j]; num += e * e; den += t[j] * t[j]; }
            double nr = Math.Sqrt(Lin.Norm2(r)), nt = Math.Sqrt(Lin.Norm2(t));
            cos += nr > 0 ? Lin.Dot(t, r) / (nr * nt) : 0.0;
        }
        return new Fidelity(num / den, cos / teacher.Count, NeighbourOverlap(teacher, recon, k));
    }

    /// <summary>Mean fraction of each row's k nearest cosine neighbours that the reconstruction preserves.</summary>
    public static double NeighbourOverlap(IReadOnlyList<IReadOnlyList<double>> a, IReadOnlyList<IReadOnlyList<double>> b, int k)
    {
        var na = Normalise(a); var nb = Normalise(b);
        int v = a.Count;
        double total = Enumerable.Range(0, v).AsParallel().AsOrdered().Select(i =>
        {
            var sa = Enumerable.Range(0, v).Select(j => j == i ? double.NegativeInfinity : Lin.Dot(na[i], na[j])).ToArray();
            var sb = Enumerable.Range(0, v).Select(j => j == i ? double.NegativeInfinity : Lin.Dot(nb[i], nb[j])).ToArray();
            var all = Enumerable.Range(0, v).ToArray();
            var ta = Lin.TopIndices(sa, all, k).ToHashSet();
            var tb = Lin.TopIndices(sb, all, k);
            return tb.Count(ta.Contains) / (double)k;
        }).Sum();
        return total / v;
    }

    private static IReadOnlyList<IReadOnlyList<double>> Normalise(IReadOnlyList<IReadOnlyList<double>> rows) =>
        rows.Select(r =>
        {
            double n = Math.Sqrt(Lin.Norm2(r));
            return (IReadOnlyList<double>)(n > 0 ? r.Select(x => x / n).ToArray() : r.ToArray());
        }).ToArray();
}
