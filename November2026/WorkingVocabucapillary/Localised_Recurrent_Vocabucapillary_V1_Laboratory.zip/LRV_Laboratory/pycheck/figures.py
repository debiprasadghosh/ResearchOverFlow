"""Figures for the paper, drawn from the C# laboratory outputs (plotting only, no computation)."""
import csv, os
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

_ROOT = Path(__file__).resolve().parent.parent
OUT = os.environ.get("LRV_OUT", str(_ROOT / "out")); FIG = os.environ.get("LRV_FIGS", str(_ROOT / "figs"))
os.makedirs(FIG, exist_ok=True)
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, GREEN, VIOLET, RED = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"
SER = [BLUE, ORANGE, AQUA, YELLOW, MAGENTA, VIOLET]
INK, INK2, MUTED, GRID = "#1f1f1f", "#52514e", "#8a8984", "#e4e3df"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9, "axes.labelsize": 8.5,
    "axes.edgecolor": MUTED, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True,
    "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False, "savefig.dpi": 220,
    "lines.linewidth": 2, "text.color": INK,
})

def rd(name): return list(csv.DictReader(open(f"{OUT}/{name}.csv")))
def save(fig, name): fig.savefig(f"{FIG}/{name}.png", bbox_inches="tight"); plt.close(fig)

# Figure 1: minimum relative error against bits per row (Gaussian rate–distortion bound, d = 4096).
c = rd("B01_rd_curve_d4096")
fig, ax = plt.subplots(figsize=(5.6, 3.1))
for i, a in enumerate(["0", "0.5", "1", "1.5"]):
    pts = [(float(r["bits_per_row"]), float(r["min_relative_error"])) for r in c if r["alpha"] == a]
    ax.plot([p[0] for p in pts], [p[1] for p in pts], color=SER[i], marker="o", ms=3, label=f"spectrum exponent α = {a}")
ax.axvline(32, color=MUTED, ls="--", lw=1); ax.text(34, 0.04, "four 8-bit seeds", color=INK2, fontsize=7.5)
ax.axvline(65536, color=MUTED, ls=":", lw=1); ax.text(9000, 0.92, "dense BF16 row", color=INK2, fontsize=7.5)
ax.set_xscale("log", base=2); ax.set_ylim(0, 1.02)
ax.set_xlabel("bits per row"); ax.set_ylabel("minimum relative squared error")
ax.legend(loc="center left", bbox_to_anchor=(1.01, 0.5), fontsize=7.5)
save(fig, "fig1_rate_distortion")

# Figure 2: reconstruction error of the fitted cell and low-rank codes.
f = rd("B02_fidelity")
methods = [("cell96_k4", "96-bit cell, 4 seeds"), ("cellfloat_k4", "float cell, 4 seeds"), ("cell96_k2", "96-bit cell, 2 seeds"),
           ("pca2_8bit", "rank 2, 8-bit"), ("pca4_8bit", "rank 4, 8-bit"), ("pca16_8bit", "rank 16, 8-bit"), ("pca64_8bit", "rank 64, 8-bit")]
fig, axes = plt.subplots(1, 2, figsize=(6.3, 2.9), sharey=True)
for ax, (tname, title) in zip(axes, [("synthetic a=0.5", "α = 0.5"), ("synthetic a=1", "α = 1")]):
    vals = [next(float(r["relative_sq_error"]) for r in f if r["teacher"] == tname and r["method"] == m) for m, _ in methods]
    cols = [ORANGE] * 3 + [BLUE] * 4
    ax.barh(range(len(vals)), vals, color=cols, height=0.62)
    for i, v in enumerate(vals): ax.text(v + 0.01, i, f"{v:.2f}", va="center", fontsize=7.5, color=INK)
    rd32 = next(float(r["relative_sq_error"]) for r in f if r["teacher"] == tname and r["method"] == "rd_bound_32bits")
    ax.axvline(rd32, color=INK2, ls="--", lw=1); ax.text(rd32 + 0.01, -0.75, "bound for any 32-bit code", ha="center", fontsize=7, color=INK2)
    ax.set_title(title, pad=14); ax.set_xlim(0, 1.12); ax.set_xlabel("relative squared error")
    ax.set_yticks(range(len(vals))); ax.set_yticklabels([n for _, n in methods])
axes[0].invert_yaxis()
save(fig, "fig2_cell_fit")

# Figure 3: downstream excess loss by input code.
d = rd("B03_variants")
names = {"dense_learned": "dense, learned", "teacher_frozen": "teacher, frozen", "pca64_frozen": "rank 64, frozen",
         "pca16_frozen": "rank 16, frozen", "pca4_frozen": "rank 4, frozen", "cell96_frozen": "96-bit cell, frozen",
         "random_unique_frozen": "random unique codes", "seed4_frozen": "4 seeds as input", "seed4_plus_layer": "4 seeds + learned layer"}
fig, ax = plt.subplots(figsize=(5.8, 3.3))
y = range(len(d)); w = 0.38
ax.barh([i - w / 2 for i in y], [float(r["excess_bits_all"]) for r in d], height=w, color=BLUE, label="all tokens (frequency-weighted)")
ax.barh([i + w / 2 for i in y], [float(r["excess_bits_rare_50pct"]) for r in d], height=w, color=ORANGE, label="rarest half of entries")
ax.set_yticks(list(y)); ax.set_yticklabels([names[r["input_code"]] for r in d]); ax.invert_yaxis()
ax.set_xlabel("excess cross-entropy over the true distribution (bits per token)")
ax.legend(loc="lower right", fontsize=7.5)
save(fig, "fig3_downstream")

# Figure 4: prefix screening recall.
s = rd("B04_screen")
conds = ["isotropic keys", "power-law keys, energy-ordered emission", "power-law keys, arbitrary coordinate order"]
labels = ["isotropic keys", "power-law, energy-ordered", "power-law, arbitrary order"]
sels = ["direct r=16", "direct r=64", "direct r=256", "cascade 16/64/256"]
fig, ax = plt.subplots(figsize=(5.8, 2.9))
w = 0.2
for ci, cnd in enumerate(conds):
    vals = [next(float(r["full_top8_recall"]) for r in s if r["keys"] == cnd and r["selector"] == sl) for sl in sels]
    ax.bar([i + (ci - 1) * w for i in range(len(sels))], vals, width=w * 0.92, color=SER[ci], label=labels[ci])
ax.set_xticks(range(len(sels))); ax.set_xticklabels(["prefix 16", "prefix 64", "prefix 256", "cascade 16→64→256"])
ax.set_ylabel("full-attention top 8 kept in final 256"); ax.set_ylim(0, 1.05)
ax.legend(fontsize=7.5, loc="upper left")
save(fig, "fig4_prefix_screen")

# Figure 5: context rot.
p = rd("B05_policies")
pols = ["full attention", "recent 256", "cascade 16/32/64", "full + validity gain", "cascade + validity gain"]
fig, axes = plt.subplots(1, 2, figsize=(6.4, 2.9))
for i, pol in enumerate(pols):
    pts = [(int(r["history"]), float(r["correct"]), float(r["wrong_revision"])) for r in p if r["policy"] == pol]
    axes[0].plot([x[0] for x in pts], [x[1] for x in pts], color=SER[i], marker="o", ms=3.5, label=pol)
    axes[1].plot([x[0] for x in pts], [x[2] for x in pts], color=SER[i], marker="o", ms=3.5)
for ax, t in zip(axes, ["correct answers", "answers from an obsolete revision"]):
    ax.set_xscale("log", base=2); ax.set_ylim(-0.03, 1.03); ax.set_title(t); ax.set_xlabel("records in history")
fig.legend(*axes[0].get_legend_handles_labels(), loc="lower center", ncol=3, fontsize=7.2, bbox_to_anchor=(0.5, -0.2))
save(fig, "fig5_context_rot")

# Figure 6: where vocabulary bytes sit.
m = rd("B00_models")
fig, ax = plt.subplots(figsize=(5.8, 2.9))
x = range(len(m)); w = 0.38
ax.bar([i - w / 2 for i in x], [float(r["embedding_share_of_params"]) for r in m], width=w, color=BLUE, label="vocabulary tables, share of parameters")
ax.bar([i + w / 2 for i in x], [float(r["output_head_share_of_decode_bytes"]) for r in m], width=w, color=ORANGE, label="output head, share of decode bytes")
ax.set_xticks(list(x)); ax.set_xticklabels([r["model"] for r in m], rotation=30, ha="right")
ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0, decimals=0))
ax.legend(fontsize=7.5, loc="upper right")
save(fig, "fig6_vocabulary_bytes")

# Figure 7: schematic of one memory read by every stage.
fig, ax = plt.subplots(figsize=(6.6, 2.7)); ax.set_axis_off(); ax.set_xlim(0, 10.6); ax.set_ylim(0, 4)
def box(x, y, w, h, t, fc, ec=INK2):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08", fc=fc, ec=ec, lw=1))
    ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", fontsize=6.8, color=INK)
box(0.05, 0.3, 2.45, 3.4, "Vocabucapillary memory\n\nper past position:\natom IDs + key and\nvalue coefficients\n\nper atom: seed z\n+ shared 96-bit rule", "#eef4fc")
stages = [("screen 1\n64 coords\n4,096 → 1,024", 2.95), ("screen 2\n256 coords\n1,024 → 512", 4.85), ("screen 3\n1,024 coords\n512 → 256", 6.75), ("full read\n4,096 coords\nvalues on 256", 8.65)]
for t, x in stages: box(x, 1.55, 1.6, 1.2, t, "#fdf0ea" if "full" not in t else "#eaf7f1")
for (_, x1), (_, x2) in zip(stages, stages[1:]):
    ax.annotate("", xy=(x2, 2.15), xytext=(x1 + 1.6, 2.15), arrowprops=dict(arrowstyle="->", color=INK2, lw=1))
for _, x in stages:
    ax.annotate("", xy=(x + 0.8, 1.55), xytext=(2.5, 0.75), arrowprops=dict(arrowstyle="->", color=BLUE, lw=0.9, connectionstyle="arc3,rad=0.12"))
ax.text(6.3, 0.3, "every stage unrolls the same seeds further; no second store", ha="center", fontsize=7.4, color=BLUE)
ax.text(9.45, 3.35, "causal working memory:\n≤ 256 references + output", ha="center", fontsize=6.8, color=INK2)
ax.annotate("", xy=(9.45, 3.05), xytext=(9.45, 2.75), arrowprops=dict(arrowstyle="->", color=INK2, lw=1))
save(fig, "fig7_one_memory")
print("figures written")
