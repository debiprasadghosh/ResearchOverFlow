"""Independent Python cross-check of the localised recurrent Vocabucapillary laboratory.

Ports the SplitMix64 generator, regenerates a teacher table and a deployed 96-bit cell, and recomputes closed forms.
Usage: python3 crosscheck.py [out_folder]
"""
import csv, json, math, sys
from pathlib import Path
import numpy as np

OUT = sys.argv[1] if len(sys.argv) > 1 else str(Path(__file__).resolve().parent.parent / "out")
H = json.load(open(f"{OUT}/headlines.json"))
M64 = (1 << 64) - 1


class Rng:
    def __init__(self, state): self.s = state & M64
    @staticmethod
    def derive(seed, stream):
        r = Rng(seed ^ ((stream * 0xD1B54A32D192ED03) & M64))
        r.u64(); return r
    def u64(self):
        self.s = (self.s + 0x9E3779B97F4A7C15) & M64
        z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return z ^ (z >> 31)
    def double(self): return (self.u64() >> 11) * (1.0 / 9007199254740992.0)
    def gauss(self):
        u1 = self.double(); u2 = self.double()
        return math.sqrt(-2.0 * math.log(1.0 - u1)) * math.cos(2.0 * math.pi * u2)
    def uniform(self, lo, hi): return lo + (hi - lo) * self.double()


rows = []
def check(name, cs, py, tol):
    rows.append((name, cs, py, abs(cs - py), abs(cs - py) <= tol))


# 1. PCA-4 fidelity of the alpha = 1 teacher of Study B02 (principal coordinates are exact by construction).
V, D, HELD = 512, 1024, 64
r = Rng.derive(31415, 2)
for _ in range(D): r.u64()                                           # Hadamard signs
lam = np.arange(1, D + 1, dtype=float) ** -1.0
lam = lam / lam.sum()
Lam = lam * D
num = den = 0.0
for v in range(V):
    g = np.array([r.gauss() for _ in range(D)])
    c = np.sqrt(lam) * g * math.sqrt(D)
    rec = np.zeros(D)
    for j in range(4):
        step = 8 * math.sqrt(Lam[j]) / 256
        rec[j] = min(max(round(c[j] / step), -128), 127) * step
    num += ((c - rec) ** 2).sum(); den += (c ** 2).sum()
check("B02 PCA-4 relative error, alpha=1", H["B02.a1.0_pca4_8bit_rel"], num / den, 1e-9)


# 2. Gaussian rate-distortion bounds by reverse water-filling.
def rd(lam, bits):
    lo, hi = 0.0, lam.max()
    for _ in range(200):
        th = 0.5 * (lo + hi)
        rate = (0.5 * np.log2(lam[lam > th] / th)).sum()
        if rate > bits: lo = th
        else: hi = th
    return np.minimum(hi, lam).sum() / lam.sum()
for a in [0.0, 0.5, 1.0, 1.5]:
    l4 = np.arange(1, 4097, dtype=float) ** -a; l4 /= l4.sum()
    check(f"B01 Gaussian bound at 32 bits, d=4096, alpha={a}", H[f"B01.d4096_a{a:.1f}_rd_32bits"], rd(l4, 32), 1e-6)
    check(f"B01 affine k=4 floor, d=4096, alpha={a}", H[f"B01.d4096_a{a:.1f}_affine_k4_floor"], 1 - l4[:4].sum(), 1e-12)
check("B02 Gaussian bound at 32 bits, d=1024, alpha=1", H["B02.a1.0_rd_bound_32"], rd(Lam, 32), 1e-6)


# 3. A deployed 96-bit cell from Study B06, run for 4,096 outputs on the 16-bit state grid.
def q4(x): return min(max(round(x * 8.0), -8.0), 7.0) / 8.0
def q8(x): return min(max(round(x * 64.0), -128.0), 127.0) / 64.0
r = Rng.derive(1414, 1)
a = [r.gauss() for _ in range(16)]; b = [r.gauss() for _ in range(16)]; c = [r.gauss() for _ in range(4)]
A = [q4(0.5 * x) for x in a]; B = [0.25 if x >= 0 else -0.25 for x in b]; C = [q4(0.3 * x) for x in c]; G = 0.7
seeds = [[q8(r.uniform(-2, 2)) for _ in range(4)] for _ in range(64)]
def run(z, d):
    drive = [C[i] + sum(B[i * 4 + j] * z[j] for j in range(4)) for i in range(4)]
    h = list(z); y = []
    for _ in range(d):
        nh = []
        for i in range(4):
            s = drive[i]
            for j in range(4): s += A[i * 4 + j] * h[j]
            s = min(max(s, -4.0), 4.0)
            nh.append(round(s / (1.0 / 4096.0)) * (1.0 / 4096.0))
        h = nh; y.append(G * h[0])
    return y
outs = [run(z, 4096) for z in seeds]
check("B06 cell output sum, atom 0", H["B06.atom0_output_sum"], sum(outs[0]), 1e-9)
check("B06 absolute output sum, 64 atoms", H["B06.all_atoms_abs_output_sum"], sum(sum(abs(x) for x in o) for o in outs), 1e-7)
check("B06 output of atom 5 at t=4095", H["B06.atom5_output_t4095"], outs[5][4095], 0.0)


# 4. Accounting.
check("B00 Llama 3 dense table bytes", H["B00.llama3_dense_bytes"], 128256 * 4096 * 2, 0)
check("B00 Llama 3 seed table bytes", H["B00.llama3_seed_bytes"], 128256 * 4 + 12, 0)
check("B00 direct-cut key products", H["B00.products_direct"], 4096 * 64 + 256 * (4096 - 64), 0)
check("B00 cascade key products", H["B00.products_cascade"], 4096 * 64 + 1024 * 192 + 512 * 768 + 256 * 3072, 0)
check("B00 Llama 3 8B embedding share", H["B00.Llama_3_8B_embedding_share"], 2 * 128256 * 4096 / 8.03e9, 1e-12)
check("B00 Llama 3 8B head regeneration over backbone FLOPs", H["B00.Llama_3_8B_regen_over_backbone"], 128256 * 4096 * 40 / (2 * 8.03e9), 1e-12)

with open(f"{OUT}/PY_crosscheck.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["quantity", "csharp", "python", "abs_difference", "agree"])
    for row in rows: w.writerow(row)
print(f"{sum(r[4] for r in rows)}/{len(rows)} agree")
for row in rows:
    if not row[4]: print("DISAGREE", row)
