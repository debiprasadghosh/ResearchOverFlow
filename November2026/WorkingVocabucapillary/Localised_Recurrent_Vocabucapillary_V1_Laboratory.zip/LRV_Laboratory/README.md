# Localised recurrent Vocabucapillary laboratory (immutable C#)

Companion to *Localised Recurrent Vocabucapillary: What a Seed-Generated Vocabulary Can Carry, and How Multistage
Attentionlet Meets Context Rot* (Ghosh, 2026). Every number, table and chart in the paper comes from `lrvlab/`.

| Folder | Contents |
|---|---|
| `lrvlab/` | .NET 8 console project, no packages. `Core/` (generator, linear algebra, teacher tables, the 96-bit cell, results); `Experiments/B00`–`B06`; `Program.cs` is the only code that writes files. |
| `out/` | Outputs used in the paper: CSV tables, `headlines.json`, `run_log.txt`, `PY_crosscheck.csv`. |
| `pycheck/` | `crosscheck.py` (independent port of the generator and cell; 19 checks) and `figures.py` (plots only). |
| `figs/` | The seven figures. |
| `paper/` | `build_paper.py` (assembles the Markdown from the outputs), `paper.md`, `ref.docx` (Word styles). |

## Running

```
cd lrvlab
dotnet run -c Release              # all seven studies, about 11 minutes on two cores; writes ../out
dotnet run -c Release -- B04 B05   # a subset (writes a partial headlines.json, so use LRV_OUT=/elsewhere)
cd ../pycheck && python3 crosscheck.py && python3 figures.py
cd ../paper && python3 build_paper.py && pandoc paper.md -o paper.docx --reference-doc=ref.docx
```

To run Study B02 on a real embedding table, export it as little-endian int32 V, int32 d, then V·d float32 values and
set `LRV_TEACHER=/path/to/table.bin`. The first 576 rows are centred, scaled and padded to a power-of-two width.

| Study | Question | Kind |
|---|---|---|
| B00 | Where do vocabulary bytes and screening products go? | Accounting |
| B01 | Rank, recurrence and rate–distortion limits; dynamics of deployed cells | Exact and Monte Carlo |
| B02 | Fitting the 96-bit cell to teacher tables | Trained model |
| B03 | Can the backbone absorb what a seed misses? | Trained model |
| B04 | Prefix screens and cascades against full attention | Monte Carlo |
| B05 | Context rot: dilution, staleness and the query switch | Monte Carlo |
| B06 | Exact identities for one shared memory | Exact |

Conventions: sealed records and read-only lists; pure static functions; `Rng` is a readonly record struct (SplitMix64)
whose draws return `(Value, Next)`; each study derives its stream with `Rng.Derive(seed, stream)`. Runs are
deterministic on a given platform.
