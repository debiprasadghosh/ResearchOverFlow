---
title: "Localised Recurrent Vocabucapillary: What a Seed-Generated Vocabulary Can Carry, and How Multistage Attentionlet Meets Context Rot"
author: "Debi Prasad Ghosh"
date: "November 2026"
abstract: |
  A language model's vocabulary table has one row of d coordinates for each of V tokenizer entries, and in small models with large vocabularies it holds a fifth of all parameters. This paper examines a proposal to replace each row by a seed of two to four numbers that a tiny shared recurrent cell of 96 bits expands into the full row, and to reuse one Vocabucapillary memory for every stage of a multistage Attentionlet read that should protect a small causal working memory from context rot. All numbers come from an immutable C# laboratory of seven studies with an independent Python cross-check. Three results are exact: the stages of a prefix cascade can share one coefficient memory without a second store, a four-state affine cell generates a table of rank at most four, and a Gaussian rate–distortion bound limits every decoder of a 32-bit seed. For teacher spectra from flat to steep, that bound leaves between 19% and 99% of each row's energy unrecoverable at width 4,096. The fitted 96-bit cell does worse than a rank-2 code (0.868 against 0.803 relative error), quantization is not the cause, and a backbone given the expanded rows learns a synthetic language worse than one given the four seeds directly. Seeds therefore compress storage and transmission only when they are sized by the rate–distortion curve, and the expansion should be energy-ordered rather than recurrent. The second half of the proposal survives with two amendments. A cascade of widening prefix screens keeps 99% of the top full-attention positions when coordinates are emitted in order of energy, and it removes the dilution form of context rot: with a validity gain on superseded records, accuracy at 16,384 records stays at 0.71, against 0.02 for full attention. Stale near-duplicates survive every screen, however, so the cascade alone answers from an obsolete revision as often as full attention does. A strict 256-record store also loses most later queries, so the history must stay addressable.
---

# 1 Introduction

The vocabulary of a language model has two sizes that are easily confused. The vocabulary size V counts the distinct entries of the tokenizer, from about 30,000 in BERT to 128,256 in Llama 3 and 256,000 in Gemma. The embedding width d counts the coordinates of each entry's vector, 768 in GPT-2 small and 4,096 in many larger models. The input table and, unless it is tied, the output projection each hold V × d parameters (Devlin et al., 2019; Radford et al., 2019; Touvron et al., 2023; Jiang et al., 2023; Grattafiori et al., 2024; Meta AI, 2024; Gemma Team, 2024). Larger vocabularies shorten sequences and serve more scripts, and scaling studies find that larger models deserve larger vocabularies (Tao et al., 2024). The cost is memory, per-step output computation and sparse training signal for rare rows.

This paper examines a proposal from the localised recurrent Vocabucapillary brief, which has fifty points. Each vocabulary entry receives a seed of two to four learned numbers. A tiny recurrent cell, shared by all entries of a local dictionary and costing about 96 bits, expands each seed into its 4,096-coordinate row, one coordinate per recurrent update. The cell is fitted to an existing embedding table before the network is trained, on the expectation that the backbone weights will absorb whatever the cell gets wrong. The brief offers a cortical microcolumn as the biological analogue of such a local recurrent expander.

The same recurrence gives the proposal its second half. Because the cell emits coordinates in order, the first 64 coordinates of a key are available after 64 updates. An Attentionlet read (Ghosh et al., 2025; Ghosh, 2026a) over a Vocabucapillary memory that replaces the key–value cache (Ghosh, 2026c) can therefore screen the history with short prefixes, unroll further only for survivors and complete full self-attention on a few hundred positions. Every stage reads the same memory, so no second store is needed. Retaining only the most relevant positions at each stage should reduce context rot, the decline in reliability as irrelevant, stale or conflicting material accumulates (Liu et al., 2024; Hong et al., 2025; Ghosh, 2026b).

The paper tests both halves numerically. Section 2 locates the bytes that a vocabulary costs. Section 3 defines the cell. Sections 4 to 6 ask what a seed can carry: limits that hold for every decoder, a fitted 96-bit cell, and whether a backbone can absorb the remainder. Sections 7 and 8 test the shared memory, the prefix cascade and context rot. Section 9 states the cortical hypothesis in testable form, Section 10 gives the revised design and Section 11 the limitations. Appendix A holds the proofs, Appendix B the laboratory and Appendix C the status of the fifty points.

The numerical work follows a standing rule of this series: every result is either an exact identity checked to machine precision, a Monte Carlo estimate with its sample size, or an accounting calculation with its assumptions. The studies are designed so that the proposal could fail, and where it fails the paper says so and gives the revised rule.

# 2 Where a vocabulary costs bytes

Table 1 sets out the vocabulary tables of eight published models. In BF16, the Llama 3 input table holds 1,050,673,152 bytes, or 1,002 MiB, and each row is 8 KiB. A seed table with four 8-bit numbers per entry and one 96-bit rule needs 513,036 bytes, or 501 KiB, so the row payload shrinks by a factor of 2,048.

Table: Table 1. Vocabulary tables in published models (BF16). The input row read per token is negligible; the output head is not. Regeneration counts 40 operations per emitted coordinate of the four-state cell.

| Model | V | d | Output head | Table share of parameters | Head share of decode bytes | Head regeneration / backbone FLOPs |
|------------|-----------|-----------|-----------|--------------|--------------|--------------|
| BERT-base | 30,522 | 768 | tied | 21.3% | 21.3% | 4.26 |
| GPT-2 small | 50,257 | 768 | tied | 31.1% | 31.1% | 6.23 |
| Llama 2 7B | 32,000 | 4,096 | untied | 3.9% | 1.9% | 0.39 |
| Mistral 7B | 32,000 | 4,096 | untied | 3.6% | 1.8% | 0.36 |
| Llama 3 8B | 128,256 | 4,096 | untied | 13.1% | 6.5% | 1.31 |
| Llama 3.2 1B | 128,256 | 2,048 | tied | 21.2% | 21.2% | 4.24 |
| Gemma 2B | 256,000 | 2,048 | tied | 20.9% | 20.9% | 4.18 |
| Gemma 7B | 256,000 | 3,072 | tied | 9.2% | 9.2% | 1.84 |

![Figure 1. Vocabulary tables as a share of parameters and the output head as a share of the bytes read per decode step.](../figs/fig6_vocabulary_bytes.png){width=5.6in}

Three facts follow from the accounting and shape everything else. First, storage and transmission scale with the parameter share, which is 13.1% for Llama 3 8B with its untied head but 21.2% for Llama 3.2 1B and 20.9% for Gemma 2B. The proposal matters most for small models with large vocabularies, which are also the models most often sent to edge devices, where quantized Vocabucapillary memories were proposed for the same reason (Ghosh, 2026d).

Second, the memory-bound cost of the input table during decoding is negligible. A decode step reads one input row of 2d bytes, which for Llama 3 8B is 5.1e−07 of the bytes it reads for all weights. Generating that row from a seed saves almost no bandwidth.

Third, the output head is read in full at every step, because exact next-token probabilities need a logit for every entry. It accounts for 6.5% of the decode bytes of Llama 3 8B and 21.2% of tied Llama 3.2 1B. A tied model can release the dense table only if the head also uses regenerated rows. Regenerating every row at every step with the four-state cell costs about 40 operations per coordinate, which is 1.31 times the backbone's own floating-point work per token for Llama 3 8B and 4.24 times for Llama 3.2 1B. In the memory-bound regime the seeds therefore buy storage and transmission, while output bandwidth requires caching rows, approximate or shortlisted logits, or an untied head kept dense.

# 3 The four-state recurrent cell

The cell has four state components. A seed z of k ≤ 4 learned numbers, padded with zeros to four, sets the initial state and also drives every update:

$$h_0 = z, \qquad h_{t+1} = Q\left(A h_t + B z + c\right), \qquad y_t = g \, h_{t+1,1}, \qquad t = 0, \ldots, d-1. \quad\quad\quad (1)$$

Here Q clips to ±4 and rounds to a signed 16-bit grid with step 2⁻¹². In the deployed rule the 16 entries of A and the four biases c are 4-bit values on a grid of 1/8, and the 16 entries of B are signs scaled by 1/4. That is 20 × 4 + 16 = 96 learned bits per dictionary. One 16-bit output gain g is added in this paper, and each seed coordinate is an 8-bit value on a grid of 1/64. Gated alternatives are costlier: a four-unit LSTM with four inputs already has 144 scalar gate parameters before its readout.

Two clocks run in the model. The outer clock selects tokens. The inner clock emits one coordinate per update, so the first r coordinates of a row are available after r updates and the full row after d. Seeds of k coordinates with b bits can name at most $2^{kb}$ rows: two 8-bit numbers give 65,536 names, too few for the 128,256 entries of Llama 3, which need at least 17 bits.

# 4 What a four-number seed can carry

Three limits apply before any training. Proofs are in Appendix A.

**Proposition 1 (counting).** A rule of P bits and V seeds of kb bits describe at most $2^{P+Vkb}$ tables. A table of V × d arbitrary 16-bit values cannot be recovered losslessly unless $P + Vkb \ge 16Vd$.

**Proposition 2 (affine rank).** If Q never clips or rounds, every generated row is an affine function of z, so the centred table has rank at most k. The squared singular values of the centred teacher beyond the k-th then lower-bound the total squared error. Moreover the coordinate differences $\Delta_t = y_{t+1} - y_t$ of every row obey one common recurrence,

$$\Delta_{t+4} + c_3 \Delta_{t+3} + c_2 \Delta_{t+2} + c_1 \Delta_{t+1} + c_0 \Delta_t = 0, \quad\quad\quad (2)$$

whose coefficients are those of the characteristic polynomial of A. The cell writes every row as the same four modes in different proportions.

**Proposition 3 (rate–distortion).** Let teacher rows be independent Gaussian vectors with covariance eigenvalues λⱼ. Any encoder and decoder that describe V rows with B bits in total, including the decoder's own description, have expected squared error per row of at least D(B/V), where reverse water-filling gives

$$D(R) = \sum_j \min(\theta, \lambda_j), \qquad R = \sum_{j : \lambda_j > \theta} \frac{1}{2} \log_2 \frac{\lambda_j}{\theta}. \quad\quad\quad (3)$$

With four 8-bit seeds and a 96-bit rule, B/V exceeds 32 bits by less than one bit for any practical V. The bound holds for any architecture: recurrent, feedforward or a lookup.

Study B01 checks the first two propositions and evaluates the third. With a random affine cell whose state never reached the clip (maximum 3.72), 256 rows of width 4,096 equalled the affine prediction from five basis runs to a relative error of 1.8e−16. Equation 2 held to 1.6e−08, a residual limited by cancellation in the differences.

Table: Table 2. Minimum relative squared error of any code for a Gaussian teacher row of width 4,096 with eigenvalues $\lambda_j \propto j^{-\alpha}$. The affine floor applies to any affine decoder of a four-number seed; the rate–distortion bound applies to every decoder.

| Spectrum exponent α | Affine floor, k = 4 | Bound at 32 bits | Bound at 256 bits | Bits for 10% error | Bits for 1% error | Compression at 10% vs BF16 |
|--------------|--------------|--------------|--------------|--------------|--------------|--------------|
| 0 | 0.999 | 0.989 | 0.917 | 6,803 | 13,607 | 10× |
| 0.5 | 0.978 | 0.935 | 0.800 | 6,265 | 13,068 | 10× |
| 1 | 0.766 | 0.613 | 0.386 | 3,297 | 10,100 | 20× |
| 1.5 | 0.353 | 0.192 | 0.063 | 112 | 2,985 | 583× |

![Figure 2. Minimum relative error of any code for a Gaussian teacher row of width 4,096, by bits per row.](../figs/fig1_rate_distortion.png){width=5.4in}

Table 2 and Figure 2 show the consequence. Trained embedding tables have high effective rank, so the realistic range lies between the flat and the moderately steep spectra. At α = 1, no 32-bit code of any kind can recover more than 39% of a row's energy, and an affine four-seed decoder at most 23%. Reaching 10% error needs 3,297 bits per row, about a twentieth of a BF16 row. That is still a strong compression, but it is a hundred times the size of a four-number seed. Only a very steep spectrum, α = 1.5, brings the cost near the proposal, at 112 bits.

The deployed cell is nonlinear, and Study B01 also measured how its trajectories behave over 4,096 updates. Across 200 random 96-bit rules with 512 seeds each, 31% of trajectories settled on a fixed point, 64% entered a cycle of period 2 to 64, and 0.2% did not repeat within the horizon. The mean period was 42.97 updates, so the late coordinates of a row mostly repeat earlier ones. Seed identity nevertheless survived to the end: the median rule gave 506 distinct final segments for 512 seeds, because the continuing drive Bz places each seed's attractor differently. When the seed set only the initial state (B = 0), the median fell to 3. A cue given once is forgotten; a cue that keeps driving the circuit is not. Section 9 returns to this distinction.

# 5 Fitting the 96-bit cell to a teacher table

Study B02 fitted the cell to 512 rows of synthetic teacher tables of width 1,024. Each teacher row is a Gaussian vector with eigenvalues $\lambda_j \propto j^{-\alpha}$, rotated by a randomized Hadamard transform so that every coordinate mixes all principal directions, as in a trained dense table. Real tables could not be obtained in this workspace; Appendix B gives the loader that runs the same study on any exported table. Training used backpropagation through time with Adam for 400 epochs, the deployed quantization in the forward pass and straight-through gradients. The loss fell from 1.086 to 0.868 of the teacher energy and was flat at the end.

Table: Table 3. Reconstruction of 512 teacher rows of width 1,024. Rank-k codes use the leading principal directions, whose basis costs 16k·d bits once per dictionary.

| Code | Seed bits per row | Relative error, α = 0.5 | Relative error, α = 1 | Mean cosine, α = 1 | 10-NN overlap, α = 1 |
|-----------------------------|--------------|--------------|--------------|--------------|--------------|
| 96-bit cell, four 8-bit seeds | 32 | 0.983 | 0.868 | 0.281 | 0.067 |
| Unquantized cell, four seeds | 32 | 0.985 | 0.869 | 0.277 | 0.053 |
| 96-bit cell, two 8-bit seeds | 16 | 0.985 | 0.869 | 0.277 | 0.056 |
| Rank 2, 8-bit coefficients | 16 | 0.973 | 0.803 | 0.383 | 0.088 |
| Rank 4, 8-bit coefficients | 32 | 0.956 | 0.724 | 0.478 | 0.234 |
| Rank 16, 8-bit coefficients | 128 | 0.895 | 0.551 | 0.646 | 0.563 |
| Rank 64, 8-bit coefficients | 512 | 0.767 | 0.368 | 0.783 | 0.779 |
| Bound for any 32-bit code | 32 | 0.869 | 0.542 | – | – |
| Bound for any 512-bit code | 512 | 0.421 | 0.181 | – | – |

![Figure 3. Relative reconstruction error of the fitted cell and of low-rank codes. The dashed line is the bound for any 32-bit code.](../figs/fig2_cell_fit.png){width=6in}

Table 3 gives the result. The 96-bit cell with four seeds leaves 0.868 of the energy unexplained at α = 1, worse than the rank-2 code (0.803) and well above the rank-4 code at the same seed size (0.724). Quantization is not the cause: the unquantized cell reaches 0.869, and the cell with only two seeds 0.869. The architecture is the limit. A shared four-state recurrence generates each row from the same few modes, Equation 2, while a teacher row in an arbitrary coordinate basis carries no such order. The rank-4 code meets the affine floor of Proposition 2 (0.723), and both sit above the rate–distortion bound for 32 bits (0.542), which only a much larger codebook could approach.

Neighbourhoods are lost even faster than energy. Of each row's ten nearest neighbours by cosine, the cell preserves 6.7%, the rank-4 code 23.4% and the rank-64 code 77.9%. New entries fare no better than old ones. With the rule frozen, seeds fitted to 64 withheld rows reached 0.892, against 0.869 for rows seen in training, so admitting an entry is cheap but its row is as poor as the rest.

# 6 Can the backbone absorb the rest?

The brief expects the network weights to cover what the cell misses. Proposition 4 in Appendix A sets the outer limit: if two entries receive identical inputs, a deterministic backbone cannot tell them apart in identical contexts. Distinct seeds avoid that collapse, but they do not say how much training it costs to rebuild lost geometry. Study B03 measured it.

A synthetic language of 512 entries was built from a teacher table of width 128: the next token w after v follows $P(w \mid v) \propto \pi_w^{1/2} \exp(8 \cos(e_v, e_w))$, with Zipf token frequencies $\pi$. The task therefore rewards exactly the geometry that a good embedding preserves. A small backbone, one hidden layer of 64 units and a learned output layer, was trained on 100,000 token pairs from each input code with the same optimiser and number of epochs. Excess loss was measured against the true distribution.

Table: Table 4. Excess cross-entropy in bits per token over the true conditional entropy (2.18 bits) after equal training on 100,000 token pairs. Lower is better.

| Input code | Width | Excess, all tokens | Excess, rarest half |
|---------------------------------|-----------|--------------|--------------|
| Dense table, learned from scratch | 128 | 0.662 | 2.463 |
| Teacher table, frozen | 128 | 0.290 | 0.816 |
| Rank 64 of teacher, frozen | 128 | 0.283 | 0.787 |
| Rank 16 of teacher, frozen | 128 | 0.258 | 0.743 |
| Rank 4 of teacher, frozen | 128 | 0.468 | 1.498 |
| 96-bit cell expansion, frozen | 128 | 1.554 | 3.843 |
| Random unique codes, frozen | 128 | 0.450 | 1.408 |
| Four seeds fed directly | 4 | 0.701 | 2.387 |
| Four seeds + one learned layer | 4 | 0.491 | 1.538 |

![Figure 4. Excess cross-entropy by input code, for all tokens and for the rarest half of entries.](../figs/fig3_downstream.png){width=5.6in}

Three findings stand out in Table 4. First, the expanded rows of the fitted cell are the worst input of all (1.554 excess bits), worse than feeding the four seeds directly (0.701) and worse than random unique codes (0.450). The expansion does not merely fail to add information; its correlated rows make the seeds harder to read. Second, the backbone can absorb a compact identity code, but at a cost. Four seeds followed by one learned layer reach 0.491, close to a frozen rank-4 code (0.468), while frozen teacher geometry reaches 0.290 and a rank-16 code 0.258. Third, rare entries carry the difference. For the rarest half of entries, a dense table learned from scratch overfits to 2.463 excess bits, while the frozen rank-16 code holds 0.743. Pre-fitting to a teacher is valuable, as the brief proposes, but it must preserve geometry, which takes tens of numbers per row, not four.

# 7 One Vocabucapillary memory for every Attentionlet stage

Let position i store active key atoms $A_i$ with coefficients $\alpha^K_{ia}$, so that its key is

$$k_i = \sum_{a \in A_i} \alpha^K_{ia} \, D_K(z_a), \qquad P_r k_i = \sum_{a \in A_i} \alpha^K_{ia} \, P_r D_K(z_a), \quad\quad\quad (4)$$

where $P_r$ keeps the first r coordinates. The second identity follows from linearity, and because the cell is causal in its coordinates, $P_r D_K(z_a)$ is exactly the output of r updates. Every screen therefore reads the same atom IDs and coefficients, and the full read continues the same trajectories (Figure 5). Study B06 confirmed both statements exactly. Runs of 64 updates matched the first 64 of 4,096 outputs bit for bit (0 mismatches), and prefixes of eight-atom mixtures equalled mixtures of prefixes with a maximum gap of 0.0e+00. Mixing must follow decoding: decoding the average seed differed from averaging the decoded rows by 0.25% on average over the first 64 coordinates. That gap is small for this rule only because early updates rarely clip.

![Figure 5. One Vocabucapillary memory read by every stage of a multistage Attentionlet.](../figs/fig7_one_memory.png){width=6.2in}

A shortlist S of the full softmax weights p, omitting mass $\delta = 1 - \sum_{i \in S} p_i$, changes the read by at most

$$\lVert y - y_S \rVert \le 2B\delta, \quad\quad\quad (5)$$

when all value norms are at most B. Renormalising a shortlist multiplies the odds of evidence over distractors by $r_E/r_D$, the fractions of their masses that survive. Study B06 found the bound ratio never above 0.37 and the odds identity exact to 4e−16 over 200 random cases.

Screening costs follow from the brief's example of 4,096 eligible positions, width 4,096 and 256 survivors. Full-width scores need 16,777,216 key products. A direct cut at 64 coordinates needs 1,294,336, 92.3% fewer. The cascade of 64, 256 and 1,024 coordinates with 1,024, 512 and 256 survivors needs 1,638,400, and a direct cut at 256 coordinates needs 2,031,616.

Study B04 measured what each screen keeps, at width 1,024 with the same fractions (prefixes of 16, 64 and 256 coordinates). The metric is agreement with full attention: the share of the eight highest full-width scores among the 256 survivors.

Table: Table 5. Share of the eight highest full-width scores kept among 256 survivors of 4,096 positions (omitted softmax mass in brackets). Width 1,024 with prefixes of 16, 64 and 256 coordinates; 100 queries per condition.

| Keys | Prefix 1/64 | Prefix 1/16 | Prefix 1/4 | Cascade 1/64 → 1/16 → 1/4 |
|-------------------------------|------------|------------|------------|--------------|
| Isotropic keys | 0.43 (0.527) | 0.90 (0.072) | 1.00 (0.008) | 0.76 (0.216) |
| Power-law keys, energy-ordered | 0.90 (0.055) | 0.99 (0.011) | 1.00 (0.008) | 0.99 (0.010) |
| Power-law keys, arbitrary order | 0.62 (0.253) | 0.97 (0.022) | 1.00 (0.006) | 0.90 (0.074) |

![Figure 6. Agreement of prefix screens and cascades with full attention.](../figs/fig4_prefix_screen.png){width=5.6in}

The ordering of coordinates decides whether a short prefix is informative. With isotropic keys, a 1/64 prefix holds 1/64 of the score and keeps only 0.43 of the top positions. When keys have a power-law spectrum and the coordinates are emitted in order of energy, the same prefix holds 45% of the energy and keeps 0.90. In an arbitrary basis it keeps 0.62. The cascade improves on its own first screen in every condition: from 0.43 to 0.76 for isotropic keys and from 0.62 to 0.90 in an arbitrary basis. With energy-ordered emission it reaches 0.99 at less cost than a direct cut at 1/4. Related systems choose large query components (Ribar et al., 2024) or low-rank key projections (Singhania et al., 2024) for the same reason. Emission order is therefore a design requirement: the generator must emit keys in a basis whose leading coordinates carry the most variance, applying the same rotation to the query.

# 8 Multistage Attentionlet and context rot

Study B05 modelled context rot in one attention head of width 128 with energy-ordered keys. A history holds one current record, obsolete near-duplicates whose number grows with the history (one per 256 records), a withdrawal notice relevant only to a later query, and filler. Each value votes for an answer from a pool of 64. Only the current record votes for the correct answer, and every obsolete note votes for the same wrong revision. A read is correct when the attended value lies closest to the correct answer. All policies keep at most 256 records for the final read, and every final read uses full-width scores.

Table: Table 6. Correct answers / answers taken from an obsolete revision, by history length (300 trials each). The last two rows give the share of later queries that can still reach a withdrawal notice.

| Policy | 256 records | 1,024 | 4,096 | 16,384 |
|--------------------------------|-----------|-----------|-----------|-----------|
| full attention | 0.93 / 0.05 | 0.54 / 0.44 | 0.07 / 0.93 | 0.00 / 1.00 |
| recent 256 | 0.93 / 0.05 | 0.18 / 0.44 | 0.05 / 0.41 | 0.01 / 0.55 |
| direct cut r=16 | 0.93 / 0.05 | 0.55 / 0.44 | 0.08 / 0.92 | 0.00 / 1.00 |
| cascade 16/32/64 | 0.93 / 0.05 | 0.55 / 0.44 | 0.07 / 0.93 | 0.00 / 1.00 |
| full + validity gain | 0.98 / 0.00 | 0.88 / 0.00 | 0.42 / 0.00 | 0.02 / 0.00 |
| cascade + validity gain | 0.98 / 0.00 | 0.92 / 0.00 | 0.85 / 0.00 | 0.71 / 0.00 |
| Later query, strict 256 store | 1.00 | 0.36 | 0.15 | 0.09 |
| Later query, addressable history | 1.00 | 1.00 | 1.00 | 0.97 |

![Figure 7. Correct answers and answers from an obsolete revision as the history grows.](../figs/fig5_context_rot.png){width=6.2in}

Two forms of context rot separate cleanly in Table 6. Dilution arises when filler shares the softmax mass. With superseded records removed by a validity gain, full attention falls from 0.98 to 0.02 as the history grows to 16,384 records, while the cascade holds 0.71. Multistage selection is the remedy for dilution, as the brief predicts. Staleness is the other form. Obsolete near-duplicates resemble the query as much as the current record does, so every screen keeps them. Without a validity signal the cascade answers from the obsolete revision as often as full attention (0.93 against 0.93 at 4,096 records). A recent-256 window fails for a different reason: the current record is usually outside it.

The remedy for staleness is the driver–modulator rule of the companion book (Ghosh, 2026b, ch. 18): multiply each observed coefficient by a nonnegative contextual gain and renormalise, with zero gain for records that a later revision supersedes. That needs revision metadata stored with the record, not a better similarity score. The query switch adds a third requirement. If the working memory keeps only the 256 records chosen for the first query, a later question about the withdrawal notice can reach it in 0.15 of cases at 4,096 records, against 1.00 when the full history remains addressable through the shared memory. The causal working memory should therefore hold references into an addressable Vocabucapillary history, not replace it.

# 9 The microcolumn as a local recurrent expander

The brief models a cortical microcolumn as a local recurrent circuit that expands a compact cue into a population response. Local recurrence is well established (Harris & Shepherd, 2015; Cossell et al., 2015), small cues can recall imprinted ensembles (Carrillo-Reid et al., 2016), and feedforward and feedback pathways reach different layers (Markov et al., 2014). Whether the minicolumn is itself a reproducible computational unit remains open (Mountcastle, 1997; Horton & Adams, 2005). The present numerics do not bear on that question. They do sharpen three predictions that the brief's tests can check.

First, a cue that sets only the initial state is forgotten by a stable circuit (Study B01: 3 distinct final segments for 512 seeds), while a cue that keeps driving it is not (506 of 512). In mouse visual cortex, activity decayed with a time constant of about 10 ms when thalamic drive stopped despite strong recurrent excitation (Reinhold et al., 2015). The analogy therefore predicts a sustained afferent drive, not a one-time seed, during readout. Second, a small shared recurrence produces responses from a few common modes, Equation 2, so a microcolumn expander should show low-dimensional, cue-scaled trajectories. A held-out comparison against a feedforward predictor with the same sensory drive, using connectome-paired recordings (MICrONS Consortium, 2025), would test it. Third, if completion depends on local recurrence, narrow vertical groups should predict later activity from early activity better than lateral groups matched for cell count and tuning. Each prediction can fail, and failure would remove the anatomical motivation without changing the engineering conclusions above.

# 10 Revised design

The numerics keep the architecture's shared memory and multistage read and change how the vocabulary is generated.

1. **Size seeds by the rate–distortion curve, not by a fixed count.** For a target relative error ε, use at least the bits of Table 2 for the measured spectrum of the teacher table. Measure the spectrum first; it costs one singular value decomposition.
2. **Replace the recurrent expander by an energy-ordered linear basis, possibly per local dictionary.** A rank-k basis costs 16kd bits once, about 0.5 MiB for k = 64 and d = 4,096, and it is optimal among linear codes. Emitting its coordinates in order of variance preserves the prefix property that motivated the recurrence. Product quantization and learned compositional codes (Shu & Nakayama, 2018) are the natural next baselines, as are factorized and hashed embeddings (Lan et al., 2020; Svenstrup et al., 2017; Hrinchuk et al., 2020).
3. **Keep a dense or cached output path.** The head dominates vocabulary traffic and regenerating it per step costs more than the backbone; shortlisted logits need their own error bound.
4. **Keep one Vocabucapillary memory for every stage.** The reuse is exact and needs no second store.
5. **Use cascades against dilution and validity gains against staleness.** Neither substitutes for the other.
6. **Keep the history addressable.** The causal working memory of a few hundred records should hold references, so that a later query can reach a record that an earlier one excluded.

# 11 Limitations

The teacher tables are synthetic Gaussian tables with controlled spectra. Real embedding tables have heavier tails, norm–frequency structure and clusters, and Proposition 3 is exact only for Gaussian rows. The C# loader in Appendix B runs Study B02 on any exported table, which is the first experiment to run. The recurrent studies use widths of 1,024 (B02, B04) and 128 (B03, B05) rather than 4,096 for computational reasons; the bounds and accounting use 4,096. Study B03 uses a small backbone and a language built from the teacher's geometry, which favours codes that preserve that geometry. Study B05 is a stylised model of one head with a decision rule over a fixed answer pool. The binding and multimodal tests of points 31 to 40 were specified but not run. None of the studies measures latency on hardware.

# 12 Conclusion

A two- to four-number seed with a 96-bit recurrent rule cannot carry a 4,096-coordinate embedding row: the rate–distortion bound leaves most of the row unrecoverable for any decoder, the fitted cell does worse than a rank-2 code, and a backbone learns less from its expanded rows than from the seeds themselves. Compressing vocabularies remains worthwhile, especially for small models with large vocabularies, but the code must be sized by the teacher's spectrum and the expansion should be an energy-ordered linear basis. The Attentionlet half of the proposal stands. One Vocabucapillary memory serves every stage exactly, energy-ordered prefix cascades agree closely with full attention at a fraction of the work, and multistage selection removes the dilution form of context rot. Stale and conflicting records require a validity gain, and later queries require an addressable history. Those two additions are where the proposal's protection against context rot actually comes from.

# Appendix A Proofs

**Proposition 1.** For a fixed architecture and arithmetic, the generated table is a function of the rule bits and the seed bits, so at most $2^{P+Vkb}$ distinct tables can be produced. There are $2^{16Vd}$ tables of V × d 16-bit values, so recovering every one requires $P + Vkb \ge 16Vd$.

**Proposition 2.** Without clipping or rounding, $h_{t+1} = A h_t + u$ with $u = Bz + c$. By induction $h_t = A^t z + \sum_{s<t} A^s u$, which is affine in z, and so is every output $y_t$. The generated table is therefore $G_0 + ZG$ for a fixed offset G₀, the V × k seed matrix Z and a fixed k × d matrix G. After centring, its rank is at most k. By the Eckart–Young theorem, the best rank-k approximation of the centred teacher leaves the sum of its squared singular values beyond the k-th, so no affine decoder does better. For the recurrence, $\Delta h_t = h_{t+1} - h_t$ satisfies $\Delta h_{t+1} = A \Delta h_t$, so $\Delta h_t = A^t \Delta h_0$ and $\Delta_t = e_1^\top A^{t+1} \Delta h_0$. The Cayley–Hamilton theorem gives $A^4 + c_3 A^3 + c_2 A^2 + c_1 A + c_0 I = 0$. Multiplying on the left by $e_1^\top A^{t+1}$ and on the right by $\Delta h_0$ gives Equation 2.

**Proposition 3.** Let $X^V$ be V independent Gaussian rows and $\hat X^V$ any reconstruction computed from a B-bit description. The converse of the rate–distortion theorem gives $V R(\bar D) \le I(X^V; \hat X^V) \le B$, where $\bar D$ is the expected distortion per row and $R(D)$ is the Gaussian rate–distortion function. Because R is decreasing, $\bar D \ge D(B/V)$. Reverse water-filling over the eigenvalues gives Equation 3 (Cover & Thomas, 2006, ch. 10). The argument holds for every block length and every decoder.

**Proposition 4.** A deterministic backbone computes its outputs from its inputs. If two entries produce identical input vectors in identical contexts, every subsequent activation is identical, so no amount of training on those inputs separates them.

**Equation 5.** If $\delta > 0$, the full read is $y = (1 - \delta) y_S + \delta y_O$, where $y_O$ is the normalised read of the omitted positions. Then $y - y_S = \delta (y_O - y_S)$, and both reads have norm at most B, so $\lVert y - y_S \rVert \le 2B\delta$.

**Odds after renormalisation.** Let the evidence and distractor masses be $m_E$ and $m_D$, and let fractions $r_E$ and $r_D$ of them survive. Renormalising divides both surviving masses by the same total, so the odds after are $r_E m_E / (r_D m_D)$, which is $r_E/r_D$ times the odds before.

**Mixture error.** If each active row has error $e_i$ with $\lVert e_i \rVert \le \varepsilon$, the mixture error $\sum_i \alpha_i e_i$ has norm at most $\varepsilon \sum_i |\alpha_i|$ by the triangle inequality. Study B06 found the ratio never above 0.47.

# Appendix B The immutable C# laboratory

The laboratory is a .NET 8 console project with no external packages. Domain state lives in sealed records and read-only lists, and every update is a pure static function that returns a new value: a fitted cell is returned as a new record with its loss history, and generators return their successors. Randomness comes from a SplitMix64 generator implemented as a readonly record struct, each study deriving its own stream from a fixed seed. Parallel evaluation over rows or variants is safe because the functions share no mutable state, and results are identical across runs. A single output boundary writes CSV tables and a JSON file of headline values.

Table: Table 8. Studies of the laboratory.

| Study | Section | Question | Kind of result |
|-----|-------|----------------------------------------------|--------------------|
| B00 | 2, 3, 7 | Where do vocabulary bytes and screening products go? | Accounting |
| B01 | 4, 9 | What can any decoder of a 32-bit seed recover; how do deployed cells behave? | Exact and Monte Carlo |
| B02 | 5 | How well does the 96-bit cell fit a teacher table? | Trained model |
| B03 | 6 | Can the backbone absorb what the seed misses? | Trained model |
| B04 | 7 | What does a prefix screen or cascade keep? | Monte Carlo |
| B05 | 8 | Does multistage selection reduce context rot? | Monte Carlo |
| B06 | 7, A | Are the shared-memory identities exact? | Exact |

Running `dotnet run -c Release` in the project folder executes all studies in about 11 minutes on two cores. Setting the environment variable `LRV_TEACHER` to a binary file (int32 V, int32 d, then V·d float32 values) adds that table to Study B02. A separate Python program ports the generator line for line, regenerates the α = 1 teacher of Study B02 and a deployed 96-bit cell of Study B06, and recomputes the rate–distortion bounds and the accounting. All 19 of 19 cross-checked quantities agreed within tolerance, including the cell's output after 4,096 updates, which matched exactly.

# Appendix C The fifty-point programme

Table: Table 7. The fifty-point programme of the brief and its status.

| Points | Topic | Status after this paper |
|-----------|-----------------------------------------|------------------------------------------------------------|
| 1–10 | Microcolumn as a local recurrent expander | Hypothesis with tests; continuing drive needed to keep seed identity (Study B01) |
| 11–16 | Two clocks, 96-bit budget, seed capacity | Arithmetic confirmed (Study B00) |
| 17–20 | Counting, rank and recurrence limits | Proved and confirmed; extended by a rate–distortion bound (Study B01) |
| 21–24 | Fitting the cell to an existing table | Tested: error above the rank-2 code; new entries fit no better (Study B02) |
| 25–30 | What the backbone can absorb | Tested on a synthetic language; expansion through the cell hurts (Study B03) |
| 31–40 | Local and multimodal vocabularies | Mixture bound confirmed (Study B06); binding tests specified, not run |
| 41–43 | One memory for every stage | Exact (Study B06) |
| 44–46 | Multistage screening and working memory | Tested; energy-ordered emission is required (Studies B04, B05) |
| 47 | Output head | Quantified: the head, not the input row, dominates vocabulary traffic (Study B00) |
| 48–50 | Context rot and query switch | Cascades remove dilution, not staleness; a validity gain is needed (Study B05) |

# References

Carrillo-Reid, L., Yang, W., Bando, Y., Peterka, D. S., & Yuste, R. (2016). Imprinting and recalling cortical ensembles. *Science, 353*(6300), 691–694. https://doi.org/10.1126/science.aaf7560

Cossell, L., Iacaruso, M. F., Muir, D. R., Houlton, R., Sader, E. N., Ko, H., Hofer, S. B., & Mrsic-Flogel, T. D. (2015). Functional organization of excitatory synaptic strength in primary visual cortex. *Nature, 518*(7539), 399–403. https://doi.org/10.1038/nature14182

Cover, T. M., & Thomas, J. A. (2006). *Elements of information theory* (2nd ed.). Wiley.

Devlin, J., Chang, M.-W., Lee, K., & Toutanova, K. (2019). BERT: Pre-training of deep bidirectional transformers for language understanding. *Proceedings of NAACL-HLT 2019*, 4171–4186. https://doi.org/10.18653/v1/N19-1423

Gemma Team. (2024). *Gemma: Open models based on Gemini research and technology* [Technical report]. arXiv:2403.08295.

Ghosh, D., Ghosh, D., & Ghosh, D. P. (2025). *Attentionlet is all you need!* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.35155.90404

Ghosh, D. P. (2026a). *KV coefficient memory for Attentionlet* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.31586.70088

Ghosh, D. P. (2026b). *Vocabucapillary memory for cooperative AI: Local vocabularies, sleep consolidation and prefrontal control in large harnesses* (2nd ed.). Debias Parametric Guru.

Ghosh, D. P. (2026c). *Vocabucapillary for cacheless transformer* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.36209.44648

Ghosh, D. P. (2026d). *Vocabuquantization for memory efficient Vocabucapillary language models* [Preprint]. ResearchGate. https://doi.org/10.13140/RG.2.2.21571.98085

Grattafiori, A., et al. (2024). *The Llama 3 herd of models* [Technical report]. arXiv:2407.21783.

Harris, K. D., & Shepherd, G. M. G. (2015). The neocortical circuit: Themes and variations. *Nature Neuroscience, 18*(2), 170–181. https://doi.org/10.1038/nn.3917

Hong, K., Troynikov, A., & Huber, J. (2025, July 14). *Context rot: How increasing input tokens impacts LLM performance* [Technical report]. Chroma. https://www.trychroma.com/research/context-rot

Horton, J. C., & Adams, D. L. (2005). The cortical column: A structure without a function. *Philosophical Transactions of the Royal Society B, 360*(1456), 837–862. https://doi.org/10.1098/rstb.2005.1623

Hrinchuk, O., Khrulkov, V., Mirvakhabova, L., Orlova, E., & Oseledets, I. (2020). Tensorized embedding layers. *Findings of the Association for Computational Linguistics: EMNLP 2020*, 4847–4860. https://doi.org/10.18653/v1/2020.findings-emnlp.436

Jiang, A. Q., et al. (2023). *Mistral 7B* [Technical report]. arXiv:2310.06825.

Lan, Z., Chen, M., Goodman, S., Gimpel, K., Sharma, P., & Soricut, R. (2020). ALBERT: A lite BERT for self-supervised learning of language representations. *International Conference on Learning Representations*. arXiv:1909.11942.

Liu, N. F., Lin, K., Hewitt, J., Paranjape, A., Bevilacqua, M., Petroni, F., & Liang, P. (2024). Lost in the middle: How language models use long contexts. *Transactions of the Association for Computational Linguistics, 12*, 157–173. https://doi.org/10.1162/tacl_a_00638

Markov, N. T., Vezoli, J., Chameau, P., Falchier, A., Quilodran, R., Huissoud, C., Lamy, C., Misery, P., Giroud, P., Ullman, S., Barone, P., Dehay, C., Knoblauch, K., & Kennedy, H. (2014). Anatomy of hierarchy: Feedforward and feedback pathways in macaque visual cortex. *Journal of Comparative Neurology, 522*(1), 225–259. https://doi.org/10.1002/cne.23458

Meta AI. (2024). *Llama 3.2: Revolutionizing edge AI and vision with open, customizable models* [Release note]. https://ai.meta.com/blog/llama-3-2-connect-2024-vision-edge-mobile-devices/

MICrONS Consortium, et al. (2025). Functional connectomics spanning multiple areas of mouse visual cortex. *Nature, 640*(8058), 435–447. https://doi.org/10.1038/s41586-025-08790-w

Mountcastle, V. B. (1997). The columnar organization of the neocortex. *Brain, 120*(4), 701–722. https://doi.org/10.1093/brain/120.4.701

Radford, A., Wu, J., Child, R., Luan, D., Amodei, D., & Sutskever, I. (2019). *Language models are unsupervised multitask learners* [Technical report]. OpenAI.

Reinhold, K., Lien, A. D., & Scanziani, M. (2015). Distinct recurrent versus afferent dynamics in cortical visual processing. *Nature Neuroscience, 18*(12), 1789–1797. https://doi.org/10.1038/nn.4153

Ribar, L., Chelombiev, I., Hudlass-Galley, L., Blake, C., Luschi, C., & Orr, D. (2024). SparQ attention: Bandwidth-efficient LLM inference. *Proceedings of the 41st International Conference on Machine Learning*. arXiv:2312.04985.

Shu, R., & Nakayama, H. (2018). Compressing word embeddings via deep compositional code learning. *International Conference on Learning Representations*. arXiv:1711.01068.

Singhania, P., Singh, S., He, S., Feizi, S., & Bhatele, A. (2024). Loki: Low-rank keys for efficient sparse attention. *Advances in Neural Information Processing Systems, 37*. arXiv:2406.02542.

Svenstrup, D., Hansen, J. M., & Winther, O. (2017). Hash embeddings for efficient word representations. *Advances in Neural Information Processing Systems, 30*. arXiv:1709.03933.

Tao, C., Liu, Q., Dou, L., Muennighoff, N., Wan, Z., Luo, P., Lin, M., & Wong, N. (2024). Scaling laws with vocabulary: Larger models deserve larger vocabularies. *Advances in Neural Information Processing Systems, 37*. arXiv:2407.13623.

Touvron, H., et al. (2023). *Llama 2: Open foundation and fine-tuned chat models* [Technical report]. arXiv:2307.09288.
