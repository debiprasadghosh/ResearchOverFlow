"""Construction checks and analytic examples, not memory-performance experiments."""
from pathlib import Path
import numpy as np
import json,math,sys
rng=np.random.default_rng(20261018)
report={'status':'construction checks only; no empirical consolidation or neuroscience experiment',
        'seed':20261018,'python':sys.version.split()[0],'numpy':np.__version__}
# Proposition 1: solve a nontrivial quadratic and independently finite-difference its energy.
n=7;d=rng.normal(size=(4,n));h=rng.normal(size=(9,n));y=rng.normal(size=9);q=rng.normal(size=n)
p=np.diag(rng.uniform(.5,2,size=n));w=np.diag(rng.uniform(.5,2,size=4));lam=np.diag(rng.uniform(.5,2,size=9))
a=p+.7*d.T@w@d+1.3*h.T@lam@h
z=np.linalg.solve(a,p@q+1.3*h.T@lam@y)
def energy(x):
 u=x-q;v=d@x;r=h@x-y
 return .5*u@p@u+.35*v@w@v+.65*r@lam@r
fd=np.array([(energy(z+1e-5*np.eye(n)[i])-energy(z-1e-5*np.eye(n)[i]))/2e-5 for i in range(n)])
assert np.max(abs(fd))<1e-8
report['regularised_read_gradient_max']=float(np.max(abs(fd)))
# Theorem 3: an SVD basis independently constructs the projection.
d=rng.normal(size=(6,9));u,s,vt=np.linalg.svd(d,full_matrices=True);basis=vt[6:].T
z=rng.normal(size=9);recon=basis@(basis.T@z)
error=np.linalg.norm(z-recon);bound=np.linalg.norm(d@z)/min(s)
assert np.linalg.norm(d@recon)<1e-12 and error<=bound+1e-12
report['projection']={'coordinates_before':9,'coordinates_after':3,'error':float(error),'bound':float(bound)}
# Proposition 2: recurrence and separated expression are evaluated independently.
T=16;coeff=rng.uniform(0,1,T);reads=rng.normal(size=(T,5));noise=rng.normal(size=(T,5))*.01;initial=rng.normal(size=5)
x=initial.copy()
for t in range(T-1,-1,-1):x=(1-coeff[t])*x+coeff[t]*reads[t]+noise[t]
remain=1.;result=np.zeros(5);weights=[]
for t in range(T):
 weights.append(remain*coeff[t]);result+=remain*(coeff[t]*reads[t]+noise[t]);remain*=1-coeff[t]
result+=remain*initial
assert np.max(abs(x-result))<1e-12 and abs(sum(weights)+remain-1)<1e-12
report['schedule_separation_max_error']=float(np.max(abs(x-result)))
# Section 8: the shared-coordinate read glues but violates a withheld dependency.
d=np.array([[0.,1.,-1.,0.]])
for beta in (0.,.1,1.,100.):
 x=np.linalg.solve(np.eye(4)+beta*d.T@d,np.array([1.,1.,1.,0.]))
 assert np.max(abs(x-[1,1,1,0]))<1e-12
candidate=np.array([1.,1.,0.]);nearest=np.array([.5,1.,.5])
assert candidate[0]!=candidate[2] and nearest[0]==nearest[2]
report['recombination']={'candidate':candidate.tolist(),'hidden_constraint_projection':nearest.tolist(),'shared_coordinates':3,'local_coordinates':4}
# Theorem 4: two fair history bits; a query selects one; only the first is stored.
distortion=0.
for bit0 in (0,1):
 for bit1 in (0,1):
  for query in (0,1):
   true=(bit0,bit1)[query]
   prob=(1. if true==bit0 else 0.) if query==0 else .5
   distortion+=(1/8)*math.log2(1/prob)
assert distortion==.5
report['information_example']={'I_Y_H_given_Q_bits':1.,'stored_bits':1,'optimal_decoder_distortion_bits':distortion,'I_Y_M_given_Q_bits':.5}
# Section 7: evaluate the displayed sample-size requirement without rounding it down.
N=5;eta=.05;tolerance=.01;required=math.ceil(2*math.log(N/eta)/tolerance**2)
assert required==92104
assert math.sqrt(2*math.log(N/eta)/required)<=tolerance
assert math.sqrt(2*math.log(N/eta)/(required-1))>tolerance
report['retention_bound']={'finalists':N,'confidence':1-eta,'tolerance':tolerance,'zero_empirical_change_required_examples':required}
report['all_checks_pass']=True
Path(__file__).with_name('checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
