# ASE for Memory Consolidation

Source for the proposal dated 18 October 2026 by Debi Prasad Ghosh.

The proposal develops an optimisation formulation and a testable cortical interpretation. It contains six formal statements with proofs, five proposed hypotheses, two original figures and a staged implementation plan. It reports no empirical ASE consolidation-performance or neuroscience experiment.

## Contents

- `proposal.md` is the complete editable text, with references.
- `fig/` contains the original figures.
- `build.py`, `reference.docx` and `postprocess.py` rebuild the Word document using pandoc, python-docx, NumPy, Matplotlib and lxml.
- `checks.py` and `checks.json` provide six small construction checks, including the displayed holdout sample-size calculation. These checks are not tests of search superiority or the cortical hypothesis.
- `validation.json` records the final page review and structural Word checks. It does not claim complete independent OOXML schema validation.
- `environment.json` records the environment used to build this version.

Run `python checks.py` and `python build.py` from this directory. The build produces `output/ASE_Memory_Consolidation_Proposal.docx`. Python 3.12.14 and NumPy 2.3.5 were used for the supplied construction checks. Tiny floating-point residuals may vary with library and platform versions. No .NET kernel is introduced or compiled for this proposal.

The definitive page count is the supplied render, not a universal pagination guarantee across Word versions and printer settings. Review the rebuilt document visually before publication.
