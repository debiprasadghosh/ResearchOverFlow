---
title: Autoregressive Sheaf Evolution for Memory Consolidation
subtitle: An optimisation proposal and a testable neocortical interpretation
author:
  - Debi Prasad Ghosh
  - Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India
date: Version 2 · 18 October 2026
---

# Proposal in one sentence

**Use ASE to search for a small, reusable and locally compatible long-term representation that preserves the task-relevant information in recent experience while protecting previously learned knowledge.** In a cortical interpretation, ASE describes a candidate computation performed by interacting cortical representations during replay and learning; slow plasticity stores the accepted result.

The object being optimised is a memory system: its retained exemplars, local latent codes, retrieval rules and, where trainable, a small set of slow parameters. The objective combines predictive fidelity, old-task retention, compatibility, storage and retrieval cost. Local consistency helps construct candidates. Behavioural evaluation decides whether they deserve to become durable memory.

This proposal extends the ASE conversion proposal, Part I and Part II [1, 2, 14]. It preserves their terminology: stalks are data spaces; a token carries a vertical fibre diagram; moving-base comparisons use an inverse image; all relevant squares commute; units precede residuals; and the four bases are kept separate. Its mathematical statements are elementary consequences of linear algebra, information theory and concentration bounds, adapted to the proposed architecture. The biological mechanism and performance advantage remain hypotheses.

## Abstract

Memory consolidation can be posed as a constrained compression and learning problem. Recent experience is rich, redundant and context-bound; durable memory must support future queries with less dependence on the original episode. We propose Autoregressive Sheaf Evolution as an optimiser over candidate memory representations. Horizontal sheaves organise partial descriptions and test their agreement on shared observables. Autoregressive layers progressively construct candidate codes; slow learning then incorporates accepted codes into a persistent memory bank or parameterised decoder. We distinguish an evidence buffer, an evaluated search archive and the persistent memory itself. A regularised harmonic read has a unique solution under an explicit observability condition. When retrieval weights are recomputed from the current code, every relaxed read with step at most two is still a guaranteed-descent step on an explicit soft energy, so the inner consolidation loop has a Lyapunov function. Compatible linear data admit exact coordinate compression, with a spectral reconstruction bound for approximately compatible data. An information bound shows why arbitrary histories cannot be compressed without a task-dependent loss. A held-out admission rule bounds expected old-task degradation for a finite, frozen candidate set; for 0–1 task losses, counting regressions reduces the required holdout from 92,104 to 459 examples at the same confidence. Strongly prioritised replay provably collapses coverage and stops composition. The cortical interpretation separates working-memory state, hippocampal episodic support, recurrent cortical computation and slow synaptic change. The harmonic read is exactly the settled state of a two-population prediction-error circuit, in which retrieval weights act as gains and observation metrics as precisions, and the hippocampus supplies the observation star as an index rather than the content. Recent replay findings motivate coordinated, selective learning, but do not establish a sheaf implementation or identify replay with successful consolidation. Seven preregisterable hypotheses specify what would support or refute the proposal.

## What changed in version 2

- **The inner loop now has a descent guarantee.** Theorem 2 extends the majorise–minimise theorem of Part II to the regularised read with soft, recomputed weights. Version 1 stated that query-dependent weights gave no descent guarantee; that gap is closed.
- **Admission needs far fewer examples.** Proposition 8 replaces the generic Hoeffding sample size by an exact regression-count bound for 0–1 losses, and records the empirical Bernstein alternative for bounded losses.
- **Prioritised replay has a proved failure mode.** Proposition 4 shows that strong prioritisation collapses coverage, so the consolidated code copies one elite record and keeps the prior elsewhere.
- **The neocortical role is made specific.** Proposition 10 shows that the read is the fixed point of a prediction-error circuit with gains and precisions, Proposition 11 predicts settling time from coverage, and Section 9.4 assigns the observation star to hippocampal indexing. Two new hypotheses, H6 and H7, test these predictions.
- **All new statements are checked numerically** (`checks_v2.py`); the version 1 construction checks are unchanged.

# 1 What moves from short term to long term

A useful operational definition of consolidation is **reduced dependence on the original history at a declared task tolerance**. Let $H$ be the recent history, $Q$ a future query, $W$ the pre-existing slow system and $M$ the durable update. Consolidation succeeds for a task distribution when a decoder using $(W,M,Q)$ reproduces the required response without reopening $H$:

$$p(Y\mid H,Q,W)\ \approx\ p(Y\mid M,Q,W). \tag{1}$$

The approximation is measured by an explicit loss, not by visual similarity between embeddings. Examples include correct answers to engineering queries, decisions under changed loads, recognition under a missing modality, or prediction of a later event. The task family determines which information may be discarded.

A memory may become durable in two ways. **External consolidation** writes a persistent exemplar, schema, rule or latent code into an addressable store. **Parametric consolidation** changes the slow decoder or its adapters so that future responses depend less on retrieving that exemplar. An unchanged backbone with a growing database performs the first kind. Claiming the second requires demonstrating useful performance when access to the original buffer, and where appropriate the new exemplar, is withdrawn.

The proposal therefore uses two outcome measures: retained task performance and the amount of historical evidence consulted at inference. Reduced context use alone is insufficient if accuracy falls. Improved accuracy with an ever-growing episode bank is useful, but does not establish compression or parametric consolidation.

## 1.1 Three memory roles and two learning timescales

Working memory is the presently usable task state. An episodic buffer retains recoverable experiences after they leave that state. Long-term memory is the durable system of exemplars, associations and learned parameters. These are functional roles, not a claim that each occupies one anatomical location. Human working-memory experiments can reveal latent information after its actively decoded representation has fallen, so present activity cannot simply be equated with all temporary storage [5].

In the proposed implementation, fast inference updates an active code $z$. Slow consolidation updates $(M,\theta)$ over batches of replay. Use $t$ for ASE computational depth, $k$ for consolidation events and $\ell$ for anatomical lamina. They are different indices. A sixteen-step optimiser is not a claim that cortex has sixteen anatomical layers, and a barcode indexed by $t$ does not describe the lifetime of an engram indexed by $k$.

# 2 The objects ASE must keep separate

The distinction between evidence and proposed solutions is essential. A population optimiser searches an archive of evaluated candidates. A memory learner also consumes experiences. Combining those two kinds of records without a type distinction would allow a proposed memory to become its own evidence.

| Object | Contents | Role and update rule |
|:--|:--|:--|
| Evidence buffer $\mathcal E_k$ | Episodes, partial observations, task labels, provenance and uncertainty | Supplies replay and evaluation targets; synthetic completions retain their synthetic status |
| Search archive $\mathcal A_k$ | Evaluated memory packages, local candidate coordinates, measured losses and costs | Guides ASE proposals; a low loss is an evaluation result, not a new observed episode |
| Persistent memory $M_k$ | Accepted exemplars, shared codes, schemas, indices and metadata | Available after the recent buffer is detached; storage cost includes its supporting maps |
| Slow parameters $\theta_k$ | Decoder and adapter weights; calibrated observation maps when learned | Updated during consolidation; prior behaviour is tested before commitment |
| Active state $z_{k,t}$ | A candidate code or a query-conditioned assignment of local codes | Changes during one search or recall trajectory; it is not itself a permanent write |

The search archive is not an inference-time memory unless it is explicitly included in $M$ and charged to the storage budget. Buffer-removal tests also prohibit undeclared access to that archive.

The long-term state is $S_k=(M_k,\theta_k)$. A proposal may change either component or both. To keep the first implementation tractable, freeze the backbone, feature encoders and restriction maps within each consolidation batch. Search over a low-dimensional adapter, a collection of local codes and explicit exemplar-selection variables. Updating all neural weights with a population method is not the proposed starting point.

![Figure 1. Information and proposals follow different paths. The evidence buffer supplies replay targets. The search archive contains evaluated candidate memories. ASE constructs a candidate, which is trained or compiled and tested before it updates durable memory. The old slow state supplies retention targets and remains available for rollback.](fig/architecture.png){width=100%}

## 2.1 The four bases

**Cover base.** At computational layer $t$, a latent domain $X_t$ has an open cover $\mathcal U_t$. The nerve describes local geometric neighbourhoods. Scale determines a resolution policy; it does not guarantee a good or Leray cover.

**Context base.** A family of observed variable subsets describes which modalities or features co-occur. Its nerve or incidence structure records partial information. It is not automatically the nerve of an open cover of latent space.

**Layer order.** The chain $T\to T-1\to\cdots\to0$ indexes one computation. Specified linear maps and pathwise tangents live here.

**Observation star.** At a query or candidate, the centre receives partial observations from retrieved records. The star determines a harmonic read. It is auxiliary and is not the cover nerve [1, 2].

An implementation records the base for every operator. A comparison between changing bases requires a declared refinement, pullback or correspondence. Rectangular restrictions represent partial observations; they are not invertible coordinate transformations.

# 3 The consolidation optimisation problem

Let $S^-=(M^-,\theta^-)$ be the current slow state. A candidate package $u=(b,M,\Delta\theta)$ specifies a branch or schema $b$, a memory update and a permitted parameter update. Its decoder is $f_u(Q)=f_{\theta^-+\Delta\theta}(Q;M)$. A branch can represent distinct task contexts, source identities or mutually exclusive hypotheses. Branch labels are retained when their distinction matters for future queries. At inference, cues or a trained router must choose a branch; an oracle test label is unavailable.

Use normalised task losses to define

$$\mathcal J_k(u)=D_{\mathrm{recent}}(u)+\alpha D_{\mathrm{old}}(u)+\beta E_{\mathrm{glue}}(u)+\lambda C_{\mathrm{store}}(u)+\mu C_{\mathrm{query}}(u). \tag{2}$$

Here $D_{\mathrm{recent}}$ measures performance on recent evidence or a frozen teacher distribution; $D_{\mathrm{old}}$ measures retention on old training anchors; $E_{\mathrm{glue}}$ penalises disagreements on genuinely shared observables; $C_{\mathrm{store}}$ counts all persisted bytes, including adapters, maps, routing, metadata and retained rollback versions; and $C_{\mathrm{query}}$ measures expected inference cost. The objective coefficients $\alpha,\beta,\lambda,\mu$ are nonnegative and have declared scales. The search is also subject to explicit constraints:

$$C_{\mathrm{store}}(u)\le B,\qquad C_{\mathrm{query}}(u)\le L,\qquad u\in\mathcal F_k. \tag{3}$$

The admissible set $\mathcal F_k$ includes branch semantics, provenance rules and any exact feasibility conditions. Held-out old-task protection is applied separately at final admission. An objective penalty cannot replace a hard requirement merely because its coefficient is large.

For $0\le\rho\le1$, a practical recent-loss term mixes labelled task loss and teacher distillation:

$$\begin{aligned}
D_{\mathrm{recent}}(u)&=(1-\rho)\mathbb E_{(h,q,y)\sim\widehat P_k}\ell(f_u(q),y)\\
&\quad+\rho\,\mathbb E_{(h,q)\sim\widehat P_k}\mathrm{KL}\bigl(p_{\mathrm{teach}}(\cdot\mid h,q)\Vert p_u(\cdot\mid q)\bigr).
\end{aligned} \tag{4}$$

For discrete responses, the candidate distribution must have adequate support for this KL term to be finite. For continuous outputs, use a declared predictive distribution or a suitably scaled regression loss. A teacher can preserve a mistake; measured agreement with it is fidelity to that teacher, not a truth certificate. Labelled tests and independent verification remain distinct.

## 3.1 A durable memory is a family of sections

The target is not one global section that represents every episode simultaneously. That would average incompatible experiences. The target is a query- and branch-conditioned decoder $q\mapsto z(q,b)$ whose local descriptions agree where they refer to the same quantity. Two different people, dates or task rules can require different sections. A global section within one declared context is compatible with multiple contextual memories in the same system.

Restriction maps must not be learned solely by minimising $E_{\mathrm{glue}}$. Setting every map to zero makes all residuals vanish while destroying information. Calibrate maps against observable shared quantities, fix their ranks or impose suitable normalisation, and test them out of sample. When geometry changes, treat it as a model update with its own validation cost.

# 4 A solvable horizontal consolidation step

Work on one fixed, dimensionless context or cover model with cochain space $C^0=\bigoplus_v F(v)$ and coboundary $\delta:C^0\to C^1$ [11]. For an edge $e=(v,w)$, the component of $\delta z$ is $r_{we}z_w-r_{ve}z_v$. Higher-dimensional extensions obey the commuting-diamond identities of Part I. On a graph, there are no triangle identities to assume unless triangles are actually added.

**Units come first.** Divide physical quantities by declared tolerances, or carry the corresponding positive metrics. Let $W\succ0$ measure overlap residuals and $\Lambda_i\succ0$ measure observation residuals. If overlap units change by $A_e$, transform the metric to $A_e^{-\top}W_eA_e^{-1}$. Vertex norms and their metrics must be transformed consistently. A displacement error cannot be added numerically to a stress error without this convention.

For a current code $q$, observations $y_i$ and calibrated linear maps $H_i$, define the frozen-weight energy

$$E_t(z;q)=\tfrac12\|z-q\|_{P_t}^2+\tfrac{\beta_t}{2}\|\delta z\|_W^2+\tfrac{\gamma_t}{2}\sum_i\omega_{it}\|H_i z-y_i\|_{\Lambda_i}^2. \tag{5}$$

Here $P_t\succeq0$, $\beta_t,\gamma_t\ge0$ and $\omega_{it}\ge0$. Retrieval weights, maps and metrics are frozen during this solve. In an evidence read, $y_i$ comes from $\mathcal E_k$. In a search read, it is a partial code from an evaluated candidate in $\mathcal A_k$. These two uses share algebra but keep different types and provenance.

**Proposition 1 — Unique regularised harmonic read.** Put

$$A_t=P_t+\beta_t\delta^\top W\delta+\gamma_t\sum_i\omega_{it}H_i^\top\Lambda_iH_i. \tag{6}$$

If $A_t\succ0$, energy (5) has exactly one minimiser,

$$R_t(q)=A_t^{-1}\left(P_tq+\gamma_t\sum_i\omega_{it}H_i^\top\Lambda_i y_i\right). \tag{7}$$

*Proof.* Expanding the quadratic gives Hessian $A_t$. Positive definiteness makes the energy strictly convex and coercive. Its gradient vanishes exactly at (7). In implementation, solve the linear system rather than explicitly forming an inverse. $\square$

A positive definite $P_t$ suffices. Without it, the observations and compatibility terms must jointly observe every direction: their weighted nullspaces have trivial intersection. Otherwise report the nullspace and choose an explicit prior or pseudoinverse convention. Unobserved directions are uncertainty, not recalled facts. With $P_t=0$, $\beta_t=0$, $H_i=I$, $\Lambda_i=I$ and $\sum_i\omega_{it}=1$, (7) reduces to the ADE weighted mean [1]. General rectangular observations permit coordinate recombination.

For fixed weights, gradient descent on (5) decreases that energy when its step size lies in $(0,2/\lambda_{\max}(A_t))$. In ASE the retrieval weights are recomputed from the current code, $\omega_{it}\propto\pi_i\exp(-e_i(z)/s_t^2)$ with $e_i(z)=\tfrac12\|H_iz-y_i\|_{\Lambda_i}^2$ and prior weights $\pi_i>0$. The energy then changes between steps, but a single function still decreases.

**Theorem 2 — The soft consolidation read is a majorise–minimise step.** Define the soft energy

$$\mathcal E_t(z)=\tfrac12\|z-q\|_{P_t}^2+\tfrac{\beta_t}{2}\|\delta z\|_W^2-\gamma_ts_t^2\log\sum_i\pi_i\exp\bigl(-e_i(z)/s_t^2\bigr). \tag{8}$$

Compute the weights, $A_t$ and the read $R_t$ at $z$, and suppose $A_t\succ0$. Then for every $0\le\lambda\le2$,

$$\mathcal E_t\bigl(z+\lambda(R_t-z)\bigr)\le\mathcal E_t(z)-\tfrac12\lambda(2-\lambda)\|z-R_t\|_{A_t}^2, \tag{9}$$

and $\nabla\mathcal E_t(z)=A_t(z-R_t)$, so the read leaves $z$ fixed exactly at stationary points of $\mathcal E_t$.

*Proof.* The map $e\mapsto-s^2\log\sum_i\pi_ie^{-e_i/s^2}$ is concave with partial derivatives $\omega_i$. Its tangent inequality bounds $\mathcal E_t$ above by the frozen-weight energy (5) plus a constant, with equality at $z$. That quadratic has Hessian $A_t$ and minimiser $R_t$, so its value at $z+\lambda(R_t-z)$ is lower than at $z$ by $\tfrac12\lambda(2-\lambda)\|z-R_t\|_{A_t}^2$. The gradient identity follows by differentiating (8). $\square$

This is Part II's Theorem 3.10 with the prior and compatibility terms added [14]; for identity maps it is the bound-optimisation view of Gaussian mean shift. The interval $[0,2]$ is sharp: with one record (9) is an equality. In 2,000 random consolidation problems with general maps, soft weights, priors and coboundaries, (9) was never violated, and the smallest ratio of actual to guaranteed decrease was 1.000000000000. Steps with $\lambda$ between 2.05 and 3 raised the energy in 1,787 of 1,978 trials. Iterating the read to a fixed point left a gradient of at most 3.6 × 10⁻⁹. The theorem concerns one inner solve with fixed records, maps and priors; it gives no guarantee across the outer ASE search or across consolidation batches.

# 5 What ASE adds to the optimiser

Equation (7) is a local solver. ASE supplies an archive-based proposal process around it. For each branch, encode candidate packages in a fixed search space, or use explicitly compared charts. Initialise tokens from current memory, selected evaluated candidates and prescribed exploratory seeds. Retrieve nearby, branch-compatible candidates from $\mathcal A_k$. Fitness and distance determine the read weights. Then apply

$$z_{t-1}=(1-\lambda_t)z_t+\lambda_tR_t(z_t)+\nu_t,\qquad 0\le\lambda_t\le1. \tag{10}$$

The schedule is prescribed within a run. Its scale controls locality and exploration. The archive stores actual evaluations of decoded memory packages. A proposed latent code receives no fitness credit until its decoder, training procedure and task tests have run. An ASE trajectory is not asserted to be an exact posterior sample.

A first implementation uses a small population to search low-dimensional codes, exemplar subsets, replay allocation and adapter hyperparameters. Gradient methods train adapters inside each candidate evaluation. The fixed quadratic block should be solved directly; ASE is justified only if the remaining nonconvex, discrete or branch-structured problem benefits from its proposal mechanism. A direct quadratic solver is therefore a required control, not an adversary to be hidden.

**Proposition 3 — Schedule separation remains pathwise.** Write $a_t=1-\lambda_t$. For every realised sequence of reads and noise increments,

$$\begin{aligned}
z_0&=\left(\prod_{t=1}^T a_t\right)z_T+\sum_{j=1}^T\lambda_j\left(\prod_{i=1}^{j-1}a_i\right)R_j\\
&\quad+\sum_{j=1}^T\left(\prod_{i=1}^{j-1}a_i\right)\nu_j.
\end{aligned} \tag{11}$$

The coefficients of the initial state and all reads are nonnegative and sum to one.

*Proof.* Substitute (10) recursively from $t=1$ back to $T$. The coefficient sum telescopes because $\lambda_j=1-a_j$. No independence assumption is needed. $\square$

Thus the schedule controls how much each read can influence the final proposed code. The identity does not determine what the read means, prove preservation of an episode, or guarantee a successful parameter update. A convex combination of inaccurate reads can remain inaccurate, and local recombination can leave the convex hull of complete archived packages.

## 5.1 One consolidation cycle

1. Freeze encoders, maps, the current slow model, task losses and the training portion of the replay buffer.
2. Form branch-specific candidate encodings; include the unchanged slow state as a feasible fallback.
3. Use ASE to propose packages. Evaluate each using the same permitted replay and inner training budget; append its measured outcome to $\mathcal A_k$.
4. Retain a Pareto set for fidelity, old-task retention, persisted bytes and inference cost. Select candidates on development data.
5. Freeze the finalists before exposing the final retention holdout. Apply the admission rule of Section 7 and the exact feasibility checks.
6. Commit one accepted package atomically with its maps and provenance; retain a rollback version. Remove source-buffer access only according to the tested consolidation claim.

Replays prioritised by uncertainty or expected gain are a policy to compare against uniform replay. Prioritisation is not automatically unbiased: use importance corrections when an unbiased task-risk estimate is required, and evaluate on the declared task distribution.

Prioritisation also has a structural cost. Suppose the prior read weights carry a priority factor, $\pi_i=\pi_i^0e^{-\beta J_i}$, where $J_i$ is a priority score such as loss or surprise, and the records observe coordinate subsets $S_i$.

**Proposition 4 — Prioritised replay collapses coverage.** Let $J$ have a unique minimiser $\iota$ and gap $\Delta=\min_{i\ne\iota}(J_i-J_\iota)>0$. For every coordinate $j$ outside $S_\iota$, its evidence coverage $\kappa_j=\sum_{i:\,j\in S_i}\omega_i$ satisfies

$$\kappa_j\le e^{-\beta\Delta}\sum_{i\ne\iota}\frac{\pi_i^0}{\pi_\iota^0}\exp\left(\frac{e_\iota(z)-e_i(z)}{s_t^2}\right). \tag{12}$$

As $\beta$ grows, the evidence term of $A_t$ vanishes on those coordinates, and the read there is set by the prior and compatibility terms alone. The consolidated code copies the top-priority record where it observed and keeps the prior elsewhere.

*Proof.* $\kappa_j\le\sum_{i\ne\iota}\omega_i\le\sum_{i\ne\iota}\omega_i/\omega_\iota$, and each ratio equals $(\pi_i^0/\pi_\iota^0)e^{-\beta(J_i-J_\iota)}e^{(e_\iota-e_i)/s_t^2}$ [14, Proposition 4.6]. $\square$

In a simulation with twelve masked records of a four-coordinate target, the top-priority record observing two coordinates, the smallest coverage at $\beta=0,1,3,10$ and $30$ was 0.288, 0.323, 0.070, 3.7 × 10⁻⁵ and 2.9 × 10⁻¹⁴. The read error on the two coordinates the elite did not observe rose from 0.020 to 0.854, because the prior took over there, and the error on the observed coordinates rose from 0.041 to 0.141, because one noisy record replaced an average. Strong prioritisation therefore stops recombination. Anneal $\beta$, or keep a coverage floor that reserves a minimum weight for records observing each coordinate.

# 6 What can be proved about compression

Let $n=\dim C^0$, $d=\dim\ker\delta$, and use the normalised Euclidean vertex norm. Let $U$ have orthonormal columns spanning $\ker\delta$. These results concern a fixed linear model; a learner must still establish that this is the right model for the task.

**Theorem 5 — Compatible coordinate compression.** Every compatible assignment $z\in\ker\delta$ has a unique representation $z=Ua$ with $a\in\mathbb R^d$. If $\delta\ne0$ and $\sigma_r$ is its smallest positive singular value, then for arbitrary $z$,

$$a=U^\top z,\qquad \|z-Ua\|\le\frac{\|\delta z\|}{\sigma_r}. \tag{13}$$

For an $L_f$-Lipschitz task decoder, the decoded change is at most $L_f\|\delta z\|/\sigma_r$.

*Proof.* Orthogonal decomposition gives $z=UU^\top z+z_\perp$. The first term lies in the kernel. On its orthogonal complement, the singular-value bound gives $\|\delta z_\perp\|\ge\sigma_r\|z_\perp\|$, proving (13). The decoder bound follows from its Lipschitz property. If $\delta=0$, retain all coordinates and the projection error is zero. $\square$

The number of removable real coordinates is $\operatorname{rank}\delta$. This is a dimension statement, not a universal bit-compression ratio. Quantisation, the basis $U$, maps, indices and exceptions all have storage costs. A small $\sigma_r$ makes residual-based compression fragile. A large residual may reflect distinct contexts that should be separated rather than averaged.

In the simple contexts $\{a,b\}$ and $\{b,c\}$, the local assignment has four coordinates $(a,b_A,b_B,c)$ and one constraint $b_A=b_B$. A compatible memory needs three shared coordinates. With an exact common quantisation grid, storing the duplicated $b$ once saves one scalar payload, before accounting for the shared schema. Repeated episodes can amortise that schema cost. The result does not say that every episode can be discarded.

**Theorem 6 — A task-dependent information floor.** Let $H,Q,Y,W$ be discrete random variables with the relevant entropies finite. Suppose $M=f(H,W)$ has at most $2^B$ possible values for every $W$. For any decoder distribution $q$, the expected log-loss distortion satisfies

$$\begin{aligned}
D&=\mathbb E\,\mathrm{KL}\bigl(p(Y\mid H,Q,W)\Vert q(Y\mid M,Q,W)\bigr)\\
D&=I(Y;H\mid M,Q,W)+\mathbb E\,\mathrm{KL}\bigl(p(Y\mid M,Q,W)\Vert q(Y\mid M,Q,W)\bigr).\end{aligned} \tag{14}$$

Consequently, $D\le\varepsilon$ implies

$$B\ge I(Y;H\mid Q,W)-\varepsilon, \tag{15}$$

when logarithms and the KL divergence use base two.

*Proof.* Add and subtract $\log p(Y\mid M,Q,W)$ inside the expected log ratio. The first term is the conditional mutual information because $M$ is determined by $(H,W)$. Also $I(Y;H\mid Q,W)=I(Y;M\mid Q,W)+I(Y;H\mid M,Q,W)$, and $I(Y;M\mid Q,W)\le H(M\mid Q,W)\le B$. Combining these facts gives (15). $\square$

This bounds the total durable update, including an external bank or parameter delta. Keeping the full original history available under a different name does not evade the bound. Existing knowledge $W$ can make a new episode highly compressible; a query family that asks for every arbitrary detail can make it incompressible. Recombination can construct useful hypotheses, but cannot manufacture information about an unobserved fact.

# 7 An admission rule for durable writes

Retention training and retention certification use separate examples. Training anchors can influence the search. A final holdout cannot repeatedly guide adaptive candidate construction while retaining the elementary guarantee below. Losses for this admission test are bounded in $[0,1]$; an unbounded KL training loss must not be inserted into this bound without another assumption.

**Theorem 7 — Finite-candidate retention certificate.** Let $u_1,\ldots,u_N$ be frozen before an independent, identically distributed old-task holdout of size $m$ is sampled or revealed. Let $g_j(x)=\ell(u_j;x)-\ell(u^-;x)\in[-1,1]$, and let $\widehat\Delta_j$ be its sample mean. 

Fix $0<\eta<1$. With probability at least $1-\eta$, every candidate satisfies

$$\Delta_j\le\widehat\Delta_j+\sqrt{\frac{2\log(N/\eta)}{m}},\qquad\Delta_j=\mathbb E g_j(X). \tag{16}$$

The logarithm in (16) is natural.

*Proof.* Hoeffding's inequality [13] for variables of range two gives $\Pr(\Delta_j-\widehat\Delta_j>r)\le\exp(-mr^2/2)$. Apply a union bound to the $N$ candidates and solve for $r$. $\square$

Accept a candidate only when its upper bound is no larger than a declared old-task degradation tolerance $\epsilon_{\mathrm{old}}$, recent-task criteria are met, and constraints (3) hold. This is a distribution-specific, probabilistic mean-risk statement. It does not certify every future query, a shifted distribution or a rare unrepresented failure. Branch-level tests are needed when their individual protection matters; adjust the confidence allocation for multiple tests.

The bound can be conservative. For five finalists, 95% confidence and zero measured old-task change, certifying a one-percentage-point degradation tolerance requires at least 92,104 independent holdout examples under (16). This is the ceiling of $2\log(5/0.05)/0.01^2$. With a small sample, the generic certificate may fail even for a useful update. The appropriate response is a larger independent test, a sharper justified bound, a smaller claim or no write. Reusing the same failed holdout to tune the next candidate invalidates the stated finite-candidate protocol.

Most of that cost comes from the generic range of $g_j$. When the task loss is a 0–1 error, a sharper certificate counts regressions directly.

**Proposition 8 — Regression-count certificate.** Let losses take values in $\{0,1\}$. Then $g_j\in\{-1,0,1\}$ and $\Delta_j\le\rho_j=\Pr(g_j=1)$, the regression rate. Let $k_j$ be the number of holdout examples on which candidate $j$ errs and the current state does not, and let $U(k,m,\alpha)$ be the one-sided Clopper–Pearson upper limit at level $\alpha$ [20]. With probability at least $1-\eta$, every candidate satisfies $\Delta_j\le U(k_j,m,\eta/N)$. For $k_j=0$,

$$U(0,m,\eta/N)=1-(\eta/N)^{1/m}. \tag{17}$$

*Proof.* The Clopper–Pearson limit is an exact one-sided confidence bound for a binomial rate [20]. A union bound over the $N$ frozen candidates gives simultaneous coverage, and $\Delta_j=\rho_j-\Pr(g_j=-1)\le\rho_j$. $\square$

For five finalists, 95% confidence, a one-percentage-point tolerance and no observed regression, (17) needs 459 independent holdout examples instead of 92,104. For bounded but not binary losses, the empirical Bernstein bound of Maurer and Pontil applied to $\max(g_j,0)$ is the natural replacement; with zero sample variance it needs 2,474 examples [19]. In 200,000 simulated admissions with five candidates whose true regression rate was 1.01%, just above the tolerance, at least one was wrongly accepted with frequency 0.0463, below the nominal 0.05. The certificate ignores improvements, so it is conservative when a candidate also fixes old errors. It still assumes an independent holdout drawn from the declared old-task distribution.

![Figure 3. Two results added in version 2. (a, b) Prioritised replay in the twelve-record simulation of Proposition 4: as the priority gain grows, the smallest coverage collapses, the read on features outside the top-priority record falls back to the prior, and the read on its own features copies one noisy record. (c) Holdout examples needed to certify a one-percentage-point retention tolerance for five finalists at 95% confidence with no observed degradation, under the Hoeffding bound of Theorem 7, the empirical Bernstein bound and the regression-count bound of Proposition 8. Simulations and analytic sample sizes, not experimental results.](fig/prioritisation_admission.png){width=100%}

**Proposition 9 — Monotonic accepted objective values.** Within one batch, suppose $\mathcal J_k$ and its evaluation data are fixed, $\mathcal J_k\ge0$, and each accepted transition satisfies $\mathcal J_k(u^{r+1})\le\mathcal J_k(u^r)$. Then accepted objective values converge.

*Proof.* They form a nonincreasing sequence bounded below. $\square$

This elementary result supplies a practical acceptance contract, not convergence of parameters or a global optimum. A new consolidation batch changes the evidence and possibly the objective. No across-batch convergence follows. In biology, an engineered certificate is a functional design analogue; no cited study shows neurons calculating (16).

# 8 A worked example and its counterexample

Consider two three-coordinate archived prototypes,

$$y^{(1)}=(1,1,1),\qquad y^{(2)}=(0,1,0).$$

One retrieved context supplies $(a,b)=(1,1)$ from the first prototype. Another supplies $(b,c)=(1,0)$ from the second. The shared observable agrees: both report $b=1$. The identity restrictions on $b$ define $\delta(a,b_A,b_B,c)=b_A-b_B$.

The read minimising

$$\tfrac12[(a-1)^2+(b_A-1)^2+(b_B-1)^2+c^2]+\tfrac{\beta}{2}(b_A-b_B)^2$$

is $(1,1,1,0)$ for every $\beta\ge0$. Its decoded shared-coordinate representation is $(a,b,c)=(1,1,0)$. All convex combinations of the two complete prototypes have $a=c$, so this read lies outside their convex hull. This is the opportunity for compositional memory: compatible parts can form a new answer without retrieving a complete earlier answer.

Now add a true but previously omitted dependency $a=c$. The new answer violates it. Adding that constraint to the same least-squares problem yields $(a,b,c)=(1/2,1,1/2)$. If $a$ and $c$ are binary, this continuous relaxation must instead be decoded to an admissible discrete state and re-evaluated. Compatibility on $b$ alone never established the validity of the new episode.

![Figure 2. Gluing is not a factual validity test. In the slice b equals one, the complete archive occupies the diagonal a equals c. Local recombination produces the orange point outside that hull. Enforcing the omitted equality returns the continuous least-squares projection to the diagonal. All coordinates and points are analytic examples, not experimental performance results.](fig/recombination.png){width=78%}

The first experiment should therefore use known chain-structured tasks where the contexts contain the generating dependencies, followed by controlled omitted-factor tests. It should measure both useful new compositions and false combinations. For autobiographical recall, a synthetic combination is labelled an inference; it must not be presented as an observed episode merely because it glues.

# 9 A role for ASE in the neocortex

The biological proposal is that **recurrent cortical activity constructs locally compatible, task-conditioned representations, while replay and slow plasticity select which constructions become easier to produce later**. ASE is a candidate algorithmic description of this process. It adds a proposal-and-evaluation mechanism to a complementary-learning-systems account [3]. It is not an established anatomical algorithm.

## 9.1 What the evidence supports

In mice, Kitamura and colleagues found that prefrontal engram cells involved in remote contextual fear memory were generated during initial learning and subsequently matured with hippocampal support [4]. Cortical learning need not begin only after an episode has been copied out of the hippocampus. The proposed optimiser should therefore allow early cortical representations followed by later reorganisation.

Schreiner and colleagues related spindle-locked medial-temporal ripples to decoded reactivation during human NREM sleep [7]. Their study included scalp EEG in healthy participants and intracranial recordings in epilepsy patients. Importantly, cueing in that experiment worsened associative retention relative to uncued material. Reactivation and a beneficial learning outcome must therefore be measured separately; more reactivation is not itself the proposed optimisation objective.

The published 2026 study by Wodeyar and colleagues used simultaneous orbitofrontal, thalamic and hippocampal recordings in 19 patients with epilepsy [8]. Coupled rhythms predicted overnight motor performance changes, whereas rhythms coupled to epileptic spikes predicted worse changes. It supports a role for coordinated timing, but does not identify a specific update rule or establish a general causal sheaf mechanism.

Widloski and Foster reported replay without detected sharp-wave ripples in male rats performing a spatial memory task [9]. The paper, with a subsequent author correction, distinguishes replay content from ripple-associated broadcasting. An ASE interpretation should likewise distinguish candidate generation, communication and durable update, rather than treating a detected ripple as proof that a memory was written.

At the synaptic scale, Benna and Fusi modelled memory retention using interacting variables with multiple timescales [6]. This motivates separating fast states from slow retention variables. It does not make the ASE layer order a measured sequence of synaptic compartments. Parameter protection also has established machine-learning precedents, including elastic weight consolidation [10]; neither replay nor protection of old parameters is new by itself.

## 9.2 The proposed functional mapping

| ASE object | Candidate cortical interpretation | Claim status |
|:--|:--|:--|
| Local stalk $F(v)$ | A calibrated space of features represented by an ensemble | Model choice; an ensemble is not literally a vector space |
| Restriction $r_{ve}$ | A readout of an observable shared by two representations | Requires independent calibration and held-out testing |
| Horizontal residual $\delta z$ | Disagreement between those shared readouts | An operational measurement after units and bases are fixed |
| Observation star | Selected replay or sensory evidence available to the current representation | Computational analogy, not an anatomical star graph |
| ASE trajectory $z_T\to\cdots\to z_0$ | Successive recurrent transformations during one construction | Computational depth; not a fixed assignment to laminae |
| Replay selection and schedule | Which experiences are communicated, when, and at what strength | A functional hypothesis motivated by replay studies |
| Update of $(M,\theta)$ | Durable change in recall or prediction after consolidation | Must be demonstrated behaviourally and by appropriate neural measures |
| Residual $\Lambda_i(y_i-H_iz)$ | Activity of prediction-error units for one input stream | Proposition 10; a model of predictive coding, not a measured cell class |
| Read weight $\omega_i$ | Gain on that stream, set by attention, neuromodulation or replay strength | Hypothesis; gains are measurable, their equality to $\omega_i$ is not given |
| Metric $\Lambda_i$ | Precision of the stream, the inverse of its expected noise | Standard in predictive-coding models; must be estimated |
| Observation star | Hippocampal index naming which cortical records are reinstated, and with what weight | Section 9.4; an index, not the stored content |

For a literal cortical-sheet model, cover the sheet by overlapping physical patches and calibrate shared local observables. For a multimodal memory model, a functional context space may be the more useful base. Long-range association edges are not automatically intersections of physical patches. These are alternative base constructions and must not silently replace one another.

A laminar hypothesis can place incoming evidence, recurrent integration and output-dependent feedback in different measured circuits. It must account for area-specific circuitry, reciprocal connections and state dependence. The proposal does not assume that every area implements a uniform L4-to-L2/3-to-L5-to-L6 chain. A first neural test should target one task and one recorded circuit, rather than infer a universal cortical architecture from the notation.

## 9.3 The read is a settled prediction-error circuit

Predictive-coding models of cortex pair units that represent a hypothesis with units that represent the error of its predictions, and let the hypothesis settle until precision-weighted errors balance [15, 16]. The consolidation read has exactly this form.

**Proposition 10 — A circuit that computes the read.** Let representation units hold $x$, and let error units for record $i$ hold $\varepsilon_i=\Lambda_i(y_i-H_ix)$, with frozen gains $\omega_i$. Consider

$$x\leftarrow x+\eta\left(\gamma_t\sum_i\omega_iH_i^\top\varepsilon_i-P_t(x-q)-\beta_t\delta^\top W\delta x\right). \tag{18}$$

Its fixed points are exactly the solutions of $A_tx=P_tq+\gamma_t\sum_i\omega_iH_i^\top\Lambda_iy_i$, so the unique fixed point is the read $R_t$ of Proposition 1. For $0<\eta<2/\lambda_{\max}(A_t)$, the circuit converges to it linearly, and (18) is gradient descent on the frozen energy (5).

*Proof.* Substituting $\varepsilon_i$, the bracket equals $-(A_tx-P_tq-\gamma_t\sum_i\omega_iH_i^\top\Lambda_iy_i)=-\nabla_xE_t$. The iteration matrix $I-\eta A_t$ has spectral radius below one in the stated range. $\square$

In 100 random problems, the circuit settled to the read to a relative 3.0 × 10⁻¹³. Theorem 2 adds that recomputing the gains from the settled errors, as attention or replay might, still lowers a single soft energy whenever each update moves at most twice the distance to the settled state. The roles separate cleanly. Gains choose which inputs count. Precisions say how much each counts per unit error. Restriction maps say what each input predicts. The compatibility term enforces agreement between areas on shared observables. Canonical-microcircuit models place prediction errors mainly in superficial layers and predictions in deep layers [17]; under Proposition 10 that is the laminar form of the hypothesis, to be tested in one recorded circuit rather than assumed.

**Proposition 11 — Settling time is set by the least-covered feature.** With coordinate masks, $P_t=0$, $\beta_t=0$ and $\Lambda_i=I$, let each record overwrite the coordinates it observes and keep the rest, with frozen gains: $x\leftarrow\sum_i\omega_i\bigl[S_iy_i+(I-S_i)x\bigr]$. Coordinate $j$ then converges as $(1-\kappa_j)^k$, so reducing the error by a factor $\epsilon$ takes about $\log\epsilon/\log(1-\kappa_{\min})$ sweeps.

*Proof.* Coordinate $j$ evolves as $x_j\leftarrow\kappa_j m_j+(1-\kappa_j)x_j$, where $m_j$ is its coverage-weighted mean. This is Cimmino's method of averaged projections in coordinates [14, Proposition 4.4]. $\square$

In 277 random masked problems, the measured number of sweeps to reduce the error by $10^{-6}$ was between 0.68 and 1.12 times this prediction, and within one sweep of its rounded value in all 277 cases. The prediction is about relative timing: features supported by few converging inputs settle last and stay closest to the prior longest.

## 9.4 The hippocampus supplies the star, the cortex holds the stalks

Hippocampal indexing theory proposes that the hippocampus stores an index to neocortical activity patterns rather than the patterns themselves, and that reactivating the index reinstates them [18]. The ASE typing says the same thing in other words. The observation star is auxiliary: it names which records are read and with what weight, while the content lives in cortical stalks and restriction maps [2]. Consolidation in this reading has two parts that can fail separately. The index can be replayed without the cortical read improving, as in the cueing result of Schreiner and colleagues [7]. The cortical read can also become self-sufficient, so that a cue reaches the stored code without the index, as the systems-consolidation results suggest for remote memories [4]. Proposition 10 places the read in recurrent cortex; nothing in it requires the hippocampus once the gains and records can be reached directly.

## 9.5 What this neocortical role predicts

- **Coverage-dependent settling.** Under partial cues, features represented by fewer converging streams should be decoded later and should carry more prior bias (Proposition 11). This is H6.
- **A prioritisation–composition trade-off.** Strongly prioritised replay should improve the prioritised episodes but impair new combinations that need features outside them (Proposition 4). This is H7.
- **No invented values.** When no replayed record observes a feature, the consolidated code should keep the prior for it rather than import a value from an unrelated episode (Proposition 1 with retention). Confabulations that import such values would count against the model.
- **Noise limits useful priority.** If the priority signal has error at most $\varepsilon$, raising its gain $\beta$ beyond about $2\tanh^{-1}(\nu)/\varepsilon$ can move the read by more than a fraction $\nu$ of the record spread [14, Theorem 4.8].

# 10 What vertical algebra can and cannot establish

During one realised computation, a specified transport diagram or the Jacobians of differentiable updates gives a linear representation of the layer order. Along a moving token path, a tower is typed as

$$\varphi_t:F_t\longrightarrow\Phi_t^{-1}F_{t-1},\qquad (\Phi_t^{-1}F_{t-1})_x=(F_{t-1})_{\Phi_t(x)}. \tag{19}$$

The stalk spaces and these maps form the token's vertical fibre diagram. On a common fixed base, horizontal restrictions and vertical maps must commute on every relevant square [2]. An arbitrary collection of fitted layer maps is not automatically a sheaf on the product. Discrete branch switches and exemplar insertion require an additional comparison construction before they can be assigned a barcode.

Part I's vertical acyclicity theorem says that ordinary cohomology of a fixed-base product with a least layer is determined by the bottom layer alone [2]. Therefore unchanged product cohomology cannot establish that consolidation has preserved a task, improved abstraction or successfully written upper-layer information. Barcodes of specified layerwise diagrams can distinguish some changes that this cohomology discards; they are not complete invariants of the entire learning system.

Exact rank is especially weak as a forgetting measure. Smooth, full-rank transformations can make task-relevant sensitivity extremely small while every exact bar survives. Report singular values, numerical cutoffs and task-conditioned reconstruction alongside barcodes. A rank-deficient readout can also discard irrelevant nuisance directions without harming the task. Neither long bars nor short bars determine what should be retained.

When learned covers require zigzag comparisons, the linear-order acyclicity theorem need not apply. Use explicit comparison maps and the appropriate algebra [12]. A birth in a cover-based cohomology barcode can be caused by a changed region, coefficients, comparison construction, failed Leray conditions or numerical error; it is not automatically the birth of a semantic concept. Across consolidation events $k$, both the coefficients and the bottom representation may themselves change.

# 11 Seven hypotheses with refutation criteria

These are proposed tests, not reported outcomes. Freeze tasks, splits, budgets, encodings, stopping rules and primary metrics before the confirmatory runs. Use independent streams as experimental units; report paired effects and confidence intervals. Tune all competing methods on the same development budget.

**H1 — Compositional consolidation.** On a generated chain-factor task with partial observations and correctly specified contexts, ASE achieves lower post-buffer task loss than identity-map ADE at the same total persisted bytes and total consolidation compute. The primary endpoint is loss on held-out combinations, with old-task degradation constrained to at most one percentage point of bounded task error. Refute the predicted advantage if the paired 95% confidence interval for ADE loss minus ASE loss does not lie above zero. A null interval is a failed confirmatory prediction, not proof that every possible ASE variant fails.

**H2 — Robustness requires the right dependencies.** Introducing a known omitted cross-context factor increases false recombinations in the version that uses overlap compatibility alone. Adding the correct factor reduces that error under the same budget. Refute this mechanism prediction if the preregistered interaction is absent. Compare to a matched generic graph regulariser and a factor-graph solver: a benefit explained completely by correct factor specification is not evidence for a special ASE search advantage.

**H3 — Parametric transfer outlives source access.** After accepted consolidation, a trained adapter preserves new-task performance within one percentage point of its buffer-assisted teacher when the original recent buffer is removed, while meeting the old-task tolerance. Test external-code retrieval and adapter-only operation separately. Refute the stronger parametric claim if it holds only while the new episodic records remain accessible. A smaller persistent bank may still satisfy the external-consolidation claim.

**H4 — Reweighting and geometry dissociate.** In a task where reward priorities change while shared feature relations are fixed, changing replay allocation and read priors should adapt behaviour while calibrated restriction maps remain transferable. Against a matched control, quantify loss recovered with maps frozen and out-of-sample shared-feature prediction. Refute the model prediction if successful adaptation requires equally large relearning of the shared maps, or if frozen-map performance is no better than independently shuffled-map controls. Shuffles must break cross-context alignment, not merely perform a gauge-equivalent change of coordinates.

**H5 — Independently calibrated compatibility predicts cortical transfer.** Calibrate neural feature readouts on one data split, then predict recall and cross-context generalisation after learning from their overlap residuals and, where observable, independent multi-route comparison defects. Require incremental predictive value beyond firing-rate changes, pairwise connectivity, replay amount and model complexity in held-out subjects or sessions. Refute this neural instantiation if the added predictive value is absent in the powered preregistered test. Maps fitted jointly to commute by construction cannot supply this test; they would make the proposed signature unfalsifiable.

**H6 — Coverage predicts settling.** In a recorded cortical area during cued recall, estimate for each decodable feature the number of independently calibrated input streams that carry it. Features with lower estimated coverage are decoded later after the cue, and their decoded values lie closer to a separately estimated prior. Refute the prediction if, in held-out sessions, decoding latency and prior bias show no preregistered monotone relation to coverage after controlling for overall decodability and firing-rate signal-to-noise.

**H7 — Prioritisation trades against composition.** In the H1 task, and in a matched behavioural task with sleep or rest replay, increase prioritisation strength while holding total replay fixed. Performance on prioritised items rises or holds, while performance on held-out compositions that require features outside the prioritised records falls at high prioritisation. Refute the computational prediction if composition error does not rise above its uniform-replay value at the highest preregistered strength, and refute the behavioural analogue if the interaction between prioritisation and item type is absent.

H4 is the principal dissociation claim. H5 asks whether the sheaf structure earns its place beyond a general account of coordinated replay. H6 and H7 test predictions specific to the neocortical role of Section 9.3. All of them require reliable estimators and prospective power analysis. Results in a synthetic task cannot establish the cortical hypothesis, and a neural correlation cannot establish the optimiser's computational advantage.

# 12 A staged implementation and decision rule

| Stage | Deliverable | Advance when |
|:--|:--|:--|
| M0 | A typed evidence buffer, candidate archive, persistent store and exact byte accounting | Detaching a buffer actually removes access to its records |
| M1 | A fixed-map harmonic read, its soft-weight iteration and a shared-coordinate encoder on small chain tasks | Direct solves agree with the algebra, and the descent inequality of Theorem 2 holds along every run |
| M2 | Branch-specific ASE search with the unchanged state as fallback | Candidate evaluations are reproducible and the archive contains no unevaluated fitness claims |
| M3 | External memory consolidation with independent admission data | Retention, compression and inference-cost criteria hold together |
| M4 | A small slow adapter with old-task protection and rollback | Parametric transfer survives the source-access ablation |
| M5 | A preregistered computational comparison and calibrated neural model | H1 to H4 and H7 are resolved before interpreting H5 and H6 as biological evidence |

## 12.1 Required comparisons and costs

The confirmatory comparison includes identity-map ADE; replay plus ordinary adapter training; a coreset or prototype memory; a matched graph-regularised learner; and a direct factor-aware or convex solver wherever applicable. Include oracle complete observations only as a ceiling. An unconstrained learner supplies a forgetting control. Give each method equal access to labels, contexts, tuning trials and stored auxiliary information.

Report retained bytes, query latency or operations, total consolidation compute, old and new task errors, false recombination rate, performance with original evidence detached, and calibration or abstention on unobserved directions. Report the cost of fitting restrictions and encoding the cover. Equal numbers of archive evaluations alone do not establish equal compute if one method performs much more inner training or larger linear solves.

For linear reads, form (6) sparsely and solve using the chain or graph structure. Do not materialise a dense global matrix merely to advertise local computation. Changes to the cover require comparison maps and new validation; cache reuse is allowed only when its dependencies remain valid. A C# implementation can use immutable episode, candidate and memory-version records, pure read functions and an atomic version replacement. Mutable numerical workspaces can remain private to a solver. The Part II kernel already implements the retention read, the guaranteed decrease of each relaxed step and the scalar truncation certificate, validated against NumPy [14]; M1 extends it with the prior and compatibility terms of (6).

## 12.2 Scope of the proposed contribution

The contribution to test is the combination of **typed partial-memory recombination, archive-based optimisation, and an independently evaluated durable write**. Horizontal sheaf algebra supplies compatibility and compression tools; vertical algebra describes how a proposal is constructed; slow learning gives it persistence. None of these alone proves that cortex runs ASE or that ASE searches better than established methods.

The recommended first study is M1 to M3 on chain-structured objectives, extending the recombination test C2 of the conversion proposal [1]. This isolates the proposed advantage before neural interpretation or full-backbone training. The critical result is not a lower reconstruction error on the same examples used to build the read. It is better future-task performance per durable byte, after original evidence is unavailable, without unacceptable loss of earlier knowledge.

# References

[1] Ghosh, D. P. (2026). *Autoregressive Sheaf Evolution*. Conversion proposal, revised 18 October 2026. Project manuscript.

[2] Ghosh, D. P. (2026). *Horizontally Topological, Vertically Algebraic*. Autoregressive Sheaf Evolution Part I, revised 18 October 2026. Project manuscript.

[3] McClelland, J. L., McNaughton, B. L. and O'Reilly, R. C. (1995). Why there are complementary learning systems in the hippocampus and neocortex: insights from the successes and failures of connectionist models of learning and memory. *Psychological Review* 102(3), 419–457. https://doi.org/10.1037/0033-295X.102.3.419

[4] Kitamura, T. et al. (2017). Engrams and circuits crucial for systems consolidation of a memory. *Science* 356(6333), 73–78. https://doi.org/10.1126/science.aam6808

[5] Rose, N. S. et al. (2016). Reactivation of latent working memories with transcranial magnetic stimulation. *Science* 354(6316), 1136–1139. https://doi.org/10.1126/science.aah7011

[6] Benna, M. K. and Fusi, S. (2016). Computational principles of synaptic memory consolidation. *Nature Neuroscience* 19, 1697–1706. https://doi.org/10.1038/nn.4401

[7] Schreiner, T. et al. (2024). Spindle-locked ripples mediate memory reactivation during human NREM sleep. *Nature Communications* 15, 5249. https://doi.org/10.1038/s41467-024-49572-8

[8] Wodeyar, A. et al. (2026). A hierarchical cascade of sleep rhythms supports motor memory and is hijacked by epileptic spikes in human epilepsy. *Proceedings of the National Academy of Sciences* 123(27), e2517454123. https://doi.org/10.1073/pnas.2517454123

[9] Widloski, J. and Foster, D. J. (2025). Replay without sharp wave ripples in a spatial memory task. *Nature Communications* 16, 10287. https://doi.org/10.1038/s41467-025-65181-5. Author correction (2026), *Nature Communications* 17, 3581. https://doi.org/10.1038/s41467-026-72252-8

[10] Kirkpatrick, J. et al. (2017). Overcoming catastrophic forgetting in neural networks. *Proceedings of the National Academy of Sciences* 114(13), 3521–3526. https://doi.org/10.1073/pnas.1611835114

[11] Hansen, J. and Ghrist, R. (2019). Toward a spectral theory of cellular sheaves. *Journal of Applied and Computational Topology* 3, 315–358. https://doi.org/10.1007/s41468-019-00038-7

[12] Russold, F. (2022). Persistent sheaf cohomology. arXiv:2204.13446. https://arxiv.org/abs/2204.13446

[13] Hoeffding, W. (1963). Probability inequalities for sums of bounded random variables. *Journal of the American Statistical Association* 58(301), 13–30. https://doi.org/10.1080/01621459.1963.10500830

[14] Ghosh, D. P. (2026). *The Horizontal Layer*. Autoregressive Sheaf Evolution Part II, 18 October 2026. Project manuscript.

[15] Rao, R. P. N. and Ballard, D. H. (1999). Predictive coding in the visual cortex: a functional interpretation of some extra-classical receptive-field effects. *Nature Neuroscience* 2(1), 79–87. https://doi.org/10.1038/4580

[16] Friston, K. (2005). A theory of cortical responses. *Philosophical Transactions of the Royal Society B* 360(1456), 815–836. https://doi.org/10.1098/rstb.2005.1622

[17] Bastos, A. M., Usrey, W. M., Adams, R. A., Mangun, G. R., Fries, P. and Friston, K. J. (2012). Canonical microcircuits for predictive coding. *Neuron* 76(4), 695–711. https://doi.org/10.1016/j.neuron.2012.10.038

[18] Teyler, T. J. and DiScenna, P. (1986). The hippocampal memory indexing theory. *Behavioral Neuroscience* 100(2), 147–154. https://doi.org/10.1037/0735-7044.100.2.147

[19] Maurer, A. and Pontil, M. (2009). Empirical Bernstein bounds and sample variance penalization. *Proceedings of the 22nd Conference on Learning Theory (COLT)*. arXiv:0907.3740

[20] Clopper, C. J. and Pearson, E. S. (1934). The use of confidence or fiducial limits illustrated in the case of the binomial. *Biometrika* 26(4), 404–413. https://doi.org/10.1093/biomet/26.4.404
