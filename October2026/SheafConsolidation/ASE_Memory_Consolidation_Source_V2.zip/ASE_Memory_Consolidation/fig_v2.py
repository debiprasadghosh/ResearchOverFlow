"""Figure 3 of version 2, drawn from checks_v2.json."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P = Path(__file__).resolve().parent
c = json.loads((P / 'checks_v2.json').read_text())
blue, orange, grey = '#28689b', '#c9692e', '#58636d'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9.5, 'axes.spines.top': False, 'axes.spines.right': False})
rows = c['prioritised_replay']; b = [r['beta'] for r in rows]
fig, ax = plt.subplots(1, 3, figsize=(10.6, 3.2))
ax[0].plot(b, [r['min_coverage'] for r in rows], 'o-', color=blue, lw=1.6)
ax[0].set(yscale='log', xscale='symlog', xlabel='prioritisation strength β', ylabel='smallest coverage', title='(a) coverage collapses')
ax[1].plot(b, [r['error_off_elite'] for r in rows], 'o-', color=orange, lw=1.6, label='features the elite did not observe')
ax[1].plot(b, [r['error_on_elite'] for r in rows], 's-', color=grey, lw=1.6, label='features the elite observed')
ax[1].set(xscale='symlog', xlabel='prioritisation strength β', ylabel='read error', title='(b) composition stops')
ax[1].legend(frameon=False, fontsize=8, loc='upper left')
rs = c['retention_sample_sizes']
names = ['Hoeffding', 'empirical\nBernstein', 'regression\ncount']
vals = [rs['hoeffding'], rs['empirical_bernstein_zero_variance'], rs['binomial_zero_regressions']]
bars = ax[2].bar(names, vals, color=[grey, blue, orange], width=0.6)
for bar, v in zip(bars, vals):
    ax[2].text(bar.get_x() + bar.get_width() / 2, v * 1.15, f'{v:,}', ha='center', fontsize=9)
ax[2].set(yscale='log', ylim=(100, 400000), ylabel='holdout examples needed', title='(c) admission sample size')
for a in ax:
    a.title.set_fontsize(10); a.title.set_fontweight('bold'); a.grid(alpha=.15)
fig.tight_layout()
fig.savefig(P / 'fig/prioritisation_admission.png', dpi=240, facecolor='white')
