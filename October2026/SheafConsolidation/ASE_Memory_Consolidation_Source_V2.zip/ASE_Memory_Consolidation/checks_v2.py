"""Checks for the results added in version 2. Construction checks and simulations, not memory-performance experiments."""
from pathlib import Path
import json, math, sys
import numpy as np

P = Path(__file__).resolve().parent
rng = np.random.default_rng(20261019)
R = {'status': 'construction checks and simulations; no empirical consolidation or neuroscience experiment',
     'seed': 20261019, 'python': sys.version.split()[0], 'numpy': np.__version__}


def softmax(x):
    e = np.exp(x - x.max()); return e / e.sum()


def problem():
    n = int(rng.integers(3, 8)); m = int(rng.integers(2, 9))
    D = rng.normal(size=(int(rng.integers(1, n)), n)); W = np.diag(rng.uniform(.5, 2, D.shape[0]))
    Pm = np.diag(rng.uniform(0, 1, n) * (rng.random(n) < .6))
    Hs = [rng.normal(size=(int(rng.integers(1, n + 1)), n)) for _ in range(m)]
    Ls = [np.diag(rng.uniform(.5, 2, H.shape[0])) for H in Hs]
    ys = [2 * rng.normal(size=H.shape[0]) for H in Hs]
    return dict(n=n, D=D, W=W, P=Pm, H=Hs, L=Ls, y=ys, q=rng.normal(size=n), lw=rng.normal(0, .5, m),
                beta=float(rng.uniform(0, 2)), gamma=float(rng.uniform(.3, 2)), s=float(rng.uniform(.5, 2.5)))


def parts(z, c):
    e = np.array([.5 * (H @ z - y) @ L @ (H @ z - y) for H, L, y in zip(c['H'], c['L'], c['y'])])
    w = softmax(c['lw'] - e / c['s'] ** 2)
    A = c['P'] + c['beta'] * c['D'].T @ c['W'] @ c['D'] + c['gamma'] * sum(wi * H.T @ L @ H for wi, H, L in zip(w, c['H'], c['L']))
    rhs = c['P'] @ c['q'] + c['gamma'] * sum(wi * H.T @ L @ y for wi, H, L, y in zip(w, c['H'], c['L'], c['y']))
    return e, w, A, rhs


def energy(z, c):
    e = np.array([.5 * (H @ z - y) @ L @ (H @ z - y) for H, L, y in zip(c['H'], c['L'], c['y'])])
    l = c['lw'] - e / c['s'] ** 2; mx = l.max()
    soft = -c['s'] ** 2 * (mx + math.log(np.exp(l - mx).sum()))
    u = z - c['q']; v = c['D'] @ z
    return .5 * u @ c['P'] @ u + .5 * c['beta'] * v @ c['W'] @ v + c['gamma'] * soft


# 1. The regularised soft read is a majorise-minimise step for every 0 <= lambda <= 2.
viol = 0; worst = math.inf; grad_err = 0.0; over = over_n = 0; trials = 2000; fixed = 0.0
for t in range(trials):
    c = problem(); z = 2 * rng.normal(size=c['n'])
    e, w, A, rhs = parts(z, c)
    if np.linalg.eigvalsh(A).min() < 1e-8:
        continue
    Rz = np.linalg.solve(A, rhs); d = z - Rz; g = .5 * d @ A @ d
    lam = float(rng.uniform(0, 2)); E0 = energy(z, c); E1 = energy(z + lam * (Rz - z), c)
    guar = lam * (2 - lam) * g
    viol += E1 > E0 - guar + 1e-10 * (1 + abs(E0))
    if guar > 1e-9:
        worst = min(worst, (E0 - E1) / guar)
    if t < 300:
        h = 1e-6; fd = np.array([(energy(z + h * u, c) - energy(z - h * u, c)) / (2 * h) for u in np.eye(c['n'])])
        grad_err = max(grad_err, float(np.abs(fd - A @ d).max() / (1 + np.abs(fd).max())))
    if g > 1e-6:
        over_n += 1; over += energy(z + float(rng.uniform(2.05, 3)) * (Rz - z), c) > E0
# fixed points of the iteration are stationary points
for t in range(40):
    c = problem(); z = rng.normal(size=c['n'])
    for _ in range(2000):
        e, w, A, rhs = parts(z, c); z = np.linalg.solve(A, rhs)
    e, w, A, rhs = parts(z, c)
    h = 1e-6; fd = np.array([(energy(z + h * u, c) - energy(z - h * u, c)) / (2 * h) for u in np.eye(c['n'])])
    fixed = max(fixed, float(np.abs(fd).max()))
R['soft_read_mm'] = dict(trials=trials, violations=int(viol), worst_ratio=float(worst), gradient_rel_err=grad_err,
                         over_two_trials=over_n, over_two_increases=int(over), fixed_point_gradient=fixed, fixed_runs=40)

# 2. Sample sizes for the retention certificate, and a coverage simulation of the regression-count rule.
N, eta, eps = 5, .05, .01
hoeff = math.ceil(2 * math.log(N / eta) / eps ** 2)
bern = math.ceil(1 + 7 * 2 * math.log(2 * N / eta) / (3 * eps))          # empirical Bernstein, zero sample variance
binom = math.ceil(math.log(eta / N) / math.log(1 - eps))                   # exact one-sided binomial, zero regressions
sims = 200000; p = eps * 1.01
reg = rng.binomial(binom, p, size=(sims, N))
false_accept = float(np.mean((reg == 0).any(1)))
R['retention_sample_sizes'] = dict(finalists=N, confidence=1 - eta, tolerance=eps, hoeffding=hoeff,
                                   empirical_bernstein_zero_variance=bern, binomial_zero_regressions=binom,
                                   simulated_false_acceptance=false_accept, simulations=sims, true_regression_rate=p)

# 3. Prioritised replay collapses coverage and stops composition (masked records in R^4).
D4, n4, s4 = 4, 12, 1.5
masks = [np.sort(rng.choice(D4, int(rng.integers(1, D4)), replace=False)) for _ in range(n4)]
masks[0] = np.array([0, 1])
for j in range(D4):
    if not any(j in mk for mk in masks[1:]):
        masks[1] = np.arange(D4)
truth = np.array([1.0, -0.5, 0.8, 0.3])
ys = [truth + .1 * rng.normal(size=D4) for _ in range(n4)]
J = rng.uniform(1, 3, n4); J[0] = 0.0
z0 = np.zeros(D4); rows = []
for beta in [0, 1, 3, 10, 30]:
    w = softmax(-beta * J - np.array([.5 * np.sum((z0[mk] - y[mk]) ** 2) for mk, y in zip(masks, ys)]) / s4 ** 2)
    kappa = np.array([sum(w[i] for i in range(n4) if j in masks[i]) for j in range(D4)])
    num = np.array([sum(w[i] * ys[i][j] for i in range(n4) if j in masks[i]) for j in range(D4)])
    read = np.where(kappa > 1e-10, num / np.maximum(kappa, 1e-300), z0)
    unobs = [j for j in range(D4) if j not in masks[0]]
    rows.append(dict(beta=beta, min_coverage=float(kappa.min()),
                     error_off_elite=float(np.linalg.norm(read[unobs] - truth[unobs])),
                     error_on_elite=float(np.linalg.norm(read[masks[0]] - truth[masks[0]]))))
R['prioritised_replay'] = rows

# 4. Settling time of repeated imputation is set by the least-covered coordinate.
ratios = []; exact = 0; cases = 0
for t in range(300):
    D = int(rng.integers(3, 8)); n = int(rng.integers(3, 9))
    mk = [np.sort(rng.choice(D, int(rng.integers(1, D + 1)), replace=False)) for _ in range(n)]
    if len(set(np.concatenate(mk))) < D:
        continue
    w = softmax(rng.normal(0, 1, n)); y = [rng.normal(size=D) for _ in range(n)]
    kappa = np.array([sum(w[i] for i in range(n) if j in mk[i]) for j in range(D)])
    target = np.array([sum(w[i] * y[i][j] for i in range(n) if j in mk[i]) for j in range(D)]) / kappa
    x = rng.normal(size=D) * 3; e0 = np.abs(x - target).max(); k = 0
    while np.abs(x - target).max() > 1e-6 * e0 and k < 100000:
        x = sum(wi * np.where(np.isin(np.arange(D), m), yi, x) for wi, m, yi in zip(w, mk, y)); k += 1
    pred = math.log(1e-6) / math.log(1 - kappa.min()) if kappa.min() < 1 else 1
    cases += 1; ratios.append(k / max(pred, 1)); exact += k <= math.ceil(pred) + 1
R['settling'] = dict(cases=cases, within_prediction=exact, ratio_min=float(min(ratios)), ratio_max=float(max(ratios)))

# 5. A two-population prediction-error circuit settles to the regularised read.
err = 0.0
for t in range(100):
    c = problem(); z = rng.normal(size=c['n']); e, w, A, rhs = parts(z, c)
    if np.linalg.eigvalsh(A).min() < 1e-3:
        continue
    ev = np.linalg.eigvalsh(A); Rz = np.linalg.solve(A, rhs); step = 1.0 / ev.max(); x = np.zeros(c['n'])
    for _ in range(int(min(400000, 40 * ev.max() / ev.min()))):
        errs = [L @ (y - H @ x) for H, L, y in zip(c['H'], c['L'], c['y'])]          # error units, frozen gains w
        drive = c['gamma'] * sum(wi * H.T @ ei for wi, H, ei in zip(w, c['H'], errs))
        x = x + step * (drive - c['P'] @ (x - c['q']) - c['beta'] * c['D'].T @ c['W'] @ (c['D'] @ x))
    err = max(err, float(np.abs(x - Rz).max() / (1 + np.abs(Rz).max())))
R['prediction_error_circuit'] = dict(cases=100, max_rel_err=err)

R['all_checks_pass'] = bool(viol == 0 and fixed < 1e-6 and false_accept <= eta and err < 1e-6)
(P / 'checks_v2.json').write_text(json.dumps(R, indent=1))
print(json.dumps(R, indent=1))
