# ASE for Memory Consolidation

Source for version 2 of the proposal, dated 18 October 2026, by Debi Prasad Ghosh. Version 1 is kept as `proposal_v1.md`.

The proposal develops an optimisation formulation and a testable cortical interpretation. Version 2 contains eleven formal statements with proofs, seven proposed hypotheses, three figures and a staged implementation plan. The five statements added in version 2 (Theorem 2 and Propositions 4, 8, 10 and 11) are checked by `checks_v2.py`, which writes `checks_v2.json`; `fig_v2.py` draws Figure 3 from it. It reports no empirical ASE consolidation-performance or neuroscience experiment.

## Contents

- `proposal_v2.md` is the complete editable text of version 2, with references; `proposal_v1.md` is version 1.
- `fig/` contains the original figures.
- `build.py`, `reference.docx` and `postprocess.py` rebuild the Word document using pandoc, python-docx, NumPy, Matplotlib and lxml.
- `checks.py` and `checks.json` provide six small construction checks, including the displayed holdout sample-size calculation. These checks are not tests of search superiority or the cortical hypothesis.
- `validation.json` records the final page review and structural Word checks. It does not claim complete independent OOXML schema validation.
- `environment.json` records the environment used to build this version.

Run `python checks.py`, `python checks_v2.py`, `python fig_v2.py` and `python build.py` from this directory. The build produces `output/ASE_Memory_Consolidation_Proposal_V2.docx`. Version 2 was built with Python 3.13.16 and NumPy 2.5.3; the version 2 Word file passes OOXML schema validation. Python 3.12.14 and NumPy 2.3.5 were used for the supplied construction checks. Tiny floating-point residuals may vary with library and platform versions. No .NET kernel is introduced or compiled for this proposal.

The definitive page count is the supplied render, not a universal pagination guarantee across Word versions and printer settings. Review the rebuilt document visually before publication.
