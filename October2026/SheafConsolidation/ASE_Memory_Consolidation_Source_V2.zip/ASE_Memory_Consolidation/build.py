from pathlib import Path
import re, subprocess, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

P=Path(__file__).resolve().parent
(P/'output').mkdir(exist_ok=True)
(P/'fig').mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
blue='#28689b'; orange='#c9692e'; grey='#58636d'
fig,ax=plt.subplots(figsize=(10.7,4.1));ax.set(xlim=(0,10.7),ylim=(0,4.1));ax.axis('off')
def box(x,y,w,h,title,body,color=blue):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.07,rounding_size=0.06',facecolor='#f6f8fa',edgecolor=color,linewidth=1.2))
    ax.text(x+w/2,y+h-.23,title,ha='center',va='center',fontsize=11,fontweight='bold',color=color)
    ax.text(x+w/2,y+h/2-.13,body,ha='center',va='center',fontsize=9.4,linespacing=1.4)
def arrow(a,b,text='',pos=None,color=grey):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=12,linewidth=1.15,color=color))
    if text:ax.text(*(pos or ((a[0]+b[0])/2,(a[1]+b[1])/2)),text,ha='center',va='center',fontsize=8.5,color=color,bbox={'facecolor':'white','edgecolor':'none','pad':1})
box(.12,2.38,2.25,1.22,'Evidence buffer E','Episodes and targets\nwith provenance')
box(.12,.25,2.25,1.22,'Old slow state','Persistent memory\nand slow parameters')
box(3.45,2.38,2.7,1.22,'ASE search archive A','Evaluated candidate packages\nwith losses and costs')
box(3.45,.25,2.7,1.22,'Candidate construction','Local reads and recombination\nplus permitted inner training')
box(7.28,2.38,3.16,1.22,'Independent admission','New-task fidelity, old-task\nretention and storage limits',orange)
box(7.28,.25,3.16,1.22,'Accepted durable state','Updated codes or parameters\nwith version and rollback')
arrow((2.37,2.9),(3.45,1.3),'replay targets',(2.81,2.18))
arrow((2.37,.83),(3.45,.83),'initialise',(2.91,1.04))
arrow((4.8,2.38),(4.8,1.47),'propose',(5.19,1.91))
arrow((5.9,1.47),(5.9,2.38),'evaluate',(6.30,2.10))
arrow((6.15,.93),(7.28,2.75),'freeze finalists',(6.83,1.55))
arrow((8.87,2.38),(8.87,1.47),'accept',(9.26,1.91),orange)

fig.savefig(P/'fig/architecture.png',dpi=240,bbox_inches='tight',facecolor='white');plt.close(fig)
fig,ax=plt.subplots(figsize=(6.6,3.65));ax.set_aspect('equal')
ax.plot([0,1],[0,1],c=grey,lw=2,label='Complete archive hull and hidden law')
ax.scatter([0,1],[0,1],s=50,c=grey,zorder=3)
ax.scatter([1],[0],s=90,c=orange,marker='X',zorder=4,label='Overlap-compatible recombination')
ax.scatter([.5],[.5],s=65,c=blue,zorder=4,label='Projection after enforcing hidden law')
ax.annotate('prototype 2',(0,0),xytext=(.04,.13),fontsize=9)
ax.annotate('prototype 1',(1,1),xytext=(.64,1.07),fontsize=9)
ax.annotate('(1, 0)',(1,0),xytext=(.74,.10),fontsize=9,color=orange)
ax.annotate('(0.5, 0.5)',(.5,.5),xytext=(.08,.65),arrowprops={'arrowstyle':'-','color':blue},fontsize=9,color=blue)
ax.set(xlabel='a',ylabel='c',xlim=(-.13,1.2),ylim=(-.13,1.23),xticks=[0,.5,1],yticks=[0,.5,1])
ax.grid(alpha=.15);ax.legend(loc='upper left',bbox_to_anchor=(1.05,1),frameon=False,fontsize=9)
fig.savefig(P/'fig/recombination.png',dpi=240,bbox_inches='tight',facecolor='white');plt.close(fig)

# Reuse the current scholarly styles, with a clean header and no title ornaments.
template=P/'reference.docx'
if not template.exists():template=P.parent/'part1_work/scholarly_ref.docx'
doc=Document(template)
for child in list(doc._element.body):
    if child.tag!=qn('w:sectPr'):doc._element.body.remove(child)
doc.core_properties.title='ASE memory proposal styles'
for sec in doc.sections:
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.left_margin=sec.right_margin=Inches(.78)
    sec.top_margin=Inches(.7);sec.bottom_margin=Inches(.7)
    sec.header_distance=Inches(.3);sec.footer_distance=Inches(.3)
    for part in (sec.header,sec.first_page_header,sec.even_page_header,sec.footer,sec.first_page_footer,sec.even_page_footer):
        for p in part.paragraphs:p.clear()
    foot=sec.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=foot.add_run();f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');r._r.addnext(f)
for name in ['Normal','Body Text','First Paragraph','Compact','Statement']:
    st=doc.styles[name];st.font.name='Liberation Serif';st.font.size=Pt(11)
    st.paragraph_format.line_spacing=1.14;st.paragraph_format.space_after=Pt(7)
for name in ['Title','Subtitle','Author','Date']:
    doc.styles[name].paragraph_format.keep_with_next=True
    doc.styles[name].font.color.rgb=RGBColor(0,0,0)
doc.styles['Title'].font.size=Pt(24)
doc.styles['Date'].paragraph_format.space_after=Pt(15)
for name in ['Image Caption','Caption']:
    doc.styles[name].font.size=Pt(9.7)
    doc.styles[name].paragraph_format.space_after=Pt(10)
doc.styles['Bibliography'].font.size=Pt(10)
doc.styles['Bibliography'].paragraph_format.space_after=Pt(7)
for name in ['Equation','Statement Equation']:
    pf=doc.styles[name].paragraph_format
    pf.space_before=Pt(4);pf.space_after=Pt(9);pf.line_spacing=1.0
    pf.keep_together=True
    pr=doc.styles[name].element.get_or_add_pPr()
    old=pr.find(qn('w:tabs'))
    if old is not None:pr.remove(old)
    tabs=OxmlElement('w:tabs')
    for value,pos in [('center',4997),('right',9994)]:
        item=OxmlElement('w:tab');item.set(qn('w:val'),value);item.set(qn('w:pos'),str(pos));tabs.append(item)
    pr.append(tabs)
for st in doc.styles:
    for node in list(st.element.iter()):
        if node.tag in [qn('w:pBdr'),qn('w:shd')]:node.getparent().remove(node)
    if st.type==1:st.font.color.rgb=RGBColor(0,0,0)
doc.save(P/'reference.docx')
s=(P/'proposal_v2.md').read_text()
def display(m):
    math=m.group(1).strip()
    num=re.search(r'\\tag\{(\d+)\}',math)
    if num:
        math=math[:num.start()].strip()
        if math.startswith(r'\begin{aligned}'):
            math=math.replace(r'\begin{aligned}','').replace(r'\end{aligned}','')
            lines=math.split(r'\\')
            return '\n'.join('\n::: {custom-style="Equation"}\n$'+line.replace('&','').replace('\n',' ').strip()+'$'+(' ('+num.group(1)+')' if i==len(lines)-1 else '')+'\n:::\n' for i,line in enumerate(lines))
        return '\n::: {custom-style="Equation"}\n$'+math.replace('\n',' ')+'$ ('+num.group(1)+')\n:::\n'
    return m.group(0)
s=re.sub(r'\$\$(.*?)\$\$',display,s,flags=re.S)
# A fresh section for sources keeps the scholarly reading sequence clear.
s=s.replace('# References','\n# References')
(P/'build.md').write_text(s)
subprocess.run(['pandoc','-f','markdown+tex_math_dollars','build.md','-o','raw.docx','--reference-doc=reference.docx','--resource-path=.','--no-highlight'],cwd=P,check=True)
doc=Document(P/'raw.docx')
doc.core_properties.title='Autoregressive Sheaf Evolution for Memory Consolidation'
doc.core_properties.author='Debi Prasad Ghosh'
doc.core_properties.subject='Optimisation proposal and a testable neocortical interpretation'
doc.core_properties.keywords='ASE; memory consolidation; neocortex; sheaf; replay; continual learning'
inrefs=False
for para in doc.paragraphs:
    if para.style.name=='Title':
        para.text='Autoregressive Sheaf Evolution\nfor Memory Consolidation'
    if para.text=='References':
        inrefs=True;para.paragraph_format.page_break_before=True
    elif inrefs and para.text.startswith('['):para.style=doc.styles['Bibliography']
    if para.text.startswith(('Proposition ','Theorem ')):
        para.paragraph_format.keep_with_next=True
    if para.style.name=='Equation' and not re.search(r'\(\d+\)\s*$',para.text):
        para.paragraph_format.keep_with_next=True
    if para.style.name in ['Caption','Image Caption']:
        para.paragraph_format.keep_together=True
    if para._p.xpath('.//w:drawing'):
        para.paragraph_format.keep_with_next=True
for i,table in enumerate(doc.tables):
    widths=[[1.35,2.65,2.94],[1.45,3.1,2.39],[.65,3.2,3.09]][i]
    table.autofit=False
    for col,w in zip(table.columns,widths):col.width=Inches(w)
    pr=table._tbl.tblPr
    old=pr.find(qn('w:tblBorders'))
    if old is not None:pr.remove(old)
    borders=OxmlElement('w:tblBorders')
    for side in ['top','left','bottom','right','insideH','insideV']:
        el=OxmlElement('w:'+side);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'4');el.set(qn('w:color'),'D9D9D9');borders.append(el)
    pr.append(borders)
    for ri,row in enumerate(table.rows):
        if ri==0:row._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
        for cell,w in zip(row.cells,widths):
            cell.width=Inches(w);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcpr=cell._tc.get_or_add_tcPr()
            shade=OxmlElement('w:shd');shade.set(qn('w:val'),'clear');shade.set(qn('w:fill'),'E7EBEF' if ri==0 else ('F7F8F9' if ri%2==0 else 'FFFFFF'));tcpr.append(shade)
            margins=OxmlElement('w:tcMar')
            for side,val in [('top',60 if i==0 else 85),('start',85),('bottom',60 if i==0 else 85),('end',85)]:
                el=OxmlElement('w:'+side);el.set(qn('w:w'),str(val));el.set(qn('w:type'),'dxa');margins.append(el)
            tcpr.append(margins)
            for para in cell.paragraphs:
                para.paragraph_format.space_after=Pt(2);para.paragraph_format.space_before=Pt(1)
                para.paragraph_format.line_spacing=1.06
                for run in para.runs:
                    run.font.size=Pt(10.0 if i==0 else 10.2)
                    if ri==0:run.bold=True
    # Let longer tables flow rather than forcing a large blank space.
    for row in table.rows:
        for para in row._tr.xpath('.//w:p'):
            ppr=para.find(qn('w:pPr'))
            if ppr is not None:
                for keep in ppr.findall(qn('w:keepNext')):ppr.remove(keep)
doc.save(P/'layout.docx')
post_path=P/'postprocess.py'
if not post_path.exists():post_path=P.parent/'part1_work/postprocess.py'
post=post_path.read_text()
post=post.replace(r'\d+\.\d+',r'\d+(?:\.\d+)?')
# Only prohibit row splitting; allow the proposal tables to cross pages if necessary.
post=post.replace('def tables(root, short=15):','def tables(root, short=0):')
(P/'postprocess.py').write_text(post)
subprocess.run([sys.executable,'postprocess.py','layout.docx','output/ASE_Memory_Consolidation_Proposal_V2.docx'],cwd=P,check=True)
# Source copy uses figure paths relative to the source project when opened there.
(P/'output/ASE_Memory_Consolidation_Proposal_V2.md').write_text((P/'proposal_v2.md').read_text())
print('Built proposal')
