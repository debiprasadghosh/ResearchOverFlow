set -e
python3 assemble.py && python3 populate.py && python3 build.py && python3 verify.py > /dev/null
python3 ../../book/tools/topdf.py output/Sheaf_Structured_Generative_Diffusion.docx preview.pdf
pdftotext preview.pdf preview.txt; echo "broken glyphs: $(grep -c '¿' preview.txt || true)"; pdfinfo preview.pdf | grep Pages
