// Sheaf-structured diffusion, V2 reference kernel: the among-example horizontal.
// Immutable values and pure static functions; a private copy is used inside
// the Cholesky solve.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace SheafDiffusion;

/// <summary>One point of a variance-preserving schedule, a^2 + s^2 = 1.</summary>
public sealed record Level(double A, double S);

/// <summary>Records y_i with log prior weights: the leaves of the example
/// star at every noise level.</summary>
public sealed record Archive(ImmutableArray<Vec> Records, Vec LogWeights);

/// <summary>A read: the posterior mean and the weights on the records.</summary>
public sealed record Read(Vec Mean, Vec Weights);

public static class ExampleSheaf
{
    static double Sq(Vec u, Vec v, double a) =>
        u.Zip(v, (p, q) => (p - a * q) * (p - a * q)).Sum();

    static Vec Softmax(Vec logits)
    {
        double top = logits.Max();
        var e = logits.Select(v => Math.Exp(v - top)).ToImmutableArray();
        double z = e.Sum();
        return e.Select(v => v / z).ToImmutableArray();
    }

    static Vec Axpy(double a, Vec x, double b, Vec y) =>
        x.Zip(y, (p, q) => a * p + b * q).ToImmutableArray();

    /// <summary>Example-star read (26): posterior mean of x0 given x_t = x
    /// for the empirical measure of the archive.</summary>
    public static Read ReadAt(Archive arc, Vec x, Level lv)
    {
        var w = Softmax(arc.Records
            .Select((y, i) =>
                arc.LogWeights[i] - Sq(x, y, lv.A) / (2 * lv.S * lv.S))
            .ToImmutableArray());
        int d = x.Length;
        var mean = Enumerable.Range(0, d)
            .Select(k => arc.Records.Select((y, i) => w[i] * y[k]).Sum())
            .ToImmutableArray();
        return new Read(mean, w);
    }

    /// <summary>DDIM coefficients (c, sigma) from lv to next.</summary>
    public static (double C, double Sigma) Coefficients(
        Level lv, Level next, double eta)
    {
        double sig = eta * next.S / lv.S
                     * Math.Sqrt(Math.Max(0, 1 - lv.A * lv.A / (next.A * next.A)));
        sig = Math.Min(sig, next.S);
        return (Math.Sqrt(Math.Max(0, next.S * next.S - sig * sig)), sig);
    }

    /// <summary>One DDIM step with a given clean prediction m (3)-(4).</summary>
    public static Vec Step(Vec x, Vec m, Level lv, Level next, double eta, Vec xi)
    {
        var (c, sig) = Coefficients(lv, next, eta);
        return Enumerable.Range(0, x.Length)
            .Select(k => next.A * m[k] + c * (x[k] - lv.A * m[k]) / lv.S
                         + sig * xi[k])
            .ToImmutableArray();
    }

    /// <summary>Diffusion Evolution step: every individual reads the whole
    /// current population, weighted by fitness (Theorem 10.4).</summary>
    public static ImmutableArray<Vec> EvolutionStep(ImmutableArray<Vec> pop,
        Vec logFitness, Level lv, Level next, double eta, ImmutableArray<Vec> xi)
    {
        var self = new Archive(pop, logFitness);
        return pop.Select((x, j) =>
            Step(x, ReadAt(self, x, lv).Mean, lv, next, eta, xi[j]))
            .ToImmutableArray();
    }

    /// <summary>Horizontal reach: the effective number of records read.</summary>
    public static double Reach(Read r) => 1.0 / r.Weights.Sum(w => w * w);

    /// <summary>Equivariant local read on a circular signal (Section 13): pixel
    /// p reads the centre values of all training windows of width 2r+1.</summary>
    public static Vec LocalRead(ImmutableArray<Vec> train, Vec x, int r, Level lv)
    {
        int n = x.Length;
        Vec Window(Vec y, int p) => Enumerable.Range(-r, 2 * r + 1)
            .Select(k => y[((p + k) % n + n) % n]).ToImmutableArray();
        var pats = train
            .SelectMany(y => Enumerable.Range(0, n).Select(p => Window(y, p)))
            .ToImmutableArray();
        return Enumerable.Range(0, n).Select(p =>
        {
            var xw = Window(x, p);
            var w = Softmax(pats.Select(q => -Sq(xw, q, lv.A) / (2 * lv.S * lv.S))
                                .ToImmutableArray());
            return pats.Select((q, i) => w[i] * q[r]).Sum();
        }).ToImmutableArray();
    }

    /// <summary>Coupled Gaussian denoiser (Theorem 12.1):
    /// D(x) = mu + a/(a^2 + p s^2) (I + h L)^{-1} (x - a mu),
    /// h = beta s^2/(a^2 + p s^2): one implicit sheaf heat step across
    /// examples.</summary>
    public static Vec CoupledDenoise(ImmutableArray<Vec> laplacian, Vec mu, Vec x,
        double p, double beta, Level lv)
    {
        double den = lv.A * lv.A + p * lv.S * lv.S, h = beta * lv.S * lv.S / den;
        int n = x.Length;
        var rhs = Axpy(1, x, -lv.A, mu);
        var sys = laplacian
            .Select((row, i) => row
                .Select((v, j) => (i == j ? 1 : 0) + h * v).ToImmutableArray())
            .ToImmutableArray();
        var y = CholeskySolve(sys, rhs);
        return Axpy(1, mu, lv.A / den, y);
    }

    /// <summary>Solve S y = b for symmetric positive definite S.</summary>
    public static Vec CholeskySolve(ImmutableArray<Vec> s, Vec b)
    {
        int n = b.Length;
        var l = new double[n, n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j <= i; j++)
            {
                double sum = s[i][j];
                for (int k = 0; k < j; k++) sum -= l[i, k] * l[j, k];
                l[i, j] = i == j ? Math.Sqrt(sum) : sum / l[j, j];
            }
        var z = new double[n];
        for (int i = 0; i < n; i++)
        {
            double sum = b[i];
            for (int k = 0; k < i; k++) sum -= l[i, k] * z[k];
            z[i] = sum / l[i, i];
        }
        var y = new double[n];
        for (int i = n - 1; i >= 0; i--)
        {
            double sum = z[i];
            for (int k = i + 1; k < n; k++) sum -= l[k, i] * y[k];
            y[i] = sum / l[i, i];
        }
        return y.ToImmutableArray();
    }

    /// <summary>Spectral coupling schedule (36): the extra precision that
    /// the noised target places on a horizontal mode of eigenvalue mu.</summary>
    public static double Kappa(double mu, double p, double beta, Level lv)
    {
        double a2 = lv.A * lv.A, s2 = lv.S * lv.S;
        return a2 * beta * mu / ((a2 + s2 * (p + beta * mu)) * (a2 + s2 * p));
    }
}
