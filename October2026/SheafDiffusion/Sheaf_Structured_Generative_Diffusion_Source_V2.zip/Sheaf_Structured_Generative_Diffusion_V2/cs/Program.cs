// Validation run of the V2 kernel; cs_validate.py recomputes every printed
// number with an independent NumPy implementation.
using System;
using System.Collections.Immutable;
using System.Globalization;
using System.Linq;
using SheafDiffusion;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

static Vec V(params double[] x) => ImmutableArray.Create(x);
static string F(double x) => x.ToString("G15", CultureInfo.InvariantCulture);
static void Print(string name, params double[] xs) =>
    Console.WriteLine(name + " " + string.Join(" ", xs.Select(F)));
static Level L(double a) => new(a, Math.Sqrt(1 - a * a));

// an archive of five records and one read at a = 0.6
var arc = new Archive(
    ImmutableArray.Create(V(0.0, 0.0), V(1.0, 0.2), V(0.4, 1.1), V(2.2, 1.5),
                          V(-0.8, 0.9)),
    V(0.0, 0.3, -0.2, 0.1, -0.4));
var read = ExampleSheaf.ReadAt(arc, V(0.7, -0.3), L(0.6));
Print("read_mean", read.Mean.ToArray());
Print("read_weights", read.Weights.ToArray());
Print("read_reach", ExampleSheaf.Reach(read));
Print("ddim_step_eta_half", ExampleSheaf.Step(V(0.7, -0.3), read.Mean, L(0.6),
      L(0.8), 0.5, V(0.25, -1.1)).ToArray());

// a twenty-level deterministic run with the exact empirical read
var levels = Enumerable.Range(0, 21)
    .Select(t => L(Math.Max(0.02, Math.Cos(Math.PI / 2 * t / 20.0))))
    .ToImmutableArray();
var x = V(1.3, -0.4);
for (int t = 20; t >= 1; t--)
    x = ExampleSheaf.Step(x, ExampleSheaf.ReadAt(arc, x, levels[t]).Mean,
                          levels[t], levels[t - 1], 0.0, V(0.0, 0.0));
Print("ddim_run_output", x.ToArray());

// one Diffusion Evolution step of a six-member population, eta = 0 and 1
var pop = Enumerable.Range(0, 6)
    .Select(j => V(1.5 * Math.Sin(1.3 * j + 0.2), 1.5 * Math.Cos(0.7 * j + 0.5)))
    .ToImmutableArray();
var fit = Enumerable.Range(0, 6).Select(j => Math.Sin(2.1 * j)).ToImmutableArray();
var xi = Enumerable.Range(0, 6)
    .Select(j => V(Math.Sin(0.9 * j + 1.0), Math.Cos(1.1 * j + 0.4)))
    .ToImmutableArray();
foreach (var eta in new[] { 0.0, 1.0 })
    Print($"de_step_eta_{eta:0}", ExampleSheaf.EvolutionStep(pop, fit, L(0.3), L(0.5),
          eta, xi).SelectMany(v => v).ToArray());

// the equivariant local read on a ten-pixel circular signal, window 3
var train = ImmutableArray.Create(
    V(1, 1, -1, -1, -1, 1, 1, 1, -1, -1), V(1, 1, 1, 1, -1, -1, 1, 1, -1, -1),
    V(-1, -1, -1, 1, 1, 1, 1, -1, -1, -1));
var sig = Enumerable.Range(0, 10).Select(p => Math.Sin(0.8 * p + 0.3)).ToImmutableArray();
Print("local_read_r1", ExampleSheaf.LocalRead(train, sig, 1, L(0.7)).ToArray());
Print("local_read_r2", ExampleSheaf.LocalRead(train, sig, 2, L(0.9)).ToArray());

// coupled Gaussian denoiser on three examples in the plane joined in a path
var delta = ImmutableArray.Create(
    V(-1.0, 0.5, 0.8, 0.0, 0.0, 0.0), V(0.0, 0.0, -0.3, 1.2, 0.0, 0.0),
    V(0.0, 0.0, 1.1, -0.4, 0.9, 0.2));
var lap = Enumerable.Range(0, 6).Select(i => Enumerable.Range(0, 6)
    .Select(j => delta.Sum(r => r[i] * r[j])).ToImmutableArray()).ToImmutableArray();
var mu = V(0.2, -0.1, 0.4, 0.3, -0.5, 0.1);
var xc = V(0.9, -0.7, 0.3, 1.4, -0.2, 0.6);
Print("coupled_denoise_a06", ExampleSheaf.CoupledDenoise(lap, mu, xc, 1.0, 2.0, L(0.6)).ToArray());
Print("coupled_denoise_a015", ExampleSheaf.CoupledDenoise(lap, mu, xc, 1.0, 2.0, L(0.15)).ToArray());
Print("kappa", new[] { 0.0, 0.5, 3.0 }.SelectMany(m =>
      new[] { 0.95, 0.6, 0.15 }.Select(a => ExampleSheaf.Kappa(m, 1.0, 2.0, L(a))))
      .ToArray());
