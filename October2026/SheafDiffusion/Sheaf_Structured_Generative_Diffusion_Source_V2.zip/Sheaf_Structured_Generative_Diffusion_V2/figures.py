from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,FancyArrowPatch
P=Path(__file__).resolve().parent
r=json.loads((P/'results.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
blue,orange,grey='#28689b','#c9692e','#58636d'
fig,ax=plt.subplots(figsize=(9,3.7));ax.axis('off');ax.set(xlim=(-.3,9.3),ylim=(-.3,3.6))
for yy,tt in [(2.5,'t'),(.3,'t-1')]:
    for xx,kind in [(0,'v'),(3.6,'e'),(7.2,'w')]:
        ax.add_patch(Rectangle((xx,yy),1.8,.65,facecolor='white',edgecolor=grey,lw=1.1))
        label=f'$F_{{{tt}}}({kind})$'
        ax.text(xx+.9,yy+.325,label,ha='center',va='center',fontsize=13)
    for a,b,label in [((1.8,yy+.325),(3.6,yy+.325),'restriction'),((7.2,yy+.325),(5.4,yy+.325),'restriction')]:
        ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=13,color=blue,lw=1.4))
        ax.text((a[0]+b[0])/2,yy+.53,label,ha='center',fontsize=10,color=blue)
for xx,label in [(0,'$V_t^v$'),(3.6,'$V_t^e$'),(7.2,'$V_t^w$')]:
    ax.add_patch(FancyArrowPatch((xx+.9,2.5),(xx+.9,.95),arrowstyle='-|>',mutation_scale=14,color=orange,lw=1.5))
    ax.text(xx+1.1,1.7,label,color=orange,fontsize=11)
ax.text(4.5,3.38,'Horizontal shared observables',ha='center',fontsize=12,color=blue)
ax.text(4.5,-.12,'Vertical denoising maps',ha='center',fontsize=12,color=orange)
fig.savefig(P/'fig/squares.png',dpi=240,bbox_inches='tight',facecolor='white');plt.close(fig)

rows=r['heat']['rows'];ts=[x['tau'] for x in rows]
fig,axs=plt.subplots(1,2,figsize=(9,3.25))
for key,label,color in [('valid_variance','Consistent heat family',blue),('invalid_variance','Proper but inconsistent family',orange)]:
    axs[0].plot(ts,[x[key] for x in rows],marker='o',c=color,label=label)
axs[0].set(xlabel='Noise variance time τ',ylabel='Marginal variance',title='(a) Forward variance evolution')
axs[0].legend(frameon=False,fontsize=8.7)
axs[1].plot(ts,[x['invalid_spatial_residual_range'] for x in rows],'o-',c=orange,label='Inconsistent')
axs[1].plot(ts,[x['valid_spatial_residual_range'] for x in rows],'s-',c=blue,label='Consistent')
axs[1].set(xlabel='Noise variance time τ',ylabel='Spatial range of PDE residual',title='(b) Heat consistency test')
axs[1].legend(frameon=False,fontsize=9)
for a in axs:a.grid(alpha=.15)
fig.tight_layout();fig.savefig(P/'fig/heat.png',dpi=240,facecolor='white');plt.close(fig)

rows=r['noise']['rows'];s=np.array([x['noise_scale'] for x in rows])
fig,ax=plt.subplots(figsize=(7.6,3.35))
ax.plot(s,[x['ambient_theory'] for x in rows],c=grey,lw=2,label='Ambient analytic expectation')
ax.scatter(s,[x['ambient_mean_squared_residual'] for x in rows],c=blue,s=40,label='Ambient Monte Carlo',zorder=3)
ax.plot(s,[x['compatible_mean_squared_residual'] for x in rows],'s-',c=orange,label='Compatible projected noise')
ax.set(xlabel='Noise scale s',ylabel='Mean squared horizontal residual',ylim=(-.15,4.4))
ax.grid(alpha=.15);ax.legend(frameon=False,fontsize=10,loc='upper left')
fig.tight_layout();fig.savefig(P/'fig/noise.png',dpi=240,facecolor='white');plt.close(fig)
print('Built three figures from declared structure and saved results')
