"""Recompute every line printed by the C# kernel with NumPy and compare."""
from pathlib import Path
import json, math, subprocess
import numpy as np
from scipy.special import softmax

P = Path(__file__).resolve().parent
dll = P / 'cs/bin/Release/net8.0/SheafDiffusion.dll'
subprocess.run(['dotnet', 'build', '-c', 'Release'], cwd=P / 'cs', check=True, capture_output=True)
cs = subprocess.run(['dotnet', str(dll)], capture_output=True, text=True, check=True).stdout.strip().splitlines()
(P / 'cs/cs_out.txt').write_text('\n'.join(cs) + '\n')


def lv(a):
    return a, math.sqrt(1 - a * a)


def read(Y, lw, x, a, s):
    w = softmax(lw - ((x - a * Y) ** 2).sum(1) / (2 * s * s))
    return w @ Y, w


def coeffs(a, s, ap, sp, eta):
    sig = min(eta * sp / s * math.sqrt(max(0, 1 - a * a / (ap * ap))), sp)
    return math.sqrt(max(0, sp * sp - sig * sig)), sig


def step(x, m, a, s, ap, sp, eta, xi):
    c, sig = coeffs(a, s, ap, sp, eta)
    return ap * m + c * (x - a * m) / s + sig * xi


Y = np.array([[0, 0], [1, .2], [.4, 1.1], [2.2, 1.5], [-.8, .9]]); lw = np.array([0, .3, -.2, .1, -.4])
py = []
m, w = read(Y, lw, np.array([.7, -.3]), *lv(.6))
py += [('read_mean', m), ('read_weights', w), ('read_reach', [1 / (w ** 2).sum()]),
       ('ddim_step_eta_half', step(np.array([.7, -.3]), m, *lv(.6), *lv(.8), .5, np.array([.25, -1.1])))]
levels = [lv(max(.02, math.cos(math.pi / 2 * t / 20))) for t in range(21)]
x = np.array([1.3, -.4])
for t in range(20, 0, -1):
    x = step(x, read(Y, lw, x, *levels[t])[0], *levels[t], *levels[t - 1], 0.0, np.zeros(2))
py.append(('ddim_run_output', x))
pop = np.array([[1.5 * math.sin(1.3 * j + .2), 1.5 * math.cos(.7 * j + .5)] for j in range(6)])
fit = np.array([math.sin(2.1 * j) for j in range(6)])
xi = np.array([[math.sin(.9 * j + 1), math.cos(1.1 * j + .4)] for j in range(6)])
for eta in (0, 1):
    new = np.array([step(pop[j], read(pop, fit, pop[j], *lv(.3))[0], *lv(.3), *lv(.5), eta, xi[j]) for j in range(6)])
    py.append((f'de_step_eta_{eta}', new.ravel()))
train = np.array([[1, 1, -1, -1, -1, 1, 1, 1, -1, -1], [1, 1, 1, 1, -1, -1, 1, 1, -1, -1],
                  [-1, -1, -1, 1, 1, 1, 1, -1, -1, -1]], float)
sig = np.sin(.8 * np.arange(10) + .3)


def local(x, r, a, s):
    idx = lambda p: [(p + k) % 10 for k in range(-r, r + 1)]
    pats = np.array([y[idx(p)] for y in train for p in range(10)])
    out = []
    for p in range(10):
        w = softmax(-((x[idx(p)] - a * pats) ** 2).sum(1) / (2 * s * s))
        out.append(w @ pats[:, r])
    return np.array(out)


py += [('local_read_r1', local(sig, 1, *lv(.7))), ('local_read_r2', local(sig, 2, *lv(.9)))]
delta = np.array([[-1, .5, .8, 0, 0, 0], [0, 0, -.3, 1.2, 0, 0], [0, 0, 1.1, -.4, .9, .2]])
L = delta.T @ delta
mu = np.array([.2, -.1, .4, .3, -.5, .1]); xc = np.array([.9, -.7, .3, 1.4, -.2, .6])
for tag, a in (('a06', .6), ('a015', .15)):
    a, s = lv(a)
    C = np.linalg.inv(np.eye(6) + 2.0 * L)                 # p = 1, beta = 2: exact Gaussian posterior form
    D = mu + a * C @ np.linalg.solve(a * a * C + s * s * np.eye(6), xc - a * mu)
    py.append((f'coupled_denoise_{tag}', D))
kap = []
evals, evecs = None, None
for mu_k in (0.0, .5, 3.0):
    for a in (.95, .6, .15):
        a, s = lv(a)
        # kappa from the definition: precision of the noised mode minus the uncoupled precision
        kap.append((1 + 2 * mu_k) / (a * a + s * s * (1 + 2 * mu_k)) - 1 / (a * a + s * s))
py.append(('kappa', np.array(kap)))

rows = []; per = []; csl = []; pyl = []
for line, (name, vals) in zip(cs, py):
    head, *nums = line.split()
    assert head == name, (head, name)
    c = np.array([float(v) for v in nums]); v = np.asarray(vals, float)
    rel = float(np.max(np.abs(c - v) / np.maximum(1, np.abs(v))))
    per.append(rel); csl.append(line)
    pyl.append(name + ' ' + ' '.join(repr(float(f'{q:.15g}')) for q in v))
out = {'lines': len(cs), 'max_relative_difference': max(per), 'per_line': per, 'csharp': csl, 'python': pyl,
       'dotnet': subprocess.run(['dotnet', '--version'], capture_output=True, text=True).stdout.strip()}
(P / 'cs_validate.json').write_text(json.dumps(out, indent=1) + '\n')
print(json.dumps({k: out[k] for k in ('lines', 'max_relative_difference')}))
for n_, r_ in zip(py, per):
    print(f'{n_[0]:24s} {r_:.2e}')
assert max(per) < 1e-12
