# Sheaf Structured Generative Diffusion, Version 2

This source accompanies the Word paper by Debi Prasad Ghosh, Version 2, dated
19 October 2026. It traces ASE back through ADE and Diffusion Evolution to
DDPM/DDIM with one organising rule: the denoising direction is vertical and the
relation among examples is horizontal.

Version 1 (Sections 2-9, retained) placed the horizontal structure inside one
candidate. Version 2 adds Sections 10-13 and Appendix A:

- Section 10: the exact empirical denoiser is the harmonic read of an example
  star; clean-top re-selection; Diffusion Evolution as a lazy consensus step on
  the population graph, with a Dobrushin bound.
- Section 11: noise correlated across a generated batch (normalised sheaf heat
  kernel) preserves every marginal and transmits correlation exactly.
- Section 12: a sheaf-coupled Gaussian target; the denoiser is one implicit
  sheaf heat step; vertical order of horizontal modes; the noised coupling
  schedule and its hard limit; failure of constant coupling.
- Section 13: local reads with records among examples; mosaics are clean fixed
  points; novelty and gluing failure against window width.
- Appendix A: an immutable C# kernel validated line by line against NumPy.

## Rebuild

Python 3.13 with NumPy, SciPy, Matplotlib, python-docx and lxml; Pandoc on
PATH; .NET 8 SDK for the C# kernel; LibreOffice only for the preview PDF.

```bash
python checks.py        # Version 1 checks  -> results.json   (23 checks)
python checks_v2.py     # Version 2 checks  -> results_v2.json (34 checks)
python cs_validate.py   # builds cs/, runs it, recomputes with NumPy -> cs_validate.json
python figures.py       # Figures 1-3
python figures_v2.py    # Figures 4-7
python assemble.py      # src/*.md -> paper_template.md
python populate.py      # fills every number from the three JSON files -> paper.md
python build.py         # Pandoc native Word maths and layout -> output/*.docx
python verify.py        # package and equation-numbering checks -> validation.json
```

All 57 checks pass. Every number in the paper is read from the JSON files.
The Version 1 result file regenerated identically apart from library versions.
No neural network was trained and no comparative generation benchmark was run.
