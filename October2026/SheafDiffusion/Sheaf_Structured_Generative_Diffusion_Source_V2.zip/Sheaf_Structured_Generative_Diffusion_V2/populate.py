"""Fill every @KEY@ in paper_template.md from results.json (V1), results_v2.json and cs_validate.json."""
from pathlib import Path
import json, re
P = Path(__file__).resolve().parent
r = json.loads((P / 'results.json').read_text())
q = json.loads((P / 'results_v2.json').read_text())
v = json.loads((P / 'cs_validate.json').read_text())
s = (P / 'paper_template.md').read_text()


def sci(x):
    if x == 0:
        return '0'
    m, e = f'{x:.2e}'.split('e')
    return '$' + m + r'\times10^{' + str(int(e)) + '}$'


pct = lambda x, d=1: f'{100 * x:.{d}f}%'
f3 = lambda x: f'{x:.3f}'
gl = {w['window']: w for w in q['gluing']['local']}
reach = q['de_reach']['rows']
nv = q['naive_coupling']
conv = {c['steps']: c for c in q['naive_coupling_convergence']}
lim = {int(x['beta']): x['distance_to_projection'] for x in q['coupling_schedule']['limit']}
sm = {x['rho']: x['same_mode'] for x in q['noise_coupling']['same_mode']}

values = {
    'CHECKS': str(r['check_count']), 'V2_CHECKS': str(q['check_count']),
    'TOTAL_CHECKS': str(r['check_count'] + q['check_count']),
    'CROSS_ONE': f"{r['score']['cross_derivatives'][0]:.6f}", 'CROSS_TWO': f"{r['score']['cross_derivatives'][1]:.6f}",
    'CURL': f"{r['score']['naive_score_curl']:.6f}",
    'DDIM_N': f"{r['DDIM']['trials']:,}", 'DDIM_ERR': sci(r['DDIM']['max_relative_identity_error']),
    'NOISE_N': f"{r['noise']['samples_per_scale']:,}", 'PROJ_N': f"{r['projection']['trials']:,}",
    'COMPAT_ERR': sci(r['projection']['max_compatible_corruption_residual']),
    'RISK_VIOL': str(r['projection']['risk_increases']), 'NOISE_ERR': f"{r['noise']['max_relative_MC_error']:.3%}",
    'SQUARE_ERR': sci(r['kernel']['pathwise_commutation_error']), 'GRAD_N': str(r['score']['gradient_trials']),
    'GRAD_ERR': sci(r['score']['max_energy_gradient_identity_error']), 'GAUSS_N': str(r['conditional_Gaussian']['trials']),
    'POST_ERR': sci(r['conditional_Gaussian']['max_posterior_formula_error']),
    'GAUSS_SCORE_ERR': sci(r['conditional_Gaussian']['max_score_denoiser_error']),
    'LOCAL_D': str(r['chain']['local_dimension']), 'GLOBAL_D': str(r['chain']['compatible_dimension']),
    'CONSTRAINT_RANK': str(r['chain']['constraint_rank']), 'HOLONOMY_DIM': str(r['holonomy']['compatible_dimension']),
    'HEAT_GOOD': sci(max(x['valid_spatial_residual_range'] for x in r['heat']['rows'])),
    'HEAT_BAD_MIN': f"{min(x['invalid_spatial_residual_range'] for x in r['heat']['rows']):g}",
    'HEAT_BAD_MAX': f"{max(x['invalid_spatial_residual_range'] for x in r['heat']['rows']):g}",
    # Section 10
    'HARM_ERR': sci(q['harmonic_error']), 'TW_ERR': sci(q['tweedie_error']),
    'RS_N': f"{q['reselection']['samples']:,}", 'RS_STEPS': str(q['reselection']['steps']),
    'RS_SHARE': pct(q['reselection']['share_within_1e-3']), 'RS_TV': f"{q['reselection']['total_variation']:.4f}",
    'DE_N': str(q['de_consensus']['trials']), 'DE_ERR': sci(q['de_consensus']['max_relative_identity_error']),
    'DE_TH_MIN': f"{q['de_consensus']['theta_range'][0]:.4f}", 'DE_TH_MAX': f"{q['de_consensus']['theta_range'][1]:.3f}",
    'DE_VIOL': str(q['de_consensus']['dobrushin_violations']),
    'DE_RATIO': f"{q['de_consensus']['max_diameter_ratio_to_bound']:.6f}",
    'REACH_A0': f"{reach[0]['archive_reach']:.0f}", 'REACH_A1': f"{reach[-1]['archive_reach']:.2f}",
    'REACH_D0': f"{reach[0]['de_reach']:.1f}", 'REACH_DMAX': f"{max(x['de_reach'] for x in reach):.1f}",
    'REACH_D1': f"{reach[-1]['de_reach']:.1f}",
    # Section 11
    'NC_BAD': f3(q['noise_coupling']['unnormalised_marginal_error']),
    'NC_MARG': sci(max(x['marginal_block_difference'] for x in q['noise_coupling']['eta'].values())),
    'NC_CROSS': f"{max(x['max_cross_block'] for x in q['noise_coupling']['eta'].values()):.2f}",
    'NC_TRANSFER': sci(max(q['noise_coupling']['transfer_error'].values())),
    'SM_M1': f"{sm[-1.0]:.3f}", 'SM_09': f"{sm[0.9]:.3f}", 'SM_IND': f"{q['noise_coupling']['independent_same_mode']:.2f}",
    # Section 12
    'SP_RES': sci(q['spectral']['resolvent_error']), 'SP_COMM': sci(q['spectral']['commutation_error']),
    'SP_H0': str(q['spectral']['global_sections']), 'SP_MUMIN': f"{q['spectral']['mu_min_positive']:.3f}",
    'SP_MUMAX': f"{q['spectral']['mu_max']:.2f}",
    'SP_SNRMAX': f"{q['spectral']['p'] + q['spectral']['beta'] * q['spectral']['mu_max']:.1f}",
    'SP_LOGERR': sci(q['spectral']['max_log_snr_error']),
    'KAP_ERR': sci(q['coupling_schedule']['kappa_formula_error']),
    'LIM_10': f"{lim[10]:.3f}", 'LIM_100': f"{lim[100]:.4f}", 'LIM_1000': f"{lim[1000]:.5f}", 'LIM_10000': f"{lim[10000]:.6f}",
    'SAT': f"{q['coupling_schedule']['saturation_value']:.4f}",
    'NV_EXACT0': pct(nv['0.0']['exact_cov_rel_error'], 2), 'NV_EXACT1': pct(nv['1.0']['exact_cov_rel_error'], 2),
    'CONV_250': pct(conv[250]['0.0'], 2), 'CONV_1000': pct(conv[1000]['0.0'], 2), 'CONV_4000': pct(conv[4000]['0.0'], 3),
    'NV_EX0': pct(nv['0.0']['naive_cov_rel_error'], 0), 'NV_GLOB': pct(nv['0.0']['naive_global_variance_ratio'], 1),
    'NV_DIS': pct(nv['0.0']['naive_disagreement_ratio'], 1), 'NV_RAD1': f"{nv['1.0']['naive_max_step_radius']:.1f}",
    # Section 13
    'GL_FIXERR': sci(q['gluing']['mosaic_fixed_point_error']), 'GL_GFIX': str(q['gluing_global_fixed']),
    'GL_F5': str(gl[5]['fixed_points']), 'GL_CG': pct(q['gluing']['global']['share_training_copy']),
    # C#
    'CS_LINES': str(v['lines']), 'CS_MAX': sci(v['max_relative_difference']), 'DOTNET': v['dotnet'],
}
for w in (3, 5, 7, 9):
    g = gl[w]
    values.update({f'GL_M{w}': str(g['mosaics']), f'GL_C{w}': pct(g['share_training_copy']),
                   f'GL_N{w}': pct(g['share_novel_mosaic']), f'GL_U{w}': str(g['distinct_novel']),
                   f'GL_G{w}': pct(1 - g['share_mosaic']), f'GL_D{w}': f"{g['mean_gluing_defect_nonmosaic']:.2f}"})


def short(line):
    head, *nums = line.split()
    nums = [f'{float(x):.6g}'.replace('-', '−') for x in nums]
    body = ', '.join(nums[:3]) + (f', … ({len(nums)} values)' if len(nums) > 3 else '')
    return head.replace('_', ' '), body


values['CS_ROWS'] = '\n'.join(f'| {short(c)[0]} | {short(c)[1]} | {sci(e)} |'
                              for c, e in zip(v['csharp'], v['per_line']))
values['CS_CODE'] = (P / 'cs/ExampleSheaf.cs').read_text().rstrip('\n')
for k, val in values.items():
    assert '@' + k + '@' in s, k
    s = s.replace('@' + k + '@', val)
left = re.findall('@[A-Z][A-Z0-9_]+@', s)
assert not left, left
(P / 'paper.md').write_text(s)
print('Populated paper', len(s.split()), 'words')
