---
title: Sheaf Structured Generative Diffusion
subtitle: Horizontal relations among examples and vertical denoising from ASE back to DDPM and DDIM. Version 2
author:
  - Debi Prasad Ghosh
  - Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India
date: 19 October 2026 · Version 2 · Defensible Intelligence series · “Respect science. Import emotion.”
---

## Abstract

Autoregressive Sheaf Evolution (ASE) replaces whole-record averaging by reads through calibrated partial-observation maps. Its ancestry runs from DDPM and DDIM through Diffusion Evolution (DE) and Autoregressive Diffusion Evolution (ADE). This paper traces that route backwards with one organising rule: the denoising direction is vertical, and the relation among examples is horizontal. Version 1 placed the horizontal structure inside one candidate and set out the probability obligations; those results are retained. Version 2 takes the horizontal axis literally as a sheaf over examples, and proves where it sits in an ordinary diffusion sampler. The exact denoiser of an empirical training set is the harmonic read of an example star, so DDIM with that read is the ADE stack. With a clean top it returns training records at their prior frequencies: in @RS_N@ samples all landed on records, with total-variation error @RS_TV@. A deterministic DE step is exactly a lazy consensus step on the population's kernel graph. The schedule supplies the step and the bandwidth, and a Dobrushin bound controls the population's diameter. For a generated batch, horizontal coupling can be placed in three places with different consequences. Noise correlated across examples by a normalised sheaf heat kernel leaves every example's marginal unchanged, and for Gaussian data it transmits each correlation exactly. Coupling in the target makes the exact denoiser one implicit sheaf heat step across the batch. It resolves the global sections first and the disagreement modes in increasing order of their Laplacian eigenvalues. The exact noised coupling follows a closed-form spectral schedule that fades with noise. A constant coupling instead missed the target covariance by @NV_EX0@ in a deterministic sampler and made a stochastic sampler diverge. Finally, combining a local cover within examples with records among examples makes every gluable family of local records a clean fixed point. Narrow windows therefore generate novel mosaics: in a window-3 toy read they made up @GL_N3@ of the samples. There are @TOTAL_CHECKS@ reproducible checks, and an immutable C# kernel agrees with an independent NumPy implementation. No trained-model generation or optimisation advantage is claimed.

**Keywords:** cellular sheaf; sheaf Laplacian; denoising diffusion; DDPM; DDIM; empirical denoiser; diffusion evolution; correlated noise; memorisation; patch mosaic.

# 1 The reverse journey

The organising proposal is simple: denoising depth is vertical, and relationships among examples or their local descriptions are horizontal. A sheaf records what can be compared at one noise level. A diffusion model specifies how distributions over those representations change with noise. Combining them requires both a geometric construction and a probability model.

The ASE programme began with diffusion models, passed through Diffusion Evolution (DE) and Autoregressive Diffusion Evolution (ADE), and then replaced the single Euclidean read by a sheaf-based read [4, 8–10, 12]. Reversing this route is productive because the DDIM sampler already accepts a predicted clean state. The question becomes which clean-state estimators retain a probabilistic interpretation when their observations are partial and their coordinates are related by restriction maps.

Table: **Table 1.** The reverse journey. Each row keeps the vertical denoising axis and changes what the horizontal axis connects; the last column names the exact link proved in this paper.

| Stage | Horizontal: among examples | Vertical: denoising | Exact link |
|:--|:--|:--|:--|
| ASE | Observation star with partial maps; harmonic read | Layer stack with scale-dependent covers | Read with maps $H_i$ (4.1, 13.1) |
| ADE | Frozen evaluated archive with identity maps | Prescribed autoregressive schedule | DDIM in clean coordinates (3.1) |
| DE | The current population reads itself | DDIM step on a moving archive | Lazy consensus step (10.4) |
| DDIM, empirical | Training set as the leaves of an example star | Exact reverse of a declared corruption | Harmonic read (10.2, 10.3) |
| DDPM, learned | A network approximates the example-star read | Stochastic reverse kernel | Local read and gluing (13.1) |
| Coupled batch | A sheaf on the generated examples | Noise coupling or target coupling | Propositions 11.1, 12.1–12.3 |

Here ADE and ASE refer to the project constructions [8–10, 12], rather than to a claim that those names describe established generative-model families. DE is the method of Zhang and colleagues [4]. The ancestry is conceptual and algebraic; it does not imply that every later optimiser samples the same density as its predecessor.

DDPM defines a Gaussian forward chain and learns a reverse model [1]. DDIM supplies related sampling processes using the same denoising training objective [2]. Score-based formulations make the time-dependent density gradient explicit [3]. Neural Sheaf Diffusion supplies horizontal operators for graph representation learning [5]. The latter use of diffusion is not, by itself, a DDPM reverse-time construction. The 2026 work on deep sheaf networks and sheaf views of attention also concerns relational architectures, not a proof that an arbitrary sheaf read is a generative score [6, 7].

## 1.1 What Version 2 adds

Version 1 used the word *horizontal* mainly for the local views of one candidate: a cover of its coordinates, shared observables on overlaps, and compatibility $\delta X=0$. Sections 2 to 9 keep that material. Version 2 adds the reading the ASE journey actually started from, in which the horizontal axis runs *among examples*. There are two kinds of example, and they must not be confused. *Records* are training examples, archive entries or population members that a read consults. *Generated examples* are the members of a batch being sampled. Section 10 treats records and Sections 11 and 12 treat generated examples. Section 13 combines the records with the local cover of Version 1.

The new results are the following.

- **The example star (Section 10).** The exact empirical denoiser is the harmonic read of a star sheaf whose leaves are the training records. The vertical axis acts only on its edge weights (Theorem 10.2). A clean-top DDIM with this read re-selects records at their prior frequencies (Corollary 10.3). A deterministic DE step is exactly a lazy consensus step on the population's kernel graph, with a Dobrushin bound on the population's diameter (Theorem 10.4).
- **Coupling in the noise (Section 11).** Correlated innovations whose diagonal blocks are identity leave every example's marginal law unchanged. For an affine denoiser they transmit each correlation exactly (Proposition 11.1). A normalised sheaf heat kernel supplies such correlations from any example graph.
- **Coupling in the target (Section 12).** For a sheaf-coupled Gaussian batch, the exact denoiser is one implicit step of sheaf heat flow across the batch (Theorem 12.1). Horizontal modes are resolved in the order of their Laplacian eigenvalues, global sections first (Theorem 12.2). The noised coupling follows a closed-form schedule that fades with noise and saturates for hard constraints (Theorem 12.3). A constant coupling fails.
- **Two horizontals together (Section 13).** With a window cover inside each example and records among examples, every gluable family of local records is a clean fixed point of the local read. Narrow windows therefore produce novel mosaics, while the global read can only return records (Proposition 13.1).
- **Implementation and evidence.** New model families E to H, an algorithm for a coupled batch, an immutable C# kernel validated line by line against NumPy (Appendix A), and @V2_CHECKS@ new checks, giving @TOTAL_CHECKS@ in all.

The contribution of this paper is a set of explicit constructions and obligations connecting these ideas. The elementary linear algebra and Gaussian identities are presented with proofs. Statements marked *new in V2* are, to our knowledge, new in this programme; classical results restated in this notation are marked as such. We make no priority claim for combining geometry and generative modelling, and no empirical claim that the proposed combination improves generation.

# 2 Horizontal data and vertical noise levels

Fix normalised coordinates before defining residuals. A displacement, angle, stress and latent feature cannot share a numerical metric without declared scales. All transposes and orthogonal projections below use these fixed coordinates. A change of coordinates requires the corresponding transformation of observation and vertex metrics.

**Definition 2.1 — A horizontal linear model.** On a fixed finite graph or cover nerve, assign a finite-dimensional data space $F(v)$ to each vertex and a shared-observation space $F(e)$ to each edge. For each incident pair, specify a linear restriction $r_{ve}:F(v)\to F(e)$. Set

$$C^0=\bigoplus_vF(v),\qquad (\delta X)_e=r_{we}X_w-r_{ve}X_v. \tag{1}$$

The compatible assignments form $V=\ker\delta$. On a graph this defines a cellular sheaf without additional face conditions. If higher cells are present, the appropriate restriction composites must agree; adding triangles without their commuting identities does not define the intended cochain complex.

A stalk is a data space. A changing sample is an element of a sequence of such spaces, not itself a stalk. Its specified transport maps or pathwise tangents form a vertical fibre diagram. The index $t$ below is noise level or computational depth, not physical time, anatomical lamina or training iteration.

**Definition 2.2 — An archive observation star.** A query has candidate space $C^0$. Retrieved example $i$ has data $y_i$ in a record space. A common observable is reached through maps $Q_i$ from the candidate and $R_i$ from the record. Its discrepancy is $Q_iX-R_iy_i$. Writing $H_i=Q_i$ and $o_i=R_iy_i$ gives the observation notation used below.

This is how the phrase horizontal among examples can be implemented without equating entire examples. An example contributes only to observables for which its map is meaningful. Examples can disagree, and their weighted boundary data need not extend to a zero-residual section. Forcing every training example to become one global section would erase legitimate variation.

The four project bases remain distinct: the cover base and its nerve describe spatial locality; the context base describes partial-variable incidence; the layer order describes depth; and the observation star describes one retrieval operation. A graph built from neighbouring examples can instantiate a horizontal relational model, but is not automatically an open-cover nerve. The same symbol for two graphs does not establish a comparison map.

![Figure 1. Two horizontal restrictions meet in a shared-observation space at each noise level. Vertical maps must respect both squares to define the indicated linear product structure. The end spaces may be example-associated frames or local views of a candidate. Their values are not required to coincide as complete records.](fig/squares.png){width=100%}

The intrinsic generative construction in Section 7 uses local views of one candidate in $C^0$. Different training examples are different compatible assignments. The archive construction uses examples as fixed leaves of a query-dependent star. These interpretations can be combined, but must not be silently identified.

# 3 DDIM in autoregressive coordinates

Use cumulative signal coefficient $\bar\alpha_t$ and write

$$a_t=\sqrt{\bar\alpha_t},\qquad s_t=\sqrt{1-\bar\alpha_t},\qquad x_t=a_tx_0+s_t\epsilon. \tag{2}$$

Here $a_0=1$, $s_0=0$, and larger $t$ means more noise. For a DDIM step, let $\widehat x_{0,t}$ be the predicted clean state and put

$$\widehat\epsilon_t=\frac{x_t-a_t\widehat x_{0,t}}{s_t},\qquad c_t=\sqrt{s_{t-1}^2-\sigma_t^2}. \tag{3}$$

The sampling update is

$$x_{t-1}=a_{t-1}\widehat x_{0,t}+c_t\widehat\epsilon_t+\sigma_t\xi_t. \tag{4}$$

For the deterministic DDIM choice, $\sigma_t=0$. Stochastic choices require $0\le\sigma_t\le s_{t-1}$. The usual consecutive-step ancestral form is obtained for its corresponding posterior-variance choice; this is not an identity for every learned-variance DDPM variant [1, 2].

**Theorem 3.1 — The DDIM to ADE coordinate identity.** Assume $a_t,a_{t-1},s_t>0$ and define $z_t=x_t/a_t$. For any realised clean prediction $R_t=\widehat x_{0,t}$ and innovation $\xi_t$, (4) is exactly

$$z_{t-1}=(1-\lambda_t)z_t+\lambda_tR_t+\nu_t, \tag{5}$$

with

$$\lambda_t=1-\frac{a_tc_t}{a_{t-1}s_t},\qquad \nu_t=\frac{\sigma_t}{a_{t-1}}\xi_t. \tag{6}$$

If $a_{t-1}\ge a_t>0$, then $0\le\lambda_t\le1$.

*Proof.* Substitute (3) into (4) and divide by $a_{t-1}$. The coefficient of $z_t$ is $a_tc_t/(a_{t-1}s_t)$ and the coefficient of $R_t$ is one minus this quantity. Monotonicity gives $c_t\le s_{t-1}\le s_t$ and $a_t\le a_{t-1}$, so the coefficient lies in $[0,1]$. $\square$

Thus the autoregressive form does not require abandoning a diffusion schedule. It is a clean-coordinate form of the sampler. The identity holds for neural, population, archive and sheaf clean predictions. What changes between these cases is the justification for the prediction, not the algebra of the step.

The transformed observation is $z_t=x_0+r_t\epsilon$ with $r_t=s_t/a_t$. Near a nearly pure-noise endpoint, $r_t$ can be large and the rescaling poorly conditioned. An exactly zero $a_t$ cannot be divided out. Implementations can retain $x$-coordinates near that endpoint and use the theorem where its assumptions hold. The final clean endpoint has $c_t=\sigma_t=0$ and therefore unit read coefficient.

The identity was checked on @DDIM_N@ random steps using matched innovations. The largest relative discrepancy was @DDIM_ERR@. This is a numerical check of a proved identity, not a comparison of sample quality.

## 3.1 What is inherited from diffusion evolution

For a frozen complete-record archive, take positive weights $\pi_i$ and set $p_0=\sum_i\pi_i\delta_{y_i}$ after normalisation. Its Gaussian noised density has posterior weights proportional to $\pi_i\exp[-\|x-a_ty_i\|^2/(2s_t^2)]$. The posterior clean mean is their weighted average. DE uses fitness-derived weights in a population read [4]; ADE changes the evaluated archive and proposal organisation [8].

For generative modelling, empirical weights represent the declared data distribution. Fitness weights instead declare a changed target. An evolving population or adaptively replaced archive changes that target again. A Gaussian-looking read at each step does not make an adaptive optimiser the reverse of one fixed forward process.

Section 10 makes this inheritance exact: the posterior read is the harmonic read of an example star, and a deterministic DE step is a consensus step on the population graph (Theorem 10.4). For complete observations, the clean mean remains in the convex hull of archive records. A partial-observation sheaf read can leave that hull, but then it is not the posterior mean of this same finite complete-record mixture. Compositional generation requires an enlarged or differently factorised clean distribution. Hull escape is a construction property, not proof of fidelity or novelty.

# 4 The harmonic read and the score obstruction

Freeze a horizontal model, observation maps $H_i$, records $o_i$, positive metrics $\Lambda_i,W$, and prior weights $\pi_i>0$. At a fixed noise variance parameter $\tau>0$, define

$$e_i(z)=\tfrac12\|H_iz-o_i\|_{\Lambda_i}^2,\qquad \omega_i(z)=\frac{\pi_i e^{-e_i(z)/\tau}}{\sum_j\pi_j e^{-e_j(z)/\tau}}. \tag{7}$$

These are retrieval affinities. Different observation dimensions and metrics require their own likelihood normalisers in a probabilistic model; the displayed affinities do not supply that model merely by being positive.

For a query $z$, a fixed anchor $q$, $P\succeq0$ and $\beta\ge0$, minimise

$$Q(u\mid z)=\tfrac12\|u-q\|_P^2+\tfrac\beta2\|\delta u\|_W^2+\sum_i\omega_i(z)e_i(u). \tag{8}$$

Put $A(z)=P+\beta\delta^\top W\delta+\sum_i\omega_i(z)H_i^\top\Lambda_iH_i$ and $b(z)=Pq+\sum_i\omega_i(z)H_i^\top\Lambda_io_i$. If $A(z)\succ0$, its unique minimiser is $R(z)=A(z)^{-1}b(z)$. Solve the system rather than form an inverse. If observability fails, report the nullspace and specify retention or regularisation; a numerical cutoff is a separate policy [10, 11].

**Proposition 4.1 — Precision weighted displacement is an energy gradient.** Set

$$E_\tau(z)=\tfrac12\|z-q\|_P^2+\tfrac\beta2\|\delta z\|_W^2-\tau\log\sum_i\pi_i e^{-e_i(z)/\tau}. \tag{9}$$

Then

$$\nabla E_\tau(z)=A(z)(z-R(z)). \tag{10}$$

If $P\succ0$ and $\kappa>0$, the density $p(z)\propto\exp[-E_\tau(z)/\kappa]$ is normalisable and has score $A(z)(R(z)-z)/\kappa$.

*Proof.* Differentiating the soft minimum gives $\sum_i\omega_i\nabla e_i$. Adding the prior and compatibility derivatives gives $Az-b$. Since $e_i\ge0$, the soft-minimum term is bounded below by $-\tau\log\sum_i\pi_i$. The positive definite prior therefore supplies an integrable Gaussian upper bound on $\exp[-E_\tau/\kappa]$. Differentiating its log density gives the score. $\square$

The temperature $\kappa$ is declared separately from the observation parameter $\tau$. In particular, choosing $\kappa=\tau$ does not establish forward-process consistency. A fixed anchor is part of this density; re-anchoring at each query changes the specification and requires a separate analysis [11].

**Proposition 4.2 — A harmonic displacement need not be a score.** In two coordinates $(x,y)$, use observations $H_1=(1,0)$ with value 0, $H_2=(0,1)$ with value 0, and $H_3=I$ with value $(1,2)$. Let $\pi_i=1$, $\tau=1$, $P=0$ and $\beta=0$. The read is

$$\begin{aligned}R_1&=\frac1{1+e^{A}},\qquad R_2=\frac2{1+e^{B}},\\ A&=-x+\tfrac12+\tfrac12(y-2)^2,\qquad B=\tfrac12(x-1)^2-2y+2.\end{aligned} \tag{11}$$

The vector field $R(z)-z$ is not the score of a positive $C^2$ density on a neighbourhood of $(0.3,0.7)$.

*Proof.* At that point $A=1.045$ and $B=0.845$. Write $f(u)=e^u/(1+e^u)^2=1/(2+2\cosh u)$. Then $\partial_yR_1=1.3f(1.045)$ and $\partial_xR_2=1.4f(0.845)$. Since $f$ decreases strictly for positive arguments, the latter is larger. Subtracting the identity field leaves these cross derivatives unchanged. A $C^2$ log density has equal mixed partial derivatives, giving a contradiction. $\square$

The computed cross derivatives are @CROSS_ONE@ and @CROSS_TWO@, a difference of @CURL@. Adding a proper prior makes the energy density in Proposition 4.1 legitimate, but does not justify discarding its precision factor. A general ASE update can be a useful preconditioned descent or proposal step while failing the stronger score interpretation.

For comparison, a complete-record Gaussian mixture obeys

$$\nabla_x\log p_t(x)=\frac{a_tm_t(x)-x}{s_t^2},\qquad m_t(x)=\mathbb E[X_0\mid X_t=x]. \tag{12}$$

This follows by differentiating each Gaussian component and collecting posterior weights. It explains the ordinary read identity, but does not extend unchanged to arbitrary partial maps. Curl-free behaviour is only a local integrability requirement; a global potential must also yield a normalisable density.

# 5 Consistency across noise levels

Even a valid score at every level is insufficient. Rescaled Gaussian noising gives $Z_\tau=X_0+\sqrt\tau\epsilon$, where $\tau=(s_t/a_t)^2$. Its marginal density is the Gaussian convolution of one initial density and satisfies the heat equation. This is a marginal statement; DDIM can realise a different coupling between times while using these same marginals [2, 3].

**Theorem 5.1 — A heat consistency criterion for sheaf energies.** Let $p_\tau(z)=Z_\tau^{-1}\exp[-\Psi_\tau(z)]$ be positive and normalised on $\mathbb R^r$. Assume the regularity and decay needed to differentiate its integral, apply the Laplacian and integrate the Laplacian to zero. Then $\partial_\tau p_\tau=\tfrac12\Delta p_\tau$ if and only if

$$\partial_\tau\Psi_\tau-\tfrac12\Delta\Psi_\tau+\tfrac12\|\nabla\Psi_\tau\|^2=c(\tau) \tag{13}$$

is spatially constant. For the energy density in Section 4 use $\Psi_\tau=E_\tau/\kappa_\tau$, including all parameter derivatives.

*Proof.* Division by $p_\tau$ gives $\partial_\tau p_\tau/p_\tau=-\partial_\tau\Psi_\tau-\partial_\tau\log Z_\tau$ and $\Delta p_\tau/p_\tau=-\Delta\Psi_\tau+\|\nabla\Psi_\tau\|^2$. Equality yields (13), with $c=-\partial_\tau\log Z_\tau$. Conversely, if the residual is spatially constant, the same calculation makes $\partial_\tau p_\tau-\tfrac12\Delta p_\tau$ a scalar multiple of $p_\tau$. Integrating and using the assumptions makes that scalar zero. $\square$

This criterion is useful because a separate energy fit at every scale can satisfy local compatibility and still violate the probability evolution required by the sampler. Its converse establishes the heat PDE under the stated conditions; matching a particular data model additionally requires its initial condition and the appropriate uniqueness assumptions. Checking a finite spatial grid cannot certify the PDE globally.

**Example 5.2 — Proper densities with incompatible time evolution.** Let $\Psi_\tau(z)=h(\tau)z^2/2$ with $h>0$. The residual is

$$\tfrac12(h'+h^2)z^2-\tfrac12h. \tag{14}$$

It is spatially constant exactly when $h'=-h^2$. The choice $h=1/(v_0+\tau)$ produces variance $v_0+\tau$, as Gaussian convolution requires. The choice $h=1+\tau$ also gives a proper Gaussian at every level, but its variance decreases as noise time increases. It fails (13).

![Figure 2. A valid Gaussian heat family increases its variance with noise time. A separately normalisable Gaussian family with increasing precision does the opposite. Both have valid scores at each level; only the first has the stated forward Gaussian evolution. The right panel shows the spatial range of the residual in Theorem 5.1 on the declared interval.](fig/heat.png){width=100%}

The criterion applies to intrinsic coordinates as well as ambient ones. For anisotropic constant covariance, the Laplacian and squared gradient are replaced by their covariance-weighted versions. Changing covariance, geometry or charts requires the corresponding forward generator, not an unmodified Euclidean heat equation. Score-SDE theory similarly ties the reverse drift to the marginals of a specified forward process [3].

# 6 Ambient corruption of compatible clean data

Suppose the clean distribution is supported on $V=\ker\delta$, but use full-dimensional noise. This produces a standard ambient forward diffusion whose clean data happen to satisfy linear constraints.

**Theorem 6.1 — Expected horizontal disagreement under corruption.** For deterministic $X_0$ with $\delta X_0=0$ and $X_t=a_tX_0+s_t\epsilon$, $\epsilon\sim\mathcal N(0,I_D)$,

$$\mathbb E\|\delta X_t\|_W^2=s_t^2\operatorname{tr}(W\delta\delta^\top). \tag{15}$$

*Proof.* The residual is $s_t\delta\epsilon$. Its second moment follows from $\mathbb E\epsilon\epsilon^\top=I_D$. $\square$

Independent corruption can therefore break exact horizontal agreement at intermediate layers without invalidating the model. A residual threshold should account for noise scale and metric. In particular, forcing every noisy representation to have zero residual would change this forward process. A clean-prediction loss can be appropriate even when a zero-residual noisy-state loss is not.

Let $U$ have orthonormal columns spanning $V$, and write $\Pi=UU^\top$.

**Proposition 6.2 — Projection improves compatible clean prediction.** For every clean $X_0\in V$ and arbitrary estimate $\widehat X$,

$$\|\widehat X-X_0\|^2=\|\Pi\widehat X-X_0\|^2+\|(I-\Pi)\widehat X\|^2. \tag{16}$$

Consequently, projecting a clean estimate cannot increase its squared reconstruction loss. Whenever defined, the Bayes clean mean $\mathbb E[X_0\mid X_t]$ already lies in $V$.

*Proof.* The two errors are orthogonal. Conditional expectation preserves the linear constraint because $\delta\mathbb E[X_0\mid X_t]=\mathbb E[\delta X_0\mid X_t]=0$. $\square$

This is a reconstruction statement in the declared norm, not a theorem about likelihood, perceptual quality or a misspecified constraint. A false compatibility law can project away real information. Projecting the clean prediction also does not force the entire noisy trajectory into $V$: DDIM's remaining noise component may lie outside it until the clean endpoint.

An ambient implementation trains a denoiser on correctly corrupted examples and returns a compatible clean estimate, for example $U g_\theta(X_t,t)$. The noise prediction is then reconstructed from (3). Training an unrestricted noise predictor and adding a clean-compatibility penalty is another option, but its finite-weight output need not satisfy the law exactly.

# 7 Intrinsic diffusion on compatible sections

Assume a fixed linear compatibility model with $r=\dim V>0$. Every compatible clean state is $X_0=Uh_0$. Define an ordinary DDPM forward chain in $\mathbb R^r$:

$$q(h_t\mid h_{t-1})=\mathcal N(\sqrt{1-b_t}\,h_{t-1},b_tI_r),\qquad 0<b_t<1. \tag{17}$$

Lift the chain through $X_t=Uh_t$. The induced clean distribution is the specified distribution of $h_0$ mapped into $C^0$.

**Theorem 7.1 — Compatibility of intrinsic DDPM and DDIM.** Every forward state of (17) lies in $V$. Every DDPM or DDIM reverse state constructed in intrinsic coordinates and lifted through $U$ also lies in $V$, for every realised innovation and every denoiser output in $\mathbb R^r$.

*Proof.* All such states are of the form $Uh$, and $\delta U=0$. $\square$

The compatibility claim is exact. It does not say that a learned reverse chain samples the true clean distribution exactly. Model error, finite-step approximation and endpoint mismatch remain. Sampling from a standard Gaussian at a finite terminal level is the usual approximation unless the terminal marginal is exactly that Gaussian.

A standard intrinsic noise-prediction objective is

$$\mathcal L(\theta)=\mathbb E\left\|\epsilon-\epsilon_\theta(a_th_0+s_t\epsilon,t)\right\|^2. \tag{18}$$

Horizontal sheaf layers can be used inside $\epsilon_\theta$, but enforcing the output representation $X=Uh$ does not require materialising a dense projector. Sparse elimination, local shared-variable assembly or a factorised parameterisation can avoid that cost. The representation and its storage count must be included in a fair comparison.

For $V=\mathbb R^D$ and $U=I$, this is ordinary diffusion. For a nontrivial $V$, densities and scores are defined relative to the intrinsic volume on $V$, not ambient Lebesgue measure. If $s_h$ is the intrinsic score, $Us_h$ is its tangent representation in $C^0$. There is no full-dimensional log density of the singular lifted law to differentiate in every ambient direction.

## 7.1 The covariance required by horizontal compatibility

**Theorem 7.2 — Compatible Gaussian noise.** Let a candidate's innovation be $G\epsilon$ with standard Gaussian $\epsilon$. Then $\delta G\epsilon=0$ almost surely if and only if $\delta G=0$. Its covariance is supported on $V$ and has rank at most $r$.

*Proof.* The expected squared residual equals $\|\delta G\|_F^2$. It vanishes exactly when $\delta G=0$. Then the image of $G$ lies in $V$, giving the support and rank statements. $\square$

If $\delta\ne0$, full-rank ambient independent noise cannot simultaneously satisfy exact compatibility. Intrinsic isotropic noise has covariance $UU^\top$, so individual local coordinates need not each have variance one. To match other local covariance conventions, use $G=US^{1/2}$ with a specified $S\succeq0$. Feasibility of desired local covariances is an additional constraint, not a consequence of having a basis.

**Proposition 7.3 — Gaussian kernels commute with restrictions in law.** For a linear restriction $R$, source corruption $Y=ax+\zeta$ with $\zeta\sim\mathcal N(0,Q)$, and Gaussian target corruption with mean $aRx$ and covariance $Q_e$, restriction and corruption have the same distribution for all $x$ if and only if $Q_e=RQR^\top$.

*Proof.* The pushed-forward Gaussian has mean $aRx$ and covariance $RQR^\top$. Gaussian laws agree exactly when these quantities agree. $\square$

A common underlying innovation gives a pathwise coupling by using $R\zeta$ at the target. Independently drawn source and target noises can obey the same marginal law without making the realised square commute. For nonisometric restrictions, assigning identity covariance at both ends usually fails even in law.

![Figure 3. Independent ambient noise creates the residual predicted by Theorem 6.1. Correlated noise obtained from the compatible projector has residual at numerical roundoff. Each point uses the same declared chain model and @NOISE_N@ Gaussian innovations; the analytic ambient curve is not fitted to the observations.](fig/noise.png){width=92%}

## 7.2 Holonomy can obstruct a nondegenerate noise model

Consider scalar restrictions around a cycle requiring $x_2=x_1$, $x_3=x_2$ and $x_1=-x_3$. The only compatible state is zero. Its coboundary is

$$\delta X=(-x_1+x_2,\,-x_2+x_3,\,x_1+x_3)^\top,\qquad \det\delta=2. \tag{19}$$

Thus an everywhere-compatible scalar Gaussian has zero covariance. In a higher-dimensional orthogonal local system, compatible values are restricted by the common fixed subspace of cycle holonomies. A nontrivial sheaf can reduce the available noise and data dimensions so far that a proposed generative model becomes useless. The target representation must have enough compatible degrees of freedom for the intended task.

This is a concrete constraint on the horizontal design. Compatibility is not always a harmless regulariser, and nontrivial holonomy is not automatically a benefit. Different generated candidates use independent intrinsic innovations by default. Correlation is required between local views within a candidate. Correlation between separate samples of a batch is optional, and Section 11 shows exactly when it leaves each sample's law unchanged.

# 8 Condition first and diffuse second

A tractable probabilistic bridge is to specify the clean conditional model before noising it. This also separates two meanings of examples. Multiple observations of one latent object can enter a likelihood product; unrelated training examples usually define a population distribution instead. Treating the latter as simultaneous measurements of one object changes the modelling assumption.

Let $h$ have proper prior $\mathcal N(\mu_0,C_0)$, with $C_0\succ0$, and conditionally independent observations $o_i=B_ih+\eta_i$, $\eta_i\sim\mathcal N(0,N_i)$ with $N_i\succ0$. For local sheaf data take $B_i=H_iU$. Collecting the observations gives $o=Bh+\eta$ with block-diagonal covariance $N$.

**Theorem 8.1 — A harmonic posterior with consistent noised marginals.** The clean posterior is Gaussian with

$$C^{-1}=C_0^{-1}+B^\top N^{-1}B,\qquad m=C(C_0^{-1}\mu_0+B^\top N^{-1}o). \tag{20}$$

Its noised marginal under $h_t=a_th+s_t\epsilon$ is $\mathcal N(a_tm,S_t)$ with $S_t=a_t^2C+s_t^2I$. Its conditional clean mean and score are

$$\widehat h_0=m+a_tC S_t^{-1}(h_t-a_tm), \tag{21}$$

$$\nabla\log p_t(h_t)=-S_t^{-1}(h_t-a_tm)=\frac{a_t\widehat h_0-h_t}{s_t^2}. \tag{22}$$

*Proof.* Completing the square gives (20), which is also the minimiser of the prior-plus-observation quadratic. Gaussian convolution gives $S_t$. Gaussian conditioning gives (21). Since $a_t^2C=S_t-s_t^2I$, substitution proves the second equality in (22); differentiation gives the first. $\square$

This construction has a valid prior, a likelihood, a harmonic clean posterior, consistent forward marginals and an analytic score. It can be lifted through $U$ to produce compatible samples. It is a useful reference model against which a learned implementation can be checked. Its exact Gaussian reverse conditional can also be sampled directly; a finite DDPM implementation must still choose and approximate its reverse kernels appropriately.

Query-dependent attention weights in Section 4 are not automatically the fixed observation precisions in (20). If the model introduces latent source selection, uncertain maps or mixtures, integrate those variables or define a corresponding joint model. A weighted least-squares solver is a posterior mean only under the declared probabilistic assumptions. Missing observation patterns must also carry an explicit missingness assumption when their selection is informative.

For genuinely distinct examples, a compositional clean model can instead factor over local contexts, with calibrated factors and a proper global prior. Noising that joint model yields a legitimate generative target. Learning its factors from incomplete examples can be nonidentifiable; overlap agreement alone does not recover omitted cross-context dependencies. The worked counterexample in ASE, where shared $b$ agrees while a hidden equality $a=c$ is violated, remains relevant [10, 11].

# 9 Vertical algebra and stochastic maps

The horizontal model at each level may have different coefficients or a different base. On a fixed base, a collection of linear vertical maps $V_t^v:F_t(v)\to F_{t-1}(v)$ is a sheaf morphism only when

$$r_{ve}^{t-1}V_t^v=V_t^e r_{ve}^{t}. \tag{23}$$

Both squares in Figure 1 must commute. If bases change by $\Phi_t:X_t\to X_{t-1}$, the typed comparison is

$$\varphi_t:F_t\longrightarrow\Phi_t^{-1}F_{t-1},\qquad (\Phi_t^{-1}F_{t-1})_x=(F_{t-1})_{\Phi_t(x)}. \tag{24}$$

A nonlinear global denoiser need not decompose into nodewise maps satisfying (23). Horizontal message passing can use neighbouring data in ways that prevent a strictly local restriction-compatible map. A regulariser that measures square defects is a test or approximation, not an identity. Product-sheaf language is justified only for a specified construction satisfying the required conditions.

There are three useful vertical objects. First, the full DDPM step is a Markov kernel between noise levels. Its pushforward is linear on measures, generally an infinite-dimensional setting. Second, conditioning on realised innovations gives a deterministic state trajectory, usually nonlinear. Third, differentiating a smooth realised trajectory gives a finite-dimensional tangent diagram. These objects have different algebraic and probabilistic meanings.

Barcodes can summarise a declared finite-dimensional linear diagram. They do not automatically apply to the full nonlinear Markov kernel, nor do they determine the generated density. Nearly singular tangents can retain exact algebraic rank while numerical sensitivity contracts. Effective-rank thresholds, singular values and the conditioning of the $x/a_t$ rescaling should be reported alongside any barcode [9, 10].

Part I's vertical acyclicity statement is a theorem about a specified product construction with a least layer [9]. It is not a substitute for score or heat-flow consistency. A generative model can have the same horizontal cohomology at every layer and still use an incorrect reverse drift. Changing covers and zigzag comparisons require their own maps; topology alone cannot validate the sampler.


# 10 The example sheaf: a read among examples

This section takes the horizontal axis to run among records. Fix a finite set of records $y_1,\ldots,y_n\in\mathbb{R}^D$ with prior weights $\pi_i>0$ summing to one, and the variance-preserving schedule (2). Write $\sigma_t=s_t/a_t$ for the noise scale in clean coordinates.

**Definition 10.1 — The example star at level $t$.** The base is a star graph. Its centre $q$ is the state being denoised, and its leaves $1,\ldots,n$ are the records. Every stalk and edge stalk is $\mathbb{R}^D$. The restriction maps are identities for complete records, or the maps $H_i$ of Definition 2.2 for partial ones. The leaf values are the records, and edge $i$ carries the weight $\omega_i(x,t)$ defined below. The records do not change with $t$. The vertical axis acts on this horizontal sheaf only through its edge weights.

**Theorem 10.2 — The exact empirical denoiser is the harmonic read of the example star (classical, restated).** Let $p_0=\sum_i\pi_i\delta_{y_i}$ and $x_t=a_tx_0+s_t\epsilon$. At $x_t=x$ put

$$\omega_i(x,t)=\frac{\pi_i\exp(-\|x-a_ty_i\|^2/(2s_t^2))}{\sum_j\pi_j\exp(-\|x-a_ty_j\|^2/(2s_t^2))}. \tag{25}$$

Then the posterior mean is the minimiser of the star's weighted disagreement,

$$m_t(x)=\sum_i\omega_i(x,t)\,y_i=\arg\min_r\sum_i\omega_i(x,t)\|r-y_i\|^2, \tag{26}$$

and the score is $(a_tm_t(x)-x)/s_t^2$, as in (12). In clean coordinates $z=x/a_t$ the exponent is $-\|z-y_i\|^2/(2\sigma_t^2)$. Hence DDIM with the exact empirical denoiser is the ADE stack with identity maps, prior weights $\pi_i$ and read scale $\sigma_t$ (Theorem 3.1).

*Proof.* Bayes' rule gives the posterior weights (25), and the posterior mean is their average. The normal equations of the weighted least-squares problem are $(\sum_i\omega_i)r=\sum_i\omega_iy_i$, which give (26). The score identity is (12). Dividing the exponent by $a_t^2$ gives the clean-coordinate form. $\square$

The theorem is the identity-map special case of the harmonic read (8) with $P=0$ and $\beta=0$. With partial maps $H_i$ the same star gives the read $A^{-1}b$ of Section 4, which is no longer a posterior mean of this mixture (Proposition 4.2). So the reverse journey has a precise meaning. An ASE layer is a sheaf read among records. ADE freezes the records and uses identity maps. Uniform weights on a training set give the exact DDIM denoiser. A trained DDPM network is an approximation to that read. The checks confirm the harmonic form to @HARM_ERR@ and the score identity to @TW_ERR@.

**Corollary 10.3 — Clean-top re-selection (Part III, transferred).** If deterministic DDIM uses the exact read (26) and ends at $a_0=1$, its continuum limit returns record $y_i$ with probability $\pi_i$. This is Proposition 3.6 of Part III [12], transferred through Theorem 10.2.

A run of @RS_STEPS@ cosine-schedule steps from @RS_N@ standard normal starts tested this. The run used five records with weights 0.35, 0.25, 0.20, 0.12 and 0.08. @RS_SHARE@ of the outputs lay within $10^{-3}$ of a record. Their frequencies differed from the prior weights by total variation @RS_TV@. An exact example-sheaf diffusion therefore memorises, which agrees with the memorisation literature [15]. Any generalisation must come from the ways a trained denoiser *fails* to reproduce (26). Section 13 makes one such failure exact.

**Theorem 10.4 — Diffusion Evolution is a lazy consensus step on the population graph (new in V2).** DE [4] uses its current population $X_t=(x^{(1)},\ldots,x^{(n)})$ as the records. Each member reads the whole population with fitness weights $g(f(x^{(k)}))$, so that $m^{(j)}=\sum_kW_{jk}x^{(k)}$ with

$$W_{jk}=\frac{g(f(x^{(k)}))\exp(-\|x^{(j)}-a_tx^{(k)}\|^2/(2s_t^2))}{\sum_lg(f(x^{(l)}))\exp(-\|x^{(j)}-a_tx^{(l)}\|^2/(2s_t^2))}. \tag{27}$$

With $\sigma_t=0$ in (4), the population moves exactly by

$$X_{t-1}=r_t\left[(1-\theta_t)I+\theta_tW_t\right]X_t, \tag{28}$$

$$r_t=\frac{c_t}{s_t}+a_{t-1}-\frac{a_tc_t}{s_t},\qquad \theta_t=\frac{1}{r_t}\left(a_{t-1}-\frac{a_tc_t}{s_t}\right)\in[0,1]. \tag{29}$$

The matrix $P_t=(1-\theta_t)I+\theta_tW_t$ is row-stochastic. For any norm, the population diameter therefore obeys

$$\text{diam}(X_{t-1})\le r_t\,\tau(P_t)\,\text{diam}(X_t),\qquad \tau(P)=\frac{1}{2}\max_{j,j'}\sum_k|P_{jk}-P_{j'k}|. \tag{30}$$

*Proof.* Substituting $\widehat\epsilon=(x-a_tm)/s_t$ into (4) gives $x'=(c_t/s_t)x+(a_{t-1}-a_tc_t/s_t)m$, whose coefficients sum to $r_t$. Monotonicity gives $c_t\le s_{t-1}\le s_t$ and $a_t\le a_{t-1}$. Both coefficients are therefore non-negative, so $\theta_t\in[0,1]$. For rows $j,j'$ the difference $(PX)_j-(PX)_{j'}=\sum_k(P_{jk}-P_{j'k})x^{(k)}$ has coefficients summing to zero. Their positive and negative parts each have mass $\frac12\sum_k|P_{jk}-P_{j'k}|\le\tau(P)$, and each part is that mass times a convex combination of members. The difference of two convex combinations is at most the diameter, which gives (30). This is the Dobrushin contraction argument [16]. $\square$

The theorem makes the two axes literal. Horizontally, $I-W_t$ is the random-walk Laplacian of the constant sheaf $\mathbb{R}^D$ on a weighted graph over the population, whose edges are kernel affinities tilted by fitness. Vertically, the schedule supplies the step $\theta_t$, the overall scale $r_t$ and the kernel bandwidth $\sigma_t$. A deterministic DE run is a forward-Euler sheaf diffusion among examples whose graph sharpens as noise falls. Replacing $W_tX_t$ by the harmonic read with maps $H_i$ turns the step into the ASE sheaf diffusion of Part II [10]. DE also treats its noisy members as clean records. That is why its target moves from step to step (Section 3.1).

The identity (28) was checked on @DE_N@ random steps to a largest relative error of @DE_ERR@. Over these steps $\theta_t$ ranged from @DE_TH_MIN@ to @DE_TH_MAX@, and the bound (30) had @DE_VIOL@ violations. The largest ratio of observed diameter to bound was @DE_RATIO@, so the bound is attained.

![Figure 4. Reads among examples. (a)–(c) A stochastic DE population of 256 members on a four-peak fitness (orange crosses) at three noise scales $s_t/a_t$. Lines join each plotted member to its strongest reads, the edges of the kernel graph $W_t$ in (27). The graph is nearly complete at high noise and splits into niches as the noise falls. (d) Horizontal reach, the effective number of records one read uses, $1/\sum_kW_{jk}^2$, averaged over members. With a fixed archive of 256 records the reach falls from @REACH_A0@ to @REACH_A1@. In DE the fitness weights already concentrate the read at high noise: the reach starts at @REACH_D0@, peaks at @REACH_DMAX@ and ends at @REACH_D1@.](fig/reach.png){width=100%}

The horizontal reach in Figure 4 summarises how the vertical axis reshapes the horizontal graph. At high noise one read averages almost the whole archive. At the clean end it reads about one record. A schedule designer can therefore read off, at each level, how many examples influence a state, which is the among-example analogue of the receptive field.

# 11 Coupling generated examples in the noise

Now let the horizontal axis connect the *generated* examples $x^1,\ldots,x^N\in\mathbb{R}^d$ of one batch. Put a cellular sheaf on a graph over the batch, with stalks $\mathbb{R}^d$, edge stalks $\mathbb{R}^{d_e}$ and restriction maps. Its coboundary $\delta$ and sheaf Laplacian $L=\delta^\top W\delta$ act on the stacked batch $X\in\mathbb{R}^{Nd}$ [5, 17]. Version 1 noted that separate candidates normally use independent innovations. That is the default, not a requirement. There are three places a horizontal coupling across the batch can enter: the noise (this section), the target (Section 12) and the read (Section 13). They have different consequences.

**Proposition 11.1 — Marginal-preserving horizontal noise (new in V2).** Run $N$ copies of a DDPM or DDIM sampler (4). Each copy uses the same per-example denoiser, and the clean prediction for $x^j$ depends on $x^j$ alone. Let the terminal draw and the innovations of each step be jointly Gaussian on $\mathbb{R}^{Nd}$ with covariance $K$, independent across steps. If every diagonal block is $K_{jj}=I_d$, then each example's path has exactly the law of the independent sampler. If, in addition, the denoiser is affine and $K=R\otimes I_d$ with correlations $\rho_{jk}$, then

$$\text{Cov}(x_0^j,x_0^k)=\rho_{jk}\,\text{Var}(x_0^j). \tag{31}$$

*Proof.* The path of copy $j$ is a fixed measurable function of its own terminal draw and innovations. These are jointly Gaussian with zero mean, identity covariance and independence across steps, exactly as in the independent sampler. For an affine denoiser, $x_0^j=b+\sum_tM_t\xi_t^j$ with common matrices $M_t$. Hence $\text{Cov}(x_0^j,x_0^k)=\sum_tM_t\rho_{jk}M_t^\top=\rho_{jk}\text{Var}(x_0^j)$. $\square$

Any example graph supplies admissible correlations through a normalised sheaf heat kernel,

$$K=B^{-1/2}e^{-\tau L}B^{-1/2},\qquad B=\text{blockdiag}_j\left(e^{-\tau L}\right)_{jj}. \tag{32}$$

$K$ is positive semidefinite with identity diagonal blocks, and its off-diagonal blocks decay with sheaf distance. The normalisation is essential. The raw kernel $e^{-\tau L}$ changes the marginals: in the check its per-example covariance error was @NC_BAD@.

The checks used a six-example sheaf with stalk dimension 3, seven edges and random $2\times3$ restriction maps, with $\tau=0.6$. For Gaussian data and the exact affine denoiser, the per-example covariance was propagated exactly through 400 steps. With $K$ from (32), each diagonal block matched the independent sampler to @NC_MARG@ for both $\eta=0$ and $\eta=1$. The off-diagonal blocks were as large as @NC_CROSS@. For a scalar correlation $\rho=0.6$, (31) held to @NC_TRANSFER@.

![Figure 5. Coupling in the noise. (a) Spectral norms of the blocks of the normalised sheaf heat kernel (32) on the six-example test sheaf; the diagonal blocks are exactly the identity. (b) Pairs of deterministic DDIM samples from a symmetric four-mode mixture, with noise draws correlated by $\rho$; 6,000 pairs per value. Each sample is marginally exact, yet the probability that both reach the same mode moves from @SM_M1@ at $\rho=-1$ to @SM_09@ at $\rho=0.9$. Independent pairs give @SM_IND@.](fig/noisecoupling.png){width=100%}

For non-Gaussian data the correlation of outputs is a nonlinear function of $\rho$, but the marginals remain exact. In Figure 5, antithetic noise ($\rho=-1$) never sends a pair to the same mode. That result is exact for this example: the mixture is symmetric under $x\mapsto-x$, and deterministic DDIM inherits the symmetry. Noise coupling is therefore a way to control the diversity of a batch at no cost to fidelity. Particle guidance [14] also produces non-independent batches, but by adding a joint potential to the dynamics. Proposition 11.1 identifies a narrower operation that leaves every marginal untouched. Noise coupling does not make outputs compatible: $\delta X_0\ne0$ in general. Compatibility of outputs requires coupling in the target.

# 12 Coupling generated examples in the target

Suppose instead that the batch is meant to be a coupled object, such as a family of designs that must agree on shared interfaces. Declare the clean joint prior

$$p_0(X)\propto\prod_j\mathcal{N}(x^j;m_0,p^{-1}I_d)\,\exp\left(-\frac{\beta}{2}\|\delta X\|_W^2\right), \tag{33}$$

a Gaussian with precision $\Lambda=pI+\beta L$, covariance $C=\Lambda^{-1}$ and mean $\mu=pC(\mathbf{1}\otimes m_0)$. This changes the target: unlike Section 11, the marginals of individual examples change. The forward noise is independent across examples, as in ordinary diffusion. Following Section 8, condition first and diffuse second.

**Theorem 12.1 — The coupled denoiser is one implicit sheaf heat step (new in V2).** For the target (33),

$$D_t(X)=\mu+\frac{a_t}{a_t^2+ps_t^2}\,(I+h_tL)^{-1}(X-a_t\mu),\qquad h_t=\frac{\beta s_t^2}{a_t^2+ps_t^2}. \tag{34}$$

Consequently, $D_t$ commutes with every function of $L$, including horizontal heat flow $e^{-\tau L}$. It leaves directions in $\ker L$, the global sections, unsmoothed.

*Proof.* By (21), $D_t(X)=\mu+a_tCS_t^{-1}(X-a_t\mu)$ with $S_t=a_t^2C+s_t^2I$. Since $CS_t^{-1}=(a_t^2I+s_t^2\Lambda)^{-1}=((a_t^2+ps_t^2)I+\beta s_t^2L)^{-1}$, factoring out $a_t^2+ps_t^2$ gives (34). $\square$

Every vertical denoising step thus performs one backward-Euler step of horizontal sheaf diffusion, with a step $h_t$ that grows from zero at the clean end to $\beta/p$ in pure noise. This is the exact sense in which, for this model, "vertical = denoising" and "horizontal = diffusion among examples" are two factors of a single operator. The checks confirm (34) to @SP_RES@ and the commutation with $e^{-0.3L}$ to @SP_COMM@.

**Theorem 12.2 — Vertical order of horizontal modes (new in V2).** Let $Lu_k=\mu_ku_k$ with orthonormal $u_k$. The share of the clean variance of mode $k$ that the denoiser has resolved at level $t$ is

$$\varrho_k(t)=\frac{a_t^2c_k}{a_t^2c_k+s_t^2}=\frac{a_t^2}{a_t^2+s_t^2(p+\beta\mu_k)},\qquad c_k=\frac{1}{p+\beta\mu_k}. \tag{35}$$

It crosses one half at signal-to-noise ratio $a_t^2/s_t^2=p+\beta\mu_k$. The global sections ($\mu_k=0$) are resolved first, at ratio $p$. The disagreement modes are resolved later, in increasing order of $\mu_k$.

*Proof.* $C$, $S_t$ and $D_t$ are diagonal in the basis $u_k$. The mode variance is $c_k$, and the resolved share of a scalar Gaussian observed at signal $a_t$ and noise $s_t$ is $a_t^2c_k/(a_t^2c_k+s_t^2)$. $\square$

The vertical axis therefore sorts the horizontal spectrum. A coupled batch is first decided as a consensus, and only later as a set of differences. In the six-example test sheaf, $L$ has @SP_H0@ global sections. Its positive eigenvalues run from @SP_MUMIN@ to @SP_MUMAX@, so with $p=1$ and $\beta=2$ the half-resolution ratios run from 1 to @SP_SNRMAX@. The crossings measured from the exact gain along a fine schedule matched $\log(p+\beta\mu_k)$ to @SP_LOGERR@.

**Theorem 12.3 — The noised coupling schedule (new in V2).** The noised score of (33) is $-S_t^{-1}(X-a_t\mu)$ with

$$S_t^{-1}=\frac{p}{a_t^2+ps_t^2}I+\sum_k\kappa(\mu_k,t)\,u_ku_k^\top,\qquad \kappa(\mu,t)=\frac{a_t^2\beta\mu}{(a_t^2+s_t^2(p+\beta\mu))(a_t^2+ps_t^2)}. \tag{36}$$

The coupling equals $\beta\mu$ at the clean end and fades with noise: $\kappa\le\beta\mu\,a_t^2/(a_t^2+ps_t^2)^2$. For hard constraints it saturates in every incompatible mode,

$$\kappa(\mu,t)\to\frac{a_t^2}{s_t^2(a_t^2+ps_t^2)}\quad(\mu>0),\qquad D_t(X)\to\mu+\frac{a_t}{a_t^2+ps_t^2}\Pi_0(X-a_t\mu)\qquad(\beta\to\infty), \tag{37}$$

where $\Pi_0$ is the orthogonal projection onto $\ker L$.

*Proof.* The precision of mode $k$ in $S_t$ is $(p+\beta\mu_k)/(a_t^2+s_t^2(p+\beta\mu_k))$. Subtracting the uncoupled value $p/(a_t^2+ps_t^2)$ gives $\kappa$. The bound follows from $a_t^2+s_t^2(p+\beta\mu)\ge a_t^2+ps_t^2$. The limits follow by letting $\beta\mu\to\infty$ in $\kappa$ and in $(I+h_tL)^{-1}$, whose action on $\ker L$ is the identity. $\square$

Equation (37) reconnects Version 2 to Version 1. In the hard limit the total precision of an incompatible mode is $\kappa+p/(a_t^2+ps_t^2)=1/s_t^2$. A disagreement mode of a compatible target is therefore pure forward noise of variance $s_t^2$, which is Theorem 6.1. The limiting denoiser projects onto global sections, which is Proposition 6.2. The soft coupling $\beta$ interpolates between independent generation ($\beta=0$) and the compatible ambient model of Family A ($\beta\to\infty$).

The closed form (36) matched the exact difference of precisions to @KAP_ERR@. As $\beta$ rose through $10$, $10^2$, $10^3$ and $10^4$ at $a=0.6$, the distance from the gain to the scaled projection fell as @LIM_10@, @LIM_100@, @LIM_1000@ and @LIM_10000@, which is first order in $1/\beta$. The saturation value at that level is @SAT@.

![Figure 6. Coupling in the target. (a) Resolved share $\varrho_k(t)$ of every horizontal mode of the six-example sheaf, from (35). The global sections (orange) are decided first, and the largest disagreement mode last; the dotted line marks half resolution. (b) The exact noised coupling $\kappa(\mu,t)$ of (36), relative to its clean value $\beta\mu$, against the noise scale $s_t/a_t$ for three eigenvalues. A constant coupling (orange) keeps the clean value at every level.](fig/spectral.png){width=100%}

A tempting shortcut adds the clean coupling force $-\beta LX$ to an uncoupled noised score at every level, treating the clean potential as if it survived noising. Theorem 12.3 says this overstates the coupling at every $s_t>0$, and most in the high-frequency modes. Exact covariance propagation through 1,000 steps quantifies the error. With the exact score of (36), the relative covariance error was @NV_EXACT0@ for deterministic DDIM and @NV_EXACT1@ for the stochastic sampler. These errors fell with the step count: at 250, 1,000 and 4,000 steps they were @CONV_250@, @CONV_1000@ and @CONV_4000@ (deterministic). With the constant shortcut, the deterministic sampler missed the target covariance by @NV_EX0@. It kept @NV_GLOB@ of the global-section variance but only @NV_DIS@ of the disagreement variance: it over-glues the batch. The stochastic sampler with the shortcut diverged. One step map had spectral radius @NV_RAD1@, whereas no step of the exact sampler exceeded one. This is the among-example form of V1's rule *condition first and diffuse second*.

# 13 Two horizontals together: local reads, gluing and novelty

Version 1's horizontal (a cover inside each example) and Section 10's horizontal (records among examples) combine naturally. Let each example be a signal on $n$ pixels with circular boundary. Cover the pixels by windows $U_p=\{p-r,\ldots,p+r\}$. A *local read* lets pixel $p$ consult the records only through their restrictions to windows:

$$m_t(x)_p=\sum_q\omega_q(x,t)\,y_q(c),\qquad \omega_q\propto\exp\left(-\frac{\|x_{U_p}-a_ty_q\|^2}{2s_t^2}\right). \tag{38}$$

Here $x_{U_p}$ is the restriction of $x$ to the window $U_p$, $q$ runs over all training windows at all positions (translation equivariance), and $y_q(c)$ is the centre value of window $q$. In sheaf terms, (38) is the harmonic read of Section 4 in which the observation maps $H_i$ are window restrictions. Kamb and Ganguli showed that locality and equivariance constraints turn the ideal denoiser into a patch-mosaic machine whose outputs predict those of trained convolutional diffusion models [13]. The statement below recasts that mechanism as gluing.

Let the *data presheaf* assign to each window the set of training windows. A *mosaic* is a signal every window of which is a training window, which is a global section of the window-level data. Every record and every rotation of a record is a mosaic. The converse fails whenever two records share enough overlap to be spliced.

**Proposition 13.1 — Mosaics are clean fixed points (new in V2).** Let $a_t=1$ and $s_t\to0$. Every mosaic $x$ satisfies $m_t(x)=x$, with an error that decays like $\exp(-g^2/(2s_t^2))$, where $g$ is the smallest distance from a window of $x$ to a non-matching training window. On sign signals $\{\pm1\}^n$, the clean fixed points of the *global* read (window equal to the whole signal) are exactly the records and their rotations.

*Proof.* For a mosaic, each window $x_{U_p}$ coincides with at least one training window. All exact matches carry the centre value $x_p$, and every other window has weight $O(\exp(-g^2/(2s_t^2)))$. For the global read, the clean limit averages the nearest records. If $x$ is not a record, each nearest record differs from $x$ in some pixel. Since all values are $\pm1$, their average can equal $x$ at every pixel only if every nearest record equals $x$, which is a contradiction. $\square$

A toy test used $n=10$ pixels and three training records whose runs all have length at least two, giving 30 records with rotations. Enumerating all $2^{10}$ sign signals counts @GL_M3@ mosaics for window 3, @GL_M5@ for window 5, and @GL_M7@ for windows 7 and 9: wide windows leave no room to splice. Mosaics were exactly the clean fixed points for window 3. Fixed points were more numerous for wider windows (@GL_F5@ against @GL_M5@ mosaics at window 5), because a pixel can be fixed without its window being a training window. Deterministic DDIM with the local read (38) then generated 3,000 samples per window over 100 steps (Figure 7).

![Figure 7. Two horizontals together. (a) The three training records, five novel mosaics and three gluing failures produced by the window-3 local read (38); dark pixels are $+1$. Every window of a mosaic occurs in some training record, but no mosaic is a rotation of a record. Each gluing failure contains an isolated pixel, a window that no record contains. (b) Shares of 3,000 deterministic DDIM samples that are training copies, novel mosaics or gluing failures, for four window widths and for the global read. Numbers above the bars count all mosaics, including the 30 rotations of the records.](fig/gluing.png){width=100%}

Table: **Table 2.** What the local read returns. Shares of 3,000 deterministic DDIM samples, 100 steps; *distinct* counts different novel outputs; *defect* is the mean number of windows outside the training set among gluing failures.

| Window | Mosaics | Copies | Novel mosaics | Distinct novel | Gluing failures | Defect |
|:--|--:|--:|--:|--:|--:|--:|
| 3 | @GL_M3@ | @GL_C3@ | @GL_N3@ | @GL_U3@ | @GL_G3@ | @GL_D3@ |
| 5 | @GL_M5@ | @GL_C5@ | @GL_N5@ | @GL_U5@ | @GL_G5@ | @GL_D5@ |
| 7 | @GL_M7@ | @GL_C7@ | @GL_N7@ | @GL_U7@ | @GL_G7@ | @GL_D7@ |
| 9 | @GL_M9@ | @GL_C9@ | @GL_N9@ | @GL_U9@ | @GL_G9@ | @GL_D9@ |
| Global | 30 | @GL_CG@ | 0.0% | 0 | 0.0% | – |

The table separates two meanings of novelty. Novel mosaics are global sections of the local data that are not restrictions of any single record. They are what an example sheaf with a narrow cover can create, and they disappear once the window is wide enough to identify the record. Gluing failures are outputs in which neighbouring pixels chose incompatible windows, so the local choices do not glue into a section. Their defect, the number of windows outside the training set, is the residual of a horizontal compatibility check of the kind in Section 6, computed on generated outputs. The cover width of Part I [9] therefore acts as a novelty budget. The global read can only memorise (Corollary 10.3). A narrow read can splice, and it pays for this with gluing failures that a sheaf residual can detect and reject. This is a count on a toy alphabet, not a claim about images.

# 14 Implementable model families

The first implementations should freeze maps and the horizontal base. This avoids confounding a new probability model with the separate problem of learning the base. Families A to D place the horizontal structure within examples. Families E to H, new in Version 2, place it among examples.

**Family A — Ambient sheaf denoising.** Assemble compatible clean examples in $C^0$, draw ordinary full-dimensional forward noise, and train a clean or noise predictor with the declared DDPM objective. Use sheaf message passing internally and optionally constrain the clean output to $V$. At sampling time, retain ordinary DDPM/DDIM coordinates and noise. Report noisy residuals relative to (15), rather than labelling all disagreement inconsistent. Projection must use independently justified constraints.

**Family B — Intrinsic sheaf denoising.** Compute or implement the compatible parameterisation $U$. Encode each clean example by $h_0=U^\top X_0$, train (18), sample in $h$-coordinates, and lift only when local outputs are needed. This guarantees compatibility by construction. It also changes the noise covariance relative to ambient diffusion; controls must account for this and for any dimension reduction.

**Family C — Archive based sheaf evolution.** At each layer, retrieve records, form the harmonic read, and use (4) or the equivalent (5). Fitness weights and archive updates can be retained for optimisation. Without a matched clean distribution and forward process, describe this as a diffusion-inspired proposal algorithm. Evaluate decoded candidates before admitting them to the fitness archive. Predicted combinations are not observations.

**Family D — Conditional probabilistic reference.** Specify the clean posterior or factor model first, then derive or learn its noised scores. The Gaussian instance of Section 8 needs no neural training and can verify the sampler, covariance conventions and local-to-global assembly. It is a reference calculation, not a competitive high-dimensional generative architecture by itself.

**Family E — Example-star sampler.** Use the exact read (26) over a frozen record set, with uniform weights for a training set or fitness weights for an archive. It is the exact DDIM sampler of the empirical measure. It is the reference against which a trained denoiser's memorisation is measured, and with the population as its own archive it is DE (Theorem 10.4). Report the horizontal reach at every level.

**Family F — Horizontally coupled noise.** Keep any trained per-example denoiser and draw the batch's innovations with the correlation (32) of a declared example graph. Marginals are untouched (Proposition 11.1), so the family needs no retraining. It changes only the joint law of a batch, for example its diversity or its coverage of modes.

**Family G — Coupled-target sampler.** For a batch that must agree on shared observables, declare the coupling (33) on the clean batch. Sample it with the exact denoiser (34), or, when per-example scores are learned, add the scheduled coupling $-\sum_k\kappa(\mu_k,t)u_ku_k^\top X$ of (36) rather than the clean force $-\beta LX$. For non-Gaussian examples the scheduled coupling is exact only in the Gaussian case; elsewhere it is a surrogate whose error must be measured (H6).

**Family H — Local-read generator.** Use window restrictions as the maps of the example star (38), with the window width as a declared novelty budget. Monitor the gluing defect of every output. Reject or resample outputs whose defect is positive when the application requires globally consistent sections.

An implementation contract records the base, maps, units, clean distribution or empirical population, forward covariance, schedule, score parameterisation, numerical rank policy and random-seed scope. For Families E to H it also records which examples are records and which are generated, the example graph, its weights and $\tau$, $\beta$ and $p$. It also distinguishes evidence records, evaluated proposals and generated samples. Immutable records and pure functions fit this contract: a denoising step receives a versioned model and returns a state plus diagnostics; a private numerical solver can use mutable work arrays.

The minimal reverse-step interface takes $x_t$, $t$, an estimated clean state, schedule coefficients and an innovation. The horizontal read is a separate function. This makes the coordinate identity testable without training a model and allows the same denoiser to be compared under deterministic and stochastic samplers. It also prevents silent schedule changes from being attributed to a sheaf advantage.

## 14.1 One step of a sheaf-structured batch sampler

The families compose into a single step. For a batch $X_t$ at level $t$:

1. *Read among records.* For each example, form the clean prediction from the example star: (26) for complete records, the harmonic read with maps $H_i$ for partial ones, or the local read (38). A trained network replaces this read in Families A and B.
2. *Couple in the target (optional).* Apply the scaled resolvent $(I+h_tL)^{-1}$ of (34) to the batch of clean predictions in the Gaussian reference, or add the scheduled coupling of (36) to the learned scores. Solve the sparse system; never form the inverse.
3. *Step vertically.* Apply (4), equivalently (5) in clean coordinates, with innovations drawn from $\mathcal{N}(0,K)$ of (32) for Family F, or independent ones otherwise.
4. *Report diagnostics.* Record the horizontal reach, the compatibility residual $\|\delta X\|_W^2$ against its noise law (15), and for local reads the gluing defect.

With a sparse example graph, step 2 costs one sparse symmetric positive-definite solve per step, and it is well conditioned because $h_t\le\beta/p$. Step 3 with (32) needs one factorisation of $K$ per batch, not per step. Appendix A gives an immutable C# kernel of steps 1 to 3.

Angles, sign-indeterminate modes and changing charts belong in a later implementation. Euclidean Gaussian corruption is not coordinate invariant under nonlinear chart changes; Jacobian factors, the chosen volume measure and, for continuous-time coordinates, the appropriate stochastic correction matter. Orthogonal linear gauges are a simpler initial test because isotropic Gaussian laws are preserved by them. A collection of local Gaussian samplers is not automatically a globally defined diffusion on a curved space.

# 15 Numerical construction checks

The companion source records @CHECKS@ named checks from Version 1 and @V2_CHECKS@ from Version 2, @TOTAL_CHECKS@ in all, with fixed seeds and runtime metadata. All pass. They test equations, bounds and synthetic constructions rather than a trained generative model. Numerical values in this section and the figures are read from the saved result files.

Table: **Table 3.** Version 1 checks: horizontal structure within examples.

| Check family | Instances | Recorded result |
|:--|--:|:--|
| DDIM coordinate identity | @DDIM_N@ | Maximum relative discrepancy @DDIM_ERR@ |
| Compatible corruption and projection | @PROJ_N@ | Maximum residual @COMPAT_ERR@; @RISK_VIOL@ risk increases |
| Ambient residual law | @NOISE_N@ per scale | Maximum relative Monte Carlo discrepancy @NOISE_ERR@ |
| Gaussian restriction coupling | 1 | Pathwise square discrepancy @SQUARE_ERR@ |
| Harmonic energy gradient | @GRAD_N@ | Maximum finite-difference discrepancy @GRAD_ERR@ |
| Conditional Gaussian identities | @GAUSS_N@ | Posterior discrepancy @POST_ERR@; score discrepancy @GAUSS_SCORE_ERR@ |

Table: **Table 4.** Version 2 checks: horizontal structure among examples.

| Check family | Instances | Recorded result |
|:--|--:|:--|
| Example-star read and score (10.2) | 200 and 1 | Harmonic form @HARM_ERR@; score identity @TW_ERR@ |
| Clean-top re-selection (10.3) | @RS_N@ | @RS_SHARE@ on records; total variation @RS_TV@ |
| DE consensus step and bound (10.4) | @DE_N@ | Identity @DE_ERR@; @DE_VIOL@ bound violations |
| Marginal-preserving noise (11.1) | 2 samplers | Marginal difference @NC_MARG@; transfer @NC_TRANSFER@ |
| Resolvent denoiser and order (12.1, 12.2) | 5 levels | Resolvent @SP_RES@; crossing error @SP_LOGERR@ |
| Coupling schedule and limits (12.3) | 4 levels | Formula @KAP_ERR@; first order in $1/\beta$ |
| Constant coupling (12.3) | 1,000 steps | Exact @NV_EXACT0@; constant @NV_EX0@; stochastic diverges |
| Mosaics and fixed points (13.1) | $2^{10}$ signals | Fixed-point error @GL_FIXERR@; global fixed points @GL_GFIX@ |
| C# kernel against NumPy | @CS_LINES@ lines | Largest relative difference @CS_MAX@ |

The chain has @LOCAL_D@ local coordinates, @GLOBAL_D@ compatible coordinates and @CONSTRAINT_RANK@ independent equality constraints. These dimensions verify the fixed example, not a universal compression ratio. The negative sign cycle has compatible dimension @HOLONOMY_DIM@, illustrating the exact-noise obstruction.

The curl counterexample uses the maps and point stated in Proposition 4.2. Its finite-difference values corroborate the analytic strict inequality. For the heat test, the valid Gaussian family has spatial residual range at most @HEAT_GOOD@ on the declared grid, while the invalid family has range from @HEAT_BAD_MIN@ to @HEAT_BAD_MAX@ over the tested times. Both are normalisable at every level.

The ambient residual experiment uses independent full-dimensional Gaussian vectors. The intrinsic comparison uses the same vectors projected into $V$, so it isolates the covariance change. The observed agreement with (15) is a Monte Carlo check, not evidence that intrinsic corruption will generate better samples.

The Version 2 Gaussian results are exact covariance propagations, not Monte Carlo estimates. Their residual errors after many steps are discretisation errors of the sampler itself, and they fall with the step count. The mixture, DE and mosaic results are simulations with fixed seeds. The Version 1 result file was regenerated in the current environment and is identical to the published one apart from the recorded library versions. The Word paper uses editable native equations, passes OOXML schema validation, and is checked structurally and by rendered-page inspection. No neural training, likelihood benchmark or comparative generation benchmark is claimed.

# 16 Predictions and a staged test

The first study should use generated chain-context data with a known joint distribution, explicit train and test combinations, and a deliberately omitted-factor condition. Freeze all splits, budgets, maps and primary endpoints before the confirmatory comparison. Separate data-model quality from numerical sampler accuracy using the analytic reference.

**H1 — Correct shared structure improves conditional completion.** Under matched observations and total compute, a calibrated sheaf model has lower held-out completion error than identity-map and shuffled-map controls. The primary endpoint is task error on unseen combinations, with confidence intervals over independent data-generating instances. Reject the predicted advantage if the paired 95 percent interval for control error minus sheaf error is not strictly positive. A benefit from additional information is not evidence for a special sampler.

**H2 — Compatible parameterisation preserves diversity.** On multimodal data supported on a known compatible space, intrinsic diffusion maintains mode coverage while reducing horizontal violation relative to an ambient baseline. Require noninferiority in a preregistered mode-coverage tolerance as well as the expected residual improvement. Reject the useful-generation claim if compatibility is obtained by losing modes or reducing all states toward a trivial section.

**H3 — Score and time consistency predict sampler fidelity.** On analytic models, precision-weighted and forward-consistent scores reproduce the declared noised distributions more accurately than naive read displacements or independently fitted incompatible energy families at matched integration budgets. Compare empirical moments and a declared distributional distance. Refute the implementation claim if the corrected sampler fails its preregistered tolerance against the analytic reference. This is primarily a correctness test, not a claim about image quality.

**H4 — Correct factors limit false recombination.** Add a known cross-context dependency absent from the initial sheaf. Predict increased false combinations under the incomplete model and recovery after the correct factor is supplied. Include a matched factor-graph learner. Reject the proposed mechanism advantage if the relevant interaction is absent, or if performance is fully explained by giving one method the missing dependency.

**H5 — Noise coupling buys batch diversity at no marginal cost.** With a fixed trained denoiser, batches drawn with negatively correlated noise from (32) cover more modes per batch than independent batches, while per-sample fidelity metrics are unchanged within preregistered noninferiority margins. Proposition 11.1 guarantees the marginals; the prediction concerns the joint coverage gain. Reject it if coverage per batch does not improve at the declared batch size.

**H6 — Scheduled coupling beats constant coupling for learned scores.** For a batch that must share interfaces, adding the schedule (36) to learned per-example scores yields lower interface error at matched fidelity than adding $-\beta LX$ at every level. It should also remain stable where the constant coupling diverges. Use a synthetic non-Gaussian family with known joint law, and report the gap to the exact coupled sampler. Reject it if the scheduled surrogate is not better than the constant one on the joint distance.

**H7 — Window width sets a novelty budget.** In a trained local or convolutional denoiser, the share of outputs that are novel mosaics falls, and the share of training copies rises, as the effective receptive field widens. Gluing failures are detected by a positive window defect. Compare with the analytic local read (38) and the patch-mosaic predictions of [13]. Reject it if novelty does not decrease monotonically with the receptive field at a fixed dataset.

Table: **Table 5.** Stages of the staged test.

| Stage | Deliverable | Required evidence |
|:--|:--|:--|
| SD0 | Fixed maps, units, chain data and exact coordinate conversion | Identity and covariance checks pass |
| SD1 | Analytic conditional Gaussian sampler | Moments and scores agree with the reference |
| SD2 | Ambient and intrinsic learned denoisers | Held-out fidelity and mode coverage reported together |
| SD3 | Archive based sheaf sampler and matched controls | Proposal gains survive equal information and compute |
| SD4 | Learned maps or nonlinear charts | Comparison maps and forward-process changes are validated |
| SD5 | Example-star reference and coupled-noise batches (E, F) | Memorisation and coverage measured against the exact read |
| SD6 | Coupled-target and local-read samplers (G, H) | Interface error, stability and gluing defect against the analytic references |

Required controls include ordinary DDPM/DDIM, identity restrictions, an ordinary graph-Laplacian architecture, a dimension-matched latent diffusion, a matched factor-aware learner, and the analytic Gaussian reference. For Families E to H, add independent batches, constant coupling and particle guidance [14] as controls. Do not compare intrinsic diffusion only to a larger ambient model and attribute every efficiency gain to topology. Report map-learning cost, basis cost, retrieval work, solver work, denoising evaluations, persisted parameters and stochastic sample counts.

Learning maps by compatibility loss alone permits degenerate zero restrictions. Independently calibrate shared observables, constrain ranks or normalisation where justified, and test out-of-sample transport. Branches representing different contexts remain distinct unless the generative model explicitly specifies transitions or mixtures between them. A router or conditioning variable must be available at inference; an oracle branch label is not a deployable model.

# 17 What the construction establishes

The DDIM-to-ADE identity makes the reverse journey algebraically concrete. Version 2 completes it at the other end. The exact empirical DDIM denoiser is the harmonic read of an example star. Diffusion Evolution is a lazy consensus step on its population graph. An ASE layer is the same read with partial maps. Tracing ASE back through ADE and DE to DDPM and DDIM therefore loses nothing essential: each stage is the previous one with a narrower horizontal sheaf.

Horizontal sheaf structure can enter at four places, and Version 2 gives each its exact law. In the read among records, it is exact and memorises. In the noise of a batch, it preserves marginals and transmits correlation. In the target of a batch, the denoiser becomes an implicit sheaf heat step, the vertical axis sorts the horizontal spectrum, and the noised coupling fades on a closed-form schedule. In a local read, gluable splices become fixed points, and novelty and gluing failure are two sides of one cover. These are different interventions and should be ablated separately.

The strongest exact statements concern compatibility and probability typing. Ambient noising has a calculable disagreement law. Intrinsic noising preserves the compatible subspace. Restrictions constrain admissible covariances. Harmonic displacement requires precision weighting to become the declared energy score. A valid collection of scores must also satisfy the forward generator's consistency conditions. Clean couplings must be noised, not copied. None of these guarantees that a learned model beats an ordinary denoiser.

Sheaf structure can therefore be carried all the way back to DDPM and DDIM, with denoising as the vertical axis and the relation among examples as the horizontal one. The resulting model should be called generative only when its distribution, forward corruption and reverse dynamics are specified together. Where ASE instead uses an evolving fitness archive to propose better designs, the same vertical schedule remains useful, with the more limited interpretation of a structured optimiser.

# References

[1] Ho, J., Jain, A. and Abbeel, P. (2020). Denoising Diffusion Probabilistic Models. *Advances in Neural Information Processing Systems* 33. https://arxiv.org/abs/2006.11239

[2] Song, J., Meng, C. and Ermon, S. (2021). Denoising Diffusion Implicit Models. *International Conference on Learning Representations*. arXiv:2010.02502v4. https://arxiv.org/abs/2010.02502v4

[3] Song, Y., Sohl-Dickstein, J., Kingma, D. P., Kumar, A., Ermon, S. and Poole, B. (2021). Score-Based Generative Modeling through Stochastic Differential Equations. *International Conference on Learning Representations*. https://arxiv.org/abs/2011.13456

[4] Zhang, Y., Hartl, B., Hazan, H. and Levin, M. (2025). Diffusion Models are Evolutionary Algorithms. *International Conference on Learning Representations*. Revised preprint arXiv:2410.02543v3, 9 May 2026. https://arxiv.org/abs/2410.02543v3

[5] Bodnar, C., Di Giovanni, F., Chamberlain, B. P., Liò, P. and Bronstein, M. M. (2022). Neural Sheaf Diffusion: A Topological Perspective on Heterophily and Oversmoothing in GNNs. *Advances in Neural Information Processing Systems* 35. https://arxiv.org/abs/2202.04579

[6] Bourgerie, R., Girdzijauskas, Š. and Fodor, V. (2026). Deep Neural Sheaf Diffusion. arXiv:2605.19021v2. Accepted at the ICML 2026 Workshop on Graph Foundation Models. https://arxiv.org/abs/2605.19021v2

[7] Hu, C.-S. (2026). A Sheaf-Theoretic and Topological Perspective on Complex Network Modeling and Attention Mechanisms in Graph Neural Models. arXiv:2601.21207v4. AAAI 2026 Workshop on Mathematical Foundations of AI. https://arxiv.org/abs/2601.21207v4

[8] Ghosh, D. P. (2026). Autoregressive Sheaf Evolution. Conversion proposal. Project manuscript.

[9] Ghosh, D. P. (2026). Horizontally Topological, Vertically Algebraic. ASE Part I. Project manuscript.

[10] Ghosh, D. P. (2026). The Horizontal Layer. ASE Part II. Project manuscript.

[11] Ghosh, D. P. (2026). Autoregressive Sheaf Evolution for Memory Consolidation. Version 3, 18 October 2026. Project manuscript.

[12] Ghosh, D. P. (2026). The Vertical Stack. ASE Part III: the token recurrence, tangent dynamics and persistence across layers. 18 October 2026. Project manuscript.

[13] Kamb, M. and Ganguli, S. (2025). An analytic theory of creativity in convolutional diffusion models. *International Conference on Machine Learning*. arXiv:2412.20292. https://arxiv.org/abs/2412.20292

[14] Corso, G., Xu, Y., De Bortoli, V., Barzilay, R. and Jaakkola, T. (2024). Particle Guidance: non-I.I.D. Diverse Sampling with Diffusion Models. *International Conference on Learning Representations*. arXiv:2310.13102. https://arxiv.org/abs/2310.13102

[15] Gu, X., Du, C., Pang, T., Li, C., Lin, M. and Wang, Y. (2025). On Memorization in Diffusion Models. *Transactions on Machine Learning Research*. arXiv:2310.02664. https://arxiv.org/abs/2310.02664

[16] Seneta, E. (2006). *Non-negative Matrices and Markov Chains*. Revised printing. Springer Series in Statistics. Springer, New York.

[17] Hansen, J. and Ghrist, R. (2019). Toward a spectral theory of cellular sheaves. *Journal of Applied and Computational Topology* 3, 315–358. https://arxiv.org/abs/1808.01513

# Appendix A. An immutable C# kernel

The kernel below implements the example-star read (26), the DDIM step (4), the DE step of Theorem 10.4, the horizontal reach, the local read (38), the coupled denoiser (34) and the schedule (36). It uses immutable records, `ImmutableArray<double>` vectors and pure static functions; the Cholesky solve works on a private copy. A validation program prints @CS_LINES@ lines of outputs on fixed inputs, and an independent NumPy implementation recomputes each line. The NumPy coupled denoiser uses the covariance form (21), not the resolvent form (34), so the comparison also checks Theorem 12.1. The schedule is recomputed from the difference of precisions, not from (36).

```csharp
@CS_CODE@
```

Table: **Table 6.** C# against NumPy, line by line (.NET @DOTNET@).

| Output | Values (C#) | Largest relative difference |
|:--|:--|--:|
@CS_ROWS@
