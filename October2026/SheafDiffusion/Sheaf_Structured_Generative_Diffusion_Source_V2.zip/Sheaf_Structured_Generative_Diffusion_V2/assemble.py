"""Assemble paper_template.md from the V2 front matter, the retained V1 Sections 2-9 and the new sections."""
from pathlib import Path
P = Path(__file__).resolve().parent / 'src'
parts = ['front.md', 'middle.md', 'among.md', 'end.md']
(P.parent / 'paper_template.md').write_text('\n'.join((P / f).read_text() for f in parts))
print('Assembled template from', ', '.join(parts))
