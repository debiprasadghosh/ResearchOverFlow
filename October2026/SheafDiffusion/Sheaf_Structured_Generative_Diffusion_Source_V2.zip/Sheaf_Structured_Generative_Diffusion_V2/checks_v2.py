"""V2 checks: the among-example horizontal of sheaf-structured diffusion.

Sections (paper numbering):
  10  example star read, DDIM = ADE recurrence, clean-top re-selection,
      Diffusion Evolution as a consensus step on the population graph
  11  horizontal coupling in the noise (marginal preservation, transmitted covariance)
  12  horizontal coupling in the target (resolvent denoiser, spectral order,
      coupling schedule, limits, naive coupling)
  13  two horizontals together: local reads, gluing and mosaics
No neural network is trained; every check is an identity, a bound or a synthetic simulation.
"""
from pathlib import Path
import itertools, json, math, sys
import numpy as np
from scipy.special import logsumexp, softmax
from scipy.linalg import expm

P = Path(__file__).resolve().parent
SEED = 20261019
rng = np.random.default_rng(SEED)
R = {'seed': SEED, 'python': sys.version.split()[0], 'numpy': np.__version__,
     'status': 'identities, bounds and synthetic simulations; no trained network'}
tests = []


def check(name, ok):
    tests.append({'name': name, 'passed': bool(ok)})


def cosine_schedule(T, smin=1e-4):
    """VP schedule a_t^2 + s_t^2 = 1 with a_0 = 1; returns arrays of length T+1."""
    u = np.arange(T + 1) / T
    abar = np.cos((u + 0.008) / 1.008 * np.pi / 2) ** 2
    abar = abar / abar[0]
    abar = np.clip(abar, smin, 1.0)
    return np.sqrt(abar), np.sqrt(1 - abar)


def ddim_coeffs(a, s, ap, sp, eta):
    sig = eta * sp / s * math.sqrt(max(0.0, 1 - a * a / (ap * ap))) if s > 0 else 0.0
    sig = min(sig, sp)
    c = math.sqrt(max(0.0, sp * sp - sig * sig))
    return c, sig


# ---------------------------------------------------------------- Section 10
def mixture_read(x, records, logw, a, s):
    """Posterior mean of x0 given x_t = x for p0 = sum_i w_i delta_{y_i}; rows of x are queries."""
    d2 = ((x[:, None, :] - a * records[None, :, :]) ** 2).sum(-1)
    W = softmax(logw[None, :] - d2 / (2 * s * s), axis=1)
    return W @ records, W


# 10.1  the read is the weighted least-squares (harmonic) extension on the example star
err_harm = 0.0
for _ in range(200):
    n, d = 7, 3
    Y = rng.normal(size=(n, d)); lw = rng.normal(size=n)
    x = rng.normal(size=(1, d)); a, s = 0.7, math.sqrt(1 - 0.49)
    m, W = mixture_read(x, Y, lw, a, s)
    # harmonic extension: minimise sum_i W_i ||r - y_i||^2 by solving the normal equations
    A = W.sum() * np.eye(d); b = (W[0][:, None] * Y).sum(0)
    err_harm = max(err_harm, float(np.max(np.abs(np.linalg.solve(A, b) - m[0]))))
check('empirical denoiser equals the harmonic read of the example star', err_harm < 1e-12)

# Tweedie identity on a random mixture
Y = rng.normal(size=(9, 3)); lw = rng.normal(size=9); a, s = 0.55, math.sqrt(1 - 0.55 ** 2)
x0 = rng.normal(size=3); h = 1e-5


def logp(x):
    return logsumexp(lw - ((x - a * Y) ** 2).sum(1) / (2 * s * s))


g = np.array([(logp(x0 + h * e) - logp(x0 - h * e)) / (2 * h) for e in np.eye(3)])
m, _ = mixture_read(x0[None], Y, lw, a, s)
tweedie_err = float(np.max(np.abs(g - (a * m[0] - x0) / s ** 2)))
check('score of the noised empirical measure is (a m - x)/s^2', tweedie_err < 1e-7)
R['harmonic_error'] = err_harm; R['tweedie_error'] = tweedie_err

# 10.2  clean-top re-selection by deterministic DDIM with the exact empirical denoiser
T = 200
at, st = cosine_schedule(T)
recs = np.array([[0., 0.], [2., 0.], [0., 2.], [2., 2.], [1., 3.5]])
prior = np.array([.35, .25, .2, .12, .08])
ns = 20000
xs = rng.normal(size=(ns, 2))
for t in range(T, 0, -1):
    m, _ = mixture_read(xs, recs, np.log(prior), at[t], st[t])
    eps = (xs - at[t] * m) / st[t]
    c, _ = ddim_coeffs(at[t], st[t], at[t - 1], st[t - 1], 0.0)
    xs = at[t - 1] * m + c * eps
dist = np.sqrt(((xs[:, None, :] - recs[None]) ** 2).sum(-1))
near = dist.argmin(1); on = dist.min(1) < 1e-3
freq = np.bincount(near[on], minlength=5) / max(1, on.sum())
tv = 0.5 * float(np.abs(freq - prior).sum())
R['reselection'] = {'samples': ns, 'steps': T, 'share_within_1e-3': float(on.mean()),
                    'frequencies': freq.tolist(), 'prior': prior.tolist(), 'total_variation': tv,
                    'final_noise_scale': float(st[1] / at[1])}
check('clean-top DDIM with the exact empirical read lands on records', on.mean() > 0.99)
check('record frequencies match prior weights (TV < 0.02)', tv < 0.02)


# 10.3  Diffusion Evolution step = DDIM step on the self-archive = lazy consensus step
def de_step(X, fit_logw, a, s, ap, sp, eta, xi):
    """Algorithm form of [4]: records are the current population members themselves."""
    m, W = mixture_read(X, X, fit_logw, a, s)
    eps = (X - a * m) / s
    c, sig = ddim_coeffs(a, s, ap, sp, eta)
    return ap * m + c * eps + sig * xi, W, c, sig


def dobrushin(Pm):
    return 0.5 * max(float(np.abs(Pm[i] - Pm[j]).sum()) for i in range(len(Pm)) for j in range(len(Pm)))


id_err = 0.0; bound_viol = 0; theta_min = 1.0; theta_max = 0.0; ratio_max = 0.0
for _ in range(500):
    n, d = 12, 2
    X = rng.normal(size=(n, d)) * rng.uniform(.3, 2)
    fl = rng.normal(size=n)
    a = float(rng.uniform(.05, .95)); ap = float(rng.uniform(a, 1.)); s = math.sqrt(1 - a * a); sp = math.sqrt(1 - ap * ap)
    Xn, W, c, _ = de_step(X, fl, a, s, ap, sp, 0.0, np.zeros((n, d)))
    r = c / s + ap - a * c / s; theta = (ap - a * c / s) / r
    Pm = (1 - theta) * np.eye(n) + theta * W
    id_err = max(id_err, float(np.max(np.abs(Xn - r * Pm @ X))) / (1 + float(np.max(np.abs(Xn)))))
    theta_min = min(theta_min, theta); theta_max = max(theta_max, theta)
    diam = lambda Z: max(float(np.linalg.norm(Z[i] - Z[j])) for i in range(len(Z)) for j in range(len(Z)))
    lhs, rhs = diam(Xn), r * dobrushin(Pm) * diam(X)
    bound_viol += lhs > rhs * (1 + 1e-12) + 1e-14
    ratio_max = max(ratio_max, lhs / rhs)
R['de_consensus'] = {'trials': 500, 'max_relative_identity_error': id_err, 'theta_range': [theta_min, theta_max],
                     'dobrushin_violations': int(bound_viol), 'max_diameter_ratio_to_bound': ratio_max}
check('deterministic DE step equals r_t[(1-theta)I + theta W]X', id_err < 1e-12)
check('consensus weight theta lies in [0,1]', 0 <= theta_min <= theta_max <= 1)
check('population diameter obeys the Dobrushin bound', bound_viol == 0)

# horizontal reach along a DE run and a fixed-archive DDIM run (four-peak fitness)
peaks = np.array([[-2., -2.], [2., -2.], [-2., 2.], [2., 2.]])
fitness = lambda X: np.log(np.exp(-((X[:, None] - peaks[None]) ** 2).sum(-1) / 0.5).sum(1) + 1e-300)
T2 = 100; a2, s2 = cosine_schedule(T2, smin=1e-3)
X = rng.normal(size=(256, 2)) * 1.0
reach = []; snapshots = {}
fixed = rng.normal(size=(256, 2)) * 0.25 + peaks[rng.integers(0, 4, 256)]
Xf = rng.normal(size=(256, 2))
for t in range(T2, 0, -1):
    Xn, W, _, _ = de_step(X, fitness(X) / 0.5, a2[t], s2[t], a2[t - 1], s2[t - 1], 1.0, rng.normal(size=X.shape))
    mf, Wf = mixture_read(Xf, fixed, np.zeros(256), a2[t], s2[t])
    c, _ = ddim_coeffs(a2[t], s2[t], a2[t - 1], s2[t - 1], 0.0)
    Xf = a2[t - 1] * mf + c * (Xf - a2[t] * mf) / s2[t]
    reach.append({'t': t, 'noise_scale': float(s2[t] / a2[t]),
                  'de_reach': float(np.mean(1 / (W ** 2).sum(1))),
                  'archive_reach': float(np.mean(1 / (Wf ** 2).sum(1)))})
    if t in (T2, 60, 35, 1):
        snapshots[str(t)] = {'X': X.tolist(), 'noise_scale': float(s2[t] / a2[t])}
    X = Xn
dpk = np.sqrt(((X[:, None] - peaks[None]) ** 2).sum(-1)).min(1)
R['de_reach'] = {'population': 256, 'steps': T2, 'rows': reach, 'snapshots': snapshots,
                 'final_share_within_0.5_of_a_peak': float((dpk < .5).mean()),
                 'reach_first': reach[0]['de_reach'], 'reach_last': reach[-1]['de_reach'],
                 'archive_reach_first': reach[0]['archive_reach'], 'archive_reach_last': reach[-1]['archive_reach']}
check('archive reach falls from almost all records to about one during denoising',
      reach[0]['archive_reach'] > 200 and reach[-1]['archive_reach'] < 3)
check('DE reach is smaller at the clean end than at the noisy end', reach[0]['de_reach'] > reach[-1]['de_reach'])

# ---------------------------------------------------------------- Section 11: coupling in the noise
def example_sheaf(N, d, de, edges, rng):
    blocks = []
    for (i, j) in edges:
        Fi = rng.normal(size=(de, d)); Fj = rng.normal(size=(de, d))
        row = np.zeros((de, N * d)); row[:, i * d:(i + 1) * d] = -Fi; row[:, j * d:(j + 1) * d] = Fj
        blocks.append(row)
    return np.vstack(blocks)


N, d, de = 6, 3, 2
edges = [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 0), (0, 3)]
delta = example_sheaf(N, d, de, edges, rng)
L = delta.T @ delta
# unit-diagonal sheaf heat-kernel correlation
Hk = expm(-0.6 * L)
Bd = np.zeros_like(Hk)
for i in range(N):
    blk = Hk[i * d:(i + 1) * d, i * d:(i + 1) * d]
    w, V = np.linalg.eigh(blk); Bd[i * d:(i + 1) * d, i * d:(i + 1) * d] = V @ np.diag(w ** -0.5) @ V.T
K = Bd @ Hk @ Bd
diag_err = max(float(np.max(np.abs(K[i * d:(i + 1) * d, i * d:(i + 1) * d] - np.eye(d)))) for i in range(N))
check('normalised sheaf heat kernel has identity diagonal blocks', diag_err < 1e-12)
check('normalised sheaf heat kernel is positive semidefinite', np.linalg.eigvalsh(K).min() > -1e-12)

# Gaussian data per example; a common linear denoiser; exact covariance propagation
G0 = rng.normal(size=(d, d)); C0 = G0 @ G0.T / d + 0.2 * np.eye(d); m0 = rng.normal(size=d)


def chain_cov(Kn, eta, T, C0, terminal_K=None):
    a, s = cosine_schedule(T)
    Nd = Kn.shape[0]; n = Nd // d
    Cbig = np.kron(np.eye(n), C0)
    S = a[T] ** 2 * Cbig + s[T] ** 2 * np.eye(Nd)
    # terminal covariance: exact marginal for independent examples, noise part correlated by K
    Sig = Kn.copy()                                               # start from correlated standard noise
    for t in range(T, 0, -1):
        Sx = a[t] ** 2 * C0 + s[t] ** 2 * np.eye(d)
        Gain = a[t] * C0 @ np.linalg.inv(Sx)                       # D(x) = m + Gain (x - a m)
        c, sig = ddim_coeffs(a[t], s[t], a[t - 1], s[t - 1], eta)
        M1 = a[t - 1] * Gain + c / s[t] * (np.eye(d) - a[t] * Gain)
        M = np.kron(np.eye(n), M1)
        Sig = M @ Sig @ M.T + sig ** 2 * Kn
    return Sig


out = {}
for eta in (0.0, 1.0):
    Sig_K = chain_cov(K, eta, 400, C0)
    Sig_I = chain_cov(np.eye(N * d), eta, 400, C0)
    marg = max(float(np.max(np.abs(Sig_K[i * d:(i + 1) * d, i * d:(i + 1) * d] - Sig_I[i * d:(i + 1) * d, i * d:(i + 1) * d])))
               for i in range(N))
    transfer = max(float(np.max(np.abs(Sig_K[i * d:(i + 1) * d, j * d:(j + 1) * d]))) for i in range(N) for j in range(N) if i != j)
    out[str(eta)] = {'marginal_block_difference': marg, 'max_cross_block': transfer,
                     'marginal_vs_target': max(float(np.max(np.abs(Sig_K[i * d:(i + 1) * d, i * d:(i + 1) * d] - C0))) for i in range(N))}
# scalar-correlation case: cross covariance equals rho times the marginal covariance
rho = 0.6; Kr = np.kron(np.array([[1, rho], [rho, 1]]), np.eye(d))
transfer_err = {}
for eta in (0.0, 1.0):
    Sg = chain_cov(Kr, eta, 400, C0)
    transfer_err[str(eta)] = float(np.max(np.abs(Sg[:d, d:] - rho * Sg[:d, :d])))
# wrong diagonal: raw heat kernel without normalisation changes marginals
Sig_bad = chain_cov(Hk, 1.0, 400, C0)
bad = max(float(np.max(np.abs(Sig_bad[i * d:(i + 1) * d, i * d:(i + 1) * d] - C0))) for i in range(N))
R['noise_coupling_blocknorm'] = [[float(np.linalg.norm(K[i * d:(i + 1) * d, j * d:(j + 1) * d], 2)) for j in range(N)] for i in range(N)]
R['noise_coupling'] = {'examples': N, 'dim': d, 'edges': len(edges), 'edge_dim': de, 'steps': 400,
                       'unit_diagonal_error': diag_err, 'eta': out, 'transfer_error': transfer_err,
                       'unnormalised_marginal_error': bad}
check('correlated innovations with identity blocks leave every marginal unchanged (DDIM and DDPM)',
      max(v['marginal_block_difference'] for v in out.values()) < 1e-12)
check('per-example marginal matches the target covariance up to discretisation (400 steps)',
      max(v['marginal_vs_target'] for v in out.values()) < 0.05)
check('scalar correlation is transmitted exactly: Cov(x^1,x^2) = rho Var(x^1)', max(transfer_err.values()) < 1e-12)
check('an unnormalised heat kernel changes the marginals', bad > 0.05)

# Mixture data: same-mode probability against correlation (deterministic DDIM, Monte Carlo)
modes = np.array([[-2., 0.], [2., 0.], [0., -2.], [0., 2.]]); mw = np.full(4, .25)
same = []
for rho in (-1.0, -0.5, 0.0, 0.5, 0.9):
    npair = 6000
    e1 = rng.normal(size=(npair, 2)); e2 = rho * e1 + math.sqrt(max(0., 1 - rho * rho)) * rng.normal(size=(npair, 2))
    out2 = []
    for xs in (e1, e2):
        xs = xs.copy()
        for t in range(T, 0, -1):
            m, _ = mixture_read(xs, modes, np.log(mw), at[t], st[t])
            c, _ = ddim_coeffs(at[t], st[t], at[t - 1], st[t - 1], 0.0)
            xs = at[t - 1] * m + c * (xs - at[t] * m) / st[t]
        out2.append(np.sqrt(((xs[:, None] - modes[None]) ** 2).sum(-1)).argmin(1))
    same.append({'rho': rho, 'same_mode': float((out2[0] == out2[1]).mean())})
R['noise_coupling']['same_mode'] = same
R['noise_coupling']['independent_same_mode'] = float((mw ** 2).sum())
check('antithetic noise lowers the same-mode probability below independence',
      same[0]['same_mode'] < 0.5 * (mw ** 2).sum())
check('positively correlated noise raises the same-mode probability', same[-1]['same_mode'] > 2 * (mw ** 2).sum())

# ---------------------------------------------------------------- Section 12: coupling in the target
p, beta = 1.0, 2.0
Lam = p * np.eye(N * d) + beta * L
Cc = np.linalg.inv(Lam)
mu = Cc @ (p * np.tile(m0, N))
evals, evecs = np.linalg.eigh(L)
res_err = 0.0; comm_err = 0.0
for t in (5, 50, 150, 300, 390):
    a, s = cosine_schedule(400)[0][t], cosine_schedule(400)[1][t]
    S = a * a * Cc + s * s * np.eye(N * d)
    Gain = a * Cc @ np.linalg.inv(S)
    hstep = beta * s * s / (a * a + p * s * s)
    Gres = a / (a * a + p * s * s) * np.linalg.inv(np.eye(N * d) + hstep * L)
    res_err = max(res_err, float(np.max(np.abs(Gain - Gres))))
    Ht = expm(-0.3 * L)
    comm_err = max(comm_err, float(np.max(np.abs(Gain @ Ht - Ht @ Gain))))
check('coupled Gaussian denoiser gain is a scaled resolvent of the sheaf Laplacian', res_err < 1e-10)
check('the denoiser commutes with horizontal sheaf heat flow', comm_err < 1e-10)

# spectral order: half-resolution log-SNR of each mode is log(p + beta mu)
mus = np.unique(np.round(evals, 10))
order = []
for mu_k in mus:
    snr_half = p + beta * mu_k
    order.append({'mu': float(mu_k), 'half_resolution_snr': float(snr_half),
                  'noise_scale_at_half': float(1 / math.sqrt(snr_half))})
h0 = int(np.sum(np.abs(evals) < 1e-9))
# verify numerically by projecting the exact gain onto eigenvectors along a fine schedule
af, sf = cosine_schedule(4000, smin=1e-8)
res_num = []
for k in (0, h0, N * d - 1):
    u = evecs[:, k]
    rk = np.array([u @ (aa * aa * Cc) @ np.linalg.solve(aa * aa * Cc + ss * ss * np.eye(N * d), u) for aa, ss in zip(af[::40], sf[::40])])
    snr = (af[::40] / np.maximum(sf[::40], 1e-12)) ** 2
    cross = float(np.interp(0.5, rk[::-1], np.log(snr[::-1])))      # rk increases as snr increases
    res_num.append({'mu': float(evals[k]), 'log_snr_measured': cross, 'log_snr_theory': math.log(p + beta * evals[k])})
order_err = max(abs(r_['log_snr_measured'] - r_['log_snr_theory']) for r_ in res_num)
R['spectral'] = {'p': p, 'beta': beta, 'global_sections': h0, 'modes': order, 'measured': res_num,
                 'max_log_snr_error': order_err, 'resolvent_error': res_err, 'commutation_error': comm_err,
                 'mu_max': float(evals.max()), 'mu_min_positive': float(evals[h0])}
check('global sections are resolved first; half-resolution at SNR p + beta mu', order_err < 0.05)
check('the example sheaf has nontrivial global sections', h0 > 0)

# coupling schedule kappa(mu,t) and the hard-constraint limit
def kappa(mu_k, a, s, p=p, beta=beta):
    return a * a * beta * mu_k / ((a * a + s * s * (p + beta * mu_k)) * (a * a + s * s * p))


kap_err = 0.0
for t in (1, 50, 200, 350):
    a, s = cosine_schedule(400)[0][t], cosine_schedule(400)[1][t]
    Sinv = np.linalg.inv(a * a * Cc + s * s * np.eye(N * d))
    Kexact = Sinv - np.eye(N * d) * p / (a * a + s * s * p)
    Kform = evecs @ np.diag([kappa(mu_k, a, s) for mu_k in evals]) @ evecs.T
    kap_err = max(kap_err, float(np.max(np.abs(Kexact - Kform))))
check('noised coupling equals the spectral schedule kappa(mu,t)', kap_err < 1e-10)
# hard limit: as beta -> infinity the gain tends to the scaled projection onto global sections
Pi0 = evecs[:, :h0] @ evecs[:, :h0].T
a, s = 0.6, 0.8
lim = []
for bb in (1e1, 1e2, 1e3, 1e4):
    hstep = bb * s * s / (a * a + p * s * s)
    G = a / (a * a + p * s * s) * np.linalg.inv(np.eye(N * d) + hstep * L)
    lim.append({'beta': bb, 'distance_to_projection': float(np.linalg.norm(G - a / (a * a + p * s * s) * Pi0, 2))})
check('hard coupling limit is projection onto global sections (O(1/beta))',
      lim[-1]['distance_to_projection'] * 1e4 < 2 * lim[-2]['distance_to_projection'] * 1e3 + 1e-9 and lim[-1]['distance_to_projection'] < 1e-3)
sat = [{'mu': float(m_), 'kappa': kappa(m_, a, s, beta=1e8)} for m_ in mus[mus > 1e-9][:3]]
R['coupling_schedule'] = {'kappa_formula_error': kap_err, 'limit': lim,
                          'saturation_value': a * a / (s * s * (a * a + s * s * p)), 'saturation_rows': sat}
check('hard-constraint coupling saturates at a^2/(s^2(a^2+p s^2)) in every incompatible mode',
      max(abs(r_['kappa'] - a * a / (s * s * (a * a + s * s * p))) for r_ in sat) < 1e-6)


# naive coupling: uncoupled score minus beta L x at every level, exact covariance propagation
def run_linear(score_mat, T, eta, radius=None):
    a, s = cosine_schedule(T)
    n = N * d
    Sig = a[T] ** 2 * Cc + s[T] ** 2 * np.eye(n); mean = a[T] * mu
    for t in range(T, 0, -1):
        A_, b_ = score_mat(a[t], s[t])                              # score(x) = A_ x + b_
        Mden = (np.eye(n) + s[t] ** 2 * A_) / a[t]; bden = s[t] ** 2 * b_ / a[t]
        c, sig = ddim_coeffs(a[t], s[t], a[t - 1], s[t - 1], eta)
        M = a[t - 1] * Mden + c / s[t] * (np.eye(n) - a[t] * Mden)
        bb = a[t - 1] * bden - c / s[t] * a[t] * bden
        Sig = M @ Sig @ M.T + sig * sig * np.eye(n); mean = M @ mean + bb
        if radius is not None:
            radius.append(float(np.max(np.abs(np.linalg.eigvals(M)))))
    return Sig, mean


def exact_score(a, s):
    Sinv = np.linalg.inv(a * a * Cc + s * s * np.eye(N * d))
    return -Sinv, Sinv @ (a * mu)


C_unc = np.eye(N * d) / p; mu_unc = mu


def naive_score(a, s):
    A0 = -np.eye(N * d) / (a * a / p + s * s)
    return A0 - beta * L, -A0 @ (a * mu)


naive = {}
for eta in (0.0, 1.0):
    re_, rn_ = [], []
    Se, me = run_linear(exact_score, 1000, eta, re_)
    Sn, mn = run_linear(naive_score, 1000, eta, rn_)
    naive[str(eta)] = {'exact_max_step_radius': max(re_), 'naive_max_step_radius': max(rn_),
                       'naive_finite': bool(np.isfinite(Sn).all() and np.linalg.norm(Sn) < 1e6),'exact_cov_rel_error': float(np.linalg.norm(Se - Cc) / np.linalg.norm(Cc)),
                       'naive_cov_rel_error': float(np.linalg.norm(Sn - Cc) / np.linalg.norm(Cc)),
                       'naive_global_variance_ratio': float(np.trace(Pi0 @ Sn) / np.trace(Pi0 @ Cc)),
                       'naive_disagreement_ratio': float(np.trace(L @ Sn) / np.trace(L @ Cc))}
R['naive_coupling'] = naive
conv = []
for steps in (250, 1000, 4000):
    row = {'steps': steps}
    for eta in (0.0, 1.0):
        Se, _ = run_linear(exact_score, steps, eta)
        row[str(eta)] = float(np.linalg.norm(Se - Cc) / np.linalg.norm(Cc))
    conv.append(row)
R['naive_coupling_convergence'] = conv
check('exact noised coupling converges to the coupled target covariance (error falls with steps)',
      all(conv[i + 1][k] < 0.5 * conv[i][k] for i in range(2) for k in ('0.0', '1.0')) and conv[-1]['1.0'] < 2e-3)
check('constant coupling beta L misses the target covariance by over 10% (deterministic)',
      naive['0.0']['naive_cov_rel_error'] > 0.1)
check('constant coupling beta L makes the stochastic sampler unstable (a step radius above one)',
      naive['1.0']['naive_max_step_radius'] > 1 and naive['1.0']['exact_max_step_radius'] <= 1 + 1e-12)

# ---------------------------------------------------------------- Section 13: local reads and gluing
n_px = 10
train = np.array([[1, 1, -1, -1, -1, 1, 1, 1, -1, -1],
                  [1, 1, 1, 1, -1, -1, 1, 1, -1, -1],
                  [-1, -1, -1, 1, 1, 1, 1, -1, -1, -1]], float)


def windows(seq, w):
    r = w // 2
    return np.array([[seq[(p_ + k) % n_px] for k in range(-r, r + 1)] for p_ in range(n_px)])


def rotations(seq):
    return {tuple(np.roll(seq, k).astype(int)) for k in range(n_px)}


train_rot = set().union(*[rotations(y) for y in train])


def mosaic_set(w):
    pats = {tuple(v.astype(int)) for y in train for v in windows(y, w)}
    allseq = [np.array(b, float) for b in itertools.product([-1, 1], repeat=n_px)]
    return {tuple(sq.astype(int)) for sq in allseq if all(tuple(v.astype(int)) in pats for v in windows(sq, w))}, pats


def local_read(X, w, a, s):
    """Equivariant local read: pixel p reads the centre values of all training windows, weighted by window match."""
    pats = np.vstack([windows(y, w) for y in train])               # (K*n, w)
    r = w // 2
    Xw = np.stack([np.roll(X, -k, axis=1) for k in range(-r, r + 1)], axis=-1)   # (ns, n, w), Xw[:,p,j] = X[:, p+j-r]
    d2 = ((Xw[:, :, None, :] - a * pats[None, None]) ** 2).sum(-1)
    Wt = softmax(-d2 / (2 * s * s), axis=-1)
    return Wt @ pats[:, r]


def global_read(X, a, s):
    recs = np.vstack([np.roll(y, k) for y in train for k in range(n_px)])
    m, _ = mixture_read(X, recs, np.zeros(len(recs)), a, s)
    return m


def sample(readfn, ns, T, rng):
    a, s = cosine_schedule(T, smin=1e-4)
    X = rng.normal(size=(ns, n_px))
    for t in range(T, 0, -1):
        m = readfn(X, a[t], s[t])
        c, _ = ddim_coeffs(a[t], s[t], a[t - 1], s[t - 1], 0.0)
        X = a[t - 1] * m + c * (X - a[t] * m) / s[t]
    return X


mos = []
fix_err = 0.0; nonfix_min = 1e9
for w in (3, 5, 7, 9):
    M_, pats = mosaic_set(w)
    Xs = sample(lambda X, a, s: local_read(X, w, a, s), 3000, 100, rng)
    snapped = np.sign(Xs); clean = np.max(np.abs(Xs - snapped), 1) < 1e-3
    tuples = [tuple(v.astype(int)) for v in snapped]
    is_mos = np.array([t_ in M_ for t_ in tuples]) & clean
    is_train = np.array([t_ in train_rot for t_ in tuples]) & clean
    mos.append({'window': w, 'mosaics': len(M_), 'training_rotations': len(train_rot),
                'patterns': len(pats), 'share_clean': float(clean.mean()),
                'share_mosaic': float(is_mos.mean()), 'share_training_copy': float(is_train.mean()),
                'share_novel_mosaic': float((is_mos & ~is_train).mean()),
                'distinct_novel': len({t_ for t_, f in zip(tuples, is_mos & ~is_train) if f})})
    # fixed points of the clean local read among sign sequences, at small noise
    s_ = 0.05
    arr = np.array(sorted(M_), float)
    fix_err = max(fix_err, float(np.max(np.abs(local_read(arr, w, 1.0, s_) - arr))))
    allseq = np.array(list(itertools.product([-1, 1], repeat=n_px)), float)
    disp = np.max(np.abs(local_read(allseq, w, 1.0, s_) - allseq), 1)
    fixed = {tuple(v.astype(int)) for v, dd in zip(allseq, disp) if dd < 1e-9}
    pats_set = pats
    defect = [sum(tuple(v.astype(int)) not in pats_set for v in windows(sq, w)) for sq, f in zip(snapped, clean & ~is_mos) if f]
    if w == 3:
        nov = [[int(q) for q in t_] for t_, f in zip(tuples, is_mos & ~is_train) if f]
        uniq = []
        for v in nov:
            if v not in uniq: uniq.append(v)
        bad_ = [[int(q) for q in t_] for t_, f in zip(tuples, clean & ~is_mos) if f][:3]
        R['gluing_examples'] = {'train': train.astype(int).tolist(), 'novel': uniq[:5], 'nonmosaic': bad_}
    mos[-1].update({'fixed_points': len(fixed), 'mosaics_subset_of_fixed': M_ <= fixed,
                    'share_fixed': float(np.mean([t_ in fixed for t_ in tuples])),
                    'mean_gluing_defect_nonmosaic': float(np.mean(defect)) if defect else 0.0})
Xg = sample(global_read, 3000, 100, rng)
sg = np.sign(Xg); cg = np.max(np.abs(Xg - sg), 1) < 1e-3
glob = {'share_clean': float(cg.mean()),
        'share_training_copy': float((np.array([tuple(v.astype(int)) in train_rot for v in sg]) & cg).mean())}
R['gluing'] = {'pixels': n_px, 'training_examples': len(train), 'local': mos, 'global': glob,
               'mosaic_fixed_point_error': fix_err, 'min_nonmosaic_displacement': nonfix_min}
check('every gluable family of local records is a clean fixed point of the local read', fix_err < 1e-12)
check('mosaics form a subset of the clean fixed points for every window', all(r_['mosaics_subset_of_fixed'] for r_ in mos))
recs_all = np.vstack([np.roll(y, k) for y in train for k in range(n_px)])
allseq = np.array(list(itertools.product([-1, 1], repeat=n_px)), float)
gdisp = np.max(np.abs(global_read(allseq, 1.0, 0.05) - allseq), 1)
gfixed = {tuple(v.astype(int)) for v, dd in zip(allseq, gdisp) if dd < 1e-9}
R['gluing_global_fixed'] = len(gfixed)
check('clean fixed points of the global read are exactly the records', gfixed == train_rot)
check('the global read returns only training records (up to rotation)', glob['share_training_copy'] > 0.99)
check('the narrowest local read produces novel mosaics', mos[0]['share_novel_mosaic'] > 0.2)
check('most clean local-read samples are mosaics for every window', all(r_['share_mosaic'] > 0.5 for r_ in mos))
check('no novel mosaic exists once the window reaches 7 pixels', all(r_['mosaics'] == r_['training_rotations'] for r_ in mos if r_['window'] >= 7))

R['checks'] = tests; R['check_count'] = len(tests); R['all_checks_pass'] = all(t_['passed'] for t_ in tests)
(P / 'results_v2.json').write_text(json.dumps(R, indent=1) + '\n')
for t_ in tests:
    print(('PASS ' if t_['passed'] else 'FAIL ') + t_['name'])
print(json.dumps({k: v for k, v in R.items() if k not in ('checks', 'de_reach', 'reselection')}, indent=1)[:6000])
