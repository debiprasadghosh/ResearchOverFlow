"""Figures 4-7 of V2, drawn from results_v2.json only (plus the declared toy structures)."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from scipy.special import softmax

P = Path(__file__).resolve().parent
r = json.loads((P / 'results_v2.json').read_text())
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10.5, 'axes.spines.top': False,
                     'axes.spines.right': False})
blue, orange, grey, ink = '#28689b', '#c9692e', '#58636d', '#1f2328'

# ------------------------------------------------------------ Figure 4: reads among examples
peaks = np.array([[-2., -2.], [2., -2.], [-2., 2.], [2., 2.]])
fitness = lambda X: np.log(np.exp(-((X[:, None] - peaks[None]) ** 2).sum(-1) / 0.5).sum(1) + 1e-300)
snaps = r['de_reach']['snapshots']
fig = plt.figure(figsize=(10.2, 3.3))
gs = fig.add_gridspec(1, 4, width_ratios=[1, 1, 1, 1.45], wspace=0.12)
gs = fig.add_gridspec(1, 5, width_ratios=[1, 1, 1, .32, 1.45], wspace=0.08)
for k, t in enumerate(['100', '60', '35']):
    ax = fig.add_subplot(gs[0, k])
    X = np.array(snaps[t]['X']); sc = snaps[t]['noise_scale']
    a = 1 / np.sqrt(1 + sc * sc); s = sc * a
    W = softmax(fitness(X)[None] / 0.5 - ((X[:, None] - a * X[None]) ** 2).sum(-1) / (2 * s * s), axis=1)
    for j in range(0, len(X), 2):
        for kk in np.argsort(W[j])[-3:]:
            if kk != j and W[j, kk] > 0.05:
                ax.plot([X[j, 0], X[kk, 0]], [X[j, 1], X[kk, 1]], c=blue, lw=0.5, alpha=0.35)
    ax.scatter(X[:, 0], X[:, 1], s=5, c=ink, zorder=3)
    ax.scatter(peaks[:, 0], peaks[:, 1], marker='+', s=60, c=orange, zorder=4)
    lim = max(3.2, float(np.abs(X).max()) * 1.05)
    ax.set(xlim=(-lim, lim), ylim=(-lim, lim), xticks=[], yticks=[], aspect='equal')
    ax.set_title(f'({"abc"[k]}) noise scale {sc:.2g}', fontsize=10)
    for sp in ax.spines.values():
        sp.set_color('#c8ccd0'); sp.set_visible(True)
ax = fig.add_subplot(gs[0, 4])
rows = r['de_reach']['rows']
ns = [q['noise_scale'] for q in rows]
ax.plot(ns, [q['archive_reach'] for q in rows], c=blue, lw=2, label='DDIM, fixed archive')
ax.plot(ns, [q['de_reach'] for q in rows], c=orange, lw=2, label='Diffusion Evolution')
ax.set(xscale='log', yscale='log', xlabel='noise scale $s_t/a_t$', ylabel='horizontal reach (records read)')
ax.set_title('(d) reach of one read', fontsize=10)
ax.grid(alpha=.15, which='both'); ax.legend(frameon=False, fontsize=9, loc='center left')
fig.savefig(P / 'fig/reach.png', dpi=240, bbox_inches='tight', facecolor='white'); plt.close(fig)

# ------------------------------------------------------------ Figure 5: coupling in the noise
fig, axs = plt.subplots(1, 2, figsize=(9.4, 3.4), gridspec_kw={'width_ratios': [1, 1.35]})
B = np.array(r['noise_coupling_blocknorm'])
im = axs[0].imshow(B, cmap='Blues', vmin=0, vmax=1)
axs[0].set(xticks=range(len(B)), yticks=range(len(B)), xlabel='example j', ylabel='example i')
axs[0].set_title('(a) block norms of the noise correlation', fontsize=10)
for i in range(len(B)):
    for j in range(len(B)):
        axs[0].text(j, i, f'{B[i, j]:.2f}', ha='center', va='center', fontsize=7.5,
                    color='white' if B[i, j] > .6 else ink)
for sp in axs[0].spines.values():
    sp.set_visible(False)
sm = r['noise_coupling']['same_mode']
axs[1].plot([q['rho'] for q in sm], [q['same_mode'] for q in sm], 'o-', c=blue, lw=2, ms=6, label='coupled pair, DDIM')
axs[1].axhline(r['noise_coupling']['independent_same_mode'], c=grey, ls='--', lw=1.3, label='independent pair')
axs[1].set(xlabel='correlation ρ of the two noise draws', ylabel='probability both reach the same mode', ylim=(-.03, 1))
axs[1].set_title('(b) four-mode mixture, 6,000 pairs per ρ', fontsize=10)
axs[1].grid(alpha=.15); axs[1].legend(frameon=False, fontsize=9, loc='upper left')
fig.tight_layout(); fig.savefig(P / 'fig/noisecoupling.png', dpi=240, facecolor='white'); plt.close(fig)

# ------------------------------------------------------------ Figure 6: coupling in the target
sp_ = r['spectral']; p, beta = sp_['p'], sp_['beta']
mus = np.array([m['mu'] for m in sp_['modes']]); mus[np.abs(mus) < 1e-9] = 0
logsnr = np.linspace(-5, 8, 400); snr = np.exp(logsnr)
a2 = snr / (1 + snr); s2 = 1 / (1 + snr)
fig, axs = plt.subplots(1, 2, figsize=(9.6, 3.5))
cmap = plt.get_cmap('Blues')
for m_ in mus:
    rk = a2 / (a2 + s2 * (p + beta * m_))
    col = orange if m_ == 0 else cmap(0.35 + 0.6 * np.log1p(m_) / np.log1p(mus.max()))
    axs[0].plot(logsnr, rk, c=col, lw=2.2 if m_ == 0 else 1.2, zorder=3 if m_ == 0 else 2)
axs[0].text(-0.4, 0.82, 'global sections\n(μ = 0)', color=orange, fontsize=9, ha='right')
axs[0].text(5.4, 0.3, f'largest μ = {mus.max():.1f}', color=cmap(0.95), fontsize=9)
axs[0].axhline(0.5, c=grey, lw=.8, ls=':')
axs[0].set(xlabel='log signal-to-noise ratio  log($a_t^2/s_t^2$)', ylabel='resolved share of mode variance')
axs[0].set_title('(a) vertical order of horizontal modes', fontsize=10)
axs[0].grid(alpha=.15)
noise = np.linspace(0.02, 3, 400); aa = 1 / np.sqrt(1 + noise ** 2); ss = noise * aa
for m_, ls in ((0.5, '-'), (3.0, '--'), (15.0, '-.')):
    kap = aa ** 2 * beta * m_ / ((aa ** 2 + ss ** 2 * (p + beta * m_)) * (aa ** 2 + ss ** 2 * p))
    axs[1].plot(noise, kap / (beta * m_), c=blue, ls=ls, lw=1.8, label=f'μ = {m_:g}')
axs[1].axhline(1, c=orange, lw=1.8, label='naive constant coupling βμ')
axs[1].set(xlabel='noise scale $s_t/a_t$', ylabel='exact coupling κ / βμ', ylim=(0, 1.08))
axs[1].set_title('(b) coupling fades with noise', fontsize=10)
axs[1].grid(alpha=.15); axs[1].legend(frameon=False, fontsize=9)
fig.tight_layout(); fig.savefig(P / 'fig/spectral.png', dpi=240, facecolor='white'); plt.close(fig)

# ------------------------------------------------------------ Figure 7: gluing and mosaics
ex = r['gluing_examples']
rows_ = ex['train'] + ex['novel'] + ex['nonmosaic']
labels = ['training 1', 'training 2', 'training 3'] + [f'novel mosaic {k + 1}' for k in range(len(ex['novel']))] + \
         [f'gluing failure {k + 1}' for k in range(len(ex['nonmosaic']))]
fig = plt.figure(figsize=(10, 3.9))
gs = fig.add_gridspec(1, 2, width_ratios=[1, 1.25], wspace=0.35)
ax = fig.add_subplot(gs[0, 0])
cm = ListedColormap(['#e9edf1', ink])
ax.imshow((np.array(rows_) + 1) / 2, cmap=cm, aspect='auto', vmin=0, vmax=1)
for yy in (2.5, 2.5 + len(ex['novel'])):
    ax.axhline(yy, c=orange, lw=1.6)
ax.set(yticks=range(len(rows_)), xticks=range(10), xlabel='pixel')
ax.set_yticklabels(labels, fontsize=8.5)
ax.tick_params(length=0)
for sp in ax.spines.values():
    sp.set_visible(False)
ax.set_title('(a) samples from the window-3 local read', fontsize=10)
ax = fig.add_subplot(gs[0, 1])
loc = r['gluing']['local']
ws = [q['window'] for q in loc]; x = np.arange(len(ws))
c1 = np.array([q['share_training_copy'] for q in loc]); c2 = np.array([q['share_novel_mosaic'] for q in loc])
c3 = 1 - c1 - c2
ax.bar(x, c1, color=grey, width=.6, label='training copy (with rotations)', edgecolor='white', lw=2)
ax.bar(x, c2, bottom=c1, color=blue, width=.6, label='novel mosaic', edgecolor='white', lw=2)
ax.bar(x, c3, bottom=c1 + c2, color=orange, width=.6, label='gluing failure', edgecolor='white', lw=2)
gb = r['gluing']['global']['share_training_copy']
ax.bar(len(ws), gb, color=grey, width=.6, edgecolor='white', lw=2)
ax.set_xticks(list(x) + [len(ws)]); ax.set_xticklabels([f'window {w}' for w in ws] + ['global read'], fontsize=8.5)
for k, q in enumerate(loc):
    ax.text(k, 1.02, f"{q['mosaics']} mosaics", ha='center', fontsize=8, color=ink)
ax.text(len(ws), 1.02, '30 records', ha='center', fontsize=8, color=ink)
ax.set(ylim=(0, 1.12), ylabel='share of 3,000 samples')
ax.set_title('(b) what the sampler returns', fontsize=10)
ax.legend(frameon=False, fontsize=8.5, loc='upper center', bbox_to_anchor=(0.5, -0.13), ncol=3)
fig.savefig(P / 'fig/gluing.png', dpi=240, bbox_inches='tight', facecolor='white'); plt.close(fig)
print('Built four V2 figures from results_v2.json')
