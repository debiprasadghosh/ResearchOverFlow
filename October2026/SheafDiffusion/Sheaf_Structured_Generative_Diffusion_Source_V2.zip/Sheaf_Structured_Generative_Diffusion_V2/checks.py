"""Construction checks for Sheaf Structured Generative Diffusion. No trained-model benchmark."""
from pathlib import Path
import json,math,sys
import numpy as np
from scipy.special import logsumexp

P=Path(__file__).resolve().parent
rng=np.random.default_rng(20261018)
R={'seed':20261018,'python':sys.version.split()[0],'numpy':np.__version__,
   'status':'algebra and synthetic construction checks; no neural training or comparative generation benchmark'}
tests=[]
def check(name,value): tests.append({'name':name,'passed':bool(value)})

# DDIM algebra in the clean-coordinate frame, with matched random innovations.
err=0.; minlam=1.;maxlam=0.
for _ in range(1000):
    a=float(rng.uniform(.02,.95)); ap=float(rng.uniform(a,1.))
    s=math.sqrt(1-a*a);sp=math.sqrt(1-ap*ap)
    sig=float(rng.uniform(0,sp));c=math.sqrt(max(0,sp*sp-sig*sig))
    x,m,xi=rng.normal(size=(3,7))
    direct=(ap*m+c*(x-a*m)/s+sig*xi)/ap
    lam=1-a*c/(ap*s)
    alternate=(1-lam)*x/a+lam*m+sig/ap*xi
    err=max(err,float(np.max(np.abs(direct-alternate))/(1+np.max(np.abs(direct)))))
    minlam=min(minlam,lam);maxlam=max(maxlam,lam)
R['DDIM']={'trials':1000,'max_relative_identity_error':err,'minimum_lambda':minlam,'maximum_lambda':maxlam}
check('DDIM equals rescaled autoregressive update',err<1e-12)
check('monotone schedule produces convex coefficients',0<=minlam<=maxlam<=1)
a,ap=.4,.8;s=math.sqrt(1-a*a);sp=math.sqrt(1-ap*ap)
check('deterministic DDIM remains in the coefficient interval',0<=1-a*sp/(ap*s)<=1)
check('clean endpoint has unit read coefficient',1-a*0/(1*s)==1)

# A chain of three overlapping contexts has six local and four global coordinates.
D=np.array([[0.,1.,-1.,0.,0.,0.],[0.,0.,0.,1.,-1.,0.]])
_,sv,vt=np.linalg.svd(D,full_matrices=True)
rank=int(np.count_nonzero(sv>1e-12));U=vt[rank:].T;Pi=U@U.T
R['chain']={'local_dimension':6,'compatible_dimension':U.shape[1],'constraint_rank':rank,
            'delta':D.tolist(),'basis':U.tolist()}
check('compatible basis is annihilated by coboundary',np.max(np.abs(D@U))<1e-12)
check('compatible basis is orthonormal',np.max(np.abs(U.T@U-np.eye(4)))<1e-12)
check('compatible projection is idempotent',np.max(np.abs(Pi@Pi-Pi))<1e-12)

residual=0.;risk_identity=0.;risk_viol=0
for _ in range(1000):
    clean=U@rng.normal(size=4);pred=rng.normal(size=6)
    projected=Pi@pred
    before=float(np.sum((pred-clean)**2));after=float(np.sum((projected-clean)**2))
    extra=float(np.sum((pred-projected)**2))
    risk_identity=max(risk_identity,abs(before-after-extra)/(1+before));risk_viol+=after>before+1e-10
    for a in [.2,.6,.9]:
        x=a*clean+math.sqrt(1-a*a)*(U@rng.normal(size=4))
        residual=max(residual,float(np.max(np.abs(D@x))))
R['projection']={'trials':1000,'max_pythagorean_relative_error':risk_identity,'risk_increases':int(risk_viol),
                 'max_compatible_corruption_residual':residual}
check('intrinsic corruption stays compatible',residual<1e-12)
check('projection obeys Pythagorean identity',risk_identity<1e-12)
check('projection never increases clean reconstruction error',risk_viol==0)

rows=[];samples=100000
noise=rng.normal(size=(samples,6));projected_noise=noise@Pi
for scale in [.05,.1,.2,.4,.6,.8,1.]:
    values=(scale*noise)@D.T
    empirical=float(np.mean(np.sum(values*values,axis=1)))
    theory=float(scale**2*np.sum(D*D))
    compatible=float(np.mean(np.sum(((scale*projected_noise)@D.T)**2,axis=1)))
    rows.append({'noise_scale':scale,'ambient_mean_squared_residual':empirical,
                 'ambient_theory':theory,'compatible_mean_squared_residual':compatible})
R['noise']={'samples_per_scale':samples,'rows':rows,
            'max_relative_MC_error':max(abs(x['ambient_mean_squared_residual']/x['ambient_theory']-1) for x in rows)}
check('ambient residual matches noise-scale law',R['noise']['max_relative_MC_error']<.02)
check('compatible correlated noise has zero horizontal residual',max(x['compatible_mean_squared_residual'] for x in rows)<1e-24)
check('projected noise covariance is the compatible projector',np.max(np.abs((U@np.eye(4))@(U@np.eye(4)).T-Pi))<1e-12)

# Gaussian restriction kernels commute only with pushed-forward covariance.
restriction=rng.normal(size=(2,4));G=rng.normal(size=(4,4));Q=G@G.T
Qedge=restriction@Q@restriction.T
x=rng.normal(size=4);eps=rng.normal(size=4)
path_error=float(np.max(np.abs(restriction@(.6*x+.8*G@eps)-(.6*restriction@x+.8*restriction@G@eps))))
wrong_cov=float(np.linalg.norm(Qedge-np.eye(2)))
R['kernel']={'pathwise_commutation_error':path_error,'wrong_identity_covariance_defect':wrong_cov}
check('coupled Gaussian corruption commutes pathwise',path_error<1e-12)
check('edge covariance must be the pushforward covariance',wrong_cov>.1)
sign_delta=np.array([[-1.,1.,0.],[0.,-1.,1.],[1.,0.,1.]])
R['holonomy']={'negative_cycle_rank':int(np.linalg.matrix_rank(sign_delta)),'compatible_dimension':3-int(np.linalg.matrix_rank(sign_delta))}
check('negative sign holonomy leaves no nonzero compatible scalar noise',R['holonomy']['compatible_dimension']==0)

# A partial-observation harmonic displacement need not be a score.
Hs=[np.array([[1.,0.]]),np.array([[0.,1.]]),np.eye(2)]
ys=[np.array([0.]),np.array([0.]),np.array([1.,2.])]
def parts(z,ridge=0.):
    e=np.array([.5*np.sum((H@z-y)**2) for H,y in zip(Hs,ys)])
    w=np.exp(-e-logsumexp(-e))
    A=ridge*np.eye(2)+sum(wi*H.T@H for wi,H in zip(w,Hs))
    b=sum(wi*H.T@y for wi,H,y in zip(w,Hs,ys))
    return np.linalg.solve(A,b),A
def energy(z,ridge=.1):
    e=np.array([.5*np.sum((H@z-y)**2) for H,y in zip(Hs,ys)])
    return .5*ridge*(z@z)-logsumexp(-e)
z=np.array([.3,.7]);step=1e-5
J=np.column_stack([(parts(z+step*v)[0]-parts(z-step*v)[0])/(2*step) for v in np.eye(2)])
curl=float(J[0,1]-J[1,0]);maxg=0.
for _ in range(200):
    z0=rng.normal(size=2);m,A=parts(z0,.1)
    g=np.array([(energy(z0+step*v)-energy(z0-step*v))/(2*step) for v in np.eye(2)])
    maxg=max(maxg,float(np.max(np.abs(g-A@(z0-m)))))
R['score']={'query':z.tolist(),'cross_derivatives':[float(J[0,1]),float(J[1,0])],
            'naive_score_curl':curl,'gradient_trials':200,'max_energy_gradient_identity_error':maxg}
check('naive harmonic score has a nonzero curl counterexample',abs(curl)>.04)
check('precision-weighted read is the negative energy gradient',maxg<1e-7)

# A scalar precision family supplies an exact heat-flow diagnostic.
taus=[0.,.2,.5,1.,2.];grid=np.linspace(-2,2,81);heat=[]
for tau in taus:
    h=1/(1+tau);hp=-1/(1+tau)**2
    good=.5*(hp+h*h)*grid**2-.5*h
    bad_h=1+tau;bad_hp=1.
    bad=.5*(bad_hp+bad_h**2)*grid**2-.5*bad_h
    heat.append({'tau':tau,'valid_variance':1/h,'invalid_variance':1/bad_h,
                 'valid_spatial_residual_range':float(np.ptp(good)),
                 'invalid_spatial_residual_range':float(np.ptp(bad))})
R['heat']={'rows':heat}
check('Gaussian heat marginal satisfies spatial-constant residual',max(x['valid_spatial_residual_range'] for x in heat)<1e-12)
check('normalisable but wrong-time Gaussian fails heat consistency',min(x['invalid_spatial_residual_range'] for x in heat)>1)

# Condition first, then diffuse: independent posterior formulae agree.
posterior_error=score_error=0.
for _ in range(300):
    n=4;m=6
    G=rng.normal(size=(n,n));C0=G@G.T+.5*np.eye(n);mu=rng.normal(size=n)
    H=rng.normal(size=(m,n));obs=rng.normal(size=m);N=np.diag(rng.uniform(.4,2,m))
    C=np.linalg.inv(np.linalg.inv(C0)+H.T@np.linalg.solve(N,H))
    mean=C@(np.linalg.solve(C0,mu)+H.T@np.linalg.solve(N,obs))
    gain=C0@H.T@np.linalg.inv(H@C0@H.T+N)
    altmean=mu+gain@(obs-H@mu);altcov=C0-gain@H@C0
    posterior_error=max(posterior_error,float(np.max(np.abs(mean-altmean))),float(np.max(np.abs(C-altcov))))
    a=.6;s=.8;Ct=a*a*C+s*s*np.eye(n);x=rng.normal(size=n)
    denoise=mean+a*C@np.linalg.solve(Ct,x-a*mean)
    correct_score=-np.linalg.solve(Ct,x-a*mean)
    score_error=max(score_error,float(np.max(np.abs((a*denoise-x)/(s*s)-correct_score))))
R['conditional_Gaussian']={'trials':300,'max_posterior_formula_error':posterior_error,'max_score_denoiser_error':score_error}
check('information and covariance posterior formulae agree',posterior_error<1e-10)
check('conditioned Gaussian denoiser has the correct noised score',score_error<1e-10)

# Finite mixture clean estimate and its score in the ambient model.
means=rng.normal(size=(8,3));logprior=rng.normal(size=8);a=.6;s=.8;x=rng.normal(size=3)
def logdensity(x):
    return logsumexp(logprior-.5*np.sum((x-a*means)**2,axis=1)/s**2)
w=np.exp(logprior-.5*np.sum((x-a*means)**2,axis=1)/s**2-logdensity(x))
clean=w@means;g=np.array([(logdensity(x+step*v)-logdensity(x-step*v))/(2*step) for v in np.eye(3)])
mixture_error=float(np.max(np.abs(g-(a*clean-x)/s**2)))
R['mixture']={'score_gradient_error':mixture_error}
check('complete-record mixture has the standard denoiser-score identity',mixture_error<1e-8)

R['checks']=tests;R['check_count']=len(tests);R['all_checks_pass']=all(x['passed'] for x in tests)
(P/'results.json').write_text(json.dumps(R,indent=2)+'\n')
print(json.dumps({k:v for k,v in R.items() if k not in ['chain','checks','noise']},indent=2))
assert R['all_checks_pass']
