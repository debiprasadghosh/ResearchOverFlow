# 10 The example sheaf: a read among examples

This section takes the horizontal axis to run among records. Fix a finite set of records $y_1,\ldots,y_n\in\mathbb{R}^D$ with prior weights $\pi_i>0$ summing to one, and the variance-preserving schedule (2). Write $\sigma_t=s_t/a_t$ for the noise scale in clean coordinates.

**Definition 10.1 — The example star at level $t$.** The base is a star graph. Its centre $q$ is the state being denoised, and its leaves $1,\ldots,n$ are the records. Every stalk and edge stalk is $\mathbb{R}^D$. The restriction maps are identities for complete records, or the maps $H_i$ of Definition 2.2 for partial ones. The leaf values are the records, and edge $i$ carries the weight $\omega_i(x,t)$ defined below. The records do not change with $t$. The vertical axis acts on this horizontal sheaf only through its edge weights.

**Theorem 10.2 — The exact empirical denoiser is the harmonic read of the example star (classical, restated).** Let $p_0=\sum_i\pi_i\delta_{y_i}$ and $x_t=a_tx_0+s_t\epsilon$. At $x_t=x$ put

$$\omega_i(x,t)=\frac{\pi_i\exp(-\|x-a_ty_i\|^2/(2s_t^2))}{\sum_j\pi_j\exp(-\|x-a_ty_j\|^2/(2s_t^2))}. \tag{25}$$

Then the posterior mean is the minimiser of the star's weighted disagreement,

$$m_t(x)=\sum_i\omega_i(x,t)\,y_i=\arg\min_r\sum_i\omega_i(x,t)\|r-y_i\|^2, \tag{26}$$

and the score is $(a_tm_t(x)-x)/s_t^2$, as in (12). In clean coordinates $z=x/a_t$ the exponent is $-\|z-y_i\|^2/(2\sigma_t^2)$. Hence DDIM with the exact empirical denoiser is the ADE stack with identity maps, prior weights $\pi_i$ and read scale $\sigma_t$ (Theorem 3.1).

*Proof.* Bayes' rule gives the posterior weights (25), and the posterior mean is their average. The normal equations of the weighted least-squares problem are $(\sum_i\omega_i)r=\sum_i\omega_iy_i$, which give (26). The score identity is (12). Dividing the exponent by $a_t^2$ gives the clean-coordinate form. $\square$

The theorem is the identity-map special case of the harmonic read (8) with $P=0$ and $\beta=0$. With partial maps $H_i$ the same star gives the read $A^{-1}b$ of Section 4, which is no longer a posterior mean of this mixture (Proposition 4.2). So the reverse journey has a precise meaning. An ASE layer is a sheaf read among records. ADE freezes the records and uses identity maps. Uniform weights on a training set give the exact DDIM denoiser. A trained DDPM network is an approximation to that read. The checks confirm the harmonic form to @HARM_ERR@ and the score identity to @TW_ERR@.

**Corollary 10.3 — Clean-top re-selection (Part III, transferred).** If deterministic DDIM uses the exact read (26) and ends at $a_0=1$, its continuum limit returns record $y_i$ with probability $\pi_i$. This is Proposition 3.6 of Part III [12], transferred through Theorem 10.2.

A run of @RS_STEPS@ cosine-schedule steps from @RS_N@ standard normal starts tested this. The run used five records with weights 0.35, 0.25, 0.20, 0.12 and 0.08. @RS_SHARE@ of the outputs lay within $10^{-3}$ of a record. Their frequencies differed from the prior weights by total variation @RS_TV@. An exact example-sheaf diffusion therefore memorises, which agrees with the memorisation literature [15]. Any generalisation must come from the ways a trained denoiser *fails* to reproduce (26). Section 13 makes one such failure exact.

**Theorem 10.4 — Diffusion Evolution is a lazy consensus step on the population graph (new in V2).** DE [4] uses its current population $X_t=(x^{(1)},\ldots,x^{(n)})$ as the records. Each member reads the whole population with fitness weights $g(f(x^{(k)}))$, so that $m^{(j)}=\sum_kW_{jk}x^{(k)}$ with

$$W_{jk}=\frac{g(f(x^{(k)}))\exp(-\|x^{(j)}-a_tx^{(k)}\|^2/(2s_t^2))}{\sum_lg(f(x^{(l)}))\exp(-\|x^{(j)}-a_tx^{(l)}\|^2/(2s_t^2))}. \tag{27}$$

With $\sigma_t=0$ in (4), the population moves exactly by

$$X_{t-1}=r_t\left[(1-\theta_t)I+\theta_tW_t\right]X_t, \tag{28}$$

$$r_t=\frac{c_t}{s_t}+a_{t-1}-\frac{a_tc_t}{s_t},\qquad \theta_t=\frac{1}{r_t}\left(a_{t-1}-\frac{a_tc_t}{s_t}\right)\in[0,1]. \tag{29}$$

The matrix $P_t=(1-\theta_t)I+\theta_tW_t$ is row-stochastic. For any norm, the population diameter therefore obeys

$$\text{diam}(X_{t-1})\le r_t\,\tau(P_t)\,\text{diam}(X_t),\qquad \tau(P)=\frac{1}{2}\max_{j,j'}\sum_k|P_{jk}-P_{j'k}|. \tag{30}$$

*Proof.* Substituting $\widehat\epsilon=(x-a_tm)/s_t$ into (4) gives $x'=(c_t/s_t)x+(a_{t-1}-a_tc_t/s_t)m$, whose coefficients sum to $r_t$. Monotonicity gives $c_t\le s_{t-1}\le s_t$ and $a_t\le a_{t-1}$. Both coefficients are therefore non-negative, so $\theta_t\in[0,1]$. For rows $j,j'$ the difference $(PX)_j-(PX)_{j'}=\sum_k(P_{jk}-P_{j'k})x^{(k)}$ has coefficients summing to zero. Their positive and negative parts each have mass $\frac12\sum_k|P_{jk}-P_{j'k}|\le\tau(P)$, and each part is that mass times a convex combination of members. The difference of two convex combinations is at most the diameter, which gives (30). This is the Dobrushin contraction argument [16]. $\square$

The theorem makes the two axes literal. Horizontally, $I-W_t$ is the random-walk Laplacian of the constant sheaf $\mathbb{R}^D$ on a weighted graph over the population, whose edges are kernel affinities tilted by fitness. Vertically, the schedule supplies the step $\theta_t$, the overall scale $r_t$ and the kernel bandwidth $\sigma_t$. A deterministic DE run is a forward-Euler sheaf diffusion among examples whose graph sharpens as noise falls. Replacing $W_tX_t$ by the harmonic read with maps $H_i$ turns the step into the ASE sheaf diffusion of Part II [10]. DE also treats its noisy members as clean records. That is why its target moves from step to step (Section 3.1).

The identity (28) was checked on @DE_N@ random steps to a largest relative error of @DE_ERR@. Over these steps $\theta_t$ ranged from @DE_TH_MIN@ to @DE_TH_MAX@, and the bound (30) had @DE_VIOL@ violations. The largest ratio of observed diameter to bound was @DE_RATIO@, so the bound is attained.

![Figure 4. Reads among examples. (a)–(c) A stochastic DE population of 256 members on a four-peak fitness (orange crosses) at three noise scales $s_t/a_t$. Lines join each plotted member to its strongest reads, the edges of the kernel graph $W_t$ in (27). The graph is nearly complete at high noise and splits into niches as the noise falls. (d) Horizontal reach, the effective number of records one read uses, $1/\sum_kW_{jk}^2$, averaged over members. With a fixed archive of 256 records the reach falls from @REACH_A0@ to @REACH_A1@. In DE the fitness weights already concentrate the read at high noise: the reach starts at @REACH_D0@, peaks at @REACH_DMAX@ and ends at @REACH_D1@.](fig/reach.png){width=100%}

The horizontal reach in Figure 4 summarises how the vertical axis reshapes the horizontal graph. At high noise one read averages almost the whole archive. At the clean end it reads about one record. A schedule designer can therefore read off, at each level, how many examples influence a state, which is the among-example analogue of the receptive field.

# 11 Coupling generated examples in the noise

Now let the horizontal axis connect the *generated* examples $x^1,\ldots,x^N\in\mathbb{R}^d$ of one batch. Put a cellular sheaf on a graph over the batch, with stalks $\mathbb{R}^d$, edge stalks $\mathbb{R}^{d_e}$ and restriction maps. Its coboundary $\delta$ and sheaf Laplacian $L=\delta^\top W\delta$ act on the stacked batch $X\in\mathbb{R}^{Nd}$ [5, 17]. Version 1 noted that separate candidates normally use independent innovations. That is the default, not a requirement. There are three places a horizontal coupling across the batch can enter: the noise (this section), the target (Section 12) and the read (Section 13). They have different consequences.

**Proposition 11.1 — Marginal-preserving horizontal noise (new in V2).** Run $N$ copies of a DDPM or DDIM sampler (4). Each copy uses the same per-example denoiser, and the clean prediction for $x^j$ depends on $x^j$ alone. Let the terminal draw and the innovations of each step be jointly Gaussian on $\mathbb{R}^{Nd}$ with covariance $K$, independent across steps. If every diagonal block is $K_{jj}=I_d$, then each example's path has exactly the law of the independent sampler. If, in addition, the denoiser is affine and $K=R\otimes I_d$ with correlations $\rho_{jk}$, then

$$\text{Cov}(x_0^j,x_0^k)=\rho_{jk}\,\text{Var}(x_0^j). \tag{31}$$

*Proof.* The path of copy $j$ is a fixed measurable function of its own terminal draw and innovations. These are jointly Gaussian with zero mean, identity covariance and independence across steps, exactly as in the independent sampler. For an affine denoiser, $x_0^j=b+\sum_tM_t\xi_t^j$ with common matrices $M_t$. Hence $\text{Cov}(x_0^j,x_0^k)=\sum_tM_t\rho_{jk}M_t^\top=\rho_{jk}\text{Var}(x_0^j)$. $\square$

Any example graph supplies admissible correlations through a normalised sheaf heat kernel,

$$K=B^{-1/2}e^{-\tau L}B^{-1/2},\qquad B=\text{blockdiag}_j\left(e^{-\tau L}\right)_{jj}. \tag{32}$$

$K$ is positive semidefinite with identity diagonal blocks, and its off-diagonal blocks decay with sheaf distance. The normalisation is essential. The raw kernel $e^{-\tau L}$ changes the marginals: in the check its per-example covariance error was @NC_BAD@.

The checks used a six-example sheaf with stalk dimension 3, seven edges and random $2\times3$ restriction maps, with $\tau=0.6$. For Gaussian data and the exact affine denoiser, the per-example covariance was propagated exactly through 400 steps. With $K$ from (32), each diagonal block matched the independent sampler to @NC_MARG@ for both $\eta=0$ and $\eta=1$. The off-diagonal blocks were as large as @NC_CROSS@. For a scalar correlation $\rho=0.6$, (31) held to @NC_TRANSFER@.

![Figure 5. Coupling in the noise. (a) Spectral norms of the blocks of the normalised sheaf heat kernel (32) on the six-example test sheaf; the diagonal blocks are exactly the identity. (b) Pairs of deterministic DDIM samples from a symmetric four-mode mixture, with noise draws correlated by $\rho$; 6,000 pairs per value. Each sample is marginally exact, yet the probability that both reach the same mode moves from @SM_M1@ at $\rho=-1$ to @SM_09@ at $\rho=0.9$. Independent pairs give @SM_IND@.](fig/noisecoupling.png){width=100%}

For non-Gaussian data the correlation of outputs is a nonlinear function of $\rho$, but the marginals remain exact. In Figure 5, antithetic noise ($\rho=-1$) never sends a pair to the same mode. That result is exact for this example: the mixture is symmetric under $x\mapsto-x$, and deterministic DDIM inherits the symmetry. Noise coupling is therefore a way to control the diversity of a batch at no cost to fidelity. Particle guidance [14] also produces non-independent batches, but by adding a joint potential to the dynamics. Proposition 11.1 identifies a narrower operation that leaves every marginal untouched. Noise coupling does not make outputs compatible: $\delta X_0\ne0$ in general. Compatibility of outputs requires coupling in the target.

# 12 Coupling generated examples in the target

Suppose instead that the batch is meant to be a coupled object, such as a family of designs that must agree on shared interfaces. Declare the clean joint prior

$$p_0(X)\propto\prod_j\mathcal{N}(x^j;m_0,p^{-1}I_d)\,\exp\left(-\frac{\beta}{2}\|\delta X\|_W^2\right), \tag{33}$$

a Gaussian with precision $\Lambda=pI+\beta L$, covariance $C=\Lambda^{-1}$ and mean $\mu=pC(\mathbf{1}\otimes m_0)$. This changes the target: unlike Section 11, the marginals of individual examples change. The forward noise is independent across examples, as in ordinary diffusion. Following Section 8, condition first and diffuse second.

**Theorem 12.1 — The coupled denoiser is one implicit sheaf heat step (new in V2).** For the target (33),

$$D_t(X)=\mu+\frac{a_t}{a_t^2+ps_t^2}\,(I+h_tL)^{-1}(X-a_t\mu),\qquad h_t=\frac{\beta s_t^2}{a_t^2+ps_t^2}. \tag{34}$$

Consequently, $D_t$ commutes with every function of $L$, including horizontal heat flow $e^{-\tau L}$. It leaves directions in $\ker L$, the global sections, unsmoothed.

*Proof.* By (21), $D_t(X)=\mu+a_tCS_t^{-1}(X-a_t\mu)$ with $S_t=a_t^2C+s_t^2I$. Since $CS_t^{-1}=(a_t^2I+s_t^2\Lambda)^{-1}=((a_t^2+ps_t^2)I+\beta s_t^2L)^{-1}$, factoring out $a_t^2+ps_t^2$ gives (34). $\square$

Every vertical denoising step thus performs one backward-Euler step of horizontal sheaf diffusion, with a step $h_t$ that grows from zero at the clean end to $\beta/p$ in pure noise. This is the exact sense in which, for this model, "vertical = denoising" and "horizontal = diffusion among examples" are two factors of a single operator. The checks confirm (34) to @SP_RES@ and the commutation with $e^{-0.3L}$ to @SP_COMM@.

**Theorem 12.2 — Vertical order of horizontal modes (new in V2).** Let $Lu_k=\mu_ku_k$ with orthonormal $u_k$. The share of the clean variance of mode $k$ that the denoiser has resolved at level $t$ is

$$\varrho_k(t)=\frac{a_t^2c_k}{a_t^2c_k+s_t^2}=\frac{a_t^2}{a_t^2+s_t^2(p+\beta\mu_k)},\qquad c_k=\frac{1}{p+\beta\mu_k}. \tag{35}$$

It crosses one half at signal-to-noise ratio $a_t^2/s_t^2=p+\beta\mu_k$. The global sections ($\mu_k=0$) are resolved first, at ratio $p$. The disagreement modes are resolved later, in increasing order of $\mu_k$.

*Proof.* $C$, $S_t$ and $D_t$ are diagonal in the basis $u_k$. The mode variance is $c_k$, and the resolved share of a scalar Gaussian observed at signal $a_t$ and noise $s_t$ is $a_t^2c_k/(a_t^2c_k+s_t^2)$. $\square$

The vertical axis therefore sorts the horizontal spectrum. A coupled batch is first decided as a consensus, and only later as a set of differences. In the six-example test sheaf, $L$ has @SP_H0@ global sections. Its positive eigenvalues run from @SP_MUMIN@ to @SP_MUMAX@, so with $p=1$ and $\beta=2$ the half-resolution ratios run from 1 to @SP_SNRMAX@. The crossings measured from the exact gain along a fine schedule matched $\log(p+\beta\mu_k)$ to @SP_LOGERR@.

**Theorem 12.3 — The noised coupling schedule (new in V2).** The noised score of (33) is $-S_t^{-1}(X-a_t\mu)$ with

$$S_t^{-1}=\frac{p}{a_t^2+ps_t^2}I+\sum_k\kappa(\mu_k,t)\,u_ku_k^\top,\qquad \kappa(\mu,t)=\frac{a_t^2\beta\mu}{(a_t^2+s_t^2(p+\beta\mu))(a_t^2+ps_t^2)}. \tag{36}$$

The coupling equals $\beta\mu$ at the clean end and fades with noise: $\kappa\le\beta\mu\,a_t^2/(a_t^2+ps_t^2)^2$. For hard constraints it saturates in every incompatible mode,

$$\kappa(\mu,t)\to\frac{a_t^2}{s_t^2(a_t^2+ps_t^2)}\quad(\mu>0),\qquad D_t(X)\to\mu+\frac{a_t}{a_t^2+ps_t^2}\Pi_0(X-a_t\mu)\qquad(\beta\to\infty), \tag{37}$$

where $\Pi_0$ is the orthogonal projection onto $\ker L$.

*Proof.* The precision of mode $k$ in $S_t$ is $(p+\beta\mu_k)/(a_t^2+s_t^2(p+\beta\mu_k))$. Subtracting the uncoupled value $p/(a_t^2+ps_t^2)$ gives $\kappa$. The bound follows from $a_t^2+s_t^2(p+\beta\mu)\ge a_t^2+ps_t^2$. The limits follow by letting $\beta\mu\to\infty$ in $\kappa$ and in $(I+h_tL)^{-1}$, whose action on $\ker L$ is the identity. $\square$

Equation (37) reconnects Version 2 to Version 1. In the hard limit the total precision of an incompatible mode is $\kappa+p/(a_t^2+ps_t^2)=1/s_t^2$. A disagreement mode of a compatible target is therefore pure forward noise of variance $s_t^2$, which is Theorem 6.1. The limiting denoiser projects onto global sections, which is Proposition 6.2. The soft coupling $\beta$ interpolates between independent generation ($\beta=0$) and the compatible ambient model of Family A ($\beta\to\infty$).

The closed form (36) matched the exact difference of precisions to @KAP_ERR@. As $\beta$ rose through $10$, $10^2$, $10^3$ and $10^4$ at $a=0.6$, the distance from the gain to the scaled projection fell as @LIM_10@, @LIM_100@, @LIM_1000@ and @LIM_10000@, which is first order in $1/\beta$. The saturation value at that level is @SAT@.

![Figure 6. Coupling in the target. (a) Resolved share $\varrho_k(t)$ of every horizontal mode of the six-example sheaf, from (35). The global sections (orange) are decided first, and the largest disagreement mode last; the dotted line marks half resolution. (b) The exact noised coupling $\kappa(\mu,t)$ of (36), relative to its clean value $\beta\mu$, against the noise scale $s_t/a_t$ for three eigenvalues. A constant coupling (orange) keeps the clean value at every level.](fig/spectral.png){width=100%}

A tempting shortcut adds the clean coupling force $-\beta LX$ to an uncoupled noised score at every level, treating the clean potential as if it survived noising. Theorem 12.3 says this overstates the coupling at every $s_t>0$, and most in the high-frequency modes. Exact covariance propagation through 1,000 steps quantifies the error. With the exact score of (36), the relative covariance error was @NV_EXACT0@ for deterministic DDIM and @NV_EXACT1@ for the stochastic sampler. These errors fell with the step count: at 250, 1,000 and 4,000 steps they were @CONV_250@, @CONV_1000@ and @CONV_4000@ (deterministic). With the constant shortcut, the deterministic sampler missed the target covariance by @NV_EX0@. It kept @NV_GLOB@ of the global-section variance but only @NV_DIS@ of the disagreement variance: it over-glues the batch. The stochastic sampler with the shortcut diverged. One step map had spectral radius @NV_RAD1@, whereas no step of the exact sampler exceeded one. This is the among-example form of V1's rule *condition first and diffuse second*.

# 13 Two horizontals together: local reads, gluing and novelty

Version 1's horizontal (a cover inside each example) and Section 10's horizontal (records among examples) combine naturally. Let each example be a signal on $n$ pixels with circular boundary. Cover the pixels by windows $U_p=\{p-r,\ldots,p+r\}$. A *local read* lets pixel $p$ consult the records only through their restrictions to windows:

$$m_t(x)_p=\sum_q\omega_q(x,t)\,y_q(c),\qquad \omega_q\propto\exp\left(-\frac{\|x_{U_p}-a_ty_q\|^2}{2s_t^2}\right). \tag{38}$$

Here $x_{U_p}$ is the restriction of $x$ to the window $U_p$, $q$ runs over all training windows at all positions (translation equivariance), and $y_q(c)$ is the centre value of window $q$. In sheaf terms, (38) is the harmonic read of Section 4 in which the observation maps $H_i$ are window restrictions. Kamb and Ganguli showed that locality and equivariance constraints turn the ideal denoiser into a patch-mosaic machine whose outputs predict those of trained convolutional diffusion models [13]. The statement below recasts that mechanism as gluing.

Let the *data presheaf* assign to each window the set of training windows. A *mosaic* is a signal every window of which is a training window, which is a global section of the window-level data. Every record and every rotation of a record is a mosaic. The converse fails whenever two records share enough overlap to be spliced.

**Proposition 13.1 — Mosaics are clean fixed points (new in V2).** Let $a_t=1$ and $s_t\to0$. Every mosaic $x$ satisfies $m_t(x)=x$, with an error that decays like $\exp(-g^2/(2s_t^2))$, where $g$ is the smallest distance from a window of $x$ to a non-matching training window. On sign signals $\{\pm1\}^n$, the clean fixed points of the *global* read (window equal to the whole signal) are exactly the records and their rotations.

*Proof.* For a mosaic, each window $x_{U_p}$ coincides with at least one training window. All exact matches carry the centre value $x_p$, and every other window has weight $O(\exp(-g^2/(2s_t^2)))$. For the global read, the clean limit averages the nearest records. If $x$ is not a record, each nearest record differs from $x$ in some pixel. Since all values are $\pm1$, their average can equal $x$ at every pixel only if every nearest record equals $x$, which is a contradiction. $\square$

A toy test used $n=10$ pixels and three training records whose runs all have length at least two, giving 30 records with rotations. Enumerating all $2^{10}$ sign signals counts @GL_M3@ mosaics for window 3, @GL_M5@ for window 5, and @GL_M7@ for windows 7 and 9: wide windows leave no room to splice. Mosaics were exactly the clean fixed points for window 3. Fixed points were more numerous for wider windows (@GL_F5@ against @GL_M5@ mosaics at window 5), because a pixel can be fixed without its window being a training window. Deterministic DDIM with the local read (38) then generated 3,000 samples per window over 100 steps (Figure 7).

![Figure 7. Two horizontals together. (a) The three training records, five novel mosaics and three gluing failures produced by the window-3 local read (38); dark pixels are $+1$. Every window of a mosaic occurs in some training record, but no mosaic is a rotation of a record. Each gluing failure contains an isolated pixel, a window that no record contains. (b) Shares of 3,000 deterministic DDIM samples that are training copies, novel mosaics or gluing failures, for four window widths and for the global read. Numbers above the bars count all mosaics, including the 30 rotations of the records.](fig/gluing.png){width=100%}

Table: **Table 2.** What the local read returns. Shares of 3,000 deterministic DDIM samples, 100 steps; *distinct* counts different novel outputs; *defect* is the mean number of windows outside the training set among gluing failures.

| Window | Mosaics | Copies | Novel mosaics | Distinct novel | Gluing failures | Defect |
|:--|--:|--:|--:|--:|--:|--:|
| 3 | @GL_M3@ | @GL_C3@ | @GL_N3@ | @GL_U3@ | @GL_G3@ | @GL_D3@ |
| 5 | @GL_M5@ | @GL_C5@ | @GL_N5@ | @GL_U5@ | @GL_G5@ | @GL_D5@ |
| 7 | @GL_M7@ | @GL_C7@ | @GL_N7@ | @GL_U7@ | @GL_G7@ | @GL_D7@ |
| 9 | @GL_M9@ | @GL_C9@ | @GL_N9@ | @GL_U9@ | @GL_G9@ | @GL_D9@ |
| Global | 30 | @GL_CG@ | 0.0% | 0 | 0.0% | – |

The table separates two meanings of novelty. Novel mosaics are global sections of the local data that are not restrictions of any single record. They are what an example sheaf with a narrow cover can create, and they disappear once the window is wide enough to identify the record. Gluing failures are outputs in which neighbouring pixels chose incompatible windows, so the local choices do not glue into a section. Their defect, the number of windows outside the training set, is the residual of a horizontal compatibility check of the kind in Section 6, computed on generated outputs. The cover width of Part I [9] therefore acts as a novelty budget. The global read can only memorise (Corollary 10.3). A narrow read can splice, and it pays for this with gluing failures that a sheaf residual can detect and reject. This is a count on a toy alphabet, not a claim about images.
