---
title: Sheaf Structured Generative Diffusion
subtitle: Horizontal relations among examples and vertical denoising from ASE back to DDPM and DDIM. Version 2
author:
  - Debi Prasad Ghosh
  - Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India
date: 19 October 2026 · Version 2 · Defensible Intelligence series · “Respect science. Import emotion.”
---

## Abstract

Autoregressive Sheaf Evolution (ASE) replaces whole-record averaging by reads through calibrated partial-observation maps. Its ancestry runs from DDPM and DDIM through Diffusion Evolution (DE) and Autoregressive Diffusion Evolution (ADE). This paper traces that route backwards with one organising rule: the denoising direction is vertical, and the relation among examples is horizontal. Version 1 placed the horizontal structure inside one candidate and set out the probability obligations; those results are retained. Version 2 takes the horizontal axis literally as a sheaf over examples, and proves where it sits in an ordinary diffusion sampler. The exact denoiser of an empirical training set is the harmonic read of an example star, so DDIM with that read is the ADE stack. With a clean top it returns training records at their prior frequencies: in @RS_N@ samples all landed on records, with total-variation error @RS_TV@. A deterministic DE step is exactly a lazy consensus step on the population's kernel graph. The schedule supplies the step and the bandwidth, and a Dobrushin bound controls the population's diameter. For a generated batch, horizontal coupling can be placed in three places with different consequences. Noise correlated across examples by a normalised sheaf heat kernel leaves every example's marginal unchanged, and for Gaussian data it transmits each correlation exactly. Coupling in the target makes the exact denoiser one implicit sheaf heat step across the batch. It resolves the global sections first and the disagreement modes in increasing order of their Laplacian eigenvalues. The exact noised coupling follows a closed-form spectral schedule that fades with noise. A constant coupling instead missed the target covariance by @NV_EX0@ in a deterministic sampler and made a stochastic sampler diverge. Finally, combining a local cover within examples with records among examples makes every gluable family of local records a clean fixed point. Narrow windows therefore generate novel mosaics: in a window-3 toy read they made up @GL_N3@ of the samples. There are @TOTAL_CHECKS@ reproducible checks, and an immutable C# kernel agrees with an independent NumPy implementation. No trained-model generation or optimisation advantage is claimed.

**Keywords:** cellular sheaf; sheaf Laplacian; denoising diffusion; DDPM; DDIM; empirical denoiser; diffusion evolution; correlated noise; memorisation; patch mosaic.

# 1 The reverse journey

The organising proposal is simple: denoising depth is vertical, and relationships among examples or their local descriptions are horizontal. A sheaf records what can be compared at one noise level. A diffusion model specifies how distributions over those representations change with noise. Combining them requires both a geometric construction and a probability model.

The ASE programme began with diffusion models, passed through Diffusion Evolution (DE) and Autoregressive Diffusion Evolution (ADE), and then replaced the single Euclidean read by a sheaf-based read [4, 8–10, 12]. Reversing this route is productive because the DDIM sampler already accepts a predicted clean state. The question becomes which clean-state estimators retain a probabilistic interpretation when their observations are partial and their coordinates are related by restriction maps.

Table: **Table 1.** The reverse journey. Each row keeps the vertical denoising axis and changes what the horizontal axis connects; the last column names the exact link proved in this paper.

| Stage | Horizontal: among examples | Vertical: denoising | Exact link |
|:--|:--|:--|:--|
| ASE | Observation star with partial maps; harmonic read | Layer stack with scale-dependent covers | Read with maps $H_i$ (4.1, 13.1) |
| ADE | Frozen evaluated archive with identity maps | Prescribed autoregressive schedule | DDIM in clean coordinates (3.1) |
| DE | The current population reads itself | DDIM step on a moving archive | Lazy consensus step (10.4) |
| DDIM, empirical | Training set as the leaves of an example star | Exact reverse of a declared corruption | Harmonic read (10.2, 10.3) |
| DDPM, learned | A network approximates the example-star read | Stochastic reverse kernel | Local read and gluing (13.1) |
| Coupled batch | A sheaf on the generated examples | Noise coupling or target coupling | Propositions 11.1, 12.1–12.3 |

Here ADE and ASE refer to the project constructions [8–10, 12], rather than to a claim that those names describe established generative-model families. DE is the method of Zhang and colleagues [4]. The ancestry is conceptual and algebraic; it does not imply that every later optimiser samples the same density as its predecessor.

DDPM defines a Gaussian forward chain and learns a reverse model [1]. DDIM supplies related sampling processes using the same denoising training objective [2]. Score-based formulations make the time-dependent density gradient explicit [3]. Neural Sheaf Diffusion supplies horizontal operators for graph representation learning [5]. The latter use of diffusion is not, by itself, a DDPM reverse-time construction. The 2026 work on deep sheaf networks and sheaf views of attention also concerns relational architectures, not a proof that an arbitrary sheaf read is a generative score [6, 7].

## 1.1 What Version 2 adds

Version 1 used the word *horizontal* mainly for the local views of one candidate: a cover of its coordinates, shared observables on overlaps, and compatibility $\delta X=0$. Sections 2 to 9 keep that material. Version 2 adds the reading the ASE journey actually started from, in which the horizontal axis runs *among examples*. There are two kinds of example, and they must not be confused. *Records* are training examples, archive entries or population members that a read consults. *Generated examples* are the members of a batch being sampled. Section 10 treats records and Sections 11 and 12 treat generated examples. Section 13 combines the records with the local cover of Version 1.

The new results are the following.

- **The example star (Section 10).** The exact empirical denoiser is the harmonic read of a star sheaf whose leaves are the training records. The vertical axis acts only on its edge weights (Theorem 10.2). A clean-top DDIM with this read re-selects records at their prior frequencies (Corollary 10.3). A deterministic DE step is exactly a lazy consensus step on the population's kernel graph, with a Dobrushin bound on the population's diameter (Theorem 10.4).
- **Coupling in the noise (Section 11).** Correlated innovations whose diagonal blocks are identity leave every example's marginal law unchanged. For an affine denoiser they transmit each correlation exactly (Proposition 11.1). A normalised sheaf heat kernel supplies such correlations from any example graph.
- **Coupling in the target (Section 12).** For a sheaf-coupled Gaussian batch, the exact denoiser is one implicit step of sheaf heat flow across the batch (Theorem 12.1). Horizontal modes are resolved in the order of their Laplacian eigenvalues, global sections first (Theorem 12.2). The noised coupling follows a closed-form schedule that fades with noise and saturates for hard constraints (Theorem 12.3). A constant coupling fails.
- **Two horizontals together (Section 13).** With a window cover inside each example and records among examples, every gluable family of local records is a clean fixed point of the local read. Narrow windows therefore produce novel mosaics, while the global read can only return records (Proposition 13.1).
- **Implementation and evidence.** New model families E to H, an algorithm for a coupled batch, an immutable C# kernel validated line by line against NumPy (Appendix A), and @V2_CHECKS@ new checks, giving @TOTAL_CHECKS@ in all.

The contribution of this paper is a set of explicit constructions and obligations connecting these ideas. The elementary linear algebra and Gaussian identities are presented with proofs. Statements marked *new in V2* are, to our knowledge, new in this programme; classical results restated in this notation are marked as such. We make no priority claim for combining geometry and generative modelling, and no empirical claim that the proposed combination improves generation.
