# 14 Implementable model families

The first implementations should freeze maps and the horizontal base. This avoids confounding a new probability model with the separate problem of learning the base. Families A to D place the horizontal structure within examples. Families E to H, new in Version 2, place it among examples.

**Family A — Ambient sheaf denoising.** Assemble compatible clean examples in $C^0$, draw ordinary full-dimensional forward noise, and train a clean or noise predictor with the declared DDPM objective. Use sheaf message passing internally and optionally constrain the clean output to $V$. At sampling time, retain ordinary DDPM/DDIM coordinates and noise. Report noisy residuals relative to (15), rather than labelling all disagreement inconsistent. Projection must use independently justified constraints.

**Family B — Intrinsic sheaf denoising.** Compute or implement the compatible parameterisation $U$. Encode each clean example by $h_0=U^\top X_0$, train (18), sample in $h$-coordinates, and lift only when local outputs are needed. This guarantees compatibility by construction. It also changes the noise covariance relative to ambient diffusion; controls must account for this and for any dimension reduction.

**Family C — Archive based sheaf evolution.** At each layer, retrieve records, form the harmonic read, and use (4) or the equivalent (5). Fitness weights and archive updates can be retained for optimisation. Without a matched clean distribution and forward process, describe this as a diffusion-inspired proposal algorithm. Evaluate decoded candidates before admitting them to the fitness archive. Predicted combinations are not observations.

**Family D — Conditional probabilistic reference.** Specify the clean posterior or factor model first, then derive or learn its noised scores. The Gaussian instance of Section 8 needs no neural training and can verify the sampler, covariance conventions and local-to-global assembly. It is a reference calculation, not a competitive high-dimensional generative architecture by itself.

**Family E — Example-star sampler.** Use the exact read (26) over a frozen record set, with uniform weights for a training set or fitness weights for an archive. It is the exact DDIM sampler of the empirical measure. It is the reference against which a trained denoiser's memorisation is measured, and with the population as its own archive it is DE (Theorem 10.4). Report the horizontal reach at every level.

**Family F — Horizontally coupled noise.** Keep any trained per-example denoiser and draw the batch's innovations with the correlation (32) of a declared example graph. Marginals are untouched (Proposition 11.1), so the family needs no retraining. It changes only the joint law of a batch, for example its diversity or its coverage of modes.

**Family G — Coupled-target sampler.** For a batch that must agree on shared observables, declare the coupling (33) on the clean batch. Sample it with the exact denoiser (34), or, when per-example scores are learned, add the scheduled coupling $-\sum_k\kappa(\mu_k,t)u_ku_k^\top X$ of (36) rather than the clean force $-\beta LX$. For non-Gaussian examples the scheduled coupling is exact only in the Gaussian case; elsewhere it is a surrogate whose error must be measured (H6).

**Family H — Local-read generator.** Use window restrictions as the maps of the example star (38), with the window width as a declared novelty budget. Monitor the gluing defect of every output. Reject or resample outputs whose defect is positive when the application requires globally consistent sections.

An implementation contract records the base, maps, units, clean distribution or empirical population, forward covariance, schedule, score parameterisation, numerical rank policy and random-seed scope. For Families E to H it also records which examples are records and which are generated, the example graph, its weights and $\tau$, $\beta$ and $p$. It also distinguishes evidence records, evaluated proposals and generated samples. Immutable records and pure functions fit this contract: a denoising step receives a versioned model and returns a state plus diagnostics; a private numerical solver can use mutable work arrays.

The minimal reverse-step interface takes $x_t$, $t$, an estimated clean state, schedule coefficients and an innovation. The horizontal read is a separate function. This makes the coordinate identity testable without training a model and allows the same denoiser to be compared under deterministic and stochastic samplers. It also prevents silent schedule changes from being attributed to a sheaf advantage.

## 14.1 One step of a sheaf-structured batch sampler

The families compose into a single step. For a batch $X_t$ at level $t$:

1. *Read among records.* For each example, form the clean prediction from the example star: (26) for complete records, the harmonic read with maps $H_i$ for partial ones, or the local read (38). A trained network replaces this read in Families A and B.
2. *Couple in the target (optional).* Apply the scaled resolvent $(I+h_tL)^{-1}$ of (34) to the batch of clean predictions in the Gaussian reference, or add the scheduled coupling of (36) to the learned scores. Solve the sparse system; never form the inverse.
3. *Step vertically.* Apply (4), equivalently (5) in clean coordinates, with innovations drawn from $\mathcal{N}(0,K)$ of (32) for Family F, or independent ones otherwise.
4. *Report diagnostics.* Record the horizontal reach, the compatibility residual $\|\delta X\|_W^2$ against its noise law (15), and for local reads the gluing defect.

With a sparse example graph, step 2 costs one sparse symmetric positive-definite solve per step, and it is well conditioned because $h_t\le\beta/p$. Step 3 with (32) needs one factorisation of $K$ per batch, not per step. Appendix A gives an immutable C# kernel of steps 1 to 3.

Angles, sign-indeterminate modes and changing charts belong in a later implementation. Euclidean Gaussian corruption is not coordinate invariant under nonlinear chart changes; Jacobian factors, the chosen volume measure and, for continuous-time coordinates, the appropriate stochastic correction matter. Orthogonal linear gauges are a simpler initial test because isotropic Gaussian laws are preserved by them. A collection of local Gaussian samplers is not automatically a globally defined diffusion on a curved space.

# 15 Numerical construction checks

The companion source records @CHECKS@ named checks from Version 1 and @V2_CHECKS@ from Version 2, @TOTAL_CHECKS@ in all, with fixed seeds and runtime metadata. All pass. They test equations, bounds and synthetic constructions rather than a trained generative model. Numerical values in this section and the figures are read from the saved result files.

Table: **Table 3.** Version 1 checks: horizontal structure within examples.

| Check family | Instances | Recorded result |
|:--|--:|:--|
| DDIM coordinate identity | @DDIM_N@ | Maximum relative discrepancy @DDIM_ERR@ |
| Compatible corruption and projection | @PROJ_N@ | Maximum residual @COMPAT_ERR@; @RISK_VIOL@ risk increases |
| Ambient residual law | @NOISE_N@ per scale | Maximum relative Monte Carlo discrepancy @NOISE_ERR@ |
| Gaussian restriction coupling | 1 | Pathwise square discrepancy @SQUARE_ERR@ |
| Harmonic energy gradient | @GRAD_N@ | Maximum finite-difference discrepancy @GRAD_ERR@ |
| Conditional Gaussian identities | @GAUSS_N@ | Posterior discrepancy @POST_ERR@; score discrepancy @GAUSS_SCORE_ERR@ |

Table: **Table 4.** Version 2 checks: horizontal structure among examples.

| Check family | Instances | Recorded result |
|:--|--:|:--|
| Example-star read and score (10.2) | 200 and 1 | Harmonic form @HARM_ERR@; score identity @TW_ERR@ |
| Clean-top re-selection (10.3) | @RS_N@ | @RS_SHARE@ on records; total variation @RS_TV@ |
| DE consensus step and bound (10.4) | @DE_N@ | Identity @DE_ERR@; @DE_VIOL@ bound violations |
| Marginal-preserving noise (11.1) | 2 samplers | Marginal difference @NC_MARG@; transfer @NC_TRANSFER@ |
| Resolvent denoiser and order (12.1, 12.2) | 5 levels | Resolvent @SP_RES@; crossing error @SP_LOGERR@ |
| Coupling schedule and limits (12.3) | 4 levels | Formula @KAP_ERR@; first order in $1/\beta$ |
| Constant coupling (12.3) | 1,000 steps | Exact @NV_EXACT0@; constant @NV_EX0@; stochastic diverges |
| Mosaics and fixed points (13.1) | $2^{10}$ signals | Fixed-point error @GL_FIXERR@; global fixed points @GL_GFIX@ |
| C# kernel against NumPy | @CS_LINES@ lines | Largest relative difference @CS_MAX@ |

The chain has @LOCAL_D@ local coordinates, @GLOBAL_D@ compatible coordinates and @CONSTRAINT_RANK@ independent equality constraints. These dimensions verify the fixed example, not a universal compression ratio. The negative sign cycle has compatible dimension @HOLONOMY_DIM@, illustrating the exact-noise obstruction.

The curl counterexample uses the maps and point stated in Proposition 4.2. Its finite-difference values corroborate the analytic strict inequality. For the heat test, the valid Gaussian family has spatial residual range at most @HEAT_GOOD@ on the declared grid, while the invalid family has range from @HEAT_BAD_MIN@ to @HEAT_BAD_MAX@ over the tested times. Both are normalisable at every level.

The ambient residual experiment uses independent full-dimensional Gaussian vectors. The intrinsic comparison uses the same vectors projected into $V$, so it isolates the covariance change. The observed agreement with (15) is a Monte Carlo check, not evidence that intrinsic corruption will generate better samples.

The Version 2 Gaussian results are exact covariance propagations, not Monte Carlo estimates. Their residual errors after many steps are discretisation errors of the sampler itself, and they fall with the step count. The mixture, DE and mosaic results are simulations with fixed seeds. The Version 1 result file was regenerated in the current environment and is identical to the published one apart from the recorded library versions. The Word paper uses editable native equations, passes OOXML schema validation, and is checked structurally and by rendered-page inspection. No neural training, likelihood benchmark or comparative generation benchmark is claimed.

# 16 Predictions and a staged test

The first study should use generated chain-context data with a known joint distribution, explicit train and test combinations, and a deliberately omitted-factor condition. Freeze all splits, budgets, maps and primary endpoints before the confirmatory comparison. Separate data-model quality from numerical sampler accuracy using the analytic reference.

**H1 — Correct shared structure improves conditional completion.** Under matched observations and total compute, a calibrated sheaf model has lower held-out completion error than identity-map and shuffled-map controls. The primary endpoint is task error on unseen combinations, with confidence intervals over independent data-generating instances. Reject the predicted advantage if the paired 95 percent interval for control error minus sheaf error is not strictly positive. A benefit from additional information is not evidence for a special sampler.

**H2 — Compatible parameterisation preserves diversity.** On multimodal data supported on a known compatible space, intrinsic diffusion maintains mode coverage while reducing horizontal violation relative to an ambient baseline. Require noninferiority in a preregistered mode-coverage tolerance as well as the expected residual improvement. Reject the useful-generation claim if compatibility is obtained by losing modes or reducing all states toward a trivial section.

**H3 — Score and time consistency predict sampler fidelity.** On analytic models, precision-weighted and forward-consistent scores reproduce the declared noised distributions more accurately than naive read displacements or independently fitted incompatible energy families at matched integration budgets. Compare empirical moments and a declared distributional distance. Refute the implementation claim if the corrected sampler fails its preregistered tolerance against the analytic reference. This is primarily a correctness test, not a claim about image quality.

**H4 — Correct factors limit false recombination.** Add a known cross-context dependency absent from the initial sheaf. Predict increased false combinations under the incomplete model and recovery after the correct factor is supplied. Include a matched factor-graph learner. Reject the proposed mechanism advantage if the relevant interaction is absent, or if performance is fully explained by giving one method the missing dependency.

**H5 — Noise coupling buys batch diversity at no marginal cost.** With a fixed trained denoiser, batches drawn with negatively correlated noise from (32) cover more modes per batch than independent batches, while per-sample fidelity metrics are unchanged within preregistered noninferiority margins. Proposition 11.1 guarantees the marginals; the prediction concerns the joint coverage gain. Reject it if coverage per batch does not improve at the declared batch size.

**H6 — Scheduled coupling beats constant coupling for learned scores.** For a batch that must share interfaces, adding the schedule (36) to learned per-example scores yields lower interface error at matched fidelity than adding $-\beta LX$ at every level. It should also remain stable where the constant coupling diverges. Use a synthetic non-Gaussian family with known joint law, and report the gap to the exact coupled sampler. Reject it if the scheduled surrogate is not better than the constant one on the joint distance.

**H7 — Window width sets a novelty budget.** In a trained local or convolutional denoiser, the share of outputs that are novel mosaics falls, and the share of training copies rises, as the effective receptive field widens. Gluing failures are detected by a positive window defect. Compare with the analytic local read (38) and the patch-mosaic predictions of [13]. Reject it if novelty does not decrease monotonically with the receptive field at a fixed dataset.

Table: **Table 5.** Stages of the staged test.

| Stage | Deliverable | Required evidence |
|:--|:--|:--|
| SD0 | Fixed maps, units, chain data and exact coordinate conversion | Identity and covariance checks pass |
| SD1 | Analytic conditional Gaussian sampler | Moments and scores agree with the reference |
| SD2 | Ambient and intrinsic learned denoisers | Held-out fidelity and mode coverage reported together |
| SD3 | Archive based sheaf sampler and matched controls | Proposal gains survive equal information and compute |
| SD4 | Learned maps or nonlinear charts | Comparison maps and forward-process changes are validated |
| SD5 | Example-star reference and coupled-noise batches (E, F) | Memorisation and coverage measured against the exact read |
| SD6 | Coupled-target and local-read samplers (G, H) | Interface error, stability and gluing defect against the analytic references |

Required controls include ordinary DDPM/DDIM, identity restrictions, an ordinary graph-Laplacian architecture, a dimension-matched latent diffusion, a matched factor-aware learner, and the analytic Gaussian reference. For Families E to H, add independent batches, constant coupling and particle guidance [14] as controls. Do not compare intrinsic diffusion only to a larger ambient model and attribute every efficiency gain to topology. Report map-learning cost, basis cost, retrieval work, solver work, denoising evaluations, persisted parameters and stochastic sample counts.

Learning maps by compatibility loss alone permits degenerate zero restrictions. Independently calibrate shared observables, constrain ranks or normalisation where justified, and test out-of-sample transport. Branches representing different contexts remain distinct unless the generative model explicitly specifies transitions or mixtures between them. A router or conditioning variable must be available at inference; an oracle branch label is not a deployable model.

# 17 What the construction establishes

The DDIM-to-ADE identity makes the reverse journey algebraically concrete. Version 2 completes it at the other end. The exact empirical DDIM denoiser is the harmonic read of an example star. Diffusion Evolution is a lazy consensus step on its population graph. An ASE layer is the same read with partial maps. Tracing ASE back through ADE and DE to DDPM and DDIM therefore loses nothing essential: each stage is the previous one with a narrower horizontal sheaf.

Horizontal sheaf structure can enter at four places, and Version 2 gives each its exact law. In the read among records, it is exact and memorises. In the noise of a batch, it preserves marginals and transmits correlation. In the target of a batch, the denoiser becomes an implicit sheaf heat step, the vertical axis sorts the horizontal spectrum, and the noised coupling fades on a closed-form schedule. In a local read, gluable splices become fixed points, and novelty and gluing failure are two sides of one cover. These are different interventions and should be ablated separately.

The strongest exact statements concern compatibility and probability typing. Ambient noising has a calculable disagreement law. Intrinsic noising preserves the compatible subspace. Restrictions constrain admissible covariances. Harmonic displacement requires precision weighting to become the declared energy score. A valid collection of scores must also satisfy the forward generator's consistency conditions. Clean couplings must be noised, not copied. None of these guarantees that a learned model beats an ordinary denoiser.

Sheaf structure can therefore be carried all the way back to DDPM and DDIM, with denoising as the vertical axis and the relation among examples as the horizontal one. The resulting model should be called generative only when its distribution, forward corruption and reverse dynamics are specified together. Where ASE instead uses an evolving fitness archive to propose better designs, the same vertical schedule remains useful, with the more limited interpretation of a structured optimiser.

# References

[1] Ho, J., Jain, A. and Abbeel, P. (2020). Denoising Diffusion Probabilistic Models. *Advances in Neural Information Processing Systems* 33. https://arxiv.org/abs/2006.11239

[2] Song, J., Meng, C. and Ermon, S. (2021). Denoising Diffusion Implicit Models. *International Conference on Learning Representations*. arXiv:2010.02502v4. https://arxiv.org/abs/2010.02502v4

[3] Song, Y., Sohl-Dickstein, J., Kingma, D. P., Kumar, A., Ermon, S. and Poole, B. (2021). Score-Based Generative Modeling through Stochastic Differential Equations. *International Conference on Learning Representations*. https://arxiv.org/abs/2011.13456

[4] Zhang, Y., Hartl, B., Hazan, H. and Levin, M. (2025). Diffusion Models are Evolutionary Algorithms. *International Conference on Learning Representations*. Revised preprint arXiv:2410.02543v3, 9 May 2026. https://arxiv.org/abs/2410.02543v3

[5] Bodnar, C., Di Giovanni, F., Chamberlain, B. P., Liò, P. and Bronstein, M. M. (2022). Neural Sheaf Diffusion: A Topological Perspective on Heterophily and Oversmoothing in GNNs. *Advances in Neural Information Processing Systems* 35. https://arxiv.org/abs/2202.04579

[6] Bourgerie, R., Girdzijauskas, Š. and Fodor, V. (2026). Deep Neural Sheaf Diffusion. arXiv:2605.19021v2. Accepted at the ICML 2026 Workshop on Graph Foundation Models. https://arxiv.org/abs/2605.19021v2

[7] Hu, C.-S. (2026). A Sheaf-Theoretic and Topological Perspective on Complex Network Modeling and Attention Mechanisms in Graph Neural Models. arXiv:2601.21207v4. AAAI 2026 Workshop on Mathematical Foundations of AI. https://arxiv.org/abs/2601.21207v4

[8] Ghosh, D. P. (2026). Autoregressive Sheaf Evolution. Conversion proposal. Project manuscript.

[9] Ghosh, D. P. (2026). Horizontally Topological, Vertically Algebraic. ASE Part I. Project manuscript.

[10] Ghosh, D. P. (2026). The Horizontal Layer. ASE Part II. Project manuscript.

[11] Ghosh, D. P. (2026). Autoregressive Sheaf Evolution for Memory Consolidation. Version 3, 18 October 2026. Project manuscript.

[12] Ghosh, D. P. (2026). The Vertical Stack. ASE Part III: the token recurrence, tangent dynamics and persistence across layers. 18 October 2026. Project manuscript.

[13] Kamb, M. and Ganguli, S. (2025). An analytic theory of creativity in convolutional diffusion models. *International Conference on Machine Learning*. arXiv:2412.20292. https://arxiv.org/abs/2412.20292

[14] Corso, G., Xu, Y., De Bortoli, V., Barzilay, R. and Jaakkola, T. (2024). Particle Guidance: non-I.I.D. Diverse Sampling with Diffusion Models. *International Conference on Learning Representations*. arXiv:2310.13102. https://arxiv.org/abs/2310.13102

[15] Gu, X., Du, C., Pang, T., Li, C., Lin, M. and Wang, Y. (2025). On Memorization in Diffusion Models. *Transactions on Machine Learning Research*. arXiv:2310.02664. https://arxiv.org/abs/2310.02664

[16] Seneta, E. (2006). *Non-negative Matrices and Markov Chains*. Revised printing. Springer Series in Statistics. Springer, New York.

[17] Hansen, J. and Ghrist, R. (2019). Toward a spectral theory of cellular sheaves. *Journal of Applied and Computational Topology* 3, 315–358. https://arxiv.org/abs/1808.01513

# Appendix A. An immutable C# kernel

The kernel below implements the example-star read (26), the DDIM step (4), the DE step of Theorem 10.4, the horizontal reach, the local read (38), the coupled denoiser (34) and the schedule (36). It uses immutable records, `ImmutableArray<double>` vectors and pure static functions; the Cholesky solve works on a private copy. A validation program prints @CS_LINES@ lines of outputs on fixed inputs, and an independent NumPy implementation recomputes each line. The NumPy coupled denoiser uses the covariance form (21), not the resolvent form (34), so the comparison also checks Theorem 12.1. The schedule is recomputed from the difference of precisions, not from (36).

```csharp
@CS_CODE@
```

Table: **Table 6.** C# against NumPy, line by line (.NET @DOTNET@).

| Output | Values (C#) | Largest relative difference |
|:--|:--|--:|
@CS_ROWS@
