"""Package and native-equation checks, not full OOXML schema validation."""
from pathlib import Path
import hashlib,json,posixpath,re,zipfile
from urllib.parse import unquote
from lxml import etree
from docx import Document
P=Path(__file__).resolve().parent
f=P/'output/Sheaf_Structured_Generative_Diffusion.docx'
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
with zipfile.ZipFile(f) as z:
    assert z.testzip() is None
    names=set(z.namelist());parts={n:etree.fromstring(z.read(n)) for n in names if n.endswith(('.xml','.rels'))}
    for name,root in parts.items():
        if not name.endswith('.rels'):continue
        base='' if name=='_rels/.rels' else posixpath.dirname(posixpath.dirname(name))
        for rel in root:
            if rel.get('TargetMode')=='External':continue
            target=unquote(rel.get('Target','')).split('#')[0]
            resolved=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join(base,target))
            assert not target or resolved in names,(name,resolved)
    body=parts['word/document.xml'];numbers=[]
    for p in body.xpath('//w:p',namespaces=ns):
        style=p.xpath('./w:pPr/w:pStyle/@w:val',namespaces=ns)
        text=''.join(p.xpath('.//w:t/text()',namespaces=ns))
        if style and style[0]=='Equation':
            match=re.search(r'\((\d+)\)\s*$',text)
            if match:numbers.append(int(match[1]))
    assert numbers==list(range(1,25)),numbers
    math=len(body.xpath('//m:oMath',namespaces=ns));assert math>100
    images=len(body.xpath('//w:drawing',namespaces=ns));assert images==3
    tables=body.xpath('//w:tbl',namespaces=ns);assert len(tables)==3
    for t in tables:
        assert set(t.xpath('./w:tblPr/w:tblBorders/*/@w:color',namespaces=ns))=={'D9D9D9'}
        assert t.xpath('./w:tr[1]/w:trPr/w:tblHeader',namespaces=ns)
    prose=''.join(body.xpath('//w:t/text()',namespaces=ns))
    assert not re.search(r'@[A-Z_]+@|\\(?:begin|tag|frac|mathcal)\b',prose)
    assert 'Sheaf Structured' in prose
d=Document(f)
assert d.sections[0].page_width.inches==8.5 and d.sections[0].page_height.inches==11
assert d.styles['Normal'].font.size.pt==11
report=dict(file=f.name,sha256=hashlib.sha256(f.read_bytes()).hexdigest(),zip_integrity=True,
            XML_parts=len(parts),internal_relationships_resolve=True,numbered_equations=len(numbers),
            native_math_objects=math,figures=images,tables=len(tables),letter_page=True,body_font_points=11,
            no_unfilled_tokens_or_raw_LaTeX=True,full_OOXML_schema_validation=False)
(P/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
