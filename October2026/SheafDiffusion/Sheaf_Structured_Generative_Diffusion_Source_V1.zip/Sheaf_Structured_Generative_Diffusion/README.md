# Sheaf Structured Generative Diffusion

This source accompanies the Word paper by Debi Prasad Ghosh, dated 18 October
2026. It traces the ASE construction back through ADE and Diffusion Evolution to
DDPM/DDIM, and distinguishes structured proposal algorithms from specified
generative probability models.

The principal results are the DDIM coordinate identity, a harmonic-score
counterexample, the precision-weighted energy-score identity, a heat-flow
consistency criterion, ambient residual and projection laws, compatible-noise
and restriction-covariance conditions, and a conditional Gaussian reference.
These are mathematical constructions and elementary deductions. The paper makes
no priority claim or trained-model performance claim.

## Rebuild

Use Python 3.12 with NumPy 2.3.5, SciPy 1.17.0, Matplotlib 3.10.8, python-docx
1.2.0 and lxml 6.1.1. Pandoc must be available on PATH. Run in this directory:

```bash
python checks.py
python populate.py
python figures.py
python build.py
python verify.py
```

`checks.py` writes the saved `results.json`. All 23 named construction checks
pass. `populate.py` fills the manuscript's numerical statements from that file.
`figures.py` generates the three figures from the declared structure and saved
results. `build.py` uses Pandoc's native Word math path and applies the tested
OOXML postprocessor. The Word file and its Markdown counterpart are in `output`.

An independent scratch rerun reproduced `results.json` byte for byte in the
recorded environment; see `reproduction.json`. No neural model was trained, no
comparative generation benchmark was run, and no C# compilation is claimed.

The final Word package is checked by `verify.py` for structural integrity and
native equations, then rendered and visually reviewed using the documents
workflow. Those checks are not full OOXML schema validation. Rendered QA PDFs
and PNGs are not deliverables in this package.

## Sources

The paper contains a numbered bibliography with primary links for DDPM, DDIM,
score-SDE modelling, Diffusion Evolution, Neural Sheaf Diffusion and the 2026
sheaf architecture papers. The ADE/ASE papers are project manuscripts.
`SOURCE_NOTES.md` records the scope of the external evidence.
