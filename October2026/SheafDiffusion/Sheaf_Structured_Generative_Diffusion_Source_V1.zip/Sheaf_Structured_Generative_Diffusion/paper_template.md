---
title: Sheaf Structured Generative Diffusion
subtitle: Horizontal relations among examples and vertical denoising from ASE to DDPM and DDIM
author:
  - Debi Prasad Ghosh
  - Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India
date: 18 October 2026
---

## Abstract

Autoregressive Sheaf Evolution replaces whole-record averaging by reads through calibrated partial-observation maps. We trace this construction back through Autoregressive Diffusion Evolution and Diffusion Evolution to generative DDPM and DDIM. A change to clean coordinates converts the DDIM update exactly into the scheduled autoregressive form used by ADE and ASE. This identifies where a sheaf read can be inserted, but does not by itself establish a generative model. We distinguish a horizontal sheaf of local data and shared observables from the vertical noise order, and develop two forward processes: ordinary ambient corruption, which creates a precisely quantified compatibility residual, and intrinsic corruption on the space of compatible sections, which preserves compatibility pathwise. A covariance theorem characterises noise that can respect the horizontal maps and exhibits an obstruction from sign holonomy. A partial-observation counterexample proves that a harmonic-read displacement need not be a score. Precision weighting repairs the energy gradient, while a heat-equation criterion supplies a separate test of consistency across noise levels. A conditional Gaussian construction gives an explicit model in which the harmonic posterior, noised marginals and score agree. We specify learned and archive-based implementations, their reduction to ordinary models, and tests that distinguish useful generation from mere residual reduction. @CHECKS@ reproducible construction checks pass. No trained-model generation or optimisation advantage is claimed.

**Keywords:** cellular sheaf; denoising diffusion; DDPM; DDIM; harmonic extension; score matching; diffusion evolution; compatible noise.

# 1 The reverse journey

The organising proposal is simple: denoising depth is vertical, and relationships among examples or their local descriptions are horizontal. A sheaf records what can be compared at one noise level. A diffusion model specifies how distributions over those representations change with noise. Combining them requires both a geometric construction and a probability model.

The ASE programme began with diffusion models, passed through Diffusion Evolution (DE) and Autoregressive Diffusion Evolution (ADE), and then replaced the single Euclidean read by a sheaf-based read [4, 8–10]. Reversing this route is productive because the DDIM sampler already accepts a predicted clean state. The question becomes which clean-state estimators retain a probabilistic interpretation when their observations are partial and their coordinates are related by restriction maps.

| Stage | Horizontal information | Vertical operation |
|:--|:--|:--|
| DDPM and DDIM | A denoiser learns statistical relationships from examples | Reverse a declared corruption process |
| Diffusion Evolution | A fitness-weighted population supplies a clean-state estimate | Apply denoising-inspired population updates |
| ADE | Evaluated archive records guide proposals | Apply a prescribed autoregressive schedule |
| ASE | Observation maps allow partial reads and compatible recombination | Carry a vertical fibre diagram through refinement |
| Proposed generative extension | Learn or specify a distribution over sheaf-structured data | Match its forward corruption and reverse dynamics |

Here ADE and ASE refer to the project constructions [8–10], rather than to a claim that those names describe established generative-model families. DE is the method of Zhang and colleagues [4]. The ancestry is conceptual and algebraic; it does not imply that every later optimiser samples the same density as its predecessor.

DDPM defines a Gaussian forward chain and learns a reverse model [1]. DDIM supplies related sampling processes using the same denoising training objective [2]. Score-based formulations make the time-dependent density gradient explicit [3]. Neural Sheaf Diffusion supplies horizontal operators for graph representation learning [5]. The latter use of diffusion is not, by itself, a DDPM reverse-time construction. The 2026 work on deep sheaf networks and sheaf views of attention also concerns relational architectures, not a proof that an arbitrary sheaf read is a generative score [6, 7].

The contribution of this paper is a set of explicit constructions and obligations connecting these ideas. The elementary linear algebra and Gaussian identities are presented with proofs. We make no priority claim for combining geometry and generative modelling, and no empirical claim that the proposed combination improves generation.

# 2 Horizontal data and vertical noise levels

Fix normalised coordinates before defining residuals. A displacement, angle, stress and latent feature cannot share a numerical metric without declared scales. All transposes and orthogonal projections below use these fixed coordinates. A change of coordinates requires the corresponding transformation of observation and vertex metrics.

**Definition 2.1 — A horizontal linear model.** On a fixed finite graph or cover nerve, assign a finite-dimensional data space $F(v)$ to each vertex and a shared-observation space $F(e)$ to each edge. For each incident pair, specify a linear restriction $r_{ve}:F(v)\to F(e)$. Set

$$C^0=\bigoplus_vF(v),\qquad (\delta X)_e=r_{we}X_w-r_{ve}X_v. \tag{1}$$

The compatible assignments form $V=\ker\delta$. On a graph this defines a cellular sheaf without additional face conditions. If higher cells are present, the appropriate restriction composites must agree; adding triangles without their commuting identities does not define the intended cochain complex.

A stalk is a data space. A changing sample is an element of a sequence of such spaces, not itself a stalk. Its specified transport maps or pathwise tangents form a vertical fibre diagram. The index $t$ below is noise level or computational depth, not physical time, anatomical lamina or training iteration.

**Definition 2.2 — An archive observation star.** A query has candidate space $C^0$. Retrieved example $i$ has data $y_i$ in a record space. A common observable is reached through maps $Q_i$ from the candidate and $R_i$ from the record. Its discrepancy is $Q_iX-R_iy_i$. Writing $H_i=Q_i$ and $o_i=R_iy_i$ gives the observation notation used below.

This is how the phrase horizontal among examples can be implemented without equating entire examples. An example contributes only to observables for which its map is meaningful. Examples can disagree, and their weighted boundary data need not extend to a zero-residual section. Forcing every training example to become one global section would erase legitimate variation.

The four project bases remain distinct: the cover base and its nerve describe spatial locality; the context base describes partial-variable incidence; the layer order describes depth; and the observation star describes one retrieval operation. A graph built from neighbouring examples can instantiate a horizontal relational model, but is not automatically an open-cover nerve. The same symbol for two graphs does not establish a comparison map.

![Figure 1. Two horizontal restrictions meet in a shared-observation space at each noise level. Vertical maps must respect both squares to define the indicated linear product structure. The end spaces may be example-associated frames or local views of a candidate. Their values are not required to coincide as complete records.](fig/squares.png){width=100%}

The intrinsic generative construction in Section 7 uses local views of one candidate in $C^0$. Different training examples are different compatible assignments. The archive construction uses examples as fixed leaves of a query-dependent star. These interpretations can be combined, but must not be silently identified.

# 3 DDIM in autoregressive coordinates

Use cumulative signal coefficient $\bar\alpha_t$ and write

$$a_t=\sqrt{\bar\alpha_t},\qquad s_t=\sqrt{1-\bar\alpha_t},\qquad x_t=a_tx_0+s_t\epsilon. \tag{2}$$

Here $a_0=1$, $s_0=0$, and larger $t$ means more noise. For a DDIM step, let $\widehat x_{0,t}$ be the predicted clean state and put

$$\widehat\epsilon_t=\frac{x_t-a_t\widehat x_{0,t}}{s_t},\qquad c_t=\sqrt{s_{t-1}^2-\sigma_t^2}. \tag{3}$$

The sampling update is

$$x_{t-1}=a_{t-1}\widehat x_{0,t}+c_t\widehat\epsilon_t+\sigma_t\xi_t. \tag{4}$$

For the deterministic DDIM choice, $\sigma_t=0$. Stochastic choices require $0\le\sigma_t\le s_{t-1}$. The usual consecutive-step ancestral form is obtained for its corresponding posterior-variance choice; this is not an identity for every learned-variance DDPM variant [1, 2].

**Theorem 3.1 — The DDIM to ADE coordinate identity.** Assume $a_t,a_{t-1},s_t>0$ and define $z_t=x_t/a_t$. For any realised clean prediction $R_t=\widehat x_{0,t}$ and innovation $\xi_t$, (4) is exactly

$$z_{t-1}=(1-\lambda_t)z_t+\lambda_tR_t+\nu_t, \tag{5}$$

with

$$\lambda_t=1-\frac{a_tc_t}{a_{t-1}s_t},\qquad \nu_t=\frac{\sigma_t}{a_{t-1}}\xi_t. \tag{6}$$

If $a_{t-1}\ge a_t>0$, then $0\le\lambda_t\le1$.

*Proof.* Substitute (3) into (4) and divide by $a_{t-1}$. The coefficient of $z_t$ is $a_tc_t/(a_{t-1}s_t)$ and the coefficient of $R_t$ is one minus this quantity. Monotonicity gives $c_t\le s_{t-1}\le s_t$ and $a_t\le a_{t-1}$, so the coefficient lies in $[0,1]$. $\square$

Thus the autoregressive form does not require abandoning a diffusion schedule. It is a clean-coordinate form of the sampler. The identity holds for neural, population, archive and sheaf clean predictions. What changes between these cases is the justification for the prediction, not the algebra of the step.

The transformed observation is $z_t=x_0+r_t\epsilon$ with $r_t=s_t/a_t$. Near a nearly pure-noise endpoint, $r_t$ can be large and the rescaling poorly conditioned. An exactly zero $a_t$ cannot be divided out. Implementations can retain $x$-coordinates near that endpoint and use the theorem where its assumptions hold. The final clean endpoint has $c_t=\sigma_t=0$ and therefore unit read coefficient.

The identity was checked on @DDIM_N@ random steps using matched innovations. The largest relative discrepancy was @DDIM_ERR@. This is a numerical check of a proved identity, not a comparison of sample quality.

## 3.1 What is inherited from diffusion evolution

For a frozen complete-record archive, take positive weights $\pi_i$ and set $p_0=\sum_i\pi_i\delta_{y_i}$ after normalisation. Its Gaussian noised density has posterior weights proportional to $\pi_i\exp[-\|x-a_ty_i\|^2/(2s_t^2)]$. The posterior clean mean is their weighted average. DE uses fitness-derived weights in a population read [4]; ADE changes the evaluated archive and proposal organisation [8].

For generative modelling, empirical weights represent the declared data distribution. Fitness weights instead declare a changed target. An evolving population or adaptively replaced archive changes that target again. A Gaussian-looking read at each step does not make an adaptive optimiser the reverse of one fixed forward process.

For complete observations, the clean mean remains in the convex hull of archive records. A partial-observation sheaf read can leave that hull, but then it is not the posterior mean of this same finite complete-record mixture. Compositional generation requires an enlarged or differently factorised clean distribution. Hull escape is a construction property, not proof of fidelity or novelty.

# 4 The harmonic read and the score obstruction

Freeze a horizontal model, observation maps $H_i$, records $o_i$, positive metrics $\Lambda_i,W$, and prior weights $\pi_i>0$. At a fixed noise variance parameter $\tau>0$, define

$$e_i(z)=\tfrac12\|H_iz-o_i\|_{\Lambda_i}^2,\qquad \omega_i(z)=\frac{\pi_i e^{-e_i(z)/\tau}}{\sum_j\pi_j e^{-e_j(z)/\tau}}. \tag{7}$$

These are retrieval affinities. Different observation dimensions and metrics require their own likelihood normalisers in a probabilistic model; the displayed affinities do not supply that model merely by being positive.

For a query $z$, a fixed anchor $q$, $P\succeq0$ and $\beta\ge0$, minimise

$$Q(u\mid z)=\tfrac12\|u-q\|_P^2+\tfrac\beta2\|\delta u\|_W^2+\sum_i\omega_i(z)e_i(u). \tag{8}$$

Put $A(z)=P+\beta\delta^\top W\delta+\sum_i\omega_i(z)H_i^\top\Lambda_iH_i$ and $b(z)=Pq+\sum_i\omega_i(z)H_i^\top\Lambda_io_i$. If $A(z)\succ0$, its unique minimiser is $R(z)=A(z)^{-1}b(z)$. Solve the system rather than form an inverse. If observability fails, report the nullspace and specify retention or regularisation; a numerical cutoff is a separate policy [10, 11].

**Proposition 4.1 — Precision weighted displacement is an energy gradient.** Set

$$E_\tau(z)=\tfrac12\|z-q\|_P^2+\tfrac\beta2\|\delta z\|_W^2-\tau\log\sum_i\pi_i e^{-e_i(z)/\tau}. \tag{9}$$

Then

$$\nabla E_\tau(z)=A(z)(z-R(z)). \tag{10}$$

If $P\succ0$ and $\kappa>0$, the density $p(z)\propto\exp[-E_\tau(z)/\kappa]$ is normalisable and has score $A(z)(R(z)-z)/\kappa$.

*Proof.* Differentiating the soft minimum gives $\sum_i\omega_i\nabla e_i$. Adding the prior and compatibility derivatives gives $Az-b$. Since $e_i\ge0$, the soft-minimum term is bounded below by $-\tau\log\sum_i\pi_i$. The positive definite prior therefore supplies an integrable Gaussian upper bound on $\exp[-E_\tau/\kappa]$. Differentiating its log density gives the score. $\square$

The temperature $\kappa$ is declared separately from the observation parameter $\tau$. In particular, choosing $\kappa=\tau$ does not establish forward-process consistency. A fixed anchor is part of this density; re-anchoring at each query changes the specification and requires a separate analysis [11].

**Proposition 4.2 — A harmonic displacement need not be a score.** In two coordinates $(x,y)$, use observations $H_1=(1,0)$ with value 0, $H_2=(0,1)$ with value 0, and $H_3=I$ with value $(1,2)$. Let $\pi_i=1$, $\tau=1$, $P=0$ and $\beta=0$. The read is

$$\begin{aligned}R_1&=\frac1{1+e^{A}},\qquad R_2=\frac2{1+e^{B}},\\ A&=-x+\tfrac12+\tfrac12(y-2)^2,\qquad B=\tfrac12(x-1)^2-2y+2.\end{aligned} \tag{11}$$

The vector field $R(z)-z$ is not the score of a positive $C^2$ density on a neighbourhood of $(0.3,0.7)$.

*Proof.* At that point $A=1.045$ and $B=0.845$. Write $f(u)=e^u/(1+e^u)^2=1/(2+2\cosh u)$. Then $\partial_yR_1=1.3f(1.045)$ and $\partial_xR_2=1.4f(0.845)$. Since $f$ decreases strictly for positive arguments, the latter is larger. Subtracting the identity field leaves these cross derivatives unchanged. A $C^2$ log density has equal mixed partial derivatives, giving a contradiction. $\square$

The computed cross derivatives are @CROSS_ONE@ and @CROSS_TWO@, a difference of @CURL@. Adding a proper prior makes the energy density in Proposition 4.1 legitimate, but does not justify discarding its precision factor. A general ASE update can be a useful preconditioned descent or proposal step while failing the stronger score interpretation.

For comparison, a complete-record Gaussian mixture obeys

$$\nabla_x\log p_t(x)=\frac{a_tm_t(x)-x}{s_t^2},\qquad m_t(x)=\mathbb E[X_0\mid X_t=x]. \tag{12}$$

This follows by differentiating each Gaussian component and collecting posterior weights. It explains the ordinary read identity, but does not extend unchanged to arbitrary partial maps. Curl-free behaviour is only a local integrability requirement; a global potential must also yield a normalisable density.

# 5 Consistency across noise levels

Even a valid score at every level is insufficient. Rescaled Gaussian noising gives $Z_\tau=X_0+\sqrt\tau\epsilon$, where $\tau=(s_t/a_t)^2$. Its marginal density is the Gaussian convolution of one initial density and satisfies the heat equation. This is a marginal statement; DDIM can realise a different coupling between times while using these same marginals [2, 3].

**Theorem 5.1 — A heat consistency criterion for sheaf energies.** Let $p_\tau(z)=Z_\tau^{-1}\exp[-\Psi_\tau(z)]$ be positive and normalised on $\mathbb R^r$. Assume the regularity and decay needed to differentiate its integral, apply the Laplacian and integrate the Laplacian to zero. Then $\partial_\tau p_\tau=\tfrac12\Delta p_\tau$ if and only if

$$\partial_\tau\Psi_\tau-\tfrac12\Delta\Psi_\tau+\tfrac12\|\nabla\Psi_\tau\|^2=c(\tau) \tag{13}$$

is spatially constant. For the energy density in Section 4 use $\Psi_\tau=E_\tau/\kappa_\tau$, including all parameter derivatives.

*Proof.* Division by $p_\tau$ gives $\partial_\tau p_\tau/p_\tau=-\partial_\tau\Psi_\tau-\partial_\tau\log Z_\tau$ and $\Delta p_\tau/p_\tau=-\Delta\Psi_\tau+\|\nabla\Psi_\tau\|^2$. Equality yields (13), with $c=-\partial_\tau\log Z_\tau$. Conversely, if the residual is spatially constant, the same calculation makes $\partial_\tau p_\tau-\tfrac12\Delta p_\tau$ a scalar multiple of $p_\tau$. Integrating and using the assumptions makes that scalar zero. $\square$

This criterion is useful because a separate energy fit at every scale can satisfy local compatibility and still violate the probability evolution required by the sampler. Its converse establishes the heat PDE under the stated conditions; matching a particular data model additionally requires its initial condition and the appropriate uniqueness assumptions. Checking a finite spatial grid cannot certify the PDE globally.

**Example 5.2 — Proper densities with incompatible time evolution.** Let $\Psi_\tau(z)=h(\tau)z^2/2$ with $h>0$. The residual is

$$\tfrac12(h'+h^2)z^2-\tfrac12h. \tag{14}$$

It is spatially constant exactly when $h'=-h^2$. The choice $h=1/(v_0+\tau)$ produces variance $v_0+\tau$, as Gaussian convolution requires. The choice $h=1+\tau$ also gives a proper Gaussian at every level, but its variance decreases as noise time increases. It fails (13).

![Figure 2. A valid Gaussian heat family increases its variance with noise time. A separately normalisable Gaussian family with increasing precision does the opposite. Both have valid scores at each level; only the first has the stated forward Gaussian evolution. The right panel shows the spatial range of the residual in Theorem 5.1 on the declared interval.](fig/heat.png){width=100%}

The criterion applies to intrinsic coordinates as well as ambient ones. For anisotropic constant covariance, the Laplacian and squared gradient are replaced by their covariance-weighted versions. Changing covariance, geometry or charts requires the corresponding forward generator, not an unmodified Euclidean heat equation. Score-SDE theory similarly ties the reverse drift to the marginals of a specified forward process [3].

# 6 Ambient corruption of compatible clean data

Suppose the clean distribution is supported on $V=\ker\delta$, but use full-dimensional noise. This produces a standard ambient forward diffusion whose clean data happen to satisfy linear constraints.

**Theorem 6.1 — Expected horizontal disagreement under corruption.** For deterministic $X_0$ with $\delta X_0=0$ and $X_t=a_tX_0+s_t\epsilon$, $\epsilon\sim\mathcal N(0,I_D)$,

$$\mathbb E\|\delta X_t\|_W^2=s_t^2\operatorname{tr}(W\delta\delta^\top). \tag{15}$$

*Proof.* The residual is $s_t\delta\epsilon$. Its second moment follows from $\mathbb E\epsilon\epsilon^\top=I_D$. $\square$

Independent corruption can therefore break exact horizontal agreement at intermediate layers without invalidating the model. A residual threshold should account for noise scale and metric. In particular, forcing every noisy representation to have zero residual would change this forward process. A clean-prediction loss can be appropriate even when a zero-residual noisy-state loss is not.

Let $U$ have orthonormal columns spanning $V$, and write $\Pi=UU^\top$.

**Proposition 6.2 — Projection improves compatible clean prediction.** For every clean $X_0\in V$ and arbitrary estimate $\widehat X$,

$$\|\widehat X-X_0\|^2=\|\Pi\widehat X-X_0\|^2+\|(I-\Pi)\widehat X\|^2. \tag{16}$$

Consequently, projecting a clean estimate cannot increase its squared reconstruction loss. Whenever defined, the Bayes clean mean $\mathbb E[X_0\mid X_t]$ already lies in $V$.

*Proof.* The two errors are orthogonal. Conditional expectation preserves the linear constraint because $\delta\mathbb E[X_0\mid X_t]=\mathbb E[\delta X_0\mid X_t]=0$. $\square$

This is a reconstruction statement in the declared norm, not a theorem about likelihood, perceptual quality or a misspecified constraint. A false compatibility law can project away real information. Projecting the clean prediction also does not force the entire noisy trajectory into $V$: DDIM's remaining noise component may lie outside it until the clean endpoint.

An ambient implementation trains a denoiser on correctly corrupted examples and returns a compatible clean estimate, for example $U g_\theta(X_t,t)$. The noise prediction is then reconstructed from (3). Training an unrestricted noise predictor and adding a clean-compatibility penalty is another option, but its finite-weight output need not satisfy the law exactly.

# 7 Intrinsic diffusion on compatible sections

Assume a fixed linear compatibility model with $r=\dim V>0$. Every compatible clean state is $X_0=Uh_0$. Define an ordinary DDPM forward chain in $\mathbb R^r$:

$$q(h_t\mid h_{t-1})=\mathcal N(\sqrt{1-b_t}\,h_{t-1},b_tI_r),\qquad 0<b_t<1. \tag{17}$$

Lift the chain through $X_t=Uh_t$. The induced clean distribution is the specified distribution of $h_0$ mapped into $C^0$.

**Theorem 7.1 — Compatibility of intrinsic DDPM and DDIM.** Every forward state of (17) lies in $V$. Every DDPM or DDIM reverse state constructed in intrinsic coordinates and lifted through $U$ also lies in $V$, for every realised innovation and every denoiser output in $\mathbb R^r$.

*Proof.* All such states are of the form $Uh$, and $\delta U=0$. $\square$

The compatibility claim is exact. It does not say that a learned reverse chain samples the true clean distribution exactly. Model error, finite-step approximation and endpoint mismatch remain. Sampling from a standard Gaussian at a finite terminal level is the usual approximation unless the terminal marginal is exactly that Gaussian.

A standard intrinsic noise-prediction objective is

$$\mathcal L(\theta)=\mathbb E\left\|\epsilon-\epsilon_\theta(a_th_0+s_t\epsilon,t)\right\|^2. \tag{18}$$

Horizontal sheaf layers can be used inside $\epsilon_\theta$, but enforcing the output representation $X=Uh$ does not require materialising a dense projector. Sparse elimination, local shared-variable assembly or a factorised parameterisation can avoid that cost. The representation and its storage count must be included in a fair comparison.

For $V=\mathbb R^D$ and $U=I$, this is ordinary diffusion. For a nontrivial $V$, densities and scores are defined relative to the intrinsic volume on $V$, not ambient Lebesgue measure. If $s_h$ is the intrinsic score, $Us_h$ is its tangent representation in $C^0$. There is no full-dimensional log density of the singular lifted law to differentiate in every ambient direction.

## 7.1 The covariance required by horizontal compatibility

**Theorem 7.2 — Compatible Gaussian noise.** Let a candidate's innovation be $G\epsilon$ with standard Gaussian $\epsilon$. Then $\delta G\epsilon=0$ almost surely if and only if $\delta G=0$. Its covariance is supported on $V$ and has rank at most $r$.

*Proof.* The expected squared residual equals $\|\delta G\|_F^2$. It vanishes exactly when $\delta G=0$. Then the image of $G$ lies in $V$, giving the support and rank statements. $\square$

If $\delta\ne0$, full-rank ambient independent noise cannot simultaneously satisfy exact compatibility. Intrinsic isotropic noise has covariance $UU^\top$, so individual local coordinates need not each have variance one. To match other local covariance conventions, use $G=US^{1/2}$ with a specified $S\succeq0$. Feasibility of desired local covariances is an additional constraint, not a consequence of having a basis.

**Proposition 7.3 — Gaussian kernels commute with restrictions in law.** For a linear restriction $R$, source corruption $Y=ax+\zeta$ with $\zeta\sim\mathcal N(0,Q)$, and Gaussian target corruption with mean $aRx$ and covariance $Q_e$, restriction and corruption have the same distribution for all $x$ if and only if $Q_e=RQR^\top$.

*Proof.* The pushed-forward Gaussian has mean $aRx$ and covariance $RQR^\top$. Gaussian laws agree exactly when these quantities agree. $\square$

A common underlying innovation gives a pathwise coupling by using $R\zeta$ at the target. Independently drawn source and target noises can obey the same marginal law without making the realised square commute. For nonisometric restrictions, assigning identity covariance at both ends usually fails even in law.

![Figure 3. Independent ambient noise creates the residual predicted by Theorem 6.1. Correlated noise obtained from the compatible projector has residual at numerical roundoff. Each point uses the same declared chain model and @NOISE_N@ Gaussian innovations; the analytic ambient curve is not fitted to the observations.](fig/noise.png){width=92%}

## 7.2 Holonomy can obstruct a nondegenerate noise model

Consider scalar restrictions around a cycle requiring $x_2=x_1$, $x_3=x_2$ and $x_1=-x_3$. The only compatible state is zero. Its coboundary is

$$\delta X=(-x_1+x_2,\,-x_2+x_3,\,x_1+x_3)^\top,\qquad \det\delta=2. \tag{19}$$

Thus an everywhere-compatible scalar Gaussian has zero covariance. In a higher-dimensional orthogonal local system, compatible values are restricted by the common fixed subspace of cycle holonomies. A nontrivial sheaf can reduce the available noise and data dimensions so far that a proposed generative model becomes useless. The target representation must have enough compatible degrees of freedom for the intended task.

This is a concrete constraint on the horizontal design. Compatibility is not always a harmless regulariser, and nontrivial holonomy is not automatically a benefit. Different generated candidates use independent intrinsic innovations. Correlation is required between local views within a candidate, not between separate samples in the generation batch.

# 8 Condition first and diffuse second

A tractable probabilistic bridge is to specify the clean conditional model before noising it. This also separates two meanings of examples. Multiple observations of one latent object can enter a likelihood product; unrelated training examples usually define a population distribution instead. Treating the latter as simultaneous measurements of one object changes the modelling assumption.

Let $h$ have proper prior $\mathcal N(\mu_0,C_0)$, with $C_0\succ0$, and conditionally independent observations $o_i=B_ih+\eta_i$, $\eta_i\sim\mathcal N(0,N_i)$ with $N_i\succ0$. For local sheaf data take $B_i=H_iU$. Collecting the observations gives $o=Bh+\eta$ with block-diagonal covariance $N$.

**Theorem 8.1 — A harmonic posterior with consistent noised marginals.** The clean posterior is Gaussian with

$$C^{-1}=C_0^{-1}+B^\top N^{-1}B,\qquad m=C(C_0^{-1}\mu_0+B^\top N^{-1}o). \tag{20}$$

Its noised marginal under $h_t=a_th+s_t\epsilon$ is $\mathcal N(a_tm,S_t)$ with $S_t=a_t^2C+s_t^2I$. Its conditional clean mean and score are

$$\widehat h_0=m+a_tC S_t^{-1}(h_t-a_tm), \tag{21}$$

$$\nabla\log p_t(h_t)=-S_t^{-1}(h_t-a_tm)=\frac{a_t\widehat h_0-h_t}{s_t^2}. \tag{22}$$

*Proof.* Completing the square gives (20), which is also the minimiser of the prior-plus-observation quadratic. Gaussian convolution gives $S_t$. Gaussian conditioning gives (21). Since $a_t^2C=S_t-s_t^2I$, substitution proves the second equality in (22); differentiation gives the first. $\square$

This construction has a valid prior, a likelihood, a harmonic clean posterior, consistent forward marginals and an analytic score. It can be lifted through $U$ to produce compatible samples. It is a useful reference model against which a learned implementation can be checked. Its exact Gaussian reverse conditional can also be sampled directly; a finite DDPM implementation must still choose and approximate its reverse kernels appropriately.

Query-dependent attention weights in Section 4 are not automatically the fixed observation precisions in (20). If the model introduces latent source selection, uncertain maps or mixtures, integrate those variables or define a corresponding joint model. A weighted least-squares solver is a posterior mean only under the declared probabilistic assumptions. Missing observation patterns must also carry an explicit missingness assumption when their selection is informative.

For genuinely distinct examples, a compositional clean model can instead factor over local contexts, with calibrated factors and a proper global prior. Noising that joint model yields a legitimate generative target. Learning its factors from incomplete examples can be nonidentifiable; overlap agreement alone does not recover omitted cross-context dependencies. The worked counterexample in ASE, where shared $b$ agrees while a hidden equality $a=c$ is violated, remains relevant [10, 11].

# 9 Vertical algebra and stochastic maps

The horizontal model at each level may have different coefficients or a different base. On a fixed base, a collection of linear vertical maps $V_t^v:F_t(v)\to F_{t-1}(v)$ is a sheaf morphism only when

$$r_{ve}^{t-1}V_t^v=V_t^e r_{ve}^{t}. \tag{23}$$

Both squares in Figure 1 must commute. If bases change by $\Phi_t:X_t\to X_{t-1}$, the typed comparison is

$$\varphi_t:F_t\longrightarrow\Phi_t^{-1}F_{t-1},\qquad (\Phi_t^{-1}F_{t-1})_x=(F_{t-1})_{\Phi_t(x)}. \tag{24}$$

A nonlinear global denoiser need not decompose into nodewise maps satisfying (23). Horizontal message passing can use neighbouring data in ways that prevent a strictly local restriction-compatible map. A regulariser that measures square defects is a test or approximation, not an identity. Product-sheaf language is justified only for a specified construction satisfying the required conditions.

There are three useful vertical objects. First, the full DDPM step is a Markov kernel between noise levels. Its pushforward is linear on measures, generally an infinite-dimensional setting. Second, conditioning on realised innovations gives a deterministic state trajectory, usually nonlinear. Third, differentiating a smooth realised trajectory gives a finite-dimensional tangent diagram. These objects have different algebraic and probabilistic meanings.

Barcodes can summarise a declared finite-dimensional linear diagram. They do not automatically apply to the full nonlinear Markov kernel, nor do they determine the generated density. Nearly singular tangents can retain exact algebraic rank while numerical sensitivity contracts. Effective-rank thresholds, singular values and the conditioning of the $x/a_t$ rescaling should be reported alongside any barcode [9, 10].

Part I's vertical acyclicity statement is a theorem about a specified product construction with a least layer [9]. It is not a substitute for score or heat-flow consistency. A generative model can have the same horizontal cohomology at every layer and still use an incorrect reverse drift. Changing covers and zigzag comparisons require their own maps; topology alone cannot validate the sampler.

# 10 Implementable model families

The first implementations should freeze maps and the horizontal base. This avoids confounding a new probability model with the separate problem of learning the base.

**Family A — Ambient sheaf denoising.** Assemble compatible clean examples in $C^0$, draw ordinary full-dimensional forward noise, and train a clean or noise predictor with the declared DDPM objective. Use sheaf message passing internally and optionally constrain the clean output to $V$. At sampling time, retain ordinary DDPM/DDIM coordinates and noise. Report noisy residuals relative to (15), rather than labelling all disagreement inconsistent. Projection must use independently justified constraints.

**Family B — Intrinsic sheaf denoising.** Compute or implement the compatible parameterisation $U$. Encode each clean example by $h_0=U^\top X_0$, train (18), sample in $h$-coordinates, and lift only when local outputs are needed. This guarantees compatibility by construction. It also changes the noise covariance relative to ambient diffusion; controls must account for this and for any dimension reduction.

**Family C — Archive based sheaf evolution.** At each layer, retrieve records, form the harmonic read, and use (4) or the equivalent (5). Fitness weights and archive updates can be retained for optimisation. Without a matched clean distribution and forward process, describe this as a diffusion-inspired proposal algorithm. Evaluate decoded candidates before admitting them to the fitness archive. Predicted combinations are not observations.

**Family D — Conditional probabilistic reference.** Specify the clean posterior or factor model first, then derive or learn its noised scores. The Gaussian instance of Section 8 needs no neural training and can verify the sampler, covariance conventions and local-to-global assembly. It is a reference calculation, not a competitive high-dimensional generative architecture by itself.

An implementation contract records the base, maps, units, clean distribution or empirical population, forward covariance, schedule, score parameterisation, numerical rank policy and random-seed scope. It also distinguishes evidence records, evaluated proposals and generated samples. Immutable records and pure functions fit this contract: a denoising step receives a versioned model and returns a state plus diagnostics; a private numerical solver can use mutable work arrays.

The minimal reverse-step interface takes $x_t$, $t$, an estimated clean state, schedule coefficients and an innovation. The horizontal read is a separate function. This makes the coordinate identity testable without training a model and allows the same denoiser to be compared under deterministic and stochastic samplers. It also prevents silent schedule changes from being attributed to a sheaf advantage.

Angles, sign-indeterminate modes and changing charts belong in a later implementation. Euclidean Gaussian corruption is not coordinate invariant under nonlinear chart changes; Jacobian factors, the chosen volume measure and, for continuous-time coordinates, the appropriate stochastic correction matter. Orthogonal linear gauges are a simpler initial test because isotropic Gaussian laws are preserved by them. A collection of local Gaussian samplers is not automatically a globally defined diffusion on a curved space.

# 11 Numerical construction checks

The companion source records @CHECKS@ named checks with fixed seed and runtime metadata. All pass. They test equations and counterexamples rather than a trained generative model. Numerical values in this section and the figures are read from the saved result file.

| Check family | Instances | Recorded result |
|:--|--:|:--|
| DDIM coordinate identity | @DDIM_N@ | Maximum relative discrepancy @DDIM_ERR@ |
| Compatible corruption and projection | @PROJ_N@ | Maximum residual @COMPAT_ERR@; @RISK_VIOL@ risk increases |
| Ambient residual law | @NOISE_N@ per scale | Maximum relative Monte Carlo discrepancy @NOISE_ERR@ |
| Gaussian restriction coupling | 1 | Pathwise square discrepancy @SQUARE_ERR@ |
| Harmonic energy gradient | @GRAD_N@ | Maximum finite-difference discrepancy @GRAD_ERR@ |
| Conditional Gaussian identities | @GAUSS_N@ | Posterior discrepancy @POST_ERR@; score discrepancy @GAUSS_SCORE_ERR@ |

The chain has @LOCAL_D@ local coordinates, @GLOBAL_D@ compatible coordinates and @CONSTRAINT_RANK@ independent equality constraints. These dimensions verify the fixed example, not a universal compression ratio. The negative sign cycle has compatible dimension @HOLONOMY_DIM@, illustrating the exact-noise obstruction.

The curl counterexample uses the maps and point stated in Proposition 4.2. Its finite-difference values corroborate the analytic strict inequality. For the heat test, the valid Gaussian family has spatial residual range at most @HEAT_GOOD@ on the declared grid, while the invalid family has range from @HEAT_BAD_MIN@ to @HEAT_BAD_MAX@ over the tested times. Both are normalisable at every level.

The ambient residual experiment uses independent full-dimensional Gaussian vectors. The intrinsic comparison uses the same vectors projected into $V$, so it isolates the covariance change. The observed agreement with (15) is a Monte Carlo check, not evidence that intrinsic corruption will generate better samples. The sampled scales, graph, covariance and basis are included in the source.

An independent rerun in the recorded environment reproduces the result file byte for byte. The Word paper uses editable native equations and is checked structurally and by rendered-page inspection. These checks are not full OOXML schema validation. No C# compilation, neural training, likelihood benchmark or biological experiment is claimed.

# 12 Predictions and a staged test

The first study should use generated chain-context data with a known joint distribution, explicit train and test combinations, and a deliberately omitted-factor condition. Freeze all splits, budgets, maps and primary endpoints before the confirmatory comparison. Separate data-model quality from numerical sampler accuracy using the analytic reference.

**H1 — Correct shared structure improves conditional completion.** Under matched observations and total compute, a calibrated sheaf model has lower held-out completion error than identity-map and shuffled-map controls. The primary endpoint is task error on unseen combinations, with confidence intervals over independent data-generating instances. Reject the predicted advantage if the paired 95 percent interval for control error minus sheaf error is not strictly positive. A benefit from additional information is not evidence for a special sampler.

**H2 — Compatible parameterisation preserves diversity.** On multimodal data supported on a known compatible space, intrinsic diffusion maintains mode coverage while reducing horizontal violation relative to an ambient baseline. Require noninferiority in a preregistered mode-coverage tolerance as well as the expected residual improvement. Reject the useful-generation claim if compatibility is obtained by losing modes or reducing all states toward a trivial section.

**H3 — Score and time consistency predict sampler fidelity.** On analytic models, precision-weighted and forward-consistent scores reproduce the declared noised distributions more accurately than naive read displacements or independently fitted incompatible energy families at matched integration budgets. Compare empirical moments and a declared distributional distance. Refute the implementation claim if the corrected sampler fails its preregistered tolerance against the analytic reference. This is primarily a correctness test, not a claim about image quality.

**H4 — Correct factors limit false recombination.** Add a known cross-context dependency absent from the initial sheaf. Predict increased false combinations under the incomplete model and recovery after the correct factor is supplied. Include a matched factor-graph learner. Reject the proposed mechanism advantage if the relevant interaction is absent, or if performance is fully explained by giving one method the missing dependency.

| Stage | Deliverable | Required evidence |
|:--|:--|:--|
| SD0 | Fixed maps, units, chain data and exact coordinate conversion | Identity and covariance checks pass |
| SD1 | Analytic conditional Gaussian sampler | Moments and scores agree with the reference |
| SD2 | Ambient and intrinsic learned denoisers | Held-out fidelity and mode coverage reported together |
| SD3 | Archive based sheaf sampler and matched controls | Proposal gains survive equal information and compute |
| SD4 | Learned maps or nonlinear charts | Comparison maps and forward-process changes are validated |

Required controls include ordinary DDPM/DDIM, identity restrictions, an ordinary graph-Laplacian architecture, a dimension-matched latent diffusion, a matched factor-aware learner, and the analytic Gaussian reference. Do not compare intrinsic diffusion only to a larger ambient model and attribute every efficiency gain to topology. Report map-learning cost, basis cost, retrieval work, solver work, denoising evaluations, persisted parameters and stochastic sample counts.

Learning maps by compatibility loss alone permits degenerate zero restrictions. Independently calibrate shared observables, constrain ranks or normalisation where justified, and test out-of-sample transport. Branches representing different contexts remain distinct unless the generative model explicitly specifies transitions or mixtures between them. A router or conditioning variable must be available at inference; an oracle branch label is not a deployable model.

# 13 What the construction establishes

The DDIM-to-ADE identity makes the reverse journey algebraically concrete. Horizontal sheaf structure can enter the clean-state estimator, the internal denoiser architecture, the clean probability model, or the noise covariance. Those are different interventions and should be ablated separately.

The strongest exact statements concern compatibility and probability typing. Ambient noising has a calculable disagreement law. Intrinsic noising preserves the compatible subspace. Restrictions constrain admissible covariances. Harmonic displacement requires precision weighting to become the declared energy score. A valid collection of scores must also satisfy the forward generator's consistency conditions. None of these guarantees that a learned model beats an ordinary denoiser.

Sheaf structure can therefore be carried all the way back to DDPM and DDIM. The resulting model should be called generative only when its distribution, forward corruption and reverse dynamics are specified together. Where ASE instead uses an evolving fitness archive to propose better designs, the same vertical schedule remains useful, with the more limited interpretation of a structured optimiser.

# References

[1] Ho, J., Jain, A. and Abbeel, P. (2020). Denoising Diffusion Probabilistic Models. *Advances in Neural Information Processing Systems* 33. https://arxiv.org/abs/2006.11239

[2] Song, J., Meng, C. and Ermon, S. (2021). Denoising Diffusion Implicit Models. *International Conference on Learning Representations*. arXiv:2010.02502v4. https://arxiv.org/abs/2010.02502v4

[3] Song, Y., Sohl-Dickstein, J., Kingma, D. P., Kumar, A., Ermon, S. and Poole, B. (2021). Score-Based Generative Modeling through Stochastic Differential Equations. *International Conference on Learning Representations*. https://arxiv.org/abs/2011.13456

[4] Zhang, Y., Hartl, B., Hazan, H. and Levin, M. (2025). Diffusion Models are Evolutionary Algorithms. *International Conference on Learning Representations*. Revised preprint arXiv:2410.02543v3, 9 May 2026. https://arxiv.org/abs/2410.02543v3

[5] Bodnar, C., Di Giovanni, F., Chamberlain, B. P., Liò, P. and Bronstein, M. M. (2022). Neural Sheaf Diffusion: A Topological Perspective on Heterophily and Oversmoothing in GNNs. *Advances in Neural Information Processing Systems* 35. https://arxiv.org/abs/2202.04579

[6] Bourgerie, R., Girdzijauskas, Š. and Fodor, V. (2026). Deep Neural Sheaf Diffusion. arXiv:2605.19021v2. Accepted at the ICML 2026 Workshop on Graph Foundation Models. https://arxiv.org/abs/2605.19021v2

[7] Hu, C.-S. (2026). A Sheaf-Theoretic and Topological Perspective on Complex Network Modeling and Attention Mechanisms in Graph Neural Models. arXiv:2601.21207v4. AAAI 2026 Workshop on Mathematical Foundations of AI. https://arxiv.org/abs/2601.21207v4

[8] Ghosh, D. P. (2026). Autoregressive Sheaf Evolution. Conversion proposal. Project manuscript.

[9] Ghosh, D. P. (2026). Horizontally Topological, Vertically Algebraic. ASE Part I. Project manuscript.

[10] Ghosh, D. P. (2026). The Horizontal Layer. ASE Part II. Project manuscript.

[11] Ghosh, D. P. (2026). Autoregressive Sheaf Evolution for Memory Consolidation. Version 3, 18 October 2026. Project manuscript.
