# Source notes

Primary sources checked on 18 October 2026:

- Ho, Jain and Abbeel, DDPM: https://arxiv.org/abs/2006.11239 and its primary
  HTML version. Used for the declared Gaussian forward process and denoising
  training setup.
- Song, Meng and Ermon, DDIM: https://arxiv.org/abs/2010.02502v4 and
  https://arxiv.org/html/2010.02502v4. Used for the clean-state sampling
  parameterisation. The coordinate substitution in Theorem 3.1 is shown in full
  in this paper rather than presented as an externally established ASE result.
- Song et al., score-SDE: https://arxiv.org/abs/2011.13456. Used for the relation
  between a specified forward process and time-dependent reverse scores.
- Zhang, Hartl, Hazan and Levin, Diffusion Evolution:
  https://arxiv.org/html/2410.02543v3. The v3 preprint was revised 9 May 2026;
  the conference paper is ICLR 2025. Its population-weighted denoising estimator
  is the external link in the proposed lineage. Its performance claims are not
  reproduced or adopted as results of the present paper.
- Bodnar et al., Neural Sheaf Diffusion:
  https://arxiv.org/abs/2202.04579. This is horizontal graph representation
  learning, not an automatic generative DDPM construction.
- Bourgerie, Girdzijauskas and Fodor, Deep Neural Sheaf Diffusion:
  https://arxiv.org/abs/2605.19021v2. The primary metadata identifies acceptance
  at the ICML 2026 Workshop on Graph Foundation Models; it is not described as a
  main-conference ICML result in this paper.
- Hu, sheaf and attention perspective: https://arxiv.org/abs/2601.21207v4.
  The version and workshop status follow the primary record. Its relational
  framework is related architecture work, not validation of a generative score.

The original project manuscripts supply the four-base vocabulary, harmonic read
and vertical-diagram distinctions. No claim that the literature contains no
prior sheaf-based generative model is made. The mathematical constructions here
are proved under their stated fixed-linear-model assumptions; angles, changing
covers and nonlinear geometry are explicitly deferred.
