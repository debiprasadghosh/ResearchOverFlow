// Governable-agent reference kernel (Version 2): family ledger, attenuated
// capabilities, leases, binding index, retry amplification, replication
// threshold, deterrence and verification floor.
// Immutable records and pure static functions; the linear solve and the
// fixed-point iteration work on private copies.
using System;
using System.Collections.Immutable;
using System.Linq;

namespace Governance;

/// <summary>Family ledger (Proposition 2): balances, expenditure, budget.
/// Every transition returns a new ledger; a refused transition returns
/// the same ledger and false.</summary>
public sealed record Ledger(ImmutableDictionary<string, long> Balances,
                            long Expended, long Budget)
{
    public static Ledger Open(long budget) =>
        new(ImmutableDictionary<string, long>.Empty.Add("root", budget), 0, budget);

    long Bal(string k) => Balances.TryGetValue(k, out var b) ? b : 0;

    public (Ledger Next, bool Ok) Spend(string k, long c) =>
        c >= 0 && Bal(k) >= c
            ? (this with { Balances = Balances.SetItem(k, Bal(k) - c),
                           Expended = Expended + c }, true)
            : (this, false);

    /// <summary>Transfer, never copy: debit the parent, credit the child.</summary>
    public (Ledger Next, bool Ok) Delegate(string k, string child, long c) =>
        c >= 0 && Bal(k) >= c && k != child
            ? (this with { Balances = Balances
                  .SetItem(k, Bal(k) - c).SetItem(child, Bal(child) + c) }, true)
            : (this, false);

    public Ledger Release(string k, long c)
    {
        long r = Math.Min(Math.Max(c, 0), Bal(k));
        return this with { Balances = Balances.SetItem(k, Bal(k) - r)
                                              .SetItem("root", Bal("root") + r) };
    }

    /// <summary>The conserved quantity E + sum of balances.</summary>
    public long Total => Expended + Balances.Values.Sum();
}

/// <summary>An attenuable capability (Proposition 7).</summary>
public sealed record Capability(ImmutableSortedSet<int> Scope, double Expiry)
{
    /// <summary>Child grant: a subset of the scope and no later expiry,
    /// or null when the request would widen authority.</summary>
    public Capability? Attenuate(ImmutableSortedSet<int> scope, double expiry) =>
        scope.IsSubsetOf(Scope) && expiry <= Expiry ? new(scope, expiry) : null;

    /// <summary>Admission against the requester's own capability, using the
    /// verifier clock reading.</summary>
    public bool Admits(int effect, double verifierTime) =>
        Scope.Contains(effect) && verifierTime < Expiry;
}

public static class Kernel
{
    /// <summary>Binding index (Proposition 4): max of (I - A)^{-1} 1,
    /// valid when rho(A) &lt; 1.</summary>
    public static double BindingIndex(ImmutableArray<ImmutableArray<double>> a)
    {
        int n = a.Length;
        var m = new double[n, n + 1];
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++) m[i, j] = (i == j ? 1 : 0) - a[i][j];
            m[i, n] = 1;
        }
        for (int c = 0; c < n; c++)
        {
            int piv = Enumerable.Range(c, n - c)
                .OrderByDescending(r => Math.Abs(m[r, c])).First();
            for (int j = 0; j <= n; j++)
                (m[c, j], m[piv, j]) = (m[piv, j], m[c, j]);
            for (int r = 0; r < n; r++)
            {
                if (r == c) continue;
                double f = m[r, c] / m[c, c];
                for (int j = c; j <= n; j++) m[r, j] -= f * m[c, j];
            }
        }
        return Enumerable.Range(0, n).Max(i => m[i, n] / m[i, i]);
    }

    /// <summary>Proposition 6: attempts reaching a persistently failing
    /// service, with R retries per layer or a retry-budget ratio per
    /// layer.</summary>
    public static double NestedAttempts(int depth, int retries) =>
        Math.Pow(retries + 1, depth);

    public static double BudgetedAttempts(int depth, double ratio) =>
        Math.Pow(1 + ratio, depth);

    /// <summary>Proposition 10: copies a family ledger can ever create.</summary>
    public static long MaxCopies(long budget, long costPerCopy) =>
        budget / costPerCopy + 1;

    /// <summary>Proposition 11: extinction probability of an escaped lineage,
    /// geometric lifetime (removal p per step), Poisson(lambda) copies per
    /// step alive; smallest fixed point by monotone iteration from zero.</summary>
    public static double Extinction(double lambda, double p)
    {
        double F(double s)
        {
            double e = Math.Exp(lambda * (s - 1));
            return p * e / (1 - (1 - p) * e);
        }
        double q = 0;
        for (int i = 0; i < 200000; i++)
        {
            double next = F(q);
            if (Math.Abs(next - q) < 1e-15) return next;
            q = next;
        }
        return q;
    }

    /// <summary>Proposition 12: lifetime values of cooperation and
    /// opportunism, and the detection threshold for deterrence.</summary>
    public static (double Coop, double Opp) Values(
        double w, double g, double p, double q) =>
        (w / q, (w + g) / (1 - (1 - p) * (1 - q)));

    public static double DeterrenceThreshold(double w, double g, double q) =>
        q * g / (w * (1 - q));

    /// <summary>Proposition 9: share of a partition (exponential, mean mu)
    /// during which a lease of length delta, renewed every r, still runs.</summary>
    public static double PartitionAvailability(double delta, double r, double mu) =>
        1 - mu / r * (Math.Exp(-(delta - r) / mu) - Math.Exp(-delta / mu));

    /// <summary>Proposition 3: latest monitored effect after revocation
    /// at time t.</summary>
    public static double CessationBound(
        double t, double delta, double eps, double l) =>
        t + delta + eps + l;

    /// <summary>Proposition 13: false claims accepted by k verifiers with
    /// common-mode miss c and independent miss m.</summary>
    public static double FalseAcceptance(double f, double m, double c, int k) =>
        f * (c + (1 - c) * Math.Pow(m, k));
}
