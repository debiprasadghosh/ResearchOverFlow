// Validation run; cs_validate.py recomputes every printed number with an
// independent Python implementation.
using System;
using System.Collections.Immutable;
using System.Globalization;
using System.Linq;
using Governance;

static string F(double x) => x.ToString("G15", CultureInfo.InvariantCulture);
static void Print(string name, params double[] xs) =>
    Console.WriteLine(name + " " + string.Join(" ", xs.Select(F)));
static ImmutableArray<ImmutableArray<double>> M(double[][] rows) =>
    rows.Select(r => r.ToImmutableArray()).ToImmutableArray();

// a fixed ledger script: spend, delegate, overspend attempt, release, spend
var l0 = Ledger.Open(100);
var (l1, ok1) = l0.Spend("root", 30);
var (l2, ok2) = l1.Delegate("root", "a1", 50);
var (l3, ok3) = l2.Spend("a1", 60);              // refused: a1 holds 50
var (l4, ok4) = l3.Delegate("a1", "a2", 20);
var l5 = l4.Release("a2", 15);
var (l6, ok6) = l5.Spend("a2", 5);
Print("ledger_admitted", new[] { ok1, ok2, ok3, ok4, ok6 }
      .Select(b => b ? 1.0 : 0.0).ToArray());
Print("ledger_final", l6.Expended, l6.Balances["root"], l6.Balances["a1"],
      l6.Balances["a2"], l6.Total);

// attenuation: a widening request is refused; admission respects expiry
var root = new Capability(ImmutableSortedSet.Create(1, 2, 3, 5, 8), 100);
var child = root.Attenuate(ImmutableSortedSet.Create(2, 3, 5), 60)!;
var widen = child.Attenuate(ImmutableSortedSet.Create(2, 9), 50);
Print("capability", widen is null ? 1 : 0, child.Admits(3, 59.9) ? 1 : 0,
      child.Admits(3, 60.0) ? 1 : 0, child.Admits(1, 10) ? 1 : 0);

// binding indices: hub, monolith, split with broker
var hub = M(new[] {
    new[] { 0.0, 0.3, 0.3, 0.3, 0.3 }, new[] { 0.2, 0.0, 0.0, 0.0, 0.0 },
    new[] { 0.2, 0.0, 0.0, 0.0, 0.0 }, new[] { 0.2, 0.0, 0.0, 0.0, 0.0 },
    new[] { 0.2, 0.0, 0.0, 0.0, 0.0 } });
var mono = M(new[] { new[] { 0.0, 0.3, 0.3 }, new[] { 0.3, 0.0, 0.3 },
                     new[] { 0.3, 0.3, 0.0 } });
var split = M(new[] {
    new[] { 0.0, 0.1, 0.1, 0.3 }, new[] { 0.1, 0.0, 0.1, 0.3 },
    new[] { 0.1, 0.1, 0.0, 0.3 }, new[] { 0.3, 0.3, 0.3, 0.0 } });
Print("binding_index", Kernel.BindingIndex(hub), Kernel.BindingIndex(mono),
      Kernel.BindingIndex(split));

var depths = Enumerable.Range(1, 5).ToArray();
Print("retries", depths.Select(d => Kernel.NestedAttempts(d, 3))
      .Concat(depths.Select(d => Kernel.BudgetedAttempts(d, 0.1))).ToArray());
Print("max_copies", Kernel.MaxCopies(100, 10), Kernel.MaxCopies(1000, 7));
Print("extinction", new[] { 0.9, 1.1, 1.3, 1.6, 2.0, 3.0 }
      .Select(m => Kernel.Extinction(m * 0.25, 0.25)).ToArray());
var v = Kernel.Values(1, 0.5, 0.02, 0.01);
Print("deterrence", v.Coop, v.Opp, Kernel.DeterrenceThreshold(1, 0.5, 0.01),
      Kernel.DeterrenceThreshold(1, 0.2, 0.01));
Print("partition_availability", new[] { 2.0, 5, 10, 20, 40, 80, 160 }
      .Select(d => Kernel.PartitionAvailability(d, 1, 30)).ToArray());
Print("cessation", Kernel.CessationBound(50, 5, 0.5, 2));
Print("false_acceptance", new[] { 1, 2, 3, 5, 8 }
      .Select(k => Kernel.FalseAcceptance(0.1, 0.2, 0.05, k)).ToArray());
