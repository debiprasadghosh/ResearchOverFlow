"""Checks for 'The Bhagavad Gita and the Design of Governable AI Agents', Version 2.

Every proposition of the paper is checked here, either as an identity or bound on random
instances, or by a seeded simulation of the stated model. No deployed system is measured.
Writes results.json next to this file.
"""
from pathlib import Path
import json, math, sys
import numpy as np
from scipy.optimize import brentq

P = Path(__file__).resolve().parent
SEED = 20261019
rng = np.random.default_rng(SEED)
R = {'seed': SEED, 'python': sys.version.split()[0], 'numpy': np.__version__}
tests = []


def check(name, ok):
    tests.append({'name': name, 'passed': bool(ok)})


def rho(A):
    return float(max(abs(np.linalg.eigvals(A))))


def kappa(A):
    """Binding index: long-run worst-case disturbance per unit external disturbance."""
    return float(np.max(np.linalg.solve(np.eye(len(A)) - A, np.ones(len(A)))))


# ------------------------------------------------------------------ Section 7: cascades
# V1 Proposition 1 (row sums) on random instances
v1_viol = 0
for _ in range(300):
    n = int(rng.integers(3, 9))
    A = rng.uniform(0, 1, (n, n)) * (rng.uniform(size=(n, n)) < .5)
    a = float(rng.uniform(.2, .95))
    A *= a / max(A.sum(1).max(), 1e-12)
    U = float(rng.uniform(.1, 2)); x = rng.uniform(0, 3, n); X0 = x.max()
    for t in range(1, 40):
        x = A @ x + rng.uniform(0, U, n)
        v1_viol += x.max() > a ** t * X0 + U * (1 - a ** t) / (1 - a) + 1e-9
check('V1 Proposition 1 bound holds on 300 random instances', v1_viol == 0)

# Proposition 4: weighted bound with a positive vector v, A v <= a v
p4_viol = 0; tight = []
for _ in range(300):
    n = int(rng.integers(3, 9))
    A = rng.uniform(0, 1, (n, n)) * (rng.uniform(size=(n, n)) < .5) + 1e-3
    r_target = float(rng.uniform(.3, .95))
    A *= r_target / rho(A)
    w, V = np.linalg.eig(A)
    k = int(np.argmax(w.real)); v = np.abs(V[:, k].real); v /= v.max()
    a = float(np.max(A @ v / v))
    Uv = float(rng.uniform(.1, 2)); x = rng.uniform(0, 3, n) * v
    X0v = float(np.max(x / v))
    for t in range(1, 60):
        x = A @ x + rng.uniform(0, Uv, n) * v
        bound = a ** t * X0v + Uv * (1 - a ** t) / (1 - a)
        p4_viol += np.max(x / v) > bound + 1e-9
    tight.append(abs(a - r_target))
check('Proposition 4 weighted bound holds on 300 random instances', p4_viol == 0)
check('Perron weighting attains a = rho(A)', max(tight) < 1e-9)

# kappa equals the long-run worst case of x(t+1) = A x + 1
kap_err = 0.0
for _ in range(100):
    n = int(rng.integers(3, 9))
    A = rng.uniform(0, 1, (n, n)) * (rng.uniform(size=(n, n)) < .5)
    A *= float(rng.uniform(.2, .9)) / max(rho(A), 1e-9)
    x = np.zeros(n)
    for _ in range(3000):
        x = A @ x + 1
    kap_err = max(kap_err, abs(x.max() - kappa(A)) / kappa(A))
check('binding index equals the long-run worst-case response', kap_err < 1e-9)
R['kappa_err'] = kap_err

# the hub example: row-sum condition fails, spectral condition holds
hub = np.zeros((5, 5)); hub[0, 1:] = 0.3; hub[1:, 0] = 0.2
hub_rowmax = float(hub.sum(1).max()); hub_rho = rho(hub); hub_kappa = kappa(hub)
x = np.zeros(5); traj = []
for t in range(40):
    x = hub @ x + 1; traj.append(float(x.max()))
R['hub'] = {'row_sum_max': hub_rowmax, 'rho': hub_rho, 'rho_exact': math.sqrt(4 * 0.3 * 0.2),
            'kappa': hub_kappa, 'trajectory': traj, 'kappa_closed': (1 + 4 * 0.3) / (1 - 0.24)}
check('hub architecture violates the row-sum condition', hub_rowmax > 1)
check('hub spectral radius equals sqrt(4 x 0.3 x 0.2)', abs(hub_rho - math.sqrt(.24)) < 1e-12)
check('hub binding index matches its closed form (1 + 1.2)/(1 - 0.24)', abs(hub_kappa - 2.2 / 0.76) < 1e-12)

# necessity: rho >= 1 gives unbounded accumulation under a constant positive input
grow = np.array([[0.5, 0.6], [0.6, 0.5]]); x = np.zeros(2)
for _ in range(200):
    x = grow @ x + 1
check('rho(A) >= 1 gives unbounded accumulation', rho(grow) >= 1 and x.max() > 100)

# monotonicity under the spectral condition (Corollary 5)
mono_viol = 0
for _ in range(300):
    n = int(rng.integers(3, 8))
    A = rng.uniform(0, 1, (n, n)); A *= float(rng.uniform(.3, .95)) / rho(A)
    Ap = A * rng.uniform(0, 1, (n, n))
    u = rng.uniform(0, 1, n)
    lhs = np.linalg.solve(np.eye(n) - Ap, u); rhs = np.linalg.solve(np.eye(n) - A, u)
    mono_viol += np.any(lhs > rhs + 1e-9)
check('Proposition 5: A\' <= A and rho(A) < 1 imply smaller accumulation', mono_viol == 0)

# V1 row-sum bound against the exact index on the same random matrices
ratios = []
for _ in range(500):
    n = int(rng.integers(3, 9))
    A = rng.uniform(0, 1, (n, n)) * (rng.uniform(size=(n, n)) < .5)
    a = float(rng.uniform(.3, .9)); A *= a / max(A.sum(1).max(), 1e-12)
    ratios.append(kappa(A) * (1 - a))
R['row_sum_conservatism'] = {'instances': 500, 'median_kappa_over_bound': float(np.median(ratios)),
                             'min_kappa_over_bound': float(np.min(ratios))}
check('exact index never exceeds the V1 bound', max(ratios) <= 1 + 1e-12)

# extraction example: splitting a monolith can raise the binding index
mono = np.array([[0, .3, .3], [.3, 0, .3], [.3, .3, 0]])
split = np.zeros((4, 4))                       # three services and a shared broker (index 3)
split[:3, :3] = np.array([[0, .1, .1], [.1, 0, .1], [.1, .1, 0]])
split[:3, 3] = 0.3                             # broker disturbs each service
split[3, :3] = 0.3                             # each service disturbs the broker
R['extraction'] = {'kappa_monolith': kappa(mono), 'kappa_split': kappa(split),
                   'rho_monolith': rho(mono), 'rho_split': rho(split),
                   'direct_coupling_before': 0.3, 'direct_coupling_after': 0.1, 'broker_coupling': 0.3}
check('extraction with a shared broker raises the binding index here', kappa(split) > kappa(mono))

# Proposition 6: retry amplification
def chain_attempts(depth, retries, budget=None, requests=1000):
    """Persistent failure at the bottom of a call chain; returns attempts reaching the bottom."""
    incoming = requests
    for _ in range(depth):
        if budget is None:
            incoming = incoming * (retries + 1)
        else:
            extra = min(incoming * retries, math.floor(budget * incoming))
            incoming = incoming + extra
    return incoming / requests


def chain_sim(depth, retries, rng):
    """Explicit recursive simulation of one request; counts bottom attempts."""
    def call(level):
        if level == depth:
            return 1, False                     # one attempt, always fails
        count = 0
        for _ in range(retries + 1):
            c, ok = call(level + 1); count += c
            if ok:
                return count, True
        return count, False
    return call(0)[0]


retry_rows = []
for d in range(1, 6):
    retry_rows.append({'depth': d, 'R3': chain_sim(d, 3, rng), 'R3_formula': 4 ** d,
                       'budget10': chain_attempts(d, 3, 0.1), 'budget10_formula': 1.1 ** d,
                       'single_layer': 4})
R['retries'] = {'rows': retry_rows, 'sre_example': chain_sim(3, 3, rng)}
check('nested retries multiply: (R+1)^d bottom attempts', all(r['R3'] == r['R3_formula'] for r in retry_rows))
check('SRE example: three layers of four attempts give 64', R['retries']['sre_example'] == 64)
check('a 10% retry budget per layer bounds amplification by 1.1^d',
      all(r['budget10'] <= r['budget10_formula'] + 1e-12 for r in retry_rows))

# ------------------------------------------------------------------ Section 8: ledger, attenuation, leases
class Ledger:
    """Atomic family ledger: balances and cumulative expenditure; returns True if a transition is admitted."""
    def __init__(self, B0):
        self.b = {'root': B0}; self.E = 0; self.B0 = B0

    def spend(self, k, c):
        if self.b.get(k, 0) >= c:
            self.b[k] -= c; self.E += c; return True
        return False

    def delegate(self, k, child, c):
        if self.b.get(k, 0) >= c:
            self.b[k] -= c; self.b[child] = self.b.get(child, 0) + c; return True
        return False

    def release(self, k, c):
        c = min(c, self.b.get(k, 0)); self.b[k] -= c; self.b['root'] += c


inv_viol = 0; steps = 0
for trial in range(200):
    L = Ledger(int(rng.integers(50, 500))); names = ['root']
    for _ in range(300):
        k = names[int(rng.integers(len(names)))]; op = rng.integers(3); c = int(rng.integers(0, 40))
        if op == 0:
            L.spend(k, c)
        elif op == 1:
            nm = f'a{len(names)}'
            if L.delegate(k, nm, c):
                names.append(nm)
        else:
            L.release(k, c)
        steps += 1
        inv_viol += (L.E + sum(L.b.values()) > L.B0) or min(L.b.values()) < 0
check('Proposition 2: E + sum of balances never exceeds B0 (atomic ledger)', inv_viol == 0)
R['ledger'] = {'trials': 200, 'transitions': steps, 'violations': int(inv_viol)}

# non-atomic check-then-spend race: k agents check a shared balance, then all spend
race = []
for k in (1, 2, 4, 8, 16):
    bal, cost = 10, 10
    passed = sum(1 for _ in range(k) if bal >= cost)    # all checks see the same balance
    spent = passed * cost
    race.append({'agents': k, 'spent': spent, 'budget': bal, 'overspend': spent - bal})
R['race'] = race
check('check-then-spend with k concurrent agents overspends by (k-1)c', all(r['overspend'] == (r['agents'] - 1) * 10 for r in race))

# Proposition 7: reservation with bounded overrun
over_viol = 0; worst = 0.0
for _ in range(300):
    B0 = 100.0; k = int(rng.integers(1, 10)); omega = float(rng.uniform(0, 5))
    bal, E = B0, 0.0; inflight = []
    for step in range(200):
        if len(inflight) < k and rng.uniform() < .6:
            r = float(rng.uniform(1, 10))
            if bal >= r:
                bal -= r; inflight.append(r)
        elif inflight:
            r = inflight.pop(int(rng.integers(len(inflight))))
            actual = r + float(rng.uniform(-r, omega))        # may be below or up to omega above reservation
            E += actual; bal += r - actual                    # settle; balance may go negative by overruns
        if omega > 0:
            worst = max(worst, (E - B0) / (k * omega))
        over_viol += E > B0 + k * omega + 1e-9
R['overrun'] = {'trials': 300, 'violations': int(over_viol), 'max_excess_over_k_omega': worst}
check('Proposition 8: expenditure exceeds B0 by at most k omega', over_viol == 0)


# Proposition 8: replication under a family ledger versus per-agent caps
def replicate(mode, B0=100, cap=30, cost=10, gens=8):
    pop, total = 1, 1; family = B0; rows = [1]
    for g in range(gens):
        children = 0
        if mode == 'family':
            can = min(pop * (cap // cost), family // cost)
            children = can; family -= can * cost
        else:
            children = pop * (cap // cost)                     # each copy gets a fresh cap
        pop = children; total += children; rows.append(total)
        if pop == 0:
            rows += [total] * (gens - g - 1); break
    return rows


rep_cap = replicate('cap'); rep_fam = replicate('family')
R['replication'] = {'per_agent_cap': rep_cap, 'family_ledger': rep_fam, 'B0': 100, 'cost': 10, 'cap': 30}
check('Proposition 10: family ledger bounds copies by B0/c + 1', rep_fam[-1] <= 100 // 10 + 1)
check('per-agent caps let copies grow geometrically', rep_cap[-1] == sum(3 ** g for g in range(9)))

# Proposition 9: attenuation closure on random delegation trees, and the confused deputy
EFFECTS = list(range(12))
att_viol = 0; deputy_viol = 0; admitted = 0
for _ in range(300):
    root = {'scope': set(rng.choice(EFFECTS, 6, replace=False).tolist()), 'expiry': 100.0, 'parent': None}
    caps = [root]
    for _ in range(30):
        par = caps[int(rng.integers(len(caps)))]
        sc = set(x for x in par['scope'] if rng.uniform() < .7)
        caps.append({'scope': sc, 'expiry': par['expiry'] * float(rng.uniform(.5, 1)), 'parent': par})
    deputy = {'scope': set(EFFECTS), 'expiry': 1e9}           # a tool with broad ambient authority
    for _ in range(200):
        c = caps[int(rng.integers(len(caps)))]; e = int(rng.integers(12)); t = float(rng.uniform(0, 120))
        if e in c['scope'] and t < c['expiry']:               # admission against the requester's capability
            admitted += 1
            att_viol += not (e in root['scope'] and t < root['expiry'])
        if e in deputy['scope'] and t < deputy['expiry']:     # admission against the deputy's ambient authority
            deputy_viol += not (e in root['scope'] and t < root['expiry'])
R['attenuation'] = {'trees': 300, 'requests': 60000, 'admitted': admitted, 'violations': att_viol,
                    'confused_deputy_violations': deputy_viol}
check('Proposition 7: every admitted effect lies in root scope before root expiry', att_viol == 0)
check('admission by ambient authority (confused deputy) breaks the closure', deputy_viol > 0)

# Proposition 3 (V1) and the tree corollary: cessation bound by event simulation
cess_viol = 0; margins = []
for _ in range(300):
    T, Delta, eps, Lop = 50.0, float(rng.uniform(1, 10)), float(rng.uniform(0, 1)), float(rng.uniform(0, 3))
    last = 0.0
    lease_end = T + Delta                                     # last renewal at T at the latest
    for _ in range(400):
        child_end = lease_end * 1.0 if rng.uniform() < .5 else lease_end - float(rng.uniform(0, Delta))
        t = float(rng.uniform(0, T + 2 * Delta + 5))
        lag = float(rng.uniform(0, eps))                      # verifier clock reads t - lag
        if t - lag < child_end:
            last = max(last, t + float(rng.uniform(0, Lop)))
    cess_viol += last > T + Delta + eps + Lop + 1e-9
    margins.append((T + Delta + eps + Lop) - last)
check('Propositions 3 and 7: monitored effects in a delegation tree cease by T + Delta + eps + L', cess_viol == 0)
R['cessation'] = {'trials': 300, 'violations': cess_viol, 'min_margin': float(min(margins))}


# Proposition 10: lease length against availability during partitions
def avail_formula(Delta, r, mu):
    return 1 - (mu / r) * (math.exp(-(Delta - r) / mu) - math.exp(-Delta / mu))


lease_rows = []; lease_err = 0.0
mu, r_ren = 30.0, 1.0
for Delta in (2, 5, 10, 20, 40, 80, 160):
    a = rng.uniform(Delta - r_ren, Delta, 200000); D = rng.exponential(mu, 200000)
    mc = float(np.minimum(D, a).mean() / D.mean())
    th = avail_formula(Delta, r_ren, mu)
    lease_err = max(lease_err, abs(mc - th))
    lease_rows.append({'Delta': Delta, 'availability_mc': mc, 'availability': th})
R['lease'] = {'mean_partition': mu, 'renewal_period': r_ren, 'rows': lease_rows, 'max_mc_error': lease_err}
check('Proposition 9: partition availability formula matches simulation', lease_err < 0.005)

# ------------------------------------------------------------------ Section 9: replication ecology
def pgf(s, lam, p):
    e = math.exp(lam * (s - 1))
    return p * e / (1 - (1 - p) * e)


def extinction(lam, p):
    m = lam / p
    if m <= 1:
        return 1.0
    return brentq(lambda s: pgf(s, lam, p) - s, 0.0, 1 - 1e-12)


def gw_mc(lam, p, trials, rng, cap=400, gens=60):
    dead = 0
    for _ in range(trials):
        z = 1
        for _ in range(gens):
            life = rng.geometric(p, z)
            z = int(rng.poisson(lam * life).sum())
            if z == 0 or z > cap:
                break
        dead += z == 0
    return dead / trials


branch = []; br_err = 0.0
p_rm = 0.25
for m in (0.6, 0.9, 1.1, 1.3, 1.6, 2.0, 3.0):
    lam = m * p_rm
    q = extinction(lam, p_rm); mc = gw_mc(lam, p_rm, 4000, rng)
    branch.append({'m': m, 'extinction': q, 'extinction_mc': mc})
    if m > 1.05:
        br_err = max(br_err, abs(q - mc))
R['branching'] = {'removal_prob': p_rm, 'rows': branch, 'max_mc_error_supercritical': br_err}
check('Proposition 11: subcritical copies die out (simulated extinction >= 0.95 for m <= 0.9)',
      all(b['extinction_mc'] >= .95 for b in branch if b['m'] <= .9))
check('Proposition 11: supercritical extinction probability matches the pgf fixed point', br_err < 0.03)


# Proposition 12: deterrence in a repeated relationship
def values(w, g, p, q):
    return w / q, (w + g) / (1 - (1 - p) * (1 - q))


det = []; det_err = 0.0
for (w, g, p, q) in ((1, .5, .02, .01), (1, .5, .01, .02), (1, .2, .001, .01), (1, 2, .05, .02)):
    vc, vo = values(w, g, p, q)
    n = 100000
    life_c = rng.geometric(q, n); life_o = rng.geometric(1 - (1 - p) * (1 - q), n)
    det.append({'w': w, 'g': g, 'p': p, 'q': q, 'V_coop': vc, 'V_opp': vo,
                'V_coop_mc': float(w * life_c.mean()), 'V_opp_mc': float((w + g) * life_o.mean()),
                'threshold_p': q * g / (w * (1 - q)), 'opportunism_pays': vo > vc})
    det_err = max(det_err, abs(w * life_c.mean() - vc) / vc, abs((w + g) * life_o.mean() - vo) / vo)
R['deterrence'] = {'rows': det, 'max_relative_mc_error': det_err}
check('Proposition 12: opportunism pays exactly when p < q g / (w (1 - q))',
      all((r['p'] < r['threshold_p']) == r['opportunism_pays'] for r in det))
check('Proposition 12: value formulas match simulation within 2%', det_err < 0.02)

# Proposition 13: verification floor under common-mode failure
ver = []
f, miss, c = 0.1, 0.2, 0.05
for k in (1, 2, 3, 5, 8):
    n = 400000
    false = rng.uniform(size=n) < f
    common = rng.uniform(size=n) < c
    allmiss = np.all(rng.uniform(size=(n, k)) < miss, axis=1)
    accepted_false = false & (common | allmiss)
    ver.append({'k': k, 'false_accept_mc': float(accepted_false.mean()),
                'false_accept': f * (c + (1 - c) * miss ** k), 'floor': f * c})
R['verification'] = {'f': f, 'miss': miss, 'common_mode': c, 'rows': ver}
check('Proposition 13: false acceptance matches f(c + (1-c) m^k)',
      max(abs(v['false_accept_mc'] - v['false_accept']) for v in ver) < 0.002)
check('Proposition 13: additional verifiers cannot go below the common-mode floor',
      all(v['false_accept'] >= v['floor'] for v in ver))

R['checks'] = tests; R['check_count'] = len(tests); R['all_pass'] = all(t['passed'] for t in tests)
(P / 'results.json').write_text(json.dumps(R, indent=1) + '\n')
for t in tests:
    print(('PASS ' if t['passed'] else 'FAIL ') + t['name'])
print(len(tests), 'checks')
