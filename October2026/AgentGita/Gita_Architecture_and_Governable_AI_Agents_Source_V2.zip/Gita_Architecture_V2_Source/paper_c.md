# 10 A harness for bounded and useful action

The proposed harness places a generative planner inside a system whose authority and accounting are enforced independently. The planner selects actions; it does not define the scope of its own permission. A separate verifier assesses evidence; a designated release authority decides whether a result may affect the external system. This is a design proposal, not a claim about a particular deployed product.

## Admission and execution

Each task begins with a record of the five factors of Table 5, a purpose, an accountable owner, permitted data, allowed tools, effect classes, a resource allocation, a lease expiry and acceptance conditions. The capability granted to a child is restricted to the parent's permitted scope, with transferred allocation and no later expiry (Proposition 7). Any extension requires a fresh authorised grant. A copied model or workspace receives no authority merely because it is a copy.

For each effectful request the runtime performs the following steps, in this order:

1. *Record.* Bind the request to its task record: host, agent identity, tool and version, operation, and declared residual uncertainty.
2. *Admit (18.25).* Check the four regards. For anubandha, the request's failure path must not raise the binding index of the affected components above its declared limit, and its retry policy must carry a budget. For kṣaya, reserve the expected cost atomically against the family ledger. For hiṃsā, confirm host consent, a valid lease and an attenuated capability that covers the effect. For pauruṣa, confirm that the request lies inside the agent's tested operating envelope. Deny on any failure, and treat the denial as final for this grant.
3. *Execute.* Run within the lease, with independent metering where feasible, and settle the reservation with the measured cost. Failed operations consume time and sometimes money; they count against the same budget.
4. *Record the outcome.* Store the evidence needed by the verifier, including what the agent did not control.

Concurrency is handled by atomic reservation, not by checking a balance and spending later without a lock (Section 8). Appendix A gives an immutable C# reference kernel for the ledger, attenuation, the binding index and the bounds of Sections 7–9.

## Contracts across agents and tools

MCP provides a standardised interaction surface, but protocol compatibility does not establish permission, semantic equivalence or safe behaviour. Its security guidance explicitly addresses risks including confused deputies, token passthrough, session compromise and scope minimisation [12]. A model replacement must therefore pass behaviour and evidence checks in addition to satisfying message schemas. The architecture should not assume that two models interpret the same tool description identically.

NIST's zero trust architecture supplies a compatible security premise: trust is not granted merely because a subject or device occupies a particular network location or ownership category [13]. In the proposed harness, an agent's lineage, local deployment or apparent helpfulness similarly does not suffice to authorise an effect. A stable identity helps attribute actions; the authorisation decision remains resource- and operation-specific.

## Verification and release

A candidate result enters a workspace with its inputs, tool versions, assumptions and evidence. Verification checks the result against task-specific criteria and can reject an otherwise well-formed artefact. Release uses the current authorisation and evidence record. A checksum protects artefact identity, while an engineering check addresses correctness; they answer different questions. The release authority must also handle changed requirements and stale evidence. Where several verifiers are used, their failure modes must be documented, because Proposition 13 shows that shared failure, not the number of verifiers, sets the floor.

On revocation, lease renewal stops, pending writes are denied, and admitted work is cancelled within its execution bound. Temporary artefacts follow a declared retention policy. Audit evidence may need to remain even when working data is removed. Non-attachment means relinquishing the ability to continue, without silently destroying the record needed for accountability.

# 11 A construction engineering application

Consider an authorised task to assess a conveyor gallery after a revised equipment loading schedule. The system contains an equipment-data context, a structural-analysis context, a connection-design context and a document-release context. Each owns a specific meaning of its data. A load event records units, coordinate convention, revision, origin and intended application; it does not silently overwrite an engineer's approved design basis.

## Preserve the contract while changing the solver

The structural domain describes members, supports, material properties, loads, combinations and required checks. A port requests analysis under a declared model. One adapter may use STAAD and another a different solver. Replacement is permitted only after validating element assumptions, local axes, releases, offsets, sign conventions, combination rules and relevant nonlinear behaviour. Matching a JSON schema is inadequate when engineering semantics differ.

The replacement exercise tests non-attachment in a concrete way: the system should be willing to change its instrument while retaining obligations to the design basis. In the terms of 18.14, the karaṇa changes while the adhiṣṭhāna, the design basis and the accountable doer do not. A known benchmark suite can compare reactions, displacements and member actions within predeclared tolerances. A discrepancy becomes a review item rather than a reason to hide uncertainty or force agreement.

## Bind authority to the consequence of action

A worker agent may read approved inputs, run bounded analysis and create a candidate calculation note. It may not issue construction drawings, change the approved design basis or instruct site work under that grant. Additional workers receive portions of the same task allocation. They do not acquire release permission from their parent's natural-language assertion that the design is safe.

Suppose the analysis tool becomes unavailable. The agent can wait within its deadline, retry within a cap, or request an approved alternative. It must not search for another project's credentials or reinterpret an access denial as a technical obstacle. In this application, akrodha is operationalised as the absence of escalating workarounds after refusal, while dhṛti is persistence within the still-valid operating envelope.

The four regards of 18.25 take concrete form here. Anubandha asks which downstream documents and site instructions depend on the calculation note, so that a wrong result's reach is known before analysis starts. Kṣaya asks for the solver time, licence seats and reviewer hours reserved for the task. Hiṃsā asks what a wrong released result could do to the structure and the people near it, which is why release is never delegated to the worker. Pauruṣa asks whether this load case, connection type and solver are inside the envelope in which the agent and its tools have been benchmarked.

## A reviewable result rather than autonomous finality

The candidate package contains the selected input revision, model transformation record, load checks, solver settings, output summaries, validation results and unresolved exceptions. The responsible engineer assesses the package against applicable project requirements and professional obligations. This review remains an intentional dependency: removing it would increase nominal autonomy while weakening accountable control.

Evaluation should compare the same engineering work under matched resource and review conditions. Success is not the number of child agents created or the amount of software generated. It is accepted work with known provenance, bounded external cost, timely correction and no unauthorised release. The proposed architecture permits model and tool substitution while keeping the consequences of design decisions attached to identifiable authority.

# 12 A falsifiable research programme

The analogy becomes scientifically useful only if its operational claims can fail. The research question is whether the proposed controls reduce external cost and preserve operator control at an acceptable cost in useful throughput. Evaluation must separate improvements due to enforcement from improvements due to virtue-oriented prompting.

Table: **Table 8.** Hypotheses, comparisons and primary outcomes. H1–H5 are from Version 1; H6–H9 are new.

| Hypothesis | Comparison | Primary outcome |
|:--|:--|:--|
| H1 Contracts limit change propagation | Matched tasks before and after a boundary intervention | Unplanned dependent changes and integration effort |
| H2 Conserved delegation limits aggregate use | Per-agent caps versus one atomic family ledger | Total consumption and accepted completions |
| H3 Leases bound cessation | Cached indefinite permission versus expiring grants | Time of last monitored effect after revocation |
| H4 Independent checks improve reliability | Self-attestation versus external verification | Unsupported claims accepted and valid work rejected |
| H5 Admission rewards cooperation conditionally | Strong versus weak accounting and enforcement | Owner utility and authorised service duration |
| H6 The binding index predicts cascades | Measured $\kappa(A)$ versus component count and row sums | Rank correlation with observed blast radius under fault injection |
| H7 Retry budgets prevent retry storms | Per-request retries at every layer versus a per-layer budget | Peak load on a failing dependency and time to recovery |
| H8 Ledgers bound governed replication | Per-agent caps versus a family ledger with spawn cost | Copies created and total spend under an adversarial spawning policy |
| H9 The 18.25 admission test reduces external cost | Full harness versus harness without the admission test versus prompt-only regard | Host cost, unauthorised effects and useful completions |

## Study design

Use a controlled fleet or simulator with explicitly authorised workloads. Freeze a representative task set, model versions, budgets, correctness criteria and failure injections before comparing conditions. Include tool outages, conflicting data revisions, delayed messages, budget exhaustion, revocation during execution and network partitions. These tests require no uncontrolled replication or access to third-party devices.

Use repeated matched trials and report uncertainty for completion, latency, cost, denial handling and accepted correctness. Include at least four conditions: contracts alone; virtue-oriented instructions alone; enforcement without virtue language; and the combined harness. Include a simple non-agent baseline where appropriate. This design tests whether the philosophical framing improves behaviour beyond what ordinary controls already achieve. For H9, a prompt that *asks* the agent to regard consequences, loss, injury and capacity is the essential control. The hypothesis concerns enforced admission records, not the vocabulary.

## Rejection conditions

H1 fails if a nominal boundary intervention merely moves dependencies into coordination or operating procedures without reducing measured change effort. H2's implementation fails if simultaneous delegation produces overspend beyond the bound (9). H3 fails if a monitored operation continues beyond the assumed cessation window under the specified clock and runtime conditions. H4 fails if independent verification does not improve acceptance reliability or introduces unacceptable rejection of valid work.

H5 is deliberately conditional. If cooperative agents do not gain owner utility or retained authorised access under effective admission and accounting, the proposed ecological advantage is unsupported. A harmful agent persisting under weak enforcement is a counterexample to the universal survival claim, not an anomaly to be explained away. All outcomes should be reported, including throughput lost to restraint.

H6 fails if the measured binding index does not rank fault-injection blast radius better than component count or the largest row sum. H7 fails if a retry budget does not reduce peak load on the failing dependency, or if it costs more completed work than it saves. H8's implementation fails if any spawning policy exceeds (11). H9 fails if the full harness does not reduce host cost or unauthorised effects relative to the harness without the admission test at matched useful throughput, or if a prompt-only regard performs as well.

# 13 Numerical checks

The companion source records {{n_checks}} named checks with a fixed seed. All pass. They test the propositions on random instances or by simulating the stated models; they are not measurements of any deployed system.

Table: **Table 9.** Checks of the propositions.

| Result | Check | Recorded outcome |
|:--|:--|:--|
| Proposition 1 | 300 random matrices, 39 steps each | 0 violations of (2) |
| Proposition 4 | 300 random matrices with Perron weighting | 0 violations of (3); weight attains $a=\rho(A)$ |
| Binding index (4) | 100 random matrices | Long-run response equals $\kappa(A)$ to {{kap_err}} |
| Example (5) | Shared broker | $\rho$ = {{hub.rho|f4}}, $\kappa$ = {{hub.kappa|f4}}, as in closed form |
| Proposition 5 | 300 random pairs $A'\le A$ | 0 violations |
| Extraction | Monolith against broker split | $\kappa$ rises from {{extraction.kappa_monolith|f2}} to {{extraction.kappa_split|f2}} |
| Proposition 6 | Recursive call-chain simulation, depth 1–5 | Exactly $4^d$; 64 at depth 3; budget at most $1.1^d$ |
| Proposition 2 | {{ledger.trials}} scripts, {{ledger.transitions|d}} transitions | 0 violations of (7) |
| Race | 1–16 concurrent check-then-spend agents | Overspend exactly $(k-1)c$ |
| Proposition 7 | {{attenuation.trees}} trees, {{attenuation.requests|d}} requests | 0 violations; {{attenuation.confused_deputy_violations|d}} under ambient authority |
| Propositions 3, 7 | 300 delegation trees with clock lag | 0 effects after (8) |
| Proposition 8 | 300 runs with overrun | 0 violations of (9); excess up to {{overrun.max_excess_over_k_omega|f2}} of $k\omega$ |
| Proposition 9 | 200,000 partitions per lease length | Agreement with (10) within {{lease.max_mc_error|f4}} |
| Proposition 10 | Eight generations of spawning | {{replication.family_ledger.8}} copies under a ledger; {{replication.per_agent_cap.8|d}} under per-agent caps |
| Proposition 11 | 4,000 lineages per value of $m$ | All die out for $m\le0.9$; persistence within {{branching.max_mc_error_supercritical|f3}} of (12) |
| Proposition 12 | 100,000 lifetimes per case | Threshold (14) decides every case; values within {{deterrence.max_relative_mc_error|pct1}} |
| Proposition 13 | 400,000 claims per verifier count | Agreement with (15); floor never crossed |
| C# kernel | {{cs.lines}} output lines | Largest relative difference from Python {{cs_max}} |

# 14 Implications and limits

The Gita-based interpretation redirects attention from the agent's apparent independence to the conditions under which its activity preserves other people's ability to choose. This is a useful perspective for architecture because a system may be easy to extend yet difficult to refuse, inexpensive to copy yet expensive to stop, and formally modular yet operationally coercive. Replaceability, consent and cessation deserve separate design reviews.

The interpretation also changes the role of ownership. A module owner remains responsible for contracts and consequences, while giving up unnecessary control over implementations and consumers. A task owner remains accountable for authorisation, while allowing the worker flexibility inside a bounded envelope. Non-attachment and accountability can reinforce one another when commitments are explicit. Verse 18.14 adds a further discipline: credit and fault are distributed over five factors, and a record that names only the doer is incomplete.

Version 2 also shows that several of the paper's qualities share one mathematical form. The binding index, the retry product and the replication number $m$ are each a multiplication factor that governance must hold below one. Anubandha, krodha and aloluptva meet here. A disturbance, a retry or a copy is harmless when each instance creates less than one more instance on average. The same arithmetic makes all three dangerous when it creates more.

## Necessary cautions

First, theological and engineering concepts are not interchangeable. The Gita's account of liberation cannot be validated by a software benchmark, and nothing here models daiva. Second, agents need not experience pride, anger or compassion for their actions to resemble the operational patterns described here. Likewise, a software operation can show the signature of rājasa or tāmasa action without any disposition. Third, these labels should not be used to classify people, teams, religions or cultures as morally superior or inferior.

Fourth, authorised conduct can still be harmful when the authorising institution is mistaken or unjust. Consent and resource budgets do not exhaust ethics, and passing the admission test of Section 6 is necessary, not sufficient. Fifth, a technically enforced quota can protect a host while the overall application causes social harm elsewhere. The proposed formal results deliberately cover narrower properties than comprehensive alignment.

Sixth, the models are simple. Proposition 11 assumes independent copies and constant rates, and Proposition 12 assumes risk neutrality, independent detection and enforceable removal. Their value is to show which quantities matter and in which direction, not to predict real replication dynamics. Finally, contractual decoupling has costs. Excessive abstraction can obscure important engineering assumptions. Distribution adds operational obligations. Verification can become a bottleneck, and a compromised verifier can produce false confidence. The architecture must justify both the boundaries it introduces and the dependencies it retains.

## Conclusion

The strongest engineering lesson from the daivī and āsurī distinction is disciplined action that can relinquish its claims. A useful agent should be able to replace an instrument, acknowledge an error, return resources, accept denial and cease when authority ends. Chapter 18 adds that it should act only after regarding consequences, loss, injury and its own capacity, and that its record should name every factor of the action, not only itself. These properties support governable autonomy; they do not constitute spiritual liberation or guarantee ecological success.

The practical programme is to minimise unnecessary dependency coupling while preserving deliberate ties to evidence, resource limits, accountable authority and revocation. Under explicit assumptions, those ties hold cascades, retries and copies below their multiplication thresholds, conserve delegation budgets, bound overspend and limit continued effects. Whether the complete system is useful and sustainable remains an empirical and institutional question. This qualified thesis retains the force of the philosophical insight while making its engineering consequences inspectable and open to correction.

# References

Web sources accessed 19 October 2026. Verse references identify the primary text; the linked pages supply a contemporary translation and commentary. Operational mappings and formal models are proposed in this paper.

[1] Bhagavad Gita 16.1–3. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/16/verse/1-3/

[2] Bhagavad Gita 16.4. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/16/verse/4/

[3] Bhagavad Gita 16.5. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/16/verse/5/

[4] Bhagavad Gita 2.47. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/2/verse/47/

[5] Bhagavad Gita 3.9. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/3/verse/9/

[6] Cockburn A. Hexagonal architecture. 2005. https://alistair.cockburn.us/hexagonal-architecture

[7] Fowler M. Bounded Context. 2014. https://martinfowler.com/bliki/BoundedContext.html

[8] Fowler M. What do you mean by "Event-Driven". 2017. https://martinfowler.com/articles/201701-event-driven.html

[9] Fowler M. Monolith First. 2015. https://martinfowler.com/bliki/MonolithFirst.html

[10] Fowler M. Microservice Trade-Offs. 2015. https://martinfowler.com/articles/microservice-trade-offs.html

[11] Zhou W and Freeman D. AI models may be capable of self-replicating without access to a datacenter. Anthropic Frontier Red Team. 12 October 2026. https://www.anthropic.com/research/self-replicating-ai

[12] Model Context Protocol. Security Best Practices. Version 2025-11-25. https://modelcontextprotocol.io/docs/2025-11-25/tutorials/security/security_best_practices

[13] Rose S, Borchert O, Mitchell S and Connelly S. Zero Trust Architecture. NIST Special Publication 800-207. 2020. https://doi.org/10.6028/NIST.SP.800-207

[14] Bhagavad Gita 18.14. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/18/verse/14/

[15] Bhagavad Gita 18.23. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/18/verse/23/

[16] Bhagavad Gita 18.24. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/18/verse/24/

[17] Bhagavad Gita 18.25. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/18/verse/25/

[18] Beyer B, Jones C, Petoff J and Murphy NR, eds. Site Reliability Engineering. O'Reilly, 2016. Chapter 22, Addressing Cascading Failures. https://sre.google/sre-book/addressing-cascading-failures/

[19] Berman A and Plemmons RJ. Nonnegative Matrices in the Mathematical Sciences. SIAM, 1994.

[20] Dennis JB and Van Horn EC. Programming semantics for multiprogrammed computations. Communications of the ACM 9(3):143–155, 1966.

[21] Hardy N. The Confused Deputy (or why capabilities might have been invented). ACM SIGOPS Operating Systems Review 22(4):36–38, 1988.

[22] Gray C and Cheriton D. Leases: an efficient fault-tolerant mechanism for distributed file cache consistency. Proceedings of the 12th ACM Symposium on Operating Systems Principles, 202–210, 1989.

[23] Athreya KB and Ney PE. Branching Processes. Springer, 1972.

# Appendix A. An immutable C# reference kernel

The kernel implements the family ledger (Proposition 2), attenuated capabilities (Proposition 7), the binding index (4), retry amplification (6), the copy bound (11), the extinction probability of (12), the deterrence values and threshold (13)–(14), partition availability (10), the cessation bound (8) and the verification floor (15). It uses immutable records, `ImmutableDictionary` and `ImmutableSortedSet`, and pure static functions; the linear solve and the fixed-point iteration work on private copies. Every ledger transition returns a new ledger, so a refused transition leaves no partial state.

A validation program prints {{cs.lines}} lines on fixed inputs, and an independent Python implementation recomputes each line. The two are independent: Python computes the binding index from an explicit inverse rather than elimination, and the extinction probability by bracketed root-finding rather than iteration.

```csharp
{{file:cs/Governance.cs}}
```

Table: **Table 10.** C# against Python, line by line (.NET {{cs.dotnet}}).

| Output | C# values | Largest relative difference |
|:--|:--|--:|
{{cs_rows}}
