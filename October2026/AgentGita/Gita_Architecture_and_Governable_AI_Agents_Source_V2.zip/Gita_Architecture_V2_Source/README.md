# The Bhagavad Gita and the Design of Governable AI Agents, Version 2

Source for the Word paper by Debi Prasad Ghosh, 19 October 2026.

Version 2 adds verses 18.14 and 18.23-25 (a five-factor task record and a
four-part admission test), the spectral cascade condition and binding index,
retry amplification, attenuation closure, bounded reservation overrun, the
lease-availability trade-off, a copy bound under a family ledger, a branching
threshold for escaped copies, an exact deterrence condition, and a
verification floor. Propositions 1-3 keep their Version 1 numbers.

## Rebuild

Python 3 with NumPy, SciPy, Matplotlib, python-docx and lxml; Pandoc; .NET 8
SDK for the C# kernel; LibreOffice only for a preview PDF.

    python gita_checks.py   # 29 checks and simulations -> results.json
    python cs_validate.py   # builds cs/, compares every output line with Python
    python figures.py       # four figures from results.json
    python render.py        # fills every number in paper_a/b/c.md -> paper.md
    python build.py         # Word file in output/

All 29 checks pass; the C# kernel agrees with Python to 1.2e-14 on 11 lines.
No deployed system was measured; simulations test the stated models only.
