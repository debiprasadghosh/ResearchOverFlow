"""Build the Word paper with native equations (Pandoc), in the typographic style of Version 1."""
from pathlib import Path
import re, subprocess, sys
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph

P = Path(__file__).resolve().parent
OUT = P / 'output'; OUT.mkdir(exist_ok=True)
FONT = 'Cambria'

# ---- reference document: Version 1 typography (Cambria, black headings, letter page)
doc = Document(P / 'reference_base.docx')
for child in list(doc._element.body):
    if child.tag != qn('w:sectPr'):
        doc._element.body.remove(child)
for sec in doc.sections:
    sec.page_width = Inches(8.5); sec.page_height = Inches(11)
    sec.left_margin = sec.right_margin = Inches(.85); sec.top_margin = sec.bottom_margin = Inches(.8)
    for part in (sec.header, sec.first_page_header, sec.even_page_header, sec.footer, sec.first_page_footer,
                 sec.even_page_footer):
        for p in part.paragraphs:
            p.clear()
    foot = sec.footer.paragraphs[0]; foot.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    fld = OxmlElement('w:fldSimple'); fld.set(qn('w:instr'), 'PAGE'); foot._p.append(fld)
for st in doc.styles:
    if st.type == 1:
        st.font.color.rgb = RGBColor(0, 0, 0)
        for node in list(st.element.iter()):
            if node.tag in (qn('w:pBdr'), qn('w:shd')):
                node.getparent().remove(node)
for name in ('Normal', 'Body Text', 'First Paragraph', 'Compact', 'Statement'):
    if name in [s.name for s in doc.styles]:
        st = doc.styles[name]; st.font.name = FONT; st.font.size = Pt(10.5)
        st.paragraph_format.line_spacing = 1.08; st.paragraph_format.space_after = Pt(7)
for name, size, bold, italic in (('Title', 25, False, False), ('Subtitle', 14, False, True),
                                 ('Heading 1', 16, True, False), ('Heading 2', 12, True, False),
                                 ('Author', 10.5, False, False), ('Date', 10.5, False, False),
                                 ('Abstract', 10.5, False, False)):
    if name in [s.name for s in doc.styles]:
        st = doc.styles[name]; st.font.name = FONT; st.font.size = Pt(size); st.font.bold = bold
        st.font.italic = italic; st.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
        st.paragraph_format.keep_with_next = True
doc.styles['Heading 1'].paragraph_format.space_before = Pt(16)
doc.styles['Heading 1'].paragraph_format.space_after = Pt(7)
doc.styles['Heading 2'].paragraph_format.space_before = Pt(11)
doc.styles['Date'].paragraph_format.space_after = Pt(14)
for name in ('Caption', 'Table Caption', 'Image Caption'):
    if name in [s.name for s in doc.styles]:
        st = doc.styles[name]; st.font.name = FONT; st.font.size = Pt(9); st.font.italic = False
        st.paragraph_format.space_after = Pt(9)
for name in ('Equation',):
    pf = doc.styles[name].paragraph_format
    pf.space_before = Pt(4); pf.space_after = Pt(8); pf.line_spacing = 1.0; pf.keep_together = True
    pr = doc.styles[name].element.get_or_add_pPr()
    for old in pr.findall(qn('w:tabs')):
        pr.remove(old)
    tabs = OxmlElement('w:tabs')
    for val, pos in (('center', 4968), ('right', 9936)):
        el = OxmlElement('w:tab'); el.set(qn('w:val'), val); el.set(qn('w:pos'), str(pos)); tabs.append(el)
    pr.append(tabs)
doc.save(P / 'reference.docx')

# ---- markdown preparation: numbered display equations become Equation paragraphs
s = (P / 'paper.md').read_text()


def display(m):
    math = m[1].strip(); num = re.search(r'\\tag\{(\d+)\}', math)
    if num is None:
        return m[0]
    math = math[:num.start()].strip()
    return '\n::: {custom-style="Equation"}\n$' + math.replace('\n', ' ') + '$ (' + num[1] + ')\n:::\n'


s = re.sub(r'\$\$(.*?)\$\$', display, s, flags=re.S)
s = re.sub(r'(?<!\$)\$([^$\n]+)\$([,.;:])(?!\w)', lambda m: '$' + m[1] + r'\text{' + m[2] + '}$', s)
(P / 'build.md').write_text(s)
subprocess.run(['pandoc', '-f', 'markdown+tex_math_dollars', 'build.md', '-o', 'raw.docx',
                '--reference-doc=reference.docx', '--resource-path=.', '--no-highlight'], cwd=P, check=True)

# ---- layout pass
doc = Document(P / 'raw.docx')
cp = doc.core_properties
cp.title = 'The Bhagavad Gita and the Design of Governable AI Agents'; cp.author = 'Debi Prasad Ghosh'
cp.subject = 'Divine qualities, architectural coupling and bounded autonomy. Version 2'
cp.keywords = 'Bhagavad Gita; karma bandhana; AI agents; bounded autonomy; resource governance; replication'
inrefs = False
for p in doc.paragraphs:
    t = p.text
    if p.style.name.startswith('Heading 1') and (t == 'References' or t.startswith('Appendix')):
        p.paragraph_format.page_break_before = True
    if t == 'References':
        inrefs = True
    elif t.startswith('Appendix'):
        inrefs = False
    elif inrefs and t.startswith('['):
        p.paragraph_format.space_after = Pt(5)
        for run in p.runs:
            run.font.size = Pt(9.5)
    if re.match(r'(Proposition|Corollary|Example) ', t):
        p.paragraph_format.keep_with_next = True
    if p.style.name == 'Equation' and not re.search(r'\(\d+\)\s*$', t):
        p.paragraph_format.keep_with_next = True
    if p._p.xpath('.//w:drawing'):
        p.paragraph_format.keep_with_next = True
    if p.style.name in ('Image Caption', 'Table Caption'):
        p.paragraph_format.keep_together = True
        if p.style.name == 'Table Caption':
            p.paragraph_format.keep_with_next = True
    if p.style.name == 'Source Code':
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.line_spacing = 1.0
        for run in p.runs:
            run.font.size = Pt(7.6); run.font.name = 'Liberation Mono'

WIDTHS = {3: [1.25, 2.35, 3.2], 4: [1.3, 2.0, 2.0, 1.5]}
special = {9: [1.3, 2.6, 2.9]}          # the checks table
for ti, table in enumerate(doc.tables):
    ncol = len(table.columns)
    widths = WIDTHS.get(ncol, [6.8 / ncol] * ncol)
    if ncol == 3 and ti in (1, 2):      # Tables 2 and 3: quality tables
        widths = [1.9, 2.45, 2.45]
    if ncol == 3 and ti == 7:           # Table 8: hypotheses
        widths = [2.0, 2.4, 2.4]
    if ncol == 3 and ti == 8:           # Table 9: checks
        widths = [1.25, 2.5, 3.05]
    if ncol == 3 and ti == 9:           # Table 10: C#
        widths = [1.55, 4.0, 1.25]
    if ncol == 4 and ti == 5:           # Table 6: three classes
        widths = [0.95, 1.9, 2.15, 1.8]
    table.autofit = False
    for col, w in zip(table.columns, widths):
        col.width = Inches(w)
    pr = table._tbl.tblPr
    for old in pr.findall(qn('w:tblBorders')):
        pr.remove(old)
    borders = OxmlElement('w:tblBorders')
    for side in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        el = OxmlElement('w:' + side); el.set(qn('w:val'), 'single'); el.set(qn('w:sz'), '4')
        el.set(qn('w:color'), 'BFBFBF'); borders.append(el)
    pr.append(borders)
    for ri, row in enumerate(table.rows):
        trpr = row._tr.get_or_add_trPr(); trpr.append(OxmlElement('w:cantSplit'))
        if ri == 0:
            trpr.append(OxmlElement('w:tblHeader'))
        for ci, (cell, w) in enumerate(zip(row.cells, widths)):
            cell.width = Inches(w); cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcpr = cell._tc.get_or_add_tcPr()
            shade = OxmlElement('w:shd'); shade.set(qn('w:val'), 'clear')
            shade.set(qn('w:fill'), 'E6E6E6' if ri == 0 else ('F7F7F7' if ri % 2 == 0 else 'FFFFFF'))
            tcpr.append(shade)
            mar = OxmlElement('w:tcMar')
            for side in ('top', 'start', 'bottom', 'end'):
                el = OxmlElement('w:' + side); el.set(qn('w:w'), '70'); el.set(qn('w:type'), 'dxa'); mar.append(el)
            tcpr.append(mar)
            for p in cell.paragraphs:
                p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(1)
                p.paragraph_format.line_spacing = 1.0
                for run in p.runs:
                    run.font.size = Pt(8.8); run.bold = ri == 0
                kn = p._p.get_or_add_pPr().find(qn('w:keepNext'))
                if kn is not None:
                    p._p.get_or_add_pPr().remove(kn)
    after = table._tbl.getnext()
    if after is not None and after.tag == qn('w:p'):
        Paragraph(after, doc._body).paragraph_format.space_before = Pt(7)

for shape, d in zip(doc.inline_shapes, [
        'Harness diagram: task record with five factors, admission with four checks, execution, verification, release.',
        'Worst-case disturbance in a shared-broker architecture converging to its binding index; retry attempts versus call depth.',
        'Copies created under per-agent caps and under a family ledger; persistence probability of escaped lineages against m.',
        'Deterrence boundary, lease availability during partitions, and false acceptance against number of verifiers.']):
    shape._inline.docPr.set('descr', d)
doc.save(P / 'layout.docx')
final = OUT / 'Gita_Architecture_and_Governable_AI_Agents_V2.docx'
subprocess.run([sys.executable, 'postprocess.py', 'layout.docx', str(final)], cwd=P, check=True)
print('built', final)
