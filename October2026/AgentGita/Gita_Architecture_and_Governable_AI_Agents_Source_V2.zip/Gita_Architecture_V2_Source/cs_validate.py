"""Run the C# kernel and recompute every printed line with independent Python code."""
from pathlib import Path
import json, math, subprocess
import numpy as np
from scipy.optimize import brentq

P = Path(__file__).resolve().parent
subprocess.run(['dotnet', 'build', '-c', 'Release'], cwd=P / 'cs', check=True, capture_output=True)
cs = subprocess.run(['dotnet', str(P / 'cs/bin/Release/net8.0/Governance.dll')], capture_output=True,
                    text=True, check=True).stdout.strip().splitlines()
(P / 'cs/cs_out.txt').write_text('\n'.join(cs) + '\n')

# ledger script, as a plain dictionary simulation
b = {'root': 100}; E = 0; ok = []
def spend(k, c):
    global E
    if b.get(k, 0) >= c:
        b[k] -= c; E += c; return 1
    return 0
def deleg(k, ch, c):
    if b.get(k, 0) >= c:
        b[k] -= c; b[ch] = b.get(ch, 0) + c; return 1
    return 0
ok += [spend('root', 30), deleg('root', 'a1', 50), spend('a1', 60), deleg('a1', 'a2', 20)]
r = min(15, b['a2']); b['a2'] -= r; b['root'] += r
ok.append(spend('a2', 5))
py = [('ledger_admitted', ok), ('ledger_final', [E, b['root'], b['a1'], b['a2'], E + sum(b.values())])]
root, child = ({1, 2, 3, 5, 8}, 100.0), ({2, 3, 5}, 60.0)
widen_refused = not ({2, 9} <= child[0] and 50 <= child[1])
adm = lambda cap, e, t: int(e in cap[0] and t < cap[1])
py.append(('capability', [int(widen_refused), adm(child, 3, 59.9), adm(child, 3, 60.0), adm(child, 1, 10)]))
hub = np.zeros((5, 5)); hub[0, 1:] = .3; hub[1:, 0] = .2
mono = np.array([[0, .3, .3], [.3, 0, .3], [.3, .3, 0]])
split = np.zeros((4, 4)); split[:3, :3] = [[0, .1, .1], [.1, 0, .1], [.1, .1, 0]]; split[:3, 3] = .3; split[3, :3] = .3
kap = lambda A: float(np.linalg.inv(np.eye(len(A)) - A).sum(1).max())     # max row sum of (I-A)^{-1}
py.append(('binding_index', [kap(hub), kap(mono), kap(split)]))
py.append(('retries', [4 ** d for d in range(1, 6)] + [1.1 ** d for d in range(1, 6)]))
py.append(('max_copies', [100 // 10 + 1, 1000 // 7 + 1]))


def ext(m, p=.25):
    lam = m * p
    if m <= 1:
        return 1.0
    return brentq(lambda s: p * math.exp(lam * (s - 1)) / (1 - (1 - p) * math.exp(lam * (s - 1))) - s,
                  0, 1 - 1e-12, xtol=1e-15)


py.append(('extinction', [ext(m) for m in (.9, 1.1, 1.3, 1.6, 2.0, 3.0)]))
py.append(('deterrence', [1 / .01, 1.5 / (1 - .98 * .99), .01 * .5 / .99, .01 * .2 / .99]))
mu, rr = 30.0, 1.0
py.append(('partition_availability', [1 - mu / rr * (math.exp(-(d - rr) / mu) - math.exp(-d / mu))
                                      for d in (2, 5, 10, 20, 40, 80, 160)]))
py.append(('cessation', [50 + 5 + .5 + 2]))
py.append(('false_acceptance', [.1 * (.05 + .95 * .2 ** k) for k in (1, 2, 3, 5, 8)]))

per = []; pyl = []
for line, (name, vals) in zip(cs, py):
    head, *nums = line.split(); assert head == name, (head, name)
    c = np.array([float(x) for x in nums]); v = np.array(vals, float)
    per.append(float(np.max(np.abs(c - v) / np.maximum(1, np.abs(v)))))
    pyl.append(name + ' ' + ' '.join(f'{x:.15g}' for x in v))
out = {'lines': len(cs), 'max_relative_difference': max(per), 'per_line': per, 'csharp': cs, 'python': pyl,
       'dotnet': subprocess.run(['dotnet', '--version'], capture_output=True, text=True).stdout.strip()}
(P / 'cs_validate.json').write_text(json.dumps(out, indent=1) + '\n')
for (n, _), e in zip(py, per):
    print(f'{n:24s} {e:.2e}')
assert len(cs) == len(py) and max(per) < 1e-12
print('C# agrees with Python on', len(cs), 'lines')
