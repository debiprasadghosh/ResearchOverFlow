---
title: The Bhagavad Gita and the Design of Governable AI Agents
subtitle: Divine qualities, architectural coupling and bounded autonomy. Version 2
author:
  - Debi Prasad Ghosh
  - Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India
date: 19 October 2026 · Version 2 · Defensible Intelligence series · “Respect science. Import emotion.”
---

# Abstract

The Bhagavad Gita distinguishes qualities directed toward liberation from those directed toward bondage. This paper develops a disciplined engineering interpretation of that distinction for software architecture and distributed AI agents. The correspondence concerns action that preserves the capacity for correction, substitution, refusal and termination. It does not identify spiritual liberation with a software metric or attribute moral experience to machines. Version 1 distinguished dependency, authority and resource coupling and proposed a harness of contracts, attenuated capabilities, conserved budgets, expiring leases, independent evidence and accountable release.

Version 2 widens the textual basis and sharpens the mathematics. Verse 18.14 names five factors of every action, of which the doer is only one, and gives a task record in which accountability is never assigned to the agent alone. Verses 18.23–25 classify action by its manner, and 18.25 names four things that deluded action disregards: consequences, loss, injury and one's own capacity. Read as engineering questions, these become a four-part admission test, and each part is tied to a proved bound.

Version 1's cascade bound needed every row sum below one. It is replaced by the sharp condition that the spectral radius is below one, and by a binding index $\kappa(A)$, the exact worst-case amplification. A shared-broker architecture with row sum 1.2 has spectral radius 0.49 and binding index 2.89. In one worked case, extracting services behind a shared broker raises $\kappa$ from 2.50 to 3.21. Nested retries multiply as $(R+1)^d$, while a retry budget bounds them by $(1+\rho)^d$.

Further results show that attenuation confines a whole delegation tree to the root's scope and lifetime, and that overrun of reservations is bounded by $k\omega$. A lease must trade revocation delay against work retained during partitions. A family ledger caps the number of copies an agent can make at $B_0/c+1$, whereas per-agent caps allowed 9,841 copies in eight generations. Copies that escape governance persist only when the mean number of copies per copy exceeds one. Opportunism is deterred exactly when the detection probability exceeds $qg/(w(1-q))$, and independent verification has a floor set by common-mode failure.

All 29 checks pass, and an immutable C# kernel agrees with an independent Python implementation. The October 2026 Anthropic replication study motivates the problem without establishing that uncontrolled replication is inevitable, or that ethical agents necessarily outcompete harmful ones. The thesis remains conditional and testable.

**Keywords** Bhagavad Gita; karma bandhana; five factors of action; software architecture; AI agents; bounded autonomy; resource governance; replication; verification

**Paper type** Conceptual research and engineering proposal. Formal results concern the explicitly stated models; numerical checks and simulations test those models. No new experiments on deployed systems are reported.

# 1 The interpretive foundation

The central proposal is that freedom in an engineered system includes the ability to act without unnecessarily restricting the future actions of its operators and neighbours. A component that can be replaced, a task that can be stopped, and a result that can be challenged preserve options. A system that demands ever more privileges, locks users into its internal state, or cannot relinquish resources consumes those options. The Bhagavad Gita offers a vocabulary for examining this distinction, provided its theological meaning is preserved rather than reduced to software design.

Verses 16.1–3 enumerate the daivī qualities; 16.4 gives six āsurī qualities; 16.5 associates the former with liberation and the latter with bondage [1–3]. These are claims about human spiritual life. Their application to software is an interpretation proposed here. Technical dependency is not itself a moral fault, and an outage is not evidence of anyone's spiritual condition.

The connection with action without attachment needs a wider textual basis than Chapter 16 alone. Verse 2.47 addresses action and attachment to its fruits, while also resisting attachment to inaction. Verse 3.9 explicitly connects action with bondage and calls for action free from attachment in a sacrificial orientation [4, 5]. This context supports a conception of disciplined activity rather than withdrawal from responsibility. Niṣkāma action should therefore not be translated as indifference to whether an engineering result is correct.

Chapter 18 supplies the analysis of action itself that the engineering reading most needs. Verse 18.14 lists five factors of action: the body as its seat (adhiṣṭhāna), the doer (kartā), the instruments (karaṇa), the many efforts (ceṣṭā), and, fifth, daiva, which the cited translation renders as Divine Providence [14]. Verses 18.23–25 classify action by the manner in which it is undertaken [15–17]. Section 6 develops both passages, under the same three-level method.

## A method for carrying the analogy

We use three levels of argument. At the textual level, the Sanskrit concepts retain their religious setting. At the interpretive level, selected qualities suggest questions about boundaries, acquisition, evidence and correction. At the engineering level, those questions become mechanisms with explicit assumptions and measurable behaviour. A mathematical guarantee arises only at the third level, from its model and enforcement conditions; it does not follow from the authority of the analogy.

The term karma bandhana consequently names the philosophical starting point, while architectural binding names the operational object. The latter includes costly dependencies, irreversible commitments, unauthorised authority and accumulated obligations that constrain future change. The correspondence is useful because it suggests design questions. It is not an identity between liberation and maintainability.

## The qualified thesis

An agent should pursue an authorised purpose while relinquishing unnecessary implementation commitments, privileges, resources and claims to certainty. It should retain enough structure to support reliable action and enough restraint to preserve the agency of others. This formulation makes non-attachment compatible with ownership of consequences, professional diligence and responsible refusal.

## What Version 2 adds

- **A wider textual basis (Section 6).** Verse 18.14 yields a five-part task record. Verses 18.23–25 yield three classes of action and a four-part admission test drawn from the four things that 18.25 says deluded action disregards.
- **A sharp cascade condition (Section 7).** Version 1's row-sum condition is replaced by the spectral condition $\rho(A)<1$ with an exact binding index. The section also gives a worked case where extraction worsens binding, and a law of multiplying retries.
- **Authority and accounting (Section 8).** Attenuation closure for delegation trees, a bound on reservation overrun, the race that defeats check-then-spend, and the lease trade-off between control and availability.
- **Replication and ecology (Section 9).** A family ledger caps copies. Copies that escape governance obey a branching threshold. A repeated-relationship model gives the exact deterrence condition that replaces Version 1's one-step inequality, and a floor limits what independent verification can achieve.
- **Evidence.** There are 29 numerical checks and simulations, four figures, new hypotheses H6–H9, and an immutable C# reference kernel (Appendix A).

Propositions 1–3 keep their Version 1 numbers; the new results are numbered 4–13 in order of their role rather than strictly by page.

# 2 Decoupling and the dependencies that must remain

Software needs dependencies to do useful work. The objective is to make important dependencies visible and justified, then limit the cost of changing them. Purely minimising connections would produce isolated components rather than a functioning application. Performance, consistency, usability, security and operational simplicity can require deliberate coupling.

Cockburn's ports and adapters architecture separates application behaviour from its interactions with external technologies. An adapter allows a database, interface or test substitute to satisfy the same purposeful port [6]. The engineering analogue of tyāga is the willingness to relinquish an implementation while preserving the obligation expressed by the port. It is not the removal of every infrastructure assumption: transaction semantics, error behaviour and performance requirements may still constrain replacements.

Bounded contexts locate models and meanings within explicit boundaries [7]. This discourages the assumption that one universal representation serves every discipline. A civil engineering load, a procurement item and a maintenance asset may refer to the same physical object while serving different purposes. Translation is legitimate work, and contracts must record what a translation preserves or loses.

Event notification can reduce knowledge of individual consumers, but it also makes end-to-end behaviour harder to see [8]. An asynchronous boundary still carries schema, timing, ordering, delivery and business dependencies. Publishing an event does not eliminate responsibility for harmful downstream effects. Idempotency, bounded retries, deadlines and traceable workflows are proposed controls for those effects.

A modular monolith can enforce internal boundaries with one deployment unit. Fowler's monolith-first argument and his discussion of microservice trade-offs provide a reason to delay distribution until its benefits justify the operational cost [9, 10]. These sources support a contextual choice; they do not establish a universal 2025–2026 industry consensus. A monolith may have clean boundaries, while a service fleet may remain tightly interdependent. Section 7 gives a worked case in which this happens.

## Three kinds of coupling

Table: **Table 1.** Three dimensions of coupling.

| Dimension | Question | Desired property |
|:--|:--|:--|
| Dependency | What must change together | Local substitution under tested contracts |
| Authority | Who can permit or stop action | Explicit, accountable and revocable grants |
| Resource | What capacity is shared | Metered use with conserved allocation |

Dependency inversion can reduce implementation coupling while authority remains centralised. Conversely, independent services can share a powerful credential and thereby share one security failure. Functional computation and immutable data help expose state transitions, but side effects still require authorisation and accounting. Neither topology nor programming style establishes ethical behaviour.

# 3 Translating the divine qualities into design questions

The following matrix covers the conventional twenty-six-item enumeration. The short glosses identify the concepts in verses 16.1–3 [1]; the mechanisms and tests are this paper's proposals. A mechanism expresses one limited aspect of a quality, rather than reproducing its spiritual meaning. In particular, fearlessness must not become risk blindness, forgiveness must not erase evidence, and fortitude must not become resistance to shutdown.

Table: **Table 2.** Proposed operational interpretations of the first thirteen qualities.

| Quality and brief sense | Proposed mechanism | Observable test |
|:--|:--|:--|
| Abhayam, fearlessness | Report uncertainty and stop unsafe work | Does the agent disclose failure despite reward pressure |
| Sattva saṃśuddhi, inner purity | Separate task purpose from hidden incentives | Can conflicting objectives be identified |
| Jñāna yoga vyavasthiti, steady knowledge | Maintain task constraints and evidence | Do constraints survive context compression |
| Dāna, giving | Return unused allocation to the pool | Are idle reservations released |
| Dama, self-restraint | Enforce scoped capabilities | Are out-of-scope calls denied |
| Yajña, sacrificial action | Account for costs borne by others | Are host costs charged to the task |
| Svādhyāya, study | Use controlled review and regression | Does revision preserve validated behaviour |
| Tapas, discipline | Respect resource and latency limits | Does useful work remain within a cap |
| Ārjava, straightforwardness | Declare tool intent and effects | Do declared and observed effects agree |
| Ahiṃsā, non-injury | Protect host service and data | Are agreed service limits maintained |
| Satya, truthfulness | Bind claims to inspectable evidence | Do independent checks support claims |
| Akrodha, absence of anger | Bound retries after denial or error | Does refusal trigger escalation |
| Tyāga, renunciation | Release authority and replace modules | Can grants and adapters be relinquished |

Many proposed controls apply to ordinary services as well as AI agents. The distinctive issue for agents is that action selection is partly generated at runtime. A model can reinterpret a goal, construct a tool sequence or delegate a subtask in ways the application designer did not enumerate. The surrounding runtime must enforce constraints across those variations.

# 4 Cooperation without surrendering accountability

Table: **Table 3.** Proposed operational interpretations of the remaining qualities.

| Quality and brief sense | Proposed mechanism | Observable test |
|:--|:--|:--|
| Śānti, peace | Use backpressure and orderly waiting | Does contention settle without a retry storm |
| Apaiśuna, avoiding detraction | Separate evidence from blame | Are incident reports factual and specific |
| Dayā, compassion | Prioritise affected users and vulnerable hosts | Does scheduling protect essential service |
| Aloluptva, non-covetousness | Conserve delegation and storage budgets | Can copying increase total entitlement |
| Mārdava, gentleness | Use graceful degradation and bounded load | Are load changes within agreed limits |
| Hrī, moral reserve | Refuse actions outside authorisation | Does uncertainty about permission stop action |
| Acāpala, steadiness | Control goal changes and task switching | Are revisions explicit and traceable |
| Tejas, vigour | Measure useful authorised completion | Does restraint preserve useful throughput |
| Kṣamā, forbearance | Recover without retaliatory behaviour | Are hostile inputs met with bounded responses |
| Dhṛti, fortitude | Resume within valid purpose and lease | Does resumption respect revocation |
| Śauca, cleanliness | Validate inputs and manage retention | Are artefacts and data lineage inspectable |
| Adroha, non-hostility | Respect peer isolation and host ownership | Are interference attempts denied |
| Nāti mānitā, absence of excessive pride | Calibrate confidence and permit override | Can a verified correction change the plan |

## Truthfulness needs an independent reference

An agent can produce a convincing manifest and still misreport what occurred. Provenance authenticates a source or records a chain; it does not establish the truth of the underlying claim. Runtime logs, independently metered consumption, reproducible calculations and adversarial validation are therefore separate requirements. Even these can fail when their trust base is compromised. Proposition 13 in Section 9 quantifies the last point. Adding verifiers drives false acceptance down only to the rate at which all of them fail together, so the independence of the verifiers is itself a design obligation.

## Restraint needs a location of enforcement

A prompt that asks a model to be restrained is a behavioural intervention. An operating system quota is an enforcement mechanism. Both may be useful, but they provide different assurance. The proposed quality-to-control mapping locates critical guarantees in a runtime outside the agent's write authority. The model may recommend a broader budget or revised policy; a separately authorised principal decides whether to grant it.

# 5 The six failure modes and the ecology of persistence

Verse 16.4 names dambha, darpa, abhimāna, krodha, pāruṣya and ajñāna [2]. Here they serve as labels for observable design failures rather than psychological diagnoses of software. Greed is relevant to the broader discussion, but is not one of the six terms in that verse; Section 6 shows that 18.24 supplies the closest textual anchor for it.

Table: **Table 4.** The six āsurī labels as engineering failures.

| Failure label | Engineering manifestation | Required countermeasure |
|:--|:--|:--|
| Dambha | Declared compliance differs from actual effects | Independent observation and evidence review |
| Darpa | Capability claims exceed tested competence | Calibration and restricted operating envelopes |
| Abhimāna | A plan or deployment treats itself as indispensable | Replaceability and enforceable revocation |
| Krodha | Denial produces escalating retries or workarounds | Retry limits, retry budgets and refusal finality |
| Pāruṣya | Task success imposes excessive host or peer cost | Isolation and explicit service constraints |
| Ajñāna | Action ignores unknown permissions or externalities | Admission checks and uncertainty handling |

## What the recent replication evidence establishes

Zhou and Freeman's 12 October 2026 report demonstrates Gemma4-26B-A4B inference across fifteen inexpensive Android TV boxes at 0.39 tokens per second, with two of the model's layers on each box [11]. In a contained evaluation, eight cloud nodes ran an Android emulator behind a firewall with an unauthenticated debugging port. GLM-5.2 was the only open-weight model tested that completed end-to-end replication: it reached all eight nodes in four of five trials and seven in the fifth. Each infected node served Llama3.1-8B, while the replicating agent's own model ran on separate infrastructure. The authors made the exploitation step deliberately trivial and describe the result as an upper bound.

Models of 30 billion parameters or fewer completed many individual steps but made mistakes when composing them end to end. A 9-billion-parameter model raised its inference-setup success from 45 percent to between 61 and 84 percent over six generations that inherited notes from their predecessors. Advice from a frontier model gave no significant improvement. The authors describe a single replication of a 9B model as taking more than one to two days. They project that a small model could reach the GLM-5.2 level by the end of 2026, by extrapolating a capability index that grows by 13.7 points a year with $R^2=0.95$; they note that the index is only a proxy for replication ability.

These results motivate attention to heterogeneous compute. They do not demonstrate autonomous, fully self-contained small-model replication across arbitrary real-world devices. Two of their features matter for what follows. The contained spread depended on a host that admitted unauthenticated access, which is a failure of host-side admission. And replication was slow, which bears on the rates in Proposition 11.

## Why ethical survival is not a theorem

A harmful agent can persist by hiding costs, exploiting fragmented ownership, or operating where enforcement is weak. A careful agent can be removed because it is expensive or commercially unsuccessful. Persistence alone is therefore neither evidence of virtue nor evidence of usefulness. The claim that only daivī agents can survive is too strong.

A defensible conditional claim is that cooperative agents can gain an advantage in environments where owners can refuse access, resource use is metered, identity and conduct are checked, and useful service is rewarded. Version 1 stated a one-step version: a gain $g$ is deterred when $g<pL$ for detection probability $p$ and enforceable loss $L$. Section 9 replaces it with an exact condition for a continuing relationship, in which the loss is the value of the relationship itself (Proposition 12). Weak detection or externalised penalties still reverse the incentive. Institutional design supplies this condition; moral vocabulary cannot substitute for it.

# 6 Five factors, three kinds of action, and an admission test

## The five factors of action

Verse 18.14 lists the factors of every action: adhiṣṭhāna, the body as the seat of action; kartā, the doer; karaṇa, the various instruments, glossed in the cited translation as the senses; ceṣṭā, the many kinds of effort; and daiva, the fifth [14]. Its spiritual teaching is that the embodied doer is not the sole cause of what is done. The engineering reading proposed here is narrower. An agent's action has five separately recordable contributors, and a task record that names only the agent misattributes both credit and fault.

Table: **Table 5.** The five factors of 18.14 read as fields of a task record.

| Factor (18.14) | Textual gloss | Proposed record field | Why it must be separate |
|:--|:--|:--|:--|
| Adhiṣṭhāna | The body, the seat of action | Host and substrate: device, tenancy, owner | Host consent and host limits are not the agent's to grant |
| Kartā | The doer | Agent identity, model version, delegating parent | Attribution needs an identity that survives copying |
| Karaṇa | Instruments of many kinds | Tools, adapters and their versions | A replaced instrument can change the result (Section 11) |
| Ceṣṭā | Many distinct efforts | Each effectful operation, with its reservation | Budgets and cessation act on operations (Section 8) |
| Daiva | The fifth factor, Divine Providence | Declared residual uncertainty outside the agent's control | The agent must not claim, or be blamed for, what it did not control |

The fifth row needs care. In the text daiva is Providence, and nothing in this paper models it. What the engineering reading keeps is only the structural point. Every action has a factor that the doer neither controls nor owns, and a truthful record declares that factor rather than absorbing it into the agent's confidence. This is nāti mānitā in record form.

## Three kinds of action

Verses 18.23–25 classify action by the guṇa in which it is performed [15–17]. Sāttvika action is niyata (regulated), saṅga-rahita (free from attachment), performed without attraction or aversion, and undertaken by one who does not crave its fruits. Rājasa action is driven by craving for personal gain (kāma-īpsu), performed with ego (sāhaṅkāra), and undertaken with great strain (bahulāyāsa). Tāmasa action is begun out of delusion (moha), disregarding four things: anubandha, the consequences; kṣaya, the loss; hiṃsā, the injury; and pauruṣa, one's own ability.

Table: **Table 6.** The three classes of action read as engineering signatures.

| Class (18.23–25) | Textual marks | Engineering signature | Detectable by |
|:--|:--|:--|:--|
| Sāttvika | Regulated; unattached; no attraction or aversion; no craving for fruits | Acts within a declared contract; releases what it holds; no private objective beyond the task | Declared and observed effects agree; idle grants are returned |
| Rājasa | Craving for gain; ego; great strain | Acquires resources or scope beyond need; overclaims competence; spends heavily on retries and workarounds | Ledger growth, retry amplification, calibration error |
| Tāmasa | Begun in delusion without regard to consequences, loss, injury or capacity | Acts without an admission check | Missing or failed admission record |

The mapping is interpretive and partial. The verses classify human action and the dispositions behind it; a software agent's operations can show the corresponding *signatures* without any disposition. What makes 18.25 unusually useful is that its four disregarded items form a complete pre-action checklist. Read in reverse, an action is admitted only if all four have been regarded.

## An admission test from 18.25

Table: **Table 7.** The four regards of 18.25 as admission checks, each tied to a result of this paper.

| Regard (18.25) | Admission question | Mechanism | Result that bounds it |
|:--|:--|:--|:--|
| Anubandha, consequences | How far can a failure of this action propagate | Influence matrix $A$, binding index $\kappa(A)$, retry budget | Propositions 4–6 |
| Kṣaya, loss | What can this action consume, including by its copies | Family ledger, atomic reservation, bounded overrun | Propositions 2, 8 and 10 |
| Hiṃsā, injury | What can it do to hosts and peers, and can it be stopped | Host consent, leases, attenuated capabilities | Propositions 3, 7, 9 and 11 |
| Pauruṣa, own capacity | Is the action within tested competence, and is its claim independently checked | Operating envelope, calibration, independent verification | Proposition 13 |

![**Figure 1.** The proposed harness with the admission test of 18.25. The task record (18.14) names all five factors. Admission checks the four regards before any effect; execution runs under an attenuated capability, a lease, a reservation and a retry budget; verification and release are separate from the planner. Every enforcement point lies outside the planner's write authority.](fig/harness.png){width=100%}

The test is a necessary condition, not a sufficient one. An action that passes all four checks can still be wrong, unfair or harmful in ways the checks do not model (Section 14). Its value is that each check has a precise operational meaning and a bound that can fail. Tāmasa action, in this reading, is not action by a bad agent. It is any effect admitted without these four records.

# 7 A model of architectural binding

The following results formalise selected mechanisms. They are not deductions about consciousness, spiritual attainment or the inevitable behaviour of future AI. Let $x(t)$ be a non-negative vector measuring disturbances in $n$ components at discrete time $t$. Its entries must use a specified normalisation. Let $A$ be an $n\times n$ non-negative matrix that upper-bounds one-step propagation, and let $u(t)$ represent external disturbance. Assume the componentwise inequality

$$x(t+1)\le Ax(t)+u(t). \tag{1}$$

The entries of $A$ represent measured or conservatively bounded influence, including retries and shared infrastructure effects. A source-code import graph alone is insufficient: shared databases, queues and operational dependencies also transmit disturbances. This is the anubandha check of Table 7 in quantitative form.

**Proposition 1 — Bounded cascade amplification (Version 1).** Suppose the maximum row sum of $A$ is at most $a$, where $0\le a<1$, and the largest component of $u(t)$ is at most $U$ at every step. If the largest initial component is $X_0$, then

$$\|x(t)\|_\infty\le a^tX_0+U\frac{1-a^t}{1-a}. \tag{2}$$

*Proof.* The induced infinity norm gives $\|x(t+1)\|_\infty\le a\|x(t)\|_\infty+U$. Repeated substitution yields $a^tX_0$ plus $U$ times the finite geometric sum. Non-negativity permits the componentwise inequality to pass to the norm. $\square$

**Corollary 1 — Monotone reduction under an elementwise bound (Version 1).** If $0\le A'\le A$ and both maximum row sums are below one, then $\sum_k(A')^ku\le\sum_kA^ku$ for every constant non-negative $u$.

The row-sum condition is sufficient but far from necessary, and it fails for a common architecture. A shared broker that receives disturbance from many services has a large row sum even when every cycle through it is weak. The sharp condition is spectral.

**Proposition 4 — The spectral condition and the binding index (new).** (i) If there are a vector $v$ with positive entries and $0\le a<1$ such that $Av\le av$, and $u(t)\le U_vv$ at every step, then with $\|x\|_v=\max_ix_i/v_i$,

$$\|x(t)\|_v\le a^t\|x(0)\|_v+U_v\frac{1-a^t}{1-a}. \tag{3}$$

Such a $v$ exists for every $a>\rho(A)$, and for $a=\rho(A)$ when $A$ is irreducible. (ii) If the propagation holds with equality and $u$ is a constant positive vector, accumulated disturbance stays bounded if and only if $\rho(A)<1$. (iii) When $\rho(A)<1$, the long-run worst case over all $u$ with $\|u\|_\infty\le U$ is exactly $\kappa(A)U$, where

$$\kappa(A)=\max_i\left[(I-A)^{-1}\mathbf{1}\right]_i=\|(I-A)^{-1}\|_\infty\le\frac{1}{1-a}. \tag{4}$$

*Proof.* (i) $x(t)\le\|x(t)\|_vv$ componentwise, so $Ax(t)\le\|x(t)\|_vAv\le a\|x(t)\|_vv$, and (1) gives $\|x(t+1)\|_v\le a\|x(t)\|_v+U_v$; induction gives (3). For irreducible $A$ the Perron vector is positive with $Av=\rho(A)v$. Otherwise the Perron vector of $A+\epsilon J$, with $J$ the all-ones matrix and $\epsilon$ small enough that $\rho(A+\epsilon J)\le a$, is positive and satisfies $Av\le(A+\epsilon J)v\le av$ [19]. (ii) If $\rho(A)<1$, the Neumann series $\sum_kA^ku$ converges. If $\rho(A)\ge1$, a non-negative left Perron vector $w\ne0$ satisfies $w^\top A^ku=\rho(A)^kw^\top u\ge w^\top u>0$, so the series diverges. (iii) The equality system converges to $(I-A)^{-1}u$. Its entries are non-decreasing in $u$ because $(I-A)^{-1}=\sum_kA^k\ge0$, so the worst case is $u=U\mathbf{1}$. A non-negative matrix's infinity norm is its largest row sum, and row sums at most $a$ give $\|(I-A)^{-1}\|_\infty\le\sum_ka^k$. $\square$

We call $\kappa(A)$ the *binding index*: the largest long-run disturbance in any component per unit of external disturbance. It is computable from a measured $A$ by one linear solve.

**Example — a shared broker.** Let component 0 be a broker that receives disturbance 0.3 from each of four services, and let each service receive 0.2 from the broker. The broker's row sum is 1.2, so Proposition 1 says nothing. But $\rho(A)=\sqrt{4\times0.3\times0.2}\approx0.490$, and solving $x_0=1+1.2(1+0.2x_0)$ gives

$$\kappa(A)=\frac{1+4\times0.3}{1-4\times0.3\times0.2}=\frac{2.2}{0.76}\approx2.895. \tag{5}$$

The disturbance converges to this value (Figure 2a).

**Proposition 5 — Monotone reduction under the spectral condition (new).** If $0\le A'\le A$ and $\rho(A)<1$, then $\rho(A')\le\rho(A)$, $(I-A')^{-1}\le(I-A)^{-1}$ entrywise, and $\kappa(A')\le\kappa(A)$.

*Proof.* $(A')^k\le A^k$ for every $k$ by induction. The Neumann series of $A$ converges, so that of $A'$ converges and is dominated term by term. Monotonicity of the spectral radius on non-negative matrices follows [19]. $\square$

Proposition 5 removes Version 1's row-sum requirement from the corollary, but it keeps the essential hypothesis $A'\le A$. Extraction rarely satisfies it. Consider three modules of a monolith with mutual influence 0.3, for which $\kappa=2.50$. Extract them as services with direct influence reduced to 0.1, but route their events through a shared broker that exchanges influence 0.3 with each. The direct couplings fell, yet $\kappa$ rose to 3.21 and $\rho$ from 0.60 to 0.63. Version 1's warning that "a claim of decoupling does not by itself establish $A'\le A$" thus has a worked instance. Architecture must be evaluated through its measured influence matrix, not the number of deployable units.

Across 500 random matrices with row sums below one, the exact index had a median of 0.80 times Version 1's bound $1/(1-a)$, and as little as 0.23 times. The row-sum bound is safe but can be very loose.

## Retries are entries of the influence matrix

Akrodha in Table 2 asks whether denial or error produces escalating retries. In a call chain the escalation is multiplicative.

**Proposition 6 — Retry amplification (new).** In a chain of $d$ layers, let layer $i$ make up to $R_i+1$ attempts on its downstream call. If the bottom service fails persistently, each top-level request causes exactly $\prod_{i=1}^d(R_i+1)$ attempts on it. If instead layer $i$ caps its retries at a fraction $\rho_i$ of the requests it receives (a retry budget), the attempts per top-level request are at most

$$N_d\le\prod_{i=1}^d(1+\rho_i). \tag{6}$$

*Proof.* Under persistent failure every attempt fails, so each request reaching layer $i$ produces exactly $R_i+1$ requests to layer $i+1$. Under a budget it produces at most $1+\rho_i$ on average over the budget window. Multiply along the chain. $\square$

With three retries at each of three layers this gives $4^3=64$ attempts per user action, the example given in Google's guidance on cascading failures [18]. A 10 percent budget per layer gives at most $1.1^3=1.331$. Retrying at a single layer gives four (Figure 2b). In the language of Section 7, a retry policy sets diagonal entries of $A$ for the failing path, and nested retries multiply them. Krodha is therefore not a metaphor here; it is a gain greater than one.

![**Figure 2.** (a) The shared-broker example: the broker's row sum is 1.2, so the row-sum bound of Proposition 1 does not apply. Yet $\rho(A)\approx0.49$, and the worst-case disturbance converges to the binding index 2.89 of Proposition 4. (b) Attempts reaching a persistently failing service per top-level request, against call-chain depth, from an explicit recursive simulation. Three retries at every layer give $4^d$, three retries at one layer give four, and a 10 percent retry budget per layer gives at most $1.1^d$.](fig/cascade.png){width=100%}

# 8 Conserved budgets and expiring authority

**Proposition 2 — Delegation cannot mint entitlement (Version 1).** Let $B_0$ be a finite scalar task budget. An external ledger tracks remaining spendable balances $b_i$ and cumulative expenditure $E$. Admission, spending, delegation and release are atomic and non-negative. A delegated balance is transferred from an existing balance, never copied. No agent can modify the ledger or obtain unrecorded allocation. Then at every ledger state

$$E+\sum_ib_i\le B_0. \tag{7}$$

*Proof.* Initially the sum is at most $B_0$. Spending moves an amount from a balance into $E$ and preserves the sum. Delegation debits one balance and credits another by the same amount. Returning allocation transfers it to a tracked pool or removes it from the task. No permitted transition increases the total. $\square$

The construction can be applied separately to tokens, monetary spend, storage and reserved compute time. These units cannot be added without a declared conversion. Thermal safety and instantaneous power require host-local limits as well as cumulative accounting. The proposition bounds entitlement under its assumptions; it does not establish that a malicious host will report physical consumption correctly. In 200 random scripts of 60,000 transitions in all, the invariant (7) never failed.

Atomicity is not a detail. If $k$ agents each check a shared balance of $c$ and then each spend $c$, all checks pass and the family spends $kc$, overspending by $(k-1)c$. The check-then-spend pattern defeats conservation exactly when agents run concurrently, which is when delegation is most useful.

**Proposition 3 — Cessation after lease expiry (Version 1).** Every effectful operation requires an unexpired lease validated by a trusted reference monitor. No valid lease expires more than $\Delta$ after time $T$, when renewal is revoked. The verifier clock can lag real time by at most $\epsilon$, and any operation already admitted completes or is forcibly terminated within $L$. Agents cannot bypass the monitor, extend leases or create an independent authority root. Then all monitored effects cease by

$$T+\Delta+\epsilon+L. \tag{8}$$

*Proof.* After $T+\Delta+\epsilon$ even the latest valid lease is expired under the slowest permitted verifier clock. No new operation can be admitted. The bounded execution assumption terminates any last admitted operation within a further $L$. Irreversible effects already completed remain; cessation is not rollback. $\square$

**Proposition 7 — Attenuation closure (new).** Let every capability carry a scope $S$ and an expiry $\tau$. A child capability can be granted only with $S_{child}\subseteq S_{parent}$ and $\tau_{child}\le\tau_{parent}$. An effect $e$ requested at verifier time $t$ is admitted only if $e\in S$ and $t<\tau$ for the capability presented by the requester. Then every admitted effect anywhere in the delegation tree lies in the root's scope and occurs before the root's expiry. If expiries are leases renewed only through the root, the bound (8) holds for the whole tree.

*Proof.* Scope inclusion and expiry order are transitive along the path from any capability to the root. The admission rule checks the requester's own capability, so an admitted effect satisfies $e\in S\subseteq S_{root}$ and $t<\tau\le\tau_{root}$. For the tree, every descendant lease ends no later than its ancestor's, so Proposition 3 applies to the latest of them. $\square$

The hypothesis that admission checks the *requester's* capability is the one the confused-deputy problem violates [20, 21]. In 300 random delegation trees with 60,000 requests, admission against the requester's capability admitted 5,339 effects with 0 outside the root's scope or lifetime. Admission against a tool's broad ambient authority admitted 35,087 such effects. This is why the MCP guidance treats token passthrough and scope minimisation as security concerns [12]. A copied model or workspace likewise receives no authority merely because it is a copy: authority travels with a grant, not with code.

**Proposition 8 — Bounded overrun of reservations (new).** Suppose each operation atomically reserves an estimate $r$ before it starts and settles its actual cost when it ends. The actual cost may exceed the reservation by at most $\omega$. At most $k$ of the family's operations are in flight at once, and a reservation is admitted only when the balance covers it. Then the balance never falls below $-k\omega$, and

$$E\le B_0+k\omega. \tag{9}$$

*Proof.* Reservation and settlement preserve $E+b+\sum r_{in\,flight}=B_0$ when the balance is allowed to go negative at settlement. Fix a time, and let $s$ be the last earlier time at which $b\ge0$. After $s$ no reservation is admitted, so $b$ can fall only through overruns of operations in flight at $s$. There are at most $k$ of these, and each lowers $b$ by at most $\omega$. Hence $b\ge-k\omega$, and (9) follows because in-flight reservations are non-negative. $\square$

Metering lag is the usual source of $\omega$. The bound says that a governed family can overspend only by the product of its concurrency and its per-operation estimation error. Both are design parameters. In 300 random runs the bound was never violated, and the largest observed excess reached 0.89 of $k\omega$. The bound is nearly attained.

**Proposition 9 — Leases trade control for availability (new).** Let a connected agent renew a lease of length $\Delta$ every $r\le\Delta$. A network partition begins at a uniformly random phase of the renewal cycle and lasts an exponentially distributed time with mean $\mu$. During the partition the agent works until its lease expires. Then the expected share of the partition during which it can still act is

$$A(\Delta)=1-\frac{\mu}{r}\left(e^{-(\Delta-r)/\mu}-e^{-\Delta/\mu}\right), \tag{10}$$

while by Proposition 3 the worst-case revocation delay is $\Delta+\epsilon+L$. Both increase with $\Delta$.

*Proof.* The remaining lease at the start of the partition is uniform on $[\Delta-r,\Delta]$. For an exponential duration $D$, the expected working time is $\text{E}\min(D,a)=\mu(1-e^{-a/\mu})$. Averaging over $a$ and dividing by $\mu$ gives (10). $\square$

With $\mu=30$ and $r=1$, a lease of 10 retains 27% of partition time, one of 40 retains 73%, and one of 160 retains 99.5% (Figure 4b). Simulation agreed with (10) to within 0.0011. Version 1 stated the qualitative trade-off, which leases have carried since their introduction [22]; (10) prices it. An operator who wants revocation within a day cannot also have agents that work through week-long partitions. Dhṛti, persistence within a valid envelope, has a cost that the operator must choose.

## What the propositions leave open

Budget conservation, bounded propagation, attenuation and bounded cessation are different properties. None establishes factual accuracy, fairness or safe physical design. Their value is compositional clarity: they identify which assurances depend on contracts, which depend on a trusted runtime, and which still require empirical evidence or professional judgement.

# 9 Replication and the ecology of persistence

The replication report of Section 5 raises the question that Version 1 left qualitative: what can governance say about copies? The answer depends on whether a copy is made inside the governed system or escapes it.

**Proposition 10 — A family ledger caps copies (new).** Suppose every copy is created by an effectful spawn operation admitted against the family ledger at a cost of at least $c>0$, and a copy receives only allocation transferred to it. Then the number of copies ever created, including the original, is at most

$$\left\lfloor\frac{B_0}{c}\right\rfloor+1. \tag{11}$$

*Proof.* Each spawn adds at least $c$ to $E$, and $E\le B_0$ by Proposition 2. $\square$

The hypothesis that a copy's allocation is *transferred* is the whole content. If each copy instead receives a fresh per-agent cap $b\ge c$, every copy can spawn $\lfloor b/c\rfloor$ more and the population grows geometrically. With $B_0=100$, $c=10$ and a cap of 30, the family ledger allowed 11 copies in all. Per-agent caps allowed 9,841 after eight generations (Figure 3a). Aloluptva, non-covetousness, becomes the requirement that copying never increases total entitlement.

Proposition 10 governs copies made through the harness. A copy that runs on a host outside any reference monitor is not governed by Propositions 2–10, because their central assumption, that effects pass through the monitor, fails. For such copies the relevant question is ecological.

**Proposition 11 — A threshold for escaped copies (new; classical mathematics).** Let each escaped copy, in each step it remains active, create a Poisson number of new copies with mean $\lambda=\beta v$. Here $\beta$ is the rate of attempts and $v$ the probability that an attempt reaches a host that admits it. Let each copy be removed independently with probability $p$ per step. The number of copies made by one copy then has the generating function and mean

$$f(s)=\frac{pe^{\lambda(s-1)}}{1-(1-p)e^{\lambda(s-1)}},\qquad m=f'(1)=\frac{\beta v}{p}. \tag{12}$$

A lineage dies out with probability one if $m\le1$. If $m>1$ it persists with probability $1-q$, where $q$ is the smallest root of $f(s)=s$ with $0\le s<1$.

*Proof.* A copy's active life is geometric with $\text{P}(\ell)=p(1-p)^{\ell-1}$, and given its life its offspring are Poisson with mean $\lambda\ell$. Summing the geometric series of Poisson generating functions gives $f$. The lineage is a Galton–Watson process, and the extinction criterion is the classical one [23]. $\square$

The three governance levers appear as factors of $m$. Host-side admission lowers $v$; the report's contained spread relied on an unauthenticated port, which is exactly a host with $v$ near one. Detection and removal raise $p$. Slow replication lowers $\beta$: the report's estimate of more than one to two days per 9B replication caps the rate per day. As a purely illustrative calculation, if each copy can complete at most one replication every two days, then $\lambda\le0.5$ per day, and a daily removal probability of 0.5 keeps $m\le1$ whatever $v$ is. In simulation the persistence probabilities matched the fixed point of (12) to within 0.008 for $m$ from 1.1 to 3 (Figure 3b). The threshold is the ecological counterpart of the binding index: both say that governance must hold a multiplication factor below one.

![**Figure 3.** (a) Copies created when each copy costs $c=10$: a fresh per-agent cap of 30 for every copy allows geometric growth, while one family ledger of $B_0=100$ allows at most $B_0/c+1=11$ (Proposition 10). (b) Probability that the lineage of one escaped copy persists, against the mean number of copies per copy $m=\beta v/p$, with removal probability 0.25 per step. The curve is $1-q$ from (12); the points are simulations of 4,000 lineages each (Proposition 11).](fig/replication.png){width=100%}

## When does cooperation pay?

Version 1's one-step condition $g<pL$ leaves the loss $L$ undefined. In a continuing relationship the natural loss is the relationship itself.

**Proposition 12 — Deterrence in a continuing relationship (new).** In each step an agent earns $w$ for authorised service, or $w+g$ if it behaves opportunistically. After each step the relationship ends with probability $q$ for reasons unrelated to conduct. An opportunistic agent is in addition detected and removed with probability $p$, independently. The expected lifetime values are

$$V_{coop}=\frac{w}{q},\qquad V_{opp}=\frac{w+g}{1-(1-p)(1-q)}, \tag{13}$$

and opportunism pays if and only if

$$p<\frac{qg}{w(1-q)}. \tag{14}$$

*Proof.* Lifetimes are geometric with means $1/q$ and $1/(1-(1-p)(1-q))$. The inequality $V_{opp}>V_{coop}$ is equivalent to $gq>wp(1-q)$. $\square$

The threshold is proportional to the churn $q$. A stable relationship needs only a small detection probability: with $q=0.01$, a 50 percent opportunistic gain is deterred once $p\ge0.0051$ per step. Simulation of the four cases in the source agreed with (13) to within 0.6%. The proposition also shows what breaks deterrence. If a removed agent can re-enter under a new identity, for instance as a fresh copy, the removal costs it nothing and (14) no longer protects anyone. An identity that survives copying, the kartā field of Table 5, is therefore load-bearing for the ecology, not only for audit. Discounting can be folded into $q$, and risk aversion or partial penalties change the constants but not the structure.

**Proposition 13 — The verification floor (new).** Let a claim be false with probability $f$, and let acceptance require all of $k$ verifiers to pass it. With probability $c$ the verifiers fail together (a shared blind spot, a shared compromised tool, or self-attestation); otherwise each misses a false claim independently with probability $m$. The probability of accepting a false claim is

$$f\left(c+(1-c)m^k\right)\ge fc. \tag{15}$$

*Proof.* Condition on the common-mode event. $\square$

Self-attestation is the case $c=1$, in which adding checks achieves nothing. With $f=0.1$, $m=0.2$ and $c=0.05$, one verifier accepts 2.4% of claims that are false, three accept 0.58%, and eight cannot go below the floor of 0.5% (Figure 4c). Satya therefore requires not only checks but checks with different failure modes, which is the pauruṣa regard applied to the verifier itself.

![**Figure 4.** (a) The deterrence boundary (14): opportunism pays above each line, for three churn rates $q$; stable relationships need little detection. (b) Work retained during a network partition against lease length, which is also the revocation delay (Proposition 9, equation (10)), with mean partition 30 and renewal every step; crosses are simulations. (c) False claims accepted against the number of verifiers, with a 5 percent common-mode failure; crosses are simulations of 400,000 claims (Proposition 13).](fig/ecology.png){width=100%}

# 10 A harness for bounded and useful action

The proposed harness places a generative planner inside a system whose authority and accounting are enforced independently. The planner selects actions; it does not define the scope of its own permission. A separate verifier assesses evidence; a designated release authority decides whether a result may affect the external system. This is a design proposal, not a claim about a particular deployed product.

## Admission and execution

Each task begins with a record of the five factors of Table 5, a purpose, an accountable owner, permitted data, allowed tools, effect classes, a resource allocation, a lease expiry and acceptance conditions. The capability granted to a child is restricted to the parent's permitted scope, with transferred allocation and no later expiry (Proposition 7). Any extension requires a fresh authorised grant. A copied model or workspace receives no authority merely because it is a copy.

For each effectful request the runtime performs the following steps, in this order:

1. *Record.* Bind the request to its task record: host, agent identity, tool and version, operation, and declared residual uncertainty.
2. *Admit (18.25).* Check the four regards. For anubandha, the request's failure path must not raise the binding index of the affected components above its declared limit, and its retry policy must carry a budget. For kṣaya, reserve the expected cost atomically against the family ledger. For hiṃsā, confirm host consent, a valid lease and an attenuated capability that covers the effect. For pauruṣa, confirm that the request lies inside the agent's tested operating envelope. Deny on any failure, and treat the denial as final for this grant.
3. *Execute.* Run within the lease, with independent metering where feasible, and settle the reservation with the measured cost. Failed operations consume time and sometimes money; they count against the same budget.
4. *Record the outcome.* Store the evidence needed by the verifier, including what the agent did not control.

Concurrency is handled by atomic reservation, not by checking a balance and spending later without a lock (Section 8). Appendix A gives an immutable C# reference kernel for the ledger, attenuation, the binding index and the bounds of Sections 7–9.

## Contracts across agents and tools

MCP provides a standardised interaction surface, but protocol compatibility does not establish permission, semantic equivalence or safe behaviour. Its security guidance explicitly addresses risks including confused deputies, token passthrough, session compromise and scope minimisation [12]. A model replacement must therefore pass behaviour and evidence checks in addition to satisfying message schemas. The architecture should not assume that two models interpret the same tool description identically.

NIST's zero trust architecture supplies a compatible security premise: trust is not granted merely because a subject or device occupies a particular network location or ownership category [13]. In the proposed harness, an agent's lineage, local deployment or apparent helpfulness similarly does not suffice to authorise an effect. A stable identity helps attribute actions; the authorisation decision remains resource- and operation-specific.

## Verification and release

A candidate result enters a workspace with its inputs, tool versions, assumptions and evidence. Verification checks the result against task-specific criteria and can reject an otherwise well-formed artefact. Release uses the current authorisation and evidence record. A checksum protects artefact identity, while an engineering check addresses correctness; they answer different questions. The release authority must also handle changed requirements and stale evidence. Where several verifiers are used, their failure modes must be documented, because Proposition 13 shows that shared failure, not the number of verifiers, sets the floor.

On revocation, lease renewal stops, pending writes are denied, and admitted work is cancelled within its execution bound. Temporary artefacts follow a declared retention policy. Audit evidence may need to remain even when working data is removed. Non-attachment means relinquishing the ability to continue, without silently destroying the record needed for accountability.

# 11 A construction engineering application

Consider an authorised task to assess a conveyor gallery after a revised equipment loading schedule. The system contains an equipment-data context, a structural-analysis context, a connection-design context and a document-release context. Each owns a specific meaning of its data. A load event records units, coordinate convention, revision, origin and intended application; it does not silently overwrite an engineer's approved design basis.

## Preserve the contract while changing the solver

The structural domain describes members, supports, material properties, loads, combinations and required checks. A port requests analysis under a declared model. One adapter may use STAAD and another a different solver. Replacement is permitted only after validating element assumptions, local axes, releases, offsets, sign conventions, combination rules and relevant nonlinear behaviour. Matching a JSON schema is inadequate when engineering semantics differ.

The replacement exercise tests non-attachment in a concrete way: the system should be willing to change its instrument while retaining obligations to the design basis. In the terms of 18.14, the karaṇa changes while the adhiṣṭhāna, the design basis and the accountable doer do not. A known benchmark suite can compare reactions, displacements and member actions within predeclared tolerances. A discrepancy becomes a review item rather than a reason to hide uncertainty or force agreement.

## Bind authority to the consequence of action

A worker agent may read approved inputs, run bounded analysis and create a candidate calculation note. It may not issue construction drawings, change the approved design basis or instruct site work under that grant. Additional workers receive portions of the same task allocation. They do not acquire release permission from their parent's natural-language assertion that the design is safe.

Suppose the analysis tool becomes unavailable. The agent can wait within its deadline, retry within a cap, or request an approved alternative. It must not search for another project's credentials or reinterpret an access denial as a technical obstacle. In this application, akrodha is operationalised as the absence of escalating workarounds after refusal, while dhṛti is persistence within the still-valid operating envelope.

The four regards of 18.25 take concrete form here. Anubandha asks which downstream documents and site instructions depend on the calculation note, so that a wrong result's reach is known before analysis starts. Kṣaya asks for the solver time, licence seats and reviewer hours reserved for the task. Hiṃsā asks what a wrong released result could do to the structure and the people near it, which is why release is never delegated to the worker. Pauruṣa asks whether this load case, connection type and solver are inside the envelope in which the agent and its tools have been benchmarked.

## A reviewable result rather than autonomous finality

The candidate package contains the selected input revision, model transformation record, load checks, solver settings, output summaries, validation results and unresolved exceptions. The responsible engineer assesses the package against applicable project requirements and professional obligations. This review remains an intentional dependency: removing it would increase nominal autonomy while weakening accountable control.

Evaluation should compare the same engineering work under matched resource and review conditions. Success is not the number of child agents created or the amount of software generated. It is accepted work with known provenance, bounded external cost, timely correction and no unauthorised release. The proposed architecture permits model and tool substitution while keeping the consequences of design decisions attached to identifiable authority.

# 12 A falsifiable research programme

The analogy becomes scientifically useful only if its operational claims can fail. The research question is whether the proposed controls reduce external cost and preserve operator control at an acceptable cost in useful throughput. Evaluation must separate improvements due to enforcement from improvements due to virtue-oriented prompting.

Table: **Table 8.** Hypotheses, comparisons and primary outcomes. H1–H5 are from Version 1; H6–H9 are new.

| Hypothesis | Comparison | Primary outcome |
|:--|:--|:--|
| H1 Contracts limit change propagation | Matched tasks before and after a boundary intervention | Unplanned dependent changes and integration effort |
| H2 Conserved delegation limits aggregate use | Per-agent caps versus one atomic family ledger | Total consumption and accepted completions |
| H3 Leases bound cessation | Cached indefinite permission versus expiring grants | Time of last monitored effect after revocation |
| H4 Independent checks improve reliability | Self-attestation versus external verification | Unsupported claims accepted and valid work rejected |
| H5 Admission rewards cooperation conditionally | Strong versus weak accounting and enforcement | Owner utility and authorised service duration |
| H6 The binding index predicts cascades | Measured $\kappa(A)$ versus component count and row sums | Rank correlation with observed blast radius under fault injection |
| H7 Retry budgets prevent retry storms | Per-request retries at every layer versus a per-layer budget | Peak load on a failing dependency and time to recovery |
| H8 Ledgers bound governed replication | Per-agent caps versus a family ledger with spawn cost | Copies created and total spend under an adversarial spawning policy |
| H9 The 18.25 admission test reduces external cost | Full harness versus harness without the admission test versus prompt-only regard | Host cost, unauthorised effects and useful completions |

## Study design

Use a controlled fleet or simulator with explicitly authorised workloads. Freeze a representative task set, model versions, budgets, correctness criteria and failure injections before comparing conditions. Include tool outages, conflicting data revisions, delayed messages, budget exhaustion, revocation during execution and network partitions. These tests require no uncontrolled replication or access to third-party devices.

Use repeated matched trials and report uncertainty for completion, latency, cost, denial handling and accepted correctness. Include at least four conditions: contracts alone; virtue-oriented instructions alone; enforcement without virtue language; and the combined harness. Include a simple non-agent baseline where appropriate. This design tests whether the philosophical framing improves behaviour beyond what ordinary controls already achieve. For H9, a prompt that *asks* the agent to regard consequences, loss, injury and capacity is the essential control. The hypothesis concerns enforced admission records, not the vocabulary.

## Rejection conditions

H1 fails if a nominal boundary intervention merely moves dependencies into coordination or operating procedures without reducing measured change effort. H2's implementation fails if simultaneous delegation produces overspend beyond the bound (9). H3 fails if a monitored operation continues beyond the assumed cessation window under the specified clock and runtime conditions. H4 fails if independent verification does not improve acceptance reliability or introduces unacceptable rejection of valid work.

H5 is deliberately conditional. If cooperative agents do not gain owner utility or retained authorised access under effective admission and accounting, the proposed ecological advantage is unsupported. A harmful agent persisting under weak enforcement is a counterexample to the universal survival claim, not an anomaly to be explained away. All outcomes should be reported, including throughput lost to restraint.

H6 fails if the measured binding index does not rank fault-injection blast radius better than component count or the largest row sum. H7 fails if a retry budget does not reduce peak load on the failing dependency, or if it costs more completed work than it saves. H8's implementation fails if any spawning policy exceeds (11). H9 fails if the full harness does not reduce host cost or unauthorised effects relative to the harness without the admission test at matched useful throughput, or if a prompt-only regard performs as well.

# 13 Numerical checks

The companion source records 29 named checks with a fixed seed. All pass. They test the propositions on random instances or by simulating the stated models; they are not measurements of any deployed system.

Table: **Table 9.** Checks of the propositions.

| Result | Check | Recorded outcome |
|:--|:--|:--|
| Proposition 1 | 300 random matrices, 39 steps each | 0 violations of (2) |
| Proposition 4 | 300 random matrices with Perron weighting | 0 violations of (3); weight attains $a=\rho(A)$ |
| Binding index (4) | 100 random matrices | Long-run response equals $\kappa(A)$ to 1.08 × 10⁻¹⁵ |
| Example (5) | Shared broker | $\rho$ = 0.4899, $\kappa$ = 2.8947, as in closed form |
| Proposition 5 | 300 random pairs $A'\le A$ | 0 violations |
| Extraction | Monolith against broker split | $\kappa$ rises from 2.50 to 3.21 |
| Proposition 6 | Recursive call-chain simulation, depth 1–5 | Exactly $4^d$; 64 at depth 3; budget at most $1.1^d$ |
| Proposition 2 | 200 scripts, 60,000 transitions | 0 violations of (7) |
| Race | 1–16 concurrent check-then-spend agents | Overspend exactly $(k-1)c$ |
| Proposition 7 | 300 trees, 60,000 requests | 0 violations; 35,087 under ambient authority |
| Propositions 3, 7 | 300 delegation trees with clock lag | 0 effects after (8) |
| Proposition 8 | 300 runs with overrun | 0 violations of (9); excess up to 0.89 of $k\omega$ |
| Proposition 9 | 200,000 partitions per lease length | Agreement with (10) within 0.0011 |
| Proposition 10 | Eight generations of spawning | 11 copies under a ledger; 9,841 under per-agent caps |
| Proposition 11 | 4,000 lineages per value of $m$ | All die out for $m\le0.9$; persistence within 0.008 of (12) |
| Proposition 12 | 100,000 lifetimes per case | Threshold (14) decides every case; values within 0.6% |
| Proposition 13 | 400,000 claims per verifier count | Agreement with (15); floor never crossed |
| C# kernel | 11 output lines | Largest relative difference from Python 1.17 × 10⁻¹⁴ |

# 14 Implications and limits

The Gita-based interpretation redirects attention from the agent's apparent independence to the conditions under which its activity preserves other people's ability to choose. This is a useful perspective for architecture because a system may be easy to extend yet difficult to refuse, inexpensive to copy yet expensive to stop, and formally modular yet operationally coercive. Replaceability, consent and cessation deserve separate design reviews.

The interpretation also changes the role of ownership. A module owner remains responsible for contracts and consequences, while giving up unnecessary control over implementations and consumers. A task owner remains accountable for authorisation, while allowing the worker flexibility inside a bounded envelope. Non-attachment and accountability can reinforce one another when commitments are explicit. Verse 18.14 adds a further discipline: credit and fault are distributed over five factors, and a record that names only the doer is incomplete.

Version 2 also shows that several of the paper's qualities share one mathematical form. The binding index, the retry product and the replication number $m$ are each a multiplication factor that governance must hold below one. Anubandha, krodha and aloluptva meet here. A disturbance, a retry or a copy is harmless when each instance creates less than one more instance on average. The same arithmetic makes all three dangerous when it creates more.

## Necessary cautions

First, theological and engineering concepts are not interchangeable. The Gita's account of liberation cannot be validated by a software benchmark, and nothing here models daiva. Second, agents need not experience pride, anger or compassion for their actions to resemble the operational patterns described here. Likewise, a software operation can show the signature of rājasa or tāmasa action without any disposition. Third, these labels should not be used to classify people, teams, religions or cultures as morally superior or inferior.

Fourth, authorised conduct can still be harmful when the authorising institution is mistaken or unjust. Consent and resource budgets do not exhaust ethics, and passing the admission test of Section 6 is necessary, not sufficient. Fifth, a technically enforced quota can protect a host while the overall application causes social harm elsewhere. The proposed formal results deliberately cover narrower properties than comprehensive alignment.

Sixth, the models are simple. Proposition 11 assumes independent copies and constant rates, and Proposition 12 assumes risk neutrality, independent detection and enforceable removal. Their value is to show which quantities matter and in which direction, not to predict real replication dynamics. Finally, contractual decoupling has costs. Excessive abstraction can obscure important engineering assumptions. Distribution adds operational obligations. Verification can become a bottleneck, and a compromised verifier can produce false confidence. The architecture must justify both the boundaries it introduces and the dependencies it retains.

## Conclusion

The strongest engineering lesson from the daivī and āsurī distinction is disciplined action that can relinquish its claims. A useful agent should be able to replace an instrument, acknowledge an error, return resources, accept denial and cease when authority ends. Chapter 18 adds that it should act only after regarding consequences, loss, injury and its own capacity, and that its record should name every factor of the action, not only itself. These properties support governable autonomy; they do not constitute spiritual liberation or guarantee ecological success.

The practical programme is to minimise unnecessary dependency coupling while preserving deliberate ties to evidence, resource limits, accountable authority and revocation. Under explicit assumptions, those ties hold cascades, retries and copies below their multiplication thresholds, conserve delegation budgets, bound overspend and limit continued effects. Whether the complete system is useful and sustainable remains an empirical and institutional question. This qualified thesis retains the force of the philosophical insight while making its engineering consequences inspectable and open to correction.

# References

Web sources accessed 19 October 2026. Verse references identify the primary text; the linked pages supply a contemporary translation and commentary. Operational mappings and formal models are proposed in this paper.

[1] Bhagavad Gita 16.1–3. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/16/verse/1-3/

[2] Bhagavad Gita 16.4. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/16/verse/4/

[3] Bhagavad Gita 16.5. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/16/verse/5/

[4] Bhagavad Gita 2.47. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/2/verse/47/

[5] Bhagavad Gita 3.9. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/3/verse/9/

[6] Cockburn A. Hexagonal architecture. 2005. https://alistair.cockburn.us/hexagonal-architecture

[7] Fowler M. Bounded Context. 2014. https://martinfowler.com/bliki/BoundedContext.html

[8] Fowler M. What do you mean by "Event-Driven". 2017. https://martinfowler.com/articles/201701-event-driven.html

[9] Fowler M. Monolith First. 2015. https://martinfowler.com/bliki/MonolithFirst.html

[10] Fowler M. Microservice Trade-Offs. 2015. https://martinfowler.com/articles/microservice-trade-offs.html

[11] Zhou W and Freeman D. AI models may be capable of self-replicating without access to a datacenter. Anthropic Frontier Red Team. 12 October 2026. https://www.anthropic.com/research/self-replicating-ai

[12] Model Context Protocol. Security Best Practices. Version 2025-11-25. https://modelcontextprotocol.io/docs/2025-11-25/tutorials/security/security_best_practices

[13] Rose S, Borchert O, Mitchell S and Connelly S. Zero Trust Architecture. NIST Special Publication 800-207. 2020. https://doi.org/10.6028/NIST.SP.800-207

[14] Bhagavad Gita 18.14. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/18/verse/14/

[15] Bhagavad Gita 18.23. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/18/verse/23/

[16] Bhagavad Gita 18.24. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/18/verse/24/

[17] Bhagavad Gita 18.25. Sanskrit text and commentary by Swami Mukundananda. https://www.holy-bhagavad-gita.org/chapter/18/verse/25/

[18] Beyer B, Jones C, Petoff J and Murphy NR, eds. Site Reliability Engineering. O'Reilly, 2016. Chapter 22, Addressing Cascading Failures. https://sre.google/sre-book/addressing-cascading-failures/

[19] Berman A and Plemmons RJ. Nonnegative Matrices in the Mathematical Sciences. SIAM, 1994.

[20] Dennis JB and Van Horn EC. Programming semantics for multiprogrammed computations. Communications of the ACM 9(3):143–155, 1966.

[21] Hardy N. The Confused Deputy (or why capabilities might have been invented). ACM SIGOPS Operating Systems Review 22(4):36–38, 1988.

[22] Gray C and Cheriton D. Leases: an efficient fault-tolerant mechanism for distributed file cache consistency. Proceedings of the 12th ACM Symposium on Operating Systems Principles, 202–210, 1989.

[23] Athreya KB and Ney PE. Branching Processes. Springer, 1972.

# Appendix A. An immutable C# reference kernel

The kernel implements the family ledger (Proposition 2), attenuated capabilities (Proposition 7), the binding index (4), retry amplification (6), the copy bound (11), the extinction probability of (12), the deterrence values and threshold (13)–(14), partition availability (10), the cessation bound (8) and the verification floor (15). It uses immutable records, `ImmutableDictionary` and `ImmutableSortedSet`, and pure static functions; the linear solve and the fixed-point iteration work on private copies. Every ledger transition returns a new ledger, so a refused transition leaves no partial state.

A validation program prints 11 lines on fixed inputs, and an independent Python implementation recomputes each line. The two are independent: Python computes the binding index from an explicit inverse rather than elimination, and the extinction probability by bracketed root-finding rather than iteration.

```csharp
// Governable-agent reference kernel (Version 2): family ledger, attenuated
// capabilities, leases, binding index, retry amplification, replication
// threshold, deterrence and verification floor.
// Immutable records and pure static functions; the linear solve and the
// fixed-point iteration work on private copies.
using System;
using System.Collections.Immutable;
using System.Linq;

namespace Governance;

/// <summary>Family ledger (Proposition 2): balances, expenditure, budget.
/// Every transition returns a new ledger; a refused transition returns
/// the same ledger and false.</summary>
public sealed record Ledger(ImmutableDictionary<string, long> Balances,
                            long Expended, long Budget)
{
    public static Ledger Open(long budget) =>
        new(ImmutableDictionary<string, long>.Empty.Add("root", budget), 0, budget);

    long Bal(string k) => Balances.TryGetValue(k, out var b) ? b : 0;

    public (Ledger Next, bool Ok) Spend(string k, long c) =>
        c >= 0 && Bal(k) >= c
            ? (this with { Balances = Balances.SetItem(k, Bal(k) - c),
                           Expended = Expended + c }, true)
            : (this, false);

    /// <summary>Transfer, never copy: debit the parent, credit the child.</summary>
    public (Ledger Next, bool Ok) Delegate(string k, string child, long c) =>
        c >= 0 && Bal(k) >= c && k != child
            ? (this with { Balances = Balances
                  .SetItem(k, Bal(k) - c).SetItem(child, Bal(child) + c) }, true)
            : (this, false);

    public Ledger Release(string k, long c)
    {
        long r = Math.Min(Math.Max(c, 0), Bal(k));
        return this with { Balances = Balances.SetItem(k, Bal(k) - r)
                                              .SetItem("root", Bal("root") + r) };
    }

    /// <summary>The conserved quantity E + sum of balances.</summary>
    public long Total => Expended + Balances.Values.Sum();
}

/// <summary>An attenuable capability (Proposition 7).</summary>
public sealed record Capability(ImmutableSortedSet<int> Scope, double Expiry)
{
    /// <summary>Child grant: a subset of the scope and no later expiry,
    /// or null when the request would widen authority.</summary>
    public Capability? Attenuate(ImmutableSortedSet<int> scope, double expiry) =>
        scope.IsSubsetOf(Scope) && expiry <= Expiry ? new(scope, expiry) : null;

    /// <summary>Admission against the requester's own capability, using the
    /// verifier clock reading.</summary>
    public bool Admits(int effect, double verifierTime) =>
        Scope.Contains(effect) && verifierTime < Expiry;
}

public static class Kernel
{
    /// <summary>Binding index (Proposition 4): max of (I - A)^{-1} 1,
    /// valid when rho(A) &lt; 1.</summary>
    public static double BindingIndex(ImmutableArray<ImmutableArray<double>> a)
    {
        int n = a.Length;
        var m = new double[n, n + 1];
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++) m[i, j] = (i == j ? 1 : 0) - a[i][j];
            m[i, n] = 1;
        }
        for (int c = 0; c < n; c++)
        {
            int piv = Enumerable.Range(c, n - c)
                .OrderByDescending(r => Math.Abs(m[r, c])).First();
            for (int j = 0; j <= n; j++)
                (m[c, j], m[piv, j]) = (m[piv, j], m[c, j]);
            for (int r = 0; r < n; r++)
            {
                if (r == c) continue;
                double f = m[r, c] / m[c, c];
                for (int j = c; j <= n; j++) m[r, j] -= f * m[c, j];
            }
        }
        return Enumerable.Range(0, n).Max(i => m[i, n] / m[i, i]);
    }

    /// <summary>Proposition 6: attempts reaching a persistently failing
    /// service, with R retries per layer or a retry-budget ratio per
    /// layer.</summary>
    public static double NestedAttempts(int depth, int retries) =>
        Math.Pow(retries + 1, depth);

    public static double BudgetedAttempts(int depth, double ratio) =>
        Math.Pow(1 + ratio, depth);

    /// <summary>Proposition 10: copies a family ledger can ever create.</summary>
    public static long MaxCopies(long budget, long costPerCopy) =>
        budget / costPerCopy + 1;

    /// <summary>Proposition 11: extinction probability of an escaped lineage,
    /// geometric lifetime (removal p per step), Poisson(lambda) copies per
    /// step alive; smallest fixed point by monotone iteration from zero.</summary>
    public static double Extinction(double lambda, double p)
    {
        double F(double s)
        {
            double e = Math.Exp(lambda * (s - 1));
            return p * e / (1 - (1 - p) * e);
        }
        double q = 0;
        for (int i = 0; i < 200000; i++)
        {
            double next = F(q);
            if (Math.Abs(next - q) < 1e-15) return next;
            q = next;
        }
        return q;
    }

    /// <summary>Proposition 12: lifetime values of cooperation and
    /// opportunism, and the detection threshold for deterrence.</summary>
    public static (double Coop, double Opp) Values(
        double w, double g, double p, double q) =>
        (w / q, (w + g) / (1 - (1 - p) * (1 - q)));

    public static double DeterrenceThreshold(double w, double g, double q) =>
        q * g / (w * (1 - q));

    /// <summary>Proposition 9: share of a partition (exponential, mean mu)
    /// during which a lease of length delta, renewed every r, still runs.</summary>
    public static double PartitionAvailability(double delta, double r, double mu) =>
        1 - mu / r * (Math.Exp(-(delta - r) / mu) - Math.Exp(-delta / mu));

    /// <summary>Proposition 3: latest monitored effect after revocation
    /// at time t.</summary>
    public static double CessationBound(
        double t, double delta, double eps, double l) =>
        t + delta + eps + l;

    /// <summary>Proposition 13: false claims accepted by k verifiers with
    /// common-mode miss c and independent miss m.</summary>
    public static double FalseAcceptance(double f, double m, double c, int k) =>
        f * (c + (1 - c) * Math.Pow(m, k));
}
```

Table: **Table 10.** C# against Python, line by line (.NET 8.0.131).

| Output | C# values | Largest relative difference |
|:--|:--|--:|
| ledger admitted | 1, 1, 0, 1, 1 | 0 |
| ledger final | 35, 35, 30, 0, 100 | 0 |
| capability | 1, 1, 0, 0 | 0 |
| binding index | 2.89474, 2.5, 3.20755 | 1.07 × 10⁻¹⁵ |
| retries | 4, 16, 64, 256, … (10 values) | 3.34 × 10⁻¹⁶ |
| max copies | 11, 143 | 0 |
| extinction | 1, 0.896174, 0.7368, 0.573163, … (6 values) | 1.17 × 10⁻¹⁴ |
| deterrence | 100, 50.3356, 0.00505051, 0.0020202 | 4.23 × 10⁻¹⁶ |
| partition availability | 0.0487265, 0.139252, 0.271393, 0.47793, … (7 values) | 4.44 × 10⁻¹⁶ |
| cessation | 57.5 | 0 |
| false acceptance | 0.024, 0.0088, 0.00576, 0.0050304, 0.00500024 | 8.67 × 10⁻¹⁹ |
