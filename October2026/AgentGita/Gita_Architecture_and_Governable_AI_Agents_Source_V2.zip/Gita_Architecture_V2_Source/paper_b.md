# 7 A model of architectural binding

The following results formalise selected mechanisms. They are not deductions about consciousness, spiritual attainment or the inevitable behaviour of future AI. Let $x(t)$ be a non-negative vector measuring disturbances in $n$ components at discrete time $t$. Its entries must use a specified normalisation. Let $A$ be an $n\times n$ non-negative matrix that upper-bounds one-step propagation, and let $u(t)$ represent external disturbance. Assume the componentwise inequality

$$x(t+1)\le Ax(t)+u(t). \tag{1}$$

The entries of $A$ represent measured or conservatively bounded influence, including retries and shared infrastructure effects. A source-code import graph alone is insufficient: shared databases, queues and operational dependencies also transmit disturbances. This is the anubandha check of Table 7 in quantitative form.

**Proposition 1 — Bounded cascade amplification (Version 1).** Suppose the maximum row sum of $A$ is at most $a$, where $0\le a<1$, and the largest component of $u(t)$ is at most $U$ at every step. If the largest initial component is $X_0$, then

$$\|x(t)\|_\infty\le a^tX_0+U\frac{1-a^t}{1-a}. \tag{2}$$

*Proof.* The induced infinity norm gives $\|x(t+1)\|_\infty\le a\|x(t)\|_\infty+U$. Repeated substitution yields $a^tX_0$ plus $U$ times the finite geometric sum. Non-negativity permits the componentwise inequality to pass to the norm. $\square$

**Corollary 1 — Monotone reduction under an elementwise bound (Version 1).** If $0\le A'\le A$ and both maximum row sums are below one, then $\sum_k(A')^ku\le\sum_kA^ku$ for every constant non-negative $u$.

The row-sum condition is sufficient but far from necessary, and it fails for a common architecture. A shared broker that receives disturbance from many services has a large row sum even when every cycle through it is weak. The sharp condition is spectral.

**Proposition 4 — The spectral condition and the binding index (new).** (i) If there are a vector $v$ with positive entries and $0\le a<1$ such that $Av\le av$, and $u(t)\le U_vv$ at every step, then with $\|x\|_v=\max_ix_i/v_i$,

$$\|x(t)\|_v\le a^t\|x(0)\|_v+U_v\frac{1-a^t}{1-a}. \tag{3}$$

Such a $v$ exists for every $a>\rho(A)$, and for $a=\rho(A)$ when $A$ is irreducible. (ii) If the propagation holds with equality and $u$ is a constant positive vector, accumulated disturbance stays bounded if and only if $\rho(A)<1$. (iii) When $\rho(A)<1$, the long-run worst case over all $u$ with $\|u\|_\infty\le U$ is exactly $\kappa(A)U$, where

$$\kappa(A)=\max_i\left[(I-A)^{-1}\mathbf{1}\right]_i=\|(I-A)^{-1}\|_\infty\le\frac{1}{1-a}. \tag{4}$$

*Proof.* (i) $x(t)\le\|x(t)\|_vv$ componentwise, so $Ax(t)\le\|x(t)\|_vAv\le a\|x(t)\|_vv$, and (1) gives $\|x(t+1)\|_v\le a\|x(t)\|_v+U_v$; induction gives (3). For irreducible $A$ the Perron vector is positive with $Av=\rho(A)v$. Otherwise the Perron vector of $A+\epsilon J$, with $J$ the all-ones matrix and $\epsilon$ small enough that $\rho(A+\epsilon J)\le a$, is positive and satisfies $Av\le(A+\epsilon J)v\le av$ [19]. (ii) If $\rho(A)<1$, the Neumann series $\sum_kA^ku$ converges. If $\rho(A)\ge1$, a non-negative left Perron vector $w\ne0$ satisfies $w^\top A^ku=\rho(A)^kw^\top u\ge w^\top u>0$, so the series diverges. (iii) The equality system converges to $(I-A)^{-1}u$. Its entries are non-decreasing in $u$ because $(I-A)^{-1}=\sum_kA^k\ge0$, so the worst case is $u=U\mathbf{1}$. A non-negative matrix's infinity norm is its largest row sum, and row sums at most $a$ give $\|(I-A)^{-1}\|_\infty\le\sum_ka^k$. $\square$

We call $\kappa(A)$ the *binding index*: the largest long-run disturbance in any component per unit of external disturbance. It is computable from a measured $A$ by one linear solve.

**Example — a shared broker.** Let component 0 be a broker that receives disturbance 0.3 from each of four services, and let each service receive 0.2 from the broker. The broker's row sum is {{hub.row_sum_max}}, so Proposition 1 says nothing. But $\rho(A)=\sqrt{4\times0.3\times0.2}\approx{{hub.rho|f3}}$, and solving $x_0=1+1.2(1+0.2x_0)$ gives

$$\kappa(A)=\frac{1+4\times0.3}{1-4\times0.3\times0.2}=\frac{2.2}{0.76}\approx2.895. \tag{5}$$

The disturbance converges to this value (Figure 2a).

**Proposition 5 — Monotone reduction under the spectral condition (new).** If $0\le A'\le A$ and $\rho(A)<1$, then $\rho(A')\le\rho(A)$, $(I-A')^{-1}\le(I-A)^{-1}$ entrywise, and $\kappa(A')\le\kappa(A)$.

*Proof.* $(A')^k\le A^k$ for every $k$ by induction. The Neumann series of $A$ converges, so that of $A'$ converges and is dominated term by term. Monotonicity of the spectral radius on non-negative matrices follows [19]. $\square$

Proposition 5 removes Version 1's row-sum requirement from the corollary, but it keeps the essential hypothesis $A'\le A$. Extraction rarely satisfies it. Consider three modules of a monolith with mutual influence 0.3, for which $\kappa={{extraction.kappa_monolith|f2}}$. Extract them as services with direct influence reduced to 0.1, but route their events through a shared broker that exchanges influence 0.3 with each. The direct couplings fell, yet $\kappa$ rose to {{extraction.kappa_split|f2}} and $\rho$ from {{extraction.rho_monolith|f2}} to {{extraction.rho_split|f2}}. Version 1's warning that "a claim of decoupling does not by itself establish $A'\le A$" thus has a worked instance. Architecture must be evaluated through its measured influence matrix, not the number of deployable units.

Across 500 random matrices with row sums below one, the exact index had a median of {{row_sum_conservatism.median_kappa_over_bound|f2}} times Version 1's bound $1/(1-a)$, and as little as {{row_sum_conservatism.min_kappa_over_bound|f2}} times. The row-sum bound is safe but can be very loose.

## Retries are entries of the influence matrix

Akrodha in Table 2 asks whether denial or error produces escalating retries. In a call chain the escalation is multiplicative.

**Proposition 6 — Retry amplification (new).** In a chain of $d$ layers, let layer $i$ make up to $R_i+1$ attempts on its downstream call. If the bottom service fails persistently, each top-level request causes exactly $\prod_{i=1}^d(R_i+1)$ attempts on it. If instead layer $i$ caps its retries at a fraction $\rho_i$ of the requests it receives (a retry budget), the attempts per top-level request are at most

$$N_d\le\prod_{i=1}^d(1+\rho_i). \tag{6}$$

*Proof.* Under persistent failure every attempt fails, so each request reaching layer $i$ produces exactly $R_i+1$ requests to layer $i+1$. Under a budget it produces at most $1+\rho_i$ on average over the budget window. Multiply along the chain. $\square$

With three retries at each of three layers this gives $4^3=64$ attempts per user action, the example given in Google's guidance on cascading failures [18]. A 10 percent budget per layer gives at most $1.1^3=1.331$. Retrying at a single layer gives four (Figure 2b). In the language of Section 7, a retry policy sets diagonal entries of $A$ for the failing path, and nested retries multiply them. Krodha is therefore not a metaphor here; it is a gain greater than one.

![**Figure 2.** (a) The shared-broker example: the broker's row sum is {{hub.row_sum_max}}, so the row-sum bound of Proposition 1 does not apply. Yet $\rho(A)\approx{{hub.rho|f2}}$, and the worst-case disturbance converges to the binding index {{hub.kappa|f2}} of Proposition 4. (b) Attempts reaching a persistently failing service per top-level request, against call-chain depth, from an explicit recursive simulation. Three retries at every layer give $4^d$, three retries at one layer give four, and a 10 percent retry budget per layer gives at most $1.1^d$.](fig/cascade.png){width=100%}

# 8 Conserved budgets and expiring authority

**Proposition 2 — Delegation cannot mint entitlement (Version 1).** Let $B_0$ be a finite scalar task budget. An external ledger tracks remaining spendable balances $b_i$ and cumulative expenditure $E$. Admission, spending, delegation and release are atomic and non-negative. A delegated balance is transferred from an existing balance, never copied. No agent can modify the ledger or obtain unrecorded allocation. Then at every ledger state

$$E+\sum_ib_i\le B_0. \tag{7}$$

*Proof.* Initially the sum is at most $B_0$. Spending moves an amount from a balance into $E$ and preserves the sum. Delegation debits one balance and credits another by the same amount. Returning allocation transfers it to a tracked pool or removes it from the task. No permitted transition increases the total. $\square$

The construction can be applied separately to tokens, monetary spend, storage and reserved compute time. These units cannot be added without a declared conversion. Thermal safety and instantaneous power require host-local limits as well as cumulative accounting. The proposition bounds entitlement under its assumptions; it does not establish that a malicious host will report physical consumption correctly. In {{ledger.trials}} random scripts of {{ledger.transitions|d}} transitions in all, the invariant (7) never failed.

Atomicity is not a detail. If $k$ agents each check a shared balance of $c$ and then each spend $c$, all checks pass and the family spends $kc$, overspending by $(k-1)c$. The check-then-spend pattern defeats conservation exactly when agents run concurrently, which is when delegation is most useful.

**Proposition 3 — Cessation after lease expiry (Version 1).** Every effectful operation requires an unexpired lease validated by a trusted reference monitor. No valid lease expires more than $\Delta$ after time $T$, when renewal is revoked. The verifier clock can lag real time by at most $\epsilon$, and any operation already admitted completes or is forcibly terminated within $L$. Agents cannot bypass the monitor, extend leases or create an independent authority root. Then all monitored effects cease by

$$T+\Delta+\epsilon+L. \tag{8}$$

*Proof.* After $T+\Delta+\epsilon$ even the latest valid lease is expired under the slowest permitted verifier clock. No new operation can be admitted. The bounded execution assumption terminates any last admitted operation within a further $L$. Irreversible effects already completed remain; cessation is not rollback. $\square$

**Proposition 7 — Attenuation closure (new).** Let every capability carry a scope $S$ and an expiry $\tau$. A child capability can be granted only with $S_{child}\subseteq S_{parent}$ and $\tau_{child}\le\tau_{parent}$. An effect $e$ requested at verifier time $t$ is admitted only if $e\in S$ and $t<\tau$ for the capability presented by the requester. Then every admitted effect anywhere in the delegation tree lies in the root's scope and occurs before the root's expiry. If expiries are leases renewed only through the root, the bound (8) holds for the whole tree.

*Proof.* Scope inclusion and expiry order are transitive along the path from any capability to the root. The admission rule checks the requester's own capability, so an admitted effect satisfies $e\in S\subseteq S_{root}$ and $t<\tau\le\tau_{root}$. For the tree, every descendant lease ends no later than its ancestor's, so Proposition 3 applies to the latest of them. $\square$

The hypothesis that admission checks the *requester's* capability is the one the confused-deputy problem violates [20, 21]. In {{attenuation.trees}} random delegation trees with {{attenuation.requests|d}} requests, admission against the requester's capability admitted {{attenuation.admitted|d}} effects with {{attenuation.violations}} outside the root's scope or lifetime. Admission against a tool's broad ambient authority admitted {{attenuation.confused_deputy_violations|d}} such effects. This is why the MCP guidance treats token passthrough and scope minimisation as security concerns [12]. A copied model or workspace likewise receives no authority merely because it is a copy: authority travels with a grant, not with code.

**Proposition 8 — Bounded overrun of reservations (new).** Suppose each operation atomically reserves an estimate $r$ before it starts and settles its actual cost when it ends. The actual cost may exceed the reservation by at most $\omega$. At most $k$ of the family's operations are in flight at once, and a reservation is admitted only when the balance covers it. Then the balance never falls below $-k\omega$, and

$$E\le B_0+k\omega. \tag{9}$$

*Proof.* Reservation and settlement preserve $E+b+\sum r_{in\,flight}=B_0$ when the balance is allowed to go negative at settlement. Fix a time, and let $s$ be the last earlier time at which $b\ge0$. After $s$ no reservation is admitted, so $b$ can fall only through overruns of operations in flight at $s$. There are at most $k$ of these, and each lowers $b$ by at most $\omega$. Hence $b\ge-k\omega$, and (9) follows because in-flight reservations are non-negative. $\square$

Metering lag is the usual source of $\omega$. The bound says that a governed family can overspend only by the product of its concurrency and its per-operation estimation error. Both are design parameters. In {{overrun.trials}} random runs the bound was never violated, and the largest observed excess reached {{overrun.max_excess_over_k_omega|f2}} of $k\omega$. The bound is nearly attained.

**Proposition 9 — Leases trade control for availability (new).** Let a connected agent renew a lease of length $\Delta$ every $r\le\Delta$. A network partition begins at a uniformly random phase of the renewal cycle and lasts an exponentially distributed time with mean $\mu$. During the partition the agent works until its lease expires. Then the expected share of the partition during which it can still act is

$$A(\Delta)=1-\frac{\mu}{r}\left(e^{-(\Delta-r)/\mu}-e^{-\Delta/\mu}\right), \tag{10}$$

while by Proposition 3 the worst-case revocation delay is $\Delta+\epsilon+L$. Both increase with $\Delta$.

*Proof.* The remaining lease at the start of the partition is uniform on $[\Delta-r,\Delta]$. For an exponential duration $D$, the expected working time is $\text{E}\min(D,a)=\mu(1-e^{-a/\mu})$. Averaging over $a$ and dividing by $\mu$ gives (10). $\square$

With $\mu=30$ and $r=1$, a lease of 10 retains {{lease.rows.2.availability|pct0}} of partition time, one of 40 retains {{lease.rows.4.availability|pct0}}, and one of 160 retains {{lease.rows.6.availability|pct1}} (Figure 4b). Simulation agreed with (10) to within {{lease.max_mc_error|f4}}. Version 1 stated the qualitative trade-off, which leases have carried since their introduction [22]; (10) prices it. An operator who wants revocation within a day cannot also have agents that work through week-long partitions. Dhṛti, persistence within a valid envelope, has a cost that the operator must choose.

## What the propositions leave open

Budget conservation, bounded propagation, attenuation and bounded cessation are different properties. None establishes factual accuracy, fairness or safe physical design. Their value is compositional clarity: they identify which assurances depend on contracts, which depend on a trusted runtime, and which still require empirical evidence or professional judgement.

# 9 Replication and the ecology of persistence

The replication report of Section 5 raises the question that Version 1 left qualitative: what can governance say about copies? The answer depends on whether a copy is made inside the governed system or escapes it.

**Proposition 10 — A family ledger caps copies (new).** Suppose every copy is created by an effectful spawn operation admitted against the family ledger at a cost of at least $c>0$, and a copy receives only allocation transferred to it. Then the number of copies ever created, including the original, is at most

$$\left\lfloor\frac{B_0}{c}\right\rfloor+1. \tag{11}$$

*Proof.* Each spawn adds at least $c$ to $E$, and $E\le B_0$ by Proposition 2. $\square$

The hypothesis that a copy's allocation is *transferred* is the whole content. If each copy instead receives a fresh per-agent cap $b\ge c$, every copy can spawn $\lfloor b/c\rfloor$ more and the population grows geometrically. With $B_0=100$, $c=10$ and a cap of 30, the family ledger allowed {{replication.family_ledger.8}} copies in all. Per-agent caps allowed {{replication.per_agent_cap.8|d}} after eight generations (Figure 3a). Aloluptva, non-covetousness, becomes the requirement that copying never increases total entitlement.

Proposition 10 governs copies made through the harness. A copy that runs on a host outside any reference monitor is not governed by Propositions 2–10, because their central assumption, that effects pass through the monitor, fails. For such copies the relevant question is ecological.

**Proposition 11 — A threshold for escaped copies (new; classical mathematics).** Let each escaped copy, in each step it remains active, create a Poisson number of new copies with mean $\lambda=\beta v$. Here $\beta$ is the rate of attempts and $v$ the probability that an attempt reaches a host that admits it. Let each copy be removed independently with probability $p$ per step. The number of copies made by one copy then has the generating function and mean

$$f(s)=\frac{pe^{\lambda(s-1)}}{1-(1-p)e^{\lambda(s-1)}},\qquad m=f'(1)=\frac{\beta v}{p}. \tag{12}$$

A lineage dies out with probability one if $m\le1$. If $m>1$ it persists with probability $1-q$, where $q$ is the smallest root of $f(s)=s$ with $0\le s<1$.

*Proof.* A copy's active life is geometric with $\text{P}(\ell)=p(1-p)^{\ell-1}$, and given its life its offspring are Poisson with mean $\lambda\ell$. Summing the geometric series of Poisson generating functions gives $f$. The lineage is a Galton–Watson process, and the extinction criterion is the classical one [23]. $\square$

The three governance levers appear as factors of $m$. Host-side admission lowers $v$; the report's contained spread relied on an unauthenticated port, which is exactly a host with $v$ near one. Detection and removal raise $p$. Slow replication lowers $\beta$: the report's estimate of more than one to two days per 9B replication caps the rate per day. As a purely illustrative calculation, if each copy can complete at most one replication every two days, then $\lambda\le0.5$ per day, and a daily removal probability of 0.5 keeps $m\le1$ whatever $v$ is. In simulation the persistence probabilities matched the fixed point of (12) to within {{branching.max_mc_error_supercritical|f3}} for $m$ from 1.1 to 3 (Figure 3b). The threshold is the ecological counterpart of the binding index: both say that governance must hold a multiplication factor below one.

![**Figure 3.** (a) Copies created when each copy costs $c=10$: a fresh per-agent cap of 30 for every copy allows geometric growth, while one family ledger of $B_0=100$ allows at most $B_0/c+1=11$ (Proposition 10). (b) Probability that the lineage of one escaped copy persists, against the mean number of copies per copy $m=\beta v/p$, with removal probability 0.25 per step. The curve is $1-q$ from (12); the points are simulations of 4,000 lineages each (Proposition 11).](fig/replication.png){width=100%}

## When does cooperation pay?

Version 1's one-step condition $g<pL$ leaves the loss $L$ undefined. In a continuing relationship the natural loss is the relationship itself.

**Proposition 12 — Deterrence in a continuing relationship (new).** In each step an agent earns $w$ for authorised service, or $w+g$ if it behaves opportunistically. After each step the relationship ends with probability $q$ for reasons unrelated to conduct. An opportunistic agent is in addition detected and removed with probability $p$, independently. The expected lifetime values are

$$V_{coop}=\frac{w}{q},\qquad V_{opp}=\frac{w+g}{1-(1-p)(1-q)}, \tag{13}$$

and opportunism pays if and only if

$$p<\frac{qg}{w(1-q)}. \tag{14}$$

*Proof.* Lifetimes are geometric with means $1/q$ and $1/(1-(1-p)(1-q))$. The inequality $V_{opp}>V_{coop}$ is equivalent to $gq>wp(1-q)$. $\square$

The threshold is proportional to the churn $q$. A stable relationship needs only a small detection probability: with $q=0.01$, a 50 percent opportunistic gain is deterred once $p\ge{{deterrence.rows.0.threshold_p|f4}}$ per step. Simulation of the four cases in the source agreed with (13) to within {{deterrence.max_relative_mc_error|pct1}}. The proposition also shows what breaks deterrence. If a removed agent can re-enter under a new identity, for instance as a fresh copy, the removal costs it nothing and (14) no longer protects anyone. An identity that survives copying, the kartā field of Table 5, is therefore load-bearing for the ecology, not only for audit. Discounting can be folded into $q$, and risk aversion or partial penalties change the constants but not the structure.

**Proposition 13 — The verification floor (new).** Let a claim be false with probability $f$, and let acceptance require all of $k$ verifiers to pass it. With probability $c$ the verifiers fail together (a shared blind spot, a shared compromised tool, or self-attestation); otherwise each misses a false claim independently with probability $m$. The probability of accepting a false claim is

$$f\left(c+(1-c)m^k\right)\ge fc. \tag{15}$$

*Proof.* Condition on the common-mode event. $\square$

Self-attestation is the case $c=1$, in which adding checks achieves nothing. With $f=0.1$, $m=0.2$ and $c=0.05$, one verifier accepts {{verification.rows.0.false_accept|pct1}} of claims that are false, three accept {{verification.rows.2.false_accept|pct2}}, and eight cannot go below the floor of {{verification.rows.4.floor|pct1}} (Figure 4c). Satya therefore requires not only checks but checks with different failure modes, which is the pauruṣa regard applied to the verifier itself.

![**Figure 4.** (a) The deterrence boundary (14): opportunism pays above each line, for three churn rates $q$; stable relationships need little detection. (b) Work retained during a network partition against lease length, which is also the revocation delay (Proposition 9, equation (10)), with mean partition 30 and renewal every step; crosses are simulations. (c) False claims accepted against the number of verifiers, with a 5 percent common-mode failure; crosses are simulations of 400,000 claims (Proposition 13).](fig/ecology.png){width=100%}
