"""Figures for Version 2, drawn from results.json and the declared models."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

P = Path(__file__).resolve().parent
(P / 'fig').mkdir(exist_ok=True)
r = json.loads((P / 'results.json').read_text())
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10, 'axes.spines.top': False,
                     'axes.spines.right': False})
blue, orange, grey, ink, light = '#28689b', '#c9692e', '#58636d', '#1f2328', '#eef2f5'

# ---------------------------------------------------------------- Figure 1: the admission harness
fig, ax = plt.subplots(figsize=(10.4, 4.6)); ax.axis('off'); ax.set(xlim=(-0.3, 10), ylim=(0, 4.75))


def box(x, y, w, h, title, body, edge=grey, fill='white'):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.02,rounding_size=0.08',
                                fc=fill, ec=edge, lw=1.2))
    ax.text(x + w / 2, y + h - 0.2, title, ha='center', va='top', fontsize=9.6, weight='bold', color=ink)
    ax.text(x + w / 2, y + h - 0.52, body, ha='center', va='top', fontsize=8.3, color=ink, linespacing=1.35)


def arrow(a, b, color=grey):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle='-|>', mutation_scale=12, color=color, lw=1.3))


box(-0.25, 1.0, 2.4, 2.7, 'Task record (18.14)',
    'adhiṣṭhāna: host, substrate\nkartā: agent identity\nkaraṇa: tools, instruments\nceṣṭā: operations\ndaiva: declared residual\nuncertainty')
box(2.65, 0.45, 2.45, 3.75, 'Admission (18.25)',
    'anubandha: consequences\nbinding index κ(A), Prop. 4\n\nkṣaya: loss\nfamily ledger, Props 2, 8, 10\n\nhiṃsā: injury\nhost limits, Props 6, 11\n\npauruṣa: own capacity\ncompetence envelope, Prop. 13',
    edge=orange, fill='#fdf4ee')
box(5.6, 2.35, 2.0, 1.3, 'Execution', 'attenuated capability\nlease, reservation\nretry budget')
box(5.6, 0.45, 2.0, 1.3, 'Verification', 'independent evidence\ncommon-mode audit')
box(8.1, 1.4, 1.8, 1.3, 'Release', 'accountable owner\ncurrent authority')
arrow((2.15, 2.4), (2.65, 2.4)); arrow((5.1, 3.0), (5.6, 3.0), orange); arrow((6.6, 2.35), (6.6, 1.75))
arrow((7.6, 1.1), (8.1, 1.8)); arrow((7.6, 3.0), (8.1, 2.4), grey)
ax.text(7.0, 4.55, 'Planner proposes; runtime outside its write authority enforces', ha='center',
        fontsize=8.6, color=grey, style='italic')
ax.text(3.875, 0.12, 'Action begun without these four checks is tāmasa (18.25)', ha='center', fontsize=8.4,
        color=orange, style='italic')
fig.savefig(P / 'fig/harness.png', dpi=220, bbox_inches='tight', facecolor='white'); plt.close(fig)

# ---------------------------------------------------------------- Figure 2: cascades and retries
fig, axs = plt.subplots(1, 2, figsize=(10, 3.6))
h = r['hub']; t = np.arange(1, len(h['trajectory']) + 1)
axs[0].plot(t, h['trajectory'], c=blue, lw=2, label='worst-case disturbance, hub')
axs[0].axhline(h['kappa'], c=orange, lw=1.5, ls='--', label=f"binding index κ = {h['kappa']:.2f}")
axs[0].set(xlabel='step t', ylabel='largest component of x(t)', ylim=(0, 3.4))
axs[0].set_title(f"(a) row sum {h['row_sum_max']:.1f} > 1, yet ρ(A) = {h['rho']:.2f}", fontsize=10)
axs[0].legend(frameon=False, fontsize=8.8, loc='lower right'); axs[0].grid(alpha=.15)
rows = r['retries']['rows']; d = [q['depth'] for q in rows]
axs[1].plot(d, [q['R3'] for q in rows], 'o-', c=orange, lw=2, label='3 retries at every layer: 4^d')
axs[1].plot(d, [q['single_layer'] for q in rows], 's-', c=grey, lw=1.6, label='3 retries at one layer only')
axs[1].plot(d, [q['budget10'] for q in rows], 'd-', c=blue, lw=2, label='10% retry budget per layer: 1.1^d')
axs[1].set(yscale='log', xlabel='call-chain depth d', ylabel='attempts at the failing service per request',
           xticks=d)
axs[1].set_title('(b) nested retries multiply (Proposition 6)', fontsize=10)
axs[1].legend(frameon=False, fontsize=8.8, loc='upper left'); axs[1].grid(alpha=.15, which='both')
fig.tight_layout(); fig.savefig(P / 'fig/cascade.png', dpi=220, facecolor='white'); plt.close(fig)

# ---------------------------------------------------------------- Figure 3: replication
fig, axs = plt.subplots(1, 2, figsize=(10, 3.6))
rep = r['replication']; g = np.arange(len(rep['per_agent_cap']))
axs[0].plot(g, rep['per_agent_cap'], 'o-', c=orange, lw=2, label='fresh cap of 30 for every copy')
axs[0].plot(g, rep['family_ledger'], 's-', c=blue, lw=2, label='one family ledger of 100')
axs[0].axhline(rep['B0'] // rep['cost'] + 1, c=grey, ls=':', lw=1.2)
axs[0].text(8, 14, 'B₀/c + 1 = 11', ha='right', color=grey, fontsize=8.6)
axs[0].set(yscale='log', xlabel='generation', ylabel='copies created so far')
axs[0].set_title('(a) each copy costs c = 10 (Proposition 10)', fontsize=10)
axs[0].legend(frameon=False, fontsize=8.8, loc='upper left'); axs[0].grid(alpha=.15, which='both')
br = r['branching']['rows']; mm = np.linspace(0.5, 3.2, 200)
from scipy.optimize import brentq
pr = r['branching']['removal_prob']


def ext(m):
    lam = m * pr
    if m <= 1:
        return 1.0
    f = lambda s: pr * np.exp(lam * (s - 1)) / (1 - (1 - pr) * np.exp(lam * (s - 1))) - s
    return brentq(f, 0, 1 - 1e-12)


axs[1].plot(mm, [1 - ext(m) for m in mm], c=blue, lw=2, label='theory: 1 − smallest fixed point')
axs[1].scatter([q['m'] for q in br], [1 - q['extinction_mc'] for q in br], c=orange, s=36, zorder=3,
               label='simulation, 4,000 lineages')
axs[1].axvline(1, c=grey, ls=':', lw=1.2)
axs[1].set(xlabel='mean copies per copy  m = βv/p', ylabel='probability a lineage persists', ylim=(-.03, .8))
axs[1].set_title('(b) escaped copies persist only if m > 1 (Prop. 11)', fontsize=10)
axs[1].legend(frameon=False, fontsize=8.8, loc='upper left'); axs[1].grid(alpha=.15)
fig.tight_layout(); fig.savefig(P / 'fig/replication.png', dpi=220, facecolor='white'); plt.close(fig)

# ---------------------------------------------------------------- Figure 4: deterrence, leases, verification
fig, axs = plt.subplots(1, 3, figsize=(11, 3.5))
pp = np.logspace(-4, -1, 200)
for q, ls in ((0.001, '-'), (0.01, '--'), (0.05, '-.')):
    axs[0].plot(pp, pp * (1 - q) / q, c=blue, ls=ls, lw=1.8, label=f'churn q = {q:g}')
axs[0].set(xscale='log', yscale='log', xlabel='detection probability per step p', ylabel='relative gain g/w',
           ylim=(1e-2, 1e2))
axs[0].text(1.3e-4, 2.6, 'opportunism pays\n(above a line)', fontsize=8.4, color=orange)
axs[0].text(2.5e-2, 0.03, 'deterred', fontsize=8.4, color=blue)
axs[0].set_title('(a) deterrence boundary (Prop. 12)', fontsize=10)
axs[0].legend(frameon=False, fontsize=8.2, loc='upper left'); axs[0].grid(alpha=.15, which='both')
lr = r['lease']['rows']
axs[1].plot([q['Delta'] for q in lr], [q['availability'] for q in lr], 'o-', c=blue, lw=2, label='equation (10)')
axs[1].scatter([q['Delta'] for q in lr], [q['availability_mc'] for q in lr], marker='x', c=orange, s=40,
               zorder=3, label='simulation')
axs[1].set(xscale='log', xlabel='lease length Δ = revocation delay', ylabel='work retained during a partition')
axs[1].set_title('(b) leases trade control for availability', fontsize=10)
axs[1].legend(frameon=False, fontsize=8.6, loc='upper left'); axs[1].grid(alpha=.15, which='both')
vr = r['verification']['rows']
axs[2].plot([q['k'] for q in vr], [q['false_accept'] for q in vr], 'o-', c=blue, lw=2, label='f(c + (1 − c)mᵏ)')
axs[2].scatter([q['k'] for q in vr], [q['false_accept_mc'] for q in vr], marker='x', c=orange, s=40, zorder=3,
               label='simulation')
axs[2].axhline(vr[0]['floor'], c=grey, ls=':', lw=1.3)
axs[2].text(8, vr[0]['floor'] * 1.08, 'common-mode floor fc', ha='right', fontsize=8.4, color=grey)
axs[2].set(xlabel='independent verifiers k', ylabel='false claims accepted', ylim=(0, .026))
axs[2].set_title('(c) verification floor (Prop. 13)', fontsize=10)
axs[2].legend(frameon=False, fontsize=8.6); axs[2].grid(alpha=.15)
fig.tight_layout(); fig.savefig(P / 'fig/ecology.png', dpi=220, facecolor='white'); plt.close(fig)
print('figures written')
