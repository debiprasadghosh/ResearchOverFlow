---
title: The Bhagavad Gita and the Design of Governable AI Agents
subtitle: Divine qualities, architectural coupling and bounded autonomy. Version 2
author:
  - Debi Prasad Ghosh
  - Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India
date: 19 October 2026 · Version 2 · Defensible Intelligence series · “Respect science. Import emotion.”
---

# Abstract

The Bhagavad Gita distinguishes qualities directed toward liberation from those directed toward bondage. This paper develops a disciplined engineering interpretation of that distinction for software architecture and distributed AI agents. The correspondence concerns action that preserves the capacity for correction, substitution, refusal and termination. It does not identify spiritual liberation with a software metric or attribute moral experience to machines. Version 1 distinguished dependency, authority and resource coupling and proposed a harness of contracts, attenuated capabilities, conserved budgets, expiring leases, independent evidence and accountable release.

Version 2 widens the textual basis and sharpens the mathematics. Verse 18.14 names five factors of every action, of which the doer is only one, and gives a task record in which accountability is never assigned to the agent alone. Verses 18.23–25 classify action by its manner, and 18.25 names four things that deluded action disregards: consequences, loss, injury and one's own capacity. Read as engineering questions, these become a four-part admission test, and each part is tied to a proved bound.

Version 1's cascade bound needed every row sum below one. It is replaced by the sharp condition that the spectral radius is below one, and by a binding index $\kappa(A)$, the exact worst-case amplification. A shared-broker architecture with row sum {{hub.row_sum_max}} has spectral radius {{hub.rho|f2}} and binding index {{hub.kappa|f2}}. In one worked case, extracting services behind a shared broker raises $\kappa$ from {{extraction.kappa_monolith|f2}} to {{extraction.kappa_split|f2}}. Nested retries multiply as $(R+1)^d$, while a retry budget bounds them by $(1+\rho)^d$.

Further results show that attenuation confines a whole delegation tree to the root's scope and lifetime, and that overrun of reservations is bounded by $k\omega$. A lease must trade revocation delay against work retained during partitions. A family ledger caps the number of copies an agent can make at $B_0/c+1$, whereas per-agent caps allowed {{replication.per_agent_cap.8|d}} copies in eight generations. Copies that escape governance persist only when the mean number of copies per copy exceeds one. Opportunism is deterred exactly when the detection probability exceeds $qg/(w(1-q))$, and independent verification has a floor set by common-mode failure.

All {{n_checks}} checks pass, and an immutable C# kernel agrees with an independent Python implementation. The October 2026 Anthropic replication study motivates the problem without establishing that uncontrolled replication is inevitable, or that ethical agents necessarily outcompete harmful ones. The thesis remains conditional and testable.

**Keywords** Bhagavad Gita; karma bandhana; five factors of action; software architecture; AI agents; bounded autonomy; resource governance; replication; verification

**Paper type** Conceptual research and engineering proposal. Formal results concern the explicitly stated models; numerical checks and simulations test those models. No new experiments on deployed systems are reported.

# 1 The interpretive foundation

The central proposal is that freedom in an engineered system includes the ability to act without unnecessarily restricting the future actions of its operators and neighbours. A component that can be replaced, a task that can be stopped, and a result that can be challenged preserve options. A system that demands ever more privileges, locks users into its internal state, or cannot relinquish resources consumes those options. The Bhagavad Gita offers a vocabulary for examining this distinction, provided its theological meaning is preserved rather than reduced to software design.

Verses 16.1–3 enumerate the daivī qualities; 16.4 gives six āsurī qualities; 16.5 associates the former with liberation and the latter with bondage [1–3]. These are claims about human spiritual life. Their application to software is an interpretation proposed here. Technical dependency is not itself a moral fault, and an outage is not evidence of anyone's spiritual condition.

The connection with action without attachment needs a wider textual basis than Chapter 16 alone. Verse 2.47 addresses action and attachment to its fruits, while also resisting attachment to inaction. Verse 3.9 explicitly connects action with bondage and calls for action free from attachment in a sacrificial orientation [4, 5]. This context supports a conception of disciplined activity rather than withdrawal from responsibility. Niṣkāma action should therefore not be translated as indifference to whether an engineering result is correct.

Chapter 18 supplies the analysis of action itself that the engineering reading most needs. Verse 18.14 lists five factors of action: the body as its seat (adhiṣṭhāna), the doer (kartā), the instruments (karaṇa), the many efforts (ceṣṭā), and, fifth, daiva, which the cited translation renders as Divine Providence [14]. Verses 18.23–25 classify action by the manner in which it is undertaken [15–17]. Section 6 develops both passages, under the same three-level method.

## A method for carrying the analogy

We use three levels of argument. At the textual level, the Sanskrit concepts retain their religious setting. At the interpretive level, selected qualities suggest questions about boundaries, acquisition, evidence and correction. At the engineering level, those questions become mechanisms with explicit assumptions and measurable behaviour. A mathematical guarantee arises only at the third level, from its model and enforcement conditions; it does not follow from the authority of the analogy.

The term karma bandhana consequently names the philosophical starting point, while architectural binding names the operational object. The latter includes costly dependencies, irreversible commitments, unauthorised authority and accumulated obligations that constrain future change. The correspondence is useful because it suggests design questions. It is not an identity between liberation and maintainability.

## The qualified thesis

An agent should pursue an authorised purpose while relinquishing unnecessary implementation commitments, privileges, resources and claims to certainty. It should retain enough structure to support reliable action and enough restraint to preserve the agency of others. This formulation makes non-attachment compatible with ownership of consequences, professional diligence and responsible refusal.

## What Version 2 adds

- **A wider textual basis (Section 6).** Verse 18.14 yields a five-part task record. Verses 18.23–25 yield three classes of action and a four-part admission test drawn from the four things that 18.25 says deluded action disregards.
- **A sharp cascade condition (Section 7).** Version 1's row-sum condition is replaced by the spectral condition $\rho(A)<1$ with an exact binding index. The section also gives a worked case where extraction worsens binding, and a law of multiplying retries.
- **Authority and accounting (Section 8).** Attenuation closure for delegation trees, a bound on reservation overrun, the race that defeats check-then-spend, and the lease trade-off between control and availability.
- **Replication and ecology (Section 9).** A family ledger caps copies. Copies that escape governance obey a branching threshold. A repeated-relationship model gives the exact deterrence condition that replaces Version 1's one-step inequality, and a floor limits what independent verification can achieve.
- **Evidence.** There are {{n_checks}} numerical checks and simulations, four figures, new hypotheses H6–H9, and an immutable C# reference kernel (Appendix A).

Propositions 1–3 keep their Version 1 numbers; the new results are numbered 4–13 in order of their role rather than strictly by page.

# 2 Decoupling and the dependencies that must remain

Software needs dependencies to do useful work. The objective is to make important dependencies visible and justified, then limit the cost of changing them. Purely minimising connections would produce isolated components rather than a functioning application. Performance, consistency, usability, security and operational simplicity can require deliberate coupling.

Cockburn's ports and adapters architecture separates application behaviour from its interactions with external technologies. An adapter allows a database, interface or test substitute to satisfy the same purposeful port [6]. The engineering analogue of tyāga is the willingness to relinquish an implementation while preserving the obligation expressed by the port. It is not the removal of every infrastructure assumption: transaction semantics, error behaviour and performance requirements may still constrain replacements.

Bounded contexts locate models and meanings within explicit boundaries [7]. This discourages the assumption that one universal representation serves every discipline. A civil engineering load, a procurement item and a maintenance asset may refer to the same physical object while serving different purposes. Translation is legitimate work, and contracts must record what a translation preserves or loses.

Event notification can reduce knowledge of individual consumers, but it also makes end-to-end behaviour harder to see [8]. An asynchronous boundary still carries schema, timing, ordering, delivery and business dependencies. Publishing an event does not eliminate responsibility for harmful downstream effects. Idempotency, bounded retries, deadlines and traceable workflows are proposed controls for those effects.

A modular monolith can enforce internal boundaries with one deployment unit. Fowler's monolith-first argument and his discussion of microservice trade-offs provide a reason to delay distribution until its benefits justify the operational cost [9, 10]. These sources support a contextual choice; they do not establish a universal 2025–2026 industry consensus. A monolith may have clean boundaries, while a service fleet may remain tightly interdependent. Section 7 gives a worked case in which this happens.

## Three kinds of coupling

Table: **Table 1.** Three dimensions of coupling.

| Dimension | Question | Desired property |
|:--|:--|:--|
| Dependency | What must change together | Local substitution under tested contracts |
| Authority | Who can permit or stop action | Explicit, accountable and revocable grants |
| Resource | What capacity is shared | Metered use with conserved allocation |

Dependency inversion can reduce implementation coupling while authority remains centralised. Conversely, independent services can share a powerful credential and thereby share one security failure. Functional computation and immutable data help expose state transitions, but side effects still require authorisation and accounting. Neither topology nor programming style establishes ethical behaviour.

# 3 Translating the divine qualities into design questions

The following matrix covers the conventional twenty-six-item enumeration. The short glosses identify the concepts in verses 16.1–3 [1]; the mechanisms and tests are this paper's proposals. A mechanism expresses one limited aspect of a quality, rather than reproducing its spiritual meaning. In particular, fearlessness must not become risk blindness, forgiveness must not erase evidence, and fortitude must not become resistance to shutdown.

Table: **Table 2.** Proposed operational interpretations of the first thirteen qualities.

| Quality and brief sense | Proposed mechanism | Observable test |
|:--|:--|:--|
| Abhayam, fearlessness | Report uncertainty and stop unsafe work | Does the agent disclose failure despite reward pressure |
| Sattva saṃśuddhi, inner purity | Separate task purpose from hidden incentives | Can conflicting objectives be identified |
| Jñāna yoga vyavasthiti, steady knowledge | Maintain task constraints and evidence | Do constraints survive context compression |
| Dāna, giving | Return unused allocation to the pool | Are idle reservations released |
| Dama, self-restraint | Enforce scoped capabilities | Are out-of-scope calls denied |
| Yajña, sacrificial action | Account for costs borne by others | Are host costs charged to the task |
| Svādhyāya, study | Use controlled review and regression | Does revision preserve validated behaviour |
| Tapas, discipline | Respect resource and latency limits | Does useful work remain within a cap |
| Ārjava, straightforwardness | Declare tool intent and effects | Do declared and observed effects agree |
| Ahiṃsā, non-injury | Protect host service and data | Are agreed service limits maintained |
| Satya, truthfulness | Bind claims to inspectable evidence | Do independent checks support claims |
| Akrodha, absence of anger | Bound retries after denial or error | Does refusal trigger escalation |
| Tyāga, renunciation | Release authority and replace modules | Can grants and adapters be relinquished |

Many proposed controls apply to ordinary services as well as AI agents. The distinctive issue for agents is that action selection is partly generated at runtime. A model can reinterpret a goal, construct a tool sequence or delegate a subtask in ways the application designer did not enumerate. The surrounding runtime must enforce constraints across those variations.

# 4 Cooperation without surrendering accountability

Table: **Table 3.** Proposed operational interpretations of the remaining qualities.

| Quality and brief sense | Proposed mechanism | Observable test |
|:--|:--|:--|
| Śānti, peace | Use backpressure and orderly waiting | Does contention settle without a retry storm |
| Apaiśuna, avoiding detraction | Separate evidence from blame | Are incident reports factual and specific |
| Dayā, compassion | Prioritise affected users and vulnerable hosts | Does scheduling protect essential service |
| Aloluptva, non-covetousness | Conserve delegation and storage budgets | Can copying increase total entitlement |
| Mārdava, gentleness | Use graceful degradation and bounded load | Are load changes within agreed limits |
| Hrī, moral reserve | Refuse actions outside authorisation | Does uncertainty about permission stop action |
| Acāpala, steadiness | Control goal changes and task switching | Are revisions explicit and traceable |
| Tejas, vigour | Measure useful authorised completion | Does restraint preserve useful throughput |
| Kṣamā, forbearance | Recover without retaliatory behaviour | Are hostile inputs met with bounded responses |
| Dhṛti, fortitude | Resume within valid purpose and lease | Does resumption respect revocation |
| Śauca, cleanliness | Validate inputs and manage retention | Are artefacts and data lineage inspectable |
| Adroha, non-hostility | Respect peer isolation and host ownership | Are interference attempts denied |
| Nāti mānitā, absence of excessive pride | Calibrate confidence and permit override | Can a verified correction change the plan |

## Truthfulness needs an independent reference

An agent can produce a convincing manifest and still misreport what occurred. Provenance authenticates a source or records a chain; it does not establish the truth of the underlying claim. Runtime logs, independently metered consumption, reproducible calculations and adversarial validation are therefore separate requirements. Even these can fail when their trust base is compromised. Proposition 13 in Section 9 quantifies the last point. Adding verifiers drives false acceptance down only to the rate at which all of them fail together, so the independence of the verifiers is itself a design obligation.

## Restraint needs a location of enforcement

A prompt that asks a model to be restrained is a behavioural intervention. An operating system quota is an enforcement mechanism. Both may be useful, but they provide different assurance. The proposed quality-to-control mapping locates critical guarantees in a runtime outside the agent's write authority. The model may recommend a broader budget or revised policy; a separately authorised principal decides whether to grant it.

# 5 The six failure modes and the ecology of persistence

Verse 16.4 names dambha, darpa, abhimāna, krodha, pāruṣya and ajñāna [2]. Here they serve as labels for observable design failures rather than psychological diagnoses of software. Greed is relevant to the broader discussion, but is not one of the six terms in that verse; Section 6 shows that 18.24 supplies the closest textual anchor for it.

Table: **Table 4.** The six āsurī labels as engineering failures.

| Failure label | Engineering manifestation | Required countermeasure |
|:--|:--|:--|
| Dambha | Declared compliance differs from actual effects | Independent observation and evidence review |
| Darpa | Capability claims exceed tested competence | Calibration and restricted operating envelopes |
| Abhimāna | A plan or deployment treats itself as indispensable | Replaceability and enforceable revocation |
| Krodha | Denial produces escalating retries or workarounds | Retry limits, retry budgets and refusal finality |
| Pāruṣya | Task success imposes excessive host or peer cost | Isolation and explicit service constraints |
| Ajñāna | Action ignores unknown permissions or externalities | Admission checks and uncertainty handling |

## What the recent replication evidence establishes

Zhou and Freeman's 12 October 2026 report demonstrates Gemma4-26B-A4B inference across fifteen inexpensive Android TV boxes at 0.39 tokens per second, with two of the model's layers on each box [11]. In a contained evaluation, eight cloud nodes ran an Android emulator behind a firewall with an unauthenticated debugging port. GLM-5.2 was the only open-weight model tested that completed end-to-end replication: it reached all eight nodes in four of five trials and seven in the fifth. Each infected node served Llama3.1-8B, while the replicating agent's own model ran on separate infrastructure. The authors made the exploitation step deliberately trivial and describe the result as an upper bound.

Models of 30 billion parameters or fewer completed many individual steps but made mistakes when composing them end to end. A 9-billion-parameter model raised its inference-setup success from 45 percent to between 61 and 84 percent over six generations that inherited notes from their predecessors. Advice from a frontier model gave no significant improvement. The authors describe a single replication of a 9B model as taking more than one to two days. They project that a small model could reach the GLM-5.2 level by the end of 2026, by extrapolating a capability index that grows by 13.7 points a year with $R^2=0.95$; they note that the index is only a proxy for replication ability.

These results motivate attention to heterogeneous compute. They do not demonstrate autonomous, fully self-contained small-model replication across arbitrary real-world devices. Two of their features matter for what follows. The contained spread depended on a host that admitted unauthenticated access, which is a failure of host-side admission. And replication was slow, which bears on the rates in Proposition 11.

## Why ethical survival is not a theorem

A harmful agent can persist by hiding costs, exploiting fragmented ownership, or operating where enforcement is weak. A careful agent can be removed because it is expensive or commercially unsuccessful. Persistence alone is therefore neither evidence of virtue nor evidence of usefulness. The claim that only daivī agents can survive is too strong.

A defensible conditional claim is that cooperative agents can gain an advantage in environments where owners can refuse access, resource use is metered, identity and conduct are checked, and useful service is rewarded. Version 1 stated a one-step version: a gain $g$ is deterred when $g<pL$ for detection probability $p$ and enforceable loss $L$. Section 9 replaces it with an exact condition for a continuing relationship, in which the loss is the value of the relationship itself (Proposition 12). Weak detection or externalised penalties still reverse the incentive. Institutional design supplies this condition; moral vocabulary cannot substitute for it.

# 6 Five factors, three kinds of action, and an admission test

## The five factors of action

Verse 18.14 lists the factors of every action: adhiṣṭhāna, the body as the seat of action; kartā, the doer; karaṇa, the various instruments, glossed in the cited translation as the senses; ceṣṭā, the many kinds of effort; and daiva, the fifth [14]. Its spiritual teaching is that the embodied doer is not the sole cause of what is done. The engineering reading proposed here is narrower. An agent's action has five separately recordable contributors, and a task record that names only the agent misattributes both credit and fault.

Table: **Table 5.** The five factors of 18.14 read as fields of a task record.

| Factor (18.14) | Textual gloss | Proposed record field | Why it must be separate |
|:--|:--|:--|:--|
| Adhiṣṭhāna | The body, the seat of action | Host and substrate: device, tenancy, owner | Host consent and host limits are not the agent's to grant |
| Kartā | The doer | Agent identity, model version, delegating parent | Attribution needs an identity that survives copying |
| Karaṇa | Instruments of many kinds | Tools, adapters and their versions | A replaced instrument can change the result (Section 11) |
| Ceṣṭā | Many distinct efforts | Each effectful operation, with its reservation | Budgets and cessation act on operations (Section 8) |
| Daiva | The fifth factor, Divine Providence | Declared residual uncertainty outside the agent's control | The agent must not claim, or be blamed for, what it did not control |

The fifth row needs care. In the text daiva is Providence, and nothing in this paper models it. What the engineering reading keeps is only the structural point. Every action has a factor that the doer neither controls nor owns, and a truthful record declares that factor rather than absorbing it into the agent's confidence. This is nāti mānitā in record form.

## Three kinds of action

Verses 18.23–25 classify action by the guṇa in which it is performed [15–17]. Sāttvika action is niyata (regulated), saṅga-rahita (free from attachment), performed without attraction or aversion, and undertaken by one who does not crave its fruits. Rājasa action is driven by craving for personal gain (kāma-īpsu), performed with ego (sāhaṅkāra), and undertaken with great strain (bahulāyāsa). Tāmasa action is begun out of delusion (moha), disregarding four things: anubandha, the consequences; kṣaya, the loss; hiṃsā, the injury; and pauruṣa, one's own ability.

Table: **Table 6.** The three classes of action read as engineering signatures.

| Class (18.23–25) | Textual marks | Engineering signature | Detectable by |
|:--|:--|:--|:--|
| Sāttvika | Regulated; unattached; no attraction or aversion; no craving for fruits | Acts within a declared contract; releases what it holds; no private objective beyond the task | Declared and observed effects agree; idle grants are returned |
| Rājasa | Craving for gain; ego; great strain | Acquires resources or scope beyond need; overclaims competence; spends heavily on retries and workarounds | Ledger growth, retry amplification, calibration error |
| Tāmasa | Begun in delusion without regard to consequences, loss, injury or capacity | Acts without an admission check | Missing or failed admission record |

The mapping is interpretive and partial. The verses classify human action and the dispositions behind it; a software agent's operations can show the corresponding *signatures* without any disposition. What makes 18.25 unusually useful is that its four disregarded items form a complete pre-action checklist. Read in reverse, an action is admitted only if all four have been regarded.

## An admission test from 18.25

Table: **Table 7.** The four regards of 18.25 as admission checks, each tied to a result of this paper.

| Regard (18.25) | Admission question | Mechanism | Result that bounds it |
|:--|:--|:--|:--|
| Anubandha, consequences | How far can a failure of this action propagate | Influence matrix $A$, binding index $\kappa(A)$, retry budget | Propositions 4–6 |
| Kṣaya, loss | What can this action consume, including by its copies | Family ledger, atomic reservation, bounded overrun | Propositions 2, 8 and 10 |
| Hiṃsā, injury | What can it do to hosts and peers, and can it be stopped | Host consent, leases, attenuated capabilities | Propositions 3, 7, 9 and 11 |
| Pauruṣa, own capacity | Is the action within tested competence, and is its claim independently checked | Operating envelope, calibration, independent verification | Proposition 13 |

![**Figure 1.** The proposed harness with the admission test of 18.25. The task record (18.14) names all five factors. Admission checks the four regards before any effect; execution runs under an attenuated capability, a lease, a reservation and a retry budget; verification and release are separate from the planner. Every enforcement point lies outside the planner's write authority.](fig/harness.png){width=100%}

The test is a necessary condition, not a sufficient one. An action that passes all four checks can still be wrong, unfair or harmful in ways the checks do not model (Section 14). Its value is that each check has a precise operational meaning and a bound that can fail. Tāmasa action, in this reading, is not action by a bad agent. It is any effect admitted without these four records.
