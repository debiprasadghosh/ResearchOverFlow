"""Assemble paper.md from paper_a/b/c.md and fill every {{...}} from results.json and cs_validate.json."""
from pathlib import Path
import json, re

P = Path(__file__).resolve().parent
src = '\n'.join((P / f).read_text() for f in ('paper_a.md', 'paper_b.md', 'paper_c.md'))
r = json.loads((P / 'results.json').read_text())
cs = json.loads((P / 'cs_validate.json').read_text())
SUP = str.maketrans('-0123456789', '⁻⁰¹²³⁴⁵⁶⁷⁸⁹')


def sci(x):
    if x == 0:
        return '0'
    m, e = f'{x:.2e}'.split('e')
    return f'{m} × 10{str(int(e)).translate(SUP)}'


data = dict(r, cs=cs, n_checks=r['check_count'], cs_max=sci(cs['max_relative_difference']),
            kap_err=sci(r['kappa_err']))


def lookup(path):
    val = data
    for key in path.split('.'):
        val = val[int(key)] if isinstance(val, list) else val[key]
    return val


def fmt(v, f):
    if f == '':
        return f'{v:g}' if isinstance(v, float) else str(v)
    if f == 'd':
        return f'{int(round(v)):,}'
    if f.startswith('f'):
        return f'{v:.{int(f[1:])}f}'
    if f.startswith('pct'):
        return f'{100 * v:.{int(f[3:])}f}%'
    raise ValueError(f)


def short(line):
    head, *nums = line.split()
    vals = [f'{float(x):.6g}' for x in nums]
    body = ', '.join(vals) if len(vals) <= 5 else ', '.join(vals[:4]) + f', … ({len(vals)} values)'
    return head.replace('_', ' '), body


def fill(m):
    body = m.group(1)
    if body.startswith('file:'):
        return (P / body[5:]).read_text().rstrip('\n')
    if body == 'cs_rows':
        return '\n'.join(f'| {short(c)[0]} | {short(c)[1]} | {sci(e)} |' for c, e in zip(cs['csharp'], cs['per_line']))
    path, _, f = body.partition('|')
    return fmt(lookup(path.strip()), f.strip())


out = re.sub(r'\{\{(.+?)\}\}', fill, src)
assert not re.search(r'\{\{', out), 'unfilled placeholder'
(P / 'paper.md').write_text(out)
print('paper.md:', len(out.split()), 'words')
