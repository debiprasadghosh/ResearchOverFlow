# 20 Changing anchor banks and noncommuting reads

The spectral products in Section 11 use one bank and one eigenbasis. Retrieval changes that setting. This section keeps a common calibrated state space and Euclidean metric, but permits different fixed banks within a cycle. It concerns the read operations alone. Backbone feedback is included in Section 21. A change of adapter version or state dimension must first be transported into this common space.

## 20 1 Exact loss of sensitivity across a cycle

For a cycle of length $m$, number reads by $j=1,\ldots,m$ and define

$$A_j=C_j^\top C_j,\quad P_j=(I+\alpha_j A_j)^{-1},\quad T_j=(1-g_j)I+g_jP_j. \tag{40}$$

Here $0\leq g_j\leq1$ and $0\leq\alpha_j<\infty$. Put $\Phi_0=I$, $\Phi_j=T_j\cdots T_1$, and $D_j=I-T_j^2$. A read is active when $g_j\alpha_j>0$. Define $N$ as the intersection of $\ker C_j$ over active reads, with $N=\mathbb R^r$ if there are none. All these are conditional sensitivity operators with the selected banks held fixed.

**Theorem 20.1 (cycle energy and the common private subspace).** The positive semidefinite matrix

$$W_m=\sum_{j=1}^m\Phi_{j-1}^\top D_j\Phi_{j-1}=I-\Phi_m^\top\Phi_m \tag{41}$$

has kernel exactly $N$. Each $T_j$ fixes $N$ pointwise and preserves $N^\perp$. If $N^\perp\neq\{0\}$, define $\kappa_m$ as the smallest eigenvalue of $W_m$ restricted to $N^\perp$. Then

$$\kappa_m>0,\qquad \|\Phi_m|_{N^\perp}\|=\sqrt{1-\kappa_m}<1. \tag{42}$$

In particular, the full cycle is strictly contractive on the whole space exactly when $N=\{0\}$. No commutation assumption is required.

**Proof.** Each $T_j$ is symmetric positive definite with spectrum in $(0,1]$. On an active read its unit eigenspace is $\ker C_j$; an inactive read is the identity. Thus $D_j\succeq0$ and its kernel is the same unit eigenspace. The identity

$$\Phi_{j-1}^\top\Phi_{j-1}-\Phi_j^\top\Phi_j=\Phi_{j-1}^\top D_j\Phi_{j-1}$$

telescopes to (41). If $W_mx=0$, every nonnegative summand in $x^\top W_mx$ is zero. The first summand implies $T_1x=x$; then the second implies $T_2x=x$, and induction gives $T_jx=x$ for every $j$. This is exactly $x\in N$. The converse follows immediately. Symmetry and pointwise fixation of $N$ imply invariance of $N^\perp$. The restriction of $W_m$ to that finite-dimensional space is positive definite. Applying (41) there proves (42). ∎

The theorem distinguishes the private subspace of one read from the private subspace of a cycle. A direction can be invisible to one context and visible to another. The weighted matrix $W_m$ measures sensitivity actually removed along the ordered trajectory. The unweighted sum $\sum_j C_j^\top C_j$ detects the same common kernel, but generally does not give the cycle contraction factor.

**Corollary 20.2 (periodic reads with a common affine fixed point).** Suppose there is a point $p$ satisfying $C_j^\top(C_jp-b_j)=0$ for every active bank. Repeat the cycle with the same gates and strengths. Its common fixed-point set is $p+N$, even if individual observation systems are inconsistent. For $x_0$ arbitrary, let $x_*=p+P_N(x_0-p)$. At cycle boundaries,

$$\|x_{km}-x_*\|\leq(1-\kappa_m)^{k/2}\|P_{N^\perp}(x_0-p)\|. \tag{43}$$

When $N^\perp$ is zero, every read is the identity and $x_*=x_0$. Otherwise all intermediate phases converge to the same $x_*$.

**Proof.** Subtract the normal equation at $p$ from each gated read. Its affine update becomes $x^+-p=T_j(x-p)$. Each active normal-equation solution set is $p+\ker C_j$, so their intersection is $p+N$. The $N$ component is preserved. Apply (42) at each cycle boundary; the intervening contractions cannot increase the error. ∎

The common-point hypothesis is substantive. A sequence of individually well-posed reads need not optimize the sum of their objectives, and its phases need not have one common limit.

**Example 20.3 (two individually consistent banks with a periodic orbit).** Take scalar unit-strength reads for observations 0 and 2. They are $R_0(x)=x/2$ and $R_2(x)=x/2+1$. A cycle in that order maps $x$ to $x/4+1$. Cycle boundaries converge to $4/3$, and the intermediate phase converges to $2/3$. Reversing the order reverses these phases. The joint least-squares minimizer is 1, which is neither phase. Thus a contraction of differences gives a stable periodic response here, while incompatible bank targets prevent convergence to one common compatible state.

## 20 2 Exactly how read order enters

**Proposition 20.4 (resolvent commutator).** For two reads as in (40), write $[A_2,A_1]=A_2A_1-A_1A_2$. Then

$$T_2T_1-T_1T_2=g_1g_2\alpha_1\alpha_2P_2P_1[A_2,A_1]P_1P_2. \tag{44}$$

Consequently $\|T_2T_1-T_1T_2\|\leq g_1g_2\alpha_1\alpha_2\|[A_2,A_1]\|$. If both reads are active, their sensitivity operators commute exactly when their Gram matrices commute. If the affine reads also share a fixed point $p$, the change in output caused by reversing their order is bounded by this operator bound times $\|u-p\|$.

**Proof.** Expanding the two gated products cancels every term except $g_1g_2(P_2P_1-P_1P_2)$. For invertible $X,Y$, direct multiplication gives $X^{-1}Y^{-1}-Y^{-1}X^{-1}=X^{-1}Y^{-1}(XY-YX)Y^{-1}X^{-1}$. Set $X=I+\alpha_2A_2$ and $Y=I+\alpha_1A_1$. Since $\|P_j\|\leq1$, submultiplicativity proves the bound. The invertible factors imply the equivalence when both strengths and gates are positive. Translation by a common $p$ gives the affine claim. ∎

Commuting sensitivities alone do not make affine reads commute. Example 20.3 has commuting scalar sensitivities but incompatible translations. Order tests must therefore compare both linear gains and anchor targets.

## 20 3 Coverage over time needs a quantitative hypothesis

Full coverage somewhere in an infinite history does not guarantee hardening. In $\mathbb R^2$, alternate observations of the two coordinate axes with $g_j=1$ and $\alpha_j=2^{-j}$ for $j\geq1$. Both coordinates are observed infinitely often and the common private subspace is zero. Nevertheless both retained gains have positive limits, because the total spend is finite. This is a changing-bank counterpart of Theorem 11.1. The strict contraction of each finite covering cycle is insufficient if its contraction factors approach one too rapidly.

**Proposition 20.5 (conditional coverage for adaptive random banks).** Let $T_t$ have the read-sensitivity form (40), and let $e_{t+1}=T_te_t$, where $e_t$ is known from the history $\mathcal F_t$ before bank selection. Suppose a fixed subspace $N$ is fixed pointwise by every $T_t$, its orthogonal complement is preserved, and for a constant $0<\kappa\leq1$,

$$\mathbb E[I-T_t^2\mid\mathcal F_t]\succeq\kappa P_{N^\perp}. \tag{45}$$

Then $\mathbb E\|P_{N^\perp}e_t\|^2\leq(1-\kappa)^t\|P_{N^\perp}e_0\|^2$ for deterministic $e_0$, and that component converges to zero almost surely. The component in $N$ is unchanged.

**Proof.** Condition on $\mathcal F_t$ and apply (45) to the history-measurable vector $P_{N^\perp}e_t$. Taking expectations and iterating gives the mean-square bound. For any $\varepsilon>0$, Markov's inequality bounds $\Pr(\|P_{N^\perp}e_t\|>\varepsilon)$ by a summable geometric sequence. The first Borel--Cantelli lemma, followed by countably many positive rational $\varepsilon$, proves almost-sure convergence. ∎

This result permits selection probabilities to depend on the current prefix. It requires conditional coverage in every remaining direction, not merely a favourable unconditional average across queries. A deterministic retriever that repeatedly selects the same narrow subspace can violate it. A common affine fixed point is still required to interpret $e_t$ as error to a fixed target.

# 21 Quantitative mixing and error accumulation

## 21 1 A finite horizon certificate for orthogonal feedback

V4 characterized the exact obstruction to a stability margin under orthogonal feedback. We now quantify the margin using a finite horizon. This is an application of the observability framework [17] to the dissipative read; the identities and their hypotheses are given explicitly.

Let $J=(I+\alpha C^\top C)^{-1}$ with $\alpha>0$, let $Q$ be orthogonal, and set $L=JQ$. Write $D=I-J^2$. For a horizon $m$, define

$$\mathcal W_m=\sum_{t=0}^{m-1}(L^t)^\top Q^\top DQ L^t=I-(L^m)^\top L^m. \tag{46}$$

**Theorem 21.1 (finite horizon mixing margin).** Put $\kappa_m=\lambda_{\min}(\mathcal W_m)$. Then $0\leq\kappa_m<1$ and

$$\|L^m\|=\sqrt{1-\kappa_m},\qquad \rho(L)\leq(1-\kappa_m)^{1/(2m)}. \tag{47}$$

Moreover,

$$\ker\mathcal W_m=\bigcap_{j=1}^m\ker(CQ^j). \tag{48}$$

In state dimension $r$, the following statements are equivalent: $\rho(L)<1$; $\kappa_r>0$; and no nonzero $Q$-invariant subspace is contained in $\ker C$. Thus a horizon of at most $r$ suffices to decide the existence of a margin in exact arithmetic. Computing its useful size still requires the eigenvalue in (46).

**Proof.** Since $I-L^\top L=Q^\top DQ$, telescoping gives (46). The matrix $L$ is invertible and a contraction, so (47) and $0\leq\kappa_m<1$ follow from singular values and $\rho(L)^m\leq\|L^m\|$. A vector lies in the kernel of (46) exactly when none of the first $m$ steps loses norm. At each such step $QL^tx\in\ker D=\ker C$, so $JQx=Qx$ at the first step, and inductively $L^tx=Q^tx$. The zero-loss conditions are therefore exactly $CQ^jx=0$ for $j=1,\ldots,m$, proving (48).

For completeness, the kernel of the stack $C,CQ,\ldots,CQ^{r-1}$ is $Q$-invariant by Cayley--Hamilton, and is the largest such subspace contained in $\ker C$. Orthogonality makes $Q$ invertible, so the stack starting with $CQ$ instead has the same kernel. Hence (48) at $m=r$ is zero exactly when that invariant subspace is zero. A positive $\kappa_r$ implies $\rho(L)<1$ by (47). Conversely a nonzero invariant subspace is acted on by $L$ as by $Q$, and therefore supplies a unit-modulus eigenvalue over the complexification. This proves all equivalences. ∎

The proof concerns one fixed feedback matrix and read. Spectral-radius estimates at isolated nonlinear states do not imply a uniform trajectory certificate. For nonorthogonal feedback, the first inequality $\|L\|\leq1$ can fail and the energy argument must be replaced by a suitable Lyapunov metric or an independently proved block contraction.

## 21 2 An exact two dimensional example

**Proposition 21.2 (rotation through one private direction).** Let $J=\operatorname{diag}(a,1)$ with $0<a<1$, and let $Q$ be a planar rotation through angle $\theta$. Put $h=1-a^2$ and $\tau=h(2-h\cos^2\theta)$. Then

$$\kappa_2=\frac{\tau-\sqrt{\tau^2-4h^2\sin^2\theta}}{2}. \tag{49}$$

Thus $\kappa_2>0$ exactly when $\sin\theta\neq0$. As $\theta\to0$, $\kappa_2\sim(1-a^2)\theta^2/(1+a^2)$. At $\theta=\pi/2$, $L^2=-aI$ and the radius bound in (47) is exact: $\rho(L)=\sqrt a$.

**Proof.** With $c=\cos\theta$ and $s=\sin\theta$, the two loss rows are $(c,-s)$ and $(ac^2-s^2,-(a+1)cs)$. Their determinant is $-s$. Equation (46) is $h$ times their Gram matrix, which has trace $\tau$ and determinant $h^2s^2$. The quadratic formula gives (49). For small $\theta$, the smaller eigenvalue is asymptotic to determinant divided by trace, giving the stated expression. Direct multiplication at a right angle gives $L^2=-aI$. ∎

This example gives a quantitative interpretation of mixing. Merely having a nonzero angle establishes stability in this surrogate, but a very small angle yields a margin only of order $\theta^2$. A positive rank test can therefore coexist with an impractically slow decay rate. Figure 6 compares the spectral radius and the certified two-step bound.

![](fig/fig6_mixing.png){width=90%}

**Figure 6.** Exact spectral radius of $JQ$, its two-step upper bound, and the smallest eigenvalue of the loss Gramian for $J=\operatorname{diag}(0.25,1)$. All curves are finite-dimensional calculations, not trained-model measurements.

## 21 3 Tracking a changing target with inexact reads

**Theorem 21.3 (block contraction with drift and implementation error).** Suppose $\|T_t\|\leq1$ and every consecutive block of $m$ steps satisfies $\|T_{t+m-1}\cdots T_t\|\leq q<1$. Consider

$$x_{t+1}=T_tx_t+(I-T_t)p_t+\epsilon_t,\quad v_t=x_t-p_t. \tag{50}$$

Let $a_t=\|p_{t+1}-p_t\|+\|\epsilon_t\|$. At block boundaries,

$$\|v_{km}\|\leq q^k\|v_0\|+\sum_{j=0}^{k-1}q^{k-1-j}\sum_{i=jm}^{(j+1)m-1}a_i. \tag{51}$$

If $a_t\leq\bar a$, the limit superior of $\|v_t\|$ is at most $m\bar a/(1-q)$. If $a_t\to0$, then $v_t\to0$.

**Proof.** Subtract $p_{t+1}$ from (50), obtaining $v_{t+1}=T_tv_t+(p_t-p_{t+1})+\epsilon_t$. Expand over a block. Its homogeneous term contracts by $q$ and each propagated disturbance is bounded by its norm because the remaining factors are contractions. Iterate that scalar block inequality to obtain (51). The same argument applies to each of the $m$ possible starting phases. A bounded forcing gives the geometric-series limit, and a forcing that tends to zero gives zero by splitting the convolution into a finite early part and a uniformly small tail. ∎

The target $p_t$ is a declared fixed point of the intended affine read at that step. Its drift includes changes of bank meaning, not just numerical noise. With a common private subspace, apply the theorem on its orthogonal complement; no contraction of arbitrary disturbances in the private subspace is promised. For the fixed orthogonal-feedback loop, use $T_t=L$ and $q=\sqrt{1-\kappa_m}$ from (47), after translating by the loop's common fixed point.

For a quadratic solve, (37) supplies $\|\epsilon_t\|\leq\|H_t\widehat z_t-h_t\|/\mu_t$ before any output-adapter amplification. Anchor perturbations can instead be bounded by (20) or (29). If an embedding adapter $D$ and gate $g$ follow the solve, their contribution is multiplied by $g\|D\|$. These explicit factors turn a tolerance into a trajectory budget. A small per-read error can still produce a large long-run tube when $q$ is near one.

# 22 Clean curvature sharpens robust corruption bounds

The uniform bound (29) uses only prior curvature $\mu I$. V4 identified this as a source of slack. For fixed maps, endpoint information gives a sharper certificate without assuming a constant active set along the full segment.

## 22 1 An exact secant equation

Let $z=R_b^H(u)$ and $z'=R_{b'}^H(u)$, with $b$ and $b'$ differing only on $S$. Write $d=z'-z$ and $r_i=c_i^\top z-b_i$. Define

$$\omega_i=\begin{cases}\dfrac{\psi_\delta(r_i+c_i^\top d)-\psi_\delta(r_i)}{c_i^\top d},&c_i^\top d\neq0,\\0,&c_i^\top d=0.\end{cases} \tag{52}$$

The value zero in the second case is a convention; any number in $[0,1]$ gives the same secant product. Monotonicity and unit Lipschitz continuity of $\psi_\delta$ give $0\leq\omega_i\leq1$. Let $\Omega=\operatorname{diag}(\omega_i)$.

**Lemma 22.1 (exact robust secant).** The displacement satisfies

$$[\mu I+\beta C^\top\Omega C]d=\Delta,\quad \Delta=\beta\sum_{i\in S}c_i\{\psi_\delta(c_i^\top z'-b_i)-\psi_\delta(c_i^\top z'-b_i')\}. \tag{53}$$

**Proof.** Subtract the two stationarity equations. First compare the gradient for bank $b$ at $z'$ and $z$. The componentwise secants in (52) give its exact difference as $[\mu I+\beta C^\top\Omega C]d$. The gradient for bank $b'$ vanishes at $z'$, so the remaining gradient difference at that point is exactly the displayed $\Delta$. ∎

The matrix in (53) is an averaged curvature, not the Hessian evaluated only at one endpoint. Saturation can change between endpoints; the identity still holds.

## 22 2 A certificate from clean endpoint residuals

**Theorem 22.2 (clean curvature certificate).** Choose $I\subseteq S^c$ such that $|c_i^\top z-b_i|\leq\delta$ and $|c_i^\top z'-b_i|\leq\delta$ for every $i\in I$. Put $H_I=\mu I+\beta\sum_{i\in I}c_ic_i^\top$. Then

$$\|d\|_{H_I}\leq2\beta\delta\sum_{i\in S}\sqrt{c_i^\top H_I^{-1}c_i}, \tag{54}$$

and, in particular,

$$\|d\|\leq\frac{2\beta\delta\sum_{i\in S}\|c_i\|}{\mu+\beta\lambda_{\min}(\sum_{i\in I}c_ic_i^\top)}. \tag{55}$$

The Euclidean certificate improves (29) whenever the retained clean rows have strictly positive minimum curvature.

**Proof.** A scalar residual is affine along the segment joining $z$ and $z'$. The two clean endpoint conditions therefore keep that residual in the Huber quadratic region throughout the segment. For such a row its score difference is exactly $c_i^\top d$, including when that difference is zero. Monotonicity of every other row gives $d^\top H_Id\leq d^\top\Delta$. Dual Cauchy--Schwarz and the score bound $2\delta$ imply (54). Alternatively the same inequality gives $\lambda_{\min}(H_I)\|d\|^2\leq\|d\|\|\Delta\|$, with $\|\Delta\|\leq2\beta\delta\sum_{S}\|c_i\|$, proving (55). The zero-displacement case is immediate. ∎

The theorem does not infer a clean set from small residuals alone. The set $I$ is assumed uncorrupted in the comparison. In a controlled corruption study that set is known. In deployment it requires an external trust criterion, or it remains a conditional certificate.

**Corollary 22.3 (certified use of approximate endpoints).** Suppose stationarity certificates give $\|\widehat z-z\|\leq e$ and $\|\widehat z'-z'\|\leq e'$. A known clean row belongs to a valid set $I$ if

$$|c_i^\top\widehat z-b_i|+\|c_i\|e\leq\delta,\quad |c_i^\top\widehat z'-b_i|+\|c_i\|e'\leq\delta. \tag{56}$$

The exact-solution bounds then apply, and a bound on $\|\widehat z'-\widehat z\|$ is obtained by adding $e+e'$.

**Proof.** Apply the triangle inequality to each endpoint residual and then apply Theorem 22.2. A second triangle inequality accounts for the two endpoint errors. ∎

**Example 22.4 (a factor of twenty-five in the denominator).** In two dimensions, take eight clean copies of each coordinate row and two further coordinate rows whose anchor values change from $(-100,-100)$ to $(100,100)$. With $u=0$, $\mu=1$, $\beta=3$ and $\delta=0.5$, the two reads are $(-0.06,-0.06)$ and $(0.06,0.06)$. All sixteen clean residuals stay within the quadratic region. The displacement is $0.12\sqrt2$, approximately 0.169706. The universal bound (29) is 6, whereas (55) is $6/25=0.24$. The improvement comes from verified clean curvature; it does not change the worst-case sharpness of (29).

# 23 Robust consolidation with a uniform approximation guarantee

The quadratic statistics in Section 13 cannot preserve all Huber reads. A more restricted family of future queries nevertheless admits an explicit and useful robust summary. Fix the branch, eligibility group, calibrated restriction rows and adapter version. The summary below approximates observation values and retains their multiplicities.

## 23 1 Stability under quantizing observation values

**Theorem 23.1 (uniform robust read approximation).** Keep $C$, $\delta>0$, $\mu>0$ and $\beta\geq0$ fixed. Replace $b$ by $\widetilde b$ with $|b_i-\widetilde b_i|\leq\varepsilon_i$. For every proposal $u$,

$$\|R_b^H(u)-R_{\widetilde b}^H(u)\|\leq\frac{\beta}{\mu}\sum_i\|c_i\|\min(\varepsilon_i,2\delta). \tag{57}$$

Thus the same bound holds uniformly over all $u\in\mathbb R^r$. Weighted observations use their nonnegative weights in the sum. Over a query family $\mu\geq\mu_{\min}>0$ and $0\leq\beta\leq\beta_{\max}$, replace $\beta/\mu$ by $\beta_{\max}/\mu_{\min}$.

**Proof.** At the solution for $\widetilde b$, the gradient of the objective for $b$ differs from zero only through the Huber scores. A score difference is at most $|b_i-\widetilde b_i|$ by unit Lipschitz continuity, and at most $2\delta$ by boundedness. Bound the norm of the gradient by the stated sum and use $\mu$-strong monotonicity, as in Theorem 12.1. The bound contains no $u$. Nonnegative weights scale the same gradient argument. ∎

**Corollary 23.2 (histograms for a finite restriction dictionary).** Suppose each row belongs to a declared dictionary $c^{(1)},\ldots,c^{(K)}$, all $b_i\in[-B,B]$, and observation values are rounded to bins of width at most $h$. Store, for each dictionary row and bin, its multiplicity $n_{k\ell}$ and bin centre $y_\ell$. The compressed robust read minimizes

$$\frac{\mu}{2}\|z-u\|^2+\beta\sum_{k,\ell}n_{k\ell}\rho_\delta((c^{(k)})^\top z-y_\ell). \tag{58}$$

It equals the read of the quantized full bank exactly and approximates the original read with error at most $\beta h\sum_i\|c_i\|/(2\mu)$. The number of possible counts is $O(K(1+B/h))$, independently of the number of observations. Only occupied bins need be stored.

**Proof.** All observations in one row-bin pair have the same quantized residual, so their losses sum to the count times one loss. The quantization error is at most $h/2$; apply (57). The interval of length $2B$ requires at most $1+\lceil2B/h\rceil$ bins. ∎

The counts in this complexity statement are numbers, whose bit length can grow as $O(\log n)$ for a bank of size $n\text{.}$ For fixed worst-case state error $\eta$ with unnormalised unit weights, one needs $h\leq2\mu\eta/(\beta\sum_i\|c_i\|)$, so the required number of bins can grow with $n$. A bank-size-independent summary at fixed error is obtained, for example, when the total observation weight is normalised and dictionary norms are bounded. Multiplicity records optimization weight; it does not establish statistical independence or evidential confidence.

The data range assumption matters. Arbitrarily unbounded observations cannot all be assigned bounded-width bins in a fixed finite range. Likewise, arbitrary future changes to the restriction rows, provenance filters or individual retrieval choices are not supported by one histogram. Consolidate within eligibility groups that future queries can select intact. Keep replayable provenance separately when individual audits or deletions are required.

## 23 2 Quantizing the restriction rows as well

**Theorem 23.3 (uniform approximation when rows and values move).** Let nonnegative observation weights sum to at most $M$. Assume $\|c_i\|\leq L_0$, $\|\widetilde c_i-c_i\|\leq e_C$, $|\widetilde b_i-b_i|\leq e_b$, and restrict proposals to $\|u\|\leq U$. Keep a fixed Huber threshold $\delta>0$ and allow $\mu\geq\mu_0>0$, $0\leq\beta\leq\beta_0$. Put

$$Z=U+\frac{\beta_0\delta M(L_0+e_C)}{\mu_0}. \tag{59}$$

The two robust reads, with the same weights and parameters, satisfy uniformly over this query family

$$\|R_{C,b}^H(u)-R_{\widetilde C,\widetilde b}^H(u)\|\leq\frac{\beta_0M}{\mu_0}\{\delta e_C+(L_0+e_C)(Ze_C+e_b)\}. \tag{60}$$

Consequently compact restriction families and bounded observation ranges admit finite row-value quantizations with uniform read-state error tending to zero as the mesh tends to zero. Identical quantized row-value pairs may be consolidated by adding their weights.

**Proof.** Stationarity and the bounded Huber score give $\|R_{\widetilde C,\widetilde b}^H(u)\|\leq Z$. At that point, the gradient contribution from one observation changes by at most its weight times $\beta[\delta e_C+(L_0+e_C)(Ze_C+e_b)]$. To see this, separate the change of the vector multiplying the score from the change of the score itself. The first is at most $\delta e_C$; unit Lipschitz continuity of the score bounds the second by $(L_0+e_C)(Ze_C+e_b)$. Sum the contributions and apply the original objective's $\mu$-strong monotonicity. Compactness supplies finite row nets and bounded-width value bins. Their exact grouping preserves the quantized objective. ∎

The bounded proposal set is needed for this row-perturbation argument: a small change of row direction can create a large residual change at a large state. The lower bound on prior curvature and the bound on total observation weight are likewise explicit. Equation (60) is a sufficient error bound; it does not claim optimal summary size.

## 23 3 What the approximation buys

The exact quadratic summary uses three polynomial coefficients; the robust histogram retains a distribution of observations at declared precision. Theorems 13.1 and 23.1 therefore answer different storage questions. The former is exact over all quadratic-read parameters in one group. The latter supplies a uniform read-state error for a constrained robust query family. Neither implies that compressed latent anchors preserve every future reasoning task.

If the resulting read is fed into a contractive loop, Theorem 21.3 converts the per-read bound in (57) into a trajectory error budget. A controller should choose $h$ from that budget rather than from a desired compression ratio alone. If no contraction is certified, (57) remains a one-read guarantee and must not be advertised as a long-run bound.

# 24 Task specific coverage and remaining mathematical questions

## 24 1 Residuals certify only identifiable quantities

A full-state distance certificate can be stronger than a task needs. Conversely a small residual says nothing about a task quantity that varies freely along the private subspace. The following result makes the distinction exact for linear quantities.

**Theorem 24.1 (task identifiability and an optimal residual constant).** Let $C$ be any real matrix and let $\ell\in\mathbb R^r$. The scalar task $\ell^\top x$ is determined by $Cx$ for every $x$ exactly when

$$\ell\in\operatorname{im}C^\top,\quad\text{equivalently}\quad\ell\perp\ker C. \tag{61}$$

In that case let $y_*=(C^\dagger)^\top\ell$, the minimum-norm solution of $C^\top y=\ell$. Put $\eta=(I-CC^\dagger)b$ and choose any least-squares solution $p\in C^\dagger b+\ker C$. Then

$$|\ell^\top(z-p)|\leq\|y_*\|\sqrt{\|Cz-b\|^2-\|\eta\|^2}. \tag{62}$$

The constant $\|y_*\|$ is the smallest possible uniform constant. If (61) fails, no finite residual-only constant controls this task error, even for a consistent bank.

**Proof.** If $C^\top y=\ell$, then $\ell^\top x=y^\top Cx$, proving identifiability. If $\ell$ has a nonzero component in $\ker C$, choose $q$ in that kernel with $\ell^\top q\neq0$. The states $x+tq$ have identical observations and arbitrarily different task values. This also proves necessity and the impossibility claim. Under (61), $\ell^\top(z-p)=y_*^\top C(z-p)$. Apply Cauchy--Schwarz and the orthogonal decomposition (21) to obtain (62). The vector $y_*$ belongs to $\operatorname{im}C$; choosing $C(z-p)$ proportional to $y_*$ attains equality whenever $\ell\neq0$. For $\ell=0$ the optimal constant is zero. ∎

**Corollary 24.2 (a task aware class margin).** Suppose a linear decoder has score differences $\ell_j^\top z+\nu_j$ between the current winning class and each competitor. If every $\ell_j$ satisfies (61), and each current score margin exceeds its right-hand side in (62), the winning class is unchanged by projection onto the least-squares affine set. This can improve the generic $2K/\sigma_{\min}^+(C)$ criterion because it uses the actual task directions. It remains a certificate of prediction stability under the declared constraints, not answer correctness.

**Proof.** Apply (62) to each pairwise score difference. Every strictly positive margin remains positive at the projected state. ∎

**Proposition 24.3 (sharp worst-case task estimation from noisy anchors).** Under (61), observe $b=Cx+e$ with $\|e\|\leq\varepsilon$. Among all estimators of $\ell^\top x$, allowing arbitrary $x\in\mathbb R^r$, the smallest worst-case absolute error is

$$\varepsilon\|(C^\dagger)^\top\ell\|. \tag{63}$$

The linear estimator $y_*^\top b$ attains it. If (61) fails, the worst-case error is unbounded even at $\varepsilon=0$.

**Proof.** The displayed estimator has error $|y_*^\top e|\leq\varepsilon\|y_*\|$. For $y_*\neq0$, take $x_\pm=\pm\varepsilon C^\dagger y_*/\|y_*\|$ and $e_\pm=-Cx_\pm$. Both admissible worlds produce $b=0$, but their task values are $\pm\varepsilon\|y_*\|$, because $CC^\dagger y_*=y_*$. Any estimator at that observation errs by at least that amount in one world. The zero-task case is immediate. The private-direction construction in Theorem 24.1 proves the remaining claim. ∎

The estimator result assumes a true linear observation model and a deterministic noise bound. A posterior covariance or a confidence interval requires additional probabilistic assumptions. Inconsistent pinned anchors need not satisfy that model at any small $\varepsilon$.

## 24 2 Consequences for the proposed implementation

Changing banks now have a precise common private subspace and a finite-cycle certificate, but adaptive retrieval still needs a uniform window or conditional-coverage hypothesis. It must also preserve branch eligibility. Adding enough rows to obtain full rank can stabilize a wrong computation if those rows describe incompatible worlds.

The robust histogram gives an implementable answer to one of Section 15's open tasks: store typed row-bin counts and certify their read error over the stated query family. Theorem 23.3 also permits a quantized restriction dictionary under bounded queries. The remaining problem is to choose or learn a small dictionary without destroying task-relevant identifiability. The uniform state-error estimate controls the read operator but does not establish that its learned contexts are semantically valid.

**Conjecture H8 (coverage guided retrieval).** At matched branch-admissible retrieval and backbone budgets, choosing anchors to improve a finite-window loss Gramian should yield more reliable sensitivity control than maximizing cosine similarity alone. The algebra predicts the conditional sensitivity change, while improvement in verified reasoning accuracy remains an empirical claim. Test both outcomes separately; failure of the accuracy claim does not refute (41).

## 24 3 Reproducibility and scope of Version 5

Version 5 adds a self-contained validation script for the new finite-dimensional results. It verifies exact identities, sharp examples, kernel dimensions, contraction bounds, robust solver certificates, histogram approximation and task-estimation lower bounds. The results are summarized in Table 6. The supplied V4 NumPy script is also rerun against its archived C# output. No new C# execution or model training is required for these checks. The source archive retains the C# project and all supplied V4 figure assets.

TABLE6_PLACEHOLDER

The V4 source archive reports 53 older checks but does not contain their two separate legacy scripts. Those historical examples are retained with that provenance; the current runnable verification consists of the supplied 25-result comparison and the new V5 suite. Exact proofs remain the basis of the mathematical claims. Floating-point checks can expose implementation errors, but cannot replace the stated assumptions or establish semantic correctness.
