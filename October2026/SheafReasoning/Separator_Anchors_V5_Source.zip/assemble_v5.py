"""Assemble the V5 manuscript from the retained V4 source and proved extensions."""
from pathlib import Path
import re
import json
import subprocess

P=Path(__file__).resolve().parent
s=(P/'v4_baseline.md').read_text().split('# Appendix A. The immutable C# kernel')[0]
s=s.replace('20 October 2026 · Version 4 · Mathematical research paper','22 October 2026 · Version 5 · Mathematical research paper')
start=s.index('# Abstract'); end=s.index('# 1. Why')
abstract=r'''# Abstract

Separator hidden states provide compact observations for continuous latent reasoning, but their shared coordinates and admissible combinations need an explicit model. We attach a causal observation star to Sep-Latent: past separator anchors are pinned observations, and only the current proposal is corrected through typed linear restrictions. The resulting metric proximal read has a unique solution and preserves its private subspace. This paper develops that interface within Autoregressive Sheaf Evolution, retaining the distinction between horizontal contexts, vertical layer diagrams and reasoning time.

We extend the fixed-bank theory to changing, noncommuting banks. An exact telescoping loss matrix identifies the private subspace of an entire read cycle and its contraction factor. A resolvent commutator quantifies order dependence, while an incompatible-bank example converges to two phases rather than to the joint least-squares solution. For orthogonal backbone feedback, a finite-horizon observability condition quantifies how mixing can dissipate private error; in two dimensions the small-angle margin is quadratic. A tracking theorem propagates target drift and numerical error through certified contraction windows. For robust reads, clean endpoint residuals certify additional curvature and sharpen corruption bounds. Histogram summaries give uniform read-state approximation for fixed restriction dictionaries; a separate theorem permits quantized restrictions on bounded query families. Finally, task-specific identifiability yields a sharp residual constant and an exact worst-case estimation error under bounded observation noise.

All proofs concern the stated finite-dimensional models. Compatibility does not certify semantic correctness. Forty new numerical checks exercise the identities and counterexamples, and the supplied NumPy comparison reproduces all 25 archived C# results. No model training or benchmark improvement is claimed. The proposed experiments test whether typed partial gluing improves verified reasoning under matched computation and retrieval budgets.

**Scope of Version 5.** Sections 20–24 add sixteen proved results and a coverage-guided retrieval conjecture. The revision corrects the domain of the schedule asymptotics in Corollary 19.2, distinguishes historical checks from currently runnable verification, and retains the implementation and empirical programme of the earlier manuscript.

'''
s=s[:start]+abstract+s[end:]

# Correct two mathematical scope claims identified during the audit.
s=s.replace('Put $\\alpha_j=c(j+1)^{-p}$ with unit gates,','Put $\\alpha_j=c(j+1)^{-p}$ with $c>0$ and $p>0$, using unit gates,')
s=s.replace('For $p<1$, $\\log\\gamma_N(\\lambda)$','For $0<p<1$, $\\log\\gamma_N(\\lambda)$')
s=s.replace('For $p<1$ the second sum has lower order than the first.','For $0<p<1$ the second sum has lower order than the first. The case $p=0$ instead has exact gain $(1+c\\lambda)^{-N}$ and is excluded from this asymptotic statement.')
s=s.replace('and $p<1$ hardens almost completely within about a hundred reads.','and $0<p<1$ gives faster-than-power decay. The near-complete hardening within about a hundred reads refers only to the plotted $c=0.5$, $\\lambda=1$, $p=1/2$ example.')
s=s.replace('The difference does not grow, because insertions only increase the Hessian, so the stored inverse contracts.','The difference does not grow in this experiment. Exact insertions increase the Hessian and contract its inverse, but that monotonicity alone is not a floating-point drift guarantee.')

# Preserve provenance without claiming absent legacy scripts were rerun in V5.
s=s.replace('The attached V2 source was rerun before revision. All 21 of its checks passed. This revision retains those reproducible examples and adds 32 checks, for 53 passing checks in total.',
'''Version 3 reported rerunning 21 V2 checks and adding 32 further checks, for 53 passing historical checks. Version 4 retained those examples. Their reported outcomes are preserved below, while Section 24.3 identifies the verification scripts available and rerun for Version 5.''')
s=s.replace('The new script uses float64, NumPy 2.3.5 and seed 20261021;','The Version 3 script was reported to use float64, NumPy 2.3.5 and seed 20261021;')
s=s.replace('The 32 new checks cover','Those 32 historical checks cover')
s=s.replace('Three mathematical tasks remain before a stronger implementation claim. First, characterize identifiability of learned restrictions under answer supervision and explicit interventions; Theorem 9.2 already exhibits a coordinate ambiguity, while zero-map collapse exhibits a worse degeneracy. Second, extend the spectral spending criterion to changing, noncommuting banks without pretending that one fixed private subspace survives. Third, derive robust consolidation summaries with an explicit error guarantee over an identified family of future queries. Proposition 13.3 rules out only the three quadratic statistics, not that broader programme.',
'''Three tasks motivated the extension. Identifiability of learned restrictions under answer supervision and explicit interventions remains open; Theorem 9.2 exhibits coordinate ambiguity, while zero-map collapse is a worse degeneracy. Section 20 now treats noncommuting bank cycles and conditional random coverage, while a general necessary-and-sufficient criterion for arbitrary infinite bank schedules remains open. Section 23 provides robust consolidation guarantees for stated query families, including bounded perturbations of restriction rows. Proposition 13.3 continues to rule out exact robust consolidation into only the three quadratic statistics.''')

extra=(P/'extensions.md').read_text()
res=json.loads((P/'v5_results.json').read_text())
val={x['name']:x.get('value') for x in res['checks']}
metrics=res['metrics']; hist=metrics['histogram']; clean=metrics['clean_curvature']
table='''**Table 6.** Selected outcomes of the 40 new checks, using float64, NumPy '''+res['numpy']+''' and seed 20261022. Random-trial counts are given separately from the number of named checks.

| Result | Numerical outcome | Verification |
|:--|:--|:--|
'''
rows=[
('Changing-bank loss identity',f"{val['cycle_energy_identity_80_trials']:.2e} maximum error",'80 noncommuting cycles'),
('Resolvent commutator',f"{val['resolvent_commutator_80_trials']:.2e} maximum error",'80 random pairs'),
('Feedback loss identity',f"{val['mixing_gramian_identity_60_trials']:.2e} maximum error",'60 orthogonal feedbacks'),
('Right-angle feedback radius','0.5 with equality in the bound','Exact two-dimensional example'),
('Clean robust curvature',f"{clean['measured']:.6f} measured; 0.24 refined; 6 universal",'Certified clean endpoint rows'),
('Robust histogram',f"{hist['rows']} rows to {hist['occupied_bins']} occupied bins",'30 proposal queries'),
('Histogram state error',f"{hist['max_measured_shift']:.6f} maximum; {hist['certified_bound']:.6f} bound",'Uniform theorem checked on the query sample'),
('Moving restriction rows',f"{metrics['moving_rows']['max_measured_shift']:.6f} maximum; {metrics['moving_rows']['certified_bound']:.6f} bound",'20 bounded proposal queries'),
('Task residual constant','Equality in the constructed example','Includes an inconsistent bank and minimax lower bound')]
for row in rows:table+='| '+' | '.join(row)+' |\n'
extra=extra.replace('TABLE6_PLACEHOLDER',table)
s=s.replace('# References',extra+'\n\n# References',1)
s+='''
\\[17\\] Boyd, S. (2008). *Observability and State Estimation.* Lecture 19, EE263 Introduction to Linear Dynamical Systems, Stanford University, Autumn 2008–09. Especially the finite-horizon observation matrix, Cayley–Hamilton criterion and invariant unobservable subspace. https://ee263.stanford.edu/archive/observ.pdf

# Appendix A Reproducible source guide

The companion archive contains the manuscript source, complete C# project, build scripts and all six figures. `validate_v5.py` runs the 40 new checks. `cs_validate.py` recomputes 25 supplied results and compares them with the archived C# output; it does not execute C#. `extensions.md` contains the added proofs, while `v4_baseline.md` preserves the input text. `README.md` gives the build order and environment details.\n'''

s=s.replace('Appendix A lists the code.', 'Appendix A identifies the complete code in the source archive.')
s=s.replace('Appendix A describes termination through', 'Appendix A of [1] describes termination through')

# Fixed-width Markdown table columns must be parsed before changing TeX lengths.
def pipe_table(match):
    result=subprocess.run(['pandoc','-f','markdown+tex_math_dollars','-t','gfm+tex_math_dollars'],input=match[0],text=True,capture_output=True,check=True)
    return result.stdout.rstrip()
s=re.sub(r'^ {2}-{5,}\n.*?^ {2}-{5,}\s*$',pipe_table,s,flags=re.M|re.S)

# Repair inherited notation artifacts without changing the mathematical model.
for old,new in [
    (r'\mathcal{l +}1',r'\ell+1'),(r'\mathcal{l + 1}',r'\ell+1'),
    (r'\mathcal{,l}',r',\ell'),(r'\mathcal{l}',r'\ell'),
    (r'\mathcal{L =}',r'\mathcal{L} ='),(r'\mathcal{S =}',r'\mathcal{S} ='),
    (r'\mathcal{,S}',r',\mathcal{S}'),('cokerC',r'\operatorname{coker} C'),('cokerB',r'\operatorname{coker} B'),('kerC',r'\ker C'),('imC',r'\operatorname{im} C'),
    ('dist\\left',r'\operatorname{dist}\left'),('argmin',r'\operatorname{argmin}')
]: s=s.replace(old,new)

# Plain descriptive headings, with number components separated by spaces.
def heading(m):
    text=m[2]
    text=re.sub(r'^(\d+)\.(\d+)\s+',r'\1 \2 ',text)
    text=re.sub(r'^(\d+)\.\s+',r'\1 ',text)
    text=text.replace('Sep-Latent','Sep Latent')
    text=text.replace('Stalks are data spaces; anchors are observations','Stalks are data spaces and anchors are observations')
    return m[1]+text
s=re.sub(r'^(#{1,2} )(.+)$',heading,s,flags=re.M)
(P/'paper.md').write_text(s)
print('Assembled V5',len(s.split()),'whitespace-separated words')
