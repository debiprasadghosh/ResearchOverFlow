---
title: "Separator Anchors for Sheaf Based Latent Reasoning"
subtitle: Mathematical foundations and implementation within Autoregressive Sheaf Evolution
author:
  - Debi Prasad Ghosh
date: 20 October 2026 · Version 4 · Mathematical research paper
---

# Abstract

Continuous latent reasoning offers a useful implementation substrate for Autoregressive Sheaf Evolution (ASE), but continuity alone does not supply a sheaf. Sep-Latent compresses explicit reasoning into separator hidden states and trains an implicit path to continue through continuous inputs. We propose to treat these separator states as observations of local reasoning contexts, rather than as globally interchangeable embeddings. A horizontal sheaf specifies which parts of neighbouring contexts refer to the same quantities and how those quantities are compared. A token still carries a vertical fibre diagram across layers; reasoning time remains a separate index. The minimal implementation adds a causal bank of immutable anchors and a typed observation-star read to Sep-Latent. For fixed linear maps, the read is a strictly convex quadratic problem with a unique solution. It damps sensitivity in observed directions while preserving every unobserved direction exactly. We prove this statement, a bound for propagation of vertical square defects, and a conditional distance certificate. We also show why pooled alignment, vanishing compatibility residuals and extra latent steps cannot establish faithful reasoning. Fifty-three numerical checks verify illustrative identities and counterexamples, and an immutable C# kernel cross-validated against NumPy explores how sharp the bounds are; no model training or benchmark improvement is claimed. A staged implementation and proposed preregistration criteria distinguish benefits of contextual gluing from benefits of additional parameters, computation or generic smoothing.

**Mathematical development in Version 3.** The revised paper proves metric covariance, a sharp anchor-influence bound, and a decomposition of the obstruction produced by pinned observations. It gives an exact cumulative-spending criterion for repeated reads, including inconsistent banks and variable gates. It characterizes when several reads equal one stronger read, separates optimization sensitivity from Gaussian posterior uncertainty, and proves a robust finite-corruption bound. Quadratic anchors admit exact consolidation into three statistics; those same statistics do not generally preserve robust reads. A commuting restriction square intertwines the read only with appropriate metric compatibility. A closed-loop stability theorem states why a nonexpansive read alone cannot stabilize a reasoning process. Sections 9--15 contain these developments, and Section 18 records 21 rebuilt V2 checks plus 32 additional checks. The proofs are self-contained; model-performance benefits remain conjectural.

**Numerical development in Version 4.** An immutable C# kernel recomputes the Version 3 examples and probes the bounds with seeded Monte Carlo. NumPy regenerates the same random inputs and agrees on all 25 reported results. A harmonic read schedule has an exact Gamma-function gain, so its hardening follows the power law $N^{-c\lambda}\text{:}$ it is the boundary case of the spending criterion. The finite-corruption bound held in 400 trials, with median ratio 0.10. An apparent violation produced by an undamped Newton solver was exposed by the stationarity certificate. For orthogonal backbone feedback, the read adds no stability margin exactly when the private subspace contains an invariant subspace of the feedback. Mixing restores a margin, but the margin shrinks as the private dimension grows. Section 19 and Appendix A contain these results.

**Central proposal.** Use separator anchors to compress local reasoning; use sheaf restrictions to control which compressed information may be combined; use vertical diagrams to track how that information changes with depth.

**Status of claims.** Published benchmark numbers below belong to Sep-Latent. Propositions concern the explicitly defined linear sidecar. Performance improvements for the proposed system remain hypotheses.

# 1. Why Sep-Latent belongs in the ASE programme

The ASE programme began by reinterpreting denoising evolution as a layered process with horizontal local structure and vertical algebra. In that setting, a global vector is often too strong a representation: different examples expose different coordinates, different charts describe the same object, and different hypotheses may belong to separate branches. The present question is whether an implicit reasoning model can use the same discipline. Instead of forcing every intermediate thought into vocabulary tokens, it would maintain continuous local states and combine only the information their contexts allow them to share.

Sep-Latent \[1\] supplies a practical starting point. Its separators are trained as compression anchors for intermediate reasoning. Its implicit path feeds a projection of a hidden state back into the embedding stream. This creates an interface where a horizontal read could operate before the next continuous input is formed. It does not already identify local semantic charts or restrictions between them. Those are the new modelling commitments proposed here.

The phrase "horizontally topological" should therefore be made operational. Continuous latent vectors live in a topological space, but so do ordinary embeddings. Nontrivial topology does not follow from bypassing a vocabulary. Conversely, a cellular sheaf can be implemented on a finite incidence structure, so continuous latent reasoning is not mathematically necessary for sheaf based AI. Its attraction is engineering: continuous states admit calibrated linear observations, differentiable compatibility penalties and local correction without repeated textual serialization.

Our proposed requirement is more specific: a horizontal model must declare a base of contexts, data spaces on that base, and maps that identify comparable information on overlaps. It must preserve the distinction between agreement, uncertainty, competing hypotheses and truth. A useful implementation can begin with fixed, known projection maps on synthetic tasks. It need not begin by learning an arbitrary topology from hidden-state proximity.

This paper calls the proposed extension **Sep-Sheaf** for convenience. The name denotes a design to be tested, not an existing trained model or a claim that ordinary latent reasoning is secretly a sheaf algorithm. The initial goal is modest and measurable: determine whether typed partial agreement improves compositional reasoning at a controlled computational budget.

# 2. What Sep-Latent actually provides

## 2.1 Explicit and implicit paths

Sep-Latent uses one shared language model in two training paths \[1, Figure 2\]. The explicit path contains a query, textual reasoning steps, separators and an answer. During training, attention to reasoning-step positions is progressively reduced to encourage separator states to retain useful information. The implicit path replaces textual intermediate steps with continuous latent inputs. Writing reasoning position as $k$ and Transformer depth as $\mathcal{l}\text{,}$ its feedback interface is

$$u_{k + 1} = f_{\theta}\left( h_{k,L} \right),\quad\quad u_{k + 1} \in \mathbb{R}^{d}. \tag{1}$$

Here $f_{\theta}$ is an MLP and $L$ is the final Transformer layer. Vocabulary decoding resumes for the answer. The explicit path is supervised on its textual sequence; the implicit path is supervised on the final answer. Hidden states at separator and answer positions provide additional distillation targets. The explicit path and attention decay are disabled at inference. Appendix A describes termination through the language-model head predicting an end marker.

This interface follows the broader continuous-reasoning direction exemplified by Coconut \[2\]; CODI \[3\] provides a related self-distillation approach. The distinction relevant to our proposal is that Sep-Latent makes separator positions an explicit compression target. Such targets are convenient observations for a horizontal sidecar. They do not guarantee that each anchor is sufficient, correct, causal or interpretable.

## 2.2 Two replication details that matter

First, Sep-Latent's displayed attention-decay equation multiplies the attention quantity at reasoning-step keys by a factor $\gamma\text{.}$ It does not specify a subsequent renormalization in that equation. A normalized implementation instead uses probabilities proportional to $p_{j}\gamma^{\mathbf{1}_{j \in I_{steps}}}\text{,}$ equivalently a logit bias when $\gamma > 0\text{.}$ These are distinct choices. A replication must record the location of the modification in the attention pipeline, behaviour at zero, and whether probabilities are renormalized. The sheaf experiment must not silently change this baseline detail.

Second, the displayed separator and answer aggregates in equations (2) and (4) sum across both positions and layers. The accompanying prose discusses alignment across layers. Without a verified implementation, one should not replace that displayed sum by an indexed tensor and call the result an exact replication. For Sep-Sheaf we deliberately retain position and layer indices. This is a proposed change, motivated by Proposition 1 below. We will compare pooled and indexed alignment rather than assume they are equivalent.

## 2.3 Evidence and limits of the published results

Table 1 records a small, directly relevant subset of the attached preprint. Accuracy is a percentage. "Tokens" retains the paper's reported measure; it is not converted into measured latency or a count of independent reasoning operations.

**Table 1.** Published Sep-Latent results, not results of Sep-Sheaf. Source: \[1\], Table 1.

  ----------------------------------------------------------------------------
  Backbone and metric                    Explicit SFT-CoT   Sep-Latent
  -------------------------------------- ------------------ ------------------
  Llama3.2-1B, GSM8k-Aug accuracy        56.2               56.8

  Llama3.2-1B, GSM8k-Aug tokens          25.3               5.4

  Llama3.2-1B, four-task mean accuracy   58.1               57.9

  Llama3.2-1B, four-task mean tokens     17.9               5.9

  Qwen3-0.6B, four-task mean accuracy    53.5               53.6
  ----------------------------------------------------------------------------

These results support investigating compact latent inference, not assuming a universal accuracy gain. The larger-model comparison in \[1, Table 2\] still favours explicit CoT in accuracy. Training budgets also differ among reported baselines. Table 1 and the discussion of two out-of-domain scores contain reporting discrepancies; the values above follow Table 1. Its GSM8k-Aug column label is retained rather than resolving the preprint's differing descriptions of the evaluation split. The replication must identify actual dataset files and group related augmented questions before splitting.

The paper's latent visualizations are suggestive, but a low-dimensional projection cannot demonstrate preserved reasoning content or a meaningful sheaf topology. The causal analysis of Coconut in \[4\] gives a further reason to test interventions. Its findings concern its evaluated models and tasks; they are not a direct test of Sep-Latent. For our extension, a useful latent state must change downstream predictions in task-relevant ways when intervened on, not merely be decodable by a probe.

# 3. Four bases two indices and one semantic contract

## 3.1 Keep the bases separate

An implementation becomes ambiguous if "layer," "example," "separator" and "region" are treated as interchangeable nodes. Table 2 states four bases used in this proposal. Their relationships must be explicit even when one data structure indexes several of them.

**Table 2.** Distinct bases and their roles.

  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Base                                 Objects and maps                                              Role in this paper
  ------------------------------------ ------------------------------------------------------------- --------------------------------------------------------------------------------------
  Latent context space and its cover   Regions $U_{v}\text{,}$ intersections and a cover nerve       Declares the horizontal topology; proximity alone does not define a semantic overlap

  Context incidence structure          Vertices, edges and optional higher cells                     Finite cellular representation carrying data spaces and restrictions

  Layer order                          Depth indices $\mathcal{l}$ and declared transition arrows    Vertical fibre diagrams; linear models, or explicitly local tangent models

  Observation star                     A current candidate joined to selected, pinned observations   Computational base of one causal horizontal read
  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

A nerve records nonempty intersections of a cover. A cellular context graph can also be declared directly, without a claim that it is a good-cover nerve. The latter is the safer minimal prototype. If an actual topological cover is later introduced, its intersections, transition maps and relationship to the context graph must be checked. A graph manufactured from nearest-neighbour embeddings is a graph, not yet a validated semantic atlas.

Reasoning position $k$ is an additional time index, not a fifth name for Transformer depth. The pair $\left( k\mathcal{,l} \right)$ locates a continuous reasoning state. ASE denoising depth, Transformer depth and latent rollout length are three potentially different axes. A model may relate them, but must state that relation rather than infer it from the word "layer."

## 3.2 Stalks are data spaces; anchors are observations

At a context vertex $v$ and depth $\mathcal{l}\text{,}$ assign a finite-dimensional space $F_{\mathcal{l}}(v)\text{.}$ At an overlap edge $e = (v,w)\text{,}$ assign $F_{\mathcal{l}}(e)$ and restrictions

$$R_{ve\mathcal{,l}}:F_{\mathcal{l}}(v) \rightarrow F_{\mathcal{l}}(e),\quad\quad R_{we\mathcal{,l}}:F_{\mathcal{l}}(w) \rightarrow F_{\mathcal{l}}(e). \tag{2}$$

These are data spaces and maps, not individual tokens. An anchor $a_{v,k\mathcal{,l}}$ is a particular observation in a space. A separator hidden state can supply it through an adapter. A token moving through layers carries a **vertical fibre diagram**; calling the token's trajectory a stalk would conflate a data space with its evolving contents.

For the first implementation, each context exposes a known subset of typed variables. An overlap contains only shared variables with matching units, entity identifiers, time and hypothesis scope. Restrictions are coordinate projections after calibration. A separator ending a sentence about force is not automatically compatible with one about cost, even if their embeddings are close. Two alternative worlds that assign different forces are separate branches unless an explicit comparison construction is declared.

The semantic contract attached to an anchor contains context identifiers, variable types, unit transformations, branch and time tags, provenance, layer, confidence and an adapter version. The contract may initially be supplied by a synthetic-task generator or a verified parser. Learning it is a separate experiment, because a sheaf with incorrectly assigned overlaps can enforce a coherent but wrong computation.

## 3.3 Units come before residuals

Before measuring disagreement, convert overlapping quantities into a common representation and metric. A dimensional force and a dimensionless normalized feature cannot be subtracted merely because they occupy vectors of the same length. Let $W_{e}$ be a declared positive-definite metric on the overlap space. The whitened disagreement is

$$\left( B_{\mathcal{l}}x \right)_{e} = W_{e}^{1/2}\left( R_{we\mathcal{,l}}x_{w} - R_{ve\mathcal{,l}}x_{v} \right). \tag{3}$$

The horizontal energy is $\parallel B_{\mathcal{l}}x \parallel^{2}/2\text{.}$ Kernel membership means agreement under these maps, not truth. On a graph this is a cellular sheaf coboundary \[5\]. With higher-dimensional cells, restriction diamonds must commute so that consecutive coboundaries compose to zero. A pairwise graph alone does not establish the triangle identities needed by a higher-dimensional complex.

An exact change of local coordinates must transform the restrictions and metrics consistently. Arbitrary Euclidean penalties are not invariant under an arbitrary change of gauge. This is why the first prototype uses calibrated projections rather than unconstrained learned matrices.

# 4. From separator compression to a causal sheaf read

## 4.1 Retain indexed information

Let $a_{j\mathcal{,l}}$ be a detached explicit-path separator target, and let $z_{k\mathcal{,l}}$ be the corresponding implicit-path feature. Store their indices. During training a monotone alignment $j = \tau(k)$ can be supplied from the explicit trace. At inference, step counts may differ. The controller must use masks, a declared alignment procedure or context matching; training-time position matching is not a proof that inference anchors denote the same local facts.

**Proposition 1 (pooled cancellation).** For $L \geq 2\text{,}$ the sum map from $L$ copies of $\mathbb{R}^{r}$ to $\mathbb{R}^{r}$ has kernel dimension $(L - 1)r\text{.}$ Therefore a zero loss on the sum does not imply agreement at each layer.

**Proof.** The sum map is surjective and has rank $r\text{,}$ so rank-nullity gives the dimension. A nonzero error $v$ at one layer and $- v$ at another has zero sum. An indexed squared loss detects both. The same issue applies to summing over separator positions. This proves a limitation of the displayed aggregation, not a claim about uninspected Sep-Latent code. ∎

We therefore propose per-position, per-layer alignment, with loss normalization over active coordinates. The target is not that every layer encode the same thing. Each layer has its own calibrated adapter and its own target. Comparing raw hidden states across unrelated layers would reintroduce the coordinate problem.

## 4.2 Immutable bank and current observation star

At reasoning step $k\text{,}$ read a bounded set of prior anchors from the same admissible branch. The bank can initially contain earlier reasoning contexts in the same query. A later version can also retrieve verified records from other examples, provided their types, gauges and branch scopes match; cross-example similarity alone is insufficient. The bank is immutable during the step. Only the current candidate is optimized. This gives a causal observation star: old anchors are observations, not unknowns to be moved until they agree with the current guess. Select anchors using context eligibility first and geometric similarity second.

Let $u \in \mathbb{R}^{r}$ be the current adapter proposal. Stack its whitened restrictions into $C$ and the corresponding prior-anchor observations into $b\text{.}$ For fixed maps and weights, define

$$z^{\text{*}} = \underset{z \in \mathbb{R}^{r}}{argmin}\left\{ \frac{\mu}{2} \parallel z - u \parallel^{2} + \frac{\beta}{2} \parallel Cz - b \parallel^{2} \right\},\quad\mu > 0,\ \beta \geq 0. \tag{4}$$

The first term preserves the current proposal; the second asks only for declared shared information. Cholesky factorization gives the small dense solve

$$\left( \mu I + \beta C^{\top}C \right)z^{\text{*}} = \mu u + \beta C^{\top}b. \tag{5}$$

Use a linear solve, not an explicit matrix inverse. For larger sparse spaces, conjugate gradients with a recorded tolerance is appropriate. Inconsistent observations do not invalidate the soft solve; they leave an irreducible disagreement which must be reported. A robust convex edge loss is a later alternative for fixed maps, with a numerical solver and a separate convergence budget.

The result is fed through an output adapter as a gated correction to the next continuous input. Past backbone keys and values are not rewritten. The immutable sidecar and the transformer's causal KV cache are different stores. Recomputing a past prefix after changing anchors would be a different, more expensive algorithm and must not be presented as the same cached inference.

## 4.3 What this read guarantees

**Proposition 2 (unique read and directional preservation).** The problem in (4) has a unique solution. With $C$ and $b$ fixed, its derivative with respect to $u$ is

$$J_{u} = \mu\left( \mu I + \beta C^{\top}C \right)^{- 1}. \tag{6}$$

For a right singular direction of $C$ with singular value $\sigma\text{,}$ the gain is $\mu/\left( \mu + \beta\sigma^{2} \right)\text{.}$ On $\ker C\text{,}$ the gain is exactly one and the solution retains the projection of $u$ exactly.

**Proof.** The Hessian is positive definite because $\mu > 0\text{.}$ Differentiating its normal equations proves (6). Diagonalizing $C^{\top}C$ proves the gains. For $q \in kerC\text{,}$ multiply (5) by $q^{\top}\text{:}$ the observation term vanishes and $q^{\top}z^{\text{*}} = q^{\top}u\text{.}$ ∎

This is the central useful guarantee. Shared coordinates can be corrected while private coordinates survive. Full-vector consensus generally lacks that property. It is also a limited guarantee: if the anchor observations are functions of $u\text{,}$ or retrieval changes discontinuously with $u\text{,}$ (6) is only the conditional derivative with the selected bank held fixed. End-to-end sensitivity includes those additional paths.

The displacement has the useful conservative bound

$$\parallel z^{\text{*}} - u \parallel \leq \frac{\beta}{\mu} \parallel C^{\top}(Cu - b) \parallel . \tag{7}$$

It follows by subtracting the normal equations for $u$ and bounding the inverse Hessian norm by $1/\mu\text{.}$ The ratio $\beta/\mu$ controls intervention strength, not evidence quality. Increasing it cannot make a wrong anchor reliable.

![](fig/image1.png){width=100%}

**Figure 1.** Exact gains from Proposition 2, with $\mu = 1\text{.}$ Agreement suppresses sensitivity along an observed coordinate. A private coordinate remains unchanged. This is an analytic plot of the proposed linear read, not a trained-model measurement.

# 5. A worked partial-information example

Consider a normalized engineering feature vector whose first two coordinates denote length and load, while the last two are private design features. Units have already been converted and standardized. One verified anchor supplies length 3; a different anchor supplies load 1. Neither asserts anything about the two private features. At the current step, use

$$u = (1,3,7, - 2)^{\top},\quad b = (3,1)^{\top},\quad C = \begin{pmatrix} 1 & 0 & 0 & 0 \\ 0 & 1 & 0 & 0 \end{pmatrix}. \tag{8}$$

With $\mu = 1$ and $\beta = 3\text{,}$ equation (5) gives $z^{\text{*}} = (2.5,1.5,7, - 2)^{\top}\text{.}$ The observed-coordinate gains are $0.25\text{,}$ and both private-coordinate gains are $1\text{.}$ The read recombines partial observations without inventing agreement on unseen coordinates. This is an information-recombination mechanism; whether a subsequent decoder can use it for a valid solution remains an empirical question.

The compatible affine set is $\{ z:z_{1} = 3,z_{2} = 1\}\text{.}$ The current solution is at distance $\sqrt{0.5}$ from it, and its observation residual has the same norm. Those numbers follow directly from the specified inputs; they are not benchmark statistics. Equation (4) is a soft penalty, so a nonzero residual at finite $\beta$ is expected.

If the anchors instead describe different hypothetical designs, forcing length from one and load from another might produce an invalid combination. The typed contract must state that these coordinates may coexist. This requirement is especially important in multimodal reasoning: shared variable names do not imply shared possible worlds. Branch-separated retrieval is preferable to averaging incompatible hypotheses.

An overlap graph also need not have the cohomology of its bare underlying graph. For example, contexts containing $(a,b)\text{,}$ $(b,c)$ and $(c,a)$ with overlap projections onto $b\text{,}$ $c$ and $a$ yield a surjective degree-zero coboundary to the three scalar edge spaces. Its first sheaf cohomology is zero, despite the cycle in the graph. Thus counting loops does not count reasoning contradictions. The coefficient spaces and restriction maps determine what an obstruction means.

# 6. Vertically algebraic squares tangents and their limits

## 6.1 A vertical fibre diagram is an additional model

The sidecar can be attached at the last layer alone. That is the minimal system. A multilayer extension assigns spaces and restrictions at selected depths, together with declared vertical maps. For fixed incidence and linear maps, let $T_{\mathcal{l}}$ act on vertex data and $S_{\mathcal{l}}$ on edge data. The compatibility square is

$$B_{\mathcal{l +}1}T_{\mathcal{l}} = S_{\mathcal{l}}B_{\mathcal{l}}. \tag{9}$$

When the horizontal base changes, first transport the next layer's sheaf using the declared base map $\Phi_{\mathcal{l}}$ and its inverse image $\Phi_{\mathcal{l}}^{- 1}\text{.}$ A map between arrays with different indexing is not a natural transformation merely because their shapes can be padded. Learned covers may give a zigzag rather than a chain; the direction of every base and coefficient map then matters.

Transformer blocks are nonlinear. Their actual hidden-state evolution is not a global representation by fixed linear maps. There are three honest options: use explicitly linear sidecar maps; use affine maps with declared homogeneous coordinates; or study local Jacobians along a particular trajectory. The last gives local tangent information and first-order approximations, not an exact global barcode of the transformer. Reasoning-time recurrence is likewise a distinct nonlinear dynamical process.

## 6.2 A bound when squares only approximately commute

Define the square defect $D_{\mathcal{l}} = B_{\mathcal{l +}1}T_{\mathcal{l}} - S_{\mathcal{l}}B_{\mathcal{l}}\text{.}$ Suppose a fixed linear sidecar evolves by $x_{\mathcal{l +}1} = T_{\mathcal{l}}x_{\mathcal{l}}\text{,}$ and put $r_{\mathcal{l}} = B_{\mathcal{l}}x_{\mathcal{l}}\text{.}$ Then

$$r_{\mathcal{l +}1} = S_{\mathcal{l}}r_{\mathcal{l}} + D_{\mathcal{l}}x_{\mathcal{l}}. \tag{10}$$

**Proposition 3 (defect propagation).** Writing $s_{\mathcal{l}} = \parallel S_{\mathcal{l}} \parallel$ and $d_{\mathcal{l}} = \parallel D_{\mathcal{l}} \parallel \text{,}$ the final residual obeys

$$\parallel r_{L} \parallel \leq \left( \prod_{j = 0}^{L - 1}s_{j} \right) \parallel r_{0} \parallel + \sum_{i = 0}^{L - 1}d_{i} \parallel x_{i} \parallel \prod_{j = i + 1}^{L - 1}s_{j}. \tag{11}$$

An empty product equals one. **Proof.** Substitute (10) recursively and apply the triangle inequality and submultiplicativity of operator norms. ∎

Commuting squares preserve compatibility, but even small defects can accumulate when vertical edge maps amplify. A squared-defect training loss is therefore not by itself a final-residual certificate. For nonlinear backbone maps, the analogous first-order expression includes Taylor remainders and depends on the chosen trajectory. Report those approximations explicitly.

## 6.3 What barcodes would and would not mean here

An exact finite-dimensional representation of a finite linearly oriented layer order has an interval decomposition \[6, 7\]. Such a barcode can summarize the declared linear sidecar or an explicitly specified sequence of tangent maps. It cannot by itself certify that an interval represents a mathematical fact, a memory or a reasoning step. Semantic meaning needs labelled interventions or other independent validation.

Exact ranks and effective ranks must both be reported. Products of theoretically full-rank maps may become numerically singular. A numerical barcode therefore needs a stated threshold, precision and conditioning diagnostic. Evidence from a tangent diagram is about local sensitivity; it is not evidence that hidden states follow a globally linear law.

The product-stack viewpoint from Part I also needs its hypotheses. Under its stated fixed-base, bottom-initial layer setting, cohomology can collapse to the bottom layer and miss vertical events. This does not justify collapsing Sep-Latent's depth index during training. Changing bases or replacing the layer order by a zigzag requires a new analysis; the product-stack theorem does not transfer automatically. The indexed vertical diagram remains the object to inspect.

# 7. Compatibility certificates are not reasoning certificates

**Proposition 4 (conditional distance certificate).** Let $Az = b$ be a consistent affine compatibility system in calibrated coordinates. If $A$ has at least one positive singular value, then

$$dist\left( z,\{ w:Aw = b\} \right) \leq \frac{\parallel Az - b \parallel}{\sigma_{\min}^{\text{+}}(A)}. \tag{12}$$

**Proof.** Let $p$ be the Euclidean projection onto the solution set. The vector $z - p$ is orthogonal to $\ker A\text{,}$ and $Az - b = A(z - p)\text{.}$ The smallest positive singular value bounds this norm below. ∎

If each decoder logit is $K$-Lipschitz on the segment from $z$ to $p\text{,}$ a margin greater than twice $K$ times the right-hand side of (12) ensures that this projection does not change the selected class. This is a conditional stability statement. It neither validates the constraints nor proves the selected answer correct. If there are no observed directions, the bound is inapplicable as written; if the constraints are inconsistent, first account for the least-squares residual floor. A tiny positive singular value makes the bound weak.

Two counterexamples should accompany every experimental report. First, a homogeneous sheaf loss accepts the zero section; learning every restriction to zero makes every state compatible. Second, three anchors all asserting the same wrong number have zero pairwise disagreement. Neither case is repaired by a smaller residual threshold. Training needs nondegeneracy controls and external correctness supervision; evaluation needs interventions and verified task constraints.

Coverage is separate from agreement. An empty or narrowly supported observation star may have negligible residual because almost nothing was compared. Report the observed subspace, its effective rank and task-required coordinates. A model should not stop merely because a graph is connected, because its residual is small, or because a latent decoder predicts an end marker.

The causal question is sharper: if a trusted anchor's shared quantity is changed while unrelated variables are fixed, does the answer change as the task requires? Conversely, if a private coordinate or punctuation placement changes, does the answer remain stable when the task says it should? Probes can help locate information, but these interventions test whether the information is used.

# 8. Training and inference specification

## 8.1 A staged objective

The first experiment freezes the baseline backbone and uses fixed context maps. Train small input and output adapters using answer supervision and indexed detached teacher targets. Only then test joint optimization. A representative later objective is

$$\mathcal{L =}\mathcal{L}_{CE,explicit} + \mathcal{L}_{CE,answer} + \lambda_{a}\mathcal{L}_{indexed} + \lambda_{h}\mathcal{L}_{overlap} + \lambda_{v}\mathcal{L}_{square}. \tag{13}$$

The indexed term averages squared, calibrated distances over matched positions, selected layers and active dimensions. The overlap term measures only declared comparable quantities. The square term applies only to the explicit linear sidecar or a clearly labelled local surrogate. It does not impose exact linearity on the transformer. Auxiliary noncollapse and map-normalization terms are necessary if restrictions or adapters are freely learned, but their form must be reported and ablated rather than hidden in a generic regularizer.

Start with nonzero supervised features and fixed projection restrictions. Otherwise the system can reduce the overlap loss by destroying information. When dimensions or anchor counts vary, normalize losses so a longer chain does not receive a larger penalty merely because more coordinates were exposed. Keep explicit answer distillation separate from separator alignment; an improved answer-state match does not establish that the intermediate anchors became more useful.

## 8.2 Causal inference algorithm

To specify the interface completely, let $q_{k + 1} = f_{\theta}\left( h_{k,L} \right)$ be the uncorrected next embedding, let $E$ map it to the calibrated sidecar, and let $D$ lift a sidecar correction back to embedding space. The read uses $u = Eq_{k + 1}$ and outputs

$${\widetilde{q}}_{k + 1} = q_{k + 1} + gD\left( z^{\text{*}} - u \right),\quad\quad 0 \leq g \leq 1. \tag{14}$$

A fixed right inverse satisfying $ED = I$ makes the sidecar of this embedding exactly $(1 - g)u + gz^{\text{*}}\text{.}$ If $E$ is not surjective or $D$ is learned without that constraint, report the reconstruction defect instead. Proposition 2 guarantees preservation in the declared sidecar coordinates; it does not guarantee unchanged hidden features after the next nonlinear backbone call. A calibrated linear projection and its fixed right inverse are the clean initial choice.

The minimal prototype reads only the final-layer sidecar. Selected-layer hooks are a later extension, tested against the same computation budget. This avoids requiring every transformer layer to participate before the basic hypothesis is established.

1.  Run the current causal backbone step and form the ordinary continuous-feedback proposal.
2.  Produce calibrated sidecar features and context metadata from the current prefix only. No teacher trace, future answer or future separator is available.
3.  Retrieve a capped set of eligible prior anchors from the same branch; construct $C$ and $b$ from fixed maps and pinned observations.
4.  Solve (5), record residual, coverage and conditioning, and form a gated correction through the output adapter.
5.  Append a new immutable anchor with provenance. Feed the corrected continuous input to the next backbone step; retain the normal KV cache unchanged.
6.  At the end-marker proposal, check the step cap and any task-specific verifier. Optional coverage and stability gates are structural diagnostics. If they fail, continue within budget or use an explicit/tool-assisted fallback with its cost recorded.

At initialization, make the correction gate zero so the implementation reproduces the baseline feedback path. Enable it gradually and verify that a zero gate and $\beta = 0$ reproduce baseline outputs within the stated numerical tolerance. Use deterministic anchor ordering and record retrieval ties. Updating the bank, solving the star and taking a backbone step are separate operations in the execution trace.

## 8.3 Attention stopping and branches

The attention-decay curriculum belongs to the training baseline. Horizontal anchor retrieval is an additional inference operation, not another name for that curriculum. Its masks must be causal, and context assignment must not use the training-only explicit answer. A controlled experiment should vary separator punctuation while retaining the same semantic context graph. Otherwise the model may learn formatting shortcuts instead of useful compression anchors.

A branch identifier prevents accidental mixing of mutually exclusive hypotheses. Multiple branches may be scored or compared through a separate decision mechanism; their embeddings should not simply be averaged into a supposed consensus. If contradictory evidence concerns the same actual world, keep its provenance and residual rather than hiding it by splitting every disagreement into a new branch.

An end-marker controller needs a maximum latent-step budget. Adding a low-residual stopping gate can suppress some unsupported exits but can also prolong wrong agreement or block correct answers with incomplete contexts. Evaluate both errors: premature stopping and needless continuation. Verification failures and fallback invocations belong in the reported task cost.

## 8.4 Cost and implementation risks

For sidecar dimension $r$ and $q$ scalar overlap observations, a dense solve costs approximately $O\left( qr^{2} + r^{3} \right)$ to form and factor the system. Fixed reusable map patterns permit factor reuse; changing gates or metrics may not. A bank of $m$ anchors at $s$ selected depths stores $O(msr)$ feature values plus metadata, in addition to the backbone KV cache. Retrieval has its own latency and memory cost.

Latent inference still performs backbone calls and creates cache entries. Fewer reported tokens do not imply proportional savings in FLOPs, memory traffic or wall-clock time. Training with a long explicit path and a recurrent implicit path also has activation and gradient costs. Record teacher-path cost, backpropagation length, solver iterations, peak memory and hardware. Any gain must survive comparison with a baseline given the same calls or the same time budget.

Soft retrieval can maintain differentiability but may blur branches. Hard retrieval is easier to audit but makes selection discontinuous. The initial fixed-map experiments should hold retrieval fixed during derivative checks and separately measure selection sensitivity. Calibration drift after joint fine-tuning requires adapter versioning and bank invalidation; stale anchors must not be silently treated as observations in a new gauge.

## 8.5 Repeated reads wrong anchors and branches

The read (4) runs once per reasoning step. Three properties of that repetition matter before any training.

**Proposition 5 (repeated reads become a hard projection).** Fix a consistent bank, $C$ and $b\text{,}$ assume $\beta > 0\text{,}$ and apply the read $k$ times, each time starting from the previous output. Let $p$ be the point of $\{ z:Cz = b\}$ nearest to $u\text{.}$ Then

$$z_{k} - p = \left( \mu\left( \mu I + \beta C^{\top}C \right)^{- 1} \right)^{k}(u - p). \tag{15}$$

Along a right singular direction with singular value $\sigma$ the error contracts by $\left( \mu/\left( \mu + \beta\sigma^{2} \right) \right)^{k}\text{.}$ The component in $\ker C$ never moves. So $z_{k} \rightarrow p\text{,}$ the hard projection.

**Proof.** Since $Cp = b\text{,}$ the normal equations (5) for $p$ read $\left( \mu I + \beta C^{\top}C \right)p = \mu p + \beta C^{\top}b\text{.}$ Subtracting them from those for $z_{j + 1}$ gives $z_{j + 1} - p = \mu\left( \mu I + \beta C^{\top}C \right)^{- 1}\left( z_{j} - p \right)\text{.}$ Then iterate, diagonalise, and use $u - p\bot kerC$ for the nearest point. ∎

This is the proximal-point method for $\frac{1}{2} \parallel Cz - b \parallel^{2}\text{.}$ On a random consistent bank the distance to $p$ fell from 3.61 to 0.040 after five reads and 5.9e-08 after twenty, while the private component moved by at most 1.1e-14. When the bank has distinct positive singular values, no single penalty gives the same affine operator as $k \geq 2$ reads at positive strength. The equal-singular-value exception is proved in Theorem 11.3. In the test, matching five reads would need $\beta \approx 1320$ in one direction and 392 in another. Extra latent steps are not neutral repetition. For a fixed consistent bank, constant positive strength and a fixed positive gate, they convert the soft correction into a hard limit. A decaying gate prevents this only when its spectral spend is finite, as Theorem 11.1 specifies. What is lost here is dependence on the initial observed component, not automatically a probabilistic uncertainty estimate. Report the number of reads per anchor set, or re-read only when the bank changes.

**Proposition 6 (one wrong anchor).** If observation $i$ is corrupted by $\epsilon\text{,}$ the quadratic read moves by $\beta\left( \mu I + \beta C^{\top}C \right)^{- 1}c_{i}\epsilon\text{.}$ This is unbounded in $\epsilon$ when $\beta > 0$ and $c_{i} \neq 0\text{;}$ a zero row has no influence. Replace the observation term by a Huber loss with threshold $\delta$ applied to each scalar residual. Then every solution satisfies

$$\parallel z^{\text{*}} - u \parallel \leq \frac{\beta\delta}{\mu}\sum_{i}^{} \parallel c_{i} \parallel , \tag{16}$$

whatever the anchor values are.

**Proof.** The quadratic statement differentiates (5) in $b\text{.}$ For Huber loss, stationarity gives $\mu\left( z^{\text{*}} - u \right) = - \beta\sum_{i}^{}c_{i}\psi_{\delta}\left( c_{i}^{\top}z^{\text{*}} - b_{i} \right)\text{,}$ where $\left| \psi_{\delta} \right| \leq \delta\text{,}$ and the triangle inequality completes it \[9\]. ∎

With $\mu = 1\text{,}$ $\beta = 3$ and coordinate observations, the quadratic shift grew as $0.75\epsilon$ and reached 75 at $\epsilon = 100\text{.}$ The Huber read with $\delta = 0.5$ never moved more than 1.35, below the per-coordinate cap $\beta\delta/\mu = 1.5$ (Figure 2a). Robustness has a price: a correct but surprising anchor is also capped. This is why Section 7 asks for correctness supervision rather than a smaller residual.

**Proposition 7 (pooling branches).** Suppose two anchors observe the same scalar coordinate with values $b_{1} \neq b_{2}$ from different branches. The pooled read $z^{\text{*}} = \left( \mu u + \beta\left( b_{1} + b_{2} \right) \right)/(\mu + 2\beta)$ tends to the midpoint as $\beta/\mu$ grows. Its distance from the nearer branch then tends to $\left| b_{1} - b_{2} \right|/2\text{.}$ A branch-separated read is within $\mu\left| u - b_{j} \right|/(\mu + \beta)$ of its own branch $j\text{.}$

**Proof.** The pooled scalar normal equation is $(\mu + 2\beta)z = \mu u + \beta\left( b_{1} + b_{2} \right)\text{.}$ Dividing and taking the positive-strength limit gives the midpoint and its branch distance. For one branch, subtract $b_{j}$ from $\left( \mu u + \beta b_{j} \right)/(\mu + \beta)$ to obtain the stated equality. ∎

With $b_{1} = 2\text{,}$ $b_{2} = 6\text{,}$ $u = 4.5$ and $\beta/\mu = 10\text{,}$ the pooled read is 4.02, about two units from both branches. The separated reads are 2.23 and 5.86. The branch identifier of Section 8.3 is therefore not bookkeeping: without it the read produces a value that neither hypothesis asserts.

![](fig/image2.png){width=100%}

**Figure 2.** (a) Shift of the read caused by an error in one anchor: quadratic (unbounded) against Huber (capped below $\beta\delta/\mu$). (b) Distance to the nearest compatible point after repeated reads against one consistent bank (Proposition 5).

# 9. Metric covariance and exact anchor influence

The first extension makes the phrase "units come before residuals" an invariant statement. Throughout Sections 9--15, spaces are finite dimensional over the real numbers, maps and bank membership are fixed during a read, and norms without a subscript are Euclidean. A statement about a fixed read is not automatically a statement about an adaptive retrieval loop. All results below are elementary specializations of convex optimization, spectral linear algebra and cellular sheaf algebra; we claim an application-specific synthesis, not new foundations for those subjects \[5, 9--11\].

## 9.1 A metric on the current data space

**Definition 9.1 (metric read).** Let $G$ be symmetric positive definite on the current data space, let $C$ contain the whitened overlap restrictions, and let $b$ be their pinned observations. Define $\parallel v \parallel_{G}^{2} = v^{\top}Gv$ and

$$R_{G,C,b}(u) = \underset{z}{argmin}\left\{ \frac{\mu}{2} \parallel z - u \parallel_{G}^{2} + \frac{\beta}{2} \parallel Cz - b \parallel^{2} \right\}. \tag{17}$$

Here $\mu > 0$ and $\beta \geq 0\text{.}$ Its Hessian is $H = \mu G + \beta C^{\top}C\text{,}$ so it has exactly one minimizer. Whitening overlap residuals and choosing a prior metric are separate operations: the first controls comparisons between contexts; the second controls displacement of the current state.

**Theorem 9.2 (covariance under a change of data coordinates).** Let $Q$ be any invertible matrix. In coordinates $z' = Qz\text{,}$ set

$$u' = Qu,\quad C' = CQ^{- 1},\quad G' = Q^{- \top}GQ^{- 1}. \tag{18}$$

Then $R_{G',C',b}(u') = QR_{G,C,b}(u)\text{.}$

**Proof.** Substitute $z' = Qz$ into (17). The displacement energy and the overlap residual are individually unchanged. The bijection between candidate states therefore carries the unique minimizer to the unique minimizer. ∎

If overlap coordinates also change by an invertible map $V\text{,}$ transform their metric by $W' = V^{- \top}WV^{- 1}$ as well as transforming restrictions and observations. The same substitution proves invariance before whitening. Keeping $G = I$ after a nonorthogonal rescaling generally changes the optimization problem. In particular, a change of engineering units is not a harmless implementation detail unless the metrics follow it.

**Lemma 9.3 (firm nonexpansiveness and private directions).** For two proposals $u,v$ and the same bank, put $d = R(u) - R(v)\text{.}$ Then

$$\parallel d \parallel_{G}^{2} + \frac{\beta}{\mu} \parallel Cd \parallel^{2} = d^{\top}G(u - v). \tag{19}$$

Consequently $R$ is nonexpansive in the $G$ norm. For every $q \in kerC\text{,}$ $q^{\top}G\left( R(u) - u \right) = 0\text{;}$ hence the $G$-orthogonal projection onto $\ker C$ is preserved.

**Proof.** Subtract the normal equations at $u$ and $v\text{,}$ multiply on the left by $d^{\top}\text{,}$ and divide by $\mu\text{.}$ Cauchy--Schwarz gives nonexpansiveness. Multiplying one normal equation by $q^{\top}$ gives the private-direction statement. ∎

This is a proximal operator in a declared metric \[10, 11\]. It cannot be strictly contractive on the full space whenever an unobserved direction remains. A downstream backbone can still amplify that direction, as Section 15 shows.

## 9.2 Sharp conditional sensitivity to anchor data

**Theorem 9.4 (exact anchor influence).** In Euclidean coordinates, write $H = \mu I + \beta C^{\top}C\text{.}$ If only $b$ changes, then $R_{b + e}(u) - R_{b}(u) = Ke\text{,}$ where $K = \beta H^{- 1}C^{\top}\text{.}$ If $C$ has positive singular values $\sigma_{i}\text{,}$ then for $\beta > 0$

$$\parallel K \parallel = \max_{i}\frac{\beta\sigma_{i}}{\mu + \beta\sigma_{i}^{2}} \leq \frac{1}{2}\sqrt{\frac{\beta}{\mu}}. \tag{20}$$

For $C = 0$ or $\beta = 0\text{,}$ the influence is zero. A scalar observation with nonzero row $c_{i}^{\top}$ has nonzero linear influence $\beta H^{- 1}c_{i}$ when $\beta > 0\text{;}$ its effect is unbounded as its error amplitude grows.

**Proof.** Subtract the two normal equations. An SVD of $C$ diagonalizes $K$ into the displayed gains. Differentiating $\beta s/\left( \mu + \beta s^{2} \right)$ gives its maximum at $s = \sqrt{\mu/\beta}\text{.}$ Finally, $H^{- 1}$ is injective, so it cannot annihilate a nonzero row vector. ∎

The universal bound is attained, so it cannot be improved without information about the restrictions. A zero restriction row is the exception to V2's unqualified wrong-anchor statement: corrupting that observation changes no state. A large residual also need not imply large influence, because its component orthogonal to $imC$ has no effect on the minimizer. The next section identifies that component.

# 10. Grounding and the horizontal obstruction

## 10.1 Inconsistency is a class rather than a dimension

For a graph sheaf with coboundary $B\text{,}$ an affine agreement problem is $Bx = d\text{.}$ Since a graph has no degree-two cells, its first cohomology is $cokerB\text{.}$ The dimension of this space counts available obstruction coordinates; the particular class $\lbrack d\rbrack$ determines whether the specified affine agreements are extendible. A nonzero dimension alone is not inconsistent data.

In an observation star, the old vertices are pinned. Partition $B = \left\lbrack C\ B_{P} \right\rbrack$ into free and pinned columns. If pinned data are $a\text{,}$ the free problem is $Cz = b\text{,}$ with $b = d - B_{P}a\text{.}$ Thus $cokerC$ is the relevant grounded obstruction space. For the subcomplex consisting of the pinned vertices, this is degree-one relative sheaf cohomology. It generally differs from absolute cohomology of the ungrounded graph.

**Theorem 10.1 (orthogonal decomposition of a grounded obstruction).** Let $C^{\dagger}$ denote the Moore--Penrose inverse. For any $C$ and $b\text{,}$ define

::: {custom-style="Equation"}
$\eta = \left( I - CC^{\dagger} \right)b,$
:::

$$\parallel Cz - b \parallel^{2} = \parallel C\left( z - C^{\dagger}b \right) \parallel^{2} + \parallel \eta \parallel^{2}. \tag{21}$$

Then $C^{\top}\eta = 0\text{.}$ The system $Cz = b$ is consistent exactly when $\eta = 0\text{,}$ and its minimum residual norm is $\parallel \eta \parallel \text{.}$ The vector $\eta$ is the Euclidean orthogonal representative of $\lbrack b\rbrack \in cokerC\text{.}$

**Proof.** The matrix $CC^{\dagger}$ is the orthogonal projector onto $imC\text{.}$ Decompose $b$ into that space and its orthogonal complement. The two terms in (21) are perpendicular, so Pythagoras gives the identity and all conclusions. ∎

**Example 10.2 (a tree can have a grounded obstruction).** One free scalar $z$ is connected to two pinned scalars 0 and 2, with identity restrictions. The full graph is a tree and its constant rank-one sheaf has absolute $H^{1} = 0\text{.}$ The free operator is $C = (1,1)^{\top}$ and $b = (0,2)^{\top}\text{.}$ Its cokernel has dimension one; $\eta = ( - 1,1)^{\top}$ and the minimum residual is $\sqrt{2}\text{.}$ No choice of the centre reconciles both pins. The obstruction comes from the boundary data, not from a loop in the base.

For complexes with higher cells, an absolute degree-one cohomology class requires $d$ to be closed: $\delta^{1}d = 0\text{.}$ A vector outside that kernel also violates higher compatibility. One must not identify the full cokernel of $\delta^{0}$ with $H^{1}$ in that setting. The graph calculation above deliberately avoids that conflation.

## 10.2 A certificate after subtracting the residual floor

**Corollary 10.3 (distance to the least-squares affine set).** Let $\mathcal{S =}C^{\dagger}b + kerC\text{,}$ which is nonempty even for inconsistent observations. If $C$ has a positive singular value, then

$$dist\left( z\mathcal{,S} \right) \leq \frac{\sqrt{\parallel Cz - b \parallel^{2} - \parallel \eta \parallel^{2}}}{\sigma_{\min}^{\text{+}}(C)}. \tag{22}$$

**Proof.** Project $z - C^{\dagger}b$ orthogonally off $\ker C\text{.}$ Apply the smallest-positive-singular-value bound to that component and use (21). ∎

This strengthens Proposition 4 to inconsistent banks. Its target is a best-fitting affine set, not a set satisfying all observations. A stopping rule should report three separate quantities: distance to best fit, the irreducible obstruction, and effective coverage. None establishes correctness of the pinned data. With an empty observed subspace, there is no positive singular value and this formula is not used.

# 11. Read schedules and repeated information

## 11.1 An exact criterion for hardening

V2 identified repeated quadratic reads with proximal iteration. That statement holds for the isolated read with an unchanged bank; an intervening nonlinear backbone step need not follow the same recurrence. Here we complete the fixed-bank analysis, allowing both gating and inconsistent observations.

**Theorem 11.1 (spectral spending criterion).** Fix $C,b$ and initial state $z_{0}\text{.}$ Put $A = C^{\top}C\text{,}$ $N = kerC\text{,}$ and $p = C^{\dagger}b + P_{N}z_{0}\text{.}$ At step $j\text{,}$ use a finite ratio $\alpha_{j} = \beta_{j}/\mu_{j} \geq 0$ and gate $0 \leq g_{j} \leq 1\text{,}$ with $\mu_{j} > 0\text{.}$ Let $R_{\alpha_{j}}$ be the quadratic read. For every eigenvector of $A$ with eigenvalue $\lambda > 0\text{,}$

::: {custom-style="Equation"}
$z_{j + 1} = \left( 1 - g_{j} \right)z_{j} + g_{j}R_{\alpha_{j}}\left( z_{j} \right),$
:::

$$\gamma_{k}(\lambda) = \prod_{j = 0}^{k - 1}\left( 1 - \frac{g_{j}\alpha_{j}\lambda}{1 + \alpha_{j}\lambda} \right). \tag{23}$$

The error relative to $p$ in that direction is its initial error times $\gamma_{k}(\lambda)\text{.}$ The private component is fixed. Convergence to $p$ for every initial state is equivalent to

$$\sum_{j = 0}^{\infty}\frac{g_{j}\alpha_{j}\lambda}{1 + \alpha_{j}\lambda} = \infty\quad\text{for each positive eigenvalue }\lambda. \tag{24}$$

**Proof.** The vector $p$ satisfies $Ap = C^{\top}b\text{,}$ whether or not $Cz = b$ is consistent. Subtract this normal equation from the read equation. The error multiplier is $\left( 1 - g_{j} \right)I + g_{j}\left( I + \alpha_{j}A \right)^{- 1}\text{,}$ which is diagonal in one fixed eigenbasis. This proves (23). Each factor is strictly positive and at most one. For numbers $0 \leq a_{j} < 1\text{,}$ $\prod_{j}^{}\left( 1 - a_{j} \right) > 0$ exactly when $\sum_{j}^{}a_{j} < \infty\text{:}$ use $- log(1 - a) \geq a\text{,}$ and, on any summable tail, $- log(1 - a) \leq 2a\text{.}$ Apply this to each eigenvalue. A nonzero initial component converges exactly when its product vanishes. ∎

Thus decaying gates do not necessarily prevent hardening. If the cumulative spend in (24) diverges, they still erase the initial error in every observed direction. Zero strength gives no correction. Inconsistency survives as the residual floor $\parallel \eta \parallel \text{,}$ even after all correctable error disappears.

**Corollary 11.2 (a finite-spend sensitivity floor).** Write $a_{j} = g_{j}\alpha_{j}\lambda/\left( 1 + \alpha_{j}\lambda \right)\text{.}$ If $a_{j} \leq a_{\max} < 1$ and $S = \sum_{j}^{}a_{j} < \infty\text{,}$ then

$$\gamma_{\infty}(\lambda) \geq exp\left( - \frac{S}{1 - a_{\max}} \right) > 0. \tag{25}$$

**Proof.** Integrating $1/(1 - t)$ between 0 and $a_{j}$ gives $- log\left( 1 - a_{j} \right) \leq a_{j}/\left( 1 - a_{\max} \right)\text{.}$ Sum and exponentiate. ∎

This is a retained-sensitivity guarantee. It is not a variance estimate unless a separate probabilistic model is supplied. A controller can budget spectral spend directly, or conservatively budget total gate strength when $\alpha_{j}$ and the spectrum are bounded.

## 11.2 Exactly when several reads equal one stronger read

**Theorem 11.3 (the single-penalty exception).** Suppose $\alpha > 0$ and an ungated fixed-bank read is applied $n \geq 2$ times. On a positive eigendirection $\lambda\text{,}$ an equivalent single-read ratio would have to be

$$\alpha_{eff}(\lambda) = \frac{(1 + \alpha\lambda)^{n} - 1}{\lambda}. \tag{26}$$

A common ratio gives the same affine read for all proposals if and only if all positive eigenvalues of $A$ are equal. If there are no positive eigenvalues, all reads are the identity. Equality on one particular proposal can occur under weaker conditions when its error occupies only one eigenspace.

**Proof.** Match the gains $(1 + \alpha\lambda)^{- n}$ and $\left( 1 + \alpha_{eff}\lambda \right)^{- 1}\text{.}$ By the binomial expansion, (26) is a positive constant plus strictly increasing positive powers of $\lambda$ when $n \geq 2\text{;}$ it is strictly increasing on $(0,\infty)\text{.}$ Two distinct positive eigenvalues therefore demand different ratios. Conversely one common positive eigenvalue gives the same gain in all observed directions, the private gain is one, and the affine fixed-point set is the same. ∎

For $\alpha = 0.5$ and five reads, eigenvalues 1 and 4 require ratios 6.59375 and 60.5. If every positive eigenvalue is 4, the single ratio 60.5 works exactly. This corrects the categorical V2 statement that no single $\beta$ can reproduce multiple reads. Its numerical anisotropic example was valid; the unrestricted generalization was not.

## 11.3 Sensitivity is not posterior uncertainty

**Proposition 11.4 (Gaussian interpretation and reuse).** Suppose the prior really is $z \sim N\left( u,\mu^{- 1}I \right)\text{,}$ and $b$ is conditionally Gaussian with mean $Cz$ and covariance $\beta^{- 1}I\text{,}$ where $\beta > 0\text{.}$ The posterior mean is the quadratic read and its covariance is $\Sigma = (\mu I + \beta A)^{- 1}\text{.}$ If $n$ conditionally independent equal-valued observations are supplied, the prior-mean gain is

$$J_{n}^{Bayes} = (I + n\alpha A)^{- 1},\quad\quad J_{n}^{prox} = (I + \alpha A)^{- n}. \tag{27}$$

For $n > 1$ and any positive eigenvalue, the proximal gain is strictly smaller.

**Proof.** Completing the Gaussian quadratic gives the mean and covariance. Independent likelihoods add their precision matrices, yielding $J_{n}^{Bayes}\text{.}$ Proximal iteration instead recentres the same fixed-precision penalty at the previous mean, giving $J_{n}^{prox}\text{.}$ The strict inequality follows from $(1 + t)^{n} > 1 + nt$ for $t > 0\text{.}$ ∎

For five operations with $\alpha\lambda = 0.5\text{,}$ these gains are 0.285714 and 0.131687. Observing the exact same random event twice is not new independent evidence: Bayesian conditioning on it again changes nothing. Equation (27) compares a declared independent-data model with proximal optimization, not a license to count duplicated anchors as independent. Separator anchors produced by one model are commonly dependent, so confidence must not be inferred from their count alone.

![](fig/image3.png){width=100%}

**Figure 3.** Left: the two exact gains in (27), with $\alpha\lambda = 0.5\text{.}$ Right: the residual floor in Example 10.2 changes when a second incompatible pin is imposed on the same tree topology. These are algebraic examples, not language-model measurements.

# 12. Robust reads and changing effective coverage

## 12.1 What a Huber cap actually bounds

For a scalar residual, define $\rho_{\delta}(t) = t^{2}/2$ when $|t| \leq \delta\text{,}$ and $\delta|t| - \delta^{2}/2$ otherwise. Its derivative is $\psi_{\delta}(t) = clip(t, - \delta,\delta)\text{.}$ The robust read is

$$R_{b}^{H}(u) = \underset{z}{argmin}\left\{ \frac{\mu}{2} \parallel z - u \parallel^{2} + \beta\sum_{i}^{}\rho_{\delta}\left( c_{i}^{\top}z - b_{i} \right) \right\}. \tag{28}$$

All rows and thresholds refer to calibrated scalar residuals. The objective is coercive and $\mu$-strongly convex, so it has one minimizer. Proposition 6 bounds displacement from the prior by $(\beta\delta/\mu)\sum_{i}^{} \parallel c_{i} \parallel \text{.}$ That is not the same quantity as displacement between the solutions for two different banks.

**Theorem 12.1 (uniform finite-corruption stability).** Let $b,b'$ differ only on an index set $S\text{,}$ with the same $C,u,\mu,\beta,\delta\text{.}$ Then

$$\parallel R_{b'}^{H}(u) - R_{b}^{H}(u) \parallel \leq \frac{2\beta\delta}{\mu}\sum_{i \in S}^{} \parallel c_{i} \parallel . \tag{29}$$

The bound is independent of corruption amplitudes. The factor two cannot in general be omitted.

**Proof.** Let $F_{b}$ be the objective gradient. It is $\mu$-strongly monotone, so the distance between its zero and any point $w$ is at most $\parallel F_{b}(w) \parallel /\mu\text{.}$ Take $w = R_{b'}^{H}(u)\text{,}$ use $F_{b'}(w) = 0\text{,}$ and subtract gradients. Only rows in $S$ remain. Each score difference is at most $2\delta\text{,}$ proving (29). For one scalar row $c = 1\text{,}$ sufficiently large positive and negative observations produce solutions $u + \beta\delta/\mu$ and $u - \beta\delta/\mu\text{,}$ attaining the factor two. ∎

The cap controls fixed-map sensitivity to values; it does not control adversarial changes of the maps, degrees or semantic types. Many corrupted rows can still exert a large total force. V2's numerical shift 1.35 was below its per-coordinate prior cap 1.5, but a clean-to-corrupt shift is not universally bounded by one such cap.

## 12.2 Robustness changes the observed subspace

**Lemma 12.2 (local active-set sensitivity).** At a solution where no residual has magnitude exactly $\delta\text{,}$ let $W$ be diagonal with $W_{ii} = 1$ for $\left| c_{i}^{\top}z - b_{i} \right| < \delta$ and zero otherwise. In a neighbourhood with the same active set,

$$\frac{\partial R_{b}^{H}}{\partial u} = \mu\left( \mu I + \beta C^{\top}WC \right)^{- 1}. \tag{30}$$

**Proof.** Differentiate the stationarity equation. Unsaturated Huber scores have derivative one, saturated scores have derivative zero, and the positive prior curvature makes the resulting Jacobian invertible. ∎

Consequently the unit-gain subspace can grow from $\ker C$ to $\ker\left( W^{1/2}C \right)\text{.}$ This is an intentional consequence of capping outliers, but it weakens curvature-based coverage. With $C = I_{2}\text{,}$ $u = (0,0)\text{,}$ $b = (100,0)\text{,}$ $\mu = 1\text{,}$ $\beta = 3$ and $\delta = 0.5\text{,}$ the read is $(1.5,0)$ and the gains are 1 and 0.25. The large first observation still exerts a constant capped force; it no longer supplies local curvature.

Elementwise Huber loss depends on the chosen axes inside a vector overlap. For coordinate-free overlap treatment, use one radial Huber penalty $\rho_{\delta}\left( \parallel r_{e} \parallel_{W_{e}} \right)$ per edge block. A coordinate change with the transformed metric leaves each norm unchanged, so the uniqueness argument in Theorem 9.2 proves covariance for this block version too. It is a different robust model and should be ablated, especially when an edge contains both a good and a corrupted coordinate.

# 13. Exact consolidation of a quadratic anchor bank

## 13.1 What can be stored without changing the read

**Theorem 13.1 (exact quadratic read statistics).** For one fixed context, branch and adapter version, a bank $(C,b)$ can be replaced for quadratic-read purposes by

$$A = C^{\top}C,\quad\quad d = C^{\top}b,\quad\quad e = b^{\top}b. \tag{31}$$

For every proposal $u$ and every $\mu > 0,\beta \geq 0\text{,}$ the read and its full objective are determined by

::: {custom-style="Equation"}
$Hz = \mu u + \beta d,\quad H = \mu I + \beta A,$
:::

$$\parallel Cz - b \parallel^{2} = z^{\top}Az - 2d^{\top}z + e. \tag{32}$$

Statistics from disjoint eligible bank portions add exactly.

**Proof.** Expand the squared residual and collect coefficients of the quadratic polynomial in $z\text{.}$ The normal equation follows by differentiating. Summing residual energies sums those same coefficients. ∎

This is an exact short-term to long-term consolidation rule for this read class. It preserves the specified energy, not the full archive. It uses $O\left( r^{2} \right)$ numbers per eligible group rather than $O(mr)$ dense anchor coordinates, which is advantageous only when the group is sufficiently large. The scalar $e$ is needed for absolute residuals and objective values, although $A,d$ suffice for the minimizer. Counts, evidence dependence, provenance and semantic eligibility still require separate metadata.

**Corollary 13.2 (one-anchor insertion).** Suppose $Hz = h$ is the current normal equation and a new observation adds energy $\tau\left( c^{\top}z - y \right)^{2}/2\text{,}$ with $\tau \geq 0\text{.}$ Then

$$z_{new} = z + \frac{\tau H^{- 1}c}{1 + \tau c^{\top}H^{- 1}c}\left( y - c^{\top}z \right). \tag{33}$$

**Proof.** Substitute the right-hand side into $\left( H + \tau cc^{\top} \right)z_{new} = h + \tau cy\text{.}$ The denominator is positive because $H$ is positive definite. ∎

This rank-one formula supplies a cheap insertion check. Store or update a factorization rather than explicitly forming $H^{- 1}\text{.}$ Its denominator tempers the correction by the observation's leverage. Deleting or individually auditing an anchor still needs its contribution or a replayable record. Arbitrary query-dependent retrieval cannot be recovered from one merged summary, so eligibility groups must be formed before consolidation.

## 13.2 Why the same compression does not preserve robust reads

**Proposition 13.3 (equal quadratic statistics can hide different robust reads).** In one dimension, use three identity observations and either bank $b = ( - 1,0,1)$ or $b' = (1,1, - 2)/\sqrt{3}\text{.}$ Both have $A = 3\text{,}$ $d = 0$ and $e = 2\text{.}$ With $u = 0\text{,}$ $\mu = \beta = 1$ and $\delta = 0.5\text{,}$ their Huber reads are respectively 0 and $\left( 2/\sqrt{3} - 0.5 \right)/3\text{,}$ approximately 0.218234.

**Proof.** The statistics follow by direct summation. The first robust objective is symmetric and strictly convex, so its minimizer is zero. For the second bank at the stated positive candidate, the first two residuals lie strictly inside the Huber quadratic region and the third is saturated positive. Its stationarity equation is $3z - 2/\sqrt{3} + 0.5 = 0\text{.}$ Strong convexity makes that stationary point the unique solution. ∎

Thus $(A,d,e)$ is not sufficient for arbitrary Huber reads, despite being exact for every quadratic read. This does not prove that all robust compression is impossible. It specifies exactly which proposed consolidation shortcut fails. A robust memory needs richer summaries, an approximation guarantee, or retained observations.

# 14. When vertical transport commutes with a horizontal read

Naturality of restrictions preserves compatibility, as Proposition 3 states. A read also uses adjoints and metrics. Consequently the commuting square alone need not intertwine the optimization update.

**Theorem 14.1 (read equivariance under isometric transport).** Let two calibrated layers have operators $C_{0},C_{1}\text{.}$ Let $T$ and $S$ be orthogonal isomorphisms on current-state and observation spaces, respectively. Use the same $\mu,\beta$ at both layers. If $C_{1}T = SC_{0}\text{,}$ then

$$R_{C_{1},Sb}(Tu) = TR_{C_{0},b}(u). \tag{34}$$

**Proof.** Substitute $z_{1} = Tz_{0}$ into the layer-one objective. Orthogonality preserves the prior norm, and $C_{1}Tz_{0} - Sb = S\left( C_{0}z_{0} - b \right)$ preserves the residual norm. The two strictly convex problems are therefore identical under the isomorphism, proving (34). ∎

The metric version uses isometries with respect to the declared state and edge metrics. This theorem is about an explicit linear diagram, not nonlinear transformer blocks. For changing bases, first use the inverse-image construction $\Phi_{\mathcal{l}}^{- 1}$ and then check the resulting coefficient maps and metrics; array shape matching does not establish the hypothesis.

**Counterexample 14.2 (a commuting square without metric compatibility).** Take scalar $C_{0} = 1\text{,}$ $C_{1} = 2\text{,}$ $T = 1$ and $S = 2\text{.}$ Then $C_{1}T = SC_{0}\text{.}$ With unchanged Euclidean metrics, $u = 1\text{,}$ $b = 0$ and $\mu = \beta = 1\text{,}$ the reads are 0.5 and 0.2. They do not intertwine. The map $S$ rescales the penalty; it is not an isometry in the metric being used. Transforming that metric as in Theorem 9.2 repairs the comparison.

**Proposition 14.3 (a bound for approximate read equivariance).** Retain orthogonal $T,S$ but allow defect $D = C_{1}T - SC_{0}\text{.}$ Put $z_{0} = R_{C_{0},b}(u)$ and $z_{1} = R_{C_{1},Sb}(Tu)\text{.}$ Then

$$\parallel z_{1} - Tz_{0} \parallel \leq \frac{\beta}{\mu} \parallel D \parallel \left( \parallel b \parallel + \left( \parallel C_{1} \parallel + \parallel C_{0} \parallel \right) \parallel z_{0} \parallel \right). \tag{35}$$

**Proof.** Write $H_{i} = \mu I + \beta C_{i}^{\top}C_{i}$ and $h_{i}$ for their right-hand sides. Then $H_{1}\left( z_{1} - Tz_{0} \right) = \left( h_{1} - Th_{0} \right) - \left( H_{1}T - TH_{0} \right)z_{0}\text{.}$ Orthogonality gives $\parallel h_{1} - Th_{0} \parallel \leq \beta \parallel D \parallel \parallel b \parallel \text{.}$ With $E = C_{1}T$ and $F = SC_{0}\text{,}$ the identity $E^{\top}E - F^{\top}F = E^{\top}D + D^{\top}F$ bounds the second operator by $\beta\left( \parallel C_{1} \parallel + \parallel C_{0} \parallel \right) \parallel D \parallel \text{.}$ Finally $\parallel H_{1}^{- 1} \parallel \leq 1/\mu\text{.}$ ∎

The bound is conservative, but it connects a measured square defect to an actual discrepancy between reads. It also states what Proposition 3 did not: preservation of compatible states is weaker than equivariance of a metric optimization step.

# 15. Stability of the reasoning loop and implementation error

## 15.1 A stable read need not give a stable loop

For a fixed bank in Euclidean coordinates, write $R(u) = Ju + c\text{.}$ Let a linear surrogate for the backbone feedback be $F(x) = Mx + a\text{.}$ The loop is $x_{k + 1} = R\left( F\left( x_{k} \right) \right)\text{.}$

**Theorem 15.1 (exact linear closed-loop criterion).** All initial states converge to one common fixed point if and only if

$$\rho(JM) < 1,\quad\quad x_{\text{*}} = (I - JM)^{- 1}(Ja + c). \tag{36}$$

**Proof.** Differences between two trajectories evolve by powers of $JM\text{.}$ In finite dimensions these powers tend to zero exactly when every eigenvalue has modulus less than one, by the Jordan form. In that case $I - JM$ is invertible and subtracting the displayed fixed point proves convergence. Conversely, convergence to one point for all initial states forces those powers to vanish. ∎

For example, $J = diag(0.5,1)$ is a valid read gain with one private direction. If $M = diag(1,1.1)\text{,}$ the loop has spectral radius 1.1 and is unstable. The read suppresses the first direction but leaves the unstable private direction untouched. A control $M = diag(1.2,0.8)$ instead gives radius 0.8. Neither statement predicts how a trained nonlinear language model will behave.

For a nonlinear feedback map on a closed convex invariant set, a uniform derivative bound $\parallel J\, DF(x) \parallel \leq q < 1$ for all $x$ is sufficient for a unique attracting fixed point by the contraction theorem. Hard retrieval switches can invalidate differentiability or continuity, so that criterion requires a fixed bank or a separately controlled retrieval map. Small spectral radius at one tangent is only local evidence, and nonnormal matrices can exhibit transient amplification before asymptotic decay.

## 15.2 Certifying an inexact numerical read

**Lemma 15.2 (state error from a solve residual).** In Euclidean coordinates let $Hz = h$ be the exact quadratic system and $\widehat{z}$ an approximate solution. Then

$$\parallel \widehat{z} - z \parallel \leq \frac{\parallel H\widehat{z} - h \parallel}{\mu}. \tag{37}$$

**Proof.** The error is $H^{- 1}\left( H\widehat{z} - h \right)$ and $\lambda_{\min}(H) \geq \mu\text{.}$ ∎

For a nonidentity prior metric the denominator is at least $\mu\lambda_{\min}(G)\text{.}$ With strongly convex Huber objectives, the analogous stationarity certificate is $\parallel \widehat{z} - z \parallel \leq \parallel \nabla f\left( \widehat{z} \right) \parallel /\mu\text{.}$ These are a posteriori bounds in exact arithmetic for the declared system. Floating-point residuals still require conditioning and roundoff checks; a small computed residual alone is not a universal forward-error guarantee.

## 15.3 Conjectures and open mathematical tasks

The results above settle fixed-map algebra, not the utility of learned separator contexts. We retain H1--H7 in Section 16 as empirical conjectures with numerical success criteria. They assert accuracy, causal use or cost benefits that these theorems do not imply. An unresolved estimate is not evidence of absence.

Three mathematical tasks remain before a stronger implementation claim. First, characterize identifiability of learned restrictions under answer supervision and explicit interventions; Theorem 9.2 already exhibits a coordinate ambiguity, while zero-map collapse exhibits a worse degeneracy. Second, extend the spectral spending criterion to changing, noncommuting banks without pretending that one fixed private subspace survives. Third, derive robust consolidation summaries with an explicit error guarantee over an identified family of future queries. Proposition 13.3 rules out only the three quadratic statistics, not that broader programme.

The immediate experiment is therefore still a known-context chain task. Correct maps, branch eligibility and a fixed read budget make the theorem hypotheses checkable. Only after that experiment should the model be asked to infer its own horizontal base.

# 16. Empirical conjectures and experiments

## 16.1 Work stages

**S0: reproducible baseline.** Reproduce Sep-Latent with dataset identities, split rules, attention-decay implementation, alignment convention, model revision and stopping policy recorded. Establish both the paper-faithful baseline and a controlled indexed-alignment variant. Match training budgets where possible and report deviations. Do not attribute a benefit from indexed alignment to sheaf gluing.

**S1: known contexts.** Use synthetic chain and cycle objectives with exact variable identities, partial observations and held-out compositions. Vary overlap coverage, noise, contradictory observations and branch ambiguity independently. Test the read without a language model first, then attach a frozen model. This stage isolates the effect of correct restrictions.

**S2: causal adapter study.** Train small adapters and correction gates on a frozen backbone. Compare matched latent-step budgets and parameter counts. Intervene on shared variables, private variables, retrieved anchors and separator placement. Report whether interventions change verified answers in the required direction.

**S3: learned structure.** Only after S1--S2, learn context assignment or restrictions. Track singular values, zero-map collapse, branch errors and coverage. Include an unrestricted block-matrix read with the same parameter budget: when two implementations compute the same operator, the sheaf vocabulary alone cannot explain an advantage.

## 16.2 Proposed preregistration

Table 3 gives proposed decision criteria to fix before training. They are planning thresholds, not confidence intervals or observed effects. Use paired task instances and seed-aware uncertainty estimates. A study that cannot resolve a threshold should report insufficient evidence rather than success. Failure to meet a success criterion is not necessarily evidence that the underlying effect is absent.

**Table 3.** Proposed hypotheses and decision rules for the planned success claims.

  -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Hypothesis                                   Prediction fixed in advance                                                                                                                              Failure criterion
  -------------------------------------------- -------------------------------------------------------------------------------------------------------------------------------------------------------- -------------------------------------------------------------------------------------------
  H1: typed partial gluing helps composition   At least 3 percentage points higher verified accuracy than indexed Sep-Latent on held-out chain compositions at matched backbone calls                   Gain below 3 points, or its uncertainty does not support the threshold

  H2: context maps matter                      Correct maps beat an edge-permuted control by at least 2 points under otherwise identical training                                                       Permuted maps match or beat correct maps within uncertainty

  H3: anchors carry used information           At least 75% of valid shared-variable interventions produce the required answer change; private interventions preserve at least 95% of correct answers   Either threshold is missed, or only retrained rather than within-model interventions work

  H4: structural stopping is useful            At least 25% fewer verifier-detected premature exits with no more than 10% extra mean backbone calls                                                     Error reduction or call budget fails

  H5: compression remains worthwhile           At matched verified accuracy, at least 10% lower median end-to-end latency than the controlled explicit-CoT baseline                                     Latency criterion fails after retrieval, solves and fallback costs are included
  -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Conjecture H6 on repeated reads.** At matched backbone calls, a controller that re-reads only when new anchors arrive should match or exceed one that re-reads every step on held-out compositions, and should keep higher observed-direction sensitivity to the initial proposal. Fails if per-step re-reading is better by at least 2 points.

**Conjecture H7 on robust reads.** With 10% of anchors corrupted by a synthetic error, the Huber read should keep verified accuracy within 3 points of clean, while the quadratic read falls by more. Fails if the gap does not appear or clean accuracy drops by more than 2 points.

H2 needs both evaluation-time corruption of a trained system and independently retrained controls; they answer different questions about reliance and learnability. H3 interventions must preserve task validity and avoid arbitrary off-manifold hidden-vector edits. H5 uses the same hardware, batching, answer budget and correctness criterion. A model that merely stops early on difficult tasks must not count as efficient.

## 16.3 Baselines measurements and leakage controls

Essential controls are: original Sep-Latent; indexed alignment without horizontal reads; a parameter-matched extra MLP; fixed pause vectors; identity full-vector consensus; random or permuted restrictions; generic learned block-matrix aggregation; and $\beta = 0\text{.}$ For sheaf variants compare correct typed contexts, nearest-neighbour contexts and parser-predicted contexts. These separate the value of extra computation, the value of correct metadata and the value of the structured read.

Primary outcomes are verified task accuracy and violation of known semantic constraints. Secondary outcomes include overlap residual, observed rank, hidden-feature effective rank, smallest positive singular values, per-branch accuracy, invalid branch mixtures and fallback rate. Plot accuracy against actual backbone calls and end-to-end latency, not just output tokens. Track prompt and answer lengths, cache bytes, solver time, FLOPs estimates and peak device memory.

Split augmented questions by source template or source problem before training. Hold out variable combinations and branch structures, not merely rephrasings. Context labels and map construction must be available from the permitted prefix at inference. Include paraphrases and alternative separator placement. For causal tests, shuffle eligible anchor contents, erase selected shared information, preserve private information, and compare with equally sized irrelevant perturbations. A low-dimensional latent plot is a diagnostic, not a success criterion.

# 17. Integration into the sheaf papers and the memory programme

In **Part I**, this idea supplies a concrete distinction between a stalk, an observation and a vertical fibre diagram. It also motivates preserving indexed layer data: pooled distillation can erase the very distinctions that a vertical representation is meant to study. No amendment to the underlying sheaf definitions is needed.

In **Part II**, the causal observation star becomes a practical read: separator anchors provide pinned local observations and the current latent proposal is the free centre. The fixed-map quadratic energy gives a transparent first implementation. Robust convex alternatives can follow after the quadratic mechanism is understood.

In **Part III**, multilayer sidecars provide a test case for commuting squares, base changes and defects. Theorem 14.1 adds the metric condition needed for the reads themselves to intertwine. A nonlinear transformer should appear as the source of observations and local tangents, not be declared globally linear to obtain an attractive barcode. Learned covers must be treated with the inverse-image construction and, where necessary, zigzag indexing.

In **SheafFarm** \[8\], the proposal is a new instance of the distinction between an operator and a typed compatibility model. If a generic operator realizes the same read, one cannot infer additional computational power from the word "sheaf." The added value is an auditable specification of what information is shared and what a residual certifies. This fits the project's emphasis on declared maps, units and limited certificates.

For **short-term to long-term memory**, the anchor bank is initially working memory. A later consolidation stage could promote only externally verified, well-covered anchors into a versioned store, retaining context, restrictions, provenance and confidence. Theorem 13.1 gives an exact quadratic-read summary within each eligible branch and adapter version; Proposition 13.3 shows why the same summary fails for robust reads. Promotion should optimize storage cost against future verified utility and interference. It must not average incompatible coordinates or erase conflicting evidence. This is an algorithmic proposal, not evidence of a neocortical mechanism.

The most informative first integration is S1 on chain-structured partial-information objectives, followed by the frozen-backbone adapter study. If correct maps do not beat matched generic controls there, adding learned topology and multilayer losses would obscure the answer. If they do, the next question is whether inference-time context assignment can recover enough of that benefit without privileged labels.

# 18. Numerical checks and mathematical scope

The attached V2 source was rerun before revision. All 21 of its checks passed. This revision retains those reproducible examples and adds 32 checks, for 53 passing checks in total. The new script uses float64, NumPy 2.3.5 and seed 20261021; the retained V2 script uses seed 20261020. Checks of exact finite-dimensional identities are numerical illustrations of proofs, not substitutes for them.

The 32 new checks cover metric covariance and gain bounds, grounded obstructions, read schedules and Gaussian reuse, robust stability and active coverage, exact consolidation, vertical equivariance, loop stability and solve error. The default absolute tolerance is $10^{- 10}\text{;}$ robust stationarity uses $10^{- 9}$ and the active-set finite difference uses $10^{- 8}\text{.}$ Legacy checks retain their original tolerances, and every boolean is checked. The twenty-read example uses $g_{j} = 1\text{,}$ $\lambda = 1$ and $\alpha_{j} = 0.1/(j + 1)^{2}$ for $j = 0,\ldots,19\text{.}$

Table 4 gives selected numerical outcomes. All entries come from the result files except the analytic expressions displayed beside them. No trained-model result has been added. For the approximate vertical example the measured read discrepancy is 0.025978 and the conservative bound in (35) is 0.300377.

**Table 4.** Selected reproducible finite examples.

  --------------------------------------------------------------------------------------------------------------
  Example                                      Quantity                                  Value
  -------------------------------------------- ----------------------------------------- -----------------------
  Grounded tree                                Unavoidable residual norm                 1.414214

  Five reads at ratio 0.5                      Proximal gain at eigenvalue 1             0.131687

  Five equal-valued independent observations   Gaussian prior-mean gain                  0.285714

  Twenty decreasing-strength reads             Retained gain and certified lower bound   0.856826 and 0.848155

  Robust consolidation counterexample          Difference between Huber reads            0.218234

  Commuting but nonisometric scalar square     Difference between reads                  0.300000

  Loop with an unstable private direction      Spectral radius                           1.100000
  --------------------------------------------------------------------------------------------------------------

The equal-singular-value check reproduces five reads by one ratio 60.5; the anisotropic check requires different ratios 6.59375 and 60.5. Thus the revision tests both sides of Theorem 11.3 rather than only its generic case. The Huber finite-difference check measures gains 1 and 0.25 when one observation is saturated, matching Lemma 12.2. Inexact robust solves are checked by their stationarity residual.

Theorems 9.2--15.1 concern declared linear data spaces, maps and optimization problems. They do not prove semantic correctness, context identifiability, faithful reasoning, generalization or lower latency. The added results determine how an implementation should preserve units, budget repeated corrections, detect irreducible disagreement, consolidate eligible data and separate read stability from loop stability. H1--H7 remain the required empirical tests.

Version 4 leaves these 53 checks unchanged. It adds 25 cross-language results from the immutable C# kernel of Appendix A. Section 19 reports them, and Table 5 gives the agreement with NumPy.

# 19. Immutable C# numerical explorations

Version 3 checked its examples with NumPy scripts. Version 4 adds an independent kernel written in C# in an immutable style. Matrices are records over immutable arrays, every operation is a pure static function, and the random-number generator is itself a value: a draw returns a number and the next generator rather than changing state. The design serves two purposes. First, every printed result is recomputed in Python with different algorithms: LAPACK solves and eigenvalues, iteratively reweighted least squares for the robust read, Householder QR and the log-gamma function. The random inputs are nevertheless bit-identical, because both languages implement the same SplitMix64 stream [12] and the same Box–Muller transform [13]. Second, seeded Monte Carlo shows how sharp Version 3's bounds are, which single examples cannot show.

## 19.1 Cross-language agreement

The kernel prints 25 named results; Appendix A lists the code. Each value is compared with its NumPy recomputation by $|a-b|/\max(1,|b|)\text{,}$ with tolerance $10^{-9}\text{.}$ The finite-difference gain uses $10^{-7}$ because central differences carry truncation and cancellation error. Two roundoff quantities, the metric-covariance residual and the largest robust stationarity residual, must both lie below $10^{-10}$ in each language. The Sherman–Morrison drift is a property of the C# floating-point path and is checked only against that threshold. All 25 results pass. Table 5 shows a selection; the complete comparison is in the source archive.

**Table 5.** Selected C# results and their largest difference from the independent NumPy recomputation.

| Result | C# value | NumPy max difference |
|:--|:--|:--|
| Grounded-tree residual (Example 10.2) | 1.4142135623730951 | $2.2\times 10^{-16}$ |
| Twenty reads: gain and floor (25) | 0.856826 and 0.848155 | $3.3\times 10^{-16}$ |
| Equivalent ratios (26) | 6.59375 and 60.5 | 0 |
| Huber consolidation counterexample | 0.218234 | $2.8\times 10^{-17}$ |
| Anchor influence and bound (20) | 1.0000000 and 1 | $1.1\times 10^{-16}$ |
| Harmonic gain, $N=10^4$ | 0.0088619369 | $2.6\times 10^{-13}$ |
| Robust ratio: maximum and median | 0.4259 and 0.09914 | $1.7\times 10^{-16}$ |
| Loop threshold, $k=1$: median | 2.4551 | $2.0\times 10^{-13}$ |
| Equivariance ratio: median | 0.03349 | $1.9\times 10^{-16}$ |

The Version 3 values are reproduced to the printed precision. The anchor-influence example also confirms that (20) is sharp: a singular value $\sigma=\sqrt{\mu/\beta}$ attains $\|K\|=\tfrac12\sqrt{\beta/\mu}\text{.}$ Metric covariance (Theorem 9.2) holds on a random metric to $1.8\times 10^{-13}\text{.}$

## 19.2 Harmonic schedules give an exact power law

Theorem 11.1 separates schedules whose spend diverges, and therefore harden, from those with a positive floor. The boundary case has a closed form.

**Proposition 19.1 (harmonic schedule).** Use unit gates and ratios $\alpha_j=c/(j+1)$ with $c>0\text{.}$ On an eigendirection with eigenvalue $\lambda>0\text{,}$ the retained gain (23) after $N$ reads is

$$\gamma_N(\lambda)=\frac{\Gamma(N+1)\,\Gamma(1+c\lambda)}{\Gamma(N+1+c\lambda)}\;\sim\;\Gamma(1+c\lambda)\,N^{-c\lambda}. \tag{38}$$

**Proof.** With $g_j=1$ each factor of (23) equals $1/(1+\alpha_j\lambda)=(j+1)/(j+1+c\lambda)\text{.}$ The product of $m/(m+c\lambda)$ over $m=1,\dots,N$ is $\Gamma(N+1)\Gamma(1+c\lambda)/\Gamma(N+1+c\lambda)$, by $\Gamma(x+1)=x\Gamma(x)\text{.}$ The asymptotic form follows from $\Gamma(N+1)/\Gamma(N+1+a)\sim N^{-a}$ as $N$ grows. ∎

**Corollary 19.2 (three regimes).** Put $\alpha_j=c(j+1)^{-p}$ with unit gates, and write $H_N(p)$ for the sum of $m^{-p}$ over $m=1,\dots,N\text{.}$ Then

$$-c\lambda H_N(p)\le\log\gamma_N(\lambda)\le -c\lambda H_N(p)+\tfrac12(c\lambda)^2H_N(2p). \tag{39}$$

For $p<1$, $\log\gamma_N(\lambda)$ behaves as $-c\lambda N^{1-p}/(1-p)$, so the gain decays faster than any power. For $p=1$ the decay is the power law (38). For $p>1$ the gain has a positive limit; for $p=2$ the limit is $\pi\sqrt{c\lambda}/\sinh(\pi\sqrt{c\lambda})$.

**Proof.** Apply $x-x^2/2\le\log(1+x)\le x$ to each factor $1/(1+c\lambda m^{-p})$ and sum. For $p<1$ the second sum has lower order than the first. The $p=2$ limit is Euler's product $\sinh(\pi x)/(\pi x)=\prod_m(1+x^2/m^2)$ with $x^2=c\lambda\text{.}$ ∎

With $c=0.5$ and $\lambda=1$ the kernel gives the following retained gains. After $N=10$ reads they are 0.10977, 0.27026 and 0.51132 for $p=\tfrac12,1,2$. After $N=10^4$ reads they are $2.4\times 10^{-43}$, 0.00886194 and 0.487602 (Figure 4). The harmonic product agrees with the Gamma form to $1.3\times 10^{-11}$ relative, the accumulated roundoff of $10^4$ factors. Its asymptote $\Gamma(1.5)\,10^{-2}=0.0088623$ is already accurate to four digits. The $p=2$ value approaches its limit 0.487577 from above.

![](fig/fig4_schedules.png){width=100%}

**Figure 4.** Retained gain on $\lambda=1$ for three gate-free schedules $\alpha_j=0.5(j+1)^{-p}\text{.}$ Circles mark the closed form (38); the dashed line is its asymptote. Computed by the C# kernel and redrawn from the validated NumPy values.

The harmonic schedule hardens, because its spend diverges, but only logarithmically. The read then acts on the spectrum as $\Gamma(1+c\lambda)e^{-c\lambda\log N}$: up to a smooth factor, this is the heat-flow filter at time $c\log N$. Two eigendirections separate as $N^{-c(\lambda_1-\lambda_2)}$, and doubling the number of reads multiplies the retained gain by about $2^{-c\lambda}\text{.}$ A controller that wants predictable, scale-dependent hardening can therefore choose $c$; it needs a summable schedule only when it wants a floor. These statements concern a fixed bank with commuting reads, the setting of Theorem 11.1.

## 19.3 How tight is the finite-corruption bound?

The experiment uses $q=8$ observation rows on $r=4$ coordinates, with $\mu=1$, $\beta=3$ and $\delta=0.5$. In each of 400 trials the first two observations are corrupted by $100$ times a standard normal draw. The ratio of the measured shift to the bound (29) had maximum 0.426, median 0.0991 and mean 0.117 (Figure 5b). The bound never failed. In typical trials it is about ten times too large. The factor two is attained only in the scalar construction of Theorem 12.1, which the kernel reproduces with shift and bound both equal to 3. The slack has a clear source. The proof bounds the inverse curvature by $1/\mu$, ignoring the curvature $\beta c_ic_i^\top$ of the clean rows that remain in the quadratic zone. A sharper bound would need control of the active set along the whole segment between the two solutions, which (29) deliberately avoids.

**A solver episode.** The first C# implementation used undamped semismooth Newton steps [14], started from the quadratic read. The first run reported a maximum ratio of 4.79 and a median of 1.16. Taken at face value, 247 of the 400 trials refuted Theorem 12.1. The stationarity certificate of Section 15.2 shows what happened instead. In every trial at least one of the two solves ended with a gradient norm far from zero, as large as 41. The undamped iteration was cycling between active sets. Armijo backtracking on the strongly convex objective [15] restored convergence. Across all 800 solves, the largest certificate is now $1.6\times 10^{-14}$, so every computed read is within that distance of the exact read divided by $\mu=1\text{.}$ The NumPy script reproduces both the faulty and the corrected numbers exactly. The procedural lesson is that a numerical counterexample to a proved bound must carry its certificate before it is believed.

## 19.4 Exact insertion does not drift in the tested regime

Corollary 13.2 updates the read after a new anchor by a rank-one formula. The experiment stores the inverse Hessian explicitly and applies the Sherman–Morrison update [16] after each of 2,000 Gaussian insertions in $r=16$, with unit prior and unit weight. At $m=10$, $100$, $1000$ and $2000$ insertions, the largest coordinate difference from a fresh Cholesky solve was $1.2\times 10^{-15}$, $2.8\times 10^{-16}$, $1.9\times 10^{-16}$ and $1.6\times 10^{-16}$. The state components are of order $10^{-2}$. The difference does not grow, because insertions only increase the Hessian, so the stored inverse contracts. The result does not cover deletion, where the rank-one weight is negative, or poorly conditioned banks. An implementation should refactorise periodically and can use (37) to decide when.

## 19.5 Loop stability needs mixing

Theorem 15.1 requires $\rho(JM)<1$. Take an orthogonal feedback scaled by a gain, $M=sQ$, so the loop is stable exactly when $s<s^{\text{*}}=1/\rho(JQ)\text{.}$ Here $J=\mu(\mu I+\beta C^\top C)^{-1}$ has eigenvalue one on $\ker C$ and eigenvalues below one elsewhere.

**Proposition 19.3 (when the read adds no loop margin).** For orthogonal $Q$, $\rho(JQ)\le1$. Equality holds if and only if $\ker C$ contains a nonzero subspace invariant under $Q\text{.}$ In particular, if $\ker C\neq0$ and the feedback preserves $\ker C$, then $s^{\text{*}}=1$.

**Proof.** $\|JQ\|\le\|J\|\le1$ gives the inequality. Suppose $JQx=\lambda x$ with complex $x\ne0$ and $|\lambda|=1$. Then $\|JQx\|=\|x\|=\|Qx\|$. Since $J$ is symmetric with eigenvalue one only on $\ker C$, this forces $Qx\in\ker C$ and $JQx=Qx$. Hence $Qx=\lambda x$, so $x\in\ker C$. The real and imaginary parts of $x$ then span a nonzero $Q$-invariant subspace inside $\ker C\text{.}$ Conversely, any nonzero invariant subspace contains a complex eigenvector $x$ of $Q$ with $Jx=x$. That $x$ is an eigenvector of $JQ$ with modulus one. ∎

The experiment takes $r=6$, $\mu=1$ and $\beta=4$, and lets $C$ observe the first $6-k$ coordinates. With no private coordinates ($k=0$), $J=0.2I$ and $s^{\text{*}}=5$ for every $Q$. For $k=1,2,3$, the non-mixing feedback $Q=I$ gives $s^{\text{*}}=1$ exactly, as Proposition 19.3 predicts. Then any amplification of a private direction destabilises the loop, whatever the anchors say. With 100 Haar-random orthogonal $Q$ for each $k$, the medians were 2.46, 1.6 and 1.36. The minima were 1.034, 1.022 and 1.019, and the maxima 3.6, 2.67 and 1.98 (Figure 5a).

![](fig/fig5_loop_robust.png){width=100%}

**Figure 5.** (a) Loop threshold $s^{\text{*}}=1/\rho(JQ)$ for 100 random orthogonal feedbacks at each private dimension $k$ (dots; black bars are medians) and for the non-mixing feedback $Q=I$ (orange bars at one). (b) Ratio of the measured robust shift to the bound (29) in 400 corrupted trials; the bound is the orange line at one.

Mixing helps because it carries private error into observed directions, where the anchors can damp it. The margin shrinks as the private subspace grows, and minima near one show that generic mixing does not guarantee a useful margin. A design therefore needs one of two things: feedback that routes private coordinates through observed ones, or separate damping of private directions, which anchors cannot reach. For a trained model, the computable diagnostic is the spectral radius of $J\,DF$ on held-out states, together with the restriction of $DF$ to the private subspace. The results above are for a linear surrogate with orthogonal feedback. Nonnormal feedback can amplify transiently even when the radius is below one (Section 15.1).

## 19.6 The equivariance bound in practice

The test draws random orthogonal $T$ and $S$ and sets $C_1=SC_0T^\top+0.05E$ with Gaussian $E$, $\mu=1$ and $\beta=2$. Over 300 trials, the ratio of the measured discrepancy to (35) had maximum 0.195, median 0.0335 and minimum 0.00442. Version 3's single example, with ratio 0.086, was typical. The bound never failed and is usually about thirty times too large. It is useful as a guarantee, not as an estimate of the discrepancy.

## 19.7 What the explorations change

The explorations change practice in five ways.

1. **Schedules.** Choose them by regime. A harmonic schedule gives predictable power-law hardening, a summable schedule gives a floor, and $p<1$ hardens almost completely within about a hundred reads.
2. **Bound ratios.** Report measured-to-bound ratios for (29) and (35). Do not read either bound as a calibrated estimate.
3. **Robust solves.** Certify every robust solve, and treat an apparent violation of a theorem as a solver failure until a certificate shows otherwise.
4. **Rank-one updates.** Refactorise periodically after rank-one updates, and test deletions separately.
5. **Loop stability.** Check whether the feedback mixes the private subspace before attributing loop stability to the read.

None of these results is trained-model evidence. They sharpen the fixed-map mathematics on which the proposed experiments rely.

# References

\[1\] Xu, Y., Huang, J., Zhou, Z., Lin, M., Lv, F., Ou, D., Xu, H., and Wu, J. (2026). *Sep-Latent: Separator Tokens as Natural Compression Anchors for Implicit Reasoning.* arXiv:2610.22924v1, 16 October. Attached version consulted, especially §§3--5 and Appendices A--D. https://arxiv.org/abs/2610.22924v1

\[2\] Hao, S., Sukhbaatar, S., Su, D. J., Li, X., Hu, Z., Weston, J., and Tian, Y. (2024; revised 2026). *Training Large Language Models to Reason in a Continuous Latent Space.* arXiv:2412.06769. COLM 2025. https://arxiv.org/abs/2412.06769

\[3\] Shen, Z., Yan, H., Zhang, L., Hu, Z., Du, Y., and He, Y. (2025). *CODI: Compressing Chain-of-Thought into Continuous Space via Self-Distillation.* arXiv:2502.21074. https://arxiv.org/abs/2502.21074

\[4\] Zhang, Y., Tang, B., Ju, T., Duan, S., and Liu, G. (2025). *Do Latent Tokens Think? A Causal and Adversarial Analysis of Chain-of-Continuous-Thought.* arXiv:2512.21711. https://arxiv.org/abs/2512.21711

\[5\] Hansen, J., and Ghrist, R. (2019). *Toward a Spectral Theory of Cellular Sheaves.* Journal of Applied and Computational Topology 3, 315--358. https://arxiv.org/abs/1808.01513

\[6\] Russold, F. (2022). *Persistent Sheaf Cohomology.* arXiv:2204.13446. https://arxiv.org/abs/2204.13446

\[7\] Carlsson, G., and de Silva, V. (2010). *Zigzag Persistence.* Foundations of Computational Mathematics 10, 367--405. https://doi.org/10.1007/s10208-010-9066-0

\[8\] Ghosh, D. P. (2026). *SheafFarm: Some Sheaf-Diffusion Algorithms are More Sheaf Than Others.* Version 3, project manuscript. Used for continuity of notation and research questions; not treated as independent empirical validation.

\[9\] Huber, P. J. (1964). *Robust Estimation of a Location Parameter.* Annals of Mathematical Statistics 35(1), 73--101. https://doi.org/10.1214/aoms/1177703732

\[10\] Parikh, N., and Boyd, S. (2014). *Proximal Algorithms.* Foundations and Trends in Optimization 1(3), 123--231. Author-hosted article and errata. https://web.stanford.edu/\~boyd/papers/prox_algs.html

\[11\] Rockafellar, R. T. (1976). *Monotone Operators and the Proximal Point Algorithm.* SIAM Journal on Control and Optimization 14(5), 877--898. https://doi.org/10.1137/0314056

\[12\] Steele, G. L., Lea, D., and Flood, C. H. (2014). *Fast Splittable Pseudorandom Number Generators.* Proceedings of OOPSLA 2014, ACM, 453--472. https://2014.splashcon.org/event/oopsla2014-fast-splittable-pseudorandom-number-generators

\[13\] Box, G. E. P., and Muller, M. E. (1958). *A Note on the Generation of Random Normal Deviates.* Annals of Mathematical Statistics 29(2), 610--611. https://doi.org/10.1214/aoms/1177706645

\[14\] Qi, L., and Sun, J. (1993). *A Nonsmooth Version of Newton's Method.* Mathematical Programming 58, 353--367. https://doi.org/10.1007/BF01581275

\[15\] Nocedal, J., and Wright, S. J. (2006). *Numerical Optimization*, 2nd edition, Chapter 3. Springer. https://doi.org/10.1007/978-0-387-40065-5

\[16\] Sherman, J., and Morrison, W. J. (1950). *Adjustment of an Inverse Matrix Corresponding to a Change in One Element of a Given Matrix.* Annals of Mathematical Statistics 21(1), 124--127. https://doi.org/10.1214/aoms/1177729893

# Appendix A. The immutable C# kernel

The kernel targets .NET 8 and has no package dependencies. `Sidecar.cs` holds the linear algebra, the generator and the reads. `Program.cs` prints the 25 named results that `cs_validate.py` recomputes. The source archive contains both files, the project file, the validation script and its output.

**A.1 Sidecar.cs**

```csharp
// Separator-anchor sidecar: an immutable reference kernel for Version 4.
// Records hold data; every public function is pure. Numerical routines work
// on private copies (Cholesky, Jacobi, Gelfand iteration) and return new
// immutable values.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace Sidecar;

/// <summary>A dense real matrix, row-major and immutable.</summary>
public sealed record Mat(int Rows, int Cols, Vec Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Mat Build(int r, int c, Func<int, int, double> f) =>
        new(r, c, Enumerable.Range(0, r * c).Select(k => f(k / c, k % c))
                            .ToImmutableArray());

    public static Mat Identity(int n) => Build(n, n, (i, j) => i == j ? 1 : 0);
    public static Mat Diag(params double[] d) =>
        Build(d.Length, d.Length, (i, j) => i == j ? d[i] : 0);
    public static Mat Rows_(params double[][] rows) =>
        Build(rows.Length, rows[0].Length, (i, j) => rows[i][j]);

    public Mat T => Build(Cols, Rows, (i, j) => this[j, i]);
    public Mat Mul(Mat b) =>
        Build(Rows, b.Cols, (i, j) => Enumerable.Range(0, Cols).Sum(k => this[i, k] * b[k, j]));
    public Vec Apply(Vec x) =>
        Enumerable.Range(0, Rows).Select(i => Enumerable.Range(0, Cols)
            .Sum(k => this[i, k] * x[k])).ToImmutableArray();
    public Mat Add(Mat b, double s = 1) => Build(Rows, Cols, (i, j) => this[i, j] + s * b[i, j]);
    public Mat Scale(double s) => Build(Rows, Cols, (i, j) => s * this[i, j]);
    public Mat Row(int i) => Build(1, Cols, (_, j) => this[i, j]);
}

/// <summary>Quadratic-read sufficient statistics (Theorem 13.1).</summary>
public sealed record BankStats(Mat A, Vec D, double E)
{
    public BankStats Merge(BankStats o) =>
        new(A.Add(o.A), V.Add(D, o.D), E + o.E);
}

public static class V
{
    public static Vec Of(params double[] x) => ImmutableArray.Create(x);
    public static Vec Add(Vec a, Vec b, double s = 1) =>
        a.Zip(b, (p, q) => p + s * q).ToImmutableArray();
    public static Vec Scale(Vec a, double s) => a.Select(p => s * p).ToImmutableArray();
    public static double Dot(Vec a, Vec b) => a.Zip(b, (p, q) => p * q).Sum();
    public static double Norm(Vec a) => Math.Sqrt(Dot(a, a));
}

/// <summary>Deterministic SplitMix64 stream, shared with the Python check.</summary>
public sealed record Rng(ulong State)
{
    public (ulong Value, Rng Next) NextU64()
    {
        ulong s = State + 0x9E3779B97F4A7C15UL, z = s;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
        return (z ^ (z >> 31), new Rng(s));
    }

    public (double Value, Rng Next) Uniform()
    {
        var (v, n) = NextU64();
        return ((v >> 11) * (1.0 / 9007199254740992.0), n);
    }

    /// <summary>Standard normal by Box-Muller (one value per two uniforms).</summary>
    public (double Value, Rng Next) Normal()
    {
        var (u1, r1) = Uniform();
        var (u2, r2) = r1.Uniform();
        return (Math.Sqrt(-2 * Math.Log(1 - u1)) * Math.Cos(2 * Math.PI * u2), r2);
    }

    public (Mat Value, Rng Next) NormalMat(int r, int c)
    {
        var vals = new double[r * c]; var g = this;
        for (int k = 0; k < r * c; k++) (vals[k], g) = g.Normal();
        return (new Mat(r, c, vals.ToImmutableArray()), g);
    }
}

public static class LinAlg
{
    /// <summary>Solve H x = h for symmetric positive definite H (Cholesky).</summary>
    public static Vec Solve(Mat h, Vec rhs)
    {
        int n = h.Rows; var l = new double[n, n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j <= i; j++)
            {
                double s = h[i, j];
                for (int k = 0; k < j; k++) s -= l[i, k] * l[j, k];
                l[i, j] = i == j ? Math.Sqrt(s) : s / l[j, j];
            }
        var y = new double[n];
        for (int i = 0; i < n; i++)
        {
            double s = rhs[i];
            for (int k = 0; k < i; k++) s -= l[i, k] * y[k];
            y[i] = s / l[i, i];
        }
        var x = new double[n];
        for (int i = n - 1; i >= 0; i--)
        {
            double s = y[i];
            for (int k = i + 1; k < n; k++) s -= l[k, i] * x[k];
            x[i] = s / l[i, i];
        }
        return x.ToImmutableArray();
    }

    public static Mat Inverse(Mat h) =>
        ColumnsToMat(Enumerable.Range(0, h.Rows)
            .Select(j => Solve(h, Mat.Identity(h.Rows).Row(j).Data)).ToArray());

    static Mat ColumnsToMat(Vec[] cols) =>
        Mat.Build(cols[0].Length, cols.Length, (i, j) => cols[j][i]);

    /// <summary>Eigenvalues (ascending) and eigenvectors of a symmetric matrix
    /// by cyclic Jacobi rotations.</summary>
    public static (Vec Values, Mat Vectors) SymEig(Mat m)
    {
        int n = m.Rows; var a = m.Data.ToArray(); var v = Mat.Identity(n).Data.ToArray();
        for (int sweep = 0; sweep < 100; sweep++)
        {
            double off = 0;
            for (int p = 0; p < n; p++)
                for (int q = p + 1; q < n; q++) off += a[p * n + q] * a[p * n + q];
            if (off < 1e-300) break;
            for (int p = 0; p < n - 1; p++)
                for (int q = p + 1; q < n; q++)
                {
                    double apq = a[p * n + q];
                    if (apq == 0) continue;
                    double th = (a[q * n + q] - a[p * n + p]) / (2 * apq);
                    double t = th == 0 ? 1 : Math.Sign(th) / (Math.Abs(th) + Math.Sqrt(th * th + 1));
                    double c = 1 / Math.Sqrt(t * t + 1), s = t * c;
                    for (int k = 0; k < n; k++)
                        (a[k * n + p], a[k * n + q]) =
                            (c * a[k * n + p] - s * a[k * n + q], s * a[k * n + p] + c * a[k * n + q]);
                    for (int k = 0; k < n; k++)
                        (a[p * n + k], a[q * n + k]) =
                            (c * a[p * n + k] - s * a[q * n + k], s * a[p * n + k] + c * a[q * n + k]);
                    for (int k = 0; k < n; k++)
                        (v[k * n + p], v[k * n + q]) =
                            (c * v[k * n + p] - s * v[k * n + q], s * v[k * n + p] + c * v[k * n + q]);
                }
        }
        var order = Enumerable.Range(0, n).OrderBy(i => a[i * n + i]).ToArray();
        return (order.Select(i => a[i * n + i]).ToImmutableArray(),
                Mat.Build(n, n, (i, j) => v[i * n + order[j]]));
    }

    /// <summary>Moore-Penrose inverse through the eigen-decomposition of C^T C.</summary>
    public static Mat Pinv(Mat c, double tol = 1e-12)
    {
        var (w, q) = SymEig(c.T.Mul(c));
        double top = w.Max(Math.Abs);
        var inv = Mat.Build(w.Length, w.Length,
            (i, j) => i == j && w[i] > tol * Math.Max(top, 1) ? 1 / w[i] : 0);
        return q.Mul(inv).Mul(q.T).Mul(c.T);
    }

    public static double SpectralNorm(Mat m) => Math.Sqrt(SymEig(m.T.Mul(m)).Values.Max());

    /// <summary>Spectral radius by Gelfand's formula, rho = lim ||M^k||^(1/k),
    /// with k = 2^steps by repeated normalised squaring.</summary>
    public static double SpectralRadius(Mat m, int steps = 40)
    {
        double logScale = 0; var p = m;
        for (int s = 0; s < steps; s++)
        {
            double nrm = p.Data.Max(Math.Abs);
            if (nrm == 0) return 0;
            p = p.Scale(1 / nrm); logScale = 2 * (logScale + Math.Log(nrm));
            p = p.Mul(p);
        }
        double fin = Math.Log(p.Data.Max(Math.Abs));
        return Math.Exp((logScale + fin) / Math.Pow(2, steps));
    }

    /// <summary>log Gamma by the Lanczos approximation (g = 7, n = 9).</summary>
    public static double LogGamma(double x)
    {
        double[] c = { 0.99999999999980993, 676.5203681218851, -1259.1392167224028,
            771.32342877765313, -176.61502916214059, 12.507343278686905,
            -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7 };
        if (x < 0.5) return Math.Log(Math.PI / Math.Abs(Math.Sin(Math.PI * x))) - LogGamma(1 - x);
        x -= 1; double a = c[0], t = x + 7.5;
        for (int i = 1; i < 9; i++) a += c[i] / (x + i);
        return 0.5 * Math.Log(2 * Math.PI) + (x + 0.5) * Math.Log(t) - t + Math.Log(a);
    }
}

public static class Reads
{
    /// <summary>Metric quadratic read (17): (mu G + beta C^T C) z = mu G u + beta C^T b.</summary>
    public static Vec Quadratic(Vec u, Mat c, Vec b, double mu, double beta, Mat? g = null)
    {
        var gm = g ?? Mat.Identity(u.Length);
        var h = gm.Scale(mu).Add(c.T.Mul(c).Scale(beta));
        return LinAlg.Solve(h, V.Add(gm.Apply(u).Select(x => mu * x).ToImmutableArray(),
                                     c.T.Apply(b), beta));
    }

    /// <summary>Robust read (28) by semismooth Newton on the active set.</summary>
    public static Vec Huber(Vec u, Mat c, Vec b, double mu, double beta, double delta)
    {
        // Semismooth Newton with Armijo backtracking on the strongly convex objective.
        var z = Quadratic(u, c, b, mu, beta);
        for (int it = 0; it < 500; it++)
        {
            var r = V.Add(c.Apply(z), b, -1);
            var psi = r.Select(t => Math.Clamp(t, -delta, delta)).ToImmutableArray();
            var grad = V.Add(V.Scale(V.Add(z, u, -1), mu), c.T.Apply(psi), beta);
            if (V.Norm(grad) < 1e-13 * (1 + V.Norm(u) + V.Norm(b))) break;
            var w = Mat.Diag(r.Select(t => Math.Abs(t) < delta ? 1.0 : 0.0).ToArray());
            var h = Mat.Identity(u.Length).Scale(mu)
                       .Add(c.T.Mul(w).Mul(c).Scale(beta));
            var step = LinAlg.Solve(h, grad);
            double f0 = HuberObjective(z, u, c, b, mu, beta, delta), slope = V.Dot(grad, step);
            double s = 1;
            while (s > 1e-12 && HuberObjective(V.Add(z, step, -s), u, c, b, mu, beta, delta)
                                > f0 - 1e-4 * s * slope) s *= 0.5;
            z = V.Add(z, step, -s);
        }
        return z;
    }

    /// <summary>Robust objective mu/2|z-u|^2 + beta sum rho_delta(c_i z - b_i).</summary>
    public static double HuberObjective(Vec z, Vec u, Mat c, Vec b, double mu, double beta,
                                        double delta) =>
        0.5 * mu * Math.Pow(V.Norm(V.Add(z, u, -1)), 2)
        + beta * V.Add(c.Apply(z), b, -1).Sum(t => Math.Abs(t) <= delta
                                                     ? 0.5 * t * t
                                                     : delta * Math.Abs(t) - 0.5 * delta * delta);

    /// <summary>Stationarity residual of the robust objective (a posteriori certificate).</summary>
    public static double HuberGradient(Vec z, Vec u, Mat c, Vec b, double mu, double beta, double delta)
    {
        var r = V.Add(c.Apply(z), b, -1);
        var psi = r.Select(t => Math.Clamp(t, -delta, delta)).ToImmutableArray();
        return V.Norm(V.Add(V.Scale(V.Add(z, u, -1), mu), c.T.Apply(psi), beta));
    }

    /// <summary>Grounded obstruction (21): eta = (I - C C^+) b.</summary>
    public static Vec Obstruction(Mat c, Vec b) =>
        V.Add(b, c.Mul(LinAlg.Pinv(c)).Apply(b), -1);

    /// <summary>Retained gain (23) of a gated schedule on eigenvalue lambda.</summary>
    public static double ScheduleGain(ImmutableArray<double> alpha, ImmutableArray<double> gate,
                                      double lambda) =>
        alpha.Zip(gate, (a, g) => 1 - g * a * lambda / (1 + a * lambda))
             .Aggregate(1.0, (p, f) => p * f);

    /// <summary>Corollary 11.2 lower bound exp(-S/(1 - a_max)).</summary>
    public static double ScheduleFloor(ImmutableArray<double> alpha, ImmutableArray<double> gate,
                                       double lambda)
    {
        var a = alpha.Zip(gate, (x, g) => g * x * lambda / (1 + x * lambda)).ToArray();
        return Math.Exp(-a.Sum() / (1 - a.Max()));
    }

    /// <summary>New Proposition: harmonic schedule alpha_j = c/(j+1), unit gates,
    /// gives Gamma(N+1)Gamma(1+c lambda)/Gamma(N+1+c lambda) exactly.</summary>
    public static double HarmonicGain(double c, double lambda, int n) =>
        Math.Exp(LinAlg.LogGamma(n + 1) + LinAlg.LogGamma(1 + c * lambda)
                 - LinAlg.LogGamma(n + 1 + c * lambda));

    /// <summary>Equation (26): single-read ratio matching n reads at ratio alpha.</summary>
    public static double EquivalentRatio(double alpha, double lambda, int n) =>
        (Math.Pow(1 + alpha * lambda, n) - 1) / lambda;

    /// <summary>Equation (27): Bayesian and proximal prior-mean gains.</summary>
    public static (double Bayes, double Prox) Gains(double alphaLambda, int n) =>
        (1 / (1 + n * alphaLambda), Math.Pow(1 + alphaLambda, -n));

    /// <summary>Theorem 13.1: consolidated statistics of a bank.</summary>
    public static BankStats Consolidate(Mat c, Vec b) =>
        new(c.T.Mul(c), c.T.Apply(b), V.Dot(b, b));

    public static Vec ReadFromStats(Vec u, BankStats s, double mu, double beta) =>
        LinAlg.Solve(Mat.Identity(u.Length).Scale(mu).Add(s.A.Scale(beta)),
                     V.Add(V.Scale(u, mu), s.D, beta));

    /// <summary>Corollary 13.2 with an explicitly stored inverse (Sherman-Morrison);
    /// returns the new state and the new inverse.</summary>
    public static (Vec Z, Mat HInv) Insert(Vec z, Mat hInv, Vec c, double y, double tau)
    {
        var hc = hInv.Apply(c);
        double den = 1 + tau * V.Dot(c, hc);
        var zNew = V.Add(z, hc, tau * (y - V.Dot(c, z)) / den);
        var hInvNew = Mat.Build(hInv.Rows, hInv.Cols, (i, j) => hInv[i, j] - tau * hc[i] * hc[j] / den);
        return (zNew, hInvNew);
    }

    /// <summary>Proposition 14.3 bound and the measured discrepancy.</summary>
    public static (double Measured, double Bound) Equivariance(Mat c0, Mat c1, Mat t, Mat s,
        Vec u, Vec b, double mu, double beta)
    {
        var z0 = Quadratic(u, c0, b, mu, beta);
        var z1 = Quadratic(t.Apply(u), c1, s.Apply(b), mu, beta);
        var d = c1.Mul(t).Add(s.Mul(c0), -1);
        double bound = beta / mu * LinAlg.SpectralNorm(d) * (V.Norm(b)
            + (LinAlg.SpectralNorm(c1) + LinAlg.SpectralNorm(c0)) * V.Norm(z0));
        return (V.Norm(V.Add(z1, t.Apply(z0), -1)), bound);
    }

    /// <summary>Read gain J = mu (mu I + beta C^T C)^{-1}.</summary>
    public static Mat Gain(Mat c, double mu, double beta) =>
        LinAlg.Inverse(Mat.Identity(c.Cols).Scale(mu).Add(c.T.Mul(c).Scale(beta))).Scale(mu);
}
```

**A.2 Program.cs**

```csharp
// Version 4 numerical explorations. Every printed line is recomputed
// independently by cs_validate.py with NumPy from the same SplitMix64 stream.
using System;
using System.Collections.Immutable;
using System.Globalization;
using System.Linq;
using Sidecar;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

static string F(double x) => x.ToString("G17", CultureInfo.InvariantCulture);
static void Print(string name, params double[] xs) =>
    Console.WriteLine(name + " " + string.Join(" ", xs.Select(F)));

// Modified Gram-Schmidt orthonormalisation of the columns of a square matrix.
static Mat Orthonormal(Mat a)
{
    int n = a.Rows; var q = new double[n][];
    for (int j = 0; j < n; j++)
    {
        var v = Enumerable.Range(0, n).Select(i => a[i, j]).ToArray();
        for (int k = 0; k < j; k++)
        {
            double d = v.Zip(q[k], (x, y) => x * y).Sum();
            for (int i = 0; i < n; i++) v[i] -= d * q[k][i];
        }
        double nrm = Math.Sqrt(v.Sum(x => x * x));
        q[j] = v.Select(x => x / nrm).ToArray();
    }
    return Mat.Build(n, n, (i, j) => q[j][i]);
}
static double Median(double[] x) { var s = x.OrderBy(v => v).ToArray();
    return s.Length % 2 == 1 ? s[s.Length / 2] : 0.5 * (s[s.Length / 2 - 1] + s[s.Length / 2]); }

var rng = new Rng(20261020UL);

// ---------------------------------------------------------------- A. V3 values
var ct = Mat.Rows_(new[] { 1.0 }, new[] { 1.0 });
var eta = Reads.Obstruction(ct, V.Of(0, 2));
Print("grounded_tree", eta[0], eta[1], V.Norm(eta));
var (bayes, prox) = Reads.Gains(0.5, 5);
Print("bayes_prox_gains", bayes, prox);
var alphas = Enumerable.Range(0, 20).Select(j => 0.1 / Math.Pow(j + 1, 2)).ToImmutableArray();
var ones = Enumerable.Repeat(1.0, 20).ToImmutableArray();
Print("twenty_reads", Reads.ScheduleGain(alphas, ones, 1), Reads.ScheduleFloor(alphas, ones, 1));
Print("equivalent_ratio", Reads.EquivalentRatio(0.5, 1, 5), Reads.EquivalentRatio(0.5, 4, 5));
var c3 = Mat.Rows_(new[] { 1.0 }, new[] { 1.0 }, new[] { 1.0 });
var bA = V.Of(-1, 0, 1); var bB = V.Of(1 / Math.Sqrt(3), 1 / Math.Sqrt(3), -2 / Math.Sqrt(3));
var sA = Reads.Consolidate(c3, bA); var sB = Reads.Consolidate(c3, bB);
Print("consolidation_stats", sA.A[0, 0], sA.D[0], sA.E, sB.A[0, 0], sB.D[0], sB.E);
var hA = Reads.Huber(V.Of(0), c3, bA, 1, 1, 0.5); var hB = Reads.Huber(V.Of(0), c3, bB, 1, 1, 0.5);
Print("huber_consolidation", hA[0], hB[0], Reads.HuberGradient(hB, V.Of(0), c3, bB, 1, 1, 0.5));
Print("nonisometric_square",
      Reads.Quadratic(V.Of(1), Mat.Diag(1), V.Of(0), 1, 1)[0],
      Reads.Quadratic(V.Of(1), Mat.Diag(2), V.Of(0), 1, 1)[0]);
var j2 = Mat.Diag(0.5, 1);
Print("loop_radius", LinAlg.SpectralRadius(j2.Mul(Mat.Diag(1, 1.1))),
      LinAlg.SpectralRadius(j2.Mul(Mat.Diag(1.2, 0.8))));
var c2 = Mat.Identity(2);
var hz = Reads.Huber(V.Of(0, 0), c2, V.Of(100, 0), 1, 3, 0.5);
Vec Hk(int k, double h) => Reads.Huber(V.Of(k == 0 ? h : 0, k == 1 ? h : 0), c2, V.Of(100, 0),
                                        1, 3, 0.5);
double Fd(int k) => (Hk(k, 1e-6)[k] - Hk(k, -1e-6)[k]) / 2e-6;
Print("huber_active", hz[0], hz[1], Fd(0), Fd(1));
var plus = Reads.Huber(V.Of(0), Mat.Diag(1), V.Of(1000), 1, 3, 0.5);
var minus = Reads.Huber(V.Of(0), Mat.Diag(1), V.Of(-1000), 1, 3, 0.5);
Print("factor_two", plus[0] - minus[0], 2 * 3 * 0.5 / 1);
double mu = 1, beta = 4;
var cInf = Mat.Diag(Math.Sqrt(mu / beta), 2.0, 0.1);
var kmat = LinAlg.Inverse(Mat.Identity(3).Scale(mu).Add(cInf.T.Mul(cInf).Scale(beta)))
                 .Mul(cInf.T).Scale(beta);
Print("anchor_influence", LinAlg.SpectralNorm(kmat), 0.5 * Math.Sqrt(beta / mu));
// metric covariance (Theorem 9.2) on random data
Mat q0, cm; Vec um, bm;
(q0, rng) = rng.NormalMat(4, 4); (cm, rng) = rng.NormalMat(3, 4);
Mat tmp; (tmp, rng) = rng.NormalMat(1, 4); um = tmp.Data;
(tmp, rng) = rng.NormalMat(1, 3); bm = tmp.Data;
Mat gr; (gr, rng) = rng.NormalMat(4, 4); var gm = gr.T.Mul(gr).Add(Mat.Identity(4));
var qInv = LinAlg.Pinv(q0);
var lhs = Reads.Quadratic(q0.Apply(um), cm.Mul(qInv), bm, 0.7, 2.0, qInv.T.Mul(gm).Mul(qInv));
var rhs = q0.Apply(Reads.Quadratic(um, cm, bm, 0.7, 2.0, gm));
Print("metric_covariance", lhs.Zip(rhs, (a, b) => Math.Abs(a - b)).Max());

// ---------------------------------------------------------------- B. schedules
foreach (var n in new[] { 10, 100, 1000, 10000 })
{
    ImmutableArray<double> Sched(double p) =>
        Enumerable.Range(0, n).Select(j => 0.5 / Math.Pow(j + 1, p)).ToImmutableArray();
    var g1 = Enumerable.Repeat(1.0, n).ToImmutableArray();
    Print($"schedule_N{n}", Reads.ScheduleGain(Sched(0.5), g1, 1), Reads.ScheduleGain(Sched(1), g1, 1),
          Reads.HarmonicGain(0.5, 1, n), Reads.ScheduleGain(Sched(2), g1, 1));
}

// ---------------------------------------------------------------- C. robust bound tightness
var ratios = new double[400]; double cert = 0;
for (int t = 0; t < 400; t++)
{
    Mat cr, ur, br, amp;
    (cr, rng) = rng.NormalMat(8, 4); (ur, rng) = rng.NormalMat(1, 4);
    (br, rng) = rng.NormalMat(1, 8);
    (amp, rng) = rng.NormalMat(1, 2);
    var b2 = br.Data.ToArray(); b2[0] += 100 * amp.Data[0]; b2[1] += 100 * amp.Data[1];
    var z0 = Reads.Huber(ur.Data, cr, br.Data, 1, 3, 0.5);
    var z1 = Reads.Huber(ur.Data, cr, b2.ToImmutableArray(), 1, 3, 0.5);
    double bound = 2 * 3 * 0.5 / 1 * (V.Norm(cr.Row(0).Data) + V.Norm(cr.Row(1).Data));
    cert = Math.Max(cert, Math.Max(
        Reads.HuberGradient(z0, ur.Data, cr, br.Data, 1, 3, 0.5),
        Reads.HuberGradient(z1, ur.Data, cr, b2.ToImmutableArray(), 1, 3, 0.5)));
    ratios[t] = V.Norm(V.Add(z1, z0, -1)) / bound;
}
Print("robust_tightness", ratios.Max(), Median(ratios), ratios.Average());
Print("robust_certificate", cert);

// ---------------------------------------------------------------- D. insertion drift
{
    int r = 16; Mat u0; (u0, rng) = rng.NormalMat(1, r);
    var z = u0.Data; var hInv = Mat.Identity(r);
    var acc = Mat.Identity(r); var rhsAcc = u0.Data;
    var drift = new System.Collections.Generic.List<double>();
    for (int m = 1; m <= 2000; m++)
    {
        Mat cc, yy; (cc, rng) = rng.NormalMat(1, r); (yy, rng) = rng.NormalMat(1, 1);
        (z, hInv) = Reads.Insert(z, hInv, cc.Data, yy.Data[0], 1.0);
        acc = acc.Add(cc.T.Mul(cc)); rhsAcc = V.Add(rhsAcc, cc.Data, yy.Data[0]);
        if (m is 10 or 100 or 1000 or 2000)
        {
            var exact = LinAlg.Solve(acc, rhsAcc);
            drift.Add(V.Add(z, exact, -1).Max(Math.Abs));
            if (m == 2000) Print("insertion_exact_head", exact[0], exact[1], exact[2]);
        }
    }
    Print("insertion_drift", drift.ToArray());
}

// ---------------------------------------------------------------- E. loop stability
foreach (var k in new[] { 0, 1, 2, 3 })
{
    int r = 6; var cl = Mat.Build(r - k, r, (i, j) => i == j ? 1 : 0);
    var jg = Reads.Gain(cl, 1, 4);
    var smix = new double[100];
    for (int t = 0; t < 100; t++)
    {
        Mat a; (a, rng) = rng.NormalMat(r, r);
        smix[t] = 1 / LinAlg.SpectralRadius(jg.Mul(Orthonormal(a)));
    }
    Print($"loop_private{k}", 1 / LinAlg.SpectralRadius(jg), smix.Min(), Median(smix), smix.Max());
}

// ---------------------------------------------------------------- F. equivariance tightness
var er = new double[300];
for (int t = 0; t < 300; t++)
{
    Mat a1, a2, c0, e, u1, b1;
    (a1, rng) = rng.NormalMat(4, 4); (a2, rng) = rng.NormalMat(3, 3); (c0, rng) = rng.NormalMat(3, 4);
    (e, rng) = rng.NormalMat(3, 4); (u1, rng) = rng.NormalMat(1, 4); (b1, rng) = rng.NormalMat(1, 3);
    var tt = Orthonormal(a1); var ss = Orthonormal(a2);
    var c1 = ss.Mul(c0).Mul(tt.T).Add(e, 0.05);
    var (meas, bnd) = Reads.Equivariance(c0, c1, tt, ss, u1.Data, b1.Data, 1, 2);
    er[t] = meas / bnd;
}
Print("equivariance_tightness", er.Max(), Median(er), er.Min());
```
