"""Independent NumPy/SciPy recomputation of every line printed by the C# kernel (Version 4).
The random inputs are regenerated with the same SplitMix64 + Box-Muller stream, so both
languages see bit-identical matrices; the algorithms used here are deliberately different
(LAPACK solves and eigenvalues, IRLS for the robust read, Householder QR, log-gamma)."""
from pathlib import Path
import json, math, sys
import numpy as np
from scipy.special import gammaln

P = Path(__file__).resolve().parent
M64 = (1 << 64) - 1


class Rng:
    def __init__(self, seed): self.s = seed & M64
    def u64(self):
        self.s = (self.s + 0x9E3779B97F4A7C15) & M64; z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return z ^ (z >> 31)
    def uniform(self): return (self.u64() >> 11) * (1.0 / 9007199254740992.0)
    def normal(self):
        u1 = self.uniform(); u2 = self.uniform()
        return math.sqrt(-2 * math.log(1 - u1)) * math.cos(2 * math.pi * u2)
    def mat(self, r, c): return np.array([self.normal() for _ in range(r * c)]).reshape(r, c)


def read(u, C, b, mu, beta, G=None):
    G = np.eye(len(u)) if G is None else G
    return np.linalg.solve(mu * G + beta * C.T @ C, mu * G @ u + beta * C.T @ b)


def huber(u, C, b, mu, beta, d, iters=4000):          # IRLS (majorise-minimise), not Newton
    z = read(u, C, b, mu, beta)
    for _ in range(iters):
        r = C @ z - b; w = np.where(np.abs(r) <= d, 1.0, d / np.maximum(np.abs(r), 1e-300))
        zn = np.linalg.solve(mu * np.eye(len(u)) + beta * C.T @ (w[:, None] * C), mu * u + beta * C.T @ (w * b))
        if np.abs(zn - z).max() < 1e-16: z = zn; break
        z = zn
    return z


def hgrad(z, u, C, b, mu, beta, d): return np.linalg.norm(mu * (z - u) + beta * C.T @ np.clip(C @ z - b, -d, d))
def sched_gain(a, lam=1.0): return float(np.prod(1 / (1 + np.asarray(a) * lam)))
def orth(A):
    Q, R = np.linalg.qr(A); return Q * np.sign(np.diag(R))
rho = lambda M: float(np.abs(np.linalg.eigvals(M)).max())
sn = lambda M: float(np.linalg.norm(M, 2))
gain = lambda C, mu, beta: mu * np.linalg.inv(mu * np.eye(C.shape[1]) + beta * C.T @ C)


def newton(u, C, b, mu, beta, d):
    z = read(u, C, b, mu, beta)
    for _ in range(200):
        r = C @ z - b; g = mu * (z - u) + beta * C.T @ np.clip(r, -d, d)
        if np.linalg.norm(g) < 1e-14: break
        w = (np.abs(r) < d).astype(float)
        z = z - np.linalg.solve(mu * np.eye(len(u)) + beta * C.T @ (w[:, None] * C), g)
    return z
rng = Rng(20261020)
for shape in [(4, 4), (3, 4), (1, 4), (1, 3), (4, 4)]: rng.mat(*shape)
rat = []; bad = 0; worst = 0
for t in range(400):
    Cr = rng.mat(8, 4); ur = rng.mat(1, 4)[0]; br = rng.mat(1, 8)[0]; amp = rng.mat(1, 2)[0]
    b2 = br.copy(); b2[:2] += 100 * amp
    z0 = newton(ur, Cr, br, 1, 3, .5); z1 = newton(ur, Cr, b2, 1, 3, .5)
    g = max(hgrad(z0, ur, Cr, br, 1, 3, .5), hgrad(z1, ur, Cr, b2, 1, 3, .5)); worst = max(worst, g)
    bad += g > 1e-8
    rat.append(np.linalg.norm(z1 - z0) / (3 * (np.linalg.norm(Cr[0]) + np.linalg.norm(Cr[1]))))
rat = np.array(rat)
print(dict(max=rat.max(), median=float(np.median(rat)), uncertified=int(bad), worst_gradient=worst, exceed=int((rat > 1).sum())))
