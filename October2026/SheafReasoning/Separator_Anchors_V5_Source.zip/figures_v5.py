"""Draw the finite-dimensional mixing result from the verified V5 values."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

P=Path(__file__).resolve().parent
curve=np.array(json.loads((P/'v5_results.json').read_text())['metrics']['mixing_curve'])
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axs=plt.subplots(1,2,figsize=(7,2.65),layout='constrained')
angles=curve[:,0]*180/np.pi
axs[0].plot(angles,curve[:,1],color='#24475E',lw=2,label='Exact spectral radius')
axs[0].plot(angles,curve[:,2],color='#A6632A',lw=1.6,ls='--',label='Two step bound')
axs[0].set(xlabel='Rotation angle in degrees',ylabel='Retained gain',xlim=(0,90),ylim=(.45,1.03))
axs[0].legend(frameon=False,fontsize=8,loc='upper right');axs[0].set_title('(a) Feedback stability',loc='left',fontsize=10)
axs[1].plot(angles,curve[:,3],color='#24475E',lw=2)
axs[1].set(xlabel='Rotation angle in degrees',ylabel='Smallest loss eigenvalue',xlim=(0,90),ylim=(0,1))
axs[1].set_title('(b) Finite horizon margin',loc='left',fontsize=10)
for ax in axs:ax.grid(alpha=.18);ax.set_xticks([0,30,60,90])
fig.savefig(P/'fig/fig6_mixing.png',dpi=220)
plt.close(fig)
