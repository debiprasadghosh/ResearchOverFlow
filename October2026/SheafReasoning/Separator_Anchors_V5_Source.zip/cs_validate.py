"""Independent NumPy/SciPy recomputation of every line printed by the C# kernel (Version 4).
The random inputs are regenerated with the same SplitMix64 + Box-Muller stream, so both
languages see bit-identical matrices; the algorithms used here are deliberately different
(LAPACK solves and eigenvalues, IRLS for the robust read, Householder QR, log-gamma)."""
from pathlib import Path
import json, math, sys
import numpy as np
from scipy.special import gammaln

P = Path(__file__).resolve().parent
M64 = (1 << 64) - 1


class Rng:
    def __init__(self, seed): self.s = seed & M64
    def u64(self):
        self.s = (self.s + 0x9E3779B97F4A7C15) & M64; z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return z ^ (z >> 31)
    def uniform(self): return (self.u64() >> 11) * (1.0 / 9007199254740992.0)
    def normal(self):
        u1 = self.uniform(); u2 = self.uniform()
        return math.sqrt(-2 * math.log(1 - u1)) * math.cos(2 * math.pi * u2)
    def mat(self, r, c): return np.array([self.normal() for _ in range(r * c)]).reshape(r, c)


def read(u, C, b, mu, beta, G=None):
    G = np.eye(len(u)) if G is None else G
    return np.linalg.solve(mu * G + beta * C.T @ C, mu * G @ u + beta * C.T @ b)


def huber(u, C, b, mu, beta, d, iters=4000):          # IRLS (majorise-minimise), not Newton
    z = read(u, C, b, mu, beta)
    for _ in range(iters):
        r = C @ z - b; w = np.where(np.abs(r) <= d, 1.0, d / np.maximum(np.abs(r), 1e-300))
        zn = np.linalg.solve(mu * np.eye(len(u)) + beta * C.T @ (w[:, None] * C), mu * u + beta * C.T @ (w * b))
        if np.abs(zn - z).max() < 1e-16: z = zn; break
        z = zn
    return z


def hgrad(z, u, C, b, mu, beta, d): return np.linalg.norm(mu * (z - u) + beta * C.T @ np.clip(C @ z - b, -d, d))
def sched_gain(a, lam=1.0): return float(np.prod(1 / (1 + np.asarray(a) * lam)))
def orth(A):
    Q, R = np.linalg.qr(A); return Q * np.sign(np.diag(R))
rho = lambda M: float(np.abs(np.linalg.eigvals(M)).max())
sn = lambda M: float(np.linalg.norm(M, 2))
gain = lambda C, mu, beta: mu * np.linalg.inv(mu * np.eye(C.shape[1]) + beta * C.T @ C)

out = {}
rng = Rng(20261020)
# ---------------------------------------------------------------- A
Ct = np.ones((2, 1)); eta = (np.eye(2) - Ct @ np.linalg.pinv(Ct)) @ np.array([0., 2])
out['grounded_tree'] = [*eta, np.linalg.norm(eta)]
out['bayes_prox_gains'] = [1 / (1 + 5 * .5), 1.5 ** -5]
al = [0.1 / (j + 1) ** 2 for j in range(20)]; a = np.array(al) / (1 + np.array(al))
out['twenty_reads'] = [sched_gain(al), math.exp(-a.sum() / (1 - a.max()))]
out['equivalent_ratio'] = [((1.5) ** 5 - 1) / 1, ((3.0) ** 5 - 1) / 4]
C3 = np.ones((3, 1)); bA = np.array([-1., 0, 1]); bB = np.array([1, 1, -2]) / math.sqrt(3)
out['consolidation_stats'] = [3, C3.T @ bA, bA @ bA, 3, C3.T @ bB, bB @ bB]
hA = huber(np.zeros(1), C3, bA, 1, 1, .5); hB = huber(np.zeros(1), C3, bB, 1, 1, .5)
out['huber_consolidation'] = [hA[0], hB[0], hgrad(hB, np.zeros(1), C3, bB, 1, 1, .5)]
out['nonisometric_square'] = [read(np.ones(1), np.eye(1), np.zeros(1), 1, 1)[0],
                              read(np.ones(1), 2 * np.eye(1), np.zeros(1), 1, 1)[0]]
J2 = np.diag([.5, 1]); out['loop_radius'] = [rho(J2 @ np.diag([1, 1.1])), rho(J2 @ np.diag([1.2, .8]))]
hz = huber(np.zeros(2), np.eye(2), np.array([100., 0]), 1, 3, .5)
fd = [(huber(1e-6 * e, np.eye(2), np.array([100., 0]), 1, 3, .5)[k] - huber(-1e-6 * e, np.eye(2), np.array([100., 0]), 1, 3, .5)[k]) / 2e-6
      for k, e in enumerate(np.eye(2))]
out['huber_active'] = [hz[0], hz[1], *fd]
out['factor_two'] = [huber(np.zeros(1), np.eye(1), np.array([1000.]), 1, 3, .5)[0] - huber(np.zeros(1), np.eye(1), np.array([-1000.]), 1, 3, .5)[0], 3.0]
Ci = np.diag([math.sqrt(1 / 4), 2, .1]); K = np.linalg.inv(np.eye(3) + 4 * Ci.T @ Ci) @ Ci.T * 4
out['anchor_influence'] = [sn(K), .5 * math.sqrt(4)]
Q0 = rng.mat(4, 4); Cm = rng.mat(3, 4); um = rng.mat(1, 4)[0]; bm = rng.mat(1, 3)[0]; Gr = rng.mat(4, 4); Gm = Gr.T @ Gr + np.eye(4)
Qi = np.linalg.inv(Q0)
out['metric_covariance'] = [np.abs(read(Q0 @ um, Cm @ Qi, bm, .7, 2, Qi.T @ Gm @ Qi) - Q0 @ read(um, Cm, bm, .7, 2, Gm)).max()]
# ---------------------------------------------------------------- B
for n in (10, 100, 1000, 10000):
    j = np.arange(1, n + 1)
    out[f'schedule_N{n}'] = [sched_gain(.5 / j ** .5), sched_gain(.5 / j),
                             math.exp(gammaln(n + 1) + gammaln(1.5) - gammaln(n + 1.5)), sched_gain(.5 / j ** 2)]
# ---------------------------------------------------------------- C
ratios = []; cert = 0
for t in range(400):
    Cr = rng.mat(8, 4); ur = rng.mat(1, 4)[0]; br = rng.mat(1, 8)[0]; amp = rng.mat(1, 2)[0]
    b2 = br.copy(); b2[:2] += 100 * amp
    z0 = huber(ur, Cr, br, 1, 3, .5); z1 = huber(ur, Cr, b2, 1, 3, .5)
    cert = max(cert, hgrad(z0, ur, Cr, br, 1, 3, .5), hgrad(z1, ur, Cr, b2, 1, 3, .5))
    ratios.append(np.linalg.norm(z1 - z0) / (3 * (np.linalg.norm(Cr[0]) + np.linalg.norm(Cr[1]))))
ratios = np.array(ratios)
out['robust_tightness'] = [ratios.max(), np.median(ratios), ratios.mean()]
out['robust_certificate'] = [cert]
# ---------------------------------------------------------------- D
r = 16; u0 = rng.mat(1, r)[0]; A = np.eye(r); h = u0.copy(); drift = []; Cs = []; ys = []
for m in range(1, 2001):
    c = rng.mat(1, r)[0]; y = rng.mat(1, 1)[0, 0]; Cs.append(c); ys.append(y)
    if m in (10, 100, 1000, 2000):
        Cm_ = np.array(Cs); ex = np.linalg.solve(np.eye(r) + Cm_.T @ Cm_, u0 + Cm_.T @ np.array(ys))
        drift.append(ex)
out['insertion_exact_head'] = list(drift[-1][:3])
# drift itself is a C# roundoff quantity; Python checks the exact targets and the order of magnitude
# ---------------------------------------------------------------- E
loop = {}
for k in (0, 1, 2, 3):
    Cl = np.eye(6)[:6 - k]; Jg = gain(Cl, 1, 4)
    s = np.array([1 / rho(Jg @ orth(rng.mat(6, 6))) for _ in range(100)]); loop[k] = s
    out[f'loop_private{k}'] = [1 / rho(Jg), s.min(), np.median(s), s.max()]
# ---------------------------------------------------------------- F
er = []
for t in range(300):
    a1 = rng.mat(4, 4); a2 = rng.mat(3, 3); c0 = rng.mat(3, 4); e = rng.mat(3, 4); u1 = rng.mat(1, 4)[0]; b1 = rng.mat(1, 3)[0]
    T = orth(a1); S = orth(a2); c1 = S @ c0 @ T.T + .05 * e
    z0 = read(u1, c0, b1, 1, 2); z1 = read(T @ u1, c1, S @ b1, 1, 2)
    bound = 2 * sn(c1 @ T - S @ c0) * (np.linalg.norm(b1) + (sn(c1) + sn(c0)) * np.linalg.norm(z0))
    er.append(np.linalg.norm(z1 - T @ z0) / bound)
er = np.array(er); out['equivariance_tightness'] = [er.max(), np.median(er), er.min()]

# ---------------------------------------------------------------- compare
cs = {l.split()[0]: [float(x) for x in l.split()[1:]] for l in (P / 'cs' / 'cs_out.txt').read_text().splitlines() if l.strip()}
rows = []; ok_all = True
for name, py in out.items():
    py = [float(np.ravel(x)[0]) for x in py]; c = cs[name]
    err = max(abs(a - b) / max(1.0, abs(b)) if abs(b) > 1e-6 else abs(a - b) for a, b in zip(c, py))
    tol = 1e-7 if name == 'huber_active' else 1e-9   # finite differences carry O(h^2)+roundoff/h noise
    # certificates and roundoff-level quantities: both must be at roundoff, not equal
    passed = (max(c) < 1e-10 and max(py) < 1e-10) if name in ('metric_covariance', 'robust_certificate') else err < tol
    ok_all &= passed
    rows.append({'name': name, 'csharp': c, 'python': py, 'max_rel_diff': err, 'passed': bool(passed)})
rows.append({'name': 'insertion_drift', 'csharp': cs['insertion_drift'], 'python': None, 'max_rel_diff': None,
             'passed': bool(max(cs['insertion_drift']) < 1e-12)})
ok_all &= rows[-1]['passed']
extra = {'ratios_hist': np.histogram(ratios, bins=20, range=(0, .5))[0].tolist(),
         'loop': {k: sorted(v.tolist()) for k, v in loop.items()}}
(P / 'cs_validate.json').write_text(json.dumps({'rows': rows, 'all_passed': bool(ok_all), 'extra': extra}, indent=1) + '\n')
for r_ in rows:
    print('PASS' if r_['passed'] else 'FAIL', r_['name'], r_['max_rel_diff'])
print('ALL', ok_all, len(rows))
