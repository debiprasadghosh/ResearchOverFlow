# Separator Anchors Version 5

Mathematical revision dated 22 October 2026, by Debi Prasad Ghosh.

The Word paper adds sixteen proved results in Sections 20–24, with 40 new
named numerical checks. These are finite-dimensional mathematical checks,
not experiments on a trained reasoning model.

## Contents

- `paper.md` — complete V5 manuscript, including the proofs.
- `extensions.md` — the new mathematical development.
- `v4_baseline.md` — preserved input manuscript source.
- `validate_v5.py` and `v5_results.json` — new checks and their measured values.
- `cs_validate.py` and `cs_validate.json` — NumPy/SciPy recomputation of the
  25 supplied V4 results, compared against archived C# output.
- `cs/` — complete supplied .NET 8 reference kernel and archived output.
- `undamped_check.py` — retained reproduction of the undamped solver failure.
- `fig/` — the five supplied figures and the added mixing figure.
- `assemble_v5.py`, `figures_v5.py`, `build_v5.py`, `reference.docx`,
  `postprocess.py` — manuscript assembly and native Word equation build.

## Reproduce the paper

Use Python with NumPy, SciPy, Matplotlib and python-docx, and install Pandoc.
In Codex, use the provided primary runtime Python executable. From this
directory run:

```bash
python validate_v5.py
python cs_validate.py
python assemble_v5.py
python figures_v5.py
python build_v5.py
```

The final command writes the Word paper to `output/`. The reference DOCX is
read as a style source; the builder creates a separate working reference.
Pandoc supplies editable OMML equations. The postprocessor orders OOXML
properties and sets display-equation tabs. LibreOffice rendering is used
separately to check the final document visually.

The recorded V5 run used float64, NumPy 2.3.5, seed 20261022, and passed all
40 named checks. Multiple random trials inside one check are not counted as
separate checks. The 25-result archived-output comparison also passed. A new
C# execution was not performed in this revision; .NET 8 is needed to rerun
`cs/Sidecar.csproj` independently. The 53 historical V2/V3 checks described
in the input manuscript are not presented as freshly rerun legacy scripts:
those two separate scripts were absent from the supplied V4 source archive.

## Mathematical scope

The cycle theorems assume a common calibrated state space and conditional
fixed-bank read operators. A common affine fixed point is required for
convergence to a single target; an incompatible-bank counterexample shows
why. The feedback Gramian result assumes orthogonal feedback. Robust
compression requires the query-family bounds stated in Theorems 23.1–23.3.
Task residual certificates assume the declared linear observation model.
None of these results proves semantic correctness of learned contexts.
