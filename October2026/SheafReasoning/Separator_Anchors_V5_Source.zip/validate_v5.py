"""Reproducible float64 checks of V5 identities and sharp counterexamples.

Run with the bundled Codex Python runtime. Checks illustrate the proofs;
they are not tests of a trained language model. No external data needed.
"""
from pathlib import Path
import json
import math
import numpy as np

P = Path(__file__).resolve().parent
rng = np.random.default_rng(20261022)
checks, metrics = [], {}


def check(name, passed, value=None):
    checks.append(dict(name=name, passed=bool(passed), value=None if value is None else float(value)))
    if not passed:
        raise AssertionError((name, value))


def sn(x):
    return float(np.linalg.norm(x, 2))


def gain(C, a=1., g=1.):
    I = np.eye(C.shape[1])
    return (1-g)*I+g*np.linalg.solve(I+a*C.T@C, I)


def cycle(Ts):
    n = len(Ts[0]); ph = np.eye(n); W = np.zeros((n,n))
    for T in Ts:
        W += ph.T@(np.eye(n)-T@T)@ph
        ph = T@ph
    return ph, (W+W.T)/2


def huber(u, C, b, mu=1., beta=1., delta=.5, weights=None):
    w = np.ones(len(b)) if weights is None else np.asarray(weights)
    def objective(z):
        ar=np.abs(C@z-b)
        return mu/2*np.sum((z-u)**2)+beta*np.sum(w*np.where(ar<=delta,ar**2/2,delta*ar-delta**2/2))
    z=np.linalg.solve(mu*np.eye(len(u))+beta*C.T@(w[:,None]*C),mu*u+beta*C.T@(w*b))
    for _ in range(1000):
        residual=C@z-b
        grad=mu*(z-u)+beta*C.T@(w*np.clip(residual,-delta,delta))
        if np.linalg.norm(grad)<2e-12:
            return z,float(np.linalg.norm(grad))
        H=mu*np.eye(len(u))+beta*C.T@((w*(np.abs(residual)<delta))[:,None]*C)
        direction=np.linalg.solve(H,-grad)
        step=1.
        if np.linalg.norm(grad)>1e-8:
            f=objective(z)
            while objective(z+step*direction)>f+1e-4*step*(grad@direction)+1e-14:
                step*=.5
                if step<1e-14: raise ArithmeticError('Armijo step collapsed')
        z=z+step*direction
    raise ArithmeticError('Huber solve did not converge')


# 20 random noncommuting full-rank cycles and their exact loss identities
cycle_identity=cycle_gain=0.; commutator_error=0.; smallest_kappa=1.
for trial in range(80):
    Cs=[rng.normal(size=(2,4)) for _ in range(3)]
    aa=rng.uniform(.1,2,size=3); gg=rng.uniform(.1,1,size=3)
    Ts=[gain(c,a,g) for c,a,g in zip(Cs,aa,gg)]
    ph,W=cycle(Ts); kappa=float(np.linalg.eigvalsh(W)[0])
    cycle_identity=max(cycle_identity,sn(W-(np.eye(4)-ph.T@ph)))
    cycle_gain=max(cycle_gain,abs(sn(ph)-math.sqrt(1-kappa)))
    smallest_kappa=min(smallest_kappa,kappa)
    A,B=Cs[0].T@Cs[0],Cs[1].T@Cs[1]
    P1,P2=gain(Cs[0],aa[0]),gain(Cs[1],aa[1])
    diff=Ts[1]@Ts[0]-Ts[0]@Ts[1]
    rhs=gg[0]*gg[1]*aa[0]*aa[1]*P2@P1@(B@A-A@B)@P1@P2
    commutator_error=max(commutator_error,sn(diff-rhs))
check('cycle_energy_identity_80_trials',cycle_identity<2e-13,cycle_identity)
check('cycle_exact_gain_80_trials',cycle_gain<2e-13,cycle_gain)
check('cycle_full_coverage_positive',smallest_kappa>0,smallest_kappa)
check('resolvent_commutator_80_trials',commutator_error<2e-13,commutator_error)

C1=np.array([[1.,0.,0.]])
C2=np.array([[1.,1.,0.]])
ph,W=cycle([gain(C1),gain(C2)])
check('common_private_kernel_dimension',sum(np.linalg.eigvalsh(W)<1e-12)==1)
check('common_private_direction_preserved',np.linalg.norm(ph@np.array([0.,0.,1.])-np.array([0.,0.,1.]))<1e-14)
check('observed_cycle_contracts',sn(ph[:2,:2])<1,sn(ph[:2,:2]))
x=np.array([2.,-1.,7.]); p=np.array([.3,-.2,0.]); xstar=p+np.array([0.,0.,7.]); init=x-xstar
kappa=np.linalg.eigvalsh(W[:2,:2])[0]
for _ in range(35): x=p+ph@(x-p)
check('periodic_common_point_limit',np.linalg.norm(x-xstar)<1e-3,np.linalg.norm(x-xstar))
check('periodic_common_point_rate',np.linalg.norm(x-xstar)<=sn(ph[:2,:2])**35*np.linalg.norm(init)+1e-13)

x=0.
for _ in range(100):
    middle=x/2
    x=middle/2+1
check('incompatible_banks_periodic_orbit',abs(x-4/3)<1e-14 and abs(middle-2/3)<1e-14)
check('periodic_orbit_not_joint_least_squares',abs(x-1)>1/3-1e-14)
floors=np.ones(2)
for j in range(1,1001):floors[(j-1)%2]/=1+2.**(-j)
check('infinite_coverage_finite_spend_floor',min(floors)>.5,min(floors))
metrics['summable_axis_gains']=floors.tolist()

# 21 finite-horizon Gramian with rotations, random orthogonal maps and rank tests
gram_error=kernel_difference=bound_violation=0.
for trial in range(60):
    r=4; C=rng.normal(size=(2,r)); Q,_=np.linalg.qr(rng.normal(size=(r,r)))
    J=gain(C,.8); L=J@Q; D=np.eye(r)-J@J
    ph=np.eye(r); W=np.zeros((r,r)); row_stack=[]; qpower=np.eye(r)
    for _ in range(r):
        W+=ph.T@Q.T@D@Q@ph; ph=L@ph; qpower=Q@qpower; row_stack.append(C@qpower)
    W=(W+W.T)/2
    gram_error=max(gram_error,sn(W-(np.eye(r)-ph.T@ph)))
    kappa=float(np.linalg.eigvalsh(W)[0])
    O=np.vstack(row_stack)
    kernel_difference=max(kernel_difference,abs(np.linalg.matrix_rank(O)-(sum(np.linalg.eigvalsh(W)>1e-11))))
    bound=(1-kappa)**(1/(2*r)); rho=max(abs(np.linalg.eigvals(L)))
    bound_violation=max(bound_violation,float(rho-bound))
check('mixing_gramian_identity_60_trials',gram_error<2e-13,gram_error)
check('mixing_observability_rank_60_trials',kernel_difference==0,kernel_difference)
check('mixing_radius_bound_60_trials',bound_violation<2e-13,bound_violation)

a=.25; h=1-a*a; formula_error=0.; angles=np.linspace(0,np.pi/2,201); curve=[]
for theta in angles:
    c,s=np.cos(theta),np.sin(theta); Q=np.array([[c,-s],[s,c]]); L=np.diag([a,1.])@Q
    L2=L@L; W=np.eye(2)-L2.T@L2
    kappa=np.linalg.eigvalsh(W)[0]; tau=h*(2-h*c*c)
    # Stable quadratic formula for small angles
    det=h*h*s*s; predicted=0 if det==0 else 2*det/(tau+np.sqrt(max(0,tau*tau-4*det)))
    formula_error=max(formula_error,abs(predicted-kappa))
    curve.append([float(theta),float(max(abs(np.linalg.eigvals(L)))),float((1-kappa)**.25),float(kappa)])
check('rotation_closed_form_201_angles',formula_error<2e-8,formula_error)
check('quarter_turn_sharp_radius_bound',abs(curve[-1][1]-curve[-1][2])<2e-14,curve[-1][2])
theta=1e-4; tau=h*(2-h*np.cos(theta)**2); det=h*h*np.sin(theta)**2
kp=2*det/(tau+np.sqrt(tau*tau-4*det))
ratio=kp/(h/(1+a*a)*theta*theta)
check('small_angle_quadratic_margin',abs(ratio-1)<1e-7,ratio)
metrics['mixing_curve']=curve

# A tracking example whose block error bound is attained, not just respected
T=np.array([[0.,-.25],[1.,0.]])
eps=np.array([.01,.02]); v=np.array([1.,-2.]); m=2; q=sn(T@T)
err0=np.linalg.norm(v); block_forcing=2*np.linalg.norm(eps)
for k in range(80):v=T@v+eps
tube=m*np.linalg.norm(eps)/(1-q)
check('block_tracking_error_tube',np.linalg.norm(v)<=tube+1e-14,np.linalg.norm(v)/tube)
scalar=.4; err=.03; v=1.
for _ in range(100):v=scalar*v+err
check('tracking_geometric_bound_sharp',abs(v-err/(1-scalar))<1e-14,v)
metrics['rotation_quarter_turn_radius']=curve[-1][1]

# 22 exact secant and endpoint-certified curvature
secant_error=0.; robust_max_certificate=0.
for trial in range(40):
    C=rng.normal(size=(8,3)); u=rng.normal(size=3); b=rng.normal(size=8); bp=b.copy(); bp[:2]+=rng.normal(size=2)*10
    z,cz=huber(u,C,b,beta=2); zp,czp=huber(u,C,bp,beta=2)
    robust_max_certificate=max(robust_max_certificate,cz,czp)
    d=zp-z; s=C@d; residual=C@z-b
    ds=np.clip(residual+s,-.5,.5)-np.clip(residual,-.5,.5)
    omega=np.divide(ds,s,out=np.zeros_like(s),where=np.abs(s)>1e-15)
    Delta=2*C[:2].T@(np.clip((C@zp-b)[:2],-.5,.5)-np.clip((C@zp-bp)[:2],-.5,.5))
    secant_error=max(secant_error,np.linalg.norm((np.eye(3)+2*C.T@(omega[:,None]*C))@d-Delta))
check('robust_exact_secant_40_trials',secant_error<2e-10,secant_error)
check('robust_stationarity_certificates',robust_max_certificate<2e-10,robust_max_certificate)
C=np.vstack([np.tile(np.eye(2),(8,1)),np.eye(2)]); b=np.r_[np.zeros(16),[-100.,-100.]]; bp=np.r_[np.zeros(16),[100.,100.]]
z,cz=huber(np.zeros(2),C,b,beta=3); zp,czp=huber(np.zeros(2),C,bp,beta=3)
actual=np.linalg.norm(zp-z); coarse=6.; refined=coarse/25
check('clean_curvature_explicit_solutions',np.linalg.norm(z-np.array([-.06,-.06]))<1e-12 and np.linalg.norm(zp-np.array([.06,.06]))<1e-12)
check('clean_curvature_improves_25_fold',actual<=refined and coarse/refined==25,actual)
check('approximate_endpoints_certify_clean_set',max(np.abs(C[:16]@zp))+max(np.linalg.norm(C[:16],axis=1))*czp<.5)
metrics['clean_curvature']={'measured':actual,'universal':coarse,'refined':refined}

# 23 uniform robust summary across proposals, exact histogram equality
K=4; n=400; dictionary=rng.normal(size=(K,3)); dictionary/=np.linalg.norm(dictionary,axis=1)[:,None]
ids=np.repeat(np.arange(K),n//K); C=dictionary[ids]; b=rng.uniform(-2,2,size=n); width=.25
bin_id=np.floor((b+2)/width).astype(int); centres=-2+(bin_id+.5)*width
keys,counts=np.unique(np.stack([ids,bin_id],axis=1),axis=0,return_counts=True)
smallC=dictionary[keys[:,0]]; smallb=-2+(keys[:,1]+.5)*width
mu=1.; beta=2/n; bound=beta/mu*np.sum(np.linalg.norm(C,axis=1)*np.abs(b-centres))
maxshift=hist_exact=0.; hist_cert=0.
for _ in range(30):
    u=rng.normal(size=3)*3
    z,cz=huber(u,C,b,mu,beta); zq,cq=huber(u,C,centres,mu,beta)
    zh,ch=huber(u,smallC,smallb,mu,beta,weights=counts)
    maxshift=max(maxshift,np.linalg.norm(z-zq)); hist_exact=max(hist_exact,np.linalg.norm(zq-zh)); hist_cert=max(hist_cert,cz,cq,ch)
check('histogram_equals_quantized_bank_30_queries',hist_exact<2e-11,hist_exact)
check('histogram_uniform_read_bound_30_queries',maxshift<=bound+1e-11,maxshift/bound)
check('histogram_compresses_row_records',len(keys)<n,len(keys))
check('histogram_solve_certificates',hist_cert<2e-10,hist_cert)
metrics['histogram']={'rows':n,'occupied_bins':len(keys),'max_measured_shift':maxshift,'certified_bound':bound}

# Moving rows need both a state bound and a separate gradient bound
roweps=.01; move=rng.normal(size=dictionary.shape); move*=roweps/np.linalg.norm(move,axis=1)[:,None]
smallC_moved=(dictionary+move)[keys[:,0]]; U=5.; Z=U+beta*.5*n*(1+roweps)/mu
rowbound=beta*n/mu*(.5*roweps+(1+roweps)*(Z*roweps+width/2))
max_moved_error=max_moved_state=0.
for _ in range(20):
    u=rng.normal(size=3);u*=U/np.linalg.norm(u)
    z,cz=huber(u,C,b,mu,beta);zm,cm=huber(u,smallC_moved,smallb,mu,beta,weights=counts)
    max_moved_error=max(max_moved_error,np.linalg.norm(z-zm));max_moved_state=max(max_moved_state,np.linalg.norm(zm))
check('moving_rows_uniform_state_bound',max_moved_state<=Z+1e-11,max_moved_state)
check('moving_rows_uniform_read_bound',max_moved_error<=rowbound+1e-11,max_moved_error/rowbound)
metrics['moving_rows']={'max_measured_shift':max_moved_error,'certified_bound':rowbound,'state_bound':Z}

# 24 exact task constants, equality examples and impossibility
C=rng.normal(size=(3,5)); ell=C.T@rng.normal(size=3); ystar=np.linalg.pinv(C).T@ell
check('task_minimum_norm_factorization',np.linalg.norm(C.T@ystar-ell)<1e-12)
b=rng.normal(size=3); p=np.linalg.pinv(C)@b; z=p+np.linalg.pinv(C)@ystar
measured=abs(ell@(z-p)); taskbound=np.linalg.norm(ystar)*np.linalg.norm(C@z-b)
check('task_residual_constant_sharp',abs(measured-taskbound)<1e-11,abs(measured-taskbound))
C=np.array([[1.,0.],[1.,0.]])
b=np.array([0.,2.]); p=np.linalg.pinv(C)@b; eta=b-C@p; z=np.array([3.,77.]); ell=np.array([1.,0.]); ystar=np.linalg.pinv(C).T@ell
floorbound=np.linalg.norm(ystar)*math.sqrt(np.linalg.norm(C@z-b)**2-np.linalg.norm(eta)**2)
check('task_certificate_inconsistent_floor',abs(abs(ell@(z-p))-floorbound)<1e-13,floorbound)
check('uncovered_task_unbounded_at_zero_residual',np.linalg.norm(np.array([[1.,0.]])@np.array([0.,1e6]))==0.)
C=rng.normal(size=(3,5)); ell=C.T@rng.normal(size=3); ystar=np.linalg.pinv(C).T@ell; eps=.2
xp=eps*np.linalg.pinv(C)@ystar/np.linalg.norm(ystar); noise=-C@xp
check('minimax_two_worlds_same_observation',np.linalg.norm(C@xp+noise)<1e-14)
check('minimax_noise_is_admissible',abs(np.linalg.norm(noise)-eps)<1e-13)
check('minimax_lower_bound_attained',abs(ell@xp-eps*np.linalg.norm(ystar))<1e-13)

# 19 corrected scope at p = 0
N=100; c=.5; exact=(1+c)**(-N)
check('constant_schedule_exact_rate',abs(math.log(exact)+N*math.log1p(c))<1e-12)
check('constant_schedule_not_harmonic_asymptotic',abs(math.log(exact)+N*c)>1.)

result={'seed':20261022,'numpy':np.__version__,'all_passed':all(c['passed'] for c in checks),'count':len(checks),'checks':checks,'metrics':metrics}
(P/'v5_results.json').write_text(json.dumps(result,indent=2)+'\n')
for c in checks:print(('PASS' if c['passed'] else 'FAIL'),c['name'])
print('ALL',result['all_passed'],len(checks))
