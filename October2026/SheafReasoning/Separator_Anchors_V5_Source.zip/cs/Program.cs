// Version 4 numerical explorations. Every printed line is recomputed
// independently by cs_validate.py with NumPy from the same SplitMix64 stream.
using System;
using System.Collections.Immutable;
using System.Globalization;
using System.Linq;
using Sidecar;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

static string F(double x) => x.ToString("G17", CultureInfo.InvariantCulture);
static void Print(string name, params double[] xs) =>
    Console.WriteLine(name + " " + string.Join(" ", xs.Select(F)));

// Modified Gram-Schmidt orthonormalisation of the columns of a square matrix.
static Mat Orthonormal(Mat a)
{
    int n = a.Rows; var q = new double[n][];
    for (int j = 0; j < n; j++)
    {
        var v = Enumerable.Range(0, n).Select(i => a[i, j]).ToArray();
        for (int k = 0; k < j; k++)
        {
            double d = v.Zip(q[k], (x, y) => x * y).Sum();
            for (int i = 0; i < n; i++) v[i] -= d * q[k][i];
        }
        double nrm = Math.Sqrt(v.Sum(x => x * x));
        q[j] = v.Select(x => x / nrm).ToArray();
    }
    return Mat.Build(n, n, (i, j) => q[j][i]);
}
static double Median(double[] x) { var s = x.OrderBy(v => v).ToArray();
    return s.Length % 2 == 1 ? s[s.Length / 2] : 0.5 * (s[s.Length / 2 - 1] + s[s.Length / 2]); }

var rng = new Rng(20261020UL);

// ---------------------------------------------------------------- A. V3 values
var ct = Mat.Rows_(new[] { 1.0 }, new[] { 1.0 });
var eta = Reads.Obstruction(ct, V.Of(0, 2));
Print("grounded_tree", eta[0], eta[1], V.Norm(eta));
var (bayes, prox) = Reads.Gains(0.5, 5);
Print("bayes_prox_gains", bayes, prox);
var alphas = Enumerable.Range(0, 20).Select(j => 0.1 / Math.Pow(j + 1, 2)).ToImmutableArray();
var ones = Enumerable.Repeat(1.0, 20).ToImmutableArray();
Print("twenty_reads", Reads.ScheduleGain(alphas, ones, 1), Reads.ScheduleFloor(alphas, ones, 1));
Print("equivalent_ratio", Reads.EquivalentRatio(0.5, 1, 5), Reads.EquivalentRatio(0.5, 4, 5));
var c3 = Mat.Rows_(new[] { 1.0 }, new[] { 1.0 }, new[] { 1.0 });
var bA = V.Of(-1, 0, 1); var bB = V.Of(1 / Math.Sqrt(3), 1 / Math.Sqrt(3), -2 / Math.Sqrt(3));
var sA = Reads.Consolidate(c3, bA); var sB = Reads.Consolidate(c3, bB);
Print("consolidation_stats", sA.A[0, 0], sA.D[0], sA.E, sB.A[0, 0], sB.D[0], sB.E);
var hA = Reads.Huber(V.Of(0), c3, bA, 1, 1, 0.5); var hB = Reads.Huber(V.Of(0), c3, bB, 1, 1, 0.5);
Print("huber_consolidation", hA[0], hB[0], Reads.HuberGradient(hB, V.Of(0), c3, bB, 1, 1, 0.5));
Print("nonisometric_square",
      Reads.Quadratic(V.Of(1), Mat.Diag(1), V.Of(0), 1, 1)[0],
      Reads.Quadratic(V.Of(1), Mat.Diag(2), V.Of(0), 1, 1)[0]);
var j2 = Mat.Diag(0.5, 1);
Print("loop_radius", LinAlg.SpectralRadius(j2.Mul(Mat.Diag(1, 1.1))),
      LinAlg.SpectralRadius(j2.Mul(Mat.Diag(1.2, 0.8))));
var c2 = Mat.Identity(2);
var hz = Reads.Huber(V.Of(0, 0), c2, V.Of(100, 0), 1, 3, 0.5);
Vec Hk(int k, double h) => Reads.Huber(V.Of(k == 0 ? h : 0, k == 1 ? h : 0), c2, V.Of(100, 0),
                                        1, 3, 0.5);
double Fd(int k) => (Hk(k, 1e-6)[k] - Hk(k, -1e-6)[k]) / 2e-6;
Print("huber_active", hz[0], hz[1], Fd(0), Fd(1));
var plus = Reads.Huber(V.Of(0), Mat.Diag(1), V.Of(1000), 1, 3, 0.5);
var minus = Reads.Huber(V.Of(0), Mat.Diag(1), V.Of(-1000), 1, 3, 0.5);
Print("factor_two", plus[0] - minus[0], 2 * 3 * 0.5 / 1);
double mu = 1, beta = 4;
var cInf = Mat.Diag(Math.Sqrt(mu / beta), 2.0, 0.1);
var kmat = LinAlg.Inverse(Mat.Identity(3).Scale(mu).Add(cInf.T.Mul(cInf).Scale(beta)))
                 .Mul(cInf.T).Scale(beta);
Print("anchor_influence", LinAlg.SpectralNorm(kmat), 0.5 * Math.Sqrt(beta / mu));
// metric covariance (Theorem 9.2) on random data
Mat q0, cm; Vec um, bm;
(q0, rng) = rng.NormalMat(4, 4); (cm, rng) = rng.NormalMat(3, 4);
Mat tmp; (tmp, rng) = rng.NormalMat(1, 4); um = tmp.Data;
(tmp, rng) = rng.NormalMat(1, 3); bm = tmp.Data;
Mat gr; (gr, rng) = rng.NormalMat(4, 4); var gm = gr.T.Mul(gr).Add(Mat.Identity(4));
var qInv = LinAlg.Pinv(q0);
var lhs = Reads.Quadratic(q0.Apply(um), cm.Mul(qInv), bm, 0.7, 2.0, qInv.T.Mul(gm).Mul(qInv));
var rhs = q0.Apply(Reads.Quadratic(um, cm, bm, 0.7, 2.0, gm));
Print("metric_covariance", lhs.Zip(rhs, (a, b) => Math.Abs(a - b)).Max());

// ---------------------------------------------------------------- B. schedules
foreach (var n in new[] { 10, 100, 1000, 10000 })
{
    ImmutableArray<double> Sched(double p) =>
        Enumerable.Range(0, n).Select(j => 0.5 / Math.Pow(j + 1, p)).ToImmutableArray();
    var g1 = Enumerable.Repeat(1.0, n).ToImmutableArray();
    Print($"schedule_N{n}", Reads.ScheduleGain(Sched(0.5), g1, 1), Reads.ScheduleGain(Sched(1), g1, 1),
          Reads.HarmonicGain(0.5, 1, n), Reads.ScheduleGain(Sched(2), g1, 1));
}

// ---------------------------------------------------------------- C. robust bound tightness
var ratios = new double[400]; double cert = 0;
for (int t = 0; t < 400; t++)
{
    Mat cr, ur, br, amp;
    (cr, rng) = rng.NormalMat(8, 4); (ur, rng) = rng.NormalMat(1, 4);
    (br, rng) = rng.NormalMat(1, 8);
    (amp, rng) = rng.NormalMat(1, 2);
    var b2 = br.Data.ToArray(); b2[0] += 100 * amp.Data[0]; b2[1] += 100 * amp.Data[1];
    var z0 = Reads.Huber(ur.Data, cr, br.Data, 1, 3, 0.5);
    var z1 = Reads.Huber(ur.Data, cr, b2.ToImmutableArray(), 1, 3, 0.5);
    double bound = 2 * 3 * 0.5 / 1 * (V.Norm(cr.Row(0).Data) + V.Norm(cr.Row(1).Data));
    cert = Math.Max(cert, Math.Max(
        Reads.HuberGradient(z0, ur.Data, cr, br.Data, 1, 3, 0.5),
        Reads.HuberGradient(z1, ur.Data, cr, b2.ToImmutableArray(), 1, 3, 0.5)));
    ratios[t] = V.Norm(V.Add(z1, z0, -1)) / bound;
}
Print("robust_tightness", ratios.Max(), Median(ratios), ratios.Average());
Print("robust_certificate", cert);

// ---------------------------------------------------------------- D. insertion drift
{
    int r = 16; Mat u0; (u0, rng) = rng.NormalMat(1, r);
    var z = u0.Data; var hInv = Mat.Identity(r);
    var acc = Mat.Identity(r); var rhsAcc = u0.Data;
    var drift = new System.Collections.Generic.List<double>();
    for (int m = 1; m <= 2000; m++)
    {
        Mat cc, yy; (cc, rng) = rng.NormalMat(1, r); (yy, rng) = rng.NormalMat(1, 1);
        (z, hInv) = Reads.Insert(z, hInv, cc.Data, yy.Data[0], 1.0);
        acc = acc.Add(cc.T.Mul(cc)); rhsAcc = V.Add(rhsAcc, cc.Data, yy.Data[0]);
        if (m is 10 or 100 or 1000 or 2000)
        {
            var exact = LinAlg.Solve(acc, rhsAcc);
            drift.Add(V.Add(z, exact, -1).Max(Math.Abs));
            if (m == 2000) Print("insertion_exact_head", exact[0], exact[1], exact[2]);
        }
    }
    Print("insertion_drift", drift.ToArray());
}

// ---------------------------------------------------------------- E. loop stability
foreach (var k in new[] { 0, 1, 2, 3 })
{
    int r = 6; var cl = Mat.Build(r - k, r, (i, j) => i == j ? 1 : 0);
    var jg = Reads.Gain(cl, 1, 4);
    var smix = new double[100];
    for (int t = 0; t < 100; t++)
    {
        Mat a; (a, rng) = rng.NormalMat(r, r);
        smix[t] = 1 / LinAlg.SpectralRadius(jg.Mul(Orthonormal(a)));
    }
    Print($"loop_private{k}", 1 / LinAlg.SpectralRadius(jg), smix.Min(), Median(smix), smix.Max());
}

// ---------------------------------------------------------------- F. equivariance tightness
var er = new double[300];
for (int t = 0; t < 300; t++)
{
    Mat a1, a2, c0, e, u1, b1;
    (a1, rng) = rng.NormalMat(4, 4); (a2, rng) = rng.NormalMat(3, 3); (c0, rng) = rng.NormalMat(3, 4);
    (e, rng) = rng.NormalMat(3, 4); (u1, rng) = rng.NormalMat(1, 4); (b1, rng) = rng.NormalMat(1, 3);
    var tt = Orthonormal(a1); var ss = Orthonormal(a2);
    var c1 = ss.Mul(c0).Mul(tt.T).Add(e, 0.05);
    var (meas, bnd) = Reads.Equivariance(c0, c1, tt, ss, u1.Data, b1.Data, 1, 2);
    er[t] = meas / bnd;
}
Print("equivariance_tightness", er.Max(), Median(er), er.Min());
