// Separator-anchor sidecar: an immutable reference kernel for Version 4.
// Records hold data; every public function is pure. Numerical routines work
// on private copies (Cholesky, Jacobi, Gelfand iteration) and return new
// immutable values.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace Sidecar;

/// <summary>A dense real matrix, row-major and immutable.</summary>
public sealed record Mat(int Rows, int Cols, Vec Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Mat Build(int r, int c, Func<int, int, double> f) =>
        new(r, c, Enumerable.Range(0, r * c).Select(k => f(k / c, k % c))
                            .ToImmutableArray());

    public static Mat Identity(int n) => Build(n, n, (i, j) => i == j ? 1 : 0);
    public static Mat Diag(params double[] d) =>
        Build(d.Length, d.Length, (i, j) => i == j ? d[i] : 0);
    public static Mat Rows_(params double[][] rows) =>
        Build(rows.Length, rows[0].Length, (i, j) => rows[i][j]);

    public Mat T => Build(Cols, Rows, (i, j) => this[j, i]);
    public Mat Mul(Mat b) =>
        Build(Rows, b.Cols, (i, j) => Enumerable.Range(0, Cols).Sum(k => this[i, k] * b[k, j]));
    public Vec Apply(Vec x) =>
        Enumerable.Range(0, Rows).Select(i => Enumerable.Range(0, Cols)
            .Sum(k => this[i, k] * x[k])).ToImmutableArray();
    public Mat Add(Mat b, double s = 1) => Build(Rows, Cols, (i, j) => this[i, j] + s * b[i, j]);
    public Mat Scale(double s) => Build(Rows, Cols, (i, j) => s * this[i, j]);
    public Mat Row(int i) => Build(1, Cols, (_, j) => this[i, j]);
}

/// <summary>Quadratic-read sufficient statistics (Theorem 13.1).</summary>
public sealed record BankStats(Mat A, Vec D, double E)
{
    public BankStats Merge(BankStats o) =>
        new(A.Add(o.A), V.Add(D, o.D), E + o.E);
}

public static class V
{
    public static Vec Of(params double[] x) => ImmutableArray.Create(x);
    public static Vec Add(Vec a, Vec b, double s = 1) =>
        a.Zip(b, (p, q) => p + s * q).ToImmutableArray();
    public static Vec Scale(Vec a, double s) => a.Select(p => s * p).ToImmutableArray();
    public static double Dot(Vec a, Vec b) => a.Zip(b, (p, q) => p * q).Sum();
    public static double Norm(Vec a) => Math.Sqrt(Dot(a, a));
}

/// <summary>Deterministic SplitMix64 stream, shared with the Python check.</summary>
public sealed record Rng(ulong State)
{
    public (ulong Value, Rng Next) NextU64()
    {
        ulong s = State + 0x9E3779B97F4A7C15UL, z = s;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
        return (z ^ (z >> 31), new Rng(s));
    }

    public (double Value, Rng Next) Uniform()
    {
        var (v, n) = NextU64();
        return ((v >> 11) * (1.0 / 9007199254740992.0), n);
    }

    /// <summary>Standard normal by Box-Muller (one value per two uniforms).</summary>
    public (double Value, Rng Next) Normal()
    {
        var (u1, r1) = Uniform();
        var (u2, r2) = r1.Uniform();
        return (Math.Sqrt(-2 * Math.Log(1 - u1)) * Math.Cos(2 * Math.PI * u2), r2);
    }

    public (Mat Value, Rng Next) NormalMat(int r, int c)
    {
        var vals = new double[r * c]; var g = this;
        for (int k = 0; k < r * c; k++) (vals[k], g) = g.Normal();
        return (new Mat(r, c, vals.ToImmutableArray()), g);
    }
}

public static class LinAlg
{
    /// <summary>Solve H x = h for symmetric positive definite H (Cholesky).</summary>
    public static Vec Solve(Mat h, Vec rhs)
    {
        int n = h.Rows; var l = new double[n, n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j <= i; j++)
            {
                double s = h[i, j];
                for (int k = 0; k < j; k++) s -= l[i, k] * l[j, k];
                l[i, j] = i == j ? Math.Sqrt(s) : s / l[j, j];
            }
        var y = new double[n];
        for (int i = 0; i < n; i++)
        {
            double s = rhs[i];
            for (int k = 0; k < i; k++) s -= l[i, k] * y[k];
            y[i] = s / l[i, i];
        }
        var x = new double[n];
        for (int i = n - 1; i >= 0; i--)
        {
            double s = y[i];
            for (int k = i + 1; k < n; k++) s -= l[k, i] * x[k];
            x[i] = s / l[i, i];
        }
        return x.ToImmutableArray();
    }

    public static Mat Inverse(Mat h) =>
        ColumnsToMat(Enumerable.Range(0, h.Rows)
            .Select(j => Solve(h, Mat.Identity(h.Rows).Row(j).Data)).ToArray());

    static Mat ColumnsToMat(Vec[] cols) =>
        Mat.Build(cols[0].Length, cols.Length, (i, j) => cols[j][i]);

    /// <summary>Eigenvalues (ascending) and eigenvectors of a symmetric matrix
    /// by cyclic Jacobi rotations.</summary>
    public static (Vec Values, Mat Vectors) SymEig(Mat m)
    {
        int n = m.Rows; var a = m.Data.ToArray(); var v = Mat.Identity(n).Data.ToArray();
        for (int sweep = 0; sweep < 100; sweep++)
        {
            double off = 0;
            for (int p = 0; p < n; p++)
                for (int q = p + 1; q < n; q++) off += a[p * n + q] * a[p * n + q];
            if (off < 1e-300) break;
            for (int p = 0; p < n - 1; p++)
                for (int q = p + 1; q < n; q++)
                {
                    double apq = a[p * n + q];
                    if (apq == 0) continue;
                    double th = (a[q * n + q] - a[p * n + p]) / (2 * apq);
                    double t = th == 0 ? 1 : Math.Sign(th) / (Math.Abs(th) + Math.Sqrt(th * th + 1));
                    double c = 1 / Math.Sqrt(t * t + 1), s = t * c;
                    for (int k = 0; k < n; k++)
                        (a[k * n + p], a[k * n + q]) =
                            (c * a[k * n + p] - s * a[k * n + q], s * a[k * n + p] + c * a[k * n + q]);
                    for (int k = 0; k < n; k++)
                        (a[p * n + k], a[q * n + k]) =
                            (c * a[p * n + k] - s * a[q * n + k], s * a[p * n + k] + c * a[q * n + k]);
                    for (int k = 0; k < n; k++)
                        (v[k * n + p], v[k * n + q]) =
                            (c * v[k * n + p] - s * v[k * n + q], s * v[k * n + p] + c * v[k * n + q]);
                }
        }
        var order = Enumerable.Range(0, n).OrderBy(i => a[i * n + i]).ToArray();
        return (order.Select(i => a[i * n + i]).ToImmutableArray(),
                Mat.Build(n, n, (i, j) => v[i * n + order[j]]));
    }

    /// <summary>Moore-Penrose inverse through the eigen-decomposition of C^T C.</summary>
    public static Mat Pinv(Mat c, double tol = 1e-12)
    {
        var (w, q) = SymEig(c.T.Mul(c));
        double top = w.Max(Math.Abs);
        var inv = Mat.Build(w.Length, w.Length,
            (i, j) => i == j && w[i] > tol * Math.Max(top, 1) ? 1 / w[i] : 0);
        return q.Mul(inv).Mul(q.T).Mul(c.T);
    }

    public static double SpectralNorm(Mat m) => Math.Sqrt(SymEig(m.T.Mul(m)).Values.Max());

    /// <summary>Spectral radius by Gelfand's formula, rho = lim ||M^k||^(1/k),
    /// with k = 2^steps by repeated normalised squaring.</summary>
    public static double SpectralRadius(Mat m, int steps = 40)
    {
        double logScale = 0; var p = m;
        for (int s = 0; s < steps; s++)
        {
            double nrm = p.Data.Max(Math.Abs);
            if (nrm == 0) return 0;
            p = p.Scale(1 / nrm); logScale = 2 * (logScale + Math.Log(nrm));
            p = p.Mul(p);
        }
        double fin = Math.Log(p.Data.Max(Math.Abs));
        return Math.Exp((logScale + fin) / Math.Pow(2, steps));
    }

    /// <summary>log Gamma by the Lanczos approximation (g = 7, n = 9).</summary>
    public static double LogGamma(double x)
    {
        double[] c = { 0.99999999999980993, 676.5203681218851, -1259.1392167224028,
            771.32342877765313, -176.61502916214059, 12.507343278686905,
            -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7 };
        if (x < 0.5) return Math.Log(Math.PI / Math.Abs(Math.Sin(Math.PI * x))) - LogGamma(1 - x);
        x -= 1; double a = c[0], t = x + 7.5;
        for (int i = 1; i < 9; i++) a += c[i] / (x + i);
        return 0.5 * Math.Log(2 * Math.PI) + (x + 0.5) * Math.Log(t) - t + Math.Log(a);
    }
}

public static class Reads
{
    /// <summary>Metric quadratic read (17): (mu G + beta C^T C) z = mu G u + beta C^T b.</summary>
    public static Vec Quadratic(Vec u, Mat c, Vec b, double mu, double beta, Mat? g = null)
    {
        var gm = g ?? Mat.Identity(u.Length);
        var h = gm.Scale(mu).Add(c.T.Mul(c).Scale(beta));
        return LinAlg.Solve(h, V.Add(gm.Apply(u).Select(x => mu * x).ToImmutableArray(),
                                     c.T.Apply(b), beta));
    }

    /// <summary>Robust read (28) by semismooth Newton on the active set.</summary>
    public static Vec Huber(Vec u, Mat c, Vec b, double mu, double beta, double delta)
    {
        // Semismooth Newton with Armijo backtracking on the strongly convex objective.
        var z = Quadratic(u, c, b, mu, beta);
        for (int it = 0; it < 500; it++)
        {
            var r = V.Add(c.Apply(z), b, -1);
            var psi = r.Select(t => Math.Clamp(t, -delta, delta)).ToImmutableArray();
            var grad = V.Add(V.Scale(V.Add(z, u, -1), mu), c.T.Apply(psi), beta);
            if (V.Norm(grad) < 1e-13 * (1 + V.Norm(u) + V.Norm(b))) break;
            var w = Mat.Diag(r.Select(t => Math.Abs(t) < delta ? 1.0 : 0.0).ToArray());
            var h = Mat.Identity(u.Length).Scale(mu)
                       .Add(c.T.Mul(w).Mul(c).Scale(beta));
            var step = LinAlg.Solve(h, grad);
            double f0 = HuberObjective(z, u, c, b, mu, beta, delta), slope = V.Dot(grad, step);
            double s = 1;
            while (s > 1e-12 && HuberObjective(V.Add(z, step, -s), u, c, b, mu, beta, delta)
                                > f0 - 1e-4 * s * slope) s *= 0.5;
            z = V.Add(z, step, -s);
        }
        return z;
    }

    /// <summary>Robust objective mu/2|z-u|^2 + beta sum rho_delta(c_i z - b_i).</summary>
    public static double HuberObjective(Vec z, Vec u, Mat c, Vec b, double mu, double beta,
                                        double delta) =>
        0.5 * mu * Math.Pow(V.Norm(V.Add(z, u, -1)), 2)
        + beta * V.Add(c.Apply(z), b, -1).Sum(t => Math.Abs(t) <= delta
                                                     ? 0.5 * t * t
                                                     : delta * Math.Abs(t) - 0.5 * delta * delta);

    /// <summary>Stationarity residual of the robust objective (a posteriori certificate).</summary>
    public static double HuberGradient(Vec z, Vec u, Mat c, Vec b, double mu, double beta, double delta)
    {
        var r = V.Add(c.Apply(z), b, -1);
        var psi = r.Select(t => Math.Clamp(t, -delta, delta)).ToImmutableArray();
        return V.Norm(V.Add(V.Scale(V.Add(z, u, -1), mu), c.T.Apply(psi), beta));
    }

    /// <summary>Grounded obstruction (21): eta = (I - C C^+) b.</summary>
    public static Vec Obstruction(Mat c, Vec b) =>
        V.Add(b, c.Mul(LinAlg.Pinv(c)).Apply(b), -1);

    /// <summary>Retained gain (23) of a gated schedule on eigenvalue lambda.</summary>
    public static double ScheduleGain(ImmutableArray<double> alpha, ImmutableArray<double> gate,
                                      double lambda) =>
        alpha.Zip(gate, (a, g) => 1 - g * a * lambda / (1 + a * lambda))
             .Aggregate(1.0, (p, f) => p * f);

    /// <summary>Corollary 11.2 lower bound exp(-S/(1 - a_max)).</summary>
    public static double ScheduleFloor(ImmutableArray<double> alpha, ImmutableArray<double> gate,
                                       double lambda)
    {
        var a = alpha.Zip(gate, (x, g) => g * x * lambda / (1 + x * lambda)).ToArray();
        return Math.Exp(-a.Sum() / (1 - a.Max()));
    }

    /// <summary>New Proposition: harmonic schedule alpha_j = c/(j+1), unit gates,
    /// gives Gamma(N+1)Gamma(1+c lambda)/Gamma(N+1+c lambda) exactly.</summary>
    public static double HarmonicGain(double c, double lambda, int n) =>
        Math.Exp(LinAlg.LogGamma(n + 1) + LinAlg.LogGamma(1 + c * lambda)
                 - LinAlg.LogGamma(n + 1 + c * lambda));

    /// <summary>Equation (26): single-read ratio matching n reads at ratio alpha.</summary>
    public static double EquivalentRatio(double alpha, double lambda, int n) =>
        (Math.Pow(1 + alpha * lambda, n) - 1) / lambda;

    /// <summary>Equation (27): Bayesian and proximal prior-mean gains.</summary>
    public static (double Bayes, double Prox) Gains(double alphaLambda, int n) =>
        (1 / (1 + n * alphaLambda), Math.Pow(1 + alphaLambda, -n));

    /// <summary>Theorem 13.1: consolidated statistics of a bank.</summary>
    public static BankStats Consolidate(Mat c, Vec b) =>
        new(c.T.Mul(c), c.T.Apply(b), V.Dot(b, b));

    public static Vec ReadFromStats(Vec u, BankStats s, double mu, double beta) =>
        LinAlg.Solve(Mat.Identity(u.Length).Scale(mu).Add(s.A.Scale(beta)),
                     V.Add(V.Scale(u, mu), s.D, beta));

    /// <summary>Corollary 13.2 with an explicitly stored inverse (Sherman-Morrison);
    /// returns the new state and the new inverse.</summary>
    public static (Vec Z, Mat HInv) Insert(Vec z, Mat hInv, Vec c, double y, double tau)
    {
        var hc = hInv.Apply(c);
        double den = 1 + tau * V.Dot(c, hc);
        var zNew = V.Add(z, hc, tau * (y - V.Dot(c, z)) / den);
        var hInvNew = Mat.Build(hInv.Rows, hInv.Cols, (i, j) => hInv[i, j] - tau * hc[i] * hc[j] / den);
        return (zNew, hInvNew);
    }

    /// <summary>Proposition 14.3 bound and the measured discrepancy.</summary>
    public static (double Measured, double Bound) Equivariance(Mat c0, Mat c1, Mat t, Mat s,
        Vec u, Vec b, double mu, double beta)
    {
        var z0 = Quadratic(u, c0, b, mu, beta);
        var z1 = Quadratic(t.Apply(u), c1, s.Apply(b), mu, beta);
        var d = c1.Mul(t).Add(s.Mul(c0), -1);
        double bound = beta / mu * LinAlg.SpectralNorm(d) * (V.Norm(b)
            + (LinAlg.SpectralNorm(c1) + LinAlg.SpectralNorm(c0)) * V.Norm(z0));
        return (V.Norm(V.Add(z1, t.Apply(z0), -1)), bound);
    }

    /// <summary>Read gain J = mu (mu I + beta C^T C)^{-1}.</summary>
    public static Mat Gain(Mat c, double mu, double beta) =>
        LinAlg.Inverse(Mat.Identity(c.Cols).Scale(mu).Add(c.T.Mul(c).Scale(beta))).Scale(mu);
}
