"""Build V5 as an editable scholarly Word document with native OMML maths."""
from pathlib import Path
import re
import subprocess
import sys
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph

P=Path(__file__).resolve().parent
(P/'output').mkdir(exist_ok=True)
doc=Document(P/'reference.docx')
for child in list(doc._element.body):
    if child.tag!=qn('w:sectPr'):doc._element.body.remove(child)
for sec in doc.sections:
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.left_margin=sec.right_margin=Inches(.78)
    sec.top_margin=sec.bottom_margin=Inches(.72)
    sec.header_distance=sec.footer_distance=Inches(.3)
    for part in (sec.header,sec.first_page_header,sec.even_page_header,sec.footer,sec.first_page_footer,sec.even_page_footer):
        for p in part.paragraphs:p.clear()
    foot=sec.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.CENTER
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');foot._p.append(field)
for name in ['Normal','Body Text','First Paragraph','Compact','Statement']:
    st=doc.styles[name];st.font.name='Liberation Serif';st.font.size=Pt(11)
    st.paragraph_format.line_spacing=1.08;st.paragraph_format.space_after=Pt(6)
    st.paragraph_format.widow_control=True
for st in doc.styles:
    if st.type==1:
        st.font.color.rgb=RGBColor(0,0,0)
    for node in list(st.element.iter()):
        if node.tag in [qn('w:pBdr'),qn('w:shd')]:node.getparent().remove(node)
        if node.tag==qn('w:color'):
            node.set(qn('w:val'),'000000')
            for name in ['themeColor','themeTint','themeShade']:
                node.attrib.pop(qn('w:'+name),None)
doc.styles['Title'].font.name='Liberation Serif';doc.styles['Title'].font.size=Pt(23)
doc.styles['Title'].paragraph_format.space_after=Pt(9)
doc.styles['Subtitle'].font.name='Liberation Serif';doc.styles['Subtitle'].font.size=Pt(12)
for name in ['Title','Subtitle','Author','Date']:
    doc.styles[name].paragraph_format.keep_with_next=True
doc.styles['Date'].paragraph_format.space_after=Pt(13)
for name,size in [('Heading 1',14),('Heading 2',12),('Heading 3',11)]:
    st=doc.styles[name];st.font.name='Liberation Serif';st.font.size=Pt(size);st.font.bold=True
    st.paragraph_format.space_before=Pt(13 if name=='Heading 1' else 10)
    st.paragraph_format.space_after=Pt(6);st.paragraph_format.keep_with_next=True
    st.paragraph_format.keep_together=True
doc.styles['Bibliography'].font.size=Pt(10)
doc.styles['Bibliography'].paragraph_format.space_after=Pt(6)
for name in ['Caption','Image Caption','Table Caption']:
    if name in doc.styles:
        st=doc.styles[name];st.font.size=Pt(9.5);st.paragraph_format.space_after=Pt(9)
for name in ['Equation','Statement Equation']:
    pf=doc.styles[name].paragraph_format
    pf.space_before=Pt(4);pf.space_after=Pt(8);pf.line_spacing=1.0;pf.keep_together=True
    pf.keep_with_next=False
    pr=doc.styles[name].element.get_or_add_pPr()
    for old in pr.findall(qn('w:tabs')):pr.remove(old)
    tabs=OxmlElement('w:tabs')
    for value,pos in [('center',4997),('right',9994)]:
        el=OxmlElement('w:tab');el.set(qn('w:val'),value);el.set(qn('w:pos'),str(pos));tabs.append(el)
    pr.append(tabs)
doc.save(P/'build_reference.docx')
s=(P/'paper.md').read_text()

def display(match):
    math=match[1].strip();num=re.search(r'\\tag\{(\d+)\}',math)
    if num is None:
        # Keep every display as native math, in the same equation paragraph style.
        return '\n::: {custom-style="Equation"}\n$'+math.replace('\n',' ')+'$\n:::\n'
    math=math[:num.start()].strip()
    aligned=math.startswith(r'\begin{aligned}')
    lines=math.replace(r'\begin{aligned}','').replace(r'\end{aligned}','').split(r'\\') if aligned else [math]
    return '\n'.join('\n::: {custom-style="Equation"}\n$'+(line.replace('&','') if aligned else line).replace('\n',' ').strip()+'$'+(' ('+num[1]+')' if i==len(lines)-1 else '')+'\n:::\n' for i,line in enumerate(lines))
s=re.sub(r'\$\$(.*?)\$\$',display,s,flags=re.S)
(P/'build.md').write_text(s)
subprocess.run(['pandoc','-f','markdown+tex_math_dollars','build.md','-o','raw.docx','--reference-doc=build_reference.docx','--resource-path=.','--no-highlight'],cwd=P,check=True)
doc=Document(P/'raw.docx')
doc.core_properties.title='Separator Anchors for Sheaf Based Latent Reasoning'
doc.core_properties.author='Debi Prasad Ghosh'
doc.core_properties.subject='Version 5 mathematical revision of the separator-anchor interface for Autoregressive Sheaf Evolution'
doc.core_properties.keywords='latent reasoning; cellular sheaf; noncommuting proximal reads; observability; robust memory; task identifiability'
inrefs=False
for p in doc.paragraphs:
    if p.style.name=='Title':p.text='Separator Anchors for\nSheaf Based Latent Reasoning'
    if p.text=='References':inrefs=True;p.paragraph_format.page_break_before=True
    if p.text.startswith('Appendix A'):inrefs=False
    elif inrefs and p.text.startswith('['):p.style=doc.styles['Bibliography']
    if p.text.startswith(('Theorem ','Proposition ','Corollary ','Lemma ','Definition ','Example ')):
        p.paragraph_format.keep_with_next=len(p.text)<650
    if p._p.xpath('.//w:drawing'):p.paragraph_format.keep_with_next=True
    if p.style.name in ['Caption','Image Caption'] or re.match(r'Figure \d+\.',p.text):
        p.paragraph_format.keep_together=True;p.paragraph_format.space_after=Pt(10)
    if p.style.name=='Table Caption' or re.match(r'Table \d+\.',p.text):
        p.paragraph_format.keep_with_next=True
    if p.text.startswith('Table 5.'):
        p.paragraph_format.page_break_before=True
    for run in p.runs:
        if run.font.color.type is not None:
            run.font.color.rgb=RGBColor(0,0,0)

widthsets=[[3.3,1.82,1.82],[1.55,2.5,2.89],[1.6,3.12,2.22],[2.5,2.99,1.45],[2.85,2.45,1.64],[2.02,2.55,2.37]]
for ti,table in enumerate(doc.tables):
    widths=widthsets[ti];table.autofit=False
    for col,w in zip(table.columns,widths):col.width=Inches(w)
    pr=table._tbl.tblPr
    for old in pr.findall(qn('w:tblBorders')):pr.remove(old)
    borders=OxmlElement('w:tblBorders')
    for side in ['top','left','bottom','right','insideH','insideV']:
        el=OxmlElement('w:'+side);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'4');el.set(qn('w:color'),'D9D9D9');borders.append(el)
    pr.append(borders)
    for ri,row in enumerate(table.rows):
        trpr=row._tr.get_or_add_trPr()
        for old in list(trpr):
            if old.tag in (qn('w:cantSplit'),qn('w:tblHeader')):trpr.remove(old)
        trpr.append(OxmlElement('w:cantSplit'))
        if ri==0:trpr.append(OxmlElement('w:tblHeader'))
        for cell,w in zip(row.cells,widths):
            cell.width=Inches(w);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcpr=cell._tc.get_or_add_tcPr()
            for old in tcpr.findall(qn('w:shd')):tcpr.remove(old)
            shade=OxmlElement('w:shd');shade.set(qn('w:val'),'clear');shade.set(qn('w:fill'),'E7EBEF' if ri==0 else ('F7F8F9' if ri%2==0 else 'FFFFFF'));tcpr.append(shade)
            mar=OxmlElement('w:tcMar')
            for side,value in [('top',85),('start',85),('bottom',85),('end',85)]:
                el=OxmlElement('w:'+side);el.set(qn('w:w'),str(value));el.set(qn('w:type'),'dxa');mar.append(el)
            tcpr.append(mar)
            for p in cell.paragraphs:
                p.paragraph_format.keep_with_next=(ti==4 and ri<len(table.rows)-1)
                p.paragraph_format.space_after=Pt(2);p.paragraph_format.space_before=Pt(1);p.paragraph_format.line_spacing=1.03
                for run in p.runs:run.font.size=Pt(9.8);run.bold=ri==0
    after=table._tbl.getnext()
    if after is not None and after.tag==qn('w:p'):Paragraph(after,doc._body).paragraph_format.space_before=Pt(6)
descriptions=[
    'Analytic sensitivity gains of the read.',
    'Wrong-anchor shift and repeated-read convergence.',
    'Proximal and Gaussian sensitivity and the residual floor of a grounded tree.',
    'Retained gain under three read schedules.',
    'Feedback thresholds and measured robust-corruption bound ratios.',
    'Exact spectral radius, two-step stability bound and loss Gramian under planar mixing.']
for shape,description in zip(doc.inline_shapes,descriptions):shape._inline.docPr.set('descr',description)
doc.save(P/'layout.docx')
out=P/'output/Separator_Anchors_for_Sheaf_Based_Latent_Reasoning_V5.docx'
subprocess.run([sys.executable,str(P/'postprocess.py'),str(P/'layout.docx'),str(out)],check=True)
print('Built',out)
