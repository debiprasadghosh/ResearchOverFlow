import json, re
R = json.load(open('results.json')); v = R['v2']; c = R['counts']
it = v['iterated']['distance_to_projection_after']
FRONT = r'''---
title: "Separator Anchors for Sheaf Based Latent Reasoning"
subtitle: An idea paper on implementing Sep-Latent within Autoregressive Sheaf Evolution. Version 2
author:
  - Debi Prasad Ghosh
date: 20 October 2026 · Version 2 · Research proposal
---

'''
ABS_ADD = (f"\n\n**What Version 2 adds.** Section 8.5 analyses three risks of running the read at every reasoning step. "
 "Repeated reads against the same bank are a proximal-point iteration: each observed direction contracts by "
 r"$(\mu/(\mu+\beta\sigma^2))^k$, the private component never moves, and the state converges to the nearest compatible point. "
 "Extra latent steps therefore silently turn a soft read into a hard projection, and no single choice of $\\beta$ reproduces "
 "several reads. A single wrong anchor shifts the quadratic read linearly without bound, whereas a Huber read keeps every displacement "
 r"below $\beta\delta/\mu$. Pooling two branch anchors lands near neither branch. "
 f"{c['total']} checks now pass: the {c['v1']} Version 1 checks rebuilt from the paper and {c['v2']} new ones.")
S85 = rf'''## 8.5 Repeated reads, wrong anchors and branches

The read (4) runs once per reasoning step. Three properties of that repetition matter before any training.

**Proposition 5 (repeated reads become a hard projection).** Fix a consistent bank, $C$ and $b$, and apply the read $k$ times, each time starting from the previous output. Let $p$ be the point of $\{{z:Cz=b\}}$ nearest to $u$. Then

$$z_k-p=\left(\mu(\mu I+\beta C^\top C)^{{-1}}\right)^k(u-p). \tag{{15}}$$

Along a right singular direction with singular value $\sigma$ the error contracts by $(\mu/(\mu+\beta\sigma^2))^k$. The component in $\ker C$ never moves. So $z_k\to p$, the hard projection.

**Proof.** Since $Cp=b$, the normal equations (5) for $p$ read $(\mu I+\beta C^\top C)p=\mu p+\beta C^\top b$. Subtracting them from those for $z_{{j+1}}$ gives $z_{{j+1}}-p=\mu(\mu I+\beta C^\top C)^{{-1}}(z_j-p)$. Then iterate, diagonalise, and use $u-p\perp\ker C$ for the nearest point. ∎

This is the proximal-point method for $\frac12\|Cz-b\|^2$. On a random consistent bank the distance to $p$ fell from {it[0]:.2f} to {it[2]:.3f} after five reads and {it[3]:.1e} after twenty, while the private component moved by at most {v['iterated']['private_drift']:.1e}. The gains differ by direction, so $k$ reads equal no single read. In the test, matching five reads would need $\beta\approx${v['iterated']['beta_needed'][0]:.0f}$ in one direction and {v['iterated']['beta_needed'][1]:.0f} in another. Extra latent steps are not neutral repetition. Unless anchors are appended or the gate decays, they convert the soft correction into a hard constraint, and the hard limit discards the uncertainty the finite $\beta$ was chosen to keep. Report the number of reads per anchor set, or re-read only when the bank changes.

**Proposition 6 (one wrong anchor).** If observation $i$ is corrupted by $\epsilon$, the quadratic read moves by $\beta(\mu I+\beta C^\top C)^{{-1}}c_i\epsilon$, which is linear and unbounded in $\epsilon$. Replace the observation term by a Huber loss with threshold $\delta$ applied to each scalar residual. Then every solution satisfies

$$\|z^*-u\|\le\frac{{\beta\delta}}{{\mu}}\sum_i\|c_i\|, \tag{{16}}$$

whatever the anchor values are.

**Proof.** The quadratic statement differentiates (5) in $b$. For Huber loss, stationarity gives $\mu(z^*-u)=-\beta\sum_ic_i\psi_\delta(c_i^\top z^*-b_i)$, where $|\psi_\delta|\le\delta$, and the triangle inequality completes it [9]. ∎

With $\mu=1$, $\beta=3$ and coordinate observations, the quadratic shift grew as $0.75\epsilon$ and reached {v['wrong_anchor']['rows'][-1]['quad_shift']:.0f} at $\epsilon=100$. The Huber read with $\delta=0.5$ never moved more than {max(r['huber_shift'] for r in v['wrong_anchor']['rows']):.2f}, below the per-coordinate cap $\beta\delta/\mu=1.5$ (Figure 2a). Robustness has a price: a correct but surprising anchor is also capped. This is why Section 7 asks for correctness supervision rather than a smaller residual.

**Proposition 7 (pooling branches).** Suppose two anchors observe the same scalar coordinate with values $b_1\neq b_2$ from different branches. The pooled read $z^*=(\mu u+\beta(b_1+b_2))/(\mu+2\beta)$ tends to the midpoint as $\beta/\mu$ grows. Its distance from the nearer branch then tends to $|b_1-b_2|/2$. A branch-separated read is within $\mu|u-b_j|/(\mu+\beta)$ of its own branch $j$.

With $b_1=2$, $b_2=6$, $u=4.5$ and $\beta/\mu=10$, the pooled read is {v['branch']['mixed']:.2f}, about two units from both branches. The separated reads are {v['branch']['separated'][0]:.2f} and {v['branch']['separated'][1]:.2f}. The branch identifier of Section 8.3 is therefore not bookkeeping: without it the read produces a value that neither hypothesis asserts.

![**Figure 2.** (a) Shift of the read caused by an error in one anchor: quadratic (unbounded) against Huber (capped below $\beta\delta/\mu$). (b) Distance to the nearest compatible point after repeated reads against one consistent bank (Proposition 5).](fig/v2_reads.png){{width=100%}}
'''
H6 = ("**H6 — repeated reads.** At matched backbone calls, a controller that re-reads only when new anchors arrive should match or exceed one that "
      "re-reads every step on held-out compositions, and should keep higher observed-direction uncertainty. Fails if per-step re-reading is "
      "better by at least 2 points.\n\n**H7 — robust reads.** With 10% of anchors corrupted by a synthetic error, the Huber read should keep verified "
      "accuracy within 3 points of clean, while the quadratic read falls by more. Fails if the gap does not appear or clean accuracy drops by more than 2 points.")
CHK = (f"\n\nVersion 2 rebuilds these twelve checks from the paper's statements, because the original script was not among the inputs, and adds "
       f"{c['v2']} checks of Propositions 5–7, {c['total']} in all, with the same seed. These cover the contraction identity (15) to $10^{{-8}}$, the "
       "kernel preservation, the impossibility of a single equivalent $\\beta$, the linear and capped wrong-anchor shifts, and the branch-mixing example.")
REF = r"\[9\] Huber, P. J. (1964). *Robust Estimation of a Location Parameter.* Annals of Mathematical Statistics 35(1), 73--101. https://doi.org/10.1214/aoms/1177703732"

s = open('v1_clean.md').read()
s = FRONT + s
i = s.index('**Central proposal.**'); s = s[:i] + s[i:].replace('\n', ABS_ADD + '\n', 1) if False else s
j = s.index('\n\n**Central proposal.**'); s = s[:j] + ABS_ADD + s[j:]
k = s.index('# 9. Experiments'); s = s[:k] + S85 + '\n' + s[k:]
k = s.index('H2 needs both evaluation-time'); s = s[:k] + H6 + '\n\n' + s[k:]
k = s.index('These are sanity checks of the specified'); k2 = s.rindex('\n\n', 0, k); s = s[:k2] + CHK + s[k2:]
s = s.rstrip('\n') + '\n\n' + REF + '\n'
s = s.replace('Twelve small numerical checks verify the algebraic examples', f"{c['total']} small numerical checks verify the algebraic examples and the new propositions")
s = re.sub(r'=\$(\{|)(\d)', r'=\2', s)
s = re.sub(r'\\tag\{e(\d+)\}', r'\\tag{\1}', s)
s = s.replace('^{*}', r'^{\text{*}}').replace('z^*', r'z^{\text{*}}').replace(r'\beta\approx$', r'\beta\approx ')
s = s.replace('_{+}', r'_{\text{+}}').replace('^{+}', r'^{\text{+}}')
(open('paper.md', 'w')).write(s)
print(len(s.split()))
