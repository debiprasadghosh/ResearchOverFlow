"""Figure 2 of Version 2 from results.json (Figure 1 is kept from Version 1)."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P = Path(__file__).resolve().parent
v = json.loads((P / 'results.json').read_text())['v2']
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
blue, orange, grey = '#28689b', '#c9692e', '#58636d'
fig, axs = plt.subplots(1, 2, figsize=(10, 3.6))
rows = v['wrong_anchor']['rows']; e = [r['error'] for r in rows]
axs[0].plot(e, [r['quad_shift'] for r in rows], 'o-', c=orange, lw=2, label='quadratic read (4)')
axs[0].plot(e, [r['huber_shift'] for r in rows], 's-', c=blue, lw=2, label='Huber read, δ = 0.5')
axs[0].axhline(v['wrong_anchor']['huber_cap'], c=grey, ls=':', lw=1.3)
axs[0].text(100, v['wrong_anchor']['huber_cap'] * 1.25, 'βδ/μ = 1.5', ha='right', fontsize=8.6, color=grey)
axs[0].set(xscale='symlog', yscale='symlog', xlim=(0, 130), ylim=(0, 120), xlabel='error in one anchor', ylabel='shift of the read')
axs[0].set_title('(a) one wrong anchor (Proposition 6)', fontsize=10)
axs[0].legend(frameon=False, fontsize=8.8, loc='upper left'); axs[0].grid(alpha=.15, which='both')
it = v['iterated']['distance_to_projection_after']; ks = [0, 1, 5, 20, 200]
axs[1].semilogy(ks[:4], it[:4], 'o-', c=blue, lw=2)
axs[1].set(xlabel='number of reads against the same bank', ylabel='distance to nearest compatible point')
axs[1].set_title('(b) repeated reads become a hard projection (Prop. 5)', fontsize=10)
axs[1].grid(alpha=.15, which='both')
fig.tight_layout(); fig.savefig(P / 'fig/v2_reads.png', dpi=220, facecolor='white')
print('ok')
