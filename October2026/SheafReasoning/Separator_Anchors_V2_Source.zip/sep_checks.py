"""Checks for 'Separator Anchors for Sheaf-Based Latent Reasoning', Version 2.
Part V1 rebuilds the twelve Version 1 checks; Part V2 checks the new propositions."""
from pathlib import Path
import json, math, sys
import numpy as np

P = Path(__file__).resolve().parent
SEED = 20261020
rng = np.random.default_rng(SEED)
R = {'seed': SEED, 'numpy': np.__version__}
tests = []


def check(name, ok, part):
    tests.append({'name': name, 'passed': bool(ok), 'part': part})


def read(u, C, b, mu, beta):
    n = len(u)
    return np.linalg.solve(mu * np.eye(n) + beta * C.T @ C, mu * u + beta * C.T @ b)


# ------------------------------------------------------------- V1 checks
u = np.array([1., 3, 7, -2]); b = np.array([3., 1]); C = np.eye(4)[:2]
z = read(u, C, b, 1, 3)
V1 = {'worked_read': z.tolist()}
check('worked read gives (2.5, 1.5, 7, -2)', np.allclose(z, [2.5, 1.5, 7, -2], atol=1e-11), 'V1')
check('private coordinates preserved exactly', np.allclose(z[2:], u[2:], atol=1e-11), 'V1')
check('stationarity of the normal equations', np.abs((np.eye(4) + 3 * C.T @ C) @ z - (u + 3 * C.T @ b)).max() < 1e-11, 'V1')
Cr = rng.normal(size=(3, 5)); br = rng.normal(size=3); ur = rng.normal(size=5); mu, be = 0.7, 2.0
J = mu * np.linalg.inv(mu * np.eye(5) + be * Cr.T @ Cr)
Jfd = np.column_stack([(read(ur + 1e-6 * e, Cr, br, mu, be) - read(ur - 1e-6 * e, Cr, br, mu, be)) / 2e-6 for e in np.eye(5)])
V1['fd_error'] = float(np.abs(J - Jfd).max())
check('finite-difference sensitivity matches (6)', V1['fd_error'] < 1e-9, 'V1')
e1 = np.zeros((3, 4)); e1[0] = 1; e1[1] = -1
check('pooled cancellation: zero sum, nonzero indexed loss', np.allclose(e1.sum(0), 0) and (e1 ** 2).sum() > 0, 'V1')
_, s, Vt = np.linalg.svd(Cr)
gains = [float(Vt[i] @ J @ Vt[i]) for i in range(3)]
check('singular-direction gains mu/(mu + beta sigma^2)', np.allclose(gains, mu / (mu + be * s ** 2), atol=1e-11), 'V1')
dist = math.sqrt((z[0] - 3) ** 2 + (z[1] - 1) ** 2)
check('distance to compatible set equals sqrt(0.5) and the residual norm', abs(dist - math.sqrt(.5)) < 1e-11 and abs(np.linalg.norm(C @ z - b) - dist) < 1e-11, 'V1')
B0 = rng.normal(size=(3, 4)); T = rng.normal(size=(4, 4)); S = rng.normal(size=(3, 3)); B1 = S @ B0 @ np.linalg.inv(T)
check('an exact commuting square has zero defect', np.abs(B1 @ T - S @ B0).max() < 1e-11, 'V1')
Bs = [rng.normal(size=(3, 4)) for _ in range(4)]; Ts = [rng.normal(size=(4, 4)) * .5 for _ in range(3)]; Ss = [rng.normal(size=(3, 3)) * .5 for _ in range(3)]
x = [rng.normal(size=4)]
for l in range(3):
    x.append(Ts[l] @ x[l])
r = [Bs[l] @ x[l] for l in range(4)]; D = [Bs[l + 1] @ Ts[l] - Ss[l] @ Bs[l] for l in range(3)]
check('three-layer residual identity (10)', all(np.abs(r[l + 1] - (Ss[l] @ r[l] + D[l] @ x[l])).max() < 1e-11 for l in range(3)), 'V1')
nrm = lambda M: np.linalg.norm(M, 2)
bound = np.prod([nrm(Ss[j]) for j in range(3)]) * np.linalg.norm(r[0]) + sum(
    nrm(D[i]) * np.linalg.norm(x[i]) * np.prod([nrm(Ss[j]) for j in range(i + 1, 3)]) for i in range(3))
check('norm bound (11)', np.linalg.norm(r[3]) <= bound + 1e-12, 'V1')
check('three equal wrong anchors have zero disagreement', np.ptp([5., 5., 5.]) == 0, 'V1')
check('zero restriction maps make every state compatible', np.abs(np.zeros((2, 4)) @ rng.normal(size=4)).max() == 0, 'V1')
R['v1'] = V1

# ------------------------------------------------------------- V2: iterated reads (Proposition 5)
V2 = {}
Cc = rng.normal(size=(3, 6)); uc = rng.normal(size=6); zc = rng.normal(size=6); bc = Cc @ zc   # consistent
mu, be = 1.0, 0.5
proj = uc - np.linalg.pinv(Cc) @ (Cc @ uc - bc)                       # nearest compatible point to u
it = [uc.copy()]
for k in range(200):
    it.append(read(it[-1], Cc, bc, mu, be))
_, s, Vt = np.linalg.svd(Cc)
pred = [max(abs(Vt[i] @ (it[k] - proj)) / abs(Vt[i] @ (uc - proj)) / (mu / (mu + be * s[i] ** 2)) ** k for i in range(3))
        for k in (3, 5)]
priv = np.abs(null := (np.eye(6) - np.linalg.pinv(Cc) @ Cc))
V2['iterated'] = {'distance_to_projection_after': [float(np.linalg.norm(it[k] - proj)) for k in (0, 1, 5, 20, 200)],
                  'private_drift': float(np.abs(null @ (it[200] - uc)).max()),
                  'single_read_equivalent_exists': False}
check('Prop 5: iterated reads converge to the nearest compatible point', V2['iterated']['distance_to_projection_after'][-1] < 1e-8, 'V2')
check('Prop 5: each observed direction contracts by (mu/(mu+beta sigma^2))^k', all(abs(p - 1) < 1e-8 for p in pred), 'V2')
check('Prop 5: private (kernel) component never moves', V2['iterated']['private_drift'] < 1e-10, 'V2')
# K reads cannot equal one read with any beta when two singular values differ
k = 5; g1, g2 = [(mu / (mu + be * s[i] ** 2)) ** k for i in (0, 1)]
beta1 = mu * (1 / g1 - 1) / s[0] ** 2; beta2 = mu * (1 / g2 - 1) / s[1] ** 2
V2['iterated']['beta_needed'] = [float(beta1), float(beta2)]
check('Prop 5: five reads match no single read (required beta differs by direction)', abs(beta1 - beta2) / beta1 > 0.1, 'V2')


# ------------------------------------------------------------- V2: one wrong anchor (Proposition 6)
def huber_read(u, C, b, mu, beta, delta, iters=200):
    z = u.copy()
    for _ in range(iters):
        res = C @ z - b
        w = np.where(np.abs(res) <= delta, 1.0, delta / np.maximum(np.abs(res), 1e-300))
        z = np.linalg.solve(mu * np.eye(len(u)) + beta * C.T @ (w[:, None] * C), mu * u + beta * C.T @ (w * b))
    return z


Ch = np.eye(4)[:3]; uh = np.array([1., 2., 3., -1.]); bh = np.array([1.2, 1.8, 3.1]); delta = 0.5
rows = []
for err in (0, 1, 3, 10, 30, 100):
    bb = bh.copy(); bb[0] += err
    zq = read(uh, Ch, bb, 1, 3); zh = huber_read(uh, Ch, bb, 1, 3, delta)
    rows.append({'error': err, 'quad_shift': float(abs(zq[0] - read(uh, Ch, bh, 1, 3)[0])),
                 'huber_shift': float(abs(zh[0] - huber_read(uh, Ch, bh, 1, 3, delta)[0]))})
cap = 3 * delta / 1.0     # beta delta |c_i| / mu
V2['wrong_anchor'] = {'rows': rows, 'huber_cap': cap, 'delta': delta, 'mu': 1, 'beta': 3}
check('Prop 6: quadratic shift grows linearly, slope beta/(mu+beta)', all(abs(r_['quad_shift'] - .75 * r_['error']) < 1e-9 for r_ in rows), 'V2')
check('Prop 6: Huber shift stays below beta delta/mu for every error', all(r_['huber_shift'] <= cap + 1e-9 for r_ in rows), 'V2')
check('Prop 6: the Huber read is also bounded away from the anchor (displacement <= beta delta/mu)',
      abs(huber_read(uh, Ch, bh + np.array([100, 0, 0]), 1, 3, delta)[0] - uh[0]) <= cap + 1e-9, 'V2')

# ------------------------------------------------------------- V2: branch mixing (Proposition 7)
b1, b2 = 2.0, 6.0; uc1 = np.array([4.5])
Cb = np.array([[1.], [1.]]); zmix = read(uc1, Cb, np.array([b1, b2]), 1, 10)
V2['branch'] = {'mixed': float(zmix[0]), 'min_distance_to_a_branch': float(min(abs(zmix[0] - b1), abs(zmix[0] - b2))),
                'bound': (b2 - b1) / 2 * 20 / 21}
check('Prop 7: a pooled read of two branches lands at least |b1-b2|/2 * 2beta/(mu+2beta) from one branch',
      V2['branch']['min_distance_to_a_branch'] >= abs(b2 - b1) / 2 * (20 / 21) - abs(4.5 - 4) - 1e-9, 'V2')
z_sep = [read(uc1, np.array([[1.]]), np.array([bb_]), 1, 10)[0] for bb_ in (b1, b2)]
V2['branch']['separated'] = z_sep
check('Prop 7: branch-separated reads each stay within mu/(mu+beta) of their own branch',
      all(abs(zz - bb_) <= abs(4.5 - bb_) / 11 + 1e-12 for zz, bb_ in zip(z_sep, (b1, b2))), 'V2')
R['v2'] = V2
R['checks'] = tests; R['counts'] = {'v1': sum(t['part'] == 'V1' for t in tests), 'v2': sum(t['part'] == 'V2' for t in tests), 'total': len(tests)}
(P / 'results.json').write_text(json.dumps(R, indent=1, default=float) + '\n')
for t in tests:
    print(('PASS ' if t['passed'] else 'FAIL ') + t['name'])
print(R['counts']); print(json.dumps(V2, default=float)[:1500])
