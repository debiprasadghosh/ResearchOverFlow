# Abstract

Continuous latent reasoning offers a useful implementation substrate for Autoregressive Sheaf Evolution (ASE), but continuity alone does not supply a sheaf. Sep-Latent compresses explicit reasoning into separator hidden states and trains an implicit path to continue through continuous inputs. We propose to treat these separator states as observations of local reasoning contexts, rather than as globally interchangeable embeddings. A horizontal sheaf specifies which parts of neighbouring contexts refer to the same quantities and how those quantities are compared. A token still carries a vertical fibre diagram across layers; reasoning time remains a separate index. The minimal implementation adds a causal bank of immutable anchors and a typed observation-star read to Sep-Latent. For fixed linear maps, the read is a strictly convex quadratic problem with a unique solution. It damps sensitivity in observed directions while preserving every unobserved direction exactly. We prove this statement, a bound for propagation of vertical square defects, and a conditional distance certificate. We also show why pooled alignment, vanishing compatibility residuals and extra latent steps cannot establish faithful reasoning. Twelve small numerical checks verify the algebraic examples; no model training or benchmark improvement is claimed. A staged implementation and proposed preregistration criteria distinguish benefits of contextual gluing from benefits of additional parameters, computation or generic smoothing.

**Central proposal.** Use separator anchors to compress local reasoning; use sheaf restrictions to control which compressed information may be combined; use vertical diagrams to track how that information changes with depth.

**Status of claims.** Published benchmark numbers below belong to Sep-Latent. Propositions concern the explicitly defined linear sidecar. Performance improvements for the proposed system remain hypotheses.

# 1. Why Sep-Latent belongs in the ASE programme

The ASE programme began by reinterpreting denoising evolution as a layered process with horizontal local structure and vertical algebra. In that setting, a global vector is often too strong a representation: different examples expose different coordinates, different charts describe the same object, and different hypotheses may belong to separate branches. The present question is whether an implicit reasoning model can use the same discipline. Instead of forcing every intermediate thought into vocabulary tokens, it would maintain continuous local states and combine only the information their contexts allow them to share.

Sep-Latent \[1\] supplies a practical starting point. Its separators are trained as compression anchors for intermediate reasoning. Its implicit path feeds a projection of a hidden state back into the embedding stream. This creates an interface where a horizontal read could operate before the next continuous input is formed. It does not already identify local semantic charts or restrictions between them. Those are the new modelling commitments proposed here.

The phrase "horizontally topological" should therefore be made operational. Continuous latent vectors live in a topological space, but so do ordinary embeddings. Nontrivial topology does not follow from bypassing a vocabulary. Conversely, a cellular sheaf can be implemented on a finite incidence structure, so continuous latent reasoning is not mathematically necessary for sheaf based AI. Its attraction is engineering: continuous states admit calibrated linear observations, differentiable compatibility penalties and local correction without repeated textual serialization.

Our proposed requirement is more specific: a horizontal model must declare a base of contexts, data spaces on that base, and maps that identify comparable information on overlaps. It must preserve the distinction between agreement, uncertainty, competing hypotheses and truth. A useful implementation can begin with fixed, known projection maps on synthetic tasks. It need not begin by learning an arbitrary topology from hidden-state proximity.

This paper calls the proposed extension **Sep-Sheaf** for convenience. The name denotes a design to be tested, not an existing trained model or a claim that ordinary latent reasoning is secretly a sheaf algorithm. The initial goal is modest and measurable: determine whether typed partial agreement improves compositional reasoning at a controlled computational budget.

# 2. What Sep-Latent actually provides

## 2.1 Explicit and implicit paths

Sep-Latent uses one shared language model in two training paths \[1, Figure 2\]. The explicit path contains a query, textual reasoning steps, separators and an answer. During training, attention to reasoning-step positions is progressively reduced to encourage separator states to retain useful information. The implicit path replaces textual intermediate steps with continuous latent inputs. Writing reasoning position as $k$ and Transformer depth as $\ell\text{,}$ its feedback interface is

$$u_{k + 1} = f_{\theta}\left( h_{k,L} \right),\quad\quad u_{k + 1} \in ℝ^{d}. \tag{e1}$$

Here $f_{\theta}$ is an MLP and $L$ is the final Transformer layer. Vocabulary decoding resumes for the answer. The explicit path is supervised on its textual sequence; the implicit path is supervised on the final answer. Hidden states at separator and answer positions provide additional distillation targets. The explicit path and attention decay are disabled at inference. Appendix A describes termination through the language-model head predicting an end marker.

This interface follows the broader continuous-reasoning direction exemplified by Coconut \[2\]; CODI \[3\] provides a related self-distillation approach. The distinction relevant to our proposal is that Sep-Latent makes separator positions an explicit compression target. Such targets are convenient observations for a horizontal sidecar. They do not guarantee that each anchor is sufficient, correct, causal or interpretable.

## 2.2 Two replication details that matter

First, Sep-Latent's displayed attention-decay equation multiplies the attention quantity at reasoning-step keys by a factor $\gamma\text{.}$ It does not specify a subsequent renormalization in that equation. A normalized implementation instead uses probabilities proportional to $p_{j}\gamma^{\mathbf{1}_{j \in I_{steps}}}\text{,}$ equivalently a logit bias when $\gamma > 0\text{.}$ These are distinct choices. A replication must record the location of the modification in the attention pipeline, behaviour at zero, and whether probabilities are renormalized. The sheaf experiment must not silently change this baseline detail.

Second, the displayed separator and answer aggregates in equations (2) and (4) sum across both positions and layers. The accompanying prose discusses alignment across layers. Without a verified implementation, one should not replace that displayed sum by an indexed tensor and call the result an exact replication. For Sep-Sheaf we deliberately retain position and layer indices. This is a proposed change, motivated by Proposition 1 below. We will compare pooled and indexed alignment rather than assume they are equivalent.

## 2.3 Evidence and limits of the published results

Table 1 records a small, directly relevant subset of the attached preprint. Accuracy is a percentage. "Tokens" retains the paper's reported measure; it is not converted into measured latency or a count of independent reasoning operations.

Table: **Table 1.** Published Sep-Latent results, not results of Sep-Sheaf. Source: \[1\], Table 1.

  -------------------------------------------------------------------------------
  **Backbone and metric**                **Explicit SFT-CoT**   **Sep-Latent**
  -------------------------------------- ---------------------- -----------------
  Llama3.2-1B, GSM8k-Aug accuracy        56.2                   56.8

  Llama3.2-1B, GSM8k-Aug tokens          25.3                   5.4

  Llama3.2-1B, four-task mean accuracy   58.1                   57.9

  Llama3.2-1B, four-task mean tokens     17.9                   5.9

  Qwen3-0.6B, four-task mean accuracy    53.5                   53.6
  -------------------------------------------------------------------------------

These results support investigating compact latent inference, not assuming a universal accuracy gain. The larger-model comparison in \[1, Table 2\] still favours explicit CoT in accuracy. Training budgets also differ among reported baselines. Table 1 and the discussion of two out-of-domain scores contain reporting discrepancies; the values above follow Table 1. Its GSM8k-Aug column label is retained rather than resolving the preprint's differing descriptions of the evaluation split. The replication must identify actual dataset files and group related augmented questions before splitting.

The paper's latent visualizations are suggestive, but a low-dimensional projection cannot demonstrate preserved reasoning content or a meaningful sheaf topology. The causal analysis of Coconut in \[4\] gives a further reason to test interventions. Its findings concern its evaluated models and tasks; they are not a direct test of Sep-Latent. For our extension, a useful latent state must change downstream predictions in task-relevant ways when intervened on, not merely be decodable by a probe.

# 3. Four bases, two indices and one semantic contract

## 3.1 Keep the bases separate

An implementation becomes ambiguous if "layer," "example," "separator" and "region" are treated as interchangeable nodes. Table 2 states four bases used in this proposal. Their relationships must be explicit even when one data structure indexes several of them.

Table: **Table 2.** Distinct bases and their roles.

  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Base**                             **Objects and maps**                                          **Role in this paper**
  ------------------------------------ ------------------------------------------------------------- --------------------------------------------------------------------------------------
  Latent context space and its cover   Regions $U_{v}\text{,}$ intersections and a cover nerve       Declares the horizontal topology; proximity alone does not define a semantic overlap

  Context incidence structure          Vertices, edges and optional higher cells                     Finite cellular representation carrying data spaces and restrictions

  Layer order                          Depth indices $\ell$ and declared transition arrows           Vertical fibre diagrams; linear models, or explicitly local tangent models

  Observation star                     A current candidate joined to selected, pinned observations   Computational base of one causal horizontal read
  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

A nerve records nonempty intersections of a cover. A cellular context graph can also be declared directly, without a claim that it is a good-cover nerve. The latter is the safer minimal prototype. If an actual topological cover is later introduced, its intersections, transition maps and relationship to the context graph must be checked. A graph manufactured from nearest-neighbour embeddings is a graph, not yet a validated semantic atlas.

Reasoning position $k$ is an additional time index, not a fifth name for Transformer depth. The pair $(k,\ell)$ locates a continuous reasoning state. ASE denoising depth, Transformer depth and latent rollout length are three potentially different axes. A model may relate them, but must state that relation rather than infer it from the word "layer."

## 3.2 Stalks are data spaces; anchors are observations

At a context vertex $v$ and depth $\ell\text{,}$ assign a finite-dimensional space $F_{\ell}(v)\text{.}$ At an overlap edge $e = (v,w)\text{,}$ assign $F_{\ell}(e)$ and restrictions

$$R_{ve,\ell}:F_{\ell}(v) \rightarrow F_{\ell}(e),\quad\quad R_{we,\ell}:F_{\ell}(w) \rightarrow F_{\ell}(e). \tag{e2}$$

These are data spaces and maps, not individual tokens. An anchor $a_{v,k,\ell}$ is a particular observation in a space. A separator hidden state can supply it through an adapter. A token moving through layers carries a **vertical fibre diagram**; calling the token's trajectory a stalk would conflate a data space with its evolving contents.

For the first implementation, each context exposes a known subset of typed variables. An overlap contains only shared variables with matching units, entity identifiers, time and hypothesis scope. Restrictions are coordinate projections after calibration. A separator ending a sentence about force is not automatically compatible with one about cost, even if their embeddings are close. Two alternative worlds that assign different forces are separate branches unless an explicit comparison construction is declared.

The semantic contract attached to an anchor contains context identifiers, variable types, unit transformations, branch and time tags, provenance, layer, confidence and an adapter version. The contract may initially be supplied by a synthetic-task generator or a verified parser. Learning it is a separate experiment, because a sheaf with incorrectly assigned overlaps can enforce a coherent but wrong computation.

## 3.3 Units come before residuals

Before measuring disagreement, convert overlapping quantities into a common representation and metric. A dimensional force and a dimensionless normalized feature cannot be subtracted merely because they occupy vectors of the same length. Let $W_{e}$ be a declared positive-definite metric on the overlap space. The whitened disagreement is

$$\left( B_{\ell}x \right)_{e} = W_{e}^{1/2}\left( R_{we,\ell}x_{w} - R_{ve,\ell}x_{v} \right). \tag{e3}$$

The horizontal energy is $\parallel B_{\ell}x \parallel^{2}/2\text{.}$ Kernel membership means agreement under these maps, not truth. On a graph this is a cellular sheaf coboundary \[5\]. With higher-dimensional cells, restriction diamonds must commute so that consecutive coboundaries compose to zero. A pairwise graph alone does not establish the triangle identities needed by a higher-dimensional complex.

An exact change of local coordinates must transform the restrictions and metrics consistently. Arbitrary Euclidean penalties are not invariant under an arbitrary change of gauge. This is why the first prototype uses calibrated projections rather than unconstrained learned matrices.

# 4. From separator compression to a causal sheaf read

## 4.1 Retain indexed information

Let $a_{j,\ell}$ be a detached explicit-path separator target, and let $z_{k,\ell}$ be the corresponding implicit-path feature. Store their indices. During training a monotone alignment $j = \tau(k)$ can be supplied from the explicit trace. At inference, step counts may differ. The controller must use masks, a declared alignment procedure or context matching; training-time position matching is not a proof that inference anchors denote the same local facts.

**Proposition 1 (pooled cancellation).** For $L \geq 2\text{,}$ the sum map from $L$ copies of $ℝ^{r}$ to $ℝ^{r}$ has kernel dimension $(L - 1)r\text{.}$ Therefore a zero loss on the sum does not imply agreement at each layer.

**Proof.** The sum map is surjective and has rank $r\text{,}$ so rank-nullity gives the dimension. A nonzero error $v$ at one layer and $- v$ at another has zero sum. An indexed squared loss detects both. The same issue applies to summing over separator positions. This proves a limitation of the displayed aggregation, not a claim about uninspected Sep-Latent code. ∎

We therefore propose per-position, per-layer alignment, with loss normalization over active coordinates. The target is not that every layer encode the same thing. Each layer has its own calibrated adapter and its own target. Comparing raw hidden states across unrelated layers would reintroduce the coordinate problem.

## 4.2 Immutable bank and current observation star

At reasoning step $k\text{,}$ read a bounded set of prior anchors from the same admissible branch. The bank can initially contain earlier reasoning contexts in the same query. A later version can also retrieve verified records from other examples, provided their types, gauges and branch scopes match; cross-example similarity alone is insufficient. The bank is immutable during the step. Only the current candidate is optimized. This gives a causal observation star: old anchors are observations, not unknowns to be moved until they agree with the current guess. Select anchors using context eligibility first and geometric similarity second.

Let $u \in ℝ^{r}$ be the current adapter proposal. Stack its whitened restrictions into $C$ and the corresponding prior-anchor observations into $b\text{.}$ For fixed maps and weights, define

$$z^{*} = \underset{z \in ℝ^{r}}{argmin}\left\{ \frac{\mu}{2} \parallel z - u \parallel^{2} + \frac{\beta}{2} \parallel Cz - b \parallel^{2} \right\},\quad\mu > 0,\ \beta \geq 0. \tag{e4}$$

The first term preserves the current proposal; the second asks only for declared shared information. Cholesky factorization gives the small dense solve

$$\left( \mu I + \beta C^{\top}C \right)z^{*} = \mu u + \beta C^{\top}b. \tag{e5}$$

Use a linear solve, not an explicit matrix inverse. For larger sparse spaces, conjugate gradients with a recorded tolerance is appropriate. Inconsistent observations do not invalidate the soft solve; they leave an irreducible disagreement which must be reported. A robust convex edge loss is a later alternative for fixed maps, with a numerical solver and a separate convergence budget.

The result is fed through an output adapter as a gated correction to the next continuous input. Past backbone keys and values are not rewritten. The immutable sidecar and the transformer's causal KV cache are different stores. Recomputing a past prefix after changing anchors would be a different, more expensive algorithm and must not be presented as the same cached inference.

## 4.3 What this read guarantees

**Proposition 2 (unique read and directional preservation).** The problem in (4) has a unique solution. With $C$ and $b$ fixed, its derivative with respect to $u$ is

$$J_{u} = \mu\left( \mu I + \beta C^{\top}C \right)^{- 1}. \tag{e6}$$

For a right singular direction of $C$ with singular value $\sigma\text{,}$ the gain is $\mu/\left( \mu + \beta\sigma^{2} \right)\text{.}$ On $\ker C\text{,}$ the gain is exactly one and the solution retains the projection of $u$ exactly.

**Proof.** The Hessian is positive definite because $\mu > 0\text{.}$ Differentiating its normal equations proves (6). Diagonalizing $C^{\top}C$ proves the gains. For $q \in \ker C\text{,}$ multiply (5) by $q^{\top}\text{:}$ the observation term vanishes and $q^{\top}z^{*} = q^{\top}u\text{.}$ ∎

This is the central useful guarantee. Shared coordinates can be corrected while private coordinates survive. Full-vector consensus generally lacks that property. It is also a limited guarantee: if the anchor observations are functions of $u\text{,}$ or retrieval changes discontinuously with $u\text{,}$ (6) is only the conditional derivative with the selected bank held fixed. End-to-end sensitivity includes those additional paths.

The displacement has the useful conservative bound

$$\parallel z^{*} - u \parallel \leq \frac{\beta}{\mu} \parallel C^{\top}(Cu - b) \parallel . \tag{e7}$$

It follows by subtracting the normal equations for $u$ and bounding the inverse Hessian norm by $1/\mu\text{.}$ The ratio $\beta/\mu$ controls intervention strength, not evidence quality. Increasing it cannot make a wrong anchor reliable.

![**Figure 1.** Exact gains from Proposition 2, with $\mu = 1\text{.}$ Agreement suppresses sensitivity along an observed coordinate. A private coordinate remains unchanged. This is an analytic plot of the proposed linear read, not a trained-model measurement.](fig/v1_gains.png){width=100%}

# 5. A worked partial-information example

Consider a normalized engineering feature vector whose first two coordinates denote length and load, while the last two are private design features. Units have already been converted and standardized. One verified anchor supplies length 3; a different anchor supplies load 1. Neither asserts anything about the two private features. At the current step, use

$$u = (1,3,7, - 2)^{\top},\quad b = (3,1)^{\top},\quad C = \begin{pmatrix}
1 & 0 & 0 & 0 \\
0 & 1 & 0 & 0
\end{pmatrix}. \tag{e8}$$

With $\mu = 1$ and $\beta = 3\text{,}$ equation (5) gives $z^{*} = (2.5,1.5,7, - 2)^{\top}\text{.}$ The observed-coordinate gains are $0.25\text{,}$ and both private-coordinate gains are $1\text{.}$ The read recombines partial observations without inventing agreement on unseen coordinates. This is an information-recombination mechanism; whether a subsequent decoder can use it for a valid solution remains an empirical question.

The compatible affine set is $\{ z:z_{1} = 3,z_{2} = 1\}\text{.}$ The current solution is at distance $\sqrt{0.5}$ from it, and its observation residual has the same norm. Those numbers follow directly from the specified inputs; they are not benchmark statistics. Equation (4) is a soft penalty, so a nonzero residual at finite $\beta$ is expected.

If the anchors instead describe different hypothetical designs, forcing length from one and load from another might produce an invalid combination. The typed contract must state that these coordinates may coexist. This requirement is especially important in multimodal reasoning: shared variable names do not imply shared possible worlds. Branch-separated retrieval is preferable to averaging incompatible hypotheses.

An overlap graph also need not have the cohomology of its bare underlying graph. For example, contexts containing $(a,b)\text{,}$ $(b,c)$ and $(c,a)$ with overlap projections onto $b\text{,}$ $c$ and $a$ yield a surjective degree-zero coboundary to the three scalar edge spaces. Its first sheaf cohomology is zero, despite the cycle in the graph. Thus counting loops does not count reasoning contradictions. The coefficient spaces and restriction maps determine what an obstruction means.

# 6. Vertically algebraic: squares, tangents and their limits

## 6.1 A vertical fibre diagram is an additional model

The sidecar can be attached at the last layer alone. That is the minimal system. A multilayer extension assigns spaces and restrictions at selected depths, together with declared vertical maps. For fixed incidence and linear maps, let $T_{\ell}$ act on vertex data and $S_{\ell}$ on edge data. The compatibility square is

$$B_{\ell + 1}T_{\ell} = S_{\ell}B_{\ell}. \tag{e9}$$

When the horizontal base changes, first transport the next layer's sheaf using the declared base map $\Phi_{\ell}$ and its inverse image $\Phi_{\ell}^{- 1}\text{.}$ A map between arrays with different indexing is not a natural transformation merely because their shapes can be padded. Learned covers may give a zigzag rather than a chain; the direction of every base and coefficient map then matters.

Transformer blocks are nonlinear. Their actual hidden-state evolution is not a global representation by fixed linear maps. There are three honest options: use explicitly linear sidecar maps; use affine maps with declared homogeneous coordinates; or study local Jacobians along a particular trajectory. The last gives local tangent information and first-order approximations, not an exact global barcode of the transformer. Reasoning-time recurrence is likewise a distinct nonlinear dynamical process.

## 6.2 A bound when squares only approximately commute

Define the square defect $D_{\ell} = B_{\ell + 1}T_{\ell} - S_{\ell}B_{\ell}\text{.}$ Suppose a fixed linear sidecar evolves by $x_{\ell + 1} = T_{\ell}x_{\ell}\text{,}$ and put $r_{\ell} = B_{\ell}x_{\ell}\text{.}$ Then

$$r_{\ell + 1} = S_{\ell}r_{\ell} + D_{\ell}x_{\ell}. \tag{e10}$$

**Proposition 3 (defect propagation).** Writing $s_{\ell} = \parallel S_{\ell} \parallel$ and $d_{\ell} = \parallel D_{\ell} \parallel \text{,}$ the final residual obeys

$$\parallel r_{L} \parallel \leq \left( \prod_{j = 0}^{L - 1}s_{j} \right) \parallel r_{0} \parallel + \sum_{i = 0}^{L - 1}d_{i} \parallel x_{i} \parallel \prod_{j = i + 1}^{L - 1}s_{j}. \tag{e11}$$

An empty product equals one. **Proof.** Substitute (10) recursively and apply the triangle inequality and submultiplicativity of operator norms. ∎

Commuting squares preserve compatibility, but even small defects can accumulate when vertical edge maps amplify. A squared-defect training loss is therefore not by itself a final-residual certificate. For nonlinear backbone maps, the analogous first-order expression includes Taylor remainders and depends on the chosen trajectory. Report those approximations explicitly.

## 6.3 What barcodes would and would not mean here

An exact finite-dimensional representation of a finite linearly oriented layer order has an interval decomposition \[6, 7\]. Such a barcode can summarize the declared linear sidecar or an explicitly specified sequence of tangent maps. It cannot by itself certify that an interval represents a mathematical fact, a memory or a reasoning step. Semantic meaning needs labelled interventions or other independent validation.

Exact ranks and effective ranks must both be reported. Products of theoretically full-rank maps may become numerically singular. A numerical barcode therefore needs a stated threshold, precision and conditioning diagnostic. Evidence from a tangent diagram is about local sensitivity; it is not evidence that hidden states follow a globally linear law.

The product-stack viewpoint from Part I also needs its hypotheses. Under its stated fixed-base, bottom-initial layer setting, cohomology can collapse to the bottom layer and miss vertical events. This does not justify collapsing Sep-Latent's depth index during training. Changing bases or replacing the layer order by a zigzag requires a new analysis; the product-stack theorem does not transfer automatically. The indexed vertical diagram remains the object to inspect.

# 7. Compatibility certificates are not reasoning certificates

**Proposition 4 (conditional distance certificate).** Let $Az = b$ be a consistent affine compatibility system in calibrated coordinates. If $A$ has at least one positive singular value, then

$$dist\left( z,\{ w:Aw = b\} \right) \leq \frac{\parallel Az - b \parallel}{\sigma_{\min}^{+}(A)}. \tag{e12}$$

**Proof.** Let $p$ be the Euclidean projection onto the solution set. The vector $z - p$ is orthogonal to $\ker A\text{,}$ and $Az - b = A(z - p)\text{.}$ The smallest positive singular value bounds this norm below. ∎

If each decoder logit is $K$-Lipschitz on the segment from $z$ to $p\text{,}$ a margin greater than twice $K$ times the right-hand side of (12) ensures that this projection does not change the selected class. This is a conditional stability statement. It neither validates the constraints nor proves the selected answer correct. If there are no observed directions, the bound is inapplicable as written; if the constraints are inconsistent, first account for the least-squares residual floor. A tiny positive singular value makes the bound weak.

Two counterexamples should accompany every experimental report. First, a homogeneous sheaf loss accepts the zero section; learning every restriction to zero makes every state compatible. Second, three anchors all asserting the same wrong number have zero pairwise disagreement. Neither case is repaired by a smaller residual threshold. Training needs nondegeneracy controls and external correctness supervision; evaluation needs interventions and verified task constraints.

Coverage is separate from agreement. An empty or narrowly supported observation star may have negligible residual because almost nothing was compared. Report the observed subspace, its effective rank and task-required coordinates. A model should not stop merely because a graph is connected, because its residual is small, or because a latent decoder predicts an end marker.

The causal question is sharper: if a trusted anchor's shared quantity is changed while unrelated variables are fixed, does the answer change as the task requires? Conversely, if a private coordinate or punctuation placement changes, does the answer remain stable when the task says it should? Probes can help locate information, but these interventions test whether the information is used.

# 8. Training and inference specification

## 8.1 A staged objective

The first experiment freezes the baseline backbone and uses fixed context maps. Train small input and output adapters using answer supervision and indexed detached teacher targets. Only then test joint optimization. A representative later objective is

$$ℒ = ℒ_{CE,explicit} + ℒ_{CE,answer} + \lambda_{a}ℒ_{indexed} + \lambda_{h}ℒ_{overlap} + \lambda_{v}ℒ_{square}. \tag{e13}$$

The indexed term averages squared, calibrated distances over matched positions, selected layers and active dimensions. The overlap term measures only declared comparable quantities. The square term applies only to the explicit linear sidecar or a clearly labelled local surrogate. It does not impose exact linearity on the transformer. Auxiliary noncollapse and map-normalization terms are necessary if restrictions or adapters are freely learned, but their form must be reported and ablated rather than hidden in a generic regularizer.

Start with nonzero supervised features and fixed projection restrictions. Otherwise the system can reduce the overlap loss by destroying information. When dimensions or anchor counts vary, normalize losses so a longer chain does not receive a larger penalty merely because more coordinates were exposed. Keep explicit answer distillation separate from separator alignment; an improved answer-state match does not establish that the intermediate anchors became more useful.

## 8.2 Causal inference algorithm

To specify the interface completely, let $q_{k + 1} = f_{\theta}\left( h_{k,L} \right)$ be the uncorrected next embedding, let $E$ map it to the calibrated sidecar, and let $D$ lift a sidecar correction back to embedding space. The read uses $u = Eq_{k + 1}$ and outputs

$${\widetilde{q}}_{k + 1} = q_{k + 1} + gD\left( z^{*} - u \right),\quad\quad 0 \leq g \leq 1. \tag{e14}$$

A fixed right inverse satisfying $ED = I$ makes the sidecar of this embedding exactly $(1 - g)u + gz^{*}\text{.}$ If $E$ is not surjective or $D$ is learned without that constraint, report the reconstruction defect instead. Proposition 2 guarantees preservation in the declared sidecar coordinates; it does not guarantee unchanged hidden features after the next nonlinear backbone call. A calibrated linear projection and its fixed right inverse are the clean initial choice.

The minimal prototype reads only the final-layer sidecar. Selected-layer hooks are a later extension, tested against the same computation budget. This avoids requiring every transformer layer to participate before the basic hypothesis is established.

1.  Run the current causal backbone step and form the ordinary continuous-feedback proposal.
2.  Produce calibrated sidecar features and context metadata from the current prefix only. No teacher trace, future answer or future separator is available.
3.  Retrieve a capped set of eligible prior anchors from the same branch; construct $C$ and $b$ from fixed maps and pinned observations.
4.  Solve (5), record residual, coverage and conditioning, and form a gated correction through the output adapter.
5.  Append a new immutable anchor with provenance. Feed the corrected continuous input to the next backbone step; retain the normal KV cache unchanged.
6.  At the end-marker proposal, check the step cap and any task-specific verifier. Optional coverage and stability gates are structural diagnostics. If they fail, continue within budget or use an explicit/tool-assisted fallback with its cost recorded.

At initialization, make the correction gate zero so the implementation reproduces the baseline feedback path. Enable it gradually and verify that a zero gate and $\beta = 0$ reproduce baseline outputs within the stated numerical tolerance. Use deterministic anchor ordering and record retrieval ties. Updating the bank, solving the star and taking a backbone step are separate operations in the execution trace.

## 8.3 Attention, stopping and branches

The attention-decay curriculum belongs to the training baseline. Horizontal anchor retrieval is an additional inference operation, not another name for that curriculum. Its masks must be causal, and context assignment must not use the training-only explicit answer. A controlled experiment should vary separator punctuation while retaining the same semantic context graph. Otherwise the model may learn formatting shortcuts instead of useful compression anchors.

A branch identifier prevents accidental mixing of mutually exclusive hypotheses. Multiple branches may be scored or compared through a separate decision mechanism; their embeddings should not simply be averaged into a supposed consensus. If contradictory evidence concerns the same actual world, keep its provenance and residual rather than hiding it by splitting every disagreement into a new branch.

An end-marker controller needs a maximum latent-step budget. Adding a low-residual stopping gate can suppress some unsupported exits but can also prolong wrong agreement or block correct answers with incomplete contexts. Evaluate both errors: premature stopping and needless continuation. Verification failures and fallback invocations belong in the reported task cost.

## 8.4 Cost and implementation risks

For sidecar dimension $r$ and $q$ scalar overlap observations, a dense solve costs approximately $O\left( qr^{2} + r^{3} \right)$ to form and factor the system. Fixed reusable map patterns permit factor reuse; changing gates or metrics may not. A bank of $m$ anchors at $s$ selected depths stores $O(msr)$ feature values plus metadata, in addition to the backbone KV cache. Retrieval has its own latency and memory cost.

Latent inference still performs backbone calls and creates cache entries. Fewer reported tokens do not imply proportional savings in FLOPs, memory traffic or wall-clock time. Training with a long explicit path and a recurrent implicit path also has activation and gradient costs. Record teacher-path cost, backpropagation length, solver iterations, peak memory and hardware. Any gain must survive comparison with a baseline given the same calls or the same time budget.

Soft retrieval can maintain differentiability but may blur branches. Hard retrieval is easier to audit but makes selection discontinuous. The initial fixed-map experiments should hold retrieval fixed during derivative checks and separately measure selection sensitivity. Calibration drift after joint fine-tuning requires adapter versioning and bank invalidation; stale anchors must not be silently treated as observations in a new gauge.

# 9. Experiments that could reject the idea

## 9.1 Work stages

**S0: reproducible baseline.** Reproduce Sep-Latent with dataset identities, split rules, attention-decay implementation, alignment convention, model revision and stopping policy recorded. Establish both the paper-faithful baseline and a controlled indexed-alignment variant. Match training budgets where possible and report deviations. Do not attribute a benefit from indexed alignment to sheaf gluing.

**S1: known contexts.** Use synthetic chain and cycle objectives with exact variable identities, partial observations and held-out compositions. Vary overlap coverage, noise, contradictory observations and branch ambiguity independently. Test the read without a language model first, then attach a frozen model. This stage isolates the effect of correct restrictions.

**S2: causal adapter study.** Train small adapters and correction gates on a frozen backbone. Compare matched latent-step budgets and parameter counts. Intervene on shared variables, private variables, retrieved anchors and separator placement. Report whether interventions change verified answers in the required direction.

**S3: learned structure.** Only after S1--S2, learn context assignment or restrictions. Track singular values, zero-map collapse, branch errors and coverage. Include an unrestricted block-matrix read with the same parameter budget: when two implementations compute the same operator, the sheaf vocabulary alone cannot explain an advantage.

## 9.2 Proposed preregistration

Table 3 gives proposed decision criteria to fix before training. They are planning thresholds, not confidence intervals or observed effects. Use paired task instances and seed-aware uncertainty estimates. A study that cannot resolve a threshold should report insufficient evidence rather than success. Failure to meet a success criterion is not necessarily evidence that the underlying effect is absent.

Table: **Table 3.** Proposed hypotheses and decision rules for the planned success claims.

  -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Hypothesis**                               **Prediction fixed in advance**                                                                                                                          **Failure criterion**
  -------------------------------------------- -------------------------------------------------------------------------------------------------------------------------------------------------------- -------------------------------------------------------------------------------------------
  H1: typed partial gluing helps composition   At least 3 percentage points higher verified accuracy than indexed Sep-Latent on held-out chain compositions at matched backbone calls                   Gain below 3 points, or its uncertainty does not support the threshold

  H2: context maps matter                      Correct maps beat an edge-permuted control by at least 2 points under otherwise identical training                                                       Permuted maps match or beat correct maps within uncertainty

  H3: anchors carry used information           At least 75% of valid shared-variable interventions produce the required answer change; private interventions preserve at least 95% of correct answers   Either threshold is missed, or only retrained rather than within-model interventions work

  H4: structural stopping is useful            At least 25% fewer verifier-detected premature exits with no more than 10% extra mean backbone calls                                                     Error reduction or call budget fails

  H5: compression remains worthwhile           At matched verified accuracy, at least 10% lower median end-to-end latency than the controlled explicit-CoT baseline                                     Latency criterion fails after retrieval, solves and fallback costs are included
  -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

H2 needs both evaluation-time corruption of a trained system and independently retrained controls; they answer different questions about reliance and learnability. H3 interventions must preserve task validity and avoid arbitrary off-manifold hidden-vector edits. H5 uses the same hardware, batching, answer budget and correctness criterion. A model that merely stops early on difficult tasks must not count as efficient.

## 9.3 Baselines, measurements and leakage controls

Essential controls are: original Sep-Latent; indexed alignment without horizontal reads; a parameter-matched extra MLP; fixed pause vectors; identity full-vector consensus; random or permuted restrictions; generic learned block-matrix aggregation; and $\beta = 0\text{.}$ For sheaf variants compare correct typed contexts, nearest-neighbour contexts and parser-predicted contexts. These separate the value of extra computation, the value of correct metadata and the value of the structured read.

Primary outcomes are verified task accuracy and violation of known semantic constraints. Secondary outcomes include overlap residual, observed rank, hidden-feature effective rank, smallest positive singular values, per-branch accuracy, invalid branch mixtures and fallback rate. Plot accuracy against actual backbone calls and end-to-end latency, not just output tokens. Track prompt and answer lengths, cache bytes, solver time, FLOPs estimates and peak device memory.

Split augmented questions by source template or source problem before training. Hold out variable combinations and branch structures, not merely rephrasings. Context labels and map construction must be available from the permitted prefix at inference. Include paraphrases and alternative separator placement. For causal tests, shuffle eligible anchor contents, erase selected shared information, preserve private information, and compare with equally sized irrelevant perturbations. A low-dimensional latent plot is a diagnostic, not a success criterion.

# 10. Integration into the sheaf papers and the memory programme

In **Part I**, this idea supplies a concrete distinction between a stalk, an observation and a vertical fibre diagram. It also motivates preserving indexed layer data: pooled distillation can erase the very distinctions that a vertical representation is meant to study. No amendment to the underlying sheaf definitions is needed.

In **Part II**, the causal observation star becomes a practical read: separator anchors provide pinned local observations and the current latent proposal is the free centre. The fixed-map quadratic energy gives a transparent first implementation. Robust convex alternatives can follow after the quadratic mechanism is understood.

In **Part III**, multilayer sidecars provide a test case for commuting squares, base changes and defects. A nonlinear transformer should appear as the source of observations and local tangents, not be declared globally linear to obtain an attractive barcode. Learned covers must be treated with the inverse-image construction and, where necessary, zigzag indexing.

In **SheafFarm** \[8\], the proposal is a new instance of the distinction between an operator and a typed compatibility model. If a generic operator realizes the same read, one cannot infer additional computational power from the word "sheaf." The added value is an auditable specification of what information is shared and what a residual certifies. This fits the project's emphasis on declared maps, units and limited certificates.

For **short-term to long-term memory**, the anchor bank is initially working memory. A later consolidation stage could promote only externally verified, well-covered anchors into a versioned store, retaining context, restrictions, provenance and confidence. Promotion should optimize storage cost against future verified utility and interference. It must not average incompatible coordinates or erase conflicting evidence. This is an algorithmic proposal, not evidence of a neocortical mechanism.

The most informative first integration is S1 on chain-structured partial-information objectives, followed by the frozen-backbone adapter study. If correct maps do not beat matched generic controls there, adding learned topology and multilayer losses would obscure the answer. If they do, the next question is whether inference-time context assignment can recover enough of that benefit without privileged labels.

# 11. Numerical sanity checks and scope

A small NumPy computation was run for this paper. It uses float64 and random seed 20261020 for its nontrivial test matrices. Twelve checks pass: the worked read, private-coordinate preservation, stationarity, finite-difference sensitivity, pooled cancellation, singular-direction gains, the distance equality in the example, an exact commuting square, a three-layer residual identity, its norm bound, wrong-consensus compatibility and zero-map collapse. Algebraic checks use tolerance $10^{- 11}\text{;}$ the finite-difference check uses $10^{- 9}\text{.}$

These are sanity checks of the specified equations and counterexamples. They do not test language-model training, semantic context extraction, reasoning faithfulness, latency or the five experimental hypotheses. The plot in Figure 1 is generated from the analytic sensitivity formula. All benchmark numbers in Table 1 are attributed to the attached Sep-Latent preprint rather than to these scripts.

The mathematical solve is standard regularized least squares. The proposed contribution is its use as a typed, causal interface between separator compression and continuous feedback, together with explicit limits on what agreement means. The implementation should earn its place through the falsifiable comparisons above. Its useful promise is controlled recombination of partial information; its principal risk is making a wrong internal account more consistently wrong.

# References

\[1\] Xu, Y., Huang, J., Zhou, Z., Lin, M., Lv, F., Ou, D., Xu, H., and Wu, J. (2026). *Sep-Latent: Separator Tokens as Natural Compression Anchors for Implicit Reasoning.* arXiv:2610.22924v1, 16 October. Attached version consulted, especially §§3--5 and Appendices A--D. https://arxiv.org/abs/2610.22924v1

\[2\] Hao, S., Sukhbaatar, S., Su, D. J., Li, X., Hu, Z., Weston, J., and Tian, Y. (2024; revised 2026). *Training Large Language Models to Reason in a Continuous Latent Space.* arXiv:2412.06769. COLM 2025. https://arxiv.org/abs/2412.06769

\[3\] Shen, Z., Yan, H., Zhang, L., Hu, Z., Du, Y., and He, Y. (2025). *CODI: Compressing Chain-of-Thought into Continuous Space via Self-Distillation.* arXiv:2502.21074. https://arxiv.org/abs/2502.21074

\[4\] Zhang, Y., Tang, B., Ju, T., Duan, S., and Liu, G. (2025). *Do Latent Tokens Think? A Causal and Adversarial Analysis of Chain-of-Continuous-Thought.* arXiv:2512.21711. https://arxiv.org/abs/2512.21711

\[5\] Hansen, J., and Ghrist, R. (2019). *Toward a Spectral Theory of Cellular Sheaves.* Journal of Applied and Computational Topology 3, 315--358. https://arxiv.org/abs/1808.01513

\[6\] Russold, F. (2022). *Persistent Sheaf Cohomology.* arXiv:2204.13446. https://arxiv.org/abs/2204.13446

\[7\] Carlsson, G., and de Silva, V. (2010). *Zigzag Persistence.* Foundations of Computational Mathematics 10, 367--405. https://doi.org/10.1007/s10208-010-9066-0

\[8\] Ghosh, D. P. (2026). *SheafFarm: Some Sheaf-Diffusion Algorithms are More Sheaf Than Others.* Version 3, project manuscript. Used for continuity of notation and research questions; not treated as independent empirical validation.
