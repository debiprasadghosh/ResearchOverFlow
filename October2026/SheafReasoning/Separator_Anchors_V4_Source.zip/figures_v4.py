"""Figures 4 and 5 of Version 4, drawn from the validated computations."""
from pathlib import Path
import json, math
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.special import gammaln

P = Path(__file__).resolve().parent
V = json.loads((P / 'cs_validate.json').read_text())
B, O, A, INK, MUT = '#2a78d6', '#eb6834', '#1baf7a', '#222222', '#6b6b6b'
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.edgecolor': MUT, 'axes.labelcolor': INK, 'xtick.color': MUT, 'ytick.color': MUT,
                     'axes.grid': True, 'grid.color': '#e6e6e6', 'grid.linewidth': .6})

# ---------------- Figure 4: retained gain of three schedules
N = np.unique(np.logspace(0, 4, 120).astype(int)); c = .5
fig, ax = plt.subplots(figsize=(6.4, 3.4))
for p, col, lab in ((.5, O, r'$p=1/2$ (non-summable, faster than harmonic)'),
                    (1, B, r'$p=1$ (harmonic, $c=1/2$)'), (2, A, r'$p=2$ (summable)')):
    g = [np.prod(1 / (1 + c / np.arange(1, n + 1) ** p)) for n in N]
    ax.loglog(N, g, color=col, lw=2, label=lab)
ax.loglog(N, [math.exp(gammaln(n + 1) + gammaln(1.5) - gammaln(n + 1.5)) for n in N], ls='none', marker='o', ms=3,
          mfc='white', mec=B, markevery=8, label=r'closed form $\Gamma(N+1)\Gamma(1+c\lambda)/\Gamma(N+1+c\lambda)$')
ax.loglog(N, math.gamma(1.5) * N ** -.5, color=MUT, lw=1, ls='--', label=r'asymptote $\Gamma(1+c\lambda)N^{-c\lambda}$')
ax.set_ylim(1e-8, 1.2); ax.set_xlabel('number of reads $N$'); ax.set_ylabel('retained gain on $\\lambda=1$')
ax.legend(frameon=False, fontsize=7.5, loc='lower left')
fig.tight_layout(); fig.savefig(P / 'fig' / 'fig4_schedules.png', dpi=220); plt.close(fig)

# ---------------- Figure 5: loop thresholds and robust-bound tightness
fig, (a1, a2) = plt.subplots(1, 2, figsize=(6.6, 3.2), gridspec_kw={'width_ratios': [1.25, 1]})
loop = V['extra']['loop']
for k in ('1', '2', '3'):
    s = np.array(loop[k]); x = int(k) + np.random.default_rng(int(k)).uniform(-.18, .18, len(s))
    a1.scatter(x, s, s=9, color=B, alpha=.55, lw=0, label='mixing backbone $Q$ (random orthogonal)' if k == '1' else None)
    a1.plot([int(k) - .3, int(k) + .3], [1, 1], color=O, lw=2.2, label='non-mixing backbone $Q=I$' if k == '1' else None)
    a1.plot([int(k) - .3, int(k) + .3], [np.median(s)] * 2, color=INK, lw=1)
a1.set_xticks([1, 2, 3]); a1.set_xlabel('private dimension $k$ (of $r=6$)'); a1.set_ylabel('loop threshold $s^\\ast=1/\\rho(JQ)$')
a1.set_ylim(0.8, 4); a1.legend(frameon=False, fontsize=7, loc='upper right'); a1.set_title('(a) loop stability', fontsize=9, color=INK)
h = V['extra']['ratios_hist']; edges = np.linspace(0, .5, 21)
a2.bar(edges[:-1], h, width=.025 - .002, align='edge', color=B)
a2.axvline(1, color=O, lw=2); a2.text(.97, max(h) * .9, 'bound', color=O, ha='right', fontsize=8)
a2.set_xlim(0, 1.05); a2.set_xlabel('measured shift / bound (29)'); a2.set_ylabel('trials (of 400)')
a2.set_title('(b) finite-corruption bound', fontsize=9, color=INK)
fig.tight_layout(); fig.savefig(P / 'fig' / 'fig5_loop_robust.png', dpi=220); plt.close(fig)
print('ok')
