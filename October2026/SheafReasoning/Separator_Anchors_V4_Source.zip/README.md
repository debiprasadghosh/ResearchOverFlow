# Separator Anchors V4: source

- `cs/` immutable C# kernel (.NET 8, no packages): `Sidecar.cs`, `Program.cs`, `Sidecar.csproj`, `nuget.config`; `cs_out.txt` is its output.
- `cs_validate.py` regenerates the same SplitMix64/Box-Muller inputs and recomputes all 25 results with NumPy/SciPy; writes `cs_validate.json`.
- `undamped_check.py` reproduces the undamped semismooth-Newton failure described in Section 19.3.
- `figures_v4.py` draws Figures 4 and 5 from `cs_validate.json`; `fig/` also holds the Version 3 figures.
- `assemble_v4.py` builds `paper.md` from the Version 3 text (`v3.md`) and the results; `build.py` + `postprocess.py` + `reference.docx` produce the Word file.

Order: build and run the C# project (stdout to `cs/cs_out.txt`), then `cs_validate.py`, `figures_v4.py`, `assemble_v4.py`, `build.py`.
