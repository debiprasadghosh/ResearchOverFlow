"""Build a scholarly Word paper with native OMML through Pandoc."""
from pathlib import Path
import re,subprocess,sys
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph

P=Path(__file__).resolve().parent
doc=Document(P/'reference.docx')
for child in list(doc._element.body):
    if child.tag!=qn('w:sectPr'):doc._element.body.remove(child)
for sec in doc.sections:
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.left_margin=sec.right_margin=Inches(.78)
    sec.top_margin=sec.bottom_margin=Inches(.7)
    sec.header_distance=sec.footer_distance=Inches(.3)
    for part in (sec.header,sec.first_page_header,sec.even_page_header,sec.footer,sec.first_page_footer,sec.even_page_footer):
        for p in part.paragraphs:p.clear()
    foot=sec.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.CENTER
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');foot._p.append(field)
for name in ['Normal','Body Text','First Paragraph','Compact','Statement']:
    st=doc.styles[name];st.font.name='Liberation Serif';st.font.size=Pt(11)
    st.paragraph_format.line_spacing=1.14;st.paragraph_format.space_after=Pt(7)
for st in doc.styles:
    if st.type==1:st.font.color.rgb=RGBColor(0,0,0)
    for node in list(st.element.iter()):
        if node.tag in [qn('w:pBdr'),qn('w:shd')]:node.getparent().remove(node)
doc.styles['Title'].font.size=Pt(24)
for name in ['Title','Subtitle','Author','Date']:
    doc.styles[name].paragraph_format.keep_with_next=True
doc.styles['Date'].paragraph_format.space_after=Pt(15)
doc.styles['Bibliography'].font.size=Pt(10)
doc.styles['Bibliography'].paragraph_format.space_after=Pt(7)
for name in ['Caption']:
    doc.styles[name].font.size=Pt(9.7)
    doc.styles[name].paragraph_format.space_after=Pt(10)
for name in ['Equation','Statement Equation']:
    pf=doc.styles[name].paragraph_format
    pf.space_before=Pt(4);pf.space_after=Pt(9);pf.line_spacing=1.0;pf.keep_together=True
    pr=doc.styles[name].element.get_or_add_pPr()
    for old in pr.findall(qn('w:tabs')):pr.remove(old)
    tabs=OxmlElement('w:tabs')
    for value,pos in [('center',4997),('right',9994)]:
        el=OxmlElement('w:tab');el.set(qn('w:val'),value);el.set(qn('w:pos'),str(pos));tabs.append(el)
    pr.append(tabs)
doc.save(P/'reference.docx')
s=(P/'paper.md').read_text()
def display(match):
    math=match[1].strip();num=re.search(r'\\tag\{(\d+)\}',math)
    if num is None:return match[0]
    math=math[:num.start()].strip()
    lines=[math];aligned=math.startswith(r'\begin{aligned}')
    if math.startswith(r'\begin{aligned}'):
        lines=math.replace(r'\begin{aligned}','').replace(r'\end{aligned}','').split(r'\\')
    return '\n'.join('\n::: {custom-style="Equation"}\n$'+(line.replace('&','') if aligned else line).replace('\n',' ').strip()+'$'+(' ('+num[1]+')' if i==len(lines)-1 else '')+'\n:::\n' for i,line in enumerate(lines))
s=re.sub(r'\$\$(.*?)\$\$',display,s,flags=re.S)
s=re.sub(r'(?<!\$)\$([^$\n]+)\$([,.;:])(?!\w)',lambda m:'$'+m[1]+r'\text{'+m[2]+'}$',s)
(P/'build.md').write_text(s)
subprocess.run(['pandoc','-f','markdown+tex_math_dollars','build.md','-o','raw.docx','--reference-doc=reference.docx','--resource-path=.','--no-highlight'],cwd=P,check=True)
doc=Document(P/'raw.docx')
doc.core_properties.title='Separator Anchors for Sheaf Based Latent Reasoning'
doc.core_properties.author='Debi Prasad Ghosh'
doc.core_properties.subject='Mathematical foundations and implementation within Autoregressive Sheaf Evolution. Version 4'
doc.core_properties.keywords='latent reasoning; separator anchors; cellular sheaf; proximal read; robust estimation; immutable C#; numerical validation'
inrefs=False
for p in doc.paragraphs:
    if p.style.name=='Title':p.text='Separator Anchors for\nSheaf Based Latent Reasoning'
    if p.text=='References':inrefs=True;p.paragraph_format.page_break_before=True
    if p.text.startswith('Appendix A'):inrefs=False;p.paragraph_format.page_break_before=True
    elif inrefs and p.text.startswith('['):p.style=doc.styles['Bibliography']
    if p.text.startswith(('Theorem ','Proposition ','Definition ','Example ')):p.paragraph_format.keep_with_next=True
    if p.style.name=='Equation' and not re.search(r'\(\d+\)\s*$',p.text):p.paragraph_format.keep_with_next=True
    if p._p.xpath('.//w:drawing'):p.paragraph_format.keep_with_next=True
    if p.style.name in ['Caption','Image Caption']:p.paragraph_format.keep_together=True
    if p.style.name=='Table Caption' or re.match(r'Table \d+\.',p.text):p.paragraph_format.keep_with_next=True
    if p.style.name=='Source Code':
        p.paragraph_format.space_after=Pt(0);p.paragraph_format.line_spacing=1.0
        for run in p.runs:run.font.size=Pt(7.6);run.font.name='Liberation Mono'
for ti,table in enumerate(doc.tables):
    widths=[[3.27,1.81,1.81],[1.56,2.57,2.81],[1.62,3.08,2.24],[2.64,2.95,1.35],[2.9,2.4,1.64]][ti]
    table.autofit=False
    for col,w in zip(table.columns,widths):col.width=Inches(w)
    pr=table._tbl.tblPr
    for old in pr.findall(qn('w:tblBorders')):pr.remove(old)
    borders=OxmlElement('w:tblBorders')
    for side in ['top','left','bottom','right','insideH','insideV']:
        el=OxmlElement('w:'+side);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'4');el.set(qn('w:color'),'D9D9D9');borders.append(el)
    pr.append(borders)
    for ri,row in enumerate(table.rows):
        trpr=row._tr.get_or_add_trPr();trpr.append(OxmlElement('w:cantSplit'))
        if ri==0:trpr.append(OxmlElement('w:tblHeader'))
        for ci,(cell,w) in enumerate(zip(row.cells,widths)):
            cell.width=Inches(w);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcpr=cell._tc.get_or_add_tcPr()
            shade=OxmlElement('w:shd');shade.set(qn('w:val'),'clear');shade.set(qn('w:fill'),'E7EBEF' if ri==0 else ('F7F8F9' if ri%2==0 else 'FFFFFF'));tcpr.append(shade)
            mar=OxmlElement('w:tcMar')
            for side,value in [('top',85),('start',85),('bottom',85),('end',85)]:
                el=OxmlElement('w:'+side);el.set(qn('w:w'),str(value));el.set(qn('w:type'),'dxa');mar.append(el)
            tcpr.append(mar)
            for p in cell.paragraphs:
                p.paragraph_format.space_after=Pt(2);p.paragraph_format.space_before=Pt(1);p.paragraph_format.line_spacing=1.08
                pass
                for run in p.runs:run.font.size=Pt(10.2);run.bold=ri==0
                if p._p.get_or_add_pPr().find(qn('w:keepNext')) is not None:
                    p._p.get_or_add_pPr().remove(p._p.get_or_add_pPr().find(qn('w:keepNext')))
    after=table._tbl.getnext()
    if after is not None and after.tag==qn('w:p'):Paragraph(after,doc._body).paragraph_format.space_before=Pt(7)
for shape,description in zip(doc.inline_shapes,[
    'Analytic sensitivity gains of the read.',
    'Wrong-anchor shift and repeated-read convergence.',
    'Proximal sensitivity compared with independent Gaussian evidence, and the residual floor caused by grounding a tree.',
    'Retained gain against number of reads for three read schedules, with the harmonic closed form and its asymptote.',
    'Loop thresholds for mixing and non-mixing feedback, and the ratio of measured robust shift to its bound.']):
    shape._inline.docPr.set('descr',description)
doc.save(P/'layout.docx')
subprocess.run([sys.executable,'postprocess.py','layout.docx','output/Separator_Anchors_for_Sheaf_Based_Latent_Reasoning_V4.docx'],cwd=P,check=True)
(P/'output').mkdir(exist_ok=True)
print('Built Word paper')
