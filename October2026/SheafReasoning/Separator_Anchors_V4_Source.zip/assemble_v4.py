"""Assemble the Version 4 Markdown source from the Version 3 text, the C# results and the validation file."""
from pathlib import Path
import json, re, shutil

P = Path(__file__).resolve().parent
ROOT = P.parent
s = ((P / 'v3.md' if (P / 'v3.md').exists() else ROOT / 'v3.md')).read_text()
V = json.loads((P / 'cs_validate.json').read_text())
rows = {r['name']: r for r in V['rows']}
cs = {l.split()[0]: [float(x) for x in l.split()[1:]] for l in (P / 'cs' / 'cs_out.txt').read_text().splitlines()}

# ------------------------------------------------------------------ structural conversion of the V3 text
s = re.sub(r'\$(u = \(1,3,7.*?)\$ \(8\)', lambda m: '$' + ' '.join(m[1].split('\n')) + '$ (8)', s, flags=re.S)
s = re.sub(r'^#{21} ', '## ', s, flags=re.M)
s = re.sub(r'^#{11} ', '# ', s, flags=re.M)
s = re.sub(r'^\$(.+)\$ \((\d+)\)$', r'$$\1 \\tag{\2}$$', s, flags=re.M)
s = re.sub(r'^(\$[^$\n]+\$)$', r'::: {custom-style="Equation"}\n\1\n:::', s, flags=re.M)
(P / 'fig').mkdir(exist_ok=True)
for i in (1, 2, 3):
    shutil.copy(ROOT / 'media' / 'media' / f'image{i}.png', P / 'fig' / f'image{i}.png')
s = re.sub(r'!\[[^\]]*\]\(media/media/(image\d)\.png\)\{[^}]*\}', r'![](fig/\1.png){width=100%}', s)
s = s.replace('\nTable 4. Selected', '\n**Table 4.** Selected').replace('\nFigure 3. Left:', '\n**Figure 3.** Left:')

FRONT = '''---
title: "Separator Anchors for Sheaf Based Latent Reasoning"
subtitle: Mathematical foundations and implementation within Autoregressive Sheaf Evolution
author:
  - Debi Prasad Ghosh
date: 20 October 2026 · Version 4 · Mathematical research paper
---

'''
s = FRONT + s

# ------------------------------------------------------------------ abstract
old = 'Fifty-three numerical checks verify illustrative identities and counterexamples;'
assert old in s
s = s.replace(old, 'Fifty-three numerical checks verify illustrative identities and counterexamples, and an immutable C# kernel '
                   'cross-validated against NumPy explores how sharp the bounds are;')
ABS4 = ('**Numerical development in Version 4.** An immutable C# kernel recomputes the Version 3 examples and probes the '
        'bounds with seeded Monte Carlo. NumPy regenerates the same random inputs and agrees on all 25 reported results. '
        'A harmonic read schedule has an exact Gamma-function gain, so its hardening follows the power law '
        r'$N^{-c\lambda}\text{:}$ it is the boundary case of the spending criterion. '
        'The finite-corruption bound held in 400 trials, with median ratio 0.10. An apparent violation produced by an '
        'undamped Newton solver was exposed by the stationarity certificate. For orthogonal backbone feedback, the read '
        'adds no stability margin exactly when the private subspace contains an invariant subspace of the feedback. '
        'Mixing restores a margin, but the margin shrinks as the private dimension grows. Section 19 and Appendix A '
        'contain these results.')
i = s.index('**Central proposal.**'); s = s[:i] + ABS4 + '\n\n' + s[i:]

# ------------------------------------------------------------------ section 18 note
anchor = '\n# References'
S18 = ('Version 4 leaves these 53 checks unchanged. It adds 25 cross-language results from the immutable C# kernel '
       'of Appendix A. Section 19 reports them, and Table 5 gives the agreement with NumPy.\n')
s = s.replace(anchor, '\n' + S18 + anchor, 1)


# ------------------------------------------------------------------ section 19
def g(x, d=6): return f'{x:.{d}g}'
def e(x):
    m, ex = f'{x:.1e}'.split('e'); return rf'{m}\times 10^{{{int(ex)}}}'


sch = {n: cs[f'schedule_N{n}'] for n in (10, 100, 1000, 10000)}
rt = cs['robust_tightness']; dr = cs['insertion_drift']; eq = cs['equivariance_tightness']
lp = {k: cs[f'loop_private{k}'] for k in range(4)}
harm_rel = abs(sch[10000][1] - sch[10000][2]) / sch[10000][2]

tab = ['| Result | C# value | NumPy max difference |', '|:--|:--|:--|']
def row(label, name, vals):
    tab.append(f'| {label} | {vals} | ${e(max(rows[name]["max_rel_diff"], 1e-17))}$ |' if rows[name]['max_rel_diff'] > 0
               else f'| {label} | {vals} | 0 |')
row('Grounded-tree residual (Example 10.2)', 'grounded_tree', '1.4142135623730951')
row('Twenty reads: gain and floor (25)', 'twenty_reads', f'{g(cs["twenty_reads"][0])} and {g(cs["twenty_reads"][1])}')
row('Equivalent ratios (26)', 'equivalent_ratio', '6.59375 and 60.5')
row('Huber consolidation counterexample', 'huber_consolidation', g(cs['huber_consolidation'][1]))
row('Anchor influence and bound (20)', 'anchor_influence', '1.0000000 and 1')
row('Harmonic gain, $N=10^4$', 'schedule_N10000', g(sch[10000][1], 8))
row('Robust ratio: maximum and median', 'robust_tightness', f'{g(rt[0], 4)} and {g(rt[1], 4)}')
row('Loop threshold, $k=1$: median', 'loop_private1', g(lp[1][2], 5))
row('Equivariance ratio: median', 'equivariance_tightness', g(eq[1], 4))
TABLE5 = '\n'.join(tab)

S19 = rf'''# 19. Immutable C# numerical explorations

Version 3 checked its examples with NumPy scripts. Version 4 adds an independent kernel written in C# in an immutable style. Matrices are records over immutable arrays, every operation is a pure static function, and the random-number generator is itself a value: a draw returns a number and the next generator rather than changing state. The design serves two purposes. First, every printed result is recomputed in Python with different algorithms: LAPACK solves and eigenvalues, iteratively reweighted least squares for the robust read, Householder QR and the log-gamma function. The random inputs are nevertheless bit-identical, because both languages implement the same SplitMix64 stream [12] and the same Box–Muller transform [13]. Second, seeded Monte Carlo shows how sharp Version 3's bounds are, which single examples cannot show.

## 19.1 Cross-language agreement

The kernel prints 25 named results; Appendix A lists the code. Each value is compared with its NumPy recomputation by $|a-b|/\max(1,|b|)\text{{,}}$ with tolerance $10^{{-9}}\text{{.}}$ The finite-difference gain uses $10^{{-7}}$ because central differences carry truncation and cancellation error. Two roundoff quantities, the metric-covariance residual and the largest robust stationarity residual, must both lie below $10^{{-10}}$ in each language. The Sherman–Morrison drift is a property of the C# floating-point path and is checked only against that threshold. All 25 results pass. Table 5 shows a selection; the complete comparison is in the source archive.

**Table 5.** Selected C# results and their largest difference from the independent NumPy recomputation.

{TABLE5}

The Version 3 values are reproduced to the printed precision. The anchor-influence example also confirms that (20) is sharp: a singular value $\sigma=\sqrt{{\mu/\beta}}$ attains $\|K\|=\tfrac12\sqrt{{\beta/\mu}}\text{{.}}$ Metric covariance (Theorem 9.2) holds on a random metric to ${e(cs['metric_covariance'][0])}\text{{.}}$

## 19.2 Harmonic schedules give an exact power law

Theorem 11.1 separates schedules whose spend diverges, and therefore harden, from those with a positive floor. The boundary case has a closed form.

**Proposition 19.1 (harmonic schedule).** Use unit gates and ratios $\alpha_j=c/(j+1)$ with $c>0\text{{.}}$ On an eigendirection with eigenvalue $\lambda>0\text{{,}}$ the retained gain (23) after $N$ reads is

$$\gamma_N(\lambda)=\frac{{\Gamma(N+1)\,\Gamma(1+c\lambda)}}{{\Gamma(N+1+c\lambda)}}\;\sim\;\Gamma(1+c\lambda)\,N^{{-c\lambda}}. \tag{{38}}$$

**Proof.** With $g_j=1$ each factor of (23) equals $1/(1+\alpha_j\lambda)=(j+1)/(j+1+c\lambda)\text{{.}}$ The product of $m/(m+c\lambda)$ over $m=1,\dots,N$ is $\Gamma(N+1)\Gamma(1+c\lambda)/\Gamma(N+1+c\lambda)$, by $\Gamma(x+1)=x\Gamma(x)\text{{.}}$ The asymptotic form follows from $\Gamma(N+1)/\Gamma(N+1+a)\sim N^{{-a}}$ as $N$ grows. ∎

**Corollary 19.2 (three regimes).** Put $\alpha_j=c(j+1)^{{-p}}$ with unit gates, and write $H_N(p)$ for the sum of $m^{{-p}}$ over $m=1,\dots,N\text{{.}}$ Then

$$-c\lambda H_N(p)\le\log\gamma_N(\lambda)\le -c\lambda H_N(p)+\tfrac12(c\lambda)^2H_N(2p). \tag{{39}}$$

For $p<1$, $\log\gamma_N(\lambda)$ behaves as $-c\lambda N^{{1-p}}/(1-p)$, so the gain decays faster than any power. For $p=1$ the decay is the power law (38). For $p>1$ the gain has a positive limit; for $p=2$ the limit is $\pi\sqrt{{c\lambda}}/\sinh(\pi\sqrt{{c\lambda}})$.

**Proof.** Apply $x-x^2/2\le\log(1+x)\le x$ to each factor $1/(1+c\lambda m^{{-p}})$ and sum. For $p<1$ the second sum has lower order than the first. The $p=2$ limit is Euler's product $\sinh(\pi x)/(\pi x)=\prod_m(1+x^2/m^2)$ with $x^2=c\lambda\text{{.}}$ ∎

With $c=0.5$ and $\lambda=1$ the kernel gives the following retained gains. After $N=10$ reads they are {g(sch[10][0], 5)}, {g(sch[10][1], 5)} and {g(sch[10][3], 5)} for $p=\tfrac12,1,2$. After $N=10^4$ reads they are ${e(sch[10000][0])}$, {g(sch[10000][1], 6)} and {g(sch[10000][3], 6)} (Figure 4). The harmonic product agrees with the Gamma form to ${e(harm_rel)}$ relative, the accumulated roundoff of $10^4$ factors. Its asymptote $\Gamma(1.5)\,10^{{-2}}=0.0088623$ is already accurate to four digits. The $p=2$ value approaches its limit 0.487577 from above.

![](fig/fig4_schedules.png){{width=100%}}

**Figure 4.** Retained gain on $\lambda=1$ for three gate-free schedules $\alpha_j=0.5(j+1)^{{-p}}\text{{.}}$ Circles mark the closed form (38); the dashed line is its asymptote. Computed by the C# kernel and redrawn from the validated NumPy values.

The harmonic schedule hardens, because its spend diverges, but only logarithmically. The read then acts on the spectrum as $\Gamma(1+c\lambda)e^{{-c\lambda\log N}}$: up to a smooth factor, this is the heat-flow filter at time $c\log N$. Two eigendirections separate as $N^{{-c(\lambda_1-\lambda_2)}}$, and doubling the number of reads multiplies the retained gain by about $2^{{-c\lambda}}\text{{.}}$ A controller that wants predictable, scale-dependent hardening can therefore choose $c$; it needs a summable schedule only when it wants a floor. These statements concern a fixed bank with commuting reads, the setting of Theorem 11.1.

## 19.3 How tight is the finite-corruption bound?

The experiment uses $q=8$ observation rows on $r=4$ coordinates, with $\mu=1$, $\beta=3$ and $\delta=0.5$. In each of 400 trials the first two observations are corrupted by $100$ times a standard normal draw. The ratio of the measured shift to the bound (29) had maximum {g(rt[0], 3)}, median {g(rt[1], 3)} and mean {g(rt[2], 3)} (Figure 5b). The bound never failed. In typical trials it is about ten times too large. The factor two is attained only in the scalar construction of Theorem 12.1, which the kernel reproduces with shift and bound both equal to 3. The slack has a clear source. The proof bounds the inverse curvature by $1/\mu$, ignoring the curvature $\beta c_ic_i^\top$ of the clean rows that remain in the quadratic zone. A sharper bound would need control of the active set along the whole segment between the two solutions, which (29) deliberately avoids.

**A solver episode.** The first C# implementation used undamped semismooth Newton steps [14], started from the quadratic read. The first run reported a maximum ratio of 4.79 and a median of 1.16. Taken at face value, 247 of the 400 trials refuted Theorem 12.1. The stationarity certificate of Section 15.2 shows what happened instead. In every trial at least one of the two solves ended with a gradient norm far from zero, as large as 41. The undamped iteration was cycling between active sets. Armijo backtracking on the strongly convex objective [15] restored convergence. Across all 800 solves, the largest certificate is now ${e(cs['robust_certificate'][0])}$, so every computed read is within that distance of the exact read divided by $\mu=1\text{{.}}$ The NumPy script reproduces both the faulty and the corrected numbers exactly. The procedural lesson is that a numerical counterexample to a proved bound must carry its certificate before it is believed.

## 19.4 Exact insertion does not drift in the tested regime

Corollary 13.2 updates the read after a new anchor by a rank-one formula. The experiment stores the inverse Hessian explicitly and applies the Sherman–Morrison update [16] after each of 2,000 Gaussian insertions in $r=16$, with unit prior and unit weight. At $m=10$, $100$, $1000$ and $2000$ insertions, the largest coordinate difference from a fresh Cholesky solve was ${e(dr[0])}$, ${e(dr[1])}$, ${e(dr[2])}$ and ${e(dr[3])}$. The state components are of order $10^{{-2}}$. The difference does not grow, because insertions only increase the Hessian, so the stored inverse contracts. The result does not cover deletion, where the rank-one weight is negative, or poorly conditioned banks. An implementation should refactorise periodically and can use (37) to decide when.

## 19.5 Loop stability needs mixing

Theorem 15.1 requires $\rho(JM)<1$. Take an orthogonal feedback scaled by a gain, $M=sQ$, so the loop is stable exactly when $s<s^{{\text{{*}}}}=1/\rho(JQ)\text{{.}}$ Here $J=\mu(\mu I+\beta C^\top C)^{{-1}}$ has eigenvalue one on $\ker C$ and eigenvalues below one elsewhere.

**Proposition 19.3 (when the read adds no loop margin).** For orthogonal $Q$, $\rho(JQ)\le1$. Equality holds if and only if $\ker C$ contains a nonzero subspace invariant under $Q\text{{.}}$ In particular, if $\ker C\neq0$ and the feedback preserves $\ker C$, then $s^{{\text{{*}}}}=1$.

**Proof.** $\|JQ\|\le\|J\|\le1$ gives the inequality. Suppose $JQx=\lambda x$ with complex $x\ne0$ and $|\lambda|=1$. Then $\|JQx\|=\|x\|=\|Qx\|$. Since $J$ is symmetric with eigenvalue one only on $\ker C$, this forces $Qx\in\ker C$ and $JQx=Qx$. Hence $Qx=\lambda x$, so $x\in\ker C$. The real and imaginary parts of $x$ then span a nonzero $Q$-invariant subspace inside $\ker C\text{{.}}$ Conversely, any nonzero invariant subspace contains a complex eigenvector $x$ of $Q$ with $Jx=x$. That $x$ is an eigenvector of $JQ$ with modulus one. ∎

The experiment takes $r=6$, $\mu=1$ and $\beta=4$, and lets $C$ observe the first $6-k$ coordinates. With no private coordinates ($k=0$), $J=0.2I$ and $s^{{\text{{*}}}}=5$ for every $Q$. For $k=1,2,3$, the non-mixing feedback $Q=I$ gives $s^{{\text{{*}}}}=1$ exactly, as Proposition 19.3 predicts. Then any amplification of a private direction destabilises the loop, whatever the anchors say. With 100 Haar-random orthogonal $Q$ for each $k$, the medians were {g(lp[1][2], 3)}, {g(lp[2][2], 3)} and {g(lp[3][2], 3)}. The minima were {g(lp[1][1], 4)}, {g(lp[2][1], 4)} and {g(lp[3][1], 4)}, and the maxima {g(lp[1][3], 3)}, {g(lp[2][3], 3)} and {g(lp[3][3], 3)} (Figure 5a).

![](fig/fig5_loop_robust.png){{width=100%}}

**Figure 5.** (a) Loop threshold $s^{{\text{{*}}}}=1/\rho(JQ)$ for 100 random orthogonal feedbacks at each private dimension $k$ (dots; black bars are medians) and for the non-mixing feedback $Q=I$ (orange bars at one). (b) Ratio of the measured robust shift to the bound (29) in 400 corrupted trials; the bound is the orange line at one.

Mixing helps because it carries private error into observed directions, where the anchors can damp it. The margin shrinks as the private subspace grows, and minima near one show that generic mixing does not guarantee a useful margin. A design therefore needs one of two things: feedback that routes private coordinates through observed ones, or separate damping of private directions, which anchors cannot reach. For a trained model, the computable diagnostic is the spectral radius of $J\,DF$ on held-out states, together with the restriction of $DF$ to the private subspace. The results above are for a linear surrogate with orthogonal feedback. Nonnormal feedback can amplify transiently even when the radius is below one (Section 15.1).

## 19.6 The equivariance bound in practice

The test draws random orthogonal $T$ and $S$ and sets $C_1=SC_0T^\top+0.05E$ with Gaussian $E$, $\mu=1$ and $\beta=2$. Over 300 trials, the ratio of the measured discrepancy to (35) had maximum {g(eq[0], 3)}, median {g(eq[1], 3)} and minimum {g(eq[2], 3)}. Version 3's single example, with ratio 0.086, was typical. The bound never failed and is usually about thirty times too large. It is useful as a guarantee, not as an estimate of the discrepancy.

## 19.7 What the explorations change

The explorations change practice in five ways.

1. **Schedules.** Choose them by regime. A harmonic schedule gives predictable power-law hardening, a summable schedule gives a floor, and $p<1$ hardens almost completely within about a hundred reads.
2. **Bound ratios.** Report measured-to-bound ratios for (29) and (35). Do not read either bound as a calibrated estimate.
3. **Robust solves.** Certify every robust solve, and treat an apparent violation of a theorem as a solver failure until a certificate shows otherwise.
4. **Rank-one updates.** Refactorise periodically after rank-one updates, and test deletions separately.
5. **Loop stability.** Check whether the feedback mixes the private subspace before attributing loop stability to the read.

None of these results is trained-model evidence. They sharpen the fixed-map mathematics on which the proposed experiments rely.
'''
s = s.replace(anchor, '\n' + S19 + anchor, 1)

# ------------------------------------------------------------------ references and appendix
REFS = r'''

\[12\] Steele, G. L., Lea, D., and Flood, C. H. (2014). *Fast Splittable Pseudorandom Number Generators.* Proceedings of OOPSLA 2014, ACM, 453--472. https://2014.splashcon.org/event/oopsla2014-fast-splittable-pseudorandom-number-generators

\[13\] Box, G. E. P., and Muller, M. E. (1958). *A Note on the Generation of Random Normal Deviates.* Annals of Mathematical Statistics 29(2), 610--611. https://doi.org/10.1214/aoms/1177706645

\[14\] Qi, L., and Sun, J. (1993). *A Nonsmooth Version of Newton's Method.* Mathematical Programming 58, 353--367. https://doi.org/10.1007/BF01581275

\[15\] Nocedal, J., and Wright, S. J. (2006). *Numerical Optimization*, 2nd edition, Chapter 3. Springer. https://doi.org/10.1007/978-0-387-40065-5

\[16\] Sherman, J., and Morrison, W. J. (1950). *Adjustment of an Inverse Matrix Corresponding to a Change in One Element of a Given Matrix.* Annals of Mathematical Statistics 21(1), 124--127. https://doi.org/10.1214/aoms/1177729893
'''
s = s.rstrip() + REFS
side = (P / 'cs' / 'Sidecar.cs').read_text().rstrip(); prog = (P / 'cs' / 'Program.cs').read_text().rstrip()
s += rf'''
# Appendix A. The immutable C# kernel

The kernel targets .NET 8 and has no package dependencies. `Sidecar.cs` holds the linear algebra, the generator and the reads. `Program.cs` prints the 25 named results that `cs_validate.py` recomputes. The source archive contains both files, the project file, the validation script and its output.

**A.1 Sidecar.cs**

```csharp
{side}
```

**A.2 Program.cs**

```csharp
{prog}
```
'''
# maths safety for LibreOffice rendering
s = s.replace(r'For numbers $a_{j}$ in $\lbrack 0,1)\text{,}$', r'For numbers $0 \leq a_{j} < 1\text{,}$')
s = s.replace(r'derivative bound $\sup_{x} \parallel J\, DF(x) \parallel < 1$ is', r'derivative bound $\parallel J\, DF(x) \parallel \leq q < 1$ for all $x$ is')
s = s.replace('x_{*}', r'x_{\text{*}}').replace('x_{\\ast}', r'x_{\text{*}}')
s = s.replace('^{*}', r'^{\text{*}}').replace('_{+}', r'_{\text{+}}').replace('^{+}', r'^{\text{+}}')
(P / 'paper.md').write_text(s)
print('words', len(s.split()))
