"""Regenerate Pathfinder-32 ("hard", contour length 14) with the original generator.

Generator: github.com/drewlinsley/pathfinder at commit 7b538865667dfe16f949ed3b7c8dc6a65ca87099
(snakes.py, snakes2.py).  Parameters: the 32 x 32 customisations listed in the LRA TFDS builder
(google-research/long-range-arena, lra_benchmarks/data/pathfinder.py, class Pathfinder32), on top of
the settings in snakes2_wrapper.py.

The repository's latest commit replaced scipy.misc.imresize / imsave by plain PIL calls, which changes
the behaviour for float arrays (no byte scaling, no clipping).  We restore the original scipy.misc
semantics (bytescale -> 'L' image -> resize; imsave = bytescale then 8-bit PNG) so that the images
match what the 2018-2020 code produced.  Images are kept as uint8 arrays (PNG is lossless).

Usage: python3 pf_gen.py <worker_id> <n_images> <out.npz>
"""
import os
import sys
import time
import random
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "data", "pathfinder_gen"))
import snakes  # noqa: E402
import snakes2  # noqa: E402

BASE_SEED = 20261010


def bytescale(data, cmin=None, cmax=None, high=255, low=0):
    """scipy.misc.bytescale (scipy <= 1.2)."""
    data = np.asarray(data)
    if data.dtype == np.uint8:
        return data
    if cmin is None:
        cmin = data.min()
    if cmax is None:
        cmax = data.max()
    cscale = cmax - cmin
    if cscale == 0:
        cscale = 1
    scale = float(high - low) / cscale
    bytedata = (data - cmin) * scale + low
    return (bytedata.clip(low, high) + 0.5).astype(np.uint8)


def imresize_orig(arr, size, interp='lanczos'):
    """scipy.misc.imresize for 2-D arrays: toimage (bytescale, mode 'L'), PIL resize, back to array."""
    func = {'nearest': 0, 'lanczos': 1, 'bilinear': 2, 'bicubic': 3, 'cubic': 3}
    im = Image.fromarray(bytescale(arr), mode=None)
    if im.mode != 'L':
        im = im.convert('L')
    im = im.resize((size[1], size[0]), resample=func[interp])
    return np.array(im)


snakes._imresize = imresize_orig
snakes2._imresize = imresize_orig

_ORIG_DRAW = snakes.draw_line_n_mask
_MINI_CACHE = {}


def _mini(orientation, length, thickness, margin, large_dilation_struct, aa_scale, contrast_scale):
    """The orientation-dependent part of snakes.draw_line_n_mask (deterministic, so it can be cached)."""
    key = (float(orientation), length, thickness, margin, aa_scale, float(contrast_scale),
           large_dilation_struct.tobytes(), large_dilation_struct.shape)
    hit = _MINI_CACHE.get(key)
    if hit is not None:
        return hit
    from PIL import ImageDraw
    miniline_blown_shape = (length + int(np.ceil(thickness)) + margin) * 2 * aa_scale + 1
    miniline_blown_center = (length + int(np.ceil(thickness)) + margin) * aa_scale
    miniline_blown_thickness = int(np.round(thickness * aa_scale))
    miniline_blown_head = snakes.translate_coord([miniline_blown_center, miniline_blown_center], orientation,
                                                 length * aa_scale)
    miniline_blown_im = Image.new('F', (miniline_blown_shape, miniline_blown_shape), 'black')
    line_draw = ImageDraw.Draw(miniline_blown_im)
    line_draw.line([(miniline_blown_center, miniline_blown_center),
                    (miniline_blown_head[1], miniline_blown_head[0])],
                   fill='white', width=miniline_blown_thickness)
    miniline_shape = (length + int(np.ceil(thickness)) + margin) * 2 + 1
    miniline_im = snakes._imresize(np.array(miniline_blown_im), (miniline_shape, miniline_shape),
                                   interp='lanczos').astype(np.float32) / 255.0
    if contrast_scale != 1.0:
        miniline_im *= contrast_scale
    minimask_blown_im = snakes.binary_dilate_custom(miniline_blown_im, large_dilation_struct,
                                                    value_scale=1.).astype(np.uint8)
    minimask_im = snakes._imresize(np.array(minimask_blown_im), (miniline_shape, miniline_shape),
                                   interp='lanczos').astype(np.float32) / 255.0
    _MINI_CACHE[key] = (miniline_im, minimask_im, miniline_shape)
    return _MINI_CACHE[key]


def draw_line_n_mask_cached(im_size, start_coord, orientation, length, thickness, margin, large_dilation_struct,
                            aa_scale, contrast_scale=1.0):
    """snakes.draw_line_n_mask with the orientation-dependent drawing cached; placement code unchanged."""
    if np.round(thickness * aa_scale) - thickness * aa_scale != 0.0:
        raise ValueError('thickness does not break even.')
    miniline_im, minimask_im, miniline_shape = _mini(orientation, length, thickness, margin, large_dilation_struct,
                                                     aa_scale, contrast_scale)
    l_im = np.zeros((im_size[0], im_size[1]), dtype=np.float32)
    m_im = l_im.copy()
    ext = length + int(np.ceil(thickness)) + margin
    v_raw = [start_coord[0] - ext, start_coord[0] + ext]
    h_raw = [start_coord[1] - ext, start_coord[1] + ext]
    v_rect = [np.maximum(v_raw[0], 0), np.minimum(v_raw[1], im_size[0] - 1)]
    h_rect = [np.maximum(h_raw[0], 0), np.minimum(h_raw[1], im_size[1] - 1)]
    mv = [np.maximum(0, -v_raw[0]), miniline_shape - 1 - np.maximum(0, v_raw[1] - (im_size[0] - 1))]
    mh = [np.maximum(0, -h_raw[0]), miniline_shape - 1 - np.maximum(0, h_raw[1] - (im_size[1] - 1))]
    l_im[v_rect[0]:v_rect[1] + 1, h_rect[0]:h_rect[1] + 1] = miniline_im[mv[0]:mv[1] + 1, mh[0]:mh[1] + 1].copy()
    m_im[v_rect[0]:v_rect[1] + 1, h_rect[0]:h_rect[1] + 1] = minimask_im[mv[0]:mv[1] + 1, mh[0]:mh[1] + 1].copy()
    return l_im, m_im


_GEOM_CACHE = {}


def get_coords_cmf_cached(last_endpoint, last_orientation, step_length, mask, continuity):
    """snakes.get_coords_cmf with its mask-independent geometry cached; the mask-dependent part unchanged."""
    height, width = mask.shape[0], mask.shape[1]
    key = (int(last_endpoint[0]), int(last_endpoint[1]), float(last_orientation), step_length, float(continuity),
           height, width)
    geom = _GEOM_CACHE.get(key)
    if geom is None:
        deg_per_pixel = 360. / (2 * step_length * np.pi)
        samples_in_rad = np.arange(0, 360, deg_per_pixel) * np.pi / 180
        samples_in_y = last_endpoint[0] + (step_length * np.sin(samples_in_rad))
        samples_in_x = last_endpoint[1] + (step_length * np.cos(samples_in_rad))
        samples_in_coord = np.concatenate((np.expand_dims(samples_in_y, axis=1),
                                           np.expand_dims(samples_in_x, axis=1)), axis=1).astype(int)
        OOB_rows = (samples_in_y >= height) | (samples_in_y < 0) | (samples_in_x >= width) | (samples_in_x < 0)
        samples_in_coord = np.delete(samples_in_coord, np.where(OOB_rows), axis=0)
        if samples_in_coord.shape[0] == 0:
            geom = (None,)
        else:
            unique_coords, indices = np.unique(samples_in_coord, axis=0, return_index=True)
            unique_displacements = unique_coords - last_endpoint
            unique_orientations = np.arctan2(unique_displacements[:, 0], unique_displacements[:, 1])
            unique_delta = np.minimum(np.abs(unique_orientations - last_orientation),
                                      2 * np.pi - np.abs(unique_orientations - last_orientation))
            unique_delta = np.minimum(unique_delta * continuity, 0.5 * np.pi)
            unique_cosinedistweights = np.maximum(np.cos(unique_delta), 0) ** 2
            geom = (unique_coords, unique_orientations, unique_cosinedistweights)
        _GEOM_CACHE[key] = geom
    if geom[0] is None:
        return None, None, None, None
    unique_coords, unique_orientations, unique_cosinedistweights = geom
    inverted = 1 - mask[unique_coords[:, 0], unique_coords[:, 1]]
    pmf = np.multiply(np.array([inverted]), unique_cosinedistweights)
    total = np.sum(pmf)
    if total < 1e-4:
        return None, None, None, None
    pmf = pmf / total
    cmf = np.cumsum(pmf)
    return unique_coords, unique_orientations, cmf, pmf


if os.environ.get("PF_NO_CACHE") != "1":
    snakes.draw_line_n_mask = draw_line_n_mask_cached
    snakes.get_coords_cmf = get_coords_cmf_cached


class Args:
    """snakes2_wrapper.py settings, then the LRA Pathfinder32 customisations."""
    def __init__(self):
        # Args defaults (snakes2_wrapper.py)
        self.contour_path = './contour'
        self.batch_id = 0
        self.n_images = 0
        self.LABEL = 1
        self.max_target_contour_retrial = 4
        self.max_distractor_contour_retrial = 4
        self.max_paddle_retrial = 2
        self.pause_display = False
        self.save_images = False
        self.save_metadata = False
        # wrapper overrides that LRA does not customise
        self.use_single_paddles = False
        self.segmentation_task = False
        self.segmentation_task_double_circle = False
        # LRA Pathfinder32 customisations
        self.paddle_margin_list = [1]
        self.window_size = [32, 32]
        self.padding = 1
        self.paddle_length = 2
        self.marker_radius = 1.5
        self.contour_length = 14
        self.paddle_thickness = 0.5
        self.antialias_scale = 2
        self.seed_distance = 7
        self.continuity = 1.0
        self.distractor_length = self.contour_length // 3
        self.num_distractor_snakes = 20 // self.distractor_length
        self.snake_contrast_list = [2]
        self.paddle_contrast_list = [0.75]


def generate(args, n_images):
    """The body of snakes2.from_wrapper, returning arrays instead of writing PNG files."""
    images, labels = [], []
    iimg = 0
    while iimg < n_images:
        label = np.random.randint(low=0, high=2)
        num_possible_margins = len(args.paddle_margin_list)
        margin_index = np.random.randint(low=0, high=num_possible_margins) if num_possible_margins > 0 else 0
        margin = args.paddle_margin_list[margin_index]
        base_num_paddles = 150
        num_paddles_factor = 1. / ((7.5 + 13 * margin + 4 * margin * margin) / 123.5)
        total_num_paddles = int(base_num_paddles * num_paddles_factor)
        small_dilation_structs = snakes.generate_dilation_struct(margin)
        large_dilation_structs = snakes.generate_dilation_struct(margin * args.antialias_scale)
        success = False
        while not success:
            twosnakes, mask, origin_tips, terminal_tips, success = snakes2.two_snakes(
                args.window_size, args.padding, args.seed_distance,
                args.contour_length, args.paddle_length, args.paddle_thickness, margin, args.continuity,
                small_dilation_structs, large_dilation_structs,
                args.snake_contrast_list, args.paddle_contrast_list,
                args.max_paddle_retrial, args.antialias_scale,
                display_snake=False, display_segment=False,
                allow_shorter_snakes=False, stop_with_availability=None)
        image = np.maximum(twosnakes[0], twosnakes[1])
        if args.num_distractor_snakes > 0:
            image, mask = snakes.make_many_snakes(
                image, mask, args.num_distractor_snakes, args.max_distractor_contour_retrial,
                args.distractor_length, args.paddle_length, args.paddle_thickness, margin, args.continuity,
                args.snake_contrast_list, args.max_paddle_retrial, args.antialias_scale,
                display_final=False, display_snake=False, display_segment=False,
                allow_incomplete=True, allow_shorter_snakes=False, stop_with_availability=0.01)
        if image is None:
            continue
        if args.use_single_paddles is not False:
            raise RuntimeError("single paddles are not used for Pathfinder32")
        origin_mark_idx = np.random.randint(0, 2)
        terminal_mark_idx = 1 - origin_mark_idx if label == 0 else origin_mark_idx
        origin_circle = snakes2.draw_circle(args.window_size, origin_tips[origin_mark_idx],
                                            args.marker_radius, args.antialias_scale)
        terminal_circle = snakes2.draw_circle(args.window_size, terminal_tips[terminal_mark_idx],
                                              args.marker_radius, args.antialias_scale)
        markers = np.maximum(origin_circle, terminal_circle).astype(np.float32) / 255.0
        image_marked = np.maximum(image, markers)
        images.append(bytescale(image_marked))      # what scipy.misc.imsave wrote to the PNG
        labels.append(label)
        iimg += 1
    return np.stack(images), np.array(labels, dtype=np.int8)


def main():
    wid, n, out = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
    seed = BASE_SEED + 1000 * wid
    np.random.seed(seed)
    random.seed(seed)
    t0 = time.time()
    X, y = generate(Args(), n)
    np.savez_compressed(out, X=X, y=y, seed=seed)
    print(f"worker {wid}: {n} images in {time.time() - t0:.1f} s, positives {y.mean():.3f}", flush=True)


if __name__ == "__main__":
    main()
