"""Exploratory: attention statistics of the untrained models on the retrieval task (seed 0, validation data).

For each variant, at initialisation: median over queries of the logit spread (SD over keys of the attention logits:
s/sqrt(rt) for signed scoring, tau log s for positive scoring), the effective key count, and the attention of the
query token on the matching key.  Output: explore/init_stats.json
"""
import os
import json
import numpy as np
import jax
import jax.numpy as jnp
import p2lib as L
import p2_run as R

data = L.load_task("retrieval")
X, pos = data["Xva"][:500], data["posva"][:500]
out = {}
for v in L.VARIANTS:
    if v == "U":
        continue
    cfg = L.default_cfg(n_classes=10, readout="first", **R.ARCH)
    cfg.update(variant=v)
    params = L.init_params(cfg, jax.random.PRNGKey(0))
    xp = jnp.asarray(L.patchify(X, 4))
    _, attns, toks = L.forward(params, xp, cfg, return_attn=True)
    row = {}
    for li in range(cfg["layers"]):
        blk = params["blocks"][li]
        Z = toks[li]
        Y = Z if v == "S" else L.pos_tokens(Z)
        Bq, Aq, Bk, Ak = L.qk_factors(blk, v)
        Q = L.kron_map(Bq, Y, Aq)
        K = L.kron_map(Bk, Y, Ak)
        B, H, N = Q.shape[0], Q.shape[1], Q.shape[2]
        s = jnp.einsum('bhiuv,bhjuv->bhij', Q, K)
        logits = s / np.sqrt(16.0) if v in ("S", "Sp") else jnp.log(s)
        a = np.asarray(attns[li])
        eff = np.exp(-(a * np.log(np.maximum(a, 1e-30))).sum(-1))
        row[f"layer{li}"] = {"logit_spread_median": float(np.median(np.asarray(logits).std(-1))),
                             "eff_keys_median": float(np.median(eff)),
                             "query_match_mass_median": float(np.median(a[np.arange(B), :, 0, pos]))}
    out[v] = row
    print(v, row, flush=True)
os.makedirs("explore", exist_ok=True)
json.dump(out, open(os.path.join("explore", "init_stats.json"), "w"), indent=1)
