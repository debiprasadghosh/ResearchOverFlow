# Positive Kronecker Attention with Dependency Control

**Debi Prasad Ghosh**

Debias Parametric Guru, Kolkata, India | debiprasadghosh@gmail.com

5 October 2026 · P2 of the log interval network programme · Pre-specified protocol executed, with reproducible scripts

---

**Abstract.** Paper II proposed a positive operating point for Kronecker-factored attention (YAKAL) in a logarithmic number system. Positive tokens and factors make every score a positive polynomial in the factors, and attention $a_{ij}\propto s_{ij}^{\tau}$ consumes the stored log score without conversion. For this point Paper II registered three things:

- a comparison with signed YAKAL on LRA-Image and Pathfinder at matched budgets;
- a certification target: total variation (TV) at most 0.1 for 95% of held-out queries when every factor entry may move by a factor $e^{\pm0.02}$;
- a rejection rule: more than two points of accuracy lost against the signed control, or the target missed at equal cost.

Paper II's closed-form bound $\tanh(2\tau\rho)$ ignores that all scores share the same four factors. Every positive Kronecker score is a log-sum-exp of affine functions of the factor log perturbations, and each of its monomials uses one entry of every factor. From this we show that Paper II's relative score variation equals $\tau\rho D_i\pm8\tau\rho^2$, where $D_i$ is the largest $\ell_1$ distance between the keys' factor-mass distributions. Two further bounds weight each key's exposure by its attention. On the confirmatory models, the best explicit perturbation found for a query reached 0.39–0.66 of its certificate in the median. A repeat of Paper II's random-token check showed that most of the score spread of dense tokens was token gain, which the box cannot move.

We ran the comparison with six variants: the four that Paper II named, the encoding baseline it asked for, and an attention-free control that we added. We also added a content-retrieval task on which attention is necessary.

- **LRA-Image** (five seeds). The positive variants met both of Paper II's criteria: they were 3.1–4.7 points more accurate than signed attention (46.3%), and every query was certified. But the attention-free control was more accurate still (52.4%). The task therefore fails the validity gate of our protocol, and we do not count it as support. Positive attention stayed nearly uniform.
- **Pathfinder.** No model left chance at about 1% of LRA's training examples, so the confirmatory runs were cut to the signed and attention-free controls.
- **Retrieval** (five seeds). Signed scoring reached 99.4%, and the positive variants averaged 17–20%. The operating point is therefore rejected on the one task that tested attention.

In exploratory runs with three times the steps, sparse positive pools did learn retrieval (85–98%), with nearly hard pools and temperatures of 24–35. Those models miss the target, and explicit perturbations show that the miss is real: the attention of 12.5–32.5% of their decision queries moved by more than 0.1. Signed attention fared no better under the same box: in the retrieving head of the signed control (seed 0), 60% of sampled queries moved by more than 0.1. Positive attention was certifiable when it pooled and not when it selected, and signed attention missed the target on both tasks.

**Keywords** Kronecker attention; logarithmic number system; positive networks; weight-perturbation certificates; total variation; linear attention; Long Range Arena

# 1 Introduction

Paper II [2] proposed log interval networks: positive computation in a logarithmic number system (LNS), in which every stored quantity carries a log interval and decisions can be checked against a box of tolerated parameters. P1 [3] tested the calculus on readouts and evidence accumulation. This paper, P2, tests it on attention.

**The question.** YAKAL [4] factors the query and key maps of matrix tokens as Kronecker products and scores them in a signed LNS. Signed scores have two costs.

- **Cancellation.** They cancel, so a certified width is multiplied by the cancellation factor κ.
- **Conversion.** Each score must leave the log domain before softmax.

Paper II proposed a positive operating point that has neither cost. With positive tokens, positive factors and attention $a_{ij}\propto s_{ij}^{\tau}$:

- each score is a positive polynomial in the factors;
- each logit is $\tau\log s_{ij}$, which the LNS already stores.

It registered three things for this point:

- **A comparison.** Signed YAKAL against positive YAKAL at τ = 1, learned τ, and sparse positive pools, on LRA-Image and Pathfinder [6] at matched budgets.
- **A target.** Total variation (TV) at most 0.1 for 95% of held-out queries when every factor entry may move by a factor $e^{\pm0.02}$.
- **A rejection rule.** An accuracy loss of more than two points against the signed control, or the target missed at equal cost.

It also named the obstacle. Its closed-form bound $\tanh(2\tau\rho)$ treats every score as independently uncertain, although all scores share the same four factors. In its check L10 the bound was 15–81 times the largest change produced by random members of the box. The sharper target, the relative score variation $\Omega_i$, was left as "a new optimization problem".

**Contributions.**

1. **$\Omega_i$ computed, and distribution-aware certificates (Section 3).**
   - Every positive Kronecker score is a log-sum-exp of affine functions of the factor log perturbations, and each of its monomials uses one entry of every factor.
   - Hence $\Omega_i=\tau\rho D_i\pm8\tau\rho^2$, where $D_i$ is the largest $\ell_1$ distance between the keys' *factor-mass distributions*. A sign vertex reaches at least the lower end.
   - Two further bounds weight each key's exposure by its attention.
   - On the confirmatory models, the best witness found for a query reached 0.39–0.66 of its certificate in the median, and 0.24–0.86 in the median of single heads. For a typical query the certificate therefore exceeds the true worst case by at most a factor of 1.5–2.6. Equation 11 was 5.7–29 times the median witness.
   - Token gain separates scores without exposing them, while content separates them by exposing them. The repetition of L10 with token mass normalised, which Paper II registered (Section 5), shows how much of the earlier picture was gain.
2. **The registered comparison (Sections 4, 6, 8).** At matched budgets:
   - six variants with five seeds each on LRA-Image and on an added content-retrieval task, on which attention is necessary by construction;
   - on Pathfinder-32, regenerated with the original generator, only the signed and attention-free controls with two seeds, because every variant stayed at chance in the pilot.

   The variants are signed YAKAL, signed scoring on positive tokens (the encoding baseline that Paper II asked for), positive YAKAL at τ = 1, learned τ, sparse positive pools, and an attention-free control that we added.
3. **The verdict (Section 8).** The registered operating point is **rejected** on the one task where attention mattered, and no task that tests attention supports it.
   - **LRA-Image.** The positive variants met both of Paper II's criteria. They beat signed attention by 3–5 points, and every query was certified. But the attention-free control was the most accurate model, so the task fails the validity gate that our protocol had set before the LRA-Image pilot, and we do not count it as support. Read by Paper II's rule alone, it would count. Positive attention stayed nearly uniform.
   - **Pathfinder.** No model left chance at our budget, about 1% of the training examples of LRA's own runs.
   - **Retrieval.** Signed scoring reached 99.4%. Every positive variant averaged below 20%.
4. **What selection costs (Section 7, exploratory).**
   - **Learning.** With three times the steps and a larger learning rate, sparse positive pools did learn the retrieval task (85–98%). They did it with nearly hard pools and temperatures of 24–35, about twice the 13.8 of the one 4×4-token model that learned.
   - **Certification.** Those models miss the certification target, and not because of looseness. Explicit factor perturbations in the box moved the attention of 12.5–32.5% of decision queries by more than 0.1. Positive attention was certifiable where it did not select, and not where it did.
   - **Signed attention.** Under the same box, signed attention also missed the target, on both tasks. In the head of the signed control that retrieves, 60% of sampled queries moved by more than 0.1. The target is out of reach for selective attention under either sign. What positivity cost here was learning to select within the budget.

**Related work.**

- **Linear attention.** Positive feature maps make linear-time attention possible [11]. Linear attention is known to struggle with associative recall [22], which our retrieval task resembles.
- **Robustness certificates.** Certificates for transformers usually bound input perturbations [21]. Certificates for weight perturbations exist for feed-forward networks [19, 20].
- **This work.** The factor box studied here is a weight perturbation shared by all scores. Its dependence structure is what Section 3 exploits. Interval arithmetic [18] would treat the scores as independent, which is Equation 11.

# 2 Setting

**Matrix tokens and Kronecker projections.** YAKAL [4] keeps each token as a matrix $X\in\mathbb R^{p\times q}$, the matrix-token view of [5], and replaces the dense query, key and value maps by Kronecker-structured ones:

$$
(A\otimes B)\,\mathrm{vec}(X)=\mathrm{vec}(BXA^{\top}),\qquad B\in\mathbb R^{r\times p},\;A\in\mathbb R^{t\times q}.
$$

A dense map from $pq$ to $rt$ coordinates has $rtpq$ parameters. The factored map has $rp+tq$ and costs $O(rpq+rqt)$ per token. The score of query $i$ for key $j$ is the Frobenius inner product $\langle Q_i,K_j\rangle_F$ of their $r\times t$ projections.

YAKAL computes this score in a signed logarithmic number system (LNS), as LNS networks do generally [23]. Each product is a sign and a log magnitude, and the positive and negative partial sums are formed separately by log-sum-exp and then subtracted [4, §4.3]. Paper II [2] made two observations about this pipeline.

- **Cancellation.** A signed sum multiplies the certified relative width of its result by $\kappa=(\Sigma_++\Sigma_-)/\lvert\Sigma_+-\Sigma_-\rvert$, where $\Sigma_+$ and $\Sigma_-$ are the positive and negative partial sums.
- **Conversion.** Softmax [10] needs the numerical score as its logit, so a stored sign-and-log score needs one inverse-log conversion per score before normalisation.

**Positive Kronecker attention.** Paper II therefore proposed the operating point studied here.

- **Ingredients.** Positive tokens, positive factors, and attention as a power of the score:
  $$
  Q_i=B_qY_iA_q^{\top},\quad K_j=B_kY_jA_k^{\top},\quad s_{ij}=\langle Q_i,K_j\rangle_F>0,\quad a_{ij}=\frac{s_{ij}^{\tau}}{\sum_ks_{ik}^{\tau}} .
  $$
- **No conversion.** $\log a_{ij}=\tau\log s_{ij}-\mathrm{LSE}_k(\tau\log s_{ik})$ consumes the stored log score directly.
- **τ = 1.** This is linear attention with positive features [11], with a cost linear in the number of keys (Proposition 6).
- **Exact score ranges.** Every score is a positive polynomial in the factor entries, so its range over a box of factor values is attained at two corners [1, 2].

**The factor box and the certificate.** A factor box of log radius $\rho$ lets every factor entry move by a factor in $[e^{-\rho},e^{\rho}]$, independently. It models what an LNS store does to its weights: a log quantiser of step $2\rho$ moves each stored log weight by at most $\rho$ [2, 3]. It also models any other relative tolerance on the weights.

The certified quantity is the largest total-variation distance between the attention of any model in the box and that of the nominal model, $\sup_\theta\mathrm{TV}(a_i(\theta),a_i^0)$. Each attention layer is taken at its nominal input tokens, as Paper II specifies. A bound on this distance says how far any query's attention distribution can move. It is not a statement about the decision.

Paper II gave the closed-form bound $\tanh(2\tau\rho)$ (its Equation 11) and observed that it is loose. In its check L10, with $\rho=0.02$ and $\tau=4$, the bound was 0.15865, while the largest TV among 300 random members of the box was 0.002–0.011. The reason is that the four factors are shared by all scores. Raising every factor entry by $e^{\rho}$ attains every upper score bound at once, but it shifts every logit by the same amount and leaves the attention unchanged. Paper II proposed the relative score variation $\Omega_i$ (its Equation 12) as the sharper target and called its computation "a new optimization problem". Section 3 solves it to second order.

**What Paper II registered for P2.**

- **Comparisons.** Signed YAKAL, positive YAKAL at τ = 1, learned τ, and sparse positive pools, on LRA-Image and Pathfinder [6] at matched budgets.
- **Measurements.** Accuracy, token size, log-score spread, concentration-normalised spread, effective key count, $\Omega_i$ bounds and measured latency.
- **Baselines.** A representational baseline for the positive token encoding. The dense-versus-sparse L10 check repeated with token mass normalised outside the uncertain computation.
- **Target.** TV at most 0.1 for at least 95% of held-out queries at factor log radius 0.02, frozen before testing.
- **Rejection.** The operating point is rejected if accuracy falls more than two points below the matched signed control, or if the TV target cannot be met at equal cost.
- **Diagnostic.** Growth of τ like $\sqrt{pq}$ diagnoses failure of Equation 11 without refuting a correlated certificate.
- **Fallback.** Accurate signed scoring with certified value or expert ranges.

Section 4 states how each item was executed.

# 3 What a factor box does to positive attention

Throughout, one attention head is fixed at its nominal input. The query token $Y_i$ and the key tokens $Y_1,\dots,Y_N$ are positive $p\times q$ matrices. The four factors $\theta=(B_q,A_q,B_k,A_k)$ are positive, with $B_q,B_k\in\mathbb R^{r\times p}$ and $A_q,A_k\in\mathbb R^{t\times q}$, and

$$
s_{ij}=\langle B_qY_iA_q^{\top},\,B_kY_jA_k^{\top}\rangle_F,\qquad a_{ij}=\frac{s_{ij}^{\tau}}{\sum_ks_{ik}^{\tau}} .
$$

The **factor box** of log radius $\rho$ multiplies every one of the $P=2(rp+tq)$ factor entries by $e^{d_l}$, with $|d_l|\le\rho$ chosen independently: $\theta=\theta^0\circ e^{d}$, $d\in[-\rho,\rho]^P$. Write $\ell_{ij}(d)=\log s_{ij}(\theta^0\circ e^{d})$, $\mathrm{TV}(a,b)=\tfrac12\lVert a-b\rVert_1$, and $a_i^0$ for the nominal attention of query $i$.

**Proposition 1 (structure of positive Kronecker scores).**

- **(a) Gram form.** With column-major vectorisation, $s_{ij}=\mathrm{vec}(Y_i)^{\top}M\,\mathrm{vec}(Y_j)$, where $M=(A_q^{\top}A_k)\otimes(B_q^{\top}B_k)$ and $\operatorname{rank}M\le rt$. $M$ is a symmetric positive semidefinite Gram matrix when the query and key factors are tied. Positive factors alone guarantee neither symmetry nor semidefiniteness: with $B_q=\bigl[\begin{smallmatrix}1&0.1\\0.1&1\end{smallmatrix}\bigr]$, $B_k=\bigl[\begin{smallmatrix}0.1&1\\1&0.1\end{smallmatrix}\bigr]$ and $q=t=1$, $A_q=A_k=1$, the matrix $M=B_q^{\top}B_k=\bigl[\begin{smallmatrix}0.2&1.01\\1.01&0.2\end{smallmatrix}\bigr]$ is symmetric with eigenvalues $-0.81$ and $1.21$.
- **(b) One entry of every factor per monomial.** Expanding,
  $$
  s_{ij}=\sum_{u,v,a,b,c,e}B_q[u,a]\,A_q[v,b]\,B_k[u,c]\,A_k[v,e]\;Y_i[a,b]\,Y_j[c,e],
  $$
  a sum of positive monomials, each containing exactly one entry of each factor. Hence $\ell_{ij}$ is a log-sum-exp of affine functions of $d$. It is convex, and its gradient at $d=0$ is the **factor-mass vector** $G_{ij}=(\mu^{B_q}_{ij},\mu^{A_q}_{ij},\mu^{B_k}_{ij},\mu^{A_k}_{ij})$. Here $\mu^{F}_{ij}[l]$ is the share of $s_{ij}$ carried by the monomials that contain entry $l$ of factor $F$. Each of the four blocks is a probability distribution, and
  $$
  \mu^{B_q}_{ij}=\frac{B_q\circ(K_jA_qY_i^{\top})}{s_{ij}},\quad \mu^{A_q}_{ij}=\frac{A_q\circ(K_j^{\top}B_qY_i)}{s_{ij}},\quad \mu^{B_k}_{ij}=\frac{B_k\circ(Q_iA_kY_j^{\top})}{s_{ij}},\quad \mu^{A_k}_{ij}=\frac{A_k\circ(Q_i^{\top}B_kY_j)}{s_{ij}},
  $$
  with $Q_i=B_qY_iA_q^{\top}$ and $K_j=B_kY_jA_k^{\top}$.
- **(c) Query-side masses are garblings of bin masses.** Let $\pi_{ij}(u,v)=Q_i[u,v]K_j[u,v]/s_{ij}$, the share of the score in pooled bin $(u,v)$. Then $\mu^{B_q}_{ij}[u,a]=\sum_v\pi_{ij}(u,v)\,\nu_i(a\mid u,v)$, where $\nu_i(a\mid u,v)=B_q[u,a](Y_iA_q^{\top})[a,v]/Q_i[u,v]$ depends on the query only. Therefore $\lVert\mu^{B_q}_{ij}-\mu^{B_q}_{ik}\rVert_1\le\lVert\pi_{ij}-\pi_{ik}\rVert_1$, and likewise for $A_q$. The key-side masses mix the same bin masses through kernels that depend on the key.

*Proof.* (a) is the identity $\mathrm{vec}(BYA^{\top})=(A\otimes B)\mathrm{vec}(Y)$. The rank bound holds because $\operatorname{rank}(A_q^{\top}A_k)\le t$ and $\operatorname{rank}(B_q^{\top}B_k)\le r$, and tying makes both Kronecker factors Gram matrices. The example is checked numerically (T1). (b) The expansion is direct. For $\ell(d)=\log\sum_mc_me^{E_m\cdot d}$ with $c_m>0$ and $E_m\in\lbrace 0,1\rbrace^P$, $\nabla\ell=\sum_m\pi_mE_m$ with $\pi_m=c_me^{E_m\cdot d}/s$, which at $d=0$ is the vector of mass shares. Every monomial has exactly one entry of each factor, so the shares within one factor sum to one. The four closed forms collect the monomials that contain a given entry. (c) Write $\mu^{B_q}_{ij}[u,a]$ as a sum over $v$ of the monomials that contain $B_q[u,a]$, and divide by $Q_i[u,v]$. A Markov kernel cannot increase the $\ell_1$ distance between two distributions. ∎

The first point is the score's geometry: it compares the query and the key after pooling each into $rt$ positive bins. The second point is what the factor box acts on. A perturbation $d$ changes $\log s_{ij}$ by $G_{ij}\cdot d$ to first order, so two keys whose scores are carried by the same factor entries in the same proportions move together, whatever their scores are.

**Proposition 2 (the independent score box and Paper II's Equation 11).**

- **(a)** For every $\theta$ in the box, $e^{-4\rho}\le s_{ij}(\theta)/s_{ij}(\theta^0)\le e^{4\rho}$. Both bounds are attained, for all pairs at once, at the corners $\theta^0e^{\pm\rho}$.
- **(b)** $\mathrm{TV}(a_i(\theta),a_i^0)\le\tanh(2\tau\rho)$.
- **(c)** At the two corners of (a), every logit $\tau\log s_{ij}$ moves by the same $\pm4\tau\rho$, so $a_i(\theta)=a_i^0$.

*Proof.* (a) Every monomial is a product of four factor entries, so it moves by a factor between $e^{-4\rho}$ and $e^{4\rho}$, and a positive sum of such terms stays within the same range. At a corner every monomial moves by exactly $e^{\pm4\rho}$. (b) follows from (a) and Proposition 3 with $\Omega\le8\tau\rho$. (c) is immediate, because softmax ignores a common shift of its logits. ∎

The score box is exact for each score, but the corners that attain it are invisible to attention. Equation 11 is reached only if some keys rise by $4\tau\rho$ while others fall by $4\tau\rho$. The shared factors allow that only for keys whose scores use disjoint factor entries (Proposition 4(c)), which strictly positive tokens and factors never quite do.

**Proposition 3 (spread bound).** Let $z,e\in\mathbb R^N$ and $\Omega=\max_je_j-\min_je_j$. Then $\mathrm{TV}(\mathrm{softmax}(z+e),\mathrm{softmax}(z))\le\tanh(\Omega/4)$. Equality holds for two keys with nominal masses $m^{\ast}=1/(1+e^{\Omega/2})$ and $1-m^{\ast}$ and $e=(\Omega,0)$. Over an independent box $e_j\in[l_j,h_j]$, the largest TV is $\max_S\bigl[U_S/(U_S+L_{S^c})-a_S\bigr]$, where $U_S=\sum_{j\in S}a_je^{h_j}$ and $L_{S^c}=\sum_{j\notin S}a_je^{l_j}$. When every key has the same interval $[l,h]$, it is $\max_Sf(a_S)$ with $f$ below and $\Omega=h-l$, so it depends on which subset masses $a_S$ are available. It never exceeds $\tanh(\Omega/4)$ with $\Omega=\max_jh_j-\min_jl_j$.

*Proof.* Shift $e$ so that it lies in $[0,\Omega]$. $\mathrm{TV}=\max_S(a'_S-a_S)$. For fixed $S$, $a'_S$ is increasing in $e_j$ for $j\in S$ and decreasing for $j\notin S$, so the worst case puts $S$ at $\Omega$ and the rest at $0$, giving $f(a_S)$ with $f(m)=me^{\Omega}/(me^{\Omega}+1-m)-m$. $f$ is maximised at $m^{\ast}$, with $f(m^{\ast})=(e^{\Omega/2}-1)/(e^{\Omega/2}+1)=\tanh(\Omega/4)$. The box statement repeats the argument with endpoints $h_j$ and $l_j$. ∎

For the attention *output* over an interval-logit box, the extreme values are attained at a sorted switch point (Karnik and Mendel [14]; [1, §5.2]). The total-variation problem has no such ordering. When all keys share one interval, the best up-set is the subset whose mass maximises the unimodal function $f$ above, which peaks at $m^{\ast}$. That is a question about subset sums, not about the order of the keys.

Paper II's Equation 12 replaces the box half-width $4\tau\rho$ by the relative score variation $\Omega_i=\sup_\theta[\max_j\delta_{ij}-\min_j\delta_{ij}]$, $\delta_{ij}=\tau\log(s_{ij}/s^0_{ij})$, and then TV $\le\tanh(\Omega_i/4)$ by Proposition 3. Proposition 3 also says that an exact threshold solve on the independent score box cannot do better than Equation 11 by more than subset granularity allows. Any real gain has to come from the dependence between scores. The next proposition computes $\Omega_i$ to second order.

**Proposition 4 (relative score variation).** For keys $j,k$ let $R_{jk}(d)=[\ell_{ij}(d)-\ell_{ij}(0)]-[\ell_{ik}(d)-\ell_{ik}(0)]$, and let $D_i=\max_{j,k}\lVert G_{ij}-G_{ik}\rVert_1$.

- **(a) Sandwich.** For every $d$ in the box, $\lvert R_{jk}(d)-(G_{ij}-G_{ik})\cdot d\rvert\le8\rho^2$. Hence
  $$
  \tau(\rho D_i-8\rho^2)\;\le\;\Omega_i\;\le\;\tau(\rho D_i+8\rho^2),
  $$
  and for a maximising pair $(j^{\ast},k^{\ast})$ the sign vertex $d^{\ast}=\rho\,\mathrm{sign}(G_{ij^{\ast}}-G_{ik^{\ast}})$ reaches at least the lower bound. Therefore $\mathrm{TV}(a_i(\theta),a_i^0)\le\tanh\bigl(\min(\tau(\rho D_i+8\rho^2),8\tau\rho)/4\bigr)$.
- **(b) Vertices and single factors.** $\sup_dR_{jk}(d)$ is attained at a vertex of the box. Over the entries of a single factor, with the other three fixed, $s_{ij}/s_{ik}$ is a ratio of two positive linear forms, maximised exactly by a threshold rule on the ratios of their coefficients.
- **(c) Extremes.** $0\le D_i\le8$. $D_i$ approaches 8 only when two keys load nearly disjoint entries of every factor. With strictly positive tokens and factors every monomial carries some mass, so $D_i<8$. When the supports are exactly disjoint, which needs zero entries, $\Omega_i=8\tau\rho$ exactly. If $Y_j=cY_k$ for a scalar $c>0$, then $R_{jk}\equiv0$: token gain spreads the scores without exposing them to the box.

*Proof.* (a) By Proposition 1(b), $\ell=\ell_{ij}$ is convex, so $\ell(d)\ge\ell(0)+G_{ij}\cdot d$. Its Hessian is the covariance of $E_m$ under $\pi(d)$, so $d^{\top}\nabla^2\ell\,d=\mathrm{Var}_{\pi}(E_m\cdot d)$. $E_m\cdot d$ is a sum of four coordinates of $d$ and lies in $[-4\rho,4\rho]$, so this variance is at most $(8\rho)^2/4=16\rho^2$. Taylor's theorem with integral remainder then gives $\ell(d)\le\ell(0)+G_{ij}\cdot d+8\rho^2$. Subtracting the corresponding bounds for $k$ gives the sandwich. Maximising $(G_{ij}-G_{ik})\cdot d$ over the box gives $\rho\lVert G_{ij}-G_{ik}\rVert_1$, attained at the sign vertex, where $R_{jk}$ is therefore at least $\rho\lVert G_{ij}-G_{ik}\rVert_1-8\rho^2$. Finally $\Omega_i=\tau\max_{j,k}\sup_dR_{jk}(d)$. The TV bound is Proposition 3, capped by Equation 11. (b) Each score is linear in the entries of any one factor. A ratio of positive linear forms over a box is maximised at a vertex, where the entries whose coefficient ratio exceeds the optimal value go up and the rest go down (Dinkelbach [13]). Moving one factor at a time to such a vertex never decreases $R_{jk}$. (c) Each block of $G$ is a probability vector, so its $\ell_1$ distance is at most 2, with equality exactly for disjoint supports. With disjoint supports in every factor (the limit of zero entries), $d$ equal to $+\rho$ on the entries of $j$ and $-\rho$ on those of $k$ multiplies every monomial of $s_{ij}$ by $e^{4\rho}$ and every monomial of $s_{ik}$ by $e^{-4\rho}$. Scaling $Y_j$ scales every monomial of $s_{ij}$ by $c$ for every $d$. ∎

The gap between the two sides of (a) is $16\tau\rho^2$, about $0.0064\,\tau$ at $\rho=0.02$, so at the registered radius $\Omega_i$ is known to within a few thousandths of a nat per unit of $\tau$. Computing it costs $O(N^2P)$ per query. Paper II listed pairwise log-score bounds, tied-factor relaxations and low-dimensional branch refinement as candidates for this "new optimization problem". At the radii that matter, the convexity of $\ell$ and the bounded curvature of a log-sum-exp settle it without them.

**Proposition 5 (certificates that use the attention distribution).** Let $\bar g_i=\sum_ja^0_{ij}G_{ij}$, $w_{ij}=\lVert G_{ij}-\bar g_i\rVert_1$, and $\gamma_i=\min\bigl(\tau(\rho\max_jw_{ij}+8\rho^2),\,8\tau\rho\bigr)$. For every $\theta$ in the box:

- **(a) Bennett–Pinsker.**
  $$
  \mathrm{TV}(a_i(\theta),a_i^0)\le\sqrt{\psi(\gamma_i)/2}\;\tau\Bigl(\rho\bigl(\textstyle\sum_ja^0_{ij}w_{ij}^2\bigr)^{1/2}+4\rho^2\Bigr),\qquad \psi(x)=\frac{e^x-1-x}{x^2};
  $$
- **(b) $\ell_1$ bound.**
  $$
  \mathrm{TV}(a_i(\theta),a_i^0)\le\phi(\gamma_i)\,\frac{\tau}{2}\Bigl(\rho\textstyle\sum_ja^0_{ij}w_{ij}+8\rho^2\Bigr),\qquad \phi(x)=\frac{e^x-1}{x}.
  $$

*Proof.* Let $e_j=\tau(\ell_{ij}(d)-\ell_{ij}(0))=\tau(G_{ij}\cdot d+r_j)$, where $0\le r_j\le8\rho^2$ by Proposition 4(a), and write $\mathbb E$ and $\mathrm{Var}$ for moments under $a_i^0$. Let $\eta_j=e_j-\mathbb Ee$. Since $\sum_ja^0_{ij}(G_{ij}-\bar g_i)=0$, $\eta_j=\tau[(G_{ij}-\bar g_i)\cdot d+(r_j-\bar r)]$. Hence $\eta_j\le\tau(\rho w_{ij}+8\rho^2)$. Also $\eta_j\le\max_ke_k-\min_ke_k\le8\tau\rho$, so $\eta_j\le\gamma_i$ for every $j$.

(a) $\mathrm{KL}(a_i^0\Vert a_i(\theta))=\log\mathbb Ee^{\eta}$. Because $(e^y-1-y)/y^2$ is increasing, $e^y\le1+y+y^2\psi(\gamma_i)$ for $y\le\gamma_i$ (Bennett's argument [15]), so $\mathrm{KL}\le\mathrm{Var}(\eta)\psi(\gamma_i)$. By Minkowski's inequality in $L^2(a_i^0)$, $\mathrm{Var}(\eta)^{1/2}\le\tau\rho(\sum_ja^0_{ij}w_{ij}^2)^{1/2}+\tau\,\mathrm{sd}(r)$, and $\mathrm{sd}(r)\le4\rho^2$ because $r$ lies in an interval of length $8\rho^2$. Pinsker's inequality [16], $\mathrm{TV}\le\sqrt{\mathrm{KL}/2}$, completes (a).

(b) $a_{ij}(\theta)=a^0_{ij}e^{e_j-\Lambda}$ with $\Lambda=\log\mathbb Ee^{e}\ge\mathbb Ee$ by Jensen's inequality. So $\mathrm{TV}=\sum_ja^0_{ij}(e^{e_j-\Lambda}-1)^+\le\sum_ja^0_{ij}(e^{\eta_j}-1)^+$. For $0\le y\le\gamma_i$, $e^y-1\le\phi(\gamma_i)\,y$ by convexity. Hence $\mathrm{TV}\le\phi(\gamma_i)\sum_ja^0_{ij}\eta_j^+=\tfrac12\phi(\gamma_i)\,\mathbb E\lvert\eta\rvert$, because $\mathbb E\eta=0$. Finally $\mathbb E\lvert\eta\rvert\le\tau(\rho\sum_ja^0_{ij}w_{ij}+8\rho^2)$. ∎

To first order in $\rho$, the exact worst case is $\tfrac{\tau\rho}{2}\max_{\sigma\in\lbrace\pm1\rbrace^P}\sum_ja^0_{ij}\lvert(G_{ij}-\bar g_i)\cdot\sigma\rvert$. This is a cut-norm-type quantity, and Alon and Naor [17] treat the general problem. Proposition 5(b) replaces it by $\tfrac{\tau\rho}{2}\sum_ja^0_{ij}w_{ij}$, which lets every key choose its own worst sign pattern. Proposition 5(a) pays for the decoupling as well, and also for the gap between a mean absolute deviation and a standard deviation. Both bounds weight each key by its nominal attention. A key with no attention cannot move the distribution much, however exposed its score is. Both also carry a second-order term, of order $\tau\rho^2$, that does not shrink with the first-order exposure; where that exposure is tiny, this term dominates the bound.

**What the evaluator computes.** Computing $D_i$ exactly costs $O(N^2P)$ per query, so the evaluator uses two cheaper upper bounds on it. Each $G_{ij}$ is within $w_{ij}$ of $\bar g_i$, so $D_i\le2\max_jw_{ij}$. And $D_i\le\sum_l\mathrm{range}_l$, where $\mathrm{range}_l=\max_jG_{ij}[l]-\min_jG_{ij}[l]$ is the range over keys of coordinate $l$. With $\bar D_i=\min(2\max_jw_{ij},\sum_l\mathrm{range}_l)$, Proposition 4(a) gives $\Omega_i\le\bar\Omega_i=\min\bigl(\tau(\rho\bar D_i+8\rho^2),8\tau\rho\bigr)$. The **certificate** of a query is the smallest of Equation 11, $\tanh(\bar\Omega_i/4)$ and Proposition 5(a)–(b). The evaluator brackets the truth from below with **witnesses**: vertices $d$ found by sign iteration on the first-order objective, evaluated exactly.

**Proposition 6 (τ = 1 and linear attention).** At $\tau=1$, $\sum_ja_{ij}V_j=\langle Q_i,\sum_jK_j\otimes V_j\rangle/\langle Q_i,\sum_jK_j\rangle$, the positive-feature reassociation of linear attention [11]. The normaliser is one inner product of size $rt$, so in a logarithmic number system $\log a_{ij}=\log s_{ij}-\log\langle Q_i,\bar K\rangle$, with $\bar K=\sum_jK_j$, needs no log-sum-exp over keys and no conversion of the stored log score. For general $\tau$, $\log a_{ij}=\tau\log s_{ij}-\mathrm{LSE}_k(\tau\log s_{ik})$ also consumes the stored log score directly, but costs $O(N^2)$ per head [2].

*Proof.* Substitute $s_{ij}=\langle Q_i,K_j\rangle$ and exchange the sums. ∎

**Checks.** `verify_p2_theory.py` (seed 20261011) checks each proposition numerically in float64, on random instances and on the extreme cases the propositions name:

| Check | Propositions | Result |
|---|---|---|
| T1 | 1(a) | identity to $10^{-13}$; rank $\le rt$; non-PSD example |
| T2 | 2 | radius exactly $4.000000000000\rho$; corner TV $1.3\times10^{-15}$ |
| T3 | 3 | attainment to $10^{-12}$; exact box TV by enumeration $\le\tanh(\text{spread}/4)$ |
| T4 | 4 | sandwich holds at every sampled point ($\rho\le0.3$). The exact suprema were found by enumerating all $2^{16}$ vertices; they lie within $\pm0.17\times8\rho^2$ of $\rho\lVert G_{ij}-G_{ik}\rVert_1$ |
| T5 | 4, 5 | every certificate exceeds every evaluated vertex; the $\Omega$ witness lies inside the sandwich |
| T6 | 4(c) | gain-related keys: $R\equiv0$ to $6.5\times10^{-16}$ |
| T7 | 6 | reassociation exact to $1.9\times10^{-16}$ |
| T8 | 4(c) | disjoint pools give $D=8$ and $R=8\rho$ |
| T9 | 1(c) | data-processing inequality holds |

# 4 Protocol

The protocol in the supplement (`PROTOCOL.md`) was written before any confirmatory run and before any test example was used.

- **Amendments.** It was amended four times, each time before the affected confirmatory runs. Three amendments followed validation-only pilots, and one followed the cost of generating Pathfinder data. Table 2 lists them with the points where we departed from Paper II's plan. Analyses decided after the confirmatory results are labelled exploratory wherever they appear.
- **Freeze.** The evaluator was frozen before any test example entered a computation (SHA-256 in Appendix A). The LRA-Image and Pathfinder test files were hashed when they were first loaded. The retrieval test split did not exist before the freeze: the frozen generator created it when the frozen evaluator first asked for it.
- **Code revisions.** The LRA-Image models were trained with an earlier revision of the training code (hashes in `runs/config_image.json`), and all other models with the revision that was later frozen. Recomputing the validation accuracy of all 30 LRA-Image models with the frozen code reproduced the values recorded at training time exactly (`p2_image_code_check.py`).

## 4.1 Tasks

- **LRA-Image** [6]. CIFAR-10 [9] in grayscale, using LRA's conversion (`tf.image.rgb_to_grayscale` on 8-bit images) and LRA's split: 45,000 training, 5,000 validation and 10,000 test images. The CIFAR-10 files came from a public mirror, and their MD5 sums match the canonical values.
- **Pathfinder-32, hard** [6, 7]. The released LRA files are not reachable from our environment, so we regenerated the data. We used the original generator [8] (`drewlinsley/pathfinder`, commit 7b53886) with the 32×32 settings listed in LRA's dataset builder (contour length 14, 5 distractor snakes of length 4, paddle length 2, margin 1).
  - The repository's latest commit replaced `scipy.misc.imresize/imsave` by PIL calls that do not byte-scale floating-point images, which changes the markers and the final scaling. We restored the original semantics.
  - Two caches make generation about three times faster. For two seeds they reproduced the uncached generator and the stored shards bit for bit (`pf_cache_check.py`, 200 images per seed).
  - Generation took about 0.09 s per image, so the training set was cut from LRA's 160,000 images to 60,000. The validation and test sets keep LRA's 20,000 each.
- **Retrieval** (added task). Each example is 64 tokens of 4×4 pixels.
  - **Query.** Token 0 carries one of 8 sparse codes (3 of 12 pixels lit) and a marker.
  - **Keys and blanks.** Tokens 1–7 are keys with distinct codes, exactly one of which matches the query, and each key carries a value from 0 to 9 in four further pixels. Tokens 8–63 are blank.
  - **Label and noise.** The label is the value of the matching key. Pixel noise has standard deviation 0.1.
  - **Splits and readout.** 50,000 training, 10,000 validation and 20,000 test examples. The model reads out token 0.
  - **Reference.** A decoder that knows the codebook and the value patterns reaches 99.65% on the validation split (`retrieval_reference.py`). The protocol quotes 99.4% from a design-time check on 3,000 generated examples.
  - **Why it was added.** It was added after the LRA-Image pilot, in which the attention-free control was the most accurate variant. Attention is necessary on it by construction. A first version with 63 keys, 16 codes and noise 0.15 was abandoned when the signed control stayed at chance through its pilot.

## 4.2 Model and variants

All tasks use the same matrix-token classifier.

- **Tokens.** Non-overlapping 4×4 patches give $N=64$ tokens. A dense embedding maps each patch to an 8×8 matrix token, to which a learned positional matrix is added.
- **Blocks.** Two pre-LN blocks follow. Each has a two-head Kronecker attention ($r=t=4$ for queries and keys, $r_v=t_v=4$ for values, and a Kronecker output map back to 8×8) and an MLP of width 128.
- **Readout.** The classifier mean-pools the normalised tokens, except on the retrieval task, where it reads token 0.

The six variants differ only in how queries and keys are formed and scored (Table 1). Values are always $V_j=B_v\,\mathrm{LN}(X_j)A_v^{\top}$ with signed factors, so the comparison isolates the scoring. The positive encoding $Y=e^{\mathrm{LN}(X)}$ lies outside the uncertain computation. In an LNS it costs nothing, because its stored log is $\mathrm{LN}(X)$ itself.

**Table 1.** Attention variants. All have 40,650 parameters on LRA-Image; Pt and Pool add one temperature per head.

| Variant | Query/key tokens | Factors | Attention weights |
|---|---|---|---|
| S, signed YAKAL (matched signed control) | $\mathrm{LN}(X)$ | signed | $\mathrm{softmax}_j(\langle Q_i,K_j\rangle/\sqrt{rt})$ |
| Sp, encoding baseline (registered by Paper II) | $e^{\mathrm{LN}(X)}$ | signed | $\mathrm{softmax}_j(\langle Q_i,K_j\rangle/\sqrt{rt})$ |
| P1, positive YAKAL at τ = 1 | $e^{\mathrm{LN}(X)}$ | $e^{\theta}$ | $s_{ij}/\sum_ks_{ik}$, by linear reassociation |
| Pt, learned τ | $e^{\mathrm{LN}(X)}$ | $e^{\theta}$ | $s_{ij}^{\tau_h}/\sum_ks_{ik}^{\tau_h}$, $\tau_h=e^{\lambda_h}$ from 1 |
| Pool, sparse positive pools | $e^{\mathrm{LN}(X)}$ | column-stochastic, $\mathrm{softmax}$ over output rows, entropy penalty 0.1 | as Pt |
| U, attention off (added) | – | – | $1/N$ |

**Training and matched budget.**

- **Optimiser.** Adam [12], batch 128, 200 warm-up steps and cosine decay, gradient norm clipped at 1.
- **Schedule.** 8 epochs on LRA-Image, 5 on Pathfinder and 4 on the retrieval task.
- **Learning rate.** For each task and variant, the rate was chosen from {10⁻³, 3·10⁻³} by validation accuracy after a short pilot schedule (seed 100).
- **Seeds.** 0–4.

Every variant has the same architecture, parameter count (up to the τ's), token size and number of optimiser steps. P1 costs less per step because it reassociates.

## 4.3 Uncertainty set, queries and certificates

- **The box.** Every entry of the four query and key factors of every head moves in a factor box of log radius ρ. The registered radius is ρ = 0.02, and 0.01 and 0.05 are also reported.
- **Queries.** A held-out query is a test image × layer × head × query position. Accuracy uses the whole test set. Certificates and attention statistics use the first 2,000 test images, 512,000 queries per model, because the float64 evaluation costs about two minutes per model on one core. On the retrieval task, 56 of the 64 query positions are blank tokens, so blank-token queries make up seven eighths of every count over all queries.
- **The certificate.** A query is certified if its certificate (Section 3) is at most 0.1. The certificate is the smallest of four sound bounds:
  - Equation 11;
  - $\tanh(\bar\Omega_i/4)$, which is Proposition 4(a) with $D_i$ replaced by its cheaper upper bound $\bar D_i$;
  - Proposition 5(a);
  - Proposition 5(b).
- **Subsample.** On the first 100 test images the evaluator also computes:
  - the exact diameters $D_i$ of every query, and with them the $\Omega_i$ sandwich;
  - the $\Omega$ witness at the sign vertex;
  - TV witnesses for 16 query positions per image.
- **Arithmetic.** Certificates are real-arithmetic bounds evaluated in float64 at the nominal float32 tokens, without outward rounding.

## 4.4 Registered criteria

- **Certification target** (Paper II). TV ≤ 0.1 for at least 95% of held-out queries at ρ = 0.02, in the mean over seeds. The minimum over seeds is also reported.
- **Accuracy criterion** (Paper II). Seed-mean test accuracy at most 2.0 points below S.
- **Pass.** A positive variant passes a task if it meets both criteria.
- **Verdict.** The P2 operating point is supported on a task if at least one positive variant passes. It is rejected there if none does.
- **Validity gate** (ours, in the protocol before the LRA-Image pilot). A task is informative about attention only if S beats U by at least 2.0 points. On a task that fails the gate, the accuracy comparison does not test the scoring, and we say so. Paper II's rule has no such gate, so Section 8 reports the verdict both ways.
- **Statistics.** Seed means with 95% t-intervals, and seed-paired differences against S.

**Table 2.** Departures from Paper II's plan and amendments of our protocol.

| Item | Paper II / first protocol | Executed | Reason | When |
|---|---|---|---|---|
| LRA data | released LRA files | CIFAR-10 converted as in LRA; Pathfinder regenerated with the original generator | released files unreachable | first protocol |
| Certified queries | held-out queries | first 2,000 test images per task (512,000 queries per model) | evaluation cost | first protocol |
| Pathfinder size | 160k/20k/20k | 60k/20k/20k | generation cost | amendment, before any Pathfinder model was trained |
| Pathfinder runs | 6 variants × 5 seeds | S and U × 2 seeds, no certificates | every variant at chance in the pilot | amendment, after the Pathfinder pilot |
| Added task | – | retrieval, all variants × 5 seeds | LRA-Image pilot: attention-free control best | amendment, after the LRA-Image pilot |
| Token-size sweep | LRA-Image | retrieval task | same reason | amendment, before any sweep run |
| Exploratory runs | – | positive variants on retrieval at learning rate $3\cdot10^{-3}$, 4 or 12 epochs, τ starting at 8, 4×4-token pools; signed witnesses | the confirmatory retrieval results | post hoc, labelled exploratory |

# 5 Random tokens: the L10 check with token mass removed

Paper II's L10 check used random positive tokens and random positive factors ($r=t=4$; for $p\times p$ tokens, entries $e^{\mathcal N(\log(1/p),\,0.5^2)}$) to show how Equation 11 behaves as tokens grow. It registered a repetition with token mass normalised outside the uncertain computation, because the contrast it found between dense and sparse tokens might reflect variation in token gain. We repeated it (`l10_repeat.py`, seed 20261012) with the two token families of L10:

- **dense:** every entry $e^{\mathcal N(0,\,0.25^2)}$;
- **sparse:** four active entries $e^{\mathcal N(0,\,0.25^2)}$, all others $10^{-6}$.

Each family was run with raw tokens and with tokens divided by their total mass, at $p=q\in\lbrace4,8,16,32\rbrace$. In each cell there were 10 random draws of 32 tokens and 8 queries per draw.

As in L10, the temperature is set to $\tau^{\ast}=1/\text{spread}$, so that the nominal logits have unit spread over keys. The table compares Equation 11 at that temperature with the certificate of Section 3, and with the TV of the best witness found.

**Table 3.** L10 repeated. Paper II registered the repetition. The certificate, witness and $D_i$ columns are ours, and our protocol listed the check among its exploratory analyses because it has no decision rule. Medians over 80 queries; ρ = 0.02. *Spread* is the median over queries of the SD over keys of $\log s_{ij}$. *Certified* is the fraction of queries with certificate ≤ 0.1. Equation 11 certified no query in any row.

| Tokens | p = q | Spread | Spread·$\sqrt{pq}$ | $\tau^{\ast}$ | Eq. 11 | Certificate | Witness | $D_i$ | Certified |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| dense, raw | 4 | 0.0604 | 0.242 | 16.6 | 0.580 | 0.048 | 0.017 | 0.61 | 100% |
| | 8 | 0.0327 | 0.261 | 30.6 | 0.841 | 0.073 | 0.021 | 0.38 | 100% |
| | 16 | 0.0168 | 0.269 | 59.5 | 0.983 | 0.118 | 0.025 | 0.23 | 10% |
| | 32 | 0.0084 | 0.269 | 118.8 | 1.000 | 0.179 | 0.038 | 0.15 | 0% |
| dense, mass 1 | 4 | 0.0175 | 0.070 | 57.1 | 0.979 | 0.188 | 0.073 | 0.59 | 0% |
| | 8 | 0.0113 | 0.090 | 88.6 | 0.998 | 0.242 | 0.071 | 0.38 | 0% |
| | 16 | 0.0059 | 0.095 | 169.4 | 1.000 | 0.313 | 0.083 | 0.24 | 0% |
| | 32 | 0.0028 | 0.090 | 357.4 | 1.000 | 0.499 | 0.102 | 0.15 | 0% |
| sparse, raw | 4 | 0.1952 | 0.781 | 5.1 | 0.202 | 0.084 | 0.044 | 3.84 | 70% |
| | 8 | 0.2151 | 1.721 | 4.6 | 0.184 | 0.116 | 0.048 | 4.87 | 10% |
| | 16 | 0.2153 | 3.444 | 4.6 | 0.184 | 0.117 | 0.060 | 4.88 | 10% |
| | 32 | 0.2286 | 7.314 | 4.4 | 0.174 | 0.115 | 0.069 | 4.95 | 14% |
| sparse, mass 1 | 4 | 0.1360 | 0.544 | 7.4 | 0.286 | 0.118 | 0.053 | 4.11 | 30% |
| | 8 | 0.1712 | 1.369 | 5.8 | 0.230 | 0.143 | 0.068 | 4.87 | 0% |
| | 16 | 0.1961 | 3.138 | 5.1 | 0.201 | 0.133 | 0.068 | 5.06 | 10% |
| | 32 | 0.1679 | 5.371 | 6.0 | 0.234 | 0.158 | 0.093 | 5.05 | 0% |

![L10 repeated](figures/fig_l10.png)

**Figure 1.** L10 repeated. (a) Log-score spread over keys against token size, for dense and sparse tokens, raw and with mass normalised; the dotted line falls like $1/\sqrt{pq}$. (b) The certificate at $\tau^{\ast}$ (circles) against Equation 11 (squares); the horizontal line is the 0.1 target. (c) The best witness found.

Four findings follow.

1. **Dense tokens concentrate.** With dense tokens the spread falls like $1/\sqrt{pq}$: spread·$\sqrt{pq}$ stays at 0.24–0.27 raw and 0.07–0.10 normalised. So $\tau^{\ast}$ grows like $\sqrt{pq}$, which is the diagnostic that Paper II registered for the failure of Equation 11. Equation 11 at $\tau^{\ast}$ is 0.58–1.00.
2. **Most of the dense spread was token gain.** Normalising the mass removed 71% of it at 4×4 (0.0604 to 0.0175) and 67% at 32×32. By Proposition 4(c), gain spreads the scores without exposing them to the factor box. This is why the certificate stayed below 0.1 for every raw dense query at 4×4 and 8×8, while Equation 11 exceeded 0.58. After normalisation the content spread alone forces $\tau^{\ast}=57$–357, and no query is certified.
3. **The sparse contrast is not gain.** Sparse tokens keep a spread of 0.14–0.23 at every size, raw or normalised, and $\tau^{\ast}$ stays between 4.4 and 7.4. So the dense-versus-sparse contrast of L10 survives normalisation and even sharpens.
4. **Sparse selectivity has a price.** Sparse tokens load different factor entries, so their factor-mass vectors are far apart ($D_i=3.8$–5.1 of a maximum of 8). The certificate then improves on Equation 11 only by a factor of 1.5–2.4. It certified 70% and 30% of queries at 4×4 (raw and normalised) and at most 14% at larger sizes.

**L10(b) repeated.** With L10's other configuration (tokens $e^{\mathcal N(0,1)}$, τ = 4) the certificate was 0.047, 0.035 and 0.026 at 4×4, 8×8 and 16×16, against Equation 11's 0.159 and witnesses of 0.027, 0.013 and 0.008. Every query was certified. The witnesses are larger than the maxima over random box members that L10 reported for the same configuration (0.011, 0.005, 0.002), as a search should be, although the random draws differ.

The table gives a criterion that does not depend on τ. At unit logit spread, Proposition 4 certifies a query when $\tau^{\ast}(\rho D_i+8\rho^2)\le4\operatorname{artanh}0.1=0.401$, that is, when the spread is at least $(\rho D_i+8\rho^2)/0.401\approx D_i/20+0.008$ at ρ = 0.02. Selectivity is certifiable when the scores separate by more than the factor masses do.

- **Raw dense tokens.** At 4×4 and 8×8 they met the criterion through gain (spread 0.060 and 0.033 against thresholds 0.038 and 0.027, computed from the median $D_i$). At 16×16 and 32×32 they did not.
- **Normalised dense tokens.** They never met it.
- **Sparse tokens.** They came close only at 4×4 (0.195 against 0.199).

# 6 Results

## 6.1 LRA-Image: attention was not needed

**Table 4.** LRA-Image, five seeds.

- **Accuracy** is the seed mean with its 95% t-interval. *vs S* is the seed-paired difference.
- **Certified** is the fraction of the 512,000 held-out queries per seed with certificate ≤ 0.1 at ρ = 0.02.
- **Heads failing Eq. 11** counts the 20 heads (5 seeds × 2 layers × 2 heads) in which $\tanh(2\tau\rho)>0.1$.
- **Logit spread** is the median over queries of the SD over keys of the attention logits ($s_{ij}/\sqrt{rt}$ for signed scoring, $\tau\log s_{ij}$ for positive). *Effective keys* is the median of $\exp H(a_i)$, out of 64. Both are then medianed over heads.

| Variant | Accuracy (%) | vs S (pp) | Certified (%) | Heads failing Eq. 11 | τ, median [range] | Logit spread | Effective keys |
|---|---:|---:|---:|---:|---|---:|---:|
| S | 46.31 [43.83, 48.79] | – | – | – | – | 1.87 | 23.1 |
| Sp | 46.81 [44.97, 48.65] | +0.49 [−0.32, +1.31] | – | – | – | 2.20 | 22.4 |
| P1 | 50.97 [48.81, 53.13] | +4.66 [+3.02, +6.29] | 100.00 | 0 | 1 | 0.45 | 56.0 |
| Pt | 49.43 [45.36, 53.51] | +3.12 [+1.02, +5.21] | 100.00 | 1 | 1.79 [1.12, 2.87] | 0.69 | 45.7 |
| Pool | 50.84 [48.07, 53.60] | +4.52 [+3.33, +5.72] | 100.00 | 2 | 1.78 [0.89, 3.35] | 0.41 | 57.3 |
| U | 52.35 [50.51, 54.20] | +6.04 [+4.44, +7.64] | – | – | – | 0 | 64 |

The attention-free control U was the most accurate model: 52.35%, 6.04 points [4.44, 7.64] above the signed control. Our validity gate requires S to beat U by at least two points. S lost to U by six, so LRA-Image fails the gate, and its accuracy comparisons say nothing about the scoring mechanism. All three positive variants met both of Paper II's criteria. They were 3.1–4.7 points more accurate than S, and every query was certified. By Paper II's rule alone, that supports the operating point on LRA-Image. By the gate it does not, and Section 8 gives both readings. The pilot had already shown the same ordering (Section 4.1), which is why we added the retrieval task.

The positive models behaved like the attention-free one.

- **Uniform attention.** Their attention stayed near uniform: a median of 46–57 effective keys of 64, against 22–23 for signed scoring.
- **Low temperatures.** The learned temperatures stayed low, at a median of 1.8 and at most 3.35.
- **Spreads.** Paper II also asked for the log-score spread $\mathrm{SD}_j\log s_{ij}$ and the concentration-normalised spread, the log-score spread times $\sqrt{pq}$ as in Section 5. Their medians over heads were 0.45, 0.36 and 0.21 for P1, Pt and Pool (times $\sqrt{pq}=8$: 3.57, 2.91 and 1.66).
- **Accuracy.** All three positive variants were more accurate than both signed ones, and U was more accurate still. Diffuse attention was the better choice on this task at this scale, and positive scoring reached it naturally.

The encoding baseline Sp was within half a point of S [−0.32, +1.31], so the positive token encoding cost nothing.

**Certificates.** Every query of every positive model was certified at ρ = 0.01 and ρ = 0.02. At ρ = 0.05, P1 was still certified on 100% of queries, Pt on 99.77% and Pool on 93.18%. In 3 of the 40 learned-τ heads, $\tau>2.508$, so Equation 11 alone exceeded 0.1. In those heads the dependency-aware bounds certified every query. Table 7 compares the bounds.

![Accuracy](figures/fig_accuracy.png)

**Figure 2.** Test accuracy of every seed (dots) and the seed mean (horizontal line) on LRA-Image (left), Pathfinder-32 (middle; S and U only, two seeds, on a narrow axis around chance) and the retrieval task (right). Blue: signed scoring; red: positive scoring; grey: attention off.

## 6.2 Pathfinder: nothing learned

The four registered Pathfinder runs, S and U on seeds 0 and 1, all stayed at chance (Table 5): S − U = −0.37 points. So did all twelve pilot runs (49.6–50.1% validation accuracy).

**Table 5.** Pathfinder-32 (hard), test accuracy (%) after the registered 5 epochs.

| Variant | Seed 0 | Seed 1 |
|---|---:|---:|
| S | 49.56 | 49.37 |
| U | 49.70 | 49.97 |

Our models processed about 300,000 training examples: 2,340 steps of 128. LRA's Pathfinder configuration trains for 200 epochs of 160,000 examples, about 32 million. At about 1% of that budget no variant left chance, so the task fails the gate and is uninformative. This says nothing about positive attention. It says that Pathfinder cannot discriminate between attention mechanisms at this compute.

## 6.3 Retrieval: positive scoring did not find the key

**Table 6.** Retrieval task, five seeds. Columns as in Table 4. *Match mass* is the attention that query 0 places on the matching key, in the head where it is largest, as a median over the first 2,000 test examples and then over seeds. Uniform attention gives 1/64 = 0.016.

| Variant | Accuracy (%) | vs S (pp) | Certified (%) | τ, median [range] | Logit spread | Effective keys | Match mass |
|---|---:|---:|---:|---|---:|---:|---:|
| S | 99.36 [99.31, 99.40] | – | – | – | 1.35 | 35.9 | 0.999 |
| Sp | 99.30 [99.25, 99.36] | −0.05 [−0.15, +0.04] | – | – | 2.38 | 18.8 | 1.000 |
| P1 | 17.63 [12.14, 23.11] | −81.73 [−87.23, −76.22] | 100.00 | 1 | 0.09 | 63.7 | 0.023 |
| Pt | 19.59 [14.42, 24.76] | −79.77 [−84.96, −74.57] | 100.00 | 1.38 [0.81, 1.98] | 0.12 | 63.4 | 0.050 |
| Pool | 17.31 [13.12, 21.50] | −82.04 [−86.24, −77.85] | 100.00 | 1.29 [0.74, 2.10] | 0.04 | 64.0 | 0.031 |
| U | 13.56 [12.60, 14.51] | −85.80 [−86.79, −84.81] | – | – | 0 | 64 | 0.016 |

Here attention is necessary, and the gate holds by 85.8 points.

- **Signed scoring.** S and Sp solved the task in every seed (99.23–99.39%). In every model, one first-layer head put a median of at least 0.999 of the query's attention on the matching key. The positive token encoding again cost nothing: Sp was 0.05 points [−0.15, +0.04] from S.
- **Positive scoring.** All three positive variants were 79.8–82.0 points below S in the seed means. Each fails the accuracy criterion by a wide margin, so the P2 operating point is rejected on this task.
- **How far they got.** Their query attention barely favoured the matching key (median match mass 0.02–0.05, at most 0.10 in any seed, against a uniform 0.016), and their best seeds reached 20.5–23.2%. Their certificates held on every query, but they certify a nearly uniform average. Their log-score spreads were 0.087, 0.091 and 0.031 for P1, Pt and Pool in the median over heads (times $\sqrt{pq}$: 0.70, 0.73 and 0.25). U reached 13.6% without attention.

The learning-rate rule picked $10^{-3}$ for every positive variant on this task, from pilot accuracies that were all at chance (10.2–10.7%). Section 7.2 asks whether a larger rate, a longer schedule or a sharp starting temperature changes the outcome.

## 6.4 How tight the certificates were (exploratory)

Our protocol listed the witnesses and the comparison among the four bounds as exploratory analyses. The $\Omega_i$ bounds were a registered measurement.

**Table 7.** Bounds on trained positive models at ρ = 0.02.

- **Bound columns.** *Eq. 11* through *Certificate* are medians over all held-out queries and seeds. *Bennett–Pinsker* is Proposition 5(a) and *ℓ₁* is Proposition 5(b); *Certificate* is the smallest of the four bounds.
- **Witness.** The median TV of the best witness found (16 queries per image on the first 100 test images). *Witness / cert.* is the median over heads of each head's median ratio between the witness and the certificate of the same query.
- **Ω columns.** $D_i$ is the exact $\ell_1$ diameter. *Ω sandwich* gives the medians of $\tau(\rho D_i-8\rho^2)$, of the witnessed spread at the sign vertex, and of $\tau(\rho D_i+8\rho^2)$.

| Task | Variant | Eq. 11 | $\tanh(\bar\Omega_i/4)$ | Bennett–Pinsker | ℓ₁ | Certificate | Witness | Witness / cert. | $D_i$ | Ω sandwich |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| LRA-Image | P1 | 0.0400 | 0.0205 | 0.0108 | 0.0108 | 0.0106 | 0.0070 | 0.66 | 3.22 | 0.061 / 0.064 / 0.068 |
| | Pt | 0.0714 | 0.0322 | 0.0159 | 0.0162 | 0.0157 | 0.0103 | 0.62 | 2.82 | 0.094 / 0.100 / 0.107 |
| | Pool | 0.0712 | 0.0410 | 0.0221 | 0.0225 | 0.0219 | 0.0120 | 0.56 | 3.77 | 0.130 / 0.136 / 0.142 |
| Retrieval | P1 | 0.0400 | 0.0119 | 0.0052 | 0.0055 | 0.0052 | 0.0025 | 0.44 | 1.70 | 0.031 / 0.034 / 0.037 |
| | Pt | 0.0552 | 0.0156 | 0.0064 | 0.0068 | 0.0064 | 0.0037 | 0.54 | 1.82 | 0.044 / 0.048 / 0.052 |
| | Pool | 0.0514 | 0.0106 | 0.0049 | 0.0054 | 0.0049 | 0.0018 | 0.39 | 1.29 | 0.024 / 0.028 / 0.032 |

![Certificates on LRA-Image](figures/fig_cert_image.png)

**Figure 3.** LRA-Image: distribution over held-out queries of the four bounds and of the certificate (their minimum), for each positive variant, all seeds pooled. The vertical line at 0.1 is the registered target. The dotted vertical line is the median witnessed TV.

Four things hold for every model.

1. **The sandwich is tight.** Every Ω witness fell inside its sandwich (Proposition 4), and the witnessed spread sat near the middle. At ρ = 0.02 the sandwich pins $\Omega_i$ to within about ±0.007 when τ ≈ 2. The relative variation is therefore effectively computed. With the median $D_i$ of 1.3–3.8, $\Omega_i$ was 2.1–6.2 times smaller than the $8\tau\rho$ allowed by the independent score box.
2. **The distribution-aware bounds win.** The certificate was always Proposition 5(a) or (b): Bennett–Pinsker for 61–80% of queries and the ℓ₁ bound for the rest. Its median was 1.9–2.5 times smaller than that of $\tanh(\bar\Omega_i/4)$ and 3.2–10.6 times smaller than that of Equation 11.
3. **Witnesses bracket the truth.** No witness exceeded its certificate, and none exceeded 0.1: the largest was 0.054 on LRA-Image and 0.031 on the retrieval task.
   - **Per model.** In the median over heads, the best witness reached 0.39–0.66 of the certificate of the same query. For a typical query the certificate is therefore at most 1.5–2.6 times the true worst case.
   - **Per head.** The heads' median ratios ranged from 0.46 to 0.78 on LRA-Image and from 0.24 to 0.86 on the retrieval task. The smallest ratios (0.24–0.30) came from second-layer retrieval heads whose median witness was below 0.001. There the second-order term of Proposition 5 dominates the certificate, whose median stayed below 0.003.
4. **Equation 11 is loose.** It was 5.7–29 times the median witness.

# 7 Diagnostics and exploratory analyses

## 7.1 Token size and the temperature (registered diagnostic)

Paper II registered a diagnostic: growth of the learned τ like $\sqrt{pq}$ would show that Equation 11 must fail as tokens grow. The registered sweep trained S, Pt and Pool with 4×4 tokens on the retrieval task (seeds 0–2, frozen learning rates) and compared them with the 8×8 confirmatory runs on the same seeds.

- **Signed.** S learned at both sizes: 98.68% with 4×4 tokens and 99.34% with 8×8.
- **Positive.** Pt and Pool stayed at chance (10.9% and 10.8% with 4×4 tokens), with median temperatures of 1.02 and 0.99. With 8×8 tokens they reached 18.4% and 15.5%, with medians 1.27 and 1.20.
- **Spreads.** Their log-score spreads followed no common law: from 4×4 to 8×8 tokens the median rose from 0.044 to 0.091 for Pt and fell from 0.061 to 0.031 for Pool.

The registered diagnostic is therefore uninformative. The positive models never selected, so their temperature never had to grow.

**Exploratory.** Sparse pools trained at learning rate $3\times10^{-3}$ for 12 epochs did learn (Section 7.2), and they give a comparison that the sweep could not.

- **8×8 tokens.** All three seeds learned (97.81%, 98.05% and 85.30%), and the retrieval head's τ reached 23.9, 34.8 and 30.2.
- **4×4 tokens.** One seed of three learned (73.04%, τ = 13.8). The other two did not (34.57% and 36.84%, τ ≤ 2.0).

Among the heads that select, the temperature at 8×8 tokens was 1.7–2.5 times that at 4×4, against a $\sqrt{pq}$ ratio of 2. This is consistent with the growth that Paper II's diagnostic describes, but it is weak evidence. It rests on one learned 4×4 model, on a schedule and learning rate outside the registered sweep, and the three 8×8 seeds alone spread from 24 to 35. Equation 11 is far above the target at both sizes (0.50 at τ = 13.8; 0.74–0.88 at τ = 24–35), as the diagnostic predicts. Section 7.3 asks whether the correlated certificate fares better.

## 7.2 Can positive scoring learn the retrieval task? (exploratory)

The registered learning-rate rule chose $10^{-3}$ for every positive variant on the retrieval task, from pilot accuracies that were all at chance. We therefore reran the positive variants at $3\times10^{-3}$, on the registered 4-epoch schedule and on a 12-epoch one. These runs were decided after the confirmatory results were seen and are exploratory.

**Table 8.** Retrieval task, positive variants at learning rate $3\times10^{-3}$ (exploratory). The *selecting head* is the head with the largest learned τ. For P1, where τ = 1 in every head, it is the head with the largest match mass. *Effective keys* and *match mass* are medians for the query token in that head. *Pool entropy* is the mean entropy of a factor column of that head, in nats. It is at most ln 4 = 1.386, and 0 means that each input row or column feeds a single pool.

| Variant | Epochs | Seeds | Test accuracy (%) | τ of selecting head | Effective keys | Match mass | Pool entropy |
|---|---:|---|---|---|---|---|---|
| P1 | 12 | 0 | 40.27 | 1 | 5.6 | 0.09 | – |
| Pt | 12 | 0 | 41.97 | 1.91 | 4.0 | 0.07 | – |
| Pt, τ starting at 8 | 4 | 0 | 35.36 | 8.36 | 5.7 | 0.07 | – |
| Pool | 4 | 0, 1, 2 | 29.70, 39.98, 46.63 | 2.15, 2.76, 2.40 | 12.7, 9.7, 9.1 | 0.13, 0.17, 0.18 | 0.25, 0.27, 0.36 |
| Pool | 12 | 0, 1, 2 | 97.81, 98.05, 85.30 | 23.9, 34.8, 30.2 | 1.4, 1.4, 2.2 | 0.91, 0.93, 0.71 | 0.04, 0.05, 0.12 |
| Pool, 4×4 tokens | 12 | 0, 1, 2 | 73.04, 34.57, 36.84 | 13.8, 1.4, 2.0 | 3.3, 10.8, 21.2 | 0.51, 0.06, 0.14 | 0.06, 0.03, 0.08 |

Four findings follow.

1. **For sparse pools, the learning-rate rule did not cause the rejection.** On the registered 4-epoch schedule at the higher rate, they reached 30–47%, still 53–70 points below S. We did not rerun P1 and Pt on that schedule.
2. **Sparse pools learned with three times the schedule; dense positive scoring did not.** Pool reached 98% in two seeds of three and 85% in the third. P1 and Pt, with one seed each, reached 40–42%. Their first-layer heads did concentrate the query's attention, on 4–6 effective keys, but not on the matching key (match mass 0.07–0.09).
3. **Starting sharp has no matched control.** Pt starting at τ = 8 reached 35.4% after 4 epochs. We did not run Pt at this rate for 4 epochs from τ = 1, so this run cannot say whether the sharp start helped.
4. **The pools that learned were nearly hard partitions, but so were pools that failed.**
   - **Learned.** The 8×8 models that learned had pool entropies of 0.03–0.12 nats per head, and their factor columns put on average 0.965–0.996 of their weight on a single pool. The confirmatory Pool models on this task (learning rate $10^{-3}$, 4 epochs) had 0.83–0.92 nats, and the 4-epoch runs at the higher rate 0.22–0.36.
   - **The prediction.** The research agenda's prediction P2.1 [24] was that trained positive factors become sparse, with nearly disjoint pools, and that the diagonal share of the Gram matrix rises during training. Every 12-epoch Pool run fits its first half. We did not measure the second.
   - **Not sufficient.** Sparsity did not separate success from failure. The two 4×4 models that stayed below 37% had pools as sparse as the one that learned (model means 0.026 and 0.038 nats, against 0.033).

So positive Kronecker attention can retrieve by content in this setting. Where it did, it used nearly hard pools and temperatures of 24–35, after three times the registered schedule, while S passed 97% validation accuracy after its first epoch. Sparse pools were part of every success and were not enough on their own.

## 7.3 Certifying attention that selects (exploratory)

The models of Section 7.2 are the first positive models in this study whose attention selects a single key. Table 9 asks the registered question of them.

**Table 9.** Certificates and witnesses at ρ = 0.02 for the sparse-pool models that learned the task (exploratory).

- **All queries.** Fraction certified over all 512,000 held-out queries per model.
- **Selecting head.** Fraction certified over that head's queries, with the medians of $D_i$ and of the Ω sandwich on the first 100 test images.
- **Decision query.** The query token of the selecting head on the first 200 test images: fraction certified, median witnessed TV, fraction of witnesses above 0.1, and the fraction of predictions that change when the witness perturbation is applied to that head inside the full model.

| Model | All queries, ρ = 0.01 / 0.02 / 0.05 (%) | Selecting head, certified (%) | Eq. 11 | $D_i$ | Ω sandwich | Decision query: certified (%) | Witness median | Witness > 0.1 (%) | Predictions changed (%) |
|---|---|---:|---:|---:|---|---:|---:|---:|---:|
| 8×8, seed 0 (τ = 23.9) | 96.8 / 78.0 / 75.0 | 12.1 | 0.742 | 3.51 | 1.60 / 1.63 / 1.75 | 35.5 | 0.039 | 12.5 | 2.0 |
| 8×8, seed 1 (τ = 34.8) | 85.1 / 75.7 / 74.7 | 2.9 | 0.883 | 3.49 | 2.32 / 2.36 / 2.54 | 14.0 | 0.055 | 25.0 | 5.5 |
| 8×8, seed 2 (τ = 30.2) | 92.4 / 77.3 / 46.8 | 9.1 | 0.836 | 4.13 | 2.40 / 2.43 / 2.59 | 9.5 | 0.076 | 32.5 | 13.5 |
| 4×4, seed 0 (τ = 13.8) | 99.6 / 89.3 / 75.0 | 57.1 | 0.501 | 4.34 | 1.15 / 1.22 / 1.24 | 61.5 | 0.042 | 7.5 | 8.0 |

![Selecting heads](figures/fig_explore.png)

**Figure 4.** The decision query of the selecting head, for the four sparse-pool models that learned the retrieval task (200 test images each). (a) Witnessed TV against the certificate; × marks images whose prediction changed under the witness perturbation. (b) Distributions of the certificate (solid) and of the witness (dotted), with Equation 11 (dashed).

- **The target is not certified.** 75.7–89.3% of all queries were certified at ρ = 0.02, against the 95% registered. Blank tokens make up seven eighths of these queries. On the eight content positions alone, the certified fractions were similar: 77.6–87.1% in the 8×8 models and 92.0% in the 4×4 model.
- **For the 8×8 models the miss is real, not looseness.**
  - In the selecting heads, explicit factor perturbations inside the box moved the decision query's attention by more than 0.1 in 12.5–32.5% of images (7.5% in the 4×4 model).
  - Over the evaluator's sampled query positions, 40–69% of the selecting head's queries had a witness above 0.1 in the 8×8 models, and 17% in the 4×4 model.
  - A head holds a quarter of a model's queries. If the sampled positions represent their head, about 10–17% of all queries miss the target in the 8×8 models, so at most about 83–90% can meet it. This is an estimate from a subsample, not a bound.
  - In the 4×4 model the same estimate puts the fraction that meets the target between the certified 89.3% and about 95.7%, so the target is undecided there.
  - The certificates stayed within a factor of about two of the witnesses (median ratio 0.42–0.55 over the head's queries), and no witness exceeded its certificate.
- **ρ = 0.01.** Half the radius certifies 85.1–96.8% of all queries in the 8×8 models and 99.6% in the 4×4 model. Of the decision queries on the first 2,000 test images, it certifies 86–93% and 99%.

Proposition 4 says why.

- **Exposure per unit of separation did not change.** The selecting heads' factor-mass diameters were not unusual: $D_i$ = 3.5–4.1 in the 8×8 models, against 4.7–5.2 in the 4-epoch pools at the same learning rate, which stayed certifiable. Their log scores separated no more either (median log-score spread 0.28–0.35, against 0.47–0.62).
- **τ changed.** Selecting one key took logit spreads of 8–10, which these log scores reach only at τ = 24–35. τ multiplies the exposure as well: $\Omega_i\approx\tau\rho D_i$ = 1.6–2.4, while TV ≤ 0.1 needs $\Omega_i\le0.40$ by Proposition 3.

Selection by content was bought with temperature, and the temperature exposed it (Section 9).

Decisions were more robust than attention. The witness perturbations were chosen to move the attention, not the prediction, and they changed 2.0–13.5% of predictions. The registered target constrains the attention distribution, which is a stronger requirement than constraining the decision.

## 7.4 Signed scoring under the same box (exploratory)

Is the target harder for positive scoring than for signed? We searched the same sign-preserving box for S and Sp (seed 0) on both tasks, with every factor entry multiplied by $e^{d}$, $|d|\le0.02$, and its sign kept (`p2_signed_witness.py`). The search is the sign iteration of the positive witnesses, applied to the first-order change of the signed logits $s_{ij}/\sqrt{rt}$, on 16 query positions of the first 100 test images per head. Each witness is an explicit model in the box, so it bounds its query's worst case from below.

**Table 10.** Signed scoring at ρ = 0.02 (seed 0, exploratory): for each head, the percentage of its 1,600 sampled queries whose witness exceeds 0.1, with the median witness in parentheses. Bold marks the head that retrieves (median match mass at least 0.999).

| Task | Variant | Layer 1, head 1 | Layer 1, head 2 | Layer 2, head 1 | Layer 2, head 2 |
|---|---|---|---|---|---|
| LRA-Image | S | 9.7 (0.071) | 11.2 (0.072) | 13.3 (0.075) | 17.4 (0.078) |
| | Sp | 61.8 (0.109) | 65.8 (0.114) | 41.7 (0.093) | 13.8 (0.075) |
| Retrieval | S | 0.2 (0.037) | **59.5 (0.182)** | 0.0 (0.033) | 22.6 (0.079) |
| | Sp | **59.9 (0.263)** | 95.1 (0.173) | 60.2 (0.117) | 45.9 (0.096) |

- **Signed attention misses the target on both tasks.** On LRA-Image, where every query of every positive model was certified, 10–17% of the sampled queries of every S head moved by more than 0.1. If the sample represents the model, at most about 87% of its queries meet the target.
- **Where it retrieves, it is exposed.** The retrieving head of S moved by more than 0.1 on 59.5% of its sampled queries.
- **The encoding baseline is more exposed still.** Sp's logits spread more than S's (Tables 4 and 6), and its witnesses were larger.

So in our models the registered target was out of reach for selective attention under either sign. We did not develop a certificate for signed scoring. A crude bound that ignores both the cancellation and the dependence between monomials certified no query on any task, so this comparison rests on the witnesses.

## 7.5 Measured latency

**Table 11.** Attention block (two heads, the trained shapes), JAX on one CPU thread in float32: median milliseconds per image (`p2_latency.py`). Batch 32 for N ≤ 256 and batch 8 for N = 1024.

| Keys N | S | Sp | P1 | Pt | Pool | U |
|---:|---:|---:|---:|---:|---:|---:|
| 64 | 0.047 | 0.040 | 0.057 | 0.069 | 0.058 | 0.027 |
| 256 | 0.241 | 0.290 | 0.117 | 0.333 | 0.312 | 0.060 |
| 1024 | 2.859 | 3.491 | 0.603 | 3.703 | 3.625 | 0.209 |

- **Reassociation.** P1 is 4.7 times faster than S at N = 1024 and 2.1 times at N = 256, as the linear reassociation predicts. At N = 64 it is slower (0.057 against 0.047 ms).
- **Power normalisation.** Pt and Pool cost 27–30% more than S at N = 1024 and 24–46% more at the smaller sizes.
- **Certificates.** The float64 certificate summaries cost 3.8 ms per image and head. For the model's four heads that is about 37 float32 forward passes of the whole model (0.41 ms per image). Their $O(N^2P)$ cost is the price of seeing the dependence between scores.
- **On LNS hardware.** In a logarithmic number system, signed scoring needs one inverse-log conversion per score before normalisation, that is N per query. Positive scoring needs none. These CPU timings in floating point say nothing about LNS hardware.

# 8 Verdict

**Table 12.** Registered criteria per task.

- **Accuracy:** seed mean no more than 2 points below S (Paper II).
- **Certified:** at least 95% of held-out queries with TV ≤ 0.1 at ρ = 0.02 (Paper II).
- **Gate:** S at least 2 points above U (our protocol).

| Task | Gate, S − U (pp) | P1: accuracy / certified | Pt: accuracy / certified | Pool: accuracy / certified | By Paper II's rule | With our gate |
|---|---:|---|---|---|---|---|
| LRA-Image | −6.04 (fails) | +4.66 ✓ / 100% ✓ | +3.12 ✓ / 100% ✓ | +4.52 ✓ / 100% ✓ | supported | uninformative |
| Pathfinder-32 | −0.37 (fails) | not run | not run | not run | not tested | uninformative |
| Retrieval (added) | +85.80 (passes) | −81.73 ✗ / 100% ✓ | −79.77 ✗ / 100% ✓ | −82.04 ✗ / 100% ✓ | rejected | **rejected** |

**Is the P2 operating point supported?** The answer depends on one rule that Paper II did not set, so we give it both ways.

- **By Paper II's rule alone.** The operating point is supported on LRA-Image, where all three positive variants met both criteria, and untested on Pathfinder, where no model left chance. Paper II registered only these two tasks.
- **With our validity gate.** Our protocol set the gate before the LRA-Image pilot: a task tests attention only if the signed control beats the attention-free one by two points. On LRA-Image the attention-free control won by six. A comparison of scoring mechanisms on a task that is solved best without attention does not test the mechanisms, so we count LRA-Image as uninformative. Pathfinder fails the gate as well.
- **On the added task.** The retrieval task passes the gate by 85.8 points. Every positive variant was 79.8–82.0 points below S there, far past the 2-point margin of Paper II's rejection rule.

Our verdict is therefore that the operating point is **not supported** by any task that tests attention, and **rejected** on the one task where attention was necessary. A reader who sets the gate aside should read LRA-Image as formal support at a scale where attention was not needed.

**Is the certification target met?** For every confirmatory model, yes. 100% of held-out queries were certified at ρ = 0.02 and at ρ = 0.01, on every task, variant and seed. This was easy because the learned temperatures stayed small (largest 3.35) and positive attention stayed diffuse. Equation 11 alone would have failed 3 of the 40 learned-τ heads on LRA-Image, and the dependency-aware certificate covered them.

The exploratory models that did learn retrieval tell the other half (Section 7.3).

- **The target is not certified for them.** 75.7–89.3% of queries were certified at ρ = 0.02.
- **For the 8×8 models the miss is real.** In their selecting heads, 40–69% of the sampled queries had a witness above 0.1. Those heads hold a quarter of each model's queries. If the sample is representative, about 10–17% of all queries miss the target, which leaves at most about 83–90% meeting it, against the 95% registered. This is an estimate from a subsample, not a bound.
- **The 4×4 model is undecided.** The fraction of its queries that meet the target lies between the certified 89.3% and an estimated 95.7%.
- **Signed attention misses it too.** Under the same box, the signed control's witnesses exceeded 0.1 on 10–17% of sampled queries per head on LRA-Image, and on 59.5% in its retrieving head (Section 7.4, seed 0).

So the target was met only where attention did not select. Signed attention, which was more selective, missed it on both tasks where we looked.

**Does τ grow like $\sqrt{pq}$?** The registered sweep cannot say. Its positive models never selected, and their temperatures stayed near 1 at both token sizes. In the exploratory models that did select, the temperature was 13.8 with 4×4 tokens and 24–35 with 8×8, a ratio of 1.7–2.5 against $\sqrt{pq}$'s 2. This is consistent with the growth that the diagnostic describes, but it rests on one learned 4×4 model. Equation 11 was far above the target for all of them (0.50–0.88).

**The fallback.** Paper II's fallback is accurate signed scoring with certified local value or expert ranges. Our results point there for content retrieval: signed scoring on the same positive tokens (Sp) matched S on both tasks where it ran. The positive encoding, which costs nothing in an LNS, can therefore stay. The positive score cannot, at least not with the training budget and initialisation used here. Section 7.4 adds a caveat for the fallback: what it certifies should be values, experts or decisions, not the attention distribution, because signed attention misses the TV target too.

# 9 Discussion

**Paper II's open certification problem has a usable answer at the registered radius.** Paper II asked for a certificate that sees the dependence between scores, because all scores share the same four factors. Proposition 4 gives one.

- **Why it works.** Every score is a log-sum-exp of affine functions of the factor log perturbations, and each monomial contains one entry of every factor. Hence the relative score variation of a key pair is linear in $d$ up to $\pm8\rho^2$.
- **What it gives.** $\Omega_i$ is known to within $16\tau\rho^2$, and an explicit vertex closes the gap from below.
- **Using the attention itself.** Proposition 5 weights the exposure by the attention distribution.
- **How tight.** On the confirmatory models, the best witness reached 0.39–0.66 of the certificate in the median over heads, and 0.24–0.86 in single heads. In the selecting heads of the exploratory models that learned retrieval it reached 0.42–0.55. The ratio was smallest, 0.07, in one exploratory head whose witnesses were below 0.001, where the certificate's second-order term dominates. Equation 11 was 5.7–29 times the median witness on the confirmatory models.
- **What it costs.** It needs no search or branching, at $O(N^2P)$ per head. In our float64 implementation that is about 37 forward passes of the model. The remaining gap to the truth comes from letting each key choose its own worst sign pattern, and from the second-order term. Closing the first is a cut-norm problem [17].

**Selectivity by content is exposure.** Attention is selective when the logits separate across keys. It is exposed when the factor masses of different keys differ, because then a factor perturbation can move the scores apart. τ multiplies both, so their ratio does not depend on τ, and raising τ cannot buy certified selectivity.

- **Gain.** Gain separates scores without exposure (Proposition 4(c)). Most of the spread of dense random tokens was of this kind (Section 5).
- **Content.** Content separates scores by loading different factor entries, and that loading is exposure. In the exploratory models that learned retrieval, the exposure per unit of log-score separation was no larger than in pools that stayed certifiable. Selection came from temperatures of 24–35, which multiplied the exposure too. The box genuinely moved their selecting heads: in the 8×8 models, 12.5–32.5% of decision queries had a witnessed TV above 0.1.
- **The criterion.** Proposition 4 alone certifies a query whose logits spread by σ when its log-score spread is at least $\sigma(\rho D_i+8\rho^2)/0.401$, about $\sigma(D_i/20+0.008)$ at ρ = 0.02. The selecting heads had σ ≈ 8–10 and $D_i$ ≈ 3.5–4.1. They would have needed log-score spreads of about 1.5–1.9, and they had 0.28–0.35. At ρ = 0.01, 85–99.6% of their models' queries and 86–99% of their decision queries were certified.

**Positivity made selection hard to learn.**

- **Within the matched budget.** Positive scoring did not learn content retrieval: 17–20% against 99.4% for signed scoring.
- **Not the encoding.** The encoding baseline Sp used the same positive tokens and matched S, which rules the encoding out.
- **The start.** At initialisation, positive scores are overlaps of positively pooled averages. In the first layer on the retrieval task, their logit spread was 0.04–0.05 against 0.41 for signed scoring, and their attention was uniform over all 64 tokens (Appendix C, exploratory).
- **The escape** (exploratory). Sparse pools broke this symmetry eventually, with three times the steps. Dense positive scoring, in one seed each, concentrated its attention but not on the matching key. This matches the known difficulty of positive-feature linear attention with associative recall [22].

**Selection misses the target under either sign.** When positive attention did learn (exploratory), it selected with large temperatures and a factor loading that the box can move, and the registered target failed. Signed attention missed it too, under the same box, on both tasks (Section 7.4). Where the target was met, it was met because attention did not select.

**When positive attention is free.**

- **On LRA-Image.** Attention was not needed at this scale: the attention-free control was the most accurate model. Positive attention stayed nearly uniform (46–57 effective keys of 64) and was 3.1–4.7 points more accurate than signed scoring, which lost 6.0 points to the attention-free control. Equation 11 alone certified all but 3 of the 40 learned-temperature heads, and the dependency-aware bounds certified those 3 as well. Signed attention on the same task was witnessed above 0.1 on 10–17% of sampled queries per head.
- **What that buys.** Positive Kronecker attention is a certifiable, conversion-free pooling operator. Its τ = 1 form was 2.1–4.7 times faster than signed softmax at 256–1024 tokens in our CPU timings.
- **The limit.** That is a real but narrow role. It is not the role that P2 registered, which was matched accuracy where attention matters.

**The registered target is the wrong shape for selective attention.** A total-variation bound of 0.1 on every query constrains the whole attention distribution. In the selecting heads, witness perturbations that moved the decision query's attention by up to 0.31 changed 2.0–13.5% of predictions. Most decisions survived them. Signed attention, the fallback, misses the target as well. Two targets could replace it.

- **A decision-level target.** Certify the output, as P1 did [3].
- **A radius matched to the selectivity the task needs.** For example, ρ = 0.01 for heads that must pick one key in seven at τ ≈ 30. That radius certified 86–93% of the decision queries of our 8×8 models.

Either would be a new registration. We record the observation and do not claim either target as met.

**Implications for the programme.**

- **YAKAL.** For content retrieval our results support Paper II's fallback: signed scoring on positive tokens (the Sp design, which cost nothing in accuracy), with certificates moved to the value path, to expert ranges [1] or to decisions. Signed attention missed the TV target wherever it selected (Section 7.4), so the fallback should not promise certified attention distributions.
- **The certificate machinery.** Propositions 4 and 5 are not specific to attention. They apply to any positive multilinear score with shared positive parameters, including the opponent decks of the basal-ganglia model (P4) and the consolidated Kronecker factors of the memory design (P3) [2]. In both, one factor enters many quantities, and common gain cancels.
- **A lesson for P3 and P4.** Exposure, not width, is the quantity to measure. P1 found the same for readouts: a uniform box rewards decisive evidence, not abundant evidence [3].

**Limitations.**

- **Scale.** The models were small (40,650 parameters, two layers, two heads) and trained briefly on CPU. Pathfinder stayed at chance at about 1% of the examples that LRA's own runs used, and LRA-Image did not need attention at this scale. A larger study could reverse either.
- **Post hoc evidence.** The retrieval task was added after a pilot, and its positive variants were tuned on a two-point grid, which selected the smaller learning rate from chance-level pilots. Every result that shows positive scoring learning the task is exploratory and post hoc, with three seeds for pools and one for P1 and Pt. Only one 4×4 model learned, so the evidence on token size is thin.
- **Signed scoring.** We did not develop a certificate for signed scoring. Its comparison with positive scoring rests on witnesses, for one seed per variant.
- **Numerics.** Certificates are real-arithmetic bounds evaluated in float64 at nominal float32 tokens, without outward rounding.
- **What is certified.** Each layer is certified at its nominal input, so perturbations do not propagate between layers. Values and the MLP are not certified.
- **Witnesses.** The witnesses come from a heuristic search, so they bound the worst case from below without locating it. Fractions of queries above 0.1 come from sampled query positions, so their extension to all queries is an estimate.
- **Latency.** Latency was measured in floating point on a CPU, not on LNS hardware.

# 10 Conclusion

P2 asked whether positive Kronecker attention keeps accuracy and certified attention under a factor box.

**The certificate.** The certification problem that Paper II left open has a short answer. Positive Kronecker scores are log-sum-exps of affine functions of the factor log perturbations, so the relative score variation is linear in the perturbation up to $\pm8\rho^2$. Weighting each key's exposure by its attention gives certificates that, for a typical query of a confirmatory model, are at most 1.5–2.6 times its true worst case, at a cost of $O(N^2P)$ per head.

**The operating point.** The registered operating point did not survive a task that tested attention.

- **LRA-Image** at this scale needs no attention. The positive variants met Paper II's two criteria there, but the attention-free control beat them all.
- **Pathfinder** was out of reach of our budget.
- **Retrieval.** On the task where attention was necessary, positive scoring did not learn within the matched budget, and the signed control solved it.
- **With more training** (exploratory). Given three times the steps, sparse positive pools did learn, with nearly hard pools and sharp temperatures. Factor perturbations of 2% then moved the attention of 12.5–32.5% of their decision queries by more than 0.1.

Selecting by content loads a key's score onto its own factor entries, and the temperature that selection needs multiplies that exposure. In our models, positive attention was certifiable when it pooled and not when it selected. Signed attention missed the target on both tasks under the same box (exploratory).

**For the programme.** Keep the positive token encoding, which costs nothing. Use signed scoring when attention must select, and certify the values or the decision instead, as Paper II's fallback prescribes. Carry Propositions 4 and 5 to the other places where shared positive factors enter many quantities at once: memory consolidation (P3) and opponent action selection (P4).

# References

[1] Ghosh, Debi Prasad. (2026). *Interval Transformers with Exact Local Weight Ranges and Sparse Expert Routing*. Manuscript, 1 October 2026.

[2] Ghosh, Debi Prasad. (2026). *Log Interval Networks for Certified Decisions and Structured Memory*. Research programme with reproducible numerical checks, 1 October 2026.

[3] Ghosh, Debi Prasad. (2026). *Log Interval Networks for Evidence Accumulation and Certified Decisions*. P1 of the log interval network programme, 4 October 2026.

[4] Dibya Ghosh, Dyuti Ghosh, and Debi Prasad Ghosh. (2025). *Yet Another Kronecker Attention in LNS (YAKAL): Fusing Algebraic Structure and Logarithmic Arithmetic for Efficient Self-Attention*. Manuscript dated 30 September. https://doi.org/10.13140/RG.2.2.26466.80329

[5] Dibya Ghosh, Dyuti Ghosh, and Debi Prasad Ghosh. (2024). *Matrix Transformers: A New Paradigm for Long-Range Dependency Modeling*. https://doi.org/10.13140/RG.2.2.32514.49602

[6] Tay, Y., Dehghani, M., Abnar, S., Shen, Y., Bahri, D., Pham, P., Rao, J., Yang, L., Ruder, S., and Metzler, D. (2021). Long Range Arena: A Benchmark for Efficient Transformers. *ICLR 2021*. arXiv:2011.04006. https://arxiv.org/abs/2011.04006

[7] Linsley, D., Kim, J., Veerabadran, V., Windolf, C., and Serre, T. (2018). Learning long-range spatial dependencies with horizontal gated recurrent units. *Advances in Neural Information Processing Systems*, 31. https://proceedings.neurips.cc/paper/2018/hash/ec8956637a99787bd197eacd77acce5e-Abstract.html

[8] Kim, J., Linsley, D., Thakkar, K., and Serre, T. (2020). Disentangling neural mechanisms for perceptual grouping. *ICLR 2020*. https://openreview.net/forum?id=HJxrVA4FDS

[9] Krizhevsky, A. (2009). *Learning Multiple Layers of Features from Tiny Images*. Technical report, University of Toronto.

[10] Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, J., Jones, L., Gomez, A. N., Kaiser, Ł., and Polosukhin, I. (2017). Attention Is All You Need. *Advances in Neural Information Processing Systems*, 30. arXiv:1706.03762. https://arxiv.org/abs/1706.03762

[11] Katharopoulos, A., Vyas, A., Pappas, N., and Fleuret, F. (2020). Transformers are RNNs: Fast Autoregressive Transformers with Linear Attention. *Proceedings of ICML*, PMLR 119, 5156–5165. https://proceedings.mlr.press/v119/katharopoulos20a.html

[12] Kingma, D. P., and Ba, J. (2015). Adam: A Method for Stochastic Optimization. *ICLR 2015*. arXiv:1412.6980. https://arxiv.org/abs/1412.6980

[13] Dinkelbach, W. (1967). On Nonlinear Fractional Programming. *Management Science*, 13(7), 492–498. https://doi.org/10.1287/mnsc.13.7.492

[14] Karnik, N. N., and Mendel, J. M. (2001). Centroid of a type-2 fuzzy set. *Information Sciences*, 132, 195–220. https://doi.org/10.1016/S0020-0255(01)00069-X

[15] Bennett, G. (1962). Probability Inequalities for the Sum of Independent Random Variables. *Journal of the American Statistical Association*, 57(297), 33–45. https://doi.org/10.1080/01621459.1962.10482149

[16] Tsybakov, A. B. (2009). *Introduction to Nonparametric Estimation*. Springer. (Pinsker's inequality, Lemma 2.5.) https://doi.org/10.1007/b13794

[17] Alon, N., and Naor, A. (2006). Approximating the cut-norm via Grothendieck's inequality. *SIAM Journal on Computing*, 35(4), 787–803. https://doi.org/10.1137/S0097539704441629

[18] Moore, R. E. (1966). *Interval Analysis*. Prentice-Hall.

[19] Weng, T.-W., Zhao, P., Liu, S., Chen, P.-Y., Lin, X., and Daniel, L. (2020). Towards Certificated Model Robustness Against Weight Perturbations. *Proceedings of the AAAI Conference on Artificial Intelligence*, 34(04), 6356–6363. https://doi.org/10.1609/aaai.v34i04.6105

[20] Tsai, Y.-L., Hsu, C.-Y., Yu, C.-M., and Chen, P.-Y. (2021). Formalizing Generalization and Adversarial Robustness of Neural Networks to Weight Perturbations. *Advances in Neural Information Processing Systems*, 34, 19692–19704. https://proceedings.neurips.cc/paper/2021/hash/a3ab4ff8fa4deed2e3bae3a5077675f0-Abstract.html

[21] Shi, Z., Zhang, H., Chang, K.-W., Huang, M., and Hsieh, C.-J. (2020). Robustness Verification for Transformers. *ICLR 2020*. https://openreview.net/forum?id=BJxwPJHFwS

[22] Arora, S., Eyuboglu, S., Timalsina, A., Johnson, I., Poli, M., Zou, J., Rudra, A., and Ré, C. (2024). Zoology: Measuring and Improving Recall in Efficient Language Models. *ICLR 2024*. arXiv:2312.04927. https://arxiv.org/abs/2312.04927

[23] Miyashita, D., Lee, E. H., and Murmann, B. (2016). Convolutional Neural Networks using Logarithmic Data Representation. arXiv:1603.01025. https://arxiv.org/abs/1603.01025

[24] Ghosh, Debi Prasad. (2026). *Log-Interval Networks: The Next Research Programme for the Interval Transformer*. Research agenda, 1 October 2026.

# Appendix A. Reproduction

The supplement contains every script, the frozen configurations, the evaluation summaries and the logs. It does not contain the trained parameters or the generated data, which the scripts regenerate deterministically.

**Environment.** Python 3.11; NumPy 2.4.4, SciPy 1.17.1, Matplotlib 3.10.9; JAX 0.10.2 on CPU with one thread per process; OpenCV 4.13.0 and Pillow 12.2.0 for the Pathfinder generator. Two CPU cores.

**Data.**

- **CIFAR-10.** The python batches from a public mirror, with MD5 sums `c99cafc1…`, `d4bba439…`, `54ebc095…`, `634d1841…`, `482c414d…` (data batches 1–5) and `40351d58…` (test batch). These are the canonical values.
- **Pathfinder-32 (hard).** Regenerated by `pf_gen.py` (shards 0–9, seed 20261010 + 1000·k). `runs/config_pathfinder.json` lists the SHA-256 of every shard's images and labels.
- **Retrieval.** Generated by `retrieval_data.py` from seeds 20261020–20261023.

**Commands**, in order:

```
python3 verify_p2_theory.py > verify_p2_theory_output.txt      # T1-T9, about 2 minutes
python3 l10_repeat.py > l10_repeat_output.txt                  # Section 5, seconds
python3 pf_gen.py <k> 10000 data/pf/shard_<k>.npz              # k = 0..9, about 15 minutes each
python3 pf_cache_check.py 200 > report/pf_cache_check.txt      # Section 4.1, about 3 minutes
python3 retrieval_reference.py > report/retrieval_reference.txt # Section 4.1, codebook decoder
python3 p2_run.py pilot image | pathfinder | retrieval         # learning-rate pilots (validation only)
python3 p2_run.py freeze image | pathfinder | retrieval        # writes runs/config_<task>.json
python3 p2_run.py confirm image                                # 30 runs
python3 p2_run.py confirm retrieval                            # 30 runs
python3 p2_run.py confirm pathfinder S,U 0,1                   # amended: 4 runs
python3 p2_run.py sweep                                        # registered token-size sweep, 9 runs
python3 p2_run.py explore && python3 p2_run.py explore2 && python3 p2_run.py explore3   # exploratory
python3 p2_image_code_check.py                                 # Section 4: LRA-Image models under the frozen code
python3 p2_eval.py <task> test [run ...]                       # frozen evaluator
python3 p2_explore_witness.py <run>                            # Section 7.3
python3 p2_signed_witness.py                                   # Section 7.4
python3 p2_init_stats.py && python3 p2_pool_entropy.py         # Appendix C
python3 p2_latency.py                                          # Section 7.5
python3 p2_report.py && python3 p2_facts.py                    # tables, figures, quoted numbers
```

**Frozen code.** The evaluator was frozen before any test example was used. The SHA-256 sums are in `evals_code_sha256.txt`:

    04481dea7a00ab7aec09e5be7a6719094f08a91bde7b17b0c1998d0e4a4d7aec  p2_eval.py
    e6dacb90df0e217926eee28bc376bb3a94dfe0a3cd4d28916319741f36b2cf3e  p2cert.py
    67e4d99618fe6ed2d8fcf930385a61414b90024af1612438d8cb5b90698afc78  p2cert_jax.py
    b273ae6ed64df3b83c27e3fd10fe2b6e098a4a546b0ec78c023127b9f7015464  p2lib.py
    6be126b93d98e8257646a3317cf63f07dcec9bb5c3162f975dcf296d0389f567  retrieval_data.py
    frozen 2026-10-04T14:37:27Z
    amendment 2026-10-04T15:08:22Z: p2lib.py gained an optional cfg['tau0'] (initial temperature, default 1.0 = old behaviour) for exploratory runs; evaluation code paths unchanged; new sha256 c51ad151797534d4604b15778caf2be3722d5f986dc2558fb69b2c1287d3254b

After freezing, `p2lib.py` gained one optional argument (the initial temperature, default 1) for the exploratory runs. The evaluation code paths did not change, and the amendment and new hash are recorded in the same file. The LRA-Image models were trained with an earlier revision of `p2lib.py` and `p2_run.py`, whose hashes `runs/config_image.json` records (`170597…` and `c9e76e…`). `p2_image_code_check.py` recomputes the validation accuracy of all 30 of them with the frozen `p2lib.py` (as amended) and finds every value identical to the one recorded at training time (`report/image_code_check.txt`).

**Compute.** About 18 CPU core-hours in all:

- Pathfinder generation, about 2.5 core-hours;
- training, 121 recorded runs: 36 pilots, 64 confirmatory, 9 sweep and 12 exploratory. Nine early design runs were not kept;
- evaluation, about 2 minutes per positive model and seconds per signed one, plus the exploratory witness searches of Sections 7.3 and 7.4.

# Appendix B. Per-seed results

**LRA-Image.**

| Variant | Seed | Accuracy (%) | Certified at 0.02 (%) | τ per layer and head |
|---|---:|---:|---:|---|
| S | 0 | 43.12 | – | – |
| S | 1 | 46.35 | – | – |
| S | 2 | 47.73 | – | – |
| S | 3 | 48.24 | – | – |
| S | 4 | 46.13 | – | – |
| Sp | 0 | 44.24 | – | – |
| Sp | 1 | 47.11 | – | – |
| Sp | 2 | 47.88 | – | – |
| Sp | 3 | 47.75 | – | – |
| Sp | 4 | 47.06 | – | – |
| P1 | 0 | 49.29 | 100.00 | – |
| P1 | 1 | 49.01 | 100.00 | – |
| P1 | 2 | 52.07 | 100.00 | – |
| P1 | 3 | 52.95 | 100.00 | – |
| P1 | 4 | 51.53 | 100.00 | – |
| Pt | 0 | 44.78 | 100.00 | 2.07, 1.79, 2.09, 1.20 |
| Pt | 1 | 47.29 | 100.00 | 2.12, 2.03, 1.12, 1.97 |
| Pt | 2 | 51.97 | 100.00 | 1.35, 1.52, 1.81, 1.80 |
| Pt | 3 | 52.39 | 100.00 | 1.46, 1.79, 1.41, 1.76 |
| Pt | 4 | 50.73 | 100.00 | 2.87, 2.43, 1.46, 1.63 |
| Pool | 0 | 47.92 | 100.00 | 2.42, 1.97, 1.30, 0.99 |
| Pool | 1 | 49.38 | 100.00 | 1.72, 2.07, 0.89, 1.80 |
| Pool | 2 | 51.88 | 100.00 | 1.71, 1.95, 1.52, 1.76 |
| Pool | 3 | 53.63 | 100.00 | 1.94, 2.37, 1.16, 1.85 |
| Pool | 4 | 51.37 | 100.00 | 3.35, 2.93, 1.16, 1.47 |
| U | 0 | 51.18 | – | – |
| U | 1 | 50.86 | – | – |
| U | 2 | 53.89 | – | – |
| U | 3 | 53.98 | – | – |
| U | 4 | 51.86 | – | – |

**Pathfinder-32.**

| Variant | Seed | Accuracy (%) | Certified at 0.02 (%) | τ per layer and head |
|---|---:|---:|---:|---|
| S | 0 | 49.56 | – | – |
| S | 1 | 49.37 | – | – |
| U | 0 | 49.70 | – | – |
| U | 1 | 49.97 | – | – |

**Retrieval.**

| Variant | Seed | Accuracy (%) | Certified at 0.02 (%) | τ per layer and head |
|---|---:|---:|---:|---|
| S | 0 | 99.39 | – | – |
| S | 1 | 99.32 | – | – |
| S | 2 | 99.31 | – | – |
| S | 3 | 99.38 | – | – |
| S | 4 | 99.38 | – | – |
| Sp | 0 | 99.30 | – | – |
| Sp | 1 | 99.35 | – | – |
| Sp | 2 | 99.33 | – | – |
| Sp | 3 | 99.23 | – | – |
| Sp | 4 | 99.31 | – | – |
| P1 | 0 | 12.92 | 100.00 | – |
| P1 | 1 | 15.40 | 100.00 | – |
| P1 | 2 | 22.13 | 100.00 | – |
| P1 | 3 | 15.12 | 100.00 | – |
| P1 | 4 | 22.56 | 100.00 | – |
| Pt | 0 | 12.93 | 100.00 | 1.03, 1.18, 1.02, 0.81 |
| Pt | 1 | 19.38 | 100.00 | 1.86, 1.48, 0.95, 0.93 |
| Pt | 2 | 23.02 | 100.00 | 1.37, 1.73, 1.48, 1.40 |
| Pt | 3 | 19.40 | 100.00 | 1.98, 1.54, 1.05, 1.06 |
| Pt | 4 | 23.23 | 100.00 | 1.45, 1.85, 1.39, 1.07 |
| Pool | 0 | 12.80 | 100.00 | 1.02, 1.14, 1.02, 0.74 |
| Pool | 1 | 14.67 | 100.00 | 1.33, 1.86, 0.93, 0.95 |
| Pool | 2 | 18.94 | 100.00 | 1.31, 1.59, 1.43, 1.26 |
| Pool | 3 | 19.64 | 100.00 | 1.94, 1.66, 1.00, 1.08 |
| Pool | 4 | 20.51 | 100.00 | 1.40, 2.10, 1.51, 1.22 |
| U | 0 | 12.64 | – | – |
| U | 1 | 13.59 | – | – |
| U | 2 | 14.37 | – | – |
| U | 3 | 12.93 | – | – |
| U | 4 | 14.24 | – | – |

# Appendix C. Pilots, initial statistics and pools

The pilots were part of the protocol. The statistics at initialisation and the pool entropies are exploratory analyses made after the confirmatory results.

**Learning-rate pilots** (validation accuracy %, seed 100). The rule chose the larger value where it was better and the smaller value otherwise.

| Task | S | Sp | P1 | Pt | Pool | U |
|---|---|---|---|---|---|---|
| LRA-Image, 4 epochs: $10^{-3}$ / $3\cdot10^{-3}$ | 39.14 / 42.06 | 39.10 / 41.58 | 37.74 / 46.68 | 37.78 / 46.46 | 37.72 / 45.50 | 37.92 / 47.00 |
| Pathfinder, 3 epochs | 49.88 / 49.58 | 49.95 / 49.73 | 49.98 / 49.95 | 49.98 / 49.94 | 50.11 / 50.07 | 50.02 / 49.94 |
| Retrieval, 2 epochs | 14.66 / 98.88 | 73.52 / 98.77 | 10.68 / 10.29 | 10.67 / 10.28 | 10.55 / 10.16 | 10.62 / 10.28 |

**Attention at initialisation** (retrieval task, 500 validation examples, seed 0; exploratory). The logit spread is the median over queries of the SD over keys of the attention logits. Effective keys are out of 64.

| Variant | Layer 1: logit spread | Layer 1: effective keys | Layer 2: logit spread | Layer 2: effective keys |
|---|---:|---:|---:|---:|
| S | 0.413 | 59.0 | 0.041 | 63.9 |
| Sp | 2.833 | 7.3 | 0.245 | 62.3 |
| P1 and Pt | 0.051 | 63.9 | 0.010 | 64.0 |
| Pool | 0.038 | 64.0 | 0.007 | 64.0 |

**Pool sparsity** (exploratory, `p2_pool_entropy.py`). The mean entropy of a pool-factor column is at most ln 4 = 1.386 nats. Per head, it was:

- 0.83–0.92 in the confirmatory retrieval Pool models (model means 0.86–0.89);
- 0.08–0.51 in the LRA-Image Pool models (model means 0.22–0.32);
- 0.22–0.36 in the 4-epoch exploratory runs at learning rate $3\cdot10^{-3}$ (model means 0.24–0.32);
- 0.03–0.12 in the 12-epoch 8×8 models that learned the retrieval task (model means 0.04–0.07), whose factor columns put on average 0.965–0.996 of their weight on one pool;
- 0.02–0.08 in the 12-epoch 4×4 models, with model means of 0.033 for the one that learned and 0.026 and 0.038 for the two that did not.
