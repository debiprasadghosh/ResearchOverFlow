# P2 protocol: positive Kronecker attention with dependency control

Written on 4 October 2026, before any confirmatory run and before any test example was read. It executes Paper II, Section 5. Items marked *pilot* are fixed by validation-only pilots and recorded in `runs/config.json` before the confirmatory runs. The evaluator `p2_eval.py` and the certificate library `p2cert.py` are frozen (SHA-256 in `evals_code_sha256.txt`) before the test split is evaluated.

## 1 Data

- **LRA-Image.** CIFAR-10 (python version; MD5 sums checked against the canonical values), converted to grayscale with LRA's operation (`tf.image.rgb_to_grayscale` on uint8: weights 0.2989, 0.5870, 0.1140, then ×255.5 and truncation). Split as in LRA: the first 45,000 training images for training, the last 5,000 for validation, the 10,000 test images for testing.
- **Pathfinder-32, hard (contour length 14).** The released LRA files are not reachable from our environment, so the data are regenerated with the original generator (github.com/drewlinsley/pathfinder, commit 7b53886) and the Pathfinder32 settings listed in LRA's TFDS builder. The repository's latest commit replaced `scipy.misc.imresize/imsave` by PIL calls that skip byte scaling; we restore the scipy semantics. Two caches make generation about three times faster and were checked to reproduce the uncached generator bit for bit. Shards of 10,000 images, with seed 20261010 + 1000·k for shard k. Test: shards 0–1. Validation: shards 2–3. Training: shards 4–9. That is 100,000 images, split 60,000/20,000/20,000. *Amendment, made before any Pathfinder model was trained:* generation ran at about 0.09 s per image on our two cores, so the training set was cut from LRA's 160,000 to 60,000 images (shards 4–9). The validation and test sizes are LRA's.
- **Controlled retrieval** *(added task; amendment made after the LRA-Image pilot and before any confirmatory run on this task)*. In the LRA-Image pilot the attention-free control U had the highest validation accuracy, so LRA-Image may not test attention at all. We therefore add a task on which attention is necessary by construction (`retrieval_data.py`).
  - **Tokens.** 64 tokens of 4×4 pixels. Rows 0–2 carry one of 8 sparse codes (3 of 12 pixels lit). Row 3 carries a value from 0 to 9 as four bits.
  - **Query and keys.** Token 0 is the query, with code c and the marker 1111. Tokens 1–7 are keys with distinct codes, exactly one of which is c, and each key has its own random value. Tokens 8–63 are blank.
  - **Label and noise.** The label is the value of the matching key. Intensities are $0.2+0.6\cdot$pattern plus Gaussian noise of standard deviation 0.1.
  - **Splits.** 50,000 training, 10,000 validation and 20,000 test examples, from fixed seeds.
  - **Readout.** The model reads out token 0 instead of the token mean. Everything else is identical to the LRA tasks.
  - **Reference.** A codebook decoder that knows the codes reaches 99.4% on 3,000 generated examples.
  - **Earlier design.** A first design with 63 keys, 16 codes and noise 0.15 was abandoned after the signed control stayed at chance (10.4–10.9% validation accuracy) for 3 pilot epochs at both learning rates. No other variant was run on it.

## 2 Model

A matrix-token classifier in the YAKAL design. Non-overlapping 4×4 patches give 64 tokens. A dense embedding maps each patch to a p×q matrix token and adds a learned positional matrix. There are L pre-LN blocks, each an attention block (H heads) and an MLP. The head mean-pools the tokens and applies a linear map.

Each head has queries and keys $Q_i=B_qY_iA_q^\top$ and $K_j=B_kY_jA_k^\top$ (r×t), values $V_j=B_vZ_jA_v^\top$ (rᵥ×tᵥ) from the signed normalised tokens $Z=\mathrm{LN}(X)$, and a Kronecker output map back to p×q. The variants differ only in how queries and keys are scored:

| Variant | Tokens $Y$ for $Q,K$ | Factors | Attention |
|---|---|---|---|
| S (signed YAKAL, matched signed control) | $Z$ | signed | $\mathrm{softmax}(\langle Q_i,K_j\rangle/\sqrt{rt})$ |
| Sp (encoding baseline) | $e^{Z}$ | signed | $\mathrm{softmax}(\langle Q_i,K_j\rangle/\sqrt{rt})$ |
| P1 (positive YAKAL, τ = 1) | $e^{Z}$ | $e^{\theta}$ | $a_{ij}\propto s_{ij}$, computed by linear reassociation |
| Pt (learned τ) | $e^{Z}$ | $e^{\theta}$ | $a_{ij}\propto s_{ij}^{\tau_h}$, $\tau_h=e^{\lambda_h}$ learned, starting at 1 |
| Pool (sparse positive pools) | $e^{Z}$ | column-stochastic: $\mathrm{softmax}$ over output rows, with entropy penalty 0.1 × mean column entropy | $a_{ij}\propto s_{ij}^{\tau_h}$, learned τ |
| U (attention off) | – | – | $a_{ij}=1/N$ |

The positive encoding $e^{Z}$ is outside the uncertain computation. In LNS its log is $Z$ itself.

**Architecture.** p = q = 8, r = t = 4, rᵥ = tᵥ = 4, H = 2, L = 2, MLP width 128.

**Training.** Adam (0.9, 0.999), batch 128, 200 warm-up steps, then cosine decay to zero; gradient norm clipped at 1. Epochs: 8 for LRA-Image, 5 for Pathfinder and 4 for the retrieval task (2,808, 2,340 and 1,560 steps).

**Matched budget.** All variants share the architecture, token size, parameter count (Pt and Pool add one τ per head) and training schedule.

**Learning rate** *(pilot)*. For each task and variant, chosen from {10⁻³, 3·10⁻³} by validation accuracy after a short schedule, with seed 100. Ties go to the smaller value. The schedule is 4 epochs for LRA-Image, 3 epochs of the 60,000 training images for Pathfinder, and 2 epochs for the retrieval task.

**Seeds.** 0–4 for every task and variant.

## 3 Uncertainty set and certificates

Every entry of the four query and key factors of every head is multiplied by $e^{d}$ with $|d|\le\rho$, independently. Each layer is certified at its nominal input tokens, as Paper II specifies ("at fixed positive tokens"). A **held-out query** is a test image × layer × head × query position. Certificates and attention statistics are computed on the first 2,000 test images of each task, which gives 2,000 × 2 × 2 × 64 = 512,000 queries per model. Accuracy uses the whole test set. The subsample keeps the float64 evaluation affordable: about two minutes per model on one core.

A query is **certified** if a sound upper bound on $\sup_\theta\mathrm{TV}(a_i(\theta),a_i^0)$ is at most 0.1. The frozen evaluator takes the smallest of four sound bounds, each proved in the paper and checked in `verify_p2_theory.py`:

1. Eq. 11, $\tanh(2\tau\rho)$;
2. $\tanh(\bar\Omega_i/4)$, with $\bar\Omega_i=\tau(\rho\bar D_i+8\rho^2)$, where $\bar D_i$ bounds the $\ell_1$ diameter of the factor-mass vectors;
3. the Bennett–Pinsker bound;
4. the $\ell_1$ bound.

## 4 Registered criteria

**Certification target** (Paper II): TV ≤ 0.1 for at least 95% of held-out queries at factor log radius ρ = 0.02. The certified fraction is computed per seed, and the target is met if the mean over seeds is at least 95%. The minimum over seeds is also reported.

**Accuracy criterion** (Paper II): seed-mean test accuracy no more than 2.0 points below the matched signed control S on the same task.

**Verdict per task.**

- A positive variant (P1, Pt, Pool) passes if it meets both the accuracy criterion and the certification target.
- The proposed P2 operating point is supported on a task if at least one positive variant passes.
- It is rejected on that task if none passes, as Paper II specifies: accuracy over two points below the matched signed control, or no registered useful TV target met at equal cost. "Equal cost" means the model trained at the matched budget, with no extra training for certification.
- Each variant's outcome on each criterion is reported.

**Validity gate.** A task counts as informative about attention only if S beats U by at least 2.0 points (seed means, test). Otherwise its accuracy comparisons are reported as uninformative.

**Retrieval task.** The criteria and the gate apply unchanged. Paper II's registration names LRA-Image and Pathfinder, so the retrieval verdict is reported separately and labelled as an added task.

**Pathfinder amendment** *(made after the Pathfinder pilot and before any confirmatory Pathfinder run)*. In the pilot, every variant at both learning rates stayed at chance (49.6–50.1% validation accuracy after 3 epochs). The registered 30 runs would cost about three core-hours to confirm chance performance. The confirmatory Pathfinder runs are therefore cut to S and U with seeds 0–1 on the registered schedule, enough to decide the validity gate. No certificate is evaluated on Pathfinder: a model at chance has no attention worth certifying.

**Statistics.** Seed means with 95% t-intervals ($t_{0.975,4}=2.776$), and seed-paired differences against S.

## 5 Registered measurements (no decision rule)

- **Per held-out query:**
  - the learned τ per layer and head;
  - the log-score spread $\mathrm{SD}_j\log s_{ij}$ (positive scores), or the logit spread $\mathrm{SD}_j\, s_{ij}/\sqrt{rt}$ (signed scores);
  - the concentration-normalised spread, $\mathrm{SD}_j\log s_{ij}\cdot\sqrt{pq}$, which is constant if scores concentrate like averages of $pq$ independent entries;
  - the effective key count $\exp H(a_i)$;
  - each certificate at ρ ∈ {0.01, 0.02, 0.05}.
- **$\Omega_i$ bounds** on the first 100 test images (all queries): the exact diameter $D_i$, the sandwich $\tau(\rho D_i\mp8\rho^2)$, and the witnessed spread at the sign vertex.
- **Token size** (retrieval task): S, Pt and Pool are also trained with 4×4 tokens (MLP width 64), seeds 0–2. The diagnostic is whether the learned τ grows like $\sqrt{pq}$, a factor of 2 from 4×4 to 8×8 tokens. Such growth diagnoses failure of Eq. 11 and does not refute the correlated certificate. *Amendment, made before any sweep run:* the sweep was first planned on LRA-Image. It moved to the retrieval task because in the LRA-Image pilot the attention-free control had the best validation accuracy, so τ there is under no pressure to select.
- **Measured latency** of the attention block for each variant, on CPU.

## 6 Exploratory analyses (labelled as such)

- TV witnesses: explicit factor perturbations, evaluated exactly, on 16 query positions of the first 100 test images.
- A TV bound for the signed variants under the same sign-preserving factor box, computed from absolute masses.
- The Paper II L10 check repeated with token mass normalised (`l10_repeat.py`).
- Comparisons among the four certificates.
- *Added after the confirmatory retrieval results were seen (post hoc).* Retrieval runs of the positive variants with learning rate 3·10⁻³:
  - P1, Pt and Pool for 12 epochs, seed 0;
  - Pt with initial τ = 8 for 4 epochs;
  - Pool for 4 epochs (seeds 0–2) and for 12 epochs (seeds 1–2).

  All are evaluated with the frozen evaluator and reported as exploratory.
  - Pool with 4×4 tokens for 12 epochs (seeds 0–2), added because the registered token-size sweep left every positive model at chance, which leaves the τ-growth diagnostic without a model that selects.

## 7 Addendum, 5 October 2026 (after all confirmatory results and a first review; nothing here changes a registered item)

- *Exploratory, post hoc:* explicit witnesses for the signed variants S and Sp (seed 0) under the same sign-preserving box (`p2_signed_witness.py`), replacing the absolute-mass bound of Section 6 as the basis of the signed comparison; pool-factor entropies of every Pool model (`p2_pool_entropy.py`).
- *Checks:* `p2_image_code_check.py` recomputes the validation accuracy of the 30 LRA-Image models, which were trained with an earlier revision of `p2lib.py`/`p2_run.py`, under the frozen code; `pf_cache_check.py` repeats the cache check of Section 1 as a script; `retrieval_reference.py` makes the codebook-decoder reference of Section 1 reproducible (99.65% on the validation split, against the 99.4% design-time figure above).
- The L10 repetition listed in Section 6 is a check that Paper II registered; it is listed there only because it carries no decision rule.
