"""Certificates for positive Kronecker attention under a factor log box (P2).

Notation (Paper II, Section 5).  Query token X_i and key tokens X_j are positive p x q matrices.
Positive factors B_q, B_k (r x p) and A_q, A_k (t x q).  Q_i = B_q X_i A_q^T, K_j = B_k X_j A_k^T,
s_ij = <Q_i, K_j>_F, a_ij = s_ij^tau / sum_k s_ik^tau.  The box: every factor entry is multiplied by
exp(d_l) with |d_l| <= rho, independently.

Every score is a sum of monomials, each containing exactly one entry of every factor, so in the log
coordinates d the score is a log-sum-exp of affine functions.  The factor-mass vector G_ij (the
gradient of log s_ij at d = 0) is four probability distributions, one per factor:

    mu^{Bq}_ij = B_q o (K_j A_q X_i^T) / s_ij      mu^{Aq}_ij = A_q o (K_j^T B_q X_i) / s_ij
    mu^{Bk}_ij = B_k o (Q_i A_k X_j^T) / s_ij      mu^{Ak}_ij = A_k o (Q_i^T B_k X_j) / s_ij

Sandwich (Proposition 4):  for every d in the box and every pair of keys j, k,
    (G_ij - G_ik).d - 8 rho^2  <=  R_jk(d)  <=  (G_ij - G_ik).d + 8 rho^2,
    R_jk(d) = log(s_ij(d)/s_ij(0)) - log(s_ik(d)/s_ik(0)).
Hence Omega_i = tau * max_{j,k} sup_d R_jk(d) lies within tau*(rho*D_i -/+ 8 rho^2), D_i = max ||G_ij - G_ik||_1.

All functions use float64.
"""
import numpy as np

F64 = np.float64
ATANH_01 = np.arctanh(0.1)


# ---------------------------------------------------------------------------
# scores and factor masses
# ---------------------------------------------------------------------------
def scores(Bq, Aq, Bk, Ak, Xq, Xk):
    """Xq (M,p,q) queries, Xk (N,p,q) keys -> Q (M,r,t), K (N,r,t), s (M,N)."""
    Q = np.einsum('up,mpq,vq->muv', Bq, Xq, Aq, optimize=True)
    K = np.einsum('up,npq,vq->nuv', Bk, Xk, Ak, optimize=True)
    s = np.einsum('muv,nuv->mn', Q, K, optimize=True)
    return Q, K, s


def factor_masses(Bq, Aq, Bk, Ak, Xq, Xk):
    """G (M, N, P): for each query m and key n the four factor-mass distributions, flattened.

    P = 2 (r p + t q); blocks in the order Bq, Aq, Bk, Ak (row-major within a block)."""
    Q, K, s = scores(Bq, Aq, Bk, Ak, Xq, Xk)
    # K_j A_q X_i^T : (r,t)(t,q)(q,p) -> (r,p)
    AqXqT = np.einsum('vq,mpq->mvp', Aq, Xq, optimize=True)          # (M,t,p)
    mBq = Bq[None, None] * np.einsum('nuv,mvp->mnup', K, AqXqT, optimize=True)
    # K_j^T B_q X_i : (t,r)(r,p)(p,q) -> (t,q)
    BqXq = np.einsum('up,mpq->muq', Bq, Xq, optimize=True)           # (M,r,q)
    mAq = Aq[None, None] * np.einsum('nuv,muq->mnvq', K, BqXq, optimize=True)
    # Q_i A_k X_j^T : (r,t)(t,q)(q,p) -> (r,p)
    AkXkT = np.einsum('vq,npq->nvp', Ak, Xk, optimize=True)          # (N,t,p)
    mBk = Bk[None, None] * np.einsum('muv,nvp->mnup', Q, AkXkT, optimize=True)
    # Q_i^T B_k X_j : (t,r)(r,p)(p,q) -> (t,q)
    BkXk = np.einsum('up,npq->nuq', Bk, Xk, optimize=True)           # (N,r,q)
    mAk = Ak[None, None] * np.einsum('muv,nuq->mnvq', Q, BkXk, optimize=True)
    M, N = s.shape
    G = np.concatenate([mBq.reshape(M, N, -1), mAq.reshape(M, N, -1),
                        mBk.reshape(M, N, -1), mAk.reshape(M, N, -1)], axis=2) / s[:, :, None]
    return G, s


def factor_masses_images(Bq, Aq, Bk, Ak, Y):
    """Self-attention over each image: Y (n, N, p, q) -> G (n, N, N, P) for query i and key j, s (n, N, N)."""
    Q = np.einsum('up,inpq,vq->inuv', Bq, Y, Aq, optimize=True)
    K = np.einsum('up,inpq,vq->inuv', Bk, Y, Ak, optimize=True)
    s = np.einsum('iauv,ibuv->iab', Q, K, optimize=True)
    AqYT = np.einsum('vq,inpq->invp', Aq, Y, optimize=True)            # (n,N,t,p)
    BqY = np.einsum('up,inpq->inuq', Bq, Y, optimize=True)             # (n,N,r,q)
    AkYT = np.einsum('vq,inpq->invp', Ak, Y, optimize=True)
    BkY = np.einsum('up,inpq->inuq', Bk, Y, optimize=True)
    n, N = s.shape[0], s.shape[1]
    mBq = np.einsum('ibuv,iavp->iabup', K, AqYT, optimize=True) * Bq
    mAq = np.einsum('ibuv,iauq->iabvq', K, BqY, optimize=True) * Aq
    mBk = np.einsum('iauv,ibvp->iabup', Q, AkYT, optimize=True) * Bk
    mAk = np.einsum('iauv,ibuq->iabvq', Q, BkY, optimize=True) * Ak
    G = np.concatenate([mBq.reshape(n, N, N, -1), mAq.reshape(n, N, N, -1), mBk.reshape(n, N, N, -1),
                        mAk.reshape(n, N, N, -1)], axis=3)
    G /= s[..., None]
    return G, s


def perturb(factors, d_list):
    """Multiply each factor entrywise by exp(d)."""
    return [f * np.exp(d) for f, d in zip(factors, d_list)]


def split_d(d, shapes):
    """Flat log-perturbation vector (P,) -> list of arrays with the factor shapes."""
    out, k = [], 0
    for sh in shapes:
        n = int(np.prod(sh))
        out.append(d[k:k + n].reshape(sh))
        k += n
    return out


def attn_from_scores(s, tau):
    """a = s^tau / sum s^tau along the last axis, computed in log space."""
    z = tau * np.log(s)
    z = z - z.max(axis=-1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=-1, keepdims=True)


def tv(a, b):
    return 0.5 * np.abs(a - b).sum(axis=-1)


# ---------------------------------------------------------------------------
# bounds
# ---------------------------------------------------------------------------
def eq11(tau, rho):
    """Paper II Eq. 11: TV <= tanh(2 tau rho)."""
    return np.tanh(2.0 * tau * rho)


def psi(m):
    """Bennett factor (e^m - 1 - m)/m^2, increasing; psi(0) = 1/2."""
    m = np.asarray(m, dtype=F64)
    out = np.full(m.shape, 0.5)
    big = m > 1e-4
    mb = m[big]
    out[big] = np.expm1(mb) - mb
    out[big] /= mb * mb
    small = ~big
    ms = m[small]
    out[small] = 0.5 + ms / 6.0 + ms * ms / 24.0
    return out


def l1_diameter_exact(G):
    """D = max_{j,k} ||G_j - G_k||_1 for G (N, P); returns (D, j, k)."""
    N = G.shape[0]
    best, bj, bk = -1.0, 0, 0
    for j in range(N):
        dist = np.abs(G[j][None, :] - G).sum(axis=1)
        k = int(np.argmax(dist))
        if dist[k] > best:
            best, bj, bk = float(dist[k]), j, k
    return best, bj, bk


def phi(m):
    """(e^m - 1)/m, increasing; phi(0) = 1."""
    m = np.asarray(m, dtype=F64)
    out = np.ones(m.shape)
    big = m > 1e-6
    out[big] = np.expm1(m[big]) / m[big]
    out[~big] = 1.0 + m[~big] / 2.0
    return out


def certificates(G, a, tau, rho, exact_pairs=False):
    """Sound upper bounds on sup_d TV(a(d), a(0)) for one query.

    G (N, P) factor masses, a (N,) nominal attention, w_j = ||G_j - gbar||_1 with gbar = sum_j a_j G_j.
      eq11      tanh(2 tau rho)                                   [Eq. 11]
      D_up      upper bound on the L1 diameter of {G_j} (exact if exact_pairs)
      omega_up  tau (rho D_up + 8 rho^2), capped at 8 tau rho      [Proposition 4]
      c_omega   tanh(omega_up / 4)                                [Eq. 12 with the sandwich]
      M         tau (rho max_j w_j + 8 rho^2), capped at 8 tau rho  (bound on max_j e_j - mean)
      c_kl      sqrt(psi(M)/2) tau (rho RMS_a(w) + 4 rho^2)       [Proposition 5(a): Bennett + Pinsker]
      c_l1      phi(M) (tau/2) (rho mean_a(w) + 8 rho^2)          [Proposition 5(b)]
      cert      the smallest of eq11, c_omega, c_kl, c_l1
    """
    gbar = a @ G
    w = np.abs(G - gbar[None, :]).sum(axis=1)
    rng = G.max(axis=0) - G.min(axis=0)
    D_tri = min(2.0 * w.max(), rng.sum())
    out = {}
    if exact_pairs:
        D, j, k = l1_diameter_exact(G)
        out.update(D=D, pair=(j, k), omega_lo=tau * (rho * D - 8 * rho * rho))
        D_up = D
    else:
        D_up = D_tri
    cap = 8.0 * tau * rho
    om = min(tau * (rho * D_up + 8 * rho * rho), cap)
    M = min(tau * (rho * w.max() + 8 * rho * rho), cap)
    w_rms = float(np.sqrt(a @ (w * w)))
    w_mean = float(a @ w)
    c_kl = float(np.sqrt(psi(np.array([M]))[0] / 2.0) * tau * (rho * w_rms + 4.0 * rho * rho))
    c_l1 = float(phi(np.array([M]))[0] * 0.5 * tau * (rho * w_mean + 8.0 * rho * rho))
    out.update(eq11=float(eq11(tau, rho)), D_up=float(D_up), D_tri=float(D_tri), omega_up=float(om),
               c_omega=float(np.tanh(om / 4.0)), c_kl=c_kl, c_l1=c_l1, M=float(M), w_rms=w_rms, w_mean=w_mean)
    out['cert'] = min(out['eq11'], out['c_omega'], out['c_kl'], out['c_l1'])
    return out


def query_summaries(G, a):
    """Per-query summaries of the factor masses that the certificates need (independent of rho).

    G (M, N, P), a (M, N) -> dict of (M,) arrays: w_max, w_mean, w_rms, D_tri, and w (M, N)."""
    gbar = np.einsum('mn,mnp->mp', a, G)
    w = np.abs(G - gbar[:, None, :]).sum(axis=2)
    rng = (G.max(axis=1) - G.min(axis=1)).sum(axis=1)
    return {"w_max": w.max(axis=1), "w_mean": (a * w).sum(axis=1), "w_rms": np.sqrt((a * w * w).sum(axis=1)),
            "D_tri": np.minimum(2.0 * w.max(axis=1), rng), "w": w}


def certificates_from_summaries(S, tau, rho):
    """Certificates for every query from query_summaries() output."""
    cap = 8.0 * tau * rho
    om = np.minimum(tau * (rho * S["D_tri"] + 8 * rho * rho), cap)
    M = np.minimum(tau * (rho * S["w_max"] + 8 * rho * rho), cap)
    c_kl = np.sqrt(psi(M) / 2.0) * tau * (rho * S["w_rms"] + 4.0 * rho * rho)
    c_l1 = phi(M) * 0.5 * tau * (rho * S["w_mean"] + 8.0 * rho * rho)
    c_om = np.tanh(om / 4.0)
    e11 = np.full(om.shape, eq11(tau, rho))
    cert = np.minimum(np.minimum(e11, c_om), np.minimum(c_kl, c_l1))
    return {"eq11": e11, "omega_up": om, "c_omega": c_om, "c_kl": c_kl, "c_l1": c_l1, "M": M, "cert": cert}


def certificates_batch(G, a, tau, rho):
    """Vectorised certificates() without exact pairs. G (M, N, P), a (M, N)."""
    S = query_summaries(G, a)
    out = certificates_from_summaries(S, tau, rho)
    out.update({k: S[k] for k in ("D_tri", "w_mean", "w_rms", "w")})
    return out


def l1_diameters(G):
    """Exact L1 diameter of {G[m, j]}_j for every query m: G (M, N, P) -> D (M,), pair indices (M, 2)."""
    M, N, _ = G.shape
    D = np.empty(M)
    pairs = np.empty((M, 2), dtype=int)
    for m in range(M):
        dist = np.abs(G[m][:, None, :] - G[m][None, :, :]).sum(axis=2)
        k = int(np.argmax(dist))
        D[m] = dist.flat[k]
        pairs[m] = divmod(k, N)
    return D, pairs


# ---------------------------------------------------------------------------
# witnesses (lower bounds): explicit vertices of the box, evaluated exactly
# ---------------------------------------------------------------------------
def tv_at(factors, d, Xq, Xk, tau, a0):
    sh = [f.shape for f in factors]
    Bq, Aq, Bk, Ak = perturb(factors, split_d(d, sh))
    _, _, s = scores(Bq, Aq, Bk, Ak, Xq, Xk)
    return tv(attn_from_scores(s, tau), a0)


def tv_witness(factors, Xq_i, Xk, tau, rho, G_i, a_i, starts=4, iters=8):
    """Search vertices d in {-rho, rho}^P that maximise the first-order TV, (tau/2) sum_j a_j |v_j . d|,
    v_j = G_j - gbar, by sign iteration from several starts; return the best exact TV found and d."""
    gbar = a_i @ G_i
    V = G_i - gbar[None, :]
    order = np.argsort(-(a_i * np.abs(V).sum(axis=1)))
    cands = []
    for s0 in range(min(starts, len(order))):
        d = rho * np.sign(V[order[s0]] + 1e-300)
        for _ in range(iters):
            sig = np.sign(V @ d + 1e-300)
            d_new = rho * np.sign((a_i * sig) @ V + 1e-300)
            if np.array_equal(d_new, d):
                break
            d = d_new
        cands.append(d)
    best, best_d = -1.0, None
    for d in cands:
        val = float(tv_at(factors, d, Xq_i[None], Xk, tau, a_i[None])[0])
        if val > best:
            best, best_d = val, d
    return best, best_d


def omega_witness(factors, Xq_i, Xk, tau, rho, G_i, j, k):
    """Exact spread of the logit change at the vertex d = rho sign(G_j - G_k)."""
    d = rho * np.sign(G_i[j] - G_i[k] + 1e-300)
    sh = [f.shape for f in factors]
    _, _, s0 = scores(*factors, Xq_i[None], Xk)
    _, _, s1 = scores(*perturb(factors, split_d(d, sh)), Xq_i[None], Xk)
    delta = tau * np.log(s1[0] / s0[0])
    return float(delta.max() - delta.min())


# ---------------------------------------------------------------------------
# exact maximum of TV over an independent logit box (small N, by enumeration)
# ---------------------------------------------------------------------------
def tv_box_bruteforce(p, lo, hi):
    """max over e in prod [lo_j, hi_j] of TV(softmax(log p + e), p), by enumerating the up-set S
    (for a fixed S the optimum puts S at hi and the rest at lo).  O(2^N); N <= 16."""
    N = len(p)
    best = 0.0
    for mask in range(1, 2 ** N - 1):
        S = np.array([(mask >> j) & 1 for j in range(N)], dtype=bool)
        up = (p[S] * np.exp(hi[S])).sum()
        dn = (p[~S] * np.exp(lo[~S])).sum()
        best = max(best, up / (up + dn) - p[S].sum())
    return best
