# Supplement to "Positive Kronecker Attention with Dependency Control" (P2)

Debi Prasad Ghosh, 5 October 2026.

This folder holds the paper, every script, the protocol, the frozen configurations, the evaluation summaries, the exploratory outputs, the figures and the logs. It does not hold the trained parameters (`runs/<task>/*.npz`), the per-query evaluation arrays (`evals/test/<task>/*.npz`, about 1.2 GB) or the data. The scripts regenerate all three deterministically.

`P2_Positive_Kronecker_Attention_Dependency_Control.md` is the paper. It reads its figures from `figures/`, so keep the two together.

## Layout

| Path | Contents |
|---|---|
| `PROTOCOL.md` | The protocol, written before any confirmatory run, with its marked amendments and a dated addendum of post hoc additions |
| `evals_code_sha256.txt` | SHA-256 of the frozen evaluator files and the one recorded amendment |
| `p2lib.py`, `p2_run.py` | Model, training loop, data loaders; pilot, freeze, confirmatory, sweep and exploratory stages |
| `p2_eval.py`, `p2cert.py`, `p2cert_jax.py` | Frozen evaluator and certificate library |
| `retrieval_data.py`, `retrieval_reference.py` | Retrieval task generator (frozen); codebook reference decoder |
| `pf_gen.py`, `pf_cache_check.py` | Pathfinder-32 regeneration with the original generator; cache bit-identity check |
| `verify_p2_theory.py` | Numerical checks T1–T9 of Propositions 1–6 |
| `l10_repeat.py` | Paper II's L10 check repeated with token mass normalised (Section 5) |
| `p2_explore_witness.py`, `p2_signed_witness.py`, `p2_pool_entropy.py`, `p2_init_stats.py` | Exploratory analyses (Sections 7.3, 7.4, Appendix C) |
| `p2_image_code_check.py` | Recomputes the LRA-Image models' validation accuracy under the frozen code (Section 4) |
| `p2_latency.py` | Latency of the attention block, the certificate summaries and the model forward pass (Section 7.5) |
| `p2_report.py`, `p2_facts.py` | Tables, figures and every quoted number |
| `runs/config_<task>.json` | Frozen run configurations: architecture, schedule, learning rates chosen by the pilots, data hashes, code hashes at freeze time |
| `runs/<task>/*.json` | Run records (configuration and per-epoch validation history) of every pilot, confirmatory, sweep and exploratory run |
| `evals/test/<task>/*.json` | Frozen-evaluator summaries per model: accuracy, certified fractions per radius, per-head statistics |
| `explore/` | Exploratory outputs: decision-query witnesses, signed witnesses, pool entropies, statistics at initialisation |
| `report/` | `summary.json` (everything the tables use), `latency.json`, the three check outputs, and `tables.md` |
| `figures/` | Figures 1–4, and `fig_cert_retrieval.png`, the retrieval counterpart of Figure 3 (not in the paper) |
| `logs/` | Logs of every stage |
| `facts_output.txt` | Output of `p2_facts.py`: every number quoted in the paper, printed from its source file |
| `verify_p2_theory_output.txt`, `l10_repeat_output.txt`, `l10_repeat.json` | Outputs of the theory checks and of the L10 repetition |
| `dev/` | Early design scripts and the shell scripts that chained the runs. They hard-code the original working directory and are kept for the record |

`report/tables.md` is an automatic summary. Its effective-key and spread columns are means over heads, and its last column for S and Sp is the logit spread. The paper's Tables 4 and 6 use medians over heads, taken from `head_detail` in `report/summary.json`. `facts_output.txt` is the reference for every number in the paper.

## Environment

Python 3.11; NumPy 2.4.4, SciPy 1.17.1, Matplotlib 3.10.9; JAX 0.10.2 (CPU); OpenCV 4.13.0 and Pillow 12.2.0 for the Pathfinder generator. The scripts set JAX and XLA to one thread per process. Everything ran on two CPU cores, about 18 core-hours in all.

## Data

- **CIFAR-10** (python version). Put `data_batch_1` … `data_batch_5` and `test_batch` in `data/cifar_repo/`. The MD5 sums must match those in `runs/config_image.json`, which are the canonical ones.
- **Pathfinder-32.** Clone the original generator into `data/pathfinder_gen/`:

  ```
  git clone https://github.com/drewlinsley/pathfinder data/pathfinder_gen
  git -C data/pathfinder_gen checkout 7b53886
  ```

  Then generate shards 0–9 with `pf_gen.py` (commands below). `pf_gen.py` restores the `scipy.misc` byte scaling that this commit replaced. `runs/config_pathfinder.json` lists the SHA-256 of every shard.
- **Retrieval.** Generated on first use by `retrieval_data.py` (seeds 20261020–20261023) into `data/retrieval/`.

## Commands, in order

```
python3 verify_p2_theory.py > verify_p2_theory_output.txt      # T1-T9, about 2 minutes
python3 l10_repeat.py > l10_repeat_output.txt                  # Section 5, seconds
python3 pf_gen.py <k> 10000 data/pf/shard_<k>.npz              # k = 0..9, about 15 minutes each
python3 pf_cache_check.py 200 > report/pf_cache_check.txt      # Section 4.1, about 3 minutes
python3 retrieval_reference.py > report/retrieval_reference.txt # Section 4.1, codebook decoder
python3 p2_run.py pilot image | pathfinder | retrieval         # learning-rate pilots (validation only)
python3 p2_run.py freeze image | pathfinder | retrieval        # writes runs/config_<task>.json
python3 p2_run.py confirm image                                # 30 runs
python3 p2_run.py confirm retrieval                            # 30 runs
python3 p2_run.py confirm pathfinder S,U 0,1                   # amended: 4 runs
python3 p2_run.py sweep                                        # registered token-size sweep, 9 runs
python3 p2_run.py explore && python3 p2_run.py explore2 && python3 p2_run.py explore3   # exploratory
python3 p2_image_code_check.py                                 # Section 4: LRA-Image models under the frozen code
python3 p2_eval.py <task> test [run ...]                       # frozen evaluator
python3 p2_explore_witness.py <run>                            # Section 7.3
python3 p2_signed_witness.py                                   # Section 7.4
python3 p2_init_stats.py && python3 p2_pool_entropy.py         # Appendix C
python3 p2_latency.py                                          # Section 7.5
python3 p2_report.py && python3 p2_facts.py > facts_output.txt # tables, figures, quoted numbers
```

Evaluation is deterministic: `p2_image_code_check.py` reproduces the recorded validation accuracies exactly. Training was not repeated, so bit-identical retraining has not been checked. Latencies depend on the machine.

## Code versions

The evaluator files in this folder have the frozen hashes of `evals_code_sha256.txt`. `p2lib.py` is the frozen file with its one recorded amendment, an optional initial temperature (default 1) used only by the exploratory run that starts at τ = 8.

`p2_run.py` gained the exploratory stages after the freeze, and the LRA-Image models were trained with an earlier revision of `p2lib.py` and `p2_run.py`. Their hashes are recorded in `runs/config_image.json`. `p2_image_code_check.py` shows that the frozen code reproduces the validation accuracy of all 30 LRA-Image models exactly (`report/image_code_check.txt`).
