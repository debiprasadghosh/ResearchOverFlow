"""L10 repeated with token mass normalised outside the uncertain computation (Paper II, Section 5).

Paper II's L10(c) drew 32 random positive tokens, dense (all entries exp(N(0, 0.25))) or sparse (4 active
entries, the rest 1e-6), with random positive factors (r = t = 4; for p x p tokens, entries exp(N(log(1/p), 0.5)),
where the code's variable pq is the side p), and reported
the spread of log-scores over keys and the Eq. 11 bound at tau* = 1/spread.  Here every configuration is
run with raw tokens and with tokens divided by their total mass, and the Eq. 11 bound is set beside the
dependency-aware certificates (Propositions 4-5) and explicit witnesses.  Ten random draws per cell.

Also repeats L10(b): tokens exp(N(0, 1)), tau = 4, rho = 0.02.
Seed 20261012.  Output: l10_repeat_output.txt (via stdout) and l10_repeat.json.
"""
import json
import numpy as np
from p2cert import factor_masses, attn_from_scores, certificates, tv_witness, eq11, scores, perturb, tv

RNG = np.random.default_rng(20261012)
RHO = 0.02
NT = 32
R = T = 4
DRAWS = 10
QUERIES = 8


def make_tokens(kind, pq, norm):
    if kind == "dense":
        X = np.exp(RNG.normal(0, 0.25, (NT, pq, pq)))
    elif kind == "dense1":
        X = np.exp(RNG.normal(0, 1.0, (NT, pq, pq)))
    else:
        X = np.full((NT, pq, pq), 1e-6)
        for n in range(NT):
            idx = RNG.choice(pq * pq, 4, replace=False)
            X[n].ravel()[idx] = np.exp(RNG.normal(0, 0.25, 4))
    if norm:
        X = X / X.sum(axis=(1, 2), keepdims=True)
    return X


def make_factors(pq):
    return [np.exp(RNG.normal(np.log(1.0 / pq), 0.5, sh)) for sh in [(R, pq), (T, pq), (R, pq), (T, pq)]]


def cell(kind, pq, norm, tau=None):
    rows = []
    for _ in range(DRAWS):
        X = make_tokens(kind, pq, norm)
        fac = make_factors(pq)
        G, s = factor_masses(*fac, X[:QUERIES], X)
        L = np.log(s)
        spread = float(np.median(L.std(axis=1)))
        t_ = (1.0 / spread) if tau is None else tau
        a = attn_from_scores(s, t_)
        for i in range(QUERIES):
            c = certificates(G[i], a[i], t_, RHO, exact_pairs=True)
            wit, _ = tv_witness(fac, X[i], X, t_, RHO, G[i], a[i])
            eff = float(np.exp(-(a[i] * np.log(a[i] + 1e-300)).sum()))
            rows.append(dict(spread=spread, tau=t_, eq11=c['eq11'], c_omega=c['c_omega'], c_kl=c['c_kl'],
                             c_l1=c['c_l1'], cert=c['cert'], witness=wit, D=c['D'], eff_keys=eff,
                             gain_sd=float(np.log(X.sum(axis=(1, 2))).std())))
    keys = rows[0].keys()
    return {k: float(np.median([r[k] for r in rows])) for k in keys} | {
        'cert_le_0.1': float(np.mean([r['cert'] <= 0.1 for r in rows])),
        'eq11_le_0.1': float(np.mean([r['eq11'] <= 0.1 for r in rows]))}


def main():
    out = {}
    print("L10(c) repeated: tau* = 1/spread (unit logit spread), rho = 0.02; medians over 10 draws x 8 queries")
    print("kind    norm  p=q  spread  spread*sqrt(pq)  tau*    Eq.11   tanh(Om/4)  best cert  witness  "
          "D (L1 diam)  eff. keys  certified<=0.1")
    for kind in ("dense", "sparse"):
        for norm in (False, True):
            for pq in (4, 8, 16, 32):
                c = cell(kind, pq, norm)
                out[f"{kind}_{'norm' if norm else 'raw'}_{pq}"] = c
                print(f"{kind:6s}  {'yes' if norm else 'no ':3s}  {pq:3d}  {c['spread']:.4f}  "
                      f"{c['spread'] * pq:13.3f}    {c['tau']:6.2f}  {c['eq11']:.4f}  {c['c_omega']:.4f}      "
                      f"{c['cert']:.4f}     {c['witness']:.4f}   {c['D']:.4f}       {c['eff_keys']:6.2f}     "
                      f"{c['cert_le_0.1']:.2f}")
    print("\nL10(b) repeated: tokens exp(N(0,1)), tau = 4, rho = 0.02")
    print("p=q  Eq.11    tanh(Om/4)  best cert  witness   (medians)")
    for pq in (4, 8, 16):
        c = cell("dense1", pq, False, tau=4.0)
        out[f"b_{pq}"] = c
        print(f"{pq:3d}  {c['eq11']:.5f}  {c['c_omega']:.5f}     {c['cert']:.5f}    {c['witness']:.5f}")
    json.dump(out, open("l10_repeat.json", "w"), indent=1)


if __name__ == "__main__":
    main()
