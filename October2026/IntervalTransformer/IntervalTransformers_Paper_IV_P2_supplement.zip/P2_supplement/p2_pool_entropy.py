"""Pool sparsity (Section 7.2, Appendix C): mean entropy (nats) of a column of the softmax pool factors, and the mean
largest weight per column, for every head of every Pool model.  Output: explore/pool_entropy.json"""
import os
import glob
import json
import numpy as np
import p2lib as L

out = {}
for task in ("image", "retrieval"):
    for p in sorted(glob.glob(os.path.join("runs", task, "*Pool*.json"))):
        name = os.path.basename(p)[:-5]
        if name.startswith("pilot_"):
            continue
        params, cfg, meta = L.load_params(p[:-5])
        heads = []
        for li, blk in enumerate(params["blocks"]):
            for h in range(cfg["heads"]):
                ent, mx = [], []
                for k in ("Bq", "Aq", "Bk", "Ak"):
                    z = np.asarray(blk[k][h], dtype=np.float64)
                    z = z - z.max(axis=0, keepdims=True)
                    P = np.exp(z)
                    P /= P.sum(axis=0, keepdims=True)
                    ent.append(float((-(P * np.log(P + 1e-300)).sum(axis=0)).mean()))
                    mx.append(float(P.max(axis=0).mean()))
                heads.append({"layer": li, "head": h, "tau": float(np.exp(np.asarray(blk["log_tau"])[h])),
                              "entropy": float(np.mean(ent)), "max_weight": float(np.mean(mx))})
        out[f"{task}/{name}"] = {"heads": heads, "model_mean_entropy": float(np.mean([x["entropy"] for x in heads]))}
        print(f"{task}/{name}: " + "  ".join(f"L{x['layer']}H{x['head']} H={x['entropy']:.3f} max={x['max_weight']:.3f} tau={x['tau']:.2f}"
                                             for x in heads) + f"  | model mean {out[f'{task}/{name}']['model_mean_entropy']:.3f}")
os.makedirs("explore", exist_ok=True)
json.dump(out, open(os.path.join("explore", "pool_entropy.json"), "w"), indent=1)
