"""Reference accuracy for the retrieval task (Section 4.1): a decoder that knows the codebook and value patterns.

For each example: read the 64 tokens back from the 32 x 32 image; pick the key (tokens 1-7) whose code pixels are
closest, in squared distance, to the clean pattern of the query's code (the query's code is itself decoded as the
nearest codebook entry); decode that key's value as the nearest of the 10 clean value patterns.  No learning.

Usage: python3 retrieval_reference.py            (validation split; prints the accuracy)
"""
import numpy as np
import retrieval_data as R


def tokens(img):
    """Inverse of the patching in retrieval_data.generate: (n, 32, 32) uint8 -> (n, 64, 16) intensities in [0, 1]."""
    n = img.shape[0]
    return img.reshape(n, 8, 4, 8, 4).transpose(0, 1, 3, 2, 4).reshape(n, 64, 16).astype(np.float64) / 255.0


def decode(img):
    tok = tokens(img)
    book = 0.2 + 0.6 * R.codebook()                     # (8, 12) clean code patterns
    vals = 0.2 + 0.6 * R.value_patterns()               # (10, 4) clean value patterns
    q = tok[:, 0, :12]
    q_code = np.argmin(((q[:, None, :] - book[None]) ** 2).sum(-1), axis=1)
    keys = tok[:, 1:R.NKEY + 1]
    d = ((keys[:, :, :12] - book[q_code][:, None, :]) ** 2).sum(-1)
    j = np.argmin(d, axis=1)
    v = keys[np.arange(len(j)), j, 12:]
    return np.argmin(((v[:, None, :] - vals[None]) ** 2).sum(-1), axis=1), j + 1


def main():
    D = R.load()
    pred, pos = decode(D["Xva"])
    acc = float((pred == D["yva"]).mean())
    print(f"validation: {len(pred)} examples, reference decoder accuracy {100 * acc:.2f}%, "
          f"matching key found {100 * float((pos == D['posva']).mean()):.2f}%")


if __name__ == "__main__":
    main()
