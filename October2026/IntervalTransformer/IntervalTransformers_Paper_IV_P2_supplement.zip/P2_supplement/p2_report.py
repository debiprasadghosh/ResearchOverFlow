"""P2 report: statistics, verdicts, tables and figures from evals/test/<task>/*.json (+ .npz arrays).

python3 p2_report.py            -> report/summary.json, report/tables.md, figures/*.png
"""
import os
import json
import glob
import numpy as np
from scipy import stats

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

TASKS = ("image", "pathfinder", "retrieval")
TASK_NAME = {"image": "LRA-Image", "pathfinder": "Pathfinder-32", "retrieval": "Retrieval"}
VARIANTS = ("S", "Sp", "P1", "Pt", "Pool", "U")
POS = ("P1", "Pt", "Pool")
TARGET_FRAC = 0.95
ACC_MARGIN = 0.02
GATE = 0.02
T4 = stats.t.ppf(0.975, 4)


def load(task, prefix=""):
    """Confirmatory runs are named <variant>_s<seed>; prefix selects another family (e.g. 'tok4_', 'explore_')."""
    import re
    out = {}
    pat = re.compile("^" + re.escape(prefix) + r"(S|Sp|P1|Pt|Pool|U)_s\d+$")
    for p in sorted(glob.glob(os.path.join("evals", "test", task, prefix + "*.json"))):
        name = os.path.basename(p)[:-5]
        if not pat.match(name):
            continue
        r = json.load(open(p))
        out.setdefault(r["variant"], {})[r["seed"]] = r
    return out


def mean_ci(x):
    x = np.asarray(x, dtype=float)
    if len(x) < 2:
        return float(x.mean()), float("nan"), float("nan")
    h = stats.t.ppf(0.975, len(x) - 1) * x.std(ddof=1) / np.sqrt(len(x))
    return float(x.mean()), float(x.mean() - h), float(x.mean() + h)


def arrays(task, variant, seed, prefix=""):
    p = os.path.join("evals", "test", task, f"{prefix}{variant}_s{seed}.npz")
    return np.load(p) if os.path.exists(p) else None


def task_summary(task):
    R = load(task)
    if not R:
        return None
    S = {}
    for v in VARIANTS:
        if v not in R:
            continue
        seeds = sorted(R[v])
        acc = [R[v][s]["acc"] for s in seeds]
        e = {"seeds": seeds, "acc": acc, "acc_mean_ci": mean_ci(acc)}
        if v in POS:
            e["certified"] = [R[v][s]["certified_frac"] for s in seeds]
            e["certified_mean"] = float(np.mean(e["certified"]))
            e["certified_min"] = float(np.min(e["certified"]))
            for r in (0.01, 0.05):
                e[f"certified_rho{r}"] = float(np.mean([R[v][s][f"certified_frac_rho{r}"] for s in seeds]))
            taus = [[L["tau"] for L in R[v][s]["layers"]] for s in seeds]
            e["tau"] = taus
            e["eq11_frac_heads"] = float(np.mean([R[v][s]["eq11_frac"] for s in seeds]))
            for k in ("frac_eq11_le_target", "frac_c_omega_le_target", "frac_c_kl_le_target", "frac_c_l1_le_target",
                      "spread_median", "eff_median", "D_tri_median", "sub_D_median", "sub_omega_lo_median",
                      "sub_omega_up_median", "sub_omega_witness_median", "sub_tv_witness_median",
                      "sub_tv_witness_max", "sub_tv_cert_median", "sub_witness_over_cert_median",
                      "sub_witness_violations", "sub_witness_frac_gt_target", "cert_median", "cert_q95",
                      "match_mass_median", "w_mean_median", "w_max_median"):
                vals = [L.get(k) for s in seeds for L in R[v][s]["layers"] if L.get(k) is not None]
                if vals:
                    e[k] = float(np.mean(vals)) if k != "sub_witness_violations" else int(np.sum(vals))
            e["omega_inside"] = all(L.get("sub_omega_witness_inside", True) for s in seeds for L in R[v][s]["layers"])
        else:
            for k in ("eff_median", "spread_median", "signed_certified_frac", "signed_tv_median", "kappa_median",
                      "match_mass_median"):
                vals = [L.get(k) for s in seeds for L in R[v][s]["layers"] if L.get(k) is not None]
                if vals:
                    e[k] = float(np.mean(vals))
        S[v] = e
    # paired differences against S (same seeds)
    if "S" in S:
        for v in S:
            common = [s for s in S[v]["seeds"] if s in S["S"]["seeds"]]
            d = [R[v][s]["acc"] - R["S"][s]["acc"] for s in common]
            S[v]["diff_vs_S"] = mean_ci(d) if len(d) > 1 else (float(np.mean(d)) if d else None, None, None)
    # verdicts
    if "S" in S and "U" in S:
        gate = S["S"]["acc_mean_ci"][0] - S["U"]["acc_mean_ci"][0]
        S["gate"] = {"S_minus_U": gate, "informative": bool(gate >= GATE)}
    for v in POS:
        if v in S and "S" in S:
            acc_ok = S[v]["acc_mean_ci"][0] >= S["S"]["acc_mean_ci"][0] - ACC_MARGIN
            cert_ok = S[v]["certified_mean"] >= TARGET_FRAC
            S[v]["verdict"] = {"accuracy_ok": bool(acc_ok), "certificate_ok": bool(cert_ok),
                               "passes": bool(acc_ok and cert_ok)}
    S["supported"] = any(S.get(v, {}).get("verdict", {}).get("passes", False) for v in POS)
    return S


def fmt_ci(m):
    return f"{100 * m[0]:.2f} [{100 * m[1]:.2f}, {100 * m[2]:.2f}]"


def tables(summary):
    lines = []
    for task in TASKS:
        S = summary.get(task)
        if not S:
            continue
        lines.append(f"\n### {TASK_NAME[task]}\n")
        lines.append("| Variant | Accuracy (%) | vs S (pp) | Certified at 0.02 (%) | min over seeds | Eq. 11 alone (%) "
                     "| τ (median over heads) | Eff. keys | Log-score spread |")
        lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|")
        for v in VARIANTS:
            if v not in S:
                continue
            e = S[v]
            dv = e.get("diff_vs_S")
            dtxt = "–" if v == "S" or dv is None else f"{100 * dv[0]:+.2f} [{100 * dv[1]:+.2f}, {100 * dv[2]:+.2f}]"
            if v in POS:
                tau_med = float(np.median([t for ts in e["tau"] for t in ts]))
                lines.append(f"| {v} | {fmt_ci(e['acc_mean_ci'])} | {dtxt} | {100 * e['certified_mean']:.2f} | "
                             f"{100 * e['certified_min']:.2f} | {100 * e['frac_eq11_le_target']:.1f} | {tau_med:.2f} | "
                             f"{e.get('eff_median', float('nan')):.1f} | {e.get('spread_median', float('nan')):.3f} |")
            else:
                lines.append(f"| {v} | {fmt_ci(e['acc_mean_ci'])} | {dtxt} | – | – | – | – | "
                             f"{e.get('eff_median', float('nan')):.1f} | "
                             f"{e.get('spread_median', float('nan')) if 'spread_median' in e else float('nan'):.3f} |")
        if "gate" in S:
            lines.append(f"\nGate S − U = {100 * S['gate']['S_minus_U']:+.2f} pp; informative: {S['gate']['informative']}")
        for v in POS:
            if v in S and "verdict" in S[v]:
                lines.append(f"- {v}: {S[v]['verdict']}")
    return "\n".join(lines)


def explore_summary():
    """Exploratory retrieval runs: accuracy, certified fractions, and the head with the largest learned tau."""
    out = {}
    for p in sorted(glob.glob(os.path.join("evals", "test", "retrieval", "explore_*.json"))):
        r = json.load(open(p))
        name = os.path.basename(p)[:-5]
        e = {"acc": r["acc"], "variant": r["variant"], "seed": r["seed"]}
        for rr in (0.01, 0.02, 0.05):
            e[f"certified_rho{rr}"] = r.get(f"certified_frac_rho{rr}")
        top = max(r["layers"], key=lambda L: L["tau"])
        e.update(top_tau=top["tau"], top_layer=top["layer"], top_head=top["head"],
                 top_eff=top["eff_median"], top_match_mass=top.get("match_mass_median"),
                 top_cert_median=top.get("cert_median"), top_certified=top.get("certified_frac_rho0.02"),
                 top_eq11=top.get("eq11_value"), top_D=top.get("sub_D_median"),
                 top_omega=[top.get("sub_omega_lo_median"), top.get("sub_omega_witness_median"),
                            top.get("sub_omega_up_median")],
                 top_witness_median=top.get("sub_tv_witness_median"), top_witness_max=top.get("sub_tv_witness_max"),
                 top_witness_gt=top.get("sub_witness_frac_gt_target"),
                 top_witness_over_cert=top.get("sub_witness_over_cert_median"),
                 top_frac_by={k: top.get(f"frac_{k}_le_target") for k in ("eq11", "c_omega", "c_kl", "c_l1")})
        Z = np.load(p[:-5] + ".npz")
        key = f"L{top['layer']}H{top['head']}"
        c = Z[f"{key}_cert_rho0.02"]
        e["top_query0_certified"] = float((c[:, 0] <= 0.1).mean())
        e["top_query0_certified_rho0.01"] = float((Z[f"{key}_cert_rho0.01"][:, 0] <= 0.1).mean())
        e["top_query0_eff"] = float(np.median(Z[f"{key}_eff"][:, 0]))
        wf = os.path.join("explore", f"witness_{name}.json")
        if os.path.exists(wf):
            e["witness_query0"] = json.load(open(wf))["summary"]
        out[name] = e
    return out


def sweep_summary():
    """Registered token-size sweep (4 x 4 tokens) on the retrieval task, against the 8 x 8 confirmatory runs."""
    out = {}
    for tag, prefix in (("tok4", "tok4_"), ("tok8", "")):
        R = load("retrieval", prefix)
        for v in ("S", "Pt", "Pool"):
            seeds = [s for s in (0, 1, 2) if s in R.get(v, {})]
            if not seeds:
                continue
            accs = [R[v][s]["acc"] for s in seeds]
            e = {"acc": accs, "acc_mean": float(np.mean(accs))}
            if v != "S":
                taus = [L["tau"] for s in seeds for L in R[v][s]["layers"]]
                sp = [L["spread_median"] for s in seeds for L in R[v][s]["layers"]]
                pq = 16 if tag == "tok4" else 64
                e.update(tau_median=float(np.median(taus)), tau_max=float(max(taus)),
                         spread_median=float(np.median(sp)), conc_spread_median=float(np.median(sp) * np.sqrt(pq)))
            out[f"{tag}_{v}"] = e
    return out


def main():
    os.makedirs("report", exist_ok=True)
    os.makedirs("figures", exist_ok=True)
    summary = {t: task_summary(t) for t in TASKS}
    summary["cert_detail"] = {t: cert_detail(t) for t in ("image", "retrieval")}
    summary["head_detail"] = {t: head_detail(t) for t in ("image", "retrieval")}
    summary["explore"] = explore_summary()
    summary["sweep"] = sweep_summary()
    for f in ("latency.json",):
        p = os.path.join("report", f)
        if os.path.exists(p):
            summary["latency"] = json.load(open(p))
    p = os.path.join("explore", "init_stats.json")
    if os.path.exists(p):
        summary["init_stats"] = json.load(open(p))
    json.dump(summary, open(os.path.join("report", "summary.json"), "w"), indent=1, default=float)
    txt = tables({t: summary[t] for t in TASKS})
    txt += "\n\n## Per-seed results\n" + "\n".join(per_seed_table(t) for t in TASKS if summary.get(t))
    open(os.path.join("report", "tables.md"), "w").write(txt)
    fig_accuracy({t: summary[t] for t in TASKS})
    for t in ("image", "retrieval"):
        fig_certificates(t)
    fig_l10()
    fig_explore()
    print(txt)


def fig_l10():
    d = json.load(open("l10_repeat.json"))
    sizes = [4, 8, 16, 32]
    fig, ax = plt.subplots(1, 3, figsize=(12.5, 3.6))
    styles = {"dense_raw": ("C0", "-", "dense, raw"), "dense_norm": ("C0", "--", "dense, mass 1"),
              "sparse_raw": ("C3", "-", "sparse, raw"), "sparse_norm": ("C3", "--", "sparse, mass 1")}
    for key, (c, ls, lab) in styles.items():
        sp = [d[f"{key}_{s}"]["spread"] for s in sizes]
        e11 = [d[f"{key}_{s}"]["eq11"] for s in sizes]
        ce = [d[f"{key}_{s}"]["cert"] for s in sizes]
        wi = [d[f"{key}_{s}"]["witness"] for s in sizes]
        ax[0].plot(sizes, sp, color=c, ls=ls, marker="o", label=lab)
        ax[1].plot(sizes, e11, color=c, ls=ls, marker="s", alpha=0.5)
        ax[1].plot(sizes, ce, color=c, ls=ls, marker="o", label=lab)
        ax[2].plot(sizes, wi, color=c, ls=ls, marker="o", label=lab)
    ref = np.array(sizes, float)
    ax[0].plot(ref, 0.25 / ref, color="gray", lw=0.8, ls=":", label=r"$\propto 1/\sqrt{pq}$")
    for a in ax:
        a.set_xscale("log", base=2)
        a.set_xticks(sizes)
        a.set_xticklabels([f"{s}×{s}" for s in sizes])
        a.set_xlabel("token size")
    ax[0].set_yscale("log")
    ax[0].set_ylabel("log-score spread")
    ax[0].legend(fontsize=7)
    ax[1].axhline(0.1, color="k", lw=0.8)
    ax[1].set_ylabel("TV bound at τ* (squares: Eq. 11)")
    ax[2].axhline(0.1, color="k", lw=0.8)
    ax[2].set_ylabel("witnessed TV at τ*")
    for a, t in zip(ax, ("(a) spread over keys", "(b) certificate vs Eq. 11", "(c) witnesses")):
        a.set_title(t, fontsize=9)
    fig.tight_layout()
    fig.savefig(os.path.join("figures", "fig_l10.png"), dpi=150)
    plt.close(fig)


def cert_detail(task):
    """Per positive variant: medians (over all certified queries of all seeds) of each bound, the witness ratio,
    the Omega sandwich on the subsample, and the fraction certified by each bound alone."""
    R = load(task)
    out = {}
    for v in POS:
        if v not in R:
            continue
        rows = {"eq11": [], "c_omega": [], "c_kl": [], "c_l1": [], "cert": []}
        for s in sorted(R[v]):
            A = arrays(task, v, s)
            if A is None:
                continue
            for L in R[v][s]["layers"]:
                key = f"L{L['layer']}H{L['head']}"
                n = A[f"{key}_c_kl"].size
                rows["eq11"].append(np.full(n, L["eq11_value"]))
                for k in ("c_omega", "c_kl", "c_l1"):
                    rows[k].append(A[f"{key}_{k}"].ravel())
                rows["cert"].append(A[f"{key}_cert_rho0.02"].ravel())
        e = {}
        for k, lst in rows.items():
            x = np.concatenate(lst)
            e[k + "_median"] = float(np.median(x))
            e[k + "_frac"] = float((x <= 0.1).mean())
        best = np.concatenate(rows["cert"])
        e["which_best"] = {k: float(np.mean(np.isclose(np.concatenate(rows[k]), best, rtol=1e-6, atol=0)))
                           for k in ("eq11", "c_omega", "c_kl", "c_l1")}
        sub = [L for s in R[v] for L in R[v][s]["layers"]]
        for k in ("sub_D_median", "sub_omega_lo_median", "sub_omega_witness_median", "sub_omega_up_median",
                  "sub_tv_witness_median", "sub_tv_cert_median", "sub_witness_over_cert_median", "sub_tv_witness_max",
                  "sub_witness_frac_gt_target"):
            e[k] = float(np.median([L[k] for L in sub]))
        e["sub_witness_violations"] = int(sum(L["sub_witness_violations"] for L in sub))
        e["omega_inside_all"] = all(L["sub_omega_witness_inside"] for L in sub)
        out[v] = e
    return out


def per_seed_table(task):
    R = load(task)
    lines = [f"\n#### {TASK_NAME[task]}\n", "| Variant | Seed | Accuracy (%) | Certified at 0.02 (%) | τ per layer and head |",
             "|---|---:|---:|---:|---|"]
    for v in VARIANTS:
        for s in sorted(R.get(v, {})):
            r = R[v][s]
            c = f"{100 * r['certified_frac']:.2f}" if "certified_frac" in r else "–"
            taus = ", ".join(f"{L['tau']:.2f}" for L in r["layers"]) if v in ("Pt", "Pool") else "–"
            lines.append(f"| {v} | {s} | {100 * r['acc']:.2f} | {c} | {taus} |")
    return "\n".join(lines)


def fig_accuracy(summary):
    tasks = [t for t in TASKS if summary.get(t)]
    fig, ax = plt.subplots(1, len(tasks), figsize=(4.2 * len(tasks), 3.4))
    ax = np.atleast_1d(ax)
    for a, t in zip(ax, tasks):
        S = summary[t]
        vs = [v for v in VARIANTS if v in S]
        for x, v in enumerate(vs):
            accs = 100 * np.array(S[v]["acc"])
            col = "C3" if v in POS else ("C0" if v in ("S", "Sp") else "gray")
            a.scatter(np.full(len(accs), x) + np.linspace(-0.12, 0.12, len(accs)), accs, s=14, color=col)
            a.hlines(accs.mean(), x - 0.3, x + 0.3, color=col)
        a.set_xticks(range(len(vs)))
        a.set_xticklabels(vs)
        a.set_title(TASK_NAME[t], fontsize=9)
        a.set_ylabel("test accuracy (%)")
    fig.tight_layout()
    fig.savefig(os.path.join("figures", "fig_accuracy.png"), dpi=150)
    plt.close(fig)


def fig_certificates(task, variants=POS):
    """ECDF over held-out queries of the four bounds and of their minimum, per positive variant (all seeds)."""
    R = load(task)
    vs = [v for v in variants if v in R]
    if not vs:
        return
    fig, ax = plt.subplots(1, len(vs), figsize=(4.2 * len(vs), 3.4), sharey=True)
    ax = np.atleast_1d(ax)
    for a, v in zip(ax, vs):
        curves = {"Eq. 11": [], "tanh(Ω/4)": [], "Bennett–Pinsker": [], "ℓ1": [], "certificate": []}
        for s in sorted(R[v]):
            A = arrays(task, v, s)
            for L in R[v][s]["layers"]:
                key = f"L{L['layer']}H{L['head']}"
                n = A[f"{key}_c_kl"].size
                curves["Eq. 11"].append(np.full(n, L["eq11_value"]))
                curves["tanh(Ω/4)"].append(A[f"{key}_c_omega"].ravel())
                curves["Bennett–Pinsker"].append(A[f"{key}_c_kl"].ravel())
                curves["ℓ1"].append(A[f"{key}_c_l1"].ravel())
                curves["certificate"].append(A[f"{key}_cert_rho0.02"].ravel())
        qs = np.linspace(0, 1, 2001)
        for (lab, lst), st in zip(curves.items(), (":", "--", "-.", (0, (1, 1)), "-")):
            x = np.quantile(np.concatenate(lst), qs)
            a.plot(x, qs, ls=st, lw=1.6 if lab == "certificate" else 1.0, label=lab)
        wit = [L["sub_tv_witness_median"] for s in R[v] for L in R[v][s]["layers"]]
        a.axvline(np.median(wit), color="k", lw=0.6, ls=":")
        a.axvline(0.1, color="k", lw=0.9)
        a.set_xscale("log")
        a.set_xlabel("TV bound at ρ = 0.02")
        a.set_title(f"{TASK_NAME[task]}: {v}", fontsize=9)
    ax[0].set_ylabel("fraction of held-out queries")
    ax[0].legend(fontsize=7, loc="upper left")
    fig.tight_layout()
    fig.savefig(os.path.join("figures", f"fig_cert_{task}.png"), dpi=150)
    plt.close(fig)


def head_detail(task, prefix=""):
    """Per variant: distribution over heads (all seeds) of tau, logit spread, effective keys, match mass, and the
    number of heads where Eq. 11 alone fails (tau > artanh(0.1)/(2 rho))."""
    R = load(task, prefix)
    out = {}
    for v in VARIANTS:
        if v not in R:
            continue
        taus, lsp, eff, mm, e11fail, conc = [], [], [], [], 0, []
        for s in sorted(R[v]):
            A = arrays(task, v, s, prefix)
            for L in R[v][s]["layers"]:
                key = f"L{L['layer']}H{L['head']}"
                eff.append(L["eff_median"])
                if "match_mass_median" in L:
                    mm.append(L["match_mass_median"])
                if v in ("S", "Sp"):
                    lsp.append(L["spread_median"])
                elif v in POS:
                    taus.append(L["tau"])
                    lsp.append(float(np.median(L["tau"] * A[f"{key}_spread"])))
                    conc.append(L["spread_median"] * 8.0)
                    e11fail += int(np.tanh(2 * L["tau"] * 0.02) > 0.1)
        e = {"eff_median_heads": float(np.median(eff)), "eff_range": [float(min(eff)), float(max(eff))]}
        if lsp:
            e.update(logit_spread_median=float(np.median(lsp)), logit_spread_range=[float(min(lsp)), float(max(lsp))])
        if taus:
            e.update(tau_median=float(np.median(taus)), tau_max=float(max(taus)), tau_min=float(min(taus)),
                     eq11_fail_heads=e11fail, n_heads=len(taus), conc_spread_median=float(np.median(conc)))
        if mm:
            e.update(match_mass_max_head_median=float(np.median([max(mm[i:i + 4]) for i in range(0, len(mm), 4)])),
                     match_mass_all=[float(x) for x in mm])
        out[v] = e
    return out


def fig_explore():
    """Exploratory sparse-pool models that learned retrieval: certificate vs witness for the decision query of the
    retrieval head (200 test images per model), and the certificate distribution over all its queries."""
    runs = [("explore_tok4_Pool_lr0.003_ep12_s0", "4×4 tokens, seed 0"), ("explore_Pool_lr0.003_ep12_s0", "8×8, seed 0"),
            ("explore_Pool_lr0.003_ep12_s2", "8×8, seed 2"), ("explore_Pool_lr0.003_ep12_s1", "8×8, seed 1")]
    runs = [(r, lab) for r, lab in runs if os.path.exists(os.path.join("explore", f"witness_{r}.json"))]
    if not runs:
        return
    fig, ax = plt.subplots(1, 2, figsize=(10.5, 4.0))
    for k, (r, lab) in enumerate(runs):
        W = json.load(open(os.path.join("explore", f"witness_{r}.json")))
        rows = W["rows"]
        c = np.array([x["cert"] for x in rows])
        w = np.array([x["witness"] for x in rows])
        flip = np.array([x["pred0"] != x["pred1"] for x in rows])
        tau = W["summary"]["tau"]
        ax[0].scatter(c[~flip], w[~flip], s=7, color=f"C{k}", alpha=0.6, label=f"{lab} (τ = {tau:.1f})")
        ax[0].scatter(c[flip], w[flip], s=22, color=f"C{k}", marker="x")
        x = np.sort(c)
        ax[1].plot(x, np.linspace(0, 1, len(x)), color=f"C{k}", label=f"certificate, {lab}")
        x = np.sort(w)
        ax[1].plot(x, np.linspace(0, 1, len(x)), color=f"C{k}", ls=":")
        ax[1].axvline(np.tanh(2 * tau * 0.02), color=f"C{k}", lw=0.7, ls="--")
    lim = [1e-3, 1.0]
    ax[0].plot(lim, lim, color="k", lw=0.6)
    ax[0].axhline(0.1, color="k", lw=0.8)
    ax[0].axvline(0.1, color="k", lw=0.8)
    ax[0].set_xscale("log")
    ax[0].set_yscale("log")
    ax[0].set_xlim(*lim)
    ax[0].set_ylim(*lim)
    ax[0].set_xlabel("certificate (TV bound) at ρ = 0.02")
    ax[0].set_ylabel("witnessed TV")
    ax[0].set_title("(a) decision query of the retrieval head; × = prediction flipped", fontsize=9)
    ax[0].legend(fontsize=7, loc="lower right")
    ax[1].axvline(0.1, color="k", lw=0.8)
    ax[1].set_xscale("log")
    ax[1].set_xlabel("TV at ρ = 0.02 (solid: certificate, dotted: witness, dashed: Eq. 11)")
    ax[1].set_ylabel("fraction of decision queries")
    ax[1].set_title("(b) distributions", fontsize=9)
    fig.tight_layout()
    fig.savefig(os.path.join("figures", "fig_explore.png"), dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    main()
