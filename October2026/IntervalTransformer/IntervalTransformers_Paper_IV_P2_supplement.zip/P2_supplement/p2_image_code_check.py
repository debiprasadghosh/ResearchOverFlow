"""Check that the frozen code computes the LRA-Image models exactly as the code that trained them (Section 4.1).

The LRA-Image confirmatory models were trained with an earlier revision of p2lib.py and p2_run.py (SHA-256 in
runs/config_image.json); the evaluator was frozen with a later revision (evals_code_sha256.txt). For every
LRA-Image model this script recomputes the validation accuracy with the current p2lib.py and compares it with the
validation accuracy that the training run recorded after its last epoch.

Usage: python3 p2_image_code_check.py          Output: report/image_code_check.txt
"""
import os
import glob
import json
import re
import p2lib as L


def main():
    data = L.load_task("image")
    lines, ok = [], True
    pat = re.compile(r"^(S|Sp|P1|Pt|Pool|U)_s\d+$")
    for p in sorted(glob.glob(os.path.join("runs", "image", "*.json"))):
        name = os.path.basename(p)[:-5]
        if not pat.match(name):
            continue
        params, cfg, meta = L.load_params(p[:-5])
        hist = meta["history"]
        if isinstance(hist, str):                      # stored as a Python repr in the run record
            import ast
            hist = ast.literal_eval(hist)
        recorded = hist[-1]["val_acc"]
        now = L.accuracy(L.make_eval(cfg), params, data["Xva"], data["yva"], cfg["patch"])
        same = abs(now - recorded) < 1e-12
        ok &= same
        lines.append(f"{name:8s} recorded {recorded:.4f}  recomputed {now:.4f}  {'identical' if same else 'DIFFERENT'}")
        print(lines[-1], flush=True)
    lines.append("ALL IDENTICAL" if ok else "MISMATCH")
    print(lines[-1])
    os.makedirs("report", exist_ok=True)
    with open(os.path.join("report", "image_code_check.txt"), "w") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
