import sys, json, time
import p2_eval as E
import p2lib as L
E.N_CERT, E.SUB, E.WIT_QUERIES = 50, 3, 4
task = sys.argv[1]
data = L.load_task(task)
for name in sys.argv[2:]:
    t = time.time()
    res, arrays = E.evaluate_run(f"runs/{task}/" + name, data, "va")
    print(name, "acc", round(res["acc"], 4), "time", round(time.time() - t, 1), "cert", res.get("certified_frac"))
    for e in res["layers"]:
        print("  ", {k: (round(float(v), 4) if isinstance(v, float) else v) for k, v in e.items()
                     if k in ("layer", "head", "tau", "eff_median", "spread_median", "match_mass_median", "cert_median",
                              "cert_q95", "certified_frac_rho0.02", "sub_D_median", "sub_tv_witness_median",
                              "sub_witness_over_cert_median", "signed_tv_median", "kappa_median", "eq11_value",
                              "frac_c_kl_le_target", "frac_c_l1_le_target", "frac_c_omega_le_target")})
