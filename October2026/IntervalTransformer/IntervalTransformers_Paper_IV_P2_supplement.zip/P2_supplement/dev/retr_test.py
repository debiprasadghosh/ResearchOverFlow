import sys, numpy as np, p2lib as L, retrieval_data as R
D = R.load()
v = sys.argv[1]
cfg = L.default_cfg(variant=v, epochs=3, lr=3e-3, p=8, q=8, mlp=128, readout="first", n_classes=10, pool_lambda=0.1)
L.train(cfg, D, log=lambda s: print(s, flush=True))
