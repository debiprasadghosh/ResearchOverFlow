#!/bin/bash
# Two sequential workers; shards 0-19 of 10,000 images each.
cd /home/claude/p2
for w in "$@"; do
  if [ ! -f data/pf/shard_$w.npz ]; then
    nice -n 19 python3 pf_gen.py $w 10000 data/pf/shard_$w.npz
  fi
done
