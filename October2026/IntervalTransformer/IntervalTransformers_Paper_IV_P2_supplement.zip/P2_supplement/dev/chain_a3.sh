#!/bin/bash
cd /home/claude/p2
while kill -0 "$1" 2>/dev/null; do sleep 15; done
python3 p2_run.py explore3 > logs/explore3.log 2>&1
