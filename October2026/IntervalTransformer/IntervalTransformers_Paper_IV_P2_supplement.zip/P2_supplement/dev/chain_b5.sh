#!/bin/bash
# core B, after the retrieval confirm (PID $1): Pathfinder S and U, seeds 0-1
cd /home/claude/p2
while kill -0 "$1" 2>/dev/null; do sleep 15; done
python3 p2_run.py confirm pathfinder S,U 0,1 > logs/confirm_pathfinder.log 2>&1
