import sys, time, numpy as np, jax, jax.numpy as jnp
import p2lib as L
D = L.load_cifar_gray()
for v in sys.argv[1].split(','):
    cfg = L.default_cfg(variant=v, epochs=int(sys.argv[2]), lr=float(sys.argv[3]))
    print(v, flush=True)
    params, hist = L.train(cfg, D, log=lambda s: print(s, flush=True))
