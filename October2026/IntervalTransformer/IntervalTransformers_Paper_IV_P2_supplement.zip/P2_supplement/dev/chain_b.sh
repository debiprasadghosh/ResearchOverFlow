#!/bin/bash
# core B: retrieval pilot, then (when shards 8 and 9 exist) the Pathfinder pilot
cd /home/claude/p2
python3 p2_run.py pilot retrieval > logs/pilot_retrieval.log 2>&1
while [ ! -f data/pf/shard_8.npz ] || [ ! -f data/pf/shard_9.npz ]; do sleep 20; done
python3 p2_run.py pilot pathfinder > logs/pilot_pathfinder.log 2>&1
