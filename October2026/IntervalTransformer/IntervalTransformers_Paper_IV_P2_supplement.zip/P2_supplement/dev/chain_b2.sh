#!/bin/bash
# core B: after the Pathfinder pilot finishes, run the retrieval pilot
cd /home/claude/p2
while pgrep -f "p2_run.py pilot pathfinder" > /dev/null; do sleep 20; done
python3 p2_run.py pilot retrieval > logs/pilot_retrieval.log 2>&1
