#!/bin/bash
# core B, after the retrieval confirm (PID $1): exploratory retrieval runs, Pathfinder S/U x 2 seeds, token-size sweep
cd /home/claude/p2
while kill -0 "$1" 2>/dev/null; do sleep 15; done
python3 p2_run.py explore > logs/explore.log 2>&1
python3 p2_run.py confirm pathfinder S,U 0,1 > logs/confirm_pathfinder.log 2>&1
python3 p2_run.py sweep > logs/sweep.log 2>&1
