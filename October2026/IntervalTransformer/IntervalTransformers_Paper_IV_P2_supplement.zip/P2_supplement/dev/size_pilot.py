import sys, json, time, numpy as np, jax, jax.numpy as jnp
import p2lib as L
D = L.load_cifar_gray()
kw = json.loads(sys.argv[1])
cfg = L.default_cfg(**kw)
print(cfg, flush=True)
params, hist = L.train(cfg, D, log=lambda s: print(s, flush=True))
print("params", L.count_params(params), "final val", hist[-1]["val_acc"], flush=True)
