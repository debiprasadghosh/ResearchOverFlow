#!/bin/bash
# Evaluate finished confirmatory runs on the test split as they appear (niced). Stops when told to (touch eval_stop).
cd /home/claude/p2
while [ ! -f eval_stop ]; do
  for task in image retrieval pathfinder; do
    names=""
    for j in runs/$task/*.json; do
      [ -e "$j" ] || continue
      n=$(basename "$j" .json)
      case "$n" in pilot_*) continue;; esac
      if [ "$task" = "pathfinder" ]; then continue; fi
      [ -f "runs/$task/$n.npz" ] || continue
      [ -f "evals/test/$task/$n.json" ] && continue
      names="$names $n"
    done
    if [ -n "$names" ]; then
      nice -n 5 python3 p2_eval.py $task test $names >> logs/eval_$task.log 2>&1
    fi
  done
  sleep 60
done
