"""Check that the two generator caches in pf_gen.py leave the Pathfinder images unchanged (Section 4.1).

For worker seeds 0 and 1, generate N images with the caches (the default) and without them (PF_NO_CACHE=1),
each in a fresh process, and compare images and labels byte for byte. The cached output is also compared with
the first N images of the stored shard, which was generated with the caches from the same seed.

Usage: python3 pf_cache_check.py [N]      (default N = 200; about 0.3 s per uncached image)
"""
import os
import sys
import subprocess
import tempfile
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
N = int(sys.argv[1]) if len(sys.argv) > 1 else 200


def run(wid, path, no_cache):
    env = dict(os.environ)
    if no_cache:
        env["PF_NO_CACHE"] = "1"
    else:
        env.pop("PF_NO_CACHE", None)
    subprocess.run([sys.executable, os.path.join(HERE, "pf_gen.py"), str(wid), str(N), path], check=True, env=env)
    d = np.load(path)
    return d["X"], d["y"]


def main():
    ok = True
    with tempfile.TemporaryDirectory() as tmp:
        for wid in (0, 1):
            Xc, yc = run(wid, os.path.join(tmp, f"cached_{wid}.npz"), no_cache=False)
            Xu, yu = run(wid, os.path.join(tmp, f"uncached_{wid}.npz"), no_cache=True)
            same = np.array_equal(Xc, Xu) and np.array_equal(yc, yu)
            line = f"seed {20261010 + 1000 * wid}: {N} images, cached == uncached: {same}"
            shard = os.path.join(HERE, "data", "pf", f"shard_{wid}.npz")
            if os.path.exists(shard):
                d = np.load(shard)
                same_shard = np.array_equal(d["X"][:N], Xc) and np.array_equal(d["y"][:N], yc)
                line += f"; equal to the first {N} images of shard {wid}: {same_shard}"
                ok &= same_shard
            print(line, flush=True)
            ok &= same
    print("ALL IDENTICAL" if ok else "MISMATCH")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
