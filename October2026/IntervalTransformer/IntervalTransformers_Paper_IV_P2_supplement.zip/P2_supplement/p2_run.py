"""P2 training driver.

  python3 p2_run.py pilot <task> [variants]   learning-rate pilot on the validation split (short schedule)
  python3 p2_run.py freeze <task>             write runs/config_<task>.json from the pilot results
  python3 p2_run.py confirm <task> [variants] [seeds]   confirmatory runs with the frozen configuration
  python3 p2_run.py sweep                     token-size sweep (4 x 4 tokens) on the retrieval task

Runs are skipped if their output already exists.  Test data are never read here.
"""
import os
import sys
import json
import hashlib
import numpy as np
import p2lib as L

ARCH = dict(patch=4, p=8, q=8, r=4, t=4, rv=4, tv=4, heads=2, layers=2, mlp=128, batch=128, warmup=200, clip=1.0,
            pool_lambda=0.1)
EPOCHS = {"image": 8, "pathfinder": 5, "retrieval": 4}
PILOT_EPOCHS = {"image": 4, "pathfinder": 3, "retrieval": 2}
LR_GRID = (1e-3, 3e-3)
SEEDS = (0, 1, 2, 3, 4)
SWEEP_ARCH = dict(p=4, q=4, mlp=64)
SWEEP_VARIANTS = ("S", "Pt", "Pool")
SWEEP_SEEDS = (0, 1, 2)


def n_classes(task):
    return 2 if task == "pathfinder" else 10


def readout(task):
    return "first" if task == "retrieval" else "mean"


def run_one(task, data, tag, **kw):
    out = os.path.join("runs", task, tag)
    if os.path.exists(out + ".npz"):
        print(f"skip {task}/{tag}", flush=True)
        return
    os.makedirs(os.path.dirname(out), exist_ok=True)
    cfg = L.default_cfg(n_classes=n_classes(task), readout=readout(task), **ARCH)
    cfg.update(kw)
    print(f"== {task}/{tag}  {json.dumps({k: cfg[k] for k in ('variant', 'lr', 'epochs', 'seed', 'p', 'q')})}",
          flush=True)
    params, hist = L.train(cfg, data, log=lambda s: print(s, flush=True))
    L.save_params(out, params, cfg, extra={"task": task, "history": hist, "n_params": L.count_params(params)})


PILOT_PF_SHARDS = tuple(range(4, 10))     # Pathfinder pilot: the whole training set (shards 4-9)


def pilot(task, variants):
    data = L.load_task(task) if task != "pathfinder" else L.load_pathfinder(train_shards=PILOT_PF_SHARDS)
    for v in variants:
        for lr in LR_GRID:
            run_one(task, data, f"pilot_{v}_lr{lr:g}", variant=v, lr=lr, epochs=PILOT_EPOCHS[task], seed=100)


def freeze(task):
    """Freeze the configuration of one task from its pilot (runs/config_<task>.json)."""
    cfg = {"task": task, "arch": ARCH, "epochs": EPOCHS[task], "pilot_epochs": PILOT_EPOCHS[task],
           "lr_grid": LR_GRID, "seeds": SEEDS, "lr": {}}
    if task == "retrieval":
        cfg.update(sweep_arch=SWEEP_ARCH, sweep_variants=SWEEP_VARIANTS, sweep_seeds=SWEEP_SEEDS)
    else:
        cfg["pilot_train_shards"] = PILOT_PF_SHARDS
    for v in L.VARIANTS:
        best, best_lr = -1, None
        for lr in LR_GRID:
            p = os.path.join("runs", task, f"pilot_{v}_lr{lr:g}.json")
            if not os.path.exists(p):
                raise SystemExit(f"missing pilot {p}")
            acc = json.load(open(p))["history"][-1]["val_acc"]
            if acc > best + 1e-12:             # ties go to the smaller learning rate (listed first)
                best, best_lr = acc, lr
        cfg["lr"][v] = {"lr": best_lr, "pilot_val_acc": best}
    cfg["data"] = data_hashes(task)
    cfg["code_sha256"] = {f: hashlib.sha256(open(f, "rb").read()).hexdigest()
                          for f in ("p2lib.py", "p2_run.py")}
    path = os.path.join("runs", f"config_{task}.json")
    if os.path.exists(path):
        raise SystemExit(f"{path} exists: the configuration is frozen")
    json.dump(cfg, open(path, "w"), indent=1)
    print(json.dumps(cfg["lr"], indent=1))


def data_hashes(task):
    out = {}
    if task == "image":
        for name in sorted(L.CIFAR_MD5):
            out["cifar/" + name] = L._md5(os.path.join(L.DATA, "cifar_repo", name))
    elif task == "retrieval":
        for split in ("tr", "va"):
            d = np.load(os.path.join(L.DATA, "retrieval", f"{split}.npz"))
            out[f"retrieval/{split}"] = hashlib.sha256(d["X"].tobytes() + d["y"].tobytes()).hexdigest()
    else:
        for k in range(20):
            p = os.path.join(L.DATA, "pf", f"shard_{k}.npz")
            if os.path.exists(p):
                d = np.load(p)
                out[f"pf/shard_{k}"] = hashlib.sha256(d["X"].tobytes() + d["y"].tobytes()).hexdigest()
    return out


def confirm(task, variants, seeds):
    cfg = json.load(open(os.path.join("runs", f"config_{task}.json")))
    data = L.load_task(task)
    for seed in seeds:
        for v in variants:
            run_one(task, data, f"{v}_s{seed}", variant=v, lr=cfg["lr"][v]["lr"], epochs=EPOCHS[task],
                    seed=seed)


def sweep(variants, seeds, task="retrieval"):
    cfg = json.load(open(os.path.join("runs", f"config_{task}.json")))
    data = L.load_task(task)
    for seed in seeds:
        for v in variants:
            run_one(task, data, f"tok4_{v}_s{seed}", variant=v, lr=cfg["lr"][v]["lr"],
                    epochs=EPOCHS[task], seed=seed, **SWEEP_ARCH)


def explore():
    """Exploratory (labelled) retrieval runs: positive variants at the higher learning rate and longer, and a sharp
    initial temperature."""
    data = L.load_task("retrieval")
    for v in ("Pt", "P1", "Pool"):
        run_one("retrieval", data, f"explore_{v}_lr0.003_ep12_s0", variant=v, lr=3e-3, epochs=12, seed=0)
    run_one("retrieval", data, "explore_Pt_tau8_lr0.003_s0", variant="Pt", lr=3e-3, epochs=4, seed=0, tau0=8.0)


def explore2():
    """Exploratory follow-up (labelled): sparse positive pools at the higher learning rate, on the registered
    4-epoch schedule (seeds 0-2) and on the 12-epoch schedule (seeds 1-2)."""
    data = L.load_task("retrieval")
    for seed in (0, 1, 2):
        run_one("retrieval", data, f"explore_Pool_lr0.003_ep4_s{seed}", variant="Pool", lr=3e-3, epochs=4, seed=seed)
    for seed in (1, 2):
        run_one("retrieval", data, f"explore_Pool_lr0.003_ep12_s{seed}", variant="Pool", lr=3e-3, epochs=12,
                seed=seed)


def explore3():
    """Exploratory (labelled): sparse pools at the higher learning rate for 12 epochs with 4 x 4 tokens (seeds 0-2),
    the token-size comparison for the learned temperature in a model that learns the task."""
    data = L.load_task("retrieval")
    for seed in (0, 1, 2):
        run_one("retrieval", data, f"explore_tok4_Pool_lr0.003_ep12_s{seed}", variant="Pool", lr=3e-3, epochs=12,
                seed=seed, **SWEEP_ARCH)


if __name__ == "__main__":
    stage = sys.argv[1]
    if stage == "pilot":
        pilot(sys.argv[2], sys.argv[3].split(",") if len(sys.argv) > 3 else L.VARIANTS)
    elif stage == "freeze":
        freeze(sys.argv[2])
    elif stage == "confirm":
        confirm(sys.argv[2], sys.argv[3].split(",") if len(sys.argv) > 3 else L.VARIANTS,
                [int(s) for s in sys.argv[4].split(",")] if len(sys.argv) > 4 else SEEDS)
    elif stage == "explore":
        explore()
    elif stage == "explore2":
        explore2()
    elif stage == "explore3":
        explore3()
    elif stage == "sweep":
        sweep(sys.argv[2].split(",") if len(sys.argv) > 2 else SWEEP_VARIANTS,
              [int(s) for s in sys.argv[3].split(",")] if len(sys.argv) > 3 else SWEEP_SEEDS)
