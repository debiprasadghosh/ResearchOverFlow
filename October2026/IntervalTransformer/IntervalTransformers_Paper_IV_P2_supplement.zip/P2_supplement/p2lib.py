"""P2 models: matrix-token Kronecker attention (YAKAL) with signed or positive scoring, in JAX.

Attention variants (the tested component; everything else is shared):
  S     signed tokens LN(X), signed factors, softmax(<Q,K>/sqrt(rt))                   [signed YAKAL]
  Sp    positive tokens exp(LN(X)), signed factors, softmax(<Q,K>/sqrt(rt))           [encoding baseline]
  P1    positive tokens, positive factors exp(theta), a ~ s (tau = 1), linear reassociation
  Pt    positive tokens, positive factors, a ~ s^tau, tau = exp(learned) per head
  Pool  positive tokens, column-stochastic factors (softmax over output rows) with an entropy
        penalty (sparse, nearly disjoint pools), a ~ s^tau, learned tau
  U     uniform attention a = 1/N (tau = 0), the attention-off control
Values are V = B_v LN(X) A_v^T (signed) for every variant, and the head outputs are mapped back to p x q
by a Kronecker output map.  Block: pre-LN residual attention + MLP.  Head: mean-pooled tokens -> linear.
"""
import os
import json
import time
import pickle
import hashlib
import numpy as np

os.environ.setdefault("XLA_FLAGS", "--xla_cpu_multi_thread_eigen=false intra_op_parallelism_threads=1")
import jax  # noqa: E402
import jax.numpy as jnp  # noqa: E402

jax.config.update("jax_default_matmul_precision", "highest")

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")
VARIANTS = ("S", "Sp", "P1", "Pt", "Pool", "U")
POSITIVE_TOKENS = ("Sp", "P1", "Pt", "Pool")
POSITIVE_FACTORS = ("P1", "Pt", "Pool")
LEARNED_TAU = ("Pt", "Pool")

CIFAR_MD5 = {"data_batch_1": "c99cafc152244af753f735de768cd75f", "data_batch_2": "d4bba439e000b95fd0a9bffe97cbabec",
             "data_batch_3": "54ebc095f3ab1f0389bbae665268c751", "data_batch_4": "634d18415352ddfa80567beed471001a",
             "data_batch_5": "482c414d41f54cd18b22e5b47cb7c3cb", "test_batch": "40351d587109b95175f43aff81a1287e"}
PF_TEST, PF_VAL, PF_TRAIN = (0, 1), (2, 3), tuple(range(4, 10))


def _md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ---------------------------------------------------------------------------
# data
# ---------------------------------------------------------------------------
def rgb_to_gray_lra(x):
    """tf.image.rgb_to_grayscale on uint8 (as in LRA): float32 weights, then convert_image_dtype back to uint8
    (multiply by 255.5 and truncate)."""
    f = x.astype(np.float32) / np.float32(255.0)
    g = f[..., 0] * np.float32(0.2989) + f[..., 1] * np.float32(0.5870) + f[..., 2] * np.float32(0.1140)
    return np.clip((g * np.float32(255.5)).astype(np.int32), 0, 255).astype(np.uint8)


def load_cifar_gray(with_test=False):
    """LRA-Image: CIFAR-10 in grayscale; train = first 45,000 of the training set, val = last 5,000, test = 10,000.
    The test batch is read only when with_test is True (evaluation)."""
    root = os.path.join(DATA, "cifar_repo")
    xs, ys = [], []
    names = ["data_batch_%d" % k for k in range(1, 6)] + (["test_batch"] if with_test else [])
    for name in names:
        p = os.path.join(root, name)
        if _md5(p) != CIFAR_MD5[name]:
            raise ValueError(f"{name}: md5 mismatch")
        with open(p, "rb") as f:
            d = pickle.load(f, encoding="bytes")
        x = d[b"data"].reshape(-1, 3, 32, 32).transpose(0, 2, 3, 1)
        xs.append(rgb_to_gray_lra(x))
        ys.append(np.array(d[b"labels"], dtype=np.int32))
    Xtr, ytr = np.concatenate(xs[:5]), np.concatenate(ys[:5])
    out = {"Xtr": Xtr[:45000], "ytr": ytr[:45000], "Xva": Xtr[45000:], "yva": ytr[45000:], "n_classes": 10}
    if with_test:
        out.update(Xte=xs[5], yte=ys[5])
    return out


def load_pathfinder(train_shards=None, with_test=False):
    def get(ids):
        X, y = [], []
        for k in ids:
            d = np.load(os.path.join(DATA, "pf", f"shard_{k}.npz"))
            X.append(d["X"])
            y.append(d["y"].astype(np.int32))
        return np.concatenate(X), np.concatenate(y)
    tr = PF_TRAIN if train_shards is None else train_shards
    Xtr, ytr = get(tr)
    Xva, yva = get(PF_VAL)
    out = {"Xtr": Xtr, "ytr": ytr, "Xva": Xva, "yva": yva, "n_classes": 2}
    if with_test:
        Xte, yte = get(PF_TEST)
        out.update(Xte=Xte, yte=yte)
    return out


def load_task(task, with_test=False, **kw):
    if task == "image":
        return load_cifar_gray(with_test)
    if task == "retrieval":
        import retrieval_data
        return retrieval_data.load(with_test=with_test)
    return load_pathfinder(with_test=with_test, **kw)


def patchify(x, patch):
    """uint8 (B, 32, 32) -> float32 (B, N, patch*patch) in [0, 1]."""
    B, H, W = x.shape
    g = H // patch
    x = x.reshape(B, g, patch, g, patch).transpose(0, 1, 3, 2, 4).reshape(B, g * g, patch * patch)
    return x.astype(np.float32) / np.float32(255.0)


# ---------------------------------------------------------------------------
# parameters
# ---------------------------------------------------------------------------
def default_cfg(**kw):
    cfg = dict(variant="S", patch=4, p=4, q=4, r=4, t=4, rv=4, tv=4, heads=2, layers=2, mlp=64,
               n_classes=10, pool_lambda=0.01, lr=1e-3, epochs=10, batch=128, warmup=200, clip=1.0, seed=0,
               readout="mean")
    cfg.update(kw)
    return cfg


def init_params(cfg, key):
    p, q, r, t, rv, tv_, H, L = (cfg[k] for k in ("p", "q", "r", "t", "rv", "tv", "heads", "layers"))
    d = p * q
    npatch = (32 // cfg["patch"]) ** 2
    dp = cfg["patch"] ** 2
    keys = iter(jax.random.split(key, 64))
    nrm = lambda shape, s: s * jax.random.normal(next(keys), shape, dtype=jnp.float32)  # noqa: E731
    params = {"emb_W": nrm((dp, d), 1.0 / np.sqrt(dp)), "emb_b": jnp.zeros((d,), jnp.float32),
              "pos": nrm((npatch, p, q), 0.02), "blocks": [],
              "head_g": jnp.ones((p, q), jnp.float32), "head_b": jnp.zeros((p, q), jnp.float32),
              "out_W": nrm((d, cfg["n_classes"]), 1.0 / np.sqrt(d)),
              "out_b": jnp.zeros((cfg["n_classes"],), jnp.float32)}
    v = cfg["variant"]
    for _ in range(L):
        blk = {"ln1_g": jnp.ones((p, q), jnp.float32), "ln1_b": jnp.zeros((p, q), jnp.float32),
               "ln2_g": jnp.ones((p, q), jnp.float32), "ln2_b": jnp.zeros((p, q), jnp.float32),
               "Bv": nrm((H, rv, p), 1.0 / np.sqrt(p)), "Av": nrm((H, tv_, q), 1.0 / np.sqrt(q)),
               "Bo": nrm((H, p, rv), 1.0 / np.sqrt(rv * H)), "Ao": nrm((H, q, tv_), 1.0 / np.sqrt(tv_)),
               "W1": nrm((d, cfg["mlp"]), 1.0 / np.sqrt(d)), "b1": jnp.zeros((cfg["mlp"],), jnp.float32),
               "W2": nrm((cfg["mlp"], d), 1.0 / np.sqrt(cfg["mlp"])), "b2": jnp.zeros((d,), jnp.float32)}
        if v in POSITIVE_FACTORS and v != "Pool":
            # log-factors: entries near 1/p and 1/q so that Q, K are averages of token entries
            blk.update(Bq=np.log(1.0 / p) + nrm((H, r, p), 0.5), Aq=np.log(1.0 / q) + nrm((H, t, q), 0.5),
                       Bk=np.log(1.0 / p) + nrm((H, r, p), 0.5), Ak=np.log(1.0 / q) + nrm((H, t, q), 0.5))
        elif v == "Pool":
            blk.update(Bq=nrm((H, r, p), 0.5), Aq=nrm((H, t, q), 0.5), Bk=nrm((H, r, p), 0.5), Ak=nrm((H, t, q), 0.5))
        else:
            blk.update(Bq=nrm((H, r, p), 1.0 / np.sqrt(p)), Aq=nrm((H, t, q), 1.0 / np.sqrt(q)),
                       Bk=nrm((H, r, p), 1.0 / np.sqrt(p)), Ak=nrm((H, t, q), 1.0 / np.sqrt(q)))
        if v in LEARNED_TAU:
            blk["log_tau"] = jnp.full((H,), np.log(cfg.get("tau0", 1.0)), jnp.float32)
        params["blocks"].append(blk)
    return params


def count_params(params):
    return int(sum(np.prod(x.shape) for x in jax.tree_util.tree_leaves(params)))


# ---------------------------------------------------------------------------
# forward
# ---------------------------------------------------------------------------
def layer_norm(x, g, b, eps=1e-5):
    mu = x.mean(axis=(-2, -1), keepdims=True)
    var = ((x - mu) ** 2).mean(axis=(-2, -1), keepdims=True)
    return (x - mu) * jax.lax.rsqrt(var + eps) * g + b


def qk_factors(blk, variant):
    """Effective query/key factors (H,r,p), (H,t,q), (H,r,p), (H,t,q)."""
    if variant in ("P1", "Pt"):
        return [jnp.exp(blk[k]) for k in ("Bq", "Aq", "Bk", "Ak")]
    if variant == "Pool":
        return [jax.nn.softmax(blk[k], axis=1) for k in ("Bq", "Aq", "Bk", "Ak")]
    return [blk[k] for k in ("Bq", "Aq", "Bk", "Ak")]


def tau_of(blk, variant):
    if variant in LEARNED_TAU:
        return jnp.exp(blk["log_tau"])
    return None


def pos_tokens(Z):
    return jnp.exp(jnp.clip(Z, -30.0, 30.0))


def kron_map(B, Y, A):
    """B (H,u,p), Y (Bt,N,p,q), A (H,v,q) -> (Bt,H,N,u,v) = B Y A^T per head, in two contractions."""
    T = jnp.einsum('bnpq,hvq->bhnpv', Y, A)
    return jnp.einsum('hup,bhnpv->bhnuv', B, T)


def attention(blk, Z, variant, return_attn=False):
    """Z = LN(X): (B, N, p, q).  Returns the residual update (B, N, p, q) [and attention (B,H,N,N)]."""
    Bt, N = Z.shape[0], Z.shape[1]
    V = kron_map(blk["Bv"], Z, blk["Av"])                       # (B,H,N,rv,tv)
    H, rv, tv_ = V.shape[1], V.shape[3], V.shape[4]
    Vf = V.reshape(Bt, H, N, rv * tv_)
    a = None
    if variant == "U":
        O = jnp.broadcast_to(Vf.mean(axis=2, keepdims=True), Vf.shape)
        if return_attn:
            a = jnp.full((Bt, H, N, N), 1.0 / N)
    else:
        Y = Z if variant == "S" else pos_tokens(Z)
        Bq, Aq, Bk, Ak = qk_factors(blk, variant)
        Q = kron_map(Bq, Y, Aq)
        K = kron_map(Bk, Y, Ak)
        rt = Q.shape[-1] * Q.shape[-2]
        Qf = Q.reshape(Bt, H, N, rt)
        Kf = K.reshape(Bt, H, N, rt)
        if variant in ("S", "Sp"):
            s = jnp.matmul(Qf, jnp.swapaxes(Kf, -1, -2)) / np.sqrt(rt)
            a = jax.nn.softmax(s, axis=-1)
            O = jnp.matmul(a, Vf)
        elif variant == "P1" and not return_attn:
            KV = jnp.matmul(jnp.swapaxes(Kf, -1, -2), Vf)            # (B,H,rt,rv*tv)
            num = jnp.matmul(Qf, KV)
            den = jnp.sum(Qf * Kf.sum(axis=2, keepdims=True), axis=-1)
            O = num / den[..., None]
        else:
            s = jnp.matmul(Qf, jnp.swapaxes(Kf, -1, -2))
            tau = 1.0 if variant == "P1" else tau_of(blk, variant)[None, :, None, None]
            a = jax.nn.softmax(tau * jnp.log(s), axis=-1)
            O = jnp.matmul(a, Vf)
    O = O.reshape(Bt, H, N, rv, tv_)
    T = jnp.einsum('bhnuw,hqw->bhnuq', O, blk["Ao"])
    out = jnp.einsum('hpu,bhnuq->bnpq', blk["Bo"], T)
    return (out, a) if return_attn else out


def forward(params, xp, cfg, return_attn=False):
    """xp: (B, N, patch^2) float32 -> logits (B, C) [and per-layer attention and positive tokens]."""
    p, q, v = cfg["p"], cfg["q"], cfg["variant"]
    B, N, _ = xp.shape
    X = (xp @ params["emb_W"] + params["emb_b"]).reshape(B, N, p, q) + params["pos"][None]
    attns, toks = [], []
    for blk in params["blocks"]:
        Z = layer_norm(X, blk["ln1_g"], blk["ln1_b"])
        if return_attn:
            upd, a = attention(blk, Z, v, return_attn=True)
            attns.append(a)
            toks.append(Z)
        else:
            upd = attention(blk, Z, v)
        X = X + upd
        Z2 = layer_norm(X, blk["ln2_g"], blk["ln2_b"]).reshape(B, N, p * q)
        X = X + (jax.nn.gelu(Z2 @ blk["W1"] + blk["b1"]) @ blk["W2"] + blk["b2"]).reshape(B, N, p, q)
    Zn = layer_norm(X, params["head_g"], params["head_b"])
    Zh = (Zn[:, 0] if cfg.get("readout", "mean") == "first" else Zn.mean(axis=1)).reshape(B, p * q)
    logits = Zh @ params["out_W"] + params["out_b"]
    return (logits, attns, toks) if return_attn else logits


def pool_entropy(params, cfg):
    if cfg["variant"] != "Pool":
        return 0.0
    tot, cnt = 0.0, 0
    for blk in params["blocks"]:
        for k in ("Bq", "Aq", "Bk", "Ak"):
            P = jax.nn.softmax(blk[k], axis=1)
            tot = tot + (-(P * jnp.log(P + 1e-12)).sum(axis=1)).mean()
            cnt += 1
    return tot / cnt


def loss_fn(params, xp, y, cfg):
    logits = forward(params, xp, cfg)
    lse = jax.nn.logsumexp(logits, axis=1)
    ce = (lse - jnp.take_along_axis(logits, y[:, None], axis=1)[:, 0]).mean()
    reg = cfg["pool_lambda"] * pool_entropy(params, cfg) if cfg["variant"] == "Pool" else 0.0
    return ce + reg, ce


# ---------------------------------------------------------------------------
# training
# ---------------------------------------------------------------------------
def make_step(cfg, total_steps):
    lr_peak, warm, clip = cfg["lr"], cfg["warmup"], cfg["clip"]
    b1, b2, eps = 0.9, 0.999, 1e-8

    def lr_at(step):
        w = jnp.minimum(1.0, (step + 1.0) / warm)
        c = 0.5 * (1.0 + jnp.cos(jnp.pi * jnp.minimum(step, total_steps) / total_steps))
        return lr_peak * w * c

    @jax.jit
    def step(params, opt, xp, y):
        (loss, ce), grads = jax.value_and_grad(loss_fn, has_aux=True)(params, xp, y, cfg)
        gnorm = jnp.sqrt(sum(jnp.sum(g * g) for g in jax.tree_util.tree_leaves(grads)))
        scale = jnp.minimum(1.0, clip / (gnorm + 1e-12))
        grads = jax.tree_util.tree_map(lambda g: g * scale, grads)
        t = opt["t"] + 1.0
        m = jax.tree_util.tree_map(lambda m_, g: b1 * m_ + (1 - b1) * g, opt["m"], grads)
        v = jax.tree_util.tree_map(lambda v_, g: b2 * v_ + (1 - b2) * g * g, opt["v"], grads)
        lr = lr_at(opt["t"])
        params = jax.tree_util.tree_map(
            lambda p_, m_, v_: p_ - lr * (m_ / (1 - b1 ** t)) / (jnp.sqrt(v_ / (1 - b2 ** t)) + eps), params, m, v)
        return params, {"t": t, "m": m, "v": v}, ce, gnorm
    return step


def make_eval(cfg):
    @jax.jit
    def ev(params, xp):
        return jnp.argmax(forward(params, xp, cfg), axis=1)
    return ev


def accuracy(ev, params, X, y, patch, bs=1000):
    correct = 0
    for i in range(0, len(X), bs):
        pred = np.asarray(ev(params, jnp.asarray(patchify(X[i:i + bs], patch))))
        correct += int((pred == y[i:i + bs]).sum())
    return correct / len(X)


def train(cfg, data, log=print, eval_every=None):
    key = jax.random.PRNGKey(cfg["seed"])
    params = init_params(cfg, key)
    n = len(data["Xtr"])
    spe = n // cfg["batch"]
    total = spe * cfg["epochs"]
    step = make_step(cfg, total)
    ev = make_eval(cfg)
    opt = {"t": jnp.zeros(()), "m": jax.tree_util.tree_map(jnp.zeros_like, params),
           "v": jax.tree_util.tree_map(jnp.zeros_like, params)}
    rng = np.random.default_rng(cfg["seed"] + 7919)
    hist = []
    t0 = time.time()
    for ep in range(cfg["epochs"]):
        perm = rng.permutation(n)
        ce_sum = 0.0
        for k in range(spe):
            idx = perm[k * cfg["batch"]:(k + 1) * cfg["batch"]]
            xp = jnp.asarray(patchify(data["Xtr"][idx], cfg["patch"]))
            params, opt, ce, gn = step(params, opt, xp, jnp.asarray(data["ytr"][idx]))
            ce_sum += float(ce) if (k % 50 == 0 or k == spe - 1) else 0.0
        va = accuracy(ev, params, data["Xva"], data["yva"], cfg["patch"])
        taus = [np.asarray(jnp.exp(b["log_tau"])).round(3).tolist() for b in params["blocks"]] \
            if cfg["variant"] in LEARNED_TAU else None
        hist.append({"epoch": ep + 1, "val_acc": va, "time": time.time() - t0, "last_ce": float(ce), "tau": taus})
        log(f"  epoch {ep + 1:3d}  val {va:.4f}  ce {float(ce):.4f}  {time.time() - t0:7.1f}s" +
            (f"  tau {taus}" if taus else ""))
    return params, hist


def save_params(path, params, cfg, extra=None):
    flat, tree = jax.tree_util.tree_flatten(params)
    np.savez(path + ".npz", *[np.asarray(x) for x in flat])
    meta = {"cfg": cfg, "treedef": str(tree)}
    if extra:
        meta.update(extra)
    json.dump(meta, open(path + ".json", "w"), indent=1)


def load_params(path):
    meta = json.load(open(path + ".json"))
    cfg = meta["cfg"]
    template = init_params(cfg, jax.random.PRNGKey(0))
    flat, tree = jax.tree_util.tree_flatten(template)
    d = np.load(path + ".npz")
    leaves = [jnp.asarray(d[f"arr_{i}"]) for i in range(len(flat))]
    return jax.tree_util.tree_unflatten(tree, leaves), cfg, meta
