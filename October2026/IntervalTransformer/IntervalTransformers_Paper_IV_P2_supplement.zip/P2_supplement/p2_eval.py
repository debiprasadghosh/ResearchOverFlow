"""P2 frozen evaluator: accuracy, attention statistics and TV certificates on held-out data.

For every trained model (task, variant, seed):
  - accuracy on the whole evaluation split;
  - on the first N_CERT images of the split, for every held-out query (image x layer x head x query position):
      effective key count exp(H(a_i)); log-score spread SD_j log s_ij (positive scores) or logit spread
      SD_j s_ij/sqrt(rt) (signed); the learned tau; and for positive-factor variants the certificates at each rho in
      RHOS: Eq. 11, tanh(Omega_up/4) with the triangle diameter, Bennett-Pinsker, L1, and their minimum;
  - on the first SUB images: the exact L1 diameter D_i and the Omega sandwich, the Omega witness at the sign
    vertex, and TV witnesses (explicit factor perturbations evaluated exactly) for WIT_QUERIES positions;
  - for signed variants (exploratory): a TV bound under the same sign-preserving factor log box from absolute
    masses, |s_ij(d) - s_ij(0)| <= (e^{4 rho} - 1) <|B_q||Y_i||A_q|^T, |B_k||Y_j||A_k|^T>.
Certificates are real-arithmetic bounds evaluated in float64 at the model's nominal (float32) tokens.

Usage: python3 p2_eval.py <task> <split: val|test> [run names ...]
"""
import os
import sys
import json
import glob
import time
import numpy as np

os.environ.setdefault("XLA_FLAGS", "--xla_cpu_multi_thread_eigen=false intra_op_parallelism_threads=1")
import p2cert_jax as CJ  # noqa: E402  (enables float64 in JAX before anything else is traced)
import jax  # noqa: E402
import jax.numpy as jnp  # noqa: E402
import p2lib as L  # noqa: E402
import p2cert as C  # noqa: E402

RHOS = (0.01, 0.02, 0.05)
RHO_MAIN = 0.02
TARGET = 0.1
N_CERT = 2000        # images per task on which every query is certified
SUB = 100            # images with exact diameters and witnesses
WIT_QUERIES = 16     # query positions per subsample image for TV witnesses (evenly spaced)
CHUNK = 25


def factors64(blk, variant, h):
    if variant in ("P1", "Pt"):
        return [np.exp(np.asarray(blk[k][h], dtype=np.float64)) for k in ("Bq", "Aq", "Bk", "Ak")]
    if variant == "Pool":
        out = []
        for k in ("Bq", "Aq", "Bk", "Ak"):
            z = np.asarray(blk[k][h], dtype=np.float64)
            z = z - z.max(axis=0, keepdims=True)
            e = np.exp(z)
            out.append(e / e.sum(axis=0, keepdims=True))
        return out
    return [np.asarray(blk[k][h], dtype=np.float64) for k in ("Bq", "Aq", "Bk", "Ak")]


def tau64(blk, variant, h):
    if variant in ("Pt", "Pool"):
        return float(np.exp(np.asarray(blk["log_tau"][h], dtype=np.float64)))
    return 1.0


def entropy_eff(a):
    return np.exp(-(a * np.log(np.maximum(a, 1e-300))).sum(axis=-1))


def signed_stats(fac, Y, rho):
    """Signed scoring: logit spread, and (exploratory) the TV bound under the sign-preserving box."""
    Bq, Aq, Bk, Ak = fac
    rt = Bq.shape[0] * Aq.shape[0]
    s = np.einsum('iauv,ibuv->iab', np.einsum('up,inpq,vq->inuv', Bq, Y, Aq, optimize=True),
                  np.einsum('up,inpq,vq->inuv', Bk, Y, Ak, optimize=True), optimize=True)
    Ya = np.abs(Y)
    sabs = np.einsum('iauv,ibuv->iab',
                     np.einsum('up,inpq,vq->inuv', np.abs(Bq), Ya, np.abs(Aq), optimize=True),
                     np.einsum('up,inpq,vq->inuv', np.abs(Bk), Ya, np.abs(Ak), optimize=True), optimize=True)
    dev = np.expm1(4 * rho) * sabs / np.sqrt(rt)
    stv = np.tanh(2.0 * dev.max(axis=2) / 4.0)
    kappa = np.median(sabs / np.maximum(np.abs(s), 1e-300), axis=2)
    return (s / np.sqrt(rt)).std(axis=2), stv, kappa


def evaluate_run(run_path, data, split):
    params, cfg, meta = L.load_params(run_path)
    v = cfg["variant"]
    X, y = data["X" + split], data["y" + split]
    ev = L.make_eval(cfg)
    acc = L.accuracy(ev, params, X, y, cfg["patch"])
    fwd = jax.jit(lambda prm, xp: L.forward(prm, xp, cfg, return_attn=True))
    res = {"run": os.path.basename(run_path), "task": meta.get("task"), "variant": v, "seed": cfg["seed"],
           "acc": acc, "n_eval": int(len(X)), "n_cert_images": N_CERT, "layers": []}
    t0 = time.time()
    nb = len(params["blocks"])
    H = cfg["heads"]
    acc_lists = {(li, h): {} for li in range(nb) for h in range(H)}
    facs = {(li, h): factors64(params["blocks"][li], v, h) for li in range(nb) for h in range(H)}
    taus = {(li, h): tau64(params["blocks"][li], v, h) for li in range(nb) for h in range(H)}
    Xc = X[:N_CERT]
    for i0 in range(0, len(Xc), CHUNK):
        xp = jnp.asarray(L.patchify(Xc[i0:i0 + CHUNK], cfg["patch"]))
        _, attns, toks = fwd(params, xp)
        for li in range(nb):
            Z = np.asarray(toks[li], dtype=np.float64)
            for h in range(H):
                d = acc_lists[(li, h)]
                a32 = np.asarray(attns[li][:, h], dtype=np.float64)
                d.setdefault("eff", []).append(entropy_eff(a32))
                if "pos" + split in data:          # retrieval: attention of the query token on the matching key
                    pos = data["pos" + split][i0:i0 + CHUNK]
                    d.setdefault("match_mass", []).append(a32[np.arange(len(pos)), 0, pos])
                if v == "U":
                    continue
                fac = facs[(li, h)]
                if v in ("S", "Sp"):
                    Y = Z if v == "S" else np.exp(np.clip(Z, -30, 30))
                    sp, stv, kap = signed_stats(fac, Y, RHO_MAIN)
                    d.setdefault("spread", []).append(sp)
                    d.setdefault("signed_tv", []).append(stv)
                    d.setdefault("kappa", []).append(kap)
                    continue
                Y = jnp.asarray(np.exp(np.clip(Z, -30, 30)))
                summ, _ = CJ.summaries(*[jnp.asarray(f) for f in fac], Y, taus[(li, h)])
                for k in ("w_max", "w_mean", "w_rms", "D_tri", "spread", "eff"):
                    d.setdefault(k if k != "eff" else "eff64", []).append(np.asarray(summ[k]))
    arrays = {}
    for li in range(nb):
        for h in range(H):
            d = {k: np.concatenate(vals) for k, vals in acc_lists[(li, h)].items()}
            tau = taus[(li, h)]
            entry = {"layer": li, "head": h, "tau": tau, "eff_median": float(np.median(d["eff"]))}
            arrays[f"L{li}H{h}_eff"] = d["eff"].astype(np.float32)
            if "match_mass" in d:
                arrays[f"L{li}H{h}_match_mass"] = d["match_mass"].astype(np.float32)
                entry["match_mass_median"] = float(np.median(d["match_mass"]))
            if "spread" in d:
                arrays[f"L{li}H{h}_spread"] = d["spread"].astype(np.float32)
                entry["spread_median"] = float(np.median(d["spread"]))
                entry["spread_x_sqrt_pq_median"] = entry["spread_median"] * np.sqrt(cfg["p"] * cfg["q"])
            if v in ("S", "Sp"):
                arrays[f"L{li}H{h}_signed_tv"] = d["signed_tv"].astype(np.float32)
                arrays[f"L{li}H{h}_kappa"] = d["kappa"].astype(np.float32)
                entry["signed_certified_frac"] = float((d["signed_tv"] <= TARGET).mean())
                entry["signed_tv_median"] = float(np.median(d["signed_tv"]))
                entry["kappa_median"] = float(np.median(d["kappa"]))
            if v in L.POSITIVE_FACTORS:
                S = {k: d[k].ravel() for k in ("w_max", "w_mean", "w_rms", "D_tri")}
                for k in S:
                    arrays[f"L{li}H{h}_{k}"] = S[k].astype(np.float32)
                    entry[f"{k}_median"] = float(np.median(S[k]))
                for r in RHOS:
                    c = C.certificates_from_summaries(S, tau, r)
                    arrays[f"L{li}H{h}_cert_rho{r}"] = c["cert"].reshape(d["w_max"].shape).astype(np.float32)
                    entry[f"certified_frac_rho{r}"] = float((c["cert"] <= TARGET).mean())
                    if r == RHO_MAIN:
                        for k in ("c_omega", "c_kl", "c_l1", "omega_up"):
                            arrays[f"L{li}H{h}_{k}"] = c[k].reshape(d["w_max"].shape).astype(np.float32)
                            entry[f"{k}_median"] = float(np.median(c[k]))
                        for k in ("eq11", "c_omega", "c_kl", "c_l1"):
                            entry[f"frac_{k}_le_target"] = float((c[k] <= TARGET).mean())
                        entry["cert_median"] = float(np.median(c["cert"]))
                        entry["cert_q95"] = float(np.quantile(c["cert"], 0.95))
                entry["eq11_value"] = float(C.eq11(tau, RHO_MAIN))
                entry.update(subsample_checks(params, cfg, li, h, facs[(li, h)], tau, X[:SUB]))
            res["layers"].append(entry)
    if v in L.POSITIVE_FACTORS:
        for r in RHOS:
            allr = np.concatenate([arrays[k].ravel() for k in arrays if k.endswith(f"_cert_rho{r}")])
            res[f"certified_frac_rho{r}"] = float((allr <= TARGET).mean())
            res[f"cert_q95_rho{r}"] = float(np.quantile(allr, 0.95))
        res["certified_frac"] = res[f"certified_frac_rho{RHO_MAIN}"]
        res["eq11_frac"] = float(np.mean([C.eq11(e["tau"], RHO_MAIN) <= TARGET for e in res["layers"]]))
    res["eval_seconds"] = time.time() - t0
    return res, arrays


def subsample_checks(params, cfg, li, h, fac, tau, Xs):
    """Exact diameters, Omega sandwich and witnesses on the first SUB images."""
    xp = jnp.asarray(L.patchify(Xs, cfg["patch"]))
    _, _, toks = L.forward(params, xp, cfg, return_attn=True)
    Y = np.exp(np.clip(np.asarray(toks[li], dtype=np.float64), -30, 30))
    facj = [jnp.asarray(f) for f in fac]
    Ds, js, ks = [], [], []
    for i0 in range(0, len(Y), 4):
        D, j, k = CJ.diameters(*facj, jnp.asarray(Y[i0:i0 + 4]))
        Ds.append(np.asarray(D))
        js.append(np.asarray(j))
        ks.append(np.asarray(k))
    D, J, K = np.concatenate(Ds), np.concatenate(js), np.concatenate(ks)
    rho = RHO_MAIN
    om_lo = tau * (rho * D - 8 * rho * rho)
    om_up = np.minimum(tau * (rho * D + 8 * rho * rho), 8 * tau * rho)
    N = Y.shape[1]
    qsel = np.linspace(0, N - 1, WIT_QUERIES).round().astype(int)
    om_wit, tv_wit, tv_cert = [], [], []
    for n_img, x in enumerate(Y):
        G, s = C.factor_masses(*fac, x[qsel], x)
        a = C.attn_from_scores(s, tau)
        cb = C.certificates_batch(G, a, tau, rho)
        for m, i in enumerate(qsel):
            om_wit.append(C.omega_witness(fac, x[i], x, tau, rho, G[m], int(J[n_img, i]), int(K[n_img, i])))
            w, _ = C.tv_witness(fac, x[i], x, tau, rho, G[m], a[m])
            tv_wit.append(w)
            tv_cert.append(float(cb["cert"][m]))
    om_wit, tv_wit, tv_cert = np.array(om_wit), np.array(tv_wit), np.array(tv_cert)
    om_up_sel = om_up[:, qsel].ravel()
    om_lo_sel = om_lo[:, qsel].ravel()
    return {"sub_D_median": float(np.median(D)), "sub_D_max": float(D.max()),
            "sub_omega_lo_median": float(np.median(om_lo)), "sub_omega_up_median": float(np.median(om_up)),
            "sub_omega_witness_median": float(np.median(om_wit)),
            "sub_omega_witness_inside": bool(np.all((om_wit <= om_up_sel + 1e-12) & (om_wit >= om_lo_sel - 1e-12))),
            "sub_tanh_omega_exact_frac": float((np.tanh(om_up / 4) <= TARGET).mean()),
            "sub_tv_witness_median": float(np.median(tv_wit)), "sub_tv_witness_max": float(tv_wit.max()),
            "sub_tv_cert_median": float(np.median(tv_cert)),
            "sub_witness_over_cert_median": float(np.median(tv_wit / np.maximum(tv_cert, 1e-300))),
            "sub_witness_violations": int((tv_wit > tv_cert + 1e-12).sum()),
            "sub_witness_frac_gt_target": float((tv_wit > TARGET).mean())}


def main():
    task, split = sys.argv[1], sys.argv[2]
    names = sys.argv[3:]
    if not names:
        names = sorted(os.path.basename(p)[:-4] for p in glob.glob(os.path.join("runs", task, "*.npz"))
                       if not os.path.basename(p).startswith("pilot_"))
    data = L.load_task(task, with_test=(split == "test"))
    outdir = os.path.join("evals", split, task)
    os.makedirs(outdir, exist_ok=True)
    for name in names:
        if os.path.exists(os.path.join(outdir, name + ".json")):
            continue
        res, arrays = evaluate_run(os.path.join("runs", task, name), data, "te" if split == "test" else "va")
        np.savez_compressed(os.path.join(outdir, name + ".npz"), **arrays)
        json.dump(res, open(os.path.join(outdir, name + ".json"), "w"), indent=1)
        print(f"{name}: acc {res['acc']:.4f}" + (f"  certified {res['certified_frac']:.4f}"
                                                 if "certified_frac" in res else "") +
              f"  ({res['eval_seconds']:.0f}s)", flush=True)


if __name__ == "__main__":
    main()
