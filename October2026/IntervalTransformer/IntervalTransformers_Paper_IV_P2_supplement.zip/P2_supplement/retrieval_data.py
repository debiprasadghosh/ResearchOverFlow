"""Controlled content-retrieval task on matrix tokens (added to the P2 protocol; see PROTOCOL.md).

Each example is a 32 x 32 image read as 64 tokens of 4 x 4 pixels (the same patching as the LRA tasks).
Rows 0-2 of a token (12 pixels) carry a code, a fixed sparse pattern with 3 of 12 pixels lit, one of K = 8;
row 3 (4 pixels) carries a value 0-9 as a 4-bit binary pattern.  Token 0 is the query: its code is c and its row 3
is the marker 1111 (never a value).  Tokens 1-7 are keys with distinct codes, one of which is c (a random
permutation of 7 of the 8 codes that contains c); every key has an independent random value.  Tokens 8-63 are
blank (all patterns zero).  The label is the value of the matching key.  Intensities are
0.2 + 0.6 * pattern + N(0, SIGMA^2), clipped to [0, 1] and stored as uint8.

Attention is necessary by construction: without it, the query token cannot reach the matching key's value.
"""
import os
import numpy as np

K, NTOK, NKEY, SIGMA = 8, 64, 7, 0.1
CODE_SEED = 20261020
SPLITS = {"tr": (50000, 20261021), "va": (10000, 20261022), "te": (20000, 20261023)}


def codebook():
    rng = np.random.default_rng(CODE_SEED)
    codes = set()
    while len(codes) < K:
        codes.add(tuple(sorted(rng.choice(12, 3, replace=False).tolist())))
    book = np.zeros((K, 12), dtype=np.float32)
    for k, c in enumerate(sorted(codes)):
        book[k, list(c)] = 1.0
    return book


def value_patterns():
    return np.array([[(v >> b) & 1 for b in (3, 2, 1, 0)] for v in range(10)], dtype=np.float32)


def generate(n, seed):
    rng = np.random.default_rng(seed)
    book, vals = codebook(), value_patterns()
    q_code = rng.integers(0, K, n)
    codes = np.zeros((n, NTOK), dtype=np.int64)
    present = np.zeros((n, NTOK), dtype=bool)
    match_pos = np.zeros(n, dtype=np.int64)
    for e in range(n):
        others = rng.permutation([k for k in range(K) if k != q_code[e]])[:NKEY - 1]
        keys = rng.permutation(np.concatenate([[q_code[e]], others]))
        codes[e, 1:NKEY + 1] = keys
        match_pos[e] = 1 + int(np.nonzero(keys == q_code[e])[0][0])
    codes[:, 0] = q_code
    present[:, :NKEY + 1] = True
    values = rng.integers(0, 10, (n, NTOK))
    y = values[np.arange(n), match_pos].astype(np.int32)
    tok = np.zeros((n, NTOK, 16), dtype=np.float32)
    tok[:, :, :12] = book[codes] * present[..., None]
    tok[:, :, 12:] = vals[values] * present[..., None]
    tok[:, 0, 12:] = 1.0                                         # query marker
    x = 0.2 + 0.6 * tok + SIGMA * rng.standard_normal(tok.shape).astype(np.float32)
    x = np.clip(np.round(np.clip(x, 0.0, 1.0) * 255.0), 0, 255).astype(np.uint8)
    # tokens -> 32 x 32 image: token n at grid (n // 8, n % 8), pixels row-major within the 4 x 4 patch
    img = x.reshape(n, 8, 8, 4, 4).transpose(0, 1, 3, 2, 4).reshape(n, 32, 32)
    return img, y, match_pos.astype(np.int32)


def load(with_test=False, cache_dir=None):
    cache_dir = cache_dir or os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "retrieval")
    os.makedirs(cache_dir, exist_ok=True)
    out = {"n_classes": 10}
    for split, (n, seed) in SPLITS.items():
        if split == "te" and not with_test:
            continue
        p = os.path.join(cache_dir, f"{split}.npz")
        if not os.path.exists(p):
            img, y, pos = generate(n, seed)
            np.savez_compressed(p, X=img, y=y, pos=pos)
        d = np.load(p)
        out["X" + split], out["y" + split], out["pos" + split] = d["X"], d["y"], d["pos"]
    return out
