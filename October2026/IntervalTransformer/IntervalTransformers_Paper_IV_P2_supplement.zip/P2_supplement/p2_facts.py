"""Print every number quoted in the P2 paper from its source files (for checking)."""
import json
import os
import numpy as np

S = json.load(open("report/summary.json"))
pct = lambda x: f"{100 * x:.2f}"  # noqa: E731


def ci(m):
    return f"{pct(m[0])} [{pct(m[1])}, {pct(m[2])}]"


print("== Accuracy (seed mean, 95% t-interval) and paired difference vs S")
for t in ("image", "pathfinder", "retrieval"):
    T = S[t]
    for v in ("S", "Sp", "P1", "Pt", "Pool", "U"):
        if v in T:
            d = T[v].get("diff_vs_S")
            dd = "" if v == "S" or d is None or d[1] is None else f"  vs S {ci(d)}"
            c = f"  certified {pct(T[v]['certified_mean'])} (min {pct(T[v]['certified_min'])})" if "certified_mean" in T[v] else ""
            print(f"  {t:10s} {v:4s} {ci(T[v]['acc_mean_ci'])}{dd}{c}  per seed {[round(100 * a, 2) for a in T[v]['acc']]}")
    if "gate" in T:
        print(f"  {t} gate S-U = {100 * T['gate']['S_minus_U']:+.2f}")
print("\n== Certificates on confirmatory positive models (Table 7)")
for t, D in S["cert_detail"].items():
    for v, e in D.items():
        print(f"  {t:9s} {v:4s} eq11 {e['eq11_median']:.4f} tanhOm {e['c_omega_median']:.4f} BP {e['c_kl_median']:.4f} "
              f"L1 {e['c_l1_median']:.4f} cert {e['cert_median']:.4f} wit {e['sub_tv_witness_median']:.4f} "
              f"w/c {e['sub_witness_over_cert_median']:.2f} D {e['sub_D_median']:.2f} Om {e['sub_omega_lo_median']:.3f}/"
              f"{e['sub_omega_witness_median']:.3f}/{e['sub_omega_up_median']:.3f} best {e['which_best']} "
              f"viol {e['sub_witness_violations']} inside {e['omega_inside_all']}")
print("\n== Heads (Tables 4, 6)")
for t, D in S["head_detail"].items():
    for v, e in D.items():
        print(f"  {t:9s} {v:4s} " + ", ".join(f"{k}={v2:.3f}" if isinstance(v2, float) else f"{k}={v2}"
                                              for k, v2 in e.items() if k != "match_mass_all"))
print("\n== Sweep (Section 7.1)")
for k, e in S["sweep"].items():
    print(f"  {k}: " + ", ".join(f"{a}={b}" for a, b in e.items()))
print("\n== Exploratory runs (Tables 8, 9)")
for k, e in S["explore"].items():
    w = e.get("witness_query0", {})
    print(f"  {k}: acc {pct(e['acc'])} cert {e['certified_rho0.01']:.4f}/{e['certified_rho0.02']:.4f}/{e['certified_rho0.05']:.4f} "
          f"tau {e['top_tau']:.2f} eff_q0 {e['top_query0_eff']:.2f} mm {e['top_match_mass']:.3f} head_cert {e['top_certified']:.4f} "
          f"eq11 {e['top_eq11']:.4f} D {e['top_D']:.2f} Om {[round(x, 3) for x in e['top_omega']]} wit>0.1 {e['top_witness_gt']:.3f} "
          f"w/c {e['top_witness_over_cert']:.3f}" + (f" | q0: cert {w['certified_frac']:.3f} wit {w['witness_median']:.4f} "
                                                      f">0.1 {w['witness_gt_0.1_frac']:.3f} flips {w['prediction_flip_frac']:.3f} "
                                                      f"acc {w['acc_nominal']:.3f}->{w['acc_under_witness']:.3f}" if w else ""))
print("\n== Latency (Table 11)")
L = S["latency"]
for n, row in L["ms"].items():
    print(f"  N={n}: " + "  ".join(f"{k} {v:.3f}" for k, v in row.items()))
print(f"  cert ms/image/head {L['cert_ms_per_image_per_head']:.3f}; forward ms/image {L['model_forward_ms_per_image_pool']:.3f}; "
      f"ratio (4 heads) {4 * L['cert_ms_per_image_per_head'] / L['model_forward_ms_per_image_pool']:.1f}")
print("\n== Init statistics (Appendix C)")
for v, d in S["init_stats"].items():
    print(f"  {v}: " + "; ".join(f"{l}: spread {x['logit_spread_median']:.3f} eff {x['eff_keys_median']:.1f}" for l, x in d.items()))
print("\n== L10 repeat (Table 3)")
D = json.load(open("l10_repeat.json"))
for k, e in D.items():
    print(f"  {k}: spread {e['spread']:.4f} tau {e['tau']:.1f} eq11 {e['eq11']:.3f} cert {e['cert']:.3f} wit {e['witness']:.3f} "
          f"D {e['D']:.2f} certified {e['cert_le_0.1']:.2f}")
print("\n== Theory checks")
print("  " + open("verify_p2_theory_output.txt").read().strip().splitlines()[-1])


# ---------------------------------------------------------------------------------------------------------------
# Numbers added in the revision (Sections 4.1, 6.4, 7.2-7.5, 8-10 and Appendix C)
# ---------------------------------------------------------------------------------------------------------------
import glob  # noqa: E402
import ast  # noqa: E402


def ev(task, name):
    return json.load(open(os.path.join("evals", "test", task, name + ".json")))


print("\n== Certificate ratios (Section 6.4): ratios of medians")
for t, D in S["cert_detail"].items():
    for v, e in D.items():
        print(f"  {t:9s} {v:4s} tanhOm/cert {e['c_omega_median'] / e['cert_median']:.2f}  eq11/cert "
              f"{e['eq11_median'] / e['cert_median']:.2f}  eq11/witness {e['eq11_median'] / e['sub_tv_witness_median']:.1f}")

print("\n== Per-head median witness/certificate ratios (Sections 1, 6.4, 9)")
for t in ("image", "retrieval"):
    rows = []
    for v in ("P1", "Pt", "Pool"):
        for s_ in range(5):
            for L_ in ev(t, f"{v}_s{s_}")["layers"]:
                rows.append((L_["sub_witness_over_cert_median"], f"{v}_s{s_} L{L_['layer']}H{L_['head']}",
                             L_["sub_tv_witness_median"], L_["sub_tv_cert_median"]))
    rows.sort()
    print(f"  {t}: range {rows[0][0]:.3f}-{rows[-1][0]:.3f}; smallest: " +
          "; ".join(f"{n} ratio {r:.3f} wit {w:.4f} cert {c:.4f}" for r, n, w, c in rows[:7]))
for n in sorted(glob.glob(os.path.join("evals", "test", "retrieval", "explore_*.json"))):
    r = json.load(open(n))
    print(f"  {os.path.basename(n)[:-5]}: " + "  ".join(
        f"L{L_['layer']}H{L_['head']} {L_['sub_witness_over_cert_median']:.3f} (wit {L_['sub_tv_witness_median']:.4f}, "
        f"max {L_['sub_tv_witness_max']:.4f})" for L_ in r["layers"]))

print("\n== Log-score spreads, median over heads (Tables 4, 6; Section 7.1)")
for t in ("image", "retrieval"):
    for v in ("P1", "Pt", "Pool"):
        e = S["head_detail"][t][v]
        print(f"  {t:9s} {v:4s} log-score spread {e['conc_spread_median'] / 8:.3f}  x sqrt(pq) {e['conc_spread_median']:.2f}")
for k in ("tok4_Pt", "tok8_Pt", "tok4_Pool", "tok8_Pool"):
    print(f"  sweep {k}: log-score spread {S['sweep'][k]['spread_median']:.3f}")

print("\n== Match mass per model, largest head (Section 6.3)")
for v in ("S", "Sp", "P1", "Pt", "Pool"):
    print(f"  {v}: " + ", ".join(f"{max(L_['match_mass_median'] for L_ in ev('retrieval', f'{v}_s{s_}')['layers']):.4f}"
                                 for s_ in range(5)))
h = [ast.literal_eval(x) if isinstance(x, str) else x for x in
     (json.load(open(os.path.join("runs", "retrieval", f"S_s{s_}.json")))["history"] for s_ in range(5))]
print("  S validation accuracy after epoch 1: " + ", ".join(f"{x[0]['val_acc']:.4f}" for x in h))

print("\n== Exploratory selecting heads (Sections 7.2, 7.3, 9)")
for n in sorted(glob.glob(os.path.join("evals", "test", "retrieval", "explore_*.json"))):
    r = json.load(open(n))
    top = max(r["layers"], key=lambda L_: L_["tau"])
    print(f"  {os.path.basename(n)[:-5]}: L{top['layer']}H{top['head']} tau {top['tau']:.2f} log-score spread "
          f"{top['spread_median']:.3f} logit spread {top['tau'] * top['spread_median']:.2f} D {top['sub_D_median']:.2f}")

print("\n== Exploratory pools that learned: certified fractions by position (Section 7.3)")
for n in ("explore_Pool_lr0.003_ep12_s0", "explore_Pool_lr0.003_ep12_s1", "explore_Pool_lr0.003_ep12_s2",
          "explore_tok4_Pool_lr0.003_ep12_s0"):
    A = np.load(os.path.join("evals", "test", "retrieval", n + ".npz"))
    c = np.stack([A[f"L{l_}H{h_}_cert_rho0.02"] for l_ in (0, 1) for h_ in (0, 1)])
    q1 = A["L0H1_cert_rho0.01"][:, 0]
    q2 = A["L0H1_cert_rho0.02"][:, 0]
    print(f"  {n}: all {100 * (c <= 0.1).mean():.1f}%  content positions 0-7 {100 * (c[:, :, :8] <= 0.1).mean():.1f}%  "
          f"blank positions {100 * (c[:, :, 8:] <= 0.1).mean():.1f}%  | decision query, 2000 images: rho 0.01 "
          f"{100 * (q1 <= 0.1).mean():.1f}%  rho 0.02 {100 * (q2 <= 0.1).mean():.1f}%")
for p_ in sorted(glob.glob(os.path.join("explore", "witness_*.json"))):
    w = json.load(open(p_))["summary"]
    print(f"  {w['run']}: decision-query witness max {w['witness_max']:.4f}")

print("\n== Pool entropy (Section 7.2, Appendix C)")
P = json.load(open(os.path.join("explore", "pool_entropy.json")))
groups = {"confirmatory retrieval": lambda k: k.startswith("retrieval/Pool_s"),
          "LRA-Image": lambda k: k.startswith("image/Pool_s"),
          "explore 4 epochs": lambda k: "ep4" in k,
          "explore 12 epochs 8x8": lambda k: k.startswith("retrieval/explore_Pool_lr0.003_ep12"),
          "explore 12 epochs 4x4": lambda k: k.startswith("retrieval/explore_tok4_Pool")}
for g, f in groups.items():
    ks = [k for k in P if f(k)]
    hs = [x["entropy"] for k in ks for x in P[k]["heads"]]
    mx = [x["max_weight"] for k in ks for x in P[k]["heads"]]
    print(f"  {g}: per head {min(hs):.3f}-{max(hs):.3f}; model means " +
          ", ".join(f"{P[k]['model_mean_entropy']:.3f}" for k in ks) + f"; largest weight {min(mx):.3f}-{max(mx):.3f}")

print("\n== Signed witnesses, seed 0 (Section 7.4, Table 10)")
W = json.load(open(os.path.join("explore", "signed_witness.json")))
for k, heads in W.items():
    print(f"  {k}: " + "  ".join(f"{h_} {100 * x['frac_gt_0.1']:.1f}% ({x['median']:.3f})" for h_, x in heads.items()))
img = W["image_S_s0"]
print(f"  image S: mean over heads of the fraction above 0.1: {100 * np.mean([x['frac_gt_0.1'] for x in img.values()]):.1f}%")

print("\n== L10 thresholds (Section 5): (rho D + 8 rho^2) / (4 artanh 0.1) at the median D")
c4 = 4 * np.arctanh(0.1)
L10 = json.load(open("l10_repeat.json"))
for k in ("dense_raw_4", "dense_raw_8", "sparse_raw_4"):
    print(f"  {k}: spread {L10[k]['spread']:.4f} threshold {(0.02 * L10[k]['D'] + 8 * 0.02 ** 2) / c4:.4f}")

print("\n== Latency ratios (Section 7.5)")
ms = L["ms"]
for n in ("64", "256", "1024"):
    print(f"  N={n}: S/P1 {ms[n]['S'] / ms[n]['P1']:.2f}  Pt/S {ms[n]['Pt'] / ms[n]['S']:.3f}  Pool/S {ms[n]['Pool'] / ms[n]['S']:.3f}")

print("\n== Checks (Section 4)")
for f in ("report/pf_cache_check.txt", "report/image_code_check.txt", "report/retrieval_reference.txt"):
    if os.path.exists(f):
        print(f"  {f}: " + open(f).read().strip().splitlines()[-1])
