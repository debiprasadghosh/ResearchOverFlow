"""Exploratory (post hoc): the sparse-pool model that learned the retrieval task.

For the decision-relevant query (token 0) in its retrieval head, on the first 200 test images:
  - the certificate at rho = 0.02 and the best witness found (explicit factor perturbation of that head, evaluated
    exactly in float64);
  - whether the model's prediction changes when that witness perturbation is applied to the head inside the full
    float32 forward pass (all other parameters nominal).
Output: explore/witness_retrieval.json
"""
import os
import sys
import json
import numpy as np
import jax
import jax.numpy as jnp
import p2lib as L
import p2cert as C
import p2_eval as E

RUN = sys.argv[1] if len(sys.argv) > 1 else "explore_Pool_lr0.003_ep12_s0"
NIMG = 200
RHO = 0.02


def forward_override(params, xp, cfg, li, h, fac_override):
    """p2lib.forward with the effective query/key factors of (layer li, head h) replaced."""
    p, q, v = cfg["p"], cfg["q"], cfg["variant"]
    B, N, _ = xp.shape
    X = (xp @ params["emb_W"] + params["emb_b"]).reshape(B, N, p, q) + params["pos"][None]
    for l, blk in enumerate(params["blocks"]):
        Z = L.layer_norm(X, blk["ln1_g"], blk["ln1_b"])
        if l == li:
            facs = [jnp.array(f) for f in L.qk_factors(blk, v)]
            facs = [f.at[h].set(jnp.asarray(o, dtype=f.dtype)) for f, o in zip(facs, fac_override)]
            V = L.kron_map(blk["Bv"], Z, blk["Av"])
            Hh, rv, tv_ = V.shape[1], V.shape[3], V.shape[4]
            Vf = V.reshape(B, Hh, N, rv * tv_)
            Y = L.pos_tokens(Z)
            Qm = L.kron_map(facs[0], Y, facs[1]).reshape(B, Hh, N, -1)
            Km = L.kron_map(facs[2], Y, facs[3]).reshape(B, Hh, N, -1)
            s = jnp.matmul(Qm, jnp.swapaxes(Km, -1, -2))
            tau = L.tau_of(blk, v)[None, :, None, None]
            a = jax.nn.softmax(tau * jnp.log(s), axis=-1)
            O = jnp.matmul(a, Vf).reshape(B, Hh, N, rv, tv_)
            T = jnp.einsum('bhnuw,hqw->bhnuq', O, blk["Ao"])
            upd = jnp.einsum('hpu,bhnuq->bnpq', blk["Bo"], T)
        else:
            upd = L.attention(blk, Z, v)
        X = X + upd
        Z2 = L.layer_norm(X, blk["ln2_g"], blk["ln2_b"]).reshape(B, N, p * q)
        X = X + (jax.nn.gelu(Z2 @ blk["W1"] + blk["b1"]) @ blk["W2"] + blk["b2"]).reshape(B, N, p, q)
    Zn = L.layer_norm(X, params["head_g"], params["head_b"])
    Zh = (Zn[:, 0] if cfg.get("readout", "mean") == "first" else Zn.mean(axis=1)).reshape(B, p * q)
    return Zh @ params["out_W"] + params["out_b"]


def main():
    params, cfg, meta = L.load_params(os.path.join("runs", "retrieval", RUN))
    data = L.load_task("retrieval", with_test=True)
    X, y, pos = data["Xte"][:NIMG], data["yte"][:NIMG], data["poste"][:NIMG]
    v = cfg["variant"]
    # the retrieval head: the (layer, head) with the largest learned tau
    taus = [(float(np.exp(np.asarray(b["log_tau"]))[h]), li, h) for li, b in enumerate(params["blocks"])
            for h in range(cfg["heads"])]
    tau, li, h = max(taus)
    blk = params["blocks"][li]
    fac = E.factors64(blk, v, h)
    xp = jnp.asarray(L.patchify(X, cfg["patch"]))
    logits0, attns, toks = L.forward(params, xp, cfg, return_attn=True)
    pred0 = np.asarray(jnp.argmax(logits0, axis=1))
    Y = np.exp(np.clip(np.asarray(toks[li], dtype=np.float64), -30, 30))
    rows = []
    for n in range(NIMG):
        G, s = C.factor_masses(*fac, Y[n][:1], Y[n])
        a = C.attn_from_scores(s, tau)
        cert = float(C.certificates_batch(G, a, tau, RHO)["cert"][0])
        wit, d = C.tv_witness(fac, Y[n][0], Y[n], tau, RHO, G[0], a[0], starts=6, iters=12)
        pert = C.perturb(fac, C.split_d(d, [f.shape for f in fac]))
        lg = forward_override(params, xp[n:n + 1], cfg, li, h, [np.asarray(f, dtype=np.float32) for f in pert])
        pred1 = int(np.asarray(jnp.argmax(lg, axis=1))[0])
        top0 = int(np.argmax(a[0]))
        _, _, s1 = C.scores(*pert, Y[n][:1], Y[n])
        a1 = C.attn_from_scores(s1, tau)[0]
        rows.append({"cert": cert, "witness": wit, "match_mass": float(a[0, pos[n]]),
                     "match_mass_witness": float(a1[pos[n]]), "top_is_match": top0 == int(pos[n]),
                     "pred0": int(pred0[n]), "pred1": pred1, "label": int(y[n])})
    W = np.array([r["witness"] for r in rows])
    Cc = np.array([r["cert"] for r in rows])
    flips = np.array([r["pred0"] != r["pred1"] for r in rows])
    correct0 = np.array([r["pred0"] == r["label"] for r in rows])
    out = {"run": RUN, "layer": li, "head": h, "tau": tau, "n_images": NIMG, "rho": RHO,
           "cert_median": float(np.median(Cc)), "certified_frac": float((Cc <= 0.1).mean()),
           "witness_median": float(np.median(W)), "witness_max": float(W.max()),
           "witness_gt_0.1_frac": float((W > 0.1).mean()), "violations": int((W > Cc + 1e-12).sum()),
           "match_mass_median": float(np.median([r["match_mass"] for r in rows])),
           "match_mass_witness_median": float(np.median([r["match_mass_witness"] for r in rows])),
           "prediction_flip_frac": float(flips.mean()), "acc_nominal": float(correct0.mean()),
           "acc_under_witness": float(np.mean([r["pred1"] == r["label"] for r in rows]))}
    os.makedirs("explore", exist_ok=True)
    json.dump({"summary": out, "rows": rows}, open(os.path.join("explore", f"witness_{RUN}.json"), "w"), indent=1)
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
