"""JAX (float64) version of the per-query certificate summaries, for speed.  Mirrors p2cert.factor_masses_images
and p2cert.query_summaries; checked against them in verify_p2_eval_consistency()."""
import jax
import jax.numpy as jnp

jax.config.update("jax_enable_x64", True)


@jax.jit
def summaries(Bq, Aq, Bk, Ak, Y, tau):
    """Y (n, N, p, q) float64 positive tokens -> per-query arrays (n, N): w_max, w_mean, w_rms, D_tri,
    log-score spread, effective key count; and attention a (n, N, N)."""
    Q = jnp.einsum('up,inpq,vq->inuv', Bq, Y, Aq)
    K = jnp.einsum('up,inpq,vq->inuv', Bk, Y, Ak)
    s = jnp.einsum('iauv,ibuv->iab', Q, K)
    ls = jnp.log(s)
    z = tau * ls
    a = jax.nn.softmax(z, axis=-1)
    AqYT = jnp.einsum('vq,inpq->invp', Aq, Y)
    BqY = jnp.einsum('up,inpq->inuq', Bq, Y)
    AkYT = jnp.einsum('vq,inpq->invp', Ak, Y)
    BkY = jnp.einsum('up,inpq->inuq', Bk, Y)
    n, N = s.shape[0], s.shape[1]
    mBq = jnp.einsum('ibuv,iavp->iabup', K, AqYT) * Bq
    mAq = jnp.einsum('ibuv,iauq->iabvq', K, BqY) * Aq
    mBk = jnp.einsum('iauv,ibvp->iabup', Q, AkYT) * Bk
    mAk = jnp.einsum('iauv,ibuq->iabvq', Q, BkY) * Ak
    G = jnp.concatenate([mBq.reshape(n, N, N, -1), mAq.reshape(n, N, N, -1), mBk.reshape(n, N, N, -1),
                         mAk.reshape(n, N, N, -1)], axis=3) / s[..., None]
    gbar = jnp.einsum('iab,iabp->iap', a, G)
    w = jnp.abs(G - gbar[:, :, None, :]).sum(axis=3)                  # (n, N, N)
    rng = (G.max(axis=2) - G.min(axis=2)).sum(axis=2)                  # (n, N)
    out = {"w_max": w.max(axis=2), "w_mean": (a * w).sum(axis=2), "w_rms": jnp.sqrt((a * w * w).sum(axis=2)),
           "D_tri": jnp.minimum(2.0 * w.max(axis=2), rng), "spread": ls.std(axis=2),
           "eff": jnp.exp(-(a * jnp.log(jnp.maximum(a, 1e-300))).sum(axis=2))}
    return out, a


@jax.jit
def diameters(Bq, Aq, Bk, Ak, Y):
    """Exact L1 diameters D (n, N) of the factor-mass vectors of every query, with the maximising pair."""
    Q = jnp.einsum('up,inpq,vq->inuv', Bq, Y, Aq)
    K = jnp.einsum('up,inpq,vq->inuv', Bk, Y, Ak)
    s = jnp.einsum('iauv,ibuv->iab', Q, K)
    AqYT = jnp.einsum('vq,inpq->invp', Aq, Y)
    BqY = jnp.einsum('up,inpq->inuq', Bq, Y)
    AkYT = jnp.einsum('vq,inpq->invp', Ak, Y)
    BkY = jnp.einsum('up,inpq->inuq', Bk, Y)
    n, N = s.shape[0], s.shape[1]
    mBq = jnp.einsum('ibuv,iavp->iabup', K, AqYT) * Bq
    mAq = jnp.einsum('ibuv,iauq->iabvq', K, BqY) * Aq
    mBk = jnp.einsum('iauv,ibvp->iabup', Q, AkYT) * Bk
    mAk = jnp.einsum('iauv,ibuq->iabvq', Q, BkY) * Ak
    G = jnp.concatenate([mBq.reshape(n, N, N, -1), mAq.reshape(n, N, N, -1), mBk.reshape(n, N, N, -1),
                         mAk.reshape(n, N, N, -1)], axis=3) / s[..., None]

    def one(Gq):                                                       # Gq (N, P)
        dist = jnp.abs(Gq[:, None, :] - Gq[None, :, :]).sum(axis=2)
        k = jnp.argmax(dist)
        return dist.reshape(-1)[k], k
    D, k = jax.vmap(jax.vmap(one))(G)
    return D, k // N, k % N
