"""Exploratory: witnesses for signed scoring under the same sign-preserving factor box (Section 7.4).

For S and Sp (seed 0) on LRA-Image and the retrieval task: on the first 100 test images, 16 evenly spaced query
positions per image, every head: search vertices d in {-rho, rho}^P (each factor entry multiplied by e^d, sign kept)
by sign iteration on the first-order TV objective sum_j a_j |(g_j - gbar).d|, where g_j is the gradient of the
logit s_ij / sqrt(rt) with respect to d; evaluate the attention exactly at the best vertices; report the TV.
Output: explore/signed_witness.json
"""
import os
import json
import numpy as np
import jax.numpy as jnp
import p2lib as L
import p2cert as C
import p2_eval as E

RHO = 0.02
NIMG = 100
NQ = 16


def grads(fac, Yq, Yk):
    """Gradient of s_ij with respect to the log-perturbation of every factor entry (signed factors): (M, N, P)."""
    Bq, Aq, Bk, Ak = fac
    Q, K, s = C.scores(Bq, Aq, Bk, Ak, Yq, Yk)
    AqYT = np.einsum('vq,mpq->mvp', Aq, Yq)
    BqY = np.einsum('up,mpq->muq', Bq, Yq)
    AkYT = np.einsum('vq,npq->nvp', Ak, Yk)
    BkY = np.einsum('up,npq->nuq', Bk, Yk)
    gBq = Bq[None, None] * np.einsum('nuv,mvp->mnup', K, AqYT)
    gAq = Aq[None, None] * np.einsum('nuv,muq->mnvq', K, BqY)
    gBk = Bk[None, None] * np.einsum('muv,nvp->mnup', Q, AkYT)
    gAk = Ak[None, None] * np.einsum('muv,nuq->mnvq', Q, BkY)
    M, N = s.shape
    g = np.concatenate([x.reshape(M, N, -1) for x in (gBq, gAq, gBk, gAk)], axis=2)
    return g, s


def softmax(z):
    z = z - z.max(axis=-1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=-1, keepdims=True)


def witness(fac, Yi, Yk, a, g, rt, starts=4, iters=8):
    gbar = a @ g
    V = (g - gbar[None, :]) / np.sqrt(rt)
    order = np.argsort(-(a * np.abs(V).sum(axis=1)))
    sh = [f.shape for f in fac]
    best = 0.0
    for s0 in range(min(starts, len(order))):
        d = RHO * np.sign(V[order[s0]] + 1e-300)
        for _ in range(iters):
            sig = np.sign(V @ d + 1e-300)
            dn = RHO * np.sign((a * sig) @ V + 1e-300)
            if np.array_equal(dn, d):
                break
            d = dn
        _, _, s1 = C.scores(*C.perturb(fac, C.split_d(d, sh)), Yi[None], Yk)
        best = max(best, float(C.tv(softmax(s1[0] / np.sqrt(rt)), a)))
    return best


def run(task, variant, seed=0):
    params, cfg, meta = L.load_params(os.path.join("runs", task, f"{variant}_s{seed}"))
    data = L.load_task(task, with_test=True)
    X = data["Xte"][:NIMG]
    xp = jnp.asarray(L.patchify(X, cfg["patch"]))
    _, attns, toks = L.forward(params, xp, cfg, return_attn=True)
    rt = cfg["r"] * cfg["t"]
    qsel = np.linspace(0, 63, NQ).round().astype(int)
    out = {}
    for li, blk in enumerate(params["blocks"]):
        Z = np.asarray(toks[li], dtype=np.float64)
        Y = Z if variant == "S" else np.exp(np.clip(Z, -30, 30))
        for h in range(cfg["heads"]):
            fac = E.factors64(blk, variant, h)
            W = []
            for n in range(NIMG):
                g, s = grads(fac, Y[n][qsel], Y[n])
                a = softmax(s / np.sqrt(rt))
                for m, i in enumerate(qsel):
                    W.append(witness(fac, Y[n][i], Y[n], a[m], g[m], rt))
            W = np.array(W)
            out[f"L{li}H{h}"] = {"median": float(np.median(W)), "max": float(W.max()),
                                 "frac_gt_0.1": float((W > 0.1).mean())}
            print(task, variant, li, h, out[f"L{li}H{h}"], flush=True)
    return out


def main():
    res = {}
    for task in ("image", "retrieval"):
        for v in ("S", "Sp"):
            res[f"{task}_{v}_s0"] = run(task, v)
    os.makedirs("explore", exist_ok=True)
    json.dump(res, open(os.path.join("explore", "signed_witness.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
