"""Measured latency of the attention block (exploratory detail of a registered measurement).

JAX on one CPU thread, float32, the trained shapes (p = q = 8, r = t = 4, r_v = t_v = 4, H = 2), batch 32,
N in {64, 256, 1024} tokens.  Times the attention update only (projections, scoring, normalisation, weighted sum,
output map), the median of 30 timed calls after warm-up.  Also times the certificate summaries per image.
Output: report/latency.json
"""
import os
import json
import time
import numpy as np

os.environ.setdefault("XLA_FLAGS", "--xla_cpu_multi_thread_eigen=false intra_op_parallelism_threads=1")
import jax  # noqa: E402
import jax.numpy as jnp  # noqa: E402
import p2lib as L  # noqa: E402


def time_fn(f, *args, reps=30):
    out = f(*args)
    jax.block_until_ready(out)
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        out = f(*args)
        jax.block_until_ready(out)
        ts.append(time.perf_counter() - t0)
    return float(np.median(ts))


def main():
    res = {"batch": 32, "shapes": dict(p=8, q=8, r=4, t=4, rv=4, tv=4, heads=2), "ms": {}}
    for N in (64, 256, 1024):
        B = 32 if N <= 256 else 8
        Z = jax.random.normal(jax.random.PRNGKey(1), (B, N, 8, 8), dtype=jnp.float32)
        row = {}
        for v in L.VARIANTS:
            cfg = L.default_cfg(variant=v, p=8, q=8, r=4, t=4, rv=4, tv=4, heads=2, layers=1, mlp=128)
            blk = L.init_params(cfg, jax.random.PRNGKey(0))["blocks"][0]
            f = jax.jit(lambda b, z, v=v: L.attention(b, z, v))
            row[v] = 1000.0 * time_fn(f, blk, Z) / B
        res["ms"][str(N)] = row
        print(f"N = {N:5d}  ms per image: " + "  ".join(f"{k} {x:.3f}" for k, x in row.items()), flush=True)
    os.makedirs("report", exist_ok=True)
    json.dump(res, open(os.path.join("report", "latency.json"), "w"), indent=1)


def cert_cost():
    """Cost of the float64 certificate summaries per image (one head, N = 64, P = 128)."""
    import p2cert_jax as CJ
    rng = np.random.default_rng(0)
    fac = [jnp.asarray(np.exp(rng.normal(-2, 0.5, sh))) for sh in [(4, 8), (4, 8), (4, 8), (4, 8)]]
    Y = jnp.asarray(np.exp(rng.normal(0, 1, (25, 64, 8, 8))))
    f = lambda Y: CJ.summaries(*fac, Y, 2.0)[0]["w_max"]  # noqa: E731
    return 1000.0 * time_fn(f, Y, reps=10) / 25


def forward_cost():
    """float32 forward pass of the whole trained-shape model (Pool variant), per image, batch 32."""
    import p2_run as R
    cfg = L.default_cfg(n_classes=10, **R.ARCH)
    cfg.update(variant="Pool")
    params = L.init_params(cfg, jax.random.PRNGKey(0))
    xp = jnp.asarray(np.random.default_rng(0).random((32, 64, 16), dtype=np.float32))
    f = jax.jit(lambda p, x: L.forward(p, x, cfg))
    return 1000.0 * time_fn(f, params, xp) / 32


if __name__ == "__main__":
    main()
    res = json.load(open(os.path.join("report", "latency.json")))
    res["cert_ms_per_image_per_head"] = cert_cost()
    res["model_forward_ms_per_image_pool"] = forward_cost()
    json.dump(res, open(os.path.join("report", "latency.json"), "w"), indent=1)
    print(f"certificate summaries {res['cert_ms_per_image_per_head']:.3f} ms per image and head; "
          f"forward pass {res['model_forward_ms_per_image_pool']:.3f} ms per image; "
          f"ratio for four heads {4 * res['cert_ms_per_image_per_head'] / res['model_forward_ms_per_image_pool']:.1f}")
