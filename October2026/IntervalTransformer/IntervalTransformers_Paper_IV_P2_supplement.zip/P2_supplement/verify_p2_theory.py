"""Numerical checks of the P2 propositions (positive Kronecker attention under a factor log box).

T1  score identity, rank, tying and a positive non-PSD cross-matrix
T2  score log radius 4 rho at the corner; Eq. 11; the corner leaves attention unchanged
T3  TV <= tanh(Omega/4), attained by a two-group split; box maximum by enumeration
T4  relative-variation sandwich: rho||G_j-G_k||_1 -/+ 8 rho^2 brackets the exact pairwise supremum
T5  soundness and size of the certificates (Omega sandwich, Bennett-Pinsker) against exact search
T6  token gain: spread without sensitivity
T7  tau = 1 reassociation (linear attention) is exact
T8  disjoint pools attain the worst case
T9  query-side masses are garblings of the bin-mass distribution
Seed 20261011.  float64 throughout.
"""
import itertools
import numpy as np
from p2cert import (scores, factor_masses, perturb, split_d, attn_from_scores, tv, eq11, psi,
                    certificates, tv_witness, omega_witness, tv_box_bruteforce, l1_diameter_exact)

RNG = np.random.default_rng(20261011)
LINE = "=" * 78
FAILS = []


def header(t):
    print("\n" + LINE + "\n" + t + "\n" + LINE)


def check(name, ok):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}")
    if not ok:
        FAILS.append(name)


def rand_pos(shape, s=0.5):
    return np.exp(RNG.normal(0.0, s, shape))


def rand_instance(p, q, r, t, N, tok_sigma=0.7, fac_sigma=0.5):
    fac = [rand_pos((r, p), fac_sigma), rand_pos((t, q), fac_sigma), rand_pos((r, p), fac_sigma),
           rand_pos((t, q), fac_sigma)]
    X = rand_pos((N, p, q), tok_sigma)
    return fac, X


def one_factor_step(fac, idx, d, Xq, Xk, j, k, rho):
    """Exact maximisation of R_jk over one factor's log perturbation, others fixed (linear-fractional)."""
    sh = [f.shape for f in fac]
    parts = split_d(d, sh)
    pert = perturb(fac, parts)
    base = pert[idx] / np.exp(parts[idx])          # nominal values of the factor being optimised

    # s_ij and s_ik are linear in this factor's entries: s = sum_l w_l z_l
    def lin_weights(col):
        eps = np.zeros(base.size)
        w = np.zeros(base.size)
        for l in range(base.size):
            z = np.zeros(base.size)
            z[l] = 1.0
            f2 = list(pert)
            f2[idx] = z.reshape(base.shape)
            _, _, s = scores(*f2, Xq[None], Xk)
            w[l] = s[0, col]
        return w
    wj, wk = lin_weights(j), lin_weights(k)
    lo, hi = base.ravel() * np.exp(-rho), base.ravel() * np.exp(rho)
    # maximise (wj.z)/(wk.z) over the box: Dinkelbach / threshold on wj/wk
    lam = (wj @ base.ravel()) / (wk @ base.ravel())
    for _ in range(100):
        z = np.where(wj - lam * wk > 0, hi, lo)
        new = (wj @ z) / (wk @ z)
        if abs(new - lam) < 1e-15:
            break
        lam = new
    dnew = np.log(z / base.ravel())
    out = list(parts)
    out[idx] = dnew.reshape(base.shape)
    return np.concatenate([o.ravel() for o in out])


def R_jk(fac, d, Xq, Xk, j, k):
    sh = [f.shape for f in fac]
    _, _, s0 = scores(*fac, Xq[None], Xk)
    _, _, s1 = scores(*perturb(fac, split_d(d, sh)), Xq[None], Xk)
    return float(np.log(s1[0, j] / s0[0, j]) - np.log(s1[0, k] / s0[0, k]))


# ---------------------------------------------------------------------------
def t1_identity():
    header("T1 Score identity, rank and tying")
    p, q, r, t, N = 6, 5, 3, 4, 7
    fac, X = rand_instance(p, q, r, t, N)
    Bq, Aq, Bk, Ak = fac
    _, _, s = scores(Bq, Aq, Bk, Ak, X, X)
    M = np.kron(Aq.T @ Ak, Bq.T @ Bk)
    V = np.stack([x.ravel(order='F') for x in X])
    err = np.abs(V @ M @ V.T - s).max() / np.abs(s).max()
    print(f"  max relative error of vec(X_i)^T [(A_q^T A_k) kron (B_q^T B_k)] vec(X_j): {err:.1e}")
    check("identity (Eq. 10) to 1e-13", err < 1e-13)
    rk = np.linalg.matrix_rank(M)
    print(f"  rank M = {rk} for r t = {r * t} (M is {p * q} x {p * q})")
    check("rank M <= r t", rk <= r * t)
    Mt = np.kron(Aq.T @ Aq, Bq.T @ Bq)
    ev = np.linalg.eigvalsh(0.5 * (Mt + Mt.T))
    check("tied factors give a symmetric PSD Gram matrix", np.allclose(Mt, Mt.T) and ev.min() > -1e-10)
    eps = 0.1
    Bq2 = np.array([[1.0, eps], [eps, 1.0]])
    C = np.array([[0.2, 1.01], [1.01, 0.2]])
    Bk2 = np.linalg.solve(Bq2.T, C)
    A1 = np.ones((1, 1))
    M2 = np.kron(A1.T @ A1, Bq2.T @ Bk2)
    ev2 = np.linalg.eigvalsh(M2)
    print(f"  positive factors B_q = [[1,.1],[.1,1]], B_k min entry {Bk2.min():.4f}; "
          f"cross-matrix eigenvalues {ev2.round(4)}")
    check("positive, symmetric, not PSD (eigenvalues -0.81 and 1.21)",
          Bk2.min() > 0 and np.allclose(M2, M2.T) and np.allclose(sorted(ev2), [-0.81, 1.21]))


def t2_corner():
    header("T2 Score radius 4 rho, Eq. 11, and the common-gain corner")
    p, q, r, t, N, rho, tau = 5, 4, 3, 3, 9, 0.02, 4.0
    fac, X = rand_instance(p, q, r, t, N)
    _, _, s0 = scores(*fac, X, X)
    _, _, su = scores(*[f * np.exp(rho) for f in fac], X, X)
    lr = np.log(su / s0)
    print(f"  all-up corner: log(s_up/s_0) / rho in [{lr.min() / rho:.12f}, {lr.max() / rho:.12f}]")
    check("score log radius is exactly 4 rho at the corner", np.allclose(lr, 4 * rho, atol=1e-13))
    a0 = attn_from_scores(s0, tau)
    au = attn_from_scores(su, tau)
    print(f"  TV at the all-up corner: {tv(au, a0).max():.1e}")
    check("the corner that attains every score bound leaves attention unchanged", tv(au, a0).max() < 1e-14)
    worst_r, worst_tv = 0.0, 0.0
    for _ in range(2000):
        d = [RNG.uniform(-rho, rho, f.shape) for f in fac]
        _, _, s = scores(*perturb(fac, d), X, X)
        worst_r = max(worst_r, np.abs(np.log(s / s0)).max())
        worst_tv = max(worst_tv, tv(attn_from_scores(s, tau), a0).max())
    print(f"  2000 random interior points: max |log s/s_0| = {worst_r / rho:.4f} rho, "
          f"max TV = {worst_tv:.5f}, Eq. 11 bound = {eq11(tau, rho):.5f}")
    check("random points respect 4 rho and Eq. 11", worst_r <= 4 * rho + 1e-12 and worst_tv <= eq11(tau, rho))


def t3_spread():
    header("T3 TV <= tanh(Omega/4); attainment; box maximum by enumeration")
    for Om in (0.1, 0.4013, 1.0, 3.0):
        m = 1.0 / (1.0 + np.exp(Om / 2))
        p = np.array([m, 1 - m])
        pn = p * np.exp([Om, 0.0])
        pn /= pn.sum()
        print(f"  Omega = {Om:6.4f}: two-group TV = {tv(pn, p):.12f}, tanh(Omega/4) = {np.tanh(Om / 4):.12f}")
        check(f"attained at Omega = {Om}", abs(tv(pn, p) - np.tanh(Om / 4)) < 1e-12)
    worst = 0.0
    for _ in range(300):
        N = RNG.integers(2, 9)
        p = RNG.dirichlet(np.ones(N) * RNG.choice([0.3, 1.0, 3.0]))
        lo = -RNG.uniform(0, 0.5, N)
        hi = RNG.uniform(0, 0.5, N)
        best = tv_box_bruteforce(p, lo, hi)
        Om = hi.max() - lo.min()
        worst = max(worst, best / np.tanh(Om / 4))
    print(f"  300 random boxes (N <= 8): max of exact box TV / tanh(spread/4) = {worst:.6f}")
    check("box maximum never exceeds tanh(spread/4)", worst <= 1 + 1e-12)


def t4_sandwich():
    header("T4 Relative-variation sandwich")
    # (a) Taylor bounds on every score: 0 <= log s(d) - log s(0) - G.d <= 8 rho^2
    p, q, r, t, N = 4, 3, 3, 2, 6
    viol, gap_max = 0, 0.0
    for rho in (0.02, 0.1, 0.3):
        fac, X = rand_instance(p, q, r, t, N)
        G, s0 = factor_masses(*fac, X, X)
        sh = [f.shape for f in fac]
        P = G.shape[2]
        for _ in range(400):
            if RNG.random() < 0.5:
                d = RNG.uniform(-rho, rho, P)
            else:
                d = rho * RNG.choice([-1.0, 1.0], P)
            _, _, s = scores(*perturb(fac, split_d(d, sh)), X, X)
            rem = np.log(s / s0) - G @ d
            viol += int((rem < -1e-12).sum() + (rem > 8 * rho * rho + 1e-12).sum())
            gap_max = max(gap_max, rem.max() / (8 * rho * rho))
    print(f"  remainder log s(d) - log s(0) - G.d: violations of [0, 8 rho^2] = {viol}; "
          f"largest remainder = {gap_max:.3f} x 8 rho^2")
    check("Taylor sandwich holds for every score (rho = 0.02, 0.1, 0.3)", viol == 0)
    sums = G.reshape(G.shape[0], G.shape[1], -1)
    blocks = np.cumsum([0] + [int(np.prod(f.shape)) for f in fac])
    bs = [G[:, :, blocks[b]:blocks[b + 1]].sum(axis=2) for b in range(4)]
    check("each factor block of G is a probability distribution", all(np.allclose(b, 1) for b in bs))

    # (b) exact pairwise supremum by vertex enumeration (P = 16) against the sandwich
    p, q, r, t, N = 2, 2, 2, 2, 4
    rows = []
    for rho in (0.02, 0.1, 0.3):
        for rep in range(3):
            fac, X = rand_instance(p, q, r, t, N, tok_sigma=1.0, fac_sigma=1.0)
            G, s0 = factor_masses(*fac, X, X)
            sh = [f.shape for f in fac]
            P = G.shape[2]
            verts = np.array(list(itertools.product([-1.0, 1.0], repeat=P))) * rho
            i = 0
            Ls = []
            for vchunk in np.array_split(verts, 16):
                for d in vchunk:
                    _, _, s = scores(*perturb(fac, split_d(d, sh)), X[i:i + 1], X)
                    Ls.append(np.log(s[0] / s0[i]))
            Ls = np.array(Ls)                      # (2^P, N)
            for j in range(N):
                for k in range(N):
                    if j == k:
                        continue
                    sup = (Ls[:, j] - Ls[:, k]).max()
                    lin = rho * np.abs(G[i, j] - G[i, k]).sum()
                    rows.append((rho, sup, lin, sup - lin))
    rows = np.array(rows)
    for rho in (0.02, 0.1, 0.3):
        sel = rows[rows[:, 0] == rho]
        dev = sel[:, 3] / (8 * rho * rho)
        print(f"  rho = {rho}: {len(sel)} pairs, (exact sup - rho||G_j-G_k||_1) / 8rho^2 in "
              f"[{dev.min():+.3f}, {dev.max():+.3f}]")
    check("exact pairwise supremum lies within rho||G_j-G_k||_1 -/+ 8 rho^2",
          np.all(np.abs(rows[:, 3]) <= 8 * rows[:, 0] ** 2 + 1e-12))

    # (c) larger instances: block-coordinate ascent (exact one-factor steps) never beats the upper bound,
    #     and the sign vertex reaches the lower bound
    p, q, r, t, N, rho = 4, 4, 3, 3, 6, 0.1
    worst_up, worst_lo = -1e9, 1e9
    for rep in range(6):
        fac, X = rand_instance(p, q, r, t, N)
        G, _ = factor_masses(*fac, X, X)
        i, j, k = 0, 1 + rep % (N - 1), 1 + (rep + 2) % (N - 1)
        if j == k:
            k = (k % (N - 1)) + 1
        g = G[i, j] - G[i, k]
        lin = rho * np.abs(g).sum()
        d = rho * np.sign(g + 1e-300)
        at_sign = R_jk(fac, d, X[i], X, j, k)
        best = at_sign
        for start in range(3):
            d = d if start == 0 else rho * RNG.choice([-1.0, 1.0], G.shape[2])
            for sweep in range(4):
                for idx in range(4):
                    d = one_factor_step(fac, idx, d, X[i], X, j, k, rho)
            best = max(best, R_jk(fac, d, X[i], X, j, k))
        worst_up = max(worst_up, (best - lin) / (8 * rho * rho))
        worst_lo = min(worst_lo, (at_sign - lin) / (8 * rho * rho))
    print(f"  4x4 tokens, rho = 0.1: best found - linear term = {worst_up:+.3f} x 8rho^2 (must be <= 1); "
          f"sign vertex - linear term >= {worst_lo:+.3f} x 8rho^2 (must be >= -1)")
    check("coordinate ascent stays below the upper bound; sign vertex above the lower bound",
          worst_up <= 1 + 1e-9 and worst_lo >= -1 - 1e-9)


def t5_certificates():
    header("T5 Certificates against exact search (rho = 0.02 and 0.05)")
    p, q, r, t, N = 4, 4, 3, 3, 12
    stats = []
    for rho in (0.02, 0.05):
        for tau in (1.0, 4.0, 12.0):
            for rep in range(4):
                fac, X = rand_instance(p, q, r, t, N, tok_sigma=RNG.choice([0.3, 1.0]))
                G, s0 = factor_masses(*fac, X, X)
                a = attn_from_scores(s0, tau)
                for i in range(3):
                    c = certificates(G[i], a[i], tau, rho, exact_pairs=True)
                    wit, _ = tv_witness(fac, X[i], X, tau, rho, G[i], a[i])
                    rnd = 0.0
                    sh = [f.shape for f in fac]
                    for _ in range(200):
                        d = rho * RNG.choice([-1.0, 1.0], G.shape[2])
                        _, _, s = scores(*perturb(fac, split_d(d, sh)), X[i:i + 1], X)
                        rnd = max(rnd, tv(attn_from_scores(s, tau), a[i:i + 1])[0])
                    om_w = omega_witness(fac, X[i], X, tau, rho, G[i], *c['pair'])
                    stats.append((rho, tau, c['eq11'], c['c_omega'], c['c_kl'], c['c_l1'], c['cert'], wit, rnd,
                                  c['omega_lo'], om_w, c['omega_up']))
    S = np.array(stats)
    lower = np.maximum(S[:, 7], S[:, 8])
    each_sound = all(np.all(S[:, col] >= lower - 1e-15) for col in (2, 3, 4, 5))
    om_ok = np.all((S[:, 10] <= S[:, 11] + 1e-12) & (S[:, 10] >= S[:, 9] - 1e-12))
    print("  rho   tau   Eq.11    tanh(Om/4)  Bennett-Pinsker  L1 bound  witness  random-vertex max  (medians)")
    for rho in (0.02, 0.05):
        for tau in (1.0, 4.0, 12.0):
            sel = S[(S[:, 0] == rho) & (S[:, 1] == tau)]
            med = np.median(sel, axis=0)
            print(f"  {rho:.2f}  {tau:4.1f}  {med[2]:.5f}  {med[3]:.5f}     {med[4]:.5f}          "
                  f"{med[5]:.5f}   {med[7]:.5f}  {med[8]:.5f}")
    ratio = S[:, 7] / S[:, 6]
    print(f"  witness / best certificate: median {np.median(ratio):.3f}, min {ratio.min():.3f}, max {ratio.max():.3f}")
    print(f"  best certificate is the L1 bound in {np.mean(S[:, 6] == S[:, 5]):.0%} of cases, "
          f"Bennett-Pinsker in {np.mean(S[:, 6] == S[:, 4]):.0%}")
    check("each certificate >= every evaluated vertex (witness and 200 random vertices)", each_sound)
    check("Omega witness lies inside the sandwich [tau(rho D - 8rho^2), tau(rho D + 8rho^2)]", om_ok)


def t6_gain():
    header("T6 Token gain: spread without sensitivity")
    p, q, r, t, N, rho, tau = 4, 4, 3, 3, 6, 0.05, 6.0
    fac, X = rand_instance(p, q, r, t, N)
    X2 = X.copy()
    X2[3] = 7.0 * X[2]
    G, s0 = factor_masses(*fac, X2, X2)
    print(f"  key 3 = 7 x key 2: log s_i3 - log s_i2 = {np.log(s0[0, 3] / s0[0, 2]):.6f} (log 7 = {np.log(7):.6f}),"
          f" ||G_i3 - G_i2||_1 = {np.abs(G[0, 3] - G[0, 2]).sum():.1e}")
    sh = [f.shape for f in fac]
    mx = 0.0
    for _ in range(500):
        d = RNG.uniform(-rho, rho, G.shape[2])
        mx = max(mx, abs(R_jk(fac, d, X2[0], X2, 3, 2)))
    print(f"  max |R_32(d)| over 500 box points: {mx:.1e}")
    check("gain-related keys: constant log-score gap, zero relative variation", mx < 1e-13)


def t7_reassoc():
    header("T7 tau = 1: linear reassociation is exact")
    p, q, r, t, N = 5, 4, 3, 3, 40
    fac, X = rand_instance(p, q, r, t, N)
    Q, K, s = scores(*fac, X, X)
    V = RNG.normal(size=(N, 3, 3))
    a = s / s.sum(1, keepdims=True)
    out1 = np.einsum('ij,juv->iuv', a, V)
    KV = np.einsum('jab,juv->abuv', K, V)
    out2 = np.einsum('iab,abuv->iuv', Q, KV) / np.einsum('iab,ab->i', Q, K.sum(0))[:, None, None]
    err = np.abs(out1 - out2).max()
    print(f"  max |explicit - reassociated| = {err:.1e}; normaliser <Q_i, sum_j K_j> is one r x t inner product")
    check("reassociation exact", err < 1e-12)


def t8_disjoint():
    header("T8 Disjoint pools attain the worst case")
    p, q, r, t, rho, tau = 4, 4, 2, 2, 0.02, 4.0
    Bq = np.full((r, p), 1e-9)
    Bq[0, :2] = 1.0
    Bq[1, 2:] = 1.0
    Aq = np.full((t, q), 1e-9)
    Aq[0, :2] = 1.0
    Aq[1, 2:] = 1.0
    fac = [Bq, Aq, Bq.copy(), Aq.copy()]
    Xq = np.full((1, p, q), 1.0)
    Xk = np.full((2, p, q), 1e-9)
    Xk[0, :2, :2] = 1.0           # key 0 lives in pool (0, 0)
    Xk[1, 2:, 2:] = 1.0           # key 1 lives in pool (1, 1)
    G, s0 = factor_masses(*fac, Xq, Xk)
    D = np.abs(G[0, 0] - G[0, 1]).sum()
    d = rho * np.sign(G[0, 0] - G[0, 1])
    R = R_jk(fac, d, Xq[0], Xk, 0, 1)
    print(f"  ||G_0 - G_1||_1 = {D:.6f}; R at the sign vertex = {R / rho:.6f} rho")
    check("disjoint pools: D = 8 and R = 8 rho", abs(D - 8) < 1e-6 and abs(R - 8 * rho) < 1e-6 * rho)


def t9_garbling():
    header("T9 Query-side factor masses are garblings of the bin-mass distribution")
    p, q, r, t, N = 5, 4, 3, 3, 8
    fac, X = rand_instance(p, q, r, t, N)
    Q, K, s = scores(*fac, X, X)
    G, _ = factor_masses(*fac, X, X)
    nb = r * p
    worst = 0.0
    for i in range(N):
        pi = Q[i][None] * K / s[i][:, None, None]            # (N, r, t) bin masses
        for j in range(N):
            for k in range(N):
                lhs = np.abs(G[i, j, :nb] - G[i, k, :nb]).sum()
                rhs = np.abs(pi[j] - pi[k]).sum()
                worst = max(worst, lhs - rhs)
    print(f"  max over (i, j, k) of ||mu^Bq_j - mu^Bq_k||_1 - ||pi_j - pi_k||_1 = {worst:.1e} (must be <= 0)")
    check("data-processing inequality for the query factor B_q", worst <= 1e-12)


if __name__ == "__main__":
    t1_identity()
    t2_corner()
    t3_spread()
    t4_sandwich()
    t5_certificates()
    t6_gain()
    t7_reassoc()
    t8_disjoint()
    t9_garbling()
    print("\n" + LINE)
    print("ALL CHECKS PASSED" if not FAILS else f"FAILED: {FAILS}")
