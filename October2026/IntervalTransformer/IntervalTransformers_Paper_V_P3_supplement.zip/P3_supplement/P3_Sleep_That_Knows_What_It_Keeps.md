# Sleep That Knows What It Keeps: Consolidation and Certified Precision for a Positive Kronecker Memory

**Debi Prasad Ghosh**

Debias Parametric Guru, Kolkata, India | debiprasadghosh@gmail.com

5 October 2026 · P3 of the log interval network programme · Pre-specified protocol executed, with reproducible scripts

---

**Abstract.** The logarithmic long-term memory (LTM) design learns in a real-valued Kronecker adapter while awake. During sleep it consolidates the adapter into a log-stored Kronecker base, and it lets rarely used factors lose precision. Paper II found the published sleep rule ill-posed and proposed repairs. It then registered P3: repaired consolidation with an accounting of the residual, and a primary comparison of certificate-guided precision against uniform and usage-and-age precision at equal total bits. A retention claim would count only when certified, and the claim was to be rejected if certificate-guided precision showed no retention advantage.

We prove six propositions about one positive Kronecker layer and check each numerically.

- **The published rule.** It is undefined wherever the leading singular vectors of the change are not positive. Under its absolute-value surrogate no weight can ever rise, and a class whose adapter rows are zero is sent to zero. In class-incremental learning, in exact arithmetic, the first sleep therefore removes every class not yet seen.
- **The repaired rules.** They absorb exactly the separable gains. Their first-order versions are accurate only when the relative change is small.
- **Stored boxes.** For a stored log box with shared factors, the decision test is exact: class rows sit at corners and shared vectors at a threshold vertex. The box contains the reference parameters, and a residual bound that uses class norms alone is exact over the residuals with those norms.

We ran split MNIST (5 tasks) and split CIFAR-100 (10 tasks) under a protocol frozen before any test example was read: 5 seeds, 9 sleep rules, 2 ranks, 2 cadences and 4 precision policies, 270 runs in all.

- **The published rule** was undefined at 94.5% and 97.5% of base entries at the first sleep. Its surrogate never stored a class introduced after that sleep. That sleep had already cut the first task to 61% on its two MNIST classes and 11% on its ten CIFAR-100 classes. The agenda's prediction that it loses *earlier* tasks fastest (P3.1) is rejected.
- **The repaired rules** (Paper II's Eqs. 13 and 14) left 99% of each learned change as residual. They ended at 12–22% on MNIST, against 83.3% without sleep, and their first-order version diverged in every seed. P3.2, that repair retains at least as much as no sleep, is rejected by 61.6 ± 12.2 points.
- **A Frobenius refit** of the store matched no-sleep accuracy on both datasets. It kept 97.5% of decisions per sleep on MNIST but only 62.8% on CIFAR-100, and none of this retention could be certified at one sleep per task. Only storing the residual densely, at 7–8 times the store's bits, certified it.
- **Precision (primary).** At 8 bits per log-weight, certificate-guided precision certified 82.9% of final MNIST decisions, against 81.0% for uniform and 80.3% for usage-and-age precision. The seed-paired differences were +1.9 ± 0.7 and +2.6 ± 1.4 points. On CIFAR-100 the figures were 67.8% against 27.4% and 45.4% (+40.4 ± 18.6 and +22.4 ± 9.0). Paper II's criterion is met at equal total bits on both stages. The measured cost, 1–24 s of extra computation per sleep, is reported, not equalized. On MNIST the advantage over uniform precision was significant only from the fourth sleep, and at 12 bits uniform precision was slightly ahead.
- **Bits per decision.** The bits at which a decision is lost followed its log margin with Spearman −0.52 to −0.65 on MNIST, so P3.3 (≤ −0.7) is rejected. In an exploratory analysis, certificates asked for a median of 4–5 bits more than the width from which the decisions were actually kept.

Storage can know what it keeps. At one sleep per task, none of the sleeps we tested both consolidated a learned change and proved that it had kept it. At a 10-step cadence (exploratory), the tangent projection's non-empty task-ending sleeps were mostly certified on MNIST (87% of decisions on average), but not on CIFAR-100 (6%).

**Keywords** continual learning; sleep consolidation; logarithmic number system; Kronecker factorization; mixed-precision storage; weight-perturbation certificates; class-incremental learning

# 1 Introduction

Paper II [2] extended the exact ranges of the Interval Transformer [1] into log interval networks. In these networks positive quantities live in a logarithmic number system (LNS) and carry log intervals, so a decision can be checked against a box of tolerated parameters. P1 [3] tested this on readouts and evidence accumulation, and P2 [4] on attention. This paper, P3, tests it on memory.

**The question.** The LTM design [5] has a fast and a slow memory.

- **Fast memory.** It learns in real-valued Kronecker adapters.
- **Slow memory.** It keeps a Kronecker-factored base in an LNS, where a multiplicative update is an addition.
- **Sleep.** It moves what the adapter learned into the base.
- **Forgetting.** It lowers the precision of factors that are rarely used.

Paper II asked what such a memory can know about what it keeps. It found three problems with the published design.

- **Sleep.** The rule fits an additive change but applies it multiplicatively. It is undefined at many base entries, and its absolute-value surrogate shrinks the base.
- **The residual.** Whatever the consolidation does not absorb is lost when the adapter is deleted.
- **Precision.** Usage-and-age decay knows nothing about which decisions a factor carries.

It therefore proposed repaired rules (its Eqs. 13–15) and required that the residual be stored or bounded. It also proposed allocating bits by decision certificates, and registered P3 with a falsifiable criterion: "No retention advantage over uniform or usage-and-age precision at equal total bits and measured cost" rejects the precision claim.

**Contributions.**

1. **Theory (Section 3).** Six propositions about a positive Kronecker sum, each checked numerically. The 28 frozen checks (T1–T10) are supplemented by checks and measurements added after review (A0–A9).
   - *The published rule (Proposition 1).* It ignores the size of the change and is undefined at a fraction $1-f_1f_2$ of base entries. Under the $|C|$ surrogate it lowers the mean log-weight by at least $\tfrac{\alpha}{2}\log(n_1n_2)$ per sleep and never raises any weight. It sends to zero every class whose adapter rows are zero. In class-incremental learning those are the classes not yet seen, as long as the adapter starts at zero and their logits are masked.
   - *The repairs (Propositions 2 and 3).* They absorb exactly the separable gains $W\circ\exp(g_1\oplus g_2)$, of any size. The first-order weighted fit is the Frobenius projection onto that $(n_1+n_2-1)$-dimensional space, which for $R>1$ terms is a small part of the tangent space. A first-order rule applied multiplicatively errs by at least $x^2/2$ times the weight for a relative change $x\ge0$.
   - *Certificates (Propositions 4–6).* Under a stored log box with shared factors, the decision test is exact: class rows sit at corners and shared vectors at a threshold vertex. The stored box contains the reference parameters. A functional residual bound that uses only class norms is exact over the residuals with those norms.
2. **The registered experiment (Sections 4–6).** Split MNIST and split CIFAR-100, class-incremental, with five seeds. We ran:
   - the published rule and its surrogate;
   - Paper II's ordinary and weighted repairs, and the first-order weighted repair;
   - the no-sleep and residual-preserving controls that Paper II named;
   - two rules of ours, a tangent projection and a Frobenius refit.

   These ran at ranks 1 and 8 and at two sleep cadences. The precision study compared four policies at five budgets, at equal total bits including metadata and protected examples.
3. **The verdict (Section 7).**
   - *Precision.* The primary criterion is met on both stages at equal total bits, with the cost of the allocation reported. At the final sleep, certificate-guided precision certified more decisions than uniform and usage-and-age precision, by 2–3 points on MNIST and by 22–40 points on CIFAR-100, where decision margins were about seven times smaller.
   - *Consolidation.* No repaired sleep kept a learned adapter. The refit kept most decisions on MNIST but could not prove it, and only a densely stored residual could.
   - *Agenda predictions.* P3.1, P3.2 and P3.3 are rejected and P3.4 is supported.

**Related work.**

- **Continual learning.** Replay and its class-incremental evaluation [11, 12], regularisation [13], and the complementary-learning-systems view of fast and slow memory [14] that the LTM design adopts. Wołczyk et al. [8] constrain weights to intervals so that earlier tasks keep guarantees. Here the intervals come from storage, and the guarantee is on decisions.
- **Low-rank adapters.** LoRA [15] and Kronecker adapters [26] train a structured update on a frozen base. The LTM sleep folds such an update back into the base.
- **Mixed-precision quantization.** Bits can be allocated by sensitivity [16, 17]. Our allocation plans with the decision test of Proposition 4 instead of a curvature proxy, and it pays for its metadata. The planning test is exact for each protected example's 8 nearest competitors and a sound bound for the rest. The certification that follows is exact.
- **Weight-perturbation certificates.** These bound the effect of bounded weight changes [18]. For this positive Kronecker store the bound is exact (Proposition 4), which lets the certified fraction serve as an allocation objective.

# 2 Setting

**The design under test.** The logarithmic long-term memory (LTM) of [5] keeps two kinds of memory.

- **Long-term store.** Base weights are Kronecker products $W=W_1\otimes W_2$ whose factors are positive and stored as logarithms in a logarithmic number system (LNS). Few-bit log encodings keep accuracy in convolutional networks [6], and in the log domain a multiplicative update is an addition.
- **Short-term memory.** Wake learning trains real-valued Kronecker adapters $\Delta W$ on top of the base.
- **Sleep.** The adapter's cumulative effect is fitted by its nearest Kronecker product (Van Loan–Pitsianis [7]): the leading singular vectors of the rearranged $\Delta W$, normalised and reshaped into $(C_1,C_2)$. The factors are then added to the base logarithms, $\log W_i\mathrel{+}=\alpha\log C_i$ [5, §4.3].
- **Forgetting.** Rarely used factors lose precision ("precision-decay forgetting" [5, §4.4]).

**What Paper II found and registered.** Paper II [2, §6] made three observations about this design.

- **Two geometries.** The sleep fits an *additive* change and applies it *multiplicatively*. With normalised delta factors, the log update was undefined for 28.0% and 63.8% of base entries in two constructions. The absolute-value surrogate $|C|$ that makes it computable changes the rule, and at unit strength it left 1.5–1.9% of the base norm.
- **A repair.** It proposed a consistent log target $D=\log((W+\Delta W)\oslash W)$, fitted by block means (its Eq. 13) or by weighted block means (its Eq. 14). The first-order version of the weighted fit is the Frobenius projection onto the tangent space of $W_1\otimes W_2$ (its Eq. 15). The unexplained residual "must remain stored or be bounded before adapter deletion".
- **Precision as a box.** Rounding a log weight to a grid identifies an interval of radius half a step, so a stored store *is* a box of parameters. Bits can then be allocated by decision certificates, not by usage.

For P3 it registered the following.

- **Budget.** Factor bits are allocated under a total memory budget that includes endpoints, scales, signs, adapters, rank metadata and protected examples.
- **Primary comparison.** Certificate-guided precision against uniform precision and usage-and-age scheduling, at equal total bits and charged decision cost.
- **Controls.** No sleep, ordinary repaired sleep, weighted repaired sleep, and residual-preserving sleep. The undefined original rule is recorded as undefined, and any absolute-value surrogate is named separately.
- **Retention claims.** A claim is accepted only when a stored box contains the reference parameters, or a separate functional residual bound covers the change.
- **Data.** Split MNIST first, then split CIFAR-100, with explicit class-incremental evaluation.
- **Rejection.** A claimed benefit is rejected if it disappears at equal memory and measured cost (Table 5 of Paper II: "No retention advantage over uniform or usage-and-age precision at equal total bits and measured cost"). "Repair alone has no theorem guaranteeing performance at least as good as no sleep."

The research agenda [24] adds four secondary predictions (P3.1–P3.4, Section 4.5).

**Our instance.** We need a store small enough to certify exactly and to run many times, but one that learns a class-incremental stream. We therefore take one positive Kronecker layer on fixed features.

- **Features.** A fixed random convolution maps an image to a positive feature matrix $H\in\mathbb R_{\ge0}^{h\times P}$ ($h=32$ channels by $P$ positions).
- **Store.** A positive Kronecker sum with one class axis,
$$
W[c,p,j]=\sum_{r=1}^{R}A_r[c,p]\,b_r[j],\qquad z_c(H)=\sum_{p,j}W[c,p,j]\,H[j,p]>0,
$$
held as $\log A_r$ and $\log b_r$. The class-by-position factors $A_r$ give each class its own rows. The channel vectors $b_r$ are shared by all classes. At $R=1$ this is Paper II's $W_1\otimes W_2$.
- **Wake.** A rank-8 real Kronecker adapter $\Delta W=\sum_jU_j\otimes V_j$, trained with replay of a few protected examples. The working weight is floored at $\varphi W$ so that it stays positive.
- **Sleep.** A rule maps the store and the adapter to a new store. The adapter is then deleted.
- **Decisions.** Prediction is $\arg\max_cz_c$ over the classes seen so far.

The store's structure makes a log box on its factors exactly certifiable. Each class's own factors enter only that class's score, and each shared factor enters every score linearly, so the worst member of the box can be found exactly (Proposition 4). Positivity alone would not suffice: for a general positive polynomial the worst case is a harder optimization. Exact or sound ranges of this kind are what the programme relies on [2, 3].

# 3 What sleep and storage do to a positive Kronecker store

Throughout, $W=\sum_{r=1}^{R}A_r\otimes b_r$ with $A_r\in\mathbb R_{>0}^{C\times P}$ and $b_r\in\mathbb R_{>0}^{h}$, and $\mathcal M(W)\in\mathbb R^{CP\times h}$ is the rearrangement in which $A\otimes b$ becomes $\mathrm{vec}(A)\,b^{\top}$, so that $\mathcal M(W)=\sum_r\mathrm{vec}(A_r)b_r^{\top}$ is a nonnegative matrix of rank at most $R$. An index $i=(c,p)$ runs over the $n_1=CP$ rows and $j$ over the $n_2=h$ channels. The adapter is $\Delta W=\sum_jU_j\otimes V_j$, and the working weight is $W^{\mathrm{work}}=\max(W+\Delta W,\varphi W)$ with $\varphi=0.05$. Section 4.6 lists the numerical checks: the frozen T1–T10 and the post-review A0–A9. All the checks pass, and A6 and A9 are measurements.

## 3.1 The published rule

The published rule [5, §§4.2–4.3] takes the leading singular triplet $(u,\sigma,v)$ of $\mathcal M(\Delta W)$, with $\lVert u\rVert=\lVert v\rVert=1$, reshapes $C_1=u$ and $C_2=v$, and updates the base logarithms: $\log A_r\mathrel{+}=\alpha\log C_1$ and $\log b_r\mathrel{+}=\alpha\log C_2$. On a sum of terms we apply the same factors to every term, which multiplies the store entrywise: $W^{\mathrm{new}}_{ij}=W_{ij}\,C_{1,i}^{\alpha}C_{2,j}^{\alpha}$.

**Proposition 1 (the published rule).**

(a) *Scale.* $\Delta W$ and $s\Delta W$ give the same update for every $s\neq0$ (up to the sign convention). The update does not depend on how much was learned.

(b) *Domain.* The update is defined at entry $(i,j)$ only if $C_{1,i}>0$ and $C_{2,j}>0$ for a common choice of sign. If $f_1$ and $f_2$ are the fractions of positive entries of $\pm u$ and $\pm v$, the rule is undefined at a fraction $1-f_1f_2$ of base entries (better sign).

(c) *Shrinkage.* Under the surrogate $|C|$, the mean log-weight falls by at least $\tfrac{\alpha}{2}\log(n_1n_2)$ at every sleep, with equality only when $|C_1|$ and $|C_2|$ are flat.

(d) *Monotonicity.* Under the surrogate, no log-weight ever increases.

(e) *Unseen classes.* If $\Delta W\neq0$ and the adapter's rows for class $c$ are zero, then $C_{1}$ vanishes on all rows of $c$. The surrogate then sends every weight of class $c$ to zero, and since every later sleep multiplies the weights by finite factors, they stay zero.

*Proof.* (a) The singular vectors of $s\,\mathcal M$ are $\pm(u,v)$. (b) Count the entries $(i,j)$ with $C_{1,i}C_{2,j}$ built from positive factors. (c) For a unit vector $x\in\mathbb R^n$, Jensen's inequality gives $\frac1n\sum\log|x_i|=\frac12\cdot\frac1n\sum\log x_i^2\le\frac12\log\frac1n\sum x_i^2=-\frac12\log n$, with equality if and only if all $|x_i|$ are equal. Apply this to $C_1$ and $C_2$. (d) $|C_{1,i}|,|C_{2,j}|\le1$ because both are unit vectors. (e) $u=\mathcal M(\Delta W)\,v/\sigma$ with $\sigma>0$, so $u$ vanishes on the zero rows of $\mathcal M(\Delta W)$. The weights on those rows become $W_{ij}\cdot0^{\alpha}=0$, and later updates multiply them. $\square$

In class-incremental training with one masked head, the adapter rows of a class not yet seen stay exactly zero, provided the adapter starts at zero and the class's logit is excluded from the loss, since then no gradient reaches them. Our code adds $-10^{9}$ to excluded logits, so in floating point their probabilities, and with them the gradients, are exactly zero. By (e), in exact arithmetic the first sleep therefore removes every class not yet seen, at any $\alpha>0$.

Our implementation clamps $|C|$ at $10^{-30}$, so those rows are multiplied by $10^{-30\alpha}$ instead of zero. With the clamp, monotonicity (d) alone does not rule out a later recovery relative to classes that shrink faster. None occurred: no class introduced after the first sleep was ever correctly predicted by the stored model, at any sleep and in any seed (Section 5.1).

P3.1 expects the rule to lose earlier tasks fastest through shrinkage. Proposition 1(e) predicts a different failure: no class introduced after the first sleep can be stored.

## 3.2 The repaired rules

Paper II's repair fits the consistent log target $D=\log(W^{\mathrm{work}}\oslash W)$, which is defined because $W^{\mathrm{work}}\ge\varphi W>0$, by an outer sum $D_{ij}\approx e_{1,i}+e_{2,j}$. It then adds $e_1$ to every $\log A_r$ and $e_2$ to every $\log b_r$:

$$
W^{\mathrm{new}}=W\circ\exp(e_1\oplus e_2)=\sum_r(A_r\circ e^{e_1})\otimes(b_r\circ e^{e_2}),
$$

which is again a positive rank-$R$ Kronecker sum. Eq. 13 of Paper II uses ordinary block means and Eq. 14 uses weights $W_{ij}^2$. For $R=1$ these weights are the product measure $\pi\otimes\omega$ of Paper II, and Eq. 14 is in closed form. For $R>1$ they are not a product, and we fit by backfitting [25].

Write $S_W=\{W\circ(x\oplus y)\}$ for the *separable gains* at $W$, and $T_W=\{\sum_rE_r\otimes b_r+A_r\otimes f_r\}$ for the tangent space of the Kronecker sum.

**Proposition 2 (what the repair fits).**

(a) *Separable gains.* If $W^{\mathrm{work}}=W\circ\exp(g_1\oplus g_2)$, ordinary or weighted block means recover $W^{\mathrm{work}}$ exactly, whatever the size of $g$ and whatever $R$. For $R=1$, ordinary block means give the least-squares best fit of $\log W^{\mathrm{work}}$ by $\log a_i+\log b_j$. This is a global fit, not a first-order one.

(b) *First order.* Weighted block means of the first-order target $D^{(1)}=(W^{\mathrm{work}}-W)\oslash W$ give the increment $W\circ(e_1\oplus e_2)$, which is the Frobenius orthogonal projection of $W^{\mathrm{work}}-W$ onto $S_W$, for every $R$.

(c) *Dimensions.* $S_W\subseteq T_W$, with $\dim S_W=n_1+n_2-1$ and, for generic positive factors with $R\le\min(n_1,n_2)$, $\dim T_W=R(n_1+n_2-R)$. For $R=1$ the two spaces coincide (Paper II's Eq. 15). For $R>1$ the gain repair sees a subspace of dimension about $1/R$ of the tangent space.

(d) *Cost.* For $R=1$ and $\Delta W=\sum_tU_t\otimes V_t$, and if the floor binds nowhere ($W+\Delta W\ge\varphi W$ everywhere), the first-order weighted means can be computed from the factors in $O(k(n_1+n_2))$ work.

*Proof.* (a) $D=g_1\oplus g_2$ lies in the fitted class, so the residual is zero. For $R=1$, $\log W_{ij}+e_{1,i}+e_{2,j}$ ranges over all outer sums as $e$ varies. (b) $\lVert\Delta W-W\circ(x\oplus y)\rVert_F^2=\sum_{ij}W_{ij}^2\,(D^{(1)}_{ij}-x_i-y_j)^2$ is the weighted least-squares objective, and $W\circ(x\oplus y)$ is linear in $(x,y)$. (c) $W\circ(x\oplus y)=\sum_r(A_r\circ x)\otimes b_r+A_r\otimes(b_r\circ y)$ lies in $T_W$. The one-dimensional kernel of $(x,y)\mapsto x\oplus y$ gives $\dim S_W$. $T_W$ is the tangent space of the rank-$R$ matrices at $\mathcal M(W)$ [19]. (d) $D^{(1)}=\sum_t(U_t\oslash a)\otimes(V_t\oslash b)$ for $W=a\otimes b$, and the weighted means of a sum of outer products are sums of weighted means of its factors. $\square$

The proposition says what the repair can absorb: a change that is a gain on rows and channels. A change learned by an adapter on a new class is not of that kind. The new class's rows were never trained, and the adapter has to move them by orders of magnitude relative to their initial values. Section 5.2 measures this. In the median sleep the largest relative change $\max|\Delta W/W|$ was $10^{2.5}$–$10^{4}$ for the rules other than the published one, depending on the rule and the dataset, and only about half of the change's norm lay in $S_W$.

**Proposition 3 (first-order rules need a small relative change).** A rule that fits the first-order target $x\approx D^{(1)}$ and then applies it multiplicatively realises $W\,e^{x}$ in place of $W(1+x)$. The error, in units of the weight, satisfies

$$
\tfrac{x^2}{2}\,e^{-|x|}\;\le\;|e^{x}-1-x|\;\le\;\tfrac{x^2}{2}\,e^{|x|},
$$

It is at least $x^2/2$ when $x\ge0$, and at least $|x|-1$ when $x<0$, since then $e^{x}-1-x=e^{x}+|x|-1$. It is therefore small only when $|x|$ is small. At $x=40$ the error is $2.4\times10^{17}$ times the weight, and the realised weight is $5.7\times10^{15}$ times the intended $41\,W$.

*Proof.* By Taylor's theorem with the Lagrange remainder, $e^{x}-1-x=\tfrac{x^2}{2}e^{\xi}$ for some $\xi$ between 0 and $x$. $\square$

A relative change of $10^4$ is harmless for the exact log target, because $\log(1+10^4)\approx9.2$. For the first-order target it is fatal. This is why the first-order version of Eq. 14 diverged at per-task cadence (Section 5.2). Paper II's caution that "first-order optimality does not guarantee a finite sleep update preserves accuracy" is borne out in the strongest form.

## 3.3 Stored boxes and exact decision tests

The store is kept as *units*: one grid per seen class (its $RP$ log-weights) and one per channel vector $b_r$ (its $h$ log-weights). A unit stored at $b$ bits defines a box. Class $c$ has log radius $\rho_c$, and each log-weight of $b_r$ has radius $\sigma_r$. Every stored log-weight may move independently within its radius.

**Proposition 4 (exact decision test).** Fix an input $H\ge0$ with $H\neq0$ (so that every score is positive), the stored decision $t$ and a seen competitor $c$. Group the monomials of the scores by the shared entry they use. For $k=(r,j)$, let $\alpha_k=\sum_pA_r[t,p]H[j,p]\,b_r[j]$ and $\beta_k=\sum_pA_r[c,p]H[j,p]\,b_r[j]$ at the stored values. Then

$$
\max_{\text{box}}\;\log\frac{z_c}{z_t}=\rho_t+\rho_c-m_{tc}(\sigma),\qquad m_{tc}(\sigma)=-\log\max_{s_k\in[e^{-\sigma_r},e^{\sigma_r}]}\frac{\sum_k\beta_ks_k}{\sum_k\alpha_ks_k},
$$

and the maximum over $s$ is attained at a *threshold vertex*: sort $k$ by $\beta_k/\alpha_k$ in decreasing order, set the leading group high and the rest low, and take the best threshold. The decision is the same for every member of the box if and only if $m_{tc}(\sigma)>\rho_t+\rho_c$ for every seen $c\neq t$, where a tie counts as a change.

*Proof.* The class-row log-weights of $c$ enter only $z_c$, and those of $t$ only $z_t$. Both scores increase with them, so the worst case puts every log-weight of $c$ at $+\rho_c$ and every log-weight of $t$ at $-\rho_t$, which multiplies the ratio by $e^{\rho_c+\rho_t}$. The shared entries enter both scores linearly through $s_k=e^{\delta_k}$ with nonnegative coefficients. A ratio of two such linear functions is quasi-linear on the box, so its maximum $\lambda^\ast$ is attained at a vertex. At that vertex $s_k$ is high exactly when $\beta_k-\lambda^\ast\alpha_k>0$, that is, at a threshold in the order of $\beta_k/\alpha_k$ [20, 21]. Equivalence holds because the maximization is exact and the box is a product over units. $\square$

The implementation evaluates the test in float64 without outward rounding, so it is exact up to rounding errors of order $10^{-15}$ in the log margin. The post-review checks A1–A3 confirm it against the pairwise test, against the explicit worst member of the box, and against brute force over every vertex at small sizes.

The test costs one sort per pair. Our implementation skips the threshold rule for a pair whose nominal log ratio exceeds $\rho_t+\rho_c+2\max_r\sigma_r$, since the shared box moves each log score by at most $\max_r\sigma_r$. Pairs are checked from the most dangerous, and the check stops at the first failure. Certifying the 10,000 test decisions of the 100-class store takes about two seconds.

**Proposition 5 (what a stored box contains).** Store a unit with values $v$ at $b\ge1$ bits on the grid with endpoints $\ell=\lfloor\min v\rfloor_{\mathrm{f16}}$, $u=\lceil\max v\rceil_{\mathrm{f16}}$ (rounded outward to float16) and step $\Delta=(u-\ell)/(2^b-1)$. (At $b=0$ the unit stores the midpoint of $[\ell,u]$, with radius $(u-\ell)/2$.) Then every reference value lies within $\Delta/2$ of its stored value, without clipping. Consequently:

1. a decision certified on the stored box (Proposition 4) equals the reference decision;
2. after $k$ re-roundings on different grids, the reference lies within the sum of the $k$ radii.

*Proof.* The outward rounding gives $\ell\le v\le u$, so rounding to the nearest grid point moves each value by at most $\Delta/2$. The reference is therefore a member of the box, and a certified decision is the decision of every member. Item 2 is the triangle inequality. $\square$

As Paper II remarks, bits added later do not shrink the box around the reference, because the information discarded by an earlier rounding is not in the stored values.

Item 1 is Paper II's retention criterion, "a stored box contains the reference parameters", turned into a computable test.

**Proposition 6 (a functional residual bound).** Let $W^{\mathrm{st}}=W^{\mathrm{work}}+\mathcal R$. Then $z_c(W^{\mathrm{work}})=z_c(W^{\mathrm{st}})-\langle\mathcal R_c,H^{\top}\rangle$ and $|\langle\mathcal R_c,H^\top\rangle|\le\lVert\mathcal R_c\rVert_F\lVert H\rVert_F$. Hence, if $\varepsilon_c\ge\lVert\mathcal R_c\rVert_F$ for every class, the working decision equals the stored decision $t$ whenever

$$
z_t(W^{\mathrm{st}})-\varepsilon_t\lVert H\rVert_F>z_c(W^{\mathrm{st}})+\varepsilon_c\lVert H\rVert_F\quad\text{for every seen }c\neq t .
$$

The test is exact over all residuals with these class norms, because each $\mathcal R_c$ can be aligned with $\pm H^\top$ independently. It costs 16 bits per class (each $\varepsilon_c$ rounded up to float16).

*Proof.* Cauchy–Schwarz, with equality for $\mathcal R_c\parallel H^\top$. $\square$

Proposition 6 is the "separate functional residual bound" that Paper II allows in place of a stored box. It knows nothing about the residual except its class norms. Keeping the $r$ leading Kronecker terms of the residual in float16 reduces its total norm (up to float16 rounding), though not necessarily every class norm, at a cost of $16\,r\,(n_1+n_2)+16\,C$ bits. Section 5.4 traces this trade-off.

# 4 Protocol

The protocol (`PROTOCOL.md` in the supplement) was written on 5 October 2026. It followed design pilots and smoke tests that used training and validation data only, and it preceded every confirmatory run and every reading of a test example. The run script reads training data only, and the evaluator alone reads the test split. The library, run script, evaluator, theory checks and protocol were frozen by SHA-256 at 04:21 UTC that day (Appendix A). Nothing was changed afterwards.

## 4.1 Data and tasks

- **Split MNIST** (Paper II's first stage). P1's split of MNIST [10]: 55,000 training, 5,000 validation and 10,000 test images. Five class-incremental tasks, {0,1}, {2,3}, {4,5}, {6,7} and {8,9}, with one head over the classes seen so far and no task label at test time [11].
- **Split CIFAR-100** (Paper II's second stage) [9]. The CIFAR-100 site is refused by our network filter, so the user supplied the official python archive (the MD5 sums of `train`, `test` and `meta` match the published values). The first 45,000 training images are used for training and the last 5,000 for validation, with the 10,000 test images for testing. There are ten class-incremental tasks of ten fine classes each, in label order.

## 4.2 Model, wake and sleep

- **Features (fixed).** 16 random 5×5 filters (zero mean, unit norm, seed 20261005), stride 2, the reflection pair $[\mathrm{relu}(x),\mathrm{relu}(-x)]$ and 2×2 average pooling. This gives $h=32$ channels at $P=36$ positions (MNIST) or $P=49$ (CIFAR-100). The features are never trained.
- **Store.** $W=\sum_{r=1}^{R}A_r\otimes b_r$ with $A_r\in\mathbb R_{>0}^{C\times P}$ and $b_r\in\mathbb R_{>0}^{32}$, held as logarithms. $R=8$ is primary and $R=1$ (Paper II's $W_1\otimes W_2$) secondary. The initial store is random and holds no knowledge.
- **Wake.** A rank-8 real Kronecker adapter is trained with Adam [22] (learning rate 0.01, 3 epochs) on the current task. Each batch has 128 current examples and 128 draws from the protected examples, and the training logits are $8\log z_c$ over the seen classes. The working weight is $\max(W+C+\Delta W,0.05\,W)$, where $C$ is a retained correction (rules none and resid only).
- **Protected examples.** When a task ends, 50 training examples per class (MNIST) or 20 (CIFAR-100) are drawn at random. They are replayed in later wakes and are the evidence of the certificate-guided policy. At 8 bits per pixel they are charged to every condition alike: 3.1 Mbit on MNIST and 49 Mbit on CIFAR-100 at the end of the stream.
- **Seeds.** 0–4.

**Sleep rules.** Each wake is followed by one sleep (per-task cadence, primary). As a secondary cadence, five rules also sleep every 10 wake steps (at $R=8$).

| Rule | Definition |
|---|---|
| none | no consolidation; the working weight is kept, with a dense float32 correction |
| pub | the published rule [5]: unit-norm nearest-Kronecker factors, $\log A_r\mathrel{+}=\alpha\log C_1$, $\log b_r\mathrel{+}=\alpha\log C_2$. Recorded as undefined where $C\le0$ (better sign); run with the named surrogate $\lvert C\rvert$ (clamped at $10^{-30}$), $\alpha=1$ |
| pub01 | the same surrogate at $\alpha=0.1$ |
| gain_ord | Paper II's Eq. 13: ordinary block means of $D=\log(W^{\mathrm{work}}\oslash W)$ |
| gain_w | Paper II's Eq. 14: block means weighted by $W^2$, exact log target |
| gain_w1 | Eq. 14 on the first-order target $(W^{\mathrm{work}}-W)\oslash W$ |
| resid | gain_w, with the residual kept as a dense float32 correction (residual-preserving control) |
| tan | (ours) Frobenius projection of the change onto $T_W$ (minimum-norm factor increments), applied additively to the factors with the floor |
| refit | (ours) after Paper II's option of "fitting a larger positive representation to the full target": the rank-$R$ store refitted to $W^{\mathrm{work}}$ in Frobenius norm (300 Adam steps on the log factors, from the current store) |

**Pilot decisions** (validation data only).

- **Rank.** $R=8$. Trained jointly on MNIST at logit scale 16–32, the rank-1 store reached 86–87% and the rank-8 store 92–93%. At logit scale 8, with 6 epochs instead of 12, they reached 81.7% and 87.0%, against 91.2% for a dense positive layer.
- **Replay and adapter.** 50 protected examples per class and replay batch 128 on MNIST: in the pilot (adapter rank 4, logit scale 16) the exact-memory stream reached 84% with them, against 73% with 20 examples and a batch of 64. Adapter rank 8: 82% against 79% for rank 4 at batch 64.
- **Scale and floor.** Logit scale 8 and floor 0.05. In the precision pilot (seed 0), uniform precision at 8 bits certified 78.3% of the final decisions at scale 8, against 69.8% at scale 16, at a reference accuracy 2 points lower (82.6% against 84.7%).
- **Correction precision.** The correction kept by the rules none and resid is stored in float32, because a float16 version overflowed in a pilot.
- **Rules added.** The repaired rules kept almost none of a learned adapter at per-task cadence. This is why refit and tan were added, and why the precision study uses the refit store.
- **CIFAR-100.** With fixed random features the model is weak. The jointly trained working model reached about 21% on 100 classes, and the exact-memory stream about 7% after ten tasks. CIFAR-100 therefore tests consolidation and storage of what such a model knows. It does not test image recognition.

## 4.3 Outcomes

At every sleep, on the test examples of the seen classes, the evaluator records the following.

- **Accuracy.** The accuracy of the working model just before the sleep, and of the stored model after it.
- **Fidelity.** The agreement of the two models.
- **Certified fidelity.** The fraction of decisions that Proposition 6 certifies, using class residual norms rounded up to float16. It is also computed with the $r\in\{1,2,4,8,16\}$ leading Kronecker terms of the residual kept in float16, together with their bits.
- **Change and residual.** The relative residual $\lVert W^{\mathrm{st}}-W^{\mathrm{work}}\rVert/\lVert W^{\mathrm{work}}-W\rVert$, the fractions of the change that lie in $S_W$ and in $T_W$, the largest relative change, the undefined fraction of the published rule, and the stored bits.
- **End of stream.** The accuracy on each task's classes.

A store with a non-finite weight has *diverged*. Its decisions are counted as errors, never as agreement.

At the secondary cadence the evaluator sees the stores before and after the *last* sleep of each task. Its sleep-level outcomes therefore describe that sleep, which consolidates the 0–9 wake steps since the previous one, not the whole task. On MNIST the wake of task 3 had a multiple of ten steps, so the sleep that ended it consolidated nothing. A stream has 132 sleeps on MNIST (127 inside the tasks and 5 at their ends) and 110 on CIFAR-100. The end-of-stream accuracies describe the whole stream.

## 4.4 Precision study

At every sleep of the $R=8$ refit runs, the full-precision store, the *reference*, is stored at reduced precision. On CIFAR-100 this is done at the sleeps that end tasks 5 and 10, for cost.

- **Units.** One grid per seen class ($R\cdot P$ log-weights) and one per channel vector (32 log-weights), as in Proposition 5. Rows of classes not yet seen are not part of the memory. Under every policy they are kept at full precision and not charged; in the dynamic arm they are carried into the next wake at full precision.
- **Equal total bits.** The budget is $\bar b$ bits per stored log-weight plus 36 bits of metadata per unit (two float16 endpoints and a 4-bit width). Usage-and-age also pays 16 bits per unit for its counters. The protected examples are common to all policies, the adapter has been deleted, and the store has no signs. Rank is fixed, so its metadata is a constant.
- **Policies.**
  - **Uniform:** $\bar b$ bits everywhere.
  - **Usage-and-age** [5, §4.4]: bits follow $\log_2$ of a decayed use count (halved per task) by water-filling. A channel vector's use is the sum over classes.
  - **Certificate-guided:** for each common width $s\in\{1,\dots,16\}$ of the channel vectors, the shared-box margins of the protected examples are computed once. They are computed on boxes centred at the reference values, whereas the stored boxes are centred at the rounded values, so this planning objective is a proxy for the evaluated one. Exact threshold values are used for each example's 8 nearest competitors, and the sound bound "nominal log ratio $-\,2\max\sigma$" for the rest. The class units start at 1 bit and receive the remaining budget one bit at a time. Each bit goes to the class with the largest exact gain in (certified protected examples $+\,10^{-3}\times$ total slack of the uncertified) per bit, and all gains are recomputed at every step. The best $s$ is kept; among equal objectives, the smallest $s$.
  - **Exposure-aware control** (ours): channel vectors at 16 bits, class units uniform with the rest. A class unit left with 0 bits stores its midpoint (Proposition 5).
- **Budgets.** $\bar b\in\{4,6,8,10,12\}$, with $\bar b=8$ primary. In the pilot, 8 was the smallest budget at which the uniform store certified at least half of the final decisions.
- **Certified retention.** The fraction of test decisions certified for every member of the stored box (Proposition 4), each of which therefore equals the reference decision (Proposition 5). We also record agreement with the reference, accuracy, the same quantities on the earlier tasks, and the allocation and certification times.
- **Bits per decision** (final sleep). For each test decision: the smallest uniform width that certifies it, $b_{\mathrm{cert}}$; the largest uniform width at which the stored decision differs from the reference, $b_{\mathrm{lost}}$ (0 if none); and the reference log margin.
- **Dynamic arm** (secondary). The $R=8$ refit stream with storage at $\bar b=8$ in the loop, for each policy: each sleep's store is replaced by its stored values before the next wake.

**A failure caught in the smoke test.** A smoke test on validation data showed that the first implementation of the certificate-guided policy starved two CIFAR-100 classes at 1 bit. That implementation was a lazy greedy, which reuses stale gains. The stored model's decisions then all became one of the starved classes: agreement with the reference fell to 0.0%. In the reproduction A5, every validation decision became class 36.

- **Cause.** Neither class was the decision of any protected example, so its initial gain was zero. The lazy greedy never re-evaluated that gain. Yet once the other classes had been refined, these two were the binding competitors of all 1,000 protected examples (A5).
- **Fix.** The exact greedy, which recomputes every gain at every step, replaced it before freezing.
- **Checks.** The frozen check T10 catches the pre-freeze lazy greedy at its own random state (A8). It is fragile, though: on fresh draws of its construction the exact greedy can also leave the never-decided class at 1 bit. Post-review check A5 reproduces the original failure on the confirmatory store, with the pre-freeze code recovered from the session transcript (A0), and shows that the exact greedy removes it. On validation decisions the exact greedy gives 99.4% agreement, with 70.7% certified.
- **Remaining limit.** The exact greedy never skips a class because of a stale gain. A class whose refinement would not raise the objective still receives bits only through the tie rule.

## 4.5 Registered criteria and predictions

- **Primary (Paper II).** Certificate-guided precision retains more than both uniform and usage-and-age precision at equal total bits.
  - *Test.* Seed-paired differences in certified retention at the final sleep of split MNIST at $\bar b=8$, with 95% t-intervals above zero for both comparisons. Otherwise Paper II's rejection applies.
  - *Cost.* Paper II's rejection reads "at equal total bits and measured cost". The protocol measures the cost and reports it beside the result; it does not equalize it.
- **Second stage (Paper II).** The same test on split CIFAR-100 at its final sleep, judged on its own.
- **Retention claims (Paper II).** Retention is claimed only when certified, by a stored box (Proposition 5) or by a functional residual bound (Proposition 6). Agreement without a certificate is reported as *uncertified* retention.
- **The published rule (Paper II).** Recorded as undefined where it is undefined; the surrogate is reported separately.
- **Agenda predictions (secondary) [24].**
  - **P3.1.** The published rule loses earlier tasks fastest: the surrogate at $\alpha=1$ has the lowest final accuracy on the pooled earlier tasks among all rules (MNIST, $R=8$, per task).
  - **P3.2.** The repaired rule (gain_w) retains at least as much as no sleep. It is rejected if the seed-paired 95% interval of the difference in final accuracy lies below zero. This tests Eq. 14 alone, as Paper II's sentence on "repair alone" does. The agenda's repaired rule also keeps "a new Kronecker term, or a retained adapter, for the remainder". Its nearest control here is the residual-preserving rule, which we report beside it as an exploratory comparison.
  - **P3.3.** "The bits at which a decision is lost follow its log-margin (Spearman ≤ −0.7)", tested with $b_{\mathrm{lost}}$ at the final sleep of split MNIST, in every seed. $b_{\mathrm{cert}}$ is reported beside it, but for it the relation is close to built in (Proposition 4).
  - **P3.4.** The primary comparison against usage-and-age.
- **Statistics.** Seed means with 95% t-intervals ($t_{0.975,4}=2.776$) and seed-paired differences.
- **Exploratory analyses.** Analyses decided after the results were seen are labelled *exploratory* where they appear:
  - the explanations offered per dataset (geometry of the residual, decision margins);
  - the bit gap between certifying a decision and keeping it;
  - the published rule's wake diagnostic;
  - the paired differences of the refit and of the residual-preserving rule from no sleep;
  - the means over the task-ending sleeps at the 10-step cadence;
  - the undefined fractions among the entries of classes already trained, and the check that no later class was ever correctly predicted at any sleep;
  - the explanation that the wake re-learns on a moved base;
  - the post-review checks and measurements A0–A9.

## 4.6 Theory checks

**The frozen checks.** `verify_p3_theory.py` (float64, seed 20261006) was frozen with the protocol. All 28 of its checks pass. The independent review found that two of them (T7 and T8) check less than their names suggest, and that one part of T10 is fragile. The table says what each check actually verifies.

| Check | Proposition | What is verified |
|---|---|---|
| T1 | 1 | on a re-implementation of the rule (clamp $10^{-300}$): scale invariance; the undefined fraction $1-f_1f_2$; shrinkage of at least $\frac{\alpha}{2}\log(n_1n_2)$ over 300 random adapters; the equality value for a flat factor; no log-weight ever rises; zero adapter rows give $C_1=0$ |
| T2 | 2(a) | ordinary block means recover separable gains of any size exactly ($R=1,3$); the $R=1$ result is the global log least-squares fit |
| T3 | 2(b) | backfitting equals Paper II's closed form; first-order weighted means equal the Frobenius projection onto $S_W$ ($R=1,2$) |
| T4 | 2(c) | $\dim S_W=n_1+n_2-1$, $\dim T_W=R(n_1+n_2-R)$ and $S_W\subseteq T_W$ ($R=1,2,3$); conjugate-gradient projection equals dense least squares |
| T5 | 2(d) | the factor-level first-order row means $e_1$ equal the dense computation (floor not binding) |
| T6 | 3 | gain_w, gain_w1 and tan agree more closely as the relative change $\varepsilon$ shrinks: their largest difference, relative to the largest change, falls from $0.28\varepsilon$ to $0.10\varepsilon$ over the tested range; the Taylor bound |
| T7 | 4 | the threshold value of `shared_margins` equals brute force over every vertex of the *shared* box, with each class unit moved as a whole (900 pairs, error $8.3\times10^{-16}$); 10,000 random members never exceed it |
| T8 | 5 | the rounding radius over 2,000 units; certified decisions equal the reference and survive 300 *uniformly sampled* members (a test that cannot detect an unsound certificate, see A4); re-rounding drift within the summed radii |
| T9 | 6 | the Cauchy–Schwarz bound and its attainment, on random matrices |
| T10 | — | allocations within budget; the greedy leaves less than one class unit unspent; exact gains equal brute force; a never-decided class gets more than 1 bit (at its random state this fails for the pre-freeze lazy greedy, but on fresh draws the exact greedy can fail it too, A8) |

**Checks added after review.** `verify_p3_addendum.py` was written after the results and the review, and it changes no frozen file. It reads training data, validation data, saved stores and the evaluator's outputs, never the test split. All its checks pass, and A6 and A9 are measurements.

| Check | What is verified |
|---|---|
| A0 | the lazy greedy used in A5 and A8 equals the pre-freeze source, recovered verbatim from the session transcript (`logs/smoke/alloc_certificate_prefreeze.py`), apart from its docstring, module prefix and import line |
| A1 | `certify`, with its pruning and early exit, agrees with the pairwise exact test on 2,400 decisions of random stores ($R=1$–8, $h=32$): 0 mismatches |
| A2 | the explicit worst member of the box (class rows at their corners, shared entries at the threshold vertex) changes or ties none of 457 certified decisions and all of 743 uncertified ones, so the test is sound and tight |
| A3 | brute force over every vertex of the full box, with every class and shared log-weight moving independently (up to $2^{12}$ vertices), equals the Proposition 4 value (120 pairs, error $4.5\times10^{-16}$) |
| A4 | with the radii deliberately halved, `certify` wrongly certifies 169 decisions; the worst member exposes all 169, while 300 uniform samples each (T8's method) expose none |
| A5 | the smoke-test failure on the confirmatory CIFAR-100 store (seed 0, sleep 5), with validation decisions: the lazy greedy leaves classes 34 and 36 at 1 bit (agreement 0.0%); the exact greedy gives widths of 6–12 bits, 99.4% agreement and 70.7% certified |
| A6 | (measurement) protected and test decisions certified by the uniform and certificate-guided policies at the first and last MNIST sleep |
| A8 | the frozen T10, run with the pre-freeze lazy greedy swapped in, fails its starvation check (class 5 at 1 bit); on six fresh draws of its construction the exact greedy gave the never-decided class 1, 8, 8, 8, 1 and 2 bits and the lazy greedy 1 bit every time |
| A9 | (measurement, validation decisions) the shared-width tie rule at the MNIST sleeps where certificate-guided precision trailed uniform precision |
| A7 | in the evaluator, no decision certified by Proposition 6 disagreed with the working model: 1,565 evaluated sleeps, 0 violations |

# 5 What sleep keeps

Unless stated otherwise, numbers are seed means with 95% t-intervals over five seeds, for $R=8$ and one sleep per task. Table 1 and Figure 1 summarise the consolidation runs, and Appendix B gives the per-seed values.

**Table 1.** Consolidation at $R=8$, one sleep per task. Columns:

- *Final.* The accuracy of the stored model after the last sleep, on all seen classes.
- *Earlier.* The same on the pooled test examples of the earlier tasks.
- *Fidelity.* The agreement of the stored and working models, averaged over sleeps. *Certified* is its certified part (Proposition 6).
- *Residual.* The median over sleeps of $\lVert W^{\mathrm{st}}-W^{\mathrm{work}}\rVert/\lVert W^{\mathrm{work}}-W\rVert$.
- *Bits.* The nominal storage cost of the store at 16 bits per log-weight, plus any float32 correction. The evaluated stores are float64; storage at reduced precision is the subject of Section 6. The protected examples are common to all rules (3.1 Mbit on MNIST, 49.2 Mbit on CIFAR-100) and are not counted.

| Rule | MNIST final (%) | MNIST earlier (%) | fidelity (%) | certified (%) | residual | bits | CIFAR-100 final (%) | CIFAR-100 earlier (%) | fidelity (%) |
|---|---|---|---|---|---|---|---|---|---|
| no sleep | 83.3 ± 1.1 | 80.7 ± 1.4 | 100 | 100 | 0 | 418,816 | 7.4 ± 0.4 | 3.7 ± 0.5 | 100 |
| published, $\lvert C\rvert$, α = 1 | 13.6 ± 4.1 | 16.9 ± 5.1 | 80.5 ± 5.6 | 0 | 0.033 | 50,176 | 1.0 ± 0.0 | 1.1 ± 0.0 | 12.5 ± 7.8 |
| published, $\lvert C\rvert$, α = 0.1 | 16.6 ± 2.9 | 20.7 ± 3.6 | 27.8 ± 3.8 | 0 | 1.001 | 50,176 | 1.2 ± 0.2 | 1.3 ± 0.3 | 4.7 ± 5.5 |
| Eq. 13 (ordinary means) | 11.6 ± 2.6 | 2.4 ± 3.4 | 49.8 ± 5.2 | 0 | 0.994 | 50,176 | 1.0 ± 0.0 | 1.1 ± 0.0 | 2.8 ± 0.9 |
| Eq. 14 (weighted means) | 21.7 ± 12.5 | 14.2 ± 17.5 | 51.0 ± 5.2 | 0 | 0.989 | 50,176 | 2.1 ± 0.3 | 2.1 ± 0.6 | 4.3 ± 1.9 |
| Eq. 14, first order | diverged (5/5) | 0 | 13.7 ± 6.4 | 0 | — | 50,176 | diverged (5/5) | 0 | 1.1 ± 0.2 |
| Eq. 14 + stored residual | 83.3 ± 1.2 | 80.6 ± 1.6 | 100 | 100 | 0 | 418,816 | 7.4 ± 0.4 | 3.7 ± 0.4 | 100 |
| tangent projection (ours) | 75.9 ± 4.9 | 76.4 ± 6.3 | 83.5 ± 5.8 | 0 | 0.911 | 50,176 | 5.7 ± 2.1 | 5.2 ± 3.5 | 19.7 ± 7.9 |
| Frobenius refit (ours) | 83.8 ± 0.7 | 82.0 ± 1.2 | 97.5 ± 0.3 | 0 | 0.343 | 50,176 | 7.4 ± 1.9 | 5.1 ± 3.3 | 62.8 ± 4.9 |

On CIFAR-100 the stores hold 631,296 bits, plus a 5,017,600-bit correction for the two rules that keep one. The relative residuals on CIFAR-100 were 0.999 (Eq. 13), 0.997 (Eq. 14), 0.847 (tangent) and 0.569 (refit). The published rule's small residual on MNIST (0.033) comes from a working model that had learned almost nothing since the first sleep (Section 5.1).

![Stored accuracy along the stream](figures/fig_streams.png)

**Figure 1.** Accuracy of the stored model on the classes seen so far, after each sleep (seed means, $R=8$, one sleep per task). Left: split MNIST. Right: split CIFAR-100. No sleep and the residual-preserving control coincide.

## 5.1 The published rule stores nothing after its first sleep

**Undefined almost everywhere.** At the first sleep, the published update was undefined at 94.5% ± 0.9 of base entries on MNIST and at 97.5% ± 0.2 on CIFAR-100. Over all sleeps the figures were 98.9% and 97.6%.

- **Why so high.** Most of the undefined entries belong to classes not yet seen, whose rows of $C_1$ are exactly zero.
- **Like-for-like** (exploratory). Among the entries of the classes already trained, the rule was undefined at 66–76% (MNIST) and 73–77% (CIFAR-100) at the first sleep. This is the comparison with the 28.0% and 63.8% of Paper II's constructions.

**The surrogate never stored a later class.** At the end of every stream the surrogate's stored model was 0.0% accurate on every task after the first. An exploratory check over all sleeps found the same: in no seed, at no sleep, did it correctly classify a single test example of a class introduced after the first sleep. This holds at α = 1 and at α = 0.1, on both datasets.

- **The first task was cut at once.** The working model was 99.9% accurate on MNIST's first task and 47.8% on CIFAR-100's. At α = 1 the first sleep left the stored model at 53.7–73.1% on the two MNIST classes (chance 50%) and 10.0–13.0% on the ten CIFAR-100 classes (chance 10%).
- **End of stream.** The stored model was 64.2% accurate on task 1 and 0.0% on tasks 2–5 of MNIST. On CIFAR-100 it was 9.8% on task 1 and 0.0% on the nine later tasks, for 1.0% overall.
- **Mechanism.** This is Proposition 1(e). In MNIST seed 0, after the first sleep the largest log-weight of each of the eight unseen classes was about −73, against −6.3 and −5.5 for the two trained classes; the clamp contributes −69.
- **The wake failed too** (exploratory diagnostic, training data). At α = 1 the wake could no longer learn new classes. The working model reached only 31.0% on four classes at the second sleep, and the adapter rows of the new classes stayed exactly zero. On those rows the loss gradient was about $10^{30}$, and its square overflowed Adam's float32 second moment, so every update was zero (`report/pub_wake_check.txt`). In exact arithmetic the rows would be exactly zero and the class's training logit $-\infty$, so the wake could not learn them by gradient descent either.
- **At α = 0.1.** The clamped factor is $10^{-3}$, and the wake did learn: the working model was 64.1% accurate at the last sleep. The sleep then discarded what it had learned, with fidelity 27.8% on average over sleeps and 19.5% at the last.

**P3.1 is rejected.**

- **MNIST.** The rule's accuracy on the earlier tasks (16.9%) ranks fourth lowest of the nine rules. First-order Eq. 14 (0.0%, diverged), Eq. 13 (2.4%) and Eq. 14 (14.2%) ended lower.
- **CIFAR-100.** It ranks second lowest (1.09%), above first-order Eq. 14 (0.0%) and just below Eq. 13 (1.12%).
- **Mechanism.** The rule does shrink the base at every sleep (Proposition 1(c)), as P3.1 assumed. But its failure is not a progressive loss of earlier tasks. It cut the first task at once, to 61% on MNIST and 11% on CIFAR-100, and never stored any later one.

## 5.2 The repaired rules leave a learned change as residual

**At per-task cadence.** Paper II's repairs consolidated almost nothing.

- **Residual.** The median relative residual was 0.994 (Eq. 13) and 0.989 (Eq. 14) on MNIST, and 0.999 and 0.997 on CIFAR-100. After the sleep, the store was almost as far from the working weight as before it.
- **Accuracy.** Fidelity fell sleep by sleep, and so did accuracy (Figure 1). The streams ended at 11.6% ± 2.6 and 21.7% ± 12.5 on MNIST, and at 1.0% and 2.1% on CIFAR-100.

**Why** (exploratory). Proposition 2 says what these rules absorb exactly: separable gains $W\circ\exp(g_1\oplus g_2)$, of any size. The changes the wake learned were not of that kind.

- **Size.** In the median sleep the largest relative change was $10^{3.5}$–$10^{4.0}$ for the two rules.
- **Direction.** Only about half of the change's norm lay in $S_W$ (0.48–0.52 across both rules and datasets), against 0.65–0.70 in the tangent space $T_W$.

Direction explains only part of the failure. With half of its norm in $S_W$, even the best first-order fit within $S_W$ would leave about 87% of the change, since $\sqrt{1-0.5^2}\approx0.87$. The rest comes from fitting logarithms. On a new class's rows the working weight grew by up to $10^3$–$10^4$ on some channels and was floored at $0.05\,W$ on others, so the log ratio mixes values near $+7$ with values near $-3$. A gain fitted in log space averages them, and applied multiplicatively it recovers little of the large entries that carry the change's Frobenius norm.

**First order.** The first-order version of Eq. 14 diverged in all five seeds on both datasets. On MNIST it diverged at the second sleep in four seeds and at the third in the other. This is Proposition 3: a relative change of $x=10^3$ realised as $e^{x}$ errs by far more than the change itself. At $R=1$ it diverged in four seeds of five on MNIST and in all five on CIFAR-100.

**P3.2 is rejected.** The difference between Eq. 14 and no sleep in final accuracy was −61.6 ± 12.2 points on MNIST, with every seed between −72.2 and −50.8. On CIFAR-100 it was −5.3 ± 0.4 points. Both intervals lie far below zero.

- **Paper II's warning.** It said that "repair alone has no theorem guaranteeing performance at least as good as no sleep". In this setting repair alone is far worse than no sleep.
- **The agenda's wider rule.** The agenda's repaired rule also keeps the remainder. Its nearest control here, Eq. 14 with the residual stored, matched no sleep to within 0.2 points in every seed: +0.0 ± 0.2 points on MNIST and +0.0 ± 0.1 on CIFAR-100 (exploratory).

**The residual-preserving control is exact because it stores what the sleep did not absorb.** Eq. 14 with the residual kept as a dense float32 correction reproduced the working model at every sleep: 100% fidelity, all of it certified, and the same final accuracy as no sleep (83.3% and 7.4%).

- **Cost.** The correction takes 368,640 bits on MNIST, 7.3 times the 16-bit store, and 5.0 Mbit on CIFAR-100, 7.9 times the store. In float16 it would take about half as much, but the float16 version overflowed in a pilot.
- **What it holds.** The repair left almost the whole change in the residual, so the correction holds nearly everything the adapter learned.

The control satisfies Paper II's requirement that the residual "remain stored". The repair contributes almost nothing to it.

## 5.3 A refit keeps most decisions but cannot prove it

**Refit.** Paper II also allows "fitting a larger positive representation to the full target when feasible". The $R=8$ store refitted to $W^{\mathrm{work}}$ in Frobenius norm (ours) was the only consolidating rule that kept pace with no sleep in accuracy.

- **MNIST.** It ended at 83.8% ± 0.7, and per task it scored 90.5, 80.0, 74.1, 82.3 and 91.3%. The paired difference from no sleep was +0.5 ± 0.7 points (exploratory). It kept 97.5% of decisions per sleep on average (94.5% at the last sleep), with a relative residual of 0.34, in a 50,176-bit store.
- **CIFAR-100.** It ended at 7.4% ± 1.9 (difference from no sleep −0.0 ± 1.9) but kept only 62.8% of decisions per sleep, with a relative residual of 0.57. What it changed was the recency bias. The refit spread accuracy over the tasks (5.1% on the earlier tasks against 3.7% without sleep) at the expense of the last task (27.8% against 40.7%).

**Tangent projection.** The first-order projection onto the full tangent space (ours), applied additively, ended at 75.9% ± 4.9 on MNIST and 5.7% ± 2.1 on CIFAR-100, with relative residuals of 0.91 and 0.85.

**Nothing certified.** None of this retention is certified. With Proposition 6 and class residual norms alone, the certified fidelity of the refit, the tangent projection and both repairs was 0.0% at every sleep, on both datasets. The refit's residual is spread over all entries. For every test decision, the class norms multiplied by the feature norm exceeded the margin to some competitor.

## 5.4 Residual accounting

Proposition 6 can be sharpened by keeping the $r$ leading Kronecker terms of the residual in float16 and bounding only the rest. Figure 2 traces certified fidelity against the bits of the kept terms.

- **Refit, per task.** At the last sleep, 16 kept terms (100,512 bits, twice the store) certified 0.9% of MNIST decisions. On CIFAR-100, 1.26 Mbit certified 0.3%.
- **Tangent projection, per task.** The same 16 terms certified 33.9% on MNIST and 8.0% on CIFAR-100.
- **Uncertified agreement.** The kept terms raise it quickly: the refit's fidelity rose from 94.5% to 98.7% on MNIST.

At one sleep per task, retention through consolidation is therefore *uncertified* in the sense of Paper II's criterion, except where the whole residual is stored.

![Residual accounting](figures/fig_residual.png)

**Figure 2.** Certified fidelity against the bits of the kept residual terms, $r\in\{0,1,2,4,8,16\}$, at the last sleep of the stream (seed means). Solid lines: one sleep per task. Dashed lines: the 10-step cadence, whose last sleep consolidates only the 2 wake steps since the previous sleep, on both datasets. The dotted line marks the dense float32 correction kept by the residual-preserving control, which certifies every decision.

## 5.5 Cadence and rank

**Sleeping every 10 wake steps** (132 sleeps per MNIST stream and 110 per CIFAR-100 stream) changed the outcome on MNIST but not on CIFAR-100.

- **MNIST, the repairs.** Eq. 14 ended at 64.6% ± 7.6, against 21.7% at one sleep per task, and Eq. 13 at 20.7% ± 8.6, against 11.6%. At this cadence the weighting mattered: Eq. 14 ended 44 points above Eq. 13.
- **MNIST, the first-order rule.** First-order Eq. 14 ended at 7.0% and diverged in one seed, against five at one sleep per task.
- **MNIST, our rules.** The tangent projection ended at 79.4% ± 1.7, against 75.9%. The refit ended at 83.3% ± 1.7, against 83.8%, so the cadence made no difference to it.
- **Small changes are not absorbed either.** Eq. 14 still left 98.5% of each small change as residual (median relative residual 0.985). Its stream nevertheless ended at 64.6%. A plausible reason (exploratory) is that the wake kept re-learning on the base that the sleeps had moved.
- **CIFAR-100.** No rule improved by more than 0.1 points. The refit ended at 6.1% ± 0.4 (7.4% per task), the tangent projection at 5.4% ± 0.6 (5.7%), Eq. 14 at 1.9% (2.1%) and Eq. 13 at 1.1% (1.0%). First-order Eq. 14 diverged in four seeds instead of five.

**Certificates at the 10-step cadence** (exploratory means). The evaluator saw only the sleep that ends each task.

- **MNIST.** One of the five task-ending sleeps consolidated nothing. Over the other four, Proposition 6 with class norms alone certified 86.9% of the tangent projection's decisions on average, and 38.3% of the refit's.
- **The last sleep of the stream.** It covers 2 wake steps on MNIST. The figures there were 76.2% (tangent) and 4.3% (refit), and 96.5% and 76.2% with 16 kept terms.
- **CIFAR-100.** The tangent projection averaged 5.7% (19.3% at the last sleep of the stream, and 93.2% there with 16 kept terms). The refit stayed below 0.5%.

Small sleeps of the tangent projection were therefore largely certifiable on MNIST, but not on CIFAR-100.

**At $R=1$**, the literal $W_1\otimes W_2$ of Paper II, no consolidating rule could hold the stream. On MNIST the refit ended at 37.1% ± 3.3, the tangent projection at 44.5% ± 4.7 and Eq. 14 at 24.3% ± 6.4. Without sleep the stream reached 83.2%, because its dense correction carries everything. On CIFAR-100 these rules ended at 1.8–2.5%.

# 6 What storage keeps

## 6.1 Certificate-guided precision (primary)

**Table 2.** Certified retention at the final sleep: the fraction of test decisions certified for every member of the stored box, each of which therefore equals the reference decision. The store is the $R=8$ refit store, with $\bar b$ bits per log-weight at equal total bits. Differences are seed-paired (certificate-guided minus the other policy).

| $\bar b$ | uniform (%) | usage-and-age (%) | certificate-guided (%) | exposure control (%) | cert − uniform | cert − usage |
|---|---|---|---|---|---|---|
| **MNIST, sleep 5** | | | | | | |
| 6 | 22.2 ± 2.8 | 22.0 ± 2.9 | 26.5 ± 3.5 | 7.0 ± 2.0 | +4.2 ± 1.4 | +4.4 ± 2.5 |
| **8 (primary)** | **81.0 ± 1.2** | **80.3 ± 2.0** | **82.9 ± 1.0** | 75.2 ± 2.0 | **+1.9 ± 0.7** | **+2.6 ± 1.4** |
| 10 | 94.9 ± 0.4 | 94.8 ± 0.5 | 95.3 ± 0.4 | 94.2 ± 0.4 | +0.3 ± 0.2 | +0.5 ± 0.2 |
| 12 | 98.7 ± 0.1 | 98.6 ± 0.1 | 98.5 ± 0.4 | 98.6 ± 0.1 | −0.1 ± 0.4 | −0.1 ± 0.4 |
| **CIFAR-100, sleep 10** | | | | | | |
| 6 | 0.5 ± 0.5 | 5.6 ± 2.7 | 17.0 ± 8.8 | 0.4 ± 0.2 | +16.6 ± 8.9 | +11.5 ± 6.9 |
| **8 (second stage)** | **27.4 ± 4.9** | **45.4 ± 13.5** | **67.8 ± 20.7** | 29.3 ± 6.2 | **+40.4 ± 18.6** | **+22.4 ± 9.0** |
| 10 | 72.6 ± 3.5 | 81.7 ± 6.8 | 90.7 ± 7.1 | 74.9 ± 4.6 | +18.1 ± 6.0 | +8.9 ± 1.7 |
| 12 | 92.3 ± 0.9 | 95.0 ± 1.8 | 97.0 ± 1.7 | 93.2 ± 1.0 | +4.7 ± 1.4 | +2.1 ± 0.6 |

At $\bar b=4$ no policy certified any decision on either dataset.

![Certified retention against budget](figures/fig_precision.png)

**Figure 3.** Certified retention at the final sleep against the budget, for each policy. Dots are seeds and lines are seed means. The dotted line marks the primary budget.

**The primary criterion is met on split MNIST, at equal total bits.** At $\bar b=8$, certificate-guided precision certified 82.9% ± 1.0 of the final decisions, against 81.0% ± 1.2 for uniform and 80.3% ± 2.0 for usage-and-age precision. Its extra cost is computation at sleep, which is reported in Section 6.4 and not equalized.

- **Differences.** The seed-paired differences were +1.9 ± 0.7 points (interval [1.2, 2.7]) and +2.6 ± 1.4 points ([1.2, 4.0]). Every seed was positive, at +1.1 to +2.7 and +1.1 to +3.8.
- **Across budgets.** The advantage was largest at 6 bits (+4.2 and +4.4) and vanished at 12 bits, where every policy certified nearly everything.
- **Earlier sleeps** (registered secondary outcomes). The advantage over uniform precision grew along the stream. At $\bar b=8$ the difference was −0.4 ± 0.5 points at sleep 1, −0.1 ± 0.4 at sleep 2, +0.7 ± 0.7 at sleep 3, +1.2 ± 0.4 at sleep 4 and +1.9 ± 0.7 at sleep 5. Against usage-and-age it was −0.4 ± 0.5, +1.1 ± 0.4, +2.4 ± 0.7, +3.3 ± 0.2 and +2.6 ± 1.4.
- **At 12 bits.** Certificate-guided precision was slightly but significantly *worse* than uniform at sleeps 1, 2 and 4, by 0.3–0.5 points.
- **Why it trailed** (exploratory; checks A6 and A9, validation decisions).
  - *Saturation.* At the first sleep uniform precision already certified 98–100% of the protected examples, so the objective could not tell many allocations apart.
  - *The tie rule.* Among equal objectives, the allocation keeps the smallest shared width, and it stored the channel vectors at 3–8 bits.
  - *At 12 bits.* Breaking ties toward the largest width recovered almost all of the shortfall at the first sleep: 99.96% certified against 99.41% with the frozen rule and 99.98% for uniform.
  - *At 8 bits.* It recovered only a little (99.43% against 99.35% and 99.78%).
  - *At sleep 2 (12 bits).* It recovered about half (99.61% against 99.47% and 99.72%).
  - *At sleep 4 (12 bits).* It recovered nothing (98.80% either way, against 99.04%).
  - *The remaining gaps.* These plausibly come from the planning objective being a proxy. It is computed on protected training examples, on boxes centred at the reference values, while the stored boxes are centred at the rounded values.

**The second stage is met on split CIFAR-100, by a wide margin.** At $\bar b=8$ the certified fractions were 67.8% ± 20.7, 27.4% ± 4.9 and 45.4% ± 13.5, giving differences of +40.4 ± 18.6 ([21.8, 59.0]) and +22.4 ± 9.0 ([13.5, 31.4]). At sleep 5 (50 classes) the differences were +30.7 ± 7.6 and +18.5 ± 5.6, and at every budget from 6 bits, at both evaluated sleeps, certificate-guided precision led both comparators. A plausible reason for the larger gain (exploratory) is that decisions were closer: the median reference log margin was 0.031 nats on CIFAR-100, against 0.21 nats on MNIST. The class units also differed more in what they needed, and certificate-guided precision gave them widths of 5.4 to 12.6 bits at an average of 8.

**Where the bits went.**

- **Usage-and-age.** It gave the channel vectors the most bits (11.4 on MNIST, 15.0 on CIFAR-100), because every class uses them.
- **Certificate-guided.** It did the same (10.2 and 14.6 bits), and then spread the class units by need.
- **Exposure control.** Our control gives the channel vectors 16 bits and the class units uniform widths. It did *worse* than uniform on MNIST (75.2%) and about as well as uniform on CIFAR-100 (29.3% against 27.4%). So exposure of the shared vectors does not explain the gain. At the first MNIST sleep at $\bar b=4$, the control's 16-bit vectors exceeded the budget (4,096 against 3,328 weight bits). It is a control, not a registered comparison.

**Agreement and accuracy.**

- **Agreement.** Uncertified agreement with the reference was 98.9–99.4% on MNIST at $\bar b=8$ for every policy, and 97.7–98.9% on CIFAR-100. Certificate-guided precision had slightly lower agreement than uniform on MNIST (99.2% against 99.4%), although it had higher certified retention.
- **When nothing can be certified.** At 4 bits its slack-driven allocation lowered agreement (88.0% against 89.2% on MNIST, 47.5% against 60.2% on CIFAR-100).
- **Accuracy.** It was the same under every policy (83.8–83.9% and 7.4% at $\bar b=8$).

Certificates and agreement are different objectives, and the certified fraction lower-bounds retention, as the agenda states.

## 6.2 Bits per decision (P3.3)

**P3.3 is rejected on split MNIST.** At the final sleep, the Spearman correlation between a decision's reference log margin and the bits at which it is lost was −0.60, −0.52, −0.53, −0.65 and −0.58 in the five seeds (mean −0.575 ± 0.066). The registered threshold is −0.7. On CIFAR-100, reported beside it, the correlation was −0.68 to −0.77 (mean −0.729 ± 0.048), with three seeds of five at −0.7 or below.

**The bits to *certify* a decision do follow its margin.** The correlation was −0.93 to −0.95 on MNIST and −0.95 to −0.97 on CIFAR-100. This is close to built in, since a uniform box certifies a decision when its margin exceeds a width that halves with every bit (Proposition 4).

**The certificate's margin** (exploratory). A certificate asks for about four to five bits more than a decision needs (Figure 4).

- **The gap.** The median gap between the bits to certify a decision and the width from which it was kept was 4 bits on MNIST (interquartile range 4–5) and 5 on CIFAR-100 (4–6). Measured from the largest width at which the decision was still lost, the gap is one bit larger.
- **Typical decisions.** The median decision was certified at 7 bits and kept from 3 bits on MNIST, and certified at 9 and kept from 5 on CIFAR-100.
- **Extremes.** Between 3.3% and 17.6% of MNIST decisions survived storage at 1 bit per log-weight.

A worst-case box aligns every rounding error against the decision. Actual rounding errors do not align.

![Bits per decision](figures/fig_bits.png)

**Figure 4.** Bits per decision at the final sleep against the reference log margin, pooled over seeds in 20 quantile bins of the margin. Blue: the smallest uniform width that certifies the decision. Red: the largest width at which the stored decision differs from the reference.

## 6.3 Precision in the loop (dynamic arm)

With storage at $\bar b=8$ after every sleep, and the next wake starting from the stored values, certificate-guided precision again certified the most decisions.

- **MNIST.** The final box certified 82.8% ± 1.1, against 81.0% ± 1.2 (uniform) and 79.9% ± 2.0 (usage-and-age), with paired differences of +1.8 ± 0.7 and +2.9 ± 2.3.
- **CIFAR-100.** It certified 64.5% ± 18.2 against 28.1% ± 6.3 and 44.7% ± 14.7 (+36.3 ± 14.2 and +19.7 ± 6.4).
- **Accuracy.** It did not change (84.0%, 83.4% and 83.8% on MNIST; 7.5%, 7.5% and 7.3% on CIFAR-100).
- **Divergence from full precision.** Rounding in the loop changed the later learning, and the final decisions agreed with the full-precision stream on 96.0–97.3% (MNIST) and 75.1–83.8% (CIFAR-100) of test examples.

## 6.4 Cost

**Memory.** By construction no policy exceeds the common budget, with one exception noted in Section 6.1.

- **Usage-and-age** pays its counters out of the same budget.
- **Certificate-guided precision** leaves less than one class unit unspent (for example 25,024 of 25,088 weight bits in MNIST seed 0).
- **Scale.** On MNIST at $\bar b=8$ the store occupies 25,736 bits including metadata, against 3.1 Mbit of protected examples. In this setting the replay memory, not the store, dominates the total.

**Time.**

- **Allocation.** Certificate-guided allocation took 1.2 s per sleep at 10 classes (MNIST), 4.3 s at 50 classes and 23.6 s at 100 classes (CIFAR-100, $\bar b=8$). Uniform, usage-and-age and the exposure control took under 0.05 s.
- **Certification.** Certifying the 10,000 test decisions of the final sleep at $\bar b=8$ took 0.5–1.7 s on MNIST and 1.9–2.6 s on CIFAR-100, under every policy.
- **Stream.** With certificate-guided storage in the loop, a whole stream took 6.2 s on MNIST and 97 s on CIFAR-100, against 3.6 s and 10.5 s with uniform storage.
- **Inference.** It is unchanged, since the stored model is evaluated the same way under every policy.
- **Measurement.** Times were measured on two CPU cores shared by two processes.

# 7 Verdict

**Table 3.** The registered criteria and predictions.

| Item (source) | Test | Result | Verdict |
|---|---|---|---|
| Primary (Paper II) | certificate-guided vs uniform and usage-and-age, certified retention, final sleep of split MNIST, $\bar b=8$, paired 95% intervals above zero | +1.9 ± 0.7 and +2.6 ± 1.4 points | **met** at equal total bits |
| Second stage (Paper II) | the same on split CIFAR-100 | +40.4 ± 18.6 and +22.4 ± 9.0 points | **met** at equal total bits |
| Measured cost (Paper II) | "at equal total bits and measured cost": cost measured and reported, as the protocol registered | extra computation at sleep: 1.2 s (MNIST) and 23.6 s (CIFAR-100) per allocation; the same memory and inference cost | reported, not equalized |
| Retention claims (Paper II) | only by a stored box or a functional residual bound | storage: certified retention reported throughout. Sleep at one per task: certified only where the residual was stored (no sleep, residual-preserving). The refit's retention (97.5% of decisions per sleep on MNIST, 62.8% on CIFAR-100) is uncertified | as registered |
| Published rule (Paper II) | undefined recorded; surrogate reported separately | undefined at 94.5% and 97.5% of base entries at the first sleep. The surrogate never stored a later class, and the first sleep cut the first task to 61% (MNIST, two classes) and 11% (CIFAR-100, ten classes) | recorded |
| Repair without a theorem (Paper II) = P3.2 | Eq. 14 minus no sleep, final accuracy | −61.6 ± 12.2 (MNIST), −5.3 ± 0.4 (CIFAR-100) points | **P3.2 rejected** for Eq. 14 alone, as registered (exploratory: with the residual stored, +0.0 ± 0.2) |
| P3.1 (agenda) | the published rule has the lowest final accuracy on the earlier tasks | 4th lowest of 9 on MNIST (2nd on CIFAR-100); three repaired variants ended lower. The rule's failure is that nothing after the first sleep is stored | **rejected** |
| P3.3 (agenda) | Spearman(margin, bits lost) ≤ −0.7 in every MNIST seed | −0.52 to −0.65 | **rejected** |
| P3.4 (agenda) | certificate-guided vs usage-and-age at equal bits | +2.6 ± 1.4 (MNIST), +22.4 ± 9.0 (CIFAR-100) at the final sleep | **supported** |
| Kill criterion (agenda) | "If P3.4 fails, certificates are not worth their cost in the store." | P3.4 holds | not triggered |

**In short.**

- **Storage.** At the registered endpoint, certificate-guided precision does what Paper II registered: at equal total bits it keeps more decisions with guarantees than uniform or usage-and-age precision, on both stages. The price is computation at sleep. On MNIST the advantage over uniform precision built up along the stream, and at 12 bits uniform precision was slightly but significantly ahead at three of the five sleeps.
- **Consolidation.** At one sleep per task, consolidation does not yet know what it keeps. No repaired sleep kept a learned adapter. The sleep that kept most decisions could not prove it, and the sleep that could prove it did not consolidate.

# 8 Discussion

**Storage can be certified, consolidation not yet.** The two halves of P3 differ in what the certificate has to cover.

- **Storage.** The perturbation is the rounding, and the rounding *is* a box. Proposition 4 decides that box exactly, so the certified fraction is computable, and it is a usable objective for allocating bits.
- **Consolidation.** The perturbation is whatever the sleep failed to absorb, and nothing makes that a box. Proposition 6 bounds it by class norms, which is exact over all residuals with those norms but knows nothing of their direction.

**The cost of worst-case statements.**

- **Consolidation.** On MNIST the refit's residual was a third of the change in norm. Its worst-case alignment with the features exceeded the margin of every decision, although on average only 2.5% of decisions changed per sleep.
- **Storage.** Bits per decision show the same gap from the other side: worst-case boxes asked for four to five bits more than the decisions needed.

Sound certificates are worst-case statements. For storage, what narrows the gap is spending bits where margins are small. For consolidation it would be a residual that is small relative to the margins, or a bound that uses more than norms. On MNIST, the short task-ending sleeps of the tangent projection were mostly certified (exploratory), so the first option can work for a single sleep. Whether per-sleep certificates can be chained into retention over a whole stream is untested: the 127 inner sleeps were never evaluated, and a chain of certificates needs a composition argument.

**When the repairs work.** Proposition 2 is a statement about separable gains. In Paper II's L9 constructions the repair's residual was 0.025 for a gain-type change and 0.98 for a generic adapter, close to the 0.99 we measured. A wake that learns new classes produces the generic kind: relative changes of $10^3$–$10^4$ on a few rows, with signs that vary across channels.

- **Cadence and weighting.** On MNIST both mattered. At the 10-step cadence Eq. 14 rose from 21.7% to 64.6% and ended 44 points above Eq. 13. Each sleep still left 98.5% of its change as residual; plausibly (exploratory) the wake did the rest by re-learning on the moved base. On CIFAR-100 cadence did not help, and weighting lifted Eq. 14 only from 1.0% to 2.1%, still near chance (1%).
- **Our two rules.** The refit and the tangent projection are not gain rules, and they did better than the repairs. The tangent projection still ended below no sleep at one sleep per task, so Paper II's warning applies to it too.

**What the published rule actually does.** Its failure is not the slow shrinkage of earlier tasks that P3.1 anticipated.

- **Shrinkage only.** Its unit-norm factors make every update a shrinkage: no weight can rise (Proposition 1(d)).
- **Untouched rows.** Rows that the adapter did not touch receive a factor of zero.

In a class-incremental stream, the classes that have not yet arrived are exactly those rows. In exact arithmetic the published rule therefore fixes the set of storable classes at the first sleep. An additive or log-consistent rule, such as any of the repairs, does not have this property. This is the strongest reason not to use the published rule as written, and it does not depend on the surrogate: the original rule is undefined on those rows, and every assignment of a finite value to them is a different rule.

**Why certificates helped more on CIFAR-100** (exploratory). Decisions were closer, with median log margins of 0.031 nats against 0.21, a factor of about 6.6. The store therefore had to be stored more precisely to certify anything, and classes differed more in how much precision they needed.

- **Uniform precision.** It spends the same bits on a class whose decisions are safe at 6 bits as on one that needs 12.
- **Usage-and-age precision.** It spends bits by how often a class was used. Under replay every class keeps being used, so the logarithm of its decayed count varies little. Usage-and-age gave the class units widths within one or two bits of each other (7–8 bits on MNIST, 7–9 on CIFAR-100), and use says little about margins.
- **Certificate-guided precision.** Its widths ranged from 5.4 to 12.6 bits at an average of 8.

On MNIST the margins were larger and the class units needed more similar precision (certificate-guided widths 6.8 to 8.8 bits). There was less to redistribute, and the gain at the final sleep was 2–3 points at 8 bits and 4 points at 6 bits.

**What the memory budget is made of.** By construction no policy exceeded the common budget, with the one exception noted in Section 6.1. In this setting the replay memory was more than 99% of that budget: 3.1 Mbit of protected examples against 26 kbit of store on MNIST. Certified retention is a property of the store, but total memory is dominated by replay. A larger store with fewer protected examples would shift the balance, and our experiment does not show where it lies at scale.

# 9 Limitations

- **One layer on fixed features.** The store is a single positive Kronecker layer on fixed random convolutional features. The certificates are exact for it (Propositions 4–6). For deeper positive stacks Paper II gives only sufficient conditions. On CIFAR-100 the model is weak (7.4% at the end of the stream), and what is certified there is retention of its decisions, not their correctness.
- **Wake learning.** The wake trains one layer by gradient descent. The agenda's interval Forward-Forward wake [23], with its forward-only radius search, was not tested.
- **Variants not run.** The agenda's "repaired rule with rank growth" was not run. A fixed-rank refit at $R=8$ and $R=1$ stands in for Paper II's "larger positive representation". P3.2 was tested, as registered, with Eq. 14 alone.
- **The fast cadence.** At the 10-step cadence the evaluator saw only the sleep that ends each task, which covers 0–9 wake steps. On MNIST one of those sleeps consolidated nothing, and per-sleep means at this cadence include it unless stated otherwise. The end-of-stream accuracies describe the whole stream.
- **The theory checks.** Two of the frozen checks are weaker than their first description, and a third is fragile.
  - T7 moves each class unit only as a whole, and it tests `shared_margins`, not `certify`.
  - T8 samples uniformly and cannot detect an unsound certificate.
  - T10's starvation check catches the pre-freeze lazy greedy at its own random state, but on fresh draws the exact greedy can fail it too.

  The post-review checks A1–A5 and A8 test these points directly, and all pass. A code comment in the frozen library claims that the exact greedy "cannot" starve a class. What holds is narrower: the exact greedy never skips a class because of a stale gain.
- **The published rule's wake.** Its wake failed in float32 by overflow in Adam. In exact arithmetic the training logit of an annihilated class is $-\infty$, so the class is not learnable that way either.
- **The certificate policy's evidence.** It plans with protected training examples, on boxes centred at the reference values, while certification is measured on test examples and on boxes centred at the stored values. At the first MNIST sleep, and at 12 bits, it was slightly worse than uniform.
- **The exposure control.** Our exposure-aware control exceeded the budget at one cell (first MNIST sleep, $\bar b=4$). It is not part of any registered comparison.
- **Times.** Times were measured with two processes sharing two CPU cores, and are indicative.
- **Scale.** Five seeds per condition. Intervals on CIFAR-100 are wide, although every seed favoured the certificate-guided policy.

# 10 Conclusion

P3 asked whether a wake–sleep memory in a logarithmic number system can know what it keeps. For storage it can.

- **An exact test.** A stored log box contains the reference parameters, and for one positive Kronecker layer with shared factors the decision test under that box is exact.
- **A better allocation.** Allocating bits by that test certified more decisions than uniform or usage-and-age precision at equal total bits. At the final sleep the margin was 2–3 points on split MNIST and 22–40 points on split CIFAR-100, at a cost of seconds of computation per sleep. Paper II's primary criterion is met on both stages at equal total bits.

For consolidation it cannot yet.

- **The published rule.** In exact arithmetic it cannot store any class introduced after its first sleep, and in our runs it never did.
- **The repaired rules.** They absorb separable gains, and learned changes are not of that kind. They left 99% of each change as residual and lost to no sleep on MNIST by 62 points (Eq. 14) and 72 points (Eq. 13).
- **The refit.** A Frobenius refit matched no-sleep accuracy and kept 97.5% of decisions per sleep on MNIST (62.8% on CIFAR-100). At one sleep per task none of that retention could be certified without storing most of the residual.

The next step is a consolidation whose residual is certifiable. That means either small, frequent sleeps, or residual bounds that use the data distribution and not only norms. On MNIST our certificates covered most decisions at the short task-ending sleeps of the tangent projection, though not on CIFAR-100, and not yet over a whole stream.

# References

[1] Ghosh, Debi Prasad. (2026). *Interval Transformers with Exact Local Weight Ranges and Sparse Expert Routing*. Manuscript, 1 October 2026.

[2] Ghosh, Debi Prasad. (2026). *Log Interval Networks for Certified Decisions and Structured Memory*. Research programme with reproducible numerical checks, 1 October 2026.

[3] Ghosh, Debi Prasad. (2026). *Log Interval Networks for Evidence Accumulation and Certified Decisions*. P1 of the log interval network programme, 4 October 2026.

[4] Ghosh, Debi Prasad. (2026). *Positive Kronecker Attention with Dependency Control*. P2 of the log interval network programme, 5 October 2026.

[5] Dibya Ghosh, Dyuti Ghosh, and Debi Prasad Ghosh. (2025). *Sleep-Consolidated Non-Backprop Learning with Logarithmic Long-Term Memory and Kronecker-Structured Weights*. Manuscript dated 21 September. https://doi.org/10.13140/RG.2.2.20326.89925

[6] Miyashita, D., Lee, E. H., and Murmann, B. (2016). Convolutional Neural Networks using Logarithmic Data Representation. arXiv:1603.01025. https://arxiv.org/abs/1603.01025

[7] Van Loan, C. F., and Pitsianis, N. (1993). Approximation with Kronecker products. In *Linear Algebra for Large Scale and Real-Time Applications*, pp. 293–314. https://doi.org/10.1007/978-94-015-8196-7_17

[8] Wołczyk, M., Piczak, K., Wójcik, B., Pustelnik, Ł., Morawiecki, P., Tabor, J., Trzciński, T., and Spurek, P. (2022). Continual Learning with Guarantees via Weight Interval Constraints. *Proceedings of ICML*, PMLR 162, 23897–23911. https://proceedings.mlr.press/v162/wolczyk22a.html

[9] Krizhevsky, A. (2009). *Learning Multiple Layers of Features from Tiny Images*. Technical report, University of Toronto.

[10] LeCun, Y., Bottou, L., Bengio, Y., and Haffner, P. (1998). Gradient-based learning applied to document recognition. *Proceedings of the IEEE*, 86(11), 2278–2324. https://doi.org/10.1109/5.726791

[11] van de Ven, G. M., and Tolias, A. S. (2019). Three scenarios for continual learning. arXiv:1904.07734. https://arxiv.org/abs/1904.07734

[12] Rebuffi, S.-A., Kolesnikov, A., Sperl, G., and Lampert, C. H. (2017). iCaRL: Incremental Classifier and Representation Learning. *Proceedings of CVPR*, 2001–2010. https://doi.org/10.1109/CVPR.2017.587

[13] Kirkpatrick, J., Pascanu, R., Rabinowitz, N., Veness, J., Desjardins, G., Rusu, A. A., Milan, K., Quan, J., Ramalho, T., Grabska-Barwinska, A., Hassabis, D., Clopath, C., Kumaran, D., and Hadsell, R. (2017). Overcoming catastrophic forgetting in neural networks. *Proceedings of the National Academy of Sciences*, 114(13), 3521–3526. https://doi.org/10.1073/pnas.1611835114

[14] McClelland, J. L., McNaughton, B. L., and O'Reilly, R. C. (1995). Why there are complementary learning systems in the hippocampus and neocortex: Insights from the successes and failures of connectionist models of learning and memory. *Psychological Review*, 102(3), 419–457. https://doi.org/10.1037/0033-295X.102.3.419

[15] Hu, E. J., Shen, Y., Wallis, P., Allen-Zhu, Z., Li, Y., Wang, S., Wang, L., and Chen, W. (2022). LoRA: Low-Rank Adaptation of Large Language Models. *ICLR 2022*. arXiv:2106.09685. https://arxiv.org/abs/2106.09685

[16] Dong, Z., Yao, Z., Gholami, A., Mahoney, M. W., and Keutzer, K. (2019). HAWQ: Hessian AWare Quantization of Neural Networks with Mixed-Precision. *Proceedings of ICCV*, 293–302. https://doi.org/10.1109/ICCV.2019.00038

[17] Wang, K., Liu, Z., Lin, Y., Lin, J., and Han, S. (2019). HAQ: Hardware-Aware Automated Quantization with Mixed Precision. *Proceedings of CVPR*, 8612–8620. https://doi.org/10.1109/CVPR.2019.00881

[18] Weng, T.-W., Zhao, P., Liu, S., Chen, P.-Y., Lin, X., and Daniel, L. (2020). Towards Certificated Model Robustness Against Weight Perturbations. *Proceedings of the AAAI Conference on Artificial Intelligence*, 34(04), 6356–6363. https://doi.org/10.1609/aaai.v34i04.6105

[19] Vandereycken, B. (2013). Low-rank matrix completion by Riemannian optimization. *SIAM Journal on Optimization*, 23(2), 1214–1236. https://doi.org/10.1137/110845768

[20] Dinkelbach, W. (1967). On Nonlinear Fractional Programming. *Management Science*, 13(7), 492–498. https://doi.org/10.1287/mnsc.13.7.492

[21] Charnes, A., and Cooper, W. W. (1962). Programming with linear fractional functionals. *Naval Research Logistics Quarterly*, 9(3–4), 181–186. https://doi.org/10.1002/nav.3800090303

[22] Kingma, D. P., and Ba, J. (2015). Adam: A Method for Stochastic Optimization. *ICLR 2015*. arXiv:1412.6980. https://arxiv.org/abs/1412.6980

[23] Hinton, G. (2022). The Forward-Forward Algorithm: Some Preliminary Investigations. arXiv:2212.13345. https://arxiv.org/abs/2212.13345

[24] Ghosh, Debi Prasad. (2026). *Log-Interval Networks: The Next Research Programme for the Interval Transformer*. Research agenda, 1 October 2026.

[25] Buja, A., Hastie, T., and Tibshirani, R. (1989). Linear Smoothers and Additive Models. *The Annals of Statistics*, 17(2), 453–510. https://doi.org/10.1214/aos/1176347115

[26] Edalati, A., Tahaei, M., Kobyzev, I., Nia, V. P., Clark, J. J., and Rezagholizadeh, M. (2022). KronA: Parameter Efficient Tuning with Kronecker Adapter. arXiv:2212.10650. https://arxiv.org/abs/2212.10650

# Appendix A. Reproduction

**Contents.** The supplement contains every script, the protocol, the frozen hashes, the theory checks and the post-review checks with their outputs, the per-run summaries (JSON) of all 270 runs, the evaluator's outputs, the logs, the tables, the figures and the quoted numbers. It omits:

- the data (MNIST and CIFAR-100, identified below by their MD5 sums);
- the saved stores (776 MB), which `p3_run.py` regenerates deterministically.

**Environment.** Python 3.11.15; NumPy 2.4.4, SciPy 1.17.1, Matplotlib 3.10.9; JAX 0.10.2 on CPU with one thread per process. Two CPU cores.

**Data.**

- **MNIST.** The four IDX files, MD5 `f68b3c2d…` (training images), `d53e105e…` (training labels), `9fb629c4…` (test images) and `ec29112d…` (test labels).
- **CIFAR-100.** The python archive supplied by the user: `train` `16019d7e…`, `test` `f0ef6b0a…` and `meta` `7973b151…`. These are the published values.

Both loaders check the sums before reading.

**Commands**, in order:

```
python3 verify_p3_theory.py > verify_p3_theory_output.txt   # T1-T10, 28 checks, about 15 seconds
python3 pilots/pilot_<name>.py ...                           # design pilots (validation data only)
python3 p3_run.py all                                        # 270 runs, training data only, about 50 minutes
python3 p3_eval.py mnist && python3 p3_eval.py cifar100      # frozen evaluator (test split), about 58 minutes
python3 p3_report.py                                         # report/summary.json, report/tables.md, figures/
python3 p3_facts.py > facts_output.txt                       # every number quoted in the paper
python3 p3_pub_wake_check.py > report/pub_wake_check.txt     # Section 5.1 diagnostic (training data only)
python3 verify_p3_addendum.py > verify_p3_addendum_output.txt # post-review checks A0-A9, about 2 minutes
```

**Frozen code.** Before the first confirmatory run and before any test example was read, the library, run script, evaluator, theory checks and protocol were hashed into `evals_code_sha256.txt`:

    17742815c2a90fee92632cfad00cec95d7fdb2af72aef8e10b637554f2ff6559  p3lib.py
    b82a2992a1cb0b4b93d3f2abdb583ced4d4ace25a172d97ddfeca5e4214e5597  p3_run.py
    272817c34b5dd625a09fb192a500c64039ce6701c938ecdaf7057458dd5d7b3f  p3_eval.py
    4ab8822b8c84b10389d5505de61c0e23bda31c670258ab913ba93673b45cb530  verify_p3_theory.py
    d59be4c93402599d8825b296b34e49701abb4f6d68cf2772e0b456204bfc99fd  PROTOCOL.md
    frozen 2026-10-05T04:21:17Z

None of these files changed afterwards. Every run records the hashes of `p3lib.py` and `p3_run.py` that produced it, and all 270 match. Four scripts were written later:

- `p3_report.py` and `p3_facts.py`, after the MNIST evaluation had finished and while CIFAR-100 was still running (the exploratory additions to `p3_facts.py` came after the review);
- `p3_pub_wake_check.py`, after the MNIST evaluation, while CIFAR-100 was being evaluated;
- `verify_p3_addendum.py`, after the review.

They read the evaluator's outputs, saved stores, and training or validation data. None of them reads the test split.

**Compute.** The confirmatory runs and their evaluation took about 1.8 CPU core-hours: the runs took 9 minutes on MNIST and 40 on CIFAR-100, and the evaluation 16 and 42 minutes. The design pilots and smoke tests took under an hour more.

# Appendix B. Per-seed results

**Final accuracy of the stored model (%)**, $R=8$, one sleep per task.

| Rule | MNIST s0 | s1 | s2 | s3 | s4 | CIFAR-100 s0 | s1 | s2 | s3 | s4 |
|---|---|---|---|---|---|---|---|---|---|---|
| no sleep | 83.4 | 84.2 | 84.2 | 82.5 | 82.4 | 7.1 | 7.0 | 7.7 | 7.8 | 7.5 |
| published, $\lvert C\rvert$, α = 1 | 15.7 | 10.0 | 12.5 | 18.2 | 11.6 | 1.0 | 0.9 | 1.0 | 1.0 | 1.0 |
| published, $\lvert C\rvert$, α = 0.1 | 16.9 | 15.6 | 13.9 | 16.7 | 20.2 | 1.2 | 1.0 | 1.4 | 1.0 | 1.3 |
| Eq. 13 | 8.9 | 10.5 | 13.2 | 14.0 | 11.6 | 1.1 | 1.0 | 1.0 | 1.0 | 1.1 |
| Eq. 14 | 11.2 | 28.9 | 26.2 | 31.7 | 10.6 | 1.7 | 2.1 | 1.9 | 2.4 | 2.3 |
| Eq. 14, first order | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| Eq. 14 + stored residual | 83.5 | 84.4 | 84.2 | 82.5 | 82.2 | 7.2 | 7.1 | 7.6 | 7.8 | 7.5 |
| tangent projection | 77.3 | 77.7 | 79.8 | 75.4 | 69.3 | 3.2 | 6.6 | 4.8 | 7.1 | 6.9 |
| Frobenius refit | 83.8 | 84.0 | 84.6 | 83.0 | 83.8 | 9.2 | 5.7 | 6.3 | 7.0 | 8.7 |

**Certified retention (%) at the final sleep, $\bar b=8$** (the registered comparisons).

| Policy | MNIST s0 | s1 | s2 | s3 | s4 | CIFAR-100 s0 | s1 | s2 | s3 | s4 |
|---|---|---|---|---|---|---|---|---|---|---|
| uniform | 80.8 | 82.4 | 81.1 | 79.6 | 80.9 | 25.4 | 27.7 | 26.5 | 33.9 | 23.5 |
| usage-and-age | 80.9 | 82.4 | 79.2 | 78.3 | 80.6 | 33.1 | 53.8 | 50.6 | 55.3 | 34.1 |
| certificate-guided | 82.6 | 83.5 | 83.0 | 81.7 | 83.7 | 46.7 | 84.5 | 79.7 | 74.6 | 53.8 |
| exposure control | 75.5 | 77.2 | 74.3 | 72.9 | 76.0 | 35.0 | 23.7 | 24.3 | 32.2 | 31.3 |
| cert − uniform | +1.8 | +1.1 | +2.0 | +2.1 | +2.7 | +21.3 | +56.8 | +53.2 | +40.6 | +30.3 |
| cert − usage-and-age | +1.6 | +1.1 | +3.8 | +3.4 | +3.0 | +13.5 | +30.7 | +29.1 | +19.3 | +19.7 |

**Bits per decision** (final sleep): Spearman correlation of the reference log margin with the bits at which a decision is lost (P3.3) and with the bits to certify it.

| Seed | MNIST, lost | MNIST, certify | CIFAR-100, lost | CIFAR-100, certify |
|---|---|---|---|---|
| 0 | −0.604 | −0.945 | −0.755 | −0.970 |
| 1 | −0.520 | −0.930 | −0.694 | −0.959 |
| 2 | −0.528 | −0.943 | −0.681 | −0.956 |
| 3 | −0.647 | −0.942 | −0.742 | −0.952 |
| 4 | −0.577 | −0.948 | −0.770 | −0.968 |

`report/tables.md` gives every budget, sleep, rule, rank and cadence, with the agreement, accuracy, certified accuracy, bits and times of each cell.

# Appendix C. Pilots and smoke tests

All pilots and smoke tests used training and validation data only. Their scripts and logs are in `pilots/` and `logs/`.

- **Capacity** (`pilot_capacity.py`). Joint training on MNIST at logit scale 16–32: the shared-channel store reached 86.0–87.1% at $R=1$ and 91.6–93.4% at $R=8$, against 95.0–96.4% for a dense positive layer. At logit scale 8, with 6 epochs instead of 12, the figures were 81.7%, 87.0% and 91.2%. This motivated $R=8$ as primary.
- **Wake** (`pilot_wake.py`, adapter rank 4, logit scale 16). The exact-memory stream with 20 protected examples per class and replay batch 64 ended at 72.7%. With 50 examples and batch 128 it ended at 83.9%.
- **Streams** (`pilot_stream.py`, `pilot_cadence.py`). These showed the pattern of Section 5 on validation data: the published rule collapses, the repairs absorb almost nothing at per-task cadence, and the refit keeps pace. The refit and tangent rules were added because of this pilot.
- **Precision** (`pilot_precision.py`). The policies at logit scale 16 and 8 on seed 0.
  - *Scale.* At 8 bits, uniform precision certified 78.3% of the final decisions at scale 8, against 69.8% at scale 16, at a reference accuracy of 82.6% against 84.7%.
  - *Budget.* At scale 8, 8 bits was the smallest budget at which uniform precision certified at least half of the final decisions.
- **Correction precision** (`pilot_stream.py`). The dense correction of the residual-preserving rule overflowed in float16 (`logs/pilot_stream_R8.log`), so corrections are stored in float32.
- **CIFAR** (`pilot_cifar.py`, `pilot_cifar100.py`). A CIFAR-10 stand-in was planned while CIFAR-100 was unreachable, and was replaced when the user supplied it. On CIFAR-100 the jointly trained working model reached 20.7% and the exact-memory stream about 7%.
- **Smoke tests** (`logs/smoke/`). These ran the full pipeline with validation data in place of test data, and caught two problems that were fixed before freezing.
  - *A starving greedy.* The lazy greedy of the certificate-guided policy left two CIFAR-100 classes at 1 bit. The stored model's decisions all fell on a starved class (agreement 0.0%). The exact greedy (Section 4.4) replaced it. This diagnosis was run interactively and its output was not saved. Check A5 reproduces it on the confirmatory store, where every validation decision became class 36. It uses the pre-freeze code, which A0 shows to be a verbatim copy of the source recovered from the session transcript (`logs/smoke/alloc_certificate_prefreeze.py`).
  - *Diverged stores.* The evaluator stopped on a diverged first-order store. Diverged stores are now counted as described in Section 4.3.
