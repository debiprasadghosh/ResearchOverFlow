# P3 protocol: sleep that knows what it keeps

Written on 5 October 2026 after design pilots and smoke tests that used training and validation data only, before any confirmatory run and before any test example was read. It executes Paper II, Section 6 (P3), and the P3 row of its Table 5. The predictions marked *agenda* are those of the research agenda (P3.1–P3.4) and are secondary. The run script `p3_run.py` reads training data only; the evaluator `p3_eval.py` alone reads the test split. The library, run script, evaluator and theory checks are frozen (SHA-256 in `evals_code_sha256.txt`) before the first test example is read.

## 1 Data and tasks

- **Split MNIST** (Paper II's first stage). MNIST with P1's split: 55,000 training, 5,000 validation and 10,000 test images (seed 20261004). Five class-incremental tasks, {0,1}, {2,3}, {4,5}, {6,7}, {8,9}, with one head over the classes seen so far and no task label at test time.
- **Split CIFAR-100** (Paper II's second stage). The CIFAR-100 site is refused by our network filter; the user supplied the official python archive (the MD5s of `train`, `test` and `meta` match the published ones). The first 45,000 training images train, the last 5,000 validate, and the 10,000 test images test. Ten class-incremental tasks of ten fine classes each in label order, {0,…,9}, {10,…,19}, …, {90,…,99}, one head over the classes seen so far. (An earlier draft of this protocol used split CIFAR-10 as a stand-in; it was replaced before any confirmatory run.)

## 2 Model

- **Features (fixed).** 16 random 5×5 filters (×3 input channels for CIFAR-100), zero mean and unit norm (seed 20261005), stride 2, the reflection pair [relu(+), relu(−)], and 2×2 average pooling. MNIST gives H ∈ R₊^{32×36} (channels × positions), CIFAR-100 H ∈ R₊^{32×49}. The features are never trained.
- **Store (long-term memory).** A positive Kronecker sum W = Σ_{r=1}^{R} A_r ⊗ b_r, with class-by-position factors A_r ∈ R₊^{C×P} (C = 10 or 100) and channel factors b_r ∈ R₊^{32}, held as logarithms. Score z_c = Σ_{p,h} W[c,p,h] H[h,p]; prediction argmax over seen classes. Primary R = 8; secondary R = 1, the literal W₁ ⊗ W₂ of Paper II. Initial store: log A ~ log(1/(PR)) + 0.5 N(0,1), log b ~ log(1/32) + 0.5 N(0,1) (seeded); it holds no knowledge before the first sleep.
- **Wake (short-term memory).** A real Kronecker adapter ΔW = Σ_{j=1}^{8} U_j ⊗ V_j (U_j ∈ R^{C×P}, V_j ∈ R^{32}; U starts at 0, V at N(0,1/32)), trained by Adam (lr 0.01) for 3 epochs over the current task, in batches of 128 current examples plus 128 draws from the protected examples. Training logits 8·log z over seen classes (P1's scale). The working weight is W_work = max(W + C + ΔW, 0.05·W) entrywise, where C is a retained correction (rules none and resid). The store is a single layer on fixed features.
- **Protected examples.** When a class's task ends, training examples of that class are drawn uniformly at random (seed 1000 + seed): 50 per class on MNIST, 20 per class on CIFAR-100. They are replayed in later wakes and are the certificate policy's evidence. They are stored at 8 bits per pixel and charged to every condition alike.
- **Seeds** 0–4.

## 3 Sleep rules (Paper II §§6.1–6.2)

Each wake is followed by one sleep (per-task cadence, primary).

| Rule | Definition |
|---|---|
| none | no consolidation; the working weight is kept as a dense float32 correction |
| pub | the published rule [LTM]: unit-norm nearest-Kronecker factors (C₁, C₂) of ΔW, log A_r += α log C₁, log b_r += α log C₂. Recorded as undefined where C₁ or C₂ ≤ 0 (better sign); run with the named surrogate \|C\| (clamped at 10⁻³⁰) at α = 1 |
| pub01 | the same surrogate at α = 0.1 |
| gain_ord | Paper II Eq. 13: ordinary block means of D = log(W_work ⊘ W) on the (C·P)×32 rearrangement; every term's factors updated by the same gain |
| gain_w | Paper II Eq. 14: block means weighted by W², exact log D |
| gain_w1 | Eq. 14 on the first-order target D₁ = (W_work − W) ⊘ W |
| resid | gain_w, with the residual W_work − W_new kept as a dense float32 correction (residual-preserving control) |
| tan | (ours) the Frobenius projection of W_work − W onto the full tangent space {Σ_r E_r ⊗ b_r + A_r ⊗ f_r}, applied additively to the factors with the floor |
| refit | (ours) Paper II's "larger positive representation fitted to the full target": the rank-R store refitted to W_work in Frobenius norm by 300 Adam steps (lr 0.05) on the log factors, from the current store |

**Secondary cadence.** gain_ord, gain_w, gain_w1, tan and refit also sleep every 10 wake steps (R = 8), each sleep consolidating the adapter trained since the last.

**Pilot decisions (validation only).** R = 8 (on split MNIST the rank-1 store reached 86–87% even when trained jointly, R = 8 reached 92–93%); adapter rank 8, 50 protected examples per class and replay batch 128 on MNIST (the exact-memory stream reached 84% instead of 73% with 20 examples and replay 64); 20 per class on CIFAR-100 (2,000 at the end of the stream); logit scale 8 (larger log margins at equal accuracy); floor 0.05. In the pilots the repaired rules kept almost none of a learned adapter at per-task cadence, which is why refit and tan were added and why the precision study uses the refit store. With fixed random features the CIFAR-100 model is weak (jointly trained working model about 21% on 100 classes; the exact-memory stream about 7% after ten tasks); CIFAR-100 tests consolidation and storage of what such a model knows, not image recognition.

## 4 Outcomes

At each sleep, on the test examples of the seen classes:

- accuracy of the working model just before sleep and of the stored model after it; **fidelity**, their agreement;
- **certified fidelity**: the working model's decision is certified to be the stored model's when every residual with the stored per-class norms ε_c = ‖(W_stored − W_work)_c‖_F (rounded up to float16) leaves it unchanged (Proposition 6); and the same with the r ∈ {1, 2, 4, 8, 16} leading Kronecker terms of the residual kept in float16, with their bits;
- relative residual ‖W_stored − W_work‖/‖W_work − W_base‖; the fractions of the change in the separable-gain space S_W and in the tangent space T_W; the largest relative change max|ΔW/W|; the undefined fraction of the published rule; stored bits;
- at the end of the stream, accuracy on each task's classes and on all classes.

A store with a non-finite weight has **diverged**: its decisions are undefined and counted as errors (never as agreement), and the residual analyses are not computed. Weights that underflow to zero (possible under the published surrogate) are reported as a fraction; the S_W/T_W fractions are then not computed.

## 5 Precision study (registered primary; Paper II §6.3 and §9)

At each sleep of the R = 8 refit runs (CIFAR-100: at the sleeps ending tasks 5 and 10, for cost), the full-precision store (the **reference**) is stored at reduced precision.

- **Units.** One grid per seen class (its R·P log-weights) and one per channel vector b_r (32 log-weights). A unit with b bits stores 2^b levels between float16 endpoints rounded outward, so every reference log-weight lies within half a step of its stored value (Proposition 5).
- **Equal total bits.** Budget = b̄ bits per stored log-weight plus 36 bits of metadata per unit (two float16 endpoints and a 4-bit width). Usage-and-age also pays 16 bits per unit for its counters. Protected examples are common to all policies.
- **Policies.**
  - *uniform*: b̄ bits everywhere;
  - *usage-and-age* [LTM §4.4]: bits follow log₂ of the decayed use count (decay 0.5 per task) by water-filling; a channel vector's use is the sum over classes;
  - *certificate-guided*: for each common width s ∈ {1,…,16} of the channel vectors, the shared-box margins of the protected examples are computed once (the exact threshold rule for each example's 8 nearest competitors, the sound bound "log ratio − 2 max σ" for the rest); the class units start at 1 bit and receive the remaining budget one bit at a time, each step giving the bit to the class with the largest exact gain in (number of certified protected examples + 10⁻³ × total slack of the uncertified ones) per bit (ties, including all-zero gains, to the class with the fewest bits, then the lowest index); the best s is kept. All gains are re-evaluated at every step. (A lazy greedy with stale gains starved two never-decided classes at 1 bit in the CIFAR-100 smoke test on validation data; it was replaced before freezing, and a regression check is in the theory checks.)
  - *exposure-aware control* (ours): channel vectors at 16 bits, class units uniform with the rest.
- **Budgets** b̄ ∈ {4, 6, 8, 10, 12}; **primary b̄ = 8**, chosen in the pilot as the smallest budget at which the uniform store certified at least half of the final decisions.
- **Outcomes.** **Certified retention**: the fraction of test decisions certified for every member of the stored box, by the exact test of Proposition 4 (such a decision equals the reference decision). Also agreement with the reference (retention), accuracy and certified accuracy, the same on the classes of earlier tasks, and allocation and certification times.
- **Bits per decision** (final sleep): the smallest uniform width that certifies each test decision (a decision not certified at 16 bits ranks above 16), the smallest width from which the stored decision always equals the reference, and the reference log margin.
- **Dynamic arm (secondary).** The R = 8 refit stream with storage at b̄ = 8 in the loop, for each policy: each sleep's store is replaced by its stored values before the next wake. Outcomes: final accuracy, agreement with the full-precision refit run of the same seed, certified retention of the final stored box.

## 6 Registered criteria

- **Primary (Paper II).** Certificate-guided precision retains more than both uniform and usage-and-age precision at equal total bits: seed-paired differences in certified retention at the final sleep (all ten classes) at b̄ = 8 on split MNIST, with 95% t-intervals above zero for both comparisons. Otherwise Paper II's rejection applies: no retention advantage at equal total bits. Measured cost (allocation and certification time) is reported beside it.
- **Second stage (Paper II).** The same test on split CIFAR-100 at the final sleep (all 100 classes), judged on its own. The paper states on which stage the claim holds.
- **Retention claims (Paper II).** A claim that sleep or storage retained a decision is accepted only when certified: the stored box contains the reference parameters (Proposition 5), or a functional residual bound covers the change (Proposition 6). Agreement without a certificate is reported as uncertified retention.
- **The published rule (Paper II).** Recorded as undefined where it is undefined; the \|C\| surrogate is reported separately.
- **Repair without a theorem (Paper II).** "Repair alone has no theorem guaranteeing performance at least as good as no sleep." Tested as P3.2 below.
- **Agenda predictions (secondary).** P3.1: the published rule (surrogate, α = 1) has the lowest final accuracy on the pooled test examples of the earlier tasks (all but the last) among all rules, seed means, R = 8, per-task cadence, split MNIST (CIFAR-100 reported beside it). P3.2: gain_w retains at least as much as no sleep (final accuracy on all classes; rejected if the seed-paired 95% interval lies below zero). P3.3, in the agenda's words "the bits at which a decision is lost follow its log-margin (Spearman ≤ −0.7)": the Spearman correlation between a test decision's reference log margin and the bits at which it is lost (b_keep − 1, the largest uniform width at which the stored decision differs from the reference; 0 if it never does) is at most −0.7 at the final sleep of split MNIST, in every seed. The width at which a decision becomes certified (b_cert) is reported beside it; for it the relation is close to built in (Proposition 4), so it is not the test. P3.4: the primary comparison against usage-and-age.
- **Statistics.** Seed means with 95% t-intervals (t₀.₉₇₅,₄ = 2.776) and seed-paired differences.

## 7 Exploratory analyses (labelled as such)

Anything decided after the confirmatory results are seen, including any further rule, budget or policy, is reported as exploratory.
