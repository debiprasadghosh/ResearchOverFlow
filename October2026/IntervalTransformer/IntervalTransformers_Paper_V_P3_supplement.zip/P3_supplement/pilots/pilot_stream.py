"""Design pilot (validation data only): class-incremental split MNIST with wake adapters and each sleep rule.
Usage: python3 pilot_stream.py <R> <scale> <k> <epochs> <lr> <floor> <rules,comma> [seed] [dataset]"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import sys
import time
import numpy as np
import p3lib as L

R, scale, k, epochs, lr, floor = int(sys.argv[1]), float(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), float(sys.argv[5]), float(sys.argv[6])
rules = sys.argv[7].split(",")
seed = int(sys.argv[8]) if len(sys.argv) > 8 else 0
dataset = sys.argv[9] if len(sys.argv) > 9 else "mnist"
D = L.load_mnist() if dataset == "mnist" else L.load_cifar10()
F = L.features(D)
Htr, ytr, Hva, yva = F["Htr"], F["ytr"], F["Hva"], F["yva"]
C, Ch, P = 10, Htr.shape[1], Htr.shape[2]
print(f"R={R} scale={scale} k={k} epochs={epochs} lr={lr} floor={floor} seed={seed} {dataset} features {Htr.shape}", flush=True)

for rule in rules:
    t0 = time.time()
    store = L.init_store(R, C, P, Ch, seed)
    rng = np.random.default_rng(1000 + seed)
    rep_H, rep_y = [], []
    seen = []
    line = []
    for t, cls in enumerate(L.TASKS):
        seen = seen + list(cls)
        sel = np.isin(ytr, cls)
        Hrep = np.concatenate(rep_H) if rep_H else None
        yrep = np.concatenate(rep_y) if rep_y else None
        ad = L.wake(store, Htr[sel], ytr[sel], Hrep, yrep, seen, k, scale, floor, lr, epochs, seed * 100 + t)
        vsel = np.isin(yva, seen)
        Ww = L.working_dense(store, ad, floor)
        pw, _ = L.predict(Ww, Hva[vsel], seen)
        alpha = 0.1 if rule == "pub01" else 1.0
        store, info = L.sleep("pub" if rule.startswith("pub") else rule, store, ad, floor, alpha=alpha)
        ps, _ = L.predict(L.effective(store), Hva[vsel], seen)
        acc_w = np.mean(pw == yva[vsel])
        acc_s = np.mean(ps == yva[vsel])
        agree = np.mean(ps == pw)
        line.append(f"t{t}: wake {100*acc_w:.1f} sleep {100*acc_s:.1f} agree {100*agree:.1f} res {info['rel_residual']:.3f}"
                    + (f" tan {info['tangent_frac']:.3f}" if "tangent_frac" in info else "")
                    + (f" undef {info['undefined_base_frac']:.3f}" if "undefined_base_frac" in info else "")
                    + f" floor {info['floor_frac']:.3f}")
        for c in cls:
            idx = np.nonzero(ytr == c)[0]
            pick = rng.choice(idx, 20, replace=False)
            rep_H.append(Htr[pick])
            rep_y.append(ytr[pick])
    print(f"== {rule} ({time.time() - t0:.0f}s)\n  " + "\n  ".join(line), flush=True)
