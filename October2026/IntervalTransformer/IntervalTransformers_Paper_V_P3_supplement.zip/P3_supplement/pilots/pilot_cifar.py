import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__)))); os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np, p3lib as L
D = L.load_cifar10(); F = L.features(D)
Htr, ytr, Hva, yva = F["Htr"], F["ytr"], F["Hva"], F["yva"]
print('features', Htr.shape, flush=True)
C, Ch, P = 10, Htr.shape[1], Htr.shape[2]
def run(rule, R=8, k=8, lr=0.01, epochs=3, nrep=50, scale=8.0, floor=0.05, seed=0, rep_batch=128):
    store = L.init_store(R, C, P, Ch, seed); rng = np.random.default_rng(1000 + seed)
    rep_H, rep_y, seen, accs = [], [], [], []
    t0=time.time()
    for t, cls in enumerate(L.TASKS):
        seen = seen + list(cls); sel = np.isin(ytr, cls)
        Hrep = np.concatenate(rep_H) if rep_H else None; yrep = np.concatenate(rep_y) if rep_y else None
        ad = L.wake(store, Htr[sel], ytr[sel], Hrep, yrep, seen, k, scale, floor, lr, epochs, seed*100+t, rep_batch=rep_batch)
        vsel = np.isin(yva, seen)
        pw,_ = L.predict(L.working_dense(store, ad, floor), Hva[vsel], seen)
        store, info = L.sleep(rule, store, ad, floor)
        ps,_ = L.predict(L.effective(store), Hva[vsel], seen)
        accs.append((np.mean(pw==yva[vsel]), np.mean(ps==yva[vsel])))
        for c in cls:
            idx = np.nonzero(ytr == c)[0]; pick = rng.choice(idx, nrep, replace=False)
            rep_H.append(Htr[pick]); rep_y.append(ytr[pick])
    print(f"{rule} scale={scale} ep={epochs} lr={lr}: " + " ".join(f"{100*a:.1f}/{100*b:.1f}" for a,b in accs) + f"  ({time.time()-t0:.0f}s)", flush=True)
for rule in ['none','refit','gain_w','tan']:
    run(rule)
run('none', epochs=6); run('refit', epochs=6)
