"""Design pilot (validation only): CIFAR-100 capacity (joint training) and the class-incremental stream.
Usage: python3 pilots/pilot_cifar100.py <n_filters> <R list> <mode: joint|stream> [nrep]"""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import jax, jax.numpy as jnp
import p3lib as L
nf = int(sys.argv[1]); Rs = [int(x) for x in sys.argv[2].split(",")]; mode = sys.argv[3]
nrep = int(sys.argv[4]) if len(sys.argv) > 4 else 20
D = L.load_cifar100(); F = L.features(D, nf)
Htr, ytr, Hva, yva = F["Htr"], F["ytr"], F["Hva"], F["yva"]
C, Ch, P = 100, Htr.shape[1], Htr.shape[2]
print("features", Htr.shape, flush=True)
if mode == "joint":
    for R in Rs:
        store = L.init_store(R, C, P, Ch, 0)
        ad = L.wake(store, Htr, ytr, None, None, list(range(C)), 16, 8.0, 0.05, 0.01, 6, 0)
        p, _ = L.predict(L.working_dense(store, ad, 0.05), Hva, list(range(C)))
        new, info = L.sleep("refit", store, ad, 0.05)
        p2, _ = L.predict(L.effective(new), Hva, list(range(C)))
        print(f"joint R={R}: working {100*np.mean(p==yva):.2f} refit store {100*np.mean(p2==yva):.2f}", flush=True)
else:
    tasks = L.DATASETS["cifar100"]["tasks"]
    for R in Rs:
        for rule in ("none", "refit", "gain_w"):
            t0 = time.time()
            store = L.init_store(R, C, P, Ch, 0); rng = np.random.default_rng(1000)
            rep_H, rep_y, seen, accs = [], [], [], []
            for t, cls in enumerate(tasks):
                seen = seen + list(cls); sel = np.isin(ytr, cls)
                Hrep = np.concatenate(rep_H) if rep_H else None; yrep = np.concatenate(rep_y) if rep_y else None
                ad = L.wake(store, Htr[sel], ytr[sel], Hrep, yrep, seen, 8, 8.0, 0.05, 0.01, 3, t, rep_batch=128)
                vsel = np.isin(yva, seen)
                pw, _ = L.predict(L.working_dense(store, ad, 0.05), Hva[vsel], seen)
                store, info = L.sleep(rule, store, ad, 0.05)
                ps, _ = L.predict(L.effective(store), Hva[vsel], seen)
                accs.append((np.mean(pw == yva[vsel]), np.mean(ps == yva[vsel])))
                for c in cls:
                    idx = np.nonzero(ytr == c)[0]; pick = rng.choice(idx, nrep, replace=False)
                    rep_H.append(Htr[pick]); rep_y.append(ytr[pick])
            print(f"R={R} {rule} nrep={nrep}: " + " ".join(f"{100*a:.1f}/{100*b:.1f}" for a, b in accs) + f" ({time.time()-t0:.0f}s)", flush=True)
