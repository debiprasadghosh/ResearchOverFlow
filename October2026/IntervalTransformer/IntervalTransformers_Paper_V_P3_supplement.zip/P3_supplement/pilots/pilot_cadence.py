"""Design pilot (validation only): sleep cadence.  Sleep every `cadence` wake steps within each task.
Usage: python3 pilot_cadence.py <R> <cadence> <rules> [seed] [epochs] [nrep]"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import sys, time
import numpy as np
import p3lib as L
R, cadence, rules = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3].split(",")
seed = int(sys.argv[4]) if len(sys.argv) > 4 else 0
epochs = int(sys.argv[5]) if len(sys.argv) > 5 else 3
nrep = int(sys.argv[6]) if len(sys.argv) > 6 else 20
scale, k, lr, floor = 8.0, 8, 0.01, 0.05
D = L.load_mnist(); F = L.features(D)
Htr, ytr, Hva, yva = F["Htr"], F["ytr"], F["Hva"], F["yva"]
C, Ch, P = 10, Htr.shape[1], Htr.shape[2]
print(f"R={R} cadence={cadence} epochs={epochs} nrep={nrep}", flush=True)
for rule in rules:
    t0 = time.time()
    store = L.init_store(R, C, P, Ch, seed)
    rng = np.random.default_rng(1000 + seed)
    rep_H, rep_y, seen, line = [], [], [], []
    for t, cls in enumerate(L.TASKS):
        seen = seen + list(cls)
        sel = np.isin(ytr, cls)
        Hrep = np.concatenate(rep_H) if rep_H else None
        yrep = np.concatenate(rep_y) if rep_y else None
        store, ad, infos = L.wake(store, Htr[sel], ytr[sel], Hrep, yrep, seen, k, scale, floor, lr, epochs, seed * 100 + t, rep_batch=128,
                                  cadence=cadence, rule=rule)
        vsel = np.isin(yva, seen)
        pw, _ = L.predict(L.working_dense(store, ad, floor), Hva[vsel], seen)
        store, info = L.sleep(rule, store, ad, floor)
        ps, _ = L.predict(L.effective(store), Hva[vsel], seen)
        res = [x["rel_residual"] for x in infos] + [info["rel_residual"]]
        line.append(f"t{t}: wake {100*np.mean(pw==yva[vsel]):.1f} sleep {100*np.mean(ps==yva[vsel]):.1f} agree {100*np.mean(ps==pw):.1f} "
                    f"sleeps {len(res)} res median {np.median(res):.3f} max {np.max(res):.3f}")
        for c in cls:
            idx = np.nonzero(ytr == c)[0]
            pick = rng.choice(idx, nrep, replace=False)
            rep_H.append(Htr[pick]); rep_y.append(ytr[pick])
    print(f"== {rule} ({time.time()-t0:.0f}s)\n  " + "\n  ".join(line), flush=True)
