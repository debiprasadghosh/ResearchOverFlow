"""Design pilot (validation only): precision policies on the refit store along the stream.
Usage: python3 pilot_precision.py <seed> <budgets comma> [dataset]"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import sys, time
import numpy as np
import p3lib as L
seed = int(sys.argv[1]); budgets = [float(x) for x in sys.argv[2].split(",")]
SCALE_ARG = float(sys.argv[4]) if len(sys.argv) > 4 else 16.0
dataset = sys.argv[3] if len(sys.argv) > 3 else "mnist"
R, k, scale, lr, floor, epochs, nrep, rep_batch = 8, 8, SCALE_ARG, 0.01, 0.05, 3, 50, 128
D = L.load_mnist() if dataset == "mnist" else L.load_cifar10()
F = L.features(D)
Htr, ytr, Hva, yva = F["Htr"], F["ytr"], F["Hva"], F["yva"]
C, Ch, P = 10, Htr.shape[1], Htr.shape[2]
store = L.init_store(R, C, P, Ch, seed); rng = np.random.default_rng(1000 + seed)
rep_H, rep_y, seen = [], [], []
use = np.zeros((len(L.TASKS), C))
for t, cls in enumerate(L.TASKS):
    seen = seen + list(cls); sel = np.isin(ytr, cls)
    Hrep = np.concatenate(rep_H) if rep_H else None; yrep = np.concatenate(rep_y) if rep_y else None
    ad = L.wake(store, Htr[sel], ytr[sel], Hrep, yrep, seen, k, scale, floor, lr, epochs, seed * 100 + t, rep_batch=rep_batch)
    steps = epochs * (sel.sum() // 128)
    for c in cls:
        use[t, c] += epochs * (ytr[sel] == c).sum()
    if Hrep is not None:
        for c in np.unique(yrep):
            use[t, c] += steps * rep_batch * np.mean(yrep == c)
    store, info = L.sleep("refit", store, ad, floor)
    for c in cls:
        idx = np.nonzero(ytr == c)[0]; pick = rng.choice(idx, nrep, replace=False)
        rep_H.append(Htr[pick]); rep_y.append(ytr[pick])
    Hprot, yprot = np.concatenate(rep_H), np.concatenate(rep_y)
    la, lb = store["la"], store["lb"]
    vsel = np.isin(yva, seen); Hv, yv = Hva[vsel], yva[vsel]
    ref, _ = L.predict(L.dense(la, lb), Hv, seen)
    decayed = sum(0.5 ** (t - kk) * use[kk] for kk in range(t + 1))
    usage = {("class", c): decayed[c] for c in range(C)}
    usage.update({("shared", r): decayed.sum() for r in range(R)})
    sizes = L.unit_sizes(la, lb); nunits = len(sizes)
    print(f"-- task {t} seen {seen} ref acc {100*np.mean(ref==yv):.2f}", flush=True)
    for bbar in budgets:
        out = []
        for pol in ("uniform", "usage", "cert"):
            t0 = time.time()
            Wbits = int(bbar * sum(sizes.values()))
            if pol == "uniform":
                bits = L.alloc_uniform(la, lb, bbar)
            elif pol == "usage":
                bits = L.alloc_usage(la, lb, Wbits - nunits * L.USAGE_BITS, usage)
            else:
                bits = L.alloc_certificate(la, lb, Wbits, Hprot, seen)
            la_q, lb_q, rho, sigma = L.quantize_store(la, lb, bits)
            top, cert = L.certify(la_q, lb_q, rho, sigma, Hv, seen)
            agree = np.mean(top == ref); acc = np.mean(top == yv)
            out.append(f"{pol} cert {100*np.mean(cert):.1f} agree {100*agree:.1f} acc {100*acc:.1f} wb {L.weight_bits(bits, sizes)} ({time.time()-t0:.0f}s)")
        print(f"  b={bbar}: " + " | ".join(out), flush=True)
