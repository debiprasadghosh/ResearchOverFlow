"""Design pilot (validation data only): capacity of candidate positive Kronecker readouts on fixed random
convolutional features of MNIST, trained jointly on all ten classes.  Not part of the registered study."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import os
os.environ.setdefault("XLA_FLAGS", "--xla_cpu_multi_thread_eigen=false intra_op_parallelism_threads=1")
import sys
import time
import gzip
import numpy as np
import jax
import jax.numpy as jnp

rng0 = np.random.default_rng(20261005)


def idx_images(p):
    raw = gzip.open(p, "rb").read()
    n, r, c = (int.from_bytes(raw[i:i + 4], "big") for i in (4, 8, 12))
    return np.frombuffer(raw, np.uint8, offset=16).reshape(n, r, c)


def idx_labels(p):
    return np.frombuffer(gzip.open(p, "rb").read(), np.uint8, offset=8).astype(np.int64)


X = idx_images("data/train-images-idx3-ubyte.gz").astype(np.float32) / 255
y = idx_labels("data/train-labels-idx1-ubyte.gz")
perm = np.random.default_rng(20261004).permutation(60000)
tr, va = np.sort(perm[:55000]), np.sort(perm[55000:])


def conv_features(X, filt, stride=2, pool=2):
    n = X.shape[0]
    k = int(np.sqrt(filt.shape[0]))
    out = (X.shape[1] - k) // stride + 1
    s = X.strides
    P = np.lib.stride_tricks.as_strided(X, (n, out, out, k, k), (s[0], s[1] * stride, s[2] * stride, s[1], s[2]))
    Z = P.reshape(n, out, out, k * k) @ filt                     # (n, out, out, F)
    Z = np.concatenate([np.maximum(Z, 0), np.maximum(-Z, 0)], axis=-1)
    if pool > 1:
        o2 = out // pool
        Z = Z[:, :o2 * pool, :o2 * pool].reshape(n, o2, pool, o2, pool, -1).mean(axis=(2, 4))
    n_, a, b, ch = Z.shape
    return Z.reshape(n_, a * b, ch).transpose(0, 2, 1).astype(np.float32)   # (n, channels, positions)


F = int(sys.argv[1]) if len(sys.argv) > 1 else 16
pool = int(sys.argv[2]) if len(sys.argv) > 2 else 2
CSCALE = float(sys.argv[3]) if len(sys.argv) > 3 else 8.0
EPOCHS = int(sys.argv[4]) if len(sys.argv) > 4 else 6
LR = float(sys.argv[5]) if len(sys.argv) > 5 else 3e-3
filt = rng0.standard_normal((25, F)).astype(np.float32)
filt -= filt.mean(axis=0, keepdims=True)
filt /= np.linalg.norm(filt, axis=0, keepdims=True)
t0 = time.time()
H = np.concatenate([conv_features(X[i:i + 5000], filt, 2, pool) for i in range(0, 60000, 5000)])
Ch, Pos = H.shape[1], H.shape[2]
print(f"features {H.shape} in {time.time() - t0:.1f}s, mean {H.mean():.3f}", flush=True)
Htr, ytr, Hva, yva = H[tr], y[tr], H[va], y[va]
C = 10


def init(kind, R, key):
    k1, k2 = jax.random.split(key)
    if kind == "dense":
        return {"T": jnp.log(1.0 / (Ch * Pos)) + 0.1 * jax.random.normal(k1, (C, Ch * Pos))}
    if kind == "signed":
        return {"V": 0.01 * jax.random.normal(k1, (C, Ch * Pos)), "d": jnp.zeros(C)}
    if kind == "perclass":
        return {"a": jnp.log(1.0 / Ch) + 0.1 * jax.random.normal(k1, (C, R, Ch)),
                "b": jnp.log(1.0 / (Pos * R)) + 0.1 * jax.random.normal(k2, (C, R, Pos))}
    if kind == "shared":
        return {"W1": jnp.log(1.0 / (Pos * R)) + 0.1 * jax.random.normal(k1, (R, C, Pos)),
                "w2": jnp.log(1.0 / Ch) + 0.1 * jax.random.normal(k2, (R, Ch))}


def scores(kind, p, Hb):
    if kind == "dense":
        return Hb.reshape(Hb.shape[0], -1) @ jnp.exp(p["T"]).T
    if kind == "perclass":
        T = jnp.einsum("nkp,crp->ncrk", Hb, jnp.exp(p["b"]))
        return jnp.einsum("ncrk,crk->nc", T, jnp.exp(p["a"]))
    if kind == "shared":
        G = jnp.einsum("nkp,rk->nrp", Hb, jnp.exp(p["w2"]))
        return jnp.einsum("nrp,rcp->nc", G, jnp.exp(p["W1"]))


def logits(kind, p, Hb):
    if kind == "signed":
        return Hb.reshape(Hb.shape[0], -1) @ p["V"].T + p["d"]
    return CSCALE * jnp.log(scores(kind, p, Hb))


def run(kind, R=1, epochs=None, lr=None, seed=0):
    epochs = epochs or EPOCHS
    lr = lr or LR
    p = init(kind, R, jax.random.PRNGKey(seed))
    m = jax.tree_util.tree_map(jnp.zeros_like, p)
    v = jax.tree_util.tree_map(jnp.zeros_like, p)

    def loss(p, Hb, yb):
        L = logits(kind, p, Hb)
        return -jnp.mean(jax.nn.log_softmax(L)[jnp.arange(Hb.shape[0]), yb])

    @jax.jit
    def step(p, m, v, t, Hb, yb):
        l, g = jax.value_and_grad(loss)(p, Hb, yb)
        m = jax.tree_util.tree_map(lambda a, b: 0.9 * a + 0.1 * b, m, g)
        v = jax.tree_util.tree_map(lambda a, b: 0.999 * a + 0.001 * b * b, v, g)
        p = jax.tree_util.tree_map(lambda a, b, c: a - lr * (b / (1 - 0.9 ** t)) / (jnp.sqrt(c / (1 - 0.999 ** t)) + 1e-8), p, m, v)
        return p, m, v, l

    pred = jax.jit(lambda p, Hb: jnp.argmax(logits(kind, p, Hb), axis=1))
    r = np.random.default_rng(seed)
    t = 0
    t0 = time.time()
    for ep in range(epochs):
        idx = r.permutation(len(Htr))
        for i in range(0, len(idx) - 127, 128):
            t += 1
            b = idx[i:i + 128]
            p, m, v, l = step(p, m, v, t, jnp.asarray(Htr[b]), jnp.asarray(ytr[b]))
    acc = np.mean(np.concatenate([np.asarray(pred(p, jnp.asarray(Hva[i:i + 1000]))) for i in range(0, 5000, 1000)]) == yva)
    npar = sum(int(np.prod(x.shape)) for x in jax.tree_util.tree_leaves(p))
    print(f"{kind:8s} R={R} params {npar:6d}  val acc {100 * acc:.2f}  ({time.time() - t0:.0f}s)", flush=True)


KINDS = [tuple([k.split(":")[0], int(k.split(":")[1])]) for k in sys.argv[6].split(",")] if len(sys.argv) > 6 else [("signed", 1), ("dense", 1), ("perclass", 1), ("perclass", 4), ("shared", 1), ("shared", 8)]
print("c", CSCALE, "epochs", EPOCHS, "lr", LR, flush=True)
for kind, R in KINDS:
    run(kind, R)
