"""Addendum to the theory checks, written AFTER the confirmatory results and the independent review (exploratory;
not part of the frozen code).  The review found that T7, T8 and T10 of verify_p3_theory.py check less than the
paper's first draft said:
  T7  enumerates every shared vertex but moves each class unit only as a whole (both corners), and tests
      shared_margins, not certify;
  T8  samples box members uniformly, which never comes near the worst corner, so it cannot detect an unsound
      certificate;
  T10 "a never-decided class is not starved" is fragile: on fresh draws of its construction the exact greedy itself
      can leave the class at 1 bit (A8), although at T10's own random state it does catch the lazy greedy.
This script adds direct checks.  It reads training and validation data and saved stores only, never the test
split, and changes nothing in the frozen files.

  A1  certify (pruning, early exit) equals the pairwise exact test on random stores of the experiment's shapes
  A2  the explicit worst member of the box (class rows at their corners, shared entries at the threshold vertex)
      flips or ties every uncertified decision and none of the certified ones (soundness and tightness)
  A3  per-entry brute force over every vertex of the full box (each class log-weight and each shared log-weight
      moving independently) equals the Proposition 4 value at small sizes
  A4  power: with the radii halved, certify certifies decisions that the worst member flips (A2 detects it);
      uniform sampling of box members, as in T8, detects none
  A5  the smoke-test failure, reproduced on the confirmatory CIFAR-100 refit store (seed 0, sleep 5) with the
      protected training examples and VALIDATION decisions: the lazy greedy (the pre-freeze implementation,
      copied below) against the exact greedy of p3lib
  A6  (measurement, no pass/fail) protected training examples and test decisions certified by the uniform and
      certificate-guided policies at the first and the last MNIST sleep; the test fractions are read from the
      evaluator's outputs.  The first draft claimed that at the first sleep every protected example was
      certified; this measurement shows 98-100%, so that explanation was withdrawn
  A0  the lazy greedy below is the pre-freeze code: it equals logs/smoke/alloc_certificate_prefreeze.py (extracted
      from the session transcript) apart from its docstring, the module prefix and the import line
  A8  frozen check T10 run with the pre-freeze lazy greedy in place of the exact one (does T10 detect it?), and the
      fragility of T10's construction over fresh random draws (measurement)
  A9  (measurement, validation decisions) the shared-width tie rule: alloc_certificate keeps the FIRST best shared
      width, i.e. the smallest among ties; at sleeps where the protected objective saturates this stores the
      channel vectors coarsely.  Certified fractions with the frozen rule, with ties broken toward the largest
      width (the same function with shared_levels reversed), and with uniform precision

Usage: python3 verify_p3_addendum.py > verify_p3_addendum_output.txt
"""
import os
import sys
import json
import heapq
import itertools
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
os.chdir(HERE)
import p3lib as L          # noqa: E402
import p3_run as Rn        # noqa: E402
import p3_eval as E        # noqa: E402

rng = np.random.default_rng(20261007)
FAILS = []


def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  ({detail})" if detail else ""))
    if not ok:
        FAILS.append(name)


def header(t):
    print("\n" + "=" * 100 + f"\n{t}\n" + "=" * 100, flush=True)


def rand_store(R, C, P, Ch, s=0.6):
    return rng.normal(np.log(1 / (P * R)), s, (R, C, P)), rng.normal(np.log(1 / Ch), s, (R, Ch))


def worst_member(la_q, lb_q, rho, sigma, H, t, c):
    """The explicit worst member of the box for the pair (t, c): class rows of c at +rho_c, of t at -rho_t, and the
    shared entries at the best threshold vertex of sum(beta s) / sum(alpha s).  Returns (la, lb)."""
    R, C, P = la_q.shape
    Ch = lb_q.shape[1]
    g = L.term_contributions(la_q, lb_q, H[None])[0]           # (C, R, Ch)
    a, b = g[t].reshape(-1), g[c].reshape(-1)
    lo = np.repeat(np.exp(-sigma), Ch)
    hi = np.repeat(np.exp(sigma), Ch)
    with np.errstate(divide="ignore", invalid="ignore"):
        key = np.where(a > 0, b / np.where(a > 0, a, 1.0), np.where(b > 0, np.inf, -np.inf))
    order = np.argsort(-key)
    best, best_s = -np.inf, None
    for k in range(len(order) + 1):
        s = lo.copy()
        s[order[:k]] = hi[order[:k]]
        val = (b @ s) / (a @ s)
        if val > best:
            best, best_s = val, s
    la = la_q.copy()
    la[:, c, :] += rho[c]
    la[:, t, :] -= rho[t]
    lb = lb_q + np.log(best_s).reshape(R, Ch)
    return la, lb


def decision(la, lb, H, seen):
    z = L.term_contributions(la, lb, H[None])[0].sum(axis=(1, 2))
    return z


# -------------------------------------------------------------------------------------------------------------
header("A1  certify equals the pairwise exact test (random stores, shapes of the experiment)")
mism, total = 0, 0
for trial in range(40):
    R = int(rng.choice([1, 2, 4, 8]))
    C = int(rng.integers(3, 12))
    P, Ch = int(rng.choice([9, 36])), 32
    la, lb = rand_store(R, C, P, Ch)
    seen = sorted(rng.choice(C, size=int(rng.integers(2, C + 1)), replace=False).tolist())
    H = np.abs(rng.normal(0, 1, (60, Ch, P))) * (rng.random((60, Ch, P)) < 0.6)
    rho = np.zeros(C)
    rho[seen] = rng.uniform(0, 0.08, len(seen))
    sigma = rng.uniform(0, 0.05, R)
    top1, cert1 = L.certify(la, lb, rho, sigma, H, seen)
    top2, m = L.shared_margins(la, lb, sigma, H, seen)
    cert2 = L.certified_from_margins(top2, m, rho)
    mism += int(np.sum((top1 != top2) | (cert1 != cert2)))
    total += len(H)
check("certify (with pruning and early exit) agrees with the pairwise exact test", mism == 0,
      f"{total} decisions, {mism} mismatches")

# -------------------------------------------------------------------------------------------------------------
header("A2  the explicit worst member flips every uncertified decision and none of the certified ones")
n_cert = n_unc = bad_cert = bad_unc = 0
for trial in range(30):
    R = int(rng.choice([1, 2, 8]))
    C, P, Ch = int(rng.integers(3, 8)), 9, 32
    la, lb = rand_store(R, C, P, Ch)
    seen = list(range(C))
    H = np.abs(rng.normal(0, 1, (40, Ch, P))) * (rng.random((40, Ch, P)) < 0.6)
    rho = rng.uniform(0, 0.08, C)
    sigma = rng.uniform(0, 0.05, R)
    top, cert = L.certify(la, lb, rho, sigma, H, seen)
    _, m = L.shared_margins(la, lb, sigma, H, seen)
    for n in range(len(H)):
        t = int(top[n])
        flipped = False
        for c in seen:
            if c == t:
                continue
            la2, lb2 = worst_member(la, lb, rho, sigma, H[n], t, c)
            z = decision(la2, lb2, H[n], seen)
            if z[c] >= z[t] * (1 - 1e-12):
                flipped = True
        if cert[n]:
            n_cert += 1
            bad_cert += flipped
        else:
            n_unc += 1
            bad_unc += not flipped
check("no certified decision is changed (or tied) by any worst member", bad_cert == 0,
      f"{n_cert} certified decisions, {bad_cert} changed")
check("every uncertified decision is changed or tied by a worst member (the test is tight)", bad_unc == 0,
      f"{n_unc} uncertified decisions, {bad_unc} not changed")

# -------------------------------------------------------------------------------------------------------------
header("A3  per-entry brute force over every vertex of the full box equals Proposition 4")
worst = 0.0
npairs = 0
for trial in range(60):
    R, C, P, Ch = int(rng.choice([1, 2])), 3, 2, 2
    la, lb = rng.normal(0, 1, (R, C, P)), rng.normal(0, 1, (R, Ch))
    H = np.abs(rng.normal(0, 1, (1, Ch, P)))
    rho = rng.uniform(0, 0.4, C)
    sigma = rng.uniform(0, 0.4, R)
    top, m = L.shared_margins(la, lb, sigma, H, range(C))
    t = int(top[0])
    for c in range(C):
        if c == t:
            continue
        # every class log-weight of t and c and every shared log-weight moves independently to +-radius
        n_t, n_c, n_s = R * P, R * P, R * Ch
        best = -np.inf
        for v in itertools.product([-1.0, 1.0], repeat=n_t + n_c + n_s):
            v = np.array(v)
            la2 = la.copy()
            la2[:, t, :] += (v[:n_t] * rho[t]).reshape(R, P)
            la2[:, c, :] += (v[n_t:n_t + n_c] * rho[c]).reshape(R, P)
            lb2 = lb + (v[n_t + n_c:].reshape(R, Ch) * sigma[:, None])
            z = L.term_contributions(la2, lb2, H)[0].sum(axis=(1, 2))
            best = max(best, np.log(z[c] / z[t]))
        exact = -(m[0, c] - rho[t] - rho[c])
        worst = max(worst, abs(best - exact))
        npairs += 1
check("max over all per-entry vertices of log(z_c/z_t) equals rho_t + rho_c - m_tc(sigma)", worst < 1e-12,
      f"{npairs} pairs, up to 2^12 vertices each, max difference {worst:.1e}")

# -------------------------------------------------------------------------------------------------------------
header("A4  power: an unsound certificate (radii halved) is caught by the worst member, not by sampling")
wrong_worst = wrong_sampled = n_claimed = 0
for trial in range(20):
    R, C, P, Ch = 3, 6, 8, 5
    la, lb = rand_store(R, C, P, Ch, s=1.0)
    H = np.abs(rng.normal(0, 1, (60, Ch, P)))
    bits = L.alloc_uniform(la, lb, 6)
    la_q, lb_q, rho, sigma = L.quantize_store(la, lb, bits)
    top_h, cert_h = L.certify(la_q, lb_q, 0.5 * rho, 0.5 * sigma, H, range(C))    # deliberately unsound
    top, cert = L.certify(la_q, lb_q, rho, sigma, H, range(C))
    claimed = np.nonzero(cert_h & ~cert)[0]                                       # certified only by the halved test
    n_claimed += len(claimed)
    for n in claimed:
        t = int(top_h[n])
        for c in range(C):
            if c == t:
                continue
            la2, lb2 = worst_member(la_q, lb_q, rho, sigma, H[n], t, c)
            z = decision(la2, lb2, H[n], range(C))
            if z[c] >= z[t] * (1 - 1e-12):
                wrong_worst += 1
                break
        flips = 0
        for _ in range(300):
            la3 = la_q + rng.uniform(-1, 1, la_q.shape) * rho[None, :, None]
            lb3 = lb_q + rng.uniform(-1, 1, lb_q.shape) * sigma[:, None]
            z = decision(la3, lb3, H[n], range(C))
            flips += int(np.argmax(z) != t)
        wrong_sampled += flips > 0
check("the worst member exposes every decision that only the halved test certifies", wrong_worst == n_claimed,
      f"{n_claimed} wrongly certified decisions; worst member exposes {wrong_worst}")
print(f"  [note] 300 uniform samples per decision (T8's method) expose {wrong_sampled} of them")

# -------------------------------------------------------------------------------------------------------------
header("A5  the smoke-test failure: lazy greedy against exact greedy (CIFAR-100, seed 0, sleep 5; validation)")


def alloc_certificate_lazy(la, lb, budget, Hprot, seen, bmin=1, bmax=16, lam=1e-3, shared_levels=range(1, 17), K=8):
    """The pre-freeze implementation (lazy greedy with stale gains), copied verbatim apart from this docstring."""
    sizes = L.unit_sizes(la, lb, seen)
    R, C, P = la.shape
    cache = L.MarginCache(la, lb, Hprot, seen, K)
    cls_units = [("class", c) for c in sorted(seen)]
    sh_units = [("shared", r) for r in range(R)]
    spans = {}
    for kind, i, v in L.units(la, lb, seen):
        spans[(kind, i)] = L._f16_up(float(v.max())) - L._f16_down(float(v.min()))

    def rad(u, b):
        return 0.5 * spans[u] if b <= 0 else 0.5 * spans[u] / (2 ** b - 1)

    best = None
    for s_bits in shared_levels:
        bits = {u: bmin for u in cls_units}
        bits.update({u: s_bits for u in sh_units})
        left = budget - L.weight_bits(bits, sizes)
        if left < 0:
            continue
        sigma = np.array([rad(u, s_bits) for u in sh_units])
        m = cache.margins(sigma)

        def score(rho):
            sl = cache.slack(m, rho)
            return float((sl > 0).sum()) + lam * float(np.minimum(sl, 0).sum())

        rho = np.zeros(C)
        for u in cls_units:
            rho[u[1]] = rad(u, bits[u])
        cur = score(rho)

        def gain(c):
            u = ("class", c)
            old = rho[c]
            rho[c] = rad(u, bits[u] + 1)
            g = (score(rho) - cur) / sizes[u]
            rho[c] = old
            return g

        heap = [(-gain(u[1]), u[1]) for u in cls_units if bits[u] < bmax]
        heapq.heapify(heap)
        while heap:
            negg, c = heapq.heappop(heap)
            u = ("class", c)
            if bits[u] >= bmax or sizes[u] > left:
                continue
            g = gain(c)
            if heap and g < -heap[0][0] - 1e-15:
                heapq.heappush(heap, (-g, c))
                continue
            bits[u] += 1
            left -= sizes[u]
            rho[c] = rad(u, bits[u])
            cur = score(rho)
            if bits[u] < bmax:
                heapq.heappush(heap, (-gain(c), c))
        if best is None or cur > best[0]:
            best = (cur, dict(bits))
    return best[1]


def _norm(code):
    import re
    code = "\n".join(l for l in code.split("\n") if "import heapq" not in l)
    code = code.replace("alloc_certificate_lazy(", "alloc_certificate(")
    code = re.sub(r"\bL\.", "", code)
    code = re.sub(r'""".*?"""', '"""DOC"""', code, flags=re.S)
    return "\n".join(l.rstrip() for l in code.split("\n") if l.strip())


_pre = open(os.path.join("logs", "smoke", "alloc_certificate_prefreeze.py")).read()
_pre = _pre[_pre.index("def alloc_certificate("):]
_me = open(os.path.abspath(__file__)).read()
_me = _me[_me.index("def alloc_certificate_lazy("):_me.index("\n\n\ndef _norm(")]
check("A0: the lazy greedy used here is the pre-freeze code (docstring, module prefix and import aside)",
      _norm(_pre) == _norm(_me))

meta, states = E.load_run(os.path.join("runs", "cifar100", "R8_task_refit_s0"))
s = states[4]
F = L.features(L.load_dataset("cifar100"), Rn.CONFIG["n_filters"])          # training and validation only
la, lb = s["after"]["la"], s["after"]["lb"]
Hprot = F["Htr"][s["protected"]]
sel = np.isin(F["yva"], s["seen"])
Hv = F["Hva"][sel]
ref, _ = L.predict(L.dense(la, lb), Hv, s["seen"])
sizes = L.unit_sizes(la, lb, s["seen"])
budget = int(round(8 * sum(sizes.values())))
out = {}
for name, fn in (("lazy", alloc_certificate_lazy), ("exact", L.alloc_certificate)):
    bits = fn(la, lb, budget, Hprot, s["seen"])
    la_q, lb_q, rho, sigma = L.quantize_store(la, lb, bits)
    top, cert = L.certify(la_q, lb_q, rho, sigma, Hv, s["seen"])
    cb = np.array([bits[("class", c)] for c in s["seen"]])
    out[name] = (cb, float(np.mean(top == ref)), float(np.mean(cert)))
    if name == "lazy":
        starved = [c for c in s["seen"] if bits[("class", c)] == 1]
        # protected examples: their decisions and the binding competitor of the planning slack at these widths
        cache = L.MarginCache(la, lb, Hprot, s["seen"], 8)
        sigma_p = np.array([0.5 * (L._f16_up(float(lb[r].max())) - L._f16_down(float(lb[r].min()))) /
                            (2 ** bits[("shared", r)] - 1) for r in range(la.shape[0])])
        rho_p = np.zeros(la.shape[1])
        for c in s["seen"]:
            v = la[:, c, :]
            rho_p[c] = 0.5 * (L._f16_up(float(v.max())) - L._f16_down(float(v.min()))) / (2 ** bits[("class", c)] - 1)
        m_ex, m_rest = cache.margins(sigma_p)
        M = np.concatenate([m_ex, m_rest], axis=1)
        comp = np.concatenate([cache.comp, cache.rest_comp], axis=1)
        S = M - rho_p[cache.top][:, None] - rho_p[comp]
        binding = comp[np.arange(len(S)), np.argmin(S, axis=1)]
        pred_counts = {int(c): int(np.sum(top == c)) for c in starved}
        print(f"  lazy greedy: starved classes {starved} decide {int(np.isin(cache.top, starved).sum())} of "
              f"{len(cache.top)} protected examples and are the binding competitor of "
              f"{int(np.isin(binding, starved).sum())} of them; validation decisions predicted as each: {pred_counts}")
    print(f"  {name:5s} greedy: class widths {cb.min()}-{cb.max()}, classes at 1 bit "
          f"{[c for c in s['seen'] if bits[('class', c)] == 1]}, agreement with the reference {100 * out[name][1]:.1f}%, "
          f"certified {100 * out[name][2]:.1f}%  (validation, {len(Hv)} decisions)")
check("the lazy greedy starves classes at 1 bit and loses the decisions; the exact greedy does not",
      (out["lazy"][0] == 1).any() and not (out["exact"][0] == 1).any() and out["exact"][1] > 0.9 > out["lazy"][1])

# -------------------------------------------------------------------------------------------------------------
header("A6  protected and test decisions certified, uniform vs certificate-guided (MNIST; measurement only)")
Fm = L.features(L.load_dataset("mnist"), Rn.CONFIG["n_filters"])
res = {}
for seed in range(5):
    meta, st = E.load_run(os.path.join("runs", "mnist", f"R8_task_refit_s{seed}"))
    ev = json.load(open(os.path.join("evals", "mnist", f"R8_task_refit_s{seed}.json")))
    for t in (0, 4):
        s0 = st[t]
        la, lb = s0["after"]["la"], s0["after"]["lb"]
        Hp = Fm["Htr"][s0["protected"]]
        usage = E.usage_from(s0["use"], t, la.shape[0], la.shape[1])
        for bbar in (6, 8, 10, 12):
            for pol in ("uniform", "cert"):
                bits = Rn.allocate(pol, la, lb, bbar, Hp, s0["seen"], usage)
                la_q, lb_q, rho, sigma = L.quantize_store(la, lb, bits)
                _, cert = L.certify(la_q, lb_q, rho, sigma, Hp, s0["seen"])
                test = next(x["certified"] for x in ev["precision"] if x["t"] == t and x["bbar"] == bbar and x["policy"] == pol)
                res.setdefault((t, bbar, pol), []).append((float(np.mean(cert)), test))
for (t, bbar, pol), v in sorted(res.items()):
    v = np.array(v)
    print(f"  sleep {t + 1}, b={bbar:2d}, {pol:7s}: protected certified {np.round(100 * v[:, 0], 1).tolist()}  "
          f"test certified {np.round(100 * v[:, 1], 1).tolist()}")

# -------------------------------------------------------------------------------------------------------------
header("A8  frozen check T10 with the pre-freeze lazy greedy; fragility of T10's construction (measurement)")
import io
import runpy
import contextlib
_orig = L.alloc_certificate
L.alloc_certificate = alloc_certificate_lazy
_buf = io.StringIO()
with contextlib.redirect_stdout(_buf):
    runpy.run_path(os.path.join(HERE, "verify_p3_theory.py"), run_name="__main__")
L.alloc_certificate = _orig
_t10 = [l.strip() for l in _buf.getvalue().split("\n") if "never the decision is not starved" in l]
print("  frozen T10 starvation check, lazy greedy swapped in: " + (_t10[0] if _t10 else "not found"))
check("the frozen T10 starvation check fails for the pre-freeze lazy greedy at T10's random state",
      bool(_t10) and _t10[0].startswith("[FAIL]"))
frag = []
for d in range(6):
    r2 = np.random.default_rng(100 + d)
    R, C, P, Ch = 2, 6, 5, 4
    la = r2.normal(np.log(1 / (P * R)), 0.3, (R, C, P))
    lb = r2.normal(np.log(1 / Ch), 0.3, (R, Ch))
    la[:, 5, :] -= 2.0
    H = np.abs(r2.normal(0, 1, (300, Ch, P)))
    sizes = L.unit_sizes(la, lb)
    budget = int(8 * sum(sizes.values()))
    top0, _ = L.predict(L.dense(la, lb), H, range(C))
    be = L.alloc_certificate(la, lb, budget, H, range(C))[("class", 5)]
    bl = alloc_certificate_lazy(la, lb, budget, H, range(C))[("class", 5)]
    frag.append((int((top0 == 5).sum()), be, bl))
print("  fresh draws of T10's construction (decisions of class 5, its width exact / lazy): " +
      "; ".join(f"{a}, {b}/{c}" for a, b, c in frag))

# -------------------------------------------------------------------------------------------------------------
header("A9  the shared-width tie rule (MNIST refit stores, validation decisions; measurement)")
rows9 = {}
for seed in range(5):
    meta, st = E.load_run(os.path.join("runs", "mnist", f"R8_task_refit_s{seed}"))
    for t, bbar in ((0, 8), (0, 12), (1, 12), (3, 12)):
        s0 = st[t]
        la, lb = s0["after"]["la"], s0["after"]["lb"]
        Hp = Fm["Htr"][s0["protected"]]
        selv = np.isin(Fm["yva"], s0["seen"])
        Hv = Fm["Hva"][selv]
        sizes = L.unit_sizes(la, lb, s0["seen"])
        budget = int(round(bbar * sum(sizes.values())))
        variants = {"frozen (smallest width among ties)": L.alloc_certificate(la, lb, budget, Hp, s0["seen"]),
                    "ties to the largest width": L.alloc_certificate(la, lb, budget, Hp, s0["seen"],
                                                                     shared_levels=range(16, 0, -1)),
                    "uniform": L.alloc_uniform(la, lb, bbar, s0["seen"])}
        for name, bits in variants.items():
            la_q, lb_q, rho, sigma = L.quantize_store(la, lb, bits)
            _, cert = L.certify(la_q, lb_q, rho, sigma, Hv, s0["seen"])
            rows9.setdefault((t, bbar, name), []).append((float(np.mean(cert)), bits[("shared", 0)]))
for (t, bbar, name), v in sorted(rows9.items()):
    v = np.array(v)
    print(f"  sleep {t + 1}, b={bbar:2d}, {name:35s}: certified {100 * v[:, 0].mean():6.2f}% "
          f"(seeds {np.round(100 * v[:, 0], 2).tolist()}), channel-vector width {v[:, 1].tolist()}")

# -------------------------------------------------------------------------------------------------------------
header("A7  Proposition 6 in the evaluator: certified decisions that the working model did not share")
viol, rows_n = 0, 0
for ds in ("mnist", "cifar100"):
    for p in sorted(os.listdir(os.path.join("evals", ds))):
        if not p.endswith(".json"):
            continue
        r = json.load(open(os.path.join("evals", ds, p)))
        for x in r.get("consolidation", []):
            if x.get("finite"):
                viol += x.get("certificate_violations", 0)
                rows_n += 1
check("no certified decision of the residual bound disagreed with the working model (all runs, all sleeps)",
      viol == 0, f"{rows_n} evaluated sleeps, {viol} violations")

print("\n" + ("ALL ADDENDUM CHECKS PASSED" if not FAILS else f"FAILED: {FAILS}"))
