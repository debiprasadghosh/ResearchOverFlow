# P3 supplement: Sleep That Knows What It Keeps

Everything needed to check and reproduce the P3 paper (`P3_Sleep_That_Knows_What_It_Keeps.md`).

## Contents

| Path | What it is |
|---|---|
| `PROTOCOL.md` | the protocol, written before any confirmatory run or test example |
| `evals_code_sha256.txt` | SHA-256 of the frozen library, run script, evaluator, theory checks and protocol (04:21 UTC, 5 October 2026) |
| `p3lib.py` | library: data, features, store, wake, sleep rules, stored precision, exact decision test, allocation policies |
| `p3_run.py` | all confirmatory runs (training data only): `python3 p3_run.py all` |
| `p3_eval.py` | the frozen evaluator, the only code that reads the test split: `python3 p3_eval.py mnist`, `python3 p3_eval.py cifar100` |
| `verify_p3_theory.py`, `verify_p3_theory_output.txt` | numerical checks T1–T10 of Propositions 1–6 (28 checks, all pass; frozen) |
| `verify_p3_addendum.py`, `verify_p3_addendum_output.txt` | post-review checks and measurements A0–A9 (written after the results and the independent review; training and validation data, saved stores and evaluator outputs only) |
| `p3_report.py` | aggregates `evals/` into `report/summary.json`, `report/tables.md` and `figures/` |
| `p3_facts.py`, `facts_output.txt` | every number quoted in the paper, with intervals and per-seed values |
| `p3_pub_wake_check.py`, `report/pub_wake_check.txt` | Section 5.1 diagnostic (training data only): why the wake cannot learn new classes after a published-rule sleep |
| `runs/<dataset>/*.json` | per-run metadata and training-side records of all 270 runs (the saved stores, 776 MB, are omitted; `p3_run.py` regenerates them deterministically) |
| `evals/<dataset>/*.json`, `*_bits.npz` | the evaluator's outputs for every run, and per-decision bits for the refit runs |
| `report/tables.md` | every table: all rules, ranks, cadences, sleeps, budgets and policies, plus per-seed tables |
| `figures/` | the four figures of the paper |
| `pilots/`, `logs/` | design pilots (validation data only) and all logs (pilots, runs, evaluation); `logs/smoke/` holds the pre-freeze smoke tests, which used validation data in place of test data, and the pre-freeze lazy greedy recovered from the session transcript |
| `chain_eval.sh` | the script that evaluated each dataset once its runs were complete |

## Reproduction

Python 3.11 with NumPy 2.4, SciPy 1.17, Matplotlib 3.10 and JAX 0.10 (CPU). Place the MNIST IDX files in `data/` and the CIFAR-100 python files (`train`, `test`, `meta`) in `data/cifar100/`; the loaders check their MD5 sums.

```
python3 verify_p3_theory.py > verify_p3_theory_output.txt
python3 p3_run.py all
python3 p3_eval.py mnist && python3 p3_eval.py cifar100
python3 p3_report.py && python3 p3_facts.py > facts_output.txt
python3 p3_pub_wake_check.py > report/pub_wake_check.txt
python3 verify_p3_addendum.py > verify_p3_addendum_output.txt
```

The runs take about 50 minutes and the evaluation about an hour on two CPU cores.
