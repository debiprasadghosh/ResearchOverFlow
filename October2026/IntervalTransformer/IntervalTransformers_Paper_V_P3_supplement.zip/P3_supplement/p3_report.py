"""P3 report: aggregates the frozen evaluator's outputs (evals/<dataset>/*.json) into report/summary.json,
report/tables.md and the figures.  Reads no data and no model; every number in the paper comes from here or
from p3_facts.py, which reads report/summary.json.

Usage: python3 p3_report.py
"""
import os
import re
import json
import glob
import numpy as np
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
DATASETS = ["mnist", "cifar100"]
RULES = ["none", "pub", "pub01", "gain_ord", "gain_w", "gain_w1", "resid", "tan", "refit"]
FAST = ["gain_ord", "gain_w", "gain_w1", "tan", "refit"]
POLICIES = ["uniform", "usage", "cert", "exposure"]
BUDGETS = [4, 6, 8, 10, 12]
SEEDS = [0, 1, 2, 3, 4]
FINAL_T = {"mnist": 4, "cifar100": 9}
PREC_T = {"mnist": [0, 1, 2, 3, 4], "cifar100": [4, 9]}


def ci(x):
    """Seed mean and 95% t half-width (None-safe)."""
    x = np.array([v for v in x if v is not None and np.isfinite(v)], float)
    if len(x) == 0:
        return {"mean": None, "half": None, "n": 0, "values": []}
    h = float(stats.t.ppf(0.975, len(x) - 1) * x.std(ddof=1) / np.sqrt(len(x))) if len(x) > 1 else None
    return {"mean": float(x.mean()), "half": h, "n": int(len(x)), "values": [float(v) for v in x]}


def load(ds):
    out = {}
    for p in sorted(glob.glob(os.path.join("evals", ds, "*.json"))):
        name = os.path.basename(p)[:-5]
        out[name] = json.load(open(p))
    return out


def nanmean(xs):
    xs = [x for x in xs if x is not None and np.isfinite(x)]
    return float(np.mean(xs)) if xs else None


def nanmedian(xs):
    xs = [x for x in xs if x is not None and np.isfinite(x)]
    return float(np.median(xs)) if xs else None


def consolidation_group(E, prefix, rule):
    runs = [E.get(f"{prefix}_{rule}_s{s}") for s in SEEDS]
    runs = [r for r in runs if r is not None]
    if not runs:
        return None
    g = {"n": len(runs)}
    rows = [r["consolidation"] for r in runs]
    g["final_acc"] = ci([c[-1]["acc_stored"] for c in rows])
    g["final_work_acc"] = ci([c[-1]["acc_working"] for c in rows])
    g["final_acc_old"] = ci([c[-1]["final_acc_old"] for c in rows])
    g["final_fidelity"] = ci([c[-1]["fidelity"] for c in rows])
    g["fidelity_mean"] = ci([np.mean([x["fidelity"] for x in c]) for c in rows])
    g["cert_fidelity_mean"] = ci([np.mean([x["certified_fidelity"] for x in c]) for c in rows])
    g["final_cert_fidelity"] = ci([c[-1]["certified_fidelity"] for c in rows])
    g["rel_residual_median"] = ci([nanmedian([x["rel_residual"] for x in c]) for c in rows])
    g["frac_S_mean"] = ci([nanmean([x["frac_S"] for x in c]) for c in rows])
    g["frac_T_mean"] = ci([nanmean([x["frac_T"] for x in c]) for c in rows])
    g["log10_max_rel_change_median"] = ci([nanmedian([np.log10(x["max_rel_change"]) if x["max_rel_change"] else None
                                                      for x in c]) for c in rows])
    g["acc_stored_by_sleep"] = [ci([c[t]["acc_stored"] for c in rows]) for t in range(len(rows[0]))]
    g["acc_working_by_sleep"] = [ci([c[t]["acc_working"] for c in rows]) for t in range(len(rows[0]))]
    g["fidelity_by_sleep"] = [ci([c[t]["fidelity"] for c in rows]) for t in range(len(rows[0]))]
    g["final_per_task"] = [ci([r["final_per_task"][k] for r in runs]) for k in range(len(runs[0]["final_per_task"]))]
    g["diverged_seeds"] = int(sum(any(not x["finite"] for x in c) for c in rows))
    g["first_diverged_sleep"] = [next((x["t"] for x in c if not x["finite"]), None) for c in rows]
    g["zero_weight_frac_final"] = ci([c[-1].get("zero_weight_frac") for c in rows])
    g["certificate_violations"] = int(sum(x.get("certificate_violations", 0) for c in rows for x in c))
    infos = [r["infos"] for r in runs]
    if rule.startswith("pub"):
        g["undefined_mean"] = ci([np.mean([i["undefined_base_frac"] for i in inf]) for inf in infos])
        g["undefined_first"] = ci([inf[0]["undefined_base_frac"] for inf in infos])
    g["bits_final"] = {k: float(np.mean([c[-1]["bits"][k] for c in rows])) for k in rows[0][-1]["bits"]}
    if "inner_sleeps" in infos[0][0]:
        g["inner_sleeps_total"] = ci([sum(i["inner_sleeps"] for i in inf) for inf in infos])
        g["inner_rel_residual_median"] = ci([np.median([i["inner_rel_residual_median"] for i in inf]) for inf in infos])
    curves = [c[-1]["residual_rank_curve"] for c in rows]
    if all(cv is not None for cv in curves):
        g["final_curve"] = [{"rank": curves[0][k]["rank"], "bits": curves[0][k]["bits"],
                             "certified_fidelity": ci([cv[k]["certified_fidelity"] for cv in curves]),
                             "fidelity": ci([cv[k]["fidelity"] for cv in curves])} for k in range(len(curves[0]))]
        allc = [[x["residual_rank_curve"] for x in c] for c in rows]
        g["mean_curve"] = [{"rank": curves[0][k]["rank"],
                            "certified_fidelity": ci([np.mean([cv[k]["certified_fidelity"] for cv in cc if cv is not None])
                                                      for cc in allc])} for k in range(len(curves[0]))]
    return g


def paired(a, b):
    d = [x - y for x, y in zip(a, b)]
    return ci(d)


def precision_summary(E, ds):
    runs = {s: E.get(f"R8_task_refit_s{s}") for s in SEEDS}
    runs = {s: r for s, r in runs.items() if r is not None and "precision" in r}
    out = {}
    for t in PREC_T[ds]:
        for bbar in BUDGETS:
            key = f"t{t}_b{bbar}"
            cell = {}
            vals = {}
            for pol in POLICIES:
                recs = [next(x for x in runs[s]["precision"] if x["t"] == t and x["bbar"] == bbar and x["policy"] == pol)
                        for s in sorted(runs)]
                vals[pol] = recs
                cell[pol] = {k: ci([x[k] for x in recs]) for k in ("certified", "agreement", "accuracy",
                                                                   "certified_accuracy", "certified_old",
                                                                   "agreement_old", "t_alloc", "t_cert")}
                cell[pol]["weight_bits"] = float(np.mean([x["weight_bits"] for x in recs]))
                cell[pol]["budget_bits"] = float(np.mean([x["budget_bits"] for x in recs]))
                cell[pol]["meta_bits"] = float(np.mean([x["meta_bits"] for x in recs]))
                cell[pol]["shared_bits_mean"] = float(np.mean([np.mean(x["shared_bits"]) for x in recs]))
                cb = [[b for b in x["class_bits"] if b is not None] for x in recs]
                cell[pol]["class_bits_min"] = float(np.mean([min(c) for c in cb]))
                cell[pol]["class_bits_max"] = float(np.mean([max(c) for c in cb]))
            for other in ("uniform", "usage", "exposure"):
                cell[f"cert_minus_{other}"] = paired([x["certified"] for x in vals["cert"]],
                                                     [x["certified"] for x in vals[other]])
                cell[f"cert_minus_{other}_agreement"] = paired([x["agreement"] for x in vals["cert"]],
                                                               [x["agreement"] for x in vals[other]])
            out[key] = cell
    return out


def bits_summary(ds):
    out = {"per_seed": []}
    pooled = {"margin": [], "b_cert": [], "b_keep": []}
    for s in SEEDS:
        p = os.path.join("evals", ds, f"R8_task_refit_s{s}_bits.npz")
        if not os.path.exists(p):
            continue
        d = np.load(p)
        m, bc, bk = d["margin"], d["b_cert"], d["b_keep"]
        lost = bk - 1
        r_lost = stats.spearmanr(m, lost).statistic
        r_cert = stats.spearmanr(m, bc).statistic
        out["per_seed"].append({"seed": s, "spearman_lost": float(r_lost), "spearman_cert": float(r_cert),
                                "never_certified_16": float(np.mean(bc == 99)), "kept_from_1": float(np.mean(bk == 1)),
                                "lost_at_16": float(np.mean(bk == 99)), "median_b_cert": float(np.median(bc)),
                                "median_b_keep": float(np.median(bk)), "n": int(len(m))})
        for k, v in (("margin", m), ("b_cert", bc), ("b_keep", bk)):
            pooled[k].append(v)
    if out["per_seed"]:
        out["spearman_lost"] = ci([x["spearman_lost"] for x in out["per_seed"]])
        out["spearman_cert"] = ci([x["spearman_cert"] for x in out["per_seed"]])
        out["p33_holds_every_seed"] = bool(all(x["spearman_lost"] <= -0.7 for x in out["per_seed"]))
        out["max_spearman_lost"] = float(max(x["spearman_lost"] for x in out["per_seed"]))
    return out, {k: np.concatenate(v) if v else None for k, v in pooled.items()}


def dynamic_summary(E):
    out = {}
    vals = {}
    for pol in POLICIES:
        recs = [E.get(f"dyn_{pol}_s{s}") for s in SEEDS]
        recs = [r["dynamic"] for r in recs if r is not None]
        if not recs:
            continue
        vals[pol] = recs
        out[pol] = {k: ci([r[k] for r in recs]) for k in ("acc", "agree_fullprec", "certified_own")}
    if "cert" in vals:
        for other in ("uniform", "usage", "exposure"):
            if other in vals:
                out[f"cert_minus_{other}_certified"] = paired([r["certified_own"] for r in vals["cert"]],
                                                              [r["certified_own"] for r in vals[other]])
                out[f"cert_minus_{other}_acc"] = paired([r["acc"] for r in vals["cert"]], [r["acc"] for r in vals[other]])
    return out


def fmt(c, pct=True, d=1):
    if c is None or c.get("mean") is None:
        return "–"
    k = 100.0 if pct else 1.0
    if c.get("half") is None:
        return f"{k * c['mean']:.{d}f}"
    return f"{k * c['mean']:.{d}f} ± {k * c['half']:.{d}f}"


def main():
    os.makedirs("report", exist_ok=True)
    os.makedirs("figures", exist_ok=True)
    S = {}
    pooled_bits = {}
    for ds in DATASETS:
        E = load(ds)
        if not E:
            continue
        S[ds] = {"consolidation": {}, "precision": None, "bits": None, "dynamic": None}
        for prefix, rules in (("R8_task", RULES), ("R1_task", RULES), ("R8_10", FAST)):
            for rule in rules:
                g = consolidation_group(E, prefix, rule)
                if g is not None:
                    S[ds]["consolidation"][f"{prefix}_{rule}"] = g
        # registered comparisons on consolidation
        cons = S[ds]["consolidation"]
        runs = lambda pre, r: [E.get(f"{pre}_{r}_s{s}") for s in SEEDS]
        if f"R8_task_gain_w" in cons and f"R8_task_none" in cons:
            a = [r["consolidation"][-1]["acc_stored"] for r in runs("R8_task", "gain_w")]
            b = [r["consolidation"][-1]["acc_stored"] for r in runs("R8_task", "none")]
            S[ds]["p32_gain_w_minus_none"] = paired(a, b)
        olds = {r: cons[f"R8_task_{r}"]["final_acc_old"]["mean"] for r in RULES if f"R8_task_{r}" in cons}
        if "pub" in olds:
            S[ds]["p31_old_acc_by_rule"] = olds
            S[ds]["p31_pub_lowest"] = bool(all(olds["pub"] < v for r, v in olds.items() if r != "pub"))
            S[ds]["p31_rank_of_pub"] = int(sorted(olds.values()).index(olds["pub"]) + 1)
        if any(k.startswith("R8_task_refit") for k in E):
            S[ds]["precision"] = precision_summary(E, ds)
            S[ds]["bits"], pooled_bits[ds] = bits_summary(ds)
        S[ds]["dynamic"] = dynamic_summary(E)
        # refit and none across seeds: paired accuracy differences
        if "R8_task_refit" in cons and "R8_task_none" in cons:
            a = [r["consolidation"][-1]["acc_stored"] for r in runs("R8_task", "refit")]
            b = [r["consolidation"][-1]["acc_stored"] for r in runs("R8_task", "none")]
            S[ds]["refit_minus_none_acc"] = paired(a, b)
    json.dump(S, open("report/summary.json", "w"), indent=1)
    write_tables(S)
    figures(S, pooled_bits)
    print("wrote report/summary.json, report/tables.md, figures/")


NAMES = {"none": "no sleep (dense correction)", "pub": "published, \\|C\\| surrogate, α = 1", "pub01": "published, \\|C\\| surrogate, α = 0.1",
         "gain_ord": "Eq. 13 (ordinary block means)", "gain_w": "Eq. 14 (weighted block means)",
         "gain_w1": "Eq. 14, first order", "resid": "Eq. 14 + stored residual", "tan": "tangent projection (ours)",
         "refit": "Frobenius refit (ours)"}
PNAMES = {"uniform": "uniform", "usage": "usage-and-age", "cert": "certificate-guided", "exposure": "exposure-aware control"}


def write_tables(S):
    L = []
    for ds in S:
        L.append(f"\n## {ds}\n")
        for prefix, title in (("R8_task", "R = 8, sleep after each task"), ("R1_task", "R = 1, sleep after each task"),
                              ("R8_10", "R = 8, sleep every 10 steps")):
            L.append(f"\n### Consolidation, {title}\n")
            L.append("| Rule | final acc. (%) | earlier tasks (%) | working acc. at last sleep (%) | fidelity, mean over sleeps (%) | "
                     "certified fidelity, mean (%) | rel. residual (median) | in S_W | in T_W | log10 max rel. change | "
                     "diverged seeds | undefined (pub) | stored bits |")
            L.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|")
            for rule in RULES:
                g = S[ds]["consolidation"].get(f"{prefix}_{rule}")
                if g is None:
                    continue
                und = fmt(g.get("undefined_mean")) if "undefined_mean" in g else ""
                L.append(f"| {NAMES[rule]} | {fmt(g['final_acc'])} | {fmt(g['final_acc_old'])} | {fmt(g['final_work_acc'])} | "
                         f"{fmt(g['fidelity_mean'])} | {fmt(g['cert_fidelity_mean'])} | {fmt(g['rel_residual_median'], False, 3)} | "
                         f"{fmt(g['frac_S_mean'], False, 2)} | {fmt(g['frac_T_mean'], False, 2)} | "
                         f"{fmt(g['log10_max_rel_change_median'], False, 1)} | {g['diverged_seeds']} | {und} | "
                         f"{g['bits_final']['total']:.0f} |")
            L.append("")
            L.append("Final accuracy per task (stored model, %):\n")
            L.append("| Rule | " + " | ".join(f"task {k + 1}" for k in range(len(next(iter(S[ds]['consolidation'].values()))['final_per_task']))) + " |")
            L.append("|---|" + "---|" * len(next(iter(S[ds]['consolidation'].values()))['final_per_task']))
            for rule in RULES:
                g = S[ds]["consolidation"].get(f"{prefix}_{rule}")
                if g is None:
                    continue
                L.append(f"| {NAMES[rule]} | " + " | ".join(f"{100 * c['mean']:.1f}" for c in g["final_per_task"]) + " |")
        if S[ds]["precision"]:
            for t in PREC_T[ds]:
                L.append(f"\n### Precision at the sleep ending task {t + 1}\n")
                L.append("| b̄ | policy | certified retention (%) | agreement (%) | accuracy (%) | certified, earlier tasks (%) | "
                         "weight bits | budget bits | class bits min–max | shared bits | alloc. time (s) | cert. time (s) |")
                L.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
                for bbar in BUDGETS:
                    cell = S[ds]["precision"][f"t{t}_b{bbar}"]
                    for pol in POLICIES:
                        c = cell[pol]
                        L.append(f"| {bbar} | {PNAMES[pol]} | {fmt(c['certified'])} | {fmt(c['agreement'])} | {fmt(c['accuracy'])} | "
                                 f"{fmt(c['certified_old'])} | {c['weight_bits']:.0f} | {c['budget_bits']:.0f} | "
                                 f"{c['class_bits_min']:.1f}–{c['class_bits_max']:.1f} | {c['shared_bits_mean']:.1f} | "
                                 f"{fmt(c['t_alloc'], False, 2)} | {fmt(c['t_cert'], False, 2)} |")
                    L.append(f"| {bbar} | cert − uniform | {fmt(cell['cert_minus_uniform'])} | | | | | | | | | |")
                    L.append(f"| {bbar} | cert − usage | {fmt(cell['cert_minus_usage'])} | | | | | | | | | |")
        if S[ds]["bits"] and S[ds]["bits"]["per_seed"]:
            L.append("\n### Bits per decision (final sleep)\n")
            L.append("| seed | Spearman(margin, bits lost) | Spearman(margin, bits certified) | never certified at 16 bits | kept from 1 bit |")
            L.append("|---|---|---|---|---|")
            for x in S[ds]["bits"]["per_seed"]:
                L.append(f"| {x['seed']} | {x['spearman_lost']:.3f} | {x['spearman_cert']:.3f} | {100 * x['never_certified_16']:.1f}% | "
                         f"{100 * x['kept_from_1']:.1f}% |")
        if S[ds]["dynamic"]:
            L.append("\n### Dynamic arm (b̄ = 8 in the loop)\n")
            L.append("| policy | final acc. (%) | agreement with full precision (%) | certified retention of final box (%) |")
            L.append("|---|---|---|---|")
            for pol in POLICIES:
                if pol in S[ds]["dynamic"]:
                    d = S[ds]["dynamic"][pol]
                    L.append(f"| {PNAMES[pol]} | {fmt(d['acc'])} | {fmt(d['agree_fullprec'])} | {fmt(d['certified_own'])} |")
    # per-seed tables (Appendix B)
    for ds in S:
        L.append(f"\n## {ds}: per seed\n")
        L.append("Final accuracy of the stored model (%), R = 8, sleep after each task:\n")
        L.append("| Rule | " + " | ".join(f"seed {s}" for s in SEEDS) + " |")
        L.append("|---|" + "---|" * len(SEEDS))
        for rule in RULES:
            g = S[ds]["consolidation"].get(f"R8_task_{rule}")
            if g is not None:
                L.append(f"| {NAMES[rule]} | " + " | ".join(f"{100 * v:.1f}" for v in g["final_acc"]["values"]) + " |")
        if S[ds]["precision"]:
            t = FINAL_T[ds]
            cell = S[ds]["precision"][f"t{t}_b8"]
            L.append(f"\nCertified retention (%) at the final sleep, b̄ = 8:\n")
            L.append("| Policy | " + " | ".join(f"seed {s}" for s in SEEDS) + " |")
            L.append("|---|" + "---|" * len(SEEDS))
            for pol in POLICIES:
                L.append(f"| {PNAMES[pol]} | " + " | ".join(f"{100 * v:.1f}" for v in cell[pol]["certified"]["values"]) + " |")
            for other in ("uniform", "usage"):
                L.append(f"| cert − {PNAMES[other]} | " + " | ".join(f"{100 * v:+.1f}" for v in cell[f"cert_minus_{other}"]["values"]) + " |")
    open("report/tables.md", "w").write("\n".join(L) + "\n")


COLORS = {"none": "k", "pub": "tab:red", "pub01": "salmon", "gain_ord": "tab:olive", "gain_w": "tab:orange",
          "gain_w1": "gold", "resid": "tab:gray", "tan": "tab:green", "refit": "tab:blue"}
PCOL = {"uniform": "tab:gray", "usage": "tab:orange", "cert": "tab:blue", "exposure": "tab:green"}


def figures(S, pooled_bits):
    dss = [ds for ds in DATASETS if ds in S]
    titles = {"mnist": "split MNIST", "cifar100": "split CIFAR-100"}
    # Figure 1: stored accuracy after each sleep
    fig, axes = plt.subplots(1, len(dss), figsize=(5.2 * len(dss), 4.6))
    axes = np.atleast_1d(axes)
    for ax, ds in zip(axes, dss):
        for rule in RULES:
            g = S[ds]["consolidation"].get(f"R8_task_{rule}")
            if g is None:
                continue
            y = [100 * c["mean"] if c["mean"] is not None else np.nan for c in g["acc_stored_by_sleep"]]
            ax.plot(np.arange(1, len(y) + 1), y, "-o", ms=3, color=COLORS[rule], label=NAMES[rule].replace("\\|", "|"),
                    lw=2.2 if rule in ("none", "refit") else 1.2)
        ax.set_xlabel("sleep (end of task)")
        ax.set_ylabel("accuracy of the stored model on seen classes (%)")
        ax.set_title(titles[ds] + ", R = 8")
        ax.set_xticks(np.arange(1, len(y) + 1))
        ax.grid(alpha=0.3)
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, fontsize=8, loc="lower center", ncol=3, frameon=False)
    fig.tight_layout(rect=(0, 0.17, 1, 1))
    fig.savefig("figures/fig_streams.png", dpi=150)
    plt.close(fig)
    # Figure 2: residual accounting curve at the final sleep
    fig, axes = plt.subplots(1, len(dss), figsize=(5.2 * len(dss), 3.8))
    axes = np.atleast_1d(axes)
    for ax, ds in zip(axes, dss):
        for key, lab, col, ls in (("R8_task_refit", "refit, per task", "tab:blue", "-"), ("R8_10_refit", "refit, every 10 steps", "tab:blue", "--"),
                                  ("R8_task_tan", "tangent, per task", "tab:green", "-"), ("R8_10_tan", "tangent, every 10 steps", "tab:green", "--"),
                                  ("R8_task_gain_w", "Eq. 14, per task", "tab:orange", "-")):
            g = S[ds]["consolidation"].get(key)
            if g is None or "final_curve" not in g:
                continue
            x = [c["bits"] for c in g["final_curve"]]
            y = [100 * c["certified_fidelity"]["mean"] for c in g["final_curve"]]
            ax.plot(np.array(x) / 1e3, y, ls, marker="o", ms=3, color=col, label=lab)
        if "R8_task_none" in S[ds]["consolidation"]:
            nb = S[ds]["consolidation"]["R8_task_none"]["bits_final"]["correction"]
            ax.axvline(nb / 1e3, color="k", lw=0.8, ls=":")
            ax.text(nb / 1e3, 50, " dense float32\n correction", fontsize=7, va="center")
        ax.set_xscale("symlog", linthresh=10)
        ax.set_xlabel("bits of the kept residual terms (thousands)")
        ax.set_ylabel("certified fidelity at the last sleep (%)")
        ax.set_title(titles[ds])
        ax.grid(alpha=0.3)
    axes[0].legend(fontsize=7)
    fig.tight_layout()
    fig.savefig("figures/fig_residual.png", dpi=150)
    plt.close(fig)
    # Figure 3: certified retention against budget, final sleep
    fig, axes = plt.subplots(1, len(dss), figsize=(5.2 * len(dss), 3.8))
    axes = np.atleast_1d(axes)
    for ax, ds in zip(axes, dss):
        if not S[ds]["precision"]:
            continue
        t = FINAL_T[ds]
        for k, pol in enumerate(POLICIES):
            ys = [S[ds]["precision"][f"t{t}_b{b}"][pol]["certified"] for b in BUDGETS]
            ax.plot(BUDGETS, [100 * c["mean"] for c in ys], "-o", ms=4, color=PCOL[pol], label=PNAMES[pol])
            for b, c in zip(BUDGETS, ys):
                ax.scatter([b + (k - 1.5) * 0.12] * len(c["values"]), [100 * v for v in c["values"]], s=6,
                           color=PCOL[pol], alpha=0.5)
        ax.axvline(8, color="k", lw=0.6, ls=":")
        ax.set_xlabel("budget b̄ (bits per stored log-weight)")
        ax.set_ylabel("certified retention (%)")
        ax.set_title(titles[ds] + f", sleep {t + 1}")
        ax.grid(alpha=0.3)
    axes[0].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig("figures/fig_precision.png", dpi=150)
    plt.close(fig)
    # Figure 4: bits per decision against the log margin (pooled seeds)
    fig, axes = plt.subplots(1, len(dss), figsize=(5.2 * len(dss), 3.8))
    axes = np.atleast_1d(axes)
    for ax, ds in zip(axes, dss):
        pb = pooled_bits.get(ds)
        if pb is None or pb["margin"] is None:
            continue
        m = pb["margin"]
        edges = np.quantile(m, np.linspace(0, 1, 21))
        mid, bc_med, bc_lo, bc_hi, bl_med, bl_lo, bl_hi = [], [], [], [], [], [], []
        for lo, hi in zip(edges[:-1], edges[1:]):
            sel = (m >= lo) & (m <= hi)
            mid.append(np.median(m[sel]))
            bc = np.minimum(pb["b_cert"][sel], 17)
            bl = np.minimum(pb["b_keep"][sel] - 1, 17)
            bc_med.append(np.median(bc)); bc_lo.append(np.quantile(bc, 0.25)); bc_hi.append(np.quantile(bc, 0.75))
            bl_med.append(np.median(bl)); bl_lo.append(np.quantile(bl, 0.25)); bl_hi.append(np.quantile(bl, 0.75))
        ax.plot(mid, bc_med, "-o", ms=3, color="tab:blue", label="bits to certify (median, IQR)")
        ax.fill_between(mid, bc_lo, bc_hi, color="tab:blue", alpha=0.15)
        ax.plot(mid, bl_med, "-s", ms=3, color="tab:red", label="bits at which lost (median, IQR)")
        ax.fill_between(mid, bl_lo, bl_hi, color="tab:red", alpha=0.15)
        ax.set_xscale("log")
        ax.set_xlabel("reference log margin (nats)")
        ax.set_ylabel("uniform bits per log-weight (17 = not within 16)")
        ax.set_title(titles[ds] + ", final sleep, 5 seeds")
        ax.grid(alpha=0.3)
    axes[0].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig("figures/fig_bits.png", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    main()
