#!/bin/bash
# waits for each dataset's last run, then evaluates it (the evaluator alone reads the test split)
cd /home/claude/p3
while [ ! -f runs/mnist/dyn_exposure_s4.json ]; do sleep 30; done
python3 -u p3_eval.py mnist > logs/eval_mnist.log 2>&1
while [ ! -f runs/cifar100/dyn_exposure_s4.json ]; do sleep 30; done
python3 -u p3_eval.py cifar100 > logs/eval_cifar100.log 2>&1
echo done > logs/eval_done
