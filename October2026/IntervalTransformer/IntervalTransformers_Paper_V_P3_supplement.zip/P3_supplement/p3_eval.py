"""P3 frozen evaluator: the only code that reads the test split.

For every saved run (runs/<dataset>/<name>.json/.npz) and every task t, on the test examples of the classes seen
by t (class-incremental, one head over the seen classes):
  consolidation:  accuracy of the working model just before sleep and of the stored model after it; fidelity
                  (agreement of the two); certified fidelity under the functional residual bound (Proposition 6;
                  per-class residual norms rounded up to float16); relative residual; the fractions of the change
                  in the separable-gain space S_W and in the tangent space T_W; the largest relative change;
                  stored bits; at the end, accuracy on each task's classes.
  precision (runs R8_task_refit_s*): for each policy (uniform, usage-and-age, certificate-guided, exposure-aware
                  control) and budget (4, 6, 8, 10, 12 bits per log-weight), the stored store's certified
                  retention (Proposition 4 exact test on the stored box), agreement with the full-precision store,
                  accuracy and certified accuracy; allocation and certification times.
  bits per decision (same runs, final task): the smallest uniform width that certifies each test decision, the
                  smallest from which it is always kept, and its log margin.
  dynamic runs (dyn_<policy>_s*): accuracy, agreement with the full-precision refit run of the same seed, and
                  certified retention of the final stored box.
Usage: python3 p3_eval.py <dataset> [run names ...]
"""
import os
import sys
import json
import time
import glob
import numpy as np
import p3lib as L
import p3_run as Rn

BUDGETS = [4, 6, 8, 10, 12]
POLICIES = ["uniform", "usage", "cert", "exposure"]
UNIFORM_LEVELS = list(range(1, 17))


def load_run(path):
    meta = json.load(open(path + ".json"))
    A = dict(np.load(path + ".npz"))
    states = []
    for t in range(len(meta["seen"])):
        def part(p):
            d = {k: A[f"t{t}_{p}_{k}"] for k in ("la", "lb", "corr") if f"t{t}_{p}_{k}" in A}
            return d
        s = {"t": t, "seen": meta["seen"][t], "before": part("before"), "after": part("after"),
             "adapter": {"U": A[f"t{t}_U"], "V": A[f"t{t}_V"]}, "protected": A[f"t{t}_protected"], "use": A[f"t{t}_use"]}
        for k in ("la_q", "lb_q", "rho", "sigma", "bits"):
            if f"t{t}_{k}" in A:
                s[k] = A[f"t{t}_{k}"]
        states.append(s)
    return meta, states


def f16_up(x):
    return np.array([L._f16_up(float(v)) for v in np.atleast_1d(x)])


def residual_certified(Wstored, Wwork, H, seen):
    """Certified fidelity: the working model's decision is the stored model's for every residual with the stored
    per-class norms (Proposition 6)."""
    C = Wstored.shape[0]
    eps = f16_up(np.linalg.norm((Wstored - Wwork).reshape(C, -1), axis=1))
    z = L.scores_dense(Wstored, H)
    hn = np.linalg.norm(H.reshape(len(H), -1), axis=1)
    seen = np.array(sorted(seen))
    zs = np.full_like(z, -np.inf)
    zs[:, seen] = z[:, seen]
    top = np.argmax(zs, axis=1)
    lo_top = z[np.arange(len(H)), top] - eps[top] * hn
    up = z + eps[None, :] * hn[:, None]
    up[:, [c for c in range(C) if c not in seen]] = -np.inf
    up[np.arange(len(H)), top] = -np.inf
    return top, lo_top > up.max(axis=1), eps


def fractions(Wbase_pos, la, lb, dW):
    """|P_S dW| / |dW| and |P_T dW| / |dW| at the positive store (la, lb)."""
    C, P, Ch = dW.shape
    nrm = np.linalg.norm(dW)
    if nrm == 0:
        return 0.0, 0.0
    W = Wbase_pos.reshape(C * P, Ch)
    e1, e2 = L.block_means(dW.reshape(C * P, Ch) / W, W ** 2, iters=2000, tol=1e-14)
    PS = W * (e1[:, None] + e2[None, :])
    _, _, PT = L.tangent_projection(dW, np.exp(la), np.exp(lb), iters=2000, tol=1e-20)
    return float(np.linalg.norm(PS) / nrm), float(np.linalg.norm(PT) / nrm)


RESID_RANKS = [0, 1, 2, 4, 8, 16]


def residual_rank_curve(Wstored, Wwork, H, seen):
    """Keep the r leading Kronecker terms (Van Loan-Pitsianis SVD) of the discarded residual R = Wstored - Wwork
    in float16 and bound the rest by its per-class norms: certified fidelity and agreement of the corrected
    store, and the bits of the kept terms."""
    C, P, Ch = Wstored.shape
    Rm = (Wstored - Wwork).reshape(C * P, Ch)
    u, sv, vt = np.linalg.svd(Rm, full_matrices=False)
    out = []
    pw, _ = L.predict(Wwork, H, seen)
    for r in RESID_RANKS:
        U16 = (u[:, :r] * sv[:r]).astype(np.float16).astype(np.float64)
        V16 = vt[:r].astype(np.float16).astype(np.float64)
        Wc = Wstored - (U16 @ V16).reshape(C, P, Ch)
        top, cert, eps = residual_certified(Wc, Wwork, H, seen)
        out.append({"rank": r, "bits": int(16 * r * (C * P + Ch) + 16 * C), "certified_fidelity": float(np.mean(cert)),
                    "fidelity": float(np.mean(top == pw))})
    return out


def stored_bits(store, n_prot, pixels):
    R, C, P = store["la"].shape
    Ch = store["lb"].shape[1]
    b = {"store": 16 * R * (C * P + Ch), "correction": 32 * C * P * Ch if "corr" in store else 0,
         "protected": 8 * n_prot * pixels}
    b["total"] = sum(b.values())
    return b


def evaluate_consolidation(meta, states, F, floor):
    """A store whose weights are not all finite has diverged: its decisions are undefined (counted as errors,
    never as agreement) and the residual analyses are not computed (None)."""
    Hte, yte = F["Hte"], F["yte"]
    pixels = L.DATASETS[meta["dataset"]]["pixels"]
    rows = []
    for s in states:
        sel = np.isin(yte, s["seen"])
        H, y = Hte[sel], yte[sel]
        with np.errstate(over="ignore", invalid="ignore"):
            Wwork = L.working_dense(s["before"], s["adapter"], floor)
            Wst = L.effective(s["after"])
            Wpos = L.dense(s["before"]["la"], s["before"]["lb"])
        Wb = Wpos + s["before"]["corr"] if "corr" in s["before"] else Wpos
        pw, _ = L.predict(Wwork, H, s["seen"])
        ps, _ = L.predict(Wst, H, s["seen"])
        finite = bool(np.isfinite(Wwork).all() and np.isfinite(Wst).all() and np.isfinite(Wpos).all())
        positive = bool((Wpos > 0).all())         # the published surrogate can underflow weights to zero
        tasks = L.DATASETS[meta["dataset"]]["tasks"]
        per_task_now = [float(np.mean(ps[np.isin(y, cls)] == y[np.isin(y, cls)])) for cls in tasks[:s["t"] + 1]]
        row = {"t": s["t"], "n_test": int(sel.sum()), "finite": finite, "acc_working": float(np.mean(pw == y)),
               "per_task_stored": per_task_now,
               "acc_stored": float(np.mean(ps == y)), "fidelity": float(np.mean((ps == pw) & (ps >= 0))),
               "undefined_stored": float(np.mean(ps < 0)), "undefined_working": float(np.mean(pw < 0)),
               "bits": stored_bits(s["after"], len(s["protected"]), pixels)}
        if finite:
            top, cert, eps = residual_certified(Wst, Wwork, H, s["seen"])
            dW = Wwork - Wb
            fS, fT = fractions(Wpos, s["before"]["la"], s["before"]["lb"], dW) if positive else (None, None)
            pos = Wpos > 0
            curve = residual_rank_curve(Wst, Wwork, H, s["seen"]) if "corr" not in s["after"] else None
            row.update({"residual_rank_curve": curve, "certified_fidelity": float(np.mean(cert & (top == ps))),
                        "certificate_violations": int(np.sum(cert & (top == ps) & (ps != pw))),
                        "rel_residual": float(np.linalg.norm(Wst - Wwork) / max(np.linalg.norm(dW), 1e-300)),
                        "frac_S": fS, "frac_T": fT, "max_rel_change": float(np.max(np.abs(dW[pos]) / Wpos[pos])),
                        "zero_weight_frac": float(np.mean(~pos)),
                        "store_scale": float(np.exp(np.log(np.maximum(Wpos, 1e-300)).mean()))})
        else:
            row.update({"residual_rank_curve": None, "certified_fidelity": 0.0, "rel_residual": None, "frac_S": None,
                        "frac_T": None, "max_rel_change": None, "store_scale": None})
        rows.append(row)
    # end of stream: accuracy per task on the final stored model
    last = states[-1]
    with np.errstate(over="ignore", invalid="ignore"):
        Wst = L.effective(last["after"])
    per_task = []
    for cls in L.DATASETS[meta["dataset"]]["tasks"]:
        sel = np.isin(yte, cls)
        p, _ = L.predict(Wst, Hte[sel], last["seen"])
        per_task.append(float(np.mean(p == yte[sel])))
    # accuracy on the pooled test examples of the earlier tasks (all but the last), for P3.1
    old_cls = [c for cls in L.DATASETS[meta["dataset"]]["tasks"][:-1] for c in cls]
    sel = np.isin(yte, old_cls)
    p, _ = L.predict(Wst, Hte[sel], last["seen"])
    rows[-1]["final_acc_old"] = float(np.mean(p == yte[sel]))
    return rows, per_task


def usage_from(use, t, R, C):
    decayed = sum(Rn.CONFIG["usage_decay"] ** (t - kk) * use[kk] for kk in range(t + 1))
    u = {("class", c): float(decayed[c]) for c in range(C)}
    u.update({("shared", r): float(decayed.sum()) for r in range(R)})
    return u


PRECISION_TASKS = {"mnist": None, "cifar100": [4, 9]}       # None: every sleep


def evaluate_precision(meta, states, F):
    Hte, yte, Htr = F["Hte"], F["yte"], F["Htr"]
    tasks = L.DATASETS[meta["dataset"]]["tasks"]
    which = PRECISION_TASKS[meta["dataset"]]
    out = []
    for s in states:
        if which is not None and s["t"] not in which:
            continue
        la, lb = s["after"]["la"], s["after"]["lb"]
        R, C, _ = la.shape
        sel = np.isin(yte, s["seen"])
        H, y = Hte[sel], yte[sel]
        ref, _ = L.predict(L.dense(la, lb), H, s["seen"])
        usage = usage_from(s["use"], s["t"], R, C)
        Hprot = Htr[s["protected"]]
        sizes = L.unit_sizes(la, lb, s["seen"])
        for bbar in BUDGETS:
            for pol in POLICIES:
                t0 = time.time()
                bits = Rn.allocate(pol, la, lb, bbar, Hprot, s["seen"], usage)
                t_alloc = time.time() - t0
                la_q, lb_q, rho, sigma = L.quantize_store(la, lb, bits)
                t0 = time.time()
                top, cert = L.certify(la_q, lb_q, rho, sigma, H, s["seen"])
                t_cert = time.time() - t0
                meta_bits = len(sizes) * L.META_BITS + (len(sizes) * L.USAGE_BITS if pol == "usage" else 0)
                old = np.isin(y, [c for c in s["seen"] if c not in tasks[s["t"]]])
                out.append({"t": s["t"], "bbar": bbar, "policy": pol,
                            "weight_bits": int(L.weight_bits(bits, sizes)), "meta_bits": int(meta_bits),
                            "budget_bits": int(round(bbar * sum(sizes.values()))) + len(sizes) * L.META_BITS,
                            "certified": float(np.mean(cert)), "agreement": float(np.mean(top == ref)),
                            "accuracy": float(np.mean(top == y)), "certified_accuracy": float(np.mean(cert & (top == y))),
                            "certified_old": float(np.mean(cert[old])) if old.any() else None,
                            "agreement_old": float(np.mean((top == ref)[old])) if old.any() else None,
                            "shared_bits": [int(bits[("shared", r)]) for r in range(R)],
                            "class_bits": [int(bits[("class", c)]) if ("class", c) in bits else None for c in range(C)],
                            "t_alloc": t_alloc, "t_cert": t_cert, "n_test": int(len(y))})
    return out


def bits_per_decision(states, F):
    """Final task: smallest uniform width that certifies each test decision, the smallest from which the stored
    decision always equals the reference, and the reference log margin."""
    Hte, yte = F["Hte"], F["yte"]
    s = states[-1]
    la, lb = s["after"]["la"], s["after"]["lb"]
    sel = np.isin(yte, s["seen"])
    H = Hte[sel]
    ref, z = L.predict(L.dense(la, lb), H, s["seen"])
    lz = np.log(z[:, s["seen"]])
    srt = np.sort(lz, axis=1)
    margin = srt[:, -1] - srt[:, -2]
    n = len(H)
    b_cert = np.full(n, 99)
    kept = np.zeros((len(UNIFORM_LEVELS), n), bool)
    for i, b in enumerate(UNIFORM_LEVELS):
        la_q, lb_q, rho, sigma = L.quantize_store(la, lb, L.alloc_uniform(la, lb, b, s["seen"]))
        top, cert = L.certify(la_q, lb_q, rho, sigma, H, s["seen"])
        b_cert = np.where(cert & (b_cert == 99), b, b_cert)
        kept[i] = top == ref
    b_keep = np.full(n, 99)
    for i in range(len(UNIFORM_LEVELS) - 1, -1, -1):
        ok = kept[i:].all(axis=0)
        b_keep = np.where(ok, UNIFORM_LEVELS[i], b_keep)
    return {"margin": margin, "b_cert": b_cert, "b_keep": b_keep}


def evaluate_dynamic(meta, states, F, ds):
    Hte, yte = F["Hte"], F["yte"]
    s = states[-1]
    stored = {"la": s["la_q"], "lb": s["lb_q"]}
    p, _ = L.predict(L.dense(stored["la"], stored["lb"]), Hte, s["seen"])
    _, fp = load_run(os.path.join("runs", ds, f"R8_task_refit_s{meta['seed']}"))
    pf, _ = L.predict(L.effective(fp[-1]["after"]), Hte, s["seen"])
    top, cert = L.certify(s["la_q"], s["lb_q"], s["rho"], s["sigma"], Hte, s["seen"])
    per_task = []
    for cls in L.DATASETS[meta["dataset"]]["tasks"]:
        sel = np.isin(yte, cls)
        per_task.append(float(np.mean(p[sel] == yte[sel])))
    return {"acc": float(np.mean(p == yte)), "agree_fullprec": float(np.mean(p == pf)),
            "certified_own": float(np.mean(cert)), "per_task": per_task,
            "weight_bits": [int(sum(row[2] * (s["la_q"].shape[0] * s["la_q"].shape[2] if row[0] == 0 else s["lb_q"].shape[1])
                                    for row in st["bits"])) for st in states]}


def main():
    ds = sys.argv[1]
    names = sys.argv[2:] or sorted(os.path.basename(p)[:-5] for p in glob.glob(os.path.join("runs", ds, "*.json")))
    F = L.features(L.load_dataset(ds, with_test=True), Rn.CONFIG["n_filters"], with_test=True)
    os.makedirs(os.path.join("evals", ds), exist_ok=True)
    for name in names:
        out_path = os.path.join("evals", ds, name)
        if os.path.exists(out_path + ".json"):
            continue
        t0 = time.time()
        meta, states = load_run(os.path.join("runs", ds, name))
        res = {"name": name, "meta": {k: v for k, v in meta.items() if k not in ("infos",)}, "infos": meta["infos"]}
        if name.startswith("dyn_"):
            res["dynamic"] = evaluate_dynamic(meta, states, F, ds)
        else:
            rows, per_task = evaluate_consolidation(meta, states, F, Rn.CONFIG["floor"])
            res["consolidation"] = rows
            res["final_per_task"] = per_task
            if name.startswith("R8_task_refit_"):
                res["precision"] = evaluate_precision(meta, states, F)
                bpd = bits_per_decision(states, F)
                np.savez_compressed(out_path + "_bits.npz", **bpd)
        json.dump(res, open(out_path + ".json", "w"), indent=1)
        print(f"{ds} {name}: {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
