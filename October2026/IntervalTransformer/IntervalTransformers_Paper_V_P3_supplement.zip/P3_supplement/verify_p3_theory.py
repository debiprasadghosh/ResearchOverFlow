"""Numerical checks of the P3 propositions (Section 3), float64, seed 20261006.

Store W = sum_r A_r (x) b_r, A_r in R_+^{C x P}, b_r in R_+^{Ch}; M(.) is the (C*P) x Ch rearrangement in which
A (x) b becomes vec(A) b^T.  T1-T10 below follow the propositions of the paper.
"""
import itertools
import numpy as np
import p3lib as L

rng = np.random.default_rng(20261006)
FAILS = []


def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  ({detail})" if detail else ""))
    if not ok:
        FAILS.append(name)


def header(t):
    print("\n" + "=" * 100 + f"\n{t}\n" + "=" * 100)


def rand_store(R, C, P, Ch, s=0.5):
    return rng.normal(np.log(1 / (P * R)), s, (R, C, P)), rng.normal(np.log(1 / Ch), s, (R, Ch))


def adapter(k, C, P, Ch, scale):
    return {"U": scale * rng.normal(0, 1, (k, C, P)), "V": rng.normal(0, 1, (k, Ch)) / np.sqrt(Ch)}


def pub_update(la, lb, dW, alpha):
    C, P, Ch = dW.shape
    u, s, v = L.nearest_kronecker(dW.reshape(C * P, Ch))
    c1 = np.maximum(np.abs(u), 1e-300).reshape(C, P)
    c2 = np.maximum(np.abs(v), 1e-300)
    return la + alpha * np.log(c1)[None], lb + alpha * np.log(c2)[None], u, v


# -------------------------------------------------------------------------------------------------------------
header("T1  Proposition 1: the published rule (unit-norm nearest-Kronecker factors, log update)")
R, C, P, Ch = 3, 10, 36, 32
la, lb = rand_store(R, C, P, Ch)
W = L.dense(la, lb)
ad = adapter(4, C, P, Ch, 1e-3)
dW = np.einsum("jcp,jh->cph", ad["U"], ad["V"])
a1, b1, u1, v1 = pub_update(la, lb, dW, 1.0)
a2, b2, u2, v2 = pub_update(la, lb, 10.0 * dW, 1.0)
d = max(np.abs(a1 - a2).max(), np.abs(b1 - b2).max())
check("(a) consolidating 10 dW instead of dW changes nothing", d < 1e-12, f"max difference {d:.1e}")
# (b) undefined fraction
best = min((1 - (sg * u1 > 0).mean() * (sg * v1 > 0).mean()) for sg in (1, -1))
direct = min(np.mean(~((sg * u1 > 0)[:, None] & (sg * v1 > 0)[None, :])) for sg in (1, -1))
check("(b) undefined base fraction = 1 - f1 f2 for the better sign", abs(best - direct) < 1e-15,
      f"{best:.4f} of base entries undefined")
# (c) mean log-weight falls by at least (alpha/2) log(n1 n2), any dW
worst = np.inf
for trial in range(300):
    ad = adapter(rng.integers(1, 6), C, P, Ch, 10 ** rng.uniform(-4, 1))
    dW = np.einsum("jcp,jh->cph", ad["U"], ad["V"])
    alpha = rng.uniform(0.05, 1.0)
    a1, b1, _, _ = pub_update(la, lb, dW, alpha)
    drop = np.log(L.dense(la, lb)).mean() - np.log(L.dense(a1, b1)).mean()
    bound = 0.5 * alpha * np.log(C * P * Ch)
    worst = min(worst, drop - bound)
check("(c) |C| surrogate lowers the mean log-weight by >= (alpha/2) log(n1 n2) (300 random adapters)", worst >= -1e-9,
      f"min(drop - bound) = {worst:.3e}; bound at alpha=1: {0.5 * np.log(C * P * Ch):.3f} nats")
c1 = np.full(C * P, 1 / np.sqrt(C * P))
check("(c) equality when |C1|, |C2| are flat", abs(np.log(c1).mean() + 0.5 * np.log(C * P)) < 1e-12)
# (d) no log-weight ever increases: the factors are unit vectors, so log|C| <= 0 entrywise
worst = -np.inf
for trial in range(300):
    ad = adapter(rng.integers(1, 6), C, P, Ch, 10 ** rng.uniform(-4, 1))
    dW = np.einsum("jcp,jh->cph", ad["U"], ad["V"])
    alpha = rng.uniform(0.05, 1.0)
    a1, b1, _, _ = pub_update(la, lb, dW, alpha)
    worst = max(worst, (a1 - la).max(), (b1 - lb).max())
check("(d) the |C| surrogate never raises any log-weight (300 random adapters)", worst <= 1e-12,
      f"largest increase {worst:.2e}")
# (e) a class whose adapter rows are zero (a class not yet seen) gets C1 = 0 on all its rows: annihilated
ad = adapter(4, C, P, Ch, 1e-2)
ad["U"][:, 5:, :] = 0.0
dW = np.einsum("jcp,jh->cph", ad["U"], ad["V"])
u, s, v = L.nearest_kronecker(dW.reshape(C * P, Ch))
rows_unseen = np.abs(u.reshape(C, P)[5:]).max()
check("(e) zero adapter rows give C1 = 0 on those rows (u = M v / sigma), so the surrogate sends the class to zero",
      rows_unseen < 1e-14, f"max |C1| on the zero rows {rows_unseen:.1e}; on the others "
      f"{np.abs(u.reshape(C, P)[:5]).max():.2e}")

# -------------------------------------------------------------------------------------------------------------
header("T2  Proposition 2(a): ordinary block means of the exact log ratio")
for R in (1, 3):
    la, lb = rand_store(R, C, P, Ch)
    W = L.dense(la, lb)
    g1 = rng.normal(0, 0.7, (C, P))
    g2 = rng.normal(0, 0.7, Ch)
    target = W * np.exp(g1[:, :, None] + g2[None, None, :])
    D = np.log(target / W).reshape(C * P, Ch)
    e1, e2 = L.block_means(D)
    Wn = W * np.exp(e1.reshape(C, P)[:, :, None] + e2[None, None, :])
    err = np.linalg.norm(Wn - target) / np.linalg.norm(target)
    check(f"R={R}: a separable gain of any size is recovered exactly", err < 1e-12, f"relative error {err:.1e}")
# R = 1: global log-space LS best positive rank-1 product
la, lb = rand_store(1, 4, 5, 6)
W = L.dense(la, lb)
T = np.exp(rng.normal(-3, 1.0, W.shape))
D = np.log(T / W).reshape(20, 6)
e1, e2 = L.block_means(D)
Lg = (la[0][:, :, None] + lb[0][None, None, :]).reshape(20, 6) + e1[:, None] + e2[None, :]
X = np.zeros((120, 26))
for i in range(20):
    for j in range(6):
        X[i * 6 + j, i] = 1
        X[i * 6 + j, 20 + j] = 1
coef = np.linalg.lstsq(X, np.log(T).reshape(-1), rcond=None)[0]
Lls = (X @ coef).reshape(20, 6)
check("R=1: the result is the least-squares best log(a_i) + log(b_j) fit of log T (global, not first order)",
      np.abs(Lg - Lls).max() < 1e-10, f"max difference {np.abs(Lg - Lls).max():.1e}")

# -------------------------------------------------------------------------------------------------------------
header("T3  Proposition 2(b): weighted block means; first-order version = Frobenius projection onto S_W")
C2, P2, Ch2 = 4, 5, 6
la, lb = rand_store(1, C2, P2, Ch2)
a = np.exp(la[0]).reshape(-1)
b = np.exp(lb[0])
Wm = np.outer(a, b)
D = rng.normal(0, 0.5, Wm.shape)
e1, e2 = L.block_means(D, Wm ** 2, iters=5000, tol=0)
pi = a ** 2 / (a ** 2).sum()
om = b ** 2 / (b ** 2).sum()
mu = pi @ D @ om
c1 = D @ om - mu / 2
c2 = pi @ D - mu / 2
fit_bf = e1[:, None] + e2[None, :]
fit_cf = c1[:, None] + c2[None, :]
check("R=1: backfitting equals Paper II's closed form (Eq. 14)", np.abs(fit_bf - fit_cf).max() < 1e-10,
      f"max difference {np.abs(fit_bf - fit_cf).max():.1e}")
# Frobenius projection: dW -> W (.) (e1 (+) e2) with D1 = dW / W equals orthogonal projection on span{W (.) (x (+) y)}
for R in (1, 2):
    la, lb = rand_store(R, C2, P2, Ch2)
    W = L.dense(la, lb).reshape(C2 * P2, Ch2)
    dWm = rng.normal(0, 1e-3, W.shape)
    e1, e2 = L.block_means(dWm / W, W ** 2, iters=20000, tol=0)
    proj_gain = W * (e1[:, None] + e2[None, :])
    basis = []
    for i in range(C2 * P2):
        Z = np.zeros_like(W)
        Z[i, :] = W[i, :]
        basis.append(Z.reshape(-1))
    for j in range(Ch2):
        Z = np.zeros_like(W)
        Z[:, j] = W[:, j]
        basis.append(Z.reshape(-1))
    Bm = np.array(basis).T
    coef = np.linalg.lstsq(Bm, dWm.reshape(-1), rcond=None)[0]
    proj_ls = (Bm @ coef).reshape(W.shape)
    err = np.abs(proj_gain - proj_ls).max() / np.abs(proj_ls).max()
    check(f"R={R}: weighted means of dW/W give the Frobenius projection onto S_W", err < 1e-8, f"relative difference {err:.1e}")

# -------------------------------------------------------------------------------------------------------------
header("T4  Proposition 2(c): S_W is a strict subspace of the tangent space for R > 1")
for R in (1, 2, 3):
    la, lb = rand_store(R, C2, P2, Ch2)
    A, bb = np.exp(la), np.exp(lb)
    W = L.dense(la, lb)
    S = []
    for i in range(C2 * P2):
        Z = np.zeros(C2 * P2 * Ch2).reshape(C2 * P2, Ch2)
        Z[i, :] = W.reshape(C2 * P2, Ch2)[i, :]
        S.append(Z.reshape(-1))
    for j in range(Ch2):
        Z = np.zeros((C2 * P2, Ch2))
        Z[:, j] = W.reshape(C2 * P2, Ch2)[:, j]
        S.append(Z.reshape(-1))
    T = []
    for r in range(R):
        for i in range(C2 * P2):
            E = np.zeros((C2 * P2,))
            E[i] = 1
            T.append(np.outer(E, bb[r]).reshape(-1))
        for j in range(Ch2):
            f = np.zeros(Ch2)
            f[j] = 1
            T.append(np.outer(A[r].reshape(-1), f).reshape(-1))
    rS = np.linalg.matrix_rank(np.array(S))
    rT = np.linalg.matrix_rank(np.array(T))
    rST = np.linalg.matrix_rank(np.array(S + T))
    check(f"R={R}: dim S_W = {rS} (CP+Ch-1 = {C2 * P2 + Ch2 - 1}), dim T_W = {rT} (R(CP+Ch-R) = {R * (C2 * P2 + Ch2 - R)}), S_W in T_W",
          rS == C2 * P2 + Ch2 - 1 and rT == R * (C2 * P2 + Ch2 - R) and rST == rT)
# the conjugate-gradient tangent projection equals the dense least-squares projection
la, lb = rand_store(3, C2, P2, Ch2)
A, bb = np.exp(la), np.exp(lb)
M = rng.normal(0, 1, (C2, P2, Ch2))
E, f, PT = L.tangent_projection(M, A, bb, iters=5000, tol=1e-30)
T = []
for r in range(3):
    for i in range(C2 * P2):
        e_ = np.zeros(C2 * P2)
        e_[i] = 1
        T.append(np.outer(e_, bb[r]).reshape(-1))
    for j in range(Ch2):
        f_ = np.zeros(Ch2)
        f_[j] = 1
        T.append(np.outer(A[r].reshape(-1), f_).reshape(-1))
Tm = np.array(T).T
coef = np.linalg.lstsq(Tm, M.reshape(-1), rcond=None)[0]
err = np.abs(PT.reshape(-1) - Tm @ coef).max()
check("conjugate-gradient tangent projection = dense least squares (R=3)", err < 1e-8, f"max difference {err:.1e}")

# -------------------------------------------------------------------------------------------------------------
header("T5  Proposition 2(d): factor-level first-order means for R = 1")
C3, P3, Ch3, k = 10, 36, 32, 5
la, lb = rand_store(1, C3, P3, Ch3)
a = np.exp(la[0])
b = np.exp(lb[0])
U = rng.normal(0, 1e-3, (k, C3, P3))
V = rng.normal(0, 1, (k, Ch3))
dW = np.einsum("jcp,jh->cph", U, V)
Wm = np.einsum("cp,h->cph", a, b)
D1 = (dW / Wm).reshape(C3 * P3, Ch3)
pi = (a ** 2).reshape(-1) / (a ** 2).sum()
om = b ** 2 / (b ** 2).sum()
mu = pi @ D1 @ om
dense_e1 = D1 @ om - mu / 2
# factor level: D1 = sum_t (U_t / a) (x) (V_t / b)
X = (U / a[None]).reshape(k, -1)
Y = V / b[None]
fac_e1 = X.T @ (Y @ om) - (pi @ X.T) @ (Y @ om) / 2
check("first-order weighted means from the factors equal the dense computation", np.abs(fac_e1 - dense_e1).max() < 1e-10,
      f"max difference {np.abs(fac_e1 - dense_e1).max():.1e}; work O(k(CP+Ch)) = {k * (C3 * P3 + Ch3)} vs dense {C3 * P3 * Ch3}")

# -------------------------------------------------------------------------------------------------------------
header("T6  Proposition 3: first-order rules need a relative-change bound")
la, lb = rand_store(1, C2, P2, Ch2)
store = {"la": la, "lb": lb}
W = L.dense(la, lb)
res = {}
for eps in (1e-2, 5e-3, 2.5e-3, 1.25e-3):
    G = rng.normal(0, 1, (2, C2, P2))
    Hh = rng.normal(0, 1, (2, Ch2))
    dWt = W * np.einsum("jcp,jh->cph", G, Hh) * eps / 3            # relative change of order eps
    out = []
    for rule in ("gain_w", "gain_w1", "tan"):
        Wwork = W + dWt
        # emulate an adapter producing exactly dWt (rank <= C2*P2): put it into U, V via SVD
        u, s, vt = np.linalg.svd(dWt.reshape(C2 * P2, Ch2), full_matrices=False)
        ad = {"U": (u * s).T.reshape(-1, C2, P2), "V": vt}
        new, info = L.sleep(rule, store, ad, floor=1e-9)
        out.append(L.dense(new["la"], new["lb"]))
    res[eps] = max(np.abs(out[0] - out[2]).max(), np.abs(out[1] - out[2]).max()) / np.abs(dWt).max()
ratios = [res[e] / e for e in res]
check("R=1, small relative change eps: gain_w, gain_w1 and tan agree to O(eps^2)",
      max(ratios) / min(ratios) < 3 and max(ratios) < 10,
      "differences / (max |dW|) = " + ", ".join(f"{res[e]:.2e} at eps={e:g}" for e in res))
e = np.array([0.1, 1.0, 5.0, 40.0])
err = np.abs(np.exp(e) - 1 - e)
bnd = e ** 2 / 2 * np.exp(np.abs(e))
check("|exp(e) - 1 - e| <= (e^2/2) e^|e|; the realisation error of e = 40 is 2.4e17 times the weight",
      np.all(err <= bnd), ", ".join(f"e={x:g}: {y:.3g}" for x, y in zip(e, err)))

# -------------------------------------------------------------------------------------------------------------
header("T7  Proposition 4: exact decision test (class rows at corners, shared vectors by the threshold rule)")
worst = 0.0
npairs = 0
for trial in range(150):
    R, C, P, Ch = 2, 3, 3, 3
    la, lb = rng.normal(0, 1, (R, C, P)), rng.normal(0, 1, (R, Ch))
    H = np.abs(rng.normal(0, 1, (3, Ch, P))) * (rng.random((3, Ch, P)) < 0.7)
    rho = rng.uniform(0, 0.3, C)
    sigma = rng.uniform(0, 0.3, R)
    top, m = L.shared_margins(la, lb, sigma, H, range(C))
    for n in range(3):
        for c in range(C):
            if c == top[n]:
                continue
            # brute force over every vertex of the full box: class rows of top and c, and the shared entries
            best = -np.inf
            for ds in itertools.product([-1, 1], repeat=R * Ch):
                dsh = np.array(ds).reshape(R, Ch) * sigma[:, None]
                for st in (-1, 1):
                    for sc in (-1, 1):
                        la2 = la.copy()
                        la2[:, top[n], :] += st * rho[top[n]]
                        la2[:, c, :] += sc * rho[c]
                        g = L.term_contributions(la2, lb + dsh, H[n:n + 1])[0]
                        best = max(best, np.log(g[c].sum() / g[top[n]].sum()))
            exact = -(m[n, c] - rho[top[n]] - rho[c])
            worst = max(worst, abs(best - exact))
            npairs += 1
check("max over the box of log(z_c/z_top) equals the threshold-rule value", worst < 1e-12,
      f"{npairs} pairs, max difference {worst:.1e}")
# random interior points never beat the vertex value
viol = 0
for trial in range(50):
    R, C, P, Ch = 3, 4, 5, 4
    la, lb = rng.normal(0, 1, (R, C, P)), rng.normal(0, 1, (R, Ch))
    H = np.abs(rng.normal(0, 1, (5, Ch, P)))
    rho = rng.uniform(0, 0.2, C)
    sigma = rng.uniform(0, 0.2, R)
    top, m = L.shared_margins(la, lb, sigma, H, range(C))
    for _ in range(200):
        la2 = la + rng.uniform(-1, 1, la.shape) * rho[None, :, None]
        lb2 = lb + rng.uniform(-1, 1, lb.shape) * sigma[:, None]
        g = L.term_contributions(la2, lb2, H).sum(axis=(2, 3))
        for n in range(5):
            for c in range(C):
                if c != top[n] and np.log(g[n, c] / g[n, top[n]]) > -(m[n, c] - rho[top[n]] - rho[c]) + 1e-12:
                    viol += 1
check("10,000 random members of the box never exceed the exact worst case", viol == 0, f"{viol} violations")

# -------------------------------------------------------------------------------------------------------------
header("T8  Proposition 5: stored boxes, certified decisions, repeated rounding")
worst = 0.0
for trial in range(2000):
    v = rng.normal(rng.uniform(-12, 0), rng.uniform(0.01, 3), rng.integers(2, 300))
    bits = int(rng.integers(0, 16))
    q, rad = L.quantize_values(v, bits)
    worst = max(worst, np.max(np.abs(v - q)) - rad)
check("every reference log-weight lies within the rounding radius of its stored value (2,000 units, 0-15 bits)",
      worst <= 1e-12, f"max excess {worst:.1e}")
# certified decisions survive every sampled member of the stored box
R, C, P, Ch = 3, 6, 8, 5
la, lb = rand_store(R, C, P, Ch, s=1.0)
H = np.abs(rng.normal(0, 1, (300, Ch, P)))
flips = 0
cert_total = 0
for bbar in (4, 6, 8):
    bits = L.alloc_uniform(la, lb, bbar)
    la_q, lb_q, rho, sigma = L.quantize_store(la, lb, bits)
    top, cert = L.certify(la_q, lb_q, rho, sigma, H, range(C))
    ref, _ = L.predict(L.dense(la, lb), H, range(C))
    cert_total += cert.sum()
    flips += int(np.sum(cert & (top != ref)))
    for _ in range(100):
        la2 = la_q + rng.uniform(-1, 1, la.shape) * rho[None, :, None]
        lb2 = lb_q + rng.uniform(-1, 1, lb.shape) * sigma[:, None]
        p2, _ = L.predict(L.dense(la2, lb2), H, range(C))
        flips += int(np.sum(cert & (p2 != top)))
check("certified decisions equal the reference decision and survive 300 sampled box members", flips == 0,
      f"{cert_total} certified decisions, {flips} changes")
# repeated rounding on different grids: accumulated radius bounds the drift
v0 = rng.normal(-5, 1, 500)
v = v0.copy()
acc = 0.0
for bits in (12, 9, 7, 5):
    v, rad = L.quantize_values(v, bits)
    acc += rad
check("after four re-roundings the drift is within the summed radii", np.max(np.abs(v - v0)) <= acc + 1e-12,
      f"drift {np.max(np.abs(v - v0)):.4f} <= sum of radii {acc:.4f}")

# -------------------------------------------------------------------------------------------------------------
header("T9  Proposition 6: the functional residual bound")
viol = 0
att = 0.0
for trial in range(500):
    Rc = rng.normal(0, 1, (8, 12))
    Hh = np.abs(rng.normal(0, 1, (8, 12)))
    lhs = abs((Rc * Hh).sum())
    rhs = np.linalg.norm(Rc) * np.linalg.norm(Hh)
    viol += lhs > rhs + 1e-12
    Ra = np.linalg.norm(Rc) * Hh / np.linalg.norm(Hh)
    att = max(att, abs((Ra * Hh).sum() - rhs))
check("|<R_c, H>| <= ||R_c|| ||H||, attained by R_c parallel to H", viol == 0 and att < 1e-10,
      f"{viol} violations; attainment error {att:.1e}")

# -------------------------------------------------------------------------------------------------------------
header("T10  Usage-and-age and certificate-guided allocations respect the budget")
R, C, P, Ch = 8, 10, 36, 32
la, lb = rand_store(R, C, P, Ch, s=1.0)
sizes = L.unit_sizes(la, lb)
H = np.abs(rng.normal(0, 0.1, (200, Ch, P)))
ok = True
for bbar in (4, 6, 8, 10):
    B = int(bbar * sum(sizes.values()))
    usage = {u: float(rng.uniform(1, 1e5)) for u in sizes}
    b1 = L.alloc_usage(la, lb, B - len(sizes) * L.USAGE_BITS, usage)
    b2 = L.alloc_certificate(la, lb, B, H, range(C))
    ok &= L.weight_bits(b1, sizes) <= B - len(sizes) * L.USAGE_BITS and L.weight_bits(b2, sizes) <= B
    # the certificate greedy leaves less than one class unit unspent (or every class unit is at 16 bits)
    left = B - L.weight_bits(b2, sizes)
    ok &= left < R * P or all(b2[("class", c)] == 16 for c in range(C))
check("weight bits never exceed the budget; the certificate greedy leaves less than one class unit unspent", ok)

# the vectorised one-step gains of the certificate objective equal brute-force re-evaluation, for every class
cache = L.MarginCache(la, lb, H, range(C), K=3)
worst = 0.0
for trial in range(40):
    sigma = rng.uniform(0, 0.05, R)
    m_exact, m_rest = cache.margins(sigma)
    M = np.concatenate([m_exact, m_rest], axis=1)
    comp = np.concatenate([cache.comp, cache.rest_comp], axis=1)
    rho = rng.uniform(0, 0.3, C)
    delta = rho * rng.uniform(0, 1, C) * (rng.uniform(0, 1, C) < 0.8)
    lam = 1e-3
    gain, cur = L.cert_gains(M, cache.top, comp, rho, delta, lam, C)

    def obj(r):
        sl = cache.slack((m_exact, m_rest), r)
        return float(np.sum((sl > 0) + lam * np.minimum(sl, 0)))
    worst = max(worst, abs(cur - obj(rho)))
    for c in range(C):
        r2 = rho.copy()
        r2[c] -= delta[c]
        worst = max(worst, abs(gain[c] - (obj(r2) - obj(rho))))
check("exact one-step gains of the certificate objective equal brute-force re-evaluation (40 states x 10 classes)",
      worst < 1e-9, f"max difference {worst:.1e}")

# starvation: a class that never decides any protected example still receives bits once it binds
R, C, P, Ch = 2, 6, 5, 4
la, lb = rand_store(R, C, P, Ch, s=0.3)
la[:, 5, :] -= 2.0                                  # class 5 is always far below the others: never the decision
H = np.abs(rng.normal(0, 1, (300, Ch, P)))
sizes = L.unit_sizes(la, lb)
top0, _ = L.predict(L.dense(la, lb), H, range(C))
bits = L.alloc_certificate(la, lb, int(8 * sum(sizes.values())), H, range(C))
check("a class that is never the decision is not starved (it gets more than the minimum width)",
      (top0 != 5).all() and bits[("class", 5)] > 1, f"class-5 bits {bits[('class', 5)]}; "
      f"widths {[bits[('class', c)] for c in range(C)]}")

print("\n" + ("ALL CHECKS PASSED" if not FAILS else f"FAILED: {FAILS}"))
