"""Precision smoke test on VALIDATION data (never the test split): cert allocation fix check."""
import sys, os, time
sys.path.insert(0, '/home/claude/p3'); os.chdir('/home/claude/p3')
import numpy as np, p3lib as L, p3_run as Rn, p3_eval as E

SM = '/tmp/claude-0/-home-claude/b1005625-5540-5259-9589-d77b2a34b4a6/scratchpad/p3smoke'
ds = sys.argv[1]
name = sys.argv[2]
ts = [int(x) for x in sys.argv[3].split(',')]
budgets = [int(x) for x in sys.argv[4].split(',')]
F = L.features(L.load_dataset(ds), 16)
meta, states = E.load_run(os.path.join(SM, name))
Hva, yva, Htr = F['Hva'], F['yva'], F['Htr']
tasks = L.DATASETS[ds]['tasks']
for t in ts:
    s = states[t]
    la, lb = s['after']['la'], s['after']['lb']
    R, C, _ = la.shape
    sel = np.isin(yva, s['seen'])
    H, y = Hva[sel], yva[sel]
    ref, _ = L.predict(L.dense(la, lb), H, s['seen'])
    usage = E.usage_from(s['use'], t, R, C)
    Hprot = Htr[s['protected']]
    sizes = L.unit_sizes(la, lb, s['seen'])
    old = np.isin(y, [c for c in s['seen'] if c not in tasks[t]])
    print(f"t={t} seen={len(s['seen'])} nval={len(y)} ref acc {np.mean(ref == y):.3f}", flush=True)
    for bbar in budgets:
        for pol in E.POLICIES:
            t0 = time.time()
            bits = Rn.allocate(pol, la, lb, bbar, Hprot, s['seen'], usage)
            ta = time.time() - t0
            la_q, lb_q, rho, sigma = L.quantize_store(la, lb, bits)
            t0 = time.time()
            top, cert = L.certify(la_q, lb_q, rho, sigma, H, s['seen'])
            tc = time.time() - t0
            cb = [bits[('class', c)] for c in s['seen']]
            sb = [bits[('shared', r)] for r in range(R)]
            print(f"  b{bbar:2d} {pol:9s} cert {np.mean(cert):.3f} agree {np.mean(top == ref):.3f} acc {np.mean(top == y):.3f}"
                  f" cert_old {np.mean(cert[old]) if old.any() else float('nan'):.3f}"
                  f" wbits {L.weight_bits(bits, sizes)}/{int(round(bbar * sum(sizes.values())))}"
                  f" class bits [{min(cb)},{max(cb)}] mean {np.mean(cb):.2f} shared {sb[0]}  t_alloc {ta:.1f}s t_cert {tc:.1f}s",
                  flush=True)
