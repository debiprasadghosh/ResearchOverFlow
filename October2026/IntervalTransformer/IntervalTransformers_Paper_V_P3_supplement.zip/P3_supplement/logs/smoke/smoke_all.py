"""End-to-end smoke test of p3_run + p3_eval on VALIDATION data only (the evaluator is pointed at Hva/yva).
Writes to the scratchpad; never reads the test split."""
import sys, os, time, json
sys.path.insert(0, '/home/claude/p3'); os.chdir('/home/claude/p3')
import numpy as np, p3lib as L, p3_run as Rn, p3_eval as E

OUT = '/tmp/claude-0/-home-claude/b1005625-5540-5259-9589-d77b2a34b4a6/scratchpad/p3smoke2'
os.makedirs(OUT, exist_ok=True)
ds = sys.argv[1]
jobs = sys.argv[2].split(';')          # e.g. "8,task,none;8,task,pub;1,task,gain_w;8,10,refit;dyn,cert"
F = Rn.feats(ds)
Fv = dict(F)
Fv['Hte'], Fv['yte'] = F['Hva'], F['yva']
for job in jobs:
    parts = job.split(',')
    t0 = time.time()
    if parts[0] == 'dyn':
        pol = parts[1]
        states, infos, secs = Rn.run_stream(ds, 8, 'task', 'refit', 0, policy=pol, bbar=8)
        name = f'{ds}_dyn_{pol}_s0'
        Rn.save_run(os.path.join(OUT, name), states, infos, {'dataset': ds, 'R': 8, 'cadence': 'task', 'rule': 'refit',
                                                             'seed': 0, 'policy': pol, 'bbar': 8, 'seconds': secs})
        meta, st = E.load_run(os.path.join(OUT, name))
        s = st[-1]
        p, _ = L.predict(L.dense(s['la_q'], s['lb_q']), Fv['Hte'], s['seen'])
        top, cert = L.certify(s['la_q'], s['lb_q'], s['rho'], s['sigma'], Fv['Hte'], s['seen'])
        print(f'{name}: run {secs:.0f}s  final acc {np.mean(p == Fv["yte"]):.3f} certified {np.mean(cert):.3f}', flush=True)
        continue
    R, cad, rule = int(parts[0]), parts[1], parts[2]
    states, infos, secs = Rn.run_stream(ds, R, cad, rule, 0)
    name = f'{ds}_R{R}_{cad}_{rule}_s0'
    Rn.save_run(os.path.join(OUT, name), states, infos, {'dataset': ds, 'R': R, 'cadence': cad, 'rule': rule, 'seed': 0,
                                                         'seconds': secs})
    meta, st = E.load_run(os.path.join(OUT, name))
    t1 = time.time()
    rows, per_task = E.evaluate_consolidation(meta, st, Fv, Rn.CONFIG['floor'])
    te = time.time() - t1
    r = rows[-1]
    curve = r['residual_rank_curve']
    f = lambda x, d=3: 'None' if x is None else f"{x:.{d}f}"
    print(f"{name}: run {secs:.0f}s eval {te:.0f}s | finite {r['finite']} final: work {f(r['acc_working'])} stored {f(r['acc_stored'])} "
          f"fid {f(r['fidelity'])} cfid {f(r['certified_fidelity'])} relres {f(r['rel_residual'])} "
          f"fS {f(r['frac_S'])} fT {f(r['frac_T'])} maxrel {f(r['max_rel_change'], 1)} "
          f"curve {[round(c['certified_fidelity'], 3) for c in curve] if curve else None} "
          f"per-task {[round(x, 3) for x in per_task]}", flush=True)
    print('   infos last:', {k: (round(v, 4) if isinstance(v, float) else v) for k, v in infos[-1].items()
                             if not isinstance(v, list)}, flush=True)
