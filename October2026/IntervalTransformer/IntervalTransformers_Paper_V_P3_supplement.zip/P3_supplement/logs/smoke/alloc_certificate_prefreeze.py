# Pre-freeze certificate-guided allocation (lazy greedy), lines 782-850 of p3lib.py as read at
# 2026-10-05T04:01:05Z, before it was replaced (04:02:45Z) and before the freeze (04:21:17Z).
# Extracted verbatim from the session transcript; no pre-freeze copy of p3lib.py was kept.

def alloc_certificate(la, lb, budget, Hprot, seen, bmin=1, bmax=16, lam=1e-3, shared_levels=range(1, 17), K=8):
    """Certificate-guided precision.  For each common bit width s of the shared channel vectors, compute the
    shared-box margins of the protected examples once, then give the remaining budget to the class units
    greedily, one bit at a time, maximising (certified protected examples + lam * total slack of the
    uncertified) per bit spent (lazy evaluation of the gains).  Keep the best s.  Certificates use the
    reference values with the rounding radii of the candidate allocation; the stored values are evaluated
    exactly afterwards."""
    import heapq
    sizes = unit_sizes(la, lb, seen)
    R, C, P = la.shape
    cache = MarginCache(la, lb, Hprot, seen, K)
    cls_units = [("class", c) for c in sorted(seen)]
    sh_units = [("shared", r) for r in range(R)]
    spans = {}
    for kind, i, v in units(la, lb, seen):
        spans[(kind, i)] = _f16_up(float(v.max())) - _f16_down(float(v.min()))

    def rad(u, b):
        return 0.5 * spans[u] if b <= 0 else 0.5 * spans[u] / (2 ** b - 1)

    best = None
    for s_bits in shared_levels:
        bits = {u: bmin for u in cls_units}
        bits.update({u: s_bits for u in sh_units})
        left = budget - weight_bits(bits, sizes)
        if left < 0:
            continue
        sigma = np.array([rad(u, s_bits) for u in sh_units])
        m = cache.margins(sigma)

        def score(rho):
            sl = cache.slack(m, rho)
            return float((sl > 0).sum()) + lam * float(np.minimum(sl, 0).sum())

        rho = np.zeros(C)
        for u in cls_units:
            rho[u[1]] = rad(u, bits[u])
        cur = score(rho)

        def gain(c):
            u = ("class", c)
            old = rho[c]
            rho[c] = rad(u, bits[u] + 1)
            g = (score(rho) - cur) / sizes[u]
            rho[c] = old
            return g

        heap = [(-gain(u[1]), u[1]) for u in cls_units if bits[u] < bmax]
        heapq.heapify(heap)
        while heap:
            negg, c = heapq.heappop(heap)
            u = ("class", c)
            if bits[u] >= bmax or sizes[u] > left:
                continue
            g = gain(c)
            if heap and g < -heap[0][0] - 1e-15:
                heapq.heappush(heap, (-g, c))
                continue
            bits[u] += 1
            left -= sizes[u]
            rho[c] = rad(u, bits[u])
            cur = score(rho)
            if bits[u] < bmax:
                heapq.heappush(heap, (-gain(c), c))
        if best is None or cur > best[0]:
            best = (cur, dict(bits))
    return best[1]
