"""P3 library: a positive Kronecker memory on fixed features, wake adapters, sleep rules, stored precision,
exact decision tests.

Memory.  Features H(x) in R_+^{Ch x P} (channels x positions) come from a fixed random convolution layer with a
reflection pair.  The long-term store is a positive Kronecker sum
    W[c, p, h] = sum_r A_r[c, p] * b_r[h],     A_r in R_+^{C x P},  b_r in R_+^{Ch},
held as logarithms (la, lb).  Class scores are z_c = sum_{p,h} W[c,p,h] H[h,p] > 0, and the training logits are
SCALE * log z_c over the classes seen so far.

Wake.  A real Kronecker adapter dW[c,p,h] = sum_j U_j[c,p] V_j[h] is trained on the current task plus stored
protected examples (replay); the working weight is W_work = max(W + dW, FLOOR * W) entrywise.

Sleep.  A sleep rule maps (store, adapter) to a new store, and possibly a retained correction.
"""
import os
import gzip
import time
import hashlib
import pickle
import numpy as np

os.environ.setdefault("XLA_FLAGS", "--xla_cpu_multi_thread_eigen=false intra_op_parallelism_threads=1")
import jax  # noqa: E402
import jax.numpy as jnp  # noqa: E402

jax.config.update("jax_enable_x64", False)

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")
F32 = np.float32

MNIST_FILES = {"train_images": "train-images-idx3-ubyte.gz", "train_labels": "train-labels-idx1-ubyte.gz",
               "test_images": "t10k-images-idx3-ubyte.gz", "test_labels": "t10k-labels-idx1-ubyte.gz"}
MNIST_MD5 = {"train_images": "f68b3c2dcbeaaa9fbdd348bbdeb94873", "train_labels": "d53e105ee54ea40749a09fcbcd1e9432",
             "test_images": "9fb629c4189551a2d022fa330f9573f3", "test_labels": "ec29112dd5afa0611ce80d1b7f02629c"}
CIFAR_MD5 = {"data_batch_1": "c99cafc152244af753f735de768cd75f", "data_batch_2": "d4bba439e000b95fd0a9bffe97cbabec",
             "data_batch_3": "54ebc095f3ab1f0389bbae665268c751", "data_batch_4": "634d18415352ddfa80567beed471001a",
             "data_batch_5": "482c414d41f54cd18b22e5b47cb7c3cb", "test_batch": "40351d587109b95175f43aff81a1287e"}
SPLIT_SEED = 20261004          # the P1 split of MNIST: 55,000 / 5,000 / 10,000
FEATURE_SEED = 20261005        # random convolution filters


# ---------------------------------------------------------------------------------------------------------------
# data and features
# ---------------------------------------------------------------------------------------------------------------
def _md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def _idx_images(path):
    raw = gzip.open(path, "rb").read()
    n, r, c = (int.from_bytes(raw[i:i + 4], "big") for i in (4, 8, 12))
    return np.frombuffer(raw, np.uint8, offset=16).reshape(n, r, c)


def _idx_labels(path):
    return np.frombuffer(gzip.open(path, "rb").read(), np.uint8, offset=8).astype(np.int64)


def load_mnist(with_test=False):
    for k, fn in MNIST_FILES.items():
        if k.startswith("test") and not with_test:
            continue
        if _md5(os.path.join(DATA, fn)) != MNIST_MD5[k]:
            raise ValueError(f"{fn}: md5 mismatch")
    X = _idx_images(os.path.join(DATA, MNIST_FILES["train_images"])).astype(F32) / F32(255)
    y = _idx_labels(os.path.join(DATA, MNIST_FILES["train_labels"]))
    perm = np.random.default_rng(SPLIT_SEED).permutation(60000)
    tr, va = np.sort(perm[:55000]), np.sort(perm[55000:])
    out = {"Xtr": X[tr], "ytr": y[tr], "Xva": X[va], "yva": y[va], "channels_in": 1}
    if with_test:
        out["Xte"] = _idx_images(os.path.join(DATA, MNIST_FILES["test_images"])).astype(F32) / F32(255)
        out["yte"] = _idx_labels(os.path.join(DATA, MNIST_FILES["test_labels"]))
    return out


def load_cifar10(with_test=False):
    root = os.path.join(DATA, "cifar10")
    Xs, ys = [], []
    for i in range(1, 6):
        p = os.path.join(root, f"data_batch_{i}")
        if _md5(p) != CIFAR_MD5[f"data_batch_{i}"]:
            raise ValueError(f"{p}: md5 mismatch")
        d = pickle.load(open(p, "rb"), encoding="bytes")
        Xs.append(d[b"data"])
        ys.append(np.array(d[b"labels"], dtype=np.int64))
    X = np.concatenate(Xs).reshape(-1, 3, 32, 32).transpose(0, 2, 3, 1).astype(F32) / F32(255)
    y = np.concatenate(ys)
    out = {"Xtr": X[:45000], "ytr": y[:45000], "Xva": X[45000:], "yva": y[45000:], "channels_in": 3}
    if with_test:
        p = os.path.join(root, "test_batch")
        if _md5(p) != CIFAR_MD5["test_batch"]:
            raise ValueError(f"{p}: md5 mismatch")
        d = pickle.load(open(p, "rb"), encoding="bytes")
        out["Xte"] = d[b"data"].reshape(-1, 3, 32, 32).transpose(0, 2, 3, 1).astype(F32) / F32(255)
        out["yte"] = np.array(d[b"labels"], dtype=np.int64)
    return out


CIFAR100_MD5 = {"train": "16019d7e3df5f24257cddd939b257f8d", "test": "f0ef6b0ae62326f3e7ffdfab6717acfc",
                "meta": "7973b15100ade9c7d40fb424638fde48"}


def load_cifar100(with_test=False):
    """CIFAR-100 (python version, fine labels): the first 45,000 training images for training, the last 5,000
    for validation, and the 10,000 test images."""
    root = os.path.join(DATA, "cifar100")
    for k in ("train", "meta") + (("test",) if with_test else ()):
        if _md5(os.path.join(root, k)) != CIFAR100_MD5[k]:
            raise ValueError(f"cifar100/{k}: md5 mismatch")
    d = pickle.load(open(os.path.join(root, "train"), "rb"), encoding="bytes")
    X = np.asarray(d[b"data"]).reshape(-1, 3, 32, 32).transpose(0, 2, 3, 1).astype(F32) / F32(255)
    y = np.array(d[b"fine_labels"], dtype=np.int64)
    out = {"Xtr": X[:45000], "ytr": y[:45000], "Xva": X[45000:], "yva": y[45000:], "channels_in": 3}
    if with_test:
        d = pickle.load(open(os.path.join(root, "test"), "rb"), encoding="bytes")
        out["Xte"] = np.asarray(d[b"data"]).reshape(-1, 3, 32, 32).transpose(0, 2, 3, 1).astype(F32) / F32(255)
        out["yte"] = np.array(d[b"fine_labels"], dtype=np.int64)
    return out


DATASETS = {
    "mnist": {"C": 10, "tasks": [(0, 1), (2, 3), (4, 5), (6, 7), (8, 9)], "pixels": 784},
    "cifar100": {"C": 100, "tasks": [tuple(range(10 * i, 10 * i + 10)) for i in range(10)], "pixels": 3072},
}


def load_dataset(name, with_test=False):
    return {"mnist": load_mnist, "cifar100": load_cifar100, "cifar10": load_cifar10}[name](with_test)


def make_filters(n_filters, cin, k=5, seed=FEATURE_SEED):
    f = np.random.default_rng(seed).standard_normal((k * k * cin, n_filters)).astype(F32)
    f -= f.mean(axis=0, keepdims=True)
    f /= np.linalg.norm(f, axis=0, keepdims=True)
    return f


def conv_features(X, filt, stride=2, pool=2):
    """Random valid convolution, reflection pair [relu(+), relu(-)], average pooling.  X: (n, H, W) or (n, H, W, C).
    Returns (n, channels, positions) float32, channels = 2 * filters."""
    if X.ndim == 3:
        X = X[..., None]
    X = np.ascontiguousarray(X)
    n, Hh, Ww, cin = X.shape
    k = int(round(np.sqrt(filt.shape[0] // cin)))
    out = (Hh - k) // stride + 1
    s = X.strides
    P = np.lib.stride_tricks.as_strided(X, (n, out, out, k, k, cin), (s[0], s[1] * stride, s[2] * stride, s[1], s[2], s[3]))
    Z = P.reshape(n, out, out, k * k * cin) @ filt
    Z = np.concatenate([np.maximum(Z, 0), np.maximum(-Z, 0)], axis=-1)
    if pool > 1:
        o2 = out // pool
        Z = Z[:, :o2 * pool, :o2 * pool].reshape(n, o2, pool, o2, pool, -1).mean(axis=(2, 4))
    n_, a, b, ch = Z.shape
    return np.ascontiguousarray(Z.reshape(n_, a * b, ch).transpose(0, 2, 1)).astype(F32)


def features(data, n_filters=16, with_test=False):
    filt = make_filters(n_filters, data["channels_in"])
    out = {}
    for split in ("tr", "va", "te"):
        if split == "te" and not with_test:
            continue
        X = data["X" + split]
        out["H" + split] = np.concatenate([conv_features(X[i:i + 5000], filt) for i in range(0, len(X), 5000)])
        out["y" + split] = data["y" + split]
    return out


TASKS = [(0, 1), (2, 3), (4, 5), (6, 7), (8, 9)]          # split MNIST (used by the design pilots)


# ---------------------------------------------------------------------------------------------------------------
# memory, adapter, scores
# ---------------------------------------------------------------------------------------------------------------
def init_store(R, C, P, Ch, seed, noise=0.5):
    rng = np.random.default_rng(seed)
    la = (np.log(1.0 / (P * R)) + noise * rng.standard_normal((R, C, P))).astype(np.float64)
    lb = (np.log(1.0 / Ch) + noise * rng.standard_normal((R, Ch))).astype(np.float64)
    return {"la": la, "lb": lb}


def dense(la, lb):
    """W[c, p, h] = sum_r exp(la[r,c,p]) exp(lb[r,h])."""
    return np.einsum("rcp,rh->cph", np.exp(la), np.exp(lb))


def scores_dense(W, H):
    """z[n, c] = sum_{p,h} W[c,p,h] H[n,h,p]."""
    return np.einsum("cph,nhp->nc", W, H, optimize=True)


def predict(W, H, seen):
    """Decision over the seen classes; -1 (no decision, counted as an error) where a seen-class score is not
    finite, which happens only when a sleep rule has diverged."""
    with np.errstate(over="ignore", invalid="ignore"):
        z = scores_dense(W, H)
    seen = list(seen)
    mask = np.full(W.shape[0], -np.inf)
    mask[seen] = 0.0
    with np.errstate(divide="ignore", invalid="ignore"):
        L = np.log(np.maximum(z, 1e-300)) + mask
    top = np.argmax(np.where(np.isnan(L), -np.inf, L), axis=1)
    top[~np.all(np.isfinite(z[:, seen]), axis=1)] = -1
    return top, z


# ---------------------------------------------------------------------------------------------------------------
# wake: train a Kronecker adapter on top of a fixed base (JAX)
# ---------------------------------------------------------------------------------------------------------------
def _working(Wpos, Weff, U, V, floor):
    dW = jnp.einsum("jcp,jh->cph", U, V)
    return jnp.maximum(Weff + dW, floor * Wpos)


def make_wake_step(scale, floor, lr):
    def loss_fn(ad, Wpos, Weff, Hb, yb, mask):
        W = _working(Wpos, Weff, ad["U"], ad["V"], floor)
        z = jnp.einsum("cph,nhp->nc", W, Hb)
        L = scale * jnp.log(z + 1e-30) + mask
        return -jnp.mean(jax.nn.log_softmax(L)[jnp.arange(Hb.shape[0]), yb])

    @jax.jit
    def step(ad, m, v, t, Wpos, Weff, Hb, yb, mask):
        l, g = jax.value_and_grad(loss_fn)(ad, Wpos, Weff, Hb, yb, mask)
        m = jax.tree_util.tree_map(lambda a, b: 0.9 * a + 0.1 * b, m, g)
        v = jax.tree_util.tree_map(lambda a, b: 0.999 * a + 0.001 * b * b, v, g)
        ad = jax.tree_util.tree_map(
            lambda a, b, c: a - lr * (b / (1 - 0.9 ** t)) / (jnp.sqrt(c / (1 - 0.999 ** t)) + 1e-8), ad, m, v)
        return ad, m, v, l
    return step


def wake(store, Htask, ytask, Hrep, yrep, seen, k, scale, floor, lr, epochs, seed, batch=128, rep_batch=64,
         cadence=None, rule=None, sleep_kw=None, log=None):
    """Train a fresh adapter on the current task plus replay.  If cadence is set, sleep with `rule` every
    `cadence` steps (and at the end), resetting the adapter each time; returns (store, adapter, infos)."""
    if cadence is not None:
        return _wake_with_cadence(store, Htask, ytask, Hrep, yrep, seen, k, scale, floor, lr, epochs, seed, batch,
                                  rep_batch, cadence, rule, sleep_kw or {})
    Wpos = dense(store["la"], store["lb"])
    Weff = Wpos + store["corr"] if store.get("corr") is not None else Wpos
    C, P, Ch = Wpos.shape
    rng = np.random.default_rng(seed)
    ad = {"U": jnp.zeros((k, C, P), jnp.float32),
          "V": jnp.asarray(rng.standard_normal((k, Ch)) / np.sqrt(Ch), jnp.float32)}
    m = jax.tree_util.tree_map(jnp.zeros_like, ad)
    v = jax.tree_util.tree_map(jnp.zeros_like, ad)
    mask = np.full(C, -1e9, np.float32)
    mask[list(seen)] = 0.0
    mask = jnp.asarray(mask)
    step = make_wake_step(scale, floor, lr)
    Wpj = jnp.asarray(Wpos, jnp.float32)
    Wej = jnp.asarray(Weff, jnp.float32)
    t = 0
    for ep in range(epochs):
        idx = rng.permutation(len(Htask))
        for i in range(0, len(idx) - batch + 1, batch):
            t += 1
            b = idx[i:i + batch]
            Hb, yb = Htask[b], ytask[b]
            if Hrep is not None and len(Hrep):
                r = rng.integers(0, len(Hrep), rep_batch)
                Hb = np.concatenate([Hb, Hrep[r]])
                yb = np.concatenate([yb, yrep[r]])
            ad, m, v, l = step(ad, m, v, t, Wpj, Wej, jnp.asarray(Hb), jnp.asarray(yb), mask)
    return {"U": np.asarray(ad["U"], np.float64), "V": np.asarray(ad["V"], np.float64)}


def effective(store):
    """The stored model's dense weight: positive store plus any retained signed correction."""
    W = dense(store["la"], store["lb"])
    return W + store["corr"] if store.get("corr") is not None else W


def working_dense(store, ad, floor):
    Wpos = dense(store["la"], store["lb"])
    dW = np.einsum("jcp,jh->cph", ad["U"], ad["V"])
    return np.maximum(effective(store) + dW, floor * Wpos)


# ---------------------------------------------------------------------------------------------------------------
# sleep rules
# ---------------------------------------------------------------------------------------------------------------
def nearest_kronecker(M):
    """Van Loan-Pitsianis rank-1 fit of the (C*P) x Ch rearrangement M: unit-norm factors and sigma."""
    u, s, vt = np.linalg.svd(M, full_matrices=False)
    return u[:, 0], s[0], vt[0]


def block_means(D, w=None, iters=200, tol=1e-12):
    """Least-squares outer-sum fit D_ij ~ e1_i + e2_j, ordinary (w=None) or weighted by w_ij >= 0.
    Ordinary: e1 = row means - mu/2, e2 = column means - mu/2.  Weighted: backfitting to convergence."""
    if w is None:
        mu = D.mean()
        return D.mean(axis=1) - mu / 2, D.mean(axis=0) - mu / 2
    e1 = np.zeros(D.shape[0])
    e2 = np.zeros(D.shape[1])
    rs = w.sum(axis=1)
    cs = w.sum(axis=0)
    rs_safe = np.where(rs > 0, rs, 1.0)
    cs_safe = np.where(cs > 0, cs, 1.0)
    prev = np.inf
    for _ in range(iters):
        e2 = (w * (D - e1[:, None])).sum(axis=0) / cs_safe
        e1 = (w * (D - e2[None, :])).sum(axis=1) / rs_safe
        obj = (w * (D - e1[:, None] - e2[None, :]) ** 2).sum()
        if prev - obj <= tol * max(1.0, obj):
            break
        prev = obj
    return e1, e2


def tangent_projection(M, A, b, iters=500, tol=1e-12):
    """Frobenius least-squares projection of M (C,P,Ch) onto T = {sum_r E_r (x) b_r + A_r (x) f_r}.
    A: (R,C,P), b: (R,Ch).  Conjugate gradients on the normal equations from zero (minimum-norm solution).
    Returns E (R,C,P), f (R,Ch) and the projection P_T M."""
    R = A.shape[0]

    def apply_T(E, f):
        return np.einsum("rcp,rh->cph", E, b) + np.einsum("rcp,rh->cph", A, f)

    def apply_Tt(X):
        return np.einsum("cph,rh->rcp", X, b), np.einsum("cph,rcp->rh", X, A)

    gE, gf = apply_Tt(M)
    E = np.zeros_like(A)
    f = np.zeros_like(b)
    rE, rf = gE.copy(), gf.copy()
    pE, pf = rE.copy(), rf.copy()
    rr = (rE * rE).sum() + (rf * rf).sum()
    rr0 = rr
    for _ in range(iters):
        if rr <= tol * rr0:
            break
        qE, qf = apply_Tt(apply_T(pE, pf))
        alpha = rr / ((pE * qE).sum() + (pf * qf).sum())
        E += alpha * pE
        f += alpha * pf
        rE -= alpha * qE
        rf -= alpha * qf
        rr_new = (rE * rE).sum() + (rf * rf).sum()
        pE = rE + (rr_new / rr) * pE
        pf = rf + (rr_new / rr) * pf
        rr = rr_new
    return E, f, apply_T(E, f)


def sleep(rule, store, ad, floor, alpha=1.0, refit_steps=300, refit_lr=0.05, resid=None):
    """Apply a sleep rule.  Returns (new store, info).  Rules:
      'pub'      published rule, |C| surrogate: log A_r += alpha log|C1|, log b_r += alpha log|C2|;
      'gain_ord' log block means of D = log(W_work / W) (Paper II, Eq. 13);
      'gain_w'   weighted block means of D, weights W^2 (Paper II, Eq. 14);
      'gain_w1'  weighted block means of the first-order target D1 = (W_work - W) / W;
      'tan'      first-order Frobenius projection onto the full tangent space of the Kronecker sum, additive in
                 the factors with the floor;
      'refit'    Frobenius refit of the store to W_work in log coordinates (Adam from the current store);
      'resid'    'gain_w' and the residual W_work - W_new kept as a dense correction;
      'none'     no consolidation."""
    la, lb = store["la"], store["lb"]
    W = dense(la, lb)
    corr = store.get("corr")
    Wbase = W + (corr if corr is not None else 0.0)
    Wwork = np.maximum(Wbase + np.einsum("jcp,jh->cph", ad["U"], ad["V"]), floor * W)
    dW = np.einsum("jcp,jh->cph", ad["U"], ad["V"])
    C, P, Ch = W.shape
    info = {"rule": rule}
    new = {"la": la.copy(), "lb": lb.copy()}
    if corr is not None:
        new["corr"] = corr.copy()
    target = Wwork - (corr if corr is not None else 0.0)        # what the positive store should become
    dWeff = target - W
    info["floor_frac"] = float((Wbase + dW < floor * W).mean())
    M = dW.reshape(C * P, Ch)
    if rule == "pub":
        u, s, v = nearest_kronecker(M)
        best = None
        for sg in (1.0, -1.0):
            ok1, ok2 = (sg * u > 0), (sg * v > 0)
            undefined = 1.0 - ok1.mean() * ok2.mean()
            if best is None or undefined < best[0]:
                best = (undefined, sg, 1.0 - ok1.mean(), 1.0 - ok2.mean())
        info.update(undefined_base_frac=float(best[0]), neg_C1_frac=float(best[2]), neg_C2_frac=float(best[3]),
                    sigma=float(s))
        c1 = np.maximum(np.abs(u), 1e-30).reshape(C, P)
        c2 = np.maximum(np.abs(v), 1e-30)
        new["la"] = la + alpha * np.log(c1)[None]
        new["lb"] = lb + alpha * np.log(c2)[None]
    elif rule in ("gain_ord", "gain_w", "gain_w1", "resid"):
        Wm = W.reshape(C * P, Ch)
        if rule == "gain_w1":
            D = dWeff.reshape(C * P, Ch) / Wm
        else:
            # the working weight is floored at FLOOR * W; a retained correction can leave target below it
            D = np.log(np.maximum(target, floor * W) / W).reshape(C * P, Ch)
        e1, e2 = block_means(D, None if rule == "gain_ord" else Wm ** 2)
        new["la"] = la + e1.reshape(C, P)[None]
        new["lb"] = lb + e2[None]
    elif rule == "tan":
        A, b = np.exp(la), np.exp(lb)
        E, f, PT = tangent_projection(dWeff, A, b)
        new["la"] = np.log(np.maximum(A + E, floor * A))
        new["lb"] = np.log(np.maximum(b + f, floor * b))
        info["tangent_frac"] = float(np.linalg.norm(PT) / max(np.linalg.norm(dWeff), 1e-300))
    elif rule == "refit":
        new["la"], new["lb"] = refit(target, la, lb, refit_steps, refit_lr)
    elif rule == "none":
        pass
    else:
        raise ValueError(rule)
    Wn = dense(new["la"], new["lb"])
    if rule in ("resid", "none"):
        new["corr"] = (Wwork - Wn).astype(np.float32).astype(np.float64)     # stored in float32
    Wstored = Wn + new.get("corr", 0.0)
    change = np.linalg.norm(Wwork - Wbase)
    info["change_norm"] = float(change)
    info["rel_change"] = float(np.max(np.abs(Wwork - Wbase) / W))
    info["rel_residual"] = float(np.linalg.norm(Wstored - Wwork) / change) if change > 0 else 0.0
    info["residual_norm_by_class"] = np.linalg.norm((Wstored - Wwork).reshape(C, -1), axis=1)
    return new, info


def _refit_loss(p, tgt):
    W = jnp.einsum("rcp,rh->cph", jnp.exp(p["la"]), jnp.exp(p["lb"]))
    return jnp.sum((W - tgt) ** 2) / jnp.sum(tgt ** 2)


@jax.jit
def _refit_step(p, m, v, t, tgt, lr):
    g = jax.grad(_refit_loss)(p, tgt)
    m = jax.tree_util.tree_map(lambda a, b: 0.9 * a + 0.1 * b, m, g)
    v = jax.tree_util.tree_map(lambda a, b: 0.999 * a + 0.001 * b * b, v, g)
    p = jax.tree_util.tree_map(lambda a, b, c: a - lr * (b / (1 - 0.9 ** t)) / (jnp.sqrt(c / (1 - 0.999 ** t)) + 1e-8),
                               p, m, v)
    return p, m, v


def refit(target, la, lb, steps, lr):
    """Frobenius refit of the positive Kronecker sum to `target`, by Adam on the log factors from the current
    store (float32)."""
    tgt = jnp.asarray(target, jnp.float32)
    p = {"la": jnp.asarray(la, jnp.float32), "lb": jnp.asarray(lb, jnp.float32)}
    m = jax.tree_util.tree_map(jnp.zeros_like, p)
    v = jax.tree_util.tree_map(jnp.zeros_like, p)
    lr = jnp.float32(lr)
    for t in range(1, steps + 1):
        p, m, v = _refit_step(p, m, v, jnp.float32(t), tgt, lr)
    return np.asarray(p["la"], np.float64), np.asarray(p["lb"], np.float64)


def _wake_with_cadence(store, Htask, ytask, Hrep, yrep, seen, k, scale, floor, lr, epochs, seed, batch, rep_batch,
                       cadence, rule, sleep_kw):
    C, P, Ch = dense(store["la"], store["lb"]).shape
    rng = np.random.default_rng(seed)
    mask = np.full(C, -1e9, np.float32)
    mask[list(seen)] = 0.0
    mask = jnp.asarray(mask)
    step = make_wake_step(scale, floor, lr)
    infos = []

    def fresh():
        ad = {"U": jnp.zeros((k, C, P), jnp.float32),
              "V": jnp.asarray(rng.standard_normal((k, Ch)) / np.sqrt(Ch), jnp.float32)}
        z = jax.tree_util.tree_map(jnp.zeros_like, ad)
        return ad, z, jax.tree_util.tree_map(jnp.zeros_like, ad)

    def bases(store):
        Wpos = dense(store["la"], store["lb"])
        Weff = Wpos + store["corr"] if store.get("corr") is not None else Wpos
        return jnp.asarray(Wpos, jnp.float32), jnp.asarray(Weff, jnp.float32)

    ad, m, v = fresh()
    Wpj, Wej = bases(store)
    t = 0
    since = 0
    for ep in range(epochs):
        idx = rng.permutation(len(Htask))
        for i in range(0, len(idx) - batch + 1, batch):
            t += 1
            since += 1
            b = idx[i:i + batch]
            Hb, yb = Htask[b], ytask[b]
            if Hrep is not None and len(Hrep):
                r = rng.integers(0, len(Hrep), rep_batch)
                Hb = np.concatenate([Hb, Hrep[r]])
                yb = np.concatenate([yb, yrep[r]])
            ad, m, v, l = step(ad, m, v, since, Wpj, Wej, jnp.asarray(Hb), jnp.asarray(yb), mask)
            if since == cadence:
                adn = {"U": np.asarray(ad["U"], np.float64), "V": np.asarray(ad["V"], np.float64)}
                store, info = sleep(rule, store, adn, floor, **sleep_kw)
                infos.append(info)
                ad, m, v = fresh()
                Wpj, Wej = bases(store)
                since = 0
    adn = {"U": np.asarray(ad["U"], np.float64), "V": np.asarray(ad["V"], np.float64)}
    return store, adn, infos


# ---------------------------------------------------------------------------------------------------------------
# stored precision: units, grids, policies
# ---------------------------------------------------------------------------------------------------------------
# Units: one grid per class (all R rows of that class, R*P log-weights) and one per shared channel vector
# (Ch log-weights).  A unit with b bits stores its entries on 2^b levels between float16 endpoints rounded
# outward; the reference value of every entry lies within half a step of its stored value.
META_BITS = 16 + 16 + 4            # two float16 endpoints and a 4-bit width field, per unit
USAGE_BITS = 8 + 8                 # usage-and-age only: log-scale use counter and coarse timestamp, per unit


def units(la, lb, seen=None):
    """List of (kind, index, values) with kind 'class' (la[:, c, :]) or 'shared' (lb[r, :]).  Only the classes in
    `seen` belong to the memory (a class enters the store at the sleep that ends its task)."""
    R, C, P = la.shape
    cls = range(C) if seen is None else sorted(seen)
    return [("class", c, la[:, c, :]) for c in cls] + [("shared", r, lb[r]) for r in range(R)]


def _f16_down(x):
    y = np.float16(x)
    return float(np.nextafter(y, np.float16(-np.inf))) if float(y) > x else float(y)


def _f16_up(x):
    y = np.float16(x)
    return float(np.nextafter(y, np.float16(np.inf))) if float(y) < x else float(y)


def quantize_values(v, bits):
    lo, hi = _f16_down(float(v.min())), _f16_up(float(v.max()))
    if bits <= 0 or hi <= lo:
        mid = 0.5 * (lo + hi)
        return np.full_like(v, mid), 0.5 * (hi - lo)
    step = (hi - lo) / (2 ** bits - 1)
    q = lo + step * np.round((v - lo) / step)
    return q, 0.5 * step


def quantize_store(la, lb, bits):
    """bits: dict {('class', c) or ('shared', r): b}.  Returns stored (la_q, lb_q) and radii rho (C,), sigma (R,)."""
    R, C, P = la.shape
    la_q, lb_q = la.copy(), lb.copy()
    rho, sigma = np.zeros(C), np.zeros(R)
    for kind, i, v in units(la, lb):
        if (kind, i) not in bits:
            continue
        q, rad = quantize_values(v, bits[(kind, i)])
        if kind == "class":
            la_q[:, i, :] = q
            rho[i] = rad
        else:
            lb_q[i] = q
            sigma[i] = rad
    return la_q, lb_q, rho, sigma


def unit_sizes(la, lb, seen=None):
    return {(k, i): v.size for k, i, v in units(la, lb, seen)}


def weight_bits(bits, sizes):
    return sum(bits[u] * sizes[u] for u in sizes)


# ---------------------------------------------------------------------------------------------------------------
# exact decision test under a log box: class rows at corners, shared channel vectors by the threshold rule
# ---------------------------------------------------------------------------------------------------------------
def term_contributions(la_q, lb_q, H):
    """g[n, c, r, h] = sum_p exp(la[r,c,p]) H[n,h,p] * exp(lb[r,h]): the score of class c split into the
    monomial groups that share one shared-factor entry b_r[h]."""
    A = np.exp(la_q)
    Bv = np.exp(lb_q)
    g = np.einsum("rcp,nhp->ncrh", A, H, optimize=True)
    return g * Bv[None, None]


def max_ratio(alpha, beta, lo, hi):
    """max over t in prod [lo_i, hi_i] of (beta.t)/(alpha.t), alpha, beta >= 0, along the last axis.
    Linear-fractional over a box: sort by beta/alpha, take the best threshold vertex (Dinkelbach)."""
    with np.errstate(divide="ignore", invalid="ignore"):
        key = np.where(alpha > 0, beta / np.where(alpha > 0, alpha, 1.0), np.where(beta > 0, np.inf, -np.inf))
    order = np.argsort(-key, axis=-1)
    a = np.take_along_axis(alpha, order, -1)
    b = np.take_along_axis(beta, order, -1)
    l = np.take_along_axis(np.broadcast_to(lo, alpha.shape), order, -1)
    h = np.take_along_axis(np.broadcast_to(hi, alpha.shape), order, -1)
    return _threshold_max(a, b, l, h)


def _threshold_max(a, b, l, h):
    zero = np.zeros(a.shape[:-1] + (1,))
    cbh = np.concatenate([zero, np.cumsum(b * h, -1)], -1)
    cbl = np.concatenate([zero, np.cumsum(b * l, -1)], -1)
    cah = np.concatenate([zero, np.cumsum(a * h, -1)], -1)
    cal = np.concatenate([zero, np.cumsum(a * l, -1)], -1)
    num = cbh + (cbl[..., -1:] - cbl)
    den = cah + (cal[..., -1:] - cal)
    with np.errstate(divide="ignore", invalid="ignore"):
        r = np.where(den > 0, num / den, np.where(num > 0, np.inf, 0.0))
    return r.max(-1)


def _chunk(C):
    return max(20, 50000 // C)


def _top_and_logratio(g, seen):
    z = g.sum(axis=(2, 3))
    n, C = z.shape
    zs = np.full_like(z, -np.inf)
    zs[:, seen] = z[:, seen]
    top = np.argmax(zs, axis=1)
    with np.errstate(divide="ignore"):
        lr = np.log(z[np.arange(n), top])[:, None] - np.log(z)
    mask = np.zeros((n, C), bool)
    mask[:, seen] = True
    mask[np.arange(n), top] = False
    lr = np.where(mask, lr, np.inf)
    return top, lr


def shared_margins(la_q, lb_q, sigma, H, seen):
    """For each example: the stored model's top class among `seen`, and m[n, c] = min over the shared box of
    log(z_top / z_c) (+inf for c = top or unseen).  Class radii enter later: certified iff
    rho_top + rho_c < m[n, c] for every c.  (Exact for every pair; used by the checks.)"""
    R, C = la_q.shape[0], la_q.shape[1]
    Ch = lb_q.shape[1]
    lo = np.repeat(np.exp(-sigma), Ch)
    hi = np.repeat(np.exp(sigma), Ch)
    seen = np.array(sorted(seen))
    tops, ms = [], []
    ch = _chunk(C)
    for i in range(0, len(H), ch):
        g = term_contributions(la_q, lb_q, H[i:i + ch])
        n = g.shape[0]
        top, lr = _top_and_logratio(g, seen)
        gf = g.reshape(n, C, R * Ch)
        alpha = gf[np.arange(n), top]
        m = np.full((n, C), np.inf)
        for c in seen:
            mask = top != c
            if mask.any():
                with np.errstate(divide="ignore"):
                    m[mask, c] = -np.log(max_ratio(alpha[mask], gf[mask, c], lo, hi))
        tops.append(top)
        ms.append(m)
    return np.concatenate(tops), np.concatenate(ms)


def certified_from_margins(top, m, rho):
    need = rho[top][:, None] + rho[None, :]
    return np.all(m > need, axis=1)


def certify(la_q, lb_q, rho, sigma, H, seen):
    """Exact decision test on the stored box (Proposition 4).  A pair (top, c) whose nominal log ratio exceeds
    rho_top + rho_c + 2 max(sigma) is certified without the threshold rule, since the shared box moves each
    log score by at most max(sigma); every other pair is decided by the threshold rule."""
    R, C = la_q.shape[0], la_q.shape[1]
    Ch = lb_q.shape[1]
    lo = np.repeat(np.exp(-sigma), Ch)
    hi = np.repeat(np.exp(sigma), Ch)
    smax = float(np.max(sigma)) if len(sigma) else 0.0
    seen = np.array(sorted(seen))
    tops, certs = [], []
    ch = _chunk(C)
    for i in range(0, len(H), ch):
        g = term_contributions(la_q, lb_q, H[i:i + ch])
        n = g.shape[0]
        top, lr = _top_and_logratio(g, seen)
        need = rho[top][:, None] + rho[None, :]
        cand = np.isfinite(lr) & (lr - 2 * smax <= need)
        cert = np.ones(n, bool)
        gf = g.reshape(n, C, R * Ch)
        # most dangerous competitors first; an example is done at its first failed pair
        order = np.argsort(np.where(cand, lr - need, np.inf), axis=1)
        ncand = cand.sum(axis=1)
        for k in range(int(ncand.max()) if n else 0):
            ni = np.nonzero(cert & (ncand > k))[0]
            if not len(ni):
                break
            ci = order[ni, k]
            with np.errstate(divide="ignore"):
                m = -np.log(max_ratio(gf[ni, top[ni]], gf[ni, ci], lo, hi))
            cert[ni[~(m > need[ni, ci])]] = False
        tops.append(top)
        certs.append(cert)
    return np.concatenate(tops), np.concatenate(certs)


class MarginCache:
    """Shared-box margins of the protected examples for fixed stored values.  For each example the K
    competitors with the smallest nominal log ratio get the exact threshold rule, with the threshold order
    precomputed once (it depends on beta/alpha only, not on the radii); the others get the sound bound
    log ratio - 2 max(sigma)."""

    def __init__(self, la, lb, H, seen, K=8):
        R, C = la.shape[0], la.shape[1]
        Ch = lb.shape[1]
        seen = np.array(sorted(seen))
        self.R, self.C, self.Ch = R, C, Ch
        K = max(1, min(K, len(seen) - 1))
        tops, ea, eb, et, ec, bl, bc = [], [], [], [], [], [], []
        ch = _chunk(C)
        for i in range(0, len(H), ch):
            g = term_contributions(la, lb, H[i:i + ch])
            n = g.shape[0]
            top, lr = _top_and_logratio(g, seen)
            order = np.argsort(lr, axis=1)
            comp = order[:, :K]                                   # most dangerous competitors (finite lr first)
            rest = order[:, K:len(seen) - 1]
            gf = g.reshape(n, C, R * Ch)
            a = np.broadcast_to(gf[np.arange(n), top][:, None, :], (n, K, R * Ch))
            b = gf[np.arange(n)[:, None], comp]
            with np.errstate(divide="ignore", invalid="ignore"):
                key = np.where(a > 0, b / np.where(a > 0, a, 1.0), np.where(b > 0, np.inf, -np.inf))
            o = np.argsort(-key, axis=-1)
            ea.append(np.take_along_axis(a, o, -1))
            eb.append(np.take_along_axis(b, o, -1))
            et.append((o // Ch).astype(np.int16))
            ec.append(comp)
            bl.append(np.take_along_axis(lr, rest, 1))
            bc.append(rest)
            tops.append(top)
        self.top = np.concatenate(tops)
        self.a, self.b, self.term = np.concatenate(ea), np.concatenate(eb), np.concatenate(et)
        self.comp = np.concatenate(ec)
        self.rest_lr, self.rest_comp = np.concatenate(bl), np.concatenate(bc)

    def margins(self, sigma):
        lo = np.exp(-sigma)[self.term]
        hi = np.exp(sigma)[self.term]
        with np.errstate(divide="ignore", invalid="ignore"):
            m_exact = -np.log(_threshold_max(self.a, self.b, lo, hi))
        m_rest = self.rest_lr - 2 * float(np.max(sigma))
        return m_exact, m_rest

    def slack(self, m, rho):
        m_exact, m_rest = m
        rt = rho[self.top][:, None]
        s1 = (m_exact - rt - rho[self.comp]).min(axis=1)
        if m_rest.shape[1]:
            s2 = (m_rest - rt - rho[self.rest_comp]).min(axis=1)
            return np.minimum(s1, s2)
        return s1


def radii_for(la, lb, bits):
    """Rounding radii per unit for a bit allocation, from the reference values' (outward float16) spans."""
    R, C, P = la.shape
    rho, sigma = np.zeros(C), np.zeros(R)
    for kind, i, v in units(la, lb):
        if (kind, i) not in bits:
            continue
        lo, hi = _f16_down(float(v.min())), _f16_up(float(v.max()))
        b = bits[(kind, i)]
        rad = 0.5 * (hi - lo) if b <= 0 else 0.5 * (hi - lo) / (2 ** b - 1)
        if kind == "class":
            rho[i] = rad
        else:
            sigma[i] = rad
    return rho, sigma


def alloc_uniform(la, lb, bbar, seen=None):
    return {(k, i): int(bbar) for k, i, _ in units(la, lb, seen)}


def alloc_usage(la, lb, budget, usage, seen=None, bmin=1, bmax=16):
    """Usage-and-age (LTM-style precision decay): bits follow log2 of decayed use, by water-filling.
    usage: dict unit -> decayed use count.  budget: weight bits."""
    sizes = unit_sizes(la, lb, seen)
    bits = {u: bmin for u in sizes}
    left = budget - weight_bits(bits, sizes)
    pri = {u: np.log2(max(usage[u], 1.0)) for u in sizes}
    while True:
        cand = [u for u in sizes if bits[u] < bmax and sizes[u] <= left]
        if not cand:
            break
        u = max(cand, key=lambda u: (pri[u] - bits[u], -sizes[u]))
        bits[u] += 1
        left -= sizes[u]
    return bits


def _cert_value(sl, lam):
    """Per-example objective: 1 if certified (slack > 0) plus lam times the slack of an uncertified example."""
    return (sl > 0).astype(float) + lam * np.minimum(sl, 0.0)


def cert_gains(M, top, comp, rho, delta, lam, C):
    """Exact one-step gains of the certificate objective for every class at once.
    M: (N, J) shared-box margins of the pairs (example n, competitor comp[n, j]); top: (N,) stored decisions;
    rho: (C,) class radii; delta: (C,) radius decrease of one more bit (0 for classes that cannot grow).
    Raising class c's precision lowers rho_c by delta_c, which raises every pair slack of the examples whose
    decision is c and the one pair slack of each example in which c competes.  The example slack is the minimum
    pair slack, so only the examples whose binding competitor is c, or whose decision is c, change.
    Returns (gain per class (C,), current objective)."""
    N = len(top)
    S = M - rho[top][:, None] - rho[comp]
    j1 = np.argmin(S, axis=1)
    rows = np.arange(N)
    min1 = S[rows, j1]
    if S.shape[1] > 1:
        S[rows, j1] = np.inf
        min2 = S.min(axis=1)
    else:
        min2 = np.full(N, np.inf)
    arg = comp[rows, j1]
    cur = _cert_value(min1, lam)
    g_top = _cert_value(min1 + delta[top], lam) - cur
    g_arg = _cert_value(np.minimum(min1 + delta[arg], min2), lam) - cur
    gain = np.bincount(top, weights=g_top, minlength=C) + np.bincount(arg, weights=g_arg, minlength=C)
    return gain, float(cur.sum())


def alloc_certificate(la, lb, budget, Hprot, seen, bmin=1, bmax=16, lam=1e-3, shared_levels=range(1, 17), K=8):
    """Certificate-guided precision.  For each common bit width s of the shared channel vectors, compute the
    shared-box margins of the protected examples once, then give the remaining budget to the class units
    greedily, one bit at a time: each step re-evaluates the exact gain of every class (cert_gains) in the
    objective (certified protected examples + lam * total slack of the uncertified) and gives the bit to the
    largest gain per bit (ties, including all-zero gains, to the class with the fewest bits, then the lowest
    index).  Keep the best s.  Certificates use the reference values with the rounding radii of the candidate
    allocation; the stored values are evaluated exactly afterwards.
    (The gains are not submodular: a class that never binds while every class is coarse becomes binding once
    the others are refined, so a lazy greedy with stale gains can starve it.  The exact greedy cannot.)"""
    sizes = unit_sizes(la, lb, seen)
    R, C, P = la.shape
    cache = MarginCache(la, lb, Hprot, seen, K)
    seen_s = sorted(seen)
    cls_units = [("class", c) for c in seen_s]
    sh_units = [("shared", r) for r in range(R)]
    usize = sizes[cls_units[0]]                                   # every class unit has R*P log-weights
    spans = {}
    for kind, i, v in units(la, lb, seen):
        spans[(kind, i)] = _f16_up(float(v.max())) - _f16_down(float(v.min()))
    cspan = np.zeros(C)
    for c in seen_s:
        cspan[c] = spans[("class", c)]

    def rad(span, b):
        b = np.asarray(b, float)
        return 0.5 * span / np.where(b <= 0, 1.0, 2.0 ** b - 1)

    comp = np.concatenate([cache.comp, cache.rest_comp], axis=1)
    top = cache.top
    seen_mask = np.zeros(C, bool)
    seen_mask[seen_s] = True
    best = None
    for s_bits in shared_levels:
        cb = np.where(seen_mask, bmin, 0).astype(int)
        left = budget - int(cb.sum()) * usize - s_bits * sum(sizes[u] for u in sh_units)
        if left < 0:
            continue
        sigma = np.array([float(rad(spans[u], s_bits)) for u in sh_units])
        m_exact, m_rest = cache.margins(sigma)
        M = np.concatenate([m_exact, m_rest], axis=1)
        rho = np.where(seen_mask, rad(cspan, cb), 0.0)
        while True:
            grow = seen_mask & (cb < bmax) & (left >= usize)
            delta = np.where(grow, rho - rad(cspan, cb + 1), 0.0)
            gain, cur = cert_gains(M, top, comp, rho, delta, lam, C)
            if not grow.any():
                break
            g = np.where(grow, gain, -np.inf)
            gmax = g.max()
            tied = np.nonzero(grow & (g >= gmax - 1e-12))[0]
            c = int(tied[np.lexsort((tied, cb[tied]))[0]])
            cb[c] += 1
            left -= usize
            rho[c] = float(rad(cspan[c], cb[c]))
        if best is None or cur > best[0]:
            bits = {("class", c): int(cb[c]) for c in seen_s}
            bits.update({u: s_bits for u in sh_units})
            best = (cur, bits)
    return best[1]


def alloc_exposure(la, lb, budget, seen=None, shared_bits=16):
    """Exposure-aware uniform control: every shared channel vector at `shared_bits`, the class units at the
    largest common width that fits, and any whole leftover bits to class units in index order."""
    sizes = unit_sizes(la, lb, seen)
    sh = [u for u in sizes if u[0] == "shared"]
    cl = [u for u in sizes if u[0] == "class"]
    bits = {u: shared_bits for u in sh}
    left = budget - sum(shared_bits * sizes[u] for u in sh)
    ncl = sum(sizes[u] for u in cl)
    b = max(left // ncl, 0)
    bits.update({u: int(b) for u in cl})
    left -= b * ncl
    for u in cl:
        if sizes[u] <= left:
            bits[u] += 1
            left -= sizes[u]
    return bits
