"""Diagnostic (training data only, after the confirmatory runs): why the wake cannot learn new classes after a
published-rule sleep.  Reads runs/mnist/R8_task_pub_s0.  Usage: python3 p3_pub_wake_check.py > report/pub_wake_check.txt"""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); os.chdir(HERE)
import numpy as np, jax, jax.numpy as jnp, p3lib as L, p3_eval as E, p3_run as Rn
meta, st = E.load_run('runs/mnist/R8_task_pub_s0')
s0 = st[0]; s1 = st[1]
store = s0['after']
print('after sleep 1: la max per class', store['la'].max(axis=(0, 2)).round(1))
F = Rn.feats('mnist'); Htr, ytr = F['Htr'], F['ytr']
sel = np.nonzero(np.isin(ytr, [2, 3]))[0][:128]
Wpos = L.dense(store['la'], store['lb']); C, P, Ch = Wpos.shape
rng = np.random.default_rng(0)
ad = {"U": jnp.zeros((8, C, P), jnp.float32), "V": jnp.asarray(rng.standard_normal((8, Ch)) / np.sqrt(Ch), jnp.float32)}
mask = np.full(C, -1e9, np.float32); mask[[0, 1, 2, 3]] = 0
def loss_fn(ad):
    W = L._working(jnp.asarray(Wpos, jnp.float32), jnp.asarray(Wpos, jnp.float32), ad["U"], ad["V"], 0.05)
    z = jnp.einsum("cph,nhp->nc", W, jnp.asarray(Htr[sel]))
    Lg = 8.0 * jnp.log(z + 1e-30) + jnp.asarray(mask)
    return -jnp.mean(jax.nn.log_softmax(Lg)[jnp.arange(len(sel)), jnp.asarray(ytr[sel])])
g = jax.grad(loss_fn)(ad)
gU = np.asarray(g["U"])
print('z for class 2 (float32):', float(np.einsum("ph,nhp->n", Wpos[2], Htr[sel]).mean()))
print('max |grad U| on rows of classes 2,3:', np.abs(gU[:, 2:4]).max(), ' on rows of 0,1:', np.abs(gU[:, :2]).max())
with np.errstate(over='ignore'):
    v = 0.001 * gU.astype(np.float32) ** 2
print('Adam second moment finite on class-2 rows:', np.isfinite(v[:, 2]).all(), ' fraction inf:', np.mean(~np.isfinite(v[:, 2:4])))
print('adapter rows of classes 2,3 after the real wake (saved):', np.abs(s1['adapter']['U'][:, 2:4]).max())
