"""Every number quoted in the P3 paper, printed from report/summary.json (written by p3_report.py) and, for the
pilot/smoke-free quantities, from the evaluator outputs.  Usage: python3 p3_facts.py > facts_output.txt"""
import os
import json
import glob
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
S = json.load(open("report/summary.json"))
RULES = ["none", "pub", "pub01", "gain_ord", "gain_w", "gain_w1", "resid", "tan", "refit"]
FAST = ["gain_ord", "gain_w", "gain_w1", "tan", "refit"]
POL = ["uniform", "usage", "cert", "exposure"]
FINAL_T = {"mnist": 4, "cifar100": 9}


def f(c, k=100.0, d=1):
    if c is None or c.get("mean") is None:
        return "n/a"
    if c.get("half") is None:
        return f"{k * c['mean']:.{d}f}"
    return f"{k * c['mean']:.{d}f} ± {k * c['half']:.{d}f} [{k * (c['mean'] - c['half']):.{d}f}, {k * (c['mean'] + c['half']):.{d}f}]"


def vals(c, k=100.0, d=1):
    return "[" + ", ".join(f"{k * v:.{d}f}" for v in c["values"]) + "]"


for ds in S:
    D = S[ds]
    C = D["consolidation"]
    print("=" * 100)
    print(ds)
    print("=" * 100)
    for prefix, rules in (("R8_task", RULES), ("R1_task", RULES), ("R8_10", FAST)):
        print(f"\n-- consolidation {prefix}")
        for r in rules:
            g = C.get(f"{prefix}_{r}")
            if g is None:
                continue
            print(f"{r:9s} final {f(g['final_acc'])} | old {f(g['final_acc_old'])} | work {f(g['final_work_acc'])} | "
                  f"fid mean {f(g['fidelity_mean'])} final {f(g['final_fidelity'])} | cfid mean {f(g['cert_fidelity_mean'])} "
                  f"final {f(g['final_cert_fidelity'])} | relres med {f(g['rel_residual_median'], 1, 3)} | "
                  f"S {f(g['frac_S_mean'], 1, 2)} T {f(g['frac_T_mean'], 1, 2)} | log10 maxrel {f(g['log10_max_rel_change_median'], 1, 1)} "
                  f"| diverged {g['diverged_seeds']} first {g['first_diverged_sleep']} | zero-w {f(g['zero_weight_frac_final'], 100, 2)} "
                  f"| viol {g['certificate_violations']}")
            print(f"          per task {[round(100 * c['mean'], 1) for c in g['final_per_task']]}")
            print(f"          stored by sleep {[round(100 * c['mean'], 1) if c['mean'] is not None else None for c in g['acc_stored_by_sleep']]}")
            print(f"          working by sleep {[round(100 * c['mean'], 1) if c['mean'] is not None else None for c in g['acc_working_by_sleep']]}")
            print(f"          fidelity by sleep {[round(100 * c['mean'], 1) if c['mean'] is not None else None for c in g['fidelity_by_sleep']]}")
            if "undefined_mean" in g:
                print(f"          undefined mean {f(g['undefined_mean'])} first sleep {f(g['undefined_first'])}")
            if "inner_sleeps_total" in g:
                print(f"          inner sleeps {f(g['inner_sleeps_total'], 1, 0)} inner relres median {f(g['inner_rel_residual_median'], 1, 3)}")
            if "final_curve" in g:
                print("          curve (rank: bits, cert fid final, fid final): " + "; ".join(
                    f"{c['rank']}: {c['bits']}, {100 * c['certified_fidelity']['mean']:.1f}, {100 * c['fidelity']['mean']:.1f}"
                    for c in g["final_curve"]))
                print("          curve mean over sleeps (cert fid): " + "; ".join(
                    f"{c['rank']}: {100 * c['certified_fidelity']['mean']:.1f}" for c in g["mean_curve"]))
            print(f"          bits {g['bits_final']}")
    print("\n-- registered consolidation comparisons")
    if "p32_gain_w_minus_none" in D:
        print("P3.2 gain_w - none (final acc):", f(D["p32_gain_w_minus_none"]), vals(D["p32_gain_w_minus_none"]))
    if "p31_old_acc_by_rule" in D:
        o = D["p31_old_acc_by_rule"]
        print("P3.1 earlier-task acc by rule (sorted):", sorted(((round(100 * v, 1), k) for k, v in o.items())))
        print("P3.1 pub lowest:", D["p31_pub_lowest"], "rank of pub (1 = lowest):", D["p31_rank_of_pub"])
    if "refit_minus_none_acc" in D:
        print("refit - none (final acc):", f(D["refit_minus_none_acc"]), vals(D["refit_minus_none_acc"]))
    P = D.get("precision")
    if P:
        print("\n-- precision")
        ts = sorted({int(k.split("_")[0][1:]) for k in P})
        for t in ts:
            for b in (4, 6, 8, 10, 12):
                cell = P[f"t{t}_b{b}"]
                line = f"t{t} b{b:2d} | " + " | ".join(f"{p} {f(cell[p]['certified'])}" for p in POL)
                print(line)
                print(f"           cert-uniform {f(cell['cert_minus_uniform'])} {vals(cell['cert_minus_uniform'])} | "
                      f"cert-usage {f(cell['cert_minus_usage'])} {vals(cell['cert_minus_usage'])} | cert-exposure {f(cell['cert_minus_exposure'])}")
                print(f"           agreement " + " | ".join(f"{p} {f(cell[p]['agreement'])}" for p in POL))
                print(f"           accuracy " + " | ".join(f"{p} {f(cell[p]['accuracy'])}" for p in POL))
                print(f"           certified old " + " | ".join(f"{p} {f(cell[p]['certified_old'])}" for p in POL))
                print(f"           t_alloc " + " | ".join(f"{p} {f(cell[p]['t_alloc'], 1, 2)}" for p in POL) +
                      " || t_cert " + " | ".join(f"{p} {f(cell[p]['t_cert'], 1, 2)}" for p in POL))
                print(f"           weight bits " + " | ".join(f"{p} {cell[p]['weight_bits']:.0f}" for p in POL) +
                      f" | budget {cell['uniform']['budget_bits']:.0f} meta {cell['uniform']['meta_bits']:.0f}"
                      f" usage meta {cell['usage']['meta_bits']:.0f}")
                print(f"           class bits min-max " + " | ".join(f"{p} {cell[p]['class_bits_min']:.1f}-{cell[p]['class_bits_max']:.1f}" for p in POL) +
                      " | shared " + " | ".join(f"{p} {cell[p]['shared_bits_mean']:.1f}" for p in POL))
    B = D.get("bits")
    if B and B.get("per_seed"):
        print("\n-- bits per decision (final sleep)")
        for x in B["per_seed"]:
            print(f"seed {x['seed']}: spearman lost {x['spearman_lost']:.3f} cert {x['spearman_cert']:.3f} never-cert-16 "
                  f"{100 * x['never_certified_16']:.2f}% kept-from-1 {100 * x['kept_from_1']:.1f}% lost-at-16 {100 * x['lost_at_16']:.2f}% "
                  f"median b_cert {x['median_b_cert']} median b_keep {x['median_b_keep']} n {x['n']}")
        print("mean spearman lost", f(B["spearman_lost"], 1, 3), "cert", f(B["spearman_cert"], 1, 3),
              "P3.3 holds every seed:", B["p33_holds_every_seed"], "max (least negative):", round(B["max_spearman_lost"], 3))
    Dy = D.get("dynamic")
    if Dy:
        print("\n-- dynamic arm")
        for p in POL:
            if p in Dy:
                print(f"{p:9s} acc {f(Dy[p]['acc'])} agree-fullprec {f(Dy[p]['agree_fullprec'])} certified {f(Dy[p]['certified_own'])}")
        for k, v in Dy.items():
            if k.startswith("cert_minus"):
                print(k, f(v), vals(v))

# exploratory quantities added after the independent review (all read from the evaluator's outputs)
print("\n-- exploratory (post hoc) quantities")
for ds in S:
    ev = {os.path.basename(p)[:-5]: json.load(open(p)) for p in glob.glob(os.path.join("evals", ds, "*.json"))}
    a = np.array([ev[f"R8_task_resid_s{s}"]["consolidation"][-1]["acc_stored"] for s in range(5)])
    b = np.array([ev[f"R8_task_none_s{s}"]["consolidation"][-1]["acc_stored"] for s in range(5)])
    d = a - b
    h = 2.776 * d.std(ddof=1) / np.sqrt(5)
    print(f"{ds}: resid - none final acc {100 * d.mean():+.1f} ± {100 * h:.1f}  per seed {np.round(100 * d, 1).tolist()}")
    for rule in ("pub", "pub01"):
        mx = max(max(r["per_task_stored"][1:]) if len(r["per_task_stored"]) > 1 else 0.0
                 for s in range(5) for r in ev[f"R8_task_{rule}_s{s}"]["consolidation"])
        first = [round(100 * ev[f"R8_task_{rule}_s{s}"]["consolidation"][0]["acc_stored"], 1) for s in range(5)]
        print(f"{ds}: {rule}: best accuracy on any later task at any sleep, any seed {100 * mx:.1f}%; "
              f"stored accuracy after the first sleep per seed {first}")
    und = [ev[f"R8_task_pub_s{s}"]["infos"][0]["undefined_base_frac"] for s in range(5)]
    C = 10 if ds == "mnist" else 100
    k = 2 if ds == "mnist" else 10
    unseen = (C - k) / C
    seen_part = [(u - unseen) / (1 - unseen) for u in und]
    print(f"{ds}: first-sleep undefined fraction {np.round(100 * np.array(und), 1).tolist()}; unseen-class rows are "
          f"{100 * unseen:.0f}% of base entries; undefined among seen-class entries {np.round(100 * np.array(seen_part), 1).tolist()}")
    ms = np.concatenate([np.load(p)["margin"] for p in sorted(glob.glob(os.path.join("evals", ds, "R8_task_refit_s*_bits.npz")))])
    print(f"{ds}: median reference log margin at the final sleep {np.median(ms):.4f} nats, quartiles "
          f"{np.round(np.quantile(ms, [0.25, 0.75]), 4).tolist()}")
    tcs = [x["t_cert"] for e in ev.values() if "precision" in e for x in e["precision"]]
    print(f"{ds}: certification time over all precision cells {min(tcs):.2f}-{max(tcs):.2f} s")
    tfin = max(x["t"] for e in ev.values() if "precision" in e for x in e["precision"])
    tcf = [x["t_cert"] for e in ev.values() if "precision" in e for x in e["precision"] if x["t"] == tfin and x["bbar"] == 8]
    wb0 = [x["weight_bits"] for x in ev["R8_task_refit_s0"]["precision"] if x["t"] == tfin and x["bbar"] == 8 and x["policy"] == "cert"]
    print(f"{ds}: certification time at the final sleep, b=8, all policies and seeds {min(tcf):.2f}-{max(tcf):.2f} s; "
          f"certificate-guided weight bits in seed 0 at that cell {wb0}")
    if f"R8_10_tan_s0" in ev:
        empty = sorted({i for s in range(5) for r in ("gain_ord", "gain_w", "tan", "refit")
                        for i, inf in enumerate(ev[f"R8_10_{r}_s{s}"]["infos"]) if inf["change_norm"] == 0.0})
        print(f"{ds}: 10-step cadence, task-ending sleeps that consolidated nothing (zero change): sleeps "
              f"{[i + 1 for i in empty]}")
        for r in ("tan", "refit"):
            per = np.array([[x["certified_fidelity"] for x in ev[f"R8_10_{r}_s{s}"]["consolidation"]] for s in range(5)])
            keep = [i for i in range(per.shape[1]) if i not in empty]
            print(f"{ds}: 10-step {r}: certified fidelity at the task-ending sleeps (seed means) "
                  f"{np.round(100 * per.mean(0), 1).tolist()}; mean over the non-empty ones {100 * per[:, keep].mean():.1f}%")

# gap between bits to certify and bits at which lost, pooled
print("\n-- pooled bits gap")
for ds in S:
    gaps = []
    for p in sorted(glob.glob(os.path.join("evals", ds, "R8_task_refit_s*_bits.npz"))):
        d = np.load(p)
        ok = (d["b_cert"] < 99) & (d["b_keep"] < 99)
        gaps.append(d["b_cert"][ok] - (d["b_keep"][ok] - 1))
    if gaps:
        g = np.concatenate(gaps)
        print(f"{ds}: median gap b_cert - b_lost = {np.median(g):.1f} bits, IQR [{np.quantile(g, 0.25):.1f}, {np.quantile(g, 0.75):.1f}], "
              f"mean {g.mean():.2f}, n {len(g)}")
        g2 = g - 1
        print(f"{ds}: median gap b_cert - b_keep (bits more than the width from which the decision is kept) = "
              f"{np.median(g2):.1f}, IQR [{np.quantile(g2, 0.25):.1f}, {np.quantile(g2, 0.75):.1f}], mean {g2.mean():.2f}")

# timing of the streams (run seconds) per rule
print("\n-- run seconds (mean over seeds)")
for ds in S:
    secs = {}
    for p in glob.glob(os.path.join("runs", ds, "*.json")):
        m = json.load(open(p))
        key = os.path.basename(p)[:-5].rsplit("_s", 1)[0]
        secs.setdefault(key, []).append(m["seconds"])
    print(ds, {k: round(float(np.mean(v)), 1) for k, v in sorted(secs.items())})
