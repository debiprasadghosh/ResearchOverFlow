"""P3 runs (training data only).  Every run is a class-incremental stream of five tasks with wake, sleep and,
in the dynamic arm, storage at reduced precision in the loop.  States after each task are saved for the frozen
evaluator (p3_eval.py), which alone touches the test split.

Usage:
  python3 p3_run.py stream <mnist|cifar100> <R> <task|10> <rule,...> <seed,...>
  python3 p3_run.py dynamic <mnist|cifar100> <policy,...> <seed,...>
  python3 p3_run.py all                       # every registered run, in order
"""
import os
import sys
import json
import time
import hashlib
import numpy as np
import p3lib as L

CONFIG = {
    "R_primary": 8, "k": 8, "scale": 8.0, "lr": 0.01, "floor": 0.05, "epochs": 3, "batch": 128, "rep_batch": 128,
    "n_protected": {"mnist": 50, "cifar100": 20}, "cadence_fast": 10, "refit_steps": 300, "refit_lr": 0.05, "usage_decay": 0.5,
    "n_filters": 16, "seeds": [0, 1, 2, 3, 4], "bbar_primary": 8,
    "rules_task": ["none", "pub", "pub01", "gain_ord", "gain_w", "gain_w1", "resid", "tan", "refit"],
    "rules_fast": ["gain_ord", "gain_w", "gain_w1", "tan", "refit"],
    "policies": ["uniform", "usage", "cert", "exposure"],
}
_FEAT = {}


def feats(dataset):
    if dataset not in _FEAT:
        _FEAT[dataset] = L.features(L.load_dataset(dataset), CONFIG["n_filters"])
    return _FEAT[dataset]


def usage_dict(use, t, R, C):
    decayed = sum(CONFIG["usage_decay"] ** (t - kk) * use[kk] for kk in range(t + 1))
    u = {("class", c): float(decayed[c]) for c in range(C)}
    u.update({("shared", r): float(decayed.sum()) for r in range(R)})
    return u


def allocate(policy, la, lb, bbar, Hprot, seen, usage):
    """Bits per stored unit (the classes seen so far and the shared channel vectors) at equal total bits:
    bbar bits per stored log-weight plus the same per-unit metadata; usage-and-age also pays for its counters."""
    sizes = L.unit_sizes(la, lb, seen)
    budget = int(round(bbar * sum(sizes.values())))
    if policy == "uniform":
        return L.alloc_uniform(la, lb, bbar, seen)
    if policy == "usage":
        return L.alloc_usage(la, lb, budget - len(sizes) * L.USAGE_BITS, usage, seen)
    if policy == "cert":
        return L.alloc_certificate(la, lb, budget, Hprot, seen)
    if policy == "exposure":
        return L.alloc_exposure(la, lb, budget, seen)
    raise ValueError(policy)


def run_stream(dataset, R, cadence, rule, seed, policy=None, bbar=None):
    F = feats(dataset)
    Htr, ytr = F["Htr"], F["ytr"]
    tasks = L.DATASETS[dataset]["tasks"]
    C, Ch, P = L.DATASETS[dataset]["C"], Htr.shape[1], Htr.shape[2]
    cfg = CONFIG
    n_prot = cfg["n_protected"][dataset]
    store = L.init_store(R, C, P, Ch, seed)
    rng = np.random.default_rng(1000 + seed)
    prot_idx, seen = [], []
    use = np.zeros((len(tasks), C))
    states, infos = [], []
    base_rule = "pub" if rule.startswith("pub") else rule
    alpha = 0.1 if rule == "pub01" else 1.0
    skw = {"alpha": alpha, "refit_steps": cfg["refit_steps"], "refit_lr": cfg["refit_lr"]}
    t_start = time.time()
    for t, cls in enumerate(tasks):
        seen = seen + list(cls)
        sel = np.nonzero(np.isin(ytr, cls))[0]
        pidx = np.concatenate(prot_idx) if prot_idx else np.zeros(0, int)
        Hrep = Htr[pidx] if len(pidx) else None
        yrep = ytr[pidx] if len(pidx) else None
        if cadence == "task":
            ad = L.wake(store, Htr[sel], ytr[sel], Hrep, yrep, seen, cfg["k"], cfg["scale"], cfg["floor"], cfg["lr"],
                        cfg["epochs"], seed * 100 + t, batch=cfg["batch"], rep_batch=cfg["rep_batch"])
            inner = []
        else:
            store, ad, inner = L.wake(store, Htr[sel], ytr[sel], Hrep, yrep, seen, cfg["k"], cfg["scale"], cfg["floor"],
                                      cfg["lr"], cfg["epochs"], seed * 100 + t, batch=cfg["batch"],
                                      rep_batch=cfg["rep_batch"], cadence=int(cadence), rule=base_rule, sleep_kw=skw)
        steps = cfg["epochs"] * (len(sel) // cfg["batch"])
        for c in cls:
            use[t, c] += cfg["epochs"] * np.sum(ytr[sel] == c)
        if yrep is not None:
            for c in np.unique(yrep):
                use[t, c] += steps * cfg["rep_batch"] * np.mean(yrep == c)
        before = {k: v.copy() for k, v in store.items()}
        after, info = L.sleep(base_rule, store, ad, cfg["floor"], **skw)
        for c in cls:
            idx = np.nonzero(ytr == c)[0]
            prot_idx.append(np.sort(rng.choice(idx, n_prot, replace=False)))
        state = {"t": t, "seen": list(seen), "before": before, "adapter": ad, "after": {k: v.copy() for k, v in after.items()},
                 "protected": np.concatenate(prot_idx), "use": use[:t + 1].copy()}
        if policy is not None:
            usage = usage_dict(use, t, R, C)
            Hprot = Htr[state["protected"]]
            bits = allocate(policy, after["la"], after["lb"], bbar, Hprot, seen, usage)
            la_q, lb_q, rho, sigma = L.quantize_store(after["la"], after["lb"], bits)
            state.update(bits=bits, la_q=la_q, lb_q=lb_q, rho=rho, sigma=sigma)
            after = {"la": la_q, "lb": lb_q}
        info = {k: (v.tolist() if isinstance(v, np.ndarray) else v) for k, v in info.items()}
        if inner:
            rr = [x["rel_residual"] for x in inner if x["change_norm"] > 0]
            info["inner_sleeps"] = len(inner)
            info["inner_rel_residual_median"] = float(np.median(rr)) if rr else 0.0
            info["inner_rel_change_median"] = float(np.median([x["rel_change"] for x in inner]))
            info["inner_undefined_median"] = float(np.median([x["undefined_base_frac"] for x in inner])) \
                if "undefined_base_frac" in inner[0] else None
        infos.append(info)
        states.append(state)
        store = after
    return states, infos, time.time() - t_start


def save_run(path, states, infos, meta):
    arrays = {}
    for s in states:
        t = s["t"]
        for part in ("before", "after"):
            for k, v in s[part].items():
                arrays[f"t{t}_{part}_{k}"] = v
        arrays[f"t{t}_U"] = s["adapter"]["U"]
        arrays[f"t{t}_V"] = s["adapter"]["V"]
        arrays[f"t{t}_protected"] = s["protected"]
        arrays[f"t{t}_use"] = s["use"]
        for k in ("la_q", "lb_q", "rho", "sigma"):
            if k in s:
                arrays[f"t{t}_{k}"] = s[k]
        if "bits" in s:
            arrays[f"t{t}_bits"] = np.array([[0 if u[0] == "class" else 1, u[1], b] for u, b in s["bits"].items()])
    np.savez_compressed(path + ".npz", **arrays)
    meta = dict(meta)
    meta["infos"] = infos
    meta["seen"] = [s["seen"] for s in states]
    json.dump(meta, open(path + ".json", "w"), indent=1)


def code_hashes():
    out = {}
    for f in ("p3lib.py", "p3_run.py"):
        out[f] = hashlib.sha256(open(os.path.join(L.HERE, f), "rb").read()).hexdigest()
    return out


def stage_stream(dataset, R, cadence, rules, seeds):
    os.makedirs(os.path.join("runs", dataset), exist_ok=True)
    for rule in rules:
        for seed in seeds:
            name = f"R{R}_{cadence}_{rule}_s{seed}"
            path = os.path.join("runs", dataset, name)
            if os.path.exists(path + ".json"):
                continue
            states, infos, secs = run_stream(dataset, R, cadence, rule, seed)
            save_run(path, states, infos, {"dataset": dataset, "R": R, "cadence": cadence, "rule": rule, "seed": seed,
                                           "seconds": secs, "config": CONFIG, "code_sha256": code_hashes()})
            print(f"{dataset} {name}: {secs:.0f}s  final rel residual {infos[-1]['rel_residual']:.3f}", flush=True)


def stage_dynamic(dataset, policies, seeds):
    os.makedirs(os.path.join("runs", dataset), exist_ok=True)
    R = CONFIG["R_primary"]
    for pol in policies:
        for seed in seeds:
            name = f"dyn_{pol}_s{seed}"
            path = os.path.join("runs", dataset, name)
            if os.path.exists(path + ".json"):
                continue
            states, infos, secs = run_stream(dataset, R, "task", "refit", seed, policy=pol, bbar=CONFIG["bbar_primary"])
            save_run(path, states, infos, {"dataset": dataset, "R": R, "cadence": "task", "rule": "refit", "seed": seed,
                                           "policy": pol, "bbar": CONFIG["bbar_primary"], "seconds": secs,
                                           "config": CONFIG, "code_sha256": code_hashes()})
            print(f"{dataset} {name}: {secs:.0f}s", flush=True)


def main():
    stage = sys.argv[1]
    if stage == "stream":
        stage_stream(sys.argv[2], int(sys.argv[3]), sys.argv[4], sys.argv[5].split(","),
                     [int(x) for x in sys.argv[6].split(",")])
    elif stage == "dynamic":
        stage_dynamic(sys.argv[2], sys.argv[3].split(","), [int(x) for x in sys.argv[4].split(",")])
    elif stage == "all":
        seeds = CONFIG["seeds"]
        for ds in ("mnist", "cifar100"):
            stage_stream(ds, 8, "task", CONFIG["rules_task"], seeds)
            stage_stream(ds, 1, "task", CONFIG["rules_task"], seeds)
            stage_stream(ds, 8, str(CONFIG["cadence_fast"]), CONFIG["rules_fast"], seeds)
            stage_dynamic(ds, CONFIG["policies"], seeds)
    else:
        raise SystemExit(__doc__)


if __name__ == "__main__":
    main()
