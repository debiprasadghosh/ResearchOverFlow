#!/usr/bin/env python3
"""
p1_run.py -- training stages for Paper P1 (MNIST).

  python3 p1_run.py pilot        learning-rate pilots at width 256 (pilot seed 0),
                                 robust-margin coefficient pilot; validation only;
                                 writes runs/config.json (the frozen configuration)
  python3 p1_run.py confirm      5 seeds x 4 widths for every family, frozen config
  python3 p1_run.py ablate       exploratory: training logit scale c at width 1024

Every run saves its float32 parameters, training history and validation metrics
to runs/<tag>.npz. Existing runs are skipped, so a stage can be resumed. The test
set is not touched here; p1_eval.py reads it after all training has finished.
"""
import json
import os
import sys
import time

import numpy as np

import p1lib as L

RUNS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "runs")
os.makedirs(RUNS, exist_ok=True)
CONFIG = os.path.join(RUNS, "config.json")

WIDTHS = (64, 256, 1024, 4096)
SEEDS = (11, 23, 37, 53, 71)
PILOT_SEED = 0
PILOT_WIDTH = 256
LRS = (3e-4, 1e-3, 3e-3)
EPOCHS, BATCH = 20, 256
C_LOGIT = 8.0
ROBUST_RHO = 0.01
ROBUST_GRID = [(lam, gam) for lam in (0.1, 1.0) for gam in (0.05, 0.25)]
FAMILIES = {                       # family tag -> make_model kwargs
    "pos": dict(),
    "signed": dict(),
    "tail_T1": dict(T=1.0),
    "tail_T0.25": dict(T=0.25),
    "tail_T4": dict(T=4.0),
    "deep": dict(),
}


def base_family(tag):
    return "tail" if tag.startswith("tail") else tag


def run_one(D, tag, family, w, seed, lr, kw, hinge=None, epochs=EPOCHS):
    path = os.path.join(RUNS, f"{tag}_w{w}_s{seed}.npz")
    if os.path.exists(path):
        return json.loads(str(np.load(path)["meta"]))
    t0 = time.time()
    model = L.make_model(base_family(family), w, seed, **kw)
    hist = L.train(model, D["Xtr"], D["ytr"], lr, epochs=epochs, batch=BATCH, seed=seed, hinge=hinge)
    va_acc, va_loss = L.evaluate_nominal(model, D["Xva"], D["yva"])
    meta = {"tag": tag, "family": family, "width": w, "seed": seed, "lr": lr, "kw": kw, "hinge": hinge,
            "epochs": epochs, "batch": BATCH, "train_loss": hist, "val_acc": float(va_acc),
            "val_loss": float(va_loss), "train_seconds": time.time() - t0}
    if model.positive_logits:
        Ls = model.forward(D["Xva"]).astype(np.float64)
        logy = Ls / model.c
        c = logy.argmax(1)
        s = np.sort(logy, 1)
        m = s[:, -1] - s[:, -2]
        meta["val_cert_acc_rho0.01"] = float(np.mean((c == D["yva"]) & (m > 2 * ROBUST_RHO)))
    L.save_model(model, path, meta)
    print(f"  {tag:12s} w={w:5d} seed={seed:3d} lr={lr:g}: val acc {va_acc:.4f} loss {va_loss:.4f}"
          f" ({meta['train_seconds']:.0f}s)", flush=True)
    return meta


def pilot():
    D = L.load_mnist()
    cfg = {"data": {"hashes": D["hashes"], "split_seed": L.SPLIT_SEED, "split_sha256": D["split_sha256"],
                    "n_train": int(len(D["ytr"])), "n_val": int(len(D["yva"])), "n_test": int(len(D["yte"]))},
           "protocol": {"widths": WIDTHS, "seeds": SEEDS, "pilot_seed": PILOT_SEED, "pilot_width": PILOT_WIDTH,
                        "lrs": LRS, "epochs": EPOCHS, "batch": BATCH, "c_logit": C_LOGIT,
                        "tail_hidden_width": 256, "deep_hidden_width": 256},
           "lr": {}, "pilot": {}}
    np.savez(os.path.join(RUNS, "split_indices.npz"), train_idx=D["train_idx"], val_idx=D["val_idx"])
    print("pilot: learning rates at width 256 (validation only)", flush=True)
    for tag, kw in FAMILIES.items():
        res = []
        for lr in LRS:
            meta = run_one(D, f"pilot_{tag}_lr{lr:g}", tag, PILOT_WIDTH, PILOT_SEED, lr, kw)
            res.append((meta["val_acc"], -meta["val_loss"], lr))
        best = max(res)
        cfg["lr"][tag] = best[2]
        cfg["pilot"][tag] = [{"lr": r[2], "val_acc": r[0], "val_loss": -r[1]} for r in res]
        print(f"  -> {tag}: lr {best[2]:g}", flush=True)
    print("pilot: robust-margin coefficient (positive readout, frozen lr)", flush=True)
    res = []
    for lam, gam in ROBUST_GRID:
        hinge = {"lam": lam, "rho": ROBUST_RHO, "gamma": gam}
        meta = run_one(D, f"pilot_robust_lam{lam:g}_gam{gam:g}", "robust", PILOT_WIDTH, PILOT_SEED,
                       cfg["lr"]["pos"], {}, hinge=hinge)
        res.append((meta["val_cert_acc_rho0.01"], meta["val_acc"], lam, gam))
    best = max(res)
    cfg["robust"] = {"lam": best[2], "gamma": best[3], "rho": ROBUST_RHO,
                     "grid": [{"lam": r[2], "gamma": r[3], "val_cert_acc_rho0.01": r[0], "val_acc": r[1]} for r in res]}
    print(f"  -> robust: lam {best[2]:g}, gamma {best[3]:g}", flush=True)
    cfg["frozen_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(CONFIG, "w") as f:
        json.dump(cfg, f, indent=1)
    print("config frozen:", CONFIG, flush=True)


def confirm():
    with open(CONFIG) as f:
        cfg = json.load(f)
    D = L.load_mnist()
    order = ["pos", "signed", "robust", "deep", "tail_T1", "tail_T0.25", "tail_T4"]
    for tag in order:
        print(f"confirm: {tag}", flush=True)
        for w in WIDTHS:
            for seed in SEEDS:
                if tag == "robust":
                    r = cfg["robust"]
                    hinge = {"lam": r["lam"], "rho": r["rho"], "gamma": r["gamma"]}
                    run_one(D, tag, "robust", w, seed, cfg["lr"]["pos"], {}, hinge=hinge)
                else:
                    run_one(D, tag, tag, w, seed, cfg["lr"][tag], FAMILIES[tag])


def ablate():
    with open(CONFIG) as f:
        cfg = json.load(f)
    D = L.load_mnist()
    print("ablation (exploratory): training logit scale c, positive readout, width 1024", flush=True)
    for c in (2.0, 4.0, 16.0, 32.0):
        for seed in SEEDS[:3]:
            run_one(D, f"ablate_c{c:g}", "pos", 1024, seed, cfg["lr"]["pos"], {"c": c})


if __name__ == "__main__":
    stage = sys.argv[1]
    {"pilot": pilot, "confirm": confirm, "ablate": ablate}[stage]()
