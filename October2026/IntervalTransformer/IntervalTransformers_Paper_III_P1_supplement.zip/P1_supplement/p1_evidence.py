#!/usr/bin/env python3
"""
p1_evidence.py -- controlled evidence-accumulation task for Paper P1.

    python3 p1_evidence.py pilot      choose mu on a pilot split; learning-rate pilot at width 256
    python3 p1_evidence.py confirm    5 seeds x 4 widths, positive and signed readouts
    python3 p1_evidence.py explore    exploratory: duplicated-block control, block-count sweep
    python3 p1_evidence.py evaluate   test-set evaluation of every trained run
    python3 p1_evidence.py report     summary tables -> evidence/summary.json

Task (Paper II, Section 4.2). A balanced label c in {-1, +1}; n conditionally
independent blocks z_g ~ N(c mu, 1). Each block is encoded separately by a fixed
positive map with k features (no cross-block mixing); the tested positive stage is
a trained positive readout y_k = sum_i exp(Theta_ki) phi_i, logits 8 log y. The
matched control is a signed readout on the same features. Width = n k.

Oracles on the same test examples: Bayes sign(sum_g z_g); the four-block oracle
sign of the sum of the four largest-|z| blocks.
"""
import json
import os
import sys
import time

import numpy as np
from scipy.stats import binomtest

import p1lib as L

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "evidence")
RUNS = os.path.join(OUT, "runs")
EVALS = os.path.join(OUT, "evals")
CONFIG = os.path.join(OUT, "config.json")
for d_ in (OUT, RUNS, EVALS):
    os.makedirs(d_, exist_ok=True)

N_BLOCKS = 16
WIDTHS = (64, 256, 1024, 4096)          # k = 4, 16, 64, 256 features per block
SEEDS = (11, 23, 37, 53, 71)
PILOT_SEED = 0
LRS = (3e-4, 1e-3, 3e-3)
EPOCHS, BATCH = 20, 256
C_LOGIT = 8.0
MU_GRID = (0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.5)
N_PILOT, N_TRAIN, N_VAL, N_TEST = 20000, 50000, 10000, 20000
DATA_SEED = 20261005                    # train +0, val +1, test +2, mu pilot +3
SLOPE, T_LO, T_HI = 1.0, -2.0, 2.0
RHOS = (0.0025, 0.005, 0.01, 0.02, 0.05, 0.1)
MC_DRAWS, MC_SUB = 16, 4000


# ---------------------------------------------------------------------------
# data and features
# ---------------------------------------------------------------------------
def make_data(n, mu, seed, n_blocks=N_BLOCKS, dup=1):
    """Balanced labels; n_blocks // dup independent sources, each repeated dup times."""
    rng = np.random.default_rng(seed)
    c = rng.permutation(np.repeat([-1, 1], n // 2))
    src = rng.normal(0.0, 1.0, (n, n_blocks // dup)) + c[:, None] * mu
    return np.repeat(src, dup, axis=1), c


def block_features(z, k):
    """Fixed positive map per block: k/2 increasing and k/2 decreasing logistic units with
    thresholds evenly spaced on [-2, 2]; block-major layout (block g -> columns g k .. g k + k - 1)."""
    t = np.linspace(T_LO, T_HI, k // 2)
    inc = L.sigmoid(SLOPE * (z[:, :, None] - t))
    return np.concatenate([inc, 1.0 - inc], 2).reshape(len(z), -1)


def oracles(z, c):
    bayes = np.sign(z.sum(1)) == c
    idx = np.argsort(-np.abs(z), 1)[:, :4]
    top4 = np.sign(np.take_along_axis(z, idx, 1).sum(1)) == c
    return bayes, top4


# ---------------------------------------------------------------------------
# readouts on fixed features
# ---------------------------------------------------------------------------
class PosFixed:
    positive_logits = True

    def __init__(self, w, rng, c=C_LOGIT):
        self.c = c
        self.p = {"Th": (np.log(1.0 / w) + rng.normal(0, 0.1, (2, w))).astype(np.float32)}

    def forward(self, Phi):
        A = np.exp(self.p["Th"])
        Y = Phi @ A.T
        self.cache = (Phi, A, Y)
        return self.c * np.log(np.maximum(Y, 1e-30))

    def backward(self, dL, extra=None):
        Phi, A, Y = self.cache
        dY = self.c * dL / Y
        return {"Th": (dY.T @ Phi) * A}


class SignedFixed:
    positive_logits = False

    def __init__(self, w, rng):
        self.p = {"V": rng.normal(0, 1.0 / np.sqrt(w), (2, w)).astype(np.float32), "d": np.zeros(2, np.float32)}

    def forward(self, Phi):
        self.cache = Phi
        return Phi @ self.p["V"].T + self.p["d"]

    def backward(self, dL, extra=None):
        return {"V": dL.T @ self.cache, "d": dL.sum(0)}


def make(fam, w, seed):
    rng = np.random.default_rng(seed)
    if fam == "pos":
        return PosFixed(w, rng)
    model = SignedFixed(w, rng)
    if fam == "signed0":                  # exploratory control: start from zero weights
        model.p["V"][:] = 0.0
    return model


def train(model, z, y, k, lr, seed):
    rng = np.random.default_rng(10_000 + seed)
    opt = L.Adam(model.p, lr)
    hist = []
    for ep in range(EPOCHS):
        perm = rng.permutation(len(y))
        tot = 0.0
        for i in range(0, len(y), BATCH):
            idx = perm[i:i + BATCH]
            Phi = block_features(z[idx], k).astype(np.float32)
            loss, dL = L.ce_and_grad(model.forward(Phi), y[idx])
            opt.step(model.p, model.backward(dL))
            tot += loss * len(idx)
        hist.append(tot / len(y))
    return hist


def logits(model, z, k, chunk=5000):
    return np.concatenate([model.forward(block_features(z[i:i + chunk], k).astype(np.float32)).astype(np.float64)
                           for i in range(0, len(z), chunk)])


def nominal(model, z, y, k):
    Lg = logits(model, z, k)
    return float((Lg.argmax(1) == y).mean()), float(-L.log_softmax(Lg)[np.arange(len(y)), y].mean())


def data_splits(mu, n_blocks=N_BLOCKS, dup=1):
    off = 0 if (n_blocks, dup) == (N_BLOCKS, 1) else 100 * n_blocks + 10 * dup
    ztr, ctr = make_data(N_TRAIN, mu, DATA_SEED + off, n_blocks, dup)
    zva, cva = make_data(N_VAL, mu, DATA_SEED + off + 1, n_blocks, dup)
    return ztr, (ctr > 0).astype(np.int64), zva, (cva > 0).astype(np.int64)


def run_one(tag, fam, w, seed, lr, mu, n_blocks=N_BLOCKS, dup=1):
    path = os.path.join(RUNS, f"{tag}_w{w}_s{seed}.npz")
    if os.path.exists(path):
        return json.loads(str(np.load(path)["meta"]))
    k = w // n_blocks
    ztr, ytr, zva, yva = data_splits(mu, n_blocks, dup)
    model = make(fam, w, seed)
    t0 = time.time()
    hist = train(model, ztr, ytr, k, lr, seed)
    va_acc, va_loss = nominal(model, zva, yva, k)
    meta = {"tag": tag, "family": fam, "width": w, "k": k, "n_blocks": n_blocks, "dup": dup, "seed": seed,
            "lr": lr, "mu": mu, "train_loss": hist, "val_acc": va_acc, "val_loss": va_loss,
            "train_seconds": time.time() - t0}
    np.savez_compressed(path, **model.p, meta=json.dumps(meta))
    print(f"  {tag:14s} w={w:5d} seed={seed:3d} lr={lr:g}: val acc {va_acc:.4f} loss {va_loss:.4f}", flush=True)
    return meta


# ---------------------------------------------------------------------------
# stages
# ---------------------------------------------------------------------------
def pilot():
    cfg = {"task": {"n_blocks": N_BLOCKS, "widths": WIDTHS, "slope": SLOPE, "thresholds": [T_LO, T_HI],
                    "n_pilot": N_PILOT, "n_train": N_TRAIN, "n_val": N_VAL, "n_test": N_TEST,
                    "data_seed": DATA_SEED, "seeds": SEEDS, "epochs": EPOCHS, "batch": BATCH, "c_logit": C_LOGIT},
           "mu_pilot": []}
    print("pilot: mu on a separate pilot split (largest Bayes minus four-block accuracy gap)", flush=True)
    for mu in MU_GRID:
        z, c = make_data(N_PILOT, mu, DATA_SEED + 3)
        b, t4 = oracles(z, c)
        cfg["mu_pilot"].append({"mu": mu, "bayes_acc": float(b.mean()), "top4_acc": float(t4.mean()),
                                "gap": float(b.mean() - t4.mean())})
        print(f"  mu {mu:4.2f}: Bayes {b.mean():.4f}  four-block {t4.mean():.4f}  gap {b.mean() - t4.mean():.4f}")
    mu = max(cfg["mu_pilot"], key=lambda r: r["gap"])["mu"]
    cfg["mu"] = mu
    print(f"  -> mu = {mu}", flush=True)
    cfg["lr"], cfg["lr_pilot"] = {}, {}
    for fam in ("pos", "signed"):
        res = []
        for lr in LRS:
            meta = run_one(f"pilot_{fam}_lr{lr:g}", fam, 256, PILOT_SEED, lr, mu)
            res.append((meta["val_acc"], -meta["val_loss"], lr))
        cfg["lr"][fam] = max(res)[2]
        cfg["lr_pilot"][fam] = [{"lr": r[2], "val_acc": r[0], "val_loss": -r[1]} for r in res]
        print(f"  -> {fam}: lr {cfg['lr'][fam]:g}", flush=True)
    cfg["frozen_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(CONFIG, "w") as f:
        json.dump(cfg, f, indent=1)


def load_cfg():
    with open(CONFIG) as f:
        return json.load(f)


def confirm():
    cfg = load_cfg()
    for fam in ("pos", "signed"):
        print(f"confirm: {fam}", flush=True)
        for w in WIDTHS:
            for s in SEEDS:
                run_one(fam, fam, w, s, cfg["lr"][fam], cfg["mu"])


def explore():
    cfg = load_cfg()
    print("explore: duplicated blocks (4 sources x 4 copies), width 256", flush=True)
    for fam in ("pos", "signed"):
        for s in SEEDS:
            run_one(f"dup4_{fam}", fam, 256, s, cfg["lr"][fam], cfg["mu"], N_BLOCKS, 4)
    print("explore: signed readout started from zero weights (all widths)", flush=True)
    for w in WIDTHS:
        for s_ in SEEDS:
            run_one("signed0", "signed0", w, s_, cfg["lr"]["signed"], cfg["mu"])
    print("explore: block count n = 4 and 64 at k = 16", flush=True)
    for n in (4, 64):
        for fam in ("pos", "signed"):
            for s in SEEDS:
                run_one(f"n{n}_{fam}", fam, 16 * n, s, cfg["lr"][fam], cfg["mu"], n, 1)


# ---------------------------------------------------------------------------
# evaluation
# ---------------------------------------------------------------------------
def signed_radius(Phi, V, d, c):
    """Exact sign-preserving multiplicative readout radius (bias = weight on a constant 1)."""
    n = len(c)
    r = np.arange(n)
    j = 1 - c
    P = Phi @ np.maximum(V, 0).T + np.maximum(d, 0)
    N = Phi @ np.maximum(-V, 0).T + np.maximum(-d, 0)
    A = P[r, c] + N[r, j]
    B = N[r, c] + P[r, j]
    with np.errstate(divide="ignore"):
        return np.maximum(0.5 * np.log(A / B), 0.0)


def evaluate_run(path, z, ylab, groups_src, chunk=4000):
    zf = np.load(path, allow_pickle=False)
    meta = json.loads(str(zf["meta"]))
    k, fam = meta["k"], meta["family"]
    parts = []
    for i0 in range(0, len(ylab), chunk):
        Phi = block_features(z[i0:i0 + chunk], k)
        n = len(Phi)
        r = np.arange(n)
        if fam == "pos":
            A = np.exp(zf["Th"].astype(np.float64))
            Y = Phi @ A.T
            logy = np.log(Y)
            c = logy.argmax(1)
            j = 1 - c
            m = logy[r, c] - logy[r, j]
            radius = m / 2
            p = A[c] * Phi / Y[r, c][:, None]
            # block mediant bound: m <= max_g log(A_g / B_g)
            Ag = (A[c] * Phi).reshape(n, -1, k).sum(2)
            Bg = (A[j] * Phi).reshape(n, -1, k).sum(2)
            extra = {"block_best_logratio": np.log(Ag / Bg).max(1)}
        else:
            V, d = zf["V"].astype(np.float64), zf["d"].astype(np.float64)
            Lg = Phi @ V.T + d
            c = Lg.argmax(1)
            m = Lg[r, c] - Lg[r, 1 - c]
            radius = signed_radius(Phi, V, d, c)
            T = np.abs(V[c] * Phi)
            p = T / T.sum(1, keepdims=True)
            extra = {}
        PB = p.reshape(n, -1, k).sum(2)
        # decision fan-in: participation of each block's contribution to y_c - y_j (bias excluded)
        Wm = A if fam == "pos" else V
        DB = ((Wm[c] - Wm[1 - c]) * Phi).reshape(n, -1, k).sum(2)
        part = {"correct": c == ylab[i0:i0 + chunk], "pred": c.astype(np.int8), "margin": m, "radius": radius,
                "fanin": 1.0 / np.sum(p * p, 1), "fanin_block": 1.0 / np.sum(PB * PB, 1),
                "dfanin_block": decision_fanin(DB)}
        if groups_src is not None:
            nsrc = groups_src.max() + 1
            PS = np.stack([PB[:, groups_src == s_].sum(1) for s_ in range(nsrc)], 1)
            part["fanin_source"] = 1.0 / np.sum(PS * PS, 1)
            DS = np.stack([DB[:, groups_src == s_].sum(1) for s_ in range(nsrc)], 1)
            part["dfanin_source"] = decision_fanin(DS)
        part.update(extra)
        parts.append(part)
    out = {key: np.concatenate([pt[key] for pt in parts]) for key in parts[0]}
    mc = {}
    if fam == "pos":
        # random perturbations uniform inside the log box (a nominal estimate, not a certificate)
        Th = zf["Th"].astype(np.float64)
        rng = np.random.default_rng(777)
        sub = np.sort(rng.choice(len(ylab), min(MC_SUB, len(ylab)), replace=False))
        Phi = block_features(z[sub], k)
        for rho in (0.02, 0.05, 0.1):
            flips = 0
            for _ in range(MC_DRAWS):
                Yp = Phi @ np.exp(Th + rng.uniform(-rho, rho, Th.shape)).T
                flips += int(np.sum(Yp.argmax(1) != out["pred"][sub]))
            mc[f"{rho:g}"] = flips / (len(sub) * MC_DRAWS)
    return out, meta, mc


def decision_fanin(D):
    """Participation ratio of signed contributions D (examples x groups): (sum |D|)^2 / sum D^2."""
    a = np.abs(D)
    return a.sum(1) ** 2 / np.maximum((a * a).sum(1), 1e-300)


def oracle_dfanin(z, dup):
    """Decision fan-in of the Bayes rule (contributions z_g) and of the four-block oracle, by source."""
    src = z[:, ::dup]
    idx = np.argsort(-np.abs(z), 1)[:, :4]
    top = np.zeros_like(z)
    np.put_along_axis(top, idx, np.take_along_axis(z, idx, 1), 1)
    top_src = top.reshape(len(z), -1, dup).sum(2)
    return float(np.median(decision_fanin(src))), float(np.median(decision_fanin(top_src)))


def mcnemar_greater(a, b):
    """One-sided exact McNemar test that classifier a is more accurate than b on paired examples."""
    n10 = int(np.sum(a & ~b))
    n01 = int(np.sum(~a & b))
    if n10 + n01 == 0:
        return 1.0, n10, n01
    return float(binomtest(n10, n10 + n01, 0.5, alternative="greater").pvalue), n10, n01


def evaluate():
    cfg = load_cfg()
    mu = cfg["mu"]
    tests = {}
    for f in sorted(os.listdir(RUNS)):
        if f.startswith("pilot_") or not f.endswith(".npz"):
            continue
        po = os.path.join(EVALS, f)
        if os.path.exists(po):
            continue
        meta = json.loads(str(np.load(os.path.join(RUNS, f))["meta"]))
        key = (meta["n_blocks"], meta["dup"])
        if key not in tests:
            off = 0 if key == (N_BLOCKS, 1) else 100 * key[0] + 10 * key[1]
            z, cl = make_data(N_TEST, mu, DATA_SEED + off + 2, key[0], key[1])
            tests[key] = (z, (cl > 0).astype(np.int64), cl)
        z, ylab, cl = tests[key]
        groups_src = np.repeat(np.arange(key[0] // key[1]), key[1]) if key[1] > 1 else None
        out, meta, mc = evaluate_run(os.path.join(RUNS, f), z, ylab, groups_src)
        bayes, top4 = oracles(z, cl)
        p_top4, n10, n01 = mcnemar_greater(out["correct"], top4)
        scal = {"acc": float(out["correct"].mean()), "bayes_acc": float(bayes.mean()), "top4_acc": float(top4.mean()),
                "agree_bayes": float(np.mean((out["pred"] == 1) == (z.sum(1) > 0))),
                "mcnemar_vs_top4": {"p_one_sided": p_top4, "model_only": n10, "top4_only": n01},
                "mc_flip_rate": mc}
        arrays = {k_: (np.asarray(v).astype(np.float32) if np.asarray(v).dtype == np.float64 else v)
                  for k_, v in out.items()}
        np.savez_compressed(po, **arrays, bayes=bayes, top4=top4, scal=json.dumps(scal), meta=json.dumps(meta))
        print(f"  {f:28s} acc {scal['acc']:.4f}  Bayes {scal['bayes_acc']:.4f}  four-block {scal['top4_acc']:.4f}"
              f"  p {p_top4:.2e}", flush=True)


def tci(v):
    v = np.asarray(v, float)
    if len(v) < 2:
        return [float(v.mean()), float("nan"), float("nan")]
    from scipy.stats import t
    h = t.ppf(0.975, len(v) - 1) * v.std(ddof=1) / np.sqrt(len(v))
    return [float(v.mean()), float(v.mean() - h), float(v.mean() + h)]


def fanin_demo(cfg, path=os.path.join(RUNS, "pos_w256_s11.npz"), n_ex=5000):
    """Mass fan-in by block counts constant mass: make every block but the first identical across the
    two rows of a trained positive readout, so that its decision uses one block, and compare."""
    z, cl = make_data(N_TEST, cfg["mu"], DATA_SEED + 2)
    z, ylab = z[:n_ex], (cl[:n_ex] > 0).astype(int)
    k = 16
    Phi = block_features(z, k)
    A = np.exp(np.load(path)["Th"].astype(np.float64))
    A1 = A.copy().reshape(2, N_BLOCKS, k)
    A1[:, 1:, :] = A1[:, 1:, :].mean(0, keepdims=True)
    out = {}
    for name, W in (("trained", A), ("one_block", A1.reshape(2, -1))):
        Y = Phi @ W.T
        c = Y.argmax(1)
        r = np.arange(len(c))
        PB = (W[c] * Phi / Y[r, c][:, None]).reshape(len(c), N_BLOCKS, k).sum(2)
        DB = ((W[c] - W[1 - c]) * Phi).reshape(len(c), N_BLOCKS, k).sum(2)
        out[name] = {"acc": float(np.mean(c == ylab)), "median_mass_fanin_block": float(np.median(1 / np.sum(PB * PB, 1))),
                     "median_decision_fanin_block": float(np.median(decision_fanin(DB)))}
    return out


def config_of(tag):
    nb = 4 if tag.startswith("n4_") else (64 if tag.startswith("n64_") else N_BLOCKS)
    dup = 4 if tag.startswith("dup4_") else 1
    return nb, dup


def report():
    from scipy.stats import spearmanr
    cfg = load_cfg()
    mu = cfg["mu"]
    tests = {}

    def test_set(nb, dup):
        if (nb, dup) not in tests:
            off = 0 if (nb, dup) == (N_BLOCKS, 1) else 100 * nb + 10 * dup
            z, cl = make_data(N_TEST, mu, DATA_SEED + off + 2, nb, dup)
            llr = 2 * mu * z[:, ::dup].sum(1)
            tests[(nb, dup)] = (z, cl, llr, oracle_dfanin(z, dup))
        return tests[(nb, dup)]
    rows = {}
    for f in sorted(os.listdir(EVALS)):
        zf = np.load(os.path.join(EVALS, f), allow_pickle=False)
        meta, scal = json.loads(str(zf["meta"])), json.loads(str(zf["scal"]))
        key = f"{meta['tag']}_w{meta['width']}"
        nb, dup = config_of(meta["tag"])
        z, cl, llr, (df_bayes, df_top4) = test_set(nb, dup)
        cor = zf["correct"]
        rad = zf["radius"].astype(float)
        mar = zf["margin"].astype(float)
        scale = C_LOGIT if meta["family"] == "pos" else 1.0
        rec = {"seed": meta["seed"], "acc": scal["acc"], "bayes_acc": scal["bayes_acc"], "top4_acc": scal["top4_acc"],
               "acc_minus_top4": scal["acc"] - scal["top4_acc"], "p_vs_top4": scal["mcnemar_vs_top4"]["p_one_sided"],
               "agree_bayes": scal["agree_bayes"], "train_seconds": meta["train_seconds"],
               "median_margin": float(np.median(mar)), "median_radius": float(np.median(rad)),
               "median_fanin": float(np.median(zf["fanin"])), "median_fanin_block": float(np.median(zf["fanin_block"])),
               "median_dfanin_block": float(np.median(zf["dfanin_block"])),
               "cert_acc": {f"{rho:g}": float(np.mean(cor & (rad > rho))) for rho in RHOS},
               "cert_share_of_correct_0.01": float(np.mean(rad[cor] > 0.01)),
               "mc_flip_rate": scal["mc_flip_rate"],
               "median_abs_llr": float(np.median(np.abs(llr))),
               "median_abs_llr_over_scale": float(np.median(np.abs(llr)) / scale),
               "spearman_margin_abs_llr": float(spearmanr(mar, np.abs(llr)).correlation),
               "oracle_dfanin_bayes": df_bayes, "oracle_dfanin_top4": df_top4}
        if meta["family"] == "pos":
            Th = np.load(os.path.join(RUNS, f), allow_pickle=False)["Th"]
            rec["logw_span"] = float(Th.max() - Th.min())
        if "fanin_source" in zf.files:
            rec["median_fanin_source"] = float(np.median(zf["fanin_source"]))
            rec["median_dfanin_source"] = float(np.median(zf["dfanin_source"]))
        if "block_best_logratio" in zf.files:
            rec["median_block_best_logratio"] = float(np.median(zf["block_best_logratio"]))
            rec["mediant_bound_holds"] = bool(np.all(zf["margin"] <= zf["block_best_logratio"] + 1e-5))
        rows.setdefault(key, []).append(rec)
    summary = {}
    for key, recs in rows.items():
        recs = sorted(recs, key=lambda r: r["seed"])
        ps = [r["p_vs_top4"] for r in recs]
        opt = lambda name: tci([r[name] for r in recs]) if name in recs[0] else None
        summary[key] = {"per_seed": recs,
                        "median_abs_bayes_logodds": recs[0]["median_abs_llr"],
                        "median_abs_llr_over_scale": recs[0]["median_abs_llr_over_scale"],
                        "oracle_dfanin_bayes": recs[0]["oracle_dfanin_bayes"],
                        "oracle_dfanin_top4": recs[0]["oracle_dfanin_top4"],
                        "cert_acc": {f"{rho:g}": tci([r["cert_acc"][f"{rho:g}"] for r in recs]) for rho in RHOS},
                        "cert_share_of_correct_0.01": tci([r["cert_share_of_correct_0.01"] for r in recs]),
                        "mc_flip_rate": ({k_: float(np.mean([r["mc_flip_rate"][k_] for r in recs]))
                                          for k_ in recs[0]["mc_flip_rate"]} if recs[0]["mc_flip_rate"] else {}),
                        "median_fanin_source": opt("median_fanin_source"),
                        "median_dfanin_source": opt("median_dfanin_source"),
                        "median_block_best_logratio": opt("median_block_best_logratio"),
                        "logw_span": opt("logw_span"),
                        "spearman_margin_abs_llr": tci([r["spearman_margin_abs_llr"] for r in recs]),
                        "agree_bayes": tci([r["agree_bayes"] for r in recs]),
                        "train_seconds": tci([r["train_seconds"] for r in recs]),
                        "acc": tci([r["acc"] for r in recs]),
                        "acc_minus_top4": tci([r["acc_minus_top4"] for r in recs]),
                        "bayes_acc": recs[0]["bayes_acc"], "top4_acc": recs[0]["top4_acc"],
                        "max_p_vs_top4": max(ps),
                        "median_fanin_block": tci([r["median_fanin_block"] for r in recs]),
                        "median_dfanin_block": tci([r["median_dfanin_block"] for r in recs]),
                        "median_fanin": tci([r["median_fanin"] for r in recs]),
                        "median_margin": tci([r["median_margin"] for r in recs]),
                        "median_radius": tci([r["median_radius"] for r in recs]),
                        "cert_acc_0.01": tci([r["cert_acc"]["0.01"] for r in recs])}
    summary["fanin_demo"] = fanin_demo(cfg)
    with open(os.path.join(OUT, "summary.json"), "w") as f:
        json.dump(summary, f, indent=1)
    print("fan-in demonstration:", summary["fanin_demo"])
    for key in sorted(summary):
        if key == "fanin_demo":
            continue
        s_ = summary[key]
        print(f"{key:18s} acc {s_['acc'][0]:.4f}  Bayes {s_['bayes_acc']:.4f}  four-block {s_['top4_acc']:.4f}"
              f"  max p {s_['max_p_vs_top4']:.1e}  dfan {s_['median_dfanin_block'][0]:.2f} (Bayes {s_['oracle_dfanin_bayes']:.2f},"
              f" four {s_['oracle_dfanin_top4']:.2f})  m50 {s_['median_margin'][0]:.4f} (|LLR|/c {s_['median_abs_llr_over_scale']:.4f},"
              f" rho {s_['spearman_margin_abs_llr'][0]:.3f})  r50 {s_['median_radius'][0]:.4f}  cert@0.01 {s_['cert_acc_0.01'][0]:.4f}")


if __name__ == "__main__":
    {"pilot": pilot, "confirm": confirm, "explore": explore, "evaluate": evaluate, "report": report}[sys.argv[1]]()
