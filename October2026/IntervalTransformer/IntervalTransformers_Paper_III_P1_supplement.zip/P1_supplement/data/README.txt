Place the four MNIST IDX .gz files here (see README.md for MD5 sums).
