"""
p1lib.py -- shared code for Paper P1 (Log Interval Networks for Evidence
Accumulation and Certified Decisions).

numpy only. Training runs in float32; every certificate is computed in
float64 from the stored float32 parameters.

Model families (all share the feature layer h = sigmoid(F x + b) > 0):
  pos      positive readout          y = exp(Theta) h,           logits = c log y
  signed   signed readout            logits = V h + d
  tail     positive tail             u = T log(exp(Psi/T) h^(1/T)), z = softplus(u),
                                     y = exp(Theta) z,           logits = c log y
  deep     deep signed control       g = sigmoid(G h + e),       logits = V g + d
  robust   positive readout trained with an added certified-margin hinge
"""
import gzip
import hashlib
import json
import os
import time

import numpy as np

F32 = np.float32
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
FILES = {
    "train_images": "train-images-idx3-ubyte.gz",
    "train_labels": "train-labels-idx1-ubyte.gz",
    "test_images": "t10k-images-idx3-ubyte.gz",
    "test_labels": "t10k-labels-idx1-ubyte.gz",
}
MD5 = {
    "train_images": "f68b3c2dcbeaaa9fbdd348bbdeb94873",
    "train_labels": "d53e105ee54ea40749a09fcbcd1e9432",
    "test_images": "9fb629c4189551a2d022fa330f9573f3",
    "test_labels": "ec29112dd5afa0611ce80d1b7f02629c",
}
SPLIT_SEED = 20261004


# ---------------------------------------------------------------------------
# data
# ---------------------------------------------------------------------------
def _digest(path, algo):
    h = hashlib.new(algo)
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def _idx_images(path):
    with gzip.open(path, "rb") as f:
        raw = f.read()
    n, r, c = (int.from_bytes(raw[i:i + 4], "big") for i in (4, 8, 12))
    return np.frombuffer(raw, np.uint8, offset=16).reshape(n, r * c)


def _idx_labels(path):
    with gzip.open(path, "rb") as f:
        raw = f.read()
    return np.frombuffer(raw, np.uint8, offset=8).astype(np.int64)


def load_mnist():
    """55,000 / 5,000 / 10,000 split of MNIST, pixels in [0, 1]."""
    hashes = {}
    for k, fn in FILES.items():
        p = os.path.join(DATA_DIR, fn)
        md5 = _digest(p, "md5")
        if md5 != MD5[k]:
            raise ValueError(f"{fn}: md5 {md5} does not match {MD5[k]}")
        hashes[k] = {"file": fn, "md5": md5, "sha256": _digest(p, "sha256")}
    Xa = _idx_images(os.path.join(DATA_DIR, FILES["train_images"])).astype(F32) / F32(255)
    ya = _idx_labels(os.path.join(DATA_DIR, FILES["train_labels"]))
    Xt = _idx_images(os.path.join(DATA_DIR, FILES["test_images"])).astype(F32) / F32(255)
    yt = _idx_labels(os.path.join(DATA_DIR, FILES["test_labels"]))
    perm = np.random.default_rng(SPLIT_SEED).permutation(60000)
    tr, va = np.sort(perm[:55000]), np.sort(perm[55000:])
    split_hash = hashlib.sha256(tr.astype(np.int64).tobytes() + va.astype(np.int64).tobytes()).hexdigest()
    return {"Xtr": Xa[tr], "ytr": ya[tr], "Xva": Xa[va], "yva": ya[va], "Xte": Xt, "yte": yt,
            "train_idx": tr, "val_idx": va, "hashes": hashes, "split_sha256": split_hash}


# ---------------------------------------------------------------------------
# elementwise helpers
# ---------------------------------------------------------------------------
def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -60, 60)))


def softplus(z):
    return np.logaddexp(0.0, z)


def softmax(L):
    L = L - L.max(1, keepdims=True)
    E = np.exp(L)
    return E / E.sum(1, keepdims=True)


def log_softmax(L):
    L = L - L.max(1, keepdims=True)
    return L - np.log(np.exp(L).sum(1, keepdims=True))


# ---------------------------------------------------------------------------
# models
# ---------------------------------------------------------------------------
class Model:
    """Base: parameters in self.p (dict of arrays); forward caches what backward needs."""
    kind = None
    positive_logits = False

    def features(self, X):
        Z = X @ self.p["F"].T + self.p["b"]
        return Z, sigmoid(Z)

    def first_layer_grads(self, X, dH, H, g):
        dZ = dH * H * (1 - H)
        g["F"] = dZ.T @ X
        g["b"] = dZ.sum(0)


class PosReadout(Model):
    kind = "pos"
    positive_logits = True

    def __init__(self, w, rng, c=8.0, d_in=784, dtype=F32):
        self.c = c
        self.p = {"F": rng.normal(0, 0.1, (w, d_in)).astype(dtype),
                  "b": np.zeros(w, dtype),
                  "Th": (np.log(1.0 / w) + rng.normal(0, 0.1, (10, w))).astype(dtype)}

    def forward(self, X):
        Z, H = self.features(X)
        A = np.exp(self.p["Th"])
        Y = H @ A.T
        self.cache = (X, H, A, Y)
        return self.c * np.log(np.maximum(Y, 1e-30))

    def logy(self, X):
        return self.forward(X) / self.c

    def backward(self, dL, dlogY_extra=None):
        X, H, A, Y = self.cache
        dlogY = self.c * dL
        if dlogY_extra is not None:
            dlogY = dlogY + dlogY_extra
        dY = dlogY / Y
        g = {}
        dA = dY.T @ H
        g["Th"] = dA * A
        dH = dY @ A
        self.first_layer_grads(X, dH, H, g)
        return g


class SignedReadout(Model):
    kind = "signed"

    def __init__(self, w, rng, d_in=784, dtype=F32):
        self.p = {"F": rng.normal(0, 0.1, (w, d_in)).astype(dtype),
                  "b": np.zeros(w, dtype),
                  "V": rng.normal(0, 1.0 / np.sqrt(w), (10, w)).astype(dtype),
                  "d": np.zeros(10, dtype)}

    def forward(self, X):
        Z, H = self.features(X)
        self.cache = (X, H)
        return H @ self.p["V"].T + self.p["d"]

    def backward(self, dL, dlogY_extra=None):
        X, H = self.cache
        g = {"V": dL.T @ H, "d": dL.sum(0)}
        dH = dL @ self.p["V"]
        self.first_layer_grads(X, dH, H, g)
        return g


class PosTail(Model):
    """Positive hidden layer with sum temperature T, then a positive readout."""
    kind = "tail"
    positive_logits = True

    def __init__(self, w, rng, T=1.0, m=256, c=8.0, d_in=784, dtype=F32):
        self.T, self.c, self.m = T, c, m
        self.p = {"F": rng.normal(0, 0.1, (w, d_in)).astype(dtype),
                  "b": np.zeros(w, dtype),
                  "Psi": (T * np.log(1.0 / w) + T * rng.normal(0, 0.1, (m, w))).astype(dtype),
                  "Th": (np.log(1.0 / m) + rng.normal(0, 0.1, (10, m))).astype(dtype)}

    def hidden(self, H, Psi=None):
        Psi = self.p["Psi"] if Psi is None else Psi
        T = self.T
        M = Psi.max(1, keepdims=True)
        P = np.exp((Psi - M) / T)
        G = H ** (1.0 / T)
        S = np.maximum(G @ P.T, 1e-37)
        U = M.T + T * np.log(S)
        return U, P, G, S

    def forward(self, X):
        Z, H = self.features(X)
        U, P, G, S = self.hidden(H)
        Zt = softplus(U)
        A = np.exp(self.p["Th"])
        Y = Zt @ A.T
        self.cache = (X, H, U, P, G, S, Zt, A, Y)
        return self.c * np.log(np.maximum(Y, 1e-30))

    def backward(self, dL, dlogY_extra=None):
        X, H, U, P, G, S, Zt, A, Y = self.cache
        T = self.T
        dlogY = self.c * dL
        if dlogY_extra is not None:
            dlogY = dlogY + dlogY_extra
        dY = dlogY / Y
        g = {}
        g["Th"] = (dY.T @ Zt) * A
        dZt = dY @ A
        dU = dZt * sigmoid(U)
        dS = dU * T / S
        g["Psi"] = (dS.T @ G) * P / T
        dG = dS @ P
        # dG/dH = (1/T) H^(1/T - 1); combined with dH/dZ = H(1-H): (1/T) G (1-H)
        dZ = dG * (1.0 / T) * G * (1 - H)
        g["F"] = dZ.T @ X
        g["b"] = dZ.sum(0)
        return g


class DeepSigned(Model):
    kind = "deep"

    def __init__(self, w, rng, m=256, d_in=784, dtype=F32):
        self.m = m
        self.p = {"F": rng.normal(0, 0.1, (w, d_in)).astype(dtype),
                  "b": np.zeros(w, dtype),
                  "G": rng.normal(0, 1.0 / np.sqrt(w), (m, w)).astype(dtype),
                  "e": np.zeros(m, dtype),
                  "V": rng.normal(0, 1.0 / np.sqrt(m), (10, m)).astype(dtype),
                  "d": np.zeros(10, dtype)}

    def forward(self, X):
        Z, H = self.features(X)
        Gz = sigmoid(H @ self.p["G"].T + self.p["e"])
        self.cache = (X, H, Gz)
        return Gz @ self.p["V"].T + self.p["d"]

    def backward(self, dL, dlogY_extra=None):
        X, H, Gz = self.cache
        g = {"V": dL.T @ Gz, "d": dL.sum(0)}
        dGz = dL @ self.p["V"]
        dA = dGz * Gz * (1 - Gz)
        g["G"] = dA.T @ H
        g["e"] = dA.sum(0)
        dH = dA @ self.p["G"]
        self.first_layer_grads(X, dH, H, g)
        return g


def make_model(family, w, seed, **kw):
    rng = np.random.default_rng(seed)
    if family in ("pos", "robust"):
        return PosReadout(w, rng, c=kw.get("c", 8.0))
    if family == "signed":
        return SignedReadout(w, rng)
    if family.startswith("tail"):
        return PosTail(w, rng, T=kw.get("T", 1.0), m=kw.get("m", 256), c=kw.get("c", 8.0))
    if family == "deep":
        return DeepSigned(w, rng, m=kw.get("m", 256))
    raise ValueError(family)


# ---------------------------------------------------------------------------
# training
# ---------------------------------------------------------------------------
def ce_and_grad(L, y):
    P = softmax(L.astype(np.float64)).astype(L.dtype)
    n = len(y)
    loss = -log_softmax(L.astype(np.float64))[np.arange(n), y].mean()
    dL = P.copy()
    dL[np.arange(n), y] -= 1
    return loss, dL / n


def robust_hinge(logY, y, rho, gamma):
    """[gamma + 2 rho - m_t]_+ with m_t = log y_t - max_{j != t} log y_j; returns mean value and dlogY."""
    n = len(y)
    lt = logY[np.arange(n), y]
    other = logY.copy()
    other[np.arange(n), y] = -np.inf
    jstar = other.argmax(1)
    m_t = lt - other[np.arange(n), jstar]
    active = (gamma + 2 * rho - m_t) > 0
    val = np.where(active, gamma + 2 * rho - m_t, 0.0).mean()
    d = np.zeros_like(logY)
    d[np.arange(n)[active], y[active]] -= 1.0 / n
    d[np.arange(n)[active], jstar[active]] += 1.0 / n
    return val, d


class Adam:
    def __init__(self, params, lr, b1=0.9, b2=0.999, eps=1e-8):
        self.lr, self.b1, self.b2, self.eps = lr, b1, b2, eps
        self.m = {k: np.zeros_like(v) for k, v in params.items()}
        self.v = {k: np.zeros_like(v) for k, v in params.items()}
        self.t = 0

    def step(self, params, grads):
        self.t += 1
        c1 = 1 - self.b1 ** self.t
        c2 = 1 - self.b2 ** self.t
        for k in params:
            g = grads[k].astype(params[k].dtype)
            self.m[k] = self.b1 * self.m[k] + (1 - self.b1) * g
            self.v[k] = self.b2 * self.v[k] + (1 - self.b2) * g * g
            params[k] -= (self.lr * (self.m[k] / c1) / (np.sqrt(self.v[k] / c2) + self.eps)).astype(params[k].dtype)


def train(model, X, y, lr, epochs=20, batch=256, seed=0, hinge=None, log_every=None):
    """Adam on mean cross-entropy (plus an optional certified-margin hinge, weight lam).
    hinge = dict(lam=..., rho=..., gamma=...) applies to positive-logit models."""
    rng = np.random.default_rng(10_000 + seed)
    opt = Adam(model.p, lr)
    n = len(y)
    hist = []
    t0 = time.time()
    for ep in range(epochs):
        perm = rng.permutation(n)
        tot, cnt = 0.0, 0
        for i in range(0, n, batch):
            idx = perm[i:i + batch]
            L = model.forward(X[idx])
            loss, dL = ce_and_grad(L, y[idx])
            extra = None
            if hinge is not None:
                hv, dlogY = robust_hinge((L / model.c).astype(np.float64), y[idx], hinge["rho"], hinge["gamma"])
                loss = loss + hinge["lam"] * hv
                extra = (hinge["lam"] * dlogY).astype(L.dtype)
            g = model.backward(dL, extra)
            opt.step(model.p, g)
            tot += loss * len(idx)
            cnt += len(idx)
        hist.append(tot / cnt)
        if log_every and (ep + 1) % log_every == 0:
            print(f"      epoch {ep + 1:2d}  train loss {tot / cnt:.4f}  ({time.time() - t0:.0f}s)", flush=True)
    return hist


def evaluate_nominal(model, X, y, batch=2000):
    Ls = []
    for i in range(0, len(y), batch):
        Ls.append(model.forward(X[i:i + batch]).astype(np.float64))
    L = np.concatenate(Ls)
    loss = -log_softmax(L)[np.arange(len(y)), y].mean()
    acc = (L.argmax(1) == y).mean()
    return acc, loss


def save_model(model, path, meta):
    np.savez_compressed(path, **{k: v for k, v in model.p.items()}, meta=json.dumps(meta))


def load_params(path):
    z = np.load(path, allow_pickle=False)
    meta = json.loads(str(z["meta"]))
    return {k: z[k] for k in z.files if k != "meta"}, meta
