#!/usr/bin/env python3
"""
p1_latency.py -- latency of the nominal pass and of each certificate, measured on an
idle CPU after all training and evaluation finished (single BLAS thread).

    OPENBLAS_NUM_THREADS=1 python3 p1_latency.py      -> report/latency.json

For seed 11 of every family and width: float32 nominal forward on the 10,000 test
images, and float64 certificate evaluations at rho = 0.01 (readout closed form,
joint-tail exact and marginal, first-layer exact and marginal). Best of 3 repeats.
"""
import json
import os
import time

import numpy as np

import p1_eval as E
import p1lib as L

HERE = os.path.dirname(os.path.abspath(__file__))
FAMS = ["pos", "robust", "signed", "deep", "tail_T1", "tail_T0.25", "tail_T4"]
WIDTHS = (64, 256, 1024, 4096)
RHO = 0.01


def best(fn, reps=3):
    b = np.inf
    for _ in range(reps):
        t0 = time.perf_counter()
        fn()
        b = min(b, time.perf_counter() - t0)
    return b


def main():
    D = L.load_mnist()
    X32, X = D["Xte"], D["Xte"].astype(np.float64)
    n = len(X)
    rows = np.arange(n)
    rv = np.full(n, RHO)
    out = {}
    for fam in FAMS:
        for w in WIDTHS:
            path = os.path.join(HERE, "runs", f"{fam}_w{w}_s11.npz")
            if not os.path.exists(path):
                continue
            p, meta = L.load_params(path)
            base = "tail" if fam.startswith("tail") else fam
            model = L.make_model(base, w, 0, **(meta.get("kw") or {}))
            model.p = {k: v.astype(np.float32) for k, v in p.items()}
            rec = {"us_nominal_f32": 1e6 * best(lambda: model.forward(X32)) / n}
            P = {k: v.astype(np.float64) for k, v in p.items()}
            H = E.sig(X @ P["F"].T + P["b"])
            if base in ("pos", "robust"):
                A = np.exp(P["Th"])
                Y = H @ A.T
                c = Y.argmax(1)
                rec["us_readout_cert"] = 1e6 * best(lambda: np.sort(np.log(Y), 1)) / n
                km = E.PairKM(A)
                Pz, Nz = E.pos_neg(X, P["F"], P["b"])

                def fl(exact):
                    def f(rho, r):
                        sl, su = E.preact_box(Pz[r], Nz[r], rho)
                        hl, hu = E.sig(sl), E.sig(su)
                        return (E.km_tests(km, c[r], hl, hu, 1.0)[0] if exact else
                                E.km_tests_marginal(A, c[r], hl, hu, 1.0))
                    return lambda: E.chunked(f, rv, rows)
                rec["us_fl_exact"] = 1e6 * best(fl(True)) / n
                rec["us_fl_marg"] = 1e6 * best(fl(False)) / n
            elif base == "signed":
                Lg = H @ P["V"].T + P["d"]
                c = Lg.argmax(1)
                rec["us_readout_cert"] = 1e6 * best(lambda: E.signed_readout_radius(H, P["V"], P["d"], c)) / n
            elif base == "tail":
                T = float(meta["kw"]["T"])
                U = E.tail_hidden(H, P["Psi"], T)
                A = np.exp(P["Th"])
                Y = E.softplus(U) @ A.T
                c = Y.argmax(1)
                rec["us_readout_cert"] = 1e6 * best(lambda: np.sort(np.log(Y), 1)) / n
                km = E.PairKM(A)

                def tl(exact):
                    def f(rho, r):
                        zl, zu = E.softplus(U[r] - E.col(rho)), E.softplus(U[r] + E.col(rho))
                        return (E.km_tests(km, c[r], zl, zu, np.exp(-2 * rho))[0] if exact else
                                E.km_tests_marginal(A, c[r], zl, zu, np.exp(-2 * rho)))
                    return lambda: E.chunked(f, rv, rows)
                rec["us_tail_exact"] = 1e6 * best(tl(True)) / n
                rec["us_tail_marg"] = 1e6 * best(tl(False)) / n
            elif base == "deep":
                Gz = E.sig(H @ P["G"].T + P["e"])
                Lg = Gz @ P["V"].T + P["d"]
                c = Lg.argmax(1)
                rec["us_readout_cert"] = 1e6 * best(lambda: E.signed_readout_radius(Gz, P["V"], P["d"], c)) / n
                V, d = P["V"], P["d"]
                Pg, Ng = E.pos_neg(H, P["G"], P["e"])

                def deep_exact(rho, r):
                    gl, gu = E.preact_box(Pg[r], Ng[r], rho)
                    gl, gu = E.sig(gl), E.sig(gu)
                    cc = c[r]
                    vlo = lambda k: V[k] * np.exp(-E.col(rho) * np.sign(V[k]))
                    vhi = lambda k: V[k] * np.exp(E.col(rho) * np.sign(V[k]))
                    dlo = lambda k: d[k] * np.exp(-rho * np.sign(d[k]))
                    dhi = lambda k: d[k] * np.exp(rho * np.sign(d[k]))
                    return E.linear_pair_tests(lambda j: vlo(cc) - vhi(j), cc, gl, gu, lambda j: dlo(cc) - dhi(j))
                rec["us_tail_exact"] = 1e6 * best(lambda: E.chunked(deep_exact, rv, rows)) / n
            out[f"{fam}_w{w}"] = rec
            print(f"{fam:10s} w={w:5d} " + "  ".join(f"{k} {v:.2f}" for k, v in rec.items()), flush=True)
    with open(os.path.join(HERE, "report", "latency.json"), "w") as f:
        json.dump(out, f, indent=1)


def subnormal_check(path=os.path.join(HERE, "runs", "tail_T0.25_w1024_s11.npz"), n=2000):
    """Why the T = 0.25 tail is slow in float32: h^(1/T) = h^4 produces subnormal numbers."""
    D = L.load_mnist()
    p, meta = L.load_params(path)
    H = L.sigmoid(D["Xte"][:n] @ p["F"].T + p["b"]).astype(np.float32)
    G = H ** np.float32(1.0 / meta["kw"]["T"])
    Psi = p["Psi"]
    P = np.exp((Psi - Psi.max(1, keepdims=True)) / meta["kw"]["T"]).astype(np.float32)
    tiny = np.finfo(np.float32).tiny
    nz = G[G != 0]
    G2 = np.where(np.abs(G) < tiny, np.float32(0), G).astype(np.float32)
    t_raw = best(lambda: G @ P.T)
    t_flush = best(lambda: G2 @ P.T)
    out = {"subnormal_fraction_of_nonzero": float(np.mean(np.abs(nz) < tiny)), "t_matmul_s": t_raw,
           "t_matmul_flushed_s": t_flush, "speedup": t_raw / t_flush, "run": os.path.basename(path), "n_images": n}
    with open(os.path.join(HERE, "report", "subnormal.json"), "w") as f:
        json.dump(out, f, indent=1)
    print(out)


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "subnormal":
        subnormal_check()
    else:
        main()
