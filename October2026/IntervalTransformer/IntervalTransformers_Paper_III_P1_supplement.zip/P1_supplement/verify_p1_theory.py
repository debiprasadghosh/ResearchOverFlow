#!/usr/bin/env python3
"""
verify_p1_theory.py -- numerical checks of the propositions of Paper P1.

    python3 verify_p1_theory.py          (numpy + scipy; deterministic; under a minute)

T1  Proposition 1  positivity costs no decisions; common-mode mass dilutes the log margin
T2  Proposition 2  exact readout radius: positive m/2, signed 0.5 log(F/O) = artanh(1/kappa)
T3  Proposition 3  mediant identity, contrast and span bounds, the bits criterion
T4  Proposition 4  the purity bound: the certified radius is intensive in the evidence
T5  Proposition 5  positive tail: exact joint test, the bracket m/4 <= r_marg <= r_exact <= m/2
T6  Proposition 6  first-layer box and deep signed tail: pairwise solves are exact
"""
import itertools
import sys

import numpy as np

import p1_eval as E

rng = np.random.default_rng(20261004)
FAIL = []


def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}{(': ' + detail) if detail else ''}")
    if not ok:
        FAIL.append(name)


def box_direct_pos(A, h, c, rho):
    """Certified iff lower(y_c) > max_j upper(y_j) under a uniform log box on independent rows."""
    y = A @ h
    up = y * np.exp(rho)
    up[c] = -np.inf
    return y[c] * np.exp(-rho) > up.max()


print("T1  positivity costs no decisions (Proposition 1)")
n_in, K = 40, 10
V = rng.normal(0, 1, (K, n_in))
d = rng.normal(0, 1, K)
H = rng.uniform(0, 1, (100000, n_in))
Lg = H @ V.T + d
for mult in (1.0, 2.0, 10.0):
    C, C0 = mult * (1e-3 - V.min()), mult * (1e-3 - d.min())
    A, beta = V + C, d + C0
    assert A.min() > 0 and beta.min() > 0
    Y = H @ A.T + beta
    same = np.mean(Y.argmax(1) == Lg.argmax(1))
    s = np.sort(np.log(Y), 1)
    m = s[:, -1] - s[:, -2]
    sl = np.sort(Lg, 1)
    delta = sl[:, -1] - sl[:, -2]
    jj = np.argsort(Lg, 1)[:, -2]
    ident = np.max(np.abs(m - np.log1p(delta / Y[np.arange(len(Y)), jj])))
    check(f"shift x{mult:g}: argmax preserved on 1e5 inputs", same == 1.0,
          f"agreement {same:.6f}; log margin = log(1 + Delta/y_j) to {ident:.1e}; median log margin {np.median(m):.4f}")

print("T2  exact readout radius (Proposition 2)")
worst = 0.0
for t in range(300):
    n = 30
    A = np.exp(rng.normal(0, 1, (10, n)))
    h = rng.uniform(0, 1, n)
    y = A @ h
    c = y.argmax()
    m = np.log(y[c]) - np.log(np.sort(y)[-2])
    lo, hi = 0.0, 5.0
    for _ in range(60):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if box_direct_pos(A, h, c, mid) else (lo, mid)
    worst = max(worst, abs(lo - m / 2))
check("positive readout: direct box radius equals m/2", worst < 1e-12, f"max |difference| {worst:.1e} over 300 readouts")
worst, worst_k, n_rows = 0.0, 0.0, 0
for t in range(300):
    n = 30
    Vs = rng.normal(0, 1, (10, n))
    ds = rng.normal(0, 1, 10)
    h = rng.uniform(0, 1, (1, n))
    Ls = (h @ Vs.T + ds)[0]
    c = np.array([Ls.argmax()])
    r_cf, jc, kap = E.signed_readout_radius(h, Vs, ds, c)

    def direct(rho):
        lo_ = h[0] @ E.signed_vertex(Vs[c[0]], rho, False) + E.signed_vertex(ds[c[0]:c[0] + 1], rho, False)[0]
        his = [h[0] @ E.signed_vertex(Vs[j], rho, True) + E.signed_vertex(ds[j:j + 1], rho, True)[0]
               for j in range(10) if j != c[0]]
        return lo_ > max(his)
    lo, hi = 0.0, 5.0
    for _ in range(60):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if direct(mid) else (lo, mid)
    worst = max(worst, abs(lo - r_cf[0]))
    worst_k = max(worst_k, abs(r_cf[0] - np.arctanh(1.0 / kap[0])))
check("signed readout: direct box radius equals min_j 0.5 log(F_j/O_j)", worst < 1e-12,
      f"max |difference| {worst:.1e}; artanh(1/kappa) identity to {worst_k:.1e}")
inside_ok, corner_flips, n_cases = True, 0, 0
for t in range(200):
    n = 20
    signed = t % 2 == 1
    if signed:
        Vs, ds = rng.normal(0, 1, (10, n)), rng.normal(0, 1, 10)
    else:
        Vs, ds = np.exp(rng.normal(0, 1, (10, n))), np.zeros(10)
    h = rng.uniform(0, 1, (1, n))
    Ls = (h @ Vs.T + ds)[0]
    c = np.array([Ls.argmax()])
    r_cf, jc, _ = E.signed_readout_radius(h, Vs, ds, c)
    r_star = r_cf[0]
    # random members of the box at 0.98 r*: none may change the winner
    rho = 0.98 * r_star
    for _ in range(300):
        f = np.exp(rng.uniform(-rho, rho, Vs.shape))
        g = np.exp(rng.uniform(-rho, rho, ds.shape))
        inside_ok &= ((h @ (Vs * f).T + ds * g)[0].argmax() == c[0])
    # the minimising corner at 1.02 r* must change it
    rho = 1.02 * r_star
    Vw, dw = Vs.copy(), ds.copy()
    Vw[c[0]] = E.signed_vertex(Vs[c[0]], rho, False)
    dw[c[0]] = E.signed_vertex(ds[c[0]:c[0] + 1], rho, False)[0]
    Vw[jc[0]] = E.signed_vertex(Vs[jc[0]], rho, True)
    dw[jc[0]] = E.signed_vertex(ds[jc[0]:jc[0] + 1], rho, True)[0]
    Lw = (h @ Vw.T + dw)[0]
    corner_flips += int(Lw[jc[0]] >= Lw[c[0]])
    n_cases += 1
check("random members of the box at 0.98 r* never change the winner (300 draws each)", bool(inside_ok),
      f"{n_cases} readouts, positive and signed")
check("the minimising corner at 1.02 r* always changes the winner", corner_flips == n_cases, f"{corner_flips}/{n_cases}")

print("T3  mediant identity, bounds and bits (Proposition 3)")
err, bound_ok, jensen_ok = 0.0, True, True
for t in range(2000):
    n = 50
    Th = rng.normal(0, 1, (10, n))
    h = rng.uniform(0, 1, n)
    y = np.exp(Th) @ h
    o = np.argsort(y)
    c, j = o[-1], o[-2]
    m = np.log(y[c] / y[j])
    pi = np.exp(Th[j]) * h / y[j]
    err = max(err, abs(np.exp(m) - pi @ np.exp(Th[c] - Th[j])) / np.exp(m))
    bound_ok &= m <= (Th[c] - Th[j]).max() + 1e-12 <= (Th.max() - Th.min()) + 1e-12
    jensen_ok &= m >= pi @ (Th[c] - Th[j]) - 1e-12
check("e^m equals the pi-weighted mean of exp contrasts", err < 1e-12, f"max relative error {err:.1e}")
check("m <= max contrast <= span; m >= mean contrast (Jensen)", bool(bound_ok and jensen_ok))
agree = total = 0
need_ok = True
for t in range(400):
    n = 40
    Th = rng.normal(0, 0.7, (10, n))
    h = rng.uniform(0, 1, n)
    nb = int(rng.integers(2, 9))
    lmin, S = Th.min(), Th.max() - Th.min()
    D = S / (2 ** nb - 1)
    q = lmin + np.round((Th - lmin) / D) * D
    yq = np.exp(q) @ h
    oq = np.argsort(yq)
    cq, jq = oq[-1], oq[-2]
    mq = np.log(yq[cq] / yq[jq])
    certified = mq > D
    # the preimage box of the stored model has log radius D/2; its worst corner decides
    yc = np.exp(q[cq] - D / 2) @ h
    yj_max = max(np.exp(q[k] + D / 2) @ h for k in range(10) if k != cq)
    corner_ok = yc > yj_max
    # random members of the preimage box (which contains the original weights)
    members_ok = all((np.exp(q + rng.uniform(-D / 2, D / 2, q.shape)) @ h).argmax() == cq for _ in range(20))
    agree += int(certified == corner_ok)
    total += 1
    if certified:
        need_ok &= members_ok and (np.exp(Th) @ h).argmax() == cq
check("bits: stored margin > step  <=>  worst preimage corner keeps the winner", agree == total, f"{agree}/{total}")
check("bits: certified stored decisions equal the original and every sampled member", bool(need_ok))
suff_ok, n_suff = True, 0
for t in range(2000):
    n = 40
    Th = rng.normal(0, 0.7, (10, n))
    h = rng.uniform(0, 1, n)
    y = np.exp(Th) @ h
    o = np.argsort(y)
    m0 = np.log(y[o[-1]] / y[o[-2]])
    nb = int(rng.integers(2, 12))
    lmin, S = Th.min(), Th.max() - Th.min()
    D = S / (2 ** nb - 1)
    if m0 > 2 * D:
        n_suff += 1
        q = lmin + np.round((Th - lmin) / D) * D
        yq = np.sort(np.log(np.exp(q) @ h))
        suff_ok &= yq[-1] - yq[-2] > D
check("bits: an original margin above 2 steps always yields a certified stored decision", bool(suff_ok),
      f"{n_suff} cases with m > 2 Delta")

print("T4  the purity bound: certified radius is intensive (Proposition 4)")
ok = True
for t in range(2000):
    nb, k = int(rng.integers(2, 20)), int(rng.integers(1, 6))
    A = np.exp(rng.normal(0, 1, (2, nb * k)))
    h = rng.uniform(0, 1, nb * k)
    y = A @ h
    c = int(y.argmax())
    j = 1 - c
    Ag = (A[c] * h).reshape(nb, k).sum(1)
    Bg = (A[j] * h).reshape(nb, k).sum(1)
    r = 0.5 * np.log(y[c] / y[j])
    ok &= r <= 0.5 * np.log(Ag / Bg).max() + 1e-12
check("r* = m/2 <= 0.5 max_g log(A_g/B_g) on 2000 random block readouts", bool(ok))
# iid blocks, block-symmetric readout: radius converges, Bayes log-odds grows
mu, kf = 0.25, 16
tt = np.linspace(-2, 2, kf // 2)
w_up = np.concatenate([np.ones(kf // 2), np.full(kf // 2, 0.05)])   # class +1 reads the increasing units
w_dn = np.concatenate([np.full(kf // 2, 0.05), np.ones(kf // 2)])   # class -1 reads the decreasing units
rows = []
for n in (4, 16, 64, 256, 1024):
    z = rng.normal(mu, 1.0, (4000, n))                       # class +1
    inc = 1 / (1 + np.exp(-(z[:, :, None] - tt)))
    phi = np.concatenate([inc, 1 - inc], 2)                   # (N, n, k)
    Ap = (phi * w_up).sum(2)
    Am = (phi * w_dn).sum(2)
    m_sum = np.log(Ap.sum(1) / Am.sum(1))          # toward class +1; the radius uses the predicted class
    M_prod = np.log(Ap / Am).sum(1)
    rows.append((n, np.median(np.abs(m_sum) / 2), np.median(np.abs(M_prod) / (2 * n)),
                 np.median(np.abs(2 * mu * z.sum(1))), np.mean(m_sum > 0), np.mean(z.sum(1) > 0)))
zinf = rng.normal(mu, 1.0, 400000)
inc = 1 / (1 + np.exp(-(zinf[:, None] - tt)))
phi = np.concatenate([inc, 1 - inc], 1)
lim_sum = 0.5 * np.log((phi * w_up).sum(1).mean() / (phi * w_dn).sum(1).mean())
lim_prod = 0.5 * np.mean(np.log((phi * w_up).sum(1) / (phi * w_dn).sum(1)))
print("     n   median r* (sum)  median r* (product)  median |Bayes log-odds|  acc (sum)  acc (Bayes)")
for n, rs, rp, lo_, a1, a2 in rows:
    print(f"  {n:5d}   {rs:13.4f}   {rp:18.4f}   {lo_:20.2f}   {a1:8.4f}   {a2:9.4f}")
print(f"  limits: 0.5 log(E A / E B) = {lim_sum:.4f};  0.5 E log(A/B) = {lim_prod:.4f}")
check("fixed sum readout: median radius approaches 0.5 log(EA/EB) while the Bayes log-odds grows",
      abs(rows[-1][1] - lim_sum) < 0.01 and rows[-1][1] <= rows[0][1] and rows[-1][3] / rows[0][3] > 100,
      f"median radius n=4: {rows[0][1]:.4f}, n=1024: {rows[-1][1]:.4f}; log-odds ratio: {rows[-1][3] / rows[0][3]:.1f}")
check("product readout: radius M/(2n) approaches 0.5 E log(A/B)", abs(rows[-1][2] - lim_prod) < 0.01)
# incoherent perturbations: std of the margin change scales with 1/sqrt(n_eff)
rho = 0.05
res = []
for n in (16, 256, 4096):
    A = np.exp(rng.normal(0, 0.3, (2, n)))
    h = rng.uniform(0.2, 1, n)
    y = A @ h
    c = int(y.argmax())
    j = 1 - c
    pc, pj = A[c] * h / y[c], A[j] * h / y[j]
    pred = np.sqrt(rho ** 2 / 3 * (np.sum(pc ** 2) + np.sum(pj ** 2)))
    eps = rng.uniform(-rho, rho, (4000, 2, n))
    ym = np.einsum("dkn,n->dk", A[None] * np.exp(eps), h)
    dm = np.log(ym[:, c] / ym[:, j]) - np.log(y[c] / y[j])
    res.append((n, 1 / np.sum(pc ** 2), dm.std(), pred))
print("     n   n_eff     sd(margin change)   first-order prediction   worst case 2 rho")
for n, ne, sd, pr in res:
    print(f"  {n:5d}  {ne:7.1f}   {sd:16.6f}   {pr:22.6f}   {2 * rho:13.3f}")
check("random log-weight noise: margin sd matches rho sqrt((sum p_c^2 + sum p_j^2)/3)",
      all(abs(sd / pr - 1) < 0.05 for _, _, sd, pr in res))

print("T5  positive tail (Proposition 5)")
agree = tot = 0
bracket_ok = True
for t in range(300):
    m_h, w = 8, 6
    T = float(rng.choice([0.25, 1.0, 4.0]))
    H = rng.uniform(0.05, 0.95, (1, w))
    Psi = rng.normal(0, 1, (m_h, w))
    Th = rng.normal(0, 0.3, (10, m_h))
    U = E.tail_hidden(H, Psi, T)
    A = np.exp(Th)
    Y = E.softplus(U) @ A.T
    c = Y.argmax(1)
    rho = float(rng.choice([0.01, 0.05, 0.1, 0.2]))
    km = E.PairKM(A)
    ex, mg, _ = E.km_tests(km, c, E.softplus(U - rho), E.softplus(U + rho), np.exp(-2 * rho))
    flip = False
    for bits in itertools.product([0, 1], repeat=m_h):
        sh = np.where(np.array(bits, bool), rho, -rho)
        z = E.softplus(E.tail_hidden(H, Psi + sh[:, None], T))[0]
        yc = np.exp(Th[c[0]] - rho) @ z
        flip |= any(np.exp(Th[j] + rho) @ z >= yc for j in E.COMP[c[0]])
    tot += 1
    agree += int(ex[0] == (not flip))
    bracket_ok &= not (mg[0] and not ex[0])
check("exact pairwise threshold test equals enumeration of hidden vertices (T in {0.25, 1, 4})",
      agree == tot, f"{agree}/{tot}")
check("the marginal test never certifies what the exact test rejects", bool(bracket_ok))
lin_agree = lin_tot = 0
for t in range(3000):
    m_h = int(rng.integers(2, 40))
    A = np.exp(rng.normal(0, 1, (10, m_h)))
    zl = np.exp(rng.normal(0, 1, (1, m_h)))
    zu = zl * np.exp(rng.uniform(0, 1.5, (1, m_h)))
    c = np.array([int(rng.integers(10))])
    rho = float(rng.choice([0.0, 0.01, 0.05, 0.2]))
    ex = E.km_tests(E.PairKM(A), c, zl, zu, np.exp(-2 * rho))[0][0]
    lin = True
    for j in E.COMP[c[0]]:
        D = np.exp(-rho) * A[c[0]] - np.exp(rho) * A[j]
        lin &= float(np.where(D > 0, D * zl[0], D * zu[0]).sum()) > 0
    lin_tot += 1
    lin_agree += int(ex == lin)
check("the threshold solve equals a coordinatewise linear test at the known threshold e^(2 rho)",
      lin_agree == lin_tot, f"{lin_agree}/{lin_tot}")
A = np.exp(rng.normal(0, 0.5, (10, 64)))
U = rng.normal(0, 1.5, (400, 64))
Y = E.softplus(U) @ A.T
c = Y.argmax(1)
s = np.sort(np.log(Y), 1)
m = s[:, -1] - s[:, -2]
km = E.PairKM(A)
t_ex = lambda r, q: E.km_tests(km, c[q], E.softplus(U[q] - E.col(r)), E.softplus(U[q] + E.col(r)), np.exp(-2 * r))[0]
t_mg = lambda r, q: E.km_tests_marginal(A, c[q], E.softplus(U[q] - E.col(r)), E.softplus(U[q] + E.col(r)), np.exp(-2 * r))
r_ex, _ = E.bisect(t_ex, np.full(400, 1e-9), np.full(400, 5.0), 40)
r_mg, _ = E.bisect(t_mg, np.full(400, 1e-9), np.full(400, 5.0), 40)
tol = 1e-6
check("m/4 <= r_marg <= r_exact <= m/2 on 400 random tails (free bisection)",
      bool(np.all(m / 4 <= r_mg * (1 + tol)) and np.all(r_mg <= r_ex * (1 + tol)) and np.all(r_ex <= m / 2 * (1 + tol))),
      f"median r_exact/(m/2) = {np.median(r_ex / (m / 2)):.3f}, median r_marg/r_exact = {np.median(r_mg / r_ex):.3f}")
# the shared-state counterexample of Paper II: h in [1, 3], y1 = 2h, y2 = h
km1 = E.PairKM(np.array([[2.0]] + [[1.0]] * 9))
ex, mg, _ = E.km_tests(km1, np.array([0]), np.array([[1.0]]), np.array([[3.0]]), 1.0)
check("Paper II counterexample: marginal ranges overlap, exact test certifies", bool(ex[0] and not mg[0]))
el = []
for u in np.linspace(-30, 30, 20001):
    el.append(E.sig(u) / E.softplus(u))
check("softplus log-elasticity sigma(u)/softplus(u) lies in (0, 1]", 0 < min(el) and max(el) <= 1.0 + 1e-12,
      f"max {max(el):.6f}")

print("T6  first-layer box and deep signed tail (Proposition 6)")
agree = tot = 0
for t in range(200):
    w = 8
    x = rng.uniform(0, 1, (1, 6))
    F = rng.normal(0, 1, (w, 6))
    b = rng.normal(0, 0.5, w)
    A = np.exp(rng.normal(0, 0.5, (10, w)))
    h = E.sig(x @ F.T + b)
    c = (h @ A.T).argmax(1)
    rho = float(rng.choice([0.01, 0.05, 0.2, 0.5]))
    P, N = E.pos_neg(x, F, b)
    sl, su = E.preact_box(P, N, np.array([rho]))
    ex, _, _ = E.km_tests(E.PairKM(A), c, E.sig(sl), E.sig(su), 1.0)
    flip = False
    for bits in itertools.product([0, 1], repeat=w):
        up = np.array(bits, bool)
        Fw = np.where(up[:, None], E.signed_vertex(F, rho, True), E.signed_vertex(F, rho, False))
        bw = np.where(up, E.signed_vertex(b, rho, True), E.signed_vertex(b, rho, False))
        yy = E.sig(x @ Fw.T + bw) @ A.T
        flip |= (yy[0] >= yy[0, c[0]]).sum() > 1
    tot += 1
    agree += int(ex[0] == (not flip))
check("first-layer box with a positive readout: threshold test equals enumeration", agree == tot, f"{agree}/{tot}")
agree = tot = 0
for t in range(200):
    m_h, w = 7, 5
    H = rng.uniform(0.05, 0.95, (1, w))
    G = rng.normal(0, 1, (m_h, w))
    e = rng.normal(0, 0.5, m_h)
    V = rng.normal(0, 1, (10, m_h))
    d = rng.normal(0, 0.3, 10)
    g = E.sig(H @ G.T + e)
    c = (g @ V.T + d).argmax(1)
    rho = float(rng.choice([0.01, 0.05, 0.2]))
    Pg, Ng = E.pos_neg(H, G, e)
    gl, gu = E.preact_box(Pg, Ng, np.array([rho]))
    gl, gu = E.sig(gl), E.sig(gu)
    vlo = lambda k: V[k] * np.exp(-rho * np.sign(V[k]))
    vhi = lambda k: V[k] * np.exp(rho * np.sign(V[k]))
    dlo = lambda k: d[k] * np.exp(-rho * np.sign(d[k]))
    dhi = lambda k: d[k] * np.exp(rho * np.sign(d[k]))
    ex = E.linear_pair_tests(lambda j: vlo(c) - vhi(j), c, gl, gu, lambda j: dlo(c) - dhi(j))
    flip = False
    for bits in itertools.product([0, 1], repeat=m_h):
        up = np.array(bits, bool)
        Gw = np.where(up[:, None], E.signed_vertex(G, rho, True), E.signed_vertex(G, rho, False))
        ew = np.where(up, E.signed_vertex(e, rho, True), E.signed_vertex(e, rho, False))
        gg = E.sig(H @ Gw.T + ew)[0]
        for j in E.COMP[c[0]]:
            if E.signed_vertex(V[j], rho, True) @ gg + dhi(j) >= E.signed_vertex(V[c[0]], rho, False) @ gg + dlo(c[0]):
                flip = True
    tot += 1
    agree += int(ex[0] == (not flip))
check("deep signed tail (G, e, V, d): pairwise linear test equals enumeration", agree == tot, f"{agree}/{tot}")

print()
print("all checks passed" if not FAIL else f"FAILED: {FAIL}")
sys.exit(1 if FAIL else 0)
