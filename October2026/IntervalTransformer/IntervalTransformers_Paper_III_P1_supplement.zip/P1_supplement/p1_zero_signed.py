#!/usr/bin/env python3
"""
p1_zero_signed.py -- exploratory MNIST control: the signed readout family trained with its
readout weights started at zero (everything else as registered), at widths 256 and 4096.

    python3 p1_zero_signed.py        -> runs/signed0_w{w}_s{seed}.npz (family "signed", tag "signed0")

Evaluate with the frozen evaluator:  python3 p1_eval.py test signed0_
"""
import json
import os
import time

import p1lib as L
from p1_run import BATCH, CONFIG, EPOCHS, RUNS, SEEDS


def main():
    with open(CONFIG) as f:
        cfg = json.load(f)
    D = L.load_mnist()
    for w in (256, 4096):
        for seed in SEEDS:
            path = os.path.join(RUNS, f"signed0_w{w}_s{seed}.npz")
            if os.path.exists(path):
                continue
            model = L.make_model("signed", w, seed)
            model.p["V"][:] = 0.0
            t0 = time.time()
            hist = L.train(model, D["Xtr"], D["ytr"], cfg["lr"]["signed"], epochs=EPOCHS, batch=BATCH, seed=seed)
            va_acc, va_loss = L.evaluate_nominal(model, D["Xva"], D["yva"])
            meta = {"tag": "signed0", "family": "signed", "width": w, "seed": seed, "lr": cfg["lr"]["signed"],
                    "kw": {}, "hinge": None, "epochs": EPOCHS, "batch": BATCH, "train_loss": hist,
                    "val_acc": float(va_acc), "val_loss": float(va_loss), "train_seconds": time.time() - t0,
                    "note": "exploratory: readout weights V started at zero"}
            L.save_model(model, path, meta)
            print(f"  signed0 w={w:5d} seed={seed:3d}: val acc {va_acc:.4f} loss {va_loss:.4f}", flush=True)


if __name__ == "__main__":
    main()
