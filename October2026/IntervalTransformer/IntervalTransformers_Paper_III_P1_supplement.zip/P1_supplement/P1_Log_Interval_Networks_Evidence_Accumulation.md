# Log Interval Networks for Evidence Accumulation and Certified Decisions

**Debi Prasad Ghosh**

Debias Parametric Guru, Kolkata, India | debiprasadghosh@gmail.com

4 October 2026 · P1 of the log interval network programme · Pre-specified protocol executed, with reproducible scripts

---

**Abstract.** Paper II asked whether a trained positive log interval network keeps accuracy, evidence accumulation and certified margins as its width grows. We ran the P1 protocol that it specified for registration on MNIST, with seven model families, widths 64 to 4096 and five seeds, and on a task with sixteen conditionally independent evidence blocks. Every parameter box studied has an exact decision test: a coordinatewise linear minimisation for each competitor. Every checked rejection was confirmed by running its witness through the network.

Positivity costs no decisions, only margin. A common shift makes any signed readout positive with the same argmax, but its common-mode mass dilutes the log margin. Under a uniform log box, the exact readout radius is half the log ratio of favouring to opposing mass, which for a positive readout is half the log margin. A sum readout's margin is the logarithm of a weighted mean of block ratios, so a fixed readout cannot certify more as independent evidence accumulates. Random weight noise, by contrast, is averaged down as fan-in grows.

On MNIST the positive readout reached 96.1–97.6% accuracy, 0.4–1.2 points below the signed control. Its certified accuracy at log radius 0.01 rose from 96.8% at width 256 to 97.5% at width 4096. It kept its margins by selection: the feature layer was nearly silent, and each decision rested on a few features (local fan-in 1.3–4.8). Positive tails had joint certified radii four to six times those of a deep signed MLP of equal size, but were 1.0–3.1 points less accurate. In an exploratory ablation, the training logit scale traded large-radius certificates for accumulation and accuracy.

On the evidence task the positive readout came within 0.16 points of the Bayes rule and beat the four-block oracle by 4.7 points (p ≤ 4.4 × 10⁻⁶⁹ for every seed and width). Its decisions drew on the blocks as broadly as the Bayes rule's did, its log margins were calibrated to the log-odds, and it certified 82.2% at every width. All acceptance criteria specified in Paper II were met, and its rejection criterion was not triggered.

**Keywords** logarithmic neural networks; interval certification; weight perturbation; evidence accumulation; positive networks; exact verification

# 1 Question and summary

Paper II [2] proposed *log interval networks*, building on the Interval Transformer [1] and on earlier positive, logarithmic and Kronecker designs [3–6]. Positive quantities carry intervals in log coordinates, and positive monotone computations have exact ranges at two parameter corners. A decision is released only when its ordering survives every model in a declared parameter box. Paper II's reproduced random-layer check, L1, exposed the obstacle. Dense positive sums of comparable terms lose their log margins as width grows, and certification fell from 90.1% at width 16 to 0.0% at width 4096. Wide input log ranges kept certification, but only by concentrating each output on a few terms. Paper II therefore made P1 the first full paper of the programme, with one question:

> Does a trained positive log interval network keep evidence accumulation, accuracy and certified margins as its width grows?

We answer it under the protocol Paper II proposed for registration, with three kinds of evidence kept apart:

- **Theory (Section 3).** Six propositions with proofs, each checked numerically.
- **MNIST (Section 5).** Seven model families, widths 64 to 4096, five seeds each, and exact certificates for three parameter boxes.
- **The evidence task (Section 6).** Sixteen conditionally independent evidence blocks, compared against the Bayes rule and a four-block oracle.

**Related work.**

- **Weight perturbations.** Certification against weight perturbations has been studied for general networks through bounds and relaxations [9, 10], and interval bound propagation certifies input perturbations [17].
- **Positivity and monotonicity.** Boxes in weight space have been used to prevent forgetting [16]. Monotone networks rely on positive weights [20].
- **Logarithmic arithmetic.** Logarithmic representations have been used for efficient inference and training [18, 19].

P1 differs in three ways:

- It uses tests that are exact, necessary and sufficient, for log-parameterised positive networks and their signed controls.
- It confirms each rejection with an executed witness.
- It asks how certified margins scale with width and with independent evidence.

**Main results.**

1. **Exact tests and their limits (Section 3).**
   - Every box studied has an exact decision test with a witness. This covers the readout, a positive hidden layer at any sum temperature, the signed first layer at a point input, and a deep signed tail.
   - Positivity costs no decisions, only margin.
   - For a fixed readout, the uniform log box cannot reward additional independent evidence. Fan-in protects only against incoherent noise.
2. **The registered width question (Sections 5 and 7).** On MNIST the positive readout's certified accuracy at $\rho=0.01$ rose by 0.76 points from width 256 to 4096, and its accuracy stayed within 1.2 points of the signed control. All three acceptance criteria were met.
3. **The mechanism (Section 5).** On MNIST the positive readout selected rather than accumulated. Its feature layer became nearly silent, and its log margins grew with width. In an exploratory ablation, the training logit scale traded large-radius certificates for accumulation and accuracy.
4. **Accumulation (Section 6).** On the evidence task the positive readout accumulated across independent blocks. It matched the Bayes rule, and its certificates changed little with width. Paper II's mass-based fan-in counts common-mode mass as participation. A decision-based fan-in, added after testing, separates single-block from many-block decisions, though only grouping by source reveals duplicated blocks.

# 2 Models, boxes and outcomes

## 2.1 Models

Every MNIST model starts with the same signed sigmoid feature layer, $h=\sigma(Fx+b)\in(0,1)^w$, on pixels $x\in[0,1]^{784}$. Table 1 lists what follows it. The positive readout is Paper II's primary model, and the positive tail is its secondary model; the signed readout and the deep signed MLP are its controls.

**Table 1.** Model families. $w$ is the width; the two-layer tails have $n_z=256$ hidden units.

| Family | Computation after $h$ | Parameters | Boxes certified |
|---|---|---:|---|
| Positive readout (primary) | $y=e^{\Theta}h$; training logits $8\log y$ | $795w$ | readout $\Theta$; first layer $(F,b)$ |
| Positive readout, robust margin | as above; the loss adds $\lambda[\gamma+2\rho_0-m_t]_+$ | $795w$ | readout $\Theta$; first layer $(F,b)$ |
| Signed readout (primary control) | $L=Vh+d$ | $795w+10$ | readout $(V,d)$; first layer $(F,b)$ |
| Positive tail, $T\in\lbrace 1,0.25,4\rbrace$ | Equation (4); $y=e^{\Theta}z$; training logits $8\log y$ | $1041w+2560$ | readout $\Theta$; joint tail $(\Psi,\Theta)$ |
| Deep signed MLP (control) | $q=\sigma(Gh+e)$; $L=Vq+d$ | $1041w+2826$ | readout $(V,d)$; joint tail $(G,e,V,d)$ |

In the robust arm, $m_t$ is the nominal log margin of the true class and $\rho_0=0.01$. Under the readout box of radius $\rho_0$, every log output moves by exactly $\pm\rho_0$, so the hinge equals Paper II's $[\gamma-\log\underline y_t+\max_{j\ne t}\log\overline y_j]_+$. Within each pair (positive and signed readouts; positive tails and deep MLP), parameter counts differ by only 10 or 266 at every width.

## 2.2 Boxes

A box of log radius $\rho$ gives every parameter of the named set the same radius. Positive weights are stored as logs, and each log moves by at most $\rho$. Signed weights and biases get sign-preserving multiplicative boxes $v\,e^{[-\rho,\rho]}$. A bias counts as a weight on a constant input equal to 1. Under the declared zero rule, an exactly zero parameter stays zero; no trained model had one. Paper II registered radii 0, 0.0025, 0.005, 0.01 and 0.02, with 0.01 primary; we add 0.05, 0.1 and 0.2 as exploratory radii.

Three boxes are reported separately, as Paper II requires:

- **Readout box.** The features are held fixed and the readout varies.
- **Joint tail box.** The hidden layer and the readout vary together, with the first-layer features fixed.
- **First-layer box.** $(F,b)$ varies at the point input, with the readout fixed.

A multiplicative radius and an additive one are not equivalent [2]. For a sensitivity analysis, every readout weight also gets an additive interval $\pm\varepsilon s$, where $s$ is the root-mean-square readout weight; positive weights are clipped at zero.

## 2.3 Outcomes and semantic tags

A decision is released at radius $\rho$ when the test certifies it. *Certified accuracy* is the fraction of test examples that are released and correct. *Coverage* is the fraction released, and *accuracy on released cases* is their ratio. A confidently preserved wrong answer counts against certified accuracy, as in Paper II.

Every number carries one of four tags:

- **Exact coordinate range.** The endpoints of a positive output, attained at two corners.
- **Exact decision test.** A test that is necessary and sufficient for the winner to survive the box: the closed forms and pairwise solves of Section 3.
- **Sound enclosure.** The marginal endpoint test, and Moore intervals [11] for the deep control.
- **Nominal estimate.** Fan-in, random perturbations, truncations and latency.

A decision rejected by an exact test is a *witnessed flip*: we build the minimising parameter vertex and run it through the network. A decision rejected by the marginal test but certified by the exact test is an *inconclusive certificate*.

All certificates are computed in float64 from the stored float32 parameters, without outward rounding. As Paper II stresses, they are arithmetic checks of the stated real-number tests, not machine-verified interval enclosures.

# 3 Exact certificates and what they can certify

Throughout, the input is a point and the features are positive: $h=\sigma(Fx+b)\in(0,1)^w$ for the first layer and $z>0$ for the positive hidden layer. A positive readout row $k$ gives $y_k=\sum_ia_{ki}h_i$, with $a_{ki}=e^{\theta_{ki}}$. For the nominal winner $c$ and a competitor $j$, the log margin is $m_j=\log y_c-\log y_j$, and $m=\min_{j\ne c}m_j$. A box of log radius $\rho$ on a parameter set lets every positive weight move to $a\,e^{\delta}$, and every signed weight or bias $v$ to $v\,e^{\delta}$, with $|\delta|\le\rho$ chosen independently for each parameter. A bias is a weight on a constant input equal to 1. The certified radius $r^{\ast}$ is the supremum of the radii at which every model in the box has winner $c$.

**Proposition 1 (positivity costs no decisions; common-mode mass costs margin).** Let $L(h)=Vh+d$ be a signed readout on $h\ge0$. Add the same vector $u$, with $u_i>-\min_kV_{ki}$, to every row of $V$, and the same constant $C_0>-\min_kd_k$ to every bias. The positive readout $y(h)=(V+\mathbf 1u^{\top})h+(d+C_0\mathbf 1)$ then has $\arg\max_ky_k(h)=\arg\max_kL_k(h)$ for every $h\ge0$, and

$$
m_j=\log\Bigl(1+\frac{L_c-L_j}{y_j}\Bigr),\qquad y_j=L_j+u^{\top}h+C_0. \tag{1}
$$

*Proof.* Every $y_k$ equals $L_k+u^{\top}h+C_0$, and the added term is the same for every class. Dividing $y_c$ by $y_j$ gives (1). ∎

A positive readout with a positive bias can therefore realise every decision rule of a signed readout on the same features. Any such shift adds the same common-mode mass $u^{\top}h+C_0$ to every output, and (1) falls as that mass grows. The least common-mode mass that keeps every weight positive is set by each feature's most negative weight. The MNIST positive readout has no bias. In the evidence task, each block's increasing and decreasing units sum to a constant, which supplies one.

**Proposition 2 (exact readout radius).** Fix features $\phi\ge0$ and let the readout weights and biases vary in a sign-preserving box of log radius $\rho$. Split each output as $L_k=P_k-N_k$, its positive and negative contributions. For a competitor $j$, let $\mathcal F_j=P_c+N_j$ be the mass favouring $c$, $\mathcal O_j=N_c+P_j$ the mass opposing it, and $\kappa_j=(\mathcal F_j+\mathcal O_j)/(\mathcal F_j-\mathcal O_j)$. Then $c$ is certified if and only if

$$
\rho<r^{\ast}=\min_{j\ne c}\tfrac12\log\frac{\mathcal F_j}{\mathcal O_j}=\min_{j\ne c}\operatorname{artanh}\frac{1}{\kappa_j}. \tag{2}
$$

For a positive readout $N=0$, so $r^{\ast}=m/2$.

*Proof.* Over the box, $L_c-L_j$ is smallest when every favouring term is multiplied by $e^{-\rho}$ and every opposing term by $e^{\rho}$. These choices concern different rows, or different signs within a row, so they are compatible, and the minimising parameters lie in the box. The minimum $\mathcal F_je^{-\rho}-\mathcal O_je^{\rho}$ is positive exactly when $\rho<\tfrac12\log(\mathcal F_j/\mathcal O_j)$, and $c$ is certified exactly when this holds for every $j$. Finally, $\tfrac12\log(\mathcal F_j/\mathcal O_j)=\tfrac12\log\bigl((\kappa_j+1)/(\kappa_j-1)\bigr)=\operatorname{artanh}(1/\kappa_j)$. ∎

Equation (2) names two ways a certificate is lost. A signed readout loses it through cancellation: for large $\kappa$, $r^{\ast}\approx1/\kappa$, with $\kappa$ the amplification factor of Paper II's Equation 8. A positive readout loses it through common-mode mass (Proposition 1). Opposing mass need not affect the decision. Weight components that leave every decision unchanged still count in $\mathcal O_j$, so two readouts that make identical decisions can have different radii. In every case the test is exact: the worst corner lies in the box, so every rejection is a witnessed flip (a tie exactly at the radius counts as one).

**Proposition 3 (mediant identity and the bits a decision needs).** For a positive readout,

$$
e^{m_j}=\sum_i\pi_i\,e^{\theta_{ci}-\theta_{ji}},\qquad \pi_i=\frac{a_{ji}h_i}{y_j}. \tag{3}
$$

Hence $\sum_i\pi_i(\theta_{ci}-\theta_{ji})\le m_j\le\max_i(\theta_{ci}-\theta_{ji})\le S$, where $S$ is the span of the readout's log weights, and $r^{\ast}\le S/2$. Store the log weights on a uniform grid of step $\Delta=S/(2^b-1)$ that covers their span. Every model whose log weights round to the stored ones lies in the box of log radius $\Delta/2$ around them, and so does the original model. The stored decision is certified over that box if and only if the stored log margin exceeds $\Delta$. A sufficient condition on the original model is $m>2\Delta$, that is, $b>\log_2(1+2S/m)$.

*Proof.* Equation (3) follows by dividing $y_c=\sum_ia_{ci}h_i$ by $y_j$. A weighted mean of $e^{x_i}$ lies between its extremes, and Jensen's inequality gives the lower bound. The grid contains both ends of the span, so rounding moves every log weight by at most $\Delta/2$ without clipping. By Proposition 2, the stored winner is certified on that box exactly when the stored margin exceeds $\Delta$. Rounding moves each log output by at most $\Delta/2$, so the stored margin is at least $m-\Delta$, which exceeds $\Delta$ when $m>2\Delta$. ∎

**Proposition 4 (more evidence, the same kind of radius).** Partition the readout inputs into blocks $g=1,\dots,n$, and for a competitor $j$ let $A_g=\sum_{i\in g}a_{ci}h_i$ and $B_g=\sum_{i\in g}a_{ji}h_i$.

- **(a)** $r^{\ast}_j=\tfrac12\log\bigl(\sum_gA_g/\sum_gB_g\bigr)\le\tfrac12\max_g\log(A_g/B_g)\le S/2$. The ratio $e^{m_j}$ of a sum readout is a weighted mean of the block ratios $A_g/B_g$. No number of agreeing blocks lifts the margin above the most favourable block's log ratio, or above the span $S$ of the log weights, and the radius stays below half of either.
- **(b)** Take a fixed readout that uses the same weights in every block, and blocks that are i.i.d. given the class, with $\mathbb EA>\mathbb EB>0$. Then $r^{\ast}_j\to\tfrac12\log(\mathbb EA/\mathbb EB)$ almost surely as $n\to\infty$. In the evidence task, the Bayes log-likelihood ratio $2\mu\sum_gz_g$ instead has mean $2n\mu^2$ in the direction of the true class, which grows without bound.
- **(c)** A product readout, $\log y_k=\sum_g\log\sum_{i\in g}a_{ki}h_i$, has log margin $M_j=\sum_g\log(A_g/B_g)$, which grows with $n$. Its radius is nevertheless $M_j/(2n)$, which under (b), with $\mathbb E\lvert\log(A/B)\rvert<\infty$, tends to $\tfrac12\mathbb E\log(A/B)$.
- **(d)** Suppose instead that every log weight is perturbed by $\sigma\xi$, with the $\xi$ i.i.d., bounded, of mean zero and unit variance. Then the change in $m_j$ has standard deviation $\sigma\bigl(\sum_ip_{ci}^2+\sum_ip_{ji}^2\bigr)^{1/2}+O(\sigma^2)$, where $p_{ki}=a_{ki}h_i/y_k$. This equals $\sigma(1/n_c+1/n_j)^{1/2}$ in terms of the fan-in $n_k=1/\sum_ip_{ki}^2$ of Paper II's Equation 6.

*Proof.* (a) $\sum_gA_g/\sum_gB_g$ is the mean of the ratios $A_g/B_g$ with weights $B_g/\sum_gB_g$ (the mediant inequality), and Proposition 3 bounds each block ratio by the span. (b) Divide the numerator and the denominator by $n$ and apply the strong law of large numbers. (c) Under the box, each block term $\log\sum_{i\in g}a_{ki}h_i$ moves by at most $\rho$, and it moves by exactly $\rho$ when its whole block row moves together. The margin $M_j$ therefore falls by at most $2n\rho$, with equality when row $c$ is lowered and row $j$ raised. (d) $\delta\log y_k=\sigma\sum_ip_{ki}\xi_{ki}+O(\sigma^2)$, and rows $c$ and $j$ use different weights. ∎

The uniform log box measures worst-case multiplicative variation, not typical variation (Paper II, Section 2.1). For a fixed readout it is blind to the number of independent sources: by (a)–(c), adding blocks cannot raise the radius beyond what single blocks and the weight span allow. A trained readout can follow growing evidence only by widening the spread of its log weights. Cross-entropy pushes it to do so, because training fits the logits $c\log y$ to the log-odds; Section 6 measures how far this goes. Robustness to incoherent noise, (d), comes from fan-in, whether or not the fan-in reflects independent sources.

**Proposition 5 (positive tail: exact joint certificate).** Let

$$
u_k=T\log\sum_j\exp\Bigl(\frac{\psi_{kj}+\log h_j}{T}\Bigr),\qquad z_k=\operatorname{softplus}(u_k),\qquad y=e^{\Theta}z, \tag{4}
$$

for $k=1,\dots,n_z$, with $h$ fixed and a log box of radius $\rho$ on $(\Psi,\Theta)$. At $T=1$, $z_k=\log\bigl(1+\sum_je^{\psi_{kj}}h_j\bigr)$, which is Paper II's positive hidden layer, and $T$ is the sum temperature of its Equation 7.

- **(a)** For every $T>0$, the attainable hidden vectors form exactly the box $Z=\prod_k\bigl[\operatorname{softplus}(u_k-\rho),\operatorname{softplus}(u_k+\rho)\bigr]$.
- **(b)** $c$ is certified if and only if, for every $j$, $\min_{z\in Z}\,(e^{-\rho}a_c-e^{\rho}a_j)\cdot z>0$. This is a linear minimisation over a box, solved coordinate by coordinate: take $z_k$ at its lower end where $a_{ck}\ge e^{2\rho}a_{jk}$, and at its upper end otherwise. The cost is $O(n_z)$ per competitor. The coordinates at their upper ends form a prefix of the order of $a_{ck}/a_{jk}$, the switch-point structure of Karnik and Mendel [12], cut at the known threshold $e^{2\rho}$.
- **(c)** The marginal test $\underline y_c>\max_{j\ne c}\overline y_j$ (Paper II, Equation 5) is sound but not necessary.
- **(d)** Let $r_{\text{marg}}$ and $r_{\text{exact}}$ be the radii of the two tests. Then $m/4\le r_{\text{marg}}\le r_{\text{exact}}\le m/2$.

*Proof.* (a) $u_k$ is nondecreasing in every $\psi_{kj}$, and shifting the whole row by $\delta$ shifts $u_k$ by exactly $\delta$, for any $T$. So $u_k$ ranges over $[u_k-\rho,u_k+\rho]$ and, by continuity, attains every value in it. Rows have disjoint parameters, so the ranges combine as a product, and softplus is increasing. (b) For fixed $z\ge0$, $y_c-y_j$ is smallest when row $c$ of $\Theta$ is lowered and row $j$ raised, which gives the linear form. The coordinatewise rule follows from the sign of each coefficient. A coordinate sits at its upper end exactly when $a_{ck}/a_{jk}<e^{2\rho}$, which is a prefix of the ratio order [12, 13]. (c) Equation 5 bounds $y_c$ and $y_j$ at separate worst cases, which may use different hidden vectors. Paper II's example, $h\in[1,3]$ with $y_1=2h$ and $y_2=h$, passes the exact test and fails the marginal one. (d) The upper bound is the corner of the conditional readout box. For the lower bound, softplus has log-elasticity $\mathrm d\log\operatorname{softplus}(u)/\mathrm du=\sigma(u)/\operatorname{softplus}(u)\in(0,1)$, so every $z_k$ stays within a factor $e^{\pm\rho}$. With $\Theta$, each output therefore moves by at most $2\rho$ in log, and both tests certify when $4\rho<m$. ∎

**Proposition 6 (first layer at a point input, and the deep signed tail).**

- **(a)** Let $h=\sigma(Fx+b)$ with $x\ge0$ and a sign-preserving box on $(F,b)$. Unit $i$'s pre-activation ranges exactly over $[P_ie^{-\rho}-N_ie^{\rho},\ P_ie^{\rho}-N_ie^{-\rho}]$, where $P_i$ and $N_i$ are its positive and negative contributions, and the feature box is exact and Cartesian. With the readout fixed, $c$ is certified if and only if, for every $j$, $\min_h(a_c-a_j)\cdot h>0$ (positive readout) or $\min_h(v_c-v_j)\cdot h+d_c-d_j>0$ (signed readout), with each coordinate taken at a box end.
- **(b)** For the deep control $q=\sigma(Gh+e)$, $L=Vq+d$, with a box on $(G,e,V,d)$ and $h$ fixed, $c$ is certified if and only if, for every $j$, the minimum of $(\underline v_c-\overline v_j)\cdot q+\underline d_c-\overline d_j$ over the $q$-box is positive. Here $\underline v_c$ lowers and $\overline v_j$ raises each entry within its box.

*Proof.* (a) Each pre-activation is linear in its own row, every parameter occurs once, and $x\ge0$, so the extremes are the stated corners. Rows are disjoint, so the box is a product. A linear function is then minimised over a box. (b) As in (a), the $q$-box is exact and Cartesian. Because $q>0$, the worst $V$ for the pair $(c,j)$ does not depend on $q$: lower row $c$ and raise row $j$, entry by entry. A linear function of $q$ remains. ∎

Every test runs once per competitor. Each rejection also returns its minimising parameter vertex. At the primary radius $\rho=0.01$, we ran these vertices through the network, up to 400 per model, to confirm the flips.

**Checks.** The script `verify_p1_theory.py` checks each proposition in float64:

- **Proposition 1.** The argmax was preserved on $10^5$ random inputs, and (1) held to $1.8\times10^{-15}$.
- **Proposition 2.** Equation (2) agreed with a direct corner evaluation to $3.3\times10^{-16}$. Independently, 300 random members of each box at $0.98\,r^{\ast}$ never changed the winner, and the minimising corner at $1.02\,r^{\ast}$ always did (200 positive and signed readouts).
- **Proposition 3.** The identity (3) held to $6.3\times10^{-16}$. The sufficient bits condition held in all 813 cases where it applied.
- **Proposition 4.** The bound (a) held on 2000 random block readouts. For a fixed block-symmetric readout, the median radius fell from 0.114 at $n=4$ blocks to 0.075 at $n=1024$, against the limit 0.074, while the median absolute Bayes log-odds rose from 0.75 to 128. The first-order noise law matched Monte Carlo to within 0.7%.
- **Propositions 5 and 6.** The exact tests matched enumeration of every hidden vertex in 300 of 300 random tails with $T\in\lbrace 0.25,1,4\rbrace$, 200 of 200 first-layer boxes and 200 of 200 deep signed tails. The linear test of Proposition 5(b) matched the threshold solve in 3000 of 3000 cases, and the bracket of Proposition 5(d) held on 400 random tails.

# 4 Protocol as executed

Paper II fixed the P1 protocol and its decision thresholds on 1 October 2026, before any P1 code was written. They were proposed registration values, not a public registration. Table 2 sets each registered field beside what was run.

**Table 2.** The registered MNIST protocol (Paper II, Table 4) and its execution.

| Field | Registered | Executed |
|---|---|---|
| Data | 55,000 / 5,000 / 10,000; save indices and hashes | MNIST [7]; seeded permutation (seed 20261004) of the 60,000 training images; indices saved; split SHA-256 `8c6d30db…7c2f`; MD5 of all four files matches the canonical values |
| Preprocessing | Pixels in $[0,1]$; no augmentation | As registered, identical for every model |
| Widths, seeds | 64, 256, 1024, 4096; seeds 11, 23, 37, 53, 71 | As registered; the seed fixes initialisation and minibatch order |
| Training | Adam, batch 256, 20 epochs; learning rate from $\lbrace 3\times10^{-4},10^{-3},3\times10^{-3}\rbrace$ at width 256 by validation accuracy, then loss; frozen across widths | As registered [8], final-epoch models. Chosen: $3\times10^{-3}$ for the positive and signed readouts and the tails at $T=0.25$ and 4; $10^{-3}$ for the tail at $T=1$ and the deep MLP |
| Logits | $8\log y$ for the positive model | As registered; margins are reported in units of $\log y$, before the factor 8 |
| Uncertainty | Log radii 0, 0.0025, 0.005, 0.01, 0.02; readout box and joint tail box separate | As registered, with the first-layer box reported separately as Paper II asks; exploratory radii 0.05, 0.1, 0.2 added |
| Temperature | $T=1$ primary; 0.25 and 4 | As registered |
| Measurements | Accuracy, certified accuracy, coverage, released accuracy, margin quantiles, local and grouped fan-in, flips, bits, latency | All. Flips are witnessed by exact vertices; margin quantiles are in Appendix B, Table B3 |
| Reporting | Five seeds, every seed, seed-level intervals, paired width differences | 95% t-intervals over seeds ($t_{0.975,4}=2.776$); widths paired by seed; per-seed values in Appendix B |
| Discipline | Choices fixed before testing | Configuration frozen at 03:32:39 on 4 October 2026, before the first confirmatory run; the evidence pilot frozen at 03:47:04; the evaluator (SHA-256 `28702c13…fd24`) was developed on pilot models with the validation split and frozen before it first read the test split |

Paper II left some details open. We fixed them before the confirmatory runs:

- **Initialisation.** $F\sim\mathcal N(0,0.1^2)$ and $b=0$. Positive log weights start at $\log(1/\text{fan-in})+\mathcal N(0,0.1^2)$, in units of $T$ for $\Psi$. Signed weights start at $\mathcal N(0,1/\text{fan-in})$, with zero biases.
- **Hidden layers.** Both two-layer tails have 256 hidden units; the deep control uses sigmoid units. The tail of Equation (4) reduces to Paper II's $\log(1+e^{\Psi}h)$ at $T=1$.
- **Robust arm.** The grid was $\lambda\in\lbrace 0.1,1\rbrace\times\gamma\in\lbrace 0.05,0.25\rbrace$, at the positive readout's learning rate. The pilot chose $\lambda=1$, $\gamma=0.05$ by validation certified accuracy at $\rho=0.01$, then by validation accuracy.
- **Grouped fan-in.** Paper II asks for a declared grouping procedure for learned features. We join features into groups by single linkage whenever their validation activations correlate at 0.99, 0.95 or 0.90. Features that are constant on the validation split form one group.
- **Bits.** The readout log weights are stored on uniform $b$-bit grids over their span, and Proposition 3 gives the exact one-layer criterion.
- **Latency.** We timed the float32 nominal pass and each certificate on the 10,000 test images, on one CPU thread after all training ended, taking the best of three runs.

Two points depart from Paper II's wording:

- **Flips.** Paper II suggested adversarial weight search to separate inconclusive certificates from flips. Our tests are exact, so every rejection has a constructed witness and search is unnecessary.
- **Matched comparisons.** Within the two pairs of Table 1, parameter counts match to within 10 and 266 parameters. Across pairs, we report parameter counts and measured latency rather than interpolating between widths.

# 5 MNIST results

## 5.1 Accuracy against the matched control

**Table 3.** Test accuracy (%), mean and 95% t-interval over five seeds. The parameter row gives the positive readout and the positive tails; the signed readout has 10 more parameters, and the deep MLP 266 more than the tails.

| Family | 64 | 256 | 1024 | 4096 |
|---|---:|---:|---:|---:|
| Parameters, readouts / tails | 50,880 / 69,184 | 203,520 / 269,056 | 814,080 / 1,068,544 | 3,256,320 / 4,266,496 |
| Positive readout | 96.1 [95.9, 96.3] | 96.9 [96.7, 97.0] | 97.3 [97.1, 97.5] | 97.6 [97.4, 97.8] |
| Positive readout, robust margin | 96.1 [95.8, 96.3] | 96.9 [96.8, 97.0] | 97.3 [97.3, 97.4] | 97.8 [97.7, 97.8] |
| Signed readout | 97.1 [97.0, 97.3] | 98.0 [98.0, 98.1] | 98.2 [98.2, 98.3] | 98.0 [97.6, 98.4] |
| Positive tail, $T=1$ | 94.1 [93.9, 94.3] | 94.8 [94.7, 95.0] | 95.5 [95.1, 96.0] | 96.4 [96.2, 96.6] |
| Positive tail, $T=0.25$ | 95.0 [94.7, 95.2] | 95.6 [95.2, 96.0] | 96.1 [96.0, 96.2] | 96.4 [96.2, 96.6] |
| Positive tail, $T=4$ | 95.5 [95.1, 95.9] | 96.2 [96.2, 96.3] | 96.9 [96.8, 97.1] | 97.3 [97.3, 97.4] |
| Deep signed MLP | 97.2 [97.1, 97.4] | 97.9 [97.8, 98.1] | 98.2 [98.1, 98.3] | 98.3 [98.2, 98.4] |

Table 3 shows the positive readout gaining accuracy with width, from 96.1% to 97.6%. Paired by seed, it trailed the signed readout by 1.05, 1.17, 0.96 and 0.40 points at the four widths, with every 95% interval inside two points. The registered accuracy criterion is met. The robust arm matched the positive readout.

The positive tails trailed the deep signed MLP of nearly equal size. Paired by seed, the gaps at widths 64 to 4096 were:

- 3.12, 3.12, 2.64 and 1.91 points at $T=1$;
- 2.23, 2.34, 2.11 and 1.93 points at $T=0.25$;
- 1.69, 1.71, 1.25 and 0.99 points at $T=4$.

Paper II registered no accuracy criterion for its secondary model. If the two-point test were applied to it, $T=4$ would pass at every width, and its 95% intervals would also stay inside two points. $T=1$ and $T=0.25$ would pass only at width 4096, and only on the seed means: their intervals there extend to 2.14 points.

## 5.2 Readout certificates do not fall with width

**Table 4.** Readout box: certified accuracy (%) at the registered radius 0.01 and the exploratory radii 0.1 and 0.2, and the median certified radius. Means over five seeds.

| Family | Width | Certified at 0.01 | at 0.1 | at 0.2 | Median radius |
|---|---:|---:|---:|---:|---:|
| Positive readout | 64 | 96.0 | 94.4 | 91.6 | 0.447 |
| | 256 | 96.8 | 95.6 | 93.9 | 0.535 |
| | 1024 | 97.2 | 96.4 | 95.0 | 0.621 |
| | 4096 | 97.5 | 96.8 | 95.5 | 0.682 |
| Signed readout | 64 | 96.6 | 84.9 | 42.5 | 0.187 |
| | 256 | 97.6 | 82.8 | 23.0 | 0.160 |
| | 1024 | 97.8 | 82.5 | 19.3 | 0.154 |
| | 4096 | 97.6 | 85.9 | 39.6 | 0.180 |
| Deep signed MLP | 64 | 96.7 | 80.8 | 20.1 | 0.157 |
| | 4096 | 98.2 | 95.3 | 86.9 | 0.336 |
| Positive tail, $T=1$ | 64 | 93.8 | 91.0 | 85.0 | 0.336 |
| | 4096 | 96.3 | 95.0 | 92.6 | 0.406 |

The registered test concerns the positive readout at $\rho=0.01$ (Table 4, Figure 1). Its certified accuracy rose from 96.8% at width 256 to 97.5% at width 4096. The paired change was $+0.76$ points, with 95% interval $[+0.49,+1.03]$, and it was positive for all five seeds, between $+0.43$ and $+1.01$. The change is within the registered five points, so the criterion is met, and the rejection criterion, a drop of more than ten points, is far from triggered. Coverage was 99.7–99.8%, and accuracy on released decisions was 96.3–97.7%.

The margins grew with width. The median log margin rose from 0.895 at width 64 to 1.363 at width 4096, a slope of $+0.079$ per doubling (95% interval $[0.074,0.084]$). Paper II asked for this slope; it is positive, and Table B3 gives the margin quantiles. By Proposition 2, the readout radius is half the log margin, so the positive readout's certificates held far beyond the registered radii. At $\rho=0.2$ it still certified 95.5% at width 4096, against 39.6% for the signed readout and 86.9% for the deep MLP. The signed readout's median radius stayed near 0.15–0.19, in line with its median cancellation factor $\kappa$ of 5.4–6.6 (for which $\operatorname{artanh}(1/\kappa)$ is 0.15–0.19).

**A signed readout started from zero (exploratory).** Signed certificates depend on the representation (Section 6.2). We therefore retrained the signed family at widths 256 and 4096 with its readout weights started at zero, everything else as registered.

- **Accuracy** was 98.0% at width 256, unchanged, and 98.3% at width 4096, 0.27 points higher.
- **The median readout radius** moved from 0.160 to 0.164 at width 256 and from 0.180 to 0.204 at width 4096.
- **Certified accuracy at $\rho=0.2$** moved from 23.0% to 26.8% and from 39.6% to 51.3%.

The zero start helped the signed readout at width 4096, but the positive readout's advantage at large radii (93.9% and 95.5% at $\rho=0.2$) remains, so it is not an artefact of the signed control's initialisation.

At $\rho=0.01$ the exact readout test rejected between 89 and 166 of the positive readout's decisions per width, summed over five seeds, and every one flipped at its corner. For the readout box the witness is the corner itself, so this check confirms the arithmetic rather than adding an independent test. The first-layer, joint-tail and signed-readout witnesses below run the network.

![Certified accuracy against width](figures/fig_cert_vs_width.png)

**Figure 1.** Certified accuracy against width for the three boxes, at the registered radius $\rho=0.01$ (solid) and the exploratory radius $\rho=0.1$ (dashed). Bars are 95% t-intervals over five seeds. At $\rho=0.01$ every family stays within a few points of its accuracy. At $\rho=0.1$ the positive models keep most of their readout and joint-tail certificates and 58–78% in the first-layer box, while the signed readout's first layer and the deep MLP's joint tail lose most or all of theirs.

## 5.3 How the positive readout keeps its margins

The positive readout selects; it does not accumulate (Figure 2).

- **Fan-in.** Its local fan-in was 1.28, 1.59, 2.40 and 4.79 at the four widths, against 26, 94, 292 and 550 for the signed readout. Grouping correlated features changed it little: 4.41 at width 4096 with the 0.90 threshold.
- **Feature activity.** The feature layer it trained was nearly silent. Between 93.1% and 98.8% of all feature activations were below $10^{-3}$, and the median activation was below $10^{-7}$. On average 0.14 to 3.67 features per image exceeded 0.5. The signed readout's features were dense: 13–17% of activations were below $10^{-3}$, and the median activation was 0.05–0.37.
- **Truncation.** Keeping only the single most active feature of each image, the same set for every class, left 95.5%, 96.1%, 96.1% and 96.4% accuracy at the four widths. Keeping four restored 96.1–97.4%, within 0.2 points of the full readout.
- **Contrast and bits.** The log margin was 0.51–0.53 of the largest log-weight contrast permitted by Proposition 3, and the readout log weights spanned 3.2–3.9 nats. The median number of bits per log weight needed to certify the stored decision was 2.6–3 (seed means). With 6 bits, certified accuracy was 95.7–97.4%.

![Radii and fan-in against width](figures/fig_margins_fanin.png)

**Figure 2.** Left: median certified radius of the readout box (solid) and the joint tail box (dashed). Centre: median local fan-in (solid) and grouped fan-in at correlation 0.90 (dotted), on a log scale. Right: median first-layer radius, exact (solid) and marginal (dotted). Means over five seeds.

The selected features are also hard for a signed readout fitted afterwards. The positive logits $8\log y$ are invariant to rescaling $h$, image by image, and the trained features are tiny and vary in scale. We trained a signed readout on the frozen features with the signed family's protocol (exploratory).

- **Raw features:** 72.4%, 77.5%, 87.3% and 94.6% at the four widths.
- **Standardised features:** 84.3%, 87.4%, 92.6% and 96.1%.
- **Each image's features normalised to unit sum, then standardised:** 96.2%, 96.9%, 97.2% and 97.4%, within 0.3 points of the positive readout at every width.

The positive readout's decision rule is itself linear in $h$ and available to the signed readout ($V=e^{\Theta}$, $d=0$). These results are consistent with the per-example normalisation that the log ratio provides being what a plain signed readout lacks on these features.

## 5.4 The joint tail box: exact and marginal tests

**Table 5.** Joint tail box at $\rho=0.01$ unless stated: certified accuracy (%) for the exact and marginal tests, means over seeds, and median radii. Decision counts are summed over five seeds. *Inconclusive* counts decisions rejected by the marginal test but certified by the exact test.

| Family | Width | Exact | Marginal | Exact at 0.1 | Median radius, exact / marginal | Inconclusive | Rejected / witnessed |
|---|---:|---:|---:|---:|---|---:|---|
| Positive tail, $T=1$ | 64 | 93.7 | 93.6 | 88.6 | 0.239 / 0.168 | 159 | 469 / 469 |
| | 256 | 94.5 | 94.4 | 90.3 | 0.249 / 0.177 | 131 | 408 / 408 |
| | 1024 | 95.3 | 95.2 | 92.4 | 0.270 / 0.192 | 100 | 275 / 275 |
| | 4096 | 96.3 | 96.2 | 94.0 | 0.285 / 0.203 | 56 | 194 / 194 |
| Positive tail, $T=0.25$ | 64 | 94.7 | 94.6 | 91.2 | 0.265 / 0.195 | 106 | 347 / 347 |
| | 4096 | 96.2 | 96.2 | 94.3 | 0.305 / 0.232 | 40 | 194 / 194 |
| Positive tail, $T=4$ | 64 | 95.1 | 95.0 | 90.0 | 0.264 / 0.204 | 116 | 450 / 450 |
| | 4096 | 97.2 | 97.2 | 95.5 | 0.383 / 0.292 | 36 | 155 / 155 |
| Deep signed MLP | 64 | 94.9 | 94.1 | 0.5 | 0.052 / 0.042 | 566 | 1883 / 1864 of 1864 checked |
| | 256 | 95.7 | 94.7 | 0.2 | 0.048 / 0.038 | 568 | 1785 / 1785 |
| | 1024 | 96.3 | 95.6 | 1.2 | 0.053 / 0.045 | 409 | 1505 / 1505 |
| | 4096 | 97.0 | 96.7 | 18.6 | 0.071 / 0.062 | 235 | 1085 / 1085 |

The joint tail box behaved as Proposition 5 predicts (Table 5). The exact joint radius sat between the marginal radius and the conditional readout radius: at width 4096 the medians were 0.203, 0.285 and 0.406 for the positive tail at $T=1$. The marginal test lost little certified accuracy at $\rho=0.01$, because the trained margins were wide. Even so, for $T=1$ it rejected 56–159 certifiable decisions per width (summed over five seeds) that only the exact test released. Every checked exact rejection was a witnessed flip. The only unchecked ones were 19 of 1883 for the deep MLP at width 64, beyond the cap of 400 per model.

At nearly equal parameter count, the positive tails' median joint radius was four to six times the deep signed MLP's: 4.0–5.2 times at $T=1$, 4.3–5.8 at $T=0.25$ and 5.1–6.3 at $T=4$. At $\rho=0.1$ the positive tail at $T=1$ certified 88.6–94.0% of test images and the deep MLP 0.2–18.6%. At $\rho=0.01$ the deep MLP certified slightly more than the tails at $T=1$ and $T=0.25$, reflecting its higher accuracy. From $\rho=0.02$ upward the tails certified more at every width. The certified accuracy of every tail and of the deep MLP rose with width; the paired change from 256 to 4096 was $+1.79$ points for the positive tail at $T=1$ and $+1.35$ points for the deep MLP.

The temperature changed the trained representation, as Paper II intended. Near a maximum ($T=0.25$), the hidden units stayed distinct: grouped at 0.95, 9.4–14.1 effective units remained. At $T=4$ they merged into one group. Yet $T=4$ was the most accurate tail (95.5–97.3%) and had the largest joint radii at widths 256 to 4096 (0.29–0.38). The joint certificate tracked the margin, not the diversity of the hidden units.

Local fan-in misleads here, as Paper II warned. The positive tail's readout at $T=1$ had a local fan-in of about 54, but its 256 hidden units were near-duplicates. Grouping units whose validation activations correlate at 0.95 left 2.3–7.2 effective units, and at 0.90 about one.

## 5.5 The first-layer box

**Table 6.** First-layer box $(F,b)$ at the point input, readout fixed: certified accuracy (%) for the exact and marginal tests and median radii. Means over five seeds.

| Family | Width | Exact at 0.01 | Marginal at 0.01 | Exact at 0.1 | Median radius, exact / marginal |
|---|---:|---:|---:|---:|---|
| Positive readout | 64 | 95.0 | 93.0 | 58.4 | 0.113 / 0.032 |
| | 256 | 95.8 | 94.7 | 64.9 | 0.125 / 0.041 |
| | 1024 | 96.5 | 95.8 | 72.6 | 0.140 / 0.062 |
| | 4096 | 97.0 | 96.5 | 78.1 | 0.152 / 0.091 |
| Signed readout | 64 | 95.4 | 94.6 | 15.4 | 0.070 / 0.054 |
| | 256 | 96.4 | 95.5 | 3.2 | 0.059 / 0.046 |
| | 1024 | 96.4 | 95.3 | 0.2 | 0.051 / 0.039 |
| | 4096 | 95.8 | 94.4 | 0.2 | 0.048 / 0.035 |

Width helped the positive readout's first layer and hurt the signed readout's (Table 6).

- **Certified accuracy.** From width 256 to 4096, the positive readout's exact certified accuracy at $\rho=0.01$ changed by $+1.20$ points (95% interval $[0.97,1.44]$), and the signed readout's by $-0.60$ $[-1.11,-0.09]$.
- **Radius.** From width 64 to 4096, the median exact radius grew from 0.113 to 0.152 for the positive readout and shrank from 0.070 to 0.048 for the signed one.
- **The exact test.** Here the dependency-aware test mattered most. For the positive readout the exact radius was 1.7 to 3.6 times the marginal radius. At width 64, 2.9% of test decisions were inconclusive under the marginal test but certified by the exact one.
- **Witnesses.** Every exact rejection, all of them checked, was a witnessed flip.

## 5.6 Robust margin, additive budgets, cost and latency

**Robust arm.** The selected hinge, $\lambda=1$ and $\gamma=0.05$, targets a log margin of 0.07. Between 98.8% and 99.5% of the positive readout's test decisions already exceed that margin, so the arm changed little. Its certified accuracy at $\rho=0.01$ was within 0.2 points of the positive readout's at every width. Its extra training cost was not measurable: 12–13 s against 12 s per pilot run at width 256.

**Additive budget.** We also perturbed every readout weight additively, by $\pm\varepsilon$ times the root-mean-square readout weight. The median certified $\varepsilon$ was 0.69–1.01 for the positive readout, 0.10–0.13 for the signed readout and 0.12–0.24 for the deep MLP. At $\varepsilon=0.05$, certified accuracy was 95.5–97.3%, 89.1–92.0% and 90.5–96.6% respectively. The positive readout's advantage therefore does not depend on the multiplicative box.

**Latency.** We measured latency for seed 11 of each family on one CPU thread with numpy, taking the best of three passes over the 10,000 test images. At small widths, timings of identical architectures differed by up to 1.7 times, so only large differences are meaningful.

- **Nominal pass.** The positive readout's float32 nominal pass took 1.5, 4.5, 15.4 and 59.6 µs per image at widths 64 to 4096.
- **Readout certificates.** The positive readout's certificate is essentially free: its radius is half the log margin, already computed in under 0.1 µs. The signed readout's closed form needs its positive and negative masses, which cost 0.4–12.2 µs.
- **Joint-tail test.** The positive tails' exact joint-tail test took 6–8 µs per image at every width, because it runs over the 256 hidden units. At width 4096 that is under 10% of the nominal pass, and the marginal test cost about the same. The deep MLP's exact tail test took 33–38 µs in our implementation, up to 16 times its nominal pass at width 64.
- **First-layer test.** For the positive readout, the exact first-layer test cost 1.0–1.5 times the nominal pass.
- **The sum temperature.** At $T=0.25$ the nominal tail pass was 3.3–6.4 times slower than at $T=1$, reaching 554 µs per image at width 4096. The power $h^{1/T}=h^4$ made 4.9% of the nonzero float32 values subnormal. Flushing them to zero sped up the main matrix product 8.4-fold.

These are numpy timings on a two-core CPU, not hardware claims.

## 5.7 Training scale (exploratory)

The positive readout trains on the logits $\alpha\log y$, with $\alpha=8$ registered. At width 1024 we repeated its training with $\alpha\in\lbrace 2,4,16,32\rbrace$ for seeds 11, 23 and 37 (Table 7).

**Table 7.** The training logit scale $\alpha$ (positive readout, width 1024, three seeds; $\alpha=8$ from the confirmatory runs).

| $\alpha$ | Accuracy (%) | Median log margin | $\alpha\times$ margin | Local fan-in | Readout certified at 0.01 / 0.1 / 0.2 (%) | First layer certified at 0.01 (%) |
|---:|---:|---:|---:|---:|---|---:|
| 2 | 96.4 | 3.48 | 7.0 | 1.02 | 96.4 / 95.9 / 95.5 | 95.5 |
| 4 | 96.8 | 2.08 | 8.3 | 1.31 | 96.8 / 96.3 / 95.6 | 96.0 |
| 8 | 97.3 | 1.26 | 10.1 | 2.43 | 97.2 / 96.3 / 94.9 | 96.5 |
| 16 | 97.7 | 0.71 | 11.4 | 7.48 | 97.5 / 95.1 / 88.9 | 96.8 |
| 32 | 98.1 | 0.43 | 13.6 | 16.5 | 97.8 / 91.5 / 58.2 | 97.2 |

The training scale acted as a temperature on the trained model.

- **Margin.** The log margin fell as $\alpha$ grew, roughly as $\alpha^{-0.76}$. That is more slowly than the $1/\alpha$ that exact calibration would give: $\alpha$ times the margin rose from 7.0 to 13.6 over a sixteenfold range.
- **Accumulation and accuracy.** Lower margins bought both. Local fan-in rose from 1.0 to 16.5, and accuracy from 96.4% to 98.1%, within 0.2 points of the signed readout's 98.2% at the same width.
- **Certificates.** Certified accuracy at the registered radius rose with $\alpha$, but at $\rho=0.2$ it fell from 95.5% to 58.2%.

The training scale thus traded large-radius certificates for accuracy and accumulation, a trained counterpart of the input log range in Paper II's L1 check. The registered $\alpha=8$ lies in the middle of this range.

# 6 The evidence task

## 6.1 Design

MNIST cannot show that a large fan-in combines independent evidence, so Paper II registered a controlled task. A balanced label $c\in\lbrace -1,+1\rbrace$ generates $n=16$ conditionally independent blocks, $z_g\sim\mathcal N(c\mu,1)$. The Bayes rule is $\operatorname{sign}\sum_gz_g$. The four-block oracle takes the sign of the sum of the four blocks of largest magnitude.

Each block is encoded separately by a fixed positive map with $k$ units: $k/2$ increasing units $\sigma(z_g-t_i)$ and $k/2$ decreasing units $1-\sigma(z_g-t_i)$, with thresholds $t_i$ evenly spaced on $[-2,2]$. Nothing mixes blocks before the tested stage. That stage is a positive readout, trained with logits $8\log y$, and the control is a signed readout on the same features. Width is $16k\in\lbrace 64,256,1024,4096\rbrace$, so wider models see finer, more redundant encodings of the same 16 blocks.

Training, validation and test sets have 50,000, 10,000 and 20,000 examples from fixed generator seeds. Every model and both oracles are scored on the same test examples. Significance against the four-block oracle uses a one-sided exact McNemar test [14] on the paired test decisions, with Holm's correction [15] over the 20 seed–width tests.

**Pilot.** $\mu$ was chosen on a separate pilot split of 20,000 examples, before any confirmatory run, to maximise the accuracy gap between the Bayes rule and the four-block oracle. The grid was $\mu\in\lbrace 0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.5\rbrace$. The gap was 0.0464 at both $\mu=0.25$ and $\mu=0.30$, a net 928 more correct decisions out of 20,000, and the rule took the first maximum, $\mu=0.25$. The learning-rate pilot at width 256 chose $3\times10^{-3}$ for the positive readout and $3\times10^{-4}$ for the signed one.

## 6.2 Accumulation with nearly width-invariant certificates

**Table 8.** Evidence task with 16 independent blocks and $\mu=0.25$. Bayes accuracy is 84.51% and four-block oracle accuracy 79.71%. Accuracy is the seed mean with its 95% t-interval; other columns are means over seeds of medians over test examples or of certified fractions. *Decision fan-in* (added after testing) is the participation ratio, $(\sum_g\lvert\delta_g\rvert)^2/\sum_g\delta_g^2$, of the block contributions $\delta_g$ to the score difference between the two outputs, bias excluded. On this measure the Bayes rule scores 10.61 and the four-block oracle 3.85. The column at $\rho=0.1$ and the zero-start rows (added after testing) are exploratory.

| Readout | Width | Accuracy (%) | Over four-block (pp) | Largest p | Decision fan-in | Local fan-in | Median radius | Certified at 0.01 (%) | Certified at 0.1 (%) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Positive | 64 | 84.38 [84.32, 84.43] | 4.67 | 5.5e-79 | 10.16 | 21.2 | 0.129 | 82.24 | 57.3 |
| Positive | 256 | 84.39 [84.32, 84.45] | 4.67 | 1.3e-71 | 10.84 | 85.1 | 0.123 | 82.21 | 55.8 |
| Positive | 1024 | 84.36 [84.28, 84.43] | 4.65 | 3.1e-69 | 10.92 | 339.6 | 0.122 | 82.18 | 55.5 |
| Positive | 4096 | 84.37 [84.29, 84.45] | 4.66 | 4.4e-69 | 10.94 | 1358.1 | 0.122 | 82.17 | 55.4 |
| Signed | 64 | 84.35 [84.31, 84.39] | 4.64 | 1.4e-79 | 10.41 | 42.6 | 0.089 | 81.33 | 43.0 |
| Signed | 256 | 84.37 [84.28, 84.46] | 4.66 | 2.6e-68 | 10.99 | 152.2 | 0.094 | 81.45 | 45.4 |
| Signed | 1024 | 84.24 [84.14, 84.35] | 4.53 | 5.8e-65 | 10.97 | 533.3 | 0.069 | 80.23 | 30.1 |
| Signed | 4096 | 84.07 [83.80, 84.34] | 4.36 | 8.4e-53 | 10.89 | 2051.9 | 0.039 | 76.75 | 4.4 |
| Signed, zero start | 64 | 84.41 | 4.70 | 5.2e-82 | 10.17 | – | 0.086 | 81.24 | 41.3 |
| Signed, zero start | 256 | 84.41 | 4.70 | 9.4e-70 | 11.05 | – | 0.101 | 81.70 | 48.4 |
| Signed, zero start | 1024 | 84.22 | 4.51 | 1.2e-64 | 11.06 | – | 0.103 | 81.69 | 49.2 |
| Signed, zero start | 4096 | 84.07 | 4.36 | 4.9e-52 | 10.94 | – | 0.107 | 81.57 | 50.6 |

![Evidence task](figures/fig_evidence.png)

**Figure 3.** Evidence task. Left: certified accuracy at $\rho=0.01$ (solid) and $\rho=0.1$ (dashed) for the positive and the registered signed readout. Centre: median readout radius. Right: the positive readout's flip rate under random log-weight draws inside the box at $\rho=0.1$, against its local fan-in, with a slope of $-1/2$ for reference.

Table 8 and Figure 3 summarise the main configuration.

**The positive readout accumulates.**

- **Accuracy.** At every width it was within 0.16 points of the Bayes rule. It agreed with the Bayes decision on 98.7–98.8% of test examples and beat the four-block oracle by 4.7 points. All 20 seed–width tests were significant, with largest p-value $4.4\times10^{-69}$, so they survive Holm's correction.
- **Decision fan-in.** It was 10.2–10.9, against 10.61 for the Bayes rule and 3.85 for the four-block oracle. The decisions therefore drew on the independent blocks as broadly as the Bayes rule did.
- **The registered criterion.** "Significantly outperforms the four-block oracle while using nonredundant blocks" is met. The blocks are nonredundant by construction. The registered grouped fan-in, 13.0–13.6 of 16, and the decision fan-in both show many blocks in use, though only the latter is decision-relevant, as the next paragraph explains.

Paper II's grouped fan-in is not the right measure here. It sums each block's share of the output mass, and that share includes the constant mass each block contributes, because its units sum to $k/2$. That fan-in was 13.0–13.6 of 16 for the positive readout. A version of the width-256 readout whose decision uses a single block, made by equalising both rows on the other 15 blocks, scores 15.75, against a decision fan-in of 1.00. Grouped mass fan-in counts common-mode mass as participation, which is Proposition 1's warning in another form. Decision fan-in, built from the contributions to the margin, does not.

**Calibration sets the margin.** Cross-entropy on the logits $8\log y$ makes the positive readout approximately calibrated. Its median log margin, 0.24–0.26, was close to the median absolute Bayes log-odds divided by 8 (0.263), and the per-example Spearman correlation between margin and absolute log-odds was 0.993–0.995. The readout radius is therefore close to $|\text{log-odds}|/16$. The radius depends only on the function computed, and the trained function changed little with width. The median radius stayed at 0.12–0.13, and certified accuracy at $\rho=0.01$ stayed at 82.2% at every width.

**What the signed control's erosion shows.** The registered signed readout matched this accuracy within 0.03 points at widths 64 and 256, but fell 0.12 and 0.30 points short at 1024 and 4096. Its certificates eroded as the encoding became redundant:

- certified accuracy at $\rho=0.01$ fell from 81.3% and 81.5% at widths 64 and 256 to 76.8% at 4096;
- certified accuracy at $\rho=0.1$ fell from 43.0% and 45.4% to 4.4%;
- its median radius fell from 0.094 at width 256 to 0.039.

Proposition 2's remark accounts for this, and the zero-start control below confirms it. Weight components that training does not constrain keep their random initial values and count as opposing mass. With two classes, cross-entropy moves the two rows in exactly opposite directions, so their sum never leaves its random start. Redundant units add further directions with little training signal.

A signed readout trained identically from zero weights did not erode (exploratory). At $\rho=0.01$ it certified 81.2–81.7%, and its median radius stayed at 0.086–0.107 across widths. The erosion therefore came from the registered initialisation, not from signed readouts as such. Even from zero, the signed readout certified less than the positive one at every width and every radius, for example 41–51% against 55–57% at $\rho=0.1$.

## 6.3 Redundant sources and more evidence (exploratory)

**Redundant blocks.** In a control, the 16 blocks are four independent sources, each copied four times. The four largest blocks are then always the four copies of the most extreme source, so the four-block oracle degenerates to a one-source rule: its decision fan-in by source is 1.00, against 2.93 for the Bayes rule. The positive readout reached 69.14%, against 69.24% for the four-source Bayes rule. It beat the degenerate oracle, at 67.73%, with p-values up to $6.6\times10^{-8}$. Grouped by source, its decision fan-in was 2.99. Grouped by block, its mass fan-in reported 15.84 and its decision fan-in 11.83. Only grouping by source reveals the redundancy, and a four-block comparison on redundant blocks is not evidence of accumulation. The signed control behaved the same way, and here it certified slightly more: 64.4% against 63.3% at $\rho=0.01$.

**More evidence.** At $k=16$ we varied the number of independent blocks, keeping $\mu$ fixed (Table 9).

**Table 9.** Evidence against the number of independent blocks ($k=16$, five seeds; medians over test examples, then means over seeds).

| Blocks $n$ | Median $\lvert$Bayes log-odds$\rvert$ | Accuracy (%), positive / Bayes | Positive log-weight span | Positive median margin (median $\lvert$log-odds$\rvert$/8) | Positive median radius | Signed median radius | Certified at 0.01 (%), positive / signed |
|---:|---:|---|---:|---|---:|---:|---|
| 4 | 0.76 | 68.92 / 68.93 | 1.6 | 0.095 (0.095) | 0.048 | 0.105 | 63.0 / 66.2 |
| 16 | 2.10 | 84.39 / 84.51 | 5.0 | 0.246 (0.263) | 0.123 | 0.094 | 82.2 / 81.5 |
| 64 | 8.04 | 97.72 / 97.82 | 7.8 | 0.336 (1.005) | 0.168 | 0.098 | 97.0 / 96.5 |

With $n=4$, the four-block oracle is the Bayes rule, and both readouts match it, with p between 0.24 and 0.98, as they should. The positive readout's margin tracked the evidence while its log weights could follow. At $n=4$ and 16 it matched the log-odds divided by 8, and its log-weight span grew from 1.6 to 5.0 nats. At $n=64$ the span grew to 7.8 nats, but the median margin, 0.336, was a third of the calibrated value, 1.005, although accuracy stayed within 0.11 points of the Bayes rule. This is consistent with Proposition 4(a). The ratio $e^{m}$ of a sum readout is a weighted mean of block ratios, so following an extensive log-odds requires the block ratios themselves to grow with $n$; the bound itself (best block, span) was not reached.

The radius rose 3.5-fold from 4 to 64 blocks while the log-odds rose 10.6-fold, and only 1.36-fold from 16 to 64 blocks while the log-odds rose 3.8-fold. The share of correct decisions certified at $\rho=0.01$ rose from 91.4% to 97.4% and 99.3%, through both larger radii and fewer decisions near the boundary. The signed readout's radius did not grow at all (0.105, 0.094, 0.098). It certified more than the positive readout at $n=4$, less at 16 and 64.

**Coherent and incoherent perturbations.** We drew 16 random perturbations of the log weights, uniform inside the box, and applied each to the same 4000 test examples. At $\rho=0.1$, they flipped the positive readout's decision with probability 1.19%, 0.74%, 0.39% and 0.17% at widths 64 to 4096. That is a 6.9-fold fall as local fan-in grew 64-fold (8.9-fold and 8.2-fold at $\rho=0.02$ and 0.05), consistent with the $\sqrt{64}=8$ of Proposition 4(d). In the same box, the worst case rejects about a third of the correct decisions at every width (55–57% certified of 84.4% correct). Redundant units average incoherent noise down without adding evidence or certified radius: the gap between worst-case and typical variation that Paper II's Section 2.1 describes.

# 7 Verdicts on the registered criteria

**Table 10.** Paper II's acceptance and rejection criteria for P1, and the outcomes.

| Criterion | Registered threshold | Result | Verdict |
|---|---|---|---|
| Certified accuracy across width, positive readout, $\rho=0.01$ | Changes by at most 5 points from width 256 to 4096 | $+0.76$ points, 95% interval $[+0.49,+1.03]$; all five seeds positive | Met |
| Accuracy against the matched signed control | Within 2 points | $-1.05$, $-1.17$, $-0.96$, $-0.40$ points at widths 64–4096; every 95% interval within 2 points | Met |
| Evidence task against the four-block oracle | Significantly better, with nonredundant blocks | $+4.65$ to $+4.67$ points at every width; all 20 seed–width tests $p\le4.4\times10^{-69}$; 16 independent blocks; registered grouped fan-in 13.0–13.6; post-hoc decision fan-in 10.2–10.9 (Bayes rule 10.6, oracle 3.85) | Met |
| Rejection of the scaling hypothesis | Certified accuracy falls by more than 10 points | Rises by 0.76 points | Not triggered |
| Loose bounds diagnosed separately | Separate inconclusive certificates from flips | Exact tests on every box; every checked exact rejection witnessed; inconclusive marginal certificates counted (Tables 5 and 6) | Done |

All three acceptance criteria are met and the rejection criterion is not triggered. The registered width hypothesis therefore survives P1. Three qualifications keep the verdict precise:

- **Selection, not accumulation.** On MNIST the criterion was met by selection. The positive readout kept its margins by concentrating each decision on a few features (local fan-in 1.3–4.8), not by accumulating many.
- **The secondary model.** At $\rho=0.01$ the positive tails' certified accuracy was within 1.21 points of the deep signed MLP's: lower at $T=1$ and $T=0.25$, higher at $T=4$. From $\rho=0.02$ upward it was higher at every width, by a wide margin at larger radii. The tails were 1.0–3.1 points less accurate (Section 5.1). No criterion was registered for them.
- **The evidence task.** It shows accumulation with nearly width-invariant certificates. The certificates follow the evidence only as far as the trained readout's log-weight span allows (Proposition 4, Table 9).

# 8 Discussion

**Why training escapes the random-layer collapse.** In Paper II's L1 check, random positive layers with comparable terms lost their margins as width grew, because averaging many comparable terms drives every output toward the same value. A trained readout is not bound to comparable terms. By Proposition 2 its exact radius is half its log margin, a property of the computed outputs and not of their number. Cross-entropy then ties the log margin, approximately, to the model's own log-odds divided by the logit scale, whatever the width.

The two tasks show the two ways of meeting that target.

- **MNIST: selection.** The feature layer became sparse and nearly silent, and the median local fan-in of a decision was 1.3–4.8. The log margin was about half the largest log-weight contrast that Proposition 3 permits.
- **Evidence task: accumulation.** Selection loses accuracy there, so the positive readout accumulated across blocks. It still kept a nearly width-invariant margin, consistent with extra width only refining the encoding of the same blocks and adding no common-mode mass.

**What the uniform box can and cannot reward.** Proposition 4 and Table 9 separate two questions.

- **A fixed readout.** A uniform log box cannot reward additional independent evidence. The radius is bounded by the most favourable block and by half the log-weight span, and it converges as blocks are added.
- **A trained readout.** It can still follow the evidence, because training calibrates its margin, but only by widening its log-weight span. In Table 9 that adaptation fell behind at 64 blocks, where the margin reached a third of its calibrated value.
- **Random perturbations.** They behave differently again. Proposition 4(d) gives the $\sqrt{\text{fan-in}}$ law that the evidence task reproduced, and in the evidence task redundant units also provided it (Section 6.3).

A certificate meant to reward independent evidence directly therefore needs a different uncertainty set, for example a budget on the number of corrupted sources, or boxes tied to sources rather than to weights. This is a hypothesis for the programme, not a result of P1.

**The logit scale sets the absolute radii.** If the margin is the log-odds divided by the logit scale $\alpha$, the registered choice $\alpha=8$ fixes the absolute size of every positive-readout radius in this paper. Paper II's evaluation temperature $\tau$ cannot change a certificate, but the training scale $\alpha$ changes the trained model. In Section 5.7 the margin fell roughly as $\alpha^{-0.76}$, so the $1/\alpha$ prediction held only roughly.

**Signed certificates depend on the representation.** By Proposition 2, opposing mass counts against a signed decision even when it does not affect the decision. The registered signed control started from random weights. In the evidence task, components that training could not reach kept those weights and eroded the signed certificates as width grew. A zero start removed the erosion. Comparisons between positive and signed certificates are therefore comparisons between trained representations, not between decision functions. Section 5 reports the MNIST signed readout started from zero for the same reason.

**Exact tests are affordable here.** Every box in P1 had an exact decision test, and each is a linear minimisation over a Cartesian box, done coordinate by coordinate for each competitor. In our implementation the positive models' tests cost at most about 1.7 times the nominal pass; the deep MLP's tail test, at up to 16 times, was the exception. Every exact rejection that we checked was confirmed by its witness. Paper II's marginal test (its Equation 5) was sound but discarded certifiable decisions; Tables 5 and 6 give the size of that loss.

**Implications for P2–P4.**

- **P2.** Relative score variation in Kronecker attention [6] is the attention analogue of the coherent box: common-mode drift cancels, and differential drift is what matters [2].
- **P3.** Readout decisions needed only a few bits per log weight at the trained margins (Proposition 3). A consolidation scheme for logarithmic memory [3] can therefore spend its precision on the few decisions with small margins.
- **P4.** The opponent action brake of the basal-ganglia model [5] can use the same coordinatewise test with witnesses, so an overlap trial can be separated from a certified release without search. The same tests apply to the multiply-and-prune body of KP-LNN [4] on a fixed selection region.

**Limitations.**

- **Scope of the evidence.** There is one image dataset and one synthetic task, small models, widths up to 4096, and 20 epochs of training. The largest learning rate in the grid was chosen for several families, so their optimum may lie beyond it.
- **What the boxes cover.** All boxes are in weight space at a point input. P1 says nothing about input perturbations, and the first-layer box was evaluated only for the readout models.
- **Numerical contract.** The certificates are real-arithmetic tests computed in float64 without outward rounding. They are not validated interval enclosures.
- **Fan-in grouping.** Grouping learned features by correlation is a heuristic, and single linkage can chain.
- **Mass fan-in.** Paper II's grouped fan-in is computed from output mass, so it counts common-mode mass as participation (Section 6.2). For decisions, the contribution-based measure is the relevant one.
- **Witnesses.** Witnesses were checked at $\rho=0.01$ only, and for at most 400 rejections per model.
- **Latency.** Latency was measured with numpy on a two-core CPU; it says nothing about LNS hardware.

# 9 Conclusion

P1 asked whether trained positive log interval networks keep evidence accumulation, accuracy and certified margins as width grows. Under the protocol registered in Paper II, they kept accuracy and certified margins: on MNIST the positive readout's certified accuracy rose with width, and on the evidence task it changed little. Evidence accumulation depended on the task. On MNIST the networks selected; on the controlled task they accumulated, matching the Bayes rule. Every box we studied admits an exact test with an executable witness, so every inconclusive marginal bound could be resolved into a certificate or a witnessed flip.

The results also mark the limits of the calculus. A uniform log box rewards decisive evidence, not abundant evidence. Training reaches large certified radii through calibrated margins, which depend on the logit scale and on the spread of log weights. Signed certificates depend on representation as well as decision. The next step for the programme is an uncertainty set tied to independent sources rather than to weights, carried into attention (P2), memory (P3) and action (P4) with the same exact, witnessed tests.

# References

[1] Ghosh, Debi Prasad. (2026). *Interval Transformers with Exact Local Weight Ranges and Sparse Expert Routing*. Manuscript, 1 October 2026.

[2] Ghosh, Debi Prasad. (2026). *Log Interval Networks for Certified Decisions and Structured Memory*. Research programme with reproducible numerical checks, 1 October 2026.

[3] Dibya Ghosh, Dyuti Ghosh, and Debi Prasad Ghosh. (2025). *Sleep-Consolidated Non-Backprop Learning with Logarithmic Long-Term Memory and Kronecker-Structured Weights*. Manuscript dated 21 September. https://doi.org/10.13140/RG.2.2.20326.89925

[4] Dibya Ghosh, Dyuti Ghosh, and Debi Prasad Ghosh. (2025). *Kronecker Product Logarithmic Neural Networks (KP-LNN): An Addition-Free, Signless Architecture for Matrix-Native Computation*. Manuscript dated 25 September. https://doi.org/10.13140/RG.2.2.28337.85604

[5] Dibya Ghosh, Dyuti Ghosh, and Debi Prasad Ghosh. (2025). *Kronecker-Factored Positive Logarithmic Network Model of the Basal Ganglia with Addition-Free RL*. Preprint. https://doi.org/10.13140/RG.2.2.17714.47041

[6] Dibya Ghosh, Dyuti Ghosh, and Debi Prasad Ghosh. (2025). *Yet Another Kronecker Attention in LNS (YAKAL): Fusing Algebraic Structure and Logarithmic Arithmetic for Efficient Self-Attention*. Manuscript dated 30 September. https://doi.org/10.13140/RG.2.2.26466.80329

[7] LeCun, Y., Bottou, L., Bengio, Y., and Haffner, P. (1998). Gradient-based learning applied to document recognition. *Proceedings of the IEEE*, 86(11), 2278–2324. https://doi.org/10.1109/5.726791

[8] Kingma, D. P., and Ba, J. (2015). Adam: A Method for Stochastic Optimization. *ICLR 2015*. arXiv:1412.6980. https://arxiv.org/abs/1412.6980

[9] Weng, T.-W., Zhao, P., Liu, S., Chen, P.-Y., Lin, X., and Daniel, L. (2020). Towards Certificated Model Robustness Against Weight Perturbations. *Proceedings of the AAAI Conference on Artificial Intelligence*, 34(04), 6356–6363. https://doi.org/10.1609/aaai.v34i04.6105

[10] Tsai, Y.-L., Hsu, C.-Y., Yu, C.-M., and Chen, P.-Y. (2021). Formalizing Generalization and Adversarial Robustness of Neural Networks to Weight Perturbations. *Advances in Neural Information Processing Systems*, 34, 19692–19704. https://proceedings.neurips.cc/paper/2021/hash/a3ab4ff8fa4deed2e3bae3a5077675f0-Abstract.html

[11] Moore, R. E. (1966). *Interval Analysis*. Prentice-Hall.

[12] Karnik, N. N., and Mendel, J. M. (2001). Centroid of a type-2 fuzzy set. *Information Sciences*, 132, 195–220. https://doi.org/10.1016/S0020-0255(01)00069-X

[13] Dinkelbach, W. (1967). On Nonlinear Fractional Programming. *Management Science*, 13(7), 492–498. https://doi.org/10.1287/mnsc.13.7.492

[14] McNemar, Q. (1947). Note on the sampling error of the difference between correlated proportions or percentages. *Psychometrika*, 12(2), 153–157. https://doi.org/10.1007/BF02295996

[15] Holm, S. (1979). A Simple Sequentially Rejective Multiple Test Procedure. *Scandinavian Journal of Statistics*, 6(2), 65–70.

[16] Wołczyk, M., Piczak, K., Wójcik, B., Pustelnik, Ł., Morawiecki, P., Tabor, J., Trzciński, T., and Spurek, P. (2022). Continual Learning with Guarantees via Weight Interval Constraints. *Proceedings of ICML*, PMLR 162, 23897–23911. https://proceedings.mlr.press/v162/wolczyk22a.html

[17] Gowal, S., Dvijotham, K., Stanforth, R., Bunel, R., Qin, C., Uesato, J., Arandjelović, R., Mann, T., and Kohli, P. (2018). On the Effectiveness of Interval Bound Propagation for Training Verifiably Robust Models. arXiv:1810.12715. https://arxiv.org/abs/1810.12715

[18] Miyashita, D., Lee, E. H., and Murmann, B. (2016). Convolutional Neural Networks using Logarithmic Data Representation. arXiv:1603.01025. https://arxiv.org/abs/1603.01025

[19] Zhao, J., Dai, S., Venkatesan, R., Zimmer, B., Ali, M., Liu, M.-Y., Khailany, B., Dally, B., and Anandkumar, A. (2021). LNS-Madam: Low-Precision Training in Logarithmic Number System using Multiplicative Weight Update. arXiv:2106.13914. https://arxiv.org/abs/2106.13914

[20] Daniëls, H. A. M., and Velikova, M. V. (2010). Monotone and partially monotone neural networks. *IEEE Transactions on Neural Networks*, 21(6), 906–917. https://doi.org/10.1109/TNN.2010.2044803

# Appendix A. Reproduction

The supplement contains every script, the frozen configurations, all summaries, the logs and the figures. The trained parameters are not included: they are large, but they can be regenerated deterministically from the scripts and seeds. Dependencies are Python 3.11, NumPy, SciPy, and Matplotlib for the figures. Everything runs on a CPU.

**Table A1.** Files and what they reproduce.

| File | Content |
|---|---|
| `p1lib.py` | Data loading and hashing, the five model families, the robust hinge, Adam, training |
| `p1_run.py` | `pilot` (learning rates, robust coefficient; writes `runs/config.json`), `confirm` (140 runs), `ablate` (logit scale) |
| `p1_eval.py` | The frozen evaluator: exact and marginal tests for every box, witnesses, fan-in, bits, additive budgets |
| `p1_report.py` | Seed statistics, paired differences, registered verdicts, tables and figures |
| `p1_evidence.py` | The evidence task: `pilot`, `confirm`, `explore`, `evaluate`, `report` |
| `p1_explore.py` | Exploratory truncation and signed refits on frozen positive features |
| `p1_zero_signed.py` | Exploratory MNIST signed readout started from zero |
| `p1_latency.py` | Latency of the nominal pass and of each certificate |
| `verify_p1_theory.py` | Checks of Propositions 1–6 (output in `verify_p1_theory_output.txt`) |
| `p1_facts.py` | Prints the MNIST numbers quoted in the paper from `report/summary.json`; the evidence-task numbers are in `evidence/summary.json` |

**Commands.**

```text
python3 verify_p1_theory.py
python3 p1_run.py pilot && python3 p1_run.py confirm && python3 p1_run.py ablate
OPENBLAS_NUM_THREADS=1 python3 p1_eval.py test
python3 p1_zero_signed.py && OPENBLAS_NUM_THREADS=1 python3 p1_eval.py test signed0_
python3 p1_evidence.py pilot && python3 p1_evidence.py confirm && python3 p1_evidence.py explore
python3 p1_evidence.py evaluate && python3 p1_evidence.py report
python3 p1_explore.py truncate && python3 p1_explore.py refit
P1_REFIT_NORM=l1 python3 p1_explore.py refit && P1_REFIT_RAW=1 python3 p1_explore.py refit
python3 p1_explore.py report
OPENBLAS_NUM_THREADS=1 python3 p1_latency.py subnormal
OPENBLAS_NUM_THREADS=1 python3 p1_latency.py
python3 p1_report.py && python3 p1_facts.py
```

**Data and hashes.** The four MNIST files [7] come from a public mirror of the original IDX files, and their MD5 checksums match the canonical values. The training split is a seeded permutation (seed 20261004), whose index arrays are saved in `runs/split_indices.npz`; its SHA-256 is `8c6d30db60a51ef375b495024e1e7517c5cf348fea42ce965b076ea3dd997c2f`. The evaluator's SHA-256 is `28702c13e66cb716531094411a1b3366942b6bcf5b265e77a9ea21d31adafd24`. The evidence task uses generator seeds 20261005 to 20261008 for the main configuration.

**Analyses added after test results were seen.** Everything registered was fixed beforehand. The registered measures and their values did not change.

After the evidence task's test set was first evaluated, an internal review led us to add several measures and one control. The earlier evaluation files are kept in `evidence/evals_v1`. The additions are:

- the decision fan-in, including that of the oracles;
- the calibration statistics;
- the log-weight span;
- the certified share of correct decisions;
- the fan-in demonstration;
- the zero-start signed control.

On MNIST, the following were written while the confirmatory runs were being evaluated, after some test results had been seen; all are labelled exploratory:

- the truncation and refit analyses (`p1_explore.py`);
- the zero-start signed control (`p1_zero_signed.py`);
- the latency script;
- the logit-scale summary.

The logit-scale runs themselves were specified in `p1_run.py` before the pilot.

**Runtime.** On two CPU cores, MNIST training and evaluation together took about six hours of wall-clock time, the evidence task about twenty minutes, and the theory checks under a minute.

# Appendix B. Per-seed results

**Table B1.** MNIST, every seed, in the order 11 / 23 / 37 / 53 / 71. *Box* is the joint tail box for the tails and the deep MLP, and the first-layer box for the readout models; both are at $\rho=0.01$. Margins are in units of $\log y$ for positive models and in logit units for signed ones.

| Family | Width | Test accuracy (%) | Readout certified (%) | Box certified, exact (%) | Box certified, marginal (%) | Median margin |
|---|---:|---|---|---|---|---|
| Positive readout | 64 | 96.1 / 96.3 / 95.8 / 96.1 / 96.1 | 95.9 / 96.2 / 95.7 / 96.0 / 95.9 | 94.9 / 95.3 / 94.6 / 95.0 / 95.0 | 93.0 / 93.4 / 92.6 / 92.7 / 93.4 | 0.903 / 0.911 / 0.869 / 0.896 / 0.894 |
| Positive readout | 256 | 96.7 / 97.0 / 96.8 / 96.9 / 97.0 | 96.7 / 96.9 / 96.6 / 96.8 / 96.9 | 95.8 / 95.7 / 95.7 / 95.8 / 96.0 | 94.9 / 94.6 / 94.7 / 94.3 / 95.0 | 1.040 / 1.074 / 1.105 / 1.052 / 1.077 |
| Positive readout | 1024 | 97.4 / 97.2 / 97.3 / 97.2 / 97.4 | 97.4 / 97.0 / 97.2 / 97.1 / 97.4 | 96.6 / 96.2 / 96.5 / 96.5 / 96.7 | 95.9 / 95.5 / 95.7 / 95.9 / 96.0 | 1.225 / 1.277 / 1.269 / 1.227 / 1.213 |
| Positive readout | 4096 | 97.6 / 97.4 / 97.7 / 97.6 / 97.7 | 97.5 / 97.3 / 97.6 / 97.5 / 97.6 | 97.1 / 96.8 / 97.2 / 97.1 / 97.0 | 96.5 / 96.3 / 96.7 / 96.5 / 96.5 | 1.326 / 1.380 / 1.364 / 1.362 / 1.384 |
| Positive readout, robust margin | 64 | 96.1 / 96.3 / 95.8 / 96.2 / 96.0 | 95.9 / 96.1 / 95.6 / 96.1 / 95.9 | 94.7 / 95.1 / 94.5 / 95.0 / 94.9 | 92.9 / 92.8 / 92.5 / 92.8 / 93.1 | 0.874 / 0.917 / 0.865 / 0.901 / 0.904 |
| Positive readout, robust margin | 256 | 97.0 / 96.8 / 96.9 / 96.8 / 96.9 | 96.9 / 96.7 / 96.8 / 96.7 / 96.8 | 95.9 / 95.9 / 96.1 / 95.8 / 96.0 | 94.8 / 94.5 / 94.9 / 94.7 / 94.9 | 1.013 / 1.107 / 1.088 / 1.013 / 1.115 |
| Positive readout, robust margin | 1024 | 97.3 / 97.4 / 97.4 / 97.3 / 97.4 | 97.2 / 97.4 / 97.3 / 97.2 / 97.3 | 96.3 / 96.8 / 96.6 / 96.7 / 96.7 | 95.5 / 96.0 / 95.8 / 96.0 / 95.9 | 1.176 / 1.274 / 1.237 / 1.209 / 1.217 |
| Positive readout, robust margin | 4096 | 97.8 / 97.8 / 97.7 / 97.8 / 97.7 | 97.7 / 97.8 / 97.6 / 97.7 / 97.6 | 97.1 / 97.3 / 97.1 / 97.3 / 97.1 | 96.8 / 96.9 / 96.4 / 96.9 / 96.5 | 1.315 / 1.409 / 1.303 / 1.356 / 1.307 |
| Signed readout | 64 | 97.1 / 97.0 / 97.1 / 97.3 / 97.2 | 96.6 / 96.4 / 96.7 / 96.7 / 96.8 | 95.4 / 95.1 / 95.5 / 95.5 / 95.6 | 94.6 / 94.1 / 94.7 / 94.7 / 94.8 | 7.813 / 7.597 / 7.760 / 7.805 / 7.791 |
| Signed readout | 256 | 98.1 / 98.0 / 98.0 / 98.0 / 98.1 | 97.6 / 97.5 / 97.6 / 97.7 / 97.7 | 96.4 / 96.4 / 96.4 / 96.3 / 96.4 | 95.6 / 95.3 / 95.6 / 95.6 / 95.6 | 10.810 / 10.576 / 10.611 / 10.571 / 10.590 |
| Signed readout | 1024 | 98.2 / 98.2 / 98.3 / 98.3 / 98.2 | 97.7 / 97.8 / 97.9 / 97.9 / 97.8 | 96.4 / 96.5 / 96.5 / 96.4 / 96.2 | 95.2 / 95.4 / 95.5 / 95.3 / 95.3 | 13.108 / 13.168 / 13.128 / 12.802 / 12.986 |
| Signed readout | 4096 | 98.3 / 98.3 / 97.9 / 97.6 / 98.0 | 97.9 / 97.9 / 97.6 / 97.2 / 97.5 | 96.2 / 96.1 / 95.9 / 95.2 / 95.5 | 94.7 / 94.8 / 94.7 / 93.8 / 94.1 | 14.425 / 14.290 / 15.508 / 13.780 / 14.038 |
| Deep signed MLP | 64 | 97.1 / 97.3 / 97.3 / 97.1 / 97.4 | 96.7 / 96.7 / 96.8 / 96.4 / 96.7 | 94.9 / 95.0 / 95.1 / 94.5 / 95.1 | 94.0 / 94.2 / 94.5 / 93.5 / 94.2 | 7.541 / 7.540 / 7.799 / 7.634 / 7.714 |
| Deep signed MLP | 256 | 97.8 / 98.0 / 98.0 / 97.9 / 98.1 | 97.4 / 97.6 / 97.7 / 97.6 / 97.7 | 95.6 / 95.3 / 96.0 / 95.7 / 95.8 | 94.7 / 94.2 / 95.1 / 94.7 / 95.0 | 9.614 / 9.477 / 9.912 / 9.659 / 9.628 |
| Deep signed MLP | 1024 | 98.1 / 98.2 / 98.2 / 98.3 / 98.2 | 97.9 / 97.9 / 97.9 / 98.0 / 98.0 | 96.2 / 96.1 / 96.2 / 96.5 / 96.6 | 95.4 / 95.5 / 95.4 / 95.8 / 95.8 | 11.098 / 11.006 / 11.278 / 11.326 / 11.351 |
| Deep signed MLP | 4096 | 98.4 / 98.4 / 98.3 / 98.3 / 98.4 | 98.2 / 98.1 / 98.1 / 98.1 / 98.3 | 97.1 / 97.0 / 96.8 / 96.9 / 97.3 | 96.9 / 96.5 / 96.4 / 96.5 / 96.9 | 11.789 / 11.922 / 11.889 / 11.935 / 11.885 |
| Positive tail, $T=1$ | 64 | 94.2 / 94.1 / 94.4 / 93.9 / 94.0 | 93.9 / 93.8 / 94.1 / 93.6 / 93.8 | 93.8 / 93.7 / 94.0 / 93.5 / 93.7 | 93.6 / 93.6 / 93.9 / 93.2 / 93.5 | 0.686 / 0.676 / 0.692 / 0.633 / 0.675 |
| Positive tail, $T=1$ | 256 | 94.8 / 94.9 / 94.7 / 94.7 / 94.9 | 94.6 / 94.7 / 94.5 / 94.5 / 94.7 | 94.4 / 94.6 / 94.3 / 94.3 / 94.6 | 94.2 / 94.5 / 94.3 / 94.2 / 94.5 | 0.710 / 0.718 / 0.718 / 0.689 / 0.703 |
| Positive tail, $T=1$ | 1024 | 95.1 / 95.7 / 96.0 / 95.5 / 95.4 | 95.0 / 95.6 / 95.9 / 95.4 / 95.1 | 94.9 / 95.6 / 95.8 / 95.3 / 95.0 | 94.8 / 95.5 / 95.7 / 95.2 / 95.0 | 0.757 / 0.763 / 0.792 / 0.768 / 0.765 |
| Positive tail, $T=1$ | 4096 | 96.5 / 96.2 / 96.4 / 96.6 / 96.5 | 96.4 / 96.1 / 96.3 / 96.5 / 96.4 | 96.3 / 96.0 / 96.2 / 96.5 / 96.3 | 96.3 / 96.0 / 96.1 / 96.4 / 96.2 | 0.803 / 0.805 / 0.801 / 0.807 / 0.847 |
| Positive tail, $T=0.25$ | 64 | 95.2 / 95.1 / 94.7 / 95.1 / 94.9 | 95.0 / 95.0 / 94.5 / 95.0 / 94.6 | 94.9 / 94.9 / 94.4 / 94.8 / 94.5 | 94.9 / 94.8 / 94.3 / 94.7 / 94.3 | 0.765 / 0.812 / 0.755 / 0.770 / 0.759 |
| Positive tail, $T=0.25$ | 256 | 95.8 / 95.7 / 95.1 / 95.8 / 95.7 | 95.6 / 95.6 / 94.9 / 95.6 / 95.6 | 95.6 / 95.5 / 94.8 / 95.6 / 95.5 | 95.5 / 95.5 / 94.8 / 95.5 / 95.4 | 0.814 / 0.839 / 0.781 / 0.807 / 0.786 |
| Positive tail, $T=0.25$ | 1024 | 95.9 / 96.2 / 96.1 / 96.1 / 96.2 | 95.7 / 96.1 / 95.9 / 95.9 / 96.0 | 95.7 / 96.0 / 95.9 / 95.8 / 96.0 | 95.7 / 96.0 / 95.8 / 95.8 / 96.0 | 0.829 / 0.900 / 0.919 / 0.871 / 0.891 |
| Positive tail, $T=0.25$ | 4096 | 96.5 / 96.6 / 96.4 / 96.1 / 96.4 | 96.4 / 96.5 / 96.4 / 96.0 / 96.2 | 96.4 / 96.4 / 96.3 / 95.9 / 96.2 | 96.3 / 96.4 / 96.3 / 95.8 / 96.1 | 0.909 / 0.920 / 0.933 / 0.908 / 0.906 |
| Positive tail, $T=4$ | 64 | 95.3 / 95.9 / 95.5 / 95.2 / 95.8 | 95.0 / 95.7 / 95.3 / 95.0 / 95.5 | 94.8 / 95.5 / 95.2 / 94.9 / 95.3 | 94.7 / 95.3 / 95.1 / 94.7 / 95.2 | 0.817 / 0.807 / 0.837 / 0.805 / 0.812 |
| Positive tail, $T=4$ | 256 | 96.3 / 96.2 / 96.2 / 96.2 / 96.2 | 96.2 / 96.0 / 96.0 / 96.1 / 96.0 | 96.1 / 95.9 / 95.9 / 96.0 / 95.9 | 96.0 / 95.8 / 95.8 / 95.9 / 95.9 | 0.896 / 0.907 / 0.909 / 0.897 / 0.869 |
| Positive tail, $T=4$ | 1024 | 96.9 / 97.1 / 96.9 / 96.8 / 97.0 | 96.7 / 97.0 / 96.8 / 96.7 / 96.9 | 96.7 / 97.0 / 96.7 / 96.7 / 96.8 | 96.5 / 96.9 / 96.6 / 96.6 / 96.8 | 1.005 / 1.023 / 1.060 / 1.010 / 1.043 |
| Positive tail, $T=4$ | 4096 | 97.4 / 97.3 / 97.4 / 97.4 / 97.4 | 97.3 / 97.2 / 97.3 / 97.3 / 97.3 | 97.2 / 97.2 / 97.2 / 97.2 / 97.2 | 97.2 / 97.1 / 97.2 / 97.2 / 97.2 | 1.173 / 1.169 / 1.182 / 1.175 / 1.134 |

**Table B2.** Evidence task, every seed (11 / 23 / 37 / 53 / 71): test accuracy (%) and the one-sided exact McNemar p-value against the four-block oracle.

| Readout | Width | Test accuracy (%) | p against the four-block oracle |
|---|---:|---|---|
| Positive | 64 | 84.36 / 84.41 / 84.31 / 84.42 / 84.38 | 4.1e-81 / 4.5e-83 / 5.5e-79 / 2.0e-83 / 3.2e-82 |
| Positive | 256 | 84.41 / 84.41 / 84.30 / 84.41 / 84.39 | 9.1e-76 / 1.9e-75 / 1.3e-71 / 1.5e-75 / 8.7e-75 |
| Positive | 1024 | 84.41 / 84.39 / 84.25 / 84.36 / 84.38 | 1.5e-74 / 1.1e-73 / 3.1e-69 / 3.4e-73 / 2.1e-73 |
| Positive | 4096 | 84.38 / 84.41 / 84.25 / 84.39 / 84.41 | 1.6e-73 / 4.1e-74 / 4.4e-69 / 1.3e-73 / 4.1e-74 |
| Signed | 64 | 84.36 / 84.36 / 84.31 / 84.34 / 84.40 | 1.4e-80 / 9.1e-81 / 1.4e-79 / 9.3e-81 / 7.3e-83 |
| Signed | 256 | 84.42 / 84.38 / 84.24 / 84.39 / 84.41 | 9.4e-74 / 1.5e-72 / 2.6e-68 / 7.4e-73 / 1.4e-73 |
| Signed | 1024 | 84.38 / 84.15 / 84.25 / 84.22 / 84.23 | 1.4e-72 / 5.8e-65 / 1.6e-68 / 1.3e-67 / 3.4e-67 |
| Signed | 4096 | 83.73 / 84.30 / 84.19 / 84.05 / 84.08 | 8.4e-53 / 2.2e-71 / 6.0e-67 / 2.3e-63 / 9.6e-63 |
| Signed, zero start | 64 | 84.44 / 84.41 / 84.38 / 84.38 / 84.42 | 2.4e-84 / 5.2e-83 / 5.2e-82 / 3.2e-82 / 1.0e-83 |
| Signed, zero start | 256 | 84.44 / 84.44 / 84.29 / 84.45 / 84.42 | 1.1e-74 / 2.8e-74 / 9.4e-70 / 1.0e-74 / 5.3e-74 |
| Signed, zero start | 1024 | 84.38 / 84.13 / 84.25 / 84.14 / 84.20 | 2.0e-72 / 1.2e-64 / 7.9e-69 / 1.9e-65 / 1.2e-66 |
| Signed, zero start | 4096 | 83.70 / 84.30 / 84.20 / 84.04 / 84.10 | 4.9e-52 / 1.5e-71 / 2.2e-67 / 4.9e-63 / 3.1e-63 |

**Table B3.** Distribution of the decision margin on the test set: quantiles 10%, 25%, 50%, 75% and 90% over all test images, each averaged over five seeds. Positive models are in units of $\log y$ (before the logit factor), signed models in logit units. The readout radius of a positive model is half its margin.

| Family | Width | 10% | 25% | 50% | 75% | 90% |
|---|---:|---:|---:|---:|---:|---:|
| Positive readout | 64 | 0.520 | 0.762 | 0.895 | 1.014 | 1.175 |
| Positive readout | 256 | 0.659 | 0.899 | 1.069 | 1.256 | 1.425 |
| Positive readout | 1024 | 0.764 | 1.040 | 1.242 | 1.403 | 1.533 |
| Positive readout | 4096 | 0.826 | 1.155 | 1.363 | 1.517 | 1.646 |
| Positive readout, robust margin | 64 | 0.510 | 0.758 | 0.892 | 1.017 | 1.154 |
| Positive readout, robust margin | 256 | 0.662 | 0.900 | 1.067 | 1.255 | 1.414 |
| Positive readout, robust margin | 1024 | 0.744 | 1.034 | 1.223 | 1.395 | 1.542 |
| Positive readout, robust margin | 4096 | 0.803 | 1.124 | 1.338 | 1.492 | 1.621 |
| Signed readout | 64 | 3.23 | 5.56 | 7.75 | 9.50 | 10.92 |
| Signed readout | 256 | 4.98 | 7.94 | 10.63 | 12.85 | 14.74 |
| Signed readout | 1024 | 6.34 | 9.89 | 13.04 | 15.74 | 18.23 |
| Signed readout | 4096 | 6.61 | 10.55 | 14.41 | 17.77 | 20.68 |
| Deep signed MLP | 64 | 3.32 | 5.60 | 7.65 | 9.28 | 10.65 |
| Deep signed MLP | 256 | 4.63 | 7.35 | 9.66 | 11.58 | 13.16 |
| Deep signed MLP | 1024 | 5.57 | 8.75 | 11.21 | 13.04 | 14.41 |
| Deep signed MLP | 4096 | 6.36 | 9.60 | 11.88 | 13.48 | 14.62 |
| Positive tail, $T=1$ | 64 | 0.320 | 0.557 | 0.672 | 0.764 | 0.815 |
| Positive tail, $T=1$ | 256 | 0.374 | 0.606 | 0.708 | 0.791 | 0.832 |
| Positive tail, $T=1$ | 1024 | 0.448 | 0.659 | 0.769 | 0.838 | 0.898 |
| Positive tail, $T=1$ | 4096 | 0.545 | 0.726 | 0.813 | 0.882 | 0.946 |
| Positive tail, $T=0.25$ | 64 | 0.415 | 0.657 | 0.772 | 0.843 | 0.937 |
| Positive tail, $T=0.25$ | 256 | 0.476 | 0.698 | 0.805 | 0.893 | 0.974 |
| Positive tail, $T=0.25$ | 1024 | 0.581 | 0.782 | 0.882 | 0.970 | 1.073 |
| Positive tail, $T=0.25$ | 4096 | 0.612 | 0.802 | 0.915 | 0.994 | 1.073 |
| Positive tail, $T=4$ | 64 | 0.365 | 0.646 | 0.815 | 0.922 | 1.031 |
| Positive tail, $T=4$ | 256 | 0.442 | 0.710 | 0.896 | 1.042 | 1.196 |
| Positive tail, $T=4$ | 1024 | 0.596 | 0.838 | 1.028 | 1.195 | 1.355 |
| Positive tail, $T=4$ | 4096 | 0.706 | 0.971 | 1.167 | 1.323 | 1.444 |
