#!/usr/bin/env python3
"""p1_facts.py -- print every number the P1 paper quotes, from the saved summaries."""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
S = json.load(open(os.path.join(HERE, "report", "summary.json")))
C = S["cells"]
FAMS = ["pos", "robust", "signed", "deep", "tail_T1", "tail_T0.25", "tail_T4"]
W = (64, 256, 1024, 4096)


def ci(st, k=100.0, nd=1):
    return f"{k * st['mean']:.{nd}f} [{k * st['lo']:.{nd}f}, {k * st['hi']:.{nd}f}]" if st else "-"


def m(st, k=100.0, nd=1):
    return f"{k * st['mean']:.{nd}f}" if st else "-"


print("== accuracy, readout cert@0.01, cov, released (mean [CI])")
for f in FAMS:
    for w in W:
        c = C.get(f"{f}_w{w}")
        if not c:
            continue
        print(f"{f:10s} {w:5d} n={c['n_seeds']} params {c['n_params']:>9,d}  acc {ci(c['acc'])}  ro@.01 {ci(c['ro_cert']['0.01'])}"
              f"  cov {m(c['ro_cov']['0.01'])} rel {m(c['ro_rel']['0.01'])}  ro@.1 {m(c['ro_cert']['0.1'])} ro@.2 {m(c['ro_cert']['0.2'])}"
              f"  m50 {m(c['margin_median'], 1, 3)}  r50 {m(c['r_ro_median'], 1, 3)}")
print("\n== registered radii, readout box (mean)")
for f in FAMS:
    for w in W:
        c = C.get(f"{f}_w{w}")
        if c:
            print(f"{f:10s} {w:5d} " + "  ".join(f"{r}:{m(c['ro_cert'][r])}" for r in ("0.0025", "0.005", "0.01", "0.02", "0.05", "0.1", "0.2")))
print("\n== joint tail / first layer boxes")
for f in FAMS:
    for w in W:
        c = C.get(f"{f}_w{w}")
        if not c:
            continue
        for b in ("tail", "fl"):
            if b + "_cert" in c:
                wt = c[b + "_witness"]
                inc = None
                print(f"{f:10s} {w:5d} {b:4s} exact@.01 {ci(c[b + '_cert']['0.01'])}  marg@.01 {ci(c[b + '_marg_cert']['0.01'])}"
                      f"  exact@.1 {m(c[b + '_cert']['0.1'])} marg@.1 {m(c[b + '_marg_cert']['0.1'])}"
                      f"  exact@.02 {m(c[b + '_cert']['0.02'])} marg@.02 {m(c[b + '_marg_cert']['0.02'])}"
                      f"  cov@.01 {m(c[b + '_cov']['0.01'], 100, 2)} margcov@.01 {m(c[b + '_marg_cov']['0.01'], 100, 2)}"
                      f"  r50 {m(c[f'r_{b}_median'], 1, 4)} rm50 {m(c[f'r_{b}_marg_median'], 1, 4)}  witness {wt}")
print("\n== fan-in, activity, bits, additive")
for f in FAMS:
    for w in W:
        c = C.get(f"{f}_w{w}")
        if not c:
            continue
        fi = c["fanin"]
        extra = ""
        if "bits_median_correct" in c:
            extra = (f" bits50 {c['bits_median_correct']['mean']:.1f} cert@4b {m(c['cert_bits']['4'])} @6b {m(c['cert_bits']['6'])}"
                     f" @8b {m(c['cert_bits']['8'])} span {c['logw_span']['mean']:.2f}")
        if "margin_over_max_contrast_median" in c:
            extra += f" m/maxcon {c['margin_over_max_contrast_median']['mean']:.3f}"
        if "kappa_median" in c:
            extra += f" kappa50 {c['kappa_median']['mean']:.2f}"
        print(f"{f:10s} {w:5d} fanin {fi['fanin']['mean']:.2f} g99 {fi['fanin_g99']['mean']:.2f} g95 {fi['fanin_g95']['mean']:.2f}"
              f" g90 {fi['fanin_g90']['mean']:.2f} active {c['n_active_h_mean']['mean']:.2f} eps50 {c['eps_add_median']['mean']:.3f}"
              f" add@.05 {m(c['add_cert']['0.05'])} add@.1 {m(c['add_cert']['0.1'])}{extra}")
print("\n== paired 4096 - 256")
for f, d in S["paired_256_4096"].items():
    print(f, {k: (round(100 * v["mean"], 2), round(100 * v["lo"], 2), round(100 * v["hi"], 2)) for k, v in d.items() if v})
print("\n== margin slope per doubling")
for f, st in S["margin_slope"].items():
    print(f, round(st["mean"], 4), round(st["lo"], 4), round(st["hi"], 4))
print("\n== logit-scale ablation (width 1024, seeds 11/23/37)")
for c_, d in S.get("logit_scale_ablation", {}).items():
    print(f"c={c_:>2s} acc {m(d['acc'])} [{100*d['acc']['lo']:.1f},{100*d['acc']['hi']:.1f}] m50 {d['margin_median']['mean']:.3f} c*m50 {d['c_times_margin_median']['mean']:.2f}"
          f" ro@.01 {m(d['ro_cert']['0.01'])} @.1 {m(d['ro_cert']['0.1'])} @.2 {m(d['ro_cert']['0.2'])} fl@.01 {m(d['fl_cert_0.01'])}"
          f" fanin {d['fanin']['mean']:.2f} r_fl50 {d['r_fl_median']['mean']:.3f}")
print("\n== verdicts")
print(json.dumps(S["verdicts"], indent=1))
for name in ("explore/summary.json", "report/latency.json"):
    p = os.path.join(HERE, name)
    if os.path.exists(p):
        print(f"\n== {name}")
        print(json.dumps(json.load(open(p)), indent=0)[:6000])
