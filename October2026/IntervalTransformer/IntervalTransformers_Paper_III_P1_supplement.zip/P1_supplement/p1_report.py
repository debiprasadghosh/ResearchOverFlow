#!/usr/bin/env python3
"""
p1_report.py -- seed-level statistics, registered verdicts, tables and figures for P1.

    python3 p1_report.py            reads evals/test/*.npz and evidence/summary.json,
                                    writes report/summary.json, report/tables.md, figures/*.png
"""
import json
import os

import numpy as np
from scipy.stats import t as student_t

import p1_eval as E

HERE = os.path.dirname(os.path.abspath(__file__))
EV = os.path.join(HERE, "evals", "test")
REP = os.path.join(HERE, "report")
FIG = os.path.join(HERE, "figures")
os.makedirs(REP, exist_ok=True)
os.makedirs(FIG, exist_ok=True)

FAMS = ["pos", "robust", "signed", "deep", "tail_T1", "tail_T0.25", "tail_T4"]
LABEL = {"pos": "positive readout", "robust": "positive readout + robust margin", "signed": "signed readout",
         "deep": "deep signed MLP", "tail_T1": "positive tail T = 1", "tail_T0.25": "positive tail T = 0.25",
         "tail_T4": "positive tail T = 4"}
WIDTHS = (64, 256, 1024, 4096)
SEEDS = (11, 23, 37, 53, 71)
RHOS = E.ALL_RHOS
EPS_ADD = (0.01, 0.02, 0.05, 0.1)


def cert_stats(correct, released):
    return {"cert_acc": float(np.mean(correct & released)), "coverage": float(np.mean(released)),
            "acc_released": float(np.mean(correct[released])) if released.any() else float("nan")}


def run_summary(a, s, meta):
    cor = a["correct"].astype(bool)
    out = {"acc": float(cor.mean()), "val_acc": meta["val_acc"], "train_seconds": meta["train_seconds"],
           "n_params": s["n_params"], "macs": s["macs"],
           "us_nominal": 1e6 * s["t_nominal_f32_s"] / s["n_eval"], "zero_params": s["zero_params"]}
    m = a["margin"].astype(float)
    out["margin_q"] = [float(np.quantile(m, q)) for q in E_Q]
    out["margin_q_correct"] = [float(np.quantile(m[cor], q)) for q in E_Q]
    out["ro"] = {f"{r:g}": cert_stats(cor, a["r_ro"] > r) for r in RHOS}
    out["r_ro_q"] = [float(np.quantile(a["r_ro"], q)) for q in E_Q]
    out["ro_witness"] = s["ro_witness"]
    if "kappa" in a:
        k = a["kappa"][np.isfinite(a["kappa"])]
        out["kappa_median"] = float(np.median(k))
    for box in ("tail", "fl"):
        if f"cert_{box}_{RHOS[0]:g}" in a:
            out[box] = {f"{r:g}": cert_stats(cor, a[f"cert_{box}_{r:g}"].astype(bool)) for r in RHOS}
            out[box + "_marg"] = {f"{r:g}": cert_stats(cor, a[f"cert_{box}_marg_{r:g}"].astype(bool)) for r in RHOS}
            out[f"r_{box}_q"] = [float(np.quantile(a[f"r_{box}"], q)) for q in E_Q]
            out[f"r_{box}_marg_q"] = [float(np.quantile(a[f"r_{box}_marg"], q)) for q in E_Q]
            out[box + "_witness"] = s[box + "_witness"]
            key = "t_tail_exact_s" if box == "tail" else "t_fl_exact_s"
            out[f"us_{box}_exact"] = 1e6 * s[key] / s["n_eval"]
            out[f"us_{box}_marg"] = 1e6 * s[key.replace("exact", "marg")] / s["n_eval"]
    out["fanin_median"] = {k: float(np.median(a[k])) for k in ("fanin", "fanin_g99", "fanin_g95", "fanin_g90")}
    out["n_groups"] = s["n_groups"]
    out["n_active_h_mean"] = float(np.mean(a["n_active_h"]))
    out["n_active_h_median"] = float(np.median(a["n_active_h"]))
    if "bits_need" in a:
        b = a["bits_need"][cor]
        out["bits_median_correct"] = float(np.median(b))
        out["bits_le16_correct"] = float(np.mean(b <= 16))
        out["cert_bits"] = {str(nb): float(np.mean(a[f"cert_bits_{nb}"].astype(bool) & cor)) for nb in (4, 6, 8, 10, 12)}
        out["logw_span"] = s.get("logw_span")
    out["eps_add_median"] = float(np.median(a["eps_add"]))
    out["add"] = {f"{e:g}": cert_stats(cor, a["eps_add"] > e) for e in EPS_ADD}
    if "mediant_bound_holds" in s:
        out["mediant_bound_holds"] = s["mediant_bound_holds"]
    if "max_contrast" in a:
        ok = a["max_contrast"] > 0
        out["margin_over_max_contrast_median"] = float(np.median(m[ok] / a["max_contrast"][ok]))
    return out


E_Q = (0.1, 0.25, 0.5, 0.75, 0.9)


def tci(v):
    v = np.asarray(v, float)
    mean = float(v.mean())
    if len(v) < 2:
        return {"mean": mean, "lo": float("nan"), "hi": float("nan"), "seeds": v.tolist()}
    h = student_t.ppf(0.975, len(v) - 1) * v.std(ddof=1) / np.sqrt(len(v))
    return {"mean": mean, "lo": mean - h, "hi": mean + h, "seeds": v.tolist()}


def get(d, path):
    for p in path:
        d = d[p]
    return d


def collect():
    runs = {}
    for f in sorted(os.listdir(EV)):
        a, s, meta = E.load_eval(os.path.join(EV, f))
        runs[(meta["tag"], meta["width"], meta["seed"])] = run_summary(a, s, meta)
    return runs


def stat(runs, fam, w, path, seeds=SEEDS):
    vals = [get(runs[(fam, w, s)], path) for s in seeds if (fam, w, s) in runs]
    return tci(vals) if vals else None


def paired(runs, fam, path, w0=256, w1=4096):
    vals = [get(runs[(fam, w1, s)], path) - get(runs[(fam, w0, s)], path)
            for s in SEEDS if (fam, w0, s) in runs and (fam, w1, s) in runs]
    return tci(vals) if vals else None


def pct(x):
    return f"{100 * x:.1f}"


def fmt_ci(st, scale=100.0, nd=1):
    if st is None:
        return "–"
    return f"{scale * st['mean']:.{nd}f} [{scale * st['lo']:.{nd}f}, {scale * st['hi']:.{nd}f}]"


def main():
    runs = collect()
    have = sorted({(k[0], k[1]) for k in runs})
    S = {"n_runs": len(runs), "cells": {}}
    for fam, w in have:
        cell = {}
        cell["acc"] = stat(runs, fam, w, ("acc",))
        cell["val_acc"] = stat(runs, fam, w, ("val_acc",))
        cell["ro_cert"] = {f"{r:g}": stat(runs, fam, w, ("ro", f"{r:g}", "cert_acc")) for r in RHOS}
        cell["ro_cov"] = {f"{r:g}": stat(runs, fam, w, ("ro", f"{r:g}", "coverage")) for r in RHOS}
        cell["ro_rel"] = {f"{r:g}": stat(runs, fam, w, ("ro", f"{r:g}", "acc_released")) for r in RHOS}
        cell["margin_median"] = stat(runs, fam, w, ("margin_q", 2))
        cell["margin_quantiles"] = {f"{q:g}": stat(runs, fam, w, ("margin_q", i)) for i, q in enumerate(E_Q)}
        cell["margin_quantiles_correct"] = {f"{q:g}": stat(runs, fam, w, ("margin_q_correct", i)) for i, q in enumerate(E_Q)}
        cell["r_ro_median"] = stat(runs, fam, w, ("r_ro_q", 2))
        cell["fanin"] = {k: stat(runs, fam, w, ("fanin_median", k)) for k in ("fanin", "fanin_g99", "fanin_g95", "fanin_g90")}
        cell["n_active_h_mean"] = stat(runs, fam, w, ("n_active_h_mean",))
        cell["eps_add_median"] = stat(runs, fam, w, ("eps_add_median",))
        cell["add_cert"] = {f"{e:g}": stat(runs, fam, w, ("add", f"{e:g}", "cert_acc")) for e in EPS_ADD}
        cell["us_nominal"] = stat(runs, fam, w, ("us_nominal",))
        cell["train_seconds"] = stat(runs, fam, w, ("train_seconds",))
        any_run = next(runs[(fam, w, s)] for s in SEEDS if (fam, w, s) in runs)
        cell["n_params"], cell["macs"] = any_run["n_params"], any_run["macs"]
        for box in ("tail", "fl"):
            if box in any_run:
                cell[box + "_cert"] = {f"{r:g}": stat(runs, fam, w, (box, f"{r:g}", "cert_acc")) for r in RHOS}
                cell[box + "_cov"] = {f"{r:g}": stat(runs, fam, w, (box, f"{r:g}", "coverage")) for r in RHOS}
                cell[box + "_rel"] = {f"{r:g}": stat(runs, fam, w, (box, f"{r:g}", "acc_released")) for r in RHOS}
                cell[box + "_marg_cert"] = {f"{r:g}": stat(runs, fam, w, (box + "_marg", f"{r:g}", "cert_acc")) for r in RHOS}
                cell[box + "_marg_cov"] = {f"{r:g}": stat(runs, fam, w, (box + "_marg", f"{r:g}", "coverage")) for r in RHOS}
                cell[f"r_{box}_median"] = stat(runs, fam, w, (f"r_{box}_q", 2))
                cell[f"r_{box}_marg_median"] = stat(runs, fam, w, (f"r_{box}_marg_q", 2))
                cell[f"us_{box}_exact"] = stat(runs, fam, w, (f"us_{box}_exact",))
                cell[f"us_{box}_marg"] = stat(runs, fam, w, (f"us_{box}_marg",))
                wit = [runs[(fam, w, s)][box + "_witness"] for s in SEEDS if (fam, w, s) in runs]
                cell[box + "_witness"] = {k: int(sum(x[k] for x in wit)) for k in wit[0] if k != "rho"}
        wit = [runs[(fam, w, s)]["ro_witness"] for s in SEEDS if (fam, w, s) in runs]
        cell["ro_witness"] = {k: int(sum(x[k] for x in wit)) for k in wit[0] if k != "rho"}
        if "kappa_median" in any_run:
            cell["kappa_median"] = stat(runs, fam, w, ("kappa_median",))
        if "margin_over_max_contrast_median" in any_run:
            cell["margin_over_max_contrast_median"] = stat(runs, fam, w, ("margin_over_max_contrast_median",))
        if "bits_median_correct" in any_run:
            cell["bits_median_correct"] = stat(runs, fam, w, ("bits_median_correct",))
            cell["cert_bits"] = {nb: stat(runs, fam, w, ("cert_bits", nb)) for nb in ("4", "6", "8", "10", "12")}
            cell["logw_span"] = stat(runs, fam, w, ("logw_span",))
        cell["n_seeds"] = sum((fam, w, s) in runs for s in SEEDS)
        S["cells"][f"{fam}_w{w}"] = cell
    # paired width differences and margin slopes
    S["paired_256_4096"] = {}
    for fam in FAMS:
        if not all((fam, w) in have for w in (256, 4096)):
            continue
        d = {"acc": paired(runs, fam, ("acc",)),
             "ro_cert_0.01": paired(runs, fam, ("ro", "0.01", "cert_acc"))}
        any_run = runs[next(k for k in runs if k[0] == fam)]
        for box in ("tail", "fl"):
            if box in any_run:
                d[f"{box}_cert_0.01"] = paired(runs, fam, (box, "0.01", "cert_acc"))
                d[f"{box}_marg_cert_0.01"] = paired(runs, fam, (box + "_marg", "0.01", "cert_acc"))
        S["paired_256_4096"][fam] = d
    S["margin_slope"] = {}
    for fam in FAMS:
        if not all((fam, w) in have for w in WIDTHS):
            continue
        slopes = []
        for s in SEEDS:
            if all((fam, w, s) in runs for w in WIDTHS):
                med = [runs[(fam, w, s)]["margin_q"][2] for w in WIDTHS]
                slopes.append(np.polyfit(np.log2(WIDTHS), med, 1)[0])
        S["margin_slope"][fam] = tci(slopes)
    # exploratory: training logit scale c at width 1024, seeds 11, 23, 37 (c = 8 from the confirmatory runs)
    abl = {}
    for c_, tag in ((2, "ablate_c2"), (4, "ablate_c4"), (8, "pos"), (16, "ablate_c16"), (32, "ablate_c32")):
        rs = [runs[(tag, 1024, s_)] for s_ in (11, 23, 37) if (tag, 1024, s_) in runs]
        if len(rs) == 3:
            abl[str(c_)] = {"acc": tci([r["acc"] for r in rs]),
                            "margin_median": tci([r["margin_q"][2] for r in rs]),
                            "c_times_margin_median": tci([c_ * r["margin_q"][2] for r in rs]),
                            "ro_cert": {k: tci([r["ro"][k]["cert_acc"] for r in rs]) for k in ("0.01", "0.1", "0.2")},
                            "fl_cert_0.01": tci([r["fl"]["0.01"]["cert_acc"] for r in rs]),
                            "fanin": tci([r["fanin_median"]["fanin"] for r in rs]),
                            "r_fl_median": tci([r["r_fl_q"][2] for r in rs])}
    S["logit_scale_ablation"] = abl
    # registered verdicts
    V = {}
    if "pos" in S["paired_256_4096"]:
        d = S["paired_256_4096"]["pos"]["ro_cert_0.01"]
        V["A1_cert_change_le_5pp"] = {"delta_pp": 100 * d["mean"], "ci_pp": [100 * d["lo"], 100 * d["hi"]],
                                      "pass": abs(d["mean"]) <= 0.05, "per_seed_pp": [100 * x for x in d["seeds"]]}
        V["R1_drop_gt_10pp"] = {"reject": d["mean"] < -0.10}
    gaps = {}
    for w in WIDTHS:
        if ("pos", w) in have and ("signed", w) in have:
            g = tci([runs[("pos", w, s)]["acc"] - runs[("signed", w, s)]["acc"] for s in SEEDS
                     if ("pos", w, s) in runs and ("signed", w, s) in runs])
            gaps[str(w)] = {"gap_pp": 100 * g["mean"], "ci_pp": [100 * g["lo"], 100 * g["hi"]],
                            "within_2pp": abs(g["mean"]) <= 0.02}
    V["A2_acc_within_2pp_of_signed"] = gaps
    ev_path = os.path.join(HERE, "evidence", "summary.json")
    if os.path.exists(ev_path):
        with open(ev_path) as f:
            ev = json.load(f)
        a3 = {}
        for w in WIDTHS:
            key = f"pos_w{w}"
            if key in ev:
                ps = sorted(r["p_vs_top4"] for r in ev[key]["per_seed"])
                holm = all(p <= 0.05 / (len(ps) * 4 - i) for i, p in enumerate(ps))
                a3[str(w)] = {"acc": ev[key]["acc"], "acc_minus_top4": ev[key]["acc_minus_top4"],
                              "max_p": max(ps), "all_seeds_p_lt_0.05": max(ps) < 0.05,
                              "median_fanin_block": ev[key]["median_fanin_block"]}
        V["A3_evidence_beats_top4"] = a3
    S["verdicts"] = V
    with open(os.path.join(REP, "summary.json"), "w") as f:
        json.dump(S, f, indent=1)
    write_tables(S, runs)
    figures(S, runs)
    print(json.dumps(V, indent=1))


def write_tables(S, runs):
    C = S["cells"]
    L = []
    L.append("## Accuracy and readout certificates at rho = 0.01 (mean [95% t-CI] over seeds, percent)\n")
    L.append("| family | width | params | test acc | readout cert@0.01 | cov | acc released | median log margin | median r_ro |")
    L.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|")
    for fam in FAMS:
        for w in WIDTHS:
            c = C.get(f"{fam}_w{w}")
            if not c:
                continue
            L.append(f"| {fam} | {w} | {c['n_params']:,} | {fmt_ci(c['acc'])} | {fmt_ci(c['ro_cert']['0.01'])} | "
                     f"{fmt_ci(c['ro_cov']['0.01'])} | {fmt_ci(c['ro_rel']['0.01'])} | "
                     f"{fmt_ci(c['margin_median'], 1, 3)} | {fmt_ci(c['r_ro_median'], 1, 3)} |")
    L.append("\n## Joint tail box and first-layer box at rho = 0.01 (exact; marginal)\n")
    L.append("| family | width | box | exact cert@0.01 | marginal cert@0.01 | median r exact | median r marginal | rejected / witnessed flips |")
    L.append("|---|---:|---|---:|---:|---:|---:|---:|")
    for fam in FAMS:
        for w in WIDTHS:
            c = C.get(f"{fam}_w{w}")
            if not c:
                continue
            for box in ("tail", "fl"):
                if box + "_cert" in c:
                    wt = c[box + "_witness"]
                    L.append(f"| {fam} | {w} | {box} | {fmt_ci(c[box + '_cert']['0.01'])} | "
                             f"{fmt_ci(c[box + '_marg_cert']['0.01'])} | {fmt_ci(c[f'r_{box}_median'], 1, 4)} | "
                             f"{fmt_ci(c[f'r_{box}_marg_median'], 1, 4)} | {wt['rejected']} / {wt['flipped']} of {wt['checked']} |")
    L.append("\n## Certified accuracy against rho (means, percent)\n")
    L.append("| family | width | box | " + " | ".join(f"{r:g}" for r in RHOS) + " |")
    L.append("|---|---:|---|" + "---:|" * len(RHOS))
    for fam in FAMS:
        for w in WIDTHS:
            c = C.get(f"{fam}_w{w}")
            if not c:
                continue
            for box in ("ro", "tail", "tail_marg", "fl", "fl_marg"):
                key = box + "_cert"
                if key in c:
                    L.append(f"| {fam} | {w} | {box} | " + " | ".join(pct(c[key][f'{r:g}']['mean']) for r in RHOS) + " |")
    L.append("\n## Fan-in, activity, bits, additive budget, latency (means over seeds)\n")
    L.append("| family | width | fan-in | grouped .99 | .95 | .90 | mean active h | median bits | cert@6 bits | median eps_add | add cert@0.05 | us nominal | us exact tail/fl |")
    L.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
    for fam in FAMS:
        for w in WIDTHS:
            c = C.get(f"{fam}_w{w}")
            if not c:
                continue
            fi = c["fanin"]
            bits = f"{c['bits_median_correct']['mean']:.1f}" if "bits_median_correct" in c else "–"
            cb6 = pct(c["cert_bits"]["6"]["mean"]) if "cert_bits" in c else "–"
            us_ex = (f"{c['us_tail_exact']['mean']:.1f}" if "us_tail_exact" in c else
                     (f"{c['us_fl_exact']['mean']:.1f}" if "us_fl_exact" in c else "–"))
            L.append(f"| {fam} | {w} | {fi['fanin']['mean']:.2f} | {fi['fanin_g99']['mean']:.2f} | {fi['fanin_g95']['mean']:.2f} | "
                     f"{fi['fanin_g90']['mean']:.2f} | {c['n_active_h_mean']['mean']:.2f} | {bits} | {cb6} | "
                     f"{c['eps_add_median']['mean']:.3f} | {pct(c['add_cert']['0.05']['mean'])} | "
                     f"{c['us_nominal']['mean']:.1f} | {us_ex} |")
    L.append("\n## Paired differences, width 4096 minus 256 (percentage points)\n")
    for fam, d in S["paired_256_4096"].items():
        L.append(f"- {fam}: " + "; ".join(f"{k} {fmt_ci(v)}" for k, v in d.items() if v))
    L.append("\n## Slope of the median margin against log2 width\n")
    for fam, st in S["margin_slope"].items():
        L.append(f"- {fam}: {st['mean']:.4f} [{st['lo']:.4f}, {st['hi']:.4f}] per doubling")
    with open(os.path.join(REP, "tables.md"), "w") as f:
        f.write("\n".join(L) + "\n")
    write_appendix(runs)


def write_appendix(runs):
    """Per-seed values (seeds 11, 23, 37, 53, 71) for the registered quantities."""
    L = ["| Family | Width | Test accuracy (%) | Readout certified at 0.01 (%) | Joint-tail or first-layer certified at 0.01, exact (%) | Same, marginal (%) | Median log margin |",
         "|---|---:|---|---|---|---|---|"]
    for fam in FAMS:
        for w in WIDTHS:
            rs = [runs.get((fam, w, s)) for s in SEEDS]
            if not all(rs):
                continue
            box = "tail" if "tail" in rs[0] else ("fl" if "fl" in rs[0] else None)
            j = lambda vals, nd=1: " / ".join(f"{v:.{nd}f}" for v in vals)
            acc = j([100 * r["acc"] for r in rs])
            ro = j([100 * r["ro"]["0.01"]["cert_acc"] for r in rs])
            ex = j([100 * r[box]["0.01"]["cert_acc"] for r in rs]) if box else "–"
            mg = j([100 * r[box + "_marg"]["0.01"]["cert_acc"] for r in rs]) if box else "–"
            mm = j([r["margin_q"][2] for r in rs], 3)
            L.append(f"| {fam} | {w} | {acc} | {ro} | {ex} | {mg} | {mm} |")
    with open(os.path.join(REP, "appendix_per_seed.md"), "w") as f:
        f.write("\n".join(L) + "\n")


def figures(S, runs):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return
    C = S["cells"]
    plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
    colors = {"pos": "#1f6f8b", "robust": "#7fb3c8", "signed": "#c0392b", "deep": "#e67e22",
              "tail_T1": "#2e7d32", "tail_T0.25": "#81c784", "tail_T4": "#1b5e20"}
    # Figure: certified accuracy against width, by box, at rho = 0.01 (solid) and 0.1 (dashed)
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.4), sharey=True)
    panels = [("ro_cert", "Readout box (exact)", ["pos", "robust", "signed", "deep", "tail_T1", "tail_T0.25", "tail_T4"]),
              ("tail_cert", "Joint tail box (exact)", ["deep", "tail_T1", "tail_T0.25", "tail_T4"]),
              ("fl_cert", "First-layer box (exact)", ["pos", "robust", "signed"])]
    for ax, (key, title, fams) in zip(axes, panels):
        for fam in fams:
            for rho, ls, lab in (("0.01", "-", True), ("0.1", "--", False)):
                xs, ys, lo, hi = [], [], [], []
                for w in WIDTHS:
                    c = C.get(f"{fam}_w{w}")
                    if c and key in c:
                        st = c[key][rho]
                        xs.append(w), ys.append(100 * st["mean"])
                        lo.append(100 * (st["mean"] - st["lo"])), hi.append(100 * (st["hi"] - st["mean"]))
                if xs:
                    ax.errorbar(xs, ys, yerr=[lo, hi], marker="o", ms=3.2, lw=1.3, ls=ls, capsize=1.5,
                                color=colors[fam], label=LABEL[fam] if lab else None)
        ax.set_xscale("log", base=2)
        ax.set_xticks(WIDTHS)
        ax.set_xticklabels([str(w) for w in WIDTHS])
        ax.set_xlabel("width")
        ax.set_ylim(0, 100)
        ax.set_title(title, fontsize=9)
        ax.grid(alpha=0.25)
    axes[0].set_ylabel("certified accuracy (%)\nsolid ρ = 0.01, dashed ρ = 0.1")
    handles, labels = [], []
    for ax in axes:
        for h, l in zip(*ax.get_legend_handles_labels()):
            if l not in labels:
                handles.append(h), labels.append(l)
    fig.legend(handles, labels, loc="lower center", ncol=4, frameon=False, fontsize=8, bbox_to_anchor=(0.5, -0.1))
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_cert_vs_width.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)
    # Figure: certified accuracy against rho at width 4096
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.2))
    for fam in FAMS:
        c = C.get(f"{fam}_w4096")
        if not c:
            continue
        axes[0].plot(RHOS, [100 * c["ro_cert"][f"{r:g}"]["mean"] for r in RHOS], marker="o", ms=3,
                     color=colors[fam], label=LABEL[fam])
        for box, ls in (("tail", "-"), ("fl", "--")):
            if box + "_cert" in c:
                axes[1].plot(RHOS, [100 * c[box + "_cert"][f"{r:g}"]["mean"] for r in RHOS], marker="o", ms=3, ls=ls,
                             color=colors[fam], label=f"{LABEL[fam]} ({'tail' if box == 'tail' else 'first layer'})")
    for ax, title in zip(axes, ("Readout box, width 4096", "Joint tail and first-layer boxes, width 4096")):
        ax.set_xscale("log")
        ax.axvline(0.01, color="0.6", lw=0.8, ls=":")
        ax.set_xlabel("log radius ρ")
        ax.set_title(title, fontsize=9)
        ax.grid(alpha=0.25)
        ax.legend(fontsize=6.5, frameon=False)
    axes[0].set_ylabel("certified accuracy (%)")
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_cert_vs_rho.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)
    # Figure: margins, radii and fan-in against width
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.1))
    for fam in ("pos", "signed", "tail_T1", "deep"):
        xs = [w for w in WIDTHS if f"{fam}_w{w}" in C]
        if not xs:
            continue
        axes[0].plot(xs, [C[f"{fam}_w{w}"]["r_ro_median"]["mean"] for w in xs], marker="o", ms=3, color=colors[fam],
                     label=LABEL[fam])
        axes[1].plot(xs, [C[f"{fam}_w{w}"]["fanin"]["fanin"]["mean"] for w in xs], marker="o", ms=3, color=colors[fam],
                     label=LABEL[fam])
        axes[1].plot(xs, [C[f"{fam}_w{w}"]["fanin"]["fanin_g90"]["mean"] for w in xs], marker="x", ms=3, ls=":",
                     color=colors[fam])
        if "tail_cert" in C[f"{fam}_w{xs[0]}"]:
            axes[0].plot(xs, [C[f"{fam}_w{w}"]["r_tail_median"]["mean"] for w in xs], marker="s", ms=3, ls="--",
                         color=colors[fam])
        if "fl_cert" in C[f"{fam}_w{xs[0]}"]:
            axes[2].plot(xs, [C[f"{fam}_w{w}"]["r_fl_median"]["mean"] for w in xs], marker="o", ms=3, color=colors[fam],
                         label=LABEL[fam])
            axes[2].plot(xs, [C[f"{fam}_w{w}"]["r_fl_marg_median"]["mean"] for w in xs], marker="x", ms=3, ls=":",
                         color=colors[fam])
    titles = ("Median certified radius: readout (solid), joint tail (dashed)", "Median fan-in: local (solid), grouped at 0.9 (dotted)",
              "Median first-layer radius: exact (solid), marginal (dotted)")
    for ax, ttl in zip(axes, titles):
        ax.set_xscale("log", base=2)
        ax.set_xticks(WIDTHS)
        ax.set_xticklabels([str(w) for w in WIDTHS])
        ax.set_xlabel("width")
        ax.set_title(ttl, fontsize=8)
        ax.grid(alpha=0.25)
    axes[1].set_yscale("log")
    axes[0].legend(fontsize=6.5, frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_margins_fanin.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)
    evidence_figure(plt, colors)


def evidence_figure(plt, colors):
    path = os.path.join(HERE, "evidence", "summary.json")
    if not os.path.exists(path):
        return
    with open(path) as f:
        ev = json.load(f)
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.1))
    for fam, lab in (("pos", "positive readout"), ("signed", "signed readout")):
        keys = [f"{fam}_w{w}" for w in WIDTHS if f"{fam}_w{w}" in ev]
        ws = [int(k.split("_w")[1]) for k in keys]
        for rho, ls in (("0.01", "-"), ("0.1", "--")):
            axes[0].plot(ws, [100 * ev[k]["cert_acc"][rho][0] for k in keys], ls=ls, marker="o", ms=3,
                         color=colors[fam], label=f"{lab}, ρ = {rho}")
        axes[1].plot(ws, [ev[k]["median_radius"][0] for k in keys], marker="o", ms=3, color=colors[fam], label=lab)
    acc = 100 * np.mean([ev[f"pos_w{w}"]["acc"][0] for w in WIDTHS])
    axes[0].axhline(acc, color="0.5", lw=0.8, ls=":", label="positive readout accuracy")
    keys = [f"pos_w{w}" for w in WIDTHS]
    fan = [ev[k]["median_fanin"][0] for k in keys]
    flip = [100 * ev[k]["mc_flip_rate"]["0.1"] for k in keys]
    axes[2].loglog(fan, flip, marker="o", ms=3, color=colors["pos"], label="random draws in the box, ρ = 0.1")
    ref = flip[0] * np.sqrt(fan[0] / np.array(fan))
    axes[2].loglog(fan, ref, ls=":", color="0.4", label="slope −1/2")
    for ax in axes[:2]:
        ax.set_xscale("log", base=2)
        ax.set_xticks(WIDTHS)
        ax.set_xticklabels([str(w) for w in WIDTHS])
        ax.set_xlabel("width (16 blocks × k units)")
    axes[0].set_ylabel("certified accuracy (%)")
    axes[1].set_ylabel("median certified radius")
    from matplotlib.ticker import FuncFormatter, NullFormatter
    axes[2].yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
    axes[2].yaxis.set_minor_formatter(NullFormatter())
    axes[2].set_yticks([0.2, 0.5, 1.0])
    axes[2].set_xlabel("local fan-in (median)")
    axes[2].set_ylabel("flip rate (%)")
    titles = ("Certified accuracy", "Median readout radius", "Incoherent noise averages out")
    for ax, ttl in zip(axes, titles):
        ax.set_title(ttl, fontsize=9)
        ax.grid(alpha=0.25)
        ax.legend(fontsize=6.5, frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_evidence.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
