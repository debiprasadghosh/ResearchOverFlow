# P1 supplement: Log Interval Networks for Evidence Accumulation and Certified Decisions

This folder reproduces every number in `P1_Log_Interval_Networks_Evidence_Accumulation.md`. Appendix A of the paper lists the commands.

## What is here

- **Scripts**
  - `p1lib.py`, `p1_run.py`: MNIST training.
  - `p1_eval.py`: the frozen evaluator (SHA-256 in `evals_code_sha256.txt`).
  - `p1_report.py`, `p1_facts.py`: statistics, tables, figures, and a print-out of quoted numbers.
  - `p1_evidence.py`: the evidence task.
  - `p1_explore.py`, `p1_zero_signed.py`, `p1_latency.py`: exploratory analyses.
  - `verify_p1_theory.py`: numerical checks of the propositions.
- **Frozen configurations**
  - `runs/config.json`: learning rates, the robust grid and data hashes, frozen before the confirmatory runs.
  - `runs/split_indices.npz`: the 55,000/5,000 split.
  - `evidence/config.json`: the μ pilot and learning rates.
- **Results**
  - MNIST: `report/summary.json`, `report/tables.md`, `report/appendix_per_seed.md`, `report/latency.json`, `report/subnormal.json`.
  - Evidence task: `evidence/summary.json`. The earlier evaluation is in `evidence/summary_v1.json`.
  - Exploratory: `explore/*.json`.
  - Checks and quoted numbers: `verify_p1_theory_output.txt`, `facts_output.txt`.
- **Logs** of every stage: `logs/`.
- **Figures**: `figures/`, as used in the paper.

## Not included

- **MNIST.** Place the four IDX files (`train-images-idx3-ubyte.gz`, `train-labels-idx1-ubyte.gz`, `t10k-images-idx3-ubyte.gz`, `t10k-labels-idx1-ubyte.gz`) in `data/`. `p1lib.load_mnist()` checks their MD5 sums:

  | File | MD5 |
  |---|---|
  | train images | `f68b3c2dcbeaaa9fbdd348bbdeb94873` |
  | train labels | `d53e105ee54ea40749a09fcbcd1e9432` |
  | test images | `9fb629c4189551a2d022fa330f9573f3` |
  | test labels | `ec29112dd5afa0611ce80d1b7f02629c` |

- **Trained parameters and per-example evaluation arrays.** They total several hundred MB. They are regenerated deterministically by the scripts; numerical results can differ in the last digits across BLAS builds and thread counts.

## Requirements

Python 3.11, NumPy, SciPy and Matplotlib. Everything runs on a CPU. On two cores, training and evaluation take about six hours; the theory checks take about ten seconds.
