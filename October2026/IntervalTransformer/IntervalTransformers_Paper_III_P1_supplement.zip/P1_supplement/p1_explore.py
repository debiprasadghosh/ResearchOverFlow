#!/usr/bin/env python3
"""
p1_explore.py -- exploratory analyses for P1 (not part of the registered protocol).

    python3 p1_explore.py truncate     top-K feature truncation of the readouts (test split)
    python3 p1_explore.py refit        signed readout refitted on frozen positive features (B')
    python3 p1_explore.py report       explore/summary.json

truncate: keep only the K most active first-layer features of each example (the
same set for every class) and recompute the readout's decision; reports accuracy
and agreement with the full model. A readout that selects keeps its accuracy at
small K; one that accumulates needs many features.
refit: for the positive-readout runs, train a signed readout (V, d) on the frozen
features h with the signed family's frozen learning rate, batch 256, 20 epochs, on
the training split only, then compare test accuracy with the positive readout.
"""
import json
import os
import sys
import time

import numpy as np

import p1lib as L

HERE = os.path.dirname(os.path.abspath(__file__))
RUNS = os.path.join(HERE, "runs")
OUT = os.path.join(HERE, "explore")
os.makedirs(OUT, exist_ok=True)
WIDTHS = (64, 256, 1024, 4096)
SEEDS = (11, 23, 37, 53, 71)
KS = (1, 2, 4, 8, 16, 32, 64)
STANDARDIZE = os.environ.get("P1_REFIT_RAW") != "1"
NORM = os.environ.get("P1_REFIT_NORM", "")


def feats(p, X, chunk=2000):
    F, b = p["F"].astype(np.float32), p["b"].astype(np.float32)
    return np.concatenate([L.sigmoid(X[i:i + chunk] @ F.T + b) for i in range(0, len(X), chunk)])


def truncate():
    D = L.load_mnist()
    X, y = D["Xte"], D["yte"]
    out_path = os.path.join(OUT, "truncate.json")
    res = json.load(open(out_path)) if os.path.exists(out_path) else {}
    for fam in ("pos", "signed"):
        for w in WIDTHS:
            for s in SEEDS:
                path = os.path.join(RUNS, f"{fam}_w{w}_s{s}.npz")
                if not os.path.exists(path) or f"{fam}_w{w}_s{s}" in res:
                    continue
                p, meta = L.load_params(path)
                H = feats(p, X).astype(np.float64)
                if fam == "pos":
                    W = np.exp(p["Th"].astype(np.float64))
                    full = (H @ W.T).argmax(1)
                else:
                    W, d = p["V"].astype(np.float64), p["d"].astype(np.float64)
                    full = (H @ W.T + d).argmax(1)
                order = np.argsort(-H, 1)
                rec = {"acc_full": float(np.mean(full == y)),
                       "frac_h_below_1e-3": float(np.mean(H < 1e-3)),
                       "median_max_h": float(np.median(H.max(1))),
                       "mean_sum_h": float(np.mean(H.sum(1))),
                       "median_h": float(np.median(H))}
                for K in KS:
                    if K >= w:
                        continue
                    mask = np.zeros_like(H, bool)
                    np.put_along_axis(mask, order[:, :K], True, 1)
                    Hk = np.where(mask, H, 0.0)
                    pred = (Hk @ W.T).argmax(1) if fam == "pos" else (Hk @ W.T + d).argmax(1)
                    rec[f"acc_top{K}"] = float(np.mean(pred == y))
                    rec[f"agree_top{K}"] = float(np.mean(pred == full))
                res[f"{fam}_w{w}_s{s}"] = rec
                with open(out_path, "w") as f:
                    json.dump(res, f, indent=1)
                print(f"  {fam:6s} w={w:5d} s={s}: full {rec['acc_full']:.4f}  " +
                      "  ".join(f"K{K} {rec.get(f'acc_top{K}', float('nan')):.3f}" for K in KS), flush=True)
    with open(os.path.join(OUT, "truncate.json"), "w") as f:
        json.dump(res, f, indent=1)


def refit(widths=WIDTHS):
    with open(os.path.join(RUNS, "config.json")) as f:
        cfg = json.load(f)
    lr = cfg["lr"]["signed"]
    D = L.load_mnist()
    res = {}
    path_out = os.path.join(OUT, ("refit_l1std.json" if NORM == "l1" else "refit_std.json") if STANDARDIZE
                            else "refit.json")
    if os.path.exists(path_out):
        with open(path_out) as f:
            res = json.load(f)
    widths = tuple(int(x) for x in os.environ.get("P1_REFIT_WIDTHS", "64,256,1024,4096").split(","))
    for w in widths:
        for s in SEEDS:
            key = f"pos_w{w}_s{s}"
            if key in res:
                continue
            p, meta = L.load_params(os.path.join(RUNS, key + ".npz"))
            t0 = time.time()
            Htr = feats(p, D["Xtr"])
            Hte = feats(p, D["Xte"])
            acc_pos_raw = float(np.mean((Hte @ np.exp(p["Th"]).T).argmax(1) == D["yte"]))
            if NORM == "l1":
                # per-example normalisation h / sum(h): the scale invariance of the positive logits
                for H_ in (Htr, Hte):
                    for i in range(0, len(H_), 5000):
                        H_[i:i + 5000] /= H_[i:i + 5000].sum(1, keepdims=True)
            if STANDARDIZE:
                # the positive readout is scale-free in h; a signed readout is not, so give it
                # features standardised on the training split (an affine reparametrisation)
                s1 = np.zeros(w)
                s2 = np.zeros(w)
                for i in range(0, len(Htr), 5000):
                    blk = Htr[i:i + 5000].astype(np.float64)
                    s1 += blk.sum(0)
                    s2 += (blk * blk).sum(0)
                mu = s1 / len(Htr)
                sd = np.sqrt(np.maximum(s2 / len(Htr) - mu * mu, 0.0)) + 1e-12
                mu32, sd32 = mu.astype(np.float32), sd.astype(np.float32)
                for H_ in (Htr, Hte):
                    for i in range(0, len(H_), 5000):
                        H_[i:i + 5000] -= mu32
                        H_[i:i + 5000] /= sd32
            rng = np.random.default_rng(s)
            model = {"V": rng.normal(0, 1.0 / np.sqrt(w), (10, w)).astype(np.float32), "d": np.zeros(10, np.float32)}
            opt = L.Adam(model, lr)
            r2 = np.random.default_rng(20_000 + s)
            for ep in range(20):
                perm = r2.permutation(len(Htr))
                for i in range(0, len(perm), 256):
                    idx = perm[i:i + 256]
                    Lg = Htr[idx] @ model["V"].T + model["d"]
                    _, dL = L.ce_and_grad(Lg, D["ytr"][idx])
                    opt.step(model, {"V": dL.T @ Htr[idx], "d": dL.sum(0)})
            acc_signed = float(np.mean((Hte @ model["V"].T + model["d"]).argmax(1) == D["yte"]))
            acc_pos = acc_pos_raw
            res[key] = {"acc_pos_readout": acc_pos, "acc_signed_refit": acc_signed, "seconds": time.time() - t0}
            print(f"  w={w:5d} s={s}: positive readout {acc_pos:.4f}  signed refit {acc_signed:.4f}", flush=True)
            with open(path_out, "w") as f:
                json.dump(res, f, indent=1)


def report():
    out = {}
    tr = json.load(open(os.path.join(OUT, "truncate.json"))) if os.path.exists(os.path.join(OUT, "truncate.json")) else {}
    rf = json.load(open(os.path.join(OUT, "refit.json"))) if os.path.exists(os.path.join(OUT, "refit.json")) else {}
    for fam in ("pos", "signed"):
        for w in WIDTHS:
            recs = [tr[f"{fam}_w{w}_s{s}"] for s in SEEDS if f"{fam}_w{w}_s{s}" in tr]
            if recs:
                out[f"truncate_{fam}_w{w}"] = {k: float(np.mean([r[k] for r in recs])) for k in recs[0]}
    for name in ("refit_l1std", "refit_std"):
      rs = json.load(open(os.path.join(OUT, name + ".json"))) if os.path.exists(os.path.join(OUT, name + ".json")) else {}
      for w in WIDTHS:
        recs = [rs[f"pos_w{w}_s{s}"] for s in SEEDS if f"pos_w{w}_s{s}" in rs]
        if recs:
            d = np.array([r["acc_signed_refit"] - r["acc_pos_readout"] for r in recs])
            out[f"{name}_w{w}"] = {"acc_pos_readout": float(np.mean([r["acc_pos_readout"] for r in recs])),
                                      "acc_signed_refit": float(np.mean([r["acc_signed_refit"] for r in recs])),
                                      "diff_mean": float(d.mean()), "diff_min": float(d.min()), "diff_max": float(d.max()),
                                      "n": len(recs)}
    for w in WIDTHS:
        recs = [rf[f"pos_w{w}_s{s}"] for s in SEEDS if f"pos_w{w}_s{s}" in rf]
        if recs:
            d = np.array([r["acc_signed_refit"] - r["acc_pos_readout"] for r in recs])
            out[f"refit_w{w}"] = {"acc_pos_readout": float(np.mean([r["acc_pos_readout"] for r in recs])),
                                  "acc_signed_refit": float(np.mean([r["acc_signed_refit"] for r in recs])),
                                  "diff_mean": float(d.mean()), "diff_min": float(d.min()), "diff_max": float(d.max()),
                                  "n": len(recs)}
    with open(os.path.join(OUT, "summary.json"), "w") as f:
        json.dump(out, f, indent=1)
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    {"truncate": truncate, "refit": refit, "report": report}[sys.argv[1]]()
