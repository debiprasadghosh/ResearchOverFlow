#!/usr/bin/env python3
"""
p1_eval.py -- exact certificates and measurements for trained P1 runs.

    python3 p1_eval.py SPLIT [PREFIX ...]      SPLIT = val | test

For every run in runs/ whose file name starts with one of the prefixes (default:
all confirmatory and ablation runs), writes evals/<SPLIT>/<run>.npz with
per-example arrays plus a JSON block of scalars. Seed statistics and verdicts are
computed by p1_report.py. The evaluation code was developed on pilot models with
the validation split; the test split is read only by the frozen version, whose
SHA-256 is stored in every output.

Conventions
-----------
Certificates use float64 arithmetic on the stored float32 parameters. A box of log
radius rho multiplies each parameter of the named set by a factor in
[e^-rho, e^rho]: positive weights stored as logs move by +-rho in the log; signed
weights and biases keep their sign (sign-preserving multiplicative box). A bias is
a weight on a constant input equal to 1. Exactly zero parameters would stay zero;
their number is recorded (it is zero for every trained model).

Tests and their semantic tags
  readout box      Theta (positive) or (V, d) (signed); features fixed.
                   [exact]  positive r = m/2;  signed r = min_j 0.5 log(A_j / B_j)
  tail box         (Psi, Theta) of the positive tail, or (G, e, V, d) of the deep
                   signed control; first-layer features fixed.
                   [exact]  pairwise solve on the hidden box (threshold or linear)
                   [sound]  marginal endpoint test, Equation 5
  first-layer box  (F, b) at the point input; readout fixed.
                   [exact]  pairwise solve on the feature box; [sound] marginal test
Each hidden unit has its own parameter row, so the hidden box is exact and
Cartesian. A winner is certified iff it beats every competitor over the box, so the
pairwise solves are necessary and sufficient. Every exact rejection at rho = 0.01
is checked by building the minimizing parameter vertex and running the network.
"""
import hashlib
import json
import os
import sys
import time

import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components

import p1lib as L

HERE = os.path.dirname(os.path.abspath(__file__))
RUNS = os.path.join(HERE, "runs")
EVALS = os.path.join(HERE, "evals")
REG_RHOS = (0.0025, 0.005, 0.01, 0.02)          # registered radii
EXPL_RHOS = (0.05, 0.1, 0.2)                    # exploratory radii
ALL_RHOS = REG_RHOS + EXPL_RHOS
PRIMARY = 0.01
GROUP_T = (0.99, 0.95, 0.9)                     # correlation thresholds for grouped fan-in
BITS = tuple(range(2, 17))
CHUNK = 1000
MAX_WITNESS = 400
COMP = np.array([[j for j in range(10) if j != c] for c in range(10)])
CODE_SHA = hashlib.sha256(open(os.path.abspath(__file__), "rb").read()).hexdigest()


def sig(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -700.0, 700.0)))


def softplus(z):
    return np.logaddexp(0.0, z)


def col(r):
    return np.asarray(r, float)[:, None]


def pos_neg(X, W, bias):
    """Positive and negative parts of the contributions to W x + bias for x >= 0."""
    return (X @ np.maximum(W, 0).T + np.maximum(bias, 0),
            X @ np.maximum(-W, 0).T + np.maximum(-bias, 0))


def preact_box(P, N, rho):
    """Exact range of P - N when every contributing weight is scaled by [e^-rho, e^rho]."""
    r = col(rho)
    return P * np.exp(-r) - N * np.exp(r), P * np.exp(r) - N * np.exp(-r)


def signed_vertex(W, rho, up):
    """Sign-preserving multiplicative vertex: up=True raises every entry's contribution
    to a nonnegative input (W e^{rho sgn W}); up=False lowers it."""
    s = np.sign(W) if up else -np.sign(W)
    return W * np.exp(rho * s)


def chunked(fn, rho, rows, chunk=CHUNK):
    out = [fn(rho[i:i + chunk], rows[i:i + chunk]) for i in range(0, len(rows), chunk)]
    return np.concatenate(out) if out else np.zeros(0, bool)


def bisect(test, lo, hi, steps):
    """Per-row largest rho with test true, by bisection in log rho. test(rho, rows) -> bool.
    Rows failing at lo get radius 0; rows passing at hi get radius hi (censored)."""
    n = len(lo)
    rows = np.arange(n)
    lo, hi = lo.astype(float).copy(), hi.astype(float).copy()
    ok_lo, ok_hi = test(lo, rows), test(hi, rows)
    act = ok_lo & ~ok_hi
    for _ in range(steps):
        idx = np.where(act)[0]
        if not len(idx):
            break
        mid = np.sqrt(lo[idx] * hi[idx])
        ok = test(mid, idx)
        lo[idx[ok]] = mid[ok]
        hi[idx[~ok]] = mid[~ok]
    return np.where(ok_hi, hi, np.where(ok_lo, lo, 0.0)), ok_hi


def participation(p):
    return 1.0 / np.sum(p * p, 1)


# ---------------------------------------------------------------------------
# exact threshold solve for a ratio of positive linear forms
# ---------------------------------------------------------------------------
class PairKM:
    """min over z in [zl, zu] of (a_c . z) / (a_j . z) for positive readout rows a.
    The minimizing vertex sets z at its upper end exactly on the coordinates with the
    smallest ratios a_c,k / a_j,k (threshold structure); the order depends only on
    the class pair, so it is sorted once."""

    def __init__(self, A):
        self.A = A
        n = A.shape[1]
        self.order = np.zeros((10, 10, n), np.int64)
        self.g = np.ones((10, 10, n))
        self.h = np.ones((10, 10, n))
        for c in range(10):
            for j in range(10):
                if j != c:
                    o = np.argsort(A[c] / A[j], kind="stable")
                    self.order[c, j], self.g[c, j], self.h[c, j] = o, A[c, o], A[j, o]

    def min_ratio(self, c, j, zl, zu):
        idx = self.order[c, j]
        zls, zus = np.take_along_axis(zl, idx, 1), np.take_along_axis(zu, idx, 1)
        g, h = self.g[c, j], self.h[c, j]
        B = len(c)
        z0 = np.zeros((B, 1))
        gu = np.concatenate([z0, np.cumsum(g * zus, 1)], 1)
        gl = np.concatenate([z0, np.cumsum(g * zls, 1)], 1)
        hu = np.concatenate([z0, np.cumsum(h * zus, 1)], 1)
        hl = np.concatenate([z0, np.cumsum(h * zls, 1)], 1)
        ratio = (gu + gl[:, -1:] - gl) / (hu + hl[:, -1:] - hl)
        t = ratio.argmin(1)
        return ratio[np.arange(B), t], t, idx


def km_tests(km, c, zl, zu, scale, witness=False):
    """Exact (threshold) and marginal tests that class c beats every competitor when the
    hidden vector ranges over [zl, zu] and the readout rows are boxed so that the ratio
    is multiplied by `scale` = exp(-2 rho) (scale 1: readout fixed)."""
    A = km.A
    B = len(c)
    r = np.arange(B)
    scale = np.broadcast_to(np.asarray(scale, float), (B,))
    YU = zu @ A.T
    lo = scale * (zl @ A.T)[r, c]
    exact, marg = np.ones(B, bool), np.ones(B, bool)
    wit = {}
    for s in range(9):
        j = COMP[c, s]
        screen = lo > YU[r, j]                   # pair passes the marginal comparison
        marg &= screen
        need = np.where(exact & ~screen)[0]
        if len(need):
            mr, t, idx = km.min_ratio(c[need], j[need], zl[need], zu[need])
            fail = ~(scale[need] * mr > 1.0)
            exact[need[fail]] = False
            if witness:
                for k in np.where(fail)[0]:
                    wit.setdefault(int(need[k]), (int(j[need[k]]), int(t[k]), idx[k]))
    return exact, marg, wit


def linear_pair_tests(D_fn, c, gl, gu, dd_fn):
    """Exact pairwise test for signed readouts on a hidden box: min over g in [gl, gu] of
    D . g + dd > 0 for every competitor; D_fn(j) -> (B, n) coefficients, dd_fn(j) -> (B,)."""
    B = len(c)
    ok = np.ones(B, bool)
    for s in range(9):
        j = COMP[c, s]
        D = D_fn(j)
        val = np.where(D > 0, D * gl, D * gu).sum(1) + dd_fn(j)
        ok &= val > 0
    return ok


# ---------------------------------------------------------------------------
# shared measurements
# ---------------------------------------------------------------------------
def feature_groups(Fv):
    """Single-linkage groups of readout input features whose validation activations
    correlate at >= t; features constant on the validation split form one group."""
    sd = Fv.std(0)
    const = sd < 1e-9
    Zs = (Fv - Fv.mean(0)) / np.where(const, 1.0, sd)
    C = (Zs.T @ Zs) / len(Fv)
    labels = {}
    for t in GROUP_T:
        adj = C >= t
        adj[const, :] = False
        adj[:, const] = False
        _, lab = connected_components(csr_matrix(adj), directed=False)
        if const.any():
            lab = lab.copy()
            lab[const] = lab.max() + 1
        _, lab = np.unique(lab, return_inverse=True)
        labels[t] = lab
    return labels, int(const.sum())


def grouped_participation(p, lab, chunk=2000):
    """n_group = 1 / sum_G P_G^2 with P_G the summed participation of group G."""
    G = lab.max() + 1
    M = csr_matrix((np.ones(len(lab)), (np.arange(len(lab)), lab)), shape=(len(lab), G))
    out = []
    for i in range(0, len(p), chunk):
        P = np.asarray(M.T @ p[i:i + chunk].T).T
        out.append(1.0 / np.sum(P * P, 1))
    return np.concatenate(out)


def fanin_block(p, groups):
    out = {"fanin": participation(p).astype(np.float32)}
    for t, lab in groups.items():
        out[f"fanin_g{int(round(t * 100))}"] = grouped_participation(p, lab).astype(np.float32)
    return out


def certs_from_radius(radius, rhos=ALL_RHOS):
    return {rho: radius > rho for rho in rhos}


def readout_bits(Z, Th, c):
    """Positive readout log weights stored on a b-bit uniform grid over their span S
    (step D = S / (2^b - 1)); the stored decision is certified to equal the original one
    iff the stored log margin exceeds D (exact one-layer criterion, Paper II 6.3)."""
    lmin, S = Th.min(), Th.max() - Th.min()
    cert = {}
    for nb in BITS:
        D = S / (2 ** nb - 1)
        q = lmin + np.round((Th - lmin) / D) * D
        lq = np.log(Z @ np.exp(q).T)
        s = np.sort(lq, 1)
        cert[nb] = (lq.argmax(1) == c) & (s[:, -1] - s[:, -2] > D)
    need = np.full(len(c), 17, np.int16)
    allok = np.ones(len(c), bool)
    for nb in reversed(BITS):
        allok &= cert[nb]
        need = np.where(allok, nb, need)
    return need, {nb: cert[nb] for nb in BITS}


def additive_positive(Z, A, c):
    """Additive budget on positive readout weights: a -> [max(a - eps s, 0), a + eps s],
    s = RMS(a). Rows independent, features fixed: Equation 5 is exact here."""
    s = np.sqrt(np.mean(A * A))
    zsum = Z.sum(1)
    Y = Z @ A.T
    B = len(c)

    def test(eps, rows):
        lo = np.einsum("bi,bi->b", np.maximum(A[c[rows]] - col(eps) * s, 0.0), Z[rows])
        hi = Y[rows] + col(eps * s * zsum[rows])
        hi[np.arange(len(rows)), c[rows]] = -np.inf
        return lo > hi.max(1)
    rad, _ = bisect(lambda e, r: chunked(test, e, r), np.full(B, 1e-7), np.full(B, 10.0), 16)
    return rad


def signed_readout_radius(G, V, d, c):
    """Exact radius of the sign-preserving multiplicative box on (V, d) with features G >= 0."""
    n = len(c)
    r = np.arange(n)
    P, N = pos_neg(G, V, d)
    Aj = P[r, c][:, None] + N
    Bj = N[r, c][:, None] + P
    with np.errstate(divide="ignore", invalid="ignore"):
        rj = 0.5 * np.log(Aj / Bj)
        rj[r, c] = np.inf
        jc = rj.argmin(1)
        A_, B_ = Aj[r, jc], Bj[r, jc]
        kappa = (A_ + B_) / (A_ - B_)
    return np.maximum(rj.min(1), 0.0), jc, kappa


def signed_readout_witness(G, V, d, c, jc, rows, rho):
    """Lower class c's row and raise competitor jc's row (with biases) and evaluate."""
    flips = 0
    for i in rows:
        Vw, dw = V.copy(), d.copy()
        Vw[c[i]] = signed_vertex(V[c[i]], rho, up=False)
        dw[c[i]] = signed_vertex(d[c[i]:c[i] + 1], rho, up=False)[0]
        Vw[jc[i]] = signed_vertex(V[jc[i]], rho, up=True)
        dw[jc[i]] = signed_vertex(d[jc[i]:jc[i] + 1], rho, up=True)[0]
        Lw = G[i] @ Vw.T + dw
        flips += int(Lw[jc[i]] >= Lw[c[i]])
    return flips


def additive_signed(G, Lg, V, d, c):
    """Additive budget on (V, d): every entry +- eps s, s = RMS(V, d); closed form."""
    s = np.sqrt(np.mean(np.concatenate([V.ravel(), d]) ** 2))
    n = len(c)
    marg = Lg[np.arange(n), c][:, None] - Lg
    marg[np.arange(n), c] = np.inf
    return (marg.min(1) / (2 * s * (G.sum(1) + 1.0)))


def timeit(fn, reps=3):
    best = np.inf
    for _ in range(reps):
        t0 = time.perf_counter()
        fn()
        best = min(best, time.perf_counter() - t0)
    return best


def zero_count(p):
    return int(sum(int(np.sum(v == 0)) for k, v in p.items()))


# ---------------------------------------------------------------------------
# families
# ---------------------------------------------------------------------------
def first_layer_positive(X, F, b, A, c, H):
    """First-layer box (F, b) at the point input with the positive readout fixed."""
    km = PairKM(A)
    n = len(c)
    Pz, Nz = pos_neg(X, F, b)

    def hbox(rho, rows):
        sl, su = preact_box(Pz[rows], Nz[rows], rho)
        return sig(sl), sig(su)

    def t_exact(rho, rows):
        hl, hu = hbox(rho, rows)
        return km_tests(km, c[rows], hl, hu, 1.0)[0]

    def t_marg(rho, rows):
        hl, hu = hbox(rho, rows)
        return km_tests_marginal(A, c[rows], hl, hu, 1.0)

    out, scal = {}, {}
    rows = np.arange(n)
    for rho in ALL_RHOS:
        rv = np.full(n, rho)
        out[f"cert_fl_{rho:g}"] = chunked(t_exact, rv, rows)
        out[f"cert_fl_marg_{rho:g}"] = chunked(t_marg, rv, rows)
    # witnesses at the primary radius
    fails = np.where(~out[f"cert_fl_{PRIMARY:g}"])[0][:MAX_WITNESS]
    flips = 0
    for i in fails:
        hl, hu = hbox(np.array([PRIMARY]), np.array([i]))
        _, _, wit = km_tests(km, c[i:i + 1], hl, hu, 1.0, witness=True)
        j, t, idx = wit[0]
        up = np.zeros(F.shape[0], bool)
        up[idx[:t]] = True
        Fw = np.where(up[:, None], signed_vertex(F, PRIMARY, True), signed_vertex(F, PRIMARY, False))
        bw = np.where(up, signed_vertex(b, PRIMARY, True), signed_vertex(b, PRIMARY, False))
        y = sig(X[i] @ Fw.T + bw) @ A.T
        flips += int(y[j] >= y[c[i]])
    scal["fl_witness"] = {"rho": PRIMARY, "rejected": int((~out[f"cert_fl_{PRIMARY:g}"]).sum()),
                          "checked": int(len(fails)), "flipped": int(flips)}
    t0 = time.perf_counter()
    chunked(t_exact, np.full(n, PRIMARY), rows)
    scal["t_fl_exact_s"] = time.perf_counter() - t0
    t0 = time.perf_counter()
    chunked(t_marg, np.full(n, PRIMARY), rows)
    scal["t_fl_marg_s"] = time.perf_counter() - t0
    lo, hi = np.full(n, 1e-7), np.full(n, 1.0)
    out["r_fl"], cens = bisect(lambda r, q: chunked(t_exact, r, q), lo, hi, 13)
    out["r_fl_marg"], _ = bisect(lambda r, q: chunked(t_marg, r, q), lo, hi, 13)
    scal["r_fl_censored"] = int(cens.sum())
    return out, scal


def km_tests_marginal(A, c, zl, zu, scale):
    B = len(c)
    r = np.arange(B)
    lo = np.broadcast_to(np.asarray(scale, float), (B,)) * (zl @ A.T)[r, c]
    hi = zu @ A.T
    hi[r, c] = -np.inf
    return lo > hi.max(1)


def eval_positive_readout(p, meta, X, y, Xv):
    F, b, Th = (p[k].astype(np.float64) for k in ("F", "b", "Th"))
    A = np.exp(Th)
    H = sig(X @ F.T + b)
    Y = H @ A.T
    logy = np.log(Y)
    c = logy.argmax(1)
    s = np.sort(logy, 1)
    m = s[:, -1] - s[:, -2]
    n = len(y)
    r = np.arange(n)
    jstar = np.argsort(logy, 1)[:, -2]
    out = {"y": y.astype(np.int8), "pred": c.astype(np.int8), "correct": c == y,
           "margin": m, "r_ro": m / 2, "n_active_h": (H > 0.5).sum(1).astype(np.int16)}
    pfan = A[c] * H / Y[r, c][:, None]
    groups, nconst = feature_groups(sig(Xv @ F.T + b))
    out.update(fanin_block(pfan, groups))
    maxcon = (Th[c] - Th[jstar]).max(1)
    out["max_contrast"] = maxcon
    scal = {"n_groups": {f"{t:g}": int(lab.max() + 1) for t, lab in groups.items()},
            "n_const_features": nconst, "logw_span": float(Th.max() - Th.min()),
            "logw_std": float(Th.std()), "mediant_bound_holds": bool(np.all(m <= maxcon + 1e-12))}
    # readout box witnesses at the primary radius: Theta_c - rho, Theta_j* + rho
    rej = np.where(~(m / 2 > PRIMARY))[0]
    yc = Y[rej, c[rej]] * np.exp(-PRIMARY)
    yj = Y[rej, jstar[rej]] * np.exp(PRIMARY)
    scal["ro_witness"] = {"rho": PRIMARY, "rejected": int(len(rej)), "checked": int(len(rej)),
                          "flipped": int(np.sum(yj >= yc))}
    need, certb = readout_bits(H, Th, c)
    out["bits_need"] = need
    for nb in (4, 6, 8, 10, 12):
        out[f"cert_bits_{nb}"] = certb[nb]
    out["eps_add"] = additive_positive(H, A, c)
    fl, fl_s = first_layer_positive(X, F, b, A, c, H)
    out.update(fl)
    scal.update(fl_s)
    return out, scal


def eval_signed_readout(p, meta, X, y, Xv):
    F, b, V, d = (p[k].astype(np.float64) for k in ("F", "b", "V", "d"))
    H = sig(X @ F.T + b)
    Lg = H @ V.T + d
    c = Lg.argmax(1)
    n = len(y)
    r = np.arange(n)
    s = np.sort(Lg, 1)
    r_ro, jc, kappa = signed_readout_radius(H, V, d, c)
    out = {"y": y.astype(np.int8), "pred": c.astype(np.int8), "correct": c == y,
           "margin": s[:, -1] - s[:, -2], "r_ro": r_ro, "kappa": kappa,
           "n_active_h": (H > 0.5).sum(1).astype(np.int16)}
    T = np.abs(V[c] * H)
    groups, nconst = feature_groups(sig(Xv @ F.T + b))
    out.update(fanin_block(T / T.sum(1, keepdims=True), groups))
    scal = {"n_groups": {f"{t:g}": int(lab.max() + 1) for t, lab in groups.items()}, "n_const_features": nconst}
    # closed form against a direct evaluation of the box at the primary radius
    lo = (H @ signed_vertex(V, PRIMARY, False).T + signed_vertex(d, PRIMARY, False))[r, c]
    hi = H @ signed_vertex(V, PRIMARY, True).T + signed_vertex(d, PRIMARY, True)
    hi[r, c] = -np.inf
    scal["closed_form_agrees_rho0.01"] = float(np.mean((lo > hi.max(1)) == (r_ro > PRIMARY)))
    rej = np.where(~(r_ro > PRIMARY))[0]
    scal["ro_witness"] = {"rho": PRIMARY, "rejected": int(len(rej)), "checked": int(min(len(rej), MAX_WITNESS)),
                          "flipped": signed_readout_witness(H, V, d, c, jc, rej[:MAX_WITNESS], PRIMARY)}
    out["eps_add"] = additive_signed(H, Lg, V, d, c)

    # first-layer box (F, b) at the point input, (V, d) fixed: exact pairwise linear solve
    Pz, Nz = pos_neg(X, F, b)

    def hbox(rho, rows):
        sl, su = preact_box(Pz[rows], Nz[rows], rho)
        return sig(sl), sig(su)

    def t_exact(rho, rows):
        hl, hu = hbox(rho, rows)
        cc = c[rows]
        return linear_pair_tests(lambda j: V[cc] - V[j], cc, hl, hu, lambda j: d[cc] - d[j])

    def t_marg(rho, rows):
        hl, hu = hbox(rho, rows)
        cc = c[rows]
        lo_ = (hl @ np.maximum(V, 0).T + hu @ np.minimum(V, 0).T + d)[np.arange(len(rows)), cc]
        hi_ = hu @ np.maximum(V, 0).T + hl @ np.minimum(V, 0).T + d
        hi_[np.arange(len(rows)), cc] = -np.inf
        return lo_ > hi_.max(1)

    for rho in ALL_RHOS:
        rv = np.full(n, rho)
        out[f"cert_fl_{rho:g}"] = chunked(t_exact, rv, r)
        out[f"cert_fl_marg_{rho:g}"] = chunked(t_marg, rv, r)
    fails = np.where(~out[f"cert_fl_{PRIMARY:g}"])[0][:MAX_WITNESS]
    flips = 0
    for i in fails:
        hl, hu = hbox(np.array([PRIMARY]), np.array([i]))
        best = None
        for j in COMP[c[i]]:
            D = V[c[i]] - V[j]
            val = np.where(D > 0, D * hl[0], D * hu[0]).sum() + d[c[i]] - d[j]
            if best is None or val < best[0]:
                best = (val, j, D)
        _, j, D = best
        up = D <= 0                                   # raise h where it helps the competitor
        Fw = np.where(up[:, None], signed_vertex(F, PRIMARY, True), signed_vertex(F, PRIMARY, False))
        bw = np.where(up, signed_vertex(b, PRIMARY, True), signed_vertex(b, PRIMARY, False))
        Lw = sig(X[i] @ Fw.T + bw) @ V.T + d
        flips += int(Lw[j] >= Lw[c[i]])
    scal["fl_witness"] = {"rho": PRIMARY, "rejected": int((~out[f"cert_fl_{PRIMARY:g}"]).sum()),
                          "checked": int(len(fails)), "flipped": int(flips)}
    t0 = time.perf_counter()
    chunked(t_exact, np.full(n, PRIMARY), r)
    scal["t_fl_exact_s"] = time.perf_counter() - t0
    t0 = time.perf_counter()
    chunked(t_marg, np.full(n, PRIMARY), r)
    scal["t_fl_marg_s"] = time.perf_counter() - t0
    lo, hi = np.full(n, 1e-7), np.full(n, 1.0)
    out["r_fl"], cens = bisect(lambda q, rr: chunked(t_exact, q, rr), lo, hi, 13)
    out["r_fl_marg"], _ = bisect(lambda q, rr: chunked(t_marg, q, rr), lo, hi, 13)
    scal["r_fl_censored"] = int(cens.sum())
    return out, scal


def tail_hidden(H, Psi, T):
    M = Psi.max(1, keepdims=True)
    S = (H ** (1.0 / T)) @ np.exp((Psi - M) / T).T
    return M.T + T * np.log(np.maximum(S, 1e-300))


def eval_tail(p, meta, X, y, Xv):
    T = float(meta["kw"]["T"])
    F, b, Psi, Th = (p[k].astype(np.float64) for k in ("F", "b", "Psi", "Th"))
    A = np.exp(Th)
    H = sig(X @ F.T + b)
    U = tail_hidden(H, Psi, T)
    Z = softplus(U)
    Y = Z @ A.T
    logy = np.log(Y)
    c = logy.argmax(1)
    s = np.sort(logy, 1)
    m = s[:, -1] - s[:, -2]
    n = len(y)
    r = np.arange(n)
    jstar = np.argsort(logy, 1)[:, -2]
    out = {"y": y.astype(np.int8), "pred": c.astype(np.int8), "correct": c == y, "margin": m, "r_ro": m / 2,
           "n_active_h": (H > 0.5).sum(1).astype(np.int16)}
    pfan = A[c] * Z / Y[r, c][:, None]
    Zv = softplus(tail_hidden(sig(Xv @ F.T + b), Psi, T))
    groups, nconst = feature_groups(Zv)
    out.update(fanin_block(pfan, groups))
    scal = {"n_groups": {f"{t:g}": int(lab.max() + 1) for t, lab in groups.items()}, "n_const_features": nconst,
            "logw_span": float(Th.max() - Th.min()), "psi_span": float(Psi.max() - Psi.min())}
    rej = np.where(~(m / 2 > PRIMARY))[0]
    scal["ro_witness"] = {"rho": PRIMARY, "rejected": int(len(rej)), "checked": int(len(rej)),
                          "flipped": int(np.sum(Y[rej, jstar[rej]] * np.exp(PRIMARY) >= Y[rej, c[rej]] * np.exp(-PRIMARY)))}
    km = PairKM(A)

    def zbox(rho, rows):
        return softplus(U[rows] - col(rho)), softplus(U[rows] + col(rho))

    def t_exact(rho, rows):
        zl, zu = zbox(rho, rows)
        return km_tests(km, c[rows], zl, zu, np.exp(-2 * rho))[0]

    def t_marg(rho, rows):
        zl, zu = zbox(rho, rows)
        return km_tests_marginal(A, c[rows], zl, zu, np.exp(-2 * rho))

    for rho in ALL_RHOS:
        rv = np.full(n, rho)
        out[f"cert_tail_{rho:g}"] = chunked(t_exact, rv, r)
        out[f"cert_tail_marg_{rho:g}"] = chunked(t_marg, rv, r)
    # witnesses: the minimizing vertex of the exact test, run through the network
    fails = np.where(~out[f"cert_tail_{PRIMARY:g}"])[0][:MAX_WITNESS]
    flips = 0
    for i in fails:
        zl, zu = zbox(np.array([PRIMARY]), np.array([i]))
        _, _, wit = km_tests(km, c[i:i + 1], zl, zu, np.exp(-2 * PRIMARY), witness=True)
        j, t, idx = wit[0]
        up = np.zeros(Psi.shape[0], bool)
        up[idx[:t]] = True
        Psi_w = Psi + np.where(up[:, None], PRIMARY, -PRIMARY)
        Th_w = Th.copy()
        Th_w[c[i]] -= PRIMARY
        Th_w[j] += PRIMARY
        yw = softplus(tail_hidden(H[i:i + 1], Psi_w, T)) @ np.exp(Th_w).T
        flips += int(yw[0, j] >= yw[0, c[i]])
    scal["tail_witness"] = {"rho": PRIMARY, "rejected": int((~out[f"cert_tail_{PRIMARY:g}"]).sum()),
                            "checked": int(len(fails)), "flipped": int(flips),
                            "marginal_rejected": int((~out[f"cert_tail_marg_{PRIMARY:g}"]).sum())}
    t0 = time.perf_counter()
    chunked(t_exact, np.full(n, PRIMARY), r)
    scal["t_tail_exact_s"] = time.perf_counter() - t0
    t0 = time.perf_counter()
    chunked(t_marg, np.full(n, PRIMARY), r)
    scal["t_tail_marg_s"] = time.perf_counter() - t0
    # radii: m/4 <= r_marg <= r_exact <= m/2 (Proposition 5), so bisect inside that bracket
    pos = m > 0
    lo, hi = np.where(pos, 0.999 * m / 4, 1e-12), np.where(pos, m / 2, 2e-12)
    out["r_tail"], _ = bisect(lambda q, rr: chunked(t_exact, q, rr), lo, hi, 12)
    out["r_tail_marg"], _ = bisect(lambda q, rr: chunked(t_marg, q, rr), lo, hi, 12)
    need, certb = readout_bits(Z, Th, c)
    out["bits_need"] = need
    for nb in (4, 6, 8, 10, 12):
        out[f"cert_bits_{nb}"] = certb[nb]
    out["eps_add"] = additive_positive(Z, A, c)
    return out, scal


def eval_deep(p, meta, X, y, Xv):
    F, b, G, e, V, d = (p[k].astype(np.float64) for k in ("F", "b", "G", "e", "V", "d"))
    H = sig(X @ F.T + b)
    Gz = sig(H @ G.T + e)
    Lg = Gz @ V.T + d
    c = Lg.argmax(1)
    n = len(y)
    r = np.arange(n)
    s = np.sort(Lg, 1)
    r_ro, jc, kappa = signed_readout_radius(Gz, V, d, c)
    out = {"y": y.astype(np.int8), "pred": c.astype(np.int8), "correct": c == y,
           "margin": s[:, -1] - s[:, -2], "r_ro": r_ro, "kappa": kappa,
           "n_active_h": (H > 0.5).sum(1).astype(np.int16)}
    Tm = np.abs(V[c] * Gz)
    groups, nconst = feature_groups(sig(sig(Xv @ F.T + b) @ G.T + e))
    out.update(fanin_block(Tm / Tm.sum(1, keepdims=True), groups))
    scal = {"n_groups": {f"{t:g}": int(lab.max() + 1) for t, lab in groups.items()}, "n_const_features": nconst}
    rej = np.where(~(r_ro > PRIMARY))[0]
    scal["ro_witness"] = {"rho": PRIMARY, "rejected": int(len(rej)), "checked": int(min(len(rej), MAX_WITNESS)),
                          "flipped": signed_readout_witness(Gz, V, d, c, jc, rej[:MAX_WITNESS], PRIMARY)}
    out["eps_add"] = additive_signed(Gz, Lg, V, d, c)
    Pg, Ng = pos_neg(H, G, e)

    def gbox(rho, rows):
        gl_, gu_ = preact_box(Pg[rows], Ng[rows], rho)
        return sig(gl_), sig(gu_)

    def vlo(k, rho):        # lowered readout row(s), per-row rho
        return V[k] * np.exp(-col(rho) * np.sign(V[k]))

    def vhi(k, rho):
        return V[k] * np.exp(col(rho) * np.sign(V[k]))

    def dlo(k, rho):
        return d[k] * np.exp(-rho * np.sign(d[k]))

    def dhi(k, rho):
        return d[k] * np.exp(rho * np.sign(d[k]))

    def t_exact(rho, rows):
        gl_, gu_ = gbox(rho, rows)
        cc = c[rows]
        return linear_pair_tests(lambda j: vlo(cc, rho) - vhi(j, rho), cc, gl_, gu_,
                                 lambda j: dlo(cc, rho) - dhi(j, rho))

    def t_marg(rho, rows):
        gl_, gu_ = gbox(rho, rows)
        cc = c[rows]
        B = len(rows)
        lo_ = np.zeros(B)
        his = np.full((B, 10), -np.inf)
        for k in range(10):
            kk = np.full(B, k)
            vl, vh = vlo(kk, rho), vhi(kk, rho)
            low = np.minimum(vl * gl_, vl * gu_).sum(1) + dlo(kk, rho)
            high = np.maximum(vh * gl_, vh * gu_).sum(1) + dhi(kk, rho)
            lo_ = np.where(cc == k, low, lo_)
            his[:, k] = np.where(cc == k, -np.inf, high)
        return lo_ > his.max(1)

    for rho in ALL_RHOS:
        rv = np.full(n, rho)
        out[f"cert_tail_{rho:g}"] = chunked(t_exact, rv, r)
        out[f"cert_tail_marg_{rho:g}"] = chunked(t_marg, rv, r)
    fails = np.where(~out[f"cert_tail_{PRIMARY:g}"])[0][:MAX_WITNESS]
    flips = 0
    rho = PRIMARY
    for i in fails:
        gl_, gu_ = gbox(np.array([rho]), np.array([i]))
        best = None
        for j in COMP[c[i]]:
            D = (V[c[i]] * np.exp(-rho * np.sign(V[c[i]]))) - (V[j] * np.exp(rho * np.sign(V[j])))
            val = np.where(D > 0, D * gl_[0], D * gu_[0]).sum() + dlo(c[i], rho) - dhi(j, rho)
            if best is None or val < best[0]:
                best = (val, j, D)
        _, j, D = best
        up = D <= 0
        Gw = np.where(up[:, None], signed_vertex(G, rho, True), signed_vertex(G, rho, False))
        ew = np.where(up, signed_vertex(e, rho, True), signed_vertex(e, rho, False))
        Vw, dw = V.copy(), d.copy()
        Vw[c[i]] = signed_vertex(V[c[i]], rho, False)
        Vw[j] = signed_vertex(V[j], rho, True)
        dw[c[i]] = signed_vertex(d[c[i]:c[i] + 1], rho, False)[0]
        dw[j] = signed_vertex(d[j:j + 1], rho, True)[0]
        Lw = sig(H[i] @ Gw.T + ew) @ Vw.T + dw
        flips += int(Lw[j] >= Lw[c[i]])
    scal["tail_witness"] = {"rho": PRIMARY, "rejected": int((~out[f"cert_tail_{PRIMARY:g}"]).sum()),
                            "checked": int(len(fails)), "flipped": int(flips),
                            "marginal_rejected": int((~out[f"cert_tail_marg_{PRIMARY:g}"]).sum())}
    t0 = time.perf_counter()
    chunked(t_exact, np.full(n, PRIMARY), r)
    scal["t_tail_exact_s"] = time.perf_counter() - t0
    t0 = time.perf_counter()
    chunked(t_marg, np.full(n, PRIMARY), r)
    scal["t_tail_marg_s"] = time.perf_counter() - t0
    lo, hi = np.full(n, 1e-7), np.full(n, 2.0)
    out["r_tail"], cens = bisect(lambda q, rr: chunked(t_exact, q, rr), lo, hi, 14)
    out["r_tail_marg"], _ = bisect(lambda q, rr: chunked(t_marg, q, rr), lo, hi, 14)
    scal["r_tail_censored"] = int(cens.sum())
    return out, scal


FAMILY_EVAL = {"pos": eval_positive_readout, "robust": eval_positive_readout, "signed": eval_signed_readout,
               "tail": eval_tail, "deep": eval_deep}


def n_params_and_macs(fam, w, m=256):
    if fam in ("pos", "robust"):
        return 785 * w + 10 * w, 784 * w + 10 * w
    if fam == "signed":
        return 785 * w + 10 * w + 10, 784 * w + 10 * w
    if fam == "tail":
        return 785 * w + m * w + 10 * m, 784 * w + m * w + 10 * m
    if fam == "deep":
        return 785 * w + m * w + m + 10 * m + 10, 784 * w + m * w + 10 * m
    raise ValueError(fam)


def nominal_latency(fam, p, meta, X):
    kw = dict(meta.get("kw") or {})
    model = L.make_model("tail" if fam == "tail" else fam, meta["width"], 0, **kw)
    model.p = {k: v.astype(np.float32) for k, v in p.items()}
    X32 = X.astype(np.float32)
    return timeit(lambda: model.forward(X32))


def eval_run(path, split, D):
    p, meta = L.load_params(path)
    fam = "tail" if meta["family"].startswith("tail") else meta["family"]
    X = (D["Xva"] if split == "val" else D["Xte"]).astype(np.float64)
    y = D["yva"] if split == "val" else D["yte"]
    Xv = D["Xva"].astype(np.float64)
    t0 = time.perf_counter()
    out, scal = FAMILY_EVAL[fam](p, meta, X, y, Xv)
    scal["eval_seconds"] = time.perf_counter() - t0
    scal["t_nominal_f32_s"] = nominal_latency(fam, p, meta, X)
    scal["n_eval"] = int(len(y))
    scal["acc"] = float(np.mean(out["correct"]))
    scal["zero_params"] = zero_count(p)
    scal["n_params"], scal["macs"] = n_params_and_macs(fam, meta["width"], (meta.get("kw") or {}).get("m", 256))
    scal["code_sha256"] = CODE_SHA
    scal["split"] = split
    return out, scal, meta


def save_eval(path_out, out, scal, meta):
    arrays = {}
    for k, v in out.items():
        v = np.asarray(v)
        if v.dtype == np.float64:
            v = v.astype(np.float32)
        arrays[k] = v
    np.savez_compressed(path_out, **arrays, scal=json.dumps(scal), meta=json.dumps(meta))


def load_eval(path):
    z = np.load(path, allow_pickle=False)
    return ({k: z[k] for k in z.files if k not in ("scal", "meta")},
            json.loads(str(z["scal"])), json.loads(str(z["meta"])))


def main(split, prefixes):
    D = L.load_mnist()
    od = os.path.join(EVALS, split)
    os.makedirs(od, exist_ok=True)
    names = sorted(f for f in os.listdir(RUNS) if f.endswith(".npz") and f != "split_indices.npz"
                   and any(f.startswith(pf) for pf in prefixes))
    for f in names:
        po = os.path.join(od, f)
        if os.path.exists(po) or time.time() - os.path.getmtime(os.path.join(RUNS, f)) < 30:
            continue                      # done already, or possibly still being written
        t0 = time.time()
        out, scal, meta = eval_run(os.path.join(RUNS, f), split, D)
        save_eval(po, out, scal, meta)
        print(f"{f:34s} acc {scal['acc']:.4f}  ({time.time() - t0:.0f}s)", flush=True)


if __name__ == "__main__":
    split = sys.argv[1]
    assert split in ("val", "test")
    prefixes = sys.argv[2:] or ["pos_", "signed_", "robust_", "deep_", "tail_", "ablate_"]
    main(split, prefixes)
