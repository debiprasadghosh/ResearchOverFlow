"""Numerical checks of the propositions in the P4 paper (Section 3).

    python3 verify_p4_theory.py > verify_p4_theory_output.txt

Each check prints PASS or FAIL; the script exits non-zero if any fails.
"""
import sys, os, itertools
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import p4lib as L

rng = np.random.default_rng(20261011)
FAILS = []


def check(name, ok, detail=''):
    print(f'[{"PASS" if ok else "FAIL"}] {name}  {detail}')
    if not ok:
        FAILS.append(name)


# ---------------------------------------------------------------- Proposition 1 (C(a)): crisp X, interval factors
# s = theta + log Go - log Stop, Go in [Gl, Gh], Stop in [Sl, Sh] (log-factor intervals): range is
# [log Gl - log Sh, log Gh - log Sl], attained at the opposite corners.
M = 20000
mG, mS = rng.normal(0, 1, M), rng.normal(0, 1, M)
rG, rS = rng.uniform(0, 1, M), rng.uniform(0, 1, M)
U = rng.uniform(-1, 1, (M, 200, 2))
samp = (mG[:, None] + rG[:, None] * U[..., 0]) - (mS[:, None] + rS[:, None] * U[..., 1])
lo, hi = mG - rG - (mS + rS), mG + rG - (mS - rS)
check('P1 sampled saliences lie inside the stated range', bool(np.all(samp >= lo[:, None] - 1e-12) & np.all(samp <= hi[:, None] + 1e-12)))
check('P1 the corners attain the endpoints', np.allclose(hi - lo, 2 * (rG + rS)))

# ---------------------------------------------------------------- Proposition 2 (C(b)): shared interval input
n = 4
ok_exact, ok_dec, naive_bad, worst_gap = True, True, 0, 0.0
ratios = []
for trial in range(4000):
    g = rng.uniform(0.01, 1, n); h = rng.uniform(0.01, 1, n)
    xl = np.exp(rng.normal(0, 1, n)); xh = xl * np.exp(rng.uniform(0, 2, n))
    V = np.array(list(itertools.product([0, 1], repeat=n)))
    XV = np.where(V == 1, xh, xl)
    rv = np.log(XV @ g) - np.log(XV @ h)
    XI = xl * (xh / xl) ** rng.uniform(0, 1, (2000, n))
    ri = np.log(XI @ g) - np.log(XI @ h)
    e_lo, e_hi = L.lr_range_exact(xl[None], xh[None], g, h)
    d_lo, d_hi = L.lr_range_decoupled(xl[None], xh[None], g, h)
    nv_lo, nv_hi = L.lr_range_naive(xl[None], xh[None], g, h)
    ok_exact &= bool(np.isclose(e_hi[0], rv.max()) and np.isclose(e_lo[0], rv.min()))
    ok_exact &= bool(ri.max() <= e_hi[0] + 1e-12 and ri.min() >= e_lo[0] - 1e-12)
    ok_dec &= bool(d_lo[0] <= e_lo[0] + 1e-12 and d_hi[0] >= e_hi[0] - 1e-12)
    naive_bad += bool(nv_lo[0] > e_lo[0] + 1e-9 or nv_hi[0] < e_hi[0] - 1e-9)
    ratios.append((d_hi[0] - d_lo[0]) / (e_hi[0] - e_lo[0]))
check('P2 threshold-vertex range = max/min over all 2^n vertices, and contains interior samples', ok_exact)
check('P2 decoupled range contains the exact range', ok_dec)
check('P2 naive corner range misses part of the exact range in some boxes', naive_bad > 0, f'({naive_bad}/4000 boxes)')
ratios = np.array(ratios)
print(f'      decoupled/exact width on random boxes: median {np.median(ratios):.2f}, 90th pct {np.percentile(ratios, 90):.2f}, max {ratios.max():.1f}')

# Task B linearisation (z -> 0): exact width ~ 2 z rad ||a - b||_1, decoupled width ~ 2 z rad (sum a + sum b) = 4 z rad.
st = L.task_b_streams(7, 300); sb = L.task_b_state(st)
z = 1e-4
lo, hi = L.task_b_bounds(sb, z, 'exact'); dlo, dhi = L.task_b_bounds(sb, z, 'dec')
a, b = L.b_shares(sb['lx'])
rad = sb['rad_unit'][..., 0]
check('P2 linearisation: exact width -> 2 z rad ||a-b||_1', np.allclose((hi - lo) / (2 * z * rad), np.abs(a - b).sum(-1), rtol=1e-3))
check('P2 linearisation: decoupled width -> 4 z rad (state independent)', np.allclose((dhi - dlo) / (2 * z * rad), 2.0, rtol=1e-3))

# ---------------------------------------------------------------- Proposition 3: OVL is a state-dependent centre threshold
st = L.task_a_streams(11, 1500); tr = L.task_a_trajectory(st); sa = L.task_a_state(tr)
for zz in (0.3, 1.0):
    w = zz * (sa['uG'] + sa['uS'])
    c_l = L._leader_take(sa['c'], sa['lead'])[..., None]; w_l = L._leader_take(w, sa['lead'])[..., None]
    marg = (c_l - sa['c']) - (w_l + w)
    np.put_along_axis(marg, sa['lead'][..., None], np.inf, axis=2)
    check(f'P3 OVL(z={zz}) iff centre gap to every rival exceeds w_l + w_j', np.array_equal(L.cond_ovl(sa, zz), marg.min(-1) > 0))
# equal widths: OVL(z) == CTR(2 z w)
Gs = np.full((L.T_MAX + 1, 500, 4), 6.0); Ss = np.full_like(Gs, 6.0)
cc = rng.normal(0, 0.5, Gs.shape)
sa_eq = dict(c=cc, uG=1 / np.sqrt(Gs), uS=1 / np.sqrt(Ss), v=1 / Gs + 1 / Ss, lead=np.argmax(cc, -1))
wq = 1 / np.sqrt(6.0) * 2
check('P3 equal widths: OVL(z) is CTR(2 z w) exactly', all(np.array_equal(L.cond_ovl(sa_eq, zz), L.cond_ctr(sa_eq, 2 * zz * wq)) for zz in (0.2, 0.7, 1.3)))

# ---------------------------------------------------------------- Proposition 4: locality of the brake
# OVL and NB (act at t = 0) differ only on trials whose state at t = 0 overlaps.
for zz in (0.35, 0.8):
    cond = L.cond_ovl(sa, zz)
    o, nb = L.outcome_a(sa, tr, cond), L.outcome_a(sa, tr, np.ones_like(cond))
    nonov = cond[0]
    check(f'P4 z={zz}: on non-overlap trials OVL and NB choose identically',
          np.array_equal(o['choice'][nonov], nb['choice'][nonov]) and np.all(o['t'][nonov] == 0),
          f'({nonov.mean():.3f} of trials non-overlapping at t = 0)')
# monotonicity in width at fixed centres: widening any interval can only add braking
cc = rng.normal(0, 1, (1, 5000, 4)); G1 = rng.integers(1, 30, (1, 5000, 4)).astype(float); S1 = rng.integers(1, 30, (1, 5000, 4)).astype(float)
sa1 = dict(c=cc, uG=1 / np.sqrt(G1), uS=1 / np.sqrt(S1), lead=np.argmax(cc, -1))
sa2 = dict(c=cc, uG=sa1['uG'] * rng.uniform(1, 2, cc.shape), uS=sa1['uS'] * rng.uniform(1, 2, cc.shape), lead=sa1['lead'])
check('P4 widening intervals at fixed centres never releases the brake', not np.any(L.cond_ovl(sa2, 1.0) & ~L.cond_ovl(sa1, 1.0)))

# ---------------------------------------------------------------- Proposition 5: l1 (overlap) vs l2 (z-score)
ratio = []
for zz in (0.5, 1.0, 1.5):
    o1, z1, z2 = L.cond_ovl(sa, zz), L.cond_zsc(sa, zz), L.cond_zsc(sa, 2 * zz)
    check(f'P5 OVL(z={zz}) implies ZSC(z)', not np.any(o1 & ~z1))
    check(f'P5 ZSC(2z={2 * zz}) implies OVL(z)', not np.any(z2 & ~o1))
l1 = (sa['uG'] + sa['uS'])[:, :, :, None] + (sa['uG'] + sa['uS'])[:, :, None, :]
l2 = np.sqrt(sa['v'][:, :, :, None] + sa['v'][:, :, None, :])
rr = (l1 / l2)[:, :, ~np.eye(4, dtype=bool)]
check('P5 ratio of l1 to l2 radius lies in [1, 2]', bool(rr.min() >= 1 - 1e-12 and rr.max() <= 2 + 1e-12),
      f'(observed {rr.min():.3f} to {rr.max():.3f} on Task A states)')

# ---------------------------------------------------------------- Proposition 6 (F): certainty equivalents
betas = np.linspace(-20, 20, 81)
rho = rng.uniform(0.01, 2, 200)
F = np.array([L.ce_uniform_shift(b, rho) for b in betas])
check('P6 CE_beta of U[-rho, rho] is nondecreasing in beta', bool(np.all(np.diff(F, axis=0) >= -1e-12)))
check('P6 limits: CE -> +rho / -rho as beta -> +/- infinity (gap log(2 beta rho)/beta)', np.allclose(L.ce_uniform_shift(1e6, rho), rho, atol=1e-4) and np.allclose(L.ce_uniform_shift(-1e6, rho), -rho, atol=1e-4))
cG, rGs, rSs = 0.3, 0.7, 0.4
Ua = rng.uniform(-rGs, rGs, 2_000_000); Ub = rng.uniform(-rSs, rSs, 2_000_000)
for b in (-3.0, -0.5, 0.5, 3.0):
    mc = np.log(np.mean(np.exp(b * (cG + Ua - Ub)))) / b
    check(f'P6 closed form CE_beta(a - b) = c + f(rG) + f(rS) at beta={b}', abs(mc - L.ce_salience(b, cG, rGs, rSs)) < 2e-3,
          f'(MC {mc:.4f}, closed {float(L.ce_salience(b, cG, rGs, rSs)):.4f})')
check('P6 beta -> 0 gives the centre', abs(float(L.ce_salience(1e-7, cG, rGs, rSs)) - cG) < 1e-6)
check('P6 beta leaves the interval unchanged (CE stays inside it)', bool(np.all(np.abs(F) <= rho[None] + 1e-12)))

print('\nALL PASS' if not FAILS else f'\nFAILED: {FAILS}')
sys.exit(1 if FAILS else 0)
