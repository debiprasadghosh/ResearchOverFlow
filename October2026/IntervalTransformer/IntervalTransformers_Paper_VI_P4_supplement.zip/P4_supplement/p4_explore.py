"""Exploratory analyses, written after the confirmatory verdicts (not registered).

E1  Task B: two further rules, tuned on seeds 0-4 and evaluated on 1000-1019:
      SQRT(k)    |r_hat| > k sigma / sqrt(t)       (first-order form of the decoupled range: state independent)
      ZSC_true(k) |r_hat| / se_true > k, se from the true x (an oracle: is the plug-in se the problem?)
E2  Task B: is the plug-in bound smallest where the estimate is ambiguous?  Correlation over states between
    |r_hat| and the plug-in ||a - b||_2, and the bound per unit k on incongruent and congruent trials.
E3  Task A: a Bayesian reference, PB(q): act when the posterior probability (Beta(G, S) per arm, 256 draws)
    that the centre leader is the best arm exceeds q.
    python3 p4_explore.py   -> report/explore.json
"""
import sys, os, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import p4lib as L

HERE = os.path.dirname(os.path.abspath(__file__))
TUNED = json.load(open(os.path.join(HERE, 'tuned.json')))['primary']
rng0 = np.random.default_rng(7)
G_SQRT = np.round(np.arange(0, 12.0001, 0.1), 4)
G_ZT = np.round(np.arange(0, 4.0001, 0.05), 4)
G_PB = np.round(np.concatenate([np.arange(0.3, 0.9, 0.02), np.arange(0.9, 0.995, 0.005)]), 4)


def cond_sqrt(sb, k):
    return np.abs(sb['r']) > k * sb['rad_unit'][..., 0]


def cond_ztrue(sb, st, k):
    a, b = L.b_shares(np.log(st['x'])[None].repeat(L.T_MAX, 0))
    se = sb['rad_unit'][..., 0] * np.sqrt(((a - b) ** 2).sum(-1))
    return np.abs(sb['r']) > k * se


def pbest(sa, tr, seed, draws=256):
    r = np.random.default_rng(seed + 77)
    G, S = tr['G'], tr['S']
    out = np.empty(G.shape[:2])
    for t in range(G.shape[0]):
        smp = r.beta(G[t][..., None], S[t][..., None], size=G[t].shape + (draws,))   # (N, K, D)
        win = np.argmax(smp, axis=1)                                                 # (N, D)
        out[t] = (win == sa['lead'][t][:, None]).mean(axis=1)
    return out


def curves(seed):
    stb = L.task_b_streams(seed, L.N_TRIALS); sb = L.task_b_state(stb)
    res = {}
    for nm, f, grid in (('SQRT', lambda q: cond_sqrt(sb, q), G_SQRT), ('ZSC_true', lambda q: cond_ztrue(sb, stb, q), G_ZT)):
        T, C = [], []
        for q in grid:
            o = L.outcome_b(sb, stb, f(q)); T.append(o['t']); C.append(o['correct'])
        res['B_' + nm] = (np.array(T), np.array(C))
    st = L.task_a_streams(seed, L.N_TRIALS); tr = L.task_a_trajectory(st); sa = L.task_a_state(tr)
    P = pbest(sa, tr, seed)
    T, C = [], []
    for q in G_PB:
        o = L.outcome_a(sa, tr, P > q); T.append(o['t']); C.append(o['correct'])
    res['A_PB'] = (np.array(T), np.array(C))
    # E2 diagnostics
    a, b = L.b_shares(sb['lx']); l2 = np.sqrt(((a - b) ** 2).sum(-1))
    at, bt = L.b_shares(np.log(stb['x'])); l2t = np.sqrt(((at - bt) ** 2).sum(-1))
    diag = dict(corr_absr_l2=float(np.corrcoef(np.abs(sb['r'][:10]).ravel(), l2[:10].ravel())[0, 1]),
                l2_plugin_t1_incong=float(l2[0][stb['cong'] == 0].mean()), l2_plugin_t1_cong=float(l2[0][stb['cong'] == 1].mean()),
                l2_true_incong=float(l2t[stb['cong'] == 0].mean()), l2_true_cong=float(l2t[stb['cong'] == 1].mean()),
                l1_plugin_t1=float(np.abs(a - b)[0].sum(-1).mean()))
    return res, diag


def rrc(T, C, t0=L.T0):
    return C.sum(1) / (T + t0).sum(1)


tune = [curves(s)[0] for s in L.TUNE_SEEDS]
grids = dict(B_SQRT=G_SQRT, B_ZSC_true=G_ZT, A_PB=G_PB)
best = {}
for k in grids:
    num = sum(c[k][1].sum(1) for c in tune); den = sum((c[k][0] + L.T0).sum(1) for c in tune)
    best[k] = int(np.argmax(num / den))
out = dict(tuned={k: float(grids[k][best[k]]) for k in grids}, per_seed={k: [] for k in grids}, diag=[])
for s in L.CONF_SEEDS:
    res, diag = curves(s)
    for k in grids:
        T, C = res[k]
        out['per_seed'][k].append(dict(rr=float(L.reward_rate(C[best[k]], T[best[k]])), acc=float(C[best[k]].mean()),
                                       samples=float(T[best[k]].mean()),
                                       frontier_acc=C.mean(1).tolist(), frontier_t=T.mean(1).tolist()))
    out['diag'].append(diag)
    print('done', s, flush=True)
json.dump(out, open(os.path.join(HERE, 'report', 'explore.json'), 'w'))
for k in grids:
    print(k, out['tuned'][k], np.mean([d['rr'] for d in out['per_seed'][k]]))
print({k: np.mean([d[k] for d in out['diag']]) for k in out['diag'][0]})
