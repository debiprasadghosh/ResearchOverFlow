"""Report: facts for the paper (report/facts.json) and figures (figs/).  Reads runs/, evals/, tuned.json and
report/explore.json.   python3 p4_report.py
"""
import sys, os, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import p4lib as L

HERE = os.path.dirname(os.path.abspath(__file__))
TU = json.load(open(os.path.join(HERE, 'tuned.json')))
T = TU['primary']
D = json.load(open(os.path.join(HERE, 'evals', 'decisions.json')))
EX = json.load(open(os.path.join(HERE, 'report', 'explore.json')))
R = [dict(np.load(os.path.join(HERE, 'runs', f'seed{s}.npz'))) for s in L.CONF_SEEDS]
OUT_F = os.path.join(HERE, 'figs')
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, GREEN = '#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300'
INK, INK2, MUTED, GRIDC, AXIS, SURF = '#0b0b0b', '#52514e', '#898781', '#e1e0d9', '#c3c2b7', '#fcfcfb'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9, 'axes.edgecolor': AXIS, 'axes.labelcolor': INK2,
                     'xtick.color': MUTED, 'ytick.color': MUTED, 'axes.grid': True, 'grid.color': GRIDC,
                     'grid.linewidth': 0.8, 'grid.linestyle': '-', 'axes.facecolor': SURF, 'figure.facecolor': SURF,
                     'savefig.facecolor': SURF, 'axes.titlecolor': INK, 'axes.titlesize': 10, 'legend.frameon': False,
                     'lines.linewidth': 2.0, 'lines.solid_capstyle': 'round'})
rng = np.random.default_rng(20261011)
BI = rng.integers(0, len(R), (10000, len(R)))
F = {}


def ci(d):
    d = np.asarray(d, float); m = d[BI].mean(1)
    return [float(d.mean()), float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))]


def ix(key, tt=T):
    return int(np.argmin(np.abs(L.GRID[key] - tt[key])))


def arm(task, nm, tt=T):
    i = ix(f'{task}_{nm}', tt)
    return [r[f'{task}_{nm}_c'][i] for r in R], [r[f'{task}_{nm}_t'][i] for r in R]


# ------------------------------------------------------------------ table: tuned arms at the primary time cost
tab = {}
for task, rules in (('A', ['OVL', 'CTR', 'ZSC']), ('B', ['OVL_exact', 'OVL_dec', 'CTR', 'ZSC'])):
    for nm in rules:
        C, Tt = arm(task, nm)
        rr = [L.reward_rate(c, t) for c, t in zip(C, Tt)]
        row = dict(param=T[f'{task}_{nm}'], rr=1e3 * np.mean(rr), acc=np.mean([c.mean() for c in C]),
                   samples=np.mean([t.mean() for t in Tt]), forced=np.mean([(t == L.T_MAX).mean() for t in Tt]))
        if task == 'B':
            cg = [r['B_cong'] == 1 for r in R]
            row.update(acc_cong=np.mean([c[m].mean() for c, m in zip(C, cg)]), acc_inc=np.mean([c[~m].mean() for c, m in zip(C, cg)]),
                       t_cong=np.mean([t[m].mean() for t, m in zip(Tt, cg)]), t_inc=np.mean([t[~m].mean() for t, m in zip(Tt, cg)]))
        tab[f'{task}_{nm}'] = {k: float(v) for k, v in row.items()}
tab['A_NB'] = dict(param=0.0, rr=1e3 * float(np.mean([L.reward_rate(r['A_NB_c'], r['A_NB_t']) for r in R])),
                   acc=float(np.mean([r['A_NB_c'].mean() for r in R])), samples=0.0, forced=0.0)
for k in ('B_SQRT', 'B_ZSC_true', 'A_PB'):
    ps = EX['per_seed'][k]
    tab[k] = dict(param=EX['tuned'][k], rr=1e3 * np.mean([p['rr'] for p in ps]), acc=np.mean([p['acc'] for p in ps]),
                  samples=np.mean([p['samples'] for p in ps]))
F['table_primary'] = tab
ex_rr = {k: np.array([p['rr'] for p in EX['per_seed'][k]]) for k in ('B_SQRT', 'B_ZSC_true', 'A_PB')}
rrA = {nm: np.array([L.reward_rate(c, t) for c, t in zip(*arm('A', nm))]) for nm in ('OVL', 'CTR', 'ZSC')}
rrB = {nm: np.array([L.reward_rate(c, t) for c, t in zip(*arm('B', nm))]) for nm in ('OVL_exact', 'OVL_dec', 'CTR', 'ZSC')}
F['explore_diffs'] = dict(
    B_SQRT_minus_OVL_dec=ci(1e3 * (ex_rr['B_SQRT'] - rrB['OVL_dec'])),
    B_ZSC_true_minus_OVL_dec=ci(1e3 * (ex_rr['B_ZSC_true'] - rrB['OVL_dec'])),
    B_ZSC_true_minus_ZSC=ci(1e3 * (ex_rr['B_ZSC_true'] - rrB['ZSC'])),
    A_PB_minus_OVL=ci(1e3 * (ex_rr['A_PB'] - rrA['OVL'])),
    A_PB_minus_CTR=ci(1e3 * (ex_rr['A_PB'] - rrA['CTR'])),
    A_OVL_minus_NB=ci(1e3 * (rrA['OVL'] - np.array([L.reward_rate(r['A_NB_c'], r['A_NB_t']) for r in R]))))
F['diag_B'] = {k: float(np.mean([d[k] for d in EX['diag']])) for k in EX['diag'][0]}

# ------------------------------------------------------------------ time-cost sensitivity
sens = {}
for key in ['T0=20', 'T0=50', 'primary', 'T0=200']:
    t0 = L.T0 if key == 'primary' else float(key[3:]); tt = TU[key]
    row = {}
    for task, rules in (('A', ['OVL', 'CTR', 'ZSC']), ('B', ['OVL_exact', 'OVL_dec', 'CTR', 'ZSC'])):
        for nm in rules:
            C, Tt = arm(task, nm, tt)
            row[f'{task}_{nm}'] = [float(1e3 * np.mean([L.reward_rate(c, t, t0) for c, t in zip(C, Tt)])), tt[f'{task}_{nm}'],
                                   float(np.mean([t.mean() for t in Tt]))]
    rA = {nm: np.array([L.reward_rate(c, t, t0) for c, t in zip(*arm('A', nm, tt))]) for nm in ('OVL', 'CTR', 'ZSC')}
    rB = {nm: np.array([L.reward_rate(c, t, t0) for c, t in zip(*arm('B', nm, tt))]) for nm in ('OVL_exact', 'OVL_dec', 'CTR', 'ZSC')}
    row['A_OVL_vs_CTR_pct'] = float(100 * (rA['OVL'].mean() / rA['CTR'].mean() - 1))
    row['A_ZSC_vs_OVL_pct'] = float(100 * (rA['ZSC'].mean() / rA['OVL'].mean() - 1))
    row['B_exact_vs_CTR_pct'] = float(100 * (rB['OVL_exact'].mean() / rB['CTR'].mean() - 1))
    row['B_dec_vs_exact_pct'] = float(100 * (rB['OVL_dec'].mean() / rB['OVL_exact'].mean() - 1))
    row['B_ZSC_vs_exact_pct'] = float(100 * (rB['ZSC'].mean() / rB['OVL_exact'].mean() - 1))
    row['A_OVL_vs_CTR_ci'] = ci(1e3 * (rA['OVL'] - rA['CTR'])); row['B_dec_vs_exact_ci'] = ci(1e3 * (rB['OVL_dec'] - rB['OVL_exact']))
    sens[key] = row
F['sensitivity'] = sens

# ------------------------------------------------------------------ where does OVL beat CTR in Task A?  by familiarity
fam_gain = {}
n0 = np.concatenate([r['A_n0'] for r in R]); best = np.concatenate([r['A_best'] for r in R])
cO, tO = [np.concatenate(x) for x in arm('A', 'OVL')]; cC, tC = [np.concatenate(x) for x in arm('A', 'CTR')]
fb = n0[np.arange(len(best)), best]
for lv in L.N0_LEVELS:
    m = fb == lv
    fam_gain[int(lv)] = dict(share=float(m.mean()), acc_ovl=float(cO[m].mean()), acc_ctr=float(cC[m].mean()),
                             t_ovl=float(tO[m].mean()), t_ctr=float(tC[m].mean()))
F['A_by_best_arm_familiarity'] = fam_gain
mean_n0 = n0.mean(1)
q = np.quantile(mean_n0, [0, 1 / 3, 2 / 3, 1])
fam_mean = {}
for k in range(3):
    m = (mean_n0 >= q[k]) & (mean_n0 <= q[k + 1]) if k == 2 else (mean_n0 >= q[k]) & (mean_n0 < q[k + 1])
    fam_mean[k] = dict(range=[float(q[k]), float(q[k + 1])], t_ovl=float(tO[m].mean()), t_ctr=float(tC[m].mean()),
                       acc_ovl=float(cO[m].mean()), acc_ctr=float(cC[m].mean()))
F['A_by_mean_familiarity_tercile'] = fam_mean

# ------------------------------------------------------------------ P4.1 brake map
# Recomputed here: the frozen library's map binned float ties (gap ~ -1e-16, from equal ratios such as 4/2 and 2/1)
# with index -1, which wrapped them into the last gap row.  Gaps are clipped at 0 before binning.
sig = {nm: [np.zeros((len(L.GAP_EDGES) - 1, len(L.WID_EDGES) - 1)), np.zeros((len(L.GAP_EDGES) - 1, len(L.WID_EDGES) - 1))] for nm in ('OVL', 'CTR', 'ZSC')}
wrapped = 0
for s in L.CONF_SEEDS:
    st_ = L.task_a_streams(s, L.N_TRIALS); tr_ = L.task_a_trajectory(st_); sa_ = L.task_a_state(tr_)
    gap, wid = L._gap_width(sa_)
    wrapped += int((gap < 0).sum())
    gi = np.digitize(np.maximum(gap, 0.0), L.GAP_EDGES) - 1; wi = np.digitize(wid, L.WID_EDGES) - 1
    for nm in sig:
        br = ~L.A_RULES[nm](sa_, T['A_' + nm])
        np.add.at(sig[nm][0], (gi.ravel(), wi.ravel()), 1); np.add.at(sig[nm][1], (gi.ravel(), wi.ravel()), br.ravel())
sig = {nm: dict(n=v[0].tolist(), frac=np.where(v[0] > 0, v[1] / np.maximum(v[0], 1), np.nan).tolist()) for nm, v in sig.items()}
F['brake_map'] = sig
F['brake_map_tie_states'] = wrapped

# ------------------------------------------------------------------ lesion map: accuracy(OVL*) - accuracy(NB) by initial gap and width
gap0 = np.maximum(np.concatenate([r['A_gap0'] for r in R]), 0.0); wid0 = np.concatenate([r['A_wid0'] for r in R])
cNB = np.concatenate([r['A_NB_c'] for r in R])
GE = [0, 0.25, 0.5, 1.0, np.inf]; WE = [0, 1.0, 1.5, 2.0, np.inf]
les = {}
for i in range(4):
    for j in range(4):
        m = (gap0 >= GE[i]) & (gap0 < GE[i + 1]) & (wid0 >= WE[j]) & (wid0 < WE[j + 1])
        les[f'{i},{j}'] = dict(n=int(m.sum()), d_acc=float(cO[m].mean() - cNB[m].mean()) if m.sum() > 50 else None,
                               acc_nb=float(cNB[m].mean()) if m.sum() > 50 else None)
F['lesion'] = dict(gap_edges=GE[:-1], wid_edges=WE[:-1], cells=les)
ov0 = np.concatenate([~r['A_ovl0_tuned'] for r in R])
F['lesion_overlap_split'] = dict(share_overlap_t0=float(ov0.mean()), d_acc_overlap=float(cO[ov0].mean() - cNB[ov0].mean()),
                                 d_acc_nonoverlap=float(cO[~ov0].mean() - cNB[~ov0].mean()))
# at a fixed centre gap: CTR's brake is blind to width, OVL's is not
F['lesion_ctr'] = {}
for j in range(4):
    m = (gap0 >= 0.5) & (gap0 < 1.0) & (wid0 >= WE[j]) & (wid0 < WE[j + 1])
    F['lesion_ctr'][j] = dict(n=int(m.sum()), d_acc_ovl=float(cO[m].mean() - cNB[m].mean()), d_acc_ctr=float(cC[m].mean() - cNB[m].mean()),
                              t_ovl=float(tO[m].mean()), t_ctr=float(tC[m].mean()))

# ------------------------------------------------------------------ beta
F['beta'] = dict(A_t0_width=D['H5a']['means'], A_t0_acc=D['H5b']['means'], C_preg=D['H5c']['means'],
                 A_stop_acc={f'{b:+.0f}': float(np.mean([r[f'A_betaS{b:+.0f}_c'].mean() for r in R])) for b in L.BETAS},
                 A_stop_width={f'{b:+.0f}': float(np.mean([r[f'A_betaS{b:+.0f}_w'].mean() for r in R])) for b in L.BETAS},
                 C_width={f'{b:+.0f}': float(np.mean([r[f'C_beta{b:+.0f}_w'].mean() for r in R])) for b in L.BETAS},
                 C_reward={f'{b:+.0f}': float(np.mean([r[f'C_beta{b:+.0f}_reward'].mean() for r in R])) for b in L.BETAS})
F['decisions'] = {k: v for k, v in D.items() if k[0] in 'HC'}
json.dump(F, open(os.path.join(HERE, 'report', 'facts.json'), 'w'), indent=1, default=float)

# ================================================================== figures
os.makedirs(OUT_F, exist_ok=True)


def frontier(task, nm):
    acc = np.mean([r[f'{task}_{nm}_c'].mean(1) for r in R], 0); t = np.mean([r[f'{task}_{nm}_t'].mean(1) for r in R], 0)
    return t, acc


# post-review exploratory baselines (verify_p4_addendum.py A5, A6): frontiers on the confirmatory seeds
G_SUM = np.round(np.arange(0, 40.001, 0.25), 3); G_TC = np.round(np.arange(0, 4.001, 0.05), 3)
fr_sum_t, fr_sum_a, fr_tc_t, fr_tc_a = [], [], [], []
tsamp = np.arange(1, L.T_MAX + 1)[:, None]; tA = np.arange(L.T_MAX + 1)[:, None]
for s in L.CONF_SEEDS:
    stb = L.task_b_streams(s, L.N_TRIALS); sb = L.task_b_state(stb)
    oo = [L.outcome_b(sb, stb, np.abs(sb['r']) * tsamp > q) for q in G_SUM]
    fr_sum_t.append([o['t'].mean() for o in oo]); fr_sum_a.append([o['correct'].mean() for o in oo])
    sta = L.task_a_streams(s, L.N_TRIALS); tra = L.task_a_trajectory(sta); saa = L.task_a_state(tra)
    gap = L._leader_take(saa['c'], saa['lead']) - L._others_max(saa['c'], saa['lead'])
    oo = [L.outcome_a(saa, tra, gap > q / np.sqrt(1 + tA)) for q in G_TC]
    fr_tc_t.append([o['t'].mean() for o in oo]); fr_tc_a.append([o['correct'].mean() for o in oo])
FR = dict(B_SUM=(np.mean(fr_sum_t, 0), np.mean(fr_sum_a, 0), int(np.argmin(np.abs(G_SUM - 4.25)))),
          A_CTRt=(np.mean(fr_tc_t, 0), np.mean(fr_tc_a, 0), int(np.argmin(np.abs(G_TC - 1.6)))))

fig, axs = plt.subplots(1, 2, figsize=(10, 4))
for ax, task, rules, xmax in ((axs[0], 'A', [('OVL', BLUE, 'OVL (overlap brake)'), ('CTR', ORANGE, 'CTR (centre gap)'), ('ZSC', AQUA, 'ZSC (standardised gap)')], 40),
                              (axs[1], 'B', [('OVL_exact', BLUE, 'OVL, exact range'), ('OVL_dec', MAGENTA, 'OVL, decoupled range'), ('CTR', ORANGE, 'CTR (centre gap)'), ('ZSC', AQUA, 'ZSC (plug-in se)')], 40)):
    for nm, col, lab in rules[::-1]:
        t, a = frontier(task, nm); ax.plot(t, a, color=col, label=lab)
        i = ix(f'{task}_{nm}'); ax.plot(t[i], a[i], 'o', color=col, ms=7 if nm == 'OVL' else 5, mec=SURF, mew=1.2, zorder=5)
    k = 'A_CTRt' if task == 'A' else 'B_SUM'
    tt_, aa_, i_ = FR[k]
    ax.plot(tt_, aa_, color=INK2, lw=1.4, ls='-.', label=('CTR shrinking as 1/sqrt(1+t) (post-review)' if task == 'A' else '1/t bound on the mean (post-review)'))
    ax.plot(tt_[i_], aa_[i_], 'D', color=INK2, ms=4, zorder=5)
    if task == 'A':
        ps = EX['per_seed']['A_PB']; tt = np.mean([p['frontier_t'] for p in ps], 0); aa = np.mean([p['frontier_acc'] for p in ps], 0)
        ax.plot(tt, aa, color=MUTED, lw=1.4, ls='--', label='Bayes P(best) > q (exploratory)')
        ax.plot(0, tab['A_NB']['acc'], 's', color=INK2, ms=5); ax.annotate('act at once', (0, tab['A_NB']['acc']), xytext=(1.2, tab['A_NB']['acc'] - 0.012), color=INK2, fontsize=8)
    bestrr = max(v['rr'] for k, v in tab.items() if k.startswith(task + '_') and k in [f'{task}_{n}' for n, _, _ in rules]) / 1e3  # best registered rule
    xs = np.linspace(0, xmax, 50); ax.plot(xs, bestrr * (xs + L.T0), color=AXIS, lw=1, ls=':', label='iso reward rate (best registered rule)')
    ax.set_xlim(0, xmax); ax.set_xlabel('mean samples per trial'); ax.set_ylabel('accuracy')
    ax.set_ylim(0.5 if task == 'A' else 0.6, 0.78 if task == 'A' else 0.95)
    ax.set_title('Task A: dissociated bandit' if task == 'A' else 'Task B: conflict (flanker)', loc='left')
    ax.legend(fontsize=7, loc='lower right')
fig.tight_layout(); fig.savefig(os.path.join(OUT_F, 'fig1_frontiers.png'), dpi=170); plt.close(fig)

# fig 2: brake map at fixed gap
fig, axs = plt.subplots(1, 2, figsize=(10, 3.6), sharey=True)
wc = ['<1', '1-1.5', '1.5-2', '2-2.5', '2.5-3', '3-4']
for ax, nm, ttl in ((axs[0], 'OVL', 'OVL*: brakes on overlap'), (axs[1], 'CTR', 'CTR*: brakes on a small centre gap')):
    fr = np.array(sig[nm]['frac']); nn = np.array(sig[nm]['n'])
    for gi, col in zip((1, 2, 3, 4), (BLUE, AQUA, YELLOW, MAGENTA)):
        y = np.where(nn[gi] > 200, fr[gi], np.nan)[:len(wc)]
        ax.plot(range(len(wc)), y, 'o-', color=col, ms=4, label=f'centre gap {L.GAP_EDGES[gi]:g}-{L.GAP_EDGES[gi + 1]:g}')
    ax.set_xticks(range(len(wc))); ax.set_xticklabels(wc); ax.set_xlabel('summed radius of leader and runner-up (z = 1 units)')
    ax.set_title(ttl, loc='left'); ax.set_ylim(-0.03, 1.03)
axs[0].set_ylabel('share of states braked'); axs[1].legend(fontsize=7.5, loc='lower right')
fig.tight_layout(); fig.savefig(os.path.join(OUT_F, 'fig3_brake_map.png'), dpi=170); plt.close(fig)

# fig 3: lesion (remove the brake) at fixed gap, by width
fig, ax = plt.subplots(figsize=(5.6, 3.6))
GL = ['gap < 0.25', 'gap 0.25-0.5', 'gap 0.5-1', 'gap > 1']
for i, col in zip(range(4), (BLUE, AQUA, YELLOW, MAGENTA)):
    y = [les[f'{i},{j}']['d_acc'] for j in range(4)]
    y = [np.nan if v is None else 100 * v for v in y]
    ax.plot(range(4), y, 'o-', color=col, ms=4, label=GL[i])
ax.axhline(0, color=AXIS, lw=1)
ax.set_xticks(range(4)); ax.set_xticklabels(['<1', '1-1.5', '1.5-2', '>2']); ax.set_xlabel('initial summed radius (z = 1 units)')
ax.set_ylabel('accuracy lost by removing the brake (pp)'); ax.set_title('Task A: cost of releasing the brake at t = 0', loc='left')
ax.legend(fontsize=7.5)
fig.tight_layout(); fig.savefig(os.path.join(OUT_F, 'fig4_lesion.png'), dpi=170); plt.close(fig)

# fig 4: beta
fig, axs = plt.subplots(1, 3, figsize=(10.5, 3.2))
bb = L.BETAS; kk = [f'{b:+.0f}' for b in bb]
axs[0].plot(bb, [F['beta']['A_t0_width'][k] for k in kk], 'o-', color=BLUE, ms=4); axs[0].set_title('Task A, t = 0: chosen width', loc='left')
axs[0].set_ylabel('summed radius of chosen arm')
axs[1].plot(bb, [100 * F['beta']['A_t0_acc'][k] for k in kk], 'o-', color=BLUE, ms=4, label='t = 0')
axs[1].plot(bb, [100 * F['beta']['A_stop_acc'][k] for k in kk], 'o-', color=AQUA, ms=4, label='at the OVL* stop')
axs[1].set_title('Task A: accuracy', loc='left'); axs[1].set_ylabel('% correct'); axs[1].legend(fontsize=7.5)
axs[2].plot(bb, [F['beta']['C_preg'][k] for k in kk], 'o-', color=ORANGE, ms=4); axs[2].set_title('Task C: pseudo-regret (200 pulls)', loc='left')
for a in axs:
    a.set_xlabel('beta (risk attitude)'); a.set_xticks(bb)
fig.tight_layout(); fig.savefig(os.path.join(OUT_F, 'fig2_beta.png'), dpi=170); plt.close(fig)
print(json.dumps({k: F[k] for k in ('table_primary', 'explore_diffs', 'diag_B', 'lesion_overlap_split', 'lesion_ctr', 'A_by_best_arm_familiarity', 'A_by_mean_familiarity_tercile')}, indent=1, default=float))
