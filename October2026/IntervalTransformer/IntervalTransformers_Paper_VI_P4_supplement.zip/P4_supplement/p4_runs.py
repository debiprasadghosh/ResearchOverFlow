"""Confirmatory runs on seeds 1000-1019 with the tuned parameters; one npz per seed in runs/.

    python3 p4_runs.py
"""
import sys, os, json
import numpy as np
from concurrent.futures import ProcessPoolExecutor
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import p4lib as L

HERE = os.path.dirname(os.path.abspath(__file__))
TUNED = json.load(open(os.path.join(HERE, 'tuned.json')))


def one(seed):
    out = L.simulate_seed(seed, tuned=TUNED['primary'])
    np.savez_compressed(os.path.join(HERE, 'runs', f'seed{seed}.npz'), **out)
    return seed


if __name__ == '__main__':
    os.makedirs(os.path.join(HERE, 'runs'), exist_ok=True)
    with ProcessPoolExecutor(2) as ex:
        for s in ex.map(one, L.CONF_SEEDS):
            print('done', s, flush=True)
