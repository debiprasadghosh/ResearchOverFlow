"""Frozen evaluator: applies the registered decision rules of PROTOCOL.md to runs/ and tuned.json.
Writes evals/decisions.json and prints a summary.

    python3 p4_eval.py
"""
import sys, os, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import p4lib as L

HERE = os.path.dirname(os.path.abspath(__file__))
TUNED = json.load(open(os.path.join(HERE, 'tuned.json')))['primary']
R = [dict(np.load(os.path.join(HERE, 'runs', f'seed{s}.npz'))) for s in L.CONF_SEEDS]
B_RES = 10000
rng = np.random.default_rng(20261011)
BOOT_IDX = rng.integers(0, len(R), (B_RES, len(R)))


def idx(key):
    return int(np.argmin(np.abs(L.GRID[key] - TUNED[key])))


def rr(r, task, nm, t0=None):
    i = idx(f'{task}_{nm}')
    return L.reward_rate(r[f'{task}_{nm}_c'][i], r[f'{task}_{nm}_t'][i], t0)


def ci(d):
    d = np.asarray(d, float)
    m = d[BOOT_IDX].mean(axis=1)
    return dict(mean=float(d.mean()), lo=float(np.percentile(m, 2.5)), hi=float(np.percentile(m, 97.5)))


def verdict(c):
    return 'supported' if c['lo'] > 0 else ('rejected' if c['hi'] < 0 else 'inconclusive')


def rel(a, b):
    return 100 * (np.mean(a) - np.mean(b)) / np.mean(b)


D = {}
A = {nm: np.array([rr(r, 'A', nm) for r in R]) for nm in ('OVL', 'CTR', 'ZSC')}
A['NB'] = np.array([L.reward_rate(r['A_NB_c'], r['A_NB_t']) for r in R])
B = {nm: np.array([rr(r, 'B', nm) for r in R]) for nm in ('OVL_exact', 'OVL_dec', 'CTR', 'ZSC')}

c = ci(A['OVL'] - A['CTR']); D['H1'] = dict(test='Task A: RR(OVL*) - RR(CTR*) > 0 (kill criterion)', **c, rel_pct=rel(A['OVL'], A['CTR']), verdict=verdict(c))
c = ci(B['OVL_exact'] - B['CTR']); D['H2'] = dict(test='Task B: RR(OVL_exact*) - RR(CTR*) > 0', **c, rel_pct=rel(B['OVL_exact'], B['CTR']), verdict=verdict(c))
c = ci(B['OVL_dec'] - B['OVL_exact']); D['H3'] = dict(test='Task B: RR(OVL_dec*) - RR(OVL_exact*) > 0 (pilot-informed)', **c, rel_pct=rel(B['OVL_dec'], B['OVL_exact']), verdict=verdict(c))
c = ci(A['ZSC'] - A['OVL']); D['H4a'] = dict(test='Task A: RR(ZSC*) - RR(OVL*) > 0', **c, rel_pct=rel(A['ZSC'], A['OVL']), verdict=verdict(c))
c = ci(B['ZSC'] - B['OVL_exact']); D['H4b'] = dict(test='Task B: RR(ZSC*) - RR(OVL_exact*) > 0', **c, rel_pct=rel(B['ZSC'], B['OVL_exact']), verdict=verdict(c))

# H5a: chosen width at t = 0 strictly increasing across the beta grid
W = {b: np.array([r[f'A_beta{b:+.0f}_w'].mean() for r in R]) for b in L.BETAS}
steps = [ci(W[b2] - W[b1]) for b1, b2 in zip(L.BETAS[:-1], L.BETAS[1:])]
v = 'supported' if all(s['lo'] > 0 for s in steps) else ('rejected' if any(s['hi'] < 0 for s in steps) else 'inconclusive')
D['H5a'] = dict(test='Task A, t = 0: mean chosen width increases at every step of the beta grid', steps=steps,
                means={f'{b:+.0f}': float(W[b].mean()) for b in L.BETAS}, verdict=v)
# H5b: accuracy at beta = 0 above beta = +8 and beta = -8
Acc = {b: np.array([r[f'A_beta{b:+.0f}_c'].mean() for r in R]) for b in L.BETAS}
s1, s2 = ci(Acc[0.0] - Acc[8.0]), ci(Acc[0.0] - Acc[-8.0])
v = 'supported' if (s1['lo'] > 0 and s2['lo'] > 0) else ('rejected' if (s1['hi'] < 0 or s2['hi'] < 0) else 'inconclusive')
D['H5b'] = dict(test='Task A, t = 0: accuracy(beta=0) > accuracy(beta=+8) and > accuracy(beta=-8)', vs_plus8=s1, vs_minus8=s2,
                means={f'{b:+.0f}': float(Acc[b].mean()) for b in L.BETAS}, verdict=v)
# H5c: Task C, pseudo-regret lower at beta = 2 than at beta = 0
PR = {b: np.array([r[f'C_beta{b:+.0f}_preg'].mean() for r in R]) for b in L.BETAS}
c = ci(PR[0.0] - PR[2.0])
D['H5c'] = dict(test='Task C: pseudo-regret(beta=0) - pseudo-regret(beta=2) > 0 (pilot-informed)', **c,
                means={f'{b:+.0f}': float(PR[b].mean()) for b in L.BETAS}, verdict=verdict(c))

# Checks (by construction; reported, not hypotheses)
mism, nonov = 0, 0
for r in R:
    i = idx('A_OVL'); m = r['A_ovl0_tuned']
    nonov += int(m.sum())
    mism += int(np.sum(r['A_OVL_c'][i][m] != r['A_NB_c'][m]) + np.sum(r['A_OVL_t'][i][m] != 0))
D['C1'] = dict(check='Brake locality: OVL* and NB differ on no trial that does not overlap at t = 0', mismatches=mism,
               nonoverlap_trials=nonov, total_trials=len(R) * L.N_TRIALS, verdict='pass' if mism == 0 else 'fail')

D['summary_rr'] = {'A': {k: float(v.mean()) for k, v in A.items()}, 'B': {k: float(v.mean()) for k, v in B.items()}}
D['tuned'] = TUNED
os.makedirs(os.path.join(HERE, 'evals'), exist_ok=True)
json.dump(D, open(os.path.join(HERE, 'evals', 'decisions.json'), 'w'), indent=1)
for k, v in D.items():
    if k.startswith('H') or k.startswith('C'):
        extra = f"  mean {v['mean']:.3e} [{v['lo']:.3e}, {v['hi']:.3e}]" if 'mean' in v else ''
        print(f"{k:4s} {v['verdict']:12s} {v.get('test', v.get('check'))}{extra}")
