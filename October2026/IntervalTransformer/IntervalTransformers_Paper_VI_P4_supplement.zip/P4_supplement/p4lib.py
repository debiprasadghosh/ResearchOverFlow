"""P4 library: the hyperdirect pathway as a brake that acts when action ranges overlap.

Three tasks, all vectorised over trials with numpy.

Task A  dissociated bandit (best-arm choice under a time cost).  k = 4 Bernoulli arms per trial,
        p_c ~ U(0.2, 0.8); familiarity (pre-observations n0_c in {0, 2, 8, 32}) drawn independently of p.
        Go deck strength G_c = successes + 1, Stop deck strength S_c = failures + 1 (crisp X, interval factors:
        Proposition C(a)).  Salience centre c = log G - log S; Go and Stop log-factor radii z/sqrt(G), z/sqrt(S).
        The sampling policy is shared by every stopping rule, so all rules read the same trajectory and differ
        only in when they stop: exact pairing.
Task B  conflict (flanker) task with a shared interval input (Proposition C(b)).  Features [tL, tR, fL, fR];
        Go_L = g.x, Stop_L = h.x, channel R mirrored, so the two saliences are s_L = theta + r, s_R = theta - r,
        r = log(g.x) - log(h.x).  The input interval comes from noisy lognormal samples.
Task C  repeated bandit (cumulative reward): the arm with the largest certainty equivalent CE_beta is pulled.

Every function is pure: inputs in, arrays out.
"""
import math
import numpy as np

# ------------------------------------------------------------------------------------------------ constants
K_A = 4
N0_LEVELS = np.array([0, 2, 8, 32])
T_MAX = 60          # deadline (samples); a trial still open at T_MAX is forced to act
T0 = 100.0          # non-decision time (inter-trial cost) added to every trial: reward rate = correct / (samples + T0)
T0_SENS = [20.0, 50.0, 200.0]   # exploratory sensitivity
ZP = 1.0            # radius multiplier used by the shared sampling policy (not by any stopping rule)
JITTER = 1e-9       # fixed per-arm tie-break added to centres when picking the leader

# Task B
G_B = np.array([1.0, 0.2, 0.4, 0.1])     # Go_L weights on [tL, tR, fL, fR]
H_B = np.array([0.2, 1.0, 0.1, 0.4])     # Stop_L weights
SIGMA_B = 2.0                            # log-normal observation noise per feature per sample
X_TARGET, X_OFF, X_FLANK = 1.0, 0.2, 1.5

# Task C
H_C = 200
Z_C = 1.0


# ------------------------------------------------------------------------------------------------ helpers
def phi_logsinhc(x):
    """log(sinh(x)/x), even in x, stable for all x."""
    a = np.abs(np.asarray(x, dtype=float))
    out = np.empty_like(a)
    small = a < 1e-4
    out[small] = a[small] ** 2 / 6.0
    b = a[~small]
    out[~small] = b + np.log1p(-np.exp(-2.0 * b)) - np.log(2.0 * b)
    return out


def ce_uniform_shift(beta, rho):
    """f_beta(rho) = CE_beta(U[-rho, rho]) = (1/beta) log(sinh(beta rho) / (beta rho)); f_0 = 0; odd in beta."""
    rho = np.asarray(rho, dtype=float)
    if beta == 0:
        return np.zeros_like(rho)
    return phi_logsinhc(beta * rho) / beta


def ce_salience(beta, c, rG, rS):
    """CE_beta of s = a - b with a ~ U[mG - rG, mG + rG], b ~ U[mS - rS, mS + rS] independent, c = mG - mS.
    CE_beta(a - b) = CE_beta(a) - CE_{-beta}(b) = c + f_beta(rG) + f_beta(rS)."""
    return c + ce_uniform_shift(beta, rG) + ce_uniform_shift(beta, rS)


def first_true(cond):
    """cond: (T+1, N) bool.  Index of the first True along axis 0, or T if none (forced at the deadline)."""
    T = cond.shape[0] - 1
    any_ = cond.any(axis=0)
    idx = np.argmax(cond, axis=0)
    return np.where(any_, idx, T)


# ------------------------------------------------------------------------------------------------ Task A
def task_a_streams(seed, n_trials):
    rng = np.random.default_rng(seed)
    p = rng.uniform(0.2, 0.8, (n_trials, K_A))
    n0 = rng.choice(N0_LEVELS, (n_trials, K_A))
    U = rng.random((n_trials, K_A, int(N0_LEVELS.max()) + T_MAX))
    jit = JITTER * rng.random((n_trials, K_A))
    return dict(p=p, n0=n0, O=(U < p[..., None]), jit=jit)


def task_a_trajectory(st):
    """Run the shared sampling policy for T_MAX samples.  Returns G, S of shape (T_MAX+1, N, K) (state before
    sample t), the arm sampled at each step, and the best arm."""
    p, n0, O, jit = st['p'], st['n0'], st['O'], st['jit']
    N, K = p.shape
    ar = np.arange(N)
    succ = np.zeros((N, K), int)
    for k in range(K):
        cs = np.cumsum(O[:, k, :], axis=1)
        succ[:, k] = np.where(n0[:, k] > 0, cs[ar, np.maximum(n0[:, k] - 1, 0)], 0)
    G = (succ + 1).astype(float)
    S = (n0 - succ + 1).astype(float)
    ptr = n0.copy()
    GG = np.empty((T_MAX + 1, N, K)); SS = np.empty((T_MAX + 1, N, K)); arm = np.empty((T_MAX, N), int)
    for t in range(T_MAX + 1):
        GG[t], SS[t] = G, S
        if t == T_MAX:
            break
        c = np.log(G) - np.log(S) + jit
        lead = np.argmax(c, axis=1)
        up = c + ZP * (1 / np.sqrt(G) + 1 / np.sqrt(S))
        up[ar, lead] = -np.inf
        chal = np.argmax(up, axis=1)
        nl, nc = G[ar, lead] + S[ar, lead], G[ar, chal] + S[ar, chal]
        a = np.where(nl < nc, lead, chal)
        o = O[ar, a, ptr[ar, a]]
        G[ar, a] += o; S[ar, a] += ~o
        ptr[ar, a] += 1
        arm[t] = a
    return dict(G=GG, S=SS, arm=arm, best=np.argmax(p, axis=1), jit=jit)


def task_a_state(tr):
    """Centres, Go/Stop radii per unit z, leader and v = 1/G + 1/S for every (t, trial, arm)."""
    G, S = tr['G'], tr['S']
    c = np.log(G) - np.log(S)
    lead = np.argmax(c + tr['jit'][None], axis=2)
    return dict(c=c, uG=1 / np.sqrt(G), uS=1 / np.sqrt(S), v=1 / G + 1 / S, lead=lead)


def _leader_take(X, lead):
    return np.take_along_axis(X, lead[..., None], axis=2)[..., 0]


def _others_max(X, lead):
    Y = X.copy()
    np.put_along_axis(Y, lead[..., None], -np.inf, axis=2)
    return Y.max(axis=2)


def cond_ovl(sa, z):
    """Brake released iff the lower salience of the leader exceeds the upper salience of every other channel."""
    w = z * (sa['uG'] + sa['uS'])
    lo_l = _leader_take(sa['c'] - w, sa['lead'])
    return lo_l > _others_max(sa['c'] + w, sa['lead'])


def cond_ctr(sa, tau):
    c_l = _leader_take(sa['c'], sa['lead'])
    return c_l - _others_max(sa['c'], sa['lead']) > tau


def cond_zsc(sa, kappa):
    c_l = _leader_take(sa['c'], sa['lead'])[..., None]
    v_l = _leader_take(sa['v'], sa['lead'])[..., None]
    zs = (c_l - sa['c']) / np.sqrt(v_l + sa['v'])
    np.put_along_axis(zs, sa['lead'][..., None], np.inf, axis=2)
    return zs.min(axis=2) > kappa


def outcome_a(sa, tr, cond):
    """Stop at the first t where cond holds (deadline forces t = T_MAX); choose the centre leader."""
    t = first_true(cond)
    N = t.shape[0]
    choice = sa['lead'][t, np.arange(N)]
    return dict(t=t, choice=choice, correct=(choice == tr['best']), forced=~cond.any(axis=0))


def reward_rate(correct, t, t0=None):
    return float(np.sum(correct) / np.sum(t + (T0 if t0 is None else t0)))


# ------------------------------------------------------------------------------------------------ Task B
def task_b_streams(seed, n_trials):
    rng = np.random.default_rng(seed)
    d = rng.integers(0, 2, n_trials)          # 0 = target left, 1 = target right
    cong = rng.integers(0, 2, n_trials)       # 1 = flankers on the target side
    x = np.full((n_trials, 4), X_OFF)
    x[np.arange(n_trials), d] = X_TARGET
    fl_side = np.where(cong == 1, d, 1 - d)
    x[np.arange(n_trials), 2 + fl_side] = X_FLANK
    eps = rng.standard_normal((n_trials, T_MAX, 4))
    return dict(d=d, cong=cong, x=x, eps=eps)


def task_b_logxhat(st):
    """log of the geometric-mean estimate after t = 1..T_MAX samples: shape (T_MAX, N, 4); row t-1 is t samples."""
    cm = np.cumsum(st['eps'], axis=1) / np.arange(1, T_MAX + 1)[None, :, None]
    return np.log(st['x'])[None] + SIGMA_B * np.transpose(cm, (1, 0, 2))


def lr_point(xh, g=G_B, h=H_B):
    return np.log(xh @ g) - np.log(xh @ h)


def lr_range_exact(lo, hi, g=G_B, h=H_B):
    """Exact range of log(g.x) - log(h.x) over the box lo <= x <= hi (all positive), by the threshold-vertex rule:
    at the maximum x_k is at its upper end iff g_k/h_k exceeds a threshold, so only n+1 vertices need checking."""
    order = np.argsort(-(g / h))
    n = len(g)
    best_hi = np.full(lo.shape[:-1], -np.inf); best_lo = np.full(lo.shape[:-1], np.inf)
    for m in range(n + 1):
        up_set = np.zeros(n, bool); up_set[order[:m]] = True          # top-m ratios at the upper end -> max candidate
        xv = np.where(up_set, hi, lo)
        best_hi = np.maximum(best_hi, np.log(xv @ g) - np.log(xv @ h))
        lo_set = np.zeros(n, bool); lo_set[order[n - m:]] = True     # bottom-m ratios at the upper end -> min candidate
        xv = np.where(lo_set, hi, lo)
        best_lo = np.minimum(best_lo, np.log(xv @ g) - np.log(xv @ h))
    return best_lo, best_hi


def lr_range_decoupled(lo, hi, g=G_B, h=H_B):
    """Sound but loose: numerator and denominator bounded separately."""
    return np.log(lo @ g) - np.log(hi @ h), np.log(hi @ g) - np.log(lo @ h)


def lr_range_naive(lo, hi, g=G_B, h=H_B):
    """Unsound: both ends read at the same corner (lower corner, upper corner)."""
    a, b = lr_point(lo, g, h), lr_point(hi, g, h)
    return np.minimum(a, b), np.maximum(a, b)


def task_b_state(st):
    lx = task_b_logxhat(st)                                        # (T, N, 4)
    rad_unit = SIGMA_B / np.sqrt(np.arange(1, T_MAX + 1))[:, None, None]
    return dict(lx=lx, rad_unit=rad_unit, r=lr_point(np.exp(lx)))


def task_b_bounds(sb, z, kind):
    lo = np.exp(sb['lx'] - z * sb['rad_unit']); hi = np.exp(sb['lx'] + z * sb['rad_unit'])
    return (lr_range_exact if kind == 'exact' else lr_range_decoupled)(lo, hi)


def outcome_b(sb, st, cond):
    """cond (T, N) over t = 1..T_MAX samples; samples used = index + 1; choice = sign of the point estimate
    (for the overlap rules the certified sign equals it)."""
    T = cond.shape[0]
    any_ = cond.any(axis=0)
    idx = np.where(any_, np.argmax(cond, axis=0), T - 1)
    N = cond.shape[1]
    r = sb['r'][idx, np.arange(N)]
    choice = np.where(r > 0, 0, 1)
    return dict(t=idx + 1, choice=choice, correct=(choice == st['d']), forced=~any_)


def cond_b_ovl(sb, z, kind):
    lo, hi = task_b_bounds(sb, z, kind)
    return (lo > 0) | (hi < 0)


def cond_b_ctr(sb, tau):
    return np.abs(sb['r']) > tau


def b_shares(lx, g=G_B, h=H_B):
    """Share vectors a_k = g_k x_k / g.x and b_k = h_k x_k / h.x: the gradient of r in log x is a - b."""
    x = np.exp(lx)
    return x * g / (x @ g)[..., None], x * h / (x @ h)[..., None]


def cond_b_zsc(sb, kappa):
    """Standardised rule: |r_hat| / se > kappa with the delta-method se = sigma/sqrt(t) * ||a - b||_2."""
    a, b = b_shares(sb['lx'])
    se = sb['rad_unit'][..., 0] * np.sqrt(((a - b) ** 2).sum(-1))
    return np.abs(sb['r']) > kappa * se


# ------------------------------------------------------------------------------------------------ Task C
def task_c_streams(seed, n_trials):
    rng = np.random.default_rng(seed)
    p = rng.uniform(0.2, 0.8, (n_trials, K_A))
    U = rng.random((n_trials, K_A, H_C))
    jit = JITTER * rng.random((n_trials, K_A))
    return dict(p=p, O=(U < p[..., None]), jit=jit)


def task_c_run(st, beta, z=Z_C):
    """Pull argmax CE_beta for H_C rounds; reward from the arm's own pre-generated stream (paired across beta).
    Returns realised reward, pseudo-regret and mean chosen width per trial."""
    p, O, jit = st['p'], st['O'], st['jit']
    N, K = p.shape
    ar = np.arange(N)
    G = np.ones((N, K)); S = np.ones((N, K)); ptr = np.zeros((N, K), int)
    rew = np.zeros(N); preg = np.zeros(N); wsum = np.zeros(N)
    pstar = p.max(axis=1)
    for _ in range(H_C):
        rG, rS = z / np.sqrt(G), z / np.sqrt(S)
        ce = ce_salience(beta, np.log(G) - np.log(S), rG, rS) + jit
        a = np.argmax(ce, axis=1)
        o = O[ar, a, ptr[ar, a]]
        G[ar, a] += o; S[ar, a] += ~o; ptr[ar, a] += 1
        rew += o; preg += pstar - p[ar, a]; wsum += rG[ar, a] + rS[ar, a]
    return dict(reward=rew, pseudo_regret=preg, mean_width=wsum / H_C)


def choose_ce_a(sa, t_idx, beta, z):
    """Task A: arm chosen by CE_beta at sample index t_idx (array over trials) with radius multiplier z."""
    N = t_idx.shape[0]
    c = sa['c'][t_idx, np.arange(N)]
    rG = z * sa['uG'][t_idx, np.arange(N)]; rS = z * sa['uS'][t_idx, np.arange(N)]
    ce = ce_salience(beta, c, rG, rS)
    ch = np.argmax(ce, axis=1)
    return ch, (rG + rS)[np.arange(N), ch]


# ------------------------------------------------------------------------------------------------ grids, seeds
GRID = dict(
    A_OVL=np.round(np.arange(0.0, 3.0001, 0.05), 4),
    A_CTR=np.round(np.arange(0.0, 4.0001, 0.05), 4),
    A_ZSC=np.round(np.arange(0.0, 4.0001, 0.05), 4),
    B_OVL_exact=np.round(np.arange(0.0, 4.0001, 0.05), 4),
    B_OVL_dec=np.round(np.arange(0.0, 4.0001, 0.05), 4),
    B_CTR=np.round(np.arange(0.0, 2.0001, 0.02), 4),
    B_ZSC=np.round(np.arange(0.0, 4.0001, 0.05), 4),
)
BETAS = [-8.0, -2.0, 0.0, 2.0, 8.0]
Z_BETA_A = 1.0          # radius multiplier for the beta test in Task A
TUNE_SEEDS = list(range(0, 5))
CONF_SEEDS = list(range(1000, 1020))
N_TRIALS = 2000


# ------------------------------------------------------------------------------------------------ one seed, all arms
A_RULES = dict(OVL=cond_ovl, CTR=cond_ctr, ZSC=cond_zsc)
B_RULES = dict(OVL_exact=lambda sb, q: cond_b_ovl(sb, q, 'exact'), OVL_dec=lambda sb, q: cond_b_ovl(sb, q, 'dec'),
               CTR=cond_b_ctr, ZSC=cond_b_zsc)
GAP_EDGES = np.array([0.0, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, np.inf])
WID_EDGES = np.array([0.0, 1.0, 1.5, 2.0, 2.5, 3.0, 4.0, np.inf])


def _gap_width(sa):
    """Centre gap leader - runner-up and the unit-z summed radius of leader and runner-up, per (t, trial)."""
    c = sa['c']; lead = sa['lead']
    c_l = _leader_take(c, lead)
    cm = c.copy(); np.put_along_axis(cm, lead[..., None], -np.inf, axis=2)
    run = np.argmax(cm, axis=2)
    u = sa['uG'] + sa['uS']
    return c_l - cm.max(axis=2), _leader_take(u, lead) + _leader_take(u, run)


def simulate_seed(seed, n_trials=N_TRIALS, tuned=None):
    """Every arm on one seed.  Curves over each rule's grid are stored so that reward rates for any time cost
    can be computed later.  If `tuned` is given, also the measurements that need the tuned parameters."""
    out = {}
    # Task A
    st = task_a_streams(seed, n_trials); tr = task_a_trajectory(st); sa = task_a_state(tr)
    out['A_best'] = tr['best']; out['A_n0'] = st['n0']; out['A_p'] = st['p']
    for nm, f in A_RULES.items():
        T, C = [], []
        for q in GRID['A_' + nm]:
            o = outcome_a(sa, tr, f(sa, q)); T.append(o['t']); C.append(o['correct'])
        out[f'A_{nm}_t'] = np.array(T, np.int16); out[f'A_{nm}_c'] = np.array(C, bool)
    nb = outcome_a(sa, tr, np.ones((T_MAX + 1, n_trials), bool))
    out['A_NB_t'] = nb['t'].astype(np.int16); out['A_NB_c'] = nb['correct']
    gap, wid = _gap_width(sa)
    out['A_gap0'], out['A_wid0'] = gap[0], wid[0]
    for b in BETAS:
        ch, w = choose_ce_a(sa, np.zeros(n_trials, int), b, Z_BETA_A)
        out[f'A_beta{b:+.0f}_c'] = ch == tr['best']; out[f'A_beta{b:+.0f}_w'] = w
    if tuned is not None:
        zs = tuned['A_OVL']; cond = cond_ovl(sa, zs); o = outcome_a(sa, tr, cond)
        for b in BETAS:   # beta at the OVL* stopping state (exploratory)
            ch, w = choose_ce_a(sa, o['t'], b, Z_BETA_A)
            out[f'A_betaS{b:+.0f}_c'] = ch == tr['best']; out[f'A_betaS{b:+.0f}_w'] = w
        # brake signature over all trajectory states: counts per (gap bin, width bin) of states and of brakes
        gi = np.digitize(gap, GAP_EDGES) - 1; wi = np.digitize(wid, WID_EDGES) - 1
        for nm in ('OVL', 'CTR', 'ZSC'):
            br = ~A_RULES[nm](sa, tuned['A_' + nm])
            Nst = np.zeros((len(GAP_EDGES) - 1, len(WID_EDGES) - 1)); Nbr = np.zeros_like(Nst)
            np.add.at(Nst, (gi.ravel(), wi.ravel()), 1); np.add.at(Nbr, (gi.ravel(), wi.ravel()), br.ravel())
            out[f'A_sig_{nm}_n'], out[f'A_sig_{nm}_b'] = Nst, Nbr
        out['A_ovl0_tuned'] = cond[0]
    # Task B
    stb = task_b_streams(seed, n_trials); sb = task_b_state(stb)
    out['B_cong'] = stb['cong']; out['B_d'] = stb['d']
    for nm, f in B_RULES.items():
        T, C = [], []
        for q in GRID['B_' + nm]:
            o = outcome_b(sb, stb, f(sb, q)); T.append(o['t']); C.append(o['correct'])
        out[f'B_{nm}_t'] = np.array(T, np.int16); out[f'B_{nm}_c'] = np.array(C, bool)
    # Task C
    stc = task_c_streams(seed, n_trials)
    for b in BETAS:
        r = task_c_run(stc, b)
        out[f'C_beta{b:+.0f}_reward'] = r['reward']; out[f'C_beta{b:+.0f}_preg'] = r['pseudo_regret']
        out[f'C_beta{b:+.0f}_w'] = r['mean_width']
    return out


def tune_from(curves_list, t0):
    """Pooled reward rate over seeds for every grid value; argmax (ties -> the smallest parameter)."""
    res = {}
    for key, grid in GRID.items():
        task, nm = key.split('_', 1)
        num = sum(c[f'{task}_{nm}_c'].sum(axis=1) for c in curves_list)
        den = sum((c[f'{task}_{nm}_t'] + t0).sum(axis=1) for c in curves_list)
        rr = num / den
        res[key] = float(grid[int(np.argmax(rr))])
    return res
