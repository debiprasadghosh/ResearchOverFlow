"""Post-hoc checks for the P4 paper (A1-A4 written after the confirmatory verdicts, A5-A10 after the independent
review; no registered hypothesis is tested).

    python3 verify_p4_addendum.py > verify_p4_addendum_output.txt

A1  With the same log-radius on every input coordinate, the decoupled range of r = log(g.x) - log(h.x) is exactly
    r_hat -/+ 2 rho (homogeneity of degree one), so OVL_dec(z) is the rule |r_hat| > 2 z sigma / sqrt(t).
A2  On the confirmatory seeds, OVL_dec(z*) and |r_hat| > 2 z* sigma / sqrt(t) choose and stop identically on every trial.
A3  Coverage: the share of arms (Task A, t = 0, arms with >= 2 pre-observations) whose true log-odds lies inside
    the salience interval c -/+ z (G^-1/2 + S^-1/2), at the tuned z* and at z = 1.96.
A4  Exact over decoupled width on Task B states at the tuned z of the exact rule: congruent vs incongruent trials.
"""
import sys, os, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import p4lib as L

HERE = os.path.dirname(os.path.abspath(__file__))
T = json.load(open(os.path.join(HERE, 'tuned.json')))['primary']
rng = np.random.default_rng(5)

print('A1  decoupled range = r_hat -/+ 2 rho when every coordinate has log-radius rho')
lx = rng.normal(0, 1, (20000, 4)); rho = rng.uniform(0, 2, (20000, 1))
lo, hi = L.lr_range_decoupled(np.exp(lx - rho), np.exp(lx + rho))
r = L.lr_point(np.exp(lx))
print(f'    max |lower - (r - 2 rho)| = {np.abs(lo - (r - 2 * rho[:, 0])).max():.2e}, max |upper - (r + 2 rho)| = {np.abs(hi - (r + 2 * rho[:, 0])).max():.2e}')

print('A2  OVL_dec(z*) against |r_hat| > 2 z* sigma/sqrt(t) on seeds 1000-1019')
z = T['B_OVL_dec']; mism = 0
for s in L.CONF_SEEDS:
    st = L.task_b_streams(s, L.N_TRIALS); sb = L.task_b_state(st)
    o1 = L.outcome_b(sb, st, L.cond_b_ovl(sb, z, 'dec'))
    o2 = L.outcome_b(sb, st, np.abs(sb['r']) > 2 * z * sb['rad_unit'][..., 0])
    mism += int(np.sum(o1['t'] != o2['t']) + np.sum(o1['choice'] != o2['choice']))
print(f'    z* = {z}: trials that differ in stopping time or choice: {mism} of {len(L.CONF_SEEDS) * L.N_TRIALS}')

print('A3  coverage of the salience interval for the true log-odds (Task A, t = 0, arms with n0 >= 2)')
for zz in (T['A_OVL'], 1.0, 1.96):
    cov = {}
    for lv in (2, 8, 32):
        hit, n = 0, 0
        for s in L.CONF_SEEDS[:5]:
            st = L.task_a_streams(s, L.N_TRIALS); tr = L.task_a_trajectory(st)
            G, S = tr['G'][0], tr['S'][0]
            c = np.log(G) - np.log(S); w = zz * (1 / np.sqrt(G) + 1 / np.sqrt(S))
            lo_ = np.log(st['p'] / (1 - st['p']))
            m = st['n0'] == lv
            hit += int(np.sum((lo_ >= c - w) & (lo_ <= c + w) & m)); n += int(m.sum())
        cov[lv] = hit / n
    print(f'    z = {zz:4}: coverage n0=2 {cov[2]:.3f}, n0=8 {cov[8]:.3f}, n0=32 {cov[32]:.3f}')

print('A4  exact / decoupled width of the range of r (Task B, z = z* of the exact rule), by trial type and samples')
z = T['B_OVL_exact']
acc = {0: [], 1: []}
for s in L.CONF_SEEDS[:5]:
    st = L.task_b_streams(s, L.N_TRIALS); sb = L.task_b_state(st)
    lo, hi = L.task_b_bounds(sb, z, 'exact'); dlo, dhi = L.task_b_bounds(sb, z, 'dec')
    ratio = (hi - lo) / (dhi - dlo)
    for cg in (0, 1):
        acc[cg].append(ratio[:, st['cong'] == cg])
for cg, nm in ((1, 'congruent'), (0, 'incongruent')):
    rr = np.concatenate(acc[cg], axis=1)
    print(f'    {nm:11s}: t=1 {rr[0].mean():.3f}, t=5 {rr[4].mean():.3f}, t=20 {rr[19].mean():.3f}, t=60 {rr[59].mean():.3f}')


# ================================================================================================ after review
print('\n--- added after the independent review ---')
rngb = np.random.default_rng(20261011)
BI = rngb.integers(0, 20, (10000, 20))


def ci(d):
    d = np.asarray(d, float); m = d[BI].mean(1)
    return f'{d.mean():+.3f} [{np.percentile(m, 2.5):+.3f}, {np.percentile(m, 97.5):+.3f}]'


def tune_eval(make_cond, grid, task):
    """Tune one parameter on seeds 0-4 (pooled reward rate), evaluate on 1000-1019; returns per-seed RR (x1e3),
    the tuned value, accuracy and samples."""
    def curves(s):
        if task == 'A':
            st = L.task_a_streams(s, L.N_TRIALS); tr = L.task_a_trajectory(st); sa = L.task_a_state(tr)
            return [L.outcome_a(sa, tr, make_cond(sa, q)) for q in grid]
        st = L.task_b_streams(s, L.N_TRIALS); sb = L.task_b_state(st)
        return [L.outcome_b(sb, st, make_cond(sb, q)) for q in grid]
    tun = [curves(s) for s in L.TUNE_SEEDS]
    rr = [sum(c[i]['correct'].sum() for c in tun) / sum((c[i]['t'] + L.T0).sum() for c in tun) for i in range(len(grid))]
    i = int(np.argmax(rr))
    conf = [curves(s)[i] for s in L.CONF_SEEDS]
    return (np.array([1e3 * L.reward_rate(o['correct'], o['t']) for o in conf]), float(grid[i]),
            float(np.mean([o['correct'].mean() for o in conf])), float(np.mean([o['t'].mean() for o in conf])), conf)


def tuned_rr(task, nm, t0=None, key='primary'):
    tt = json.load(open(os.path.join(HERE, 'tuned.json')))[key]
    i = int(np.argmin(np.abs(L.GRID[f'{task}_{nm}'] - tt[f'{task}_{nm}'])))
    out = []
    for s in L.CONF_SEEDS:
        r = np.load(os.path.join(HERE, 'runs', f'seed{s}.npz'))
        out.append(1e3 * L.reward_rate(r[f'{task}_{nm}_c'][i], r[f'{task}_{nm}_t'][i], t0))
    return np.array(out)


print('A5  Task B: a fixed bound on summed evidence, |t r_hat| > A (no intervals), tuned on seeds 0-4')
tsamp = np.arange(1, L.T_MAX + 1)[:, None]
rrS, A_, accS, smpS, confS = tune_eval(lambda sb, q: np.abs(sb['r']) * tsamp > q, np.round(np.arange(0, 40.001, 0.25), 3), 'B')
print(f'    A* = {A_}; RR {rrS.mean():.3f}, accuracy {accS:.3f}, samples {smpS:.1f}')
for nm in ('OVL_dec', 'OVL_exact', 'CTR'):
    print(f'    minus {nm:9s}: {ci(rrS - tuned_rr("B", nm))}')

print('A6  Task A: a centre threshold that shrinks with time, gap > tau / sqrt(1 + t), tuned on seeds 0-4')
tA = np.arange(L.T_MAX + 1)[:, None]
rrT, tau_, accT, smpT, _ = tune_eval(lambda sa, q: L.cond_ctr(sa, 0.0) & (
    (L._leader_take(sa['c'], sa['lead']) - L._others_max(sa['c'], sa['lead'])) > q / np.sqrt(1 + tA)),
    np.round(np.arange(0, 4.001, 0.05), 3), 'A')
rO, rC = tuned_rr('A', 'OVL'), tuned_rr('A', 'CTR')
print(f'    tau* = {tau_}; RR {rrT.mean():.3f}, accuracy {accT:.3f}, samples {smpT:.1f}')
print(f'    minus CTR: {ci(rrT - rC)};  OVL minus it: {ci(rO - rrT)};  share of the OVL-CTR gain recovered {(rrT - rC).mean() / (rO - rC).mean():.2f}')
_m = (rO - rrT)[BI].mean(1) / rrT.mean() * 100
print(f'    OVL minus it, relative to its rate: {100 * (rO - rrT).mean() / rrT.mean():.2f}% [{np.percentile(_m, 2.5):.2f}%, {np.percentile(_m, 97.5):.2f}%]')

print('A7  Task B oracle (ZSC with the true se) against OVL_exact, paired')
EX = json.load(open(os.path.join(HERE, 'report', 'explore.json')))
rZT = 1e3 * np.array([p['rr'] for p in EX['per_seed']['B_ZSC_true']])
print(f'    ZSC_true minus OVL_exact: {ci(rZT - tuned_rr("B", "OVL_exact"))};  ZSC_true minus ZSC: {ci(rZT - tuned_rr("B", "ZSC"))}')

print('A8  Task B by trial type (seeds 1000-1019): accuracy / mean samples / share ending at the deadline')
TT = json.load(open(os.path.join(HERE, 'tuned.json')))['primary']
rows = {}
for s in L.CONF_SEEDS:
    st = L.task_b_streams(s, L.N_TRIALS); sb = L.task_b_state(st)
    conds = {nm: L.B_RULES[nm](sb, TT['B_' + nm]) for nm in ('OVL_exact', 'OVL_dec', 'CTR', 'ZSC')}
    conds['ZSC_true'] = np.abs(sb['r']) > EX['tuned']['B_ZSC_true'] * sb['rad_unit'][..., 0] * np.sqrt(
        ((np.subtract(*L.b_shares(np.log(st['x'])))) ** 2).sum(-1))[None]
    conds['SUM'] = np.abs(sb['r']) * tsamp > A_
    for nm, cd in conds.items():
        o = L.outcome_b(sb, st, cd)
        for cg in (1, 0):
            m = st['cong'] == cg
            rows.setdefault((nm, cg), []).append((o['correct'][m].mean(), o['t'][m].mean(), o['forced'][m].mean()))
for (nm, cg), v in rows.items():
    v = np.mean(v, 0)
    print(f'    {nm:9s} {"congruent  " if cg else "incongruent"}: {v[0]:.3f} / {v[1]:5.1f} / {v[2]:.3f}')

print('A9  Time-cost sensitivity, paired intervals (x1e3), parameters re-tuned at each T0')
for key in ('T0=20', 'T0=50', 'primary', 'T0=200'):
    t0 = L.T0 if key == 'primary' else float(key[3:])
    tt = json.load(open(os.path.join(HERE, 'tuned.json')))[key]
    edge = [k for k, v in tt.items() if v in (L.GRID[k][0], L.GRID[k][-1])]
    print(f'    {key:7s} A OVL-CTR {ci(tuned_rr("A", "OVL", t0, key) - tuned_rr("A", "CTR", t0, key))}  '
          f'A ZSC-OVL {ci(tuned_rr("A", "ZSC", t0, key) - tuned_rr("A", "OVL", t0, key))}  '
          f'B exact-CTR {ci(tuned_rr("B", "OVL_exact", t0, key) - tuned_rr("B", "CTR", t0, key))}  '
          f'B ZSC-exact {ci(tuned_rr("B", "ZSC", t0, key) - tuned_rr("B", "OVL_exact", t0, key))}  grid-edge: {edge}')

print('A11 Task B: the linearised exact rule |r_hat| > q sigma ||a - b||_1 / sqrt(t), with shares from the true input or the\n'
      '    plug-in estimate (tuned on seeds 0-4): does a raised bound on conflict trials buy accuracy when its width is noise-free?')
for lab, true_ in (('true shares', True), ('plug-in shares', False)):
    def mk(sb, q, true_=true_):
        lx = np.log(sb['x_true'])[None].repeat(L.T_MAX, 0) if true_ else sb['lx']
        a_, b_ = L.b_shares(lx)
        return np.abs(sb['r']) > q * sb['rad_unit'][..., 0] * np.abs(a_ - b_).sum(-1)
    _orig = L.task_b_state
    L.task_b_state = lambda st, _o=_orig: dict(_o(st), x_true=st['x'])
    rrL, qL, accL, smpL, confL = tune_eval(mk, np.round(np.arange(0, 3.001, 0.05), 3), 'B')
    L.task_b_state = _orig
    inc = [];
    for s_, o in zip(L.CONF_SEEDS, confL):
        cg = L.task_b_streams(s_, L.N_TRIALS)['cong'] == 0
        inc.append((o['correct'][cg].mean(), o['t'][cg].mean()))
    inc = np.mean(inc, 0)
    print(f'    {lab:14s}: q* = {qL}; RR {rrL.mean():.3f}; incongruent accuracy {inc[0]:.3f} at {inc[1]:.1f} samples; minus OVL_dec {ci(rrL - tuned_rr("B", "OVL_dec"))}')

print('A10 Task A tuned rules: share of trials truly forced (no stop before the deadline) vs ending at t = 60')
for nm in ('OVL', 'CTR', 'ZSC'):
    tf, t60 = [], []
    for s in L.CONF_SEEDS[:5]:
        st = L.task_a_streams(s, L.N_TRIALS); tr = L.task_a_trajectory(st); sa = L.task_a_state(tr)
        o = L.outcome_a(sa, tr, L.A_RULES[nm](sa, TT['A_' + nm])); tf.append(o['forced'].mean()); t60.append((o['t'] == L.T_MAX).mean())
    print(f'    {nm}: forced {np.mean(tf):.4f}, ending at 60 {np.mean(t60):.4f} (seeds 1000-1004)')
