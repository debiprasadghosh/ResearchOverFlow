# P4 supplement: A Brake That Acts When Action Ranges Overlap

Debi Prasad Ghosh, 11 October 2026. Everything needed to reproduce the paper's numbers and figures.

## Contents
- `PROTOCOL.md`, `evals_code_sha256.txt`: the frozen protocol and SHA-256 hashes (frozen 2026-10-11T10:07:17Z).
- Frozen code:
  - `p4lib.py`: tasks, rules and grids;
  - `p4_tune.py`: tuning on seeds 0-4;
  - `p4_runs.py`: confirmatory seeds 1000-1019;
  - `p4_eval.py`: decision rules;
  - `verify_p4_theory.py`: 28 checks.
- Written after the verdicts:
  - `p4_explore.py`: exploratory rules;
  - `p4_report.py`: facts and figures, revised after review;
  - `verify_p4_addendum.py`: A1-A4 after the verdicts, A5-A11 after the independent review.
- Outputs:
  - `tuned.json`;
  - `evals/decisions.json` (registered verdicts);
  - `report/facts.json`, `report/explore.json`, `report/tuning_curves.npz`;
  - `verify_*_output.txt`;
  - `figs/`;
  - `runs/seed*.npz` (per-trial outcomes on every grid value).
- `pilot/`: pre-freeze pilot and smoke-test scripts. Their printed outputs were not archived. The scripts import the frozen library, so pilots at other T0 and sigma need the constants edited.

## Reproduce
```
python3 verify_p4_theory.py > verify_p4_theory_output.txt
python3 p4_tune.py && python3 p4_runs.py && python3 p4_eval.py
python3 p4_explore.py && python3 p4_report.py
python3 verify_p4_addendum.py > verify_p4_addendum_output.txt
```
Python 3.11.15, NumPy 2.4.4, Matplotlib 3.10.9; about 15 minutes on two cores.
