"""Tune every rule's single parameter on the tuning seeds (0-4) at the primary time cost and at each
exploratory time cost.  Writes tuned.json and report/tuning_curves.npz.

    python3 p4_tune.py
"""
import sys, os, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import p4lib as L

HERE = os.path.dirname(os.path.abspath(__file__))
curves = [L.simulate_seed(s) for s in L.TUNE_SEEDS]
tuned = {'primary': L.tune_from(curves, L.T0), 'T0': L.T0}
for t0 in L.T0_SENS:
    tuned[f'T0={t0:g}'] = L.tune_from(curves, t0)
json.dump(tuned, open(os.path.join(HERE, 'tuned.json'), 'w'), indent=1)
os.makedirs(os.path.join(HERE, 'report'), exist_ok=True)
save = {}
for key, grid in L.GRID.items():
    task, nm = key.split('_', 1)
    num = sum(c[f'{task}_{nm}_c'].sum(axis=1) for c in curves)
    den = sum((c[f'{task}_{nm}_t'] + L.T0).sum(axis=1) for c in curves)
    save[key] = num / den; save[key + '_grid'] = grid
np.savez(os.path.join(HERE, 'report', 'tuning_curves.npz'), **save)
print(json.dumps(tuned, indent=1))
