import sys, time; sys.path.insert(0,'..'); sys.path.insert(0,'.')
import numpy as np, p4lib as L
t0=time.time()
for seed in (900,901):
    st=L.task_a_streams(seed,2000); tr=L.task_a_trajectory(st); sa=L.task_a_state(tr)
    out={}
    for nm,f,grid in [('OVL',L.cond_ovl,L.GRID['A_OVL']),('CTR',L.cond_ctr,L.GRID['A_CTR']),('ZSC',L.cond_zsc,L.GRID['A_ZSC'])]:
        rr=[]
        for q in grid:
            o=L.outcome_a(sa,tr,f(sa,q)); rr.append(L.reward_rate(o['correct'],o['t']))
        i=int(np.argmax(rr)); o=L.outcome_a(sa,tr,f(sa,grid[i]))
        out[nm]=(grid[i],rr[i],o['correct'].mean(),o['t'].mean(),o['forced'].mean())
    o=L.outcome_a(sa,tr,np.ones((61,2000),bool)); out['NB']=(0,L.reward_rate(o['correct'],o['t']),o['correct'].mean(),0,0)
    print('A',seed,{k:tuple(np.round(v,4)) for k,v in out.items()})
    st=L.task_b_streams(seed,2000); sb=L.task_b_state(st); out={}
    for nm,f,grid in [('OVLx',lambda s,q:L.cond_b_ovl(s,q,'exact'),L.GRID['B_OVL_exact']),('OVLd',lambda s,q:L.cond_b_ovl(s,q,'dec'),L.GRID['B_OVL_dec']),('CTR',L.cond_b_ctr,L.GRID['B_CTR'])]:
        rr=[]
        for q in grid:
            o=L.outcome_b(sb,st,f(sb,q)); rr.append(L.reward_rate(o['correct'],o['t']))
        i=int(np.argmax(rr)); o=L.outcome_b(sb,st,f(sb,grid[i]))
        out[nm]=(grid[i],rr[i],o['correct'].mean(),o['t'].mean(),o['forced'].mean(), o['correct'][st['cong']==1].mean(),o['correct'][st['cong']==0].mean(),o['t'][st['cong']==1].mean(),o['t'][st['cong']==0].mean())
    print('B',seed,{k:tuple(np.round(v,3)) for k,v in out.items()})
    st=L.task_c_streams(seed,1000)
    print('C',seed,[(b,round(L.task_c_run(st,b)['pseudo_regret'].mean(),2)) for b in L.BETAS])
print(time.time()-t0)
