import sys; sys.path.insert(0,'.')
import numpy as np, p4lib as L
def best(rrf, grid): 
    rr=[rrf(q) for q in grid]; i=int(np.argmax(rr)); return grid[i], rr[i]
for T0 in (20.,50.):
    L.T0=T0
    for seed in (900,901):
        st=L.task_a_streams(seed,2000); tr=L.task_a_trajectory(st); sa=L.task_a_state(tr)
        res={}
        for nm,f,grid in [('OVL',L.cond_ovl,L.GRID['A_OVL']),('CTR',L.cond_ctr,L.GRID['A_CTR']),('ZSC',L.cond_zsc,L.GRID['A_ZSC'])]:
            def rrf(q):
                o=L.outcome_a(sa,tr,f(sa,q)); return L.reward_rate(o['correct'],o['t'])
            q,r=best(rrf,grid); o=L.outcome_a(sa,tr,f(sa,q)); res[nm]=(q,round(r,5),round(o['correct'].mean(),3),round(o['t'].mean(),1),round(o['forced'].mean(),3))
        print('A T0',T0,seed,res)
    for sig in (2.,3.):
        L.SIGMA_B=sig
        for seed in (900,):
            st=L.task_b_streams(seed,2000); sb=L.task_b_state(st); res={}
            for nm,f,grid in [('OVLx',lambda s,q:L.cond_b_ovl(s,q,'exact'),L.GRID['B_OVL_exact']),('OVLd',lambda s,q:L.cond_b_ovl(s,q,'dec'),L.GRID['B_OVL_dec']),('CTR',L.cond_b_ctr,L.GRID['B_CTR'])]:
                def rrf(q):
                    o=L.outcome_b(sb,st,f(sb,q)); return L.reward_rate(o['correct'],o['t'])
                q,r=best(rrf,grid); o=L.outcome_b(sb,st,f(sb,q)); c=st['cong']==1
                res[nm]=(q,round(r,5),round(o['correct'].mean(),3),round(o['t'].mean(),1),round(o['forced'].mean(),3),round(o['t'][c].mean(),1),round(o['t'][~c].mean(),1))
            print('B T0',T0,'sig',sig,seed,res)
