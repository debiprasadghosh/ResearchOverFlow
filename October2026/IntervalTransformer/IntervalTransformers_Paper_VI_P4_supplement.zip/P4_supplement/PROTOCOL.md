# P4 protocol: the hyperdirect pathway as a brake that acts when action ranges overlap

Frozen with `p4lib.py`, `p4_tune.py`, `p4_runs.py`, `p4_eval.py` and `verify_p4_theory.py` before any tuning or
confirmatory run. The hashes are in `evals_code_sha256.txt`. The evaluator applies the decision rules itself.

## Model (agenda, P4)

Go deck $Y^+=B^+XA^{+\top}$, Stop deck $Y^-=B^-XA^{-\top}$, salience $s(c)=\theta+S^+(c)-S^-(c)$. The brake is
released, and the leader acts, when the lower salience of the leader exceeds the upper salience of every other
channel (rule **OVL**). Otherwise the agent keeps sampling, up to a deadline of 60 samples, after which it acts
on the centre leader.

## Tasks

- **Task A (dissociated bandit; Proposition C(a)).** 4 Bernoulli arms, $p_c\sim U(0.2,0.8)$; familiarity
  $n_{0,c}\in\{0,2,8,32\}$ pre-observations, drawn independently of $p_c$. $G_c$ = successes + 1 and $S_c$ = failures + 1.
  The centre is $\log G_c-\log S_c$, with Go and Stop log-radii $z/\sqrt{G_c}$ and $z/\sqrt{S_c}$. A shared sampling
  policy samples the less-observed of the centre leader and the rival with the largest centre $+\,1\cdot$(radius at $z=1$).
  A choice is correct if it is the arm with the largest $p$.
- **Task B (conflict; Proposition C(b)).** Features $[t_L,t_R,f_L,f_R]$: the target 1.0 on its side and 0.2 on the
  other; flankers 1.5 on their side (the target's side if congruent) and 0.2 on the other. Each sample observes every
  feature with log-normal noise $\sigma=2$. $g=[1,0.2,0.4,0.1]$, $h=[0.2,1,0.1,0.4]$, $r=\log g\!\cdot\!x-\log h\!\cdot\!x$,
  $s_{L/R}=\theta\pm r$. The input box is the geometric mean $\pm z\sigma/\sqrt t$ in log space.
- **Task C (repeated bandit; Proposition F).** 4 Bernoulli arms, $p\sim U(0.2,0.8)$, 200 pulls. Each pull goes to
  $\arg\max\mathrm{CE}_\beta$ under the uniform law on the Go and Stop log-factor intervals ($z=1$).

## Rules (one parameter each, tuned)

| Rule | Act when |
|---|---|
| OVL($z$) | leader's lower salience > every rival's upper salience (Task A: radii $z(G^{-1/2}+S^{-1/2})$) |
| OVL_exact($z$), OVL_dec($z$) | Task B: the exact (threshold-vertex) or decoupled range of $r$ excludes 0 |
| CTR($\tau$) | centre gap to the runner-up $>\tau$ (Task B: $\lvert\hat r\rvert>\tau$) |
| ZSC($\kappa$) | standardised gap $>\kappa$: Task A $\min_j (c_l-c_j)/\sqrt{v_l+v_j}$, $v=1/G+1/S$; Task B $\lvert\hat r\rvert/\mathrm{se}$, se by the delta method |
| NB | act at once (Task A, $t=0$) |

**Reward rate** = correct choices / (samples + $T_0$), with $T_0=100$ (primary). $T_0\in\{20,50,200\}$ are exploratory.

## Seeds, tuning, statistics

- Tuning seeds 0–4: each rule's parameter maximises the pooled reward rate over its grid (`p4lib.GRID`).
- Confirmatory seeds 1000–1019, 2000 trials each. Every rule reads the same trajectories (exact pairing).
- Statistic: the mean over the 20 seeds of the paired per-seed difference, with a 95% bootstrap interval (10,000 resamples).
  **Supported** if the interval is above 0, **rejected** if it is below 0, **inconclusive** otherwise.

## Registered hypotheses

| | Prediction | Basis |
|---|---|---|
| H1 | Task A: RR(OVL\*) > RR(CTR\*). **Kill criterion: if H1 is not supported, P4 is dropped.** | agenda; pilot-informed |
| H2 | Task B: RR(OVL_exact\*) > RR(CTR\*) | agenda; pilot-informed |
| H3 | Task B: RR(OVL_dec\*) > RR(OVL_exact\*) | pilot-informed (the pilot reversed our prior); linearisation, Prop. 2 |
| H4a | Task A: RR(ZSC\*) > RR(OVL\*) | Prop. 5 (the overlap rule is an ℓ1 statistic, the noise is ℓ2) |
| H4b | Task B: RR(ZSC\*) > RR(OVL_exact\*) | Prop. 2 linearisation; not piloted before the smoke test |
| H5a | Task A, $t=0$: the mean width of the chosen arm's salience interval increases at every step of $\beta\in\{-8,-2,0,2,8\}$ | Prop. F; not piloted |
| H5b | Task A, $t=0$: accuracy at $\beta=0$ exceeds accuracy at $\beta=+8$ and at $\beta=-8$ | Prop. F; not piloted |
| H5c | Task C: pseudo-regret at $\beta=2$ is below that at $\beta=0$ | optimism; pilot-informed |

H5a needs all four adjacent differences above 0, and is rejected if any is below 0. H5b needs both differences above 0.

**Checks (by construction, reported):** C1, brake locality: OVL\* and NB agree on every trial that does not overlap
at $t=0$. P4.1 (braking tracks overlap at a fixed centre gap) is reported as a brake-probability map over states.

**Exploratory:** reward rate against parameter on the confirmatory seeds; sensitivity to $T_0$; the β effect at the
OVL\* stopping state; congruency effects in Task B; the "lesion" map (error increase from removing the brake, by
initial centre gap and initial width).

## Pilots (before freezing)

1. Seeds 900–901 at $T_0=5$, $\sigma=1$: every rule's optimum was to act at once (degenerate).
2. $T_0\in\{20,50\}$, $\sigma\in\{2,3\}$: still near-degenerate in Task A.
3. $T_0\in\{100,200\}$: OVL beat CTR in both tasks by 4–8%, and ZSC and OVL were close in Task A. In Task B the
   decoupled range beat the exact one, against our prior. That led to H3's direction and to adding ZSC in Task B.
   Task C: pseudo-regret fell monotonically in β over $\{-8,\dots,8\}$.
4. Smoke test of the full pipeline: tuning on seed 902, two "confirmatory" seeds 900–901 with 300 trials. It produced
   verdicts: H1, H2, H5a, H5b, H5c supported; H3, H4a inconclusive; H4b rejected; C1 pass. No hypothesis or rule changed after it.

Pilot calibration chose $T_0=100$ and $\sigma=2$. H1, H2, H3 and H5c were therefore not blind.
