# A Brake That Acts When Action Ranges Overlap: Interval Salience, the Hyperdirect Pathway and Reward Rate

**Debi Prasad Ghosh**

Debias Parametric Guru, Kolkata, India | debiprasadghosh@gmail.com

11 October 2026 · P4 of the log interval network programme · Pre-specified protocol executed, with reproducible scripts

---

**Abstract.** In the double-decker basal-ganglia model [5], a Go deck and a Stop deck compute positive strengths from the same cortical input. A channel's salience is their log ratio, so if the decks or the input carry log intervals, each salience is an interval. The research agenda [6] registered P4:

- **The rule.** Act when the lower salience of the leading channel exceeds the upper salience of every other channel; otherwise brake and keep gathering evidence. This is an interval form of the conflict signal that the subthalamic nucleus (STN) provides in Frank's model [7].
- **Risk.** A parameter $\beta$ picks the operating point inside each interval.
- **Kill criterion.** The rule is dropped if it does not beat a tuned threshold on the difference of interval centres in reward rate.

We prove six propositions and check them numerically.

- **Exact ranges.** The salience range is exact by two passes when only the factors are intervals. It is exact at a threshold vertex when the factors are crisp and the input is a shared interval. The *decoupled* bound, which treats numerator and denominator separately, is sound but wider. With equal input radii it is exactly the point estimate $\pm2\rho$.
- **What the rule is.** It is a centre threshold whose height is the two intervals' summed width. Removing it changes behaviour only on trials whose initial intervals overlap. It is an $\ell_1$ statistic, at most twice as conservative as a standardised gap.
- **Risk.** Under a uniform law, the certainty equivalent $\mathrm{CE}_\beta$ moves monotonically from one end of the interval to the other without changing its width.

We then ran three simulated tasks under a protocol frozen before the tuning and confirmatory runs: 20 confirmatory seeds of 2,000 trials each, with each rule's single parameter tuned on 5 other seeds.

**The registered verdicts.**

- **Kill criterion: passed.** The overlap brake earned 4.5% more reward per unit time than the tuned centre threshold in a four-armed bandit where familiarity was independent of value: 5.89 against 5.64 correct choices per 1000 time units (paired +0.25 [0.23, 0.28]). In a flanker-style conflict task it earned 7.4% more. Both margins held at time costs of 50–200; at 20 the bandit margin was inconclusive.
- **Exactness.** In the conflict task the loose decoupled interval beat the exact one by 2.8% (pilot-informed).
- **Standardisation.** A standardised rule lost to the exact interval by 2.5% (rejected). An oracle check suggests plug-in noise in its standard error explains the loss.
- **Risk.** Raising $\beta$ moved choices toward wide intervals at every step. The centre ($\beta=0$) was most accurate for one-shot choice, while optimism ($\beta=2$) cut regret by 23% in a repeated bandit.

**After review, stronger baselines change the reading.** The registered baseline holds its threshold fixed on the *mean* of the evidence.

- **Task A.** A centre threshold that merely shrinks with time recovers 73% of the overlap brake's gain. Against this baseline the overlap brake retains 1.2% [0.7%, 1.7%].
- **Task B.** A $1/t$ bound on the mean, in which $t\lvert\hat r\rvert$ approximates summed evidence, uses no intervals at all. It beats every interval rule, the decoupled one by 0.9%.

**What this means.** The overlap brake survives its kill criterion, but most of its advantage is the time course of its threshold, which simple non-interval bounds also provide. Its reward-optimal radius covered the true value only 43–54% of the time, so it is a heuristic, not a certificate.

**Keywords** basal ganglia; subthalamic nucleus; hyperdirect pathway; speed–accuracy trade-off; interval analysis; best-arm identification; risk-sensitive choice; reward rate

# 1 Introduction

The log interval network programme carries every positive quantity with a log interval and asks which decisions survive every tolerated model [1, 2]. P1 studied readouts and evidence accumulation [3], P2 attention [4] and P3 memory. P4 studies action selection in the double-decker basal-ganglia (BG) model [5].

**The model.** In that model, a Go deck $Y^+=B_+XA_+^\top$ and a Stop deck $Y^-=B_-XA_-^\top$ read the same positive cortical input $X$.

- **Salience.** A channel's salience is $s(c)=\theta+S_+(c)-S_-(c)$, with $S_\pm(c)=\log\sum_{j\in c}Y^\pm_j$.
- **Selection.** $\pi(c\mid s)\propto e^{s(c)}$.

The agenda [6] showed that the salience is exact by two passes when only the factors carry intervals. With an interval input, the threshold solver of the Interval Transformer makes it exact [1]. The agenda then asked what a decision maker should do with salience *intervals*, and registered a rule borrowed from the hyperdirect pathway.

**The hyperdirect pathway.** Cortex projects directly onto the STN, which excites the output nuclei broadly and so holds back every action [8].

- **Frank's model [7].** The STN signal grows with conflict, that is, with coactivation of competing Go representations, and raises the decision threshold until the conflict resolves.
- **Stimulation studies.** STN deep-brain stimulation makes patients choose faster and worse in high-conflict choices [9]. STN stimulation also reverses the influence of mediofrontal theta over the decision threshold [10].
- **Stopping.** The STN takes part in stopping [11].

**The registered rule.** Two channels conflict, in interval form, when their salience intervals overlap. When the channels' uncertainties are independent, overlap means that some tolerated model ranks them differently or ties them. The registered rule (P4) brakes exactly then.

**The kill criterion.** The agenda drops the rule "if the overlap brake does not improve reward rate over the tuned centre-difference threshold" [6]. That baseline is uncertainty-blind, as a conflict signal that reads only the centres would be.

**Contributions.**

1. **Theory (Section 3).** Six propositions, with 28 frozen numerical checks and post-hoc checks A1–A11.
   - The salience range is exact for interval factors (Proposition 1), and for a shared interval input with crisp factors (Proposition 2).
   - The overlap brake is a width-dependent centre threshold (Proposition 3), local to overlap and monotone in width (Proposition 4).
   - It is an $\ell_1$ statistic within a factor of 2 of the standardised gap (Proposition 5).
   - $\mathrm{CE}_\beta$ under the uniform law has a closed form and moves monotonically through the interval (Proposition 6).
2. **A frozen experiment (Sections 4–5).**
   - *Tasks.* Task A is a four-armed best-arm choice with familiarity independent of value. Task B is a flanker-style conflict task with a shared interval input. Task C is a repeated bandit.
   - *Hypotheses.* Eight registered hypotheses, plus one check.
3. **Exploratory and post-review analyses (Sections 5–7).**
   - *Baselines.* A Bayesian stopping rule, an oracle standard error, and, after review, two non-interval baselines that let the threshold change with time.
   - *Lesion map.* The cost of removing the brake, by initial gap and width.
   - *Coverage.* How often the tuned intervals contain the true value.

**Related work.**

- **Stopping rules.** The overlap rule is not new as a stopping rule. It is the stopping condition of action elimination [12] and of LUCB in best-arm identification [13]: stop when the leader's lower confidence bound clears every rival's upper bound. Those works choose radii to guarantee a probability of error. Here the radius is tuned for reward rate, and the intervals come from opponent decks.
- **Standardised statistics.** The standardised gap is close in spirit to generalised likelihood-ratio stopping [14].
- **Reward-rate optimal bounds.** In the drift-diffusion model, the reward-rate optimal policy for a fixed difficulty is a fixed bound on *accumulated* evidence [15]. When difficulty varies from trial to trial, optimal bounds collapse over time [16, 17].
- **The BG and the STN.** Bogacz and Gurney mapped the multihypothesis sequential probability ratio test onto the BG, with the STN as a normaliser [18].
- **Coordinate spaces.** Our registered rules threshold the *mean* of the evidence, not its sum. A fixed threshold on the mean is a bound that grows linearly on the sum. We return to this in Section 5.2.

# 2 Model

**Interval factors.** The decks are positive, so each deck strength $S_\pm(c)$ is a log-sum of positive terms. When $B_\pm$ and $A_\pm$ carry log intervals and $X$ is crisp, each $S_\pm(c)$ has an exact range from two passes, $[S_\pm^\downarrow(c),S_\pm^\uparrow(c)]$ [6]. The Go and Stop factors are disjoint, so
$$
s(c)\in\big[\theta+S_+^\downarrow-S_-^\uparrow,\ \theta+S_+^\uparrow-S_-^\downarrow\big].
$$

**Interval input.** When $X$ is an interval shared by both decks and the factors are crisp, the Go and Stop strengths move together, and the range solves a linear-fractional program (Proposition 2). Interval factors *and* an interval input together would make the problem bilinear; we do not treat that case.

**Rules.** Each channel has a salience interval $[\underline s(c),\overline s(c)]$ with centre $m(c)$, and $\ell=\arg\max_cm(c)$ is the centre leader.

- **OVL (overlap brake, registered).** Act on $\ell$ iff $\underline s(\ell)>\max_{c\neq\ell}\overline s(c)$; otherwise brake and sample again.
- **CTR (centre threshold, the registered baseline).** Act iff $m(\ell)-\max_{c\neq\ell}m(c)>\tau$.
- **ZSC (standardised gap, ours).** Act iff $\min_{c\neq\ell}\,(m(\ell)-m(c))/\mathrm{se}(\ell,c)>\kappa$.

A deadline forces the centre leader. *Reward rate* is correct choices per unit time, where each trial costs its samples plus a fixed non-decision time $T_0$ (as in [15]).

**Risk.** Proposition F of the agenda [6] defines the certainty equivalent $\mathrm{CE}_\beta(R)=\beta^{-1}\log\mathbb E\,e^{\beta R}$ of a salience $R$ with a law over its box. It is optimistic for $\beta>0$ and pessimistic for $\beta<0$. The agenda attributes $\beta$ to tonic dopamine. Choosing $\arg\max_c\mathrm{CE}_\beta(s(c))$ picks a point inside each interval.

# 3 Theory

Throughout, a Go log-factor $a$ ranges over $[\mu_G-\rho_G,\mu_G+\rho_G]$ and a Stop log-factor $b$ over $[\mu_S-\rho_S,\mu_S+\rho_S]$, with $s=\theta+a-b$ and centre $m=\theta+\mu_G-\mu_S$. Section 4.5 lists the numerical checks.

**Proposition 1 (interval factors).** With a crisp input, the salience range is exactly $m\pm(\rho_G+\rho_S)$. It is attained at the corners $(a^\uparrow,b^\downarrow)$ and $(a^\downarrow,b^\uparrow)$.

*Proof.* $s$ is increasing in $a$ and decreasing in $b$, and the two vary independently. $\square$

**Proposition 2 (shared interval input, crisp factors).** Let $g,h\in\mathbb R^n_{>0}$, let $x$ range over a positive box $[x^\downarrow,x^\uparrow]$, and let $r(x)=\log(g\!\cdot\!x)-\log(h\!\cdot\!x)$.

(a) *Threshold vertex.* The maximum of $r$ is attained at a vertex where $x_k=x_k^\uparrow$ iff $g_k/h_k$ exceeds a threshold. The minimum is the mirror image. Sorting by $g_k/h_k$ and checking the $n+1$ thresholds, with prefix sums, takes $O(n\log n)$. Our implementation recomputes each sum, which is $O(n^2)$ and immaterial at $n=4$.

(b) *Decoupled bound.* $[\log g\!\cdot\!x^\downarrow-\log h\!\cdot\!x^\uparrow,\ \log g\!\cdot\!x^\uparrow-\log h\!\cdot\!x^\downarrow]$ contains the exact range.

(c) *Naive corner.* Reading both ends at one common corner is not sound.

(d) *Linearisation.* Write $x=\hat x\circ e^{\delta}$ with $|\delta_k|\le\rho_k$, and define the shares $a_k=g_k\hat x_k/g\!\cdot\!\hat x$ and $b_k=h_k\hat x_k/h\!\cdot\!\hat x$, so that $\nabla_\delta r=a-b$. As $\rho\to0$:

- the exact half-width is $\sum_k\rho_k|a_k-b_k|$;
- the decoupled half-width is $\sum_k\rho_k(a_k+b_k)$.

Since $|a_k-b_k|<a_k+b_k$ termwise (all entries are positive), the exact range is strictly narrower to first order whenever some $\rho_k>0$. With equal radii the half-widths are $\rho\lVert a-b\rVert_1$ and $2\rho$.

(e) *Equal radii.* If $\rho_k=\rho$ for all $k$, the decoupled range is exactly $r(\hat x)\pm2\rho$ at every $\rho$, not only to first order. The first-order form was in the frozen checks and in H3's registered basis; the exact identity was noticed after the confirmatory runs (check A1).

*Proof.*

- (a) The ratio $g\!\cdot\!x/h\!\cdot\!x$ is quasi-linear, so its maximum $\lambda^\ast$ is at a vertex, where $x_k$ is high exactly when $g_k-\lambda^\ast h_k>0$ [19, 20]. This is the switch point of Karnik and Mendel [21].
- (b) Each term is bounded separately.
- (c) The frozen check P2 finds boxes where it misses part of the range.
- (d) First-order Taylor expansion.
- (e) $g\!\cdot\!(\hat xe^{\pm\rho})=e^{\pm\rho}\,g\!\cdot\!\hat x$.

$\square$

On random boxes the decoupled range was a median 4.1 times as wide as the exact one; the agenda's L3 construction gave 1.87 times [6].

**Proposition 3 (what the overlap brake is).** Assume each channel's interval is symmetric about its centre, with half-width $w(c)$. This is the setting of Task A, with $w=z(G^{-1/2}+S^{-1/2})$; independence of the channels is needed only to read overlap as a possible reversal, not for the identity. Then OVL acts iff
$$
m(\ell)-m(c)>w(\ell)+w(c)\quad\text{for every }c\neq\ell ,
$$
a centre threshold whose height depends on the state. If every channel has the same half-width $zu$ in every state, OVL at multiplier $z$ is exactly CTR at $\tau=2zu$. Any reward-rate difference between them then comes from variation in width.

*Proof.* Substitute $\underline s(\ell)=m(\ell)-w(\ell)$ and $\overline s(c)=m(c)+w(c)$. If some channel $j$ has $\underline s(j)>\overline s(c)$ for all $c\neq j$, then $m(j)\ge\underline s(j)>\overline s(c)\ge m(c)$, so $j$ is the centre leader. $\square$

In Task B, CTR thresholds the point estimate $\hat r$, which is not the midpoint of the exact range of $r$ (the range is asymmetric). Proposition 3 therefore does not transfer to Task B directly.

**Proposition 4 (locality and pointwise monotonicity).**

(a) *Locality.* An agent with the overlap brake and an agent with no brake choose identically on every trial whose initial state does not overlap.

(b) *Monotonicity.* At fixed centres, widening any interval can only add braking: the set of braking states grows pointwise with width.

*Proof.* (a) On such a trial the braking agent acts at $t=0$ on the same leader. (b) Widening lowers $\underline s(\ell)$ and raises every $\overline s(c)$. $\square$

**What this makes of P4.1 and P4.3.**

- **P4.3.** Its "only" ("removing the brake raises errors *only* on trials whose intervals overlap") is a property of the rule, by (a). That errors actually *rise* on overlap trials is empirical.
- **P4.1.** Pointwise, (b) makes braking monotone in width. A brake map that bins states by gap and width (Figure 3) visualises this definition and need not be exactly monotone, since bins mix states.
- **Their empirical content.** It lies in the brain: whether braking and STN-lesion effects follow overlap rather than the centre gap (Section 8).

**Proposition 5 (overlap is $\ell_1$, noise is $\ell_2$).** In Task A, with radii $z/\sqrt G$ and $z/\sqrt S$ and $\mathrm{se}(\ell,c)=\sqrt{v_\ell+v_c}$, where $v=1/G+1/S$:

- the overlap threshold for the pair $(\ell,c)$ is $z$ times the $\ell_1$ norm $u$ of the four terms $(G_\ell^{-1/2},S_\ell^{-1/2},G_c^{-1/2},S_c^{-1/2})$;
- $\mathrm{se}$ is their $\ell_2$ norm.

Since $\mathrm{se}\le u\le2\,\mathrm{se}$, OVL($z$) implies ZSC($z$), and ZSC($2z$) implies OVL($z$). The ratio $u/\mathrm{se}$ is 2 when the four terms are equal. It approaches 1 when one term dominates, that is, when one count is much smaller than the others.

*Proof.* $\lVert y\rVert_2\le\lVert y\rVert_1\le2\lVert y\rVert_2$ for $y\in\mathbb R^4$. $\square$

On Task A's states $u/\mathrm{se}$ ranged from 1.56 to 2.00, so the two rules differ little there.

**Proposition 6 (risk inside the box).** Let $a$ and $b$ be independent and uniform on their intervals, and let $f_\beta(\rho)=\beta^{-1}\log\big(\sinh(\beta\rho)/(\beta\rho)\big)$ with $f_0=0$. Then:

(a) *Closed form.* $\mathrm{CE}_\beta(s)=\theta+\mathrm{CE}_\beta(a)-\mathrm{CE}_{-\beta}(b)=m+f_\beta(\rho_G)+f_\beta(\rho_S)$.

(b) *Monotonicity.* $\mathrm{CE}_\beta$ is nondecreasing in $\beta$. It tends to $m+\rho_G+\rho_S$ as $\beta\to\infty$, with a gap of $\beta^{-1}[\log(2\beta\rho_G)+\log(2\beta\rho_S)]+o(1/\beta)$, and to the lower end as $\beta\to-\infty$. It equals $m$ at $\beta=0$.

(c) *Widths.* $\beta$ changes the point chosen inside each interval, not the interval. $f_\beta$ is increasing in $\rho$ for $\beta>0$ and decreasing for $\beta<0$, so optimism favours wide intervals and pessimism narrow ones. As $\beta\to\pm\infty$ the choice becomes the upper- [22] or lower-confidence-bound choice [23] with radius $\rho_G+\rho_S$.

*Proof.*

- (a) Independence factorises $\mathbb Ee^{\beta(a-b)}$, and $\mathbb Ee^{\beta U}=\sinh(\beta\rho)/(\beta\rho)$ for $U$ uniform on $[-\rho,\rho]$. $f$ is odd in $\beta$.
- (b) $\mathrm{CE}_\beta=\log M_\beta(e^s)$, where $M_\beta$ is the power mean of order $\beta$, which is nondecreasing in its order [24]. The gap follows from $\log(\sinh x/x)=x-\log(2x)+o(1)$.
- (c) $\frac{d}{dx}\log(\sinh x/x)=\coth x-1/x>0$ for $x>0$.

$\square$

Proposition 6(c) makes P4.2's "without changing interval widths" true by construction. What is left to test is the direction and size of the effect on choices.

# 4 Tasks, rules and protocol

## 4.1 Tasks

**Task A: dissociated bandit (Proposition 1).**

- **Arms.** Four Bernoulli arms, $p_c\sim U(0.2,0.8)$.
- **Familiarity.** Each arm has $n_{0,c}\in\{0,2,8,32\}$ pre-observations, drawn independently of $p_c$.
- **Decks.** $G_c$ = successes + 1 and $S_c$ = failures + 1. The centre is $\log G_c-\log S_c$, a log-odds estimate. The Go and Stop log-radii are $z/\sqrt{G_c}$ and $z/\sqrt{S_c}$.
- **What sets the width.** Familiarity, the samples taken during the trial, and, at a fixed count, the split between successes and failures.
- **Correct choice.** The arm with the largest $p$.
- **Sampling.** One policy is shared by every rule: sample the less-observed of the centre leader and the rival with the largest upper end at $z=1$. This LUCB-style policy [13] targets overlap. Rules therefore differ only in *when* they stop, and read the same trajectories (exact pairing).

**Task B: conflict (Proposition 2).** A two-choice flanker-style task [25].

- **Features.** $x=[t_L,t_R,f_L,f_R]$. The target is 1.0 on its side and 0.2 on the other. Flankers are 1.5 on their side, which is the target's side on congruent trials and the opposite side on incongruent ones, and 0.2 elsewhere. Congruent and incongruent trials are equally likely.
- **Samples.** Each sample observes every feature with log-normal noise, $\sigma=2$.
- **Decks.** Go$_L=g\!\cdot\!x$ and Stop$_L=h\!\cdot\!x$, with $g=[1,0.2,0.4,0.1]$ and $h=[0.2,1,0.1,0.4]$. Channel $R$ is mirrored, so $s_{L/R}=\theta\pm r$.
- **The input box.** The geometric mean $\pm\,z\sigma/\sqrt t$ in log space, with equal radii.
- **Evidence.** At the true input, $r=0.97$ on congruent and $0.22$ on incongruent trials.
- **The brake.** With the two channels exactly anti-correlated, OVL acts iff the range of $r$ excludes 0.

**Task C: repeated bandit (Proposition 6).**

- **Arms.** Four Bernoulli arms, $p\sim U(0.2,0.8)$, played for 200 pulls.
- **Choice.** Each pull takes $\arg\max\mathrm{CE}_\beta$ at $z=1$.
- **Outcome.** Pseudo-regret, $\sum_t(p^\ast-p_{a_t})$.

## 4.2 Rules

| Rule | Task | Acts when |
|---|---|---|
| OVL($z$) | A | the leader's lower salience exceeds every rival's upper salience |
| OVL_exact($z$), OVL_dec($z$) | B | the exact (Proposition 2(a)) or decoupled (2(b)) range of $r$ excludes 0 |
| CTR($\tau$) | A, B | the centre gap to the runner-up exceeds $\tau$ (B: $\lvert\hat r\rvert>\tau$) |
| ZSC($\kappa$) | A, B | A: $\min_c(m_\ell-m_c)/\sqrt{v_\ell+v_c}>\kappa$; B: $\lvert\hat r\rvert/\mathrm{se}>\kappa$, delta-method $\mathrm{se}=\sigma\lVert a-b\rVert_2/\sqrt t$ |
| NB | A | act at once, $t=0$ |

**Deadline and cost.** The deadline is 60 samples. Reward rate is correct / (samples + $T_0$), with $T_0=100$ primary and $T_0\in\{20,50,200\}$ exploratory. It is reported per 1000 time units.

## 4.3 Protocol

**Freeze.** The protocol (`PROTOCOL.md`), library, tuning, run and evaluation scripts and theory checks were frozen by SHA-256 at 10:07 UTC on 11 October 2026 (Appendix A). The freeze preceded the tuning on seeds 0–4 and every confirmatory run. A pre-freeze smoke test had run the whole pipeline on pilot seeds (Section 4.4).

**Tuning.** Each rule's single parameter was tuned to the pooled reward-rate maximum over a fixed grid, on seeds 0–4.

**Confirmatory runs.** Seeds 1000–1019, 2,000 trials per seed and task.

**Statistics.** The statistic is the mean over seeds of the seed-paired difference, with a 95% bootstrap interval (10,000 resamples). A hypothesis is *supported* if the interval lies above 0, *rejected* if it lies below, and *inconclusive* otherwise.

**Table 1.** Registered hypotheses and what was known before freezing.

| | Prediction | Basis | Known before freezing |
|---|---|---|---|
| H1 | Task A: RR(OVL\*) > RR(CTR\*). **Kill criterion.** | agenda | pilots |
| H2 | Task B: RR(OVL_exact\*) > RR(CTR\*) | agenda | pilots |
| H3 | Task B: RR(OVL_dec\*) > RR(OVL_exact\*) | Proposition 2(d) | pilots (they reversed our prior) |
| H4a | Task A: RR(ZSC\*) > RR(OVL\*) | Proposition 5 | pilots ("close") |
| H4b | Task B: RR(ZSC\*) > RR(OVL_exact\*) | Proposition 2(d) | smoke test only, which returned "rejected" |
| H5a | Task A, $t=0$: the chosen interval's width rises at every step of $\beta\in\{-8,-2,0,2,8\}$ | Proposition 6 | smoke test only |
| H5b | Task A, $t=0$: accuracy at $\beta=0$ exceeds accuracy at $\beta=\pm8$ | Proposition 6 | smoke test only |
| H5c | Task C: pseudo-regret at $\beta=2$ is below that at $\beta=0$ | optimism | pilots |

**C1.** Brake locality (Proposition 4(a)) is reported as pass or fail.

## 4.4 Pilots and smoke test

The pilots ran before freezing, on seeds 900–902, outside both seed ranges.

- **Calibration.** At $T_0=5$ every rule's optimum was to act at once. At $T_0=20$–$50$, Task A was still nearly degenerate, because telling four Bernoulli arms apart takes many samples. We chose $T_0=100$ and $\sigma=2$, which gave both tasks a real speed–accuracy trade-off.
- **Rule comparisons.** The pilots showed OVL ahead of CTR on both tasks and ZSC close to OVL in Task A. They also showed the decoupled range ahead of the exact one in Task B, against our prior, so H3 was registered in the observed direction. The standardised rule was then added to Task B.
- **Smoke test.** Tuning on seed 902, with seeds 900–901 and 300 trials, produced provisional verdicts:
  - H1, H2 and H5a–c supported;
  - H3 and H4a inconclusive;
  - H4b rejected;
  - C1 passed.

  Nothing changed after it.
- **Records.** The pilots' printed outputs were not archived. The pilot scripts in the supplement import the frozen library, so pilots 1–2 (other $T_0$ and $\sigma$) re-run only after the constants are edited.

## 4.5 Checks

**Frozen checks.** `verify_p4_theory.py` runs 28 checks, all of which pass:

- **P1.** Containment over 4 million samples. The companion corner check is algebraically vacuous.
- **P2.**
  - the threshold vertex against all $2^4$ vertices and 2,000 interior samples of each of 4,000 random boxes;
  - containment of the exact range in the decoupled one;
  - failure of the naive corner;
  - both linearisations at $z=10^{-4}$.
- **P3.**
  - the overlap–threshold identity;
  - the reduction of OVL to CTR under equal widths.
- **P4.**
  - locality;
  - pointwise monotonicity.
- **P5.**
  - both implications;
  - the ratio bound.
- **P6.**
  - monotonicity on 81 values of $\beta$;
  - the limits, without checking the gap's order;
  - the closed form against Monte Carlo ($2\times10^6$ draws);
  - that $\mathrm{CE}_\beta$ lies inside the interval.

**Post-hoc checks.** `verify_p4_addendum.py` contains checks A1–A4, written after the verdicts, and A5–A11, written after the independent review. All are exploratory.

- **A1.** Proposition 2(e) holds to $10^{-15}$.
- **A2.** OVL_dec($z^\ast$) and $\lvert\hat r\rvert>2z^\ast\sigma/\sqrt t$ agree on all 40,000 trials.
- **A3.** The coverage of the salience interval.
- **A4.** The exact-to-decoupled width ratio.
- **A5–A6.** Two non-interval baselines.
- **A11.** The linearised exact rule with true and with plug-in shares.
- **A7.** The oracle comparison.
- **A8.** Task B by trial type.
- **A9.** Time-cost intervals.
- **A10.** The forced shares.

# 5 Results

**Table 2.** Verdicts. Differences are in correct choices per 1000 time units (H5c: pseudo-regret over 200 pulls). Intervals are 95% bootstrap intervals over 20 seed-paired differences.

| | Difference | Relative | Verdict |
|---|---|---|---|
| H1 (kill) | OVL − CTR, Task A: +0.251 [0.227, 0.275] | +4.5% | **supported**: P4 is not dropped |
| H2 | OVL_exact − CTR, Task B: +0.523 [0.494, 0.552] | +7.4% | **supported** |
| H3 | OVL_dec − OVL_exact, Task B: +0.211 [0.192, 0.230] | +2.8% | **supported** |
| H4a | ZSC − OVL, Task A: +0.015 [0.006, 0.023] | +0.25% | **supported** (negligible) |
| H4b | ZSC − OVL_exact, Task B: −0.192 [−0.214, −0.169] | −2.5% | **rejected** |
| H5a | chosen width, successive $\beta$ steps: +0.097, +0.142, +0.219, +0.187 (all intervals above 0) | 0.92 → 1.57 | **supported** |
| H5b | accuracy, $\beta=0$ − $\beta=+8$: +8.3 pp [7.8, 8.7]; $\beta=0$ − $\beta=-8$: +2.5 pp [2.2, 2.8] | | **supported** |
| H5c | pseudo-regret, $\beta=0$ − $\beta=2$: +2.61 [2.52, 2.70] | −23% | **supported** |
| C1 | 0 mismatches on the 7,500 of 40,000 trials not overlapping at $t=0$ | | **pass** |

**Table 3.** Tuned rules at $T_0=100$, means over seeds 1000–1019. *At deadline* is the share of trials that ended at 60 samples. It exceeds the truly forced share by about 0.1 point; for example, A10 gives 5.3%, 13.9% and 4.6% forced for OVL, CTR and ZSC (seeds 1000–1004). Rows in italics are exploratory: † was added after the results, ‡ after the review.

| Task | Rule | Parameter | RR | Accuracy | Samples | At deadline |
|---|---|---|---|---|---|---|
| A | NB (act at once) | — | 5.10 | 51.0% | 0 | — |
| A | CTR | $\tau=0.70$ | 5.64 | 63.6% | 12.8 | 13.8% |
| A | *Bayes, P(leader best) > q* † | $q=0.74$ | *5.81* | *65.7%* | *13.1* | |
| A | *CTR, gap > $\tau/\sqrt{1+t}$* ‡ | $\tau=1.6$ | *5.82* | *62.9%* | *8.0* | |
| A | OVL | $z=0.40$ | 5.89 | 65.8% | 11.8 | 5.4% |
| A | ZSC | $\kappa=0.75$ | 5.91 | 65.9% | 11.5 | 4.6% |
| B | CTR | $\tau=0.90$ | 7.10 | 79.2% | 11.6 | 15.6% |
| B | ZSC (plug-in se) | $\kappa=1.5$ | 7.43 | 81.2% | 9.2 | 7.2% |
| B | OVL_exact | $z=0.85$ | 7.62 | 86.4% | 13.4 | 10.2% |
| B | *ZSC (true se, oracle)* † | $\kappa=1.3$ | *7.63* | *87.1%* | *14.1* | |
| B | OVL_dec ($\equiv\lvert\hat r\rvert>0.9\sigma/\sqrt t$) | $z=0.45$ | 7.83 | 87.9% | 12.3 | 6.8% |
| B | *$1/t$ bound on the mean, $t\lvert\hat r\rvert>A$* ‡ | $A=4.25$ | *7.90* | *86.0%* | *8.8* | |

![Speed–accuracy frontiers](figs/fig1_frontiers.png)

**Figure 1.** Speed–accuracy frontiers on the confirmatory seeds. Each curve is one rule over its parameter grid; dots and diamonds mark tuned parameters. The dotted line is the iso-reward-rate line through the best registered rule, so a frontier above it earns more. Dash-dotted lines are the post-review baselines. In Task A the tuned points of OVL and ZSC nearly coincide; the OVL dot hides the ZSC dot. The ZSC curve in Task B ends where its grid ends ($\kappa=4$). The rule $\lvert\hat r\rvert>\kappa\sigma/\sqrt t$ is not drawn because it coincides with OVL_dec (Proposition 2(e)).

## 5.1 The kill criterion

**Task A.** The overlap brake earned 5.89 correct choices per 1000 time units, against 5.64 for the tuned centre threshold, a 4.5% gain (H1). It was more accurate (65.8% against 63.6%) with fewer samples (11.8 against 12.8), and its frontier lies above CTR's (Figure 1).

**How it differed** (exploratory). Width in Task A reflects familiarity, samples taken and the success–failure split, so the following breakdown by familiarity is descriptive, not causal.

- **Best arm unfamiliar** ($n_0=0$). OVL sampled more than CTR (12.5 against 9.0 samples) and was more accurate (58.2% against 50.1%).
- **Best arm well known** ($n_0=32$). It sampled less (10.2 against 18.3) at the same accuracy (73.7% against 73.8%).
- **Deadline.** CTR ended 13.8% of trials at the deadline, against 5.4% for OVL.

CTR acts quickly on a large gap between poorly known arms and keeps sampling a small gap between well-known arms.

**A baseline that shrinks with time** (post-review, A6). A centre threshold $\tau/\sqrt{1+t}$, with one tuned parameter, earned 5.82. That recovers 73% of OVL's gain over CTR (+0.183 [0.157, 0.210]). OVL still beat it by 0.068 [0.041, 0.096], or 1.2%.

So most of the registered margin is reproduced by a threshold that shrinks within the trial. The split is not unique: OVL's widths shrink with each arm's own count, including pre-observations and the samples the policy assigns to it, and a different time schedule could recover more or less. Against this baseline, the width-dependent part of OVL is worth 1.2% [0.7%, 1.7%].

**Task B.** The exact overlap brake beat CTR by 7.4% (H2), with 86.4% against 79.2% accuracy, at 13.4 against 11.6 samples.

**A $1/t$ baseline** (post-review, A5). CTR here holds a fixed threshold on the running mean $\hat r$, which is a bound that grows linearly in $t\hat r$. It is a weak baseline. The rule $t\lvert\hat r\rvert>A$ is a $1/t$ bound on the mean. Since $\hat r$ is a nonlinear function of the averaged log-samples, $t\hat r$ only approximates summed evidence, and this is not the likelihood ratio of the task. It uses no intervals, and it earned 7.90. That is 11.3% above CTR (+0.803 [0.769, 0.837]) and above every interval rule: +0.279 [0.255, 0.304] over the exact range and +0.069 [0.047, 0.091] over the decoupled one.

**Sensitivity** (exploratory). Seed-paired differences of tuned rules in correct choices per 1000 time units, with parameters re-tuned at each $T_0$, and 95% intervals. The source is A9, except the decoupled − exact column, which is from `report/facts.json`.

| $T_0$ | A: OVL − CTR | A: ZSC − OVL | B: exact − CTR | B: decoupled − exact | B: ZSC − exact |
|---|---|---|---|---|---|
| 20 | +0.086 [−0.040, 0.207] | +0.048 [0.025, 0.070] | +0.959 [0.832, 1.090] | +0.261 [0.168, 0.361] | −0.194 [−0.244, −0.147] |
| 50 | +0.337 [0.284, 0.389] | +0.030 [0.014, 0.045] | +0.824 [0.774, 0.873] | +0.307 [0.258, 0.357] | −0.261 [−0.295, −0.227] |
| 100 | +0.251 [0.227, 0.275] | +0.015 [0.006, 0.023] | +0.523 [0.494, 0.552] | +0.211 [0.192, 0.230] | −0.192 [−0.214, −0.169] |
| 200 | +0.130 [0.121, 0.139] | −0.006 [−0.014, 0.001] | +0.291 [0.277, 0.304] | +0.093 [0.088, 0.099] | −0.156 [−0.163, −0.148] |

- **At $T_0=20$.** Almost no sampling pays in Task A (0.3–0.6 samples per trial), and CTR's tuned threshold sits at the edge of its grid ($\tau=0$).
- **ZSC against OVL in Task A.** The difference is inconclusive at $T_0=200$.

## 5.2 What the interval rules gain in Task B

**H3 (supported, pilot-informed).** The decoupled range, which is sound but loose, earned 2.8% more than the exact range: 7.83 against 7.62, with 87.9% against 86.4% accuracy in 12.3 against 13.4 samples.

**Why the decoupled rule is a clock.** By Proposition 2(e), OVL_dec is the rule $\lvert\hat r\rvert>2z\sigma/\sqrt t$, whose threshold on the mean shrinks as $1/\sqrt t$ and is the same on every trial. The rule $\lvert\hat r\rvert>\kappa\sigma/\sqrt t$, tuned on the same seeds, picked $\kappa=0.9=2z^\ast$ as expected, and the two agreed on all 40,000 trials (A2).

**Why the exact range does worse.** Its half-width is, to first order, $z\sigma\lVert a-b\rVert_1/\sqrt t$. This is relatively larger on incongruent trials, where target and flanker push the shares apart.

- **Width ratio** (A4, seeds 1000–1004). Relative to the decoupled width, it was 0.30–0.41 on congruent trials and 0.33–0.62 on incongruent trials, from 1 to 60 samples.
- **Incongruent trials** (A8). The exact brake took 22.4 samples against 20.0, and was *less* accurate: 74.2% against 76.4%.

A bound that is simply higher on these trials should buy accuracy with its extra samples. This one bought none, plausibly because its width depends on the noisy estimate $\hat x$. A post-review check (A11) supports this. It uses the linearised exact rule $\lvert\hat r\rvert>q\sigma\lVert a-b\rVert_1/\sqrt t$, tuned on seeds 0–4.

- **True shares.** The raised bound does buy accuracy: 78.4% on incongruent trials at 23.0 samples, with reward rate 7.70.
- **Plug-in shares.** It does not: 66.5% at 15.1 samples, with reward rate 7.43.
- **Two caveats.** The true-share rule still lost to OVL_dec (−0.130 [−0.148, −0.113]). The actual exact range (7.62) did better than its plug-in linearisation, so it is not simply that linearisation.

**H4b (rejected), explained by plug-in noise (oracle check A7).** The standardised rule with the plug-in $\mathrm{se}$ lost to the exact brake by 2.5%. On incongruent trials it stopped *sooner* (15.5 samples) at 66.7% accuracy (A8).

An oracle that uses the $\mathrm{se}$ at the true input tied the exact brake: +0.012 [−0.004, 0.027] (A7). It was 0.203 [0.181, 0.226] above the plug-in rule. The oracle genuinely raises its bound on incongruent trials (26.1 samples, 80.0% accuracy). It still lost to the decoupled rule by 0.199 [0.176, 0.221].

**The ordering in Task B** (Table 3) follows how the bound behaves over time on the mean.

| Rule | Bound on the mean |
|---|---|
| $t\lvert\hat r\rvert>A$ (best) | falls as $1/t$ |
| decoupled | falls as $1/\sqrt t$ |
| exact, oracle | fall as $1/\sqrt t$, but stay higher on conflict trials |
| plug-in standardised | noisy |
| fixed centre threshold (worst) | constant |

The best rule gave up soonest on incongruent trials: 12.1 samples at 72.0% accuracy, against 20.0 samples and 76.4% for the decoupled rule (A8).

This is loosely analogous to the optimal-stopping result that, when difficulty is unknown, a reward-rate maximiser should not hold out long on hard trials [16, 17]. We did not derive the optimal policy for Task B, so it is an interpretation, not a test.

**H4a (supported, but negligible).** In Task A the standardised gap beat the overlap brake by 0.25% [0.10%, 0.38%]. By Proposition 5 the two statistics differ by a factor of 1.56–2.00 on Task A's states, so their tuned versions nearly coincide (Figure 1).

**A Bayesian reference** (exploratory). Stopping when the posterior probability that the centre leader is best exceeds $q$ (Beta posteriors, 256 draws) earned 5.81. That is 1.4% below OVL (−0.080 [−0.095, −0.065]), and close to the shrinking centre threshold. A fixed posterior threshold is not the reward-rate optimum either.

## 5.3 Risk: β moves choices through the interval

**H5a (supported).** At $t=0$ in Task A, the mean summed radius of the chosen arm rose at every step: 0.92, 1.02, 1.16, 1.38 and 1.57 for $\beta=-8,-2,0,2,8$. Pessimism chose familiar arms and optimism unfamiliar ones, while the intervals were unchanged (Proposition 6(c)).

**H5b (supported).** The centre was best for a one-shot choice: 51.1% at $\beta=0$, against 42.9% at $\beta=8$ and 48.6% at $\beta=-8$. In the no-brake arm, ties are broken by a fixed jitter, and at $\beta=0$ by the lowest index; this gives 51.0% against 51.1%.

**At the OVL stopping state** (exploratory). $\beta$ hardly mattered: accuracy was 65.9% for $\beta\in[-8,2]$ and 64.9% at $\beta=8$. The $\mathrm{CE}_\beta$ intervals use $z=1$ while OVL\* releases at $z=0.4$, so they can still overlap. A plausible reading, which we did not measure, is that by the time the brake releases, the leader's centre is usually far enough ahead that only extreme optimism reorders the arms. About 5% of trials end at the deadline without release.

**H5c (supported).** When choices inform later choices, optimism paid. Over 200 pulls, pseudo-regret was 19.9, 15.2, 11.3, 8.7 and 7.1 for $\beta=-8,-2,0,2,8$. This is the classical case for optimism under uncertainty [22], reached through the certainty equivalent of a salience interval.

![Risk inside the interval](figs/fig2_beta.png)

**Figure 2.** Left: summed radius of the arm chosen at $t=0$ in Task A, against $\beta$. Middle: accuracy at $t=0$ and at the OVL\* stopping state. Right: pseudo-regret over 200 pulls in Task C.

## 5.4 Locality and the brake map

**C1 (pass).** At $z^\ast=0.4$, 7,500 of the 40,000 confirmatory trials (18.8%) did not overlap at $t=0$. On every one of them OVL and the no-brake agent made the same choice at $t=0$ (Proposition 4(a)).

On the 81.2% of trials that did overlap, removing the brake cost 18.2 points of accuracy. This is the empirical half of P4.3.

**Brake map (Figure 3).** The map visualises Proposition 4(b) over the trajectory states. At a fixed centre gap, OVL's braking rises with width. For a gap of 0.75–1, it is 0.00 below a summed radius of 1.5, 0.51 at 2–2.5 and 1.00 above 2.5.

CTR's braking depends on width only through the spread of gaps inside a bin. In the 0.5–0.75 bin, which contains $\tau^\ast=0.7$, it runs from 0.82 to 1.00.

![Brake map](figs/fig3_brake_map.png)

**Figure 3.** Share of Task A states braked, against the summed radius of leader and runner-up (at $z=1$), for four bins of centre gap. Left: OVL\*. Right: CTR\*. The map was recomputed after we found that the frozen library's version binned 2,221 exact-tie states (gaps of $-10^{-16}$, from equal ratios) into the last gap row.

# 6 What removing the brake costs (exploratory)

**The lesion map** (Figure 4) bins trials by initial centre gap and initial width. It plots the accuracy lost by acting at once instead of under the overlap brake, as a simulated counterpart of STN stimulation [9].

- **Small gaps.** For gaps below 0.25 the brake was worth 20–29 points at every width.
- **Gaps of 0.5–1.** It was worth 0.9–2.7 points below a summed radius of 1.5, against 8.8 points above 2.
- **Gaps above 1.** It was worth 0.0–0.1 points below 2, against 5.6 above.

The near-zero cells are largely set by the rule's definition: at $z^\ast=0.4$, OVL usually releases at $t=0$ in those states. The larger cells are where the brake earned its accuracy.

**What this adds to P4.3.** Removing the brake costs most where options overlap, and that includes a large value gap between unfamiliar options. A brake that reads only the centres cannot express this. At a gap of 0.5–1, CTR took 24.3 samples on the narrowest states and 4.9 on the widest; OVL took 2.6 and 10.3.

![Lesion map](figs/fig4_lesion.png)

**Figure 4.** Task A: accuracy lost by acting at $t=0$ rather than under the overlap brake, by initial centre gap (lines) and initial summed radius of leader and runner-up (at $z=1$). Bins with 50 or fewer trials are omitted.

# 7 Is the reward-optimal brake a certificate?

**No.** At its tuned radius $z^\ast=0.4$, the salience interval contained the true log-odds of an arm 54%, 46% and 43% of the time, for arms with 2, 8 and 32 pre-observations. These figures are measured at $t=0$ on seeds 1000–1004 (A3). The coverage was 85–95% at $z=1$, and 99.6–100% at $z=1.96$.

**What it shares with a certificate.** The registered brake is not a certified decision in the sense of P1 [3]. What it shares with one is the *form* of its threshold, a sum of widths, not its coverage.

**Why.** At $T_0=100$, waiting for 95% intervals to separate costs more time than the extra accuracy earns. When errors are expensive relative to time, the reward-optimal radius should grow toward certifying values. We did not test that regime.

# 8 Discussion

**What survives.** The registered rule passes its kill criterion in both tasks, at every time cost but the lowest. Two things carry the gain.

- **The time course of the threshold.** It shrinks as evidence accrues. This is most of the gain, and simple non-interval bounds reproduce it. In Task A a post-review centre threshold shrinking as $1/\sqrt{1+t}$ recovers 73% of the margin. In Task B a $1/t$ bound on the mean beats every interval rule.
- **Width.** The overlap brake waits on poorly known options and releases on well-known ones. Against the shrinking threshold, OVL retains 1.2% in Task A. This decomposition depends on the schedule chosen for the baseline.

**What does not survive.** Neither exactness nor standardisation improved the brake in Task B. The exact salience range, the programme's usual goal, was a worse stopping statistic than the loose decoupled bound. Its state-dependent width, read from a noisy estimate, did not buy accuracy on hard trials (A11). The plug-in standardised rule was worse still. In Task A, standardisation was a negligible gain.

**Conflict and threshold.** In the textbook reading of the STN, conflict raises the threshold [7, 10]. In our Task B, conflict meant weak evidence. The exact brake and the oracle held out longer on incongruent trials, and both earned less than the decoupled rule and the $1/t$ bound, which held out less. The best rule gave up soonest. Holding out longer does not by itself order the rules: the plug-in standardised rule held out least and earned less than the exact brake.

- **Scope.** This holds only among rules whose threshold already shrinks with time. A fixed centre threshold, which does not raise its bar on conflict, was worst of all.
- **Not a refutation.** Frank's model concerns conflict between response tendencies early in a trial, and human tasks set their own costs on time and errors.
- **A cost to measure.** It names a cost that a conflict-driven threshold has to pay. That suggests a measurement: whether STN-mediated slowing on incongruent trials is reward-rate optimal at the time costs of the task.

**Predictions for experiments.** P4.1 and P4.3 are properties of the rule (Proposition 4). They become empirical claims about people and animals, and they separate the overlap brake from the shrinking centre threshold that matched most of its reward rate.

1. **Familiarity slows choice (P4.1).** At a fixed difference in learned value, choices between less familiar options take longer. A centre threshold predicts the opposite. In our runs, CTR took 9.0 samples when the best arm was unfamiliar and 18.3 when it was well known, because noisy centres between unfamiliar options cross a fixed gap sooner.
2. **The cost of STN disruption follows overlap (P4.3).** Disruption should raise errors even at large value differences between unfamiliar options, and not at large differences between familiar ones. This refines the BG paper's prediction 4 [5], as the agenda states.
3. **Risk moves choices, not braking (P4.2).** Manipulating tonic dopamine should change *which* options are chosen, toward the unfamiliar under optimism. It should not change the interval widths that govern braking.

**Relation to bandit theory.** The overlap stopping rule is that of LUCB and action elimination [12, 13]. Our contribution is not the rule. It is three things:

- its derivation from opponent Go and Stop decks, with an exact salience range for a shared input (Proposition 2);
- the finding that at reward-optimal radii the confidence semantics are lost (Section 7);
- the finding that a time-shrinking non-interval threshold reproduces most of its reward-rate advantage.

# 9 Limitations

- **Simulated agents only.** No neural or behavioural data were analysed. Every claim about the brain is a prediction.
- **A weak registered baseline.** The agenda's baseline, a fixed threshold on the centre difference, does not shrink with time. The kill criterion was met against it. Against stronger, post-review baselines, chosen after the results were seen, the overlap brake's advantage was 1.2% in Task A and reversed in Task B.
- **One parameterisation per task.** Each task fixes four arms, uniform values, one familiarity distribution, one flanker geometry, one noise level and a deadline of 60. The pilots chose $T_0=100$ and $\sigma=2$ so that the tasks would not be degenerate.
- **The shared sampling policy.** Task A's policy picks its challenger by the upper bound at $z=1$, so it targets overlap. This may favour OVL and ZSC over CTR. A rule's best sampling policy might differ.
- **Heuristic intervals.** The radii $z/\sqrt G$ and $z/\sqrt S$ are not posterior regions. A different radius formula would change the width variation, and with it the overlap brake's advantage (Proposition 3).
- **Not blind.** The pilots informed H1–H4a and H5c. The smoke test produced verdicts on every hypothesis before freezing, and H3's direction was set after a pilot reversed our prior. The pilots' printed outputs were not archived.
- **No optimal policy.** We did not compute the reward-rate optimal policy for either task, so the interpretations in Section 5.2 are not tests.
- **The brake map.** The frozen library's exploratory brake map mis-binned exact ties, and the map was recomputed. No registered outcome used it.
- **Coverage and width checks.** A3 and A4 use 5 of the 20 confirmatory seeds, and A3 measures coverage at $t=0$ only.

# 10 Conclusion

**The registered result.** P4 asked whether a brake that acts on overlapping salience intervals earns more reward than a tuned threshold on their centres. It does: by 4.5% in a bandit where familiarity and value were independent, and by 7.4% in a conflict task. The kill criterion is not triggered.

**Where the gain comes from.** Mostly from a threshold that shrinks as evidence accrues. A centre threshold that shrinks with time recovers 73% of the gain in the bandit, leaving the overlap brake 1.2% ahead. A $1/t$ bound on the mean, with no intervals, beats every interval rule in the conflict task.

**What did not help.**

- *Exactness.* The decoupled range beat the exact one.
- *Standardisation.* The plug-in standardised rule lost, through noise in its standard error.
- *Certification.* At the reward-optimal radius the intervals covered the truth about half the time.

**Risk.** $\beta$ did what Proposition 6 says. It moved choices through the intervals without touching them, with the centre best for one-shot choice and optimism best for repeated choice.

**For the basal ganglia.** The rule's distinctive predictions are about familiarity and STN lesions, not reward rate. Those predictions, not the simulations, are what an experiment would test.

# References

[1] Ghosh, Debi Prasad. (2026). *Interval Transformers with Exact Local Weight Ranges and Sparse Expert Routing*. Manuscript, 1 October 2026.

[2] Ghosh, Debi Prasad. (2026). *Log Interval Networks for Certified Decisions and Structured Memory*. Research programme with reproducible numerical checks, 1 October 2026.

[3] Ghosh, Debi Prasad. (2026). *Log Interval Networks for Evidence Accumulation and Certified Decisions*. P1 of the log interval network programme, 4 October 2026.

[4] Ghosh, Debi Prasad. (2026). *Positive Kronecker Attention with Dependency Control*. P2 of the log interval network programme, 5 October 2026.

[5] Ghosh, D. P., Ghosh, D., and Ghosh, D. (2025). *Kronecker-Factored Positive Logarithmic Network Model of the Basal Ganglia with Addition-Free RL*. https://doi.org/10.13140/RG.2.2.17714.47041

[6] Ghosh, Debi Prasad. (2026). *Log-Interval Networks: The Next Research Programme for the Interval Transformer*. Research agenda, 1 October 2026.

[7] Frank, M. J. (2006). Hold your horses: A dynamic computational role for the subthalamic nucleus in decision making. *Neural Networks*, 19(8), 1120–1136. https://doi.org/10.1016/j.neunet.2006.03.006

[8] Nambu, A., Tokuno, H., and Takada, M. (2002). Functional significance of the cortico–subthalamo–pallidal 'hyperdirect' pathway. *Neuroscience Research*, 43(2), 111–117. https://doi.org/10.1016/S0168-0102(02)00027-5

[9] Frank, M. J., Samanta, J., Moustafa, A. A., and Sherman, S. J. (2007). Hold your horses: Impulsivity, deep brain stimulation, and medication in parkinsonism. *Science*, 318(5854), 1309–1312. https://doi.org/10.1126/science.1146157

[10] Cavanagh, J. F., Wiecki, T. V., Cohen, M. X., Figueroa, C. M., Samanta, J., Sherman, S. J., and Frank, M. J. (2011). Subthalamic nucleus stimulation reverses mediofrontal influence over decision threshold. *Nature Neuroscience*, 14(11), 1462–1467. https://doi.org/10.1038/nn.2925

[11] Aron, A. R., and Poldrack, R. A. (2006). Cortical and subcortical contributions to stop signal response inhibition: Role of the subthalamic nucleus. *Journal of Neuroscience*, 26(9), 2424–2433. https://doi.org/10.1523/JNEUROSCI.4682-05.2006

[12] Even-Dar, E., Mannor, S., and Mansour, Y. (2006). Action elimination and stopping conditions for the multi-armed bandit and reinforcement learning problems. *Journal of Machine Learning Research*, 7, 1079–1105.

[13] Kalyanakrishnan, S., Tewari, A., Auer, P., and Stone, P. (2012). PAC subset selection in stochastic multi-armed bandits. *Proceedings of ICML 2012*, 655–662.

[14] Garivier, A., and Kaufmann, E. (2016). Optimal best arm identification with fixed confidence. *Proceedings of COLT 2016*, PMLR 49, 998–1027.

[15] Bogacz, R., Brown, E., Moehlis, J., Holmes, P., and Cohen, J. D. (2006). The physics of optimal decision making: A formal analysis of models of performance in two-alternative forced-choice tasks. *Psychological Review*, 113(4), 700–765. https://doi.org/10.1037/0033-295X.113.4.700

[16] Drugowitsch, J., Moreno-Bote, R., Churchland, A. K., Shadlen, M. N., and Pouget, A. (2012). The cost of accumulating evidence in perceptual decision making. *Journal of Neuroscience*, 32(11), 3612–3628. https://doi.org/10.1523/JNEUROSCI.4010-11.2012

[17] Malhotra, G., Leslie, D. S., Ludwig, C. J. H., and Bogacz, R. (2018). Time-varying decision boundaries: Insights from optimality analysis. *Psychonomic Bulletin & Review*, 25(3), 971–996. https://doi.org/10.3758/s13423-017-1340-6

[18] Bogacz, R., and Gurney, K. (2007). The basal ganglia and cortex implement optimal decision making between alternative actions. *Neural Computation*, 19(2), 442–477. https://doi.org/10.1162/neco.2007.19.2.442

[19] Dinkelbach, W. (1967). On nonlinear fractional programming. *Management Science*, 13(7), 492–498. https://doi.org/10.1287/mnsc.13.7.492

[20] Charnes, A., and Cooper, W. W. (1962). Programming with linear fractional functionals. *Naval Research Logistics Quarterly*, 9(3–4), 181–186. https://doi.org/10.1002/nav.3800090303

[21] Karnik, N. N., and Mendel, J. M. (2001). Centroid of a type-2 fuzzy set. *Information Sciences*, 132, 195–220. https://doi.org/10.1016/S0020-0255(01)00069-X

[22] Auer, P., Cesa-Bianchi, N., and Fischer, P. (2002). Finite-time analysis of the multiarmed bandit problem. *Machine Learning*, 47, 235–256. https://doi.org/10.1023/A:1013689704352

[23] Jin, Y., Yang, Z., and Wang, Z. (2021). Is pessimism provably efficient for offline RL? *Proceedings of ICML 2021*, PMLR 139, 5084–5096.

[24] Hardy, G. H., Littlewood, J. E., and Pólya, G. (1934). *Inequalities*. Cambridge University Press.

[25] Eriksen, B. A., and Eriksen, C. W. (1974). Effects of noise letters upon the identification of a target letter in a nonsearch task. *Perception & Psychophysics*, 16(1), 143–149. https://doi.org/10.3758/BF03203267

# Appendix A. Reproduction

**Environment.** Python 3.11.15, NumPy 2.4.4, Matplotlib 3.10.9; two CPU cores.

**Commands**, in order:

```
python3 verify_p4_theory.py > verify_p4_theory_output.txt      # 28 frozen checks, about 3 s
python3 p4_tune.py                                             # seeds 0-4 -> tuned.json, about 1.5 min
python3 p4_runs.py                                             # seeds 1000-1019 -> runs/, about 2.5 min
python3 p4_eval.py                                             # frozen evaluator -> evals/decisions.json
python3 p4_explore.py                                          # exploratory rules -> report/explore.json, about 5 min
python3 p4_report.py                                           # report/facts.json, figs/
python3 verify_p4_addendum.py > verify_p4_addendum_output.txt  # A1-A11, about 1.5 min
```

**Frozen code** (`evals_code_sha256.txt`; check with `sha256sum -c`, which warns about the last line):

    d972bee9d6d32d9217c84dbd0d881bab11c50c9c6c5a7f5f0f4da37168731dae  p4lib.py
    ef12c570ea88887a3dbef6656dd51f53fe777ae3f6bd281cb5854c4f786cf1cd  p4_tune.py
    d2410e857369c21c0c5f9b52ae79bd6ed4a90f2e48b9bb247e3293b6c185a66c  p4_runs.py
    a111bcf5b900bd60370d8b5d7fba5dc9cbe5b693de87b03a8d635060d8977a8c  p4_eval.py
    bb9630119205ff64ff06a9ad72917c1ad1e5587361e74a4996fbc3c79a455642  verify_p4_theory.py
    894416d5bd17c2ec707470c0bd61a4521184247e5dc301419357da490b03468e  PROTOCOL.md
    frozen 2026-10-11T10:07:17Z

None of these files changed afterwards. The freeze time is self-reported. Three scripts were written later:

- `p4_explore.py`, after the confirmatory verdicts;
- `p4_report.py`, after the verdicts, and revised after the review;
- `verify_p4_addendum.py`: A1–A4 after the verdicts, A5–A11 after the review.

None of them tests a registered hypothesis.

**Tuned parameters** at the primary $T_0=100$ (`tuned.json`):

- **Task A.** OVL $z=0.40$, CTR $\tau=0.70$, ZSC $\kappa=0.75$.
- **Task B.** OVL_exact $z=0.85$, OVL_dec $z=0.45$, CTR $\tau=0.90$, ZSC $\kappa=1.5$.
