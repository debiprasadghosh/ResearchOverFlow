"""KP-LNN-0 (the published Multiply-Prune body) and KP-LNN-Sigma (the BG paper's appendix layer), in the log domain.

KP-LNN-0 layer [KP-LNN, Sec. 3.2]:
  1. Kronecker composition   log Z[(i,k),(j,l)] = log X[i,j] + log W[k,l]
  2. typed routing           a binary mask; a masked entry is set to exponent 0 (value 1) or removed (exponent -inf);
                             an inhibitory flow flips the matrix-level sign state, i.e. negates every exponent
  3. thresholding            keep rows / columns whose energy (maximum exponent) exceeds tau, at most K of them
Every matrix carries its provenance: log X = sigma * xhat[S] + C, with S the input entry copied (-1 for a constant),
sigma in {-1, 0, +1} and C a constant.  This is Proposition H made executable.

KP-LNN-Sigma layer [BG, Appendix A.3], with temperature T:
  log Y_ij = T * LSE_{k,l}((Bhat_ik + Xhat_kl + Ahat_jl) / T),   T = 1: Y = B X A^T exactly.
"""
import numpy as np
from scipy.special import logsumexp, softmax


# --------------------------------------------------------------------------------------------- KP-LNN-0
def top_k(energy, K, tau):
    """Indices kept: energy > tau, the K largest (ties broken by lower index), returned in index order."""
    cand = np.where(energy > tau)[0]
    if len(cand) > K:
        order = np.lexsort((cand, -energy[cand]))
        cand = np.sort(cand[order[:K]])
    return cand


def layer0(state, Lw, Kr, Kc, tau=-np.inf, mask=None, mask_mode='one', invert=False, Rw=0.0):
    """One KP-LNN-0 layer on a provenance state dict(L, S, sig, C, R); R is a log-radius (for Section 4)."""
    L, S, sig, C, R = (state[k] for k in ('L', 'S', 'sig', 'C', 'R'))
    WK, WL, WS = state.get('WK', []), state.get('WL', []), state.get('WS', [])   # weight index and coefficient per layer
    rx, cx = L.shape; rw, cw = Lw.shape

    def kron_idx(M):          # Z[(i,k),(j,l)] = M[i,j]
        return np.repeat(np.repeat(M, rw, 0), cw, 1)

    def kron_w(Wm):           # Z[(i,k),(j,l)] = Wm[k,l]
        return np.tile(Wm, (rx, cx))

    L2 = kron_idx(L) + kron_w(Lw)
    S2, sig2 = kron_idx(S), kron_idx(sig)
    C2 = kron_idx(C) + kron_w(Lw)
    R2 = kron_idx(R) + Rw
    kk, ll = np.meshgrid(np.arange(rw), np.arange(cw), indexing='ij')
    WK2 = [kron_idx(a) for a in WK] + [kron_w(kk)]
    WL2 = [kron_idx(a) for a in WL] + [kron_w(ll)]
    WS2 = [kron_idx(a) for a in WS] + [np.ones(L2.shape, int)]
    if mask is not None and not isinstance(mask, np.ndarray):       # (seed, p): drawn at the layer's actual shape
        mask = np.random.default_rng(mask[0]).random(L2.shape) < mask[1]
    if mask is not None:
        if mask_mode == 'one':
            L2 = np.where(mask, 0.0, L2); C2 = np.where(mask, 0.0, C2); R2 = np.where(mask, 0.0, R2)
        else:
            L2 = np.where(mask, -np.inf, L2); C2 = np.where(mask, -np.inf, C2); R2 = np.where(mask, 0.0, R2)
        S2 = np.where(mask, -1, S2); sig2 = np.where(mask, 0, sig2)
        WS2 = [np.where(mask, 0, a) for a in WS2]
    if invert:                 # a removed entry (exponent -inf, value 0) stays removed
        gone = np.isneginf(L2)
        L2 = np.where(gone, -np.inf, -L2); C2 = np.where(gone, -np.inf, -C2); sig2 = -sig2
        WS2 = [-a for a in WS2]
    if L2.size == 0:
        r = c = np.zeros(0, int)
    else:
        r = top_k(L2.max(1), Kr, tau); c = top_k(L2.max(0), Kc, tau)
    ix = np.ix_(r, c)
    full = dict(L=L2, S=S2, sig=sig2, WK=WK2, WL=WL2, WS=WS2)
    return dict(L=L2[ix], S=S2[ix], sig=sig2[ix], C=C2[ix], R=R2[ix], rows=r, cols=c, Lfull=L2, Rfull=R2,
                WK=[a[ix] for a in WK2], WL=[a[ix] for a in WL2], WS=[a[ix] for a in WS2], full=full)


def init_state(xhat, rho=0.0):
    n = xhat.size
    return dict(L=xhat.copy(), S=np.arange(n).reshape(xhat.shape), sig=np.ones(xhat.shape, int),
                C=np.zeros(xhat.shape), R=np.full(xhat.shape, rho))


def forward0(xhat, Ws, K, tau=-np.inf, masks=None, mask_mode='one', inverts=None, rho_x=0.0, rho_w=0.0):
    st = init_state(xhat, rho_x); trace = []
    for t, Lw in enumerate(Ws):
        st = layer0(st, Lw, K, K, tau, None if masks is None else masks[t], mask_mode,
                    False if inverts is None else inverts[t], rho_w)
        trace.append(st)
    return st, trace


# --------------------------------------------------------------------------------------------- KP-LNN-Sigma
def sigma_layer(Xh, Bh, Ah, T):
    """log Y_ij = T * LSE_kl((Bh_ik + Xh_kl + Ah_jl)/T); also the log-Jacobian d log Y_ij / d log X_kl."""
    E = Bh[:, None, :, None] + Xh[None, None, :, :] + Ah[None, :, None, :]       # (i, j, k, l)
    flat = E.reshape(E.shape[0], E.shape[1], -1) / T
    LY = T * logsumexp(flat, axis=-1)
    J = softmax(flat, axis=-1)                                                   # rows sum to 1
    return LY, J


def participation(J):
    return 1.0 / (J ** 2).sum(-1)


def diff_radius(full, a, b, rho_x, rho_w):
    """Exact log-radius of (entry a - entry b) of one matrix, as linear forms in independent box variables:
    shared variables with equal coefficients cancel.  a, b are flat indices."""
    S, sig = full['S'].ravel(), full['sig'].ravel()
    if S[a] >= 0 and S[a] == S[b]:
        r = abs(sig[a] - sig[b]) * rho_x
    else:
        r = (abs(sig[a]) + abs(sig[b])) * rho_x
    for K_, L_, W_ in zip(full['WK'], full['WL'], full['WS']):
        k, l, w = K_.ravel(), L_.ravel(), W_.ravel()
        if k[a] == k[b] and l[a] == l[b]:
            r += abs(w[a] - w[b]) * rho_w
        else:
            r += (abs(w[a]) + abs(w[b])) * rho_w
    return r


def pair_radius(full, rho_x, rho_w):
    """Vectorised diff_radius over all pairs of entries of one matrix: (N, N)."""
    S, sig = full['S'].ravel(), full['sig'].ravel()
    same = (S[:, None] == S[None, :]) & (S[:, None] >= 0)
    R = np.where(same, np.abs(sig[:, None] - sig[None, :]), np.abs(sig)[:, None] + np.abs(sig)[None, :]) * rho_x
    for K_, L_, W_ in zip(full['WK'], full['WL'], full['WS']):
        k, l, w = K_.ravel(), L_.ravel(), W_.ravel()
        sm = (k[:, None] == k[None, :]) & (l[:, None] == l[None, :])
        R = R + np.where(sm, np.abs(w[:, None] - w[None, :]), np.abs(w)[:, None] + np.abs(w)[None, :]) * rho_w
    return R


def certify_dependent(full, axis_rows, K, tau, lo, hi, rho_x, rho_w):
    """Dependency-aware sound certification: line i certainly outranks line j if some entry of i exceeds every entry
    of j for every model in the box (exact range of each pairwise difference).  Status per line: 1 kept, 0 dropped,
    -1 undecided."""
    L = full['L']; shp = L.shape
    PR = pair_radius(full, rho_x, rho_w)
    Lf = L.ravel()
    with np.errstate(invalid='ignore'):
        D = Lf[:, None] - Lf[None, :]
    surely = np.where(np.isneginf(Lf)[None, :], True, np.where(np.isneginf(Lf)[:, None], False, D > PR))
    idx = np.arange(L.size).reshape(shp)
    lines = [idx[i, :] for i in range(shp[0])] if axis_rows else [idx[:, j] for j in range(shp[1])]
    n = len(lines)
    beats = np.zeros((n, n), bool)
    for i in range(n):
        for j in range(n):
            if i != j:
                beats[i, j] = bool(np.any(np.all(surely[np.ix_(lines[i], lines[j])], axis=1)))
    st = np.full(n, -1)
    for i in range(n):
        if lo[i] > tau and np.sum(~beats[i][np.arange(n) != i]) <= K - 1:
            st[i] = 1
        elif hi[i] <= tau or beats[:, i].sum() >= K:
            st[i] = 0
    return st
