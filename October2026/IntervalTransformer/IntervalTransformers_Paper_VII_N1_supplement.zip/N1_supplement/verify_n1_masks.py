"""N1, Proposition 6(c): removing masks void the copy-map bound (post-review measurement).
    python3 verify_n1_masks.py > verify_n1_masks_output.txt"""
import numpy as np
from kplnn import forward0
rng = np.random.default_rng(7)
for K, depth, bound in ((2, 2, 36), (4, 2, 225)):
    best = 0
    for net in range(3):
        Ws = [rng.normal(0, 1, (2, 2)) for _ in range(depth)]
        masks = [(int(rng.integers(1 << 30)), 0.2) for _ in range(depth)]
        maps = set()
        for _ in range(8000):
            st, _ = forward0(rng.normal(0, 1, (3, 3)), Ws, K, masks=masks, mask_mode='inf')
            maps.add(tuple(st['S'].ravel()))
        best = max(best, len(maps))
    print(f'K={K} depth={depth}, removing masks at rate 0.2: up to {best} distinct copy maps (bound without masks {bound})')
