"""Numerical checks for N1 (the KP-LNN note).   python3 verify_n1.py > verify_n1_output.txt

C1  Proposition 1 (H): every KP-LNN-0 output is one input exponent (sign +-1) plus a constant, or a constant;
    its log-Jacobian has at most one non-zero entry per row, equal to its sign; inputs present can only shrink.
C2  Proposition 2: inside a matrix every non-constant entry has the same sign; with budget-only pruning and no
    constant (value-1) masks the body is gain-equivariant; masks or an absolute threshold break this.
C3  Proposition 3: selection functions cannot accumulate; lower bounds log2/(2K) (sum) and R/K (product), and
    selection functions that attain them.
C4  Proposition 4: KP-LNN-Sigma at T = 1 is Y = B X A^T; its log-Jacobian rows are probability vectors; T -> 0
    gives the tropical product; effective fan-in against T.
C5  Proposition 5: pruning under tolerance; sound energy intervals, certified survivor sets, margins, branching,
    exact output widths for a certified route.
C6  Section 5: routing patterns against depth and budget (measurement); discontinuity at route switches.
"""
import itertools, math, sys
import numpy as np
from math import comb
from kplnn import forward0, layer0, init_state, sigma_layer, participation, top_k, certify_dependent

RNG = np.random.default_rng(20261011)
FAILS = []


def check(name, ok, detail=''):
    print(f'[{"PASS" if ok else "FAIL"}] {name}  {detail}')
    if not ok:
        FAILS.append(name)


def head(s):
    print('\n' + '=' * 100 + '\n' + s)


def rand_net(depth, p_mask=0.0, p_inv=0.0, shape_w=(2, 2), K=4, xs=(3, 3)):
    Ws = [RNG.normal(0, 1, shape_w) for _ in range(depth)]
    masks = [(int(RNG.integers(1 << 30)), p_mask) if p_mask > 0 else None for _ in range(depth)]
    inv = [bool(RNG.random() < p_inv) for _ in range(depth)]
    return Ws, masks, inv


# ============================================================================================= C1
head('C1  Proposition 1: one input per output')
bad_form, bad_jac, n_out, n_const, n_route_change, bad_rec = 0, 0, 0, 0, 0, 0
for trial in range(600):
    depth = 1 + trial % 4
    mode = 'one' if trial % 2 else 'inf'
    tau = -np.inf if trial % 3 else RNG.normal(0, 1)
    Ws, masks, inv = rand_net(depth, p_mask=0.15, p_inv=0.4)
    x = RNG.normal(0, 1, (3, 3))
    st, tr = forward0(x, Ws, 4, tau, masks, mode, inv)
    if st['L'].size == 0:
        continue
    pred = np.where(st['S'] >= 0, st['sig'] * x.ravel()[np.maximum(st['S'], 0)] + st['C'], st['C'])
    bad_form += int(not np.allclose(pred, st['L'], equal_nan=False))
    # independent reconstruction: x and the weights indexed by the provenance, evaluated from the raw parameters
    rec = np.where(st['S'] >= 0, st['sig'] * x.ravel()[np.maximum(st['S'], 0)], 0.0) + sum(
        ws * W[k, l] for ws, k, l, W in zip(st['WS'], st['WK'], st['WL'], Ws))
    fin = np.isfinite(st['L'])
    bad_rec += int(not np.allclose(rec[fin], st['L'][fin]) or (mode == 'one' and not fin.all()))
    n_out += st['L'].size; n_const += int((st['S'] < 0).sum())
    # finite-difference log-Jacobian
    J = np.zeros((st['L'].size, 9)); eps = 1e-6; changed = False
    for a in range(9):
        xp = x.copy().ravel(); xp[a] += eps
        st2, tr2 = forward0(xp.reshape(3, 3), Ws, 4, tau, masks, mode, inv)
        if any((t1['rows'].shape != t2['rows'].shape) or np.any(t1['rows'] != t2['rows']) or np.any(t1['cols'] != t2['cols'])
               for t1, t2 in zip(tr, tr2)):
            changed = True; break
        J[:, a] = ((st2['L'] - st['L']) / eps).ravel()
    if changed:
        n_route_change += 1; continue
    J = np.where(np.isfinite(J), J, 0.0)
    nz = np.abs(J) > 1e-3
    expect = np.zeros_like(J)
    for o, (s, g) in enumerate(zip(st['S'].ravel(), st['sig'].ravel())):
        if s >= 0:
            expect[o, s] = g
    bad_jac += int(np.any(nz.sum(1) > 1) or not np.allclose(J, expect, atol=1e-4))
check('C1a every output = sigma * xhat[S] + C, or a constant (600 random stacks, depth 1-4, masks, inversions, thresholds)', bad_form == 0,
      f'({n_out} outputs, {n_const} constant)')
check("C1a' every finite output = sigma * x[S] + sum of +-W_t[k_t, l_t] rebuilt from the raw parameters", bad_rec == 0)
check('C1b log-Jacobian: at most one non-zero entry per row, equal to the provenance sign', bad_jac == 0,
      f'({n_route_change} stacks skipped because the finite-difference step changed the route)')

nest_bad = 0
for trial in range(300):
    Ws, masks, inv = rand_net(1 + trial % 4, p_mask=0.15, p_inv=0.4)
    st, tr = forward0(RNG.normal(0, 1, (3, 3)), Ws, 4, -np.inf if trial % 2 else 0.0, masks, 'one', inv)
    prev = set(range(9))
    for t_ in tr:
        cur = set(t_['S'][t_['S'] >= 0].ravel().tolist())
        nest_bad += int(not cur <= prev); prev = cur
check('C1c nesting: the input entries present after layer t are a subset of those after layer t-1', nest_bad == 0)

# ============================================================================================= C2
head('C2  Proposition 2: one sign per matrix; gain equivariance')
mixed = 0
for trial in range(300):
    depth = 1 + trial % 4
    Ws, masks, inv = rand_net(depth, p_mask=0.15, p_inv=0.5)
    st, tr = forward0(RNG.normal(0, 1, (3, 3)), Ws, 4, -np.inf, masks, 'one', inv)
    for t_ in tr:
        s = t_['sig'][t_['S'] >= 0]
        mixed += int(len(np.unique(s)) > 1)
check('C2a within every matrix all non-constant entries share one sign', mixed == 0)
viol = 0
for trial in range(300):
    depth = 1 + trial % 4
    Ws, _, inv = rand_net(depth, p_inv=0.5)
    x = RNG.normal(0, 1, (3, 3)); lam = RNG.normal(0, 3)
    s1, t1 = forward0(x, Ws, 4, -np.inf, None, 'one', inv)
    s2, t2 = forward0(x + lam, Ws, 4, -np.inf, None, 'one', inv)
    same = all(np.array_equal(a['rows'], b['rows']) and np.array_equal(a['cols'], b['cols']) for a, b in zip(t1, t2))
    viol += int(not (same and np.allclose(s2['L'], s1['L'] + s1['sig'] * lam)))
check('C2b no masks, budget-only pruning: Y(lambda X) = lambda^sigma Y(X), same route, for 300 random gains', viol == 0)
br_mask = br_tau = 0
for trial in range(300):
    Ws, masks, inv = rand_net(2, p_mask=0.3)
    x = RNG.normal(0, 1, (3, 3)); lam = 3.0
    _, t1 = forward0(x, Ws, 4, -np.inf, masks, 'one', inv); _, t2 = forward0(x + lam, Ws, 4, -np.inf, masks, 'one', inv)
    br_mask += int(not all(np.array_equal(a['rows'], b['rows']) and np.array_equal(a['cols'], b['cols']) for a, b in zip(t1, t2)))
    _, t1 = forward0(x, Ws, 4, 0.5, None, 'one', inv); _, t2 = forward0(x + lam, Ws, 4, 0.5, None, 'one', inv)
    br_tau += int(not all(np.array_equal(a['rows'], b['rows']) and np.array_equal(a['cols'], b['cols']) for a, b in zip(t1, t2)))
check('C2c value-1 masks or an absolute threshold tau break gain equivariance (route changes under a gain of e^3)',
      br_mask > 0 and br_tau > 0, f'(masks: {br_mask}/300 stacks; tau = 0.5: {br_tau}/300)')

dec = tot = 0
for trial in range(2000):
    Ws, _, _ = rand_net(2)
    x = RNG.normal(0, 1, (3, 3)); a = RNG.integers(9)
    s1, _ = forward0(x, Ws, 4); xp = x.ravel().copy(); xp[a] += 0.3
    s2, _ = forward0(xp.reshape(3, 3), Ws, 4)
    tot += 1; dec += int(np.any(s2['L'] < s1['L'] - 1e-12))
check('C2d KP-LNN-0 is not monotone even without flips or masks (raising one input lowers some output)', dec > 0,
      f'({dec}/{tot} two-layer stacks, input raised by 0.3)')

# ============================================================================================= C3
head('C3  Proposition 3: what selection functions cannot do')
h = lambda d: np.log1p(np.exp(-np.abs(d)))           # log(e^a + e^b) - max(a, b)
D = 40.0; dg = np.linspace(0, D, 400001); drop = h(0.0) - h(D)


def best_piecewise_error(edges, target, x, slopes):
    """Sup error of the best approximant that, on each piece, is slope*x + constant with slope from `slopes`."""
    worst = 0.0
    last = len(edges) - 2
    for i, (lo, hi) in enumerate(zip(edges[:-1], edges[1:])):
        m = (x >= lo) & ((x < hi) if i < last else (x <= hi))   # half-open pieces: an endpoint belongs to one piece
        if not m.any():
            continue
        best = min((np.ptp(target[m] - s * x[m]) / 2 for s in slopes))
        worst = max(worst, best)
    return worst


ok_lb, ok_ach, rows_ = True, True, []
for K in (1, 2, 4, 8, 16):
    lb = drop / (2 * K)
    # attain: copy a, constants at the midpoints of equal drops of h
    levels = h(0.0) - drop * np.arange(K + 1) / K
    edges = np.concatenate([[0.0], [-np.log(np.expm1(v)) for v in levels[1:-1]], [D]])
    ach = best_piecewise_error(edges, h(dg), dg, (0.0,))
    ok_ach &= abs(ach - lb) < 1e-4
    # random partitions with slope choices {-1, 0, +1} never beat it
    worst_rand = np.inf
    for _ in range(300):
        e = np.sort(np.concatenate([[0.0, D], RNG.uniform(0, 8, K - 1)]))
        worst_rand = min(worst_rand, best_piecewise_error(e, h(dg[::10]), dg[::10], (-1.0, 0.0, 1.0)))
    ok_lb &= worst_rand >= lb - 1e-6
    rows_.append(f'K={K:2d}: bound {lb:.4f}, attained {ach:.4f}, best of 300 random partitions {worst_rand:.4f}')
check('C3a log(x1+x2): no K-piece selection function beats log2/(2K) on a ray; equal-drop pieces attain it', ok_lb and ok_ach)
for r_ in rows_:
    print('      ' + r_)
Rr = 5.0; ag = np.linspace(-Rr, Rr, 200001); ok = True
for K in (1, 2, 4, 8):
    e = np.sort(np.concatenate([[-Rr, Rr], RNG.uniform(-Rr, Rr, K - 1)]))
    errs = [best_piecewise_error(np.sort(np.concatenate([[-Rr, Rr], RNG.uniform(-Rr, Rr, K - 1)])), 2 * ag[::20], ag[::20], (-1.0, 0.0, 1.0)) for _ in range(200)]
    eq = best_piecewise_error(np.linspace(-Rr, Rr, K + 1), 2 * ag, ag, (1.0,))
    ok &= min(errs) >= Rr / K - 1e-6 and abs(eq - Rr / K) < 1e-6
check('C3b log(x1 x2) on the diagonal of [-R, R]^2: sup error >= R/K, attained by equal pieces of slope 1', ok)

# ============================================================================================= C4
head('C4  Proposition 4: KP-LNN-Sigma')
Xh = RNG.normal(0, 1, (8, 8)); Ah, Bh = RNG.normal(0, 1, (4, 8)), RNG.normal(0, 1, (4, 8))
LY, J = sigma_layer(Xh, Bh, Ah, 1.0)
check('C4a T = 1: log Y = log(B X A^T) exactly', np.allclose(LY, np.log(np.exp(Bh) @ np.exp(Xh) @ np.exp(Ah).T)))
check('C4b log-Jacobian rows are probability vectors (non-negative, sum 1)', bool(np.all(J >= 0) and np.allclose(J.sum(-1), 1)))
E = (Bh[:, None, :, None] + Xh[None, None, :, :] + Ah[None, :, None, :]).reshape(4, 4, -1)
LY0, J0 = sigma_layer(Xh, Bh, Ah, 1e-3)
check('C4c T -> 0: log Y -> tropical product max_kl(B_ik + X_kl + A_jl), within T log 64', bool(np.all(np.abs(LY0 - E.max(-1)) <= 1e-3 * np.log(64) + 1e-12)))
for T in (1.0, 0.3, 0.1, 0.03, 0.01):
    _, Jt = sigma_layer(Xh, Bh, Ah, T)
    print(f'      T = {T:5.2f}: median effective fan-in {np.median(participation(Jt)):6.2f} of 64; median largest weight {np.median(Jt.max(-1)):.3f}')
x12 = RNG.normal(0, 1, (1, 2))
LYs, _ = sigma_layer(x12, np.zeros((1, 1)), np.zeros((1, 2)), 1.0)
check('C4d T = 1 represents log(x1 + x2) exactly (B, A = ones)', np.allclose(LYs[0, 0], np.log(np.exp(x12).sum())))
LYa, _ = sigma_layer(Xh + 2.0, Bh, Ah, 0.1); LYb, _ = sigma_layer(Xh, Bh, Ah, 0.1)
check('C4e KP-LNN-Sigma is gain-equivariant at every T (log Y shifts by the log gain)', np.allclose(LYa, LYb + 2.0))

# ============================================================================================= C5
head('C5  Proposition 5: pruning under tolerance')


def certify(lo, hi, K, tau):
    """Status per index: 1 certainly kept, 0 certainly dropped, -1 uncertain (sound for any joint law in the box)."""
    n = len(lo); st = np.full(n, -1)
    for i in range(n):
        above_lo = np.sum(np.delete(hi, i) >= lo[i])           # rivals that may beat i
        below_hi = np.sum(np.delete(lo, i) > hi[i])            # rivals that certainly beat i
        if lo[i] > tau and above_lo <= K - 1:
            st[i] = 1
        elif hi[i] <= tau or below_hi >= K:
            st[i] = 0
    return st


def interval_route(x, Ws, K, tau, masks, inv, rho):
    """Centre route with sound energy intervals; returns per-layer certified flags and survivor sets."""
    st = init_state(x, rho); out = []
    for t, Lw in enumerate(Ws):
        nxt = layer0(st, Lw, K, K, tau, masks[t], 'one', inv[t], rho)
        Lf, Rf = nxt['Lfull'], nxt['Rfull']
        flags = []
        for ax in (1, 0):
            lo, hi = (Lf - Rf).max(ax), (Lf + Rf).max(ax)
            s = certify(lo, hi, K, tau)
            flags.append(s)
        ok = bool(np.all(flags[0] >= 0) and np.all(flags[1] >= 0))
        out.append(dict(ok=ok, rows=np.where(flags[0] == 1)[0], cols=np.where(flags[1] == 1)[0], st=nxt,
                        u=int((flags[0] < 0).sum() + (flags[1] < 0).sum()),
                        c=(int((flags[0] == 1).sum()), int((flags[1] == 1).sum())), nr=int((flags[0] < 0).sum()), nc=int((flags[1] < 0).sum())))
        if not ok:
            break
        st = nxt
    return out


def sample_model(x, Ws, rho, corners):
    f = (lambda s: np.sign(RNG.uniform(-1, 1, s))) if corners else (lambda s: RNG.uniform(-1, 1, s))
    return x + rho * f(x.shape), [W + rho * f(W.shape) for W in Ws]


viol = viol_out = 0; table = {}; branch_seen, branch_bound, loose = [], [], 0; n_unc = 0; attain_bad = attain_n = 0
for rho in (0.003, 0.01, 0.03, 0.1, 0.3):
    cert_depth = np.zeros(4)
    for trial in range(400):
        Ws, masks, inv = rand_net(3, p_mask=0.1, p_inv=0.3)
        x = RNG.normal(0, 1, (3, 3)); tau = -np.inf if trial % 2 else -1.0
        route = interval_route(x, Ws, 4, tau, masks, inv, rho)
        d_ok = sum(r['ok'] for r in route); cert_depth[d_ok] += 1
        sets = {}
        for m in range(60):
            xs, Wss = sample_model(x, Ws, rho, corners=m % 2 == 0)
            _, trm = forward0(xs, Wss, 4, tau, masks, 'one', inv)
            for t, r in enumerate(route):
                if r['ok']:
                    if not (np.array_equal(trm[t]['rows'], r['rows']) and np.array_equal(trm[t]['cols'], r['cols'])):
                        viol += 1
                    if t == len(route) - 1 or True:
                        Lc, Rc = r['st']['L'], r['st']['R']
                        if t == len(trm) - 1 and d_ok == len(Ws):
                            viol_out += int(np.any(trm[t]['L'] > Lc + Rc + 1e-9) or np.any(trm[t]['L'] < Lc - Rc - 1e-9))
                else:
                    sets[(tuple(trm[t]['rows']), tuple(trm[t]['cols']))] = 1
                    break
        if not route[-1]['ok']:
            r = route[-1]; n_unc += 1
            K = 4
            bnd = comb(r['nr'], max(K - r['c'][0], 0)) * comb(r['nc'], max(K - r['c'][1], 0)) if tau == -np.inf else None
            branch_seen.append(len(sets))
            if bnd is not None:
                branch_bound.append(bnd)
            loose += int(len(sets) <= 1)
        # attainment of the output radius for a fully certified route (small rho, one output)
        if d_ok == len(Ws) and rho <= 0.01 and trial < 60:
            stc = route[-1]['st']
            nc_idx = np.argwhere(stc['S'] >= 0)
            if len(nc_idx) == 0:
                continue
            o = tuple(nc_idx[0])
            g_x = np.zeros(9); g_w = [np.zeros(W.shape) for W in Ws]; eps = 1e-7
            base = stc['L'][o]
            for a in range(9):
                xp = x.ravel().copy(); xp[a] += eps
                g_x[a] = (forward0(xp.reshape(3, 3), Ws, 4, tau, masks, 'one', inv)[0]['L'][o] - base) / eps
            for t, W in enumerate(Ws):
                for k in np.ndindex(W.shape):
                    Wp = [w.copy() for w in Ws]; Wp[t][k] += eps
                    g_w[t][k] = (forward0(x, Wp, 4, tau, masks, 'one', inv)[0]['L'][o] - base) / eps
            xe = x + rho * np.sign(np.round(g_x, 3)).reshape(3, 3)
            We = [W + rho * np.sign(np.round(g, 3)) for W, g in zip(Ws, g_w)]
            ext = forward0(xe, We, 4, tau, masks, 'one', inv)[0]['L'][o]
            attain_n += 1; attain_bad += int(abs(ext - (base + stc['R'][o])) > 1e-9)
    table[rho] = cert_depth / cert_depth.sum()
check('C5a certified survivor sets: no sampled model in the box ever pruned differently (sound)', viol == 0)
check('C5b fully certified routes: every sampled output lies in centre +- radius', viol_out == 0)
check('C5c fully certified routes: the radius of a non-constant output is attained by the gradient-sign corner (exact)', attain_bad == 0, f'({attain_n} outputs)')
print('      share of 400 random 3-layer stacks (K = 4) whose route is certified through depth d:')
for rho, v in table.items():
    print(f'        rho = {rho:5.3f}: depth >= 1 {1 - v[0]:.3f}, >= 2 {max(1 - v[0] - v[1], 0):.3f}, all 3 {v[3]:.3f}')
bb = np.array(branch_bound)
print(f'      uncertain layers: {n_unc}; distinct survivor sets seen in 60 samples: median {np.median(branch_seen):.0f}, max {max(branch_seen)}; '
      f'combinatorial bound (budget-only): median {np.median(bb):.0f}, max {bb.max()}; uncertain layers where sampling found one set only: {loose}')



def route_both(x, Ws, K, tau, masks, inv, rho):
    """Certified depth under the entrywise rule and under the dependency-aware rule (same stack)."""
    st = init_state(x, rho); d_e = d_d = None; out_sets = []
    for t, Lw in enumerate(Ws):
        nxt = layer0(st, Lw, K, K, tau, masks[t], 'one', inv[t], rho)
        Lf, Rf = nxt['Lfull'], nxt['Rfull']
        ok_e = ok_d = True; sets = []
        for ax, rows_axis in ((1, True), (0, False)):
            lo, hi = (Lf - Rf).max(ax), (Lf + Rf).max(ax)
            se = certify(lo, hi, K, tau); sd = certify_dependent(nxt['full'], rows_axis, K, tau, lo, hi, rho, rho)
            ok_e &= bool(np.all(se >= 0)); ok_d &= bool(np.all(sd >= 0)); sets.append(np.where(sd == 1)[0])
        if d_e is None and not ok_e:
            d_e = t
        if not ok_d:
            d_d = t; break
        out_sets.append(sets); st = nxt
    return (len(Ws) if d_e is None else d_e), (len(Ws) if d_d is None else d_d), out_sets


viol_d = 0; rates = {}; weaker = 0
for rho in (0.01, 0.03, 0.1):
    de_all, dd_all = [], []
    for trial in range(200):
        Ws, masks, inv = rand_net(3, p_mask=0.1 if trial % 2 else 0.0, p_inv=0.3)
        x = RNG.normal(0, 1, (3, 3)); tau = -np.inf if trial % 2 else -1.0
        de, dd, sets = route_both(x, Ws, 4, tau, masks, inv, rho)
        de_all.append(de); dd_all.append(dd)
        for m in range(40):
            xs, Wss = sample_model(x, Ws, rho, corners=m % 2 == 0)
            _, trm = forward0(xs, Wss, 4, tau, masks, 'one', inv)
            for t, (rs, cs) in enumerate(sets):
                viol_d += int(not (np.array_equal(trm[t]['rows'], rs) and np.array_equal(trm[t]['cols'], cs)))
    de_all, dd_all = np.array(de_all), np.array(dd_all)
    weaker += int(np.sum(dd_all < de_all))
    rates[rho] = [((de_all >= d).mean(), (dd_all >= d).mean()) for d in (1, 2, 3)]
check('C5e dependency-aware certification is sound (no sampled model pruned differently)', viol_d == 0)
check('C5f the dependency-aware rule certifies at least as deep as the entrywise rule on every stack', weaker == 0, '(600 stacks)')
print('      certified through depth d, entrywise rule / dependency-aware rule (200 stacks per radius):')
for rho, rr in rates.items():
    print(f'        rho = {rho:4.2f}: ' + ', '.join(f'd>={d + 1}: {a:.3f} / {b:.3f}' for d, (a, b) in enumerate(rr)))

# margin: radius of an output after t layers is rho_x + t rho_w (no masks)
Ws, _, _ = rand_net(3)
st, tr = forward0(RNG.normal(0, 1, (3, 3)), Ws, 4, rho_x=0.1, rho_w=0.05)
check('C5d log-radius after t layers = rho_x + t rho_w (no masks)', all(np.allclose(t_['R'], 0.1 + (i + 1) * 0.05) for i, t_ in enumerate(tr)))

# ============================================================================================= C6
head('C6  Routing patterns against depth and budget (measurement; 3x3 log-inputs, 2x2 weights, no masks, budget-only)')
N = 40000
Xs = RNG.normal(0, 1, (N, 3, 3))
for K in (2, 3, 4):
    for depth in (1, 2, 3):
        cnt_route, cnt_copy, cnt_route_gain = [], [], []
        for net in range(3):
            Ws, _, _ = rand_net(depth, K=K)
            routes, copies = set(), set()
            for x in Xs:
                st, tr = forward0(x, Ws, K)
                routes.add(tuple((tuple(t['rows']), tuple(t['cols'])) for t in tr))
                copies.add(tuple(st['S'].ravel()))
            cnt_route.append(len(routes)); cnt_copy.append(len(copies))
        cap = 1
        r, c = 3, 3
        for t in range(depth):
            r, c = r * 2, c * 2
            cap *= comb(r, min(K, r)) * comb(c, min(K, c))
            r, c = min(K, r), min(K, c)
        print(f'      K={K} depth={depth}: distinct routes {np.mean(cnt_route):8.1f} (nets: {cnt_route}), distinct copy maps {np.mean(cnt_copy):8.1f}; '
              f'combinatorial cap {cap}')

cm_bad, cm_rows = 0, []
for K in (2, 3, 4):
    bound = comb(K + 2, 2) ** 2
    for depth in (1, 2, 3, 4, 5):
        counts = []
        for net in range(3):
            Ws, _, _ = rand_net(depth, K=K)
            maps = set()
            for x in Xs[:8000]:
                st, _ = forward0(x, Ws, K)
                maps.add(tuple(st['S'].ravel()))
                rr_, cc_ = st['S'] // 3, st['S'] % 3          # each output row traces to one X row, columns alike
                cm_bad += int(not (np.all(rr_ == rr_[:, :1]) and np.all(cc_ == cc_[:1, :])
                                   and np.all(np.diff(rr_[:, 0]) >= 0) and np.all(np.diff(cc_[0, :]) >= 0)))
            counts.append(len(maps))
        cm_bad += int(max(counts) > bound)
        cm_rows.append(f'K={K} depth={depth}: copy maps {counts} (bound {bound})')
check('C6c copy maps: S(r, c) = (rho(r), gamma(c)) with rho, gamma nondecreasing; count <= C(K+2, 2)^2 at every depth', cm_bad == 0)
for r_ in cm_rows:
    print('      ' + r_)

jumps, n_switch = [], 0
for trial in range(200):
    Ws, _, _ = rand_net(2)
    x0, x1 = RNG.normal(0, 1, (3, 3)), RNG.normal(0, 1, (3, 3))
    prev_st, prev_tr = forward0(x0, Ws, 4)
    for s in np.linspace(0, 1, 2001)[1:]:
        st, tr = forward0((1 - s) * x0 + s * x1, Ws, 4)
        if not all(np.array_equal(a['rows'], b['rows']) and np.array_equal(a['cols'], b['cols']) for a, b in zip(tr, prev_tr)):
            n_switch += 1
            jumps.append(np.abs(st['L'] - prev_st['L']).max())
        prev_st, prev_tr = st, tr
jumps = np.array(jumps)
print(f'      route switches along 200 random segments (2000 steps each): {n_switch}; largest output change at a switch: '
      f'median {np.median(jumps):.3f}, 90th percentile {np.percentile(jumps, 90):.3f} (log units; a continuous map would move by about 1e-3)')
check('C6b KP-LNN-0 outputs jump at route switches (not continuous piecewise-linear)', np.median(jumps) > 0.05)

print('\nALL PASS' if not FAILS else f'\nFAILED: {FAILS}')
sys.exit(1 if FAILS else 0)
