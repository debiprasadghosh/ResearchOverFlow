# N1 supplement: What KP-LNN Computes

Debi Prasad Ghosh, 11 October 2026.

- `Log_Interval_Networks_N1_What_KP-LNN_Computes.md`: the note.
- `kplnn.py`: KP-LNN-0 with full provenance (input, weight indices, coefficients, radii), entrywise and dependency-aware route certification, and KP-LNN-Sigma.
- `verify_n1.py` and `verify_n1_output.txt`: 23 pass/fail checks (C1-C6), all passing, plus the measurements quoted in the note (about 9 minutes).
- `verify_n1_masks.py` and `verify_n1_masks_output.txt`: removing masks void the copy-map bound of Proposition 6(c).

Python 3.11.15, NumPy 2.4.4, SciPy 1.17.1.
