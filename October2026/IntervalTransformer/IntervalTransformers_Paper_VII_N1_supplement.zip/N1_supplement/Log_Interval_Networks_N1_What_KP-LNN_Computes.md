# What KP-LNN Computes: One Input per Output, Two Operators, and Pruning under Tolerance

**Debi Prasad Ghosh**

Debias Parametric Guru, Kolkata, India | debiprasadghosh@gmail.com

11 October 2026 · N1 of the log interval network programme · A note, with numerical checks

---

**Abstract.** The Kronecker Product Logarithmic Neural Network (KP-LNN) [1] is a forward body built entirely in the logarithmic number system (LNS). Each layer forms a Kronecker product with a positive weight matrix, applies typed masks, and keeps the rows and columns of largest maximum exponent within a budget. It never adds in the value domain.

The research agenda [2] registered N1, a note that states what this body computes and what interval semantics make of it. We prove six propositions and run 23 pass/fail numerical checks, all of which pass, alongside several measurements.

1. **One input per output (Proposition 1; the agenda's Proposition H).** Every output of a KP-LNN stack is a constant, or one input entry or its reciprocal, times a product of weights and inverse weights. Its log-domain Jacobian has at most one non-zero entry per row, equal to ±1.
2. **Structure (Proposition 2).** When sign flips act on whole matrices:
   - every non-constant entry of a matrix carries the same sign;
   - without value-1 masks or an absolute threshold, the body is *gain-equivariant*, routing on input ratios only;
   - the set of input entries present can only shrink with depth.
3. **No accumulation (Proposition 3).** Neither $x_1+x_2$ nor $x_1x_2$ is representable on any open set.
   - A selection function with $K$ pieces along a ray errs by at least $\log2/(2K)$ in log on the sum.
   - On the product, over inputs in $[-R,R]$ (log), the error is at least $R/K$.
   - Selection functions attain both bounds.
4. **Two operators, one name (Proposition 4).** The basal-ganglia paper's "KP-LNN layer" [3] computes $Y=BXA^\top$ with log-sum-exp. We call it **KP-LNN-Σ**, and the published body **KP-LNN-0**.
   - At temperature 1, KP-LNN-Σ is the exact positive bilinear map and accumulates: the median effective fan-in was 10.6 of 64 inputs.
   - As the temperature goes to 0, its fan-in goes to 1. It stays continuous and monotone, which KP-LNN-0 is not.
5. **Pruning under tolerance (Proposition 5).** For a fixed route, log intervals pass through KP-LNN-0 exactly, with radius $\rho_x+t\rho_w$ after $t$ layers. The route itself can be certified.
   - *Two sound tests.* An entrywise test, and a dependency-aware test that lets shared variables cancel. No sampled model ever violated either.
   - *Certification falls with depth.* At a log radius of 0.03 per factor, the entrywise test certified 62% of random 3-layer stacks at the first layer and 8% through all three. On a separate sample, the dependency-aware test raised certification through all three layers from 10% to 18%.
   - *Branching.* Where certification fails, the route branches: up to 22 distinct survivor sets appeared among 60 sampled models.
6. **The expressivity prediction, restated (Proposition 6).** The KP-LNN paper predicts that linear regions grow multiplicatively with depth and pruning budgets [1, §5].
   - *Where the regions lie.* For KP-LNN-0 they are unions of cells of an arrangement of hyperplanes $\hat x_a-\hat x_b=c$.
   - *Discontinuity.* Outputs jump between them, by a median of 1.8 log units at a switch. Region counts for continuous networks therefore do not carry over.
   - *Routes grow.* In sampled counts at budget 4, routes grew with depth: 35, 488, 990.
   - *Copy maps do not.* Without masks, each output row copies from one input row, and the rows are taken in order. The number of copy maps (which output copies which input) is therefore at most $\binom{K+2}{2}^2$ for a $3\times3$ input, whatever the depth. The samples approach this bound and never exceed it.

KP-LNN-0 is a router, not an accumulator. Where the programme needs evidence to add up, as in the basal-ganglia decks, KP-LNN-Σ at positive temperature does that work, and it should carry its own name.

**Keywords** logarithmic number system; Kronecker product; structured pruning; tropical algebra; interval analysis; selection functions; basal ganglia

# 1 Introduction

**Two works, one name.** The log interval network programme carries every positive quantity with a log interval, and asks which decisions survive every tolerated model [2, 4]. Two of the works it builds on use the name KP-LNN:

- **The KP-LNN paper [1]** describes an "addition-free" body that "never invok[es] log-add/log-sum-exp".
- **The basal-ganglia (BG) paper [3]** defines a "KP-LNN layer" that sums by log-sum-exp.

**What the agenda registered.** The agenda [2] read both works for tolerance. It found that the published body cannot add evidence (its Proposition H and check L8). It then registered N1 as a clarification in four parts:

1. Proposition H;
2. two names, KP-LNN-0 and KP-LNN-Σ;
3. pruning under tolerance;
4. a restated expressivity prediction.

**What this note adds.** It states and proves all four parts, with checks, and adds four consequences the agenda did not state:

- gain equivariance;
- nesting of the inputs present;
- a bound on copy maps that holds at every depth;
- discontinuity at route switches.

The last two change how the expressivity prediction should be read. N1 makes no claim about accuracy and registers no experiment.

# 2 The operator

**The KP-LNN-0 layer.** We follow [1, §3]. A KP-LNN-0 layer maps a positive matrix $X^{(t-1)}$ and a positive weight matrix $W^{(t)}$ to $X^{(t)}$ in three steps. In log coordinates, $\hat X=\log X$.

1. **Kronecker composition.** $\hat Z[(i,k),(j,l)]=\hat X[i,j]+\hat W[k,l]$, so $Z=X\otimes W$.
2. **Typed routing.** Learned binary masks for inhibitory and disinhibitory flows are applied to $Z$. The paper leaves the arithmetic open. It says only that "an inhibitory flow reduces the value of the output matrix" and that the sign state is updated "based on the active flow type (addition or subtraction)" [1, §§3.1–3.2]. We model two readings:
   - *Masks.* A masked entry is either set to exponent 0, so that its value is 1 (a *value-1 mask*), or removed, so that its value is 0 and its exponent is $-\infty$.
   - *Sign flips.* A flip acts on a whole matrix and negates every exponent; a removed entry stays removed.

   **Readings not modelled.** Two others are possible: flows acting entrywise, which would be a per-entry flip chosen by a mask, and flows that subtract weight exponents. Proposition 1 holds under all of these. Propositions 2(a)–(b) and 6 assume whole-matrix flips.
3. **Thresholding.** The energy of a row or column is its largest exponent. A row or column is kept if its energy exceeds $\tau_t$ and it is among the $K$ largest. Ties go to the lower index, and survivors keep their index order.

**Remark (the data model).** The paper stores a matrix as $E_X=|\log X|$, with one sign state for the whole matrix recording whether its entries are mostly above or below 1 [1, §3.1]. This is lossless only if every entry lies on the same side of 1; an entry on the other side is stored as its reciprocal. Everything below uses exact signed exponents.

**The KP-LNN-Σ layer.** The BG paper's Appendix A.3 [3] defines

$$
\log Z_{ij}=\mathrm{LSE}_k(\sigma_X\hat X_{ik}+\sigma_A\hat A_{jk}),\qquad \log Y_{ij}=\mathrm{LSE}_k(\sigma_B\hat B_{ik}+\log Z_{kj}),
$$

that is, $Y=BXA^\top$ evaluated with log-adds. We absorb the signs into the hatted matrices and add a temperature $T$:

$$
\log Y_{ij}=T\,\mathrm{LSE}_{k,l}\big((\hat B_{ik}+\hat X_{kl}+\hat A_{jl})/T\big).
$$

This is the BG layer at $T=1$.

**Notation.** $n$ is the number of input entries, and $\hat x\in\mathbb R^n$ collects them. A *route* is the sequence of survivor sets chosen by every layer's thresholding.

# 3 One input per output

**Proposition 1 (KP-LNN-0 copies one input; the agenda's Proposition H).** Take any stack of KP-LNN-0 layers, with either mask reading, any whole-matrix or entrywise flips, and any thresholds and budgets. Every output entry is either
$$
\hat y_o=\sigma_o\,\hat x_{S(o)}+\sum_t s_{o,t}\,\hat W^{(t)}[k_{o,t},l_{o,t}]\qquad\text{or}\qquad\hat y_o=\text{constant},
$$
with $\sigma_o,s_{o,t}\in\{-1,+1\}$ (or 0 for layers before a value-1 mask). An output of the second kind is constant in $\hat x$; it may still depend on later weights. Inside each route's region, the log-Jacobian $\partial\hat y/\partial\hat x$ has at most one non-zero entry per row, equal to $\sigma_o$. Rows of constant outputs are zero. This is why we say "at most one", where the agenda's Proposition H says "one".

*Proof.* By induction on layers, carrying the provenance of every entry: $S$, $\sigma$, and, for each layer, the weight index and its coefficient.

- **Composition.** The Kronecker step gives entry $[(i,k),(j,l)]$ the provenance of $[i,j]$, plus the weight $[k,l]$ with coefficient $+1$.
- **Masks.** A mask replaces the provenance by a constant.
- **Flips.** A flip negates the coefficients of the entries it acts on.
- **Thresholding.** It selects entries without changing them.

Within a route's region, the provenance is fixed. $\square$

**Checks.**

- *C1a and C1a′.* The library `kplnn.py` carries this provenance. These checks rebuild every output from the raw input and weights, using the provenance, on 600 random stacks: 9,057 outputs, 2,190 of them constant, at depths 1–4, with both mask readings, whole-matrix flips and thresholds.
- *C1b.* This check compares the claimed Jacobian with finite differences.

Nothing disagreed.

**Proposition 2 (structure, under whole-matrix flips).**

(a) *One sign per matrix.* In every matrix of a stack, all non-constant entries carry the same $\sigma$.

(b) *Gain equivariance.* Suppose there are no value-1 masks and every $\tau_t=-\infty$. Then the route is invariant to a common gain on the input, and $Y(\lambda X)=\lambda^{\sigma}\circ Y(X)$ entrywise. Every switching boundary lies on a hyperplane $\hat x_a-\hat x_b=c$ with $a\neq b$, so routing depends only on the $n-1$ input log-ratios.

(c) *Nesting.* The set of input indices present after layer $t$ is a subset of the set present after layer $t-1$.

*Proof.*

- (a) Inputs start with $\sigma=+1$, the Kronecker step copies $\sigma$, and a flip negates the whole matrix.
- (b) A common shift $\lambda$ moves every non-constant entry of a matrix by the same $\sigma\lambda$, by (a). Removed entries stay at $-\infty$. Maxima, and every comparison between them, are therefore unchanged. A comparison between $\sigma\hat x_a+c$ and $\sigma\hat x_b+c'$ switches on $\hat x_a-\hat x_b=\sigma(c'-c)$.
- (c) Composition copies entries, and masking and thresholding remove them.

$\square$

**What breaks equivariance.** Value-1 masks and absolute thresholds both break it, because their comparisons switch on $\hat x_a=c$. Under a gain of $e^3$, the route changed in 52 of 300 random masked stacks and in 73 of 300 stacks with $\tau=0.5$ (C2c). Entrywise flips would break (a) and (b) as well: they mix $+\hat x_a$ with $-\hat x_b$, which gives boundaries $\hat x_a+\hat x_b=c$.

Under whole-matrix flips and budget-only pruning, KP-LNN-0 routes on ratios. It has a divisive normalisation by a common gain built in.

**Monotonicity.** KP-LNN-0 is not monotone, even without flips or masks. Raising one input can change which entry fills an output slot. Raising one input by 0.3 lowered some output in 322 of 2,000 random two-layer stacks (C2d).

**Proposition 3 (no accumulation).** A *selection function* is a function on a finite partition of its domain into polyhedral cells with nonempty interior that, on each cell, equals $\pm\hat x_a+c$ or a constant. By Proposition 1, every KP-LNN-0 output is one. Its route regions are bounded by comparisons between entries of the form $\pm\hat x_a+c$ or constants, that is, by hyperplanes $\hat x_a\pm\hat x_b=c$ or $\hat x_a=c$, so they are unions of polyhedral cells.

(a) No selection function equals $\log(x_1+x_2)$ or $\log(x_1x_2)$ on any open set: their gradients have two non-zero entries everywhere.

(b) *The sum.* Take the ray $\hat x_2=\hat x_1-d$, $d\ge0$, with $\hat x_1$ and the other inputs fixed, and suppose the selection function changes piece $K-1$ times along it. Then
$$
\sup_{d\ge0}\big|\log(x_1+x_2)-f\big|\ \ge\ \frac{\log2}{2K}.
$$
A selection function attains this: copy $\hat x_1$, with constants at the midpoints of $K$ equal drops of $\log(1+e^{-d})$. The maximum ($K=1$) errs by $\log2/2$ when centred, and by $\log2$ uncentred.

(c) *The product.* Along the diagonal $\hat x_1=\hat x_2\in[-R,R]$, with $K$ pieces, $\sup|\log(x_1x_2)-f|\ge R/K$. This is attained by $K$ equal pieces.

*Proof.*

- (a) A selection function has at most one non-zero gradient entry on each open cell.
- (b) Let $h(d)=\log(1+e^{-d})$, so the target on the ray is $\hat x_1+h(d)$, with $h'\in(-\tfrac12,0)$. Along the ray, every piece of $f$ has slope $0$ (it copies $\pm\hat x_1$, another input, or a constant) or $\pm1$ (it copies $\pm\hat x_2$). On a slope-0 piece the error changes by exactly the drop of $h$; on a slope-$\pm1$ piece, $|e'|\ge\tfrac12>|h'|$. Either way the error's variation is at least the drop of $h$. Summing over the $K$ pieces, $2K\sup|e|\ge\log2$. Midrange constants attain the bound.
- (c) The target's slope along the diagonal is 2, and $f$'s slope is in $\{-1,0,1\}$, so $|e'|\ge1$ throughout. The total variation over length $2R$ is therefore at least $2R$.

$\square$

**Checks C3a–b.** Both constructions attain their bounds exactly. As a sanity check, random partitions with the best slope and constant on each piece stayed above the bounds: at $K=16$, the best of 300 erred by 0.063, against a bound of 0.022. The proof, not this sampling, carries the claim. Whether a KP-LNN-0 stack can realise the optimal pieces is not shown.

**What this means.** A log-sum to within $\varepsilon$ needs about $\log2/(2\varepsilon)$ switches along each such ray. A product's error grows with the log-range of the inputs at any fixed number of pieces. This is the precise form of the agenda's statement that "neither $x_1x_2$ nor $x_1+x_2$ is representable, and both can at best be approximated piecewise" [2, §2.1], with one correction: the pieces switch the constant as well as which input is copied.

# 4 Two operators under one name

**Proposition 4 (KP-LNN-Σ).**

(a) *At $T=1$.* KP-LNN-Σ computes $Y=BXA^\top$ exactly. Its log-Jacobian row is $\partial\log Y_{ij}/\partial\hat X_{kl}=B_{ik}X_{kl}A_{jl}/Y_{ij}$, a probability vector. It represents $\log(x_1+x_2)$ exactly, so Propositions 1 and 3 do not hold for it.

(b) *At every $T>0$.* It is continuous, monotone nondecreasing in every input, and gain-equivariant. Its Jacobian rows are softmax weights at temperature $T$.

(c) *As $T\to0$.* $\log Y_{ij}\to\max_{k,l}(\hat B_{ik}+\hat X_{kl}+\hat A_{jl})$, the tropical matrix product, uniformly within $T\log m$ for $m$ terms. Almost everywhere, each output then depends on one input.

(d) *What still separates the two.*
- KP-LNN-Σ at $T\to0$ reduces over all inputs by a maximum, and stays continuous and monotone, with fixed output dimensions.
- KP-LNN-0 selects positions by pruning. It is discontinuous (Section 6) and not monotone (C2d), and its dimensions multiply before pruning.

*Proof.*

- (a)–(b) Direct differentiation of the log-sum-exp.
- (c) $\max\le T\,\mathrm{LSE}(\cdot/T)\le\max+T\log m$.
- (d) A maximum of affine functions with non-negative coefficients is continuous and monotone. For KP-LNN-0, see C2d and C6b.

$\square$

**Effective fan-in.** This is the participation ratio of a Jacobian row (C4; $8\times8$ log-normal inputs, $4\times8$ factors). Its median was:

| $T$ | 1 | 0.3 | 0.1 | 0.03 | 0.01 |
|---|---|---|---|---|---|
| fan-in (of 64) | 10.6 | 1.6 | 1.04 | 1.00 | 1.00 |

The agenda's L8 reported 13.4, 1.62 and 1.00 at $T=1$, 0.1 and 0.01. Its draw and generator differ, and its value at $T=0.1$ is higher than ours. Both show the same collapse to fan-in 1.

**The two names.**

- **KP-LNN-0** is the published body of [1]: Kronecker products, masks and max-pruning, with no log-add.
- **KP-LNN-Σ** is the appendix layer of [3]: $Y=BXA^\top$ with log-adds.

**Where each belongs.**

- *The BG decks.* The double-decker BG model accumulates cortical evidence into its Go and Stop decks [3, §3]. That is KP-LNN-Σ at $T=1$, and the programme's P4 [5] used it so.
- *The tropical reading.* The KP-LNN paper's tropical reading [1, §2.3] fits KP-LNN-Σ only in the $T\to0$ limit. It fits KP-LNN-0 only partly, since KP-LNN-0 selects positions rather than taking maxima of sums.

# 5 Pruning under tolerance

**Setting.** Give every input a log-interval of radius $\rho_x$, and every weight a log-interval of radius $\rho_w$.

**Proposition 5 (KP-LNN-0 under log intervals).**

(a) *Exact widths on a fixed route.* For a fixed route without masks, each output after $t$ layers ranges exactly over $\hat y_o\pm(\rho_x+t\rho_w)$. Its variables (one input, and one weight per layer) are distinct, so every endpoint is attained. A value-1 mask resets the radius at that entry to 0. The provenance gives the range directly. Two passes give it too, with the endpoints swapped where $\sigma=-1$.

(b) *Entrywise energies.* A row's energy lies in $[\max_j(\hat z_{ij}-r_{ij}),\max_j(\hat z_{ij}+r_{ij})]$. This interval is sound, but it ignores variables shared between entries.

(c) *Entrywise certification.* Write $[\ell_i,u_i]$ for the energy intervals. Row $i$ is certainly kept if $\ell_i>\tau$ and $\#\{j\neq i:u_j\ge\ell_i\}\le K-1$. It is certainly dropped if $u_i\le\tau$ or $\#\{j\neq i:\ell_j>u_i\}\ge K$. Columns are treated alike. If every line is decided, the survivor set is the same for every model in the box.

(d) *Dependency-aware certification.* Row $i$ *surely outranks* row $j$ if some entry $a$ of row $i$ exceeds every entry $b$ of row $j$ for every model. That holds if $\hat z_a-\hat z_b$ exceeds the exact radius of the difference of two linear forms in independent variables. Shared variables with equal coefficients cancel, and every other variable counts once per entry that uses it. Replace "$u_j\ge\ell_i$" in (c) by "$i$ does not surely outrank $j$", and "$\ell_j>u_i$" by "$j$ surely outranks $i$". This test is sound, and it decides every line the entrywise test decides.

(e) *Margin for the entrywise test.* Without masks, every entry at layer $t$ has radius $\rho_x+t\rho_w$. With budget-only pruning ($\tau=-\infty$) and more than $K$ candidates, the entrywise test can certify layer $t$ only if the $K$-th and $(K+1)$-th largest centre energies differ by more than $2(\rho_x+t\rho_w)$. This required margin grows linearly with depth. The dependency-aware test can need less, because the input and earlier weights cancel between entries that share them.

(f) *Branching.* An undecided layer has more than one possible survivor set. Exactness over the box then requires the union over branches, as in the Interval Transformer's routing result [4, Proposition 8]. With $c$ rows certainly kept and $u$ undecided, budget-only pruning has at most $\binom{u}{K-c}$ row sets, and likewise for columns.

*Proof.*

- (a) Proposition 1: radii of distinct independent variables add in log space.
- (b) The maximum is monotone.
- (c) A rival can outrank $i$ only if $u_j\ge\ell_i$; the dropping rule is symmetric.
- (d) Each surely-outranks claim holds for every model in the box, so the counts bound the true ranks. If $\ell_i>u_j$, let $a$ attain $\ell_i$. Then for every $b$, $\hat z_a-\hat z_b>r_a+r_b$, which is at least the exact radius of the difference. Every entrywise certificate is therefore a dependency-aware one.
- (e) Apply (c) to the two boundary entries.
- (f) Counting.

$\square$

**Checks.** We drew 400 random 3-layer stacks per radius ($3\times3$ inputs, $2\times2$ weights, budget 4, with masks and flips, half thresholded at $\tau=-1$), and 60 sampled models per stack, half of them at corners of the box.

- **C5a, soundness.** No sampled model ever pruned differently from an entrywise-certified layer.
- **C5b, containment.** On fully certified routes, every output lay within its predicted range.
- **C5c, attainment.** For 52 non-constant outputs, the gradient-sign corner attained the radius exactly.
- **C5d, radius.** The radius grew as $\rho_x+t\rho_w$.
- **C5e–f, the dependency-aware test.** On 600 further stacks with 40 sampled models each, the test was sound and never certified less deeply than the entrywise test.

**Table 1.** Share of stacks whose route is certified through layer $d$, with the entrywise test (400 stacks per radius).

| $\rho_x=\rho_w$ | $d\ge1$ | $d\ge2$ | $d=3$ |
|---|---|---|---|
| 0.003 | 90.2% | 76.5% | 58.5% |
| 0.01 | 84.5% | 60.5% | 36.5% |
| 0.03 | 61.5% | 24.5% | 8.0% |
| 0.1 | 21.8% | 0.8% | 0.0% |
| 0.3 | 0.5% | 0.0% | 0.0% |

**Table 2.** The two tests on the same stacks (a separate 200 per radius). Cells give entrywise / dependency-aware.

| $\rho_x=\rho_w$ | $d\ge1$ | $d\ge2$ | $d=3$ |
|---|---|---|---|
| 0.01 | 85.0% / 86.5% | 66.5% / 72.0% | 45.5% / 54.5% |
| 0.03 | 66.5% / 71.0% | 30.5% / 38.0% | 10.0% / 17.5% |
| 0.1 | 23.5% / 29.5% | 1.5% / 3.0% | 0.0% / 0.5% |

**Branching.** At the first undecided layer (1,588 of them), the 60 sampled models showed a median of 2 distinct survivor sets and at most 22. The combinatorial bound of (f) had a median of 4 and a maximum of 4,900. In 354 undecided layers the samples found only one set. Either the entrywise test was conservative there, or the samples missed alternatives.

**What this means for the programme.** KP-LNN-0 is the easy case for widths and the hard case for routes.

- *Widths.* They add exactly along a fixed route, as the agenda says [2, §2.1].
- *Routes.* Certifying them needs margins that grow with depth. In this setting, depth-3 certification of a majority of stacks needed log tolerances of about 1% per factor with the dependency-aware test, and less than that with the entrywise test.
- *Dependency.* Accounting for shared variables raised the share certified through depth 3 from 10% to 18% at $\rho=0.03$, and from 46% to 55% at $\rho=0.01$. P2 [7] drew the same lesson for attention: dependency control pays.

# 6 The expressivity prediction, restated

The KP-LNN paper predicts that "the number of linear regions represented by a KP-LNN will grow multiplicatively with its depth and pruning budgets, consistent with predictions from tropical geometry for (max, +) networks" [1, §5]. Propositions 1–3 change what "linear region" can mean here.

**Proposition 6 (regions and copy maps of KP-LNN-0).** Assume no value-1 masks, $\tau=-\infty$ and whole-matrix flips. For (c), assume in addition no masks of either kind, and that every layer keeps exactly $K$ rows and $K$ columns.

(a) *Regions.* The route regions are unions of cells of an arrangement of $H$ hyperplanes of the form $\hat x_a-\hat x_b=c$. On each cell, every output is affine, $\pm\hat x_a+c$. The arrangement is invariant along $\mathbf 1$, so the number of cells, and hence of routes, is at most $\sum_{i=0}^{n-1}\binom Hi$.

(b) *Discontinuity.* Outputs generally jump at route boundaries.

(c) *Copy maps.* Let the input be $n_r\times n_c$. At every depth, output entry $(r,c)$ copies input $(\rho(r),\gamma(c))$, where $\rho$ and $\gamma$ are nondecreasing sequences of length $K$. Hence the number of distinct copy maps is at most
$$
\binom{K+n_r-1}{n_r-1}\binom{K+n_c-1}{n_c-1},
$$
whatever the depth. For a $3\times3$ input this is 36, 100 and 225 at $K=2,3,4$.

Masks void (c). A removed entry copies nothing, and which output positions are removed depends on the route. With removing masks at rate 0.2, three networks and 8,000 inputs, we counted up to 87 distinct copy maps at $K=2$ and depth 2 (bound 36 without masks), and 558 at $K=4$ (bound 225).

*Proof.*

- (a) Proposition 2(b), and the standard bound for arrangements in $\mathbb R^{n-1}$.
- (b) Copying $\hat x_a+c$ on one side and $\hat x_b+c'$ on the other agree only on the hyperplane $\hat x_a-\hat x_b=c'-c$, which is generally not the switching boundary.
- (c) Kronecker row $(i,k)$ descends from input-matrix row $i$, so by induction every row of every layer descends from one input row, and likewise for columns. Rows are indexed $X$-major and survivors keep index order, so the descent map is nondecreasing. A nondecreasing sequence of length $K$ over $n_r$ values is a multiset, of which there are $\binom{K+n_r-1}{n_r-1}$.

$\square$

**Why depth 1 is small.** A first-layer row's energy is the row maximum of $X$ plus the row maximum of $W$. With $3\times3$ inputs and $2\times2$ weights, the kept rows form an order ideal of size $K$ in the 3×2 grid of (rank in $X$, rank in $W$), placed on the actual rows by the ordering of $X$'s row maxima.

| $K$ | Possible row sets | Routes at depth 1, at most |
|---|---|---|
| 2 | 6 | 36 |
| 3 | 7 | 49 |
| 4 | 6 | 36 |

The 36 at $K=2$ and $K=4$ is a coincidence of these counts.

**Measurement** (C6). $3\times3$ log-normal inputs, $2\times2$ weights, budget $K$; three random networks, 40,000 sampled inputs. Counts are means over the networks and are lower bounds.

| $K$ | Depth | Routes | Copy maps | Cap on routes (combinatorial) | Bound on copy maps |
|---|---|---|---|---|---|
| 2 | 1 | 36 | 36 | 225 | 36 |
| 2 | 2 | 105 | 36 | 8,100 | 36 |
| 2 | 3 | 131 | 36 | 291,600 | 36 |
| 3 | 1 | 49 | 49 | 400 | 100 |
| 3 | 2 | 260 | 99 | 160,000 | 100 |
| 3 | 3 | 397 | 98 | 6.4×10⁷ | 100 |
| 4 | 1 | 35 | 35 | 225 | 225 |
| 4 | 2 | 488 | 181 | 1.1×10⁶ | 225 |
| 4 | 3 | 990 | 205 | 5.4×10⁹ | 225 |

**Deeper stacks** (C6c; 8,000 inputs, three networks, depths 1–5). The copy-map counts ranged up to 36, 100 and 223 at $K=2,3,4$, against bounds of 36, 100 and 225. Every output had the predicted row-and-column structure, and no count exceeded its bound.

**Jumps** (C6b; depth 2, $K=4$). Along 200 random segments, 1,164 route switches changed the output by a median of 1.8 log units. A continuous map would move by about $10^{-3}$ at that step.

**The restated prediction (N1.4).** Consider budget-only KP-LNN-0 on $n$ log-inputs arranged $n_r\times n_c$.

1. **Routes.** The number of routes is at most $\sum_{i<n}\binom Hi$, where $H$ is the number of distinct thresholds $\hat x_a-\hat x_b=c$. $H$ can grow multiplicatively with depth, through products of weight entries, and with budgets. The measured route counts did grow, by a factor of 1.2–14 per added layer here. Each depth used fresh random networks, so this compares independent networks, not one network grown a layer at a time.
2. **Copy maps.** Without masks, they are drawn from a fixed set of at most $\binom{K+n_r-1}{n_r-1}\binom{K+n_c-1}{n_c-1}$ maps at any depth. Depth can reach more of that set (at $K=4$, at most 36 at depth 1 and up to 223 deeper), but never leave it.
3. **Comparison with other networks.** Region counts are not comparable to those of continuous (max, +) or ReLU networks [6], because KP-LNN-0's pieces are generically separated by jumps. We observed this (C6b) but did not prove it in general. On any target that needs accumulation, error is bounded below by Proposition 3, whatever the region count.

Point 2 and the bound in point 3 are theorems. The empirical content of point 1 is how $H$ and the route counts grow in *trained* networks, which we have not measured.

# 7 What this means for the programme

- **Two jobs, two operators.**
  - *KP-LNN-0* is a positive router. With whole-matrix flips it is sign-uniform, and with budget-only pruning and no value-1 masks it routes on ratios. It is exact under log intervals along a fixed route, but its routes need margins that grow with depth, and it cannot add evidence.
  - *KP-LNN-Σ* at $T>0$ adds evidence and is monotone, so its intervals are exact by two passes [2]. Its temperature trades accumulation against the certifiable margins of selection. This is the central open question of the agenda [2, Summary and §3.1].
- **The BG decks are KP-LNN-Σ.** The interval results of P4 [5] apply to them, and not to KP-LNN-0.
- **Certified pruning is a margin condition.** A KP-LNN-0 meant to be certified should prune with budgets that leave gaps, account for shared variables (Proposition 5(d)), or branch where it cannot (5(f)).

# 8 Limitations

- **The operator.** We formalised it from the paper's description [1], which leaves the arithmetic of masks and flows open. Propositions 2(a)–(b) and 6 assume whole-matrix flips; entrywise flips would break them, though not Proposition 1.
- **No training.** All checks use random, untrained networks. Route and copy-map counts are sampled lower bounds on small networks.
- **Soundness, not exactness.** Both certification tests are sound but not exact. The dependency-aware test reasons about pairs of entries, not about the joint maximum. In 354 undecided layers, sampling found only one survivor set.
- **Loose bounds.** The arrangement bound in Proposition 6(a) is general and is not tight for the structured offsets KP-LNN-0 produces. Proposition 3's bounds are attained by selection functions, but whether a KP-LNN-0 stack can realise those functions is not shown.

# References

[1] Ghosh, D. P., Ghosh, D., and Ghosh, D. (2025). *Kronecker Product Logarithmic Neural Networks (KP-LNN): An Addition-Free, Signless Architecture for Matrix-Native Computation*. https://doi.org/10.13140/RG.2.2.28337.85604

[2] Ghosh, Debi Prasad. (2026). *Log-Interval Networks: The Next Research Programme for the Interval Transformer*. Research agenda, 1 October 2026.

[3] Ghosh, D. P., Ghosh, D., and Ghosh, D. (2025). *Kronecker-Factored Positive Logarithmic Network Model of the Basal Ganglia with Addition-Free RL*. https://doi.org/10.13140/RG.2.2.17714.47041

[4] Ghosh, Debi Prasad. (2026). *Interval Transformers with Exact Local Weight Ranges and Sparse Expert Routing*. Manuscript, 1 October 2026.

[5] Ghosh, Debi Prasad. (2026). *A Brake That Acts When Action Ranges Overlap: Interval Salience, the Hyperdirect Pathway and Reward Rate*. P4 of the log interval network programme, 11 October 2026.

[6] Zhang, L., Naitzat, G., and Lim, L.-H. (2018). Tropical geometry of deep neural networks. *Proceedings of ICML 2018*, PMLR 80, 5824–5832. arXiv:1805.07091.

[7] Ghosh, Debi Prasad. (2026). *Positive Kronecker Attention with Dependency Control*. P2 of the log interval network programme, 5 October 2026.

# Appendix A. Checks and reproduction

`kplnn.py` implements KP-LNN-0, with full provenance (input, weight indices, coefficients, radii) and both certification tests, and KP-LNN-Σ. `verify_n1.py` runs 23 pass/fail checks, all of which pass, and prints the measurements quoted above (`verify_n1_output.txt`).

**Environment.** Python 3.11.15, NumPy 2.4.4, SciPy 1.17.1; the script takes about 9 minutes.

| Checks | Verify | Measurements printed |
|---|---|---|
| C1a, C1a′, C1b, C1c | Proposition 1 (provenance, rebuilt outputs, Jacobians) and 2(c) (nesting) | |
| C2a–d | Proposition 2(a)–(b); masks and thresholds break equivariance; non-monotonicity | |
| C3a–b | Proposition 3: bounds and attainment | random partitions |
| C4a–e | Proposition 4: exactness at $T=1$, Jacobian rows, tropical limit, the sum, gain equivariance | fan-in against $T$ |
| C5a–f | Proposition 5: soundness of both tests, containment, attainment, radius growth, dominance of the dependency-aware test | certification rates, branching |
| C6b, C6c | Section 6: jumps at route switches; copy-map structure and bound at depths 1–5 | route and copy-map counts (C6) |

```
python3 verify_n1.py > verify_n1_output.txt
python3 verify_n1_masks.py > verify_n1_masks_output.txt   # Proposition 6(c) with removing masks (post-review)
```
