from pathlib import Path
import subprocess,sys
P=Path(__file__).resolve().parent
subprocess.run([sys.executable,'assemble_v2.py'],cwd=P,check=True)
subprocess.run([sys.executable,'revise_paper.py'],cwd=P,check=True)
