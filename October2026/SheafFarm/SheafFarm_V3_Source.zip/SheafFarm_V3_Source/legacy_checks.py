"""Checks for 'SheafFarm: Some Sheaf-Diffusion Algorithms are More Sheaf Than Others', Version 2.

Part A rebuilds the seventeen Version 1 checks from the statements in the paper.
Part B checks the Version 2 results and runs the SheafFarm certificate audit.
Every check is an identity, a bound or an exact computation on a declared example.
"""
from pathlib import Path
import itertools, json, math, sys
import numpy as np
from scipy.linalg import expm, null_space
from scipy.optimize import linprog

P = Path(__file__).resolve().parent
SEED = 20261020
rng = np.random.default_rng(SEED)
R = {'seed': SEED, 'python': sys.version.split()[0], 'numpy': np.__version__}
tests = []


def check(name, ok, part):
    tests.append({'name': name, 'passed': bool(ok), 'part': part})


def rot(a):
    return np.array([[math.cos(a), -math.sin(a)], [math.sin(a), math.cos(a)]])


def rand_orth(d, rng):
    q, r = np.linalg.qr(rng.normal(size=(d, d)))
    return q * np.sign(np.diag(r))


def coboundary(nv, d, edges):
    """edges: list of (v, w, Rv, Rw); residual Rw x_w - Rv x_v. Returns B (edge blocks stacked) and block slices."""
    rows = []; sl = []; start = 0
    for (v, w, Rv, Rw) in edges:
        de = Rv.shape[0]; blk = np.zeros((de, nv * d))
        blk[:, v * d:(v + 1) * d] = -Rv; blk[:, w * d:(w + 1) * d] = Rw
        rows.append(blk); sl.append(slice(start, start + de)); start += de
    return np.vstack(rows), sl


def transport_edges(nv, d, pairs, Ts):
    return [(v, w, T, np.eye(d)) for (v, w), T in zip(pairs, Ts)]


def proj_kernel(L, tol=1e-9):
    w, V = np.linalg.eigh(L); K = V[:, w < tol]
    return K @ K.T


# =============================================================== Part A: Version 1 checks
A = {}
# Example 3.2: equal Laplacians, different H^1
B1 = np.array([[-1., 1.]]); B2 = np.array([[-1., 1.], [0., 0.]])
h1 = [B.shape[0] - np.linalg.matrix_rank(B) for B in (B1, B2)]
A['same_gram_H1'] = h1
check('Example 3.2: equal Laplacians, first cohomology 0 and 1', np.allclose(B1.T @ B1, B2.T @ B2) and h1 == [0, 1], 'V1')
# Example 3.3: parallel edges, same Gram, holonomies 3/2 and 11/6
Ba = np.array([[-1., 1.], [-2., 3.]]); Bb = np.array([[-11 / 5, 3.], [-2 / 5, 1.]])
hol = lambda B: (-B[0, 0] / B[0, 1]) / (-B[1, 0] / B[1, 1])
A['parallel_holonomy'] = [hol(Ba), hol(Bb)]
check('Example 3.3: same Gram, loop multipliers 3/2 and 11/6',
      np.allclose(Ba.T @ Ba, [[5, -7], [-7, 10]]) and np.allclose(Bb.T @ Bb, Ba.T @ Ba)
      and abs(hol(Ba) - 1.5) < 1e-12 and abs(hol(Bb) - 11 / 6) < 1e-12, 'V1')
# Theorem 4.1: flatten a random orthogonal local system on a tree
nv, d = 7, 3
tree = [(0, 1), (0, 2), (1, 3), (1, 4), (2, 5), (5, 6)]
Ts = [rand_orth(d, rng) for _ in tree]
Pv = {0: np.eye(d)}
for (v, w), T in zip(tree, Ts):
    Pv[w] = T @ Pv[v]
gauge_res = max(float(np.abs(Pv[w].T @ T @ Pv[v] - np.eye(d)).max()) for (v, w), T in zip(tree, Ts))
A['tree_gauge_residual'] = gauge_res
check('Theorem 4.1: tree gauge flattening residual below 1e-12', gauge_res < 1e-12, 'V1')
# sign cycles: spectra (0,3,3) and (1,1,4)
def sign_cycle(signs):
    return np.array([[-signs[0], 1, 0], [0, -signs[1], 1], [1, 0, -signs[2]]], float)
bal, fru = sign_cycle([1, 1, 1]), sign_cycle([1, 1, -1])
A['sign_spectra'] = [np.round(np.linalg.eigvalsh(b.T @ b), 12).tolist() for b in (bal, fru)]
check('sign cycles: spectra (0,3,3) and (1,1,4)', np.allclose(A['sign_spectra'][0], [0, 3, 3]) and np.allclose(A['sign_spectra'][1], [1, 1, 4]), 'V1')
# Proposition 4.2: ReLU counterexample
x = np.array([-1., 2.]); G = rot(math.pi / 2)
relu = lambda z: np.maximum(z, 0)
A['relu_counterexample'] = [relu(G @ x).tolist(), (G @ relu(x)).tolist()]
check('Proposition 4.2: ReLU(Gx) = 0 but G ReLU(x) = (-2, 0)', np.allclose(relu(G @ x), 0) and np.allclose(G @ relu(x), [-2, 0]), 'V1')
# Example 5.2: section preserving map without local naturality; Theorem 5.1 factorisation
signs = [1, 1, -1]; cyc = [(0, 1), (1, 2), (2, 0)]
edges52 = [(v, w, np.diag([1., s]), np.eye(2)) for (v, w), s in zip(cyc, signs)]
D52, _ = coboundary(3, 2, edges52)
avals = [1., 2., 3.]
T52 = np.zeros((6, 6))
for v in range(3):
    T52[2 * v:2 * v + 2, 2 * v:2 * v + 2] = np.diag([1., avals[v]])
S52 = D52 @ T52 @ np.linalg.pinv(D52)
fact_res = float(np.abs(D52 @ T52 - S52 @ D52).max())
local_defect = 0.0
for (v, w, Rv, Rw) in edges52:
    # minimise ||Rv Tv - S Rv||^2 + ||Rw Tw - S Rw||^2 over S (least squares, closed form)
    Tv, Tw = np.diag([1., avals[v]]), np.diag([1., avals[w]])
    M = np.hstack([Rv, Rw]); Y = np.hstack([Rv @ Tv, Rw @ Tw])
    Sopt = Y @ np.linalg.pinv(M)
    local_defect += float(np.sum((Y - Sopt @ M) ** 2))
A['factorisation_residual'] = fact_res; A['local_square_defect'] = local_defect
A['ex52_kernel_dim'] = int(null_space(D52).shape[1])
check('Theorem 5.1: global factorisation residual below 1e-12', fact_res < 1e-12, 'V1')
check('Example 5.2: best local square defect equals 3 on a nonzero section space', abs(local_defect - 3) < 1e-12 and A['ex52_kernel_dim'] == 1, 'V1')
# Proposition 5.3: heat intertwiner
Bh = rng.normal(size=(5, 4))
inter = float(np.abs(Bh @ expm(-0.7 * Bh.T @ Bh) - expm(-0.7 * Bh @ Bh.T) @ Bh).max())
A['heat_intertwiner'] = inter
check('Proposition 5.3: B exp(-tB^T B) = exp(-tBB^T) B', inter < 1e-12, 'V1')
# Theorem 6.1: path L0 versus 4 L0
Bp = np.array([[-1., 1, 0], [0, -1., 1]]); L0 = Bp.T @ Bp
A['path_heat_difference_t1'] = float(np.linalg.norm(expm(-L0) - expm(-4 * L0), 2))
check('Theorem 6.1: same projector, finite heat differs (0.349564 at t = 1)',
      np.allclose(proj_kernel(L0), proj_kernel(4 * L0)) and abs(A['path_heat_difference_t1'] - 0.349564) < 1e-6, 'V1')
lp = float(np.linalg.eigvalsh(L0)[1])
gap_t = float(abs(np.linalg.norm(expm(-2 * L0) - proj_kernel(L0), 2) - math.exp(-2 * lp)))
gap_b = float(abs(np.linalg.norm(np.linalg.inv(np.eye(3) + 5 * L0) - proj_kernel(L0), 2) - 1 / (1 + 5 * lp)))
check('Theorem 6.1: heat and resolvent distances to the projector match (10) and (11)', max(gap_t, gap_b) < 1e-12, 'V1')
# Proposition 6.2: Gaussian reconstruction of L
Bq = rng.normal(size=(6, 4)); Lq = Bq.T @ Bq; p_, b_, a_, s_ = 1.0, 2.0, 0.6, 0.8
S = a_ ** 2 * np.linalg.inv(p_ * np.eye(4) + b_ * Lq) + s_ ** 2 * np.eye(4)
Lrec = (np.linalg.inv((S - s_ ** 2 * np.eye(4)) / a_ ** 2) - p_ * np.eye(4)) / b_
A['gaussian_reconstruction'] = float(np.abs(Lrec - Lq).max())
check('Proposition 6.2: Gaussian covariance reconstructs L', A['gaussian_reconstruction'] < 1e-10, 'V1')


# Theorem 6.3: rotation cycle
def rot_cycle(n, eps, d=2):
    pairs = [(i, (i + 1) % n) for i in range(n)]
    Ts = [np.eye(2)] * (n - 1) + [rot(eps)]
    B, _ = coboundary(n, 2, transport_edges(n, 2, pairs, Ts))
    return B.T @ B


lm = float(np.linalg.eigvalsh(rot_cycle(3, 0.003))[0])
A['rotation_lambda_min'] = lm; A['rotation_formula_error'] = abs(lm - 4 * math.sin(0.003 / 6) ** 2)
check('Theorem 6.3: smallest eigenvalue 4 sin^2(eps/6) at eps = 0.003', A['rotation_formula_error'] < 1e-14, 'V1')
# Proposition 6.4: perturbation bounds
Bx = rng.normal(size=(6, 4)); Bhx = Bx + 0.05 * rng.normal(size=(6, 4))
Lx, Lhx = Bx.T @ Bx, Bhx.T @ Bhx; dl = np.linalg.norm(Lhx - Lx, 2)
b15 = dl <= (np.linalg.norm(Bhx, 2) + np.linalg.norm(Bx, 2)) * np.linalg.norm(Bhx - Bx, 2)
b16 = np.linalg.norm(expm(-0.8 * Lhx) - expm(-0.8 * Lx), 2) <= 0.8 * dl
b17 = np.linalg.norm(np.linalg.inv(np.eye(4) + 3 * Lhx) - np.linalg.inv(np.eye(4) + 3 * Lx), 2) <= 3 * dl
check('Proposition 6.4: bounds (15), (16) and (17) hold on a fixed perturbation', b15 and b16 and b17, 'V1')
# Theorem 7.1: normalised heat covariance on the frustrated sign cycle
Lf = fru.T @ fru; H = expm(-0.5 * Lf); Dm = np.diag(np.diag(H) ** -0.5); K = Dm @ H @ Dm
A['frustrated_residual'] = float(np.trace(fru @ K @ fru.T)); A['frustrated_diag_error'] = float(np.abs(np.diag(K) - 1).max())
check('Theorem 7.1: unit marginals but expected residual 3.903308 (tau = 0.5)',
      abs(A['frustrated_residual'] - 3.903308) < 1e-6 and A['frustrated_diag_error'] < 1e-15, 'V1')
# Section 7.2: resolvent posterior mean equals the Gaussian posterior mean
Lr = Lq; mu = rng.normal(size=4); xr = rng.normal(size=4); a2, s2 = 0.6, 0.8; p2, b2 = 1.0, 2.0
C = np.linalg.inv(p2 * np.eye(4) + b2 * Lr)
post = mu + a2 * C @ np.linalg.solve(a2 ** 2 * C + s2 ** 2 * np.eye(4), xr - a2 * mu)
h = b2 * s2 ** 2 / (a2 ** 2 + p2 * s2 ** 2)
res = mu + a2 / (a2 ** 2 + p2 * s2 ** 2) * np.linalg.solve(np.eye(4) + h * Lr, xr - a2 * mu)
A['resolvent_posterior'] = float(np.abs(post - res).max())
check('Equation (20): resolvent form equals the Gaussian posterior mean', A['resolvent_posterior'] < 1e-12, 'V1')
# Section 7.3: context cycle has no global law
assign = list(itertools.product([0, 1], repeat=3)); Aeq = []; beq = []
for (i, j, equal) in ((0, 1, True), (1, 2, True), (2, 0, False)):
    for u in (0, 1):
        for v in (0, 1):
            Aeq.append([1.0 if (a[i] == u and a[j] == v) else 0.0 for a in assign])
            beq.append(0.5 if ((u == v) == equal) else 0.0)
lp_res = linprog(np.zeros(8), A_eq=np.array(Aeq), b_eq=np.array(beq), bounds=[(0, None)] * 8)
A['context_cycle_feasible'] = bool(lp_res.status == 0)
check('Section 7.3: the context-cycle marginals admit no global law', lp_res.status == 2, 'V1')
# Theorem 7.1 converse: flat system, Xi_v = P_v Z has unit marginals, compatibility and joint rank d
Pflat = [rand_orth(2, rng) for _ in range(4)]
Tfl = [Pflat[w] @ Pflat[v].T for (v, w) in itertools.combinations(range(4), 2)]
Bfl, _ = coboundary(4, 2, transport_edges(4, 2, list(itertools.combinations(range(4), 2)), Tfl))
Pstack = np.vstack(Pflat); Cfl = Pstack @ Pstack.T
A['flat_construction'] = {'residual': float(np.abs(Bfl @ Cfl @ Bfl.T).max()),
                          'diag': float(max(np.abs(Cfl[2*v:2*v+2, 2*v:2*v+2] - np.eye(2)).max() for v in range(4))),
                          'rank': int(np.linalg.matrix_rank(Cfl))}
check('Theorem 7.1: on a flat system Xi_v = P_v Z is compatible with unit marginals and rank d',
      A['flat_construction']['residual'] < 1e-12 and A['flat_construction']['diag'] < 1e-12 and A['flat_construction']['rank'] == 2, 'V1')
R['v1'] = A

# =============================================================== Part B: Version 2
Bres = {}
# Theorem 3.4: Gram fibre (isometry characterisation)
Bg = rng.normal(size=(7, 4)); U = rand_orth(7, rng); Bg2 = U @ Bg
fwd = float(np.abs(Bg.T @ Bg - Bg2.T @ Bg2).max())
# converse on the Example 3.3 pair: U = Bb Ba^+ is an isometry on im Ba and Bb = U Ba
Uab = Bb @ np.linalg.pinv(Ba)
conv = float(max(np.abs(Uab @ Ba - Bb).max(), np.abs(Uab.T @ Uab - np.eye(2)).max()))
Bres['gram_fibre'] = {'forward': fwd, 'converse': conv, 'mixing_matrix': Uab.tolist()}
check('Theorem 3.4: B2 = U B1 with U isometric gives equal Grams', fwd < 1e-12, 'V2')
check('Theorem 3.4: equal Grams give an isometry U with B2 = U B1 (Example 3.3 pair)', conv < 1e-12, 'V2')
check('Theorem 3.4: the Example 3.3 isometry mixes the two edge blocks',
      abs(Uab[0, 1]) > 1e-3 and abs(Uab[1, 0]) > 1e-3, 'V2')

# Proposition 3.6: a continuum of scalar sheaves on K4 with the same Laplacian
V4 = 4; E4 = list(itertools.combinations(range(V4), 2))


def lap_scalar(r, V=V4, E=E4):
    L = np.zeros((V, V))
    for k, (i, j) in enumerate(E):
        b = np.zeros(V); b[i] = -r[2 * k]; b[j] = r[2 * k + 1]; L += np.outer(b, b)
    return L


def feats(r, V=V4, E=E4):
    return lap_scalar(r, V, E)[np.triu_indices(V)]


def jac(r, V=V4, E=E4, h=1e-7):
    return np.array([(feats(r + h * e, V, E) - feats(r - h * e, V, E)) / (2 * h) for e in np.eye(len(r))]).T


def holo(r, cyc, E=E4):
    out = 1.0
    for a, b in zip(cyc, cyc[1:] + cyc[:1]):
        if (a, b) in E:
            k = E.index((a, b)); out *= r[2 * k] / r[2 * k + 1]
        else:
            k = E.index((b, a)); out *= r[2 * k + 1] / r[2 * k]
    return out


r0 = np.array([1.2, 0.8, 0.9, 1.5, 1.1, 0.7, 1.3, 1.0, 0.6, 1.4, 1.6, 0.9])
target = feats(r0); r = r0.copy(); path = [{'s': 0.0, 'h012': holo(r, [0, 1, 2]), 'h013': holo(r, [0, 1, 3]),
                                            'h023': holo(r, [0, 2, 3]), 'res': 0.0}]
srun = 0.0
for step in range(60):
    J = jac(r); rk = np.linalg.matrix_rank(J, 1e-8); _, _, Vt = np.linalg.svd(J); N = Vt[rk:]
    g = np.array([(holo(r + 1e-7 * e, [0, 1, 2]) - holo(r - 1e-7 * e, [0, 1, 2])) / 2e-7 for e in np.eye(12)])
    dvec = N.T @ (N @ g); dvec /= np.linalg.norm(dvec)
    r = r + 0.01 * dvec; srun += 0.01
    for _ in range(30):
        r = r - np.linalg.pinv(jac(r)) @ (feats(r) - target)
    path.append({'s': srun, 'h012': holo(r, [0, 1, 2]), 'h013': holo(r, [0, 1, 3]), 'h023': holo(r, [0, 2, 3]),
                 'res': float(np.abs(feats(r) - target).max())})
rK4 = r.copy()
rank_k4 = int(np.linalg.matrix_rank(jac(r0), 1e-8))
# a single cycle: the fibre is discrete (full-rank Jacobian)
V5 = 5; E5 = [(i, (i + 1) % V5) if i < V5 - 1 else (0, V5 - 1) for i in range(V5)]
r5 = rng.uniform(.5, 2, 2 * V5)
rank_c5 = int(np.linalg.matrix_rank(jac(r5, V5, E5), 1e-8))
Bres['k4_fibre'] = {'path': path, 'jacobian_rank': rank_k4, 'unknowns': 12, 'fibre_dim': 12 - rank_k4,
                    'max_residual': max(q['res'] for q in path), 'r_start': r0.tolist(), 'r_end': rK4.tolist(),
                    'cycle5_rank': rank_c5, 'cycle5_unknowns': 2 * V5}
check('Proposition 3.6: K4 Gram fibre has dimension |E| - |V| = 2', 12 - rank_k4 == 2, 'V2')
check('Proposition 3.6: Laplacian held fixed to 1e-12 along the K4 path', Bres['k4_fibre']['max_residual'] < 1e-12, 'V2')
check('Proposition 3.6: triangle holonomies change along the fibre',
      abs(path[-1]['h012'] - path[0]['h012']) > 0.1 and abs(path[-1]['h013'] - path[0]['h013']) > 0.01, 'V2')
check('Proposition 3.6: on a single 5-cycle the Jacobian has full rank (discrete fibre)', rank_c5 == 2 * V5, 'V2')


# Corollary 3.5: edge-resolved Grams recover transports and distinguish the pair
def edge_grams(r, V=V4, E=E4):
    out = []
    for k, (i, j) in enumerate(E):
        b = np.zeros(V); b[i] = -r[2 * k]; b[j] = r[2 * k + 1]; out.append(np.outer(b, b))
    return out


def transports_from_grams(Gs, E=E4):
    tr = []
    for Gk, (i, j) in zip(Gs, E):
        tr.append(-Gk[i, j] / Gk[j, j])                 # (r_i r_j)/(r_j^2) = r_i / r_j
    return tr


tr0 = transports_from_grams(edge_grams(r0)); true0 = [r0[2 * k] / r0[2 * k + 1] for k in range(6)]
edge_diff = max(float(np.abs(a - b).max()) for a, b in zip(edge_grams(r0), edge_grams(rK4)))
Bres['edge_resolved'] = {'transport_recovery_error': float(np.abs(np.array(tr0) - true0).max()),
                         'edge_gram_difference_on_pair': edge_diff,
                         'laplacian_difference_on_pair': float(np.abs(lap_scalar(r0) - lap_scalar(rK4)).max())}
check('Corollary 3.5: edge-resolved Grams recover every transport', Bres['edge_resolved']['transport_recovery_error'] < 1e-12, 'V2')
check('Corollary 3.5: edge-resolved Grams separate the K4 pair that the Laplacian cannot', edge_diff > 0.05, 'V2')

# Proposition 4.3: radial vertex nonlinearities are frame covariant
nv2, d2 = 4, 2
pairs4 = E4
T4 = [rand_orth(2, rng) for _ in pairs4]
B4, sl4 = coboundary(nv2, d2, transport_edges(nv2, d2, pairs4, T4))
L4 = B4.T @ B4
Gs = [rand_orth(2, rng) for _ in range(nv2)]
Gbig = np.zeros((8, 8))
for v in range(nv2):
    Gbig[2 * v:2 * v + 2, 2 * v:2 * v + 2] = Gs[v]
T4g = [Gs[w] @ T @ Gs[v].T for (v, w), T in zip(pairs4, T4)]
B4g, _ = coboundary(nv2, d2, transport_edges(nv2, d2, pairs4, T4g))
L4g = B4g.T @ B4g


def radial(z, d=2):
    out = z.copy()
    for v in range(len(z) // d):
        y = z[d * v:d * v + d]; nrm = np.linalg.norm(y)
        out[d * v:d * v + d] = y * (math.tanh(nrm) / nrm if nrm > 0 else 1.0)
    return out


xin = rng.normal(size=8); alpha = 0.1
layer = lambda L, z, nl: nl(z - alpha * L @ z)
relu_def = float(np.abs(layer(L4g, Gbig @ xin, relu) - Gbig @ layer(L4, xin, relu)).max())
rad_def = float(np.abs(layer(L4g, Gbig @ xin, radial) - Gbig @ layer(L4, xin, radial)).max())
Bres['frame'] = {'relu_defect': relu_def, 'radial_defect': rad_def,
                 'laplacian_conjugation': float(np.abs(L4g - Gbig @ L4 @ Gbig.T).max())}
check('Proposition 4.3: a radial nonlinearity gives a frame-covariant layer', rad_def < 1e-12, 'V2')
check('Proposition 4.3: the same layer with ReLU is not frame covariant', relu_def > 1e-3, 'V2')


# Proposition 6.5: spectrum of an orthogonal connection on an n-cycle
def cycle_conn(n, H):
    d = H.shape[0]; pairs = [(i, (i + 1) % n) for i in range(n)]
    Ts = [np.eye(d)] * (n - 1) + [H]
    B, _ = coboundary(n, d, transport_edges(n, d, pairs, Ts))
    return B.T @ B


spec_err = 0.0
for n in (3, 5, 8):
    Q = rand_orth(4, rng)
    ang = np.angle(np.linalg.eigvals(Q))
    pred = np.sort([2 - 2 * math.cos((th + 2 * math.pi * k) / n) for th in ang for k in range(n)])
    spec_err = max(spec_err, float(np.abs(np.sort(np.linalg.eigvalsh(cycle_conn(n, Q))) - pred).max()))
lam_rows = []
for n in (3, 6, 12, 24):
    for eps in (0.01, 0.03, 0.1, 0.3, 1.0):
        lm_ = float(np.linalg.eigvalsh(cycle_conn(n, rot(eps)))[0])
        lam_rows.append({'n': n, 'eps': eps, 'lambda_min': lm_, 'formula': 4 * math.sin(eps / (2 * n)) ** 2})
Bres['cycle_spectrum'] = {'max_error': spec_err, 'rows': lam_rows,
                          'max_formula_error': max(abs(q['lambda_min'] - q['formula']) for q in lam_rows)}
check('Proposition 6.5: n-cycle spectrum equals 2 - 2cos((theta_j + 2 pi k)/n) for random holonomy', spec_err < 1e-10, 'V2')
check('Proposition 6.5: smallest eigenvalue 4 sin^2(eps/2n) for all tested n and eps', Bres['cycle_spectrum']['max_formula_error'] < 1e-12, 'V2')


# Corollary 6.6: layers needed to see holonomy
def depth_half(eps, n, alpha):
    lam = 4 * math.sin(eps / (2 * n)) ** 2
    return math.ceil(math.log(2) / -math.log(1 - alpha * lam))


depth_rows = []; depth_ok = True
for n in (3, 6, 12):
    for eps in (0.1, 0.3, 1.0):
        Kh = depth_half(eps, n, 0.25)
        Lc = cycle_conn(n, rot(eps)); M = np.eye(2 * n) - 0.25 * Lc
        top = float(np.linalg.eigvalsh(np.linalg.matrix_power(M, Kh))[-1])
        topm = float(np.linalg.eigvalsh(np.linalg.matrix_power(M, Kh - 1))[-1])
        depth_ok &= top <= 0.5 + 1e-12 and topm > 0.5
        depth_rows.append({'n': n, 'eps': eps, 'layers': Kh, 'retained': top})
Bres['depth'] = {'alpha': 0.25, 'rows': depth_rows}
check('Corollary 6.6: the slowest mode first falls to one half exactly at the predicted depth', depth_ok, 'V2')

# Proposition 6.7: a thresholded kernel is continuous (Davis-Kahan)
L30 = rot_cycle(3, 0.0); P30 = proj_kernel(L30); lam_plus = float(np.sort(np.linalg.eigvalsh(L30))[2])
thr_rows = []; dk_ok = True
for eps in (1e-4, 1e-3, 1e-2, 0.05, 0.1, 0.3, 0.6, 1.0):
    Le = rot_cycle(3, eps); E_ = float(np.linalg.norm(Le - L30, 2))
    w, Vv = np.linalg.eigh(Le); Pt = Vv[:, w < lam_plus / 2] @ Vv[:, w < lam_plus / 2].T
    exact = float(np.linalg.norm(proj_kernel(Le, 1e-12) - P30, 2))
    thr = float(np.linalg.norm(Pt - P30, 2))
    bound = E_ / (lam_plus - E_) if E_ < lam_plus / 2 else float('nan')
    if E_ < lam_plus / 2:
        dk_ok &= thr <= bound + 1e-12 and np.linalg.matrix_rank(Pt) == 2
    thr_rows.append({'eps': eps, 'perturbation': E_, 'exact_kernel_distance': exact, 'threshold_distance': thr,
                     'bound': bound})
Bres['threshold'] = {'lambda_plus': lam_plus, 'rows': thr_rows}
check('Proposition 6.7: the exact-kernel projector jumps by one for every eps > 0',
      all(abs(q['exact_kernel_distance'] - 1) < 1e-9 for q in thr_rows), 'V2')
check('Proposition 6.7: the thresholded projector obeys the Davis-Kahan bound and keeps rank 2', dk_ok, 'V2')

# Proposition 7.2: under the probability-flow limit, the constant force -beta L x scales mode mu by a_T^(beta mu)
def mode_std(c_target, bm, aT, steps=20000):
    # scalar mode, uncoupled target variance 1/c_target; start from its exact terminal law; deterministic DDIM
    sT = math.sqrt(1 - aT * aT)
    sig_end = math.log(sT / aT); grid = np.exp(np.linspace(sig_end, math.log(1e-6), steps))   # sigma = s/a, log spaced
    grid = np.append(grid, 0.0)
    var = aT * aT / c_target + sT * sT
    for k in range(steps):
        sg, sgn = grid[k], grid[k + 1]
        a = 1 / math.sqrt(1 + sg * sg); s = sg * a; an = 1 / math.sqrt(1 + sgn * sgn); sn = sgn * an
        A_ = -1 / (a * a / c_target + s * s) - bm
        Mden = (1 + s * s * A_) / a
        M = an * Mden + sn / s * (1 - a * Mden)
        var *= M * M
    return math.sqrt(var)


cc_rows = []; cc_err = 0.0
for aT in (0.1, 0.03, 0.01):
    for bm in (0.5, 1.0, 2.0, 4.0):
        unc = mode_std(1.0, 0.0, aT, 80000); cpl = mode_std(1.0, bm, aT, 80000)
        ratio = cpl / unc; pred = aT ** bm
        cc_rows.append({'a_T': aT, 'beta_mu': bm, 'ratio': ratio, 'predicted': pred,
                        'exact_target_ratio': math.sqrt(1 / (1 + bm))})
        cc_err = max(cc_err, abs(ratio / pred - 1))
conv_cc = [{'steps': st, 'relative_error': mode_std(1.0, 4.0, 0.01, st) / mode_std(1.0, 0.0, 0.01, st) / 1e-8 - 1}
           for st in (5000, 20000, 80000, 320000)]
Bres['constant_coupling'] = {'rows': cc_rows, 'max_relative_error': cc_err, 'steps': 80000, 'convergence': conv_cc}
check('Proposition 7.2: the discretisation error falls about fourfold per fourfold refinement',
      all(3.5 < conv_cc[i]['relative_error'] / conv_cc[i + 1]['relative_error'] < 4.5 for i in range(3)), 'V2')
check('Proposition 7.2: constant coupling scales each mode by a_T^(beta mu) (within 1%)', cc_err < 0.01, 'V2')
check('Proposition 7.2: with a_T = 0.01 and beta mu = 4 the mode is suppressed below 1e-7',
      [r_ for r_ in cc_rows if r_['a_T'] == 0.01 and r_['beta_mu'] == 4.0][0]['ratio'] < 1e-7, 'V2')

# =============================================================== SheafFarm audit
# Test bed: (i) the K4 scalar pair with equal Laplacians, (ii) a flat 2-D orthogonal system on K4
# with a two-dimensional section space, its frame transform, and its scaled copy (4L, same kernel).
Rflat = [rand_orth(2, rng) for _ in range(4)]
Tflat = [Rflat[w] @ Rflat[v].T for (v, w) in pairs4]                  # flat: holonomy identity
Bf, slf = coboundary(4, 2, transport_edges(4, 2, pairs4, Tflat)); Lf2 = Bf.T @ Bf
Tflat_g = [Gs[w] @ T @ Gs[v].T for (v, w), T in zip(pairs4, Tflat)]
Bfg, slfg = coboundary(4, 2, transport_edges(4, 2, pairs4, Tflat_g))
Bf4 = 2 * Bf
Bs1 = np.array([[(-r0[2 * k] if i == a else (r0[2 * k + 1] if i == b else 0.0)) for i in range(4)] for k, (a, b) in enumerate(E4)])
Bs2 = np.array([[(-rK4[2 * k] if i == a else (rK4[2 * k + 1] if i == b else 0.0)) for i in range(4)] for k, (a, b) in enumerate(E4)])
sl_s = [slice(k, k + 1) for k in range(6)]
Lg = np.zeros((4, 4))
for (a, b) in E4:
    Lg[a, a] += 1; Lg[b, b] += 1; Lg[a, b] -= 1; Lg[b, a] -= 1


def edge_mp(B, sl, z, alpha=0.1):
    out = z.copy()
    for s_ in sl:
        Be = B[s_]; y = Be @ z; nrm = np.linalg.norm(y)
        out -= alpha * Be.T @ (y * (math.tanh(nrm) / nrm if nrm > 0 else 1.0))
    return out


def ddim_cov(score, T=1000):
    """Exact covariance of deterministic DDIM from N(0, I) with a linear score A x + b (mean zero target)."""
    u = np.arange(T + 1) / T
    abar = np.clip(np.cos((u + .008) / 1.008 * np.pi / 2) ** 2 / math.cos(.008 / 1.008 * np.pi / 2) ** 2, 1e-4, 1)
    a, s = np.sqrt(abar), np.sqrt(1 - abar)
    n = score(a[T], s[T]).shape[0]; Sig = np.eye(n)
    for t in range(T, 0, -1):
        Am = score(a[t], s[t]); Mden = (np.eye(n) + s[t] ** 2 * Am) / a[t]
        M = a[t - 1] * Mden + s[t - 1] / s[t] * (np.eye(n) - a[t] * Mden)
        Sig = M @ Sig @ M.T
    return Sig


def exact_score(L, p=1.0, beta=1.0):
    C = np.linalg.inv(p * np.eye(len(L)) + beta * L)
    return lambda a, s: -np.linalg.inv(a * a * C + s * s * np.eye(len(L)))


def naive_score(L, p=1.0, beta=1.0):
    return lambda a, s: -np.eye(len(L)) / (a * a / p + s * s) - beta * L


def Ktau(L, d, tau=0.5):
    Hh = expm(-tau * L); n = len(L) // d; Dm = np.zeros_like(Hh)
    for v in range(n):
        blk = Hh[d * v:d * v + d, d * v:d * v + d]; w, Vv = np.linalg.eigh(blk)
        Dm[d * v:d * v + d, d * v:d * v + d] = Vv @ np.diag(w ** -0.5) @ Vv.T
    return Dm @ Hh @ Dm


# Each algorithm maps (B, slices, d, input) to an output vector, or to an output covariance for samplers.
farm = {
    'Constant-sheaf heat': ('det', lambda B, sl, d, z: expm(-np.kron(Lg, np.eye(d))) @ z),
    'Frozen sheaf heat': ('det', lambda B, sl, d, z: expm(-B.T @ B) @ z),
    'Sheaf resolvent': ('det', lambda B, sl, d, z: np.linalg.solve(np.eye(len(z)) + B.T @ B, z)),
    'Exact-kernel projector': ('det', lambda B, sl, d, z: proj_kernel(B.T @ B) @ z),
    'Sheaf layer with ReLU': ('det', lambda B, sl, d, z: relu(z - 0.1 * B.T @ B @ z)),
    'Sheaf layer, radial': ('det', lambda B, sl, d, z: radial(z - 0.1 * B.T @ B @ z, d)),
    'Edge-resolved message passing': ('det', lambda B, sl, d, z: edge_mp(B, sl, z)),
    'Correlated baseline noise': ('law', lambda B, sl, d, z: Ktau(B.T @ B, d)),
    'Coupled target, exact score': ('law', lambda B, sl, d, z: ddim_cov(exact_score(B.T @ B))),
    'Coupled target, constant coupling': ('law', lambda B, sl, d, z: ddim_cov(naive_score(B.T @ B))),
    'Intrinsic compatible sampler': ('law', lambda B, sl, d, z: proj_kernel(B.T @ B)),
}
declared = {   # the law each sampler claims to produce
    'Correlated baseline noise': lambda B, d: ('marginal', np.eye(d)),
    'Coupled target, exact score': lambda B, d: ('joint', np.linalg.inv(np.eye(B.shape[1]) + B.T @ B)),
    'Coupled target, constant coupling': lambda B, d: ('joint', np.linalg.inv(np.eye(B.shape[1]) + B.T @ B)),
    'Intrinsic compatible sampler': lambda B, d: ('joint', proj_kernel(B.T @ B)),
}
CERTS = ['E', 'S', 'F', 'P', 'C', 'Q']
zs = rng.normal(size=4); z2 = rng.normal(size=8)
Kf = null_space(Bf); zc = Kf @ rng.normal(size=Kf.shape[1])           # a compatible input
audit = {}
for name, (kind, fn) in farm.items():
    row = {}
    o1, o2 = fn(Bs1, sl_s, 1, zs), fn(Bs2, sl_s, 1, zs)
    row['E'] = bool(np.abs(o1 - o2).max() > 1e-6)
    oa, ob = fn(Bf, slf, 2, z2), fn(Bf4, slf, 2, z2)
    row['S'] = bool(np.abs(oa - ob).max() > 1e-6)
    og = fn(Bfg, slfg, 2, Gbig @ z2)
    row['F'] = bool(np.abs(og - (Gbig @ oa if kind == 'det' else Gbig @ oa @ Gbig.T)).max() < 1e-6)
    if kind == 'det':
        row['P'] = bool(np.abs(Bf @ fn(Bf, slf, 2, zc)).max() < 1e-9)
        row['C'] = bool(np.abs(Bf @ oa).max() < 1e-9)
        row['Q'] = None
    else:
        row['P'] = None
        row['C'] = bool(np.abs(Bf @ oa @ Bf.T).max() < 1e-9)          # residual covariance zero: a.s. compatible
        mode, target_ = declared[name](Bf, 2)
        if mode == 'marginal':
            row['Q'] = bool(max(np.abs(oa[2 * v:2 * v + 2, 2 * v:2 * v + 2] - target_).max() for v in range(4)) < 1e-2)
        else:
            row['Q'] = bool(np.linalg.norm(oa - target_) / np.linalg.norm(target_) < 1e-2)
    audit[name] = row
Bres['audit'] = {'certificates': CERTS, 'rows': audit}
exp_ = {'Constant-sheaf heat': 'E0 S0 F0 P0 C0', 'Frozen sheaf heat': 'E0 S1 F1 P1 C0',
        'Exact-kernel projector': 'E0 S0 F1 P1 C1', 'Edge-resolved message passing': 'E1 S1 F1 P1 C0',
        'Sheaf layer with ReLU': 'F0', 'Sheaf layer, radial': 'F1 P1',
        'Coupled target, exact score': 'Q1 C0', 'Coupled target, constant coupling': 'Q0 C1 S0',
        'Intrinsic compatible sampler': 'C1 Q1 S0', 'Correlated baseline noise': 'Q1 C0'}
ok_audit = True
for name, spec in exp_.items():
    for tok in spec.split():
        ok_audit &= audit[name][tok[0]] == bool(int(tok[1]))
check('SheafFarm audit: every certificate takes the value the theory predicts', ok_audit, 'V2')
check('SheafFarm audit: only edge-resolved message passing uses more than the Laplacian',
      [n for n, r_ in audit.items() if r_['E']] == ['Edge-resolved message passing'], 'V2')


# the partial order by inclusion of verified certificate sets
def certset(r_):
    return frozenset(c for c in CERTS if r_[c])


names = list(audit)
order = [[a_, b_] for a_ in names for b_ in names if a_ != b_ and certset(audit[a_]) < certset(audit[b_])]
cover = [[a_, b_] for a_, b_ in order if not any(certset(audit[a_]) < certset(audit[c_]) < certset(audit[b_]) for c_ in names)]
maximal = [n for n in names if not any(certset(audit[n]) < certset(audit[m]) for m in names)]
Bres['order'] = {'strict_pairs': order, 'cover_pairs': cover, 'maximal': maximal,
                 'sets': {n: sorted(certset(audit[n])) for n in names}}
check('SheafFarm order: there is more than one maximal algorithm (no single winner)', len(maximal) >= 2, 'V2')
R['v2'] = Bres
R['checks'] = tests
R['counts'] = {'v1': sum(t['part'] == 'V1' for t in tests), 'v2': sum(t['part'] == 'V2' for t in tests), 'total': len(tests)}
R['all_pass'] = all(t['passed'] for t in tests)
(P / 'legacy_results.json').write_text(json.dumps(R, indent=1, default=lambda o: o.tolist()) + '\n')
for t in tests:
    print(('PASS ' if t['passed'] else 'FAIL ') + f"[{t['part']}] " + t['name'])
print(R['counts'])
for n_, r_ in audit.items():
    print(f'{n_:36s}', ' '.join(f"{c}:{'-' if r_[c] is None else int(r_[c])}" for c in CERTS))
print('maximal:', maximal)
