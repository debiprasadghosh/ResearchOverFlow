"""Assemble paper.md: Version 1 text (labelled) + Version 2 blocks, then fill values and number equations."""
from pathlib import Path
import json, re

P = Path(__file__).resolve().parent
v1 = (P / 'v1_labelled.md').read_text()
blk = dict(re.findall(r'@@(\w+)\n(.*?)\n@@END', (P / 'blocks.md').read_text(), flags=re.S))


def after_paragraph(text, anchor, insert):
    i = text.index(anchor); j = text.index('\n\n', i)
    return text[:j] + '\n\n' + insert + text[j:]


s = v1
# figure and table renumbering for order of appearance
s = s.replace('**Figure 2.**', '**Figure 3.**').replace('Figure 2', 'Figure 3')
s = s.replace('Table: **Table 3.**', 'Table: **Table 6.**')
# front matter and roadmap
s = blk['FRONT'] + '\n\n' + s[s.index('# 1 What the title means'):]
i = s.index('This paper develops a small'); j = s.index('\n\n', i)
s = s[:i] + blk['ROADMAP'] + s[j:]
# section insertions
s = after_paragraph(s, '![**Figure 1.**', blk['S3'])
s = after_paragraph(s, 'Coordinatewise ReLU fails it for a general rotation', blk['S4'])
s = after_paragraph(s, 'These bounds do not certify robustness of every nonlinear', blk['S6'])
s = after_paragraph(s, 'This is a scalar times a sheaf resolvent on the centred', blk['S7'])
s = after_paragraph(s, 'There is one implication the comparison does establish', blk['S9'])
s = s.replace('# 9 An engineering evaluation', '# 10 An engineering evaluation')
s = s.replace('# 10 What should count as more sheaf', '# 11 What should count as more sheaf')
i = s.index('Table: **Table 6.**'); s = s[:i] + blk['P5'] + '\n\n' + s[i:]
i = s.index('## 9.1 Small mathematical checks'); j = s.index('# 11 What should count')
s = s[:i] + blk['CHECKS'] + '\n\n' + s[j:]
s = after_paragraph(s, 'For ASE and its diffusion ancestry, the useful next step', blk['CONCL'])
s = s.rstrip('\n') + '\n\n' + blk['REFS'] + '\n\n' + blk['APPENDIX'] + '\n'
# maths followed directly by a value: move the value inside the maths
s = re.sub(r'=\$\{\{([^}]+)\}\}', r'={{\1}}$', s)

# ---------------------------------------------------------------- values
R = json.loads((P / 'results.json').read_text()); cs = json.loads((P / 'cs_validate.json').read_text())
SUP = str.maketrans('-0123456789', '⁻⁰¹²³⁴⁵⁶⁷⁸⁹')
WORDS = 'zero one two three four five six seven eight nine ten eleven twelve'.split()


def sci(x):
    if x == 0:
        return '0'
    m, e = f'{x:.2e}'.split('e')
    return f'{m} × 10{str(int(e)).translate(SUP)}'


aud = R['v2']['audit']['rows']; sets = R['v2']['order']['sets']; maximal = R['v2']['order']['maximal']
classes = {tuple(sets[n]) for n in maximal}
mark = lambda v: '–' if v is None else ('✓' if v else '✗')
data = dict(R, cs=cs, cs_max=sci(cs['max_relative_difference']),
            n_maximal_word=WORDS[len(maximal)].capitalize(), n_classes_word=WORDS[len(classes)],
            audit_rows='\n'.join(f'| {n} | ' + ' | '.join(mark(aud[n][c]) for c in 'ESFPCQ') + ' |' for n in aud))


def lookup(path):
    val = data
    for k in path.split('.'):
        val = val[int(k)] if isinstance(val, list) else val[k]
    return val


def fmt(v, f):
    if f == '':
        return str(v)
    if f == 'd':
        return f'{int(round(v)):,}'
    if f == 'sci':
        return sci(v)
    if f.startswith('f'):
        return f'{v:.{int(f[1:])}f}'
    if f.startswith('pct'):
        return f'{100 * v:.{int(f[3:])}f}%'
    raise ValueError(f)


def short(line):
    head, *nums = line.split()
    vals = [f'{float(x):.6g}' for x in nums]
    body = ', '.join(vals) if len(vals) <= 4 else ', '.join(vals[:3]) + f', … ({len(vals)} values)'
    return head.replace('_', ' '), body.replace('-', '−')


def fill(m):
    body = m.group(1)
    if body.startswith('file:'):
        return (P / body[5:]).read_text().rstrip('\n')
    if body == 'cs_rows':
        return '\n'.join(f'| {short(c)[0]} | {short(c)[1]} | {sci(e)} |' for c, e in zip(cs['csharp'], cs['per_line']))
    path, _, f = body.partition('|')
    return fmt(lookup(path.strip()), f.strip())


s = s.replace('{{n_maximal_word_lc}}', '{{n_classes_word}}')
s = re.sub(r'\{\{(.+?)\}\}', fill, s)
assert '{{' not in s, 'unfilled placeholder'

# ---------------------------------------------------------------- equation numbers
labels = re.findall(r'\\tag\{([a-z]\d+)\}', s)
num = {lab: str(k + 1) for k, lab in enumerate(labels)}
s = re.sub(r'\\tag\{([a-z]\d+)\}', lambda m: r'\tag{' + num[m.group(1)] + '}', s)
s = re.sub(r'\(@([a-z]\d+)\)', lambda m: '(' + num[m.group(1)] + ')', s)
assert '(@' not in s
s = s.replace('_{+}', r'_{\text{+}}').replace('^{+}', r'^{\text{+}}')
s = re.sub(r'_\+(?![\w{])', r'_{\\text{+}}', s)
(P / 'paper.md').write_text(s)
print('paper.md:', len(s.split()), 'words;', len(labels), 'numbered equations')
