from pathlib import Path
from docx import Document
P=Path(__file__).resolve().parent
f=P/'output/SheafFarm_V3.docx';d=Document(f)
notes={
'Orthogonal connection transport is identifiable on a simple graph':'New scope result: on the stated simple-graph orthogonal family, the Laplacian already determines transport. The general scalar K4 example belongs to a different admissible family.',
'Half-amplitude damping depth':'Corrected from a holonomy-detection claim to an eigenmode damping time. Proposition 6.8 and evaluation P7 explain the distinction.',
'Constant force under a variance-preserving schedule':'The variance-preserving schedule is now explicit. At a positive signal cutoff the variance remains positive; exact collapse is only a limit. Proposition 7.3 covers other schedules.',
'SheafFarm as a typed audit':'The revision separates mathematical properties from numerical probes, finite from limiting constructions, and marginal from joint laws. No global inclusion ranking is asserted across different obligations.'}
for anchor,note in notes.items():
 ps=[p for p in d.paragraphs if anchor in p.text]
 assert len(ps)==1,(anchor,len(ps))
 assert ps[0].runs
 d.add_comment(ps[0].runs[0],note,author='Revision notes',initials='RN')
d.save(f)
print('Added four local revision comments')
