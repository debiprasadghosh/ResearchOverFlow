// SheafFarm reference kernel (Version 2): typed restrictions, the Gram and
// edge-resolved interfaces, cycle spectra, a thresholded kernel with its
// Davis-Kahan certificate, radial frame-covariant layers and the constant-
// coupling factor. Immutable records and pure static functions; the Jacobi
// eigensolver works on private copies.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace SheafFarm;

/// <summary>A dense real matrix stored row-major.</summary>
public sealed record Matrix(int Rows, int Cols, Vec Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Matrix Zero(int r, int c) =>
        new(r, c, Enumerable.Repeat(0.0, r * c).ToImmutableArray());

    public static Matrix Identity(int n) =>
        new(n, n, Enumerable.Range(0, n * n)
            .Select(k => k / n == k % n ? 1.0 : 0.0).ToImmutableArray());

    public static Matrix FromRows(params double[][] rows) =>
        new(rows.Length, rows[0].Length,
            rows.SelectMany(r => r).ToImmutableArray());

    public Matrix Transpose() =>
        new(Cols, Rows, Enumerable.Range(0, Rows * Cols)
            .Select(k => this[k % Rows, k / Rows]).ToImmutableArray());

    public Matrix Times(Matrix b) =>
        new(Rows, b.Cols, Enumerable.Range(0, Rows * b.Cols)
            .Select(k => Enumerable.Range(0, Cols)
                .Sum(j => this[k / b.Cols, j] * b[j, k % b.Cols]))
            .ToImmutableArray());

    public Vec Apply(Vec x) =>
        Enumerable.Range(0, Rows)
            .Select(i => Enumerable.Range(0, Cols).Sum(j => this[i, j] * x[j]))
            .ToImmutableArray();

    public Matrix Combine(double a, Matrix b, double c) =>
        this with { Data = Data.Zip(b.Data, (p, q) => a * p + c * q)
                               .ToImmutableArray() };

    public double MaxAbs => Data.Max(Math.Abs);

    /// <summary>Eigenvalues (ascending) and orthonormal eigenvectors (columns)
    /// of a symmetric matrix, by cyclic Jacobi rotations on private
    /// copies.</summary>
    public (Vec Values, Matrix Vectors) SymmetricEigen()
    {
        int n = Rows;
        var a = Data.ToArray();
        var v = Identity(n).Data.ToArray();
        for (int sweep = 0; sweep < 100; sweep++)
        {
            double off = 0.0;
            for (int p = 0; p < n; p++)
                for (int q = p + 1; q < n; q++) off += a[p * n + q] * a[p * n + q];
            if (off < 1e-300) break;
            for (int p = 0; p < n - 1; p++)
                for (int q = p + 1; q < n; q++)
                {
                    double apq = a[p * n + q];
                    if (apq == 0.0) continue;
                    double th = (a[q * n + q] - a[p * n + p]) / (2.0 * apq);
                    double t = th == 0.0 ? 1.0
                        : Math.Sign(th) / (Math.Abs(th) + Math.Sqrt(th * th + 1.0));
                    double c = 1.0 / Math.Sqrt(t * t + 1.0), s = t * c;
                    for (int k = 0; k < n; k++)
                        (a[k * n + p], a[k * n + q]) =
                            (c * a[k * n + p] - s * a[k * n + q],
                             s * a[k * n + p] + c * a[k * n + q]);
                    for (int k = 0; k < n; k++)
                        (a[p * n + k], a[q * n + k]) =
                            (c * a[p * n + k] - s * a[q * n + k],
                             s * a[p * n + k] + c * a[q * n + k]);
                    for (int k = 0; k < n; k++)
                        (v[k * n + p], v[k * n + q]) =
                            (c * v[k * n + p] - s * v[k * n + q],
                             s * v[k * n + p] + c * v[k * n + q]);
                }
        }
        var order = Enumerable.Range(0, n).OrderBy(i => a[i * n + i]).ToArray();
        var values = order.Select(i => a[i * n + i]).ToImmutableArray();
        var vectors = new Matrix(n, n, Enumerable.Range(0, n * n)
            .Select(k => v[(k / n) * n + order[k % n]]).ToImmutableArray());
        return (values, vectors);
    }
}

/// <summary>One edge v -> w with restrictions; residual Rw x_w - Rv x_v.</summary>
public sealed record Edge(int V, int W, Matrix Rv, Matrix Rw);

/// <summary>A typed cellular sheaf on a graph, vertex dimension d.</summary>
public sealed record TypedSheaf(int Vertices, int Dim, ImmutableArray<Edge> Edges)
{
    /// <summary>The coboundary block of one edge (de x Vertices*Dim).</summary>
    public Matrix EdgeBlock(Edge e)
    {
        int n = Vertices * Dim, de = e.Rv.Rows;
        return new Matrix(de, n, Enumerable.Range(0, de * n).Select(k =>
        {
            int r = k / n, c = k % n, vert = c / Dim, j = c % Dim;
            return (vert == e.V ? -e.Rv[r, j] : 0.0)
                 + (vert == e.W ? e.Rw[r, j] : 0.0);
        }).ToImmutableArray());
    }

    /// <summary>The edge-resolved interface: one Gram matrix per edge.</summary>
    public ImmutableArray<Matrix> EdgeGrams() =>
        Edges.Select(e => { var b = EdgeBlock(e); return b.Transpose().Times(b); })
             .ToImmutableArray();

    /// <summary>The Gram interface L: the sum of the edge Grams.</summary>
    public Matrix Laplacian() =>
        EdgeGrams().Aggregate(Matrix.Zero(Vertices * Dim, Vertices * Dim),
                              (acc, g) => acc.Combine(1, g, 1));

    /// <summary>Scalar stalks: transport r_v/r_w of each edge, read from its
    /// edge Gram alone (Corollary 3.5).</summary>
    public Vec TransportsFromEdgeGrams() =>
        Edges.Zip(EdgeGrams(), (e, g) => -g[e.V, e.W] / g[e.W, e.W])
             .ToImmutableArray();
}

public static class Farm
{
    /// <summary>Proposition 6.5: smallest eigenvalue of a rotation by eps
    /// distributed around an n-cycle with planar stalks.</summary>
    public static double CycleLambdaMin(double eps, int n) =>
        4 * Math.Pow(Math.Sin(eps / (2.0 * n)), 2);

    /// <summary>Corollary 6.6: layers of x -> (I - alpha L) x before the
    /// slowest holonomy mode has lost half its amplitude.</summary>
    public static int HolonomyDepth(double eps, int n, double alpha) =>
        (int)Math.Ceiling(Math.Log(2)
                          / -Math.Log(1 - alpha * CycleLambdaMin(eps, n)));

    /// <summary>Proposition 6.7: projector onto eigenvectors below theta.</summary>
    public static Matrix ThresholdedProjector(Matrix l, double theta)
    {
        var (vals, vecs) = l.SymmetricEigen();
        int n = l.Rows;
        var keep = Enumerable.Range(0, n).Where(i => vals[i] < theta).ToArray();
        return new Matrix(n, n, Enumerable.Range(0, n * n)
            .Select(k => keep.Sum(i => vecs[k / n, i] * vecs[k % n, i]))
            .ToImmutableArray());
    }

    /// <summary>Davis-Kahan certificate ||E|| / (lambda_plus - ||E||), valid
    /// when ||E|| is below lambda_plus / 2.</summary>
    public static double DavisKahanBound(double perturbation, double lambdaPlus) =>
        perturbation < lambdaPlus / 2 ? perturbation / (lambdaPlus - perturbation)
                                      : double.NaN;

    /// <summary>Proposition 4.3: x_v -> x_v tanh(|x_v|)/|x_v| at each
    /// vertex.</summary>
    public static Vec Radial(Vec x, int dim) =>
        Enumerable.Range(0, x.Length).Select(k =>
        {
            int v = k / dim;
            double nrm = Math.Sqrt(Enumerable.Range(v * dim, dim)
                                             .Sum(j => x[j] * x[j]));
            return nrm > 0 ? x[k] * Math.Tanh(nrm) / nrm : x[k];
        }).ToImmutableArray();

    /// <summary>One sheaf layer x -> sigma(x - alpha L x).</summary>
    public static Vec Layer(Matrix l, Vec x, double alpha, Func<Vec, Vec> sigma) =>
        sigma(x.Zip(l.Apply(x), (p, q) => p - alpha * q).ToImmutableArray());

    public static Vec Relu(Vec x) =>
        x.Select(v => Math.Max(v, 0)).ToImmutableArray();

    /// <summary>Proposition 7.2: the factor by which a constant force
    /// -beta L x scales a mode of eigenvalue mu under the probability flow
    /// started at signal level aT, and the factor the exact target needs.</summary>
    public static (double Constant, double Exact) CouplingFactors(
        double betaMu, double aT, double p) =>
        (Math.Pow(aT, betaMu), Math.Sqrt(p / (p + betaMu)));
}
