// Validation run; cs_validate.py recomputes every printed number with NumPy.
using System;
using System.Collections.Immutable;
using System.Globalization;
using System.Linq;
using SheafFarm;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

static string F(double x) => x.ToString("G15", CultureInfo.InvariantCulture);
static void Print(string name, params double[] xs) =>
    Console.WriteLine(name + " " + string.Join(" ", xs.Select(F)));
static Matrix S(double a) => Matrix.FromRows(new[] { a });
static Matrix Rot(double a) => Matrix.FromRows(new[] { Math.Cos(a), -Math.Sin(a) },
                                               new[] { Math.Sin(a), Math.Cos(a) });

// the Example 3.3 pair: two parallel edges, equal Laplacians
var pa = new TypedSheaf(2, 1, ImmutableArray.Create(
    new Edge(0, 1, S(1), S(1)), new Edge(0, 1, S(2), S(3))));
var pb = new TypedSheaf(2, 1, ImmutableArray.Create(
    new Edge(0, 1, S(11.0 / 5), S(3)), new Edge(0, 1, S(2.0 / 5), S(1))));
Print("pair_laplacian_a", pa.Laplacian().Data.ToArray());
Print("pair_laplacian_b", pb.Laplacian().Data.ToArray());
Print("pair_transports", pa.TransportsFromEdgeGrams()
      .Concat(pb.TransportsFromEdgeGrams()).ToArray());

// a scalar sheaf on K4 from the paper's starting point r0
var r0 = new[] { 1.2, 0.8, 0.9, 1.5, 1.1, 0.7, 1.3, 1.0, 0.6, 1.4, 1.6, 0.9 };
var k4pairs = new[] { (0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3) };
var k4 = new TypedSheaf(4, 1, k4pairs.Select((e, k) =>
    new Edge(e.Item1, e.Item2, S(r0[2 * k]), S(r0[2 * k + 1]))).ToImmutableArray());
Print("k4_laplacian", k4.Laplacian().Data.ToArray());
Print("k4_transports", k4.TransportsFromEdgeGrams().ToArray());

// rotation 3-cycle: spectrum, thresholded projector, Davis-Kahan certificate
TypedSheaf Cycle(double eps) => new(3, 2, ImmutableArray.Create(
    new Edge(0, 1, Matrix.Identity(2), Matrix.Identity(2)),
    new Edge(1, 2, Matrix.Identity(2), Matrix.Identity(2)),
    new Edge(2, 0, Rot(eps), Matrix.Identity(2))));
var l0 = Cycle(0).Laplacian();
var le = Cycle(0.1).Laplacian();
Print("cycle_eigenvalues", le.SymmetricEigen().Values.ToArray());
Print("cycle_lambda_min_formula", Farm.CycleLambdaMin(0.1, 3),
      Farm.CycleLambdaMin(0.3, 12));
Print("holonomy_depth", Farm.HolonomyDepth(0.1, 3, 0.25),
      Farm.HolonomyDepth(0.3, 12, 0.25));
var p0 = Farm.ThresholdedProjector(l0, 1.5);
var pe = Farm.ThresholdedProjector(le, 1.5);
Print("threshold_projector", pe.Combine(1, p0, -1).MaxAbs,
      Enumerable.Range(0, 6).Sum(i => pe[i, i]));
Print("davis_kahan", Farm.DavisKahanBound(0.2, 3.0),
      double.IsNaN(Farm.DavisKahanBound(2.0, 3.0)) ? 1 : 0);

// radial layer against ReLU under a frame change at one vertex of the cycle
var x = ImmutableArray.Create(0.3, -1.2, 0.8, 0.5, -0.4, 1.1);
var g = Rot(0.7);
Matrix Block(Matrix a, Matrix b, Matrix c) =>
    new(6, 6, Enumerable.Range(0, 36).Select(k =>
{
    int r = k / 6, col = k % 6, bv = r / 2;
    return bv != col / 2 ? 0.0 : (bv == 0 ? a : bv == 1 ? b : c)[r % 2, col % 2];
}).ToImmutableArray());
var gbig = Block(g, Matrix.Identity(2), Matrix.Identity(2));
var lg = gbig.Times(le).Times(gbig.Transpose());
Vec Diff(Func<Vec, Vec> sigma) =>
    Farm.Layer(lg, gbig.Apply(x), 0.1, sigma)
        .Zip(gbig.Apply(Farm.Layer(le, x, 0.1, sigma)), (p, q) => p - q)
        .ToImmutableArray();
Print("frame_defects", Diff(v => Farm.Radial(v, 2)).Max(Math.Abs),
      Diff(Farm.Relu).Max(Math.Abs));
Print("radial_layer", Farm.Layer(le, x, 0.1, v => Farm.Radial(v, 2)).ToArray());
Print("coupling_factors", new[] { 0.5, 1.0, 2.0, 4.0 }.SelectMany(bm =>
{
    var (c, e) = Farm.CouplingFactors(bm, 0.01, 1.0);
    return new[] { c, e };
}).ToArray());
