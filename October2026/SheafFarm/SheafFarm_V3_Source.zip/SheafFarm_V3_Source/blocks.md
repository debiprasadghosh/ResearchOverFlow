@@FRONT
---
title: "SheafFarm: Some Sheaf-Diffusion Algorithms are More Sheaf Than Others"
subtitle: Distinguishing operator, geometry, compatibility and generative law. Version 2
author:
  - Debi Prasad Ghosh
  - Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India
date: 20 October 2026 · Version 2
---

## Abstract

The name sheaf diffusion covers several different mathematical commitments. A model may assemble a Laplacian from restriction maps, transport data between local frames, preserve compatible assignments, or generate a probability law on global sections. These properties are not interchangeable. We propose a comparison by explicit structural certificates rather than a scalar measure of sheafness. Version 1 proved three separations. Algorithms that access a sheaf only through its vertex Laplacian cannot recover the whole sheaf. Preserving global sections does not imply a local sheaf morphism. Stronger compatibility can discard operator information: on a cycle with two-dimensional orthogonal data, an arbitrarily small nontrivial rotation changes the compatible subspace from dimension two to zero, so the zero-holonomy and infinite-diffusion limits do not commute.

Version 2 adds positive results and an executable audit. Two coboundaries have the same Laplacian if and only if they differ by an isometry of the edge space. The edge-resolved Grams recover the sheaf up to edge-local isometry, and with it every transport. On the complete graph on four vertices, which is a simple graph, scalar sheaves with one Laplacian form a two-dimensional family whose cycle holonomies vary continuously; on a single cycle the family is discrete. Radial vertex nonlinearities give frame-covariant sheaf layers where coordinatewise ReLU fails. On an $n$-cycle a rotation holonomy $\varepsilon$ gives smallest eigenvalue $4\sin^2(\varepsilon/2n)$, so the depth needed to see it grows like $n^2/\varepsilon^2$. A triangle with $\varepsilon=0.1$ needs {{v2.depth.rows.0.layers|d}} layers of step 0.25. A rank threshold inside the spectral gap restores the continuity that the exact kernel loses, with a Davis–Kahan certificate. Adding the clean force $-\beta Lx$ to an uncoupled score is worse than inexact. Under the probability flow started at signal level $a_T$, it scales each disagreement mode of eigenvalue $\mu$ by $a_T^{\beta\mu}$, and so silently becomes a hard constraint. Finally, a SheafFarm audit computes six certificates for eleven reference algorithms. {{n_maximal_word}} of them are maximal, so no algorithm is the most sheaf. All {{counts.total}} checks pass, and an immutable C# kernel agrees with NumPy on every output line. The question for an implementation remains precise: which structural information does the algorithm retain, which relations does it enforce, and which probability claim has actually been established?

**Keywords:** cellular sheaf; sheaf diffusion; sheaf Laplacian; holonomy; naturality; Gaussian diffusion; global sections; identifiability; spectral gap; model comparison.
@@END

@@ROADMAP
This paper develops a small mathematical theory of those interfaces. Section 3 establishes what a Laplacian-only algorithm cannot identify, and what the edge-resolved interface recovers. Section 4 removes coordinate-dependent notions of nontriviality and gives a frame-covariant nonlinear layer. Section 5 separates section preservation, cochain maps and local naturality. Section 6 shows how hard compatibility can forget geometry and become discontinuous, how cycle length hides holonomy, and how a rank policy restores continuity. Section 7 separates compatible noise, unchanged marginal laws and globally calibrated targets, and shows that a constant coupling force collapses to the hard law. Section 8 compares constructions. Section 9 runs the comparison as an executable certificate audit. Sections 10 and 11 give falsifiable engineering tests and conclusions.

## 1.1 What Version 2 adds

- **The Gram fibre and the edge-resolved interface (Section 3).** Equal Laplacians mean exactly an edge-space isometry (Theorem 3.4). The per-edge Grams recover every transport (Corollary 3.5). On simple graphs with more edges than vertices, one Laplacian hides a continuum of holonomies (Proposition 3.6).
- **A covariant nonlinearity (Section 4).** Radial vertex nonlinearities make sheaf layers frame covariant and section preserving (Proposition 4.3).
- **Cycle length, depth and rank policy (Section 6.3).** The spectrum of an orthogonal connection on an $n$-cycle gives a depth law for seeing holonomy (Proposition 6.5, Corollary 6.6). A threshold inside the spectral gap makes hard compatibility continuous (Proposition 6.7).
- **Constant coupling collapses (Section 7.2).** The clean force $-\beta Lx$ scales mode $\mu$ by $a_T^{\beta\mu}$ (Proposition 7.2).
- **SheafFarm (Section 9).** Six certificates are computed, not asserted, for eleven reference algorithms, and the inclusion order is drawn.
- **Evidence.** There are {{counts.total}} checks: the {{counts.v1}} Version 1 checks rebuilt from the paper's statements, and {{counts.v2}} new ones. An immutable C# kernel is listed in Appendix A.
@@END

@@S3
**Theorem 3.4 --- The Gram fibre.** Let $B_1$ and $B_2$ be whitened coboundaries on the same vertex space. Then $B_1^\top B_1=B_2^\top B_2$ if and only if there is a linear isometry $U:\text{im}B_1\to\text{im}B_2$ with

$$B_2=UB_1. \tag{n1}$$

When the two edge spaces have equal dimension, $U$ extends to an orthogonal map of the whole edge space.

*Proof.* If $B_2=UB_1$ with $U$ isometric on $\text{im}B_1$, then $B_2^\top B_2=B_1^\top U^\top UB_1=B_1^\top B_1$. Conversely, equal Grams give $\|B_1x\|=\|B_2x\|$ for every $x$. Hence $B_1x=B_1y$ implies $B_2x=B_2y$, so $U(B_1x)=B_2x$ is well defined, linear and isometric. When the dimensions agree, the orthogonal complements of the two images have equal dimension, and any isometry between them completes $U$. ▫

Theorem 3.1 therefore has an exact converse description. A Laplacian-only algorithm identifies the coboundary up to the group of all isometries of edge coordinates. Over a fixed graph with whitened edge metrics, the sheaf itself is determined only up to the smaller group of edge-local isometries $U=\oplus_eU_e$, which act on each edge space separately. The difference between these two groups is precisely what Laplacian-only algorithms cannot see. In Example 3.3 the isometry is the rotation

$$U=B_bB_a^{+}=\begin{pmatrix}0.6&0.8\\-0.8&0.6\end{pmatrix}, \tag{n2}$$

which mixes the two parallel edge coordinates. That mixing is exactly what changes the loop multiplier while leaving every vertex energy unchanged.

**Corollary 3.5 --- The edge-resolved interface identifies transports.** Suppose an algorithm receives the edge Grams $L_e=B_e^\top B_e$ for every edge, rather than only their sum $L$. Then it determines each edge block $B_e$ up to an isometry of $F(e)$, and hence the sheaf up to edge-local isometry. Whenever the head restriction is invertible, the transport $T_e=r_{we}^{-1}r_{ve}$ is determined exactly, and so is every cycle holonomy. For scalar stalks, $T_e=-(L_e)_{vw}/(L_e)_{ww}$.

*Proof.* Theorem 3.4 applied to each edge gives $B_e$ up to a left isometry $U_e$. Replacing $(r_{ve},r_{we})$ by $(U_er_{ve},U_er_{we})$ leaves $r_{we}^{-1}r_{ve}$ unchanged. For scalar stalks $(L_e)_{vw}=-r_{ve}r_{we}$ and $(L_e)_{ww}=r_{we}^2$. ▫

The corollary gives a positive meaning to "using more of the sheaf". An algorithm whose update depends on the individual edge residuals $B_ex$, nonlinearly or with edge-specific weights, can depend on information that no function of $L$ carries. Linear heat cannot, because its update sums the edge Grams before acting. Section 9 shows the difference on a test bed. The parallel-edge pair of Example 3.3 is not a special artefact, as the next result shows.

**Proposition 3.6 --- On simple graphs with more edges than vertices, one Laplacian hides a continuum.** Consider scalar stalks with nonzero restrictions on a simple connected graph. The map from the $2|E|$ restriction values to $L$ has at most $|E|+|V|$ independent output entries: one per vertex on the diagonal and one per edge off it. Near any point where its Jacobian has constant rank $k$, the set of restriction values with the same Laplacian is a manifold of dimension

$$2|E|-k\ \ge\ |E|-|V|. \tag{n3}$$

On the complete graph $K_4$, with $|E|=6$ and $|V|=4$, the Jacobian has rank {{v2.k4_fibre.jacobian_rank}}, so the fibre is two-dimensional. Along it the triangle holonomies change continuously. On a single cycle, $|E|=|V|$; for the tested 5-cycle the Jacobian has full rank {{v2.k4_fibre.cycle5_rank}}, so the fibre is discrete there.

*Proof.* The entry count is immediate for a simple graph, and the dimension statement is the constant-rank theorem. Edge sign changes form a finite group and cannot account for a positive-dimensional fibre. Cycle holonomy is invariant under every invertible scalar change of vertex frame, so sheaves on the fibre with different holonomies are not isomorphic over the fixed graph. The $K_4$ and 5-cycle statements are exact rank computations, and the holonomy variation along the $K_4$ fibre is computed in the companion script. ▫

Following the fibre of $K_4$ from one scalar sheaf for an arc length of 0.6 held every entry of $L$ fixed to {{v2.k4_fibre.max_residual|sci}}. Meanwhile the holonomy of triangle 0–1–2 moved from {{v2.k4_fibre.path.0.h012|f2}} to {{v2.k4_fibre.path.-1.h012|f2}}, and that of triangle 0–1–3 from {{v2.k4_fibre.path.0.h013|f2}} to {{v2.k4_fibre.path.-1.h013|f2}} (Figure 2). The edge Grams of the two end points differ by {{v2.edge_resolved.edge_gram_difference_on_pair|f2}} in some entry, and the transports read from them agree with the true ones to {{v2.edge_resolved.transport_recovery_error|sci}}. Thus every Laplacian-only algorithm, however deep or nonlinear, treats these geometrically different sheaves identically, and an edge-resolved algorithm need not.

![**Figure 2.** The Gram fibre on $K_4$ with scalar stalks. (a) Holonomies of three triangles along a path of sheaves that all have the same Laplacian; the sheaves are not isomorphic because their holonomies differ. (b) The largest change in any entry of $L$ along the path; exact zeros are plotted at $10^{-17}$.](fig/fibre.png){width=100%}
@@END

@@S4
**Proposition 4.3 --- Radial nonlinearities give frame-covariant layers.** Let $\sigma$ act on each vertex value by $\sigma(x)_v=x_v\varphi(\|x_v\|)$ for some scalar function $\varphi$. Then $\sigma(Gx)=G\sigma(x)$ for every block-diagonal orthogonal $G$. Hence the layer $x\mapsto\sigma(x-\alpha Lx)$ is covariant under orthogonal local frames. On a connected orthogonal local system it also maps compatible assignments to compatible assignments.

*Proof.* $\|G_vx_v\|=\|x_v\|$, so $\sigma(Gx)_v=G_vx_v\varphi(\|x_v\|)$. Combine this with $L'=GLG^\top$ from Proposition 4.2. A compatible assignment satisfies $Lx=0$, and orthogonal transport along a connected graph gives every vertex the same norm. So every vertex is multiplied by the same factor, which preserves each residual $x_w-T_ex_v=0$. ▫

The radial layer with $\varphi(r)=\tanh(r)/r$ had frame defect {{v2.frame.radial_defect|sci}} on a random orthogonal system on $K_4$. The same layer with coordinatewise ReLU had defect {{v2.frame.relu_defect|f3}}. The positive example shows that frame covariance is a design choice available to nonlinear sheaf networks, not only to linear ones. Its cost is that the nonlinearity sees only norms within each stalk.
@@END

@@S6
## 6.3 Longer cycles hide holonomy, and a rank policy restores continuity

Theorem 6.3 concerns a triangle. Its quantitative content depends on cycle length.

**Proposition 6.5 --- Spectrum of an orthogonal connection on a cycle (classical).** Let an $n$-cycle carry $d$-dimensional stalks and orthogonal transports with holonomy $H$, whose eigenvalues are $e^{i\theta_j}$. The Laplacian spectrum is

$$\left\{2-2\cos\frac{\theta_j+2\pi k}{n}\ :\ j=1,\ldots,d,\ k=0,\ldots,n-1\right\}. \tag{n4}$$

For a planar rotation by $\varepsilon$ with $|\varepsilon|<\pi$, the smallest eigenvalue is

$$\lambda_{\min}=4\sin^2\frac{\varepsilon}{2n}\sim\frac{\varepsilon^2}{n^2}. \tag{n5}$$

*Proof.* Local frames distribute the holonomy as $H^{1/n}$ on every edge, which conjugates $L$ without changing its spectrum. In the eigenbasis of $H$ the operator becomes $d$ scalar circulants with twist $e^{i\theta_j/n}$, whose Fourier modes give (@n4). Theorem 6.3 is the case $n=3$. ▫

**Corollary 6.6 --- Depth needed to see holonomy.** For the discrete diffusion $x\mapsto(I-\alpha L)x$ with $0<\alpha\lambda_{\max}\le1$, the slowest mode loses half its amplitude only after

$$K_{1/2}=\left\lceil\frac{\ln2}{-\ln(1-4\alpha\sin^2(\varepsilon/2n))}\right\rceil\approx\frac{n^2\ln2}{\alpha\varepsilon^2} \tag{n6}$$

layers. Before then, the system is within a factor of two of a flat one along that mode.

With $\alpha=0.25$, a triangle with holonomy 0.1 needs {{v2.depth.rows.0.layers|d}} layers, a 6-cycle needs {{v2.depth.rows.3.layers|d}}, and a 12-cycle {{v2.depth.rows.6.layers|d}}. In every tested case the slowest mode fell to one half exactly at the predicted layer. A sheaf network of a few dozen layers therefore cannot tell small holonomy from none on a long cycle through diffusion alone. If holonomy matters to a task, it must enter through an interface that reads it directly, such as the edge-resolved one.

The discontinuity in Theorem 6.3 belongs to a particular rank policy: treating eigenvalue zero exactly. A threshold inside the spectral gap behaves differently.

**Proposition 6.7 --- A rank threshold restores continuity.** Let $L$ have kernel projector $\Pi$ and smallest positive eigenvalue $\lambda_+$. Let $\widehat L$ be symmetric with $\eta=\|\widehat L-L\|_2<\lambda_+/2$. Then the spectral projector $\widehat P$ of $\widehat L$ onto eigenvalues below $\lambda_+/2$ has the rank of $\Pi$, and

$$\|\widehat P-\Pi\|_2\le\frac{\eta}{\lambda_+-\eta}\le\frac{2\eta}{\lambda_+}. \tag{n7}$$

*Proof.* By Weyl's inequality the eigenvalues of $\widehat L$ that continue the zero eigenvalues lie below $\eta<\lambda_+/2$, and the others lie above $\lambda_+-\eta>\lambda_+/2$. So the ranks agree. The Davis–Kahan $\sin\Theta$ theorem with separation $\lambda_+-\eta$ bounds the distance between the projectors by $\|(\widehat L-L)\Pi\|_2/(\lambda_+-\eta)$ [12]. ▫

On the rotation triangle, $\lambda_+=${{v2.threshold.lambda_plus|f0}}. At $\varepsilon=0.1$ the perturbation is $\eta=${{v2.threshold.rows.4.perturbation|f4}}, the thresholded projector moves by {{v2.threshold.rows.4.threshold_distance|f4}}, and the bound (@n7) is {{v2.threshold.rows.4.bound|f4}}. The exact-kernel projector moves by one at every nonzero angle (Figure 4b). The threshold declares near-flat systems flat. That is a modelling decision with a quantified consequence, not a numerical detail, and it should be reported with the model.

![**Figure 4.** (a) Smallest Laplacian eigenvalue against holonomy angle for rotation cycles of length 3 to 24. Lines are (@n5) and points are computed eigenvalues; longer cycles hide holonomy quadratically. (b) Distance of the compatible projector from the flat one on the rotation triangle. The exact kernel jumps to one at every nonzero angle, while a threshold at $\lambda_+/2$ moves continuously and stays below the Davis–Kahan bound (@n7).](fig/cycles.png){width=100%}
@@END

@@S7
The size of the error has a closed form, and it is not small.

**Proposition 7.2 --- Constant coupling becomes a hard constraint.** Take a centred uncoupled Gaussian target whose covariance commutes with $L$, for instance $N(0,p^{-1}I)$. Add the clean force $-\beta Lx$ to its exact score at every noise level, and run the probability-flow limit of deterministic DDIM from signal level $a_T$. Then along every eigenvector of $L$ with eigenvalue $\mu$, the output equals that of the uncoupled flow multiplied by

$$a_T^{\beta\mu}, \tag{n8}$$

whereas the exact coupled target requires the factor $\sqrt{p/(p+\beta\mu)}$, independent of $a_T$. As $a_T\to0$, every disagreement mode is removed, and the sampler converges to the hard intrinsic law on $\ker L$.

*Proof.* In clean coordinates $z=x/a$ and $\sigma=s/a$, the deterministic DDIM update is $z'=z+(\sigma'-\sigma)\widehat\epsilon$ with $\widehat\epsilon=-s\nabla\log p(x)$, so in the continuum limit $\text{d}z/\text{d}\sigma=-s\nabla\log p(az)$. The added force contributes $\beta\mu\,as\,z$ along the eigenvector, separately from the uncoupled part, because both are diagonal in the same basis. Since $as=\sigma/(1+\sigma^2)$, integrating from $\sigma_T$ down to zero multiplies the component by $\exp(-\frac{1}{2}\beta\mu\ln(1+\sigma_T^2))=a_T^{\beta\mu}$, using $1+\sigma_T^2=a_T^{-2}$. ▫

With the common choice $\bar\alpha_T=10^{-4}$, so $a_T=0.01$, a mode with $\beta\mu=4$ is scaled by $10^{-8}$ instead of the required {{v2.constant_coupling.rows.11.exact_target_ratio|f3}}. Deterministic DDIM over 80,000 steps reproduced (@n8) within {{v2.constant_coupling.max_relative_error|pct1}} for $a_T\in\{0.1,0.03,0.01\}$ and $\beta\mu\in\{0.5,1,2,4\}$, and the error fell fourfold for each fourfold refinement (Figure 5). This explains the over-gluing reported in [7]. A constant coupling does not merely miss the soft target; it implements a different, hard one, and so loses the positive spectral information of Theorem 6.1 while appearing to enforce agreement well.

![**Figure 5.** Output scale of a horizontal mode under constant coupling, against $\beta\mu$, for three starting signal levels. Dashed lines are $a_T^{\beta\mu}$ from (@n8); points are deterministic DDIM simulations. The solid line is the scale required by the exact coupled target.](fig/coupling.png){width=82%}
@@END

@@S9
# 9 SheafFarm: an executable certificate audit

Table 2 records declared obligations. This section computes certificates instead. It runs eleven reference algorithms on one test bed and records which certificates each verifies. The audit is a measurement on that test bed, not a theorem about the algorithms in general. A failed certificate is a witness against the claim, and a passed one is evidence for it.

The test bed has three parts. The first is the pair of scalar sheaves on $K_4$ from Proposition 3.6, which have the same Laplacian but different holonomy. The second is a flat orthogonal system on $K_4$ with planar stalks and a two-dimensional section space, together with its transform by random vertex rotations. The third is the same system with every restriction doubled, which multiplies $L$ by four and keeps its kernel. The six certificates are computed as follows.

Table: **Table 4.** The certificates computed by the audit.

| Certificate | Computed test | Theory behind it |
|:--|:--|:--|
| E: edge-resolved | Output differs on the two $K_4$ sheaves with equal $L$ | Theorem 3.1, Corollary 3.5 |
| S: positive spectrum | Output differs between $L$ and $4L$, which share a kernel | Theorem 6.1 |
| F: frame covariant | Output, or output covariance, transforms with the vertex rotations | Propositions 4.2, 4.3 |
| P: preserves sections | A compatible input gives a compatible output | Theorem 5.1 |
| C: compatible output | Every output is compatible, or the output covariance is supported on $\ker\delta$ | Section 7.1 |
| Q: declared law | A sampler reproduces its declared law within 1% (exact covariance propagation) | Section 7, Proposition 7.2 |

Table: **Table 5.** Certificates verified by eleven reference algorithms (✓ verified, ✗ failed, – inapplicable).

| Algorithm | E | S | F | P | C | Q |
|:--|:-:|:-:|:-:|:-:|:-:|:-:|
{{audit_rows}}

![**Figure 6.** The SheafFarm audit. (a) The certificate matrix of Table 5. (b) The inclusion order of verified certificate sets. Algorithms with equal sets share a box, a line joins a set to the smallest sets containing it, and height is the number of certificates. Orange boxes are maximal: none is dominated.](fig/farm.png){width=100%}

Five findings follow, each anticipated by a proved statement.

- **Only edge-resolved message passing verifies E.** Every other algorithm, including the nonlinear ReLU and radial layers, sees the sheaf through $L$ and gives identical outputs on the $K_4$ pair (Theorem 3.1). The edge-resolved layer applies a radial nonlinearity to each edge residual before summing, and so reads what Corollary 3.5 says the edge Grams carry.
- **Frame covariance is a property of the whole layer.** Frozen heat, the resolvent and the radial layer verify F; the ReLU layer does not (Propositions 4.2, 4.3). Constant-sheaf heat fails F and every other certificate, because it ignores the maps altogether.
- **The radial layer has the certificates of frozen heat.** It is nonlinear, yet it verifies exactly $\{F,P,S\}$. The ReLU layer verifies only $\{S\}$.
- **More agreement, less geometry.** Constant coupling verifies C, with exactly compatible outputs, while failing S and Q. That is Proposition 7.2: it has become the hard law. The exact coupled sampler fails C, as a soft law must, but verifies S and Q.
- **No single winner.** The order has {{n_classes_word}} maximal classes: the kernel projector $\{C,F,P\}$, the intrinsic sampler $\{C,F,Q\}$, correlated noise and the exact coupled sampler $\{F,Q,S\}$, and edge-resolved message passing $\{E,F,P,S\}$. They are pairwise incomparable.

The last finding is the title's claim in its precise form. Some algorithms do use more sheaf than others: edge-resolved message passing dominates frozen heat, and frozen heat dominates the ReLU layer. But "more sheaf" is a partial order with several maximal elements, not a ladder. Which maximal element to build depends on whether the task needs edge information, exact agreement, positive spectral information or a calibrated law.
@@END

@@P5
**P5 --- Edge-resolved information matters exactly where the Laplacian is silent.** On labelled pairs from Gram fibres such as Proposition 3.6, every Laplacian-only model is at chance by Theorem 3.1. An edge-resolved model can exceed chance. Measure accuracy on held-out fibre pairs; a Laplacian-only model above chance refutes the implementation claim, because it must be using other information. Away from such pairs, test whether edge resolution improves held-out task loss over a matched Laplacian model. This is the performance hypothesis, and it may fail.

**P6 --- A rank policy inside the gap is stable; an exact one is not.** Under small random perturbations of calibrated maps near a flat cycle, the retained dimension of an exact-kernel model should change, and that of a thresholded model should not, as long as the perturbation stays below $\lambda_+/2$ (Proposition 6.7). Report the retained dimension and the projector distance against the bound (@n7). A violation of the bound refutes the implementation.

**P7 --- Shallow diffusion cannot see small holonomy on long cycles.** A frozen linear stack of $K<K_{1/2}$ layers (@n6) should not separate a cycle with holonomy $\varepsilon$ from a flat one by more than the factor $(1-\alpha\lambda_{\min})^K$. A learned diffusion-only network should approach chance on holonomy labels as $\varepsilon$ shrinks or $n$ grows. Separation beyond the factor indicates leakage of edge information and should be traced.
@@END

@@CHECKS
## 10.1 Small mathematical checks

The companion script records {{counts.total}} deterministic checks, all passing in its saved runtime. {{counts.v1}} rebuild the Version 1 checks from the statements of this paper, using their own random instances where Version 1 used random examples. {{counts.v2}} check the Version 2 results and the audit. They illustrate exact examples and bounds, not learned-model performance.

Table: **Table 7.** Recorded values of selected checks.

| Result | Check | Recorded value |
|:--|:--|:--|
| Example 3.2 | First cohomology of the same-Gram pair | 0 and 1 |
| Example 3.3 | Loop multipliers of the parallel-edge pair | 3/2 and 11/6 |
| Theorem 4.1 | Tree gauge-flattening residual | {{v1.tree_gauge_residual|sci}} |
| Example 5.2 | Best local square defect; global factorisation residual | 3; {{v1.factorisation_residual|sci}} |
| Theorem 6.1 | Path heat difference at $t=1$ ($L_0$ against $4L_0$) | {{v1.path_heat_difference_t1|f6}} |
| Proposition 6.2 | Gaussian reconstruction of $L$ | {{v1.gaussian_reconstruction|sci}} |
| Theorem 6.3 | $\lambda_{\min}$ at $\varepsilon=0.003$; error from (@e14) | {{v1.rotation_lambda_min|sci}}; {{v1.rotation_formula_error|sci}} |
| Theorem 7.1 | Frustrated-cycle residual with unit marginals ($\tau=0.5$) | {{v1.frustrated_residual|f6}} |
| Theorem 3.4 | Isometry residual on the Example 3.3 pair | {{v2.gram_fibre.converse|sci}} |
| Proposition 3.6 | $K_4$ Jacobian rank; Laplacian drift along the fibre | {{v2.k4_fibre.jacobian_rank}} of 12; {{v2.k4_fibre.max_residual|sci}} |
| Corollary 3.5 | Transport recovery from edge Grams | {{v2.edge_resolved.transport_recovery_error|sci}} |
| Proposition 4.3 | Frame defect, radial against ReLU | {{v2.frame.radial_defect|sci}} against {{v2.frame.relu_defect|f3}} |
| Proposition 6.5 | Largest spectral error, random holonomies, $n=3,5,8$ | {{v2.cycle_spectrum.max_error|sci}} |
| Corollary 6.6 | Half-amplitude depth, 9 cases | Exact in every case |
| Proposition 6.7 | Thresholded projector at $\varepsilon=0.1$ against bound | {{v2.threshold.rows.4.threshold_distance|f4}} against {{v2.threshold.rows.4.bound|f4}} |
| Proposition 7.2 | Largest error from $a_T^{\beta\mu}$, 80,000 steps | {{v2.constant_coupling.max_relative_error|pct2}} |
| C# kernel | Largest relative difference from NumPy, {{cs.lines}} lines | {{cs_max}} |

All displayed numerical values are read from the result files. The Version 1 script was not part of this revision's inputs, so its checks were rebuilt; the rebuilt values agree with every number quoted in Version 1 that does not depend on a random instance, including 0.349564, 3.903308 and the $10^{-6}$ eigenvalue. The paper's main findings remain proved statements about finite-dimensional interfaces and explicit limiting examples.
@@END

@@CONCL
Version 2 adds a positive side to these separations. The information a Laplacian hides is exactly an edge-space isometry, and the edge-resolved Grams restore it. Holonomy that diffusion can barely see on a long cycle can be read directly from those Grams. The discontinuity of hard compatibility is a property of the exact-kernel policy, and a threshold inside the gap removes it at a declared price. A constant coupling force is not a cheap soft target but a hard one in disguise. Computed over eleven algorithms, the certificates form a partial order with several maximal elements. Some sheaf-diffusion algorithms are indeed more sheaf than others, but none is most sheaf in every respect.
@@END

@@REFS
\[12\] Davis, C. and Kahan, W. M. (1970). The rotation of eigenvectors by a perturbation. III. *SIAM Journal on Numerical Analysis* 7(1), 1--46. https://doi.org/10.1137/0707001
@@END

@@APPENDIX
# Appendix A. An immutable C# reference kernel

The kernel implements typed restrictions with the Gram and edge-resolved interfaces (Theorem 3.4, Corollary 3.5), the cycle spectrum and depth law (@n5)–(@n6), a thresholded projector with its Davis–Kahan certificate (@n7), radial frame-covariant layers (Proposition 4.3) and the coupling factors of (@n8). It uses immutable records, `ImmutableArray<double>` and pure static functions; the Jacobi eigensolver works on private copies. A validation program prints {{cs.lines}} lines on fixed inputs, including the Example 3.3 pair, the $K_4$ starting sheaf and the rotation triangle. An independent NumPy implementation recomputes each line.

```csharp
{{file:cs/SheafFarm.cs}}
```

Table: **Table 8.** C# against NumPy, line by line (.NET {{cs.dotnet}}).

| Output | C# values | Largest relative difference |
|:--|:--|--:|
{{cs_rows}}
@@END
