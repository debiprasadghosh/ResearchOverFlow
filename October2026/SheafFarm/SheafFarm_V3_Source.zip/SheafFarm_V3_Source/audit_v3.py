"""Scoped properties of explicit reference formulas, not universal numerical certificates."""
from pathlib import Path
import json
P=Path(__file__).resolve().parent
names=['Constant heat against supplied maps','Frozen sheaf heat','Sheaf resolvent','Exact-kernel projector','Sheaf ReLU layer','Shared radial vertex layer','Radial edge-gradient step','Correlated baseline noise','Exact soft Gaussian target','Constant force finite cutoff','Constant force hard limit','Intrinsic compatible sampler']
# Columns E,S,F,P,C,Qm,Qj; - means no such obligation is claimed in this row.
rows=['00000--','01110--','01110--','00111--','01000--','01110--','11110--','011-01-','011-0-1','011-0-0','001-1-0','001-1-1']
R={'columns':['E','S','F','P','C','Qm','Qj'],'rows':{n:[None if x=='-' else int(x) for x in q] for n,q in zip(names,rows)},'scope':'Mathematical properties of declared reference formulas. Empirical probes are not proofs of universal identities. No global cross-type inclusion order is defined.'}
(P/'audit_v3.json').write_text(json.dumps(R,indent=2)+'\n')
