"""Independent finite-dimensional checks for the V3 corrections and extensions."""
from pathlib import Path
from fractions import Fraction as F
import json, math, sys
import numpy as np
import scipy
from scipy.linalg import block_diag, expm
from scipy.integrate import quad
P=Path(__file__).resolve().parent
rng=np.random.default_rng(20261021)
R={'python':sys.version.split()[0],'numpy':np.__version__,'scipy':scipy.__version__,'seed':20261021};tests=[]
def check(name,ok):tests.append({'name':name,'passed':bool(ok)})
def orth(d):
 q,r=np.linalg.qr(rng.normal(size=(d,d)));return q*np.sign(np.diag(r))
def cob(n,d,edges):
 rows=[]
 for v,w,A,C in edges:
  b=np.zeros((A.shape[0],n*d));b[:,v*d:(v+1)*d]=-A;b[:,w*d:(w+1)*d]=C;rows.append(b)
 return np.vstack(rows)
def rotation(a):return np.array([[math.cos(a),-math.sin(a)],[math.sin(a),math.cos(a)]])
def cycle(n,H):
 d=len(H);return cob(n,d,[(i,(i+1)%n,H if i==n-1 else np.eye(d),np.eye(d)) for i in range(n)])
def rref(A):
 A=[list(map(F,row)) for row in A];m=len(A);n=len(A[0]);row=0;piv=[]
 for j in range(n):
  k=next((i for i in range(row,m) if A[i][j]),None)
  if k is None:continue
  A[row],A[k]=A[k],A[row];a=A[row][j];A[row]=[x/a for x in A[row]]
  for i in range(m):
   if i!=row:
    a=A[i][j];A[i]=[x-a*y for x,y in zip(A[i],A[row])]
  piv.append(j);row+=1
  if row==m:break
 return A,piv
def determinant(A):
 A=[list(map(F,row)) for row in A];det=F(1);n=len(A)
 for j in range(n):
  k=next((i for i in range(j,n) if A[i][j]),None)
  if k is None:return F(0)
  if k!=j:A[j],A[k]=A[k],A[j];det=-det
  a=A[j][j];det*=a
  for i in range(j+1,n):
   b=A[i][j]/a
   for q in range(j,n):A[i][q]-=b*A[j][q]
 return det
# Exact regular-point witness for the original K4 family. Rows: four diagonal
# sums, then the six positive endpoint products. Coordinates t=10r.
edges=[(i,j) for i in range(4) for j in range(i+1,4)]
t=[12,8,9,15,11,7,13,10,6,14,16,9]
J=[[F(0) for _ in t] for _ in range(10)]
for k,(v,w) in enumerate(edges):
 J[v][2*k]=2*t[2*k];J[w][2*k+1]=2*t[2*k+1]
 J[4+k][2*k]=t[2*k+1];J[4+k][2*k+1]=t[2*k]
rr,piv=rref(J);free=[k for k in range(12) if k not in piv];N=[]
for j in free:
 v=[F(0)]*12;v[j]=F(1)
 for i,k in enumerate(piv):v[k]=-rr[i][j]
 N.append(v)
grad=[F(0)]*12
# log holonomy of 0->1->2->0: t0/t1 * t6/t7 * t3/t2
for j,sgn in [(0,1),(1,-1),(6,1),(7,-1),(3,1),(2,-1)]:grad[j]=F(sgn,t[j])
der=[sum(x*y for x,y in zip(grad,v)) for v in N]
minor=determinant([[row[j] for j in piv] for row in J])
R['exact_fibre']={'t':t,'pivot_columns_zero_based':piv,'minor_determinant':str(minor),'rank':len(piv),'log_holonomy_directional_derivatives':[str(v) for v in der]}
check('K4 Jacobian has exact rational rank ten at the recorded point',len(piv)==10 and minor!=0)
check('K4 holonomy has a nonzero exact derivative tangent to its Gram fibre',any(v!=0 for v in der))
# Orthogonal incidence maps on a simple graph, with edge scalar weights.
n,d=4,3;As=[orth(d) for _ in edges];Cs=[orth(d) for _ in edges];weights=rng.uniform(.3,2,len(edges))
B=cob(n,d,[(v,w,math.sqrt(q)*A,math.sqrt(q)*C) for (v,w),q,A,C in zip(edges,weights,As,Cs)]);L=B.T@B
rec=[];we=[]
for (v,w),q,A,C in zip(edges,weights,As,Cs):
 off=L[v*d:(v+1)*d,w*d:(w+1)*d];qh=np.linalg.norm(off,'fro')/math.sqrt(d)
 we.append(abs(qh-q));rec.append(np.linalg.norm(-off.T/qh-C.T@A,2))
R['orthogonal_recovery']={'weight_error':max(we),'transport_error':max(rec)}
check('Simple orthogonal connection transports are recovered from off-diagonal Laplacian blocks',max(rec)<1e-12)
check('Unknown positive scalar edge weights are recovered from block Frobenius norms',max(we)<1e-12)
# Parallel cancellation is a boundary of the recovery theorem.
Bpa=cob(2,1,[(0,1,np.array([[1.]]),np.eye(1)),(0,1,np.array([[-1.]]),np.eye(1))])
Bpb=cob(2,1,[(0,1,np.array([[-1.]]),np.eye(1)),(0,1,np.array([[1.]]),np.eye(1))])
check('Labelled parallel edges can hide different transports with the same orthogonal Gram',np.allclose(Bpa.T@Bpa,Bpb.T@Bpb) and not np.array_equal(Bpa,Bpb))
# Nonlinear energy log cosh(norm residual), matching the original edge_mp.
def blocks(B,nedges):return np.array_split(B,nedges)
def energy(B,z,ne):return sum(float(np.logaddexp(q,-q)-math.log(2)) for q in [np.linalg.norm(b@z) for b in blocks(B,ne)])
def grad_energy(B,z,ne):
 g=np.zeros(len(z))
 for b in blocks(B,ne):
  u=b@z;r=np.linalg.norm(u);g+=b.T@(u*(math.tanh(r)/r if r else 1.))
 return g
z=rng.normal(size=n*d);ne=len(edges);g=grad_energy(B,z,ne);h=1e-6
fd=np.array([(energy(B,z+h*e,ne)-energy(B,z-h*e,ne))/(2*h) for e in np.eye(len(z))]);ge=float(np.linalg.norm(fd-g,np.inf))
R['nonlinear_energy']={'gradient_error':ge}
check('Edge-resolved radial message passing is the gradient of log cosh residual energy',ge<1e-8)
G=block_diag(*[orth(d) for _ in range(n)]);U=block_diag(*[orth(d) for _ in edges]);Bg=U@B@G.T
frame=np.linalg.norm(grad_energy(Bg,G@z,ne)-G@g,np.inf)
R['nonlinear_energy']['frame_defect']=float(frame)
check('The nonlinear gradient is covariant under independent vertex and edge orthogonal frames',frame<1e-12)
alpha=.8/np.linalg.norm(L,2);z1=z-alpha*g
lhs=energy(B,z1,ne);rhs=energy(B,z,ne)-alpha*(1-alpha*np.linalg.norm(L,2)/2)*np.dot(g,g)
R['nonlinear_energy'].update(energy_before=energy(B,z,ne),energy_after=lhs,descent_margin=rhs-lhs)
check('A certified step decreases the nonlinear energy by the descent-lemma bound',lhs<=rhs+1e-12)
u=rng.normal(size=len(z));v=rng.normal(size=len(z));lip=np.linalg.norm(grad_energy(B,u,ne)-grad_energy(B,v,ne))/np.linalg.norm(u-v)
check('The nonlinear gradient satisfies the bound Lipschitz constant at most norm L',lip<=np.linalg.norm(L,2)+1e-12)
# Arbitrary partial maps: a compatible vector is fixed because every residual vanishes.
Bpartial=np.array([[-1.,0,1.,0],[0,0,-1.,1.]])
sec=np.array([.7,2.,.7,.7]);R['nonlinear_energy']['partial_section_residual']=float(np.linalg.norm(grad_energy(Bpartial,sec,2)))
check('Nonlinear edge-gradient fixes a section even for partial nonorthogonal restrictions',np.linalg.norm(grad_energy(Bpartial,sec,2))<1e-12)
# Reflective holonomy on an even cycle has no real orthogonal nth root, but
# the twisted complex Fourier formula still holds.
H=np.diag([-1.,1.]);nr=4;Bc=cycle(nr,H);ang=np.angle(np.linalg.eigvals(H));pred=sorted(2-2*math.cos((th+2*math.pi*k)/nr) for th in ang for k in range(nr))
err=float(np.max(np.abs(np.linalg.eigvalsh(Bc.T@Bc)-pred)));R['reflection_spectrum_error']=err
check('Cycle spectrum holds for reflection holonomy on an even cycle',err<1e-12)
# Finite heat detects first-order coordinate changes, far before half damping.
tm=.5;epss=[1e-3,1e-4,1e-5];Lzero=cycle(3,np.eye(2));Lzero=Lzero.T@Lzero
heat=[]
for eps in epss:
 Be=cycle(3,rotation(eps));Le=Be.T@Be;diff=float(np.linalg.norm(expm(-tm*Le)-expm(-tm*Lzero),2))
 heat.append({'epsilon':eps,'difference':diff,'difference_over_epsilon':diff/eps,'bound':tm*2*math.sin(eps/2)})
R['finite_detection']=heat
check('Finite heat differs at first order in a small holonomy angle',min(q['difference_over_epsilon'] for q in heat)>.05)
check('Finite heat differences satisfy the Duhamel perturbation bound',all(q['difference']<=q['bound']+1e-12 for q in heat))
# Correct probability-flow schedule identity for common initial x and diagonal linear baseline.
bm=2.;sigT=3.;siglo=0.
VP=quad(lambda sg:sg/(1+sg*sg),siglo,sigT)[0];VE=quad(lambda sg:sg,siglo,sigT)[0]
vp=math.exp(-bm*VP);ve=math.exp(-bm*VE);R['schedule_factors']={'beta_mu':bm,'sigma_T':sigT,'VP':vp,'VE':ve,'a_T':1/math.sqrt(10)}
check('General schedule integral reduces to the VP signal-power factor',abs(vp-(1/math.sqrt(10))**bm)<1e-14)
check('VE constant force can suppress modes even though its signal a is identically one',abs(ve-math.exp(-9))<1e-14 and ve<1)
# VP p=1, correct terminal baseline law is N(0,I), exact integration.
aT=.01;mu=4.;b=1.;variance=math.exp(2*b*mu*math.log(aT));variance4=math.exp(2*b*(4*mu)*math.log(aT))
R['finite_coupling']={'a_T':aT,'positive_eigenvalue':mu,'multiplicity':6,'variance_per_mode':variance,'scaled_variance':variance4,'positive_spectrum_difference':variance-variance4,'expected_squared_agreement_residual':6*mu*variance,'hard_limit_variance':0.}
check('Finite constant-coupling output has strictly positive disagreement variance',variance>0)
check('Finite constant coupling is sensitive to positive spectrum even below a coarse audit tolerance',variance>variance4>0 and variance-variance4<1e-6)
check('A compatibility tolerance can hide positive variance without making support exactly compatible',0<6*mu*variance<1e-9)
# Corrected finite exact-Gaussian score, initialized from its noisy terminal marginal.
prec=np.array([1.,2.,5.,17.]);s2=1-aT*aT;start=aT*aT/prec+s2;factor=np.sqrt((1/prec)/start);out=factor**2*start
R['exact_gaussian_terminal']={'max_covariance_error':float(np.max(np.abs(out-1/prec))),'wrong_terminal_max_error':float(np.max(np.abs(factor**2-1/prec)))}
check('Exact Gaussian probability flow has its target covariance with a matched finite terminal law',np.max(np.abs(out-1/prec))<1e-14)
# Frame-independent energy interface, using per-edge Grams, not a choice of factor.
gram_grad=sum((b.T@b@z)*(math.tanh(np.linalg.norm(b@z))/np.linalg.norm(b@z)) for b in blocks(B,ne))
check('Nonlinear radial edge gradient is determined by per-edge Grams',np.linalg.norm(gram_grad-g,np.inf)<1e-12)

# Exact score of a tilted finite archive after Gaussian corruption.
Y=rng.normal(size=(9,4));prior=rng.uniform(.1,1,9);prior/=prior.sum();xx=rng.normal(size=4)
Bt=np.array([[-1.,1,0,0],[0,0,-1.,1]])
UY=np.array([energy(Bt,y,2) for y in Y]);beta=.7;a=.6;sn=.8
base_logits=np.log(prior)-np.sum((xx-a*Y)**2,axis=1)/(2*sn**2)
def soft(v):v=v-v.max();w=np.exp(v);return w/w.sum()
w0=soft(base_logits);wb=soft(base_logits-beta*UY)
score0=(a*(w0@Y)-xx)/sn**2;scoreb=(a*(wb@Y)-xx)/sn**2
# Scalar potential log E_0[exp(-beta U(Y)) | X=x].
def logsum(v):m=v.max();return m+math.log(np.exp(v-m).sum())
def tiltlog(x):
 q=np.log(prior)-np.sum((x-a*Y)**2,axis=1)/(2*sn**2)
 return logsum(q-beta*UY)-logsum(q)
h=1e-5;dg=np.array([(tiltlog(xx+h*e)-tiltlog(xx-h*e))/(2*h) for e in np.eye(4)])
err=float(np.max(np.abs(dg-(scoreb-score0))));R['tilted_score']={'gradient_identity_error':err,'clean_force_discrepancy':float(np.linalg.norm((scoreb-score0)+beta*grad_energy(Bt,xx,2)))}
check('Noised tilted-law score correction is the gradient of a posterior reweighting potential',err<1e-9)
check('Direct clean nonlinear force differs from the correctly noised score correction',R['tilted_score']['clean_force_discrepancy']>.01)
Ct=np.linalg.inv(np.eye(4)+beta*Bt.T@Bt);correct=-(np.linalg.inv(a*a*Ct+sn*sn*np.eye(4))-np.eye(4)/(a*a+sn*sn))@xx
postb=a*Ct@np.linalg.solve(a*a*Ct+sn*sn*np.eye(4),xx);post0=a*xx/(a*a+sn*sn)
check('Gaussian quadratic tilt agrees with its covariance-based noised score correction',np.linalg.norm(correct-a*(postb-post0)/sn**2)<1e-12)
R['checks']=tests;R['check_count']=len(tests);R['all_pass']=all(t['passed'] for t in tests)
(P/'revision_results.json').write_text(json.dumps(R,indent=2)+'\n')
for t in tests:print(('PASS ' if t['passed'] else 'FAIL ')+t['name'])
assert R['all_pass']
