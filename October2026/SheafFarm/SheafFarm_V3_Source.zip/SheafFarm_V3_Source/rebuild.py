from pathlib import Path
import subprocess,sys,json,hashlib,shutil
P=Path(__file__).resolve().parent
for script in ['legacy_checks.py','revision_checks.py','cs_validate.py']:
 subprocess.run([sys.executable,script],cwd=P,check=True)
shutil.copyfile(P/'legacy_results.json',P/'results.json')
for script in ['audit_v3.py','figures.py','render.py','build.py','add_review_comments.py','verify.py']:
 subprocess.run([sys.executable,script],cwd=P,check=True)
for fn in ['legacy_results.json','revision_results.json']:
 assert json.loads((P/fn).read_text())['all_pass']
before={fn:hashlib.sha256((P/fn).read_bytes()).hexdigest() for fn in ['legacy_results.json','revision_results.json']}
for script in ['legacy_checks.py','revision_checks.py']:subprocess.run([sys.executable,script],cwd=P,check=True,stdout=subprocess.DEVNULL)
after={fn:hashlib.sha256((P/fn).read_bytes()).hexdigest() for fn in before}
assert before==after
(P/'reproducibility.json').write_text(json.dumps({'same_runtime_byte_identical_results':True,'sha256':after,'legacy_checks':39,'revision_checks':23,'all_pass':True},indent=2)+'\n')
