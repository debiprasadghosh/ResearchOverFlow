"""Apply local mathematical revisions to the regenerated V2 text."""
from pathlib import Path
import json,re
P=Path(__file__).resolve().parent
s=(P/'paper.md').read_text();r=json.loads((P/'revision_results.json').read_text());leg=json.loads((P/'legacy_results.json').read_text());cs=json.loads((P/'cs_validate.json').read_text())
def sci(x):
 a,b=f'{x:.2e}'.split('e');return '$'+a+r'\times10^{'+str(int(b))+'}$'
def replace_section(start,end,new):
 global s
 a=s.index(start);b=s.index(end,a);s=s[:a]+new.strip()+'\n\n'+s[b:]
def after_para(anchor,new):
 global s
 a=s.index(anchor);b=s.index('\n\n',a);s=s[:b]+'\n\n'+new.strip()+s[b:]
s=s.replace('Distinguishing operator, geometry, compatibility and generative law. Version 2','Distinguishing operator geometry compatibility and generative law')
s=s.replace('date: 20 October 2026 · Version 2','date: 20 October 2026 · Version 3')
abstract=r'''## Abstract

Sheaf diffusion can use a restriction diagram, its Laplacian, its compatible subspace, or a probability law on that subspace. These interfaces retain different information. We organise their comparison through typed structural obligations, with explicit separation examples and constructive updates. Equal vertex Laplacians identify a coboundary only up to an isometry on its observed edge image. General invertible scalar sheaves on the complete graph on four vertices admit a two-dimensional Gram fibre with changing holonomy; an exact rational Jacobian and tangent witness establish this locally. However, on a simple graph a standard orthogonal connection Laplacian already determines every edge transport. Edge resolution therefore supplies extra information only relative to a declared map family. Radial edge message passing is gradient descent on a convex log-cosh agreement energy, with frame covariance, section preservation and an explicit step-size bound. Hard agreement can discard positive spectral information and become discontinuous near trivial holonomy. The cycle half-amplitude depth scales as $n^2/\varepsilon^2$, but it is a damping time, not a general detection lower bound. For generative diffusion, a constant clean force under a variance-preserving schedule scales a disagreement mode by $a_T^{\beta\mu}$. At finite signal cutoff this is positive; exact collapse occurs only in the limit. We derive the general schedule integral and the correct score of an energy-tilted clean law through posterior reweighting. The revised SheafFarm audit separates finite and limiting constructions, marginal and joint laws, and empirical probes from universal guarantees. It supplies no common quality score or global winner. All 39 legacy checks reproduce, and 23 additional checks pass. The resulting engineering question is which information is available, which identities are enforced, and which target law is actually sampled.'''
replace_section('## Abstract','**Keywords:**',abstract)
replace_section('## 1.1 What Version 2 adds','The underlying sheaf and spectral facts',r'''## 1.1 Results and scope of this revision

This revision retains the Gram fibre, frame, naturality and probability distinctions, while making their domains explicit. Theorem 3.7 identifies the important simple-graph orthogonal case in which the Laplacian loses no transport information. Theorem 4.4 supplies a convex nonlinear edge energy and its descent guarantee. Proposition 6.5 is proved using a complex twisted Fourier basis, which also covers reflective holonomy on even cycles. Corollary 6.6 remains an exact damping calculation; it does not imply an inability to distinguish two finite operators. Proposition 7.2 now assumes a variance-preserving schedule and distinguishes finite suppression from an infinite-noise hard limit. Proposition 7.3 gives the general schedule formula, and Theorem 7.4 derives the correctly noised score of an energy tilt.

Section 9 replaces a global ordering of unlike certificates by a typed audit. Constant-sheaf heat is assessed against the supplied nonidentity system, rather than declared intrinsically invalid. Marginal preservation and joint target fidelity have separate columns. A residual below tolerance is recorded as approximate agreement, never as proof of exact support. Source material and numerical records are retained with the revision.''')
s=s.replace('how cycle length hides holonomy, and how a rank policy restores continuity','how cycle length slows damping, and how a rank policy restores local continuity')
s=s.replace('shows that a constant coupling force collapses to the hard law','distinguishes finite constant-force suppression from its hard limit and derives the correctly noised energy tilt')
s=s.replace('Section 9 runs the comparison as an executable certificate audit.','Section 9 audits the resulting reference constructions with their types and limits declared.')
s=s.replace('Theorem 3.1 therefore has an exact converse description. A Laplacian-only algorithm identifies the coboundary up to the group of all isometries of edge coordinates. Over a fixed graph with whitened edge metrics, the sheaf itself is determined only up to the smaller group of edge-local isometries $U=\\oplus_eU_e$, which act on each edge space separately. The difference between these two groups is precisely what Laplacian-only algorithms cannot see.',r'''Theorem 3.1 therefore has an exact description of its observation fibre. If the edge dimensions are supplied and fixed, the common Gram identifies the whitened coboundary up to a global orthogonal map on comparison coordinates. If edge dimensions are not supplied, it identifies only the observed image: unused comparison directions remain invisible, as Example 3.2 shows. A global orthogonal map need not preserve edge blocks or incidence sparsity. Edge-local orthogonal changes are one family of sheaf isomorphisms, but arbitrary sheaf isomorphisms may also change vertex frames and need not be isometries. Thus the comparison is between metric diagrams in fixed vertex coordinates, rather than a classification of all abstract sheaves by two groups.''')
s=s.replace('Suppose an algorithm receives the edge Grams $L_e=B_e^\\top B_e$ for every edge, rather than only their sum $L$.','Suppose the vertex and edge dimensions, graph incidences and whitened metrics are declared, and an algorithm receives the edge Grams $L_e=B_e^\\top B_e$ for every edge, rather than only their sum $L$.')
s=s.replace('Whenever the head restriction is invertible, the transport',r'Whenever the head restriction is square and invertible, the transport')
# Turn the K4 regularity evidence into an exact local proof.
s=s.replace('**Proposition 3.6 --- On simple graphs with more edges than vertices, one Laplacian hides a continuum.**','**Proposition 3.6 --- Dimension of a regular Gram fibre for general scalar restrictions.**')
s=s.replace('On the complete graph $K_4$, with $|E|=6$ and $|V|=4$, the Jacobian has rank 10, so the fibre is two-dimensional. Along it the triangle holonomies change continuously. On a single cycle, $|E|=|V|$; for the tested 5-cycle the Jacobian has full rank 10, so the fibre is discrete there.',r'''At the recorded $K_4$ point the Jacobian has rank ten, so the local fibre is two-dimensional and triangle holonomy varies on it. This is an existence statement for general nonzero scalar restrictions. It does not assert that every positive-dimensional fibre has varying holonomy or that every cycle fibre is discrete. For the tested regular five-cycle the numerical Jacobian has full rank ten, giving an isolated local fibre at that point.''')
s=s.replace('The $K_4$ and 5-cycle statements are exact rank computations, and the holonomy variation along the $K_4$ fibre is computed in the companion script.',r'''For an exact $K_4$ witness, order the edges as $01,02,03,12,13,23$ and take the endpoint restrictions to be $t/10$, with $t=(12,8,9,15,11,7,13,10,6,14,16,9)$. Use the four sums of squared incident endpoint values and the six endpoint products as outputs. In $t$ coordinates a ten-column Jacobian minor, with one-based columns $1,2,3,4,5,6,7,8,9,11$, has determinant 489692044800. Hence the rank is ten locally. In the exact nullspace basis obtained by row reduction, the direction with free coordinate $t_{10}=1$ and $t_{12}=0$ has derivative $-264949/347004$ for $\log h_{012}$. The derivative is nonzero, so holonomy is nonconstant on this smooth local fibre. The five-cycle claim is only the reported numerical regular-point computation.''')
new3=r'''**Theorem 3.7 — Orthogonal connection transport is identifiable on a simple graph.** Suppose a known simple graph carries $d$-dimensional orthogonal incidence maps $A_e,C_e$ and a positive scalar edge weight $w_e$. Write its whitened residual on $e:v\to w$ as $\sqrt{w_e}(C_ex_w-A_ex_v)$. In fixed calibrated vertex coordinates, the off-diagonal block of the unnormalised Laplacian determines both weight and transport:

$$L_{vw}=-w_eA_e^\top C_e,\qquad w_e=\frac{\|L_{vw}\|_F}{\sqrt d},\qquad T_e=C_e^\top A_e=-\frac{L_{wv}}{w_e}. \tag{31}$$

It therefore determines all cycle transports, and the full incidence pair up to an orthogonal change of the edge comparison frame.

*Proof.* A simple graph has at most one edge contributing to the block $L_{vw}$. Its contribution is the stated product. An orthogonal matrix has Frobenius norm $\sqrt d$, giving the weight; transposition then recovers $T_e$. The pair $(A_e,C_e)$ is equivalent under the edge frame $C_e^\top$ to $(T_e,I)$. Products along oriented paths recover holonomy. $\square$

The restrictions in Proposition 3.6 are not orthogonal, so there is no contradiction. Parallel edges can cancel in an off-diagonal block. Matrix-valued edge metrics and rectangular restrictions also fall outside the theorem. A normalised Laplacian alone is not automatically the unnormalised one: its normalisation convention and any required degree factors must be supplied. On the stated orthogonal family, however, an edge energy can be reconstructed from $L$ and the graph. Computing per edge can still aid implementation, sparsity and calibration; it adds no information at this interface. The label E in Section 9 is consequently indexed by an admissible family, not an intrinsic property of an algorithm name.'''
after_para('![**Figure 2.**',new3)
new4=r'''**Theorem 4.4 — A convex nonlinear edge update with a descent certificate.** For fixed whitened edge blocks $B_e$, set $r_e=\|B_ex\|$, and interpret $\tanh r_e/r_e$ as one at zero. The original radial edge update is gradient descent on

$$\mathcal E(x)=\sum_e\log\cosh\|B_ex\|,\qquad g(x)=\nabla\mathcal E(x)=\sum_e B_e^\top B_ex\frac{\tanh r_e}{r_e}. \tag{32}$$

The energy is convex, its minimisers are exactly $\ker B$, and its gradient is Lipschitz with constant at most $M=\|B^\top B\|_2$. When $M>0$ and $0<\alpha<2/M$, the update $x^+=x-\alpha g(x)$ satisfies

$$\mathcal E(x^+)\le\mathcal E(x)-\alpha(1-\alpha M/2)\|g(x)\|^2. \tag{33}$$

Every compatible input is fixed, including for partial or nonorthogonal restrictions. Under orthogonal changes of vertex and edge frames, the complete update is covariant. It is determined by the individual edge Grams $L_e$, because $r_e^2=x^\top L_ex$.

*Proof.* For $f(u)=\log\cosh\|u\|$, radial differentiation gives gradient $u\tanh r/r$. The radial Hessian eigenvalue is $\operatorname{sech}^2r$ and each tangential one is $\tanh r/r$; both lie in $[0,1]$, with limit one at zero. Hence $0\preceq\nabla^2\mathcal E(x)\preceq\sum_eB_e^\top B_e=L$. The descent lemma proves (33). Every term is nonnegative and vanishes exactly when its residual vanishes. Orthogonal edge frames preserve residual norms, and vertex frames conjugate the gradient. $\square$

This is an energy-based reference member of the existing nonlinear sheaf diffusion family, not a priority claim for nonlinear sheaf energies [14]. It strengthens the Section 9 radial edge example by exposing its objective and step-size condition. A state-dependent learned restriction family changes the energy derivative: the derivatives of those restrictions must be included to retain this interpretation. Covariance likewise requires the map learner, scalings, nonlinearities and decoder to transform consistently. Theorem 4.4 concerns fixed maps, and it does not turn an arbitrary learned update into a gradient method.'''
after_para('The radial layer with',new4)
s=s.replace('## 6.3 Longer cycles hide holonomy, and a rank policy restores continuity','## 6.3 Cycle length controls damping and a rank policy gives local stability')
s=s.replace('*Proof.* Local frames distribute the holonomy as $H^{1/n}$ on every edge, which conjugates $L$ without changing its spectrum. In the eigenbasis of $H$ the operator becomes $d$ scalar circulants with twist $e^{i\\theta_j/n}$, whose Fourier modes give (21). Theorem 6.3 is the case $n=3$. ▫',r'''*Proof.* Gauge all but the closing edge to identity, complexify the vertex spaces, and diagonalise the orthogonal holonomy as a unitary matrix. For an eigenvector with eigenvalue $e^{i\theta_j}$, the resulting scalar sequence has a twisted periodic boundary condition. Its Fourier frequencies are $(\theta_j+2\pi k)/n$, up to an orientation sign that permutes the spectral multiset. Applying the cycle difference operator gives (21). Complexification preserves the real eigenvalue multiplicities. This proof needs no real orthogonal $n$th root of $H$: such a root need not exist when $n$ is even and $\det H=-1$. $\square$''')
s=s.replace('**Corollary 6.6 --- Depth needed to see holonomy.**','**Corollary 6.6 --- Half-amplitude damping depth.**')
s=s.replace('with $0<\\alpha\\lambda_{\\max}\\le1$, the slowest mode loses half its amplitude only after','with $0<|\\varepsilon|<\\pi$ and $0<\\alpha\\lambda_{\\max}\\le1$, the slowest eigenmode first reaches at most half its initial amplitude after')
s=s.replace('layers. Before then, the system is within a factor of two of a flat one along that mode.','layers. This is a statement about one eigenmode of the nonflat operator. It does not compare arbitrary inputs under two different operators.')
s=s.replace('A sheaf network of a few dozen layers therefore cannot tell small holonomy from none on a long cycle through diffusion alone. If holonomy matters to a task, it must enter through an interface that reads it directly, such as the edge-resolved one.',r'''This does not prohibit detecting holonomy at smaller depth. For any known finite $t>0$, exact knowledge of the full positive-definite heat operator determines $L=-t^{-1}\log(e^{-tL})$. Finite observations, noise and selected readouts can make this inversion difficult, but a detection lower bound must specify those restrictions. The half-amplitude law alone supplies no such bound.''')
s=s.replace('**Proposition 6.7 --- A rank threshold restores continuity.**','**Proposition 6.7 --- A rank threshold gives stability inside a reference gap.**')
s=s.replace('The threshold declares near-flat systems flat.',r'The threshold retains a near-compatible spectral subspace; it does not make that subspace the exact kernel of the perturbed restrictions.')
new6=r'''**Proposition 6.8 — Finite heat can respond at first order.** On the rotation triangle with the changing rotation confined to one edge,

$$\|L_\varepsilon-L_0\|_2=2|\sin(\varepsilon/2)|,\qquad \|e^{-tL_\varepsilon}-e^{-tL_0}\|_2\le2t|\sin(\varepsilon/2)|. \tag{34}$$

The smallest eigenvalue changes quadratically, but this does not force the full heat operator to change only quadratically.

*Proof.* The changed Laplacian consists of the two off-diagonal blocks $-(R_\varepsilon-I)$ and their transposes. Its norm is $\|R_\varepsilon-I\|_2=2|\sin(\varepsilon/2)|$. The Duhamel bound (19) gives the second inequality. For the final distinction, $L'_0\ne0$, and the Fréchet derivative of the heat map is $-\int_0^t e^{-(t-u)L_0}L'_0e^{-uL_0}\,du$. In an eigenbasis of $L_0$, each entry of $L'_0$ is multiplied by a strictly positive integral, so this derivative is nonzero. $\square$

At $t=0.5$, the computed operator difference divided by $|\varepsilon|$ approaches {{heat_ratio}} over $\varepsilon=10^{-3},10^{-4},10^{-5}$. This illustrates the distinction between first-order operator response and second-order slow-mode damping. Proposition 6.7 remains a local theorem around a declared reference gap; once an eigenvalue crosses the threshold, rank can change again.'''
after_para('![**Figure 4.**',new6)
# Replace the probability-flow statement, keeping its original numbered formula.
replace_section('**Proposition 7.2','![**Figure 5.**',r'''**Proposition 7.2 — Constant force under a variance-preserving schedule.** Let $X=aY+s\epsilon$ with $a^2+s^2=1$, $a>0$, and let the centred Gaussian baseline covariance commute with $L$. Compare two continuous probability flows with the same initial state at $a_T>0$: one uses the baseline noisy score and the other adds $-\beta Lx$ at every noise level. Along a common eigenvector with Laplacian eigenvalue $\mu$, their endpoint coordinates have ratio

$$a_T^{\beta\mu}. \tag{28}$$

For the isotropic baseline $Y\sim\mathcal N(0,p^{-1}I)$, a correctly initialised baseline flow ends with standard deviation $p^{-1/2}$. The desired soft target $\mathcal N(0,(pI+\beta L)^{-1})$ instead requires a clean mode scale ratio $\sqrt{p/(p+\beta\mu)}$. These are different laws.

*Proof.* Set $z=x/a$ and $\sigma=s/a$. In the deterministic DDIM continuum, $dz/d\sigma=-s\nabla\log p(az)$. The added force contributes $\beta\mu asz$. Both linear drifts are diagonal in the same basis. Under the stated variance-preserving schedule, $as=\sigma/(1+\sigma^2)$. Integrating from $\sigma_T$ down to zero multiplies the mode by $\exp[-\beta\mu\log(1+\sigma_T^2)/2]=a_T^{\beta\mu}$. $\square$

For every finite $a_T>0$ and finite coupling, this factor is positive. An initially nondegenerate Gaussian retains positive disagreement variance. It is not exactly supported on $\ker L$, and it still depends on positive eigenvalues. Only as $a_T\to0$, with correctly matched baseline terminal marginals, does the output converge to the baseline law projected onto $\ker L$. This is a limiting hard law. Starting all finite-cutoff flows from an approximate standard Gaussian introduces a separate terminal mismatch when the baseline noisy covariance is not identity.

For the recorded $p=1$ example, $a_T=0.01$ and $\beta\mu=4$ give a mode scale $10^{-8}$ rather than $1/\sqrt5\approx0.447$. The 80,000-step deterministic DDIM simulations approximate (28) with maximum relative error {{legacy_cc}}. Large suppression can look like exact compatibility under a coarse tolerance. Section 9 reports that distinction explicitly.''')
s=s.replace('**Figure 5.** Output scale','**Figure 5.** Finite-cutoff output scale')
new7=r'''**Proposition 7.3 — The suppression factor depends on the corruption schedule.** Let $\sigma=s/a$ parametrise a corruption family with $a(\sigma)>0$, and retain the commuting linear Gaussian baseline of Proposition 7.2. Between $\sigma_T$ and $\sigma_0$, adding $-\beta Lx$ multiplies a mode relative to its baseline flow by

$$\exp\left(\beta\mu\int_{\sigma_T}^{\sigma_0}\sigma a(\sigma)^2\,d\sigma\right). \tag{35}$$

*Proof.* In the same clean coordinates the added drift is $\beta\mu asz=\beta\mu\sigma a^2z$. The scalar linear equation integrates to (35). $\square$

For variance-preserving corruption this gives (28). For variance-exploding corruption with $a\equiv1$ it gives $\exp[\beta\mu(s_0^2-s_T^2)/2]$, even though the signal coefficient never changes. Thus the power of $a_T$ is not a schedule-independent sheaf invariant. Commutation matters as well: noncommuting time-dependent linear drifts require a matrix evolution, not independent scalar factors.

**Theorem 7.4 — An energy-tilted target needs posterior reweighting.** Let a baseline clean law $P_0$ and nonnegative energy $U$ define $dP_\beta(y)=Z_\beta^{-1}e^{-\beta U(y)}dP_0(y)$ with $0<Z_\beta<\infty$. At a fixed positive Gaussian noise level, write $p_{0,t}$ and $p_{\beta,t}$ for the two noisy densities. Assuming finite first moments and differentiation under the Gaussian integral, their exact score correction is

$$\nabla\log p_{\beta,t}(x)-\nabla\log p_{0,t}(x)=\nabla\log\mathbb E_0[e^{-\beta U(Y)}\mid X_t=x]=\frac{a_t}{s_t^2}(m_{\beta,t}(x)-m_{0,t}(x)). \tag{36}$$

Here $m_{\beta,t}$ is obtained by reweighting the baseline clean posterior by $e^{-\beta U(Y)}$ and normalising.

*Proof.* Multiplying the baseline joint law of $(Y,X_t)$ by $e^{-\beta U(Y)}/Z_\beta$ gives $p_{\beta,t}(x)=p_{0,t}(x)\mathbb E_0[e^{-\beta U(Y)}\mid X_t=x]/Z_\beta$. Take a logarithmic gradient. Differentiating the Gaussian kernel yields each score as $(a_tm_t(x)-x)/s_t^2$, proving the last identity. $\square$

For a finite archive this reweighting is an exact finite sum. For a factorised compositional support it may require the inference machinery of Section 7.3. Choosing $U=\mathcal E$ from Theorem 4.4 gives a legitimate nonlinear sheaf-coupled clean law. Its noisy force is the posterior expression (36), generally not $-\beta\nabla\mathcal E(x)$. The latter is a clean-energy gradient evaluated at a noisy state. In the Gaussian quadratic case, (36) reduces to the difference of the two correctly noised precision operators. An exact score still leaves finite reverse integration and endpoint policy to be specified. The construction extends a standard Gaussian posterior identity [4–6]; it makes no claim that local computation is automatically exact or cheap.'''
after_para('A model using sheaf message passing inside a denoiser',new7)
# Replace the cross-type global ranking by a typed audit.
sec9=r'''# 9 SheafFarm as a typed audit

An executable probe can refute a universal identity by one counterexample. Passing a finite collection of probes cannot prove that identity for every admissible input. This distinction applies to frame covariance and section preservation. For the reference functions below, universal claims come from their formulas and proofs; numerical probes test those implementations on declared instances. They are not certifications of trained NSD or DNSD checkpoints.

The original test bed remains: a general scalar $K_4$ pair with equal $L$ and different holonomy; a flat planar orthogonal system and a vertex-frame change; and scaling its restrictions by two, which replaces $L$ by $4L$ without changing its kernel. E means separation on the general scalar family. It is not an orthogonal simple-graph identifiability test, because Theorem 3.7 rules that ambiguity out. The constant-sheaf control ignores the supplied nonidentity transports. Its failed frame or section test is relative to that supplied system; ordinary constant-sheaf heat retains its valid sheaf interpretation on its own declared system.

Table: **Table 4.** Obligations and the evidence each requires.

| Symbol | Meaning at the declared interface | Evidence and scope |
|:--|:--|:--|
| E | Can distinguish the general scalar same-Gram pair | A separating input suffices; Theorem 3.1 proves failure for an $L$-only function |
| S | Depends on positive spectrum, beyond the kernel | Compare $L$ and $4L$; an exact zero differs from an effect below a tolerance |
| F | Orthogonal frame covariance of the whole reference function | Formula and proof, checked on a frame transform |
| P | Sends compatible deterministic inputs to compatible outputs | Formula and proof; one passing input alone is insufficient |
| C | Has exactly compatible output support | Operator range or covariance support, rather than a small rounded residual |
| Qm | Preserves the stated baseline marginal law | Conditional innovation argument and a marginal-law check |
| Qj | Produces the stated joint clean target | Matched forward law, noisy score, initial law and reverse limit |

Table: **Table 5.** Scoped reference properties. Y denotes an established property for the stated formula, N an absent property or a counterexample, and a dash an inapplicable or unclaimed obligation. The constant-force finite row is its continuous probability-flow formula at positive cutoff. Exact joint-law rows assume their declared terminal marginals and an exact reverse construction. This is not a performance table.

| Reference construction | E | S | F | P | C | Qm | Qj |
|:--|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| Constant heat against supplied maps | N | N | N | N | N | – | – |
| Frozen sheaf heat | N | Y | Y | Y | N | – | – |
| Sheaf resolvent | N | Y | Y | Y | N | – | – |
| Exact-kernel projector | N | N | Y | Y | Y | – | – |
| Sheaf ReLU layer | N | Y | N | N | N | – | – |
| Shared radial vertex layer | N | Y | Y | Y | N | – | – |
| Radial edge-gradient step | Y | Y | Y | Y | N | – | – |
| Correlated baseline noise | N | Y | Y | – | N | Y | – |
| Exact soft Gaussian target | N | Y | Y | – | N | – | Y |
| Constant force finite cutoff | N | Y | Y | – | N | – | N |
| Constant force hard limit | N | N | Y | – | Y | – | N |
| Intrinsic compatible sampler | N | N | Y | – | Y | – | Y |

The finite constant-force output is the clearest correction to the original threshold-based table. On the flat $K_4$ connection the positive Laplacian eigenvalue is four, with multiplicity six. With $p=\beta=1$ and $a_T=0.01$, its disagreement variance per mode is {{finite_var}}, its expected squared residual is {{finite_res}}, and replacing $L$ by $4L$ changes a mode variance by {{finite_diff}}. All are positive, although the latter two can fall below the original audit tolerances. A dense floating-point covariance may round away that variance when it is added to order-one compatible components. The mode representation exposes it without subtraction. Calling this exactly compatible or spectrally insensitive confuses numerical resolution with the mathematical law.

The hard-limit row is a different construction and a different order of limits. Its Qj entry is N because it is being judged against the advertised soft target. The intrinsic row has Qj equal to Y because it explicitly declares an intrinsic hard target. Correlated noise has a marginal preservation claim, not the same joint target as either row. Consequently these seven columns must not be pooled into one cross-task inclusion score. Even a genuine partial order of sets needs a fixed interface, common admissible family and common meaning for each obligation. Treating a dash as a failed certificate would create artificial comparisons.

Within a fixed deterministic interface, certificate inclusion can still organise proved properties. For example the radial edge-gradient retains a same-Gram separation that frozen heat lacks on the general scalar family. It is not automatically better on an orthogonal simple graph, where those transports are already recoverable from $L$. No single winner follows from the global table, and no experiment here ranks trained models by task accuracy.

![**Figure 6.** Left: scoped properties of the twelve reference constructions from Table 5, with marginal and joint laws separated. Right: positive finite-cutoff disagreement variance under constant force, shown in eigenmodes rather than rounded dense covariance. The horizontal line marks the original numerical agreement threshold; crossing it does not create exact support. Hard collapse is a limit, not a threshold crossing.](fig/farm_v3.png){width=100%}

## 9.1 Structural dependence and task value require different tests

Liu [13] separates map movement during training, fixed-checkpoint reliance, and value that remains after matched retraining. Those distinctions complement this paper’s observation interfaces. A changed output on a Gram fibre establishes access to additional information. It does not establish that a task needs that information or that a retrained control cannot replace its effect. Published checkpoint and retraining results are external evidence; they are not runs of SheafFarm.

A practical protocol should lock the structural intervention, report the fixed-checkpoint change, then retrain controls under paired splits and a declared budget. Include identity maps, a shared map or parameter-matched channel adapter, and controls that disrupt persistent edge assignment. Reserve necessity language for the tested control suite and protocol. The present deterministic checks establish neither learned-model accuracy nor a universal advantage of nontrivial sheaves.'''
replace_section('# 9 SheafFarm:', '# 10 An engineering evaluation',sec9)
s=s.replace('**P2 --- Finite operator sensitivity survives a kernel match.**','**P2 --- Finite operator sensitivity survives a kernel match.**')
s=s.replace('the retained dimension of an exact-kernel model should change, and that of a thresholded model should not, as long as the perturbation stays below', 'the exact mathematical kernel dimension can change while a thresholded retained dimension remains stable, as long as the perturbation from the declared reference stays below')
s=s.replace('every Laplacian-only model is at chance by Theorem 3.1. An edge-resolved model can exceed chance.',r'a balanced label assigned to the two members is independent of the common $L$, so a model receiving only that interface is at chance in population by Theorem 3.1. An edge-resolved model can exceed chance if the distinguishing information is learnable. A finite test sample can exceed chance by fluctuation; repeated, statistically resolved above-chance performance calls for an information-leakage check.')
s=s.replace('a Laplacian-only model above chance refutes the implementation claim, because it must be using other information.',r'interpret the result against an interval for chance and audit any additional metadata or training leakage.')
s=s.replace('for an arc length of 0.6','for a cumulative predictor step of 0.6').replace('longer cycles hide holonomy quadratically','longer cycles slow the smallest-mode damping quadratically')
# Add a domain restriction to the relevant proposed Gram-fibre experiment.
s=s.replace('**P5 --- Edge-resolved information matters exactly where the Laplacian is silent.** On labelled pairs',r'**P5 --- Edge-resolved information can matter on a declared Gram fibre.** Restrict this test to general nonorthogonal scalar maps; Theorem 3.7 excludes the same ambiguity for standard orthogonal maps on simple graphs. On labelled pairs')
checks=r'''## 10.1 Reproducible mathematical checks

The 39 legacy checks reproduce in this runtime. They include the original coarse numerical audit and its set bookkeeping. Reproducing those thresholds is a replication result, not an endorsement of the universal or exact interpretations corrected in Section 9. The revision adds {{new_count}} independent checks, all passing, for a total of {{total_count}} recorded checks. The result files separate the two groups.

The added checks cover exact rational regularity and holonomy variation, transport and weight recovery, a parallel-edge boundary example, the nonlinear energy gradient and descent bound, full frame covariance, preservation under partial restrictions, reflective cycle spectrum, first-order finite heat response, VP and VE schedule factors, positive finite-cutoff disagreement variance, finite terminal-law matching, and correctly noised energy-tilt scores.

Table: **Table 3.** Selected evidence from the current result files. Residuals illustrate the proofs; they are not learned-model benchmarks.

| Statement | Computation | Result |
|:--|:--|:--|
| Proposition 3.6 | Exact rational Jacobian rank and nonzero minor | 10; 489692044800 |
| Theorem 3.7 | Largest transport and weight recovery errors | {{rec_err}}; {{weight_err}} |
| Theorem 4.4 | Gradient check against centred differences | {{grad_err}} |
| Theorem 4.4 | Vertex and edge frame covariance defect | {{frame_err}} |
| Theorem 4.4 | Energy before and after certified update | {{energy_before}} to {{energy_after}} |
| Proposition 6.5 | Reflection on an even cycle, spectrum error | {{reflection_err}} |
| Proposition 6.8 | Finite heat difference divided by angle | {{heat_ratio}} at $t=0.5$ |
| Proposition 7.3 | VP and VE factors at $\beta\mu=2$, $\sigma_T=3$ | {{vp_factor}}; {{ve_factor}} |
| Proposition 7.2 | Positive finite-cutoff disagreement variance | {{finite_var}} |
| Theorem 7.4 | Posterior-tilt score identity finite-difference error | {{tilt_err}} |
| C# reference | Archived output rechecked against current NumPy | 13 of 13 lines; {{cs_error}} maximum scaled error |

The C# output belongs to the supplied V2 .NET run. This revision independently recomputes all thirteen recorded lines with NumPy; it does not count a fresh C# compilation. The immutable kernel remains in Appendix A and the source package. Its coupling-factor routine has the variance-preserving assumptions of Proposition 7.2. Current Python checks use fixed seeds and record package versions. Repeated runs in this runtime reproduce the result files byte for byte; floating-point residuals may differ across libraries or platforms. The mathematical statements are supported by their proofs and explicit hypotheses.'''
replace_section('## 10.1 Small mathematical checks','# 11 What should count',checks)
old=s[s.index('Version 2 adds a positive side'):s.index('# References')]
s=s.replace(old,r'''The constructive conclusion is conditional on the interface, rather than on a name. General restrictions can carry edge information hidden by their summed Gram, whereas standard orthogonal transports on a simple graph can already be recovered from it. A convex nonlinear edge energy gives a controlled update. A thresholded low-energy subspace gives local stability without claiming exact compatibility. A generative energy tilt needs its posterior correction after corruption, and finite constant force must be distinguished from its limiting hard law. These are concrete implementation choices that can be tested separately.

''')
refs=r'''\[13\] Liu, Y. (2026). Learned, Relied Upon, or Necessary? Separating Checkpoint Dependence from Task-Level Value in Sheaf GNNs. arXiv:2607.25387v2, 31 July 2026. https://arxiv.org/pdf/2607.25387

\[14\] Zaghen, O., Longa, A., Azzolin, S., Telyatnikov, L., Passerini, A. and Liò, P. (2024). Sheaf Diffusion Goes Nonlinear: Enhancing GNNs with Adaptive Sheaf Laplacians. *Proceedings of Machine Learning Research* 251, 264–276. https://proceedings.mlr.press/v251/zaghen24a.html'''
after_para(r'\[12\] Davis',refs)
# Scope and provenance of the retained code listing.
a=s.index('The kernel implements typed restrictions');b=s.index('\n\n',a)
s=s[:a]+r'''The retained immutable C# kernel implements the typed restriction and edge-Gram interfaces, the cycle spectrum formula, a thresholded projector, radial vertex layers and the VP constant-force factor. It uses immutable records, `ImmutableArray<double>` and pure static functions; the Jacobi eigensolver works on private copies. The thirteen-line output recorded in the supplied V2 package is independently recomputed in this revision. The current comparison is an archived-output recheck, not a fresh compiler run. Its maximum scaled difference is {{cs_error}}, using $|c-p|/\max(1,|p|)$, so small values are compared by absolute error. The full executable sources and provenance are supplied alongside the manuscript. The new nonlinear edge-energy and tilted-law checks are implemented in Python.'''+s[b:]
s=s.replace('The largest relative difference is','The largest scaled difference is')

# Keep the evaluation protocol consistent with the corrected damping theorem.
a=s.index('**P7 ---');b=s.index('\n\n',a)
s=s[:a]+r'''**P7 — Measure damping and detection separately.** On each rotation cycle, measure the amplitude of a known slow eigenmode and compare it with (23). In a separate detection experiment, declare the input distribution, observation operator, measurement noise and precision, then compare finite heat responses under flat and nonflat maps. Proposition 6.8 permits a first-order response well before half-amplitude damping. Any claimed detection lower bound must be derived for that observation model; early separation alone is not evidence of information leakage.'''+s[b:]
s=s.replace('the numerical Jacobian has full rank ten, giving an isolated local fibre at that point','the numerical Jacobian has full rank ten, consistent with an isolated local fibre at that point')
a=s.index('![**Figure 6.**');b=s.index('\n\n',a)
s=s[:a]+r'''![**Figure 6.** Positive finite-cutoff disagreement under constant force on the flat planar $K_4$ connection, with $p=\beta=1$. The expected squared residual is $24a_T^8$. The dashed line shows the original $10^{-9}$ numerical agreement level for scale; falling below it does not establish exact support. The point at $a_T=0.01$ has residual $2.4\times10^{-15}$. The hard limit is approached as $a_T\to0$, rather than attained by crossing a positive threshold.](fig/farm_v3.png){width=82%}'''+s[b:]
# Tables follow their order of first appearance, including retained captions.
oldtables=re.findall(r'Table: \*\*Table (\d+)\.',s)
tablemap={old:str(i+1) for i,old in enumerate(oldtables)}
s=re.sub(r'\bTable (\d+)\b',lambda m:'Table '+tablemap.get(m[1],m[1]),s)

# Read all inserted numerical quantities directly from the new result files.
values={'heat_ratio':f"{r['finite_detection'][-1]['difference_over_epsilon']:.6f}",'legacy_cc':f"{100*leg['v2']['constant_coupling']['max_relative_error']:.2f}%",'finite_var':sci(r['finite_coupling']['variance_per_mode']),'finite_res':sci(r['finite_coupling']['expected_squared_agreement_residual']),'finite_diff':sci(r['finite_coupling']['positive_spectrum_difference']),'new_count':r['check_count'],'total_count':r['check_count']+leg['counts']['total'],'rec_err':sci(r['orthogonal_recovery']['transport_error']),'weight_err':sci(r['orthogonal_recovery']['weight_error']),'grad_err':sci(r['nonlinear_energy']['gradient_error']),'frame_err':sci(r['nonlinear_energy']['frame_defect']),'energy_before':f"{r['nonlinear_energy']['energy_before']:.6f}",'energy_after':f"{r['nonlinear_energy']['energy_after']:.6f}",'reflection_err':sci(r['reflection_spectrum_error']),'vp_factor':f"{r['schedule_factors']['VP']:.6g}",'ve_factor':f"{r['schedule_factors']['VE']:.6g}",'tilt_err':sci(r['tilted_score']['gradient_identity_error']),'cs_error':sci(cs['max_relative_difference'])}
for k,v in values.items():s=s.replace('{{'+k+'}}',str(v))
assert '{{' not in s
# Normalize a handful of malformed math names inherited from the Word round-trip.
s=s.replace('kerB',r'\ker B').replace('kerL',r'\ker L').replace('ker\\delta',r'\ker\delta').replace('im\\delta',r'\operatorname{im}\delta').replace('dimC',r'\dim C').replace('rankL',r'\operatorname{rank}L')
s=s.replace(r'Cov\left',r'\operatorname{Cov}\left').replace(r'{blockdiag}_{v}',r'\operatorname{blockdiag}_{v}').replace(r'diag\left',r'\operatorname{diag}\left').replace(r'\nabla logp',r'\nabla\log p').replace(r'mathcal{\sim N}',r'sim\mathcal N').replace(r'\mathbb{= E}',r'=\mathbb E')
s=s.replace(r'\\ker',r'\ker')
s=s.replace('Largest relative difference','Largest scaled difference')
# Canonical equation numbering and matching numerical prose references.
nums=re.findall(r'\\tag\{(\d+)\}',s);assert len(nums)==len(set(nums))
mp={n:str(i+1) for i,n in enumerate(nums)}
s=re.sub(r'\\tag\{(\d+)\}',lambda m:r'\tag{'+mp[m[1]]+'}',s)
s=re.sub(r'(?<![\w.])\((\d+)\)',lambda m:'('+mp.get(m[1],m[1])+')',s)
(P/'equation_map_v3.json').write_text(json.dumps(mp,indent=2)+'\n')
(P/'paper.md').write_text(s)
print('V3 manuscript:',len(s.split()),'words;',len(nums),'numbered equations')
