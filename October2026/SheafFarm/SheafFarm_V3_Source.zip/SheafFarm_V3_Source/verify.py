from pathlib import Path
from zipfile import ZipFile
from lxml import etree
from urllib.parse import unquote
import posixpath,json,re,hashlib
P=Path(__file__).resolve().parent;f=P/'output/SheafFarm_V3.docx'
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
with ZipFile(f) as z:
 assert z.testzip() is None
 names=set(z.namelist());parts={n:etree.fromstring(z.read(n)) for n in names if n.endswith(('.xml','.rels'))}
 for name,rt in parts.items():
  if not name.endswith('.rels'):continue
  base='' if name=='_rels/.rels' else posixpath.dirname(posixpath.dirname(name))
  for rel in rt:
   if rel.get('TargetMode')=='External':continue
   target=unquote(rel.get('Target','')).split('#')[0]
   resolved=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join(base,target))
   assert not target or resolved in names,(name,resolved)
 rt=parts['word/document.xml'];numbers=[]
 for p in rt.xpath('//w:p',namespaces=ns):
  if p.xpath('./w:pPr/w:pStyle/@w:val',namespaces=ns)==['Equation']:
   m=re.search(r'\((\d+)\)\s*$',''.join(p.xpath('.//w:t/text()',namespaces=ns)))
   if m:numbers.append(int(m[1]))
 assert numbers==list(range(1,37)),numbers
 mats=[]
 for m in rt.xpath('//m:m',namespaces=ns):
  rows=m.xpath('./m:mr',namespaces=ns);cols=[len(x.xpath('./m:e',namespaces=ns)) for x in rows]
  assert len(set(cols))==1; mats.append([len(rows),cols[0]])
 assert mats==[[1,2],[2,2],[2,2],[2,2],[2,2],[2,2]],mats
 text='\n'.join(rt.xpath('//w:t/text()',namespaces=ns))
 # Source-code backslashes are allowed; raw TeX outside native math is not.
 assert not re.search(r'\{\{|\(@|\\(?:begin|frac|mathbb|tag|ker|underset)\b',text)
 assert 'cannot see small holonomy' not in text
 assert '¿' not in ''.join(rt.xpath('//m:t/text()',namespaces=ns))
 tabs=rt.xpath('//w:tbl',namespaces=ns);assert len(tabs)==7
 for t in tabs:
  assert t.xpath('./w:tr[1]/w:trPr/w:tblHeader',namespaces=ns)
  assert set(t.xpath('./w:tblPr/w:tblBorders/*/@w:color',namespaces=ns))=={'D9D9D9'}
 captions=re.findall(r'Table (\d+)\.',text);assert captions==[str(i) for i in range(1,8)],captions
 assert len(rt.xpath('//w:drawing',namespaces=ns))==6
 comments=parts['word/comments.xml'];assert len(comments)==4
 ids=comments.xpath('./w:comment/@w:id',namespaces=ns)
 assert sorted(ids)==sorted(rt.xpath('//w:commentRangeStart/@w:id',namespaces=ns))==sorted(rt.xpath('//w:commentRangeEnd/@w:id',namespaces=ns))
 math_count=len(rt.xpath('//m:oMath',namespaces=ns))
r={'file':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'numbered_equations':36,'native_math_objects':math_count,'matrix_shapes':mats,'tables':7,'figures':6,'revision_comments':4,'package_integrity':True,'internal_relationships_resolve':True,'full_OOXML_schema_validation':False}
(P/'validation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
