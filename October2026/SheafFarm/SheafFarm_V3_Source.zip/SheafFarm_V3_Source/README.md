# SheafFarm Version 3

Source for the revised Word paper dated 20 October 2026, by Debi Prasad Ghosh.

## Main changes

- A simple-graph orthogonal connection Laplacian determines its edge weights and transports. The K4 Gram-fibre ambiguity concerns a different family of general scalar restrictions.
- Exact rational Jacobian and tangent witnesses strengthen the K4 local continuum result.
- The radial edge message-passing example is gradient descent on a convex log-cosh residual energy, with a certified step bound.
- The cycle proof covers reflective holonomy without a real orthogonal root. Half-amplitude depth is distinguished from detection, including in evaluation prediction P7.
- Finite constant-force suppression is separated from the hard limit. General corruption schedules and correctly noised energy-tilt scores are derived.
- The audit separates marginal and joint laws, exact and approximate agreement, finite and limiting formulas, and numerical probes from universal guarantees.
- Native Word matrix shapes are preserved; captions are numbered in order. Four Word comments mark the principal scope corrections.

## Rebuild

Use Python 3.12 with NumPy, SciPy, Matplotlib, python-docx 1.2 or newer, and lxml. Install Pandoc on PATH. Then run:

```bash
python rebuild.py
```

This runs the 39 legacy checks and 23 new checks, rechecks the archived C# output, rebuilds the manuscript and figures, adds the revision comments and validates the Word package. It reruns the numerical checks and verifies byte identity of the result files in the same runtime. The editable output is `output/SheafFarm_V3.docx`.

All 62 checks pass in the recorded runtime. The original 39 checks include replication of the old coarse audit thresholds and set bookkeeping. Passing those legacy tests does not endorse the exact-support or cross-type ranking interpretations corrected in the paper. No trained-model benchmark is reported.

## Files and provenance

- `paper.md` is the complete updated manuscript.
- `legacy_checks.py`, `legacy_results.json` reproduce the V2 checks. `results.json` is the same legacy data consumed by the inherited assembly and figure code.
- `revision_checks.py`, `revision_results.json` contain the independent added checks and exact rational witnesses.
- `audit_v3.py`, `audit_v3.json` declare the scoped mathematical properties of explicit reference formulas. These entries are not labels inferred from a finite numerical probe or proof of a task advantage.
- `assemble_v2.py`, `v1_labelled.md`, `blocks.md`, `render.py` and `revise_paper.py` assemble the manuscript. The V2 material is retained as the input to local revisions; do not edit only `paper.md` and expect those edits to survive rebuilding.
- `figures.py` regenerates Figures 2, 4, 5 and 6. Figures 1 and 3 are retained from the supplied project and their assets are included.
- `cs/` is the immutable C# reference kernel from V2. `cs_validate.py` compiles and runs it if a .NET SDK is available; otherwise it explicitly rechecks the supplied archived 13-line output. The saved V3 validation used archived output, not a fresh compiler run. The scaled error is absolute error divided by max(1, absolute NumPy value), not a relative error for tiny values. Its coupling-factor formula assumes a VP schedule; see Proposition 7.2.
- `build.py`, `postprocess.py`, `reference.docx`, `add_review_comments.py` create editable native OMML equations and review comments.
- `verify.py`, `validation.json`, `reproducibility.json`, `render_review.json` record the checks and final layout review. Full OOXML schema validation is not claimed.

The document was rendered to 30 pages and every page visually inspected. Scientific figures are raster plots; equations are native Word math. QA PDFs and page PNGs are intentionally excluded. Pagination can vary with Word fonts and renderer settings. Numerical residuals can vary across platforms; same-runtime reproducibility is distinct from cross-platform byte identity.
