---
title: "SheafFarm: Some Sheaf-Diffusion Algorithms are More Sheaf Than Others"
subtitle: Distinguishing operator, geometry, compatibility and generative law. Version 2
author:
  - Debi Prasad Ghosh
  - Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India
date: 20 October 2026 · Version 2
---

## Abstract

The name sheaf diffusion covers several different mathematical commitments. A model may assemble a Laplacian from restriction maps, transport data between local frames, preserve compatible assignments, or generate a probability law on global sections. These properties are not interchangeable. We propose a comparison by explicit structural certificates rather than a scalar measure of sheafness. Version 1 proved three separations. Algorithms that access a sheaf only through its vertex Laplacian cannot recover the whole sheaf. Preserving global sections does not imply a local sheaf morphism. Stronger compatibility can discard operator information: on a cycle with two-dimensional orthogonal data, an arbitrarily small nontrivial rotation changes the compatible subspace from dimension two to zero, so the zero-holonomy and infinite-diffusion limits do not commute.

Version 2 adds positive results and an executable audit. Two coboundaries have the same Laplacian if and only if they differ by an isometry of the edge space. The edge-resolved Grams recover the sheaf up to edge-local isometry, and with it every transport. On the complete graph on four vertices, which is a simple graph, scalar sheaves with one Laplacian form a two-dimensional family whose cycle holonomies vary continuously; on a single cycle the family is discrete. Radial vertex nonlinearities give frame-covariant sheaf layers where coordinatewise ReLU fails. On an $n$-cycle a rotation holonomy $\varepsilon$ gives smallest eigenvalue $4\sin^2(\varepsilon/2n)$, so the depth needed to see it grows like $n^2/\varepsilon^2$. A triangle with $\varepsilon=0.1$ needs 2,496 layers of step 0.25. A rank threshold inside the spectral gap restores the continuity that the exact kernel loses, with a Davis–Kahan certificate. Adding the clean force $-\beta Lx$ to an uncoupled score is worse than inexact. Under the probability flow started at signal level $a_T$, it scales each disagreement mode of eigenvalue $\mu$ by $a_T^{\beta\mu}$, and so silently becomes a hard constraint. Finally, a SheafFarm audit computes six certificates for eleven reference algorithms. Five of them are maximal, so no algorithm is the most sheaf. All 39 checks pass, and an immutable C# kernel agrees with NumPy on every output line. The question for an implementation remains precise: which structural information does the algorithm retain, which relations does it enforce, and which probability claim has actually been established?

**Keywords:** cellular sheaf; sheaf diffusion; sheaf Laplacian; holonomy; naturality; Gaussian diffusion; global sections; identifiability; spectral gap; model comparison.

# 1 What the title means

Some sheaf-diffusion algorithms use more of a sheaf than others. That statement becomes useful only after specifying what *use* means. Multiplying by a matrix assembled from restrictions uses their Gram operator. Solving for a compatible assignment uses their common kernel. Checking the restriction squares uses the local diagram itself. Sampling a law on compatible assignments requires a further probabilistic specification. An algorithm can make a strong commitment in one of these senses and a weak commitment in another.

We therefore interpret the title as a question about retained structure. It is not a claim that a constant sheaf is less legitimate, that nonzero holonomy is always desirable, or that an elaborate construction should outperform a simple one. Constant sheaves are sheaves. Ordinary graph diffusion is a valid special case. A sheaf with complicated matrices can be equivalent, after changing local coordinates, to that simple case. Conversely, hard compatibility may eliminate directions that a useful model needs.

The distinction matters in the ASE programme. The route from DDPM and DDIM through Diffusion Evolution and ADE to Autoregressive Sheaf Evolution changes the clean prediction inside a scheduled recurrence. The reverse route shows where a sheaf can enter a conventional sampler: a read among records, correlations among generated examples, a clean joint target, or a compositional support model \[7, 11\]. Sharing a denoising update does not make those constructions share a probability law.

There is also an established architectural meaning. Neural Sheaf Diffusion learns restriction maps and uses their associated operator for graph representation learning \[2\]. Deep Neural Sheaf Diffusion changes the propagation mechanism to address depth-related signal decay \[3\]. Such models need not be generative DDPMs, nor do their learned nonlinear layers automatically become morphisms of sheaves. Their structural claims should be assessed at the interfaces they actually declare.

This paper develops a small mathematical theory of those interfaces. Section 3 establishes what a Laplacian-only algorithm cannot identify, and what the edge-resolved interface recovers. Section 4 removes coordinate-dependent notions of nontriviality and gives a frame-covariant nonlinear layer. Section 5 separates section preservation, cochain maps and local naturality. Section 6 shows how hard compatibility can forget geometry and become discontinuous, how cycle length hides holonomy, and how a rank policy restores continuity. Section 7 separates compatible noise, unchanged marginal laws and globally calibrated targets, and shows that a constant coupling force collapses to the hard law. Section 8 compares constructions. Section 9 runs the comparison as an executable certificate audit. Sections 10 and 11 give falsifiable engineering tests and conclusions.

## 1.1 What Version 2 adds

- **The Gram fibre and the edge-resolved interface (Section 3).** Equal Laplacians mean exactly an edge-space isometry (Theorem 3.4). The per-edge Grams recover every transport (Corollary 3.5). On simple graphs with more edges than vertices, one Laplacian hides a continuum of holonomies (Proposition 3.6).
- **A covariant nonlinearity (Section 4).** Radial vertex nonlinearities make sheaf layers frame covariant and section preserving (Proposition 4.3).
- **Cycle length, depth and rank policy (Section 6.3).** The spectrum of an orthogonal connection on an $n$-cycle gives a depth law for seeing holonomy (Proposition 6.5, Corollary 6.6). A threshold inside the spectral gap makes hard compatibility continuous (Proposition 6.7).
- **Constant coupling collapses (Section 7.2).** The clean force $-\beta Lx$ scales mode $\mu$ by $a_T^{\beta\mu}$ (Proposition 7.2).
- **SheafFarm (Section 9).** Six certificates are computed, not asserted, for eleven reference algorithms, and the inclusion order is drawn.
- **Evidence.** There are 39 checks: the 17 Version 1 checks rebuilt from the paper's statements, and 22 new ones. An immutable C# kernel is listed in Appendix A.

The underlying sheaf and spectral facts are classical \[1, 2\]. The contribution is their organisation into an operational comparison, together with explicit separation examples and their consequences for sheaf-based generative diffusion. We make no literature-priority claim for the elementary identities, no assertion that sheaf theory is necessary to compute a matrix product, and no trained-model performance claim.

# 2 A typed structural comparison

Fix units before taking a residual. Displacements, rotations, stresses and latent features require declared scales and metrics. We use orthonormal coordinates after that calibration. A permitted change of frame acts within the declared physical or feature type; it does not authorise mixing quantities with incompatible units.

**Definition 2.1 --- Horizontal data and agreement.** On a finite oriented graph, assign data spaces $F(v)$ and comparison spaces $F(e)\text{,}$ with linear restrictions $r_{ve}:F(v) \rightarrow F(e)$ for each incidence. Put

$$C^{0} = \bigoplus_{v}F(v),\quad\quad C^{1} = \bigoplus_{e}F(e),\quad\quad(\delta x)_{e} = r_{we}x_{w} - r_{ve}x_{v}. \tag{1}$$

For positive-definite edge metric $W\text{,}$ let $B = W^{1/2}\delta\text{.}$ The agreement energy, vertex Laplacian and compatible space are

$$E(x) = \frac{1}{2} \parallel Bx \parallel^{2},\quad\quad L = B^{\top}B,\quad\quad V = kerB = kerL. \tag{2}$$

A stalk is a data space, not a travelling token. A token occupies elements of successive data spaces; specified linear transports or pathwise derivatives form its vertical fibre diagram. A graph sheaf has no higher-face identities to check. If a model adds triangles or higher cells, the relevant restriction composites must commute before the resulting cochain complex is asserted.

The four bases remain distinct. A cover and its nerve describe locality; a context base describes partial-variable incidence; a layer order describes computational depth or noise levels; an observation star describes retrieval. A graph connecting examples is not automatically an open-cover nerve. Comparison between these objects needs maps, not shared terminology.

**Definition 2.2 --- A declared comparison interface.** An algorithmic claim specifies its data spaces, restriction family, allowed coordinate changes, available operations, admissible inputs, and a baseline class. A structural certificate is a statement about that interface, not merely a name attached to the code.

Table: **Table 1.** Certificates used in this paper. Each needs its own assumptions and witness.

  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Certificate               What it establishes                                                                         What does not establish it
  ------------------------- ------------------------------------------------------------------------------------------- -------------------------------------------------
  Operator dependence       Changes in admissible restrictions affect the operator or law beyond the declared control   Nonidentity entries in one coordinate system

  Frame covariance          The complete calculation transforms with allowed local frames                               Covariance of the Laplacian alone

  Local naturality          Specified stalk maps commute with the incidence restrictions                                A global matrix factorisation

  Section compatibility     The stated output or trajectory satisfies the declared agreement law                        A small average residual without a tolerance

  Probability consistency   A clean law, corruption and reverse construction agree under stated limits                  A compatible mean or a score at one noise level
  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------

An algorithm can carry several certificates. For a fixed interface and common certificate vocabulary, inclusion of verified certificate sets defines a preorder; quotienting algorithms with equal sets gives a partial order. This is bookkeeping, not a new numerical invariant. Unverified is not false, and inapplicable is not a failed test. A deterministic graph classifier has no obligation to provide a generative score.

Baseline choice is essential. A scalar graph Laplacian acting independently on channels is a narrow control. An unrestricted block-matrix network may represent the same linear operator as a sheaf layer. Demonstrating a difference from the first control does not establish a difference from the second. Tests should state whether the claimed benefit concerns parameterisation, calibrated interfaces, computation, expressivity or access to information.

# 3 A Laplacian is not the whole sheaf

**Theorem 3.1 --- Indistinguishability through the Gram interface.** Suppose an algorithm receives the horizontal structure only through $L = B^{\top}B\text{.}$ Its other inputs, parameters, initial law and randomisation rules are held fixed. Two structures with the same $L$ induce the same output law. This applies to finite compositions of measurable functions of that interface, including heat flow, resolvents and Gaussian energies depending only on $x^{\top}Lx\text{.}$

*Proof.* Equal interfaces give equal first-step functions or transition kernels. Induction gives equal joint laws of every subsequent state and equal final output laws. For a deterministic algorithm with a shared random seed, the realised outputs also agree. ▫

The statement holds regardless of how sophisticated the function of $L$ is. It does not say that $L$ is useless: it determines the vertex agreement energy and its compatible subspace. It says that a claim about the *whole* sheaf needs more information than that interface supplies.

**Example 3.2 --- Equal Laplacians and different first cohomology.** Take two scalar vertex spaces joined by one edge. In the first sheaf the edge space is $\mathbb{R}$ with identity restrictions. In the second it is $\mathbb{R}^{2}$ and both restrictions send $u$ to $(u,0)\text{.}$ With identity metrics,

$$B_{1} = \begin{pmatrix}
 - 1 & 1
\end{pmatrix},\quad\quad B_{2} = \begin{pmatrix}
 - 1 & 1 \\
0 & 0
\end{pmatrix},\quad\quad B_{1}^{\top}B_{1} = B_{2}^{\top}B_{2}. \tag{3}$$

On a graph, $H^{1} = C^{1}/im\delta\text{.}$ Its dimensions are zero and one respectively. The extra comparison coordinate is invisible to the vertex energy. Its nonzero first cohomology does not assert inconsistent observed data. Consequently, no experiment confined to the common Laplacian interface can decide which first cohomology is present.

This example deliberately exposes an unobserved edge direction. A minimal-realisation assumption can rule it out, but that assumption must be supplied. Also, when $\dim C^{1}$ is separately known, the graph formula $\dim H^{1} = dimC^{1} - rankL$ determines the dimension. The example does not deny that formula; the two interfaces hide different edge dimensions. Even knowing a dimension does not reconstruct the individual restrictions.

**Example 3.3 --- Even invertible restrictions and fixed dimensions do not identify general holonomy.** Join two scalar vertices by two parallel edges, both oriented from the first vertex to the second. Take the two coboundaries

$$B_{a} = \begin{pmatrix}
 - 1 & 1 \\
 - 2 & 3
\end{pmatrix},\quad\quad B_{b} = \begin{pmatrix}
 - 11/5 & 3 \\
 - 2/5 & 1
\end{pmatrix}. \tag{4}$$

Both have Gram matrix $\begin{pmatrix}
5 & - 7 \\
 - 7 & 10
\end{pmatrix}\text{.}$ All incidence restrictions are nonzero and hence invertible. Their transports, obtained by dividing the positive tail restriction by the head restriction, are $(1,2/3)$ and $(11/15,2/5)\text{.}$ Transport around the two-edge loop is therefore $3/2$ in the first case and $11/6$ in the second. Scalar local changes of frame cannot change a loop multiplier. The sheaves are not isomorphic over this fixed graph, although their vertex energies and all Laplacian-only algorithms coincide. These transports are general invertible maps, not orthogonal ones. A direct sum with the same constant sheaf gives a nonzero section space without changing the indistinguishability argument.

More generally, orthogonal changes of whitened comparison coordinates leave $L$ unchanged. Such changes mixing different edge blocks can destroy the original incidence interpretation, or, on parallel edges as above, preserve incidence while changing the sheaf. An arbitrary factorisation of a positive-semidefinite matrix is therefore not a certificate of a specified local diagram. The typed factorisation and the Gram operator answer different questions.

![**Figure 1.** Information retained by three interfaces. Passing from typed restrictions to the vertex Gram operator can lose edge-space information. Passing from the operator to its kernel projector loses positive spectral information. Heat and soft Gaussian laws use the middle interface; exact compatibility alone can use the last. The arrows express information loss, not a ranking of model quality.](fig/v1_interfaces.png){width=100%}

**Theorem 3.4 --- The Gram fibre.** Let $B_1$ and $B_2$ be whitened coboundaries on the same vertex space. Then $B_1^\top B_1=B_2^\top B_2$ if and only if there is a linear isometry $U:\text{im}B_1\to\text{im}B_2$ with

$$B_2=UB_1. \tag{5}$$

When the two edge spaces have equal dimension, $U$ extends to an orthogonal map of the whole edge space.

*Proof.* If $B_2=UB_1$ with $U$ isometric on $\text{im}B_1$, then $B_2^\top B_2=B_1^\top U^\top UB_1=B_1^\top B_1$. Conversely, equal Grams give $\|B_1x\|=\|B_2x\|$ for every $x$. Hence $B_1x=B_1y$ implies $B_2x=B_2y$, so $U(B_1x)=B_2x$ is well defined, linear and isometric. When the dimensions agree, the orthogonal complements of the two images have equal dimension, and any isometry between them completes $U$. ▫

Theorem 3.1 therefore has an exact converse description. A Laplacian-only algorithm identifies the coboundary up to the group of all isometries of edge coordinates. Over a fixed graph with whitened edge metrics, the sheaf itself is determined only up to the smaller group of edge-local isometries $U=\oplus_eU_e$, which act on each edge space separately. The difference between these two groups is precisely what Laplacian-only algorithms cannot see. In Example 3.3 the isometry is the rotation

$$U=B_bB_a^{\text{+}}=\begin{pmatrix}0.6&0.8\\-0.8&0.6\end{pmatrix}, \tag{6}$$

which mixes the two parallel edge coordinates. That mixing is exactly what changes the loop multiplier while leaving every vertex energy unchanged.

**Corollary 3.5 --- The edge-resolved interface identifies transports.** Suppose an algorithm receives the edge Grams $L_e=B_e^\top B_e$ for every edge, rather than only their sum $L$. Then it determines each edge block $B_e$ up to an isometry of $F(e)$, and hence the sheaf up to edge-local isometry. Whenever the head restriction is invertible, the transport $T_e=r_{we}^{-1}r_{ve}$ is determined exactly, and so is every cycle holonomy. For scalar stalks, $T_e=-(L_e)_{vw}/(L_e)_{ww}$.

*Proof.* Theorem 3.4 applied to each edge gives $B_e$ up to a left isometry $U_e$. Replacing $(r_{ve},r_{we})$ by $(U_er_{ve},U_er_{we})$ leaves $r_{we}^{-1}r_{ve}$ unchanged. For scalar stalks $(L_e)_{vw}=-r_{ve}r_{we}$ and $(L_e)_{ww}=r_{we}^2$. ▫

The corollary gives a positive meaning to "using more of the sheaf". An algorithm whose update depends on the individual edge residuals $B_ex$, nonlinearly or with edge-specific weights, can depend on information that no function of $L$ carries. Linear heat cannot, because its update sums the edge Grams before acting. Section 9 shows the difference on a test bed. The parallel-edge pair of Example 3.3 is not a special artefact, as the next result shows.

**Proposition 3.6 --- On simple graphs with more edges than vertices, one Laplacian hides a continuum.** Consider scalar stalks with nonzero restrictions on a simple connected graph. The map from the $2|E|$ restriction values to $L$ has at most $|E|+|V|$ independent output entries: one per vertex on the diagonal and one per edge off it. Near any point where its Jacobian has constant rank $k$, the set of restriction values with the same Laplacian is a manifold of dimension

$$2|E|-k\ \ge\ |E|-|V|. \tag{7}$$

On the complete graph $K_4$, with $|E|=6$ and $|V|=4$, the Jacobian has rank 10, so the fibre is two-dimensional. Along it the triangle holonomies change continuously. On a single cycle, $|E|=|V|$; for the tested 5-cycle the Jacobian has full rank 10, so the fibre is discrete there.

*Proof.* The entry count is immediate for a simple graph, and the dimension statement is the constant-rank theorem. Edge sign changes form a finite group and cannot account for a positive-dimensional fibre. Cycle holonomy is invariant under every invertible scalar change of vertex frame, so sheaves on the fibre with different holonomies are not isomorphic over the fixed graph. The $K_4$ and 5-cycle statements are exact rank computations, and the holonomy variation along the $K_4$ fibre is computed in the companion script. ▫

Following the fibre of $K_4$ from one scalar sheaf for an arc length of 0.6 held every entry of $L$ fixed to 8.88 × 10⁻¹⁶. Meanwhile the holonomy of triangle 0–1–2 moved from 3.25 to 6.30, and that of triangle 0–1–3 from 0.41 to 1.26 (Figure 2). The edge Grams of the two end points differ by 0.72 in some entry, and the transports read from them agree with the true ones to 2.22 × 10⁻¹⁶. Thus every Laplacian-only algorithm, however deep or nonlinear, treats these geometrically different sheaves identically, and an edge-resolved algorithm need not.

![**Figure 2.** The Gram fibre on $K_4$ with scalar stalks. (a) Holonomies of three triangles along a path of sheaves that all have the same Laplacian; the sheaves are not isomorphic because their holonomies differ. (b) The largest change in any entry of $L$ along the path; exact zeros are plotted at $10^{-17}$.](fig/fibre.png){width=100%}

# 4 Nonidentity maps can be a choice of frame

Consider a connected graph with $F(v) = F(e) = \mathbb{R}^{d}$ and orthogonal transport $T_{e}$ on each oriented edge $v \rightarrow w\text{.}$ Write the residual as $x_{w} - T_{e}x_{v}\text{.}$ Local orthogonal frames $G_{v}$ change transport by

$$x'_{v} = G_{v}x_{v},\quad\quad T'_{e} = G_{w}T_{e}G_{v}^{\top}. \tag{8}$$

Cycle transport, based at a fixed root, is holonomy. Changing frames conjugates it and therefore preserves whether it is the identity.

**Theorem 4.1 --- Flattening an orthogonal local system.** There are local orthogonal frames making every $T'_{e} = I$ if and only if every cycle holonomy is the identity. In particular, every such local system on a tree is equivalent to an identity-transport system.

*Proof.* Identity edge transports give identity transport around every cycle, and conjugation preserves that property. Conversely, choose a root and a spanning tree. For each vertex let $P_{v}$ be transport from the root along the tree and set $G_{v} = P_{v}^{\top}\text{.}$ Every tree edge becomes identity. Each remaining edge becomes the holonomy of its corresponding fundamental cycle, which is identity by assumption. ▫

Thus counting nonidentity matrices is not a coordinate-invariant measure of structural complexity. A chain of rotation matrices can be ordinary graph heat expressed in different local frames. That does not make the maps irrelevant in an engineering implementation: local frames may be fixed by sensors or finite-element conventions, and their calibration is necessary to compare physical data correctly.

When holonomy is nontrivial, global sections correspond to root vectors fixed by every cycle holonomy. Indeed, a compatible assignment must be the transport of its root value, and path independence requires precisely those fixed-vector identities. A balanced scalar sign cycle therefore has a one-dimensional compatible space, while a frustrated three-cycle has none. Their vertex spectra are respectively $(0,3,3)$ and $(1,1,4)\text{.}$ This is a controlled geometric distinction on the same graph, not a change in its ordinary cycle count.

**Proposition 4.2 --- A covariant linear operator does not certify a covariant network.** If local frame changes are orthogonal, then $L' = GLG^{\top}$ and every spectral function obeys $f(L') = Gf(L)G^{\top}\text{.}$ A nonlinear layer additionally needs $\sigma(Gx) = G\sigma(x)\text{,}$ or a correspondingly transformed nonlinear rule.

*Proof.* Whitened residuals transform by an orthogonal edge map, so the Gram transforms by conjugation. Polynomial functional calculus and its spectral extension prove the first claim. Substitution into the complete nonlinear update gives the second condition. ▫

Coordinatewise ReLU fails it for a general rotation. With $x = ( - 1,2)$ and a quarter-turn $G\text{,}$ $ReLU(Gx) = 0$ while $GReLU(x) = ( - 2,0)\text{.}$ Odd nonlinearities can respect scalar sign changes, but oddness alone does not imply covariance under arbitrary orthogonal mixing. Normalisation, learned map prediction and decoding also belong in a whole-network frame test. These observations concern the declared symmetry, not a demand that all architectures use the largest possible gauge group.

**Proposition 4.3 --- Radial nonlinearities give frame-covariant layers.** Let $\sigma$ act on each vertex value by $\sigma(x)_v=x_v\varphi(\|x_v\|)$ for some scalar function $\varphi$. Then $\sigma(Gx)=G\sigma(x)$ for every block-diagonal orthogonal $G$. Hence the layer $x\mapsto\sigma(x-\alpha Lx)$ is covariant under orthogonal local frames. On a connected orthogonal local system it also maps compatible assignments to compatible assignments.

*Proof.* $\|G_vx_v\|=\|x_v\|$, so $\sigma(Gx)_v=G_vx_v\varphi(\|x_v\|)$. Combine this with $L'=GLG^\top$ from Proposition 4.2. A compatible assignment satisfies $Lx=0$, and orthogonal transport along a connected graph gives every vertex the same norm. So every vertex is multiplied by the same factor, which preserves each residual $x_w-T_ex_v=0$. ▫

The radial layer with $\varphi(r)=\tanh(r)/r$ had frame defect 1.11 × 10⁻¹⁶ on a random orthogonal system on $K_4$. The same layer with coordinatewise ReLU had defect 0.582. The positive example shows that frame covariance is a design choice available to nonlinear sheaf networks, not only to linear ones. Its cost is that the nonlinearity sees only norms within each stalk.

# 5 Preserving sections is weaker than local naturality

Let $T:C^{0} \rightarrow C^{0}$ be linear and keep the horizontal model fixed. A tempting test asks only whether $T(V) \subseteq V\text{.}$ The following result shows exactly what that test certifies.

**Theorem 5.1 --- Section preservation and global factorisation.** In finite dimensions,

$$T\left( \ker\delta \right) \subseteq ker\delta\quad \Leftrightarrow \quad\delta T = S\delta\text{ for some linear }S:C^{1} \rightarrow C^{1}. \tag{9}$$

The edge map $S$ in this statement need not preserve individual edge spaces or any incidence locality.

*Proof.* A factorisation immediately sends a vector in $\ker\delta$ back to that kernel. Conversely, define $S(\delta x) = \delta Tx$ on $im\delta\text{.}$ If $\delta x = \delta y\text{,}$ then $x - y \in ker\delta$ and the assumed preservation gives $\delta Tx = \delta Ty\text{.}$ Thus the definition is well-defined and linear. Extend it linearly to a complement of $im\delta$ in $C^{1}\text{.}$ ▫

An unrestricted factorisation therefore adds nothing to linear section preservation. A local sheaf morphism is more specific. It supplies maps $T_{v}$ on vertex data spaces and $S_{e}$ on edge spaces satisfying each incidence square,

$$r_{ve}T_{v} = S_{e}r_{ve}. \tag{10}$$

For changing coefficients the restrictions on the two sides belong to the appropriate layers. For a changing base with continuous map $\Phi_{t}:X_{t} \rightarrow X_{t - 1}\text{,}$ the typed comparison is $F_{t} \rightarrow \Phi_{t}^{- 1}F_{t - 1}\text{.}$ These declarations cannot be replaced by a factorisation of two large matrices.

**Example 5.2 --- A nonzero compatible space without local naturality.** On a three-cycle take two coordinates at every vertex. The first has identity transport on all edges. The second has signs $+ , + , - \text{.}$ The compatible assignments are exactly $x_{v} = (c,0)\text{,}$ with one common scalar $c\text{.}$ Let

$$T_{v} = diag\left( 1,a_{v} \right),\quad\quad\left( a_{0},a_{1},a_{2} \right) = (1,2,3). \tag{11}$$

This preserves the nonzero compatible space. However, every edge restriction is invertible. Its two incidence identities would require the edge map to equal the corresponding conjugates of both endpoint maps. Those have different second diagonal entries, so no such edge map exists. Minimising the sum of squared Frobenius square defects independently over edge maps gives $\frac{1}{2}\left\lbrack (1 - 2)^{2} + (2 - 3)^{2} + (3 - 1)^{2} \right\rbrack = 3\text{.}$ This is not a vacuous preservation example with $V = 0\text{.}$

There is an important converse caution: sheaf diffusion need not be a stalkwise sheaf morphism. Heat transfers information between vertices. Its action on $C^{0}$ is generally not block diagonal. Requiring a vertex-local morphism at every computational step would exclude ordinary message passing, including valid sheaf-assembled heat flow.

**Proposition 5.3 --- Heat has a cochain intertwiner.** In whitened edge coordinates,

$$Be^{- tB^{\top}B} = e^{- tBB^{\top}}B. \tag{12}$$

*Proof.* The identity $B\left( B^{\top}B \right)^{k} = \left( BB^{\top} \right)^{k}B$ holds by induction for every integer $k \geq 0\text{.}$ Sum the convergent exponential series. ▫

This gives a global cochain map and proves section preservation. It is not generally a local sheaf morphism. Accordingly, an algorithm can be genuinely assembled from a sheaf without satisfying a different, unclaimed locality condition. A comparison should distinguish these achievements rather than treating the strongest-looking diagram as compulsory.

# 6 Hard compatibility can forget geometry

This section keeps $L \succcurlyeq 0$ fixed unless a perturbation is explicitly introduced. Let $\Pi$ be orthogonal projection onto $V = kerL\text{,}$ and assume there is at least one positive eigenvalue. Denote the smallest positive eigenvalue by $\lambda_{\text{+}}\text{.}$

**Theorem 6.1 --- Spectral information lost in the hard limit.** For $p > 0$ and $\beta > 0\text{,}$

$$\underset{t \rightarrow \infty}{\text{lim}}e^{- tL} = \Pi,\quad\quad \parallel e^{- tL} - \Pi \parallel_{2} = e^{- t\lambda_{\text{+}}}, \tag{13}$$

$$\underset{\beta \rightarrow \infty}{\text{lim}}(pI + \beta L)^{- 1} = p^{- 1}\Pi,\quad\quad \parallel (pI + \beta L)^{- 1} - p^{- 1}\Pi \parallel_{2} = \frac{1}{p + \beta\lambda_{\text{+}}}. \tag{14}$$

Consequently, two operators with the same kernel but different positive spectra have identical limiting heat projectors and hard Gaussian covariances.

*Proof.* Diagonalise $L$ in an orthonormal eigenbasis. Heat has gain one on zero eigenvalues and $e^{- t\lambda}$ on positive ones. The Gaussian covariance has gains $1/p$ and $1/(p + \beta\lambda)\text{.}$ Taking limits and the largest remaining gain proves all claims. ▫

For example, the path Laplacians $L_{0}$ and $4L_{0}$ have the same compatible space but different finite heat operators. Their hard limits agree. An intrinsic sampler that uses only $\Pi$ and the same intrinsic clean distribution is equally unable to distinguish them. The qualification about the clean distribution matters: an algorithm can still retain coefficient information elsewhere, such as in learned factors or its decoder.

A soft Gaussian target retains more operator information. Let $Y\mathcal{\sim N}(\mu,C)$ with $C = (pI + \beta L)^{- 1}\text{,}$ and corrupt it by $X = aY + s\epsilon\text{.}$ Its covariance is $S = a^{2}C + s^{2}I\text{.}$

**Proposition 6.2 --- A known positive-signal Gaussian law identifies the vertex operator.** If $p,\beta,a,s$ are known, $\beta > 0$ and $a \neq 0\text{,}$ exact knowledge of $S$ determines

$$L = \frac{1}{\beta}\left\lbrack \left( \frac{S - s^{2}I}{a^{2}} \right)^{- 1} - pI \right\rbrack. \tag{15}$$

*Proof.* Subtract the known noise covariance, divide by $a^{2}$ to recover $C\text{,}$ and invert the clean precision formula. ▫

This identifies $L\text{,}$ not the full restriction diagram, by Theorem 3.1. It also fails at pure noise $a = 0\text{,}$ and it is not a stable finite-sample identification guarantee. Subtraction by $s^{2}I\text{,}$ division by $a^{2}$ and covariance inversion can amplify estimation errors. The proposition concerns exact distributions under a known model.

## 6.1 A small holonomy can make a hard discontinuity

Consider a three-cycle with two-dimensional orthogonal transport. Two edges have identity transport and the third has the planar rotation $R_{\varepsilon}\text{.}$ Let $L_{\varepsilon}$ be its vertex Laplacian. At $\varepsilon = 0\text{,}$ compatible assignments have a common arbitrary vector, so the kernel has dimension two. At any $0 < |\varepsilon| < \pi\text{,}$ a compatible root vector must be fixed by a nontrivial planar rotation and is therefore zero.

**Theorem 6.3 --- The zero-holonomy and hard-diffusion limits do not commute.** For this fixed-base family,

$$\underset{\varepsilon \rightarrow 0,\,\varepsilon \neq 0}{\text{lim}}\left( \underset{t \rightarrow \infty}{\text{lim}}e^{- tL_{\varepsilon}} \right) = 0,$$

$$\underset{t \rightarrow \infty}{\text{lim}}\left( \underset{\varepsilon \rightarrow 0}{\text{lim}}e^{- tL_{\varepsilon}} \right) = \Pi_{0} \neq 0. \tag{16}$$

For $|\varepsilon| < \pi\text{,}$ the smallest eigenvalue is

$$\lambda_{\min}\left( L_{\varepsilon} \right) = 4\sin^{2}(\varepsilon/6) \sim \varepsilon^{2}/9. \tag{17}$$

*Proof.* The kernel statement gives the first iterated limit. Since the entries of $L_{\varepsilon}$ vary continuously, matrix exponentiation at fixed finite $t$ converges to $e^{- tL_{0}}\text{,}$ giving the second. For the gap, distribute the rotation equally around the cycle by local frames and identify the plane with the complex numbers. The cyclic Fourier modes have eigenvalues $2 - 2\cos\left\lbrack (\varepsilon + 2\pi k)/3 \right\rbrack\text{,}$ $k = 0,1,2\text{,}$ each appearing twice over the real coordinates. In the stated interval the smallest is the $k = 0$ value, which equals (17). ▫

The compatible projectors differ in operator norm by one, however small the nonzero angle is. The corresponding hard Gaussian covariance limits are zero for nonzero angle and $p^{- 1}\Pi_{0}$ at zero. Yet the finite-time heat is continuous. Its slowest decay time grows like $9/\varepsilon^{2}\text{.}$ A model can therefore look almost compatible over every practical finite depth and still have a qualitatively different infinite-depth limit.

This is a precise reason to avoid equating a stronger agreement constraint with a better architecture. An exact hard constraint is sensitive to whether a nearly closed transport cycle closes exactly. Learning error, calibration error and numerical rank thresholds can decide which compatible space is used. Reporting that choice is part of the model, not a minor implementation detail.

![**Figure 3.** Finite heat and hard collapse on the rotation cycle. The left panel plots the heat operator norm, which is one at zero holonomy and decays as $\exp\left\lbrack - 4t\sin^{2}(\varepsilon/6) \right\rbrack$ for nonzero angles. Decreasing the angle delays collapse but does not change its infinite-time endpoint. The right panel plots the corresponding soft Gaussian covariance norm for $p = 1\text{.}$ The curves are analytic evaluations, not learned-model measurements.](fig/v1_collapse.png){width=100%}

## 6.2 Finite operators have perturbation certificates

**Proposition 6.4 --- Stability before the hard limit.** For any two whitened coboundaries $B,\widehat{B}$ on the same declared coordinate spaces, let $L = B^{\top}B$ and $\widehat{L} = {\widehat{B}}^{\top}\widehat{B}\text{.}$ Then

$$\parallel \widehat{L} - L \parallel_{2} \leq \left( \parallel \widehat{B} \parallel_{2} + \parallel B \parallel_{2} \right) \parallel \widehat{B} - B \parallel_{2}, \tag{18}$$

$$\parallel e^{- t\widehat{L}} - e^{- tL} \parallel_{2} \leq t \parallel \widehat{L} - L \parallel_{2}, \tag{19}$$

$$\parallel \left( pI + \beta\widehat{L} \right)^{- 1} - (pI + \beta L)^{- 1} \parallel_{2} \leq \frac{\beta}{p^{2}} \parallel \widehat{L} - L \parallel_{2}. \tag{20}$$

*Proof.* Expand the Gram difference as ${\widehat{B}}^{\top}\left( \widehat{B} - B \right) + \left( \widehat{B} - B \right)^{\top}B$ and apply submultiplicativity. For heat, the Duhamel difference formula is an integral of two positive-semidefinite heat contractions around $\widehat{L} - L\text{;}$ its norm is bounded by the integration length $t$ times that difference. For the final inequality use the resolvent identity and the bound $\parallel (pI + \beta L)^{- 1} \parallel_{2} \leq 1/p$ at both ends. ▫

These bounds do not certify robustness of every nonlinear learned layer. They quantify the frozen linear or Gaussian component. Their dependence on $t$ and $\beta$ also explains why they do not imply continuity of the hard limits in Theorem 6.3. A gap assumption is needed for a stable kernel comparison. When estimated restrictions change with the state, derivatives of that estimation rule enter tangent analysis as well.

## 6.3 Longer cycles hide holonomy, and a rank policy restores continuity

Theorem 6.3 concerns a triangle. Its quantitative content depends on cycle length.

**Proposition 6.5 --- Spectrum of an orthogonal connection on a cycle (classical).** Let an $n$-cycle carry $d$-dimensional stalks and orthogonal transports with holonomy $H$, whose eigenvalues are $e^{i\theta_j}$. The Laplacian spectrum is

$$\left\{2-2\cos\frac{\theta_j+2\pi k}{n}\ :\ j=1,\ldots,d,\ k=0,\ldots,n-1\right\}. \tag{21}$$

For a planar rotation by $\varepsilon$ with $|\varepsilon|<\pi$, the smallest eigenvalue is

$$\lambda_{\min}=4\sin^2\frac{\varepsilon}{2n}\sim\frac{\varepsilon^2}{n^2}. \tag{22}$$

*Proof.* Local frames distribute the holonomy as $H^{1/n}$ on every edge, which conjugates $L$ without changing its spectrum. In the eigenbasis of $H$ the operator becomes $d$ scalar circulants with twist $e^{i\theta_j/n}$, whose Fourier modes give (21). Theorem 6.3 is the case $n=3$. ▫

**Corollary 6.6 --- Depth needed to see holonomy.** For the discrete diffusion $x\mapsto(I-\alpha L)x$ with $0<\alpha\lambda_{\max}\le1$, the slowest mode loses half its amplitude only after

$$K_{1/2}=\left\lceil\frac{\ln2}{-\ln(1-4\alpha\sin^2(\varepsilon/2n))}\right\rceil\approx\frac{n^2\ln2}{\alpha\varepsilon^2} \tag{23}$$

layers. Before then, the system is within a factor of two of a flat one along that mode.

With $\alpha=0.25$, a triangle with holonomy 0.1 needs 2,496 layers, a 6-cycle needs 9,982, and a 12-cycle 39,926. In every tested case the slowest mode fell to one half exactly at the predicted layer. A sheaf network of a few dozen layers therefore cannot tell small holonomy from none on a long cycle through diffusion alone. If holonomy matters to a task, it must enter through an interface that reads it directly, such as the edge-resolved one.

The discontinuity in Theorem 6.3 belongs to a particular rank policy: treating eigenvalue zero exactly. A threshold inside the spectral gap behaves differently.

**Proposition 6.7 --- A rank threshold restores continuity.** Let $L$ have kernel projector $\Pi$ and smallest positive eigenvalue $\lambda_{\text{+}}$. Let $\widehat L$ be symmetric with $\eta=\|\widehat L-L\|_2<\lambda_{\text{+}}/2$. Then the spectral projector $\widehat P$ of $\widehat L$ onto eigenvalues below $\lambda_{\text{+}}/2$ has the rank of $\Pi$, and

$$\|\widehat P-\Pi\|_2\le\frac{\eta}{\lambda_{\text{+}}-\eta}\le\frac{2\eta}{\lambda_{\text{+}}}. \tag{24}$$

*Proof.* By Weyl's inequality the eigenvalues of $\widehat L$ that continue the zero eigenvalues lie below $\eta<\lambda_{\text{+}}/2$, and the others lie above $\lambda_{\text{+}}-\eta>\lambda_{\text{+}}/2$. So the ranks agree. The Davis–Kahan $\sin\Theta$ theorem with separation $\lambda_{\text{+}}-\eta$ bounds the distance between the projectors by $\|(\widehat L-L)\Pi\|_2/(\lambda_{\text{+}}-\eta)$ [12]. ▫

On the rotation triangle, $\lambda_{\text{+}}=3$. At $\varepsilon=0.1$ the perturbation is $\eta=0.1000$, the thresholded projector moves by 0.0272, and the bound (24) is 0.0345. The exact-kernel projector moves by one at every nonzero angle (Figure 4b). The threshold declares near-flat systems flat. That is a modelling decision with a quantified consequence, not a numerical detail, and it should be reported with the model.

![**Figure 4.** (a) Smallest Laplacian eigenvalue against holonomy angle for rotation cycles of length 3 to 24. Lines are (22) and points are computed eigenvalues; longer cycles hide holonomy quadratically. (b) Distance of the compatible projector from the flat one on the rotation triangle. The exact kernel jumps to one at every nonzero angle, while a threshold at $\lambda_{\text{+}}/2$ moves continuously and stays below the Davis–Kahan bound (24).](fig/cycles.png){width=100%}

# 7 A probability law requires its own certificate

The phrase diffusion refers both to smoothing a signal on a relational structure and to reversing a specified stochastic corruption process. These operations can be combined, but one does not certify the other. DDPM, DDIM and score-based models require a declared data law and a relationship between its noisy marginals and the reverse dynamics \[4--6\]. A sheaf Laplacian can be an architectural ingredient without being that marginal score.

## 7.1 Exact compatibility and unit marginal noise can conflict

**Theorem 7.1 --- Full unit marginal covariance requires trivial holonomy.** On a connected orthogonal local system with $d$-dimensional vertex spaces, there exists a jointly Gaussian assignment $\Xi$ that is almost surely compatible and has $Cov\left( \Xi_{v} \right) = I_{d}$ at every vertex if and only if all cycle holonomies are identity. In that case a compatible zero-mean Gaussian with these marginals has cross-covariance

$$Cov\left( \Xi_{v},\Xi_{w} \right) = P_{v}P_{w}^{\top}, \tag{25}$$

where $P_{v}$ transports from a root to $v\text{.}$ Its joint covariance has rank $d\text{.}$

*Proof.* Compatibility expresses every vertex value as $P_{v}\Xi_{o}\text{.}$ For every root holonomy $H\text{,}$ it also gives $(H - I)\Xi_{o} = 0$ almost surely. Taking the covariance and using $Cov\left( \Xi_{o} \right) = I$ yields $(H - I)(H - I)^{\top} = 0\text{,}$ so $H = I\text{.}$ Conversely, when the system is flat, let $Z\mathcal{\sim N}\left( 0,I_{d} \right)$ and set $\Xi_{v} = P_{v}Z\text{.}$ Path independence gives compatibility, orthogonality gives unit marginal covariance, and the common root gives (25) and joint rank $d\text{.}$ ▫

The necessity actually uses only finite second moments, not Gaussianity. The theorem is restricted to full orthogonal transports. With partial observation maps, private vertex directions can carry additional noise. General feasibility is a covariance problem: find $Q \succcurlyeq 0$ with $\delta Q = 0$ and specified diagonal blocks. It is not solved merely by choosing a graph or normalising its adjacency.

Now form the normalised heat covariance

$$K_{\tau} = D_{\tau}^{- 1/2}e^{- \tau L}D_{\tau}^{- 1/2},\quad\quad D_{\tau} = {blockdiag}_{v}\left( e^{- \tau L} \right)_{vv}. \tag{26}$$

For finite $\tau\text{,}$ the heat matrix and its diagonal blocks are positive definite, so $K_{\tau}$ is positive definite with identity diagonal blocks. If $\delta \neq 0\text{,}$ it cannot be supported on $\ker\delta\text{:}$ $tr\left( \delta K_{\tau}\delta^{\top} \right) > 0\text{.}$ Thus exact unit marginals obtained this way do not imply exact agreement. The frustrated sign-cycle check gives expected squared residual 3.903308 despite diagonal error $1.11 \times 10^{- 16}\text{.}$

Correlating the terminal draws and fresh innovations of separable baseline samplers can preserve each copy's baseline path law. A state-adaptive covariance also works when it is chosen from past information and each fresh conditional diagonal block is identity \[7\]. This is a certificate about marginal laws. It neither makes the outputs compatible nor guarantees more diverse batches. If a denoiser couples different samples, the separable-sampler argument no longer applies.

## 7.2 A coupled target and a sheaf architecture are different interventions

An explicit soft target is $Y\mathcal{\sim N}\left( \mu,(pI + \beta L)^{- 1} \right)\text{.}$ Under independent corruption $X = aY + s\epsilon\text{,}$ its exact clean posterior mean is

$$m(x) = \mu + \frac{a}{a^{2} + ps^{2}}(I + hL)^{- 1}(x - a\mu),\quad\quad h = \frac{\beta s^{2}}{a^{2} + ps^{2}}. \tag{27}$$

This is a scalar times a sheaf resolvent on the centred noisy state. The linear gain commutes with heat, but the full affine map need not: its offset must be compatible for that commutation. Applying the resolvent to an arbitrary clean prediction instead does not inherit this Gaussian posterior formula. Also, copying the clean force $- \beta Lx$ to every noisy score is generally incorrect; the clean coupling must be propagated through the corruption \[7\].

The size of the error has a closed form, and it is not small.

**Proposition 7.2 --- Constant coupling becomes a hard constraint.** Take a centred uncoupled Gaussian target whose covariance commutes with $L$, for instance $N(0,p^{-1}I)$. Add the clean force $-\beta Lx$ to its exact score at every noise level, and run the probability-flow limit of deterministic DDIM from signal level $a_T$. Then along every eigenvector of $L$ with eigenvalue $\mu$, the output equals that of the uncoupled flow multiplied by

$$a_T^{\beta\mu}, \tag{28}$$

whereas the exact coupled target requires the factor $\sqrt{p/(p+\beta\mu)}$, independent of $a_T$. As $a_T\to0$, every disagreement mode is removed, and the sampler converges to the hard intrinsic law on $\ker L$.

*Proof.* In clean coordinates $z=x/a$ and $\sigma=s/a$, the deterministic DDIM update is $z'=z+(\sigma'-\sigma)\widehat\epsilon$ with $\widehat\epsilon=-s\nabla\log p(x)$, so in the continuum limit $\text{d}z/\text{d}\sigma=-s\nabla\log p(az)$. The added force contributes $\beta\mu\,as\,z$ along the eigenvector, separately from the uncoupled part, because both are diagonal in the same basis. Since $as=\sigma/(1+\sigma^2)$, integrating from $\sigma_T$ down to zero multiplies the component by $\exp(-\frac{1}{2}\beta\mu\ln(1+\sigma_T^2))=a_T^{\beta\mu}$, using $1+\sigma_T^2=a_T^{-2}$. ▫

With the common choice $\bar\alpha_T=10^{-4}$, so $a_T=0.01$, a mode with $\beta\mu=4$ is scaled by $10^{-8}$ instead of the required 0.447. Deterministic DDIM over 80,000 steps reproduced (28) within 1.0% for $a_T\in\{0.1,0.03,0.01\}$ and $\beta\mu\in\{0.5,1,2,4\}$, and the error fell fourfold for each fourfold refinement (Figure 5). This explains the over-gluing reported in [7]. A constant coupling does not merely miss the soft target; it implements a different, hard one, and so loses the positive spectral information of Theorem 6.1 while appearing to enforce agreement well.

![**Figure 5.** Output scale of a horizontal mode under constant coupling, against $\beta\mu$, for three starting signal levels. Dashed lines are $a_T^{\beta\mu}$ from (28); points are deterministic DDIM simulations. The solid line is the scale required by the exact coupled target.](fig/coupling.png){width=82%}

A model using sheaf message passing inside a denoiser can still learn the score of an uncoupled data law. A model with an explicit coupled target can compute its exact score with ordinary linear algebra. The first is an architectural commitment; the second is a probabilistic commitment. Neither description exhausts the other.

## 7.3 Gluing support does not determine frequencies

Local agreements need not admit a probability distribution with all the proposed context laws. For three binary signs, let the $(A,B)$ and $(B,C)$ laws be uniform on equal pairs, and the $(C,A)$ law uniform on unequal pairs. Every singleton marginal is uniform, but no global assignment satisfies $A = B = C$ and $C \neq A\text{.}$ This elementary obstruction belongs to the marginal-extension question studied in sheaf-theoretic contextuality \[9\]. It is not inferred just from the numerical value of a linear $H^{1}\text{.}$

One constructive alternative declares a proper clean law on compatible finite assignments:

$$P_{0}(y) = Z_{0}^{- 1}\prod_{p}^{}\psi_{p}\left( y_{U_{p}} \right),\quad\quad Z_{0} > 0,\quad\quad\psi_{p} \geq 0. \tag{29}$$

Zeros in the factors define forbidden local patterns. The resulting joint law need not have the empirical patch marginals used to choose those factors; it is a model whose frequencies require calibration. Gaussian corruption of this one law gives a legitimate posterior mean and score,

$$m_{t}(x)\mathbb{= E}\left\lbrack Y \mid X_{t} = x \right\rbrack,\quad\quad\nabla logp_{t}(x) = \frac{a_{t}m_{t}(x) - x}{s_{t}^{2}}. \tag{30}$$

For chain or ring contexts, exact finite-state inference supplies a reference \[10\]. The ASE diffusion manuscript develops this construction and compares it with independent local centre reads \[7\]. Local patch generation has an established analytic account in convolutional diffusion \[8\]; describing its vocabulary as a gluing problem does not by itself turn its assembled local predictions into one joint posterior.

This construction explicitly changes the clean target from archived records to compatible combinations. Its posterior mean stays in the convex hull of the enlarged support. A posterior draw respects the discrete support, while the mean may lie between allowed assignments. A last DDIM mean step therefore does not automatically produce a support-valued sample. Finite integration, terminal approximation and the zero-noise endpoint remain separate issues even when the denoiser is exact.

# 8 Comparing algorithms without awarding a single score

Table 2 compares declared constructions, not implementations whose full details have not been inspected. The neural rows identify their published operator mechanisms. The other rows are explicit reference models. An empty probability obligation for a classifier is not evidence against its structural validity.

Table: **Table 2.** Distinct uses of sheaf structure. Each row needs the evidence named in its final column.

  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Construction                        Structural interface                                 Agreement or probability claim              Necessary evidence
  ----------------------------------- ---------------------------------------------------- ------------------------------------------- ----------------------------------------------------
  Constant-sheaf graph heat           Identity restrictions and graph Laplacian            Preserves existing consensus sections       Graph and metric declaration

  Neural Sheaf Diffusion \[2\]        Learned restrictions and sheaf Laplacian             Relational representation learning          Restriction learning and matched graph controls

  Deep Neural Sheaf Diffusion \[3\]   Learned sheaf adjacency and nonlinear architecture   Modified propagation at depth               Architecture-specific depth and map ablations

  Frozen sheaf heat or resolvent      $L$ assembled from typed maps                        Operator response and kernel preservation   Gram assembly and coefficient sensitivity

  ADE empirical example star          Identity-map record reads                            Exact empirical posterior mean              Fixed record law and sampler qualifications

  ASE partial-observation read        Calibrated maps and normal equations                 Structured proposal or energy descent       Observability and score interpretation

  Correlated baseline noise           Block correlation such as (26)                       Unchanged per-copy baseline law             Conditional noise law and separability

  Soft coupled Gaussian target        $C = (pI + \beta L)^{- 1}$                           Declared joint Gaussian clean law           Correct noised mean, covariance and score

  Intrinsic compatible diffusion      Compatible basis or projector                        Trajectories in $\ker\delta$                Forward covariance, retained dimensions and target

  Probabilistic gluing                Set-valued context support and joint factors         Clean law on compatible combinations        Nonempty support, normalisation and inference
  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Two comparisons follow immediately. Frozen heat depends on positive spectral information but does not send every arbitrary input into the compatible space at finite time. An intrinsic sampler can enforce exact compatibility while retaining only the kernel interface. These constructions are incomparable by the operator and support certificates. Similarly, a correlated-noise sampler can preserve every baseline marginal while violating horizontal agreement, whereas a hard compatible sampler changes those marginals unless the required covariance conditions hold.

The published NSD and DNSD models should not be ordered by whether they look more like classical heat. DNSD's adjacency-based mechanism retains learned relational maps while changing the propagation objective \[3\]. It may have a different energy behaviour from a Laplacian update. Whether that change improves a task is an architectural and empirical question. Local naturality and generative exactness would require additional claims, not an assumption based on either model's name.

There is one implication the comparison does establish. If an implementation erases the typed map factorisation and exposes only $L\text{,}$ it cannot subsequently support distinctions invisible to $L$ without additional metadata. If it further exposes only $\Pi\text{,}$ it cannot distinguish different positive spectra. Those are provable limits on an interface, rather than judgements about the usefulness of its outputs.

# 9 SheafFarm: an executable certificate audit

Table 2 records declared obligations. This section computes certificates instead. It runs eleven reference algorithms on one test bed and records which certificates each verifies. The audit is a measurement on that test bed, not a theorem about the algorithms in general. A failed certificate is a witness against the claim, and a passed one is evidence for it.

The test bed has three parts. The first is the pair of scalar sheaves on $K_4$ from Proposition 3.6, which have the same Laplacian but different holonomy. The second is a flat orthogonal system on $K_4$ with planar stalks and a two-dimensional section space, together with its transform by random vertex rotations. The third is the same system with every restriction doubled, which multiplies $L$ by four and keeps its kernel. The six certificates are computed as follows.

Table: **Table 4.** The certificates computed by the audit.

| Certificate | Computed test | Theory behind it |
|:--|:--|:--|
| E: edge-resolved | Output differs on the two $K_4$ sheaves with equal $L$ | Theorem 3.1, Corollary 3.5 |
| S: positive spectrum | Output differs between $L$ and $4L$, which share a kernel | Theorem 6.1 |
| F: frame covariant | Output, or output covariance, transforms with the vertex rotations | Propositions 4.2, 4.3 |
| P: preserves sections | A compatible input gives a compatible output | Theorem 5.1 |
| C: compatible output | Every output is compatible, or the output covariance is supported on $\ker\delta$ | Section 7.1 |
| Q: declared law | A sampler reproduces its declared law within 1% (exact covariance propagation) | Section 7, Proposition 7.2 |

Table: **Table 5.** Certificates verified by eleven reference algorithms (✓ verified, ✗ failed, – inapplicable).

| Algorithm | E | S | F | P | C | Q |
|:--|:-:|:-:|:-:|:-:|:-:|:-:|
| Constant-sheaf heat | ✗ | ✗ | ✗ | ✗ | ✗ | – |
| Frozen sheaf heat | ✗ | ✓ | ✓ | ✓ | ✗ | – |
| Sheaf resolvent | ✗ | ✓ | ✓ | ✓ | ✗ | – |
| Exact-kernel projector | ✗ | ✗ | ✓ | ✓ | ✓ | – |
| Sheaf layer with ReLU | ✗ | ✓ | ✗ | ✗ | ✗ | – |
| Sheaf layer, radial | ✗ | ✓ | ✓ | ✓ | ✗ | – |
| Edge-resolved message passing | ✓ | ✓ | ✓ | ✓ | ✗ | – |
| Correlated baseline noise | ✗ | ✓ | ✓ | – | ✗ | ✓ |
| Coupled target, exact score | ✗ | ✓ | ✓ | – | ✗ | ✓ |
| Coupled target, constant coupling | ✗ | ✗ | ✓ | – | ✓ | ✗ |
| Intrinsic compatible sampler | ✗ | ✗ | ✓ | – | ✓ | ✓ |

![**Figure 6.** The SheafFarm audit. (a) The certificate matrix of Table 5. (b) The inclusion order of verified certificate sets. Algorithms with equal sets share a box, a line joins a set to the smallest sets containing it, and height is the number of certificates. Orange boxes are maximal: none is dominated.](fig/farm.png){width=100%}

Five findings follow, each anticipated by a proved statement.

- **Only edge-resolved message passing verifies E.** Every other algorithm, including the nonlinear ReLU and radial layers, sees the sheaf through $L$ and gives identical outputs on the $K_4$ pair (Theorem 3.1). The edge-resolved layer applies a radial nonlinearity to each edge residual before summing, and so reads what Corollary 3.5 says the edge Grams carry.
- **Frame covariance is a property of the whole layer.** Frozen heat, the resolvent and the radial layer verify F; the ReLU layer does not (Propositions 4.2, 4.3). Constant-sheaf heat fails F and every other certificate, because it ignores the maps altogether.
- **The radial layer has the certificates of frozen heat.** It is nonlinear, yet it verifies exactly $\{F,P,S\}$. The ReLU layer verifies only $\{S\}$.
- **More agreement, less geometry.** Constant coupling verifies C, with exactly compatible outputs, while failing S and Q. That is Proposition 7.2: it has become the hard law. The exact coupled sampler fails C, as a soft law must, but verifies S and Q.
- **No single winner.** The order has four maximal classes: the kernel projector $\{C,F,P\}$, the intrinsic sampler $\{C,F,Q\}$, correlated noise and the exact coupled sampler $\{F,Q,S\}$, and edge-resolved message passing $\{E,F,P,S\}$. They are pairwise incomparable.

The last finding is the title's claim in its precise form. Some algorithms do use more sheaf than others: edge-resolved message passing dominates frozen heat, and frozen heat dominates the ReLU layer. But "more sheaf" is a partial order with several maximal elements, not a ladder. Which maximal element to build depends on whether the task needs edge information, exact agreement, positive spectral information or a calibrated law.

# 10 An engineering evaluation that could change the design

The first evaluation should use a chain or small cycle of substructures with calibrated shared degrees of freedom. Give each region a local frame, a private variable and an interface variable. Choose the clean target explicitly. This can be a known Gaussian reference or a finite factor model whose feasible assignments can be enumerated. An arbitrary archive read should be described as a proposal algorithm until its target law has been derived.

Three conditions isolate the mechanisms. A tree with consistent rotations tests whether frame-aware assembly helps when all transports are gauge-flattenable. A cycle with known holonomy tests a structural distinction that cannot be removed by local frames. A near-flat cycle tests whether hard constraints discard useful dimensions under calibration error. These conditions keep physical coordinate transformations separate from genuine model misspecification.

Use an identity-map graph control, a gauge-transformed implementation of the same model, a matched block-matrix model, and a factor-aware inference baseline. Match access to constraints, target information, evaluations and compute. Give every method the same noise schedule when comparing samplers. Do not attribute an advantage from extra known equations solely to sheaf topology.

The following predictions are concrete enough to reject.

**P1 --- Coordinate complexity is not intrinsic complexity.** On the flat tree, an implementation claiming local orthogonal frame covariance should give transformed outputs that agree after the inverse frame transformation. A discrepancy exceeding its numerical tolerance refutes that covariance claim. A general coordinatewise nonlinearity is expected to need an adapted rule or a smaller symmetry group.

**P2 --- Finite operator sensitivity survives a kernel match.** With the same initial state, the frozen heat operators for $L_{0}$ and $4L_{0}$ should differ at finite positive time and agree in their limiting projector. A test that observes only the limiting compatible state cannot establish positive-spectrum sensitivity. This follows from Theorem 6.1 rather than from a learned-model hypothesis.

**P3 --- Soft models are preferable when exact holonomy is uncertain.** Under bounded map error, a preregistered finite-time or finite-coupling design should retain useful variation and achieve lower held-out task loss than a hard-kernel model near the rank change. This is a performance hypothesis, not a consequence of the perturbation bounds. Reject it if the paired task-loss interval does not favour the soft model at matched constraint-violation tolerance and compute. Report retained dimensions so that collapse cannot masquerade as agreement.

**P4 --- A probability certificate improves calibration only when implemented.** On a known finite factor target, a matched reverse sampler using its exact posterior should approach that target as integration is refined on positive cutoff intervals. An uncalibrated local read need not do so after rejecting support defects. Freeze a distributional distance and endpoint policy. Failure of the reference to converge within solver tolerances refutes the implementation claim; a search-quality advantage needs a separate objective experiment.

**P5 --- Edge-resolved information matters exactly where the Laplacian is silent.** On labelled pairs from Gram fibres such as Proposition 3.6, every Laplacian-only model is at chance by Theorem 3.1. An edge-resolved model can exceed chance. Measure accuracy on held-out fibre pairs; a Laplacian-only model above chance refutes the implementation claim, because it must be using other information. Away from such pairs, test whether edge resolution improves held-out task loss over a matched Laplacian model. This is the performance hypothesis, and it may fail.

**P6 --- A rank policy inside the gap is stable; an exact one is not.** Under small random perturbations of calibrated maps near a flat cycle, the retained dimension of an exact-kernel model should change, and that of a thresholded model should not, as long as the perturbation stays below $\lambda_{\text{+}}/2$ (Proposition 6.7). Report the retained dimension and the projector distance against the bound (24). A violation of the bound refutes the implementation.

**P7 --- Shallow diffusion cannot see small holonomy on long cycles.** A frozen linear stack of $K<K_{1/2}$ layers (23) should not separate a cycle with holonomy $\varepsilon$ from a flat one by more than the factor $(1-\alpha\lambda_{\min})^K$. A learned diffusion-only network should approach chance on holonomy labels as $\varepsilon$ shrinks or $n$ grows. Separation beyond the factor indicates leakage of edge information and should be traced.

Table: **Table 6.** Measurements with distinct meanings. No weighted sum is proposed.

  ---------------------------------------------------------------------------------------------------------------------------------
  Measurement                                 Interpretation                         Main confound to control
  ------------------------------------------- -------------------------------------- ----------------------------------------------
  Output change under admissible maps         Sensitivity of a declared interface    Changed input information or coordinates

  Frame transformation defect                 Complete-model covariance              Frozen rather than transformed decoder

  Incidence square defect                     Local naturality                       Substitution of a global edge map

  Agreement residual and retained dimension   Compatibility and possible collapse    Units, noise scale and rank policy

  Joint and marginal distribution distances   Target fidelity and batch dependence   Terminal law, cutoff and integration error

  Task loss and total compute                 Practical value                        Unequal constraints, retrieval or basis cost
  ---------------------------------------------------------------------------------------------------------------------------------

## 10.1 Small mathematical checks

The companion script records 39 deterministic checks, all passing in its saved runtime. 17 rebuild the Version 1 checks from the statements of this paper, using their own random instances where Version 1 used random examples. 22 check the Version 2 results and the audit. They illustrate exact examples and bounds, not learned-model performance.

Table: **Table 7.** Recorded values of selected checks.

| Result | Check | Recorded value |
|:--|:--|:--|
| Example 3.2 | First cohomology of the same-Gram pair | 0 and 1 |
| Example 3.3 | Loop multipliers of the parallel-edge pair | 3/2 and 11/6 |
| Theorem 4.1 | Tree gauge-flattening residual | 6.66 × 10⁻¹⁶ |
| Example 5.2 | Best local square defect; global factorisation residual | 3; 1.33 × 10⁻¹⁵ |
| Theorem 6.1 | Path heat difference at $t=1$ ($L_0$ against $4L_0$) | 0.349564 |
| Proposition 6.2 | Gaussian reconstruction of $L$ | 3.02 × 10⁻¹⁴ |
| Theorem 6.3 | $\lambda_{\min}$ at $\varepsilon=0.003$; error from (17) | 1.00 × 10⁻⁶; 4.97 × 10⁻¹⁶ |
| Theorem 7.1 | Frustrated-cycle residual with unit marginals ($\tau=0.5$) | 3.903308 |
| Theorem 3.4 | Isometry residual on the Example 3.3 pair | 3.77 × 10⁻¹⁵ |
| Proposition 3.6 | $K_4$ Jacobian rank; Laplacian drift along the fibre | 10 of 12; 8.88 × 10⁻¹⁶ |
| Corollary 3.5 | Transport recovery from edge Grams | 2.22 × 10⁻¹⁶ |
| Proposition 4.3 | Frame defect, radial against ReLU | 1.11 × 10⁻¹⁶ against 0.582 |
| Proposition 6.5 | Largest spectral error, random holonomies, $n=3,5,8$ | 3.11 × 10⁻¹⁵ |
| Corollary 6.6 | Half-amplitude depth, 9 cases | Exact in every case |
| Proposition 6.7 | Thresholded projector at $\varepsilon=0.1$ against bound | 0.0272 against 0.0345 |
| Proposition 7.2 | Largest error from $a_T^{\beta\mu}$, 80,000 steps | 0.96% |
| C# kernel | Largest relative difference from NumPy, 13 lines | 2.03 × 10⁻¹⁵ |

All displayed numerical values are read from the result files. The Version 1 script was not part of this revision's inputs, so its checks were rebuilt; the rebuilt values agree with every number quoted in Version 1 that does not depend on a random instance, including 0.349564, 3.903308 and the $10^{-6}$ eigenvalue. The paper's main findings remain proved statements about finite-dimensional interfaces and explicit limiting examples.

# 11 What should count as more sheaf

A claim that an algorithm is more sheaf-based should name the additional structural commitment. Does it retain calibrated edge comparisons that a Gram-only interface hides? Does it respect an allowed change of local frame? Does it provide local naturality where that is actually required? Does it preserve compatible support? Does it sample a declared law on that support? Each question has a different mathematical witness.

The strongest conclusion is that enforcing more agreement can retain less geometry. Infinite-time heat and hard Gaussian coupling collapse the operator to its kernel. That kernel can change discontinuously under an arbitrarily small nontrivial holonomy, even though finite diffusion remains continuous. Soft and hard constructions therefore address different needs rather than occupying successive levels of one quality ladder.

For ASE and its diffusion ancestry, the useful next step is to make these interfaces explicit in code and compare them under a known target. The sheaf specifies the local comparisons. The algorithm chooses which information to retain. The probability model determines which generation claims follow. Task performance decides which commitment is worth its cost.

Version 2 adds a positive side to these separations. The information a Laplacian hides is exactly an edge-space isometry, and the edge-resolved Grams restore it. Holonomy that diffusion can barely see on a long cycle can be read directly from those Grams. The discontinuity of hard compatibility is a property of the exact-kernel policy, and a threshold inside the gap removes it at a declared price. A constant coupling force is not a cheap soft target but a hard one in disguise. Computed over eleven algorithms, the certificates form a partial order with several maximal elements. Some sheaf-diffusion algorithms are indeed more sheaf than others, but none is most sheaf in every respect.

# References

\[1\] Hansen, J. and Ghrist, R. (2019). Toward a Spectral Theory of Cellular Sheaves. *Journal of Applied and Computational Topology* 3, 315--358. https://arxiv.org/abs/1808.01513

\[2\] Bodnar, C., Di Giovanni, F., Chamberlain, B. P., Liò, P. and Bronstein, M. M. (2022). Neural Sheaf Diffusion: A Topological Perspective on Heterophily and Oversmoothing in GNNs. *Advances in Neural Information Processing Systems* 35. https://arxiv.org/abs/2202.04579

\[3\] Bourgerie, R., Girdzijauskas, Š. and Fodor, V. (2026). Deep Neural Sheaf Diffusion. arXiv:2605.19021v2. ICML 2026 Workshop on Graph Foundation Models. https://arxiv.org/abs/2605.19021v2

\[4\] Ho, J., Jain, A. and Abbeel, P. (2020). Denoising Diffusion Probabilistic Models. *Advances in Neural Information Processing Systems* 33. https://arxiv.org/abs/2006.11239

\[5\] Song, J., Meng, C. and Ermon, S. (2021). Denoising Diffusion Implicit Models. *International Conference on Learning Representations*. https://arxiv.org/abs/2010.02502

\[6\] Song, Y., Sohl-Dickstein, J., Kingma, D. P., Kumar, A., Ermon, S. and Poole, B. (2021). Score-Based Generative Modeling through Stochastic Differential Equations. *International Conference on Learning Representations*. https://arxiv.org/abs/2011.13456

\[7\] Ghosh, D. P. (2026). Sheaf Structured Generative Diffusion. Version 3, 19 October 2026. https://github.com/debiprasadghosh/ResearchOverFlow/tree/main/October2026/SheafDiffusion

\[8\] Kamb, M. and Ganguli, S. (2025). An analytic theory of creativity in convolutional diffusion models. *International Conference on Machine Learning*. https://arxiv.org/abs/2412.20292

\[9\] Abramsky, S. and Brandenburger, A. (2011). The Sheaf-Theoretic Structure of Non-Locality and Contextuality. *New Journal of Physics* 13, 113036. https://arxiv.org/abs/1102.0264

\[10\] Kschischang, F. R., Frey, B. J. and Loeliger, H.-A. (2001). Factor graphs and the sum-product algorithm. *IEEE Transactions on Information Theory* 47(2), 498--519. https://doi.org/10.1109/18.910572

\[11\] Zhang, Y., Hartl, B., Hazan, H. and Levin, M. (2025). Diffusion Models are Evolutionary Algorithms. *International Conference on Learning Representations*. arXiv:2410.02543v3. https://arxiv.org/abs/2410.02543v3

\[12\] Davis, C. and Kahan, W. M. (1970). The rotation of eigenvectors by a perturbation. III. *SIAM Journal on Numerical Analysis* 7(1), 1--46. https://doi.org/10.1137/0707001

# Appendix A. An immutable C# reference kernel

The kernel implements typed restrictions with the Gram and edge-resolved interfaces (Theorem 3.4, Corollary 3.5), the cycle spectrum and depth law (22)–(23), a thresholded projector with its Davis–Kahan certificate (24), radial frame-covariant layers (Proposition 4.3) and the coupling factors of (28). It uses immutable records, `ImmutableArray<double>` and pure static functions; the Jacobi eigensolver works on private copies. A validation program prints 13 lines on fixed inputs, including the Example 3.3 pair, the $K_4$ starting sheaf and the rotation triangle. An independent NumPy implementation recomputes each line.

```csharp
// SheafFarm reference kernel (Version 2): typed restrictions, the Gram and
// edge-resolved interfaces, cycle spectra, a thresholded kernel with its
// Davis-Kahan certificate, radial frame-covariant layers and the constant-
// coupling factor. Immutable records and pure static functions; the Jacobi
// eigensolver works on private copies.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace SheafFarm;

/// <summary>A dense real matrix stored row-major.</summary>
public sealed record Matrix(int Rows, int Cols, Vec Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Matrix Zero(int r, int c) =>
        new(r, c, Enumerable.Repeat(0.0, r * c).ToImmutableArray());

    public static Matrix Identity(int n) =>
        new(n, n, Enumerable.Range(0, n * n)
            .Select(k => k / n == k % n ? 1.0 : 0.0).ToImmutableArray());

    public static Matrix FromRows(params double[][] rows) =>
        new(rows.Length, rows[0].Length,
            rows.SelectMany(r => r).ToImmutableArray());

    public Matrix Transpose() =>
        new(Cols, Rows, Enumerable.Range(0, Rows * Cols)
            .Select(k => this[k % Rows, k / Rows]).ToImmutableArray());

    public Matrix Times(Matrix b) =>
        new(Rows, b.Cols, Enumerable.Range(0, Rows * b.Cols)
            .Select(k => Enumerable.Range(0, Cols)
                .Sum(j => this[k / b.Cols, j] * b[j, k % b.Cols]))
            .ToImmutableArray());

    public Vec Apply(Vec x) =>
        Enumerable.Range(0, Rows)
            .Select(i => Enumerable.Range(0, Cols).Sum(j => this[i, j] * x[j]))
            .ToImmutableArray();

    public Matrix Combine(double a, Matrix b, double c) =>
        this with { Data = Data.Zip(b.Data, (p, q) => a * p + c * q)
                               .ToImmutableArray() };

    public double MaxAbs => Data.Max(Math.Abs);

    /// <summary>Eigenvalues (ascending) and orthonormal eigenvectors (columns)
    /// of a symmetric matrix, by cyclic Jacobi rotations on private
    /// copies.</summary>
    public (Vec Values, Matrix Vectors) SymmetricEigen()
    {
        int n = Rows;
        var a = Data.ToArray();
        var v = Identity(n).Data.ToArray();
        for (int sweep = 0; sweep < 100; sweep++)
        {
            double off = 0.0;
            for (int p = 0; p < n; p++)
                for (int q = p + 1; q < n; q++) off += a[p * n + q] * a[p * n + q];
            if (off < 1e-300) break;
            for (int p = 0; p < n - 1; p++)
                for (int q = p + 1; q < n; q++)
                {
                    double apq = a[p * n + q];
                    if (apq == 0.0) continue;
                    double th = (a[q * n + q] - a[p * n + p]) / (2.0 * apq);
                    double t = th == 0.0 ? 1.0
                        : Math.Sign(th) / (Math.Abs(th) + Math.Sqrt(th * th + 1.0));
                    double c = 1.0 / Math.Sqrt(t * t + 1.0), s = t * c;
                    for (int k = 0; k < n; k++)
                        (a[k * n + p], a[k * n + q]) =
                            (c * a[k * n + p] - s * a[k * n + q],
                             s * a[k * n + p] + c * a[k * n + q]);
                    for (int k = 0; k < n; k++)
                        (a[p * n + k], a[q * n + k]) =
                            (c * a[p * n + k] - s * a[q * n + k],
                             s * a[p * n + k] + c * a[q * n + k]);
                    for (int k = 0; k < n; k++)
                        (v[k * n + p], v[k * n + q]) =
                            (c * v[k * n + p] - s * v[k * n + q],
                             s * v[k * n + p] + c * v[k * n + q]);
                }
        }
        var order = Enumerable.Range(0, n).OrderBy(i => a[i * n + i]).ToArray();
        var values = order.Select(i => a[i * n + i]).ToImmutableArray();
        var vectors = new Matrix(n, n, Enumerable.Range(0, n * n)
            .Select(k => v[(k / n) * n + order[k % n]]).ToImmutableArray());
        return (values, vectors);
    }
}

/// <summary>One edge v -> w with restrictions; residual Rw x_w - Rv x_v.</summary>
public sealed record Edge(int V, int W, Matrix Rv, Matrix Rw);

/// <summary>A typed cellular sheaf on a graph, vertex dimension d.</summary>
public sealed record TypedSheaf(int Vertices, int Dim, ImmutableArray<Edge> Edges)
{
    /// <summary>The coboundary block of one edge (de x Vertices*Dim).</summary>
    public Matrix EdgeBlock(Edge e)
    {
        int n = Vertices * Dim, de = e.Rv.Rows;
        return new Matrix(de, n, Enumerable.Range(0, de * n).Select(k =>
        {
            int r = k / n, c = k % n, vert = c / Dim, j = c % Dim;
            return (vert == e.V ? -e.Rv[r, j] : 0.0)
                 + (vert == e.W ? e.Rw[r, j] : 0.0);
        }).ToImmutableArray());
    }

    /// <summary>The edge-resolved interface: one Gram matrix per edge.</summary>
    public ImmutableArray<Matrix> EdgeGrams() =>
        Edges.Select(e => { var b = EdgeBlock(e); return b.Transpose().Times(b); })
             .ToImmutableArray();

    /// <summary>The Gram interface L: the sum of the edge Grams.</summary>
    public Matrix Laplacian() =>
        EdgeGrams().Aggregate(Matrix.Zero(Vertices * Dim, Vertices * Dim),
                              (acc, g) => acc.Combine(1, g, 1));

    /// <summary>Scalar stalks: transport r_v/r_w of each edge, read from its
    /// edge Gram alone (Corollary 3.5).</summary>
    public Vec TransportsFromEdgeGrams() =>
        Edges.Zip(EdgeGrams(), (e, g) => -g[e.V, e.W] / g[e.W, e.W])
             .ToImmutableArray();
}

public static class Farm
{
    /// <summary>Proposition 6.5: smallest eigenvalue of a rotation by eps
    /// distributed around an n-cycle with planar stalks.</summary>
    public static double CycleLambdaMin(double eps, int n) =>
        4 * Math.Pow(Math.Sin(eps / (2.0 * n)), 2);

    /// <summary>Corollary 6.6: layers of x -> (I - alpha L) x before the
    /// slowest holonomy mode has lost half its amplitude.</summary>
    public static int HolonomyDepth(double eps, int n, double alpha) =>
        (int)Math.Ceiling(Math.Log(2)
                          / -Math.Log(1 - alpha * CycleLambdaMin(eps, n)));

    /// <summary>Proposition 6.7: projector onto eigenvectors below theta.</summary>
    public static Matrix ThresholdedProjector(Matrix l, double theta)
    {
        var (vals, vecs) = l.SymmetricEigen();
        int n = l.Rows;
        var keep = Enumerable.Range(0, n).Where(i => vals[i] < theta).ToArray();
        return new Matrix(n, n, Enumerable.Range(0, n * n)
            .Select(k => keep.Sum(i => vecs[k / n, i] * vecs[k % n, i]))
            .ToImmutableArray());
    }

    /// <summary>Davis-Kahan certificate ||E|| / (lambda_plus - ||E||), valid
    /// when ||E|| is below lambda_plus / 2.</summary>
    public static double DavisKahanBound(double perturbation, double lambdaPlus) =>
        perturbation < lambdaPlus / 2 ? perturbation / (lambdaPlus - perturbation)
                                      : double.NaN;

    /// <summary>Proposition 4.3: x_v -> x_v tanh(|x_v|)/|x_v| at each
    /// vertex.</summary>
    public static Vec Radial(Vec x, int dim) =>
        Enumerable.Range(0, x.Length).Select(k =>
        {
            int v = k / dim;
            double nrm = Math.Sqrt(Enumerable.Range(v * dim, dim)
                                             .Sum(j => x[j] * x[j]));
            return nrm > 0 ? x[k] * Math.Tanh(nrm) / nrm : x[k];
        }).ToImmutableArray();

    /// <summary>One sheaf layer x -> sigma(x - alpha L x).</summary>
    public static Vec Layer(Matrix l, Vec x, double alpha, Func<Vec, Vec> sigma) =>
        sigma(x.Zip(l.Apply(x), (p, q) => p - alpha * q).ToImmutableArray());

    public static Vec Relu(Vec x) =>
        x.Select(v => Math.Max(v, 0)).ToImmutableArray();

    /// <summary>Proposition 7.2: the factor by which a constant force
    /// -beta L x scales a mode of eigenvalue mu under the probability flow
    /// started at signal level aT, and the factor the exact target needs.</summary>
    public static (double Constant, double Exact) CouplingFactors(
        double betaMu, double aT, double p) =>
        (Math.Pow(aT, betaMu), Math.Sqrt(p / (p + betaMu)));
}
```

Table: **Table 8.** C# against NumPy, line by line (.NET 8.0.131).

| Output | C# values | Largest relative difference |
|:--|:--|--:|
| pair laplacian a | 5, −7, −7, 10 | 0 |
| pair laplacian b | 5, −7, −7, 10 | 1.78 × 10⁻¹⁶ |
| pair transports | 1, 0.666667, 0.733333, 0.4 | 3.33 × 10⁻¹⁶ |
| k4 laplacian | 3.46, −0.96, −1.35, … (16 values) | 1.54 × 10⁻¹⁶ |
| k4 transports | 1.5, 0.6, 1.57143, … (6 values) | 1.12 × 10⁻¹⁵ |
| cycle eigenvalues | 0.00111101, 0.00111101, 2.94172, … (6 values) | 2.03 × 10⁻¹⁵ |
| cycle lambda min formula | 0.00111101, 0.000624967 | 4.12 × 10⁻¹⁸ |
| holonomy depth | 2496, 4437 | 0 |
| threshold projector | 0.0222058, 2 | 6.66 × 10⁻¹⁶ |
| davis kahan | 0.0714286, 1 | 4.16 × 10⁻¹⁷ |
| frame defects | 1.11022e−16, 0.518301 | 3.33 × 10⁻¹⁶ |
| radial layer | 0.219029, −0.654554, 0.535426, … (6 values) | 4.44 × 10⁻¹⁶ |
| coupling factors | 0.1, 0.816497, 0.01, … (8 values) | 4.44 × 10⁻¹⁶ |
