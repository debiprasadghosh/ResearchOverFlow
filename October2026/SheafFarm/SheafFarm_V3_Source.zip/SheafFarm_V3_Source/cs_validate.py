"""Run the C# kernel and recompute every printed line with independent NumPy code."""
from pathlib import Path
import json, math, subprocess, shutil
import numpy as np

P = Path(__file__).resolve().parent
compiler=shutil.which('dotnet')
if compiler:
    subprocess.run([compiler, 'build', '-c', 'Release'], cwd=P/'cs', check=True, capture_output=True)
    cs=subprocess.run([compiler, str(P/'cs/bin/Release/net8.0/SheafFarm.dll')],capture_output=True,text=True,check=True).stdout.strip().splitlines()
    execution_mode='fresh_compilation'
else:
    cs=(P/'cs/cs_out.txt').read_text().strip().splitlines()
    execution_mode='archived_CSharp_output_rechecked'



def rot(a):
    return np.array([[math.cos(a), -math.sin(a)], [math.sin(a), math.cos(a)]])


def lap(nv, d, edges):
    rows = []
    for v, w, Rv, Rw in edges:
        blk = np.zeros((Rv.shape[0], nv * d)); blk[:, v * d:(v + 1) * d] -= Rv; blk[:, w * d:(w + 1) * d] += Rw
        rows.append(blk)
    B = np.vstack(rows); return B.T @ B


s = lambda a: np.array([[a]])
py = []
La = lap(2, 1, [(0, 1, s(1), s(1)), (0, 1, s(2), s(3))]); Lb = lap(2, 1, [(0, 1, s(11 / 5), s(3)), (0, 1, s(2 / 5), s(1))])
py += [('pair_laplacian_a', La.ravel()), ('pair_laplacian_b', Lb.ravel()), ('pair_transports', [1, 2 / 3, 11 / 15, 2 / 5])]
r0 = [1.2, 0.8, 0.9, 1.5, 1.1, 0.7, 1.3, 1.0, 0.6, 1.4, 1.6, 0.9]
pairs = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
py.append(('k4_laplacian', lap(4, 1, [(v, w, s(r0[2 * k]), s(r0[2 * k + 1])) for k, (v, w) in enumerate(pairs)]).ravel()))
py.append(('k4_transports', [r0[2 * k] / r0[2 * k + 1] for k in range(6)]))
I2 = np.eye(2)
cyc = lambda e: lap(3, 2, [(0, 1, I2, I2), (1, 2, I2, I2), (2, 0, rot(e), I2)])
L0, Le = cyc(0.0), cyc(0.1)
py.append(('cycle_eigenvalues', np.linalg.eigvalsh(Le)))
py.append(('cycle_lambda_min_formula', [4 * math.sin(0.1 / 6) ** 2, 4 * math.sin(0.3 / 24) ** 2]))
dep = lambda e, n, a: math.ceil(math.log(2) / -math.log(1 - a * 4 * math.sin(e / (2 * n)) ** 2))
py.append(('holonomy_depth', [dep(0.1, 3, .25), dep(0.3, 12, .25)]))


def tproj(L, th):
    w, V = np.linalg.eigh(L); K = V[:, w < th]; return K @ K.T


Pe, P0 = tproj(Le, 1.5), tproj(L0, 1.5)
py.append(('threshold_projector', [np.abs(Pe - P0).max(), np.trace(Pe)]))
py.append(('davis_kahan', [0.2 / 2.8, 1]))
x = np.array([0.3, -1.2, 0.8, 0.5, -0.4, 1.1]); G = np.eye(6); G[:2, :2] = rot(0.7)
Lg = G @ Le @ G.T


def radial(z):
    out = z.copy()
    for v in range(3):
        y = z[2 * v:2 * v + 2]; n = np.linalg.norm(y); out[2 * v:2 * v + 2] = y * math.tanh(n) / n
    return out


layer = lambda L, z, f: f(z - 0.1 * L @ z)
relu = lambda z: np.maximum(z, 0)
py.append(('frame_defects', [np.abs(layer(Lg, G @ x, radial) - G @ layer(Le, x, radial)).max(),
                             np.abs(layer(Lg, G @ x, relu) - G @ layer(Le, x, relu)).max()]))
py.append(('radial_layer', layer(Le, x, radial)))
py.append(('coupling_factors', [v for bm in (0.5, 1, 2, 4) for v in (0.01 ** bm, math.sqrt(1 / (1 + bm)))]))

per = []; pyl = []
for line, (name, vals) in zip(cs, py):
    head, *nums = line.split(); assert head == name, (head, name)
    c = np.array([float(t) for t in nums]); v = np.array(vals, float)
    per.append(float(np.max(np.abs(c - v) / np.maximum(1, np.abs(v)))))
    pyl.append(name + ' ' + ' '.join(f'{t:.15g}' for t in v))
out = {'lines': len(cs), 'max_relative_difference': max(per), 'per_line': per, 'csharp': cs, 'python': pyl,
       'execution_mode':execution_mode, 'dotnet':subprocess.run([compiler,'--version'],capture_output=True,text=True).stdout.strip() if compiler else 'V2 archived .NET 8.0.131 output'}
(P / 'cs_validate.json').write_text(json.dumps(out, indent=1) + '\n')
for (n, _), e in zip(py, per):
    print(f'{n:28s} {e:.2e}')
assert len(cs) == len(py) and max(per) < 1e-12
print('C# agrees with NumPy on', len(cs), 'lines')
