"""Figures 3-6 of Version 2 from results.json (Figures 1-2 are kept from Version 1)."""
from pathlib import Path
import json, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

P = Path(__file__).resolve().parent
(P / 'fig').mkdir(exist_ok=True)
r = json.loads((P / 'results.json').read_text())['v2']
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10, 'axes.spines.top': False,
                     'axes.spines.right': False})
blue, orange, grey, ink = '#28689b', '#c9692e', '#58636d', '#1f2328'

# ---------------------------------------------------------------- Figure 3: the K4 Gram fibre
path = r['k4_fibre']['path']; s = [q['s'] for q in path]
fig, axs = plt.subplots(1, 2, figsize=(10, 3.5), gridspec_kw={'width_ratios': [1.4, 1]})
for key, lab, c, ls in (('h012', 'triangle 0–1–2', blue, '-'), ('h013', 'triangle 0–1–3', orange, '--'),
                        ('h023', 'triangle 0–2–3', grey, '-.')):
    axs[0].plot(s, [q[key] for q in path], c=c, ls=ls, lw=2, label=lab)
axs[0].set(xlabel='cumulative predictor step on the fixed-Gram continuation', ylabel='cycle holonomy (loop multiplier)')
axs[0].set_title('(a) holonomy moves while L stays fixed', fontsize=10)
axs[0].legend(frameon=False, fontsize=8.8); axs[0].grid(alpha=.15)
res = [max(q['res'], 1e-17) for q in path[1:]]
axs[1].semilogy(s[1:], res, 'o', ms=3, c=blue)
axs[1].axhline(1e-12, c=orange, ls=':', lw=1.2); axs[1].text(s[-1], 2e-12, 'check tolerance', ha='right', fontsize=8.4, color=orange)
axs[1].set(xlabel='cumulative predictor step', ylabel='largest change in any entry of L', ylim=(1e-17, 1e-10))
axs[1].set_title('(b) Laplacian residual along the path', fontsize=10); axs[1].grid(alpha=.15, which='both')
fig.tight_layout(); fig.savefig(P / 'fig/fibre.png', dpi=220, facecolor='white'); plt.close(fig)

# ---------------------------------------------------------------- Figure 4: cycle length and rank policy
fig, axs = plt.subplots(1, 2, figsize=(10, 3.6))
rows = r['cycle_spectrum']['rows']; eg = np.logspace(-2.2, 0.2, 200)
for n, c in zip((3, 6, 12, 24), ('#9ec5e8', '#5a9bd4', blue, '#163f61')):
    pts = [q for q in rows if q['n'] == n]
    axs[0].loglog(eg, 4 * np.sin(eg / (2 * n)) ** 2, c=c, lw=1.6, label=f'n = {n}')
    axs[0].scatter([q['eps'] for q in pts], [q['lambda_min'] for q in pts], c=c, s=22, zorder=3)
axs[0].set(xlabel='holonomy angle ε (radians)', ylabel='smallest eigenvalue of L')
axs[0].set_title('(a) λ_min = 4 sin²(ε/2n): long cycles slow damping', fontsize=10)
axs[0].legend(frameon=False, fontsize=8.6, title='cycle length', title_fontsize=8.6); axs[0].grid(alpha=.15, which='both')
th = r['threshold']['rows']; e = [q['eps'] for q in th]
axs[1].semilogx(e, [q['exact_kernel_distance'] for q in th], 's-', c=orange, lw=2, label='exact kernel (tolerance 1e-12)')
axs[1].semilogx(e, [q['threshold_distance'] for q in th], 'o-', c=blue, lw=2, label='threshold λ₊/2')
okb = [(q['eps'], q['bound']) for q in th if q['bound'] == q['bound']]
axs[1].semilogx([a for a, _ in okb], [b for _, b in okb], ':', c=grey, lw=1.6, label='Davis–Kahan bound')
axs[1].set(xlabel='holonomy angle ε (radians)', ylabel='distance from the flat projector', ylim=(-0.03, 1.1))
axs[1].set_title('(b) a rank policy restores continuity', fontsize=10)
axs[1].legend(frameon=False, fontsize=8.6, loc='center left'); axs[1].grid(alpha=.15, which='both')
fig.tight_layout(); fig.savefig(P / 'fig/cycles.png', dpi=220, facecolor='white'); plt.close(fig)

# ---------------------------------------------------------------- Figure 5: constant coupling collapses
cc = r['constant_coupling']['rows']
fig, ax = plt.subplots(figsize=(7.4, 3.6))
bm = np.linspace(0, 4.2, 100)
ax.semilogy(bm, np.sqrt(1 / (1 + bm)), c=ink, lw=2.2, label='exact coupled target, √(p/(p+βμ))')
for aT, c, mk in ((0.1, '#5a9bd4', 'o'), (0.03, blue, 's'), (0.01, '#163f61', 'd')):
    ax.semilogy(bm, aT ** bm, c=c, lw=1.4, ls='--')
    pts = [q for q in cc if q['a_T'] == aT]
    ax.scatter([q['beta_mu'] for q in pts], [q['ratio'] for q in pts], c=c, marker=mk, s=34, zorder=3,
               label=f'constant force, start a_T = {aT}')
ax.set(xlabel='βμ (coupling strength × Laplacian eigenvalue)', ylabel='output scale of the mode', ylim=(1e-9, 2))
ax.set_title('Constant coupling scales each mode by a_T^βμ (dashed lines; points simulated)', fontsize=10)
ax.legend(frameon=False, fontsize=8.4, loc='lower left'); ax.grid(alpha=.15, which='both')
fig.tight_layout(); fig.savefig(P / 'fig/coupling.png', dpi=220, facecolor='white'); plt.close(fig)



# Figure 6: eigenmode residuals expose finite suppression without cancellation.
a=np.logspace(-4,-.2,200);expected=24*a**8
fig,ax=plt.subplots(figsize=(7.4,3.6))
ax.loglog(a,expected,c=blue,lw=2,label=r'finite expected residual $24a_T^8$')
ax.axhline(1e-9,c=orange,ls='--',label=r'reference numerical level $10^{-9}$')
ax.scatter([.01],[24*.01**8],c=ink,zorder=4)
ax.annotate(r'$a_T=0.01$: positive residual',xy=(.01,24*.01**8),xytext=(.0003,1e-5),fontsize=9,arrowprops={'arrowstyle':'->','color':grey})
ax.set(xlabel=r'positive starting signal $a_T$',ylabel='expected squared agreement residual',ylim=(1e-32,1))
ax.set_title('Below a numerical tolerance does not mean zero',fontsize=11)
ax.legend(frameon=False,fontsize=9,loc='lower right');ax.grid(alpha=.15,which='both')
fig.tight_layout();fig.savefig(P/'fig/farm_v3.png',dpi=230,facecolor='white');plt.close(fig)
print('V3 figures written')
