# SheafFarm: Some Sheaf-Diffusion Algorithms are More Sheaf Than Others, Version 2

Source for the Word paper by Debi Prasad Ghosh, 20 October 2026.

Version 2 keeps the Version 1 text and adds: the Gram fibre theorem (3.4), the
edge-resolved interface (3.5), a continuum of holonomies under one Laplacian on
K4 (3.6), radial frame-covariant layers (4.3), the n-cycle spectrum and depth
law (6.5, 6.6), a Davis-Kahan rank-threshold certificate (6.7), the collapse of
constant coupling to the hard law, a_T^(beta mu) (7.2), and the SheafFarm
certificate audit of eleven reference algorithms (Section 9).

## Rebuild

Python 3 with NumPy, SciPy, Matplotlib, python-docx, lxml; Pandoc; .NET 8 SDK.

    python farm_checks.py   # 39 checks (17 rebuilt from V1, 22 new) -> results.json
    python cs_validate.py   # builds cs/, compares 13 output lines with NumPy
    python figures.py       # Figures 2 and 4-6 (Figures 1 and 3 are from V1)
    python render.py        # V1 text + blocks.md + values -> paper.md
    python build.py         # Word file in output/

The Version 1 check script was not among the inputs, so its checks were rebuilt
from the statements in the paper; every V1 number that does not depend on a
random instance is reproduced exactly (0.349564, 3.903308, 1e-6 eigenvalue).
