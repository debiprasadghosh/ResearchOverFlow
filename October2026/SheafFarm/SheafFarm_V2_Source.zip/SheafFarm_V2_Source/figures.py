"""Figures 3-6 of Version 2 from results.json (Figures 1-2 are kept from Version 1)."""
from pathlib import Path
import json, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

P = Path(__file__).resolve().parent
(P / 'fig').mkdir(exist_ok=True)
r = json.loads((P / 'results.json').read_text())['v2']
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10, 'axes.spines.top': False,
                     'axes.spines.right': False})
blue, orange, grey, ink = '#28689b', '#c9692e', '#58636d', '#1f2328'

# ---------------------------------------------------------------- Figure 3: the K4 Gram fibre
path = r['k4_fibre']['path']; s = [q['s'] for q in path]
fig, axs = plt.subplots(1, 2, figsize=(10, 3.5), gridspec_kw={'width_ratios': [1.4, 1]})
for key, lab, c, ls in (('h012', 'triangle 0–1–2', blue, '-'), ('h013', 'triangle 0–1–3', orange, '--'),
                        ('h023', 'triangle 0–2–3', grey, '-.')):
    axs[0].plot(s, [q[key] for q in path], c=c, ls=ls, lw=2, label=lab)
axs[0].set(xlabel='arc length along the set of sheaves with the same Laplacian', ylabel='cycle holonomy (loop multiplier)')
axs[0].set_title('(a) holonomy moves while L stays fixed', fontsize=10)
axs[0].legend(frameon=False, fontsize=8.8); axs[0].grid(alpha=.15)
res = [max(q['res'], 1e-17) for q in path[1:]]
axs[1].semilogy(s[1:], res, 'o', ms=3, c=blue)
axs[1].axhline(1e-12, c=orange, ls=':', lw=1.2); axs[1].text(s[-1], 2e-12, 'check tolerance', ha='right', fontsize=8.4, color=orange)
axs[1].set(xlabel='arc length', ylabel='largest change in any entry of L', ylim=(1e-17, 1e-10))
axs[1].set_title('(b) Laplacian residual along the path', fontsize=10); axs[1].grid(alpha=.15, which='both')
fig.tight_layout(); fig.savefig(P / 'fig/fibre.png', dpi=220, facecolor='white'); plt.close(fig)

# ---------------------------------------------------------------- Figure 4: cycle length and rank policy
fig, axs = plt.subplots(1, 2, figsize=(10, 3.6))
rows = r['cycle_spectrum']['rows']; eg = np.logspace(-2.2, 0.2, 200)
for n, c in zip((3, 6, 12, 24), ('#9ec5e8', '#5a9bd4', blue, '#163f61')):
    pts = [q for q in rows if q['n'] == n]
    axs[0].loglog(eg, 4 * np.sin(eg / (2 * n)) ** 2, c=c, lw=1.6, label=f'n = {n}')
    axs[0].scatter([q['eps'] for q in pts], [q['lambda_min'] for q in pts], c=c, s=22, zorder=3)
axs[0].set(xlabel='holonomy angle ε (radians)', ylabel='smallest eigenvalue of L')
axs[0].set_title('(a) λ_min = 4 sin²(ε/2n): long cycles hide holonomy', fontsize=10)
axs[0].legend(frameon=False, fontsize=8.6, title='cycle length', title_fontsize=8.6); axs[0].grid(alpha=.15, which='both')
th = r['threshold']['rows']; e = [q['eps'] for q in th]
axs[1].semilogx(e, [q['exact_kernel_distance'] for q in th], 's-', c=orange, lw=2, label='exact kernel (tolerance 1e-12)')
axs[1].semilogx(e, [q['threshold_distance'] for q in th], 'o-', c=blue, lw=2, label='threshold λ₊/2')
okb = [(q['eps'], q['bound']) for q in th if q['bound'] == q['bound']]
axs[1].semilogx([a for a, _ in okb], [b for _, b in okb], ':', c=grey, lw=1.6, label='Davis–Kahan bound')
axs[1].set(xlabel='holonomy angle ε (radians)', ylabel='distance from the flat projector', ylim=(-0.03, 1.1))
axs[1].set_title('(b) a rank policy restores continuity', fontsize=10)
axs[1].legend(frameon=False, fontsize=8.6, loc='center left'); axs[1].grid(alpha=.15, which='both')
fig.tight_layout(); fig.savefig(P / 'fig/cycles.png', dpi=220, facecolor='white'); plt.close(fig)

# ---------------------------------------------------------------- Figure 5: constant coupling collapses
cc = r['constant_coupling']['rows']
fig, ax = plt.subplots(figsize=(7.4, 3.6))
bm = np.linspace(0, 4.2, 100)
ax.semilogy(bm, np.sqrt(1 / (1 + bm)), c=ink, lw=2.2, label='exact coupled target, √(p/(p+βμ))')
for aT, c, mk in ((0.1, '#5a9bd4', 'o'), (0.03, blue, 's'), (0.01, '#163f61', 'd')):
    ax.semilogy(bm, aT ** bm, c=c, lw=1.4, ls='--')
    pts = [q for q in cc if q['a_T'] == aT]
    ax.scatter([q['beta_mu'] for q in pts], [q['ratio'] for q in pts], c=c, marker=mk, s=34, zorder=3,
               label=f'constant force, start a_T = {aT}')
ax.set(xlabel='βμ (coupling strength × Laplacian eigenvalue)', ylabel='output scale of the mode', ylim=(1e-9, 2))
ax.set_title('Constant coupling scales each mode by a_T^βμ (dashed lines; points simulated)', fontsize=10)
ax.legend(frameon=False, fontsize=8.4, loc='lower left'); ax.grid(alpha=.15, which='both')
fig.tight_layout(); fig.savefig(P / 'fig/coupling.png', dpi=220, facecolor='white'); plt.close(fig)

# ---------------------------------------------------------------- Figure 6: the SheafFarm audit
aud = r['audit']['rows']; C = r['audit']['certificates']; names = list(aud)
labels = {'E': 'E edge-resolved', 'S': 'S positive spectrum', 'F': 'F frame covariant', 'P': 'P preserves sections',
          'C': 'C compatible output', 'Q': 'Q declared law'}
M = np.array([[(-1 if aud[n][c] is None else int(aud[n][c])) for c in C] for n in names])
fig = plt.figure(figsize=(11.5, 5.0))
gs = fig.add_gridspec(1, 2, width_ratios=[1, 1.2], wspace=0.06)
ax = fig.add_subplot(gs[0, 0])
cmap = ListedColormap(['#f2f2f2', '#f4d9c8', '#bcd5ea'])
ax.imshow(M + 1, cmap=cmap, vmin=0, vmax=2, aspect='auto')
for i in range(len(names)):
    for j in range(len(C)):
        ax.text(j, i, {-1: '–', 0: '✗', 1: '✓'}[M[i, j]], ha='center', va='center', fontsize=10,
                color={-1: grey, 0: orange, 1: blue}[M[i, j]])
ax.set_xticks(range(len(C))); ax.set_xticklabels([labels[c] for c in C], rotation=35, ha='right', fontsize=8.4)
ax.set_yticks(range(len(names))); ax.set_yticklabels(names, fontsize=8.6)
ax.tick_params(length=0)
for sp in ax.spines.values():
    sp.set_visible(False)
ax.set_title('(a) certificates computed on the test bed', fontsize=10)
ax2 = fig.add_subplot(gs[0, 1]); ax2.axis('off')
sets = r['order']['sets']
groups = {}
for n in names:
    groups.setdefault(tuple(sets[n]), []).append(n)
manual = {(): (0.5, 0), ('S',): (0.78, 1), ('C', 'F'): (0.22, 2), ('C', 'F', 'P'): (0.07, 3),
          ('C', 'F', 'Q'): (0.36, 3), ('F', 'P', 'S'): (0.65, 3), ('F', 'Q', 'S'): (0.93, 3), ('E', 'F', 'P', 'S'): (0.65, 4)}
pos = {k: manual[k] for k in groups}
level = {y: None for _, y in pos.values()}
cover = set()
for a, b in r['order']['cover_pairs']:
    cover.add((tuple(sets[a]), tuple(sets[b])))
for a, b in cover:
    (x1, y1), (x2, y2) = pos[a], pos[b]
    ax2.plot([x1, x2], [y1, y2], c='#b5bcc3', lw=1.1, zorder=1)
short = {'Constant-sheaf heat': 'constant heat', 'Frozen sheaf heat': 'sheaf heat', 'Sheaf resolvent': 'resolvent',
         'Exact-kernel projector': 'kernel projector', 'Sheaf layer with ReLU': 'ReLU layer',
         'Sheaf layer, radial': 'radial layer', 'Edge-resolved message passing': 'edge-resolved MP',
         'Correlated baseline noise': 'correlated noise', 'Coupled target, exact score': 'coupled, exact',
         'Coupled target, constant coupling': 'coupled, constant', 'Intrinsic compatible sampler': 'intrinsic sampler'}
for k, (x, y) in pos.items():
    txt = '\n'.join(short[n] for n in groups[k]) + '\n{' + ','.join(k) + '}'
    ax2.text(x, y, txt, ha='center', va='center', fontsize=7.3, zorder=2, color=ink,
             bbox=dict(boxstyle='round,pad=0.3', fc='white', ec=orange if not any(
                 set(k) < set(k2) for k2 in pos) else blue, lw=1.2))
ax2.set_ylim(-0.6, max(level) + 0.6); ax2.set_xlim(-0.08, 1.08)
ax2.set_title('(b) inclusion order; orange boxes are maximal', fontsize=10)
ax2.text(0.0, -0.45, 'height = number of verified certificates', fontsize=8, color=grey)
fig.savefig(P / 'fig/farm.png', dpi=220, bbox_inches='tight', facecolor='white'); plt.close(fig)
print('figures written')
