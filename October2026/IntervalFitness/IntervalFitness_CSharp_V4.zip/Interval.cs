namespace IntervalFitness;

/// <summary>Closed interval with outward rounding: every correctly rounded IEEE result is
/// widened by one unit in the last place, so the true real result is always enclosed.</summary>
public readonly record struct Iv(double Lo, double Hi)
{
    public static Iv Point(double x) => new(x, x);
    static double Dn(double x) => Math.BitDecrement(x);
    static double Up(double x) => Math.BitIncrement(x);
    public double Mid => 0.5 * (Lo + Hi);
    public double Width => Hi - Lo;
    public bool Contains(double x) => Lo <= x && x <= Hi;

    public static Iv operator +(Iv a, Iv b) => new(Dn(a.Lo + b.Lo), Up(a.Hi + b.Hi));
    public static Iv operator -(Iv a, Iv b) => new(Dn(a.Lo - b.Hi), Up(a.Hi - b.Lo));
    public static Iv operator -(Iv a) => new(-a.Hi, -a.Lo);
    public static Iv operator *(Iv a, Iv b)
    {
        double p1 = a.Lo * b.Lo, p2 = a.Lo * b.Hi, p3 = a.Hi * b.Lo, p4 = a.Hi * b.Hi;
        return new(Dn(Math.Min(Math.Min(p1, p2), Math.Min(p3, p4))), Up(Math.Max(Math.Max(p1, p2), Math.Max(p3, p4))));
    }
    public static Iv operator *(double s, Iv a) => Point(s) * a;
    public static Iv operator +(Iv a, double s) => a + Point(s);
    public static Iv operator -(Iv a, double s) => a - Point(s);

    public Iv Sqr() => (Lo, Hi) switch
    {
        ( >= 0, _) => new(Dn(Lo * Lo), Up(Hi * Hi)),
        (_, <= 0) => new(Dn(Hi * Hi), Up(Lo * Lo)),
        _ => new(0.0, Up(Math.Max(Lo * Lo, Hi * Hi)))
    };
    public Iv Intersect(Iv o) => new(Math.Max(Lo, o.Lo), Math.Min(Hi, o.Hi));
    public double Mag => Math.Max(Math.Abs(Lo), Math.Abs(Hi));
}
