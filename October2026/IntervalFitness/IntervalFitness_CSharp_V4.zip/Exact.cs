namespace IntervalFitness;
using System.Numerics;

/// <summary>Exact rational arithmetic for Proposition 10.1 and for checking double endpoints.</summary>
public readonly record struct Q(BigInteger N, BigInteger D)
{
    public static Q Of(BigInteger n, BigInteger d) { var g = BigInteger.GreatestCommonDivisor(n, d); if (d.Sign < 0) { n = -n; d = -d; } return new(n / g, d / g); }
    public static Q operator +(Q a, Q b) => Of(a.N * b.D + b.N * a.D, a.D * b.D);
    public static Q operator -(Q a, Q b) => Of(a.N * b.D - b.N * a.D, a.D * b.D);
    public static Q operator *(Q a, Q b) => Of(a.N * b.N, a.D * b.D);
    public static bool operator <(Q a, Q b) => a.N * b.D < b.N * a.D;
    public static bool operator >(Q a, Q b) => a.N * b.D > b.N * a.D;
    public static bool operator <=(Q a, Q b) => !(a > b);
    public static bool operator >=(Q a, Q b) => !(a < b);
    /// <summary>Exact value of a finite double.</summary>
    public static Q FromDouble(double x)
    {
        long bits = BitConverter.DoubleToInt64Bits(x); bool neg = bits < 0; int exp = (int)((bits >> 52) & 0x7FF); long man = bits & 0xFFFFFFFFFFFFFL;
        if (exp == 0) exp++; else man |= 1L << 52; exp -= 1075;
        BigInteger n = man, d = 1; if (exp > 0) n <<= exp; else d <<= -exp; return Of(neg ? -n : n, d);
    }
    public string Decimal(int digits) { var s = BigInteger.Abs(N) * BigInteger.Pow(10, digits) / D; var t = s.ToString().PadLeft(digits + 1, '0'); return (N.Sign < 0 ? "-" : "") + t[..^digits] + "." + t[^digits..]; }
}

public static class Exact
{
    // Sign of 8 n^3 - 8 n D^2 + D^3, i.e. of the cubic z^3 - z + 1/8 at z = n / D, times 8 D^3.
    public static int CubicSign(BigInteger n, BigInteger D) => (8 * n * n * n - 8 * n * D * D + D * D * D).Sign;
    public static Q G(Q r) => r * r - Q.Of(3, 8) * r - Q.Of(5, 4);

    /// <summary>Bisection on integers for the root of the cubic in (9/10, 1) with denominator 10^digits.</summary>
    public static (BigInteger lo, BigInteger D) RootBracket(int digits)
    {
        BigInteger D = BigInteger.Pow(10, digits), lo = 9 * D / 10, hi = D;
        while (hi - lo > 1) { var m = (lo + hi) / 2; if (CubicSign(m, D) < 0) lo = m; else hi = m; }
        return (lo, D);
    }
}
