namespace IntervalFitness;

public static class Experiments
{
    // ---------- Theorem 4.4: simulated adaptive cost against bound (10)
    public sealed record CostRow(string Gaps, int M, int K, double Gamma, int N, double Simulated, double Bound, double Limit);
    public static IReadOnlyList<CostRow> CostTheorem(int seed)
    {
        var rows = new List<CostRow>();
        foreach (var (name, gen) in new (string, Func<Random, double>)[] {
            ("uniform on (0, 1)", r => r.NextDouble()), ("log-uniform on (1e-6, 1)", r => Math.Pow(10, -6 * r.NextDouble())) })
        foreach (int k in new[] { 1, 3 })
        foreach (double gamma in new[] { 2.0, 4.0 })
        foreach (int N in new[] { 10, 20, 30 })
        {
            var rnd = new Random(seed); int m = 100; double sumSim = 0, sumBound = 0; int reps = 200;
            for (int rep = 0; rep < reps; rep++)
            {
                var gaps = Enumerable.Range(0, m).Select(i => i < k ? 0.0 : gen(rnd)).ToArray();
                var phi = gaps.Select(g => 1.0 - g).ToArray();
                bool[] alive = Enumerable.Repeat(true, m).ToArray(); double cost = 0;
                for (int n = 0; n <= N; n++)
                {
                    double w = Math.Pow(2, -n); var lo = new double[m]; var hi = new double[m];
                    for (int i = 0; i < m; i++) { if (!alive[i]) continue; cost += Math.Pow(gamma, n); lo[i] = phi[i] - rnd.NextDouble() * w; hi[i] = lo[i] + w; }
                    double best = Enumerable.Range(0, m).Where(i => alive[i]).Max(i => lo[i]);
                    for (int i = 0; i < m; i++) if (alive[i] && hi[i] < best) alive[i] = false;
                }
                double unif = m * (Math.Pow(gamma, N + 1) - 1) / (gamma - 1);
                double bound = (double)k / m + gaps.Skip(k).Sum(d =>
                {
                    int ni = N; for (int n = 0; n <= N; n++) if (2 * Math.Pow(2, -n) < d) { ni = n; break; }
                    return Math.Pow(gamma, ni + 1) - 1;
                }) / (m * (Math.Pow(gamma, N + 1) - 1));
                sumSim += cost / unif; sumBound += bound;
            }
            rows.Add(new(name, m, k, gamma, N, sumSim / reps, sumBound / reps, (double)k / m));
        }
        return rows;
    }

    // ---------- Theorem 9.2: scalar equation for the minimum selected mean
    static double Mu(double[] f, double[] q, double beta)
    {
        double mx = f.Max(), num = 0, den = 0;
        for (int i = 0; i < f.Length; i++) { double w = q[i] * Math.Exp(beta * (f[i] - mx)); num += w * f[i]; den += w; }
        return num / den;
    }
    public static (double min, double[] f) SolveMin(double[] l, double[] u, double[] q, double beta)
    {
        double H(double t)
        {
            double s = 0, mx = u.Max();
            for (int i = 0; i < l.Length; i++) { double c = Math.Min(u[i], Math.Max(l[i], t)); s += q[i] * Math.Exp(beta * (c - mx)) * (c - t - 1 / beta); }
            return s;
        }
        double a = l.Min() - 1 / beta, b = u.Max() - 1 / beta;
        for (int it = 0; it < 200; it++) { double m = 0.5 * (a + b); if (H(m) > 0) a = m; else b = m; }
        double t = 0.5 * (a + b); var f = l.Select((li, i) => Math.Min(u[i], Math.Max(li, t))).ToArray();
        return (t + 1 / beta, f);
    }
    public sealed record SelectRow(int Instances, int Dimension, double FractionInterior, double MaxIdentityError, double MedianVertexGap,
        double MaxVertexGap, double MinSampledMinusSolution, double MaxSampledMinusVertexMax, double ExampleRoot, double ExampleMin);
    public static SelectRow SelectedMean(int seed)
    {
        var rnd = new Random(seed); int n = 6, inst = 2000, interior = 0; double idErr = 0, worstSample = double.PositiveInfinity, maxAbove = double.NegativeInfinity;
        var gaps = new List<double>();
        double Nrm() => Math.Sqrt(-2 * Math.Log(1 - rnd.NextDouble())) * Math.Cos(2 * Math.PI * rnd.NextDouble());
        for (int s = 0; s < inst; s++)
        {
            var q = Enumerable.Range(0, n).Select(_ => 0.2 + 1.8 * rnd.NextDouble()).ToArray(); double beta = 0.2 + 2.8 * rnd.NextDouble();
            var l = Enumerable.Range(0, n).Select(_ => Nrm()).ToArray(); var u = l.Select(x => x + 3 * rnd.NextDouble()).ToArray();
            var (mn, f) = SolveMin(l, u, q, beta);
            idErr = Math.Max(idErr, Math.Abs(Mu(f, q, beta) - mn));
            if (f.Where((x, i) => x > l[i] && x < u[i]).Any()) interior++;
            double vmin = double.PositiveInfinity, vmax = double.NegativeInfinity;
            for (int mask = 0; mask < (1 << n); mask++)
            {
                var v = Enumerable.Range(0, n).Select(i => ((mask >> i) & 1) == 1 ? u[i] : l[i]).ToArray(); double mv = Mu(v, q, beta);
                vmin = Math.Min(vmin, mv); vmax = Math.Max(vmax, mv);
            }
            gaps.Add(vmin - mn);
            for (int k = 0; k < 2000; k++)
            {
                var v = Enumerable.Range(0, n).Select(i => l[i] + (u[i] - l[i]) * rnd.NextDouble()).ToArray(); double mv = Mu(v, q, beta);
                worstSample = Math.Min(worstSample, mv - mn); maxAbove = Math.Max(maxAbove, mv - vmax);
            }
        }
        gaps.Sort();
        // Example: q = (1, 1), beta = 1, f2 = 0, f1 in [-2, 0]
        var (exMin, exF) = SolveMin(new[] { -2.0, 0.0 }, new[] { 0.0, 0.0 }, new[] { 1.0, 1.0 }, 1.0);
        return new(inst, n, (double)interior / inst, idErr, gaps[gaps.Count / 2], gaps[^1], worstSample, maxAbove, exF[0], exMin);
    }

    // ---------- Theorem 5.4: Taylor excess bound for g = sin z1 cos z2 + 0.3 z1 z2
    public sealed record TaylorRow(double Radius, double MaxExcessOverR, double MedianExcess, double MedianR);
    public static IReadOnlyList<TaylorRow> Taylor(int seed)
    {
        var rnd = new Random(seed); var rows = new List<TaylorRow>();
        double g(double a, double b) => Math.Sin(a) * Math.Cos(b) + 0.3 * a * b;
        double[,] H = { { 1.0, 1.3 }, { 1.3, 1.0 } };
        foreach (double r in new[] { 0.4, 0.2, 0.1, 0.05, 0.025 })
        {
            var ex = new List<double>(); var Rs = new List<double>(); double worst = 0;
            for (int s = 0; s < 300; s++)
            {
                double c1 = -2 + 4 * rnd.NextDouble(), c2 = -2 + 4 * rnd.NextDouble();
                double v1 = Math.Cos(c1) * Math.Cos(c2) + 0.3 * c2, v2 = -Math.Sin(c1) * Math.Sin(c2) + 0.3 * c1;
                double A = Math.Abs(v1) * r + Math.Abs(v2) * r, R = 0.5 * (H[0, 0] + 2 * H[0, 1] + H[1, 1]) * r * r;
                double lo = double.PositiveInfinity, hi = double.NegativeInfinity; int G = 300;
                for (int i = 0; i <= G; i++) for (int j = 0; j <= G; j++)
                { double val = g(c1 - r + 2 * r * i / G, c2 - r + 2 * r * j / G); lo = Math.Min(lo, val); hi = Math.Max(hi, val); }
                double excess = 2 * A + 2 * R - (hi - lo); ex.Add(excess); Rs.Add(R); worst = Math.Max(worst, excess / R);
            }
            ex.Sort(); Rs.Sort(); rows.Add(new(r, worst, ex[ex.Count / 2], Rs[Rs.Count / 2]));
        }
        return rows;
    }

    // ---------- Proposition 7.3: two shared-parameter families with opposite sample-count trends
    public sealed record SlackRow(string Family, int Samples, double MedianRatio, double MinRatio);
    public static IReadOnlyList<SlackRow> Slack(int seed)
    {
        var rows = new List<SlackRow>(); var rnd = new Random(seed);
        double Nrm() => Math.Sqrt(-2 * Math.Log(1 - rnd.NextDouble())) * Math.Cos(2 * Math.PI * rnd.NextDouble());
        foreach (var fam in new[] { "independent targets", "one opposing sample" })
        foreach (int ns in new[] { 2, 5, 20, 100 })
        {
            var ratios = new List<double>();
            for (int rep = 0; rep < 200; rep++)
            {
                var c = fam == "independent targets" ? Enumerable.Range(0, 3).Select(_ => 0.5 * Nrm()).ToArray() : new double[3];
                var X = new double[ns][]; var t = new double[ns];
                for (int i = 0; i < ns; i++)
                {
                    if (fam == "independent targets") { X[i] = Enumerable.Range(0, 3).Select(_ => Nrm()).ToArray(); t[i] = Nrm(); }
                    else { X[i] = new[] { 1 + 0.1 * Nrm(), 0.1 * Nrm(), 0.1 * Nrm() }; t[i] = i == 0 ? -1.0 : 1.0; }
                }
                double sumMax = 0, aggMax = double.NegativeInfinity; var per = new double[ns]; Array.Fill(per, double.NegativeInfinity);
                for (int mask = 0; mask < 8; mask++)
                {
                    var th = Enumerable.Range(0, 3).Select(j => c[j] + (((mask >> j) & 1) == 1 ? 0.5 : -0.5)).ToArray(); double agg = 0;
                    for (int i = 0; i < ns; i++) { double y = X[i].Zip(th, (a, b) => a * b).Sum() - t[i]; double L = y * y; agg += L; per[i] = Math.Max(per[i], L); }
                    aggMax = Math.Max(aggMax, agg);
                }
                sumMax = per.Sum(); ratios.Add(aggMax / sumMax);
            }
            ratios.Sort(); rows.Add(new(fam, ns, ratios[ratios.Count / 2], ratios[0]));
        }
        return rows;
    }
}
