namespace IntervalFitness;

/// <summary>Robust benchmark (30): F(z, xi) = -(z^2 - 1)^2 + xi z / 2 - xi^2 / 4.</summary>
public static class Problem30
{
    public enum Form { Natural, MeanValue, Intersection }

    public static Iv Natural(Iv z, Iv x) => -((z.Sqr() - 1.0).Sqr()) + 0.5 * (x * z) - 0.25 * x.Sqr();

    public static Iv DzF(Iv z, Iv x) => -4.0 * (z * (z.Sqr() - 1.0)) + 0.5 * x;
    public static Iv DxF(Iv z, Iv x) => 0.5 * z - 0.5 * x;

    public static Iv MeanValue(Iv z, Iv x)
    {
        var zc = Iv.Point(z.Mid); var xc = Iv.Point(x.Mid);
        return Natural(zc, xc) + DzF(z, x) * (z - zc) + DxF(z, x) * (x - xc);
    }

    public static Iv Joint(Form form, Iv z, Iv x) => form switch
    {
        Form.Natural => Natural(z, x),
        Form.MeanValue => MeanValue(z, x),
        _ => Natural(z, x).Intersect(MeanValue(z, x))
    };
}
