namespace IntervalFitness;
using static Problem30;

public sealed record InnerResult(Iv Phi, IReadOnlyList<Iv> Cells, long Evaluations, int Discarded);
public sealed record SearchResult(double B, double Upper, long Splits, long Evaluations, int Active,
    bool GapMonotone, bool IncumbentMonotone, long CellsDiscarded, long MinimiserChecks, long MinimiserViolations);

public static class RobustSearch
{
    /// <summary>Theorem 6.1 enclosure with Proposition 6.4 pruning; cells are bisected until width <= target.</summary>
    public static InnerResult Inner(Form form, Iv z, IReadOnlyList<Iv> start, double target)
    {
        var cells = start; long evals = 0; int discarded = 0;
        while (true)
        {
            var vals = cells.Select(s => Joint(form, z, s)).ToArray(); evals += vals.Length;
            double lo = vals.Min(v => v.Lo), up = vals.Min(v => v.Hi);
            var keep = cells.Where((s, i) => vals[i].Lo <= up).ToArray();      // strict exclusion A_S > U
            discarded += cells.Count - keep.Length;
            if (keep.All(s => s.Width <= target)) return new(new Iv(lo, up), keep, evals, discarded);
            cells = keep.SelectMany(s => s.Width <= target ? new[] { s } : new[] { new Iv(s.Lo, s.Mid), new Iv(s.Mid, s.Hi) }).ToArray();
        }
    }

    sealed record Box(double Lo, double Hi, double L, double U, IReadOnlyList<Iv> Cells);

    // Minimiser of the inner problem is xi = -sign(z); check that a retained cell contains it.
    static (long, long) CheckMinimisers(double lo, double hi, IReadOnlyList<Iv> cells)
    {
        long checks = 0, bad = 0;
        if (hi > 0) { checks++; if (!cells.Any(c => c.Contains(-1.0))) bad++; }
        if (lo < 0) { checks++; if (!cells.Any(c => c.Contains(1.0))) bad++; }
        return (checks, bad);
    }

    public static SearchResult Run(Form form, double tol, long maxSplits = 100_000)
    {
        var root = new Iv(-2, 2); var all = new[] { new Iv(-1, 1) };
        var r0 = Inner(form, root, all, 2.0); long evals = r0.Evaluations, disc = r0.Discarded;
        var p0 = Inner(form, Iv.Point(0.0), all, Math.Pow(2, -10)); evals += p0.Evaluations;
        double b = p0.Phi.Lo;
        var pq = new PriorityQueue<Box, double>(); pq.Enqueue(new Box(-2, 2, r0.Phi.Lo, r0.Phi.Hi, r0.Cells), -r0.Phi.Hi);
        long splits = 0, checks = 0, bad = 0; double lastGap = double.PositiveInfinity, lastB = b; bool gapMono = true, bMono = true;
        while (pq.Count > 0 && splits < maxSplits)
        {
            while (pq.Count > 0 && pq.Peek().U <= b) pq.Dequeue();
            if (pq.Count == 0) break;
            double upper = Math.Max(b, pq.Peek().U), gap = upper - b;
            gapMono &= gap <= lastGap; bMono &= b >= lastB; lastGap = gap; lastB = b;
            if (gap <= tol) break;
            var box = pq.Dequeue(); double m = 0.5 * (box.Lo + box.Hi); splits++;
            foreach (var (lo, hi) in new[] { (box.Lo, m), (m, box.Hi) })
            {
                double w = hi - lo;
                var e = Inner(form, new Iv(lo, hi), box.Cells, w); evals += e.Evaluations; disc += e.Discarded;
                var (c1, b1) = CheckMinimisers(lo, hi, e.Cells); checks += c1; bad += b1;
                double L = Math.Max(box.L, e.Phi.Lo), U = Math.Min(box.U, e.Phi.Hi);
                var pc = Inner(form, Iv.Point(0.5 * (lo + hi)), e.Cells, Math.Min(w, tol)); evals += pc.Evaluations;
                b = Math.Max(b, pc.Phi.Lo);
                if (U > b) pq.Enqueue(new Box(lo, hi, L, U, e.Cells), -U);
            }
        }
        var active = pq.UnorderedItems.Where(t => t.Element.U > b).ToArray();
        double B = Math.Max(b, active.Length > 0 ? active.Max(t => t.Element.U) : b);
        return new(b, B, splits, evals, active.Length, gapMono && (B - b) <= lastGap, bMono, disc, checks, bad);
    }

    /// <summary>Theorem 6.5 / Corollary 6.6: uniform Lipschitz cover with balanced point accuracy kappa = K.</summary>
    public static (double b, double B, long boxes, long evals, double K) LipschitzCover(Form form, double eps)
    {
        double K = DzF(new Iv(-2, 2), new Iv(-1, 1)).Mag;          // validated sup |dF/dz| on D x Xi
        double rho = eps / (2 * K); long m = (long)Math.Ceiling(4.0 / (2 * rho)); double h = 4.0 / m;
        double b = double.NegativeInfinity, B = double.NegativeInfinity; long evals = 0;
        var all = new[] { new Iv(-1, 1) };
        for (long i = 0; i < m; i++)
        {
            double c = -2 + (i + 0.5) * h, rhoQ = 0.5 * h;
            double target = K * rhoQ; InnerResult p;
            do { p = Inner(form, Iv.Point(c), all, target); evals += p.Evaluations; target *= 0.5; }
            while (p.Phi.Width > K * rhoQ);                              // point accuracy delta_Q <= kappa rho_Q
            b = Math.Max(b, p.Phi.Lo); B = Math.Max(B, Math.BitIncrement(p.Phi.Hi + Math.BitIncrement(K * rhoQ)));
        }
        return (b, B, m, evals, K);
    }
}
