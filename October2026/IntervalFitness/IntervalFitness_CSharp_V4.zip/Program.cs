using System.Diagnostics;
using System.Numerics;
using System.Text.Json;
using IntervalFitness;
using static IntervalFitness.Problem30;

var results = new Dictionary<string, object>();

// Proposition 10.1: exact integer certificate and a 60-digit bracket
BigInteger D26 = BigInteger.Pow(10, 26), nMinus = BigInteger.Parse("93040292655585169319291809");
results["prop10_1"] = new { signAtNminus = Exact.CubicSign(nMinus, D26), signAtNplus = Exact.CubicSign(nMinus + 1, D26),
    gMinus = Exact.G(Q.Of(nMinus, D26)).Decimal(30), gPlus = Exact.G(Q.Of(nMinus + 1, D26)).Decimal(30) };
var (lo60, D60) = Exact.RootBracket(60);
var phiLo = Exact.G(Q.Of(lo60, D60)); var phiHi = Exact.G(Q.Of(lo60 + 1, D60));
results["bracket60"] = new { rho = Q.Of(lo60, D60).Decimal(60), phiLo = phiLo.Decimal(58), phiHi = phiHi.Decimal(58) };

// Validated branch and bound with outward rounding
var bb = new List<object>();
foreach (Form form in new[] { Form.Natural, Form.MeanValue, Form.Intersection })
foreach (double tol in new[] { 1e-2, 1e-4, 1e-6, 1e-8 })
{
    var sw = Stopwatch.StartNew(); var r = RobustSearch.Run(form, tol); sw.Stop();
    bool lowerOk = Q.FromDouble(r.B) <= phiHi, upperOk = Q.FromDouble(r.Upper) >= phiLo;   // exact rational comparison
    bb.Add(new { form = form.ToString(), tol, incumbent = r.B, upper = r.Upper, gap = r.Upper - r.B, r.Splits, r.Evaluations, r.Active, r.GapMonotone, r.IncumbentMonotone,
        r.CellsDiscarded, r.MinimiserChecks, r.MinimiserViolations, exactLowerOk = lowerOk, exactUpperOk = upperOk, ms = sw.Elapsed.TotalMilliseconds });
    Console.WriteLine($"{form} {tol:E0} splits={r.Splits} gap={r.Upper - r.B:E3} b={r.B:R} ok={lowerOk && upperOk} mono={r.GapMonotone}/{r.IncumbentMonotone} minviol={r.MinimiserViolations}/{r.MinimiserChecks} {sw.ElapsedMilliseconds}ms");
}
results["bb"] = bb;

// Theorem 6.5 Lipschitz cover
var lip = new List<object>();
foreach (double eps in new[] { 1e-2, 1e-3, 1e-4 })
{
    var sw = Stopwatch.StartNew(); var (b, B, boxes, evals, K) = RobustSearch.LipschitzCover(Form.Intersection, eps); sw.Stop();
    lip.Add(new { eps, incumbent = b, upper = B, gap = B - b, boxes, evals, K, exactOk = Q.FromDouble(b) <= phiHi && Q.FromDouble(B) >= phiLo, ms = sw.Elapsed.TotalMilliseconds });
    Console.WriteLine($"Lipschitz eps={eps} K={K} boxes={boxes} gap={B - b:E3} evals={evals} {sw.ElapsedMilliseconds}ms");
}
results["lipschitz"] = lip;

results["cost"] = Experiments.CostTheorem(20261027);
results["select"] = Experiments.SelectedMean(20261028);
results["taylor"] = Experiments.Taylor(20261029);
results["slack"] = Experiments.Slack(20261030);
results["runtime"] = new { framework = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription, os = System.Runtime.InteropServices.RuntimeInformation.OSDescription };
File.WriteAllText("results.json", JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine("written results.json");
