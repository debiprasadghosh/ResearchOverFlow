using System;
using System.Collections.Immutable;
using System.Linq;

namespace SheafRuntime;

/// <summary>A group element with composition this · other. Implementations are immutable value types.</summary>
public interface IGroupElement<TSelf> where TSelf : IGroupElement<TSelf>
{
    static abstract TSelf Identity { get; }
    TSelf Compose(TSelf other);
    TSelf Inverse();
    double DistanceToIdentity();
}

public readonly record struct SO2(double Angle) : IGroupElement<SO2>
{
    public static SO2 Identity => new(0);
    public SO2 Compose(SO2 other) => new(Wrap(Angle + other.Angle));
    public SO2 Inverse() => new(Wrap(-Angle));
    public double DistanceToIdentity() => Math.Abs(Wrap(Angle));
    public static double Wrap(double a) => a - 2 * Math.PI * Math.Floor((a + Math.PI) / (2 * Math.PI));
}

/// <summary>Planar rigid motion (R(theta), t): x -> R x + t. Composition (R1,t1)(R2,t2) = (R1R2, t1 + R1 t2).</summary>
public readonly record struct SE2(double Theta, double X, double Y) : IGroupElement<SE2>
{
    public static SE2 Identity => new(0, 0, 0);
    public SE2 Compose(SE2 o)
    {
        double c = Math.Cos(Theta), s = Math.Sin(Theta);
        return new SE2(SO2.Wrap(Theta + o.Theta), X + c * o.X - s * o.Y, Y + s * o.X + c * o.Y);
    }
    public SE2 Inverse()
    {
        double c = Math.Cos(Theta), s = Math.Sin(Theta);
        return new SE2(SO2.Wrap(-Theta), -(c * X + s * Y), -(-s * X + c * Y));
    }
    public double DistanceToIdentity() => Math.Abs(SO2.Wrap(Theta)) + Math.Sqrt(X * X + Y * Y);
}

public abstract record GaugeResult<TG> where TG : IGroupElement<TG>;
/// <summary>Frames s with measurement(u,v) = s_u^{-1} s_v on every edge (Theorem 30.1), unique up to one left factor per component.</summary>
public sealed record GaugeTrivial<TG>(ImmutableArray<TG> Frames)
    : GaugeResult<TG> where TG : IGroupElement<TG>;
/// <summary>Root-based holonomies of the fundamental walks that differ from the identity.</summary>
public sealed record NontrivialHolonomy<TG>(ImmutableArray<(int NonTreeEdge, TG Holonomy)> Walks)
    : GaugeResult<TG> where TG : IGroupElement<TG>;

public static class Holonomy        // Theorem 30.1
{
    /// <summary>Integrate frames along the deterministic spanning forest; measurement(e) is the transport from
    /// edges[e].U's frame to edges[e].V's frame, i.e. it should equal s_U^{-1} s_V.</summary>
    public static ImmutableArray<TG> IntegrateFrames<TG>(int n, ImmutableArray<Edge> edges, ImmutableArray<TG> measurement, SpanningForest f)
        where TG : IGroupElement<TG>
    {
        var s = new TG[n];
        foreach (int u in f.Order)
        {
            int p = f.Parent[u];
            if (p < 0) { s[u] = TG.Identity; continue; }
            int e = f.ParentEdge[u];
            var m = edges[e].U == p ? measurement[e] : measurement[e].Inverse();
            s[u] = s[p].Compose(m);
        }
        return s.ToImmutableArray();
    }

    /// <summary>Holonomy of each fundamental walk based at its root: s_u · m_uv · s_v^{-1}.</summary>
    public static ImmutableArray<(int NonTreeEdge, TG Holonomy)> FundamentalHolonomies<TG>(
        int n, ImmutableArray<Edge> edges, ImmutableArray<TG> measurement)
        where TG : IGroupElement<TG>
    {
        if (measurement.Length != edges.Length) throw new ArgumentException("Size mismatch");
        var f = Graphs.BfsForest(n, edges);
        var s = IntegrateFrames(n, edges, measurement, f);          // s_v = s_u m_uv along the tree
        var tree = f.TreeEdges;
        return Enumerable.Range(0, edges.Length).Where(e => !tree.Contains(e))
            .Select(e => (e, s[edges[e].U].Compose(measurement[e])
                                          .Compose(s[edges[e].V].Inverse())))
            .ToImmutableArray();
    }

    public static GaugeResult<TG> Trivialise<TG>(int n, ImmutableArray<Edge> edges,
        ImmutableArray<TG> measurement, double tolerance) where TG : IGroupElement<TG>
    {
        var bad = FundamentalHolonomies(n, edges, measurement)
            .Where(w => w.Holonomy.DistanceToIdentity() > tolerance).ToImmutableArray();
        return bad.IsEmpty
            ? new GaugeTrivial<TG>(
                  IntegrateFrames(n, edges, measurement, Graphs.BfsForest(n, edges)))
            : new NontrivialHolonomy<TG>(bad);
    }
}
