using System;
using System.Collections.Immutable;
using System.Linq;

namespace SheafRuntime;

/// <summary>Typed outcomes of the calibrated exactness test on a graph (no 2-cells).</summary>
public abstract record VerificationResult;
public sealed record NoCycles : VerificationResult;
public sealed record ExactWithinNoise(int Dof, double Statistic, double PValue)
    : VerificationResult;
public sealed record ObstructionDetected(int Dof, double Statistic, double PValue,
    ImmutableArray<CycleScore> Cycles) : VerificationResult;
public sealed record CycleScore(int NonTreeEdge, double CycleSum, double StandardError)
{
    public double Z => CycleSum / StandardError;
}

/// <summary>Proposition 29.4: T = (Zg)^T (Z W^{-1} Z^T)^{-1} (Zg) / sigma^2, chi-square with h = m - n + c dof under exactness.</summary>
public static class CycleVerifier   // Proposition 29.4 with the chi-square law of Theorem 29.1
{
    public static VerificationResult Verify(int n, ImmutableArray<Edge> edges,
        ImmutableArray<double> g, ImmutableArray<double> weights, double sigma, double alpha)
    {
        if (g.Length != edges.Length || weights.Length != edges.Length) throw new ArgumentException("Size mismatch");
        if (weights.Any(w => !(w > 0))) throw new ArgumentException("Weights must be positive");
        if (!(sigma > 0)) throw new ArgumentOutOfRangeException(nameof(sigma));
        var cycles = Graphs.FundamentalCycles(n, edges);
        int h = cycles.Length;
        if (h == 0) return new NoCycles();
        var y = cycles.Select(c => c.Terms.Sum(t => t.Sign * g[t.Edge])).ToArray();
        var C = new double[h, h];                                  // Z W^{-1} Z^T
        for (int a = 0; a < h; a++)
            for (int b = a; b < h; b++)
            {
                double s = 0;
                foreach (var (ea, sa) in cycles[a].Terms)
                    foreach (var (eb, sb) in cycles[b].Terms)
                        if (ea == eb) s += sa * sb / weights[ea];
                C[a, b] = C[b, a] = s;
            }
        var x = Linear.CholeskySolve(C, y);
        double T = y.Zip(x, (p, q) => p * q).Sum() / (sigma * sigma);
        double p = SpecialFunctions.ChiSquareUpperTail(h, T);
        if (p >= alpha) return new ExactWithinNoise(h, T, p);
        var scores = cycles
            .Select((c, k) => new CycleScore(c.NonTreeEdge, y[k], sigma * Math.Sqrt(C[k, k])))
            .OrderByDescending(s => Math.Abs(s.Z)).ToImmutableArray();
        return new ObstructionDetected(h, T, p, scores);
    }
}

public static class Linear
{
    /// <summary>Solve A x = b for symmetric positive definite A (Cholesky). Inputs are not modified.</summary>
    public static double[] CholeskySolve(double[,] A, double[] b)
    {
        int n = b.Length;
        var L = new double[n, n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j <= i; j++)
            {
                double s = A[i, j];
                for (int k = 0; k < j; k++) s -= L[i, k] * L[j, k];
                if (i == j)
                {
                    if (!(s > 0)) throw new InvalidOperationException("Matrix is not positive definite");
                    L[i, i] = Math.Sqrt(s);
                }
                else L[i, j] = s / L[j, j];
            }
        var z = new double[n];
        for (int i = 0; i < n; i++)
        {
            double s = b[i];
            for (int k = 0; k < i; k++) s -= L[i, k] * z[k];
            z[i] = s / L[i, i];
        }
        var x = new double[n];
        for (int i = n - 1; i >= 0; i--)
        {
            double s = z[i];
            for (int k = i + 1; k < n; k++) s -= L[k, i] * x[k];
            x[i] = s / L[i, i];
        }
        return x;
    }

    /// <summary>Eigen-decomposition of a real symmetric matrix by cyclic Jacobi rotations.
    /// Returns eigenvalues ascending with matching eigenvector columns.</summary>
    public static (double[] Values, double[,] Vectors) SymmetricEigen(double[,] input, int maxSweeps = 100)
    {
        int n = input.GetLength(0);
        var a = (double[,])input.Clone();
        var v = new double[n, n];
        for (int i = 0; i < n; i++) v[i, i] = 1;
        for (int sweep = 0; sweep < maxSweeps; sweep++)
        {
            double off = 0, total = 0;
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++) { total += a[i, j] * a[i, j]; if (i != j) off += a[i, j] * a[i, j]; }
            if (off <= 1e-30 * Math.Max(total, 1e-300)) break;
            for (int p = 0; p < n - 1; p++)
                for (int q = p + 1; q < n; q++)
                {
                    if (Math.Abs(a[p, q]) < 1e-300) continue;
                    double theta = (a[q, q] - a[p, p]) / (2 * a[p, q]);
                    double t = Math.Sign(theta) / (Math.Abs(theta) + Math.Sqrt(theta * theta + 1));
                    if (theta == 0) t = 1;
                    double c = 1 / Math.Sqrt(t * t + 1), s = t * c;
                    for (int k = 0; k < n; k++)
                    {
                        double akp = a[k, p], akq = a[k, q];
                        a[k, p] = c * akp - s * akq; a[k, q] = s * akp + c * akq;
                    }
                    for (int k = 0; k < n; k++)
                    {
                        double apk = a[p, k], aqk = a[q, k];
                        a[p, k] = c * apk - s * aqk; a[q, k] = s * apk + c * aqk;
                    }
                    for (int k = 0; k < n; k++)
                    {
                        double vkp = v[k, p], vkq = v[k, q];
                        v[k, p] = c * vkp - s * vkq; v[k, q] = s * vkp + c * vkq;
                    }
                }
        }
        var idx = Enumerable.Range(0, n).OrderBy(i => a[i, i]).ToArray();
        var values = idx.Select(i => a[i, i]).ToArray();
        var vectors = new double[n, n];
        for (int c = 0; c < n; c++) for (int r = 0; r < n; r++) vectors[r, c] = v[r, idx[c]];
        return (values, vectors);
    }
}
