using System;

namespace SheafRuntime;

/// <summary>Chi-square upper tail via the regularised incomplete gamma function. Pure static functions.</summary>
public static class SpecialFunctions
{
    private static readonly double[] Lanczos =
    {
        0.99999999999980993, 676.5203681218851, -1259.1392167224028, 771.32342877765313,
        -176.61502916214059, 12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6,
        1.5056327351493116e-7
    };

    /// <summary>log Gamma(x) for x &gt; 0 (Lanczos, g = 7).</summary>
    public static double LogGamma(double x)
    {
        if (x <= 0) throw new ArgumentOutOfRangeException(nameof(x));
        if (x < 0.5) return Math.Log(Math.PI / Math.Sin(Math.PI * x)) - LogGamma(1 - x);
        double xm = x - 1, a = Lanczos[0], t = xm + 7.5;
        for (int i = 1; i < Lanczos.Length; i++) a += Lanczos[i] / (xm + i);
        return 0.5 * Math.Log(2 * Math.PI) + (xm + 0.5) * Math.Log(t) - t + Math.Log(a);
    }

    /// <summary>Regularised upper incomplete gamma Q(a, x) = Gamma(a, x) / Gamma(a).</summary>
    public static double RegularizedGammaQ(double a, double x)
    {
        if (a <= 0) throw new ArgumentOutOfRangeException(nameof(a));
        if (x <= 0) return 1.0;
        double logPrefix = -x + a * Math.Log(x) - LogGamma(a);
        if (x < a + 1)
        {
            // series for P(a, x)
            double ap = a, sum = 1.0 / a, del = sum;
            for (int n = 0; n < 100000; n++)
            {
                ap += 1; del *= x / ap; sum += del;
                if (Math.Abs(del) < Math.Abs(sum) * 1e-16) break;
            }
            return 1.0 - sum * Math.Exp(logPrefix);
        }
        // continued fraction for Q(a, x), modified Lentz
        const double fpmin = 1e-300;
        double b = x + 1 - a, c = 1 / fpmin, d = 1 / b, h = d;
        for (int i = 1; i < 100000; i++)
        {
            double an = -i * (i - a);
            b += 2;
            d = an * d + b; if (Math.Abs(d) < fpmin) d = fpmin;
            c = b + an / c; if (Math.Abs(c) < fpmin) c = fpmin;
            d = 1 / d;
            double del = d * c; h *= del;
            if (Math.Abs(del - 1) < 1e-16) break;
        }
        return Math.Exp(logPrefix) * h;
    }

    public static double ChiSquareUpperTail(int df, double x) =>
        df <= 0 ? throw new ArgumentOutOfRangeException(nameof(df)) : x <= 0 ? 1.0 : RegularizedGammaQ(0.5 * df, 0.5 * x);
}
