using System;
using System.Collections.Immutable;
using System.Linq;
using System.Numerics;

namespace SheafRuntime;

// Theorem 30.4 and Proposition 30.5: certificate and a posteriori gap of AngularSync.Solve
public sealed record SyncResult(ImmutableArray<double> Angles, double Cost, double LambdaMin,
                                bool Certified, double GapBound);

/// <summary>Minimise sum_e w_e |z_v - r_e z_u|^2 over unit complex z (r_e = exp(i angle_e) measures s_u^{-1} s_v).
/// Spectral start, generalised power iterations, then the a-posteriori certificate lambda_min(M - Diag(lambda)).</summary>
public static class AngularSync
{
    public static Complex[,] Matrix(int n, ImmutableArray<Edge> edges, ImmutableArray<double> angles, ImmutableArray<double> w)
    {
        var M = new Complex[n, n];
        for (int e = 0; e < edges.Length; e++)
        {
            var (u, v) = edges[e];
            var r = Complex.FromPolarCoordinates(1, angles[e]);
            M[u, u] += w[e]; M[v, v] += w[e];
            M[u, v] += -w[e] * Complex.Conjugate(r); M[v, u] += -w[e] * r;
        }
        return M;
    }

    /// <summary>Hermitian eigen-decomposition through the real symmetric embedding [[A, -B], [B, A]].</summary>
    public static (double[] Values, Complex[,] Vectors) HermitianEigen(Complex[,] H)
    {
        int n = H.GetLength(0);
        var R = new double[2 * n, 2 * n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
            {
                R[i, j] = H[i, j].Real; R[i + n, j + n] = H[i, j].Real;
                R[i, j + n] = -H[i, j].Imaginary; R[i + n, j] = H[i, j].Imaginary;
            }
        var (vals, vecs) = Linear.SymmetricEigen(R);
        // each eigenvalue appears twice; keep every second one with its complex vector x + i y
        var values = new double[n]; var vectors = new Complex[n, n];
        for (int k = 0; k < n; k++)
        {
            int c = 2 * k;
            values[k] = vals[c];
            for (int i = 0; i < n; i++) vectors[i, k] = new Complex(vecs[i, c], vecs[i + n, c]);
        }
        return (values, vectors);
    }

    private static Complex[] Multiply(Complex[,] M, Complex[] z)
    {
        int n = z.Length; var y = new Complex[n];
        for (int i = 0; i < n; i++) { Complex s = 0; for (int j = 0; j < n; j++) s += M[i, j] * z[j]; y[i] = s; }
        return y;
    }

    public static SyncResult Solve(int n, ImmutableArray<Edge> edges, ImmutableArray<double> angles, ImmutableArray<double> w,
                                   int maxIterations = 5000, double tolerance = 1e-14)
    {
        var M = Matrix(n, edges, angles, w);
        var (vals, vecs) = HermitianEigen(M);
        var z = Enumerable.Range(0, n).Select(i => vecs[i, 0] / Complex.Abs(vecs[i, 0])).ToArray();
        double shift = vals[^1] + 1.0;                       // (shift I - M) is positive definite
        for (int it = 0; it < maxIterations; it++)
        {
            var Mz = Multiply(M, z);
            var next = z.Select((zi, i) => { var y = shift * zi - Mz[i]; return y / Complex.Abs(y); }).ToArray();
            double change = next.Zip(z, (a, b) => Complex.Abs(a - b)).Max();
            z = next;
            if (change < tolerance) break;
        }
        var Mz2 = Multiply(M, z);
        var lambda = z.Select((zi, i) => (Complex.Conjugate(zi) * Mz2[i]).Real).ToArray();
        double cost = lambda.Sum();                          // z^H M z = sum_u Re(conj(z_u) (Mz)_u) exactly
        var S = new Complex[n, n];
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) S[i, j] = M[i, j] - (i == j ? lambda[i] : 0.0);
        double lmin = HermitianEigen(S).Values[0];
        double scale = Enumerable.Range(0, n).Max(i => Enumerable.Range(0, n).Sum(j => Complex.Abs(M[i, j])));
        bool certified = lmin >= -1e-9 * scale;
        double gap = n * Math.Max(0.0, -lmin);               // Proposition 30.5: cost - optimum <= n max(0, -lambda_min)
        var phase = Complex.Conjugate(z[0]);
        var anglesOut = z.Select(zi => Math.Atan2((zi * phase).Imaginary, (zi * phase).Real)).ToImmutableArray();
        return new SyncResult(anglesOut, cost, lmin, certified, gap);
    }
}
