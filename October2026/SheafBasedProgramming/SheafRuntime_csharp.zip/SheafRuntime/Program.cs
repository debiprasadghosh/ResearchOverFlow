using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.IO;
using System.Linq;
using System.Text.Json;
using SheafRuntime;

// Cross-language checks against golden.json produced by make_golden.py (Section 32).
var path = args.Length > 0 ? args[0] : "golden.json";
using var doc = JsonDocument.Parse(File.ReadAllText(path));
var root = doc.RootElement;
var failures = new List<string>();
var report = new Dictionary<string, object>();

static ImmutableArray<Edge> Edges(JsonElement e) =>
    e.EnumerateArray().Select(p => new Edge(p[0].GetInt32(), p[1].GetInt32())).ToImmutableArray();
static ImmutableArray<double> Doubles(JsonElement e) => e.EnumerateArray().Select(x => x.GetDouble()).ToImmutableArray();

// 1. Appendix A, verbatim listing ------------------------------------------------------------------
Edge[] tri = { new(0, 1), new(1, 2), new(0, 2) };
if (GraphSheafF2.Dimensions(3, tri) != (1, 1)) failures.Add("AppendixA triangle dimensions");
if (!GraphSheafF2.IsExact(3, tri, new[] { true, true, false })) failures.Add("AppendixA exact example");
if (GraphSheafF2.IsExact(3, tri, new[] { true, false, false })) failures.Add("AppendixA inexact example");
int f2n = 0;
foreach (var c in root.GetProperty("f2").EnumerateArray())
{
    var edges = Edges(c.GetProperty("edges")).ToArray(); int n = c.GetProperty("n").GetInt32();
    var dims = GraphSheafF2.Dimensions(n, edges);
    if (dims.H0 != c.GetProperty("H0").GetInt32() || dims.H1 != c.GetProperty("H1").GetInt32()) failures.Add($"F2 dims case {f2n}");
    var g = c.GetProperty("g").EnumerateArray().Select(x => x.GetInt32() == 1).ToArray();
    if (GraphSheafF2.IsExact(n, edges, g) != c.GetProperty("exact").GetBoolean()) failures.Add($"F2 exactness case {f2n}");
    f2n++;
}
report["appendixA_cases"] = f2n + 3;

// 2. Chi-square upper tail -----------------------------------------------------------------------------
double chiMax = 0; int chiN = 0;
foreach (var c in root.GetProperty("chi2").EnumerateArray())
{
    double q = c.GetProperty("q").GetDouble();
    if (q == 0) continue;
    double mine = SpecialFunctions.ChiSquareUpperTail(c.GetProperty("df").GetInt32(), c.GetProperty("x").GetDouble());
    chiMax = Math.Max(chiMax, Math.Abs(mine - q) / q); chiN++;
}
report["chi2_points"] = chiN; report["chi2_max_rel_err"] = chiMax;
if (chiMax > 1e-11) failures.Add($"chi2 relative error {chiMax:E2}");

// 3. Calibrated cycle verifier --------------------------------------------------------------------------
double tMax = 0, pMax = 0; int vN = 0, agree = 0;
foreach (var c in root.GetProperty("verifier").EnumerateArray())
{
    var edges = Edges(c.GetProperty("edges")); int n = c.GetProperty("n").GetInt32();
    var res = CycleVerifier.Verify(n, edges, Doubles(c.GetProperty("g")), Doubles(c.GetProperty("w")), c.GetProperty("sigma").GetDouble(), 0.05);
    double T0 = c.GetProperty("T").GetDouble(), p0 = c.GetProperty("p").GetDouble();
    (int dof, double T, double p) = res switch
    {
        ExactWithinNoise x => (x.Dof, x.Statistic, x.PValue),
        ObstructionDetected x => (x.Dof, x.Statistic, x.PValue),
        _ => (0, double.NaN, double.NaN)
    };
    if (dof != c.GetProperty("h").GetInt32()) failures.Add($"verifier dof case {vN}");
    tMax = Math.Max(tMax, Math.Abs(T - T0) / Math.Max(1, T0));
    if (p0 > 1e-280) pMax = Math.Max(pMax, Math.Abs(p - p0) / Math.Max(p0, 1e-300));
    agree += (res is ObstructionDetected) == (p0 < 0.05) ? 1 : 0;
    vN++;
}
report["verifier_cases"] = vN; report["verifier_T_max_rel_err"] = tMax; report["verifier_p_max_rel_err"] = pMax; report["verifier_decision_agreement"] = agree;
if (tMax > 1e-10 || pMax > 1e-8 || agree != vN) failures.Add($"verifier T {tMax:E2} p {pMax:E2} agree {agree}/{vN}");

// 4. SE(2) holonomy of fundamental walks ---------------------------------------------------------------
double hMax = 0; int hN = 0, hClass = 0, frameMax = 0; double frameErr = 0;
foreach (var c in root.GetProperty("holonomy").EnumerateArray())
{
    var edges = Edges(c.GetProperty("edges")); int n = c.GetProperty("n").GetInt32();
    var meas = c.GetProperty("meas").EnumerateArray().Select(m => new SE2(m[0].GetDouble(), m[1].GetDouble(), m[2].GetDouble())).ToImmutableArray();
    var mine = Holonomy.FundamentalHolonomies(n, edges, meas).ToDictionary(w => w.NonTreeEdge, w => w.Holonomy);
    foreach (var w in c.GetProperty("walks").EnumerateArray())
    {
        int e = w.GetProperty("edge").GetInt32();
        if (!mine.TryGetValue(e, out var H)) { failures.Add($"holonomy walk missing {e}"); continue; }
        hMax = Math.Max(hMax, Math.Abs(SO2.Wrap(H.Theta - w.GetProperty("theta").GetDouble())));
        hMax = Math.Max(hMax, Math.Abs(H.X - w.GetProperty("x").GetDouble()));
        hMax = Math.Max(hMax, Math.Abs(H.Y - w.GetProperty("y").GetDouble()));
        hN++;
    }
    bool perturbed = c.GetProperty("perturbed").GetInt32() >= 0;
    var verdict = Holonomy.Trivialise(n, edges, meas, 1e-9);
    if (verdict is GaugeTrivial<SE2> gt)
    {
        hClass += perturbed ? 0 : 1;
        for (int e = 0; e < edges.Length; e++)
        {
            var fitted = gt.Frames[edges[e].U].Inverse().Compose(gt.Frames[edges[e].V]);
            frameErr = Math.Max(frameErr, Math.Abs(SO2.Wrap(fitted.Theta - meas[e].Theta)) + Math.Abs(fitted.X - meas[e].X) + Math.Abs(fitted.Y - meas[e].Y));
        }
        frameMax++;
    }
    else hClass += perturbed ? 1 : 0;
}
report["holonomy_walks"] = hN; report["holonomy_max_abs_err"] = hMax; report["holonomy_classification_correct"] = hClass;
report["gauge_trivial_frame_max_err"] = frameErr;
if (hMax > 1e-10 || hClass != root.GetProperty("holonomy").GetArrayLength() || frameErr > 1e-9) failures.Add($"holonomy err {hMax:E2} class {hClass} frames {frameErr:E2}");

// 5. Certified angular synchronisation ------------------------------------------------------------------
int sN = 0, both = 0, flagAgree = 0; double costMax = 0;
foreach (var c in root.GetProperty("sync").EnumerateArray())
{
    var edges = Edges(c.GetProperty("edges")); int n = c.GetProperty("n").GetInt32();
    var res = AngularSync.Solve(n, edges, Doubles(c.GetProperty("angles")), Doubles(c.GetProperty("w")));
    bool pyCert = c.GetProperty("certified").GetBoolean();
    flagAgree += res.Certified == pyCert ? 1 : 0;
    if (res.Certified && pyCert)
    {
        both++;
        double c0 = c.GetProperty("cost").GetDouble();
        costMax = Math.Max(costMax, Math.Abs(res.Cost - c0) / Math.Max(1, Math.Abs(c0)));
    }
    sN++;
}
report["sync_cases"] = sN; report["sync_both_certified"] = both; report["sync_flag_agreement"] = flagAgree; report["sync_cost_max_rel_err"] = costMax;
if (costMax > 1e-9) failures.Add($"sync cost {costMax:E2}");

report["failures"] = failures;
report["runtime"] = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription;
Console.WriteLine(JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }));
return failures.Count == 0 ? 0 : 1;
