using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;

namespace SheafRuntime;

/// <summary>A deterministic spanning forest: roots in increasing order, neighbours in increasing order.</summary>
public sealed record SpanningForest(ImmutableArray<int> Parent, ImmutableArray<int> ParentEdge, ImmutableArray<int> Order)
{
    public ImmutableHashSet<int> TreeEdges => ParentEdge.Where(e => e >= 0).ToImmutableHashSet();
}

/// <summary>A signed edge-incidence vector of a fundamental cycle, keyed by its non-tree edge.</summary>
public sealed record FundamentalCycle(int NonTreeEdge, ImmutableArray<(int Edge, int Sign)> Terms);

public static class Graphs
{
    public static SpanningForest BfsForest(int n, ImmutableArray<Edge> edges)
    {
        var adj = Enumerable.Range(0, n).Select(_ => new List<(int V, int E)>()).ToArray();
        for (int e = 0; e < edges.Length; e++)
        {
            var (u, v) = edges[e];
            if (u == v) continue;
            adj[u].Add((v, e)); adj[v].Add((u, e));
        }
        foreach (var list in adj) list.Sort();
        var parent = Enumerable.Repeat(-1, n).ToArray();
        var pedge = Enumerable.Repeat(-1, n).ToArray();
        var seen = new bool[n];
        var order = new List<int>(n);
        for (int r = 0; r < n; r++)
        {
            if (seen[r]) continue;
            seen[r] = true;
            var queue = new Queue<int>(); queue.Enqueue(r);
            while (queue.Count > 0)
            {
                int u = queue.Dequeue(); order.Add(u);
                foreach (var (v, e) in adj[u])
                {
                    if (seen[v]) continue;
                    seen[v] = true; parent[v] = u; pedge[v] = e; queue.Enqueue(v);
                }
            }
        }
        return new SpanningForest(parent.ToImmutableArray(), pedge.ToImmutableArray(), order.ToImmutableArray());
    }

    /// <summary>Fundamental cycles of the forest: traverse the non-tree edge u -> v, return v -> root, root -> u.
    /// Signs are relative to each edge's stored orientation. Loops give the single-term cycle (e, +1) cancelled to empty.</summary>
    public static ImmutableArray<FundamentalCycle> FundamentalCycles(int n, ImmutableArray<Edge> edges)
    {
        var f = BfsForest(n, edges);
        var tree = f.TreeEdges;
        var result = ImmutableArray.CreateBuilder<FundamentalCycle>();
        for (int e = 0; e < edges.Length; e++)
        {
            if (tree.Contains(e)) continue;
            var (u, v) = edges[e];
            if (u == v) continue;                      // a loop is a cycle whose real coboundary row is zero
            var acc = new Dictionary<int, int> { [e] = 1 };
            // v up to its root: traverse child -> parent
            for (int x = v; f.Parent[x] >= 0; x = f.Parent[x])
            {
                int te = f.ParentEdge[x];
                int sign = edges[te].U == f.Parent[x] ? -1 : 1;   // edge stored parent->child is traversed backwards
                acc[te] = acc.GetValueOrDefault(te) + sign;
            }
            // root down to u: traverse parent -> child
            for (int x = u; f.Parent[x] >= 0; x = f.Parent[x])
            {
                int te = f.ParentEdge[x];
                int sign = edges[te].U == f.Parent[x] ? 1 : -1;
                acc[te] = acc.GetValueOrDefault(te) + sign;
            }
            result.Add(new FundamentalCycle(e, acc.Where(kv => kv.Value != 0)
                                                  .OrderBy(kv => kv.Key)
                                                  .Select(kv => (kv.Key, kv.Value))
                                                  .ToImmutableArray()));
        }
        return result.ToImmutable();
    }
}
