using System;
public readonly record struct Edge(int U, int V);
public static class GraphSheafF2
{
    public static bool[,] D0(int n, Edge[] edges)
    {
        if (n < 0) throw new ArgumentOutOfRangeException(nameof(n));
        ArgumentNullException.ThrowIfNull(edges);
        var d = new bool[edges.Length, n];
        for (int e = 0; e < edges.Length; e++)
        {
            var (u, v) = edges[e];
            if (u < 0 || u >= n || v < 0 || v >= n)
                throw new ArgumentException("Invalid endpoint");
            d[e, u] ^= true;
            d[e, v] ^= true; // A loop has zero coboundary.
        }
        return d;
    }
    public static int Rank(bool[,] input)
    {
        var a = (bool[,])input.Clone();
        int m = a.GetLength(0), n = a.GetLength(1), r = 0;
        for (int c = 0; c < n && r < m; c++)
        {
            int pivot = r;
            while (pivot < m && !a[pivot,c]) pivot++;
            if (pivot == m) continue;
            for (int k = 0; k < n; k++)
                (a[r,k], a[pivot,k]) = (a[pivot,k], a[r,k]);
            for (int j = r + 1; j < m; j++)
                if (a[j,c])
                    for (int k = c; k < n; k++)
                        a[j,k] ^= a[r,k];
            r++;
        }
        return r;
    }
    public static (int H0, int H1) Dimensions(int n, Edge[] edges)
    {
        int r = Rank(D0(n, edges));
        return (n - r, edges.Length - r);
    }
    public static bool IsExact(int n, Edge[] edges, bool[] g)
    {
        var d = D0(n, edges);
        ArgumentNullException.ThrowIfNull(g);
        int m = edges.Length;
        if (g.Length != m) throw new ArgumentException("Wrong size");
        var augmented = new bool[m, n + 1];
        for (int e = 0; e < m; e++)
        {
            for (int v = 0; v < n; v++) augmented[e,v] = d[e,v];
            augmented[e,n] = g[e];
        }
        return Rank(augmented) == Rank(d);
    }
}
// Edge[] tri = { new(0,1), new(1,2), new(0,2) };
// Dimensions(3, tri) is (1,1).
// IsExact(3, tri, new[] { true, true, false }) is true.
// IsExact(3, tri, new[] { true, false, false }) is false.
