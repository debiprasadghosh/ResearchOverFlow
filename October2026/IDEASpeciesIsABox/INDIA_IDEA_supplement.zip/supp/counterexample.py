import itertools, math
import numpy as np
g = lambda u: -2*np.log(np.cos(u))
def worst_rec(L, R, D0, D1):
    states = [(D0, 0.0)]
    for l, r in zip(L, R):
        states = [(b, max(m + g(b - a) for a, m in states)) for b in (l, r)]
    return max(m + g(D1 - a) for a, m in states)
def J_mode(cu, s, eta, umin=-8.0, umax=8.0):
    cu = np.sort(np.asarray(cu, float))
    if np.any(np.diff(cu) < 2*eta) or cu[0] - eta < umin or cu[-1] + eta > umax: return np.inf
    th = lambda u: np.arctan(np.exp(u)/s)
    return worst_rec(th(cu - eta), th(cu + eta), th(umin), th(umax))
def J(cu, eta, S): return max(J_mode(cu, s, eta) for s in S)
S, eta = (0.1, 10.0), 0.25
found = None
grid = np.arange(-6, 6.5, 0.5)
best = None
for a in itertools.combinations(grid, 2):
    for b in itertools.combinations(grid, 2):
        ja, jb = J(a, eta, S), J(b, eta, S)
        if not (np.isfinite(ja) and np.isfinite(jb)): continue
        m = (np.array(a) + np.array(b))/2
        jm = J(m, eta, S)
        gap = jm - max(ja, jb)
        if best is None or gap > best[0]: best = (gap, a, b, ja, jb, jm, tuple(m))
print(best)
gap, a, b, ja, jb, jm, m = best
for name, c in (('a', a), ('b', b), ('mid', m)):
    print(name, c, [round(J_mode(c, s, eta), 5) for s in S], round(J(c, eta, S), 5))

rng = np.random.default_rng(5)
S, eta = (0.1, 10.0), 0.1
umin, umax = -6.0, 6.0
def Jr(c): return max(J_mode(c, s, eta, umin, umax) for s in S)
print('--- dense designs v2 ---')
def rand_design(n, skew):
    total = (umax - umin) - 2*eta*n
    w = rng.dirichlet(np.ones(n+1)) * np.exp(skew*np.linspace(-1, 1, n+1)); w = w/w.sum()*total
    c = umin + eta + np.cumsum(w[:-1]) + 2*eta*np.arange(n)
    return np.round(c, 3)
best = None; cnt = 0
for trial in range(4000):
    n = int(rng.integers(12, 40))
    a = rand_design(n, rng.normal(0, 2)); b = rand_design(n, rng.normal(0, 2))
    if np.any(np.diff(a) < 2*eta) or np.any(np.diff(b) < 2*eta): continue
    ja, jb = Jr(a), Jr(b)
    if not (np.isfinite(ja) and np.isfinite(jb)) or max(ja, jb) > 1.0: continue
    m = (a + b)/2; jm = Jr(m)
    if not np.isfinite(jm): continue
    cnt += 1; gap = jm - max(ja, jb)
    if best is None or gap > best[0]: best = (gap, a, b, ja, jb, jm, n)
print('pairs tested', cnt, 'best gap', best[0] if best else None)
if best and best[0] > 0:
    gap, a, b, ja, jb, jm, n = best
    for name, c in (('a', a), ('b', b), ('mid', (a+b)/2)):
        print(name, n, [round(J_mode(c, s, eta, umin, umax), 4) for s in S], round(Jr(c), 4))
print('A =', ', '.join(f'{x:.3f}' for x in a))
print('B =', ', '.join(f'{x:.3f}' for x in b))
# robustness of the example: recompute with 3 decimals as printed
A = np.array([float(x) for x in ', '.join(f'{x:.3f}' for x in a).split(',')]); B = np.array([float(x) for x in ', '.join(f'{x:.3f}' for x in b).split(',')])
print('recomputed', round(Jr(A), 4), round(Jr(B), 4), round(Jr((A+B)/2), 4), 'min spacing', np.diff(A).min(), np.diff(B).min(), np.diff((A+B)/2).min())
