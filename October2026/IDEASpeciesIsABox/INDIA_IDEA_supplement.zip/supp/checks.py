"""Numerical checks of the identities and bounds in 'Optimal Robust Covers of INDIA using IDEA'.
Not experiments: each block checks a closed form or inequality stated in the paper."""
import itertools, math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import minimize
rng = np.random.default_rng(20261012)
g = lambda u: -2*np.log(np.cos(u))
OK = []
def check(name, ok, extra=''):
    print(('PASS ' if ok else 'FAIL ') + name, extra); OK.append(bool(ok))

def worst_brute(L, R, D):
    """max over vertices of sum g(increments), endpoints 0 and D, handoff i in [L_i, R_i] (rectangular)."""
    best = -np.inf
    for v in itertools.product(*[(l, r) for l, r in zip(L, R)]):
        t = np.concatenate([[0.0], v, [D]]); d = np.diff(t)
        if np.any(d < -1e-15): continue
        best = max(best, g(d).sum())
    return best

def worst_rec(L, R, D):
    """two-state recurrence (INDIA Prop 7), maximising loss = minimising log P."""
    states = [(0.0, 0.0)]
    for l, r in zip(L, R):
        states = [(b, max(m + g(b - a) for a, m in states)) for b in (l, r)]
    return max(m + g(D - a) for a, m in states)

# C1 recurrence = brute force on random rectangular designs
bad = 0
for _ in range(300):
    n = rng.integers(1, 9); D = rng.uniform(0.2, 1.5)
    cuts = np.sort(rng.uniform(0, D, 2*n)); L, R = cuts[0::2], cuts[1::2]
    bad += abs(worst_brute(L, R, D) - worst_rec(L, R, D)) > 1e-12
check('C1 two-state recurrence equals vertex enumeration', bad == 0)

# C2 equal-centre closed form (alternating pattern)
def J_closed(N, h, w):
    a = w/2
    if N % 2 == 0:
        return g(h+a) + g(h-a) + (N//2 - 1)*(g(h+w) + g(h-w))
    return 2*g(h-a) + (N-1)//2*g(h+w) + (N-3)//2*g(h-w)
bad = 0
for N in range(2, 12):
    for _ in range(20):
        D = rng.uniform(0.3, 1.5); h = D/N; w = rng.uniform(0, h)
        c = h*np.arange(1, N); L, R = c - w/2, c + w/2
        bad += abs(worst_rec(L, R, D) - J_closed(N, h, w)) > 1e-12
check('C2 equal-centre worst case = alternating closed form (N even / odd)', bad == 0)

# C3 refinement while feasible: J(N) decreasing for N <= floor(D/w)
bad = tot = 0
for _ in range(400):
    D = rng.uniform(0.2, 1.5); w = rng.uniform(0.005, 0.3)
    Nmax = int(np.floor(D/w))
    vals = [J_closed(N, D/N, w) for N in range(2, Nmax+1)]
    tot += 1; bad += np.any(np.diff(vals) > 1e-14)
check('C3 equal designs: worst-case loss decreases with N while h >= w', bad == 0, f'({tot} cases)')

# C4 lower bound: J >= sum k_i^2 + sum ((w_i+w_{i-1})/2)^2 >= sum k_i (w_i + w_{i-1})
bad = 0
for _ in range(400):
    n = rng.integers(1, 9); D = rng.uniform(0.2, 1.4)
    cuts = np.sort(rng.uniform(0, D, 2*n)); L, R = cuts[0::2], cuts[1::2]
    mu = np.concatenate([[0], (L+R)/2, [D]]); w = np.concatenate([[0], R-L, [0]])
    k = np.diff(mu); lb1 = (k**2).sum() + (((w[1:]+w[:-1])/2)**2).sum(); lb2 = (k*(w[1:]+w[:-1])).sum()
    J = worst_rec(L, R, D); bad += not (J >= lb1 - 1e-12 >= lb2 - 2e-12)
check('C4 lower bounds sum k^2 + sum((w_i+w_{i-1})/2)^2 >= sum k(w_i+w_{i-1})', bad == 0)

# C5 multiplicative width formula
bad = 0
for _ in range(1000):
    s, sig, eta = np.exp(rng.normal(0, 2)), np.exp(rng.normal(0, 2)), rng.uniform(0, 2)
    th = math.atan(sig/s)
    lhs = math.atan(sig*math.exp(eta)/s) - math.atan(sig*math.exp(-eta)/s)
    bad += abs(lhs - math.atan(math.sinh(eta)*math.sin(2*th))) > 1e-12
check('C5 angular width of [sigma e^-eta, sigma e^eta] = arctan(sinh eta sin 2 theta_s(sigma))', bad == 0)

# C6 tight cover: worst case = best pairing of consecutive widths (blocks of size <= 2)
def best_pairing(w):
    n = len(w); M = np.full(n+1, -np.inf); M[0] = 0.0
    for i in range(1, n+1):
        M[i] = max(M[i], M[i-1] + g(w[i-1]))
        if i >= 2: M[i] = max(M[i], M[i-2] + g(w[i-2] + w[i-1]))
    return M[n]
bad = 0
for _ in range(300):
    n = rng.integers(2, 10); w = rng.dirichlet(np.ones(n)) * rng.uniform(0.2, 1.4)
    b = np.concatenate([[0], np.cumsum(w)])          # tiles [0, D]; handoff intervals I_i = [b_{i-1}, b_i], i = 1..n-1
    D = b[-1]; L, R = b[:-2], b[1:-1]
    # handoffs I_1..I_{n-1}; the last tile [b_{n-1}, b_n] is the final step's own range -> use n-1 handoffs
    bad += abs(worst_rec(L, R, D) - best_pairing(w)) > 1e-12
check('C6 tight cover: worst case = max over partitions of the widths into blocks of 1-2', bad == 0)

# C7 asymptotics for the tight log-uniform cover; spectrum independence
def I_full(eta):
    c = math.sinh(eta); return quad(lambda t: math.atan(c*math.sin(2*t)), 0, math.pi/2)[0]
def tight_log_cover(s, eta, lo=-30.0, hi=30.0):
    u = np.arange(lo, hi + 1e-9, 2*eta)              # boundaries in log sigma, tiles of log-width 2 eta
    th = np.arctan(np.exp(u)/s); return np.diff(th), th[-1] - th[0]
rows = []
for eta in (0.2, 0.1, 0.05, 0.025):
    vals = [best_pairing(tight_log_cover(s, eta)[0]) for s in (0.01, 1.0, 100.0)]
    rows.append((eta, 2*I_full(eta), vals))
for eta, two_I, vals in rows:
    print(f'     eta={eta:5.3f}: 2 I(eta) = {two_I:.5f}; tight log cover worst case for s = 0.01, 1, 100: '
          + ', '.join(f'{v:.5f}' for v in vals) + f'; ratio {vals[1]/two_I:.4f}')
check('C7 tight log cover worst case -> 2 I(eta), equal across scales', all(abs(v[1]/(2*I_full(e)) - 1) < 0.15 and np.ptp(v) < 1e-3 for e, _, v in rows))
# rigorous upper bound 2 sec^2(2 wbar) (I + 2 wbar^2)
ok = True
for eta in (0.4, 0.2, 0.1, 0.05):
    wb = math.atan(math.sinh(eta)); ub = 2/math.cos(2*wb)**2*(I_full(eta) + 2*wb**2)
    ok &= best_pairing(tight_log_cover(1.0, eta)[0]) <= ub
check('C7b tight cover worst case <= 2 sec^2(2 wbar)(I + 2 wbar^2)', ok)
# I(eta) closed form via Legendre chi: int_0^{pi/2} arctan(c sin x) dx = 2 chi_2((sqrt(1+c^2)-1)/c)
def chi2(x, K=4000):
    k = np.arange(K); return np.sum(x**(2*k+1)/(2*k+1)**2)
ok = all(abs(I_full(e) - 2*chi2((math.sqrt(1+math.sinh(e)**2) - 1)/math.sinh(e))) < 1e-9 for e in (0.05, 0.3, 1.0, 2.0))
check('C7c I(eta) = 2 chi_2(tanh(eta/2))', ok)

# C8 (measurement, no assertion) single-mode free optimisation; compare with the tight log cover and 2 I
def design_worst(cen_u, s, eta):
    cen_u = np.sort(cen_u)
    L = np.arctan(np.exp(cen_u - eta)/s); R = np.arctan(np.exp(cen_u + eta)/s)
    if np.any(L[1:] < R[:-1]): return 1e3               # rectangular class only
    return worst_rec(L, R, math.pi/2)
for eta in (0.2, 0.1):
    best = np.inf
    for N in range(int(1/eta), int(6/eta)):
        x0 = np.linspace(-6, 6, N-1) + rng.normal(0, 0.01, N-1)
        r = minimize(design_worst, x0, args=(1.0, eta), method='Nelder-Mead', options=dict(maxiter=4000, xatol=1e-6, fatol=1e-9))
        best = min(best, r.fun)
    tight = best_pairing(tight_log_cover(1.0, eta)[0])
    print(f'     eta={eta}: best optimised rectangular design {best:.5f}; tight log cover {tight:.5f}; 2 I = {2*I_full(eta):.5f}')

# C9 (measurement, no assertion) average case (uniform lives) for the tight cover
for eta in (0.1, 0.05):
    w, _ = tight_log_cover(1.0, eta, -12, 12); b = np.concatenate([[0], np.cumsum(w)]); D = b[-1]
    Lh, Rh = b[:-2], b[1:-1]
    T = rng.uniform(Lh, Rh, (20000, len(Lh)))
    d = np.diff(np.concatenate([np.zeros((20000, 1)), T, np.full((20000, 1), D)], 1), axis=1)
    loss = g(d).sum(1)
    print(f'     eta={eta}: uniform lives mean {loss.mean():.5f}, sd {loss.std():.5f}, 90th percentile of loss (IDEA q = 0.1 fitness) {np.quantile(loss, .9):.5f}, worst {best_pairing(w):.5f}; (7/6) I = {7/6*I_full(eta):.5f}')

# C10 convexity / recombination safety in a mode's angle with equal widths
bad = 0
for _ in range(300):
    n = rng.integers(2, 7); D = 1.2; w = rng.uniform(0.01, 0.08)
    def J(c):
        c = np.sort(c); L, R = c - w/2, c + w/2
        return worst_rec(L, R, D)
    cs = []
    for _ in range(3):
        c = np.sort(rng.uniform(0.1, 1.1, n))
        while np.any(np.diff(c) < w + 1e-3) or c[0] < w or c[-1] > D - w: c = np.sort(rng.uniform(0.1, 1.1, n))
        cs.append(c)
    W = rng.dirichlet(np.ones(3)); cbar = sum(Wi*ci for Wi, ci in zip(W, cs))
    bad += J(cbar) > sum(Wi*J(ci) for Wi, ci in zip(W, cs)) + 1e-12
check('C10 recombination: J(sum W_j c_j) <= sum W_j J(c_j) (equal widths, one mode)', bad == 0)

# C11 multi-mode in log sigma: not convex -- find a violation of midpoint convexity
viol = 0
for _ in range(2000):
    n = 4; eta = 0.15
    def Jm(cu):
        return max(design_worst(cu, s, eta) for s in (0.1, 10.0))
    a, b = np.sort(rng.uniform(-4, 4, n)), np.sort(rng.uniform(-4, 4, n))
    ja, jb = Jm(a), Jm(b)
    if ja < 1e3 and jb < 1e3:
        jm = Jm((a+b)/2)
        viol += jm > max(ja, jb) + 1e-9
check('C11 two-mode objective in log sigma is not quasi-convex (violations found)', viol > 0, f'({viol} midpoint violations of quasi-convexity)')

# C12 additive single-mode bounds: any rectangular design with widths >= w has J >= 2 D w - 1.5 w^2;
#     the centred tight design (handoffs [(i-1/2)w, (i+1/2)w]) has J <= sec^2(2w) (2 D w - 1.5 w^2)
bad = 0
for _ in range(300):
    w = rng.uniform(0.01, 0.12); M = int(rng.integers(2, 14)); D = M*w
    c = w*np.arange(1, M); Jt = worst_rec(c - w/2, c + w/2, D)
    lo, hi = 2*D*w - 1.5*w*w, (2*D*w - 1.5*w*w)/math.cos(2*w)**2
    bad += not (lo - 1e-12 <= Jt <= hi + 1e-12)
    # random rectangular designs with widths >= w, any number of steps
    n = int(rng.integers(0, M)); extra = D - n*w
    if n == 0: Jr_ = g(D)
    else:
        gaps = rng.dirichlet(np.ones(n+1))*extra; L = np.cumsum(gaps[:-1]) + w*np.arange(n); R = L + w
        Jr_ = worst_rec(L, R, D)
    bad += Jr_ < lo - 1e-12
check('C12 additive: 2Dw - 1.5w^2 <= OPT <= J(centred tight) <= sec^2(2w)(2Dw - 1.5w^2)', bad == 0)

# C13 multiplicative lower bound (Theorem 7a): J_s >= (2 I_s - 2 F_d sqrt(I_s)) / (1 + 4.25 L), L = 2 sinh eta,
#     F_d = max of f_s at the two arc ends; tested at practical eta and on truncated arcs, incl. designs close to optimal
def th_s(u, s): return np.arctan(np.exp(u)/s)
def Jmult(cu, s, eta, umin, umax):
    states = [(th_s(umin, s), 0.0)]
    for l, r in zip(th_s(cu - eta, s), th_s(cu + eta, s)):
        states = [(b, max(m + g(b - a) for a, m in states)) for b in (l, r)]
    return max(m + g(th_s(umax, s) - a) for a, m in states)
bad = tot = 0; ratios = []
for _ in range(400):
    eta = rng.uniform(0.02, 0.4); s = math.exp(rng.uniform(-2, 2))
    umin, umax = rng.uniform(-10, -1), rng.uniform(1, 10)
    n = int(rng.integers(1, int((umax-umin)/(2*eta))))
    extra = (umax - umin) - 2*eta*n
    gaps = rng.dirichlet(np.ones(n+1)*rng.uniform(0.3, 5))*extra
    cu = umin + eta + np.cumsum(gaps[:-1]) + 2*eta*np.arange(n)
    J = Jmult(cu, s, eta, umin, umax)
    a, b = th_s(umin, s), th_s(umax, s); c = math.sinh(eta)
    f = lambda t: math.atan(c*math.sin(2*t))
    Is = quad(f, a, b)[0]; Fd = max(f(a), f(b)); L = 2*c
    lb = (2*Is - 2*Fd*math.sqrt(Is))/(1 + 4.25*L)
    tot += 1; bad += J < lb - 1e-12; ratios.append(lb/J)
# near-optimal designs: the tight log cover itself
for eta in (0.05, 0.1, 0.2, 0.4):
    for s in (0.1, 1.0, 10.0):
        umin, umax = -12.0, 12.0
        nt = int(np.floor((umax-umin)/(2*eta)))
        cu = umin + eta + 2*eta*np.arange(nt - 0)
        cu = cu[cu + eta <= umax]
        J = Jmult(cu, s, eta, umin, umax)
        a, b = th_s(umin, s), th_s(umax, s); c = math.sinh(eta); f = lambda t: math.atan(c*math.sin(2*t))
        Is = quad(f, a, b)[0]; Fd = max(f(a), f(b))
        lb = (2*Is - 2*Fd*math.sqrt(Is))/(1 + 4.25*2*c)
        tot += 1; bad += J < lb - 1e-12
print(f'     random designs: lower bound / J ranges {min(ratios):.3f} to {max(ratios):.3f}')
check('C13 Theorem 7(a): J_s >= (2I_s - 2 F_d sqrt(I_s))/(1 + 4.25 L), practical eta, truncated arcs', bad == 0, f'({tot} designs)')

# C14 average case (uniform lives): E loss >= sum(k^2 + m^2/6) on random designs; tight cover E ~ (7/6) sum w^2
bad = 0
for _ in range(100):
    n = int(rng.integers(1, 8)); D = rng.uniform(0.3, 1.2)
    cuts = np.sort(rng.uniform(0, D, 2*n)); L, R = cuts[0::2], cuts[1::2]
    T = rng.uniform(L, R, (200000, n)); d = np.diff(np.concatenate([np.zeros((200000, 1)), T, np.full((200000, 1), D)], 1), axis=1)
    E = g(d).sum(1).mean(); se = g(d).sum(1).std()/math.sqrt(200000)
    mu = np.concatenate([[0], (L+R)/2, [D]]); w = np.concatenate([[0], R-L, [0]]); k = np.diff(mu); m = (w[1:]+w[:-1])/2
    bad += E < (k**2 + m**2/6).sum() - 4*se
check('C14 average case: E loss >= sum(k_i^2 + m_i^2/6)', bad == 0)

# C15 the explicit two-mode counterexample (s = 0.1, 10; eta = 0.1; log sigma in [-6, 6])
A = np.array([-5.900, -5.698, -5.496, -5.295, -5.084, -4.859, -4.646, -4.367, -4.105, -3.873, -3.670, -3.149, -2.233, 1.937, 2.783])
B = np.array([-5.085, -4.444, -3.341, -2.556, -0.611, 0.341, 1.904, 2.105, 2.376, 3.065, 3.455, 4.038, 4.320, 4.978, 5.726])
def Jmode(cu, s, eta=0.1, umin=-6.0, umax=6.0):
    th = lambda u: np.arctan(np.exp(u)/s)
    states = [(th(umin), 0.0)]
    for l, r in zip(th(cu - eta), th(cu + eta)):
        states = [(b, max(m + g(b - a) for a, m in states)) for b in (l, r)]
    return max(m + g(th(umax) - a) for a, m in states)
JA, JB, JM = (max(Jmode(c, s) for s in (0.1, 10.0)) for c in (A, B, (A+B)/2))
print(f'     J(A) = {JA:.4f}, J(B) = {JB:.4f}, J((A+B)/2) = {JM:.4f}; min spacings {np.diff(A).min():.3f}, {np.diff(B).min():.3f}, {np.diff((A+B)/2).min():.3f}')
check('C15 counterexample to quasi-convexity in log noise (scales 0.1 and 10)', JM > max(JA, JB) and min(np.diff(A).min(), np.diff(B).min()) >= 0.2)
J1 = [Jmode(c, 10.0) for c in (A, B, (A+B)/2)]
print(f'     scale 10 alone: J(A) = {J1[0]:.4f}, J(B) = {J1[1]:.4f}, J((A+B)/2) = {J1[2]:.4f}')
check('C15b the same counterexample with the single scale s = 10', J1[2] > max(J1[0], J1[1]))

# C16 Theorem 12: gradient in log-noise centres uses theta_s' at the vertex point, (1/2) sin 2 theta_s(c_i +- eta)
def argmax_vertex(cu, s, eta, umin, umax):
    L_, R_ = cu - eta, cu + eta
    best, bestv = -np.inf, None
    for v in itertools.product(*[(0, 1) for _ in cu]):
        t = np.where(np.array(v) == 1, R_, L_)
        val = g(np.diff(th_s(np.concatenate([[umin], t, [umax]]), s))).sum()
        if val > best: best, bestv = val, t
    return best, bestv
bad = 0
for _ in range(100):
    n = int(rng.integers(2, 6)); eta = 0.1; s = 1.0; umin, umax = -4.0, 4.0
    cu = np.sort(rng.uniform(-3, 3, n))
    if np.any(np.diff(cu) < 2*eta + 0.05): continue
    J0, t = argmax_vertex(cu, s, eta, umin, umax)
    thp = np.concatenate([[umin], t, [umax]]); d = np.diff(th_s(thp, s))
    grad = 0.5*np.sin(2*th_s(t, s))*(2*np.tan(d[:-1]) - 2*np.tan(d[1:]))
    fd = np.array([(Jmult(cu + 1e-7*np.eye(n)[i], s, eta, umin, umax) - J0)/1e-7 for i in range(n)])
    bad += not np.allclose(fd, grad, rtol=1e-4, atol=1e-6)
check('C16 Theorem 12: log-noise gradient = (1/2) sin 2 theta_s(vertex point) (g\'(d_i) - g\'(d_{i+1}))', bad == 0)

# C17 Theorem 4(c) general upper bound: OPT <= J(equal design, M = floor(D/w)) <= sec^2(3w)(2Dw - 1.5w^2 + w^3/(D - w)), D >= 2w
bad = 0
for _ in range(500):
    w = rng.uniform(0.005, 0.15); D = rng.uniform(2*w, min(1.5, 25*w))
    if 3*w >= math.pi/2: continue
    M = int(np.floor(D/w)); h = D/M; c = h*np.arange(1, M)
    Jeq = worst_rec(c - w/2, c + w/2, D)
    ub = (2*D*w - 1.5*w*w + w**3/(D - w))/math.cos(3*w)**2
    bad += Jeq > ub + 1e-12
check('C17 Theorem 4(c): equal design with floor(D/w) steps <= sec^2(3w)(2Dw - 1.5w^2 + w^3/(D-w))', bad == 0)

# C18 Theorem 14(c): tight cover, uniform lives: E loss <= sec^2(2 wbar)(7/6 sum w^2 + 2 wbar^2)
bad = 0
for eta in (0.05, 0.1, 0.2):
    for s in (0.3, 1.0, 3.0):
        u = np.arange(-8, 8 + 1e-9, 2*eta); th = th_s(u, s); w = np.diff(th); b = th - th[0]; D = b[-1]
        Lh, Rh = b[:-2], b[1:-1]
        T = rng.uniform(Lh, Rh, (40000, len(Lh)))
        d = np.diff(np.concatenate([np.zeros((40000, 1)), T, np.full((40000, 1), D)], 1), axis=1)
        E = g(d).sum(1).mean(); wb = w.max()
        bad += E > (7/6*(w**2).sum() + 2*wb**2)/math.cos(2*wb)**2
check('C18 Theorem 14(c): tight cover mean loss bound', bad == 0)

# C19 Proposition 13: J = E + sum |dE_i| w_i/2 + O(N max w^2)
bad = 0
for _ in range(100):
    n = int(rng.integers(2, 7)); D = 1.2
    mu = np.sort(rng.uniform(0.1, 1.1, n))
    if np.any(np.diff(mu) < 0.05): continue
    e = lambda m: g(np.diff(np.concatenate([[0], m, [D]]))).sum()
    d = np.diff(np.concatenate([[0], mu, [D]])); dE = 2*(np.tan(d[:-1]) - np.tan(d[1:]))
    for w in (1e-3, 2e-3):
        J = worst_rec(mu - w/2, mu + w/2, D)
        pred = e(mu) + np.abs(dE).sum()*w/2
        bad += abs(J - pred) > 40*n*w*w
check('C19 Proposition 13 first-order expansion', bad == 0)
print('ALL PASS' if all(OK) else 'SOME FAIL')
