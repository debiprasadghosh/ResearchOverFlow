# Supplement: Optimal Robust Covers of INDIA using IDEA

- `checks.py` runs the numerical checks C1–C19 (plus C15b) cited in Appendix A of the paper: `python3 checks.py`
- `checks_output.txt` is the output of that run (ends in ALL PASS).
- `counterexample.py` is the search that produced the two designs in Proposition 11 (non-convexity in log σ, single scale s = 10, η = 0.1, u ∈ [−6, 6]).

Every check is numerical confirmation only. The paper's results are proved analytically.
