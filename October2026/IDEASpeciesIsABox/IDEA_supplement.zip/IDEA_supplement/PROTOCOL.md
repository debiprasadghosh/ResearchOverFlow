# IDEA protocol (frozen before any confirmatory run)

Interval Diffusion Evolutionary Algorithm (IDEA): Diffusion Evolution (Zhang, Hartl, Hazan & Levin,
ICLR 2025, arXiv:2410.02543v3) in which the unit of selection is a species, an axis-aligned box, rather
than a point. This protocol fixes the algorithms, landscapes, seeds, metrics, hypotheses and decision
rules before any confirmatory run. Everything listed under "Pilots" was run before freezing and is
reported as such.

## 1. Sources

- Paper: the user-supplied PDF of arXiv:2410.02543v3 (Eqs. 1-12, 13-21; Algorithm 1; App. A.2-A.4; Tables 1-3).
- Reference code: github.com/Zhangyanbo/diffusion-evolution at commit 41ac6ca
  (diffevo/ddim.py, generator.py, fitnessmapping.py; experiments/benchmarks/methods/diff_evo.py,
  benchmarks.py, run_benchmarks.py, statistic.py) and github.com/bhartl/foobench at commit 18de5da
  (foobench/objective.py, foos.py).
- The IDEA sketch supplied by the user (the "sketch").

## 2. Landscapes

Coordinates as in the reference benchmarks: the population lives in population coordinates x,
initialised N(0, I); the landscape is evaluated at u = 4x (function coordinates, the paper's box
(-4, 4)^2). Fitness is the paper's Eq. 19 density map g in [0, 1] (T = 1), with the code's targets,
scales and maximum distances.

- **Paper landscapes** P = {Rosenbrock, Beale, Himmelblau, Ackley, Rastrigin}. Ackley and Rastrigin
  are maximised (App. A.4): four global optima near the corners, at (±3.61405, ±3.61405) and
  (±3.51786, ±3.51786). Himmelblau: four minima. Rosenbrock (1, 1), Beale (3, 0.5).
  - *coded*: outside the box, foobench's limit values (|u_d| > 4 in any coordinate): g = 0.706
    (Rosenbrock), 0.0067 (Beale), 0.0028 (Himmelblau), 0 (Ackley, Rastrigin).
  - *lethal*: g = 0 outside the box for every landscape. **Primary** for every comparison.
- **Held-out landscapes** H = {six-hump camel back, Shubert, Vincent} (CEC 2013 niching F5, F6, F7,
  2-D), mapped affinely onto (-4, 4)^2, Eq. 19's form with target f*, D = |f - f*|, D_max over the
  box, and scale s calibrated so that 10% of the box has g >= 0.5 (the paper's landscapes: 7.9-18.2%,
  median 9.4%). g = 0 outside. 2, 18 and 36 global optima. **No algorithm was run on H before
  freezing.**
- **Two-peak landscape**: g(u) = max(h1 exp(-|u-a|^2/2w1^2), h2 exp(-|u-b|^2/2w2^2)), a = (2, 2),
  b = (-2, -2), tall-narrow h1 = 1, w1 = 0.4; low-broad h2 = 0.7, w2 = 1.2; g = 0 outside the box.

Optimum radius: delta_L = min(0.25, half the smallest distance between two global optima)
(function coordinates): 0.25 everywhere except Shubert 0.1767 and Vincent 0.1195.

## 3. Algorithms

All runs use the paper's benchmark schedule: cosine alpha schedule (DDIMSchedulerCosine) with
num_step = 25 (24 updates), noise Eq. 17 with sigma_m = 0.1 (the value in the benchmark code, which
reproduces Table 3; the text says sigma_m = 1), and an equal budget of 12,800 fitness evaluations
(24 x 512 during the run plus 512 for the final output).

**DE** (Diffusion Evolution): numpy port of BayesianGenerator + ddim_step (uniform density, the
code's 1e-9 floors), N = 512. Output: the final population and its fitness.

**IDEA** (idealib.idea_run; defaults below). K = 32 species, n = 16 lives per species per generation
(K n = 512). Each generation:

1. *Evaluate*: n lives uniform in each box; species fitness F = empirical q-quantile of g over its
   lives, q = 0.1 (the k-th smallest, k = ceil(q n) = 2). Q = F.
2. *Extinction* (governor 3): species with F < theta_t die, theta_t = theta alpha_t max_k F_k,
   theta = 0.5 (relative, annealed threshold). If none survives, the best survives.
3. *Exclusion* (governor 2): in order of decreasing F, a box overlapping a fitter kept box has the face
   on its axis of least penetration clipped to the winner's face; if its half-width would fall below
   rho_min it is excluded. Lives outside clipped boxes are dropped and F recomputed.
4. *Speciation*: if the elite lives (g >= the box median) have a gap wider than half the box along a
   coordinate, the box splits at the gap's midpoint (largest normalised gap; both halves >= rho_min);
   the parent dies.
5. *Cap and birth*: above K, the fittest K are kept; below K, a uniformly chosen living box splits at
   its centre along its widest coordinate (fission).
6. *Denoise*: weights W_ij proportional to Q_j K_ij flow_ij with
   K_ij = exp(-sum_d (c_id - sqrt(alpha_t) c_jd)^2 / (2 (1 - alpha_t)(rho_id + rho_jd)^2)) (unnormalised,
   as the reference code's gaussian_prob) and flow_ij = 1{gap(B_i, B_j) < r_t},
   r_t = sqrt((1 - alpha_t)/alpha_t) (the paper's neighbourhood radius, App. A.3). c_hat = W c,
   rho_hat = W rho (mean type). Centres take the DDIM step (Eq. 5, Eq. 17 noise) towards c_hat.
   Radii: rho' = clip(s_t rho_hat + sigma_t rho_hat |xi|, rho_min, rho_max), xi ~ N(0, I) (the sketch's
   inflating radius mutation), with
   - **repaired** s_t = sqrt((1 - alpha_{t-1})/(1 - alpha_t)) (default; IDEA-R);
   - **literal** s_t = sqrt(alpha_{t-1}) (the sketch as written; IDEA-L);
   - **none** s_t = 1 (governor 1 removed).
   rho_min = 0.0125 (pop; 0.05 function units), rho_max = 1.0, initial rho_T = rho_min / prod_t s_t
   (repaired) = 0.3951 (1.580 function units), so the repaired schedule alone lands on rho_min.
7. *Output*: after the last update, one more evaluation; the output set is the final K n lives and their
   fitness.

## 4. Arms

Seeds: run i in {0, ..., 99} of every (arm, landscape) cell uses np.random.default_rng(100000 + i).

**Primary** (P lethal and H): `DE`, `IDEA_R`, `IDEA_L`.
**Secondary** (P coded): `DE`, `IDEA_R`, `IDEA_L`.
**Exploratory ablations** (P lethal): `DE_sm1` (sigma_m = 1), `DE_N32` (N = 32), `R_noG1`
(radius_rule none), `R_noG2` (no exclusion), `R_noG3` (no extinction), `R_nospec` (no speciation),
`R_abstheta` (theta_t = theta alpha_t), `R_normK` (normalised kernel), `R_fitbirth` (fission parent
in proportion to Q), `R_within` (c_hat from fitness-weighted life means), `R_gauss` (symmetric radius
mutation), `R_K128` (K = 128, n = 4).
**Explosion** (P lethal; rho_hat moment type = radius of the uniform box matching the second moment of
the weighted mixture of neighbour boxes, "union-style growth"; rho_max = infinity): `X_full`,
`X_noG1`, `X_noG2`, `X_noG3`, `X_noall`.
**Two-peak**:
- `T_sel_m` (selection-only tournament): 16 species at a and 16 at b, centres frozen
  (move_centres = False), initial radius rho_T = m rho_T,crit with rho_T,crit = 0.5908 function
  units (T13), m in {0.25, 0.354, 0.5, 0.707, 1, 1.414, 2, 2.83, 4}; all else IDEA-R.
- `T_full_m` (same with full dynamics; exploratory); `T_DE_vitro` (DE with 256 + 256 at a, b; exploratory).
- `V_DE`, `V_IDEA_R` (in vivo: random initialisation, defaults).

## 5. Metrics (per run; function coordinates)

Output set: DE final population; IDEA final lives (512 points each). Viable: g >= 0.5.

- `top_fit`: mean g of the 64 fittest outputs. `best`: max g. `top_entropy`: the paper's entropy
  (bits; cells round(10 u)) of the 64 fittest outputs.
- `optima`: number of global optima with a viable output within delta_L. (`optima_any`: any output.)
- `basins`: number of distinct steepest-ascent basins (0.01 grid) holding a viable output.
- `viable_frac`, `inside_frac`.
- `robust_0.2`, `robust_0.05`: mean over the 64 fittest outputs of the q = 0.1 quantile of g over a box
  of half-width 0.2 (0.05) function units around the output (256 uniform samples, fixed RNG).
- IDEA: final median half-width (geometric mean over coordinates; pop units), fraction of species
  centres outside the box, union-vs-hull non-viable shares of the final boxes (g < 0.5; Monte Carlo,
  100,000 points over the bounding box), per-generation radius trajectory and event counts.
- DE also: the paper's metrics (mean x0-estimate fitness of the top 64 by x0 fitness; entropy of the
  final population members with those indices).
- Two-peak: tall kept / broad kept = a viable output within 0.25 of a / of b.

Bootstrap: 95% percentile interval of the difference of means between two arms (unpaired; 10,000
resamples; np.random.default_rng(12345)).

## 6. Hypotheses and decision rules

From the sketch:

- **H1** (Rosenbrock, worse). On Rosenbrock (lethal), `top_fit`(IDEA_R) < `top_fit`(DE).
  Supported if the interval of IDEA_R - DE lies below 0; rejected if above 0; else inconclusive.
- **H2** (more optima kept). On Himmelblau, Ackley and Rastrigin (lethal), `optima`(IDEA_R) >
  `optima`(DE). Per landscape: supported if the interval of IDEA_R - DE lies above 0, rejected if below,
  else inconclusive. H2 is supported if supported on all three, rejected if rejected on any.
  **H2-H**: the same rule on the held-out landscapes.
- **H3** (governors). Explosion arms. A run explodes if its final median half-width >= 1.0 (pop; a box
  at least as wide as the whole domain). An arm explodes on a landscape if >= 50 of 100 runs explode.
  H3a: `X_full` explodes on no landscape. H3b: each of `X_noG1`, `X_noG2`, `X_noG3` explodes on every
  landscape. H3 is supported if H3a and H3b hold; otherwise rejected (with the failing cells listed).

From the theory (Section 4 of the paper; checks T1-T17):

- **H4a** (selection reads the lower quantile). Selection-only tournament: let P_m be the share of runs
  that keep the tall peak. Predicted: (i) P_m >= 0.8 for every m <= 0.5; (ii) P_m <= 0.2 for every m >= 2;
  (iii) the first downward crossing of 0.5 (log-linear interpolation between grid points) lies in
  [0.5, 2]. Supported if (i)-(iii) all hold.
- **H4b** (in vivo). P(`V_IDEA_R` keeps the tall peak) <= 0.2 and P(`V_DE` keeps it) >= 0.8.
- **H5** (robustness). On each paper landscape (lethal), `robust_0.2`(IDEA_R) > `robust_0.2`(DE):
  supported if the interval lies above 0 on all five, rejected if below 0 on any.
- **H6** (flight to flatness, landscapes as coded). On Rosenbrock (coded) the median over runs of the
  fraction of IDEA_R's final species centres outside the box is >= 0.5.
- **H7** (the radius rule as written collapses). In `IDEA_L` on every paper landscape (lethal), the
  median over runs of the fraction of species at rho_min after the third update is >= 0.9.

Everything else is exploratory and is reported as such.

## 7. Pilots (run before freezing; paper landscapes and the two-peak landscape only)

- DE reproduction of Table 3 (seeds 0-99, landscapes as coded, sigma_m in {0.1, 1}); logs/repro_de.log.
- Smoke and design pilots (seeds 1001, 2000-2004, 3000-3007, 3001, 4000-4009, 7000-7003, 8000-8019,
  9000-9003, 9100-9101, 500-529): scratch/, pilots/, logs/pilot_*.log. Pipeline smoke test of
  idea_runs.py and idea_eval.py (seeds 9500-9501, every cell except the held-out ones):
  logs/smoke_runs/, logs/smoke_evals/. Design changes made after
  them: fitness 0 outside the box for the IDEA comparisons (species fled to the coded plateaus);
  relative annealed extinction threshold (an absolute threshold extinguished every species in the
  first generations); uniform fission parent; half-normal (inflating) radius mutation; overlap
  tolerance 1e-12 (rounding produced spurious overlaps); frozen-centre tournament (in the full
  dynamics, seeded species drift off their peaks, T11).
- The tournament pilot (20 seeds) put the crossing of H4a near 2.2 rho_T,crit, outside the
  predicted window, with P_m = 0.55 at m = 2 and 0.40 at m = 2.83. The prediction (T13) and its
  window were chosen before that pilot was run and are kept unchanged.
- Pilots used none of the confirmatory seeds and none of the held-out landscapes.
