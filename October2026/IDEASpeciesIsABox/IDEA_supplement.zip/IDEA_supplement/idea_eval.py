"""Frozen evaluator of the IDEA study: metrics per run (PROTOCOL.md, Section 5) and the decision rules
of Section 6.

    python3 idea_eval.py metrics [--workers 2]   # runs/<set>/*.npz -> evals/<set>/*.json
    python3 idea_eval.py decide                   # evals -> evals/decisions.json (printed)
"""
import sys, os, json, glob, math
import numpy as np
from multiprocessing import Pool

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import idealib as L

HERE = os.path.dirname(os.path.abspath(__file__))
RUNS = os.path.join(HERE, sys.argv[sys.argv.index('--runs') + 1]) if '--runs' in sys.argv else os.path.join(HERE, 'runs')
EVALS = os.path.join(HERE, sys.argv[sys.argv.index('--evals') + 1]) if '--evals' in sys.argv else os.path.join(HERE, 'evals')
MULTS = [0.25, 0.354, 0.5, 0.707, 1.0, 1.414, 2.0, 2.83, 4.0]
_BASIN = {}


def basin(nm, outside):
    key = (nm, outside)
    if key not in _BASIN:
        _BASIN[key] = L.BasinMap(L.make_g(nm, outside) if outside else L.make_g(nm))
    return _BASIN[key]


def eval_cell(path):
    meta = json.load(open(path.replace('.npz', '.json')))
    A = np.load(path)
    nm, outside, kind = meta['landscape'], meta['outside'], meta['kind']
    g = L.make_g(nm, outside) if outside else L.make_g(nm)
    B = basin(nm, outside)
    seeds = A['seeds']
    per = []
    for i, s in enumerate(seeds):
        if kind == 'de':
            Xf, f = A['x'][i] * L.SCALING, A['fit'][i]
        else:
            Xf, f = A['lives'][i] * L.SCALING, A['lives_fit'][i]
        m = L.output_metrics(Xf, f, B, nm)
        top = Xf[L.top_k_idx(f)]
        m['robust_0.2'] = float(L.robust_fitness(g, top, 0.2, rng=np.random.default_rng(int(s) + 7)).mean())
        m['robust_0.05'] = float(L.robust_fitness(g, top, 0.05, rng=np.random.default_rng(int(s) + 8)).mean())
        if nm == 'two_peak':
            P = L.TWO_PEAK
            m['tall_kept'] = L.optima_covered(Xf, P['a'][None], 0.25, f, L.VIABLE)
            m['broad_kept'] = L.optima_covered(Xf, P['b'][None], 0.25, f, L.VIABLE)
        if kind == 'de':
            x0f = A['x0_fit'][i]
            idx = L.top_k_idx(x0f)
            m['paper_fitness'] = float(x0f[idx].mean())
            m['paper_entropy'] = L.entropy_bits(A['x'][i][idx] * L.SCALING)
        else:
            R, C = A['radii'][i], A['centres'][i]
            gm = np.sqrt(np.prod(R, axis=1))
            m['final_rho'] = float(np.median(gm))
            m['final_rho_max'] = float(gm.max())
            m['centres_outside'] = float(np.any(np.abs(C * L.SCALING) > 4.0, axis=1).mean())
            m['frac_at_min_3'] = float(A['log_frac_at_min'][i][2])
            m['total_extinction'] = int(A['total_extinction'][i])
            for k in ('extinct', 'excluded', 'splits', 'births'):
                m[f'n_{k}'] = int(A[f'log_{k}'][i].sum())
            m['med_rho_traj'] = [float(v) for v in A['log_med_rho'][i]]
            m['F_median'] = float(np.median(A['F'][i]))
            if np.all(np.isfinite(R)) and gm.max() < 50:
                cm = L.clade_metrics(g, C, R, L.VIABLE, n_mc=100000, rng=np.random.default_rng(int(s) + 9))
                m.update({f'clade_{k}': float(v) for k, v in cm.items()})
        if 'two_peak' == nm and kind != 'de':
            Cf = A['centres'][i] * L.SCALING
            m['share_on_tall'] = float(np.mean(np.sqrt(((Cf - L.TWO_PEAK['a']) ** 2).sum(1)) <= L.TWO_PEAK['w1']))
        per.append(m)
    out = dict(meta=meta, n=len(per), runs=per)
    od = os.path.join(EVALS, meta['set'])
    os.makedirs(od, exist_ok=True)
    json.dump(out, open(os.path.join(od, os.path.basename(path).replace('.npz', '.json')), 'w'))
    return os.path.basename(path)


# ------------------------------------------------------------------------------------------- decisions
def load(sset, arm, nm):
    return json.load(open(os.path.join(EVALS, sset, f'{arm}__{nm}.json')))['runs']


def col(runs, key):
    return np.array([r[key] for r in runs], float)


def boot_diff(a, b, n=10000, seed=12345):
    rng = np.random.default_rng(seed)
    ia = rng.integers(0, len(a), (n, len(a)))
    ib = rng.integers(0, len(b), (n, len(b)))
    d = a[ia].mean(1) - b[ib].mean(1)
    return float(a.mean() - b.mean()), float(np.quantile(d, 0.025)), float(np.quantile(d, 0.975))


def verdict(lo, hi, sign):
    """sign = +1: hypothesis says difference > 0."""
    if sign > 0:
        return 'supported' if lo > 0 else ('rejected' if hi < 0 else 'inconclusive')
    return 'supported' if hi < 0 else ('rejected' if lo > 0 else 'inconclusive')


def decide():
    D = {}
    # H1
    a, b = col(load('primary', 'IDEA_R', 'rosenbrock'), 'top_fit'), col(load('primary', 'DE', 'rosenbrock'), 'top_fit')
    d, lo, hi = boot_diff(a, b)
    D['H1'] = dict(diff=d, ci=[lo, hi], IDEA_R=a.mean(), DE=b.mean(), verdict=verdict(lo, hi, -1))
    # H2, H2-H
    for key, lands in (('H2', ['himmelblau', 'ackley', 'rastrigin']), ('H2-H', L.HELDOUT)):
        cells = {}
        if not all(os.path.exists(os.path.join(EVALS, 'primary', f'IDEA_R__{nm}.json')) for nm in lands):
            D[key] = dict(verdict='missing')
            continue
        for nm in lands:
            a, b = col(load('primary', 'IDEA_R', nm), 'optima'), col(load('primary', 'DE', nm), 'optima')
            d, lo, hi = boot_diff(a, b)
            cells[nm] = dict(diff=d, ci=[lo, hi], IDEA_R=a.mean(), DE=b.mean(), verdict=verdict(lo, hi, +1))
        vs = [c['verdict'] for c in cells.values()]
        overall = 'supported' if all(v == 'supported' for v in vs) else ('rejected' if 'rejected' in vs else 'inconclusive')
        D[key] = dict(cells=cells, verdict=overall)
    # H3
    cells, fails = {}, []
    for arm in ('X_full', 'X_noG1', 'X_noG2', 'X_noG3', 'X_noall'):
        for nm in L.LANDSCAPES:
            fr = col(load('explosion', arm, nm), 'final_rho')
            n_expl = int((fr >= 1.0).sum())
            cells[f'{arm}/{nm}'] = dict(n_exploded=n_expl, median_final_rho=float(np.median(fr)), explodes=n_expl >= 50)
    h3a = all(not cells[f'X_full/{nm}']['explodes'] for nm in L.LANDSCAPES)
    h3b = all(cells[f'{arm}/{nm}']['explodes'] for arm in ('X_noG1', 'X_noG2', 'X_noG3') for nm in L.LANDSCAPES)
    D['H3'] = dict(cells=cells, H3a=h3a, H3b=h3b, verdict='supported' if (h3a and h3b) else 'rejected')
    # H4a
    P = {m: col(load('twopeak', f'T_sel_m{m}', 'two_peak'), 'tall_kept').mean() for m in MULTS}
    i_ok = all(P[m] >= 0.8 for m in MULTS if m <= 0.5)
    ii_ok = all(P[m] <= 0.2 for m in MULTS if m >= 2.0)
    cross = None                          # None: P never falls below 0.5 on the grid (crossing above 4)
    if P[MULTS[0]] < 0.5:
        cross = 0.0                       # already below 0.5 at the smallest grid point
    else:
        for m1, m2 in zip(MULTS[:-1], MULTS[1:]):
            if P[m1] >= 0.5 > P[m2]:
                t = (P[m1] - 0.5) / (P[m1] - P[m2])
                cross = math.exp(math.log(m1) + t * (math.log(m2) - math.log(m1)))
                break
    iii_ok = cross is not None and 0.5 <= cross <= 2.0
    D['H4a'] = dict(P=P, crossing=cross, i=i_ok, ii=ii_ok, iii=iii_ok,
                    verdict='supported' if (i_ok and ii_ok and iii_ok) else 'rejected')
    # H4b
    pi = col(load('twopeak', 'V_IDEA_R', 'two_peak'), 'tall_kept').mean()
    pd = col(load('twopeak', 'V_DE', 'two_peak'), 'tall_kept').mean()
    D['H4b'] = dict(P_IDEA_R=pi, P_DE=pd, verdict='supported' if (pi <= 0.2 and pd >= 0.8) else 'rejected')
    # H5
    cells = {}
    for nm in L.LANDSCAPES:
        a, b = col(load('primary', 'IDEA_R', nm), 'robust_0.2'), col(load('primary', 'DE', nm), 'robust_0.2')
        d, lo, hi = boot_diff(a, b)
        cells[nm] = dict(diff=d, ci=[lo, hi], IDEA_R=a.mean(), DE=b.mean(), verdict=verdict(lo, hi, +1))
    vs = [c['verdict'] for c in cells.values()]
    D['H5'] = dict(cells=cells, verdict='supported' if all(v == 'supported' for v in vs) else
                   ('rejected' if 'rejected' in vs else 'inconclusive'))
    # H6
    co = col(load('coded', 'IDEA_R', 'rosenbrock'), 'centres_outside')
    D['H6'] = dict(median_outside=float(np.median(co)), verdict='supported' if np.median(co) >= 0.5 else 'rejected')
    # H7
    cells = {nm: float(np.median(col(load('primary', 'IDEA_L', nm), 'frac_at_min_3'))) for nm in L.LANDSCAPES}
    D['H7'] = dict(cells=cells, verdict='supported' if all(v >= 0.9 for v in cells.values()) else 'rejected')
    json.dump(D, open(os.path.join(EVALS, 'decisions.json'), 'w'), indent=1, default=float)
    for k, v in D.items():
        print(k, v['verdict'])
        print('   ', json.dumps({kk: vv for kk, vv in v.items() if kk != 'verdict'}, default=float)[:1500])
    return D


if __name__ == '__main__':
    mode = sys.argv[1] if len(sys.argv) > 1 else 'metrics'
    if mode == 'metrics':
        workers = int(sys.argv[sys.argv.index('--workers') + 1]) if '--workers' in sys.argv else 2
        paths = sorted(glob.glob(os.path.join(RUNS, '*', '*.npz')))
        with Pool(workers) as pool:
            for i, p in enumerate(pool.imap_unordered(eval_cell, paths)):
                print(f'[{i + 1}/{len(paths)}] {p}', flush=True)
    elif mode == 'decide':
        decide()
    else:
        raise SystemExit(__doc__)
