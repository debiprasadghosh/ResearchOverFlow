"""Every number quoted in the IDEA paper, from evals/ (frozen evaluator outputs) and, for the
exploratory per-optimum analysis, runs/ (raw outputs). Written after the confirmatory runs.

    python3 idea_facts.py > facts_output.txt
"""
import sys, os, json, math
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import idealib as L

HERE = os.path.dirname(os.path.abspath(__file__))
EV, RU = os.path.join(HERE, 'evals'), os.path.join(HERE, 'runs')
MULTS = [0.25, 0.354, 0.5, 0.707, 1.0, 1.414, 2.0, 2.83, 4.0]


def load(sset, arm, nm):
    return json.load(open(os.path.join(EV, sset, f'{arm}__{nm}.json')))['runs']


def col(runs, key):
    return np.array([r[key] for r in runs if r.get(key) is not None], float)


def boot_diff(a, b, n=10000, seed=12345):
    rng = np.random.default_rng(seed)
    d = a[rng.integers(0, len(a), (n, len(a)))].mean(1) - b[rng.integers(0, len(b), (n, len(b)))].mean(1)
    return a.mean() - b.mean(), np.quantile(d, 0.025), np.quantile(d, 0.975)


def line(*a):
    print(*a)


D = json.load(open(os.path.join(EV, 'decisions.json')))
line('=' * 100); line('DECISIONS (frozen evaluator)')
for k, v in D.items():
    line(f'{k}: {v["verdict"]}')

line('=' * 100); line('PRIMARY: mean (sd) and IDEA - DE intervals')
for nm in L.LANDSCAPES + L.HELDOUT:
    line(f'-- {nm} ({len(L.OPTIMA[nm])} optima, delta {L.optimum_radius(nm):.4f})')
    R = {arm: load('primary', arm, nm) for arm in ('DE', 'IDEA_R', 'IDEA_L')}
    for key in ('top_fit', 'best', 'optima', 'optima_any', 'basins', 'top_entropy', 'viable_frac', 'robust_0.2',
                'robust_0.05', 'inside_frac'):
        vals = {arm: col(R[arm], key) for arm in R}
        s = '  '.join(f'{arm} {v.mean():.3f} ({v.std():.3f})' for arm, v in vals.items())
        d1 = boot_diff(vals['IDEA_R'], vals['DE']); d2 = boot_diff(vals['IDEA_L'], vals['DE'])
        line(f'   {key:12s} {s}   R-DE {d1[0]:+.3f} [{d1[1]:+.3f}, {d1[2]:+.3f}]   L-DE {d2[0]:+.3f} [{d2[1]:+.3f}, {d2[2]:+.3f}]')
    for arm in ('IDEA_R', 'IDEA_L'):
        r = R[arm]
        line(f'   {arm}: final half-width (f.u.) {col(r, "final_rho").mean() * 4:.4f}; extinctions {col(r, "n_extinct").mean():.1f}; '
             f'exclusions {col(r, "n_excluded").mean():.1f}; speciations {col(r, "n_splits").mean():.1f}; births {col(r, "n_births").mean():.1f}; '
             f'total extinctions {col(r, "total_extinction").mean():.2f}; at floor after 3 updates (median) {np.median(col(r, "frac_at_min_3")):.2f}')
        un, hu = col(r, 'clade_union_nonviable'), col(r, 'clade_hull_nonviable')
        line(f'   {arm}: union non-viable {np.nanmean(un):.3f} (median {np.nanmedian(un):.3f}); hull non-viable {np.nanmean(hu):.3f} '
             f'(median {np.nanmedian(hu):.3f}); union area {np.nanmean(col(r, "clade_union_area")):.3f}; hull area {np.nanmean(col(r, "clade_hull_area")):.3f}')
    de = R['DE']
    line(f'   DE paper metrics: fitness (x0) {col(de, "paper_fitness").mean():.3f}; entropy {col(de, "paper_entropy").mean():.2f}')

line('=' * 100); line('H2 counts: runs keeping all optima / at least one')
for nm in ['himmelblau', 'ackley', 'rastrigin'] + L.HELDOUT:
    n_opt = len(L.OPTIMA[nm])
    s = []
    for arm in ('DE', 'IDEA_R', 'IDEA_L'):
        v = col(load('primary', arm, nm), 'optima')
        s.append(f'{arm}: all {int((v == n_opt).sum())}, >=1 {int((v >= 1).sum())}, mean {v.mean():.2f}')
    line(f'   {nm}: ' + ' | '.join(s))

line('=' * 100); line('ABLATIONS (paper landscapes, lethal): mean optima / top_fit / robust_0.2 / viable_frac')
arms = ['DE', 'DE_sm1', 'DE_N32', 'IDEA_R', 'R_noG1', 'R_noG2', 'R_noG3', 'R_nospec', 'R_abstheta', 'R_normK', 'R_fitbirth',
        'R_within', 'R_gauss', 'R_K128', 'IDEA_L']
for arm in arms:
    s = []
    for nm in L.LANDSCAPES:
        sset = 'primary' if arm in ('DE', 'IDEA_R', 'IDEA_L') else 'ablation'
        r = load(sset, arm, nm)
        s.append(f'{nm[:5]} {col(r, "optima").mean():.2f}/{col(r, "top_fit").mean():.3f}/{col(r, "robust_0.2").mean():.3f}/{col(r, "viable_frac").mean():.3f}')
    line(f'   {arm:11s} ' + '  '.join(s))
line('   optima, IDEA_R vs R_K128 and DE vs DE_N32 (intervals):')
for nm in ['himmelblau', 'ackley', 'rastrigin']:
    a = col(load('ablation', 'R_K128', nm), 'optima'); b = col(load('primary', 'IDEA_R', nm), 'optima')
    c = col(load('ablation', 'DE_N32', nm), 'optima'); d = col(load('primary', 'DE', nm), 'optima')
    x1 = boot_diff(a, b); x2 = boot_diff(a, d); x3 = boot_diff(c, d)
    line(f'   {nm}: K128 - R {x1[0]:+.2f} [{x1[1]:+.2f}, {x1[2]:+.2f}]; K128 - DE {x2[0]:+.2f} [{x2[1]:+.2f}, {x2[2]:+.2f}]; '
         f'DE_N32 - DE {x3[0]:+.2f} [{x3[1]:+.2f}, {x3[2]:+.2f}]')

line('=' * 100); line('EXPLOSION')
for arm in ('X_full', 'X_noG1', 'X_noG2', 'X_noG3', 'X_noall'):
    s = []
    for nm in L.LANDSCAPES:
        fr = col(load('explosion', arm, nm), 'final_rho')
        s.append(f'{nm[:5]} {int((fr >= 1).sum())}/{np.median(fr):.4f}/max {fr.max():.3f}')
    line(f'   {arm:8s} ' + '  '.join(s))

line('=' * 100); line('TWO-PEAK')
for pre in ('T_sel', 'T_full'):
    for m in MULTS:
        r = load('twopeak', f'{pre}_m{m}', 'two_peak')
        tr = np.array([x['med_rho_traj'] for x in r]) * 4
        line(f'   {pre} m={m:5.3f}: tall {col(r, "tall_kept").mean():.2f} broad {col(r, "broad_kept").mean():.2f} share_on_tall {col(r, "share_on_tall").mean():.2f} '
             f'speciations {col(r, "n_splits").mean():.1f} births {col(r, "n_births").mean():.1f} extinctions {col(r, "n_extinct").mean():.1f} '
             f'median half-width (f.u.) after updates 6/12/18/24: {np.median(tr[:, 5]):.3f}/{np.median(tr[:, 11]):.3f}/{np.median(tr[:, 17]):.3f}/{np.median(tr[:, 23]):.3f}')
# deterministic prediction of the radius trajectory (Prop 3c) for comparison
pairs = L.schedule_pairs(25)
grow = np.array([math.sqrt((1 - ap) / (1 - at)) + math.sqrt(2 / math.pi) * 0.1 * L.ddpm_sigma(at, ap) for at, ap in pairs])
cg = np.cumprod(grow)
line(f'   predicted half-width / rho_T after updates 6/12/18/24: {cg[5]:.3f}/{cg[11]:.3f}/{cg[17]:.3f}/{cg[23]:.3f}')
for arm in ('T_DE_vitro', 'V_DE', 'V_IDEA_R'):
    r = load('twopeak', arm, 'two_peak')
    line(f'   {arm}: tall {col(r, "tall_kept").mean():.2f} broad {col(r, "broad_kept").mean():.2f} top_fit {col(r, "top_fit").mean():.3f}')
line(f'   H4a: {D["H4a"]}')

line('=' * 100); line('CODED LANDSCAPES')
for nm in L.LANDSCAPES:
    for arm in ('DE', 'IDEA_R', 'IDEA_L'):
        r = load('coded', arm, nm)
        s = f'top_fit {col(r, "top_fit").mean():.3f} optima {col(r, "optima").mean():.2f} inside {col(r, "inside_frac").mean():.3f}'
        if arm != 'DE':
            co = col(r, 'centres_outside')
            s += f' centres_outside mean {co.mean():.3f} median {np.median(co):.3f} runs>=0.5 {int((co >= 0.5).sum())}'
        line(f'   {nm:10s} {arm:7s} {s}')

line('=' * 100); line('EXPLORATORY: which optima are kept (share of runs keeping each), from runs/')
for nm in ('himmelblau', 'ackley', 'rastrigin', 'vincent', 'sixhump'):
    O, dl = L.OPTIMA[nm], L.optimum_radius(nm)
    for arm in ('DE', 'IDEA_R'):
        A = np.load(os.path.join(RU, 'primary', f'{arm}__{nm}.npz'))
        X = A['x'] if arm == 'DE' else A['lives']
        Fv = A['fit'] if arm == 'DE' else A['lives_fit']
        kept = np.zeros(len(O))
        for i in range(X.shape[0]):
            Xf = X[i] * 4
            Xf = Xf[Fv[i] >= L.VIABLE]
            if len(Xf):
                d = np.sqrt(((Xf[:, None, :] - O[None]) ** 2).sum(-1)).min(0)
                kept += d <= dl
        kept /= X.shape[0]
        if nm == 'vincent':
            # columns by x-coordinate (original domain): narrow optima at small x
            xo = L._to_orig(O, L.SPEC_H['vincent'][1], L.SPEC_H['vincent'][2])
            cols = np.unique(np.round(xo[:, 0], 4))
            s = ' '.join(f'x={c:.3f}:{kept[np.isclose(xo[:, 0], c, atol=1e-3)].mean():.2f}' for c in cols)
            line(f'   {nm} {arm}: mean share kept per column of optima (by x, narrow -> broad): {s}')
        else:
            line(f'   {nm} {arm}: ' + ' '.join(f'({o[0]:+.2f},{o[1]:+.2f}):{k:.2f}' for o, k in zip(O, kept)))

line('=' * 100); line('EXPLORATORY: where the random-start two-peak runs end (from runs/)')
P = L.TWO_PEAK
for arm in ('V_DE', 'V_IDEA_R'):
    A = np.load(os.path.join(RU, 'twopeak', f'{arm}__two_peak.npz'))
    if arm == 'V_DE':
        X = A['x'] * 4
    else:
        X = A['centres'] * 4
    da = np.sqrt(((X - P['a']) ** 2).sum(-1)); db = np.sqrt(((X - P['b']) ** 2).sum(-1))
    line(f'   {arm}: mean share within w1 of the tall peak {np.mean(da <= P["w1"]):.3f}; within w2 of the broad peak {np.mean(db <= P["w2"]):.3f}; '
         f'runs with any within w2 of broad {np.mean((db <= P["w2"]).any(1)):.2f}; runs with any within w1 of tall {np.mean((da <= P["w1"]).any(1)):.2f}')
    if arm == 'V_IDEA_R':
        Fv = A['lives_fit']
        line(f'   {arm}: mean best output g {Fv.max(1).mean():.3f}; median distance of species centres to b {np.median(db):.3f}')
