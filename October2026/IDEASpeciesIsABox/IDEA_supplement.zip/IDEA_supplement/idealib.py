"""IDEA library: Diffusion Evolution (numpy port of the reference code) and the
Interval Diffusion Evolutionary Algorithm (species = axis-aligned boxes).

Coordinates. As in the reference benchmarks, the population lives in
"population coordinates" x (initialised N(0, I)); the landscape is evaluated at
4x ("function coordinates", the paper's box (-4, 4)^2).

Reference implementation read for the port: github.com/Zhangyanbo/diffusion-evolution
at commit 41ac6ca (diffevo/ddim.py, diffevo/generator.py,
experiments/benchmarks/methods/{diff_evo,benchmarks}.py, statistic.py) and
github.com/bhartl/foobench at commit 18de5da (foobench/{objective,foos}.py).
"""
import math
import numpy as np

SCALING = 4.0
D = 2

# ----------------------------------------------------------------------------
# Schedule (paper App. A.2, Eq. 16; code DDIMSchedulerCosine) and noise (Eq. 17)
# ----------------------------------------------------------------------------

def cosine_alphas(num_step=25):
    a = (np.cos(np.linspace(0.0, np.pi, num_step)) + 1.0) / 2.0
    return (a + 1e-3) * (1 - 1e-3) / (1 + 1e-3)


def schedule_pairs(num_step=25):
    """(alpha_t, alpha_{t-1}) in the order the reference scheduler yields them."""
    a = cosine_alphas(num_step)
    return [(float(a[t]), float(a[t - 1])) for t in range(num_step - 1, 0, -1)]


def ddpm_sigma(at, ap):
    """Eq. 17 with sigma_m = 1 (reference: ddim.ddpm_sigma)."""
    return math.sqrt((1 - ap) / (1 - at) * (1 - at / ap))


def neighbourhood_radius(at):
    """Paper App. A.3: r_t = sqrt((1 - alpha_t) / alpha_t)."""
    return math.sqrt((1 - at) / at)


# ----------------------------------------------------------------------------
# Landscapes (paper Table 2; foobench definitions; Eq. 19 fitness map as coded
# in benchmarks.energy_wrapper with the code's targets and scales, T = 1)
# ----------------------------------------------------------------------------

def _rosenbrock(X):
    return (1 - X[:, 0]) ** 2 + 100 * (X[:, 1] - X[:, 0] ** 2) ** 2


def _beale(X):
    x, y = X[:, 0], X[:, 1]
    return (1.5 - x + x * y) ** 2 + (2.25 - x + x * y ** 2) ** 2 + (2.625 - x + x * y ** 3) ** 2


def _himmelblau(X):
    x, y = X[:, 0], X[:, 1]
    return (x ** 2 + y - 11) ** 2 + (x + y ** 2 - 7) ** 2


def _ackley(X):
    x, y = X[:, 0], X[:, 1]
    return (-20 * np.exp(-0.2 * np.sqrt(0.5 * (x ** 2 + y ** 2)))
            - np.exp(0.5 * (np.cos(2 * np.pi * x) + np.cos(2 * np.pi * y))) + 20 + np.e)


def _rastrigin(X, A=10.0):
    return A * X.shape[1] + (X ** 2 - A * np.cos(2 * np.pi * X)).sum(axis=1)


# name: (foo, maximize, limit_val, target, scale, max_distance)
SPEC = {
    'rosenbrock': (_rosenbrock, False, 100.0, 0.0, 287.51, 40009.0),
    'beale': (_beale, False, 100.0, 0.0, 20.0, 72769.2),
    'himmelblau': (_himmelblau, False, 100.0, 0.0, 17.01, 308.803),
    'ackley': (_ackley, True, 1e-9, -12.5401, 2.0, 12.5401),
    'rastrigin': (_rastrigin, True, 1e-9, -64.6249, 30.0, 64.6249),
}
LANDSCAPES = ['rosenbrock', 'beale', 'himmelblau', 'ackley', 'rastrigin']

# Global optima in function coordinates (Ackley and Rastrigin are maximised,
# paper App. A.4; maximisers located numerically, scratch/optima.py).
OPTIMA = {
    'rosenbrock': np.array([[1.0, 1.0]]),
    'beale': np.array([[3.0, 0.5]]),
    'himmelblau': np.array([[3.0, 2.0], [-2.805118, 3.131312],
                            [-3.779310, -3.283186], [3.584428, -1.848126]]),
    'ackley': 3.61404944 * np.array([[1, 1], [1, -1], [-1, 1], [-1, -1]], float),
    'rastrigin': 3.51785914 * np.array([[1, 1], [1, -1], [-1, 1], [-1, -1]], float),
}


def objective(name, Xf):
    """foobench Objective.__call__: negate if maximise, then limits (|x| > 4 in
    any coordinate -> limit_val; foobench applies them unconditionally)."""
    foo, maximize, limit_val, _, _, _ = SPEC[name]
    Xf = np.asarray(Xf, dtype=float)
    f = foo(Xf)
    if maximize:
        f = -f
    out = ((Xf < -4.0) | (Xf > 4.0)).any(axis=1)
    return np.where(out, limit_val, f)


def g_map(name, Xf, T=1.0, outside='coded'):
    """Eq. 19 as coded (energy_wrapper). Clipped at 0: in float64 the
    out-of-box value 1e-9 gives -1e-10 where the float32 reference gives 0.
    outside='coded': foobench's limit values outside the box (Rosenbrock 0.706,
    Beale 0.0067, Himmelblau 0.0028, Ackley and Rastrigin 0);
    outside='lethal': fitness 0 outside the box for every landscape."""
    _, _, _, target, scale, maxd = SPEC[name]
    Xf = np.asarray(Xf, dtype=float)
    f = objective(name, Xf)
    pmin = math.exp(-maxd / (T * scale))
    p = np.exp(-np.abs(f - target) / (T * scale))
    gv = np.maximum((p - pmin) / (1.0 - pmin), 0.0)
    if outside == 'lethal':
        gv = np.where(((Xf < -4.0) | (Xf > 4.0)).any(axis=1), 0.0, gv)
    elif outside != 'coded':
        raise ValueError(outside)
    return gv


# Two-peak landscape for the viability test (function coordinates; zero outside
# the box like Ackley and Rastrigin).
TWO_PEAK = dict(a=np.array([2.0, 2.0]), b=np.array([-2.0, -2.0]),
                h1=1.0, w1=0.4, h2=0.7, w2=1.2)


def g_two_peak(Xf, P=TWO_PEAK):
    Xf = np.asarray(Xf, dtype=float)
    d1 = ((Xf - P['a']) ** 2).sum(1)
    d2 = ((Xf - P['b']) ** 2).sum(1)
    v = np.maximum(P['h1'] * np.exp(-d1 / (2 * P['w1'] ** 2)),
                   P['h2'] * np.exp(-d2 / (2 * P['w2'] ** 2)))
    out = ((Xf < -4.0) | (Xf > 4.0)).any(axis=1)
    return np.where(out, 0.0, v)


# Held-out landscapes: CEC 2013 niching benchmarks F5 (six-hump camel back), F6 (Shubert) and
# F7 (Vincent) in 2-D, mapped affinely onto the function box (-4, 4)^2, with Eq. 19's form
# (target f*, D = |f - f*|, D_max over the box) and the scale s calibrated so that 10% of the box
# has g >= 0.5 (pilots/heldout_calib.py; the paper's landscapes: 7.9%-18.2%, median 9.4%).
# Fitness 0 outside the box. None of these was run before the protocol was frozen.

def _camel(X):
    x, y = X[:, 0], X[:, 1]
    return (4 - 2.1 * x ** 2 + x ** 4 / 3) * x ** 2 + x * y + (-4 + 4 * y ** 2) * y ** 2


def _shubert(X):
    j = np.arange(1, 6)
    s = (j[None, None, :] * np.cos((j[None, None, :] + 1) * X[:, :, None] + j[None, None, :])).sum(-1)
    return s.prod(1)


def _vincent(X):
    return -np.sin(10 * np.log(X)).mean(1)


# name: (f to minimise, lo, hi, f*, D_max, s)
SPEC_H = {
    'sixhump': (_camel, np.array([-1.9, -1.1]), np.array([1.9, 1.1]), -1.031628453489877, 6.892579, 0.961627),
    'shubert': (_shubert, np.array([-10.0, -10.0]), np.array([10.0, 10.0]), -186.7309088310239, 397.212689, 587.332923),
    'vincent': (_vincent, np.array([0.25, 0.25]), np.array([10.0, 10.0]), -1.0, 1.999993, 0.392267),
}
HELDOUT = ['sixhump', 'shubert', 'vincent']


def _to_orig(U, lo, hi):
    return lo + (np.asarray(U, float) + 4.0) / 8.0 * (hi - lo)


def _to_u(X, lo, hi):
    return (np.asarray(X, float) - lo) / (hi - lo) * 8.0 - 4.0


def g_heldout(name, Xf):
    f, lo, hi, fstar, dmax, s = SPEC_H[name]
    Xf = np.asarray(Xf, dtype=float)
    out = ((Xf < -4.0) | (Xf > 4.0)).any(axis=1)
    Xo = _to_orig(np.clip(Xf, -4.0, 4.0), lo, hi)
    pmin = math.exp(-dmax / s)
    gv = np.maximum((np.exp(-np.abs(f(Xo) - fstar) / s) - pmin) / (1.0 - pmin), 0.0)
    return np.where(out, 0.0, gv)


_vx = np.array([math.exp((math.pi / 2 + 2 * math.pi * k) / 10) for k in range(-2, 4)])
_sh_max = np.array([-7.08350641, -0.8003211, 5.48286421])
_sh_min = np.array([-7.70831374, -1.42512843, 4.85805688])
_OPT_H_ORIG = {
    'sixhump': np.array([[0.08984201, -0.71265640], [-0.08984201, 0.71265640]]),
    'shubert': np.array([[a, b] for a in _sh_max for b in _sh_min] + [[b, a] for a in _sh_max for b in _sh_min]),
    'vincent': np.array([[a, b] for a in _vx for b in _vx]),
}
for _nm in HELDOUT:
    OPTIMA[_nm] = _to_u(_OPT_H_ORIG[_nm], SPEC_H[_nm][1], SPEC_H[_nm][2])
OPTIMA['two_peak'] = np.array([TWO_PEAK['a'], TWO_PEAK['b']])


def optimum_radius(name):
    """delta_L = min(0.25, half the smallest distance between two global optima), function coords."""
    O = OPTIMA[name]
    if len(O) < 2:
        return 0.25
    d = np.sqrt(((O[:, None, :] - O[None, :, :]) ** 2).sum(-1))
    np.fill_diagonal(d, np.inf)
    return float(min(0.25, d.min() / 2))


def make_g(name, outside='lethal'):
    if name == 'two_peak':
        return g_two_peak
    if name in SPEC_H:
        return lambda Xf: g_heldout(name, Xf)
    return lambda Xf: g_map(name, Xf, outside=outside)


# ----------------------------------------------------------------------------
# Diffusion Evolution: numpy port of BayesianGenerator + ddim_step +
# methods/diff_evo.experiment (density='uniform', noise=sigma_m)
# ----------------------------------------------------------------------------

def de_estimate(x, fit, at):
    """generator.BayesianEstimator._estimate for all x_t at once."""
    N = x.shape[0]
    mu = x * math.sqrt(at)
    d2 = ((x[:, None, :] - mu[None, :, :]) ** 2).sum(-1)
    p_diff = np.exp(-d2 / (2.0 * (1.0 - at)))
    p_xt = 1.0 / N
    prob = (fit[None, :] + 1e-9) * (p_diff + 1e-9) / (p_xt + 1e-9)
    z = prob.sum(1)
    return (prob @ x) / (z + 1e-9)[:, None]


def ddim_step(xt, x0, at, ap, sigma_m, rng):
    sigma = ddpm_sigma(at, ap) * sigma_m
    eps = (xt - math.sqrt(at) * x0) / math.sqrt(1.0 - at)
    return (math.sqrt(ap) * x0 + math.sqrt(max(1.0 - ap - sigma ** 2, 0.0)) * eps
            + sigma * rng.standard_normal(x0.shape))


def de_run(g_fn, rng, N=512, num_step=25, sigma_m=0.1, x_init=None, trace=False):
    """Returns dict with final population x (population coords), its fitness,
    the last x0 estimate and its fitness (the reference's x0_fitness[-1])."""
    x = rng.standard_normal((N, D)) if x_init is None else np.array(x_init, float)
    tr = []
    n_eval = 0
    x0 = None
    for at, ap in schedule_pairs(num_step):
        fit = g_fn(x * SCALING)
        n_eval += x.shape[0]
        x0 = de_estimate(x, fit, at)
        x = ddim_step(x, x0, at, ap, sigma_m, rng)
        if trace:
            tr.append(x.copy())
    fit = g_fn(x * SCALING)
    n_eval += x.shape[0]
    out = dict(x=x, fit=fit, x0=x0, x0_fit=g_fn(x0 * SCALING), n_eval=n_eval)
    if trace:
        out['trace'] = np.stack(tr)
    return out


# ----------------------------------------------------------------------------
# IDEA: species = boxes [c - rho, c + rho]
# ----------------------------------------------------------------------------

def quantile_k(G, q):
    """Empirical q-quantile as the k-th smallest value, k = max(1, ceil(q n))."""
    n = G.shape[-1]
    k = max(1, int(math.ceil(q * n - 1e-12)))
    return np.partition(G, k - 1, axis=-1)[..., k - 1]


def box_gap(C, R):
    """Euclidean distance between boxes i and j (0 if they touch or overlap)."""
    sep = np.abs(C[:, None, :] - C[None, :, :]) - (R[:, None, :] + R[None, :, :])
    return np.sqrt((np.maximum(sep, 0.0) ** 2).sum(-1))


OVERLAP_TOL = 1e-12   # penetration below this is rounding from (lo + hi) / 2, (hi - lo) / 2


def boxes_overlap(ci, ri, cj, rj, tol=OVERLAP_TOL):
    """Positive-volume overlap: penetration depth above tol in every coordinate."""
    return bool(np.all((ri + rj) - np.abs(ci - cj) > tol))


class Species:
    __slots__ = ('c', 'r', 'F', 'lx', 'lg')

    def __init__(self, c, r, F=0.0, lx=None, lg=None):
        self.c = np.array(c, float)
        self.r = np.array(r, float)
        self.F = float(F)
        self.lx = lx      # lives (population coords) inside the box, or None
        self.lg = lg      # their fitness


def _restrict(sp, q, F_parent):
    """Keep the lives inside sp's box; F from them (parent's F if none)."""
    if sp.lx is not None and len(sp.lx):
        inside = np.all(np.abs(sp.lx - sp.c) <= sp.r + 1e-15, axis=1)
        sp.lx, sp.lg = sp.lx[inside], sp.lg[inside]
    if sp.lx is not None and len(sp.lx):
        sp.F = float(quantile_k(sp.lg[None, :], q)[0])
    else:
        sp.F = float(F_parent)
    return sp


def _split(sp, d, s, q):
    lo, hi = sp.c - sp.r, sp.c + sp.r
    lo1, hi1 = lo.copy(), hi.copy(); hi1[d] = s
    lo2, hi2 = lo.copy(), hi.copy(); lo2[d] = s
    kids = []
    for a, b in ((lo1, hi1), (lo2, hi2)):
        kids.append(_restrict(Species((a + b) / 2, (b - a) / 2, sp.F, sp.lx, sp.lg), q, sp.F))
    return kids


def compete_boxes(S, rmin, q):
    """Exclusion. Species are visited in order of decreasing F (ties by index). A box that overlaps
    an already kept (fitter) box loses: its face on the axis of least penetration is clipped to the
    winner's face. A loser whose clipped half-width would fall below rho_min is excluded (dies).
    Lives outside the clipped box are dropped and F is recomputed from the rest."""
    order = sorted(range(len(S)), key=lambda i: -S[i].F)
    kept, n_exc = [], 0
    for i in order:
        s = S[i]
        dead = False
        for w in kept:
            if boxes_overlap(s.c, s.r, w.c, w.r):
                ov = (s.r + w.r) - np.abs(s.c - w.c)
                d = int(np.argmin(ov))
                lo, hi = s.c - s.r, s.c + s.r
                if s.c[d] < w.c[d]:
                    hi[d] = min(hi[d], w.c[d] - w.r[d])
                else:
                    lo[d] = max(lo[d], w.c[d] + w.r[d])
                if (hi[d] - lo[d]) / 2 < rmin:
                    dead = True
                    break
                s.c, s.r = (lo + hi) / 2, (hi - lo) / 2
        if dead:
            n_exc += 1
            continue
        if s.lx is not None:
            _restrict(s, q, s.F)
        kept.append(s)
    return kept, n_exc


DEFAULTS = dict(K=32, n=16, q=0.1, theta=0.5, rho_min=0.0125, rho_max=1.0,
                num_step=25, sigma_m=0.1, radius_rule='repaired', rhohat='mean',
                compete=True, extinct=True, speciate=True, within=False,
                valley=0.5, init_centres=None, rho_init=None, birth='uniform',
                theta_mode='relative', fallback='best', rho_noise='half',
                kernel_norm=False, move_centres=True)


def idea_run(g_fn, rng, record=False, **kw):
    """One IDEA run. Options (see DEFAULTS):
    radius_rule: 'literal'  rho' = sqrt(alpha_{t-1}) rho_hat + sigma rho_hat xi   (sketch as written)
                 'repaired' rho' = sqrt((1-alpha_{t-1})/(1-alpha_t)) rho_hat + ...  (tracks the noise scale)
                 'none'     rho' = rho_hat + ...                                     (governor 1 removed)
    rhohat:      'mean'   Q.K-weighted mean of neighbours' radii
                 'moment' radius of the uniform box with the variance of the weighted mixture of
                          neighbour boxes (union-style growth)
    compete:     exclusion by clipping the losing face (governor 2)
    extinct:     extinction when F < theta_t (governor 3); theta_mode 'absolute': theta_t = theta * alpha_t,
                 'relative': theta_t = theta * alpha_t * max_k F_k; fallback when every species
                 fails: 'best' keeps the best one, 'suspend' keeps all
    within:      numerator of c_hat uses each species' fitness-weighted life mean (within-species selection)
    birth:       'uniform' (a uniformly chosen living box splits) or 'fitness' (chosen in proportion to Q)
    rho_noise:   'half'  radius mutation sigma_t rho_hat |xi| (inflates only, as the sketch says)
                 'gauss' radius mutation sigma_t rho_hat xi   (symmetric)
    kernel_norm: False   kernel exp(-|c_i - sqrt(a) c_j|^2 / 2 var_ij), unnormalised as in the reference
                         code's gaussian_prob
                 True    normalised density: extra factor prod_d (rho_id + rho_jd)^-1
    move_centres: False freezes the centres (no recombination, drift or mutation of centres): only the
                 species-level selection (extinction, exclusion, speciation, fission) and the radius
                 dynamics act -- the selection-only tournament of H4a
    rho_max may be np.inf (no wrapping bound).
    """
    o = dict(DEFAULTS); o.update(kw)
    K, n, q, theta = o['K'], o['n'], o['q'], o['theta']
    rmin, rmax, sm = o['rho_min'], o['rho_max'], o['sigma_m']
    alphas = cosine_alphas(o['num_step'])
    pairs = schedule_pairs(o['num_step'])
    rho_T = o['rho_init'] if o['rho_init'] is not None else \
        rmin * math.sqrt((1 - alphas[-1]) / (1 - alphas[0]))
    rho_T = min(max(rho_T, rmin), rmax)
    C0 = rng.standard_normal((K, D)) if o['init_centres'] is None else np.array(o['init_centres'], float)
    S = [Species(c, np.full(D, rho_T)) for c in C0]
    n_eval = 0
    log = dict(n_species=[], frac_at_min=[], med_rho=[], extinct=[], excluded=[],
               splits=[], births=[], total_extinction=0, mean_F=[]) if record else None

    def evaluate(S):
        nonlocal n_eval
        Cc = np.array([s.c for s in S]); Rr = np.array([s.r for s in S])
        U = rng.uniform(-1.0, 1.0, (len(S), n, D))
        X = Cc[:, None, :] + Rr[:, None, :] * U
        Gv = g_fn((X * SCALING).reshape(-1, D)).reshape(len(S), n)
        n_eval += len(S) * n
        F = quantile_k(Gv, q)
        for i, s in enumerate(S):
            s.lx, s.lg, s.F = X[i], Gv[i], float(F[i])
        return X, Gv

    for step, (at, ap) in enumerate(pairs):
        evaluate(S)
        # (b) extinction
        n_ext = 0
        if o['extinct']:
            if o['theta_mode'] == 'absolute':
                th = theta * at
            elif o['theta_mode'] == 'relative':
                th = theta * at * max(s.F for s in S)
            else:
                raise ValueError(o['theta_mode'])
            alive = [s for s in S if s.F >= th]
            n_ext = len(S) - len(alive)
            if not alive:
                if record:
                    log['total_extinction'] += 1
                if o['fallback'] == 'best':
                    alive = [max(S, key=lambda s: s.F)]
                else:            # 'suspend': nobody is viable, nobody dies
                    alive = list(S)
                    n_ext = 0
            S = alive
        # (c) competition: clip the losing face along the axis of least overlap
        n_exc = 0
        if o['compete'] and len(S) > 1:
            S, n_exc = compete_boxes(S, rmin, q)
        # (d) speciation along the widest valley of the elite lives
        n_split = 0
        if o['speciate']:
            S2 = []
            for s in S:
                done = False
                if s.lx is not None and len(s.lx) >= 4:
                    elite = s.lx[s.lg >= np.median(s.lg)]
                    if len(elite) >= 2:
                        best = (0.0, None, None)
                        for d in range(D):
                            v = np.sort(elite[:, d])
                            gaps = np.diff(v)
                            j = int(np.argmax(gaps))
                            nu = gaps[j] / (2 * s.r[d])
                            if nu > best[0]:
                                best = (nu, d, 0.5 * (v[j] + v[j + 1]))
                        nu, d, cut = best
                        if d is not None and nu > o['valley']:
                            lo, hi = s.c[d] - s.r[d], s.c[d] + s.r[d]
                            if (cut - lo) / 2 >= rmin and (hi - cut) / 2 >= rmin:
                                S2.extend(_split(s, d, cut, q))
                                n_split += 1
                                done = True
                if not done:
                    S2.append(s)
            S = S2
        # (e) cap and refill by fission of living boxes (parent uniform, or in proportion to Q)
        if len(S) > K:
            S = sorted(S, key=lambda s: -s.F)[:K]
        n_birth = 0
        while len(S) < K:
            if o['birth'] == 'uniform':
                i = int(rng.integers(len(S)))
            else:   # 'fitness': parent chosen in proportion to Q = F
                Fv = np.array([s.F for s in S])
                p = Fv / Fv.sum() if Fv.sum() > 0 else np.full(len(S), 1.0 / len(S))
                i = int(rng.choice(len(S), p=p))
            par = S.pop(i)
            d = int(np.argmax(par.r))
            kids = _split(par, d, par.c[d], q)
            for kd in kids:
                if kd.r[d] < rmin:   # too narrow to halve: children keep the floor width
                    kd.r[d] = rmin
            S.extend(kids)
            n_birth += 1
        # (f) denoise centres and radii with the gated kernel
        Cc = np.array([s.c for s in S]); Rr = np.array([s.r for s in S])
        Q = np.array([s.F for s in S])
        sa = math.sqrt(at)
        var = (1 - at) * (Rr[:, None, :] + Rr[None, :, :]) ** 2
        logK = -(((Cc[:, None, :] - sa * Cc[None, :, :]) ** 2) / (2 * var)).sum(-1)
        if o['kernel_norm']:
            logK = logK - np.log(Rr[:, None, :] + Rr[None, :, :]).sum(-1)
        flow = box_gap(Cc, Rr) < neighbourhood_radius(at)
        with np.errstate(divide='ignore'):
            logW = np.log(Q)[None, :] + logK
        logW = np.where(flow, logW, -np.inf)
        rowmax = logW.max(axis=1)
        ok = np.isfinite(rowmax)
        Wt = np.zeros_like(logW)
        Wt[ok] = np.exp(logW[ok] - rowmax[ok, None])
        Wt[~ok] = np.eye(len(S))[~ok]                 # no weight anywhere: self only
        Wt /= Wt.sum(axis=1, keepdims=True)
        if o['within']:
            M = np.array([(s.lg @ s.lx) / s.lg.sum() if (s.lx is not None and len(s.lx) and s.lg.sum() > 0)
                          else s.c for s in S])
        else:
            M = Cc
        c_hat = Wt @ M
        if o['rhohat'] == 'mean':
            r_hat = Wt @ Rr
        else:
            dev = (Cc[None, :, :] - c_hat[:, None, :]) ** 2 + (Rr[None, :, :] ** 2) / 3.0
            r_hat = np.sqrt(3.0 * np.einsum('ij,ijd->id', Wt, dev))
        sig = ddpm_sigma(at, ap) * sm
        Cn = ddim_step(Cc, c_hat, at, ap, sm, rng) if o['move_centres'] else Cc.copy()
        if o['radius_rule'] == 'literal':
            st = math.sqrt(ap)
        elif o['radius_rule'] == 'repaired':
            st = math.sqrt((1 - ap) / (1 - at))
        elif o['radius_rule'] == 'none':
            st = 1.0
        else:
            raise ValueError(o['radius_rule'])
        xi = rng.standard_normal(r_hat.shape)
        if o['rho_noise'] == 'half':
            xi = np.abs(xi)
        elif o['rho_noise'] != 'gauss':
            raise ValueError(o['rho_noise'])
        Rn = np.clip(st * r_hat + sig * r_hat * xi, rmin, rmax)
        for i, s in enumerate(S):
            s.c, s.r = Cn[i], Rn[i]
        if record:
            log['n_species'].append(len(S)); log['extinct'].append(n_ext); log['excluded'].append(n_exc)
            log['splits'].append(n_split); log['births'].append(n_birth)
            log['frac_at_min'].append(float(np.mean(np.all(Rn <= rmin * (1 + 1e-9), axis=1))))
            log['med_rho'].append(float(np.median(np.sqrt(np.prod(Rn, axis=1)))))
            log['mean_F'].append(float(Q.mean()))
    X, Gv = evaluate(S)
    out = dict(lives=X.reshape(-1, D), lives_fit=Gv.reshape(-1),
               centres=np.array([s.c for s in S]), radii=np.array([s.r for s in S]),
               F=np.array([s.F for s in S]), n_eval=n_eval)
    if record:
        out['log'] = log
    return out


# ----------------------------------------------------------------------------
# Metrics
# ----------------------------------------------------------------------------

def top_k_idx(fit, k=64):
    return np.argsort(-fit, kind='stable')[:k]


def entropy_bits(Xf, scale=10):
    """statistic.entropy: cells round(10 x) in function coordinates."""
    cells = np.round(np.asarray(Xf) * scale).astype(np.int64)
    _, cnt = np.unique(cells, axis=0, return_counts=True)
    p = cnt / cnt.sum()
    return float(-(p * np.log2(p)).sum())


class BasinMap:
    """Steepest-ascent basin labels of g on a grid over [-4, 4]^2 (function coords)."""

    def __init__(self, g_fn, h=0.01):
        s = np.arange(-4.0, 4.0 + h / 2, h)
        self.s, self.h, self.m = s, h, len(s)
        G = np.stack(np.meshgrid(s, s, indexing='ij'), -1).reshape(-1, 2)
        V = g_fn(G).reshape(self.m, self.m)
        self.V = V
        m = self.m
        best = np.arange(m * m).reshape(m, m)
        bestv = V.copy()
        P = np.pad(V, 1, constant_values=-np.inf)
        idx = np.arange(m * m).reshape(m, m)
        Pi = np.pad(idx, 1, constant_values=-1)
        for di in (-1, 0, 1):
            for dj in (-1, 0, 1):
                if di == 0 and dj == 0:
                    continue
                nv = P[1 + di:1 + di + m, 1 + dj:1 + dj + m]
                ni = Pi[1 + di:1 + di + m, 1 + dj:1 + dj + m]
                upd = nv > bestv
                bestv = np.where(upd, nv, bestv)
                best = np.where(upd, ni, best)
        ptr = best.reshape(-1)
        for _ in range(64):
            nxt = ptr[ptr]
            if np.array_equal(nxt, ptr):
                break
            ptr = nxt
        self.label = ptr.reshape(m, m)

    def labels(self, Xf):
        Xf = np.asarray(Xf, float)
        out = ((Xf < -4.0) | (Xf > 4.0)).any(axis=1)
        ij = np.clip(np.rint((Xf + 4.0) / self.h).astype(int), 0, self.m - 1)
        lab = self.label[ij[:, 0], ij[:, 1]]
        return np.where(out, -1, lab)   # -1 = outside the box


def optima_covered(Xf, optima, delta=0.25, fit=None, theta=None):
    """Number of optima with an output point within delta (function coords); with fit and theta,
    only points of fitness >= theta count (a viable point near the optimum)."""
    Xf = np.asarray(Xf, float)
    if fit is not None and theta is not None:
        Xf = Xf[np.asarray(fit) >= theta]
    if len(Xf) == 0:
        return 0
    d = np.sqrt(((Xf[:, None, :] - optima[None, :, :]) ** 2).sum(-1))
    return int((d.min(axis=0) <= delta).sum())


VIABLE = 0.5   # an output point is viable if g >= 0.5 (the half-fitness level)


def output_metrics(Xf, fit, basin, name, k=64):
    """Metrics of an output set (DE: final population; IDEA: final lives), function coords."""
    optima, delta = OPTIMA[name], optimum_radius(name)
    idx = top_k_idx(fit, k)
    viable = fit >= VIABLE
    labs = basin.labels(Xf[viable]) if viable.any() else np.array([], int)
    return dict(top_fit=float(fit[idx].mean()),
                top_entropy=entropy_bits(Xf[idx]),
                basins=int(len(np.unique(labs))),
                optima=optima_covered(Xf, optima, delta, fit, VIABLE),
                optima_any=optima_covered(Xf, optima, delta),
                optima_top=optima_covered(Xf[idx], optima, delta),
                viable_frac=float(viable.mean()),
                best=float(fit.max()),
                inside_frac=float(np.all(np.abs(Xf) <= 4.0, axis=1).mean()))


def robust_fitness(g_fn, Xf, rho_f, q=0.1, m=256, rng=None):
    """Exact-in-expectation q-quantile of g over the box of half-width rho_f (function coords)
    around each point, from m uniform samples per point (used to score robustness of outputs)."""
    rng = np.random.default_rng(0) if rng is None else rng
    Xf = np.asarray(Xf, float)
    U = rng.uniform(-1.0, 1.0, (len(Xf), m, D))
    G = g_fn((Xf[:, None, :] + rho_f * U).reshape(-1, D)).reshape(len(Xf), m)
    return np.quantile(G, q, axis=1)


def clade_metrics(g_fn, centres, radii, theta_v, n_mc=200000, rng=None):
    """Union C of the final boxes vs its bounding hull (function coords): volume share of points
    with g < theta_v (non-viable) in each, by Monte Carlo over the hull."""
    rng = np.random.default_rng(0) if rng is None else rng
    Cf, Rf = np.asarray(centres) * SCALING, np.asarray(radii) * SCALING
    lo, hi = (Cf - Rf).min(0), (Cf + Rf).max(0)
    X = lo + (hi - lo) * rng.uniform(0.0, 1.0, (n_mc, D))
    inU = np.zeros(n_mc, bool)
    for c, r in zip(Cf, Rf):
        inU |= np.all(np.abs(X - c) <= r, axis=1)
    bad = g_fn(X) < theta_v
    hull_area = float(np.prod(hi - lo))
    return dict(union_area=hull_area * inU.mean(), hull_area=hull_area,
                union_nonviable=float(bad[inU].mean()) if inU.any() else float('nan'),
                hull_nonviable=float(bad.mean()))
