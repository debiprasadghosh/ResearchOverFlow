"""Calibrate the held-out landscapes (CEC 2013 niching F5, F6, F7 in 2-D), mapped onto the
paper's function box (-4, 4)^2, with Eq. 19's form and a scale s chosen so that 10% of the box
has g >= 0.5 (the paper's five landscapes range from 7.9% to 18.2%, median 9.4%).
Also locates the global optima. Written before any held-out run."""
import math, numpy as np
from scipy.optimize import brentq, minimize

def to_orig(U, lo, hi):
    return lo + (np.asarray(U, float) + 4.0) / 8.0 * (hi - lo)

def to_u(X, lo, hi):
    return (np.asarray(X, float) - lo) / (hi - lo) * 8.0 - 4.0

def camel(X):
    x, y = X[:, 0], X[:, 1]
    return (4 - 2.1 * x ** 2 + x ** 4 / 3) * x ** 2 + x * y + (-4 + 4 * y ** 2) * y ** 2

def shubert(X):
    j = np.arange(1, 6)
    s = (j[None, None, :] * np.cos((j[None, None, :] + 1) * X[:, :, None] + j[None, None, :])).sum(-1)
    return s.prod(1)

def vincent(X):
    return -np.sin(10 * np.log(X)).mean(1)

H = {  # name: (f to minimise, lo, hi, f*)
    'sixhump': (camel, np.array([-1.9, -1.1]), np.array([1.9, 1.1]), -1.031628453489877),
    'shubert': (shubert, np.array([-10.0, -10.0]), np.array([10.0, 10.0]), -186.7309088310239),
    'vincent': (vincent, np.array([0.25, 0.25]), np.array([10.0, 10.0]), -1.0),
}
s1 = np.linspace(-4, 4, 1601)
G = np.stack(np.meshgrid(s1, s1, indexing='ij'), -1).reshape(-1, 2)
for name, (f, lo, hi, fstar) in H.items():
    F = f(to_orig(G, lo, hi))
    print(name, 'grid min', F.min(), 'f*', fstar)
    dmax = float(np.abs(F - fstar).max())
    def frac(s):
        pmin = math.exp(-dmax / s)
        g = (np.exp(-np.abs(F - fstar) / s) - pmin) / (1 - pmin)
        return (g >= 0.5).mean()
    s = brentq(lambda s: frac(s) - 0.10, 1e-6 * dmax, 10 * dmax, xtol=1e-12)
    print(f"   D_max = {dmax:.6f}  s = {s:.6f}  frac(g>=0.5) = {frac(s):.4f}")
    # optima
    if name == 'sixhump':
        O = np.array([[0.08984201, -0.71265640], [-0.08984201, 0.71265640]])
    elif name == 'vincent':
        xs = np.array([math.exp((math.pi / 2 + 2 * math.pi * k) / 10) for k in range(-2, 4)])
        xs = xs[(xs >= 0.25) & (xs <= 10)]
        O = np.array([[a, b] for a in xs for b in xs])
    else:
        # 1-D factor s(x); global min of s(x)s(y) = smax * smin at (argmax, argmin) and (argmin, argmax)
        j = np.arange(1, 6)
        sx = lambda x: (j * np.cos((j + 1) * x + j)).sum()
        xx = np.linspace(-10, 10, 200001)
        sv = (j[None, :] * np.cos((j[None, :] + 1) * xx[:, None] + j[None, :])).sum(1)
        mx, mn = [], []
        for arr, sign in ((mx, -1), (mn, 1)):
            idx = np.where((sign * sv[1:-1] < sign * sv[:-2]) & (sign * sv[1:-1] < sign * sv[2:]))[0] + 1
            target = sv.max() if sign == -1 else sv.min()
            for i in idx:
                if abs(sv[i] - target) < 1e-3 * abs(target):
                    r = minimize(lambda z: sign * sx(z[0]), [xx[i]], method='Nelder-Mead', options=dict(xatol=1e-12, fatol=1e-14))
                    arr.append(r.x[0])
        O = np.array([[a, b] for a in mx for b in mn] + [[b, a] for a in mx for b in mn])
        print('   1-D maxima', np.round(mx, 6), 'minima', np.round(mn, 6))
    fo = f(O)
    print(f"   {len(O)} optima, f range [{fo.min():.6f}, {fo.max():.6f}]")
    Ou = to_u(O, lo, hi)
    dd = np.sqrt(((Ou[:, None] - Ou[None]) ** 2).sum(-1)); np.fill_diagonal(dd, np.inf)
    print(f"   min pairwise distance (function coords) {dd.min():.4f} -> delta = {min(0.25, dd.min() / 2):.4f}")
    np.set_printoptions(precision=8, suppress=True, linewidth=200)
    print('   optima (orig coords):'); print(repr(O))
