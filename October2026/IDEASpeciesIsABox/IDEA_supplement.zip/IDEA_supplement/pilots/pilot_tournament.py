"""Tournament pilot: selection-only (centres frozen) vs full dynamics, seeded 16 + 16 on the two peaks.
Seeds 8000-8019. Two-peak landscape only."""
import sys, time, numpy as np
sys.path.insert(0, '/home/claude/idea')
import idealib as L
P = L.TWO_PEAK; g = L.make_g('two_peak'); crit = 0.5908
a, b = P['a'], P['b']
init = np.vstack([np.tile(a / 4, (16, 1)), np.tile(b / 4, (16, 1))])
for mode, kw in [('selection-only', dict(move_centres=False)), ('full dynamics', {})]:
    print(mode)
    for mult in (0.25, 0.354, 0.5, 0.707, 1.0, 1.414, 2.0, 2.83, 4.0):
        rT = mult * crit / 4
        kt, kb, nt = [], [], []
        for s in range(8000, 8020):
            o = L.idea_run(g, np.random.default_rng(s), init_centres=init, rho_init=rT, **kw)
            Xf, f = o['lives'] * 4, o['lives_fit']
            kt.append(L.optima_covered(Xf, a[None], 0.25, f, 0.5)); kb.append(L.optima_covered(Xf, b[None], 0.25, f, 0.5))
            C = o['centres'] * 4
            nt.append(np.mean(np.sqrt(((C - a) ** 2).sum(1)) <= P['w1']))
        print(f"  rho_T = {mult:5.3f} x crit ({rT * 4:.3f} f.u.): P(tall kept) {np.mean(kt):.2f}  P(broad kept) {np.mean(kb):.2f}  share of species on tall {np.mean(nt):.2f}", flush=True)
