"""Design pilots after the half-normal radius noise and the overlap tolerance were introduced.
Paper landscapes (lethal outside) and the two-peak landscape only; held-out landscapes are not run.
Seeds 9000-9003 (landscapes), 8000-8009 (tournament), 7000-7003 (explosion)."""
import sys, time, numpy as np
sys.path.insert(0, '/home/claude/idea')
import idealib as L
which = sys.argv[1] if len(sys.argv) > 1 else 'all'
if which in ('all', 'land'):
    for name in L.LANDSCAPES:
        g = L.make_g(name, 'lethal'); B = L.BasinMap(g)
        for arm, kw in [('DE', None), ('IDEA-R', {}), ('IDEA-L', dict(radius_rule='literal'))]:
            M, t0, rad = [], time.time(), []
            for s in range(9000, 9004):
                rng = np.random.default_rng(s)
                if kw is None:
                    r = L.de_run(g, rng); Xf, f = r['x'] * 4, r['fit']
                else:
                    o = L.idea_run(g, rng, **kw); Xf, f = o['lives'] * 4, o['lives_fit']
                    rad.append(np.median(np.sqrt(np.prod(o['radii'], 1))) * 4)
                M.append(L.output_metrics(Xf, f, B, name))
            v = {k: np.mean([m[k] for m in M]) for k in M[0]}
            print(f"{name:10s} {arm:7s} {time.time() - t0:5.1f}s " + " ".join(f"{k}={v[k]:.3f}" for k in
                  ['top_fit', 'best', 'top_entropy', 'optima', 'basins', 'viable_frac']) +
                  (f" final_rho_f={np.median(rad):.3f}" if rad else ""), flush=True)
if which in ('all', 'tour'):
    P = L.TWO_PEAK; g = L.make_g('two_peak'); crit = 0.5908
    a, b = P['a'], P['b']
    for mult in (0.25, 0.5, 1.0, 2.0, 4.0):
        rT = mult * crit / 4
        kept_t, kept_b = [], []
        t0 = time.time()
        for s in range(8000, 8010):
            init = np.vstack([np.tile(a / 4, (16, 1)), np.tile(b / 4, (16, 1))])
            o = L.idea_run(g, np.random.default_rng(s), init_centres=init, rho_init=rT)
            Xf, f = o['lives'] * 4, o['lives_fit']
            kept_t.append(L.optima_covered(Xf, a[None], 0.25, f, 0.5)); kept_b.append(L.optima_covered(Xf, b[None], 0.25, f, 0.5))
        print(f"tournament rho_T = {mult:4.2f} x crit ({rT * 4:.3f} f.u.): P(tall kept) {np.mean(kept_t):.2f}  P(broad kept) {np.mean(kept_b):.2f}  {time.time() - t0:.1f}s", flush=True)
if which in ('all', 'expl'):
    for name in ('himmelblau', 'rosenbrock'):
        g = L.make_g(name, 'lethal')
        for arm, kw in [('full', {}), ('-G1', dict(radius_rule='none')), ('-G2', dict(compete=False)),
                        ('-G3', dict(extinct=False)), ('-all', dict(radius_rule='none', compete=False, extinct=False))]:
            fr, t0 = [], time.time()
            for s in range(7000, 7004):
                o = L.idea_run(g, np.random.default_rng(s), rhohat='moment', rho_max=np.inf, **kw)
                fr.append(np.median(np.sqrt(np.prod(o['radii'], 1))))
            print(f"explosion {name:10s} {arm:5s} median final rho (pop) per seed {np.round(fr, 3)}  {time.time() - t0:.1f}s", flush=True)
