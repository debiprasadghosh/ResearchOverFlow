"""Post-review checks and measurements for the IDEA paper (written after the confirmatory runs and the
independent review; reads runs/ and evals/, and runs small simulations; no test of a registered hypothesis).

    python3 verify_idea_addendum.py > verify_idea_addendum_output.txt
"""
import sys, os, json, math, glob
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import idealib as L

HERE = os.path.dirname(os.path.abspath(__file__))
RU, EV = os.path.join(HERE, 'runs'), os.path.join(HERE, 'evals')
pairs = L.schedule_pairs(25)
rng = np.random.default_rng(20261011)


def head(s):
    print('\n' + '=' * 100 + '\n' + s)


# --------------------------------------------------------------------------------------------- A1
head('A1  Proposition 3(a) with the paper\'s half-normal mutation (T8c used a symmetric one)')
rT, rmin = 0.0125 / np.prod([math.sqrt((1 - ap) / (1 - at)) for at, ap in pairs]), 0.0125
R = np.full((20000, 2), rT)
for k, (at, ap) in enumerate(pairs[:4]):
    sg = 0.1 * L.ddpm_sigma(at, ap)
    R = np.clip(math.sqrt(ap) * R + sg * R * np.abs(rng.standard_normal(R.shape)), rmin, 1.0)
    one = (R[:, 0] <= rmin * (1 + 1e-9)).mean(); both = np.all(R <= rmin * (1 + 1e-9), axis=1).mean()
    print(f'   after update {k + 1}: share at rho_min, one coordinate {one:.3f}, both coordinates {both:.3f}')
print(f'   without mutation, radius after 3 updates / rho_T = {np.prod([math.sqrt(ap) for at, ap in pairs[:3]]):.5f}')

# --------------------------------------------------------------------------------------------- A2
head('A2  IDEA-L confirmatory runs: share of species at rho_min (both coordinates) after updates 1-3')
for nm in L.LANDSCAPES:
    A = np.load(os.path.join(RU, 'primary', f'IDEA_L__{nm}.npz'))
    fr = A['log_frac_at_min'][:, :3]
    print(f'   {nm:10s} medians {np.round(np.median(fr, 0), 3)}  means {np.round(fr.mean(0), 3)}  minimum after update 3 {fr[:, 2].min():.3f}; '
          f'runs with share < 1 after update 3: {int((fr[:, 2] < 1).sum())}')

# --------------------------------------------------------------------------------------------- A3/B4
head('A3/B4  Final IDEA-R boxes overlap; union of the boxes after a post-hoc exclusion pass')
for nm in L.LANDSCAPES + L.HELDOUT:
    A = np.load(os.path.join(RU, 'primary', f'IDEA_R__{nm}.npz'))
    g = L.make_g(nm)
    n_ov, maxpen, runs_ov, u_raw, u_dis, lives_nv, k_kept = [], 0.0, 0, [], [], [], []
    for i in range(A['centres'].shape[0]):
        C, Rr, F = A['centres'][i], A['radii'][i], A['F'][i]
        K = len(C); n = A['lives'].shape[1] // K
        LX = A['lives'][i].reshape(K, n, 2); LG = A['lives_fit'][i].reshape(K, n)
        pen = (Rr[:, None, :] + Rr[None, :, :]) - np.abs(C[:, None, :] - C[None, :, :])
        ov = np.all(pen > 1e-12, axis=-1); np.fill_diagonal(ov, False)
        cnt = int(ov.sum() // 2); n_ov.append(cnt); runs_ov += cnt > 0
        if cnt:
            maxpen = max(maxpen, float(np.min(pen, axis=-1)[ov].max()) * 4)
        lives_nv.append(float((LG < L.VIABLE).mean()))
        if i < 30:   # union metrics on the first 30 runs (Monte Carlo)
            u_raw.append(L.clade_metrics(g, C, Rr, L.VIABLE, n_mc=60000, rng=np.random.default_rng(i))['union_nonviable'])
            S = [L.Species(C[k], Rr[k], F=float(F[k]), lx=LX[k].copy(), lg=LG[k].copy()) for k in range(K)]
            kept, _ = L.compete_boxes(S, 0.0125, 0.1)
            k_kept.append(len(kept))
            u_dis.append(L.clade_metrics(g, np.array([s.c for s in kept]), np.array([s.r for s in kept]), L.VIABLE,
                                         n_mc=60000, rng=np.random.default_rng(i))['union_nonviable'])
    print(f'   {nm:10s} runs with overlapping final boxes {runs_ov}/100; overlapping pairs per run {np.mean(n_ov):.1f}; '
          f'largest penetration {maxpen:.3f} f.u.; non-viable share: lives {np.mean(lives_nv):.3f}, union {np.nanmean(u_raw):.3f}, '
          f'union after exclusion {np.nanmean(u_dis):.3f} ({np.mean(k_kept):.1f} boxes kept of 32; first 30 runs)')

# --------------------------------------------------------------------------------------------- A5
head('A5  Proposition 2(a): population quantiles commute with left-continuous nondecreasing maps only')
# exact (population) computation for g ~ U[0, 1], q = 0.1, phi = 1{z >= 0.1} (right-continuous at 0.1):
# the CDF of phi(g) at 0 is P(g < 0.1) = 0.1 >= q, so its q-quantile (inf{s : P(phi(g) <= s) >= q}) is 0,
# while phi(q-quantile of g) = phi(0.1) = 1.
print('   g ~ U[0,1], q = 0.1, phi = 1{z >= 0.1}: q-quantile of phi(g) = 0 (P(phi(g) <= 0) = P(g < 0.1) = 0.1), '
      'phi(q-quantile of g) = phi(0.1) = 1: the population statement needs phi left-continuous.')
# the sample statement (k-th order statistic) holds for every nondecreasing phi, including this one
G = rng.uniform(0, 1, (20000, 16))
ok = np.allclose(L.quantile_k((G >= 0.1).astype(float), 0.1), (L.quantile_k(G, 0.1) >= 0.1).astype(float))
print(f'   k-th order statistic of 16 lives, same phi: commutes in all 20000 samples: {ok}')

# --------------------------------------------------------------------------------------------- A6
head('A6  Tournament: generation-0 exclusions of the identical seeded boxes')
for m in [0.25, 0.5, 1.0, 2.0, 2.83, 4.0]:
    A = np.load(os.path.join(RU, 'twopeak', f'T_sel_m{m}__two_peak.npz'))
    C = A['centres'] * 4
    da = np.sqrt(((C - L.TWO_PEAK['a']) ** 2).sum(-1)); db = np.sqrt(((C - L.TWO_PEAK['b']) ** 2).sum(-1))
    print(f'   m={m:5.3f}: generation 0 extinctions {A["log_extinct"][:, 0].mean():.1f}, exclusions {A["log_excluded"][:, 0].mean():.1f}, '
          f'births {A["log_births"][:, 0].mean():.1f}; final median distance of species centres to the nearer peak {np.median(np.minimum(da, db)):.2f} f.u.')

# --------------------------------------------------------------------------------------------- A7
head('A7  Model-matched tournament (exploratory): 16 centred boxes per peak, centres fixed, no exclusion,\n'
     '    no speciation, extinction by the relative threshold, refill by cloning a uniformly chosen survivor,\n'
     '    radius = own radius x (s_t + sigma_t |xi|), clipped to [0.05, 4] f.u.; 200 runs per cell')
P = L.TWO_PEAK


def model_run(mult, n, seed, theta=0.5, q=0.1, crit=0.5908):
    r = np.random.default_rng(seed)
    lab = np.array([0] * 16 + [1] * 16)
    Cc = np.where(lab[:, None] == 0, P['a'][None], P['b'][None]).astype(float)
    Rr = np.full(32, mult * crit)
    for at, ap in pairs:
        U = r.uniform(-1, 1, (32, n, 2))
        G = L.g_two_peak((Cc[:, None, :] + Rr[:, None, None] * U).reshape(-1, 2)).reshape(32, n)
        F = L.quantile_k(G, q)
        alive = F >= theta * at * F.max()
        idx = np.where(alive)[0] if alive.any() else np.array([int(np.argmax(F))])
        new = np.concatenate([idx, r.choice(idx, 32 - len(idx))]) if len(idx) < 32 else idx
        lab, Cc, Rr = lab[new], Cc[new], Rr[new]
        sg = 0.1 * L.ddpm_sigma(at, ap); st = math.sqrt((1 - ap) / (1 - at))
        Rr = np.clip(st * Rr + sg * Rr * np.abs(r.standard_normal(32)), 0.05, 4.0)
    return bool((lab == 0).any()), float((lab == 0).mean())


MULTS = [0.25, 0.354, 0.5, 0.707, 1.0, 1.414, 2.0, 2.83, 4.0]
B7 = {}
for n in (16, 256):
    row = []
    for m in MULTS:
        res = [model_run(m, n, 50000 + s) for s in range(200)]
        B7[f'{n}/{m}'] = float(np.mean([x[0] for x in res]))
        row.append(f'{m:g}:{np.mean([x[0] for x in res]):.2f}')
    print(f'   n = {n:3d}: share of runs keeping the tall lineage  ' + '  '.join(row))
os.makedirs(os.path.join(HERE, 'report'), exist_ok=True)
json.dump(B7, open(os.path.join(HERE, 'report', 'b7_model_tournament.json'), 'w'), indent=1)

# --------------------------------------------------------------------------------------------- A8
head('A8  Distance of the 64 best outputs to the nearest global optimum (median over runs of the median)')
for nm in L.LANDSCAPES:
    O = L.OPTIMA[nm]
    s = []
    for arm in ('DE', 'IDEA_R'):
        A = np.load(os.path.join(RU, 'primary', f'{arm}__{nm}.npz'))
        X = A['x'] if arm == 'DE' else A['lives']; Fv = A['fit'] if arm == 'DE' else A['lives_fit']
        med = []
        for i in range(X.shape[0]):
            top = X[i][L.top_k_idx(Fv[i])] * 4
            med.append(np.median(np.sqrt(((top[:, None] - O[None]) ** 2).sum(-1)).min(1)))
        s.append(f'{arm} {np.median(med):.3f}')
    print(f'   {nm:10s} ' + '  '.join(s))

# --------------------------------------------------------------------------------------------- A9/B10
head('A9/B10  DE on Rosenbrock as coded; the plateau against the box')
A = np.load(os.path.join(RU, 'coded', 'DE__rosenbrock.npz'))
ins_top, all_top, ins_x0 = [], 0, []
for i in range(A['x'].shape[0]):
    top = A['x'][i][L.top_k_idx(A['fit'][i])] * 4
    inside = np.all(np.abs(top) <= 4, axis=1)
    ins_top.append(inside.mean()); all_top += inside.all()
    ins_x0.append(np.all(np.abs(A['x0'][i] * 4) <= 4, axis=1).mean())
ins_x0top = [np.all(np.abs(A['x0'][i][L.top_k_idx(A['x0_fit'][i])] * 4) <= 4, axis=1).mean() for i in range(A['x'].shape[0])]
print(f'   share of the 64 best final individuals inside the box {np.mean(ins_top):.3f} (all 64 inside in {all_top} runs); '
      f'share of all 512 target estimates x0 inside {np.mean(ins_x0):.3f}; share of the 64 fittest target estimates inside {np.mean(ins_x0top):.3f}')
s1 = np.linspace(-4, 4, 801); G2 = np.stack(np.meshgrid(s1, s1, indexing='ij'), -1).reshape(-1, 2)
for nm in ('rosenbrock', 'beale', 'himmelblau'):
    gc = L.g_map(nm, G2, outside='coded'); plateau = float(L.g_map(nm, np.array([[5.0, 5.0]]), outside='coded')[0])
    print(f'   {nm:10s} share of the box with g below the outside plateau ({plateau:.4f}): {(gc < plateau).mean():.3f}')

# --------------------------------------------------------------------------------------------- A11
head('A11  Evaluation wall time (from file times of evals/)')
ts = sorted(os.path.getmtime(p) for p in glob.glob(os.path.join(EV, '*', '*.json')))
print(f'   first {ts[0]:.0f}, last {ts[-1]:.0f}: {(ts[-1] - ts[0]) / 60:.1f} minutes on 2 workers (cell durations before the first file not included)')
