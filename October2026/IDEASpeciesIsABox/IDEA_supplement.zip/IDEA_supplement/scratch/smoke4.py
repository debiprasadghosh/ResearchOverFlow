import sys, time, numpy as np
sys.path.insert(0, '/home/claude/idea')
import idealib as L
arms={'DE':None,'abs_best':dict(theta_mode='absolute',fallback='best'),'abs_susp':dict(theta_mode='absolute',fallback='suspend'),
      'rel':dict(theta_mode='relative'),'rel_fitbirth':dict(theta_mode='relative',birth='fitness'),'rel_within':dict(theta_mode='relative',within=True),
      'lit_rel':dict(theta_mode='relative',radius_rule='literal')}
for name in ['himmelblau','ackley','rastrigin','rosenbrock','beale']:
    g=L.make_g(name,'lethal'); B=L.BasinMap(g)
    print(name)
    for arm,kw in arms.items():
        M=[];te=[]
        for s in range(8):
            rng=np.random.default_rng(3000+s)
            if kw is None:
                r=L.de_run(g,rng); Xf=r['x']*4; f=r['fit']
            else:
                o=L.idea_run(g,rng,record=True,**kw); Xf=o['lives']*4; f=o['lives_fit']; te.append(o['log']['total_extinction'])
            M.append(L.output_metrics(Xf,f,B,L.OPTIMA[name]))
        v={k:np.mean([m[k] for m in M]) for k in M[0]}
        print(f"   {arm:12s} "+" ".join(f"{k}={v[k]:.3f}" for k in ['top_fit','top_entropy','basins','optima','viable_frac','best'])+(f" totext={np.mean(te):.1f}" if te else ""))
