import sys, numpy as np
sys.path.insert(0, '/home/claude/idea')
import idealib as L
g=L.make_g('himmelblau')
for s in range(8):
    rng=np.random.default_rng(3000+s)
    o=L.idea_run(g,rng,record=True)
    lg=o['log']; C=o['centres']*4
    inbox=np.all(np.abs(C)<=4,1).mean()
    print(s, 'top', round(float(np.sort(o['lives_fit'])[-64:].mean()),3), 'F', np.round(np.sort(o['F'])[-5:],3), 'inbox', inbox, 'totext', lg['total_extinction'],
          'centre mean', np.round(C.mean(0),2), 'meanF', np.round(lg['mean_F'][-6:],3))
