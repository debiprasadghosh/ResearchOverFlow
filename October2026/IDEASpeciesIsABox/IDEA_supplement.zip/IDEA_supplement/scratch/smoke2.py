import sys, time, numpy as np
sys.path.insert(0, '/home/claude/idea')
import idealib as L
for name in L.LANDSCAPES:
    g = L.make_g(name)
    t=time.time(); B = L.BasinMap(g); tb=time.time()-t
    roots=np.unique(B.label); vals=B.V.reshape(-1)[roots]
    print(f"{name:10s} basin map {tb:.1f}s  #local maxima {len(roots)}  #with g>=0.5: {(vals>=0.5).sum()}  max g {B.V.max():.4f}")
    res={}
    for arm in ['DE','lit','rep','rw']:
        M=[]
        for s in range(5):
            rng=np.random.default_rng(2000+s)
            if arm=='DE':
                r=L.de_run(g,rng); Xf=r['x']*4; f=r['fit']
            else:
                kw=dict(radius_rule='literal') if arm=='lit' else dict(radius_rule='repaired', within=(arm=='rw'))
                o=L.idea_run(g,rng,**kw); Xf=o['lives']*4; f=o['lives_fit']
            M.append(L.output_metrics(Xf,f,B,L.OPTIMA[name]))
        res[arm]={k:np.mean([m[k] for m in M]) for k in M[0]}
    for arm,v in res.items():
        print(f"   {arm:4s} " + " ".join(f"{k}={v[k]:.3f}" for k in v))
