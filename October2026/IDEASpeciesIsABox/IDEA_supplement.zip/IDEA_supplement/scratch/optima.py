import numpy as np
from scipy.optimize import minimize
def ackley(X):
    x,y=X[...,0],X[...,1]
    return -20*np.exp(-0.2*np.sqrt(0.5*(x**2+y**2)))-np.exp(0.5*(np.cos(2*np.pi*x)+np.cos(2*np.pi*y)))+20+np.e
def rastrigin(X): return 20+(X**2-10*np.cos(2*np.pi*X)).sum(-1)
for name,f in [('ackley',ackley),('rastrigin',rastrigin)]:
    s=np.linspace(-4,4,1601); G=np.stack(np.meshgrid(s,s,indexing='ij'),-1); V=f(G)
    i=np.unravel_index(np.argmax(V),V.shape); x0=G[i]
    r=minimize(lambda z:-f(z),x0,method='Nelder-Mead',options=dict(xatol=1e-10,fatol=1e-12))
    print(name,'grid max',V.max(),'at',x0,'refined',r.x,-r.fun)
    # value at boundary corners
    print('  f(4,4)=',f(np.array([4.,4.])),' f(3.5,3.5)=',f(np.array([3.5,3.5])))
