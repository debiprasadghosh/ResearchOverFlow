import sys, numpy as np
sys.path.insert(0, '/home/claude/idea')
import idealib as L
P=L.TWO_PEAK; g=L.make_g('two_peak')
a=P['a']/4; b=P['b']/4; w1=P['w1']/4; w2=P['w2']/4
def occ(C):  # centres in pop coords
    d1=np.sqrt(((C-a)**2).sum(1)); d2=np.sqrt(((C-b)**2).sum(1))
    return (d1<=w1).mean(), (d2<=w2).mean(), (d1<=w1).any(), (d2<=w2).any()
for invitro in [False, True]:
    print('in vitro' if invitro else 'in vivo')
    for rm in [0.025,0.05,0.075,0.1,0.125,0.15,0.2,0.25]:
        R=[]
        for s in range(10):
            rng=np.random.default_rng(4000+s)
            init=None
            if invitro:
                init=np.vstack([np.tile(a,(16,1)),np.tile(b,(16,1))])
            o=L.idea_run(g,rng,record=True,rho_min=rm,theta_mode='absolute',init_centres=init)
            R.append(occ(o['centres'])+(o['log']['total_extinction'],))
        R=np.array(R,float)
        print(f"  rho_min {rm:.3f}: share tall {R[:,0].mean():.2f} share broad {R[:,1].mean():.2f} P(tall occupied) {R[:,2].mean():.2f} P(broad) {R[:,3].mean():.2f} totext {R[:,4].mean():.1f}")
R=[]
for s in range(10):
    rng=np.random.default_rng(4000+s); r=L.de_run(g,rng)
    R.append(occ(r['x']))
R=np.array(R,float); print('DE: share tall %.2f broad %.2f P(tall) %.2f P(broad) %.2f'%tuple(R.mean(0)))
