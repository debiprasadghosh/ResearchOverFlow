import numpy as np
np.set_printoptions(precision=4, suppress=True, linewidth=160)
# cosine schedule as in DDIMSchedulerCosine(num_step=25)
S=25
a=(np.cos(np.linspace(0,np.pi,S))+1)/2
a=(a+1e-3)*(1-1e-3)/(1+1e-3)
print("alpha[0],alpha[-1]",a[0],a[-1])
# iteration: t=S-1..1 ; (alpha_t, alpha_prev)=(a[t],a[t-1])
pairs=[(a[t],a[t-1]) for t in range(S-1,0,-1)]
def sig(at,ap,sm): return sm*np.sqrt((1-ap)/(1-at)*(1-at/ap))
print("step  alpha_t  alpha_p  sqrt(ap)  noise_ratio  sigma(0.1) sigma(1)  m_t(0.1)  r_t")
cum_lit=1;cum_rep=1;cum_m=1
for k,(at,ap) in enumerate(pairs):
    s=sig(at,ap,0.1)
    m=np.sqrt(ap)+np.sqrt(1-ap-s**2)*(1-np.sqrt(at))/np.sqrt(1-at)
    nr=np.sqrt((1-ap)/(1-at))
    cum_lit*=np.sqrt(ap);cum_rep*=nr;cum_m*=m
    print(f"{k:3d} {at:8.5f} {ap:8.5f} {np.sqrt(ap):8.4f} {nr:10.4f} {s:9.4f} {sig(at,ap,1):8.4f} {m:9.4f} {np.sqrt((1-at)/at):8.3f}")
print("cum literal coeff",cum_lit," cum noise-ratio",cum_rep," cum drift m",cum_m)
