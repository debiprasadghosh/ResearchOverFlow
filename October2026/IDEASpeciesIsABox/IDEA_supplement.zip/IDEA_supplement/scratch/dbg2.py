import sys, numpy as np
sys.path.insert(0, '/home/claude/idea')
import idealib as L
g=L.make_g('himmelblau','lethal'); B=L.BasinMap(g)
rng=np.random.default_rng(3001)
o=L.idea_run(g,rng,record=True)
lg=o['log']
for k in ['n_species','extinct','excluded','splits','births','med_rho','mean_F']:
    print(k, np.round(lg[k],3))
C=o['centres']*4
print('final centres basins', np.unique(B.labels(C),return_counts=True))
print('F', np.round(np.sort(o['F']),3))
