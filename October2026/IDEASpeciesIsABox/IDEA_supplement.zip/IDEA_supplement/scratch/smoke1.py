import sys, time, numpy as np
sys.path.insert(0, '/home/claude/idea')
import idealib as L
for name in L.LANDSCAPES:
    g = L.make_g(name)
    t=time.time(); rng=np.random.default_rng(1001)
    r = L.de_run(g, rng)
    t1=time.time()-t
    idx=L.top_k_idx(r['x0_fit']); 
    print(f"{name:10s} DE  {t1:.2f}s top64 x0 fit {r['x0_fit'][idx].mean():.3f} ent(x at idx) {L.entropy_bits(r['x'][idx]*4):.2f} | pop top64 {r['fit'][L.top_k_idx(r['fit'])].mean():.3f} n_eval {r['n_eval']}")
    for rule in ['literal','repaired']:
        t=time.time(); rng=np.random.default_rng(1001)
        o = L.idea_run(g, rng, record=True, radius_rule=rule)
        t1=time.time()-t
        lg=o['log']
        print(f"   IDEA-{rule[:3]} {t1:.2f}s top64 {o['lives_fit'][L.top_k_idx(o['lives_fit'])].mean():.3f} best {o['lives_fit'].max():.3f} n_eval {o['n_eval']} medrho {np.round(lg['med_rho'][::4],4)} at_min {np.round(lg['frac_at_min'][::4],2)}")
        print(f"        ext {lg['extinct']} exc {lg['excluded']} splits {sum(lg['splits'])} births {sum(lg['births'])} totext {lg['total_extinction']}")
