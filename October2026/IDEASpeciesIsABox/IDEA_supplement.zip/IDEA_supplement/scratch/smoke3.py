import sys, time, numpy as np
sys.path.insert(0, '/home/claude/idea')
import idealib as L
arms={'DE':None,'rep_unif':dict(),'rep_fit':dict(birth='fitness'),'rw_unif':dict(within=True),
      'A1_none':dict(radius_rule='none'),'A2_nocomp':dict(compete=False),'A3_noext':dict(extinct=False),
      'A4_moment':dict(rhohat='moment'),'A14':dict(rhohat='moment',radius_rule='none')}
for name in ['himmelblau','ackley','rastrigin','rosenbrock']:
    g=L.make_g(name); B=L.BasinMap(g)
    print(name)
    for arm,kw in arms.items():
        M=[];rad=[];t=time.time()
        for s in range(8):
            rng=np.random.default_rng(3000+s)
            if kw is None:
                r=L.de_run(g,rng); Xf=r['x']*4; f=r['fit']
            else:
                o=L.idea_run(g,rng,**kw); Xf=o['lives']*4; f=o['lives_fit']; rad.append(np.median(np.sqrt(np.prod(o['radii'],1))))
            M.append(L.output_metrics(Xf,f,B,L.OPTIMA[name]))
        v={k:np.mean([m[k] for m in M]) for k in M[0]}
        print(f"   {arm:10s} {time.time()-t:5.1f}s "+" ".join(f"{k}={v[k]:.3f}" for k in ['top_fit','top_entropy','basins','optima','viable_frac'])+(f" medrho={np.median(rad):.4f}" if rad else ""))
