# IDEA supplement: When the Species Is a Box

Everything needed to check and reproduce the paper `IDEA_When_the_Species_Is_a_Box.md`.

| Path | What it is |
|---|---|
| `PROTOCOL.md`, `evals_code_sha256.txt` | protocol and SHA-256 of the frozen library, run script, evaluator, theory checks and protocol (10:43 UTC, 6 October 2026) |
| `idealib.py` | NumPy port of Diffusion Evolution (reference commit 41ac6ca; foobench 18de5da) and IDEA |
| `idea_runs.py`, `idea_eval.py` | the 145 confirmatory cells; the frozen evaluator and decision rules (`evals/decisions.json`) |
| `verify_idea_theory.py`, `verify_idea_theory_output.txt` | checks T1–T17 of the propositions (frozen) |
| `verify_idea_addendum.py`, `verify_idea_addendum_output.txt` | post-review checks A1–A11 (A7: exploratory simulation of Proposition 4's model) |
| `repro_de.py`, `results/repro_de.json`, `logs/repro_de.log` | reproduction of the original paper's Table 3 |
| `evals/` | per-run metrics of every cell (JSON) |
| `idea_report.py`, `idea_facts.py`, `paper_tables.py` | tables (`report/`), figures (`figures/`), quoted numbers (`facts_output.txt`), Appendix B |
| `pilots/`, `scratch/`, `logs/` | pre-freeze pilots and smoke tests; `logs/scratch_outputs_recovered.txt` is reconstructed after the fact |

Raw run outputs (`runs/`, 191 MB) are omitted; `python3 idea_runs.py all` regenerates them. The reference repositories are identified by commit and not redistributed.

Reproduction (Python 3.11, NumPy 2.4, SciPy 1.17, Matplotlib 3.10): see Appendix A of the paper.
