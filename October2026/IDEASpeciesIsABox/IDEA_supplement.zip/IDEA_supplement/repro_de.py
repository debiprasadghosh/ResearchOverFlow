"""Reproduction of the Diffusion Evolution column of Table 3 (paper App. A.4) with
the numpy port, landscapes as coded (foobench limit values outside the box).
Metric definitions follow experiments/benchmarks/statistic.py at commit 41ac6ca:
fitness = mean of the top-64 x0-estimate fitness values at the last step;
entropy = entropy (bits, cells round(10 x)) of the final population members whose
x0 estimates are the top 64. Seeds 0-99; sigma_m in {0.1 (code), 1.0 (text)}."""
import sys, json, time, numpy as np
sys.path.insert(0, '/home/claude/idea')
import idealib as L
PAPER = {  # Table 3, Diffusion Evolution: (entropy mean, sd, fitness mean, sd)
    'rosenbrock': (5.86, 0.10, 0.88, 0.06), 'beale': (5.50, 0.16, 0.96, 0.01),
    'himmelblau': (5.23, 0.20, 0.96, 0.01), 'ackley': (5.67, 0.13, 0.78, 0.07),
    'rastrigin': (5.79, 0.10, 0.64, 0.04)}
out = {}
for sm in (0.1, 1.0):
    for name in L.LANDSCAPES:
        g = L.make_g(name, 'coded')
        ent, fit, pent, pfit, outside = [], [], [], [], []
        for s in range(100):
            rng = np.random.default_rng(s)
            r = L.de_run(g, rng, sigma_m=sm)
            idx = L.top_k_idx(r['x0_fit'])
            fit.append(float(r['x0_fit'][idx].mean()))
            ent.append(L.entropy_bits(r['x'][idx] * 4))
            pidx = L.top_k_idx(r['fit'])
            pfit.append(float(r['fit'][pidx].mean()))
            pent.append(L.entropy_bits(r['x'][pidx] * 4))
            outside.append(float((np.abs(r['x'] * 4) > 4).any(1).mean()))
        out[f'{sm}_{name}'] = dict(sigma_m=sm, landscape=name, entropy=ent, fitness=fit,
                                   pop_entropy=pent, pop_fitness=pfit, frac_outside=outside)
        pe, ps, pf, pfs = PAPER[name]
        e, f = np.array(ent), np.array(fit)
        print(f"sigma_m={sm:<4} {name:10s} entropy {e.mean():.2f} ({e.std():.2f}) [paper {pe:.2f} ({ps:.2f})]  "
              f"fitness {f.mean():.3f} ({f.std():.3f}) [paper {pf:.2f} ({pfs:.2f})]  "
              f"pop: ent {np.mean(pent):.2f} fit {np.mean(pfit):.3f}  outside {np.mean(outside):.3f}", flush=True)
json.dump(out, open('results/repro_de.json', 'w'))
