# IDEA study: tables

### Table R. Reproduction of the Diffusion Evolution column of the paper's Table 3 (100 runs each, landscapes as coded)

| Landscape | entropy, paper | entropy, port, σ_m = 0.1 | entropy, port, σ_m = 1 | fitness, paper | fitness, port, σ_m = 0.1 | fitness, port, σ_m = 1 | final population outside the box (σ_m = 0.1) |
|---|---|---|---|---|---|---|---|
| Rosenbrock | 5.86 (0.10) | 5.85 (0.08) | 5.88 (0.09) | 0.88 (0.06) | 0.89 (0.05) | 0.89 (0.05) | 0.802 |
| Beale | 5.50 (0.16) | 5.48 (0.18) | 5.49 (0.15) | 0.96 (0.01) | 0.97 (0.01) | 0.97 (0.01) | 0.004 |
| Himmelblau | 5.23 (0.20) | 5.22 (0.24) | 5.37 (0.16) | 0.96 (0.01) | 0.96 (0.01) | 0.96 (0.01) | 0.012 |
| Ackley | 5.67 (0.13) | 5.68 (0.14) | 5.79 (0.10) | 0.78 (0.07) | 0.78 (0.07) | 0.70 (0.06) | 0.011 |
| Rastrigin | 5.79 (0.10) | 5.80 (0.08) | 5.90 (0.06) | 0.64 (0.04) | 0.64 (0.03) | 0.58 (0.03) | 0.003 |

Mean (sd). The paper's metrics: mean x0-estimate fitness of the 64 best x0 estimates at the last step; entropy of the final population members with those indices.

### Primary comparison: Mean fitness g of the 64 fittest outputs

| Landscape | DE | IDEA-R | IDEA-L |
|---|---|---|---|
| Rosenbrock | 0.993 (0.002) | 0.991 (0.007) | 0.983 (0.057) |
| Beale | 0.961 (0.012) | 0.954 (0.034) | 0.963 (0.030) |
| Himmelblau | 0.943 (0.016) | 0.927 (0.066) | 0.861 (0.106) |
| Ackley | 0.750 (0.060) | 0.950 (0.064) | 0.927 (0.095) |
| Rastrigin | 0.609 (0.030) | 0.832 (0.114) | 0.813 (0.118) |
| Six-hump camel | 0.932 (0.020) | 0.899 (0.112) | 0.767 (0.199) |
| Shubert | 0.567 (0.019) | 0.510 (0.022) | 0.533 (0.061) |
| Vincent | 0.910 (0.021) | 0.933 (0.065) | 0.857 (0.146) |

Mean (sd) over 100 runs; paper landscapes with fitness 0 outside the box; held-out landscapes below the line of five.

### Primary comparison: Best output fitness

| Landscape | DE | IDEA-R | IDEA-L |
|---|---|---|---|
| Rosenbrock | 1.000 (0.000) | 0.998 (0.003) | 0.992 (0.054) |
| Beale | 0.999 (0.002) | 0.982 (0.023) | 0.982 (0.023) |
| Himmelblau | 0.998 (0.002) | 0.971 (0.050) | 0.923 (0.085) |
| Ackley | 0.992 (0.012) | 0.982 (0.056) | 0.967 (0.075) |
| Rastrigin | 0.928 (0.065) | 0.912 (0.101) | 0.899 (0.111) |
| Six-hump camel | 0.998 (0.002) | 0.941 (0.099) | 0.817 (0.195) |
| Shubert | 0.928 (0.070) | 0.590 (0.074) | 0.636 (0.136) |
| Vincent | 0.997 (0.004) | 0.978 (0.049) | 0.909 (0.132) |

Mean (sd) over 100 runs; paper landscapes with fitness 0 outside the box; held-out landscapes below the line of five.

### Primary comparison: Global optima kept (a viable output within δ_L)

| Landscape | DE | IDEA-R | IDEA-L |
|---|---|---|---|
| Rosenbrock (of 1) | 1.00 (0.00) | 0.49 (0.50) | 0.30 (0.46) |
| Beale (of 1) | 1.00 (0.00) | 0.45 (0.50) | 0.36 (0.48) |
| Himmelblau (of 4) | 3.64 (0.50) | 1.33 (0.58) | 0.89 (0.66) |
| Ackley (of 4) | 3.39 (0.68) | 1.78 (0.76) | 1.48 (0.71) |
| Rastrigin (of 4) | 2.49 (0.91) | 1.36 (0.88) | 1.14 (0.69) |
| Six-hump camel (of 2) | 1.99 (0.10) | 0.81 (0.67) | 0.37 (0.52) |
| Shubert (of 18) | 6.04 (2.05) | 0.05 (0.22) | 0.20 (0.42) |
| Vincent (of 36) | 8.44 (2.02) | 1.23 (0.79) | 0.70 (0.64) |

Mean (sd) over 100 runs; paper landscapes with fitness 0 outside the box; held-out landscapes below the line of five.

### Primary comparison: Basins holding a viable output

| Landscape | DE | IDEA-R | IDEA-L |
|---|---|---|---|
| Rosenbrock | 75.2 (9.0) | 34.5 (13.4) | 34.8 (15.0) |
| Beale | 10.7 (2.6) | 5.2 (2.2) | 6.3 (2.6) |
| Himmelblau | 3.8 (0.4) | 2.0 (0.6) | 1.8 (0.6) |
| Ackley | 14.7 (1.4) | 6.6 (1.6) | 5.5 (1.9) |
| Rastrigin | 20.7 (2.7) | 4.5 (1.4) | 3.4 (1.1) |
| Six-hump camel | 2.0 (0.0) | 1.7 (0.5) | 1.3 (0.7) |
| Shubert | 45.3 (5.9) | 5.6 (2.5) | 5.0 (2.4) |
| Vincent | 13.9 (1.9) | 2.4 (0.7) | 1.8 (0.7) |

Mean (sd) over 100 runs; paper landscapes with fitness 0 outside the box; held-out landscapes below the line of five.

### Primary comparison: Entropy of the 64 fittest outputs (bits)

| Landscape | DE | IDEA-R | IDEA-L |
|---|---|---|---|
| Rosenbrock | 5.41 (0.15) | 3.30 (0.36) | 3.17 (0.44) |
| Beale | 5.50 (0.18) | 3.17 (0.34) | 2.96 (0.47) |
| Himmelblau | 5.17 (0.25) | 2.45 (0.59) | 2.48 (0.55) |
| Ackley | 5.69 (0.14) | 2.63 (0.54) | 2.42 (0.57) |
| Rastrigin | 5.78 (0.09) | 2.48 (0.59) | 2.38 (0.52) |
| Six-hump camel | 5.44 (0.17) | 2.92 (0.48) | 2.73 (0.55) |
| Shubert | 5.88 (0.07) | 3.82 (0.35) | 3.44 (0.48) |
| Vincent | 5.41 (0.22) | 2.68 (0.47) | 2.46 (0.58) |

Mean (sd) over 100 runs; paper landscapes with fitness 0 outside the box; held-out landscapes below the line of five.

### Primary comparison: Share of outputs with g ≥ 0.5

| Landscape | DE | IDEA-R | IDEA-L |
|---|---|---|---|
| Rosenbrock | 0.869 (0.022) | 0.997 (0.007) | 0.985 (0.099) |
| Beale | 0.786 (0.034) | 0.970 (0.048) | 0.974 (0.046) |
| Himmelblau | 0.579 (0.048) | 0.937 (0.119) | 0.838 (0.202) |
| Ackley | 0.215 (0.042) | 0.962 (0.085) | 0.927 (0.167) |
| Rastrigin | 0.115 (0.022) | 0.781 (0.213) | 0.741 (0.232) |
| Six-hump camel | 0.519 (0.045) | 0.908 (0.201) | 0.638 (0.382) |
| Shubert | 0.112 (0.016) | 0.069 (0.038) | 0.091 (0.059) |
| Vincent | 0.394 (0.040) | 0.932 (0.106) | 0.790 (0.276) |

Mean (sd) over 100 runs; paper landscapes with fitness 0 outside the box; held-out landscapes below the line of five.

### Primary comparison: Robust fitness of the 64 fittest outputs (10th percentile of g over a box of half-width 0.2)

| Landscape | DE | IDEA-R | IDEA-L |
|---|---|---|---|
| Rosenbrock | 0.942 (0.010) | 0.909 (0.077) | 0.844 (0.142) |
| Beale | 0.892 (0.029) | 0.847 (0.097) | 0.753 (0.181) |
| Himmelblau | 0.791 (0.029) | 0.765 (0.113) | 0.656 (0.170) |
| Ackley | 0.529 (0.046) | 0.765 (0.152) | 0.694 (0.204) |
| Rastrigin | 0.374 (0.022) | 0.556 (0.087) | 0.539 (0.090) |
| Six-hump camel | 0.851 (0.026) | 0.817 (0.122) | 0.675 (0.206) |
| Shubert | 0.333 (0.012) | 0.373 (0.023) | 0.328 (0.055) |
| Vincent | 0.625 (0.054) | 0.723 (0.094) | 0.631 (0.163) |

Mean (sd) over 100 runs; paper landscapes with fitness 0 outside the box; held-out landscapes below the line of five.

### Primary comparison: Robust fitness at half-width 0.05

| Landscape | DE | IDEA-R | IDEA-L |
|---|---|---|---|
| Rosenbrock | 0.987 (0.002) | 0.981 (0.013) | 0.964 (0.066) |
| Beale | 0.950 (0.013) | 0.939 (0.039) | 0.935 (0.050) |
| Himmelblau | 0.917 (0.019) | 0.897 (0.081) | 0.823 (0.117) |
| Ackley | 0.708 (0.058) | 0.921 (0.079) | 0.895 (0.109) |
| Rastrigin | 0.556 (0.029) | 0.778 (0.115) | 0.757 (0.119) |
| Six-hump camel | 0.916 (0.022) | 0.882 (0.116) | 0.747 (0.201) |
| Shubert | 0.482 (0.010) | 0.464 (0.012) | 0.475 (0.039) |
| Vincent | 0.850 (0.031) | 0.899 (0.071) | 0.815 (0.151) |

Mean (sd) over 100 runs; paper landscapes with fitness 0 outside the box; held-out landscapes below the line of five.

### Explosion arms (moment-type radius estimate, no ρ_max): runs exploded / median final half-width (population units)

| Arm | Rosenbrock | Beale | Himmelblau | Ackley | Rastrigin |
|---|---|---|---|---|---|
| X_full | 0 / 0.013 | 0 / 0.013 | 0 / 0.013 | 0 / 0.013 | 0 / 0.013 |
| X_noG1 | 0 / 0.028 | 0 / 0.029 | 0 / 0.014 | 0 / 0.013 | 0 / 0.013 |
| X_noG2 | 0 / 0.033 | 0 / 0.036 | 0 / 0.018 | 0 / 0.013 | 0 / 0.013 |
| X_noG3 | 0 / 0.022 | 0 / 0.021 | 0 / 0.022 | 0 / 0.022 | 0 / 0.023 |
| X_noall | 36 / 0.948 | 21 / 0.813 | 30 / 0.715 | 41 / 0.903 | 70 / 1.444 |

A run explodes when its median final half-width is ≥ 1.0 (a box at least as wide as the domain); the domain half-width is 1.0.

### Two-peak tournament: share of runs keeping the tall / broad peak, and mean share of species on the tall peak

| m = ρ_T / ρ_T,crit | ρ_T (function units) | selection-only: tall | broad | species on tall | full dynamics: tall | broad | species on tall |
|---|---|---|---|---|---|---|---|
| 0.25 | 0.148 | 1.00 | 1.00 | 0.48 | 0.31 | 0.02 | 0.22 |
| 0.354 | 0.209 | 1.00 | 1.00 | 0.37 | 0.38 | 0.04 | 0.28 |
| 0.5 | 0.295 | 1.00 | 1.00 | 0.24 | 0.40 | 0.05 | 0.26 |
| 0.707 | 0.418 | 0.99 | 1.00 | 0.14 | 0.28 | 0.08 | 0.18 |
| 1 | 0.591 | 0.94 | 0.94 | 0.11 | 0.26 | 0.18 | 0.15 |
| 1.414 | 0.835 | 0.78 | 0.87 | 0.10 | 0.19 | 0.25 | 0.09 |
| 2 | 1.182 | 0.57 | 0.79 | 0.08 | 0.11 | 0.38 | 0.03 |
| 2.83 | 1.672 | 0.45 | 0.78 | 0.05 | 0.02 | 0.48 | 0.00 |
| 4 | 2.363 | 0.03 | 0.68 | 0.01 | 0.00 | 0.55 | 0.00 |

### Two-peak landscape: DE seeded on the peaks, and in vivo runs

| Arm | tall kept | broad kept | top-64 fitness |
|---|---|---|---|
| T_DE_vitro | 0.00 | 0.99 | 0.664 (0.012) |
| V_DE | 0.83 | 1.00 | 0.701 (0.030) |
| V_IDEA_R | 0.02 | 0.46 | 0.649 (0.057) |

### Exploratory ablations (paper landscapes, fitness 0 outside): mean optima

| Arm | Rosenbrock | Beale | Himmelblau | Ackley | Rastrigin |
|---|---|---|---|---|---|
| DE | 1.00 | 1.00 | 3.64 | 3.39 | 2.49 |
| DE_sm1 | 1.00 | 0.96 | 3.23 | 3.09 | 1.56 |
| DE_N32 | 0.27 | 0.27 | 0.91 | 0.77 | 0.41 |
| IDEA_R | 0.49 | 0.45 | 1.33 | 1.78 | 1.36 |
| R_noG1 | 0.54 | 0.47 | 1.28 | 1.64 | 1.24 |
| R_noG2 | 0.45 | 0.29 | 1.11 | 1.04 | 0.59 |
| R_noG3 | 0.09 | 0.13 | 0.41 | 0.71 | 0.70 |
| R_nospec | 0.47 | 0.39 | 1.19 | 1.81 | 1.12 |
| R_abstheta | 0.46 | 0.34 | 1.18 | 1.99 | 1.30 |
| R_normK | 0.41 | 0.34 | 1.28 | 1.54 | 1.18 |
| R_fitbirth | 0.52 | 0.50 | 1.07 | 1.82 | 1.18 |
| R_within | 0.37 | 0.43 | 1.18 | 1.58 | 1.23 |
| R_gauss | 0.33 | 0.31 | 1.16 | 1.67 | 1.51 |
| R_K128 | 0.93 | 0.88 | 2.74 | 3.94 | 3.46 |
| IDEA_L | 0.30 | 0.36 | 0.89 | 1.48 | 1.14 |

### Exploratory ablations (paper landscapes, fitness 0 outside): mean top_fit

| Arm | Rosenbrock | Beale | Himmelblau | Ackley | Rastrigin |
|---|---|---|---|---|---|
| DE | 0.993 | 0.961 | 0.943 | 0.750 | 0.609 |
| DE_sm1 | 0.994 | 0.968 | 0.956 | 0.691 | 0.554 |
| DE_N32 | 0.713 | 0.625 | 0.462 | 0.360 | 0.318 |
| IDEA_R | 0.991 | 0.954 | 0.927 | 0.950 | 0.832 |
| R_noG1 | 0.990 | 0.948 | 0.928 | 0.949 | 0.850 |
| R_noG2 | 0.985 | 0.931 | 0.901 | 0.867 | 0.770 |
| R_noG3 | 0.769 | 0.755 | 0.551 | 0.641 | 0.609 |
| R_nospec | 0.991 | 0.953 | 0.909 | 0.943 | 0.824 |
| R_abstheta | 0.991 | 0.950 | 0.917 | 0.965 | 0.873 |
| R_normK | 0.991 | 0.952 | 0.921 | 0.956 | 0.832 |
| R_fitbirth | 0.993 | 0.965 | 0.946 | 0.972 | 0.874 |
| R_within | 0.989 | 0.954 | 0.901 | 0.938 | 0.821 |
| R_gauss | 0.990 | 0.949 | 0.899 | 0.943 | 0.849 |
| R_K128 | 0.993 | 0.967 | 0.952 | 0.968 | 0.897 |
| IDEA_L | 0.983 | 0.963 | 0.861 | 0.927 | 0.813 |

### Exploratory ablations (paper landscapes, fitness 0 outside): mean robust_0.2

| Arm | Rosenbrock | Beale | Himmelblau | Ackley | Rastrigin |
|---|---|---|---|---|---|
| DE | 0.942 | 0.892 | 0.791 | 0.529 | 0.374 |
| DE_sm1 | 0.952 | 0.921 | 0.826 | 0.511 | 0.339 |
| DE_N32 | 0.578 | 0.502 | 0.318 | 0.235 | 0.181 |
| IDEA_R | 0.909 | 0.847 | 0.765 | 0.765 | 0.556 |
| R_noG1 | 0.916 | 0.843 | 0.771 | 0.784 | 0.569 |
| R_noG2 | 0.924 | 0.840 | 0.729 | 0.714 | 0.506 |
| R_noG3 | 0.563 | 0.490 | 0.368 | 0.422 | 0.371 |
| R_nospec | 0.918 | 0.844 | 0.740 | 0.770 | 0.549 |
| R_abstheta | 0.902 | 0.835 | 0.756 | 0.788 | 0.587 |
| R_normK | 0.897 | 0.826 | 0.752 | 0.793 | 0.555 |
| R_fitbirth | 0.928 | 0.877 | 0.798 | 0.814 | 0.591 |
| R_within | 0.911 | 0.829 | 0.734 | 0.737 | 0.546 |
| R_gauss | 0.899 | 0.823 | 0.730 | 0.763 | 0.567 |
| R_K128 | 0.911 | 0.842 | 0.795 | 0.812 | 0.599 |
| IDEA_L | 0.844 | 0.753 | 0.656 | 0.694 | 0.539 |

### Exploratory ablations (paper landscapes, fitness 0 outside): mean viable_frac

| Arm | Rosenbrock | Beale | Himmelblau | Ackley | Rastrigin |
|---|---|---|---|---|---|
| DE | 0.869 | 0.786 | 0.579 | 0.215 | 0.115 |
| DE_sm1 | 0.925 | 0.842 | 0.680 | 0.177 | 0.079 |
| DE_N32 | 0.775 | 0.689 | 0.442 | 0.257 | 0.145 |
| IDEA_R | 0.997 | 0.970 | 0.937 | 0.962 | 0.781 |
| R_noG1 | 0.996 | 0.957 | 0.941 | 0.961 | 0.791 |
| R_noG2 | 0.990 | 0.919 | 0.932 | 0.858 | 0.681 |
| R_noG3 | 0.149 | 0.173 | 0.071 | 0.141 | 0.122 |
| R_nospec | 0.997 | 0.963 | 0.922 | 0.961 | 0.793 |
| R_abstheta | 0.998 | 0.997 | 0.985 | 0.984 | 0.965 |
| R_normK | 0.997 | 0.971 | 0.929 | 0.964 | 0.774 |
| R_fitbirth | 0.999 | 0.988 | 0.966 | 0.981 | 0.860 |
| R_within | 0.995 | 0.963 | 0.906 | 0.950 | 0.747 |
| R_gauss | 0.995 | 0.973 | 0.908 | 0.953 | 0.804 |
| R_K128 | 0.996 | 0.991 | 0.971 | 0.963 | 0.907 |
| IDEA_L | 0.985 | 0.974 | 0.838 | 0.927 | 0.741 |

### Exploratory ablations (paper landscapes, fitness 0 outside): mean basins

| Arm | Rosenbrock | Beale | Himmelblau | Ackley | Rastrigin |
|---|---|---|---|---|---|
| DE | 75.2 | 10.7 | 3.8 | 14.7 | 20.7 |
| DE_sm1 | 66.3 | 7.7 | 3.4 | 13.9 | 18.5 |
| DE_N32 | 8.7 | 3.5 | 2.0 | 3.8 | 2.8 |
| IDEA_R | 34.5 | 5.2 | 2.0 | 6.6 | 4.5 |
| R_noG1 | 48.4 | 5.3 | 1.9 | 6.0 | 4.0 |
| R_noG2 | 28.9 | 3.4 | 1.4 | 4.4 | 3.5 |
| R_noG3 | 12.5 | 5.0 | 1.7 | 4.1 | 4.6 |
| R_nospec | 36.8 | 4.9 | 2.0 | 6.3 | 4.2 |
| R_abstheta | 36.8 | 4.9 | 1.5 | 5.9 | 2.5 |
| R_normK | 36.3 | 4.8 | 2.0 | 5.8 | 4.0 |
| R_fitbirth | 34.1 | 5.1 | 1.3 | 5.6 | 3.7 |
| R_within | 37.0 | 5.0 | 2.0 | 6.1 | 4.5 |
| R_gauss | 36.5 | 4.8 | 2.0 | 6.2 | 4.4 |
| R_K128 | 78.1 | 10.0 | 3.1 | 15.4 | 10.0 |
| IDEA_L | 34.8 | 6.3 | 1.8 | 5.5 | 3.4 |

### Secondary: landscapes as coded (foobench values outside the box)

| Landscape | Arm | top-64 fitness | optima kept | outputs inside the box | species centres outside the box |
|---|---|---|---|---|---|
| Rosenbrock | DE | 0.870 (0.053) | 0.58 (0.49) | 0.193 (0.049) | - |
| Rosenbrock | IDEA-R | 0.706 (0.000) | 0.00 (0.00) | 0.000 (0.000) | 1.000 (0.000) |
| Rosenbrock | IDEA-L | 0.713 (0.022) | 0.01 (0.10) | 0.005 (0.016) | 0.995 (0.016) |
| Beale | DE | 0.961 (0.012) | 0.98 (0.14) | 0.996 (0.003) | - |
| Beale | IDEA-R | 0.788 (0.355) | 0.31 (0.46) | 0.830 (0.376) | 0.170 (0.376) |
| Beale | IDEA-L | 0.833 (0.323) | 0.29 (0.45) | 0.869 (0.336) | 0.130 (0.336) |
| Himmelblau | DE | 0.942 (0.016) | 3.59 (0.51) | 0.989 (0.005) | - |
| Himmelblau | IDEA-R | 0.697 (0.385) | 0.79 (0.64) | 0.769 (0.420) | 0.230 (0.421) |
| Himmelblau | IDEA-L | 0.859 (0.158) | 0.87 (0.63) | 0.975 (0.141) | 0.022 (0.141) |
| Ackley | DE | 0.750 (0.060) | 3.39 (0.68) | 0.988 (0.005) | - |
| Ackley | IDEA-R | 0.950 (0.064) | 1.78 (0.76) | 0.990 (0.013) | 0.004 (0.011) |
| Ackley | IDEA-L | 0.927 (0.095) | 1.48 (0.71) | 0.990 (0.018) | 0.004 (0.016) |
| Rastrigin | DE | 0.609 (0.030) | 2.49 (0.91) | 0.997 (0.003) | - |
| Rastrigin | IDEA-R | 0.832 (0.114) | 1.36 (0.88) | 0.997 (0.008) | 0.001 (0.006) |
| Rastrigin | IDEA-L | 0.813 (0.118) | 1.14 (0.69) | 0.997 (0.009) | 0.001 (0.005) |

### IDEA clades and events (means per run)

| Landscape | Arm | union non-viable | hull non-viable | union area | hull area | final half-width (f.u.) | extinctions | exclusions | speciations | births | total extinctions |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Rosenbrock | IDEA-R | 0.003 | 0.413 | 0.284 | 14.53 | 0.050 | 113.3 | 84.6 | 17.1 | 181.0 | 0.00 |
| Rosenbrock | IDEA-L | 0.016 | 0.474 | 0.263 | 13.74 | 0.050 | 118.1 | 95.7 | 0.4 | 213.4 | 0.00 |
| Beale | IDEA-R | 0.032 | 0.521 | 0.280 | 16.42 | 0.050 | 112.5 | 88.3 | 18.1 | 182.9 | 0.00 |
| Beale | IDEA-L | 0.027 | 0.511 | 0.258 | 16.63 | 0.050 | 114.3 | 95.0 | 0.4 | 208.8 | 0.00 |
| Himmelblau | IDEA-R | 0.068 | 0.636 | 0.205 | 15.70 | 0.050 | 220.7 | 163.6 | 11.7 | 372.5 | 0.00 |
| Himmelblau | IDEA-L | 0.171 | 0.603 | 0.187 | 14.43 | 0.050 | 195.2 | 151.6 | 0.8 | 345.9 | 0.00 |
| Ackley | IDEA-R | 0.043 | 0.807 | 0.208 | 38.07 | 0.050 | 167.1 | 129.8 | 42.4 | 256.0 | 0.00 |
| Ackley | IDEA-L | 0.079 | 0.702 | 0.187 | 30.34 | 0.050 | 149.2 | 122.3 | 1.6 | 270.0 | 0.00 |
| Rastrigin | IDEA-R | 0.227 | 0.881 | 0.190 | 41.20 | 0.050 | 161.2 | 126.5 | 68.3 | 235.8 | 0.00 |
| Rastrigin | IDEA-L | 0.276 | 0.830 | 0.177 | 33.64 | 0.050 | 160.6 | 119.8 | 2.3 | 278.3 | 0.00 |
| Six-hump camel | IDEA-R | 0.096 | 0.482 | 0.255 | 10.18 | 0.050 | 138.3 | 102.7 | 23.6 | 218.2 | 0.00 |
| Six-hump camel | IDEA-L | 0.361 | 0.524 | 0.231 | 14.93 | 0.050 | 131.1 | 111.4 | 1.6 | 241.0 | 0.00 |
| Shubert | IDEA-R | 0.932 | 0.894 | 0.310 | 50.63 | 0.050 | 60.2 | 49.4 | 61.1 | 67.6 | 0.00 |
| Shubert | IDEA-L | 0.908 | 0.896 | 0.278 | 54.42 | 0.050 | 70.8 | 60.9 | 3.0 | 129.1 | 0.00 |
| Vincent | IDEA-R | 0.070 | 0.670 | 0.215 | 9.87 | 0.050 | 197.8 | 144.3 | 22.3 | 319.8 | 0.00 |
| Vincent | IDEA-L | 0.218 | 0.591 | 0.195 | 6.33 | 0.050 | 184.7 | 144.9 | 2.1 | 327.6 | 0.00 |

Areas in function units squared (the box has area 64). Non-viable: g < 0.5.

### DE on the paper landscapes with fitness 0 outside: the paper's metrics (x0 estimates) vs output metrics

| Landscape | paper fitness (x0) | paper entropy | top-64 output fitness | top-64 output entropy |
|---|---|---|---|---|
| Rosenbrock | 0.994 (0.002) | 5.41 (0.16) | 0.993 (0.002) | 5.41 (0.15) |
| Beale | 0.965 (0.012) | 5.54 (0.17) | 0.961 (0.012) | 5.50 (0.18) |
| Himmelblau | 0.959 (0.014) | 5.22 (0.25) | 0.943 (0.016) | 5.17 (0.25) |
| Ackley | 0.779 (0.068) | 5.70 (0.13) | 0.750 (0.060) | 5.69 (0.14) |
| Rastrigin | 0.647 (0.036) | 5.79 (0.09) | 0.609 (0.030) | 5.78 (0.09) |
