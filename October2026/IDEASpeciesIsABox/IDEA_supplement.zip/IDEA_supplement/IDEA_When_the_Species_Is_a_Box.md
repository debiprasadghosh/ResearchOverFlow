# When the Species Is a Box: An Interval Diffusion Evolutionary Algorithm, Made Precise and Tested

**Debi Prasad Ghosh**

Debias Parametric Guru, Kolkata, India | debiprasadghosh@gmail.com

11 October 2026 · A diversion from the log interval network programme · Pre-specified protocol executed, with reproducible scripts

---

**Abstract.** Diffusion Evolution (DE) [1] evolves a population by running a diffusion sampler backwards over a fitness landscape. A sketch [26] proposed changing its unit of selection from the individual to the species. In the resulting algorithm, IDEA, a species is an axis-aligned box of tolerated genomes:

- it is ranked by the lower fitness quantile of its box;
- it is isolated from others by geometry;
- it is born by fission, and goes extinct when too much of its box is lethal;
- the union of the surviving boxes is the clade.

We make the sketch precise and state seven propositions about it, six with proofs and one computed on a grid. We then test three of its predictions and five of our own under a protocol frozen before any confirmatory run: 145 cells of 100 runs, all but a deliberately smaller DE control at DE's budget of 12,800 evaluations.

- **DE, checked.** Our port reproduces the paper's Table 3 to within 0.02 bits of entropy and 0.01 of fitness, with the noise level in its code ($\sigma_m=0.1$); the noise level in its text ($\sigma_m=1$) does not reproduce it. As coded, the paper's landscapes are flat outside their box, and 80% of DE's final population on Rosenbrock sits there.
- **Theory.**
  - Lower-quantile selection is a robust objective. Above a computable box width it prefers the flatter of two peaks, which is survival of the flattest. In high dimension it reads the bulk of a box rather than its worst part.
  - Species fitness from lives is an estimate, not a bound: certifying at 95% that 90% of a box is viable takes 29 lives.
  - The sketch's radius rule, as written, drives almost every box to its floor within three updates. The DDIM noise ratio does what the sketch describes.
  - A union of boxes is guaranteed to inherit their statistical viability when the boxes are disjoint; overlap can break it.
- **The sketch's predictions.**
  - Its central one fails. IDEA kept fewer optima than DE on Himmelblau, Ackley and Rastrigin (Himmelblau: 1.33 against 3.64 of 4), and on three held-out niching benchmarks (Shubert: 0.05 against 6.04 of 18; Vincent: 1.23 against 8.44 of 36).
  - It was worse on Rosenbrock, as predicted, but only by 0.002.
  - Removing any one of its three governors never caused interval explosion; removing all three did, in 21–70% of runs. The governors are redundant, not each necessary.
- **Our predictions.**
  - As coded, every IDEA species left Rosenbrock's box for the flat plateau, in all 100 runs.
  - From a random start, IDEA kept a tall, narrow peak in 2% of runs; DE kept it in 83%.
  - Under the literal radius rule, the median share of species at the floor after three updates was 1.00 on every landscape.
  - A tournament's transition came at 2.45 times the predicted radius, outside the predicted window (rejected). The registered design departed from the theory's model in several untested ways; an exploratory simulation of the model itself, with sampling noise, put the transition between 1 and 1.41 times.
  - IDEA's outputs were more robust than DE's on the rugged landscapes but less robust on the smooth ones (rejected).
- **What IDEA did instead** (exploratory).
  - On the paper's five landscapes, 78–100% of its outputs were viable, against 11–87% for DE.
  - On Ackley and Rastrigin its 64 best outputs were fitter: 0.95 against 0.75, and 0.83 against 0.61.
  - In an exploratory reallocation, 128 species with 4 lives each kept more optima than DE on Ackley and Rastrigin, though not on Himmelblau.

IDEA is not a better Diffusion Evolution. It asks a different question, namely where a population with standing variation can live, and answers it with a robust objective. Its natural use in the interval programme is certifying viable regions, not optimisation.

**Keywords** evolutionary algorithms; diffusion models; species selection; quasispecies; survival of the flattest; robust optimisation; niching; interval analysis; set inversion

# 1 Introduction

Zhang, Hartl, Hazan and Levin [1] showed that a population can be evolved by running a diffusion model's sampler backwards over a fitness landscape. Each individual estimates a high-fitness target as a fitness-weighted, Gaussian-weighted average of the population, and takes a DDIM step [2] towards it. Selection lives in the weights, recombination in the average, mutation in the injected noise, and reproductive isolation in the Gaussian, which narrows as the run proceeds. The resulting algorithm, Diffusion Evolution (DE), keeps several optima alive on two-dimensional benchmarks where CMA-ES settles on one.

DE is an algorithm about individuals. The sketch this paper tests [26] starts from the opposite premise: evolution is not about individual lives but about the survival of species. A species carries standing variation, so it should be represented as a set of genomes it still tolerates, an axis-aligned box. It should live or die by the part of that set that can still live, not by its best member. In the sketch's words, an interval diffusion evolutionary algorithm (IDEA) is "Diffusion Evolution in which the denoised state is a box, selection reads the lower fitness quantile of that box, gene flow is intersection, and the surviving clade is the union of the boxes that have not gone extinct." The sketch predicts three things:

- IDEA is worse than DE on a single curved valley (Rosenbrock);
- it keeps more optima than DE on Himmelblau, Ackley and Rastrigin, because its isolation is geometric rather than statistical;
- three governors (the schedule on the radius, the overlap clip and extinction) are each needed to stop "interval explosion".

The idea has deep roots in biology. Selection among species with heritable range properties is a recognised level of selection [5, 6]. Quasispecies theory shows that a population spread by mutation is selected for its mean fitness, so that a flatter, lower peak can beat a higher, sharper one [11–14]. The idea also touches interval analysis [17–19], where boxes are kept or discarded on bounds. It is a natural diversion for the log interval network programme (Paper II and P1–P3, [22–25]): there an interval was a certificate about a decision, and here it would be a population.

**What we did.**

- We checked DE's equations, defaults and benchmarks against the paper and its code, and reproduced its Table 3 (Section 2).
- We made the sketch into an algorithm, recording every reading we had to choose (Section 3).
- We proved seven propositions about it, most of them checked numerically (Section 4).
- We froze a protocol with nine decisions: the sketch's three predictions, one of them repeated on held-out landscapes, and five predictions of the theory. We then ran 145 cells of 100 runs each, on the paper's five landscapes, three held-out niching benchmarks [9] and a two-peak landscape built for the theory (Sections 5 and 6).

# 2 Diffusion Evolution, checked against its text and code

We read the paper [1] and its reference code (github.com/Zhangyanbo/diffusion-evolution, commit 41ac6ca; benchmark functions from github.com/bhartl/foobench, commit 18de5da), and ported the benchmark pipeline to NumPy. (A companion paper by the same group evolves with a trained diffusion network and conditional sampling instead [4]; we do not consider it.)

## 2.1 The algorithm

The diffusion convention is DDIM's [2]: $x_t=\sqrt{\alpha_t}x_0+\sqrt{1-\alpha_t}\,\epsilon$, with $\alpha_t$ falling from $\alpha_0\approx1$ to $\alpha_T\approx0$. Evolution runs the denoising direction, $t=T,\dots,1$. Fitness $f$ is mapped to a density weight $Q_j=g[f(x^{(j)})]$. Each individual $i$ estimates a target and takes a DDIM step:

$$\hat x_0^{(i)}=\frac1{Z_i}\sum_jQ_j\,\mathcal N\big(x^{(i)}_t;\sqrt{\alpha_t}\,x^{(j)}_t,\,1-\alpha_t\big)\,x^{(j)}_t \qquad\text{(paper Eq. 8)}$$

$$x^{(i)}_{t-1}=\sqrt{\alpha_{t-1}}\,\hat x_0^{(i)}+\sqrt{1-\alpha_{t-1}-\sigma_t^2}\;\hat\epsilon^{(i)}+\sigma_tw,\qquad \hat\epsilon^{(i)}=\frac{x^{(i)}_t-\sqrt{\alpha_t}\,\hat x^{(i)}_0}{\sqrt{1-\alpha_t}} \qquad\text{(Eqs. 5, 10)}$$

with $\sigma_t=\sigma_m\sqrt{(1-\alpha_{t-1})/(1-\alpha_t)}\sqrt{1-\alpha_t/\alpha_{t-1}}$ (Eq. 17). The paper reads the weights as selection, the average as recombination, $\sigma_tw$ as mutation, and the shrinking Gaussian as reproductive isolation. The sketch states Eqs. 8 and 5 correctly.

## 2.2 What the code adds

The benchmark code fixes several things the text leaves open, and differs from it in one place.

- **Schedule and budget.** The cosine schedule [3] is rescaled to $\alpha\in[0.000998,\,0.999]$, with 25 steps (24 updates) and a population of 512. That is 12,288 evaluations during the run, 12,800 with the final population.
- **Noise.** The benchmark calls the generator with $\sigma_m=0.1$. Appendix A.2 says $\sigma_m=1$ "for most experiments, except for the experiment demonstrating the process in Figure 2".
- **Kernel and floors.** The Gaussian is unnormalised, which is harmless because its variance is common to all $j$. Every factor carries a floor, $(Q_j+10^{-9})(K_{ij}+10^{-9})$, so every individual always receives some weight from every other: isolation is never exact.
- **Fitness map.** The map is Eq. 19 at $T=1$, with per-landscape targets and scales. Rosenbrock, Beale and Himmelblau are minimised. Ackley and Rastrigin are *maximised* over the box $(-4,4)^2$ (App. A.4), so each has four global optima near the corners: $(\pm3.614,\pm3.614)$ for Ackley and $(\pm3.518,\pm3.518)$ for Rastrigin, 0.39 and 0.48 function units inside the edge. The population lives in coordinates $x\sim\mathcal N(0,I)$ and the landscape is evaluated at $4x$.
- **Outside the box.** foobench assigns limit values there unconditionally (the call tests the module's `apply_limits` function, which is always true, instead of the object's `apply_limits` flag). For the minimised landscapes the limit is $f=100$, which maps to $g=0.706$ (Rosenbrock), 0.0067 (Beale) and 0.0028 (Himmelblau); Ackley and Rastrigin get $g=0$. On Rosenbrock the outside is fitter than most of the inside, because $f>100$ wherever $|y-x^2|>1$.
- **The reported fitness.** The code that computes the paper's Table 1 (`statistic.py`) scores Diffusion Evolution by the mean fitness of the 64 best *target estimates* $\hat x_0$ at the last step, and its entropy on the final individuals whose targets rank in those 64. CMA-ES, OpenES, PEPG and MAP-Elite are scored on their populations; Latent Diffusion Evolution, like DE, on its target estimates.

## 2.3 Reproduction

With $\sigma_m=0.1$ our port reproduces the Diffusion Evolution column of the paper's Table 3 (100 runs per landscape; Table R in `report/tables.md`). Every entropy is within 0.02 bits of the paper's value and every fitness within 0.01. With $\sigma_m=1$, the value the text gives, Ackley falls to 0.705 against 0.78 and Rastrigin to 0.581 against 0.64: misses of 0.075 and 0.059, against at most 0.01 with $\sigma_m=0.1$. The table was produced with $\sigma_m=0.1$, and we use that value throughout.

One more fact explains a later result. On Rosenbrock as coded, 80% of the final population lies outside the box, on the 0.706 plateau. The table does not show it: in our confirmatory runs on the coded landscape, 84% of the 64 fittest target estimates, the ones the table reports, lie inside the box, although only 18% of all target estimates do.

Two small points of the text. Appendix A.3's change of variable holds with the factor $\alpha^{-D/2}$; the stated $1/\sqrt{\alpha}$ is the case $D=1$ (T1e). The update is also not stationary for an individual that has no neighbours (Proposition 1).

# 3 IDEA made precise

## 3.1 The algorithm

A species is a box $B_k=\prod_d[c_{k,d}-\rho_{k,d},\,c_{k,d}+\rho_{k,d}]$. A life is a point drawn uniformly from it. There are $K=32$ species and $n=16$ lives per species per generation, so a generation costs $Kn=512$ evaluations, as in Diffusion Evolution. One generation of IDEA, on the schedule of Section 2:

1. **Evaluate.** Draw $n$ lives in each box. The species fitness $F_k$ is the empirical $q$-quantile of their fitness $g$: the $k$-th smallest, $k=\lceil qn\rceil=2$ for $q=0.1$. Set $Q_k=F_k$. When clipping or splitting later removes lives from a box, $F$ is recomputed from the $n'$ that remain, with $k=\lceil qn'\rceil$; a box left with none keeps its $F$.
2. **Extinction** (governor 3). Species with $F_k<\theta_t=\theta\,\alpha_t\max_jF_j$ die, with $\theta=0.5$. If none would survive, the fittest does.
3. **Exclusion** (governor 2). Visit species in order of decreasing $F$. A box that overlaps a fitter box already kept loses: its face on the coordinate of least penetration is clipped to the winner's face. A loser that would become narrower than $\rho_{\min}$ is excluded. Lives outside clipped boxes are dropped, and $F$ is recomputed.
4. **Speciation.** Take the elite lives of a box (fitness at least the box median; at least 4 lives and 2 elite lives are needed). If they leave a gap wider than half the box along some coordinate, the box splits at the middle of the widest such gap, provided both halves are at least $\rho_{\min}$ wide; the parent dies.
5. **Cap and birth.** Above $K$ species, the fittest $K$ are kept. Below $K$, a uniformly chosen living box splits at its centre along its widest coordinate (fission). A child narrower than $\rho_{\min}$ is widened back to $\rho_{\min}$ about its own centre, so the two children of a box at the floor overlap and meet again at the next exclusion.
6. **Denoise.** Set weights $W_{ij}\propto Q_j\,K_{ij}\,\mathrm{flow}_{ij}$, with
$$K_{ij}=\exp\Big(-\sum_d\frac{(c_{id}-\sqrt{\alpha_t}\,c_{jd})^2}{2(1-\alpha_t)(\rho_{id}+\rho_{jd})^2}\Big),\qquad \mathrm{flow}_{ij}=\mathbf 1\{\mathrm{gap}(B_i,B_j)<r_t\},\quad r_t=\sqrt{(1-\alpha_t)/\alpha_t}.$$
Set $\hat c_i=\sum_jW_{ij}c_j$ and $\hat\rho_i=\sum_jW_{ij}\rho_j$; a species with no positive weight uses its own centre and radius. Centres take the DDIM step of Eq. 5 towards $\hat c$, with Eq. 17's noise. Radii update as
$$\rho_{t-1}=\mathrm{clip}\big(s_t\,\hat\rho+\sigma_t\,\hat\rho\,|\xi|,\ \rho_{\min},\ \rho_{\max}\big),\qquad \xi\sim\mathcal N(0,I),$$
with $s_t=\sqrt{(1-\alpha_{t-1})/(1-\alpha_t)}$ (**IDEA-R**, repaired) or $s_t=\sqrt{\alpha_{t-1}}$ (**IDEA-L**, literal). Removing governor 1 sets $s_t=1$.
7. **Output.** After the last update, evaluate once more. The output is the final $Kn=512$ lives.

Initial centres are drawn from $\mathcal N(0,I)$ in population coordinates, like DE's population, so many initial boxes overhang the box edge. The defaults are $\rho_{\min}=0.0125$ (0.05 function units), $\rho_{\max}=1$ (the half-width of the domain), and an initial half-width $\rho_T=\rho_{\min}/\prod_ts_t=0.395$ (1.58 function units), at which the repaired schedule alone ends on $\rho_{\min}$ (Proposition 3).

## 3.2 Where the sketch needed a reading

The sketch fixes the architecture: boxes, a lower-quantile species fitness, extinction, birth by fission, a gated and widened kernel, a denoised radius, exclusion instead of hulls, speciation, radius mutation, and the union as the clade. It leaves several quantities open, and in two places it says something other than what it means. We list every choice. Those marked † were made after pilots on the paper's landscapes, and the protocol records them.

- **Species fitness.** The sketch's $F(\mathcal B)=\mathrm{Quantile}_q\{f(x)\}$ is estimated from the $n$ lives, and $Q_k=g[F]$ equals the quantile of $g$, because $g$ increases with fitness (Proposition 2a). Where the code expresses a landscape as a loss, this is the upper quantile of the loss.
- **Extinction threshold.**† The sketch's $\theta$ is unspecified. In a Himmelblau pilot, an absolute threshold extinguished all 32 species in the first generation, so the whole population descended from one founder; and the level at which an absolute threshold bites differs from landscape to landscape. We use $\theta_t=\theta\,\alpha_t\max_jF_j$: a threshold relative to the fittest species, which tightens on the diffusion schedule.
- **Birth.**† "Fission of a living box": a uniformly chosen survivor splits at its centre. A fitness-proportional choice is an ablation.
- **Speciation.** "Split along the widest fitness valley" becomes the widest gap among the elite lives, with a threshold of half the box width.
- **Exclusion.** "Push $c_i$ off $c_j$ in proportion to the overlap volume and clip the losing face" becomes the clip alone. It moves the loser's face by the least penetration depth (which does not always remove the least volume), and so moves the loser's centre by half that depth.
- **Gate.** The shrinking margin $\epsilon_t$ is the paper's own neighbourhood radius $r_t=\sqrt{(1-\alpha_t)/\alpha_t}$ (App. A.3). The sketch's first condition, positive intersection volume, implies the second (a gap of zero), so it is redundant (Proposition 6a).
- **Kernel.** We keep the reference code's unnormalised Gaussian. Read as a normalised density, the sketch's kernel would add a weight $\prod_d(\rho_{id}+\rho_{jd})^{-1}$ favouring narrow donors (Proposition 6d); that reading is an ablation.
- **Denoised radius.** The sketch does not define $\hat\rho$. By analogy with $\hat c$ we use the weighted mean, which cannot exceed the widest neighbour (Proposition 6e); the radius mutation can still inflate it. The moment-matched radius, the "union-style growth" of the sketch's failure mode, is used only in the explosion test.
- **Radius coefficient.** The sketch writes $\sqrt{\alpha_{t-1}}$ and describes fat early boxes that tighten late. The coefficient does the opposite (Proposition 3a). IDEA-L keeps the coefficient as written; IDEA-R uses the noise ratio, which does what the sketch describes.
- **Radius mutation.**† The sketch says the noise "inflates $\rho$ slightly", so $\xi$ is half-normal, with scale $\sigma_t\hat\rho$. A symmetric version is an ablation.
- **Interval bound.** The sketch calls extinction on an interval lower bound $\underline f<\theta$ equivalent to the quantile rule. It is not (Proposition 5c). We use the quantile.
- **Outside the box.**† As coded, the paper's landscapes are flat outside the box. In pilots IDEA's species left the box for these plateaus (Proposition 7). Our comparisons therefore set fitness to 0 outside, for both algorithms, and report the landscapes as coded separately.

Nothing in IDEA's centre update moves a species towards its own fittest lives: the centre moves only through other species' centres (Proposition 1). Speciation followed by extinction can do so for a lineage. Using each species' fitness-weighted mean life in $\hat c$ is an ablation (`R_within`).

# 4 Theory

Most statements below are checked numerically by the frozen `verify_idea_theory.py` (32 checks, T1–T17, all pass; output in the supplement). Proposition 2(c) rests on Anderson's theorem and has no check of its own; Proposition 3(c)'s expectation is computed, not simulated; Proposition 7 is a grid computation. Checks A1–A11 (`verify_idea_addendum.py`) were added after the independent review, and correct one frozen check (T8c, by A1) and the statement of Proposition 2(a) (A5). Coordinates are function units (f.u.) unless marked "pop" (population units; one population unit is four function units).

## 4.1 Diffusion Evolution away from its neighbours

**Proposition 1 (an isolated individual drifts).** Suppose an individual's only weight in Eq. 8 is its own, so that $\hat x_0 = x_t$. Then Eq. 5 gives $x_{t-1} = m_t\,x_t + \sigma_t w$ with

$$m_t=\sqrt{\alpha_{t-1}}+\sqrt{1-\alpha_{t-1}-\sigma_t^2}\;\frac{1-\sqrt{\alpha_t}}{\sqrt{1-\alpha_t}} .$$

With $\sigma_t=0$ and $\alpha_{t-1}<1$, $m_t\ge1$, with equality only when $\alpha_{t-1}=\alpha_t$.

*Proof.* Write $a=\sqrt{\alpha_t}<b=\sqrt{\alpha_{t-1}}$ and $c^2=(1-a)/(1+a)$, so that $m=b+c\sqrt{1-b^2}$. For $b<1$, $m\ge1$ holds if and only if $c^2(1-b^2)\ge(1-b)^2$, that is $c^2(1+b)\ge1-b$, that is $b\ge(1-c^2)/(1+c^2)=a$. ∎

On the benchmark schedule with $\sigma_m=0.1$ every $m_t$ is at least 1, and their product over the 24 updates is 1.848; with $\sigma_m=1$ it is 0.138 (T11a). An individual, or a species, that nothing else pulls is carried 85% further from the origin by the end of the run. Two consequences matter for IDEA.

- **Isolation is not a resting state.** A species whose gate has closed does not sit on its niche; it moves along $m_t c$.
- **There is no within-species selection.** The sketch denoises a centre from the centres of other species. A species with no partner therefore moves to $m_t c$ plus noise whatever its own lives look like (T11b): nothing pulls it towards its fittest members.

## 4.2 What the lower quantile selects

Write $F_q(B)$ for the $q$-quantile of $g(u)$ with $u$ uniform on a box $B$, and $\hat F$ for its estimate from $n$ lives.

**Proposition 2 (species fitness).**

- **(a) The fitness map does not change the ranking.** For every nondecreasing $\varphi$, the estimate satisfies $\hat F(\varphi\circ g)=\varphi(\hat F(g))$ (T2); the population quantile does when $\varphi$ is also left-continuous (A5 gives a right-continuous counterexample). The density map $g$ therefore changes the selection weights but not the ranking of species. Extinction decisions change unless the threshold is transformed with it, and for the relative threshold $\theta\alpha_t\max F$ that requires $\varphi$ to be positively homogeneous.
- **(b) Inclusion.** For $q=0$ (the essential infimum), $B\subseteq B'$ implies $F_0(B')\le F_0(B)$ (T3a). For $q>0$ this fails: a box $[-0.5,0.5]^2$ with 80% of its area in a pit has 10th percentile 0, and a box containing it with 8% of its area in the pit has 10th percentile 1 (T3b).
- **(c) Centring.** If $g$ is symmetric about $a$ with convex superlevel sets, then among translates of a symmetric box, every quantile is largest for the box centred on $a$.
- **(d) Survival of the flattest.** Let $g(u)=\max\big(h_1e^{-|u-a|^2/2w_1^2},\,h_2e^{-|u-b|^2/2w_2^2}\big)$ with $h_1>h_2$ and $w_1<w_2$, and let a box of half-width $\rho$ centred on a peak see only that peak. Then
$$F_q=h_k\exp\!\big(-\kappa_q^2\rho^2/2w_k^2\big),$$
where $\kappa_q$ is the $(1-q)$-quantile of $|U|$ for $U$ uniform on $[-1,1]^D$. The low, broad peak holds the fitter species exactly when
$$\rho>\rho^*=\frac1{\kappa_q}\sqrt{\frac{2\ln(h_1/h_2)}{w_1^{-2}-w_2^{-2}}}.$$
A species on peak $k$ clears an absolute threshold $\theta$ while $\rho\le\rho_{v,k}=(w_k/\kappa_q)\sqrt{2\ln(h_k/\theta)}$.
- **(e) High dimension.** For a separable landscape with $D$ independent terms, the gap between a box's lower quantile and its mean grows like $\sqrt D$, while the gap between the mean and the worst point grows like $D$. The quantile then reads the bulk of the box, not its worst part.

*Proof.* (a) A nondecreasing map preserves the order of a sample; for the population quantile $\inf\{s:G(s)\ge q\}$, left-continuity is the standard condition for generalised inverses to commute with $\varphi$. (b) The infimum over a larger set is no larger; the counterexample is computed in T3b. (c) $P(g(u)\ge s)$ for $u$ uniform on $c+B$ equals $\mathrm{vol}((c+B)\cap L_s)/\mathrm{vol}(B)$, where $L_s=\{g\ge s\}$ is convex and symmetric about $a$. Anderson's theorem [15] makes this largest at $c=a$ for every $s$, so every quantile is largest there. (d) For a centred box, $g(u)\ge s$ is the disc $|u-a|\le r_s$, and the share of the box outside the disc is $q$ exactly when $r_s=\kappa_q\rho$. Solve $F_{q,1}=F_{q,2}$ and $F_{q,k}=\theta$. (e) follows from the central limit theorem: the terms have mean $D\mu$ and standard deviation $\sqrt D s$, so the quantile sits about $z_q\sqrt D s$ from the mean, while the worst point sits $D(\mu-h_{\min})$ from it. ∎

**Numbers.** For $D=2$: $\kappa_0=\sqrt2$ and $\kappa_{0.1}=1.1150$ (T4). For the two-peak landscape of Section 5 ($h_1=1$, $w_1=0.4$; $h_2=0.7$, $w_2=1.2$; $q=0.1$), $\rho^*=0.321$ f.u. Below it the tall peak's centred species is fitter (at $\rho=0.257$: 0.774 against 0.680); above it the broad peak's is (at $\rho=0.402$: 0.534 against 0.653) (T5). The viability radii at $\theta=0.5$ are 0.42 f.u. (tall) and 0.88 f.u. (broad). For (e), the ratio (quantile − mean)/(worst − mean) is 0.70, 0.33, 0.16 and 0.08 at $D$ = 2, 8, 32 and 128 (T14).

So "the part of the box that can still live" is a robust objective, not a better estimate of the peak. It prefers the flatter of two peaks once boxes are wider than $\rho^*$, which is what quasispecies theory calls survival of the flattest [11–13]. In high dimension it sits close to the box's mean, measured against the worst point. On the paper's 32- and 256-dimensional Rastrigin it would read the bulk of a species, not the worst-case part the sketch intends, although boxes with equal means are still ranked by their spread.

## 4.3 The radius rule

**Proposition 3 (radius schedule).**

- **(a) As written, the radius collapses at once.** The sketch's update $\rho_{t-1}=\sqrt{\alpha_{t-1}}\,\hat\rho+\dots$ multiplies the radius by $\sqrt{\alpha_{t-1}}$, which is smallest when the run starts. On the benchmark schedule the first factor is 0.0726, and the product over the run is $6.8\times10^{-7}$ (T8a). Without mutation, three updates leave 0.0019 of the initial radius. With the paper's half-normal mutation, 0%, 45% and 99.9% of species sit at $\rho_{\min}$ in both coordinates after one, two and three updates (A1; the frozen check T8c used a symmetric mutation and reported 32%, 91% and 100%). The coefficient contracts hardest at the start of the run and hardly at all at the end, the reverse of what the sketch describes.
- **(b) The coefficient that does what the sketch describes is the noise ratio.** With $s_t=\sqrt{(1-\alpha_{t-1})/(1-\alpha_t)}$, the coefficient that DDIM applies to its noise term, the product telescopes:
$$\prod_t s_t=\sqrt{\frac{1-\alpha_0}{1-\alpha_T}}=0.0316 .$$
Without selection and mutation, $\rho_t=\rho_T\sqrt{(1-\alpha_t)/(1-\alpha_T)}$: tolerance proportional to the diffusion's noise level, fat early and tight late. Choosing $\rho_T=\rho_{\min}/\prod_t s_t$ (1.58 f.u. for $\rho_{\min}=0.05$ f.u.) makes the schedule alone land on $\rho_{\min}$ (T8b).
- **(c) The inflating mutation roughly doubles it.** With $\xi$ half-normal and ignoring the clip, $E[\rho_{t-1}]=\hat\rho\,(s_t+\sigma_t\sqrt{2/\pi})$. Over the run, $\prod_t(s_t+\sigma_t\sqrt{2/\pi})=0.066$, 2.1 times the schedule's 0.032 (from T13's quantities).

*Proof.* (a) and (c) are direct products. In (b) consecutive factors cancel. ∎

## 4.4 The tournament prediction

Seed 16 species on each peak of the two-peak landscape with half-width $\rho_T$, freeze the centres, and let only species selection act. Under the relative threshold $\theta_t=\theta\,\alpha_t\max_kF_k$ the broad lineage never dies, because $F_{\text{broad}}/F_{\text{tall}}\ge h_2/h_1=0.7>\theta$. The tall lineage dies at the first generation in which $F_{\text{tall}}/F_{\text{broad}}<\theta\alpha_t$. By Proposition 2(d), that is when its radius exceeds

$$b_t=\sqrt{\frac{2\ln\!\big(h_1/(h_2\,\theta\,\alpha_t)\big)}{\kappa_q^2\,(w_1^{-2}-w_2^{-2})}} .$$

**Proposition 4 (critical initial radius).** If radii follow the expected trajectory of Proposition 3(c), and the quantiles are exact, the tall lineage survives the run if and only if

$$\rho_T\le\rho_{T,\mathrm{crit}}=\min_t\frac{b_t}{\prod_{s\text{ before }t}\big(s_s+\sigma_s\sqrt{2/\pi}\big)}=0.591\ \text{f.u.},$$

with the minimum at generation 12, counting from 0, where $\alpha_t=0.5$ and $b_t=0.71$ f.u. (T13). The prediction ignores three things the algorithm does: estimation noise in $\hat F$, selection among radii through $\hat\rho$, and the halving of boxes by speciation and fission. All three were left out on purpose. The registered tournament (Section 5) also departs from the model in its seeding: its 16 seeds per peak are identical boxes, so for $m\le2$ exclusion leaves one per peak after the first generation and fission refills the slots with halves (A6). For $m\ge2.83$ the seeded boxes overhang the lethal edge, which Proposition 2(d) excludes. Section 6.2 reports both the registered test and an exploratory tournament built to match the model.

## 4.5 An estimate is not a bound

**Proposition 5 (species fitness from $n$ lives).**

- **(a) The estimate.** Let $G$ be the continuous distribution function of $g(u)$ on the box, and let $\hat F$ be the $k$-th smallest of $n$ independent lives. Then $P(G(\hat F)\le q)=P(\mathrm{Bin}(n,q)\ge k)$ and $E[G(\hat F)]=k/(n+1)$. For $n=16$, $k=2$ and $q=0.1$ these are 0.485 and 0.118 (T6a, T6b). About half the time, a species looks fitter than its true 10th percentile.
- **(b) A certificate.** If all $n$ lives clear $\theta$, the share of the box below $\theta$ is less than $q$ with confidence $1-(1-q)^n$. That is 0.815 for $n=16$, and 95% needs $n\ge29$ (T6c).
- **(c) Interval bounds are not quantiles.** For any inclusion function, the interval lower bound satisfies $\underline g(B)\le\min_Bg\le F_q(B)$. On Himmelblau with the natural interval extension, the bound was strictly below the minimum on 306 of 400 random boxes, and an extinction test at $\theta=0.5$ decided differently on 10 of them (T7).

*Proof.* (a) $G(\hat F)$ is the $k$-th order statistic of $n$ uniforms [16]. (b) If the share below $\theta$ were at least $q$, all $n$ lives would clear $\theta$ with probability at most $(1-q)^n$. (c) An inclusion function encloses the range of $g$ on $B$. ∎

The sketch's "equivalently, keep the fitness interval and declare extinction when $\underline f<\theta$" therefore names two different rules. The quantile is a noisy statistical statement about most of the box. The interval bound is a sound statement about all of it, and it is loosened by the dependency problem of interval arithmetic [17]. The bound kills a superset of the species the exact minimum kills, and the minimum a superset of those the quantile kills.

## 4.6 Gate, exclusion and the clade

**Proposition 6 (geometry).**

- **(a) The gate's first condition is redundant.** If $\mathrm{vol}(B_i\cap B_j)>0$ then $\mathrm{gap}(B_i,B_j)=0$, so for $\epsilon_t>0$, $\mathrm{flow}(i,j)=\mathbf 1\{\mathrm{gap}<\epsilon_t\}$ (T10a).
- **(b) Exclusion leaves disjoint interiors.** Visiting species in order of decreasing $F$, and clipping each loser to the winners it overlaps, leaves no two survivors with a positive-volume overlap (T10b: 200 × 40 random boxes; largest penetration $2.2\times10^{-16}$, rounding).
- **(c) Disjoint boxes pass their guarantee to the union.** If the boxes have disjoint interiors, the non-viable share of their union equals the volume-weighted mean of the boxes' shares. So if every box has at most a share $q$ below $\theta$, so does the clade (T15b). If boxes overlap, the union can be less viable than every box: $B_1=[0,2]$, $B_2=[1,3]$ and viable set $[1,2]$ give shares $\tfrac12,\tfrac12$ and $\tfrac23$ for the union (T15a). In our runs the final boxes overlapped (Section 6.3), so the measured clade is not covered by this guarantee.
- **(d) A normalised kernel adds a hidden selection on width.** Read as a normalised density, $\mathcal N(c_i;\sqrt{\alpha_t}c_j,(1-\alpha_t)(\rho_i+\rho_j)^2)$ carries the factor $\prod_d(\rho_{id}+\rho_{jd})^{-1}$. Through that factor alone, a donor $j$ half as wide as a donor $k$ (with $\rho_i=\rho_j=\rho_k/2$) gets $((\rho_i+\rho_k)/(\rho_i+\rho_j))^D=1.5^D$ times the weight: 2.25 in two dimensions, $1.6\times10^{10}$ in 58 (T12). The exponent also depends on the widths, so at a positive distance the net effect differs. In the paper's DE the variance is common and the factor cancels.
- **(e) The mean radius estimate cannot grow; the moment-matched one can.** The weighted mean $\hat\rho=\sum_jw_{ij}\rho_j$ lies between the smallest and largest neighbour radius (T9a). The moment-matched radius, that of the uniform box with the second moment of the weighted mixture of neighbour boxes, is at least $\sqrt{\sum_jw_{ij}\rho_j^2}$. When centres are spread it exceeds every neighbour's radius, with a median ratio of 4.23 to the largest in random configurations (T9b). The half-normal radius mutation is a growth term of its own: with $s_t=1$ it multiplies the radius by 2.0 over the run in expectation.

*Proof.* (a) A positive-volume overlap separates the boxes by zero in every coordinate. (b) Each clip moves one face of the loser onto a face of a winner and only ever shrinks the loser, so the loser no longer overlaps that winner, nor any earlier one. (c) With disjoint interiors, $\mathrm{vol}(C\setminus V)=\sum_k\mathrm{vol}(B_k\setminus V)$ and $\mathrm{vol}(C)=\sum_k\mathrm{vol}(B_k)$. (d) The normalising constant of a Gaussian with standard deviation $\sigma$ is $\propto\sigma^{-1}$ per coordinate. (e) A weighted mean lies within its range, and a mixture's second moment is at least the weighted mean of the components' second moments. ∎

## 4.7 The paper's landscapes are flat outside the box

As coded, a point outside the box gets the limit value $f=100$. That is fitness 0.706 on Rosenbrock, 0.0067 on Beale and 0.0028 on Himmelblau, the same everywhere. A box lying wholly outside has $F_q$ equal to that plateau; it is the flattest place on the landscape.

**Proposition 7 (flight to flatness).** At the initial half-width $\rho_T=1.58$ f.u.:

- **Rosenbrock.** The plateau beats every box that fits inside $(-4,4)^2$; the best inside box reaches 0.228. Inside boxes fall below the plateau once $\rho$ exceeds 0.91 f.u.
- **Himmelblau.** 98.8% of inside positions are below the plateau.
- **Beale.** 80.5% of inside positions are below the plateau (T16).

On Rosenbrock, a selection rule that reads the lower quantile of fat boxes must therefore prefer the plateau outside the box to any box inside it; on Himmelblau and Beale it prefers the plateau to most inside positions. The plateau also beats most single points: 88% of Rosenbrock's box has $g$ below it (A10), which is why DE's population, too, ends there. We test the flight (H6). Our main comparisons use landscapes with fitness 0 outside the box.

# 5 Protocol

The protocol (`PROTOCOL.md`) was frozen, with the library, run script, evaluator and theory checks, at 10:43 UTC on 6 October 2026. That was before any confirmatory run, and before any algorithm had run on the held-out landscapes. The hashes are in `evals_code_sha256.txt`. The evaluator applies the decision rules itself.

**Landscapes.**

- **The paper's five**, with fitness 0 outside the box (*lethal*; primary). The same five as coded, with foobench's plateaus outside, are secondary.
- **Three held-out landscapes:** the 2-D six-hump camel back, Shubert and Vincent functions of the CEC 2013 niching benchmark [9], with 2, 18 and 36 global optima. Each is mapped onto the same box and given Eq. 19's form, with a scale chosen so that 10% of the box has $g\ge0.5$ (the paper's five range from 7.9% to 18.2%).
- **A two-peak landscape** for the tournament: a tall, narrow peak ($h_1=1$, $w_1=0.4$ at $(2,2)$) and a low, broad one ($h_2=0.7$, $w_2=1.2$ at $(-2,-2)$).

**Arms.**

- **Primary:** DE (Diffusion Evolution, $N=512$), IDEA-R and IDEA-L.
- **Ablations (exploratory):**
  - DE with $\sigma_m=1$, and DE with $N=32$;
  - IDEA-R without each governor, without speciation, with an absolute threshold, with the normalised kernel, with fitness-proportional birth, with within-species centres, with symmetric radius mutation, and with $K=128$, $n=4$.
- **Explosion arms:** the moment-matched radius with no $\rho_{\max}$, with all three governors, with each removed, and with none.
- **Two-peak:**
  - the registered tournament: 16 identical boxes seeded on each peak, with the DDIM update of centres switched off (exclusion, speciation and fission still act, and still move centres), initial half-width $\rho_T=m\,\rho_{T,\mathrm{crit}}$ for nine values of $m$ from 0.25 to 4;
  - the same with full dynamics;
  - DE seeded on the peaks;
  - random-start runs of DE and IDEA-R.

Every cell has 100 runs. Run $i$ uses seed $100000+i$. Every arm has the same budget of 12,800 evaluations, except DE with $N=32$, a deliberately smaller control at 800.

**Metrics** are computed on each output set, in function coordinates; an output is viable if $g\ge0.5$.

- **Quality:** the mean $g$ of the 64 fittest outputs (the paper's fitness, applied to outputs).
- **Optima kept:** the number of global optima with a viable output within $\delta_L$. $\delta_L$ is 0.25, or half the smallest distance between two optima if that is smaller (Shubert 0.18, Vincent 0.12).
- **Diversity:** the number of steepest-ascent basins holding a viable output, and the paper's entropy.
- **Robustness:** for each of the 64 fittest outputs, the 10th percentile of $g$ over a box of half-width 0.2 around it, averaged.
- **Clade:** the non-viable share of the union of IDEA's final boxes and of their bounding box.

Differences between arms carry 95% bootstrap intervals (10,000 resamples).

**Hypotheses.** H1–H3 are the sketch's predictions; H4–H7 are ours, derived from Section 4 (Table 1).

**Table 1. Registered hypotheses and decision rules.**

| | Prediction | Decision rule |
|---|---|---|
| H1 | Rosenbrock: IDEA-R's quality is below DE's | interval of the difference below 0 |
| H2 | Himmelblau, Ackley, Rastrigin: IDEA-R keeps more optima than DE | interval above 0 on all three (rejected if below 0 on any); H2-H: the same on the held-out landscapes |
| H3 | Removing any one governor makes the population explode | a run explodes if its median final half-width is ≥ 1 (a box as wide as the domain); an arm explodes if ≥ 50 of 100 runs do. H3a: the full arm never explodes; H3b: each single removal explodes on every landscape |
| H4a | Selection reads the lower quantile | tournament: share of runs keeping the tall peak ≥ 0.8 for $m\le0.5$, ≤ 0.2 for $m\ge2$, and crossing 0.5 within $m\in[0.5,2]$ |
| H4b | From a random start, IDEA loses the narrow peak and DE keeps it | IDEA-R keeps it in ≤ 20% of runs, DE in ≥ 80% |
| H5 | IDEA-R's outputs are more robust than DE's | robustness interval above 0 on all five paper landscapes |
| H6 | As coded, IDEA-R's species leave Rosenbrock's box | median share of species centres outside ≥ 0.5 |
| H7 | IDEA-L's radii collapse at once | median share of species at $\rho_{\min}$ after three updates ≥ 0.9 on all five |

**Pilots** ran before freezing, on the paper's landscapes and the two-peak landscape only, with seeds outside the confirmatory range (Appendix C). They led to the choices marked † in Section 3.2, to the tolerance in the overlap test, and to freezing the centres in the H4a tournament (with free centres, seeded species drift off their peaks; Proposition 1). One pilot matters for reading H4a. With 20 seeds it put the crossing near $m=2.2$, outside the predicted window. The prediction and its window had been chosen before that pilot was run, and were kept. The pipeline smoke test (two pilot seeds per cell, run before freezing) also produced decision outputs, which agreed with the final verdicts for H2 and H3–H7 (H1 was inconclusive on two seeds; H2-H was not run). No decision rule changed after it. H6 was formulated after pilots had shown the flight. The verdicts on H4b, H6 and H7 were therefore not blind.

# 6 Results

All 145 cells ran with the frozen code; every cell records the hashes of the library and run script, and all match. The decisions below are the evaluator's (`evals/decisions.json`; Table 2). Means are over 100 runs; intervals are 95% bootstrap intervals for differences of means.

**Table 2. Decisions.**

| | Prediction | Outcome | Decision |
|---|---|---|---|
| H1 | Rosenbrock: IDEA-R below DE in quality | 0.991 vs 0.993; −0.002 [−0.004, −0.001] | supported |
| H2 | More optima kept on Himmelblau, Ackley, Rastrigin | fewer on all three (Table 3) | rejected |
| H2-H | The same on the held-out landscapes | fewer on all three | rejected |
| H3 | Removing any one governor explodes | no single removal exploded on any landscape; removing all three exploded 21–70 runs of 100 (at arm level only on Rastrigin) | rejected |
| H4a | Tournament: transition near $\rho_{T,\mathrm{crit}}$ | (i) holds; (ii) and (iii) fail: crossing at $m=2.45$ | rejected |
| H4b | Random start: IDEA loses the narrow peak, DE keeps it | IDEA-R 2% of runs, DE 83% | supported |
| H5 | IDEA-R more robust on all five | more robust on Ackley and Rastrigin, less on the other three | rejected |
| H6 | Coded Rosenbrock: species leave the box | all species outside in all 100 runs | supported |
| H7 | IDEA-L at $\rho_{\min}$ after three updates | median share 1.00 on all five | supported |

## 6.1 The sketch's predictions

**H1 (supported, by a small margin).** On Rosenbrock the mean fitness of IDEA-R's 64 best outputs was 0.991, against 0.993 for DE. The difference is small but its interval excludes zero. A larger gap shows in the optimum itself: IDEA-R put a viable output within 0.25 of $(1,1)$ in 49 runs of 100, and DE in all 100.

**H2 (rejected, everywhere).** Table 3 lists the optima kept. IDEA-R kept fewer optima than DE on every multi-optimum landscape, by 1.1 to 2.3 optima of 4 on the paper's three and by 1.2, 6.0 and 7.2 on the held-out ones. It never kept all four optima of Himmelblau or Ackley (DE did so in 65 and 50 runs of 100), and kept all four of Rastrigin once (DE 13 times). IDEA-L kept fewer still, except on Shubert.

**Table 3. Global optima kept** (mean (sd) over 100 runs; a viable output within $\delta_L$ of the optimum).

| Landscape (optima) | DE | IDEA-R | IDEA-L | IDEA-R − DE |
|---|---|---|---|---|
| Rosenbrock (1) | 1.00 (0.00) | 0.49 (0.50) | 0.30 (0.46) | −0.51 [−0.61, −0.41] |
| Beale (1) | 1.00 (0.00) | 0.45 (0.50) | 0.36 (0.48) | −0.55 [−0.64, −0.45] |
| Himmelblau (4) | 3.64 (0.50) | 1.33 (0.58) | 0.89 (0.66) | −2.31 [−2.46, −2.15] |
| Ackley (4) | 3.39 (0.68) | 1.78 (0.76) | 1.48 (0.71) | −1.61 [−1.81, −1.41] |
| Rastrigin (4) | 2.49 (0.91) | 1.36 (0.88) | 1.14 (0.69) | −1.13 [−1.37, −0.89] |
| Six-hump camel (2) | 1.99 (0.10) | 0.81 (0.67) | 0.37 (0.52) | −1.18 [−1.31, −1.05] |
| Shubert (18) | 6.04 (2.05) | 0.05 (0.22) | 0.20 (0.42) | −5.99 [−6.41, −5.59] |
| Vincent (36) | 8.44 (2.02) | 1.23 (0.79) | 0.70 (0.64) | −7.21 [−7.63, −6.78] |

![Figure 1](figures/fig_optima.png)

*Figure 1. Share of global optima kept, with 95% intervals of the mean. The number of optima is in brackets.*

**H3 (rejected).** Under the moment-matched radius and with no $\rho_{\max}$, no arm with at least one governor exploded on any landscape (Figure 2). Median final half-widths were 0.013–0.036 population units (the domain's half-width is 1), and the largest single run reached 0.49 (no schedule, Ackley). With all three governors removed, 21 to 70 runs of 100 exploded, with median final half-widths of 0.71–1.44; only on Rastrigin did that pass the arm-level threshold of 50 runs. Any two governors were enough. Configurations with a single governor were not run, so whether each one alone suffices is untested. The sketch's failure mode is real, but no single governor was necessary.

![Figure 2](figures/fig_explosion.png)

*Figure 2. Median final half-width of each run (100 runs × 5 landscapes per arm) under the moment-matched radius with no $\rho_{\max}$. Black bars: medians.*

## 6.2 The theory's predictions

**H4a (rejected quantitatively).** In the registered tournament, the share of runs that kept the tall peak was 1.00, 1.00, 1.00, 0.99, 0.94, 0.78, 0.57, 0.45 and 0.03 at $m$ = 0.25 to 4 (Figure 3). Part (i) holds. Parts (ii) and (iii) fail: the share crossed 0.5 at $m=2.45$, outside the predicted window $[0.5,2]$, and was still 0.57 at $m=2$ and 0.45 at $m=2.83$. The 20-seed pilot had placed the crossing near 2.2.

The registered tournament departed from Proposition 4's model in more than the three omissions the proposition lists.

- **Seeding.** The 16 seeds of each peak were identical boxes. In the first generation exclusion removed all but one per peak (30 exclusions and 30 births in every cell with $m\le2$; A6), and fission refilled the slots with halves of the two survivors.
- **Halving.** Speciation (22 splits per run at $m=2$) and fission (134 births, refilling extinctions and exclusions) then kept halving boxes. At $m=2$ the median half-width after 12 updates was 0.25 function units, against 1.42 for the schedule and mutation alone.
- **Moving centres.** Exclusion, speciation and fission moved centres: the median distance of final species centres to the nearer peak was 0.15–1.06 function units across $m$.
- **Lineage shares.** The share of species on the tall peak fell steadily with $m$, from 0.48 at $m=0.25$ to 0.11 at $m=1$ and 0.01 at $m=4$. It fell even below $\rho_{T,\mathrm{crit}}$, where the model predicts no deaths.

An exploratory simulation of the model itself (centred boxes with fixed centres, no exclusion or speciation, birth by cloning a survivor, the expected radius trajectory; A7, 200 runs per cell, designed after the registered result) shows that sampling noise alone does not move the transition. Its outcome is survival of the tall lineage. With 16 lives per box, the share keeping the tall lineage was 1.00 up to $m=0.707$, 0.97 at $m=1$ and 0 from $m=1.414$ on. With 256 lives it was 1.00 up to $m=1$ and 0.01 at $m=1.414$. At $m=4$ the boxes overhang the lethal edge, both lineages' quantiles start at 0 and nothing dies until the boxes shrink; with 256 lives the tall lineage then survived in 45% of runs. The registered miss is therefore consistent with the departures listed above, but no tournament removed them one at a time, so which of them moved the transition is untested.

![Figure 3](figures/fig_tournament.png)

*Figure 3. Share of runs keeping the tall peak against the initial half-width. Blue: the registered H4a tournament (100 runs per point). Orange: full dynamics (exploratory). Green: share of runs in which the tall lineage survives in a simulation of Proposition 4's model with 16 lives per box (exploratory, A7; 200 runs per point; a different outcome from the registered one). Dashed: Proposition 4's prediction.*

**Full dynamics (exploratory).** With centres free, the seeded tournament kept the tall peak in at most 40% of runs and the broad peak in at most 55%, at any $m$. Two things push seeded species off their peaks: Proposition 1's outward drift, and the early blending of the two lineages while the kernel is still wide. We did not separate them. DE seeded with 256 individuals on each peak lost the tall peak in every run and kept the broad one in 99.

**H4b (supported).** From a random start, IDEA-R kept the tall peak in 2 runs of 100 and DE in 83. In exploratory measures, IDEA-R's species ended on the broad peak's flank. In every run some species sat within 1.2 function units of its centre (67% of all species on average), at a median distance of 1.05, with a best output of 0.677 against the peak's 0.7. By the δ = 0.25 criterion, IDEA-R kept the broad peak in 46 runs.

**H5 (rejected).** IDEA-R's 64 best outputs were more robust than DE's where the landscape is rugged: on Ackley by +0.237 [+0.204, +0.266] and on Rastrigin by +0.182 [+0.164, +0.200]. Where it is smooth they were less robust: on Rosenbrock by −0.033 [−0.050, −0.020], on Beale by −0.045 [−0.066, −0.026] and on Himmelblau by −0.026 [−0.050, −0.005]. The difference is not that DE's outputs sit closer to the optimum. On the smooth landscapes both algorithms' 64 best outputs lay at similar median distances from the nearest optimum: Rosenbrock 1.22 against 1.26 function units, Beale 0.86 against 0.81, Himmelblau 0.187 against 0.192 (A8). On Ackley and Rastrigin, IDEA-R's lay much closer: 0.12 against 0.39, and 0.17 against 1.21. On the held-out landscapes (exploratory) IDEA-R was more robust on Vincent (+0.098) and Shubert (+0.040), and less on the six-hump camel (−0.034).

**H6 (supported).** On Rosenbrock as coded, every species of IDEA-R ended outside the box in every one of 100 runs. The fitness of its 64 best outputs was the plateau's, 0.706. On the coded Himmelblau and Beale, 23 and 17 runs had at least half their species outside. DE on coded Rosenbrock left 81% of its final population outside too. Its 64 best outputs averaged 0.870, and 79% of them lay inside the box. The plateau beats 88% of the box point by point (A10), so H6 does not isolate the quantile. What it shows is that IDEA's species all went to the plateau, while DE's best individuals mostly did not.

**H7 (supported).** In IDEA-L the median share of species at $\rho_{\min}$ after three updates was 1.00 on all five landscapes (A2). The median share after the second update was 63–94%. After the third, the share was below 1 in only 1–4 runs per landscape, with a minimum of 0.906. The median curve in Figure 4 reaches the floor at the second update.

![Figure 4](figures/fig_radius.png)

*Figure 4. Median half-width per update (function units, log scale). Dashed: the repaired schedule and the inflating mutation alone (Proposition 3); grey line: $\rho_{\min}$.*

## 6.3 What IDEA did instead (exploratory)

**Viability over diversity.** IDEA-R's outputs were far more often viable: 0.94–1.00 of them on the smooth landscapes, 0.96 on Ackley and 0.78 on Rastrigin, against DE's 0.58–0.87, 0.21 and 0.11. Its 64 best outputs were fitter on the two rugged landscapes (Ackley 0.950 against 0.750; Rastrigin 0.832 against 0.609) and slightly less fit on the smooth ones. Its single best output was lower on average on every landscape (on Rastrigin within noise). On the paper's landscapes its entropy was 2.4–3.3 bits against DE's 5.2–5.8, and it occupied fewer basins (Rastrigin 4.55 against 20.7).

**Which optima survive.** Which optima IDEA kept followed the width of their basins more closely than for DE:

- **Himmelblau.** It kept the minimum nearest the box corner, $(-3.78,-3.28)$, least often: in 6 runs of 100, against DE's 67. It kept $(3,2)$ in 62 (DE 100), and the other two, at 0.42 and 0.87 function units from an edge, in 32 and 33 (DE 99 and 98).
- **Vincent.** Optima are narrow at small $x$ and broad at large $x$. IDEA-R kept optima only in the three broadest columns (1%, 11% and 8% per optimum) and none in the three narrowest. DE's shares rose from 2% to 44% across the six columns.
- **Shubert.** The extreme case: a flat background ($g\approx0.45$) carries sharp peaks and sharp pits. IDEA-R settled on the background, kept 0.05 of 18 optima, and its best output averaged 0.59 against DE's 0.93.

**The clade.**

- **Overlap.** IDEA-R's final boxes overlapped in every run (86 of 100 on Shubert), with 2–53 overlapping pairs per run (A3). The output comes after the last update, with no exclusion after it, and floor-width fission creates overlapping siblings. Proposition 6(c)'s guarantee therefore does not cover the measured clade.
- **Union against bounding box.** The union's non-viable share was 0.003–0.23, except on Shubert (0.93). That is close to the share of non-viable lives, and a post-hoc exclusion pass on the first 30 runs lowered it by at most 0.04 (A4). The bounding box was 0.41–0.89 non-viable.

The sketch's geometric point, union rather than hull, holds here. It follows from where the boxes sit, not from a guarantee.

**Where the lost optima go.** Two ablations locate the cost.

- **Lineages.** DE with 32 individuals kept 0.27–0.91 optima, fewer than IDEA-R's 32 species on every landscape. But it also had 800 evaluations, a sixteenth of the budget, so this comparison does not separate the box from the budget. At equal evaluations DE's 512 lineages win.
- **More species, fewer lives.** With $K=128$ and $n=4$, IDEA kept 2.74, 3.94 and 3.46 optima on Himmelblau, Ackley and Rastrigin. That is more than DE on Ackley (+0.55 [+0.41, +0.69]) and Rastrigin (+0.97 [+0.76, +1.18]) and fewer on Himmelblau (−0.90 [−1.06, −0.74]). Its 64 best outputs averaged 0.952, 0.968 and 0.897. It also changes more than the allocation. With $n=4$ the species fitness is the minimum of four lives, at an expected quantile level of 0.20 against 0.12, and splits and births are far more frequent. This is one ablation of twelve, read after the results, and it is not a confirmed result. It restates the sketch's H2 in a form worth registering.

**The governors under the default radius.** These are the ablations with $\rho_{\max}=1$ and the mean radius.

- **No extinction.** Viability collapsed: 0.07–0.17 of outputs viable, and 0.09–0.71 optima kept. Extinction is IDEA's main selection force.
- **No exclusion.** Optima kept fell on Ackley (1.04 against 1.78) and Rastrigin (0.59 against 1.36). Exclusion is its niching.
- **No schedule.** It changed little: speciation, fission and exclusion shrink boxes faster than the schedule does. After 12 updates IDEA-R's median half-width was 6.5–12 times smaller than the schedule and mutation alone would give, and without the schedule it was only 1.1–1.2 times larger than with it (Figure 4).

The other ablations (no speciation, an absolute threshold, the normalised kernel, fitness-proportional birth, within-species centres, symmetric radius mutation) all stayed within 0.3 optima of IDEA-R on every landscape. DE with $\sigma_m=1$ kept fewer optima than with 0.1 on four landscapes (Rastrigin 1.56 against 2.49) and as many on Rosenbrock.

![Figure 5](figures/fig_landscapes.png)

*Figure 5. Final states of run 0 on the eight landscapes (fitness 0 outside the box). Top: DE's population. Bottom: IDEA-R's boxes and lives. Crosses: global optima; darker grey: higher fitness.*

# 7 Discussion

**Making the species a box changes the objective.** DE's targets are fitness-weighted averages, so its population spreads over the high-fitness region roughly in proportion to fitness. IDEA ranks species by the lower quantile of a box, which is a robust objective (Proposition 2). On these landscapes it meant:

- broad basins over narrow peaks (Vincent, the two-peak landscape);
- the Himmelblau minimum nearest a lethal corner least often;
- flat, mediocre ground over rugged, good ground (Shubert);
- and, where the landscape is flat outside the box, the outside: on Rosenbrock as coded, all of IDEA's species went there (H6).

This is survival of the flattest [11–14], made explicit and pushed to its limit. It is the right objective when a solution must tolerate variation. That is what the sketch means by standing variation, and what robust optimisation seeks with its effective fitness [20, 21]. It is the wrong objective when the goal is to find every optimum.

It may not, however, be the main reason H2 failed. The same objective with 128 species of 4 lives kept more optima than DE on Ackley and Rastrigin (exploratory, with confounds; Section 6.3). The objective decides which optima survive; the number of lineages decides how many.

**The lower quantile reads a box as load, not as range.** The sketch's box is standing variation: the share of a species' offspring that fall in lethal ground is its load. That is the quasispecies reading, and the lower quantile is a fair score for it. Species selection in palaeobiology reads a range the other way. A species with a broad geographic range survives longer because it is extinguished only when every part of its range fails [7, 6]. The sketch's sentence "a Himmelblau peak that sits in one corner of a box whose rest is lethal does not save the species" is true of load and false of range, since a refugium does save a species. A box that stands for range would be scored by an upper quantile or the maximum, which is a different algorithm. Both are coherent; they answer different questions, and an IDEA should say which one it asks.

**The governors are redundant, and the schedule barely acts.** As written, the radius rule runs backwards: the median radius reaches the floor at the second update (Proposition 3a, H7). Repaired, it does what the sketch describes. But the algorithm's own events already shrink boxes far faster than the schedule: after 12 updates the median box was 6.5–12 times narrower than the schedule and mutation alone would make it on the paper's landscapes, and 5.6 times narrower in the tournament at $m=2$ (Figure 4, Section 6.2). Removing the schedule changed little. Under union-style growth, any two governors prevented explosion, and removing all three let 21–70% of runs explode (H3); we did not run single-governor configurations. Explosion needed a growth operator and the absence of all three.

**Isolation is real but bought with lineages.** Exclusion does niche: removing it cost optima on the rugged landscapes. This is the clearing and sharing family of niching methods [8, 10] in a geometric form. Our final boxes overlapped, so the guarantee of Proposition 6(c) went untested; the union stayed on viable ground because the boxes did. The price of species is the budget: sixteen lives per species leave 32 species against DE's 512 individuals. The theory also says the early fat boxes cull narrow niches before they shrink (Proposition 4). H4b is consistent with this, but we did not run random starts with narrow initial boxes. The exploratory allocation with 128 species of 4 lives kept more optima than DE on Ackley and Rastrigin. Three changes follow, each to be tested rather than assumed:

- spend the budget on species rather than lives;
- start no wider than the viability radius of the narrowest niche worth keeping;
- keep extinction and exclusion, which carry the selection and the niching, and treat the schedule as optional.

**An estimate, not a certificate.** In P1–P3 an interval was a sound statement about a decision. In IDEA the box is a population, and its fitness is an estimate. With 16 lives the 10th percentile is overstated about half the time, and a 95% statement that 90% of a box is viable needs 29 lives (Proposition 5). Interval arithmetic gives a sound lower bound, but the dependency problem loosens it [17, 19]. An IDEA whose extinction read a sound bound would be a stochastic form of set inversion [18]. Its clade would then be an inner approximation of the viable set $\{g\ge\theta\}$. With sound bounds every surviving box lies inside the viable set, and so does their union, overlapping or not. With quantile estimates the union is guaranteed to inherit the boxes' guarantee when they are disjoint (Proposition 6c). That, rather than a better optimiser, may be the natural home of the idea in the log interval programme.

**In high dimension** the lower quantile reads the bulk of a box rather than its worst part (Proposition 2e), and a normalised kernel's preference for narrow donors grows exponentially with dimension (Proposition 6d). The paper's high-dimensional and latent experiments therefore say nothing about IDEA. We did not test it there.

# 8 Limitations

- **Scope.** Two dimensions, one budget (12,800 evaluations), and the paper's benchmark schedule and noise. The theory's high-dimensional statements are untested.
- **The design saw the paper's landscapes.** Pilots on them led to the four choices marked † in Section 3.2, to the overlap tolerance, to the tournament without the centre update, and to H6 itself. The pipeline smoke test also gave pre-freeze verdicts on two seeds per cell, which agreed with the final ones for H2 and H3–H7 (H1 came out inconclusive; H2-H was not run). The confirmatory seeds were fresh, and no algorithm ran on the held-out landscapes before the protocol was frozen. Still, the frozen design is not independent of the paper's landscapes, and the supported verdicts on H4b, H6 and H7 were not blind.
- **Two design flaws found in review.**
  - The registered tournament seeded identical boxes, which exclusion collapsed in the first generation. An exploratory simulation of the model (A7) shows the model itself behaves as predicted, but it is not a registered test and does not test the algorithm.
  - IDEA's final boxes overlap, because floor-width fission creates overlapping siblings and the output follows an update with no exclusion. The clade measurement is therefore not the disjoint union that Proposition 6(c) assumes.
- **One control is not budget-matched.** DE with $N=32$ used 800 evaluations.
- **One reading of a sketch.** Other thresholds, birth rules, speciation tests or radius estimates could behave differently. The ablations bound single choices: all stayed within 0.3 optima of IDEA-R except extinction, exclusion and the split of the budget between species and lives.
- **Metrics.** An optimum counts as kept when a viable output lies within $\delta_L$ of it. Outputs are DE's final population and IDEA's final lives. The paper scores DE by its target estimates instead; we report both.
- **The tournament** switched off the centre update to isolate selection, but exclusion, speciation and fission still moved and halved boxes, and its theory left them out. The registered prediction missed by a factor of about 2.5.
- **Statistics.** Intervals are unpaired bootstrap intervals, and there is no correction for multiplicity. Every decision follows the frozen rule.
- **Held-out scales** were set by one rule: 10% of the box at $g\ge0.5$.

# 9 Conclusion

Diffusion Evolution is reproduced to within 0.02 bits and 0.01 fitness with the noise level in its code, which differs from the one in its text. Turned into a species algorithm as sketched, with boxes, lower-quantile selection, geometric isolation and a union clade, it does something coherent and measurable: it finds where a population with standing variation can live. In exploratory measures on the paper's landscapes, its outputs were far more often viable, and on the rugged ones fitter and more robust. As coded, Rosenbrock drew every one of its species out of the box onto a flat plateau.

It did not keep more optima. At equal evaluations it kept 45–99% fewer optima than DE on every multi-optimum landscape we tried, held-out ones included. The ablations point to the split of the budget between species and lives, and the theory to the early fat boxes. No single one of its three governors was necessary, and its radius rule as written runs backwards. Theory predicted the flight to flatness, the loss of narrow peaks from a random start, and the collapse of the literal radius rule. It predicted greater robustness everywhere, which held only on the rugged landscapes (H5). It missed where the registered tournament's transition fell; that design departed from its model in ways we did not test one at a time, and an exploratory simulation of the model itself put the transition where the theory said.

The exploratory result worth registering next is the reallocation: many small species, few lives each. The idea worth building next is a certified version, in which extinction reads a sound bound and the clade is an inner approximation of the viable set.

# References

[1] Zhang, Y., Hartl, B., Hazan, H., and Levin, M. (2025). Diffusion Models are Evolutionary Algorithms. *International Conference on Learning Representations (ICLR 2025)*. arXiv:2410.02543v3. Code: github.com/Zhangyanbo/diffusion-evolution.

[2] Song, J., Meng, C., and Ermon, S. (2021). Denoising Diffusion Implicit Models. *ICLR 2021*. arXiv:2010.02502.

[3] Nichol, A. Q., and Dhariwal, P. (2021). Improved Denoising Diffusion Probabilistic Models. *Proceedings of the 38th International Conference on Machine Learning*, PMLR 139, 8162–8171.

[4] Hartl, B., Zhang, Y., Hazan, H., and Levin, M. (2024). Heuristically Adaptive Diffusion-Model Evolutionary Strategy. arXiv:2411.13420.

[5] Stanley, S. M. (1975). A Theory of Evolution above the Species Level. *Proceedings of the National Academy of Sciences* 72(2), 646–650.

[6] Jablonski, D. (2008). Species Selection: Theory and Data. *Annual Review of Ecology, Evolution, and Systematics* 39, 501–524.

[7] Jablonski, D. (1987). Heritability at the Species Level: Analysis of Geographic Ranges of Cretaceous Mollusks. *Science* 238(4825), 360–363.

[8] Goldberg, D. E., and Richardson, J. (1987). Genetic Algorithms with Sharing for Multimodal Function Optimization. *Proceedings of the Second International Conference on Genetic Algorithms*, 41–49.

[9] Li, X., Engelbrecht, A., and Epitropakis, M. G. (2013). *Benchmark Functions for CEC'2013 Special Session and Competition on Niching Methods for Multimodal Function Optimization*. Technical report, Evolutionary Computation and Machine Learning Group, RMIT University.

[10] Pétrowski, A. (1996). A Clearing Procedure as a Niching Method for Genetic Algorithms. *Proceedings of the IEEE International Conference on Evolutionary Computation*, 798–803.

[11] Eigen, M. (1971). Selforganization of Matter and the Evolution of Biological Macromolecules. *Naturwissenschaften* 58(10), 465–523.

[12] Schuster, P., and Swetina, J. (1988). Stationary Mutant Distributions and Evolutionary Optimization. *Bulletin of Mathematical Biology* 50(6), 635–660.

[13] Wilke, C. O., Wang, J. L., Ofria, C., Lenski, R. E., and Adami, C. (2001). Evolution of Digital Organisms at High Mutation Rates Leads to Survival of the Flattest. *Nature* 412, 331–333.

[14] van Nimwegen, E., Crutchfield, J. P., and Huynen, M. (1999). Neutral Evolution of Mutational Robustness. *Proceedings of the National Academy of Sciences* 96(17), 9716–9720.

[15] Anderson, T. W. (1955). The Integral of a Symmetric Unimodal Function over a Symmetric Convex Set and Some Probability Inequalities. *Proceedings of the American Mathematical Society* 6(2), 170–176.

[16] David, H. A., and Nagaraja, H. N. (2003). *Order Statistics*, 3rd ed. Wiley.

[17] Moore, R. E. (1966). *Interval Analysis*. Prentice-Hall.

[18] Jaulin, L., and Walter, E. (1993). Set Inversion via Interval Analysis for Nonlinear Bounded-Error Estimation. *Automatica* 29(4), 1053–1064.

[19] Hansen, E., and Walster, G. W. (2004). *Global Optimization Using Interval Analysis*, 2nd ed. Marcel Dekker.

[20] Beyer, H.-G., and Sendhoff, B. (2007). Robust Optimization – A Comprehensive Survey. *Computer Methods in Applied Mechanics and Engineering* 196(33–34), 3190–3218.

[21] Tsutsui, S., and Ghosh, A. (1997). Genetic Algorithms with a Robust Solution Searching Scheme. *IEEE Transactions on Evolutionary Computation* 1(3), 201–208.

[22] Ghosh, Debi Prasad. (2026). *Log Interval Networks for Certified Decisions and Structured Memory*. Research programme with reproducible numerical checks, 1 October 2026.

[23] Ghosh, Debi Prasad. (2026). *Log Interval Networks for Evidence Accumulation and Certified Decisions*. P1 of the log interval network programme, 4 October 2026.

[24] Ghosh, Debi Prasad. (2026). *Positive Kronecker Attention with Dependency Control*. P2 of the log interval network programme, 5 October 2026.

[25] Ghosh, Debi Prasad. (2026). *Sleep That Knows What It Keeps: Consolidation and Certified Precision for a Positive Kronecker Memory*. P3 of the log interval network programme, 5 October 2026.

[26] Ghosh, Debi Prasad. (2026). *Interval Diffusion Evolutionary Algorithm (IDEA)*. Research note (the sketch tested here), 6 October 2026.

# Appendix A. Reproduction

**Contents of the supplement.**

- **Code and protocol:** every script, the protocol, the frozen hashes, and the theory checks with their output.
- **Pilots:** the pilot and smoke-test scripts and logs.
- **Results:** the evaluator's outputs for all 145 cells (`evals/`, per-run metrics as JSON, with `decisions.json`), the tables, the figures and the quoted numbers.

It omits the raw run outputs (`runs/`, 191 MB), which `idea_runs.py` regenerates deterministically, and the reference repositories, which are identified by commit.

**Environment.** Python 3.11.15, NumPy 2.4.4, SciPy 1.17.1 and Matplotlib 3.10.9, on two CPU cores.

**Sources read.**

- github.com/Zhangyanbo/diffusion-evolution at commit 41ac6ca: `diffevo/ddim.py`, `generator.py`, `fitnessmapping.py`, `kde.py`, `optimizer.py`; `experiments/benchmarks/methods/diff_evo.py`, `benchmarks.py`, `run_benchmarks.py`, `run_temperature.py`, `statistic.py`.
- github.com/bhartl/foobench at commit 18de5da: `foobench/objective.py`, `foos.py`.

**Commands**, in order:

```
python3 repro_de.py > logs/repro_de.log                       # the paper's Table 3 (pre-freeze), ~6 minutes
python3 verify_idea_theory.py > verify_idea_theory_output.txt # T1-T17, 32 checks, ~25 seconds
python3 idea_runs.py all --workers 2                          # 145 cells x 100 runs, ~17 minutes
python3 idea_eval.py metrics --workers 2                      # frozen evaluator, ~16 minutes
python3 idea_eval.py decide                                   # decision rules -> evals/decisions.json
python3 idea_report.py                                        # report/summary.json, report/tables.md, figures/
python3 idea_facts.py > facts_output.txt                      # every number quoted in the paper
python3 paper_tables.py                                       # Appendix B tables
python3 verify_idea_addendum.py > verify_idea_addendum_output.txt  # post-review checks A1-A11, ~2 minutes
```

**Frozen code.** Before the first confirmatory run, the library, run script, evaluator, theory checks and protocol were hashed into `evals_code_sha256.txt`:

    dbc49ef61098d65c76c55966a2db5db760177e62671b78fb8b58ffbd5143a11f  idealib.py
    f94665108b8edd951a6037a56f1d42a54fa70ad6661c5f3db56355d99d967802  idea_runs.py
    5b9e669c8d47c935481cba9e9ff65ef5c8fa298601ef0ba9294f352e06ff316e  idea_eval.py
    c64845807e6db6e3605ffaaaf0d59414f12ad90af60611555c6daa9a9c5e72ab  verify_idea_theory.py
    13cbede3577632874dfe45c35c269754cd9c45733a0908a8edfa3672267cc33b  PROTOCOL.md
    frozen 2026-10-06T10:43:28Z

None of these files changed afterwards. Every cell records the hashes of `idealib.py` and `idea_runs.py` that produced it, and all 145 match. `idea_report.py`, `idea_facts.py`, `paper_tables.py` and `verify_idea_addendum.py` were written after the runs, the last after the independent review.

- **Inputs.** They read the evaluator's outputs and the raw run outputs. `idea_report.py` also reads `results/repro_de.json` and `report/b7_model_tournament.json`.
- **Uses of the raw outputs.** Figure 5; the exploratory analyses of which optima were kept and where the random-start two-peak runs ended; and the checks A2–A4, A6 and A8–A9.
- **New simulations.** `verify_idea_addendum.py` runs its own small simulations for A1, A5 and A7. None tests a registered hypothesis.

**What the checks check.** Several checks confirm arithmetic or internal consistency rather than test independently.

- **T1b and T1d** compare the port with the same formulas typed again. Fidelity to the reference code rests on reading that code and on reproducing the paper's Table 3; PyTorch was not available to run the reference itself.
- **T12 and T15a** are arithmetic.
- **T13** checks the closed form of Proposition 4 against its own recursion, not against the algorithm.
- **T3a** compares minima on scaled, not nested, grids.
- **T7** compares the interval bound with a grid minimum.
- **T8c** used a symmetric radius mutation; A1 redoes it with the paper's half-normal one.

**Compute.** The confirmatory runs took 0.56 CPU core-hours, and the evaluation 15.4 minutes on two workers (about 0.5 core-hours). The pilots, smoke tests, reproduction and post-review checks took under an hour more.

# Appendix B. Further results

`report/tables.md` gives every cell, with standard deviations. TABLESA1A7 are generated by `paper_tables.py` from the frozen evaluator's outputs.

**Table B1. Quality, viability, robustness and diversity** (means over 100 runs; DE / IDEA-R / IDEA-L).

| Landscape | fitness of the 64 best | best output | viable share | robustness (0.2) | entropy (bits) | basins |
|---|---|---|---|---|---|---|
| Rosenbrock | 0.993 / 0.991 / 0.983 | 1.000 / 0.998 / 0.992 | 0.87 / 1.00 / 0.98 | 0.942 / 0.909 / 0.844 | 5.41 / 3.30 / 3.17 | 75.19 / 34.46 / 34.75 |
| Beale | 0.961 / 0.954 / 0.963 | 0.999 / 0.982 / 0.982 | 0.79 / 0.97 / 0.97 | 0.892 / 0.847 / 0.753 | 5.50 / 3.17 / 2.96 | 10.71 / 5.20 / 6.34 |
| Himmelblau | 0.943 / 0.927 / 0.861 | 0.998 / 0.971 / 0.923 | 0.58 / 0.94 / 0.84 | 0.791 / 0.765 / 0.656 | 5.17 / 2.45 / 2.48 | 3.78 / 1.98 / 1.80 |
| Ackley | 0.750 / 0.950 / 0.927 | 0.992 / 0.982 / 0.967 | 0.21 / 0.96 / 0.93 | 0.529 / 0.765 / 0.694 | 5.69 / 2.63 / 2.42 | 14.66 / 6.63 / 5.51 |
| Rastrigin | 0.609 / 0.832 / 0.813 | 0.928 / 0.912 / 0.899 | 0.11 / 0.78 / 0.74 | 0.374 / 0.556 / 0.539 | 5.78 / 2.48 / 2.38 | 20.72 / 4.55 / 3.38 |
| Six-hump camel | 0.932 / 0.899 / 0.767 | 0.998 / 0.941 / 0.817 | 0.52 / 0.91 / 0.64 | 0.851 / 0.817 / 0.675 | 5.44 / 2.92 / 2.73 | 2.00 / 1.74 / 1.31 |
| Shubert | 0.567 / 0.510 / 0.533 | 0.928 / 0.590 / 0.636 | 0.11 / 0.07 / 0.09 | 0.333 / 0.373 / 0.328 | 5.88 / 3.82 / 3.44 | 45.31 / 5.60 / 4.98 |
| Vincent | 0.910 / 0.933 / 0.857 | 0.997 / 0.978 / 0.909 | 0.39 / 0.93 / 0.79 | 0.625 / 0.723 / 0.631 | 5.41 / 2.68 / 2.46 | 13.95 / 2.39 / 1.82 |

**Table B2. Exploratory ablations: optima kept** (means over 100 runs; paper landscapes, fitness 0 outside; every arm at 12,800 evaluations except DE with N = 32, at 800).

| Arm | Rosenbrock | Beale | Himmelblau | Ackley | Rastrigin |
|---|---|---|---|---|---|
| DE | 1.00 | 1.00 | 3.64 | 3.39 | 2.49 |
| DE, σ_m = 1 | 1.00 | 0.96 | 3.23 | 3.09 | 1.56 |
| DE, N = 32 | 0.27 | 0.27 | 0.91 | 0.77 | 0.41 |
| IDEA-R | 0.49 | 0.45 | 1.33 | 1.78 | 1.36 |
| no schedule | 0.54 | 0.47 | 1.28 | 1.64 | 1.24 |
| no exclusion | 0.45 | 0.29 | 1.11 | 1.04 | 0.59 |
| no extinction | 0.09 | 0.13 | 0.41 | 0.71 | 0.70 |
| no speciation | 0.47 | 0.39 | 1.19 | 1.81 | 1.12 |
| absolute threshold | 0.46 | 0.34 | 1.18 | 1.99 | 1.30 |
| normalised kernel | 0.41 | 0.34 | 1.28 | 1.54 | 1.18 |
| fitness-proportional birth | 0.52 | 0.50 | 1.07 | 1.82 | 1.18 |
| within-species centres | 0.37 | 0.43 | 1.18 | 1.58 | 1.23 |
| symmetric radius mutation | 0.33 | 0.31 | 1.16 | 1.67 | 1.51 |
| K = 128, n = 4 | 0.93 | 0.88 | 2.74 | 3.94 | 3.46 |
| IDEA-L | 0.30 | 0.36 | 0.89 | 1.48 | 1.14 |

**Table B3. The same ablations: fitness of the 64 best outputs / viable share.**

| Arm | Rosenbrock | Beale | Himmelblau | Ackley | Rastrigin |
|---|---|---|---|---|---|
| DE | 0.993 / 0.87 | 0.961 / 0.79 | 0.943 / 0.58 | 0.750 / 0.21 | 0.609 / 0.11 |
| DE, σ_m = 1 | 0.994 / 0.92 | 0.968 / 0.84 | 0.956 / 0.68 | 0.691 / 0.18 | 0.554 / 0.08 |
| DE, N = 32 | 0.713 / 0.77 | 0.625 / 0.69 | 0.462 / 0.44 | 0.360 / 0.26 | 0.318 / 0.14 |
| IDEA-R | 0.991 / 1.00 | 0.954 / 0.97 | 0.927 / 0.94 | 0.950 / 0.96 | 0.832 / 0.78 |
| no schedule | 0.990 / 1.00 | 0.948 / 0.96 | 0.928 / 0.94 | 0.949 / 0.96 | 0.850 / 0.79 |
| no exclusion | 0.985 / 0.99 | 0.931 / 0.92 | 0.901 / 0.93 | 0.867 / 0.86 | 0.770 / 0.68 |
| no extinction | 0.769 / 0.15 | 0.755 / 0.17 | 0.551 / 0.07 | 0.641 / 0.14 | 0.609 / 0.12 |
| no speciation | 0.991 / 1.00 | 0.953 / 0.96 | 0.909 / 0.92 | 0.943 / 0.96 | 0.824 / 0.79 |
| absolute threshold | 0.991 / 1.00 | 0.950 / 1.00 | 0.917 / 0.98 | 0.965 / 0.98 | 0.873 / 0.96 |
| normalised kernel | 0.991 / 1.00 | 0.952 / 0.97 | 0.921 / 0.93 | 0.956 / 0.96 | 0.832 / 0.77 |
| fitness-proportional birth | 0.993 / 1.00 | 0.965 / 0.99 | 0.946 / 0.97 | 0.972 / 0.98 | 0.874 / 0.86 |
| within-species centres | 0.989 / 1.00 | 0.954 / 0.96 | 0.901 / 0.91 | 0.938 / 0.95 | 0.821 / 0.75 |
| symmetric radius mutation | 0.990 / 1.00 | 0.949 / 0.97 | 0.899 / 0.91 | 0.943 / 0.95 | 0.849 / 0.80 |
| K = 128, n = 4 | 0.993 / 1.00 | 0.967 / 0.99 | 0.952 / 0.97 | 0.968 / 0.96 | 0.897 / 0.91 |
| IDEA-L | 0.983 / 0.98 | 0.963 / 0.97 | 0.861 / 0.84 | 0.927 / 0.93 | 0.813 / 0.74 |

**Table B4. Explosion arms: runs exploded (of 100) / median final half-width (population units).**

| Governors | Rosenbrock | Beale | Himmelblau | Ackley | Rastrigin |
|---|---|---|---|---|---|
| all three kept | 0 / 0.013 | 0 / 0.013 | 0 / 0.013 | 0 / 0.013 | 0 / 0.013 |
| schedule removed | 0 / 0.028 | 0 / 0.029 | 0 / 0.014 | 0 / 0.013 | 0 / 0.013 |
| exclusion removed | 0 / 0.033 | 0 / 0.036 | 0 / 0.018 | 0 / 0.013 | 0 / 0.013 |
| extinction removed | 0 / 0.022 | 0 / 0.021 | 0 / 0.022 | 0 / 0.022 | 0 / 0.023 |
| all removed | 36 / 0.948 | 21 / 0.813 | 30 / 0.715 | 41 / 0.903 | 70 / 1.444 |

**Table B5. Two-peak tournament** (share of 100 runs keeping the tall / broad peak; mean share of species on the tall peak; median half-width after 12 updates, function units).

| $m$ | $\rho_T$ (f.u.) | registered tournament | species on tall | half-width at 12 | full dynamics | species on tall |
|---|---|---|---|---|---|---|
| 0.25 | 0.148 | 1.00 / 1.00 | 0.48 | 0.050 | 0.31 / 0.02 | 0.22 |
| 0.354 | 0.209 | 1.00 / 1.00 | 0.37 | 0.091 | 0.38 / 0.04 | 0.28 |
| 0.5 | 0.295 | 1.00 / 1.00 | 0.24 | 0.120 | 0.40 / 0.05 | 0.26 |
| 0.707 | 0.418 | 0.99 / 1.00 | 0.14 | 0.158 | 0.28 / 0.08 | 0.18 |
| 1 | 0.591 | 0.94 / 0.94 | 0.11 | 0.197 | 0.26 / 0.18 | 0.15 |
| 1.414 | 0.835 | 0.78 / 0.87 | 0.10 | 0.232 | 0.19 / 0.25 | 0.09 |
| 2 | 1.182 | 0.57 / 0.79 | 0.08 | 0.253 | 0.11 / 0.38 | 0.03 |
| 2.83 | 1.672 | 0.45 / 0.78 | 0.05 | 0.251 | 0.02 / 0.48 | 0.00 |
| 4 | 2.363 | 0.03 / 0.68 | 0.01 | 0.250 | 0.00 / 0.55 | 0.00 |

**Table B6. Landscapes as coded** (DE / IDEA-R / IDEA-L; species centres outside: IDEA-R / IDEA-L).

| Landscape | fitness of the 64 best | optima kept | outputs inside the box | species centres outside |
|---|---|---|---|---|
| Rosenbrock | 0.870 / 0.706 / 0.713 | 0.58 / 0.00 / 0.01 | 0.19 / 0.00 / 0.01 | 1.00 / 0.99 |
| Beale | 0.961 / 0.788 / 0.833 | 0.98 / 0.31 / 0.29 | 1.00 / 0.83 / 0.87 | 0.17 / 0.13 |
| Himmelblau | 0.942 / 0.697 / 0.859 | 3.59 / 0.79 / 0.87 | 0.99 / 0.77 / 0.97 | 0.23 / 0.02 |
| Ackley | 0.750 / 0.950 / 0.927 | 3.39 / 1.78 / 1.48 | 0.99 / 0.99 / 0.99 | 0.00 / 0.00 |
| Rastrigin | 0.609 / 0.832 / 0.813 | 2.49 / 1.36 / 1.14 | 1.00 / 1.00 / 1.00 | 0.00 / 0.00 |

**Table B7. IDEA-R events and clade** (means per run).

| Landscape | extinctions | exclusions | speciations | births | union non-viable | bounding box non-viable |
|---|---|---|---|---|---|---|
| Rosenbrock | 113 | 85 | 17 | 181 | 0.003 | 0.413 |
| Beale | 113 | 88 | 18 | 183 | 0.032 | 0.521 |
| Himmelblau | 221 | 164 | 12 | 373 | 0.068 | 0.636 |
| Ackley | 167 | 130 | 42 | 256 | 0.043 | 0.807 |
| Rastrigin | 161 | 127 | 68 | 236 | 0.227 | 0.881 |
| Six-hump camel | 138 | 103 | 24 | 218 | 0.096 | 0.482 |
| Shubert | 60 | 49 | 61 | 68 | 0.932 | 0.894 |
| Vincent | 198 | 144 | 22 | 320 | 0.070 | 0.670 |

# Appendix C. Pilots and smoke tests

All pilots ran before the protocol was frozen, on the paper's five landscapes and the two-peak landscape, with seeds outside the confirmatory range (100000–100099). No algorithm ran on a held-out landscape; `pilots/heldout_calib.py` only evaluated those landscapes, to calibrate them.

The scratch scripts were written against an earlier signature of `output_metrics` and do not run against the frozen library. Their commands and outputs were reconstructed after the fact (on 11 October) from the session record into `logs/scratch_outputs_recovered.txt`; it is not a contemporaneous log. Seeds 9100–9101 were used in a timing check of $K=128$, and seeds 500–529 by an earlier version of the theory checks, whose 30 four-step runs were not used.

- **Reproduction** (`repro_de.py`, seeds 0–99). This is the paper's Table 3 with both noise levels, on the landscapes as coded (Section 2.3).
- **Schedule calibration and optima** (`scratch/calib.py`, `scratch/optima.py`). They gave the per-update coefficients behind Propositions 1 and 3, and the maximisers of Ackley and Rastrigin in the box.
- **First smoke tests** (`scratch/smoke1.py`–`smoke4.py`, `dbg_himm.py`, `dbg2.py`; seeds 1001, 2000–2004, 3000–3007).
  - On the landscapes as coded, IDEA's species left the box on Rosenbrock in every run and on Himmelblau in 4 runs of 8. This led to the comparisons with fitness 0 outside, and to H6.
  - An absolute extinction threshold extinguished every species in the first generation on Himmelblau. This led to the relative, annealed threshold.
  - Across variants (absolute and relative thresholds, uniform and fitness-proportional birth, within-species centres, the literal rule), IDEA kept fewer optima than DE on Himmelblau, Ackley and Rastrigin. We registered the sketch's H2 regardless.
- **Two-peak pilot** (`scratch/smoke_tp.py`, seeds 4000–4009, absolute threshold). From a random start, IDEA's species ended mostly on the broad peak for every $\rho_{\min}$ from 0.025 to 0.25 (population units). The tall peak held species in 3 of 10 runs at $\rho_{\min}=0.05$, and in none at the other settings. DE kept both peaks in every run.
- **Design pilots** (`pilots/pilot_design.py`, seeds 9000–9003, 8000–8009 and 7000–7003; `logs/pilot_design.log`). These came after the half-normal radius mutation and the overlap tolerance were introduced.
  - IDEA-R and IDEA-L again kept fewer optima than DE on the five landscapes.
  - In the tournament with full dynamics, seeded species drifted off both peaks, which led to switching off the centre update in the registered tournament.
  - Under the moment-matched radius with no $\rho_{\max}$, only removing all three governors made radii grow towards the domain's size.
- **Tournament pilot** (`pilots/pilot_tournament.py`, seeds 8000–8019; `logs/pilot_tournament.log`). Selection only: the share keeping the tall peak was 1.00 up to $m=1$, then 0.80, 0.55, 0.40 and 0.10 at $m$ = 1.414, 2, 2.83 and 4, so the crossing fell near 2.2. The prediction of H4a was not changed.
- **Pipeline smoke test** (`idea_runs.py smoke`, seeds 9500–9501). Every cell except the held-out ones was run, and the evaluator and decision rules were exercised on the output (`logs/smoke_runs/`, `logs/smoke_evals/`).
