"""Report for the IDEA study (written after the protocol was frozen; reads evals/ and runs/ only).

    python3 idea_report.py [--evals DIR] [--runs DIR]

Writes report/summary.json, report/tables.md and figures/*.png.
"""
import sys, os, json, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import idealib as L

HERE = os.path.dirname(os.path.abspath(__file__))
EV = os.path.join(HERE, sys.argv[sys.argv.index('--evals') + 1]) if '--evals' in sys.argv else os.path.join(HERE, 'evals')
RU = os.path.join(HERE, sys.argv[sys.argv.index('--runs') + 1]) if '--runs' in sys.argv else os.path.join(HERE, 'runs')
OUT_R, OUT_F = os.path.join(HERE, 'report'), os.path.join(HERE, 'figures')
os.makedirs(OUT_R, exist_ok=True); os.makedirs(OUT_F, exist_ok=True)
MULTS = [0.25, 0.354, 0.5, 0.707, 1.0, 1.414, 2.0, 2.83, 4.0]
NAMES = dict(rosenbrock='Rosenbrock', beale='Beale', himmelblau='Himmelblau', ackley='Ackley',
             rastrigin='Rastrigin', sixhump='Six-hump camel', shubert='Shubert', vincent='Vincent',
             two_peak='Two peaks')
# palette: dataviz reference instance (validated, light surface)
C_DE, C_R, C_L, C_4, C_5, C_6 = '#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300'
INK, INK2, MUTED, GRID, AXIS, SURF = '#0b0b0b', '#52514e', '#898781', '#e1e0d9', '#c3c2b7', '#fcfcfb'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9, 'axes.edgecolor': AXIS, 'axes.labelcolor': INK2,
                     'xtick.color': MUTED, 'ytick.color': MUTED, 'axes.grid': True, 'grid.color': GRID,
                     'grid.linewidth': 0.8, 'grid.linestyle': '-', 'axes.facecolor': SURF, 'figure.facecolor': SURF,
                     'savefig.facecolor': SURF, 'axes.titlecolor': INK, 'axes.titlesize': 10, 'legend.frameon': False,
                     'lines.linewidth': 2.0, 'lines.solid_capstyle': 'round'})


def load(sset, arm, nm):
    p = os.path.join(EV, sset, f'{arm}__{nm}.json')
    return json.load(open(p))['runs'] if os.path.exists(p) else None


def col(runs, key):
    return np.array([r[key] for r in runs if key in r and r[key] is not None], float)


def ms(v, f='{:.3f}'):
    return (f + ' ({})').format(v.mean(), f.format(v.std())) if len(v) else 'n/a'


def ci_mean(v, n=10000, seed=1):
    rng = np.random.default_rng(seed)
    b = v[rng.integers(0, len(v), (n, len(v)))].mean(1)
    return float(np.quantile(b, 0.025)), float(np.quantile(b, 0.975))


S = {}          # summary
T = []          # markdown tables


def table(title, header, rows, note=None):
    T.append(f'### {title}\n')
    T.append('| ' + ' | '.join(header) + ' |')
    T.append('|' + '---|' * len(header))
    for r in rows:
        T.append('| ' + ' | '.join(str(x) for x in r) + ' |')
    if note:
        T.append('\n' + note)
    T.append('')


# ------------------------------------------------------------------ replication (pre-freeze, results/repro_de.json)
PAPER = {'rosenbrock': (5.86, 0.10, 0.88, 0.06), 'beale': (5.50, 0.16, 0.96, 0.01), 'himmelblau': (5.23, 0.20, 0.96, 0.01),
         'ackley': (5.67, 0.13, 0.78, 0.07), 'rastrigin': (5.79, 0.10, 0.64, 0.04)}
rp = os.path.join(HERE, 'results', 'repro_de.json')
if os.path.exists(rp):
    R = json.load(open(rp))
    rows = []
    for nm in L.LANDSCAPES:
        pe, ps, pf, pfs = PAPER[nm]
        a, b = R[f'0.1_{nm}'], R[f'1.0_{nm}']
        rows.append([NAMES[nm], f'{pe:.2f} ({ps:.2f})', ms(np.array(a['entropy']), '{:.2f}'), ms(np.array(b['entropy']), '{:.2f}'),
                     f'{pf:.2f} ({pfs:.2f})', ms(np.array(a['fitness']), '{:.2f}'), ms(np.array(b['fitness']), '{:.2f}'),
                     f"{np.mean(a['frac_outside']):.3f}"])
        S[f'repro/{nm}'] = dict(entropy_01=np.mean(a['entropy']), fitness_01=np.mean(a['fitness']),
                                entropy_1=np.mean(b['entropy']), fitness_1=np.mean(b['fitness']),
                                outside_01=np.mean(a['frac_outside']))
    table('Table R. Reproduction of the Diffusion Evolution column of the paper\'s Table 3 (100 runs each, landscapes as coded)',
          ['Landscape', 'entropy, paper', 'entropy, port, σ_m = 0.1', 'entropy, port, σ_m = 1', 'fitness, paper',
           'fitness, port, σ_m = 0.1', 'fitness, port, σ_m = 1', 'final population outside the box (σ_m = 0.1)'], rows,
          'Mean (sd). The paper\'s metrics: mean x0-estimate fitness of the 64 best x0 estimates at the last step; entropy of the final population members with those indices.')

# ------------------------------------------------------------------ primary comparison
PRIM = L.LANDSCAPES + L.HELDOUT
ARMS = [('DE', 'DE'), ('IDEA_R', 'IDEA-R'), ('IDEA_L', 'IDEA-L')]
for metric, title, fmt in [('top_fit', 'Mean fitness g of the 64 fittest outputs', '{:.3f}'),
                           ('best', 'Best output fitness', '{:.3f}'),
                           ('optima', 'Global optima kept (a viable output within δ_L)', '{:.2f}'),
                           ('basins', 'Basins holding a viable output', '{:.1f}'),
                           ('top_entropy', 'Entropy of the 64 fittest outputs (bits)', '{:.2f}'),
                           ('viable_frac', 'Share of outputs with g ≥ 0.5', '{:.3f}'),
                           ('robust_0.2', 'Robust fitness of the 64 fittest outputs (10th percentile of g over a box of half-width 0.2)', '{:.3f}'),
                           ('robust_0.05', 'Robust fitness at half-width 0.05', '{:.3f}')]:
    rows = []
    for nm in PRIM:
        row = [NAMES[nm] + (f' (of {len(L.OPTIMA[nm])})' if metric == 'optima' else '')]
        for arm, _ in ARMS:
            r = load('primary', arm, nm)
            if r is None:
                row.append('n/a'); continue
            v = col(r, metric)
            row.append(ms(v, fmt))
            S[f'primary/{arm}/{nm}/{metric}'] = dict(mean=float(v.mean()), sd=float(v.std()), ci=ci_mean(v))
        rows.append(row)
    table(f'Primary comparison: {title}', ['Landscape'] + [a for _, a in ARMS], rows,
          'Mean (sd) over 100 runs; paper landscapes with fitness 0 outside the box; held-out landscapes below the line of five.')

# ------------------------------------------------------------------ hypotheses (decisions.json from the frozen evaluator)
dp = os.path.join(EV, 'decisions.json')
if os.path.exists(dp):
    Dd = json.load(open(dp))
    S['decisions'] = Dd

# ------------------------------------------------------------------ explosion
rows = []
for arm in ('X_full', 'X_noG1', 'X_noG2', 'X_noG3', 'X_noall'):
    row = [arm]
    for nm in L.LANDSCAPES:
        r = load('explosion', arm, nm)
        if r is None:
            row.append('n/a'); continue
        fr = col(r, 'final_rho')
        row.append(f'{int((fr >= 1).sum())} / {np.median(fr):.3f}')
        S[f'explosion/{arm}/{nm}'] = dict(n_exploded=int((fr >= 1).sum()), median=float(np.median(fr)),
                                          q90=float(np.quantile(fr, 0.9)), max=float(fr.max()))
    rows.append(row)
table('Explosion arms (moment-type radius estimate, no ρ_max): runs exploded / median final half-width (population units)',
      ['Arm'] + [NAMES[n] for n in L.LANDSCAPES], rows,
      'A run explodes when its median final half-width is ≥ 1.0 (a box at least as wide as the domain); the domain half-width is 1.0.')

# ------------------------------------------------------------------ tournaments
rows = []
for m in MULTS:
    row = [f'{m:g}', f'{m * 0.5908:.3f}']
    for pre in ('T_sel', 'T_full'):
        r = load('twopeak', f'{pre}_m{m}', 'two_peak')
        if r is None:
            row += ['n/a', 'n/a', 'n/a']; continue
        tk, bk, sh = col(r, 'tall_kept'), col(r, 'broad_kept'), col(r, 'share_on_tall')
        row += [f'{tk.mean():.2f}', f'{bk.mean():.2f}', f'{sh.mean():.2f}']
        S[f'twopeak/{pre}/{m}'] = dict(tall=float(tk.mean()), broad=float(bk.mean()), share_tall=float(sh.mean()))
    rows.append(row)
table('Two-peak tournament: share of runs keeping the tall / broad peak, and mean share of species on the tall peak',
      ['m = ρ_T / ρ_T,crit', 'ρ_T (function units)', 'selection-only: tall', 'broad', 'species on tall',
       'full dynamics: tall', 'broad', 'species on tall'], rows)
rows = []
for arm in ('T_DE_vitro', 'V_DE', 'V_IDEA_R'):
    r = load('twopeak', arm, 'two_peak')
    if r is None:
        continue
    tk, bk = col(r, 'tall_kept'), col(r, 'broad_kept')
    rows.append([arm, f'{tk.mean():.2f}', f'{bk.mean():.2f}', ms(col(r, 'top_fit'))])
    S[f'twopeak/{arm}'] = dict(tall=float(tk.mean()), broad=float(bk.mean()))
table('Two-peak landscape: DE seeded on the peaks, and in vivo runs', ['Arm', 'tall kept', 'broad kept', 'top-64 fitness'], rows)

# ------------------------------------------------------------------ ablations (exploratory)
ABL_ARMS = ['DE', 'DE_sm1', 'DE_N32', 'IDEA_R', 'R_noG1', 'R_noG2', 'R_noG3', 'R_nospec', 'R_abstheta', 'R_normK',
            'R_fitbirth', 'R_within', 'R_gauss', 'R_K128', 'IDEA_L']
for metric, fmt in [('optima', '{:.2f}'), ('top_fit', '{:.3f}'), ('robust_0.2', '{:.3f}'), ('viable_frac', '{:.3f}'),
                    ('basins', '{:.1f}')]:
    rows = []
    for arm in ABL_ARMS:
        row = [arm]
        for nm in L.LANDSCAPES:
            sset = 'primary' if arm in ('DE', 'IDEA_R', 'IDEA_L') else 'ablation'
            r = load(sset, arm, nm)
            if r is None:
                row.append('n/a'); continue
            v = col(r, metric)
            row.append(fmt.format(v.mean()))
            S[f'ablation/{arm}/{nm}/{metric}'] = float(v.mean())
        rows.append(row)
    table(f'Exploratory ablations (paper landscapes, fitness 0 outside): mean {metric}', ['Arm'] + [NAMES[n] for n in L.LANDSCAPES], rows)

# ------------------------------------------------------------------ coded landscapes (secondary)
rows = []
for nm in L.LANDSCAPES:
    for arm, lab in ARMS:
        r = load('coded', arm, nm)
        if r is None:
            continue
        row = [NAMES[nm], lab, ms(col(r, 'top_fit')), ms(col(r, 'optima'), '{:.2f}'), ms(col(r, 'inside_frac'))]
        row.append(ms(col(r, 'centres_outside')) if arm != 'DE' else '-')
        rows.append(row)
        S[f'coded/{arm}/{nm}'] = dict(top_fit=float(col(r, 'top_fit').mean()), optima=float(col(r, 'optima').mean()),
                                      inside=float(col(r, 'inside_frac').mean()),
                                      centres_outside=float(col(r, 'centres_outside').mean()) if arm != 'DE' else None)
table('Secondary: landscapes as coded (foobench values outside the box)',
      ['Landscape', 'Arm', 'top-64 fitness', 'optima kept', 'outputs inside the box', 'species centres outside the box'], rows)

# ------------------------------------------------------------------ clade, events, radii
rows = []
for nm in PRIM:
    for arm, lab in ARMS[1:]:
        r = load('primary', arm, nm)
        if r is None:
            continue
        un, hu = col(r, 'clade_union_nonviable'), col(r, 'clade_hull_nonviable')
        ua, ha = col(r, 'clade_union_area'), col(r, 'clade_hull_area')
        rows.append([NAMES[nm], lab, f'{np.nanmean(un):.3f}', f'{np.nanmean(hu):.3f}', f'{np.nanmean(ua):.3f}', f'{np.nanmean(ha):.2f}',
                     f"{col(r, 'final_rho').mean() * 4:.3f}", f"{col(r, 'n_extinct').mean():.1f}", f"{col(r, 'n_excluded').mean():.1f}",
                     f"{col(r, 'n_splits').mean():.1f}", f"{col(r, 'n_births').mean():.1f}", f"{col(r, 'total_extinction').mean():.2f}"])
        S[f'clade/{arm}/{nm}'] = dict(union_nonviable=float(np.nanmean(un)), hull_nonviable=float(np.nanmean(hu)),
                                      union_area=float(np.nanmean(ua)), hull_area=float(np.nanmean(ha)),
                                      final_rho_f=float(col(r, 'final_rho').mean() * 4),
                                      extinct=float(col(r, 'n_extinct').mean()), excluded=float(col(r, 'n_excluded').mean()),
                                      splits=float(col(r, 'n_splits').mean()), births=float(col(r, 'n_births').mean()))
table('IDEA clades and events (means per run)',
      ['Landscape', 'Arm', 'union non-viable', 'hull non-viable', 'union area', 'hull area', 'final half-width (f.u.)',
       'extinctions', 'exclusions', 'speciations', 'births', 'total extinctions'], rows,
      'Areas in function units squared (the box has area 64). Non-viable: g < 0.5.')

# ------------------------------------------------------------------ DE paper metrics on lethal landscapes
rows = []
for nm in L.LANDSCAPES:
    r = load('primary', 'DE', nm)
    if r is None:
        continue
    rows.append([NAMES[nm], ms(col(r, 'paper_fitness')), ms(col(r, 'paper_entropy'), '{:.2f}'), ms(col(r, 'top_fit')), ms(col(r, 'top_entropy'), '{:.2f}')])
table('DE on the paper landscapes with fitness 0 outside: the paper\'s metrics (x0 estimates) vs output metrics',
      ['Landscape', 'paper fitness (x0)', 'paper entropy', 'top-64 output fitness', 'top-64 output entropy'], rows)

json.dump(S, open(os.path.join(OUT_R, 'summary.json'), 'w'), indent=1, default=float)
open(os.path.join(OUT_R, 'tables.md'), 'w').write('# IDEA study: tables\n\n' + '\n'.join(T))


# ================================================================== figures
def heat(ax, nm, outside='lethal'):
    s = np.linspace(-4, 4, 321)
    G = np.stack(np.meshgrid(s, s, indexing='ij'), -1).reshape(-1, 2)
    gv = (L.make_g(nm, outside) if nm != 'two_peak' else L.make_g(nm))(G).reshape(321, 321)
    ax.imshow(gv.T, origin='lower', extent=(-4, 4, -4, 4), cmap='Greys', vmin=0, vmax=1.6, interpolation='bilinear')
    O = L.OPTIMA[nm]
    ax.scatter(O[:, 0], O[:, 1], s=60, marker='+', color=INK, linewidths=1.2, zorder=6)
    ax.set_xlim(-4.2, 4.2); ax.set_ylim(-4.2, 4.2); ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)
    ax.set_aspect('equal')


def fig_landscapes(seed_idx=0):
    lands = L.LANDSCAPES + L.HELDOUT
    fig, axes = plt.subplots(2, len(lands), figsize=(2.05 * len(lands), 4.4))
    for j, nm in enumerate(lands):
        for i, (arm, lab, colr) in enumerate([('DE', 'DE', C_DE), ('IDEA_R', 'IDEA-R', C_R)]):
            ax = axes[i, j]
            heat(ax, nm)
            p = os.path.join(RU, 'primary', f'{arm}__{nm}.npz')
            if os.path.exists(p):
                A = np.load(p)
                if arm == 'DE':
                    X = A['x'][seed_idx] * 4
                    ax.scatter(X[:, 0], X[:, 1], s=5, color=colr, alpha=0.6, linewidths=0, zorder=5)
                else:
                    Cc, Rr = A['centres'][seed_idx] * 4, A['radii'][seed_idx] * 4
                    for c, r in zip(Cc, Rr):
                        ax.add_patch(Rectangle(c - r, 2 * r[0], 2 * r[1], facecolor=colr, alpha=0.35, edgecolor=colr, lw=0.8, zorder=5))
                    X = A['lives'][seed_idx] * 4
                    ax.scatter(X[:, 0], X[:, 1], s=2, color=colr, alpha=0.9, linewidths=0, zorder=5)
            if i == 0:
                ax.set_title(NAMES[nm], fontsize=9)
            if j == 0:
                ax.set_ylabel(lab, fontsize=9, color=INK2)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_F, 'fig_landscapes.png'), dpi=170)
    plt.close(fig)


def fig_tournament():
    fig, ax = plt.subplots(figsize=(5.6, 3.4))
    ax.axvspan(0.5, 2.0, color=GRID, alpha=0.6, lw=0, zorder=0)
    ax.text(1.0, 1.06, 'predicted window for the 0.5 crossing', ha='center', va='bottom', color=INK2, fontsize=8)
    for pre, lab, colr in (('T_sel', 'registered tournament (H4a)', C_DE), ('T_full', 'full dynamics', C_R)):
        P = [S.get(f'twopeak/{pre}/{m}', {}).get('tall', np.nan) for m in MULTS]
        ax.plot(MULTS, P, color=colr, marker='o', ms=5, mec=SURF, mew=1.5, label=lab, zorder=3)
    b7p = os.path.join(OUT_R, 'b7_model_tournament.json')
    if os.path.exists(b7p):
        B7 = json.load(open(b7p))
        ax.plot(MULTS, [B7[f'16/{m}'] for m in MULTS], color=C_L, marker='o', ms=5, mec=SURF, mew=1.5,
                label='model-matched: tall lineage survives (exploratory, A7)', zorder=3)
    ax.axhline(0.5, color=AXIS, lw=1)
    ax.step([0.2, 1.0, 5.0], [1.0, 0.0, 0.0], where='post', color=INK2, lw=1.2, ls='--',
            label='prediction (exact quantiles, expected radii)', zorder=2)
    ax.set_xlim(0.21, 4.8)
    ax.set_xscale('log'); ax.set_xticks(MULTS); ax.set_xticklabels([f'{m:g}' for m in MULTS])
    ax.minorticks_off()
    ax.set_ylim(-0.03, 1.12)
    ax.set_xlabel('initial radius / predicted critical radius  (ρ_T / ρ_T,crit)')
    ax.set_ylabel('share of runs keeping the tall peak')
    ax.legend(loc='lower left', fontsize=8)
    fig.tight_layout(); fig.savefig(os.path.join(OUT_F, 'fig_tournament.png'), dpi=170); plt.close(fig)


def fig_radius():
    lands = L.LANDSCAPES
    fig, axes = plt.subplots(1, len(lands), figsize=(2.3 * len(lands), 2.8), sharey=True)
    pairs = L.schedule_pairs(25)
    rep = np.array([math.sqrt((1 - ap) / (1 - at)) for at, ap in pairs])
    sig = np.array([0.1 * L.ddpm_sigma(at, ap) for at, ap in pairs])
    rhoT = 0.0125 / np.prod(rep) * 4
    pred = rhoT * np.cumprod(rep + math.sqrt(2 / math.pi) * sig)
    gen = np.arange(1, 25)
    for j, nm in enumerate(lands):
        ax = axes[j]
        ax.plot(gen, pred, color=INK2, lw=1.2, ls='--', label='schedule and mutation alone')
        for arm, sset, lab, colr in (('IDEA_R', 'primary', 'IDEA-R', C_R), ('IDEA_L', 'primary', 'IDEA-L', C_L),
                                     ('R_noG1', 'ablation', 'no schedule', C_DE)):
            r = load(sset, arm, nm)
            if r is None:
                continue
            Tr = np.array([x['med_rho_traj'] for x in r]) * 4
            ax.plot(gen, np.median(Tr, 0), color=colr, label=lab)
        ax.axhline(0.05, color=AXIS, lw=1)
        ax.set_yscale('log'); ax.set_title(NAMES[nm], fontsize=9); ax.set_xlabel('update')
        if j == 0:
            ax.set_ylabel('median half-width (function units)')
    axes[-1].legend(fontsize=7, loc='upper right')
    fig.tight_layout(); fig.savefig(os.path.join(OUT_F, 'fig_radius.png'), dpi=170); plt.close(fig)


def fig_optima():
    lands = L.LANDSCAPES + L.HELDOUT
    fig, ax = plt.subplots(figsize=(8.4, 3.2))
    w = 0.26
    for k, (arm, lab, colr) in enumerate([('DE', 'DE', C_DE), ('IDEA_R', 'IDEA-R', C_R), ('IDEA_L', 'IDEA-L', C_L)]):
        mv, lo, hi = [], [], []
        for nm in lands:
            d = S.get(f'primary/{arm}/{nm}/optima')
            n_opt = len(L.OPTIMA[nm])
            if d is None:
                mv.append(np.nan); lo.append(0); hi.append(0); continue
            mv.append(d['mean'] / n_opt); lo.append((d['mean'] - d['ci'][0]) / n_opt); hi.append((d['ci'][1] - d['mean']) / n_opt)
        x = np.arange(len(lands)) + (k - 1) * w
        ax.bar(x, mv, width=w - 0.03, color=colr, label=lab, zorder=3)
        ax.errorbar(x, mv, yerr=[lo, hi], fmt='none', ecolor=INK2, elinewidth=1, capsize=0, zorder=4)
    ax.set_xticks(np.arange(len(lands))); ax.set_xticklabels([NAMES[n] + f'\n({len(L.OPTIMA[n])})' for n in lands], fontsize=8)
    ax.set_ylabel('share of global optima kept'); ax.set_ylim(0, 1.05)
    ax.legend(fontsize=8, ncol=3, loc='upper right')
    ax.grid(axis='x', visible=False)
    fig.tight_layout(); fig.savefig(os.path.join(OUT_F, 'fig_optima.png'), dpi=170); plt.close(fig)


def fig_explosion():
    arms = ['X_full', 'X_noG1', 'X_noG2', 'X_noG3', 'X_noall']
    labs = ['all three kept', 'schedule removed', 'exclusion removed', 'extinction removed', 'all removed']
    fig, ax = plt.subplots(figsize=(6.0, 3.2))
    rng = np.random.default_rng(0)
    for k, arm in enumerate(arms):
        vals = []
        for nm in L.LANDSCAPES:
            r = load('explosion', arm, nm)
            if r is not None:
                vals.append(col(r, 'final_rho'))
        if not vals:
            continue
        v = np.concatenate(vals)
        ax.scatter(k + rng.uniform(-0.28, 0.28, len(v)), v, s=6, color=C_DE, alpha=0.35, linewidths=0, zorder=3)
        ax.plot([k - 0.32, k + 0.32], [np.median(v)] * 2, color=INK, lw=2, zorder=4)
    ax.axhline(1.0, color=C_R, lw=1.2)
    ax.text(4.45, 1.08, 'explosion threshold (domain half-width)', ha='right', va='bottom', fontsize=8, color=INK2)
    ax.set_yscale('log'); ax.set_xticks(range(len(arms))); ax.set_xticklabels(labs, fontsize=8)
    ax.set_xlabel('governors (moment-type radius estimate, no ρ_max)')
    ax.set_ylabel('median final half-width (population units)')
    ax.grid(axis='x', visible=False)
    fig.tight_layout(); fig.savefig(os.path.join(OUT_F, 'fig_explosion.png'), dpi=170); plt.close(fig)


fig_landscapes(); fig_tournament(); fig_radius(); fig_optima(); fig_explosion()
print('wrote', os.path.join(OUT_R, 'tables.md'), 'and figures')
