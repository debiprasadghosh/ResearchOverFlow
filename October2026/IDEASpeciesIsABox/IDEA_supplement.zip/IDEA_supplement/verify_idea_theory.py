"""Numerical checks of the IDEA propositions (T1-T13). Prints PASS/FAIL per check."""
import sys, math
import numpy as np
from scipy import stats, optimize
sys.path.insert(0, '/home/claude/idea')
import idealib as L

RESULTS = []


def check(name, ok, detail=''):
    RESULTS.append((name, bool(ok)))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}  {detail}")


rng = np.random.default_rng(12345)
alphas = L.cosine_alphas(25)
pairs = L.schedule_pairs(25)

# ---------------------------------------------------------------- T1 port fidelity
print("\nT1  Diffusion Evolution as stated (paper Eqs. 5, 8, 17, A.3) and as coded")
check("T1a cosine schedule: alpha in [0.000998, 0.999], increasing along the run",
      abs(alphas[-1] - 0.000998) < 1e-6 and abs(alphas[0] - 0.999) < 1e-12 and
      all(ap > at for at, ap in pairs), f"first pair {pairs[0]}, last pair {pairs[-1]}")
x = rng.standard_normal((300, 2)); fit = rng.uniform(0.05, 1.0, 300); at = 0.3
est = L.de_estimate(x, fit, at)
Kx = np.exp(-((x[:, None, :] - math.sqrt(at) * x[None, :, :]) ** 2).sum(-1) / (2 * (1 - at)))
ref = (fit[None, :] + 1e-9) * (Kx + 1e-9) / (1.0 / 300 + 1e-9)          # generator.py lines 41-48
ref_est = (ref @ x) / (ref.sum(1) + 1e-9)[:, None]
check("T1b port estimator equals the reference formula (with its 1e-9 floors)",
      np.abs(est - ref_est).max() < 1e-12, f"max |diff| = {np.abs(est - ref_est).max():.2e}")
W = fit[None, :] * Kx
eq8 = (W @ x) / W.sum(1, keepdims=True)
# floors: prob = W + eps (fit + K) + eps^2 (times a common constant); the shift of a weighted mean
# is at most 2 max|x| * (floor mass) / (W mass) per row
eps = 1e-9
floor_mass = eps * (fit[None, :] + Kx + eps).sum(1)
bound = 2 * np.abs(x).max() * floor_mass / W.sum(1)
diff = np.abs(est - eq8).max(1)
check("T1c ... and differs from Eq. 8 only by the floors: |diff| <= 2 max|x| floor mass / weight mass",
      np.all(diff <= bound + 1e-15), f"max |diff| = {diff.max():.2e}, largest bound {bound.max():.2e}")
x0 = eq8; ap = 0.4; sm = 0.1
r1 = np.random.default_rng(7); r2 = np.random.default_rng(7)
step = L.ddim_step(x, x0, at, ap, sm, r1)
sig = sm * math.sqrt((1 - ap) / (1 - at) * (1 - at / ap))
eps = (x - math.sqrt(at) * x0) / math.sqrt(1 - at)
eq5 = math.sqrt(ap) * x0 + math.sqrt(1 - ap - sig ** 2) * eps + sig * r2.standard_normal(x0.shape)
check("T1d port step equals Eq. 5 with Eq. 17 noise", np.abs(step - eq5).max() < 1e-12)
xt = rng.standard_normal(2); xx = rng.standard_normal(2); a = 0.37
lhs = stats.multivariate_normal(mean=math.sqrt(a) * xx, cov=(1 - a) * np.eye(2)).pdf(xt)
rhs = stats.multivariate_normal(mean=xt / math.sqrt(a), cov=(1 - a) / a * np.eye(2)).pdf(xx) / a
check("T1e App. A.3 identity in D = 2: N(x_t; sqrt(a) x, 1-a) = a^(-D/2) N(x; x_t/sqrt(a), (1-a)/a)",
      abs(lhs - rhs) / lhs < 1e-12, "(the paper's factor 1/sqrt(a) is the D = 1 case)")

# ---------------------------------------------------------------- T2 quantile equivariance
print("\nT2  Species fitness commutes with monotone fitness maps")
G = rng.uniform(0, 1, (1000, 16))
ok = True
for phi in (np.exp, np.log1p, lambda z: z ** 3, lambda z: np.floor(4 * z)):
    ok &= np.allclose(L.quantile_k(phi(G), 0.1), phi(L.quantile_k(G, 0.1)))
check("T2  quantile_q(phi(g)) = phi(quantile_q(g)) for nondecreasing phi (incl. a step map)", ok)

# ---------------------------------------------------------------- T3 nested boxes
print("\nT3  Monotonicity in the box")
h = lambda X: L.g_map('himmelblau', X, outside='lethal')
viol = 0
for _ in range(200):
    c = rng.uniform(-3, 3, 2); r1_ = rng.uniform(0.05, 0.5); r2_ = r1_ * rng.uniform(1.0, 3.0)
    s1 = np.linspace(-1, 1, 81)
    grid = np.stack(np.meshgrid(s1, s1, indexing='ij'), -1).reshape(-1, 2)
    m1 = h(c + r1_ * grid).min(); m2 = h(c + r2_ * grid).min()
    viol += m2 > m1 + 1e-12
check("T3a q = 0: the minimum over a larger box never exceeds that over a nested smaller box", viol == 0,
      f"200 nested pairs, {viol} violations")
# counterexample for q = 0.1: a box sitting mostly in a pit; enlarging it into high ground raises the quantile
f1 = lambda X: np.where(X[:, 0] < 0.3, 0.0, 1.0)
U = rng.uniform(-1, 1, (200000, 2))
qa = np.quantile(f1(0.0 + 0.5 * U), 0.1)                                  # [-0.5, 0.5]^2: 80% in the pit
qb = np.quantile(f1(np.array([4.5, 0.0]) + 5.0 * U), 0.1)                 # [-0.5, 9.5] x [-5, 5]: 8% in the pit
check("T3b q = 0.1: not monotone (a box containing another can have a higher 10th percentile)",
      qb > qa, f"inner box 10th pct {qa:.2f}, enclosing box 10th pct {qb:.2f}")


# ---------------------------------------------------------------- T4 kappa_q
print("\nT4  kappa_q: the (1-q)-quantile of |U| for U uniform on [-1, 1]^2")
def cdf_dist_square(u):
    if u <= 1:
        return math.pi * u * u / 4
    if u >= math.sqrt(2):
        return 1.0
    return (math.pi * u * u - 4 * u * u * math.acos(1 / u) + 4 * math.sqrt(u * u - 1)) / 4
kappa = {q: optimize.brentq(lambda u: cdf_dist_square(u) - (1 - q), 1e-9, math.sqrt(2) - 1e-12) for q in (0.1, 0.25)}
kappa[0.0] = math.sqrt(2)
mc = np.sqrt((rng.uniform(-1, 1, (2_000_000, 2)) ** 2).sum(1))
check("T4  kappa_0.1 (analytic) matches Monte Carlo", abs(kappa[0.1] - np.quantile(mc, 0.9)) < 2e-3,
      f"kappa_0 = {kappa[0.0]:.4f}, kappa_0.1 = {kappa[0.1]:.4f} (MC {np.quantile(mc, 0.9):.4f}), kappa_0.25 = {kappa[0.25]:.4f}")
K01 = kappa[0.1]

# ---------------------------------------------------------------- T5 flattest flip
print("\nT5  Survival of the flattest: two isotropic Gaussian peaks")
P = L.TWO_PEAK
h1, w1, h2, w2, th = P['h1'], P['w1'], P['h2'], P['w2'], 0.5
rho_star = math.sqrt(2 * math.log(h1 / h2) / (w1 ** -2 - w2 ** -2)) / K01
rho_v1 = w1 * math.sqrt(2 * math.log(h1 / th)) / K01
rho_v2 = w2 * math.sqrt(2 * math.log(h2 / th)) / K01
def Fq_mc(centre, rho, q=0.1, n=400000):
    X = centre + rho * rng.uniform(-1, 1, (n, 2))
    return np.quantile(L.g_two_peak(X), q)
ok = True; det = []
for rho, pred in ((0.8 * rho_star, 'tall'), (1.25 * rho_star, 'broad')):
    Ft, Fb = Fq_mc(P['a'], rho), Fq_mc(P['b'], rho)
    ok &= (Ft > Fb) == (pred == 'tall')
    det.append(f"rho={rho:.3f}: F_tall={Ft:.3f} F_broad={Fb:.3f}")
F_formula = h1 * math.exp(-(K01 * 0.3) ** 2 / (2 * w1 ** 2))
check("T5a F_q of a centred box = h exp(-kappa_q^2 rho^2 / 2w^2)", abs(Fq_mc(P['a'], 0.3) - F_formula) < 5e-3,
      f"rho=0.3: MC {Fq_mc(P['a'], 0.3):.4f} formula {F_formula:.4f}")
check("T5b the winner flips at rho* (function coords)", ok,
      f"rho* = {rho_star:.4f} ({rho_star / 4:.4f} pop); " + "; ".join(det))
check("T5c viability radii: F_q = theta at rho_v",
      abs(Fq_mc(P['a'], rho_v1) - th) < 6e-3 and abs(Fq_mc(P['b'], rho_v2) - th) < 6e-3,
      f"rho_v(tall) = {rho_v1:.4f} ({rho_v1 / 4:.4f} pop), rho_v(broad) = {rho_v2:.4f} ({rho_v2 / 4:.4f} pop)")

# ---------------------------------------------------------------- T6 order statistics
print("\nT6  The empirical quantile from n lives is an estimate, not a bound")
n, q = 16, 0.1; k = max(1, math.ceil(q * n - 1e-12))
trials = 200000
Ysamp = rng.uniform(0, 1, (trials, n))
Yk = np.partition(Ysamp, k - 1, axis=1)[:, k - 1]
p_below = (Yk <= q).mean()
p_theory = 1 - stats.binom.cdf(k - 1, n, q)
check("T6a P(Y_(k) <= y_q) = P(Bin(n, q) >= k)", abs(p_below - p_theory) < 4e-3,
      f"n={n}, k={k}: MC {p_below:.4f}, theory {p_theory:.4f}")
check("T6b E[F(Y_(k))] = k/(n+1)", abs(Yk.mean() - k / (n + 1)) < 2e-3, f"MC {Yk.mean():.4f}, k/(n+1) = {k / (n + 1):.4f}")
n95 = math.ceil(math.log(0.05) / math.log(1 - q))
check("T6c certificate: all n lives >= theta proves viable fraction > 1-q at confidence 1-(1-q)^n",
      abs((1 - q) ** 16 - 0.1853) < 1e-3 and n95 == 29,
      f"n=16 gives confidence {1 - (1 - q) ** 16:.3f}; 95% needs n >= {n95}")

# ---------------------------------------------------------------- T7 interval bound vs quantile
print("\nT7  Interval-arithmetic lower bound is not the lower quantile")
def isq(lo, hi):
    if lo >= 0: return lo * lo, hi * hi
    if hi <= 0: return hi * hi, lo * lo
    return 0.0, max(lo * lo, hi * hi)
def himmel_interval(xl, xh, yl, yh):
    a = isq(xl, xh); b = isq(yl, yh)
    u = (a[0] + yl - 11, a[1] + yh - 11); v = (xl + b[0] - 7, xh + b[1] - 7)
    su, sv = isq(*u), isq(*v)
    return su[0] + sv[0], su[1] + sv[1]
_, _, _, tgt, scale, maxd = L.SPEC['himmelblau']; pmin = math.exp(-maxd / scale)
gmap = lambda hval: max((math.exp(-hval / scale) - pmin) / (1 - pmin), 0.0)
n_ok, n_strict, n_dis, Nbox = 0, 0, 0, 400
s1 = np.linspace(-1, 1, 101)
grid = np.stack(np.meshgrid(s1, s1, indexing='ij'), -1).reshape(-1, 2)
for _ in range(Nbox):
    c = rng.uniform(-3.5, 3.5, 2); r = rng.uniform(0.05, 0.4, 2)
    lo_h, hi_h = himmel_interval(c[0] - r[0], c[0] + r[0], c[1] - r[1], c[1] + r[1])
    g_lb = gmap(hi_h)
    vals = L.g_map('himmelblau', c + r * grid)
    gmin, gq = vals.min(), np.quantile(vals, 0.1)
    n_ok += (g_lb <= gmin + 1e-12) and (gmin <= gq + 1e-12)
    n_strict += g_lb < gmin - 1e-6
    n_dis += (g_lb < 0.5) != (gq < 0.5)
check("T7  bound <= exact minimum <= 10th percentile on every box; the decisions differ on many boxes",
      n_ok == Nbox and n_dis > 0, f"{Nbox} boxes: bound strictly below the minimum on {n_strict}; "
      f"extinction at theta=0.5 decided differently on {n_dis}")

# ---------------------------------------------------------------- T8 radius schedule
print("\nT8  The radius update as written collapses early; the noise-ratio coefficient telescopes")
lit = np.array([math.sqrt(ap) for at, ap in pairs])
rep = np.array([math.sqrt((1 - ap) / (1 - at)) for at, ap in pairs])
check("T8a sketch coefficient sqrt(alpha_{t-1}): first step 0.0726, product over the run 6.8e-7",
      abs(lit[0] - 0.0726) < 1e-3 and abs(np.prod(lit) - 6.82e-7) < 1e-8, f"first {lit[0]:.4f}, product {np.prod(lit):.3e}")
check("T8b repaired coefficient sqrt((1-a_{t-1})/(1-a_t)) telescopes to sqrt((1-a_0)/(1-a_T))",
      abs(np.prod(rep) - math.sqrt((1 - alphas[0]) / (1 - alphas[-1]))) < 1e-12,
      f"product {np.prod(rep):.5f}; rho_T = rho_min / product = {0.0125 / np.prod(rep):.4f} for rho_min = 0.0125")
# literal recursion with relative radius noise, from rho_T, 10000 species
R0 = 0.0125 / np.prod(rep); rr = np.full(10000, R0); fr = []
for (at, ap) in pairs[:6]:
    sg = 0.1 * L.ddpm_sigma(at, ap)
    rr = np.clip(math.sqrt(ap) * rr + sg * rr * rng.standard_normal(rr.shape), 0.0125, 1.0)
    fr.append((rr <= 0.0125 + 1e-12).mean())
check("T8c with the sketch's coefficient every radius is at the floor within 5 updates",
      fr[4] == 1.0, "fraction at rho_min after updates 1..6: " + ", ".join(f"{v:.2f}" for v in fr))

# ---------------------------------------------------------------- T9 mean vs moment radius
print("\nT9  No growth from a mean-type radius update; union-style growth from a moment-matched one")
ok_mean, ok_mom, infl = True, True, []
for _ in range(500):
    m = 20; w = rng.dirichlet(np.ones(m)); rad = rng.uniform(0.01, 0.4, m); cen = rng.standard_normal(m)
    rm = w @ rad; chat = w @ cen
    mom = math.sqrt(3 * (w @ (rad ** 2 / 3 + (cen - chat) ** 2)))
    ok_mean &= rad.min() - 1e-15 <= rm <= rad.max() + 1e-15
    ok_mom &= mom >= math.sqrt(w @ rad ** 2) - 1e-12 >= rm - 2e-12
    infl.append(mom / rad.max())
check("T9a mean-type rho_hat lies in [min rho, max rho]", ok_mean)
check("T9b moment-matched rho_hat >= sqrt(sum w rho^2) >= mean-type, and exceeds every parent radius when centres are spread",
      ok_mom and np.median(infl) > 1, f"median moment / max parent radius = {np.median(infl):.2f}")

# ---------------------------------------------------------------- T10 gate and competition
print("\nT10 Gate: overlap implies zero gap; competition leaves no positive-volume overlap")
C = rng.standard_normal((40, 2)) * 0.5; Rb = rng.uniform(0.05, 0.4, (40, 2))
gap = L.box_gap(C, Rb)
ov = np.all(np.abs(C[:, None, :] - C[None, :, :]) < Rb[:, None, :] + Rb[None, :, :], axis=-1)
check("T10a vol(B_i ∩ B_j) > 0 implies gap = 0, so flow = 1{gap < eps_t} for eps_t > 0", np.all(gap[ov] == 0))
worst_pen, n_pairs, n_surv = 0.0, 0, 0
for trial in range(200):
    Ct = rng.standard_normal((40, 2)) * 0.5; Rt = rng.uniform(0.05, 0.4, (40, 2))
    S_test = [L.Species(c, r, F=float(f)) for c, r, f in zip(Ct, Rt, rng.uniform(0, 1, 40))]
    kept, _ = L.compete_boxes(S_test, 1e-4, 0.1)
    n_surv += len(kept)
    for i in range(len(kept)):
        for j in range(i + 1, len(kept)):
            pen = np.min((kept[i].r + kept[j].r) - np.abs(kept[i].c - kept[j].c))
            worst_pen = max(worst_pen, pen); n_pairs += 1
check("T10b competition leaves no positive-volume overlap (penetration <= 1e-12, rounding only)",
      worst_pen <= 1e-12, f"200 x 40 random boxes -> {n_surv} survivors; {n_pairs} pairs; largest penetration {worst_pen:.1e}")

# ---------------------------------------------------------------- T11 isolated drift
print("\nT11 An isolated point (or species) is not stationary under the DDIM step")
def mfac(at, ap, smv):
    s = smv * L.ddpm_sigma(at, ap)
    return math.sqrt(ap) + math.sqrt(max(1 - ap - s * s, 0)) * (1 - math.sqrt(at)) / math.sqrt(1 - at)
m01 = np.array([mfac(at, ap, 0.1) for at, ap in pairs]); m1 = np.array([mfac(at, ap, 1.0) for at, ap in pairs])
check("T11a with x0_hat = x_t the step multiplies x_t by m_t >= 1 (sigma_m = 0.1)", np.all(m01 >= 1),
      f"cumulative factor {np.prod(m01):.3f} (sigma_m = 0.1), {np.prod(m1):.3f} (sigma_m = 1); from mid-run (step 12): {np.prod(m01[12:]):.3f}")
# IDEA species with the gate closed: centre follows m_t c + sigma w regardless of fitness
c0 = np.array([0.5, -0.3]); reps = 20000
Cc = np.tile(c0, (reps, 1)); at, ap = pairs[10]
nxt = L.ddim_step(Cc, Cc, at, ap, 0.1, np.random.default_rng(3))
check("T11b an isolated IDEA species (c_hat = c) moves to m_t c + noise: no within-species selection",
      np.allclose(nxt.mean(0), mfac(at, ap, 0.1) * c0, atol=2e-3), f"E[c'] = {nxt.mean(0).round(4)}, m_t c = {(mfac(at, ap, 0.1) * c0).round(4)}")

# ---------------------------------------------------------------- T12 kernel normalisation
print("\nT12 If N(.) is read as a normalised density, donors are reweighted by (rho_i + rho_j)^-D")
ri, rj, rk = 0.05, 0.05, 0.10
f2 = ((ri + rk) / (ri + rj)) ** 2; f58 = ((ri + rk) / (ri + rj)) ** 58
check("T12 donor at equal distance with half the radius gets factor ((r_i+r_k)/(r_i+r_j))^D", f2 > 2,
      f"D=2: {f2:.2f}x; D=58 (the paper's cart-pole network): {f58:.2e}x")

# ---------------------------------------------------------------- T13 tournament prediction
print("\nT13 Two-peak tournament (16 species seeded on each peak): the tall lineage survives only while"
      " F_tall / F_broad >= theta alpha_t at every generation")
# Relative extinction (theta_t = theta alpha_t max_k F_k): the broad lineage never dies here
# (F_broad / F_tall > h2 / h1 = 0.7 > theta); the tall one dies at the first generation k with
# R(rho_k) = F_tall / F_broad < theta alpha_k, i.e. rho_k > b_k below.
# Radius trajectory without selection on radii: E[rho_{k+1}] = rho_k (s_k + E|xi| sigma_k),
# s_k = sqrt((1 - a_{k-1}) / (1 - a_k)), E|xi| = sqrt(2 / pi) (half-normal inflation).
at_k = np.array([at for at, ap in pairs])
sig_k = np.array([0.1 * L.ddpm_sigma(at, ap) for at, ap in pairs])
grow = rep + math.sqrt(2 / math.pi) * sig_k
cumg = np.concatenate([[1.0], np.cumprod(grow)[:-1]])          # rho_k / rho_T at evaluation k
cst = K01 ** 2 * (w1 ** -2 - w2 ** -2) / 2
b_k = np.sqrt(np.log(h1 / (h2 * 0.5 * at_k)) / cst)              # survival needs rho_k <= b_k
ratio = b_k / cumg
kk = int(np.argmin(ratio)); rhoT_crit = float(ratio[kk])
# simulate the deterministic recursion to confirm the closed form
def tall_survives(rhoT):
    r = rhoT
    for k in range(len(pairs)):
        Ft = h1 * math.exp(-(K01 * r) ** 2 / (2 * w1 ** 2)); Fb = h2 * math.exp(-(K01 * r) ** 2 / (2 * w2 ** 2))
        if Ft < 0.5 * at_k[k] * max(Ft, Fb):
            return False
        r = r * grow[k]
    return True
ok = tall_survives(0.999 * rhoT_crit) and not tall_survives(1.001 * rhoT_crit)
check("T13 critical initial radius of the tall lineage (relative theta, half-normal inflation, function coords)", ok,
      f"rho_T,crit = {rhoT_crit:.4f} f.u. ({rhoT_crit / 4:.4f} pop), binding at generation {kk} "
      f"(alpha = {at_k[kk]:.3f}, rho_k = {b_k[kk]:.3f}); expected inflation over the run x{np.prod(1 + math.sqrt(2 / math.pi) * sig_k):.2f}; "
      f"final radius / rho_T = {np.prod(grow):.4f}")
RHO_T_CRIT = rhoT_crit

# ---------------------------------------------------------------- T14 high dimension
print("\nT14 In high dimension the lower quantile of a box approaches the box mean")
def rast_terms(Xd):
    return Xd ** 2 - 10 * np.cos(2 * np.pi * Xd) + 10
fr = []
for Dd in (2, 8, 32, 128):
    Xb = 0.25 + 0.5 * rng.uniform(-1, 1, (20000, Dd))     # box [-0.25, 0.75]^D around a ridge point
    R = rast_terms(Xb).sum(1)
    worst = Dd * rast_terms(np.array([0.5])).max()        # every coordinate at the ridge x = 0.5 (the box maximum)
    fr.append((Dd, (np.quantile(R, 0.9) - R.mean()) / (worst - R.mean())))
check("T14 (q-quantile - mean) / (worst - mean) shrinks roughly like D^(-1/2)",
      all(fr[i][1] > fr[i + 1][1] for i in range(3)) and fr[-1][1] < 0.25 * fr[0][1],
      "; ".join(f"D={d}: {v:.3f}" for d, v in fr))

# ---------------------------------------------------------------- T15 union soundness needs exclusion
print("\nT15 The union of disjoint boxes is as viable as its boxes on average; overlap can make it worse than all")
# counterexample (1-D, exact): B1 = [0, 2], B2 = [1, 3], viable set V = [1, 2]
p1 = p2 = 0.5; p_union = 2.0 / 3.0
check("T15a with overlap, the union's non-viable share (2/3) exceeds every box's (1/2)", p_union > max(p1, p2))
hv = lambda X: L.g_map('himmelblau', X, outside='lethal')
worst_gap = -1.0
for trial in range(50):
    Ct = rng.uniform(-3, 3, (30, 2)); Rt = rng.uniform(0.1, 0.8, (30, 2))
    kept, _ = L.compete_boxes([L.Species(c, r, F=float(f)) for c, r, f in zip(Ct, Rt, rng.uniform(0, 1, 30))], 1e-3, 0.1)
    vols = np.array([np.prod(2 * s.r) for s in kept])
    pk = np.array([(hv(s.c + s.r * rng.uniform(-1, 1, (4000, 2))) < 0.5).mean() for s in kept])
    lo = np.min([s.c - s.r for s in kept], 0); hi = np.max([s.c + s.r for s in kept], 0)
    Xm = lo + (hi - lo) * rng.uniform(0, 1, (400000, 2))
    inU = np.zeros(len(Xm), bool)
    for s in kept:
        inU |= np.all(np.abs(Xm - s.c) <= s.r, axis=1)
    pu = (hv(Xm[inU]) < 0.5).mean()
    pred = (vols * pk).sum() / vols.sum()
    worst_gap = max(worst_gap, abs(pu - pred))
check("T15b after exclusion (disjoint interiors) the union's non-viable share = volume-weighted mean of the boxes'",
      worst_gap < 0.01, f"50 random clades: largest |union - weighted mean| = {worst_gap:.4f} (Monte Carlo)")

# ---------------------------------------------------------------- T16 flight to flatness (landscapes as coded)
print("\nT16 As coded, the out-of-box plateaus compete with every box that fits inside the box")
grid1 = np.linspace(-1, 1, 21)
cell = np.stack(np.meshgrid(grid1, grid1, indexing='ij'), -1).reshape(-1, 2)
RHO_T_F = 0.0125 / np.prod(rep) * 4          # default initial radius, function coords (1.58)
def inside_F(gc, rho, step=0.1):
    cs = np.arange(-4 + rho, 4 - rho + 1e-9, step)
    Cg = np.stack(np.meshgrid(cs, cs, indexing='ij'), -1).reshape(-1, 2)
    Fv = np.concatenate([np.quantile(gc((ch[:, None, :] + rho * cell[None]).reshape(-1, 2)).reshape(len(ch), -1), 0.1, axis=1)
                         for ch in np.array_split(Cg, max(1, len(Cg) // 2000))])
    return Fv
det, ok = [], True
for nm in ('rosenbrock', 'beale', 'himmelblau'):
    gc = lambda X, nm=nm: L.g_map(nm, X, outside='coded')
    plateau = float(gc(np.array([[5.0, 5.0]]))[0])
    Fv = inside_F(gc, RHO_T_F)
    share = float((Fv < plateau).mean())
    det.append(f"{nm}: plateau {plateau:.4f}, best inside box at rho_T {Fv.max():.4f}, share of inside boxes below the plateau {share:.3f}")
    if nm == 'rosenbrock':
        lo_r, hi_r = 0.8, 1.6
        for _ in range(7):
            mid = 0.5 * (lo_r + hi_r)
            if inside_F(gc, mid).max() < plateau: hi_r = mid
            else: lo_r = mid
        det.append(f"rosenbrock crossover radius in [{lo_r:.3f}, {hi_r:.3f}] f.u.")
        ok &= Fv.max() < plateau and hi_r < RHO_T_F
check("T16 Rosenbrock: at rho_T = 1.58 f.u. the outside plateau (0.706) beats every box that fits inside",
      ok, " | ".join(det))

# ---------------------------------------------------------------- T17 held-out landscapes
print("\nT17 Held-out landscapes: calibration and optima (landscape evaluations only; no algorithm runs)")
sH = np.linspace(-4, 4, 1601)
GH = np.stack(np.meshgrid(sH, sH, indexing='ij'), -1).reshape(-1, 2)
det, ok = [], True
for nm in L.HELDOUT:
    gv = L.make_g(nm)(GH)
    fr_ = float((gv >= 0.5).mean()); go = L.make_g(nm)(L.OPTIMA[nm])
    det.append(f"{nm}: share g>=0.5 {fr_:.4f}, {len(L.OPTIMA[nm])} optima with g in [{go.min():.6f}, {go.max():.6f}], delta {L.optimum_radius(nm):.4f}")
    ok &= abs(fr_ - 0.10) < 0.002 and go.min() > 0.9999 and np.all(np.abs(L.OPTIMA[nm]) < 4)
check("T17 10% of the box has g >= 0.5; every listed optimum has g = 1 inside the box", ok, " | ".join(det))

print(f"\n{sum(ok for _, ok in RESULTS)}/{len(RESULTS)} checks passed")
if not all(ok for _, ok in RESULTS):
    sys.exit(1)
