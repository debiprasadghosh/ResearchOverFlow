"""Appendix tables of the IDEA paper, printed as Markdown from evals/ (written after the runs)."""
import sys, os, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import idealib as L
EV = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'evals')
NAMES = dict(rosenbrock='Rosenbrock', beale='Beale', himmelblau='Himmelblau', ackley='Ackley', rastrigin='Rastrigin',
             sixhump='Six-hump camel', shubert='Shubert', vincent='Vincent')
def load(sset, arm, nm):
    return json.load(open(os.path.join(EV, sset, f'{arm}__{nm}.json')))['runs']
def m(sset, arm, nm, key):
    return np.mean([r[key] for r in load(sset, arm, nm)])

print('**Table B1. Quality, viability, robustness and diversity** (means over 100 runs; DE / IDEA-R / IDEA-L).\n')
print('| Landscape | fitness of the 64 best | best output | viable share | robustness (0.2) | entropy (bits) | basins |')
print('|---|---|---|---|---|---|---|')
for nm in L.LANDSCAPES + L.HELDOUT:
    cells = []
    for key, f in (('top_fit', '{:.3f}'), ('best', '{:.3f}'), ('viable_frac', '{:.2f}'), ('robust_0.2', '{:.3f}'),
                   ('top_entropy', '{:.2f}'), ('basins', '{:.2f}')):
        cells.append(' / '.join(f.format(m('primary', a, nm, key)) for a in ('DE', 'IDEA_R', 'IDEA_L')))
    print(f'| {NAMES[nm]} | ' + ' | '.join(cells) + ' |')

print('\n**Table B2. Exploratory ablations: optima kept** (means over 100 runs; paper landscapes, fitness 0 outside; every arm at 12,800 evaluations except DE with N = 32, at 800).\n')
arms = [('DE', 'DE', 'primary'), ('DE_sm1', 'DE, σ_m = 1', 'ablation'), ('DE_N32', 'DE, N = 32', 'ablation'),
        ('IDEA_R', 'IDEA-R', 'primary'), ('R_noG1', 'no schedule', 'ablation'), ('R_noG2', 'no exclusion', 'ablation'),
        ('R_noG3', 'no extinction', 'ablation'), ('R_nospec', 'no speciation', 'ablation'),
        ('R_abstheta', 'absolute threshold', 'ablation'), ('R_normK', 'normalised kernel', 'ablation'),
        ('R_fitbirth', 'fitness-proportional birth', 'ablation'), ('R_within', 'within-species centres', 'ablation'),
        ('R_gauss', 'symmetric radius mutation', 'ablation'), ('R_K128', 'K = 128, n = 4', 'ablation'), ('IDEA_L', 'IDEA-L', 'primary')]
print('| Arm | ' + ' | '.join(NAMES[n] for n in L.LANDSCAPES) + ' |')
print('|---|' + '---|' * len(L.LANDSCAPES))
for arm, lab, sset in arms:
    print(f'| {lab} | ' + ' | '.join(f"{m(sset, arm, nm, 'optima'):.2f}" for nm in L.LANDSCAPES) + ' |')

print('\n**Table B3. The same ablations: fitness of the 64 best outputs / viable share.**\n')
print('| Arm | ' + ' | '.join(NAMES[n] for n in L.LANDSCAPES) + ' |')
print('|---|' + '---|' * len(L.LANDSCAPES))
for arm, lab, sset in arms:
    print(f'| {lab} | ' + ' | '.join(f"{m(sset, arm, nm, 'top_fit'):.3f} / {m(sset, arm, nm, 'viable_frac'):.2f}" for nm in L.LANDSCAPES) + ' |')

print('\n**Table B4. Explosion arms: runs exploded (of 100) / median final half-width (population units).**\n')
print('| Governors | ' + ' | '.join(NAMES[n] for n in L.LANDSCAPES) + ' |')
print('|---|' + '---|' * len(L.LANDSCAPES))
for arm, lab in (('X_full', 'all three kept'), ('X_noG1', 'schedule removed'), ('X_noG2', 'exclusion removed'), ('X_noG3', 'extinction removed'), ('X_noall', 'all removed')):
    row = []
    for nm in L.LANDSCAPES:
        fr = np.array([r['final_rho'] for r in load('explosion', arm, nm)])
        row.append(f'{int((fr >= 1).sum())} / {np.median(fr):.3f}')
    print(f'| {lab} | ' + ' | '.join(row) + ' |')

print('\n**Table B5. Two-peak tournament** (share of 100 runs keeping the tall / broad peak; mean share of species on the tall peak; median half-width after 12 updates, function units).\n')
print('| $m$ | $\\rho_T$ (f.u.) | registered tournament | species on tall | half-width at 12 | full dynamics | species on tall |')
print('|---|---|---|---|---|---|---|')
for mm in [0.25, 0.354, 0.5, 0.707, 1.0, 1.414, 2.0, 2.83, 4.0]:
    s = load('twopeak', f'T_sel_m{mm}', 'two_peak'); f = load('twopeak', f'T_full_m{mm}', 'two_peak')
    hw = np.median([r['med_rho_traj'][11] for r in s]) * 4
    print(f"| {mm:g} | {mm * 0.5908:.3f} | {np.mean([r['tall_kept'] for r in s]):.2f} / {np.mean([r['broad_kept'] for r in s]):.2f} | "
          f"{np.mean([r['share_on_tall'] for r in s]):.2f} | {hw:.3f} | {np.mean([r['tall_kept'] for r in f]):.2f} / {np.mean([r['broad_kept'] for r in f]):.2f} | "
          f"{np.mean([r['share_on_tall'] for r in f]):.2f} |")

print('\n**Table B6. Landscapes as coded** (DE / IDEA-R / IDEA-L; species centres outside: IDEA-R / IDEA-L).\n')
print('| Landscape | fitness of the 64 best | optima kept | outputs inside the box | species centres outside |')
print('|---|---|---|---|---|')
for nm in L.LANDSCAPES:
    c = [' / '.join(f.format(m('coded', a, nm, key)) for a in ('DE', 'IDEA_R', 'IDEA_L'))
         for key, f in (('top_fit', '{:.3f}'), ('optima', '{:.2f}'), ('inside_frac', '{:.2f}'))]
    c.append(' / '.join(f"{m('coded', a, nm, 'centres_outside'):.2f}" for a in ('IDEA_R', 'IDEA_L')))
    print(f'| {NAMES[nm]} | ' + ' | '.join(c) + ' |')

print('\n**Table B7. IDEA-R events and clade** (means per run).\n')
print('| Landscape | extinctions | exclusions | speciations | births | union non-viable | bounding box non-viable |')
print('|---|---|---|---|---|---|---|')
for nm in L.LANDSCAPES + L.HELDOUT:
    r = load('primary', 'IDEA_R', nm)
    g = lambda k: np.nanmean([x.get(k, np.nan) for x in r])
    print(f"| {NAMES[nm]} | {g('n_extinct'):.0f} | {g('n_excluded'):.0f} | {g('n_splits'):.0f} | {g('n_births'):.0f} | "
          f"{g('clade_union_nonviable'):.3f} | {g('clade_hull_nonviable'):.3f} |")
