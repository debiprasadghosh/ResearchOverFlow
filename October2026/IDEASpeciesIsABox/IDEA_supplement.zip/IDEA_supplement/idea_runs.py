"""All confirmatory runs of the IDEA study (PROTOCOL.md, Section 4).

    python3 idea_runs.py all [--workers 2]     # every cell, 100 seeds each
    python3 idea_runs.py smoke                  # 2 pilot seeds per cell, paper and two-peak landscapes only

Each (set, arm, landscape) cell is saved to runs/<set>/<arm>__<landscape>.npz with the raw outputs of
every seed; idea_eval.py computes the metrics. Seeds: run i uses np.random.default_rng(100000 + i).
"""
import sys, os, json, time, hashlib, math
import numpy as np
from multiprocessing import Pool

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import idealib as L

HERE = os.path.dirname(os.path.abspath(__file__))
N_SEEDS = 100
SEED0 = 100000
RHO_T_CRIT = 0.5908            # function units (verify_idea_theory.py, T13)
MULTS = [0.25, 0.354, 0.5, 0.707, 1.0, 1.414, 2.0, 2.83, 4.0]

ABL = {
    'R_noG1': dict(radius_rule='none'), 'R_noG2': dict(compete=False), 'R_noG3': dict(extinct=False),
    'R_nospec': dict(speciate=False), 'R_abstheta': dict(theta_mode='absolute'),
    'R_normK': dict(kernel_norm=True), 'R_fitbirth': dict(birth='fitness'), 'R_within': dict(within=True),
    'R_gauss': dict(rho_noise='gauss'), 'R_K128': dict(K=128, n=4),
}
EXPL = {
    'X_full': {}, 'X_noG1': dict(radius_rule='none'), 'X_noG2': dict(compete=False),
    'X_noG3': dict(extinct=False), 'X_noall': dict(radius_rule='none', compete=False, extinct=False),
}
for _k in EXPL:
    EXPL[_k].update(rhohat='moment', rho_max=np.inf)


def jobs():
    J = []
    for nm in L.LANDSCAPES + L.HELDOUT:
        for arm in ('DE', 'IDEA_R', 'IDEA_L'):
            J.append(('primary', arm, nm, 'lethal'))
    for nm in L.LANDSCAPES:
        for arm in ('DE', 'IDEA_R', 'IDEA_L'):
            J.append(('coded', arm, nm, 'coded'))
    for nm in L.LANDSCAPES:
        for arm in ['DE_sm1', 'DE_N32'] + list(ABL):
            J.append(('ablation', arm, nm, 'lethal'))
        for arm in EXPL:
            J.append(('explosion', arm, nm, 'lethal'))
    for m in MULTS:
        J.append(('twopeak', f'T_sel_m{m}', 'two_peak', None))
        J.append(('twopeak', f'T_full_m{m}', 'two_peak', None))
    for arm in ('T_DE_vitro', 'V_DE', 'V_IDEA_R'):
        J.append(('twopeak', arm, 'two_peak', None))
    return J


def arm_spec(arm):
    """('de' | 'idea', kwargs)."""
    if arm in ('DE', 'V_DE'):
        return 'de', {}
    if arm == 'DE_sm1':
        return 'de', dict(sigma_m=1.0)
    if arm == 'DE_N32':
        return 'de', dict(N=32)
    if arm == 'T_DE_vitro':
        P = L.TWO_PEAK
        return 'de', dict(x_init=np.vstack([np.tile(P['a'] / 4, (256, 1)), np.tile(P['b'] / 4, (256, 1))]))
    if arm in ('IDEA_R', 'V_IDEA_R'):
        return 'idea', {}
    if arm == 'IDEA_L':
        return 'idea', dict(radius_rule='literal')
    if arm in ABL:
        return 'idea', dict(ABL[arm])
    if arm in EXPL:
        return 'idea', dict(EXPL[arm])
    if arm.startswith('T_sel_m') or arm.startswith('T_full_m'):
        m = float(arm.split('_m')[1])
        P = L.TWO_PEAK
        kw = dict(init_centres=np.vstack([np.tile(P['a'] / 4, (16, 1)), np.tile(P['b'] / 4, (16, 1))]),
                  rho_init=m * RHO_T_CRIT / 4)
        if arm.startswith('T_sel'):
            kw['move_centres'] = False
        return 'idea', kw
    raise ValueError(arm)


def run_cell(job, seeds):
    sset, arm, nm, outside = job
    g = L.make_g(nm, outside) if outside is not None else L.make_g(nm)
    kind, kw = arm_spec(arm)
    rec = {}
    t0 = time.time()
    for s in seeds:
        rng = np.random.default_rng(s)
        if kind == 'de':
            r = L.de_run(g, rng, **kw)
            out = dict(x=r['x'], fit=r['fit'], x0=r['x0'], x0_fit=r['x0_fit'], n_eval=r['n_eval'])
        else:
            o = L.idea_run(g, rng, record=True, **kw)
            lg = o['log']
            out = dict(lives=o['lives'], lives_fit=o['lives_fit'], centres=o['centres'], radii=o['radii'],
                       F=o['F'], n_eval=o['n_eval'], total_extinction=lg['total_extinction'],
                       **{f'log_{k}': np.array(lg[k]) for k in ('n_species', 'frac_at_min', 'med_rho',
                                                               'extinct', 'excluded', 'splits', 'births', 'mean_F')})
        for k, v in out.items():
            rec.setdefault(k, []).append(np.asarray(v))
    arrays = {k: np.stack(v) for k, v in rec.items()}
    arrays['seeds'] = np.array(seeds)
    return arrays, time.time() - t0


def sha(path):
    return hashlib.sha256(open(path, 'rb').read()).hexdigest()


def work(args):
    job, seeds, outdir = args
    arrays, dt = run_cell(job, seeds)
    sset, arm, nm, outside = job
    os.makedirs(os.path.join(outdir, sset), exist_ok=True)
    path = os.path.join(outdir, sset, f'{arm}__{nm}.npz')
    np.savez_compressed(path, **arrays)
    meta = dict(set=sset, arm=arm, landscape=nm, outside=outside, seeds=[int(s) for s in seeds], seconds=dt,
                kind=arm_spec(arm)[0], kwargs={k: (v if not isinstance(v, np.ndarray) else 'array')
                                               for k, v in arm_spec(arm)[1].items()},
                sha_idealib=sha(os.path.join(HERE, 'idealib.py')), sha_runs=sha(os.path.abspath(__file__)))
    json.dump(meta, open(path.replace('.npz', '.json'), 'w'), indent=1, default=str)
    return f'{sset:9s} {arm:12s} {nm:10s} {dt:7.1f}s'


if __name__ == '__main__':
    mode = sys.argv[1] if len(sys.argv) > 1 else 'all'
    workers = int(sys.argv[sys.argv.index('--workers') + 1]) if '--workers' in sys.argv else 2
    if mode == 'smoke':
        J = [j for j in jobs() if j[2] not in L.HELDOUT]
        seeds, outdir = [9500, 9501], os.path.join(HERE, 'logs', 'smoke_runs')
    elif mode == 'all':
        J, seeds, outdir = jobs(), [SEED0 + i for i in range(N_SEEDS)], os.path.join(HERE, 'runs')
    else:
        raise SystemExit(__doc__)
    # longest cells first
    order = sorted(J, key=lambda j: (j[1] != 'R_K128', j[0] != 'primary'))
    t0 = time.time()
    with Pool(workers) as pool:
        for i, msg in enumerate(pool.imap_unordered(work, [(j, seeds, outdir) for j in order])):
            print(f'[{i + 1:3d}/{len(order)}] {msg}  ({time.time() - t0:.0f}s)', flush=True)
    print('done', len(order), 'cells')
