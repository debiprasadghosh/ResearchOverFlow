// Driver for the verified-transition study. Every printed number is exact or derived from exact counts.
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Globalization;
using System.IO;
using System.Linq;
using Tcr;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
string dir = args.Length > 0 ? args[0] : "out"; Directory.CreateDirectory(dir);
string F(object o) => o switch { bool b => b ? "1" : "0", double d => d.ToString("R", CultureInfo.InvariantCulture),
    string s => s, System.Collections.IEnumerable e => string.Join(" ", e.Cast<object>().Select(F)), _ => o.ToString() ?? "" };
void Emit(string k, params object[] v) => Console.WriteLine(k + "\t" + string.Join(" ", v.Select(F)));
if (args.Contains("--idc")) { IdcCensus.Run(dir, (k, v) => Emit(k, v)); return; }

const int n = 5;
var pairs = (from i in Enumerable.Range(0, n) from j in Enumerable.Range(i + 1, n - i - 1) select new Edge(i, j)).ToArray();
foreach (var (tag, grid, seed) in new[] { ("tenths", 10, 20261031001UL), ("hundredths", 100, 20261031002UL) })
{
var rng = new Rng(seed);
int graphs = 0, models = 0, queries = 0;
long validSets = 0, validMismatch = 0, invalidSets = 0, invExact = 0, invR2 = 0, invR1 = 0, inv001 = 0, inv005 = 0;
long naive = 0, naiveExact = 0, naiveR2 = 0, naive001 = 0, queriesInvR2 = 0, queriesWithInvalid = 0;
long backdoorSets = 0, validNotBackdoor = 0, backdoorNotValid = 0, multiQueries = 0, crossDisagree = 0;
double ratioSum = 0, ratioMax = 0;
var hist = new long[9];
var names = new[] { "honest", "invalid_set", "slip_outcome_table", "slip_marginal_table", "drop_action_condition", "slip_final_sum" };
var applied = new long[names.Length]; var accExact = new long[names.Length]; var accR2 = new long[names.Length];
var accOverlap = new long[names.Length]; var accCert = new long[names.Length];
var diffs = new List<string> { "abs_error" };
Q hundredth = Q.Of(1, 100);

for (int dm = 0; dm < 1 << pairs.Length; dm++)
{
    var g = Admg.Make(n, pairs.Where((_, k) => (dm >> k & 1) != 0), Array.Empty<Edge>()); graphs++;
    for (int r = 0; r < 3; r++)
    {
        CptModel model; (model, rng) = CptModel.Random(g, rng, grid); models++;
        var obs = model.Law();
        for (int x = 0; x < n; x++) for (int y = x + 1; y < n; y++)
        {
            if ((g.Ancestors(1 << y) >> x & 1) == 0) continue;
            int others = g.V & ~(1 << x | 1 << y);
            for (int xv = 0; xv <= 1; xv++)
            {
                queries++;
                Q truth = CptModel.Mass(model.Law(x, xv), 1 << y, 1 << y);
                var valid = new List<int>(); var invalid = new List<int>(); bool anyInvR2 = false;
                var answers = new Dictionary<int, Derivation>();
                for (int z = 0; z < 1 << n; z++)
                {
                    if ((z & ~others) != 0) continue;
                    var d = Derivation.Honest(obs, x, xv, y, z); answers[z] = d;
                    bool v = Adjustment.Valid(g, x, y, z), bd = Adjustment.BackDoor(g, x, y, z);
                    if (bd) backdoorSets++;
                    if (bd && !v) backdoorNotValid++;
                    Q diff = Rounding.Abs(d.Answer - truth);
                    if (v)
                    {
                        validSets++; valid.Add(z); if (!bd) validNotBackdoor++;
                        if (!diff.IsZero) validMismatch++;
                    }
                    else
                    {
                        invalidSets++; invalid.Add(z);
                        bool r2 = Rounding.Round(d.Answer, 2) == Rounding.Round(truth, 2);
                        if (diff.IsZero) invExact++;
                        if (r2) { invR2++; anyInvR2 = true; }
                        if (Rounding.Round(d.Answer, 1) == Rounding.Round(truth, 1)) invR1++;
                        if (diff <= hundredth) inv001++;
                        if (diff <= Q.Of(1, 20)) inv005++;
                        if (z == 0) { naive++; if (diff.IsZero) naiveExact++; if (r2) naiveR2++; if (diff <= hundredth) naive001++; }
                        diffs.Add(diff.ToDouble().ToString("R", CultureInfo.InvariantCulture));
                    }
                }
                if (invalid.Count > 0) queriesWithInvalid++;
                if (anyInvR2) queriesInvR2++;
                hist[valid.Count]++;
                if (valid.Count >= 2)
                {
                    multiQueries++;
                    var strata = valid.Select(z => 1 << SetBits.Count(z)).ToArray();
                    double ratio = (double)strata.Max() / strata.Min(); ratioSum += ratio; ratioMax = Math.Max(ratioMax, ratio);
                    if (valid.Select(z => answers[z].Answer).Distinct().Count() != 1) crossDisagree++;
                }
                if (valid.Count == 0) continue;
                int zs = valid.OrderBy(z => SetBits.Count(z)).ThenBy(z => z).First();
                var honest = answers[zs];
                void Judge(int kind, Derivation d)
                {
                    applied[kind]++;
                    if (d.Answer == truth) accExact[kind]++;
                    if (Rounding.Round(d.Answer, 2) == Rounding.Round(truth, 2)) accR2[kind]++;
                    if (d.OverlapAgrees()) accOverlap[kind]++;
                    if (d.Certified(g, obs, x, xv, y)) accCert[kind]++;
                }
                Q Sum(ImmutableArray<Q> t2, ImmutableArray<Q> t1) => Enumerable.Range(0, t1.Length).Aggregate(Q.Zero, (s, k) => s + t2[k] * t1[k]);
                Judge(0, honest);
                foreach (int z in invalid) Judge(1, answers[z]);
                int m = honest.T1.Length, z0 = Enumerable.Range(0, m).OrderByDescending(k => honest.T1[k]).ThenBy(k => k).First();
                Q step = honest.T2[z0] + hundredth <= Q.One ? hundredth : -hundredth;
                var t2s = honest.T2.SetItem(z0, honest.T2[z0] + step);
                Judge(2, honest with { T2 = t2s, Answer = Sum(t2s, honest.T1) });
                if (m > 1)
                {
                    int z1 = (z0 + 1) % m; Q mv = Q.Min(hundredth, honest.T1[z0]);
                    var t1s = honest.T1.SetItem(z0, honest.T1[z0] - mv).SetItem(z1, honest.T1[z1] + mv);
                    Judge(3, honest with { T1 = t1s, Answer = Sum(honest.T2, t1s) });
                }
                // drop the action from the conditioning set: P(Y = 1 | z) in place of P(Y = 1 | x, z)
                var t2d = Enumerable.Range(0, m).Select(k => honest.T0[2 * k] + honest.T0[2 * k + 1] == Q.Zero ? Q.Zero :
                    CptModel.Mass(obs, zs | 1 << y, Embed(zs, k) | 1 << y) / CptModel.Mass(obs, zs, Embed(zs, k))).ToImmutableArray();
                Judge(4, honest with { T2 = t2d, Answer = Sum(t2d, honest.T1) });
                Judge(5, honest with { Answer = honest.Answer + hundredth });
            }
        }
    }
}
Emit(tag + "_" + "family", graphs, models, queries);
Emit(tag + "_" + "valid_sets", validSets, validMismatch, backdoorSets, validNotBackdoor, backdoorNotValid);
Emit(tag + "_" + "invalid_sets", invalidSets, invExact, invR2, inv001, inv005, invR1);
Emit(tag + "_" + "naive_conditional", naive, naiveExact, naiveR2, naive001);
Emit(tag + "_" + "queries_invalid_pass_round2", queriesWithInvalid, queriesInvR2);
Emit(tag + "_" + "valid_set_histogram", hist);
Emit(tag + "_" + "alternative_derivations", multiQueries, crossDisagree, ratioSum / multiQueries, ratioMax);
for (int k = 0; k < names.Length; k++)
    Emit(tag + "_" + "checker_" + names[k], applied[k], accExact[k], accR2[k], accOverlap[k], accCert[k]);
// acceptance precision of answer filtering, with the measured rounded-answer coincidence rate
double c = (double)invR2 / invalidSets;
foreach (int len in new[] { 5, 10, 20, 40 })
    Emit(tag + $"_precision_L{len}", new[] { 0.01, 0.02, 0.05 }.Select(eps => { double v = Math.Pow(1 - eps, len); return v / (v + (1 - v) * c); }).ToArray());
File.WriteAllLines(Path.Combine(dir, tag + "_invalid_abs_errors.csv"), diffs);
}
static int Embed(int zmask, int k) { int v = 0, j = 0; foreach (int i in SetBits.Of(zmask)) { v |= (k >> j & 1) << i; j++; } return v; }

