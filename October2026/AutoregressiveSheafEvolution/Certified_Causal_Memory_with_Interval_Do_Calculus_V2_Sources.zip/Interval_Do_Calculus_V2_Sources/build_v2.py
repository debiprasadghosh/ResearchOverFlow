"""Build Version 2 of 'Interval Do Calculus for Reusable Autoregressive Causal Computation' from the supplied Word file.

The supplied file is edited in place; its text, equations, tables and figure are kept. New material is converted by
Pandoc with the supplied file as reference document. Every number is read from the validated C# output cs_idc.txt."""
import copy, json, os, subprocess, tempfile
from docx import Document
from docx.shared import Inches
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from lxml import etree

H = os.path.dirname(os.path.abspath(__file__)); SRC = os.path.join(os.path.dirname(H), "in", "v1.docx")
OUT = os.path.join(H, "Interval_Do_Calculus_for_Reusable_ADC_V2.docx")
cs = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1].split() for l in open(os.path.join(H, "cs_idc.txt"))}
val = json.load(open(os.path.join(H, "validation_idc.json"))); assert val["all_passed"]
NCHK = len(val["checks"])
W_ = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"; WNS = f'xmlns:w="{W_}"'
doc = Document(SRC); body = doc.element.body
exec(open(os.path.join(H, "_helpers.py")).read())

def I(k): return [int(float(v)) for v in cs[k]]
def num(x): return f"{x:,}"
def pc(a, b, d=1): return f"{100 * a / b:.{d}f}%"
st, sh = I("tenths_surgery"), I("hundredths_surgery"); pairs_g = st[3] // 3
rf = I("iv_refinement"); sw = I("iv_solver_work"); ft = I("iv_face_test"); de = I("iv_decision")
r0, r1 = I("iv_repair_m0"), I("iv_repair_m1"); tr = cs["iv_transport"]
n_ref = rf[0]; fails = rf[10]; same = rf[5] + rf[6]
inc = lambda a, b: f"{100 * (b - a) / a:+.1f}%"

# ------------------------------------------------------------------ front matter
set_text(find("31 October 2026"), "Version 2, 1 November 2026")
replace_in(find("Autoregressive causal reasoning becomes expensive"),
    "The paper is conceptual: its examples are exact analytical constructions, and no new agent benchmark, training run or biological experiment is reported.",
    "Version 2 adds an immutable C# implementation whose exact rational simplex returns a witness and multipliers for every bound, with four "
    "algorithms for certified bounds, refinement service, multiplier repair and decision certificates. On 30,720 regimes per parameter grid, baseline "
    f"transmission equals node intervention on every non-target marginal, while the two clamp responses are reversed in {pc(sh[5], sh[3])} of finer-grid "
    f"queries. On 6,000 evidence refinements of an instrumental-variable response polytope, the stored witness survives for {pc(rf[2], n_ref)} of upper "
    f"endpoints, yet {pc(same, fails)} of lost witnesses leave the endpoint unchanged. Witness reuse removes {pc(n_ref * 2 - sw[1], n_ref * 2)} of endpoint "
    f"solves; an exact face test settles more endpoints but costs {inc(sw[2], ft[5])} in pivots. After the observed law moves by 0.05, old multipliers "
    f"remain valid in every case and exact in {pc(r1[2], r1[0])}, although {pc(r1[5], r1[0])} of old numerical bounds have become false. Joint contrast "
    f"certificates decide {pc(de[1], de[0])} of states against {pc(de[2], de[0])} for marginal subtraction. An independent Python program re-certifies every "
    "exported bound exactly. No agent benchmark, training run or biological experiment is reported.")
after(find("We define two distinct interval objects"), fragment(
    "Version 2 implements these contracts. Section 12.5 gives four algorithms, and Sections 12.6 to 12.10 report exact censuses that test Lemma 2.2, "
    "Proposition 2.3, Theorems 5.1, 5.2 and 5.4, Proposition 6.2 and Theorem 7.3 on finite families. Two short propositions, 12.1 and 12.2, explain what the "
    "census shows about refinement repair and joint decisions. The censuses measure behaviour of the stated algorithms; they are not benchmarks of an agent."))
append_text(find("Sections 2 and 3 define surgeries"), " Sections 12.5 to 12.10 add algorithms and an exact numerical census.")
set_text(find("12 Exact analytical examples", "Heading 1"), "12 Exact analytical examples and a numerical census")

# ------------------------------------------------------------------ tables and figure
t4 = table(["| Endpoint | Refinements | Stored witness feasible | Witness lost, endpoint unchanged | Endpoint moved | Witness feasible, endpoint moved |", "|---|---|---|---|---|---|",
            f"| Upper | {num(n_ref)} | {num(rf[2])} ({pc(rf[2], n_ref)}) | {num(rf[5])} ({pc(rf[5], n_ref)}) | {num(rf[8])} ({pc(rf[8], n_ref)}) | 0 |",
            f"| Lower | {num(n_ref)} | {num(rf[3])} ({pc(rf[3], n_ref)}) | {num(rf[6])} ({pc(rf[6], n_ref)}) | {num(rf[9])} ({pc(rf[9], n_ref)}) | 0 |"],
           [1300, 1300, 1700, 1800, 1560, 1700], "Table 4 Sharp endpoints after one valid evidence report")
t5 = table(["| Policy | Full endpoint solves | Phase-one face tests | Simplex pivots | Change in pivots |", "|---|---|---|---|---|",
            f"| Fresh solve at every step | {num(2 * n_ref)} | 0 | {num(sw[2])} | — |",
            f"| Reuse surviving witnesses (Algorithm 2, steps 1–2 and 4) | {num(sw[1])} | 0 | {num(sw[3])} | {inc(sw[2], sw[3])} |",
            f"| Add the face test (Algorithm 2, all steps) | {num(ft[3])} | {num(ft[0])} | {num(ft[5])} | {inc(sw[2], ft[5])} |"],
           [3400, 1500, 1500, 1500, 1460], "Table 5 Solver work over 6,000 refinements (pivots include the 2,000 initial solves shared by all policies)")
t6 = table(["| Change in the observed law | Laws | Repaired bound valid | Repaired bound exact | Excess at most 0.01 | Excess at most 0.05 | Old numerical bound now false |", "|---|---|---|---|---|---|---|",
            f"| Mass 0.01 moved between two types | {num(r0[0])} | {pc(r0[1], r0[0])} | {pc(r0[2], r0[0])} | {pc(r0[3], r0[0])} | {pc(r0[4], r0[0])} | {pc(r0[5], r0[0])} |",
            f"| Mass 0.05 moved between two types | {num(r1[0])} | {pc(r1[1], r1[0])} | {pc(r1[2], r1[0])} | {pc(r1[3], r1[0])} | {pc(r1[4], r1[0])} | {pc(r1[5], r1[0])} |"],
           [2160, 900, 1200, 1200, 1250, 1250, 1400], "Table 6 Multiplier repair of both endpoints after changed data")
fig2 = figure(os.path.join(H, "fig", "idc_reuse_and_repair.png"), "Figure 2 Endpoint reuse after refinement and multiplier repair after changed data",
              "Left: fate of the sharp upper and lower endpoints of P(Y_1 = 1) after each of 6,000 valid evidence reports. Right: outcome of evaluating (9) with "
              "the stored multipliers after the observed law changes, for 1,000 instances at each change size. Exact census; not a benchmark.",
              "Stacked bars for upper and lower endpoints showing witness survival, unchanged endpoints and moved endpoints; grouped bars showing exact and near-exact repair rates.")
# the pivot change of the witness policy is negative and printed with its sign by inc()

sec = fragment(rf"""## 12.5 Algorithms

Each algorithm returns a claim together with the data that let a separate checker accept it.

**Algorithm 1 (certified exact bound).** *Input:* rows $Eq = f$ and $Aq \le b$ on the response simplex, and a query $c$. *Output:* $(U, q_*, \lambda)$.

(1) Add slack variables to the inequality rows and the normalisation row, giving standard form. (2) Run a two-phase simplex method with Bland's rule in exact rational arithmetic. (3) Read the witness $q_*$ from the final basis. (4) Solve $B^{{\mathsf{{T}}}} y = c_B$ exactly on the optimal basis $B$. Check that every reduced cost is nonpositive and that $y^{{\mathsf{{T}}}} b = c^{{\mathsf{{T}}}} q_*$. (5) Return $U = c^{{\mathsf{{T}}}} q_*$, the witness and the multipliers without the normalisation row. Inequality multipliers are then nonnegative, and (9) evaluated at $\lambda$ equals $U$.

The returned triple certifies itself through Proposition 5.5. A checker needs only feasibility of $q_*$, the attained value and one evaluation of (9). It need not trust the solver.

**Algorithm 2 (service after an evidence refinement).** *Input:* a stored record $(U, q_*, \lambda)$ for $K$ and a certified refinement $K' \subseteq K$.

(1) Return $U$ immediately as an outer bound (Theorem 5.1). (2) If $q_*$ satisfies the added rows, $U$ is sharp on $K'$ (Corollary 5.3) and no solve is needed. (3) Otherwise test, by phase one only, whether $K' \cap \{{c^{{\mathsf{{T}}}} q = U\}}$ is nonempty. If it is, $U$ remains sharp with a new witness (Theorem 5.2). (4) Otherwise run Algorithm 1 on $K'$.

**Algorithm 3 (repair after changed data).** *Input:* stored multipliers $\lambda$ and new rows $(A', b')$ in the same response coordinates, aligned row by row. (1) Evaluate (9) at $\lambda$ to obtain a valid outer bound. (2) If it meets the requested tolerance, return it labelled *outer*. (3) Otherwise, or if sharpness is required, run Algorithm 1.

**Algorithm 4 (decision certificate).** For two actions with linear utilities, run Algorithm 1 on the contrast $c_1 - c_0$ in both directions. Certify the action whose contrast interval excludes zero. Marginal intervals are used only as a fallback outer bound.

**Proposition 12.1 (zero multipliers reproduce the old endpoint).** Let $\lambda$ be the multipliers returned by Algorithm 1 for $K$ and let $K'$ add rows. Then (9) evaluated on $K'$ with $(\lambda, 0)$ equals $U(K)$. Multiplier repair alone cannot tighten a bound after a pure refinement; any improvement needs new multipliers or a surviving witness argument.

*Proof.* The added rows contribute zero to $\lambda^{{\mathsf{{T}}}} b$ and to $A^{{\mathsf{{T}}}} \lambda$. The remaining expression is (9) on $K$, which equals $U(K)$ by step (5) of Algorithm 1. ∎

**Proposition 12.2 (the joint contrast is never wider).** For linear $c_1, c_0$ on a common set $K$,

$$\Big[\min_K (c_1 - c_0)^{{\mathsf{{T}}}} q,\ \max_K (c_1 - c_0)^{{\mathsf{{T}}}} q\Big] \subseteq \Big[\min_K c_1^{{\mathsf{{T}}}} q - \max_K c_0^{{\mathsf{{T}}}} q,\ \max_K c_1^{{\mathsf{{T}}}} q - \min_K c_0^{{\mathsf{{T}}}} q\Big].\quad\quad\text{{~~~~(25)}}$$

Every sign decision certified by marginal subtraction is therefore certified by Algorithm 4.

*Proof.* For each $q \in K$, $c_1^{{\mathsf{{T}}}} q - c_0^{{\mathsf{{T}}}} q$ lies between the right-hand endpoints. Taking the extrema over $q$ preserves the inclusion. ∎

## 12.6 Graph surgery on a finite DAG family

The first census uses all 1,024 DAGs on five binary events that respect one fixed order. Each graph receives three positive models whose conditional probabilities are drawn from tenths or hundredths, the family of Ghosh (2026b). For every event $X$ and value $x_0$, the census builds the outgoing baseline replacement of Definition 2.1 and compares it with $do(X = x_0)$. There are 30,720 regimes per grid. The marginal law of all events other than $X$ was identical in every regime, as Lemma 2.2 requires. The full joint law differed in every regime, because the replacement keeps the observational mechanism of $X$.

For every ordered pair in which $X$ is an ancestor of $Y$ (18,939 model-level queries per grid), the census compares $P(Y = 1 \mid do(X = 1))$ with $P(Y = 1 \mid do(X = 0))$. On the hundredths grid the active value gave the larger response in {num(sh[4])} queries, the smaller in {num(sh[5])} and an equal response in {num(sh[6])}. On the tenths grid the counts were {num(st[4])}, {num(st[5])} and {num(st[6])}. In {num(sh[7])} of the {num(pairs_g)} graph-level pairs ({pc(sh[7], pairs_g)}; tenths {pc(st[7], pairs_g)}), both orders occurred among the three models of the same graph. Proposition 2.3 is therefore the typical case in this family, not a constructed exception: the graph fixes neither direction.

## 12.7 Sequential evidence on an instrumental-variable polytope

The second census uses the binary instrumental-variable model with instrument $Z$, treatment $X$ and outcome $Y$ (Balke & Pearl, 1997). It has 16 response types, four for $X$ as a function of $Z$ and four for $Y$ as a function of $X$. Six observed cells $P(x, y \mid z)$ and normalisation give seven independent equality rows. Each of 1,000 instances draws a true response law with integer weights from 0 to 4, so the polytope is nonempty and contains the truth. Six reports then follow. Each report bounds the total mass of a random group of response types by an interval around its true value, with half-widths $k/40$ for $k \in \{{0,1,2,3\}}$. Every report is a valid refinement in the sense of Definition 3.3. The query is $P(Y_1 = 1)$, linear in the response law.

The old interval enclosed the new sharp interval in all {num(n_ref)} refinements (Theorem 5.1). Table 4 shows what happened to each sharp endpoint. A stored witness that survived always certified an unchanged endpoint, as Corollary 5.3 requires. The converse failed often: {num(same)} of the {num(fails)} lost witnesses ({pc(same, fails)}) left the endpoint unchanged, because another optimizer on the same face survived. This is the gap between the sufficient witness shortcut and the exact condition of Theorem 5.2. Proposition 12.1 held in all {num(rf[11])} refinements: repairing with zero multipliers on the added rows reproduced the old upper endpoint exactly.

Table 5 compares solver work. Reusing surviving witnesses avoided {num(2 * n_ref - sw[1])} of {num(2 * n_ref)} endpoint solves ({pc(2 * n_ref - sw[1], 2 * n_ref)}) and {pc(sw[2] - sw[3], sw[2])} of simplex pivots. The exact face test of Algorithm 2 settled all {num(ft[1])} unchanged endpoints with phase one alone and correctly sent the {num(ft[3])} moved endpoints to a full solve. Its cold-start phase one, however, cost more pivots than it saved: total pivots rose by {inc(sw[2], ft[5]).lstrip('+')} over the fresh policy. A test that answers more questions exactly is not automatically cheaper. A warm-started dual simplex method is the natural remedy and remains to be measured. Pivot counts are properties of this implementation and Bland's rule, not wall time.

## 12.8 Repair after changed data and query transport

For each instance, the step-0 multipliers of both endpoints were reused after the observed law changed (Algorithm 3). The change moves mass $0.01$ or $0.05$ between two response types of the true law, so the new polytope is not a subset of the old one and Theorem 5.1 does not apply. Table 6 reports the result. Every repaired bound was valid, as Theorem 5.4 guarantees. With the smaller change {pc(r0[2], r0[0])} were exact; with the larger change {pc(r1[2], r1[0])} were exact and {pc(r1[4], r1[0])} were within $0.05$. At the same time the old numerical bounds had become false in {pc(r0[5], r0[0])} and {pc(r1[5], r1[0])} of instances. This is the separation claimed in Section 12.2, now at scale: an obsolete bound can carry multipliers that still certify the new one.

For query transport, each instance perturbed every coefficient of the query by $-1/20$, $0$ or $1/20$. The transported interval (12) contained the fresh sharp interval in all {num(int(tr[1]))} cases. It was never exact, and on average it was {float(tr[4]):.3f} times as wide as the fresh interval. Transport is a cheap outer certificate, not a substitute for a solve when precision matters.

## 12.9 Decisions certified by the joint contrast

At each of the {num(de[0])} evidence states, Algorithm 4 compared treating ($X = 1$) with not treating, using the contrast $P(Y_1 = 1) - P(Y_0 = 1)$. The joint contrast interval excluded zero in {num(de[1])} states ({pc(de[1], de[0])}); marginal subtraction did so in {num(de[2])} ({pc(de[2], de[0])}). In {num(de[3])} states only the joint certificate decided, and in no state did marginal subtraction decide alone, as (25) requires. By the last report, {num(de[6])} instances were decided jointly and {num(de[7])} by marginal subtraction; the joint certificate decided strictly earlier in {num(de[8])}. Shared response types cancel in the contrast, as in Section 12.3.

## 12.10 Validation

An independent Python program checks every census line. For each of the 7,000 evidence states, it re-certifies the C# upper and lower endpoints exactly. The exported witness must be feasible and attain the value, and its own implementation of (9) at the exported multipliers must return the same value with nonnegative inequality multipliers. The other bounds are recomputed with the HiGHS solver in SciPy and agree within $1.4 \times 10^{{-15}}$. The face-test outcomes are recomputed as independent feasibility problems, and the surgery census is recomputed with integer-scaled laws and a replay of the random streams. All {NCHK} checks pass. Pivot counts are reported by the C# implementation and are not independently checked.

These are finite calculations on declared families. They show what the theorems and algorithms do there; the thresholds of hypotheses C1 to C3 remain prospective tests on frozen workloads.
""")
def split_at(els, heading):
    i = next(i for i, e in enumerate(els) if heading in "".join(e.itertext())); return els[:i], els[i:]
a, rest = split_at(sec, "12.7 Sequential evidence")
b, rest = split_at(rest, "12.8 Repair after changed data")
c, d = split_at(rest, "12.9 Decisions certified")
after(find("These constructions are worked proofs, not benchmark observations"), a + b + t4 + t5 + fig2 + c + t6 + d)

# ------------------------------------------------------------------ hypotheses, conclusion, appendix
after(find("Hypothesis C1 (refinement reuse"), fragment(
    f"*Census note.* On the workload of Section 12.7, witness reuse removed {pc(2 * n_ref - sw[1], 2 * n_ref)} of endpoint solves and {pc(sw[2] - sw[3], sw[2])} of pivots. The exact "
    f"face test removed more full solves but raised pivots by {inc(sw[2], ft[5]).lstrip('+')}. Solver calls are therefore not a proxy for solver time, and C1 must be scored in measured time."))
after(find("Hypothesis C2 (repair is useful"), fragment(
    f"*Census note.* In Section 12.8, stored multipliers met a tolerance of 0.01 without a solve in {pc(r0[3], r0[0])} and {pc(r1[3], r1[0])} of the two change families. "
    "This is consistent with C2 for those families. It does not test C2, whose request family must be frozen in advance."))
after(find("Hypothesis C3 (decision stopping"), fragment(
    f"*Census note.* In Section 12.9 the joint contrast decided {num(de[6])} instances by the last report against {num(de[7])} for marginal subtraction, and never decided later. "
    "C3 concerns refinement counts at matched regret tolerance, which this census does not vary."))
append_text(find("The first implementation should expose the certificate interface"),
    " The Version 2 census supplies a first instance: certificates reproduce exactly, witness reuse saves a fifth of the solver work, and a stricter exact test can cost more than it saves.")
replace_in(find("The manuscript's examples require only the displayed finite arithmetic."),
    "No runtime improvement, trained latent representation, neural localization or biological equivalence has been demonstrated here.",
    "Sections 12.5 to 12.10 report exact finite computations and pivot counts. No wall-time improvement, trained latent representation, neural localization or biological equivalence has been demonstrated here.")
set_text(find("Table 4 Assumptions attached to the principal results", "Caption"), "Table 7 Assumptions attached to the principal results")
refs = find("References", "Heading 1")
refs._p.addprevious(fragment("# Appendix B Reproduction\n")[0])
for e in fragment(
    "The source bundle contains the C# project (kernel/Idc.cs with the inherited exact rational, graph and model files), its output cs_idc.txt and the exported "
    "records out/iv_records.json. Run dotnet run -c Release --project kernel -- out --idc to reproduce them in about thirty seconds, then python "
    "validate_idc.py cs_idc.txt out/iv_records.json validation_idc.json, fig_idc.py for Figure 2 and build_v2.py for this document. The kernel targets "
    ".NET 8; the validator uses Python 3 with NumPy and SciPy. Public values are immutable records; simplex tableaux are local scratch storage."):
    refs._p.addprevious(e)
doc.core_properties.title = "Interval Do Calculus for Reusable Autoregressive Causal Computation, Version 2"
doc.save(OUT); print("saved", OUT)
exec(open(os.path.join(H, "_mathfix.py")).read())

# ------------------------------------------------------------------ settings.xml child order (inherited from the supplied file)
SORDER = ("writeProtection view zoom removePersonalInformation removeDateAndTime doNotDisplayPageBoundaries displayBackgroundShape "
          "printPostScriptOverText printFractionalCharacterWidth printFormsData embedTrueTypeFonts embedSystemFonts saveSubsetFonts saveFormsData "
          "mirrorMargins alignBordersAndEdges bordersDoNotSurroundHeader bordersDoNotSurroundFooter gutterAtTop hideSpellingErrors hideGrammaticalErrors "
          "activeWritingStyle proofState formsDesign attachedTemplate linkStyles stylePaneFormatFilter stylePaneSortMethod documentType mailMerge "
          "revisionView trackRevisions doNotTrackMoves doNotTrackFormatting documentProtection autoFormatOverride styleLockTheme styleLockQFSet "
          "defaultTabStop autoHyphenation consecutiveHyphenLimit hyphenationZone doNotHyphenateCaps showEnvelope summaryLength clickAndTypeStyle "
          "defaultTableStyle evenAndOddHeaders bookFoldRevPrinting bookFoldPrinting bookFoldPrintingSheets drawingGridHorizontalSpacing "
          "drawingGridVerticalSpacing displayHorizontalDrawingGridEvery displayVerticalDrawingGridEvery doNotUseMarginsForDrawingGridOrigin "
          "drawingGridHorizontalOrigin drawingGridVerticalOrigin doNotShadeFormData noPunctuationKerning characterSpacingControl printTwoOnOne "
          "strictFirstAndLastChars noLineBreaksAfter noLineBreaksBefore savePreviewPicture doNotValidateAgainstSchema saveInvalidXml ignoreMixedContent "
          "alwaysShowPlaceholderText doNotDemarcateInvalidXml saveXmlDataOnly useXSLTWhenSaving saveThroughXslt showXMLTags alwaysMergeEmptyNamespace "
          "updateFields hdrShapeDefaults footnotePr endnotePr compat docVars rsids mathPr attachedSchema themeFontLang clrSchemeMapping "
          "doNotIncludeSubdocsInStats doNotAutoCompressPictures forceUpgrade captions readModeInkLockDown smartTagType schemaLibrary shapeDefaults "
          "doNotEmbedSmartTags decimalSymbol listSeparator").split()
tmp = OUT + ".tmp"
with zipfile.ZipFile(OUT) as zi, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zo:
    for it in zi.infolist():
        data = zi.read(it.filename)
        if it.filename == "word/settings.xml":
            root = etree.fromstring(data); kids = list(root)
            for k in kids: root.remove(k)
            for k in sorted(kids, key=lambda k: SORDER.index(etree.QName(k).localname) if etree.QName(k).localname in SORDER else 999): root.append(k)
            for z in root.iter(f"{{{W_}}}zoom"):
                if z.get(f"{{{W_}}}percent") is None: z.set(f"{{{W_}}}percent", "100")
            data = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
        if it.filename == "word/numbering.xml":
            root = etree.fromstring(data)
            for e in list(root.iter(f"{{{W_}}}nsid")) + list(root.iter(f"{{{W_}}}tmpl")): e.set(f"{{{W_}}}val", e.get(f"{{{W_}}}val").zfill(8))
            data = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
        zo.writestr(it, data)
shutil.move(tmp, OUT); print("settings order fixed")
