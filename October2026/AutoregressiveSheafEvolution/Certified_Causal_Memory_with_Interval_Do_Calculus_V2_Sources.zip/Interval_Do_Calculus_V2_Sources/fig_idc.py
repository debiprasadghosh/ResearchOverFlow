"""Figure 2 of Version 2, drawn from the validated C# output cs_idc.txt."""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

H = Path(__file__).resolve().parent
cs = {l.split("\t")[0]: list(map(float, l.rstrip("\n").split("\t")[1].split())) for l in open(H / "cs_idc.txt")}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.titlesize": 11, "axes.labelsize": 10,
                     "axes.spines.top": False, "axes.spines.right": False, "savefig.facecolor": "white"})
BLUE, RUST, GREY = "#336982", "#a95235", "#9aa6ad"
r = cs["iv_refinement"]; n = r[0]
fig, ax = plt.subplots(1, 2, figsize=(9.4, 3.7), layout="constrained")
cats = ["Upper endpoint", "Lower endpoint"]
surv = [r[2] / n * 100, r[3] / n * 100]; same = [r[5] / n * 100, r[6] / n * 100]; chg = [r[8] / n * 100, r[9] / n * 100]
y = [1, 0]
ax[0].barh(y, surv, color=BLUE, height=0.5, label="Stored witness still feasible")
ax[0].barh(y, same, left=surv, color=GREY, height=0.5, label="Witness lost, endpoint unchanged")
ax[0].barh(y, chg, left=[a + b for a, b in zip(surv, same)], color=RUST, height=0.5, label="Endpoint moved")
for yi, a, b, c in zip(y, surv, same, chg):
    for left, w in ((0, a), (a, b), (a + b, c)):
        ax[0].text(left + w / 2, yi, f"{w:.1f}", ha="center", va="center", color="white", fontsize=9)
ax[0].set_yticks(y, cats); ax[0].set_xlim(0, 100); ax[0].set_xlabel("Share of 6,000 evidence refinements (%)")
ax[0].legend(frameon=False, fontsize=8, loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=1)
ax[0].set_title("A  What happens to a sharp endpoint")
labels = ["Exact", "Within 0.01", "Within 0.05", "Old bound\nnow false"]
for i, (key, lab, col) in enumerate((("iv_repair_m0", "Data moved by 0.01", BLUE), ("iv_repair_m1", "Data moved by 0.05", RUST))):
    v = cs[key]; vals = [v[2] / v[0] * 100, v[3] / v[0] * 100, v[4] / v[0] * 100, v[5] / v[0] * 100]
    xs = [k + (i - 0.5) * 0.36 for k in range(4)]
    bars = ax[1].bar(xs, vals, 0.33, color=col, label=lab)
    for b, val in zip(bars, vals): ax[1].text(b.get_x() + b.get_width() / 2, val + 1.5, f"{val:.1f}", ha="center", fontsize=8)
ax[1].set_xticks(range(4), labels); ax[1].set_ylim(0, 128); ax[1].set_ylabel("Share of 1,000 changed laws (%)")
ax[1].legend(frameon=False, fontsize=8, loc="upper center", ncol=2); ax[1].set_title("B  Old multipliers after the data change")
(H / "fig").mkdir(exist_ok=True)
fig.savefig(H / "fig/idc_reuse_and_repair.png", dpi=240); fig.savefig(H / "fig/idc_reuse_and_repair.svg"); plt.close(fig)
