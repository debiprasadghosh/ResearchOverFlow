"""Independent validation of the Interval Do Calculus numerics (cs_idc.txt, out/iv_records.json).

Every C# sharp bound is re-certified exactly from its own exported witness and multipliers: the witness must be
feasible and attain the value, and the multiplier bound of Theorem 5.4 (implemented here from the formula, with
inequality signs checked) must equal the same value. Bounds without exported certificates are recomputed with
SciPy's HiGHS solver. All counts are rebuilt from these values. The surgery census is recomputed with
integer-scaled laws. Usage: python validate_idc.py cs_idc.txt out/iv_records.json validation_idc.json"""
import json, math, sys
from fractions import Fraction as F
import numpy as np
from scipy.optimize import linprog

cs = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1].split() for l in open(sys.argv[1])}
R = json.load(open(sys.argv[2])); checks = []
def check(name, ok, detail=""):
    checks.append(dict(name=name, passed=bool(ok), detail=str(detail)[:300])); print(("PASS " if ok else "FAIL ") + name, str(detail)[:150], flush=True)
def eq(name, vals, tol=1e-12):
    got = cs[name]
    ok = len(got) == len(vals) and all((abs(float(g) - v) <= tol * max(1, abs(v))) if isinstance(v, float) else int(g) == v for g, v in zip(got, vals))
    check(name, ok, (got, vals))

T = 16
Xof = lambda k, z: (k >> 2) >> z & 1
Yof = lambda k, x: (k & 3) >> x & 1
CELLS = [(0, 0, 0), (0, 0, 1), (0, 1, 0), (1, 0, 0), (1, 0, 1), (1, 1, 0)]
DROWS = [[1 if Xof(k, z) == x and Yof(k, x) == y else 0 for k in range(T)] for z, x, y in CELLS]
C1 = [Yof(k, 1) for k in range(T)]; C0 = [Yof(k, 0) for k in range(T)]; ATE = [a - b for a, b in zip(C1, C0)]
grp = lambda mask: [mask >> k & 1 for k in range(T)]
dot = lambda a, b: sum(x * y for x, y in zip(a, b))

def rows_of(q, reports):
    rows = [list(r) for r in DROWS]; rhs = [dot(r, q) for r in DROWS]
    for mask, lo, hi in reports:
        g = grp(mask); rows += [g, [-v for v in g]]; rhs += [hi, -lo]
    return rows, rhs

def feasible(x, rows, rhs):
    if any(v < 0 for v in x) or sum(x) != 1: return False
    return all((dot(r, x) == b) if i < 6 else (dot(r, x) <= b) for i, (r, b) in enumerate(zip(rows, rhs)))

def repair(c, lam, rows, rhs):
    assert all(l >= 0 for l in lam[6:]), "negative inequality multiplier"
    return dot(lam, rhs) + max(c[k] - sum(l * r[k] for l, r in zip(lam, rows)) for k in range(T))

def lp(c, rows, rhs, sense):
    A_eq = np.array([r for r in rows[:6]] + [[1] * T], float); b_eq = np.array([float(v) for v in rhs[:6]] + [1.0])
    A_ub = np.array(rows[6:], float) if len(rows) > 6 else None; b_ub = np.array([float(v) for v in rhs[6:]]) if len(rows) > 6 else None
    res = linprog(-sense * np.array(c, float), A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq, bounds=(0, None), method="highs")
    assert res.status == 0
    return -sense * res.fun

def face_feasible(c, v, rows, rhs):
    A_eq = np.array([r for r in rows[:6]] + [[1] * T, c], float); b_eq = np.array([float(x) for x in rhs[:6]] + [1.0, float(v)])
    A_ub = np.array(rows[6:], float) if len(rows) > 6 else None; b_ub = np.array([float(x) for x in rhs[6:]]) if len(rows) > 6 else None
    return linprog(np.zeros(T), A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq, bounds=(0, None), method="highs").status == 0

t = [0] * 30; certified = 0; float_ok = True; worst = 0.0
rep = [[0] * 6 for _ in range(2)]; trans = [0, 0, 0, 0]; ratio = 0.0; face_ok = True
for rec in R:
    q = [F(v) for v in rec["q"]]; reports = []; prev = None; firstJ = firstM = -1
    for s, st in enumerate(rec["steps"]):
        if s > 0: reports.append((st["mask"], F(st["lo"]), F(st["hi"])))
        rows, rhs = rows_of(q, reports)
        U1, L1 = F(st["U1"]), F(st["L1"]); xU = [F(v) for v in st["xU"]]; xL = [F(v) for v in st["xL"]]
        yU = [F(v) for v in st["yU"]]; yL = [F(v) for v in st["yL"]]
        ok = feasible(xU, rows, rhs) and dot(C1, xU) == U1 and repair(C1, yU, rows, rhs) == U1 \
             and feasible(xL, rows, rhs) and dot(C1, xL) == L1 and -repair([-v for v in C1], yL, rows, rhs) == L1
        certified += ok
        vals = dict(U0=lp(C0, rows, rhs, 1), L0=lp(C0, rows, rhs, -1), Uate=lp(ATE, rows, rhs, 1), Late=lp(ATE, rows, rhs, -1))
        for k, v in vals.items():
            e = abs(float(F(st[k])) - v); worst = max(worst, e); float_ok &= e < 1e-9
        if prev is not None:
            pU, pL, pxU, pxL, pyU = prev
            t[0] += 1; t[1] += L1 >= pL and U1 <= pU
            wu, wl = feasible(pxU, rows, rhs), feasible(pxL, rows, rhs)
            t[2] += wu; t[3] += wl; t[4] += wu and wl
            t[5] += (not wu) and U1 == pU; t[6] += (not wl) and L1 == pL
            t[7] += (wu and U1 != pU) + (wl and L1 != pL); t[8] += U1 != pU; t[9] += L1 != pL
            t[10] += (not wu) + (not wl); t[11] += repair(C1, pyU + [0, 0], rows, rhs) == pU
            for w, c, old, new in ((wu, C1, pU, U1), (wl, [-v for v in C1], -pL, -L1)):
                if w: continue
                ff = face_feasible(c, old, rows, rhs); t[22] += 1; face_ok &= ff == (new == old)
                if ff: t[23] += 1; t[24] += new == old
                else: t[25] += 1; t[26] += new != old
        Ul, Ll, U0, L0 = F(st["Uate"]), F(st["Late"]), F(st["U0"]), F(st["L0"])
        mlo, mhi = L1 - U0, U1 - L0
        dj = Ll > 0 or Ul < 0; dm = mlo > 0 or mhi < 0
        t[12] += 1; t[13] += dj; t[14] += dm; t[15] += dj and not dm; t[16] += dm and not dj; t[17] += (mhi - mlo) >= (Ul - Ll)
        if dj and firstJ < 0: firstJ = s
        if dm and firstM < 0: firstM = s
        prev = (U1, L1, xU, xL, yU)
    t[18] += firstJ >= 0; t[19] += firstM >= 0; t[20] += firstJ >= 0 and (firstM < 0 or firstJ < firstM); t[21] += firstM >= 0 and firstJ > firstM
    # repairs after changed data, using the step-0 multipliers
    s0 = rec["steps"][0]; yU0 = [F(v) for v in s0["yU"]]; yL0 = [F(v) for v in s0["yL"]]; U0_, L0_ = F(s0["U1"]), F(s0["L1"])
    for mi, r in enumerate(rec["repairs"]):
        q2 = list(q); m = F(r["m"]); q2[r["i"]] -= m; q2[r["j"]] += m
        rows, rhs = rows_of(q2, [])
        BU = repair(C1, yU0, rows, rhs); BL = -repair([-v for v in C1], yL0, rows, rhs)
        U, L = F(r["U"]), F(r["L"])
        float_ok &= abs(float(U) - lp(C1, rows, rhs, 1)) < 1e-9 and abs(float(L) - lp(C1, rows, rhs, -1)) < 1e-9
        assert BU == F(r["BU"]) and BL == F(r["BL"])
        gap = max(BU - U, L - BL); a = rep[mi]
        a[0] += 1; a[1] += BU >= U and BL <= L; a[2] += gap == 0; a[3] += gap <= F(1, 100); a[4] += gap <= F(1, 20); a[5] += U > U0_ or L < L0_
    d = [F(v) for v in rec["d"]]; cp = [a + b for a, b in zip(C1, d)]; rows, rhs = rows_of(q, [])
    TU, TL = F(rec["TU"]), F(rec["TL"])
    float_ok &= abs(float(TU) - lp(cp, rows, rhs, 1)) < 1e-9 and abs(float(TL) - lp(cp, rows, rhs, -1)) < 1e-9
    tlo, thi = L0_ + min(d), U0_ + max(d)
    trans[0] += 1; trans[1] += tlo <= TL and TU <= thi; trans[2] += tlo == TL and thi == TU
    if TU - TL > 0: trans[3] += 1; ratio += float((thi - tlo) / (TU - TL))

check("iv_certificates_exact", certified == sum(len(r["steps"]) for r in R), certified)
check("iv_float_crosscheck", float_ok, worst)
check("iv_face_test_matches_theorem_5_2", face_ok)
eq("iv_refinement", t[:12]); eq("iv_solver_work", [2 * t[0], t[10], int(cs["iv_solver_work"][2]), int(cs["iv_solver_work"][3])])
eq("iv_face_test", t[22:27] + [int(cs["iv_face_test"][5])]); eq("iv_decision", t[12:22])
for mi in range(2): eq(f"iv_repair_m{mi}", rep[mi])
eq("iv_transport", trans + [ratio / trans[3]], tol=1e-9)

# ---------------------------------------------------------------- surgery census (integer-scaled laws)
class Rng:
    def __init__(s, st): s.s = st
    def next(s):
        s.s = (s.s + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF; z = s.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & 0xFFFFFFFFFFFFFFFF
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & 0xFFFFFFFFFFFFFFFF
        return z ^ (z >> 31)
    def int(s, lo, hi): return lo + math.floor((s.next() >> 11) * (1.0 / 9007199254740992.0) * (hi - lo + 1))
n = 5; PAIRS = [(i, j) for i in range(n) for j in range(i + 1, n)]
def anc(edges, s):
    s = set(s)
    while True:
        t2 = s | {a for a, b in edges if b in s}
        if t2 == s: return s
        s = t2
for tag, grid, seed in (("tenths", 10, 20261031001), ("hundredths", 100, 20261031002)):
    rng = Rng(seed); c = [0] * 8
    for dm in range(1 << len(PAIRS)):
        edges = [PAIRS[k] for k in range(len(PAIRS)) if dm >> k & 1]
        par = [sorted(a for a, b in edges if b == i) for i in range(n)]
        up, down = set(), set()
        for r in range(3):
            cpt = [[rng.int(1, grid - 1) for _ in range(1 << len(par[i]))] for i in range(n)]
            def f(i, v, arg):
                k = cpt[i][sum((arg >> p & 1) << j for j, p in enumerate(par[i]))]
                return k if v >> i & 1 else grid - k
            def dolaw(x, xv): return [0 if (v >> x & 1) != xv else math.prod(f(i, v, v) * grid ** 0 for i in range(n) if i != x) * grid for v in range(32)]
            for x in range(n):
                for xv in (0, 1):
                    c[0] += 1; D = dolaw(x, xv)
                    O = [math.prod(f(i, v, v if i == x else (v & ~(1 << x)) | xv << x) for i in range(n)) for v in range(32)]
                    md = {}; mo = {}
                    for v in range(32):
                        k = v & ~(1 << x); md[k] = md.get(k, 0) + D[v]; mo[k] = mo.get(k, 0) + O[v]
                    c[1] += all(md[k] == mo[k] for k in md); c[2] += D != O
            for x in range(n):
                for y in range(x + 1, n):
                    if x not in anc(edges, {y}): continue
                    c[3] += 1
                    p1 = sum(w for v, w in enumerate(dolaw(x, 1)) if v >> y & 1); p0 = sum(w for v, w in enumerate(dolaw(x, 0)) if v >> y & 1)
                    if p1 > p0: c[4] += 1; up.add((x, y))
                    elif p1 < p0: c[5] += 1; down.add((x, y))
                    else: c[6] += 1
        c[7] += len(up & down)
    eq(f"{tag}_surgery", c)
missing = [k for k in cs if not any(ch["name"] == k for ch in checks)]
for k in missing: check(k, False, "not validated")
json.dump(dict(checks=checks, all_passed=all(ch["passed"] for ch in checks), lines=len(cs)), open(sys.argv[3], "w"), indent=1)
print("ALL", all(ch["passed"] for ch in checks), "lines", len(cs), "checks", len(checks))
