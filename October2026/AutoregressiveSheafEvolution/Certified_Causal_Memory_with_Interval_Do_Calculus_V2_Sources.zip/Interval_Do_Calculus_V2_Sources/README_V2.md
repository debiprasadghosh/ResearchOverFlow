# Interval Do Calculus for Reusable ADC — Version 2 (1 November 2026)

New: Section 12.5 (Algorithms 1–4, Propositions 12.1–12.2) and Sections 12.6–12.10 (exact census), Tables 4–6,
Figure 2, Appendix B. The appendix assumptions table is renumbered Table 7.

Files
- kernel/ — C# (.NET 8) project. Idc.cs is new: exact simplex with witness and multipliers, IV response polytope,
  surgery census, sequential-evidence workload. Exact.cs, Graph.cs, Distill.cs are inherited from the series kernel.
- cs_idc.txt, out/iv_records.json — census output and exported certificates.
- validate_idc.py, validation_idc.json — independent Python validation (12 checks, all pass).
- fig_idc.py, fig/ — Figure 2.  build_v2.py (+ _helpers.py, _mathfix.py) — edits the supplied Word file.

Reproduce
    dotnet run -c Release --project kernel -- out --idc > cs_idc.txt
    python validate_idc.py cs_idc.txt out/iv_records.json validation_idc.json
    python fig_idc.py && python build_v2.py

Limits: pivot counts are implementation measurements (Bland's rule, cold starts), not wall time, and are not
independently checked. Families are declared finite families; no agent benchmark or training run.
