# Certified Causal Flow Distillation in Autoregressive Do Calculus — Version 3

2 November 2026. Author: Debi Prasad Ghosh.

## Scope

The target is the declared causal flow alone. No teacher architecture, attention pattern, latent coordinate system, or numerical implementation is copied. Version 3 extends the attached Version 2 with conditional-memory characterizations, inequality-aware identification, task-sensitive approximation, composition with intervention coverage, adaptive statistical source reuse, decision certificates, and falsifiable neuroscience hypotheses.

The final Word paper has 33 pages, native editable equations, seven tables, two retained figures and four reviewer comments. These are scoped finite-model derivations; no neural training, biological implementation, or end-to-end speed gain is claimed.

## Files and provenance

- `base_v2.docx` is the supplied authoritative Version 2 Word attachment, unchanged.
- `inherited_v2/` preserves every file in the supplied Version 2 source ZIP byte for byte, including original C# source, census records, figures and earlier source files.
- `additions_v3.md` is the new text, with markers for surgical insertion and numeric placeholders populated from `checks_v3.json`.
- `build_v3.py` edits `base_v2.docx` and imports native math via Pandoc; it generates `additions_v3_filled.md` and the Version 3 DOCX.
- `check_v3.py` contains 20 exact rational/integer examples illustrating the new results. They are not learned-student experiments or exhaustive verification of the proofs.
- `checks_v3_rerun.json` is a second clean-process run, byte-identical to `checks_v3.json`.
- `validation_v2_rerun.json` and its log record a fresh independent run of the supplied Python validator: 19 checks pass, covering all 16 C# census output lines. The C# census was preserved and NOT regenerated or recompiled for Version 3.
- `qa_v3.py` and `qa_v3.json` record structural, provenance and render-text checks. These do not constitute a complete OOXML schema validation.
- `SOURCE_NOTES_V3.md` records new literature and claim boundaries.

## Reproduction

Use Python 3.12, the packages in `requirements_v3.txt`, and Pandoc 3.1.3 (the installed version used here). Run from this extracted directory:

```bash
python check_v3.py > checks_v3.json
python check_v3.py > checks_v3_rerun.json
cmp checks_v3.json checks_v3_rerun.json
python build_v3.py
python inherited_v2/validate_flow.py inherited_v2/cs_flow.txt inherited_v2/out/flow_records.json validation_v2_rerun.json
```

`check_v3.py` itself needs only Python's standard library. The old `inherited_v2/build_v2.py` is retained for provenance; its historical external input path is not the Version 3 build route. Consult its original README for original C# generation commands.

The DOCX builder is reproducible in content and formatting; ZIP timestamps/metadata may differ. The stated byte reproducibility applies to the exact new JSON results, not necessarily to the DOCX container bytes. Render the output in Word or LibreOffice and inspect every page after editing. The audited 33-page rendering used the documents workflow renderer with LibreOffice.

The included QA script takes an optional rendered PDF for text bounds/page-count checks. Render artifacts are internal QA intermediates and are not included in this source ZIP.
