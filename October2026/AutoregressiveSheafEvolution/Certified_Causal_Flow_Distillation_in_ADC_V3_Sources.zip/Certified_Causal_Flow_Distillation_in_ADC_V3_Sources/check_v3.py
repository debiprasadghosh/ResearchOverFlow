"""Exact examples for the Version 3 conditional memory and certificate results."""
from fractions import Fraction as F
from itertools import product,combinations
from pathlib import Path
import json,sys

checks=[]
def ck(name,ok,**kw):
    if not ok:raise AssertionError(name)
    checks.append(dict(name=name,passed=True,**kw))
def dot(a,b):return sum((x*y for x,y in zip(a,b)),F(0))
def rank(M):
    A=[list(map(F,r)) for r in M];k=0
    if not A:return 0
    for j in range(len(A[0])):
        p=next((i for i in range(k,len(A)) if A[i][j]),None)
        if p is None:continue
        A[k],A[p]=A[p],A[k];v=A[k][j];A[k]=[x/v for x in A[k]]
        for i in range(len(A)):
            if i!=k:
                v=A[i][j];A[i]=[x-v*y for x,y in zip(A[i],A[k])]
        k+=1
        if k==len(A):break
    return k
def comps(n,k):
    if k==1:yield(n,);return
    for j in range(n+1):
        for t in comps(n-j,k-1):yield(j,)+t
def ratio(a,b,q):return dot(a,q)/dot(b,q)
one=[1]*4;a=[1,0,0,0];b=[1,1,0,0]
q1=[F(1,4),F(1,4),F(1,4),F(1,4)]
q2=[F(1,4),F(1,2),F(1,8),F(1,8)]
ck('numerator alone loses a nonconstant conditional',dot(a,q1)==dot(a,q2) and ratio(a,b,q1)==F(1,2) and ratio(a,b,q2)==F(1,3))
q3=[F(1,8),F(3,8),F(1,4),F(1,4)]
ck('denominator alone loses a nonconstant conditional',dot(b,q1)==dot(b,q3) and ratio(a,b,q3)==F(1,4))
ck('two linear coordinates suffice and are necessary',rank([one,a,b])-1==2)
# A constant conditional on q0=q1 can need no memory despite varying moments.
constant=[tuple(F(x,12) for x in z) for z in comps(12,4) if z[0]==z[1] and z[0]+z[1]>=3]
ck('constant conditional exception',len({ratio(a,b,q) for q in constant})==1 and len({dot(b,q) for q in constant})>1,grid_laws=len(constant))
a2=[0,0,1,0];b2=[0,0,1,1]
ck('two nonconstant ratios require three linear coordinates',rank([one,a,b,a2,b2])-1==3,linear_coordinates=3,nonlinear_ratio_coordinates=2)
grid=[tuple(F(x,8) for x in z) for z in comps(8,4) if 2<=z[0]+z[1]<=6]
moments={}
for q in grid:
    key=(dot(a,q),dot(b,q),dot(a2,q))
    value=(ratio(a,b,q),ratio(a2,b2,q))
    if key in moments:assert moments[key]==value
    moments[key]=value
ck('three coordinate recovery on supported grid',True,laws=len(grid))
# The ratio derivative determinant along each hidden memory direction.
v=[0,1,-1,0]
ck('derivative detects denominator leakage',dot(a,v)*dot(b,q1)-dot(b,v)*dot(a,q1)!=0)
v2=[0,0,1,-1]
ck('ratio invariant along preserved moment direction',all(dot(a,v2)*dot(b,q)-dot(b,v2)*dot(a,q)==0 for q in grid))
# Universal-tight inequalities can fix positive coordinates, not only zero atoms.
vertices=[(F(0),F(1,2),F(1,2)),(F(1,2),F(0),F(1,2))]
rows=[[1,1,1],[1,1,0],[-1,-1,0]]
ck('tight inequality changes affine dimension',rank(rows)==2 and rank([[1,1,1]])==1)
ck('positive atom identified by inequalities',all(q[2]==F(1,2) for q in vertices) and rank(rows+[[0,0,1]])==rank(rows))
ck('no zero atom is required',all(any(q[i]>0 for q in vertices) for i in range(3)))
# Constant denominator makes only the numerator direction necessary.
ck('constant denominator rank reduction',rank([one,a,one])-1==1)
# Exact task-sensitive conditioning bound.
p=[F(1,5),F(3,10),F(1,4),F(1,4)]
q=[F(21,100),F(31,100),F(24,100),F(24,100)]
beta=F(1,4);dn=abs(dot(a,q)-dot(a,p));db=abs(dot(b,q)-dot(b,p))
ck('weighted moment error certificate',abs(ratio(a,b,q)-ratio(a,b,p))<=(dn+db)/beta)
# Composition of distinct internal encodings for all nine perfect interventions.
actions=list(product((None,0,1),repeat=2));cases=0
def high(u,I):
    A=u[0] if I[0] is None else I[0]
    B=(A^u[1]) if I[1] is None else I[1]
    return A,B
def tauSM(s):
    A=1-s[0];B=A^s[1];return A,B^1
def tauMH(m):return m[0],m[1]^1
for u in product((0,1),repeat=2):
    for I in actions:
        A,B=high(u,I);low=(1-A,A^B)
        assert tauMH(tauSM(low))==(A,B);cases+=1
ck('abstraction maps compose on common backgrounds',True,background_intervention_cases=cases)
ck('intervention coverage is a separate premise',len([I for I in actions if I[1] is None])<len(actions))
def tv(x,y):return sum((abs(a-b) for a,b in zip(x,y)),F(0))/2
laws=[tuple(F(x,4) for x in z) for z in comps(4,3)]
for x,y,z in product(laws,repeat=3):assert tv(x,z)<=tv(x,y)+tv(y,z)
ck('common profile errors compose',True,triples=len(laws)**3)
# Reused source failures are counted once, even with dependent certificates.
worlds=set(range(16));fail1={0,1,2,3};fail2={3,4}
alpha1=F(len(fail1),16);alpha2=F(len(fail2),16)
ck('dependent sources obey a union budget',F(len(fail1|fail2),16)<=alpha1+alpha2,actual_failure=F(5,16),budget=alpha1+alpha2)
request_failures=[fail1,fail2]*10
ck('twenty reuses do not create twenty sources',set.union(*request_failures)==fail1|fail2,requests=len(request_failures),sources=2)
# Decisions can be fixed although probabilities are not identified.
K=[(F(i,8),1-F(i,8)) for i in range(2,7)]
utilities=[[1,1],[0,1]]
ck('one action is robustly optimal without point identification',all(dot(utilities[0],q)>=dot(utilities[1],q) for q in K) and len({dot(utilities[1],q) for q in K})>1)
T=[F(4,5),F(1,5)];S=[F(2,5),F(3,5)]
u=[[1,0],[0,1]];astar=max(range(2),key=lambda i:dot(u[i],S));truebest=max(dot(x,T) for x in u)
gaperr=max(abs(dot([x-y for x,y in zip(u[i],u[j])],T)-dot([x-y for x,y in zip(u[i],u[j])],S)) for i in range(2) for j in range(2))
ck('pairwise advantage error bounds regret',truebest-dot(u[astar],T)<=gaperr)
def enc(o):
    if isinstance(o,F):return str(o)
    raise TypeError()
result=dict(all_passed=True,checks=checks,checks_passed=len(checks),arithmetic='exact rational and integer enumeration')
out=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('checks_v3.json')
out.write_text(json.dumps(result,default=enc,sort_keys=True,indent=2)+'\n')
print(json.dumps(result,default=enc,sort_keys=True,indent=2))
