"""Surgical Version 3 update using the included authoritative Version 2 DOCX."""
from pathlib import Path
from copy import deepcopy
import json,re,subprocess,tempfile
from docx import Document
from docx.shared import Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_ALIGN_PARAGRAPH

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'base_v2.docx'
OUT=ROOT/'Certified_Causal_Flow_Distillation_in_ADC_V3.docx'
data=json.loads((ROOT/'checks_v3.json').read_text())
assert data['all_passed']
look={x['name']:x for x in data['checks']}
values={'COUNT':data['checks_passed'],'GRID':look['three coordinate recovery on supported grid']['laws'],'COMPOSE':look['abstraction maps compose on common backgrounds']['background_intervention_cases'],'TRIPLES':f"{look['common profile errors compose']['triples']:,}"}
src=(ROOT/'additions_v3.md').read_text()
for k,v in values.items():src=src.replace('@@'+k+'@@',str(v))
assert '@@' not in src
(ROOT/'additions_v3_filled.md').write_text(src)
chunks={}
for key,body in re.findall(r'<!-- ([A-Z0-9]+) -->\s*(.*?)(?=<!-- [A-Z0-9]+ -->|\Z)',src,re.S):chunks[key]=body
doc=Document(BASE)

def txt(el):return ''.join(el.xpath('.//w:t/text()|.//m:t/text()'))
def paragraph(starts):
    found=[p for p in doc.paragraphs if p.text.startswith(starts)]
    assert len(found)==1,(starts,len(found))
    return found[0]
def replace_plain(starts,new):
    p=paragraph(starts);p.text=new;return p
def fragment(md):
    with tempfile.TemporaryDirectory() as td:
        td=Path(td);(td/'f.md').write_text(md)
        subprocess.run(['pandoc',str(td/'f.md'),'-f','markdown+tex_math_dollars-auto_identifiers-fancy_lists','-o',str(td/'f.docx'),'--reference-doc='+str(BASE)],check=True)
        f=Document(td/'f.docx');els=[deepcopy(e) for e in f.element.body if e.tag!=qn('w:sectPr')]
        # Preserve external hyperlink relationships when importing fragment paragraphs.
        for e in els:
            for relnode in e.iter():
                rid=relnode.get(qn('r:id'))
                if rid:
                    rel=f.part.rels[rid]
                    assert rel.is_external
                    relnode.set(qn('r:id'),doc.part.relate_to(rel.target_ref,rel.reltype,is_external=True))
            for b in list(e.iter(qn('w:bookmarkStart')))+list(e.iter(qn('w:bookmarkEnd'))):b.getparent().remove(b)
            if e.tag!=qn('w:p'):continue
            ppr=e.find(qn('w:pPr'))
            if ppr is None:ppr=OxmlElement('w:pPr');e.insert(0,ppr)
            ps=ppr.find(qn('w:pStyle'))
            if ps is None:ps=OxmlElement('w:pStyle');ppr.insert(0,ps)
            if ps.get(qn('w:val')) in ('FirstParagraph','Compact',None):ps.set(qn('w:val'),'BodyText')
            isheading=ps.get(qn('w:val'),'').startswith('Heading')
            if not isheading and e.find(qn('m:oMathPara')) is None:
                jc=ppr.find(qn('w:jc'))
                if jc is None:jc=OxmlElement('w:jc');ppr.append(jc)
                jc.set(qn('w:val'),'both')
            for mr in e.iter(qn('m:r')):
                rpr=mr.find(qn('m:rPr'))
                wrpr=mr.find(qn('w:rPr'))
                if wrpr is None:wrpr=OxmlElement('w:rPr');mr.insert(1 if rpr is not None else 0,wrpr)
                if rpr is not None and mr[0] is not rpr:mr.remove(rpr);mr.insert(0,rpr)
                fonts=wrpr.find(qn('w:rFonts'))
                if fonts is None:fonts=OxmlElement('w:rFonts');wrpr.insert(0,fonts)
                fonts.set(qn('w:ascii'),'Cambria Math');fonts.set(qn('w:hAnsi'),'Cambria Math')
            # OMML delimiter properties have a specified order; some converters emit end before separator.
            order={qn('m:'+k):i for i,k in enumerate(('begChr','sepChr','endChr','grow','shp','ctrlPr'))}
            for dpr in e.iter(qn('m:dPr')):
                children=sorted(list(dpr),key=lambda c:order.get(c.tag,99))
                for ch in list(dpr):dpr.remove(ch)
                dpr.extend(children)
            if e.find(qn('m:oMathPara')) is not None:
                for mt in e.iter(qn('m:t')):
                    if re.fullmatch(r'\(\d+\)',mt.text or ''):
                        mt.text='\u00a0\u00a0\u00a0\u00a0'+mt.text;mt.set(qn('xml:space'),'preserve')
        for i,e in enumerate(els[:-1]):
            if e.tag==qn('w:p') and els[i+1].find(qn('m:oMathPara')) is not None:
                ppr=e.find(qn('w:pPr'))
                if ppr.find(qn('w:keepNext')) is None:ppr.insert(1,OxmlElement('w:keepNext'))
    return els
def before(starts,key):
    anchor=paragraph(starts)._p
    for e in fragment(chunks[key]):anchor.addprevious(e)

doc.paragraphs[0].text='Certified Causal Flow Distillation\nin Autoregressive Do Calculus'
doc.paragraphs[1].text='Conditional memory and compositional guarantees'
doc.paragraphs[3].text='Version 3, 2 November 2026'
abstract=(
'Distillation of Autoregressive Do Calculus (ADC) transfers a declared causal flow while allowing the student to choose its own implementation. '
'A shared response law connects factual evidence, interventions and alternative outcomes; separate agreement on predictions need not preserve that connection. '
'We retain the finite coherence and gluing contracts and the exact census of 1,000 instrumental-variable teachers. '
'This revision characterizes conditional-query memory directly. On a convex model family with positive denominators, exact recovery of a nonconstant conditional probability from linear memory requires preservation of both its numerator and denominator moment directions, even when decoding is nonlinear. '
'Constant conditional queries are an exception. The minimum linear dimension for a finite conditional family follows from the rank of its nonconstant moment rows. '
'We extend identification to universally tight inequality records, derive a task-sensitive approximation certificate and prove composition of causal realizations with explicit intervention coverage. '
'Simultaneous source coverage makes valid query bounds reusable under adaptive requests; repeated use of one record does not create new statistical evidence. '
'A separate decision certificate permits stopping before full flow identification. '
'The inherited independent validator passes all 19 checks again, and 20 new rational checks illustrate the added results. The original C# census is preserved and was not regenerated. '
'Recent cortical connectivity findings motivate tests of task alignment under representational compression, without identifying neural dimensionality with a response-memory rank. '
'An updated harness separates proposals, semantic records, primitive checks and evidence acquisition. No neural training, biological implementation or end-to-end speed advantage is established.')
doc.paragraphs[6].text=abstract
contrib=paragraph('Version 2 recompiles')
contrib.text=contrib.text.replace('Version 2 recompiles','Version 2 implemented').replace('are new.','were added.').replace('Every census line is recomputed','Every census line was crosschecked')
for e in fragment('Version 3 adds Lemma 6.8, Theorem 6.9, Corollary 6.10, Example 6.11, Proposition 7.5, Corollary 7.6, Theorem 8.4, Corollary 8.5, Theorems 10.3 and 10.4, and Algorithm 8. These are scoped finite-model derivations integrating linear algebra, conditional probability, causal abstraction and simultaneous coverage. The exact census is retained, its independent validator is rerun, and the new biological and learned-harness claims remain hypotheses.\n'):
    contrib._p.addnext(e);contrib=type(contrib)(e,doc._body)

before('7 Approximate flow','SECTION6')
before('8 Behavioral transfer','SECTION7')
before('9 A training programme','SECTION8')
before('11 Exact finite','SECTION10')
before('12 Neuroscience','SECTION11')
before('13 Falsifiable','SECTION12')
before('14 Limits','SECTION13')
before('Appendix B','APPENDIX')

# Strengthen the scope of the inherited intervention abstraction contract.
p=paragraph('for every allowed background and intervention, with')
for e in fragment('Every semantic intervention included in the certificate must be in the image of the declared intervention map. Otherwise Theorem 8.2 applies only to the represented image, not to all task interventions.\n'):p._p.addnext(e)

# Repair the inherited reproduction command and remove a machine-specific timing claim.
p=paragraph('Version 2 adds kernel/Flow.cs')
p.text='Version 2 added kernel/Flow.cs to the series C# project. The census command is dotnet run -c Release --project kernel -- out --flow, with output redirected to cs_flow.txt. Then run python validate_flow.py cs_flow.txt out/flow_records.json validation_flow.json. The kernel targets .NET 8; the validator uses Python with NumPy and SciPy. The historical figure and Version 2 builders are retained for provenance; the portable Version 3 build is specified below.'

# The source skipped Table 4. Renumber its seven tables and local references consistently.
for el in doc.element.body.iter(qn('w:t')):
    if el.text:
        el.text=re.sub(r'\bTable ([5-8])\b',lambda m:'Table '+str(int(m.group(1))-1),el.text)
        el.text=el.text.replace('Tables 5–7','Tables 4–6').replace('Table 8','Table 7')

# Add bibliography items at the appropriate alphabetical positions.
for e in fragment(chunks['REFERENCES']):
    s=txt(e)
    if s.startswith('Anthropic.'):anchor=paragraph('Balke, A.')._p
    elif s.startswith('Chakravarthula,'):anchor=paragraph('Deng, X.')._p
    else:anchor=paragraph('Luo, X.')._p
    anchor.addprevious(e)

# Match inherited typography; retain the original seven tables and two figures.
for name in ('Title','Subtitle','Heading 1','Heading 2','Heading 3'):
    if name in doc.styles:
        doc.styles[name].font.color.rgb=RGBColor(0,0,0)
for p in doc.paragraphs:
    if p.style.name=='Title':p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    if p.text.startswith(('Lemma 6.8','Theorem 6.9','Corollary 6.10','Example 6.11','Proposition 7.5','Corollary 7.6','Theorem 8.4','Corollary 8.5','Theorem 10.3','Theorem 10.4','Algorithm 8','H7 ','H8 ','N4 ','N5 ')):
        p.paragraph_format.keep_together=True
    if p.style.name.startswith('Heading'):
        p.paragraph_format.keep_with_next=True
        for r in p.runs:r.font.color.rgb=RGBColor(0,0,0)
inrefs=False
for p in doc.paragraphs:
    if p.text=='References':
        inrefs=True;p.paragraph_format.page_break_before=False;continue
    if inrefs:
        p.alignment=WD_ALIGN_PARAGRAPH.LEFT
        p.paragraph_format.left_indent=doc.paragraphs[-1].paragraph_format.left_indent
        p.paragraph_format.first_line_indent=doc.paragraphs[-1].paragraph_format.first_line_indent
        for r in p.runs:
            r.font.name='Times New Roman';r.font.size=Pt(11.5)
        p.paragraph_format.space_after=Pt(8);p.paragraph_format.line_spacing=1.08

if 'CommentReference' not in doc.styles:
    st=doc.styles.add_style('CommentReference',WD_STYLE_TYPE.CHARACTER);st.font.superscript=True
for lead,note in [
('Theorem 6.9','Version 3 adds an exact dichotomy for linear memory with arbitrary decoding. Convexity, positive denominators and nonconstancy are essential; this is not a neural parameter minimum.'),
('Every semantic intervention included','The intervention coverage premise is now explicit. Without it, the earlier realization theorem only certifies the represented image.'),
('Theorem 10.3 (','Version 3 separates simultaneous statistical coverage from exact arithmetic and common-model feasibility. Reuse counts source dependencies once.'),
('Connectivity geometry and conditional memory','This new neuroscience subsection distinguishes the published October 2026 result from its accompanying preprint and from the proposed ADC interpretation.')]:
    p=paragraph(lead);runs=[r for r in p.runs if r.text.strip()]
    if runs:doc.add_comment(runs[0],note,author='Revision notes',initials='V3')

doc.core_properties.title='Certified Causal Flow Distillation in Autoregressive Do Calculus'
doc.core_properties.subject='Conditional memory and compositional guarantees'
doc.core_properties.author='Debi Prasad Ghosh'
doc.save(OUT)
print(json.dumps({'file':str(OUT),'paragraphs':len(doc.paragraphs),'tables':len(doc.tables),'figures':len(doc.inline_shapes),'native_equations':len(list(doc.element.iter(qn('m:oMath')))),'new_checks':data['checks_passed']},indent=2))
