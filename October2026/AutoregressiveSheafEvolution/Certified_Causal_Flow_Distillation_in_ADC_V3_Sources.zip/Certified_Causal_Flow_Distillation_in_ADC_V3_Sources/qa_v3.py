"""Scoped structural/provenance audit; not full OOXML XSD validation."""
from pathlib import Path
from zipfile import ZipFile
import json, hashlib, re, sys
from lxml import etree
from docx import Document

P=Path(__file__).resolve().parent
F=P/'Certified_Causal_Flow_Distillation_in_ADC_V3.docx'
N={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
   'm':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
checks=[]
def check(name,ok,detail=None):
    checks.append({'name':name,'passed':bool(ok),'detail':detail})
    assert ok, (name,detail)
with ZipFile(F) as z, ZipFile(P/'base_v2.docx') as b:
    check('DOCX ZIP CRC',z.testzip() is None)
    for n in z.namelist():
        if n.endswith(('.xml','.rels')): etree.fromstring(z.read(n))
    check('XML well formed',True)
    root=etree.fromstring(z.read('word/document.xml'))
    text=''.join(root.xpath('//w:t/text()|//m:t/text()',namespaces=N))
    check('No placeholders or retrieval tokens',not any(s in text for s in ('@@','turn180view','genui','TODO','TBD')))
    check('Native math retained',len(root.xpath('//m:oMath',namespaces=N))==409,
          len(root.xpath('//m:oMath',namespaces=N)))
    check('Display math present',len(root.xpath('//m:oMathPara',namespaces=N))==20,
          len(root.xpath('//m:oMathPara',namespaces=N)))
    imgs=[n for n in b.namelist() if n.startswith('word/media/')]
    check('Both original images unchanged',len(imgs)==2 and all(z.read(n)==b.read(n) for n in imgs))
    c=etree.fromstring(z.read('word/comments.xml'))
    ids=c.xpath('//w:comment/@w:id',namespaces=N)
    starts=root.xpath('//w:commentRangeStart/@w:id',namespaces=N)
    ends=root.xpath('//w:commentRangeEnd/@w:id',namespaces=N)
    refs=root.xpath('//w:commentReference/@w:id',namespaces=N)
    check('Four comment anchors matched',len(ids)==4 and sorted(ids)==sorted(starts)==sorted(ends)==sorted(refs))
    rel=etree.fromstring(z.read('word/_rels/document.xml.rels'))
    check('Comment relationship and content type',any(x.get('Type','').endswith('/comments') for x in rel)
          and b'/word/comments.xml' in z.read('[Content_Types].xml'))
a=Document(P/'base_v2.docx');d=Document(F)
cells=lambda t:[[c.text for c in r.cells] for r in t.rows]
check('Seven tables all original cell data unchanged',len(a.tables)==len(d.tables)==7 and all(cells(x)==cells(y) for x,y in zip(a.tables,d.tables)))
caps=[p.text for p in d.paragraphs if p.style.name=='Caption' and re.match(r'Table \d+ ',p.text)]
check('Contiguous table captions', [int(re.match(r'Table (\d+)',s)[1]) for s in caps]==list(range(1,8)))
for label in ('Lemma 6.8','Theorem 6.9','Corollary 6.10','Example 6.11','Proposition 7.5','Corollary 7.6','Theorem 8.4','Corollary 8.5','Theorem 10.3','Theorem 10.4','Algorithm 8'):
    check('New result '+label,label in text)
v=json.loads((P/'checks_v3.json').read_text())
check('Twenty exact examples pass',v['all_passed'] and v['checks_passed']==20 and all(x['passed'] for x in v['checks']))
check('Exact JSON clean-process rerun identical',(P/'checks_v3.json').read_bytes()==(P/'checks_v3_rerun.json').read_bytes())
v2=json.loads((P/'validation_v2_rerun.json').read_text())
check('Inherited validator 19 checks / 16 output lines',v2['all_passed'] and len(v2['checks'])==19 and v2['lines']==16)
sourcezip=P.parent/'upload/Causal_Flow_Distillation_in_ADC_V2_Sources.zip'
if sourcezip.exists():
    with ZipFile(sourcezip) as z:
        files=[n for n in z.namelist() if not n.endswith('/')]
        check('All inherited source files byte-identical',all((P/'inherited_v2'/Path(n).relative_to('Causal_Flow_Distillation_V2_Sources')).read_bytes()==z.read(n) for n in files),len(files))
if len(sys.argv)>1:
    import fitz
    pdf=fitz.open(sys.argv[1]);check('Rendered page count',len(pdf)==33,len(pdf))
    check('No blank rendered pages',all(len(p.get_text().strip())>30 for p in pdf))
    violations=[]
    for i,p in enumerate(pdf):
        for block in p.get_text('dict')['blocks']:
            for line in block.get('lines',[]):
                for span in line['spans']:
                    x0,y0,x1,y1=span['bbox']
                    if x0<60 or y0<30 or x1>560 or y1>795: violations.append([i+1,span['text'],span['bbox']])
    check('Rendered text within page boundaries',not violations,violations)
report={'all_passed':all(x['passed'] for x in checks),'checks':checks,
        'limitations':'Structural checks, not full OOXML XSD validation. Visual review is separate. Original C# census not regenerated.'}
(P/'qa_v3.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'all_passed':report['all_passed'],'checks':len(checks)}))
