# Version 3 source notes and claim boundaries

The supplied Version 2 Word document and ZIP are authoritative. All inherited table cells, images and source files are preserved. No percentage from the inherited C# census is presented as a new Version 3 run.

## New primary sources checked

1. Chakravarthula, L. N. C., Ito, T., Tzalavras, A., & Cole, M. W. (2026). Network geometry shapes the transformation of task representations across the human cortex. Nature Neuroscience, published 22 October 2026. https://doi.org/10.1038/s41593-026-02486-8 . Official article checked for the reported relationship between connectivity dimensions and representational compression/expansion. This is motivation for N4, not evidence that cortex computes ADC certificates or that neural dimension equals exact response-law memory rank.
2. Same authors, accompanying preprint, Version 3, 3 September 2026, DOI https://doi.org/10.1101/2025.03.14.643366 ; https://pmc.ncbi.nlm.nih.gov/articles/PMC13684672/ . Identified explicitly as a preprint. Its nonlinear simulation qualification is separate from the published article's reported human cortical findings.
3. Howard, S. R., Ramdas, A., McAuliffe, J., & Sekhon, J. (2021). Time-uniform, nonparametric, nonasymptotic confidence sequences. Annals of Statistics 49(2), 1055–1080. https://doi.org/10.1214/20-AOS1991 ; https://arxiv.org/abs/1810.08240 . Source for time-uniform statistical inference; Theorem 10.3 separately proves a union-bound statement under explicit coverage premises. It does not make arbitrary fixed-time intervals valid after selection.
4. Anthropic (2025, 26 November). Effective harnesses for long-running agents. https://www.anthropic.com/research/effective-harnesses-for-long-running-agents . Operational precedent for persistent artifacts across sessions, not a formal causal certificate method.
5. Anthropic (2026, 24 March). Harness design for long-running application development. https://www.anthropic.com/research/harness-design-long-running-apps . Operational precedent for generator/evaluator separation and verification cost. No vendor latency result is transferred to ADC.

Retained Zong et al. (2025), https://www.nature.com/articles/s41593-025-01928-z , was also checked as a caution against a compulsory serial hippocampal-teacher/cortical-copy account.

## New results and limits

Conditional-memory results require a nonempty compact convex finite response-law polytope, positive denominators and real linear memory; arbitrary decoding is permitted. Nonlinear encoders and nonconvex latent-independence families are outside the minimum linear dimension claim. Constant conditionals are an explicit exception. Common-profile approximation uses joint laws, not separate L2 marginals. Composition requires intervention coverage and matching background/evidence contracts. Statistical reuse requires a true law in the declared class and a simultaneous source-coverage contract. Source reuse does not manufacture new independent evidence. Utility gaps use fixed units and action sets. Biological predictions are prospective; no neural experiment was conducted.
