<!-- SECTION6 -->
## Conditional query memory

Version 2 characterizes linear moment memory. We now characterize the conditional queries themselves. Throughout this subsection, $K$ is a nonempty compact convex polytope, normalization is included in its equalities, and each declared denominator is positive throughout $K$. The memory is a real linear map $Lq$, but its decoder may be nonlinear. These assumptions exclude arbitrary nonlinear encoders and nonconvex latent-independence classes.

**Lemma 6.8 (the affine hull with inequality records).** Write $K=\{q:Eq=e,\ Gq\le h\}$, including nonnegativity among the inequalities. Let $J$ index the inequalities tight at every point of $K$, and put $H=[E;G_J]$. Then

$$T=\operatorname{span}(K-K)=\ker H.\qquad\text{(15)}$$

For $f(q)=a^\top q/(b^\top q)$ and any $q_0\in K$, put $p_0=f(q_0)$. The query is identified on $K$ exactly when $a-p_0b$ belongs to the row space of $H$.

**Proof.** Every difference of feasible points annihilates the equalities and the universally tight rows, so $T\subseteq\ker H$. For every other inequality there exists a feasible point where it is strict. Averaging these finitely many points gives a feasible point strict in all those rows simultaneously. Sufficiently short perturbations in any direction of $\ker H$ remain feasible, proving the reverse inclusion. The ratio is constant at $p_0$ exactly when $(a-p_0b)^\top q=0$ throughout $K$. Since it vanishes at $q_0$, this is equivalent to its annihilating $T$, hence to the stated row-space test. $\square$

Proposition 6.7 is the equality-plus-nonnegativity case. General interval records can identify a query through tight inequalities even when no response atom is forced to zero. For example, in the three-atom simplex, impose $q_1+q_2\le1/2$ and $q_1+q_2\ge1/2$. The third mass is fixed at $1/2$, although every atom is positive somewhere. A support-zero test alone misses the additional affine equality. A row is universally tight when its maximum slack over $K$ is zero; checking one optimizer's active set is insufficient.

**Theorem 6.9 (conditional memory dichotomy).** Let $a,b$ define a conditional query with $b^\top q>0$ on $K$, and put $N=\ker L\cap T$. If the query is nonconstant on $K$, its value is determined by $Lq$ for every $q\in K$ if and only if both $a$ and $b$ annihilate $N$. A constant query requires no varying memory coordinate, although its value and identification certificate remain scoped to $K$.

**Proof.** Sufficiency follows from Theorem 6.1: both moments are determined by the memory, so their ratio is determined. For necessity, fix $v\in N$ and $q$ in the relative interior of $K$. A short segment $q+tv$ stays feasible and has the same memory. Constancy of the decoded ratio on this segment implies

$$ (a^\top v)(b^\top q)-(b^\top v)(a^\top q)=0.\qquad\text{(16)}$$

Thus $a^\top v=f(q)b^\top v$. If $b^\top v\ne0$, the ratio has the same value $a^\top v/b^\top v$ throughout the relative interior. By continuity and density it is constant on $K$, contrary to the hypothesis. Therefore $b^\top v=0$ and then $a^\top v=0$. A constant query can be returned directly from its scoped identification record. $\square$

**Corollary 6.10 (minimum linear memory for conditional queries).** For finitely many supported conditional queries, remove those constant on $K$ and stack the remaining numerator and denominator rows in $C_*$. The minimum number of real linear memory coordinates, with arbitrary decoding, is

$$m_{\mathrm{cond}}=\operatorname{rank}(C_*|_T).\qquad\text{(17)}$$

**Proof.** Theorem 6.9 requires every remaining moment row to annihilate the hidden memory directions. Theorem 6.1 gives exactly the stated rank and an attaining linear coordinate basis. Constant-query values are fixed metadata for the contract. $\square$

**Example 6.11 (two answers can require three linear coordinates).** On the four-atom simplex restricted by $1/4\le q_1+q_2\le3/4$, request $q_1/(q_1+q_2)$ and $q_3/(q_3+q_4)$. Both queries are nonconstant. Their four moment rows span three directions beyond normalization, so exact linear memory needs three coordinates. A nonlinear encoder can simply store the two ratios for these current questions. Such storage need not support a new conditioning event. Conversely, on a family with $q_1=q_2$ and $q_1+q_2\ge1/4$, the first ratio is constantly $1/2$ and needs no varying coordinate. These examples explain precisely where the moment and ratio contracts differ.

For a fixed query family, refinement to a nonempty $K'\subseteq K$ cannot increase the minimum sufficient memory: an old decoder remains valid on the subset. New factual evidence can instead change the numerator and denominator rows. That is a new query contract, not merely population refinement, and the old rank or stored ratio need not suffice. The continuation quotient of Definition 6.5 must therefore include the permitted evidence operations.

<!-- SECTION7 -->
## Task specific approximation

**Proposition 7.5 (a moment certificate for approximate conditional memory).** Suppose on $K$ the moments admit $a^\top q=a_0+u^\top Lq$ and $b^\top q=b_0+v^\top Lq$. For teacher and student laws in $K$, let their memory discrepancy satisfy $|(Lq_S-Lq_T)_i|\le\epsilon_i$. If both query denominators are at least $\beta>0$, then

$$|f(q_S)-f(q_T)|\le\min\left(1,\frac{\sum_i(|u_i|+|v_i|)\epsilon_i}{\beta}\right).\qquad\text{(18)}$$

**Proof.** The affine constants cancel. The numerator discrepancy is at most $\sum_i|u_i|\epsilon_i$, and the denominator discrepancy is at most $\sum_i|v_i|\epsilon_i$. Apply Lemma 7.1. $\square$

This certificate controls the required task through its decoded moment directions. It does not require closeness of every response atom. The factorization coefficients and the support floor must themselves be certified on the retained class. A good fit on sampled memories does not establish either premise. If the student lies outside that class, the affine identities must be revalidated or their residuals included in the moment error budget.

**Corollary 7.6 (sequential evidence uses joint support).** If an initial common-profile error is at most $\varepsilon$ and factual evidence is accumulated as $E^{(t)}=\bigcap_{s\le t}E_s$, Theorem 7.2 bounds the conditional error by $\min(1,\varepsilon/\beta_t)$ whenever both joint-event masses are at least $\beta_t>0$. Large probabilities for the separate $E_s$ do not supply that joint floor without additional dependence information.

**Proof.** Apply Theorem 7.2 to the single event $E^{(t)}$. For the last claim, two events can each have probability $1/2$ and be disjoint, giving zero joint mass. $\square$

The bound is a worst-case guarantee, not a prediction that rare evidence must increase error. Errors can cancel or leave the conditional law unchanged. A behavioral claim about rarity therefore requires its own test, rather than following from the denominator in (18).

<!-- SECTION8 -->
## Composition without copying internal coordinates

**Theorem 8.4 (composition of causal realizations).** Suppose a student $S$ realizes an intermediate semantic model $M$, and $M$ realizes a task model $H$, each under Definition 8.1. Assume the certified intervention domain of each upper model is covered by the corresponding intervention map, and that evidence and requested outcomes use the composed pullbacks. Then the composed realization has

$$\tau_{SH}=\tau_{MH}\circ\tau_{SM},\quad\eta_{SH}=\eta_{MH}\circ\eta_{SM},\quad\omega_{SH}=\omega_{MH}\circ\omega_{SM}.\qquad\text{(19)}$$

It preserves the declared conditional multiworld flow of $H$ on positive support.

**Proof.** Apply the first commuting equality to each student intervention and background, then apply the second equality to the resulting intermediate state. Substitution gives the commuting equality for the three composed maps. Pushforwards of background laws compose. The same background is used for every world, and the composed evidence pullback preserves the conditioning event. Intervention coverage ensures that every certified task intervention is represented. Theorem 8.2 completes the proof. $\square$

The intermediate model is an optional semantic interface, not the teacher's neural architecture. It may use another cover or coordinate system. If cover restrictions are part of the interface, the abstraction maps must commute with those restrictions as well as with interventions; matching local dimensions is insufficient. The probability-extension obligations of Section 5 remain in force.

**Corollary 8.5 (approximate behavioral chains).** If three systems are compared on the same finite profile space and their successive total-variation errors are bounded by $\varepsilon_1$ and $\varepsilon_2$, the endpoint error is at most $\min(1,\varepsilon_1+\varepsilon_2)$. Conditional queries then satisfy Theorem 7.2 under a verified positive endpoint support floor.

**Proof.** Use the triangle inequality for total variation and then condition the endpoint laws. $\square$

Marginal L2 bounds cannot be substituted for these joint-profile premises. Nor does an intervention map covering only the factual regime certify task interventions outside its image. This coverage requirement is now explicit in the realization contract.

<!-- SECTION10 -->
## Adaptive requests and statistical source records

The exact C# census has no sampling uncertainty. A harness learning teacher records from observations needs a separate statistical contract. Time-uniform confidence sequences provide one established route to coverage under optional stopping (Howard et al., 2021). They require appropriate sampling assumptions; no statistical method repairs incorrectly declared event meanings or an incorrect structural model class.

**Theorem 10.3 (simultaneous coverage for adaptive reuse).** Fix a true semantic law $q_*$ in the declared structural class. Let source record $i$ define a random constraint set $C_i$ with $P(q_*\notin C_i)\le\alpha_i$. For a finite or countable collection with $\sum_i\alpha_i\le\alpha$, let the harness intersect any acquired records with the structural class to form $K_t$. On an event of probability at least $1-\alpha$, every $K_t$ contains $q_*$, and every valid query enclosure over $K_t$ contains the true value, simultaneously over all adaptively selected requests with defined support. Reusing a source does not add another failure event.

**Proof.** The union bound gives

$$P\left(q_*\in\bigcap_i C_i\right)\ge1-\sum_i\alpha_i\ge1-\alpha.\qquad\text{(20)}$$

On that event every acquired intersection contains $q_*$. For any query chosen from the history, an enclosure valid for every model in the current intersection is valid at $q_*$. This is a pathwise statement for all requests and does not require independence among source records. Repeated use of the same $C_i$ leaves the intersection and its coverage event unchanged. $\square$

For adaptively acquired sources, the theorem's coverage premise must already account for selection. A sufficient alternative is conditional failure probability at most a predictable allocation $\alpha_i$, given the preceding history, with a pathwise total allocation at most $\alpha$. Taking conditional expectations and applying a union bound gives the same result. A fixed-time interval repeatedly inspected until it becomes favorable need not satisfy either premise. Records derived from the same measurement retain the same source dependency; they are not independent evidence. A change in regime or semantic model invalidates the fixed-$q_*$ premise and requires a new contract.

**Theorem 10.4 (decision sufficient flow).** For finitely many actions with expected utilities $v_a^\top q$, an action $a$ is optimal for every $q\in K$ exactly when $\inf_{q\in K}(v_a-v_b)^\top q\ge0$ for every competitor $b$. A checked lower certificate for each advantage therefore permits stopping without point identification of the full flow. If instead teacher and student pairwise advantages differ by at most $\varepsilon$ uniformly, an action maximizing student utility has true regret at most $\varepsilon$.

**Proof.** The first equivalence is the definition of optimality written for every competitor and law. For the second, let $a_S$ maximize student utility and $a_T$ maximize teacher utility. The student advantage of $a_T$ over $a_S$ is nonpositive. Its teacher counterpart is at most $\varepsilon$ larger and equals the true regret. $\square$

Utility gaps can require fewer moment directions than complete probability reconstruction. Their units and baseline convention must be fixed before checking residuals. The decision certificate is scoped to the action set, model family and utility version; it makes no claim about actions that were not included.

**Algorithm 8 (a scoped distillation request).** Resolve the semantic and regime versions, case evidence, intervention family and required decision or precision. Retrieve candidate immutable records and their unique source dependencies. Validate support and the applicable common-model certificate. Use a conditional-memory certificate, a transported realization certificate or an interval over the retained family as appropriate. If Theorem 10.4 settles the decision, stop. Otherwise request an informative probe or solve a tighter bound, accounting for any newly acquired statistical source under Theorem 10.3. Append the result with its scope, guarantee type and dependencies. A selected compatible law remains labelled selected; it is not promoted to the teacher's identified flow.

Anthropic's long-running-agent guide (2025) uses persistent artifacts to carry work between sessions. Its later harness report (2026) separates generation from evaluation and discusses explicit task contracts and the cost of verification. These are useful operational precedents. For ADC, prose progress notes help a model recover context, while authoritative semantic values, support conditions and certificates remain structured records. An evaluator model can propose checks; mathematical acceptance uses the primitive checker. This preserves implementation freedom while preventing an evaluator's favorable prose from serving as a causal certificate.

Theorem 10.3 controls coverage, not honesty of the teacher's assumptions or the latency of Algorithm 8. Theorem 10.4 can justify an early stop mathematically, but any speed benefit still requires the measured test in H5. Compaction may discard text after a sufficient semantic frontier is retained; it may not discard a premise still needed by a certificate and continue calling that certificate valid.

<!-- SECTION11 -->
## Further exact examples for conditional memory

Version 3 adds @@COUNT@@ exact rational checks in `check_v3.py`. They include the constant-conditional exception, nonconstant numerator and denominator counterexamples, tight-inequality identification without forced-zero atoms, task-sensitive conditional error, composition of distinct encodings, statistical source reuse and decision sufficiency. The two-query example of Section 6 has a three-coordinate linear recovery checked on @@GRID@@ supported laws. Distinct abstraction maps compose in @@COMPOSE@@ background–intervention cases, and the common-profile triangle inequality is checked on @@TRIPLES@@ law triples. These illustrate the proofs; they are not a learned student experiment.

The supplied Version 2 Python validator was rerun: all 19 checks passed, including all 16 census output lines. The original C# sources and census files are preserved unchanged; the C# census was not regenerated for Version 3. The new rational result file is reproduced in two clean processes and compared byte for byte. There is no new latency, human, animal or neural-training result.

<!-- SECTION12 -->
## Connectivity geometry and conditional memory

Chakravarthula et al. (2026), published on 22 October, relate connectivity geometry to task representations across human cortex. Their fMRI and activity-flow analyses of diverse tasks associate lower-dimensional connectivity with representational compression and higher-dimensional connectivity with expansion and conjunctive coding. Their model captures transformation of representations, rather than requiring a copy of the source representation. This supports investigating implementation-independent task structure. It does not establish the ADC intervention maps or a common response law.

The mathematical question is which task directions a compressed representation preserves. Two representations of equal dimension can retain different causal information. Theorem 6.9 and Proposition 7.5 distinguish dimension from task alignment: a conditional query may lose either its numerator or its evidence denominator while marginal predictions remain good. The finite linear-memory theorem is not a rank law for neuronal activity or fMRI. The authors' accompanying preprint also shows that strong local nonlinear computations can break the simple connectivity–dimensionality relation. We therefore use the reported geometry as motivation for a discriminating task, not as proof of cortical linear storage.

The retained Zong et al. (2025) finding also matters here: it cautions against a compulsory serial hippocampus-as-teacher and cortex-as-copy arrangement. Parallel systems can learn different sufficient descriptions and interact through task-relevant interfaces. Any proposed biological distillation must test transfer of intervention-sensitive relations, not merely similarity of representational geometry.

<!-- SECTION13 -->
**H7 (conditional memory audit).** On finite convex teachers with supported conditional queries, an exact implementation of Lemma 6.8 and Theorem 6.9 will agree with independently computed query variation and memory-fibre counterexamples. A rank certificate claiming sufficiency while two admissible laws share memory and differ on the query refutes the implementation. Comparing learned encoders requires a separate accuracy test; the theorem covers exact real linear memory.

**H8 (adaptive certificate scope).** In simulated harness runs with known joint source coverage, repeated cached queries will retain the coverage level certified for unique sources, while changed semantics and unsupported events trigger revalidation. A reported guarantee that fails under its own sampling and scope assumptions refutes the implementation. Adding ordinary fixed-time intervals after adaptive selection is not an admissible test of Theorem 10.3's premises.

**N4 (task alignment beyond dimension).** At matched retained dimension, exposure and marginal recall, a representation or training condition preserving the learned joint relations will support held-out conditional causal judgments better than one preserving only unrelated directions, by a preregistered effect $\Delta_4>0$. An upper confidence endpoint below $\Delta_4$ refutes this quantitative functional prediction. This tests preservation of task information and does not identify a neuronal response simplex.

**N5 (evidence rarity under matched perturbation).** In a learned causal task, controlled perturbations of joint-event estimates will produce greater conditional-judgment error for lower-support factual events than for matched higher-support events, by a registered $\Delta_5>0$. Match marginal knowledge and inference difficulty, and include perturbations that cancel in the ratio. Absence of the registered effect refutes this behavioral prediction. The worst-case bound (18) alone does not entail it.

<!-- APPENDIX -->
Version 3 adds `additions_v3.md`, `build_v3.py`, `check_v3.py`, `checks_v3.json` and a fresh `validation_v2_rerun.json`. Run the new checker with Python, then build the Word paper from the included `base_v2.docx`; no earlier project path is required. The inherited Version 2 builder is retained for provenance and is not the build route for this revision. The new builder preserves the existing body, figures and tables and inserts native Word equations at the relevant sections. The inherited census remains a historical exact computation with a freshly rerun validator, not a newly timed C# run. The guarantee ledger below continues to apply; conditional memory additionally assumes a convex family, positive denominators and linear storage, composition additionally requires intervention coverage, and statistical reuse requires simultaneous or sequentially valid source coverage.

<!-- REFERENCES -->
Anthropic. (2025, November 26). *Effective harnesses for long-running agents*. https://www.anthropic.com/research/effective-harnesses-for-long-running-agents

Anthropic. (2026, March 24). *Harness design for long-running application development*. https://www.anthropic.com/research/harness-design-long-running-apps

Chakravarthula, L. N. C., Ito, T., Tzalavras, A., & Cole, M. W. (2026). Network geometry shapes the transformation of task representations across the human cortex. *Nature Neuroscience*. https://doi.org/10.1038/s41593-026-02486-8

Chakravarthula, L. N. C., Ito, T., Tzalavras, A., & Cole, M. W. (2026). *Network geometry shapes the transformation of task representations across human cortex* (Version 3) [Preprint]. bioRxiv. https://doi.org/10.1101/2025.03.14.643366

Howard, S. R., Ramdas, A., McAuliffe, J., & Sekhon, J. (2021). Time-uniform, nonparametric, nonasymptotic confidence sequences. *The Annals of Statistics, 49*(2), 1055–1080. https://doi.org/10.1214/20-AOS1991
