"""Independent validation of the level-3 census (cs_cf.txt, out/cf_iv_records.json).

Part A recomputes every twin-network counterfactual with Python integers (independent pair kernels), the Tian-Pearl
bounds with fractions, the sharp bounds with SciPy's HiGHS solver, the level-2 suffix answer and the descendant counts.
Part B recomputes every linear-fractional bound with HiGHS on an independently written Charnes-Cooper programme,
re-checks every exported witness exactly (feasibility and attained ratio), and recounts all events.
Usage: python validate_cf.py cs_cf.txt out/cf_iv_records.json validation_cf.json"""
import json, math, sys
from fractions import Fraction as F
from multiprocessing import Pool
import numpy as np
from scipy.optimize import linprog

n = 5; PAIRS = [(i, j) for i in range(n) for j in range(i + 1, n)]

class Rng:
    def __init__(s, st): s.s = st
    def next(s):
        s.s = (s.s + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF; z = s.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & 0xFFFFFFFFFFFFFFFF
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & 0xFFFFFFFFFFFFFFFF
        return z ^ (z >> 31)
    def int(s, lo, hi): return lo + math.floor((s.next() >> 11) * (1.0 / 9007199254740992.0) * (hi - lo + 1))

def desc(edges, x):
    s = {x}
    while True:
        t = s | {b for a, b in edges if a in s}
        if t == s: return s - {x}
        s = t

def pair(kind, g, p, r, a, b, same, orient_differs):
    if same: return 0 if a != b else (p if a else g - p) * g
    if kind == 1: return (p if a else g - p) * (r if b else g - r)
    one = max(0, p + r - g) * g if (kind == 2 and orient_differs) else min(p, r) * g
    p10, p01 = p * g - one, r * g - one; p00 = g * g - one - p10 - p01
    return (one if b else p10) if a else (p01 if b else p00)

def sharp(pc, e0, e1):
    """HiGHS bounds of P(X=1, Y(1)=1, Y(0)=0) over the 8-type bivariate response model."""
    k = [(xv, ty) for xv in (0, 1) for ty in range(4)]
    A = [[1] * 8, [1 if xv == 0 and ty & 1 == 0 else 0 for xv, ty in k], [1 if xv == 0 and ty & 1 == 1 else 0 for xv, ty in k],
         [1 if xv == 1 and ty >> 1 & 1 == 0 else 0 for xv, ty in k], [1 if ty & 1 else 0 for xv, ty in k], [1 if ty >> 1 & 1 else 0 for xv, ty in k]]
    b = [1, pc[0], pc[1], pc[2], e0, e1]; c = np.array([1.0 if (xv == 1 and ty == 2) else 0.0 for xv, ty in k])
    hi = -linprog(-c, A_eq=np.array(A, float), b_eq=np.array(b, float), bounds=(0, None), method="highs").fun
    lo = linprog(c, A_eq=np.array(A, float), b_eq=np.array(b, float), bounds=(0, None), method="highs").fun
    return lo, hi

def work(job):
    dm, models, grid = job
    edges = [PAIRS[k] for k in range(len(PAIRS)) if dm >> k & 1]
    par = [sorted(a for a, b in edges if b == i) for i in range(n)]
    cfg = lambda i, v: sum((v >> p & 1) << j for j, p in enumerate(par[i]))
    out = dict(c=[0] * 12, width=0.0, spread=0.0, gap=0.0, lpok=True)
    for cpt in models:
        P = lambda i, c: cpt[i][c]
        obs = [math.prod((P(i, cfg(i, v)) if v >> i & 1 else grid - P(i, cfg(i, v))) for i in range(n)) for v in range(32)]
        tot = grid ** n
        def dolaw(x, xv):
            return [0 if (v >> x & 1) != xv else math.prod((P(i, cfg(i, v)) if v >> i & 1 else grid - P(i, cfg(i, v))) for i in range(n) if i != x) for v in range(32)]
        for x in range(n):
            de = desc(edges, x); ys = sorted(y for y in de if y > x)
            if not ys: continue
            out["c"][11] += 1
            W = []
            for kind in range(3):
                Wk = {}
                for v in range(32):
                    if not v >> x & 1: continue
                    for w in range(32):
                        if w >> x & 1: continue
                        s = 1
                        for i in range(n):
                            cf, cc = cfg(i, v), cfg(i, w)
                            if i == x: s *= (P(i, cf) if v >> i & 1 else grid - P(i, cf)) * grid
                            else: s *= pair(kind, grid, P(i, cf), P(i, cc), v >> i & 1, w >> i & 1, cf == cc, (cf & 1) != (cc & 1))
                            if s == 0: break
                        if s:
                            assert all((v >> j & 1) == (w >> j & 1) for j in range(n) if j != x and j not in de)
                            Wk[(v, w)] = s
                W.append(Wk)
            D0 = dolaw(x, 0); t0 = grid ** (n - 1)
            for y in ys:
                c = out["c"]; c[0] += 1
                pn = []
                for Wk in W:
                    num = sum(s for (v, w), s in Wk.items() if v >> y & 1 and not w >> y & 1)
                    den = sum(s for (v, w), s in Wk.items() if v >> y & 1)
                    pn.append(F(num, den))
                pxy = F(sum(obs[v] for v in range(32) if v >> x & 1 and v >> y & 1), tot)
                py = F(sum(obs[v] for v in range(32) if v >> y & 1), tot)
                pyx0 = F(sum(D0[v] for v in range(32) if v >> y & 1), t0)
                px0y0 = F(sum(obs[v] for v in range(32) if not v >> x & 1 and not v >> y & 1), tot)
                lo = max(F(0), (py - pyx0) / pxy); hi = min(F(1), (1 - pyx0 - px0y0) / pxy)
                c[1] += all(lo <= p <= hi for p in pn); out["width"] += float(hi - lo); c[7] += lo == hi
                sp = max(pn) - min(pn); out["spread"] = max(out["spread"], float(sp))
                c[4] += sp == 0; c[8] += sp > F(1, 10); c[9] += sp > F(1, 4); c[5] += pn[0] == lo; c[6] += pn[0] == hi
                D1 = dolaw(x, 1)
                pc = [F(sum(obs[v] for v in range(32) if (v >> x & 1, v >> y & 1) == cell), tot) for cell in ((0, 0), (0, 1), (1, 0))]
                slo, shi = sharp(pc, pyx0, F(sum(D1[v] for v in range(32) if v >> y & 1), t0))
                ok = abs(slo / float(pxy) - float(lo)) < 1e-9 and abs(shi / float(pxy) - float(hi)) < 1e-9
                c[2] += ok
                pre = (1 << x) - 1; l2 = F(0)
                for v in range(32):
                    if not (v >> x & 1 and v >> y & 1): continue
                    m = sum(D0[u] for u in range(32) if (u & pre) == (v & pre))
                    m0 = sum(D0[u] for u in range(32) if (u & pre) == (v & pre) and not u >> y & 1)
                    l2 += F(obs[v], tot) * F(m0, m)
                l2 /= pxy
                c[10] += l2 < lo or l2 > hi; out["gap"] += float(abs(l2 - pn[0]))
    return out

# ---------------------------------------------------------------- Part B helpers
T = 16
Xof = lambda k, z: (k >> 2) >> z & 1
Yof = lambda k, x: (k & 3) >> x & 1
CELLS = [(0, 0, 0), (0, 0, 1), (0, 1, 0), (1, 0, 0), (1, 0, 1), (1, 1, 0)]
DROWS = [[1 if Xof(k, z) == x and Yof(k, x) == y else 0 for k in range(T)] for z, x, y in CELLS]
ind = lambda f: [1 if f(k) else 0 for k in range(T)]
A1 = ind(lambda k: Yof(k, 1) == 1 and Yof(k, 0) == 0); B1 = ind(lambda k: Yof(k, 0) == 0)
A2 = ind(lambda k: Yof(k, 1) == 1 and Yof(k, 0) == 0 and Xof(k, 1) == 1); B2 = ind(lambda k: Yof(k, 0) == 0 and Xof(k, 1) == 1)
G1 = ind(lambda k: Yof(k, 1) == 1); G0 = ind(lambda k: Yof(k, 0) == 1); GV = ind(lambda k: Yof(k, 0) == 1 and Yof(k, 1) == 0)
dot = lambda a, b: sum(x * y for x, y in zip(a, b))

def rows_for(truth, exp, mtr):
    eqs = [(r, dot(r, truth)) for r in DROWS] + [([1] * T, F(1))]
    if exp: eqs += [(G1, dot(G1, truth)), (G0, dot(G0, truth))]
    if mtr: eqs += [(GV, F(0))]
    return eqs

def lin(c, eqs, sense):
    res = linprog(-sense * np.array(c, float), A_eq=np.array([r for r, _ in eqs], float), b_eq=np.array([float(v) for _, v in eqs]), bounds=(0, None), method="highs")
    assert res.status == 0
    return -sense * res.fun

def cc(a, b, eqs, sense):
    """Charnes-Cooper in (r, t): r ≥ 0, t ≥ 0, row·r − rhs·t = 0, b·r = 1."""
    A = [list(r) + [-float(v)] for r, v in eqs] + [list(b) + [0]]
    rhs = [0.0] * len(eqs) + [1.0]
    res = linprog(-sense * np.array(list(a) + [0], float), A_eq=np.array(A, float), b_eq=np.array(rhs), bounds=(0, None), method="highs")
    assert res.status == 0
    return -sense * res.fun

def feasible(q, eqs): return all(v >= 0 for v in q) and all(dot(r, q) == rhs for r, rhs in eqs)

def main():
    cs = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1].split() for l in open(sys.argv[1])}
    R = json.load(open(sys.argv[2])); checks = []
    def check(name, ok, detail=""):
        checks.append(dict(name=name, passed=bool(ok), detail=str(detail)[:300])); print(("PASS " if ok else "FAIL ") + name, str(detail)[:150], flush=True)
    def eq(name, vals, tol=1e-9):
        got = cs[name]
        ok = len(got) == len(vals) and all((abs(float(g) - v) <= tol * max(1, abs(v))) if isinstance(v, float) else (F(g) == F(v) if isinstance(v, (str, F)) else int(g) == v) for g, v in zip(got, vals))
        check(name, ok, (got, vals))
    eq("cf_examples", [5, 7, "0", "1", "1/2", "1/2"])
    gx = de = sf = 0
    for dm in range(1 << len(PAIRS)):
        edges = [PAIRS[k] for k in range(len(PAIRS)) if dm >> k & 1]
        for x in range(n): gx += 1; de += len(desc(edges, x)); sf += n - 1 - x
    eq("cf_prediction_cost", [gx, de, sf])
    for tag, grid, seed in (("tenths", 10, 20261031001), ("hundredths", 100, 20261031002)):
        rng = Rng(seed); jobs = []
        for dm in range(1 << len(PAIRS)):
            edges = [PAIRS[k] for k in range(len(PAIRS)) if dm >> k & 1]
            par = [sorted(a for a, b in edges if b == i) for i in range(n)]
            jobs.append((dm, [[[rng.int(1, grid - 1) for _ in range(1 << len(par[i]))] for i in range(n)] for _ in range(3)], grid))
        with Pool() as pool: res = pool.map(work, jobs, chunksize=8)
        c = [sum(x) for x in zip(*(r["c"] for r in res))]
        q = c[0]
        eq(f"cf_{tag}_pn", [c[0], c[1], c[2], 0, c[4], c[5], c[6], c[7], c[8], c[9], c[10], c[11]])
        eq(f"cf_{tag}_pn_real", [sum(r["width"] for r in res) / q, max(r["spread"] for r in res), sum(r["gap"] for r in res) / q])
    names = ["iv", "iv_exp", "iv_mtr", "iv_exp_mtr"]; flags = [(0, 0, 0), (0, 1, 0), (1, 0, 1), (1, 1, 1)]
    cnt = {nm: [0] * 9 for nm in names}; wid = {nm: [0.0, 0.0] for nm in names}; worst = 0.0; exact_ok = True
    q2 = [0, 0, 0]; wq2 = 0.0
    for rec in R:
        qs = [F(v) for v in rec["q"]]; qm = [F(v) for v in rec["qm"]]
        for nm, (usem, exp, mtr) in zip(names, flags):
            truth = qm if usem else qs; eqs = rows_for(truth, exp, mtr); r = rec[nm]; a = cnt[nm]
            bmax, bmin = lin(B1, eqs, 1), lin(B1, eqs, -1); amax, amin = lin(A1, eqs, 1), lin(A1, eqs, -1)
            worst = max(worst, abs(bmax - float(F(r["bmax"]))), abs(bmin - float(F(r["bmin"]))))
            a[0] += 1
            if bmax <= 1e-12: continue
            a[1] += 1
            U, L = F(r["U"]), F(r["L"]); qU = [F(v) for v in r["qU"]]; qL = [F(v) for v in r["qL"]]
            a[2] += bool(qU) and bool(qL)
            exact_ok &= feasible(qU, eqs) and feasible(qL, eqs) and F(dot(A1, qU), dot(B1, qU)) == U and F(dot(A1, qL), dot(B1, qL)) == L
            worst = max(worst, abs(cc(A1, B1, eqs, 1) - float(U)), abs(cc(A1, B1, eqs, -1) - float(L)))
            bmn, bmx = F(r["bmin"]), F(r["bmax"])
            amx = F(dot(A1, qU)) if False else None
            nL, nU = F(r["nL"]), F(r["nU"])
            worst = max(worst, abs(float(nL) - amin / bmax), abs(float(nU) - (1.0 if bmn == 0 else min(1.0, amax / bmin))))
            a[3] += bmn == 0; a[4] += nL <= L and U <= nU; a[5] += nL < L or U < nU
            tb = dot(B1, truth)
            if tb > 0: a[6] += 1; a[7] += L <= F(dot(A1, truth), tb) <= U
            a[8] += L == U; wid[nm][0] += float(U - L); wid[nm][1] += float(nU - nL)
        if "L2" in rec:
            eqs = rows_for(qs, 1, 0); L2, U2 = F(rec["L2"]), F(rec["U2"])
            worst = max(worst, abs(cc(A2, B2, eqs, 1) - float(U2)), abs(cc(A2, B2, eqs, -1) - float(L2)))
            L, U = F(rec["iv_exp"]["L"]), F(rec["iv_exp"]["U"])
            q2[0] += 1; q2[1] += L2 < L or U2 > U; q2[2] += L2 > U or U2 < L; wq2 += float(U2 - L2)
    check("cf_ratio_witnesses_exact", exact_ok)
    check("cf_ratio_float_crosscheck", worst < 1e-9, worst)
    for nm in names: eq(f"cf_ratio_{nm}", cnt[nm] + [wid[nm][0] / cnt[nm][1], wid[nm][1] / cnt[nm][1]])
    eq("cf_reuse_new_evidence", q2 + [wq2 / q2[0]])
    missing = [k for k in cs if not any(ch["name"] == k for ch in checks)]
    for k in missing: check(k, False, "not validated")
    json.dump(dict(checks=checks, all_passed=all(ch["passed"] for ch in checks), lines=len(cs)), open(sys.argv[3], "w"), indent=1)
    print("ALL", all(ch["passed"] for ch in checks), "lines", len(cs), "checks", len(checks))

if __name__ == "__main__":
    main()
