"""Build 'Counterfactual Branches for Autoregressive Do Calculus' as a Word file.

paper_template.md is filled with numbers read from the validated C# output cs_cf.txt, converted by Pandoc with the
series reference document, and post-processed: CAPTION and FIGURE markers become captions and figures, tables take
the series look, equation tags and schema order are fixed."""
import copy, json, os, re, shutil, subprocess, tempfile, zipfile
from docx import Document
from docx.shared import Inches
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from lxml import etree

H = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(os.path.dirname(os.path.dirname(H)), "idc", "work", "Interval_Do_Calculus_for_Reusable_ADC_V2.docx")
OUT = os.path.join(H, "Counterfactual_Branches_for_ADC.docx")
cs = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1].split() for l in open(os.path.join(H, "cs_cf.txt"))}
val = json.load(open(os.path.join(H, "validation_cf.json"))); assert val["all_passed"]
W_ = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"; WNS = f'xmlns:w="{W_}"'
I = lambda k: [int(v) for v in cs[k]]
num = lambda x: f"{x:,}"
pc = lambda a, b, d=1: f"{100 * a / b:.{d}f}%"
th, hu = I("cf_tenths_pn"), I("cf_hundredths_pn"); tr, hr = cs["cf_tenths_pn_real"], cs["cf_hundredths_pn_real"]
cost = I("cf_prediction_cost"); ex = cs["cf_examples"]; reuse = cs["cf_reuse_new_evidence"]
lv = {k: cs[f"cf_ratio_{k}"] for k in ("iv", "iv_exp", "iv_mtr", "iv_exp_mtr")}
worst = next(c for c in val["checks"] if c["name"] == "cf_ratio_float_crosscheck")["detail"]

def row2(lab, c, r):
    return (f"| {lab} | {num(c[0])} | {pc(c[1], c[0])} | {pc(c[2], c[0])} | {pc(c[8], c[0])} | {pc(c[9], c[0])} | "
            f"{pc(c[5], c[0])} | {float(r[0]):.3f} | {float(r[2]):.3f} |")
table2 = "\n".join(["| Grid | PN queries | Coupling answers inside (3) | LP equals (3) | Spread above 0.1 | Spread above 0.25 | Comono­tone at lower bound | Mean width of (3) | Mean suffix gap |",
                    "|---|---|---|---|---|---|---|---|---|", row2("Tenths", th, tr), row2("Hundredths", hu, hr)])
def row3(lab, v):
    c = [int(x) for x in v[:9]]
    return f"| {lab} | {float(v[9]):.3f} | {float(v[10]):.3f} | {pc(c[5], c[1])} | {pc(c[8], c[1])} | {pc(c[7], c[6])} | {pc(c[2], c[1])} |"
table3 = "\n".join(["| Assumptions | Mean sharp width | Mean endpoint-division width | Endpoint division strictly wider | Point identified | Truth inside | Endpoints attained by a witness |",
                    "|---|---|---|---|---|---|---|", row3("Instrument data", lv["iv"]), row3("Instrument data and experimental marginals", lv["iv_exp"]),
                    row3("Instrument data and monotone response", lv["iv_mtr"]), row3("Both additions", lv["iv_exp_mtr"])])
fill = dict(Q=num(hu[0]), S25H=pc(hu[9], hu[0]), S10H=pc(hu[8], hu[0]), COMOH=pc(hu[5], hu[0]), GAPH=f"{float(hr[2]):.3f}",
            DESC=num(cost[1]), SUF=num(cost[2]), RATIO=pc(cost[1], cost[2]), W0=f"{float(lv['iv'][9]):.3f}", W1=f"{float(lv['iv_exp'][9]):.3f}",
            W2=f"{float(lv['iv_mtr'][9]):.3f}", MTRW=pc(int(lv['iv_mtr'][5]), int(lv['iv_mtr'][1])), Q2N=num(int(reuse[0])),
            REUSEN=num(int(reuse[1])), REUSE=pc(int(reuse[1]), int(reuse[0])), DISJ=num(int(reuse[2])), TOYA=ex[2], TOYB=ex[3],
            NCHK=str(len(val["checks"])), WORST=f"{float(worst):.1e}", TABLE2=table2, TABLE3=table3)
md = open(os.path.join(H, "paper_template.md"), encoding="utf-8").read()
md = re.sub(r"«([A-Z0-9]+)»", lambda m: fill[m.group(1)], md)
md = re.sub(r"^\*\*(Table \d[^*]*)\*\*$", r"CAPTION: \1", md, flags=re.M)
open(os.path.join(H, "paper.md"), "w", encoding="utf-8").write(md)
with tempfile.TemporaryDirectory() as td:
    subprocess.run(["pandoc", os.path.join(H, "paper.md"), "-f", "markdown+tex_math_dollars-auto_identifiers-fancy_lists", "-o", OUT, f"--reference-doc={SRC}"], cwd=H, check=True)
doc = Document(OUT); body = doc.element.body
exec(open(os.path.join(H, "_helpers.py")).read())
# front matter: pandoc puts title and subtitle; author lines are plain paragraphs
for p in list(doc.paragraphs):
    t = p.text.strip()
    if t.startswith("CAPTION: "):
        cap = caption(t[len("CAPTION: "):]); p._p.addprevious(cap); nxt = p._p.getnext(); p._p.getparent().remove(p._p)
        while nxt is not None and nxt.tag != qn("w:tbl"): nxt = nxt.getnext()
        if nxt is not None:
            ncol = len(nxt.find(qn("w:tblGrid")).findall(qn("w:gridCol")))
            widths = {3: [1700, 3560, 4100], 9: [1240] + [1015] * 8, 7: [2160] + [1200] * 6}[ncol]
            style_table(nxt, widths)
            rows = nxt.findall(qn("w:tr"))
            for tr in rows[:-1]:
                for pp in tr.iter(qn("w:p")):
                    ppr = pp.find(qn("w:pPr")); kn = OxmlElement("w:keepNext"); ppr.find(qn("w:pStyle")).addnext(kn)
    elif t.startswith("FIGURE: "):
        path, title, text = [s.strip() for s in t[len("FIGURE: "):].split("|", 2)]
        els = figure(os.path.join(H, path), title, text, "Grouped bars of the spread of PN across couplings, and of interval widths as assumptions are added.")
        ref = p._p
        for e in els: ref.addnext(e); ref = e
        p._p.getparent().remove(p._p)
paras = doc.paragraphs; inrefs = False
bib = "Bibliography1" if "Bibliography1" in [s.name for s in doc.styles] else None
for p in paras:
    if p.text in ("Debi Prasad Ghosh", "Version 1, 1 November 2026", "Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India"):
        p.style = doc.styles["Body Text"]; p.alignment = 1
    if p.style.name == "Heading 1": inrefs = p.text == "References"; continue
    if inrefs and bib and p.style.name in ("Body Text", "First Paragraph"): p.style = doc.styles[bib]
doc.core_properties.title = "Counterfactual Branches for Autoregressive Do Calculus"; doc.core_properties.author = "Debi Prasad Ghosh"
doc.save(OUT); print("saved", OUT)
exec(open(os.path.join(H, "_mathfix.py")).read())
exec(open(os.path.join(H, "_settingsfix.py")).read())
