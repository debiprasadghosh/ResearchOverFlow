# ------------------------------------------------------------------ OMML schema order (Pandoc emits some children out of order)
import zipfile, shutil
M_ = "http://schemas.openxmlformats.org/officeDocument/2006/math"
ORDER = {"dPr": ["begChr", "sepChr", "endChr", "grow", "shp", "ctrlPr"], "rPr": ["lit", "nor", "scr", "sty", "brk", "aln"]}
def fix_math(xml):
    root = etree.fromstring(xml)
    for name, order in ORDER.items():
        for el in root.iter(f"{{{M_}}}{name}"):
            kids = list(el)
            for k in kids: el.remove(k)
            if name == "rPr" and any(etree.QName(k).localname == "nor" for k in kids):
                kids = [k for k in kids if etree.QName(k).localname not in ("sty", "scr")]
            for k in sorted(kids, key=lambda k: order.index(etree.QName(k).localname) if etree.QName(k).localname in order else 99): el.append(k)
    import re as _re
    for rr in root.iter(f"{{{M_}}}r"):
        t = rr.find(f"{{{M_}}}t"); rp = rr.find(f"{{{M_}}}rPr")
        if t is not None and rp is not None and _re.fullmatch(r"\s*\(\d+\)", t.text or "") and rp.find(f"{{{M_}}}nor") is not None:
            for k in list(rp): rp.remove(k)
            sty = etree.SubElement(rp, f"{{{M_}}}sty"); sty.set(f"{{{M_}}}val", "p")
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
tmp = OUT + ".tmp"
with zipfile.ZipFile(OUT) as zi, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zo:
    for it in zi.infolist():
        data = zi.read(it.filename)
        if it.filename == "word/document.xml": data = fix_math(data)
        zo.writestr(it, data)
shutil.move(tmp, OUT); print("math order fixed")
