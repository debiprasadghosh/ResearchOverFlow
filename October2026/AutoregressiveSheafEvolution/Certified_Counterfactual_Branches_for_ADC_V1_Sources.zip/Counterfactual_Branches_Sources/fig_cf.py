"""Figure 2 of the level-3 paper, drawn from the validated C# output cs_cf.txt."""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

H = Path(__file__).resolve().parent
cs = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1].split() for l in open(H / "cs_cf.txt")}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.titlesize": 11, "axes.labelsize": 10,
                     "axes.spines.top": False, "axes.spines.right": False, "savefig.facecolor": "white"})
BLUE, RUST, GREY = "#336982", "#a95235", "#9aa6ad"
fig, ax = plt.subplots(1, 2, figsize=(9.4, 3.8), layout="constrained")
cats = ["Above 0, up to 0.1", "0.1 to 0.25", "Above 0.25"]
for i, (tag, col, lab) in enumerate((("tenths", RUST, "Tenths grid"), ("hundredths", BLUE, "Hundredths grid"))):
    c = list(map(int, cs[f"cf_{tag}_pn"])); q = c[0]
    vals = [100 * (q - c[8]) / q, 100 * (c[8] - c[9]) / q, 100 * c[9] / q]
    xs = [k + (i - 0.5) * 0.36 for k in range(3)]
    bars = ax[0].bar(xs, vals, 0.33, color=col, label=lab)
    for b, v in zip(bars, vals): ax[0].text(b.get_x() + b.get_width() / 2, v + 1, f"{v:.1f}", ha="center", fontsize=8)
ax[0].set_xticks(range(3), cats); ax[0].set_xlabel("Spread of PN across three couplings")
ax[0].set_ylabel("Share of 18,939 queries (%)"); ax[0].set_ylim(0, 70); ax[0].legend(frameon=False, fontsize=8, loc="upper left")
ax[0].set_title("A  Same data, different counterfactuals")
lv = [("cf_ratio_iv", "IV data"), ("cf_ratio_iv_exp", "+ experiment"), ("cf_ratio_iv_mtr", "IV + monotone\nresponse"), ("cf_ratio_iv_exp_mtr", "+ experiment\n+ monotone")]
sharp = [float(cs[k][9]) for k, _ in lv]; naive = [float(cs[k][10]) for k, _ in lv]
xs = range(4)
b1 = ax[1].bar([x - 0.18 for x in xs], sharp, 0.34, color=BLUE, label="Sharp (linear-fractional)")
b2 = ax[1].bar([x + 0.18 for x in xs], naive, 0.34, color=GREY, label="Endpoint division")
for bs in (b1, b2):
    for b in bs: ax[1].text(b.get_x() + b.get_width() / 2, b.get_height() + 0.015, f"{b.get_height():.3f}", ha="center", fontsize=8)
ax[1].set_xticks(list(xs), [l for _, l in lv], fontsize=8.5); ax[1].set_ylim(0, 1.18); ax[1].set_ylabel("Mean interval width")
ax[1].legend(frameon=False, fontsize=8, loc="upper right"); ax[1].set_title("B  Assumptions narrow P(Y₁=1 | Y₀=0)")
(H / "fig").mkdir(exist_ok=True)
fig.savefig(H / "fig/cf_couplings_and_ladder.png", dpi=240); fig.savefig(H / "fig/cf_couplings_and_ladder.svg"); plt.close(fig)
