import zipfile, shutil
# ------------------------------------------------------------------ settings.xml child order (inherited from the supplied file)
SORDER = ("writeProtection view zoom removePersonalInformation removeDateAndTime doNotDisplayPageBoundaries displayBackgroundShape "
          "printPostScriptOverText printFractionalCharacterWidth printFormsData embedTrueTypeFonts embedSystemFonts saveSubsetFonts saveFormsData "
          "mirrorMargins alignBordersAndEdges bordersDoNotSurroundHeader bordersDoNotSurroundFooter gutterAtTop hideSpellingErrors hideGrammaticalErrors "
          "activeWritingStyle proofState formsDesign attachedTemplate linkStyles stylePaneFormatFilter stylePaneSortMethod documentType mailMerge "
          "revisionView trackRevisions doNotTrackMoves doNotTrackFormatting documentProtection autoFormatOverride styleLockTheme styleLockQFSet "
          "defaultTabStop autoHyphenation consecutiveHyphenLimit hyphenationZone doNotHyphenateCaps showEnvelope summaryLength clickAndTypeStyle "
          "defaultTableStyle evenAndOddHeaders bookFoldRevPrinting bookFoldPrinting bookFoldPrintingSheets drawingGridHorizontalSpacing "
          "drawingGridVerticalSpacing displayHorizontalDrawingGridEvery displayVerticalDrawingGridEvery doNotUseMarginsForDrawingGridOrigin "
          "drawingGridHorizontalOrigin drawingGridVerticalOrigin doNotShadeFormData noPunctuationKerning characterSpacingControl printTwoOnOne "
          "strictFirstAndLastChars noLineBreaksAfter noLineBreaksBefore savePreviewPicture doNotValidateAgainstSchema saveInvalidXml ignoreMixedContent "
          "alwaysShowPlaceholderText doNotDemarcateInvalidXml saveXmlDataOnly useXSLTWhenSaving saveThroughXslt showXMLTags alwaysMergeEmptyNamespace "
          "updateFields hdrShapeDefaults footnotePr endnotePr compat docVars rsids mathPr attachedSchema themeFontLang clrSchemeMapping "
          "doNotIncludeSubdocsInStats doNotAutoCompressPictures forceUpgrade captions readModeInkLockDown smartTagType schemaLibrary shapeDefaults "
          "doNotEmbedSmartTags decimalSymbol listSeparator").split()
tmp = OUT + ".tmp"
with zipfile.ZipFile(OUT) as zi, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zo:
    for it in zi.infolist():
        data = zi.read(it.filename)
        if it.filename == "word/settings.xml":
            root = etree.fromstring(data); kids = list(root)
            for k in kids: root.remove(k)
            for k in sorted(kids, key=lambda k: SORDER.index(etree.QName(k).localname) if etree.QName(k).localname in SORDER else 999): root.append(k)
            for z in root.iter(f"{{{W_}}}zoom"):
                if z.get(f"{{{W_}}}percent") is None: z.set(f"{{{W_}}}percent", "100")
            data = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
        if it.filename == "word/numbering.xml":
            root = etree.fromstring(data)
            for e in list(root.iter(f"{{{W_}}}nsid")) + list(root.iter(f"{{{W_}}}tmpl")): e.set(f"{{{W_}}}val", e.get(f"{{{W_}}}val").zfill(8))
            data = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
        zo.writestr(it, data)
shutil.move(tmp, OUT); print("settings order fixed")
