def fragment(md):
    with tempfile.TemporaryDirectory() as td:
        open(os.path.join(td, "f.md"), "w", encoding="utf-8").write(md)
        subprocess.run(["pandoc", "f.md", "-f", "markdown+tex_math_dollars-auto_identifiers-fancy_lists", "-o", "f.docx", f"--reference-doc={SRC}"], cwd=td, check=True)
        f = Document(os.path.join(td, "f.docx"))
        els = [copy.deepcopy(e) for e in f.element.body if e.tag != qn("w:sectPr")]
    for e in els:
        for b in list(e.iter(qn("w:bookmarkStart"))) + list(e.iter(qn("w:bookmarkEnd"))): b.getparent().remove(b)
    return els

def style_table(tbl, widths):
    tp = tbl.find(qn("w:tblPr"))
    for ch in list(tp): tp.remove(ch)
    for ch in etree.fromstring(f'<w:tblPr {WNS}><w:tblW w:w="{sum(widths)}" w:type="dxa"/><w:jc w:val="center"/><w:tblBorders>' +
                               "".join(f'<w:{s} w:val="single" w:sz="4" w:space="0" w:color="D9D9D9"/>' for s in ("top", "left", "bottom", "right", "insideH", "insideV")) +
                               '</w:tblBorders><w:tblLayout w:type="fixed"/><w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/></w:tblPr>'): tp.append(ch)
    for gc, w in zip(tbl.find(qn("w:tblGrid")).findall(qn("w:gridCol")), widths): gc.set(qn("w:w"), str(w))
    for ri, tr in enumerate(tbl.findall(qn("w:tr"))):
        trpr = tr.find(qn("w:trPr"))
        if trpr is None: trpr = OxmlElement("w:trPr"); tr.insert(0, trpr)
        for ch in list(trpr): trpr.remove(ch)
        trpr.append(OxmlElement("w:cantSplit"))
        if ri == 0: trpr.append(OxmlElement("w:tblHeader"))
        for ci, (tc, w) in enumerate(zip(tr.findall(qn("w:tc")), widths)):
            tcpr = tc.find(qn("w:tcPr"))
            if tcpr is None: tcpr = OxmlElement("w:tcPr"); tc.insert(0, tcpr)
            for ch in list(tcpr): tcpr.remove(ch)
            fill = "E8EDF1" if ri == 0 else "FFFFFF"
            for ch in etree.fromstring(f'<w:tcPr {WNS}><w:tcW w:w="{w}" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="{fill}"/><w:tcMar><w:top w:w="85" w:type="dxa"/>'
                                       '<w:left w:w="80" w:type="dxa"/><w:bottom w:w="85" w:type="dxa"/><w:right w:w="80" w:type="dxa"/></w:tcMar><w:vAlign w:val="center"/></w:tcPr>'): tcpr.append(ch)
            for p in tc.findall(qn("w:p")):
                ppr = p.find(qn("w:pPr"))
                if ppr is None: ppr = OxmlElement("w:pPr"); p.insert(0, ppr)
                for ch in list(ppr): ppr.remove(ch)
                jc = "left" if ci == 0 else "center"
                for ch in etree.fromstring(f'<w:pPr {WNS}><w:pStyle w:val="BodyText"/><w:spacing w:after="40" w:line="252" w:lineRule="auto"/><w:jc w:val="{jc}"/></w:pPr>'): ppr.append(ch)
                for rr in p.findall(qn("w:r")):
                    rpr = rr.find(qn("w:rPr"))
                    if rpr is None: rpr = OxmlElement("w:rPr"); rr.insert(0, rpr)
                    for x in rpr.findall(qn("w:b")) + rpr.findall(qn("w:sz")) + rpr.findall(qn("w:rStyle")): rpr.remove(x)
                    if ri == 0: rpr.insert(0, OxmlElement("w:b"))
                    sz = OxmlElement("w:sz"); sz.set(qn("w:val"), "20"); rpr.append(sz)

def caption(text, keep=True):
    p = OxmlElement("w:p"); ppr = OxmlElement("w:pPr"); ps = OxmlElement("w:pStyle"); ps.set(qn("w:val"), "Caption"); ppr.append(ps)
    kn = OxmlElement("w:keepNext")
    if not keep: kn.set(qn("w:val"), "0")
    ppr.append(kn); p.append(ppr)
    rr = OxmlElement("w:r"); rp = OxmlElement("w:rPr"); rp.append(OxmlElement("w:b")); rr.append(rp)
    t = OxmlElement("w:t"); t.text = text; t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve"); rr.append(t); p.append(rr)
    return p

def table(rows, widths, cap):
    els = fragment("\n".join(rows) + "\n")
    for e in els:
        if e.tag == qn("w:tbl"): style_table(e, widths)
    return [caption(cap)] + els

def figure(path, title, text, alt):
    p = doc.add_paragraph(style="Body Text"); p.alignment = 1
    run = p.add_run(); run.add_picture(path, width=Inches(6.4))
    el = p._p; el.getparent().remove(el)
    ppr = el.find(qn("w:pPr")); ppr.find(qn("w:pStyle")).addnext(OxmlElement("w:keepNext"))
    for d in el.iter("{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}docPr"): d.set("descr", alt)
    cap = caption(title, keep=False)
    br = OxmlElement("w:r"); br.append(OxmlElement("w:br")); t = OxmlElement("w:t"); t.text = text
    t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve"); br.append(t); cap.append(br)
    return [el, cap]

def norm(s): return s.replace("\xa0", " ").replace("’", "'")
def find(start, style=None):
    for p in doc.paragraphs:
        if norm(p.text).startswith(start) and (style is None or p.style.name == style): return p
    raise KeyError(start)
def after(anchor, els):
    ref = anchor._p if hasattr(anchor, "_p") else anchor
    for e in els: ref.addnext(e); ref = e
    return ref
def append_text(p, text):
    rr = OxmlElement("w:r"); t = OxmlElement("w:t"); t.text = text
    t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve"); rr.append(t); p._p.append(rr)
def replace_in(p, old, new):
    for t in p._p.iter(qn("w:t")):
        if old in t.text: t.text = t.text.replace(old, new); return
    raise KeyError(old)
def set_text(p, text):
    ts = list(p._p.iter(qn("w:t")))
    for t in ts: t.text = ""
    ts[0].text = text

