# Counterfactual Branches for Autoregressive Do Calculus — Version 1 (1 November 2026)

Level-3 (counterfactual) reasoning for ADC: abduction, mechanism replacement and prediction with shared
background circumstances; twin networks under declared couplings; certified linear-fractional intervals.

Files
- kernel/ — C# (.NET 8). Cf.cs is new (twin networks, three couplings, Tian–Pearl and LP bounds, suffix answer,
  Charnes–Cooper intervals). Marginals.cs, Idc.cs (exact simplex, IV polytope), Exact.cs, Graph.cs, Distill.cs are series files.
- cs_cf.txt, out/cf_iv_records.json — census output and exported witnesses.
- validate_cf.py, validation_cf.json, validate_cf.log — independent Python validation (13 checks, all pass).
- fig_cf.py, fig/ — Figure 1.  paper_template.md, paper.md, build_paper.py (+ _helpers.py, _mathfix.py, _settingsfix.py).

Reproduce
    dotnet run -c Release --project kernel -- out --cf > cs_cf.txt
    python validate_cf.py cs_cf.txt out/cf_iv_records.json validation_cf.json
    python fig_cf.py && python build_paper.py   # needs Pandoc and the IDC V2 docx as style reference

Limits: five binary events, one fixed order, three couplings (a lower bound on counterfactual ambiguity);
one IV query family. No language model trained or queried; prediction cost counted in events, not time.
