// Level-3 numerics for ADC. (A) Twin-network counterfactuals on the inherited 6,144 positive binary DAG models
// under three exogenous couplings that share every observational and interventional law; Tian-Pearl bounds;
// sharp linear-programme bounds; the level-2 suffix-recomputation answer; dependency-local prediction.
// (B) Linear-fractional counterfactual bounds on the instrumental-variable response polytope (Charnes-Cooper),
// with support checks, naive endpoint division and reuse after new case evidence.
// Public values are immutable records; enumeration buffers are local scratch storage.
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text.Json;

namespace Tcr;

/// <summary>An exogenous coupling: how one node's response at two parent configurations co-varies under one shared U.</summary>
public enum Coupling { Comonotone, Independent, Alternating }

/// <summary>Twin network for one action node x set to x' = 0 in the counterfactual world. Pair weights are integers
/// on the scale grid² per node, so a full twin weight is exact on the scale grid^(2n).</summary>
public sealed record TwinNetwork(CptModel Model, int Grid, Coupling Kind)
{
    int Pk(int i, int c) => (int)(Model.Cpt[i][c].Num * Grid / Model.Cpt[i][c].Den);
    int Config(int i, int v) { int c = 0; for (int k = 0; k < Model.Parents[i].Length; k++) c |= (v >> Model.Parents[i][k] & 1) << k; return c; }
    /// <summary>Joint weight of factual value a at configuration cf and counterfactual value b at configuration cc.</summary>
    public Int128 Pair(int i, int a, int b, int cf, int cc)
    {
        int g = Grid; Int128 p = Pk(i, cf), r = Pk(i, cc), gg = (Int128)g * g;
        if (cf == cc) return a != b ? 0 : (a == 1 ? p : g - p) * g;
        bool flip = Kind == Coupling.Alternating && ((cf ^ cc) & 1) == 1 && (cf & 1) != (cc & 1);
        Int128 one;
        if (Kind == Coupling.Independent) return (a == 1 ? p : g - p) * (b == 1 ? r : g - r);
        one = flip ? Int128.Max(0, p + r - g) * g : Int128.Min(p, r) * g;          // P(both one)
        Int128 p10 = p * g - one, p01 = r * g - one, p00 = gg - one - p10 - p01;
        return a == 1 ? (b == 1 ? one : p10) : (b == 1 ? p01 : p00);
    }
    /// <summary>Weight of (factual v, counterfactual w) with do(X = 0) in the counterfactual world (w_x must be 0).</summary>
    public Int128 Weight(int x, int v, int w)
    {
        Int128 s = 1; int n = Model.N;
        for (int i = 0; i < n; i++)
        {
            int cf = Config(i, v);
            if (i == x) { int p = Pk(i, cf); s *= ((v >> i & 1) == 1 ? p : Grid - p) * Grid; }
            else s *= Pair(i, v >> i & 1, w >> i & 1, cf, Config(i, w));
            if (s == 0) return 0;
        }
        return s;
    }
}

public static class CfCensus
{
    static Q R(Int128 a, Int128 b) => new(BigInteger.Parse(a.ToString()), BigInteger.Parse(b.ToString()));
    static string S(Q q) => q.ToString();

    public static void Run(string dir, Action<string, object[]> emit)
    {
        Examples(emit);
        TwinCensus(emit);
        Fractional(dir, emit);
    }

    /// <summary>The two toy models of the paper: Y = 2X + U and the A/B pair Y = U versus Y = X xor U.</summary>
    static void Examples(Action<string, object[]> emit)
    {
        int u = 11 - 2 * 3, y1 = 2 * 1 + u;                                       // abduction U = 5, prediction Y_1 = 7
        // A: Y = U, B: Y = X xor U, X and U independent fair bits; evidence X = 0, Y = 0; query P(Y_1 = 1 | e)
        Q Cf(Func<int, int, int> f)
        {
            Q num = Q.Zero, den = Q.Zero;
            for (int x = 0; x <= 1; x++) for (int uu = 0; uu <= 1; uu++)
            {
                if (x != 0 || f(x, uu) != 0) continue;
                den += Q.Of(1, 4); if (f(1, uu) == 1) num += Q.Of(1, 4);
            }
            return num / den;
        }
        Q obsA = Q.Of(1, 2), obsB = Q.Of(1, 2);
        emit("cf_examples", new object[] { u, y1, S(Cf((x, uu) => uu)), S(Cf((x, uu) => x ^ uu)), S(obsA), S(obsB) });
    }

    static void TwinCensus(Action<string, object[]> emit)
    {
        const int n = 5;
        var pairs = (from i in Enumerable.Range(0, n) from j in Enumerable.Range(i + 1, n - i - 1) select new Edge(i, j)).ToArray();
        var kinds = new[] { Coupling.Comonotone, Coupling.Independent, Coupling.Alternating };
        long gx = 0, desc = 0, suffix = 0;
        foreach (var (tag, grid, seed) in new[] { ("tenths", 10, 20261031001UL), ("hundredths", 100, 20261031002UL) })
        {
            var rng = new Rng(seed);
            long q = 0, sound = 0, lpTp = 0, allEq = 0, comoLo = 0, comoUp = 0, l2Out = 0, kept = 0, spread10 = 0, spread25 = 0, lpFail = 0, identified = 0;
            double widthSum = 0, spreadMax = 0, l2Gap = 0;
            for (int dm = 0; dm < 1 << pairs.Length; dm++)
            {
                var g = Admg.Make(n, pairs.Where((_, k) => (dm >> k & 1) != 0), Array.Empty<Edge>());
                if (tag == "tenths")
                    for (int x = 0; x < n; x++) { gx++; desc += SetBits.Count(Descendants(g, 1 << x) & ~(1 << x)); suffix += n - 1 - x; }
                for (int r = 0; r < 3; r++)
                {
                    CptModel model; (model, rng) = CptModel.Random(g, rng, grid);
                    var obs = model.Law(); var mo = Marginals.Of(obs);
                    for (int x = 0; x < n; x++)
                    {
                        int de = Descendants(g, 1 << x) & ~(1 << x);
                        var ys = Enumerable.Range(x + 1, n - x - 1).Where(y => (de >> y & 1) != 0).ToArray();
                        if (ys.Length == 0) continue;
                        var twins = kinds.Select(k => new TwinNetwork(model, grid, k)).ToArray();
                        // twin weights restricted to factual X = 1 (the evidence) and counterfactual X = 0 (the action)
                        var wts = twins.Select(t => new Int128[32, 32]).ToArray();
                        for (int ti = 0; ti < twins.Length; ti++)
                            for (int v = 0; v < 32; v++)
                            {
                                if ((v >> x & 1) != 1) continue;
                                for (int w = 0; w < 32; w++) if ((w >> x & 1) == 0)
                                {
                                    var wt = twins[ti].Weight(x, v, w); wts[ti][v, w] = wt;
                                    // dependency-local prediction: non-descendants never differ across worlds
                                    if (wt != 0 && ((v ^ w) & ~de & ~(1 << x) & 31) != 0) throw new InvalidOperationException("non-descendant changed");
                                }
                            }
                        kept++;
                        var dol0 = model.Law(x, 0); var md0 = Marginals.Of(dol0);
                        foreach (int y in ys)
                        {
                            q++;
                            Q pxy = mo.Mass(1 << x | 1 << y, 1 << x | 1 << y);
                            var pn = Enumerable.Range(0, twins.Length).Select(ti =>
                            {
                                Int128 num = 0, den = 0;
                                for (int v = 0; v < 32; v++) if ((v >> x & 1) == 1 && (v >> y & 1) == 1)
                                    for (int w = 0; w < 32; w++) if ((w >> x & 1) == 0) { den += wts[ti][v, w]; if ((w >> y & 1) == 0) num += wts[ti][v, w]; }
                                return R(num, den);
                            }).ToArray();
                            Q py = mo.Mass(1 << y, 1 << y), pyx0 = md0.Mass(1 << y, 1 << y), px0y0 = mo.Mass(1 << x | 1 << y, 0);
                            Q lo = Q.Max(Q.Zero, (py - pyx0) / pxy), hi = Q.Min(Q.One, (Q.One - pyx0 - px0y0) / pxy);
                            if (pn.All(p => lo <= p && p <= hi)) sound++;
                            widthSum += (hi - lo).ToDouble(); if (lo == hi) identified++;
                            Q sp = pn.Max() - pn.Min(); spreadMax = Math.Max(spreadMax, sp.ToDouble());
                            if (sp.IsZero) allEq++; if (sp > Q.Of(1, 10)) spread10++; if (sp > Q.Of(1, 4)) spread25++;
                            if (pn[0] == lo) comoLo++; if (pn[0] == hi) comoUp++;
                            var (slo, shi, ok) = Sharp(mo, md0, Marginals.Of(model.Law(x, 1)), x, y);
                            if (!ok) lpFail++; else if (slo == lo && shi == hi) lpTp++;
                            // level-2 suffix recomputation: keep the prefix V_<x, discard the later evidence Y = 1
                            int pre = (1 << x) - 1; Q l2 = Q.Zero;
                            for (int v = 0; v < 32; v++)
                            {
                                if ((v >> x & 1) != 1 || (v >> y & 1) != 1) continue;
                                Q pv = obs[v]; if (pv.IsZero) continue;
                                Q cond = md0.Mass(pre | 1 << y, (v & pre)) / md0.Mass(pre, v & pre);   // P_do0(Y = 0 | prefix)
                                l2 += pv * cond;
                            }
                            l2 /= pxy;
                            if (l2 < lo || l2 > hi) l2Out++;
                            l2Gap += Rounding.Abs(l2 - pn[0]).ToDouble();
                        }
                    }
                }
            }
            emit($"cf_{tag}_pn", new object[] { q, sound, lpTp, lpFail, allEq, comoLo, comoUp, identified, spread10, spread25, l2Out, kept });
            emit($"cf_{tag}_pn_real", new object[] { widthSum / q, spreadMax, l2Gap / q });
        }
        emit("cf_prediction_cost", new object[] { gx, desc, suffix });
    }

    static int Descendants(Admg g, int s)
    {
        int old; do { old = s; foreach (var e in g.D) if ((s >> e.From & 1) != 0) s |= 1 << e.To; } while (s != old);
        return s;
    }

    /// <summary>Sharp bounds on PN from P(x, y) and P(y_x), P(y_x') by the bivariate response LP (8 types).</summary>
    static (Q Lo, Q Hi, bool Ok) Sharp(Marginals mo, Marginals md0, Marginals md1, int x, int y)
    {
        // type k = xv * 4 + ty, Y(x) = ty >> x & 1
        Q[] Row(Func<int, int, bool> f) => Enumerable.Range(0, 8).Select(k => f(k >> 2, k & 3) ? Q.One : Q.Zero).ToArray();
        var a = new List<Q[]> { Row((xv, ty) => true), Row((xv, ty) => xv == 0 && (ty & 1) == 0), Row((xv, ty) => xv == 0 && (ty & 1) == 1),
            Row((xv, ty) => xv == 1 && (ty >> 1 & 1) == 0), Row((xv, ty) => (ty & 1) == 1), Row((xv, ty) => (ty >> 1 & 1) == 1) };
        int xm = 1 << x, ym = 1 << y;
        var b = new[] { Q.One, mo.Mass(xm | ym, 0), mo.Mass(xm | ym, ym), mo.Mass(xm | ym, xm), md0.Mass(ym, ym), md1.Mass(ym, ym) };
        var c = Row((xv, ty) => xv == 1 && ty == 2);
        Q pxy = mo.Mass(xm | ym, xm | ym);
        try { var up = Lp.Max(a, b, c); var dn = Lp.Max(a, b, c.Select(v => -v).ToArray()); return (-dn.Value / pxy, up.Value / pxy, true); }
        catch (InvalidOperationException) { return (Q.Zero, Q.Zero, false); }
    }

    /// <summary>Charnes-Cooper bounds of a·q / b·q over the IV polytope with its reports: variables (r, t, slack)
    /// with r = t q, b·r = 1; equality rows E r − f t = 0, report rows A r − h t + s = 0.</summary>
    static (Q Value, ImmutableArray<Q> Q, Q T) Ratio(IvPolytope p, Q[] num, Q[] den, bool maximise)
    {
        const int T = IvPolytope.T; var (prow, prhs, eq) = p.PaperRows(); int ni = prow.Count - eq, nv = T + 1 + ni;
        var rows = new List<Q[]>(); var rhs = new List<Q>();
        for (int i = 0; i < prow.Count; i++)
        {
            var row = new Q[nv]; for (int j = 0; j < nv; j++) row[j] = Q.Zero;
            for (int j = 0; j < T; j++) row[j] = prow[i][j];
            row[T] = -prhs[i]; if (i >= eq) row[T + 1 + i - eq] = Q.One;
            rows.Add(row); rhs.Add(Q.Zero);
        }
        rows.Add(Enumerable.Range(0, nv).Select(j => j < T ? Q.One : j == T ? -Q.One : Q.Zero).ToArray()); rhs.Add(Q.Zero);
        rows.Add(Enumerable.Range(0, nv).Select(j => j < T ? den[j] : Q.Zero).ToArray()); rhs.Add(Q.One);
        var c = Enumerable.Range(0, nv).Select(j => j < T ? (maximise ? num[j] : -num[j]) : Q.Zero).ToArray();
        var s = Lp.Max(rows, rhs.ToArray(), c);
        Q t = s.X[T];
        var q = t.IsZero ? ImmutableArray<Q>.Empty : s.X.Take(T).Select(v => v / t).ToImmutableArray();
        return (maximise ? s.Value : -s.Value, q, t);
    }

    /// <summary>One assumption level: bounds, naive division, truth containment.</summary>
    static Dictionary<string, object> Level(IvPolytope p, Q[] a, Q[] b, ImmutableArray<Q> truth, long[] cnt, double[] w)
    {
        Q Dot(Q[] c, IReadOnlyList<Q> q) => Enumerable.Range(0, IvPolytope.T).Aggregate(Q.Zero, (s, k) => s + c[k] * q[k]);
        Q bmax = p.Max(b).Value, bmin = -p.Max(b.Select(v => -v).ToArray()).Value;
        Q amax = p.Max(a).Value, amin = -p.Max(a.Select(v => -v).ToArray()).Value;
        var rec = new Dictionary<string, object> { ["bmin"] = S(bmin), ["bmax"] = S(bmax) };
        cnt[0]++; if (bmax.Sign <= 0) return rec;
        cnt[1]++;
        var hi = Ratio(p, a, b, true); var lo = Ratio(p, a, b, false);
        if (hi.T.Sign > 0 && lo.T.Sign > 0) cnt[2]++;
        Q nlo = amin / bmax, nhi = bmin.IsZero ? Q.One : Q.Min(Q.One, amax / bmin);
        if (bmin.IsZero) cnt[3]++;
        if (nlo <= lo.Value && hi.Value <= nhi) cnt[4]++;
        if (nlo < lo.Value || hi.Value < nhi) cnt[5]++;
        Q tb = Dot(b, truth); if (tb.Sign > 0) { Q tr = Dot(a, truth) / tb; cnt[6]++; if (lo.Value <= tr && tr <= hi.Value) cnt[7]++; }
        if (lo.Value == hi.Value) cnt[8]++;
        w[0] += (hi.Value - lo.Value).ToDouble(); w[1] += (nhi - nlo).ToDouble();
        rec["L"] = S(lo.Value); rec["U"] = S(hi.Value); rec["qL"] = lo.Q.Select(S).ToArray(); rec["qU"] = hi.Q.Select(S).ToArray();
        rec["nL"] = S(nlo); rec["nU"] = S(nhi);
        return rec;
    }

    static void Fractional(string dir, Action<string, object[]> emit)
    {
        const int N = 1000, Ty = IvPolytope.T;
        var rng = new Rng(20261101002UL);
        int Draw(int lo, int hi) { int k; (k, rng) = rng.Int(lo, hi); return k; }
        Q[] Ind(Func<int, bool> f) => Enumerable.Range(0, Ty).Select(k => f(k) ? Q.One : Q.Zero).ToArray();
        int Mask(Func<int, bool> f) => Enumerable.Range(0, Ty).Where(f).Aggregate(0, (m, k) => m | 1 << k);
        var y0no = Ind(k => IvPolytope.Yof(k, 0) == 0);
        var a1 = Ind(k => IvPolytope.Yof(k, 1) == 1 && IvPolytope.Yof(k, 0) == 0);
        var b2 = Ind(k => IvPolytope.Yof(k, 0) == 0 && IvPolytope.Xof(k, 1) == 1);
        var a2 = Ind(k => IvPolytope.Yof(k, 1) == 1 && IvPolytope.Yof(k, 0) == 0 && IvPolytope.Xof(k, 1) == 1);
        int m1 = Mask(k => IvPolytope.Yof(k, 1) == 1), m0 = Mask(k => IvPolytope.Yof(k, 0) == 1), mv = Mask(k => IvPolytope.Yof(k, 0) == 1 && IvPolytope.Yof(k, 1) == 0);
        var names = new[] { "iv", "iv_exp", "iv_mtr", "iv_exp_mtr" };
        var cnt = names.Select(_ => new long[9]).ToArray(); var w = names.Select(_ => new double[2]).ToArray();
        long q2n = 0, q2notIn = 0, q2disj = 0; double wq2 = 0;
        var recs = new List<Dictionary<string, object>>();
        Q Mass(int mask, IReadOnlyList<Q> q) => Enumerable.Range(0, Ty).Where(k => (mask >> k & 1) != 0).Aggregate(Q.Zero, (s, k) => s + q[k]);
        for (int inst = 0; inst < N; inst++)
        {
            var wts = Enumerable.Range(0, Ty).Select(_ => Draw(0, 4)).ToArray(); if (wts.Sum() == 0) wts[Draw(0, 15)] = 1;
            var qs = wts.Select(v => Q.Of(v, wts.Sum())).ToImmutableArray();
            // a second truth that satisfies monotone treatment response Y(1) >= Y(0)
            var wm = wts.Select((v, k) => (mv >> k & 1) != 0 ? 0 : v).ToArray(); if (wm.Sum() == 0) wm[0] = 1;
            var qm = wm.Select(v => Q.Of(v, wm.Sum())).ToImmutableArray();
            var rec = new Dictionary<string, object> { ["q"] = qs.Select(S).ToArray(), ["qm"] = qm.Select(S).ToArray() };
            IvPolytope Make(ImmutableArray<Q> truth, bool exp, bool mtr)
            {
                var reps = ImmutableArray.CreateBuilder<(int, Q, Q)>();
                if (exp) { reps.Add((m1, Mass(m1, truth), Mass(m1, truth))); reps.Add((m0, Mass(m0, truth), Mass(m0, truth))); }
                if (mtr) reps.Add((mv, Q.Zero, Q.Zero));
                return new IvPolytope(IvPolytope.DataOf(truth), reps.ToImmutable());
            }
            var levels = new[] { (qs, false, false), (qs, true, false), (qm, false, true), (qm, true, true) };
            for (int li = 0; li < 4; li++)
            {
                var (tq, e, m) = levels[li];
                rec[names[li]] = Level(Make(tq, e, m), a1, y0no, tq, cnt[li], w[li]);
            }
            // new case evidence X(1) = 1 changes the query, not only the constraints (experimental level)
            var pe = Make(qs, true, false);
            if (pe.Max(b2).Value.Sign > 0)
            {
                q2n++;
                var h2 = Ratio(pe, a2, b2, true); var l2 = Ratio(pe, a2, b2, false);
                var r1 = (Dictionary<string, object>)rec["iv_exp"]; Q lo = new Q(System.Numerics.BigInteger.Parse(((string)r1["L"]).Split('/')[0]), ((string)r1["L"]).Contains('/') ? System.Numerics.BigInteger.Parse(((string)r1["L"]).Split('/')[1]) : 1);
                Q hi = new Q(System.Numerics.BigInteger.Parse(((string)r1["U"]).Split('/')[0]), ((string)r1["U"]).Contains('/') ? System.Numerics.BigInteger.Parse(((string)r1["U"]).Split('/')[1]) : 1);
                wq2 += (h2.Value - l2.Value).ToDouble();
                if (l2.Value < lo || h2.Value > hi) q2notIn++;
                if (l2.Value > hi || h2.Value < lo) q2disj++;
                rec["L2"] = S(l2.Value); rec["U2"] = S(h2.Value);
            }
            recs.Add(rec);
        }
        for (int li = 0; li < 4; li++)
            emit($"cf_ratio_{names[li]}", new object[] { cnt[li], w[li][0] / cnt[li][1], w[li][1] / cnt[li][1] });
        emit("cf_reuse_new_evidence", new object[] { q2n, q2notIn, q2disj, wq2 / q2n });
        File.WriteAllText(Path.Combine(dir, "cf_iv_records.json"), JsonSerializer.Serialize(recs));
    }
}
