---
title: "Counterfactual Branches for Autoregressive Do Calculus"
subtitle: "Level-3 causal reasoning by abduction, twin networks and certified intervals"
---

Debi Prasad Ghosh

Version 1, 1 November 2026

Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India

## Abstract

Pearl's causal hierarchy separates association, intervention and counterfactuals. A counterfactual asks what would have happened to the same case under another assignment, given what actually happened. Recomputing a Transformer's key-value cache after an edited prefix does not by itself answer that question. It discards the factual suffix that should inform the case's background circumstances, and it follows token order rather than causal order. We define a counterfactual branch for Autoregressive Do Calculus (ADC). The branch keeps the factual record intact, infers the background circumstances by abduction, applies an explicit mechanism replacement and predicts with the same circumstances. Four algorithms implement the branch, its dependency-local prediction, its certified interval and its reuse rule. An immutable C# kernel computes all quantities exactly. On «Q» probability-of-necessity queries over 3,072 positive five-event DAG models per parameter grid, three exogenous couplings with identical observational and interventional laws never agreed. Their spread exceeded 0.25 in «S25H» of finer-grid queries. Every coupling answer lay inside the Tian–Pearl bounds, and an exact linear programme reproduced those bounds in every query. The answer obtained by recomputing from the edited prefix differed from the comonotone counterfactual by «GAPH» on average. Non-descendants of the edited event never changed across worlds, so prediction recomputed «DESC» events against «SUF» in token order. On 1,000 instrumental-variable polytopes, a linear-fractional programme bounds P(Y₁=1 | Y₀=0). Its mean width fell from «W0» with instrument data alone to «W1» with experimental marginals and to zero under monotone treatment response with experiments. Adding new case evidence moved the interval outside the old one in «REUSE» of cases. An independent Python program validates every result. No language model was trained or queried.

**Keywords** counterfactuals; causal hierarchy; abduction; twin networks; probability of necessity; partial identification; linear-fractional programming; autoregressive reasoning; key-value cache

# 1 Introduction

The causal hierarchy has three levels (Pearl, 2009; Bareinboim et al., 2022). Association concerns $P(Y \mid X = x)$. Intervention concerns $P(Y \mid do(X = x'))$. A counterfactual concerns $P(Y_{x'} = y \mid E = e)$: given the evidence $e$ about what actually happened to a case, how would its outcome have behaved under $x'$? The causal hierarchy theorem shows that, in general, quantities at a higher level are not determined by data from lower levels (Bareinboim et al., 2022).

An autoregressive Transformer conditions on a prefix and extends it. If a retrospection engine edits a token several thousand positions back, the cached keys and values after that position no longer describe the edited prefix, and the suffix is recomputed. Recomputation is a matter of cost. The causal level is fixed by the meaning of the computation. A recomputed suffix sampled from the edited prefix answers, at best, an interventional or conditional question about that prefix. It discards the factual suffix. A counterfactual uses that suffix as evidence about the case.

A Transformer can execute an interpreter for counterfactual queries. With recorded sampling noise, its own token generator is a structural causal model and counterfactual token sequences can be produced (Oberst & Sontag, 2019; Chatzi et al., 2025). That construction concerns the text generator and depends on an untestable choice of noise coupling. The present paper concerns counterfactuals about the world that the text describes, and treats the coupling choice as part of the declared model.

## 1.1 Relation to earlier work

Autoregressive Do Calculus (Ghosh, 2026a) represents events, mechanisms and sequential evidence. Interval Do Calculus (Ghosh, 2026b) certifies intervals over admissible models and specifies reuse by refinement, witnesses and multipliers. Task observability (Ghosh, 2026c) concerns which task quantities a retained state can determine. Task-sufficient geometry (Ghosh, 2026d) and certified archive memory (Ghosh, 2026e) concern what an adaptive computation must retain. The operation-certificate work separates value agreement, operation licences and latent execution (Ghosh, 2026f). This paper adds a counterfactual branch to that programme.

The three-step procedure of abduction, action and prediction, and the twin network that links factual and counterfactual worlds, are classical (Balke & Pearl, 1994; Pearl, 2009). Probabilities of causation and their bounds are due to Tian and Pearl (2000). Complete counterfactual identification procedures, ID* and IDC*, are given by Shpitser and Pearl (2008). Linear-fractional programmes reduce to linear programmes by the Charnes–Cooper transformation (Charnes & Cooper, 1962). Monotone treatment response is a standard partial-identification assumption (Manski, 1997). We use these results; the contribution is their integration into ADC as checked operations, with exact numerics.

## 1.2 Contribution and status

We give a record contract for counterfactual branches, four algorithms, and six propositions about suffix recomputation, cross-world invariance, coupling non-identification, linear-fractional bounds and reuse. An exact C# census tests each claim on declared finite families, and an independent Python program re-derives every number. The study is mathematical. No language model is trained or queried, and no claim is made about wall-clock speed.

# 2 Three questions about one case

**Table 1 The causal hierarchy for one case**

| Level | Question | Object |
|---|---|---|
| Association | What accompanies $X = x$? | $P(Y \mid X = x)$ |
| Intervention | What happens if $X = x'$ is imposed? | $P(Y \mid do(X = x'))$ |
| Counterfactual | Given what actually happened, what would have happened to this case under $X = x'$? | $P(Y_{x'} \mid E = e)$ |

Let a structural causal model have assignments $V_i = f_i(\mathrm{Pa}_i, U_i)$ with background variables $U$. For a finite model,

$$P(Y_{x'} = y \mid E = e) = \sum_{u} \mathbf{1}\{Y_{x'}(u) = y\}\, P(u \mid E = e).\quad\quad\text{~~~~(1)}$$

The factual and hypothetical outcomes are linked through the same $u$. For $Y = 2X + U$, the observation $X = 3, Y = 11$ gives $U = 5$, and imposing $X := 1$ gives $Y_1 = 7$. The factual record $Y = 11$ is retained and used to infer $U$; the counterfactual outcome is not forced to equal it.

Correcting an erroneous record is a different operation. It revises the evidence or the model. A counterfactual leaves the factual record unchanged and adds a separately labelled alternative.

**Definition 2.1 (counterfactual branch record).** A branch record contains a case identity, model and mechanism versions, a factual evidence snapshot, an abducted background law or response-type constraint set, a branch identity, the intervention as a mechanism replacement, the requested outcome, dependencies and a certificate or interval status. The factual branch keeps the accepted observations and their provenance. The counterfactual branch keeps the replacement, the shared background identity and the predicted consequences.

The horizontal sheaf of ADC organises overlapping descriptions within each world. Across worlds, the branch must declare what is shared: case identity, background circumstances, unaffected mechanisms, units and variable meanings. Gluing must not impose $Y^{\text{factual}} = Y^{\text{counterfactual}}$ because both name the same physical quantity. The sheaf supplies compatibility checks within a world; the causal model supplies the connection between worlds.

# 3 Algorithms

**Algorithm 1 (counterfactual branch).** *Input:* a finite model with mechanisms and a declared exogenous coupling, factual evidence $e$, an action $X := x'$ and an outcome event. *Output:* $P(Y_{x'} = y \mid e)$ exactly, or an interval from Algorithm 3.

(1) *Abduction.* Enumerate joint factual and counterfactual assignments $(v, w)$ with $w_X = x'$. Weight each node $i \ne X$ by the coupling kernel $K_i(v_i, w_i \mid \mathrm{pa}_i(v), \mathrm{pa}_i(w))$, which gives the probability that one shared $U_i$ produces $v_i$ at the factual parent value and $w_i$ at the counterfactual one. Weight $X$ by its factual mechanism only. (2) *Action.* The counterfactual world uses $x'$ for every child of $X$. (3) *Prediction.* Sum the weights consistent with $e$ and with the requested counterfactual outcome, and divide by the weight consistent with $e$. All weights are exact integers on a fixed grid scale.

**Algorithm 2 (dependency-local prediction).** With the evidence fixed, recompute only the descendants of the intervened event; every other event keeps its factual value (Proposition 4.2). If the evidence itself changes, rerun abduction: posterior quantities can change for non-descendants.

**Algorithm 3 (certified counterfactual interval).** *Input:* a response-type polytope $K = \{q \ge 0 : Eq = f,\ Aq \le h,\ \mathbf{1}^{\mathsf{T}} q = 1\}$ and a query $a^{\mathsf{T}} q / b^{\mathsf{T}} q$, where $b$ is the factual evidence event and $a$ is the joint factual and counterfactual event. (1) Check support: $\max_K b^{\mathsf{T}} q > 0$, else return *undefined*. (2) Solve the Charnes–Cooper programme in $(r, t)$: maximise or minimise $a^{\mathsf{T}} r$ subject to $Er = ft$, $Ar \le ht$, $\mathbf{1}^{\mathsf{T}} r = t$, $b^{\mathsf{T}} r = 1$, $r, t \ge 0$, in exact rational arithmetic. (3) If $t > 0$, return the witness $q = r/t$, which attains the endpoint. (4) Return the sharp interval with witnesses, or endpoint division $[\min a^{\mathsf{T}} q / \max b^{\mathsf{T}} q,\ \max a^{\mathsf{T}} q / \min b^{\mathsf{T}} q]$ as a cheaper outer bound.

**Algorithm 4 (branch reuse).** Keep an old counterfactual interval as an outer bound when new constraints are added and the query, including its evidence event, is unchanged. When the case evidence changes, the query has changed: rerun Algorithm 3.

# 4 Results on structure

**Proposition 4.1 (suffix recomputation omits abduction from the suffix).** Let the factual evidence be $e = (e_{<}, x, y)$, where $e_{<}$ is the prefix before $X$ and $y$ is a later outcome. Recomputing from the edited prefix yields $\mathbb{E}[P(Y = y' \mid do(X = x'), e_{<}) \mid e]$. The counterfactual is $P(Y_{x'} = y' \mid e)$. The two coincide when the later evidence carries no information about the background variables of $Y$ beyond $e_{<}$, but not in general.

*Proof.* Under recomputation, the edited prefix is the only conditioning information for the new suffix, so its outcome law is the interventional law given $e_{<}$; averaging over the factual cases gives the first expression. Equation (1) conditions the background variables on all of $e$, including $y$. ∎

**Proposition 4.2 (cross-world invariance of non-descendants).** In a twin network with shared background variables and any coupling kernel that returns identical outputs at identical parent values, every non-descendant of $X$ takes the same value in both worlds with probability one.

*Proof.* Order the events topologically. A non-descendant other than $X$ has only non-descendant parents, which agree by induction; its two parent values are therefore identical, and the kernel returns identical outputs. ∎

**Proposition 4.3 (couplings are not identified by levels 1 and 2).** For binary events, let three couplings assign each node the same response probabilities $p_i(c)$ at every parent value $c$: comonotone ($V_i = \mathbf{1}\{U_i < p_i(c)\}$), independent across parent values, and alternating (comonotone between parent values of equal parity, countermonotone otherwise). All three induce the same observational law and the same interventional law for every intervention, but can induce different counterfactual laws.

*Proof.* A single-world law under any set of interventions is a product of the response probabilities at the parent values that occur, which are the same in all three couplings. A twin-network law uses the joint response at two different parent values, which the couplings specify differently. The example of Section 5.1 gives different values. ∎

**Proposition 4.4 (when the evidence probability is fixed, the ratio is linear).** If $b^{\mathsf{T}} q$ is constant on $K$, the bounds of $a^{\mathsf{T}} q / b^{\mathsf{T}} q$ are the linear bounds of $a^{\mathsf{T}} q$ divided by that constant, and endpoint division is exact. Otherwise, endpoint division is a valid outer bound that can be strictly wider than the Charnes–Cooper interval.

*Proof.* With constant denominator the ratio is linear on $K$. In general, for every feasible $q$, $\min a^{\mathsf{T}} q / \max b^{\mathsf{T}} q \le a^{\mathsf{T}} q / b^{\mathsf{T}} q \le \max a^{\mathsf{T}} q / \min b^{\mathsf{T}} q$; the extremes of numerator and denominator need not occur at the same $q$. The Charnes–Cooper transformation is exact for positive denominators (Charnes & Cooper, 1962). ∎

**Proposition 4.5 (new evidence changes the counterfactual query).** Adding constraints with the evidence event fixed preserves an old outer interval. Conditioning on additional case evidence replaces $(a, b)$ by $(a \wedge g, b \wedge g)$ and can move the interval outside the old one.

*Proof.* The first claim is refinement reuse (Ghosh, 2026b). For the second, the conditional probability given more evidence is a different functional; Section 5.3 shows that its interval often is not contained in the old one. ∎

The toy pair of the companion discussion makes Proposition 4.3 concrete. With $X$ and $U$ independent fair bits, $Y = U$ and $Y = X \oplus U$ have the same observational law and $P(Y = 1 \mid do(X = x)) = 1/2$ for both values. After observing $X = 0, Y = 0$ both give $U = 0$, yet $P(Y_1 = 1 \mid X = 0, Y = 0)$ is «TOYA» in the first model and «TOYB» in the second. If both models are admissible, the certified answer is $[0, 1]$. More tokens or more caching cannot remove this ambiguity; only structural assumptions or counterfactual data can.

# 5 Exact census

## 5.1 Couplings, bounds and suffix recomputation

The first census reuses the series family: all 1,024 DAGs on five binary events that respect one fixed order, with three positive models per graph whose conditional probabilities lie on a tenths or a hundredths grid (Ghosh, 2026f). For every model and every pair in which $X$ is an ancestor of $Y$, the census computes the probability of necessity

$$\mathrm{PN} = P(Y_{X=0} = 0 \mid X = 1, Y = 1)\quad\quad\text{~~~~(2)}$$

by Algorithm 1 under the three couplings of Proposition 4.3. It also computes the Tian–Pearl bounds

$$\max\Big\{0, \frac{P(y) - P(y_{x'})}{P(x, y)}\Big\} \le \mathrm{PN} \le \min\Big\{1, \frac{P(y'_{x'}) - P(x', y')}{P(x, y)}\Big\},\quad\quad\text{~~~~(3)}$$

which use only observational and interventional quantities (Tian & Pearl, 2000). An exact linear programme over the eight response types of $(X, Y)$, constrained by the same quantities, gives the sharp bounds independently. The suffix-recomputation answer of Proposition 4.1 keeps the events before $X$ and discards the later evidence $Y = 1$.

Table 2 summarises the results. Every coupling answer lay inside (3), and the linear programme reproduced (3) in every query, confirming that the Tian–Pearl bounds are sharp for these data. No query was point identified. The three couplings never agreed; their spread exceeded 0.1 in «S10H» and 0.25 in «S25H» of hundredths queries, and reached the full width 1 in some queries. The comonotone coupling attained the lower bound in «COMOH» of hundredths queries and never attained the upper bound, consistent with its role as a monotonicity assumption. The suffix-recomputation answer stayed inside (3) in every query, but differed from the comonotone counterfactual by «GAPH» on average. Lying inside the interval does not make it the counterfactual of any declared coupling.

CAPTION: Table 2 Probability of necessity under three couplings with identical levels 1 and 2

«TABLE2»

FIGURE: fig/cf_couplings_and_ladder.png | Figure 1 Coupling spread and the assumption ladder | Left: spread of PN across the comonotone, independent and alternating couplings, which share every observational and interventional law; the spread was never zero. Right: mean width of the sharp interval for P(Y₁=1 | Y₀=0) on 1,000 instrumental-variable polytopes, and of endpoint division, as assumptions are added. Exact census; not a learned-model experiment.

## 5.2 Cross-world invariance and prediction cost

For every model and every action event with descendants (9,408 per grid), the census checked every twin weight of every coupling. No non-descendant ever differed between the factual and counterfactual worlds, as Proposition 4.2 requires. Over the 5,120 pairs of graph and action event, prediction under fixed evidence recomputed «DESC» descendant events in total. Recomputing every later event in token order would have recomputed «SUF» («RATIO»). In five events the saving is modest; it grows with the number of later events that are causally unrelated to the edited one. This saving applies to causal prediction. A full revised transcript rendered by a language model may still need its own key-value computation.

## 5.3 Linear-fractional bounds on an instrumental-variable polytope

The second census uses the binary instrumental-variable model with 16 response types (Balke & Pearl, 1997). Each of 1,000 instances draws a true response law with integer weights from 0 to 4. The counterfactual query is

$$P(Y_1 = 1 \mid Y_0 = 0) = \frac{P(Y_1 = 1, Y_0 = 0)}{P(Y_0 = 0)},\quad\quad\text{~~~~(4)}$$

whose denominator is not fixed by instrument data. Algorithm 3 computes it at four assumption levels: instrument data; instrument data with experimental marginals $P(Y_1 = 1)$ and $P(Y_0 = 1)$; instrument data with monotone treatment response $Y_1 \ge Y_0$ (Manski, 1997), using a second true law that satisfies it; and both additions.

Table 3 reports the ladder. Every interval contained the true value and every endpoint was attained by a witness. With instrument data alone the mean width was «W0»: the data say almost nothing about this counterfactual. Experimental marginals fixed the denominator, so endpoint division coincided with the sharp interval, as Proposition 4.4 predicts, and the width fell to «W1». Monotone response alone left the denominator free; the sharp interval had width «W2», and endpoint division was strictly wider in «MTRW» of instances. Together, the two assumptions identified the counterfactual in every instance.

CAPTION: Table 3 Counterfactual interval for P(Y₁=1 | Y₀=0) as assumptions are added (1,000 instances)

«TABLE3»

For Algorithm 4, the census added case evidence $X(z{=}1) = 1$ at the experimental level. In «Q2N» instances the new query was defined. Its interval was not contained in the old one in «REUSEN» («REUSE») and was disjoint from it in «DISJ». An old counterfactual interval is not a cache hit for a case with more evidence.

## 5.4 Validation

An independent Python program recomputes every census line. It evaluates the twin networks with Python integers and separately written coupling kernels, the bounds (3) with fractions, the sharp bounds with the HiGHS solver in SciPy, and the suffix answer and descendant counts from the graphs. For the instrumental-variable census it re-solves every interval with an independently written Charnes–Cooper programme, checks every exported witness exactly for feasibility and attained ratio, and recounts all events. All «NCHK» checks pass, with a largest floating-point discrepancy of «WORST».

# 6 Use in an AI harness and in retrospection

In the harness, the language model proposes a counterfactual: which event to change, to what, and which outcome to ask about. ADC compiles it into a branch record. The checker establishes the evidence snapshot, the declared coupling or response-type class and the support condition. Algorithm 1 or 3 returns a value or an interval with its status. Algorithm 2 recomputes only causal descendants while the evidence is fixed. Algorithm 4 decides whether an old branch can be reused. The language model then renders the result as text. Its key-value cache serves that rendering; it is not the authoritative state of the counterfactual.

This also clarifies what retrospection needs. Remembering a long factual history is necessary but not sufficient. The system must retain the mechanisms, the background-variable constraints that the history implies, and an explicit statement of which couplings it is prepared to assume. Without the last item, Section 5.1 shows that the same observational and interventional knowledge can support very different counterfactual stories.

# 7 Falsifiable hypotheses

**H1 (branch fidelity).** In a synthetic text world generated from a known structural causal model, an ADC branch will leave every non-descendant fact unchanged after an edit thousands of tokens back, whereas suffix regeneration will change some of them. Any changed non-descendant fact in an ADC branch refutes the implementation.

**H2 (cost follows descendants).** At fixed evidence, ADC branch cost will scale with the number of descendants of the edited event and not with suffix length. A fitted cost slope in suffix length whose confidence interval excludes zero at fixed descendant count refutes the prediction.

**H3 (certified coverage).** For queries whose ground truth is computed from the generating model under its stated assumptions, every ADC interval will contain the truth. One violation under correct assumptions refutes the implementation.

**H4 (assumption sensitivity is reported).** When two admissible couplings disagree by more than the requested tolerance, the harness will return an interval or an unresolved status rather than a point. Returning a point in such a case is an error, not a speed gain.

# 8 Limitations

The census covers five binary events in one fixed order and three couplings; it does not span all couplings, so the coupling spread is a lower bound on counterfactual ambiguity. The instrumental-variable census uses one query family and one evidence extension. Tian–Pearl bounds use only the action and outcome; richer evidence requires Algorithm 3 on a larger response space, where independent latent blocks make the constraints multilinear and the linear-fractional programme becomes an outer relaxation. General counterfactual identification requires ID* and IDC* style reasoning where applicable (Shpitser & Pearl, 2008). Prediction cost is counted in events, not time. No language model, agent or human retrospection has been studied.

# 9 Conclusion

Level 3 is a matter of meaning, not of cache mechanics. ADC reaches it by keeping the factual record, inferring background circumstances from all of it, replacing a mechanism and predicting with the same circumstances. The exact census shows why each part is needed. Couplings that agree on every observational and interventional law disagree on counterfactuals, so a certified interval or an explicit assumption is required. Suffix recomputation gives a number that differs from a declared counterfactual by about a quarter on average. Cross-world invariance lets prediction follow causal descendants rather than token order. Linear-fractional programming gives sharp intervals when the evidence probability is not fixed, and new case evidence makes old intervals unsafe to reuse.

# Appendix A Reproduction

The source bundle contains the C# project (kernel/Cf.cs, with the series files for exact rationals, graphs, models, marginals and the exact simplex), its output cs_cf.txt and the exported records out/cf_iv_records.json. Run dotnet run -c Release --project kernel -- out --cf to reproduce them in about twenty seconds. Then run python validate_cf.py cs_cf.txt out/cf_iv_records.json validation_cf.json, fig_cf.py for Figure 1 and build_paper.py for this document. The kernel targets .NET 8; the validator uses Python 3 with NumPy and SciPy. Public values are immutable records; enumeration buffers and simplex tableaux are local scratch storage.

# References

Balke, A., & Pearl, J. (1994). Counterfactual probabilities: Computational methods, bounds and applications. In *Proceedings of the 10th Conference on Uncertainty in Artificial Intelligence* (pp. 46–54). https://arxiv.org/abs/1302.6784

Balke, A., & Pearl, J. (1997). Bounds on treatment effects from studies with imperfect compliance. *Journal of the American Statistical Association, 92*(439), 1171–1176. https://doi.org/10.1080/01621459.1997.10474074

Bareinboim, E., Correa, J. D., Ibeling, D., & Icard, T. (2022). On Pearl's hierarchy and the foundations of causal inference. In H. Geffner, R. Dechter, & J. Y. Halpern (Eds.), *Probabilistic and causal inference: The works of Judea Pearl* (pp. 507–556). ACM. https://doi.org/10.1145/3501714.3501743

Charnes, A., & Cooper, W. W. (1962). Programming with linear fractional functionals. *Naval Research Logistics Quarterly, 9*(3–4), 181–186. https://doi.org/10.1002/nav.3800090303

Chatzi, I., Corvelo Benz, N., Straitouri, E., Tsirtsis, S., & Gomez-Rodriguez, M. (2025). Counterfactual token generation in large language models. In *Proceedings of the Fourth Conference on Causal Learning and Reasoning*, PMLR 275. https://proceedings.mlr.press/v275/chatzi25a.html

Ghosh, D. (2026a). *Autoregressive Do Calculus with Sequential Evidence*. https://doi.org/10.13140/RG.2.2.24386.75209

Ghosh, D. (2026b). *Certified Causal Memory with Interval Do Calculus (IDC)*. https://doi.org/10.13140/RG.2.2.11436.83848

Ghosh, D. (2026c). *Task Observability in Latent Causal Reasoning*. https://doi.org/10.13140/RG.2.2.25697.47204

Ghosh, D. (2026d). *Task Sufficient Geometry and Certified Growth in Adaptive Optimisation*. https://doi.org/10.13140/RG.2.2.27244.12167

Ghosh, D. (2026e). *Certified Archive Memory for Adaptive Multiobjective Optimisation*. https://doi.org/10.13140/RG.2.2.29524.77442

Ghosh, D. (2026f). *Operation Certificates for Latent Causal Reasoning* (Version 3). Author manuscript.

Manski, C. F. (1997). Monotone treatment response. *Econometrica, 65*(6), 1311–1334. https://doi.org/10.2307/2171738

Oberst, M., & Sontag, D. (2019). Counterfactual off-policy evaluation with Gumbel-max structural causal models. In *Proceedings of the 36th International Conference on Machine Learning*, PMLR 97, 4881–4890. https://proceedings.mlr.press/v97/oberst19a.html

Pearl, J. (2009). *Causality: Models, reasoning, and inference* (2nd ed.). Cambridge University Press.

Shpitser, I., & Pearl, J. (2008). Complete identification methods for the causal hierarchy. *Journal of Machine Learning Research, 9*, 1941–1979. https://jmlr.org/papers/v9/shpitser08a.html

Tian, J., & Pearl, J. (2000). Probabilities of causation: Bounds and identification. *Annals of Mathematics and Artificial Intelligence, 28*(1–4), 287–313. https://doi.org/10.1023/A:1018912507879
