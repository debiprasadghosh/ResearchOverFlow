#!/bin/sh
# Render the paper source with the recorded results, convert it with pandoc and post-process the Word file.
set -e
cd "$(dirname "$0")"
python3 render.py
pandoc paper.md -o raw.docx --reference-doc=ref.docx --no-highlight
python3 postprocess.py raw.docx paper.docx
echo "paper.docx written"
