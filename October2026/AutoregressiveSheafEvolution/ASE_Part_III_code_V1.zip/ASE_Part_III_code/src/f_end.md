
# 6 Register of numerical checks

Table 5 lists every numerical check in Part III. A main script produced {{d.n_main}} checks and a supplementary script {{d.n_extra}}; the pilot of Section 5.3 and the kernel comparison of Appendix A complete the list. All scripts write machine-readable results, and every number in this paper is read from those files when the document is built. The checks test the implementations and illustrate the statements; the proofs establish them. Random archives are synthetic, so ratios to bounds describe these constructions, not engineering archives in general.

Table: **Table 5.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 2.2 | coefficients, {{c.variance_bookkeeping.schedules}} schedules | bookkeeping {{c.variance_bookkeeping.max_rel_err\|e1}}; (19.2) to {{c.variance_bookkeeping.coefficient_err\|e1}} |
| 2 | Proposition 2.3 | ADE recovery, {{c.ade_stack.cases}} stacks | {{c.ade_stack.max_rel_err\|e1}} |
| 3 | Theorem 3.1 | separation, {{c.separation.cases}} paths | {{c.separation.max_rel_err\|e1}} |
| 4 | Theorem 3.2 | noise budget, {{c.noise_budget.schedules}} schedules; oracle | {{c.noise_budget.max_rel_err\|e1}}; output deviation within 0.3% of $s_0$ |
| 5 | Corollary 3.3 | deterministic weights, cosine table | {{c.deterministic_weights.omega_err\|e1}}; V2 table reproduced |
| 6 | Proposition 3.4 | Euler and score forms, {{c.euler_identity.cases}} layers | {{c.euler_identity.max_err\|e1}} |
| 7 | Theorem 3.5 | continuum limit, 40,000 tokens | KS {{d.ks4\|f3}} to {{d.ks256\|f4}} from 4 to 256 layers |
| 8 | Proposition 3.6 | clean-top re-selection | {{d.clean_share\|pct1}} on records; frequencies within {{c.clean_top.max_frequency_error\|f4}} |
| 9 | Proposition 3.7 | hulls, {{c.hulls.identity_cases}} and {{c.hulls.masked_cases}} stacks | {{c.hulls.identity_violations}} identity outputs outside; {{c.hulls.masked_outside}} masked outputs outside |
| 10 | Proposition 4.1 | layer Jacobian, {{c.layer_jacobian.cases}} layers | {{c.layer_jacobian.fd_rel_err\|e1}}; {{c.layer_jacobian.bound_violations}} bound violations |
| 11 | Theorem 4.2 | composites, {{c.composite.cases}} and {{c.composite.noisy_cases}} stacks | {{c.composite.floor_violations}} violations; floor attained; volume {{c.composite.volume_err\|e1}} |
| 12 | Corollary 4.3 | clean-top sandwich; Part I replayed | {{c.composite.clean_lower_violations}} and {{c.composite.clean_upper_violations}} violations; {{x.part_one.lower_holds}} of {{x.part_one.tokens}} tokens |
| 13 | Proposition 4.4(i), (ii) | Morse index and balance, {{c.morse.archives}} archives | {{c.morse.agree}} of {{c.morse.stationary_points}} points; {{c.morse.balanced_archives}} balanced |
| 14 | Proposition 4.4(iii), Example 4.5 | pitchfork and fold | tangent {{c.bifurcation.equal_tangent_at_midpoint\|f4}}; fold at {{c.bifurcation.unequal_fold_scale\|f4}} |
| 15 | Proposition 4.6 | thresholded ranks, {{c.effective_rank.random_chains}} chains; Part I | {{c.effective_rank.chains_with_negative_multiplicity}} negative; exact {{c.effective_rank.exact_negative}}; {{d.neg_1e2}} tokens at $10^{-2}$ |
| 16 | Proposition 5.2 | one-dimensional modes, {{c.causality_1d.archives}} archives | {{c.causality_1d.violations}} increases |
| 17 | Example 5.3 | triangle counts and Morse balance | four modes from 0.41 to 0.425; fold {{x.triangle_morse.fold_scale\|f4}} |
| 18 | Section 5.1 | components against modes, {{c.components_vs_modes.pairs}} pairs | {{c.components_vs_modes.share\|pct1}} agree |
| 19 | Theorem 5.4(i) | path curvature, {{c.euler_density.points}} points | median {{c.euler_density.median_rel_err\|e1}}; forms {{c.euler_density.moment_form_err\|e1}} |
| 20 | Theorem 5.4(ii) | curvature bound, {{x.curvature_bound.cases}} cases | {{x.curvature_bound.violations}} violations; largest ratio {{x.curvature_bound.ratio_max\|f4}} |
| 21 | Proposition 5.5 | efficiency against loss, pilot | {{d.eff_rank_text}} |
| 22 | Section 5.3 | C3 pilot, {{d.pilot_instances}} archives | {{d.c3_summary}} |
| 23 | Appendix A | C# kernel against NumPy | {{v.agree}} of {{v.lines}} lines agree; {{v.identical}} identical to 15 digits |

# 7 Discussion

## 7.1 What Part III supplies to the rest of the book

Part IV, on targets and estimation, needs the law of the proposals. Theorem 3.5 identifies it in the continuum limit: a deterministic stack with identity maps proposes from $p_{s_0}$, the archive density at the top scale. Its discretisation error is controlled by the curvature of Theorem 5.4. With a clean top, Proposition 3.6 says the stack proposes from the archive itself. The noise budget fixes the exact Gaussian part of any stochastic stack. These are the facts an importance weight or a Gibbs target must be built on.

Part V, on fusion and constraints, needs end-to-end sensitivities. Theorem 4.2 gives two-sided bounds for every singular value of a composite. Corollary 4.3 shows that at a clean top the composite is the top posterior covariance up to explicit factors, so the sensitivity of an output design to its starting query is decided by how concentrated the last read is. Part VI, on evidence and computation, takes the diagnostics of Table 6 and the kernel of Appendix A as specifications.

For the hypotheses of V2, the pilot of Section 5.3 bears on C3, and Proposition 5.5 gives it a quantitative form: whether a schedule can halve its layers depends on the efficiency of the baseline, which the archive alone determines.

## 7.2 Diagnostics a stack should report

Table: **Table 6.** Diagnostics reported with every stack.

| Diagnostic | Source | Action when it is poor |
|:-------------------|:-------------------|:-------------------------------|
| weight $\omega_\star$ and the noise budget split | Theorem 3.2 | report both shares of $s_0^2$ |
| eigenvalues of the top posterior covariance and the excess $X$ | Corollary 4.3 | report with every sensitivity claim |
| layers where $c>s^2$ along each path | Proposition 4.1 | flag branch decisions; never threshold them away |
| exact barcode and singular-value profile | Proposition 4.6 | never report a thresholded barcode |
| component barcode, not mode counts, in two or more dimensions | Proposition 5.1, Example 5.3 | use modes only as a proxy, with its agreement rate |
| curvature density $g$ and schedule efficiency $e$ | Proposition 5.5 | move layers to where $\sqrt g$ is large |
| re-selection share and the size of each novelty channel | Propositions 3.6, 3.7 | state which channel produced each novel output |

## 7.3 What is not claimed

The exact statements use identity edge maps; masks and general maps change the Jacobian of a read and break the transport interpretation of Theorem 3.5, whose read is no longer a score. The continuum results are limits, with first-order rates, not finite-layer guarantees. The stochastic stack, $\eta>0$, is observed to converge but is not proved to. The error model of Proposition 5.5 omits error propagation and is tested only empirically. The pilot is exploratory: it uses a transport metric instead of the optimisation outcomes of V2, and it does not settle C3. No statement here concerns search performance.

## 7.4 Open problems

1. **Stochastic stacks.** Prove convergence, with a rate, of the stack with $\eta>0$ to the reverse-time equation of the archive mixture, whose score is known exactly.
2. **Transport with maps.** Find the density, if any, whose score is the sheaf read with masks or rectangular maps, so that Theorem 3.5 extends beyond identity maps.
3. **Propagation-aware schedules.** Weight the curvature density by the composite tangents of Theorem 4.2, and compare with second-order layers that spend two reads per step.
4. **Mode zigzags.** Describe the births and deaths of modes across scales in two and more dimensions as a zigzag module, using the eigenvalue-one crossings of Proposition 4.4.
5. **A stable sensitivity summary.** Find a summary of numerical sensitivity along a tangent diagram that is stable under perturbation and consistent with rank invariants.
6. **C3 in the optimisation setting.** Run the confirmatory C3 protocol of V2, with output loss on the design objective, and add the curvature schedule as a declared comparator.

## 7.5 Conclusion

A stack of ASE layers is a schedule acting on reads. The schedule fixes how outputs mix starting state, reads and noise, and it fixes the noise budget. In the continuum limit the deterministic stack transports the coarse archive density to the fine one, and a clean top turns it into a weighted re-selection of the archive. Tangents never contract below the schedule's own ratio except at the top read, and they expand exactly where the energy has negative curvature, which is also where modes are born, die and change type. Components form a filtration across layers; modes do not, and thresholded ranks do not either. Token paths curve only where the posterior is spread, which tells a schedule where its layers matter. {{d.conclusion_pilot}} Part IV now turns from the stack to the targets it serves.

# References

::: {custom-style="Bibliography"}
[1] Anderson, B. D. O. (1982). Reverse-time diffusion equation models. *Stochastic Processes and their Applications* 12(3), 313–326.

[2] Babaud, J., Witkin, A. P., Baudin, M. and Duda, R. O. (1986). Uniqueness of the Gaussian kernel for scale-space filtering. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 8(1), 26–33.

[3] Carlsson, G. (2009). Topology and data. *Bulletin of the American Mathematical Society* 46(2), 255–308.

[4] Carreira-Perpiñán, M. Á. and Williams, C. K. I. (2003a). On the number of modes of a Gaussian mixture. In *Scale Space Methods in Computer Vision*, Lecture Notes in Computer Science 2695, 625–640. Springer.

[5] Carreira-Perpiñán, M. Á. and Williams, C. K. I. (2003b). An isotropic Gaussian mixture can have more modes than components. Technical report EDI-INF-RR-0185, School of Informatics, University of Edinburgh.

[6] Efron, B. (2011). Tweedie's formula and selection bias. *Journal of the American Statistical Association* 106(496), 1602–1614.

[7] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[8] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[9] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[10] Ghosh, D. P. (2026d). *Horizontally Topological, Vertically Algebraic: The Two Axes of Autoregressive Sheaf Evolution. Part I: Sheaves on Covers and Representations of the Layer Order*. 18 October 2026.

[11] Ghosh, D. P. (2026e). *The Horizontal Layer: One Layer of Autoregressive Sheaf Evolution. Part II: Sheaf Attention, Gaussian Stalks, Locality and the Topology of Design Spaces*. 18 October 2026.

[12] Hairer, E., Nørsett, S. P. and Wanner, G. (1993). *Solving Ordinary Differential Equations I: Nonstiff Problems*, 2nd revised edn. Springer Series in Computational Mathematics 8. Springer.

[13] Horn, R. A. and Johnson, C. R. (1991). *Topics in Matrix Analysis*. Cambridge University Press.

[14] Karras, T., Aittala, M., Aila, T. and Laine, S. (2022). Elucidating the design space of diffusion-based generative models. *Advances in Neural Information Processing Systems* 35. arXiv:2206.00364.

[15] Lu, C., Zhou, Y., Bao, F., Chen, J., Li, C. and Zhu, J. (2022). DPM-Solver: a fast ODE solver for diffusion probabilistic model sampling in around 10 steps. *Advances in Neural Information Processing Systems* 35. arXiv:2206.00927.

[16] Milnor, J. W. (1965). *Topology from the Differentiable Viewpoint*. University Press of Virginia.

[17] Silverman, B. W. (1981). Using kernel density estimates to investigate multimodality. *Journal of the Royal Statistical Society, Series B* 43(1), 97–99.

[18] Song, J., Meng, C. and Ermon, S. (2021). Denoising diffusion implicit models. *International Conference on Learning Representations*. arXiv:2010.02502.

[19] Song, Y., Sohl-Dickstein, J., Kingma, D. P., Kumar, A., Ermon, S. and Poole, B. (2021). Score-based generative modeling through stochastic differential equations. *International Conference on Learning Representations*. arXiv:2011.13456.
:::

# Appendix A: an immutable C# reference kernel

The kernel computes schedule coefficients from scales or signal levels, the separation weights and the noise budget, runs a stack with identity maps along a given noise path, and multiplies the layer Jacobians into the composite tangent. It also gives the composite's singular values, the product bounds of Theorem 4.2, the volume (4.2), the expanding directions of a layer and the path curvature (5.2). Values are immutable records and functions are pure; the symmetric eigensolver, a cyclic Jacobi method, works on a private copy of its input. The kernel targets .NET 8 and uses only the base class library.

```csharp
{{file:cs/VerticalStack.cs}}
```

A driver program prints the coefficients, weights and noise budget of a five-layer schedule with $\eta=0.5$, and the cosine weights of Corollary 3.3. On five records in $ℝ^2$ it prints a noisy path with its separation residual, a deterministic path with its composite tangent, bounds and volume, and a clean-top path with the lower bounds of Corollary 4.3. It ends with the expanding directions at the midpoint of two records below and above the pitchfork, and one path curvature. An independent NumPy script recomputes every printed number (Table A1). Of the {{v.lines}} lines, {{v.identical}} are identical to 15 significant digits, and the largest relative difference is {{v.worst_rel_diff|e1}}.

Table: **Table A1.** C# kernel output against the NumPy recomputation.

| C# | NumPy | Agreement |
|:------------------|:------------------|:----------|
{{cs_rows}}

# Appendix B: reproducibility

All results were produced with Python {{env.python}}, NumPy {{env.numpy}}, SciPy {{env.scipy}}, Matplotlib {{env.matplotlib}} and .NET SDK {{env.dotnet}}. The script `p3_checks.py` runs the {{d.n_main}} main checks with seed 20261022 and writes `p3_checks.json`. The script `p3_extras.py` runs the {{d.n_extra}} supplementary checks, including the replay of Part I's experiment from its own random stream, and writes `p3_extras.json`. The script `p3_explore.py` runs the pilot of Section 5.3 with seed 20261024 and writes `p3_explore.json`. The shared primitives are in `p3_core.py`. The script `fig_p3.py` draws the figures; panels marked as recomputed use their own fixed seeds, and all other plotted values are read from the result files. The C# project in `cs/` builds the kernel and its driver, and `cs_validate.py` compares the driver's output with NumPy and writes `cs_validate.json`. The document is assembled by `render.py`, which reads every quoted number from these files, converted to Word by Pandoc and post-processed for equation layout and schema order. A code archive accompanies this paper.
