
## 5.3 An exploratory pilot of hypothesis C3

V2 states hypothesis C3 as follows: a $k$-layer schedule chosen from component persistence scales matches a $2k$-layer cosine schedule within 2% in declared output loss and novel-output share, on frozen multimodal families in dimensions 2, 4 and 8, with shared endpoint and cutoff rules; a $k$-layer geometric schedule is the control for layer thinning [9, Section 18]. The confirmatory test needs the optimisation families and output losses of V2. In the transport setting of Theorem 3.5, however, the quality of a schedule can be measured exactly, against the continuum flow from the same starting tokens. We ran that comparison as an exploratory pilot. The metrics and the decision rule were fixed in the script before the first run. After a trial on one archive, we replaced a flow-based estimate of the curvature density by the archive-only estimate described below and added the mass-weighted barcode schedule. Every schedule that was run is reported.

**Families and shared rules.** In each dimension $D\in\{2,4,8\}$ we froze {{e.instances}} archives of 27 records in three nested levels of clusters, with spreads 4, 1 and 0.25 before normalising to unit pooled deviation per coordinate, and log prior weights with standard deviation 0.5. Every schedule has a clean top, $s_0=0$, the coarse start $s_k$ equal to twice the largest merge radius, and a common finest positive scale $s_1$. With a *fine top*, $s_1$ is half the smallest merge radius, so the last read resolves every record. With a *coarse top*, $s_1$ is the median merge radius. {{e.tokens}} tokens per archive were drawn from $p_{s_k}$ and shared by all schedules, so every comparison is paired. The reference output of a token is the clean-top read at $s_1$ of the exact flow (3.5), integrated by the classical Runge–Kutta method in $\log s$ with step {{e.rk4_step}}; halving the step moved the reference outputs by at most {{d.ref_dev_max|e1}} nearest-neighbour distances.

Table: **Table 2.** Schedules in the pilot. All share $s_0=0$, $s_1$ and $s_k$; the rules place the $k-2$ interior scales.

| Schedule | Interior scales | Role |
|:---------------|:------------------------------------|:-----------------------|
| cosine | $\arctan s$ uniformly spaced | the C3 baseline, at $2k$ layers |
| geometric | $\log s$ uniformly spaced | the C3 control for thinning |
| EDM, $\rho=7$ | $s^{1/7}$ uniformly spaced [14] | a common sampler schedule |
| barcode, quantiles | merge radii at evenly spaced ranks | the C3 schedule |
| barcode, longest bars | the $k-2$ largest merge radii | a second reading of C3 |
| barcode, mass-weighted | quantiles of merge radii weighted by the prior mass that splits there | added after the trial |
| curvature | density proportional to $\sqrt g$, with $g$ from 300 draws of $p_s$ at {{e.curvature_grid}} scales | Proposition 5.5, archive only |

**Metrics.** The *path loss* is the mean distance between a schedule's output and the reference output, in units of the median nearest-neighbour distance $d_{nn}$ of the records. The *novel-output share* is the share of outputs farther than $10^{-3}d_{nn}$ from every record. For C3 we compared each barcode schedule with $k$ layers against cosine with $2k$ layers, for $k=4$, 8, 16 and 32. Degradation is the ratio of archive-mean losses minus one, and the novelty difference is in percentage points; both carry paired bootstrap 95% intervals over the archives, with 10,000 resamples. A comparison *supports* C3 if the loss interval lies below +2% and the novelty interval within ±2 points. It *refutes* C3 if the loss interval lies above +2% or the novelty interval lies outside ±2 points. Otherwise it is *inconclusive*.

Table: **Table 3.** Path loss pooled over $D=2$, 4 and 8, by schedule and number of layers $k$, with a fine top; the median efficiency $e$ of Proposition 5.5 at $k=16$; and the loss at $k=16$ with a coarse top.

| Schedule | $k=4$ | 8 | 16 | 32 | 64 | $e$ | coarse top |
|:----------------------|:------|:------|:------|:------|:------|:-----|:----------|
{{table:loss}}

Table: **Table 4.** The C3 comparison with a fine top: the barcode schedule with quantile placement and $k$ layers against cosine with $2k$ layers. Intervals are paired bootstrap 95% intervals. The last two columns give the degradation of the same barcode schedule against geometric with $k$ layers, and of the curvature schedule with $k$ layers against cosine with $2k$ layers.

| $D$ | $k$ | loss degradation, % | novelty difference, points | verdict | against geometric, % | curvature against cosine, % |
|:--|:--|:----------------|:----------------|:--------|:----------|:----------|
{{table:c3}}

{{file:src/pilot_results.md}}

![**Figure 5.** The schedule pilot. (a) For one archive in $ℝ^2$: the square root of the curvature density $g$, the 26 merge radii, and the scales of the seven schedules with eight layers. Most merge radii are fine, while most curvature lies at coarse scales. (b) Path loss against the number of layers, pooled over $D=2$, 4 and 8, with a fine top. (c) The C3 comparison: loss of the quantile barcode schedule and of the curvature schedule with $k$ layers, divided by the loss of cosine with $2k$ layers, with bootstrap 95% intervals; the dashed line is the 2% margin. (d) For every archive and $k=8$, 16 and 32, the error model (5.4) of each schedule against its path loss, both relative to cosine with the same $k$.](fig/schedules.png){width=100%}
