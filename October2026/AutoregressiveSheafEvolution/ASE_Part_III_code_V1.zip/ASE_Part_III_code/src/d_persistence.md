
# 5 Persistence across layers

Part I described two vertical persistence modules: the tangent fibre diagram of a token, and the cohomology of layer covers along a filtration [10, Sections 4.4–4.5]. Section 4.4 showed that the first must be read with exact ranks. This section asks which scale summaries of the archive form filtrations at all, since only those have barcodes, and then asks where in the scale range the layers of a stack actually matter. The second question is the subject of hypothesis C3 of V2.

## 5.1 Which scale summaries are filtrations

::: {custom-style="Statement"}
**Proposition 5.1** (component barcodes). Fix the records and open balls $B(y_i,r)$.
:::

::: {custom-style="Statement"}
\(i) For radii $r_0\le\cdots\le r_T$ the ball nerves are nested, and in the token direction the degree-zero maps are injective; every bar reaches the top (Part I, Proposition 4.10).
:::

::: {custom-style="Statement"}
\(ii) The number of components at radius $r$ is $n$ minus the number of merge heights $h_j<2r$, where $h_1\le\cdots\le h_{n-1}$ are the merge heights of single-linkage clustering of the records. In the token direction a bar is born at each merge radius $h_j/2$.
:::

::: {custom-style="Statement"}
\(iii) For two records at distance $d$ the merge radius $d/2$ is the pitchfork scale of Proposition 4.4(iv).
:::

::: {custom-style="Statement Tag"}
\(i) Part I Proposition 4.10; (ii) classical [3]; (iii) V2 Proposition 14.2.
:::

*Proof.* (ii) Two open balls of radius $r$ meet exactly when their centres are closer than $2r$, so the components of their union are the components of the graph that joins records at distance below $2r$. Single linkage merges components exactly at those thresholds. (iii) Proposition 4.4(iv). $\blacksquare$

Components are thus a filtration whose barcode the archive determines once and for all. Modes of $p_s$ are a different matter.

::: {custom-style="Statement"}
**Proposition 5.2** (in one dimension modes are only born in the token direction). For $D=1$ and positive weights, the number of modes of $p_s$ does not increase with $s$.
:::

::: {custom-style="Statement Tag"}
Classical [17, 2].
:::

::: {custom-style="Check"}
*Numerical check.* For {{c.causality_1d.archives}} random one-dimensional archives of 3 to 9 records with random weights, the mode count on {{c.causality_1d.scales}} geometric scales from 0.05 to 5 never increased; there were {{c.causality_1d.violations}} exceptions.
:::

::: {custom-style="Statement"}
**Example 5.3** (in two dimensions a mode is born as the scale grows). Place three records of equal weight at the vertices of an equilateral triangle with unit side. Then $p_s$ has three modes for $s<1/\sqrt6\approx0.4082$, four for $1/\sqrt6<s<0.4267$, and one for larger $s$. In units of the circumradius the two transitions are $\sqrt2/2$ and 0.7391, as found by Carreira-Perpiñán and Williams [5]. At $s=1/\sqrt6$ the tangent at the centroid reaches the expansion threshold in both directions at once (Proposition 4.4(iv)): the three saddles, approaching from the sides, pass through the centroid and leave towards the vertices, and the centroid turns from a minimum of the density into a mode. At $s\approx0.4267$ each vertex mode meets a saddle in a fold. The Morse balance holds throughout: $3-3+1=4-3+0=1-0+0=1$.
:::

::: {custom-style="Statement Tag"}
The mode counts Carreira-Perpiñán and Williams [5], who credit the example to Duistermaat, see also [4]; the mechanism and the exact first transition New in Part III.
:::

::: {custom-style="Check"}
*Numerical check.* Mode finding by the read iteration from a 41 by 41 grid gave three modes up to $s=0.4075$, four from 0.41 to 0.425 and one from 0.4275, in steps of 0.0025. Newton's method from 2,116 starts at twelve scales confirmed the counts of minima, saddles and maxima, with balance 1 at every scale. Bisection placed the fold at {{x.triangle_morse.fold_scale|f5}}, that is {{x.triangle_morse.circumradius_units.fold|f4}} circumradii, and the centroid switch at {{x.triangle_morse.centroid_switch_scale|f5}}.
:::

So in two dimensions the mode count is not monotone in $s$, the mode sets of successive layers do not form a filtration, and inclusion–exclusion on mode counts does not produce a barcode. The component barcode of the same three records is unaffected: the balls merge once, at $r=1/2$. V2 reported agreement between component counts and mode counts of 76% in one dimension and 80% in two, and called it a proxy rather than a theorem [9, Section 14]. For 30 random archives of 8 equal records in the unit square and {{c.components_vs_modes.scales}} scales from 0.03 to 0.6, with radius equal to scale, the counts agreed in {{c.components_vs_modes.agree}} of {{c.components_vs_modes.pairs}} pairs ({{c.components_vs_modes.share|pct1}}).

![**Figure 4.** (a) Stationary points of $E_s$ for records at $\pm1$: with equal weights a pitchfork at $s=1$, with weights 7 to 3 a fold at $s\approx0.737$ (Example 4.5). Grey points are saddles, where a layer expands. (b) Three equal records at the vertices of a unit triangle, with contours of $p_s$, modes, saddles and the density minimum at three scales. Between $s=1/\sqrt6$ and 0.4267 the centroid is a fourth mode (Example 5.3). (c) Counts of modes and saddles against $s$; the dotted line marks $s=1/\sqrt6$.](fig/modes.png){width=100%}

## 5.2 Where layers matter

Theorem 3.5(iii) locates the error of a layer in the motion of the read along its step. The next theorem says how fast the read moves.

::: {custom-style="Statement"}
**Theorem 5.4** (curvature of token paths). Use identity maps. Along a solution of (3.5), with $\alpha_i$, $m$ and $C$ evaluated at $(z(s),s)$, let
:::

::: {custom-style="Statement Equation"}
$M_3=\sum_i\alpha_i\Vert y_i-m\Vert^2\,(y_i-m)$ (5.1)
:::

::: {custom-style="Statement"}
\(i) The path curves as fast as the read moves:
:::

::: {custom-style="Statement Equation"}
$z''=\frac{C(z-m)-M_3}{s^4}=-\frac{1}{s}\,\frac{\text{d}m}{\text{d}s}$ (5.2)
:::

::: {custom-style="Statement"}
\(ii) If one record has posterior mass at least $1-\varepsilon$ and $R$ is the diameter of the records, then
:::

::: {custom-style="Statement Equation"}
$\Vert z''\Vert\le\frac{\varepsilon\left(R^2\Vert z-m\Vert+(1+\varepsilon^2)R^3\right)}{s^4}$ (5.3)
:::

::: {custom-style="Statement"}
\(iii) Hence, by (3.6), a layer whose step keeps the posterior concentrated on one record is exact up to $O(\varepsilon)$: token paths are straight lines except where the posterior is spread over several records.
:::

::: {custom-style="Statement Tag"}
New in Part III.
:::

*Proof.* (i) Differentiating $z'=(z-m)/s$ gives $z''=(z'-m')/s-(z-m)/s^2=-m'/s$, where $m'=\text{d}m/\text{d}s=(C/s^2)z'+\partial_sm$. Differentiating the softmax gives $\partial_s\alpha_i=(2/s^3)\alpha_i(e_i-\langle e\rangle)$ with $e_i=\tfrac12\Vert z-y_i\Vert^2$, so $\partial_sm=(2/s^3)\sum_i\alpha_i(e_i-\langle e\rangle)(y_i-m)$. Expanding $e_i$ about $m$, $e_i-\langle e\rangle=-(z-m)^{\top}(y_i-m)+\tfrac12(\Vert y_i-m\Vert^2-\langle\Vert y-m\Vert^2\rangle)$, hence $\partial_sm=(M_3-2C(z-m))/s^3$ and $m'=(M_3-C(z-m))/s^3$. (ii) $\Vert C\Vert\le\varepsilon R^2$ by Part I, Proposition 4.6(ii). For the dominant record $j$, $\Vert y_j-m\Vert\le\varepsilon R$, and $\Vert y_i-m\Vert\le R$ for every $i$, so $\Vert M_3\Vert\le(\varepsilon R)^3+\varepsilon R^3$. (iii) Insert (5.3) in (3.6). $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* At {{c.euler_density.points}} points on finely resolved flows in $ℝ^2$, second differences of the paths matched (5.2) to a median relative {{c.euler_density.median_rel_err|e1}} (largest {{c.euler_density.max_rel_err|e1}}, set by the reference flow), and the two forms of (5.2) agreed to {{c.euler_density.moment_form_err|e1}} of the scale of (5.3). In {{x.curvature_bound.cases}} random configurations, (5.3) had {{x.curvature_bound.violations}} violations; the largest ratio to the bound was {{x.curvature_bound.ratio_max|f4}} and the median {{x.curvature_bound.ratio_median|f3}}.
:::

Along the exact flow the token at scale $s$ has the law $p_s$ (Theorem 3.5(ii)). The mean curvature $g(s)=E_{z\sim p_s}\Vert z''\Vert$ can therefore be estimated from the archive alone, by sampling $p_s$ and evaluating (5.2), without running any flow.

::: {custom-style="Statement"}
**Proposition 5.5** (an error model and the layer-halving bound). For positive scales $s_1<\cdots<s_k$, replace $\text{max}\,\Vert z''\Vert$ in (3.6) by $g$ and sum the local errors:
:::

::: {custom-style="Statement Equation"}
$ℰ(s_1,\ldots,s_k)=\sum_{t=2}^{k}\frac{1}{2}(s_t-s_{t-1})\int_{s_{t-1}}^{s_t}g(s)\,\text{d}s$ (5.4)
:::

::: {custom-style="Statement"}
\(i) For a layer density $\rho$ with $\int\rho\,\text{d}s=k-1$, the continuum form $\tfrac12\int g/\rho\,\text{d}s$ of (5.4) is minimised by $\rho\propto\sqrt{g}$, with minimum
:::

::: {custom-style="Statement Equation"}
$ℰ_{\text{min}}(k)=\frac{1}{2(k-1)}\left(\int_{s_1}^{s_k}\sqrt{g(s)}\,\text{d}s\right)^2$ (5.5)
:::

::: {custom-style="Statement"}
\(ii) Call $e=ℰ_{\text{min}}/ℰ$ the efficiency of a schedule. Under the model, a $k$-layer schedule can match a $2k$-layer baseline only if the baseline's efficiency is at most $(k-1)/(2k-1)$, which is less than one half.
:::

::: {custom-style="Statement Tag"}
\(i) Classical in form, the equidistribution of local error [12]; (ii) New in Part III.
:::

*Proof.* (i) By the Cauchy–Schwarz inequality, $\left(\int\sqrt{g}\right)^2=\left(\int\sqrt{g/\rho}\,\sqrt{\rho}\right)^2\le\int(g/\rho)\int\rho$, with equality if and only if $\rho\propto\sqrt{g}$. (ii) A $k$-layer schedule has $ℰ\ge ℰ_{\text{min}}(k)$, while a $2k$-layer baseline of efficiency $e$ has $ℰ=ℰ_{\text{min}}(2k)/e$. By (5.5), $ℰ_{\text{min}}(k)\le ℰ_{\text{min}}(2k)/e$ if and only if $e\le(k-1)/(2k-1)$. $\blacksquare$

The model ignores how later layers propagate an error, which Theorem 4.2 shows can contract or expand it, and it replaces the worst case by the mean. It is a model, not a bound. Its value is that it makes the question behind C3 quantitative. Halving the number of layers at equal quality is impossible for first-order layers unless the baseline wastes more than half of its layers, and whether a schedule wastes layers is measured by $e$.
