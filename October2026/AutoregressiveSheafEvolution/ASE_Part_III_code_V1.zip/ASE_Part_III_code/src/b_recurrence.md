
# 2 The stack and its schedule

V2 converts ADE into scaled coordinates, in which every layer interpolates between the token and its read [9, Proposition 6.2]. The schedule enters only through the scales. We state the recurrence in that form, with the scale sequence as the primary object, because every identity below depends on the scales and on nothing else.

::: {custom-style="Statement"}
**Definition 2.1** (schedule and stack). Fix records $y_1,\ldots,y_n\in ℝ^D$ with prior weights $w_i>0$. A *schedule* consists of scales $0\le s_0<s_1<\cdots<s_T$ and a noise parameter $0\le\eta\le1$. Its coefficients are
:::

::: {custom-style="Statement Equation"}
$\gamma_t^2=\eta^2s_{t-1}^2\,\frac{s_t^2-s_{t-1}^2}{s_t^2},\qquad 1-\lambda_t=\frac{\sqrt{s_{t-1}^2-\gamma_t^2}}{s_t},\qquad t=1,\ldots,T$ (2.1)
:::

::: {custom-style="Statement"}
The *stack* is the recurrence (1.1), with $\xi_1,\ldots,\xi_T$ independent standard normal vectors, independent of the starting state $z_T$. The read of layer $t$ is $m_t(z)=m(z,s_t)$, where
:::

::: {custom-style="Statement Equation"}
$\alpha_i(z,s)=\frac{w_ie^{-\Vert z-y_i\Vert^2/2s^2}}{\sum_jw_je^{-\Vert z-y_j\Vert^2/2s^2}},\quad m(z,s)=\sum_i\alpha_iy_i,\quad C(z,s)=\sum_i\alpha_i(y_i-m)(y_i-m)^{\top}$ (2.2)
:::

::: {custom-style="Statement"}
The top is *clean* when $s_0=0$. The archive density at scale $s>0$ is $p_s=\sum_i\beta_iN(y_i,s^2I)$, and the layer energy is
:::

::: {custom-style="Statement Equation"}
$E_s(z)=-s^2\log\sum_iw_ie^{-\Vert z-y_i\Vert^2/2s^2}$ (2.3)
:::

::: {custom-style="Statement Tag"}
V2 Proposition 6.2 and Section 7, with the scale sequence made primary; (2.3) is the soft energy of Part II with identity maps.
:::

With identity maps, $E_s=-s^2\log p_s+\text{const}$, its gradient is $z-m$ and its Hessian is $I-C/s^2$ (Part II, Proposition 3.9). The read (2.2) is sheaf attention with identity edge maps (Part II, Definition 2.2).

::: {custom-style="Statement"}
**Proposition 2.2** (coefficients and variance bookkeeping). Let $r_t=s_{t-1}/s_t$.
:::

::: {custom-style="Statement"}
\(i) $0\le\gamma_t^2\le s_{t-1}^2(1-r_t^2)$ and $1-r_t\le\lambda_t\le1-r_t^2$. In particular $0\le\lambda_t\le1$, and $\lambda_t$ increases with $\eta$, from $1-r_t$ at $\eta=0$ to $1-r_t^2$ at $\eta=1$.
:::

::: {custom-style="Statement"}
\(ii) $(1-\lambda_t)^2s_t^2+\gamma_t^2=s_{t-1}^2$.
:::

::: {custom-style="Statement"}
\(iii) If $s_t^2=(1-a_t)/a_t$ for signal levels $1\ge a_0\ge a_1\ge\cdots\ge a_T>0$, then $\gamma_t=\sigma_t/\sqrt{a_{t-1}}$ and $\lambda_t=1-A_t\sqrt{a_t/a_{t-1}}$, where $\sigma_t$ and $A_t$ are the coefficients (19.2) of the Mathematics book.
:::

::: {custom-style="Statement"}
\(iv) At a clean top, $\lambda_1=1$ and $\gamma_1=0$, so $z_0=m_1(z_1)$.
:::

::: {custom-style="Statement Tag"}
\(i), (ii) New in Part III in this form; (iii) Mathematics book Propositions 19.2 and 19.3, V2 Proposition 6.2; (iv) V2 Corollary 7.2.
:::

*Proof.* (i) $\gamma_t^2=\eta^2s_{t-1}^2(1-r_t^2)$, so the radicand in (2.1) is $s_{t-1}^2\,(1-\eta^2(1-r_t^2))$, which lies between $s_{t-1}^2r_t^2$ and $s_{t-1}^2$ and decreases in $\eta$. Taking the square root and dividing by $s_t$ gives $r_t^2\le1-\lambda_t\le r_t$. (ii) Square the second identity in (2.1). (iii) Substitute $s^2=(1-a)/a$: $\gamma_t^2=\eta^2\frac{1-a_{t-1}}{a_{t-1}}\cdot\frac{a_{t-1}-a_t}{a_{t-1}(1-a_t)}=\sigma_t^2/a_{t-1}$, and $\sqrt{s_{t-1}^2-\gamma_t^2}/s_t=\sqrt{(1-a_{t-1}-\sigma_t^2)\,a_t/((1-a_t)\,a_{t-1})}=A_t\sqrt{a_t/a_{t-1}}$. (iv) Here $r_1=0$. $\blacksquare$

Identity (ii) is the defining property of the family of Song, Meng and Ermon [18]: if the read were the true record, a layer would map noise of scale $s_t$ to noise of scale $s_{t-1}$. Theorem 3.2 below sums it over a stack.

::: {custom-style="Check"}
*Numerical check.* In {{c.variance_bookkeeping.schedules}} random schedules with 2 to 20 layers, scales between 0.02 and 30, a clean top in one case in four and random $\eta$, identity (ii) held to a relative {{c.variance_bookkeeping.max_rel_err|e1}}, every $\lambda_t$ lay in the unit interval, and the coefficients of (iii) matched (19.2) to {{c.variance_bookkeeping.coefficient_err|e1}}.
:::

::: {custom-style="Statement"}
**Proposition 2.3** (a stack is ADE in scaled coordinates). Let $s_t^2=(1-a_t)/a_t$ and $q_t=\sqrt{a_t}\,z_t$. For every realisation of the noise, the stack (1.1) with identity maps reproduces $T$ consecutive ADE proposal steps (19.1) of the Mathematics book, with the same retrieval weights at every layer and noise $\sigma_t\xi_t$.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 6.2, applied layer by layer.
:::

*Proof.* The weights agree because $\Vert q_t-\sqrt{a_t}y_i\Vert^2/(1-a_t)=\Vert z_t-y_i\Vert^2/s_t^2$. Dividing the ADE step $q_{t-1}=A_tq_t+B_tm_t+\sigma_t\xi_t$ by $\sqrt{a_{t-1}}$ and using Proposition 2.2(iii) gives (1.1) for one layer, and the layers compose. $\blacksquare$

The ADE bottom $a_T=0$ has $s_T=\infty$, so a stack in scaled coordinates needs a positive cutoff $a_T>0$ [9, Section 8]. The cutoff is where the starting state enters, and Section 3.3 shows that it is one of the channels of novelty.

::: {custom-style="Check"}
*Numerical check.* In {{c.ade_stack.cases}} random stacks with 2 to 16 layers, random levels, a clean top in about half of them and random $\eta$, the scaled stack and the ADE recursion in $q$ agreed to a relative {{c.ade_stack.max_rel_err|e1}} along the same noise paths.
:::

# 3 The token recurrence

## 3.1 Separation and the noise budget

Unrolling (1.1) separates what the schedule does from what the reads do.

::: {custom-style="Statement"}
**Theorem 3.1** (separation). Let realised reads $m_t$ and increments $\nu_t$ satisfy $z_{t-1}=(1-\lambda_t)z_t+\lambda_tm_t+\nu_t$ with $0\le\lambda_t\le1$. With $\pi_t=\prod_{u=1}^{t-1}(1-\lambda_u)$, $\omega_t=\lambda_t\pi_t$ and $\omega_\star=\prod_{u=1}^{T}(1-\lambda_u)$,
:::

::: {custom-style="Statement Equation"}
$z_0=\omega_\star z_T+\sum_{t=1}^{T}\omega_tm_t+\sum_{t=1}^{T}\pi_t\nu_t,\qquad \omega_\star+\sum_{t=1}^{T}\omega_t=1$ (3.1)
:::

::: {custom-style="Statement Tag"}
V2 Theorem 7.1.
:::

The weights depend only on the schedule, but the identity is pathwise: later reads depend on earlier ones through the queries, so (3.1) is an accounting identity, not a decomposition into independent effects [9, Section 7].

::: {custom-style="Check"}
*Numerical check.* Along {{c.separation.cases}} realised paths in dimensions 1 to 4, with up to 16 layers and random $\eta$, the right side of (3.1) reproduced the output to a relative {{c.separation.max_rel_err|e1}}, and the weights summed to one within {{c.separation.weight_sum_err|e1}}.
:::

For the coefficients (2.1), the noise term of (3.1) is $N=\sum_t\pi_t\gamma_t\xi_t$. Its size is fixed by the two end scales.

::: {custom-style="Statement"}
**Theorem 3.2** (the noise budget). For every schedule,
:::

::: {custom-style="Statement Equation"}
$\sum_{t=1}^{T}\pi_t^2\gamma_t^2=s_0^2-\omega_\star^2s_T^2$ (3.2)
:::

::: {custom-style="Statement"}
Consequently:
:::

::: {custom-style="Statement"}
\(i) $\omega_\star\le s_0/s_T$, with equality if and only if $\eta=0$ or $s_0=0$;
:::

::: {custom-style="Statement"}
\(ii) whatever the reads, the explicit noise $N$ has the law $N(0,(s_0^2-\omega_\star^2s_T^2)\,I)$, and it vanishes at a clean top;
:::

::: {custom-style="Statement"}
\(iii) if every read equals one point $y$, as for a one-record archive, and $z_T\sim N(y,s_T^2I)$, then $z_0\sim N(y,s_0^2I)$, for every schedule, every $\eta$ and every number of layers.
:::

::: {custom-style="Statement Tag"}
New in Part III.
:::

*Proof.* Since $\pi_{t+1}=(1-\lambda_t)\pi_t$, Proposition 2.2(ii) gives $\pi_t^2\gamma_t^2=\pi_t^2s_{t-1}^2-\pi_{t+1}^2s_t^2$. The sum telescopes to $\pi_1^2s_0^2-\pi_{T+1}^2s_T^2$, with $\pi_1=1$ and $\pi_{T+1}=\omega_\star$. (i) The left side of (3.2) is nonnegative. If $\eta>0$ and $s_0>0$, its first term is $\gamma_1^2=\eta^2s_0^2(1-s_0^2/s_1^2)>0$; otherwise every $\gamma_t\pi_t$ vanishes, since $\eta=0$ or, at a clean top, $\gamma_1=0$ and $\pi_t=0$ for $t\ge2$. (ii) $N$ is a fixed linear combination of independent standard normal vectors. (iii) By (3.1) and $\sum_t\omega_t=1-\omega_\star$, $z_0-y=\omega_\star(z_T-y)+N$, a sum of independent centred Gaussians with variances $\omega_\star^2s_T^2$ and $s_0^2-\omega_\star^2s_T^2$ per coordinate. $\blacksquare$

The noise channel can thus deposit at most the top variance $s_0^2$ in the output, and a schedule only decides how that budget is split between the starting state and fresh noise (Figure 1b). The calibration (iii) is exact for every finite stack, but only for one record. With several records the reads move with the token, and calibration becomes a continuum statement (Theorem 3.5).

::: {custom-style="Check"}
*Numerical check.* In {{c.noise_budget.schedules}} random schedules, (3.2) held to a relative {{c.noise_budget.max_rel_err|e1}}. With an oracle read $y=1.5$, twelve geometric layers from $s_T=10$ to $s_0=0.3$ and 200,000 tokens, the output standard deviation was {{c.noise_budget.oracle.0.output_sd|f4}}, {{c.noise_budget.oracle.1.output_sd|f4}} and {{c.noise_budget.oracle.2.output_sd|f4}} for $\eta=0$, 0.5 and 1, against $s_0=0.3$.
:::

::: {custom-style="Statement"}
**Corollary 3.3** (deterministic weights). For $\eta=0$, $1-\lambda_t=s_{t-1}/s_t$, $\pi_t=s_0/s_{t-1}$ and
:::

::: {custom-style="Statement Equation"}
$\omega_t=s_0\left(\frac{1}{s_{t-1}}-\frac{1}{s_t}\right),\qquad \omega_\star=\frac{s_0}{s_T}$ (3.3)
:::

::: {custom-style="Statement"}
with the product form of $\pi_t$ used at a clean top. For the limiting sixteen-layer cosine schedule $s_t=\tan(\pi t/32)$, the reads of layers 2, 3, 4, 5 and 6 to 16 carry the weights 0.5049, 0.1705, 0.0869, 0.0535 and 0.1843 in the query $z_1$.
:::

::: {custom-style="Statement Tag"}
V2 Corollary 7.2 and the table of V2 Section 8.
:::

::: {custom-style="Check"}
*Numerical check.* In {{c.deterministic_weights.cases}} random deterministic schedules, (3.3) held to {{c.deterministic_weights.omega_err|e1}} and $\omega_\star=s_0/s_T$ to {{c.deterministic_weights.omega_star_err|e1}}. The recomputed cosine weights were {{c.deterministic_weights.cosine_top_query.t2|f4}}, {{c.deterministic_weights.cosine_top_query.t3|f4}}, {{c.deterministic_weights.cosine_top_query.t4|f4}}, {{c.deterministic_weights.cosine_top_query.t5|f4}} and {{c.deterministic_weights.cosine_top_query.t6_to_16|f4}}, as in V2.
:::

## 3.2 The deterministic stack is a discretised transport

::: {custom-style="Statement"}
**Proposition 3.4** (precision coordinates). Let $\eta=0$ and $s_{t-1}>0$. With the precision $\tau_t=1/s_t$ and $w_t=z_t/s_t$, layer $t$ of (1.1) is
:::

::: {custom-style="Statement Equation"}
$w_{t-1}=w_t+(\tau_{t-1}-\tau_t)\,m_t(z_t)$ (3.4)
:::

::: {custom-style="Statement"}
the forward Euler step for $\text{d}w/\text{d}\tau=m$. Equivalently, $z_{t-1}=z_t+(s_{t-1}-s_t)(z_t-m_t)/s_t$, the forward Euler step for
:::

::: {custom-style="Statement Equation"}
$\frac{\text{d}z}{\text{d}s}=\frac{z-m(z,s)}{s}$ (3.5)
:::

::: {custom-style="Statement"}
and this step solves (3.5) exactly when the read is frozen at $m_t$ over the step. Summing (3.4) gives (3.3) as a left Riemann sum: $z_0=s_0\left(z_T/s_T+\sum_t(\tau_{t-1}-\tau_t)\,m_t\right)$.
:::

::: {custom-style="Statement Tag"}
(3.4) New in Part III; the Euler form Mathematics book Proposition 19.6, as a fractional score step, and Karras et al. [14], who list DDIM as Euler's method for $\sigma(t)=t$; the frozen-read form is first-order DPM-Solver, which equals DDIM [15].
:::

*Proof.* Divide the deterministic layer by $s_{t-1}$ and use $(1-\lambda_t)/s_{t-1}=1/s_t$ and $\lambda_t/s_{t-1}=1/s_{t-1}-1/s_t$. With $m$ frozen, (3.5) is linear with solution $z(s)=m+(s/s_t)(z_t-m)$, which at $s=s_{t-1}$ is the layer. Summing (3.4) from $t=T$ to 1 and multiplying by $s_0$ gives the last formula. $\blacksquare$

Figure 1c shows (3.4) for two records. The weights of Theorem 3.1 are the widths $s_0\Delta\tau_t$ of the Riemann sum, and the read curve that the sum approximates is the read along the exact flow of (3.5).

::: {custom-style="Statement"}
**Theorem 3.5** (the deterministic stack discretises a transport). Use identity maps and $s_0>0$.
:::

::: {custom-style="Statement"}
\(i) $m(z,s)-z=s^2\nabla\log p_s(z)$, so (3.5) is the probability-flow equation $\text{d}z/\text{d}s=-s\nabla\log p_s(z)$.
:::

::: {custom-style="Statement"}
\(ii) The densities satisfy $\partial_sp_s=s\Delta p_s$, and for $0<s<s'$ the flow map $\Phi_{s'\to s}$ of (3.5) pushes $p_{s'}$ forward to $p_s$.
:::

::: {custom-style="Statement"}
\(iii) If $z(\cdot)$ solves (3.5) with $z(s_t)=z_t$, the local error of the layer is
:::

::: {custom-style="Statement Equation"}
$z(s_{t-1})-z_{t-1}=s_{t-1}\int_{\tau_t}^{\tau_{t-1}}\left(m(z(\tau),1/\tau)-m_t\right)\text{d}\tau,\qquad \Vert z(s_{t-1})-z_{t-1}\Vert\le\frac{1}{2}(s_t-s_{t-1})^2\,\text{max}\,\Vert z''\Vert$ (3.6)
:::

::: {custom-style="Statement"}
with the maximum over the step: the error is caused only by the motion of the read.
:::

::: {custom-style="Statement"}
\(iv) As the largest step tends to zero with $s_0$ and $s_T$ fixed, the stack output tends to $\Phi_{s_T\to s_0}(z_T)$, uniformly on compact sets and at first order. If $z_T\sim p_{s_T}$, the law of the output tends to $p_{s_0}$.
:::

::: {custom-style="Statement Tag"}
\(i) Classical, Tweedie's formula [6] (Part II, Proposition 4.1); (ii) classical [19, 14]; (iii) New in Part III; (iv) classical [12].
:::

*Proof.* (i) Differentiate $p_s$: $\nabla p_s=\sum_i\beta_iN(z;y_i,s^2I)(y_i-z)/s^2$, so $\nabla\log p_s=(m-z)/s^2$. (ii) Each $N(y_i,s^2I)$ satisfies $\partial_s=s\Delta$, since its variance is $s^2$. With the velocity $v=-s\nabla\log p_s$, $\nabla\cdot(p_sv)=-s\Delta p_s=-\partial_sp_s$, so $p_s$ solves the continuity equation of the flow. The velocity is smooth with $\Vert Dv\Vert\le(1+R^2/4s^2)/s$ (Part II, Proposition 5.4), so the flow exists globally for $s\ge s_0$ and transports densities [19]. (iii) In precision coordinates the exact flow satisfies $w(\tau_{t-1})=w(\tau_t)+\int m\,\text{d}\tau$, while (3.4) uses $m_t$; subtract and multiply by $s_{t-1}$. The norm bound is Taylor's theorem with integral remainder for the Euler step in $s$. (iv) The right side of (3.5) is smooth with bounded derivatives on $s\ge s_0$, so Euler's method converges at first order [12]; uniform convergence of the maps on compacts gives convergence of the pushed-forward laws. $\blacksquare$

With $\eta>0$ the stack discretises a reverse-time stochastic equation instead [1, 19], and the same limit is observed numerically (Figure 2b), but we do not prove it here.

::: {custom-style="Check"}
*Numerical check.* In {{c.euler_identity.cases}} random layers, the layer, the Euler step and the score form (19.5) agreed to {{c.euler_identity.max_err|e1}}. For six records in one dimension, 40,000 tokens drawn from $p_{20}$ and geometric stacks down to $s_0=0.3$, the Kolmogorov–Smirnov distance to $p_{s_0}$ fell from {{d.ks4|f3}} with 4 layers to {{d.ks16|f3}}, {{d.ks64|f4}} and {{d.ks256|f4}} with 16, 64 and 256 layers, against a sampling floor of {{c.continuum.sampling_floor|f4}}. With $\eta=1$ the values were {{d.ks4n|f3}}, {{d.ks16n|f3}}, {{d.ks64n|f4}} and {{d.ks256n|f4}}. A Gaussian start with the ADE variance $1+s_T^2$ instead of $p_{s_T}$ raised the 256-layer distance to {{c.continuum.gaussian_start_ks|f4}}.
:::

![**Figure 2.** (a) Outputs of deterministic stacks with 4 and 64 geometric layers from $s_T=20$ to $s_0=0.3$, for 40,000 tokens drawn from $p_{20}$, against the density $p_{s_0}$ of six weighted records (recomputed with a fixed seed). (b) Kolmogorov–Smirnov distance to $p_{s_0}$ against the number of layers, for $\eta=0$ and $\eta=1$ (Theorem 3.5). (c) With a clean top, 256 geometric layers down to $s_1=0.01$ re-select the records with frequencies equal to their prior weights (Proposition 3.6).](fig/transport.png){width=100%}

## 3.3 Re-selection and the channels of novelty

::: {custom-style="Statement"}
**Proposition 3.6** (a clean top re-selects). Let $s_0=0$ and let the records be distinct.
:::

::: {custom-style="Statement"}
\(i) For every $\eta$ and every path, $z_0=m_1(z_1)$ lies in the convex hull of the records.
:::

::: {custom-style="Statement"}
\(ii) If $z_1\sim p_{s_1}$, then as $s_1\to0$ the output tends almost surely to the record from whose component $z_1$ was drawn. The law of $z_0$ tends to $\sum_i\beta_i\delta_{y_i}$.
:::

::: {custom-style="Statement"}
\(iii) Hence a stack in the continuum limit of Theorem 3.5, closed by a clean top, samples the archive itself: it re-selects records with probabilities equal to their prior weights and produces no new design.
:::

::: {custom-style="Statement Tag"}
\(i) V2 Corollary 7.2; (ii) and (iii) New in Part III.
:::

*Proof.* (i) Proposition 2.2(iv). (ii) Write $z_1=y_J+s_1\varepsilon$ with $P(J=i)=\beta_i$ and $\varepsilon\sim N(0,I)$. For $i\ne J$, $\alpha_i/\alpha_J=(w_i/w_J)\exp(-(\Vert y_J-y_i\Vert^2+2s_1\varepsilon^{\top}(y_J-y_i))/2s_1^2)$, which tends to zero almost surely, so $m_1(z_1)\to y_J$. (iii) Apply (ii) to the limit law $p_{s_1}$ of Theorem 3.5(iv). $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* For the six records of Figure 2, 40,000 tokens from $p_{20}$ and 256 geometric layers down to $s_1=0.01$ followed by a clean top, {{d.clean_share|pct1}} of the outputs lay within $10^{-6}$ of a record. The largest difference between a re-selection frequency and its prior weight was {{c.clean_top.max_frequency_error|f4}}, about twice the binomial standard error of the largest weight.
:::

V2 lists noise, the starting state, and transformed or recombined reads as distinct sources of novelty [9, Section 7]. Theorems 3.1 and 3.2 make the list exhaustive for identity maps and give each channel its size.

::: {custom-style="Statement"}
**Proposition 3.7** (the channels of novelty). Use identity maps and write $H=\text{conv}\{y_1,\ldots,y_n\}$.
:::

::: {custom-style="Statement"}
\(i) *Starting state.* $z_0-N$ lies in $\text{conv}(\{z_T\}\cup H)$, with weight $\omega_\star\le s_0/s_T$ on $z_T$.
:::

::: {custom-style="Statement"}
\(ii) *Noise.* $N$ has the law $N(0,(s_0^2-\omega_\star^2s_T^2)I)$ (Theorem 3.2).
:::

::: {custom-style="Statement"}
\(iii) *Blending.* The reads lie in $H$, and a read is a record only in the limit of a concentrated posterior; at a clean top the blending of the last read is the only channel left, and it closes as $s_1\to0$ (Proposition 3.6).
:::

::: {custom-style="Statement"}
\(iv) *Maps.* Non-identity maps can place reads outside $H$; coordinate masks do so whenever records disagree on complementary coordinates (Part II, Proposition 3.5). Discretisation error is not a channel: it moves outputs within $\text{conv}(\{z_T\}\cup H)$.
:::

::: {custom-style="Statement Tag"}
New in Part III; the list of channels is V2 Section 7.
:::

*Proof.* (i) In (3.1) every $\omega_t\ge0$, every read lies in $H$ and the weights of $z_T$ and the reads sum to one; Theorem 3.2(i) bounds $\omega_\star$. (ii) Theorem 3.2(ii). (iii) Proposition 3.6. (iv) Part II, Proposition 3.5, and (i) for any schedule. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* A linear program found the output of each of {{c.hulls.identity_cases}} deterministic stacks with identity maps inside $\text{conv}(\{z_T\}\cup H)$; there were {{c.hulls.identity_violations}} exceptions. With random coordinate masks in $ℝ^3$, {{c.hulls.masked_outside}} of {{c.hulls.masked_cases}} outputs lay outside that hull.
:::
