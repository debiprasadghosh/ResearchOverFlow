
# 4 Tangent dynamics

Along a realised path, with the noise held fixed, the derivative of the output with respect to the starting state is the product of the layer Jacobians. These products are the tangent fibre diagrams of Part I, and their exact barcodes and effective ranks were compared there [10, Section 4.4]. This section bounds their singular values, locates where they contract and expand, and shows why thresholded ranks cannot replace exact ones.

## 4.1 One layer

::: {custom-style="Statement"}
**Proposition 4.1** (a layer is a gradient step). Use identity maps and $s_t>0$. Without noise, layer $t$ is the gradient step $z\mapsto z-\lambda_t\nabla E_{s_t}(z)$, and its Jacobian is
:::

::: {custom-style="Statement Equation"}
$J_t(z)=(1-\lambda_t)I+\lambda_t\,C(z,s_t)/s_t^2=I-\lambda_t\nabla^2E_{s_t}(z)$ (4.1)
:::

::: {custom-style="Statement"}
It is symmetric, with eigenvalues $1-\lambda_t+\lambda_tc/s_t^2$ for the eigenvalues $c$ of $C$, all in $[1-\lambda_t,\ 1-\lambda_t+\lambda_tR^2/4s_t^2]$. If $\lambda_t>0$, the layer expands along an eigenvector $u$ of $C$ if and only if $c>s_t^2$, that is, if and only if $u$ is a direction of negative curvature of $E_{s_t}$ at $z$. In every direction orthogonal to the affine span of the records it multiplies by exactly $1-\lambda_t$.
:::

::: {custom-style="Statement Tag"}
The Jacobian and its bound V2 Proposition 13.1 and Part II Proposition 5.4; the gradient form Part II Proposition 3.9 and Corollary 3.12; the expansion criterion New in Part III.
:::

*Proof.* $\nabla E_s=z-m$ and $\nabla^2E_s=I-C/s^2$ (Part II, Proposition 3.9), so $(1-\lambda)z+\lambda m=z-\lambda\nabla E_s$ and (4.1) follows. The variance of the records along a unit vector is at most $R^2/4$. An eigenvalue exceeds one exactly when $\lambda(c/s^2-1)>0$. The range of $C$ is the direction space of the affine span of the records (Part I, Proposition 4.6(i)), so $Cu=0$ for $u$ orthogonal to it. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{c.layer_jacobian.cases}} random layers in dimensions 1 to 4, (4.1) matched central differences to a relative {{c.layer_jacobian.fd_rel_err|e1}}, and the eigenvalue bounds had {{c.layer_jacobian.bound_violations}} violations.
:::

## 4.2 Composite tangents

::: {custom-style="Statement"}
**Theorem 4.2** (floor, ceiling and volume). Use identity maps. Along a realised path, with the noise fixed, let $K=J_1J_2\cdots J_T$ be the Jacobian of $z_0$ with respect to $z_T$.
:::

::: {custom-style="Statement"}
\(i) $\prod_t\lambda_{\text{min}}(J_t)\le\sigma_{\text{min}}(K)\le\sigma_{\text{max}}(K)\le\prod_t\lambda_{\text{max}}(J_t)$.
:::

::: {custom-style="Statement"}
\(ii) $\sigma_{\text{min}}(K)\ge\omega_\star$, which is $s_0/s_T$ when $\eta=0$. If $u$ is orthogonal to the affine span of the records, then $Ku=\omega_\star u$, so the floor is attained whenever the records do not affinely span $ℝ^D$.
:::

::: {custom-style="Statement"}
\(iii) With $c_{t,k}$ the eigenvalues of $C$ at layer $t$,
:::

::: {custom-style="Statement Equation"}
$\log|\text{det}\,K|=\sum_{t=1}^{T}\sum_{k=1}^{D}\log\left(1-\lambda_t+\lambda_tc_{t,k}/s_t^2\right)\ge D\log\omega_\star$ (4.2)
:::

::: {custom-style="Statement Tag"}
New in Part III; V2 Section 13 gives the bound for one layer.
:::

*Proof.* The noise enters additively, so the Jacobian of a noisy layer is (4.1) evaluated on the noisy path. (i) Each $J_t$ is symmetric positive semidefinite, so its singular values are its eigenvalues, and $\sigma_{\text{min}}(AB)\ge\sigma_{\text{min}}(A)\sigma_{\text{min}}(B)$ and $\sigma_{\text{max}}(AB)\le\sigma_{\text{max}}(A)\sigma_{\text{max}}(B)$ [13]. (ii) $\lambda_{\text{min}}(J_t)\ge1-\lambda_t$ and $\prod_t(1-\lambda_t)=\omega_\star$; Corollary 3.3 gives the deterministic value. For $u$ orthogonal to the affine span, $J_tu=(1-\lambda_t)u$ at every layer by Proposition 4.1. (iii) The determinant is multiplicative, and every factor is at least $1-\lambda_t$. $\blacksquare$

In scaled coordinates a deterministic stack can therefore contract a tangent by at most the schedule ratio $s_0/s_T$. The reads only ever push singular values up from that floor, and they push hardest near branch decisions (Figure 3a).

::: {custom-style="Check"}
*Numerical check.* In {{c.composite.cases}} random stacks in dimensions 2 to 4 with 6 to 20 layers, half of them with a clean top, (i) had {{c.composite.floor_violations}} and {{c.composite.ceiling_violations}} violations and (4.2) held to a relative {{c.composite.volume_err|e1}}. The deterministic floor had {{c.composite.det_floor_violations}} violations; the ratio $\sigma_{\text{min}}(K)/(s_0/s_T)$ had median {{c.composite.floor_ratio_median|f3}} and minimum {{c.composite.floor_ratio_min|f6}}, attained in the {{c.composite.complement_cases}} stacks whose records did not affinely span the space, where $Ku=\omega_\star u$ held to {{c.composite.complement_err|e1}}. In {{c.composite.noisy_cases}} noisy stacks the floor $\omega_\star$ had {{c.composite.eta_floor_violations}} violations. Central differences matched $K$ to a relative {{c.composite.fd_err|e1}}.
:::

::: {custom-style="Statement"}
**Corollary 4.3** (contraction beyond the schedule happens at the top). Let $\eta=0$ and $s_0=0$, and let $c_{1,1}\ge\cdots\ge c_{1,D}$ be the eigenvalues of the top posterior covariance $C(z_1,s_1)$. Then for every $k$
:::

::: {custom-style="Statement Equation"}
$\frac{c_{1,k}}{s_1s_T}\le\sigma_k(K)\le\frac{c_{1,k}}{s_1s_T}\,X,\qquad X=\prod_{t=2}^{T}\frac{\lambda_{\text{max}}(J_t)}{1-\lambda_t}\ge1$ (4.3)
:::

::: {custom-style="Statement"}
and the rank of $K$ is the rank of $C(z_1,s_1)$, the affine dimension of the records when every weight is positive. The expansion excess $X$ equals one only if every posterior covariance below the top vanishes.
:::

::: {custom-style="Statement Tag"}
New in Part III; the rank statement is Part I Proposition 4.6.
:::

*Proof.* At a clean top $J_1=C(z_1,s_1)/s_1^2$, whose $k$-th singular value is $c_{1,k}/s_1^2$. For $B=J_2\cdots J_T$, $\sigma_k(J_1)\sigma_{\text{min}}(B)\le\sigma_k(J_1B)\le\sigma_k(J_1)\Vert B\Vert$ [13]. Theorem 4.2 gives $\sigma_{\text{min}}(B)\ge\prod_{t\ge2}(1-\lambda_t)=s_1/s_T$ and $\Vert B\Vert\le\prod_{t\ge2}\lambda_{\text{max}}(J_t)=(s_1/s_T)X$. $B$ is invertible, so $\text{rank}\,K=\text{rank}\,J_1$. $\blacksquare$

Part I ran 1,000 tokens through a sixteen-layer cosine stack with a clean top, starting from layer 15, and found median singular values 0.0353 and $6.4\times10^{-4}$ for the composite [10, Section 4.4]. For that schedule $s_1s_{15}=\tan(\pi/32)\tan(15\pi/32)=1$, so (4.3) says that each singular value is the corresponding eigenvalue of the top posterior covariance, multiplied by a factor between 1 and $X$. Replaying the same archive and tokens confirms it (Figure 3b). The contraction Part I observed is the concentration of the top read, inflated by the expansion of the layers below.

::: {custom-style="Check"}
*Numerical check.* In the {{d.clean_cases}} clean-top stacks of the previous check, (4.3) had {{c.composite.clean_lower_violations}} lower and {{c.composite.clean_upper_violations}} upper violations. On Part I's experiment, replayed from its random stream, both sides held for {{x.part_one.lower_holds}} of {{x.part_one.tokens}} tokens. The median singular values were {{x.part_one.median_sv.0|f4}} and {{x.part_one.median_sv.1|e2}}, the median top eigenvalues {{x.part_one.median_c1.0|e2}} and {{x.part_one.median_c1.1|e2}}, and the median ratios $\sigma_k/c_{1,k}$ were {{x.part_one.median_ratio.0|f2}} and {{x.part_one.median_ratio.1|f2}}. The excess $X$ had median {{x.part_one.excess_median|f1}} and 90th percentile {{x.part_one.excess_q90|f1}}.
:::

![**Figure 3.** (a) Largest and smallest singular values of the composite $K_{T\to t}$ for 40 tokens climbing a sixteen-layer geometric stack from $s_T=20$ to $s_0=0.05$ over three clusters of ten records in $ℝ^2$ (recomputed with a fixed seed). No singular value falls below the floor $s_t/s_T$ (Theorem 4.2). (b) The experiment of Part I, replayed: singular values of the composite against the eigenvalues of the top posterior covariance. Every point lies above the bound of Corollary 4.3, here $\sigma_k=c_{1,k}$ because $s_1s_{15}=1$. (c) The largest eigenvalue of $C_t/s_t^2$ along 300 of those paths. A layer expands where the curve exceeds one (Proposition 4.1). Over all 1,000 tokens, no layer above layer {{x.part_one.first_expanding_layer}} expanded; from there to the top, {{d.expand_min|pct0}} to {{d.expand_max|pct0}} of the tokens expanded at each layer, and {{x.part_one.expanding_any|pct0}} expanded at some layer.](fig/tangent.png){width=100%}

## 4.3 Fixed points, Morse index and bifurcations

At a fixed scale, the fixed points of the read are the stationary points of $E_s$. Their type, and the scales at which they appear and disappear, are what a mode-based barcode would record.

::: {custom-style="Statement"}
**Proposition 4.4** (fixed points, Morse index and bifurcations). Use identity maps and fix $s>0$.
:::

::: {custom-style="Statement"}
\(i) $m(z^\star,s)=z^\star$ if and only if $\nabla E_s(z^\star)=0$. Every layer at scale $s$ with $\lambda>0$ then fixes $z^\star$, and the number of its expanding directions equals the Morse index of $E_s$ at $z^\star$. Nondegenerate minima of $E_s$, the modes of $p_s$, attract.
:::

::: {custom-style="Statement"}
\(ii) (Morse balance) If every stationary point of $E_s$ is nondegenerate, then $\sum_k(-1)^kN_k=1$, where $N_k$ is the number of stationary points of index $k$.
:::

::: {custom-style="Statement"}
\(iii) (bifurcations) If 1 is not an eigenvalue of $C(z^\star,\varsigma)/\varsigma^2$ at a stationary point $z^\star$ for the scale $\varsigma$, then for $s$ near $\varsigma$ there is exactly one stationary point near $z^\star$; it depends smoothly on $s$ and keeps its index. Stationary points can therefore appear, disappear or change type only at scales where a stationary point has a tangent eigenvalue $c/s^2=1$, the expansion threshold of Proposition 4.1.
:::

::: {custom-style="Statement"}
\(iv) For two records of equal weight at distance $d$, the midpoint is a stationary point with $C/s^2=d^2/4s^2$, and the pitchfork occurs at $s=d/2$. For three equal records at the vertices of an equilateral triangle with side $\ell$, the centroid has $C=(\ell^2/6)\,I$ at every scale, so it changes type at $s=\ell/\sqrt6$.
:::

::: {custom-style="Statement Tag"}
\(i) Part II Corollary 5.5, with Proposition 4.1; (ii) classical, the Poincaré–Hopf theorem [16]; (iii) classical, the implicit function theorem, with the identification of the threshold New in Part III; (iv) the pitchfork V2 Proposition 14.2, the centroid New in Part III.
:::

*Proof.* (i) $\nabla E_s=z-m$. At $z^\star$, the eigenvalues of $J$ are $1-\lambda+\lambda c/s^2$, and the Hessian $I-C/s^2$ has a negative eigenvalue exactly when $c>s^2$. At a nondegenerate minimum every $c<s^2$, so $J$ has spectral radius below one. (ii) On a large ball, $\nabla E_s=z-m$ points outward because $m$ stays in the hull of the records. The Poincaré–Hopf theorem gives $\sum\text{sign}\,\text{det}\,\nabla^2E_s=\chi(\text{ball})=1$, and the sign is $(-1)^k$ at a point of index $k$ [16]. (iii) Apply the implicit function theorem to $F(z,s)=m(z,s)-z$, whose $z$-derivative $C/s^2-I$ is invertible at $(z^\star,\varsigma)$; the eigenvalues vary continuously and cannot cross one along the branch. (iv) At the midpoint the two weights are equal, so $C=(d/2)^2$ along the line of the records and zero across it. At the centroid the three weights are equal, and the second moment of the vertices about the centroid is $(r^2/2)I$, with circumradius $r=\ell/\sqrt3$. $\blacksquare$

::: {custom-style="Statement"}
**Example 4.5** (pitchfork and fold). For records at $\pm1$ with equal weights, there are three stationary points for $s<1$ and one for $s>1$. With weights in the ratio 7 to 3, the symmetry breaks and the pitchfork becomes a fold: the lighter record's mode and the saddle between the records meet and vanish together (Figure 4a).
:::

::: {custom-style="Check"}
*Numerical check.* In {{c.morse.archives}} random archives in $ℝ^2$, Newton's method from 285 starts found {{c.morse.stationary_points}} stationary points: {{c.morse.energy_minima}} minima, {{c.morse.saddles}} saddles and {{c.morse.energy_maxima}} maxima of $E_s$. The number of expanding directions equalled the Morse index of a finite-difference Hessian of $\log p_s$ at all {{c.morse.agree}}, and the Morse balance held in {{c.morse.balanced_archives}} of {{c.morse.archives}} archives. For records at $\pm1$, the counts at $s=0.8$, 0.9 and 0.99 were 3 and at 1.01, 1.1 and 1.3 were 1, and the midpoint tangent at $s=1$ was {{c.bifurcation.equal_tangent_at_midpoint|f4}}. With weights 7 to 3 the fold lay at $s={{c.bifurcation.unequal_fold_scale|f4}}$, where the two merging points had tangent eigenvalues {{c.bifurcation.unequal_tangent_eigenvalues.1|f4}} and {{c.bifurcation.unequal_tangent_eigenvalues.2|f4}}.
:::

## 4.4 Exact and effective rank

Part I showed that the exact barcode of a Gaussian tangent diagram is usually full, while sensitivity contracts by orders of magnitude [10, Proposition 4.6]. It is tempting to repair this by computing barcodes from thresholded ranks. That repair fails.

::: {custom-style="Statement"}
**Proposition 4.6** (thresholded ranks are not rank invariants). For a chain of linear maps and a tolerance $\tau>0$, let $r_\tau(a,b)$ be the number of singular values of the composite from layer $a$ to layer $b$ that exceed $\tau$.
:::

::: {custom-style="Statement"}
\(i) $r_\tau$ can increase under composition. For $J_1=\text{diag}(10,0.05)$, $J_2=\text{diag}(0.05,10)$ and $\tau=0.1$, $r_\tau(2,1)=r_\tau(1,0)=1$ but $r_\tau(2,0)=2$.
:::

::: {custom-style="Statement"}
\(ii) Even for contractions, $r_\tau$ violates Sylvester's inequality $r(a,c)\ge r(a,b)+r(b,c)-\text{dim}\,V_b$. For $J_1=J_2=0.7\,I_2$ and $\tau=0.6$, $r_\tau(2,1)=r_\tau(1,0)=2$ but $r_\tau(2,0)=0$.
:::

::: {custom-style="Statement"}
\(iii) In both examples, formula (4.1) of Part I returns negative multiplicities: $m[2,1]=m[1,0]=-1$ in (i) and $m[1,1]=-2$ in (ii). Exact ranks never do (Part I, Theorem 4.2).
:::

::: {custom-style="Statement Tag"}
New in Part III; exact ranks Part I Theorem 4.2 [10].
:::

*Proof.* (i) $J_2J_1=0.5\,I$. (ii) $J_2J_1=0.49\,I$. (iii) Substitute into Part I (4.1): in (i), $m[2,1]=r(2,1)-r(2,0)=-1$ and $m[1,0]=r(1,0)-r(2,0)=-1$; in (ii), $m[1,1]=2-r(2,1)-r(1,0)+r(2,0)=-2$. For exact ranks, every chain decomposes into intervals, and the multiplicities are counts. $\blacksquare$

A thresholded "effective barcode" is therefore not a barcode. The defensible report has two parts: the exact barcode, which is a complete invariant and usually trivial, and the singular-value profile of the composites, which is stable under perturbation (Part I, Proposition 4.6(iv)) and is bounded by Theorem 4.2 and Corollary 4.3.

::: {custom-style="Check"}
*Numerical check.* Formula (4.1) of Part I returned the multiplicities stated in (iii). Among {{c.effective_rank.random_chains}} random chains of three maps on $ℝ^3$ with log-normal singular values, half of the maps losing rank exactly, {{c.effective_rank.chains_with_negative_multiplicity}} had a negative multiplicity at $\tau=1$, and none with exact ranks. Along the {{x.part_one.tokens}} realised sixteen-layer tangent diagrams of Part I's experiment, thresholded ranks gave negative multiplicities for {{d.neg_1e2}} tokens at $\tau=10^{-2}$ and {{d.neg_1e3}} at $\tau=10^{-3}$. At a relative tolerance of $10^{-14}$, {{x.part_one.exact_negative_tokens}} tokens still did; these are the numerically singular tokens of Part I, for which even the exact rank is, in floating point, a thresholded one.
:::
