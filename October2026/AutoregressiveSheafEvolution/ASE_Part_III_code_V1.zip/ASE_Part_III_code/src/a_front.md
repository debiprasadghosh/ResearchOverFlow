---
title: "The Vertical Stack"
subtitle: "Layers of Autoregressive Sheaf Evolution. Part III: the token recurrence, tangent dynamics and persistence across layers"
author:
  - "Debi Prasad Ghosh"
  - "Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India"
date: "Defensible Intelligence series · Autoregressive Sheaf Evolution, Part III · 18 October 2026 · “Respect science. Import emotion.”"
abstract: |
  {{file:src/abstract.md}}
---

# 1 Introduction

Autoregressive Diffusion Evolution (ADE) proposes designs by running tokens down a denoising stack whose layers read an archive of evaluated designs [7, 8]. Autoregressive Sheaf Evolution (ASE) generalises each read to an observation star with edge maps and scale-dependent covers [9]. Part I separated the two axes of the stack: horizontally topological within a layer, vertically algebraic across layers [10]. Part II worked out one layer. Its read is a harmonic extension, and every deterministic ADE layer is a majorise–minimise step on the soft energy at its own scale [11]. This paper, Part III of the book, stacks the layers. It covers chapters 7 to 9 of the book plan: the token recurrence, tangent dynamics, and persistence across layers [9, Section 21].

A stack does three things. It mixes each token with the reads it collects, in proportions fixed by the schedule alone. It transports a population of tokens from a coarse density to a fine one. And it moves tangent vectors, contracting most directions and expanding a few. Each of these has an exact description, and each description says where in the schedule the layers matter. In the scaled coordinates of V2, a stack with identity maps is the recurrence

::: {custom-style="Equation"}
$z_{t-1}=(1-\lambda_t)\,z_t+\lambda_t\,m_t(z_t)+\gamma_t\,\xi_t,\qquad t=T,\ldots,1$ (1.1)
:::

with $m_t(z)=\sum_i\alpha_i(z,s_t)\,y_i$ the Gaussian read at scale $s_t$, independent standard normal increments $\xi_t$, and coefficients $\lambda_t,\gamma_t$ that depend only on the scales $s_0<s_1<\cdots<s_T$ and a noise parameter $\eta$ (Definition 2.1). The three descriptions are the following. Unrolling (1.1) separates the output into a starting term, a convex combination of reads, and a noise term with a fixed budget (Section 3.1). In precision coordinates $\tau=1/s$, a deterministic layer is a forward Euler step of the probability-flow equation of the archive density (Section 3.2). And the Jacobian of a layer is one minus a multiple of the Hessian of its energy, so that tangents expand exactly along directions of negative curvature (Section 4).

![**Figure 1.** (a) Weights of the reads in the output of an eight-layer geometric stack from $s_8=4$ to $s_0=0.1$ (Theorem 3.1). Noise moves weight towards the top layers and shrinks the weight $\omega_\star$ of the starting state. (b) The noise budget of the same stack (Theorem 3.2). The shares of the top variance $s_0^2$ carried by the starting state and by the explicit noise always sum to one. (c) A deterministic layer is a forward Euler step in the precision $\tau=1/s$ (Proposition 3.4). The shaded area is $\sum_t\Delta\tau_t\,m_t$, and the stack output is $z_0=s_0(z_T/s_T+\sum_t\Delta\tau_t\,m_t)$; the black curve is the read along the exact flow, recomputed for two records at $\pm1$ with weights 0.45 and 0.55.](fig/separation.png){width=100%}

## 1.1 Contributions

- **The token recurrence (Section 3).** We prove a noise budget: the explicit noise reaching the output is exactly $N(0,(s_0^2-\omega_\star^2s_T^2)I)$ (Theorem 3.2). Hence the starting state has weight at most $s_0/s_T$, a one-record stack is exactly calibrated for every schedule and every $\eta$, and a clean top closes both channels. In precision coordinates the separation identity is a Riemann sum (Proposition 3.4). The deterministic stack discretises the probability-flow equation $\text{d}z/\text{d}s=-s\nabla\log p_s$, which carries $p_{s_T}$ to $p_{s_0}$, with local error caused only by the motion of the read (Theorem 3.5). With a clean top, the continuum stack re-selects archived records with probabilities equal to their prior weights (Proposition 3.6), and novelty has exactly four channels (Proposition 3.7).
- **Tangent dynamics (Section 4).** A layer is a gradient step, and it expands exactly along directions of negative curvature of its energy (Proposition 4.1). Every singular value of a composite lies between products of layer eigenvalues. The deterministic floor $s_0/s_T$ is attained in directions the archive does not span (Theorem 4.2). With a clean top, the $k$-th singular value is pinned to the $k$-th eigenvalue of the top posterior covariance, up to the factor $1/(s_1s_T)$ and an expansion excess (Corollary 4.3). This explains the contraction reported in Part I. Stationary points can change number or type only where a tangent eigenvalue equals one, and they obey a Morse balance (Proposition 4.4). Thresholded ranks are not rank invariants and can give negative barcode multiplicities (Proposition 4.6).
- **Persistence across layers (Section 5).** Component barcodes are filtrations. Mode counts are monotone in one dimension, but not in two: for three equal records a fourth mode is born at exactly $s=\text{side}/\sqrt6$ (Example 5.3). Token paths curve only where the posterior is spread (Theorem 5.4). This gives an error model whose optimal layer density is proportional to $\sqrt{g}$, and a layer-halving bound (Proposition 5.5). An exploratory pilot refutes hypothesis C3 in all {{d.bar_total}} of its comparisons, and the error model explains why (Section 5.3).
- **Evidence.** There are {{d.n_checks}} numerical checks, {{d.n_main}} from a main script and {{d.n_extra}} from a supplementary script, besides the pilot (Table 5). An immutable C# kernel agrees with an independent NumPy implementation on every output line (Appendix A).

## 1.2 Scope and status of statements

The exact statements concern identity edge maps, which give the ADE geometry. Most of them carry over unchanged to orthogonal transports, which replace each record by its transported value. General maps change the Jacobian of a read (Part II, Proposition 5.4) and the hull in which reads lie (Part II, Proposition 3.5). Where a statement needs identity maps, it says so. Prior weights are fixed. The paper proves statements about sampling and sensitivity of the stack; it makes no claim about search performance. Section 5.3 reports an exploratory pilot related to hypothesis C3 of V2 [9, Section 18]. It is not the confirmatory test that V2 specifies, and its outcome is labelled as exploratory throughout.

Every statement in a shaded box ends with a provenance tag. *Classical* marks a known result restated in ASE notation. *V2* marks a statement of the conversion proposal [9], sometimes with a new proof. *Mathematics book* marks a result retained from [8], with its number there. *Part I* and *Part II* refer to [10] and [11]. *New in Part III* marks a statement proved here for the first time in this programme; each comes with a proof and a numerical check. All spaces are finite-dimensional and real.

## 1.3 Conventions and notation

Layers are numbered from the bottom, $t=T$, to the top, $t=1$; the token enters layer $t$ as $z_t$ and leaves it as $z_{t-1}$, so $z_0$ is the output. The scale of layer $t$ is $s_t$. "Coarse" means large $s$ and "fine" means small $s$.

Table: **Table 1.** Notation used throughout Part III.

| Symbol | Meaning |
|:--------------------------|:--------------------------------------------------|
| $y_i,\ w_i,\ \beta_i$ | records, prior weights and normalised weights $\beta_i=w_i/\sum_jw_j$ |
| $s_0<s_1<\cdots<s_T$ | scales; a clean top has $s_0=0$ |
| $\eta,\ \lambda_t,\ \gamma_t$ | noise parameter, interpolation weight and scaled noise deviation (2.1) |
| $\alpha_i(z,s),\ m(z,s),\ C(z,s)$ | posterior weights, read and posterior covariance at scale $s$ |
| $p_s$ | archive density $\sum_i\beta_iN(y_i,s^2I)$ |
| $E_s$ | layer energy (2.3) |
| $\pi_t,\ \omega_t,\ \omega_\star$ | separation weights of Theorem 3.1 |
| $\tau=1/s,\ w=z/s$ | precision and precision-scaled state (Proposition 3.4) |
| $J_t,\ K$ | layer Jacobian and composite tangent $K=J_1\cdots J_T$ |
| $c_{t,k}$ | eigenvalues of $C$ at layer $t$, in decreasing order |
| $M_3$ | posterior third moment (5.1) |
| $R$ | diameter of the records |
