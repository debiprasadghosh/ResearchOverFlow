# Autoregressive Sheaf Evolution, Part III: code and results

Companion files for the paper "The Vertical Stack" (18 October 2026).
Every number in the paper is read from the JSON files in this folder when the document is built.

| File | Purpose |
|------|---------|
| `p3_core.py` | Shared primitives: schedule coefficients, separation weights, Gaussian reads, the stack recurrence, layer Jacobians, mode finding, barcode multiplicities |
| `p3_checks.py` | Eighteen numerical checks (seed 20261022); writes `p3_checks.json` |
| `p3_extras.py` | Three supplementary checks: the curvature bound, the Morse balance and fold of the equilateral triangle, and the replay of Part I's tangent experiment; writes `p3_extras.json` |
| `part_one/p1_checks.py` | Part I's main script, imported by `p3_extras.py` to replay its random stream exactly |
| `p3_explore.py` | Exploratory pilot of hypothesis C3 (seed 20261024); writes `p3_explore.json` |
| `pilot_summary.py` | Derived pilot quantities and the rows of Tables 3 and 4 |
| `cs/` | .NET 8 reference kernel (`VerticalStack.cs`) and validation program (`Program.cs`); `cs_out.txt` is its output |
| `cs_validate.py` | Recomputes every line of `cs/cs_out.txt` with NumPy; writes `cs_validate.json` |
| `fig_p3.py`, `fig_schedules.py` | Draw Figures 1 to 5 into `fig/` |
| `src/*.md`, `render.py` | Paper source; `render.py` fills every number from the JSON files and writes `paper.md` |
| `make_ref.py`, `ref.docx`, `postprocess.py` | Word styles, and post-processing that centres numbered equations and puts XML elements in schema order |
| `build.sh` | Render, convert with pandoc, post-process and validate |

Order of execution: `p3_checks.py`, `p3_extras.py`, `p3_explore.py` (about 20 minutes on one core); build and run the
C# project (`dotnet run -c Release` in `cs/`) and save its output as `cs/cs_out.txt`; `cs_validate.py`; `fig_p3.py`;
`render.py`; pandoc with `--reference-doc=ref.docx`; `postprocess.py`.

The pilot is exploratory. Its metrics and decision rule were fixed in `p3_explore.py` before the first run; after a
trial on one archive, the curvature schedule's flow-based estimate was replaced by the archive-only estimate and the
mass-weighted barcode schedule was added. All schedules that were run are reported.

Versions used: Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1, Matplotlib 3.11.2, .NET SDK 8.0.131, pandoc 3.1.3.
