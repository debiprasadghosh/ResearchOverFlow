# Primary sources added in Version 4

Literature checked on 1 November 2026. All four additions are primary research
papers. Their findings motivate interpretations and tests rather than establish
that a biological or learned system satisfies an ADC certificate.

| Source | Verified metadata and use | Primary record |
|---|---|---|
| He et al. (2026) | Human intracranial compositional inference; hippocampal ripples, replay and medial prefrontal representations. Nature Neuroscience 29, 1711–1721. | https://pubmed.ncbi.nlm.nih.gov/42092183/ and https://doi.org/10.1038/s41593-026-02291-3 |
| Chakravarthula et al. (2026) | Network geometry and transformations of human task representations; fMRI and activity-flow modeling. Published 22 October 2026. | https://www.nature.com/articles/s41593-026-02486-8 |
| Thompson et al. (2026) | Replay of procedural memory is independent of the hippocampus. Nature Neuroscience 29, 2237–2248. | https://www.nature.com/articles/s41593-026-02362-5 |
| Yin et al. (2026) | VerifierBench; generated executable verifiers can falsely reject valid alternatives and share assumptions with their self-tests. arXiv v1, 19 October 2026. | https://arxiv.org/abs/2610.28679 |

The new text distinguishes association, lesion evidence, normative interpretation
and formal mathematical premises. Bibliographic author lists and titles follow the
primary records. The He et al. abstract and metadata were read through PubMed
because the Nature page redirected to an inaccessible authorization endpoint.

The previously cited Rosset et al. and CLIFT arXiv records were also checked:

- https://arxiv.org/abs/2604.06240
- https://arxiv.org/abs/2610.06829

No learned-verifier calibration claim is imported as a universal causal or latent
execution guarantee. No new empirical number is inferred from these sources.
