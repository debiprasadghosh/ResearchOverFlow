"""Small exact examples for Version 4. No inherited census or model is run.

Uses only Python's standard library. Output is deterministic and timestamp-free.
The independent vertex calculation enumerates active constraints rather than
using the greedy interval routine. Matrix calculations use exact fractions.
"""
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
checks = []

def check(name, condition):
    checks.append({"name": name, "passed": bool(condition)})
    if not condition:
        raise AssertionError(name)

def dot(a, b):
    return sum((x*y for x, y in zip(a, b)), F(0))

def trans(a):
    return [list(c) for c in zip(*a)]

def mul(a, b):
    return [[dot(row, col) for col in trans(b)] for row in a]

def mv(a, x):
    return [dot(row, x) for row in a]

def inv(a):
    n = len(a)
    v = [[F(x) for x in row] + [F(i == j) for j in range(n)] for i, row in enumerate(a)]
    for j in range(n):
        k = next((i for i in range(j, n) if v[i][j]), None)
        if k is None:
            raise ValueError("singular")
        v[j], v[k] = v[k], v[j]
        scale = v[j][j]
        v[j] = [x/scale for x in v[j]]
        for i in range(n):
            if i != j:
                scale = v[i][j]
                v[i] = [x-scale*y for x, y in zip(v[i], v[j])]
    return [row[n:] for row in v]

def greedy(p, capacities, budget):
    allocation = [F(0)] * len(p)
    for i in sorted(range(len(p)), key=lambda i: (-p[i], i)):
        take = min(capacities[i], max(F(0), budget))
        allocation[i] = take
        budget -= take
    return dot(p, allocation)

def vertex_max(p, capacities, budget):
    """Independent LP optimum from all active-constraint intersections."""
    n = len(p)
    inequalities = []
    for i in range(n):
        row = [F(int(i == j)) for j in range(n)]
        inequalities += [(row, capacities[i]), ([-x for x in row], F(0))]
    inequalities.append(([F(1)]*n, budget))
    vals = []
    for active in combinations(inequalities, n):
        try:
            x = mv(inv([a for a, _ in active]), [b for _, b in active])
        except ValueError:
            continue
        if all(dot(a, x) <= b for a, b in inequalities):
            vals.append(dot(p, x))
    return max(vals)

# Table-average counterexample, represented exactly.
p = [F(1)] + [F(0)]*7
t = [F(2, 25)] + [F(0)]*7
mae = sum(t)/8
error = dot(p, t)
check("eight-cell MAE is 1/100", mae == F(1, 100))
check("query error is 2/25", error == F(2, 25))
check("query error exceeds MAE", error > mae)

# Sharp budget interval, and independent active-set confirmation.
interval_cases = [
    ([F(3,4), F(1,4)], [F(1,2), F(1,2)], F(1,4)),
    ([F(1,2), F(1,3), F(1,6)], [F(9,10), F(1,5), F(1,2)], F(3,5)),
    ([F(1,3)]*3, [F(0), F(1), F(1,2)], F(1)),
    ([F(1), F(0)], [F(1), F(0)], F(0)),
]
intervals = []
for k, (p, th, budget) in enumerate(interval_cases):
    upper_caps = [1-x for x in th]
    low = greedy(p, th, budget)
    high = greedy(p, upper_caps, budget)
    check(f"case {k}: greedy lower equals vertex optimum", low == vertex_max(p, th, budget))
    check(f"case {k}: greedy upper equals vertex optimum", high == vertex_max(p, upper_caps, budget))
    intervals.append([dot(p, th)-low, dot(p, th)+high])
check("reported sharp interval", intervals[0] == [F(5,16), F(11,16)])

# All 2,025 cases on a small rational grid check Theorem 8.9.
grid = [F(i,4) for i in range(5)]
tables = list(product([F(0), F(1,2), F(1)], repeat=2))
bound_count = 0
for a, ah, t, th in product(grid, grid, tables, tables):
    p, ph = [a, 1-a], [ah, 1-ah]
    alpha = sum(abs(x-y) for x,y in zip(p, ph))/2
    beta = sum(abs(x-y) for x,y in zip(t, th))/2
    rho = max(th)-min(th)
    bound = min(F(1), min(F(1), 2*max(p)*beta) + rho*min(2*alpha, F(2))/2)
    if abs(dot(p,t)-dot(ph,th)) > bound:
        raise AssertionError("sensitivity bound grid")
    bound_count += 1
check("sensitivity bound on 2025 rational cases", bound_count == 2025)

# Exact task observability and its best constant.
B = [[F(-1),F(1),F(0)], [F(0),F(-1),F(1)], [F(1),F(0),F(-1)]]
C = [F(1),F(0),F(0)]
Q = B + [C]
H = [F(0),F(0),F(1)]
A = mul(trans(Q), Q)
A_expected = [[F(3),F(-1),F(-1)],[F(-1),F(2),F(-1)],[F(-1),F(-1),F(2)]]
Ainv = inv(A)
check("anchored Gram matrix", A == A_expected)
check("Gram inverse identity", mul(A,Ainv) == [[F(i==j) for j in range(3)] for i in range(3)])
gamma2 = dot(H, mv(Ainv, H))
check("best squared task constant is 5/3", gamma2 == F(5,3))
sharp_v = mv(Ainv, H)
check("best constant has an exact witness", dot(H,sharp_v)**2 == gamma2*dot(mv(Q,sharp_v),mv(Q,sharp_v)))
ones = [F(1)]*3
check("shared wrong section is audit invisible", mv(B,ones) == [F(0)]*3)
check("shared wrong section changes task", dot(H,ones) == 1)
check("anchor sees the shared direction", dot(C,ones) == 1)

# Independent ordinary and anchored least-norm repair calculations.
x = [F(2), F(0), F(0)]
free = [sum(x)/3]*3
check("free cycle repair", free == [F(2,3)]*3 and mv(B,free) == [F(0)]*3)
BU = [row[1:] for row in B]
bu_dagger = mul(inv(mul(trans(BU),BU)),trans(BU))
delta = [-y for y in mv(bu_dagger,mv(B,x))]
anchored = [x[0]]+[x[i+1]+delta[i] for i in range(2)]
check("anchored cycle repair", anchored == [F(2)]*3)
check("repair preserves trusted coordinate", anchored[0] == x[0])
check("anchored residual zero", mv(B,anchored) == [F(0)]*3)
# Solve the first two independent constraints directly, without the pseudoinverse.
independent_delta = mv(inv(BU[:2]),[-r for r in mv(B,x)[:2]])
check("independent repair solve agrees", delta == independent_delta)

# One-dimensional coverage bound attained by distance to the finite probe set.
probes = [F(0),F(1,2),F(1)]
def defect(z): return min(abs(z-y) for y in probes)
check("probe defects vanish", all(defect(z)==0 for z in probes))
check("coverage-plus-regularity bound attained", defect(F(1,4)) == F(1,4))

# Continuation packing on the inherited bit-machine specification.
states = list(product([0,1],repeat=3))
def operation(s,o):
    a,b,c = s
    return [(1-a,b,c),(b,a,c),(a,b,1-c)][o]
def observation(s,word):
    for o in word: s = operation(s,o)
    return s[0]
def distance(s,t,h):
    return max(abs(observation(s,w)-observation(t,w)) for n in range(h+1) for w in product(range(3),repeat=n))
packing = max(len(subset) for n in range(9) for subset in combinations(states,n)
              if all(distance(s,t,1)>F(1,2) for s,t in combinations(subset,2)))
check("continuation packing has size four", packing == 4)
check("packing requires at least two bits", (packing-1).bit_length() == 2)
check("future distance ignores irrelevant third bit", all(distance((a,b,0),(a,b,1),1)==0 for a,b in product([0,1],repeat=2)))
check("transition contracts horizon distance", all(distance(operation(s,o),operation(t,o),1)<=distance(s,t,2)
      for s,t,o in product(states,states,range(3))))

budgets = {"a":F(1,100),"b":F(1,50)}
lookups = ["a","a","b","a","b"]
check("reuse charges unique admitted claims", sum(budgets[k] for k in set(lookups)) == F(3,100))

result = {
    "scope":"Exact finite examples for Version 4; no inherited census rerun or trained-model experiment.",
    "all_passed": all(c["passed"] for c in checks),
    "checks": checks,
    "results": {
        "counterexample_mae": str(mae), "counterexample_query_error":str(error),
        "sharp_budget_intervals":[[str(v) for v in q] for q in intervals],
        "sensitivity_grid_cases":bound_count, "anchor_gram_inverse":[[str(v) for v in row] for row in Ainv],
        "anchor_best_constant_squared":str(gamma2), "anchor_sharpness_witness":[str(v) for v in sharp_v],
        "free_repair":[str(v) for v in free], "anchored_repair":[str(v) for v in anchored],
        "continuation_packing":packing, "minimum_bits":(packing-1).bit_length(),
        "unique_claim_budget":"3/100",
    }
}
(ROOT/"checks_v4.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(f"{len(checks)} exact checks passed; {bound_count} sensitivity cases; no inherited census run.")
