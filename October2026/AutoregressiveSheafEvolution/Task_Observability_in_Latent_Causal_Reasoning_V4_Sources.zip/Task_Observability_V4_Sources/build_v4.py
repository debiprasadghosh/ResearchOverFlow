"""Edit the supplied Version 3 manuscript into Version 4.

Self-contained inputs: base_v3.docx, additions_v4.md, inherited_v3/cs_v3.txt.
Python dependencies: python-docx, lxml, NumPy, Matplotlib; executable: Pandoc.
Existing numbered display equations and the first three figures are preserved.
Proposition 8.7 and one Table 12 label are corrected. Figure 4 is relabelled
and its annotations repositioned; its numerical data are unchanged.
"""
from pathlib import Path
import argparse, copy, json, re, subprocess, tempfile, zipfile
from lxml import etree
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parent
NAME = "Task_Observability_in_Latent_Causal_Reasoning_V4.docx"
SOURCE = ROOT / "base_v3.docx"
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M = "http://schemas.openxmlformats.org/officeDocument/2006/math"
REL = "http://schemas.openxmlformats.org/package/2006/relationships"
NS = {"w":W,"m":M}

def norm(s):
    return s.replace("\xa0"," ").replace("’", "'")

def main(out):
    doc = Document(SOURCE)
    body = doc.element.body
    blocks = dict(re.findall(r"<!-- BLOCK (\w+) -->\s*(.*?)(?=<!-- BLOCK |\Z)", (ROOT/"additions_v4.md").read_text(), re.S))

    def find(prefix):
        matches = [p for p in doc.paragraphs if norm(p.text).startswith(prefix)]
        if len(matches) != 1:
            raise ValueError((prefix,len(matches)))
        return matches[0]

    def frag(md):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td)
            (td/"fragment.md").write_text(md,encoding="utf-8")
            subprocess.run(["pandoc",str(td/"fragment.md"),"-f","markdown+tex_math_dollars-auto_identifiers-fancy_lists", "-o",str(td/"fragment.docx"),f"--reference-doc={SOURCE}"],check=True)
            d=Document(td/"fragment.docx")
            els=[copy.deepcopy(e) for e in d.element.body if e.tag != qn("w:sectPr")]
        for e in els:
            for b in list(e.iter(qn("w:bookmarkStart")))+list(e.iter(qn("w:bookmarkEnd"))):
                b.getparent().remove(b)
        return els

    def before(anchor,els):
        el=anchor._p if hasattr(anchor,"_p") else anchor
        for e in els: el.addprevious(e)

    def replace(prefix,md):
        p=find(prefix)
        before(p,frag(md))
        p._p.getparent().remove(p._p)

    def plain(prefix,text):
        p=find(prefix)
        r=p.runs[0] if p.runs else p.add_run()
        for child in list(p._p):
            if child.tag != qn("w:pPr"): p._p.remove(child)
        p.add_run(text)
        return p

    # The supplied document is the authority for author details and design.
    plain("Operation Certificates for Latent Causal Reasoning","Task Observability in Latent Causal Reasoning")
    plain("Learning from teacher traces through compatible representations", "Operation certificates with finite precision and anchored sheaf repair")
    plain("Version 3, 31 October 2026", "Version 4, 1 November 2026")
    replace("Long reasoning traces from reinforcement-trained teachers", """Long teacher traces can train Autoregressive Do Calculus through verified operations, but answer accuracy, horizontal compatibility and realized latent execution require different evidence. This revision establishes a task-observability criterion: compatibility and independently trusted anchors control a linear task error exactly when their common null directions cannot change that task. The sharp constant is a pseudoinverse norm. A constrained repair formula preserves trusted coordinates. We also distinguish mean decoding error from uniform entrywise error, derive a task-sensitive answer bound and a sharp interval under an $L^1$ budget, extend exact continuation memory to finite-horizon packing bounds, and state when finite execution probes imply a uniform defect. Repeated adaptive reuse of a scoped certificate spends the risk of its distinct source claims once. The inherited census retains all 1,024 fixed-order five-vertex DAGs and 2,211,840 operation applications per parameter regime. Its value coincidences and exact graph licences remain unchanged. Under a uniform entrywise radius of 0.01, 45.6% of numerically wrong finer-grid adjustment answers lie inside the honest-table enclosure; this is not implied by D2's mean-error target. New exact examples check the added formulas without rerunning the inherited census. Recent replay and cortical-representation findings constrain a functional neuroscience interpretation; they do not establish neural proof checking. Learned-agent gains, transfer benefits and biological mappings remain explicit, untested hypotheses.""")
    plain("Keywords:","Keywords: causal reasoning; task observability; operation certificates; finite-precision memory; sheaf compatibility; anchored repair; adaptive verification")
    replace("The paper develops the verification layer", "The paper develops the verification layer of a teacher-to-latent pipeline. Its contribution is a set of scoped contracts connecting licensed operations, decoded execution, task-sensitive precision, retained future computations and horizontal audits. The mathematical ingredients include established composition, optimal recovery, finite-state minimization, linear observability and packing arguments; they are specialized and proved here. The revision does not claim the underlying linear algebra or covering arguments as new general mathematics.")
    replace("The inherited study is exhaustive over a fixed-order graph family", "The inherited study is exhaustive over its fixed-order graph family and random over model parameters. Its supplied outputs and validation logs are retained with their original provenance. Version 4 adds new proofs and small exact-arithmetic examples, reproduced in clean processes, without rerunning the exhaustive census or compiler. No trained student or biological experiment is reported.")
    replace("Version 3 returns the new contracts", "Version 3 connected the original C# kernel to the operation, repair and interval contracts through its exhaustive census over 6,144 models. Version 4 adds Theorems 8.9, 8.14, 9.6 and 9.8, a coverage lemma and a certificate-reuse risk theorem. It corrects the distinction between D2's MAE prediction and the entrywise hypothesis used by the interval census, and makes the decoded-simplex premise in Proposition 8.7 explicit. Section 13.8 separates the new examples from the inherited computation.")
    replace("Sections 2 to 6 retain and correct", "Sections 2–6 retain the transition definitions, adjustment census and latent curriculum. Sections 7–9 develop operation semantics, decoded execution, task-sensitive precision, future memory and anchored compatibility. Section 10 studies adaptive acquisition. Sections 11–12 connect the contracts to neuroscience and an AI harness. Section 13 distinguishes inherited computations from the new exact examples; Sections 14–15 state limitations and conclusions. Appendix A gives the current reproduction contract.")

    # A probability simplex, not only normalization, is needed in the proof.
    replace("Proposition 8.7 (interval enclosure", r"""**Proposition 8.7 (interval enclosure of a decoded adjustment sum).** Suppose a checkpoint decodes $\widehat T_1\in\Delta_m$ and $\widehat T_2\in[0,1]^m$. Assume the true tables satisfy $|T_1-\widehat T_1|\leq h$ and $|T_2-\widehat T_2|\leq h$ entrywise, with $T_1\in\Delta_m$, $T_2\in[0,1]^m$ and $h\geq0$. The consistent adjustment sums form a closed interval $[\ell,u]$. Its endpoints are the optima of two linear programmes over

$$\left\{T_1:\max(0,\widehat T_1-h)\leq T_1\leq\min(1,\widehat T_1+h),\quad\mathbf1^{\mathsf T}T_1=1\right\},$$

with coefficient vectors $\max(0,\widehat T_2-h)$ and $\min(1,\widehat T_2+h)$, solved exactly by a greedy fill. With $m$ strata and range $\rho$ of $\widehat T_2$, the enclosure width obeys (15).""")
    replace("A value check made on the decoded tables", r"A value check using only this uncertainty set can refute a submitted answer $a$ only if $a\notin[\ell,u]$. A separate graph-premise check may reject a derivation whose value lies inside the interval.")
    replace("Prediction D2 asks for decoded tables within", "Prediction D2 asks for mean absolute decoding error below 0.01; it does not assert the per-context entrywise bound of Proposition 8.7. The following results distinguish those guarantees. Section 13.6 retains the interval census as a uniform-radius sensitivity calculation.")
    before(find("9 Horizontal compatibility"), frag(blocks["precision"]+"\n"+blocks["coverage"]))

    replace("A correct repair requires down-weighting the corrupted table", "In this two-table setup, selecting weights that favor the correct table requires external trust information. A failed overlap alone does not locate the faulty table; an independent value certificate can supply such information. The linear audit also omits affine normalization, which every repaired joint-table slip in this example violates. A repair must therefore state both its trust assumptions and its feasibility constraints.")
    before(find("10 Training and replay"),frag(blocks["anchors"]))

    # Keep H1-H3; add a separate current-evidence discussion and H4.
    before(find("12 An AI harness"),frag(blocks["neuroscience"]))
    replace("Corollary 12.2 (reuse on a certified subset)", r"""**Corollary 12.2 (reuse on a certified subset).** If an operation's claim holds on a model set $K$, a nonempty certified subset $K'\subseteq K$ preserves it when event meanings, query, operation and decoder semantics remain fixed. A previously attained sharp bound remains sharp if an attaining witness for each endpoint remains feasible in $K'$. If an endpoint was not attained, sharpness requires a separate argument, such as retained approximating sequences.""")
    replace("Proof. A universally valid claim on", "*Proof.* A universally valid claim holds on every subset. A surviving endpoint witness still attains the old endpoint, while subset inclusion prevents a wider range. Nonattainment is not covered by this witness argument. ∎")
    replace("Proposition 8.7 adds a separate caution", "Proposition 8.7 supplies a separate, stronger entrywise contract. At uniform radius 0.01, 45.6% of the numerically wrong finer-grid invalid-set answers lie inside the honest-table enclosure, and only 29.1% of affected queries have all such answers excluded. D2's MAE target alone does not license this enclosure. A per-context certified budget can instead use Theorem 8.9 or Proposition 8.11 where their premises apply. Graph-premise checks remain necessary even for exact value coincidences.")
    replace("All four learned-model predictions remain untested", "D1–D4 remain untested; D5 below adds a task-sensitive decoding comparison. Exact verification can label operations inside a declared domain, but it does not establish that a neural policy learns to propose them efficiently or generalizes to unseen structures.")
    before(find("13 What the added computation"),frag(blocks["harness"]))

    replace("The inherited independent validator was rerun", "Version 2 reports that its inherited independent validator reproduced all 34 summary records and passed 36 checks. Version 3 reports recompilation of the kernel and the added census in Sections 13.2–13.7. These are inherited results: Version 4 retains their supplied outputs and logs without a fresh exhaustive or compiler rerun. No teacher model was invoked in those reported studies.")
    replace("The new reference emits 16 deterministic records", "The Version 2 reference reports 16 deterministic records and 26 independent checks. Its five two-model linear programmes were compared with exact rational active-constraint enumeration; its graph primitive with direct-path d-separation on 1,586 cases. The archived report records clean-process replay. These historical claims are distinguished from the newly reproduced examples in Section 13.8. The reported spectral eigenvalue is a floating-point cross-check, not an outward-certified interval.")
    replace("For each query the honest tables", "For each query the honest tables of the smallest valid set are perturbed through the uncertainty set of Proposition 8.7, and every invalid set's exact answer is tested for membership (Table 12, Figure 4B). Mean widths stay close to 2.16h, within (15). Exact coincidences are excluded from these shares. At a uniform entrywise radius of 0.01, 45.6% of wrong answers lie inside the enclosure. Two-decimal rounding radius 0.005 leaves 32.9%, three decimals 8.9% and four decimals 2.1%. The least number of decimals excluding a wrong answer is 1 for 31,696 of 159,651 wrong answers, 2 for 75,376, 3 for 38,320, 4 for 10,913, 5 for 2,568, 6 for 590, 7 for 154 and 8 for 29; 5 need more than eight. The tenths grid needs at most seven. These numbers are inherited unchanged.")
    replace("A decoder that meets D2 therefore supports", "A decoder with this certified entrywise radius would permit the interval value check to exclude the answers outside the enclosure. Meeting D2's dataset MAE alone makes no such per-query guarantee. The graph premise rejects all graph-invalid adjustment selections, including exact numerical coincidences.")
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    for t in p._p.iter(qn("w:t")):
                        if t.text: t.text=t.text.replace("0.01 (D2)","0.01 uniform")
    before(find("14 Limitations"),frag(blocks["checks"]))

    replace("Theorem 8.1 requires uniform defects", "Theorem 8.1 requires uniform defects on relevant reachable states and fixed operation semantics. Lemma 8.12 bridges finite probes only with independently justified coverage and regularity; obtaining them in a large latent domain can be expensive. The exact quotient theorem is finite. Theorem 8.14 gives a necessary finite-horizon packing bound, not an approximate quotient construction or a neural sample-complexity result. Unbounded horizons and changing tasks require new analysis. A successful probe may expose information that the policy never uses; a failed probe need not prove its absence.")
    replace("The spectral repair theorem assumes", "The spectral and observability results assume finite-dimensional linear maps, declared inner products and compatible units. Theorem 9.6 depends on independently correct anchors and a correct task readout; it cannot establish them from agreement. Theorem 9.8 enforces a linear audit, while probability and physical feasibility need additional constraints. Learned maps, nonlinear gluing and changing covers need separate guarantees. Response constraints across independent districts may be multilinear, and the LP recovery theorem does not silently extend to them or to arbitrary stochastic noise.")
    replace("The cited neuroscience supports selective memory processing", "The cited neuroscience supports selective memory processing, compositional and procedural replay, context routing and representational transformations. It does not identify anatomical layers with ASE depth or neural rhythms with exact certificates. Recent systems-level findings motivate tests of future-task sufficiency and reliable-context transfer; D1–D5 and H1–H4 remain predictions rather than measured benefits.")
    replace("Long teacher traces can train a causal reasoner through", "Long teacher traces can supply proposed transitions, intermediate facts and alternative derivations for a causal interpreter. Value agreement, an operation licence and realized latent execution remain different claims. The inherited census shows why graph premises cannot be replaced by numerical coincidence. The new precision analysis shows why mean checkpoint accuracy cannot be promoted to a per-query error guarantee.")
    replace("Horizontal sheaf structure provides a quantitative compatibility", "Horizontal sheaf structure supports a quantitative audit once spaces, units and maps are fixed. Theorem 9.6 identifies exactly when independent anchors make a linear task observable despite the audit's blind directions; Theorem 9.8 gives a repair that preserves trusted coordinates. Future continuations, rather than transcript length alone, determine the distinctions a finite-precision memory must retain. Scoped certificate reuse can avoid recomputation without multiplying the same claim's statistical risk. These contracts define what to verify and measure; neural learning gains, latency savings and biological implementations remain open empirical questions.")
    # Keep the Figure 3 caption on the same page as its plot.
    p=find("Figure 3 Selection bias")
    for child in list(p._p):
        if child.tag != qn("w:pPr"): p._p.remove(child)
    r=p.add_run("Figure 3 Selection bias and complementary evidence in finite examples")
    r.bold=True
    p.add_run().add_break()
    p.add_run("Left: reference, inspected and corrected expected record values. Right: remaining query width for no report, either report and their pair. Exact finite examples.")
    p.paragraph_format.keep_together=True

    # Replace inaccurate historical build instructions with the current contract.
    app=find("Appendix A Reproduction")
    refs=find("References")
    e=app._p.getnext()
    while e is not None and e is not refs._p:
        nxt=e.getnext(); body.remove(e); e=nxt
    before(refs,frag(blocks["appendix"]))
    newrefs = {
      "Chakravarthula": "Chakravarthula, L. N. C., Ito, T., Tzalavras, A., & Cole, M. W. (2026). Network geometry shapes the transformation of task representations across the human cortex. *Nature Neuroscience*. Advance online publication. https://doi.org/10.1038/s41593-026-02486-8",
      "He, L.": "He, L., Wang, X., Zhang, J., Xiao, Z., Hu, X., Schwartenbeck, P., Bakermans, J., Behrens, T., & Liu, Y. (2026). Human hippocampal ripples coordinate planning sequences and compositional representations in neocortex. *Nature Neuroscience, 29*, 1711–1721. https://doi.org/10.1038/s41593-026-02291-3",
      "Thompson": "Thompson, E. J., Rollik, L. B., Waked, B., Mills, G., Pati, S., Kaur, J., Geva, B., Li, H., Carrasco-Davis, R., George, T., Domine, C., Dorrell, W., & Stephenson-Jones, M. (2026). Replay of procedural memory is independent of the hippocampus. *Nature Neuroscience, 29*, 2237–2248. https://doi.org/10.1038/s41593-026-02362-5",
      "Yin": "Yin, J., Chen, Z., Wang, H., Sun, Y., Jin, Z., Song, D., & Zhang, D. (2026). *VerifierBench: Benchmarking the generation of executable verifiers for LLM agents*. arXiv. https://arxiv.org/abs/2610.28679",
    }
    ref_els=list(refs._p.itersiblings())
    for key,text in newrefs.items():
        target=next((e for e in ref_els if e.tag==qn("w:p") and "".join(e.itertext()).strip() and "".join(e.xpath(".//w:t/text()"))>key),None)
        if target is None:
            target=next((e for e in body if e.tag==qn("w:sectPr")),None)
        if target is None:
            for e in frag(text): body.append(e)
        else:
            before(target,frag(text))

    # Native equation normalization for the tested Pandoc/LibreOffice path.
    for run in doc.element.iter(qn("m:rPr")):
        if run.find(qn("m:nor")) is not None:
            for tag in ("m:sty","m:scr"):
                for el in run.findall(qn(tag)): run.remove(el)
        order={qn("m:"+tag):i for i,tag in enumerate(("lit","nor","scr","sty","brk","aln"))}
        children=sorted(list(run),key=lambda el:order.get(el.tag,99))
        for child in list(run): run.remove(child)
        for child in children: run.append(child)
    for t in doc.element.iter(qn("m:t")):
        if t.text == "\\": t.text="∖"
    for acc in list(doc.element.iter(qn("m:acc"))):
        prop=acc.find(qn("m:accPr"))
        ch=prop.find(qn("m:chr")) if prop is not None else None
        if ch is not None and ch.get(qn("m:val")) in ("̅","¯","‾"):
            bar=OxmlElement("m:bar"); bp=OxmlElement("m:barPr"); pos=OxmlElement("m:pos"); pos.set(qn("m:val"),"top"); bp.append(pos); bar.append(bp)
            base=acc.find(qn("m:e"))
            if base is not None: bar.append(copy.deepcopy(base))
            acc.getparent().replace(acc,bar)

    # Neutral article typography, keeping the source's compact hierarchy.
    style_ids={s.style_id for s in doc.styles}
    if "VerbatimChar" not in style_ids:
        st=doc.styles.add_style("Verbatim Char",WD_STYLE_TYPE.CHARACTER)
        st.font.name="Courier New"; st.font.size=Pt(9.5)
    if "CommentReference" not in style_ids:
        st=doc.styles.add_style("Comment Reference",WD_STYLE_TYPE.CHARACTER)
        st.font.superscript=True
    for st in doc.styles:
        if st.type == 1:
            st.font.name="Times New Roman"
            st.font.color.rgb=RGBColor(0,0,0)
            rf=st.element.find(".//"+qn("w:rFonts"))
            if rf is not None:
                for a in list(rf.attrib):
                    if a.endswith("Theme"): del rf.attrib[a]
    doc.styles["Title"].font.size=Pt(22)
    doc.styles["Subtitle"].font.size=Pt(11)
    for name in ("Normal","Body Text","First Paragraph"):
        st=doc.styles[name]
        st.font.size=Pt(11)
        st.paragraph_format.line_spacing=1.12
        st.paragraph_format.space_after=Pt(6)
    for name,size in (("Heading 1",14),("Heading 2",12),("Heading 3",11)):
        st=doc.styles[name]; st.font.size=Pt(size); st.font.bold=True
        st.paragraph_format.keep_with_next=True
    # Preserve equations and reference layout; avoid dangling Pandoc style IDs.
    after_refs=False
    for p in doc.paragraphs:
        if p.text=="References": after_refs=True; continue
        if after_refs:
            p.style=doc.styles["Normal"]
            p.alignment=WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.left_indent=Inches(.25)
            p.paragraph_format.first_line_indent=Inches(-.25)
            p.paragraph_format.space_after=Pt(4)
            p.paragraph_format.line_spacing=1.08
            for r in p.runs: r.font.size=Pt(10.5)
        if p.style.name in ("Author","Date1","Date"):
            p.style=doc.styles["Normal"]
            p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_after=Pt(4)
            for r in p.runs: r.font.size=Pt(10.5)
        if p.style.name in ("Title","Subtitle") or p.style.name.startswith("Heading"):
            for r in p.runs:
                r.font.color.rgb=RGBColor(0,0,0)
    # Style the one new table in the inherited table idiom.
    if len(doc.tables) != 13: raise ValueError(("table count",len(doc.tables)))
    table=doc.tables[-1]
    table.autofit=False
    widths=[2200,3750,3410]
    tp=table._tbl.find(qn("w:tblPr"))
    for side in ("top","left","bottom","right","insideH","insideV"):
        borders=tp.find(qn("w:tblBorders"))
        if borders is None: borders=OxmlElement("w:tblBorders"); tp.append(borders)
        e=OxmlElement("w:"+side); e.set(qn("w:val"),"single"); e.set(qn("w:sz"),"4"); e.set(qn("w:color"),"D9D9D9"); borders.append(e)
    # Source section has a 6.5-inch text width = 9360 twips.
    for gc,width in zip(table._tbl.tblGrid.gridCol_lst,widths): gc.set(qn("w:w"),str(width))
    for ri,row in enumerate(table.rows):
        trpr=row._tr.get_or_add_trPr(); trpr.append(OxmlElement("w:cantSplit"))
        if ri==0: trpr.append(OxmlElement("w:tblHeader"))
        for ci,cell in enumerate(row.cells):
            cell.width=Inches(widths[ci]/1440)
            pr=cell._tc.get_or_add_tcPr()
            sh=OxmlElement("w:shd"); sh.set(qn("w:fill"),"E9EEF2" if ri==0 else "FFFFFF"); pr.append(sh)
            for p in cell.paragraphs:
                p.style=doc.styles["Body Text"]; p.alignment=WD_ALIGN_PARAGRAPH.LEFT
                p.paragraph_format.space_after=Pt(3); p.paragraph_format.line_spacing=1.05
                for r in p.runs: r.font.size=Pt(9.5); r.bold=(ri==0)
    # Figure 4 is redrawn using the exact same archived census numbers.
    from figure_v4 import draw_figure4
    image_path=draw_figure4(ROOT)
    shape=doc.inline_shapes[3]
    rid=shape._inline.graphic.graphicData.pic.blipFill.blip.embed
    doc.part.related_parts[rid]._blob=image_path.read_bytes()
    doc.core_properties.title="Task Observability in Latent Causal Reasoning"
    doc.core_properties.subject="Version 4: operation certificates, finite precision and anchored sheaf repair"
    doc.core_properties.last_modified_by="Revision review"
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        raw=Path(td)/"uncommented.docx"; doc.save(raw)
        add_comments(raw,out)
    print(out)

def add_comments(source,target):
    """Add three concise review notes, preserving valid paragraph order."""
    with zipfile.ZipFile(source) as z:
        files={name:z.read(name) for name in z.namelist()}
    root=etree.fromstring(files["word/document.xml"])
    comments=etree.Element(qn("w:comments"),nsmap={"w":W})
    notes=[
      ("The tolerance in D2 is a mean absolute error", "V4 correction: D2's mean error is not the entrywise uncertainty radius assumed by the inherited interval census. The census values are retained as a uniform-radius scenario."),
      ("Proposition 8.7 (interval enclosure", "V4 correction: the decoded weighting table is explicitly a probability vector. Normalization alone did not justify the distance-at-most-two step of the original proof."),
      ("The Version 4 source bundle contains", "V4 reproduction update: this builder uses the bundled authoritative V3 Word file. Historical V2 inputs missing from the supplied archive are not required for the current build."),
    ]
    for i,(needle,text) in enumerate(notes):
        matches=[p for p in root.xpath(".//w:p",namespaces=NS) if needle in "".join(p.xpath(".//w:t/text()",namespaces=NS))]
        if len(matches)!=1: raise ValueError(("comment anchor",needle,len(matches)))
        p=matches[0]
        start=OxmlElement("w:commentRangeStart"); start.set(qn("w:id"),str(i))
        p.insert(1 if len(p) and p[0].tag==qn("w:pPr") else 0,start)
        end=OxmlElement("w:commentRangeEnd"); end.set(qn("w:id"),str(i)); p.append(end)
        run=OxmlElement("w:r"); rp=OxmlElement("w:rPr"); sty=OxmlElement("w:rStyle"); sty.set(qn("w:val"),"CommentReference"); rp.append(sty); run.append(rp)
        ref=OxmlElement("w:commentReference"); ref.set(qn("w:id"),str(i)); run.append(ref); p.append(run)
        c=etree.SubElement(comments,qn("w:comment")); c.set(qn("w:id"),str(i)); c.set(qn("w:author"),"Revision review")
        cp=etree.SubElement(c,qn("w:p")); cr=etree.SubElement(cp,qn("w:r")); ct=etree.SubElement(cr,qn("w:t")); ct.text=text
    rels=etree.fromstring(files["word/_rels/document.xml.rels"])
    typ="http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"
    if not any(r.get("Type")==typ for r in rels):
        ids={r.get("Id") for r in rels}; n=1
        while f"rId{n}" in ids: n+=1
        rel=etree.SubElement(rels,f"{{{REL}}}Relationship"); rel.set("Id",f"rId{n}"); rel.set("Type",typ); rel.set("Target","comments.xml")
    ct=etree.fromstring(files["[Content_Types].xml"])
    ns="http://schemas.openxmlformats.org/package/2006/content-types"
    if not any(e.get("PartName")=="/word/comments.xml" for e in ct):
        e=etree.SubElement(ct,f"{{{ns}}}Override"); e.set("PartName","/word/comments.xml"); e.set("ContentType","application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml")
    for name,e in (("word/document.xml",root),("word/comments.xml",comments),("word/_rels/document.xml.rels",rels),("[Content_Types].xml",ct)):
        files[name]=etree.tostring(e,xml_declaration=True,encoding="UTF-8",standalone=True)
    with zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED) as z:
        for name,data in files.items(): z.writestr(name,data)

if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--output",type=Path,default=ROOT/NAME); args=ap.parse_args()
    main(args.output)
