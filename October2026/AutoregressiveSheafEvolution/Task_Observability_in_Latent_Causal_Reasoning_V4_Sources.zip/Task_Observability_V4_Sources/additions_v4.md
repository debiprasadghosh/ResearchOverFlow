<!-- BLOCK precision -->
## 8.4 Mean decoding error and the sensitivity of a query

The tolerance in D2 is a mean absolute error (MAE). Proposition 8.7 instead assumes a bound on every entry of both tables in each evaluated context. These are different contracts. A small dataset average need not bound even the average error of a particular table, and a small table average need not bound a highly weighted query coordinate. The census at a uniform radius of 0.01 is a sensitivity scenario, not a consequence of meeting D2.

**Definition 8.8 (per-context decoding budgets).** For one context with $m$ strata, let $p,\widehat p\in\Delta_m$ be the true and decoded stratum probabilities and let $t,\widehat t\in[0,1]^m$ be the corresponding outcome tables. Write $\tau=p^{\mathsf T}t$, $\widehat\tau=\widehat p^{\mathsf T}\widehat t$, and

$$\alpha=\frac{\|p-\widehat p\|_1}{m},\qquad \beta=\frac{\|t-\widehat t\|_1}{m}.$$

The quantities are dimensionless probability errors. A bound on their average across contexts does not assert either bound in each context. A certified uncertainty set, rather than a fitted average, is needed for a guaranteed answer interval.

**Theorem 8.9 (task sensitivity under table-average budgets).** Let $\overline p\geq\|p\|_\infty$ be a valid bound and let $\rho=\max_i\widehat t_i-\min_i\widehat t_i$. Under Definition 8.8,

$$|\tau-\widehat\tau|\leq\min\!\left\{1,\ \min(1,m\overline p\beta)+\frac{\rho}{2}\min(m\alpha,2)\right\}.$$

*Proof.* Split the difference as $p^{\mathsf T}(t-\widehat t)+(p-\widehat p)^{\mathsf T}\widehat t$. The first term has absolute value at most $\overline p\|t-\widehat t\|_1=m\overline p\beta$, and at most one because $p$ is a probability vector. Subtracting the midrange of $\widehat t$ in the second term changes nothing, since the entries of $p-\widehat p$ sum to zero. Its absolute value is at most $\rho\|p-\widehat p\|_1/2$, and two probability vectors have distance at most two. Finally, both answers lie in $[0,1]$. The triangle inequality gives the claim. ∎

The separate coefficients are attainable, but the sum need not be the sharp joint bound for a particular pair of decoded tables. If no informative probability cap is available, $\overline p=1$ is valid. If $p$ is exactly uniform, the outcome-table term is at most $\beta$; if one stratum carries all the mass it can be $m\beta$. Thus the distribution used by the query matters as much as unweighted readout accuracy.

**Counterexample 8.10 (MAE 0.01 with answer error 0.08).** Set $m=8$, $p=\widehat p=(1,0,\ldots,0)$, $\widehat t=0$ and $t=(0.08,0,\ldots,0)$. Then $\alpha=0$, $\beta=0.01$ and $|\tau-\widehat\tau|=0.08$. Positivity of the weighting table can be imposed by moving $p$ arbitrarily close to this vertex. Lowering $t_1$ slightly makes the MAE strictly less than 0.01 while leaving the answer error close to 0.08. More generally, a single error of one among $Nm$ evaluated outcome cells contributes only $1/(Nm)$ to a dataset MAE. This is a constructed counterexample, not an observed decoder error.

**Proposition 8.11 (sharp interval with an authoritative weighting table).** Suppose $p\in\Delta_m$ is known exactly, $\widehat t\in[0,1]^m$, $b\geq0$, and the sole uncertainty is $t\in[0,1]^m$ with $\|t-\widehat t\|_1\leq b$. The exact upper and lower answer endpoints are

$$u= p^{\mathsf T}\widehat t+\max_{0\leq d\leq 1-\widehat t,\ \mathbf1^{\mathsf T}d\leq b}p^{\mathsf T}d,$$

$$\ell= p^{\mathsf T}\widehat t-\max_{0\leq d\leq\widehat t,\ \mathbf1^{\mathsf T}d\leq b}p^{\mathsf T}d.$$

Each maximum is obtained by sorting the entries of $p$ in descending order and filling the available coordinate capacities until the budget is exhausted. The cost is $O(m\log m)$, or linear after an order has been retained.

*Proof.* For maximization, negative deviations from $\widehat t$ cannot help because $p\geq0$; replacing them by zero preserves feasibility and increases the objective. If an allocation uses a lower-weight coordinate while a higher-weight coordinate has capacity, transferring the smaller of the two available amounts cannot decrease the objective. Repeating this exchange gives the greedy allocation. Apply the same argument to decreases for the lower endpoint. The feasible set is convex and compact, so its continuous scalar image contains every value between the attained endpoints. ∎

This proposition does not greedily solve the general case in which both tables are uncertain. For training it suggests reporting the query-weighted error $\sum_i p_i|t_i-\widehat t_i|$ when $p$ is authoritative, alongside MAE and a worst-case or coverage guarantee. A weighted training loss is a design choice; neither theorem proves that it is easier to optimize or improves generalization.

<!-- BLOCK coverage -->
## 8.5 What finite execution probes can establish

**Lemma 8.12 (coverage plus regularity gives a uniform defect).** Fix one licensed operation, a reachable latent domain $K$, and the execution defect $g(z)=D'F(z)-TD(z)$ in a normed semantic space. Suppose $g$ is $G$-Lipschitz on $K$. If evaluated probes form an $r$-net of $K$ and $\|g(z_i)\|\leq e$ at every probe, then

$$\sup_{z\in K}\|g(z)\|\leq e+Gr.$$

*Proof.* For each $z\in K$, choose a probe with $\|z-z_i\|\leq r$. The triangle inequality gives $\|g(z)\|\leq\|g(z_i)\|+G\|z-z_i\|$. ∎

For example, valid Lipschitz constants for the component maps give $G\leq L_{D'}L_F+L_TL_D$. This is a sufficient estimate and may be loose. The net radius, reachable domain and constants are additional premises; average error on a test set does not supply them. They must be established for the fixed decoder version and operation whose error enters Theorem 8.1. A changed operation still requires a separate premise check.

Without regularity, any finite probes of $[0,1]$ admit a continuous piecewise-linear defect that is zero at every probe and has a peak of one between two probes or at an unprobed endpoint. Without a range constraint its peak can be arbitrarily large. Passing finitely many execution tests therefore proves the evaluated cases, not a universal execution square. In a finite semantic interpreter complete enumeration is an alternative to geometric coverage. In a high-dimensional latent domain a small certified net can be prohibitively expensive.

## 8.6 Future computation at finite precision

The exact quotient in Theorem 8.4 is not obtained by merely declaring nearby states equivalent. Approximation requires a distance and a memory contract.

**Definition 8.13 (finite-horizon continuation pseudometric).** Fix a finite deterministic machine, an operation alphabet and a bounded metric on its observations, including a distinct failure observation. Extend every illegal transition to an absorbing failure state. For horizon $h$, let $O_w(s)$ be the observation after the operation word $w$, and define

$$d_h(s,t)=\max_{|w|\leq h}d\bigl(O_w(s),O_w(t)\bigr).$$

The empty word is included. This is a pseudometric: different states may have identical future observations. For $h\geq1$ and every operation $o$,

$$d_{h-1}(T_os,T_ot)\leq d_h(s,t).$$

*Proof.* Each observation distance satisfies symmetry and the triangle inequality, and taking a maximum preserves them. A continuation after $o$ of length at most $h-1$ is a word of length at most $h$ from the original state. ∎

**Theorem 8.14 (finite-precision continuation memory).** Suppose a deterministic memory with $M$ codes supports every continuation of length at most $h$ with observation error at most $\varepsilon$, uniformly over initial states. States receiving the same code satisfy $d_h(s,t)\leq2\varepsilon$. Consequently, if $\mathcal P(S,d_h,2\varepsilon)$ is the largest size of a set with pairwise distances strictly greater than $2\varepsilon$, then

$$M\geq\mathcal P(S,d_h,2\varepsilon),\qquad b\geq\lceil\log_2\mathcal P(S,d_h,2\varepsilon)\rceil.$$

for a fixed-length $b$-bit memory.

*Proof.* Starting from one code, the same continuation must give one decoded observation. If it is within $\varepsilon$ of each of the two required observations, those observations differ by at most $2\varepsilon$. Take the maximum over continuations. Every pair in a strictly separated packing must therefore receive different codes. Counting codes gives the bit bound. ∎

Pairwise closeness is not an equivalence relation: three real observations $0,a,2a$ have adjacent distances at most $a$ while the endpoints do not. A practical compressor must select actual code cells of controlled diameter and verify their transitions. The theorem is a necessary bound; it does not assert that every packing bound can be attained by a recurrent latent architecture or that approximate cells form a quotient machine.

**Corollary 8.15 (a bounded real code with adversarial noise).** Suppose codes lie in a Euclidean ball of radius $R$ in $\mathbb R^d$, and every report may be perturbed by any vector of norm at most $\eta>0$. If $N$ initial states are pairwise more than $2\varepsilon$ apart in $d_h$ and all continuations must still be decoded with error at most $\varepsilon$, then

$$N\leq(1+R/\eta)^d.$$

*Proof.* Two code centres at distance at most $2\eta$ admit a common corrupted report. From that report one continuation decoder cannot approximate two observations separated by more than $2\varepsilon$. The radius-$\eta$ balls about the $N$ centres are therefore disjoint and lie within the radius-$(R+\eta)$ ball. Comparing Euclidean volumes proves the claim. ∎

This bound states its precision assumption explicitly. It is not a limit for noiseless real numbers with unbounded precision, a stochastic-noise capacity theorem or an estimate of cortical storage capacity. Together with Theorem 8.9 it distinguishes memory that preserves many future tasks from a representation that only has low average present-table error.

<!-- BLOCK anchors -->
## 9.3 When trusted anchors make a task observable

**Hypotheses 9.5 (a fixed linear audit with authoritative anchors).** Let $V$ be the dimensionless product data space, $B:V\to W_B$ its fixed horizontal audit, $C:V\to W_C$ a fixed map of independently trusted measurements, and $H:V\to W_H$ the task readout. All three maps are linear and all spaces are finite dimensional with specified inner products. Assume that a true state $z_*$ exists with $Bz_*=0$ and $Cz_*=b$. The anchors $b$ are authoritative for this theorem; agreement among the audited records alone does not establish their truth. Set $Qz=(Bz,Cz)$.

**Theorem 9.6 (task observability from compatibility and anchors).** Under Hypotheses 9.5, there is a finite constant $\Gamma$ such that, for every $z\in V$,

$$\|H(z-z_*)\|\leq\Gamma\left(\|Bz\|^2+\|Cz-b\|^2\right)^{1/2}$$

if and only if

$$\ker B\cap\ker C\subseteq\ker H.$$

The smallest constant is $\Gamma=\|HQ^\dagger\|_{2\to2}$, where the dagger denotes the Moore-Penrose inverse in the declared inner products.

*Proof.* Put $v=z-z_*$. The combined residual is $Qv$. If a vector lies in $\ker Q$ but not in $\ker H$, its residual is zero and its task error is nonzero; no finite bound exists. Conversely, if $H$ vanishes on $\ker Q$, orthogonal decomposition gives $H=HQ^\dagger Q$. Hence $\|Hv\|\leq\|HQ^\dagger\|\|Qv\|$. For sharpness, $Q^\dagger$ vanishes on $(\operatorname{im}Q)^\perp$, so the norm of $HQ^\dagger$ is attained on $\operatorname{im}Q$ unless it is zero. Every vector in that image is $Qv$ for some $v$, giving equality in the best-constant problem. The zero case has best constant zero. ∎

This is a finite-dimensional factorization and observability criterion applied to the ADC audit. It supplies a task-error certificate relative to trusted semantics, rather than turning horizontal agreement into causal identification. A wrong graph, false anchor or incorrect readout remains an external error. Scaling audit or anchor rows changes $Q$ and its best constant together; a smaller raw residual alone has no invariant meaning.

**Corollary 9.7 (whole-state recovery is stronger than task recovery).** Taking $H=I$ gives a finite state-error bound exactly when $Q$ is injective. In that case the best constant is $1/\sigma_{\min}(Q)$. A task can be observable when $Q$ is not injective, provided every remaining null direction is invisible to $H$.

*Proof.* For $H=I$, the kernel condition says $\ker Q=0$, and the norm of $Q^\dagger$ is the reciprocal of its least singular value. The general statement is Theorem 9.6. ∎

For the three-vertex cycle of Section 9.1 with identity restrictions, $\ker B$ is the constant-vector direction. The anchor $Cz=z_1$ removes it. If $Hz=z_3$, then

$$Q^{\mathsf T}Q=\begin{pmatrix}3&-1&-1\\-1&2&-1\\-1&-1&2\end{pmatrix},\qquad \Gamma^2=5/3.$$

Thus exact agreement together with one correct coordinate fixes the task value; approximate agreement and anchor error control it with constant $\sqrt{5/3}$. With no anchor, the constant wrong section is still invisible. This exact scalar example does not treat the coordinates as probabilities.

**Theorem 9.8 (minimum repair that preserves trusted coordinates).** Partition coordinates into fixed trusted coordinates $x_T$ and adjustable coordinates $x_U$, write $B=(B_T,B_U)$, and let $W_U$ be positive definite. A correction with $\delta_T=0$ and $B(x+\delta)=0$ exists exactly when $r=Bx\in\operatorname{im}B_U$. When feasible, the unique correction minimizing $\delta_U^{\mathsf T}W_U\delta_U$ is

$$\delta_U=-W_U^{-1}B_U^{\mathsf T}\bigl(B_UW_U^{-1}B_U^{\mathsf T}\bigr)^\dagger r.$$

*Proof.* Substitute $y=W_U^{1/2}\delta_U$. The constraint is $B_UW_U^{-1/2}y=-r$. It is feasible precisely under the image condition. The minimum Euclidean-norm solution is the pseudoinverse solution. The identity $A^\dagger=A^{\mathsf T}(AA^{\mathsf T})^\dagger$ gives the displayed expression. Strict convexity gives uniqueness. ∎

For the scalar cycle, the input $(2,0,0)$ projects without anchors to $(2/3,2/3,2/3)$. Fixing the authoritative first coordinate at two instead gives $(2,2,2)$. The first projection is the nearest agreement; the second respects the external trust premise. If the purported anchor is false, neither theorem repairs that premise.

The formula concerns a linear audit in its ambient vector space. Nonnegativity, normalization and other feasibility constraints must be included separately. With a nonempty closed convex feasible set, the coercive, strictly convex weighted repair still has a unique minimizer; the displayed pseudoinverse formula applies only if its candidate satisfies those added constraints. In particular, a table can be horizontally compatible yet fail probability normalization, as the inherited census demonstrates.

<!-- BLOCK neuroscience -->
## 11.5 Recent evidence and the limits of a cortical mapping

He et al. (2026) recorded hippocampal and cortical intracranial activity in patients performing compositional inference tasks. Ripple-associated replay coordinated with medial prefrontal representations of inferred configurations. This supports studying whether replay reorganizes reusable components rather than merely repeating complete episodes. It does not identify a typed operator, an authoritative anchor or an execution certificate in those recordings. The appropriate ADC analogy is a testable relation between replay content, available premises and later transfer.

Chakravarthula et al. (2026) combined human task fMRI with activity-flow modeling to study how connectivity geometry transforms representations. Their analyses associate lower-dimensional connectivity with compression and higher-dimensional connectivity with expansion and conjunctive coding. This motivates measuring which future distinctions survive compression, as formalized by $d_h$, instead of treating a lower-dimensional representation as automatically sufficient. Their measurements do not establish the deterministic continuation contract or the adversarial-noise assumptions of Corollary 8.15.

Replay also cannot be assigned to a single mandatory biological route. Thompson et al. (2026) found striatal procedural replay after complete bilateral hippocampal lesions in mice. Its relationship with learning supports parallel replay mechanisms. An ADC implementation may similarly distribute reusable procedures and episodic records across stores, but that engineering decomposition does not follow anatomically from the experiment.

**H4 (trusted context constrains transfer).** In a compositional inference task, provide independently reliable evidence for one component while other mutually agreeing components conflict with it. The prediction is that later transfer will track the reliable component more than an otherwise matched, explicitly unreliable cue, with matched exposure, reward and present-task accuracy. Freeze the reliability manipulation, a positive minimum transfer interaction and its confidence construction before data collection. An upper confidence endpoint below that minimum refutes the specified prediction. Neural tests should ask whether replay or routing predicts this interaction beyond surprise and reward. Such a finding would support a functional trust constraint, not show that neurons evaluate a pseudoinverse or execute do-calculus.

The mathematical distinction remains useful even if every proposed neural mapping is rejected: overlap residuals measure agreement, independent anchors constrain semantic error, and future-task tests evaluate the information retained by compression. Biological clocks, token order, reasoning-step order and ASE depth remain separate indices.

<!-- BLOCK harness -->
## 12.5 Certificates have different version dependencies

A harness should retain a certificate dependency graph alongside its immutable operation history. An exact table certificate depends on the declared law and query. An operation certificate additionally depends on its primitive semantics and premises. A latent execution certificate depends on the actual update, decoder version, reachable domain, norm and tested or certified error contract. Changing neural weights can invalidate this last certificate while leaving a symbolic graph licence valid. The cache key must bind the dependencies of the particular claim, rather than every available byte or an underspecified task name.

Before a hit, compare immutable references and check a stated transport rule, such as certified model-set inclusion. If neither exact scope equality nor a proved implication is available, return unverified or recompute. A smaller model set preserves a valid outer interval, but sharpness needs surviving endpoint witnesses. A cached failed premise can also be reused only within its declared scope; a new graph may license the formerly forbidden step.

**Theorem 12.3 (deduplicated risk for repeated reuse).** Index distinct admitted uncertain claims by creation order. Suppose the event $E_i$ that claim $i$ is false in its bound scope has conditional probability at most a predictable $\delta_i$, with $\sum_i\delta_i\leq\delta$ almost surely. Suppose every reuse preserves that scope or follows a checked implication introducing no new uncertain premise. Then any number of adaptive cache lookups has probability at most $\delta$ of using a false claim.

*Proof.* A false reused claim implies that at least one of its source claims was false at creation; valid logical implication does not make a true premise false. The event is contained in $\bigcup_iE_i$. Conditional expectation and the union bound give probability at most $\mathbb E\sum_i\delta_i\leq\delta$. The number and adaptive timing of lookups do not enlarge this union. ∎

Repeated reuse of the same uncertain claim spends its creation risk once. It does not create independent corroboration or make that risk smaller. A new statistical premise, a changed evaluator or an unsupported scope extension needs a new valid coverage argument. Exact symbolic checks can use zero mathematical risk relative to their premises; uncertainty in data, model meaning and interpreter correctness is not removed by that convention. This is a reuse specialization of Theorem 10.2, not a calibration theorem for learned verifiers.

## 12.6 Completeness and task-sensitive evaluation

Yin et al. (2026) introduce VerifierBench for executable agent verifiers. Their evaluated verifiers often reject valid alternatives, and verifier-generated tests can share the verifier's mistaken assumptions. This reinforces the distinction between soundness and completeness in Section 7.2. ADC should test certified alternative derivations and expected abstentions alongside corruptions. Agreement between a generated checker and its own examples supplies no universal proof of either property.

**D5 (task-sensitive decoding supervision).** At matched teacher, accepted-record, model-training and verification budgets, adding an authoritative query-weighted outcome loss will reduce held-out causal-answer error compared with unweighted table MAE supervision, while keeping graph-premise checks fixed. Prespecify a relative reduction of at least 10% on a nonzero-error comparison family with concentrated stratum weights, the seed aggregation and a paired uncertainty analysis. A confidence interval for the error ratio entirely above 0.90 refutes the prediction; one crossing 0.90 is inconclusive. Report ordinary MAE, worst per-context error, certified interval width, coverage and cost separately. The mathematical bounds motivate this prediction but do not establish it.

For deployment, the harness therefore records four different observations: whether the operation was licensed, whether its arithmetic passed, whether the decoded execution contract held on the evaluated domain, and how much of the requested task was observable at the available precision. Reusing an immutable verified record can save computation. Whether its savings exceed parsing, lookup, transport and revalidation costs is an empirical latency question, to be measured separately from semantic correctness.

<!-- BLOCK checks -->
## 13.8 Exact examples added in Version 4

The new exact-arithmetic checker evaluates the sensitivity counterexample, a sharp greedy interval, the finite-horizon packing example, the anchor observability constant and the anchored projection. It is separate from the inherited exhaustive census and does not rerun that census, query a teacher, train a student or collect neural data. Its small finite cases check calculations in the new statements; the proofs establish their general forms.

**Table 13 Exact examples for precision and anchored compatibility**

| Calculation | Exact result | Scope |
|:--|:--|:--|
| Eight-cell outcome table | MAE $1/100$; answer error $2/25$ | Average error does not imply an entrywise radius |
| Fixed $p=(3/4,1/4)$, $\widehat t=(1/2,1/2)$, budget $1/4$ | Answer interval $[5/16,11/16]$ | Sharp for the specified $L^1$ uncertainty set |
| Three-cycle with first-coordinate anchor and third-coordinate task | Best squared constant $5/3$ | Fixed scalar linear audit |
| Input $(2,0,0)$ on that cycle | Free repair $(2/3,2/3,2/3)$; anchored repair $(2,2,2)$ | True anchor assumed |
| Eight-state bit machine, one-step horizon, error $1/4$ | Packing size four; at least two bits | Declared future output and operation family |

The result JSON is generated twice in clean Python processes and compared byte for byte. Package checks preserve the inherited census records unchanged and confirm the new Word equations and source paths. The updated Figure 4 label says “uniform radius” rather than identifying the census radius with D2's MAE target. No empirical rate in Sections 5 or 13.2–13.7 is newly estimated by this revision.

<!-- BLOCK appendix -->
The Version 4 source bundle contains the authoritative supplied Version 3 Word file, its available source archive, the new additions, the self-contained builder, the exact-example checker and its result JSON. From the bundle root, run `python check_v4.py` to regenerate the new exact examples and `python build_v4.py` to rebuild the updated Word paper. The builder uses the included Version 3 file directly. It requires Python with python-docx, lxml, NumPy and Matplotlib, plus Pandoc; the checker uses the Python standard library. The generated Markdown is an accessible text companion. Render the rebuilt Word file before relying on its pagination.

The original Version 3 source is retained in `inherited_v3/`. In that directory, `dotnet run -c Release --project kernel -- out_v3 --v3` runs the expanded .NET 8 census, and `python validate_v3.py cs_v3.txt validation_v3.json` regenerates its independent checks. Those commands describe the inherited reproduction path; this revision does not claim to have rerun them. Some earlier Version 2 build inputs referenced by the inherited notes are absent from the supplied archive, so those historical instructions do not constitute the current build contract. Their existing logs are historical results rather than new evidence.

The immutable packet interface, exact rational kernel and original result files remain available for inspection. The current revision adds proof-level observability, finite-precision and reuse contracts. Its small exact examples are reproduced from the new checker; inherited exhaustive results retain their original provenance. No compiler rerun, teacher query, student training or biological experiment is claimed for Version 4.

**Claim status.** Formal results are proved under their stated hypotheses. An authoritative anchor is an assumption to justify outside the horizontal residual. A uniform error bound or a coverage guarantee is an additional certificate, not the consequence of average readout accuracy. D1–D5 and H1–H4 are untested predictions. Exact packet checking remains relative to correct semantics and a correct primitive interpreter; a learned checker requires its own error and completeness assessment.
