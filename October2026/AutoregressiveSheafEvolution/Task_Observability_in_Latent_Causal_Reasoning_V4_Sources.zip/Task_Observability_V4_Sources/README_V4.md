# Task Observability in Latent Causal Reasoning

Version 4 · 1 November 2026 · Debi Prasad Ghosh

Subtitle: Operation certificates with finite precision and anchored sheaf repair

This source bundle rebuilds the updated Word paper from the included authoritative
Version 3 Word file. It retains the inherited result files without claiming a new
exhaustive census or compiler run.

## Main additions

- Theorem 9.6: a task readout is controlled by compatibility and independent anchors
  exactly when the common nullspace cannot change that task; the sharp constant is
  the norm of the readout composed with the combined audit's pseudoinverse.
- Theorem 9.8: minimum weighted repair while holding trusted coordinates fixed,
  with an explicit feasibility condition.
- Theorem 8.9 and Proposition 8.11: task-sensitive query error from per-context
  average budgets, and a sharp interval when the probability weighting is known.
- Lemma 8.12: finite execution probes imply a uniform defect only with certified
  coverage and regularity.
- Theorem 8.14 and Corollary 8.15: finite-horizon continuation packing and a noisy
  real-code bound; approximate closeness is not an equivalence relation.
- Theorem 12.3: scoped reuse counts each distinct uncertain source claim once.
- Updated primary neuroscience evidence and AI-verifier literature, plus untested
  predictions H4 and D5.

## Corrections retained in the manuscript and review comments

1. D2 predicts a mean decoding error, whereas the inherited interval census assumes
   a uniform entrywise radius. The 0.01 row is a sensitivity scenario, not a D2
   consequence. Its numerical values are unchanged. Figure 4's label is corrected.
2. Proposition 8.7 now explicitly requires the decoded weighting table to be a
   probability vector; normalization alone did not justify its original proof.
3. The current build has no dependency on absent historical Version 2 manuscripts.
   Appendix A distinguishes available historical logs from newly reproduced work.

## Files

- `Task_Observability_in_Latent_Causal_Reasoning_V4.docx`: final editable paper.
- `paper_v4.md`, `media/`: synchronized Markdown companion and embedded figures.
- `base_v3.docx`: byte-identical copy of the authoritative supplied V3 manuscript.
- `additions_v4.md`, `build_v4.py`: additions and self-contained edit builder.
- `check_v4.py`, `checks_v4.json`: standard-library exact examples and results.
- `figure_v4.py`, `fig/`: corrected Figure 4, using unchanged inherited census data.
- `source_notes_v4.md`: provenance of the newly cited primary literature.
- `qa_v4.json`: document package and reproduction checks from this revision.
- `inherited_v3/`: supplied V3 sources, logs, C# kernel and recovered V2 materials.

## Reproduce the current revision

From this directory, using Python 3 with python-docx, lxml, NumPy and Matplotlib,
and Pandoc on PATH:

```bash
python check_v4.py
python build_v4.py
pandoc Task_Observability_in_Latent_Causal_Reasoning_V4.docx --standalone --wrap=none --extract-media=. -o paper_v4.md
```

The exact checker runs without third-party Python packages. Its result JSON was
generated in two clean processes and compared byte for byte. It passes 32 small
exact checks, including a comparison of the sensitivity bound on 2,025 rational
cases and independent active-constraint confirmation of the greedy intervals.
These finite calculations support the displayed examples; they do not replace
the proofs or estimate neural performance.

Render the rebuilt DOCX with Word or LibreOffice to inspect all pages. Pagination
depends on installed fonts and Office versions. Native Word equations are retained.
The build is content reproducible; ZIP timestamps and metadata need not give a
byte-identical DOCX package.

## Inherited reproduction path and limits

The commands in `inherited_v3/README_V3.md` document the .NET 8 census and independent
Python validation reported by Version 3. No full census or compiler was rerun for
this revision. The available inherited outputs and validation JSON are preserved
byte for byte. Some V2 inputs referenced by the historical instructions were absent
from the supplied ZIP; those missing inputs are not required for `build_v4.py`.

No teacher was queried, latent student trained, latency benchmark run or biological
data collected. All learned-agent and neuroscience benefits remain hypotheses.

## Mathematical scope

The new observability and repair theorems require fixed finite-dimensional linear
maps and independent anchor truth. Probability feasibility is an additional
constraint. Per-context budgets and finite probe coverage are assumptions to
certify. Reuse risk requires valid source coverage and checked scope transport.
Underlying pseudoinverse, packing, covering and union-bound principles are standard
mathematics specialized to the declared ADC contracts.
