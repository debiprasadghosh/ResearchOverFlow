"""Structural QA for the Version 4 Word/source package; not full OOXML XSD validation."""
from pathlib import Path, PurePosixPath
from collections import Counter
import ast, hashlib, json, posixpath, re, zipfile
from lxml import etree
from docx import Document
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parent
FILE=ROOT/"Task_Observability_in_Latent_Causal_Reasoning_V4.docx"
W="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M="http://schemas.openxmlformats.org/officeDocument/2006/math"
NS={"w":W,"m":M,"r":"http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
checks=[]
def check(name,ok):
    checks.append({"name":name,"passed":bool(ok)})
    if not ok:raise AssertionError(name)

doc=Document(FILE); base=Document(ROOT/"base_v3.docx")
with zipfile.ZipFile(FILE) as z:
    check("DOCX ZIP CRC",z.testzip() is None)
    names=set(z.namelist())
    roots={n:etree.fromstring(z.read(n)) for n in names if n.endswith((".xml",".rels"))}
    check("all XML parts parse",len(roots)>10)
    missing=[]
    for n,r in roots.items():
        if not n.endswith(".rels"):continue
        owner=PurePosixPath(n).parent.parent if n!="_rels/.rels" else PurePosixPath("")
        for rel in r:
            if rel.get("TargetMode")=="External":continue
            target=rel.get("Target","")
            resolved=posixpath.normpath(str(owner/target)) if not target.startswith("/") else target.lstrip("/")
            if resolved not in names:missing.append([n,target,resolved])
    check("internal relationships resolve",not missing)
    r=roots["word/document.xml"]
    check("554 editable OMML equations",len(r.xpath(".//m:oMath",namespaces=NS))==554)
    check("31 native display equations",len(r.xpath(".//m:oMathPara",namespaces=NS))==31)
    comments=roots["word/comments.xml"]
    ids={c.get(qn("w:id")) for c in comments}
    starts={e.get(qn("w:id")) for e in r.xpath(".//w:commentRangeStart",namespaces=NS)}
    ends={e.get(qn("w:id")) for e in r.xpath(".//w:commentRangeEnd",namespaces=NS)}
    refs={e.get(qn("w:id")) for e in r.xpath(".//w:commentReference",namespaces=NS)}
    check("three anchored review comments",len(ids)==3 and ids==starts==ends==refs)
    check("paragraph properties precede content",all(not p.findall(qn("w:pPr")) or p[0].tag==qn("w:pPr") for p in r.iter(qn("w:p"))))
    check("four existing figure slots",len(doc.inline_shapes)==4)
    with zipfile.ZipFile(ROOT/"base_v3.docx") as old:
        for n in ("word/media/image1.png","word/media/image2.png","word/media/image3.png"):
            check("unchanged inherited figure "+n,z.read(n)==old.read(n))

check("author details retained",doc.paragraphs[2].text==base.paragraphs[2].text and doc.paragraphs[3].text==base.paragraphs[3].text)
check("title updated",doc.paragraphs[0].text=="Task Observability in Latent Causal Reasoning")
check("13 tables",len(doc.tables)==13)
def table_text(t):
    return ["".join(c._tc.xpath(".//w:t/text() | .//m:t/text()")) for row in t.rows for c in row.cells]
for i in range(12):
    old=[s.replace("0.01 (D2)","0.01 uniform") for s in table_text(base.tables[i])]
    check(f"inherited table {i+1} values retained",table_text(doc.tables[i])==old)
styleids={s.style_id for s in doc.styles}
check("all paragraph and character styles exist",all(e.get(qn("w:val")) in styleids for e in doc.element.iter() if e.tag in (qn("w:pStyle"),qn("w:rStyle"))))
order={qn("m:"+tag):i for i,tag in enumerate(("lit","nor","scr","sty","brk","aln"))}
check("math run properties in schema order",all([order.get(c.tag,99) for c in pr]==sorted(order.get(c.tag,99) for c in pr) for pr in doc.element.iter(qn("m:rPr"))))
check("title subtitle and headings are black",all(s.font.color.rgb is not None and str(s.font.color.rgb)=="000000" for s in doc.styles if s.name in ("Title","Subtitle","Heading 1","Heading 2","Heading 3")))
sourcepaths=["base_v3.docx","additions_v4.md","build_v4.py","check_v4.py","checks_v4.json","figure_v4.py","README_V4.md","source_notes_v4.md","inherited_v3/cs_v3.txt","inherited_v3/validation_v3.json","inherited_v3/kernel/OpCensus.cs"]
check("current build inputs included",all((ROOT/p).is_file() for p in sourcepaths))
check("authoritative base copies identical",(ROOT/"base_v3.docx").read_bytes()==(ROOT/"inherited_v3/Operation_Certificates_for_Latent_Causal_Reasoning_V3.docx").read_bytes())
for p in ("build_v4.py","check_v4.py","figure_v4.py","audit_v4.py"):ast.parse((ROOT/p).read_text())
check("current Python sources parse",True)
exact=json.loads((ROOT/"checks_v4.json").read_text())
check("32 exact example checks pass",exact["all_passed"] and len(exact["checks"])==32)
historical=json.loads((ROOT/"inherited_v3/validation_v3.json").read_text())
check("inherited 48-check result retained",historical["all_passed"] and len(historical["checks"])==48 and historical["lines"]==36)
md=(ROOT/"paper_v4.md").read_text()
images=re.findall(r"!\[[^\]]*\]\(([^)]+)\)",md)
check("Markdown figures resolve",len(images)==4 and all((ROOT/path).is_file() for path in images))
check("Markdown has title and corrected MAE distinction","title: Task Observability in Latent Causal Reasoning" in md and "mean absolute" in md and "not a consequence of meeting D2" in md)
hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/"inherited_v3").rglob("*")) if p.is_file()}
result={"scope":"Structural package checks and source provenance, not full OOXML schema validation or a census rerun.",
        "all_passed":all(c["passed"] for c in checks),"checks":checks,
        "native_equations":554,"display_equations":31,"tables":13,"figures":4,"review_comments":3,
        "inherited_file_sha256":hashes}
(ROOT/"qa_v4.json").write_text(json.dumps(result,indent=2)+"\n")
print(f"{len(checks)} document/source checks passed; inherited results retained unchanged.")
