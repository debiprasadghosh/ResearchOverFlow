---
subtitle: Operation certificates with finite precision and anchored sheaf repair
title: Task Observability in Latent Causal Reasoning
---

Debi Prasad Ghosh, debiprasadghosh@gmail.com

Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India

Version 4, 1 November 2026

## Abstract

Long teacher traces can train Autoregressive Do Calculus through verified operations, but answer accuracy, horizontal compatibility and realized latent execution require different evidence. This revision establishes a task-observability criterion: compatibility and independently trusted anchors control a linear task error exactly when their common null directions cannot change that task. The sharp constant is a pseudoinverse norm. A constrained repair formula preserves trusted coordinates. We also distinguish mean decoding error from uniform entrywise error, derive a task-sensitive answer bound and a sharp interval under an $L^{1}$ budget, extend exact continuation memory to finite-horizon packing bounds, and state when finite execution probes imply a uniform defect. Repeated adaptive reuse of a scoped certificate spends the risk of its distinct source claims once. The inherited census retains all 1,024 fixed-order five-vertex DAGs and 2,211,840 operation applications per parameter regime. Its value coincidences and exact graph licences remain unchanged. Under a uniform entrywise radius of 0.01, 45.6% of numerically wrong finer-grid adjustment answers lie inside the honest-table enclosure; this is not implied by D2's mean-error target. New exact examples check the added formulas without rerunning the inherited census. Recent replay and cortical-representation findings constrain a functional neuroscience interpretation; they do not establish neural proof checking. Learned-agent gains, transfer benefits and biological mappings remain explicit, untested hypotheses.

Keywords: causal reasoning; task observability; operation certificates; finite-precision memory; sheaf compatibility; anchored repair; adaptive verification

# 1 Introduction

A teacher that has learned by reinforcement to reason at length produces far more text than answers. For ADC this text can supply explicit demonstrations and candidate computations that can be checked and executed. ADC's input is a declared causal model, an observational law and a query; its output is an identified expression with a derivation and a certificate, or a qualified failure (Ghosh, 2026b). A long trace contains candidate operations --- select an adjustment set, apply a rule, compute a table, normalise, sum --- interleaved with corrections, digressions and abandoned attempts.

The proposal examined here has five steps. Generate several candidate solutions for each authoritative problem. Convert their text into checked transitions. Use the checked records to supervise operation selection, latent decoders, alternative derivations, error repair and certificate production. Gradually replace explicit reasoning with continuous computation. Add the sheaf structure of ADC as agreement on declared overlaps. The final objective rewards valid operations, decodable intermediate facts, overlap agreement and certified answers, and is followed by checked on-policy rollouts.

Three questions decide whether this is sound, and each can be answered exactly before any model is trained. Does a correct final answer certify the reasoning that produced it? Does agreement of local representations on their overlaps certify a derivation? And how complete must the checker be? Sections 3 to 5 answer them for adjustment derivations, the simplest identification operation that ADC uses.

## 1.1 Literature Survey

DeepSeek-R1 showed that reasoning ability obtained by large-scale reinforcement learning can be transferred to smaller dense models by supervised fine-tuning on generated reasoning samples (DeepSeek-AI, 2025). GRPO, which estimates advantages from groups of sampled outputs instead of a learned value function, was introduced with DeepSeekMath (Shao et al., 2024); PPO supplies the clipped policy-optimization approach from which GRPO adapts its policy objective (Schulman et al., 2017). The student does not need either optimiser to learn from the teacher's outputs.

Self-taught reasoning filters generated rationales by the correctness of their final answers (Zelikman et al., 2022). Outcome supervision of this kind can raise final-answer accuracy while leaving reasoning errors (Uesato et al., 2022), and step-level process supervision outperformed outcome supervision on difficult mathematics (Lightman et al., 2024). Reported reasoning is also not a reliable account of the computation: models often fail to mention influences that changed their answers (Turpin et al., 2023; Chen et al., 2025). ADC can replace learned step judgements by exact checkers wherever an operation is formally typed.

Coconut trains a model to reason in a continuous latent space by progressively replacing language reasoning steps with continuous thoughts, training on the remaining text without asking each thought to reconstruct the omitted words (Hao et al., 2024). The present proposal adds decodable, certified checkpoints to that curriculum. Interchange interventions offer one way to test whether latent states realise a declared causal computation (Geiger et al., 2021).

Adjustment is classical (Pearl, 1995, 2009). The adjustment criterion of Shpitser, VanderWeele and Robins (2010) is complete for single-action adjustment in DAGs, and Perković et al. (2015) give a complete generalisation. Learning from one's own corrected rollouts is the setting of dataset aggregation (Ross et al., 2011). ADC supplies the typed derivations, exact rule checks and failure records used here (Ghosh, 2026b); its predecessor separates mechanism contexts, clocks and interval dependencies (Ghosh, 2026d).

## 1.2 Contribution and status

The paper develops the verification layer of a teacher-to-latent pipeline. Its contribution is a set of scoped contracts connecting licensed operations, decoded execution, task-sensitive precision, retained future computations and horizontal audits. The mathematical ingredients include established composition, optimal recovery, finite-state minimization, linear observability and packing arguments; they are specialized and proved here. The revision does not claim the underlying linear algebra or covering arguments as new general mathematics.

The inherited study is exhaustive over its fixed-order graph family and random over model parameters. Its supplied outputs and validation logs are retained with their original provenance. Version 4 adds new proofs and small exact-arithmetic examples, reproduced in clean processes, without rerunning the exhaustive census or compiler. No trained student or biological experiment is reported.

Version 3 connected the original C# kernel to the operation, repair and interval contracts through its exhaustive census over 6,144 models. Version 4 adds Theorems 8.9, 8.14, 9.6 and 9.8, a coverage lemma and a certificate-reuse risk theorem. It corrects the distinction between D2's MAE prediction and the entrywise hypothesis used by the interval census, and makes the decoded-simplex premise in Proposition 8.7 explicit. Section 13.8 separates the new examples from the inherited computation.

## 1.3 Structure

Sections 2--6 retain the transition definitions, adjustment census and latent curriculum. Sections 7--9 develop operation semantics, decoded execution, task-sensitive precision, future memory and anchored compatibility. Section 10 studies adaptive acquisition. Sections 11--12 connect the contracts to neuroscience and an AI harness. Section 13 distinguishes inherited computations from the new exact examples; Sections 14--15 state limitations and conclusions. Appendix A gives the current reproduction contract.

# 2 Transition records

**Definition 2.1 (transition record).** A record is a tuple

$$r = (\kappa,\ s,\ o,\ s',\ c,\ \sigma),\quad\quad\ \ \ \ (1)$$

where $\kappa$ is the authoritative problem context (graph, observational law, query, units and intervention assumptions), $s$ the current derivation state, $o$ a typed operation, $s'$ the claimed result, $c$ a certificate or failure record, and $\sigma \in \{\text{verified},\ \text{refuted},\ \text{unverified}\}$ its status. A claim without an available checker keeps the status unverified. Agreement with the final answer alone does not promote an operation to universally valid.

For an adjustment derivation of $P\left( Y = 1 \mid do(X = x) \right)$ the operations are: select a set $Z$, with a graph premise; compute $T_{0} = P(x,z)$, $T_{1} = P(z)$ and $T_{2} = P(Y = 1 \mid x,z)$ from the observational law; and sum

$$\widehat{\tau} = \sum_{z}^{}T_{2}(z)\, T_{1}(z).\quad\quad\ \ \ \ (2)$$

A teacher sentence such as "adjust for the confounder" becomes a selection record. Its certificate is the adjustment criterion evaluated on the declared graph, and the following arithmetic records are checked exactly against the declared law.

**Definition 2.2 (checkers).** For a derivation with answer $\widehat{\tau}$ and true interventional value $\tau$ we compare four checks.

(1) *Exact answer:* $\widehat{\tau} = \tau$.

(2) *Rounded answer:* $\widehat{\tau}$ and $\tau$ agree when both are rounded to two decimals.

(3) *Overlap residual:* the local tables agree on their declared overlap, $\sum_{x}^{}T_{0}(x,z) = T_{1}(z)$ for every $z$, and $\sum_{z}^{}T_{1}(z) = 1$.

(4) *Value certificate:* the set satisfies the complete adjustment criterion, every table equals its exact recomputation from the law, and (2) holds exactly.

The first two are outcome checks. The third is the sheaf-style agreement that the latent objective would encourage. The fourth is the record-level certificate.

# 3 Why a correct answer does not certify a derivation

**Proposition 3.1 (precision of answer filtering).** Suppose every valid trace is accepted, an invalid trace is accepted with probability $c$, and a trace is valid with probability $v$. Then the probability that an accepted trace is valid is

$$\pi = \frac{v}{v + (1 - v)c}.\quad\quad\ \ \ \ (3)$$

If each of $L$ steps is independently wrong with probability $0 < \varepsilon < 1$, then $v = (1 - \varepsilon)^{L}$ and $\pi \rightarrow 0$ as $L \rightarrow \infty$ for every fixed $c > 0$.

*Proof.* Bayes' rule gives (3). With $v = (1 - \varepsilon)^{L} \rightarrow 0$, the numerator vanishes while the denominator tends to $c > 0$. ∎

Long traces are exactly where the risk grows. Equation (3) needs $c$, which depends on the problem family and on how answers are compared; Section 5 measures it.

**Proposition 3.2 (exact and rounded coincidences).** Fix a DAG, finite state spaces, a single-action query and an adjustment set. Assume that the allowed CPT family contains a positive model in which the adjustment answer differs from the true effect. On the open positive CPT parameter domain, that answer difference is a nonzero rational function. Its exact zero set has Lebesgue measure zero. For any fixed rounding precision with a cell whose interior meets $(0,1)$, the rounded-agreement region contains a nonempty open set in the binary CPT family.

*Proof.* The positive witness makes the rational difference nonzero at one interior point. Clearing positive denominators gives a polynomial that is not identically zero, whose zero set has measure zero in independent CPT coordinates. For the rounded statement, choose an interior rounding-cell value $c$. Set every outcome CPT entry to $c$, for example $c = 1/2$ at two-decimal precision, and set the entries at every other vertex to $1/2$, independently of their parents. The observational joint law is then a product law, so both the true effect and every adjustment expression equal $c$, including when the proposed set contains descendants. Positivity and continuity give a neighbourhood in which both remain strictly inside that same cell. This proves a nonempty open region, rather than inferring positive measure from an arbitrary nonempty set. ∎

The measure-zero statement says little about data built from round numbers. Problems written with probabilities in tenths sit on a coarse grid, where ties between conditional probabilities create exact numerical independences. Section 5 shows the consequence.

# 4 What overlap agreement and certificates establish

**Proposition 4.1 (overlap agreement is blind to the choice of set).** Let all local tables of an adjustment derivation be computed correctly from one observational law. They agree on every declared overlap, whether or not $Z$ is a valid adjustment set.

*Proof.* $T_{0}$ and $T_{1}$ are marginals of the same joint law, so marginalising $T_{0}$ over $x$ gives $T_{1}$, and $T_{1}$ sums to one. The validity of $Z$ concerns the causal graph, which does not enter these equalities. ∎

A latent overlap residual of zero therefore cannot teach the student to avoid an invalid adjustment. It detects local inconsistency, such as an arithmetic slip that changes $T_{1}$ without changing $T_{0}$. It cannot detect a consistent computation of the wrong quantity.

**Proposition 4.2 (soundness of the value certificate).** If the certificate accepts a derivation and the observational law is positive, then $\widehat{\tau} = P\left( Y = 1 \mid do(X = x) \right)$ in every model compatible with the graph that induces that law.

*Proof.* A set satisfying the adjustment criterion makes (2) equal to the interventional probability in every compatible model (Shpitser et al., 2010). Exact equality of every table and of the sum then transfers that identity to the computed answer. ∎

The converse direction is deliberate. A derivation through an invalid set can be numerically right in one model, and the certificate still rejects it, because the adjustment-set selection is meant to hold for every compatible model. This value check does not additionally establish how an identical submitted table was produced.

**Proposition 4.3 (valid alternatives agree).** All valid adjustment sets for the same query give identical values of (2). An exact disagreement between two derivations that both claim validity refutes at least one of them.

*Proof.* Each equals the same interventional probability by Proposition 4.2. ∎

Alternative derivations are therefore both training targets and cross-checks. Their costs differ: the number of strata in (2) is $2^{|Z|}$ for binary events.

# 5 Exact study

## 5.1 Design

The family contains all 1,024 DAGs whose edges respect one fixed ordering of five labelled events. Each graph receives three random positive binary models. Every conditional probability $P\left( V_{i} = 1 \mid \text{parents} \right)$ is drawn uniformly from a grid: tenths $\{ 1/10,\ldots,9/10\}$ in one regime, mimicking textbook problems, and hundredths $\{ 1/100,\ldots,99/100\}$ in the other. Queries are $P\left( Y = 1 \mid do(X = x) \right)$ for every ordered pair in which $X$ is an ancestor of $Y$ and for both action values, 37,878 queries per regime. For each query every subset of the other three events is a candidate adjustment set, and its derivation is computed exactly with rational arithmetic. Truth comes from mechanism replacement. Validity follows the complete adjustment criterion: no member on, or descending from, a proper causal path, and every proper non-causal path blocked (Shpitser et al., 2010; Perković et al., 2015).

For the checker study each query's honest derivation uses its smallest valid set. Five corruptions are applied separately:

• every invalid set, computed honestly;

• a slip of $0.01$ in $T_{2}$ at the heaviest stratum, propagated to the answer;

• $0.01$ of mass moved between two strata of $T_{1}$;

• $X$ dropped from the conditioning set of $T_{2}$;

• a slip of $0.01$ in the final sum.

The C# kernel uses immutable records and exact rationals. A Python program recomputes every line with fractions, an independent path-enumeration form of the adjustment and back-door criteria, and a bit-exact replay of the random streams. All 34 lines agree.

## 5.2 Answers do not certify derivations

Every one of the 141,828 valid sets reproduced the true effect exactly. The 161,196 graph-invalid sets included exact and rounded numerical coincidences (Table 1, Figure 1b).

**Table 1 Invalid adjustment sets judged by their answers**

  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Parameters**   **Invalid sets**   **Exact match**   **Match to 2 decimals**   **Error ≤ 0.01**   **Error ≤ 0.05**   **Queries with some invalid set matching to 2 decimals**
  ---------------- ------------------ ----------------- ------------------------- ------------------ ------------------ ----------------------------------------------------------
  Tenths           161,196            10.7%             33.9%                     47.5%              83.3%              60.5%

  Hundredths       161,196            1.0%              30.5%                     44.6%              78.3%              54.8%
  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

With textbook parameters, 10.7% of invalid sets gave exactly the right number, and the naive conditional $P(Y = 1 \mid x)$ was exactly right in 15.6% of the queries that needed adjustment. On the finer grid these rates fell to 1.0% and 1.5%, consistent with Proposition 3.2: coarse grids produce ties between conditional probabilities and hence numerical independences. Agreement to two decimals hardly depended on the grid. In more than half of the queries that admit an invalid set, at least one invalid derivation would pass a two-decimal answer check.

The magnitudes are family dependent. Random tables produce modest confounding biases. Problems designed with strong confounding would produce fewer coincidences, and problems near independence more. The structural point does not depend on the family: an answer check accepts invalid derivations at a rate that must be measured, never assumed to be zero.

## 5.3 What each check catches

Table 2 gives the share of derivations each check accepts in the hundredths regime. The tenths regime is qualitatively identical.

**Table 2 Acceptance by four checks (hundredths regime)**

  ----------------------------------------------------------------------------------------------------------------------------------------------
  **Derivation**                        **Cases**   **Exact answer**   **Answer to 2 decimals**   **Overlap residual**   **Value certificate**
  ------------------------------------- ----------- ------------------ -------------------------- ---------------------- -----------------------
  Honest derivation                     37,878      100.0%             100.0%                     100.0%                 100.0%

  Invalid adjustment set                161,196     1.0%               30.5%                      100.0%                 0.0%

  Slip of 0.01 in P(y \| x, z)          37,878      0.0%               7.2%                       100.0%                 0.0%

  Slip of 0.01 moved within P(z)        9,714       1.0%               74.4%                      0.0%                   0.0%

  X dropped from the conditioning set   37,878      0.5%               8.1%                       100.0%                 0.5%

  Slip of 0.01 in the final sum         37,878      0.0%               0.0%                       100.0%                 0.0%
  ----------------------------------------------------------------------------------------------------------------------------------------------

The certificate accepted every honest derivation and rejected every invalid set and every slip. The overlap residual accepted every invalid set, every slip in $T_{2}$, every dropped condition and every slip in the final sum, exactly as Proposition 4.1 predicts; it caught only the slip that breaks marginal consistency. A two-decimal answer check accepted 74.4% of those marginal slips, because moving $0.01$ of mass between strata with similar outcome rates barely changes the sum.

The certificate accepted 186 dropped-condition derivations (2,268 with tenths). These are not checker errors. In each case the submitted table equalled the required $P(Y = 1 \mid x,z)$ table at the queried action value in that model, so the table the teacher wrote down was numerically the required table. The value checker does not bind the claimed condition-deletion operation. Section 7 supplies a stronger operator contract and distinguishes graph-licensed deletion from a coincident value or an explicitly law-specific rewrite. Section 13.4 shows that none of these deletions is graph-licensed (Proposition 7.5); an operation-bound certificate rejects all of them.

![Left: acceptance shares by derivation type and check, hundredths regime. Right: cumulative distribution of the absolute error of invalid adjustment sets in both regimes, with reference lines at 0.005, 0.01 and 0.05.](./media/image1.png){width="6.4in" height="2.8342858705161853in"}

**Figure 1 Acceptance by four checks, and how close invalid adjustment sets come to the true effect**\
Left: acceptance shares by derivation type and check, hundredths regime. Right: cumulative distribution of the absolute error of invalid adjustment sets in both regimes, with reference lines at 0.005, 0.01 and 0.05.

## 5.4 Checker completeness and alternative derivations

The back-door criterion is sound but not complete for adjustment. Of the 141,828 valid sets, 32,040 (22.6%) failed the back-door test; they contain descendants of $X$ that lie off every causal path. No back-door set was invalid. A back-door-only checker would leave more than a fifth of the valid derivations uncertified. Relabelling those unresolved records as errors would teach a false rejection; honest abstention preserves soundness.

Valid alternatives were common. The full histogram of valid sets per query is: one in 6,192 queries; two in 10,728; three in 1,092; four in 10,872; five in 486; six in 1,422; seven in 234; and eight in 6,852. These counts sum to 37,878. In 31,686 queries (83.7%) at least two valid derivations existed, and in every one of them all valid derivations agreed exactly, as Proposition 4.3 requires. Their costs differed: the largest valid set used on average 4.31 times as many strata as the smallest, and up to 8 times.

## 5.5 Consequences for answer-filtered data

Taking the measured two-decimal acceptance rate of invalid sets, $c = 0.305$, as the acceptance probability of an invalid trace, Proposition 3.1 gives the share of valid traces among those accepted by answer filtering (Table 3). This transfer is a model assumption: real traces fail in many ways, and $c$ differs for each.

**Table 3 Valid share of answer-filtered traces, with c measured in Section 5.2**

  -------------------------------------------------------------------------------
  **Steps L**   **Step error 0.01**   **Step error 0.02**   **Step error 0.05**
  ------------- --------------------- --------------------- ---------------------
  5             0.985                 0.969                 0.918

  10            0.969                 0.936                 0.830

  20            0.936                 0.868                 0.647

  40            0.869                 0.725                 0.326
  -------------------------------------------------------------------------------

At forty steps and a 5% step error, only about a third of the accepted traces would be valid. A sound value certificate removes false-answer acceptance within its declared domain. Certifying the actual operation additionally requires the binding introduced in Section 7; a parser or input-model error remains a separate risk.

# 6 From verified records to latent computation

This section is a proposal. It specifies how the verified records would train ADC, and what would show the approach to be wrong.

## 6.1 What each kind of teacher material trains

**Table 4 Teacher material and its training use**

  -------------------------------------------------------------------------------------------------------------------------------------------------------
  **Teacher-derived material**             **Training use in ADC**                                   **Check that admits it**
  ---------------------------------------- --------------------------------------------------------- ----------------------------------------------------
  Valid operation sequences                Select the next operation or tool                         Operation-bound certificate of Section 7

  Verified intermediate claims             Train decoders that test what a latent state represents   Exact recomputation of the claim

  Alternative valid derivations            Learn several solution paths and their costs              Exact agreement of their answers (Proposition 4.3)

  Incorrect steps with checked diagnoses   Learn rejection, repair and qualified failure             Certificate failure with its reason

  Final answers and certificates           Train answer generation and certificate production        The full derivation certificate
  -------------------------------------------------------------------------------------------------------------------------------------------------------

Steps without a checker remain unverified records. They may serve as context, but not as supervised targets.

## 6.2 Objective

For a record set $\mathcal{R}$ the student minimises

$$\mathcal{L =}\mathcal{L}_{op} + \lambda_{d}\mathcal{L}_{dec} + \lambda_{o}\sum_{i,j}^{} \parallel \rho_{i,ij}\left( z_{i} \right) - \rho_{j,ij}\left( z_{j} \right) \parallel^{2} + \lambda_{a}\mathcal{L}_{ans},\quad\quad\ \ \ \ (4)$$

where $\mathcal{L}_{op}$ is the cross-entropy of the certified next operation, $\mathcal{L}_{dec}$ the decoding loss of verified claims from separator checkpoints, the third term the overlap residual after coordinates and units are aligned, and $\mathcal{L}_{ans}$ the loss of certified answers and certificates. By Proposition 4.1 the overlap term is a regulariser, not a correctness signal. Correctness enters only through records admitted by certificates, and the exact certificate is still run at inference.

## 6.3 Curriculum and information availability

Training starts from explicit verified steps. Stage $k$ removes the first $k$ verbal steps of each derivation and requires the latent computation to support the remaining steps, the checkpoint decoders and the certified answer, following Coconut's progressive replacement (Hao et al., 2024). Two constraints are added:

• The input at a checkpoint may contain only information available at that point of the derivation. This is the prefix condition of nonanticipation, and teacher activations are not required.

• Reasoning-step order, physical event time and layer depth remain separate indices, as in ADC and its predecessor.

After supervised training, the student's own rollouts are checked by the same certificates and added as records, so that errors occurring along its own trajectories are corrected (Ross et al., 2011).

## 6.4 Falsifiable predictions

**D1 (step certificates beat answer filtering).** On held-out causal structures, a student trained on certificate-admitted records will select invalid adjustment sets at most half as often as one trained on the same number of two-decimal answer-filtered traces from the same teacher. A confidence interval for the ratio lying entirely above 0.5 contradicts the prediction; one crossing 0.5 is inconclusive.

**D2 (decodable checkpoints survive step removal).** After removing half of the verbal steps, linear decoders at separator checkpoints will recover the certified intermediate tables of held-out queries with mean absolute error below 0.01. Failure to meet this threshold contradicts the stated linear-readout prediction. It does not alone establish a shortcut; Section 8 adds an execution test.

**D3 (complete checkers matter).** A student trained with a back-door-only checker will fail to certify valid non-back-door sets on held-out queries at least twice as often as one trained with the complete criterion. A ratio interval entirely below 2 contradicts the prediction.

None of these has been run. Propositions 3.1 to 4.3 and the measurements of Section 5 do not depend on their outcomes.

# 7 Operations and values require different certificates

## 7.1 A typed execution model

An answer can be numerically right for two different reasons. A licensed rule may establish it throughout the declared model class, or a different computation may happen to agree on the current observational law. Both facts can be useful, but they supervise different capabilities. The dropped-condition rows of Table 2 make this distinction observable: the original checker compares the submitted tables with the required tables, without recording the syntax of the operation that produced them. We call that checker a *value certificate* in this revision. Its soundness for the submitted answer is retained. A stronger claim about a reusable operation requires an operation-bound certificate.

**Definition 7.1 (a context-indexed execution).** Fix an authoritative context $\kappa$, containing the event meanings, graph, latent-model class, data, query, units and evaluator versions. A state $s \in S_{\kappa}$ is a typed collection of available facts and unresolved obligations. An operation $o$ has a declared precondition $P_{\kappa,o}$ and a partial semantic map $T_{\kappa,o}:P_{\kappa,o} \rightarrow S_{\kappa}$. A certificate binds $\kappa$, the actual operand state, $o$, its premises and the claimed result. Its checker accepts only if those premises hold and the result equals the declared map on those operands.

This definition is relative to a trusted mathematical interpreter and a faithful input specification. An expression parser, a graph extracted from prose and an observation protocol each require their own assessment. A digest detects changes to bound contents; it does not establish their truth, provenance or authority. The context includes semantic objects rather than only human-readable labels.

**Proposition 7.2 (numerical equality does not license condition deletion).** A value certificate can accept a table computed by dropping $X$ from $P(Y \mid X,Z)$ even though that deletion is not a valid graph-level rule.

*Proof.* Consider the allowed graph $X \rightarrow Y$ and a positive model in which $X$ and $Y$ are independent fair bits. For $Z = \varnothing$, both $P(Y = 1 \mid X = 1)$ and $P(Y = 1)$ equal $1/2$. Adjustment by the empty set is valid, and a checker comparing only tables and the resulting answer accepts the dropped table. The graph does not imply $Y\bot X$. In a compatible positive model with $P(Y = 1 \mid X = 0) = 1/4$ and $P(Y = 1 \mid X = 1) = 3/4$, the required table at $X = 1$ is $3/4$, while the dropped table is $1/2$ if $X$ remains fair. Thus universal deletion is invalid. ∎

No faithfulness assumption is made here: an allowed arrow may be inactive in a particular model. Conversely, deletion is legitimately available in $C \rightarrow X$, $C \rightarrow Y$ after conditioning on $C$, because $Y\bot X \mid C$ follows by d-separation. An operation-aware checker must support this valid route instead of banning every textual deletion. A separately proved equality on one fixed law can also license an explicitly law-specific rewrite; it does not become a graph-universal rule.

**Theorem 7.3 (relative soundness of typed composition).** Suppose the initial state is correct in a fixed context and every accepted operation-bound certificate satisfies Definition 7.1. Then any finite sequence of accepted operations produces the semantic state obtained by composing the corresponding maps. Every claim entailed by that state is correct relative to the same context.

*Proof.* The base state has the asserted meaning by hypothesis. If state $s_{j}$ is the semantic state and its certificate accepts, its premises hold on the actual $s_{j}$ and the next state is $T_{\kappa,o_{j}}\left( s_{j} \right)$. Induction establishes the claim at every finite step. The final entailment is part of the trusted semantic interpreter. ∎

This is an elementary execution theorem, not a new completeness theorem for causal identification. Its purpose is to state exactly what a training label promises. The general causal rules remain attributed to their original authors; an accepted adjustment operation uses the complete criterion only within its specified domain.

## 7.2 Abstention and completeness

**Corollary 7.4 (incompleteness requires an unresolved status).** A sound checker that fails to prove a proposed operation cannot, from that failure alone, label its conclusion false. It may return unverified. A refutation needs a failed claimed premise or a semantic witness against the relevant validity claim.

*Proof.* A sound incomplete checker can fail on a true proposition. Therefore failure cannot imply falsity. A countermodel or an exact contradiction supplies additional evidence and must be checked in the same context. ∎

The back-door comparison in Section 5 measures missed certificates, not necessarily false negative truth judgements. A back-door-only service that honestly returns unverified remains sound. A training pipeline that relabels all those returns as invalid operations introduces label error. This distinction matters when estimating the cost of a more complete checker.

**Table 5 Three claims carried by a reasoning record**

  -----------------------------------------------------------------------------------------------------------------------------------------------------------
  **Claim**                     **What is established**                                            **Additional obligation**
  ----------------------------- ------------------------------------------------------------------ ----------------------------------------------------------
  Value agreement               The submitted value equals a required value on the declared data   Bind the query, data and arithmetic

  Licensed operation            The stated transformation is valid in its declared scope           Bind the operator, operands and premises

  Realized latent computation   Decoded latent transitions implement the stated transformations    Check execution squares on the relevant reachable states
  -----------------------------------------------------------------------------------------------------------------------------------------------------------

These levels are cumulative only when their extra obligations are met. A natural-language account of an operation is a proposal to the interpreter. It is not evidence that the teacher internally executed that operation, even when the resulting formal derivation is valid.

## 7.3 The dropped condition is never licensed

**Proposition 7.5 (the dropped action is unlicensed in every adjustment derivation).** Let $X$ be an ancestor of $Y$ in a DAG and let $Z$ satisfy the adjustment criterion for $(X,Y)$. Then $Y$ and $X$ are d-connected given $Z$. Replacing $P(Y \mid X,Z)$ by $P(Y \mid Z)$ is therefore never a graph-licensed step of such a derivation.

*Proof.* There is a directed path from $X$ to $Y$. Its interior vertices lie on a proper causal path and are forbidden, so none belongs to $Z$. A directed path has no colliders, so it is open given $Z$. ∎

The 186 and 2,268 dropped-condition derivations that the value certificate accepted in Table 2 are thus coincidences of the sampled law, never instances of a reusable rule. The operation-bound certificate of Definition 7.1 rejects them by its premise check alone; Section 13.4 confirms this on every inherited query.

**Proposition 7.6 (unlicensed deletion is non-generic).** Fix a DAG on binary events. If $Y$ and $W$ are not d-separated by $S$, the positive conditional-probability parameters at which $P(Y = 1 \mid W,S) = P(Y = 1 \mid S)$ holds in every cell form a set of Lebesgue measure zero.

*Proof.* For binary $Y$ the cellwise equality is the conditional independence $Y\bot W \mid S$. For discrete DAG models, the parameters at which a d-connected pair is conditionally independent have measure zero (Meek, 1995). ∎

Proposition 7.6 is a statement about continuous parameters. Problems written on a coarse grid sit on a measure-zero set where such coincidences are common, which Section 13.3 measures for deletion and for the three rules of the do-calculus. Rules 2 and 3 compare interventional and observational laws; for them we report the census without claiming a genericity theorem.

# 8 What latent reasoning must preserve

## 8.1 A commuting execution square

Let $Z_{j}$ be a latent state space and $D_{j}:Z_{j} \rightarrow S_{j}$ a semantic decoder. For one fixed licensed operation at step $j$, let $F_{j}$ be the latent update and $T_{j}$ the semantic update. Exact realization requires

$$D_{j + 1} \circ F_{j} = T_{j} \circ D_{j}.\quad\quad\ \ \ \ (5)$$

Equation (5) is a commuting square. It concerns reasoning-step transitions, not the denoising layer index. Within each step, a representation can also carry ASE's vertical fibre diagram across layers. Physical event time, generated token order, reasoning steps and ASE depth retain their separate meanings. A stalk is a data space; neither a word token nor its trajectory is itself a stalk. If a layer changes its base through $\Phi_{t}$, transporting sheaves uses the inverse image $\Phi_{t}^{- 1}$, with compatible structure maps. The finite calculations below use fixed bases and require no changing-base construction.

**Theorem 8.1 (error accumulation for decoded execution).** Suppose the semantic spaces use stated norms, $T_{j}$ is $L_{j}$-Lipschitz, and on every latent state reachable under the evaluated policy,

$$\parallel D_{j + 1}F_{j}(z) - T_{j}D_{j}(z) \parallel \leq \epsilon_{j}.\quad\quad\ \ \ \ (6)$$

Let $s_{j + 1} = T_{j}\left( s_{j} \right)$, $z_{j + 1} = F_{j}\left( z_{j} \right)$ and $e_{0} = \parallel D_{0}\left( z_{0} \right) - s_{0} \parallel$. Then

$$\parallel D_{n}\left( z_{n} \right) - s_{n} \parallel \leq e_{0}\prod_{j = 0}^{n - 1}L_{j} + \sum_{k = 0}^{n - 1}\epsilon_{k}\prod_{j = k + 1}^{n - 1}L_{j}.\quad\quad\ \ \ \ (7)$$

*Proof.* Insert and subtract $T_{j}D_{j}\left( z_{j} \right)$ and apply the triangle inequality to obtain $e_{j + 1} \leq \epsilon_{j} + L_{j}e_{j}$. Repeated substitution gives (7), with an empty product equal to one. ∎

For probability states propagated by a fixed Markov kernel, total variation is nonexpansive, so $L_{j} \leq 1$ and the bound is $e_{0} + \sum_{j}^{}\epsilon_{j}$. A normalization by a small probability can instead have a large sensitivity; it must be bounded separately. A norm on concatenated quantities is meaningful only after compatible types and units have been specified. The theorem assumes the same licensed operation on both sides. A wrong graph or a different selected operation is not silently included in $\epsilon_{j}$.

The reference recurrence takes $T(s) = s/2$, $F(z) = z/2 + 1/100$ and initial error $1/10$. After 4 steps its error and bound both equal $1/40$. This is an exact calculation demonstrating tightness of the recurrence, not evidence that a neural decoder achieves its uniform premises.

**Proposition 8.2 (decodability alone does not establish use).** Perfect checkpoint decoding and correct training answers need not imply (5) after a relevant state intervention.

*Proof.* Let the semantic task be $T(s) = 1 - s$ on bits. Let latent states be $z = (s,b)$, let $D(z) = s$, and let $F(s,b) = (b,b)$. On the training states $(0,1)$ and $(1,0)$, the decoder recovers $s$ perfectly and $DF(s,b) = 1 - s$. Replace $s$ by $1 - s$ while retaining $b$. The decoded input changes, but the computation still outputs $b$, so both modified cases violate (5). ∎

The independent check reports 0 training errors and 2 altered-state errors among 2 cases in each condition. Such an intervention tests a computational abstraction. It does not establish that an external physical intervention has occurred. Geiger et al. (2021) provide the relevant causal-abstraction methodology. A failed linear probe alone would establish neither this bypass nor the absence of reasoning.

## 8.2 A sufficient memory for future operations

Reconstructing every word of the teacher trace is unnecessary. Retaining only the present answer can be insufficient. The correct target lies between these extremes and depends on the allowed future computations.

**Definition 8.3 (continuation equivalence).** Consider a finite deterministic semantic machine with partial transitions $T_{o}$, an operation alphabet and a fixed family of observable claims. Two states satisfy $s \sim t$ when every finite operation word has the same legality from both states and, whenever legal, yields the same observable claims. The empty word is included. An illegal continuation has a distinct failure output.

**Theorem 8.4 (minimal exact continuation memory).** The equivalence of Definition 8.3 is preserved by every legal transition. Its quotient machine reproduces all declared continuation claims. Any deterministic encoding that supports all these claims exactly must distinguish different equivalence classes. If there are $N$ classes, any fixed-length binary memory requires at least $\lceil\log_{2}N\rceil$ bits; an encoding by class index attains this bound.

*Proof.* If $s \sim t$, appending any operation word after a legal first operation gives the same legality and outputs; hence $T_{o}(s) \sim T_{o}(t)$. Transitions and observations therefore descend to the quotient. If an encoding assigned the same code to inequivalent states, some continuation would require two distinct outputs or legality decisions from that same code, a contradiction. Counting distinct fixed-length binary codes proves the bit bound. ∎

This is the finite-state minimization principle applied to a declared causal interpreter. It does not prove a neural sample-complexity bound, and the bit bound cannot be applied to noiseless arbitrary real coordinates without an encoding or precision assumption.

In the reference machine, states are three bits $(a,b,c)$; operations flip $a$, swap $a$ and $b$, or flip $c$. The third bit is irrelevant to the chosen tasks. Preserving the present output $a$ and all future operations requires 4 equivalence classes, or 2 bits. Preserving parity $a \oplus b$ requires 2 classes, or 1 bit. Encoding only $a$ gives the present output exactly but produces 16 ordered state-pair disagreements after the swap. Memory adequacy depends on both queries and continuations.

## 8.3 Linear information and stored precision

**Corollary 8.5 (additional exact linear memory).** Let $q$ range over the full probability simplex, retain $Aq$ exactly with the normalization row in the row space of $A$, and require the fixed linear query family $Cq$. The least number of additional linear memory coordinates is

$$k = rank\begin{pmatrix}
A \\
C
\end{pmatrix} - rank(A).\quad\quad\ \ \ \ (8)$$

*Proof.* Choose a basis of the query rows modulo the row space of $A$ to obtain a sufficient code with $k$ rows. Conversely, exact reconstruction requires every query row to lie in the row space of the retained and added rows. Otherwise a null direction changes a query while leaving all retained coordinates fixed. A sufficiently small perturbation of an interior simplex point realizes both signs of that direction. At least $k$ additional rows are necessary. ∎

This specializes the causal-memory result in Ghosh (2026b). Extra known affine constraints must be included before applying the row-space test. Multiple unknown independent response blocks generally give nonlinear constraints; concatenation does not automatically turn them into one free response simplex.

Rank does not determine noise amplification. For completeness, the precision contract inherited from the same paper is stated explicitly.

**Proposition 8.6 (bounded-noise recovery on a response polytope).** Let $K$ be a nonempty compact polytope, let a memory report $z = Mq + e$ with $|e| \leq h$ and $h \geq 0$, and let the scalar query be $c^{\mathsf{T}}q$. For this unrestricted coordinatewise bounded-report channel, the minimax absolute error over deterministic decoders is

$$R^{*} = \frac{1}{2}\max_{\substack{q,q' \in K \\ \left| M(q - q') \right| \leq 2h}}c^{\mathsf{T}}(q - q').\quad\quad\ \ \ \ (9)$$

Equivalently, writing $W(K;v) = \max_{K}v^{\mathsf{T}}q - \min_{K}v^{\mathsf{T}}q$,

$$R^{*} = \min_{\lambda}\left\lbrack h^{\mathsf{T}}|\lambda| + \frac{1}{2}W\left( K;c - M^{\mathsf{T}}\lambda \right) \right\rbrack.\quad\quad\ \ \ \ (10)$$

*Proof.* A feasible pair in (9) admits a common midpoint report, so any decoder errs by at least half the query difference on one member. For any $\lambda$, subtract the midpoint of the residual range of $\left( c - M^{\mathsf{T}}\lambda \right)^{\mathsf{T}}q$ and use the affine decoder based on $\lambda^{\mathsf{T}}z$. Its error is bounded by (10). Linear-programming duality makes these bounds equal. This is the finite recovery theorem proved in Ghosh (2026b), related to classical optimal recovery. ∎

For $K = \Delta_{3}$, $c = (1,0,0)$ and rows $M_{1} = (1,1,0)$, $M_{2} = (0,1,0)$, subtracting the two stored values recovers $q_{1}$ exactly at zero noise. With coordinate errors $h_{1} = h_{2} = 1/20$, the sharp minimax error is $1/10$. Section 13 independently checks the LP over indistinguishable pairs. An adequate exact memory can therefore be too imprecise for a requested causal decision.

**Proposition 8.7 (interval enclosure of a decoded adjustment sum).** Suppose a checkpoint decodes ${\widehat{T}}_{1} \in \Delta_{m}$ and ${\widehat{T}}_{2} \in \lbrack 0,1\rbrack^{m}$. Assume the true tables satisfy $\left| T_{1} - {\widehat{T}}_{1} \right| \leq h$ and $\left| T_{2} - {\widehat{T}}_{2} \right| \leq h$ entrywise, with $T_{1} \in \Delta_{m}$, $T_{2} \in \lbrack 0,1\rbrack^{m}$ and $h \geq 0$. The consistent adjustment sums form a closed interval $\lbrack\ell,u\rbrack$. Its endpoints are the optima of two linear programmes over

$$\left\{ T_{1}:\max\left( 0,{\widehat{T}}_{1} - h \right) \leq T_{1} \leq \min\left( 1,{\widehat{T}}_{1} + h \right),\quad\mathbf{1}^{\mathsf{T}}T_{1} = 1 \right\},$$

with coefficient vectors $\max\left( 0,{\widehat{T}}_{2} - h \right)$ and $\min\left( 1,{\widehat{T}}_{2} + h \right)$, solved exactly by a greedy fill. With $m$ strata and range $\rho$ of ${\widehat{T}}_{2}$, the enclosure width obeys (15).

$$u - \ell \leq 2h + \rho\,\min(mh,\, 2).\quad\quad\ \ \ \ (15)$$

A value check using only this uncertainty set can refute a submitted answer $a$ only if $a \notin \lbrack\ell,u\rbrack$. A separate graph-premise check may reject a derivation whose value lies inside the interval.

*Proof.* For fixed nonnegative $T_{1}$ the sum is increasing in each entry of $T_{2}$, so its extremes use the endpoint coefficients; the remaining problem is linear over a box intersected with the simplex, where the greedy fill is optimal. The feasible set is connected and the sum is continuous, so every intermediate value is attained. For (15), write $\sum T_{2}T_{1} - \sum{\widehat{T}}_{2}{\widehat{T}}_{1} = \sum\left( T_{2} - {\widehat{T}}_{2} \right)T_{1} + \sum\left( {\widehat{T}}_{2} - c \right)\left( T_{1} - {\widehat{T}}_{1} \right)$ for the midrange $c$ of ${\widehat{T}}_{2}$, using $\sum\left( T_{1} - {\widehat{T}}_{1} \right) = 0$. The first term is at most $h$ and the second at most $\frac{1}{2}\rho\, \parallel T_{1} - {\widehat{T}}_{1} \parallel_{1} \leq \frac{1}{2}\rho\min(mh,2)$. ∎

Prediction D2 asks for mean absolute decoding error below 0.01; it does not assert the per-context entrywise bound of Proposition 8.7. The following results distinguish those guarantees. Section 13.6 retains the interval census as a uniform-radius sensitivity calculation.

## 8.4 Mean decoding error and the sensitivity of a query

The tolerance in D2 is a mean absolute error (MAE). Proposition 8.7 instead assumes a bound on every entry of both tables in each evaluated context. These are different contracts. A small dataset average need not bound even the average error of a particular table, and a small table average need not bound a highly weighted query coordinate. The census at a uniform radius of 0.01 is a sensitivity scenario, not a consequence of meeting D2.

**Definition 8.8 (per-context decoding budgets).** For one context with $m$ strata, let $p,\widehat{p} \in \Delta_{m}$ be the true and decoded stratum probabilities and let $t,\widehat{t} \in \lbrack 0,1\rbrack^{m}$ be the corresponding outcome tables. Write $\tau = p^{\mathsf{T}}t$, $\widehat{\tau} = {\widehat{p}}^{\mathsf{T}}\widehat{t}$, and

$$\alpha = \frac{\parallel p - \widehat{p} \parallel_{1}}{m},\quad\quad\beta = \frac{\parallel t - \widehat{t} \parallel_{1}}{m}.$$

The quantities are dimensionless probability errors. A bound on their average across contexts does not assert either bound in each context. A certified uncertainty set, rather than a fitted average, is needed for a guaranteed answer interval.

**Theorem 8.9 (task sensitivity under table-average budgets).** Let $\overline{p} \geq \parallel p \parallel_{\infty}$ be a valid bound and let $\rho = \max_{i}{\widehat{t}}_{i} - \min_{i}{\widehat{t}}_{i}$. Under Definition 8.8,

$$\left| \tau - \widehat{\tau} \right| \leq \min\left\{ 1,\ \min\left( 1,m\overline{p}\beta \right) + \frac{\rho}{2}\min(m\alpha,2) \right\}.$$

*Proof.* Split the difference as $p^{\mathsf{T}}\left( t - \widehat{t} \right) + \left( p - \widehat{p} \right)^{\mathsf{T}}\widehat{t}$. The first term has absolute value at most $\overline{p} \parallel t - \widehat{t} \parallel_{1} = m\overline{p}\beta$, and at most one because $p$ is a probability vector. Subtracting the midrange of $\widehat{t}$ in the second term changes nothing, since the entries of $p - \widehat{p}$ sum to zero. Its absolute value is at most $\rho \parallel p - \widehat{p} \parallel_{1}/2$, and two probability vectors have distance at most two. Finally, both answers lie in $\lbrack 0,1\rbrack$. The triangle inequality gives the claim. ∎

The separate coefficients are attainable, but the sum need not be the sharp joint bound for a particular pair of decoded tables. If no informative probability cap is available, $\overline{p} = 1$ is valid. If $p$ is exactly uniform, the outcome-table term is at most $\beta$; if one stratum carries all the mass it can be $m\beta$. Thus the distribution used by the query matters as much as unweighted readout accuracy.

**Counterexample 8.10 (MAE 0.01 with answer error 0.08).** Set $m = 8$, $p = \widehat{p} = (1,0,\ldots,0)$, $\widehat{t} = 0$ and $t = (0.08,0,\ldots,0)$. Then $\alpha = 0$, $\beta = 0.01$ and $\left| \tau - \widehat{\tau} \right| = 0.08$. Positivity of the weighting table can be imposed by moving $p$ arbitrarily close to this vertex. Lowering $t_{1}$ slightly makes the MAE strictly less than 0.01 while leaving the answer error close to 0.08. More generally, a single error of one among $Nm$ evaluated outcome cells contributes only $1/(Nm)$ to a dataset MAE. This is a constructed counterexample, not an observed decoder error.

**Proposition 8.11 (sharp interval with an authoritative weighting table).** Suppose $p \in \Delta_{m}$ is known exactly, $\widehat{t} \in \lbrack 0,1\rbrack^{m}$, $b \geq 0$, and the sole uncertainty is $t \in \lbrack 0,1\rbrack^{m}$ with $\parallel t - \widehat{t} \parallel_{1} \leq b$. The exact upper and lower answer endpoints are

$$u = p^{\mathsf{T}}\widehat{t} + \max_{0 \leq d \leq 1 - \widehat{t},\ \mathbf{1}^{\mathsf{T}}d \leq b}p^{\mathsf{T}}d,$$

$$\ell = p^{\mathsf{T}}\widehat{t} - \max_{0 \leq d \leq \widehat{t},\ \mathbf{1}^{\mathsf{T}}d \leq b}p^{\mathsf{T}}d.$$

Each maximum is obtained by sorting the entries of $p$ in descending order and filling the available coordinate capacities until the budget is exhausted. The cost is $O\left( m\log m \right)$, or linear after an order has been retained.

*Proof.* For maximization, negative deviations from $\widehat{t}$ cannot help because $p \geq 0$; replacing them by zero preserves feasibility and increases the objective. If an allocation uses a lower-weight coordinate while a higher-weight coordinate has capacity, transferring the smaller of the two available amounts cannot decrease the objective. Repeating this exchange gives the greedy allocation. Apply the same argument to decreases for the lower endpoint. The feasible set is convex and compact, so its continuous scalar image contains every value between the attained endpoints. ∎

This proposition does not greedily solve the general case in which both tables are uncertain. For training it suggests reporting the query-weighted error $\sum_{i}^{}p_{i}\left| t_{i} - {\widehat{t}}_{i} \right|$ when $p$ is authoritative, alongside MAE and a worst-case or coverage guarantee. A weighted training loss is a design choice; neither theorem proves that it is easier to optimize or improves generalization.

## 8.5 What finite execution probes can establish

**Lemma 8.12 (coverage plus regularity gives a uniform defect).** Fix one licensed operation, a reachable latent domain $K$, and the execution defect $g(z) = D\prime F(z) - TD(z)$ in a normed semantic space. Suppose $g$ is $G$-Lipschitz on $K$. If evaluated probes form an $r$-net of $K$ and $\parallel g\left( z_{i} \right) \parallel \leq e$ at every probe, then

$$\sup_{z \in K} \parallel g(z) \parallel \leq e + Gr.$$

*Proof.* For each $z \in K$, choose a probe with $\parallel z - z_{i} \parallel \leq r$. The triangle inequality gives $\parallel g(z) \parallel \leq \parallel g\left( z_{i} \right) \parallel + G \parallel z - z_{i} \parallel$. ∎

For example, valid Lipschitz constants for the component maps give $G \leq L_{D\prime}L_{F} + L_{T}L_{D}$. This is a sufficient estimate and may be loose. The net radius, reachable domain and constants are additional premises; average error on a test set does not supply them. They must be established for the fixed decoder version and operation whose error enters Theorem 8.1. A changed operation still requires a separate premise check.

Without regularity, any finite probes of $\lbrack 0,1\rbrack$ admit a continuous piecewise-linear defect that is zero at every probe and has a peak of one between two probes or at an unprobed endpoint. Without a range constraint its peak can be arbitrarily large. Passing finitely many execution tests therefore proves the evaluated cases, not a universal execution square. In a finite semantic interpreter complete enumeration is an alternative to geometric coverage. In a high-dimensional latent domain a small certified net can be prohibitively expensive.

## 8.6 Future computation at finite precision

The exact quotient in Theorem 8.4 is not obtained by merely declaring nearby states equivalent. Approximation requires a distance and a memory contract.

**Definition 8.13 (finite-horizon continuation pseudometric).** Fix a finite deterministic machine, an operation alphabet and a bounded metric on its observations, including a distinct failure observation. Extend every illegal transition to an absorbing failure state. For horizon $h$, let $O_{w}(s)$ be the observation after the operation word $w$, and define

$$d_{h}(s,t) = \max_{|w| \leq h}d\left( O_{w}(s),O_{w}(t) \right).$$

The empty word is included. This is a pseudometric: different states may have identical future observations. For $h \geq 1$ and every operation $o$,

$$d_{h - 1}\left( T_{o}s,T_{o}t \right) \leq d_{h}(s,t).$$

*Proof.* Each observation distance satisfies symmetry and the triangle inequality, and taking a maximum preserves them. A continuation after $o$ of length at most $h - 1$ is a word of length at most $h$ from the original state. ∎

**Theorem 8.14 (finite-precision continuation memory).** Suppose a deterministic memory with $M$ codes supports every continuation of length at most $h$ with observation error at most $\varepsilon$, uniformly over initial states. States receiving the same code satisfy $d_{h}(s,t) \leq 2\varepsilon$. Consequently, if $\mathcal{P}\left( S,d_{h},2\varepsilon \right)$ is the largest size of a set with pairwise distances strictly greater than $2\varepsilon$, then

$$M \geq \mathcal{P}\left( S,d_{h},2\varepsilon \right),\quad\quad b \geq \lceil\log_{2}\mathcal{P}\left( S,d_{h},2\varepsilon \right)\rceil.$$

for a fixed-length $b$-bit memory.

*Proof.* Starting from one code, the same continuation must give one decoded observation. If it is within $\varepsilon$ of each of the two required observations, those observations differ by at most $2\varepsilon$. Take the maximum over continuations. Every pair in a strictly separated packing must therefore receive different codes. Counting codes gives the bit bound. ∎

Pairwise closeness is not an equivalence relation: three real observations $0,a,2a$ have adjacent distances at most $a$ while the endpoints do not. A practical compressor must select actual code cells of controlled diameter and verify their transitions. The theorem is a necessary bound; it does not assert that every packing bound can be attained by a recurrent latent architecture or that approximate cells form a quotient machine.

**Corollary 8.15 (a bounded real code with adversarial noise).** Suppose codes lie in a Euclidean ball of radius $R$ in $\mathbb{R}^{d}$, and every report may be perturbed by any vector of norm at most $\eta > 0$. If $N$ initial states are pairwise more than $2\varepsilon$ apart in $d_{h}$ and all continuations must still be decoded with error at most $\varepsilon$, then

$$N \leq (1 + R/\eta)^{d}.$$

*Proof.* Two code centres at distance at most $2\eta$ admit a common corrupted report. From that report one continuation decoder cannot approximate two observations separated by more than $2\varepsilon$. The radius-$\eta$ balls about the $N$ centres are therefore disjoint and lie within the radius-$(R + \eta)$ ball. Comparing Euclidean volumes proves the claim. ∎

This bound states its precision assumption explicitly. It is not a limit for noiseless real numbers with unbounded precision, a stochastic-noise capacity theorem or an estimate of cortical storage capacity. Together with Theorem 8.9 it distinguishes memory that preserves many future tasks from a representation that only has low average present-table error.

# 9 Horizontal compatibility has a quantitative but limited role

## 9.1 Data spaces and overlap maps

**Definition 9.1 (a finite horizontal audit).** Fix a finite context graph. At vertex $i$ place a finite-dimensional inner-product data space $V_{i}$, and at edge $e = ij$ an overlap space $V_{e}$ with linear maps $\rho_{i,e}:V_{i} \rightarrow V_{e}$ and $\rho_{j,e}:V_{j} \rightarrow V_{e}$. These define a cellular sheaf on the graph. After fixing orientations, units and positive audit weights, form the dimensionless coboundary

$$(Bz)_{e} = \sqrt{w_{e}}\,\left\lbrack \rho_{j,e}z_{j} - \rho_{i,e}z_{i} \right\rbrack,\quad\quad L = B^{*}B.\quad\quad\ \ \ \ (11)$$

Its compatible sections are $\ker B$. If higher-dimensional overlap cells are included, their restriction diamonds must commute for the coboundaries to form a cochain complex. A learned collection of arbitrary pairwise maps is not automatically such a higher-dimensional sheaf. A probabilistic marginal-consistency diagram also need not satisfy unique gluing; the linear audit here makes no such claim about arbitrary probability tables.

**Theorem 9.2 (spectral repair bound).** Suppose $B \neq 0$ and let $\lambda_{+}$ be the smallest positive eigenvalue of $L$. With $P$ the orthogonal projection onto $\ker B$,

$$\parallel z - Pz \parallel \leq \frac{\parallel Bz \parallel}{\sqrt{\lambda_{+}}}.\quad\quad\ \ \ \ (12)$$

The constant is sharp. For a linear decoded quantity $Hz$, replacing $z$ by $Pz$ changes it by at most $\parallel H \parallel \, \parallel Bz \parallel /\sqrt{\lambda_{+}}$.

*Proof.* Expand $z - Pz$ in orthonormal eigenvectors with positive eigenvalues. Its squared residual is $\langle z - Pz,L(z - Pz)\rangle \geq \lambda_{+} \parallel z - Pz \parallel^{2}$. An eigenvector with eigenvalue $\lambda_{+}$ attains equality. The decoder statement follows from the operator norm inequality. ∎

This standard spectral estimate is a direct application of cellular-sheaf Laplacian theory (Hansen & Ghrist, 2019). It is a certificate of representational repair, not a causal identification theorem. If $B = 0$, every section is already compatible and the distance is zero; no positive spectral gap is available or required.

**Corollary 9.3 (compatible errors survive the audit).** An error lying in $\ker B$ is invisible to the overlap residual and need not be invisible to the task decoder or causal checker.

*Proof.* For $v \in kerB$, $B(z + v) = Bz$. If $Hv \neq 0$, the decoded quantity changes. In particular a constant wrong scalar on every vertex of a connected constant sheaf has zero residual. ∎

On a three-vertex cycle with identity restriction maps, the positive gap is $3$. The section $(1, - 1,0)$ has squared residual $6$ and squared distance $2$, attaining (12). Multiplying every audit row by $1/100$ changes the squared residual to $3/5000$ and the gap to $3/10000$, leaving the certified distance unchanged. A raw residual threshold without its map scale is therefore not a portable guarantee. These are exact spectral identities with a floating-point eigenvalue cross-check.

![Left: row scaling makes the audit residual arbitrarily small while the normalized repair bound and distance stay fixed. Right: the two-state bypass example passes both observed training cases and fails both altered-state cases. This is a finite counterexample, not a trained-model experiment.](./media/image2.png){width="6.4in" height="2.4510640857392825in"}

**Figure 2 Compatibility and decoded execution require separate tests**\
Left: row scaling makes the audit residual arbitrarily small while the normalized repair bound and distance stay fixed. Right: the two-state bypass example passes both observed training cases and fails both altered-state cases. This is a finite counterexample, not a trained-model experiment.

**Proposition 9.4 (repair allocates trust; it does not locate errors).** In the adjustment audit, let the overlap map send $T_{0}$ to its $Z$-marginal and compare it with $T_{1}$, so the residual is $r(z) = \sum_{x}^{}T_{0}(x,z) - T_{1}(z)$. Weight every $T_{0}$ coordinate by $1$ and every $T_{1}$ coordinate by $\alpha > 0$. The nearest compatible section in this weighted norm is

$$T_{1}\prime(z) = T_{1}(z) + \frac{r(z)}{2\alpha + 1},\quad\quad T_{0}\prime(x,z) = T_{0}(x,z) - \frac{\alpha\, r(z)}{2\alpha + 1}.\quad\quad\ \ \ \ (16)$$

Consequently, a slip $\delta$ placed in $T_{1}$ leaves the share $2\alpha/(2\alpha + 1)$ of $\delta$ in $T_{1}\prime$, and a slip $\delta$ placed in one entry of $T_{0}$ moves the share $1/(2\alpha + 1)$ of $\delta$ into $T_{1}\prime$. The two shares sum to one for every $\alpha$. With the outcome table fixed, the adjustment-answer error after repairing a $T_{1}$ slip is exactly $2\alpha/(2\alpha + 1)$ times the error before. A $T_{0}$ slip that left the answer exactly correct changes it by $T_{2}\left( z_{0} \right)\,\delta/(2\alpha + 1)$. At $\alpha = 1$, $BB^{\mathsf{T}} = 3I$, so every positive eigenvalue of the audit Laplacian equals $3$ and (12) holds with equality for every table vector.

*Proof.* The constraint couples only the two $T_{0}$ entries and the $T_{1}$ entry of one stratum, so strata decouple. Minimise $\alpha(c\prime - c)^{2} + (a\prime - a)^{2} + (b\prime - b)^{2}$ subject to $a\prime + b\prime = c\prime$ with a Lagrange multiplier to obtain (16). Substituting $r = - \delta$ or $r = \delta$ gives the shares; the answer $\sum_{z}^{}T_{2}(z)T_{1}(z)$ is linear in $T_{1}$. For the spectral statement, each row of $B$ has two entries $+ 1$ and one $- 1$ on disjoint coordinates. ∎

In this two-table setup, selecting weights that favor the correct table requires external trust information. A failed overlap alone does not locate the faulty table; an independent value certificate can supply such information. The linear audit also omits affine normalization, which every repaired joint-table slip in this example violates. A repair must therefore state both its trust assumptions and its feasibility constraints.

## 9.2 Learning compatible coordinates

The horizontal loss in (4) is useful once observation maps and units are fixed. It can encourage shared representations to agree and reduce the repair term in (12). The operation loss supplies a separate validity signal. A zero residual can be correct evidence of agreement while the shared proposition is wrong, as Proposition 4.1 already demonstrated for adjustment tables.

Learning all maps and all representations from this loss alone permits trivial solutions: every representation or every restriction map can vanish. Preventing collapse needs independently verified decoding targets, declared coordinate scales and constraints on the admissible map family. Restrictions between fixed semantic coordinates can be implemented exactly; restrictions between learned features require their own abstraction tests. Distinct hypotheses or causal regimes remain separate branches until a stated map relates them. Averaging incompatible branches does not establish gluing.

## 9.3 When trusted anchors make a task observable

**Hypotheses 9.5 (a fixed linear audit with authoritative anchors).** Let $V$ be the dimensionless product data space, $B:V \rightarrow W_{B}$ its fixed horizontal audit, $C:V \rightarrow W_{C}$ a fixed map of independently trusted measurements, and $H:V \rightarrow W_{H}$ the task readout. All three maps are linear and all spaces are finite dimensional with specified inner products. Assume that a true state $z_{*}$ exists with $Bz_{*} = 0$ and $Cz_{*} = b$. The anchors $b$ are authoritative for this theorem; agreement among the audited records alone does not establish their truth. Set $Qz = (Bz,Cz)$.

**Theorem 9.6 (task observability from compatibility and anchors).** Under Hypotheses 9.5, there is a finite constant $\Gamma$ such that, for every $z \in V$,

$$\parallel H\left( z - z_{*} \right) \parallel \leq \Gamma\left( \parallel Bz \parallel^{2} + \parallel Cz - b \parallel^{2} \right)^{1/2}$$

if and only if

$$\ker B \cap \ker C \subseteq \ker H.$$

The smallest constant is $\Gamma = \parallel HQ^{\dagger} \parallel_{2 \rightarrow 2}$, where the dagger denotes the Moore-Penrose inverse in the declared inner products.

*Proof.* Put $v = z - z_{*}$. The combined residual is $Qv$. If a vector lies in $\ker Q$ but not in $\ker H$, its residual is zero and its task error is nonzero; no finite bound exists. Conversely, if $H$ vanishes on $\ker Q$, orthogonal decomposition gives $H = HQ^{\dagger}Q$. Hence $\parallel Hv \parallel \leq \parallel HQ^{\dagger} \parallel \parallel Qv \parallel$. For sharpness, $Q^{\dagger}$ vanishes on $(imQ)^{\bot}$, so the norm of $HQ^{\dagger}$ is attained on $imQ$ unless it is zero. Every vector in that image is $Qv$ for some $v$, giving equality in the best-constant problem. The zero case has best constant zero. ∎

This is a finite-dimensional factorization and observability criterion applied to the ADC audit. It supplies a task-error certificate relative to trusted semantics, rather than turning horizontal agreement into causal identification. A wrong graph, false anchor or incorrect readout remains an external error. Scaling audit or anchor rows changes $Q$ and its best constant together; a smaller raw residual alone has no invariant meaning.

**Corollary 9.7 (whole-state recovery is stronger than task recovery).** Taking $H = I$ gives a finite state-error bound exactly when $Q$ is injective. In that case the best constant is $1/\sigma_{\min}(Q)$. A task can be observable when $Q$ is not injective, provided every remaining null direction is invisible to $H$.

*Proof.* For $H = I$, the kernel condition says $\ker Q = 0$, and the norm of $Q^{\dagger}$ is the reciprocal of its least singular value. The general statement is Theorem 9.6. ∎

For the three-vertex cycle of Section 9.1 with identity restrictions, $\ker B$ is the constant-vector direction. The anchor $Cz = z_{1}$ removes it. If $Hz = z_{3}$, then

$$Q^{\mathsf{T}}Q = \begin{pmatrix}
3 & - 1 & - 1 \\
 - 1 & 2 & - 1 \\
 - 1 & - 1 & 2
\end{pmatrix},\quad\quad\Gamma^{2} = 5/3.$$

Thus exact agreement together with one correct coordinate fixes the task value; approximate agreement and anchor error control it with constant $\sqrt{5/3}$. With no anchor, the constant wrong section is still invisible. This exact scalar example does not treat the coordinates as probabilities.

**Theorem 9.8 (minimum repair that preserves trusted coordinates).** Partition coordinates into fixed trusted coordinates $x_{T}$ and adjustable coordinates $x_{U}$, write $B = \left( B_{T},B_{U} \right)$, and let $W_{U}$ be positive definite. A correction with $\delta_{T} = 0$ and $B(x + \delta) = 0$ exists exactly when $r = Bx \in imB_{U}$. When feasible, the unique correction minimizing $\delta_{U}^{\mathsf{T}}W_{U}\delta_{U}$ is

$$\delta_{U} = - W_{U}^{- 1}B_{U}^{\mathsf{T}}(B_{U}W_{U}^{- 1}B_{U}^{\mathsf{T}})^{\dagger}r.$$

*Proof.* Substitute $y = W_{U}^{1/2}\delta_{U}$. The constraint is $B_{U}W_{U}^{- 1/2}y = - r$. It is feasible precisely under the image condition. The minimum Euclidean-norm solution is the pseudoinverse solution. The identity $A^{\dagger} = A^{\mathsf{T}}\left( AA^{\mathsf{T}} \right)^{\dagger}$ gives the displayed expression. Strict convexity gives uniqueness. ∎

For the scalar cycle, the input $(2,0,0)$ projects without anchors to $(2/3,2/3,2/3)$. Fixing the authoritative first coordinate at two instead gives $(2,2,2)$. The first projection is the nearest agreement; the second respects the external trust premise. If the purported anchor is false, neither theorem repairs that premise.

The formula concerns a linear audit in its ambient vector space. Nonnegativity, normalization and other feasibility constraints must be included separately. With a nonempty closed convex feasible set, the coercive, strictly convex weighted repair still has a unique minimizer; the displayed pseudoinverse formula applies only if its candidate satisfies those added constraints. In particular, a table can be horizontally compatible yet fail probability normalization, as the inherited census demonstrates.

# 10 Training and replay as controlled information acquisition

## 10.1 The teacher corpus is an adaptive archive

A teacher can supply many traces for one easy graph and few for a rare difficult graph. A verifier can then inspect only a selected subset. Even perfect labels on inspected records do not make that archive representative of a declared training population. Ghosh (2026a, 2026c, 2026e) develops this sampling distinction for adaptive optimisation; the same elementary identity applies to a finite record universe.

**Lemma 10.1 (proposal and inspection correction).** Let a finite universe $\Omega$ have fixed reference probabilities $\mu(\omega)$. Before attempt $t$, choose a predictable proposal $q_{t}(\omega) > 0$ wherever $\mu(\omega) > 0$. After drawing $\omega_{t}$, choose its inspection probability $p_{t}\left( \omega_{t} \right) > 0$ before observing the expensive inspection result. Let $I_{t}$ be its inclusion indicator with the declared conditional mean. For a fixed bounded function $f$,

$$\mathbb{E}\left\lbrack \frac{I_{t}\mu\left( \omega_{t} \right)f\left( \omega_{t} \right)}{q_{t}\left( \omega_{t} \right)p_{t}\left( \omega_{t} \right)}\, \middle| \,\mathcal{F}_{t - 1} \right\rbrack = \sum_{\omega \in \Omega}^{}\mu(\omega)f(\omega).\quad\quad\ \ \ \ (13)$$

*Proof.* Conditional on the history, sum first over the inspection indicator and then over the draw. Its factors $p_{t}$ and $q_{t}$ cancel the denominators. ∎

For validity indicator $V(\omega)$, (13) applies separately to $Vf$ and $V$. Under fixed positive joint coverage bounds, bounded martingale differences give convergence of their averages to the reference integrals. If the limiting valid mass is positive, the ratio converges to the reference expectation conditional on validity. The finite-sample self-normalized ratio is generally biased; the identity is for the unnormalized integrals. A generated text sequence's proposal probability is useful only if it is actually available under the stated sampling procedure. An arbitrary inaccessible teacher API does not supply a computable correction simply by producing text.

In the finite illustration, the reference mean is $7/4$, while the normalized mean among uncorrected inspected records is $22/25$. Applying both corrections recovers $7/4$ in expectation. This verifies the sampling identity; it is not a claim that importance weighting alone gives a low-variance neural training algorithm.

## 10.2 Error budgets for a continuing harness

Exact primitive verification has zero mathematical false acceptance under its premises. Other components, including statistical tests and learned evaluators, need an explicit failure budget. High empirical accuracy on a fixed benchmark does not by itself supply that budget.

**Theorem 10.2 (conditional error spending).** Let $E_{t}$ be a false accepted declaration at attempt $t$. Suppose $\Pr\left( E_{t} \mid \mathcal{F}_{t - 1} \right) \leq \delta_{t}$, with $\delta_{t}$ predictable and $\sum_{t \geq 1}^{}\delta_{t} \leq \delta$ almost surely. Then the probability of any false accepted declaration, including before an adaptively chosen stopping time, is at most $\delta$.

*Proof.* The union bound and conditional expectation give

$$\Pr\left( \bigcup_{t}E_{t} \right) \leq \sum_{t}^{}\mathbb{E}\left\lbrack \Pr\left( E_{t} \mid \mathcal{F}_{t - 1} \right) \right\rbrack\mathbb{\leq E}\sum_{t}^{}\delta_{t} \leq \delta.$$

Stopping only removes events from this union. No independence is required. ∎

For $\delta_{t} = \delta/\left\lbrack t(t + 1) \right\rbrack$, the infinite budget sums exactly to $\delta$. At $\delta = 1/20$, the first hundred terms use $5/101$ and leave $1/2020$. These fractions check the allocation algebra, not achieved coverage of a learned judge. A conformal or confidence-sequence method must establish its own sampling and adaptation conditions before it can enter this theorem.

## 10.3 Complementary records and query-dependent retention

**Proposition 10.3 (verification value need not be submodular).** A query-specific information objective can assign zero one-step worst-case benefit to either of two reports and positive benefit to their pair.

*Proof.* Let $q \in \Delta_{3}$ and target $q_{1}$. Allow exact reports $q_{1} + q_{2}$ and $q_{2}$. Each alone leaves a fibre with query width one: the first cannot distinguish simplex vertices 1 and 2, and the second cannot distinguish vertices 1 and 3. Their pair gives $q_{1}$ by subtraction, so worst remaining width is zero. The information gains on the empty set, each singleton and the pair are $0,0,0,1$, violating diminishing returns. ∎

This reproduces the complementary-channel example of Ghosh (2026b) in the training-memory setting. The maps are legitimate observation channels; their availability as interventions in an application must be separately specified. It does not refute submodularity of other objectives. For replay, it suggests evaluating bundles of mutually informative records rather than stopping whenever no single record changes the present answer. No optimal general bundle-selection algorithm follows from this counterexample.

## 10.4 Soft priorities follow hard validity

Among records that meet the intended admission contract, a priority can trade verification cost, continuation coverage, representation repair and query-memory precision. The units must first be normalized. A bounded loss $\mathcal{l}$ and reference $\mu$ give a preference $p_{\beta} \propto \mu e^{- \beta\mathcal{l}}$. This is a sampling preference over records, not a probability that their claims are true. A hard validity or feasibility condition remains a separate gate.

**Proposition 10.4 (stability under priority error).** Let two normalized preferences have the same reference and dimensionless log-weight difference $u$ with oscillation $osc(u) = supu - infu = d < \infty$. Then

$$TV(p,p') \leq tanh(d/4).\quad\quad\ \ \ \ (14)$$

The bound is sharp, and a constant shift in $u$ has no effect.

*Proof.* Put $g = e^{u} \in \lbrack m,M\rbrack$ and $s = \mathbb{E}_{p}g$. Convexity bounds the expected positive deviation by the endpoint distribution with the same mean, giving $TV(p,p') \leq (M - s)(s - m)/\left\lbrack s(M - m) \right\rbrack$. Its maximum over $s \in \lbrack m,M\rbrack$ occurs at $s = \sqrt{mM}$ and equals $\left( \sqrt{M} - \sqrt{m} \right)/\left( \sqrt{M} + \sqrt{m} \right) = tanh(d/4)$. A two-point reference realizing that mean attains equality. Normalization cancels constant shifts. ∎

This is the error-oscillation principle used in the companion fusion work (Ghosh, 2026f), specialized to replay priorities. With weights $1/4$ and $4$ and reference masses $4/5$ and $1/5$, the exact total variation is $3/5$, attaining the bound. Preference stability does not establish validity, and a stable sampler can consistently emphasize the wrong target.

The joint-limit and normal-geometry analysis in Ghosh (2026g) supplies a further scheduling caution: changing retrieval noise and inverse temperature together can select a different limit from changing them in succession. Nothing in that result identifies an optimal neural curriculum. It motivates freezing the intended population, units and schedule before interpreting a change in the selected training records.

**Table 6 Connections to the related research programme**

  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Paper**                                       **Ingredient used here**                              **Scope retained**
  ----------------------------------------------- ----------------------------------------------------- -----------------------------------------------------------------
  ADE for adaptive search                         Predictable proposals and logged evaluated states     Retrieval is distinct from target sampling

  ADC with sequential evidence                    Response fibres, memory ranks and noisy recovery      Fixed model and declared query family

  Certified cache and temperature reuse           Versioned reuse and joint observation coverage        A cache hit requires a matching contract

  Dependency preserving temporal computation      Shared variables, clocks and interval dependence      Token order does not supply physical causation

  Interval fitness and robust generalized Bayes   Loss preferences and sampling corrections             Preference is distinct from observation likelihood

  Interval Pareto certificates                    Hard admissibility and separate preference channels   Scalar preference cannot certify validity

  Joint limits and normal geometry                Coupled schedule limits                               No automatic transfer of geometric exponents to neural learning
  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------

![Left: expected record values under the reference, uncorrected inspected archive and corrected estimator. Right: worst remaining query width for no report, either individual report and their pair. These calculations illustrate distinct sampling and information obligations.](./media/image3.png){width="6.4in" height="2.3829790026246718in"}

**Figure 3 Selection bias and complementary evidence in finite examples**\
Left: reference, inspected and corrected expected record values. Right: remaining query width for no report, either report and their pair. Exact finite examples.

# 11 Neuroscience constrains an interpretation

## 11.1 Replay as selective access

Mattar and Daw (2018) propose a normative account in which memory access is prioritized by the improvement in future decisions, balancing expected use with the gain from updating a state. Their spatial-learning simulations connect this utility to observed replay patterns. This supports a functional question for the present architecture: which retained transition is useful for the next task? It does not establish that hippocampal sequences carry operation certificates or solve the optimization programmes above.

Proposition 10.3 adds a limitation to a purely myopic interpretation. Two retained observations can jointly preserve a future causal contrast even when neither has a one-step worst-case benefit. A replay policy for a known query family may therefore need a bundle value. The mathematical claim concerns a stated information objective; whether biological replay prioritizes such bundles is a separate hypothesis.

## 11.2 Evidence for selective consolidation

Chang et al. (2025) recorded hippocampal populations and pupil dynamics in naturally sleeping mice. Recent and older experience replay preferentially occupied different non-REM pupil substates. Closed-loop disruption of ripples in the contracted-pupil substate impaired recent-memory recall, while the compared disruption in dilated-pupil substates did not. These findings motivate distinct consolidation schedules for recent and established material. They do not show that sleep alternates between the particular loss terms in (4).

Denis et al. (2026) used human EEG and a sleep-versus-wake memory design to identify encoding activity associated with subsequent retention across sleep. Their tagging-related theta response was related to later slow-oscillation--spindle coupling and memory performance. This supports the study of an encoding-time retention tag. It does not identify a logical certificate as the content of that tag, nor establish the sufficiency of theta activity for preserving a particular causal query.

The engineering interpretation is to retain different metadata at encoding: context identity, verified claims, unresolved obligations and anticipated query use. Offline consolidation can then choose what to replay, recheck and compress. In this interpretation the retained object may be a sufficient set of consequences rather than a verbatim transcript. Theorem 8.4 states a finite exact criterion for that replacement; Proposition 8.6 states one precision cost. Neither is presently a neural mechanism.

## 11.3 Context selection through thalamocortical interaction

Rikhye et al. (2018) studied mice switching between cueing contexts. Their results distinguish prefrontal cue and rule representations from mediodorsal-thalamic activity involved in context switching, including maintaining relevant representations and suppressing irrelevant ones. This motivates a context-indexed routing role: the same stored computation can be applicable in one task context and unavailable in another. It provides no evidence that mediodorsal thalamus computes sheaf restrictions or performs symbolic proof checking.

Anatomical laminae are not identified with ASE's arbitrary layer count. Hippocampal replay time is not the physical clock of an event described in a reasoning problem. A decoder intervention tests the proposed computational representation, while neural perturbations test a biological mechanism. Both need to preserve the intended comparison context before their effects can be interpreted.

## 11.4 Falsifiable functional hypotheses

**H1 (complementary replay).** After subjects learn both channels in a complementary-evidence task, replay or retrieval should depend on their joint relevance to a future query, beyond individual prediction error. Compare a paired-channel condition with matched single-channel and redundant-channel controls, keeping exposure, reward and task difficulty controlled. Freeze a behavioural or neural interaction statistic before data collection. A confidence interval entirely in the opposite direction to the specified positive interaction refutes the prediction; an interval spanning zero is inconclusive.

**H2 (context-dependent reuse).** Reusing a learned relation after a task-context change should depend on whether the original premises still apply. A controlled task can change the relevant conditioning variable while retaining superficial cues and rewards. The prediction is an increase in context-appropriate routing and suppression of stale reuse after learning, beyond a cue-only model. Prespecify a minimum positive held-out interaction; a confidence interval whose upper endpoint falls below that minimum refutes this prediction. A thalamic mechanism would require additional neural measurements or interventions.

**H3 (retention follows future computation).** When two groups have matched present-answer performance but different future operation requirements, later retention should preserve the information needed for those operations. The swap example in Section 8 provides a minimal task logic. Compare query-preserving compression with transcript length, usage and surprise baselines at matched resources. A reliable advantage for the opposite retention pattern refutes the proposed direction; equivalence within a declared sensitivity margin would also contradict a prespecified nonzero effect.

No new animal, human, sleep or neural-recording experiment is reported. The primary findings above constrain a proposed functional mapping and supply tests; they do not prove that the brain implements ADC.

## 11.5 Recent evidence and the limits of a cortical mapping

He et al. (2026) recorded hippocampal and cortical intracranial activity in patients performing compositional inference tasks. Ripple-associated replay coordinated with medial prefrontal representations of inferred configurations. This supports studying whether replay reorganizes reusable components rather than merely repeating complete episodes. It does not identify a typed operator, an authoritative anchor or an execution certificate in those recordings. The appropriate ADC analogy is a testable relation between replay content, available premises and later transfer.

Chakravarthula et al. (2026) combined human task fMRI with activity-flow modeling to study how connectivity geometry transforms representations. Their analyses associate lower-dimensional connectivity with compression and higher-dimensional connectivity with expansion and conjunctive coding. This motivates measuring which future distinctions survive compression, as formalized by $d_{h}$, instead of treating a lower-dimensional representation as automatically sufficient. Their measurements do not establish the deterministic continuation contract or the adversarial-noise assumptions of Corollary 8.15.

Replay also cannot be assigned to a single mandatory biological route. Thompson et al. (2026) found striatal procedural replay after complete bilateral hippocampal lesions in mice. Its relationship with learning supports parallel replay mechanisms. An ADC implementation may similarly distribute reusable procedures and episodic records across stores, but that engineering decomposition does not follow anatomically from the experiment.

**H4 (trusted context constrains transfer).** In a compositional inference task, provide independently reliable evidence for one component while other mutually agreeing components conflict with it. The prediction is that later transfer will track the reliable component more than an otherwise matched, explicitly unreliable cue, with matched exposure, reward and present-task accuracy. Freeze the reliability manipulation, a positive minimum transfer interaction and its confidence construction before data collection. An upper confidence endpoint below that minimum refutes the specified prediction. Neural tests should ask whether replay or routing predicts this interaction beyond surprise and reward. Such a finding would support a functional trust constraint, not show that neurons evaluate a pseudoinverse or execute do-calculus.

The mathematical distinction remains useful even if every proposed neural mapping is rejected: overlap residuals measure agreement, independent anchors constrain semantic error, and future-task tests evaluate the information retained by compression. Biological clocks, token order, reasoning-step order and ASE depth remain separate indices.

# 12 An AI harness that can train from its own computations

## 12.1 Separate execution from training

Agent Lightning already separates agent execution from training and decomposes trajectories into transitions through a unified interface (Luo et al., 2025). Transition decomposition itself is therefore not a novelty claim here. The added contract is to bind a transition's actual operation and operands to a declared causal interpreter, preserve explicit unresolved statuses and distinguish decoded execution from observed answer agreement.

Rosset et al. (2026) study computer-use verification with separate process and outcome signals, explicit treatment of failure causes and long-context management. Their empirical verifier is evidence that those distinctions matter in evaluated web tasks. It is not an exact verifier for our mathematical domain. Zhang et al. (2026) propose CLIFT, which reuses a learned verification bank in training and trajectory selection. Its judge-relative calibration and evaluation setting differ from exact causal validity. A claimed statistical guarantee in such a system would enter Theorem 10.2 only after its conditional or simultaneous coverage assumptions were established.

## 12.2 Authoritative state and proposed packets

**Definition 12.1 (an operation-bound packet).** A packet records the authoritative context reference, actual input-state reference, operator identifier, operand scopes, claimed result, premise evidence, arithmetic or logical certificate and claim scope. A teacher or student proposes this packet. The harness retains the authoritative problem separately and compares the bound contents before executing the admitted transition.

**Table 7 Fields checked by the reference packet interface**

  ----------------------------------------------------------------------------
  **Field**           **Required relationship**
  ------------------- --------------------------------------------------------
  Context             Exact graph, data, query, units and version match

  Input state         Matches the actual current operands

  Operation           Recognized primitive with its own semantics

  Scope               Conditioning and outcome variables match the primitive

  Premise             Adjustment and condition-deletion requirements hold

  Result              Submitted table and sum equal exact recomputation

  Unsupported claim   Returns unverified rather than an invented proof
  ----------------------------------------------------------------------------

The reference uses immutable Python dataclasses and exact fractions. It verifies two supported operations on finite positive binary DAG laws: constructing a conditional table for an admissible adjustment and deleting a condition when d-separation licenses that equality. It is deliberately smaller than the full ADC kernel. A content digest binds values but supplies neither authentication nor access control.

The new packet cases include an honestly computed table, a coincidentally equal but unlicensed deletion, a licensed deletion, changed context and units, stale operands, changed arithmetic, an unsupported operator and an invalid adjustment. Numerical mismatch and premise failure receive distinct results. A rejected premise does not assert that the reported number is false in the present model; Proposition 7.2 explains why.

## 12.3 Reuse after evidence changes

**Corollary 12.2 (reuse on a certified subset).** If an operation's claim holds on a model set $K$, a nonempty certified subset $K\prime \subseteq K$ preserves it when event meanings, query, operation and decoder semantics remain fixed. A previously attained sharp bound remains sharp if an attaining witness for each endpoint remains feasible in $K\prime$. If an endpoint was not attained, sharpness requires a separate argument, such as retained approximating sequences.

*Proof.* A universally valid claim holds on every subset. A surviving endpoint witness still attains the old endpoint, while subset inclusion prevents a wider range. Nonattainment is not covered by this witness argument. ∎

This is the evidence-refinement contract of Ghosh (2026b). An arbitrary version change does not prove inclusion. A target change can invalidate both a numerical cache and a reasoning certificate even if every input array has the same shape. Evidence refinement can release memory coordinates under (8); changes to the future query family can require additional memory instead.

## 12.4 A training and evaluation protocol

First freeze a task family with authoritative graphs, exact or statistically justified observations, query semantics and operation schemas. Generate teacher proposals with logged sampling settings. Parse the visible traces into candidate packets; preserve the original text for audit and optional explicit-step training. Admit packets according to the intended value, operation or execution claim, keeping their labels distinct. Train the operation policy and semantic decoders on accepted records. Add the sheaf residual only after units and maps are declared. Replace verbal steps progressively and test (5) on student-generated trajectories and prespecified state interventions.

Teacher activations are optional. A text-only interface supplies visible traces and tool results; the student supplies its own separator representations. Any checkpoint input must be a function of the available prefix and current observations. The verified target for that checkpoint must concern that same available state. Future answers may be labels, but cannot be supplied as checkpoint features or smuggled into its state target as already established evidence. A decrease in visible tokens does not imply a decrease in floating-point operations, sequential depth, tool calls or elapsed time; report these budgets separately.

The original D1 prediction remains a comparison between certificate-admitted and two-decimal answer-filtered training. Match accepted-record counts as well as teacher, parsing and verification budgets, and report the cost of obtaining those records. Keep the original error-ratio threshold of one half, handling a zero-error baseline separately. D3 retains the predicted factor-of-two difference in missed valid non-back-door certificates, with honest abstention separated from erroneous refutation labels.

D2 requires a narrower interpretation. Its original target of linear checkpoint mean absolute error below $0.01$ after removing half the verbal steps remains an untested readout prediction. Failure refutes that particular linear-readout claim; it does not by itself prove a shortcut. The bypass test of Proposition 8.2 and the continuation tests of Theorem 8.4 supply the additional execution comparisons.

Proposition 8.7 supplies a separate, stronger entrywise contract. At uniform radius 0.01, 45.6% of the numerically wrong finer-grid invalid-set answers lie inside the honest-table enclosure, and only 29.1% of affected queries have all such answers excluded. D2's MAE target alone does not license this enclosure. A per-context certified budget can instead use Theorem 8.9 or Proposition 8.11 where their premises apply. Graph-premise checks remain necessary even for exact value coincidences.

**D4 (operation-bound supervision).** At matched training and evaluation budgets, operation-bound records will reduce unlicensed condition-deletion proposals on held-out positive models with the same allowed graph, compared with value-only records. Freeze the proposed rate ratio at at most one half, the model family, confidence construction and minimum nonzero comparator rate in advance. A ratio interval wholly above one half refutes the prediction; one crossing the threshold is inconclusive. Final-answer accuracy, qualified failure, certificate coverage and verification cost are reported separately.

D1--D4 remain untested; D5 below adds a task-sensitive decoding comparison. Exact verification can label operations inside a declared domain, but it does not establish that a neural policy learns to propose them efficiently or generalizes to unseen structures.

## 12.5 Certificates have different version dependencies

A harness should retain a certificate dependency graph alongside its immutable operation history. An exact table certificate depends on the declared law and query. An operation certificate additionally depends on its primitive semantics and premises. A latent execution certificate depends on the actual update, decoder version, reachable domain, norm and tested or certified error contract. Changing neural weights can invalidate this last certificate while leaving a symbolic graph licence valid. The cache key must bind the dependencies of the particular claim, rather than every available byte or an underspecified task name.

Before a hit, compare immutable references and check a stated transport rule, such as certified model-set inclusion. If neither exact scope equality nor a proved implication is available, return unverified or recompute. A smaller model set preserves a valid outer interval, but sharpness needs surviving endpoint witnesses. A cached failed premise can also be reused only within its declared scope; a new graph may license the formerly forbidden step.

**Theorem 12.3 (deduplicated risk for repeated reuse).** Index distinct admitted uncertain claims by creation order. Suppose the event $E_{i}$ that claim $i$ is false in its bound scope has conditional probability at most a predictable $\delta_{i}$, with $\sum_{i}^{}\delta_{i} \leq \delta$ almost surely. Suppose every reuse preserves that scope or follows a checked implication introducing no new uncertain premise. Then any number of adaptive cache lookups has probability at most $\delta$ of using a false claim.

*Proof.* A false reused claim implies that at least one of its source claims was false at creation; valid logical implication does not make a true premise false. The event is contained in $\bigcup_{i}E_{i}$. Conditional expectation and the union bound give probability at most $\mathbb{E}\sum_{i}^{}\delta_{i} \leq \delta$. The number and adaptive timing of lookups do not enlarge this union. ∎

Repeated reuse of the same uncertain claim spends its creation risk once. It does not create independent corroboration or make that risk smaller. A new statistical premise, a changed evaluator or an unsupported scope extension needs a new valid coverage argument. Exact symbolic checks can use zero mathematical risk relative to their premises; uncertainty in data, model meaning and interpreter correctness is not removed by that convention. This is a reuse specialization of Theorem 10.2, not a calibration theorem for learned verifiers.

## 12.6 Completeness and task-sensitive evaluation

Yin et al. (2026) introduce VerifierBench for executable agent verifiers. Their evaluated verifiers often reject valid alternatives, and verifier-generated tests can share the verifier's mistaken assumptions. This reinforces the distinction between soundness and completeness in Section 7.2. ADC should test certified alternative derivations and expected abstentions alongside corruptions. Agreement between a generated checker and its own examples supplies no universal proof of either property.

**D5 (task-sensitive decoding supervision).** At matched teacher, accepted-record, model-training and verification budgets, adding an authoritative query-weighted outcome loss will reduce held-out causal-answer error compared with unweighted table MAE supervision, while keeping graph-premise checks fixed. Prespecify a relative reduction of at least 10% on a nonzero-error comparison family with concentrated stratum weights, the seed aggregation and a paired uncertainty analysis. A confidence interval for the error ratio entirely above 0.90 refutes the prediction; one crossing 0.90 is inconclusive. Report ordinary MAE, worst per-context error, certified interval width, coverage and cost separately. The mathematical bounds motivate this prediction but do not establish it.

For deployment, the harness therefore records four different observations: whether the operation was licensed, whether its arithmetic passed, whether the decoded execution contract held on the evaluated domain, and how much of the requested task was observable at the available precision. Reusing an immutable verified record can save computation. Whether its savings exceed parsing, lookup, transport and revalidation costs is an empirical latency question, to be measured separately from semantic correctness.

# 13 What the added computation establishes

## 13.1 Finite examples of Version 2

Version 2 reports that its inherited independent validator reproduced all 34 summary records and passed 36 checks. Version 3 reports recompilation of the kernel and the added census in Sections 13.2--13.7. These are inherited results: Version 4 retains their supplied outputs and logs without a fresh exhaustive or compiler rerun. No teacher model was invoked in those reported studies.

The Version 2 reference reports 16 deterministic records and 26 independent checks. Its five two-model linear programmes were compared with exact rational active-constraint enumeration; its graph primitive with direct-path d-separation on 1,586 cases. The archived report records clean-process replay. These historical claims are distinguished from the newly reproduced examples in Section 13.8. The reported spectral eigenvalue is a floating-point cross-check, not an outward-certified interval.

**Table 8 New finite verification results**

  -------------------------------------------------------------------------------------------------------------------------------------------------
  **Computation**                 **Result**                                                **Meaning**
  ------------------------------- --------------------------------------------------------- -------------------------------------------------------
  Coincident condition deletion   Value $1/2$ accepted by value check; operation rejected   Numerical agreement can hide an unlicensed rule

  Compatible witness              Required $3/4$ versus dropped $1/2$                       The failed universal deletion has a semantic witness

  Licensed deletion               Conditional table $(1/5,4/5)$ accepted                    Valid alternative operators remain available

  Continuation quotient           4 classes for future $a$; 2 for parity                    Required memory depends on future operations

  Decoded execution               Error $1/40$ equals the bound                             The finite recurrence can attain the theorem

  Horizontal repair               Squared residual $6$, gap $3$, distance squared $2$       Spectral normalization is necessary

  Selection and precision         Corrected mean $7/4$; recovery radius $1/10$              Sampling correction and memory precision are separate

  Independent verification        16 records and 26 passing checks                          Mathematical examples only
  -------------------------------------------------------------------------------------------------------------------------------------------------

These records demonstrate arithmetic and interface behaviour on their specified finite inputs. They do not estimate the error rates of a real trace parser, the faithfulness of a frontier teacher, a learned latent execution defect or a biological mechanism. The learned experiments remain necessary to assess those claims.

## 13.2 The recompiled kernel

The Version 3 source compiles the inherited C# kernel with .NET 8 and runs it unchanged. Its 34-line summary and both error files are byte-for-byte identical to the recorded Version 1 outputs. The new census is a separate entry point of the same kernel. It uses the same seeds, graph order and model draws, so its 6,144 models (3,072 per regime) are exactly those behind Tables 1 to 3. All arithmetic is exact over rationals, and public values are immutable records.

## 13.3 Do-calculus rules: licence and coincidence

For every model the census applies every instance of four operations, 2,211,840 applications per regime. *Condition deletion* replaces $P(Y \mid W,S)$ by $P(Y \mid S)$. *Rule 1* deletes an observation $Z$ from $P\left( Y \mid do(X),Z,S \right)$. *Rule 2* exchanges $do(X)$ with conditioning on $X$ in $P\left( Y \mid do(X),S \right)$. *Rule 3* deletes the action from $P\left( Y \mid do(X),S \right)$. Each application is licensed by the corresponding d-separation in the mutilated graph (Pearl, 1995) and checked numerically at both action values and every conditioning value; one such equality is a *cell*.

Soundness holds without exception: all 1,010,448 licensed applications per regime hold exactly, in all 7,143,258 of their cells. Unlicensed applications are where value and operation separate (Table 9, Figure 4A). On the hundredths grid 0.3--0.5% of them hold exactly on the sampled law; on the tenths grid 4.1--6.6%. Rule 2, the step that turns an intervention into a conditional, has the highest rate in both regimes. A value check made on one cell is weaker still: 0.9% of unlicensed Rule 2 cells hold exactly on the finer grid, and 12.2% agree to two decimals.

The last column of Table 9 asks whether a coincidence belongs to the graph or to the draw. On the hundredths grid no unlicensed pattern held in all three models of its graph, consistent with Proposition 7.6. On the tenths grid 256 graph-level patterns did, so a coarse problem generator can make an unlicensed rule appear valid across repeated draws. This is a property of the data generator, not of the graph.

**Table 9 Value coincidence versus graphical licence (every application per regime)**

  ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Operation**                 **Licensed applications**   **Unlicensed exactly equal, tenths**   **Unlicensed exactly equal, hundredths**   **Unlicensed cells equal to 2 decimals, hundredths**   **Unlicensed in all three models, tenths / hundredths**
  ----------------------------- --------------------------- -------------------------------------- ------------------------------------------ ------------------------------------------------------ ---------------------------------------------------------
  Condition deletion            150,546 of 491,520          4.5%                                   0.33%                                      4.1%                                                   68 / 0

  Rule 1 (observation)          274,080 of 737,280          4.5%                                   0.32%                                      8.4%                                                   82 / 0

  Rule 2 (action/observation)   301,110 of 491,520          6.6%                                   0.49%                                      12.2%                                                  66 / 0

  Rule 3 (action deletion)      284,712 of 491,520          4.1%                                   0.34%                                      11.2%                                                  40 / 0
  ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 13.4 Operation-bound certificates on the inherited derivations

Table 10 replays the inherited derivations with the operation recorded. The value certificate again accepts all honest derivations, no invalid set and 186 (2,268) dropped-action derivations. None of the 37,878 dropped-action steps is graph-licensed, as Proposition 7.5 requires, so the operation-bound certificate rejects every one while still accepting every honest derivation. The slipped tables of Table 2 already fail the value comparison, and the operation-bound certificate adds the premise check to it, so they remain rejected.

**Table 10 Value certificate and operation-bound certificate on the inherited derivations**

  ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Derivation**                **Cases per regime**   **Value certificate, tenths**   **Value certificate, hundredths**   **Graph licence of the stated operation**   **Operation-bound certificate**
  ----------------------------- ---------------------- ------------------------------- ----------------------------------- ------------------------------------------- ---------------------------------
  Honest, smallest valid set    37,878                 37,878                          37,878                              All valid                                   37,878

  Invalid adjustment set        161,196                0                               0                                   Premise fails                               0

  X dropped from P(y \| x, z)   37,878                 2,268                           186                                 0 licensed                                  0
  ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 13.5 Repair census

Every marginal slip of Table 2 (9,714 per regime) and a new slip of $0.01$ in the $T_{0}$ entry at the heaviest stratum and the queried action value (37,878 per regime) were repaired by the exact weighted projection, computed by a generic rational solve of the normal equations rather than by (16). Every repaired section has zero residual, and every case matches (16) and the shares of Proposition 9.4 for all three weights (Table 11). After repairing a $T_{1}$ slip, the answer is exactly right only in the 93 (856) cases where the slip had not changed it. Every repaired $T_{0}$ slip turns an exactly correct answer into a wrong one and breaks the normalisation of $T_{1}$. At $\alpha = 1$ all 47,592 cases per regime attain (12) with equality.

**Table 11 Exact weighted repair of single table slips**

  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Audit weight α on T1**   **Share of a T1 slip retained**   **Share of a T0 slip moved into T1**   **T1 slips matching (16), per regime**   **T0 slips leaving a wrong answer, per regime**
  -------------------------- --------------------------------- -------------------------------------- ---------------------------------------- -------------------------------------------------
  1/10                       1/6                               5/6                                    9,714 of 9,714                           37,878 of 37,878

  1                          2/3                               1/3                                    9,714 of 9,714                           37,878 of 37,878

  10                         20/21                             1/21                                   9,714 of 9,714                           37,878 of 37,878
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 13.6 Precision of value checks on decoded tables

For each query the honest tables of the smallest valid set are perturbed through the uncertainty set of Proposition 8.7, and every invalid set's exact answer is tested for membership (Table 12, Figure 4B). Mean widths stay close to 2.16h, within (15). Exact coincidences are excluded from these shares. At a uniform entrywise radius of 0.01, 45.6% of wrong answers lie inside the enclosure. Two-decimal rounding radius 0.005 leaves 32.9%, three decimals 8.9% and four decimals 2.1%. The least number of decimals excluding a wrong answer is 1 for 31,696 of 159,651 wrong answers, 2 for 75,376, 3 for 38,320, 4 for 10,913, 5 for 2,568, 6 for 590, 7 for 154 and 8 for 29; 5 need more than eight. The tenths grid needs at most seven. These numbers are inherited unchanged.

A decoder with this certified entrywise radius would permit the interval value check to exclude the answers outside the enclosure. Meeting D2's dataset MAE alone makes no such per-query guarantee. The graph premise rejects all graph-invalid adjustment selections, including exact numerical coincidences.

**Table 12 What a value check on decoded tables can reject**

  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Decoded precision h**   **Mean enclosure width, hundredths**   **Largest width, hundredths**   **Wrong invalid answers inside, tenths**   **Wrong invalid answers inside, hundredths**   **Queries with all wrong answers excluded, hundredths**
  ------------------------- -------------------------------------- ------------------------------- ------------------------------------------ ---------------------------------------------- ---------------------------------------------------------
  0.01 uniform              0.02162                                0.07560                         43.0%                                      45.6%                                          29.1%

  0.005                     0.01081                                0.03780                         28.0%                                      32.9%                                          41.8%

  0.0005                    0.00108                                0.00378                         4.9%                                       8.9%                                           78.0%

  0.00005                   0.00011                                0.00038                         0.7%                                       2.1%                                           93.8%
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

![Bar chart of exact coincidence rates for four operations in two grids, and a line chart of the share of wrong answers inside the decoded-table enclosure falling as precision improves.](./media/image4.png){width="6.4in" height="2.519149168853893in"}

**Figure 4 Licence, coincidence and the precision of value checks**\
Left: share of unlicensed applications that hold exactly on the sampled law, by operation and parameter grid. Right: share of numerically wrong invalid adjustment answers that lie inside the interval enclosure of the honest decoded tables, against the decoding precision h. Exact census over 6,144 models; not a trained-model experiment.

## 13.7 Validation

An independent Python program recomputes all 36 census records with integer-scaled joint laws, d-separation by explicit path enumeration with the blocking rule, the rule licences written as edge deletions, the closed form (16) instead of the generic solve, and a bit-exact replay of the parameter streams. It passes 48 checks, including licensed-application soundness for every rule. Vertex enumeration of the box-simplex polytope confirms 1,516 sampled enclosure optima per regime, and a floating-point least-squares projection agrees with the exact repair to within $2 \times 10^{- 16}$ on 186 sampled cases per regime. The census takes about eighty seconds in C#.

These are exhaustive calculations on a declared finite family. They measure how often values agree without a licence; they do not estimate how often a real teacher proposes an unlicensed step.

## 13.8 Exact examples added in Version 4

The new exact-arithmetic checker evaluates the sensitivity counterexample, a sharp greedy interval, the finite-horizon packing example, the anchor observability constant and the anchored projection. It is separate from the inherited exhaustive census and does not rerun that census, query a teacher, train a student or collect neural data. Its small finite cases check calculations in the new statements; the proofs establish their general forms.

**Table 13 Exact examples for precision and anchored compatibility**

  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Calculation**                                                      **Exact result**                                         **Scope**
  -------------------------------------------------------------------- -------------------------------------------------------- --------------------------------------------------
  Eight-cell outcome table                                             MAE $1/100$; answer error $2/25$                         Average error does not imply an entrywise radius

  Fixed $p = (3/4,1/4)$, $\widehat{t} = (1/2,1/2)$, budget $1/4$       Answer interval $\lbrack 5/16,11/16\rbrack$              Sharp for the specified $L^{1}$ uncertainty set

  Three-cycle with first-coordinate anchor and third-coordinate task   Best squared constant $5/3$                              Fixed scalar linear audit

  Input $(2,0,0)$ on that cycle                                        Free repair $(2/3,2/3,2/3)$; anchored repair $(2,2,2)$   True anchor assumed

  Eight-state bit machine, one-step horizon, error $1/4$               Packing size four; at least two bits                     Declared future output and operation family
  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

The result JSON is generated twice in clean Python processes and compared byte for byte. Package checks preserve the inherited census records unchanged and confirm the new Word equations and source paths. The updated Figure 4 label says "uniform radius" rather than identifying the census radius with D2's MAE target. No empirical rate in Sections 5 or 13.2--13.7 is newly estimated by this revision.

# 14 Limitations and remaining mathematical questions

The exact adjustment census is exhaustive over DAGs respecting one fixed five-vertex order, and random over the stated CPT grids. It is not a census of all labelled five-vertex DAGs, all mechanisms or actual teacher errors. The new operation interface covers only two primitives and finite positive binary laws. The original C# value checker remains useful for numerical certification, but it does not bind the actual textual operator that produced a coincident table; Version 3 adds that binding for adjustment and deletion.

The Version 3 census covers single actions, single binary outcomes and five events in one fixed order, with three models per graph. Its graph-level coincidence column depends on those three draws, and Proposition 7.6 is proved only for deletion. The repair analysis concerns one linear audit with diagonal weights; nonlinear audits and learned restriction maps need their own analysis. The enclosure of Proposition 8.7 assumes worst-case entrywise decoding error within a declared bound; a probabilistic decoder needs a coverage statement before it can use it.

Theorem 8.1 requires uniform defects on relevant reachable states and fixed operation semantics. Lemma 8.12 bridges finite probes only with independently justified coverage and regularity; obtaining them in a large latent domain can be expensive. The exact quotient theorem is finite. Theorem 8.14 gives a necessary finite-horizon packing bound, not an approximate quotient construction or a neural sample-complexity result. Unbounded horizons and changing tasks require new analysis. A successful probe may expose information that the policy never uses; a failed probe need not prove its absence.

The spectral and observability results assume finite-dimensional linear maps, declared inner products and compatible units. Theorem 9.6 depends on independently correct anchors and a correct task readout; it cannot establish them from agreement. Theorem 9.8 enforces a linear audit, while probability and physical feasibility need additional constraints. Learned maps, nonlinear gluing and changing covers need separate guarantees. Response constraints across independent districts may be multilinear, and the LP recovery theorem does not silently extend to them or to arbitrary stochastic noise.

The sampling identity assumes known proposal and inspection probabilities. A useful teacher whose sampling law is unavailable can still generate demonstrations, but those demonstrations do not automatically estimate a declared reference population. Conditional error budgets are assumptions to establish for each approximate verifier, not consequences of calling a system calibrated. Task generation, parsing, data versioning and real-world intervention meaning remain external obligations.

The cited neuroscience supports selective memory processing, compositional and procedural replay, context routing and representational transformations. It does not identify anatomical layers with ASE depth or neural rhythms with exact certificates. Recent systems-level findings motivate tests of future-task sufficiency and reliable-context transfer; D1--D5 and H1--H4 remain predictions rather than measured benefits.

# 15 Conclusion

Long teacher traces can supply proposed transitions, intermediate facts and alternative derivations for a causal interpreter. Value agreement, an operation licence and realized latent execution remain different claims. The inherited census shows why graph premises cannot be replaced by numerical coincidence. The new precision analysis shows why mean checkpoint accuracy cannot be promoted to a per-query error guarantee.

Horizontal sheaf structure supports a quantitative audit once spaces, units and maps are fixed. Theorem 9.6 identifies exactly when independent anchors make a linear task observable despite the audit's blind directions; Theorem 9.8 gives a repair that preserves trusted coordinates. Future continuations, rather than transcript length alone, determine the distinctions a finite-precision memory must retain. Scoped certificate reuse can avoid recomputation without multiplying the same claim's statistical risk. These contracts define what to verify and measure; neural learning gains, latency savings and biological implementations remain open empirical questions.

# Appendix A Reproduction and claim status

The Version 4 source bundle contains the authoritative supplied Version 3 Word file, its available source archive, the new additions, the self-contained builder, the exact-example checker and its result JSON. From the bundle root, run `python check_v4.py` to regenerate the new exact examples and `python build_v4.py` to rebuild the updated Word paper. The builder uses the included Version 3 file directly. It requires Python with python-docx, lxml, NumPy and Matplotlib, plus Pandoc; the checker uses the Python standard library. The generated Markdown is an accessible text companion. Render the rebuilt Word file before relying on its pagination.

The original Version 3 source is retained in `inherited_v3/`. In that directory, `dotnet run -c Release --project kernel -- out_v3 --v3` runs the expanded .NET 8 census, and `python validate_v3.py cs_v3.txt validation_v3.json` regenerates its independent checks. Those commands describe the inherited reproduction path; this revision does not claim to have rerun them. Some earlier Version 2 build inputs referenced by the inherited notes are absent from the supplied archive, so those historical instructions do not constitute the current build contract. Their existing logs are historical results rather than new evidence.

The immutable packet interface, exact rational kernel and original result files remain available for inspection. The current revision adds proof-level observability, finite-precision and reuse contracts. Its small exact examples are reproduced from the new checker; inherited exhaustive results retain their original provenance. No compiler rerun, teacher query, student training or biological experiment is claimed for Version 4.

**Claim status.** Formal results are proved under their stated hypotheses. An authoritative anchor is an assumption to justify outside the horizontal residual. A uniform error bound or a coverage guarantee is an additional certificate, not the consequence of average readout accuracy. D1--D5 and H1--H4 are untested predictions. Exact packet checking remains relative to correct semantics and a correct primitive interpreter; a learned checker requires its own error and completeness assessment.

# References

Chakravarthula, L. N. C., Ito, T., Tzalavras, A., & Cole, M. W. (2026). Network geometry shapes the transformation of task representations across the human cortex. *Nature Neuroscience*. Advance online publication. https://doi.org/10.1038/s41593-026-02486-8

Chang, H., Tang, W., Wulf, A. M., Nyasulu, T., Wolf, M. E., Fernandez-Ruiz, A., & Oliva, A. (2025). Sleep microstructure organizes memory replay. *Nature, 637*, 1161--1169. https://doi.org/10.1038/s41586-024-08340-w

Chen, Y., Benton, J., Radhakrishnan, A., Uesato, J., Denison, C., Schulman, J., Somani, A., Hase, P., Wagner, M., Roger, F., Mikulik, V., Bowman, S. R., Leike, J., Kaplan, J., & Perez, E. (2025). *Reasoning models don't always say what they think*. arXiv. https://arxiv.org/abs/2505.05410

DeepSeek-AI. (2025). DeepSeek-R1 incentivizes reasoning in LLMs through reinforcement learning. *Nature, 645*, 633--638. https://doi.org/10.1038/s41586-025-09422-z

Denis, D., Chen, Z., Kaur, M., Clayden, B., Schreiner, T., & Cairney, S. A. (2026). Theta oscillations tag episodic memories for sleep-dependent consolidation. *PLOS Biology, 24*(8), e3003938. https://doi.org/10.1371/journal.pbio.3003938

Geiger, A., Lu, H., Icard, T., & Potts, C. (2021). Causal abstractions of neural networks. *Advances in Neural Information Processing Systems, 34*. https://papers.nips.cc/paper/2021/hash/4f5c422f4d49a5a807eda27434231040-Abstract.html

Ghosh, D. (2026a). *Autoregressive Diffusion Evolution for Adaptive Search and Gibbs Estimation*. https://doi.org/10.13140/RG.2.2.12688.57603

Ghosh, D. (2026b). *Autoregressive Do Calculus with Sequential Evidence*. https://doi.org/10.13140/RG.2.2.24386.75209

Ghosh, D. (2026c). *Certified Cache and Temperature Reuse for Selective Adaptive Optimisation*. https://doi.org/10.13140/RG.2.2.15650.80326

Ghosh, D. (2026d). *Dependency Preserving Temporal Causal Computation: Horizontal sheaves, interval ranges and temporal smoothing*. https://doi.org/10.13140/RG.2.2.33732.18568

Ghosh, D. (2026e). *Interval Fitness and Robust Generalized Bayes for Adaptive Optimisation*. https://doi.org/10.13140/RG.2.2.36412.60806

Ghosh, D. (2026f). *Interval Pareto Certificates and Evidence Gated Fusion for Adaptive Optimisation*. https://doi.org/10.13140/RG.2.2.35121.54889

Ghosh, D. (2026g). *Joint Limits and Normal Geometry in Adaptive Objective Fusion*. https://doi.org/10.13140/RG.2.2.22564.85121

Hansen, J., & Ghrist, R. (2019). Toward a spectral theory of cellular sheaves. *Journal of Applied and Computational Topology, 3*, 315--358. https://doi.org/10.1007/s41468-019-00038-7

Hao, S., Sukhbaatar, S., Su, D., Li, X., Hu, Z., Weston, J., & Tian, Y. (2024). *Training large language models to reason in a continuous latent space*. arXiv. https://arxiv.org/abs/2412.06769

He, L., Wang, X., Zhang, J., Xiao, Z., Hu, X., Schwartenbeck, P., Bakermans, J., Behrens, T., & Liu, Y. (2026). Human hippocampal ripples coordinate planning sequences and compositional representations in neocortex. *Nature Neuroscience, 29*, 1711--1721. https://doi.org/10.1038/s41593-026-02291-3

Lightman, H., Kosaraju, V., Burda, Y., Edwards, H., Baker, B., Lee, T., Leike, J., Schulman, J., Sutskever, I., & Cobbe, K. (2024). Let's verify step by step. *International Conference on Learning Representations*. https://proceedings.iclr.cc/paper_files/paper/2024/hash/aca97732e30bcf1303bc22ac3924fd16-Abstract-Conference.html

Luo, X., Zhang, Y., He, Z., Wang, Z., Zhao, S., Li, D., Qiu, L. K., & Yang, Y. (2025). *Agent Lightning: Train ANY AI agents with reinforcement learning*. arXiv. https://arxiv.org/abs/2508.03680

Mattar, M. G., & Daw, N. D. (2018). Prioritized memory access explains planning and hippocampal replay. *Nature Neuroscience, 21*, 1609--1617. https://doi.org/10.1038/s41593-018-0232-z

Meek, C. (1995). Strong completeness and faithfulness in Bayesian networks. *Proceedings of the 11th Conference on Uncertainty in Artificial Intelligence*, 411--418. https://arxiv.org/abs/1302.4973

Pearl, J. (1995). Causal diagrams for empirical research. *Biometrika, 82*(4), 669--688. https://doi.org/10.1093/biomet/82.4.669

Pearl, J. (2009). *Causality: Models, reasoning, and inference* (2nd ed.). Cambridge University Press.

Perković, E., Textor, J., Kalisch, M., & Maathuis, M. H. (2015). A complete generalized adjustment criterion. *Proceedings of the 31st Conference on Uncertainty in Artificial Intelligence*. https://arxiv.org/abs/1507.01524

Rikhye, R. V., Gilra, A., & Halassa, M. M. (2018). Thalamic regulation of switching between cortical representations enables cognitive flexibility. *Nature Neuroscience, 21*, 1753--1763. https://doi.org/10.1038/s41593-018-0269-z

Ross, S., Gordon, G., & Bagnell, D. (2011). A reduction of imitation learning and structured prediction to no-regret online learning. *Proceedings of Machine Learning Research, 15*, 627--635. https://proceedings.mlr.press/v15/ross11a.html

Rosset, C., Sharma, P., Zhao, A., Gonzalez-Fernandez, M., & Awadallah, A. (2026). *The art of building verifiers for computer use agents*. arXiv. https://arxiv.org/abs/2604.06240

Schulman, J., Wolski, F., Dhariwal, P., Radford, A., & Klimov, O. (2017). *Proximal policy optimization algorithms*. arXiv. https://arxiv.org/abs/1707.06347

Shao, Z., Wang, P., Zhu, Q., Xu, R., Song, J., Bi, X., Zhang, H., Zhang, M., Li, Y. K., Wu, Y., & Guo, D. (2024). *DeepSeekMath: Pushing the limits of mathematical reasoning in open language models*. arXiv. https://arxiv.org/abs/2402.03300

Shpitser, I., VanderWeele, T., & Robins, J. M. (2010). On the validity of covariate adjustment for estimating causal effects. *Proceedings of the 26th Conference on Uncertainty in Artificial Intelligence*. https://arxiv.org/abs/1203.3515

Thompson, E. J., Rollik, L. B., Waked, B., Mills, G., Pati, S., Kaur, J., Geva, B., Li, H., Carrasco-Davis, R., George, T., Domine, C., Dorrell, W., & Stephenson-Jones, M. (2026). Replay of procedural memory is independent of the hippocampus. *Nature Neuroscience, 29*, 2237--2248. https://doi.org/10.1038/s41593-026-02362-5

Turpin, M., Michael, J., Perez, E., & Bowman, S. R. (2023). Language models don't always say what they think: Unfaithful explanations in chain-of-thought prompting. *Advances in Neural Information Processing Systems, 36*. https://arxiv.org/abs/2305.04388

Uesato, J., Kushman, N., Kumar, R., Song, F., Siegel, N., Wang, L., Creswell, A., Irving, G., & Higgins, I. (2022). *Solving math word problems with process- and outcome-based feedback*. arXiv. https://arxiv.org/abs/2211.14275

Yin, J., Chen, Z., Wang, H., Sun, Y., Jin, Z., Song, D., & Zhang, D. (2026). *VerifierBench: Benchmarking the generation of executable verifiers for LLM agents*. arXiv. https://arxiv.org/abs/2610.28679

Zelikman, E., Wu, Y., Mu, J., & Goodman, N. D. (2022). STaR: Bootstrapping reasoning with reasoning. *Advances in Neural Information Processing Systems, 35*. https://proceedings.neurips.cc/paper_files/paper/2022/hash/639a9a172c044fbb64175b5fad42e9a5-Abstract-Conference.html

Zhang, Y., Dai, Y., Prabhu, V., Hu, Z., Xu, R., & Chen, Z. (2026). *CLIFT: Conformal self-verification for web agent training and test-time scaling*. arXiv. https://arxiv.org/abs/2610.06829
