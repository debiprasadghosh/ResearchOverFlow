"""Redraw inherited Figure 4; only the D2/MAE label is corrected."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def draw_figure4(root):
    root=Path(root)
    cs={line.split("\t")[0]:list(map(float,line.rstrip("\n").split("\t")[1].split()))
        for line in (root/"inherited_v3/cs_v3.txt").read_text().splitlines()}
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":10,"axes.titlesize":11,"axes.labelsize":10,
                         "axes.spines.top":False,"axes.spines.right":False,"savefig.facecolor":"white"})
    colors={"tenths":"#a95235","hundredths":"#336982"}; labels={"tenths":"Tenths grid","hundredths":"Hundredths grid"}
    fig,ax=plt.subplots(1,2,figsize=(9.4,3.7),layout="constrained")
    kinds=["deletion","rule1","rule2","rule3"]; names=["Condition\ndeletion","Rule 1","Rule 2","Rule 3"]
    x=np.arange(4); width=.36
    for i,tag in enumerate(("tenths","hundredths")):
        vals=[100*cs[f"{tag}_census_{k}"][6]/cs[f"{tag}_census_{k}"][5] for k in kinds]
        bars=ax[0].bar(x+(i-.5)*width,vals,width*.92,color=colors[tag],label=labels[tag])
        for b,val in zip(bars,vals): ax[0].text(b.get_x()+b.get_width()/2,val+.12,f"{val:.1f}",ha="center",fontsize=8)
    ax[0].set_xticks(x,names); ax[0].set_ylabel("Unlicensed instances exactly equal (%)")
    ax[0].set_ylim(0,7.8); ax[0].legend(frameon=False,fontsize=8,loc="upper right"); ax[0].set_title("A  Equal values without a licence")
    hs=[("d2_threshold",.01),("dec2",.005),("dec3",.0005),("dec4",.00005)]
    for tag in ("tenths","hundredths"):
        vals=[100*cs[f"{tag}_precision_{lab}"][5]/cs[f"{tag}_precision_{lab}"][4] for lab,_ in hs]
        ax[1].plot([h for _,h in hs],vals,marker="o",ms=6,lw=2,color=colors[tag],label=labels[tag])
        for (_,h),val in zip(hs,vals):
            offset=1.6 if tag=="hundredths" else (-3.8 if val>7 else 1.0)
            ax[1].text(h*(.86 if tag=="hundredths" else 1.12),val+offset,f"{val:.1f}",
                       ha="left" if tag=="hundredths" else "right",fontsize=8,color=colors[tag])
    ax[1].set_xscale("log"); ax[1].set_xlim(.018,3.2e-5); ax[1].set_ylim(0,56)
    ax[1].set_xlabel("Uniform entrywise radius h"); ax[1].set_ylabel("Wrong answers inside enclosure (%)")
    ax[1].axvline(.01,color="#677780",lw=.8,ls=":")
    ax[1].text(.0092,3,"Uniform radius 0.01",fontsize=8,color="#677780",ha="left")
    ax[1].legend(frameon=False,fontsize=8,loc="upper right"); ax[1].set_title("B  Value checks need precision")
    (root/"fig").mkdir(exist_ok=True)
    path=root/"fig/v4_licence_and_precision.png"
    fig.savefig(path,dpi=240); fig.savefig(path.with_suffix(".svg")); plt.close(fig)
    return path

if __name__=="__main__": draw_figure4(Path(__file__).resolve().parent)
