"""Apply final document metadata, table readability and section starts."""
from pathlib import Path
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import sys

src,dst=sys.argv[1:3]
doc=Document(src)
doc.core_properties.title='Horizontally Topological, Vertically Algebraic'
doc.core_properties.author='Debi Prasad Ghosh'
doc.core_properties.subject='Autoregressive Sheaf Evolution Part I Sheaves on covers and representations of the layer order'
for p in doc.paragraphs:
    if p.style and p.style.name=='Title':
        p.text='Horizontally Topological,\nVertically Algebraic'
    if p.text.strip() in ['References','Appendix A an immutable C# reference kernel','Appendix B reproducibility']:
        p.paragraph_format.page_break_before=True
    if p.style and p.style.name in ['Statement','Statement Equation']:
        # Keep the identifying paragraph with at least the next paragraph.
        if p.text.startswith(('Definition ','Proposition ','Theorem ','Corollary ','Lemma ')):
            p.paragraph_format.keep_with_next=True
    if p.style and p.style.name=='Date':
        p.text='Autoregressive Sheaf Evolution Part I  •  18 October 2026'
        for r in p.runs:r.font.size=Pt(9.5)
for ti,table in enumerate(doc.tables):
    pr=table._tbl.tblPr
    for old in list(pr.findall(qn('w:tblBorders'))):pr.remove(old)
    borders=OxmlElement('w:tblBorders')
    for side in ['top','left','bottom','right','insideH','insideV']:
        e=OxmlElement('w:'+side);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
    pr.append(borders)
    for ri,row in enumerate(table.rows):
        if ri==0:
            trpr=row._tr.get_or_add_trPr()
            if trpr.find(qn('w:tblHeader')) is None:trpr.append(OxmlElement('w:tblHeader'))
        for ci,cell in enumerate(row.cells):
            cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            cpr=cell._tc.get_or_add_tcPr()
            shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E7EBEF' if ri==0 else ('F7F8F9' if ri%2==0 else 'FFFFFF'));cpr.append(shade)
            margin=OxmlElement('w:tcMar')
            for side,val in [('top',65),('bottom',65),('left',85),('right',85)]:
                e=OxmlElement('w:'+side);e.set(qn('w:w'),str(val));e.set(qn('w:type'),'dxa');margin.append(e)
            cpr.append(margin)
            for p in cell.paragraphs:
                p.paragraph_format.space_after=Pt(2);p.paragraph_format.space_before=Pt(1)
                p.paragraph_format.line_spacing=1.08
                if ci==0 and ti in [1,2]:p.alignment=WD_ALIGN_PARAGRAPH.CENTER
                for r in p.runs:
                    r.font.color.rgb=RGBColor(0,0,0)
                    if ri==0:r.bold=True
doc.save(dst)
print(dst)
