"""Structural package checks only; not a complete OOXML schema validator."""
from pathlib import Path
from zipfile import ZipFile
from lxml import etree
import json
import posixpath
import sys

here = Path(__file__).resolve().parent
source = Path(sys.argv[1]) if len(sys.argv) > 1 else here / 'ASE_Part_I_The_Two_Axes.docx'
destination = Path(sys.argv[2]) if len(sys.argv) > 2 else here / 'document_checks.json'
ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
      'm': 'http://schemas.openxmlformats.org/officeDocument/2006/math',
      'dc': 'http://purl.org/dc/elements/1.1/'}
with ZipFile(source) as archive:
    names = set(archive.namelist())
    xml = {name: etree.fromstring(archive.read(name))
           for name in names if name.endswith(('.xml', '.rels'))}
    unresolved = []
    for name, root in xml.items():
        if not name.endswith('.rels'):
            continue
        parent = '' if name == '_rels/.rels' else posixpath.dirname(posixpath.dirname(name))
        for rel in root:
            if rel.get('TargetMode') == 'External':
                continue
            target = rel.get('Target', '')
            resolved = (target.lstrip('/') if target.startswith('/') else
                        posixpath.normpath(posixpath.join(parent, target)))
            if resolved not in names:
                unresolved.append({'part': name, 'target': target})
    body = xml['word/document.xml']
    tracked = sum(len(body.findall('.//w:' + tag, ns)) for tag in
                  ('ins', 'del', 'commentRangeStart', 'commentReference'))
    report = {
        'xml_parts_parsed': len(xml),
        'unresolved_relationships': unresolved,
        'native_math_elements': len(body.findall('.//m:oMath', ns)),
        'embedded_images': len([name for name in names if name.startswith('word/media/')]),
        'title': xml['docProps/core.xml'].findtext('dc:title', namespaces=ns),
        'tracked_changes_or_comment_markers': tracked,
        'unfilled_result_placeholders': '{{' in ''.join(body.itertext()),
        'full_independent_ooxml_schema_validation': False
    }
assert not unresolved, unresolved
assert report['native_math_elements'] > 0
assert tracked == 0
assert not report['unfilled_result_placeholders']
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
