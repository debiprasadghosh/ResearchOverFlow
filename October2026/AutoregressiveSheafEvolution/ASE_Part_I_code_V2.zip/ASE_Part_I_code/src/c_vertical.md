
# 4 The vertical axis representations of the layer order

## 4.1 Representations and barcodes

::: {custom-style="Statement"}
**Definition 4.1** (representations of the layer order). A representation $V$ of $P$ consists of finite-dimensional spaces $V_t$, $t=T,\ldots,0$, and linear maps $\rho_t:V_t\to V_{t-1}$. For $a\ge b$ write $\rho_{a\to b}=\rho_{b+1}\circ\cdots\circ\rho_a:V_a\to V_b$, the identity when $a=b$. The rank invariant is $r(a,b)=\text{rank}\,\rho_{a\to b}$. For $T\ge b\ge d\ge 0$, the interval module $𝕀[b,d]$ is $ℝ$ at the layers $b,b-1,\ldots,d$, joined by identities, and $0$ elsewhere. It is born at layer $b$ and is alive up to layer $d$.
:::

::: {custom-style="Statement Tag"}
Classical.
:::

::: {custom-style="Statement"}
**Theorem 4.2** (interval decomposition). Every representation of $P$ decomposes as $V\cong\bigoplus 𝕀[b,d]^{m[b,d]}$. The multiset of intervals, the barcode, is unique and is a complete invariant up to isomorphism, and
:::

::: {custom-style="Statement Equation"}
$m[b,d]=r(b,d)-r(b+1,d)-r(b,d-1)+r(b+1,d-1)$ (4.1)
:::

::: {custom-style="Statement"}
with $r=0$ whenever an index leaves $\{T,\ldots,0\}$.
:::

::: {custom-style="Statement Tag"}
Classical [13, 15, 26, 34].
:::

*Proof.* The decomposition is Gabriel's theorem for the linearly oriented quiver of type A [15]; Crawley-Boevey extends it to pointwise finite-dimensional modules over the real line [13]. The rank $r(a,b)$ counts the intervals that contain both $a$ and $b$, and inclusion–exclusion over the four corners isolates those born exactly at $b$ and alive exactly up to $d$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{c.barcodes.random_chains}} random chains with 3 to 6 layers, dimensions 1 to 4 and maps of random rank, every multiplicity from (4.1) was nonnegative and the bars reproduced every rank $r(a,b)$ exactly.
:::

## 4.2 Vertical fibre diagrams

::: {custom-style="Statement"}
**Definition 4.3** (token path and fibre diagrams). Let a token visit $x_t\in X_t$, and let $V_t$ be the data space attached to its visited cell. Linear vertical maps arise in three ways.
:::

::: {custom-style="Statement"}
\(a) *Transport diagrams:* specified linear maps $\rho_t:V_t\to V_{t-1}$, such as stalk maps induced by refinements or validated chart transports. This is the token's vertical fibre diagram.
:::

::: {custom-style="Statement"}
\(b) *Tangent diagrams:* the Jacobians $J_t=\partial z_{t-1}/\partial z_t$ of a smooth update along the realised path, with the noise held fixed.
:::

::: {custom-style="Statement"}
\(c) *Affine diagrams:* $z_{t-1}=A_tz_t+b_t$, made linear by homogenisation.
:::

::: {custom-style="Statement"}
A single stalk is one fibre; the whole journey is a sequence of stalks and maps, not one stalk. A state-dependent nonlinear update is not a linear representation and does not acquire a barcode merely by being layered.
:::

::: {custom-style="Statement Tag"}
V2 Definition 3.1, with the three sources separated.
:::

::: {custom-style="Statement"}
**Proposition 4.4** (homogenisation adds exactly one full bar). Let $\tilde A_t=\begin{pmatrix}A_t & b_t\\ 0 & 1\end{pmatrix}$ act on $ℝ^{D+1}$.
:::

::: {custom-style="Statement"}
\(i) The composite of the affine diagram is
:::

::: {custom-style="Statement Equation"}
$z_0=A_1A_2\cdots A_T\,z_T+\sum_{t=1}^{T}A_1\cdots A_{t-1}\,b_t$ (4.2)
:::

::: {custom-style="Statement"}
\(ii) The barcode of $(ℝ^{D+1},\tilde A_t)$ is the barcode of $(ℝ^{D},A_t)$ plus one interval $𝕀[T,0]$.
:::

::: {custom-style="Statement Tag"}
\(i) V2 Section 7 with matrix coefficients; (ii) new in Part I.
:::

*Proof.* (i) Substitute each recurrence into the next. (ii) The vectors with last coordinate zero form a subrepresentation isomorphic to $(ℝ^D,A_t)$, and the quotient is $𝕀[T,0]$ because every $\tilde A_t$ preserves the last coordinate. The extension splits. Choose any $w_T$, set $w_{t-1}=A_tw_t+b_t$, and observe that the vectors $(w_t,1)$ span a subrepresentation isomorphic to $𝕀[T,0]$ and complementary to the first. Uniqueness of barcodes gives (ii). $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* For 200 random affine chains with $D=3$ and $T=8$, the direct recurrence, formula (4.2) and the homogenised product agreed to {{c.affine_max_err|e1}}. In {{x.affine_bars.trials}} random chains with rank-deficient $A_t$ and random offsets, the homogenised barcode equalled the linear barcode plus one full bar in {{x.affine_bars.agree}} cases.
:::

The full bar is the affine direction: the trajectory of one point. Everything the offsets $b_t$ do is in where that trajectory goes, not in the barcode. A barcode of an affine diagram is therefore the barcode of its linear part, plus the one full bar.

## 4.3 Births at a clean top

::: {custom-style="Statement"}
**Proposition 4.5** (births at the top). Suppose $\text{dim}\,V_t=D$ for every $t$, every map below the top is invertible, and the top map $\rho_1:V_1\to V_0$ has rank $r$. Then
:::

::: {custom-style="Statement Equation"}
$V\cong 𝕀[T,0]^{r}\oplus 𝕀[T,1]^{D-r}\oplus 𝕀[0,0]^{D-r}$ (4.3)
:::

::: {custom-style="Statement Tag"}
V2 Section 13, with proof.
:::

*Proof.* The ranks are $r(a,b)=D$ for $b\ge 1$, $r(a,0)=r$ for $a\ge 1$, and $r(0,0)=D$. Formula (4.1) returns $m[T,0]=r$, $m[T,1]=D-r$ and $m[0,0]=D-r$, and every other multiplicity vanishes. $\blacksquare$

Of the $D$ bars born at the bottom, $r$ reach the top and $D-r$ end one layer below it. The top also has $D-r$ bars of its own: output directions that no lower perturbation reaches. Counting only the bars born at the bottom, and calling the missing ones deaths, misreads the rank. For the Gaussian update with a clean top, $a_0=1$, V2 gives $\lambda_1=1$ and $J_1=C_1/s_1^2$, so $r=\text{rank}\,C_1$.

::: {custom-style="Check"}
*Numerical check.* With $D=4$, five layers and a top map of rank 2, formula (4.1) returned the bars $𝕀[T,0]^{ {{c.barcodes.top_example.[1,5]}} }$, $𝕀[T,1]^{ {{c.barcodes.top_example.[1,4]}} }$ and $𝕀[0,0]^{ {{c.barcodes.top_example.[5,5]}} }$. The C# kernel reproduces the case $D=3$, four layers and top rank 1 (Appendix A).
:::

## 4.4 Exact bars and effective sensitivity

::: {custom-style="Statement"}
**Proposition 4.6** (exact versus effective rank of the Gaussian tangent). Within a fixed cell and star, assume orthogonal, locally constant transports, query-independent prior weights, $s_t>0$ and $0\le\lambda_t\le1$. Let $v_1,\ldots,v_n$ be the transported values, $\alpha_i>0$ their Gaussian posterior weights, $m=\sum_i\alpha_iv_i$, $C=\sum_i\alpha_i(v_i-m)(v_i-m)^{\top}$ and $J_t=(1-\lambda_t)I+(\lambda_t/s_t^2)\,C$ [19, Proposition 13.1].
:::

::: {custom-style="Statement"}
\(i) The range of $C$ is $\text{span}\{v_i-v_1\}$, so $\text{rank}\,C=\text{dim}\,\text{aff}\{v_1,\ldots,v_n\}\le\text{min}(D,n-1)$.
:::

::: {custom-style="Statement"}
\(ii) If one record has posterior mass at least $1-\varepsilon$ and $R$ is the diameter of the transported values, then
:::

::: {custom-style="Statement Equation"}
$\|C\|\le\varepsilon R^2$ (4.4)
:::

::: {custom-style="Statement"}
\(iii) If $\lambda_t<1$, every eigenvalue of $J_t$ lies in $[1-\lambda_t,\ 1-\lambda_t+\lambda_tR^2/(4s_t^2)]$, so $J_t$ is invertible. At a clean top, $\text{rank}\,J_1=\text{dim}\,\text{aff}\{v_i\}$. If the spaces all have dimension $D$, every lower map has $\lambda_t<1$ and the top records affinely span $ℝ^D$, every exact tangent bar is full, however small $\varepsilon$ is.
:::

::: {custom-style="Statement"}
\(iv) For all matrices $A$ and $E$ and every $k$, $|\sigma_k(A+E)-\sigma_k(A)|\le\|E\|$. Hence the effective rank at tolerance $\tau$, the number of singular values above $\tau$, is unchanged by every perturbation with $\|E\|<\text{min}_k|\sigma_k(A)-\tau|$, while arbitrarily small generic perturbations can increase the exact rank of a rank-deficient matrix.
:::

::: {custom-style="Statement Tag"}
\(i) and the bar statement in (iii) new in Part I; (ii) and the eigenvalue bound V2 Section 13; (iv) Weyl [23].
:::

*Proof.* (i) Since every $\alpha_i>0$, the range of $C$ is $\text{span}\{v_i-m\}$. Because $m$ is an affine combination of the $v_i$, this equals $\text{span}\{v_i-v_1\}$, the direction space of the affine hull. (ii) For every point $c$, $\sum_i\alpha_i(v_i-c)(v_i-c)^{\top}=C+(m-c)(m-c)^{\top}\succeq C$. Take $c=v_j$, the record of mass at least $1-\varepsilon$: the $j$-th term vanishes, and the others have total mass at most $\varepsilon$ and norm at most $R^2$. (iii) The eigenvalue bound is V2 Proposition 13.1; at the top $J_1=C_1/s_1^2$, and (i) applies. (iv) This is Weyl's inequality for singular values [23]. $\blacksquare$

Re-selection of an archived record is therefore usually contraction of singular values, not literal death of an interval. Exact death occurs at rank loss or in the one-hot limit. A numerical threshold $\tau$ defines an effective rank, which must be reported together with its tolerance.

::: {custom-style="Check"}
*Numerical check (Proposition 4.6 (i)–(ii)).* In {{x.covariance.trials}} random record sets in $ℝ^4$ with prescribed affine dimension 0 to 3 and random positive weights, $\text{rank}\,C$ equalled the affine dimension in {{x.covariance.rank_equals_affine_dim}} cases. Bound (4.4) held in {{x.covariance.eps_bound_holds}} cases with $\varepsilon$ up to 0.3; the largest ratio $\|C\|/(\varepsilon R^2)$ was {{x.covariance.worst_ratio|f3}}.
:::

To see both effects in a full stack, we ran {{c.tangent.tokens}} tokens through a 16-layer cosine schedule with $a_t=\cos^2(\pi t/32)$, $\eta=0$ and a clean top, on 30 records in three clusters in $ℝ^2$. The composite tangent $\partial z_0/\partial z_{15}$ was computed along each realised path. In exact arithmetic every composite has rank 2, by Proposition 4.6. At the declared numerical cutoff $10^{-14}\max(1,\sigma_{\max})$, the measured rank was full for {{c.tangent.exact_full_rank|pct1}} of tokens. In each of the other {{t.deficient}} tokens at most {{t.deficient_weights_above_1e8.1}} records kept a final weight above $10^{-8}$, the smallest eigenvalue of $C_1$ was at most {{t.deficient_min_eig_C1_max|e1}}, and the composite was numerically singular. This is numerical rank at a chosen cutoff, not exact singularity. Concentration near a line or point can make the smaller covariance direction negligible, although the remaining positive weights retain exact rank. At practical tolerances the effective rank told a different story. At $\tau=10^{-3}$ it was 0, 1 or 2 for {{c.tangent.effective_rank_1e3.0|pct1}}, {{c.tangent.effective_rank_1e3.1|pct1}} and {{c.tangent.effective_rank_1e3.2|pct1}} of tokens. At $\tau=10^{-2}$ the shares were {{c.tangent.effective_rank_1e2.0|pct1}}, {{c.tangent.effective_rank_1e2.1|pct1}} and {{c.tangent.effective_rank_1e2.2|pct1}}. The median singular values at the top were {{c.tangent.median_smax|f4}} and {{c.tangent.median_smin|e1}} (Figure 4). The exact bars survive while sensitivity contracts by one to three orders of magnitude, most sharply in the final step.

A revision audit replays the same {{a.covariance_replay.tokens}} token paths using both $C_{\mathrm{raw}}=\sum_i\alpha_iv_iv_i^{\top}-mm^{\top}$ and $C_{\mathrm{cent}}=\sum_i\alpha_i(v_i-m)(v_i-m)^{\top}$. Both classify {{a.covariance_replay.raw_deficient}} composites below the same cutoff, with {{a.covariance_replay.changed_classifications}} changed classifications. The raw final covariance has a negative eigenvalue for {{a.covariance_replay.raw_final_negative_eigenvalues}} tokens; the largest covariance discrepancy is {{a.covariance_replay.maximum_covariance_difference|e1}}. Thus cancellation is observable, but changing to the centred formula does not remove the 3.1% numerical-rank result in this experiment. The data show association with at most two weights above $10^{-8}$, not that every affected token is one-hot. Use the centred form in implementations.

![**Figure 4.** Exact bars survive while sensitivity contracts. Median singular values of the composite tangent $\partial z_t/\partial z_{15}$ for 200 tokens as they climb a 16-layer cosine stack with a clean top. Dashed lines mark two effective-rank tolerances. The mathematical rank is 2 for every path under the hypotheses; measured rank depends on the tolerance and floating-point evaluation.](fig/tangent.png){width=92%}

## 4.5 Persistence of layer cohomology

::: {custom-style="Statement"}
**Proposition 4.7** (layer cohomology is a representation of $P$). Suppose that for each $t$ there is a simplicial map $f_t:N_{t-1}\to N_t$, for instance from a refinement or an inclusion, and a sheaf morphism $\varphi_t:f_t^{-1}F_t\to F_{t-1}$. Then the composites
:::

::: {custom-style="Statement Equation"}
$H^k(N_t;F_t)\to H^k(N_{t-1};f_t^{-1}F_t)\to H^k(N_{t-1};F_{t-1})$ (4.5)
:::

::: {custom-style="Statement"}
make $t\mapsto H^k(N_t;F_t)$ a representation of $P$ for every $k$. It therefore has a barcode in every degree.
:::

::: {custom-style="Statement Tag"}
New packaging in Part I: a topological step followed by an algebraic step, in the sense of Russold [28].
:::

*Proof.* The first arrow is Proposition 3.20, and the second is functoriality of cohomology under sheaf morphisms. Composition is functorial, so the maps compose along $P$, and Theorem 4.2 applies. $\blacksquare$

::: {custom-style="Statement"}
**Proposition 4.8** (Leray covers give full bars). Let $𝒮$ be a sheaf on a fixed space $X$, and let $𝒰_T,\ldots,𝒰_0$ be covers of $X$ such that each $𝒰_{t-1}$ refines $𝒰_t$ and every $𝒰_t$ is a Leray cover for $𝒮$. With Čech data sheaves and refinement maps, every vertical map $H^k(N_t;F_t)\to H^k(N_{t-1};F_{t-1})$ is an isomorphism, and the degree-$k$ barcode consists of $\text{dim}\,H^k(X;𝒮)$ copies of $𝕀[T,0]$.
:::

::: {custom-style="Statement Tag"}
New in Part I, as a corollary of Proposition 3.21.
:::

*Proof.* By Proposition 3.21 each refinement map commutes with the Leray isomorphisms to $H^k(X;𝒮)$, which are isomorphisms at every layer by Theorem 3.9. $\blacksquare$

Under these hypotheses and canonical refinement maps, refinement alone creates no birth or death. An observed change means that the region, underlying coefficients, Leray hypotheses or comparison construction changed, or that numerical or implementation error occurred. In particular, replacing Čech coefficients by one scalar per overlap can create an artefact even when the cover itself is Leray.

::: {custom-style="Statement"}
**Example 4.9** (a coarse cover that misses a loop; Figure 3). Cover the circle at the bottom by the two arcs of Example 3.10, in the middle by three arcs and at the top by six arcs, each cover refining the one below. With the plain nerve and constant coefficients, $H^1$ is $0$, $1$ and $1$, and a bar is born at the middle layer. That bar is an artefact of replacing the bottom overlap's two-dimensional Čech data by one scalar. The two-arc cover itself is Leray; the plain coefficient summary is incorrect. With the Čech data sheaf at the bottom, $H^1=ℝ$ at every layer and the bar is full, as Proposition 4.8 predicts.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

::: {custom-style="Check"}
*Numerical check.* The covers, overlaps and refinement maps were computed from the arcs on a grid of 7,200 angles. The refinement maps were $({{x.circle.data_sheaf.refinement_maps.0.0}},{{x.circle.data_sheaf.refinement_maps.0.1}},{{x.circle.data_sheaf.refinement_maps.0.2}})$ and $({{x.circle.data_sheaf.refinement_maps.1.0}},{{x.circle.data_sheaf.refinement_maps.1.1}},{{x.circle.data_sheaf.refinement_maps.1.2}},{{x.circle.data_sheaf.refinement_maps.1.3}},{{x.circle.data_sheaf.refinement_maps.1.4}},{{x.circle.data_sheaf.refinement_maps.1.5}})$, and the induced cochain maps commuted with the coboundaries exactly. The bottom overlap had {{x.circle.data_sheaf.bottom_overlap_components}} components. Barcodes from (4.1): plain nerve $H^0$ full and $H^1$ born at the middle layer; data sheaf $H^0$ and $H^1$ both full.
:::

::: {custom-style="Statement"}
**Proposition 4.10** (nested ball nerves). Fix centres $y_i\in ℝ^D$ and positive radii $0<r_0\le\cdots\le r_T$, and let $N_t$ be the nerve of the open balls $B(y_i,r_t)$. Then $N_0\subseteq\cdots\subseteq N_T$, each $N_t$ is homotopy equivalent to the union of its balls, and the inclusions give $H^k(N_T)\to\cdots\to H^k(N_0)$ in the token direction. In degree zero these maps are injective. Every $H^0$ bar therefore reaches the top layer, and the number of bars born at layer $t-1$ is the increase $c(N_{t-1})-c(N_t)$ in the number of components.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 14.1.
:::

*Proof.* The finite ball covers of their Euclidean unions are good covers. An intersection that is nonempty at a smaller radius stays nonempty at a larger one. Ball intersections are convex, so the nerve theorem applies [22]. The nerves share their vertices, so a function that is constant on the components of $N_t$ restricts to a function constant on the finer components of $N_{t-1}$, and distinct coarse functions differ at some vertex. Injective maps kill no bar, and (4.1) counts the births. $\blacksquare$

For open balls an edge appears at centre distance strictly below $2r_t$; a convention at exact equality must be chosen and recorded. The nerve is homotopy equivalent to the union of the balls, not to the latent domain, unless the balls cover that domain.

::: {custom-style="Check"}
*Numerical check (Figure 5).* The archive has {{x.archive_barcode.records}} records in three clusters of three sub-clusters, with radius $r_t=s_t$, that is $\kappa=1$, on the 16-layer cosine schedule. The component counts are {{x.archive_barcode.components.15}} at layers 15 to 12, {{x.archive_barcode.components.11}} at layers 11 to 9, {{x.archive_barcode.components.8}} at layer 8 and {{x.archive_barcode.components.7}} at layers 7 to 1. Births occur at layers 15, 11, 8 and 7 with multiplicities {{x.archive_barcode.births.15}}, {{x.archive_barcode.births.11}}, {{x.archive_barcode.births.8}} and {{x.archive_barcode.births.7}}. Every vertical map is injective and every bar reaches layer 1. The clean top has radius zero and is excluded. This reproduces check 21 of the proposal register [18, 19].
:::

![**Figure 5.** $H^0$ barcode of a nested ball filtration. Left: an archive with structure at three scales. Right: bars in the token's direction, born when components split; the numbers above give the component count at each layer. Every bar reaches the top because the vertical maps are injective in degree zero (Proposition 4.10).](fig/barcode.png){width=100%}

::: {custom-style="Statement"}
**Proposition 4.11** (stability of component counts). Let $y,y'$ be configurations of $n$ points with $\text{max}_i\|y_i-y'_i\|\le\varepsilon$, and let $c_r(y)$ be the number of components of the graph with an edge whenever $\|y_i-y_j\|\le r$. Then
:::

::: {custom-style="Statement Equation"}
$c_{r+2\varepsilon}(y)\le c_r(y')\le c_{r-2\varepsilon}(y)$ (4.6)
:::

::: {custom-style="Statement Tag"}
New in Part I as stated; a component-level form of persistence stability [12].
:::

*Proof.* If $\|y'_i-y'_j\|\le r$, then $\|y_i-y_j\|\le r+2\varepsilon$ by the triangle inequality, so the graph of $y'$ at radius $r$ is contained in the graph of $y$ at $r+2\varepsilon$. Both graphs have the same vertices, and more edges give fewer components. The second inequality is symmetric. $\blacksquare$

For negative thresholds define $c_r=n$, with no edges; this makes (4.6) valid when $r-2\varepsilon<0$. Births read from component counts are robust only away from thresholds. A schedule chosen from births should therefore be reported together with the $2\varepsilon$ margin of the archive's uncertainty.

::: {custom-style="Check"}
*Numerical check.* We drew 80 configurations of 40 points in $[0,10]^2$, with $\varepsilon$ from 0.02 to 0.4, and evaluated 15 radii each: {{c.stability.cases}} cases with {{c.stability.violations}} violations of (4.6).
:::

::: {custom-style="Statement"}
**Remark 4.12** (zigzags). If covers are learned, centres move or neighbourhoods are not nested, consecutive layers need not admit a map in either direction. A common refinement $𝒲$ gives $H^k(N_t)\to H^k(N(𝒲))\leftarrow H^k(N_{t-1})$. This is a zigzag module, which also decomposes into intervals [10]. Section 5 gives a zigzag whose nonconstant coefficients have nonzero derived-limit cohomology. A zigzag is not automatically non-acyclic, and learned covers do not force a unique comparison construction.
:::

::: {custom-style="Statement Tag"}
V2 Section 14.
:::
