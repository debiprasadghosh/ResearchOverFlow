
# 3 The horizontal axis sheaves on covers

## 3.1 Layer covers and data sheaves

::: {custom-style="Statement"}
**Definition 3.1** (layer cover). Fix layers $t=T,\ldots,1,0$, traversed from bottom to top, a schedule $0<a_t\le a_{t-1}\le 1$ and the scale $s_t=\sqrt{(1-a_t)/a_t}$. Each layer has a base $X_t$ and a finite open cover $𝒰_t=\{U_i\}_{i\in I_t}$ of the region visited by its tokens. Its nerve $N_t$ has a simplex $\sigma\subseteq I_t$ whenever $U_\sigma=\bigcap_{i\in\sigma}U_i$ is nonempty. A cover diameter near $\kappa s_t$ is a resolution policy, not an existence theorem for a good cover.
:::

::: {custom-style="Statement Tag"}
V2 Definition 2.1.
:::

::: {custom-style="Statement"}
**Definition 3.2** (cellular data sheaf). A cellular sheaf $F$ on a simplicial complex $K$ assigns a finite-dimensional real vector space $F(\sigma)$, the stalk, to every simplex $\sigma$, and a linear map $r_{\sigma\tau}:F(\sigma)\to F(\tau)$ to every face relation $\sigma\le\tau$, such that $r_{\sigma\sigma}=I$ and $r_{\tau\rho}\,r_{\sigma\tau}=r_{\sigma\rho}$ whenever $\sigma\le\tau\le\rho$. The maps run from a vertex to its overlaps. A graph sheaf specifies only vertex and edge stalks. To extend it over a triangle $\tau$, one must give $F(\tau)$ and maps $r_{e\tau}$ satisfying, for each vertex $u$ of $\tau$ and the two edges $e,e'$ of $\tau$ through $u$,
:::

::: {custom-style="Statement Equation"}
$r_{e\tau}\,r_{ue}=r_{e'\tau}\,r_{ue'}$ (3.1)
:::

::: {custom-style="Statement Tag"}
V2 Definition 2.2, with the triangle identities made explicit [3, 5, 14].
:::

A stalk is the data space attached to one cell [27]. It need not be a chart coordinate system, and the restriction maps need not be invertible. A rectangular restriction models a partial observation. An affine coordinate transition requires an affine sheaf or a torsor (Section 3.5), and nonlinear coordinate changes require sheaves of nonlinear objects, which Part I does not treat. Orthogonal restrictions form a tractable subclass (Section 3.4); they do not define what a sheaf is.

::: {custom-style="Statement"}
**Remark 3.3** (units before residuals). Before overlap residuals are compared, every edge stalk carries declared units and a weight $W_e\succ 0$ that makes $\|c\|_{W_e}^2=c^{\top}W_ec$ dimensionless, for instance $W_e=\text{diag}(1/\sigma_j^2)$ with $\sigma_j$ the tolerance of component $j$. If the units of an edge stalk change by an invertible matrix $S_e$, so that $c\mapsto S_ec$, the weight must change to $S_e^{-\top}W_eS_e^{-1}$. With that convention the energy, its kernel and every bound of Propositions 3.7 and 3.8 are unchanged. Without it, mixing displacement, stress and dimensionless utilisation changes the energy and the resulting read. Vertex coordinates are also nondimensionalised before a Euclidean state norm is used; a change of vertex units requires transforming the vertex metric as well.
:::

::: {custom-style="Statement Tag"}
V2 Section 2, made quantitative.
:::

## 3.2 Cochains, residuals and cohomology

::: {custom-style="Statement"}
**Definition 3.4** (cochains, coboundary, residual). Order the vertices of $K$. For a $(k+1)$-simplex $\tau=\{v_0<\cdots<v_{k+1}\}$, let $\tau_i$ be the face opposite $v_i$. Set $C^k(K;F)=\bigoplus_{\text{dim}\,\sigma=k}F(\sigma)$ and
:::

::: {custom-style="Statement Equation"}
$(\delta x)_\tau=\sum_{i=0}^{k+1}(-1)^i\,r_{\tau_i\tau}\,x_{\tau_i}$ (3.2)
:::

::: {custom-style="Statement"}
For an edge $e=\{u<v\}$ this reads $(\delta x)_e=r_{ve}x_v-r_{ue}x_u$. Cohomology is $H^k=\text{ker}\,\delta^k/\text{im}\,\delta^{k-1}$. A section is a vertex assignment $x\in C^0$ with $\delta x=0$, so $H^0$ is the space of sections. The residual of an arbitrary assignment $x$ is $\delta x\in C^1$.
:::

::: {custom-style="Statement Tag"}
Classical [14, 20].
:::

::: {custom-style="Statement"}
**Proposition 3.5** (the coboundary needs compatibility; Euler identity). Let restriction maps be given only for codimension-one faces.
:::

::: {custom-style="Statement"}
\(i) $\delta^{k+1}\delta^k=0$ for every $k$ if and only if every diamond commutes: for every simplex $\rho$ and every face $\sigma$ of codimension two in $\rho$, with $\tau,\tau'$ the two faces between them, $r_{\tau\rho}\,r_{\sigma\tau}=r_{\tau'\rho}\,r_{\sigma\tau'}$. In degree one these are exactly the triangle identities (3.1).
:::

::: {custom-style="Statement"}
\(ii) The diamonds commute exactly when the codimension-one maps extend to a cellular sheaf. Hence the full condition $\delta\circ\delta=0$ characterises cellular sheaves among these simplicial data. If $\delta^1\delta^0\ne0$, the quotient defining $H^1$ is not defined.
:::

::: {custom-style="Statement"}
\(iii) $\sum_k(-1)^k\,\text{dim}\,C^k=\sum_k(-1)^k\,\text{dim}\,H^k$. On a graph,
:::

::: {custom-style="Statement Equation"}
$\text{dim}\,H^0-\text{dim}\,H^1=\sum_v\text{dim}\,F(v)-\sum_e\text{dim}\,F(e)$ (3.3)
:::

::: {custom-style="Statement Tag"}
Classical in substance; (i) is the reason for V2's triangle requirement.
:::

*Proof.* (i) Let $\rho$ have dimension $k+2$ and let $\sigma$ be the face of $\rho$ missing the vertices $v_i$ and $v_j$, with $i<j$. The block of $\delta^{k+1}\delta^k$ in row $\rho$ and column $\sigma$ comes from the two intermediate faces, each missing one of these vertices. The two routes carry the signs $(-1)^j(-1)^i$ and $(-1)^i(-1)^{j-1}$, which are opposite, so the block is $\pm(r_{\tau\rho}r_{\sigma\tau}-r_{\tau'\rho}r_{\sigma\tau'})$. Every block vanishes exactly when every diamond commutes. (ii) If the diamonds commute, define $r_{\sigma\rho}$ as the composite along any maximal chain of faces from $\sigma$ to $\rho$. Two such chains add the missing vertices in different orders, and adjacent transpositions of that order, which are diamond moves, connect them, so the composite is well defined and compatible. The converse is immediate. (iii) Rank–nullity in each degree. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* On a filled triangle with random vertex stalks, edge stalks $ℝ^4$ and triangle stalk $ℝ^2$, built to satisfy (3.1), the largest entry of $\delta^1\delta^0$ is {{c.delta_squared.compatible_max|g3}}. After one vertex-to-edge map is replaced by a random matrix it is {{c.delta_squared.incompatible_max|f2}}. The alternating sums of cochain and cohomology dimensions agree ({{c.delta_squared.euler_cells}} and {{c.delta_squared.euler_cohomology}}).
:::

A residual is always a coboundary. A nonzero disagreement $\delta x$ is therefore never itself a nonzero cohomology class. Cohomology in degree one measures something else: edge data that no assignment can produce. The next proposition makes both statements quantitative.

::: {custom-style="Statement"}
**Proposition 3.6** (positive sheaf energy). Let $W=\bigoplus_eW_e$ be positive definite on $C^1$, with the units of Remark 3.3. The energy $E(x)=\frac{1}{2}\|\delta x\|_W^2=\frac{1}{2}x^{\top}Lx$, with $L=\delta^{\top}W\delta$, is positive semidefinite and $\text{ker}\,L=H^0$.
:::

::: {custom-style="Statement Tag"}
V2 Lemma 2.3; $L$ is the sheaf Laplacian [20].
:::

::: {custom-style="Statement"}
**Proposition 3.7** (distance to consistency; Hodge split). Let $F$ be a graph sheaf, $P$ the orthogonal projection of $C^0$ onto $H^0$, and suppose $L\ne0$. Let $\lambda_2$ and $\lambda_{\text{max}}$ be its smallest positive and largest eigenvalue. For $x\in C^0$,
:::

::: {custom-style="Statement Equation"}
$\frac{\|\delta x\|_W}{\sqrt{\lambda_{\text{max}}}}\le\|x-Px\|\le\frac{\|\delta x\|_W}{\sqrt{\lambda_2}}$ (3.4)
:::

::: {custom-style="Statement"}
Moreover $C^1=\text{im}\,\delta\oplus\text{ker}(\delta^{\top}W)$, orthogonally for the inner product $W$, and $\text{ker}(\delta^{\top}W)\cong H^1$. For prescribed edge data $c\in C^1$, write $c=\delta y+h$ with $h\in\text{ker}(\delta^{\top}W)$. Then
:::

::: {custom-style="Statement Equation"}
$\text{min}_{x}\,\|\delta x-c\|_W=\|h\|_W$ (3.5)
:::

::: {custom-style="Statement"}
and the minimum is zero exactly when the class of $c$ in $H^1=C^1/\text{im}\,\delta$ vanishes.
:::

::: {custom-style="Statement Tag"}
Classical in substance [20]; stated here with units and the least-squares reading.
:::

*Proof.* The vector $x-Px$ is orthogonal to $\text{ker}\,L$, so it lies in the span of the eigenvectors of $L$ with positive eigenvalues. Since $\|\delta x\|_W^2=x^{\top}Lx=(x-Px)^{\top}L(x-Px)$, this quantity lies between $\lambda_2\|x-Px\|^2$ and $\lambda_{\text{max}}\|x-Px\|^2$. The $W$-orthogonal complement of $\text{im}\,\delta$ is $\{c:\langle\delta y,c\rangle_W=0\ \text{for all}\ y\}=\text{ker}(\delta^{\top}W)$. Its dimension is $\text{dim}\,C^1-\text{rank}\,\delta=\text{dim}\,H^1$ because a graph has no $2$-cells. The least-squares problem projects $c$ onto $\text{im}\,\delta$ and leaves $h$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* We used a connected graph with 8 vertices and 13 edges, stalks $ℝ^2$, and edge weights drawn uniformly from $[0.5,2]$. One sheaf is gauge-equivalent to the constant sheaf, with $H^0={{c.hodge_residual.0.H0}}$ and $H^1={{c.hodge_residual.0.H1}}$. The other has random orthogonal maps, with $H^0={{c.hodge_residual.1.H0}}$ and $H^1={{c.hodge_residual.1.H1}}$. For 500 random assignments per sheaf, (3.4) held without violation. The distance exceeded the lower bound by a factor of at least {{c.hodge_residual.0.min_ratio_to_lower|f2}} and stayed below the upper bound by a factor of at most {{c.hodge_residual.0.max_ratio_to_upper|f2}}. The harmonic dimension equalled $H^1$ in both cases ({{c.hodge_residual.0.harmonic_dim}} and {{c.hodge_residual.1.harmonic_dim}}).
:::

::: {custom-style="Statement"}
**Proposition 3.8** (heat flow converges to compatible data). Suppose $L\ne0$. Let $D\succ 0$ be a mass matrix on $C^0$ and solve $D\dot x=-Lx$. Let $P_D$ be the $D$-orthogonal projection onto $H^0$ and $\gamma$ the smallest positive eigenvalue of $D^{-1/2}LD^{-1/2}$. Then
:::

::: {custom-style="Statement Equation"}
$\|x(\theta)-P_Dx(0)\|_D\le e^{-\gamma\theta}\,\|x(0)-P_Dx(0)\|_D$ (3.6)
:::

::: {custom-style="Statement"}
If $H^0=0$, every state flows to zero.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 9.1.
:::

The proof is in V2. The substitution $u=D^{1/2}x$ makes the generator symmetric. Consensus is optional in ASE: it removes every component outside $H^0$, which is the sheaf form of oversmoothing in deep sheaf networks [5, 7]. Section 3.4 shows that the number of dimensions that survive is the dimension of a holonomy-fixed subspace, not the stalk dimension.

## 3.3 Nerves with coefficients

::: {custom-style="Statement"}
**Theorem 3.9** (Čech data sheaf). Let $𝒮$ be a sheaf of real vector spaces on a space $X$ and $𝒰=\{U_i\}_{i\in I}$ a finite open cover with nerve $N$. Finite-dimensional computation additionally requires every $𝒮(U_\sigma)$ used here to be finite dimensional. Set $F_𝒮(\sigma)=𝒮(U_\sigma)$, with the restriction maps of $𝒮$. Then $F_𝒮$ is a cellular sheaf on $N$, its cochain complex is the alternating Čech complex of $𝒰$ with coefficients in $𝒮$, and
:::

::: {custom-style="Statement Equation"}
$H^k(N;F_𝒮)=\text{Ȟ}^k(𝒰;𝒮)$ (3.7)
:::

::: {custom-style="Statement"}
If $𝒰$ is a Leray cover for $𝒮$, that is $H^q(U_\sigma;𝒮)=0$ for all $q\ge 1$ and all $\sigma\in N$, then $H^k(N;F_𝒮)\cong H^k(X;𝒮)$. For the constant sheaf $ℝ$ on a paracompact locally contractible space and a good cover, $F_𝒮$ is constant on $N$ and the isomorphism is the cohomological nerve theorem. The usual homotopy nerve theorem uses its standard numerability hypotheses.
:::

::: {custom-style="Statement Tag"}
Classical [6, 9, 22]; packaged for ASE.
:::

*Proof.* Compatibility is the functoriality of restriction in $𝒮$. The coboundary (3.2) is the Čech differential, written on ordered simplices, and alternating cochains are determined by their values there. Leray's theorem gives the isomorphism with sheaf cohomology [6, 9]. In a good cover every $U_\sigma$ is connected, so $𝒮(U_\sigma)=ℝ$ with identity restrictions. $\blacksquare$

::: {custom-style="Statement"}
**Example 3.10** (two arcs). Cover the circle by two arcs $U_0,U_1$ whose intersection has two components $A$ and $B$ (Figure 3a). The nerve is a single edge, so $H^1(N;ℝ)=0$. The Čech data sheaf has $F(0)=F(1)=ℝ$ and $F(01)=ℝ^2$, one value per component, with both restrictions equal to $(1,1)^{\top}$. Its cohomology is $H^0=H^1=ℝ$, the cohomology of the circle. The cover is Leray, since every component of every intersection is an arc. The coefficients carry the loop that the nerve misses.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

::: {custom-style="Check"}
*Numerical check.* Data sheaf $({{c.two_arcs.betti.0}},{{c.two_arcs.betti.1}})$; plain nerve $({{c.two_arcs.nerve_betti.0}},{{c.two_arcs.nerve_betti.1}})$.
:::

![**Figure 3.** A coarse cover whose nerve misses the loop. (a) Two arcs cover the circle; their overlap has two components $A$ and $B$. (b, c) Finer covers by three and six arcs, each refining the cover below it. (d) Bars of layer cohomology from the bottom (two arcs) to the top (six arcs). With the plain nerve, an $H^1$ bar is born at the middle layer; with the Čech data sheaf, the $H^1$ bar is full (Example 4.9).](fig/circle.png){width=100%}

The coefficient model matters as much as the nerve. A Leray cover justifies the Čech data complex; replacing its coefficients by one scalar per simplex additionally requires connected intersections in the constant-sheaf case. The two-arc cover is Leray, yet its disconnected overlap needs two coordinates. If intersections have higher cohomology, component counts alone do not suffice; retain that derived information or use an appropriate acyclic refinement.

## 3.4 Orthogonal sheaves and holonomy

::: {custom-style="Statement"}
**Definition 3.11** (orthogonal sheaf, transport, holonomy). Let $G=(V,E)$ be a connected graph and $F$ a graph sheaf with $F(v)=F(e)=ℝ^d$ and orthogonal restrictions $r_{ve}\in O(d)$. The transport along an edge $e$ from $u$ to $v$ is $T_{v\leftarrow u}=r_{ve}^{\top}r_{ue}$; the value $T_{v\leftarrow u}x_u$ is the unique value at $v$ that agrees with $x_u$ on $e$. For a closed walk $\gamma=(v_0,v_1,\ldots,v_\ell=v_0)$, the holonomy is $\text{Hol}(\gamma)=T_{v_0\leftarrow v_{\ell-1}}\cdots T_{v_1\leftarrow v_0}$. These matrices form the holonomy group $\text{Hol}(F,v_0)\subseteq O(d)$. A gauge transformation by $g_v,h_e\in O(d)$ replaces $r_{ve}$ by $h_e\,r_{ve}\,g_v^{\top}$; it changes every transport to $g_vT_{v\leftarrow u}g_u^{\top}$ and conjugates the holonomy group by $g_{v_0}$.
:::

::: {custom-style="Statement Tag"}
Classical in substance [30, 31].
:::

::: {custom-style="Statement"}
**Theorem 3.12** (holonomy theorem). Let $F$ be an orthogonal sheaf on a connected graph $G$.
:::

::: {custom-style="Statement"}
\(i) Evaluation at $v_0$ is an isomorphism $H^0(G;F)\cong\text{Fix}\,\text{Hol}(F,v_0)=\{\xi: h\xi=\xi\ \text{for all}\ h\in\text{Hol}(F,v_0)\}$.
:::

::: {custom-style="Statement"}
\(ii) The holonomy group is generated by the holonomies of the $|E|-|V|+1$ fundamental cycles of any spanning tree.
:::

::: {custom-style="Statement"}
\(iii) The dimensions satisfy
:::

::: {custom-style="Statement Equation"}
$\text{dim}\,H^1=d\,(|E|-|V|)+\text{dim}\,H^0$ (3.8)
:::

::: {custom-style="Statement"}
\(iv) Both dimensions are gauge invariant.
:::

::: {custom-style="Statement Tag"}
New in Part I as stated; (i) is the flat-bundle statement in graph form.
:::

*Proof.* Choose a spanning tree and gauge-fix along it: let $g_v$ be the transport from $v$ to $v_0$ along the tree path, so that every tree edge has identity transport. In this gauge the transport across a non-tree edge equals the holonomy of its fundamental cycle. Every closed walk is a product of fundamental cycles, because the fundamental group of a graph is free on them, which proves (ii). A section in this gauge is constant along the tree, $x_v=\xi$ for every $v$, and it closes across a non-tree edge exactly when the corresponding holonomy fixes $\xi$; this proves (i). Identity (3.3) with $\text{dim}\,C^0=d|V|$ and $\text{dim}\,C^1=d|E|$ gives (iii). Gauge transformations are sheaf isomorphisms, which gives (iv). $\blacksquare$

Table: **Table 2.** Holonomy check on a connected graph with 7 vertices, 11 edges and 5 fundamental cycles. The fixed dimension is computed from the holonomies alone; $H^0$ and $H^1$ are computed from the coboundary; the last column is $d(|E|-|V|)+\text{dim}\,H^0$.

| Stalk | Edge maps | Fixed dimension | $H^0$ | $H^1$ | Right side of (3.8) |
|:----|:-------------------|:----------|:----|:----|:----------|
| $ℝ^2$ | gauge of the identity | {{c.holonomy.0.fixed_dim}} | {{c.holonomy.0.H0}} | {{c.holonomy.0.H1}} | {{c.holonomy.0.H1_euler}} |
| $ℝ^2$ | random orthogonal | {{c.holonomy.1.fixed_dim}} | {{c.holonomy.1.H0}} | {{c.holonomy.1.H1}} | {{c.holonomy.1.H1_euler}} |
| $ℝ^2$ | one reflected edge | {{c.holonomy.2.fixed_dim}} | {{c.holonomy.2.H0}} | {{c.holonomy.2.H1}} | {{c.holonomy.2.H1_euler}} |
| $ℝ^3$ | gauge of the identity | {{c.holonomy.3.fixed_dim}} | {{c.holonomy.3.H0}} | {{c.holonomy.3.H1}} | {{c.holonomy.3.H1_euler}} |
| $ℝ^3$ | random orthogonal | {{c.holonomy.4.fixed_dim}} | {{c.holonomy.4.H0}} | {{c.holonomy.4.H1}} | {{c.holonomy.4.H1_euler}} |
| $ℝ^3$ | one edge rotated by 1.1 rad | {{c.holonomy.5.fixed_dim}} | {{c.holonomy.5.H0}} | {{c.holonomy.5.H1}} | {{c.holonomy.5.H1_euler}} |

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Corollary 3.13** (Harary's balance theorem [21]). Let the graph be connected, $d=1$ and $r_{ve}\in\{\pm1\}$, so that $F$ defines a signed graph. Then $H^0\neq 0$ if and only if every cycle has a positive product of signs, if and only if the vertices admit a 2-colouring in which positive edges join equal colours and negative edges join different colours.
:::

::: {custom-style="Statement Tag"}
Classical; here a corollary of Theorem 3.12.
:::

::: {custom-style="Check"}
*Numerical check.* In {{c.harary.graphs}} random connected signed graphs with 8 vertices, 8 to 14 edges and negative signs with probability 0.25, $H^0=1$ held exactly when a balanced 2-colouring existed, in {{c.harary.agree}} of {{c.harary.graphs}} graphs.
:::

::: {custom-style="Statement"}
**Proposition 3.14** (filled triangles are flat). Let $\tau=\{a,b,c\}$ be a 2-simplex with $F(\tau)=ℝ^d$, and let every restriction on $\tau$ and its faces be orthogonal and compatible. Then $T_{a\leftarrow c}\,T_{c\leftarrow b}\,T_{b\leftarrow a}=I$. Consequently an orthogonal sheaf on a 2-complex $K$ defines a representation $\pi_1(K,v_0)\to O(d)$, a local coefficient system in Steenrod's sense [31], whose fixed subspace is $H^0$.
:::

::: {custom-style="Statement Tag"}
New in Part I as stated.
:::

*Proof.* For an edge $e$ of $\tau$ with endpoints $p,q$, compatibility gives $r_{p\tau}=r_{e\tau}r_{pe}$, hence $r_{pe}=r_{e\tau}^{\top}r_{p\tau}$. Therefore $T_{q\leftarrow p}=r_{qe}^{\top}r_{pe}=r_{q\tau}^{\top}r_{e\tau}r_{e\tau}^{\top}r_{p\tau}=r_{q\tau}^{\top}r_{p\tau}$, and the product around $\tau$ telescopes to $I$. The fundamental group of a 2-complex is generated by edge loops modulo the boundaries of its 2-cells [22], so holonomy descends to $\pi_1$, and Theorem 3.12(i) identifies $H^0$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* For 200 random compatible orthogonal triangles with $d\in\{2,3,4\}$, the largest entry of $\text{Hol}-I$ around the boundary was {{c.triangle_flat_max_err|e1}}.
:::

::: {custom-style="Statement"}
**Remark 3.15** (flat is not trivial). Flatness says that holonomy around every filled triangle is trivial. It does not say that holonomy around a non-contractible loop is trivial. A flat orthogonal sheaf has $H^0\cong\text{Fix}\,\rho(\pi_1)$, which can be smaller than $ℝ^d$, and under heat flow (Proposition 3.8) exactly that many dimensions survive. On a graph without 2-cells flatness is vacuous, and every orthogonal sheaf is flat in this sense.
:::

::: {custom-style="Statement Tag"}
V2 Section 9, made precise.
:::

## 3.5 Three obstructions

The circle supports three different local-to-global failures. Their coefficient systems and conclusions differ, and V2 corrected two earlier statements that conflated them. The next proposition places all three on the same nerve.

::: {custom-style="Statement"}
**Proposition 3.16** (three obstructions on one cycle). Let $N$ be the 3-cycle with vertices $0,1,2$ and edges $01,12,02$. It is the nerve of three arcs that cover the circle with connected pairwise overlaps and no triple intersection.
:::

::: {custom-style="Statement"}
\(a) *Linear class.* For the constant sheaf $ℝ$ on $N$, $H^0\cong H^1\cong ℝ$, and the class of edge data $c$ is the oriented sum $c_{01}+c_{12}-c_{02}$. With unit weights,
:::

::: {custom-style="Statement Equation"}
$\text{min}_{x}\,\|\delta x-c\|=\frac{|c_{01}+c_{12}-c_{02}|}{\sqrt 3}$ (3.9)
:::

::: {custom-style="Statement"}
\(b) *Additive obstruction (angles).* Real angle lifts $\theta_i$ on the three arcs differ on each overlap by a constant in $2\pi ℤ$. These differences form a Čech 1-cocycle of the constant sheaf $2\pi ℤ$ whose oriented sum is $2\pi$, one full turn. No choice of lifts, even after shifting each by an arbitrary real constant, makes every overlap difference vanish; the least residual is $2\pi/\sqrt 3$. The local lifts form a torsor for an additive sheaf, not a linear vector sheaf. The circle still has global coordinates $(\cos\theta,\sin\theta)$; the obstruction concerns a global real angle.
:::

::: {custom-style="Statement"}
\(c) *Multiplicative obstruction (signs).* Take lines at 0°, 60° and 120° with representatives $u_0,u_1,u_2$ and transition signs $s_{ij}=\text{sign}\langle u_i,u_j\rangle$. The product of signs around the cycle is $-1$. The real sheaf with restrictions $(1,s_{ij})$ has $H^0=H^1=0$. The obstruction to coherent nonzero representatives is the nonzero class of $s$ in $H^1(N;ℤ_2)$, that is, the holonomy $-1$. It is not a nonzero $H^1$ of the twisted real sheaf.
:::

::: {custom-style="Statement Tag"}
V2 Sections 10 and 11, unified; the residual in (b) is check 11 of the register [19]; (3.9) is new in Part I.
:::

*Proof.* (a) In the edge order $(01,12,02)$, $\text{im}\,\delta$ is the plane orthogonal to $n=(1,1,-1)$, so the distance from $c$ to it is $|n\cdot c|/\sqrt 3$. (b) On an overlap, $\theta_j-\theta_i$ is continuous with values in $2\pi ℤ$, hence constant. Around the circle the angle increases by $2\pi$, so the oriented sum of the differences is $2\pi$. Changing the lifts by real constants adds a coboundary, which leaves the oriented sum unchanged; (3.9) then gives the residual. (c) A section satisfies $x_j=s_{ij}x_i$ on every edge, so after one loop $x_0=-x_0$. Hence $x_0=0$ and $H^0=0$. The coboundary is a $3\times 3$ matrix with trivial kernel, hence invertible, so $H^1=0$. Writing the signs additively in $ℤ_2$, their sum around the only cycle is $1$, so the class of $s$ in $H^1(N;ℤ_2)\cong ℤ_2$ is nonzero. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* The least-squares residual for the angle cocycle is {{c.obstructions.angle_residual|f4}}, against $2\pi/\sqrt 3={{c.obstructions.angle_residual_formula|f4}}$. The constant sheaf has $(H^0,H^1)=({{c.obstructions.constant_betti.0}},{{c.obstructions.constant_betti.1}})$, the sign-twisted sheaf has $({{c.obstructions.twisted_betti.0}},{{c.obstructions.twisted_betti.1}})$, and the computed holonomy is {{c.obstructions.holonomy|d}}.
:::

::: {custom-style="Statement"}
**Example 3.17** (mode shapes and subspaces). An isolated real vibration eigenmode is a line, because $u$ and $-u$ describe the same physical mode. Tracking it across a family of structural models therefore produces case (c), with alignment tested in the mass inner product for mass-normalised modes. For repeated or nearly repeated eigenvalues the right object is the modal subspace. Frames in it are defined up to $O(k)$, transports are orthogonal $k\times k$ matrices, and holonomy can be any element of $O(k)$. For orthonormal frames representing the same subspace on an overlap, the projector $UU^{\top}$ is frame invariant and agrees there. Varying modal subspaces form a global projector field only under the corresponding continuity and spectral-separation assumptions. The obstruction concerns frames, not subspaces, and a Grassmannian description replaces independent sign flips.
:::

::: {custom-style="Statement Tag"}
V2 Section 11.
:::

::: {custom-style="Statement"}
**Example 3.18** (a sheaf of sets with no global section). Take binary variables $x_1,x_2,x_3$ and the contexts $\{1,2\}$, $\{2,3\}$ and $\{1,3\}$. On each context the feasible local sections are the assignments with unequal bits. Every local set is nonempty, and every local section agrees on the shared variable with some section of each neighbouring context. Yet no global assignment satisfies all three inequalities. The coordinate sheaf on the same contexts has $H^1=0$ (Proposition 3.19), so no linear cohomology class detects the failure. This is the possibilistic form of contextuality [1] and the set-level analogue of the marginal extension problem [32]; Part V treats it.
:::

::: {custom-style="Statement Tag"}
V2 Section 16, as a sheaf of sets.
:::

::: {custom-style="Check"}
*Numerical check.* Local feasible sets have sizes {{x.feasible_cycle.local_sizes.0}}, {{x.feasible_cycle.local_sizes.1}} and {{x.feasible_cycle.local_sizes.2}}; every local section extends to each neighbouring context; {{x.feasible_cycle.global_sections}} of the 8 global assignments are feasible.
:::

## 3.6 Context sheaves

::: {custom-style="Statement"}
**Proposition 3.19** (coordinate sheaves on contexts). Let $S_1,\ldots,S_k\subseteq\{1,\ldots,D\}$ be nonempty contexts with union $J$, and let $n_j$ be the number of contexts containing the variable $j$. On the nerve of the contexts, where $\sigma$ is a simplex when $S_\sigma=\bigcap_{i\in\sigma}S_i$ is nonempty, define the coordinate sheaf $K(\sigma)=ℝ^{S_\sigma}$ with coordinate projections as restrictions. Then:
:::

::: {custom-style="Statement"}
\(i) $H^0\cong ℝ^{J}$, so a section is an assignment of every covered variable;
:::

::: {custom-style="Statement"}
\(ii) $H^k=0$ for all $k\ge 1$;
:::

::: {custom-style="Statement"}
\(iii) on the pairwise graph (the 1-skeleton of the nerve),
:::

::: {custom-style="Statement Equation"}
$\text{dim}\,H^1=\sum_{j\in J}\frac{(n_j-1)(n_j-2)}{2}$ (3.10)
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

*Proof.* The sheaf splits as $K=\bigoplus_{j\in J}K_j$, where $K_j(\sigma)=ℝ$ if $j\in S_\sigma$ and $0$ otherwise. Let $A_j$ be the set of contexts containing $j$. Every nonempty subset of $A_j$ is a simplex of the nerve, because its contexts share $j$. So the cochain complex of $K_j$ is the simplicial cochain complex of the full simplex on the $n_j$ vertices $A_j$. A full simplex is acyclic, which proves (i) and (ii). On the pairwise graph, $K_j$ sees the complete graph on $n_j$ vertices. That graph is connected and has $\binom{n_j}{2}-n_j+1=(n_j-1)(n_j-2)/2$ independent cycles. Summing over $j$ gives (3.10). $\blacksquare$

On the pairwise graph, $H^1$ counts redundant agreement constraints on the same variable; it does not certify an inconsistency. Filling the triangles of the nerve removes those classes. A nonzero $H^1$ on a pairwise context graph is therefore never by itself evidence of an obstruction.

::: {custom-style="Check"}
*Numerical check.* In {{c.contexts.trials}} random context families (4 to 7 variables, 3 to 6 contexts of size 2 or 3), (3.10) and statements (i) and (ii) held in every case. For the contexts $\{1,2\},\{1,3\},\{1,4\}$ of Figure 2b, the pairwise graph gives $(H^0,H^1)=({{c.contexts.example_pairwise.0}},{{c.contexts.example_pairwise.1}})$ and the full nerve gives $({{c.contexts.example_full.0}},{{c.contexts.example_full.1}})$. For the cycle $\{1,2\},\{2,3\},\{1,3\}$ of Example 3.18 the pairwise graph gives $({{c.contexts.cycle_example_pairwise.0}},{{c.contexts.cycle_example_pairwise.1}})$.
:::

## 3.7 Changing the base pullbacks and refinements

::: {custom-style="Statement"}
**Proposition 3.20** (inverse image along a simplicial map). Let $f:K\to L$ be a simplicial map and $G$ a cellular sheaf on $L$. Then $(f^{-1}G)(\sigma)=G(f(\sigma))$, with restrictions $G(f(\sigma)\le f(\tau))$, is a cellular sheaf on $K$. The map $f^{♯}:C^k(L;G)\to C^k(K;f^{-1}G)$ sends $y$ to the cochain with value $\varepsilon_\sigma\,y_{f(\sigma)}$ on $\sigma$ when $f$ is injective on $\sigma$, and $0$ when $f(\sigma)$ is degenerate. Here $\varepsilon_\sigma$ is the sign of the permutation that orders $f(\sigma)$. It satisfies $\delta f^{♯}=f^{♯}\delta$, and so induces maps $H^k(L;G)\to H^k(K;f^{-1}G)$.
:::

::: {custom-style="Statement Tag"}
Classical; the simplicial case of the inverse-image functoriality used by Russold [28].
:::

*Proof.* Compatibility of $f^{-1}G$ is inherited from $G$ because $f$ preserves faces. In $(\delta f^{♯}y)_\tau$, the terms whose faces map degenerately cancel in pairs exactly as in simplicial cohomology [22]; the remaining terms reproduce $(f^{♯}\delta y)_\tau$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* A filled triangle was collapsed onto an edge, with vertex stalks $ℝ^2$, an edge stalk $ℝ^3$ and random restrictions on the edge. The commutation defects $\delta f^{♯}-f^{♯}\delta$ were {{c.pullback.commute_deg0|g3}} in degree 0 and {{c.pullback.commute_deg1|g3}} in degree 1, and the pulled-back sheaf was compatible with $\delta^1\delta^0={{c.pullback.pulled_back_compatible|g3}}$.
:::

::: {custom-style="Statement"}
**Proposition 3.21** (refinement). Let $𝒱=\{V_j\}$ refine $𝒰=\{U_i\}$, with a refinement map $\varphi$ such that $V_j\subseteq U_{\varphi(j)}$. Then $\varphi$ induces a simplicial map $N(𝒱)\to N(𝒰)$, and the restrictions $𝒮(U_{\varphi(\sigma)})\to 𝒮(V_\sigma)$ define a morphism $\varphi^{-1}F^{𝒰}_𝒮\to F^{𝒱}_𝒮$. The induced map $H^k(N(𝒰);F^{𝒰}_𝒮)\to H^k(N(𝒱);F^{𝒱}_𝒮)$ does not depend on the choice of $\varphi$, and it commutes with the maps to $H^k(X;𝒮)$.
:::

::: {custom-style="Statement Tag"}
Classical [6, 9]; Russold's topological-type step [28].
:::

*Proof.* Nonempty intersections of the $V_j$ lie in the corresponding intersections of the $U_{\varphi(j)}$, which gives the simplicial map; the restriction maps of $𝒮$ give the morphism. Two refinement maps induce chain-homotopic cochain maps on Čech complexes, and both factor the canonical maps to sheaf cohomology [6, 9]. $\blacksquare$

Different covers at successive layers do not by themselves provide vertical maps. Refinement maps, a common refinement or a fixed complex with changing coefficients do. Once such maps are specified, horizontal restrictions and vertical maps must commute on every square (Proposition 5.2).
