"""Rebuild the paper from numerical result files already present in this directory."""
from pathlib import Path
import subprocess,sys

here=Path(__file__).resolve().parent
def run(*args):
    subprocess.run([str(x) for x in args],cwd=here,check=True)

run(sys.executable,'render.py')
run(sys.executable,'fig_p1.py')
run(sys.executable,'build_reference.py')
run('pandoc','-f','markdown+tex_math_dollars','paper.md','-o','paper_raw.docx',
    '--reference-doc=scholarly_ref.docx','--resource-path=.','--no-highlight')
run(sys.executable,'finalize_docx.py','paper_raw.docx','paper_layout.docx')
run(sys.executable,'postprocess.py','paper_layout.docx','ASE_Part_I_The_Two_Axes.docx')
