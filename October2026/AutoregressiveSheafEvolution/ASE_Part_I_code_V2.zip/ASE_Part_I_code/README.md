# Horizontally Topological, Vertically Algebraic

Companion source and results for Autoregressive Sheaf Evolution Part I.

## Reproduction

Use Python with NumPy and Matplotlib. The revision set OPENBLAS_NUM_THREADS=1.

1. Run `python p1_checks.py p1_checks.json` for fourteen primary checks.
2. Run `python p1_extras.py` for six supplementary checks.
3. Run `python tangent_mech.py` for the tangent diagnostic.
4. Run `python cs_validate.py` to compare fresh NumPy with the supplied C# output.
5. Run `python revision_audit.py` for assertions and covariance replay.
6. Run `python build_paper.py` to create Markdown, figures and Word. This also needs pandoc and python-docx.
7. Run `python verify_document.py` for structural Word-package checks.

The build uses render.py, fig_p1.py, build_reference.py, finalize_docx.py and
postprocess.py. Postprocessing normalises XML property order; it is not a
complete independent OOXML schema validator.

## Verification

The supplied_results folder preserves the four original result files. Root
result files were regenerated. repeatability.json records byte-identical
second runs of the two primary numerical result files in the revision
environment. revision_audit.json records the assertions and covariance replay.
document_checks.json records native mathematics, XML and relationship checks.
layout_review.json records pagination and the visual review.

All stated integer outcomes agree with the supplied run. Floating-point
residual differences across environments are below 1e-12 in absolute value.
Byte-identical results across library versions are not claimed.

NumPy matches all thirteen supplied C# lines. This environment has no .NET SDK,
so C# was not freshly compiled or executed. To add that check, build
cs/AsePartOne.csproj under .NET 8, compare its output to cs/cs_out.txt and rerun
cs_validate.py.

The supplied run records Python 3.13.16, NumPy 2.5.3, Matplotlib 3.11.2 and .NET
SDK 8.0.131. The revision used Python 3.12.14 and NumPy 2.3.5; its environment is
recorded in revision_audit.json.

## Mathematical qualifications

Vertical acyclicity concerns ordinary cohomology of a product with a least
layer. Barcodes add information but are not the only vertical invariant. A
zigzag can have nonzero higher derived limits for nonconstant coefficients;
this is not forced for every diagram. The two-arc circle cover is Leray: its
false birth comes from discarding disconnected-overlap coefficient data.
Numerical rank always has a cutoff. A fixed path tangent diagram on a
one-vertex base is distinct from a pointwise-varying morphism of constant
sheaves on a continuous domain.
