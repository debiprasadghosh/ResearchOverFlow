"""Build a plain scholarly Word style system from the supplied reference."""
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pathlib import Path
import sys

HERE=Path(__file__).parent
doc=Document(HERE/'ref.docx')
SIZE=float(sys.argv[1]) if len(sys.argv)>1 else 11.0
LINE=float(sys.argv[2]) if len(sys.argv)>2 else 1.12
for sec in doc.sections:
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.left_margin=sec.right_margin=Inches(.78)
    sec.top_margin=Inches(.67);sec.bottom_margin=Inches(.67)
    sec.header_distance=Inches(.28);sec.footer_distance=Inches(.3)
for st in doc.styles:
    for el in list(st.element.iter()):
        if el.tag in [qn('w:pBdr'),qn('w:shd')]:el.getparent().remove(el)
    if st.type==1:
        st.font.name='Liberation Serif';st.font.color.rgb=RGBColor(0,0,0)
        rp=st.element.get_or_add_rPr();rf=rp.find(qn('w:rFonts'))
        if rf is not None:
            for key in list(rf.attrib):
                if 'theme' in key.lower():del rf.attrib[key]
            rf.set(qn('w:cs'),'Liberation Serif');rf.set(qn('w:eastAsia'),'Liberation Serif')
def setstyle(name,size=SIZE,bold=False,italic=False,before=0,after=6,line=LINE,keep=False,font='Liberation Serif'):
    st=doc.styles[name];st.font.name=font;st.font.size=Pt(size);st.font.bold=bold;st.font.italic=italic
    st.font.color.rgb=RGBColor(0,0,0)
    pf=st.paragraph_format;pf.space_before=Pt(before);pf.space_after=Pt(after);pf.line_spacing=line
    pf.keep_with_next=keep;pf.keep_together=False;pf.left_indent=Inches(0);pf.right_indent=Inches(0)
    pf.first_line_indent=Inches(0);pf.alignment=WD_ALIGN_PARAGRAPH.LEFT
    return st
for name in ['Normal','Body Text','First Paragraph','Compact','Statement']:
    setstyle(name)
setstyle('Title',24,True,before=0,after=10,line=1.0,keep=True,font='Liberation Sans').paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
setstyle('Subtitle',12,False,True,after=10,line=1.0,keep=True).paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
setstyle('Author',10.5,after=2,line=1.0,keep=True).paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
setstyle('Date',9.5,after=10,line=1.0,keep=True).paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
setstyle('Abstract Title',11,True,before=4,after=5,keep=True,font='Liberation Sans')
setstyle('Abstract',10.4,after=5,line=1.07)
for lvl,size in [(1,15),(2,12),(3,11)]:
    setstyle(f'Heading {lvl}',size,True,before=13 if lvl==1 else 10,after=6,line=1,keep=True,font='Liberation Sans')
setstyle('Statement Tag',9,False,True,after=7,line=1.0)
setstyle('Gap',1,after=0,line=1.0)
setstyle('Check',10,after=7,line=1.07)
setstyle('Bibliography',9.4,after=3,line=1.04)
for name in ['Caption','Table Caption','Image Caption']:
    setstyle(name,9.5,after=9,line=1.05,keep=name=='Table Caption')
for name in ['Figure','Captioned Figure']:
    setstyle(name,11,before=5,after=3,line=1.0,keep=True).paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
for name in ['Equation','Statement Equation']:
    st=setstyle(name,10.5,before=3,after=7,line=1.0)
    st.paragraph_format.keep_together=True
    ppr=st.element.get_or_add_pPr()
    old=ppr.find(qn('w:tabs'))
    if old is not None:ppr.remove(old)
    tabs=OxmlElement('w:tabs')
    for val,pos in [('center',4997),('right',9994)]:
        e=OxmlElement('w:tab');e.set(qn('w:val'),val);e.set(qn('w:pos'),str(pos));tabs.append(e)
    ppr.append(tabs)
setstyle('Source Code',7.5,after=7,line=1.0,font='DejaVu Sans Mono')
for name in ['Verbatim Char']:
    st=doc.styles[name];st.font.name='DejaVu Sans Mono';st.font.size=Pt(8)
for sec in doc.sections:
    for part in [sec.header,sec.footer]:
        for para in part.paragraphs:
            for r in para.runs:r.font.color.rgb=RGBColor(0,0,0);r.font.name='Liberation Serif'
doc.save(HERE/'scholarly_ref.docx')
print('Reference size',SIZE,'line',LINE)
