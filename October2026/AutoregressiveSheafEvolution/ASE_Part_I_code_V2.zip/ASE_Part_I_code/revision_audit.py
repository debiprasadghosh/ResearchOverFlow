"""Audit the stored experiments and distinguish covariance evaluation effects."""
import json, math, platform
from pathlib import Path
import numpy as np
import p1_checks as pc

HERE=Path(__file__).resolve().parent

def replay_tangents():
    for fn in [pc.check_delta_squared,pc.check_hodge_residual,pc.check_holonomy,
               pc.check_triangle_flat,pc.check_harary,pc.check_contexts,
               pc.check_two_arcs,pc.check_pullback,pc.check_barcodes]:
        fn()
    rng=pc.rng;T=16
    a=[math.cos(math.pi*t/(2*T))**2 for t in range(T)]
    centres=np.array([[0.,0.],[2.5,0.],[1.2,2.2]])
    y=np.concatenate([c+.35*rng.standard_normal((10,2)) for c in centres])
    raw_low=stable_low=raw_negative=0;changed=0;maxdiff=0.
    for _ in range(1000):
        z=rng.standard_normal(2)/math.sqrt(a[15]);mr=np.eye(2);ms=np.eye(2)
        for t in range(15,0,-1):
            st=math.sqrt((1-a[t])/a[t]);sp=math.sqrt((1-a[t-1])/a[t-1]) if t>1 else 0.
            lam=1-sp/st
            logs=-((z-y)**2).sum(1)/(2*st*st)
            al=np.exp(logs-logs.max());al/=al.sum();m=al@y
            cr=(al[:,None]*y).T@y-np.outer(m,m)
            centred=y-m;cs=(al[:,None]*centred).T@centred
            maxdiff=max(maxdiff,float(np.linalg.norm(cr-cs,2)))
            mr=((1-lam)*np.eye(2)+lam/st**2*cr)@mr
            ms=((1-lam)*np.eye(2)+lam/st**2*cs)@ms
            z=(1-lam)*z+lam*m
        lr=pc.rank(mr,1e-14)<2;ls=pc.rank(ms,1e-14)<2
        raw_low+=lr;stable_low+=ls;changed+=lr!=ls
        raw_negative+=np.linalg.eigvalsh(cr)[0]<0
    return dict(tokens=1000,raw_deficient=int(raw_low),centred_deficient=int(stable_low),
                changed_classifications=int(changed),raw_final_negative_eigenvalues=int(raw_negative),
                maximum_covariance_difference=maxdiff,
                cutoff='singular value > 1e-14 * max(1, largest singular value)')

def validate_results():
    c=json.loads((HERE/'p1_checks.json').read_text());x=json.loads((HERE/'p1_extras.json').read_text())
    assert c['delta_squared']['compatible_max']==0 and c['delta_squared']['incompatible_max']>0
    assert all(v['violations']==0 and v['harmonic_dim']==v['H1'] for v in c['hodge_residual'])
    assert all(v['fixed_dim']==v['H0'] and v['H1']==v['H1_euler'] for v in c['holonomy'])
    assert int(c['harary']['agree'])==c['harary']['graphs']
    assert c['contexts']['formula_holds'] and c['barcodes']['multiplicities_nonnegative'] and c['barcodes']['ranks_reconstructed']
    assert c['stability']['violations']==0
    assert x['affine_bars']['agree']==x['affine_bars']['trials']
    assert x['product_random']['agree']==x['product_random']['trials']
    assert x['product_random']['zigzag']==[1,1,0]
    assert x['feasible_cycle']['global_sections']==0 and x['feasible_cycle']['pairwise_extendable']
    assert int(x['covariance']['eps_bound_holds'])==x['covariance']['trials']==x['covariance']['rank_equals_affine_dim']
    assert x['archive_barcode']['injective'] and x['archive_barcode']['all_reach_top']
    v=json.loads((HERE/'cs_validate.json').read_text())
    assert v['agree']==v['lines']==13
    return dict(all_assertions_pass=True,python=platform.python_version(),numpy=np.__version__,
                csharp_status='NumPy rerun matches supplied C# output; C# not recompiled in this environment')

if __name__=='__main__':
    out=dict(validation=validate_results(),covariance_replay=replay_tangents())
    (HERE/'revision_audit.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))
