# Figures for Part I. Data come from p1_checks.json and p1_extras.json; schematic figures are drawn directly.
import json, math, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon, FancyArrowPatch, Rectangle

here = os.path.dirname(os.path.abspath(__file__))
BLUE, FILL, OR, ORF, GREY, INK, MUTED = "#2a78d6", "#eef3fb", "#eb6834", "#fdeee7", "#9a9893", "#222222", "#555555"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.edgecolor": "#bdbbb6", "axes.linewidth": 0.6,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.labelcolor": INK, "mathtext.fontset": "dejavusans"})
R = json.load(open(os.path.join(here, "p1_checks.json")))
X = json.load(open(os.path.join(here, "p1_extras.json")))


def arrow(ax, a, b, color=BLUE, lw=1.0, ms=7, ls="-", z=5):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=ms, color=color, lw=lw, linestyle=ls, zorder=z,
                                 shrinkA=2, shrinkB=2))


# ------------------------------------------------------------------ Figure 1: the two axes
def fig_stack(path):
    W, H = 6.4, 4.7
    fig = plt.figure(figsize=(W, H), dpi=300)
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, W); ax.set_ylim(0, H); ax.axis("off")
    x0, w, dx, h = 0.95, 3.25, 0.75, 0.62
    ys = [0.12, 0.95, 1.78, 2.61, 3.44]                # layer t = 4 (bottom) ... t = 0 (top)
    labels = ["t = 4   (s large)", "t = 3", "t = 2", "t = 1", "t = 0   (s small)"]

    def P(u, v, y):
        return (x0 + u * w + v * dx, y + v * h)

    pts = np.array([[0.16, 0.42], [0.22, 0.58], [0.27, 0.47], [0.52, 0.40], [0.58, 0.52], [0.61, 0.37],
                    [0.80, 0.62], [0.86, 0.55], [0.83, 0.70]])
    covers = [
        [((0.52, 0.52), 0.44)],
        [((0.30, 0.50), 0.28), ((0.70, 0.52), 0.28)],
        [((0.22, 0.49), 0.15), ((0.57, 0.43), 0.15), ((0.83, 0.62), 0.15)],
        [((0.19, 0.50), 0.09), ((0.27, 0.49), 0.07), ((0.55, 0.46), 0.09), ((0.61, 0.38), 0.06), ((0.83, 0.62), 0.10)],
        [((p[0], p[1]), 0.035) for p in pts],
    ]
    token = [(0.40, 0.22), (0.47, 0.33), (0.53, 0.40), (0.555, 0.43), (0.565, 0.445)]
    for k, y in enumerate(ys):
        poly = [P(0, 0, y), P(1, 0, y), P(1, 1, y), P(0, 1, y)]
        ax.add_patch(Polygon(poly, closed=True, fc="#f7f7f5", ec="#c9c7c2", lw=0.8, zorder=1))
        ax.text(x0 - 0.12, y + 0.06, labels[k], ha="right", va="bottom", fontsize=7.2, color=MUTED)
        cov = covers[k]
        for i in range(len(cov)):
            for j in range(i + 1, len(cov)):
                (ci, ri), (cj, rj) = cov[i], cov[j]
                if math.dist(ci, cj) < ri + rj:
                    a, b = P(*ci, y), P(*cj, y)
                    ax.plot([a[0], b[0]], [a[1], b[1]], color=OR, lw=0.9, zorder=3)
        for (c, r) in cov:
            th = np.linspace(0, 2 * math.pi, 120)
            ring = [P(c[0] + r * math.cos(t), c[1] + r * math.sin(t) * 0.92, y) for t in th]
            ax.add_patch(Polygon(ring, closed=True, fc=ORF, ec=OR, lw=0.7, alpha=0.55, zorder=2))
        for p in pts:
            q = P(p[0], p[1], y); ax.plot([q[0]], [q[1]], "o", ms=2.3, color=INK, zorder=4)
        tq = P(*token[k], y)
        ax.plot([tq[0]], [tq[1]], "o", ms=4.6, color=BLUE, mec="white", mew=0.6, zorder=6)
        ax.add_patch(Polygon([(tq[0] + 0.07, tq[1] + 0.03), (tq[0] + 0.19, tq[1] + 0.03), (tq[0] + 0.19, tq[1] + 0.15),
                              (tq[0] + 0.07, tq[1] + 0.15)], closed=True, fc=FILL, ec=BLUE, lw=0.8, zorder=6))
    for k in range(4):
        a, b = P(*token[k], ys[k]), P(*token[k + 1], ys[k + 1])
        ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=7, color=BLUE, lw=1.0, zorder=5,
                                     shrinkA=3, shrinkB=3))
    xq = 5.55
    for k, y in enumerate(ys):
        yc = y + 0.31
        ax.add_patch(Polygon([(xq - 0.2, yc - 0.14), (xq + 0.2, yc - 0.14), (xq + 0.2, yc + 0.14), (xq - 0.2, yc + 0.14)],
                             closed=True, fc=FILL, ec=BLUE, lw=0.9, zorder=3))
        ax.text(xq, yc, f"V$_{{{4 - k}}}$", ha="center", va="center", fontsize=8.5, color=INK, zorder=4)
        if k < 4:
            ax.add_patch(FancyArrowPatch((xq, yc + 0.15), (xq, ys[k + 1] + 0.31 - 0.15), arrowstyle="-|>", mutation_scale=8,
                                         color=BLUE, lw=1.0))
            ax.text(xq + 0.1, (yc + ys[k + 1] + 0.31) / 2, f"ρ$_{{{4 - k}}}$", ha="left", va="center", fontsize=7.5, color=INK)
    ax.text(xq, 4.55, "vertical: algebraic", ha="center", va="center", fontsize=8.2, weight="bold", color=BLUE)
    ax.text(xq, 4.36, "the token's vertical fibre diagram,\na representation of the layer order", ha="center", va="top",
            fontsize=6.6, color=MUTED, linespacing=1.1)
    ax.text(x0 + w / 2 + dx / 2, 4.55, "horizontal: topological", ha="center", va="center", fontsize=8.2, weight="bold", color=OR)
    ax.text(x0 + w / 2 + dx / 2, 4.36, "each layer: a cover at scale s$_t$, its nerve, a data sheaf on the nerve", ha="center",
            va="top", fontsize=6.6, color=MUTED)
    fig.savefig(path, dpi=300, facecolor="white")
    plt.close(fig)


# ------------------------------------------------------------------ Figure 2: the bases
def fig_bases(path):
    fig, axs = plt.subplots(1, 4, figsize=(6.6, 2.25), dpi=300)
    for ax in axs:
        ax.set_aspect("equal"); ax.axis("off")
    ax = axs[0]; ax.set_xlim(-0.2, 3.2); ax.set_ylim(-0.4, 2.9)
    cs = [(0.8, 0.9), (1.7, 0.75), (1.25, 1.65), (2.45, 1.55)]
    for c in cs:
        ax.add_patch(Circle(c, 0.72, fc=ORF, ec=OR, lw=0.7, alpha=0.55))
    for tri in [(0, 1, 2), (1, 2, 3)]:
        ax.add_patch(Polygon([cs[k] for k in tri], closed=True, fc="#f6c9b3", ec="none", alpha=0.9, zorder=3))
    for i, j in [(0, 1), (1, 2), (0, 2), (1, 3), (2, 3)]:
        ax.plot([cs[i][0], cs[j][0]], [cs[i][1], cs[j][1]], color=OR, lw=1.1, zorder=4)
    for c in cs:
        ax.plot(*c, "o", ms=3.4, color=INK, zorder=5)
    ax.set_title("(a) cover and its nerve", fontsize=7.6, color=INK, pad=2)
    ax = axs[1]; ax.set_xlim(-0.2, 3.2); ax.set_ylim(-0.4, 2.9)
    ctx = [(0.55, 0.55), (2.45, 0.55), (1.5, 2.15)]
    ax.add_patch(Polygon(ctx, closed=True, fc=FILL, ec="none", zorder=1))
    for i, j in [(0, 1), (1, 2), (0, 2)]:
        ax.plot([ctx[i][0], ctx[j][0]], [ctx[i][1], ctx[j][1]], color=BLUE, lw=1.1, zorder=2)
    for (x, y), lab in zip(ctx, ["{1,2}", "{1,3}", "{1,4}"]):
        ax.add_patch(Rectangle((x - 0.36, y - 0.17), 0.72, 0.34, fc="white", ec=BLUE, lw=0.9, zorder=3))
        ax.text(x, y, lab, ha="center", va="center", fontsize=6.6, color=INK, zorder=4)
    ax.text(1.5, 1.05, "shared\nvariable 1", ha="center", va="center", fontsize=5.8, color=MUTED, zorder=4)
    ax.set_title("(b) contexts of variables", fontsize=7.6, color=INK, pad=2)
    ax = axs[2]; ax.set_xlim(-1.0, 2.2); ax.set_ylim(-0.4, 2.9)
    ys = np.linspace(0.0, 2.45, 5)
    for k, y in enumerate(ys):
        ax.plot(0.5, y, "o", ms=4.2, color=BLUE, zorder=3)
        ax.text(0.85, y, ["T", "T−1", "⋮", "1", "0"][k], ha="left", va="center", fontsize=6.8, color=INK)
        if k < 4:
            ax.add_patch(FancyArrowPatch((0.5, y + 0.09), (0.5, ys[k + 1] - 0.09), arrowstyle="-|>", mutation_scale=6,
                                         color=BLUE, lw=0.9))
    ax.text(-0.15, 1.2, "bottom\nto top", ha="right", va="center", fontsize=6.2, color=MUTED)
    ax.set_title("(c) layer order", fontsize=7.6, color=INK, pad=2)
    ax = axs[3]; ax.set_xlim(-0.2, 3.2); ax.set_ylim(-0.4, 2.9)
    c0 = (1.5, 1.2)
    for k in range(7):
        ang = 2 * math.pi * k / 7 + 0.3
        p = (c0[0] + 1.05 * math.cos(ang), c0[1] + 1.05 * math.sin(ang))
        ax.plot([c0[0], p[0]], [c0[1], p[1]], color=GREY, lw=0.9, zorder=1)
        ax.plot(*p, "s", ms=3.3, color=INK, zorder=3)
    ax.plot(*c0, "o", ms=6.0, color=BLUE, mec="white", mew=0.6, zorder=4)
    ax.set_title("(d) observation star", fontsize=7.6, color=INK, pad=2)
    fig.tight_layout(pad=0.4)
    fig.savefig(path, dpi=300, facecolor="white"); plt.close(fig)


# ------------------------------------------------------------------ Figure 3: a coarse cover whose nerve misses the loop
def fig_circle(path):
    C = X["circle"]
    covers = [[(-1.2, math.pi + 1.2), (math.pi - 1.2, 2 * math.pi + 1.2)],
              [(2 * math.pi * j / 3 - 0.1, 2 * math.pi * (j + 1) / 3 + 0.1) for j in range(3)],
              [(2 * math.pi * j / 6 - 0.05, 2 * math.pi * (j + 1) / 6 + 0.05) for j in range(6)]]
    titles = ["(a) bottom: 2 arcs", "(b) middle: 3 arcs", "(c) top: 6 arcs"]
    cols = [[OR, BLUE], [OR, BLUE, "#7a7873"], [OR, BLUE] * 3]
    fig = plt.figure(figsize=(6.6, 2.45), dpi=300)
    th = np.linspace(0, 2 * math.pi, 400)
    for k, cov in enumerate(covers):
        ax = fig.add_axes([0.0 + 0.175 * k, 0.10, 0.17, 0.74]); ax.set_aspect("equal"); ax.axis("off")
        ax.set_xlim(-1.5, 1.5); ax.set_ylim(-1.5, 1.5)
        ax.plot(np.cos(th), np.sin(th), color="#cfcdc8", lw=0.8)
        for j, (a, b) in enumerate(cov):
            rad = 1.16 + (0.13 * (j % 2) if len(cov) != 3 else 0.1 * j)
            tt = np.linspace(a, b, 200)
            ax.plot(rad * np.cos(tt), rad * np.sin(tt), color=cols[k][j], lw=2.0, solid_capstyle="round")
        if k == 0:
            for (a, b), lab in [((math.pi - 1.2, math.pi + 1.2), "A"), ((-1.2, 1.2), "B")]:
                tt = np.linspace(a, b, 120)
                ax.plot(0.80 * np.cos(tt), 0.80 * np.sin(tt), color=INK, lw=2.2, solid_capstyle="butt")
                mid = (a + b) / 2
                ax.text(0.55 * math.cos(mid), 0.55 * math.sin(mid), lab, ha="center", va="center", fontsize=7.5, color=INK)
            ax.text(0, -1.62, "overlap = A ⊔ B", ha="center", va="top", fontsize=6.4, color=MUTED)
        ax.set_title(titles[k], fontsize=7.4, color=INK, pad=1)
    ax = fig.add_axes([0.58, 0.20, 0.40, 0.62])
    rows = [("H$^0$, plain nerve and Čech data sheaf", C["plain_nerve"]["H0_bars"]),
            ("H$^1$, Čech data sheaf", C["data_sheaf"]["H1_bars"]),
            ("H$^1$, plain nerve", C["plain_nerve"]["H1_bars"])]
    for y, (lab, bars) in zip([2, 1, 0], rows):
        for key, mult in bars.items():
            a, b = [int(v) for v in key.strip("[]").split(",")]
            ax.plot([a - 1 - 0.3, b - 1 + 0.3], [y, y], color=BLUE, lw=2.4, solid_capstyle="butt")
            ax.plot([a - 1 - 0.3], [y], "o", ms=3.0, color=BLUE)
        ax.text(-0.3, y + 0.2, lab, ha="left", va="bottom", fontsize=6.6, color=INK)
    ax.set_yticks([])
    ax.set_xticks(range(3)); ax.set_xticklabels(["2 arcs", "3 arcs", "6 arcs"], fontsize=6.6)
    ax.set_xlim(-0.5, 2.5); ax.set_ylim(-0.5, 2.75)
    ax.set_title("(d) bars, bottom to top", fontsize=7.4, color=INK, pad=3)
    for s in ["top", "right", "left"]:
        ax.spines[s].set_visible(False)
    fig.savefig(path, dpi=300, facecolor="white"); plt.close(fig)


# ------------------------------------------------------------------ Figure 4: exact versus effective rank
def fig_tangent(path):
    t = R["tangent"]
    layers = t["median_path_layers"]; mp = np.array(t["median_path"])
    x = np.arange(len(layers))
    fig, ax = plt.subplots(figsize=(6.0, 2.6), dpi=300)
    ax.plot(x, mp[:, 0], color=BLUE, lw=2.0, marker="o", ms=3.2, zorder=3, label="largest singular value")
    ax.plot(x, mp[:, 1], color=OR, lw=2.0, marker="o", ms=3.2, zorder=3, label="smallest singular value")
    for tau, lab in [(1e-2, "τ = 10⁻²"), (1e-3, "τ = 10⁻³")]:
        ax.axhline(tau, color=GREY, lw=0.8, ls=(0, (4, 3)), zorder=1)
        ax.text(x[0] - 0.2, tau * 1.12, lab, fontsize=6.6, color=MUTED, ha="left", va="bottom")
    ax.set_yscale("log"); ax.set_ylim(2e-4, 1.0)
    ax.set_xticks(x); ax.set_xticklabels([str(l) for l in layers])
    ax.set_xlabel("layer reached by the token (bottom layer 15 on the left, top layer 0 on the right)")
    ax.set_ylabel("median singular value of ∂zₜ/∂z₁₅", fontsize=7.4)
    ax.grid(axis="y", color="#e6e4df", lw=0.6, zorder=0, which="major")
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)
    ax.text(x[-1] + 0.22, mp[-1, 0], f"{mp[-1,0]:.3f}", fontsize=6.6, color=BLUE, ha="left", va="center")
    ax.text(x[-1] + 0.22, mp[-1, 1], f"{mp[-1,1]:.4f}", fontsize=6.6, color=OR, ha="left", va="center")
    ax.set_xlim(-0.5, x[-1] + 1.3)
    ax.legend(frameon=False, fontsize=6.8, loc="upper right")
    fig.tight_layout()
    fig.savefig(path, dpi=300, facecolor="white"); plt.close(fig)


# ------------------------------------------------------------------ Figure 5: H0 barcode of a nested ball filtration
def fig_barcode(path):
    import p1_extras as PE
    Y = PE.barcode_archive()
    A = X["archive_barcode"]
    comps = {int(k): v for k, v in A["components"].items()}
    scales = {int(k): v for k, v in A["scales"].items()}
    layers = sorted(comps, reverse=True)
    births = [int(t) for t, v in sorted(A["births"].items(), key=lambda kv: -int(kv[0])) for _ in range(v)]
    fig = plt.figure(figsize=(6.4, 2.75), dpi=300)
    a1 = fig.add_axes([0.06, 0.17, 0.27, 0.70])
    a1.plot(Y[:, 0], Y[:, 1], "o", ms=2.6, color=INK)
    a1.set_aspect("equal"); a1.set_xticks([]); a1.set_yticks([])
    a1.set_title(f"archive ({A['records']} records)", fontsize=7.6, color=INK, pad=3)
    for side in ["top", "right"]:
        a1.spines[side].set_visible(False)
    a2 = fig.add_axes([0.42, 0.17, 0.56, 0.70])
    xs = {t: i for i, t in enumerate(layers)}
    for k, b in enumerate(births):
        a2.plot([xs[b] - 0.35, len(layers) - 0.6], [k, k], color=BLUE, lw=2.0, solid_capstyle="butt")
        a2.plot([xs[b] - 0.35], [k], "o", ms=2.6, color=BLUE)
    a2.set_xlim(-0.8, len(layers) - 0.5); a2.set_ylim(-0.8, len(births) - 0.2)
    a2.set_xticks(range(len(layers)))
    a2.set_xticklabels([f"{t}\n{scales[t]:.2g}" for t in layers], fontsize=6.0)
    a2.set_yticks([])
    a2.set_xlabel("layer t (top row) and scale s$_t$ (bottom row), from bottom to top of the stack", fontsize=7)
    for i, t in enumerate(layers):
        a2.text(i, len(births) - 0.25, str(comps[t]), ha="center", va="bottom", fontsize=6.3, color=MUTED)
    a2.set_title("H$^0$ bars in the token's direction (components at each layer)", fontsize=7.6, color=INK, pad=11)
    for side in ["top", "right", "left"]:
        a2.spines[side].set_visible(False)
    fig.savefig(path, dpi=300, facecolor="white"); plt.close(fig)


# ------------------------------------------------------------------ Figure 6: the product and vertical acyclicity
def fig_product(path):
    fig = plt.figure(figsize=(6.6, 2.7), dpi=300)
    ax = fig.add_axes([0.0, 0.0, 0.40, 0.92]); ax.axis("off"); ax.set_xlim(-0.55, 3.45); ax.set_ylim(-0.25, 3.6)
    base = [(0.75, 0.0), (2.35, 0.05), (1.75, 0.55)]
    ys = [0.15, 1.35, 2.55]
    names = ["G$_T$", "G$_{T-1}$", "G$_0$"]
    def pt(v, y):
        return (base[v][0], base[v][1] + y)
    for k, y in enumerate(ys):
        ax.add_patch(Polygon([(0.35, y - 0.25), (2.75, y - 0.25), (3.15, y + 0.8), (0.75, y + 0.8)], closed=True,
                             fc="#f7f7f5", ec="#c9c7c2", lw=0.7, zorder=1))
        for i, j in [(0, 1), (1, 2), (0, 2)]:
            a, b = pt(i, y), pt(j, y)
            ax.plot([a[0], b[0]], [a[1], b[1]], color=OR, lw=1.2, zorder=3)
        for v in range(3):
            ax.plot(*pt(v, y), "o", ms=3.6, color=INK, zorder=4)
        ax.text(0.28, y + 0.2, names[k], ha="right", va="center", fontsize=7.4, color=INK)
    for k in range(2):
        for v in range(3):
            arrow(ax, pt(v, ys[k]), pt(v, ys[k + 1]), color=BLUE, lw=0.8, ms=6, ls=(0, (3, 2)))
    # highlighted square: vertex 0, edge (0,1) at the two lower layers
    m0, m1 = [((pt(0, y)[0] + pt(1, y)[0]) / 2, (pt(0, y)[1] + pt(1, y)[1]) / 2) for y in ys[:2]]
    ax.add_patch(Polygon([pt(0, ys[0]), m0, m1, pt(0, ys[1])], closed=True, fc=FILL, ec=BLUE, lw=0.9, alpha=0.9, zorder=2))
    ax.text(1.55, 3.48, "(a) one sheaf on Q × P", ha="center", va="center", fontsize=7.4, color=INK)
    # (b) commuting square
    bx = fig.add_axes([0.40, 0.0, 0.27, 0.92]); bx.axis("off"); bx.set_xlim(0, 3.0); bx.set_ylim(-0.25, 3.6)
    P0, P1, P2, P3 = (0.55, 0.75), (2.45, 0.75), (0.55, 2.45), (2.45, 2.45)
    for p, lab in [(P0, "G$_T$(u)"), (P1, "G$_T$(e)"), (P2, "G$_{T-1}$(u)"), (P3, "G$_{T-1}$(e)")]:
        bx.text(*p, lab, ha="center", va="center", fontsize=7.6, color=INK,
                bbox=dict(boxstyle="round,pad=0.25", fc=FILL, ec=BLUE, lw=0.8))
    arrow(bx, (P0[0] + 0.45, P0[1]), (P1[0] - 0.45, P1[1]), color=OR, lw=1.0)
    arrow(bx, (P2[0] + 0.55, P2[1]), (P3[0] - 0.55, P3[1]), color=OR, lw=1.0)
    arrow(bx, (P0[0], P0[1] + 0.22), (P2[0], P2[1] - 0.22), color=BLUE, lw=1.0)
    arrow(bx, (P1[0], P1[1] + 0.22), (P3[0], P3[1] - 0.22), color=BLUE, lw=1.0)
    bx.text(1.5, 0.55, "restriction", ha="center", va="top", fontsize=6.2, color=OR)
    bx.text(1.5, 2.65, "restriction", ha="center", va="bottom", fontsize=6.2, color=OR)
    bx.text(0.42, 1.6, "vertical", ha="right", va="center", fontsize=6.2, color=BLUE, rotation=90)
    bx.text(2.58, 1.6, "vertical", ha="left", va="center", fontsize=6.2, color=BLUE, rotation=90)
    bx.text(1.5, 1.6, "commutes", ha="center", va="center", fontsize=6.6, color=MUTED, style="italic")
    bx.text(1.5, 3.48, "(b) every square commutes", ha="center", va="center", fontsize=7.4, color=INK)
    # (c) the persistence module and what the product sees
    cx = fig.add_axes([0.67, 0.0, 0.33, 0.92]); cx.axis("off"); cx.set_xlim(0, 3.2); cx.set_ylim(-0.25, 3.6)
    terms = [(1.15, 0.35, "H$^k$(Q; G$_T$)"), (1.15, 1.35, "H$^k$(Q; G$_{T-1}$)"), (1.15, 2.05, "⋮"), (1.15, 2.75, "H$^k$(Q; G$_0$)")]
    for x, y, lab in terms:
        cx.text(x, y, lab, ha="center", va="center", fontsize=7.4, color=INK)
    arrow(cx, (1.15, 0.55), (1.15, 1.15), color=BLUE, lw=1.0)
    arrow(cx, (1.15, 1.55), (1.15, 1.9), color=BLUE, lw=1.0)
    arrow(cx, (1.15, 2.2), (1.15, 2.55), color=BLUE, lw=1.0)
    cx.add_patch(Rectangle((0.42, 0.14), 1.46, 0.42, fc="none", ec=OR, lw=1.0))
    cx.text(1.15, -0.08, "= H$^k$(Q × P; G)", ha="center", va="center", fontsize=7.2, color=OR)
    cx.plot([2.05, 2.15, 2.15, 2.05], [0.25, 0.25, 2.85, 2.85], color=BLUE, lw=0.9)
    cx.text(2.25, 1.55, "barcode:\na vertical\ninvariant", ha="left", va="center", fontsize=6.6, color=BLUE)
    cx.text(1.6, 3.48, "(c) what each invariant sees", ha="center", va="center", fontsize=7.4, color=INK)
    fig.savefig(path, dpi=300, facecolor="white"); plt.close(fig)


if __name__ == "__main__":
    os.makedirs(os.path.join(here, "fig"), exist_ok=True)
    fig_stack(os.path.join(here, "fig", "stack.png"))
    fig_bases(os.path.join(here, "fig", "bases.png"))
    fig_circle(os.path.join(here, "fig", "circle.png"))
    fig_tangent(os.path.join(here, "fig", "tangent.png"))
    fig_barcode(os.path.join(here, "fig", "barcode.png"))
    fig_product(os.path.join(here, "fig", "product.png"))
    print("ok")
