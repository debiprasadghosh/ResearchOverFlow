# Assemble the paper source and fill every {{...}} placeholder from the machine-readable results.
import json, os, re, subprocess, sys, shutil

here = os.path.dirname(os.path.abspath(__file__))
parts = ["a_front.md", "b_horizontal.md", "c_vertical.md", "d_product.md"]
src = "\n".join(open(os.path.join(here, "src", p), encoding="utf-8").read() for p in parts)

data = {
    "c": json.load(open(os.path.join(here, "p1_checks.json"))),
    "x": json.load(open(os.path.join(here, "p1_extras.json"))),
    "v": json.load(open(os.path.join(here, "cs_validate.json"))),
    "t": json.load(open(os.path.join(here, "tangent_mech.json"))),
    "a": json.load(open(os.path.join(here, "revision_audit.json"))),
}
import numpy, matplotlib, platform
dotnet = subprocess.run(["dotnet", "--version"], capture_output=True, text=True).stdout.strip() if shutil.which("dotnet") else "not available"
data["env"] = dict(python=platform.python_version(), numpy=numpy.__version__, matplotlib=matplotlib.__version__, dotnet=dotnet)

SUP = str.maketrans("-0123456789", "⁻⁰¹²³⁴⁵⁶⁷⁸⁹")


def lookup(path):
    head, *rest = path.split(".")
    v = data[head]
    for key in rest:
        if isinstance(v, list):
            v = v[int(key)]
        elif key in v:
            v = v[key]
        else:
            raise KeyError(f"missing key {key!r} in {path}")
    return v


def num(v):
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, str) and re.fullmatch(r"-?\d+(\.\d+)?", v):
        return float(v) if "." in v else int(v)
    return v


def fmt(v, f):
    v = num(v)
    if f in ("", None):
        if isinstance(v, float) and v.is_integer():
            v = int(v)
        s = f"{v:,}" if isinstance(v, int) and abs(v) >= 1000 else str(v)
        return s.replace("-", "−") if isinstance(v, (int, float)) else s
    if f == "d":
        return str(int(round(float(v)))).replace("-", "−")
    if f in ("f1", "f2", "f3", "f4"):
        return f"{float(v):.{f[1]}f}"
    if f == "g3":
        return "0" if float(v) == 0 else f"{float(v):.3g}"
    if f == "e1":
        m, e = f"{float(v):.1e}".split("e")
        return f"{m} × 10{str(int(e)).translate(SUP)}"
    if f == "pct1":
        return f"{100 * float(v):.1f}%"
    raise ValueError(f"unknown format {f}")


def fill(m):
    body = m.group(1).replace("\\|", "|")
    if body.startswith("file:"):
        return open(os.path.join(here, body[5:]), encoding="utf-8").read().rstrip("\n")
    if body == "cs_rows":
        V = data["v"]
        return "\n".join(f"| `{a}` | `{b}` | {'yes' if a == b else 'NO'} |" for a, b in zip(V["csharp"], V["python"]))
    path, _, f = body.partition("|")
    return fmt(lookup(path.strip()), f.strip())


out = re.sub(r"\{\{(.+?)\}\}", fill, src)
out = out.replace("$\\blacksquare$", "∎")
# an empty two-point paragraph after every tag keeps adjacent statement boxes from merging
# Statements use ordinary typography; no shaded panels or artificial gap paragraphs.
left = re.findall(r"\{\{\s*[a-z]", out)
assert not left, "unfilled placeholders remain"
open(os.path.join(here, "paper.md"), "w", encoding="utf-8").write(out)
print("paper.md written;", len(out.split()), "words")
