---
title: "Horizontally Topological, Vertically Algebraic"
subtitle: "The two axes of Autoregressive Sheaf Evolution. Part I: sheaves on covers and representations of the layer order"
author:
  - "Debi Prasad Ghosh"
  - "Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India"
date: "Defensible Intelligence series · Autoregressive Sheaf Evolution, Part I · 18 October 2026 · “Respect science. Import emotion.”"
abstract: |
  Autoregressive Sheaf Evolution (ASE) replaces the single Euclidean retrieval geometry of Autoregressive Diffusion Evolution (ADE) by local data spaces on every layer of a stack. Its organising principle is that each layer is horizontally topological and each token's journey is vertically algebraic. This paper, the first part of the ASE book, makes the principle precise, proves what it delivers and marks where it stops. The horizontal axis is a cellular data sheaf on the nerve of a layer cover. Its stalks are data spaces, not charts; its sections are compatible assignments; residuals are coboundaries; cohomology measures the edge data that no assignment explains. We prove residual bounds with declared units, a holonomy theorem for orthogonal sheaves that contains Harary's balance theorem, and a cohomology formula for coordinate sheaves on variable contexts. We also separate three obstructions that are easily conflated: linear H¹ classes, additive angle torsors and multiplicative sign holonomy. The vertical axis is a representation of the layer order. Every specified transport, tangent or homogenised affine diagram decomposes into interval modules. We show that a clean top produces births at the top, that homogenisation adds exactly one full bar, that exact bars usually survive while sensitivity contracts, and that layer cohomology has only full bars when the layers use nested Leray covers of one space. The central new result is vertical acyclicity: for every sheaf on the product of a base with the layer order, cohomology equals that of the bottom layer. In this product model ordinary cohomology discards all upper-layer changes. Layerwise diagrams and their barcodes retain additional vertical information. A zigzag need not share this acyclicity. ADE is the trivial product with a separate observation star. Twenty numerical checks support the constructions. A fresh NumPy recomputation also matches all thirteen supplied C# output lines. The numerical results are accompanied by explicit tolerances and reproducibility limits.
---

# 1 Introduction

Autoregressive Diffusion Evolution (ADE) treats an archive of evaluated designs as the memory of a denoising stack [16, 17]. A token starts at the bottom of a stack of layers $t=T,\ldots,1,0$. At each layer it reads the archive through a Gaussian kernel at scale $s_t$ and moves towards the read. In the scaled coordinate used by the conversion proposal [19, Proposition 6.2], with records $y_i$, prior weights $w_i$ and $s_t^2=(1-a_t)/a_t$,

::: {custom-style="Equation"}
$m_t(z)=\sum_i \alpha_i(z)\,y_i,\quad \alpha_i(z)\propto w_i\exp\left(-\frac{\|z-y_i\|^2}{2s_t^2}\right),\quad z_{t-1}=(1-\lambda_t)\,z_t+\lambda_t\,m_t(z_t)+\nu_t$ (1.1)
:::

where $\nu_t$ is the scaled noise increment. Every layer uses the same retrieval geometry: one Euclidean space, one distance and one global read.

The revised conversion proposal [19], cited below as V2, replaces that single geometry by local data spaces, compatibility maps and scale-dependent covers. It states the organising principle in one line: horizontal topology within each layer and vertical algebra across layers (Figure 1). This paper is Part I of the resulting six-part book, covering its first two chapters: sheaves on covers, and representations of the layer order. Its task is to make the principle mathematically precise, to prove what it delivers and to mark where it stops.

![**Figure 1.** The two axes. Each layer carries a cover at its scale, the nerve of the cover and a data sheaf on the nerve (left). A token visits one cell per layer; the data spaces of the visited cells and the maps between them form the token's vertical fibre diagram, a representation of the layer order (right). The small squares mark the stalk at the visited cell.](fig/stack.png){width=96%}

## 1.1 The principle as mathematics

*Horizontal.* A layer is a base with a finite cover. The nerve of the cover carries a cellular data sheaf. Stalks are data spaces attached to cells, and restriction maps say how the data on a cell are observed on an overlap. A section is a compatible assignment, a residual is a coboundary, and cohomology measures what cannot be made compatible.

*Vertical.* A token's journey produces a diagram of linear maps indexed by the layer order. Such a diagram is a representation of a finite linear order and decomposes into interval modules; its barcode is a complete invariant. The cohomology of the layers, compared across layers, forms another such representation.

*Product.* The two axes combine into one sheaf on the product of a base with the layer order. The main new theorem of this paper, Theorem 5.3, says that the cohomology of every such sheaf equals the cohomology of its bottom layer. Whatever the stack does above a fixed bottom is invisible to ordinary cohomology of the whole product. Layerwise diagrams and barcodes can distinguish such stacks. The theorem therefore justifies retaining vertical algebra rather than replacing the diagram by product cohomology; it does not assert that barcodes are the only possible vertical invariant.

## 1.2 Contributions

- **A typed vocabulary.** Four bases are kept distinct: the cover nerve, the context nerve, the layer order and the observation star (Definition 2.4). Stalks are data spaces, restrictions run from vertices to overlaps, and residuals carry declared units.
- **Horizontal results.** We show that the coboundary squares to zero exactly when every diamond of restriction maps commutes, which in degree one are the triangle compatibility identities (Proposition 3.5), and prove a residual sandwich with its Hodge split (Proposition 3.7). We also give nerves with coefficients, including a two-arc example in which the coefficients rather than the nerve carry the loop (Theorem 3.9, Example 3.10). For orthogonal sheaves we prove a holonomy theorem with a dimension formula and Harary's theorem as a corollary (Theorem 3.12, Corollary 3.13), and show that filled triangles are flat (Proposition 3.14). Three obstructions are separated (Proposition 3.16), and coordinate sheaves on contexts receive a cohomology formula (Proposition 3.19).
- **Vertical results.** Homogenisation adds exactly one full bar (Proposition 4.4), and a clean top produces births at the top (Proposition 4.5). The tangent rank equals the affine dimension of the records, so exact bars survive while effective rank contracts (Proposition 4.6). Leray covers give full bars in layer cohomology (Proposition 4.8). Component counts are stable under perturbation (Proposition 4.11).
- **The product.** We give a slice description of the fixed-base product (Proposition 5.1) and prove vertical acyclicity (Theorem 5.3). A zigzag counterexample shows that the theorem needs a least element (Remark 5.5). Moving tokens become fixed-base diagrams in Lagrangian coordinates (Proposition 5.7), and ADE is the trivial product (Proposition 5.9).
- **Evidence.** Twenty numerical checks support the quantitative examples (Table 3). An independent NumPy rerun matches the supplied thirteen-line C# output (Appendix A). The revision also compares raw-moment and centred covariance evaluation within the same tangent experiment.

## 1.3 Scope and status of statements

Part I is foundational. It makes no claim about search performance, sampling validity or engineering feasibility; those belong to Parts II to VI, and V2 lists the falsifiable hypotheses C1 to C5 that will test them. Numbered statements carry provenance notes. *Classical* means a known result restated in ASE notation. *V2* means a statement of the conversion proposal, sometimes with a new proof. *New in Part I* means a statement proved here for the first time in this programme. New statements carry proofs and numerical checks. Computational stalks and barcode modules are finite dimensional and real. Derived-functor arguments take place in the ambient category of all sheaves of real vector spaces, which has enough injectives. The general product theorem does not require finite-dimensional stalks; its layerwise barcodes do require finite-dimensional cohomology. Algebraic statements extend to fields where their proofs apply; orthogonality, norms and eigenvalues use real inner products.

## 1.4 Conventions and notation

Table: **Table 1.** Notation used throughout Part I.

| Symbol | Meaning |
|:--------------|:--------------------------------------------------------------|
| $t=T,\ldots,0$ | layers, traversed from the bottom ($T$) to the top ($0$) |
| $P$ | the layer order $T<T-1<\cdots<0$ with the Alexandrov topology of up-sets |
| $\uparrow t$ | the up-set $\{t,t-1,\ldots,0\}$, the smallest open set containing $t$ |
| $X_t,\ 𝒰_t,\ N_t$ | base, finite open cover and nerve at layer $t$ |
| $F(\sigma),\ r_{\sigma\tau}$ | stalk on the cell $\sigma$ and restriction for $\sigma\le\tau$ |
| $C^k,\ \delta,\ H^k$ | cochains, coboundary and cohomology |
| $W,\ L=\delta^{\top}W\delta$ | positive definite edge weights in declared units, sheaf Laplacian |
| $V_t,\ \rho_t$ | data space of the visited cell, vertical map $V_t\to V_{t-1}$ |
| $𝕀[b,d]$ | interval module born at layer $b$ and alive up to layer $d$, with $b\ge d$ |
| $\Phi_t,\ \Phi_t^{-1}$ | deterministic step $X\to X$ and inverse image of sheaves |
| $Q$ | a finite poset, usually the face poset of a nerve |

# 2 Finite posets and the bases of ASE

The computational bases of Part I are finite posets, usually face posets of nerves. Their sheaves become finite diagrams of vector spaces. General spaces also appear in the Leray and product theorems; those results justify, under stated hypotheses, which finite summaries represent their cohomology.

::: {custom-style="Statement"}
**Definition 2.1** (Alexandrov topology [2]). Let $(Q,\le)$ be a finite poset. A subset $U\subseteq Q$ is open when it is an up-set: $p\in U$ and $p\le q$ imply $q\in U$. The set $\uparrow p=\{q: q\ge p\}$ is the smallest open set containing $p$, and these sets form a basis.
:::

::: {custom-style="Statement Tag"}
Classical.
:::

::: {custom-style="Statement"}
**Proposition 2.2** (sheaves on a finite poset). Let $Q$ be a finite poset with its Alexandrov topology.
:::

::: {custom-style="Statement"}
\(i) The assignment $ℱ\mapsto F$, $F(p)=ℱ(\uparrow p)$, is an equivalence between sheaves of real vector spaces on $Q$ and functors $F:Q\to\text{Vect}$, where $Q$ has one arrow $p\to q$ whenever $p\le q$. The stalk at $p$ is $F(p)$, and the restriction for $p\le q$ is the map $F(p\le q):F(p)\to F(q)$.
:::

::: {custom-style="Statement"}
\(ii) Global sections are the limit: $\Gamma(Q;F)=\text{lim}_Q F=\{(x_p)\in\prod_p F(p): F(p\le q)\,x_p=x_q\}$.
:::

::: {custom-style="Statement"}
\(iii) Sheaf cohomology is the derived limit, $H^k(Q;F)\cong R^k\text{lim}_Q F$. It is computed by the cochain complex whose degree-$n$ term is the product of the spaces $F(p_n)$ over the strictly increasing chains $p_0<\cdots<p_n$, with differential
:::

::: {custom-style="Statement Equation"}
$(dx)(c)=\sum_{k=0}^{n}(-1)^k\,x(\partial_kc)+(-1)^{n+1}F(p_n\le p_{n+1})\,x(\partial_{n+1}c)$ (2.1)
:::

::: {custom-style="Statement"}
Here $c=(p_0<\cdots<p_{n+1})$ and $\partial_kc$ deletes $p_k$ from the chain.
:::

::: {custom-style="Statement Tag"}
Classical [8, 14, 25].
:::

*Proof.* Every open cover of $\uparrow p$ contains $\uparrow p$ itself, because some member contains $p$ and is an up-set. The sheaf condition on basic open sets is therefore empty, and a sheaf is the same as a presheaf on the basis. Since $\uparrow q\subseteq\uparrow p$ exactly when $p\le q$, that basis category is $Q$. Gluing over the cover $\{\uparrow p\}_{p\in U}$ gives $ℱ(U)=\text{lim}_{p\in U}F(p)$, which proves (i) and, for $U=Q$, (ii). Sheaf cohomology is the right derived functor of global sections, here the derived limit. The Bousfield–Kan cosimplicial replacement computes derived limits [8], and normalisation keeps only strictly increasing chains, which gives (2.1). ∎

::: {custom-style="Statement"}
**Proposition 2.3** (cellular cohomology is sheaf cohomology). Let $K$ be a finite simplicial complex with face poset $𝒫(K)$ and let $F$ be a cellular sheaf on $K$ (Definition 3.2). The cohomology of the cellular cochain complex of Definition 3.4 is isomorphic to $R^k\text{lim}_{𝒫(K)}F$.
:::

::: {custom-style="Statement Tag"}
Classical [14, 29].
:::

::: {custom-style="Check"}
*Numerical check.* The complex (2.1) and the cellular complex were computed independently on three sheaves on a triangle. The constant sheaf on the hollow triangle gives $(1,1,0)$ against cellular $(1,1)$; a sign-twisted sheaf gives $(0,0,0)$ against $(0,0)$; the constant sheaf on the filled triangle gives $(1,0,0)$ against $(1,0,0)$.
:::

ASE uses four different bases. They are all finite posets, and they answer different questions. Confusing them is the most common source of wrong statements in the earlier drafts, so we fix them now.

::: {custom-style="Statement"}
**Definition 2.4** (the four bases of ASE). Each sheaf in an ASE implementation records which of the following bases it lives on.
:::

::: {custom-style="Statement"}
\(a) *Cover base.* At layer $t$, a finite open cover $𝒰_t$ of the region of $X_t$ visited by tokens, its nerve $N_t$ and the face poset of $N_t$. It describes spatial locality, and the horizontal data sheaves live on it.
:::

::: {custom-style="Statement"}
\(b) *Context base.* A family of variable subsets $S_1,\ldots,S_k\subseteq\{1,\ldots,D\}$, with its nerve (a simplex whenever the contexts share a variable) or its pairwise graph. It describes partial information and objective incidence. An incidence hypergraph is not automatically the nerve of an open cover of design space.
:::

::: {custom-style="Statement"}
\(c) *Layer order.* The chain $P$ of Table 1. It describes computation depth, and the vertical diagrams live on it.
:::

::: {custom-style="Statement"}
\(d) *Observation star.* At one layer, a token vertex joined to one leaf per retrieved record. The token stalk is the token frame, a leaf stalk is the record space and an edge stalk is a common observation space, reached from the token by $Q_i$ and from the record by $R_i$. The harmonic read of Part II is the harmonic extension of the record values over this star [19, Proposition 5.1]. The star is auxiliary and is never the cover nerve.
:::

::: {custom-style="Statement Tag"}
V2 Section 1, made a definition.
:::

![**Figure 2.** The four bases. (a) A cover by four disks and its nerve, with both triangles filled because their triple intersections are nonempty. (b) Three contexts that share the variable 1. (c) The layer order from the bottom $T$ to the top $0$. (d) The observation star of one token and seven retrieved records.](fig/bases.png){width=100%}

The distinction between (a) and (d) resolves an apparent paradox noted in V2. ADE has a one-vertex cover nerve at every layer, yet it reads a nontrivial archive. The nerve describes the base geometry; the star describes the observations attached to it (Proposition 5.9).


# 3 The horizontal axis sheaves on covers

## 3.1 Layer covers and data sheaves

::: {custom-style="Statement"}
**Definition 3.1** (layer cover). Fix layers $t=T,\ldots,1,0$, traversed from bottom to top, a schedule $0<a_t\le a_{t-1}\le 1$ and the scale $s_t=\sqrt{(1-a_t)/a_t}$. Each layer has a base $X_t$ and a finite open cover $𝒰_t=\{U_i\}_{i\in I_t}$ of the region visited by its tokens. Its nerve $N_t$ has a simplex $\sigma\subseteq I_t$ whenever $U_\sigma=\bigcap_{i\in\sigma}U_i$ is nonempty. A cover diameter near $\kappa s_t$ is a resolution policy, not an existence theorem for a good cover.
:::

::: {custom-style="Statement Tag"}
V2 Definition 2.1.
:::

::: {custom-style="Statement"}
**Definition 3.2** (cellular data sheaf). A cellular sheaf $F$ on a simplicial complex $K$ assigns a finite-dimensional real vector space $F(\sigma)$, the stalk, to every simplex $\sigma$, and a linear map $r_{\sigma\tau}:F(\sigma)\to F(\tau)$ to every face relation $\sigma\le\tau$, such that $r_{\sigma\sigma}=I$ and $r_{\tau\rho}\,r_{\sigma\tau}=r_{\sigma\rho}$ whenever $\sigma\le\tau\le\rho$. The maps run from a vertex to its overlaps. A graph sheaf specifies only vertex and edge stalks. To extend it over a triangle $\tau$, one must give $F(\tau)$ and maps $r_{e\tau}$ satisfying, for each vertex $u$ of $\tau$ and the two edges $e,e'$ of $\tau$ through $u$,
:::

::: {custom-style="Statement Equation"}
$r_{e\tau}\,r_{ue}=r_{e'\tau}\,r_{ue'}$ (3.1)
:::

::: {custom-style="Statement Tag"}
V2 Definition 2.2, with the triangle identities made explicit [3, 5, 14].
:::

A stalk is the data space attached to one cell [27]. It need not be a chart coordinate system, and the restriction maps need not be invertible. A rectangular restriction models a partial observation. An affine coordinate transition requires an affine sheaf or a torsor (Section 3.5), and nonlinear coordinate changes require sheaves of nonlinear objects, which Part I does not treat. Orthogonal restrictions form a tractable subclass (Section 3.4); they do not define what a sheaf is.

::: {custom-style="Statement"}
**Remark 3.3** (units before residuals). Before overlap residuals are compared, every edge stalk carries declared units and a weight $W_e\succ 0$ that makes $\|c\|_{W_e}^2=c^{\top}W_ec$ dimensionless, for instance $W_e=\text{diag}(1/\sigma_j^2)$ with $\sigma_j$ the tolerance of component $j$. If the units of an edge stalk change by an invertible matrix $S_e$, so that $c\mapsto S_ec$, the weight must change to $S_e^{-\top}W_eS_e^{-1}$. With that convention the energy, its kernel and every bound of Propositions 3.7 and 3.8 are unchanged. Without it, mixing displacement, stress and dimensionless utilisation changes the energy and the resulting read. Vertex coordinates are also nondimensionalised before a Euclidean state norm is used; a change of vertex units requires transforming the vertex metric as well.
:::

::: {custom-style="Statement Tag"}
V2 Section 2, made quantitative.
:::

## 3.2 Cochains, residuals and cohomology

::: {custom-style="Statement"}
**Definition 3.4** (cochains, coboundary, residual). Order the vertices of $K$. For a $(k+1)$-simplex $\tau=\{v_0<\cdots<v_{k+1}\}$, let $\tau_i$ be the face opposite $v_i$. Set $C^k(K;F)=\bigoplus_{\text{dim}\,\sigma=k}F(\sigma)$ and
:::

::: {custom-style="Statement Equation"}
$(\delta x)_\tau=\sum_{i=0}^{k+1}(-1)^i\,r_{\tau_i\tau}\,x_{\tau_i}$ (3.2)
:::

::: {custom-style="Statement"}
For an edge $e=\{u<v\}$ this reads $(\delta x)_e=r_{ve}x_v-r_{ue}x_u$. Cohomology is $H^k=\text{ker}\,\delta^k/\text{im}\,\delta^{k-1}$. A section is a vertex assignment $x\in C^0$ with $\delta x=0$, so $H^0$ is the space of sections. The residual of an arbitrary assignment $x$ is $\delta x\in C^1$.
:::

::: {custom-style="Statement Tag"}
Classical [14, 20].
:::

::: {custom-style="Statement"}
**Proposition 3.5** (the coboundary needs compatibility; Euler identity). Let restriction maps be given only for codimension-one faces.
:::

::: {custom-style="Statement"}
\(i) $\delta^{k+1}\delta^k=0$ for every $k$ if and only if every diamond commutes: for every simplex $\rho$ and every face $\sigma$ of codimension two in $\rho$, with $\tau,\tau'$ the two faces between them, $r_{\tau\rho}\,r_{\sigma\tau}=r_{\tau'\rho}\,r_{\sigma\tau'}$. In degree one these are exactly the triangle identities (3.1).
:::

::: {custom-style="Statement"}
\(ii) The diamonds commute exactly when the codimension-one maps extend to a cellular sheaf. Hence the full condition $\delta\circ\delta=0$ characterises cellular sheaves among these simplicial data. If $\delta^1\delta^0\ne0$, the quotient defining $H^1$ is not defined.
:::

::: {custom-style="Statement"}
\(iii) $\sum_k(-1)^k\,\text{dim}\,C^k=\sum_k(-1)^k\,\text{dim}\,H^k$. On a graph,
:::

::: {custom-style="Statement Equation"}
$\text{dim}\,H^0-\text{dim}\,H^1=\sum_v\text{dim}\,F(v)-\sum_e\text{dim}\,F(e)$ (3.3)
:::

::: {custom-style="Statement Tag"}
Classical in substance; (i) is the reason for V2's triangle requirement.
:::

*Proof.* (i) Let $\rho$ have dimension $k+2$ and let $\sigma$ be the face of $\rho$ missing the vertices $v_i$ and $v_j$, with $i<j$. The block of $\delta^{k+1}\delta^k$ in row $\rho$ and column $\sigma$ comes from the two intermediate faces, each missing one of these vertices. The two routes carry the signs $(-1)^j(-1)^i$ and $(-1)^i(-1)^{j-1}$, which are opposite, so the block is $\pm(r_{\tau\rho}r_{\sigma\tau}-r_{\tau'\rho}r_{\sigma\tau'})$. Every block vanishes exactly when every diamond commutes. (ii) If the diamonds commute, define $r_{\sigma\rho}$ as the composite along any maximal chain of faces from $\sigma$ to $\rho$. Two such chains add the missing vertices in different orders, and adjacent transpositions of that order, which are diamond moves, connect them, so the composite is well defined and compatible. The converse is immediate. (iii) Rank–nullity in each degree. ∎

::: {custom-style="Check"}
*Numerical check.* On a filled triangle with random vertex stalks, edge stalks $ℝ^4$ and triangle stalk $ℝ^2$, built to satisfy (3.1), the largest entry of $\delta^1\delta^0$ is 0. After one vertex-to-edge map is replaced by a random matrix it is 1.78. The alternating sums of cochain and cohomology dimensions agree (−2 and −2).
:::

A residual is always a coboundary. A nonzero disagreement $\delta x$ is therefore never itself a nonzero cohomology class. Cohomology in degree one measures something else: edge data that no assignment can produce. The next proposition makes both statements quantitative.

::: {custom-style="Statement"}
**Proposition 3.6** (positive sheaf energy). Let $W=\bigoplus_eW_e$ be positive definite on $C^1$, with the units of Remark 3.3. The energy $E(x)=\frac{1}{2}\|\delta x\|_W^2=\frac{1}{2}x^{\top}Lx$, with $L=\delta^{\top}W\delta$, is positive semidefinite and $\text{ker}\,L=H^0$.
:::

::: {custom-style="Statement Tag"}
V2 Lemma 2.3; $L$ is the sheaf Laplacian [20].
:::

::: {custom-style="Statement"}
**Proposition 3.7** (distance to consistency; Hodge split). Let $F$ be a graph sheaf, $P$ the orthogonal projection of $C^0$ onto $H^0$, and suppose $L\ne0$. Let $\lambda_2$ and $\lambda_{\text{max}}$ be its smallest positive and largest eigenvalue. For $x\in C^0$,
:::

::: {custom-style="Statement Equation"}
$\frac{\|\delta x\|_W}{\sqrt{\lambda_{\text{max}}}}\le\|x-Px\|\le\frac{\|\delta x\|_W}{\sqrt{\lambda_2}}$ (3.4)
:::

::: {custom-style="Statement"}
Moreover $C^1=\text{im}\,\delta\oplus\text{ker}(\delta^{\top}W)$, orthogonally for the inner product $W$, and $\text{ker}(\delta^{\top}W)\cong H^1$. For prescribed edge data $c\in C^1$, write $c=\delta y+h$ with $h\in\text{ker}(\delta^{\top}W)$. Then
:::

::: {custom-style="Statement Equation"}
$\text{min}_{x}\,\|\delta x-c\|_W=\|h\|_W$ (3.5)
:::

::: {custom-style="Statement"}
and the minimum is zero exactly when the class of $c$ in $H^1=C^1/\text{im}\,\delta$ vanishes.
:::

::: {custom-style="Statement Tag"}
Classical in substance [20]; stated here with units and the least-squares reading.
:::

*Proof.* The vector $x-Px$ is orthogonal to $\text{ker}\,L$, so it lies in the span of the eigenvectors of $L$ with positive eigenvalues. Since $\|\delta x\|_W^2=x^{\top}Lx=(x-Px)^{\top}L(x-Px)$, this quantity lies between $\lambda_2\|x-Px\|^2$ and $\lambda_{\text{max}}\|x-Px\|^2$. The $W$-orthogonal complement of $\text{im}\,\delta$ is $\{c:\langle\delta y,c\rangle_W=0\ \text{for all}\ y\}=\text{ker}(\delta^{\top}W)$. Its dimension is $\text{dim}\,C^1-\text{rank}\,\delta=\text{dim}\,H^1$ because a graph has no $2$-cells. The least-squares problem projects $c$ onto $\text{im}\,\delta$ and leaves $h$. ∎

::: {custom-style="Check"}
*Numerical check.* We used a connected graph with 8 vertices and 13 edges, stalks $ℝ^2$, and edge weights drawn uniformly from $[0.5,2]$. One sheaf is gauge-equivalent to the constant sheaf, with $H^0=2$ and $H^1=12$. The other has random orthogonal maps, with $H^0=0$ and $H^1=10$. For 500 random assignments per sheaf, (3.4) held without violation. The distance exceeded the lower bound by a factor of at least 1.07 and stayed below the upper bound by a factor of at most 0.72. The harmonic dimension equalled $H^1$ in both cases (12 and 10).
:::

::: {custom-style="Statement"}
**Proposition 3.8** (heat flow converges to compatible data). Suppose $L\ne0$. Let $D\succ 0$ be a mass matrix on $C^0$ and solve $D\dot x=-Lx$. Let $P_D$ be the $D$-orthogonal projection onto $H^0$ and $\gamma$ the smallest positive eigenvalue of $D^{-1/2}LD^{-1/2}$. Then
:::

::: {custom-style="Statement Equation"}
$\|x(\theta)-P_Dx(0)\|_D\le e^{-\gamma\theta}\,\|x(0)-P_Dx(0)\|_D$ (3.6)
:::

::: {custom-style="Statement"}
If $H^0=0$, every state flows to zero.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 9.1.
:::

The proof is in V2. The substitution $u=D^{1/2}x$ makes the generator symmetric. Consensus is optional in ASE: it removes every component outside $H^0$, which is the sheaf form of oversmoothing in deep sheaf networks [5, 7]. Section 3.4 shows that the number of dimensions that survive is the dimension of a holonomy-fixed subspace, not the stalk dimension.

## 3.3 Nerves with coefficients

::: {custom-style="Statement"}
**Theorem 3.9** (Čech data sheaf). Let $𝒮$ be a sheaf of real vector spaces on a space $X$ and $𝒰=\{U_i\}_{i\in I}$ a finite open cover with nerve $N$. Finite-dimensional computation additionally requires every $𝒮(U_\sigma)$ used here to be finite dimensional. Set $F_𝒮(\sigma)=𝒮(U_\sigma)$, with the restriction maps of $𝒮$. Then $F_𝒮$ is a cellular sheaf on $N$, its cochain complex is the alternating Čech complex of $𝒰$ with coefficients in $𝒮$, and
:::

::: {custom-style="Statement Equation"}
$H^k(N;F_𝒮)=\text{Ȟ}^k(𝒰;𝒮)$ (3.7)
:::

::: {custom-style="Statement"}
If $𝒰$ is a Leray cover for $𝒮$, that is $H^q(U_\sigma;𝒮)=0$ for all $q\ge 1$ and all $\sigma\in N$, then $H^k(N;F_𝒮)\cong H^k(X;𝒮)$. For the constant sheaf $ℝ$ on a paracompact locally contractible space and a good cover, $F_𝒮$ is constant on $N$ and the isomorphism is the cohomological nerve theorem. The usual homotopy nerve theorem uses its standard numerability hypotheses.
:::

::: {custom-style="Statement Tag"}
Classical [6, 9, 22]; packaged for ASE.
:::

*Proof.* Compatibility is the functoriality of restriction in $𝒮$. The coboundary (3.2) is the Čech differential, written on ordered simplices, and alternating cochains are determined by their values there. Leray's theorem gives the isomorphism with sheaf cohomology [6, 9]. In a good cover every $U_\sigma$ is connected, so $𝒮(U_\sigma)=ℝ$ with identity restrictions. ∎

::: {custom-style="Statement"}
**Example 3.10** (two arcs). Cover the circle by two arcs $U_0,U_1$ whose intersection has two components $A$ and $B$ (Figure 3a). The nerve is a single edge, so $H^1(N;ℝ)=0$. The Čech data sheaf has $F(0)=F(1)=ℝ$ and $F(01)=ℝ^2$, one value per component, with both restrictions equal to $(1,1)^{\top}$. Its cohomology is $H^0=H^1=ℝ$, the cohomology of the circle. The cover is Leray, since every component of every intersection is an arc. The coefficients carry the loop that the nerve misses.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

::: {custom-style="Check"}
*Numerical check.* Data sheaf $(1,1)$; plain nerve $(1,0)$.
:::

![**Figure 3.** A coarse cover whose nerve misses the loop. (a) Two arcs cover the circle; their overlap has two components $A$ and $B$. (b, c) Finer covers by three and six arcs, each refining the cover below it. (d) Bars of layer cohomology from the bottom (two arcs) to the top (six arcs). With the plain nerve, an $H^1$ bar is born at the middle layer; with the Čech data sheaf, the $H^1$ bar is full (Example 4.9).](fig/circle.png){width=100%}

The coefficient model matters as much as the nerve. A Leray cover justifies the Čech data complex; replacing its coefficients by one scalar per simplex additionally requires connected intersections in the constant-sheaf case. The two-arc cover is Leray, yet its disconnected overlap needs two coordinates. If intersections have higher cohomology, component counts alone do not suffice; retain that derived information or use an appropriate acyclic refinement.

## 3.4 Orthogonal sheaves and holonomy

::: {custom-style="Statement"}
**Definition 3.11** (orthogonal sheaf, transport, holonomy). Let $G=(V,E)$ be a connected graph and $F$ a graph sheaf with $F(v)=F(e)=ℝ^d$ and orthogonal restrictions $r_{ve}\in O(d)$. The transport along an edge $e$ from $u$ to $v$ is $T_{v\leftarrow u}=r_{ve}^{\top}r_{ue}$; the value $T_{v\leftarrow u}x_u$ is the unique value at $v$ that agrees with $x_u$ on $e$. For a closed walk $\gamma=(v_0,v_1,\ldots,v_\ell=v_0)$, the holonomy is $\text{Hol}(\gamma)=T_{v_0\leftarrow v_{\ell-1}}\cdots T_{v_1\leftarrow v_0}$. These matrices form the holonomy group $\text{Hol}(F,v_0)\subseteq O(d)$. A gauge transformation by $g_v,h_e\in O(d)$ replaces $r_{ve}$ by $h_e\,r_{ve}\,g_v^{\top}$; it changes every transport to $g_vT_{v\leftarrow u}g_u^{\top}$ and conjugates the holonomy group by $g_{v_0}$.
:::

::: {custom-style="Statement Tag"}
Classical in substance [30, 31].
:::

::: {custom-style="Statement"}
**Theorem 3.12** (holonomy theorem). Let $F$ be an orthogonal sheaf on a connected graph $G$.
:::

::: {custom-style="Statement"}
\(i) Evaluation at $v_0$ is an isomorphism $H^0(G;F)\cong\text{Fix}\,\text{Hol}(F,v_0)=\{\xi: h\xi=\xi\ \text{for all}\ h\in\text{Hol}(F,v_0)\}$.
:::

::: {custom-style="Statement"}
\(ii) The holonomy group is generated by the holonomies of the $|E|-|V|+1$ fundamental cycles of any spanning tree.
:::

::: {custom-style="Statement"}
\(iii) The dimensions satisfy
:::

::: {custom-style="Statement Equation"}
$\text{dim}\,H^1=d\,(|E|-|V|)+\text{dim}\,H^0$ (3.8)
:::

::: {custom-style="Statement"}
\(iv) Both dimensions are gauge invariant.
:::

::: {custom-style="Statement Tag"}
New in Part I as stated; (i) is the flat-bundle statement in graph form.
:::

*Proof.* Choose a spanning tree and gauge-fix along it: let $g_v$ be the transport from $v$ to $v_0$ along the tree path, so that every tree edge has identity transport. In this gauge the transport across a non-tree edge equals the holonomy of its fundamental cycle. Every closed walk is a product of fundamental cycles, because the fundamental group of a graph is free on them, which proves (ii). A section in this gauge is constant along the tree, $x_v=\xi$ for every $v$, and it closes across a non-tree edge exactly when the corresponding holonomy fixes $\xi$; this proves (i). Identity (3.3) with $\text{dim}\,C^0=d|V|$ and $\text{dim}\,C^1=d|E|$ gives (iii). Gauge transformations are sheaf isomorphisms, which gives (iv). ∎

Table: **Table 2.** Holonomy check on a connected graph with 7 vertices, 11 edges and 5 fundamental cycles. The fixed dimension is computed from the holonomies alone; $H^0$ and $H^1$ are computed from the coboundary; the last column is $d(|E|-|V|)+\text{dim}\,H^0$.

| Stalk | Edge maps | Fixed dimension | $H^0$ | $H^1$ | Right side of (3.8) |
|:----|:-------------------|:----------|:----|:----|:----------|
| $ℝ^2$ | gauge of the identity | 2 | 2 | 10 | 10 |
| $ℝ^2$ | random orthogonal | 0 | 0 | 8 | 8 |
| $ℝ^2$ | one reflected edge | 1 | 1 | 9 | 9 |
| $ℝ^3$ | gauge of the identity | 3 | 3 | 15 | 15 |
| $ℝ^3$ | random orthogonal | 0 | 0 | 12 | 12 |
| $ℝ^3$ | one edge rotated by 1.1 rad | 1 | 1 | 13 | 13 |

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Corollary 3.13** (Harary's balance theorem [21]). Let the graph be connected, $d=1$ and $r_{ve}\in\{\pm1\}$, so that $F$ defines a signed graph. Then $H^0\neq 0$ if and only if every cycle has a positive product of signs, if and only if the vertices admit a 2-colouring in which positive edges join equal colours and negative edges join different colours.
:::

::: {custom-style="Statement Tag"}
Classical; here a corollary of Theorem 3.12.
:::

::: {custom-style="Check"}
*Numerical check.* In 600 random connected signed graphs with 8 vertices, 8 to 14 edges and negative signs with probability 0.25, $H^0=1$ held exactly when a balanced 2-colouring existed, in 600 of 600 graphs.
:::

::: {custom-style="Statement"}
**Proposition 3.14** (filled triangles are flat). Let $\tau=\{a,b,c\}$ be a 2-simplex with $F(\tau)=ℝ^d$, and let every restriction on $\tau$ and its faces be orthogonal and compatible. Then $T_{a\leftarrow c}\,T_{c\leftarrow b}\,T_{b\leftarrow a}=I$. Consequently an orthogonal sheaf on a 2-complex $K$ defines a representation $\pi_1(K,v_0)\to O(d)$, a local coefficient system in Steenrod's sense [31], whose fixed subspace is $H^0$.
:::

::: {custom-style="Statement Tag"}
New in Part I as stated.
:::

*Proof.* For an edge $e$ of $\tau$ with endpoints $p,q$, compatibility gives $r_{p\tau}=r_{e\tau}r_{pe}$, hence $r_{pe}=r_{e\tau}^{\top}r_{p\tau}$. Therefore $T_{q\leftarrow p}=r_{qe}^{\top}r_{pe}=r_{q\tau}^{\top}r_{e\tau}r_{e\tau}^{\top}r_{p\tau}=r_{q\tau}^{\top}r_{p\tau}$, and the product around $\tau$ telescopes to $I$. The fundamental group of a 2-complex is generated by edge loops modulo the boundaries of its 2-cells [22], so holonomy descends to $\pi_1$, and Theorem 3.12(i) identifies $H^0$. ∎

::: {custom-style="Check"}
*Numerical check.* For 200 random compatible orthogonal triangles with $d\in\{2,3,4\}$, the largest entry of $\text{Hol}-I$ around the boundary was 2.0 × 10⁻¹⁵.
:::

::: {custom-style="Statement"}
**Remark 3.15** (flat is not trivial). Flatness says that holonomy around every filled triangle is trivial. It does not say that holonomy around a non-contractible loop is trivial. A flat orthogonal sheaf has $H^0\cong\text{Fix}\,\rho(\pi_1)$, which can be smaller than $ℝ^d$, and under heat flow (Proposition 3.8) exactly that many dimensions survive. On a graph without 2-cells flatness is vacuous, and every orthogonal sheaf is flat in this sense.
:::

::: {custom-style="Statement Tag"}
V2 Section 9, made precise.
:::

## 3.5 Three obstructions

The circle supports three different local-to-global failures. Their coefficient systems and conclusions differ, and V2 corrected two earlier statements that conflated them. The next proposition places all three on the same nerve.

::: {custom-style="Statement"}
**Proposition 3.16** (three obstructions on one cycle). Let $N$ be the 3-cycle with vertices $0,1,2$ and edges $01,12,02$. It is the nerve of three arcs that cover the circle with connected pairwise overlaps and no triple intersection.
:::

::: {custom-style="Statement"}
\(a) *Linear class.* For the constant sheaf $ℝ$ on $N$, $H^0\cong H^1\cong ℝ$, and the class of edge data $c$ is the oriented sum $c_{01}+c_{12}-c_{02}$. With unit weights,
:::

::: {custom-style="Statement Equation"}
$\text{min}_{x}\,\|\delta x-c\|=\frac{|c_{01}+c_{12}-c_{02}|}{\sqrt 3}$ (3.9)
:::

::: {custom-style="Statement"}
\(b) *Additive obstruction (angles).* Real angle lifts $\theta_i$ on the three arcs differ on each overlap by a constant in $2\pi ℤ$. These differences form a Čech 1-cocycle of the constant sheaf $2\pi ℤ$ whose oriented sum is $2\pi$, one full turn. No choice of lifts, even after shifting each by an arbitrary real constant, makes every overlap difference vanish; the least residual is $2\pi/\sqrt 3$. The local lifts form a torsor for an additive sheaf, not a linear vector sheaf. The circle still has global coordinates $(\cos\theta,\sin\theta)$; the obstruction concerns a global real angle.
:::

::: {custom-style="Statement"}
\(c) *Multiplicative obstruction (signs).* Take lines at 0°, 60° and 120° with representatives $u_0,u_1,u_2$ and transition signs $s_{ij}=\text{sign}\langle u_i,u_j\rangle$. The product of signs around the cycle is $-1$. The real sheaf with restrictions $(1,s_{ij})$ has $H^0=H^1=0$. The obstruction to coherent nonzero representatives is the nonzero class of $s$ in $H^1(N;ℤ_2)$, that is, the holonomy $-1$. It is not a nonzero $H^1$ of the twisted real sheaf.
:::

::: {custom-style="Statement Tag"}
V2 Sections 10 and 11, unified; the residual in (b) is check 11 of the register [19]; (3.9) is new in Part I.
:::

*Proof.* (a) In the edge order $(01,12,02)$, $\text{im}\,\delta$ is the plane orthogonal to $n=(1,1,-1)$, so the distance from $c$ to it is $|n\cdot c|/\sqrt 3$. (b) On an overlap, $\theta_j-\theta_i$ is continuous with values in $2\pi ℤ$, hence constant. Around the circle the angle increases by $2\pi$, so the oriented sum of the differences is $2\pi$. Changing the lifts by real constants adds a coboundary, which leaves the oriented sum unchanged; (3.9) then gives the residual. (c) A section satisfies $x_j=s_{ij}x_i$ on every edge, so after one loop $x_0=-x_0$. Hence $x_0=0$ and $H^0=0$. The coboundary is a $3\times 3$ matrix with trivial kernel, hence invertible, so $H^1=0$. Writing the signs additively in $ℤ_2$, their sum around the only cycle is $1$, so the class of $s$ in $H^1(N;ℤ_2)\cong ℤ_2$ is nonzero. ∎

::: {custom-style="Check"}
*Numerical check.* The least-squares residual for the angle cocycle is 3.6276, against $2\pi/\sqrt 3=3.6276$. The constant sheaf has $(H^0,H^1)=(1,1)$, the sign-twisted sheaf has $(0,0)$, and the computed holonomy is −1.
:::

::: {custom-style="Statement"}
**Example 3.17** (mode shapes and subspaces). An isolated real vibration eigenmode is a line, because $u$ and $-u$ describe the same physical mode. Tracking it across a family of structural models therefore produces case (c), with alignment tested in the mass inner product for mass-normalised modes. For repeated or nearly repeated eigenvalues the right object is the modal subspace. Frames in it are defined up to $O(k)$, transports are orthogonal $k\times k$ matrices, and holonomy can be any element of $O(k)$. For orthonormal frames representing the same subspace on an overlap, the projector $UU^{\top}$ is frame invariant and agrees there. Varying modal subspaces form a global projector field only under the corresponding continuity and spectral-separation assumptions. The obstruction concerns frames, not subspaces, and a Grassmannian description replaces independent sign flips.
:::

::: {custom-style="Statement Tag"}
V2 Section 11.
:::

::: {custom-style="Statement"}
**Example 3.18** (a sheaf of sets with no global section). Take binary variables $x_1,x_2,x_3$ and the contexts $\{1,2\}$, $\{2,3\}$ and $\{1,3\}$. On each context the feasible local sections are the assignments with unequal bits. Every local set is nonempty, and every local section agrees on the shared variable with some section of each neighbouring context. Yet no global assignment satisfies all three inequalities. The coordinate sheaf on the same contexts has $H^1=0$ (Proposition 3.19), so no linear cohomology class detects the failure. This is the possibilistic form of contextuality [1] and the set-level analogue of the marginal extension problem [32]; Part V treats it.
:::

::: {custom-style="Statement Tag"}
V2 Section 16, as a sheaf of sets.
:::

::: {custom-style="Check"}
*Numerical check.* Local feasible sets have sizes 2, 2 and 2; every local section extends to each neighbouring context; 0 of the 8 global assignments are feasible.
:::

## 3.6 Context sheaves

::: {custom-style="Statement"}
**Proposition 3.19** (coordinate sheaves on contexts). Let $S_1,\ldots,S_k\subseteq\{1,\ldots,D\}$ be nonempty contexts with union $J$, and let $n_j$ be the number of contexts containing the variable $j$. On the nerve of the contexts, where $\sigma$ is a simplex when $S_\sigma=\bigcap_{i\in\sigma}S_i$ is nonempty, define the coordinate sheaf $K(\sigma)=ℝ^{S_\sigma}$ with coordinate projections as restrictions. Then:
:::

::: {custom-style="Statement"}
\(i) $H^0\cong ℝ^{J}$, so a section is an assignment of every covered variable;
:::

::: {custom-style="Statement"}
\(ii) $H^k=0$ for all $k\ge 1$;
:::

::: {custom-style="Statement"}
\(iii) on the pairwise graph (the 1-skeleton of the nerve),
:::

::: {custom-style="Statement Equation"}
$\text{dim}\,H^1=\sum_{j\in J}\frac{(n_j-1)(n_j-2)}{2}$ (3.10)
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

*Proof.* The sheaf splits as $K=\bigoplus_{j\in J}K_j$, where $K_j(\sigma)=ℝ$ if $j\in S_\sigma$ and $0$ otherwise. Let $A_j$ be the set of contexts containing $j$. Every nonempty subset of $A_j$ is a simplex of the nerve, because its contexts share $j$. So the cochain complex of $K_j$ is the simplicial cochain complex of the full simplex on the $n_j$ vertices $A_j$. A full simplex is acyclic, which proves (i) and (ii). On the pairwise graph, $K_j$ sees the complete graph on $n_j$ vertices. That graph is connected and has $\binom{n_j}{2}-n_j+1=(n_j-1)(n_j-2)/2$ independent cycles. Summing over $j$ gives (3.10). ∎

On the pairwise graph, $H^1$ counts redundant agreement constraints on the same variable; it does not certify an inconsistency. Filling the triangles of the nerve removes those classes. A nonzero $H^1$ on a pairwise context graph is therefore never by itself evidence of an obstruction.

::: {custom-style="Check"}
*Numerical check.* In 300 random context families (4 to 7 variables, 3 to 6 contexts of size 2 or 3), (3.10) and statements (i) and (ii) held in every case. For the contexts $\{1,2\},\{1,3\},\{1,4\}$ of Figure 2b, the pairwise graph gives $(H^0,H^1)=(4,1)$ and the full nerve gives $(4,0)$. For the cycle $\{1,2\},\{2,3\},\{1,3\}$ of Example 3.18 the pairwise graph gives $(3,0)$.
:::

## 3.7 Changing the base pullbacks and refinements

::: {custom-style="Statement"}
**Proposition 3.20** (inverse image along a simplicial map). Let $f:K\to L$ be a simplicial map and $G$ a cellular sheaf on $L$. Then $(f^{-1}G)(\sigma)=G(f(\sigma))$, with restrictions $G(f(\sigma)\le f(\tau))$, is a cellular sheaf on $K$. The map $f^{♯}:C^k(L;G)\to C^k(K;f^{-1}G)$ sends $y$ to the cochain with value $\varepsilon_\sigma\,y_{f(\sigma)}$ on $\sigma$ when $f$ is injective on $\sigma$, and $0$ when $f(\sigma)$ is degenerate. Here $\varepsilon_\sigma$ is the sign of the permutation that orders $f(\sigma)$. It satisfies $\delta f^{♯}=f^{♯}\delta$, and so induces maps $H^k(L;G)\to H^k(K;f^{-1}G)$.
:::

::: {custom-style="Statement Tag"}
Classical; the simplicial case of the inverse-image functoriality used by Russold [28].
:::

*Proof.* Compatibility of $f^{-1}G$ is inherited from $G$ because $f$ preserves faces. In $(\delta f^{♯}y)_\tau$, the terms whose faces map degenerately cancel in pairs exactly as in simplicial cohomology [22]; the remaining terms reproduce $(f^{♯}\delta y)_\tau$. ∎

::: {custom-style="Check"}
*Numerical check.* A filled triangle was collapsed onto an edge, with vertex stalks $ℝ^2$, an edge stalk $ℝ^3$ and random restrictions on the edge. The commutation defects $\delta f^{♯}-f^{♯}\delta$ were 0 in degree 0 and 0 in degree 1, and the pulled-back sheaf was compatible with $\delta^1\delta^0=0$.
:::

::: {custom-style="Statement"}
**Proposition 3.21** (refinement). Let $𝒱=\{V_j\}$ refine $𝒰=\{U_i\}$, with a refinement map $\varphi$ such that $V_j\subseteq U_{\varphi(j)}$. Then $\varphi$ induces a simplicial map $N(𝒱)\to N(𝒰)$, and the restrictions $𝒮(U_{\varphi(\sigma)})\to 𝒮(V_\sigma)$ define a morphism $\varphi^{-1}F^{𝒰}_𝒮\to F^{𝒱}_𝒮$. The induced map $H^k(N(𝒰);F^{𝒰}_𝒮)\to H^k(N(𝒱);F^{𝒱}_𝒮)$ does not depend on the choice of $\varphi$, and it commutes with the maps to $H^k(X;𝒮)$.
:::

::: {custom-style="Statement Tag"}
Classical [6, 9]; Russold's topological-type step [28].
:::

*Proof.* Nonempty intersections of the $V_j$ lie in the corresponding intersections of the $U_{\varphi(j)}$, which gives the simplicial map; the restriction maps of $𝒮$ give the morphism. Two refinement maps induce chain-homotopic cochain maps on Čech complexes, and both factor the canonical maps to sheaf cohomology [6, 9]. ∎

Different covers at successive layers do not by themselves provide vertical maps. Refinement maps, a common refinement or a fixed complex with changing coefficients do. Once such maps are specified, horizontal restrictions and vertical maps must commute on every square (Proposition 5.2).


# 4 The vertical axis representations of the layer order

## 4.1 Representations and barcodes

::: {custom-style="Statement"}
**Definition 4.1** (representations of the layer order). A representation $V$ of $P$ consists of finite-dimensional spaces $V_t$, $t=T,\ldots,0$, and linear maps $\rho_t:V_t\to V_{t-1}$. For $a\ge b$ write $\rho_{a\to b}=\rho_{b+1}\circ\cdots\circ\rho_a:V_a\to V_b$, the identity when $a=b$. The rank invariant is $r(a,b)=\text{rank}\,\rho_{a\to b}$. For $T\ge b\ge d\ge 0$, the interval module $𝕀[b,d]$ is $ℝ$ at the layers $b,b-1,\ldots,d$, joined by identities, and $0$ elsewhere. It is born at layer $b$ and is alive up to layer $d$.
:::

::: {custom-style="Statement Tag"}
Classical.
:::

::: {custom-style="Statement"}
**Theorem 4.2** (interval decomposition). Every representation of $P$ decomposes as $V\cong\bigoplus 𝕀[b,d]^{m[b,d]}$. The multiset of intervals, the barcode, is unique and is a complete invariant up to isomorphism, and
:::

::: {custom-style="Statement Equation"}
$m[b,d]=r(b,d)-r(b+1,d)-r(b,d-1)+r(b+1,d-1)$ (4.1)
:::

::: {custom-style="Statement"}
with $r=0$ whenever an index leaves $\{T,\ldots,0\}$.
:::

::: {custom-style="Statement Tag"}
Classical [13, 15, 26, 34].
:::

*Proof.* The decomposition is Gabriel's theorem for the linearly oriented quiver of type A [15]; Crawley-Boevey extends it to pointwise finite-dimensional modules over the real line [13]. The rank $r(a,b)$ counts the intervals that contain both $a$ and $b$, and inclusion–exclusion over the four corners isolates those born exactly at $b$ and alive exactly up to $d$. ∎

::: {custom-style="Check"}
*Numerical check.* In 1,500 random chains with 3 to 6 layers, dimensions 1 to 4 and maps of random rank, every multiplicity from (4.1) was nonnegative and the bars reproduced every rank $r(a,b)$ exactly.
:::

## 4.2 Vertical fibre diagrams

::: {custom-style="Statement"}
**Definition 4.3** (token path and fibre diagrams). Let a token visit $x_t\in X_t$, and let $V_t$ be the data space attached to its visited cell. Linear vertical maps arise in three ways.
:::

::: {custom-style="Statement"}
\(a) *Transport diagrams:* specified linear maps $\rho_t:V_t\to V_{t-1}$, such as stalk maps induced by refinements or validated chart transports. This is the token's vertical fibre diagram.
:::

::: {custom-style="Statement"}
\(b) *Tangent diagrams:* the Jacobians $J_t=\partial z_{t-1}/\partial z_t$ of a smooth update along the realised path, with the noise held fixed.
:::

::: {custom-style="Statement"}
\(c) *Affine diagrams:* $z_{t-1}=A_tz_t+b_t$, made linear by homogenisation.
:::

::: {custom-style="Statement"}
A single stalk is one fibre; the whole journey is a sequence of stalks and maps, not one stalk. A state-dependent nonlinear update is not a linear representation and does not acquire a barcode merely by being layered.
:::

::: {custom-style="Statement Tag"}
V2 Definition 3.1, with the three sources separated.
:::

::: {custom-style="Statement"}
**Proposition 4.4** (homogenisation adds exactly one full bar). Let $\tilde A_t=\begin{pmatrix}A_t & b_t\\ 0 & 1\end{pmatrix}$ act on $ℝ^{D+1}$.
:::

::: {custom-style="Statement"}
\(i) The composite of the affine diagram is
:::

::: {custom-style="Statement Equation"}
$z_0=A_1A_2\cdots A_T\,z_T+\sum_{t=1}^{T}A_1\cdots A_{t-1}\,b_t$ (4.2)
:::

::: {custom-style="Statement"}
\(ii) The barcode of $(ℝ^{D+1},\tilde A_t)$ is the barcode of $(ℝ^{D},A_t)$ plus one interval $𝕀[T,0]$.
:::

::: {custom-style="Statement Tag"}
\(i) V2 Section 7 with matrix coefficients; (ii) new in Part I.
:::

*Proof.* (i) Substitute each recurrence into the next. (ii) The vectors with last coordinate zero form a subrepresentation isomorphic to $(ℝ^D,A_t)$, and the quotient is $𝕀[T,0]$ because every $\tilde A_t$ preserves the last coordinate. The extension splits. Choose any $w_T$, set $w_{t-1}=A_tw_t+b_t$, and observe that the vectors $(w_t,1)$ span a subrepresentation isomorphic to $𝕀[T,0]$ and complementary to the first. Uniqueness of barcodes gives (ii). ∎

::: {custom-style="Check"}
*Numerical check.* For 200 random affine chains with $D=3$ and $T=8$, the direct recurrence, formula (4.2) and the homogenised product agreed to 3.6 × 10⁻¹⁵. In 500 random chains with rank-deficient $A_t$ and random offsets, the homogenised barcode equalled the linear barcode plus one full bar in 500 cases.
:::

The full bar is the affine direction: the trajectory of one point. Everything the offsets $b_t$ do is in where that trajectory goes, not in the barcode. A barcode of an affine diagram is therefore the barcode of its linear part, plus the one full bar.

## 4.3 Births at a clean top

::: {custom-style="Statement"}
**Proposition 4.5** (births at the top). Suppose $\text{dim}\,V_t=D$ for every $t$, every map below the top is invertible, and the top map $\rho_1:V_1\to V_0$ has rank $r$. Then
:::

::: {custom-style="Statement Equation"}
$V\cong 𝕀[T,0]^{r}\oplus 𝕀[T,1]^{D-r}\oplus 𝕀[0,0]^{D-r}$ (4.3)
:::

::: {custom-style="Statement Tag"}
V2 Section 13, with proof.
:::

*Proof.* The ranks are $r(a,b)=D$ for $b\ge 1$, $r(a,0)=r$ for $a\ge 1$, and $r(0,0)=D$. Formula (4.1) returns $m[T,0]=r$, $m[T,1]=D-r$ and $m[0,0]=D-r$, and every other multiplicity vanishes. ∎

Of the $D$ bars born at the bottom, $r$ reach the top and $D-r$ end one layer below it. The top also has $D-r$ bars of its own: output directions that no lower perturbation reaches. Counting only the bars born at the bottom, and calling the missing ones deaths, misreads the rank. For the Gaussian update with a clean top, $a_0=1$, V2 gives $\lambda_1=1$ and $J_1=C_1/s_1^2$, so $r=\text{rank}\,C_1$.

::: {custom-style="Check"}
*Numerical check.* With $D=4$, five layers and a top map of rank 2, formula (4.1) returned the bars $𝕀[T,0]^{ 2 }$, $𝕀[T,1]^{ 2 }$ and $𝕀[0,0]^{ 2 }$. The C# kernel reproduces the case $D=3$, four layers and top rank 1 (Appendix A).
:::

## 4.4 Exact bars and effective sensitivity

::: {custom-style="Statement"}
**Proposition 4.6** (exact versus effective rank of the Gaussian tangent). Within a fixed cell and star, assume orthogonal, locally constant transports, query-independent prior weights, $s_t>0$ and $0\le\lambda_t\le1$. Let $v_1,\ldots,v_n$ be the transported values, $\alpha_i>0$ their Gaussian posterior weights, $m=\sum_i\alpha_iv_i$, $C=\sum_i\alpha_i(v_i-m)(v_i-m)^{\top}$ and $J_t=(1-\lambda_t)I+(\lambda_t/s_t^2)\,C$ [19, Proposition 13.1].
:::

::: {custom-style="Statement"}
\(i) The range of $C$ is $\text{span}\{v_i-v_1\}$, so $\text{rank}\,C=\text{dim}\,\text{aff}\{v_1,\ldots,v_n\}\le\text{min}(D,n-1)$.
:::

::: {custom-style="Statement"}
\(ii) If one record has posterior mass at least $1-\varepsilon$ and $R$ is the diameter of the transported values, then
:::

::: {custom-style="Statement Equation"}
$\|C\|\le\varepsilon R^2$ (4.4)
:::

::: {custom-style="Statement"}
\(iii) If $\lambda_t<1$, every eigenvalue of $J_t$ lies in $[1-\lambda_t,\ 1-\lambda_t+\lambda_tR^2/(4s_t^2)]$, so $J_t$ is invertible. At a clean top, $\text{rank}\,J_1=\text{dim}\,\text{aff}\{v_i\}$. If the spaces all have dimension $D$, every lower map has $\lambda_t<1$ and the top records affinely span $ℝ^D$, every exact tangent bar is full, however small $\varepsilon$ is.
:::

::: {custom-style="Statement"}
\(iv) For all matrices $A$ and $E$ and every $k$, $|\sigma_k(A+E)-\sigma_k(A)|\le\|E\|$. Hence the effective rank at tolerance $\tau$, the number of singular values above $\tau$, is unchanged by every perturbation with $\|E\|<\text{min}_k|\sigma_k(A)-\tau|$, while arbitrarily small generic perturbations can increase the exact rank of a rank-deficient matrix.
:::

::: {custom-style="Statement Tag"}
\(i) and the bar statement in (iii) new in Part I; (ii) and the eigenvalue bound V2 Section 13; (iv) Weyl [23].
:::

*Proof.* (i) Since every $\alpha_i>0$, the range of $C$ is $\text{span}\{v_i-m\}$. Because $m$ is an affine combination of the $v_i$, this equals $\text{span}\{v_i-v_1\}$, the direction space of the affine hull. (ii) For every point $c$, $\sum_i\alpha_i(v_i-c)(v_i-c)^{\top}=C+(m-c)(m-c)^{\top}\succeq C$. Take $c=v_j$, the record of mass at least $1-\varepsilon$: the $j$-th term vanishes, and the others have total mass at most $\varepsilon$ and norm at most $R^2$. (iii) The eigenvalue bound is V2 Proposition 13.1; at the top $J_1=C_1/s_1^2$, and (i) applies. (iv) This is Weyl's inequality for singular values [23]. ∎

Re-selection of an archived record is therefore usually contraction of singular values, not literal death of an interval. Exact death occurs at rank loss or in the one-hot limit. A numerical threshold $\tau$ defines an effective rank, which must be reported together with its tolerance.

::: {custom-style="Check"}
*Numerical check (Proposition 4.6 (i)–(ii)).* In 400 random record sets in $ℝ^4$ with prescribed affine dimension 0 to 3 and random positive weights, $\text{rank}\,C$ equalled the affine dimension in 400 cases. Bound (4.4) held in 400 cases with $\varepsilon$ up to 0.3; the largest ratio $\|C\|/(\varepsilon R^2)$ was 0.991.
:::

To see both effects in a full stack, we ran 1,000 tokens through a 16-layer cosine schedule with $a_t=\cos^2(\pi t/32)$, $\eta=0$ and a clean top, on 30 records in three clusters in $ℝ^2$. The composite tangent $\partial z_0/\partial z_{15}$ was computed along each realised path. In exact arithmetic every composite has rank 2, by Proposition 4.6. At the declared numerical cutoff $10^{-14}\max(1,\sigma_{\max})$, the measured rank was full for 96.9% of tokens. In each of the other 31 tokens at most 2 records kept a final weight above $10^{-8}$, the smallest eigenvalue of $C_1$ was at most 5.1 × 10⁻¹⁵, and the composite was numerically singular. This is numerical rank at a chosen cutoff, not exact singularity. Concentration near a line or point can make the smaller covariance direction negligible, although the remaining positive weights retain exact rank. At practical tolerances the effective rank told a different story. At $\tau=10^{-3}$ it was 0, 1 or 2 for 11.9%, 44.0% and 44.1% of tokens. At $\tau=10^{-2}$ the shares were 26.5%, 60.6% and 12.9%. The median singular values at the top were 0.0353 and 6.4 × 10⁻⁴ (Figure 4). The exact bars survive while sensitivity contracts by one to three orders of magnitude, most sharply in the final step.

A revision audit replays the same 1,000 token paths using both $C_{\mathrm{raw}}=\sum_i\alpha_iv_iv_i^{\top}-mm^{\top}$ and $C_{\mathrm{cent}}=\sum_i\alpha_i(v_i-m)(v_i-m)^{\top}$. Both classify 31 composites below the same cutoff, with 0 changed classifications. The raw final covariance has a negative eigenvalue for 9 tokens; the largest covariance discrepancy is 7.5 × 10⁻¹⁵. Thus cancellation is observable, but changing to the centred formula does not remove the 3.1% numerical-rank result in this experiment. The data show association with at most two weights above $10^{-8}$, not that every affected token is one-hot. Use the centred form in implementations.

![**Figure 4.** Exact bars survive while sensitivity contracts. Median singular values of the composite tangent $\partial z_t/\partial z_{15}$ for 200 tokens as they climb a 16-layer cosine stack with a clean top. Dashed lines mark two effective-rank tolerances. The mathematical rank is 2 for every path under the hypotheses; measured rank depends on the tolerance and floating-point evaluation.](fig/tangent.png){width=92%}

## 4.5 Persistence of layer cohomology

::: {custom-style="Statement"}
**Proposition 4.7** (layer cohomology is a representation of $P$). Suppose that for each $t$ there is a simplicial map $f_t:N_{t-1}\to N_t$, for instance from a refinement or an inclusion, and a sheaf morphism $\varphi_t:f_t^{-1}F_t\to F_{t-1}$. Then the composites
:::

::: {custom-style="Statement Equation"}
$H^k(N_t;F_t)\to H^k(N_{t-1};f_t^{-1}F_t)\to H^k(N_{t-1};F_{t-1})$ (4.5)
:::

::: {custom-style="Statement"}
make $t\mapsto H^k(N_t;F_t)$ a representation of $P$ for every $k$. It therefore has a barcode in every degree.
:::

::: {custom-style="Statement Tag"}
New packaging in Part I: a topological step followed by an algebraic step, in the sense of Russold [28].
:::

*Proof.* The first arrow is Proposition 3.20, and the second is functoriality of cohomology under sheaf morphisms. Composition is functorial, so the maps compose along $P$, and Theorem 4.2 applies. ∎

::: {custom-style="Statement"}
**Proposition 4.8** (Leray covers give full bars). Let $𝒮$ be a sheaf on a fixed space $X$, and let $𝒰_T,\ldots,𝒰_0$ be covers of $X$ such that each $𝒰_{t-1}$ refines $𝒰_t$ and every $𝒰_t$ is a Leray cover for $𝒮$. With Čech data sheaves and refinement maps, every vertical map $H^k(N_t;F_t)\to H^k(N_{t-1};F_{t-1})$ is an isomorphism, and the degree-$k$ barcode consists of $\text{dim}\,H^k(X;𝒮)$ copies of $𝕀[T,0]$.
:::

::: {custom-style="Statement Tag"}
New in Part I, as a corollary of Proposition 3.21.
:::

*Proof.* By Proposition 3.21 each refinement map commutes with the Leray isomorphisms to $H^k(X;𝒮)$, which are isomorphisms at every layer by Theorem 3.9. ∎

Under these hypotheses and canonical refinement maps, refinement alone creates no birth or death. An observed change means that the region, underlying coefficients, Leray hypotheses or comparison construction changed, or that numerical or implementation error occurred. In particular, replacing Čech coefficients by one scalar per overlap can create an artefact even when the cover itself is Leray.

::: {custom-style="Statement"}
**Example 4.9** (a coarse cover that misses a loop; Figure 3). Cover the circle at the bottom by the two arcs of Example 3.10, in the middle by three arcs and at the top by six arcs, each cover refining the one below. With the plain nerve and constant coefficients, $H^1$ is $0$, $1$ and $1$, and a bar is born at the middle layer. That bar is an artefact of replacing the bottom overlap's two-dimensional Čech data by one scalar. The two-arc cover itself is Leray; the plain coefficient summary is incorrect. With the Čech data sheaf at the bottom, $H^1=ℝ$ at every layer and the bar is full, as Proposition 4.8 predicts.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

::: {custom-style="Check"}
*Numerical check.* The covers, overlaps and refinement maps were computed from the arcs on a grid of 7,200 angles. The refinement maps were $(0,0,1)$ and $(0,0,1,1,2,2)$, and the induced cochain maps commuted with the coboundaries exactly. The bottom overlap had 2 components. Barcodes from (4.1): plain nerve $H^0$ full and $H^1$ born at the middle layer; data sheaf $H^0$ and $H^1$ both full.
:::

::: {custom-style="Statement"}
**Proposition 4.10** (nested ball nerves). Fix centres $y_i\in ℝ^D$ and positive radii $0<r_0\le\cdots\le r_T$, and let $N_t$ be the nerve of the open balls $B(y_i,r_t)$. Then $N_0\subseteq\cdots\subseteq N_T$, each $N_t$ is homotopy equivalent to the union of its balls, and the inclusions give $H^k(N_T)\to\cdots\to H^k(N_0)$ in the token direction. In degree zero these maps are injective. Every $H^0$ bar therefore reaches the top layer, and the number of bars born at layer $t-1$ is the increase $c(N_{t-1})-c(N_t)$ in the number of components.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 14.1.
:::

*Proof.* The finite ball covers of their Euclidean unions are good covers. An intersection that is nonempty at a smaller radius stays nonempty at a larger one. Ball intersections are convex, so the nerve theorem applies [22]. The nerves share their vertices, so a function that is constant on the components of $N_t$ restricts to a function constant on the finer components of $N_{t-1}$, and distinct coarse functions differ at some vertex. Injective maps kill no bar, and (4.1) counts the births. ∎

For open balls an edge appears at centre distance strictly below $2r_t$; a convention at exact equality must be chosen and recorded. The nerve is homotopy equivalent to the union of the balls, not to the latent domain, unless the balls cover that domain.

::: {custom-style="Check"}
*Numerical check (Figure 5).* The archive has 36 records in three clusters of three sub-clusters, with radius $r_t=s_t$, that is $\kappa=1$, on the 16-layer cosine schedule. The component counts are 1 at layers 15 to 12, 3 at layers 11 to 9, 6 at layer 8 and 9 at layers 7 to 1. Births occur at layers 15, 11, 8 and 7 with multiplicities 1, 2, 3 and 3. Every vertical map is injective and every bar reaches layer 1. The clean top has radius zero and is excluded. This reproduces check 21 of the proposal register [18, 19].
:::

![**Figure 5.** $H^0$ barcode of a nested ball filtration. Left: an archive with structure at three scales. Right: bars in the token's direction, born when components split; the numbers above give the component count at each layer. Every bar reaches the top because the vertical maps are injective in degree zero (Proposition 4.10).](fig/barcode.png){width=100%}

::: {custom-style="Statement"}
**Proposition 4.11** (stability of component counts). Let $y,y'$ be configurations of $n$ points with $\text{max}_i\|y_i-y'_i\|\le\varepsilon$, and let $c_r(y)$ be the number of components of the graph with an edge whenever $\|y_i-y_j\|\le r$. Then
:::

::: {custom-style="Statement Equation"}
$c_{r+2\varepsilon}(y)\le c_r(y')\le c_{r-2\varepsilon}(y)$ (4.6)
:::

::: {custom-style="Statement Tag"}
New in Part I as stated; a component-level form of persistence stability [12].
:::

*Proof.* If $\|y'_i-y'_j\|\le r$, then $\|y_i-y_j\|\le r+2\varepsilon$ by the triangle inequality, so the graph of $y'$ at radius $r$ is contained in the graph of $y$ at $r+2\varepsilon$. Both graphs have the same vertices, and more edges give fewer components. The second inequality is symmetric. ∎

For negative thresholds define $c_r=n$, with no edges; this makes (4.6) valid when $r-2\varepsilon<0$. Births read from component counts are robust only away from thresholds. A schedule chosen from births should therefore be reported together with the $2\varepsilon$ margin of the archive's uncertainty.

::: {custom-style="Check"}
*Numerical check.* We drew 80 configurations of 40 points in $[0,10]^2$, with $\varepsilon$ from 0.02 to 0.4, and evaluated 15 radii each: 1,200 cases with 0 violations of (4.6).
:::

::: {custom-style="Statement"}
**Remark 4.12** (zigzags). If covers are learned, centres move or neighbourhoods are not nested, consecutive layers need not admit a map in either direction. A common refinement $𝒲$ gives $H^k(N_t)\to H^k(N(𝒲))\leftarrow H^k(N_{t-1})$. This is a zigzag module, which also decomposes into intervals [10]. Section 5 gives a zigzag whose nonconstant coefficients have nonzero derived-limit cohomology. A zigzag is not automatically non-acyclic, and learned covers do not force a unique comparison construction.
:::

::: {custom-style="Statement Tag"}
V2 Section 14.
:::


# 5 The product one sheaf for the whole stack

The two axes combine into one object: a sheaf on the product of a base with the layer order. This section describes such sheaves, computes their cohomology and draws the consequence for the principle.

::: {custom-style="Statement"}
**Proposition 5.1** (fixed-base product). Let $X$ be a topological space and give $P$ its Alexandrov topology.
:::

::: {custom-style="Statement"}
\(i) A set $W\subseteq X\times P$ is open exactly when every slice $W_t=\{x:(x,t)\in W\}$ is open and $W_t\subseteq W_{t'}$ whenever $t\le t'$ in $P$, that is, whenever $t'$ lies above $t$.
:::

::: {custom-style="Statement"}
\(ii) Sheaves $G$ on $X\times P$ correspond to diagrams $G_T\to G_{T-1}\to\cdots\to G_0$ of sheaves on $X$, through $G_t(U)=G(U\times\uparrow t)$; the vertical arrow is restriction along $U\times\uparrow(t-1)\subseteq U\times\uparrow t$. Conversely,
:::

::: {custom-style="Statement Equation"}
$G(W)=\{(s_t)_t\in\prod_tG_t(W_t):\ \rho_{t\to t'}(s_t)=\text{res}_{W_t}(s_{t'})\ \text{whenever}\ t\le t'\ \text{in}\ P\}$ (5.1)
:::

::: {custom-style="Statement Tag"}
V2 Proposition 3.2, with a new proof through slices; compare Russold's correspondence between linear diagrams of sheaves and sheaves of graded modules [28].
:::

*Proof.* (i) Basic open sets $U\times V$, with $V$ an up-set, have open and monotone slices, and unions preserve both properties. Conversely, a set with open monotone slices equals $\bigcup_t W_t\times\uparrow t$. (ii) A cover of $U$ gives a cover of $U\times\uparrow t$, so each $G_t$ is a sheaf, and the inclusions give the vertical maps. Given a diagram, cover $W$ by the sets $W_t\times\uparrow t$. Two of them, with $t\le t'$, intersect in $W_t\times\uparrow t'$, and the gluing condition there is exactly the condition in (5.1). On $W=U\times\uparrow t_0$, (5.1) returns $G_{t_0}(U)$, because the sections above $t_0$ are determined by $s_{t_0}$. The two constructions are inverse up to natural isomorphism. ∎

::: {custom-style="Statement"}
**Proposition 5.2** (the finite case). For a finite poset $Q$, the product topology on $Q\times P$ is the Alexandrov topology of the product order. Sheaves on $Q\times P$ are functors $Q\times P\to\text{Vect}$, that is, layer sheaves $G_t:Q\to\text{Vect}$ with natural maps $G_t\Rightarrow G_{t-1}$. Naturality says that horizontal restrictions and vertical maps commute on every square (Figure 6b). A family of unrelated layer sheaves is not a sheaf on the product.
:::

::: {custom-style="Statement Tag"}
V2 Section 3, made precise.
:::

*Proof.* Products of up-sets are up-sets of the product order, and every up-set is the union of the products $\uparrow q\times\uparrow t$ over its elements. Proposition 2.2 then identifies sheaves with functors, and a functor on a product of posets is a commuting diagram. ∎

::: {custom-style="Statement"}
**Theorem 5.3** (vertical acyclicity). Let $X$ be a topological space and $G$ a sheaf of real vector spaces on $X\times P$, with bottom layer $G_T$. For every $k\ge 0$, naturally in $G$,
:::

::: {custom-style="Statement Equation"}
$H^k(X\times P;\,G)\cong H^k(X;\,G_T)$ (5.2)
:::

::: {custom-style="Statement"}
In particular $\Gamma(X\times P;G)=\Gamma(X;G_T)$, and for a finite poset $Q$, $H^k(Q\times P;G)\cong H^k(Q;G_T)$.
:::

::: {custom-style="Statement Tag"}
ASE formulation derived from the standard exact-adjoint argument.
:::

*Proof.* Let $e$ send a sheaf $G$ on $X\times P$ to its bottom layer $G_T$, and let $\pi:X\times P\to X$ be the projection.

*Step 1: $e$ is exact.* The smallest open subset of $P$ containing $T$ is $\uparrow T=P$, so the sets $U\times P$ form a neighbourhood basis of $(x,T)$. Hence the stalk of $G_T$ at $x$ equals the stalk of $G$ at $(x,T)$, and exactness is tested on stalks.

*Step 2: $\pi^{-1}$ is an exact left adjoint of $e$.* Under Proposition 5.1, $\pi^{-1}F$ is the constant diagram $F\to F\to\cdots\to F$ with identity maps. A morphism from it to $(G_t)$ is a family $\varphi_t:F\to G_t$ with $\rho_t\varphi_t=\varphi_{t-1}$, which is determined by $\varphi_T$. Inverse images are exact.

*Step 3: $e$ preserves injectives,* because it has an exact left adjoint [33].

*Step 4: global sections factor through $e$.* $\Gamma(X\times P;G)=G(X\times\uparrow T)=G_T(X)$.

For an injective resolution $G\to I^{\bullet}$, Steps 1 and 3 make $e\,I^{\bullet}$ an injective resolution of $G_T$. Step 4 then gives $H^k(X\times P;G)=H^k\,\Gamma(X;e\,I^{\bullet})=H^k(X;G_T)$. ∎

For finite bases, the same result is a collapse of the Grothendieck spectral sequence [33] for $\text{lim}_{Q\times P}=\text{lim}_Q\circ\text{lim}_P$. The functor $\text{lim}_P$ is evaluation at the least element $T$, which is exact.

::: {custom-style="Check"}
*Numerical check.* Derived limits over $Q\times P$ were computed from (2.1) and compared with the cellular cohomology of the bottom layer. The base was a hollow triangle with three layers, in four hand-built stacks. With constant $ℝ^2$ and common random vertical maps the result was $(2,2,0,0)$. A twisted bottom under constant layers gave $(0,0,0,0)$, and a constant bottom under twisted layers gave $(1,1,0,0)$. A stack twisted at every layer, with scalar vertical maps, gave $(0,0,0,0)$. Each equals the bottom layer's cohomology. We also built 80 random stacks of subquotient sheaves on four complexes (hollow triangle; filled triangle with a pendant edge; a filled and a hollow triangle sharing an edge; four-cycle), with three layers and random twists. In 78 of them some upper layer had cohomology different from the bottom. The derived limits equalled the bottom cohomology in 80 of 80 stacks.
:::

![**Figure 6.** The product and what each invariant sees. (a) A sheaf on $Q\times P$ is a stack of layer sheaves joined by vertical maps. (b) Every square formed by a restriction and two vertical maps commutes. (c) The cohomology of the product is the bottom term of the persistence module $t\mapsto H^k(Q;G_t)$; the barcode of that module is a vertical invariant.](fig/product.png){width=100%}

::: {custom-style="Statement"}
**Corollary 5.4** (what the cohomology of a stack sees). Every global section of a stack is a bottom-layer section propagated upward, and every class in $H^k(X\times P;G)$ is determined at the bottom. Two stacks with the same bottom layer have isomorphic product cohomology, whatever happens above. The persistence module $t\mapsto H^k(X;G_t)$ of Proposition 4.7 has $H^k(X;G_T)$ as its bottom term, so its barcode retains the bottom cohomology and can distinguish stacks with identical product cohomology. It need not distinguish all sheaf diagrams or retain their metrics.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

For instance, the stack with a constant bottom and twisted layers above has product cohomology $(1,1)$, the same as a stack that is constant throughout. In its persistence module, however, both classes die after the bottom layer, while in the constant stack they persist to the top. Vertical information is invisible to the cohomology of the product and visible to barcodes. This is the precise sense in which ASE is vertically algebraic.

::: {custom-style="Statement"}
**Remark 5.5** (orientation, cosheaves and zigzags). \(i) The theorem depends on the direction of the layer order. With the opposite orientation, where information flows from the top down, evaluation happens at the top. For cosheaves, which use colimits, the dual statement evaluates at the terminal layer. \(ii) A least element guarantees evaluation and exactness for every coefficient diagram; layering alone does not. Its absence need not make every diagram non-acyclic. On the zigzag $a\le c\ge b$, put $G(a)=G(b)=ℝ$ and $G(c)=ℝ^2$, with both maps onto the same line. Then $R^0\text{lim}=ℝ$ and $R^1\text{lim}=ℝ$: the vertical axis carries a class, the direction of $G(c)$ that neither side reaches. For the constant scalar diagram on this same zigzag, higher derived limits vanish. Zigzag barcodes and derived-limit cohomology answer different questions and may both be informative.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

::: {custom-style="Check"}
*Numerical check.* The derived limits of the zigzag are $(1,1,0)$.
:::

Moving tokens fit the same framework once the inverse image is typed correctly.

::: {custom-style="Statement"}
**Definition 5.6** (tower). A tower on $X$ consists of sheaves $F_t$ on $X$, continuous deterministic steps $\Phi_t:X\to X$ and morphisms $\varphi_t:F_t\to\Phi_t^{-1}F_{t-1}$. Since $(\Phi_t^{-1}F_{t-1})_x=(F_{t-1})_{\Phi_t(x)}$, the morphism maps the stalk at $x$ into the stalk at $\Phi_t(x)$. Under a fixed noise realisation, the same description applies pathwise when the realised maps satisfy these continuity and sheaf-morphism assumptions. Piecewise chart-switching maps require a suitable stratified or local comparison construction.
:::

::: {custom-style="Statement Tag"}
V2 Section 3.
:::

::: {custom-style="Statement"}
**Proposition 5.7** (Lagrangian coordinates). Let $\Psi_T=\text{id}$ and $\Psi_{t-1}=\Phi_t\circ\Psi_t$ be the flow from the bottom. The sheaves $G_t=\Psi_t^{-1}F_t$, with the maps $\Psi_t^{-1}\varphi_t:G_t\to\Psi_t^{-1}\Phi_t^{-1}F_{t-1}\cong G_{t-1}$, form a fixed-base diagram, hence a sheaf on $X\times P$. Its stalk diagram at $x$ is the vertical fibre diagram of the token that starts at $x$:
:::

::: {custom-style="Statement Equation"}
$(F_T)_{x}\to(F_{T-1})_{\Psi_{T-1}(x)}\to\cdots\to(F_0)_{\Psi_0(x)}$ (5.3)
:::

::: {custom-style="Statement"}
Consequently every tower satisfies $H^k(X\times P;G)\cong H^k(X;F_T)$.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

*Proof.* Inverse images compose, $(g\circ f)^{-1}\cong f^{-1}g^{-1}$, and have stalks $(f^{-1}F)_x=F_{f(x)}$ [24]. Since $\Psi_T=\text{id}$, $G_T=F_T$, and Theorem 5.3 applies. ∎

A moving token is therefore one stalk diagram of a fixed-base product, written in the coordinates of the bottom layer and labelled by where the token started. The typing matters: the morphism goes into $\Phi_t^{-1}F_{t-1}$, so the stalk at $x$ maps into the stalk at $\Phi_t(x)$. Different bases at different layers first require pullbacks to a common base, a specified correspondence or another explicit comparison.

::: {custom-style="Statement"}
**Remark 5.8** (two parameters are wild). Pairing the layer order with a second filtration, such as a scale within each layer, gives a representation of a product of two chains. Such multiparameter persistence modules admit no complete discrete invariant in general [11]. ASE therefore reads barcodes one parameter at a time and reports rank invariants otherwise.
:::

::: {custom-style="Statement Tag"}
Classical.
:::

::: {custom-style="Statement"}
**Proposition 5.9** (ADE is the trivial product). Take the one-element cover $𝒰_t=\{ℝ^D\}$ and work on its one-vertex nerve $Q=\{*\}$. Fix a realised token path. Use $V=ℝ^D$ for its tangent diagram, or $V=ℝ^{D+1}$ for a homogenised affine diagram, with the corresponding linear vertical maps. These are diagrams on $Q\times P$, not arbitrary pointwise-varying morphisms of constant sheaves on $ℝ^D$. Add, separately, an observation star at each layer with one leaf per record and identity restrictions. Then:
:::

::: {custom-style="Statement"}
\(i) every layer has $H^0=V$ and $H^k=0$ for $k\ge 1$;
:::

::: {custom-style="Statement"}
\(ii) the product has $H^0=V$ and no higher cohomology;
:::

::: {custom-style="Statement"}
\(iii) the harmonic read on the star equals the ADE Gaussian read at $q_t=\sqrt{a_t}\,z_t$ [19, Proposition 6.2];
:::

::: {custom-style="Statement"}
\(iv) all vertical structure lies in the fibre diagrams, whose barcodes obey Propositions 4.4 to 4.6.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 6.2, specialised.
:::

*Proof.* A one-vertex nerve has a cochain complex concentrated in degree zero, which gives (i); Theorem 5.3 gives (ii); (iii) is V2 Proposition 6.2; (iv) is Section 4. ∎

ADE is horizontally trivial and vertically algebraic. ASE adds horizontal topology without changing the vertical algebra. Every horizontal construction of Section 3 reduces to ADE when the cover has one element and the restrictions are identities, and the applicable vertical statements of Section 4 retain their explicit hypotheses. A globally varying tangent field requires an appropriate sheaf of sections rather than an arbitrary morphism of a constant local system.

# 6 Register of numerical checks

Table 3 lists every numerical check in Part I. Fourteen checks come from one script and six from a supplementary script. Both scripts write machine-readable results, and experimental outcomes are inserted from those files when the document is built. The checks support the implementations and illustrate the statements; the proofs establish them.

Table: **Table 3.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 2.3 | derived limits against cellular cohomology | equal in 3 of 3 sheaves |
| 2 | Proposition 3.5 | $\delta^1\delta^0$ with compatible and incompatible maps | 0 and 1.78; Euler sums equal |
| 3 | Proposition 3.7 | residual sandwich, 2 sheaves, 500 assignments each | no violation; harmonic dimension equals $H^1$ |
| 4 | Example 3.10 | two arcs | data sheaf (1, 1); plain nerve (1, 0) |
| 5 | Theorem 3.12 | holonomy, 6 orthogonal sheaves | fixed dimension equals $H^0$; (3.8) in 6 of 6 |
| 6 | Corollary 3.13 | Harary balance, 600 signed graphs | 600 of 600 |
| 7 | Proposition 3.14 | flat triangles, 200 cases | largest defect 2.0 × 10⁻¹⁵ |
| 8 | Proposition 3.16 | three obstructions | residual 3.6276; (1, 1) and (0, 0); holonomy $-1$ |
| 9 | Example 3.18 | binary three-cycle | 0 global sections of 8 |
| 10 | Proposition 3.19 | context sheaves, 300 families | formula exact in every family |
| 11 | Proposition 3.20 | inverse-image cochain map | commutation defects 0 and 0 |
| 12 | Theorem 4.2 | 1,500 random chains | multiplicities nonnegative; ranks reconstructed |
| 13 | Proposition 4.4 | affine composites; homogenised barcodes | 3.6 × 10⁻¹⁵; 500 of 500 |
| 14 | Proposition 4.5 | births at the top | bars as predicted |
| 15 | Proposition 4.6 | covariance rank and bound (4.4) | 400 and 400 of 400 |
| 16 | Proposition 4.6 | 1,000 tokens on a cosine stack | numerically full rank 96.9%; effective rank depends on $\tau$ |
| 17 | Example 4.9 | circle covers | plain nerve $H^1$ born mid-stack; data sheaf full |
| 18 | Proposition 4.10 | archive filtration | births at 15, 11, 8, 7; all reach the top |
| 19 | Proposition 4.11 | 1,200 perturbation cases | 0 violations |
| 20 | Theorem 5.3, Remark 5.5 | 4 hand-built and 80 random stacks; zigzag | all equal the bottom; zigzag (1, 1, 0) |
| C# | Appendix A | supplied C# output against fresh NumPy | 13 of 13 output lines identical |

# 7 Discussion

## 7.1 What Part I supplies to the rest of the book

Part II, the horizontal layer, builds the harmonic read on the observation star of Definition 2.4(d). Its normal equations are a harmonic extension problem with fixed boundary values, so Propositions 3.6 to 3.8 supply its residual, conditioning and consensus language. Section 3.5 organises the chapter on design-space topology: branches, angles, signs and subspaces are different coefficient systems. Proposition 3.19 explains why a pairwise context graph over-counts cycles, a point that matters when recombination is read from context overlaps.

Part III, the vertical stack, studies the token recurrence. The separation identity of V2 is the affine composite (4.2) for scalar coefficients, and Proposition 4.4 says that its barcode is the barcode of the linear part. The tangent chapter inherits the distinction between exact and effective rank (Propositions 4.5 and 4.6). The persistence chapter inherits Propositions 4.7 to 4.11 and the zigzag caveat.

Parts IV to VI concern targets, fusion and evidence. Theorem 5.3 has a negative consequence there: product cohomology alone cannot certify changes in targets, laws or feasibility introduced above a fixed bottom layer. Information already encoded at the bottom is not ruled out by this theorem. Example 3.18 previews the marginal extension problem. The dependency order of V2 Section 16 is another finite Alexandrov space, to which Proposition 2.2 applies unchanged.

## 7.2 Diagnostics an implementation should report

Defensibility requires that every ASE run report the objects these results depend on:

- the base on which each sheaf lives (Definition 2.4);
- units and edge weights $W$ (Remark 3.3);
- per layer, $\text{dim}\,H^0$ together with the holonomy or $ℤ_2$ class where it applies (Theorem 3.12, Proposition 3.16);
- the residual bounds $\lambda_2$ and $\lambda_{\text{max}}$ (Proposition 3.7);
- the Leray status and coefficient fidelity of every cover; connectedness alone does not imply acyclicity (Theorem 3.9);
- barcodes together with their conventions: open or closed thresholds, and the tolerance $\tau$ of every effective rank (Propositions 4.6 and 4.10);
- which vertical maps were used: transport, tangent or affine (Definition 4.3).

## 7.3 Open problems

1. **Nonlinear stalks.** Modal subspaces live on Grassmannians and angles on circles. Frame and lift obstructions can be expressed by suitable torsors and nonabelian first cohomology; nonlinear feasibility requires its own construction. Which parts of Section 3 survive, with which bounds?
2. **Learned covers.** When covers are fitted to data, common refinements can supply zigzag comparisons; stable fitted comparison maps are an additional assumption. Stability of zigzag barcodes under perturbation of the fitted covers is needed before births can guide schedules (hypothesis C3 of V2).
3. **Symmetry.** Mirror-symmetric designs (hypothesis C4) call for equivariant sheaves or sheaves on quotient stacks $[X/G]$. Novelty modulo symmetry should be measured on the quotient, and its relation to sections on $X$ needs a theorem.
4. **Two-parameter summaries.** Remark 5.8 rules out complete invariants for layer and scale together. Which rank-invariant summaries are stable and informative for schedules?
5. **Frustration bounds.** For an orthogonal sheaf with $H^0=0$, the smallest eigenvalue of $L$ measures how far the best assignment is from consistent. The connection-Laplacian Cheeger theory [4] relates spectral quantities to frustration under normalisation and unit-vector or orthogonal-frame constraints. Without a norm constraint, the zero assignment always has zero energy. An extension to weighted, rectangular and unit-scaled sheaves would give ASE a certified horizontal diagnostic.
6. **Stability of effective bars.** Proposition 4.6(iv) is pointwise. A perturbation theory for tangent barcodes under changes of the archive, in the language of interleavings [12], would turn effective rank into a stable statistic.

## 7.4 Conclusion

The principle *horizontally topological, vertically algebraic* now has a precise form in three parts. Horizontally, each layer carries a typed data sheaf whose sections, residuals, holonomy and cohomology are computable, with declared units and distinct bases. Vertically, every specified linear diagram along a token's path, and the cohomology of the layers themselves, decomposes into intervals whose births and deaths have exact meanings and effective counterparts. Joined, the two axes form a product whose cohomology is that of its bottom layer, so information about upper-layer changes requires more than this single cohomological summary. Specified linear diagrams admit barcodes, while singular spectra supply metric sensitivity. ADE is the special case in which the horizontal axis is trivial. Part II begins from the observation star and the harmonic read.

# References

::: {custom-style="Bibliography"}
[1] Abramsky, S. and Brandenburger, A. (2011). The sheaf-theoretic structure of non-locality and contextuality. *New Journal of Physics* 13, 113036.

[2] Alexandroff, P. (1937). Diskrete Räume. *Matematicheskii Sbornik (N.S.)* 2(44), 501–519.

[3] Ayzenberg, A., Gebhart, T., Magai, G. and Solomadin, G. (2025). Sheaf theory: from deep geometry to deep learning. arXiv:2502.15476.

[4] Bandeira, A. S., Singer, A. and Spielman, D. A. (2013). A Cheeger inequality for the graph connection Laplacian. *SIAM Journal on Matrix Analysis and Applications* 34(4), 1611–1630. DOI 10.1137/120875338. https://arxiv.org/abs/1204.3873v2

[5] Bodnar, C., Di Giovanni, F., Chamberlain, B. P., Liò, P. and Bronstein, M. M. (2022). Neural sheaf diffusion: a topological perspective on heterophily and oversmoothing in GNNs. *Advances in Neural Information Processing Systems* 35. arXiv:2202.04579.

[6] Bott, R. and Tu, L. W. (1982). *Differential Forms in Algebraic Topology*. Graduate Texts in Mathematics 82. Springer.

[7] Bourgerie, R., Girdzijauskas, Š. and Fodor, V. (2026). Deep neural sheaf diffusion. arXiv:2605.19021.

[8] Bousfield, A. K. and Kan, D. M. (1972). *Homotopy Limits, Completions and Localizations*. Lecture Notes in Mathematics 304. Springer.

[9] Bredon, G. E. (1997). *Sheaf Theory*, 2nd edn. Graduate Texts in Mathematics 170. Springer.

[10] Carlsson, G. and de Silva, V. (2010). Zigzag persistence. *Foundations of Computational Mathematics* 10(4), 367–405. https://doi.org/10.1007/s10208-010-9066-0

[11] Carlsson, G. and Zomorodian, A. (2009). The theory of multidimensional persistence. *Discrete & Computational Geometry* 42(1), 71–93.

[12] Cohen-Steiner, D., Edelsbrunner, H. and Harer, J. (2007). Stability of persistence diagrams. *Discrete & Computational Geometry* 37(1), 103–120.

[13] Crawley-Boevey, W. (2015). Decomposition of pointwise finite-dimensional persistence modules. *Journal of Algebra and Its Applications* 14(5), 1550066.

[14] Curry, J. (2014). *Sheaves, Cosheaves and Applications*. PhD thesis, University of Pennsylvania. arXiv:1303.3255.

[15] Gabriel, P. (1972). Unzerlegbare Darstellungen I. *Manuscripta Mathematica* 6, 71–103.

[16] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[17] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[18] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 1, 17 October 2026.

[19] Ghosh, D. P. (2026d). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[20] Hansen, J. and Ghrist, R. (2019). Toward a spectral theory of cellular sheaves. *Journal of Applied and Computational Topology* 3(4), 315–358.

[21] Harary, F. (1953). On the notion of balance of a signed graph. *Michigan Mathematical Journal* 2(2), 143–146.

[22] Hatcher, A. (2002). *Algebraic Topology*. Cambridge University Press.

[23] Horn, R. A. and Johnson, C. R. (2013). *Matrix Analysis*, 2nd edn. Cambridge University Press.

[24] Kashiwara, M. and Schapira, P. (1990). *Sheaves on Manifolds*. Grundlehren der mathematischen Wissenschaften 292. Springer.

[25] Mac Lane, S. and Moerdijk, I. (1992). *Sheaves in Geometry and Logic: A First Introduction to Topos Theory*. Universitext. Springer.

[26] Oudot, S. Y. (2015). *Persistence Theory: From Quiver Representations to Data Analysis*. Mathematical Surveys and Monographs 209. American Mathematical Society.

[27] Robinson, M. (2017). Sheaves are the canonical data structure for sensor integration. *Information Fusion* 36, 208–224.

[28] Russold, F. (2022). Persistent sheaf cohomology. arXiv:2204.13446. https://arxiv.org/abs/2204.13446

[29] Shepard, A. D. (1985). *A Cellular Description of the Derived Category of a Stratified Space*. PhD thesis, Brown University.

[30] Singer, A. and Wu, H.-T. (2012). Vector diffusion maps and the connection Laplacian. *Communications on Pure and Applied Mathematics* 65(8), 1067–1144.

[31] Steenrod, N. E. (1943). Homology with local coefficients. *Annals of Mathematics* 44(4), 610–627.

[32] Vorob'ev, N. N. (1962). Consistent families of measures and their extensions. *Theory of Probability and Its Applications* 7(2), 147–163.

[33] Weibel, C. A. (1994). *An Introduction to Homological Algebra*. Cambridge Studies in Advanced Mathematics 38. Cambridge University Press.

[34] Zomorodian, A. and Carlsson, G. (2005). Computing persistent homology. *Discrete & Computational Geometry* 33(2), 249–274.
:::

# Appendix A an immutable C# reference kernel

The kernel below assumes dimensionally valid finite inputs and computes the coboundary and the cohomology dimensions of a graph sheaf, and the barcode of a chain from its rank invariant. Values are immutable records; functions are pure, and the rank computation works on a private copy of its input. It targets .NET 8 and has no dependencies beyond the base class library.

```csharp
// ASE Part I reference kernel: graph data sheaves and barcodes of chains.
// Immutable values and pure functions; Rank works on a private copy.
using System;
using System.Collections.Immutable;
using System.Linq;

namespace AsePartOne;

/// <summary>A dense real matrix stored row-major.</summary>
public sealed record Matrix(int Rows, int Cols, ImmutableArray<double> Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Matrix Of(int rows, int cols, params double[] data) =>
        new(rows, cols, ImmutableArray.Create(data));

    public static Matrix Identity(int n) =>
        new(n, n, Enumerable.Range(0, n * n)
            .Select(k => k / n == k % n ? 1.0 : 0.0).ToImmutableArray());

    public Matrix Times(Matrix b) =>
        new(Rows, b.Cols, Enumerable.Range(0, Rows * b.Cols)
            .Select(k => Enumerable.Range(0, Cols)
                .Sum(j => this[k / b.Cols, j] * b[j, k % b.Cols]))
            .ToImmutableArray());

    /// <summary>Rank by Gaussian elimination, relative tolerance.</summary>
    public int Rank(double relTol = 1e-10)
    {
        var a = Data.ToArray();
        double scale = Math.Max(1.0, a.Select(Math.Abs).DefaultIfEmpty(0).Max());
        int rank = 0;
        for (int c = 0; c < Cols && rank < Rows; c++)
        {
            int p = Enumerable.Range(rank, Rows - rank)
                .OrderByDescending(r => Math.Abs(a[r * Cols + c])).First();
            if (Math.Abs(a[p * Cols + c]) <= relTol * scale) continue;
            for (int j = 0; j < Cols; j++)
                (a[p * Cols + j], a[rank * Cols + j]) =
                    (a[rank * Cols + j], a[p * Cols + j]);
            for (int r = rank + 1; r < Rows; r++)
            {
                double f = a[r * Cols + c] / a[rank * Cols + c];
                for (int j = c; j < Cols; j++)
                    a[r * Cols + j] -= f * a[rank * Cols + j];
            }
            rank++;
        }
        return rank;
    }
}

/// <summary>An oriented edge U -> V with restrictions from both stalks.</summary>
public sealed record Edge(int U, int V, Matrix FromU, Matrix FromV)
{
    public int Dim => FromU.Rows;
}

/// <summary>A data sheaf on a graph: vertex stalk dimensions and edges.</summary>
public sealed record GraphSheaf(ImmutableArray<int> VertexDims,
                                ImmutableArray<Edge> Edges)
{
    /// <summary>(delta x)_e = FromV x_V - FromU x_U.</summary>
    public Matrix Coboundary()
    {
        var col = VertexDims.Select((_, i) => VertexDims.Take(i).Sum())
            .ToImmutableArray();
        var row = Edges.Select((_, k) => Edges.Take(k).Sum(f => f.Dim))
            .ToImmutableArray();
        int rows = Edges.Sum(e => e.Dim), cols = VertexDims.Sum();
        double Entry(int r, int c)
        {
            int k = row.LastIndexOf(row.Last(o => o <= r));
            var e = Edges[k];
            int i = r - row[k];
            double Block(int v, Matrix m, double sign) =>
                c >= col[v] && c < col[v] + VertexDims[v]
                    ? sign * m[i, c - col[v]] : 0.0;
            return Block(e.V, e.FromV, 1.0) + Block(e.U, e.FromU, -1.0);
        }
        return new Matrix(rows, cols, Enumerable.Range(0, rows * cols)
            .Select(k => Entry(k / cols, k % cols)).ToImmutableArray());
    }

    /// <summary>dim H0 and dim H1 from the rank of delta.</summary>
    public (int H0, int H1) Cohomology()
    {
        int r = Coboundary().Rank();
        return (VertexDims.Sum() - r, Edges.Sum(e => e.Dim) - r);
    }
}

/// <summary>An interval [Birth, Death], positions from the bottom (1).</summary>
public sealed record Bar(int Birth, int Death, int Multiplicity);

public static class Barcodes
{
    /// <summary>Bars of V_1 -> ... -> V_n from the rank invariant:
    /// m(i, j) = r(i, j) - r(i-1, j) - r(i, j+1) + r(i-1, j+1).</summary>
    public static ImmutableArray<Bar> FromChain(ImmutableArray<int> dims,
                                                ImmutableArray<Matrix> maps)
    {
        int n = dims.Length;
        Matrix Composite(int i, int j) => Enumerable.Range(i - 1, j - i)
            .Aggregate(Matrix.Identity(dims[i - 1]), (m, k) => maps[k].Times(m));
        int R(int i, int j) =>
            i < 1 || j > n || i > j ? 0
            : i == j ? dims[i - 1]
            : Composite(i, j).Rank();
        return (from i in Enumerable.Range(1, n)
                from j in Enumerable.Range(i, n - i + 1)
                let mult = R(i, j) - R(i - 1, j) - R(i, j + 1) + R(i - 1, j + 1)
                where mult != 0
                select new Bar(i, j, mult)).ToImmutableArray();
    }
}
```

A small program builds seven cases: the constant and sign-twisted triangles, the three-line example, the coordinate sheaf of Figure 2b, an orthogonal four-cycle with reflection holonomy, the clean-top chain of Proposition 4.5 with $D=3$, and a chain with dimensions $2,3,2,2$. An independent NumPy implementation recomputes every supplied output line. Table 4 compares the new NumPy run with the recorded C# output; this revision does not claim a fresh .NET compilation. The elimination routine reports numerical rank with a scale floor of one; its threshold is not generally equivalent to an SVD threshold. The test matrices have separated ranks.

Table: **Table 4.** Output of the C# kernel and of the NumPy recomputation. Cohomology lines give $\text{dim}\,H^0$ and $\text{dim}\,H^1$; bar lines give birth position, death position and multiplicity, counted from the bottom (1) to the top.

| C# kernel | NumPy | Match |
|:-----------------|:-----------------|:--|
| `constant 1 1` | `constant 1 1` | yes |
| `twisted 0 0` | `twisted 0 0` | yes |
| `three_lines 0 0` | `three_lines 0 0` | yes |
| `contexts 4 1` | `contexts 4 1` | yes |
| `reflection_cycle 1 1` | `reflection_cycle 1 1` | yes |
| `bar 1 3 2` | `bar 1 3 2` | yes |
| `bar 1 4 1` | `bar 1 4 1` | yes |
| `bar 4 4 2` | `bar 4 4 2` | yes |
| `chain 1 2 1` | `chain 1 2 1` | yes |
| `chain 1 4 1` | `chain 1 4 1` | yes |
| `chain 2 2 1` | `chain 2 2 1` | yes |
| `chain 3 3 1` | `chain 3 3 1` | yes |
| `chain 4 4 1` | `chain 4 4 1` | yes |

# Appendix B reproducibility

Two Python scripts write the numerical-check results to machine-readable files. The main script runs fourteen checks with seed 20261018. The supplementary script runs six more, with seed 20261019: affine barcodes, random stacks with the zigzag, feasible sets, covariance rank, circle covers and the archive filtration. A third script recomputes the C# output, a fourth draws Figures 1 to 6 from the same files, and a fifth replays the random stream of the main script to diagnose the numerically rank-deficient tokens of Section 4.4. Experimental outcomes are inserted from those result files; theorem constants, dimensions fixed by the protocols and literature metadata are specified directly in the source. The supplied run records Python 3.13.16, NumPy 2.5.3, Matplotlib 3.11.2 and .NET SDK 8.0.131. The revision reruns the Python calculations using Python 3.12.14 and NumPy 2.3.5; all stated integer outcomes agree and residual differences are below $10^{-12}$ in absolute value. The two primary numerical result files were also reproduced byte for byte in a second run within the revision environment. Byte-identical results across library versions are not claimed. NumPy matches 13 of 13 supplied C# lines; a .NET SDK is not available for a fresh C# build here. The source, both result versions, comparison audit, Markdown paper and C# project accompany this paper.


## Validation layers

The companion archive separates the supplied result files from the revision results. The mathematical tests check commuting maps, dimensions, rank identities and reconstruction of rank invariants. These checks are independent of the Word layout. Exact assertions on integer dimensions are evaluated separately from floating-point residual comparisons; no failed outcome is hidden by rounding a displayed number.

The covariance replay preserves the original token paths while changing the covariance formula. It therefore tests numerical evaluation of the same pathwise tangent, rather than comparing two different search trajectories. Negative raw-moment eigenvalues near rounding scale are recorded, not interpreted as negative mathematical covariance.

To reproduce the paper, run the two numerical scripts, the tangent diagnostic, the NumPy comparison and the revision audit before assembling Markdown. Rebuild the figures from those results, then convert the Markdown to Word using the included reference styles and finalisation scripts. The supplied C# project can additionally be compiled under its declared SDK; preserve the distinction between a fresh build and comparison against the recorded output.

Document checks verify native Office Math elements, XML readability, relationships to the embedded figures and ordered property elements. Rendered page inspection checks equation legibility, tables and pagination. These are explicit structural and visual checks; they are not presented as a complete independent validation against every OOXML schema rule. The paper's mathematical validity rests on its proofs, and the numerical examples remain finite tests of the stated constructions.
