"""Apply plain scholarly table and pagination settings, preserving native math."""
import sys
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

doc=Document(sys.argv[1])
for table in doc.tables:
    table.autofit=False
    n=len(table.columns)
    # Use distinct column widths for the numerical register and layer contracts.
    header=' '.join(c.text for c in table.rows[0].cells)
    if n==4 and header.startswith('No Statement'):
        widths=[.34,1.22,2.23,3.15]
    elif n==5 and header.startswith('Edge maps'):
        widths=[1.15,1.13,1.95,1.46,1.25]
    elif n==5:
        widths=[.55,.68,1.30,1.93,2.48]
    elif n==2:
        widths=[2.18,4.76] if header.startswith('Check') else [1.48,5.46]
    elif n==3:
        widths=[2.45,2.44,2.05] if header.startswith('Output') else [1.62,3.99,1.33]
    else:
        widths=[6.94/n]*n
    for col,width in zip(table.columns,widths):col.width=Inches(width)
    pr=table._tbl.tblPr
    b=pr.find(qn('w:tblBorders'))
    if b is not None:pr.remove(b)
    b=OxmlElement('w:tblBorders')
    for side in ['top','left','bottom','right','insideH','insideV']:
        el=OxmlElement('w:'+side);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'3');el.set(qn('w:color'),'C4C4C4');b.append(el)
    pr.append(b)
    for ri,row in enumerate(table.rows):
        if ri==0:
            trpr=row._tr.get_or_add_trPr()
            e=OxmlElement('w:tblHeader');trpr.append(e)
        for cell,width in zip(row.cells,widths):
            cell.width=Inches(width)
            for p in cell.paragraphs:
                pf=p.paragraph_format;pf.space_before=Pt(0);pf.space_after=Pt(3);pf.line_spacing=1.04
                for r in p.runs:
                    r.font.size=Pt(9.5);r.font.color.rgb=RGBColor(0,0,0)
                    if ri==0:r.bold=True
for p in doc.paragraphs:
    text=p.text.strip()
    if p.style.name=='Statement' and text.startswith(('Proposition ','Theorem ','Corollary ','Definition ','Example ')):
        p.paragraph_format.keep_with_next=True
    if p.style.name in ('Equation','Statement Equation'):
        p.paragraph_format.keep_together=True
        # Keep a continued equation with its numbered final line.
        if not text.rstrip().endswith(')'):p.paragraph_format.keep_with_next=True
    if p.style.name=='Bibliography':p.paragraph_format.keep_together=True
    if text.startswith('#') and p.style.name=='Source Code':
        pass
doc.core_properties.title='The Horizontal Layer: Autoregressive Sheaf Evolution, Part II'
doc.core_properties.subject='Chapters 3–6: sheaf attention, Gaussian models, certified locality, and design-space topology'
doc.core_properties.author='Debi Prasad Ghosh'
doc.core_properties.keywords='ASE; sheaf attention; harmonic extension; majorisation; locality; engineering optimisation'
doc.save(sys.argv[2])
print('Scholarly tables and pagination applied')
