# Autoregressive Sheaf Evolution, Part II

Companion project for *The Horizontal Layer*, covering Chapters 3–6 of the six-part ASE plan.

The manuscript develops harmonic sheaf attention, a one-layer majorise–minimise theorem, Gaussian mixture/product laws, certified locality, and structured design spaces. The revised source distinguishes exact reads from spectral filtering and corrects the strong-selection limit, point-atom criterion, saddle instability, and canonical-index claims.

## Reproduce numerical results

Use Python with NumPy, SciPy, Matplotlib and python-docx. The current versions are recorded in `verification.json`. With a single BLAS thread, run:

```sh
OPENBLAS_NUM_THREADS=1 python3 p2_checks.py
OPENBLAS_NUM_THREADS=1 python3 p2_extras.py
OPENBLAS_NUM_THREADS=1 python3 review_checks.py
python3 cs_validate.py
python3 verify_results.py
python3 fig_p2.py
```

There are 20 main experiment groups, 14 supplementary groups and 8 focused review checks. The violation counters and selected quantitative tolerances are asserted by `verify_results.py`. These finite experiments support the implementations; the manuscript proofs establish the mathematical results.

`supplied_results/` preserves the original three JSON files. `reproducibility.json` compares them with the current rerun. They are not claimed byte-identical across environments. The Python reader now uses the same absolute/relative spectral cutoff declared in the paper. The truncation check separately evaluates the sharp posterior-mass bound and the computable certificate, and records skipped empty stars and uncertified radius attempts. The final gradient diagnostic is computed as `H @ z - b`, rather than from a filtered step.

## C# comparison

`cs/SheafAttention.cs` uses immutable values and a private-copy Jacobi eigensolver. The project targets .NET 8. In the environment used for this revision, .NET was not installed; the 12 supplied output lines in `cs/cs_out.txt` were compared afresh with an independent NumPy implementation. All 12 agree to the declared scaled tolerance; 11 are identical to 15 significant digits. No fresh C# compilation is claimed. The revised C# source caches the weight denominator once; its arithmetic is unchanged.

To regenerate the C# output where .NET 8 is available, run `dotnet run -c Release` in `cs/`, redirect stdout to `cs_out.txt`, then rerun `cs_validate.py` and `verify_results.py`. Inputs must be finite and dimensionally consistent. This is a reference kernel.

## Build the Word paper

`src/` contains the final source fragments; `paper.md` is the assembled Markdown. Reported register outcomes are filled from result JSON files; theorem constants and example parameters are declared in the source. Figure panels recomputed from fixed seeds are identified in the captions.

Install Pandoc and run `sh build.sh`. It makes plain scholarly styles from `ref.docx`, applies table formatting, preserves native OMML mathematics, and writes `paper.docx`. `postprocess.py` orders known XML properties and formats numbered equations. This is structural checking, not a full OOXML schema validation.

For layout QA, use the documents skill renderer or LibreOffice to render the final file, and inspect every page at full size. Render intermediates are not included in this archive.
