#!/bin/sh
# Build from recorded results. Run the experiment scripts separately to regenerate results.
set -eu
cd "$(dirname "$0")"
part2_python="${PYTHON:-python3}"
"$part2_python" verify_results.py
"$part2_python" build_reference.py 11 1.08
"$part2_python" render.py
pandoc paper.md -o raw.docx --reference-doc=scholarly_ref.docx --no-highlight
"$part2_python" finalize_docx.py raw.docx styled.docx
"$part2_python" postprocess.py styled.docx paper.docx
printf '%s\n' 'paper.docx written; render and inspect all pages before release.'
