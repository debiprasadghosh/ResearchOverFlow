"""Basic Word package checks, distinct from full OOXML schema validation."""
from pathlib import Path
from zipfile import ZipFile
from lxml import etree
import json,sys
P=Path(__file__).parent
path=Path(sys.argv[1]) if len(sys.argv)>1 else P/'paper.docx'
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
with ZipFile(path) as z:
    for name in z.namelist():
        if name.endswith(('.xml','.rels')):etree.fromstring(z.read(name))
    doc=etree.fromstring(z.read('word/document.xml'))
    styles=etree.fromstring(z.read('word/styles.xml'))
    text=''.join(doc.itertext())
    assert '{{' not in text
    maths=len(doc.findall('.//m:oMath',ns))
    assert maths>500
    assert not doc.findall('.//w:ins',ns) and not doc.findall('.//w:del',ns)
    assert not styles.xpath('//w:style[@w:styleId="Statement"]//w:shd',namespaces=ns)
    report=dict(xml_parts_parse=True,native_math_objects=maths,tables=len(doc.findall('.//w:tbl',ns)),
                inline_figures=len(doc.findall('.//w:drawing',ns)),unfilled_placeholders=False,
                tracked_changes=False,full_schema_validation=False)
(P/'document_structure.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
