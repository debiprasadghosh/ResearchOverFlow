# Mathematical review of Part II

The final manuscript retains the proposed six-part book structure and covers Chapters 3–6. The main one-layer MM theorem, harmonic extension, operator weights, Gaussian laws, locality bounds, Jacobian, and design-space topology are proved in the manuscript.

Substantive refinements:

1. Positive operator weights form a partition of the identity in the normal-matrix inner product. They do not imply ordinary convex-hull containment in another metric.
2. Exact pseudoinverse reads and numerically filtered reads are separate operators. An ideal spectral cutoff preserves the MM decrease inequality, but a filtered fixed point need not be stationary for the exact energy.
3. Strong selection can collapse coverage without collapsing the exact conditional coordinate averages. The limit of reads need not equal the retention read of the limiting normal matrix.
4. Derivatives and descent require fixed maps, baseline weights, archive and scale over the stated domain or segment. Attention itself remains query dependent.
5. Strict minima attract locally; negative curvature gives an expanding direction, while a saddle can have a stable manifold. Degenerate critical points are not classified by the linear result.
6. A boundary-supported law need not have point atoms. The relevant condition is positive probability of an individual decoder preimage.
7. Coincident angle antipodes contribute their total attention. A projector-based subspace read still needs a spectral gap at the chosen cluster boundary.
8. Discontinuous canonicalisation can miss nearby orbits in a single Euclidean radius index. It does not misidentify exact orbit duplicates when representatives are chosen consistently.
9. Gaussian measurement claims concern expected unnormalised weights. The sample-variance correction has an explicit bias factor, including its equality case.
10. Units are standardised before discrepancies, and the latent base, layer order, cover nerve and observation star remain distinct. A numerical state update is not automatically a sheaf morphism.

The vertical interface uses the Jacobian of the complete relaxed layer, `(1 − lambda) I + lambda Dm`; multiplying read Jacobians alone is insufficient for general relaxations.

Numerical corrections:

- The Python reader now applies the declared cutoff consistently in both absolute and relative scale regimes.
- Final exact energy gradients are evaluated as H z − b, rather than inferred from a filtered displacement.
- Truncation separately tests the sharp posterior-mass bound and the computable certificate. Empty stars are counted and excluded explicitly, and certified-radius success counts are reported.
- Candidate stationary points are checked against a gradient tolerance.
- The independent NumPy comparison checks that all twelve supplied C# lines are present. No fresh C# compilation is claimed.
- The current C# source caches the attention denominator once, removing an unnecessary repeated sum without changing its arithmetic.

`verification.json` records the passing checks. `reproducibility.json` preserves differences from the supplied results; they are not described as exact cross-environment reproduction. Native OMML and package structure are checked and the final Word document is rendered for page-by-page review. Full OOXML schema validation is not claimed.
