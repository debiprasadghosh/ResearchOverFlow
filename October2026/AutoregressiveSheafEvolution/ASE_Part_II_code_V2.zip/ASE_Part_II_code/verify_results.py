"""Check reported tolerances and record differences from supplied results."""
import json,platform
from pathlib import Path
import numpy,scipy,matplotlib
P=Path(__file__).parent
def load(n):return json.loads((P/n).read_text())
c=load('p2_checks.json');x=load('p2_extras.json');v=load('cs_validate.json');r=load('review_checks.json')
def flags(d,path=''):
    out=[]
    if isinstance(d,dict):
        for k,vv in d.items():
            if 'viol' in k:out.append((path+'.'+k,int(vv)))
            out.extend(flags(vv,path+'.'+k))
    return out
vf=flags(c)+flags(x)+flags(r)
assert all(n==0 for _,n in vf),vf
assert len(c)==20 and len(x)==14 and len(r)==8
assert c['mm']['runs_monotone']==c['mm']['runs']
assert c['harmonic_extension']['better_found']==0
assert c['ade_recovery']['max_err']<1e-12
assert c['jacobian']['fd_rel_err']<1e-4
assert x['hessian_and_step']['hessian_rel_err']<1e-4
assert x['stationary']['max_gradient']<1e-7
assert x['retention']['nearest_minimiser_err']<1e-7
assert all(float(vv)<=float(kk)/(1+float(kk))+1e-8 for kk,vv in x['retention']['ridge_rel_err'].items())
assert v['agree']==v['lines']==12
def differences(a,b,path=''):
    out=[]
    if isinstance(a,dict) and isinstance(b,dict):
        for k in sorted(a.keys()|b.keys()):out.extend(differences(a.get(k),b.get(k),path+'.'+k))
    elif isinstance(a,list) and isinstance(b,list):
        if len(a)!=len(b):out.append([path,'length',len(a),len(b)])
        else:
            for i,(aa,bb) in enumerate(zip(a,b)):out.extend(differences(aa,bb,path+'.'+str(i)))
    elif a!=b:out.append([path,'value',a,b])
    return out
out={}
for name in ['p2_checks.json','p2_extras.json','cs_validate.json']:
    a=json.loads((P/'supplied_results'/name).read_text());b=load(name);ds=differences(a,b)
    numeric=[d for d in ds if isinstance(d[2],(int,float)) and isinstance(d[3],(int,float))]
    out[name]=dict(byte_identical=(P/'supplied_results'/name).read_bytes()==(P/name).read_bytes(),
                   changed_fields=len(ds),max_absolute_numeric_difference=max((abs(d[2]-d[3]) for d in numeric),default=0),differences=ds)
(P/'reproducibility.json').write_text(json.dumps(out,indent=2))
report=dict(status='PASS',main_groups=len(c),extra_groups=len(x),review_checks=len(r),zero_violation_flags=len(vf),
            csharp_comparison_lines=v['lines'],csharp_agree=v['agree'],csharp_freshly_compiled=False,
            environment=dict(python=platform.python_version(),numpy=numpy.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__))
(P/'verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
