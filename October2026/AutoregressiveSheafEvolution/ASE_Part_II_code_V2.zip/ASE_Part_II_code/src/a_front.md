---
title: "The Horizontal Layer"
subtitle: "One layer of Autoregressive Sheaf Evolution. Part II: sheaf attention, Gaussian stalks, locality and the topology of design spaces"
author:
  - "Debi Prasad Ghosh"
  - "Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India"
date: "Defensible Intelligence series · Autoregressive Sheaf Evolution, Part II · 18 October 2026 · “Respect science. Import emotion.”"
abstract: |
  Part II of Autoregressive Sheaf Evolution develops the horizontal layer: a token reads mapped observations on a star, then moves towards their harmonic extension. The minimum-change read retains the token in unobserved directions. Positive operator weights explain how partial records recombine outside the archive hull, while coordinatewise bounds limit the gain. The principal theorem identifies the read as a majorise–minimise step for a soft discrepancy energy. Every relaxation between zero and two has an explicit decrease bound, and deterministic ADE is recovered at its own layer scale. The Gaussian analysis separates proper mixtures from proper products, imputation from harmonic extension, and loss of coverage from loss of exact recombination. In particular, taking a strong-selection limit and taking a pseudoinverse need not commute. Locality is quantified by computable truncation certificates; sensitivity by an exact Jacobian and covariance bound. Branches, angles, signs, modal subspaces and physical symmetries require distinct treatments. Numerical evidence comprises thirty-four supplied checks rerun in the current environment, eight focused review checks, and a fresh NumPy comparison with the twelve supplied C# output lines. The results establish one-layer guarantees rather than improved optimisation across a stack.

---

# 1 Introduction

Autoregressive Diffusion Evolution (ADE) reads an archive of evaluated designs through a Gaussian kernel at every layer of a denoising stack [12, 13]. Autoregressive Sheaf Evolution (ASE) replaces the single Euclidean retrieval geometry of ADE by local data spaces, compatibility maps and scale-dependent covers [14]. Part I made the organising principle precise: each layer is horizontally topological, and each token's journey through the layers is vertically algebraic [15]. It also separated four bases that are easily confused. One of them is the observation star, a token vertex joined to one leaf per retrieved record [15, Definition 2.4(d)]. This paper, Part II of the book, studies what happens on that star. It covers chapters 3 to 6 of the book plan: sheaf attention, Gaussian models in a stalk, scale locality and covers, and the topology of design spaces [14, Section 21].

A layer does one thing to a token. It reads records through maps and moves towards the read. With record observations $o_i=R_iy_i$, token-side edge maps $Q_i$, prior weights $w_i$ and scale $s$, the read is

::: {custom-style="Equation"}
$e_i(z)=\tfrac12\|Q_iz-o_i\|^2,\qquad \alpha_i\propto w_i\,e^{-e_i(z)/s^2}$
:::

::: {custom-style="Equation"}
$H=\sum_i\alpha_iQ_i^{\top}Q_i,\qquad b=\sum_i\alpha_iQ_i^{\top}o_i,\qquad m=H^{-1}b$ (1.1)
:::

when $H$ is invertible. With identity maps, (1.1) is the ADE read and also biased softmax attention [13, Proposition 5.1; 24]. With general maps, it is the harmonic extension of the observations from the leaves of the star to the token [14, Proposition 5.1]. We call (1.1), with the retention rule of Definition 2.2 for singular $H$, *sheaf attention*. Barbero and co-authors used the phrase earlier for a graph neural network layer that learns attention coefficients on a cellular sheaf [1, 4]. Ours is a different object: a read on an observation star, with fixed maps and weights computed from discrepancies.

![**Figure 1.** (a) The observation star of one token. Each edge carries an edge stalk $ℝ^{k_i}$, reached from the token by $Q_i$ and from the record by $R_i$. (b) Two records with complementary coordinate masks: the read takes $x_1$ from the first and $x_2$ from the second, and lands outside the archive hull. On the cost $-x_1-x_2$ both records score $-1.1$ and the read scores $-2.0$ (Proposition 3.5). (c) Two records whose observation spaces are lines at an angle $\theta$. A unit move of one observation moves the read by exactly $1/\sin\theta$, below the general bound of Proposition 3.7.](fig/star.png){width=100%}

## 1.1 Contributions

- **Sheaf attention as an operator (Section 3).** We give the Schur-complement form of the harmonic extension (Proposition 3.1) and the retention read for singular normal matrices (Proposition 3.2). Matrix weights are invariant under lifts and self-adjoint in the $H$-geometry (Proposition 3.3). We prove hulls, coordinate boxes, a crossover property and a coordinatewise ceiling (Corollary 3.4, Proposition 3.5), and the exact spectrum of two weighted projectors with two-sided conditioning bounds (Proposition 3.6). The central result is the majorise–minimise theorem (Theorem 3.10). It gives guaranteed descent for every relaxation $0\le\lambda\le 2$, and every deterministic ADE layer descends at its own scale (Corollary 3.12).
- **Gaussian stalks (Section 4).** Tweedie's identity holds in preconditioned form (Proposition 4.1). The chart posterior of the mathematics book and sheaf attention differ exactly off the chart (Proposition 4.2). Mixtures of partial records are improper, while products of experts are proper exactly under coverage (Proposition 4.3). One imputation is a gradient step, and repeated imputation is Cimmino's method converging to the harmonic read (Proposition 4.4). Selection tilting collapses coverage (Proposition 4.6). Bounded measurement error has a sharp $\tanh$ bound (Theorem 4.8).
- **Locality (Section 5).** We give a posteriori truncation certificates for transported reads, with certified radii, and for rectangular reads (Proposition 5.1, Corollary 5.2, Theorem 5.3). The Jacobian of the read is exact and has a covariance bound (Proposition 5.4). Strict minima are locally attracting and negative-curvature stationary points are unstable (Corollary 5.5). Section 5.3 states the cost and index contracts that the certificates need.
- **Topology (Section 6).** Shared reads land in the gap between branches (Proposition 6.2). Local angle reads jump only at antipodes, with an exponential bound when another record is nearer (Proposition 6.5). Nearest-image reads approximate all-image reads for every finite orthogonal group (Theorem 6.6), and projector reads are stable under measurement error (Proposition 6.8). Orbit indexes are exact for reflection groups, and every continuous canonicalisation fails for involutions with two or more antisymmetric directions (Proposition 6.10).
- **Evidence.** There are {{d.n_checks}} numerical checks (Table 6): {{d.n_main}} from a main script and {{d.n_extra}} from a supplementary script. An immutable C# kernel agrees with an independent NumPy implementation on every output line (Appendix A).

## 1.2 Scope and status of statements

Part II concerns one layer at one query. It makes no claim about search performance, sampling validity or the feasibility of proposed designs. The hypotheses C1 to C5 of V2 remain open, and nothing here tests them [14, Sections 17–18]. Each numbered mathematical statement carries a provenance tag. *Classical* marks a known result restated in ASE notation. *V2* marks a statement of the conversion proposal [14], sometimes with a new proof. *Mathematics book* marks a result retained from [13], with its number there. *New in Part II* marks a statement proved here for the first time in this programme; each comes with a proof and a numerical check. All spaces are finite-dimensional and real. The observation maps, baseline weights, archive and scale are fixed throughout each derivative and descent argument; attention weights depend on the query and are frozen only when forming the quadratic surrogate. A query-dependent star, learned map or prior adds terms or changes the energy and requires a separate argument. The word “new” is relative to this ASE programme, not a claim of priority over the literature.

## 1.3 Conventions and notation

Table: **Table 1.** Notation used throughout Part II.

| Symbol | Meaning |
|:--------------|:--------------------------------------------------------------|
| $z\in ℝ^D$ | token state in the token frame |
| $y_i,\ R_i,\ o_i=R_iy_i$ | record value, record-side map and observation |
| $Q_i:ℝ^D\to ℝ^{k_i}$ | token-side edge map of record $i$ |
| $w_i,\ s$ | prior weight of record $i$ and the scale of the layer |
| $e_i,\ \alpha_i$ | discrepancy and attention weight (2.1) |
| $H,\ b,\ m$ | normal matrix, right side and read (2.2), (2.3) |
| $E_s$ | soft discrepancy energy (3.6) |
| $\kappa_j$ | coverage of coordinate $j$ under masks |
| $c_A$ | the largest $\lambda_{\text{max}}(Q_i^{\top}Q_i)$ over the records |
| $S,\ W,\ W_S,\ D_S$ | star, total archive weight, star weight and star kernel mass |
| $G,\ d_G$ | finite group of orthogonal symmetries and its orbit distance |
| $\langle g\rangle$ | the $\alpha$-weighted mean $\sum_i\alpha_ig_i$ |

# 2 The observation star and the layer contract

An ASE layer consumes a token, a versioned archive, declared edge maps and schedule coefficients. It produces a proposal together with its read, its star and numerical diagnostics [14, Section 4]. The read is computed on an auxiliary graph, the observation star. The cover nerve describes the base geometry, while the star describes the observations attached to it. ADE has a one-vertex nerve and a star with one leaf per record [15, Proposition 5.9].

::: {custom-style="Statement"}
**Definition 2.1** (observation star). At one layer, fix a token frame $ℝ^D$ and retrieved records $i=1,\ldots,n$ with values $y_i\in ℝ^{d_i}$, edge maps $Q_i:ℝ^D\to ℝ^{k_i}$ and $R_i:ℝ^{d_i}\to ℝ^{k_i}$, observations $o_i=R_iy_i$, prior weights $w_i>0$ and a scale $s>0$. The discrepancy and attention weight of record $i$ at the token $z$ are
:::

::: {custom-style="Statement Equation"}
$e_i(z)=\tfrac12\|Q_iz-o_i\|^2,\qquad \alpha_i(z)=\frac{w_i\exp(-e_i(z)/s^2)}{\sum_jw_j\exp(-e_j(z)/s^2)}$ (2.1)
:::

::: {custom-style="Statement"}
and the normal matrix and right side are
:::

::: {custom-style="Statement Equation"}
$H(z)=\sum_i\alpha_i(z)\,Q_i^{\top}Q_i,\qquad b(z)=\sum_i\alpha_i(z)\,Q_i^{\top}o_i$ (2.2)
:::

::: {custom-style="Statement Tag"}
V2 Section 4, made a definition.
:::

::: {custom-style="Statement"}
**Definition 2.2** (sheaf attention). The read at $z$ is
:::

::: {custom-style="Statement Equation"}
$m(z)=z+H^{\dagger}(b-Hz)$ (2.3)
:::

::: {custom-style="Statement"}
where $H^{\dagger}$ is the Moore–Penrose pseudo-inverse. If $H\succ 0$, then $m=H^{-1}b$. The eigenvectors of $H$ with eigenvalue zero span the unresolved directions, in which the read keeps the token's own value. Equation (2.3) is the exact operator. Its floating-point approximation is a separate, spectrally filtered operator $m_\epsilon$: in floating point, eigenvalues at most $\epsilon\,\text{max}(1,\lambda_{\text{max}}(H))$ are treated as zero, and the layer raises an unresolved flag. The kernel of Appendix A uses $\epsilon=10^{-10}$.
:::

::: {custom-style="Statement Tag"}
V2 Definition 4.1, with the retention rule of V2 Section 4 made explicit.
:::

The kernel computes $m_\epsilon=z+H_\epsilon^\dagger(b-Hz)$, where $H_\epsilon^\dagger$ inverts only eigenvalues above the declared cutoff. A discarded positive eigenvalue is numerically unresolved, rather than algebraically absent. Underflow can also replace a mathematically positive attention weight by zero. All claims involving exact stationarity, observability or limits below concern $m$ unless explicitly stated otherwise.

## 2.1 Units before residuals

The edge norm is part of the model. Convert physical quantities to common dimensionless units, or whiten them by a declared positive-definite error covariance, before forming (2.1). For raw maps $\bar Q_i,\bar R_i$ and a whitening map $W_i$, use $Q_i=W_i\bar Q_i$ and $R_i=W_i\bar R_i$. A change of units must be cancelled by the corresponding change of $W_i$; otherwise it changes attention and the resulting optimisation problem. Different edge dimensions or noise conventions require explicit calibration of prior weights, including normalising constants if a probabilistic interpretation is intended. An edge map is not evidence that incompatible physical quantities may be subtracted.

## 2.2 The four bases and the vertical interface

Keep the latent base $X_t$, the layer order $T$, the cover nerve $N(\mathcal U_t)$ and the observation star distinct. The nerve encodes overlaps of regions; the star attaches observations to one query. A stalk is a data space. A token carries values and a vertical fibre diagram, rather than being a stalk itself. With a continuous comparison $\Phi_t:X_t\to X_{t-1}$, a layer morphism has target $\Phi_t^{-1}\mathcal F_{t-1}$; the comparison squares with horizontal restriction maps must commute. A state-dependent numerical read is not automatically a linear sheaf morphism. This paper supplies that read; Part III must specify how it enters the stack.

Each record contributes through its own observation space, so a record can contribute a strong subassembly without contributing anything else. A coordinate mask records what a record actually observed; an unobserved coordinate receives no invented value [14, Section 4]. Table 2 lists the map classes that recur below.

Table: **Table 2.** Classes of edge maps. Here $n$ is the number of records in the star; costs count arithmetic operations per read, with transports $Q_i^{\top}o_i$ and normal blocks $Q_i^{\top}Q_i$ stored with the records.

| Edge maps | Normal matrix | Read | Where the read lies | Cost per read |
|:----------------|:--------------|:----------------|:----------------|:----------------|
| identity | $H=I$ | $\sum_i\alpha_iy_i$, the ADE read | archive hull | $O(nD)$ |
| orthogonal transport | $H=I$ | $\sum_i\alpha_iQ_i^{\top}o_i$ | transported hull | $O(nD)$ |
| coordinate mask | diagonal coverage | observed means; retain other coordinates | observed box if fully covered | $O(\sum_ik_i+D)$ |
| partial isometry | $0\preceq H\preceq I$ | limit of repeated imputation | no hull in general | $O(nD^2+D^3)$ |
| general rectangular | $H\succeq 0$ | $z+H^{\dagger}(b-Hz)$ | no hull in general | $O(nD^2+D^3)$ |
