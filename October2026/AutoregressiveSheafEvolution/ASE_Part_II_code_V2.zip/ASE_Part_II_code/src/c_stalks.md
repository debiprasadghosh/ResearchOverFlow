
# 4 Gaussian models in a stalk

ADE rests on a Gaussian observation model: the query is a noisy view of an archived design, and the read is a posterior mean [13, Chapter 3]. In ASE that model becomes local. It is attached to one stalk, and the records are seen through their maps. This section asks which of the Gaussian identities of ADE survive, and in what form.

## 4.1 Tweedie's identity and the chart posterior

::: {custom-style="Statement"}
**Proposition 4.1** (Tweedie's identity in a stalk).
:::

::: {custom-style="Statement"}
\(i) For square orthogonal maps, let $p_s(z)=\sum_iw_i\,N(z;v_i,s^2I)/\sum_iw_i$ with $v_i=Q_i^{\top}o_i$. Then $m(z)=z+s^2\nabla\log p_s(z)$.
:::

::: {custom-style="Statement"}
\(ii) For general maps, let $\tilde p_s(z)=\sum_iw_i\exp(-e_i(z)/s^2)$, which may have infinite mass. Then $H(z)(m(z)-z)=s^2\nabla\log\tilde p_s(z)$, and if $H\succ 0$,
:::

::: {custom-style="Statement Equation"}
$m(z)=z+s^2H(z)^{-1}\nabla\log\tilde p_s(z)$ (4.1)
:::

::: {custom-style="Statement Tag"}
\(i) Classical: Tweedie's formula [10], in the unscaled form of Mathematics book Proposition 3.3; (ii) New in Part II.
:::

*Proof.* Since $\log\tilde p_s=-E_s/s^2$, Proposition 3.9 gives $s^2\nabla\log\tilde p_s=-\nabla E_s=H(m-z)$, which is (ii). For square orthogonal maps $e_i=\tfrac12\|z-v_i\|^2$, so $\tilde p_s$ is proportional to $p_s$ and $H=I$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{c.gradient_tweedie.tweedie_cases}} random orthogonal stars, $z+s^2\nabla\log p_s$, with the gradient taken by central differences, matched the read to {{c.gradient_tweedie.tweedie_err|e1}}. Part (ii) is the gradient identity of Proposition 3.9, checked there.
:::

The preconditioned form (4.1) says that the read follows the score of the local density potential, rescaled by the inverse of the normal matrix. Only the gradient of a logarithm enters, so the identity holds even when $\tilde p_s$ cannot be normalised (Proposition 4.3).

The mathematics book also reads full designs through a chart, but from the other side: there the token is observed through the chart, while the records are complete [13, Proposition 3.8]. The two operators can be compared exactly.

::: {custom-style="Statement"}
**Proposition 4.2** (chart posterior and sheaf read). Let $U\in ℝ^{D\times k}$ have orthonormal columns, let $\Sigma$ be a positive diagonal $k\times k$ matrix and $A=\Sigma^{-1}U^{\top}$, and let the records be full designs $y_i$. Put $a=1/(1+s^2)$ and $q=\sqrt a\,Az$.
:::

::: {custom-style="Statement"}
\(i) The posterior mean of the full design under the chart observation $q$ [13, Proposition 3.8] is $m_{\text{chart}}=\sum_i\alpha_iy_i$, with $\alpha_i\propto w_i\exp(-\|Az-Ay_i\|^2/2s^2)$. These are exactly the weights of sheaf attention with $Q_i=A$ and $o_i=Ay_i$.
:::

::: {custom-style="Statement"}
\(ii) The sheaf read of the same observations is $m_{\text{sheaf}}=P_Am_{\text{chart}}+(I-P_A)z$, where $P_A=A^{\dagger}A$ is the orthogonal projector onto the row space of $A$. Hence
:::

::: {custom-style="Statement Equation"}
$m_{\text{chart}}-m_{\text{sheaf}}=(I-P_A)(m_{\text{chart}}-z)$ (4.2)
:::

::: {custom-style="Statement Tag"}
Mathematics book Proposition 3.8; the comparison is New in Part II.
:::

*Proof.* (i) The logit of [13, (3.7)] is $\|q-\sqrt a\,Ay_i\|^2/2(1-a)=a\|Az-Ay_i\|^2/2(1-a)$, and $a/(1-a)=1/s^2$. (ii) Here $H=A^{\top}A$ and, since the weights sum to one, $b=A^{\top}A\,m_{\text{chart}}$. Then $H^{\dagger}H=A^{\dagger}A=P_A$, so $m_{\text{sheaf}}=z+H^{\dagger}H(m_{\text{chart}}-z)=z+P_A(m_{\text{chart}}-z)$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{x.chart_vs_sheaf.cases}} random charts, the two weight vectors agreed to {{x.chart_vs_sheaf.weight_err|e1}}, and (4.2) held to {{x.chart_vs_sheaf.difference_err|e1}}. The median distance between the two reads was {{x.chart_vs_sheaf.median_gap|f2}}.
:::

*Engineering meaning.* The two operators answer different questions. The chart posterior returns a convex combination of complete archived designs, and so it imports the records' coordinates off the chart. Sheaf attention keeps the token's coordinates off the chart, because it sees the records only through their maps. Which one is right depends on what the records carry. Complete designs make the posterior available. With partial observations, the retention read is a specified minimum-change rule. A different read needs additional assumptions, such as a declared prior on unobserved coordinates.

## 4.2 Two local laws

A local Gaussian model in a stalk can be built from the records in two ways, and the difference matters as soon as a record is partial.

::: {custom-style="Statement"}
**Proposition 4.3** (mixture and product). Use Lebesgue measure on the full unbounded token space $\mathbb R^D$, with $s>0$ and positive weights. Freeze the weights $\alpha$ at the query for the product law.
:::

::: {custom-style="Statement"}
\(i) The record mixture $\mu_{\text{mix}}(dx)\propto\sum_iw_i\exp(-e_i(x)/s^2)\,dx$ has finite mass if and only if every $Q_i$ is injective.
:::

::: {custom-style="Statement"}
\(ii) The product of experts $\mu_{\text{prod}}(dx)\propto\prod_i\exp(-\alpha_ie_i(x)/s^2)\,dx=\exp(-M(x)/s^2)\,dx$ has finite mass if and only if $H\succ 0$, and then $\mu_{\text{prod}}=N(m,s^2H^{-1})$.
:::

::: {custom-style="Statement Tag"}
New in Part II; products of experts after [18].
:::

*Proof.* (i) The $i$-th term is constant along $\text{ker}\,Q_i$ and Gaussian along $\text{range}\,Q_i^{\top}$, so its integral is finite if and only if $\text{ker}\,Q_i=\{0\}$. A finite sum of positive terms has finite integral if and only if each term does. (ii) By Proposition 3.2, $M(x)=M(m)+\tfrac12(x-m)^{\top}H(x-m)$. The Gaussian integral is finite if and only if $H\succ 0$, and its covariance is then $s^2H^{-1}$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* At $s=1$, on boxes of half-width 5, 10, 20 and 40, the mass of a full record in the plane was {{d.prop_full.0|f3}}, {{d.prop_full.1|f3}}, {{d.prop_full.2|f3}} and {{d.prop_full.3|f3}}, agreeing with $2\pi$ at the shown precision. The mass of a record observing one coordinate was {{d.prop_part.0|f1}}, {{d.prop_part.1|f1}}, {{d.prop_part.2|f1}} and {{d.prop_part.3|f1}}, proportional to the box width. The product of two records observing complementary coordinates has $\lambda_{\text{min}}(H)={{c.properness.product_min_eig_covering}}$; the product of two records observing the same coordinate has $\lambda_{\text{min}}(H)={{c.properness.product_min_eig_same_coordinate}}$.
:::

*Engineering meaning.* A local law in ASE must say whether it is a mixture or a product. On the full unbounded space, a positive mixture containing a partial record has infinite mass. Restricting the domain or adding a proper prior changes this conclusion and must be declared before sampling or using importance weights [14, Section 15]. A product is a law exactly when the records jointly cover the frame, and its covariance $s^2H^{-1}$ is the conditioning of Proposition 3.6 in probabilistic form.

::: {custom-style="Statement"}
**Proposition 4.4** (imputation, gradient steps and the harmonic read). Let every $Q_i$ be a partial isometry, $Q_iQ_i^{\top}=I$, and freeze $\alpha$ at $z$. Impute record $i$ from the token by $x_i(z)=Q_i^{\top}o_i+(I-Q_i^{\top}Q_i)z$, the point of $\{x:Q_ix=o_i\}$ nearest to $z$, and let $m_A=\sum_i\alpha_ix_i$.
:::

::: {custom-style="Statement"}
\(i) $m_A=z-\nabla E_s(z)$: one imputation is a unit gradient step.
:::

::: {custom-style="Statement"}
\(ii) If $H\succ 0$, then $m-z=H^{-1}(m_A-z)$ and $\|m-z\|\ge\|m_A-z\|$: the harmonic read is the preconditioned step, and it moves at least as far.
:::

::: {custom-style="Statement"}
\(iii) If $H\succ0$, repeated imputation with frozen weights, $x_{k+1}=\sum_i\alpha_i[Q_i^{\top}o_i+(I-Q_i^{\top}Q_i)x_k]$ with $x_0=z$, satisfies $\|x_k-m\|\le(1-\lambda_{\text{min}}(H))^k\|z-m\|$ and converges to the harmonic read.
:::

::: {custom-style="Statement Tag"}
New in Part II; (iii) is Cimmino's method of averaged projections [7] in the present notation.
:::

*Proof.* (i) $m_A=b+(I-H)z=z-(Hz-b)$. (ii) $H(m-z)=b-Hz=m_A-z$. Each $Q_i^{\top}Q_i$ is an orthogonal projector, so $H\preceq I$ and, with $H\succ 0$, $H^{-1}\succeq I$. (iii) Since $m=b+(I-H)m$, we have $x_{k+1}-m=(I-H)(x_k-m)$, and $\|I-H\|=1-\lambda_{\text{min}}(H)$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{c.imputation.cases}} stars with masks and partial isometries, (i) held to {{c.imputation.gradient_identity_err|e1}}, and (ii) to {{c.imputation.preconditioning_identity_err|e1}} on the {{c.imputation.well_conditioned}} stars with condition number below $10^8$. The median distance between $m_A$ and $m$ was {{c.imputation.median_gap|f3}}. In {{x.cimmino.trials}} further stars, the rate bound of (iii) held at $k=50$ in every case. On the {{x.cimmino.well_covered}} stars with $\lambda_{\text{min}}(H)>0.05$, 2,000 sweeps reached the read to {{x.cimmino.final_err|e1}}.
:::

![**Figure 3.** (a) Two partial records whose observation sets are lines, with equal frozen weights. The imputations (squares) are the projections of the token onto the lines; their average is one gradient step (Proposition 4.4(i)), and repeated averaging converges to the harmonic read at the intersection (Proposition 4.4(iii)). (b) The smallest eigenvalue of $H$ against the selection strength $\beta$ for twelve masked records in $ℝ^4$, with an elite that observes two coordinates or all four (Proposition 4.6; register values). (c) Total variation between the weights before and after a bounded measurement error, against $\beta\varepsilon$, for 1,500 random trials drawn for the figure, with the sharp bound $\tanh(\beta\varepsilon/2)$ of Theorem 4.8.](fig/stalks.png){width=100%}

*Engineering meaning.* An imputation crossover fills a parent's missing coordinates from the current design. By Proposition 4.4 it takes one gradient step on the soft energy, and repeating it with fixed weights converges to the harmonic read. The harmonic read moves farther in poorly covered directions. That is where recombination acts, and also where conditioning matters.

## 4.3 Tilting

The mathematics book tilts a Gaussian by a linear loss and moves its mean by $-\beta\Sigma a$ [13, Theorem 4.4]. Two tilts arise in a stalk: of the local law, and of the record weights by selection.

::: {custom-style="Statement"}
**Proposition 4.5** (tilting the product law). If $H\succ 0$, tilting $\mu_{\text{prod}}=N(m,s^2H^{-1})$ by $e^{-\beta a^{\top}x}$ gives $N(m-\beta s^2H^{-1}a,\ s^2H^{-1})$. If $H$ is singular, the tilted measure has infinite mass for every $a$, and its mass on growing boxes grows exponentially when $\beta a$ has a nonzero component in $\text{ker}\,H$.
:::

::: {custom-style="Statement Tag"}
Mathematics book Theorem 4.4 with $\Sigma=s^2H^{-1}$; the singular case is New in Part II.
:::

*Proof.* Complete the square [13, Theorem 4.4]. If $H$ is singular, write $x=x_r+x_k$ with $x_k\in\text{ker}\,H$. The tilted density factorises, and its factor on $\text{ker}\,H$ is $\exp(-\beta a_k^{\top}x_k)$, whose integral over $\text{ker}\,H$ is infinite whatever $a_k$ is. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{x.tilt_law.cases}} random two-dimensional stalks, the tilted mean computed by quadrature matched the formula to a relative {{x.tilt_law.mean_rel_err|e1}}. For $H=\text{diag}(1,0)$ and $\beta=1$, with slope $0.5$ along the unobserved axis, the mass on boxes of half-width 5, 10, 20 and 40 was {{d.tilt_slope.0|f1}}, {{d.tilt_slope.1|f0}}, {{d.tilt_slope.2|e2}} and {{d.tilt_slope.3|e2}}. With no slope there it was {{d.tilt_flat.0|f1}}, {{d.tilt_flat.1|f1}}, {{d.tilt_flat.2|f1}} and {{d.tilt_flat.3|f1}}.
:::

A linear objective therefore moves the local mean along $H^{-1}a$, farthest where coverage is thin. In an unobserved direction it pushes without limit, so a tilted local proposal needs coverage, a declared prior or a step bound in every direction in which the objective has slope.

::: {custom-style="Statement"}
**Proposition 4.6** (selection tilting collapses coverage). Let $w_i=w_i^0e^{-\beta J_i}$, where $J$ has a unique minimiser $\iota$, the elite record, and gap $\Delta=\text{min}_{i\ne\iota}(J_i-J_\iota)>0$, with fixed query, scale and observations and $\beta\ge0$. For coordinate masks and every coordinate $j\notin S_\iota$,
:::

::: {custom-style="Statement Equation"}
$\lambda_{\text{min}}(H)\le\kappa_j\le e^{-\beta\Delta}\sum_{i\ne\iota}\frac{w_i^0}{w_\iota^0}\exp\Big(\frac{e_\iota(z)-e_i(z)}{s^2}\Big)$ (4.3)
:::

::: {custom-style="Statement"}
So $\lambda_{\text{min}}(H)\to 0$ exponentially as $\beta\to\infty$. The normal matrix tends to the elite's projector. The retention read of this limiting matrix retains the token elsewhere; it need not equal the limit of the exact finite-$\beta$ reads. If the elite observes every coordinate, then $H\to I$.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* $\kappa_j\le\sum_{i\ne\iota}\alpha_i\le\sum_{i\ne\iota}\alpha_i/\alpha_\iota$, and $\alpha_i/\alpha_\iota=(w_i^0/w_\iota^0)\,e^{-\beta(J_i-J_\iota)}\,e^{(e_\iota-e_i)/s^2}$. As $\beta\to\infty$, $\alpha$ tends to the indicator of $\iota$ and $H$ to $Q_\iota^{\top}Q_\iota$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* For twelve masked records in $ℝ^4$ at $s=1.5$, with an elite observing two coordinates, $\lambda_{\text{min}}(H)$ was {{d.tilt_p.0|f3}}, {{d.tilt_p.1|f3}}, {{d.tilt_p.2|f4}}, {{d.tilt_p.3|e1}}, {{d.tilt_p.4|e1}} and {{d.tilt_p.5|e1}} at $\beta=0,1,3,10,30$ and $100$. With an elite observing all four coordinates it was {{d.tilt_f.0|f3}}, {{d.tilt_f.1|f3}}, {{d.tilt_f.2|f3}}, {{d.tilt_f.3|f7}}, {{d.tilt_f.4|f3}} and {{d.tilt_f.5|f3}} (Figure 3b).
:::

**Counterexample: solving and taking the limit do not commute.** Take two complementary one-coordinate masks in $\mathbb R^2$ with observations $1$ and $7$, and token $z=(0,-2)$. At this query choose fixed baseline weights so that the posterior weights are proportional to $(1,e^{-\beta})$. Then $H=\operatorname{diag}(\alpha_1,\alpha_2)$ and $b=(\alpha_1,7\alpha_2)$. For every finite $\beta$, the exact read is $(1,7)$. At the limiting weights $(1,0)$, the retention read is $(1,-2)$, a gap of {{r.selection_limit.gap|f0}} in the second coordinate. Vanishing coverage does not force the exact read to retain that coordinate.

*Engineering meaning.* Strong selection destroys conditioning. In a filtered implementation it can eventually suppress recombination by discarding small coverage eigenvalues; in exact arithmetic the conditional averages can survive. A fixed positive ridge prior also changes the limit, because it dominates vanishing coverage. Annealing $\beta$ or maintaining a coverage floor addresses conditioning, while the choice of cutoff or prior determines which information is actually retained.

## 4.4 Measurement

::: {custom-style="Statement"}
**Proposition 4.7** (Gaussian measurement noise). Let $\beta\ge0$. In (ii), use $k\ge2$ and the unbiased sample variance; in (iii), use an equicorrelated Gaussian model with fixed marginal variance and $0\le\rho\le1$. (i) If the loss of a design is measured as the mean $S_k$ of $k$ independent $N(J+b,\sigma^2)$ judgements, then $E\,e^{-\beta S_k}=\exp(-\beta(J+b)+\beta^2\sigma^2/2k)$, so heteroscedastic noise changes the expected weights. (ii) The plug-in correction $\exp(-\beta S_k-\beta^2V/2k)$, with $V$ the sample variance, is biased upward. (iii) A shared error with correlation $\rho$ survives repetition: the residual factor tends to $e^{\beta^2\sigma^2\rho/2}$ as $k\to\infty$.
:::

::: {custom-style="Statement Tag"}
Mathematics book Propositions 4.8, 4.9 and 4.10, retained in a specified local measure.
:::

For (ii), independence of the normal sample mean and sample variance gives an exact multiplicative factor $\exp(t)(1+2t/(k-1))^{-(k-1)/2}$ relative to $e^{-\beta(J+b)}$, where $t=\beta^2\sigma^2/(2k)$. This exceeds one when $t>0$ and equals one when $t=0$, since $\log(1+x)<x$ for $x>0$. For (iii), $\operatorname{Var}(S_k)=\sigma^2[\rho+(1-\rho)/k]$ yields the stated limit.

Proposition 4.7 concerns expected **unnormalised** weights under Gaussian noise. It does not identify the expectation of the normalised attention vector. An engineering critic, such as a surrogate model or a coarse analysis, is often known only to be within a tolerance. The next theorem covers that case.

::: {custom-style="Statement"}
**Theorem 4.8** (bounded measurement error). Let the losses be measured as $J_i+\delta_i$ with $|\delta_i|\le\varepsilon$, $\beta\ge0$ and $\varepsilon\ge0$, so that the weights become $\alpha'_i\propto\alpha_ie^{-\beta\delta_i}$.
:::

::: {custom-style="Statement"}
\(i) $\text{TV}(\alpha,\alpha')=\tfrac12\sum_i|\alpha'_i-\alpha_i|\le\tanh(\beta\varepsilon/2)$. Equality holds for two records with $\alpha=(p,1-p)$, $p=1/(1+e^{\beta\varepsilon})$ and $\delta=(-\varepsilon,\varepsilon)$.
:::

::: {custom-style="Statement"}
\(ii) For square orthogonal maps, $\|m'-m\|\le\tanh(\beta\varepsilon/2)\,\text{diam}\{v_i\}$.
:::

::: {custom-style="Statement"}
\(iii) For general maps with $H,H'\succ 0$, $\|m'-m\|\le\text{TV}(\alpha,\alpha')\,\text{diam}\{Q_i^{\top}r_i\}/\lambda_{\text{min}}(H')$, where $r_i=Q_im-o_i$.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* (i) $\text{TV}(\alpha,\alpha')=\text{max}_A(\alpha'(A)-\alpha(A))$ over sets of records. Fix $A$ with $\alpha(A)=p$. Then $\alpha'(A)=X/(X+Y)$ with $X=\sum_{i\in A}\alpha_ie^{-\beta\delta_i}\le pe^{\beta\varepsilon}$ and $Y=\sum_{i\notin A}\alpha_ie^{-\beta\delta_i}\ge(1-p)e^{-\beta\varepsilon}$. The ratio increases in $X$ and decreases in $Y$, so with $u=e^{2\beta\varepsilon}$ we get $\alpha'(A)-p\le\varphi(p)$, where $\varphi(p)=pu/(pu+1-p)-p$. Setting the derivative of $\varphi$ to zero gives $p=1/(\sqrt u+1)$. At that point $\varphi=(\sqrt u-1)/(\sqrt u+1)$, which equals $\tanh(\beta\varepsilon/2)$. The two-point example attains this value. (ii) $m'-m=\sum_i(\alpha'_i-\alpha_i)v_i$. The positive and negative parts of $\alpha'-\alpha$ each have mass $\text{TV}$, so this is $\text{TV}$ times the difference of two convex combinations of the $v_i$. (iii) $\sum_i\alpha_iQ_i^{\top}r_i=Hm-b=0$. Hence $H'(m'-m)=b'-H'm=-\sum_i\alpha'_iQ_i^{\top}r_i=-\sum_i(\alpha'_i-\alpha_i)Q_i^{\top}r_i$, and the argument of (ii) applies. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{c.measurement.trials}} random weight vectors, half of them with the extremal pattern $\delta_i=\pm\varepsilon$, (i) was never violated; the largest ratio to the bound was {{c.measurement.tv_worst_ratio|f7}}, and for (ii) it was {{c.measurement.read_worst_ratio|f3}}. In {{c.measurement.rect_trials}} general stars, (iii) was never violated, with largest ratio {{c.measurement.rect_worst_ratio|f3}}. The two-point example at $\beta=2$ and $\varepsilon=0.7$ gave $\text{TV}={{c.measurement.two_point_tv|f6}}=\tanh(0.7)$.
:::

*Engineering meaning.* Theorem 4.8 sets the selection strength against the critic's error. If losses are misstated by at most $\varepsilon$, the read of a transported archive moves by at most $\tanh(\beta\varepsilon/2)$ of its diameter, about 10% when $\beta\varepsilon=0.2$. Equivalently, a tolerance $\nu$ on the relative displacement holds whenever $\beta\le 2\,\text{artanh}(\nu)/\varepsilon$. Unlike Proposition 4.7, the bound is worst case and assumes no distribution.
