---
title: "The Horizontal Layer"
subtitle: "One layer of Autoregressive Sheaf Evolution. Part II: sheaf attention, Gaussian stalks, locality and the topology of design spaces"
author:
  - "Debi Prasad Ghosh"
  - "Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India"
date: "Defensible Intelligence series · Autoregressive Sheaf Evolution, Part II · 18 October 2026 · “Respect science. Import emotion.”"
abstract: |
  Part II of Autoregressive Sheaf Evolution develops the horizontal layer: a token reads mapped observations on a star, then moves towards their harmonic extension. The minimum-change read retains the token in unobserved directions. Positive operator weights explain how partial records recombine outside the archive hull, while coordinatewise bounds limit the gain. The principal theorem identifies the read as a majorise–minimise step for a soft discrepancy energy. Every relaxation between zero and two has an explicit decrease bound, and deterministic ADE is recovered at its own layer scale. The Gaussian analysis separates proper mixtures from proper products, imputation from harmonic extension, and loss of coverage from loss of exact recombination. In particular, taking a strong-selection limit and taking a pseudoinverse need not commute. Locality is quantified by computable truncation certificates; sensitivity by an exact Jacobian and covariance bound. Branches, angles, signs, modal subspaces and physical symmetries require distinct treatments. Numerical evidence comprises thirty-four supplied checks rerun in the current environment, eight focused review checks, and a fresh NumPy comparison with the twelve supplied C# output lines. The results establish one-layer guarantees rather than improved optimisation across a stack.

---

# 1 Introduction

Autoregressive Diffusion Evolution (ADE) reads an archive of evaluated designs through a Gaussian kernel at every layer of a denoising stack [12, 13]. Autoregressive Sheaf Evolution (ASE) replaces the single Euclidean retrieval geometry of ADE by local data spaces, compatibility maps and scale-dependent covers [14]. Part I made the organising principle precise: each layer is horizontally topological, and each token's journey through the layers is vertically algebraic [15]. It also separated four bases that are easily confused. One of them is the observation star, a token vertex joined to one leaf per retrieved record [15, Definition 2.4(d)]. This paper, Part II of the book, studies what happens on that star. It covers chapters 3 to 6 of the book plan: sheaf attention, Gaussian models in a stalk, scale locality and covers, and the topology of design spaces [14, Section 21].

A layer does one thing to a token. It reads records through maps and moves towards the read. With record observations $o_i=R_iy_i\text{,}$ token-side edge maps $Q_i\text{,}$ prior weights $w_i$ and scale $s\text{,}$ the read is

::: {custom-style="Equation"}
$e_i(z)=\tfrac12\|Q_iz-o_i\|^2,\qquad \alpha_i\propto w_i\,e^{-e_i(z)/s^2}$
:::

::: {custom-style="Equation"}
$H=\sum_i\alpha_iQ_i^{\top}Q_i,\qquad b=\sum_i\alpha_iQ_i^{\top}o_i,\qquad m=H^{-1}b$ (1.1)
:::

when $H$ is invertible. With identity maps, (1.1) is the ADE read and also biased softmax attention [13, Proposition 5.1; 24]. With general maps, it is the harmonic extension of the observations from the leaves of the star to the token [14, Proposition 5.1]. We call (1.1), with the retention rule of Definition 2.2 for singular $H\text{,}$ *sheaf attention*. Barbero and co-authors used the phrase earlier for a graph neural network layer that learns attention coefficients on a cellular sheaf [1, 4]. Ours is a different object: a read on an observation star, with fixed maps and weights computed from discrepancies.

![**Figure 1.** (a) The observation star of one token. Each edge carries an edge stalk $ℝ^{k_i}\text{,}$ reached from the token by $Q_i$ and from the record by $R_i\text{.}$ (b) Two records with complementary coordinate masks: the read takes $x_1$ from the first and $x_2$ from the second, and lands outside the archive hull. On the cost $-x_1-x_2$ both records score $-1.1$ and the read scores $-2.0$ (Proposition 3.5). (c) Two records whose observation spaces are lines at an angle $\theta\text{.}$ A unit move of one observation moves the read by exactly $1/\sin\theta\text{,}$ below the general bound of Proposition 3.7.](fig/star.png){width=100%}

## 1.1 Contributions

- **Sheaf attention as an operator (Section 3).** We give the Schur-complement form of the harmonic extension (Proposition 3.1) and the retention read for singular normal matrices (Proposition 3.2). Matrix weights are invariant under lifts and self-adjoint in the $H$-geometry (Proposition 3.3). We prove hulls, coordinate boxes, a crossover property and a coordinatewise ceiling (Corollary 3.4, Proposition 3.5), and the exact spectrum of two weighted projectors with two-sided conditioning bounds (Proposition 3.6). The central result is the majorise–minimise theorem (Theorem 3.10). It gives guaranteed descent for every relaxation $0\le\lambda\le 2\text{,}$ and every deterministic ADE layer descends at its own scale (Corollary 3.12).
- **Gaussian stalks (Section 4).** Tweedie's identity holds in preconditioned form (Proposition 4.1). The chart posterior of the mathematics book and sheaf attention differ exactly off the chart (Proposition 4.2). Mixtures of partial records are improper, while products of experts are proper exactly under coverage (Proposition 4.3). One imputation is a gradient step, and repeated imputation is Cimmino's method converging to the harmonic read (Proposition 4.4). Selection tilting collapses coverage (Proposition 4.6). Bounded measurement error has a sharp $\tanh$ bound (Theorem 4.8).
- **Locality (Section 5).** We give a posteriori truncation certificates for transported reads, with certified radii, and for rectangular reads (Proposition 5.1, Corollary 5.2, Theorem 5.3). The Jacobian of the read is exact and has a covariance bound (Proposition 5.4). Strict minima are locally attracting and negative-curvature stationary points are unstable (Corollary 5.5). Section 5.3 states the cost and index contracts that the certificates need.
- **Topology (Section 6).** Shared reads land in the gap between branches (Proposition 6.2). Local angle reads jump only at antipodes, with an exponential bound when another record is nearer (Proposition 6.5). Nearest-image reads approximate all-image reads for every finite orthogonal group (Theorem 6.6), and projector reads are stable under measurement error (Proposition 6.8). Orbit indexes are exact for reflection groups, and every continuous canonicalisation fails for involutions with two or more antisymmetric directions (Proposition 6.10).
- **Evidence.** There are 34 numerical checks (Table 6): 20 from a main script and 14 from a supplementary script. An immutable C# kernel agrees with an independent NumPy implementation on every output line (Appendix A).

## 1.2 Scope and status of statements

Part II concerns one layer at one query. It makes no claim about search performance, sampling validity or the feasibility of proposed designs. The hypotheses C1 to C5 of V2 remain open, and nothing here tests them [14, Sections 17–18]. Each numbered mathematical statement carries a provenance tag. *Classical* marks a known result restated in ASE notation. *V2* marks a statement of the conversion proposal [14], sometimes with a new proof. *Mathematics book* marks a result retained from [13], with its number there. *New in Part II* marks a statement proved here for the first time in this programme; each comes with a proof and a numerical check. All spaces are finite-dimensional and real. The observation maps, baseline weights, archive and scale are fixed throughout each derivative and descent argument; attention weights depend on the query and are frozen only when forming the quadratic surrogate. A query-dependent star, learned map or prior adds terms or changes the energy and requires a separate argument. The word “new” is relative to this ASE programme, not a claim of priority over the literature.

## 1.3 Conventions and notation

Table: **Table 1.** Notation used throughout Part II.

| Symbol | Meaning |
|:--------------|:--------------------------------------------------------------|
| $z\in ℝ^D$ | token state in the token frame |
| $y_i,\ R_i,\ o_i=R_iy_i$ | record value, record-side map and observation |
| $Q_i:ℝ^D\to ℝ^{k_i}$ | token-side edge map of record $i$ |
| $w_i,\ s$ | prior weight of record $i$ and the scale of the layer |
| $e_i,\ \alpha_i$ | discrepancy and attention weight (2.1) |
| $H,\ b,\ m$ | normal matrix, right side and read (2.2), (2.3) |
| $E_s$ | soft discrepancy energy (3.6) |
| $\kappa_j$ | coverage of coordinate $j$ under masks |
| $c_A$ | the largest $\lambda_{\text{max}}(Q_i^{\top}Q_i)$ over the records |
| $S,\ W,\ W_S,\ D_S$ | star, total archive weight, star weight and star kernel mass |
| $G,\ d_G$ | finite group of orthogonal symmetries and its orbit distance |
| $\langle g\rangle$ | the $\alpha$-weighted mean $\sum_i\alpha_ig_i$ |

# 2 The observation star and the layer contract

An ASE layer consumes a token, a versioned archive, declared edge maps and schedule coefficients. It produces a proposal together with its read, its star and numerical diagnostics [14, Section 4]. The read is computed on an auxiliary graph, the observation star. The cover nerve describes the base geometry, while the star describes the observations attached to it. ADE has a one-vertex nerve and a star with one leaf per record [15, Proposition 5.9].

::: {custom-style="Statement"}
**Definition 2.1** (observation star). At one layer, fix a token frame $ℝ^D$ and retrieved records $i=1,\ldots,n$ with values $y_i\in ℝ^{d_i}\text{,}$ edge maps $Q_i:ℝ^D\to ℝ^{k_i}$ and $R_i:ℝ^{d_i}\to ℝ^{k_i}\text{,}$ observations $o_i=R_iy_i\text{,}$ prior weights $w_i>0$ and a scale $s>0\text{.}$ The discrepancy and attention weight of record $i$ at the token $z$ are
:::

::: {custom-style="Statement Equation"}
$e_i(z)=\tfrac12\|Q_iz-o_i\|^2,\qquad \alpha_i(z)=\frac{w_i\exp(-e_i(z)/s^2)}{\sum_jw_j\exp(-e_j(z)/s^2)}$ (2.1)
:::

::: {custom-style="Statement"}
and the normal matrix and right side are
:::

::: {custom-style="Statement Equation"}
$H(z)=\sum_i\alpha_i(z)\,Q_i^{\top}Q_i,\qquad b(z)=\sum_i\alpha_i(z)\,Q_i^{\top}o_i$ (2.2)
:::

::: {custom-style="Statement Tag"}
V2 Section 4, made a definition.
:::

::: {custom-style="Statement"}
**Definition 2.2** (sheaf attention). The read at $z$ is
:::

::: {custom-style="Statement Equation"}
$m(z)=z+H^{\dagger}(b-Hz)$ (2.3)
:::

::: {custom-style="Statement"}
where $H^{\dagger}$ is the Moore–Penrose pseudo-inverse. If $H\succ 0\text{,}$ then $m=H^{-1}b\text{.}$ The eigenvectors of $H$ with eigenvalue zero span the unresolved directions, in which the read keeps the token's own value. Equation (2.3) is the exact operator. Its floating-point approximation is a separate, spectrally filtered operator $m_\epsilon\text{:}$ in floating point, eigenvalues at most $\epsilon\,\text{max}(1,\lambda_{\text{max}}(H))$ are treated as zero, and the layer raises an unresolved flag. The kernel of Appendix A uses $\epsilon=10^{-10}\text{.}$
:::

::: {custom-style="Statement Tag"}
V2 Definition 4.1, with the retention rule of V2 Section 4 made explicit.
:::

The kernel computes $m_\epsilon=z+H_\epsilon^\dagger(b-Hz)\text{,}$ where $H_\epsilon^\dagger$ inverts only eigenvalues above the declared cutoff. A discarded positive eigenvalue is numerically unresolved, rather than algebraically absent. Underflow can also replace a mathematically positive attention weight by zero. All claims involving exact stationarity, observability or limits below concern $m$ unless explicitly stated otherwise.

## 2.1 Units before residuals

The edge norm is part of the model. Convert physical quantities to common dimensionless units, or whiten them by a declared positive-definite error covariance, before forming (2.1). For raw maps $\bar Q_i,\bar R_i$ and a whitening map $W_i\text{,}$ use $Q_i=W_i\bar Q_i$ and $R_i=W_i\bar R_i\text{.}$ A change of units must be cancelled by the corresponding change of $W_i\text{;}$ otherwise it changes attention and the resulting optimisation problem. Different edge dimensions or noise conventions require explicit calibration of prior weights, including normalising constants if a probabilistic interpretation is intended. An edge map is not evidence that incompatible physical quantities may be subtracted.

## 2.2 The four bases and the vertical interface

Keep the latent base $X_t\text{,}$ the layer order $T\text{,}$ the cover nerve $N(\mathcal U_t)$ and the observation star distinct. The nerve encodes overlaps of regions; the star attaches observations to one query. A stalk is a data space. A token carries values and a vertical fibre diagram, rather than being a stalk itself. With a continuous comparison $\Phi_t:X_t\to X_{t-1}\text{,}$ a layer morphism has target $\Phi_t^{-1}\mathcal F_{t-1}\text{;}$ the comparison squares with horizontal restriction maps must commute. A state-dependent numerical read is not automatically a linear sheaf morphism. This paper supplies that read; Part III must specify how it enters the stack.

Each record contributes through its own observation space, so a record can contribute a strong subassembly without contributing anything else. A coordinate mask records what a record actually observed; an unobserved coordinate receives no invented value [14, Section 4]. Table 2 lists the map classes that recur below.

Table: **Table 2.** Classes of edge maps. Here $n$ is the number of records in the star; costs count arithmetic operations per read, with transports $Q_i^{\top}o_i$ and normal blocks $Q_i^{\top}Q_i$ stored with the records.

| Edge maps | Normal matrix | Read | Where the read lies | Cost per read |
|:----------------|:--------------|:----------------|:----------------|:----------------|
| identity | $H=I$ | $\sum_i\alpha_iy_i\text{,}$ the ADE read | archive hull | $O(nD)$ |
| orthogonal transport | $H=I$ | $\sum_i\alpha_iQ_i^{\top}o_i$ | transported hull | $O(nD)$ |
| coordinate mask | diagonal coverage | observed means; retain other coordinates | observed box if fully covered | $O(\sum_ik_i+D)$ |
| partial isometry | $0\preceq H\preceq I$ | limit of repeated imputation | no hull in general | $O(nD^2+D^3)$ |
| general rectangular | $H\succeq 0$ | $z+H^{\dagger}(b-Hz)$ | no hull in general | $O(nD^2+D^3)$ |


# 3 Sheaf attention

## 3.1 The read is a harmonic extension

On the star, give the token vertex the stalk $ℝ^D\text{,}$ the leaf of record $i$ the stalk $ℝ^{d_i}$ and the edge joining them the stalk $ℝ^{k_i}\text{.}$ The coboundary of an assignment $(x_0,x_1,\ldots,x_n)$ is $(\delta x)_i=R_ix_i-Q_ix_0\text{,}$ and fixed coefficients $c_i>0$ define the weighted sheaf Laplacian $L=\delta^{\top}C\delta$ [17]. Partition $L$ into the token block $t$ and the leaf block $\ell\text{.}$

::: {custom-style="Statement"}
**Proposition 3.1** (harmonic extension and its Schur complement). Suppose $G=\sum_ic_iQ_i^{\top}Q_i\succ 0$ and fix the leaves at $y=(y_1,\ldots,y_n)\text{.}$
:::

::: {custom-style="Statement"}
\(i) The unique minimiser of $\sum_ic_i\|Q_ix_0-R_iy_i\|^2$ over the token value is $x_0=G^{-1}\sum_ic_iQ_i^{\top}R_iy_i=-L_{tt}^{-1}L_{t\ell}\,y\text{.}$ It is the harmonic extension of $y\text{:}$ the token component of $L(x_0,y)$ vanishes.
:::

::: {custom-style="Statement"}
\(ii) The minimum value is the Schur-complement form
:::

::: {custom-style="Statement Equation"}
$\text{min}_{x_0}\sum_ic_i\|Q_ix_0-R_iy_i\|^2=y^{\top}(L_{\ell\ell}-L_{\ell t}L_{tt}^{-1}L_{t\ell})\,y$ (3.1)
:::

::: {custom-style="Statement Tag"}
\(i) V2 Proposition 5.1; (ii) Classical [17, 19].
:::

*Proof.* The energy is $(x_0,y)^{\top}L(x_0,y)$ with $L_{tt}=\sum_ic_iQ_i^{\top}Q_i=G$ and $L_{t\ell}\,y=-\sum_ic_iQ_i^{\top}R_iy_i\text{.}$ It is a strictly convex quadratic in $x_0\text{,}$ minimised where $L_{tt}x_0+L_{t\ell}y=0\text{,}$ which is the harmonic condition at the token vertex. Substituting the minimiser gives the Schur complement. ∎

::: {custom-style="Check"}
*Numerical check.* In 300 random stars with general rectangular maps, the normal-equation read and $-L_{tt}^{-1}L_{t\ell}y$ agreed to 2.6 × 10⁻¹³. Among 15,000 random perturbations of size $10^{-3}\text{,}$ 0 lowered the energy. In 300 further stars, the minimum value matched (3.1) to a relative 2.4 × 10⁻¹⁴.
:::

The retention rule of Definition 2.2 is needed whenever the retrieved records do not jointly observe every direction of the token frame. The next proposition says what it computes.

::: {custom-style="Statement"}
**Proposition 3.2** (the retention read). Freeze the weights at $z$ and let $M(x)=\sum_i\alpha_ie_i(x)$ be the frozen star energy. Then:
:::

::: {custom-style="Statement"}
\(i) $b\in\text{range}\,H\text{,}$ so the minimisers of $M$ form the affine set $m+\text{ker}\,H\text{;}$
:::

::: {custom-style="Statement"}
\(ii) the read (2.3) is the minimiser of $M$ nearest to $z\text{;}$
:::

::: {custom-style="Statement"}
\(iii) for $\tau>0\text{,}$ the token-anchored ridge read $m_\tau=(H+\tau I)^{-1}(b+\tau z)$ satisfies
:::

::: {custom-style="Statement Equation"}
$\|m_\tau-m\|\le\frac{\tau}{\lambda_r+\tau}\,\|m-z\|$ (3.2)
:::

::: {custom-style="Statement"}
where $\lambda_r$ is the smallest positive eigenvalue when $H\ne0\text{,}$ so $m_\tau\to m$ as $\tau\to0\text{.}$ If $H=0\text{,}$ then $b=0$ and $m_\tau=m=z\text{;}$
:::

::: {custom-style="Statement"}
\(iv) if $H\succ 0\text{,}$ then $m=H^{-1}b\text{.}$
:::

::: {custom-style="Statement Tag"}
New in Part II. V2 Section 4 states the rule.
:::

*Proof.* (i) Every $\alpha_i$ is positive, so $\text{range}\,H=\sum_i\text{range}\,Q_i^{\top}\text{,}$ which contains $b\text{.}$ Since $M(x)=\tfrac12x^{\top}Hx-b^{\top}x+\text{const}\text{,}$ its minimisers are the solutions of $Hx=b\text{.}$ (ii) Because $b-Hz\in\text{range}\,H\text{,}$ $Hm=Hz+HH^{\dagger}(b-Hz)=b\text{,}$ so $m$ is a minimiser. Moreover $m-z=H^{\dagger}(b-Hz)\in\text{range}\,H=(\text{ker}\,H)^{\perp}\text{,}$ which characterises the orthogonal projection of $z$ onto $m+\text{ker}\,H\text{.}$ (iii) $m_\tau-z=(H+\tau I)^{-1}(b-Hz)$ and $m-z=H^{\dagger}(b-Hz)\text{.}$ In an eigenbasis of $H\text{,}$ the component along an eigenvalue $\lambda>0$ changes by the factor $\lambda/(\lambda+\tau)\text{,}$ that is, by $\tau/(\lambda+\tau)\le\tau/(\lambda_r+\tau)$ of itself. The components along $\text{ker}\,H$ vanish in both. (iv) Here $H^{\dagger}=H^{-1}\text{.}$ ∎

::: {custom-style="Check"}
*Numerical check.* In 300 stars whose maps observe a random proper subspace, the read agreed with an independently computed nearest minimiser, obtained from a least-squares solution projected along $\text{ker}\,H\text{,}$ to a relative 5.1 × 10⁻⁹. The normal residual on resolved directions was 3.0 × 10⁻¹⁴. At $\tau/\lambda_r=10^{-2}\text{,}$ $10^{-4}$ and $10^{-6}\text{,}$ the largest values of $\|m_\tau-m\|/\|m-z\|$ were 0.009901, 9.999 × 10⁻⁵ and 1.003 × 10⁻⁶, the largest excess over the theoretical bounds was 2.8 × 10⁻⁹, consistent with the numerical error of these ill-conditioned solves. The exact bound is established by the proof.
:::

*Engineering meaning.* The retention read never invents a value in a direction that no retrieved record observes; that direction keeps the token's own value. A ridge prior is the alternative V2 allows. Proposition 3.2 shows that the retention read is the vanishing-ridge limit, and that any positive $\tau$ is a declared prior that changes the read.

## 3.2 Matrix weights

::: {custom-style="Statement"}
**Proposition 3.3** (matrix weights). Let $G=\sum_ic_iQ_i^{\top}Q_i\succ 0$ and $A_i=G^{-1}c_iQ_i^{\top}Q_i\text{.}$
:::

::: {custom-style="Statement"}
\(i) $\sum_iA_i=I\text{.}$
:::

::: {custom-style="Statement"}
\(ii) Let $v_i$ be any lift of record $i\text{,}$ that is, any vector with $Q_iv_i=Q_iQ_i^{\dagger}o_i\text{,}$ the projection of $o_i$ onto $\text{range}\,Q_i\text{.}$ Then
:::

::: {custom-style="Statement Equation"}
$m=\sum_iA_iv_i$ (3.3)
:::

::: {custom-style="Statement"}
and the read does not depend on the choice of lifts.
:::

::: {custom-style="Statement"}
\(iii) Each $A_i$ is self-adjoint in the inner product $\langle x,y\rangle_G=x^{\top}Gy$ and satisfies $0\preceq A_i\preceq I$ there. Equivalently, $A_i$ is similar to the positive semidefinite matrix $G^{-1/2}c_iQ_i^{\top}Q_iG^{-1/2}\text{,}$ and its eigenvalues lie in $[0,1]\text{.}$
:::

::: {custom-style="Statement Tag"}
\(i) V2 check 5; (ii) and (iii) New in Part II.
:::

*Proof.* (i) Sum the definition. (ii) $Q_iQ_i^{\dagger}$ is the orthogonal projector onto $\text{range}\,Q_i\text{,}$ and $Q_i^{\top}$ vanishes on the orthogonal complement of that range. Hence $Q_i^{\top}o_i=Q_i^{\top}Q_iQ_i^{\dagger}o_i=Q_i^{\top}Q_iv_i\text{,}$ and $m=G^{-1}\sum_ic_iQ_i^{\top}Q_iv_i=\sum_iA_iv_i\text{.}$ Adding a vector of $\text{ker}\,Q_i$ to $v_i$ does not change $Q_i^{\top}Q_iv_i\text{.}$ (iii) $GA_i=c_iQ_i^{\top}Q_i$ is symmetric, which is $G$-self-adjointness. The matrices $B_i=G^{1/2}A_iG^{-1/2}=G^{-1/2}c_iQ_i^{\top}Q_iG^{-1/2}$ are positive semidefinite and sum to $I\text{,}$ so $0\preceq B_i\preceq I\text{.}$ ∎

With identity maps, $A_i=\alpha_iI$ and (3.3) is the convex read of ADE. In general, the $A_i$ form a positive operator partition of the identity in the $G$ inner product. This is not an ordinary convex combination. Changing an inner product does not change an affine convex hull; no choice of metric restores the scalar convex-hull conclusion for general operator weights.

::: {custom-style="Check"}
*Numerical check.* In 300 random stars, $\sum_iA_i=I$ held to 7.8 × 10⁻¹⁴ and (3.3) to 6.4 × 10⁻¹⁴. Adding random kernel components to every lift changed the read by at most 7.1 × 10⁻¹⁴. The smallest eigenvalue of any $B_i$ was −2.3 × 10⁻¹³, which is zero to rounding.
:::

## 3.3 Hulls, boxes and recombination

::: {custom-style="Statement"}
**Corollary 3.4** (transported hull and ceiling). If every $Q_i$ is square orthogonal, then $H=I$ and $m=\sum_i\alpha_iv_i$ with $v_i=Q_i^{\top}o_i\text{.}$ The read lies in the convex hull of the transported records, and for every linear cost $c\text{,}$ $c(m)\ge\text{min}_i\,c(v_i)\text{.}$
:::

::: {custom-style="Statement Tag"}
V2 Corollary 5.2; Mathematics book Corollary 6.1.
:::

::: {custom-style="Check"}
*Numerical check.* In 200 random orthogonal stars, $m-\sum_i\alpha_iv_i$ was at most 1.3 × 10⁻¹⁵.
:::

::: {custom-style="Statement"}
**Proposition 3.5** (recombination and the coordinatewise ceiling). Let $Q_i=R_i$ select the coordinates $S_i$ of a full design, and let every coordinate have positive coverage $\kappa_j=\sum_{i:\,j\in S_i}\alpha_i\text{.}$
:::

::: {custom-style="Statement"}
\(i) $m_j=\kappa_j^{-1}\sum_{i:\,j\in S_i}\alpha_iy_{ij}\text{.}$ Hence the read lies in the coordinate box spanned by the observed values, but not necessarily in the convex hull of the archived designs.
:::

::: {custom-style="Statement"}
\(ii) For two records with complementary masks $S$ and $S^c\text{,}$ the read lies outside the segment joining $y_1$ and $y_2$ unless the two records agree on $S$ or on $S^c\text{.}$
:::

::: {custom-style="Statement"}
\(iii) For a linear cost $c(x)=\sum_ja_jx_j\text{,}$ $c(m)\ge\sum_j\text{min}_{i:\,j\in S_i}a_jy_{ij}\text{.}$ The read can beat the best archived design, but never the best coordinatewise combination of observed values.
:::

::: {custom-style="Statement Tag"}
\(i) V2 Proposition 5.3; (ii) and (iii) New in Part II.
:::

*Proof.* (i) $H$ is diagonal with entries $\kappa_j\text{,}$ and the normal equations decouple coordinate by coordinate. (ii) A point of the segment is $(1-t)y_1+ty_2\text{.}$ It agrees with the read on $S$ only if $t\,(y_2-y_1)_S=0\text{,}$ and on $S^c$ only if $(1-t)(y_1-y_2)_{S^c}=0\text{.}$ If both differences are nonzero, these force $t=0$ and $t=1\text{.}$ (iii) By (i), each term $a_jm_j$ is a convex combination of the values $a_jy_{ij}$ with $j\in S_i\text{.}$ ∎

::: {custom-style="Check"}
*Numerical check.* In 396 random masked stars in $ℝ^4$ (4 further stars had a coverage below $10^{-8}$ and were skipped), no read left its coordinate box, and 345 left the archive hull according to a linear-programming test. All 300 of 300 complementary pairs read outside their segment. In 400 masked stars with random linear costs, the floor of (iii) was never violated, and the read beat the best archived design in 15 of them (3.8%).
:::

*Engineering meaning.* Coordinate recombination breaks the ceiling of Corollary 3.4: a record contributes its strong subassembly without its weak ones (Figure 1b). This is the mechanism behind hypothesis C2 of V2. It creates candidates, not feasible designs: coupled loads, interfaces and global stability must be re-evaluated [14, Section 5]. Part (iii) bounds the gain, since recombination cannot extrapolate beyond the observed values of each coordinate.

## 3.4 Conditioning

Conditioning depends on coverage, the relative weights and the angles of complementary observation directions. Coincident fully observed spaces are harmless, whereas nearly parallel lines that must jointly span a plane are ill conditioned. Principal angles quantify the two-space case [3].

::: {custom-style="Statement"}
**Proposition 3.6** (two weighted subspaces). Let $P_1,P_2$ be orthogonal projectors onto subspaces $S_1,S_2\subseteq ℝ^D$ of dimensions $k_1\le k_2\text{,}$ let $c_1,c_2>0\text{,}$ and let $\theta_1,\ldots,\theta_{k_1}$ be the principal angles between $S_1$ and $S_2\text{.}$
:::

::: {custom-style="Statement"}
\(i) The spectrum of $c_1P_1+c_2P_2$ consists of $c_1+c_2$ once for each zero angle; $c_1$ once for each right angle; $c_2$ with multiplicity $k_2-n_0-n_m\text{,}$ where $n_0$ counts the zero angles and $n_m$ the angles strictly between $0$ and $\pi/2\text{;}$ for each $\theta_j\in(0,\pi/2)$ the pair
:::

::: {custom-style="Statement Equation"}
$\tfrac12\Big[(c_1+c_2)\pm\sqrt{(c_1+c_2)^2-4c_1c_2\sin^2\theta_j}\,\Big]$ (3.4)
:::

::: {custom-style="Statement"}
and $0$ for the remaining dimensions.
:::

::: {custom-style="Statement"}
\(ii) Suppose $S_1+S_2=ℝ^D\text{.}$ Let $\theta_F$ be the smallest nonzero principal angle, or $\pi/2$ if every principal angle is zero, and let $h=2c_1c_2/(c_1+c_2)\text{.}$ Then
:::

::: {custom-style="Statement Equation"}
$\tfrac12h\sin^2\theta_F\le\lambda_{\text{min}}(c_1P_1+c_2P_2)\le h\sin^2\theta_F$ (3.5)
:::

::: {custom-style="Statement"}
where the upper bound requires $\theta_F<\pi/2\text{.}$ The constant $\tfrac12$ is sharp as $\theta_F\to 0\text{.}$
:::

::: {custom-style="Statement Tag"}
\(i) Classical: the two-subspace decomposition [16] made explicit; (ii) New in Part II.
:::

*Proof.* (i) By Halmos's theorem, $ℝ^D$ splits orthogonally into $S_1\cap S_2\text{,}$ $S_1\cap S_2^{\perp}\text{,}$ $S_1^{\perp}\cap S_2\text{,}$ $S_1^{\perp}\cap S_2^{\perp}$ and a sum of two-dimensional subspaces invariant under both projectors. There is one such subspace for each principal angle in $(0,\pi/2)\text{,}$ and on it $P_1$ and $P_2$ project onto two lines at that angle [16]. The first four summands contribute $c_1+c_2\text{,}$ $c_1\text{,}$ $c_2$ and $0\text{,}$ with the stated multiplicities: zero angles count $S_1\cap S_2\text{,}$ right angles count $S_1\cap S_2^{\perp}$ because $k_1\le k_2\text{,}$ and the rest of $S_2$ lies in $S_1^{\perp}\cap S_2\text{.}$ On each two-dimensional block the trace is $c_1+c_2$ and the determinant is $c_1c_2\sin^2\theta_j\text{,}$ which gives (3.4). (ii) The smaller root of (3.4) equals $2c_1c_2\sin^2\theta/[(c_1+c_2)+\sqrt{(c_1+c_2)^2-4c_1c_2\sin^2\theta}\,]\text{.}$ The denominator lies between $c_1+c_2$ and $2(c_1+c_2)\text{,}$ so the root lies between $\tfrac12h\sin^2\theta$ and $h\sin^2\theta\text{,}$ and it increases with $\theta\text{.}$ Spanning excludes the eigenvalue $0\text{.}$ The eigenvalues $c_1\text{,}$ $c_2$ and $c_1+c_2$ are at least $\text{min}(c_1,c_2)\ge\tfrac12h\text{.}$ Hence the lower bound holds, and the upper bound holds whenever a block exists. As $\theta\to 0\text{,}$ the denominator tends to $2(c_1+c_2)\text{.}$ ∎

::: {custom-style="Check"}
*Numerical check.* In 460 random spanning pairs, 190 of them with an interior angle, bound (3.5) was never violated. The ratio $\lambda_{\text{min}}/(h\sin^2\theta_F)$ ranged from 0.5000004 to 0.811. In 500 further pairs with 263 interior angles, the spectrum (i) matched the computed eigenvalues to 9.8 × 10⁻¹⁵.
:::

::: {custom-style="Statement"}
**Proposition 3.7** (amplification and coverage). Let $G=\sum_ic_iQ_i^{\top}Q_i\succ 0$ with fixed coefficients $c_i>0\text{,}$ and let $m=G^{-1}\sum_ic_iQ_i^{\top}o_i\text{.}$
:::

::: {custom-style="Statement"}
\(i) The read moves with record $i$'s observation through $\partial m/\partial o_i=G^{-1}c_iQ_i^{\top}\text{,}$ and $\|G^{-1}c_iQ_i^{\top}\|\le(c_i/\lambda_{\text{min}}(G))^{1/2}\text{.}$
:::

::: {custom-style="Statement"}
\(ii) For coordinate masks with $c_i=\alpha_i\text{,}$ $\lambda_{\text{min}}(H)=\text{min}_j\,\kappa_j\text{.}$
:::

::: {custom-style="Statement"}
\(iii) For two lines in the plane with unit normals at an angle $0<\theta\le\pi/2$ and $c_1=c_2=1\text{,}$ a unit move of $o_1$ moves the read by exactly $1/\sin\theta\text{.}$
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* (i) Write $X=G^{-1}c_iQ_i^{\top}\text{.}$ Then $XX^{\top}=c_i\,G^{-1}(c_iQ_i^{\top}Q_i)G^{-1}\preceq c_i\,G^{-1}GG^{-1}=c_iG^{-1}\text{,}$ because $c_iQ_i^{\top}Q_i\preceq G$ and congruence preserves order. Hence $\|X\|^2\le c_i/\lambda_{\text{min}}(G)\text{.}$ (ii) $H$ is diagonal with entries $\kappa_j\text{.}$ (iii) Take $n_1=e_1$ and $n_2=(\cos\theta,\sin\theta)\text{.}$ Then $G^{-1}n_1=(1,-\cot\theta)\text{,}$ whose norm is $1/\sin\theta\text{.}$ ∎

::: {custom-style="Check"}
*Numerical check.* In 400 random stars, (i) held for every record, with largest ratio 0.9991. In 300 masked stars, $\lambda_{\text{min}}(H)$ equalled the smallest coverage to 0. For two lines at $\theta=\pi/2,\pi/4,\pi/8,\pi/16$ and $\pi/32\text{,}$ the displacement was 1.000, 1.414, 2.613, 5.126 and 10.202, against the bound (i) of 1.000, 1.848, 3.625, 7.214 and 14.411 (Figure 1c).
:::

*Engineering meaning.* Nearly parallel observation spaces make the read hypersensitive. Two gauges that measure almost the same combination of member forces locate the design poorly in the orthogonal direction. Coverage is the masked form of the same effect. A layer therefore reports $\lambda_{\text{min}}(H)\text{,}$ or the smallest coverage, with every read, and a small value triggers the conditioning control of V2: enlarge the star, add a declared prior, or retain the token's value.

## 3.5 Residual and soft energy

::: {custom-style="Statement"}
**Proposition 3.8** (residual at the read). If $H\succ 0\text{,}$ then $\sum_i\alpha_i\|Q_im-o_i\|^2=\sum_i\alpha_i\|o_i\|^2-b^{\top}H^{-1}b\text{.}$ For square orthogonal maps, this equals $\text{tr}\,C$ with $C=\sum_i\alpha_i(v_i-m)(v_i-m)^{\top}\text{,}$ the weighted spread of the transported records.
:::

::: {custom-style="Statement Tag"}
Classical least squares; the trace form is its orthogonal case.
:::

::: {custom-style="Check"}
*Numerical check.* In 300 random orthogonal stars, the residual and $\text{tr}\,C$ agreed to 3.6 × 10⁻¹⁵.
:::

The read is also a step on an energy. With query-independent weights $w_i$ on a region where the star and maps are fixed, V2 defines the soft discrepancy energy

::: {custom-style="Equation"}
$E_s(z)=-s^2\log\sum_iw_i\exp(-e_i(z)/s^2)$ (3.6)
:::

::: {custom-style="Statement"}
**Proposition 3.9** (gradient and Hessian of the soft energy). Let $g_i=Q_i^{\top}(Q_iz-o_i)\text{,}$ the gradient of $e_i\text{,}$ and let $c_A=\text{max}_i\,\lambda_{\text{max}}(Q_i^{\top}Q_i)\text{.}$ Then
:::

::: {custom-style="Statement Equation"}
$\nabla E_s(z)=H\,(z-m),\qquad \nabla^2E_s(z)=H-s^{-2}\,\text{Cov}_\alpha(g)\preceq H\preceq c_AI$ (3.7)
:::

::: {custom-style="Statement"}
where $\text{Cov}_\alpha(g)=\sum_i\alpha_i(g_i-\langle g\rangle)(g_i-\langle g\rangle)^{\top}\text{.}$ The gradient identity holds with the retention read when $H$ is singular.
:::

::: {custom-style="Statement Tag"}
Gradient: V2 Proposition 6.1; Hessian: New in Part II.
:::

*Proof.* $\nabla E_s=\sum_i\alpha_ig_i=Hz-b\text{,}$ and $b=Hm$ by Proposition 3.2. Differentiating again, $\nabla g_i=Q_i^{\top}Q_i$ and $\nabla\alpha_i=-s^{-2}\alpha_i(g_i-\langle g\rangle)\text{,}$ so $\nabla^2E_s=H-s^{-2}\sum_i\alpha_i(g_i-\langle g\rangle)g_i^{\top}\text{,}$ which is the stated covariance form. ∎

::: {custom-style="Check"}
*Numerical check.* In 300 random stars, central differences matched the gradient to a relative 1.8 × 10⁻⁹. In 300 stars, finite differences of the gradient matched the Hessian to a relative 6.2 × 10⁻¹⁰.
:::

## 3.6 Sheaf mean shift

::: {custom-style="Statement"}
**Theorem 3.10** (sheaf attention is a majorise–minimise step). Use the exact read (2.3), a fixed nonempty archive, fixed maps and positive baseline weights, and fixed $s>0\text{.}$ These data remain fixed over each update segment and throughout the iteration in (iii). Fix $z\text{,}$ and compute $\alpha\text{,}$ $H\text{,}$ $b$ and the read $m$ at $z\text{.}$
:::

::: {custom-style="Statement"}
\(i) For every $\lambda\in[0,2]\text{,}$
:::

::: {custom-style="Statement Equation"}
$E_s(z+\lambda(m-z))\le E_s(z)-\tfrac12\lambda(2-\lambda)\,\|z-m\|_H^2$ (3.8)
:::

::: {custom-style="Statement"}
with $\|x\|_H^2=x^{\top}Hx\text{,}$ and with equality for every $\lambda$ when the star has a single record.
:::

::: {custom-style="Statement"}
\(ii) $m=z$ if and only if $\nabla E_s(z)=0\text{,}$ also when $H$ is singular.
:::

::: {custom-style="Statement"}
\(iii) Let $z_{t+1}=z_t+\lambda_t(m(z_t)-z_t)$ with $\epsilon\le\lambda_t\le 2-\epsilon$ for some $\epsilon>0\text{.}$ Then $E_s(z_t)$ is non-increasing, $\sum_t\|z_t-m(z_t)\|_{H(z_t)}^2<\infty\text{,}$ and $\nabla E_s(z_t)\to 0\text{.}$
:::

::: {custom-style="Statement Tag"}
New in Part II; an instance of the majorise–minimise principle [21]. For identity maps and $\lambda=1$ it is the bound-optimisation and EM view of Gaussian mean shift [5, 6, 8, 11] and the concave–convex view of modern Hopfield retrieval [23, 26].
:::

*Proof.* (i) The function $F(e)=-s^2\log\sum_iw_ie^{-e_i/s^2}$ is concave on $ℝ^n\text{,}$ being $-s^2$ times a log-sum-exp of affine functions of $e\text{,}$ and $\partial F/\partial e_i=\alpha_i\text{.}$ The tangent inequality at $e(z)$ gives $F(e')\le F(e(z))+\sum_i\alpha_i(e'_i-e_i(z))\text{.}$ Putting $e'=e(x)$ yields $E_s(x)\le E_s(z)+M(x)-M(z)$ with the frozen quadratic $M$ of Proposition 3.2. Since $m$ minimises $M\text{,}$ $M(x)-M(m)=\tfrac12\|x-m\|_H^2$ for every $x\text{.}$ For $x=z+\lambda(m-z)$ we have $x-m=(1-\lambda)(z-m)\text{,}$ so $M(x)-M(z)=-\tfrac12\lambda(2-\lambda)\|z-m\|_H^2\text{.}$ With one record, $F$ is affine and the tangent inequality is an equality. (ii) $\nabla E_s(z)=Hz-b\text{.}$ If $m=z\text{,}$ then $Hz=Hm=b\text{.}$ Conversely, if $Hz=b\text{,}$ then $m=z+H^{\dagger}\cdot 0=z\text{.}$ (iii) Each $e_i\ge 0\text{,}$ so $E_s\ge -s^2\log\sum_iw_i$ is bounded below. Summing (3.8), and using $\tfrac12\lambda_t(2-\lambda_t)\ge\tfrac12\epsilon(2-\epsilon)\text{,}$ gives the finite sum. Finally, $\|\nabla E_s(z_t)\|^2=\|H_t(z_t-m_t)\|^2\le\|H_t\|\,\|z_t-m_t\|_{H_t}^2\le c_A\|z_t-m_t\|_{H_t}^2\to 0\text{.}$ ∎

The theorem guarantees descent, not convergence of the iterates. Convergence of Gaussian mean-shift iterates needs further conditions even for identity maps [5]. The interval $[0,2]$ cannot be enlarged in general: for a single record (3.8) is an equality, and the energy rises for every $\lambda>2\text{.}$ Over-relaxed steps with $1<\lambda<2$ remain guaranteed descent steps.

::: {custom-style="Check"}
*Numerical check.* In 3,000 random stars drawn equally from the four map classes, with random $\lambda\in(0,2)\text{,}$ inequality (3.8) was never violated. The smallest ratio of actual to guaranteed decrease was 1.000000000000, so the bound is attained to rounding. For $\lambda\in(2.05,3)\text{,}$ the energy rose in 1,942 of 3,000 trials (65%). In 40 runs of 400 read iterations, every energy sequence was non-increasing, the largest final gradient was 3.5 × 10⁻¹⁰, and 2 runs ended below the diagnostic threshold $10^{-8}\max(1,\lambda_{\max}(H))\text{.}$ This is numerical ill-conditioning, not a proof of an exact kernel; the read uses its separate $10^{-10}$ cutoff.
:::

![**Figure 2.** Sheaf mean shift in the plane with two full records (dots) and three partial records, each observing one linear combination (lines), at $s=0.6\text{.}$ (a) Contours of the soft energy and the read iteration from four starts. The stars are the three local minima. (b) The soft energy along the relaxed iteration from one start. It decreases monotonically for $\lambda=0.5\text{,}$ $1$ and $1.5\text{,}$ as Theorem 3.10 guarantees. The displayed $\lambda=2.4$ trajectory includes increases, illustrating the loss of the general guarantee outside $[0,2]\text{.}$](fig/meanshift.png){width=100%}

**Spectral filtering and stationarity.** Let $B=H_\epsilon^\dagger$ be an ideal orthogonal spectral cutoff, and $d_\epsilon=B(b-Hz)\text{.}$ Its resolved components satisfy $d_\epsilon^\top\nabla E_s=-d_\epsilon^\top H d_\epsilon\text{.}$ The same quadratic majorant therefore proves (3.8) with $m-z$ replaced by $d_\epsilon\text{.}$ This statement assumes an exact spectral projector; floating-point eigensolves need numerical tolerances. A filtered fixed point only implies $B\nabla E_s=0\text{.}$ For $H=\operatorname{diag}(1,10^{-12})\text{,}$ $b=(0,10^{-12})$ and $z=0\text{,}$ the cutoff $10^{-10}$ returns $z$ although $\nabla E_s=(0,-10^{-12})\ne0\text{.}$ Reporting a rank cutoff cannot certify exact stationarity. The review suite checks filtered descent in 300 ill-conditioned stars, with 0 violations.

ADE is the special case with identity maps. The next statement restates the exact reduction of V2 in the present notation, so that Theorem 3.10 can be applied to it.

::: {custom-style="Statement"}
**Proposition 3.11** (ADE is the identity star). Take identity maps, the ADE archive weights, $s_t^2=(1-a_t)/a_t$ and $q_t=\sqrt{a_t}\,z_t\text{.}$ Assume $0<a_t\le a_{t-1}\le1\text{,}$ $a_t<1$ and $0\le\eta\le1\text{.}$ With these schedule parameters,
:::

::: {custom-style="Statement Equation"}
$\sigma_t^2=\eta^2\frac{1-a_{t-1}}{1-a_t}\Big(1-\frac{a_t}{a_{t-1}}\Big),\quad A_t=\sqrt{\frac{1-a_{t-1}-\sigma_t^2}{1-a_t}}$
:::

::: {custom-style="Statement Equation"}
$\lambda_t=1-A_t\sqrt{\frac{a_t}{a_{t-1}}}$ (3.9)
:::

::: {custom-style="Statement"}
the ADE update $q_{t-1}=A_tq_t+B_tm_t+\sigma_t\xi_t\text{,}$ with $B_t=\sqrt{a_{t-1}}-A_t\sqrt{a_t}\text{,}$ equals $z_{t-1}=(1-\lambda_t)z_t+\lambda_tm_t(z_t)+\sigma_t\xi_t/\sqrt{a_{t-1}}$ in the scaled coordinate.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 6.2.
:::

::: {custom-style="Check"}
*Numerical check.* In 100 random archives and schedules, the two updates agreed to 2.3 × 10⁻¹⁵.
:::

::: {custom-style="Statement"}
**Corollary 3.12** (every deterministic ADE layer descends at its own scale). Let $\eta=0$ and $0<a_t<a_{t-1}\le 1\text{.}$ Then $\lambda_t=1-\sqrt{a_t(1-a_{t-1})/(a_{t-1}(1-a_t))}$ satisfies $0<\lambda_t\le 1\text{,}$ and the deterministic ADE layer satisfies
:::

::: {custom-style="Statement Equation"}
$E_{s_t}(z_{t-1})\le E_{s_t}(z_t)-\tfrac12\lambda_t(2-\lambda_t)\,\|z_t-m_t(z_t)\|^2$ (3.10)
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* With $\sigma_t=0\text{,}$ the formula for $\lambda_t$ follows from (3.9). The ratio under the root is nonnegative, and it is below 1 exactly when $a_t<a_{t-1}\text{.}$ Apply Theorem 3.10 with identity maps, for which $H=I\text{.}$ ∎

The scale changes from layer to layer, so (3.10) compares two points on one energy and not energies of different layers. An ADE stack is a sequence of guaranteed-descent steps on a sequence of annealed energies.

::: {custom-style="Check"}
*Numerical check.* On the 16-layer cosine schedule with the bottom cut off at $a_{16}=10^{-4}\text{,}$ the coefficients $\lambda_t$ ranged from 0.1793 to 1.0000. Along deterministic trajectories in 100 random archives (1,600 layer steps), (3.10) was never violated, and the smallest ratio of actual to guaranteed decrease was 1.000000000000.
:::

::: {custom-style="Statement"}
**Proposition 3.13** (the Euclidean energy step). Assume $c_A>0\text{;}$ if $c_A=0\text{,}$ the gradient vanishes and the update is trivial. For $0\le\lambda\le 2/c_A\text{,}$
:::

::: {custom-style="Statement Equation"}
$E_s(z-\lambda\nabla E_s(z))\le E_s(z)-\lambda(1-\tfrac12\lambda c_A)\|\nabla E_s(z)\|^2$ (3.11)
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* By (3.7), $\nabla^2E_s\preceq c_AI$ everywhere. Taylor's formula with integral remainder along the segment gives $E_s(z+d)\le E_s(z)+\nabla E_s(z)^{\top}d+\tfrac12c_A\|d\|^2\text{.}$ Put $d=-\lambda\nabla E_s(z)\text{.}$ ∎

::: {custom-style="Check"}
*Numerical check.* In 300 random stars with random $\lambda\in(0,2/c_A)\text{,}$ inequality (3.11) was never violated; the smallest ratio of actual to guaranteed decrease was 1.00000.
:::

Table 3 collects the three updates of V2 and the guarantee that this section proves for each.

Table: **Table 3.** Layer updates and their guarantees. The noise term is omitted.

| Update | Formula | Interpretation | Guarantee |
|:----------------|:------------------|:-------------------|:-------------------|
| orthogonal transport | $z'=(1-\lambda)z+\lambda m$ | gradient step $z-\lambda\nabla E_s\text{,}$ since $H=I$ | descent for $0<\lambda<2$ (Theorem 3.10) |
| harmonic interpolation | $z'=(1-\lambda)z+\lambda m$ | preconditioned step $z-\lambda H^{\dagger}\nabla E_s$ | descent for $0<\lambda<2$ (Theorem 3.10) |
| Euclidean energy step | $z'=z-\lambda H(z-m)$ | gradient step $z-\lambda\nabla E_s$ | descent for $0<\lambda<2/c_A$ (Proposition 3.13) |


# 4 Gaussian models in a stalk

ADE rests on a Gaussian observation model: the query is a noisy view of an archived design, and the read is a posterior mean [13, Chapter 3]. In ASE that model becomes local. It is attached to one stalk, and the records are seen through their maps. This section asks which of the Gaussian identities of ADE survive, and in what form.

## 4.1 Tweedie's identity and the chart posterior

::: {custom-style="Statement"}
**Proposition 4.1** (Tweedie's identity in a stalk).
:::

::: {custom-style="Statement"}
\(i) For square orthogonal maps, let $p_s(z)=\sum_iw_i\,N(z;v_i,s^2I)/\sum_iw_i$ with $v_i=Q_i^{\top}o_i\text{.}$ Then $m(z)=z+s^2\nabla\log p_s(z)\text{.}$
:::

::: {custom-style="Statement"}
\(ii) For general maps, let $\tilde p_s(z)=\sum_iw_i\exp(-e_i(z)/s^2)\text{,}$ which may have infinite mass. Then $H(z)(m(z)-z)=s^2\nabla\log\tilde p_s(z)\text{,}$ and if $H\succ 0\text{,}$
:::

::: {custom-style="Statement Equation"}
$m(z)=z+s^2H(z)^{-1}\nabla\log\tilde p_s(z)$ (4.1)
:::

::: {custom-style="Statement Tag"}
\(i) Classical: Tweedie's formula [10], in the unscaled form of Mathematics book Proposition 3.3; (ii) New in Part II.
:::

*Proof.* Since $\log\tilde p_s=-E_s/s^2\text{,}$ Proposition 3.9 gives $s^2\nabla\log\tilde p_s=-\nabla E_s=H(m-z)\text{,}$ which is (ii). For square orthogonal maps $e_i=\tfrac12\|z-v_i\|^2\text{,}$ so $\tilde p_s$ is proportional to $p_s$ and $H=I\text{.}$ ∎

::: {custom-style="Check"}
*Numerical check.* In 200 random orthogonal stars, $z+s^2\nabla\log p_s\text{,}$ with the gradient taken by central differences, matched the read to 9.8 × 10⁻¹⁰. Part (ii) is the gradient identity of Proposition 3.9, checked there.
:::

The preconditioned form (4.1) says that the read follows the score of the local density potential, rescaled by the inverse of the normal matrix. Only the gradient of a logarithm enters, so the identity holds even when $\tilde p_s$ cannot be normalised (Proposition 4.3).

The mathematics book also reads full designs through a chart, but from the other side: there the token is observed through the chart, while the records are complete [13, Proposition 3.8]. The two operators can be compared exactly.

::: {custom-style="Statement"}
**Proposition 4.2** (chart posterior and sheaf read). Let $U\in ℝ^{D\times k}$ have orthonormal columns, let $\Sigma$ be a positive diagonal $k\times k$ matrix and $A=\Sigma^{-1}U^{\top}\text{,}$ and let the records be full designs $y_i\text{.}$ Put $a=1/(1+s^2)$ and $q=\sqrt a\,Az\text{.}$
:::

::: {custom-style="Statement"}
\(i) The posterior mean of the full design under the chart observation $q$ [13, Proposition 3.8] is $m_{\text{chart}}=\sum_i\alpha_iy_i\text{,}$ with $\alpha_i\propto w_i\exp(-\|Az-Ay_i\|^2/2s^2)\text{.}$ These are exactly the weights of sheaf attention with $Q_i=A$ and $o_i=Ay_i\text{.}$
:::

::: {custom-style="Statement"}
\(ii) The sheaf read of the same observations is $m_{\text{sheaf}}=P_Am_{\text{chart}}+(I-P_A)z\text{,}$ where $P_A=A^{\dagger}A$ is the orthogonal projector onto the row space of $A\text{.}$ Hence
:::

::: {custom-style="Statement Equation"}
$m_{\text{chart}}-m_{\text{sheaf}}=(I-P_A)(m_{\text{chart}}-z)$ (4.2)
:::

::: {custom-style="Statement Tag"}
Mathematics book Proposition 3.8; the comparison is New in Part II.
:::

*Proof.* (i) The logit of [13, (3.7)] is $\|q-\sqrt a\,Ay_i\|^2/2(1-a)=a\|Az-Ay_i\|^2/2(1-a)\text{,}$ and $a/(1-a)=1/s^2\text{.}$ (ii) Here $H=A^{\top}A$ and, since the weights sum to one, $b=A^{\top}A\,m_{\text{chart}}\text{.}$ Then $H^{\dagger}H=A^{\dagger}A=P_A\text{,}$ so $m_{\text{sheaf}}=z+H^{\dagger}H(m_{\text{chart}}-z)=z+P_A(m_{\text{chart}}-z)\text{.}$ ∎

::: {custom-style="Check"}
*Numerical check.* In 200 random charts, the two weight vectors agreed to 5.6 × 10⁻¹⁶, and (4.2) held to 4.7 × 10⁻¹⁵. The median distance between the two reads was 1.49.
:::

*Engineering meaning.* The two operators answer different questions. The chart posterior returns a convex combination of complete archived designs, and so it imports the records' coordinates off the chart. Sheaf attention keeps the token's coordinates off the chart, because it sees the records only through their maps. Which one is right depends on what the records carry. Complete designs make the posterior available. With partial observations, the retention read is a specified minimum-change rule. A different read needs additional assumptions, such as a declared prior on unobserved coordinates.

## 4.2 Two local laws

A local Gaussian model in a stalk can be built from the records in two ways, and the difference matters as soon as a record is partial.

::: {custom-style="Statement"}
**Proposition 4.3** (mixture and product). Use Lebesgue measure on the full unbounded token space $\mathbb R^D\text{,}$ with $s>0$ and positive weights. Freeze the weights $\alpha$ at the query for the product law.
:::

::: {custom-style="Statement"}
\(i) The record mixture $\mu_{\text{mix}}(dx)\propto\sum_iw_i\exp(-e_i(x)/s^2)\,dx$ has finite mass if and only if every $Q_i$ is injective.
:::

::: {custom-style="Statement"}
\(ii) The product of experts $\mu_{\text{prod}}(dx)\propto\prod_i\exp(-\alpha_ie_i(x)/s^2)\,dx=\exp(-M(x)/s^2)\,dx$ has finite mass if and only if $H\succ 0\text{,}$ and then $\mu_{\text{prod}}=N(m,s^2H^{-1})\text{.}$
:::

::: {custom-style="Statement Tag"}
New in Part II; products of experts after [18].
:::

*Proof.* (i) The $i$-th term is constant along $\text{ker}\,Q_i$ and Gaussian along $\text{range}\,Q_i^{\top}\text{,}$ so its integral is finite if and only if $\text{ker}\,Q_i=\{0\}\text{.}$ A finite sum of positive terms has finite integral if and only if each term does. (ii) By Proposition 3.2, $M(x)=M(m)+\tfrac12(x-m)^{\top}H(x-m)\text{.}$ The Gaussian integral is finite if and only if $H\succ 0\text{,}$ and its covariance is then $s^2H^{-1}\text{.}$ ∎

::: {custom-style="Check"}
*Numerical check.* At $s=1\text{,}$ on boxes of half-width 5, 10, 20 and 40, the mass of a full record in the plane was 6.283, 6.283, 6.283 and 6.283, agreeing with $2\pi$ at the shown precision. The mass of a record observing one coordinate was 25.1, 50.2, 100.4 and 200.8, proportional to the box width. The product of two records observing complementary coordinates has $\lambda_{\text{min}}(H)=0.5\text{;}$ the product of two records observing the same coordinate has $\lambda_{\text{min}}(H)=0\text{.}$
:::

*Engineering meaning.* A local law in ASE must say whether it is a mixture or a product. On the full unbounded space, a positive mixture containing a partial record has infinite mass. Restricting the domain or adding a proper prior changes this conclusion and must be declared before sampling or using importance weights [14, Section 15]. A product is a law exactly when the records jointly cover the frame, and its covariance $s^2H^{-1}$ is the conditioning of Proposition 3.6 in probabilistic form.

::: {custom-style="Statement"}
**Proposition 4.4** (imputation, gradient steps and the harmonic read). Let every $Q_i$ be a partial isometry, $Q_iQ_i^{\top}=I\text{,}$ and freeze $\alpha$ at $z\text{.}$ Impute record $i$ from the token by $x_i(z)=Q_i^{\top}o_i+(I-Q_i^{\top}Q_i)z\text{,}$ the point of $\{x:Q_ix=o_i\}$ nearest to $z\text{,}$ and let $m_A=\sum_i\alpha_ix_i\text{.}$
:::

::: {custom-style="Statement"}
\(i) $m_A=z-\nabla E_s(z)\text{:}$ one imputation is a unit gradient step.
:::

::: {custom-style="Statement"}
\(ii) If $H\succ 0\text{,}$ then $m-z=H^{-1}(m_A-z)$ and $\|m-z\|\ge\|m_A-z\|\text{:}$ the harmonic read is the preconditioned step, and it moves at least as far.
:::

::: {custom-style="Statement"}
\(iii) If $H\succ0\text{,}$ repeated imputation with frozen weights, $x_{k+1}=\sum_i\alpha_i[Q_i^{\top}o_i+(I-Q_i^{\top}Q_i)x_k]$ with $x_0=z\text{,}$ satisfies $\|x_k-m\|\le(1-\lambda_{\text{min}}(H))^k\|z-m\|$ and converges to the harmonic read.
:::

::: {custom-style="Statement Tag"}
New in Part II; (iii) is Cimmino's method of averaged projections [7] in the present notation.
:::

*Proof.* (i) $m_A=b+(I-H)z=z-(Hz-b)\text{.}$ (ii) $H(m-z)=b-Hz=m_A-z\text{.}$ Each $Q_i^{\top}Q_i$ is an orthogonal projector, so $H\preceq I$ and, with $H\succ 0\text{,}$ $H^{-1}\succeq I\text{.}$ (iii) Since $m=b+(I-H)m\text{,}$ we have $x_{k+1}-m=(I-H)(x_k-m)\text{,}$ and $\|I-H\|=1-\lambda_{\text{min}}(H)\text{.}$ ∎

::: {custom-style="Check"}
*Numerical check.* In 300 stars with masks and partial isometries, (i) held to 1.3 × 10⁻¹³, and (ii) to 1.6 × 10⁻⁹ on the 295 stars with condition number below $10^8\text{.}$ The median distance between $m_A$ and $m$ was 0.949. In 200 further stars, the rate bound of (iii) held at $k=50$ in every case. On the 165 stars with $\lambda_{\text{min}}(H)>0.05\text{,}$ 2,000 sweeps reached the read to 4.7 × 10⁻¹⁵.
:::

![**Figure 3.** (a) Two partial records whose observation sets are lines, with equal frozen weights. The imputations (squares) are the projections of the token onto the lines; their average is one gradient step (Proposition 4.4(i)), and repeated averaging converges to the harmonic read at the intersection (Proposition 4.4(iii)). (b) The smallest eigenvalue of $H$ against the selection strength $\beta$ for twelve masked records in $ℝ^4\text{,}$ with an elite that observes two coordinates or all four (Proposition 4.6; register values). (c) Total variation between the weights before and after a bounded measurement error, against $\beta\varepsilon\text{,}$ for 1,500 random trials drawn for the figure, with the sharp bound $\tanh(\beta\varepsilon/2)$ of Theorem 4.8.](fig/stalks.png){width=100%}

*Engineering meaning.* An imputation crossover fills a parent's missing coordinates from the current design. By Proposition 4.4 it takes one gradient step on the soft energy, and repeating it with fixed weights converges to the harmonic read. The harmonic read moves farther in poorly covered directions. That is where recombination acts, and also where conditioning matters.

## 4.3 Tilting

The mathematics book tilts a Gaussian by a linear loss and moves its mean by $-\beta\Sigma a$ [13, Theorem 4.4]. Two tilts arise in a stalk: of the local law, and of the record weights by selection.

::: {custom-style="Statement"}
**Proposition 4.5** (tilting the product law). If $H\succ 0\text{,}$ tilting $\mu_{\text{prod}}=N(m,s^2H^{-1})$ by $e^{-\beta a^{\top}x}$ gives $N(m-\beta s^2H^{-1}a,\ s^2H^{-1})\text{.}$ If $H$ is singular, the tilted measure has infinite mass for every $a\text{,}$ and its mass on growing boxes grows exponentially when $\beta a$ has a nonzero component in $\text{ker}\,H\text{.}$
:::

::: {custom-style="Statement Tag"}
Mathematics book Theorem 4.4 with $\Sigma=s^2H^{-1}\text{;}$ the singular case is New in Part II.
:::

*Proof.* Complete the square [13, Theorem 4.4]. If $H$ is singular, write $x=x_r+x_k$ with $x_k\in\text{ker}\,H\text{.}$ The tilted density factorises, and its factor on $\text{ker}\,H$ is $\exp(-\beta a_k^{\top}x_k)\text{,}$ whose integral over $\text{ker}\,H$ is infinite whatever $a_k$ is. ∎

::: {custom-style="Check"}
*Numerical check.* In 100 random two-dimensional stalks, the tilted mean computed by quadrature matched the formula to a relative 1.2 × 10⁻¹³. For $H=\text{diag}(1,0)$ and $\beta=1\text{,}$ with slope $0.5$ along the unobserved axis, the mass on boxes of half-width 5, 10, 20 and 40 was 63.6, 781, 1.16 × 10⁵ and 2.58 × 10⁹. With no slope there it was 26.2, 52.5, 104.9 and 209.9.
:::

A linear objective therefore moves the local mean along $H^{-1}a\text{,}$ farthest where coverage is thin. In an unobserved direction it pushes without limit, so a tilted local proposal needs coverage, a declared prior or a step bound in every direction in which the objective has slope.

::: {custom-style="Statement"}
**Proposition 4.6** (selection tilting collapses coverage). Let $w_i=w_i^0e^{-\beta J_i}\text{,}$ where $J$ has a unique minimiser $\iota\text{,}$ the elite record, and gap $\Delta=\text{min}_{i\ne\iota}(J_i-J_\iota)>0\text{,}$ with fixed query, scale and observations and $\beta\ge0\text{.}$ For coordinate masks and every coordinate $j\notin S_\iota\text{,}$
:::

::: {custom-style="Statement Equation"}
$\lambda_{\text{min}}(H)\le\kappa_j\le e^{-\beta\Delta}\sum_{i\ne\iota}\frac{w_i^0}{w_\iota^0}\exp\Big(\frac{e_\iota(z)-e_i(z)}{s^2}\Big)$ (4.3)
:::

::: {custom-style="Statement"}
So $\lambda_{\text{min}}(H)\to 0$ exponentially as $\beta\to\infty\text{.}$ The normal matrix tends to the elite's projector. The retention read of this limiting matrix retains the token elsewhere; it need not equal the limit of the exact finite-$\beta$ reads. If the elite observes every coordinate, then $H\to I\text{.}$
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* $\kappa_j\le\sum_{i\ne\iota}\alpha_i\le\sum_{i\ne\iota}\alpha_i/\alpha_\iota\text{,}$ and $\alpha_i/\alpha_\iota=(w_i^0/w_\iota^0)\,e^{-\beta(J_i-J_\iota)}\,e^{(e_\iota-e_i)/s^2}\text{.}$ As $\beta\to\infty\text{,}$ $\alpha$ tends to the indicator of $\iota$ and $H$ to $Q_\iota^{\top}Q_\iota\text{.}$ ∎

::: {custom-style="Check"}
*Numerical check.* For twelve masked records in $ℝ^4$ at $s=1.5\text{,}$ with an elite observing two coordinates, $\lambda_{\text{min}}(H)$ was 0.446, 0.261, 0.0154, 1.8 × 10⁻⁷, 2.6 × 10⁻²¹ and 5.5 × 10⁻⁶⁹ at $\beta=0,1,3,10,30$ and $100\text{.}$ With an elite observing all four coordinates it was 0.551, 0.683, 0.970, 0.9999995, 1.000 and 1.000 (Figure 3b).
:::

**Counterexample: solving and taking the limit do not commute.** Take two complementary one-coordinate masks in $\mathbb R^2$ with observations $1$ and $7\text{,}$ and token $z=(0,-2)\text{.}$ At this query choose fixed baseline weights so that the posterior weights are proportional to $(1,e^{-\beta})\text{.}$ Then $H=\operatorname{diag}(\alpha_1,\alpha_2)$ and $b=(\alpha_1,7\alpha_2)\text{.}$ For every finite $\beta\text{,}$ the exact read is $(1,7)\text{.}$ At the limiting weights $(1,0)\text{,}$ the retention read is $(1,-2)\text{,}$ a gap of 9 in the second coordinate. Vanishing coverage does not force the exact read to retain that coordinate.

*Engineering meaning.* Strong selection destroys conditioning. In a filtered implementation it can eventually suppress recombination by discarding small coverage eigenvalues; in exact arithmetic the conditional averages can survive. A fixed positive ridge prior also changes the limit, because it dominates vanishing coverage. Annealing $\beta$ or maintaining a coverage floor addresses conditioning, while the choice of cutoff or prior determines which information is actually retained.

## 4.4 Measurement

::: {custom-style="Statement"}
**Proposition 4.7** (Gaussian measurement noise). Let $\beta\ge0\text{.}$ In (ii), use $k\ge2$ and the unbiased sample variance; in (iii), use an equicorrelated Gaussian model with fixed marginal variance and $0\le\rho\le1\text{.}$ (i) If the loss of a design is measured as the mean $S_k$ of $k$ independent $N(J+b,\sigma^2)$ judgements, then $E\,e^{-\beta S_k}=\exp(-\beta(J+b)+\beta^2\sigma^2/2k)\text{,}$ so heteroscedastic noise changes the expected weights. (ii) The plug-in correction $\exp(-\beta S_k-\beta^2V/2k)\text{,}$ with $V$ the sample variance, is biased upward. (iii) A shared error with correlation $\rho$ survives repetition: the residual factor tends to $e^{\beta^2\sigma^2\rho/2}$ as $k\to\infty\text{.}$
:::

::: {custom-style="Statement Tag"}
Mathematics book Propositions 4.8, 4.9 and 4.10, retained in a specified local measure.
:::

For (ii), independence of the normal sample mean and sample variance gives an exact multiplicative factor $\exp(t)(1+2t/(k-1))^{-(k-1)/2}$ relative to $e^{-\beta(J+b)}\text{,}$ where $t=\beta^2\sigma^2/(2k)\text{.}$ This exceeds one when $t>0$ and equals one when $t=0\text{,}$ since $\log(1+x)<x$ for $x>0\text{.}$ For (iii), $\operatorname{Var}(S_k)=\sigma^2[\rho+(1-\rho)/k]$ yields the stated limit.

Proposition 4.7 concerns expected **unnormalised** weights under Gaussian noise. It does not identify the expectation of the normalised attention vector. An engineering critic, such as a surrogate model or a coarse analysis, is often known only to be within a tolerance. The next theorem covers that case.

::: {custom-style="Statement"}
**Theorem 4.8** (bounded measurement error). Let the losses be measured as $J_i+\delta_i$ with $|\delta_i|\le\varepsilon\text{,}$ $\beta\ge0$ and $\varepsilon\ge0\text{,}$ so that the weights become $\alpha'_i\propto\alpha_ie^{-\beta\delta_i}\text{.}$
:::

::: {custom-style="Statement"}
\(i) $\text{TV}(\alpha,\alpha')=\tfrac12\sum_i|\alpha'_i-\alpha_i|\le\tanh(\beta\varepsilon/2)\text{.}$ Equality holds for two records with $\alpha=(p,1-p)\text{,}$ $p=1/(1+e^{\beta\varepsilon})$ and $\delta=(-\varepsilon,\varepsilon)\text{.}$
:::

::: {custom-style="Statement"}
\(ii) For square orthogonal maps, $\|m'-m\|\le\tanh(\beta\varepsilon/2)\,\text{diam}\{v_i\}\text{.}$
:::

::: {custom-style="Statement"}
\(iii) For general maps with $H,H'\succ 0\text{,}$ $\|m'-m\|\le\text{TV}(\alpha,\alpha')\,\text{diam}\{Q_i^{\top}r_i\}/\lambda_{\text{min}}(H')\text{,}$ where $r_i=Q_im-o_i\text{.}$
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* (i) $\text{TV}(\alpha,\alpha')=\text{max}_A(\alpha'(A)-\alpha(A))$ over sets of records. Fix $A$ with $\alpha(A)=p\text{.}$ Then $\alpha'(A)=X/(X+Y)$ with $X=\sum_{i\in A}\alpha_ie^{-\beta\delta_i}\le pe^{\beta\varepsilon}$ and $Y=\sum_{i\notin A}\alpha_ie^{-\beta\delta_i}\ge(1-p)e^{-\beta\varepsilon}\text{.}$ The ratio increases in $X$ and decreases in $Y\text{,}$ so with $u=e^{2\beta\varepsilon}$ we get $\alpha'(A)-p\le\varphi(p)\text{,}$ where $\varphi(p)=pu/(pu+1-p)-p\text{.}$ Setting the derivative of $\varphi$ to zero gives $p=1/(\sqrt u+1)\text{.}$ At that point $\varphi=(\sqrt u-1)/(\sqrt u+1)\text{,}$ which equals $\tanh(\beta\varepsilon/2)\text{.}$ The two-point example attains this value. (ii) $m'-m=\sum_i(\alpha'_i-\alpha_i)v_i\text{.}$ The positive and negative parts of $\alpha'-\alpha$ each have mass $\text{TV}\text{,}$ so this is $\text{TV}$ times the difference of two convex combinations of the $v_i\text{.}$ (iii) $\sum_i\alpha_iQ_i^{\top}r_i=Hm-b=0\text{.}$ Hence $H'(m'-m)=b'-H'm=-\sum_i\alpha'_iQ_i^{\top}r_i=-\sum_i(\alpha'_i-\alpha_i)Q_i^{\top}r_i\text{,}$ and the argument of (ii) applies. ∎

::: {custom-style="Check"}
*Numerical check.* In 2,000 random weight vectors, half of them with the extremal pattern $\delta_i=\pm\varepsilon\text{,}$ (i) was never violated; the largest ratio to the bound was 0.9999985, and for (ii) it was 0.998. In 600 general stars, (iii) was never violated, with largest ratio 0.893. The two-point example at $\beta=2$ and $\varepsilon=0.7$ gave $\text{TV}=0.604368=\tanh(0.7)\text{.}$
:::

*Engineering meaning.* Theorem 4.8 sets the selection strength against the critic's error. If losses are misstated by at most $\varepsilon\text{,}$ the read of a transported archive moves by at most $\tanh(\beta\varepsilon/2)$ of its diameter, about 10% when $\beta\varepsilon=0.2\text{.}$ Equivalently, a tolerance $\nu$ on the relative displacement holds whenever $\beta\le 2\,\text{artanh}(\nu)/\varepsilon\text{.}$ Unlike Proposition 4.7, the bound is worst case and assumes no distribution.


# 5 Scale, locality and covers

A layer at scale $s$ should touch only the records near the token. Two questions follow. How much does truncating the read to a star change it? And how sensitive is the read to the token itself? This section answers both, and states the index contract the answers need.

## 5.1 Truncation

::: {custom-style="Statement"}
**Proposition 5.1** (truncating a transported read). In one token frame with transported values $v_i\text{,}$ weights $w_i$ and scale $s\text{,}$ let $S=\{i:\|z-v_i\|\le\rho\}$ be a nonempty star with complement $F\text{.}$ Let $D_S=\sum_{i\in S}w_i\exp(-\|z-v_i\|^2/2s^2)$ and $D_F$ be the star and far kernel masses, $W_S$ the star weight, $W$ the total archive weight and $R$ the diameter of the transported archive. Then the full read $m$ and the star read $m_S$ satisfy
:::

::: {custom-style="Statement Equation"}
$\|m-m_S\|\le R\,\frac{D_F}{D_S+D_F}$
:::

::: {custom-style="Statement Equation"}
$\frac{R D_F}{D_S+D_F}\le R\,\min\Big\{1,\frac{W-W_S}{D_S}e^{-\rho^2/(2s^2)}\Big\}$ (5.1)
:::

::: {custom-style="Statement"}
The right-hand side is computable from the star and the running total $W\text{,}$ without visiting the far field.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 12.1; the a posteriori form is New in Part II.
:::

*Proof.* The full read splits as $m=(D_Sm_S+D_Fm_F)/(D_S+D_F)\text{,}$ so $m-m_S=D_F(m_F-m_S)/(D_S+D_F)\text{,}$ and both conditional reads lie in the transported hull. Every far kernel is at most $w_ie^{-\rho^2/2s^2}\text{,}$ so $D_F\le(W-W_S)e^{-\rho^2/2s^2}\text{,}$ and $D_F/(D_S+D_F)\le\text{min}\{1,D_F/D_S\}\text{.}$ ∎

::: {custom-style="Check"}
*Numerical check.* An archive of 400 records drawn uniformly in $[0,10]^2$ with weights in $[0.5,1.5]$ has diameter $R=13.31\text{.}$ For $s=0.1\text{,}$ $0.3$ and $1\text{,}$ $\rho=2s\text{,}$ $3s$ and $4s\text{,}$ and 60 random query attempts each, 472 nonempty stars were tested and 68 empty stars were skipped. Neither bound in (5.1) was violated (0 and 0 violations). Table 4 lists the details.
:::

Table: **Table 4.** Truncating a transported read: 400 records in $[0,10]^2\text{,}$ 60 query attempts per row. Star shares and error ratios are conditional on nonempty stars; counts are shown with the shares. The last two columns give the largest ratio of the true error to the first bound in (5.1), and the median certificate as a fraction of $R\text{,}$ where 1 means the certificate is vacuous.

| $s$ | $\rho/s$ | star share (valid / 60) | largest error / bound | median certificate / $R$ |
|:--|:--|:--|:--|:--|
| 0.1 | 2 | 0.34% (22/60) | 0.0396 | 1 |
| 0.1 | 3 | 0.42% (37/60) | 0.0532 | 1 |
| 0.1 | 4 | 0.50% (54/60) | 0.0650 | 1 |
| 0.3 | 2 | 1.24% (59/60) | 0.0703 | 1 |
| 0.3 | 3 | 2.36% (60/60) | 0.0725 | 1 |
| 0.3 | 4 | 4.10% (60/60) | 0.0949 | 0.0534 |
| 1 | 2 | 10.58% (60/60) | 0.1270 | 1 |
| 1 | 3 | 20.88% (60/60) | 0.2000 | 0.163 |
| 1 | 4 | 33.90% (60/60) | 0.2696 | 0.00396 |

::: {custom-style="Statement"}
**Corollary 5.2** (certified radius). For a tolerance $\eta>0\text{,}$ grow the star until the right-hand side of (5.1) is at most $\eta R\text{.}$ The radius reached certifies $\|m-m_S\|\le\eta R$ at that query, before any far record is read.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

::: {custom-style="Check"}
*Numerical check.* At $\eta=10^{-3}\text{,}$ on a grid of radii from $s$ to $8s$ in steps of $s/4\text{,}$ the median certified radius was 5.875$s\text{,}$ 5.00$s$ and 4.50$s$ at $s=0.1\text{,}$ $0.3$ and $1\text{.}$ The mean star shares were 1.0%, 6.4% and 42.9%, and every certified read was within $\eta R$ of the full read. The counts certified out of 60 attempts were 60, 60 and 60, respectively.
:::

![**Figure 4.** Truncation in an archive of 400 records drawn as in the check, recomputed for the figure with its own seed. (a) Median certificate (solid) and median true error (dotted), relative to the archive diameter, against the star radius for three scales. The certificate is conservative by several orders of magnitude, and no query's error exceeded its own certificate. (b) Mean share of the archive in the star, on a logarithmic scale; dots mark the median certified radius at $\eta=10^{-3}\text{.}$](fig/locality.png){width=100%}

The a priori radius $3s$ of hypothesis C5 [14, Section 18] is not certified at $\eta=10^{-3}$ in this archive. At $3s\text{,}$ the median certificate is still vacuous for $s=0.1$ and $s=0.3\text{.}$ At $s=0.1\text{,}$ the true error was at most 0.053 of the first bound. The certificate is conservative because it charges every far record with the kernel at the boundary and every far read with the full diameter. Locality pays most at small scales, in the upper layers, where the certified star holds about 1% of the archive. It pays least at large scales, in the lower layers, where it holds over 40%.

::: {custom-style="Statement"}
**Theorem 5.3** (truncating a rectangular read). Let $S=\{i:e_i(z)\le\rho^2/2\}$ be nonempty, and let $H_S\text{,}$ $b_S$ and $m_S$ be the normal matrix, right side and read of the star with renormalised weights. Suppose $H\succ 0$ and $H_S\succ 0\text{.}$
:::

::: {custom-style="Statement"}
\(i) $\|m-m_S\|\le(\|b-b_S\|+\|H-H_S\|\,\|m_S\|)/\lambda_{\text{min}}(H)\text{.}$
:::

::: {custom-style="Statement"}
\(ii) Let $D_S=\sum_{i\in S}w_ie^{-e_i(z)/s^2}$ and $\Phi_S=\text{min}\{1,(W-W_S)e^{-\rho^2/2s^2}/D_S\}\text{.}$ Take archive constants $c_H\ge\text{max}_{i,j}\|Q_i^{\top}Q_i-Q_j^{\top}Q_j\|$ and $R_b\ge\text{diam}\{Q_i^{\top}o_i\}\text{.}$ If $\lambda_{\text{min}}(H_S)>\Phi_Sc_H\text{,}$ then
:::

::: {custom-style="Statement Equation"}
$\|m-m_S\|\le\frac{\Phi_S\,(R_b+c_H\|m_S\|)}{\lambda_{\text{min}}(H_S)-\Phi_Sc_H}$ (5.2)
:::

::: {custom-style="Statement"}
For square orthogonal maps, $c_H=0$ and $H_S=I\text{,}$ and (5.2) reduces to (5.1).
:::

::: {custom-style="Statement Tag"}
\(i) V2 Section 12; (ii) New in Part II.
:::

*Proof.* (i) $H(m-m_S)=(b-b_S)-(H-H_S)m_S\text{.}$ (ii) Let $F=D_F/(D_S+D_F)$ be the far posterior mass; as in Proposition 5.1, $F\le\Phi_S\text{.}$ With the far conditional quantities $H_F$ and $b_F\text{,}$ we have $H=(1-F)H_S+FH_F$ and $b=(1-F)b_S+Fb_F\text{,}$ so $H-H_S=F(H_F-H_S)$ and $b-b_S=F(b_F-b_S)\text{.}$ The matrix $H_F-H_S$ is the difference of two convex combinations of the $Q_i^{\top}Q_i\text{,}$ so its norm is at most $c_H\text{;}$ likewise $\|b_F-b_S\|\le R_b\text{.}$ Weyl's inequality gives $\lambda_{\text{min}}(H)\ge\lambda_{\text{min}}(H_S)-Fc_H$ [19]. Substitute into (i). The resulting bound increases with $F\text{,}$ so $F$ may be replaced by $\Phi_S\text{.}$ ∎

::: {custom-style="Check"}
*Numerical check.* For (i), 400 stars of 30 records were truncated to their 12 heaviest records: there were 0 violations, and the largest ratio was 0.994. For (ii), two families of 16 archives of 300 records in $[0,10]^D\text{,}$ $D=2$ to $4\text{,}$ with full-rank or mixed-rank random maps, were queried 8 times each at $s=0.5\text{,}$ $1$ and $2$ with $\rho=2s$ to $6s\text{.}$ Of 1,257 tests, 723 certificates were finite and 534 vacuous on nonsingular stars; 0 further stars failed the numerical observability threshold. No finite certificate was violated. The largest ratio of error to certificate was 0.017. At $s=0.5$ and $\rho=5s\text{,}$ the star held on average 16% (full rank) and 20% (mixed rank) of the archive, and the median certificates were 1.6 × 10⁻³ $R_b$ and 5.7 × 10⁻⁴ $R_b\text{.}$
:::

The tested rectangular archives were less local than the transported example. A record with a null observation direction has constant discrepancy along lines parallel to that direction, which can enlarge stars compared with full Euclidean retrieval. The certificate also needs the margin $\lambda_{\text{min}}(H_S)>\Phi_Sc_H\text{,}$ which small stars rarely provide.

## 5.2 Sensitivity of the read

The Jacobian of the read controls how errors in one layer propagate to the next, which is the subject of Part III. For identity maps it is a covariance [13, Proposition 6.2]. For general maps it is a covariance between residuals and gradients, preconditioned by $H\text{.}$

::: {custom-style="Statement"}
**Proposition 5.4** (the Jacobian of sheaf attention). Let $H\succ 0\text{,}$ and put $g_i=Q_i^{\top}(Q_iz-o_i)$ and $u_i=Q_i^{\top}(Q_im-o_i)\text{.}$
:::

::: {custom-style="Statement"}
\(i) $\sum_i\alpha_iu_i=0\text{,}$ and
:::

::: {custom-style="Statement Equation"}
$Dm(z)=s^{-2}H^{-1}\sum_i\alpha_i\,u_i\,(g_i-\langle g\rangle)^{\top}$ (5.3)
:::

::: {custom-style="Statement"}
\(ii) For square orthogonal maps, $Dm=s^{-2}C\text{,}$ with $C$ the weighted covariance of the transported records.
:::

::: {custom-style="Statement"}
\(iii) At a stationary point, $Dm=s^{-2}H^{-1}C_u\text{,}$ with $C_u=\sum_i\alpha_iu_iu_i^{\top}\text{.}$
:::

::: {custom-style="Statement"}
\(iv) Put $A=\|\operatorname{Cov}_\alpha(u)\|^{1/2}\|\operatorname{Cov}_\alpha(g)\|^{1/2}\text{.}$ Then $\|Dm\|\le A/(s^2\lambda_{\min}(H))$ and $A\le\operatorname{diam}\{u_i\}\operatorname{diam}\{g_i\}/4\text{.}$ The first bound is an equality for square orthogonal maps.
:::

::: {custom-style="Statement Tag"}
\(ii) Mathematics book Proposition 6.2, in the scaled coordinate; (i), (iii) and (iv) New in Part II.
:::

*Proof.* (i) $\sum_i\alpha_iu_i=Hm-b=0\text{.}$ Differentiate $m=H^{-1}b$ with $\nabla\alpha_i=-s^{-2}\alpha_i(g_i-\langle g\rangle)\text{:}$ $dm=H^{-1}(db-dH\,m)=-H^{-1}\sum_id\alpha_i\,u_i\text{,}$ which is (5.3). (ii) Here $H=I$ and $u_i=m-v_i=g_i-\langle g\rangle\text{.}$ (iii) At $z=m$ we have $g_i=u_i$ and $\langle g\rangle=0\text{.}$ (iv) For unit vectors $x$ and $y\text{,}$ the Cauchy–Schwarz inequality gives $|\sum_i\alpha_i(x^{\top}u_i)((g_i-\langle g\rangle)^{\top}y)|\le(x^{\top}\text{Cov}_\alpha(u)\,x)^{1/2}(y^{\top}\text{Cov}_\alpha(g)\,y)^{1/2}\text{,}$ using (i) for the first factor. The variance of a law on an interval of length $\ell$ is at most $\ell^2/4$ [2], which gives the second inequality. For square orthogonal maps, $Dm=s^{-2}C\succeq 0\text{,}$ and both covariances equal $C\text{.}$ ∎

::: {custom-style="Check"}
*Numerical check.* In 297 random stars (3 with condition number above $10^6$ were excluded), central differences matched (5.3) to 2.3 × 10⁻⁶ at worst and 1.4 × 10⁻¹⁰ in the median. Part (ii) held to 2.7 × 10⁻¹⁵ in 200 orthogonal stars, and (iii) to 3.5 × 10⁻¹⁴ at 59 stationary points. In 597 further stars, neither inequality of (iv) was violated. The ratio of $\|Dm\|$ to the first bound was 1 to within $10^{-15}$ on all 150 orthogonal stars, and $\sum_i\alpha_iu_i$ vanished to 9.2 × 10⁻¹⁵.
:::

::: {custom-style="Statement"}
**Corollary 5.5** (strict minima attract; negative curvature is unstable). Let $\zeta$ be a stationary point of $E_s$ with $H\succ 0\text{.}$ Then $Dm(\zeta)=I-H^{-1}\nabla^2E_s(\zeta)\text{,}$ and its eigenvalues are real and nonnegative. If $\nabla^2E_s(\zeta)\succ 0\text{,}$ every eigenvalue $\mu$ satisfies $0\le\mu<1\text{,}$ and the read iteration converges linearly near $\zeta\text{.}$ If $\nabla^2E_s(\zeta)$ has a negative eigenvalue, then $Dm(\zeta)$ has an eigenvalue greater than $1\text{,}$ and $\zeta$ is linearly unstable in at least one direction. A saddle can still have a stable manifold.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* At $\zeta\text{,}$ $\text{Cov}_\alpha(g)=C_u\text{,}$ so (3.7) gives $\nabla^2E_s=H-s^{-2}C_u\text{,}$ and Proposition 5.4(iii) gives $Dm=s^{-2}H^{-1}C_u=I-H^{-1}\nabla^2E_s\text{.}$ This matrix is similar to $K=s^{-2}H^{-1/2}C_uH^{-1/2}\succeq 0\text{,}$ so its eigenvalues are real and nonnegative. Moreover $I-K=H^{-1/2}\nabla^2E_sH^{-1/2}$ is congruent to $\nabla^2E_s$ and has the same inertia [19]. If $\nabla^2E_s\succ 0\text{,}$ every eigenvalue of $K$ is below 1. If $\nabla^2E_s$ has a negative eigenvalue, $K$ has an eigenvalue above 1. ∎

::: {custom-style="Check"}
*Numerical check.* At 79 minima reached by 3,000 read iterations from random starts, the identity held to 1.7 × 10⁻¹⁴, and the largest spectral radius of $Dm$ was 0.894. The largest checked gradient norm was 6.3 × 10⁻¹⁵, and 0 candidates failed the $10^{-7}$ stationarity tolerance. At the saddle formed by two records observing $x_1=\pm1$ and one observing $x_2=0.5\text{,}$ the leading eigenvalue was 4.0000 at $s=0.5$ and 1.5625 at $s=0.8\text{,}$ which is $1/s^2$ in both cases.
:::

*Engineering meaning.* Near a stationary point, the read iteration is a quasi-Newton method whose Hessian model is $H\text{.}$ It is fast where the records agree, because the residual spread $C_u$ is small. It can be slow where they disagree, and a stationary point with negative curvature has an expanding direction. Degenerate minima, with zero Hessian eigenvalues, are not classified by this result. The relaxed step of Theorem 3.10 changes the local rate to $1-\lambda(1-\mu)$ for each eigenvalue $\mu$ of $Dm\text{.}$ For $1<\lambda<2\text{,}$ over-relaxation improves the local rate when all $\mu$ are sufficiently close to one, but can worsen it when some are near zero. The decrease theorem remains valid; an acceleration claim also needs the spectrum.

## 5.3 Cost and index contracts

Table 2 gives the cost of one read. The certificates add $O(n)$ operations for a transported read, plus one smallest-eigenvalue computation, $O(D^3)\text{,}$ for a rectangular read. They also impose an index contract (Table 5). The star must contain every record with $e_i(z)\le\rho^2/2\text{.}$ For records that share a map $Q\text{,}$ this is a range query of radius $\rho$ around $Qz$ in that map's observation space, so each chart needs its own index. Masked records need one index per mask pattern, built on the observed coordinates. An approximate nearest-neighbour index voids both certificates, unless its miss probability is accounted for separately.

Table: **Table 5.** The index contract of a certified read.

| Ingredient | Requirement | Used by |
|:----------------|:-----------------------------|:----------------|
| star | every record with $e_i(z)\le\rho^2/2\text{,}$ by a complete range query per chart | (5.1), (5.2) |
| total weight $W$ | running sum over the archive, versioned with it | (5.1), (5.2) |
| constants $c_H\text{,}$ $R_b$ | valid versioned diameter bounds; pairwise updates or bounds $2\max_i\|Q_i^\top Q_i\|\text{,}$ $2\max_i\|Q_i^\top o_i\|$ | (5.2) |
| scale and radius | $s$ and $\rho/s$ stored with every read | reproducibility |
| map versions | stored per record and frozen for the token | all reads |


# 6 Topology of design spaces

Engineering design spaces are rarely a single Euclidean space. Discrete choices split them into branches. Angles live on circles. Mode shapes are lines or subspaces, defined only up to sign or rotation. Symmetric structures identify designs that are mirror images of each other. Part I separated the obstructions these create [15, Section 3.5]. This section studies what they do to the read.

## 6.1 Branches

::: {custom-style="Statement"}
**Proposition 6.1** (branch purity and branch-conditional reads). (i) If every cover element lies in one branch, and all maps, updates, noise models and decoders preserve branches, a token stays in its branch. (ii) With identity maps, let $\pi_b=\sum_{i\in b}\alpha_i$ be the weight of branch $b$ and $m_b$ the branch-conditional read, the read renormalised to the records of branch $b\text{.}$ Then the shared read is $m=\sum_b\pi_bm_b\text{,}$ and each $m_b$ lies in the hull of its own branch.
:::

::: {custom-style="Statement Tag"}
\(i) V2 Proposition 9.2; (ii) Mathematics book Theorem 3.10 and Proposition 5.16.
:::

::: {custom-style="Statement"}
**Proposition 6.2** (shared reads land in gaps). In one dimension, let the records of branch 1 lie in $[-w,0]$ and those of branch 2 in $[g,g+w]\text{,}$ with gap $g>0$ and width $w>0\text{.}$ If
:::

::: {custom-style="Statement Equation"}
$\frac{w}{g+w}<\pi_2<\frac{g}{g+w}$ (6.1)
:::

::: {custom-style="Statement"}
then the shared read lies in the gap $(0,g)\text{,}$ where no design is feasible.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* $m=\pi_1m_1+\pi_2m_2$ with $m_1\in[-w,0]$ and $m_2\in[g,g+w]\text{.}$ The smallest possible value is $-\pi_1w+\pi_2g\text{,}$ which is positive when $\pi_2>w/(g+w)\text{.}$ The largest is $\pi_2(g+w)\text{,}$ which is below $g$ when $\pi_2<g/(g+w)\text{.}$ ∎

::: {custom-style="Check"}
*Numerical check.* In 4,000 random two-branch archives with random queries and scales, no branch-conditional read left its branch. Condition (6.1) held in 1,792 cases, and the shared read landed in the gap in 1,792 of them. Overall, 2,164 shared reads landed in the gap, so (6.1) is sufficient but not necessary.
:::

::: {custom-style="Statement"}
**Proposition 6.3** (connectedness and decoder atoms). (i) A continuous image of a connected latent space is connected, so such a decoder cannot be onto a disconnected feasible set. In one dimension, nearest-point projection onto a union of separated closed intervals is discontinuous at gap midpoints. It creates an atom at an endpoint precisely when that endpoint's preimage has positive input probability. (ii) More generally, a decoded design $y$ has an atom exactly when its full decoder preimage has positive probability. Clipping or repair can satisfy this condition, but lower-dimensional support alone does not imply an atom.
:::

::: {custom-style="Statement Tag"}
Mathematics book Theorem 15.1 and Proposition 15.4.
:::

*Proof of Proposition 6.3.* Connectedness is preserved by continuous maps. For any random latent state $Z$ and measurable decoder $D\text{,}$ $\Pr[D(Z)=y]=\Pr[Z\in D^{-1}(\{y\})]\text{,}$ which proves the atom criterion. For example, $(X,Y)\mapsto(X,0)$ with continuous $X$ gives a law supported on a line but no point atoms.

*Engineering meaning.* On a design space with a discrete topology choice and continuous sizing, a shared read can propose designs that belong to no branch when several branches carry weight. Proposition 6.2 gives a sufficient condition; nonzero branch weights alone do not force it. For the interval branches above, branch-conditional reads, with an explicit branch choice and an exploration floor for unrepresented branches [14, Section 9], avoid the gap. Because the branch is chosen explicitly, they also avoid the decoder obstruction of Proposition 6.3(i).

![**Figure 5.** (a) Reads against the query for two branches, with $w=0.3\text{,}$ $g=1.4$ and $s=0.45\text{.}$ The shared read crosses the infeasible gap; the branch-conditional reads stay in their branches. The bar marks the queries at which (6.1) holds. (b) Twenty records near angle 0 at $s=0.5\text{.}$ The read in the cut coordinate, which runs from 0 to $2\pi\text{,}$ jumps as the query crosses the cut; the local displacement read is continuous across this cut (Proposition 6.5). (c) The all-image read against the nearest-image read for three finite groups, with the bound of Theorem 6.6, for 250 random archives per group drawn for the figure. (d) A record just left of the canonical half-space of the sign group is stored as its negative, far from a nearby query, so a canonical index misses it (Proposition 6.10(iv)).](fig/topology.png){width=100%}

## 6.2 Angles

An angle is stored as a coordinate with a cut, but it lives on a circle. V2 replaces the cut coordinate by local displacements $d_i=\text{wrap}(\theta_i-\theta)$ from the query, with $-\pi<d_i\le\pi$ [14, Section 10]. The read is then $r(\theta)=\theta+\sum_i\alpha_id_i$ with $\alpha_i\propto w_i\exp(-d_i^2/2s^2)\text{,}$ taken modulo $2\pi$ [22].

::: {custom-style="Statement"}
**Proposition 6.4** (nearest-lift approximation). Let $|d_i|\le\pi-\delta$ for some $\delta>0\text{.}$ Compare the weighted mean displacement using only the nearest lifts $d_i$ with the one using all lifts $d_i+2\pi k$ and their Gaussian factors. With $q=\exp(-2\pi\delta/s^2)<1\text{,}$
:::

::: {custom-style="Statement Equation"}
$|m_{\text{all}}-m_{\text{near}}|\le\frac{4\pi q(2-q)}{(1-q)^2}$ (6.2)
:::

::: {custom-style="Statement Tag"}
V2 Proposition 10.1.
:::

::: {custom-style="Check"}
*Numerical check.* In 557 random configurations with $q<1/2$ and lifts up to $|k|=30\text{,}$ (6.2) was never violated, and the largest ratio to the bound was 0.128.
:::

::: {custom-style="Statement"}
**Proposition 6.5** (the local angle read jumps only at antipodes). The local read $r$ is continuous on the circle except at the antipodes $\theta_k+\pi$ of the records. At an isolated record antipode it jumps by $2\pi\alpha_k$ modulo $2\pi\text{;}$ if several records share that antipode, replace $\alpha_k$ by their total attention. For each such record, and for every other record $j\text{,}$
:::

::: {custom-style="Statement Equation"}
$\alpha_k\le\frac{w_k}{w_j}\exp\Big(-\frac{\pi^2-d_j^2}{2s^2}\Big)$ (6.3)
:::

::: {custom-style="Statement"}
By contrast, the read in a cut coordinate $0\le\theta<2\pi$ jumps at the cut whenever records lie on both sides of it.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* Each $d_i$ is continuous except where $\theta=\theta_i+\pi\text{,}$ at which it jumps between $\pi$ and $-\pi\text{.}$ Since $d_i^2$ is continuous, so are all the weights. Hence $r$ jumps only through the term $\alpha_kd_k\text{,}$ by $2\pi\alpha_k\text{;}$ at a shared antipode these contributions add. At the antipode $|d_k|=\pi\text{,}$ so $\alpha_k/\alpha_j=(w_k/w_j)\exp(-(\pi^2-d_j^2)/2s^2)\text{,}$ and $\alpha_j\le 1\text{.}$ In a cut coordinate, the coordinate distance to a record changes by $2\pi$ when the query crosses the cut, and so do the weights. ∎

::: {custom-style="Check"}
*Numerical check.* In 300 random configurations, the jump across an antipode, measured by a straddle of $\pm10^{-9}\text{,}$ equalled $2\pi\alpha_k$ to 2.7 × 10⁻⁸, and (6.3) was never violated. For twenty records near $0.15$ and $-0.15$ at $s=0.5\text{,}$ the cut-coordinate read jumped by 5.97 rad in the coordinate, or 0.31 rad on the circle, while the local read changed by 2.5 × 10⁻¹⁰ (Figure 5b).
:::

The local read therefore has discontinuities, but only where a record sits exactly opposite the query, and they are exponentially small whenever another record is nearer than the antipode. This is the precise sense in which local displacements repair the cut.

## 6.3 Signs and finite symmetry groups

A vibration mode is a line, not a vector: $u$ and $-u$ are the same mode. A mirror-symmetric structure identifies a design with its mirror image. Both are actions of a finite group of orthogonal maps, and one theorem covers them.

::: {custom-style="Statement"}
**Theorem 6.6** (nearest-image reads for a finite group). Let $G$ be a finite group of orthogonal matrices acting on records $y_i\in ℝ^D$ with weights $w_i\text{.}$ The all-image read $m_{\text{all}}$ replaces each record by its $|G|$ images $gy_i\text{,}$ each with weight $w_i\text{.}$ The nearest-image read $m_{\text{near}}$ replaces each record by its image nearest to $z\text{.}$ Let $\Delta^2$ be the smallest, over records, gap between the nearest and second-nearest squared image distances. Put $q=e^{-\Delta^2/2s^2}$ and $\varepsilon=(|G|-1)q/(1+(|G|-1)q)\text{.}$ For the trivial group take $\Delta^2=+\infty$ and $\varepsilon=0\text{,}$ so the reads coincide. Then:
:::

::: {custom-style="Statement"}
\(i) $\|m_{\text{all}}-m_{\text{near}}\|\le 2\varepsilon\,\text{max}_i\|y_i\|\text{;}$
:::

::: {custom-style="Statement"}
\(ii) $m_{\text{all}}(gz)=g\,m_{\text{all}}(z)$ for every $g\in G\text{;}$
:::

::: {custom-style="Statement"}
\(iii) $m_{\text{near}}(gz)=g\,m_{\text{near}}(z)$ wherever the nearest images are unique.
:::

::: {custom-style="Statement Tag"}
New in Part II. The group $\{\pm I\}$ gives the sign alignment of V2 Section 11; the angle lifts of Proposition 6.4 are the analogue for the infinite group $2\pi ℤ\text{.}$
:::

*Proof.* (i) Let $\pi_i$ be the kernel weight of the nearest image $n_i$ of record $i\text{,}$ and $Z=\sum_i\pi_i\text{.}$ Every other image has relative weight at most $q\text{,}$ so the extra mass $Y$ satisfies $Y\le(|G|-1)qZ\text{.}$ Then $m_{\text{all}}-m_{\text{near}}$ is a weighted sum of the vectors $gy_i-m_{\text{near}}$ over non-nearest images, with total weight $Y/(Z+Y)\le\varepsilon\text{.}$ Each vector has norm at most $\|y_i\|+\|m_{\text{near}}\|\le 2\,\text{max}_i\|y_i\|\text{,}$ because orthogonal maps preserve norms and $m_{\text{near}}$ is a convex combination of images. (ii) $\|gz-hy_i\|=\|z-g^{-1}hy_i\|\text{,}$ so reindexing the images by $h=gh'$ maps the weighted image set at $z$ onto $g$ times itself. (iii) The image of $y_i$ nearest to $gz$ is $g$ times the image nearest to $z\text{.}$ ∎

::: {custom-style="Check"}
*Numerical check.* For sign flips in $ℝ^6\text{,}$ mirror reversal of the coordinates in $ℝ^6$ and the dihedral group of order 12 in $ℝ^2\text{,}$ 500 random archives each gave no violation of (i). The largest ratios to the bound were 0.647, 0.639 and 0.386. Equivariance held to 4.6 × 10⁻¹⁵ for the all-image read and to 4.3 × 10⁻¹⁵ for the nearest-image read (Figure 5c).
:::

::: {custom-style="Statement"}
**Example 6.7** (sign transport, re-run). Take fifty unit vectors in $ℝ^6$ near a reference direction $u\text{,}$ with random signs. At $s=2\text{,}$ the raw read has norm 0.089 and cosine 0.942 with $u\text{,}$ while the sign-aligned read has norm 0.859 and cosine 0.997. At $s=0.5$ they are 0.866 (0.993) and 0.879 (0.996), because a small scale already selects the nearest images.
:::

::: {custom-style="Statement Tag"}
V2 Section 11; this is a new random instance, so the numbers differ from the proposal's while the conclusion stands.
:::

## 6.4 Lines and subspaces

Repeated or nearly repeated eigenvalues define a modal subspace in which individual eigenvectors rotate freely. The stable object is the orthogonal projector onto the subspace, and the read is the weighted projector average $P_\alpha=\sum_i\alpha_iP_i\text{,}$ whose top eigenvectors span the read subspace [14, Section 11].

::: {custom-style="Statement"}
**Proposition 6.8** (projector reads).
:::

::: {custom-style="Statement"}
\(i) For lines in the plane at angles $\phi_i\text{,}$ measured from a reference direction with $\text{max}_i|\phi_i|=\psi\text{,}$ let $\theta_P$ be the principal direction of $P_\alpha$ and $\theta_m$ the direction of the sign-aligned mean $\sum_i\alpha_i(\cos\phi_i,\sin\phi_i)\text{.}$ With $\mu=\sum_i\alpha_i\phi_i$ and $\kappa_3=\sum_i\alpha_i(\phi_i-\mu)^3\text{,}$
:::

::: {custom-style="Statement Equation"}
$\theta_P-\theta_m=-\tfrac12\kappa_3+O(\psi^5)$ (6.4)
:::

::: {custom-style="Statement"}
\(ii) For $1\le k<D\text{,}$ if $P_\alpha$ is perturbed to $P_\alpha+E\text{,}$ and $\gamma=\lambda_k(P_\alpha)-\lambda_{k+1}(P_\alpha)>0$ is the gap below the top $k$ eigenvalues, then the read subspaces satisfy $\|\sin\Theta\|\le 2\|E\|/\gamma\text{.}$
:::

::: {custom-style="Statement"}
\(iii) Under the bounded measurement error of Theorem 4.8, $\|E\|\le\text{TV}(\alpha,\alpha')\,\text{max}_{i,j}\|P_i-P_j\|\text{,}$ so $\|\sin\Theta\|\le 2\tanh(\beta\varepsilon/2)\,\text{max}_{i,j}\|P_i-P_j\|/\gamma\text{.}$
:::

::: {custom-style="Statement Tag"}
\(i) and (iii) New in Part II; (ii) Classical [9, 25].
:::

*Proof.* (i) Write $\phi_i=\mu+\delta_i$ with $\sum_i\alpha_i\delta_i=0\text{.}$ Expanding, $\sum_i\alpha_i\sin\delta_i=-\kappa_3/6+O(\psi^5)$ and $\sum_i\alpha_i\cos\delta_i=1+O(\psi^2)\text{,}$ so $\theta_m=\mu-\kappa_3/6+O(\psi^5)\text{.}$ Likewise $\sum_i\alpha_i\sin 2\delta_i=-\tfrac43\kappa_3+O(\psi^5)\text{,}$ so $\theta_P=\mu+\tfrac12\text{atan2}(\sum_i\alpha_i\sin 2\delta_i,\sum_i\alpha_i\cos 2\delta_i)=\mu-\tfrac23\kappa_3+O(\psi^5)\text{.}$ Subtract. (ii) If $\|E\|\ge\gamma/2\text{,}$ the bound exceeds 1, and $\|\sin\Theta\|\le 1$ always. Otherwise, Weyl's inequality separates the perturbed top-$k$ eigenvalues from the remaining unperturbed spectrum by at least $\gamma-\|E\|\ge\gamma/2\text{.}$ The Davis–Kahan $\sin\Theta$ theorem then gives $\|\sin\Theta\|\le\|E\|/(\gamma/2)$ [9, 25]. (iii) $E=\sum_i(\alpha'_i-\alpha_i)P_i$ is $\text{TV}$ times the difference of two convex combinations of projectors. That difference has norm at most $\text{max}_{i,j}\|P_i-P_j\|\text{,}$ because the norm is convex. ∎

::: {custom-style="Check"}
*Numerical check.* In 400 random sets of lines with spread up to 0.48 rad, $|\theta_P-\theta_m+\kappa_3/2|/\psi^5$ was at most 0.307. In 400 random subspace perturbations, (ii) was never violated, with largest ratio 0.430. In 400 trials with bounded measurement error, both inequalities of (iii) held, with largest ratios 0.999 and 0.370.
:::

Sign alignment and projector averaging therefore agree to second order, and differ at third order by half the third central moment of the angles. When the records are skewed around the mean mode, the two reads disagree measurably. The full averaged projector remains Lipschitz in its weights. Extracting its top-$k$ subspace requires a nonzero gap at the boundary of that cluster; the subspace bound becomes uninformative when that gap closes. An internal degeneracy can instead be handled by retaining the entire separated modal cluster.

## 6.5 Physical quotients

A reflected copy of an archived design is a new coordinate vector but often the same engineering design. Hypothesis C4 of V2 asks that novelty be reported modulo symmetry [14, Section 18].

::: {custom-style="Statement"}
**Definition 6.9** (orbit distance and novelty modulo symmetry). For a finite group $G$ of orthogonal matrices, the orbit distance is $d_G(x,y)=\text{min}_{g\in G}\|x-gy\|\text{.}$ A candidate $x$ is coordinate-novel at tolerance $\tau$ if $\|x-y_i\|>\tau$ for every archived $y_i\text{,}$ and orbit-novel if $d_G(x,y_i)>\tau$ for every $i\text{.}$
:::

::: {custom-style="Statement Tag"}
V2 Section 18, hypothesis C4, made a definition.
:::

::: {custom-style="Statement"}
**Proposition 6.10** (indexing modulo a finite group).
:::

::: {custom-style="Statement"}
\(i) $d_G$ is a metric on the orbit space $ℝ^D/G\text{,}$ and orbit novelty implies coordinate novelty.
:::

::: {custom-style="Statement"}
\(ii) A range query of radius $\tau$ in $d_G$ is answered exactly by $|G|$ ordinary range queries of radius $\tau$ at the points $g^{-1}x\text{,}$ followed by removal of duplicate records.
:::

::: {custom-style="Statement"}
\(iii) If $G$ is generated by reflections, let $𝒞$ be a closed fundamental chamber and $c(x)$ the unique point of the orbit $Gx$ in $𝒞\text{.}$ Then $d_G(x,y)=\|c(x)-c(y)\|\text{,}$ so one ordinary index on canonical representatives is exact.
:::

::: {custom-style="Statement"}
\(iv) Let $G=\{I,g\}$ with $g$ an involution whose $-1$ eigenspace has dimension at least 2. Then no continuous map $c$ on the set of points not fixed by $g$ satisfies $c(x)\in\{x,gx\}$ and $c(gx)=c(x)\text{.}$ Consequently, a single ordinary Euclidean radius query on canonical representatives cannot preserve every orbit neighbourhood: discontinuities can turn arbitrarily close orbit neighbours into separated representatives. This does not preclude exact indexes using multiple images, additional probes or other orbit-aware data structures. This applies to the sign group in $ℝ^D$ for $D\ge 2\text{,}$ and to mirror reversal of a design with at least two mirrored pairs of coordinates.
:::

::: {custom-style="Statement Tag"}
\(i) and (ii) Classical; (iii) from [20, Section 1.12]; (iv) New in Part II.
:::

*Proof.* (i) Orthogonality gives $\|x-gy\|=\|g^{-1}x-y\|\text{,}$ hence symmetry, and the triangle inequality follows from $\|x-ghz\|\le\|x-gy\|+\|y-hz\|\text{.}$ The minimum over a finite group is attained, so $d_G(x,y)=0$ only when $x$ and $y$ lie on one orbit. Orbit novelty implies coordinate novelty because $d_G\le\|\cdot\|\text{.}$ (ii) $\|x-gy\|=\|g^{-1}x-y\|\text{.}$ (iii) For $x,y\in 𝒞$ and $w\in G\text{,}$ the conjugate of $wy$ in $𝒞$ is $y\text{,}$ and $y-wy$ is a nonnegative combination of simple roots [20, Lemma and Theorem 1.12]. Since $x\in 𝒞$ has nonnegative inner product with every simple root, $\langle x,y-wy\rangle\ge 0\text{,}$ so $\|x-wy\|^2-\|x-y\|^2=2\langle x,y-wy\rangle\ge 0\text{.}$ Thus $d_G(x,y)=\|x-y\|$ on $𝒞\text{,}$ and $d_G$ is constant on orbits. (iv) Write $x=x_s+x_a$ with $x_s$ in the $+1$ and $x_a$ in the $-1$ eigenspace of $g\text{.}$ The points not fixed by $g$ are those with $x_a\ne 0\text{,}$ a connected set because $x_a$ ranges over a space of dimension at least 2 with the origin removed. On it, $c(x)=x$ or $c(x)=gx\text{,}$ and the choice is a continuous function into $\{1,-1\}\text{,}$ hence constant. If $c(x)=x$ everywhere, then $c(gx)=gx\ne x=c(x)\text{;}$ if $c(x)=gx$ everywhere, then $c(gx)=x\ne gx=c(x)\text{.}$ For the sign group the $-1$ eigenspace is $ℝ^D\text{.}$ For mirror reversal its dimension is the number of mirrored pairs. ∎

::: {custom-style="Check"}
*Numerical check.* For the dihedral group of order 12, a reflection group, $d_G$ and the canonical distance agreed to 2.0 × 10⁻¹⁵ on 2,000 random pairs. Queries were placed near random images of 500 archived designs, with noise of standard deviation 0.15. Over 2,000 queries, an index on a canonical half-space missed the true nearest orbit neighbour in 82 queries (4.1%) for sign flips in $ℝ^6\text{,}$ and in 86 (4.3%) for mirror reversal in $ℝ^6$ (Figure 5d).
:::

*Engineering meaning.* Re-selection and novelty under symmetry should be measured with $d_G\text{,}$ computed exactly by $|G|$ queries, or by a chamber index when the group is generated by reflections. Storing canonical orbit representatives, as hypothesis C4 suggests, is exact for a single mirrored pair of members. A symmetric truss with two or more mirrored pairs has no continuous canonical form, so a single Euclidean index on canonical representatives can miss near-orbit neighbours at a positive novelty tolerance. Exact copies of the same orbit still have the same canonical representative; discontinuity by itself does not turn an exact reflected duplicate into a novel design.


# 7 Register of numerical checks

Tables 6 and 6a list the numerical checks in Part II. A main script produced 20 checks and a supplementary script 14. Both write machine-readable results. Reported register outcomes are filled from these files at build time; theorem constants, example parameters and illustrative figure settings are specified separately. Eight focused review checks are recorded in `review_checks.json`, including the noncommuting selection limit, filtered fixed points, filtered descent, unit invariance, coincident antipodes and exact orbit duplicates. The checks test the implementations and illustrate the statements; the proofs establish them. Random archives are synthetic, so the ratios to bounds describe these constructions, not engineering archives in general.

Table: **Table 6.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 3.1 | harmonic extension, 300 stars | 2.6 × 10⁻¹³; 0 of 15,000 perturbations lower the energy |
| 2 | Proposition 3.1(ii) | Schur-complement minimum, 300 stars | relative 2.4 × 10⁻¹⁴ |
| 3 | Proposition 3.2 | retention read, 300 singular stars | nearest minimiser to 5.1 × 10⁻⁹; ridge-bound excess 2.8 × 10⁻⁹ |
| 4 | Proposition 3.3 | matrix weights, 300 stars | sum 7.8 × 10⁻¹⁴; lifts 7.1 × 10⁻¹⁴ |
| 5 | Corollary 3.4, Proposition 3.5 | hulls, boxes, crossovers | 0 box violations; 345 outside hull; 300 of 300 crossovers outside |
| 6 | Proposition 3.5(iii) | coordinatewise ceiling, 400 stars | 0 violations; 15 beat the best record |
| 7 | Proposition 3.6 | bounds (3.5), 460 pairs | 0 and 0 violations; ratio from 0.5000004 |
| 8 | Proposition 3.6(i) | spectrum (3.4), 500 pairs | 9.8 × 10⁻¹⁵ |
| 9 | Proposition 3.7 | amplification, coverage, two lines | largest ratio 0.9991; coverage exact; $1/\sin\theta$ exact |
| 10 | Proposition 3.8 | residual trace, 300 stars | 3.6 × 10⁻¹⁵ |
| 11 | Propositions 3.9, 4.1 | gradient and Tweedie identities | 1.8 × 10⁻⁹ and 9.8 × 10⁻¹⁰ |
| 12 | Propositions 3.9, 3.13 | Hessian and Euclidean step, 300 stars | Hessian 6.2 × 10⁻¹⁰; 0 violations |
| 13 | Theorem 3.10 | majorise–minimise, 3,000 stars, 40 runs | 0 violations; all runs monotone; rises beyond $\lambda=2$ in 65% |
| 14 | Proposition 3.11 | ADE recovery, 100 cases | 2.3 × 10⁻¹⁵ |
| 15 | Corollary 3.12 | ADE layers, 1,600 steps | 0 violations |
| 16 | Proposition 4.2 | chart posterior, 200 charts | (4.2) to 4.7 × 10⁻¹⁵ |
| 17 | Proposition 4.3 | properness | $2\pi$ for a full record; linear growth for a partial one |
| 18 | Proposition 4.4(i), (ii) | imputation, 300 stars | 1.3 × 10⁻¹³ and 1.6 × 10⁻⁹ |
| 19 | Proposition 4.4(iii) | Cimmino sweeps, 200 stars | 0 rate violations; 4.7 × 10⁻¹⁵ |
| 20 | Proposition 4.5 | tilted product law | 1.2 × 10⁻¹³; exponential mass growth with slope |
| 21 | Proposition 4.6 | selection tilt | $\lambda_{\text{min}}$ 5.5 × 10⁻⁶⁹ against 1.000 at $\beta=100$ |
| 22 | Theorem 4.8 | measurement, 2,000 and 600 trials | 0 violations; two-point case attains the bound |
| 23 | Proposition 5.1, Corollary 5.2 | truncation, 540 attempts; 472 valid stars | 0 violations; certified radii 5.88$s\text{,}$ 5.00$s\text{,}$ 4.50$s$ |
| 24 | Theorem 5.3(i) | rectangular truncation, 400 stars | 0 violations; largest ratio 0.994 |
| 25 | Theorem 5.3(ii) | rectangular certificate, 1,257 tests | 723 finite, none violated; largest ratio 0.017 |
| 26 | Proposition 5.4(i)–(iii) | Jacobian, 297 stars | 2.3 × 10⁻⁶ worst; orthogonal 2.7 × 10⁻¹⁵ |
| 27 | Proposition 5.4(iv) | Jacobian bound, 597 stars | 0 violations; equality on orthogonal stars |
| 28 | Corollary 5.5 | stationary points | 79 minima; maximum $\rho(Dm)\approx$ 0.894; saddles at $1/s^2$ |
| 29 | Proposition 6.2 | branches, 4,000 archives | 1,792 of 1,792 in the gap |
| 30 | Propositions 6.4, 6.5 | angle lifts and antipodal jumps | 0 and 0 violations; cut jump 5.97 rad |
| 31 | Theorem 6.6 | nearest images, three groups | 0 violations in 1,500 trials |
| 32 | Example 6.7 | sign transport | read norm 0.089 raw against 0.859 aligned |
| 33 | Proposition 6.8 | projector reads, 400 and 400 trials | residual at most 0.307$\psi^5\text{;}$ 0 violations |
| 34 | Proposition 6.10 | orbit indexes | reflection group 2.0 × 10⁻¹⁵; misses 4.1% and 4.3% |
| 35 | Appendix A | C# kernel against NumPy | 12 of 12 lines agree; 11 identical to 15 digits |

## 7.1 Focused mathematical review checks

Table: **Table 6a.** Eight focused checks supplement the thirty-four experiment groups. Algebraic examples distinguish claims that a random test alone cannot separate.

| Check | Outcome |
|:-----------------------------|:----------------------------------------------|
| Positive operator weights | read cost −2.0; both archived costs are −1.1; read is outside their segment |
| Selection limit | exact finite-tilt read $(1,7)\text{;}$ read of limiting weights $(1,-2)$ |
| Filtered fixed point | filtered step zero with exact gradient norm 1.0 × 10⁻¹² |
| Filtered descent | 300 stars; 0 violations |
| Change of physical units | discrepancy difference 0 after corresponding whitening |
| Boundary-supported law | $(X,Y)\mapsto(X,0)$ with continuous $X\text{:}$ no point atoms |
| Coincident antipodes | straddle error 4.2 × 10⁻¹⁰ against the total-weight jump |
| Exact orbit duplicate | canonical distance 0 for $x$ and $-x$ |

# 8 Discussion

## 8.1 What Part II supplies to the rest of the book

Part III, the vertical stack, studies the token recurrence. Its layer updates are those of Table 3, and Corollary 3.12 adds that every deterministic ADE layer is a guaranteed-descent step at its own scale. Proposition 5.4 gives the tangent map of one layer. Products of these maps along a token's path are the tangent fibre diagrams of Part I, and the eigenvalue description of Corollary 5.5 says which tangent directions contract at a converged layer. The chain rule must use the complete layer update. With fixed schedule and additive noise realisations, a relaxed layer has $J_t=(1-\lambda_t)I+\lambda_t Dm_t\text{.}$ If $L_t$ bounds $\|Dm_t\|$ on the relevant domain, then

::: {custom-style="Equation"}
$\|J_1\cdots J_T\|\le\prod_{t=1}^T\bigl(|1-\lambda_t|+|\lambda_t|L_t\bigr)$ (8.1)
:::

This follows from the operator-norm triangle inequality and submultiplicativity. Multiplying the read bounds $L_t$ alone is valid for full-read layers with $\lambda_t=1\text{,}$ but not for arbitrary relaxations. Changes of coordinates, inverse-image comparisons and state-dependent noise require their own derivative factors. This supplies the interface for the end-to-end error analysis requested before testing C5 [14, Section 12].

Part IV, on targets and estimation, inherits the distinction between mixture and product laws (Proposition 4.3). A local law is a probability law only under the stated conditions, and only a proper law can serve as an importance proposal. Proposition 4.5 adds that a tilted proposal needs coverage in every direction of objective slope, and Theorem 4.8 gives a worst-case budget for critic error. The truncation certificates separate truncation error from estimation error in any consistency argument.

Part V, on fusion and constraints, must keep products of experts apart from the junction-tree marginal extension of V2 [14, Section 16], since they are different operations with different conclusions. The coordinatewise ceiling of Proposition 3.5(iii) bounds what recombination alone can achieve before constraints act. Part VI, on evidence and computation, takes the retention rule, the eigenvalue threshold, the certificates and the index contract of Table 5 as kernel specifications. Appendix A gives the first implementation.

## 8.2 Diagnostics a layer should report

Defensibility requires that every read carry the quantities its guarantees depend on (Table 7).

Table: **Table 7.** Diagnostics reported with every read.

| Diagnostic | Source | Action when it is poor |
|:-------------------|:-------------------|:-------------------------------|
| $\lambda_{\text{min}}(H)$ or the smallest coverage | Propositions 3.6, 3.7, 4.6 | enlarge the star, add a declared prior, or anneal $\beta$ |
| exact and filtered unresolved dimensions, with cutoff | Proposition 3.2 | distinguish lost observations from discarded weak directions |
| predicted decrease and actual energy difference | Theorem 3.10 | keep $0<\lambda<2$ and monitor numerical residuals |
| truncation certificate and star share | Proposition 5.1, Theorem 5.3 | grow the star or fall back to the full read |
| Jacobian bound | Proposition 5.4(iv) | flag sensitive reads |
| branch weights $\pi_b$ | Propositions 6.1, 6.2 | read per branch when (6.1) holds |
| largest antipodal weight | Proposition 6.5 | none while it is exponentially small |
| orbit distance $d_G$ to the archive | Proposition 6.10 | report orbit novelty, not coordinate novelty |

## 8.3 What is not claimed

The descent of Theorem 3.10 holds at one layer, for fixed records, maps and prior weights. It does not imply that the iterates converge, and it says nothing about search across layers. The baseline weights and maps are fixed over the domain of each derivative and update segment; learned or query-dependent maps and weights add terms to every derivative used here [14, Section 6]. The certificates assume a complete star and were conservative by two to six orders of magnitude in the experiments. None of hypotheses C1 to C5 is tested. In particular, the recombination results of Section 3.3 describe single reads, not search outcomes.

## 8.4 Open problems

1. **Convergence of iterates.** Prove that sheaf mean-shift iterates converge for rectangular maps under conditions comparable to those known for Gaussian mean shift [5].
2. **Sharper certificates.** Use second moments of the far field, or a hierarchical index, to tighten (5.1) and (5.2) by orders of magnitude without losing their a posteriori character.
3. **Compact symmetry groups.** Rotational symmetries of components form compact groups such as $SO(2)$ and $SO(3)\text{.}$ Extend Theorem 6.6, with Haar averages in place of finite sums, and Proposition 6.10 to their orbit spaces.
4. **Adaptive maps.** Add the Jacobian terms of query-dependent maps to Proposition 5.4, and certify truncation when the maps themselves are uncertain.
5. **Selection against critic error.** Design annealing schedules for $\beta$ that respect the budget of Theorem 4.8 while keeping the coverage of Proposition 4.6, and test them within hypothesis C2.
6. **Grassmannian reads.** Compare the projector read with Karcher means on the Grassmannian, and determine when the third-order disagreement of Proposition 6.8(i) matters for mode tracking.

## 8.5 Conclusion

One layer of ASE is one operation: a read through maps on an observation star. Part II shows that this read is a harmonic extension, a matrix-weighted combination, a recombination operator with a provable ceiling, and a majorise–minimise step on the soft energy, of which every deterministic ADE layer is an instance. Its local laws, tilts and measurement errors obey exact statements, and so do its locality and sensitivity. On structured design spaces its failure modes are explicit and its repairs proved: gaps between branches, cuts in angles, signs and symmetries. Part III now stacks these layers.

# References

::: {custom-style="Bibliography"}
[1] Barbero, F., Bodnar, C., Sáez de Ocáriz Borde, H. and Liò, P. (2022). Sheaf attention networks. *NeurIPS 2022 Workshop on Symmetry and Geometry in Neural Representations*. https://openreview.net/pdf?id=LIDvgVjpkZr.

[2] Bhatia, R. and Davis, C. (2000). A better bound on the variance. *The American Mathematical Monthly* 107(4), 353–357.

[3] Björck, Å. and Golub, G. H. (1973). Numerical methods for computing angles between linear subspaces. *Mathematics of Computation* 27(123), 579–594.

[4] Bodnar, C., Di Giovanni, F., Chamberlain, B. P., Liò, P. and Bronstein, M. M. (2022). Neural sheaf diffusion: a topological perspective on heterophily and oversmoothing in GNNs. *Advances in Neural Information Processing Systems* 35. arXiv:2202.04579.

[5] Carreira-Perpiñán, M. Á. (2007). Gaussian mean-shift is an EM algorithm. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 29(5), 767–776. https://doi.org/10.1109/TPAMI.2007.1057.

[6] Cheng, Y. (1995). Mean shift, mode seeking, and clustering. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 17(8), 790–799.

[7] Cimmino, G. (1938). Calcolo approssimato per le soluzioni dei sistemi di equazioni lineari. *La Ricerca Scientifica ed il Progresso Tecnico nell'Economia Nazionale*, Serie II, 1, 326–333.

[8] Comaniciu, D. and Meer, P. (2002). Mean shift: a robust approach toward feature space analysis. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 24(5), 603–619.

[9] Davis, C. and Kahan, W. M. (1970). The rotation of eigenvectors by a perturbation. III. *SIAM Journal on Numerical Analysis* 7(1), 1–46.

[10] Efron, B. (2011). Tweedie's formula and selection bias. *Journal of the American Statistical Association* 106(496), 1602–1614. https://doi.org/10.1198/jasa.2011.tm11181.

[11] Fashing, M. and Tomasi, C. (2005). Mean shift is a bound optimization. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 27(3), 471–474. https://doi.org/10.1109/TPAMI.2005.59.

[12] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[13] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[14] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[15] Ghosh, D. P. (2026d). *Horizontally Topological, Vertically Algebraic: The Two Axes of Autoregressive Sheaf Evolution. Part I: Sheaves on Covers and Representations of the Layer Order*. 18 October 2026.

[16] Halmos, P. R. (1969). Two subspaces. *Transactions of the American Mathematical Society* 144, 381–389.

[17] Hansen, J. and Ghrist, R. (2019). Toward a spectral theory of cellular sheaves. *Journal of Applied and Computational Topology* 3(4), 315–358. https://arxiv.org/abs/1808.01513.

[18] Hinton, G. E. (2002). Training products of experts by minimizing contrastive divergence. *Neural Computation* 14(8), 1771–1800.

[19] Horn, R. A. and Johnson, C. R. (2013). *Matrix Analysis*, 2nd edn. Cambridge University Press.

[20] Humphreys, J. E. (1990). *Reflection Groups and Coxeter Groups*. Cambridge Studies in Advanced Mathematics 29. Cambridge University Press.

[21] Hunter, D. R. and Lange, K. (2004). A tutorial on MM algorithms. *The American Statistician* 58(1), 30–37.

[22] Mardia, K. V. and Jupp, P. E. (2000). *Directional Statistics*. Wiley.

[23] Ramsauer, H., Schäfl, B., Lehner, J., Seidl, P., Widrich, M., Adler, T., Gruber, L., Holzleitner, M., Pavlović, M., Sandve, G. K., Greiff, V., Kreil, D., Kopp, M., Klambauer, G., Brandstetter, J. and Hochreiter, S. (2021). Hopfield networks is all you need. *International Conference on Learning Representations*. arXiv:2008.02217.

[24] Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, J., Jones, L., Gomez, A. N., Kaiser, Ł. and Polosukhin, I. (2017). Attention is all you need. *Advances in Neural Information Processing Systems* 30.

[25] Yu, Y., Wang, T. and Samworth, R. J. (2015). A useful variant of the Davis–Kahan theorem for statisticians. *Biometrika* 102(2), 315–323. https://arxiv.org/abs/1405.0680.

[26] Yuille, A. L. and Rangarajan, A. (2003). The concave-convex procedure. *Neural Computation* 15(4), 915–936.
:::

# Appendix A: an immutable C# reference kernel

The kernel computes sheaf attention with the retention rule, the soft energy, relaxed steps with their guaranteed decrease, the scalar truncation certificate, and all-image and nearest-image reads under a finite group. Values are immutable records and functions are pure; the symmetric eigensolver, a cyclic Jacobi method, works on a private copy of its input. The kernel targets .NET 8 and uses only the base class library. Inputs are assumed finite, prewhitened and dimensionally consistent. It recomputes normal blocks for clarity; Table 2 assumes these blocks are cached. The eigensolver is a small reference implementation, not a general numerical linear-algebra library.

```csharp
// ASE Part II reference kernel: sheaf attention on an observation star.
// Immutable values and pure functions; numerical routines use private copies.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AsePartTwo;

/// <summary>A dense real matrix stored row-major.</summary>
public sealed record Matrix(int Rows, int Cols, Vec Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Matrix Of(int rows, int cols, params double[] data) =>
        new(rows, cols, ImmutableArray.Create(data));

    public static Matrix Zero(int n) =>
        new(n, n, ImmutableArray.CreateRange(new double[n * n]));

    public Matrix Transpose() =>
        new(Cols, Rows, Enumerable.Range(0, Rows * Cols)
            .Select(k => this[k % Rows, k / Rows]).ToImmutableArray());

    public Matrix Times(Matrix b) =>
        new(Rows, b.Cols, Enumerable.Range(0, Rows * b.Cols)
            .Select(k => Enumerable.Range(0, Cols)
                .Sum(j => this[k / b.Cols, j] * b[j, k % b.Cols]))
            .ToImmutableArray());

    public Matrix Plus(Matrix b) =>
        this with { Data = Data.Zip(b.Data, (p, q) => p + q).ToImmutableArray() };

    public Matrix Scale(double s) =>
        this with { Data = Data.Select(x => s * x).ToImmutableArray() };

    public Vec Apply(Vec x) =>
        Enumerable.Range(0, Rows)
            .Select(r => Enumerable.Range(0, Cols).Sum(c => this[r, c] * x[c]))
            .ToImmutableArray();

    /// <summary>Eigenvalues and eigenvectors (columns) of a symmetric matrix,
    /// by cyclic Jacobi rotations on a private copy.</summary>
    public (Vec Values, Matrix Vectors) SymmetricEigen()
    {
        int n = Rows;
        var a = Data.ToArray();
        var v = new double[n * n];
        for (int i = 0; i < n; i++) v[i * n + i] = 1.0;
        void Rotate(double[] m, int i, int j, double c, double s)
        {
            (m[i], m[j]) = (c * m[i] - s * m[j], s * m[i] + c * m[j]);
        }
        for (int sweep = 0; sweep < 100; sweep++)
        {
            double off = 0.0;
            for (int p = 0; p < n; p++)
                for (int q = p + 1; q < n; q++) off += a[p * n + q] * a[p * n + q];
            if (off < 1e-300) break;
            for (int p = 0; p < n - 1; p++)
                for (int q = p + 1; q < n; q++)
                {
                    double apq = a[p * n + q];
                    if (apq == 0.0) continue;
                    double th = (a[q * n + q] - a[p * n + p]) / (2.0 * apq);
                    double t = th == 0.0 ? 1.0
                        : Math.Sign(th) / (Math.Abs(th) + Math.Sqrt(th * th + 1.0));
                    double c = 1.0 / Math.Sqrt(t * t + 1.0), s = t * c;
                    for (int k = 0; k < n; k++)
                    {
                        Rotate(a, k * n + p, k * n + q, c, s);
                        Rotate(v, k * n + p, k * n + q, c, s);
                    }
                    for (int k = 0; k < n; k++)
                        Rotate(a, p * n + k, q * n + k, c, s);
                }
        }
        return (Enumerable.Range(0, n).Select(i => a[i * n + i]).ToImmutableArray(),
                new Matrix(n, n, v.ToImmutableArray()));
    }
}

/// <summary>One leaf of the star: edge map Q, observation R y and log prior
/// weight.</summary>
public sealed record ObservedRecord(Matrix Q, Vec Observation, double LogWeight);

/// <summary>One read: weights, normal matrix H, right side b, the read value
/// and diagnostics.</summary>
public sealed record SheafRead(Vec Weights, Matrix Normal, Vec Rhs, Vec Value,
                               double MinEigenvalue, bool Unresolved);

public static class SheafAttention
{
    static double Discrepancy(ObservedRecord r, Vec z) =>
        0.5 * r.Q.Apply(z).Zip(r.Observation, (p, o) => (p - o) * (p - o)).Sum();

    static Vec Logits(Vec z, ImmutableArray<ObservedRecord> records, double s) =>
        records.Select(r => r.LogWeight - Discrepancy(r, z) / (s * s))
               .ToImmutableArray();

    static Vec Add(Vec x, Vec y) => x.Zip(y, (p, q) => p + q).ToImmutableArray();

    /// <summary>E_s(z) = -s^2 log sum_i w_i exp(-e_i(z) / s^2).</summary>
    public static double Energy(Vec z, ImmutableArray<ObservedRecord> records,
                                double s)
    {
        var l = Logits(z, records, s);
        double peak = l.Max();
        return -s * s * (peak + Math.Log(l.Sum(v => Math.Exp(v - peak))));
    }

    /// <summary>The read m = z + H^+ (b - H z): H^{-1} b when H is positive
    /// definite, and the token's own value in unresolved directions otherwise.
    /// </summary>
    public static SheafRead Read(Vec z, ImmutableArray<ObservedRecord> records,
                                 double s, double relTol = 1e-10)
    {
        if (z.IsDefaultOrEmpty || records.IsDefaultOrEmpty || !(s > 0))
            throw new ArgumentException("Invalid read input");
        var l = Logits(z, records, s);
        double peak = l.Max();
        var un = l.Select(v => Math.Exp(v - peak)).ToImmutableArray();
        double total = un.Sum();
        var alpha = un.Select(v => v / total).ToImmutableArray();
        int d = z.Length;
        var H = records.Select((r, i) => r.Q.Transpose().Times(r.Q).Scale(alpha[i]))
                       .Aggregate(Matrix.Zero(d), (x, y) => x.Plus(y));
        var b = records
            .Select((r, i) => r.Q.Transpose().Apply(r.Observation)
                .Select(v => alpha[i] * v).ToImmutableArray())
            .Aggregate(ImmutableArray.CreateRange(new double[d]), Add);
        var (values, vectors) = H.SymmetricEigen();
        double cut = relTol * Math.Max(1.0, values.Max());
        var res = b.Zip(H.Apply(z), (p, q) => p - q).ToImmutableArray();
        var coef = Enumerable.Range(0, d)
            .Select(k => values[k] <= cut ? 0.0
                : Enumerable.Range(0, d).Sum(j => vectors[j, k] * res[j])
                  / values[k])
            .ToImmutableArray();
        var m = Enumerable.Range(0, d)
            .Select(j => z[j]
                + Enumerable.Range(0, d).Sum(k => vectors[j, k] * coef[k]))
            .ToImmutableArray();
        return new SheafRead(alpha, H, b, m, values.Min(), values.Min() <= cut);
    }

    /// <summary>Damped step z + lambda (m - z); it lowers E_s
    /// for 0 &lt; lambda &lt; 2.</summary>
    public static Vec Step(Vec z, SheafRead read, double lambda) =>
        z.Zip(read.Value, (p, m) => (1 - lambda) * p + lambda * m)
         .ToImmutableArray();

    /// <summary>Guaranteed decrease lambda (2 - lambda) |z - m|_H^2 / 2.</summary>
    public static double GuaranteedDecrease(Vec z, SheafRead read, double lambda)
    {
        var d = z.Zip(read.Value, (p, m) => p - m).ToImmutableArray();
        double q = d.Zip(read.Normal.Apply(d), (p, h) => p * h).Sum();
        return 0.5 * lambda * (2 - lambda) * q;
    }

    /// <summary>Truncation certificate
    /// R min(1, (W - W_S) exp(-rho^2 / 2 s^2) / D_S).</summary>
    public static double TruncationCertificate(double diameter, double totalWeight,
                                               double starWeight, double starMass,
                                               double rho, double s) =>
        diameter * Math.Min(1.0, (totalWeight - starWeight)
                                 * Math.Exp(-rho * rho / (2 * s * s)) / starMass);
}

public static class SymmetricReads
{
    static double Dist2(Vec a, Vec b) =>
        a.Zip(b, (p, q) => (p - q) * (p - q)).Sum();

    static Vec Mean(Vec logits, ImmutableArray<Vec> points)
    {
        double peak = logits.Max();
        var w = logits.Select(v => Math.Exp(v - peak)).ToImmutableArray();
        return Enumerable.Range(0, points[0].Length)
            .Select(j => Enumerable.Range(0, points.Length)
                .Sum(i => w[i] * points[i][j]) / w.Sum())
            .ToImmutableArray();
    }

    /// <summary>Reads over all group images, and over the nearest image
    /// of each record.</summary>
    public static (Vec All, Vec Nearest) Read(
        Vec z, ImmutableArray<Vec> records, Vec logWeights,
        ImmutableArray<Matrix> group, double s)
    {
        double Logit(int i, Vec x) => logWeights[i] - Dist2(z, x) / (2 * s * s);
        var images = records
            .Select(y => group.Select(g => g.Apply(y)).ToImmutableArray())
            .ToImmutableArray();
        var all = images.SelectMany((im, i) => im.Select(x => (x, l: Logit(i, x))))
                        .ToImmutableArray();
        var near = images.Select(im => im.OrderBy(x => Dist2(z, x)).First())
                         .ToImmutableArray();
        return (Mean(all.Select(p => p.l).ToImmutableArray(),
                     all.Select(p => p.x).ToImmutableArray()),
                Mean(near.Select((x, i) => Logit(i, x)).ToImmutableArray(), near));
    }
}
```

A driver program exercises the kernel on four records in $ℝ^3\text{:}$ a coordinate mask, a single coordinate, a partial isometry with two rows, and one general row. It prints a resolved read with three relaxed steps, an unresolved read at a small scale, both group reads under coordinate reversal, and a truncation certificate. An independent NumPy script recomputes every printed number (Table A1). On the current comparison, 11 of 12 lines are identical to 15 significant digits. The remaining line is the error of a truncated read, a difference of two nearly equal means. Its largest scaled difference is 4.9 × 10⁻¹¹, with denominator $\max(10^{-12},|x|)$ for each NumPy value $x\text{.}$ The C# source caches the weight denominator once; this arithmetic-preserving change has not been freshly compiled here.

Table: **Table A1.** C# kernel output against the NumPy recomputation.

| Output | Scaled error | Identical to 15 digits |
|:------------------|:------------------|:----------|
| `weights` | 0 | yes |
| `read` | 0 | yes |
| `min_eig` | 0 | yes |
| `energy` | 0 | yes |
| `step_0.5` | 0 | yes |
| `step_1` | 0 | yes |
| `step_1.5` | 0 | yes |
| `unresolved` | 0 | yes |
| `read_unresolved` | 0 | yes |
| `image_all` | 0 | yes |
| `image_nearest` | 0 | yes |
| `truncation` | 4.9 × 10⁻¹¹ | no |

# Appendix B: reproducibility

The current Python rerun used Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 and Matplotlib 3.10.8. The supplied archive reported .NET SDK 8.0.131; .NET availability for the current build is recorded as “not installed; supplied output compared”. Original result files are preserved beside the rerun results, and `reproducibility.json` reports their comparison. Cross-environment differences in low-order floating-point digits are retained rather than described as byte-for-byte reproduction. The script `p2_checks.py` runs the twenty main checks with seed 20261020 and writes `p2_checks.json`. The script `p2_extras.py` runs the fourteen supplementary checks with seed 20261021 and writes `p2_extras.json`. The script `fig_p2.py` draws the figures. Panels marked as recomputed use their own fixed seeds; all other plotted values are read from the result files. The C# project in `cs/` contains the kernel and its driver. The supplied C# output was retained; no fresh compilation is claimed when .NET is unavailable. The independent NumPy comparison was rerun, and `cs_validate.py` compares the driver's output with NumPy and writes `cs_validate.json`. The document is assembled by `render.py`, which fills reported register outcomes from these files, converted to Word by Pandoc, and post-processed for equation layout and XML property order. Package structure and native equation presence are checked, and every rendered page is visually inspected; these checks are not a full OOXML schema validation. A code archive accompanies this paper, including the assembled Markdown, source fragments, figures, seeds, result files, focused review checks and build instructions.
