"""Independent regression checks for the mathematical distinctions in the revision."""
from pathlib import Path
import json, math, platform
import numpy as np
from p2_checks import energy

HERE = Path(__file__).parent
out = {}

# Positive operator weights need not yield an ordinary convex combination.
y = np.array([[1., .1], [.1, 1.]])
m = np.array([1., 1.])
out['operator_hull'] = dict(read=m.tolist(), archive_cost=(-y.sum(1)).tolist(),
                            read_cost=float(-m.sum()), outside_hull=bool(m.sum()>y[0].sum()))
assert out['operator_hull']['outside_hull']

# Solve before taking a rank-dropping selection limit, then reverse the order.
betas = [0, 10, 30, 60, 100]
z = np.array([0., -2.])
rows=[]
for beta in betas:
    a2=math.exp(-beta)/(1+math.exp(-beta)); a1=1-a2
    H=np.diag([a1,a2]); b=np.array([a1,7*a2])
    exact=np.linalg.solve(H,b)
    cut=1e-10*max(1.,np.linalg.eigvalsh(H).max())
    filt=z+np.array([(b[j]-H[j,j]*z[j])/H[j,j] if H[j,j]>cut else 0 for j in range(2)])
    rows.append(dict(beta=beta, coverage=a2, exact=exact.tolist(), filtered=filt.tolist()))
    assert np.allclose(exact,[1,7],rtol=0,atol=2e-15)
out['selection_limit']=dict(rows=rows, read_of_limit=[1.,-2.], exact_limit=[1.,7.], gap=9.)

# A filtered fixed point can have a nonzero exact gradient.
H=np.diag([1.,1e-12]); b=np.array([0.,1e-12]); z=np.zeros(2)
out['filtered_fixed_point']=dict(read=z.tolist(), gradient=(H@z-b).tolist(), gradient_norm=float(np.linalg.norm(H@z-b)))
assert out['filtered_fixed_point']['gradient_norm']>0

# Ideal spectral filtering preserves the MM decrease, even for discarded
# positive eigenvalues. Test 300 independent genuinely ill-conditioned stars.
rng=np.random.default_rng(20261022); violations=0; worst_excess=0.; dropped=0
for _ in range(300):
    D=3; n=8; z=rng.normal(size=D)
    Qs=[rng.normal(size=(2,D))*np.array([1.,.2,1e-7]) for _ in range(n)]
    obs=[rng.normal(size=2) for _ in range(n)]; lw=rng.normal(size=n); s=1.
    logits=lw-np.array([np.sum((Q@z-o)**2)/2 for Q,o in zip(Qs,obs)])
    a=np.exp(logits-logits.max());a/=a.sum()
    H=sum(ai*Q.T@Q for ai,Q in zip(a,Qs));b=sum(ai*Q.T@o for ai,Q,o in zip(a,Qs,obs))
    ev,V=np.linalg.eigh(H);cut=1e-10*max(1.,ev.max()); keep=ev>cut
    dropped+=int(np.count_nonzero(~keep))
    d=V[:,keep]@((V[:,keep].T@(b-H@z))/ev[keep])
    lam=float(rng.uniform(.05,1.95));guar=.5*lam*(2-lam)*float(d@H@d)
    excess=energy(z+lam*d,Qs,obs,lw,s)-energy(z,Qs,obs,lw,s)+guar
    worst_excess=max(worst_excess,float(excess));violations+=int(excess>1e-10)
assert violations==0
out['filtered_descent']=dict(trials=300, discarded_directions=dropped, violations=violations, worst_excess=worst_excess)

# A change of physical units must be cancelled before discrepancies form.
x=np.array([1.2,.03]);y=np.array([1.,.05]);sc=np.array([.2,.01])
metric=np.diag(1/sc);change=np.diag([1000.,1.])
e1=np.sum((metric@(x-y))**2)/2
e2=np.sum((metric@np.linalg.inv(change)@(change@x-change@y))**2)/2
assert abs(e1-e2)<1e-13
out['units']=dict(original_energy=float(e1), changed_units_energy=float(e2), absolute_error=float(abs(e1-e2)))

# Collapsing one coordinate yields a singular law, but does not give point atoms.
# An analytic check: (X,Y)->(X,0) for a continuous X has P((X,0)=(a,0))=0.
out['boundary_law']=dict(example='(X,Y) -> (X,0), X continuous', point_atom_mass=0,
                          ambient_lebesgue_singular=True)

# Coincident antipodes contribute their total attention, not just one record.
theta=np.array([0.,0.,1.]);w=np.array([1.,2.,1.]);s=1.
wrap=lambda x:(x+math.pi)%(2*math.pi)-math.pi
def angle_read(t):
    d=wrap(theta-t); a=w*np.exp(-d*d/(2*s*s));a/=a.sum()
    return t+float(a@d)
d=wrap(theta-math.pi);a=w*np.exp(-d*d/2);a/=a.sum()
jump=2*math.pi*float(a[:2].sum())
got=abs(angle_read(math.pi+1e-10)-angle_read(math.pi-1e-10))
assert abs(got-jump)<1e-8
out['coincident_antipodes']=dict(predicted_jump=jump,straddle_jump=got,error=abs(got-jump))

# Canonical representatives agree exactly for orbit-identical points, even
# when the canonical map is discontinuous.
def canon_sign(x): return x if x[0]>=0 else -x
x=np.array([.1,2.]);err=float(np.linalg.norm(canon_sign(x)-canon_sign(-x)))
assert err==0
out['exact_orbit_duplicate']=dict(canonical_distance=err)

json.dump(out,open(HERE/'review_checks.json','w'),indent=2,allow_nan=False)
print(json.dumps({'checks':len(out),'status':'PASS','python':platform.python_version()}))
