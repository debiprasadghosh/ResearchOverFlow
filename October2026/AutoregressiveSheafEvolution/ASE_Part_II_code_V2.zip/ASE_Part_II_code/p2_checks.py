# Numerical checks for ASE Part II, "The Horizontal Layer". Every number quoted in the paper is read from p2_checks.json.
import json, math, os, sys
import numpy as np
from scipy.optimize import linprog

here = os.path.dirname(os.path.abspath(__file__))
rng = np.random.default_rng(20261020)
R = {}


# ---------------------------------------------------------------- sheaf attention primitives
def lse(x):
    m = float(np.max(x))
    return m + math.log(float(np.sum(np.exp(x - m))))


def softmax(x):
    e = np.exp(x - np.max(x))
    return e / e.sum()


def discrepancies(z, Qs, obs):
    return np.array([0.5 * float(np.sum((Q @ z - o) ** 2)) for Q, o in zip(Qs, obs)])


def energy(z, Qs, obs, logw, s):
    """Soft discrepancy energy E_s(z) = -s^2 log sum_i w_i exp(-e_i(z)/s^2)."""
    return -s * s * lse(logw - discrepancies(z, Qs, obs) / (s * s))


def read(z, Qs, obs, logw, s):
    """Sheaf attention: weights, normal matrix H, right side b and the read. When H is numerically singular the read
    keeps the token's own value in the unresolved directions: m = z + H^+ (b - H z)."""
    e = discrepancies(z, Qs, obs)
    a = softmax(logw - e / (s * s))
    H = sum(ai * Q.T @ Q for ai, Q in zip(a, Qs))
    b = sum(ai * Q.T @ o for ai, Q, o in zip(a, Qs, obs))
    ev = np.linalg.eigvalsh(H)
    if ev[0] > 1e-10 * max(1.0, ev[-1]):
        return a, H, b, np.linalg.solve(H, b)
    vals, V = np.linalg.eigh(H)
    keep = vals > 1e-10 * max(1.0, vals[-1])
    return a, H, b, z + V[:, keep] @ ((V[:, keep].T @ (b - H @ z)) / vals[keep])


def random_setup(kind, D=None, n=None, spread=1.5):
    """Records seen through edge maps Q_i with observations o_i = R_i y_i; Σ Q_i^T Q_i is made positive definite."""
    while True:
        D_ = D or int(rng.integers(2, 6)); n_ = n or int(rng.integers(3, 9))
        Qs = []
        for _ in range(n_):
            if kind == "mask":
                k = int(rng.integers(1, D_ + 1)); Q = np.eye(D_)[np.sort(rng.choice(D_, k, replace=False))]
            elif kind == "orth":
                Q = np.linalg.qr(rng.standard_normal((D_, D_)))[0]
            elif kind == "partial":
                k = int(rng.integers(1, D_ + 1)); Q = np.linalg.qr(rng.standard_normal((D_, k)))[0].T
            else:
                k = int(rng.integers(1, D_ + 1)); Q = rng.standard_normal((k, D_)) * rng.uniform(0.5, 1.5)
            Qs.append(Q)
        if np.linalg.eigvalsh(sum(Q.T @ Q for Q in Qs)).min() > 1e-3:
            obs = [spread * rng.standard_normal(Q.shape[0]) for Q in Qs]
            return D_, Qs, obs, rng.normal(0.0, 0.5, n_)


# ---------------------------------------------------------------- 1. harmonic extension on the observation star
def check_harmonic_extension():
    err_schur = err_min = 0.0; worse = 0; trials = 300
    for _ in range(trials):
        D, Qs, _, _ = random_setup("general")
        n = len(Qs); c = rng.uniform(0.2, 2.0, n)
        dims = [int(rng.integers(1, 4)) for _ in range(n)]
        Rs = [rng.standard_normal((Q.shape[0], d)) for Q, d in zip(Qs, dims)]
        ys = [rng.standard_normal(d) for d in dims]
        G = sum(ci * Q.T @ Q for ci, Q in zip(c, Qs))
        m = np.linalg.solve(G, sum(ci * Q.T @ Rr @ y for ci, Q, Rr, y in zip(c, Qs, Rs, ys)))
        # star sheaf: token vertex, one leaf per record, edge stalks; (delta x)_e = R_i x_leaf - Q_i x_token
        off = np.concatenate([[0, D], D + np.cumsum(dims)])
        rows = []
        for i, (Q, Rr) in enumerate(zip(Qs, Rs)):
            blk = np.zeros((Q.shape[0], off[-1])); blk[:, :D] = -Q; blk[:, off[i + 1]:off[i + 2]] = Rr
            rows.append(np.sqrt(c[i]) * blk)
        d = np.vstack(rows); L = d.T @ d
        yb = np.concatenate(ys)
        xo = -np.linalg.solve(L[:D, :D], L[:D, D:] @ yb)
        err_schur = max(err_schur, float(np.abs(xo - m).max()))
        f = lambda x: sum(ci * float(np.sum((Q @ x - Rr @ y) ** 2)) for ci, Q, Rr, y in zip(c, Qs, Rs, ys))
        fm = f(m)
        for _ in range(50):
            worse += f(m + 1e-3 * rng.standard_normal(D)) < fm - 1e-12
        err_min = max(err_min, abs(fm - f(m)))
    R["harmonic_extension"] = dict(trials=trials, schur_max_err=err_schur, perturbations=trials * 50, better_found=worse)


# ---------------------------------------------------------------- 2. matrix weights and lift invariance
def check_matrix_weights():
    sum_err = read_err = lift_err = 0.0; min_eig = 1.0; trials = 300
    for _ in range(trials):
        D, Qs, _, _ = random_setup("general")
        n = len(Qs); c = rng.uniform(0.2, 2.0, n)
        vs = [rng.standard_normal(D) for _ in range(n)]
        obs = [Q @ v for Q, v in zip(Qs, vs)]
        G = sum(ci * Q.T @ Q for ci, Q in zip(c, Qs))
        Gi = np.linalg.inv(G)
        A = [Gi @ (ci * Q.T @ Q) for ci, Q in zip(c, Qs)]
        m = np.linalg.solve(G, sum(ci * Q.T @ o for ci, Q, o in zip(c, Qs, obs)))
        sum_err = max(sum_err, float(np.abs(sum(A) - np.eye(D)).max()))
        read_err = max(read_err, float(np.abs(sum(Ai @ v for Ai, v in zip(A, vs)) - m).max()))
        # lifts: add null-space components to every v_i; the read is unchanged
        vs2 = []
        for Q, v in zip(Qs, vs):
            _, sv, vt = np.linalg.svd(Q); r = int((sv > 1e-10).sum())
            N = vt[r:].T
            vs2.append(v + (N @ rng.standard_normal(N.shape[1]) if N.shape[1] else 0.0))
        lift_err = max(lift_err, float(np.abs(sum(Ai @ v for Ai, v in zip(A, vs2)) - m).max()))
        w, U = np.linalg.eigh(G); Gh = U @ np.diag(w ** 0.5) @ U.T; Ghi = U @ np.diag(w ** -0.5) @ U.T
        for Ai in A:
            min_eig = min(min_eig, float(np.linalg.eigvalsh((Gh @ Ai @ Ghi + (Gh @ Ai @ Ghi).T) / 2).min()))
    R["matrix_weights"] = dict(trials=trials, sum_to_identity_err=sum_err, read_err=read_err, lift_invariance_err=lift_err,
                               min_eig_symmetrised=min_eig)


# ---------------------------------------------------------------- 3. transported hull, coordinate box, crossover
def in_hull(pts, x):
    n = len(pts)
    res = linprog(np.zeros(n), A_eq=np.vstack([np.array(pts).T, np.ones(n)]), b_eq=np.append(x, 1.0),
                  bounds=[(0, None)] * n, method="highs")
    return res.status == 0


def check_hulls():
    hull_err = 0.0
    for _ in range(200):
        D, Qs, obs, logw = random_setup("orth")
        z = rng.standard_normal(D); s = float(rng.uniform(0.5, 3.0))
        a, H, b, m = read(z, Qs, obs, logw, s)
        v = [Q.T @ o for Q, o in zip(Qs, obs)]
        hull_err = max(hull_err, float(np.abs(m - sum(ai * vi for ai, vi in zip(a, v))).max()))
    outside = box_viol = box_skipped = box_cases = 0; trials = 400
    for _ in range(trials):
        D, n = 4, 6
        while True:
            masks = [np.sort(rng.choice(D, int(rng.integers(1, D)), replace=False)) for _ in range(n)]
            if len(set(np.concatenate(masks))) == D:
                break
        Qs = [np.eye(D)[S] for S in masks]
        ys = [rng.standard_normal(D) for _ in range(n)]
        obs = [Q @ y for Q, y in zip(Qs, ys)]
        z = rng.standard_normal(D); s = float(rng.uniform(0.5, 3.0)); logw = rng.normal(0, 0.5, n)
        a, H, b, m = read(z, Qs, obs, logw, s)
        cover = [sum(a[i] for i in range(n) if j in masks[i]) for j in range(D)]
        if min(cover) < 1e-8:
            box_skipped += 1
            continue
        for j in range(D):
            vals = [ys[i][j] for i in range(n) if j in masks[i]]
            box_viol += not (min(vals) - 1e-12 <= m[j] <= max(vals) + 1e-12)
        outside += not in_hull(ys, m); box_cases += 1
    cross = 0; ctrials = 300
    for _ in range(ctrials):
        D = int(rng.integers(2, 7)); S = np.sort(rng.choice(D, int(rng.integers(1, D)), replace=False))
        Sc = np.setdiff1d(np.arange(D), S)
        y1, y2 = rng.standard_normal(D), rng.standard_normal(D)
        m = np.empty(D); m[S] = y1[S]; m[Sc] = y2[Sc]
        cross += not in_hull([y1, y2], m)
    R["hulls"] = dict(orth_cases=200, orth_convex_err=hull_err, mask_cases=box_cases, mask_skipped=box_skipped,
                      box_violations=box_viol,
                      outside_hull=outside, crossover_cases=ctrials, crossover_outside=cross)


# ---------------------------------------------------------------- 4. conditioning: principal angles and coverage
def check_conditioning():
    lo_viol = hi_viol = interior = spanning = 0; trials = 500; ratios = []
    for _ in range(trials):
        D = int(rng.integers(2, 7))
        k1 = int(rng.integers(1, D + 1)); k2 = int(rng.integers(max(1, D - k1), D + 1))
        U1 = np.linalg.qr(rng.standard_normal((D, k1)))[0]; U2 = np.linalg.qr(rng.standard_normal((D, k2)))[0]
        if rng.random() < 0.3 and k1 >= 1 and k2 >= 1:          # force a shared direction now and then
            U2[:, 0] = U1[:, 0]; U2 = np.linalg.qr(U2)[0]
        c1, c2 = rng.uniform(0.1, 3.0, 2)
        H = c1 * U1 @ U1.T + c2 * U2 @ U2.T
        lam = float(np.linalg.eigvalsh(H).min())
        if lam < 1e-9:
            continue                                            # the subspaces do not span
        spanning += 1
        cos = np.clip(np.linalg.svd(U1.T @ U2, compute_uv=False), 0, 1)
        nonzero = [math.acos(cv) for cv in cos if cv < 1 - 1e-9]
        thF = min(nonzero) if nonzero else math.pi / 2
        h = 2 * c1 * c2 / (c1 + c2)
        lo_viol += lam < 0.5 * h * math.sin(thF) ** 2 - 1e-12
        if thF < math.pi / 2 - 1e-9:
            interior += 1; hi_viol += lam > h * math.sin(thF) ** 2 + 1e-12
            ratios.append(lam / (h * math.sin(thF) ** 2))
    amp_viol = 0; atrials = 400; worst = 0.0
    for _ in range(atrials):
        D, Qs, _, _ = random_setup("general")
        c = rng.uniform(0.2, 2.0, len(Qs)); H = sum(ci * Q.T @ Q for ci, Q in zip(c, Qs))
        lmin = float(np.linalg.eigvalsh(H).min()); Hi = np.linalg.inv(H)
        for ci, Q in zip(c, Qs):
            r = np.linalg.norm(Hi @ (ci * Q.T), 2) / math.sqrt(ci / lmin)
            worst = max(worst, r); amp_viol += r > 1 + 1e-10
    cov_err = 0.0
    for _ in range(300):
        D, Qs, obs, logw = random_setup("mask")
        z = rng.standard_normal(D); s = float(rng.uniform(0.5, 3.0))
        a, H, b, m = read(z, Qs, obs, logw, s)
        cover = [sum(ai for ai, Q in zip(a, Qs) if Q[:, j].any()) for j in range(D)]
        cov_err = max(cov_err, abs(float(np.linalg.eigvalsh(H).min()) - min(cover)))
    # two lines in the plane: exact displacement of the read when one record moves by one unit
    lines = []
    for th in [math.pi / 2, math.pi / 4, math.pi / 8, math.pi / 16, math.pi / 32]:
        n1, n2 = np.array([1.0, 0.0]), np.array([math.cos(th), math.sin(th)])
        H = np.outer(n1, n1) + np.outer(n2, n2)
        disp = float(np.linalg.norm(np.linalg.solve(H, n1)))
        lines.append(dict(theta=th, displacement=disp, inverse_sine=1 / math.sin(th),
                          bound=math.sqrt(1 / float(np.linalg.eigvalsh(H).min()))))
    R["conditioning"] = dict(angle_trials=spanning, interior_angle_trials=interior, lower_violations=lo_viol,
                             upper_violations=hi_viol,
                             ratio_min=float(min(ratios)), ratio_max=float(max(ratios)),
                             amplification_trials=atrials, amplification_violations=amp_viol, amplification_worst=worst,
                             coverage_cases=300, coverage_err=cov_err, two_lines=lines)


# ---------------------------------------------------------------- 5. residual at the read equals the posterior trace
def check_residual_trace():
    err = 0.0
    for _ in range(300):
        D, Qs, obs, logw = random_setup("orth")
        z = rng.standard_normal(D); s = float(rng.uniform(0.5, 3.0))
        a, H, b, m = read(z, Qs, obs, logw, s)
        v = np.array([Q.T @ o for Q, o in zip(Qs, obs)])
        res = sum(ai * float(np.sum((Q @ m - o) ** 2)) for ai, Q, o in zip(a, Qs, obs))
        C = (a[:, None] * (v - m)).T @ (v - m)
        err = max(err, abs(res - float(np.trace(C))))
    R["residual_trace"] = dict(cases=300, max_err=err)


# ---------------------------------------------------------------- 6. majorise-minimise descent (sheaf mean shift)
def check_mm():
    viol = 0; trials = 3000; worst = math.inf; over_increase = over_trials = 0
    for t in range(trials):
        kind = ["general", "mask", "partial", "orth"][t % 4]
        D, Qs, obs, logw = random_setup(kind)
        z = 2.0 * rng.standard_normal(D); s = float(rng.uniform(0.3, 3.0))
        a, H, b, m = read(z, Qs, obs, logw, s)
        E0 = energy(z, Qs, obs, logw, s); d = z - m; q = float(d @ H @ d)
        lam = float(rng.uniform(0.0, 2.0))
        E1 = energy(z + lam * (m - z), Qs, obs, logw, s)
        guaranteed = 0.5 * lam * (2 - lam) * q
        viol += E1 > E0 - guaranteed + 1e-10 * (1 + abs(E0))
        if guaranteed > 1e-9:
            worst = min(worst, (E0 - E1) / guaranteed)
        lam2 = float(rng.uniform(2.05, 3.0))
        if q > 1e-6:
            over_trials += 1
            over_increase += energy(z + lam2 * (m - z), Qs, obs, logw, s) > E0
    # iterate the full read from random starts
    runs = []
    for _ in range(40):
        D, Qs, obs, logw = random_setup(["general", "mask", "partial"][len(runs) % 3])
        s = float(rng.uniform(0.5, 2.0)); z = 3.0 * rng.standard_normal(D)
        Es = [energy(z, Qs, obs, logw, s)]
        for _ in range(400):
            z = read(z, Qs, obs, logw, s)[3]; Es.append(energy(z, Qs, obs, logw, s))
        a, H, b, m = read(z, Qs, obs, logw, s)
        runs.append(dict(monotone=bool(all(Es[k + 1] <= Es[k] + 1e-12 for k in range(len(Es) - 1))),
                         grad_norm=float(np.linalg.norm(H @ z - b)),
                         singular=bool(np.linalg.eigvalsh(H).min() < 1e-8 * max(1.0, np.linalg.eigvalsh(H).max()))))
    R["mm"] = dict(trials=trials, violations=viol, worst_ratio=worst, over_two_trials=over_trials,
                   over_two_increases=over_increase, runs=len(runs), runs_monotone=sum(r["monotone"] for r in runs),
                   max_final_grad=max(r["grad_norm"] for r in runs), runs_singular=sum(r["singular"] for r in runs))


# ---------------------------------------------------------------- 7. soft-energy gradient and Tweedie in a stalk
def check_gradient_tweedie():
    gerr = 0.0
    for t in range(300):
        D, Qs, obs, logw = random_setup(["general", "mask", "partial"][t % 3])
        z = rng.standard_normal(D); s = float(rng.uniform(0.5, 3.0))
        a, H, b, m = read(z, Qs, obs, logw, s)
        h = 1e-5; g = np.array([(energy(z + h * e, Qs, obs, logw, s) - energy(z - h * e, Qs, obs, logw, s)) / (2 * h)
                                for e in np.eye(D)])
        gerr = max(gerr, float(np.abs(g - H @ (z - m)).max() / (1 + np.abs(g).max())))
    terr = 0.0
    for _ in range(200):
        D, Qs, obs, logw = random_setup("orth")
        z = rng.standard_normal(D); s = float(rng.uniform(0.5, 3.0))
        a, H, b, m = read(z, Qs, obs, logw, s)
        v = [Q.T @ o for Q, o in zip(Qs, obs)]
        logp = lambda x: lse(logw - np.array([float(np.sum((x - vi) ** 2)) for vi in v]) / (2 * s * s))
        h = 1e-5; gl = np.array([(logp(z + h * e) - logp(z - h * e)) / (2 * h) for e in np.eye(D)])
        terr = max(terr, float(np.abs(z + s * s * gl - m).max()))
    R["gradient_tweedie"] = dict(gradient_cases=300, gradient_rel_err=gerr, tweedie_cases=200, tweedie_err=terr)


# ---------------------------------------------------------------- 8. exact recovery of the ADE update
def check_ade_recovery():
    err = 0.0
    for _ in range(100):
        D, n = int(rng.integers(1, 6)), int(rng.integers(2, 12))
        ys = rng.standard_normal((n, D)) * 2; logw = rng.normal(0, 1, n)
        a_t = float(rng.uniform(0.05, 0.9)); a_p = float(rng.uniform(a_t, 0.99)); eta = float(rng.uniform(0, 1))
        sig2 = eta ** 2 * (1 - a_p) / (1 - a_t) * (1 - a_t / a_p)
        A = math.sqrt(max(0.0, 1 - a_p - sig2) / (1 - a_t)); B = math.sqrt(a_p) - A * math.sqrt(a_t)
        q = rng.standard_normal(D); xi = rng.standard_normal(D)
        l = logw - np.sum((q - math.sqrt(a_t) * ys) ** 2, 1) / (2 * (1 - a_t)); mq = softmax(l) @ ys
        q_next = A * q + B * mq + math.sqrt(sig2) * xi
        s = math.sqrt((1 - a_t) / a_t); z = q / math.sqrt(a_t)
        _, _, _, m = read(z, [np.eye(D)] * n, list(ys), logw, s)
        lam = 1 - A * math.sqrt(a_t / a_p)
        z_next = (1 - lam) * z + lam * m + math.sqrt(sig2) * xi / math.sqrt(a_p)
        err = max(err, float(np.abs(z_next - q_next / math.sqrt(a_p)).max()))
    R["ade_recovery"] = dict(cases=100, max_err=err)


# ---------------------------------------------------------------- 9. imputation mixture versus product of experts
def check_imputation():
    e1 = e2 = 0.0; diff = []; well = 0
    for _ in range(300):
        D, Qs, obs, logw = random_setup(["mask", "partial"][len(diff) % 2])
        z = rng.standard_normal(D); s = float(rng.uniform(0.5, 3.0))
        a, H, b, m = read(z, Qs, obs, logw, s)
        mA = sum(ai * (Q.T @ o + (np.eye(D) - Q.T @ Q) @ z) for ai, Q, o in zip(a, Qs, obs))
        grad = H @ (z - m)
        e1 = max(e1, float(np.abs(mA - (z - grad)).max()))
        if np.linalg.cond(H) < 1e8:
            e2 = max(e2, float(np.abs((m - z) - np.linalg.solve(H, mA - z)).max())); well += 1
        diff.append(float(np.linalg.norm(mA - m)))
    R["imputation"] = dict(cases=300, gradient_identity_err=e1, well_conditioned=well, preconditioning_identity_err=e2,
                           median_gap=float(np.median(diff)))


# ---------------------------------------------------------------- 10. proper and improper local laws
def check_properness():
    s = 1.0; out = {}
    for name, Q, o in [("full record", np.eye(2), np.zeros(2)), ("partial record", np.array([[1.0, 0.0]]), np.zeros(1))]:
        masses = []
        for L in [5, 10, 20, 40]:
            g = np.linspace(-L, L, 801); X, Y = np.meshgrid(g, g); P = np.stack([X.ravel(), Y.ravel()], 1)
            val = np.exp(-np.sum((P @ Q.T - o) ** 2, 1) / (2 * s * s))
            masses.append(float(val.sum() * (g[1] - g[0]) ** 2))
        out[name] = masses
    Hcov = 0.5 * np.diag([1.0, 0.0]) + 0.5 * np.diag([0.0, 1.0]); Hsame = np.diag([1.0, 0.0])
    R["properness"] = dict(box_half_widths=[5, 10, 20, 40], mixture_masses=out,
                           product_min_eig_covering=float(np.linalg.eigvalsh(Hcov).min()),
                           product_min_eig_same_coordinate=float(np.linalg.eigvalsh(Hsame).min()))


# ---------------------------------------------------------------- 11. tilting collapses coverage
def check_tilt_coverage():
    D, n, s = 4, 12, 1.5
    masks = [np.sort(rng.choice(D, int(rng.integers(1, D)), replace=False)) for _ in range(n)]
    masks[0] = np.array([0, 1])                                  # the elite observes two of four coordinates
    ys = [rng.standard_normal(D) for _ in range(n)]
    J = rng.uniform(1.0, 3.0, n); J[0] = 0.0
    z = rng.standard_normal(D) * 0.5; logw0 = np.zeros(n)
    betas = [0, 1, 3, 10, 30, 100]
    out = {}
    for name, elite_mask in [("elite partial", np.array([0, 1])), ("elite full", np.arange(D))]:
        mk = list(masks); mk[0] = elite_mask
        Qs = [np.eye(D)[S] for S in mk]
        if len(set(np.concatenate(mk))) < D:
            Qs.append(np.eye(D)); ys.append(rng.standard_normal(D))
        obs = [Q @ y for Q, y in zip(Qs, ys)]
        lam = []
        for beta in betas:
            Jall = np.append(J, [3.0] * (len(Qs) - n))
            a, H, b, m = read(z, Qs, obs, np.zeros(len(Qs)) - beta * Jall, s)
            lam.append(float(np.linalg.eigvalsh(H).min()))
        out[name] = lam
    R["tilt_coverage"] = dict(betas=betas, min_eig=out)


# ---------------------------------------------------------------- 12. bounded measurement error
def check_measurement():
    tv_viol = read_viol = rect_viol = 0; worst_tv = worst_read = worst_rect = 0.0; trials = 2000
    for t in range(trials):
        n = int(rng.integers(2, 12)); alpha = softmax(rng.normal(0, 2, n))
        beta, eps = float(rng.uniform(0.1, 10)), float(rng.uniform(0.01, 1.0))
        dJ = rng.uniform(-eps, eps, n) if t % 2 else eps * rng.choice([-1.0, 1.0], n)
        alpha2 = alpha * np.exp(-beta * dJ); alpha2 /= alpha2.sum()
        tv = 0.5 * float(np.abs(alpha - alpha2).sum()); bound = math.tanh(beta * eps / 2)
        worst_tv = max(worst_tv, tv / bound); tv_viol += tv > bound + 1e-12
        v = rng.standard_normal((n, 3)); diam = max(np.linalg.norm(v[i] - v[j]) for i in range(n) for j in range(n))
        err = float(np.linalg.norm((alpha - alpha2) @ v))
        if diam * bound > 1e-9:
            worst_read = max(worst_read, err / (diam * bound))
        read_viol += err > diam * bound + 1e-12
    for _ in range(600):
        D, Qs, obs, logw = random_setup(["general", "mask", "partial"][_ % 3])
        z = rng.standard_normal(D); s = float(rng.uniform(0.5, 3.0))
        a, H, b, m = read(z, Qs, obs, logw, s)
        beta, eps = float(rng.uniform(0.1, 10)), float(rng.uniform(0.01, 1.0))
        a2 = a * np.exp(-beta * rng.uniform(-eps, eps, len(a))); a2 /= a2.sum()
        H2 = sum(ai * Q.T @ Q for ai, Q in zip(a2, Qs)); b2 = sum(ai * Q.T @ o for ai, Q, o in zip(a2, Qs, obs))
        m2 = np.linalg.solve(H2, b2)
        g = [Q.T @ (Q @ m - o) for Q, o in zip(Qs, obs)]
        diam = max(np.linalg.norm(g[i] - g[j]) for i in range(len(g)) for j in range(len(g)))
        tv = 0.5 * float(np.abs(a - a2).sum())
        bound = tv * diam / float(np.linalg.eigvalsh(H2).min())
        err = float(np.linalg.norm(m2 - m))
        if bound > 1e-9:
            worst_rect = max(worst_rect, err / bound)
        rect_viol += err > bound + 1e-12
    # the two-point worst case attains the bound
    beta, eps, p = 2.0, 0.7, 1 / (1 + math.exp(2.0 * 0.7))
    alpha = np.array([p, 1 - p]); alpha2 = alpha * np.exp(-beta * np.array([-eps, eps])); alpha2 /= alpha2.sum()
    R["measurement"] = dict(trials=trials, tv_violations=tv_viol, tv_worst_ratio=worst_tv, read_violations=read_viol,
                            read_worst_ratio=worst_read, rect_trials=600, rect_violations=rect_viol,
                            rect_worst_ratio=worst_rect, two_point_tv=0.5 * float(np.abs(alpha - alpha2).sum()),
                            two_point_bound=math.tanh(beta * eps / 2))


# ---------------------------------------------------------------- 13. truncation: bound, certificate and certified radius
def check_truncation():
    Y = rng.uniform(0, 10, (400, 2)); w = rng.uniform(0.5, 1.5, 400); Wtot = float(w.sum())
    diam = max(float(np.linalg.norm(Y[i] - Y[j])) for i in range(400) for j in range(i + 1, 400))
    rows, viol, cert_viol = [], 0, 0
    for s in [0.1, 0.3, 1.0]:
        for c in [2.0, 3.0, 4.0]:
            rho = c * s; ratios, shares, certs = [], [], []
            for _ in range(60):
                z = rng.uniform(0, 10, 2)
                d2 = np.sum((Y - z) ** 2, 1); k = w * np.exp(-d2 / (2 * s * s))
                S = d2 <= rho * rho
                if not S.any():
                    continue
                m = k @ Y / k.sum(); mS = k[S] @ Y[S] / k[S].sum()
                DS, DF, WF = float(k[S].sum()), float(k[~S].sum()), float(w[~S].sum())
                bound = diam * DF / (DS + DF)
                cert = diam * min(1.0, (Wtot - float(w[S].sum())) / DS * math.exp(-rho * rho / (2 * s * s)))
                err = float(np.linalg.norm(m - mS))
                viol += err > bound + 1e-12; cert_viol += err > cert + 1e-12
                ratios.append(err / bound if bound > 0 else 0.0); shares.append(float(S.mean())); certs.append(cert / diam)
            rows.append(dict(s=s, c=c, attempted=60, tested=len(shares), empty_star=60-len(shares), share=float(np.mean(shares)), max_ratio=float(max(ratios)),
                             median_cert=float(np.median(certs))))
    # certified radius for a tolerance eta: smallest rho/s on a grid with certificate <= eta * diameter
    eta, cr = 1e-3, []
    for s in [0.1, 0.3, 1.0]:
        shares, cs = [], []
        for _ in range(60):
            z = rng.uniform(0, 10, 2); d2 = np.sum((Y - z) ** 2, 1); k = w * np.exp(-d2 / (2 * s * s))
            for c in np.arange(1.0, 8.01, 0.25):
                S = d2 <= (c * s) ** 2
                if S.any() and (Wtot - float(w[S].sum())) / float(k[S].sum()) * math.exp(-c * c / 2) <= eta:
                    m = k @ Y / k.sum(); mS = k[S] @ Y[S] / k[S].sum()
                    assert np.linalg.norm(m - mS) <= eta * diam + 1e-12
                    shares.append(float(S.mean())); cs.append(float(c)); break
        cr.append(dict(s=s, attempted=60, certified=len(cs), uncertified=60-len(cs), median_c=float(np.median(cs)), mean_share=float(np.mean(shares))))
    R["truncation"] = dict(records=400, diameter=diam, rows=rows, violations=viol, certificate_violations=cert_viol,
                           eta=eta, certified=cr)


def check_rect_truncation():
    viol = 0; worst = 0.0; trials = 400
    for t in range(trials):
        D, Qs, obs, logw = random_setup(["general", "mask", "partial"][t % 3], n=30)
        z = rng.standard_normal(D); s = float(rng.uniform(0.5, 2.0))
        a, H, b, m = read(z, Qs, obs, logw, s)
        idx = np.argsort(-a)[:12]
        aS = np.zeros_like(a); aS[idx] = a[idx]; aS /= aS.sum()
        HS = sum(ai * Q.T @ Q for ai, Q in zip(aS, Qs)); bS = sum(ai * Q.T @ o for ai, Q, o in zip(aS, Qs, obs))
        if np.linalg.eigvalsh(HS).min() < 1e-8:
            continue
        mS = np.linalg.solve(HS, bS)
        bound = (np.linalg.norm(b - bS) + np.linalg.norm(H - HS, 2) * np.linalg.norm(mS)) / np.linalg.eigvalsh(H).min()
        err = float(np.linalg.norm(m - mS)); worst = max(worst, err / bound); viol += err > bound + 1e-12
    R["rect_truncation"] = dict(trials=trials, violations=viol, worst_ratio=worst)


# ---------------------------------------------------------------- 14. the Jacobian of sheaf attention
def jacobian_formula(z, Qs, obs, logw, s):
    a, H, b, m = read(z, Qs, obs, logw, s)
    g = [Q.T @ (Q @ z - o) for Q, o in zip(Qs, obs)]; gbar = sum(ai * gi for ai, gi in zip(a, g))
    M = sum(ai * np.outer(Q.T @ (Q @ m - o), gi - gbar) for ai, Q, o, gi in zip(a, Qs, obs, g))
    return np.linalg.solve(H, M) / (s * s), a, H, m


def check_jacobian():
    err = orth_err = stat_err = 0.0; excluded = 0; errs = []
    for t in range(300):
        D, Qs, obs, logw = random_setup(["general", "mask", "partial"][t % 3])
        z = rng.standard_normal(D); s = float(rng.uniform(0.7, 3.0))
        J, a, H, m = jacobian_formula(z, Qs, obs, logw, s)
        if np.linalg.cond(H) > 1e6:
            excluded += 1
            continue
        h = 1e-6
        Jfd = np.column_stack([(read(z + h * e, Qs, obs, logw, s)[3] - read(z - h * e, Qs, obs, logw, s)[3]) / (2 * h)
                               for e in np.eye(D)])
        errs.append(float(np.abs(J - Jfd).max() / (1 + np.abs(Jfd).max()))); err = max(err, errs[-1])
    for _ in range(200):
        D, Qs, obs, logw = random_setup("orth")
        z = rng.standard_normal(D); s = float(rng.uniform(0.5, 3.0))
        J, a, H, m = jacobian_formula(z, Qs, obs, logw, s)
        v = np.array([Q.T @ o for Q, o in zip(Qs, obs)]); C = (a[:, None] * (v - m)).T @ (v - m)
        orth_err = max(orth_err, float(np.abs(J - C / (s * s)).max()))
    nstat = 0
    for t in range(60):
        D, Qs, obs, logw = random_setup(["general", "mask", "partial"][t % 3])
        s = float(rng.uniform(0.7, 2.0)); z = rng.standard_normal(D)
        for _ in range(3000):
            z = read(z, Qs, obs, logw, s)[3]
        if np.linalg.eigvalsh(read(z, Qs, obs, logw, s)[1]).min() < 1e-6:
            continue
        J, a, H, m = jacobian_formula(z, Qs, obs, logw, s)
        Cr = sum(ai * np.outer(Q.T @ (Q @ m - o), Q.T @ (Q @ m - o)) for ai, Q, o in zip(a, Qs, obs))
        stat_err = max(stat_err, float(np.abs(J - np.linalg.solve(H, Cr) / (s * s)).max())); nstat += 1
    R["jacobian"] = dict(cases=300 - excluded, excluded_ill_conditioned=excluded, fd_rel_err=err,
                         fd_rel_err_median=float(np.median(errs)), orth_cases=200, orth_err=orth_err, stationary_cases=nstat,
                         stationary_err=stat_err)


# ---------------------------------------------------------------- 15. branches: purity and gap landing
def check_branches():
    sufficient = landed = 0; total = 0; in_gap_any = 0; purity_viol = 0
    for _ in range(4000):
        g, w = float(rng.uniform(0.5, 3.0)), float(rng.uniform(0.05, 0.4))
        n1, n2 = int(rng.integers(2, 8)), int(rng.integers(2, 8))
        y1 = rng.uniform(-w, 0, n1); y2 = rng.uniform(g, g + w, n2)
        ys = np.concatenate([y1, y2]); logw = rng.normal(0, 0.5, n1 + n2)
        s = float(rng.choice([0.2, 0.5, 1.0, 2.0])); z = float(rng.uniform(-w - 0.5, g + w + 0.5))
        lg = logw - (z - ys) ** 2 / (2 * s * s); a = softmax(lg)
        m = float(a @ ys); pi2 = float(a[n1:].sum())
        m1 = float(a[:n1] @ y1 / a[:n1].sum()); m2 = float(a[n1:] @ y2 / a[n1:].sum())
        purity_viol += not (-w <= m1 <= 0 and g <= m2 <= g + w)
        total += 1; gap = 0 < m < g; in_gap_any += gap
        if w / (g + w) < pi2 < g / (g + w):
            sufficient += 1; landed += gap
    R["branches"] = dict(cases=total, condition_met=sufficient, landed_in_gap=landed, shared_in_gap=in_gap_any,
                         purity_violations=purity_viol)


# ---------------------------------------------------------------- 16. nearest-image reads for finite symmetry groups
def dihedral(k):
    G = []
    for j in range(k):
        c, s_ = math.cos(2 * math.pi * j / k), math.sin(2 * math.pi * j / k)
        Rm = np.array([[c, -s_], [s_, c]]); G.append(Rm); G.append(Rm @ np.diag([1.0, -1.0]))
    return G


def image_reads(z, ys, logw, G, s):
    imgs = np.array([[g @ y for g in G] for y in ys])                      # n x |G| x D
    d2 = np.sum((imgs - z) ** 2, 2)
    lg_all = logw[:, None] - d2 / (2 * s * s)
    a_all = softmax(lg_all.ravel()).reshape(d2.shape)
    m_all = np.einsum("ig,igd->d", a_all, imgs)
    best = d2.argmin(1)
    near = imgs[np.arange(len(ys)), best]
    a_near = softmax(logw - d2[np.arange(len(ys)), best] / (2 * s * s))
    m_near = a_near @ near
    srt = np.sort(d2, 1); gap2 = float((srt[:, 1] - srt[:, 0]).min()) if d2.shape[1] > 1 else math.inf
    return m_all, m_near, gap2


def check_nearest_image():
    out = {}
    groups = {"sign flips in R^6": [np.eye(6), -np.eye(6)],
              "mirror reversal in R^6": [np.eye(6), np.eye(6)[::-1]],
              "dihedral group of order 12 in R^2": dihedral(6)}
    for name, G in groups.items():
        D = G[0].shape[0]; viol = 0; worst = 0.0; eq_all = eq_near = 0.0; trials = 500
        for _ in range(trials):
            n = int(rng.integers(3, 10)); ys = rng.standard_normal((n, D)); logw = rng.normal(0, 0.5, n)
            z = rng.standard_normal(D); s = float(rng.uniform(0.2, 1.5))
            m_all, m_near, gap2 = image_reads(z, ys, logw, G, s)
            q = math.exp(-gap2 / (2 * s * s)); k = len(G) - 1
            eps = k * q / (1 + k * q); bound = 2 * eps * float(np.linalg.norm(ys, axis=1).max())
            err = float(np.linalg.norm(m_all - m_near)); viol += err > bound + 1e-12
            if bound > 1e-9:
                worst = max(worst, err / bound)
            g = G[int(rng.integers(len(G)))]
            ma2, mn2, _ = image_reads(g @ z, ys, logw, G, s)
            eq_all = max(eq_all, float(np.abs(ma2 - g @ m_all).max()))
            if gap2 > 1e-6:
                eq_near = max(eq_near, float(np.abs(mn2 - g @ m_near).max()))
        out[name] = dict(order=len(G), trials=trials, violations=viol, worst_ratio=worst,
                         equivariance_all=eq_all, equivariance_near=eq_near)
    R["nearest_image"] = out


def check_sign_example():
    D, n = 6, 50
    u = rng.standard_normal(D); u /= np.linalg.norm(u)
    Y = np.array([(u + 0.25 * rng.standard_normal(D)) for _ in range(n)])
    Y /= np.linalg.norm(Y, axis=1)[:, None]; Y *= rng.choice([-1.0, 1.0], n)[:, None]
    z = u + 0.3 * rng.standard_normal(D) / math.sqrt(D)
    rows = []
    for s in [0.5, 2.0]:
        raw = softmax(-np.sum((z - Y) ** 2, 1) / (2 * s * s)) @ Y
        Ya = Y * np.sign(Y @ z)[:, None]
        al = softmax(-np.sum((z - Ya) ** 2, 1) / (2 * s * s)) @ Ya
        cosine = lambda v: float(abs(v @ u) / np.linalg.norm(v))
        rows.append(dict(s=s, raw_norm=float(np.linalg.norm(raw)), raw_cos=cosine(raw),
                         aligned_norm=float(np.linalg.norm(al)), aligned_cos=cosine(al)))
    R["sign_example"] = rows


# ---------------------------------------------------------------- 17. angles: nearest lift and antipodal jumps
def wrap(x):
    return (x + math.pi) % (2 * math.pi) - math.pi


def check_angles():
    viol = 0; worst = 0.0; trials = 0
    for _ in range(600):
        s = float(rng.uniform(0.3, 2.5)); delta = float(rng.uniform(0.2, 1.5)); n = int(rng.integers(2, 12))
        d = rng.uniform(-(math.pi - delta), math.pi - delta, n); logw = rng.normal(0, 0.5, n)
        q = math.exp(-2 * math.pi * delta / s ** 2)
        if q >= 0.5:
            continue
        ks = np.arange(-30, 31)
        lifts = d[:, None] + 2 * math.pi * ks[None, :]
        lg = logw[:, None] - lifts ** 2 / (2 * s * s)
        m_all = float(softmax(lg.ravel()) @ lifts.ravel())
        m_near = float(softmax(logw - d ** 2 / (2 * s * s)) @ d)
        bound = 4 * math.pi * q * (2 - q) / (1 - q) ** 2
        err = abs(m_all - m_near); trials += 1
        viol += err > bound + 1e-12
        if bound > 1e-9:
            worst = max(worst, err / bound)
    jumps = []; jviol = 0
    for _ in range(300):
        n = int(rng.integers(2, 10)); th = rng.uniform(0, 2 * math.pi, n); logw = rng.normal(0, 0.5, n)
        s = float(rng.uniform(0.4, 1.5)); k = int(rng.integers(n))
        def local(tz):
            dd = np.array([wrap(t - tz) for t in th]); a = softmax(logw - dd ** 2 / (2 * s * s))
            return tz + float(a @ dd), a
        tz0 = th[k] + math.pi; h = 1e-9
        r1, a1 = local(tz0 - h); r2, a2 = local(tz0 + h)
        jump = abs(r2 - r1)
        dd = np.array([wrap(t - tz0) for t in th]); others = np.delete(np.arange(n), k)
        if not len(others):
            continue
        jstar = others[np.argmin(np.abs(dd[others]))]
        bound = 2 * math.pi * math.exp(logw[k] - logw[jstar] - (math.pi ** 2 - dd[jstar] ** 2) / (2 * s * s))
        a0 = softmax(logw - dd ** 2 / (2 * s * s))
        jumps.append(abs(jump - 2 * math.pi * a0[k])); jviol += 2 * math.pi * a0[k] > bound * (1 + 1e-12)
    # the ADE cut coordinate jumps at the cut; the local read does not
    th = np.concatenate([rng.normal(0.15, 0.1, 10) % (2 * math.pi), rng.normal(2 * math.pi - 0.15, 0.1, 10) % (2 * math.pi)])
    s = 0.5
    cut = lambda tz: float(softmax(-(tz - th) ** 2 / (2 * s * s)) @ th)
    loc = lambda tz: (tz + float(softmax(-np.array([wrap(t - tz) for t in th]) ** 2 / (2 * s * s)) @
                            np.array([wrap(t - tz) for t in th]))) % (2 * math.pi)
    cut_jump = abs(cut(2 * math.pi - 1e-9) - cut(1e-9))
    loc_jump = abs(wrap(loc(2 * math.pi - 1e-9) - loc(1e-9)))
    R["angles"] = dict(lift_trials=trials, lift_violations=viol, lift_worst_ratio=worst, jump_cases=len(jumps),
                       jump_formula_err=float(max(jumps)), jump_bound_violations=jviol,
                       cut_jump=cut_jump, local_jump=loc_jump)


# ---------------------------------------------------------------- 18. lines and subspaces: projector reads
def check_projector():
    resid = []; spreads = []
    for _ in range(400):
        n = int(rng.integers(3, 12)); psi = float(rng.uniform(0.01, 0.3))
        phi = rng.uniform(-psi, psi, n) + 0.3 * psi * rng.standard_normal(n); a = softmax(rng.normal(0, 1, n))
        th_m = math.atan2(float(a @ np.sin(phi)), float(a @ np.cos(phi)))
        th_P = 0.5 * math.atan2(float(a @ np.sin(2 * phi)), float(a @ np.cos(2 * phi)))
        mu = float(a @ phi); k3 = float(a @ (phi - mu) ** 3)
        spread = float(np.abs(phi).max()); spreads.append(spread)
        resid.append(abs((th_P - th_m) + 0.5 * k3) / spread ** 5)
    dk_viol = 0; dk_worst = 0.0
    for _ in range(400):
        D, k = int(rng.integers(3, 7)), int(rng.integers(1, 3))
        base = np.linalg.qr(rng.standard_normal((D, k)))[0]
        Ps = []
        for _ in range(int(rng.integers(3, 9))):
            U = np.linalg.qr(base + 0.3 * rng.standard_normal((D, k)))[0]; Ps.append(U @ U.T)
        a = softmax(rng.normal(0, 1, len(Ps))); P = sum(ai * Pi for ai, Pi in zip(a, Ps))
        E = 0.02 * rng.standard_normal((D, D)); E = (E + E.T) / 2
        w, V = np.linalg.eigh(P); w2, V2 = np.linalg.eigh(P + E)
        U1, U2 = V[:, -k:], V2[:, -k:]; gap = w[-k] - w[-k - 1]
        sin = float(np.linalg.norm(U2 - U1 @ (U1.T @ U2), 2)); bound = 2 * np.linalg.norm(E, 2) / gap
        dk_viol += sin > bound + 1e-12; dk_worst = max(dk_worst, sin / bound)
    R["projector"] = dict(line_cases=400, third_order_residual_max=float(max(resid)), max_spread=float(max(spreads)),
                          dk_cases=400, dk_violations=dk_viol, dk_worst_ratio=dk_worst)


if __name__ == "__main__":
    for fn in [check_harmonic_extension, check_matrix_weights, check_hulls, check_conditioning, check_residual_trace,
               check_mm, check_gradient_tweedie, check_ade_recovery, check_imputation, check_properness,
               check_tilt_coverage, check_measurement, check_truncation, check_rect_truncation, check_jacobian,
               check_branches, check_nearest_image, check_sign_example, check_angles, check_projector]:
        fn(); print("done", fn.__name__, flush=True)
    json.dump(R, open(os.path.join(here, "p2_checks.json"), "w"), indent=1,
              default=lambda o: o.tolist() if hasattr(o, "tolist") else (int(o) if isinstance(o, np.integer) else str(o)))
    print(json.dumps(R, indent=1, default=str))
