# Recompute every number printed by the Part II C# kernel (cs/cs_out.txt) with an independent NumPy implementation.
import json, math, os
import numpy as np

here = os.path.dirname(os.path.abspath(__file__))


def softmax(x):
    e = np.exp(x - x.max())
    return e / e.sum()


Qs = [np.array([[1.0, 0, 0], [0, 1, 0]]), np.array([[0, 0, 1.0]]), np.array([[0.6, 0.8, 0], [0, 0, 1.0]]),
      np.array([[1.0, -1, 0.5]])]
obs = [np.array([1.0, -0.5]), np.array([2.0]), np.array([0.4, 1.5]), np.array([0.3])]
logw = np.array([0.0, -0.3, 0.2, 0.1])


def logits(z, s):
    return logw - np.array([0.5 * np.sum((Q @ z - o) ** 2) for Q, o in zip(Qs, obs)]) / s ** 2


def energy(z, s):
    l = logits(z, s); p = l.max()
    return -s * s * (p + math.log(np.exp(l - p).sum()))


def read(z, s, tol=1e-10):
    a = softmax(logits(z, s))
    H = sum(ai * Q.T @ Q for ai, Q in zip(a, Qs)); b = sum(ai * Q.T @ o for ai, Q, o in zip(a, Qs, obs))
    w, V = np.linalg.eigh(H); cut = tol * max(1.0, w.max())
    inv = np.array([1 / x if x > cut else 0.0 for x in w])
    m = z + V @ (inv * (V.T @ (b - H @ z)))
    return a, H, m, w.min(), w.min() <= cut


lines = []
fmt = lambda name, xs: name + " " + " ".join(f"{float(x):.15g}" for x in xs)
z = np.array([0.2, -0.1, 0.5]); s = 0.8
a, H, m, lmin, _ = read(z, s)
lines += [fmt("weights", a), fmt("read", m), fmt("min_eig", [lmin]), fmt("energy", [energy(z, s)])]
for lam in [0.5, 1.0, 1.5]:
    zn = (1 - lam) * z + lam * m; d = z - m
    lines.append(fmt(f"step_{lam:g}", [energy(zn, s), 0.5 * lam * (2 - lam) * d @ H @ d]))
au, Hu, mu, _, unres = read(np.array([5.0, 5.0, 2.0]), 0.05)
lines += [fmt("unresolved", [1.0 if unres else 0.0]), fmt("read_unresolved", mu)]
G = [np.eye(3), np.eye(3)[::-1]]
ys = [np.array([1.0, 0.2, -0.5]), np.array([-0.3, 0.8, 1.1]), np.array([0.5, -1.0, 0.0])]
lw = np.array([0.0, 0.2, -0.1]); zi = np.array([0.9, 0.1, -0.2]); si = 0.6
imgs = np.array([[g @ y for g in G] for y in ys]); d2 = np.sum((imgs - zi) ** 2, 2)
m_all = np.einsum("ig,igd->d", softmax((lw[:, None] - d2 / (2 * si * si)).ravel()).reshape(d2.shape), imgs)
best = d2.argmin(1); near = imgs[np.arange(3), best]
m_near = softmax(lw - d2[np.arange(3), best] / (2 * si * si)) @ near
lines += [fmt("image_all", m_all), fmt("image_nearest", m_near)]
P = np.array([(0.0, 0.0), (0.4, 0.1), (1.0, 0.8), (2.5, 2.0), (3.0, 0.5), (0.2, 1.6), (4.0, 4.0), (1.4, 0.2)])
wt = np.array([1.0, 0.8, 1.2, 0.9, 1.1, 0.7, 1.3, 1.0]); zt = np.array([0.3, 0.3]); sc, rho = 0.5, 1.5
dd = np.sum((P - zt) ** 2, 1); k = wt * np.exp(-dd / (2 * sc * sc)); S = dd <= rho * rho
diam = max(np.linalg.norm(p - q) for p in P for q in P)
mfull = k @ P / k.sum(); mstar = k[S] @ P[S] / k[S].sum()
cert = diam * min(1.0, (wt.sum() - wt[S].sum()) * math.exp(-rho * rho / (2 * sc * sc)) / k[S].sum())
lines.append(fmt("truncation", [np.linalg.norm(mfull - mstar), cert]))

got = [ln.split() for ln in open(os.path.join(here, "cs", "cs_out.txt")) if ln.strip()]
exp = [ln.split() for ln in lines]
assert len(got) == len(exp), "C# and NumPy line counts differ"
worst, agree, per_line, identical = 0.0, 0, [], 0
for g, e in zip(got, exp):
    ok = g[0] == e[0] and len(g) == len(e); line_worst = 0.0
    for x, y in zip(g[1:], e[1:]):
        rel = abs(float(x) - float(y)) / max(1e-300, abs(float(y)), 1e-12)
        line_worst = max(line_worst, rel); ok &= rel < 1e-9
    worst = max(worst, line_worst); agree += ok; per_line.append(line_worst); identical += g == e
res = dict(lines=len(exp), agree=agree, identical=identical, worst_rel_diff=worst, per_line=per_line,
           csharp=[" ".join(g) for g in got], python=lines)
assert agree == len(exp), "C# comparison failed"
json.dump(res, open(os.path.join(here, "cs_validate.json"), "w"), indent=1)
print(json.dumps({k: v for k, v in res.items() if k in ("lines", "agree", "identical", "worst_rel_diff")}))
