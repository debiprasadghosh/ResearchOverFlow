# Assemble the Part II source and fill every {{...}} placeholder from the machine-readable results.
import json, math, os, re, subprocess, shutil

here = os.path.dirname(os.path.abspath(__file__))
parts = ["a_front.md", "b_attention.md", "c_stalks.md", "d_locality.md", "e_topology.md", "f_end.md"]
src = "\n".join(open(os.path.join(here, "src", p), encoding="utf-8").read() for p in parts)

c = json.load(open(os.path.join(here, "p2_checks.json")))
x = json.load(open(os.path.join(here, "p2_extras.json")))
v = json.load(open(os.path.join(here, "cs_validate.json")))
wrap = lambda a: (a + math.pi) % (2 * math.pi) - math.pi
rc = x["rect_certificate"]
d = dict(
    n_checks=len(c) + len(x),
    n_main=len(c), n_extra=len(x),
    cut_jump_circle=abs(wrap(c["angles"]["cut_jump"])),
    ridge_excess=max(float(vv)-float(kk)/(1+float(kk)) for kk,vv in x["retention"]["ridge_rel_err"].items()),
    ridge2=x["retention"]["ridge_rel_err"]["0.01"], ridge4=x["retention"]["ridge_rel_err"]["0.0001"],
    ridge6=x["retention"]["ridge_rel_err"]["1e-06"],
    rc_full=rc["full-rank maps"], rc_mixed=rc["mixed-rank maps"],
    rc_full_05_5=rc["full-rank maps"]["by_radius"]["0.5|5"], rc_mixed_05_5=rc["mixed-rank maps"]["by_radius"]["0.5|5"],
    rc_tests=rc["full-rank maps"]["tests"] + rc["mixed-rank maps"]["tests"],
    rc_finite=rc["full-rank maps"]["finite"] + rc["mixed-rank maps"]["finite"],
    rc_singular=rc["full-rank maps"]["singular_star"] + rc["mixed-rank maps"]["singular_star"],
    rc_vacuous=rc["full-rank maps"]["vacuous"] + rc["mixed-rank maps"]["vacuous"],
    rc_worst=max(rc["full-rank maps"]["worst_ratio"], rc["mixed-rank maps"]["worst_ratio"]),
    ni=c["nearest_image"], qi=x["quotient_index"],
    ni_sign=c["nearest_image"]["sign flips in R^6"], ni_mirror=c["nearest_image"]["mirror reversal in R^6"],
    ni_dihedral=c["nearest_image"]["dihedral group of order 12 in R^2"],
    qi_refl=x["quotient_index"]["reflection group (dihedral, order 12)"],
    qi_sign=x["quotient_index"]["sign group in R^6"], qi_mirror=x["quotient_index"]["mirror reversal in R^6"],
    tilt_p=c["tilt_coverage"]["min_eig"]["elite partial"], tilt_f=c["tilt_coverage"]["min_eig"]["elite full"],
    tilt_slope=x["tilt_law"]["masses"]["slope along the unobserved axis"],
    tilt_flat=x["tilt_law"]["masses"]["no slope there"],
    prop_full=c["properness"]["mixture_masses"]["full record"],
    prop_part=c["properness"]["mixture_masses"]["partial record"],
    ni_eq_all=max(g["equivariance_all"] for g in c["nearest_image"].values()),
    ni_eq_near=max(g["equivariance_near"] for g in c["nearest_image"].values()),
    ni_trials=sum(g["trials"] for g in c["nearest_image"].values()),
    nim_viol=sum(g["violations"] for g in c["nearest_image"].values()),
    qi_miss_rate_sign=x["quotient_index"]["sign group in R^6"]["nearest_missed"] / x["quotient_index"]["sign group in R^6"]["queries"],
    qi_miss_rate_mirror=x["quotient_index"]["mirror reversal in R^6"]["nearest_missed"] / x["quotient_index"]["mirror reversal in R^6"]["queries"],
    beat_rate=x["coordinate_ceiling"]["beats_best_record"] / x["coordinate_ceiling"]["cases"],
    over_two_rate=c["mm"]["over_two_increases"] / c["mm"]["over_two_trials"],
    trunc_total=sum(1 for _ in c["truncation"]["rows"]) * 60,
    trunc_tested=sum(r["tested"] for r in c["truncation"]["rows"]),
    trunc_empty=sum(r["empty_star"] for r in c["truncation"]["rows"]),
)
import numpy, matplotlib, platform, scipy
dotnet = subprocess.run(["dotnet", "--version"], capture_output=True, text=True).stdout.strip() if shutil.which("dotnet") else "not installed; supplied output compared"
env = dict(python=platform.python_version(), numpy=numpy.__version__, scipy=scipy.__version__,
           matplotlib=matplotlib.__version__, dotnet=dotnet)
r = json.load(open(os.path.join(here, "review_checks.json")))
data = dict(c=c, x=x, v=v, d=d, r=r, env=env)

SUP = str.maketrans("-0123456789", "⁻⁰¹²³⁴⁵⁶⁷⁸⁹")


def lookup(path):
    head, *rest = path.split(".")
    val = data[head]
    for key in rest:
        if isinstance(val, list):
            val = val[int(key)]
        elif key in val:
            val = val[key]
        else:
            raise KeyError(f"missing key {key!r} in {path}")
    return val


def num(val):
    if isinstance(val, bool):
        return int(val)
    if isinstance(val, str) and re.fullmatch(r"-?\d+(\.\d+)?", val):
        return float(val) if "." in val else int(val)
    return val


def fmt(val, f):
    val = num(val)
    if f in ("", None):
        if isinstance(val, float) and val.is_integer():
            val = int(val)
        s = f"{val:,}" if isinstance(val, int) and abs(val) >= 1000 else str(val)
        return s.replace("-", "−") if isinstance(val, (int, float)) else s
    if f == "d":
        return f"{int(round(float(val))):,}".replace("-", "−")
    if re.fullmatch(r"f\d+", f):
        return f"{float(val):.{int(f[1:])}f}".replace("-", "−")
    if f in ("g2", "g3", "g4", "g6"):
        if float(val) == 0:
            return "0"
        s = f"{float(val):.{f[1]}g}"
        if "e" in s:
            m, e = s.split("e")
            return f"{m} × 10{str(int(e)).translate(SUP)}"
        return s.replace("-", "−")
    if f in ("e1", "e2"):
        if float(val) == 0:
            return "0"
        m, e = f"{float(val):.{f[1]}e}".split("e")
        return f"{m} × 10{str(int(e)).translate(SUP)}".replace("-", "−", 1) if m.startswith("-") else f"{m} × 10{str(int(e)).translate(SUP)}"
    if f in ("pct0", "pct1"):
        return f"{100 * float(val):.{f[3]}f}%"
    raise ValueError(f"unknown format {f}")


def trunc_rows():
    out = []
    for r in c["truncation"]["rows"]:
        out.append(f"| {r['s']:g} | {r['c']:g} | {100 * r['share']:.2f}% ({r['tested']}/60) | {r['max_ratio']:.4f} | "
                   f"{fmt(r['median_cert'], 'g3')} |")
    return "\n".join(out)


def fill(m):
    body = m.group(1).replace("\\|", "|")
    if body.startswith("file:"):
        return open(os.path.join(here, body[5:]), encoding="utf-8").read().rstrip("\n")
    if body == "cs_rows":
        return "\n".join(f"| `{a.split()[0]}` | {fmt(r, 'e1')} | {'yes' if a == b else 'no'} |"
                         for a, b, r in zip(v["csharp"], v["python"], v["per_line"]))
    if body == "trunc_rows":
        return trunc_rows()
    path, _, f = body.partition("|")
    return fmt(lookup(path.strip()), f.strip())


out = re.sub(r"\{\{(.+?)\}\}", fill, src)
out = out.replace("$\\blacksquare$", "∎")
# Put following punctuation inside the inline math object so Word cannot
# strand a comma or full stop at the start of the next line.
out = re.sub(r"\$([^$\n]+)\$([,.;:])", lambda m: "$" + m.group(1) + r"\text{" + m.group(2) + "}$", out)
left = re.findall(r"\{\{\s*[a-z]", out)
assert not left, "unfilled placeholders remain"
open(os.path.join(here, "paper.md"), "w", encoding="utf-8").write(out)
print("paper.md written;", len(out.split()), "words")
