// The paper's constructions in exact arithmetic: linear structural models, perfect interventions,
// path resolvents, the error allowance of Theorem 8.1, the incidence sheaf cohomology of
// Theorem 4.4, the symmetric smoother of Section 7.1 and the interval studies of Section 11.
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;

namespace Tcr;

/// <summary>A linear structural model x = Bx + u in a topological order (B strictly lower triangular).</summary>
public sealed record LinearScm(QMat B)
{
    public int N => B.Rows;

    /// <summary>Recursive solution with perfect interventions (target -> clamp).</summary>
    public ImmutableArray<Q> Solve(ImmutableArray<Q> u, ImmutableDictionary<int, Q> doMap) =>
        Enumerable.Range(0, N).Aggregate(ImmutableArray<Q>.Empty, (x, v) => x.Add(doMap.TryGetValue(v, out var d)
            ? d : Enumerable.Range(0, v).Aggregate(u[v], (s, w) => s + B[v, w] * x[w])));

    /// <summary>R_D = (I - P B)^{-1} with P zeroing the target rows (Theorem 6.1).</summary>
    public QMat Resolvent(IEnumerable<int> targets)
    {
        var t = targets.ToHashSet();
        var pb = QMat.Of(N, N, (i, j) => t.Contains(i) ? Q.Zero : B[i, j]);
        return QMat.Identity(N).Sub(pb).Inverse();
    }

    /// <summary>The same resolvent as a sum over directed paths of (P B)^k, k = 0..n-1.</summary>
    public QMat PathSum(IEnumerable<int> targets)
    {
        var t = targets.ToHashSet();
        var pb = QMat.Of(N, N, (i, j) => t.Contains(i) ? Q.Zero : B[i, j]);
        var (acc, pw) = (QMat.Identity(N), QMat.Identity(N));
        for (int k = 1; k < N; k++) { pw = pw.Mul(pb); acc = QMat.Of(N, N, (i, j) => acc[i, j] + pw[i, j]); }
        return acc;
    }
}

/// <summary>A DAG whose edge gains are symbols. Edge e = (child, parent) is symbol e.</summary>
public sealed record SymbolicDag(int N, ImmutableArray<(int Child, int Parent)> Edges)
{
    /// <summary>Forward-substitution expression for the response of every node to a unit input
    /// at <paramref name="source"/>: r_v = sum over parents w of g_(v,w) r_w. Shared subtrees are
    /// reused, exactly as interval forward substitution reuses computed node intervals.</summary>
    public ImmutableArray<Expr> Forward(int source)
    {
        var r = new Expr[N];
        for (int v = 0; v < N; v++)
        {
            if (v == source) { r[v] = new Expr.C(Q.One); continue; }
            var terms = Edges.Select((e, i) => (e, i)).Where(t => t.e.Child == v && r[t.e.Parent] is not Expr.C { Value.IsZero: true })
                .Select(t => r[t.e.Parent] is Expr.C { Value: var one } && one == Q.One ? new Expr.V(t.i) : Expr.Mul(new Expr.V(t.i), r[t.e.Parent]))
                .ToArray();
            r[v] = terms.Length == 0 ? new Expr.C(Q.Zero) : Expr.Add(terms);
        }
        return r.ToImmutableArray();
    }

    /// <summary>Number of directed paths from source to target.</summary>
    public long PathCount(int s, int t)
    {
        var c = new long[N]; c[s] = 1;
        for (int v = s + 1; v < N; v++) c[v] = Edges.Where(e => e.Child == v).Sum(e => c[e.Parent]);
        return c[t];
    }
}

/// <summary>Incidence-graph realisation of the linear mechanism sheaf (Section 4.2).</summary>
public static class IncidenceSheaf
{
    /// <summary>Mechanism v has endogenous parents with gains and exogenous inputs with gains.
    /// Returns (dim C0, dim C1, rank of the coboundary, dim H0, dim H1, graph vertices, graph
    /// edges, first Betti number of the constant sheaf).</summary>
    public static (int C0, int C1, int Rank, int H0, int H1, int Vertices, int EdgesN, int ConstantH1) Cohomology(
        int n, int q, ImmutableArray<ImmutableArray<(int Var, Q Gain)>> inputs)
    {
        // variable points: 0..n-1 endogenous, n..n+q-1 exogenous; mechanism stalks follow.
        var mechOffset = new int[n]; int c0 = n + q;
        for (int v = 0; v < n; v++) { mechOffset[v] = c0; c0 += inputs[v].Length; }
        var rows = new List<Q[]>();
        for (int v = 0; v < n; v++)
        {
            var row = new Q[c0]; Array.Fill(row, Q.Zero); row[v] = Q.One;              // child edge
            for (int k = 0; k < inputs[v].Length; k++) row[mechOffset[v] + k] = -inputs[v][k].Gain;
            rows.Add(row);
            for (int k = 0; k < inputs[v].Length; k++)                                  // input edges
            {
                var r = new Q[c0]; Array.Fill(r, Q.Zero);
                r[inputs[v][k].Var] = Q.One; r[mechOffset[v] + k] = -Q.One; rows.Add(r);
            }
        }
        var delta = new QMat(rows.Count, c0, rows.SelectMany(r => r).ToImmutableArray());
        int rank = delta.Rank();
        int vertices = n + q + n, edgesN = rows.Count;
        // constant sheaf: incidence matrix of the same graph
        var inc = new List<Q[]>();
        for (int v = 0; v < n; v++)
            foreach (var a in inputs[v].Select(t => t.Var).Prepend(v))
            {
                var r = new Q[vertices]; Array.Fill(r, Q.Zero); r[a] = Q.One; r[n + q + v] = -Q.One; inc.Add(r);
            }
        int incRank = new QMat(inc.Count, vertices, inc.SelectMany(r => r).ToImmutableArray()).Rank();
        return (c0, rows.Count, rank, c0 - rank, rows.Count - rank, vertices, edgesN, edgesN - incRank);
    }
}

/// <summary>The regularised harmonic read of Section 7.1 on a path of T scalar event blocks:
/// K(w) = (I + w L)^{-1}, with L the path Laplacian.</summary>
public static class Smoother
{
    public static QMat K(int t, Q w) => QMat.Of(t, t, (i, j) =>
        i == j ? Q.One + w * (i == 0 || i == t - 1 ? 1 : 2) : Math.Abs(i - j) == 1 ? -w : Q.Zero).Inverse();

    /// <summary>det(I + wL) as a polynomial in the symbol 0 = w, by the tridiagonal recurrence.</summary>
    public static Poly Det(int t)
    {
        var w = Poly.Var(0); var one = Poly.Const(Q.One);
        Poly Diag(int i) => one + w * Poly.Const(i == 0 || i == t - 1 ? 1 : 2);
        var (p2, p1) = (one, Diag(0));
        for (int i = 1; i < t; i++) (p2, p1) = (p1, Diag(i) * p1 - w * w * p2);
        return p1;
    }
}
