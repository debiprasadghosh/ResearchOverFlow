"""Figure 3 of V2: drawn from the validated C# kernel output."""
import os, sys
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
H = os.path.dirname(os.path.abspath(__file__))
cs = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1].split(" ") for l in open(os.path.join(H, "cs", "cs_out.txt"))}
B, O, A, INK, MUT = "#2a78d6", "#eb6834", "#1baf7a", "#222222", "#6b6b6b"
plt.rcParams.update({"font.size": 8.5, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": MUT,
                     "xtick.color": MUT, "ytick.color": MUT, "axes.grid": True, "grid.color": "#e8e8e8", "grid.linewidth": .6})
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 2.9), gridspec_kw=dict(width_ratios=[1.15, 1]))
items = [("exact range = single-use form", "cf_interval_single_use", A),
         ("expanded polynomial", "cf_interval_expanded", B),
         ("abduction, action, prediction\nevaluated step by step", "cf_interval_stepwise", O),
         ("population intervention mean", "cf_interval_population_mean", MUT)]
for k, (lab, key, col) in enumerate(items):
    lo, hi = map(float, cs[key]); y = len(items) - 1 - k
    a1.plot([lo, hi], [y, y], color=col, lw=6, solid_capstyle="butt")
    a1.text(lo - 0.08, y, lab, ha="right", va="center", fontsize=7.2, color=INK)
    a1.text(hi + 0.06, y, f"{hi - lo:.2f}", ha="left", va="center", fontsize=7, color=MUT)
a1.set_yticks([]); a1.set_xlim(3.4, 9.1); a1.set_ylim(-0.6, len(items) - 0.4)
a1.axvline(8, color=INK, lw=.7, ls=":", ymin=0.3)
a1.set_xlabel("counterfactual $Y^{do(X=3)}$ (interval width at right)")
a1.set_title("(a) one counterfactual, four evaluation orders", fontsize=8.5, color=INK)
a1.grid(axis="y", visible=False)
d = pd.read_csv(os.path.join(H, "cs", "dag_study.csv")); m = d[d.regime == "mixed"].copy()
bins = [(2, 2, "2"), (3, 3, "3"), (4, 4, "4"), (5, 5, "5"), (6, 7, "6–7"), (8, 99, "≥8")]
xs = np.arange(len(bins))
for col, key, lab, off in ((B, "expanded_ratio", "expanded polynomial", -0.18), (O, "forward_ratio", "forward substitution", 0.0), (A, "horner_ratio", "greedy Horner form", 0.18)):
    mean = [m[(m.paths >= lo) & (m.paths <= hi)][key].mean() for lo, hi, _ in bins]
    mx = [m[(m.paths >= lo) & (m.paths <= hi)][key].max() for lo, hi, _ in bins]
    a2.plot(xs + off, mean, "o", color=col, ms=4.5, label=lab)
    a2.vlines(xs + off, 1, mx, color=col, lw=1)
p = d[d.regime == "positive"]
a2.axhline(1, color=INK, lw=.8, ls="--")
a2.set_xticks(xs); a2.set_xticklabels([b[2] for b in bins])
a2.set_xlabel("directed paths from source to sink"); a2.set_ylabel("enclosure width / exact width")
a2.set_title("(b) total effect with sign-indefinite gain intervals", fontsize=8.5, color=INK)
a2.legend(frameon=False, fontsize=6.8, loc="upper right"); a2.set_ylim(0.9, 2.95)
fig.tight_layout(); out = os.path.join(H, "fig", "tcr_interval.png"); fig.savefig(out, dpi=220); plt.close(fig)
print("ok", out)
