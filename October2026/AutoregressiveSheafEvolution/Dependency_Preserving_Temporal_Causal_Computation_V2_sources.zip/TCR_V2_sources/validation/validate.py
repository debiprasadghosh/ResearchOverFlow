"""Independent recomputation of every line of the C# kernel output.

Exact quantities are recomputed with fractions and SymPy (determinants, inverses, ranks).
Interval lines are recomputed in exact rational interval arithmetic: the C# outward-rounded
interval must contain the exact rational result of the same expression form, and be no more than
1e-12 wider in relative terms. Exact ranges are recomputed by vertex enumeration in NumPy."""
import itertools, json, math, sys
from fractions import Fraction as F
import numpy as np
import sympy as sp

cs = {}
for line in open(sys.argv[1]):
    name, _, vals = line.rstrip("\n").partition("\t")
    cs[name] = vals.split(" ")
rows = []


def check(name, ok, detail=""):
    rows.append(dict(name=name, passed=bool(ok), detail=str(detail)))


def fr(tok): return F(tok)


def eq_exact(name, vals):
    got = [fr(t) for t in cs[name]]
    check(name, got == [F(v) for v in vals], f"{cs[name]} vs {vals}")


# --------------------------------------------------------------- exact interval arithmetic
class I:
    def __init__(s, lo, hi=None): s.lo, s.hi = F(lo), F(lo if hi is None else hi)
    def __add__(s, o): o = o if isinstance(o, I) else I(o); return I(s.lo + o.lo, s.hi + o.hi)
    __radd__ = __add__
    def __neg__(s): return I(-s.hi, -s.lo)
    def __sub__(s, o): return s + (-(o if isinstance(o, I) else I(o)))
    def __mul__(s, o):
        o = o if isinstance(o, I) else I(o); p = [s.lo * o.lo, s.lo * o.hi, s.hi * o.lo, s.hi * o.hi]
        return I(min(p), max(p))
    __rmul__ = __mul__


def iv_check(name, exact_iv, tol=1e-12):
    lo, hi = float(cs[name][0]), float(cs[name][1])
    contains = F(lo) <= exact_iv.lo and F(hi) >= exact_iv.hi
    w = float(exact_iv.hi - exact_iv.lo); slack = (hi - lo) - w
    check(name, contains and slack <= tol * max(1.0, abs(w), abs(float(exact_iv.hi))), f"cs [{lo},{hi}] exact-form [{float(exact_iv.lo)},{float(exact_iv.hi)}]")


# --------------------------------------------------------------- the diamond
B = sp.Matrix([[0, 0, 0, 0], [2, 0, 0, 0], [1, 0, 0, 0], [0, 3, 4, 0]])
def solve(u, do):
    x = []
    for v in range(4):
        x.append(F(do[v]) if v in do else F(u[v]) + sum(F(int(B[v, w])) * x[w] for w in range(v)))
    return x
u0 = [1, 0, 0, 0]
eq_exact("diamond_factual", solve(u0, {}))
eq_exact("diamond_do_x2_eq_3", solve(u0, {1: 3}))
eq_exact("diamond_do_x1_eq_2", solve(u0, {0: 2}))
R0 = (sp.eye(4) - B).inv(); P2 = sp.diag(1, 0, 1, 1); R2 = (sp.eye(4) - P2 * B).inv()
eq_exact("diamond_routes_and_total", [6, 4, R0[3, 0]])
eq_exact("diamond_R_last_row", list(R0.row(3)))
eq_exact("diamond_RD_last_row_do2", list(R2.row(3)))
eq_exact("diamond_RDPC_last_row_do2", list((R2 * P2).row(3)))
ps = sum(((P2 * B) ** k for k in range(4)), sp.zeros(4)); ps0 = sum((B ** k for k in range(4)), sp.zeros(4))
check("diamond_inverse_equals_pathsum", cs["diamond_inverse_equals_pathsum"] == ["1"] and ps == R2 and ps0 == R0)
x, xd = sp.Matrix(solve(u0, {})), sp.Matrix(solve(u0, {1: 3}))
check("diamond_difference_identity", cs["diamond_difference_identity"] == ["1"] and xd - x == R2 * (sp.eye(4) - P2) * (sp.Matrix([0, 3, 0, 0]) - x))
eta, w1 = F(1, 100), F(2, 100)
m0 = sum(F(int(v)) for v in R0.row(3)) * eta; p0 = max(abs(F(int(v))) for v in R0.row(3)) * w1
row = R2.row(3); m2 = sum(F(int(row[j])) * (0 if j == 1 else eta) for j in range(4)); p2 = max(abs(F(int(v))) for v in (R2 * P2).row(3)) * w1
eq_exact("bound_no_intervention", [m0, p0, m0 + p0]); eq_exact("bound_do_node2", [m2, p2, m2 + p2])

# --------------------------------------------------------------- clocks
edges = [(0, 1, 2), (0, 2, 1), (1, 3, 3), (2, 3, 4)]
def earliest(hi):
    e = [0] * 4
    for v in range(4):
        e[v] = max([0] + [e[f] + l for f, t, l in edges if t == v])
    return e, all(e[v] <= hi[v] for v in range(4))
e8, ok8 = earliest([0, 3, 2, 8]); e4, ok4 = earliest([0, 3, 2, 4])
eq_exact("clock_earliest", e8); check("clock_feasible_h8", cs["clock_feasible_h8"] == ["1"] and ok8)
check("clock_feasible_h4", cs["clock_feasible_h4"] == ["0"] and not ok4)
w = [int(t) for t in cs["clock_witness_h4"]]
check("clock_witness_h4", w[0] == 1 and w[-1] == 4 and sum(l for f, t, l in edges if (f + 1, t + 1) in list(zip(w, w[1:]))) > 4, w)


def stn_dist(n, cons):
    INF = None; d = [[F(0) if i == j else INF for j in range(n)] for i in range(n)]
    for i, j, c in cons:
        if d[i][j] is None or c < d[i][j]: d[i][j] = F(c)
    for k in range(n):
        for i in range(n):
            for j in range(n):
                if d[i][k] is not None and d[k][j] is not None and (d[i][j] is None or d[i][k] + d[k][j] < d[i][j]):
                    d[i][j] = d[i][k] + d[k][j]
    return d


def stn_build(dates, lags):
    c = []
    for ev, lo, hi in dates: c += [(0, ev, hi), (ev, 0, -lo)]
    for f, t, mn, mx in lags:
        c.append((t, f, -mn))
        if mx is not None: c.append((f, t, mx))
    return c
cons = stn_build([(v + 1, 0, [0, 3, 2, 4][v]) for v in range(4)], [(f + 1, t + 1, l, None) for f, t, l in edges])
d = stn_dist(5, cons)
check("stn_diamond_h4_consistent", cs["stn_diamond_h4_consistent"] == ["0"] and any(d[i][i] < 0 for i in range(5)))
cyc = [int(t) for t in cs["stn_negative_cycle"][0].split(">")]; clen = F(cs["stn_negative_cycle"][1])
cl = sum(min(c for i, j, c in cons if (i, j) == e) for e in zip(cyc, cyc[1:]))
check("stn_negative_cycle", cyc[0] == cyc[-1] and cl == clen and cl < 0, (cyc, cl))
cons2 = stn_build([(1, 0, 0), (2, 0, 3), (3, 0, 2), (4, 0, 8)], [(1, 2, 2, F(5, 2)), (1, 3, 1, F(3, 2)), (2, 4, 3, 4), (3, 4, 4, F(9, 2))])
d2 = stn_dist(5, cons2)
check("stn_diamond_upper_lags_consistent", cs["stn_diamond_upper_lags_consistent"] == ["1"] and all(d2[i][i] >= 0 for i in range(5)))
eq_exact("stn_diamond_upper_lags_windows", sum(([-d2[v][0], d2[0][v]] for v in range(1, 5)), []))

# --------------------------------------------------------------- finite checks
rel = [(a, b, a ^ b) for a in (0, 1) for b in (0, 1)]
eq_exact("xor_pairwise_projection_sizes", [len({(a, b) for a, b, c in rel}), len({(a, c) for a, b, c in rel}), len({(b, c) for a, b, c in rel})])
acc = sum(1 for a, b, c in itertools.product((0, 1), repeat=3) if any(t[:2] == (a, b) for t in rel) and any((t[0], t[2]) == (a, c) for t in rel) and any((t[1], t[2]) == (b, c) for t in rel))
eq_exact("xor_binary_closure_vs_relation", [acc, len(rel)])
check("thm53_same_observational_support", cs["thm53_same_observational_support"] == ["1"])
eq_exact("thm53_P_Y0_do_X0_A_B", [1, F(1, 2)])
def PY(model, dx, dy, y):
    return sum(F(1, 4) for ux in (0, 1) for uy in (0, 1) if (dy if dy is not None else (uy if model == 0 else uy ^ (dx if dx is not None else ux))) == y)
check("prop55_interventions_agree", cs["prop55_interventions_agree"] == ["1"] and all(PY(0, a, b, 1) == PY(1, a, b, 1) for a in (None, 0, 1) for b in (None, 0, 1)))
eq_exact("prop55_counterfactual_Y_C_D", [0, 1])
wv = sp.symbols("w", positive=True)
def Lap(t): return sp.Matrix(t, t, lambda i, j: (1 if i in (0, t - 1) else 2) if i == j else (-1 if abs(i - j) == 1 else 0))
K2 = (sp.eye(2) + Lap(2)).inv()
eq_exact("smoother_T2_w1", list(K2))
eq_exact("cf_10_2_counterfactual_population", [4 + 2 * (3 - 1), 2 * 3])
check("compression_identity_fails_parity_holds", cs["compression_identity_fails_parity_holds"] == ["1", "1"])

# --------------------------------------------------------------- Theorem 4.4
def cohom(n, q, inputs):
    off, c0 = [], n + q
    for v in range(n): off.append(c0); c0 += len(inputs[v])
    rows_ = []
    for v in range(n):
        r = [0] * c0; r[v] = 1
        for k, (a, g) in enumerate(inputs[v]): r[off[v] + k] = -g
        rows_.append(r)
        for k, (a, g) in enumerate(inputs[v]):
            r = [0] * c0; r[a] = 1; r[off[v] + k] = -1; rows_.append(r)
    rk = sp.Matrix(rows_).rank()
    V = n + q + n; inc = []
    for v in range(n):
        for a in [v] + [a for a, g in inputs[v]]:
            r = [0] * V; r[a] = 1; r[n + q + v] = -1; inc.append(r)
    irk = sp.Matrix(inc).rank()
    return [c0, len(rows_), rk, c0 - rk, len(rows_) - rk, V, len(rows_), len(rows_) - irk]
eq_exact("cohomology_diamond", cohom(4, 4, [[(4, 1)], [(0, 2), (5, 1)], [(0, 1), (6, 1)], [(1, 3), (2, 4), (7, 1)]]))


class Rng:
    def __init__(s, st): s.s = st
    def next(s):
        s.s = (s.s + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF; z = s.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & 0xFFFFFFFFFFFFFFFF
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & 0xFFFFFFFFFFFFFFFF
        return z ^ (z >> 31)
    def uniform(s): return (s.next() >> 11) * (1.0 / 9007199254740992.0)
    def int(s, lo, hi): return lo + math.floor(s.uniform() * (hi - lo + 1))

rng = Rng(20261030); stats = [0, 0, 0, 0, 0, 0]
for m in range(300):
    n = rng.int(2, 9); shared = rng.int(0, 2); q = n + shared; inp = []
    for v in range(n):
        lst = []
        for w in range(v):
            if rng.uniform() < 0.4: k = rng.int(-8, 8); lst.append((w, sp.Rational(k, 4)))
        lst.append((n + v, 1))
        for s_ in range(shared):
            if rng.uniform() < 0.5: k = rng.int(-8, 8); lst.append((n + n + s_, sp.Rational(k, 4)))
        inp.append(lst)
    h = cohom(n, q, inp)
    stats[0] += 1; stats[1] += h[3] == q; stats[2] += h[4] == 0; stats[3] += h[7] > 0; stats[4] = max(stats[4], h[7]); stats[5] += h[7]
got = cs["cohomology_random_models"]
check("cohomology_random_models", [int(t) for t in got[:5]] == stats[:5] and abs(float(got[5]) - stats[5] / 300) < 1e-12, (got, stats))

# --------------------------------------------------------------- symbolic path polynomials and interval forms
def forward_expr(n, edges, src, sym):
    """Return SymPy expression tree (unevaluated) of forward substitution, and an interval evaluator."""
    r = [None] * n; r[src] = ("one",)
    for v in range(n):
        if v == src: continue
        terms = [(i, e[1]) for i, e in enumerate(edges) if e[0] == v and r[e[1]] is not None and r[e[1]] != ("zero",)]
        r[v] = ("sum", [("var", i) if r[p] == ("one",) else ("mul", ("var", i), r[p]) for i, p in terms]) if terms else ("zero",)
    return r


def ev_tree(t, box):
    k = t[0]
    if k == "one": return I(1)
    if k == "zero": return I(0)
    if k == "var": return I(*box[t[1]])
    if k == "mul": return ev_tree(t[1], box) * ev_tree(t[2], box)
    if k == "sum":
        acc = ev_tree(t[1][0], box)
        for x in t[1][1:]: acc = acc + ev_tree(x, box)
        return acc


def tree_poly(t, syms):
    k = t[0]
    if k == "one": return sp.Integer(1)
    if k == "zero": return sp.Integer(0)
    if k == "var": return syms[t[1]]
    if k == "mul": return sp.expand(tree_poly(t[1], syms) * tree_poly(t[2], syms))
    return sp.expand(sum(tree_poly(x, syms) for x in t[1]))


def monos(poly, syms):
    P = sp.Poly(poly, *syms)
    return [(tuple(i for i, e in enumerate(m) if e) , F(int(c.p), int(c.q))) for m, c in zip(P.monoms(), P.coeffs())]


def expanded_iv(ms, box):
    acc = I(0)
    for vs, c in ms:
        t = I(c)
        for v in vs: t = t * I(*box[v])
        acc = acc + t
    return acc


def horner_iv(ms, box):
    if len(ms) <= 1: return expanded_iv(ms, box)
    allv = sorted({v for vs, c in ms for v in vs})
    cnt = [(sum(1 for vs, c in ms if v in vs), v) for v in allv]
    best = max(cnt, key=lambda t: (t[0], -t[1]))
    if best[0] < 2: return expanded_iv(ms, box)
    v = best[1]
    w = [(tuple(x for x in vs if x != v), c) for vs, c in ms if v in vs]; rest = [(vs, c) for vs, c in ms if v not in vs]
    head = I(*box[v]) * horner_iv(w, box)
    return head if not rest else head + horner_iv(rest, box)


def exact_range(ms, box):
    vs = sorted({v for m, c in ms for v in m}); idx = {v: i for i, v in enumerate(vs)}
    lo = np.array([float(box[v][0]) for v in vs]); hi = np.array([float(box[v][1]) for v in vs])
    grid = np.array(list(itertools.product((0, 1), repeat=len(vs))), dtype=bool)
    X = np.where(grid, hi, lo)
    val = np.zeros(len(X))
    for m, c in ms:
        t = np.full(len(X), float(c))
        for v in m: t = t * X[:, idx[v]]
        val += t
    return F(val.min()), F(val.max())


# diamond, symbols 0:a 1:c 2:b 3:d
dd = [(1, 0), (2, 0), (3, 1), (3, 2)]; syms = sp.symbols("g0:4")
box = {0: (F(3, 2), F(5, 2)), 1: (F(1, 2), F(3, 2)), 2: (F(5, 2), F(7, 2)), 3: (F(7, 2), F(9, 2))}
tr = forward_expr(4, dd, 0, syms)[3]; pol = tree_poly(tr, syms)
check("diamond_path_polynomial", sp.expand(pol - (syms[0] * syms[2] + syms[1] * syms[3])) == 0, pol)
iv_check("diamond_interval_forward", ev_tree(tr, box))
ms = monos(pol, syms); lo, hi = exact_range(ms, box); eq_exact("diamond_interval_exact", [lo, hi])
pre = [(1, 0), (2, 1), (3, 1), (3, 2)]
bx = {0: (F(1, 2), F(3, 2)), 1: (F(-1), F(1)), 2: (F(1), F(2)), 3: (F(1), F(2))}
tr = forward_expr(4, pre, 0, syms)[3]; pol = tree_poly(tr, syms); ms = monos(pol, syms)
check("prefix_path_polynomial", sp.expand(pol - (syms[0] * syms[2] + syms[0] * syms[1] * syms[3])) == 0, pol)
iv_check("prefix_interval_forward", ev_tree(tr, bx)); iv_check("prefix_interval_expanded", expanded_iv(ms, bx))
iv_check("prefix_interval_horner", horner_iv(ms, bx)); eq_exact("prefix_interval_exact", list(exact_range(ms, bx)))
check("prefix_occurrences_forward_horner", cs["prefix_occurrences_forward_horner"] == ["2", "1"])


def path_count(n, edges, s, t):
    c = [0] * n; c[s] = 1
    for v in range(s + 1, n): c[v] = sum(c[p] for ch, p in edges if ch == v)
    return c[t]


for regime, klo, khi, seed in (("mixed", -8, 8, 20261101), ("positive", 4, 12, 20261102)):
    rng = Rng(seed); n = 7; acc_ = tries = 0; frs, ers, hrs, nE, nP = [], [], [], [], []
    while acc_ < 300:
        tries += 1; edges, gain = [], []
        for v in range(1, n):
            for w in range(v):
                if rng.uniform() >= 0.45: continue
                k = rng.int(klo, khi); edges.append((v, w)); gain.append((F(k, 8) - F(1, 4), F(k, 8) + F(1, 4)))
        paths = path_count(n, edges, 0, n - 1)
        if paths < 2: continue
        syms = sp.symbols(f"g0:{len(edges)}")
        tr = forward_expr(n, edges, 0, syms)[n - 1]; pol = tree_poly(tr, syms); ms = monos(pol, syms)
        nv = len({v for m, c in ms for v in m})
        if nv > 14: continue
        acc_ += 1
        box = dict(enumerate(gain)); lo, hi = exact_range(ms, box); w_ = float(hi - lo)
        fi, ei, hi_ = ev_tree(tr, box), expanded_iv(ms, box), horner_iv(ms, box)
        frs.append(float(fi.hi - fi.lo) / w_); ers.append(float(ei.hi - ei.lo) / w_); hrs.append(float(hi_.hi - hi_.lo) / w_)
        nE.append(nv); nP.append(paths)
    c = cs[f"dag_{regime}_counts"]
    check(f"dag_{regime}_counts", int(c[0]) == acc_ and int(c[1]) == tries and abs(float(c[6]) - np.mean(nE)) < 1e-12
          and abs(float(c[7]) - np.mean(nP)) < 1e-12 and int(c[8]) == max(nP) and c[2] == c[0] and c[3] == c[0], (c, tries))
    for nm, arr in (("forward", frs), ("expanded", ers), ("horner", hrs)):
        g = [float(t) for t in cs[f"dag_{regime}_{nm}"]]
        mine = [float(np.median(arr)), float(np.mean(arr)), max(arr), sum(1 for t in arr if t <= 1 + 1e-9) / len(arr)]
        check(f"dag_{regime}_{nm}", all(abs(a - b) <= 1e-9 * max(1, abs(b)) for a, b in zip(g, mine)), (g, mine))

# --------------------------------------------------------------- counterfactual intervals
A_, X_, Y_ = I(F(19, 10), F(21, 10)), I(F(19, 20), F(21, 20)), I(F(39, 10), F(41, 10))
a_, x_, y_ = sp.symbols("a x y")
single = y_ + a_ * (3 - x_); stepwise = a_ * 3 + x_ + (y_ - (a_ + 1) * x_)
check("cf_interval_forms_equal", sp.expand(single - stepwise) == 0)
vals = [F(y) + F(a) * (3 - F(x)) for a in (F(19, 10), F(21, 10)) for x in (F(19, 20), F(21, 20)) for y in (F(39, 10), F(41, 10))]
eq_exact("cf_interval_exact", [min(vals), max(vals)])
iv_check("cf_interval_single_use", Y_ + A_ * (I(3) - X_))
iv_check("cf_interval_stepwise", A_ * 3 + X_ + (Y_ - (A_ + 1) * X_))
iv_check("cf_interval_expanded", I(3) * A_ + Y_ + I(-1) * A_ * X_)
iv_check("cf_interval_population_mean", A_ * 3)
iv_check("cf_interval_decoupled_worlds", A_ * 3 + X_ + (Y_ - (A_ + 1) * X_))

# --------------------------------------------------------------- smoother
for t in (2, 3, 4, 5, 6, 8):
    M = sp.eye(t) + wv * Lap(t); det = sp.expand(M.det()); coef = [sp.Poly(det, wv).coeff_monomial(wv ** k) for k in range(t)]
    K1T = sp.simplify(M.adjugate()[0, t - 1] / det)
    K1 = (sp.eye(t) + Lap(t)).inv()
    dK = sp.simplify(sp.diff(K1T, wv))
    mono = all(dK.subs(wv, sp.Rational(k, 7)) > 0 for k in range(1, 40))
    want = [",".join(str(c) for c in coef), 1, K1T.subs(wv, 1), 1 - K1[0, 0], K1T.subs(wv, sp.Rational(1, 2)), K1T.subs(wv, 2), 1, t]
    got = cs[f"smoother_T{t}"]
    check(f"smoother_T{t}", got[0] == want[0] and all(F(g) == F(str(wv_)) for g, wv_ in zip(got[1:], want[1:])) and mono and sp.simplify(K1T - wv ** (t - 1) / det) == 0, (got, want))
ok = all((sp.eye(t) + Lap(t)).det() == sp.fibonacci(2 * t) for t in range(2, 31))
K30 = (sp.eye(30) + Lap(30)).inv()
g = cs["smoother_fibonacci_T2_to_30"]
check("smoother_fibonacci_T2_to_30", g[0] == "1" and ok and abs(float(g[1]) - float(1 - K30[0, 0])) < 1e-15 and abs(float(g[3]) - float(K30[0, 29])) < 1e-25
      and sp.Rational(1) - K30[0, 0] == sp.fibonacci(58) / sp.fibonacci(60), g)

# --------------------------------------------------------------- year study
rng = Rng(20261103); N_, n = 2000, 6
pf = cons_ok = inside = syp = syc = wrong = ties = pairs = certall = 0; wd = wm = F(0)
for s_ in range(N_):
    tau = [None] * (n + 1); tau[1] = 2000 + F(rng.int(0, 143), 48)
    for v in range(2, n + 1): tau[v] = tau[v - 1] + F(rng.int(0, 38), 48)
    lags = []
    for v in range(2, n + 1):
        for w in range(1, v):
            if rng.uniform() >= 0.5: continue
            lag = tau[v] - tau[w]; dmin = F(math.floor(lag * 4), 4)
            lags.append((w, v, dmin, dmin + F(1, 2) if rng.uniform() < 0.5 else None))
    dates, point = [], [None] * (n + 1)
    for v in range(1, n + 1):
        if rng.uniform() < 0.7: y = F(math.floor(tau[v])); dates.append((v, y, y + 1)); point[v] = y
        else: mo = F(math.floor(tau[v] * 12), 12); dates.append((v, mo, mo + F(1, 12))); point[v] = mo
    if not all(point[b] - point[a] >= mn and (mx is None or point[b] - point[a] <= mx) for a, b, mn, mx in lags): pf += 1
    d = stn_dist(n + 1, stn_build(dates, lags))
    if not all(d[i][i] >= 0 for i in range(n + 1)): continue
    cons_ok += 1
    inside += all(-d[v][0] <= tau[v] <= d[0][v] for v in range(1, n + 1))
    for v in range(1, n + 1): wd += dates[v - 1][2] - dates[v - 1][1]; wm += d[0][v] + d[v][0]
    for a in range(1, n + 1):
        for b in range(a + 1, n + 1):
            if tau[a] == tau[b]: continue
            pairs += 1
            cab = d[b][a] is not None and -d[b][a] > 0; cba = d[a][b] is not None and -d[a][b] > 0
            if (cab and tau[b] < tau[a]) or (cba and tau[a] < tau[b]): wrong += 1
            certall += cab or cba; ties += point[a] == point[b]
            if dates[a - 1][1:] == dates[b - 1][1:]: syp += 1; syc += cab or cba
eq_exact("year_study_narratives_point_false_contradictions", [N_, pf])
eq_exact("year_study_interval_consistent_truth_inside", [cons_ok, inside])
eq_exact("year_study_pairs_certified_wrong", [pairs, certall, wrong, ties])
eq_exact("year_study_identical_boxes_certified", [syp, syc])
g = cs["year_study_mean_width_declared_minimal"]
check("year_study_mean_width_declared_minimal", abs(float(g[0]) - float(wd / (N_ * n))) < 1e-15 and abs(float(g[1]) - float(wm / (N_ * n))) < 1e-15, g)

# --------------------------------------------------------------- mask
with np.errstate(invalid="ignore"):
    lc, nq = 2, 3; L = lc + nq; tg = lc + 1
    M = np.array([[0.0 if (i < lc and j < lc) or (i >= lc and j < lc) or (i >= lc and j >= lc and j <= i) else -np.inf for j in range(L)] for i in range(L)])
    keep = np.array([[float(i != tg and j != tg) for j in range(L)] for i in range(L)])
    mult = M * keep
    assign = np.where(keep == 0, -np.inf, M)
    def sm(r): m = r.max(); e = np.exp(r - m); return e / e.sum()
    Rm = np.array([sm(r) for r in mult]); Ra = np.array([sm(r) for r in assign])
    cut = keep == 0
    eq_exact("mask_eq9_nan_logits_open_entries", [int(np.isnan(mult).sum()), int((cut & (mult == 0)).sum())])
    eq_exact("mask_eq9_nan_rows", [int(np.isnan(Rm).any(axis=1).sum())])
    check("mask_eq9_weight_last_query_on_target", float(cs["mask_eq9_weight_last_query_on_target"][0]) == Rm[L - 1, tg])
    check("mask_assign_nan_rows_weight_on_target", [int(np.isnan(Ra).any(axis=1).sum()), Ra[L - 1, tg]] == [int(cs["mask_assign_nan_rows_weight_on_target"][0]), float(cs["mask_assign_nan_rows_weight_on_target"][1])])
    Mf = np.where(np.isinf(M), -1e9, 0.0); mf = Mf * keep; Rf = np.array([sm(r) for r in mf])
    g = [float(t) for t in cs["mask_eq9_finite_fill_reopened_weights"]]
    check("mask_eq9_finite_fill_reopened_weights", g == [float(((M < 0) & (mf == 0)).sum()), Rf[L - 1, tg], Rf[tg, L - 1], Rf[0, tg]], g)

missing = sorted(set(cs) - {r["name"] for r in rows})
for m in missing: check(m, False, "not validated")
json.dump(dict(rows=rows, all_passed=all(r["passed"] for r in rows), lines=len(cs)), open(sys.argv[2], "w"), indent=1)
for r in rows:
    if not r["passed"]: print("FAIL", r["name"], r["detail"][:300])
print("lines", len(cs), "checked", len(rows), "ALL", all(r["passed"] for r in rows))
