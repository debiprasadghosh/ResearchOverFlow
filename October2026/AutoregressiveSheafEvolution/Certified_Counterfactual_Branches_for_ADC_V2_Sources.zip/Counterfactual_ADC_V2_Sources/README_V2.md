# Certified Counterfactual Branches in Autoregressive Do Calculus

Version 2 · Debi Prasad Ghosh · 1 November 2026

This revision edits the supplied Word manuscript, preserves the original census
tables and figure, and adds mathematical, neuroscience and harness contracts.

## Mathematical additions

- Theorem 4.6 bounds the effect of discarded factual information by total variation.
- Lemma 4.7 proves support and endpoint attainment for finite event ratios, including
  a zero-support face of the admissible model set.
- Theorem 4.8 checks conditional bounds directly in response coordinates, with
  witnesses and multipliers. Corollary 4.9 states fixed-query refinement reuse.
- Theorem 4.10 repairs a certificate with a certified positive support floor.
- Proposition 4.11 gives a three-world coupling obstruction and an extension test.
- Theorem 4.12 gives an exact linear-memory criterion for a declared moment family.
- Proposition 4.13 states the support-size and mechanism-cost factors in prediction.
- Corollary 4.14 explains point identification under monotone binary response and
  experimental marginals. Lemma 6.1 gives a sufficient semantic abstraction contract.

The ingredients are established mathematical tools specialized to ADC, not a new
general identification calculus. Neuroscience tests N1–N3, computational tests
H1–H4 and the learned harness remain prospective.

## Corrections that affect interpretation

- Edited-prefix generation is not automatically a world intervention.
- A posterior over response atoms differs from imposing population certainty for
  the case's evidence event.
- Algorithm 1's node product assumes independent node backgrounds. General
  confounding requires the appropriate joint response law.
- A zero evidence probability, inconsistent model class and failed computation have
  separate statuses. Endpoint division does not divide by zero.
- More population constraints refine a fixed query; new case evidence changes it.
- The Tian–Pearl LP sharpness statement concerns the reduced bivariate response
  class and specified summaries, not every full-DAG restriction.
- Comonotone local noise does not imply monotone treatment response for a whole DAG.
- Structural prediction counts do not measure total latency or inference complexity.
- The task rank is for real linear moment memory, not every ratio-only or nonlinear code.

## Files

- `Certified_Counterfactual_Branches_for_ADC_V2.docx`: current Word paper.
- `paper_v2.md` and `media/`: synchronized Markdown and its unchanged figure.
- `base_v1.docx`: supplied authoritative manuscript for the standalone edit builder.
- `additions_v2.md`, `build_v2.py`: text additions and current builder.
- `check_v2.py`, `checks_v2.json`: 33 new exact checks, including 2,287 feasible
  repair-grid cases and 1,800 total-variation distribution-pair/event cases.
- `validation_v1_rerun.json`, `validation_v1_rerun.log`: fresh run of the original
  independent validator; all 13 checks pass. Its exact rational witness checks and
  floating HiGHS comparisons remain distinct.
- `audit_v2.py`, `qa_v2.json`: document and source checks, not full XSD validation.
- `source_notes_v2.md`: literature provenance and inference scope.
- `inherited_v1/`: byte-identical original C# code, records, outputs, manuscripts,
  builder, figure and validation. The old builder needs an external style source;
  use `build_v2.py` for this revision.

## Reproduce

The new example checker uses only the Python standard library. The builder needs
python-docx 1.2 or later, lxml and Pandoc. From the bundle root:

```bash
python check_v2.py
python build_v2.py
pandoc Certified_Counterfactual_Branches_for_ADC_V2.docx --standalone --wrap=none --extract-media=. -o paper_v2.md
python audit_v2.py
```

Render and inspect the Word file after rebuilding. It uses native editable Word
equations. The content is reproducible; ZIP timestamps and review-comment dates
can differ. The new check JSON was generated in two clean processes and matched
byte for byte.

The unchanged inherited validator can be rerun with Python, NumPy and SciPy:

```bash
python inherited_v1/validate_cf.py inherited_v1/cs_cf.txt inherited_v1/out/cf_iv_records.json validation_v1_rerun.json
```

The completed revision's run limited that script to four worker processes and set
BLAS/OpenMP threads to one. It recreated every supplied census line and independently
checked exported witnesses; the largest floating discrepancy was
1.3322676295501878e-15. It did not regenerate the original C# output. The historical
.NET 8 census command is documented in `inherited_v1/README.md`.

No language model was trained or queried, no end-to-end harness was run, and no
human or animal experiment or wall-clock advantage is reported.

The new direct-certificate algebra is exercised by the finite Python examples.
The extended certificate-service interface and Algorithm 5 are specifications,
not features newly added to the unchanged C# census or a learned agent runtime.
