"""Structural and source QA. This is not full OOXML XSD validation."""
from pathlib import Path,PurePosixPath
from zipfile import ZipFile
import ast,hashlib,json,posixpath,re
from lxml import etree
from docx import Document
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parent
DOC=ROOT/'Certified_Counterfactual_Branches_for_ADC_V2.docx'
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
d=Document(DOC);base=Document(ROOT/'base_v1.docx')
with ZipFile(DOC) as z,ZipFile(ROOT/'base_v1.docx') as old:
    check('Word ZIP CRC',z.testzip() is None)
    names=set(z.namelist());parts={n:etree.fromstring(z.read(n)) for n in names if n.endswith(('.xml','.rels'))}
    check('Every XML part parses',len(parts)>10)
    missing=[]
    for name,r in parts.items():
        if not name.endswith('.rels'):continue
        owner=PurePosixPath(name).parent.parent if name!='_rels/.rels' else PurePosixPath('')
        for rel in r:
            if rel.get('TargetMode')=='External':continue
            target=rel.get('Target','')
            resolved=posixpath.normpath(str(owner/target)) if not target.startswith('/') else target.lstrip('/')
            if resolved not in names:missing.append((name,target))
    check('Internal relationships resolve',not missing)
    r=parts['word/document.xml'];b=etree.fromstring(old.read('word/document.xml'))
    nmath=len(r.xpath('.//m:oMath',namespaces=NS));ndisplay=len(r.xpath('.//m:oMathPara',namespaces=NS))
    check('Added equations are native',nmath>len(b.xpath('.//m:oMath',namespaces=NS)) and ndisplay==10)
    for name in old.namelist():
        if name.startswith('word/media/'):check('Original figure unchanged '+name,z.read(name)==old.read(name))
    check('One figure retained',len(d.inline_shapes)==1)
    check('Paragraph properties precede content',all(not p.findall(qn('w:pPr')) or p[0].tag==qn('w:pPr') for p in r.iter(qn('w:p'))))
    cm=parts['word/comments.xml'];ids={x.get(qn('w:id')) for x in cm}
    check('Four comments correctly anchored',len(ids)==4 and all({x.get(qn('w:id')) for x in r.iter(qn('w:'+tag))}==ids for tag in ('commentRangeStart','commentRangeEnd','commentReference')))
    text=' '.join(r.xpath('.//w:t/text()',namespaces=NS))
    check('No visible TeX fallback',re.search(r'\\(?:frac|mathbf|begin|lambda|nu|quad|mathrm|square|operatorname)\b',text) is None)
    eqs=[]
    for p in r.xpath('.//w:p[m:oMathPara]',namespaces=NS):
        t=''.join(p.xpath('.//w:t/text() | .//m:t/text()',namespaces=NS))
        matches=re.findall(r'\((\d+)\)',t)
        if matches:eqs.append(int(matches[-1]))
    check('Equation numbers in sequence',eqs==list(range(1,11)))
    check('Node product independence scope explicit','The nodewise product in Algorithm 1 uses independent backgrounds' in text)
    check('Zero denominator convention explicit','and one otherwise' in text)
    check('Reduced PN sharpness scope explicit','reduced two-event response class' in text)
    check('Comonotonicity interpretation corrected','does not by itself imply monotone treatment response' in text)
check('Author affiliation preserved',d.paragraphs[2].text==base.paragraphs[2].text and d.paragraphs[4].text==base.paragraphs[4].text)
check('Title updated',d.paragraphs[0].text=='Certified Counterfactual Branches in Autoregressive Do Calculus')
check('Four tables',len(d.tables)==4)
def cells(t):return [[''.join(c._tc.xpath('.//w:t/text() | .//m:t/text()')) for c in row.cells] for row in t.rows]
for i in range(3):
    before=cells(base.tables[i]);after=cells(d.tables[i])
    if i==1:before=[[s.replace('(3)','(9)') for s in row] for row in before]
    check('Inherited table '+str(i+1)+' data retained',before==after)
check('Witness table has eight atoms',len(d.tables[-1].rows)==9)
styles={s.style_id for s in d.styles}
missing_styles={x.get(qn('w:val')) for x in d.element.iter() if x.tag in (qn('w:pStyle'),qn('w:rStyle')) and x.get(qn('w:val')) not in styles}
check('All used text styles defined',not missing_styles)
check('Title subtitle headings black',all(s.font.color.rgb is not None and str(s.font.color.rgb)=='000000' for s in d.styles if s.name in ('Title','Subtitle','Heading 1','Heading 2')))
for tag,order in {'rPr':['lit','nor','scr','sty','brk','aln'],'dPr':['begChr','sepChr','endChr','grow','shp','ctrlPr']}.items():
    ix={qn('m:'+name):i for i,name in enumerate(order)}
    check('Math '+tag+' property order',all([ix.get(x.tag,99) for x in pr]==sorted(ix.get(x.tag,99) for x in pr) for pr in d.element.iter(qn('m:'+tag))))
for name in ('check_v2.py','build_v2.py','audit_v2.py'):ast.parse((ROOT/name).read_text())
check('Python sources parse',True)
new=json.loads((ROOT/'checks_v2.json').read_text());rerun=json.loads((ROOT/'validation_v1_rerun.json').read_text())
check('33 new exact checks pass',new['all_passed'] and len(new['checks'])==33)
check('13 inherited validator checks rerun and pass',rerun['all_passed'] and len(rerun['checks'])==13)
check('Inherited base copy identical',(ROOT/'base_v1.docx').read_bytes()==(ROOT/'inherited_v1/Counterfactual_Branches_for_ADC.docx').read_bytes())
md=(ROOT/'paper_v2.md').read_text()
check('H and N series present',all(x in md for x in ('H1 (','H2 (','H3 (','H4 (','N1 (','N2 (','N3 (')))
check('All added results present',all(x in md for x in ('Theorem 4.6','Lemma 4.7','Theorem 4.8','Corollary 4.9','Theorem 4.10','Proposition 4.11','Theorem 4.12','Proposition 4.13','Corollary 4.14','Lemma 6.1')))
images=re.findall(r'!\[[^\]]*\]\(([^)]+)\)',md)
check('Markdown figure resolves',len(images)==1 and all((ROOT/p).is_file() for p in images))
hashes={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'inherited_v1').rglob('*')) if p.is_file()}
result=dict(scope='Structural source and provenance checks; not full XSD validation.',all_passed=all(c['passed'] for c in checks),checks=checks,native_equations=nmath,native_display_equations=ndisplay,tables=4,figures=1,review_comments=4,inherited_file_sha256=hashes)
(ROOT/'qa_v2.json').write_text(json.dumps(result,indent=2)+'\n')
print(f'{len(checks)} structural/source checks pass; {nmath} native equations, {ndisplay} displays.')
