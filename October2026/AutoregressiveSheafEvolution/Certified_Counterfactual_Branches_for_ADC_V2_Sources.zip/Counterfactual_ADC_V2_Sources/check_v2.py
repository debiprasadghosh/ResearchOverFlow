"""Exact finite checks for the new counterfactual contracts.

Standard library only. This is not a learned-agent or timing benchmark.
Vertex enumeration is independent of the inherited Charnes-Cooper simplex.
"""
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
checks = []

def encode(v):
    if isinstance(v,F): return str(v)
    if isinstance(v,(tuple,list)): return [encode(x) for x in v]
    if isinstance(v,dict): return {k:encode(x) for k,x in v.items()}
    return v

def check(name, ok, detail=None):
    checks.append(dict(name=name,passed=bool(ok),detail=encode(detail)))
    if not ok: raise AssertionError(name)

def dot(a,b): return sum((F(x)*F(y) for x,y in zip(a,b)), F(0))

def rref(A,b=None):
    M=[[F(x) for x in row]+([] if b is None else [F(b[i])]) for i,row in enumerate(A)]
    n=len(A[0]) if A else 0; pivot=0; cols=[]
    for j in range(n):
        ix=next((i for i in range(pivot,len(M)) if M[i][j]),None)
        if ix is None:continue
        M[pivot],M[ix]=M[ix],M[pivot]
        scale=M[pivot][j]; M[pivot]=[x/scale for x in M[pivot]]
        for i in range(len(M)):
            if i!=pivot:
                s=M[i][j]
                M[i]=[x-s*y for x,y in zip(M[i],M[pivot])]
        cols.append(j);pivot+=1
        if pivot==len(M):break
    if b is not None and any(all(x==0 for x in row[:n]) and row[-1] for row in M):return None,cols
    return M[:pivot],cols

def rank(A):return len(rref(A)[1]) if A else 0

def solve(A,b):
    rows,cols=rref(A,b)
    if rows is None or len(cols)!=len(A[0]):return None
    q=[F(0)]*len(cols)
    for row,j in zip(rows,cols):q[j]=row[-1]
    return tuple(q)

def vertices(n,E,f,A=(),h=()):
    rows,cols=rref(E,f)
    if rows is None:return []
    eq=[r[:n] for r in rows];rhs=[r[-1] for r in rows]
    pool=list(zip(A,h))+[(tuple(F(i==j) for i in range(n)),F(0)) for j in range(n)]
    out=set()
    for active in combinations(pool,n-len(cols)):
        q=solve(eq+[list(a) for a,_ in active],rhs+[b for _,b in active])
        if q is not None and min(q)>=0 and all(dot(a,q)<=b for a,b in zip(A,h)):
            out.add(q)
    return sorted(out)

def ratio_bounds(vs,a,b):
    candidates=[(dot(a,q)/dot(b,q),q) for q in vs if dot(b,q)>0]
    return min(candidates),max(candidates)

def support_bound(v,E,f,A,h,nu,lam):
    assert all(x>=0 for x in lam)
    return dot(nu,f)+dot(lam,h)+max(F(v[i])-sum((F(nu[j])*F(E[j][i]) for j in range(len(E))),F(0))-sum((F(lam[j])*F(A[j][i]) for j in range(len(A))),F(0)) for i in range(len(v)))

# User-specified Tian-Pearl example, over (X,Y0,Y1) response atoms.
atoms=list(product((0,1),repeat=3))
obs_cells=[(1,1),(1,0),(0,1),(0,0)]
E=[[1]*8]+[[int(x==xc and (y1 if x else y0)==yc) for x,y0,y1 in atoms] for xc,yc in obs_cells]
E += [[y1 for x,y0,y1 in atoms],[y0 for x,y0,y1 in atoms]]
f=[F(1),F(2,5),F(1,10),F(1,10),F(2,5),F(7,10),F(1,5)]
a=[int(x==1 and y1==1 and y0==0) for x,y0,y1 in atoms]
b=[int(x==1 and y1==1) for x,y0,y1 in atoms]
vs=vertices(8,E,f);lo,hi=ratio_bounds(vs,a,b)
check('Tian Pearl example feasible',bool(vs),{'vertices':len(vs)})
check('Tian Pearl example sharp interval',lo[0]==F(3,4) and hi[0]==1,{'lower':lo,'upper':hi,'atom_order':atoms})
check('Tian Pearl decision certified',lo[0]>F(7,10))
check('PN denominator fixed',all(dot(b,q)==F(2,5) for q in vs))

# Support can have a zero face without preventing ratio endpoint attainment.
simplex=vertices(3,[[1,1,1]],[1]);a3=[1,0,0];b3=[1,1,0]
lo0,hi0=ratio_bounds(simplex,a3,b3)
check('Zero support face allowed',min(dot(b3,q) for q in simplex)==0 and max(dot(b3,q) for q in simplex)==1)
check('Conditional endpoints attained on positive support',lo0[0]==0 and hi0[0]==1 and dot(b3,lo0[1])>0 and dot(b3,hi0[1])>0)
cc_ok=True
for q in simplex:
    if dot(b3,q)>0:
        t=1/dot(b3,q);r=tuple(t*x for x in q)
        cc_ok &= t>=1 and sum(r)==t and dot(b3,r)==1 and tuple(x/t for x in r)==q
check('Charnes Cooper positive scale and inverse',cc_ok)
check('All zero evidence is undefined',all(dot([0,0,0],q)==0 for q in simplex))

# Direct original-coordinate ratio certificates and a tight repair.
A=[[-1,-1,0],[1,-1,0]];h=[-F(1,4),F(0)]
K=vertices(3,[[1,1,1]],[1],A,h);lower,upper=ratio_bounds(K,a3,b3)
v=[F(1,2),-F(1,2),0];lam=[F(0),F(1,2)]
BU=support_bound(v,[],[],A,h,[],lam)
BL=support_bound([-1,0,0],[],[],A,h,[],[0,0])
check('Direct upper certificate',BU==0 and upper[0]==F(1,2))
check('Direct lower certificate',BL==0 and lower[0]==0)
check('Ratio sharpness witnesses',dot(b3,lower[1])>0 and dot(b3,upper[1])>0,{'lower':lower,'upper':upper})
newh=[-F(1,4),F(1,20)];newK=vertices(3,[[1,1,1]],[1],A,newh)
delta=support_bound(v,[],[],A,newh,[],lam);repaired=F(1,2)+max(delta,0)/F(1,4)
newlo,newhi=ratio_bounds(newK,a3,b3)
check('Repair residual exact',delta==F(1,40))
check('Support floor repair is tight',repaired==F(3,5) and newhi[0]==repaired,{'residual':delta,'upper':repaired,'witness':newhi[1]})
check('Old number can be false after row change',newhi[0]>F(1,2))
refined=vertices(3,[[1,1,1]],[1],A+[[1,0,0]],h+[F(1,20)])
rlo,rhi=ratio_bounds(refined,a3,b3)
check('Fixed query refinement preserves outer bound',0<=rlo[0]<=rhi[0]<=F(1,2))
rare=F(1,1000);qrare=(rare,F(0),1-rare)
rareB=support_bound(v,[],[],[[1,-1,0]],[rare],[],[F(1,2)])
check('Rare evidence amplifies positive residual',dot(a3,qrare)/dot(b3,qrare)==1 and dot(v,qrare)==rareB==F(1,2000) and dot([1,-1,0],qrare)<=rare,{'denominator':dot(b3,qrare),'certified_residual':rareB,'ratio':F(1)})
grid_count=0;grid_ok=True
for d in (F(0),F(1,40),F(1,20),F(1,10),F(1,5)):
    cap=min(F(1),F(1,2)+2*d)
    for i in range(41):
        for j in range(41-i):
            q=(F(i,40),F(j,40),F(40-i-j,40))
            if q[0]+q[1]>=F(1,4) and q[0]-q[1]<=d:
                grid_count+=1;grid_ok &= dot(a3,q)/dot(b3,q)<=cap
check('Repair inequality rational grid',grid_ok,{'feasible_grid_cases':grid_count})

# Total variation: enumerate distributions and all events.
probs=[(F(i,4),F(j,4),F(4-i-j,4)) for i in range(5) for j in range(5-i)]
tv_count=0;tv_ok=True;tv_sharp=True
for p,q in product(probs,repeat=2):
    tv=sum(abs(x-y) for x,y in zip(p,q))/2
    pos=[int(x>y) for x,y in zip(p,q)]
    tv_sharp &= dot(pos,p)-dot(pos,q)==tv
    for event in product((0,1),repeat=3):
        tv_count+=1;tv_ok &= abs(dot(event,p)-dot(event,q))<=tv
check('Total variation rational grid',tv_ok,{'event_pairs':tv_count})
check('Total variation constant attained',tv_sharp)

# Pairwise anti-correlations cannot extend; equal correlations can.
triples=list(product((0,1),repeat=3))
dis=[sum(x[i]!=x[j] for i,j in ((0,1),(1,2),(0,2))) for x in triples]
check('Three world coupling obstruction',max(dis)==2 and 3>max(dis))
global_equal=[F(1,2) if x in ((0,0,0),(1,1,1)) else F(0) for x in triples]
check('Coherent pair family has global extension',sum(global_equal)==1 and all(sum(w for x,w in zip(triples,global_equal) if x[i]!=x[j])==0 for i,j in ((0,1),(1,2),(0,2))))

# Task memory retains joint numerator and denominator moments.
p=(F(1,4),F(1,4),F(1,2));q=(F(1,4),F(1,2),F(1,4))
C=[a3,b3];fullrank=rank([[1,1,1]]+C)-1
check('Linear moment rank is two',fullrank==2)
check('Marginal code confuses conditional tasks',dot(a3,p)==dot(a3,q) and dot(a3,p)/dot(b3,p)==F(1,2) and dot(a3,q)/dot(b3,q)==F(1,3))
check('Two moment code separates tasks',tuple(dot(c,p) for c in C)!=tuple(dot(c,q) for c in C))
direction=(F(0),F(1),-F(1))
check('Memory null direction changes required moment',sum(direction)==0 and dot(a3,direction)==0 and dot(b3,direction)!=0)

# Reconditioning is not population refinement.
population=(F(1,2),F(1,2)); evidence=(0,1)
mass=dot(evidence,population)
posterior=tuple(F(b)*q/mass for b,q in zip(evidence,population))
before=dot([0,1],population)
after=dot([0,1],posterior)
check('New case evidence can leave old interval',before==F(1,2) and after>before)
check('Abduction reweights rather than imposing population certainty',mass==F(1,2) and posterior==(F(0),F(1)) and dot(evidence,posterior)==1)
# Z=U is not a descendant of the intervention X; factual Y=X xor U reveals U.
z_before=dot([0,1],population);z_after=dot([0,1],posterior)
z_factual=[u for u in (0,1)];z_alternative=[u for u in (0,1)]
check('New evidence can change non descendant beliefs',z_before!=z_after and dot(z_factual,posterior)==dot(z_alternative,posterior))

# A finite commuting abstraction for every intervention and background atom.
def low(u,iv):
    x=u[0] if iv is None else iv
    return x,x^u[1],u[1]
def high(u,iv):
    x=u[0] if iv is None else iv
    return x,x^u[1]
ok=all(low(u,iv)[:2]==high(u,iv) for u in product((0,1),repeat=2) for iv in (None,0,1))
check('Abstraction square commutes exhaustively',ok)
us=list(product((0,1),repeat=2));e=[u for u in us if low(u,None)[:2]==(0,0)]
check('Abstraction preserves conditional counterfactual',bool(e) and F(sum(low(u,1)[1]==1 for u in e),len(e))==F(sum(high(u,1)[1]==1 for u in e),len(e))==1)
check('Incorrect abstraction has a counterexample',any(low(u,iv)[1]!=u[1] for u in us for iv in (0,1)))

# Binary monotone response plus fixed experimental marginals.
monotone_laws=[(F(i,4),F(j,4),F(4-i-j,4)) for i in range(5) for j in range(5-i)]
mtr_count=0;mtr_ok=True
for p00,p01,p11 in monotone_laws:
    if p00+p01>0:
        mtr_count+=1
        ey0=p11;ey1=p01+p11
        mtr_ok &= p01/(p00+p01)==(ey1-ey0)/(1-ey0)
check('Monotone response identity',mtr_ok,{'positive_support_laws':mtr_count})
comonotone_responses=[(int(F(i,100)<F(4,5)),int(F(i,100)<F(1,5))) for i in range(100)]
check('Comonotone noise need not be monotone treatment response',sum(y0>y1 for y0,y1 in comonotone_responses)==60)

result={'scope':'Exact finite examples and rational grid checks for the new proofs; no learned-agent, timing or biological experiment.',
        'all_passed':all(c['passed'] for c in checks),'checks':checks,
        'counts':{'new_exact_checks':len(checks),'repair_grid_cases':grid_count,'total_variation_event_pairs':tv_count}}
(ROOT/'checks_v2.json').write_text(json.dumps(result,indent=2)+'\n')
print(f"{len(checks)} exact checks passed; repair grid {grid_count}; TV event pairs {tv_count}.")
