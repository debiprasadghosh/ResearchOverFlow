<!-- BLOCK structure -->
## 1.3 Structure

Sections 2 and 3 specify the branch and its four algorithms. Section 4 develops the structural results, then adds support, certificate, coupling, memory and cost contracts. Section 5 retains the finite census and distinguishes its fresh validation from the new exact examples. Section 6 connects the mathematics to an agent harness, semantic abstraction, neuroscience and the related papers. Section 7 separates computational tests H1–H4 from biological hypotheses N1–N3. Sections 8 and 9 state limits and conclusions; the appendices give the proof obligations and reproduction path.

<!-- BLOCK branch -->
**Definition 2.2 (the common response space).** In a finite acyclic model, a response atom $r$ specifies a deterministic output for every parent configuration of every mechanism. A law $q\in\Delta_m$ over the permitted atoms supplies their joint background distribution. It is the same atom, or the same abducted law over atoms, that links the worlds. For a fixed factual event $e$, let $b_r=\mathbf1\{V^{\mathrm f}(r)\in e\}$ and $a_r=\mathbf1\{V^{\mathrm f}(r)\in e,\ Y_{x'}(r)=y\}$. Then $0\leq a_r\leq b_r\leq1$ and the query is $a^Tq/b^Tq$ on positive support.

For a known $q$, abduction produces the posterior $q_r^e=b_rq_r/(b^Tq)$. It reweights and removes incompatible atoms; it does not generally replace the population law $q$ by a population constraint $b^Tq=1$. With an uncertain $q$, retain the family of such posteriors induced by the admissible laws. Additional population reports restrict that family, whereas additional facts about this case change the conditioning event. A recorded background realization makes abduction degenerate; an already certified posterior can be reused without performing abduction again.

The unrestricted simplex over global response atoms allows arbitrary dependence between their components. If the causal model demands independent latent blocks, those restrictions must also be imposed; they are generally nonlinear. The linear programmes in this paper are exact only for the declared linear response model, and otherwise need an explicitly justified outer relaxation. An interval certified for that relaxation is valid for an included model class but need not be sharp for it.

<!-- BLOCK theory -->
## 4.1 Factual information and evidence support

**Theorem 4.6 (the information lost by discarding factual evidence).** Fix one finite SCM and an intervention. Let $\mu_e$ and $\mu_p$ be its background posteriors given full factual evidence $e$ and retained prefix information $p$, both of positive probability. For any counterfactual event with indicator $h(r)$,

$$
\left|\sum_r h(r)\mu_e(r)-\sum_r h(r)\mu_p(r)\right|
\leq \operatorname{TV}(\mu_e,\mu_p)
=\frac12\sum_r|\mu_e(r)-\mu_p(r)|. \qquad (2)
$$

*Proof.* Put $d_r=\mu_e(r)-\mu_p(r)$. Its positive and negative masses are equal to $\frac12\sum_r|d_r|$, since $\sum_r d_r=0$. The sum over any event lies between the negative and positive masses. Taking the event on the positive coordinates attains the upper value among all indicators, so the constant is sharp. $\square$

This is the standard total-variation event bound applied to the branch contract. The discarded information can include the actual treatment assignment as well as its later outcome. In a confounded model, the actual assignment itself can inform the background. Equal posteriors are sufficient for every branch query to agree; a particular query can agree even when the posteriors differ. Equation (2) therefore does not infer a causal error from textual distance or from suffix length.

**Lemma 4.7 (support and attainment).** Let $K$ be a nonempty compact polytope in $\Delta_m$, with event vectors $0\leq a\leq b\leq1$. If $\max_K b^Tq=0$, the conditional query is undefined throughout $K$. Otherwise the Charnes–Cooper programme in Algorithm 3 is feasible, every feasible point has $t\geq1$, and both conditional endpoints are attained by positive-support witnesses. A uniform positive lower bound on $b^Tq$ is not required for this finite event-query result.

*Proof.* A positive-support $q$ gives $t=1/(b^Tq)$ and $r=tq$, hence feasibility. Conversely $b^Tr=1\leq\mathbf1^Tr=t$ proves $t\geq1$ and permits $q=r/t$. The maps are inverse on the feasible sets, preserving the objective. Since $0\leq a^Tr\leq b^Tr=1$, the linear objective is bounded on a nonempty polyhedron. Its minimum and maximum are attained by the finite-dimensional linear-programming attainment theorem. Mapping the optimizers back gives the witnesses. $\square$

Zero-support models are excluded from the conditional query; they do not turn it into a probability conditional on an impossible event. Empty $K$, all-zero support, uncertain model identification and an unsuccessful solver are four different situations. Algorithm 3 must report them separately. Endpoint division uses a lower numerator bound divided by a positive upper denominator bound. If the lower denominator bound is zero, its probability upper bound is one, rather than a division by zero.

## 4.2 Direct certificates and their repair

Write $K=\{q\in\Delta_m:Eq=f,\ Aq\leq h\}$. Equality multipliers $\nu$ are free; inequality multipliers $\lambda$ must be nonnegative. For any linear objective $v$, define

$$
B_K(v;\nu,\lambda)=\nu^Tf+\lambda^Th+
\max_i\left(v_i-(E^T\nu+A^T\lambda)_i\right). \qquad (3)
$$

**Theorem 4.8 (a conditional bound checked in the original coordinates).** If $B_K(a-u b;\nu,\lambda)\leq0$, then $a^Tq/b^Tq\leq u$ for every $q\in K$ with positive denominator. If $B_K(\ell b-a;\tilde\nu,\tilde\lambda)\leq0$, the ratio is at least $\ell$. A feasible positive-support witness attaining a checked endpoint certifies sharpness. Under Lemma 4.7, every sharp endpoint admits such a multiplier certificate and witness.

*Proof.* Decompose $v^Tq$ into $\nu^TEq+\lambda^TAq$ and the residual dot product. Feasibility and $\lambda\geq0$ bound the first terms by $\nu^Tf+\lambda^Th$; simplex normalization bounds the residual by its largest coordinate. Thus $v^Tq\leq B_K(v;\nu,\lambda)$. Apply this to the two displayed objectives and divide by $b^Tq>0$. An attaining witness proves that the bound cannot improve. For completeness, let $u$ be the true upper endpoint. On positive support, $(a-u b)^Tq\leq0$; on zero support $a^Tq=0$ as well. Its maximum on $K$ is zero, attained at a positive-support ratio optimizer. Linear-programming duality, with a free normalization multiplier, supplies (3) equal to zero. The lower endpoint is identical with reversed objective. $\square$

The checker can therefore validate the returned conditional interval using rational dot products, multiplier signs, a residual maximum and primal feasibility. It need not trust the optimisation routine or rely on the transformed variables being named correctly. Exact arithmetic is still conditional on correct event meanings, response coordinates and causal assumptions. A witness with zero evidence probability cannot certify endpoint sharpness.

**Corollary 4.9 (refinement reuse for a fixed conditional query).** Suppose $K'\subseteq K$ is a checked refinement with some positive-support model, and $a,b$, mechanisms, coupling class and units are unchanged. Every old valid interval remains an outer interval. An old endpoint remains sharp whenever its attaining positive-support witness lies in $K'$. With the finite polytope assumptions, it remains sharp exactly when some old attaining positive-support model survives.

*Proof.* The positive-support part of $K'$ is a subset of that of $K$. Its image under the same ratio lies in the old interval. A surviving optimizer attains an endpoint; conversely Lemma 4.7 supplies an attaining optimizer if the refined endpoint is unchanged. $\square$

This gives the exact condition behind Algorithm 4. Survival of one selected witness is sufficient, not necessary. Reconditioning on a different case event changes $a,b$ and is not covered by this corollary. Nor can a newly adopted coupling assumption be hidden in an otherwise identical cache key.

**Theorem 4.10 (repair with a certified support floor).** Evaluate stored upper and lower multiplier vectors on the current rows, obtaining residual bounds $\delta_U$ for $a-u b$ and $\delta_L$ for $\ell b-a$ through (3). If the current model set certifies $b^Tq\geq\beta>0$, then a valid repaired interval is

$$
\left[\max\{0,\ell-[\delta_L]_+/\beta\},\
\min\{1,u+[\delta_U]_+/\beta\}\right],\quad [s]_+=\max\{s,0\}. \qquad (4)
$$

*Proof.* The upper residual inequality gives $a^Tq\leq u b^Tq+\delta_U$. If $\delta_U\leq0$, the old upper bound holds; otherwise division and $b^Tq\geq\beta$ give the upper term in (4). The lower residual gives the corresponding lower term. The event probability lies in $[0,1]$, permitting the clipping. $\square$

For example, let $a=(1,0,0)$ and $b=(1,1,0)$. Impose $q_1+q_2\geq1/4$ and $q_1-q_2\leq0$. Multiplier $1/2$ on the second row proves $u=1/2$. Replace its right-hand side by $1/20$. The same multiplier gives $\delta_U=1/40$, and (4) gives $u'=3/5$. The witness $(3/20,1/10,3/4)$ attains it. The old number is false while its multiplier remains useful. If no positive support floor is available and a residual is positive, this repair need not give a nontrivial result; solve the conditional problem or retain a coarser valid interval. Rare factual evidence can amplify reconstruction error.

## 4.3 Coherent worlds and sufficient task memory

**Proposition 4.11 (pairwise couplings need not share one background model).** Pairwise response kernels with matching one-world marginals and identical-input consistency need not extend to a joint law over responses at three distinct parent configurations.

*Proof.* At three configurations let binary responses $R_1,R_2,R_3$ each be fair, and specify that every distinct pair disagrees with probability one. Each pair is a valid fair antithetic coupling. For any deterministic triple,

$$
\mathbf1\{R_1\ne R_2\}+\mathbf1\{R_2\ne R_3\}
+\mathbf1\{R_1\ne R_3\}\leq2. \qquad (5)
$$

The pair specifications require its expectation to be three, a contradiction. Diagonal kernels can still impose identical outputs at identical configurations; they do not remove the contradiction. $\square$

A finite extendability test introduces one nonnegative weight $\theta_r$ for each permitted deterministic response vector and requires its pairwise marginals to equal the proposed kernels. Feasibility gives a common response law; an exact infeasibility certificate rejects the package. The three census couplings are globally defined response constructions, so this observation does not invalidate them. It limits a future learned implementation that proposes pair kernels independently. Horizontal overlap agreement alone does not supply the missing global probabilistic realization.

**Theorem 4.12 (linear memory sufficient for a declared moment contract).** Let a nonempty convex posterior family have affine direction space $T=\operatorname{span}(K-K)$. Let rows of $C$ be the response-atom moments that future tasks require, including relevant joint numerators and evidence denominators. A linear memory $z=Lq$ determines every $Cq$ on $K$ exactly if and only if

$$
\ker L\cap T\subseteq\ker C. \qquad (6)
$$

The least number of real linear memory coordinates is $\operatorname{rank}(C|_T)$. For the full simplex it is $\operatorname{rank}\!\begin{bmatrix}\mathbf1^T\\ C\end{bmatrix}-1$.

*Proof.* If two posteriors have equal memory, their difference lies in the left-hand null space, so (6) makes their required moments equal. Conversely take a direction violating (6) and a relative-interior point of $K$. Sufficiently small positive and negative displacements along that direction remain in $K$, have equal memory and different task moments. For the dimension statement, (6) forces $\operatorname{rank}(L|_T)\geq\operatorname{rank}(C|_T)$. Choosing rows spanning the task map on $T$, and retaining the known affine offset, attains equality. On the full simplex $T=\mathbf1^\perp$, yielding the displayed rank. $\square$

This is an exact linear moment contract, not a universal lower bound for arbitrary nonlinear codes, finite-bit storage or ratios alone. A ratio can require fewer coordinates than recovering its numerator and denominator separately. For the declared moment contract, however, a memory retaining only $q_1$ confuses $(1/4,1/4,1/2)$ with $(1/4,1/2,1/4)$. Both initially give $P(R=1)=1/4$, but conditioning on the first two atoms gives $1/2$ and $1/3$. Retaining both $q_1$ and $q_1+q_2$ supports this continuation. Expanding the future evidence family can therefore require new memory coordinates even when the old answer remains correct.

## 4.4 The cost covered by causal locality

**Proposition 4.13 (prediction locality with its actual cost factors).** Fix the mechanisms, the abducted law, a factual assignment for each retained response atom, intervention nodes $S$ and requested outcomes $Q$. Let $R$ be the nodes reachable from $S$ and ancestral to $Q$, including endpoints. At each fixed atom, only nodes in $R$ need new evaluation; intervened nodes are assigned their replacement values. If evaluating node $i$ costs $c_i$, the new mechanism-evaluation work over $m$ retained atoms is at most $m\sum_{i\in R}c_i$, treating an intervention assignment as its declared constant-cost operation.

*Proof.* Outside $S$ and its descendants, shared background arguments and unchanged mechanisms give identical values by induction. Outside the ancestors of $Q$, a value is unnecessary for the requested outputs. Reevaluate the intersection in topological order. Summing the node costs over the retained atoms proves the bound. $\square$

This bound excludes parsing the text, locating the subgraph, obtaining the posterior, solving or checking bounds, looking up records and rendering a transcript. Graph discovery can itself cost $O(|V|+|E|)$ without an index. The response support can be exponentially large; exact probabilistic inference may depend on graphical width. A sparse descendant set therefore does not prove low total latency. Dense causal dependence can make nearly the whole suffix relevant. With evidence fixed, the census counts only the prediction part of this contract.

## 4.5 Why the assumption ladder reaches a point

**Corollary 4.14 (monotone binary response with experimental marginals).** If $Y_1\geq Y_0$ almost surely and $P(Y_0=0)>0$, then

$$
P(Y_1=1\mid Y_0=0)=\frac{P(Y_1=1)-P(Y_0=1)}{1-P(Y_0=1)}. \qquad (7)
$$

*Proof.* Monotonicity excludes $Y_0=1,Y_1=0$. Hence $P(Y_1=1,Y_0=0)=P(Y_1=1)-P(Y_0=1)$, while the denominator is $1-P(Y_0=1)$. Division proves the claim. $\square$

This elementary response-type identity explains the zero-width experimental-plus-monotonicity census result. Monotonicity alone does not supply the two marginals, and a comonotone noise construction alone does not supply the displayed treatment-response order. If the evidence denominator is zero, the conditional probability remains undefined.

<!-- BLOCK examples -->
## 5.5 New exact examples and validation provenance

The revision adds rational checks for (2)–(7), zero-support models, endpoint certificates, support-sensitive repair, coupling extendability and sufficient memory. The worked probability-of-necessity data are $P(x,y)=2/5$, $P(x,y')=1/10$, $P(x',y)=1/10$, $P(x',y')=2/5$, with $P(y_x)=7/10$ and $P(y_{x'})=1/5$. Equation (9) gives the sharp interval $[3/4,1]$. Exact vertex enumeration over the eight bivariate response types independently attains both endpoints. A decision requiring $PN>7/10$ is therefore certified without point identification. The example's numbers are specified rational inputs, not new population measurements.

For support and repair, the examples attain the values stated in Lemma 4.7 and Theorem 4.10. The three-world obstruction has no extending response law, while the all-equal pair family has an explicit extension. Exact matrix elimination verifies the moment rank and the two distinct conditional answers in Theorem 4.12. Finite rational grids check the total-variation and repair inequalities; those checks illustrate the proved statements rather than establishing their generality.

The unchanged Version 1 Python validator was rerun against the supplied C# output and exported witnesses, with four worker processes. All 13 checks pass again; the maximum floating discrepancy remains $1.3322676295501878\times10^{-15}$. Its rational witness checks are exact; its HiGHS comparisons use floating arithmetic. The C# census was not regenerated; the new certificate service and Algorithm 5 are interface extensions. The original source, output, validation and figure remain unchanged in the bundle. New example results are produced in two clean Python processes and compared byte for byte. No language model, agent runtime, timing study or biological experiment is added.

<!-- BLOCK harness -->
## 6.1 An interface for branches and certificates

The proposed harness extends the six-component IDC interface. A semantic registry binds the case, event meanings, units, graph, mechanism and coupling versions. A proposal policy suggests an intervention and outcome. A primitive checker validates support, mechanism replacements, dependency claims and the certificates in Theorem 4.8. An append-only operation store keeps factual and alternative records separately. The interval engine solves or repairs the conditional query. The scheduler chooses whether a checked interval already meets the decision requirement or whether more inference or evidence is useful. These are interface requirements, not an implemented learned agent.

The branch key must include the factual evidence event as well as the evidence snapshot: a new observation about the same case can change the conditional query even if all population arrays are unchanged. It must also include the coupling or admissible response class. A value computed under comonotonicity cannot silently serve a request allowing all couplings. A selected coupling may yield a point answer labelled as conditional on that assumption; it does not make the broader class point identified.

**Algorithm 5 (checked branch service).** Pin the request snapshot and semantic map. Check that the model set is nonempty and determine whether the evidence has positive support. Retrieve a record only under a matching query and contract or a checked transport. Try a surviving endpoint witness and multiplier certificate; otherwise use Algorithm 3 or Theorem 4.10. Reevaluate only the necessary structural operations under Proposition 4.13, with the abducted state fixed. Return the achieved interval, coupling scope and status; append the record. A latest-state request additionally checks its registry version at commit. An undefined conditioning event, certified inconsistency, valid outer interval, sharp interval, identified point and unverified computation have separate statuses.

SWE-agent studies how model–computer interfaces affect software-agent behavior (Yang et al., 2024). Agent Lightning separates agent execution from reinforcement training (Luo et al., 2025). Anthropic's later account separates generation and evaluation and discusses orchestration costs (Anthropic, 2026). These are harness precedents, not counterfactual identification results. A language-model evaluator can propose concerns or tests, while the exact checker accepts only the mathematical claim its premises establish. A learned route policy may optimize time, memory, solver calls and external observations separately; correctness remains a constraint on every accepted result, rather than a reward traded against token count.

## 6.2 Generator counterfactuals and semantic abstraction

Chatzi et al. (2025), building on Gumbel-max SCMs, construct counterfactual token generation without retraining the language model. If the original noise is unavailable, it can be abducted from the realized tokens under that model; logging noise is useful but not a prerequisite. A stored seed alone is sufficient only when it reproduces the declared noise coordinates and sampling policy after branching. Keeping noise indexed by generation step and vocabulary item makes the intended sharing explicit. The chosen coupling is part of the generator model and is not established uniquely by next-token probabilities (Oberst & Sontag, 2019).

Pona et al. (2025) instead develop abstract counterfactuals around meaningful characteristics of language-agent actions, including token and latent interventions. Their experiments motivate semantic intervention interfaces. For ADC, interpreting a string as an action still needs a declared map to the described system and a checked intervention meaning. A generated narrative's coherence or semantic similarity is not a certificate for the physical model.

**Lemma 6.1 (a sufficient abstraction contract).** Let $F_I(u)$ and $F^{\mathrm H}_{\omega(I)}(u^{\mathrm H})$ be the low- and high-level assignments under corresponding interventions, including the factual intervention $I=\varnothing$. Suppose maps $\tau$ and $\eta$ satisfy $\tau(F_I(u))=F^{\mathrm H}_{\omega(I)}(\eta(u))$ for every allowed $u,I$, and the high-level background law is the pushforward of the low-level law by $\eta$. If factual evidence and requested outcomes are pullbacks of high-level events, their positive-support conditional counterfactual probabilities agree at both levels.

*Proof.* The commuting identity identifies the factual evidence events and the interventional outcome events pointwise under $\eta$. The pushforward identity preserves the probabilities of their intersection and of the factual evidence. Dividing these equal quantities proves the conditional equality. $\square$

The lemma is a sufficient semantic contract. It does not follow from a small reconstruction loss or a few successful interchange probes. Exact finite models can check it exhaustively; learned continuous models need restricted task domains or certified error statements. A failed commutation square identifies which claimed abstraction has not been justified. The context cover, physical causal graph, evidence order, operation graph and learned layer order retain separate meanings; a world label is additional scope metadata, not a substitute for any of them.

## 6.3 Neuroscience as evidence for components and a source of tests

Human counterfactual thinking includes episodic construction, valuation of unchosen outcomes and learning from hypothetical feedback. These processes overlap with, but do not establish, Pearl-style inference under a known SCM. We use neural findings to constrain functional hypotheses rather than assigning a brain region to an LP variable or assuming that a vivid imagined alternative is causally certified.

Schuck and Niv (2019) detected sequential structure in hippocampal fMRI patterns during rest following a nonspatial task. Its strength related to the fidelity of orbitofrontal task-state representations. This supports studying replay of structured task information; it does not show that a factual episode is retained as an immutable log or that replay preserves a cross-world noise coupling. The ADC counterpart is retaining enough joint information for later branch queries, as Theorem 4.12 specifies.

Doll et al. (2015) associated model-based choices with prospective neural representations of future paths. Boorman et al. (2011) found signals related to the best unchosen option and learning from hypothetical feedback in a network including lateral frontopolar cortex. These are evidence for prospective evaluation and alternative-option learning. They do not by themselves distinguish a level-2 action evaluation from a level-3 same-case counterfactual. An experiment testing the ADC analogy must manipulate evidence about a shared hidden cause while keeping the proposed alternative action fixed.

Li et al. (2025) reported hippocampal and orbitofrontal representations of learned social hierarchies and increased connectivity during inference-based decisions. This is a recent correlate of relational inference, not a causal demonstration of abduction or a neural certificate checker. It motivates asking whether a representation of common background circumstances mediates the transfer from factual evidence to an alternative-case judgement. The relevant test needs behavior that separates a full-evidence model from a prefix-only model.

Morales-Torres et al. (2026) studied episodic counterfactual plausibility in three experiments. Earlier-generated alternatives tended to be more plausible and vivid, without parallel changes in difficulty. This constrains any claim that computational ease alone determines perceived plausibility. In a harness, proposal order may depend on a learned plausibility policy; acceptance still requires a certificate. In the brain, the suggested separation between constructing an alternative and evaluating its credibility remains a functional hypothesis, not evidence of formal proof checking.

No cited study establishes exact exogenous-state preservation, Charnes–Cooper computation, an append-only cortical store or a neural implementation of (3). Representations and memories can change. The testable analogy concerns which information influences a judgement and which relationships survive task-directed retention. N1–N3 below state the proposed discriminating tests.

## 6.4 What the related papers actually supply

The ADC sequential-evidence paper supplies mechanism semantics, response fibres and evidence contracts (Ghosh, 2026a). The IDC paper supplies scoped reuse and multiplier checks (Ghosh, 2026b). The task-observability paper asks when compatible, anchored latent data control a declared task and distinguishes decoded agreement from realized execution (Ghosh, 2026c). These contracts support the branch interface, but do not identify an unspecified coupling.

Task-sufficient geometry concerns declared reductions, objective schemas and certification in adaptive optimisation (Ghosh, 2026d). It is not already a minimum-memory theorem for arbitrary counterfactuals; Theorem 4.12 gives the narrower linear moment result needed here. Certified archive memory separates proposal, evidence and reporting stores (Ghosh, 2026e). It motivates protecting the evidence needed for abduction rather than treating a selected proposal archive as an unbiased record of reality. None of the five papers warrants retaining every token forever: a checked sufficient posterior or task frontier can replace a verbatim trace for the specified future queries. Changing those queries can change the required frontier.

<!-- BLOCK neurotests -->
## 7.1 Biological hypotheses

The computational H-series concerns a future implementation. The following N-series concerns human behavior and, where feasible, neural measurements. For each, fix the task, contrast, scoring model, power, delay and a minimum effect $\Delta>0$ before data collection. An upper confidence endpoint below the registered effect refutes that quantitative prediction; an interval crossing it is inconclusive. These tests can challenge the proposed functional analogy without refuting the conditional mathematical theorems.

**N1 (diagnostic factual evidence informs alternative worlds).** After matched learning of a finite causal task, a late factual observation diagnostic of a hidden background cause will shift same-case counterfactual judgements more than a matched nondiagnostic observation, by at least the registered effect. Keep the alternative action, token order and exposure constant. Compare full-evidence abduction with prefix-only and associative alternatives on held-out cases. Equal predictive performance within a prespecified equivalence band weakens the claimed shared-background account. This tests how evidence is used, not whether the brain stores a literal value of $U$.

**N2 (alternative construction respects task dependencies).** At fixed factual evidence, changing an antecedent will alter decoded task representations and behavioral predictions more for its causal descendants than for matched non-descendants, by the registered contrast. Match attention, rehearsal and sensory change, and use independently learned decoders rather than assuming fixed neurons. Equal changes after these controls refute the selective-dependency prediction. New evidence can change beliefs about non-descendants, so that manipulation belongs in N1 and must not be counted as an N2 invariance failure.

**N3 (joint information supports later conditional questions).** A retention condition preserving learned joint relations will support future conditional counterfactual judgements better than retention of matched marginal facts, by the registered effect, while marginal recall is equated. Include an explicit relational-rehearsal control. Equivalent conditional performance refutes the predicted advantage on that task family. Theorem 4.12 predicts the insufficiency of particular moment codes, not inevitable dependency loss during cortical consolidation.

<!-- BLOCK obligations -->
## Appendix B Scope of the added guarantees

The certificate theorems assume a correctly specified nonempty finite response polytope, correctly aligned events and rows, and exact or validated arithmetic. Lemma 4.7 concerns bounded event ratios and a polyhedral model set; a general noncompact model class can fail endpoint attainment. Theorem 4.10 additionally needs a certified positive support floor for nonzero residual repair. Proposition 4.11 requires a coherent multiworld extension rather than independent pairwise choices. Theorem 4.12 concerns real linear moment memory on a convex family. Proposition 4.13 fixes the posterior and counts mechanism evaluations separately from inference. Lemma 6.1 assumes pointwise commutation on its declared domain. None of these hypotheses is supplied by text fluency, a cache hit, horizontal agreement or biological analogy alone.
