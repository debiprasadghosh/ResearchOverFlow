---
subtitle: Shared background models and task sufficient memory
title: Certified Counterfactual Branches in Autoregressive Do Calculus
---

Debi Prasad Ghosh

Version 2, 1 November 2026

Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India

## Abstract

A counterfactual branch in Autoregressive Do Calculus (ADC) retains factual evidence, abducts background circumstances, replaces a mechanism and evaluates an alternative for the same case. Recomputing a Transformer cache alone does not establish those semantics. We extend the branch contract with support, certificate and memory results. On a finite response polytope, event-ratio extrema are attained even when some admissible models assign the evidence zero probability. Upper and lower conditional bounds admit direct linear residual certificates in the original response coordinates. A positive support floor controls certificate repair after changed constraints; rare evidence can amplify a small residual. Pairwise compatible world couplings need not extend to one response law, as a three-world obstruction shows. A null-space criterion characterizes exact linear memory for declared future numerator and denominator moments. Prediction locality is proved with its support-size and mechanism-cost factors, separately from abduction and text rendering. The inherited census is preserved: its three couplings share observational and interventional laws but are not all equal on any of the 18,939 queried probabilities of necessity per grid; counterfactual intervals can move outside an old interval after new case evidence. The supplied independent validator passes all 13 checks again. New rational examples check the added formulas without regenerating the C# census. The expanded harness binds case identity, evidence, coupling and query scope; a commuting abstraction lemma connects semantic interventions to conditional counterfactuals. Replay, prospective choice, alternative-option learning and recent relational-inference findings motivate three falsifiable neuroscience hypotheses. Neither a neural implementation of these certificates nor an end-to-end agent speed advantage is established.

Keywords counterfactuals; abduction; response types; conditional certificates; evidence support; coherent couplings; task sufficient memory; neuroscience; AI harness

# 1 Introduction

The causal hierarchy has three levels (Pearl, 2009; Bareinboim et al., 2022). Association concerns $P(Y \mid X = x)$. Intervention concerns $P\left( Y \mid do(X = x\prime) \right)$. A counterfactual concerns $P\left( Y_{x\prime} = y \mid E = e \right)$: given the evidence $e$ about what actually happened to a case, how would its outcome have behaved under $x\prime$? The causal hierarchy theorem shows that, in general, quantities at a higher level are not determined by data from lower levels (Bareinboim et al., 2022).

An autoregressive Transformer conditions on a prefix and extends it. Editing an earlier token can invalidate dependent later hidden states, typically requiring recomputation of much of the suffix under dense causal attention. The causal level is fixed by the semantics, not by that work. Bare regeneration from an edited prefix is conditional generation; only a justified causal interpretation licenses an intervention claim. When it abandons factual evidence relevant to the case's background circumstances, it omits the corresponding abduction. A separate factual record or certified posterior can retain that information even if the rendered alternative needs a new cache.

A Transformer can execute an interpreter for counterfactual queries. With recorded sampling noise, its own token generator is a structural causal model and counterfactual token sequences can be produced (Oberst & Sontag, 2019; Chatzi et al., 2025). That construction concerns the text generator and requires a noise coupling not identified by one-world token probabilities alone. The present paper concerns counterfactuals about the world that the text describes, and treats the coupling choice as part of the declared model.

## 1.1 Literature survey

Autoregressive Do Calculus (Ghosh, 2026a) represents events, mechanisms and sequential evidence. Interval Do Calculus (Ghosh, 2026b) certifies intervals over admissible models and specifies reuse by refinement, witnesses and multipliers. Task observability (Ghosh, 2026c) concerns which task quantities a retained state can determine. Task-sufficient geometry (Ghosh, 2026d) and certified archive memory (Ghosh, 2026e) concern what an adaptive computation must retain. The operation-certificate work separates value agreement, operation licences and latent execution (Ghosh, 2026f). This paper adds a counterfactual branch to that programme.

The three-step procedure of abduction, action and prediction, and the twin network that links factual and counterfactual worlds, are classical (Balke & Pearl, 1994; Pearl, 2009). Probabilities of causation and their bounds are due to Tian and Pearl (2000). Complete counterfactual identification procedures, ID\* and IDC\*, are given by Shpitser and Pearl (2008). Linear-fractional programmes reduce to linear programmes by the Charnes--Cooper transformation (Charnes & Cooper, 1962). Monotone treatment response is a standard partial-identification assumption (Manski, 1997). We use these results; the contribution is their integration into ADC as checked operations, with exact numerics.

## 1.2 Contribution and status

We retain the record contract, four branch algorithms, the structural propositions and the exact finite census. This revision adds Theorems 4.6, 4.8, 4.10 and 4.12; Lemmas 4.7 and 6.1; Corollaries 4.9 and 4.14; and Propositions 4.11 and 4.13. Their ingredients are established total-variation, linear-programming, marginal-consistency, observability and abstraction arguments specialized to the ADC branch interface. We claim scoped integration and explicit proof obligations, not a new general counterfactual identification algorithm. The neuroscience and learned-harness predictions are prospective. No language model is trained or queried, and no wall-clock speed advantage is measured.

## 1.3 Structure

Sections 2 and 3 specify the branch and its four algorithms. Section 4 develops the structural results, then adds support, certificate, coupling, memory and cost contracts. Section 5 retains the finite census and distinguishes its fresh validation from the new exact examples. Section 6 connects the mathematics to an agent harness, semantic abstraction, neuroscience and the related papers. Section 7 separates computational tests H1--H4 from biological hypotheses N1--N3. Sections 8 and 9 state limits and conclusions; the appendices give the proof obligations and reproduction path.

# 2 Three questions about one case

**Table 1 The causal hierarchy for one case**

  ------------------------------------------------------------------------------------------------------------------------------------------------------
  **Level**        **Question**                                                                               **Object**
  ---------------- ------------------------------------------------------------------------------------------ ------------------------------------------
  Association      What accompanies $X = x$?                                                                  $P(Y \mid X = x)$

  Intervention     What happens if $X = x\prime$ is imposed?                                                  $P\left( Y \mid do(X = x\prime) \right)$

  Counterfactual   Given what actually happened, what would have happened to this case under $X = x\prime$?   $P\left( Y_{x\prime} \mid E = e \right)$
  ------------------------------------------------------------------------------------------------------------------------------------------------------

Let a structural causal model have assignments $V_{i} = f_{i}\left( {Pa}_{i},U_{i} \right)$ with background variables $U$. For a finite model,

$$P\left( Y_{x\prime} = y \mid E = e \right) = \sum_{u}^{}\mathbf{1}\{ Y_{x\prime}(u) = y\}\, P(u \mid E = e).\quad\quad\ \ \ \ (1)$$

The factual and hypothetical outcomes are linked through the same $u$. For $Y = 2X + U$, the observation $X = 3,Y = 11$ gives $U = 5$, and imposing $X: = 1$ gives $Y_{1} = 7$. The factual record $Y = 11$ is retained and used to infer $U$; the counterfactual outcome is not forced to equal it.

Correcting an erroneous record is a different operation. It revises the evidence or the model. A counterfactual leaves the factual record unchanged and adds a separately labelled alternative.

**Definition 2.1 (counterfactual branch record).** A branch record contains a case identity, model and mechanism versions, a factual evidence snapshot, an abducted background law or response-type constraint set, a branch identity, the intervention as a mechanism replacement, the requested outcome, dependencies and a certificate or interval status. The factual branch keeps the accepted observations and their provenance. The counterfactual branch keeps the replacement, the shared background identity and the predicted consequences.

The horizontal sheaf of ADC organises overlapping descriptions within each world. Across worlds, the branch must declare what is shared: case identity, background circumstances, unaffected mechanisms, units and variable meanings. Gluing must not impose $Y^{\text{factual}} = Y^{\text{counterfactual}}$ because both name the same physical quantity. The sheaf supplies compatibility checks within a world; the causal model supplies the connection between worlds.

**Definition 2.2 (the common response space).** In a finite acyclic model, a response atom $r$ specifies a deterministic output for every parent configuration of every mechanism. A law $q \in \Delta_{m}$ over the permitted atoms supplies their joint background distribution. It is the same atom, or the same abducted law over atoms, that links the worlds. For a fixed factual event $e$, let $b_{r} = \mathbf{1}\{ V^{f}(r) \in e\}$ and $a_{r} = \mathbf{1}\{ V^{f}(r) \in e,\ Y_{x\prime}(r) = y\}$. Then $0 \leq a_{r} \leq b_{r} \leq 1$ and the query is $a^{T}q/b^{T}q$ on positive support.

For a known $q$, abduction produces the posterior $q_{r}^{e} = b_{r}q_{r}/\left( b^{T}q \right)$. It reweights and removes incompatible atoms; it does not generally replace the population law $q$ by a population constraint $b^{T}q = 1$. With an uncertain $q$, retain the family of such posteriors induced by the admissible laws. Additional population reports restrict that family, whereas additional facts about this case change the conditioning event. A recorded background realization makes abduction degenerate; an already certified posterior can be reused without performing abduction again.

The unrestricted simplex over global response atoms allows arbitrary dependence between their components. If the causal model demands independent latent blocks, those restrictions must also be imposed; they are generally nonlinear. The linear programmes in this paper are exact only for the declared linear response model, and otherwise need an explicitly justified outer relaxation. An interval certified for that relaxation is valid for an included model class but need not be sharp for it.

# 3 Algorithms

**Algorithm 1 (counterfactual branch).** *Input:* a finite binary DAG with independent node backgrounds and globally coherent within-node response couplings, factual evidence $e$, an action $X: = x\prime$ and an outcome event. *Output:* $P\left( Y_{x\prime} = y \mid e \right)$ exactly, or an interval from Algorithm 3.

\(1\) *Abduction.* Enumerate joint factual and counterfactual assignments $(v,w)$ with $w_{X} = x\prime$. Weight each node $i \neq X$ by the coupling kernel $K_{i}\left( v_{i},w_{i} \mid {pa}_{i}(v),{pa}_{i}(w) \right)$, which gives the probability that one shared $U_{i}$ produces $v_{i}$ at the factual parent value and $w_{i}$ at the counterfactual one. Weight $X$ by its factual mechanism only. (2) *Action.* The counterfactual world uses $x\prime$ for every child of $X$. (3) *Prediction.* Sum the weights consistent with $e$ and with the requested counterfactual outcome, and divide by the weight consistent with $e$. All weights are exact integers on a fixed grid scale.

The nodewise product in Algorithm 1 uses independent backgrounds across mechanisms, as in the DAG census. A model with dependent background components instead needs the declared joint law in (1), or an equivalent valid inference procedure. Multiplying locally specified pair kernels does not establish arbitrary confounding semantics.

**Algorithm 2 (dependency-local prediction).** With mechanisms and the abducted background law fixed, reevaluate the requested descendants of the intervention. At each background realization, every non-descendant other than the intervened node retains its factual-world value (Proposition 4.2); an unobserved value can remain uncertain. If the evidence changes, revalidate or rerun abduction: posterior quantities can change for non-descendants. Proposition 4.13 states exactly which costs this locality covers.

**Algorithm 3 (certified counterfactual interval).** *Input:* a nonempty declared linear response polytope $K = \{ q \geq 0:Eq = f,\ Aq \leq h,\ \mathbf{1}^{T}q = 1\}$ and event query $a^{T}q/b^{T}q$, with $0 \leq a \leq b \leq 1$. First distinguish certified infeasibility of $K$ from failure to solve it. (1) Check $\max_{K}b^{T}q > 0$; if it is zero, the conditional query is undefined. (2) In exact rational arithmetic minimize and maximize $a^{T}r$ subject to $Er = ft$, $Ar \leq ht$, $\mathbf{1}^{T}r = t$, $b^{T}r = 1$, $r,t \geq 0$. (3) Lemma 4.7 guarantees $t \geq 1$; return positive-support witnesses $q = r/t$. (4) Return and check the direct endpoint certificates of Theorem 4.8. A cheaper probability enclosure uses $\min_{K}a^{T}q/\max_{K}b^{T}q$ for its lower endpoint; its upper endpoint is $\min\{ 1,\max_{K}a^{T}q/\min_{K}b^{T}q\}$ when the denominator minimum is positive, and one otherwise. Label it outer unless sharpness is independently certified.

**Algorithm 4 (branch reuse).** Keep an old counterfactual interval as an outer bound when new constraints are added and the query, including its evidence event, is unchanged. When the case evidence changes, the query has changed: rerun Algorithm 3.

# 4 Results on structure

**Proposition 4.1 (bare suffix regeneration does not supply abduction).** Let $e$ be the full factual evidence and $p$ the prefix information retained by a regeneration procedure. The regenerated token law is conditioned on $p$ and the edited prefix; it does not by that fact implement a world intervention. If a declared SCM interprets the procedure as prediction under $do(X = x\prime)$ with background posterior $P(U \mid p)$, its result agrees with the same-case counterfactual for every outcome event whenever $P(U \mid p) = P(U \mid e)$. Agreement need not hold otherwise.

*Proof.* The stipulated prediction and the counterfactual evaluate the same intervened assignments, but integrate them against $P(U \mid p)$ and $P(U \mid e)$ respectively. Equal laws make every result equal. The toy pair below and the example $Y = 2X + U$ show why discarded evidence can change the result. Theorem 4.6 bounds the event-probability difference. $▫$

**Proposition 4.2 (cross-world invariance of non-descendants).** In a twin network with shared background variables and any coupling kernel that returns identical outputs at identical parent values, every non-descendant of $X$ other than the intervened node takes the same value in both worlds with probability one.

*Proof.* Order the events topologically. A non-descendant other than $X$ has only non-descendant parents, which agree by induction; its two parent values are therefore identical, and the kernel returns identical outputs. ∎

**Proposition 4.3 (couplings are not identified by levels 1 and 2).** For the binary DAG family with independent node backgrounds, let three couplings assign each node the same response probabilities $p_{i}(c)$ at every parent value $c$: comonotone ($V_{i} = \mathbf{1}\{ U_{i} < p_{i}(c)\}$), independent across parent values, and alternating (comonotone between parent values of equal parity, countermonotone otherwise). All three induce the same observational law and the same interventional law for every intervention, but can induce different counterfactual laws.

*Proof.* A single-world law under any set of interventions is a product of the response probabilities at the parent values that occur, which are the same in all three couplings. A twin-network law uses the joint response at two different parent values, which the couplings specify differently. The example of Section 5.1 gives different values. ∎

**Proposition 4.4 (a fixed positive evidence probability makes the ratio linear).** If $b^{T}q = \gamma > 0$ on $K$, the conditional endpoints are the extrema of $a^{T}q$ divided by $\gamma$, and endpoint division is exact. Otherwise, separate numerator and denominator extrema give a valid outer interval with the zero-denominator convention in Algorithm 3; it can be strictly wider than the Charnes--Cooper interval.

*Proof.* A fixed positive denominator makes the ratio a linear functional scaled by $1/\gamma$. For variable denominators, nonnegative numerator and positive denominator imply the endpoint-division inequalities. If the denominator minimum is zero, the event-ratio upper bound one remains valid because $a \leq b$. Separate extrema need not share an optimizer. The Charnes--Cooper change of variables preserves each feasible positive-support ratio. $▫$

**Proposition 4.5 (new evidence changes the counterfactual query).** Adding constraints with the evidence event fixed preserves an old outer interval. Conditioning on additional case evidence replaces $(a,b)$ by $(a \land g,b \land g)$ and can move the interval outside the old one.

*Proof.* For a fixed ratio, restriction to a subset cannot introduce a new query value. For reconditioning, take a fixed model with fair binary $U$, proxy $Z = U$ and counterfactual response $Y_{x\prime} = U$. Before observing $Z$, the conditional query is $1/2$; after the case observation $Z = 1$, it is one. The model did not change, but the conditioning event did. $▫$

The toy pair of the companion discussion makes Proposition 4.3 concrete. With $X$ and $U$ independent fair bits, $Y = U$ and $Y = X \oplus U$ have the same observational law and $P\left( Y = 1 \mid do(X = x) \right) = 1/2$ for both values. After observing $X = 0,Y = 0$ both give $U = 0$, yet $P\left( Y_{1} = 1 \mid X = 0,Y = 0 \right)$ is 0 in the first model and 1 in the second. If both models are admissible, the certified answer is $\lbrack 0,1\rbrack$. More tokens or more caching cannot remove this ambiguity; only structural assumptions or counterfactual data can.

## 4.1 Factual information and evidence support

**Theorem 4.6 (the information lost by discarding factual evidence).** Fix one finite SCM and an intervention. Let $\mu_{e}$ and $\mu_{p}$ be its background posteriors given full factual evidence $e$ and retained prefix information $p$, both of positive probability. For any counterfactual event with indicator $h(r)$,

$$\left| \sum_{r}^{}h(r)\mu_{e}(r) - \sum_{r}^{}h(r)\mu_{p}(r) \right| \leq TV\left( \mu_{e},\mu_{p} \right) = \frac{1}{2}\sum_{r}^{}\left| \mu_{e}(r) - \mu_{p}(r) \right|.\quad\quad(2)$$

*Proof.* Put $d_{r} = \mu_{e}(r) - \mu_{p}(r)$. Its positive and negative masses are equal to $\frac{1}{2}\sum_{r}^{}\left| d_{r} \right|$, since $\sum_{r}^{}d_{r} = 0$. The sum over any event lies between the negative and positive masses. Taking the event on the positive coordinates attains the upper value among all indicators, so the constant is sharp. $▫$

This is the standard total-variation event bound applied to the branch contract. The discarded information can include the actual treatment assignment as well as its later outcome. In a confounded model, the actual assignment itself can inform the background. Equal posteriors are sufficient for every branch query to agree; a particular query can agree even when the posteriors differ. Equation (2) therefore does not infer a causal error from textual distance or from suffix length.

**Lemma 4.7 (support and attainment).** Let $K$ be a nonempty compact polytope in $\Delta_{m}$, with event vectors $0 \leq a \leq b \leq 1$. If $\max_{K}b^{T}q = 0$, the conditional query is undefined throughout $K$. Otherwise the Charnes--Cooper programme in Algorithm 3 is feasible, every feasible point has $t \geq 1$, and both conditional endpoints are attained by positive-support witnesses. A uniform positive lower bound on $b^{T}q$ is not required for this finite event-query result.

*Proof.* A positive-support $q$ gives $t = 1/\left( b^{T}q \right)$ and $r = tq$, hence feasibility. Conversely $b^{T}r = 1 \leq \mathbf{1}^{T}r = t$ proves $t \geq 1$ and permits $q = r/t$. The maps are inverse on the feasible sets, preserving the objective. Since $0 \leq a^{T}r \leq b^{T}r = 1$, the linear objective is bounded on a nonempty polyhedron. Its minimum and maximum are attained by the finite-dimensional linear-programming attainment theorem. Mapping the optimizers back gives the witnesses. $▫$

Zero-support models are excluded from the conditional query; they do not turn it into a probability conditional on an impossible event. Empty $K$, all-zero support, uncertain model identification and an unsuccessful solver are four different situations. Algorithm 3 must report them separately. Endpoint division uses a lower numerator bound divided by a positive upper denominator bound. If the lower denominator bound is zero, its probability upper bound is one, rather than a division by zero.

## 4.2 Direct certificates and their repair

Write $K = \{ q \in \Delta_{m}:Eq = f,\ Aq \leq h\}$. Equality multipliers $\nu$ are free; inequality multipliers $\lambda$ must be nonnegative. For any linear objective $v$, define

$$B_{K}(v;\nu,\lambda) = \nu^{T}f + \lambda^{T}h + \max_{i}\left( v_{i} - \left( E^{T}\nu + A^{T}\lambda \right)_{i} \right).\quad\quad(3)$$

**Theorem 4.8 (a conditional bound checked in the original coordinates).** If $B_{K}(a - ub;\nu,\lambda) \leq 0$, then $a^{T}q/b^{T}q \leq u$ for every $q \in K$ with positive denominator. If $B_{K}\left( \ell b - a;\widetilde{\nu},\widetilde{\lambda} \right) \leq 0$, the ratio is at least $\ell$. A feasible positive-support witness attaining a checked endpoint certifies sharpness. Under Lemma 4.7, every sharp endpoint admits such a multiplier certificate and witness.

*Proof.* Decompose $v^{T}q$ into $\nu^{T}Eq + \lambda^{T}Aq$ and the residual dot product. Feasibility and $\lambda \geq 0$ bound the first terms by $\nu^{T}f + \lambda^{T}h$; simplex normalization bounds the residual by its largest coordinate. Thus $v^{T}q \leq B_{K}(v;\nu,\lambda)$. Apply this to the two displayed objectives and divide by $b^{T}q > 0$. An attaining witness proves that the bound cannot improve. For completeness, let $u$ be the true upper endpoint. On positive support, $(a - ub)^{T}q \leq 0$; on zero support $a^{T}q = 0$ as well. Its maximum on $K$ is zero, attained at a positive-support ratio optimizer. Linear-programming duality, with a free normalization multiplier, supplies (3) equal to zero. The lower endpoint is identical with reversed objective. $▫$

The checker can therefore validate the returned conditional interval using rational dot products, multiplier signs, a residual maximum and primal feasibility. It need not trust the optimisation routine or rely on the transformed variables being named correctly. Exact arithmetic is still conditional on correct event meanings, response coordinates and causal assumptions. A witness with zero evidence probability cannot certify endpoint sharpness.

**Corollary 4.9 (refinement reuse for a fixed conditional query).** Suppose $K\prime \subseteq K$ is a checked refinement with some positive-support model, and $a,b$, mechanisms, coupling class and units are unchanged. Every old valid interval remains an outer interval. An old endpoint remains sharp whenever its attaining positive-support witness lies in $K\prime$. With the finite polytope assumptions, it remains sharp exactly when some old attaining positive-support model survives.

*Proof.* The positive-support part of $K\prime$ is a subset of that of $K$. Its image under the same ratio lies in the old interval. A surviving optimizer attains an endpoint; conversely Lemma 4.7 supplies an attaining optimizer if the refined endpoint is unchanged. $▫$

This gives the exact condition behind Algorithm 4. Survival of one selected witness is sufficient, not necessary. Reconditioning on a different case event changes $a,b$ and is not covered by this corollary. Nor can a newly adopted coupling assumption be hidden in an otherwise identical cache key.

**Theorem 4.10 (repair with a certified support floor).** Evaluate stored upper and lower multiplier vectors on the current rows, obtaining residual bounds $\delta_{U}$ for $a - ub$ and $\delta_{L}$ for $\ell b - a$ through (3). If the current model set certifies $b^{T}q \geq \beta > 0$, then a valid repaired interval is

$$\left\lbrack \max\{ 0,\ell - \left\lbrack \delta_{L} \right\rbrack_{+}/\beta\},\ \min\{ 1,u + \left\lbrack \delta_{U} \right\rbrack_{+}/\beta\} \right\rbrack,\quad\lbrack s\rbrack_{+} = \max\{ s,0\}.\quad\quad(4)$$

*Proof.* The upper residual inequality gives $a^{T}q \leq ub^{T}q + \delta_{U}$. If $\delta_{U} \leq 0$, the old upper bound holds; otherwise division and $b^{T}q \geq \beta$ give the upper term in (4). The lower residual gives the corresponding lower term. The event probability lies in $\lbrack 0,1\rbrack$, permitting the clipping. $▫$

For example, let $a = (1,0,0)$ and $b = (1,1,0)$. Impose $q_{1} + q_{2} \geq 1/4$ and $q_{1} - q_{2} \leq 0$. Multiplier $1/2$ on the second row proves $u = 1/2$. Replace its right-hand side by $1/20$. The same multiplier gives $\delta_{U} = 1/40$, and (4) gives $u\prime = 3/5$. The witness $(3/20,1/10,3/4)$ attains it. The old number is false while its multiplier remains useful. If no positive support floor is available and a residual is positive, this repair need not give a nontrivial result; solve the conditional problem or retain a coarser valid interval. Rare factual evidence can amplify reconstruction error.

## 4.3 Coherent worlds and sufficient task memory

**Proposition 4.11 (pairwise couplings need not share one background model).** Pairwise response kernels with matching one-world marginals and identical-input consistency need not extend to a joint law over responses at three distinct parent configurations.

*Proof.* At three configurations let binary responses $R_{1},R_{2},R_{3}$ each be fair, and specify that every distinct pair disagrees with probability one. Each pair is a valid fair antithetic coupling. For any deterministic triple,

$$\mathbf{1}\{ R_{1} \neq R_{2}\} + \mathbf{1}\{ R_{2} \neq R_{3}\} + \mathbf{1}\{ R_{1} \neq R_{3}\} \leq 2.\quad\quad(5)$$

The pair specifications require its expectation to be three, a contradiction. Diagonal kernels can still impose identical outputs at identical configurations; they do not remove the contradiction. $▫$

A finite extendability test introduces one nonnegative weight $\theta_{r}$ for each permitted deterministic response vector and requires its pairwise marginals to equal the proposed kernels. Feasibility gives a common response law; an exact infeasibility certificate rejects the package. The three census couplings are globally defined response constructions, so this observation does not invalidate them. It limits a future learned implementation that proposes pair kernels independently. Horizontal overlap agreement alone does not supply the missing global probabilistic realization.

**Theorem 4.12 (linear memory sufficient for a declared moment contract).** Let a nonempty convex posterior family have affine direction space $T = span(K - K)$. Let rows of $C$ be the response-atom moments that future tasks require, including relevant joint numerators and evidence denominators. A linear memory $z = Lq$ determines every $Cq$ on $K$ exactly if and only if

$$\ker L \cap T \subseteq \ker C.\quad\quad(6)$$

The least number of real linear memory coordinates is $rank\left( C|_{T} \right)$. For the full simplex it is $rank\begin{bmatrix}
\mathbf{1}^{T} \\
C
\end{bmatrix} - 1$.

*Proof.* If two posteriors have equal memory, their difference lies in the left-hand null space, so (6) makes their required moments equal. Conversely take a direction violating (6) and a relative-interior point of $K$. Sufficiently small positive and negative displacements along that direction remain in $K$, have equal memory and different task moments. For the dimension statement, (6) forces $rank\left( L|_{T} \right) \geq rank\left( C|_{T} \right)$. Choosing rows spanning the task map on $T$, and retaining the known affine offset, attains equality. On the full simplex $T = \mathbf{1}^{\bot}$, yielding the displayed rank. $▫$

This is an exact linear moment contract, not a universal lower bound for arbitrary nonlinear codes, finite-bit storage or ratios alone. A ratio can require fewer coordinates than recovering its numerator and denominator separately. For the declared moment contract, however, a memory retaining only $q_{1}$ confuses $(1/4,1/4,1/2)$ with $(1/4,1/2,1/4)$. Both initially give $P(R = 1) = 1/4$, but conditioning on the first two atoms gives $1/2$ and $1/3$. Retaining both $q_{1}$ and $q_{1} + q_{2}$ supports this continuation. Expanding the future evidence family can therefore require new memory coordinates even when the old answer remains correct.

## 4.4 The cost covered by causal locality

**Proposition 4.13 (prediction locality with its actual cost factors).** Fix the mechanisms, the abducted law, a factual assignment for each retained response atom, intervention nodes $S$ and requested outcomes $Q$. Let $R$ be the nodes reachable from $S$ and ancestral to $Q$, including endpoints. At each fixed atom, only nodes in $R$ need new evaluation; intervened nodes are assigned their replacement values. If evaluating node $i$ costs $c_{i}$, the new mechanism-evaluation work over $m$ retained atoms is at most $m\sum_{i \in R}^{}c_{i}$, treating an intervention assignment as its declared constant-cost operation.

*Proof.* Outside $S$ and its descendants, shared background arguments and unchanged mechanisms give identical values by induction. Outside the ancestors of $Q$, a value is unnecessary for the requested outputs. Reevaluate the intersection in topological order. Summing the node costs over the retained atoms proves the bound. $▫$

This bound excludes parsing the text, locating the subgraph, obtaining the posterior, solving or checking bounds, looking up records and rendering a transcript. Graph discovery can itself cost $O\left( |V| + |E| \right)$ without an index. The response support can be exponentially large; exact probabilistic inference may depend on graphical width. A sparse descendant set therefore does not prove low total latency. Dense causal dependence can make nearly the whole suffix relevant. With evidence fixed, the census counts only the prediction part of this contract.

## 4.5 Why the assumption ladder reaches a point

**Corollary 4.14 (monotone binary response with experimental marginals).** If $Y_{1} \geq Y_{0}$ almost surely and $P\left( Y_{0} = 0 \right) > 0$, then

$$P\left( Y_{1} = 1 \mid Y_{0} = 0 \right) = \frac{P\left( Y_{1} = 1 \right) - P\left( Y_{0} = 1 \right)}{1 - P\left( Y_{0} = 1 \right)}.\quad\quad(7)$$

*Proof.* Monotonicity excludes $Y_{0} = 1,Y_{1} = 0$. Hence $P\left( Y_{1} = 1,Y_{0} = 0 \right) = P\left( Y_{1} = 1 \right) - P\left( Y_{0} = 1 \right)$, while the denominator is $1 - P\left( Y_{0} = 1 \right)$. Division proves the claim. $▫$

This elementary response-type identity explains the zero-width experimental-plus-monotonicity census result. Monotonicity alone does not supply the two marginals, and a comonotone noise construction alone does not supply the displayed treatment-response order. If the evidence denominator is zero, the conditional probability remains undefined.

# 5 Exact census

## 5.1 Couplings, bounds and suffix recomputation

The first census reuses the series family: all 1,024 DAGs on five binary events that respect one fixed order, with three positive models per graph whose conditional probabilities lie on a tenths or a hundredths grid (Ghosh, 2026f). For every model and every pair in which $X$ is an ancestor of $Y$, the census computes the probability of necessity

$$PN = P\left( Y_{X = 0} = 0 \mid X = 1,Y = 1 \right)\quad\quad\ \ \ \ (8)$$

by Algorithm 1 under the three couplings of Proposition 4.3. It also computes the Tian--Pearl bounds

$$\max\left\{ 0,\frac{P(y) - P\left( y_{x\prime} \right)}{P(x,y)} \right\} \leq PN \leq \min\left\{ 1,\frac{P\left( y\prime_{x\prime} \right) - P(x\prime,y\prime)}{P(x,y)} \right\},\quad\quad\ \ \ \ (9)$$

which use only observational and interventional quantities (Tian & Pearl, 2000). An exact linear programme over the eight response types of $(X,Y)$, constrained by the same quantities, gives the sharp bounds independently. The suffix-recomputation answer of Proposition 4.1 keeps the events before $X$ and discards the later evidence $Y = 1$.

The LP sharpness statement concerns the reduced two-event response class and the observational and experimental summaries imposed on it. It does not claim sharpness after every restriction of the original five-event DAG is imposed.

Table 2 summarises the results. Every coupling answer lay inside (9), and the linear programme reproduced (9) in every query, confirming that the Tian--Pearl bounds are sharp for these data. No query was point identified from these summaries. The three answers were never all equal; their spread exceeded 0.1 in 82.5% and 0.25 in 52.0% of hundredths queries, and reached the full width 1 in some queries. The comonotone coupling attained the lower bound in 54.1% of hundredths queries and never attained the upper bound, a property of the declared coupling in this census. Comonotonic local noise does not by itself imply monotone treatment response for the whole DAG. The suffix-recomputation answer stayed inside (9) in every query, but differed from the comonotone counterfactual by 0.257 on average. Membership alone does not certify that the number is the counterfactual of the coupling declared in the branch.

**Table 2 Probability of necessity under three couplings with identical levels 1 and 2**

  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Grid**     **PN queries**   **Coupling answers inside (9)**   **LP equals (9)**   **Spread above 0.1**   **Spread above 0.25**   **Comono­tone at lower bound**   **Mean width of (9)**   **Mean suffix gap**
  ------------ ---------------- --------------------------------- ------------------- ---------------------- ----------------------- ------------------------------- ----------------------- ---------------------
  Tenths       18,939           100.0%                            100.0%              94.0%                  58.3%                   60.6%                           0.642                   0.279

  Hundredths   18,939           100.0%                            100.0%              82.5%                  52.0%                   54.1%                           0.606                   0.257
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

![Grouped bars of the spread of PN across couplings, and of interval widths as assumptions are added.](./media/image1.png){width="6.4in" height="2.587234251968504in"}

**Figure 1 Coupling spread and the assumption ladder**\
Left: spread of PN across the comonotone, independent and alternating couplings, which share every observational and interventional law; the spread was never zero. Right: mean width of the sharp interval for P(Y₁=1 \| Y₀=0) on 1,000 instrumental-variable polytopes, and of endpoint division, as assumptions are added. Exact census; not a learned-model experiment.

## 5.2 Cross-world invariance and prediction cost

For every model and every action event with descendants (9,408 per grid), the census checked every twin weight of every coupling. No non-descendant ever differed between the factual and counterfactual worlds, as Proposition 4.2 requires. Over the 5,120 graph and action-event pairs, prediction under fixed evidence required 6,313 descendant-event evaluations, versus 10,240 later-event evaluations in token order. The former count is 61.7% of the latter. These are structural counts, not measured computation times. They omit abduction, integration over response atoms, graph lookup, certificate checking and rendering, as Proposition 4.13 makes explicit. A full revised transcript may still require its own key-value computation.

## 5.3 Linear-fractional bounds on an instrumental-variable polytope

The second census uses the binary instrumental-variable model with 16 response types (Balke & Pearl, 1997). Each of 1,000 instances draws a true response law with integer weights from 0 to 4. The counterfactual query is

$$P\left( Y_{1} = 1 \mid Y_{0} = 0 \right) = \frac{P\left( Y_{1} = 1,Y_{0} = 0 \right)}{P\left( Y_{0} = 0 \right)},\quad\quad\ \ \ \ (10)$$

whose denominator is not fixed by instrument data. Algorithm 3 computes it at four assumption levels: instrument data; instrument data with experimental marginals $P\left( Y_{1} = 1 \right)$ and $P\left( Y_{0} = 1 \right)$; instrument data with monotone treatment response $Y_{1} \geq Y_{0}$ (Manski, 1997), using a second true law that satisfies it; and both additions.

Table 3 reports the ladder. Every interval contained the true value and every endpoint was attained by a witness. With instrument data alone the mean width was 0.993: the data say almost nothing about this counterfactual. Experimental marginals fixed the denominator, so endpoint division coincided with the sharp interval, as Proposition 4.4 predicts, and the width fell to 0.678. Monotone response alone left the denominator free; the sharp interval had width 0.628, and endpoint division was strictly wider in 99.3% of instances. Together, the two assumptions identified the counterfactual in every instance.

**Table 3 Counterfactual interval for P(Y₁=1 \| Y₀=0) as assumptions are added (1,000 instances)**

  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Assumptions**                              **Mean sharp width**   **Mean endpoint-division width**   **Endpoint division strictly wider**   **Point identified**   **Truth inside**   **Endpoints attained by a witness**
  -------------------------------------------- ---------------------- ---------------------------------- -------------------------------------- ---------------------- ------------------ -------------------------------------
  Instrument data                              0.993                  0.996                              3.5%                                   0.0%                   100.0%             100.0%

  Instrument data and experimental marginals   0.678                  0.678                              0.0%                                   0.0%                   100.0%             100.0%

  Instrument data and monotone response        0.628                  0.871                              99.3%                                  0.0%                   100.0%             100.0%

  Both additions                               0.000                  0.000                              0.0%                                   100.0%                 100.0%             100.0%
  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

For Algorithm 4, the census added case evidence $X(z = 1) = 1$ at the experimental level. In 998 instances the new query was defined. Its interval was not contained in the old one in 730 (73.1%) and was disjoint from it in 6. An old counterfactual interval is not a cache hit for a case with more evidence.

These conditioning events specify potential-response properties; the census does not establish their joint availability as observations from a factual transcript.

## 5.4 Validation

Version 1 supplies an independent Python validator for every census line. It evaluates twin networks with Python integers and separately written coupling kernels, computes (9) with rational arithmetic, and compares LP endpoints using SciPy's HiGHS solver. It independently checks suffix answers, descendant counts, Charnes--Cooper bounds and the feasibility and attained ratios of exported witnesses. The supplied report contains 13 passing checks with maximum floating discrepancy $1.3 \times 10^{- 15}$. Section 5.5 reports this revision's rerun and new exact examples; it does not claim a new C# compiler run.

## 5.5 New exact examples and validation provenance

The revision adds rational checks for (2)--(7), zero-support models, endpoint certificates, support-sensitive repair, coupling extendability and sufficient memory. The worked probability-of-necessity data are $P(x,y) = 2/5$, $P(x,y\prime) = 1/10$, $P(x\prime,y) = 1/10$, $P(x\prime,y\prime) = 2/5$, with $P\left( y_{x} \right) = 7/10$ and $P\left( y_{x\prime} \right) = 1/5$. Equation (9) gives the sharp interval $\lbrack 3/4,1\rbrack$. Exact vertex enumeration over the eight bivariate response types independently attains both endpoints. A decision requiring $PN > 7/10$ is therefore certified without point identification. The example's numbers are specified rational inputs, not new population measurements.

All 33 new exact checks pass. The support-sensitive repair grid contains 2,287 feasible cases, and the total-variation grid checks 1,800 distribution-pair and event combinations. The result file records the exact endpoint witnesses and arithmetic for each named check.

**Table 4 Exact witnesses for the worked probability of necessity**

  ------------------------------------------------------------------------------------------
  **Response atom** $\left( X,Y_{0},Y_{1} \right)$   **Lower witness**   **Upper witness**
  -------------------------------------------------- ------------------- -------------------
  (0,0,0)                                            1/10                1/5

  (0,0,1)                                            3/10                1/5

  (0,1,0)                                            1/10                0

  (0,1,1)                                            0                   1/10

  (1,0,0)                                            1/10                0

  (1,0,1)                                            3/10                2/5

  (1,1,0)                                            0                   1/10

  (1,1,1)                                            1/10                0
  ------------------------------------------------------------------------------------------

For support and repair, the examples attain the values stated in Lemma 4.7 and Theorem 4.10. The three-world obstruction has no extending response law, while the all-equal pair family has an explicit extension. Exact matrix elimination verifies the moment rank and the two distinct conditional answers in Theorem 4.12. Finite rational grids check the total-variation and repair inequalities; those checks illustrate the proved statements rather than establishing their generality.

The unchanged Version 1 Python validator was rerun against the supplied C# output and exported witnesses, with four worker processes. All 13 checks pass again; the maximum floating discrepancy remains $1.3322676295501878 \times 10^{- 15}$. Its rational witness checks are exact; its HiGHS comparisons use floating arithmetic. The C# census was not regenerated; the new certificate service and Algorithm 5 are interface extensions. The original source, output, validation and figure remain unchanged in the bundle. New example results are produced in two clean Python processes and compared byte for byte. No language model, agent runtime, timing study or biological experiment is added.

# 6 Use in an AI harness and in retrospection

In the harness, the language model proposes a counterfactual: which event to change, to what, and which outcome to ask about. ADC compiles it into a branch record. The checker establishes the evidence snapshot, the declared coupling or response-type class and the support condition. Algorithm 1 or 3 returns a value or an interval with its status. Algorithm 2 recomputes only causal descendants while the evidence is fixed. Algorithm 4 decides whether an old branch can be reused. The language model then renders the result as text. Its key-value cache serves that rendering; it is not the authoritative state of the counterfactual.

Retrospection needs sufficient factual evidence or a certified abducted state, mechanism semantics and an explicit coupling scope. A complete verbatim history is unnecessary when a checked task frontier preserves the required joint information. Section 5.1 shows that observational and interventional knowledge alone can permit different counterfactual answers; storage efficiency cannot resolve that identification gap.

## 6.1 An interface for branches and certificates

The proposed harness extends the six-component IDC interface. A semantic registry binds the case, event meanings, units, graph, mechanism and coupling versions. A proposal policy suggests an intervention and outcome. A primitive checker validates support, mechanism replacements, dependency claims and the certificates in Theorem 4.8. An append-only operation store keeps factual and alternative records separately. The interval engine solves or repairs the conditional query. The scheduler chooses whether a checked interval already meets the decision requirement or whether more inference or evidence is useful. These are interface requirements, not an implemented learned agent.

The branch key must include the factual evidence event as well as the evidence snapshot: a new observation about the same case can change the conditional query even if all population arrays are unchanged. It must also include the coupling or admissible response class. A value computed under comonotonicity cannot silently serve a request allowing all couplings. A selected coupling may yield a point answer labelled as conditional on that assumption; it does not make the broader class point identified.

**Algorithm 5 (checked branch service).** Pin the request snapshot and semantic map. Check that the model set is nonempty and determine whether the evidence has positive support. Retrieve a record only under a matching query and contract or a checked transport. Try a surviving endpoint witness and multiplier certificate; otherwise use Algorithm 3 or Theorem 4.10. Reevaluate only the necessary structural operations under Proposition 4.13, with the abducted state fixed. Return the achieved interval, coupling scope and status; append the record. A latest-state request additionally checks its registry version at commit. An undefined conditioning event, certified inconsistency, valid outer interval, sharp interval, identified point and unverified computation have separate statuses.

SWE-agent studies how model--computer interfaces affect software-agent behavior (Yang et al., 2024). Agent Lightning separates agent execution from reinforcement training (Luo et al., 2025). Anthropic's later account separates generation and evaluation and discusses orchestration costs (Anthropic, 2026). These are harness precedents, not counterfactual identification results. A language-model evaluator can propose concerns or tests, while the exact checker accepts only the mathematical claim its premises establish. A learned route policy may optimize time, memory, solver calls and external observations separately; correctness remains a constraint on every accepted result, rather than a reward traded against token count.

## 6.2 Generator counterfactuals and semantic abstraction

Chatzi et al. (2025), building on Gumbel-max SCMs, construct counterfactual token generation without retraining the language model. If the original noise is unavailable, it can be abducted from the realized tokens under that model; logging noise is useful but not a prerequisite. A stored seed alone is sufficient only when it reproduces the declared noise coordinates and sampling policy after branching. Keeping noise indexed by generation step and vocabulary item makes the intended sharing explicit. The chosen coupling is part of the generator model and is not established uniquely by next-token probabilities (Oberst & Sontag, 2019).

Pona et al. (2025) instead develop abstract counterfactuals around meaningful characteristics of language-agent actions, including token and latent interventions. Their experiments motivate semantic intervention interfaces. For ADC, interpreting a string as an action still needs a declared map to the described system and a checked intervention meaning. A generated narrative's coherence or semantic similarity is not a certificate for the physical model.

**Lemma 6.1 (a sufficient abstraction contract).** Let $F_{I}(u)$ and $F_{\omega(I)}^{H}\left( u^{H} \right)$ be the low- and high-level assignments under corresponding interventions, including the factual intervention $I = \varnothing$. Suppose maps $\tau$ and $\eta$ satisfy $\tau\left( F_{I}(u) \right) = F_{\omega(I)}^{H}\left( \eta(u) \right)$ for every allowed $u,I$, and the high-level background law is the pushforward of the low-level law by $\eta$. If factual evidence and requested outcomes are pullbacks of high-level events, their positive-support conditional counterfactual probabilities agree at both levels.

*Proof.* The commuting identity identifies the factual evidence events and the interventional outcome events pointwise under $\eta$. The pushforward identity preserves the probabilities of their intersection and of the factual evidence. Dividing these equal quantities proves the conditional equality. $▫$

The lemma is a sufficient semantic contract. It does not follow from a small reconstruction loss or a few successful interchange probes. Exact finite models can check it exhaustively; learned continuous models need restricted task domains or certified error statements. A failed commutation square identifies which claimed abstraction has not been justified. The context cover, physical causal graph, evidence order, operation graph and learned layer order retain separate meanings; a world label is additional scope metadata, not a substitute for any of them.

## 6.3 Neuroscience as evidence for components and a source of tests

Human counterfactual thinking includes episodic construction, valuation of unchosen outcomes and learning from hypothetical feedback. These processes overlap with, but do not establish, Pearl-style inference under a known SCM. We use neural findings to constrain functional hypotheses rather than assigning a brain region to an LP variable or assuming that a vivid imagined alternative is causally certified.

Schuck and Niv (2019) detected sequential structure in hippocampal fMRI patterns during rest following a nonspatial task. Its strength related to the fidelity of orbitofrontal task-state representations. This supports studying replay of structured task information; it does not show that a factual episode is retained as an immutable log or that replay preserves a cross-world noise coupling. The ADC counterpart is retaining enough joint information for later branch queries, as Theorem 4.12 specifies.

Doll et al. (2015) associated model-based choices with prospective neural representations of future paths. Boorman et al. (2011) found signals related to the best unchosen option and learning from hypothetical feedback in a network including lateral frontopolar cortex. These are evidence for prospective evaluation and alternative-option learning. They do not by themselves distinguish a level-2 action evaluation from a level-3 same-case counterfactual. An experiment testing the ADC analogy must manipulate evidence about a shared hidden cause while keeping the proposed alternative action fixed.

Li et al. (2025) reported hippocampal and orbitofrontal representations of learned social hierarchies and increased connectivity during inference-based decisions. This is a recent correlate of relational inference, not a causal demonstration of abduction or a neural certificate checker. It motivates asking whether a representation of common background circumstances mediates the transfer from factual evidence to an alternative-case judgement. The relevant test needs behavior that separates a full-evidence model from a prefix-only model.

Morales-Torres et al. (2026) studied episodic counterfactual plausibility in three experiments. Earlier-generated alternatives tended to be more plausible and vivid, without parallel changes in difficulty. This constrains any claim that computational ease alone determines perceived plausibility. In a harness, proposal order may depend on a learned plausibility policy; acceptance still requires a certificate. In the brain, the suggested separation between constructing an alternative and evaluating its credibility remains a functional hypothesis, not evidence of formal proof checking.

No cited study establishes exact exogenous-state preservation, Charnes--Cooper computation, an append-only cortical store or a neural implementation of (3). Representations and memories can change. The testable analogy concerns which information influences a judgement and which relationships survive task-directed retention. N1--N3 below state the proposed discriminating tests.

## 6.4 What the related papers actually supply

The ADC sequential-evidence paper supplies mechanism semantics, response fibres and evidence contracts (Ghosh, 2026a). The IDC paper supplies scoped reuse and multiplier checks (Ghosh, 2026b). The task-observability paper asks when compatible, anchored latent data control a declared task and distinguishes decoded agreement from realized execution (Ghosh, 2026c). These contracts support the branch interface, but do not identify an unspecified coupling.

Task-sufficient geometry concerns declared reductions, objective schemas and certification in adaptive optimisation (Ghosh, 2026d). It is not already a minimum-memory theorem for arbitrary counterfactuals; Theorem 4.12 gives the narrower linear moment result needed here. Certified archive memory separates proposal, evidence and reporting stores (Ghosh, 2026e). It motivates protecting the evidence needed for abduction rather than treating a selected proposal archive as an unbiased record of reality. None of the five papers warrants retaining every token forever: a checked sufficient posterior or task frontier can replace a verbatim trace for the specified future queries. Changing those queries can change the required frontier.

# 7 Falsifiable hypotheses

**H1 (branch fidelity).** In a synthetic text world generated from a known structural causal model, an ADC branch will leave every non-descendant fact outside the intervention unchanged after an edit thousands of tokens back, whereas suffix regeneration will change some of them. Any changed non-descendant fact in an ADC branch refutes the implementation.

**H2 (prediction work follows the relevant subgraph).** With parsed inputs, indexed dependencies, fixed posterior support and matched mechanism-evaluation costs, ADC's branch-prediction work will follow the relevant descendant and ancestor intersection rather than padded suffix length. Measure parsing, graph discovery, abduction, probability integration, certification and text rendering separately. A reproducible suffix-length dependence in the indexed mechanism-evaluation stage at fixed relevant subgraph refutes that implementation prediction. It does not refute counterfactual semantics or imply that total latency is independent of input length.

**H3 (certified coverage).** For queries whose ground truth is computed from the generating model under its stated assumptions, every ADC interval will contain the truth. One violation under correct assumptions refutes the implementation.

**H4 (assumption sensitivity is reported).** When admissible couplings disagree beyond the request's uncertainty allowance, the harness reports an interval or an unresolved status rather than an identified point. A point approximation is permitted only with an error certificate meeting the contract. Reporting point identification while admissible models disagree is an implementation error.

## 7.1 Biological hypotheses

The computational H-series concerns a future implementation. The following N-series concerns human behavior and, where feasible, neural measurements. For each, fix the task, contrast, scoring model, power, delay and a minimum effect $\Delta > 0$ before data collection. An upper confidence endpoint below the registered effect refutes that quantitative prediction; an interval crossing it is inconclusive. These tests can challenge the proposed functional analogy without refuting the conditional mathematical theorems.

**N1 (diagnostic factual evidence informs alternative worlds).** After matched learning of a finite causal task, a late factual observation diagnostic of a hidden background cause will shift same-case counterfactual judgements more than a matched nondiagnostic observation, by at least the registered effect. Keep the alternative action, token order and exposure constant. Compare full-evidence abduction with prefix-only and associative alternatives on held-out cases. Equal predictive performance within a prespecified equivalence band weakens the claimed shared-background account. This tests how evidence is used, not whether the brain stores a literal value of $U$.

**N2 (alternative construction respects task dependencies).** At fixed factual evidence, changing an antecedent will alter decoded task representations and behavioral predictions more for its causal descendants than for matched non-descendants, by the registered contrast. Match attention, rehearsal and sensory change, and use independently learned decoders rather than assuming fixed neurons. Equal changes after these controls refute the selective-dependency prediction. New evidence can change beliefs about non-descendants, so that manipulation belongs in N1 and must not be counted as an N2 invariance failure.

**N3 (joint information supports later conditional questions).** A retention condition preserving learned joint relations will support future conditional counterfactual judgements better than retention of matched marginal facts, by the registered effect, while marginal recall is equated. Include an explicit relational-rehearsal control. Equivalent conditional performance refutes the predicted advantage on that task family. Theorem 4.12 predicts the insufficiency of particular moment codes, not inevitable dependency loss during cortical consolidation.

# 8 Limitations

The inherited census covers five binary events in one fixed order and three globally specified couplings. Their spread is a lower bound on ambiguity over a larger coupling class. The instrumental-variable census uses one conditional query family and one evidence extension; it is not an end-to-end agent experiment. The linear-fractional sharpness claims require the declared linear response model, not an unrestricted substitution for a model with independent latent blocks. A coherent multiworld extension and a positive-support event are checked separately. General identification still requires counterfactual-graph procedures such as ID\* and IDC\* where applicable (Shpitser & Pearl, 2008). The new memory rank concerns a stated moment family and exact real linear storage; it is not a bound for all learned encoders. The neuroscience findings motivate component hypotheses and do not establish neural execution of the branch algorithms.

# 9 Conclusion

Level 3 depends on the connection between factual evidence and an alternative mechanism for the same case. The original census exposes counterfactual ambiguity among couplings with identical lower-level laws. The new results make the certificate boundary more explicit: conditional endpoints can be checked directly in response coordinates, support controls repair sensitivity, and local world kernels require a coherent global extension. A task moment contract determines which linear memory directions must survive. Prediction can reuse unaffected structural computations while still paying for abduction, integration and rendering. The proposed harness enforces these distinctions before a language model presents its answer. Biological tests and measured agent benefits remain future work.

# Appendix A Reproduction

The current bundle includes `base_v1.docx`, `additions_v2.md`, `build_v2.py`, `check_v2.py`, `checks_v2.json`, the current Word and Markdown files, and the unchanged original sources under `inherited_v1/`. Run `python check_v2.py` for the new exact examples and `python build_v2.py` for the current Word paper. The builder needs python-docx, lxml and Pandoc; its base manuscript is included and no earlier project path is needed. Render and inspect after rebuilding because Office versions and fonts can change pagination.

The original C# project targets .NET 8. Inside `inherited_v1/`, its documented census command is `dotnet run -c Release --project kernel -- out --cf`, with output redirected to `cs_cf.txt`; its independent validator is `python validate_cf.py cs_cf.txt out/cf_iv_records.json validation_cf.json`. That validator was rerun for this revision with four worker processes; the original output and source bytes were preserved. `validation_v1_rerun.json` and its log record the new run. The C# census itself was not regenerated. Public C# values are immutable records; enumeration buffers and simplex tableaux are local scratch storage.

The new exact result file is reproduced in two clean Python processes and compared byte for byte. `README_V2.md` states the supported build and validation commands; the historical builder is retained only for provenance because it references an external style document. No model training, agent benchmark, human or animal study, or latency experiment is reported.

## Appendix B Scope of the added guarantees

The certificate theorems assume a correctly specified nonempty finite response polytope, correctly aligned events and rows, and exact or validated arithmetic. Lemma 4.7 concerns bounded event ratios and a polyhedral model set; a general noncompact model class can fail endpoint attainment. Theorem 4.10 additionally needs a certified positive support floor for nonzero residual repair. Proposition 4.11 requires a coherent multiworld extension rather than independent pairwise choices. Theorem 4.12 concerns real linear moment memory on a convex family. Proposition 4.13 fixes the posterior and counts mechanism evaluations separately from inference. Lemma 6.1 assumes pointwise commutation on its declared domain. None of these hypotheses is supplied by text fluency, a cache hit, horizontal agreement or biological analogy alone.

# References

Anthropic. (2026, March 24). *Harness design for long-running application development*. https://www.anthropic.com/research/harness-design-long-running-apps

Balke, A., & Pearl, J. (1994). Counterfactual probabilities: Computational methods, bounds and applications. In *Proceedings of the 10th Conference on Uncertainty in Artificial Intelligence* (pp. 46--54). https://arxiv.org/abs/1302.6784

Balke, A., & Pearl, J. (1997). Bounds on treatment effects from studies with imperfect compliance. *Journal of the American Statistical Association, 92*(439), 1171--1176. https://doi.org/10.1080/01621459.1997.10474074

Bareinboim, E., Correa, J. D., Ibeling, D., & Icard, T. (2022). On Pearl's hierarchy and the foundations of causal inference. In H. Geffner, R. Dechter, & J. Y. Halpern (Eds.), *Probabilistic and causal inference: The works of Judea Pearl* (pp. 507--556). ACM. https://doi.org/10.1145/3501714.3501743

Boorman, E. D., Behrens, T. E., & Rushworth, M. F. (2011). Counterfactual choice and learning in a neural network centered on human lateral frontopolar cortex. *PLOS Biology, 9*(6), e1001093. https://doi.org/10.1371/journal.pbio.1001093

Charnes, A., & Cooper, W. W. (1962). Programming with linear fractional functionals. *Naval Research Logistics Quarterly, 9*(3--4), 181--186. https://doi.org/10.1002/nav.3800090303

Chatzi, I., Corvelo Benz, N. L., Straitouri, E., Tsirtsis, S., & Gomez-Rodriguez, M. (2025). Counterfactual token generation in large language models. In *Proceedings of the Fourth Conference on Causal Learning and Reasoning*, PMLR 275, 1291--1315. https://proceedings.mlr.press/v275/chatzi25a.html

Doll, B. B., Duncan, K. D., Simon, D. A., Shohamy, D., & Daw, N. D. (2015). Model-based choices involve prospective neural activity. *Nature Neuroscience, 18*, 767--772. https://doi.org/10.1038/nn.3981

Ghosh, D. (2026a). *Autoregressive Do Calculus with Sequential Evidence*. https://doi.org/10.13140/RG.2.2.24386.75209

Ghosh, D. (2026b). *Certified Causal Memory with Interval Do Calculus (IDC)*. https://doi.org/10.13140/RG.2.2.11436.83848

Ghosh, D. (2026c). *Task Observability in Latent Causal Reasoning*. https://doi.org/10.13140/RG.2.2.25697.47204

Ghosh, D. (2026d). *Task Sufficient Geometry and Certified Growth in Adaptive Optimisation*. https://doi.org/10.13140/RG.2.2.27244.12167

Ghosh, D. (2026e). *Certified Archive Memory for Adaptive Multiobjective Optimisation*. https://doi.org/10.13140/RG.2.2.29524.77442

Ghosh, D. (2026f). *Operation Certificates for Latent Causal Reasoning* (Version 3). Author manuscript.

Li, J., Liao, J., Liang, Q., Yang, Y., Zheng, S., & Huang, R. (2025). Functional connectivity between human hippocampus and orbitofrontal cortex supports inference-based decision making. *Psychophysiology, 62*(11), e70180. https://doi.org/10.1111/psyp.70180

Luo, X., Zhang, Y., He, Z., Wang, Z., Zhao, S., Li, D., Qiu, L. K., & Yang, Y. (2025). *Agent Lightning: Train ANY AI agents with reinforcement learning*. arXiv. https://arxiv.org/abs/2508.03680

Manski, C. F. (1997). Monotone treatment response. *Econometrica, 65*(6), 1311--1334. https://doi.org/10.2307/2171738

Morales-Torres, R., Miceli, K., & De Brigard, F. (2026). Plausibility in episodic counterfactual thinking does not depend on the difficulty of the mental simulation. *Cognition, 271*, 106424. https://doi.org/10.1016/j.cognition.2025.106424

Oberst, M., & Sontag, D. (2019). Counterfactual off-policy evaluation with Gumbel-max structural causal models. In *Proceedings of the 36th International Conference on Machine Learning*, PMLR 97, 4881--4890. https://proceedings.mlr.press/v97/oberst19a.html

Pearl, J. (2009). *Causality: Models, reasoning, and inference* (2nd ed.). Cambridge University Press.

Pona, E., Kazemi, M., Du, Y., Watson, D., & Paoletti, N. (2025). *Abstract counterfactuals for language model agents*. arXiv. https://arxiv.org/abs/2506.02946

Schuck, N. W., & Niv, Y. (2019). Sequential replay of nonspatial task states in the human hippocampus. *Science, 364*(6447), eaaw5181. https://doi.org/10.1126/science.aaw5181

Shpitser, I., & Pearl, J. (2008). Complete identification methods for the causal hierarchy. *Journal of Machine Learning Research, 9*, 1941--1979. https://jmlr.org/papers/v9/shpitser08a.html

Tian, J., & Pearl, J. (2000). Probabilities of causation: Bounds and identification. *Annals of Mathematics and Artificial Intelligence, 28*(1--4), 287--313. https://doi.org/10.1023/A:1018912507879

Yang, J., Jimenez, C. E., Wettig, A., Lieret, K., Yao, S., Narasimhan, K., & Press, O. (2024). SWE-agent: Agent-computer interfaces enable automated software engineering. *Advances in Neural Information Processing Systems, 37*. https://arxiv.org/abs/2405.15793
