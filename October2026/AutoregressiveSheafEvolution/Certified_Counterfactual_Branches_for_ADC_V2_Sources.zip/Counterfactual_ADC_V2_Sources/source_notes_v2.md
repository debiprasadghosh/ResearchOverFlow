# Source notes for the counterfactual branch revision

Primary sources were checked on 1 November 2026. This file records the scope of
the added literature claims; the Word paper contains ordinary APA references.

## Counterfactual semantics and token generators

- Chatzi, Corvelo Benz, Straitouri, Tsirtsis and Gomez-Rodriguez (2025), CLeaR,
  PMLR 275, 1291–1315. https://proceedings.mlr.press/v275/chatzi25a.html and
  https://arxiv.org/html/2409.17027v3. Their SCM gives token-generator
  counterfactuals under declared Gumbel coupling; noise can be abducted, so logging
  the original realization is not mandatory. It is not an identification result
  for the world described by arbitrary text.
- Oberst and Sontag (2019), ICML, PMLR 97, 4881–4890.
  https://proceedings.mlr.press/v97/oberst19a.html. Gumbel-max SCMs and
  counterfactual off-policy evaluation provide precedent for the generator model.
- Pona, Kazemi, Du, Watson and Paoletti (2025).
  https://arxiv.org/html/2506.02946v1. Abstract action characteristics address
  semantic limitations of token interventions. The new Lemma 6.1 is an explicit
  sufficient contract for ADC, not a claim that their learned abstractions satisfy
  a universal exact commutation property.
- Tian and Pearl (2000), 28, 287–313.
  https://ftp.cs.ucla.edu/pub/stat_ser/r271-A.pdf. The PN bounds are classical;
  the worked rational example is newly checked by independent vertex enumeration.
- Bareinboim et al. (2022), DOI 10.1145/3501714.3501743; author version
  https://causalai.net/r60.pdf. The hierarchy theorem establishes generic
  separation, not impossibility of executing counterfactual software on a Transformer.
- Charnes and Cooper (1962), DOI 10.1002/nav.3800090303, supplies the established
  linear-fractional transformation. The paper's support and residual proofs state
  their own assumptions and do not attribute the transformation to ADC.

## Neuroscience and behavior

- Schuck and Niv (2019), Science 364, eaaw5181.
  https://pmc.ncbi.nlm.nih.gov/articles/PMC7241311/. Nonspatial task-state
  sequentiality in hippocampal fMRI and its relation to OFC task representation
  support a structured-replay hypothesis. They do not show stored response types
  or immutable cortical records.
- Doll et al. (2015), Nature Neuroscience 18, 767–772, DOI 10.1038/nn.3981.
  The primary publisher search result supplied the abstract and metadata;
  direct publisher opening failed. The paper uses only the abstract-level finding
  of prospective path representations associated with model-based choices.
- Boorman, Behrens and Rushworth (2011), PLOS Biology 9, e1001093.
  https://journals.plos.org/plosbiology/article?id=10.1371/journal.pbio.1001093.
  Unchosen-option value and hypothetical-feedback learning do not by themselves
  establish same-case SCM counterfactual inference.
- Li et al. (2025), Psychophysiology 62(11), e70180, DOI 10.1111/psyp.70180.
  https://pubmed.ncbi.nlm.nih.gov/41221634/. The abstract reports a social
  hierarchy inference task, HIP/OFC representations and increased connectivity;
  the neural associations do not prove the direction of influence or abduction.
- Morales-Torres, Miceli and De Brigard (2026), Cognition 271, 106424, DOI
  10.1016/j.cognition.2025.106424. Primary publisher abstract and Duke record:
  https://www.sciencedirect.com/science/article/abs/pii/S0010027725003658 and
  https://scholars.duke.edu/publication/1700446. Plausibility, vividness and
  generation order are behaviorally related without equivalent difficulty
  changes. The paper does not turn subjective plausibility into a validity test.

## Harness precedents and related papers

- Agent Lightning (Luo et al., 2025), https://arxiv.org/abs/2508.03680:
  execution/training separation, not counterfactual certificates.
- SWE-agent (Yang et al., 2024), https://arxiv.org/abs/2405.15793:
  model/computer interface precedent, not SCM identification.
- Anthropic (24 March 2026),
  https://www.anthropic.com/research/harness-design-long-running-apps:
  generation/evaluation separation and orchestration costs. No model performance
  numbers are imported and an LLM evaluator is not called an exact proof checker.
- Current contents of the five related Ghosh manuscripts were read for Section 6.4:
  ADC Sequential Evidence V4, Certified Causal Memory with IDC V3, Task
  Observability V4, Task Sufficient Geometry V5 and Certified Archive Memory V5.
  In particular, the optimisation geometry paper is not misrepresented as already
  proving the new counterfactual moment-memory rank result.

The new mathematical statements specialize standard tools and are proved in the
paper. No claim of neural implementation, unmeasured speed improvement or a new
general identification theorem is made.
