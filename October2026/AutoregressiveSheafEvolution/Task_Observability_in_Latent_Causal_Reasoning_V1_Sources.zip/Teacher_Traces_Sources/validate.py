"""Independent validation of the verified-transition study.

Recomputes every summary line with fractions, an independent path-based adjustment criterion
(Shpitser, VanderWeele and Robins, 2010: no forbidden vertex, every proper non-causal path blocked),
a path-based back-door criterion, and a bit-exact replay of the SplitMix64 parameter streams.
Usage: python validate.py cs_out.txt out_dir validation.json"""
import itertools, json, math, sys
from fractions import Fraction as F
from pathlib import Path

cs = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1].split() for l in open(sys.argv[1])}
out = Path(sys.argv[2]); checks = []
def check(name, ok, detail=""):
    checks.append(dict(name=name, passed=bool(ok), detail=str(detail)[:300])); print(("PASS " if ok else "FAIL ") + name, str(detail)[:160], flush=True)

class Rng:
    def __init__(s, st): s.s = st
    def next(s):
        s.s = (s.s + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF; z = s.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & 0xFFFFFFFFFFFFFFFF
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & 0xFFFFFFFFFFFFFFFF
        return z ^ (z >> 31)
    def uniform(s): return (s.next() >> 11) * (1.0 / 9007199254740992.0)
    def int(s, lo, hi): return lo + math.floor(s.uniform() * (hi - lo + 1))

n = 5; PAIRS = [(i, j) for i in range(n) for j in range(i + 1, n)]

def desc(edges, s):
    s = set(s)
    while True:
        t = s | {b for a, b in edges if a in s}
        if t == s: return s
        s = t

def anc(edges, s):
    s = set(s)
    while True:
        t = s | {a for a, b in edges if b in s}
        if t == s: return s
        s = t

def simple_paths(edges, x, y):
    adj = {i: [] for i in range(n)}
    for a, b in edges: adj[a].append((b, "out")); adj[b].append((a, "in"))
    def go(v, path, dirs):
        if v == y: yield list(path), list(dirs); return
        for w, d in adj[v]:
            if w in path: continue
            path.append(w); dirs.append(d)
            yield from go(w, path, dirs)
            path.pop(); dirs.pop()
    yield from go(x, [x], [])

def blocked(edges, path, dirs, z):
    """d-separation path rule. dirs[k] says whether edge k leaves path[k] ('out') or enters it ('in')."""
    for k in range(1, len(path) - 1):
        into_from_left = dirs[k - 1] == "out"          # edge k-1 points at path[k]
        into_from_right = dirs[k] == "in"              # edge k points at path[k] (it enters path[k] from path[k+1])
        v = path[k]
        if into_from_left and into_from_right:         # collider
            if not (desc(edges, {v}) & z): return True
        elif v in z: return True
    return False

def adjustment_valid(edges, x, y, z):
    causal = [p for p, d in simple_paths(edges, x, y) if all(t == "out" for t in d)]
    on = {v for p in causal for v in p[1:]}
    forb = desc(edges, on) | {x}
    if z & forb: return False
    return all(blocked(edges, p, d, z) for p, d in simple_paths(edges, x, y) if not all(t == "out" for t in d))

def backdoor(edges, x, y, z):
    if z & desc(edges, {x}): return False
    return all(blocked(edges, p, d, z) for p, d in simple_paths(edges, x, y) if d[0] == "in")

def r2(q, d=2):
    s = 10 ** d; t = q * s + F(1, 2); return t.numerator // t.denominator

for tag, grid, seed in (("tenths", 10, 20261031001), ("hundredths", 100, 20261031002)):
    rng = Rng(seed)
    C = dict(graphs=0, models=0, queries=0, valid=0, vmis=0, bd=0, vnbd=0, bdnv=0, inv=0, iex=0, ir2=0, i01=0, i05=0, ir1=0,
             nv=0, nex=0, nr2=0, n01=0, qinv=0, qinvr2=0, multi=0, cross=0)
    hist = [0] * 9; ratio_sum = 0.0; ratio_max = 0.0
    names = ["honest", "invalid_set", "slip_outcome_table", "slip_marginal_table", "drop_action_condition", "slip_final_sum"]
    acc = {k: [0] * 5 for k in names}; errors = []
    for dm in range(1 << len(PAIRS)):
        edges = [PAIRS[k] for k in range(len(PAIRS)) if dm >> k & 1]; C["graphs"] += 1
        parents = [sorted(a for a, b in edges if b == i) for i in range(n)]
        for r in range(3):
            cpt = [[F(rng.int(1, grid - 1), grid) for _ in range(1 << len(parents[i]))] for i in range(n)]
            C["models"] += 1
            def factor(i, v):
                c = sum((v >> p & 1) << k for k, p in enumerate(parents[i])); p = cpt[i][c]
                return p if v >> i & 1 else 1 - p
            def law(x=-1, xv=0):
                return [F(0) if x >= 0 and (v >> x & 1) != xv else math.prod((factor(i, v) for i in range(n) if i != x), start=F(1)) for v in range(1 << n)]
            obs = law()
            def mass(L, mask, vals): return sum((q for v, q in enumerate(L) if v & mask == vals & mask), F(0))
            for x in range(n):
                for y in range(x + 1, n):
                    if x not in anc(edges, {y}): continue
                    others = [i for i in range(n) if i not in (x, y)]
                    for xv in (0, 1):
                        C["queries"] += 1
                        truth = mass(law(x, xv), 1 << y, 1 << y)
                        valid, invalid, answers = [], [], {}
                        any_r2 = False
                        for size in range(len(others) + 1):
                            for zt in itertools.combinations(others, size):
                                z = set(zt); zm = sum(1 << i for i in z); zs = sorted(z); m = 1 << len(zs)
                                def emb(k): return sum((k >> j & 1) << i for j, i in enumerate(zs))
                                t1 = [mass(obs, zm, emb(k)) for k in range(m)]
                                t0 = [mass(obs, zm | 1 << x, emb(k >> 1) | (k & 1) << x) for k in range(2 * m)]
                                t2 = [mass(obs, zm | 1 << x | 1 << y, emb(k) | xv << x | 1 << y) / mass(obs, zm | 1 << x, emb(k) | xv << x) for k in range(m)]
                                ans = sum((a * b for a, b in zip(t2, t1)), F(0))
                                answers[zm] = (zs, t0, t1, t2, ans)
                                v = adjustment_valid(edges, x, y, z); b = backdoor(edges, x, y, z)
                                C["bd"] += b; C["bdnv"] += b and not v
                                diff = abs(ans - truth)
                                if v:
                                    C["valid"] += 1; valid.append(zm); C["vnbd"] += not b; C["vmis"] += diff != 0
                                else:
                                    C["inv"] += 1; invalid.append(zm); ok2 = r2(ans) == r2(truth)
                                    C["iex"] += diff == 0; C["ir2"] += ok2; any_r2 |= ok2
                                    C["ir1"] += r2(ans, 1) == r2(truth, 1); C["i01"] += diff <= F(1, 100); C["i05"] += diff <= F(1, 20)
                                    if zm == 0: C["nv"] += 1; C["nex"] += diff == 0; C["nr2"] += ok2; C["n01"] += diff <= F(1, 100)
                                    errors.append(float(diff))
                        C["qinv"] += bool(invalid); C["qinvr2"] += any_r2; hist[len(valid)] += 1
                        if len(valid) >= 2:
                            C["multi"] += 1; strata = [1 << bin(z).count("1") for z in valid]
                            ratio = max(strata) / min(strata); ratio_sum += ratio; ratio_max = max(ratio_max, ratio)
                            C["cross"] += len({answers[z][4] for z in valid}) != 1
                        zs_ = min(valid, key=lambda z: (bin(z).count("1"), z)); zs, t0, t1, t2, ans = answers[zs_]
                        def judge(kind, zmask, T0, T1, T2, A):
                            a = acc[kind]; a[0] += 1; a[1] += A == truth; a[2] += r2(A) == r2(truth)
                            a[3] += all(T0[2 * k] + T0[2 * k + 1] == T1[k] for k in range(len(T1))) and sum(T1, F(0)) == 1
                            h = answers[zmask]
                            a[4] += adjustment_valid(edges, x, y, {i for i in range(n) if zmask >> i & 1}) and h[1] == T0 and h[2] == T1 and h[3] == T2 and sum((p * q for p, q in zip(T2, T1)), F(0)) == A
                        S = lambda T2, T1: sum((p * q for p, q in zip(T2, T1)), F(0))
                        judge("honest", zs_, t0, t1, t2, ans)
                        for z in invalid: judge("invalid_set", z, *answers[z][1:])
                        m = len(t1); z0 = max(range(m), key=lambda k: (t1[k], -k))
                        step = F(1, 100) if t2[z0] + F(1, 100) <= 1 else -F(1, 100)
                        t2s = list(t2); t2s[z0] += step; judge("slip_outcome_table", zs_, t0, t1, t2s, S(t2s, t1))
                        if m > 1:
                            z1 = (z0 + 1) % m; mv = min(F(1, 100), t1[z0]); t1s = list(t1); t1s[z0] -= mv; t1s[z1] += mv
                            judge("slip_marginal_table", zs_, t0, t1s, t2, S(t2, t1s))
                        def emb2(k): return sum((k >> j & 1) << i for j, i in enumerate(zs))
                        t2d = [mass(obs, zs_ | 1 << y, emb2(k) | 1 << y) / mass(obs, zs_, emb2(k)) for k in range(m)]
                        judge("drop_action_condition", zs_, t0, t1, t2d, S(t2d, t1))
                        judge("slip_final_sum", zs_, t0, t1, t2, ans + F(1, 100))
    def eq(name, vals):
        got = cs[f"{tag}_{name}"]
        ok = len(got) == len(vals) and all((abs(float(g) - v) <= 1e-12 * max(1, abs(v))) if isinstance(v, float) else int(g) == v for g, v in zip(got, vals))
        check(f"{tag}_{name}", ok, (got, vals))
    eq("family", [C["graphs"], C["models"], C["queries"]])
    eq("valid_sets", [C["valid"], C["vmis"], C["bd"], C["vnbd"], C["bdnv"]])
    eq("invalid_sets", [C["inv"], C["iex"], C["ir2"], C["i01"], C["i05"], C["ir1"]])
    eq("naive_conditional", [C["nv"], C["nex"], C["nr2"], C["n01"]])
    eq("queries_invalid_pass_round2", [C["qinv"], C["qinvr2"]])
    eq("valid_set_histogram", hist)
    eq("alternative_derivations", [C["multi"], C["cross"], ratio_sum / C["multi"], ratio_max])
    for k in names: eq(f"checker_{k}", acc[k])
    c = C["ir2"] / C["inv"]
    for L in (5, 10, 20, 40):
        eq(f"precision_L{L}", [((1 - e) ** L) / ((1 - e) ** L + (1 - (1 - e) ** L) * c) for e in (0.01, 0.02, 0.05)])
    csv = [float(v) for v in (out / f"{tag}_invalid_abs_errors.csv").read_text().split()[1:]]
    check(f"{tag}_error_csv", len(csv) == len(errors) and all(abs(a - b) <= 1e-14 * max(1e-300, abs(b)) or a == b for a, b in zip(sorted(csv), sorted(errors))), len(csv))
missing = [k for k in cs if not any(c["name"] == k for c in checks)]
for k in missing: check(k, False, "not validated")
json.dump(dict(checks=checks, all_passed=all(c["passed"] for c in checks), lines=len(cs)), open(sys.argv[3], "w"), indent=1)
print("ALL", all(c["passed"] for c in checks), "lines", len(cs), "checks", len(checks))
