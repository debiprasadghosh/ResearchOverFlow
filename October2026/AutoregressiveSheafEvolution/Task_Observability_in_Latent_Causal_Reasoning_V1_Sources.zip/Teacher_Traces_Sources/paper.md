---
title: "From Teacher Traces to Verified Transitions"
subtitle: "How long reasoning tokens can train Autoregressive Do Calculus"
author: "Debi Prasad Ghosh"
date: "31 October 2026"
---

Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India

## Abstract

Frontier models trained with proximal policy optimisation (PPO) or group relative policy optimisation (GRPO) generate long reasoning traces. We ask how such traces can supply training data for Autoregressive Do Calculus (ADC), a finite framework that compiles interventional queries into certified computations. Our answer is that a trace should not be imitated as text. It should be converted into transition records — problem context, current state, typed operation, result and certificate — that ADC learns to select and execute in its own latent states. The teacher's optimiser need not be reproduced: as with the distilled DeepSeek-R1 models, the student first learns from generated examples by supervision. The paper establishes the verification layer on which that pipeline depends and measures, in exact arithmetic, why it is needed. On all 1,024 labelled five-event DAGs with 3,072 random positive binary models, we enumerate every candidate adjustment derivation of 37,878 causal queries. An invalid adjustment set matched the true effect to two decimals in 30.5% of 161,196 cases and exactly in 0.96%; with textbook parameters in tenths the exact rate rose to 10.7%. A zero overlap residual between local tables accepted every invalid set, as a proposition predicts, while a transition certificate built on the complete adjustment criterion rejected all of them and accepted every honest derivation. A back-door-only checker would have rejected 22.6% of the valid sets, so checker completeness also matters. In 83.7% of queries two or more valid derivations existed; all agreed exactly. An independent Python program reproduces all 34 output lines. Latent training itself is not run here; we state it as a protocol with falsifiable predictions.

**Keywords** reasoning traces; distillation; process supervision; causal identification; adjustment criterion; certified computation; continuous latent reasoning; Autoregressive Do Calculus

# 1 Introduction

A teacher that has learned by reinforcement to reason at length produces far more text than answers. For ADC this text is valuable only if it can be turned into something ADC can check and execute. ADC's input is a declared causal model, an observational law and a query; its output is an identified expression with a derivation and a certificate, or a qualified failure (Ghosh, 2026a). A long trace contains candidate operations — select an adjustment set, apply a rule, compute a table, normalise, sum — interleaved with corrections, digressions and abandoned attempts.

The proposal examined here has five steps. Generate several candidate solutions for each authoritative problem. Convert their text into checked transitions. Use the checked records to supervise operation selection, latent decoders, alternative derivations, error repair and certificate production. Gradually replace explicit reasoning with continuous computation. Add the sheaf structure of ADC as agreement on declared overlaps. The final objective rewards valid operations, decodable intermediate facts, overlap agreement and certified answers, and is followed by checked on-policy rollouts.

Three questions decide whether this is sound, and each can be answered exactly before any model is trained. Does a correct final answer certify the reasoning that produced it? Does agreement of local representations on their overlaps certify a derivation? And how complete must the checker be? Sections 3 to 5 answer them for adjustment derivations, the simplest identification operation that ADC uses.

## 1.1 Related work

DeepSeek-R1 showed that reasoning ability obtained by large-scale reinforcement learning can be transferred to smaller dense models by supervised fine-tuning on generated reasoning samples (DeepSeek-AI, 2025). GRPO, which estimates advantages from groups of sampled outputs instead of a learned value function, was introduced with DeepSeekMath (Shao et al., 2024); PPO is its predecessor (Schulman et al., 2017). The student does not need either optimiser to learn from the teacher's outputs.

Self-taught reasoning filters generated rationales by the correctness of their final answers (Zelikman et al., 2022). Outcome supervision of this kind can raise final-answer accuracy while leaving reasoning errors (Uesato et al., 2022), and step-level process supervision outperformed outcome supervision on difficult mathematics (Lightman et al., 2024). Reported reasoning is also not a reliable account of the computation: models often fail to mention influences that changed their answers (Turpin et al., 2023; Chen et al., 2025). ADC can replace learned step judgements by exact checkers wherever an operation is formally typed.

Coconut trains a model to reason in a continuous latent space by progressively replacing language reasoning steps with continuous thoughts, training on the remaining text without asking each thought to reconstruct the omitted words (Hao et al., 2024). The present proposal adds decodable, certified checkpoints to that curriculum. Interchange interventions offer one way to test whether latent states realise a declared causal computation (Geiger et al., 2021).

Adjustment is classical (Pearl, 1995, 2009). The adjustment criterion of Shpitser, VanderWeele and Robins (2010) is complete for single-action adjustment in DAGs, and Perković et al. (2015) give a complete generalisation. Learning from one's own corrected rollouts is the setting of dataset aggregation (Ross et al., 2011). ADC supplies the typed derivations, exact rule checks and failure records used here (Ghosh, 2026a); its predecessor separates mechanism contexts, clocks and interval dependencies (Ghosh, 2026b).

## 1.2 Contribution and status

The contribution is the verification layer of the teacher-to-latent pipeline and an exact measurement of why each component is needed. Propositions 3.1 to 4.3 are elementary; their value lies in what they rule out. The numerical study is exhaustive over a stated graph family and random over model parameters. The latent-training curriculum of Section 6 is a proposal: no student model is trained, and its predictions are stated with outcomes that would contradict them.

# 2 Transition records

**Definition 2.1 (transition record).** A record is a tuple

$$r=(\kappa,\ s,\ o,\ s',\ c,\ \sigma),\quad\quad\text{(1)}$$

where $\kappa$ is the authoritative problem context (graph, observational law, query, units and intervention assumptions), $s$ the current derivation state, $o$ a typed operation, $s'$ the claimed result, $c$ a certificate or failure record, and $\sigma\in\{\text{verified},\ \text{refuted},\ \text{unverified}\}$ its status. A claim without an available checker keeps the status unverified. It is never promoted by agreement with the final answer.

For an adjustment derivation of $P(Y=1\mid do(X=x))$ the operations are: select a set $Z$, with a graph premise; compute $T_0=P(x,z)$, $T_1=P(z)$ and $T_2=P(Y=1\mid x,z)$ from the observational law; and sum

$$\hat\tau=\sum_z T_2(z)\,T_1(z).\quad\quad\text{(2)}$$

A teacher sentence such as "adjust for the confounder" becomes a selection record. Its certificate is the adjustment criterion evaluated on the declared graph, and the following arithmetic records are checked exactly against the declared law.

**Definition 2.2 (checkers).** For a derivation with answer $\hat\tau$ and true interventional value $\tau$ we compare four checks.

(1) *Exact answer:* $\hat\tau=\tau$.

(2) *Rounded answer:* $\hat\tau$ and $\tau$ agree when both are rounded to two decimals.

(3) *Overlap residual:* the local tables agree on their declared overlap, $\sum_x T_0(x,z)=T_1(z)$ for every $z$, and $\sum_z T_1(z)=1$.

(4) *Transition certificate:* the set satisfies the complete adjustment criterion, every table equals its exact recomputation from the law, and (2) holds exactly.


The first two are outcome checks. The third is the sheaf-style agreement that the latent objective would encourage. The fourth is the record-level certificate.

# 3 Why a correct answer does not certify a derivation

**Proposition 3.1 (precision of answer filtering).** Suppose every valid trace is accepted, an invalid trace is accepted with probability $c$, and a trace is valid with probability $v$. Then the probability that an accepted trace is valid is

$$\pi=\frac{v}{v+(1-v)c}.\quad\quad\text{(3)}$$

If each of $L$ steps is independently wrong with probability $\varepsilon$, then $v=(1-\varepsilon)^L$ and $\pi\to0$ as $L\to\infty$ for every fixed $c>0$.

*Proof.* Bayes' rule gives (3). With $v=(1-\varepsilon)^L\to0$, the numerator vanishes while the denominator tends to $c>0$. ∎

Long traces are exactly where the risk grows. Equation (3) needs $c$, which depends on the problem family and on how answers are compared; Section 5 measures it.

**Proposition 3.2 (exact agreement has measure zero, rounded agreement does not).** For a fixed DAG and an invalid adjustment set $Z$, the difference $\hat\tau-\tau$ is a rational function of the conditional probability tables that is not identically zero. Its zero set has Lebesgue measure zero, but the set on which the rounded values agree has positive measure whenever it is nonempty.

*Proof.* Completeness of the adjustment criterion gives a model in which the difference is nonzero, so the rational function is not identically zero, and its zero set is a proper algebraic subset of the parameter cube. Agreement after rounding holds on an open set around any parameter value at which $\hat\tau$ and $\tau$ lie strictly inside the same rounding cell. ∎

The measure-zero statement says little about data built from round numbers. Problems written with probabilities in tenths sit on a coarse grid, where ties between conditional probabilities create exact numerical independences. Section 5 shows the consequence.

# 4 What overlap agreement and certificates establish

**Proposition 4.1 (overlap agreement is blind to the choice of set).** Let all local tables of an adjustment derivation be computed correctly from one observational law. They agree on every declared overlap, whether or not $Z$ is a valid adjustment set.

*Proof.* $T_0$ and $T_1$ are marginals of the same joint law, so marginalising $T_0$ over $x$ gives $T_1$, and $T_1$ sums to one. The validity of $Z$ concerns the causal graph, which does not enter these equalities. ∎

A latent overlap residual of zero therefore cannot teach the student to avoid an invalid adjustment. It detects local inconsistency, such as an arithmetic slip that changes $T_1$ without changing $T_0$. It cannot detect a consistent computation of the wrong quantity.

**Proposition 4.2 (soundness of the transition certificate).** If the certificate accepts a derivation and the observational law is positive, then $\hat\tau=P(Y=1\mid do(X=x))$ in every model compatible with the graph that induces that law.

*Proof.* A set satisfying the adjustment criterion makes (2) equal to the interventional probability in every compatible model (Shpitser et al., 2010). Exact equality of every table and of the sum then transfers that identity to the computed answer. ∎

The converse direction is deliberate. A derivation through an invalid set can be numerically right in one model, and the certificate still rejects it, because a record is meant to teach an operation that is correct for every compatible model.

**Proposition 4.3 (valid alternatives agree).** All valid adjustment sets for the same query give identical values of (2). An exact disagreement between two derivations that both claim validity refutes at least one of them.

*Proof.* Each equals the same interventional probability by Proposition 4.2. ∎

Alternative derivations are therefore both training targets and cross-checks. Their costs differ: the number of strata in (2) is $2^{|Z|}$ for binary events.

# 5 Exact study

## 5.1 Design

The family contains all 1,024 DAGs on five labelled events whose edges respect the labelling. Each graph receives three random positive binary models. Every conditional probability $P(V_i=1\mid \text{parents})$ is drawn uniformly from a grid: tenths $\{1/10,\ldots,9/10\}$ in one regime, mimicking textbook problems, and hundredths $\{1/100,\ldots,99/100\}$ in the other. Queries are $P(Y=1\mid do(X=x))$ for every ordered pair in which $X$ is an ancestor of $Y$ and for both action values, 37,878 queries per regime. For each query every subset of the other three events is a candidate adjustment set, and its derivation is computed exactly with rational arithmetic. Truth comes from mechanism replacement. Validity follows the complete adjustment criterion: no member on, or descending from, a proper causal path, and every proper non-causal path blocked (Shpitser et al., 2010; Perković et al., 2015).

For the checker study each query's honest derivation uses its smallest valid set. Five corruptions are applied separately:

• every invalid set, computed honestly;

• a slip of $0.01$ in $T_2$ at the heaviest stratum, propagated to the answer;

• $0.01$ of mass moved between two strata of $T_1$;

• $X$ dropped from the conditioning set of $T_2$;

• a slip of $0.01$ in the final sum.


The C# kernel uses immutable records and exact rationals. A Python program recomputes every line with fractions, an independent path-enumeration form of the adjustment and back-door criteria, and a bit-exact replay of the random streams. All 34 lines agree.

## 5.2 Answers do not certify derivations

Every one of the 141,828 valid sets reproduced the true effect exactly. The 161,196 invalid sets did not, but many came close (Table 1, Figure 1b).

CAPTION: Table 1 Invalid adjustment sets judged by their answers

| Parameters | Invalid sets | Exact match | Match to 2 decimals | Error ≤ 0.01 | Error ≤ 0.05 | Queries with some invalid set matching to 2 decimals |
|:--|:--|:--|:--|:--|:--|:--|
| Tenths | 161,196 | 10.7% | 33.9% | 47.5% | 83.3% | 60.5% |
| Hundredths | 161,196 | 1.0% | 30.5% | 44.6% | 78.3% | 54.8% |

With textbook parameters, 10.7% of invalid sets gave exactly the right number, and the naive conditional $P(Y=1\mid x)$ was exactly right in 15.6% of the queries that needed adjustment. On the finer grid these rates fell to 1.0% and 1.5%, consistent with Proposition 3.2: coarse grids produce ties between conditional probabilities and hence numerical independences. Agreement to two decimals hardly depended on the grid. In more than half of the queries that admit an invalid set, at least one invalid derivation would pass a two-decimal answer check.

The magnitudes are family dependent. Random tables produce modest confounding biases. Problems designed with strong confounding would produce fewer coincidences, and problems near independence more. The structural point does not depend on the family: an answer check accepts invalid derivations at a rate that must be measured, never assumed to be zero.

## 5.3 What each check catches

Table 2 gives the share of derivations each check accepts in the hundredths regime. The tenths regime is qualitatively identical.

CAPTION: Table 2 Acceptance by four checks (hundredths regime)

| Derivation | Cases | Exact answer | Answer to 2 decimals | Overlap residual | Transition certificate |
|:--|:--|:--|:--|:--|:--|
| Honest derivation | 37,878 | 100.0% | 100.0% | 100.0% | 100.0% |
| Invalid adjustment set | 161,196 | 1.0% | 30.5% | 100.0% | 0.0% |
| Slip of 0.01 in P(y \| x, z) | 37,878 | 0.0% | 7.2% | 100.0% | 0.0% |
| Slip of 0.01 moved within P(z) | 9,714 | 1.0% | 74.4% | 0.0% | 0.0% |
| X dropped from the conditioning set | 37,878 | 0.5% | 8.1% | 100.0% | 0.5% |
| Slip of 0.01 in the final sum | 37,878 | 0.0% | 0.0% | 100.0% | 0.0% |

The certificate accepted every honest derivation and rejected every invalid set and every slip. The overlap residual accepted every invalid set, every slip in $T_2$, every dropped condition and every slip in the final sum, exactly as Proposition 4.1 predicts; it caught only the slip that breaks marginal consistency. A two-decimal answer check accepted 74.4% of those marginal slips, because moving $0.01$ of mass between strata with similar outcome rates barely changes the sum.

The certificate accepted 186 dropped-condition derivations (2,268 with tenths). These are not checker errors. In each case $P(Y=1\mid z)=P(Y=1\mid x,z)$ held exactly in the model, so the table the teacher wrote down was numerically the required table. A record that stores the operation together with its graph premise distinguishes this from a valid derivation; a record that stores only the numbers does not.

FIGURE: fig/checks_and_errors.png|Figure 1 Acceptance by four checks, and how close invalid adjustment sets come to the true effect|Left: acceptance shares by derivation type and check, hundredths regime. Right: cumulative distribution of the absolute error of invalid adjustment sets in both regimes, with reference lines at 0.005, 0.01 and 0.05.

## 5.4 Checker completeness and alternative derivations

The back-door criterion is sound but not complete for adjustment. Of the 141,828 valid sets, 32,040 (22.6%) failed the back-door test; they contain descendants of $X$ that lie off every causal path. No back-door set was invalid. A back-door-only checker would therefore label more than a fifth of the valid derivations as errors and teach the student to reject them.

Valid alternatives were common. The number of valid sets per query was one in 6,192 queries, two in 10,728, four in 10,872 and eight in 6,852. In 31,686 queries (83.7%) at least two valid derivations existed, and in every one of them all valid derivations agreed exactly, as Proposition 4.3 requires. Their costs differed: the largest valid set used on average 4.31 times as many strata as the smallest, and up to 8 times.

## 5.5 Consequences for answer-filtered data

Taking the measured two-decimal acceptance rate of invalid sets, $c=0.305$, as the acceptance probability of an invalid trace, Proposition 3.1 gives the share of valid traces among those accepted by answer filtering (Table 3). This transfer is a model assumption: real traces fail in many ways, and $c$ differs for each.

CAPTION: Table 3 Valid share of answer-filtered traces, with c measured in Section 5.2

| Steps L | Step error 0.01 | Step error 0.02 | Step error 0.05 |
|:--|:--|:--|:--|
| 5 | 0.985 | 0.969 | 0.918 |
| 10 | 0.969 | 0.936 | 0.830 |
| 20 | 0.936 | 0.868 | 0.647 |
| 40 | 0.869 | 0.725 | 0.326 |

At forty steps and a 5% step error, only about a third of the accepted traces would be valid. Step-level certificates remove this dependence on $c$ for every operation that has a checker.

# 6 From verified records to latent computation

This section is a proposal. It specifies how the verified records would train ADC, and what would show the approach to be wrong.

## 6.1 What each kind of teacher material trains

CAPTION: Table 4 Teacher material and its training use

| Teacher-derived material | Training use in ADC | Check that admits it |
|:--|:--|:--|
| Valid operation sequences | Select the next operation or tool | Transition certificate for each step |
| Verified intermediate claims | Train decoders that test what a latent state represents | Exact recomputation of the claim |
| Alternative valid derivations | Learn several solution paths and their costs | Exact agreement of their answers (Proposition 4.3) |
| Incorrect steps with checked diagnoses | Learn rejection, repair and qualified failure | Certificate failure with its reason |
| Final answers and certificates | Train answer generation and certificate production | The full derivation certificate |

Steps without a checker remain unverified records. They may serve as context, but not as supervised targets.

## 6.2 Objective

For a record set $\mathcal R$ the student minimises

$$\mathcal L=\mathcal L_{op}+\lambda_d\mathcal L_{dec}+\lambda_o\sum_{i,j}\big\|\rho_{i,ij}(z_i)-\rho_{j,ij}(z_j)\big\|^2+\lambda_a\mathcal L_{ans},\quad\quad\text{(4)}$$

where $\mathcal L_{op}$ is the cross-entropy of the certified next operation, $\mathcal L_{dec}$ the decoding loss of verified claims from separator checkpoints, the third term the overlap residual after coordinates and units are aligned, and $\mathcal L_{ans}$ the loss of certified answers and certificates. By Proposition 4.1 the overlap term is a regulariser, not a correctness signal. Correctness enters only through records admitted by certificates, and the exact certificate is still run at inference.

## 6.3 Curriculum and information availability

Training starts from explicit verified steps. Stage $k$ removes the first $k$ verbal steps of each derivation and requires the latent computation to support the remaining steps, the checkpoint decoders and the certified answer, following Coconut's progressive replacement (Hao et al., 2024). Two constraints are added:

• The input at a checkpoint may contain only information available at that point of the derivation. This is the prefix condition of nonanticipation, and teacher activations are not required.

• Reasoning-step order, physical event time and layer depth remain separate indices, as in ADC and its predecessor.


After supervised training, the student's own rollouts are checked by the same certificates and added as records, so that errors occurring along its own trajectories are corrected (Ross et al., 2011).

## 6.4 Falsifiable predictions

**D1 (step certificates beat answer filtering).** On held-out causal structures, a student trained on certificate-admitted records will select invalid adjustment sets at most half as often as one trained on the same number of two-decimal answer-filtered traces from the same teacher. A confidence interval for the ratio lying entirely above 0.5 contradicts the prediction; one crossing 0.5 is inconclusive.

**D2 (decodable checkpoints survive step removal).** After removing half of the verbal steps, linear decoders at separator checkpoints will recover the certified intermediate tables of held-out queries with mean absolute error below 0.01. Correct final answers combined with undecodable checkpoints would contradict the prediction and indicate a shortcut.

**D3 (complete checkers matter).** A student trained with a back-door-only checker will reject valid non-back-door sets on held-out queries at least twice as often as one trained with the complete criterion. A ratio interval entirely below 2 contradicts the prediction.

None of these has been run. Propositions 3.1 to 4.3 and the measurements of Section 5 do not depend on their outcomes.

# 7 Limitations

The exact study covers adjustment derivations on five-event DAGs with binary events. ADC's other operations — do-calculus rules, district factorisation, the ID recursion, clock certificates and credal bounds — have exact checkers in the ADC kernel, but their corruption rates were not measured here. The coincidence rates depend on the parameter distribution, and the transfer of $c$ to whole traces in Table 3 is a model. No teacher model was queried, and no student was trained. The conversion of free text into typed records, including the parsing of operations and the detection of unstated influences, is itself an error source that the certificates check but do not remove.

# 8 Conclusion

Long reasoning traces are useful to ADC as a source of candidate operations, not as text to imitate. Each candidate becomes useful only after a certificate admits it. The exact study shows that final-answer checks admit many invalid derivations, that overlap agreement admits every consistently computed wrong quantity, and that a sound but incomplete checker rejects many valid ones. A complete, exact transition certificate admitted every honest derivation and no corrupted one. The proposed latent curriculum can then aim at a well-defined target: operations certified for every compatible model, intermediate facts that can be decoded and checked, and answers accompanied by their certificates.

# Appendix A Reproduction

The kernel targets .NET 8 without third-party packages and reuses the exact rational, random-stream and graph routines of the ADC kernel. `Distill.cs` holds the binary DAG models, both adjustment criteria, typed derivations and the four checkers; `Program.cs` runs both parameter regimes with seeds 20261031001 and 20261031002. The validator `validate.py` recomputes all 34 summary lines independently and passed all 36 checks. The verified environment was .NET SDK 8.0.131, Python 3.13.16 and NumPy 2.5.3. The core of the kernel follows.

**Distill.cs**

```csharp
// Verified transitions for teacher-to-ADC training data: exact positive binary DAG models, the
// complete adjustment criterion, typed adjustment derivations with corruptions, and four checkers
// (exact answer, rounded answer, overlap residual, transition certificate). Public values are
// immutable records; enumeration uses local scratch storage only.
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Globalization;
using System.Linq;
using System.Numerics;

namespace Tcr;

/// <summary>A positive binary DAG model. Cpt[i][c] = P(V_i = 1 | parent configuration c), parents ascending.</summary>
public sealed record CptModel(Admg Graph, ImmutableArray<ImmutableArray<int>> Parents, ImmutableArray<ImmutableArray<Q>> Cpt)
{
    public int N => Graph.N;

    public static (CptModel Model, Rng Next) Random(Admg g, Rng rng, int grid = 10)
    {
        var parents = Enumerable.Range(0, g.N).Select(i => g.D.Where(e => e.To == i).Select(e => e.From).OrderBy(p => p).ToImmutableArray()).ToImmutableArray();
        var cpt = ImmutableArray.CreateBuilder<ImmutableArray<Q>>();
        for (int i = 0; i < g.N; i++)
        {
            var row = ImmutableArray.CreateBuilder<Q>();
            for (int c = 0; c < 1 << parents[i].Length; c++) { int k; (k, rng) = rng.Int(1, grid - 1); row.Add(Q.Of(k, grid)); }
            cpt.Add(row.ToImmutable());
        }
        return (new CptModel(g, parents, cpt.ToImmutable()), rng);
    }

    Q Factor(int i, int v)
    {
        int c = 0; for (int k = 0; k < Parents[i].Length; k++) c |= (v >> Parents[i][k] & 1) << k;
        var p = Cpt[i][c]; return (v >> i & 1) != 0 ? p : Q.One - p;
    }

    /// <summary>Joint law, optionally under do(X = xv) for a single action vertex x (x &lt; 0: none).</summary>
    public ImmutableArray<Q> Law(int x = -1, int xv = 0) => Enumerable.Range(0, 1 << N).Select(v =>
        x >= 0 && (v >> x & 1) != xv ? Q.Zero
        : Enumerable.Range(0, N).Where(i => i != x).Aggregate(Q.One, (acc, i) => acc * Factor(i, v))).ToImmutableArray();

    public static Q Mass(ImmutableArray<Q> law, int mask, int values) =>
        law.Where((_, v) => (v & mask) == (values & mask)).Aggregate(Q.Zero, (a, b) => a + b);
}

/// <summary>The complete adjustment criterion for a single action and outcome in a DAG
/// (Shpitser, VanderWeele and Robins, 2010; Perkovic et al., 2015), and the classical back-door criterion.</summary>
public static class Adjustment
{
    static int Descendants(Admg g, int s)
    {
        int old; do { old = s; foreach (var e in g.D) if ((s >> e.From & 1) != 0) s |= 1 << e.To; } while (s != old);
        return s;
    }
    public static bool Valid(Admg g, int x, int y, int z)
    {
        int causal = Descendants(g, 1 << x) & g.Ancestors(1 << y) & ~(1 << x);      // vertices on proper causal paths, without x
        int forb = Descendants(g, causal) | 1 << x;
        if ((z & forb) != 0) return false;
        var pbd = Admg.Make(g.N, g.D.Where(e => !(e.From == x && (causal >> e.To & 1) != 0)), g.B);
        return pbd.Separated(1 << y, 1 << x, z);
    }
    public static bool BackDoor(Admg g, int x, int y, int z) =>
        (z & Descendants(g, 1 << x)) == 0 && g.Mutilate(0, 1 << x).Separated(1 << y, 1 << x, z);
}

/// <summary>A typed adjustment derivation: the claimed set, three local tables and the answer.
/// T0 = P(x, z) over (x, z); T1 = P(z); T2 = P(Y = 1 | x, z) at the action value.</summary>
public sealed record Derivation(int Z, ImmutableArray<Q> T0, ImmutableArray<Q> T1, ImmutableArray<Q> T2, Q Answer)
{
    static int Embed(int zmask, int k) { int v = 0, j = 0; foreach (int i in SetBits.Of(zmask)) { v |= (k >> j & 1) << i; j++; } return v; }

    /// <summary>The honest derivation for set z, computed from the observational law.</summary>
    public static Derivation Honest(ImmutableArray<Q> law, int x, int xv, int y, int z)
    {
        int nz = SetBits.Count(z), m = 1 << nz;
        var t1 = Enumerable.Range(0, m).Select(k => CptModel.Mass(law, z, Embed(z, k))).ToImmutableArray();
        var t0 = Enumerable.Range(0, 2 * m).Select(k => CptModel.Mass(law, z | 1 << x, Embed(z, k >> 1) | (k & 1) << x)).ToImmutableArray();
        var t2 = Enumerable.Range(0, m).Select(k =>
        {
            int cond = z | 1 << x, vals = Embed(z, k) | xv << x;
            return CptModel.Mass(law, cond | 1 << y, vals | 1 << y) / CptModel.Mass(law, cond, vals);
        }).ToImmutableArray();
        var ans = Enumerable.Range(0, m).Aggregate(Q.Zero, (s, k) => s + t2[k] * t1[k]);
        return new(z, t0, t1, t2, ans);
    }
    /// <summary>Overlap residual: the Z-marginal of T0 must equal T1, and T1 must sum to one.</summary>
    public bool OverlapAgrees() =>
        Enumerable.Range(0, T1.Length).All(k => T0[2 * k] + T0[2 * k + 1] == T1[k]) && T1.Aggregate(Q.Zero, (a, b) => a + b) == Q.One;
    /// <summary>Transition certificate: graph premise, every table recomputed exactly, and the final sum.</summary>
    public bool Certified(Admg g, ImmutableArray<Q> law, int x, int xv, int y)
    {
        if (!Adjustment.Valid(g, x, y, Z)) return false;
        var h = Honest(law, x, xv, y, Z);
        return h.T0.SequenceEqual(T0) && h.T1.SequenceEqual(T1) && h.T2.SequenceEqual(T2)
            && Enumerable.Range(0, T1.Length).Aggregate(Q.Zero, (s, k) => s + T2[k] * T1[k]) == Answer;
    }
}

public static class Rounding
{
    /// <summary>Round half up to d decimals, exactly.</summary>
    public static BigInteger Round(Q q, int d)
    {
        var s = BigInteger.Pow(10, d); var t = q * new Q(s, 1) + Q.Of(1, 2);
        return BigInteger.Divide(t.Num - (t.Num.Sign < 0 ? t.Den - 1 : 0), t.Den);
    }
    public static Q Abs(Q q) => q.Sign < 0 ? -q : q;
}
```

# References

Chen, Y., et al. (2025). *Reasoning models don't always say what they think*. arXiv:2505.05410. https://arxiv.org/abs/2505.05410

DeepSeek-AI. (2025). *DeepSeek-R1: Incentivizing reasoning capability in LLMs via reinforcement learning*. arXiv:2501.12948. https://arxiv.org/abs/2501.12948

Geiger, A., Lu, H., Icard, T., & Potts, C. (2021). Causal abstractions of neural networks. *Advances in Neural Information Processing Systems, 34*. https://papers.nips.cc/paper/2021/hash/4f5c422f4d49a5a807eda27434231040-Abstract.html

Ghosh, D. P. (2026a). *Autoregressive Do Calculus (ADC): Clock certificates and credal precision for event generators* (Version 2, 30 October 2026).

Ghosh, D. P. (2026b). *Temporal causal reasoning in horizontal sheaf topology* (Version 2, 30 October 2026).

Hao, S., Sukhbaatar, S., Su, D., Li, X., Hu, Z., Weston, J., & Tian, Y. (2024). *Training large language models to reason in a continuous latent space*. arXiv:2412.06769. https://arxiv.org/abs/2412.06769

Lightman, H., Kosaraju, V., Burda, Y., Edwards, H., Baker, B., Lee, T., Leike, J., Schulman, J., Sutskever, I., & Cobbe, K. (2024). Let's verify step by step. *International Conference on Learning Representations*. https://proceedings.iclr.cc/paper_files/paper/2024/hash/aca97732e30bcf1303bc22ac3924fd16-Abstract-Conference.html

Pearl, J. (1995). Causal diagrams for empirical research. *Biometrika, 82*(4), 669–688. https://doi.org/10.1093/biomet/82.4.669

Pearl, J. (2009). *Causality: Models, reasoning, and inference* (2nd ed.). Cambridge University Press.

Perković, E., Textor, J., Kalisch, M., & Maathuis, M. H. (2015). A complete generalized adjustment criterion. *Proceedings of the 31st Conference on Uncertainty in Artificial Intelligence*. arXiv:1507.01524. https://arxiv.org/abs/1507.01524

Ross, S., Gordon, G., & Bagnell, D. (2011). A reduction of imitation learning and structured prediction to no-regret online learning. *Proceedings of the 14th International Conference on Artificial Intelligence and Statistics*, 627–635.

Schulman, J., Wolski, F., Dhariwal, P., Radford, A., & Klimov, O. (2017). *Proximal policy optimization algorithms*. arXiv:1707.06347. https://arxiv.org/abs/1707.06347

Shao, Z., et al. (2024). *DeepSeekMath: Pushing the limits of mathematical reasoning in open language models*. arXiv:2402.03300. https://arxiv.org/abs/2402.03300

Shpitser, I., VanderWeele, T., & Robins, J. M. (2010). On the validity of covariate adjustment for estimating causal effects. *Proceedings of the 26th Conference on Uncertainty in Artificial Intelligence*. https://proceedings.mlr.press/r8/shpitser10a.html

Turpin, M., Michael, J., Perez, E., & Bowman, S. R. (2023). Language models don't always say what they think: Unfaithful explanations in chain-of-thought prompting. *Advances in Neural Information Processing Systems, 36*.

Uesato, J., Kushman, N., Kumar, R., Song, F., Siegel, N., Wang, L., Creswell, A., Irving, G., & Higgins, I. (2022). *Solving math word problems with process- and outcome-based feedback*. arXiv:2211.14275. https://arxiv.org/abs/2211.14275

Zelikman, E., Wu, Y., Mu, J., & Goodman, N. D. (2022). STaR: Bootstrapping reasoning with reasoning. *Advances in Neural Information Processing Systems, 35*. https://proceedings.neurips.cc/paper_files/paper/2022/hash/639a9a172c044fbb64175b5fad42e9a5-Abstract-Conference.html
