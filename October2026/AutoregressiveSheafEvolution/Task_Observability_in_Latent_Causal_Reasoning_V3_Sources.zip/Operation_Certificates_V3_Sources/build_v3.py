"""Build Version 3 of 'Operation Certificates for Latent Causal Reasoning' from the supplied V2 Word file.

V2 is edited in place: its text, equations, tables and figures are kept. New material is converted by
Pandoc with V2 as the reference document; new tables copy V2's table look. Every number is read from
the validated C# output cs_v3.txt (and cs_out_rerun.txt for the reproduced inherited census)."""
import copy, json, os, subprocess, tempfile
from docx import Document
from docx.shared import Inches
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from lxml import etree

H = os.path.dirname(os.path.abspath(__file__)); SRC = os.path.join(os.path.dirname(H), "in", "v2.docx")
OUT = os.path.join(H, "Operation_Certificates_for_Latent_Causal_Reasoning_V3.docx")
cs = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1].split() for l in open(os.path.join(H, "cs_v3.txt"))}
val = json.load(open(os.path.join(H, "validation_v3.json"))); assert val["all_passed"]
NCHK, NLINES = len(val["checks"]), val["lines"]
W_ = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"; WNS = f'xmlns:w="{W_}"'

def I(k): return list(map(int, cs[k][:13])) if "precision" not in k else list(map(int, cs[k][:8]))
def num(x): return f"{x:,}"
def pc(a, b, d=1): return f"{100 * a / b:.{d}f}%"

# ------------------------------------------------------------------ numbers
K = ["deletion", "rule1", "rule2", "rule3"]; KN = {"deletion": "Condition deletion", "rule1": "Rule 1 (observation)", "rule2": "Rule 2 (action/observation)", "rule3": "Rule 3 (action deletion)"}
T = {t: {k: list(map(int, cs[f"{t}_census_{k}"])) for k in K} for t in ("tenths", "hundredths")}
apps = sum(T["hundredths"][k][0] for k in K)
for t in T:
    for k in K: assert T[t][k][1] == T[t][k][2] and T[t][k][3] == T[t][k][4]
lic_cells = sum(T["hundredths"][k][3] for k in K)
op = {t: list(map(int, cs[f"{t}_opcert"])) for t in T}
rep = {t: [list(map(int, cs[f"{t}_repair_alpha{i}"])) for i in range(3)] for t in T}
spec = {t: list(map(int, cs[f"{t}_repair_spectral"])) for t in T}
P = {t: {lab: cs[f"{t}_precision_{lab}"] for lab in ("d2_threshold", "dec2", "dec3", "dec4")} for t in T}
def pin(t, lab): p = list(map(int, P[t][lab][:8])); return p[5], p[4]
def qall(t, lab): p = list(map(int, P[t][lab][:8])); return p[7], p[6]
dig = {t: list(map(int, cs[f"{t}_digits_needed"])) for t in T}
hu = T["hundredths"]; te = T["tenths"]
rng_exact_h = [100 * hu[k][6] / hu[k][5] for k in K]; rng_exact_t = [100 * te[k][6] / te[k][5] for k in K]
rng_r2_h = [100 * hu[k][9] / hu[k][7] for k in K]
d2in = pin("hundredths", "d2_threshold"); d2all = qall("hundredths", "d2_threshold")
r = lambda a, b: f"{a:.1f}–{b:.1f}%"

doc = Document(SRC); body = doc.element.body

def fragment(md):
    with tempfile.TemporaryDirectory() as td:
        open(os.path.join(td, "f.md"), "w", encoding="utf-8").write(md)
        subprocess.run(["pandoc", "f.md", "-f", "markdown+tex_math_dollars-auto_identifiers-fancy_lists", "-o", "f.docx", f"--reference-doc={SRC}"], cwd=td, check=True)
        f = Document(os.path.join(td, "f.docx"))
        els = [copy.deepcopy(e) for e in f.element.body if e.tag != qn("w:sectPr")]
    for e in els:
        for b in list(e.iter(qn("w:bookmarkStart"))) + list(e.iter(qn("w:bookmarkEnd"))): b.getparent().remove(b)
    return els

def style_table(tbl, widths):
    tp = tbl.find(qn("w:tblPr"))
    for ch in list(tp): tp.remove(ch)
    for ch in etree.fromstring(f'<w:tblPr {WNS}><w:tblW w:w="{sum(widths)}" w:type="dxa"/><w:jc w:val="center"/><w:tblBorders>' +
                               "".join(f'<w:{s} w:val="single" w:sz="4" w:space="0" w:color="D9D9D9"/>' for s in ("top", "left", "bottom", "right", "insideH", "insideV")) +
                               '</w:tblBorders><w:tblLayout w:type="fixed"/><w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/></w:tblPr>'): tp.append(ch)
    for gc, w in zip(tbl.find(qn("w:tblGrid")).findall(qn("w:gridCol")), widths): gc.set(qn("w:w"), str(w))
    for ri, tr in enumerate(tbl.findall(qn("w:tr"))):
        trpr = tr.find(qn("w:trPr"))
        if trpr is None: trpr = OxmlElement("w:trPr"); tr.insert(0, trpr)
        for ch in list(trpr): trpr.remove(ch)
        trpr.append(OxmlElement("w:cantSplit"))
        if ri == 0: trpr.append(OxmlElement("w:tblHeader"))
        for ci, (tc, w) in enumerate(zip(tr.findall(qn("w:tc")), widths)):
            tcpr = tc.find(qn("w:tcPr"))
            if tcpr is None: tcpr = OxmlElement("w:tcPr"); tc.insert(0, tcpr)
            for ch in list(tcpr): tcpr.remove(ch)
            fill = "E9EEF2" if ri == 0 else "FFFFFF"
            for ch in etree.fromstring(f'<w:tcPr {WNS}><w:tcW w:w="{w}" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="{fill}"/><w:tcMar><w:top w:w="85" w:type="dxa"/>'
                                       '<w:left w:w="80" w:type="dxa"/><w:bottom w:w="85" w:type="dxa"/><w:right w:w="80" w:type="dxa"/></w:tcMar><w:vAlign w:val="center"/></w:tcPr>'): tcpr.append(ch)
            for p in tc.findall(qn("w:p")):
                ppr = p.find(qn("w:pPr"))
                if ppr is None: ppr = OxmlElement("w:pPr"); p.insert(0, ppr)
                for ch in list(ppr): ppr.remove(ch)
                jc = "left" if ci == 0 else "center"
                for ch in etree.fromstring(f'<w:pPr {WNS}><w:pStyle w:val="BodyText"/><w:spacing w:after="40" w:line="252" w:lineRule="auto"/><w:jc w:val="{jc}"/></w:pPr>'): ppr.append(ch)
                for rr in p.findall(qn("w:r")):
                    rpr = rr.find(qn("w:rPr"))
                    if rpr is None: rpr = OxmlElement("w:rPr"); rr.insert(0, rpr)
                    for x in rpr.findall(qn("w:b")) + rpr.findall(qn("w:sz")) + rpr.findall(qn("w:rStyle")): rpr.remove(x)
                    if ri == 0: rpr.insert(0, OxmlElement("w:b"))
                    sz = OxmlElement("w:sz"); sz.set(qn("w:val"), "19"); rpr.append(sz)

def caption(text, keep=True):
    p = OxmlElement("w:p"); ppr = OxmlElement("w:pPr"); ps = OxmlElement("w:pStyle"); ps.set(qn("w:val"), "Caption"); ppr.append(ps)
    kn = OxmlElement("w:keepNext")
    if not keep: kn.set(qn("w:val"), "0")
    ppr.append(kn); p.append(ppr)
    rr = OxmlElement("w:r"); rp = OxmlElement("w:rPr"); rp.append(OxmlElement("w:b")); rr.append(rp)
    t = OxmlElement("w:t"); t.text = text; t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve"); rr.append(t); p.append(rr)
    return p

def table(rows, widths, cap):
    els = fragment("\n".join(rows) + "\n")
    for e in els:
        if e.tag == qn("w:tbl"): style_table(e, widths)
    return [caption(cap)] + els

def figure(path, title, text, alt):
    p = doc.add_paragraph(style="Body Text"); p.alignment = 1
    run = p.add_run(); run.add_picture(path, width=Inches(6.4))
    el = p._p; el.getparent().remove(el)
    ppr = el.find(qn("w:pPr")); ppr.find(qn("w:pStyle")).addnext(OxmlElement("w:keepNext"))
    for d in el.iter("{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}docPr"): d.set("descr", alt)
    cap = caption(title, keep=False)
    br = OxmlElement("w:r"); br.append(OxmlElement("w:br")); t = OxmlElement("w:t"); t.text = text
    t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve"); br.append(t); cap.append(br)
    return [el, cap]

def norm(s): return s.replace("\xa0", " ").replace("’", "'")
def find(start, style=None):
    for p in doc.paragraphs:
        if norm(p.text).startswith(start) and (style is None or p.style.name == style): return p
    raise KeyError(start)
def after(anchor, els):
    ref = anchor._p if hasattr(anchor, "_p") else anchor
    for e in els: ref.addnext(e); ref = e
    return ref
def append_text(p, text):
    rr = OxmlElement("w:r"); t = OxmlElement("w:t"); t.text = text
    t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve"); rr.append(t); p._p.append(rr)
def replace_in(p, old, new):
    for t in p._p.iter(qn("w:t")):
        if old in t.text: t.text = t.text.replace(old, new); return
    raise KeyError(old)
def set_text(p, text):
    ts = list(p._p.iter(qn("w:t")))
    for t in ts: t.text = ""
    ts[0].text = text

# ------------------------------------------------------------------ front matter
set_text(find("Version 2, 31 October 2026"), "Version 3, 31 October 2026")
set_text(find("Long reasoning traces from reinforcement-trained teachers"),
    "Long reasoning traces from reinforcement-trained teachers can supply demonstrations for Autoregressive Do Calculus, but their values, stated operations "
    "and realized computations require different evidence. We extend the verified-transition proposal with context-bound operation semantics, a composition "
    "theorem, a quantitative commuting-square bound and a finite continuation quotient that characterizes sufficient exact memory. The inherited adjustment "
    "census covers all 1,024 DAGs respecting a fixed five-vertex order, with three positive binary models per graph in each parameter regime. Invalid "
    "adjustment sets match the true answer to two decimals in 30.5% of the finer-grid cases, while overlap agreement accepts every consistently computed wrong "
    f"adjustment. Version 3 recompiles the immutable C# kernel, which reproduces the inherited output byte for byte, and adds an exhaustive operation census of "
    f"{num(apps)} applications per regime of condition deletion and the three do-calculus rules. Every graph-licensed application holds exactly. Among unlicensed "
    f"applications, {r(min(rng_exact_h), max(rng_exact_h))} hold exactly on the finer grid and {r(min(rng_exact_t), max(rng_exact_t))} on the tenths grid; "
    f"{r(min(rng_r2_h), max(rng_r2_h))} of individual finer-grid cells agree to two decimals. The dropped-action derivations accepted by the value certificate "
    f"({num(op['hundredths'][5])} and {num(op['tenths'][5])}) are never graph-licensed, and an operation-bound certificate rejects every one. Exact weighted repair of the "
    "table audit retains a share 2α/(2α+1) of a marginal-table slip and moves a share 1/(2α+1) of a joint-table slip into a previously correct answer, so no audit "
    f"weight repairs both. At the decoding tolerance of prediction D2, {pc(*d2in)} of numerically wrong invalid-set answers lie inside the interval enclosure "
    "of the honest decoded tables. Spectral, sampling, error-spending and neuroscience connections are retained from Version 2. The inherited validator passes "
    f"36 checks and the new independent validator passes {NCHK} checks on {NLINES} census records. No teacher was queried, student trained or new biological "
    "data collected. Learned-model gains and neural mappings remain falsifiable hypotheses.")

p = find("The inherited study is exhaustive over a fixed-order graph family")
after(p, fragment(
    "Version 3 returns the new contracts to the original C# kernel. It replaces the Version 2 toy instances of Proposition 7.2 and Theorem 9.2 by exhaustive "
    "censuses over the inherited 6,144 models, proves that the dropped action is never licensed in an adjustment derivation (Proposition 7.5), gives the exact "
    "weighted repair of the table audit (Proposition 9.4) and an interval enclosure for value checks on decoded tables (Proposition 8.7). Each census line is "
    "recomputed by an independent Python program."))
append_text(find("Sections 2 to 6 retain and correct"), " Sections 13.2 to 13.7 report the Version 3 census.")
append_text(find("The certificate accepted 186 dropped-condition derivations"),
    " Section 13.4 shows that none of these deletions is graph-licensed (Proposition 7.5); an operation-bound certificate rejects all of them.")

# ------------------------------------------------------------------ Section 7.3
p = find("These levels are cumulative only when their extra obligations are met")
after(p, fragment(rf"""## 7.3 The dropped condition is never licensed

**Proposition 7.5 (the dropped action is unlicensed in every adjustment derivation).** Let $X$ be an ancestor of $Y$ in a DAG and let $Z$ satisfy the adjustment criterion for $(X,Y)$. Then $Y$ and $X$ are d-connected given $Z$. Replacing $P(Y \mid X, Z)$ by $P(Y \mid Z)$ is therefore never a graph-licensed step of such a derivation.

*Proof.* There is a directed path from $X$ to $Y$. Its interior vertices lie on a proper causal path and are forbidden, so none belongs to $Z$. A directed path has no colliders, so it is open given $Z$. ∎

The 186 and 2,268 dropped-condition derivations that the value certificate accepted in Table 2 are thus coincidences of the sampled law, never instances of a reusable rule. The operation-bound certificate of Definition 7.1 rejects them by its premise check alone; Section 13.4 confirms this on every inherited query.

**Proposition 7.6 (unlicensed deletion is non-generic).** Fix a DAG on binary events. If $Y$ and $W$ are not d-separated by $S$, the positive conditional-probability parameters at which $P(Y = 1 \mid W, S) = P(Y = 1 \mid S)$ holds in every cell form a set of Lebesgue measure zero.

*Proof.* For binary $Y$ the cellwise equality is the conditional independence $Y \perp W \mid S$. For discrete DAG models, the parameters at which a d-connected pair is conditionally independent have measure zero (Meek, 1995). ∎

Proposition 7.6 is a statement about continuous parameters. Problems written on a coarse grid sit on a measure-zero set where such coincidences are common, which Section 13.3 measures for deletion and for the three rules of the do-calculus. Rules 2 and 3 compare interventional and observational laws; for them we report the census without claiming a genericity theorem.
"""))

# ------------------------------------------------------------------ Section 8.3: enclosure
p = find("For K = Δ") if any(norm(x.text).startswith("For K = Δ") for x in doc.paragraphs) else None
if p is None:
    p = next(x for x in doc.paragraphs if "the sharp minimax error is" in norm(x.text))
after(p, fragment(rf"""**Proposition 8.7 (interval enclosure of a decoded adjustment sum).** Suppose a checkpoint decodes tables $\hat T_1$ and $\hat T_2$ with $\sum_z \hat T_1(z) = 1$, and the true tables satisfy $|T_1 - \hat T_1| \le h$, $|T_2 - \hat T_2| \le h$ entrywise, with $T_1$ in the simplex and $T_2 \in [0,1]$. The set of adjustment sums consistent with the decoded tables is a closed interval $[\ell, u]$. Its endpoints are the optima of two linear programmes over $\{{T_1 : \max(0,\hat T_1 - h) \le T_1 \le \min(1,\hat T_1 + h),\ \sum_z T_1(z) = 1\}}$ with coefficients $\max(0,\hat T_2 - h)$ and $\min(1,\hat T_2 + h)$, solved exactly by a greedy fill. With $m$ strata and range $\rho$ of $\hat T_2$,

$$u - \ell \le 2h + \rho\,\min(mh,\,2).\quad\quad\text{{~~~~(15)}}$$

A value check made on the decoded tables can refute a submitted answer $a$ only if $a \notin [\ell, u]$.

*Proof.* For fixed nonnegative $T_1$ the sum is increasing in each entry of $T_2$, so its extremes use the endpoint coefficients; the remaining problem is linear over a box intersected with the simplex, where the greedy fill is optimal. The feasible set is connected and the sum is continuous, so every intermediate value is attained. For (15), write $\sum T_2 T_1 - \sum \hat T_2 \hat T_1 = \sum (T_2 - \hat T_2) T_1 + \sum (\hat T_2 - c)(T_1 - \hat T_1)$ for the midrange $c$ of $\hat T_2$, using $\sum (T_1 - \hat T_1) = 0$. The first term is at most $h$ and the second at most $\tfrac{{1}}{{2}}\rho\,\lVert T_1 - \hat T_1 \rVert_1 \le \tfrac{{1}}{{2}}\rho \min(mh, 2)$. ∎

Prediction D2 asks for decoded tables within $0.01$. Proposition 8.7 converts that tolerance into the set of answers a decoded value check cannot reject. Section 13.6 shows that this set contains a large share of the invalid adjustment answers.
"""))

# ------------------------------------------------------------------ Section 9: repair
p = find("Figure 2 Compatibility and decoded execution", "Caption")
after(p, fragment(rf"""**Proposition 9.4 (repair allocates trust; it does not locate errors).** In the adjustment audit, let the overlap map send $T_0$ to its $Z$-marginal and compare it with $T_1$, so the residual is $r(z) = \sum_x T_0(x,z) - T_1(z)$. Weight every $T_0$ coordinate by $1$ and every $T_1$ coordinate by $\alpha > 0$. The nearest compatible section in this weighted norm is

$$T_1'(z) = T_1(z) + \frac{{r(z)}}{{2\alpha + 1}},\qquad T_0'(x,z) = T_0(x,z) - \frac{{\alpha\, r(z)}}{{2\alpha + 1}}.\quad\quad\text{{~~~~(16)}}$$

Consequently, a slip $\delta$ placed in $T_1$ leaves the share $2\alpha/(2\alpha+1)$ of $\delta$ in $T_1'$, and a slip $\delta$ placed in one entry of $T_0$ moves the share $1/(2\alpha+1)$ of $\delta$ into $T_1'$. The two shares sum to one for every $\alpha$. With the outcome table fixed, the adjustment-answer error after repairing a $T_1$ slip is exactly $2\alpha/(2\alpha+1)$ times the error before. A $T_0$ slip that left the answer exactly correct changes it by $T_2(z_0)\,\delta/(2\alpha+1)$. At $\alpha = 1$, $BB^{{\mathsf{{T}}}} = 3I$, so every positive eigenvalue of the audit Laplacian equals $3$ and (12) holds with equality for every table vector.

*Proof.* The constraint couples only the two $T_0$ entries and the $T_1$ entry of one stratum, so strata decouple. Minimise $\alpha(c'-c)^2 + (a'-a)^2 + (b'-b)^2$ subject to $a' + b' = c'$ with a Lagrange multiplier to obtain (16). Substituting $r = -\delta$ or $r = \delta$ gives the shares; the answer $\sum_z T_2(z) T_1(z)$ is linear in $T_1$. For the spectral statement, each row of $B$ has two entries $+1$ and one $-1$ on disjoint coordinates. ∎

A correct repair requires down-weighting the corrupted table, that is, knowing where the error is. That knowledge is what a certificate supplies. The linear audit also ignores the affine normalisation $\sum_z T_1(z) = 1$, which every repaired $T_0$ slip violates. Repair is therefore an operation to apply after a certificate has located the faulty record, not a substitute for one.
"""))

# ------------------------------------------------------------------ Section 12.4: D2 caution
p = find("D2 requires a narrower interpretation")
after(p, fragment(
    f"Proposition 8.7 adds a separate caution. Meeting the D2 readout tolerance does not make decoded tables precise enough for a value check. At $h = 0.01$, "
    f"{pc(*d2in)} of the numerically wrong invalid-set answers in the finer-grid census lie inside the enclosure of the honest tables, and only {pc(*d2all)} of the "
    "queries with such answers have all of them excluded (Section 13.6). Adjustment-set selection must therefore be checked through its graph premise, "
    "not by comparing decoded values."))

# ------------------------------------------------------------------ Section 13
replace_in(find("The inherited independent validator was rerun"), "No C# compiler or teacher model was invoked in this revision.",
    "Version 2 invoked no C# compiler; Version 3 recompiles the kernel (Section 13.2). No teacher model was invoked in any version.")
h13 = find("13 What the added computation establishes", "Heading 1")
after(h13, fragment("## 13.1 Finite examples of Version 2\n"))
anchor = find("These records demonstrate arithmetic and interface behaviour")

def rowc(k):
    a, b = T["tenths"][k], T["hundredths"][k]
    return (f"| {KN[k]} | {num(b[1])} of {num(b[0])} | {pc(a[6], a[5])} | {pc(b[6], b[5], 2)} | {pc(b[9], b[7])} | {num(a[12])} / {num(b[12])} |")
t9 = table(["| Operation | Licensed applications | Unlicensed exactly equal, tenths | Unlicensed exactly equal, hundredths | Unlicensed cells equal to 2 decimals, hundredths | Unlicensed in all three models, tenths / hundredths |",
            "|---|---|---|---|---|---|"] + [rowc(k) for k in K], [1900, 1500, 1350, 1450, 1560, 1600],
           "Table 9 Value coincidence versus graphical licence (every application per regime)")
def rowo(lbl, cases, vt, vh, licd, opc): return f"| {lbl} | {cases} | {vt} | {vh} | {licd} | {opc} |"
o_t, o_h = op["tenths"], op["hundredths"]
t10 = table(["| Derivation | Cases per regime | Value certificate, tenths | Value certificate, hundredths | Graph licence of the stated operation | Operation-bound certificate |", "|---|---|---|---|---|---|",
             rowo("Honest, smallest valid set", num(o_h[0]), num(o_t[1]), num(o_h[1]), "All valid", num(o_h[1])),
             rowo("Invalid adjustment set", num(o_h[2]), num(o_t[3]), num(o_h[3]), "Premise fails", "0"),
             rowo("X dropped from P(y \\| x, z)", num(o_h[4]), num(o_t[5]), num(o_h[5]), f"{num(o_h[6])} licensed", num(o_h[7]))],
            [2160, 1250, 1400, 1450, 1700, 1400], "Table 10 Value certificate and operation-bound certificate on the inherited derivations")
alph = ["1/10", "1", "10"]; keep = ["1/6", "2/3", "20/21"]; mov = ["5/6", "1/3", "1/21"]
t11 = table(["| Audit weight α on T1 | Share of a T1 slip retained | Share of a T0 slip moved into T1 | T1 slips matching (16), per regime | T0 slips leaving a wrong answer, per regime |", "|---|---|---|---|---|"] +
            [f"| {alph[i]} | {keep[i]} | {mov[i]} | {num(rep['hundredths'][i][2])} of {num(rep['hundredths'][i][0])} | {num(rep['hundredths'][i][6])} of {num(rep['hundredths'][i][4])} |" for i in range(3)],
            [1700, 1800, 1900, 2000, 1960], "Table 11 Exact weighted repair of single table slips")
hl = [("d2_threshold", "0.01 (D2)"), ("dec2", "0.005"), ("dec3", "0.0005"), ("dec4", "0.00005")]
def rowp(lab, s):
    pt, ph = list(map(int, P["tenths"][lab][:8])), list(map(int, P["hundredths"][lab][:8]))
    return f"| {s} | {float(P['hundredths'][lab][8]):.5f} | {float(P['hundredths'][lab][9]):.5f} | {pc(pt[5], pt[4])} | {pc(ph[5], ph[4])} | {pc(ph[7], ph[6])} |"
t12 = table(["| Decoded precision h | Mean enclosure width, hundredths | Largest width, hundredths | Wrong invalid answers inside, tenths | Wrong invalid answers inside, hundredths | Queries with all wrong answers excluded, hundredths |", "|---|---|---|---|---|---|"] +
            [rowp(l, s) for l, s in hl], [1500, 1500, 1400, 1600, 1700, 1660], "Table 12 What a value check on decoded tables can reject")
fig4 = figure(os.path.join(H, "fig", "v3_licence_and_precision.png"), "Figure 4 Licence, coincidence and the precision of value checks",
              "Left: share of unlicensed applications that hold exactly on the sampled law, by operation and parameter grid. Right: share of numerically wrong "
              "invalid adjustment answers that lie inside the interval enclosure of the honest decoded tables, against the decoding precision h. "
              "Exact census over 6,144 models; not a trained-model experiment.",
              "Bar chart of exact coincidence rates for four operations in two grids, and a line chart of the share of wrong answers inside the decoded-table enclosure falling as precision improves.")

dh, dt = dig["hundredths"], dig["tenths"]
s2 = T["hundredths"]
sec = fragment(rf"""## 13.2 The recompiled kernel

The Version 3 source compiles the inherited C# kernel with .NET 8 and runs it unchanged. Its 34-line summary and both error files are byte-for-byte identical to the recorded Version 1 outputs. The new census is a separate entry point of the same kernel. It uses the same seeds, graph order and model draws, so its 6,144 models (3,072 per regime) are exactly those behind Tables 1 to 3. All arithmetic is exact over rationals, and public values are immutable records.

## 13.3 Do-calculus rules: licence and coincidence

For every model the census applies every instance of four operations, {num(apps)} applications per regime. *Condition deletion* replaces $P(Y \mid W, S)$ by $P(Y \mid S)$. *Rule 1* deletes an observation $Z$ from $P(Y \mid do(X), Z, S)$. *Rule 2* exchanges $do(X)$ with conditioning on $X$ in $P(Y \mid do(X), S)$. *Rule 3* deletes the action from $P(Y \mid do(X), S)$. Each application is licensed by the corresponding d-separation in the mutilated graph (Pearl, 1995) and checked numerically at both action values and every conditioning value; one such equality is a *cell*.

Soundness holds without exception: all {num(sum(s2[k][1] for k in K))} licensed applications per regime hold exactly, in all {num(lic_cells)} of their cells. Unlicensed applications are where value and operation separate (Table 9, Figure 4A). On the hundredths grid {r(min(rng_exact_h), max(rng_exact_h))} of them hold exactly on the sampled law; on the tenths grid {r(min(rng_exact_t), max(rng_exact_t))}. Rule 2, the step that turns an intervention into a conditional, has the highest rate in both regimes. A value check made on one cell is weaker still: {pc(s2['rule2'][8], s2['rule2'][7])} of unlicensed Rule 2 cells hold exactly on the finer grid, and {pc(s2['rule2'][9], s2['rule2'][7])} agree to two decimals.

The last column of Table 9 asks whether a coincidence belongs to the graph or to the draw. On the hundredths grid no unlicensed pattern held in all three models of its graph, consistent with Proposition 7.6. On the tenths grid {num(sum(te[k][12] for k in K))} graph-level patterns did, so a coarse problem generator can make an unlicensed rule appear valid across repeated draws. This is a property of the data generator, not of the graph.

## 13.4 Operation-bound certificates on the inherited derivations

Table 10 replays the inherited derivations with the operation recorded. The value certificate again accepts all honest derivations, no invalid set and {num(o_h[5])} ({num(o_t[5])}) dropped-action derivations. None of the {num(o_h[4])} dropped-action steps is graph-licensed, as Proposition 7.5 requires, so the operation-bound certificate rejects every one while still accepting every honest derivation. The slipped tables of Table 2 already fail the value comparison, and the operation-bound certificate adds the premise check to it, so they remain rejected.

## 13.5 Repair census

Every marginal slip of Table 2 ({num(rep['hundredths'][0][0])} per regime) and a new slip of $0.01$ in the $T_0$ entry at the heaviest stratum and the queried action value ({num(rep['hundredths'][0][4])} per regime) were repaired by the exact weighted projection, computed by a generic rational solve of the normal equations rather than by (16). Every repaired section has zero residual, and every case matches (16) and the shares of Proposition 9.4 for all three weights (Table 11). After repairing a $T_1$ slip, the answer is exactly right only in the {num(rep['hundredths'][0][3])} ({num(rep['tenths'][0][3])}) cases where the slip had not changed it. Every repaired $T_0$ slip turns an exactly correct answer into a wrong one and breaks the normalisation of $T_1$. At $\alpha = 1$ all {num(spec['hundredths'][0])} cases per regime attain (12) with equality.

## 13.6 Precision of value checks on decoded tables

For each query the honest tables of the smallest valid set are perturbed only through the enclosure of Proposition 8.7, and every invalid set's exact answer is tested for membership (Table 12, Figure 4B). Mean widths stay close to $2.16h$, well inside (15). Exact coincidences can never be excluded, so they are left out of the shares. At the D2 tolerance $h = 0.01$, {pc(*d2in)} of the wrong answers lie inside the enclosure. Two-decimal precision still leaves {pc(*pin('hundredths', 'dec2'))}, three decimals {pc(*pin('hundredths', 'dec3'))} and four decimals {pc(*pin('hundredths', 'dec4'))}. The least number of decimals that excludes a wrong answer is 1 for {num(dh[0])} of {num(sum(dh))} wrong answers, 2 for {num(dh[1])}, 3 for {num(dh[2])}, 4 for {num(dh[3])}, 5 for {num(dh[4])}, 6 for {num(dh[5])}, 7 for {num(dh[6])} and 8 for {num(dh[7])}; {num(dh[8])} need more than eight. The tenths grid needs at most seven.

A decoder that meets D2 therefore supports a value check on about half of the wrong adjustment answers. The graph premise of Proposition 4.2 remains the only check that rejects all of them, at any precision.

## 13.7 Validation

An independent Python program recomputes all {NLINES} census records with integer-scaled joint laws, d-separation by explicit path enumeration with the blocking rule, the rule licences written as edge deletions, the closed form (16) instead of the generic solve, and a bit-exact replay of the parameter streams. It passes {NCHK} checks, including licensed-application soundness for every rule. Vertex enumeration of the box-simplex polytope confirms 1,516 sampled enclosure optima per regime, and a floating-point least-squares projection agrees with the exact repair to within $2 \times 10^{{-16}}$ on 186 sampled cases per regime. The census takes about eighty seconds in C#.

These are exhaustive calculations on a declared finite family. They measure how often values agree without a licence; they do not estimate how often a real teacher proposes an unlicensed step.
""")
# place: 13.2 and 13.3 text, Table 9 after 13.3's last paragraph, etc.
def split_at(els, heading):
    i = next(i for i, e in enumerate(els) if heading in "".join(e.itertext())); return els[:i], els[i:]
a, rest = split_at(sec, "13.4 Operation-bound")
b, rest = split_at(rest, "13.5 Repair census")
c, rest = split_at(rest, "13.6 Precision of value checks")
d, e = split_at(rest, "13.7 Validation")
last = after(anchor, a + t9 + b + t10 + c + t11 + d + t12 + fig4 + e)

# ------------------------------------------------------------------ Section 14, 15, Appendix, references
p = find("The exact adjustment census is exhaustive over DAGs respecting one fixed")
replace_in(p, "The original C# value checker remains useful for numerical certification, but it does not bind the actual textual operator that produced a coincident table.",
           "The original C# value checker remains useful for numerical certification, but it does not bind the actual textual operator that produced a coincident table; Version 3 adds that binding for adjustment and deletion.")
after(p, fragment(
    "The Version 3 census covers single actions, single binary outcomes and five events in one fixed order, with three models per graph. Its graph-level "
    "coincidence column depends on those three draws, and Proposition 7.6 is proved only for deletion. The repair analysis concerns one linear audit with "
    "diagonal weights; nonlinear audits and learned restriction maps need their own analysis. The enclosure of Proposition 8.7 assumes worst-case entrywise "
    "decoding error within a declared bound; a probabilistic decoder needs a coverage statement before it can use it."))
append_text(find("Horizontal sheaf structure provides a quantitative compatibility audit"),
    " The Version 3 census makes these distinctions measurable: graph licences are exact where value checks only coincide, and audit repair redistributes error "
    "unless a certificate first locates it.")
p = find("The immutable public packet consists of")
after(p, fragment(
    "Version 3 adds kernel/OpCensus.cs to the same C# project. Run dotnet run -c Release --project kernel -- out to reproduce the inherited census and "
    "dotnet run -c Release --project kernel -- out_v3 --v3 to produce cs_v3.txt. Then python validate_v3.py cs_v3.txt validation_v3.json recomputes every "
    "record independently, fig_v3.py draws Figure 4, and build_v3.py edits the Version 2 Word file into this paper. The kernel targets .NET 8; the validator "
    "uses Python 3 with NumPy."))
replace_in(find("Claim status."), "Sections 5 and 13 report deterministic or seeded finite calculations.",
           "Sections 5 and 13 report deterministic or seeded finite calculations; Sections 13.2 to 13.7 come from the recompiled C# kernel and its independent validator.")
mattar = find("Mattar, M. G., & Daw, N. D. (2018).", "Bibliography1")
meek = copy.deepcopy(mattar._p); mattar._p.addnext(meek)
from docx.text.paragraph import Paragraph
mp = Paragraph(meek, mattar._parent)
for rr in list(meek.findall(qn("w:r"))) + list(meek.findall(qn("w:hyperlink"))): meek.remove(rr)
def run(text, italic=False):
    rr = OxmlElement("w:r")
    if italic: rp = OxmlElement("w:rPr"); rp.append(OxmlElement("w:i")); rr.append(rp)
    t = OxmlElement("w:t"); t.text = text; t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve"); rr.append(t); meek.append(rr)
run("Meek, C. (1995). Strong completeness and faithfulness in Bayesian networks. "); run("Proceedings of the 11th Conference on Uncertainty in Artificial Intelligence", True)
run(", 411–418. https://arxiv.org/abs/1302.4973")

doc.core_properties.title = "Operation Certificates for Latent Causal Reasoning, Version 3"
doc.save(OUT); print("saved", OUT)

# ------------------------------------------------------------------ OMML schema order (Pandoc emits some children out of order)
import zipfile, shutil
M_ = "http://schemas.openxmlformats.org/officeDocument/2006/math"
ORDER = {"dPr": ["begChr", "sepChr", "endChr", "grow", "shp", "ctrlPr"], "rPr": ["lit", "nor", "scr", "sty", "brk", "aln"]}
def fix_math(xml):
    root = etree.fromstring(xml)
    for name, order in ORDER.items():
        for el in root.iter(f"{{{M_}}}{name}"):
            kids = list(el)
            for k in kids: el.remove(k)
            if name == "rPr" and any(etree.QName(k).localname == "nor" for k in kids):
                kids = [k for k in kids if etree.QName(k).localname not in ("sty", "scr")]
            for k in sorted(kids, key=lambda k: order.index(etree.QName(k).localname) if etree.QName(k).localname in order else 99): el.append(k)
    import re as _re
    for rr in root.iter(f"{{{M_}}}r"):
        t = rr.find(f"{{{M_}}}t"); rp = rr.find(f"{{{M_}}}rPr")
        if t is not None and rp is not None and _re.fullmatch(r"\s*\(\d+\)", t.text or "") and rp.find(f"{{{M_}}}nor") is not None:
            for k in list(rp): rp.remove(k)
            sty = etree.SubElement(rp, f"{{{M_}}}sty"); sty.set(f"{{{M_}}}val", "p")
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
tmp = OUT + ".tmp"
with zipfile.ZipFile(OUT) as zi, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zo:
    for it in zi.infolist():
        data = zi.read(it.filename)
        if it.filename == "word/document.xml": data = fix_math(data)
        zo.writestr(it, data)
shutil.move(tmp, OUT); print("math order fixed")
