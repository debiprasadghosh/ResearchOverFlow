"""Independent validation of the Version 3 operation census (cs_v3.txt).

Independent of the C# kernel in four ways: integer-scaled joint laws instead of rationals; d-separation
by explicit path enumeration with the blocking rule instead of moralisation; the do-calculus licences
written as edge deletions on edge lists; and the sheaf repair by its closed form per stratum instead of
a generic weighted projection (with a floating-point least-squares spot check). The interval enclosure
reuses the greedy fill but is spot-checked against vertex enumeration of the box-simplex polytope.
Usage: python validate_v3.py cs_v3.txt validation_v3.json"""
import itertools, json, math, random, sys
from fractions import Fraction as F
from multiprocessing import Pool

import numpy as np

n = 5; PAIRS = [(i, j) for i in range(n) for j in range(i + 1, n)]
ALPHAS = [F(1, 10), F(1), F(10)]
HS = [("d2_threshold", F(1, 100)), ("dec2", F(1, 200)), ("dec3", F(1, 2000)), ("dec4", F(1, 20000))]

class Rng:
    def __init__(s, st): s.s = st
    def next(s):
        s.s = (s.s + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF; z = s.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & 0xFFFFFFFFFFFFFFFF
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & 0xFFFFFFFFFFFFFFFF
        return z ^ (z >> 31)
    def uniform(s): return (s.next() >> 11) * (1.0 / 9007199254740992.0)
    def int(s, lo, hi): return lo + math.floor(s.uniform() * (hi - lo + 1))

def bits(s): return [i for i in range(n) if s >> i & 1]

def desc(edges, s):
    s = set(s)
    while True:
        t = s | {b for a, b in edges if a in s}
        if t == s: return s
        s = t

def anc(edges, s):
    s = set(s)
    while True:
        t = s | {a for a, b in edges if b in s}
        if t == s: return s
        s = t

def paths(edges, x, y):
    adj = {i: [] for i in range(n)}
    for a, b in edges: adj[a].append((b, "out")); adj[b].append((a, "in"))
    def go(v, path, dirs):
        if v == y: yield list(path), list(dirs); return
        for w, d in adj[v]:
            if w in path: continue
            path.append(w); dirs.append(d); yield from go(w, path, dirs); path.pop(); dirs.pop()
    yield from go(x, [x], [])

def blocked(edges, path, dirs, z):
    for k in range(1, len(path) - 1):
        v = path[k]
        if dirs[k - 1] == "out" and dirs[k] == "in":
            if not (desc(edges, {v}) & z): return True
        elif v in z: return True
    return False

def dsep(edges, a, b, z):
    return all(blocked(edges, p, d, set(z)) for p, d in paths(edges, a, b))

def adjustment_valid(edges, x, y, z):
    causal = [p for p, d in paths(edges, x, y) if all(t == "out" for t in d)]
    forb = desc(edges, {v for p in causal for v in p[1:]}) | {x}
    if z & forb: return False
    return all(blocked(edges, p, d, z) for p, d in paths(edges, x, y) if not all(t == "out" for t in d))

def subsets(mask):
    s = mask
    while True:
        yield s
        if s == 0: return
        s = (s - 1) & mask

def emb(zmask, k): return sum((k >> j & 1) << i for j, i in enumerate(bits(zmask)))
def r2(a, b): return (200 * a + b) // (2 * b)          # round half up of 100·a/b, a, b > 0
def rq(q, d): t = q * 10 ** d + F(1, 2); return t.numerator // t.denominator

def marg(law):
    M = [0] * 1024
    for v, p in enumerate(law):
        if p:
            for mask in range(32): M[mask << 5 | (v & mask)] += p
    return M

def cond(M, y, mask, vals): return M[(mask | 1 << y) << 5 | ((vals | 1 << y) & (mask | 1 << y))], M[mask << 5 | (vals & mask)]

def greedy(c, lo, hi, maximise):
    rem = 1 - sum(lo); t = list(lo)
    for k in sorted(range(len(c)), key=lambda k: (-c[k] if maximise else c[k], k)):
        a = min(rem, hi[k] - lo[k]); t[k] += a; rem -= a
    assert rem == 0
    return sum(ci * ti for ci, ti in zip(c, t))

def enclosure(t1, t2, h):
    l1 = [max(F(0), v - h) for v in t1]; u1 = [min(F(1), v + h) for v in t1]
    l2 = [max(F(0), v - h) for v in t2]; u2 = [min(F(1), v + h) for v in t2]
    return greedy(l2, l1, u1, False), greedy(u2, l1, u1, True)

def vertex_extremum(c, lo, hi, maximise):
    """Independent LP: vertices of {lo ≤ t ≤ hi, Σt = 1} have at most one coordinate strictly inside its bounds."""
    m = len(c); best = None
    for free in range(m):
        for pat in itertools.product((0, 1), repeat=m - 1):
            t = []; it = iter(pat)
            for k in range(m): t.append(None if k == free else (hi[k] if next(it) else lo[k]))
            s = 1 - sum(v for v in t if v is not None)
            if not (lo[free] <= s <= hi[free]): continue
            t[free] = s; val = sum(ci * ti for ci, ti in zip(c, t))
            best = val if best is None or (val > best if maximise else val < best) else best
    return best

GRAPH_CACHE = {}

def graph_licences(dm):
    edges = [PAIRS[k] for k in range(len(PAIRS)) if dm >> k & 1]
    no_in = lambda x: [(a, b) for a, b in edges if b != x]
    no_out = lambda x: [(a, b) for a, b in edges if a != x]
    L = {}
    for y in range(n):
        for w in range(n):
            if w == y: continue
            rest = 31 & ~(1 << y | 1 << w)
            for s in subsets(rest):
                S = set(bits(s))
                L[(0, y, w, s, 0)] = dsep(edges, y, w, S)
                x = w
                L[(2, y, x, s, 0)] = dsep(no_out(x), y, x, S)
                L[(3, y, x, s, 0)] = dsep(edges if x in anc(edges, S) else no_in(x), y, x, S)
                for z in bits(rest):
                    if s >> z & 1: continue
                    L[(1, y, x, s, z)] = dsep(no_in(x), y, z, S | {x})
    return edges, L

def work(job):
    dm, models, grid = job
    edges, L = graph_licences(dm)
    parents = [sorted(a for a, b in edges if b == i) for i in range(n)]
    C = {k: [0] * 13 for k in ("deletion", "rule1", "rule2", "rule3")}
    size = {k: [0] * 8 for k in C}
    eqm = {key: 0 for key in L}
    out = dict(queries=0, honest=0, invalid=0, drops=0, dropv=0, dropl=0,
               rep=[[0] * 9 for _ in ALPHAS], spec=[0, 0, 0], pre=[[0] * 8 for _ in HS], wsum=[[] for _ in HS], wmax=[None] * len(HS),
               digits=[0] * 10, samples=[])
    rnd = random.Random(dm)
    for cpt in models:
        def num(i, v):
            c = sum((v >> p & 1) << k for k, p in enumerate(parents[i])); k = cpt[i][c]
            return k if v >> i & 1 else grid - k
        obs = [math.prod(num(i, v) for i in range(n)) for v in range(32)]
        dol = {(x, xv): [0 if (v >> x & 1) != xv else math.prod(num(i, v) for i in range(n) if i != x) for v in range(32)] for x in range(n) for xv in (0, 1)}
        Mo = marg(obs); Md = {k: marg(v) for k, v in dol.items()}
        def tally(kind, key, csize, cells):
            l = L[key]; a = C[kind]; allq = True; c = ce = cr = 0
            for (p, q), (r, s) in cells:
                c += 1; e = p * s == r * q; ce += e; allq &= e
                cr += r2(p, q) == r2(r, s)
            a[0] += 1
            if l: a[1] += 1; a[3] += c; a[4] += ce; a[2] += allq
            else:
                a[5] += 1; a[7] += c; a[8] += ce; a[9] += cr; a[6] += allq
                size[kind][2 * csize] += 1; size[kind][2 * csize + 1] += allq
            eqm[key] += allq
        for y in range(n):
            for w in range(n):
                if w == y: continue
                rest = 31 & ~(1 << y | 1 << w)
                for s in subsets(rest):
                    m = 1 << bin(s).count("1"); cs = bin(s).count("1")
                    tally("deletion", (0, y, w, s, 0), cs, [(cond(Mo, y, s | 1 << w, emb(s, k)), cond(Mo, y, s | 1 << w, emb(s, k) | 1 << w)) for k in range(m)])
                    x = w
                    tally("rule2", (2, y, x, s, 0), cs, [(cond(Md[x, xv], y, s, emb(s, k)), cond(Mo, y, s | 1 << x, emb(s, k) | xv << x)) for xv in (0, 1) for k in range(m)])
                    tally("rule3", (3, y, x, s, 0), cs, [(cond(Md[x, xv], y, s, emb(s, k)), cond(Mo, y, s, emb(s, k))) for xv in (0, 1) for k in range(m)])
                    for z in bits(rest):
                        if s >> z & 1: continue
                        tally("rule1", (1, y, x, s, z), cs, [(cond(Md[x, xv], y, s | 1 << z, emb(s, k) | zv << z), cond(Md[x, xv], y, s, emb(s, k)))
                                                            for xv in (0, 1) for zv in (0, 1) for k in range(m)])
        # adjustment queries
        tot = grid ** 5
        for x in range(n):
            for y in range(x + 1, n):
                if x not in anc(edges, {y}): continue
                others = 31 & ~(1 << x | 1 << y)
                for xv in (0, 1):
                    out["queries"] += 1
                    a_, b_ = cond(Md[x, xv], y, 0, 0); truth = F(a_, b_)
                    def deriv(z):
                        m = 1 << bin(z).count("1")
                        t1 = [F(Mo[z << 5 | emb(z, k)], tot) for k in range(m)]
                        t2 = [F(*cond(Mo, y, z | 1 << x, emb(z, k) | xv << x)) for k in range(m)]
                        return t1, t2, sum((p * q for p, q in zip(t2, t1)), F(0))
                    valid = []; inval = []
                    for z in subsets(others):
                        if adjustment_valid(edges, x, y, set(bits(z))): valid.append(z)
                        else: inval.append(deriv(z)[2])
                    out["invalid"] += len(inval)
                    zs = min(valid, key=lambda z: (bin(z).count("1"), z)); t1, t2, ans = deriv(zs); m = len(t1)
                    out["honest"] += ans == truth
                    out["drops"] += 1
                    t2d = [F(*cond(Mo, y, zs, emb(zs, k))) for k in range(m)]
                    out["dropv"] += t2d == t2
                    out["dropl"] += dsep(edges, y, x, set(bits(zs)))
                    # repair, closed form per stratum: T1' = T1 + r/(2α+1), T0' = T0 − α r/(2α+1)
                    t0 = [F(Mo[(zs | 1 << x) << 5 | (emb(zs, k >> 1) | (k & 1) << x)], tot) for k in range(2 * m)]
                    z0 = min(range(m), key=lambda k: (-t1[k], k))
                    def repair(T0, T1, al):
                        r = [T0[2 * k] + T0[2 * k + 1] - T1[k] for k in range(m)]
                        P0 = [T0[j] - al * r[j // 2] / (2 * al + 1) for j in range(2 * m)]
                        P1 = [T1[k] + r[k] / (2 * al + 1) for k in range(m)]
                        return P0, P1, r
                    for ai, al in enumerate(ALPHAS):
                        rr = out["rep"][ai]
                        if m > 1:
                            z1 = (z0 + 1) % m; mv = min(F(1, 100), t1[z0]); t1s = list(t1); t1s[z0] -= mv; t1s[z1] += mv
                            P0, P1, r = repair(t0, t1s, al)
                            before = sum(p * q for p, q in zip(t2, t1s)) - truth; after = sum(p * q for p, q in zip(t2, P1)) - truth
                            rr[0] += 1; rr[1] += all(P0[2 * k] + P0[2 * k + 1] == P1[k] for k in range(m))
                            rr[2] += after == before * 2 * al / (2 * al + 1); rr[3] += after == 0
                            if al == 1:
                                out["spec"][0] += 1; out["spec"][1] += 1
                                d2 = sum((a - b) ** 2 for a, b in zip(t0 + t1s, P0 + P1)); out["spec"][2] += 3 * d2 == sum(q * q for q in r)
                                if rnd.random() < 0.02: out["samples"].append(("repair", [float(v) for v in t0 + t1s], m, [float(v) for v in P0 + P1]))
                        idx = 2 * z0 + xv; dl = F(1, 100) if t0[idx] + F(1, 100) <= 1 else -F(1, 100)
                        t0s = list(t0); t0s[idx] += dl
                        P0, P1, r = repair(t0s, t1, al)
                        before = ans - truth; after = sum(p * q for p, q in zip(t2, P1)) - truth
                        rr[4] += 1; rr[5] += before == 0; rr[6] += after != 0; rr[7] += after == t2[z0] * dl / (2 * al + 1); rr[8] += sum(P1) != 1
                        if al == 1:
                            out["spec"][0] += 1; out["spec"][1] += 1
                            d2 = sum((a - b) ** 2 for a, b in zip(t0s + t1, P0 + P1)); out["spec"][2] += 3 * d2 == sum(q * q for q in r)
                    # precision
                    for hi, (_, h) in enumerate(HS):
                        lo, up = enclosure(t1, t2, h); pp = out["pre"][hi]
                        pp[0] += 1; pp[1] += lo <= truth <= up
                        wd = up - lo; out["wsum"][hi].append(wd); out["wmax"][hi] = wd if out["wmax"][hi] is None else max(out["wmax"][hi], wd)
                        anyn = False; allout = True
                        for a in inval:
                            ins = lo <= a <= up; pp[2] += 1; pp[3] += ins
                            if a != truth:
                                anyn = True; pp[4] += 1; pp[5] += ins
                                if ins: allout = False
                        if anyn: pp[6] += 1; pp[7] += allout
                        if rnd.random() < 0.01:
                            l1 = [max(F(0), v - h) for v in t1]; u1 = [min(F(1), v + h) for v in t1]
                            l2 = [max(F(0), v - h) for v in t2]; u2 = [min(F(1), v + h) for v in t2]
                            out["samples"].append(("vertex", lo == vertex_extremum(l2, l1, u1, False) and up == vertex_extremum(u2, l1, u1, True)))
                    for a in inval:
                        if a == truth: continue
                        d = 9
                        for dd in range(1, 9):
                            lo, up = enclosure(t1, t2, F(1, 2 * 10 ** dd))
                            if a < lo or a > up: d = dd; break
                        out["digits"][d] += 1
    tight = {k: 0 for k in C}; gi = {k: 0 for k in C}; gu = {k: 0 for k in C}
    names = {0: "deletion", 1: "rule1", 2: "rule2", 3: "rule3"}
    for key, l in L.items():
        k = names[key[0]]; gi[k] += 1; gu[k] += not l; tight[k] += (not l) and eqm[key] == len(models)
    for k in C: C[k][10] += gi[k]; C[k][11] += gu[k]; C[k][12] += tight[k]
    out["C"] = C; out["size"] = size
    return out

def main():
    cs = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1].split() for l in open(sys.argv[1])}
    checks = []
    def check(name, ok, detail=""):
        checks.append(dict(name=name, passed=bool(ok), detail=str(detail)[:300])); print(("PASS " if ok else "FAIL ") + name, str(detail)[:150], flush=True)
    def eq(name, vals, tol=1e-12):
        got = cs[name]
        ok = len(got) == len(vals) and all((abs(float(g) - v) <= tol * max(1, abs(v))) if isinstance(v, float) else int(g) == v for g, v in zip(got, vals))
        check(name, ok, (got, vals))
    for tag, grid, seed in (("tenths", 10, 20261031001), ("hundredths", 100, 20261031002)):
        rng = Rng(seed); jobs = []
        for dm in range(1 << len(PAIRS)):
            edges = [PAIRS[k] for k in range(len(PAIRS)) if dm >> k & 1]
            parents = [sorted(a for a, b in edges if b == i) for i in range(n)]
            jobs.append((dm, [[[rng.int(1, grid - 1) for _ in range(1 << len(parents[i]))] for i in range(n)] for _ in range(3)], grid))
        with Pool() as pool: res = pool.map(work, jobs, chunksize=8)
        agg = lambda f: [sum(x) for x in zip(*map(f, res))]
        for k in ("deletion", "rule1", "rule2", "rule3"):
            eq(f"{tag}_census_{k}", agg(lambda r: r["C"][k])); eq(f"{tag}_census_{k}_bysize", agg(lambda r: r["size"][k]))
            c = agg(lambda r: r["C"][k]); check(f"{tag}_{k}_soundness", c[1] == c[2] and c[3] == c[4], c[:5])
        Q = sum(r["queries"] for r in res); s = lambda f: sum(f(r) for r in res)
        eq(f"{tag}_opcert", [Q, s(lambda r: r["honest"]), s(lambda r: r["invalid"]), 0, s(lambda r: r["drops"]), s(lambda r: r["dropv"]), s(lambda r: r["dropl"]), s(lambda r: r["dropl"])])
        for ai in range(len(ALPHAS)): eq(f"{tag}_repair_alpha{ai}", agg(lambda r: r["rep"][ai]))
        eq(f"{tag}_repair_spectral", agg(lambda r: r["spec"]))
        for hi, (lab, _) in enumerate(HS):
            ws = [w for r in res for w in r["wsum"][hi]]
            eq(f"{tag}_precision_{lab}", agg(lambda r: r["pre"][hi]) + [float(sum(ws) / len(ws)), float(max(ws))], tol=1e-9)
        eq(f"{tag}_digits_needed", agg(lambda r: r["digits"])[1:])
        samp = [x for r in res for x in r["samples"]]
        vtx = [x[1] for x in samp if x[0] == "vertex"]; check(f"{tag}_enclosure_vertex_enumeration", vtx and all(vtx), len(vtx))
        worst = 0.0; cnt = 0
        for kind, v, m, p in (x for x in samp if x[0] == "repair"):
            B = np.zeros((m, 3 * m))
            for k in range(m): B[k, 2 * k] = B[k, 2 * k + 1] = 1; B[k, 2 * m + k] = -1
            v = np.array(v); proj = v - B.T @ np.linalg.lstsq(B @ B.T, B @ v, rcond=None)[0]
            worst = max(worst, float(np.max(np.abs(proj - np.array(p))))); cnt += 1
        check(f"{tag}_repair_float_lstsq", cnt > 0 and worst < 1e-12, (cnt, worst))
    missing = [k for k in cs if not any(c["name"] == k for c in checks)]
    for k in missing: check(k, False, "not validated")
    json.dump(dict(checks=checks, all_passed=all(c["passed"] for c in checks), lines=len(cs)), open(sys.argv[2], "w"), indent=1)
    print("ALL", all(c["passed"] for c in checks), "lines", len(cs), "checks", len(checks))

if __name__ == "__main__":
    main()
