// Version 3 operation census. Same graph family, seeds and models as the inherited adjustment census.
// (A) value coincidence versus graphical licence for condition deletion and the three do-calculus rules;
// (B) operation-bound certificates on the inherited derivations; (C) exact weighted sheaf repair of
// local-table slips; (D) interval precision needed for a value check on decoded tables.
// Public values are immutable records; counters are local scratch storage of the enumeration.
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;

namespace Tcr;

/// <summary>All marginal masses of a law on five binary events, indexed by (mask, values on mask).</summary>
public sealed record Marginals(ImmutableArray<Q> M)
{
    public const int N = 5;
    public static Marginals Of(ImmutableArray<Q> law)
    {
        var acc = Enumerable.Repeat(Q.Zero, 1 << 2 * N).ToArray();
        for (int v = 0; v < 1 << N; v++)
            for (int mask = 0; mask < 1 << N; mask++) acc[mask << N | (v & mask)] += law[v];
        return new(acc.ToImmutableArray());
    }
    public Q Mass(int mask, int vals) => M[mask << N | (vals & mask)];
    /// <summary>P(Y = 1 | mask = vals); y must lie outside mask.</summary>
    public Q Cond(int y, int mask, int vals) => Mass(mask | 1 << y, vals | 1 << y) / Mass(mask, vals);
}

/// <summary>Counts for one rule kind. Cells are individual (action value, conditioning value) equalities.</summary>
public sealed record RuleTally(string Kind, long Instances, long Licensed, long LicensedAllEqual, long LicensedCells, long LicensedCellsEqual,
    long Unlicensed, long UnlicensedAllEqual, long UnlicensedCells, long UnlicensedCellsEqual, long UnlicensedCellsRound2,
    long GraphInstances, long GraphUnlicensed, long UnlicensedEqualInAllModels, ImmutableArray<long> BySize);

/// <summary>Interval enclosure of an adjustment sum when the decoded tables are known to within ±h.</summary>
public static class Enclosure
{
    /// <summary>Extremum of Σ c_k t_k over {lo ≤ t ≤ hi, Σ t = 1} by the exact greedy fill (feasible boxes only).</summary>
    public static Q Extremum(IReadOnlyList<Q> c, IReadOnlyList<Q> lo, IReadOnlyList<Q> hi, bool maximise)
    {
        Q rem = Q.One - lo.Aggregate(Q.Zero, (a, b) => a + b), s = Q.Zero;
        var order = Enumerable.Range(0, c.Count).OrderBy(k => maximise ? -c[k] : c[k]).ThenBy(k => k);
        var t = lo.ToArray();
        foreach (int k in order) { Q add = Q.Min(rem, hi[k] - lo[k]); t[k] += add; rem -= add; }
        if (!rem.IsZero) throw new InvalidOperationException("infeasible box");
        for (int k = 0; k < c.Count; k++) s += c[k] * t[k];
        return s;
    }
    public static (Q Lo, Q Hi) Of(IReadOnlyList<Q> t1, IReadOnlyList<Q> t2, Q h)
    {
        var l1 = t1.Select(v => Q.Max(Q.Zero, v - h)).ToArray(); var u1 = t1.Select(v => Q.Min(Q.One, v + h)).ToArray();
        var l2 = t2.Select(v => Q.Max(Q.Zero, v - h)).ToArray(); var u2 = t2.Select(v => Q.Min(Q.One, v + h)).ToArray();
        return (Extremum(l2, l1, u1, false), Extremum(u2, l1, u1, true));
    }
}

/// <summary>Weighted orthogonal repair onto the compatible sections of the table audit (M T0 = T1).</summary>
public static class Repair
{
    public static QMat Coboundary(int m) => QMat.Of(m, 3 * m, (k, j) =>
        j == 2 * k || j == 2 * k + 1 ? Q.One : j == 2 * m + k ? -Q.One : Q.Zero);
    public static QMat T(QMat a) => QMat.Of(a.Cols, a.Rows, (i, j) => a[j, i]);
    /// <summary>v' = v − G⁻¹Bᵀ(BG⁻¹Bᵀ)⁻¹Bv with G = diag(1 on T0, α on T1): the G-nearest compatible section.</summary>
    public static ImmutableArray<Q> Project(ImmutableArray<Q> v, int m, Q alpha)
    {
        var b = Coboundary(m); int c = 3 * m;
        var ginv = Enumerable.Range(0, c).Select(j => j < 2 * m ? Q.One : Q.One / alpha).ToArray();
        // Gram matrix B G⁻¹ Bᵀ, the residual Bv, the multiplier λ = (B G⁻¹ Bᵀ)⁻¹ Bv, and the correction G⁻¹ Bᵀ λ
        var gram = QMat.Of(m, m, (i, k) => Enumerable.Range(0, c).Where(j => !b[i, j].IsZero && !b[k, j].IsZero)
            .Aggregate(Q.Zero, (s, j) => s + b[i, j] * ginv[j] * b[k, j]));
        var res = QMat.Of(m, 1, (i, _) => Enumerable.Range(0, c).Where(j => !b[i, j].IsZero).Aggregate(Q.Zero, (s, j) => s + b[i, j] * v[j]));
        var lam = gram.Inverse().Mul(res);
        return Enumerable.Range(0, c).Select(j => v[j] - ginv[j] *
            Enumerable.Range(0, m).Where(i => !b[i, j].IsZero).Aggregate(Q.Zero, (s, i) => s + b[i, j] * lam[i, 0])).ToImmutableArray();
    }
    public static Q Norm2(IEnumerable<Q> v) => v.Aggregate(Q.Zero, (a, x) => a + x * x);
    public static ImmutableArray<Q> Residual(ImmutableArray<Q> v, int m) =>
        Enumerable.Range(0, m).Select(k => v[2 * k] + v[2 * k + 1] - v[2 * m + k]).ToImmutableArray();
}

public static class OpCensus
{
    static int Embed(int zmask, int k) { int v = 0, j = 0; foreach (int i in SetBits.Of(zmask)) { v |= (k >> j & 1) << i; j++; } return v; }
    static IEnumerable<int> Subsets(int mask) { for (int s = mask; ; s = (s - 1) & mask) { yield return s; if (s == 0) yield break; } }

    sealed class Acc
    {
        public long Inst, Lic, LicAll, LicCells, LicCellsEq, Unl, UnlAll, UnlCells, UnlCellsEq, UnlCellsR2, GInst, GUnl, GTight;
        public long[] Size = new long[8];   // unlicensed and unlicensed-all-equal counts by conditioning size 0..3
        public RuleTally Freeze(string k) => new(k, Inst, Lic, LicAll, LicCells, LicCellsEq, Unl, UnlAll, UnlCells, UnlCellsEq, UnlCellsR2, GInst, GUnl, GTight, Size.ToImmutableArray());
    }

    public static void Run(string dir, Action<string, object[]> emit)
    {
        const int n = 5;
        var pairs = (from i in Enumerable.Range(0, n) from j in Enumerable.Range(i + 1, n - i - 1) select new Edge(i, j)).ToArray();
        Q hundredth = Q.Of(1, 100);
        var alphas = new[] { Q.Of(1, 10), Q.One, Q.Of(10) };
        var hs = new (string Label, Q H)[] { ("d2_threshold", Q.Of(1, 100)), ("dec2", Q.Of(1, 200)), ("dec3", Q.Of(1, 2000)), ("dec4", Q.Of(1, 20000)) };
        foreach (var (tag, grid, seed) in new[] { ("tenths", 10, 20261031001UL), ("hundredths", 100, 20261031002UL) })
        {
            var rng = new Rng(seed);
            var kinds = new[] { "deletion", "rule1", "rule2", "rule3" };
            var acc = kinds.ToDictionary(k => k, _ => new Acc());
            long queries = 0, drops = 0, dropValue = 0, dropLicensed = 0, dropOp = 0, honestOp = 0, invalidOp = 0, invalidSets = 0;
            // repair: per alpha [t1 cases, residual zero, ratio exact, answer exact after, t0 cases, before exact, after wrong, ratio exact, sum broken]
            var rep = alphas.Select(_ => new long[9]).ToArray();
            long specCases = 0, specGram = 0, specEqual = 0;
            // precision per h: [queries, tau inside, invalid, invalid inside, noncoinc, noncoinc inside, queries with noncoinc, queries all excluded]
            var pre = hs.Select(_ => new long[8]).ToArray(); var widthSum = new double[hs.Length]; var widthMax = new Q[hs.Length];
            var digits = new long[10];

            for (int dm = 0; dm < 1 << pairs.Length; dm++)
            {
                var g = Admg.Make(n, pairs.Where((_, k) => (dm >> k & 1) != 0), Array.Empty<Edge>());
                // graph-level licences, keyed per rule instance, with a count of models in which all cells were equal
                var lic = new Dictionary<(int, int, int, int, int), bool>(); var eqModels = new Dictionary<(int, int, int, int, int), int>();
                for (int r = 0; r < 3; r++)
                {
                    CptModel model; (model, rng) = CptModel.Random(g, rng, grid);
                    var obs = model.Law(); var mo = Marginals.Of(obs);
                    var md = new Marginals[n, 2];
                    for (int x = 0; x < n; x++) for (int xv = 0; xv <= 1; xv++) md[x, xv] = Marginals.Of(model.Law(x, xv));

                    void Tally(string kind, (int, int, int, int, int) key, int condSize, Func<bool> licence, IEnumerable<(Q A, Q B)> cells)
                    {
                        var a = acc[kind];
                        if (!lic.TryGetValue(key, out bool l)) { l = licence(); lic[key] = l; eqModels[key] = 0; a.GInst++; if (!l) a.GUnl++; }
                        bool all = true; long c = 0, ce = 0, cr = 0;
                        foreach (var (p, q) in cells)
                        {
                            c++; bool e = p == q; if (e) ce++; else all = false;
                            if (Rounding.Round(p, 2) == Rounding.Round(q, 2)) cr++;
                        }
                        a.Inst++;
                        if (l) { a.Lic++; a.LicCells += c; a.LicCellsEq += ce; if (all) a.LicAll++; }
                        else { a.Unl++; a.UnlCells += c; a.UnlCellsEq += ce; a.UnlCellsR2 += cr; a.Size[2 * condSize]++; if (all) { a.UnlAll++; a.Size[2 * condSize + 1]++; } }
                        if (all) eqModels[key]++;
                    }

                    for (int y = 0; y < n; y++)
                        for (int w = 0; w < n; w++)
                        {
                            if (w == y) continue;
                            int rest = g.V & ~(1 << y | 1 << w);
                            // deletion of W from P(Y | W, S): licence Y ⊥ W | S
                            foreach (int s in Subsets(rest))
                            {
                                int yy = y, ww = w, ss = s;
                                Tally("deletion", (0, y, w, s, 0), SetBits.Count(s), () => g.Separated(1 << yy, 1 << ww, ss),
                                    Enumerable.Range(0, 1 << SetBits.Count(s)).Select(k => (mo.Cond(yy, ss | 1 << ww, Embed(ss, k)), mo.Cond(yy, ss | 1 << ww, Embed(ss, k) | 1 << ww))));
                            }
                            int x = w;   // the same ordered pair read as (outcome y, action x)
                            foreach (int s in Subsets(rest))
                            {
                                int xx = x, yy = y, ss = s, m = 1 << SetBits.Count(s);
                                Tally("rule2", (2, y, x, s, 0), SetBits.Count(s), () => g.Rule(2, 1 << yy, 0, 1 << xx, ss),
                                    from xv in new[] { 0, 1 } from k in Enumerable.Range(0, m)
                                    select (md[xx, xv].Cond(yy, ss, Embed(ss, k)), mo.Cond(yy, ss | 1 << xx, Embed(ss, k) | xv << xx)));
                                Tally("rule3", (3, y, x, s, 0), SetBits.Count(s), () => g.Rule(3, 1 << yy, 0, 1 << xx, ss),
                                    from xv in new[] { 0, 1 } from k in Enumerable.Range(0, m)
                                    select (md[xx, xv].Cond(yy, ss, Embed(ss, k)), mo.Cond(yy, ss, Embed(ss, k))));
                                // rule 1: delete observation z from P(Y | do(x), z, s)
                                foreach (int z in SetBits.Of(rest))
                                {
                                    if ((s >> z & 1) != 0) continue;
                                    int zz = z;
                                    Tally("rule1", (1, y, x, s, z), SetBits.Count(s), () => g.Rule(1, 1 << yy, 1 << xx, 1 << zz, ss),
                                        from xv in new[] { 0, 1 } from zv in new[] { 0, 1 } from k in Enumerable.Range(0, m)
                                        select (md[xx, xv].Cond(yy, ss | 1 << zz, Embed(ss, k) | zv << zz), md[xx, xv].Cond(yy, ss, Embed(ss, k))));
                                }
                            }
                        }

                    // inherited single-action adjustment queries
                    for (int x = 0; x < n; x++) for (int y = x + 1; y < n; y++)
                    {
                        if ((g.Ancestors(1 << y) >> x & 1) == 0) continue;
                        int others = g.V & ~(1 << x | 1 << y);
                        for (int xv = 0; xv <= 1; xv++)
                        {
                            queries++;
                            Q truth = CptModel.Mass(model.Law(x, xv), 1 << y, 1 << y);
                            var valid = new List<int>(); var invalidAnswers = new List<Q>();
                            var answers = new Dictionary<int, Derivation>();
                            foreach (int z in Subsets(others))
                            {
                                var d = Derivation.Honest(obs, x, xv, y, z); answers[z] = d;
                                if (Adjustment.Valid(g, x, y, z)) valid.Add(z);
                                else { invalidSets++; invalidAnswers.Add(d.Answer); if (d.Certified(g, obs, x, xv, y)) invalidOp++; }
                            }
                            int zs = valid.OrderBy(z => SetBits.Count(z)).ThenBy(z => z).First();
                            var hd = answers[zs]; int m = hd.T1.Length;
                            if (hd.Certified(g, obs, x, xv, y) && Adjustment.Valid(g, x, y, zs)) honestOp++;

                            // (B) dropped action condition: value certificate versus operation-bound certificate
                            var t2d = Enumerable.Range(0, m).Select(k => mo.Cond(y, zs, Embed(zs, k))).ToImmutableArray();
                            var dd = hd with { T2 = t2d, Answer = Enumerable.Range(0, m).Aggregate(Q.Zero, (s, k) => s + t2d[k] * hd.T1[k]) };
                            drops++; bool valueOk = dd.Certified(g, obs, x, xv, y); if (valueOk) dropValue++;
                            bool licensed = g.Separated(1 << y, 1 << x, zs); if (licensed) dropLicensed++;
                            if (licensed && t2d.SequenceEqual(Enumerable.Range(0, m).Select(k => mo.Cond(y, zs, Embed(zs, k))))) dropOp++;

                            // (C) repair of a slip in T1 (as inherited) and of a slip in T0
                            var v0 = hd.T0.AddRange(hd.T1);
                            for (int ai = 0; ai < alphas.Length; ai++)
                            {
                                Q al = alphas[ai], keep = 2 * al / (2 * al + 1), pass = Q.One / (2 * al + 1); var rr = rep[ai];
                                int z0 = Enumerable.Range(0, m).OrderByDescending(k => hd.T1[k]).ThenBy(k => k).First();
                                if (m > 1)
                                {
                                    int z1 = (z0 + 1) % m; Q mv = Q.Min(hundredth, hd.T1[z0]);
                                    var t1s = hd.T1.SetItem(z0, hd.T1[z0] - mv).SetItem(z1, hd.T1[z1] + mv);
                                    var v = hd.T0.AddRange(t1s); var p = Repair.Project(v, m, al);
                                    Q before = Enumerable.Range(0, m).Aggregate(Q.Zero, (s, k) => s + hd.T2[k] * t1s[k]) - truth;
                                    Q after = Enumerable.Range(0, m).Aggregate(Q.Zero, (s, k) => s + hd.T2[k] * p[2 * m + k]) - truth;
                                    rr[0]++; if (Repair.Residual(p, m).All(q => q.IsZero)) rr[1]++;
                                    if (after == before * keep) rr[2]++; if (after.IsZero) rr[3]++;
                                    if (al == Q.One)
                                    {
                                        specCases++; var b = Repair.Coboundary(m);
                                        if (b.Mul(Repair.T(b)).A.SequenceEqual(QMat.Identity(m).Scale(Q.Of(3)).A)) specGram++;
                                        if (Repair.Norm2(v.Zip(p, (a1, b1) => a1 - b1)) * 3 == Repair.Norm2(Repair.Residual(v, m))) specEqual++;
                                    }
                                }
                                {
                                    int idx = 2 * z0 + xv; Q dl = hd.T0[idx] + hundredth <= Q.One ? hundredth : -hundredth;
                                    var v = v0.SetItem(idx, hd.T0[idx] + dl); var p = Repair.Project(v, m, al);
                                    Q before = hd.Answer - truth;
                                    Q after = Enumerable.Range(0, m).Aggregate(Q.Zero, (s, k) => s + hd.T2[k] * p[2 * m + k]) - truth;
                                    rr[4]++; if (before.IsZero) rr[5]++; if (!after.IsZero) rr[6]++;
                                    if (after == hd.T2[z0] * dl * pass) rr[7]++;
                                    if (Enumerable.Range(0, m).Aggregate(Q.Zero, (s, k) => s + p[2 * m + k]) != Q.One) rr[8]++;
                                    if (al == Q.One)
                                    {
                                        specCases++; specGram++;
                                        if (Repair.Norm2(v.Zip(p, (a1, b1) => a1 - b1)) * 3 == Repair.Norm2(Repair.Residual(v, m))) specEqual++;
                                    }
                                }
                            }

                            // (D) precision of a value check made on tables known to within ±h
                            for (int hi = 0; hi < hs.Length; hi++)
                            {
                                var (lo, up) = Enclosure.Of(hd.T1, hd.T2, hs[hi].H); var pp = pre[hi];
                                pp[0]++; if (lo <= truth && truth <= up) pp[1]++;
                                Q wdt = up - lo; widthSum[hi] += wdt.ToDouble(); if (pp[0] == 1 || wdt > widthMax[hi]) widthMax[hi] = wdt;
                                bool anyNc = false, allOut = true;
                                foreach (var a in invalidAnswers)
                                {
                                    bool inside = lo <= a && a <= up; pp[2]++; if (inside) pp[3]++;
                                    if (a != truth) { anyNc = true; pp[4]++; if (inside) { pp[5]++; allOut = false; } }
                                }
                                if (anyNc) { pp[6]++; if (allOut) pp[7]++; }
                            }
                            foreach (var a in invalidAnswers.Where(a => a != truth))
                            {
                                int dneed = 9;
                                for (int d = 1; d <= 8; d++)
                                {
                                    var (lo, up) = Enclosure.Of(hd.T1, hd.T2, Q.Of(1, 2 * (long)Math.Pow(10, d)));
                                    if (a < lo || a > up) { dneed = d; break; }
                                }
                                digits[dneed]++;
                            }
                        }
                    }
                }
                foreach (var (key, l) in lic) if (!l && eqModels[key] == 3) acc[KindOf(key.Item1)].GTight++;
            }
            foreach (var k in kinds)
            {
                var t = acc[k].Freeze(k);
                emit($"{tag}_census_{k}", new object[] { t.Instances, t.Licensed, t.LicensedAllEqual, t.LicensedCells, t.LicensedCellsEqual,
                    t.Unlicensed, t.UnlicensedAllEqual, t.UnlicensedCells, t.UnlicensedCellsEqual, t.UnlicensedCellsRound2, t.GraphInstances, t.GraphUnlicensed, t.UnlicensedEqualInAllModels });
                emit($"{tag}_census_{k}_bysize", new object[] { t.BySize });
            }
            emit($"{tag}_opcert", new object[] { queries, honestOp, invalidSets, invalidOp, drops, dropValue, dropLicensed, dropOp });
            for (int ai = 0; ai < alphas.Length; ai++) emit($"{tag}_repair_alpha{ai}", new object[] { rep[ai] });
            emit($"{tag}_repair_spectral", new object[] { specCases, specGram, specEqual });
            for (int hi = 0; hi < hs.Length; hi++)
                emit($"{tag}_precision_{hs[hi].Label}", new object[] { pre[hi], widthSum[hi] / pre[hi][0], widthMax[hi].ToDouble() });
            emit($"{tag}_digits_needed", new object[] { digits.Skip(1).ToArray() });
        }
    }
    static string KindOf(int code) => code switch { 0 => "deletion", 1 => "rule1", 2 => "rule2", _ => "rule3" };
}
