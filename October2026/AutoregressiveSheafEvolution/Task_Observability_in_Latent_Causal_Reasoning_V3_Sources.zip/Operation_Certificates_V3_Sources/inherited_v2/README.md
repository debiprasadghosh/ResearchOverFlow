# Operation Certificates for Latent Causal Reasoning

Version 2 · 31 October 2026 · Debi Prasad Ghosh

The current paper extends the supplied *From Teacher Traces to Verified
Transitions*. It distinguishes a value certificate, a licensed operation and a
realized latent computation. It adds finite execution and memory theorems,
horizontal repair bounds, sampling and error-spending contracts, bounded
neuroscience interpretations and an AI harness proposal. The seven author-supplied
related publications are cited with the supplied DOI strings.

## Current files

- `deliverables/Operation_Certificates_for_Latent_Causal_Reasoning_V2.docx`: current paper.
- `paper.md`: complete manuscript, including APA references and appendix.
- `paper_current_v2.md`: reading copy extracted from the exact final Word file.
- `prepare_manuscript.py`: corrections to the inherited manuscript and filling of new result values.
- `extension_v2.md`, `extension_v2_filled.md`, `references_v2.md`: extension and its references.
- `build_v2.py`, `base_v1.docx`: self-contained Word builder and supplied series reference.
- `transition_reference.py`: immutable context and operation packets; exact small probabilities.
- `validate_v2.py`: independent analytic/rational verification, API cross-check and replay.
- `out_v2/transition_results.json`, `py_v2.txt`, `validation_v2.json`: current results and checks.
- `validation_v1_rerun.json`, `validation_v1_rerun.log`: independent inherited validator rerun.
- `fig/`: inherited and new scientific figures; no generated artwork.
- `document_audit_v2.json`, `render_review_v2.json`: structural and final rendering review.
- `runtime_v2.json`, `requirements_v2.txt`: exact current environment versions.
- `PROJECT_NOTE_V2.md`: scope and interpretation changes.

## Reproduce the calculations

Use Python 3.12 and install `requirements_v2.txt`. Run from this directory:

```bash
python validate.py cs_out.txt out validation_v1_rerun.json
python transition_reference.py out_v2 > py_v2.txt
python validate_v2.py
```

The first command independently recomputes the supplied census in Python and
reproduces all 34 C# summary records, passing 36 checks. It is a Python rerun of
the arithmetic, not a new execution of the C# kernel. The source uses exact
Fractions, direct path-based graph tests and replayed parameter streams. The
recorded source C# output and original result CSVs remain unchanged.

The new reference emits 16 deterministic records; its validator passes 26 checks.
Five SciPy LP results are independently checked by a separate exact rational
active-constraint enumerator. The new graph primitive is cross-checked against
independent path enumeration on 1,586 cases. The current summary and result JSON
reproduce byte for byte in a fresh Python process. These are finite mathematical
checks; they are not measurements of a teacher, trained student or biological
system. The spectral eigenvalue is a floating-point cross-check of an exact
three-cycle calculation and is not an outward-certified eigenvalue enclosure.

## Build and review the Word paper

Pandoc 3.1.3 is additionally required. Run:

```bash
python build_v2.py
```

The builder runs manuscript preparation and figure generation, converts the
manuscript with Pandoc and the included `base_v1.docx`, and post-processes the Word
styles, tables, captions and native editable OMML equations. It checks ZIP
integrity, XML well-formedness, statement uniqueness and expected figure/table
counts. It does not claim complete OOXML schema validation. Rendering and visual
review are required after every rebuild because fonts and Office versions affect
pagination and equation display.

The final reading copy was extracted with Pandoc from the delivered Word file;
its images are in `current_media_v2`. It is a convenience copy. `paper.md` and the
builder are the authoring sources.

## Inherited files

`kernel/`, `cs_out.txt`, `out/`, `validate.py`, `validation.json` and the original
figure remain available. `paper_v1.md`, `build_paper_v1.py`,
`fig_distill_v1.py` and `fig/checks_and_errors_v1.png` preserve earlier source
material. The old builder refers to a series reference outside its original ZIP;
the current builder removes that external manuscript dependency. The current
Figure 1 is redrawn from the same original results with its final check labelled
"graph and value check" to reflect the clarified interpretation.

## Mathematical and implementation limits

The operation interface assumes an authoritative positive binary DAG model. It
supports conditional-table construction for a valid adjustment and a condition
deletion licensed by d-separation. It is not a general natural-language parser,
authentication layer, production data validator or complete ADC implementation.
The semantic input contract must be established independently.

An invalid premise is a rejected operation license, not necessarily a false
number on the current law. An unsupported primitive returns unverified. The
new examples distinguish those outcomes. A valid reconstructed derivation also
does not establish which internal computation the teacher used.

The continuation theorem is finite and exact. The spectral theorem is a
compatibility bound on fixed linear maps and declared units. The recovery LP
assumes a compact polytope and a coordinatewise bounded-report channel. Sampling
correction needs known proposal and inspection laws. The conditional error
budget is a premise to establish for each approximate verifier.

D1–D4 and H1–H3 remain untested. No new C# execution, teacher query, student
training, agent benchmark, animal study or human experiment is claimed.
