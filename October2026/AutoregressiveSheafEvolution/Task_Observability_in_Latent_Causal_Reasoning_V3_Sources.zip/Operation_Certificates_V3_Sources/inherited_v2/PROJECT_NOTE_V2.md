# Mathematical revision notes

The current title is *Operation Certificates for Latent Causal Reasoning*.

The main distinction is between extensional numerical equality, a licensed
semantic transformation and an implemented latent execution. The original
condition-deletion rows already contain evidence for this distinction: 186
finer-grid submissions and 2,268 coarser-grid submissions satisfy the old table
checker despite changing the claimed operation. The old checker is now called
a graph-and-value certificate. Its answer-soundness result is retained; operator
provenance was not one of its fields.

The added reference distinguishes coincident unlicensed deletion from a
d-separation-licensed deletion, and binds context and operand references to the
submitted operator. Binding a proposed derivation does not identify the
teacher's internal computation.

The revised rounded-coincidence proposition assumes a positive witness to a
nonzero answer difference, and constructs an open rounded-agreement region by
making the whole observational law a product law. Nonempty sets do not in
general have positive measure. The finite graph census is correctly described
as all DAGs respecting one fixed order. The full valid-set histogram includes
three, five, six and seven valid alternatives, which the older prose omitted.

The linear checkpoint prediction is retained as a readout prediction. Failure of
a linear probe alone does not establish a shortcut or absence of reasoning.
The new bypass example and the commuting-square theorem specify a separate
execution test. Incompleteness is an unresolved result unless an actual
refutation is supplied.

The added formal statements specialize established principles of typed
composition, finite-state minimization, spectral sheaf theory, importance
weighting and optimal recovery. No priority is claimed for those principles.
The exact linear-memory and bounded-noise recovery results are attributed to
the companion ADC paper. The manuscript links the other six related papers to
their appropriate sampling, cache, dependency, preference and schedule roles.

The independent original validator was rerun and passed. The current finite
examples also pass independent arithmetic, graph and replay checks. The original
C# kernel was not recompiled or executed. No neural or biological performance
study was run. Neuroscience and learned-agent benefits remain hypotheses.
