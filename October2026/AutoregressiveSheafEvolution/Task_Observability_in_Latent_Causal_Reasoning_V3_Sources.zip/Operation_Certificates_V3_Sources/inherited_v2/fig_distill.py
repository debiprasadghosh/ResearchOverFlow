"""Figure 1 of the paper, drawn from the validated C# output."""
from pathlib import Path
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
H = Path(__file__).resolve().parent
cs = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1].split() for l in open(H / "cs_out.txt")}
B, O, A, INK, MUT = "#2a78d6", "#eb6834", "#1baf7a", "#222222", "#6b6b6b"
plt.rcParams.update({"font.size": 8.5, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": MUT,
                     "xtick.color": MUT, "ytick.color": MUT})
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 3.1), gridspec_kw=dict(width_ratios=[1.15, 1]))
rows = [("honest", "honest derivation"), ("invalid_set", "invalid adjustment set"), ("slip_outcome_table", "slip in P(y | x, z)"),
        ("slip_marginal_table", "slip in P(z)"), ("drop_action_condition", "drop x from conditioning"), ("slip_final_sum", "slip in final sum")]
cols = ["exact\nanswer", "answer to\n2 decimals", "overlap\nresidual", "graph and\nvalue check"]
M = np.array([[int(v) / int(cs[f"hundredths_checker_{k}"][0]) for v in cs[f"hundredths_checker_{k}"][1:]] for k, _ in rows])
a1.imshow(M, cmap="Blues", vmin=0, vmax=1.25, aspect="auto")
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        a1.text(j, i, f"{100 * M[i, j]:.0f}%" if M[i, j] >= 0.005 or M[i, j] == 0 else "<1%", ha="center", va="center", fontsize=7.5,
                color="white" if M[i, j] > 0.75 else INK)
a1.set_xticks(range(4)); a1.set_xticklabels(cols, fontsize=7.2); a1.set_yticks(range(len(rows))); a1.set_yticklabels([r[1] for r in rows], fontsize=7.4)
a1.tick_params(length=0); [s.set_visible(False) for s in a1.spines.values()]
a1.set_title("(a) share of derivations each check accepts", fontsize=8.5, color=INK)
for tag, col, lab in (("tenths", O, "parameters in tenths"), ("hundredths", B, "parameters in hundredths")):
    e = np.sort(np.loadtxt(H / "out" / f"{tag}_invalid_abs_errors.csv", skiprows=1))
    a2.plot(e, np.arange(1, len(e) + 1) / len(e), color=col, lw=1.8, label=lab)
for t, lab in ((0.005, "0.005"), (0.01, "0.01"), (0.05, "0.05")):
    a2.axvline(t, color=MUT, lw=.7, ls=":"); a2.text(t, 0.02, lab, rotation=90, fontsize=6.8, color=MUT, ha="right", va="bottom")
a2.set_xscale("log"); a2.set_xlim(1e-4, 0.5); a2.set_ylim(0, 1)
a2.set_xlabel("Absolute answer error"); a2.set_ylabel("cumulative share")
a2.set_title("(b) how close wrong derivations come", fontsize=8.5, color=INK)
a2.grid(True, color="#ececec", lw=.6); a2.legend(frameon=False, fontsize=7, loc="upper left")
fig.tight_layout(); fig.savefig(H / "fig" / "checks_and_errors.png", dpi=220); plt.close(fig); print("ok")
