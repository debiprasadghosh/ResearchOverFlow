# From Teacher Traces to Verified Transitions: sources

- `kernel/`: .NET 8 project (no third-party packages). `Distill.cs` holds the models, adjustment criteria, typed derivations and checkers; `Exact.cs` and `Graph.cs` are reused from the ADC kernel.
- `validate.py`: independent Python recomputation of every summary line.
- `cs_out.txt`, `validation.json`, `out/`: outputs and validation record.
- `fig_distill.py`, `fig/`: Figure 1. `build_paper.py`, `paper.md`: Word builder (needs Pandoc 3.1.3 and the ADC Word file as reference document).

```bash
dotnet build kernel/Distill.csproj -c Release
dotnet kernel/bin/Release/net8.0/Distill.dll out > cs_out.txt
python validate.py cs_out.txt out validation.json
```
Seeds: 20261031001 (tenths), 20261031002 (hundredths). Verified with .NET SDK 8.0.131, Python 3.13.16, NumPy 2.5.3.
