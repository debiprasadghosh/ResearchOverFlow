from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
H=Path(__file__).resolve().parent
r=json.loads((H/'out_v2/transition_results.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':11,'axes.labelsize':10,
                     'axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white'})
fig,ax=plt.subplots(1,2,figsize=(9.4,3.6),layout='constrained')
s=np.logspace(-2,0,50)
ax[0].plot(s,np.sqrt(6)*s,label='Raw residual',color='#336982')
ax[0].plot(s,np.full_like(s,np.sqrt(2)),label='Distance and repair bound',color='#a95235')
ax[0].set_xscale('log');ax[0].set_xlabel('Audit row scale');ax[0].set_ylabel('Euclidean magnitude')
ax[0].set_title('A  Small residual needs a scale');ax[0].legend(frameon=False,fontsize=8,loc='upper left')
ax[1].bar(['Observed\ntraining states','Altered\ninput states'],[2,0],color=['#336982','#a95235'],width=.55)
ax[1].set_ylim(0,2.4);ax[1].set_yticks([0,1,2]);ax[1].set_ylabel('Correct cases out of two')
ax[1].set_title('B  A decoder can be bypassed')
for i,v in enumerate([2,0]):ax[1].text(i,v+.08,str(v),ha='center')
fig.savefig(H/'fig/v2_execution_and_compatibility.png',dpi=240)
fig.savefig(H/'fig/v2_execution_and_compatibility.svg');plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(9.4,3.5),layout='constrained')
from fractions import Fraction as F
vals=[float(F(r['archive_correction'][k])) for k in ['reference_mean','uncorrected_observed_mean','corrected_mean']]
ax[0].bar(['Reference','Inspected\nuncorrected','Corrected\nexpectation'],vals,color=['#677780','#a95235','#336982'],width=.6)
ax[0].set_ylim(0,2.1);ax[0].set_ylabel('Mean record value');ax[0].set_title('A  Correct both selection stages')
for i,v in enumerate(vals):ax[0].text(i,v+.05,f'{v:.2f}',ha='center',fontsize=9)
ax[1].bar(['None','Report 1','Report 2','Both'],[1,1,1,0],color=['#677780','#336982','#336982','#a95235'],width=.6)
ax[1].set_ylim(0,1.25);ax[1].set_yticks([0,.5,1]);ax[1].set_ylabel('Worst remaining query width')
ax[1].set_title('B  Two reports can be complementary')
fig.savefig(H/'fig/v2_archive_and_evidence.png',dpi=240)
fig.savefig(H/'fig/v2_archive_and_evidence.svg');plt.close(fig)
