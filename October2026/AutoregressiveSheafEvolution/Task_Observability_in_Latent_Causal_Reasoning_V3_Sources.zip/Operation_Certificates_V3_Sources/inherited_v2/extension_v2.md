# 7 Operations and values require different certificates

## 7.1 A typed execution model

An answer can be numerically right for two different reasons. A licensed rule may establish it throughout the declared model class, or a different computation may happen to agree on the current observational law. Both facts can be useful, but they supervise different capabilities. The dropped-condition rows of Table 2 make this distinction observable: the original checker compares the submitted tables with the required tables, without recording the syntax of the operation that produced them. We call that checker a *value certificate* in this revision. Its soundness for the submitted answer is retained. A stronger claim about a reusable operation requires an operation-bound certificate.

**Definition 7.1 (a context-indexed execution).** Fix an authoritative context $\kappa$, containing the event meanings, graph, latent-model class, data, query, units and evaluator versions. A state $s\in S_\kappa$ is a typed collection of available facts and unresolved obligations. An operation $o$ has a declared precondition $P_{\kappa,o}$ and a partial semantic map $T_{\kappa,o}:P_{\kappa,o}\to S_\kappa$. A certificate binds $\kappa$, the actual operand state, $o$, its premises and the claimed result. Its checker accepts only if those premises hold and the result equals the declared map on those operands.

This definition is relative to a trusted mathematical interpreter and a faithful input specification. An expression parser, a graph extracted from prose and an observation protocol each require their own assessment. A digest detects changes to bound contents; it does not establish their truth, provenance or authority. The context includes semantic objects rather than only human-readable labels.

**Proposition 7.2 (numerical equality does not license condition deletion).** A value certificate can accept a table computed by dropping $X$ from $P(Y\mid X,Z)$ even though that deletion is not a valid graph-level rule.

*Proof.* Consider the allowed graph $X\to Y$ and a positive model in which $X$ and $Y$ are independent fair bits. For $Z=\varnothing$, both $P(Y=1\mid X=1)$ and $P(Y=1)$ equal $1/2$. Adjustment by the empty set is valid, and a checker comparing only tables and the resulting answer accepts the dropped table. The graph does not imply $Y\perp X$. In a compatible positive model with $P(Y=1\mid X=0)=1/4$ and $P(Y=1\mid X=1)=3/4$, the required table at $X=1$ is $3/4$, while the dropped table is $1/2$ if $X$ remains fair. Thus universal deletion is invalid. ∎

No faithfulness assumption is made here: an allowed arrow may be inactive in a particular model. Conversely, deletion is legitimately available in $C\to X$, $C\to Y$ after conditioning on $C$, because $Y\perp X\mid C$ follows by d-separation. An operation-aware checker must support this valid route instead of banning every textual deletion. A separately proved equality on one fixed law can also license an explicitly law-specific rewrite; it does not become a graph-universal rule.

**Theorem 7.3 (relative soundness of typed composition).** Suppose the initial state is correct in a fixed context and every accepted operation-bound certificate satisfies Definition 7.1. Then any finite sequence of accepted operations produces the semantic state obtained by composing the corresponding maps. Every claim entailed by that state is correct relative to the same context.

*Proof.* The base state has the asserted meaning by hypothesis. If state $s_j$ is the semantic state and its certificate accepts, its premises hold on the actual $s_j$ and the next state is $T_{\kappa,o_j}(s_j)$. Induction establishes the claim at every finite step. The final entailment is part of the trusted semantic interpreter. ∎

This is an elementary execution theorem, not a new completeness theorem for causal identification. Its purpose is to state exactly what a training label promises. The general causal rules remain attributed to their original authors; an accepted adjustment operation uses the complete criterion only within its specified domain.

## 7.2 Abstention and completeness

**Corollary 7.4 (incompleteness requires an unresolved status).** A sound checker that fails to prove a proposed operation cannot, from that failure alone, label its conclusion false. It may return unverified. A refutation needs a failed claimed premise or a semantic witness against the relevant validity claim.

*Proof.* A sound incomplete checker can fail on a true proposition. Therefore failure cannot imply falsity. A countermodel or an exact contradiction supplies additional evidence and must be checked in the same context. ∎

The back-door comparison in Section 5 measures missed certificates, not necessarily false negative truth judgements. A back-door-only service that honestly returns unverified remains sound. A training pipeline that relabels all those returns as invalid operations introduces label error. This distinction matters when estimating the cost of a more complete checker.

CAPTION: Table 5 Three claims carried by a reasoning record

| Claim | What is established | Additional obligation |
|:--|:--|:--|
| Value agreement | The submitted value equals a required value on the declared data | Bind the query, data and arithmetic |
| Licensed operation | The stated transformation is valid in its declared scope | Bind the operator, operands and premises |
| Realized latent computation | Decoded latent transitions implement the stated transformations | Check execution squares on the relevant reachable states |

These levels are cumulative only when their extra obligations are met. A natural-language account of an operation is a proposal to the interpreter. It is not evidence that the teacher internally executed that operation, even when the resulting formal derivation is valid.

# 8 What latent reasoning must preserve

## 8.1 A commuting execution square

Let $Z_j$ be a latent state space and $D_j:Z_j\to S_j$ a semantic decoder. For one fixed licensed operation at step $j$, let $F_j$ be the latent update and $T_j$ the semantic update. Exact realization requires

$$D_{j+1}\circ F_j=T_j\circ D_j.\qquad\text{(5)}$$

Equation (5) is a commuting square. It concerns reasoning-step transitions, not the denoising layer index. Within each step, a representation can also carry ASE's vertical fibre diagram across layers. Physical event time, generated token order, reasoning steps and ASE depth retain their separate meanings. A stalk is a data space; neither a word token nor its trajectory is itself a stalk. If a layer changes its base through $\Phi_t$, transporting sheaves uses the inverse image $\Phi_t^{-1}$, with compatible structure maps. The finite calculations below use fixed bases and require no changing-base construction.

**Theorem 8.1 (error accumulation for decoded execution).** Suppose the semantic spaces use stated norms, $T_j$ is $L_j$-Lipschitz, and on every latent state reachable under the evaluated policy,

$$\|D_{j+1}F_j(z)-T_jD_j(z)\|\leq\epsilon_j.\qquad\text{(6)}$$

Let $s_{j+1}=T_j(s_j)$, $z_{j+1}=F_j(z_j)$ and $e_0=\|D_0(z_0)-s_0\|$. Then

$$\|D_n(z_n)-s_n\|\leq e_0\prod_{j=0}^{n-1}L_j+\sum_{k=0}^{n-1}\epsilon_k\prod_{j=k+1}^{n-1}L_j.\qquad\text{(7)}$$

*Proof.* Insert and subtract $T_jD_j(z_j)$ and apply the triangle inequality to obtain $e_{j+1}\leq\epsilon_j+L_je_j$. Repeated substitution gives (7), with an empty product equal to one. ∎

For probability states propagated by a fixed Markov kernel, total variation is nonexpansive, so $L_j\leq1$ and the bound is $e_0+\sum_j\epsilon_j$. A normalization by a small probability can instead have a large sensitivity; it must be bounded separately. A norm on concatenated quantities is meaningful only after compatible types and units have been specified. The theorem assumes the same licensed operation on both sides. A wrong graph or a different selected operation is not silently included in $\epsilon_j$.

The reference recurrence takes $T(s)=s/2$, $F(z)=z/2+1/100$ and initial error $1/10$. After {{COMMUTE_STEPS}} steps its error and bound both equal ${{COMMUTE_ERROR}}$. This is an exact calculation demonstrating tightness of the recurrence, not evidence that a neural decoder achieves its uniform premises.

**Proposition 8.2 (decodability alone does not establish use).** Perfect checkpoint decoding and correct training answers need not imply (5) after a relevant state intervention.

*Proof.* Let the semantic task be $T(s)=1-s$ on bits. Let latent states be $z=(s,b)$, let $D(z)=s$, and let $F(s,b)=(b,b)$. On the training states $(0,1)$ and $(1,0)$, the decoder recovers $s$ perfectly and $DF(s,b)=1-s$. Replace $s$ by $1-s$ while retaining $b$. The decoded input changes, but the computation still outputs $b$, so both modified cases violate (5). ∎

The independent check reports {{BYPASS_TRAIN}} training errors and {{BYPASS_ALTER}} altered-state errors among {{BYPASS_CASES}} cases in each condition. Such an intervention tests a computational abstraction. It does not establish that an external physical intervention has occurred. Geiger et al. (2021) provide the relevant causal-abstraction methodology. A failed linear probe alone would establish neither this bypass nor the absence of reasoning.

## 8.2 A sufficient memory for future operations

Reconstructing every word of the teacher trace is unnecessary. Retaining only the present answer can be insufficient. The correct target lies between these extremes and depends on the allowed future computations.

**Definition 8.3 (continuation equivalence).** Consider a finite deterministic semantic machine with partial transitions $T_o$, an operation alphabet and a fixed family of observable claims. Two states satisfy $s\sim t$ when every finite operation word has the same legality from both states and, whenever legal, yields the same observable claims. The empty word is included. An illegal continuation has a distinct failure output.

**Theorem 8.4 (minimal exact continuation memory).** The equivalence of Definition 8.3 is preserved by every legal transition. Its quotient machine reproduces all declared continuation claims. Any deterministic encoding that supports all these claims exactly must distinguish different equivalence classes. If there are $N$ classes, any fixed-length binary memory requires at least $\lceil\log_2N\rceil$ bits; an encoding by class index attains this bound.

*Proof.* If $s\sim t$, appending any operation word after a legal first operation gives the same legality and outputs; hence $T_o(s)\sim T_o(t)$. Transitions and observations therefore descend to the quotient. If an encoding assigned the same code to inequivalent states, some continuation would require two distinct outputs or legality decisions from that same code, a contradiction. Counting distinct fixed-length binary codes proves the bit bound. ∎

This is the finite-state minimization principle applied to a declared causal interpreter. It does not prove a neural sample-complexity bound, and the bit bound cannot be applied to noiseless arbitrary real coordinates without an encoding or precision assumption.

In the reference machine, states are three bits $(a,b,c)$; operations flip $a$, swap $a$ and $b$, or flip $c$. The third bit is irrelevant to the chosen tasks. Preserving the present output $a$ and all future operations requires {{A_CLASSES}} equivalence classes, or {{A_BITS}} bits. Preserving parity $a\mathbin{\oplus}b$ requires {{PARITY_CLASSES}} classes, or {{PARITY_BITS}} bit. Encoding only $a$ gives the present output exactly but produces {{QUOTIENT_FAILURES}} ordered state-pair disagreements after the swap. Memory adequacy depends on both queries and continuations.

## 8.3 Linear information and stored precision

**Corollary 8.5 (additional exact linear memory).** Let $q$ range over the full probability simplex, retain $Aq$ exactly with the normalization row in the row space of $A$, and require the fixed linear query family $Cq$. The least number of additional linear memory coordinates is

$$k=\operatorname{rank}\!\begin{pmatrix}A\\C\end{pmatrix}-\operatorname{rank}(A).\qquad\text{(8)}$$

*Proof.* Choose a basis of the query rows modulo the row space of $A$ to obtain a sufficient code with $k$ rows. Conversely, exact reconstruction requires every query row to lie in the row space of the retained and added rows. Otherwise a null direction changes a query while leaving all retained coordinates fixed. A sufficiently small perturbation of an interior simplex point realizes both signs of that direction. At least $k$ additional rows are necessary. ∎

This specializes the causal-memory result in Ghosh (2026b). Extra known affine constraints must be included before applying the row-space test. Multiple unknown independent response blocks generally give nonlinear constraints; concatenation does not automatically turn them into one free response simplex.

Rank does not determine noise amplification. For completeness, the precision contract inherited from the same paper is stated explicitly.

**Proposition 8.6 (bounded-noise recovery on a response polytope).** Let $K$ be a nonempty compact polytope, let a memory report $z=Mq+e$ with $|e|\leq h$ and $h\geq0$, and let the scalar query be $c^\mathsf Tq$. For this unrestricted coordinatewise bounded-report channel, the minimax absolute error over deterministic decoders is

$$R^*=\frac12\max_{\substack{q,q'\in K\\|M(q-q')|\leq2h}}c^\mathsf T(q-q').\qquad\text{(9)}$$

Equivalently, writing $W(K;v)=\max_Kv^\mathsf Tq-\min_Kv^\mathsf Tq$,

$$R^*=\min_\lambda\left[h^\mathsf T|\lambda|+\frac12W(K;c-M^\mathsf T\lambda)\right].\qquad\text{(10)}$$

*Proof.* A feasible pair in (9) admits a common midpoint report, so any decoder errs by at least half the query difference on one member. For any $\lambda$, subtract the midpoint of the residual range of $(c-M^\mathsf T\lambda)^\mathsf Tq$ and use the affine decoder based on $\lambda^\mathsf Tz$. Its error is bounded by (10). Linear-programming duality makes these bounds equal. This is the finite recovery theorem proved in Ghosh (2026b), related to classical optimal recovery. ∎

For $K=\Delta_3$, $c=(1,0,0)$ and rows $M_1=(1,1,0)$, $M_2=(0,1,0)$, subtracting the two stored values recovers $q_1$ exactly at zero noise. With coordinate errors $h_1=h_2={{NOISE_H}}$, the sharp minimax error is ${{NOISE_RISK}}$. Section 13 independently checks the LP over indistinguishable pairs. An adequate exact memory can therefore be too imprecise for a requested causal decision.

# 9 Horizontal compatibility has a quantitative but limited role

## 9.1 Data spaces and overlap maps

**Definition 9.1 (a finite horizontal audit).** Fix a finite context graph. At vertex $i$ place a finite-dimensional inner-product data space $V_i$, and at edge $e=ij$ an overlap space $V_e$ with linear maps $\rho_{i,e}:V_i\to V_e$ and $\rho_{j,e}:V_j\to V_e$. These define a cellular sheaf on the graph. After fixing orientations, units and positive audit weights, form the dimensionless coboundary

$$ (Bz)_e=\sqrt{w_e}\,[\rho_{j,e}z_j-\rho_{i,e}z_i],\qquad L=B^*B.\qquad\text{(11)}$$

Its compatible sections are $\ker B$. If higher-dimensional overlap cells are included, their restriction diamonds must commute for the coboundaries to form a cochain complex. A learned collection of arbitrary pairwise maps is not automatically such a higher-dimensional sheaf. A probabilistic marginal-consistency diagram also need not satisfy unique gluing; the linear audit here makes no such claim about arbitrary probability tables.

**Theorem 9.2 (spectral repair bound).** Suppose $B\ne0$ and let $\lambda_+$ be the smallest positive eigenvalue of $L$. With $P$ the orthogonal projection onto $\ker B$,

$$\|z-Pz\|\leq\frac{\|Bz\|}{\sqrt{\lambda_+}}.\qquad\text{(12)}$$

The constant is sharp. For a linear decoded quantity $Hz$, replacing $z$ by $Pz$ changes it by at most $\|H\|\,\|Bz\|/\sqrt{\lambda_+}$.

*Proof.* Expand $z-Pz$ in orthonormal eigenvectors with positive eigenvalues. Its squared residual is $\langle z-Pz,L(z-Pz)\rangle\geq\lambda_+\|z-Pz\|^2$. An eigenvector with eigenvalue $\lambda_+$ attains equality. The decoder statement follows from the operator norm inequality. ∎

This standard spectral estimate is a direct application of cellular-sheaf Laplacian theory (Hansen & Ghrist, 2019). It is a certificate of representational repair, not a causal identification theorem. If $B=0$, every section is already compatible and the distance is zero; no positive spectral gap is available or required.

**Corollary 9.3 (compatible errors survive the audit).** An error lying in $\ker B$ is invisible to the overlap residual and need not be invisible to the task decoder or causal checker.

*Proof.* For $v\in\ker B$, $B(z+v)=Bz$. If $Hv\ne0$, the decoded quantity changes. In particular a constant wrong scalar on every vertex of a connected constant sheaf has zero residual. ∎

On a three-vertex cycle with identity restriction maps, the positive gap is $3$. The section $(1,-1,0)$ has squared residual $6$ and squared distance $2$, attaining (12). Multiplying every audit row by $1/100$ changes the squared residual to $3/5000$ and the gap to $3/10000$, leaving the certified distance unchanged. A raw residual threshold without its map scale is therefore not a portable guarantee. These are exact spectral identities with a floating-point eigenvalue cross-check.

FIGURE: fig/v2_execution_and_compatibility.png|Figure 2 Compatibility and decoded execution require separate tests|Left: row scaling makes the audit residual arbitrarily small while the normalized repair bound and distance stay fixed. Right: the two-state bypass example passes both observed training cases and fails both altered-state cases. This is a finite counterexample, not a trained-model experiment.

## 9.2 Learning compatible coordinates

The horizontal loss in (4) is useful once observation maps and units are fixed. It can encourage shared representations to agree and reduce the repair term in (12). The operation loss supplies a separate validity signal. A zero residual can be correct evidence of agreement while the shared proposition is wrong, as Proposition 4.1 already demonstrated for adjustment tables.

Learning all maps and all representations from this loss alone permits trivial solutions: every representation or every restriction map can vanish. Preventing collapse needs independently verified decoding targets, declared coordinate scales and constraints on the admissible map family. Restrictions between fixed semantic coordinates can be implemented exactly; restrictions between learned features require their own abstraction tests. Distinct hypotheses or causal regimes remain separate branches until a stated map relates them. Averaging incompatible branches does not establish gluing.

# 10 Training and replay as controlled information acquisition

## 10.1 The teacher corpus is an adaptive archive

A teacher can supply many traces for one easy graph and few for a rare difficult graph. A verifier can then inspect only a selected subset. Even perfect labels on inspected records do not make that archive representative of a declared training population. Ghosh (2026a, 2026c, 2026e) develops this sampling distinction for adaptive optimisation; the same elementary identity applies to a finite record universe.

**Lemma 10.1 (proposal and inspection correction).** Let a finite universe $\Omega$ have fixed reference probabilities $\mu(\omega)$. Before attempt $t$, choose a predictable proposal $q_t(\omega)>0$ wherever $\mu(\omega)>0$. After drawing $\omega_t$, choose its inspection probability $p_t(\omega_t)>0$ before observing the expensive inspection result. Let $I_t$ be its inclusion indicator with the declared conditional mean. For a fixed bounded function $f$,

$$\mathbb E\!\left[\frac{I_t\mu(\omega_t)f(\omega_t)}{q_t(\omega_t)p_t(\omega_t)}\,\middle|\,\mathcal F_{t-1}\right]=\sum_{\omega\in\Omega}\mu(\omega)f(\omega).\qquad\text{(13)}$$

*Proof.* Conditional on the history, sum first over the inspection indicator and then over the draw. Its factors $p_t$ and $q_t$ cancel the denominators. ∎

For validity indicator $V(\omega)$, (13) applies separately to $Vf$ and $V$. Under fixed positive joint coverage bounds, bounded martingale differences give convergence of their averages to the reference integrals. If the limiting valid mass is positive, the ratio converges to the reference expectation conditional on validity. The finite-sample self-normalized ratio is generally biased; the identity is for the unnormalized integrals. A generated text sequence's proposal probability is useful only if it is actually available under the stated sampling procedure. An arbitrary inaccessible teacher API does not supply a computable correction simply by producing text.

In the finite illustration, the reference mean is ${{ARCHIVE_MEAN}}$, while the normalized mean among uncorrected inspected records is ${{ARCHIVE_NAIVE}}$. Applying both corrections recovers ${{ARCHIVE_CORRECTED}}$ in expectation. This verifies the sampling identity; it is not a claim that importance weighting alone gives a low-variance neural training algorithm.

## 10.2 Error budgets for a continuing harness

Exact primitive verification has zero mathematical false acceptance under its premises. Other components, including statistical tests and learned evaluators, need an explicit failure budget. High empirical accuracy on a fixed benchmark does not by itself supply that budget.

**Theorem 10.2 (conditional error spending).** Let $E_t$ be a false accepted declaration at attempt $t$. Suppose $\Pr(E_t\mid\mathcal F_{t-1})\leq\delta_t$, with $\delta_t$ predictable and $\sum_{t\geq1}\delta_t\leq\delta$ almost surely. Then the probability of any false accepted declaration, including before an adaptively chosen stopping time, is at most $\delta$.

*Proof.* The union bound and conditional expectation give

$$\Pr\!\left(\bigcup_tE_t\right)\leq\sum_t\mathbb E[\Pr(E_t\mid\mathcal F_{t-1})]\leq\mathbb E\sum_t\delta_t\leq\delta.$$

Stopping only removes events from this union. No independence is required. ∎

For $\delta_t=\delta/[t(t+1)]$, the infinite budget sums exactly to $\delta$. At $\delta={{RISK_TOTAL}}$, the first hundred terms use ${{RISK_SPENT}}$ and leave ${{RISK_LEFT}}$. These fractions check the allocation algebra, not achieved coverage of a learned judge. A conformal or confidence-sequence method must establish its own sampling and adaptation conditions before it can enter this theorem.

## 10.3 Complementary records and query-dependent retention

**Proposition 10.3 (verification value need not be submodular).** A query-specific information objective can assign zero one-step worst-case benefit to either of two reports and positive benefit to their pair.

*Proof.* Let $q\in\Delta_3$ and target $q_1$. Allow exact reports $q_1+q_2$ and $q_2$. Each alone leaves a fibre with query width one: the first cannot distinguish simplex vertices 1 and 2, and the second cannot distinguish vertices 1 and 3. Their pair gives $q_1$ by subtraction, so worst remaining width is zero. The information gains on the empty set, each singleton and the pair are $0,0,0,1$, violating diminishing returns. ∎

This reproduces the complementary-channel example of Ghosh (2026b) in the training-memory setting. The maps are legitimate observation channels; their availability as interventions in an application must be separately specified. It does not refute submodularity of other objectives. For replay, it suggests evaluating bundles of mutually informative records rather than stopping whenever no single record changes the present answer. No optimal general bundle-selection algorithm follows from this counterexample.

## 10.4 Soft priorities follow hard validity

Among records that meet the intended admission contract, a priority can trade verification cost, continuation coverage, representation repair and query-memory precision. The units must first be normalized. A bounded loss $\ell$ and reference $\mu$ give a preference $p_\beta\propto\mu e^{-\beta\ell}$. This is a sampling preference over records, not a probability that their claims are true. A hard validity or feasibility condition remains a separate gate.

**Proposition 10.4 (stability under priority error).** Let two normalized preferences have the same reference and dimensionless log-weight difference $u$ with oscillation $\operatorname{osc}(u)=\sup u-\inf u=d<\infty$. Then

$$\operatorname{TV}(p,p')\leq\tanh(d/4).\qquad\text{(14)}$$

The bound is sharp, and a constant shift in $u$ has no effect.

*Proof.* Put $g=e^u\in[m,M]$ and $s=\mathbb E_p g$. Convexity bounds the expected positive deviation by the endpoint distribution with the same mean, giving $\operatorname{TV}(p,p')\leq(M-s)(s-m)/[s(M-m)]$. Its maximum over $s\in[m,M]$ occurs at $s=\sqrt{mM}$ and equals $(\sqrt M-\sqrt m)/(\sqrt M+\sqrt m)=\tanh(d/4)$. A two-point reference realizing that mean attains equality. Normalization cancels constant shifts. ∎

This is the error-oscillation principle used in the companion fusion work (Ghosh, 2026f), specialized to replay priorities. With weights $1/4$ and $4$ and reference masses $4/5$ and $1/5$, the exact total variation is ${{TILT_TV}}$, attaining the bound. Preference stability does not establish validity, and a stable sampler can consistently emphasize the wrong target.

The joint-limit and normal-geometry analysis in Ghosh (2026g) supplies a further scheduling caution: changing retrieval noise and inverse temperature together can select a different limit from changing them in succession. Nothing in that result identifies an optimal neural curriculum. It motivates freezing the intended population, units and schedule before interpreting a change in the selected training records.

CAPTION: Table 6 Connections to the related research programme

| Paper | Ingredient used here | Scope retained |
|:--|:--|:--|
| ADE for adaptive search | Predictable proposals and logged evaluated states | Retrieval is distinct from target sampling |
| ADC with sequential evidence | Response fibres, memory ranks and noisy recovery | Fixed model and declared query family |
| Certified cache and temperature reuse | Versioned reuse and joint observation coverage | A cache hit requires a matching contract |
| Dependency preserving temporal computation | Shared variables, clocks and interval dependence | Token order does not supply physical causation |
| Interval fitness and robust generalized Bayes | Loss preferences and sampling corrections | Preference is distinct from observation likelihood |
| Interval Pareto certificates | Hard admissibility and separate preference channels | Scalar preference cannot certify validity |
| Joint limits and normal geometry | Coupled schedule limits | No automatic transfer of geometric exponents to neural learning |

FIGURE: fig/v2_archive_and_evidence.png|Figure 3 Selection bias and complementary evidence in finite examples|Left: expected record values under the reference, uncorrected inspected archive and corrected estimator. Right: worst remaining query width for no report, either individual report and their pair. These calculations illustrate distinct sampling and information obligations.

# 11 Neuroscience constrains an interpretation

## 11.1 Replay as selective access

Mattar and Daw (2018) propose a normative account in which memory access is prioritized by the improvement in future decisions, balancing expected use with the gain from updating a state. Their spatial-learning simulations connect this utility to observed replay patterns. This supports a functional question for the present architecture: which retained transition is useful for the next task? It does not establish that hippocampal sequences carry operation certificates or solve the optimization programmes above.

Proposition 10.3 adds a limitation to a purely myopic interpretation. Two retained observations can jointly preserve a future causal contrast even when neither has a one-step worst-case benefit. A replay policy for a known query family may therefore need a bundle value. The mathematical claim concerns a stated information objective; whether biological replay prioritizes such bundles is a separate hypothesis.

## 11.2 Evidence for selective consolidation

Chang et al. (2025) recorded hippocampal populations and pupil dynamics in naturally sleeping mice. Recent and older experience replay preferentially occupied different non-REM pupil substates. Closed-loop disruption of ripples in the contracted-pupil substate impaired recent-memory recall, while the compared disruption in dilated-pupil substates did not. These findings motivate distinct consolidation schedules for recent and established material. They do not show that sleep alternates between the particular loss terms in (4).

Denis et al. (2026) used human EEG and a sleep-versus-wake memory design to identify encoding activity associated with subsequent retention across sleep. Their tagging-related theta response was related to later slow-oscillation–spindle coupling and memory performance. This supports the study of an encoding-time retention tag. It does not identify a logical certificate as the content of that tag, nor establish the sufficiency of theta activity for preserving a particular causal query.

The engineering interpretation is to retain different metadata at encoding: context identity, verified claims, unresolved obligations and anticipated query use. Offline consolidation can then choose what to replay, recheck and compress. In this interpretation the retained object may be a sufficient set of consequences rather than a verbatim transcript. Theorem 8.4 states a finite exact criterion for that replacement; Proposition 8.6 states one precision cost. Neither is presently a neural mechanism.

## 11.3 Context selection through thalamocortical interaction

Rikhye et al. (2018) studied mice switching between cueing contexts. Their results distinguish prefrontal cue and rule representations from mediodorsal-thalamic activity involved in context switching, including maintaining relevant representations and suppressing irrelevant ones. This motivates a context-indexed routing role: the same stored computation can be applicable in one task context and unavailable in another. It provides no evidence that mediodorsal thalamus computes sheaf restrictions or performs symbolic proof checking.

Anatomical laminae are not identified with ASE's arbitrary layer count. Hippocampal replay time is not the physical clock of an event described in a reasoning problem. A decoder intervention tests the proposed computational representation, while neural perturbations test a biological mechanism. Both need to preserve the intended comparison context before their effects can be interpreted.

## 11.4 Falsifiable functional hypotheses

**H1 (complementary replay).** After subjects learn both channels in a complementary-evidence task, replay or retrieval should depend on their joint relevance to a future query, beyond individual prediction error. Compare a paired-channel condition with matched single-channel and redundant-channel controls, keeping exposure, reward and task difficulty controlled. Freeze a behavioural or neural interaction statistic before data collection. A confidence interval entirely in the opposite direction to the specified positive interaction refutes the prediction; an interval spanning zero is inconclusive.

**H2 (context-dependent reuse).** Reusing a learned relation after a task-context change should depend on whether the original premises still apply. A controlled task can change the relevant conditioning variable while retaining superficial cues and rewards. The prediction is an increase in context-appropriate routing and suppression of stale reuse after learning, beyond a cue-only model. Prespecify a minimum positive held-out interaction; a confidence interval whose upper endpoint falls below that minimum refutes this prediction. A thalamic mechanism would require additional neural measurements or interventions.

**H3 (retention follows future computation).** When two groups have matched present-answer performance but different future operation requirements, later retention should preserve the information needed for those operations. The swap example in Section 8 provides a minimal task logic. Compare query-preserving compression with transcript length, usage and surprise baselines at matched resources. A reliable advantage for the opposite retention pattern refutes the proposed direction; equivalence within a declared sensitivity margin would also contradict a prespecified nonzero effect.

No new animal, human, sleep or neural-recording experiment is reported. The primary findings above constrain a proposed functional mapping and supply tests; they do not prove that the brain implements ADC.

# 12 An AI harness that can train from its own computations

## 12.1 Separate execution from training

Agent Lightning already separates agent execution from training and decomposes trajectories into transitions through a unified interface (Luo et al., 2025). Transition decomposition itself is therefore not a novelty claim here. The added contract is to bind a transition's actual operation and operands to a declared causal interpreter, preserve explicit unresolved statuses and distinguish decoded execution from observed answer agreement.

Rosset et al. (2026) study computer-use verification with separate process and outcome signals, explicit treatment of failure causes and long-context management. Their empirical verifier is evidence that those distinctions matter in evaluated web tasks. It is not an exact verifier for our mathematical domain. Zhang et al. (2026) propose CLIFT, which reuses a learned verification bank in training and trajectory selection. Its judge-relative calibration and evaluation setting differ from exact causal validity. A claimed statistical guarantee in such a system would enter Theorem 10.2 only after its conditional or simultaneous coverage assumptions were established.

## 12.2 Authoritative state and proposed packets

**Definition 12.1 (an operation-bound packet).** A packet records the authoritative context reference, actual input-state reference, operator identifier, operand scopes, claimed result, premise evidence, arithmetic or logical certificate and claim scope. A teacher or student proposes this packet. The harness retains the authoritative problem separately and compares the bound contents before executing the admitted transition.

CAPTION: Table 7 Fields checked by the reference packet interface

| Field | Required relationship |
|:--|:--|
| Context | Exact graph, data, query, units and version match |
| Input state | Matches the actual current operands |
| Operation | Recognized primitive with its own semantics |
| Scope | Conditioning and outcome variables match the primitive |
| Premise | Adjustment and condition-deletion requirements hold |
| Result | Submitted table and sum equal exact recomputation |
| Unsupported claim | Returns unverified rather than an invented proof |

The reference uses immutable Python dataclasses and exact fractions. It verifies two supported operations on finite positive binary DAG laws: constructing a conditional table for an admissible adjustment and deleting a condition when d-separation licenses that equality. It is deliberately smaller than the full ADC kernel. A content digest binds values but supplies neither authentication nor access control.

The new packet cases include an honestly computed table, a coincidentally equal but unlicensed deletion, a licensed deletion, changed context and units, stale operands, changed arithmetic, an unsupported operator and an invalid adjustment. Numerical mismatch and premise failure receive distinct results. A rejected premise does not assert that the reported number is false in the present model; Proposition 7.2 explains why.

## 12.3 Reuse after evidence changes

**Corollary 12.2 (reuse on a certified subset).** If an operation's claim is valid on model set $K$, a new nonempty model set $K'\subseteq K$ preserves that claim when event meanings, query, operation and decoder semantics remain fixed. A sharp bound additionally requires endpoint witnesses feasible in $K'$.

*Proof.* A universally valid claim on $K$ holds on every subset. A previously attained endpoint remains attained precisely when an endpoint witness remains feasible. ∎

This is the evidence-refinement contract of Ghosh (2026b). An arbitrary version change does not prove inclusion. A target change can invalidate both a numerical cache and a reasoning certificate even if every input array has the same shape. Evidence refinement can release memory coordinates under (8); changes to the future query family can require additional memory instead.

## 12.4 A training and evaluation protocol

First freeze a task family with authoritative graphs, exact or statistically justified observations, query semantics and operation schemas. Generate teacher proposals with logged sampling settings. Parse the visible traces into candidate packets; preserve the original text for audit and optional explicit-step training. Admit packets according to the intended value, operation or execution claim, keeping their labels distinct. Train the operation policy and semantic decoders on accepted records. Add the sheaf residual only after units and maps are declared. Replace verbal steps progressively and test (5) on student-generated trajectories and prespecified state interventions.

Teacher activations are optional. A text-only interface supplies visible traces and tool results; the student supplies its own separator representations. Any checkpoint input must be a function of the available prefix and current observations. The verified target for that checkpoint must concern that same available state. Future answers may be labels, but cannot be supplied as checkpoint features or smuggled into its state target as already established evidence. A decrease in visible tokens does not imply a decrease in floating-point operations, sequential depth, tool calls or elapsed time; report these budgets separately.

The original D1 prediction remains a comparison between certificate-admitted and two-decimal answer-filtered training. Match accepted-record counts as well as teacher, parsing and verification budgets, and report the cost of obtaining those records. Keep the original error-ratio threshold of one half, handling a zero-error baseline separately. D3 retains the predicted factor-of-two difference in missed valid non-back-door certificates, with honest abstention separated from erroneous refutation labels.

D2 requires a narrower interpretation. Its original target of linear checkpoint mean absolute error below $0.01$ after removing half the verbal steps remains an untested readout prediction. Failure refutes that particular linear-readout claim; it does not by itself prove a shortcut. The bypass test of Proposition 8.2 and the continuation tests of Theorem 8.4 supply the additional execution comparisons.

**D4 (operation-bound supervision).** At matched training and evaluation budgets, operation-bound records will reduce unlicensed condition-deletion proposals on held-out positive models with the same allowed graph, compared with value-only records. Freeze the proposed rate ratio at at most one half, the model family, confidence construction and minimum nonzero comparator rate in advance. A ratio interval wholly above one half refutes the prediction; one crossing the threshold is inconclusive. Final-answer accuracy, qualified failure, certificate coverage and verification cost are reported separately.

All four learned-model predictions remain untested. Exact verification can provide trustworthy labels inside a declared domain; it does not establish that a neural policy learns to propose them efficiently or generalizes to unseen causal structures.

# 13 What the added computation establishes

The inherited independent validator was rerun from the attached source and reproduced all {{OLD_LINES}} summary records, passing {{OLD_CHECKS}} checks against the original C# outputs. No C# compiler or teacher model was invoked in this revision. The original C# kernel and its recorded outputs are retained; the new finite examples use the immutable Python reference.

The new reference emits {{NEW_RECORDS}} deterministic records. Its independent checker passes {{NEW_CHECKS}} checks. Five two-model linear programmes computed with SciPy are checked by a separate exact rational active-constraint enumerator. The graph primitive is compared with independent direct-path d-separation on {{DSEP_CASES}} cases, with no discrepancy. Clean-process replay reproduces the new summary and result JSON byte for byte. The spectral eigenvalue is a floating-point cross-check of an exact three-cycle identity, not an outward-certified eigenvalue interval.

CAPTION: Table 8 New finite verification results

| Computation | Result | Meaning |
|:--|:--|:--|
| Coincident condition deletion | Value $1/2$ accepted by value check; operation rejected | Numerical agreement can hide an unlicensed rule |
| Compatible witness | Required $3/4$ versus dropped $1/2$ | The failed universal deletion has a semantic witness |
| Licensed deletion | Conditional table $(1/5,4/5)$ accepted | Valid alternative operators remain available |
| Continuation quotient | {{A_CLASSES}} classes for future $a$; {{PARITY_CLASSES}} for parity | Required memory depends on future operations |
| Decoded execution | Error ${{COMMUTE_ERROR}}$ equals the bound | The finite recurrence can attain the theorem |
| Horizontal repair | Squared residual $6$, gap $3$, distance squared $2$ | Spectral normalization is necessary |
| Selection and precision | Corrected mean ${{ARCHIVE_MEAN}}$; recovery radius ${{NOISE_RISK}}$ | Sampling correction and memory precision are separate |
| Independent verification | {{NEW_RECORDS}} records and {{NEW_CHECKS}} passing checks | Mathematical examples only |

These records demonstrate arithmetic and interface behaviour on their specified finite inputs. They do not estimate the error rates of a real trace parser, the faithfulness of a frontier teacher, a learned latent execution defect or a biological mechanism. The learned experiments remain necessary to assess those claims.

# 14 Limitations and remaining mathematical questions

The exact adjustment census is exhaustive over DAGs respecting one fixed five-vertex order, and random over the stated CPT grids. It is not a census of all labelled five-vertex DAGs, all mechanisms or actual teacher errors. The new operation interface covers only two primitives and finite positive binary laws. The original C# value checker remains useful for numerical certification, but it does not bind the actual textual operator that produced a coincident table.

Theorem 8.1 requires uniform defects on the relevant reachable states and fixed operation semantics. Finite probe accuracy cannot establish that uniform premise. The quotient theorem is finite and exact; approximate continuation equivalence with noise, unbounded operation horizons and changing task families needs additional analysis. A learned latent representation can preserve more information than any one probe recovers, or can expose a correct probe while routing through another feature. State interventions distinguish some of these cases but require their own abstraction validity.

The spectral repair theorem assumes finite-dimensional linear spaces, fixed units and a known positive eigenvalue. It does not solve nonlinear gluing, learn a cover or certify a causal assertion. General response constraints may be multilinear across independent unknown districts. The LP recovery theorem does not silently extend to them or to arbitrary stochastic memory noise.

The sampling identity assumes known proposal and inspection probabilities. A useful teacher whose sampling law is unavailable can still generate demonstrations, but those demonstrations do not automatically estimate a declared reference population. Conditional error budgets are assumptions to establish for each approximate verifier, not consequences of calling a system calibrated. Task generation, parsing, data versioning and real-world intervention meaning remain external obligations.

The cited neuroscience supports selective memory processing, replay and context-dependent routing. It does not support equating individual anatomical layers with an arbitrary ASE depth or identifying a neural rhythm with an exact certificate. The proposed mappings and learned-agent advantages are hypotheses with stated comparisons and failure outcomes.

# 15 Conclusion

Long teacher traces can train a causal reasoner through visible examples, typed operations, verified intermediate facts and alternative derivations. The original finite census establishes why answer agreement and overlap agreement require additional checks. The revision distinguishes a numerically correct value, a licensed operation and a realized latent computation. Typed composition supplies relative semantic soundness; commuting execution squares supply an explicit propagation bound; continuation equivalence specifies what an exact compressed state must preserve.

Horizontal sheaf structure provides a quantitative compatibility audit when its spaces, units and maps are fixed. It leaves compatible semantic errors untouched. Adaptive training archives require logged selection laws if they are used to estimate a fixed population target. Replay and consolidation must preserve the intended future computations at the required precision, with complementary records considered jointly when necessary. These mathematical contracts give a concrete training and harness proposal whose neural and biological benefits remain to be measured.

# Appendix A Reproduction and claim status

The source bundle retains the original C# kernel, its 34-line output and all original result files. Run the independent inherited check with `python validate.py cs_out.txt out validation_v1_rerun.json`. The new finite examples are produced by `python transition_reference.py out_v2 > py_v2.txt` and checked by `python validate_v2.py`. The reference uses Python {{PYTHON_VERSION}}, NumPy {{NUMPY_VERSION}} and SciPy {{SCIPY_VERSION}} in this revision. Exact fractions certify finite arithmetic and the independent LP optima; SciPy and NumPy provide separate floating-point computations.

The current manuscript is `paper.md`; `build_v2.py` creates the current Word paper using the attached V1 Word file as the series reference. `paper_v1.md` and `build_paper_v1.py` preserve the earlier manuscript and builder. The earlier builder refers to an external series document that was not in its source ZIP; the current builder uses the included `base_v1.docx` and has no such external manuscript dependency. Rendering is required after a rebuild because Office versions and fonts can change pagination.

The immutable public packet consists of a context reference, an input reference, an operation, conditioning variables, a rational table and a rational answer. Temporary enumeration uses private scratch structures. The checker first compares context and input, then recognizes the operation, verifies graph premises and finally recomputes the value. This implements the distinction of Table 5 without claiming authenticated provenance or a general causal-language parser.

**Claim status.** Theorems and propositions are proved under their stated hypotheses. Sections 5 and 13 report deterministic or seeded finite calculations. D1 to D4 and H1 to H3 are untested predictions. No frontier teacher was queried, no latent student was trained, and no new biological data were collected. Exact mathematical verification remains relative to correct input semantics and a correct primitive interpreter.

