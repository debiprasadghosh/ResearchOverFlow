"""Build the revised paper with native OMML and the supplied series reference."""
from pathlib import Path
import copy,json,re,subprocess,sys,zipfile
from lxml import etree
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

H=Path(__file__).resolve().parent
for script in ['prepare_manuscript.py','fig_distill.py','fig_v2.py']:
    subprocess.run([sys.executable,str(H/script)],cwd=H,check=True)
raw=H/'raw_v2.docx';out=H/'deliverables/Operation_Certificates_for_Latent_Causal_Reasoning_V2.docx'
out.parent.mkdir(exist_ok=True)
subprocess.run(['pandoc','paper.md','-f','markdown+tex_math_dollars-auto_identifiers','--reference-doc=base_v1.docx','-o',str(raw)],cwd=H,check=True)
d=Document(raw)
for sec in d.sections:
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.top_margin=Inches(.85);sec.bottom_margin=Inches(.85)
    sec.left_margin=Inches(1);sec.right_margin=Inches(1)
    sec.header_distance=Inches(.35);sec.footer_distance=Inches(.4)
    # Retain a simple page number, free of old running titles.
    for part in [sec.header,sec.footer]:
        for p in part.paragraphs:
            for x in list(p._p):
                if x.tag!=qn('w:pPr'):p._p.remove(x)
    fp=sec.footer.paragraphs[0];fp.alignment=WD_ALIGN_PARAGRAPH.CENTER
    run=fp.add_run();field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');run._r.addnext(field)
for st in d.styles:
    if st.type==1:
        st.font.name='Times New Roman';st.font.color.rgb=RGBColor(0,0,0)
        st.font.size=Pt(11)
        st.paragraph_format.widow_control=True
        if st._element.find('.//'+qn('w:pBdr'))is not None:
            for x in list(st._element.iter(qn('w:pBdr'))):x.getparent().remove(x)
for name in ['Normal','Body Text','First Paragraph']:
    if name in d.styles:
        st=d.styles[name];st.paragraph_format.space_after=Pt(6)
        st.paragraph_format.line_spacing=1.12
        st.paragraph_format.keep_with_next=False
        st.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
for name,size in [('Title',22),('Subtitle',12),('Heading 1',14),('Heading 2',12),('Heading 3',11.5)]:
    st=d.styles[name];st.font.size=Pt(size)
    st.font.bold=name.startswith('Heading')
    st.paragraph_format.keep_with_next=True
    st.paragraph_format.space_before=Pt(12 if name.startswith('Heading')else 0)
    st.paragraph_format.space_after=Pt(6)
    if name in ['Title','Subtitle']:st.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
    st.paragraph_format.page_break_before=False
d.styles['Title'].paragraph_format.space_after=Pt(9)
for name in ['Author','Date']:
    if name in d.styles:
        d.styles[name].paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
        d.styles[name].paragraph_format.space_after=Pt(5)
d.styles['Caption'].font.size=Pt(9.5)
d.styles['Caption'].font.italic=False
d.styles['Caption'].font.bold=False
d.styles['Caption'].paragraph_format.alignment=WD_ALIGN_PARAGRAPH.LEFT
d.styles['Caption'].paragraph_format.space_before=Pt(5)
d.styles['Caption'].paragraph_format.space_after=Pt(8)

widths={1:[1100,1000,950,1500,1000,1000,2810],2:[2800,950,1150,1350,1450,1660],
        3:[1500,2620,2620,2620],4:[2500,3650,3210],5:[1900,3600,3860],
        6:[2700,3300,3360],7:[1900,7460],8:[2400,3100,3860]}

def fmt_table(tbl,number):
    tbl.alignment=WD_TABLE_ALIGNMENT.CENTER;tbl.autofit=False
    ws=widths[number]
    pr=tbl._tbl.tblPr
    for x in list(pr):pr.remove(x)
    tw=OxmlElement('w:tblW');tw.set(qn('w:w'),'9360');tw.set(qn('w:type'),'dxa');pr.append(tw)
    jc=OxmlElement('w:jc');jc.set(qn('w:val'),'center');pr.append(jc)
    borders=OxmlElement('w:tblBorders')
    for name in ['top','left','bottom','right','insideH','insideV']:
        x=OxmlElement('w:'+name);x.set(qn('w:val'),'single');x.set(qn('w:sz'),'4');x.set(qn('w:color'),'D9D9D9');borders.append(x)
    pr.append(borders)
    layout=OxmlElement('w:tblLayout');layout.set(qn('w:type'),'fixed');pr.append(layout)
    grid=tbl._tbl.tblGrid
    for gc,w in zip(grid.gridCol_lst,ws):gc.set(qn('w:w'),str(w))
    for i,row in enumerate(tbl.rows):
        trpr=row._tr.get_or_add_trPr()
        for x in trpr.findall(qn('w:trHeight')):trpr.remove(x)
        if trpr.find(qn('w:cantSplit'))is None:trpr.append(OxmlElement('w:cantSplit'))
        if i==0 and trpr.find(qn('w:tblHeader'))is None:trpr.append(OxmlElement('w:tblHeader'))
        for j,cell in enumerate(row.cells):
            cell.width=Inches(ws[j]/1440);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            cp=cell._tc.get_or_add_tcPr()
            for x in list(cp):cp.remove(x)
            cw=OxmlElement('w:tcW');cw.set(qn('w:w'),str(ws[j]));cw.set(qn('w:type'),'dxa');cp.append(cw)
            sh=OxmlElement('w:shd');sh.set(qn('w:val'),'clear');sh.set(qn('w:fill'),'E9EEF2' if i==0 else 'FFFFFF');cp.append(sh)
            mar=OxmlElement('w:tcMar')
            for tag,v in [('top',85),('left',80),('bottom',85),('right',80)]:
                x=OxmlElement('w:'+tag);x.set(qn('w:w'),str(v));x.set(qn('w:type'),'dxa');mar.append(x)
            cp.append(mar)
            va=OxmlElement('w:vAlign');va.set(qn('w:val'),'center');cp.append(va)
            for p in cell.paragraphs:
                p.style=d.styles['Body Text']
                p.paragraph_format.keep_with_next=False
                p.paragraph_format.space_before=Pt(0);p.paragraph_format.space_after=Pt(2)
                p.paragraph_format.line_spacing=1.05
                p.alignment=WD_ALIGN_PARAGRAPH.LEFT if (j==0 or len(ws)==3)else WD_ALIGN_PARAGRAPH.CENTER
                for run in p.runs:
                    run.font.name='Times New Roman';run.font.size=Pt(9.5);run.font.bold=i==0
                    run.font.color.rgb=RGBColor(0,0,0)

for p in list(d.paragraphs):
    t=p.text
    if t.startswith('CAPTION: '):
        p.text=t[9:];p.style=d.styles['Caption'];p.paragraph_format.keep_with_next=True
        p.alignment=WD_ALIGN_PARAGRAPH.LEFT
        for run in p.runs:run.font.bold=True
        number=int(re.search(r'Table (\d+)',p.text)[1])
        el=p._p.getnext()
        while el is not None and el.tag!=qn('w:tbl'):el=el.getnext()
        assert el is not None
        from docx.table import Table
        fmt_table(Table(el,p._parent),number)
    elif t.startswith('FIGURE: '):
        path,cap,alt=t[8:].split('|')
        pp=d.add_paragraph();pp.alignment=WD_ALIGN_PARAGRAPH.CENTER
        pp.paragraph_format.keep_with_next=True
        run=pp.add_run();run.add_picture(str(H/path),width=Inches(6.4))
        for x in pp._p.iter(qn('wp:docPr')):x.set('descr',alt)
        p._p.addprevious(pp._p)
        p.text='';p.style=d.styles['Caption'];p.paragraph_format.keep_with_next=False
        p.alignment=WD_ALIGN_PARAGRAPH.LEFT
        p.add_run(cap).bold=True
        p.add_run('\n'+alt).bold=False
    if p.style.name=='Title':
        p.text='Operation Certificates for\nLatent Causal Reasoning'
        p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    if p.style.name=='Subtitle':
        p.text='Learning from teacher traces through compatible representations\nand selective consolidation'
        p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    if p.text.startswith('Founder and Principal Engineer'):
        p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.space_after=Pt(10)
    if p.text in ['1 Introduction','Appendix A Reproduction and claim status','References']:
        p.paragraph_format.page_break_before=True
    if re.match(r'^(Definition|Theorem|Lemma|Proposition|Corollary) \d+\.\d+',p.text):
        p.paragraph_format.keep_with_next=True
    if p.text.rstrip().endswith('Then'):
        p.paragraph_format.keep_with_next=True
    if p.text.startswith('**'):raise AssertionError(p.text[:80])

# Long URLs use Word's hyperlink rendering; remove fixed no-wrap properties.
for tbl in d.tables:
    nxt=tbl._tbl.getnext()
    if nxt is not None and nxt.tag==qn('w:p'):
        from docx.text.paragraph import Paragraph
        following=Paragraph(nxt,d._body)
        following.paragraph_format.space_before=Pt(6)
M='http://schemas.openxmlformats.org/officeDocument/2006/math'
for rp in d.element.body.iter('{'+M+'}rPr'):
    if rp.find('{'+M+'}nor')is not None:
        for x in rp.findall('{'+M+'}scr')+rp.findall('{'+M+'}sty'):rp.remove(x)
    order=['lit','nor','scr','sty','brk','aln']
    for x in sorted(list(rp),key=lambda x:order.index(etree.QName(x).localname)if etree.QName(x).localname in order else 99):rp.append(x)
for r in d.element.body.iter('{'+M+'}r'):
    t=r.find('{'+M+'}t')
    if t is not None and re.fullmatch(r'\(\d+\)',t.text or ''):
        t.text='\u00a0\u00a0\u00a0\u00a0'+t.text
        t.set('{http://www.w3.org/XML/1998/namespace}space','preserve')
for p in d.paragraphs:
    if p.style.name in ['Title','Subtitle'] or p.style.name.startswith('Heading'):
        for run in p.runs:run.font.color.rgb=RGBColor(0,0,0)
        pp=p._p.get_or_add_pPr()
        for x in pp.findall(qn('w:pBdr')):pp.remove(x)
# Bibliography styling keeps references together while allowing a sensible page flow.
in_refs=False
for p in d.paragraphs:
    if p.text=='References':in_refs=True;continue
    if in_refs and p.text.strip():
        p.style=d.styles['Bibliography'] if 'Bibliography'in d.styles else d.styles['Normal']
        p.alignment=WD_ALIGN_PARAGRAPH.LEFT
        p.paragraph_format.first_line_indent=Inches(-.2);p.paragraph_format.left_indent=Inches(.2)
        p.paragraph_format.space_after=Pt(7);p.paragraph_format.line_spacing=1.06
        p.paragraph_format.keep_together=True;p.paragraph_format.keep_with_next=False
        for run in p.runs:run.font.size=Pt(10)
d.core_properties.title='Operation Certificates for Latent Causal Reasoning'
d.core_properties.subject='Teacher trace supervision compatible representations selective consolidation'
d.core_properties.author='Debi Prasad Ghosh'
d.core_properties.comments='Version 2 mathematical neuroscience and AI harness revision'
d.save(out);raw.unlink()
with zipfile.ZipFile(out)as z:
    assert z.testzip()is None
    for name in z.namelist():
        if name.endswith(('.xml','.rels')):etree.fromstring(z.read(name))
    root=etree.fromstring(z.read('word/document.xml'))
    ns={'m':M,'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    audit={'zip_and_xml_well_formed':True,'native_equations':len(root.findall('.//m:oMath',ns)),
           'tables':len(d.tables),'figures':len(d.inline_shapes),
           'formal_statements':re.findall(r'(?m)^\*\*((?:Definition|Theorem|Lemma|Proposition|Corollary) \d+\.\d+)',(H/'paper.md').read_text()),
           'full_schema_validation_claimed':False}
assert len(audit['formal_statements'])==len(set(audit['formal_statements']))
assert audit['tables']==8 and audit['figures']==3
(H/'document_audit_v2.json').write_text(json.dumps(audit,indent=2)+'\n')
print(out)
