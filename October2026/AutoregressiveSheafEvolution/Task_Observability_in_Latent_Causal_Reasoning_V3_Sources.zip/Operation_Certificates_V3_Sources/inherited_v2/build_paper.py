"""Build 'From Teacher Traces to Verified Transitions' as a Word document.

The manuscript is written in Pandoc Markdown with every number read from the validated C# output,
converted with the ADC paper as the reference document (same series styles), then post-processed
for tables, captions, the figure, equation tags and OOXML schema order."""
import copy, json, os, re, shutil, subprocess, sys, zipfile
from docx import Document
from docx.shared import Inches
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from lxml import etree

H = os.path.dirname(os.path.abspath(__file__))
REF = os.path.join(os.path.dirname(H), "adc", "in", "v1.docx")
OUT = os.path.join(H, "Teacher_Traces_to_Verified_Transitions.docx")
cs = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1].split() for l in open(os.path.join(H, "cs_out.txt"))}
val = json.load(open(os.path.join(H, "validation.json"))); assert val["all_passed"]
I = lambda k, i: int(cs[k][i]); D = lambda k, i: float(cs[k][i])
def num(x): return f"{x:,}"
def pct(a, b, d=1): return f"{100 * a / b:.{d}f}%"
T, U = "tenths", "hundredths"
Q = I(f"{U}_family", 2); NV = I(f"{U}_valid_sets", 0); NI = I(f"{U}_invalid_sets", 0)
nb = I(f"{U}_valid_sets", 3); multi = I(f"{U}_alternative_derivations", 0)
qi = I(f"{U}_queries_invalid_pass_round2", 0)
hist = [int(v) for v in cs[f"{U}_valid_set_histogram"]]

def inv_row(tag):
    k = f"{tag}_invalid_sets"; n = I(k, 0)
    return f"| {('Tenths' if tag == T else 'Hundredths')} | {num(n)} | {pct(I(k,1), n)} | {pct(I(k,2), n)} | {pct(I(k,3), n)} | {pct(I(k,4), n)} | {pct(I(f'{tag}_queries_invalid_pass_round2',1), I(f'{tag}_queries_invalid_pass_round2',0))} |"

checker_names = [("honest", "Honest derivation"), ("invalid_set", "Invalid adjustment set"), ("slip_outcome_table", "Slip of 0.01 in P(y \\| x, z)"),
                 ("slip_marginal_table", "Slip of 0.01 moved within P(z)"), ("drop_action_condition", "X dropped from the conditioning set"), ("slip_final_sum", "Slip of 0.01 in the final sum")]
def chk(tag, k):
    v = [int(x) for x in cs[f"{tag}_checker_{k}"]]; return v
chk_rows = []
for k, lab in checker_names:
    v = chk(U, k)
    chk_rows.append(f"| {lab} | {num(v[0])} | {pct(v[1], v[0])} | {pct(v[2], v[0])} | {pct(v[3], v[0])} | {pct(v[4], v[0])} |")
prec_rows = []
for L in (5, 10, 20, 40):
    v = [float(x) for x in cs[f"{U}_precision_L{L}"]]
    prec_rows.append(f"| {L} | {v[0]:.3f} | {v[1]:.3f} | {v[2]:.3f} |")
c_meas = I(f"{U}_invalid_sets", 2) / I(f"{U}_invalid_sets", 0)
drop_t = chk(T, "drop_action_condition"); drop_u = chk(U, "drop_action_condition")
slipz_u = chk(U, "slip_marginal_table")

MD = f"""---
title: "From Teacher Traces to Verified Transitions"
subtitle: "How long reasoning tokens can train Autoregressive Do Calculus"
author: "Debi Prasad Ghosh"
date: "31 October 2026"
---

Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India

## Abstract

Frontier models trained with proximal policy optimisation (PPO) or group relative policy optimisation (GRPO) generate long reasoning traces. We ask how such traces can supply training data for Autoregressive Do Calculus (ADC), a finite framework that compiles interventional queries into certified computations. Our answer is that a trace should not be imitated as text. It should be converted into transition records — problem context, current state, typed operation, result and certificate — that ADC learns to select and execute in its own latent states. The teacher's optimiser need not be reproduced: as with the distilled DeepSeek-R1 models, the student first learns from generated examples by supervision. The paper establishes the verification layer on which that pipeline depends and measures, in exact arithmetic, why it is needed. On all {num(I(f'{U}_family',0))} labelled five-event DAGs with {num(I(f'{U}_family',1))} random positive binary models, we enumerate every candidate adjustment derivation of {num(Q)} causal queries. An invalid adjustment set matched the true effect to two decimals in {pct(I(f'{U}_invalid_sets',2), NI)} of {num(NI)} cases and exactly in {pct(I(f'{U}_invalid_sets',1), NI, 2)}; with textbook parameters in tenths the exact rate rose to {pct(I(f'{T}_invalid_sets',1), I(f'{T}_invalid_sets',0))}. A zero overlap residual between local tables accepted every invalid set, as a proposition predicts, while a transition certificate built on the complete adjustment criterion rejected all of them and accepted every honest derivation. A back-door-only checker would have rejected {pct(nb, NV)} of the valid sets, so checker completeness also matters. In {pct(multi, Q)} of queries two or more valid derivations existed; all agreed exactly. An independent Python program reproduces all {val['lines']} output lines. Latent training itself is not run here; we state it as a protocol with falsifiable predictions.

**Keywords** reasoning traces; distillation; process supervision; causal identification; adjustment criterion; certified computation; continuous latent reasoning; Autoregressive Do Calculus

# 1 Introduction

A teacher that has learned by reinforcement to reason at length produces far more text than answers. For ADC this text is valuable only if it can be turned into something ADC can check and execute. ADC's input is a declared causal model, an observational law and a query; its output is an identified expression with a derivation and a certificate, or a qualified failure (Ghosh, 2026a). A long trace contains candidate operations — select an adjustment set, apply a rule, compute a table, normalise, sum — interleaved with corrections, digressions and abandoned attempts.

The proposal examined here has five steps. Generate several candidate solutions for each authoritative problem. Convert their text into checked transitions. Use the checked records to supervise operation selection, latent decoders, alternative derivations, error repair and certificate production. Gradually replace explicit reasoning with continuous computation. Add the sheaf structure of ADC as agreement on declared overlaps. The final objective rewards valid operations, decodable intermediate facts, overlap agreement and certified answers, and is followed by checked on-policy rollouts.

Three questions decide whether this is sound, and each can be answered exactly before any model is trained. Does a correct final answer certify the reasoning that produced it? Does agreement of local representations on their overlaps certify a derivation? And how complete must the checker be? Sections 3 to 5 answer them for adjustment derivations, the simplest identification operation that ADC uses.

## 1.1 Related work

DeepSeek-R1 showed that reasoning ability obtained by large-scale reinforcement learning can be transferred to smaller dense models by supervised fine-tuning on generated reasoning samples (DeepSeek-AI, 2025). GRPO, which estimates advantages from groups of sampled outputs instead of a learned value function, was introduced with DeepSeekMath (Shao et al., 2024); PPO is its predecessor (Schulman et al., 2017). The student does not need either optimiser to learn from the teacher's outputs.

Self-taught reasoning filters generated rationales by the correctness of their final answers (Zelikman et al., 2022). Outcome supervision of this kind can raise final-answer accuracy while leaving reasoning errors (Uesato et al., 2022), and step-level process supervision outperformed outcome supervision on difficult mathematics (Lightman et al., 2024). Reported reasoning is also not a reliable account of the computation: models often fail to mention influences that changed their answers (Turpin et al., 2023; Chen et al., 2025). ADC can replace learned step judgements by exact checkers wherever an operation is formally typed.

Coconut trains a model to reason in a continuous latent space by progressively replacing language reasoning steps with continuous thoughts, training on the remaining text without asking each thought to reconstruct the omitted words (Hao et al., 2024). The present proposal adds decodable, certified checkpoints to that curriculum. Interchange interventions offer one way to test whether latent states realise a declared causal computation (Geiger et al., 2021).

Adjustment is classical (Pearl, 1995, 2009). The adjustment criterion of Shpitser, VanderWeele and Robins (2010) is complete for single-action adjustment in DAGs, and Perković et al. (2015) give a complete generalisation. Learning from one's own corrected rollouts is the setting of dataset aggregation (Ross et al., 2011). ADC supplies the typed derivations, exact rule checks and failure records used here (Ghosh, 2026a); its predecessor separates mechanism contexts, clocks and interval dependencies (Ghosh, 2026b).

## 1.2 Contribution and status

The contribution is the verification layer of the teacher-to-latent pipeline and an exact measurement of why each component is needed. Propositions 3.1 to 4.3 are elementary; their value lies in what they rule out. The numerical study is exhaustive over a stated graph family and random over model parameters. The latent-training curriculum of Section 6 is a proposal: no student model is trained, and its predictions are stated with outcomes that would contradict them.

# 2 Transition records

**Definition 2.1 (transition record).** A record is a tuple

$$r=(\\kappa,\\ s,\\ o,\\ s',\\ c,\\ \\sigma),\\quad\\quad\\text{{(1)}}$$

where $\\kappa$ is the authoritative problem context (graph, observational law, query, units and intervention assumptions), $s$ the current derivation state, $o$ a typed operation, $s'$ the claimed result, $c$ a certificate or failure record, and $\\sigma\\in\\{{\\text{{verified}},\\ \\text{{refuted}},\\ \\text{{unverified}}\\}}$ its status. A claim without an available checker keeps the status unverified. It is never promoted by agreement with the final answer.

For an adjustment derivation of $P(Y=1\\mid do(X=x))$ the operations are: select a set $Z$, with a graph premise; compute $T_0=P(x,z)$, $T_1=P(z)$ and $T_2=P(Y=1\\mid x,z)$ from the observational law; and sum

$$\\hat\\tau=\\sum_z T_2(z)\\,T_1(z).\\quad\\quad\\text{{(2)}}$$

A teacher sentence such as "adjust for the confounder" becomes a selection record. Its certificate is the adjustment criterion evaluated on the declared graph, and the following arithmetic records are checked exactly against the declared law.

**Definition 2.2 (checkers).** For a derivation with answer $\\hat\\tau$ and true interventional value $\\tau$ we compare four checks.

1. *Exact answer:* $\\hat\\tau=\\tau$.
2. *Rounded answer:* $\\hat\\tau$ and $\\tau$ agree when both are rounded to two decimals.
3. *Overlap residual:* the local tables agree on their declared overlap, $\\sum_x T_0(x,z)=T_1(z)$ for every $z$, and $\\sum_z T_1(z)=1$.
4. *Transition certificate:* the set satisfies the complete adjustment criterion, every table equals its exact recomputation from the law, and (2) holds exactly.

The first two are outcome checks. The third is the sheaf-style agreement that the latent objective would encourage. The fourth is the record-level certificate.

# 3 Why a correct answer does not certify a derivation

**Proposition 3.1 (precision of answer filtering).** Suppose every valid trace is accepted, an invalid trace is accepted with probability $c$, and a trace is valid with probability $v$. Then the probability that an accepted trace is valid is

$$\\pi=\\frac{{v}}{{v+(1-v)c}}.\\quad\\quad\\text{{(3)}}$$

If each of $L$ steps is independently wrong with probability $\\varepsilon$, then $v=(1-\\varepsilon)^L$ and $\\pi\\to0$ as $L\\to\\infty$ for every fixed $c>0$.

*Proof.* Bayes' rule gives (3). With $v=(1-\\varepsilon)^L\\to0$, the numerator vanishes while the denominator tends to $c>0$. ∎

Long traces are exactly where the risk grows. Equation (3) needs $c$, which depends on the problem family and on how answers are compared; Section 5 measures it.

**Proposition 3.2 (exact agreement has measure zero, rounded agreement does not).** For a fixed DAG and an invalid adjustment set $Z$, the difference $\\hat\\tau-\\tau$ is a rational function of the conditional probability tables that is not identically zero. Its zero set has Lebesgue measure zero, but the set on which the rounded values agree has positive measure whenever it is nonempty.

*Proof.* Completeness of the adjustment criterion gives a model in which the difference is nonzero, so the rational function is not identically zero, and its zero set is a proper algebraic subset of the parameter cube. Agreement after rounding holds on an open set around any parameter value at which $\\hat\\tau$ and $\\tau$ lie strictly inside the same rounding cell. ∎

The measure-zero statement says little about data built from round numbers. Problems written with probabilities in tenths sit on a coarse grid, where ties between conditional probabilities create exact numerical independences. Section 5 shows the consequence.

# 4 What overlap agreement and certificates establish

**Proposition 4.1 (overlap agreement is blind to the choice of set).** Let all local tables of an adjustment derivation be computed correctly from one observational law. They agree on every declared overlap, whether or not $Z$ is a valid adjustment set.

*Proof.* $T_0$ and $T_1$ are marginals of the same joint law, so marginalising $T_0$ over $x$ gives $T_1$, and $T_1$ sums to one. The validity of $Z$ concerns the causal graph, which does not enter these equalities. ∎

A latent overlap residual of zero therefore cannot teach the student to avoid an invalid adjustment. It detects local inconsistency, such as an arithmetic slip that changes $T_1$ without changing $T_0$. It cannot detect a consistent computation of the wrong quantity.

**Proposition 4.2 (soundness of the transition certificate).** If the certificate accepts a derivation and the observational law is positive, then $\\hat\\tau=P(Y=1\\mid do(X=x))$ in every model compatible with the graph that induces that law.

*Proof.* A set satisfying the adjustment criterion makes (2) equal to the interventional probability in every compatible model (Shpitser et al., 2010). Exact equality of every table and of the sum then transfers that identity to the computed answer. ∎

The converse direction is deliberate. A derivation through an invalid set can be numerically right in one model, and the certificate still rejects it, because a record is meant to teach an operation that is correct for every compatible model.

**Proposition 4.3 (valid alternatives agree).** All valid adjustment sets for the same query give identical values of (2). An exact disagreement between two derivations that both claim validity refutes at least one of them.

*Proof.* Each equals the same interventional probability by Proposition 4.2. ∎

Alternative derivations are therefore both training targets and cross-checks. Their costs differ: the number of strata in (2) is $2^{{|Z|}}$ for binary events.

# 5 Exact study

## 5.1 Design

The family contains all {num(I(f'{U}_family',0))} DAGs on five labelled events whose edges respect the labelling. Each graph receives three random positive binary models. Every conditional probability $P(V_i=1\\mid \\text{{parents}})$ is drawn uniformly from a grid: tenths $\\{{1/10,\\ldots,9/10\\}}$ in one regime, mimicking textbook problems, and hundredths $\\{{1/100,\\ldots,99/100\\}}$ in the other. Queries are $P(Y=1\\mid do(X=x))$ for every ordered pair in which $X$ is an ancestor of $Y$ and for both action values, {num(Q)} queries per regime. For each query every subset of the other three events is a candidate adjustment set, and its derivation is computed exactly with rational arithmetic. Truth comes from mechanism replacement. Validity follows the complete adjustment criterion: no member on, or descending from, a proper causal path, and every proper non-causal path blocked (Shpitser et al., 2010; Perković et al., 2015).

For the checker study each query's honest derivation uses its smallest valid set. Five corruptions are applied separately:

- every invalid set, computed honestly;
- a slip of $0.01$ in $T_2$ at the heaviest stratum, propagated to the answer;
- $0.01$ of mass moved between two strata of $T_1$;
- $X$ dropped from the conditioning set of $T_2$;
- a slip of $0.01$ in the final sum.

The C# kernel uses immutable records and exact rationals. A Python program recomputes every line with fractions, an independent path-enumeration form of the adjustment and back-door criteria, and a bit-exact replay of the random streams. All {val['lines']} lines agree.

## 5.2 Answers do not certify derivations

Every one of the {num(NV)} valid sets reproduced the true effect exactly. The {num(NI)} invalid sets did not, but many came close (Table 1, Figure 1b).

CAPTION: Table 1 Invalid adjustment sets judged by their answers

| Parameters | Invalid sets | Exact match | Match to 2 decimals | Error ≤ 0.01 | Error ≤ 0.05 | Queries with some invalid set matching to 2 decimals |
|:--|:--|:--|:--|:--|:--|:--|
{inv_row(T)}
{inv_row(U)}

With textbook parameters, {pct(I(f'{T}_invalid_sets',1), I(f'{T}_invalid_sets',0))} of invalid sets gave exactly the right number, and the naive conditional $P(Y=1\\mid x)$ was exactly right in {pct(I(f'{T}_naive_conditional',1), I(f'{T}_naive_conditional',0))} of the queries that needed adjustment. On the finer grid these rates fell to {pct(I(f'{U}_invalid_sets',1), NI)} and {pct(I(f'{U}_naive_conditional',1), I(f'{U}_naive_conditional',0))}, consistent with Proposition 3.2: coarse grids produce ties between conditional probabilities and hence numerical independences. Agreement to two decimals hardly depended on the grid. In more than half of the queries that admit an invalid set, at least one invalid derivation would pass a two-decimal answer check.

The magnitudes are family dependent. Random tables produce modest confounding biases. Problems designed with strong confounding would produce fewer coincidences, and problems near independence more. The structural point does not depend on the family: an answer check accepts invalid derivations at a rate that must be measured, never assumed to be zero.

## 5.3 What each check catches

Table 2 gives the share of derivations each check accepts in the hundredths regime. The tenths regime is qualitatively identical.

CAPTION: Table 2 Acceptance by four checks (hundredths regime)

| Derivation | Cases | Exact answer | Answer to 2 decimals | Overlap residual | Transition certificate |
|:--|:--|:--|:--|:--|:--|
{chr(10).join(chk_rows)}

The certificate accepted every honest derivation and rejected every invalid set and every slip. The overlap residual accepted every invalid set, every slip in $T_2$, every dropped condition and every slip in the final sum, exactly as Proposition 4.1 predicts; it caught only the slip that breaks marginal consistency. A two-decimal answer check accepted {pct(slipz_u[2], slipz_u[0])} of those marginal slips, because moving $0.01$ of mass between strata with similar outcome rates barely changes the sum.

The certificate accepted {num(drop_u[4])} dropped-condition derivations ({num(drop_t[4])} with tenths). These are not checker errors. In each case $P(Y=1\\mid z)=P(Y=1\\mid x,z)$ held exactly in the model, so the table the teacher wrote down was numerically the required table. A record that stores the operation together with its graph premise distinguishes this from a valid derivation; a record that stores only the numbers does not.

FIGURE: fig/checks_and_errors.png|Figure 1 Acceptance by four checks, and how close invalid adjustment sets come to the true effect|Left: acceptance shares by derivation type and check, hundredths regime. Right: cumulative distribution of the absolute error of invalid adjustment sets in both regimes, with reference lines at 0.005, 0.01 and 0.05.

## 5.4 Checker completeness and alternative derivations

The back-door criterion is sound but not complete for adjustment. Of the {num(NV)} valid sets, {num(nb)} ({pct(nb, NV)}) failed the back-door test; they contain descendants of $X$ that lie off every causal path. No back-door set was invalid. A back-door-only checker would therefore label more than a fifth of the valid derivations as errors and teach the student to reject them.

Valid alternatives were common. The number of valid sets per query was one in {num(hist[1])} queries, two in {num(hist[2])}, four in {num(hist[4])} and eight in {num(hist[8])}. In {num(multi)} queries ({pct(multi, Q)}) at least two valid derivations existed, and in every one of them all valid derivations agreed exactly, as Proposition 4.3 requires. Their costs differed: the largest valid set used on average {D(f'{U}_alternative_derivations',2):.2f} times as many strata as the smallest, and up to {int(D(f'{U}_alternative_derivations',3))} times.

## 5.5 Consequences for answer-filtered data

Taking the measured two-decimal acceptance rate of invalid sets, $c={c_meas:.3f}$, as the acceptance probability of an invalid trace, Proposition 3.1 gives the share of valid traces among those accepted by answer filtering (Table 3). This transfer is a model assumption: real traces fail in many ways, and $c$ differs for each.

CAPTION: Table 3 Valid share of answer-filtered traces, with c measured in Section 5.2

| Steps L | Step error 0.01 | Step error 0.02 | Step error 0.05 |
|:--|:--|:--|:--|
{chr(10).join(prec_rows)}

At forty steps and a 5% step error, only about a third of the accepted traces would be valid. Step-level certificates remove this dependence on $c$ for every operation that has a checker.

# 6 From verified records to latent computation

This section is a proposal. It specifies how the verified records would train ADC, and what would show the approach to be wrong.

## 6.1 What each kind of teacher material trains

CAPTION: Table 4 Teacher material and its training use

| Teacher-derived material | Training use in ADC | Check that admits it |
|:--|:--|:--|
| Valid operation sequences | Select the next operation or tool | Transition certificate for each step |
| Verified intermediate claims | Train decoders that test what a latent state represents | Exact recomputation of the claim |
| Alternative valid derivations | Learn several solution paths and their costs | Exact agreement of their answers (Proposition 4.3) |
| Incorrect steps with checked diagnoses | Learn rejection, repair and qualified failure | Certificate failure with its reason |
| Final answers and certificates | Train answer generation and certificate production | The full derivation certificate |

Steps without a checker remain unverified records. They may serve as context, but not as supervised targets.

## 6.2 Objective

For a record set $\\mathcal R$ the student minimises

$$\\mathcal L=\\mathcal L_{{op}}+\\lambda_d\\mathcal L_{{dec}}+\\lambda_o\\sum_{{i,j}}\\big\\|\\rho_{{i,ij}}(z_i)-\\rho_{{j,ij}}(z_j)\\big\\|^2+\\lambda_a\\mathcal L_{{ans}},\\quad\\quad\\text{{(4)}}$$

where $\\mathcal L_{{op}}$ is the cross-entropy of the certified next operation, $\\mathcal L_{{dec}}$ the decoding loss of verified claims from separator checkpoints, the third term the overlap residual after coordinates and units are aligned, and $\\mathcal L_{{ans}}$ the loss of certified answers and certificates. By Proposition 4.1 the overlap term is a regulariser, not a correctness signal. Correctness enters only through records admitted by certificates, and the exact certificate is still run at inference.

## 6.3 Curriculum and information availability

Training starts from explicit verified steps. Stage $k$ removes the first $k$ verbal steps of each derivation and requires the latent computation to support the remaining steps, the checkpoint decoders and the certified answer, following Coconut's progressive replacement (Hao et al., 2024). Two constraints are added:

- The input at a checkpoint may contain only information available at that point of the derivation. This is the prefix condition of nonanticipation, and teacher activations are not required.
- Reasoning-step order, physical event time and layer depth remain separate indices, as in ADC and its predecessor.

After supervised training, the student's own rollouts are checked by the same certificates and added as records, so that errors occurring along its own trajectories are corrected (Ross et al., 2011).

## 6.4 Falsifiable predictions

**D1 (step certificates beat answer filtering).** On held-out causal structures, a student trained on certificate-admitted records will select invalid adjustment sets at most half as often as one trained on the same number of two-decimal answer-filtered traces from the same teacher. A confidence interval for the ratio lying entirely above 0.5 contradicts the prediction; one crossing 0.5 is inconclusive.

**D2 (decodable checkpoints survive step removal).** After removing half of the verbal steps, linear decoders at separator checkpoints will recover the certified intermediate tables of held-out queries with mean absolute error below 0.01. Correct final answers combined with undecodable checkpoints would contradict the prediction and indicate a shortcut.

**D3 (complete checkers matter).** A student trained with a back-door-only checker will reject valid non-back-door sets on held-out queries at least twice as often as one trained with the complete criterion. A ratio interval entirely below 2 contradicts the prediction.

None of these has been run. Propositions 3.1 to 4.3 and the measurements of Section 5 do not depend on their outcomes.

# 7 Limitations

The exact study covers adjustment derivations on five-event DAGs with binary events. ADC's other operations — do-calculus rules, district factorisation, the ID recursion, clock certificates and credal bounds — have exact checkers in the ADC kernel, but their corruption rates were not measured here. The coincidence rates depend on the parameter distribution, and the transfer of $c$ to whole traces in Table 3 is a model. No teacher model was queried, and no student was trained. The conversion of free text into typed records, including the parsing of operations and the detection of unstated influences, is itself an error source that the certificates check but do not remove.

# 8 Conclusion

Long reasoning traces are useful to ADC as a source of candidate operations, not as text to imitate. Each candidate becomes useful only after a certificate admits it. The exact study shows that final-answer checks admit many invalid derivations, that overlap agreement admits every consistently computed wrong quantity, and that a sound but incomplete checker rejects many valid ones. A complete, exact transition certificate admitted every honest derivation and no corrupted one. The proposed latent curriculum can then aim at a well-defined target: operations certified for every compatible model, intermediate facts that can be decoded and checked, and answers accompanied by their certificates.

# Appendix A Reproduction

The kernel targets .NET 8 without third-party packages and reuses the exact rational, random-stream and graph routines of the ADC kernel. `Distill.cs` holds the binary DAG models, both adjustment criteria, typed derivations and the four checkers; `Program.cs` runs both parameter regimes with seeds 20261031001 and 20261031002. The validator `validate.py` recomputes all {val['lines']} summary lines independently and passed all {len(val['checks'])} checks. The verified environment was .NET SDK 8.0.131, Python 3.13.16 and NumPy 2.5.3. The core of the kernel follows.

**Distill.cs**

```csharp
{open(os.path.join(H, "kernel", "Distill.cs"), encoding="utf-8").read().rstrip()}
```

# References

Chen, Y., et al. (2025). *Reasoning models don't always say what they think*. arXiv:2505.05410. https://arxiv.org/abs/2505.05410

DeepSeek-AI. (2025). *DeepSeek-R1: Incentivizing reasoning capability in LLMs via reinforcement learning*. arXiv:2501.12948. https://arxiv.org/abs/2501.12948

Geiger, A., Lu, H., Icard, T., & Potts, C. (2021). Causal abstractions of neural networks. *Advances in Neural Information Processing Systems, 34*. https://papers.nips.cc/paper/2021/hash/4f5c422f4d49a5a807eda27434231040-Abstract.html

Ghosh, D. P. (2026a). *Autoregressive Do Calculus (ADC): Clock certificates and credal precision for event generators* (Version 2, 30 October 2026).

Ghosh, D. P. (2026b). *Temporal causal reasoning in horizontal sheaf topology* (Version 2, 30 October 2026).

Hao, S., Sukhbaatar, S., Su, D., Li, X., Hu, Z., Weston, J., & Tian, Y. (2024). *Training large language models to reason in a continuous latent space*. arXiv:2412.06769. https://arxiv.org/abs/2412.06769

Lightman, H., Kosaraju, V., Burda, Y., Edwards, H., Baker, B., Lee, T., Leike, J., Schulman, J., Sutskever, I., & Cobbe, K. (2024). Let's verify step by step. *International Conference on Learning Representations*. https://proceedings.iclr.cc/paper_files/paper/2024/hash/aca97732e30bcf1303bc22ac3924fd16-Abstract-Conference.html

Pearl, J. (1995). Causal diagrams for empirical research. *Biometrika, 82*(4), 669–688. https://doi.org/10.1093/biomet/82.4.669

Pearl, J. (2009). *Causality: Models, reasoning, and inference* (2nd ed.). Cambridge University Press.

Perković, E., Textor, J., Kalisch, M., & Maathuis, M. H. (2015). A complete generalized adjustment criterion. *Proceedings of the 31st Conference on Uncertainty in Artificial Intelligence*. arXiv:1507.01524. https://arxiv.org/abs/1507.01524

Ross, S., Gordon, G., & Bagnell, D. (2011). A reduction of imitation learning and structured prediction to no-regret online learning. *Proceedings of the 14th International Conference on Artificial Intelligence and Statistics*, 627–635.

Schulman, J., Wolski, F., Dhariwal, P., Radford, A., & Klimov, O. (2017). *Proximal policy optimization algorithms*. arXiv:1707.06347. https://arxiv.org/abs/1707.06347

Shao, Z., et al. (2024). *DeepSeekMath: Pushing the limits of mathematical reasoning in open language models*. arXiv:2402.03300. https://arxiv.org/abs/2402.03300

Shpitser, I., VanderWeele, T., & Robins, J. M. (2010). On the validity of covariate adjustment for estimating causal effects. *Proceedings of the 26th Conference on Uncertainty in Artificial Intelligence*. https://proceedings.mlr.press/r8/shpitser10a.html

Turpin, M., Michael, J., Perez, E., & Bowman, S. R. (2023). Language models don't always say what they think: Unfaithful explanations in chain-of-thought prompting. *Advances in Neural Information Processing Systems, 36*.

Uesato, J., Kushman, N., Kumar, R., Song, F., Siegel, N., Wang, L., Creswell, A., Irving, G., & Higgins, I. (2022). *Solving math word problems with process- and outcome-based feedback*. arXiv:2211.14275. https://arxiv.org/abs/2211.14275

Zelikman, E., Wu, Y., Mu, J., & Goodman, N. D. (2022). STaR: Bootstrapping reasoning with reasoning. *Advances in Neural Information Processing Systems, 35*. https://proceedings.neurips.cc/paper_files/paper/2022/hash/639a9a172c044fbb64175b5fad42e9a5-Abstract-Conference.html
"""
# explicit list markers: the series reference document carries no list numbering definitions
MD = re.sub(r"(?m)^- (.*)$", lambda m: "\u2022\u00a0" + m.group(1) + "\n", MD)
MD = re.sub(r"(?m)^(\d+)\. (.*)$", lambda m: "(" + m.group(1) + ")\u00a0" + m.group(2) + "\n", MD)
open(os.path.join(H, "paper.md"), "w", encoding="utf-8").write(MD)
subprocess.run(["pandoc", "paper.md", "-f", "markdown+tex_math_dollars-auto_identifiers-fancy_lists", "-o", "raw.docx", f"--reference-doc={REF}", "--no-highlight"], cwd=H, check=True)

doc = Document(os.path.join(H, "raw.docx")); body = doc.element.body
WNS = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'

def style_table(tbl, widths):
    tp = tbl.find(qn("w:tblPr"))
    for ch in list(tp): tp.remove(ch)
    for ch in etree.fromstring(f'<w:tblPr {WNS}><w:tblW w:w="9648" w:type="dxa"/><w:jc w:val="center"/><w:tblBorders>' +
                               "".join(f'<w:{s} w:val="single" w:sz="4" w:color="D9D9D9"/>' for s in ("top", "left", "bottom", "right", "insideH", "insideV")) +
                               '</w:tblBorders><w:tblLayout w:type="fixed"/></w:tblPr>'): tp.append(ch)
    grid = tbl.find(qn("w:tblGrid"))
    for gc, w in zip(grid.findall(qn("w:gridCol")), widths): gc.set(qn("w:w"), str(w))
    for ri, tr in enumerate(tbl.findall(qn("w:tr"))):
        trpr = tr.find(qn("w:trPr"))
        if trpr is None: trpr = OxmlElement("w:trPr"); tr.insert(0, trpr)
        for ch in list(trpr): trpr.remove(ch)
        trpr.append(OxmlElement("w:cantSplit"))
        if ri == 0: trpr.append(OxmlElement("w:tblHeader"))
        for tc, w in zip(tr.findall(qn("w:tc")), widths):
            tcpr = tc.find(qn("w:tcPr"))
            if tcpr is None: tcpr = OxmlElement("w:tcPr"); tc.insert(0, tcpr)
            for ch in list(tcpr): tcpr.remove(ch)
            fill = "EDF0F2" if ri == 0 else "FFFFFF"
            for ch in etree.fromstring(f'<w:tcPr {WNS}><w:tcW w:w="{w}" w:type="dxa"/><w:shd w:val="clear" w:fill="{fill}"/><w:tcMar><w:top w:w="85" w:type="dxa"/>'
                                       '<w:left w:w="85" w:type="dxa"/><w:bottom w:w="85" w:type="dxa"/><w:right w:w="85" w:type="dxa"/></w:tcMar><w:vAlign w:val="center"/></w:tcPr>'): tcpr.append(ch)
            for p in tc.findall(qn("w:p")):
                ppr = p.find(qn("w:pPr"))
                if ppr is None: ppr = OxmlElement("w:pPr"); p.insert(0, ppr)
                for ch in list(ppr): ppr.remove(ch)
                for ch in etree.fromstring(f'<w:pPr {WNS}><w:pStyle w:val="BodyText"/><w:keepNext w:val="0"/><w:spacing w:before="0" w:after="30" w:line="252" w:lineRule="auto"/><w:jc w:val="left"/></w:pPr>'): ppr.append(ch)
                for r in p.findall(qn("w:r")):
                    rpr = r.find(qn("w:rPr"))
                    if rpr is None: rpr = OxmlElement("w:rPr"); r.insert(0, rpr)
                    for x in rpr.findall(qn("w:b")): rpr.remove(x)
                    b = OxmlElement("w:b")
                    if ri != 0: b.set(qn("w:val"), "0")
                    rpr.insert(0, b)
                    if rpr.find(qn("w:sz")) is None: sz = OxmlElement("w:sz"); sz.set(qn("w:val"), "20"); rpr.append(sz)

def make_caption(text, keep):
    p = OxmlElement("w:p"); ppr = OxmlElement("w:pPr"); ps = OxmlElement("w:pStyle"); ps.set(qn("w:val"), "Caption"); ppr.append(ps)
    kn = OxmlElement("w:keepNext")
    if not keep: kn.set(qn("w:val"), "0")
    ppr.append(kn); p.append(ppr)
    r = OxmlElement("w:r"); t = OxmlElement("w:t"); t.text = text; t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve"); r.append(t); p.append(r)
    return p

widths = {"Table 1": [1300, 1100, 1100, 1350, 1150, 1150, 2498], "Table 2": [3000, 1000, 1300, 1400, 1400, 1548],
          "Table 3": [1800, 2616, 2616, 2616], "Table 4": [2800, 3700, 3148]}
for p in list(doc.paragraphs):
    t = p.text
    if t.startswith("CAPTION: "):
        cap = t[len("CAPTION: "):]; el = make_caption(cap, True); p._p.addprevious(el)
        tbl = p._p.getnext(); p._p.getparent().remove(p._p)
        while tbl is not None and tbl.tag != qn("w:tbl"): tbl = tbl.getnext()
        style_table(tbl, widths[cap.split(" ")[0] + " " + cap.split(" ")[1]])
    elif t.startswith("FIGURE: "):
        path, cap, alt = t[len("FIGURE: "):].split("|")
        np_ = doc.add_paragraph(style="Body Text"); np_.alignment = 1
        np_.add_run().add_picture(os.path.join(H, path), width=Inches(6.45))
        el = np_._p; el.getparent().remove(el)
        ppr = el.find(qn("w:pPr")); ppr.find(qn("w:pStyle")).addnext(OxmlElement("w:keepNext"))
        for d in el.iter("{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}docPr"): d.set("descr", alt)
        p._p.addprevious(el); p._p.addprevious(make_caption(cap, False)); p._p.getparent().remove(p._p)
for p in body.iter(qn("w:p")):                     # monospace code listing
    ppr = p.find(qn("w:pPr")); st = ppr.find(qn("w:pStyle")) if ppr is not None else None
    if st is None or st.get(qn("w:val")) != "SourceCode": continue
    for r in p.findall(qn("w:r")):
        rpr = r.find(qn("w:rPr"))
        if rpr is None: rpr = OxmlElement("w:rPr"); r.insert(0, rpr)
        for x in rpr.findall(qn("w:rFonts")) + rpr.findall(qn("w:sz")): rpr.remove(x)
        f_ = OxmlElement("w:rFonts")
        for a in ("ascii", "hAnsi", "cs"): f_.set(qn(f"w:{a}"), "Consolas")
        rs = rpr.find(qn("w:rStyle")); (rs.addnext(f_) if rs is not None else rpr.insert(0, f_))
        sz = OxmlElement("w:sz"); sz.set(qn("w:val"), "15"); rpr.append(sz)
    sp_ = ppr.find(qn("w:spacing"))
    if sp_ is None: sp_ = OxmlElement("w:spacing"); ppr.append(sp_)
    sp_.set(qn("w:before"), "0"); sp_.set(qn("w:after"), "0"); sp_.set(qn("w:line"), "228"); sp_.set(qn("w:lineRule"), "auto")
# headings of numbered H1 sections start on the flow (like ADC); the first author line uses Date-like spacing
M = "http://schemas.openxmlformats.org/officeDocument/2006/math"
def reorder(parent, order):
    kids = sorted(list(parent), key=lambda e: order.index(etree.QName(e).localname) if etree.QName(e).localname in order else 99)
    for k in kids: parent.append(k)
PPR = ("pStyle keepNext keepLines pageBreakBefore framePr widowControl numPr suppressLineNumbers pBdr shd tabs suppressAutoHyphens "
       "kinsoku wordWrap overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi adjustRightInd snapToGrid spacing ind "
       "contextualSpacing mirrorIndents suppressOverlap jc textDirection textAlignment textboxTightWrap outlineLvl divId "
       "cnfStyle rPr sectPr pPrChange").split()
for r in body.iter(f"{{{M}}}r"):                     # equation tags upright, renderable everywhere
    if re.fullmatch(r"\(\d+\)", r.findtext(f"{{{M}}}t") or ""):
        rpr = r.find(f"{{{M}}}rPr")
        if rpr is not None:
            for x in list(rpr): rpr.remove(x)
            s = etree.SubElement(rpr, f"{{{M}}}sty"); s.set(f"{{{M}}}val", "p")
for x in body.iter(qn("w:pPr")): reorder(x, PPR)
for x in body.iter(f"{{{M}}}dPr"): reorder(x, ["begChr", "sepChr", "endChr", "grow", "shp", "ctrlPr"])
for x in body.iter(f"{{{M}}}rPr"):
    if x.find(f"{{{M}}}nor") is not None:
        for s in x.findall(f"{{{M}}}sty") + x.findall(f"{{{M}}}scr"): x.remove(s)
    reorder(x, ["lit", "nor", "scr", "sty", "brk", "aln"])
for shd in body.iter(qn("w:shd")):
    if shd.get(qn("w:val")) is None: shd.set(qn("w:val"), "clear")
# references in the bibliography style of the series
refs = False
ref_tmpl = None
src = Document(REF)
for p in src.paragraphs:
    if p.style.name == "Bibliography": ref_tmpl = p._p.find(qn("w:pPr")); break
for p in doc.paragraphs:
    if p.style.name.startswith("Heading 1") and p.text == "References":
        refs = True; ppr = p._p.find(qn("w:pPr")); ppr.find(qn("w:pStyle")).addnext(OxmlElement("w:pageBreakBefore")); continue
    if refs and p.text.strip():
        old = p._p.find(qn("w:pPr"))
        if old is not None: p._p.remove(old)
        p._p.insert(0, copy.deepcopy(ref_tmpl))
for p in doc.paragraphs:
    if p.style.name.startswith("Heading 1") and p.text.startswith("Appendix A"):
        p._p.find(qn("w:pPr")).find(qn("w:pStyle")).addnext(OxmlElement("w:pageBreakBefore"))
cp = doc.core_properties; cp.title = "From Teacher Traces to Verified Transitions"; cp.author = "Debi Prasad Ghosh"
cp.subject = "How long reasoning tokens can train Autoregressive Do Calculus"
for x in body.iter(qn("w:pPr")): reorder(x, PPR)
doc.save(OUT)
ORDER = ("writeProtection view zoom removePersonalInformation removeDateAndTime doNotDisplayPageBoundaries displayBackgroundShape "
         "printPostScriptOverText printFractionalCharacterWidth printFormsData embedTrueTypeFonts embedSystemFonts saveSubsetFonts "
         "saveFormsData mirrorMargins alignBordersAndEdges bordersDoNotSurroundHeader bordersDoNotSurroundFooter gutterAtTop "
         "hideSpellingErrors hideGrammaticalErrors activeWritingStyle proofState formsDesign attachedTemplate linkStyles "
         "stylePaneFormatFilter stylePaneSortMethod documentType mailMerge revisionView trackRevisions doNotTrackMoves "
         "doNotTrackFormatting documentProtection autoFormatOverride styleLockTheme styleLockQFSet defaultTabStop autoHyphenation "
         "consecutiveHyphenLimit hyphenationZone doNotHyphenateCaps showEnvelope summaryLength clickAndTypeStyle defaultTableStyle "
         "evenAndOddHeaders bookFoldRevPrinting bookFoldPrinting bookFoldPrintingSheets drawingGridHorizontalSpacing "
         "drawingGridVerticalSpacing displayHorizontalDrawingGridEvery displayVerticalDrawingGridEvery "
         "doNotUseMarginsForDrawingGridOrigin drawingGridHorizontalOrigin drawingGridVerticalOrigin doNotShadeFormData "
         "noPunctuationKerning characterSpacingControl printTwoOnOne strictFirstAndLastChars noLineBreaksAfter noLineBreaksBefore "
         "savePreviewPicture doNotValidateAgainstSchema saveInvalidXml ignoreMixedContent alwaysShowPlaceholderText "
         "doNotDemarcateInvalidXml saveXmlDataOnly useXSLTWhenSaving saveThroughXslt showXMLTags alwaysMergeEmptyNamespace "
         "updateFields hdrShapeDefaults footnotePr endnotePr compat docVars rsids mathPr attachedSchema themeFontLang "
         "clrSchemeMapping doNotIncludeSubdocsInStats doNotAutoCompressPictures forceUpgrade captions readModeInkLockDown "
         "smartTagType schemaLibrary shapeDefaults doNotEmbedSmartTags decimalSymbol listSeparator").split()
tmp = OUT + ".tmp"
with zipfile.ZipFile(OUT) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
    for item in zin.infolist():
        data = zin.read(item.filename)
        if item.filename == "word/settings.xml":
            root = etree.fromstring(data)
            for k in sorted(list(root), key=lambda e: ORDER.index(etree.QName(e).localname) if etree.QName(e).localname in ORDER else len(ORDER)): root.append(k)
            W_ = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
            for z in root.findall(W_ + "zoom"):
                if z.get(W_ + "percent") is None: z.set(W_ + "percent", "100")
            data = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
        if item.filename == "word/numbering.xml":
            data = re.sub(rb'(<w:nsid w:val=")([0-9A-Fa-f]{1,7})(")', lambda m: m.group(1) + m.group(2).rjust(8, b"0") + m.group(3), data)
        zout.writestr(item, data)
shutil.move(tmp, OUT); os.remove(os.path.join(H, "raw.docx"))
print("saved", OUT)
