# Operation Certificates for Latent Causal Reasoning — Version 3

Version 3 · 31 October 2026 · Debi Prasad Ghosh

Version 3 recompiles the immutable C# kernel and adds an exhaustive operation census over the inherited
6,144 models (1,024 fixed-order five-event DAGs × 3 models × 2 parameter grids).

## New content
- Proposition 7.5: the dropped action is never graph-licensed in an adjustment derivation.
- Proposition 7.6: unlicensed condition deletion is non-generic (via Meek, 1995).
- Proposition 8.7: exact interval enclosure of an adjustment sum from decoded tables, with width bound (15).
- Proposition 9.4: exact weighted repair of the table audit, eq. (16); shares 2α/(2α+1) and 1/(2α+1) sum to one.
- Sections 13.2–13.7, Tables 9–12, Figure 4: census results.

## Files
- `kernel/` — C# project; `OpCensus.cs` is new, `Program.cs` gains the `--v3` entry point.
- `cs_out_rerun.txt`, `out/` — inherited census re-run; byte-identical to the Version 1 outputs.
- `cs_v3.txt` — 36 Version 3 census records.
- `validate_v3.py`, `validation_v3.json`, `validate_v3.log` — independent Python validation (48 checks, all pass).
- `fig_v3.py`, `fig/v3_licence_and_precision.{png,svg}` — Figure 4.
- `build_v3.py` — edits the Version 2 Word file into Version 3.
- `inherited_v2/` — the Version 2 source bundle as recovered.

## Reproduce
    dotnet run -c Release --project kernel -- out
    dotnet run -c Release --project kernel -- out_v3 --v3 > cs_v3.txt
    python validate_v3.py cs_v3.txt validation_v3.json
    python fig_v3.py
    python build_v3.py      # needs Pandoc and the Version 2 docx at ../in/v2.docx

## Note on the supplied Version 2 archive
The supplied Version 2 sources ZIP has no central directory. Its 36 local entries were recovered intact.
The README lists files that were not in the archive, including `paper.md`, `transition_reference.py` and
`validate_v2.py`, so Version 3 edits the delivered Version 2 Word file directly.

## Limits
Single action, single binary outcome, five events in one order, three models per graph. No teacher was
queried, no student trained and no biological data collected.
