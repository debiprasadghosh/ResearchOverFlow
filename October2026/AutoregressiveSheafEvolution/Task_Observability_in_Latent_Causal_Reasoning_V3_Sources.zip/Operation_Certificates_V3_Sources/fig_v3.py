"""Figure 4 of Version 3, drawn from the validated C# output cs_v3.txt."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

H = Path(__file__).resolve().parent
cs = {l.split("\t")[0]: list(map(float, l.rstrip("\n").split("\t")[1].split())) for l in open(H / "cs_v3.txt")}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.titlesize": 11, "axes.labelsize": 10,
                     "axes.spines.top": False, "axes.spines.right": False, "savefig.facecolor": "white"})
COL = {"tenths": "#a95235", "hundredths": "#336982"}; LAB = {"tenths": "Tenths grid", "hundredths": "Hundredths grid"}
fig, ax = plt.subplots(1, 2, figsize=(9.4, 3.7), layout="constrained")
kinds = ["deletion", "rule1", "rule2", "rule3"]; names = ["Condition\ndeletion", "Rule 1", "Rule 2", "Rule 3"]
x = np.arange(len(kinds)); w = 0.36
for i, tag in enumerate(["tenths", "hundredths"]):
    v = [100 * cs[f"{tag}_census_{k}"][6] / cs[f"{tag}_census_{k}"][5] for k in kinds]
    bars = ax[0].bar(x + (i - 0.5) * w, v, w * 0.92, color=COL[tag], label=LAB[tag])
    for b, val in zip(bars, v): ax[0].text(b.get_x() + b.get_width() / 2, val + 0.12, f"{val:.1f}", ha="center", fontsize=8)
ax[0].set_xticks(x, names); ax[0].set_ylabel("Unlicensed instances exactly equal (%)")
ax[0].set_ylim(0, 7.8); ax[0].legend(frameon=False, fontsize=8, loc="upper right")
ax[0].set_title("A  Equal values without a licence")
hs = [("d2_threshold", 0.01), ("dec2", 0.005), ("dec3", 0.0005), ("dec4", 0.00005)]
for tag in ["tenths", "hundredths"]:
    y = [100 * cs[f"{tag}_precision_{lab}"][5] / cs[f"{tag}_precision_{lab}"][4] for lab, _ in hs]
    ax[1].plot([h for _, h in hs], y, marker="o", ms=6, lw=2, color=COL[tag], label=LAB[tag])
    for (_, h), val in zip(hs, y): ax[1].text(h * (0.86 if tag == "hundredths" else 1.12), val + (1.6 if tag == "hundredths" else -3.8), f"{val:.1f}", ha="left" if tag == "hundredths" else "right", fontsize=8, color=COL[tag])
ax[1].set_xscale("log"); ax[1].set_xlim(0.018, 3.2e-5); ax[1].set_ylim(0, 56)
ax[1].set_xlabel("Decoded table precision h"); ax[1].set_ylabel("Wrong answers inside enclosure (%)")
ax[1].axvline(0.01, color="#677780", lw=0.8, ls=":"); ax[1].text(0.0092, 3, "D2 threshold", fontsize=8, color="#677780", ha="left")
ax[1].legend(frameon=False, fontsize=8, loc="upper right"); ax[1].set_title("B  Value checks need precision")
(H / "fig").mkdir(exist_ok=True)
fig.savefig(H / "fig/v3_licence_and_precision.png", dpi=240); fig.savefig(H / "fig/v3_licence_and_precision.svg"); plt.close(fig)
