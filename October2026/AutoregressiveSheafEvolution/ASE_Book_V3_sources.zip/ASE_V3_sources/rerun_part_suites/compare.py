"""Compare freshly generated result files of all six parts with the recorded ones, leaf by leaf."""
import json, math, os
H = os.path.dirname(os.path.abspath(__file__))


def leaves(x, path=""):
    if isinstance(x, dict):
        for k, v in x.items(): yield from leaves(v, f"{path}/{k}")
    elif isinstance(x, list):
        for i, v in enumerate(x): yield from leaves(v, f"{path}[{i}]")
    else:
        yield path, x


report = {}
for part in ("p1", "p2", "p3", "p4", "p5", "p6"):
    for fn in sorted(os.listdir(os.path.join(H, part, "orig"))):
        new_p = os.path.join(H, part, fn)
        if not os.path.exists(new_p):
            report[f"{part}/{fn}"] = dict(missing=True); continue
        old = dict(leaves(json.load(open(os.path.join(H, part, "orig", fn)))))
        new = dict(leaves(json.load(open(new_p))))
        nums = same = 0; worst = 0.0; changed = []; timing = []
        for k in sorted(set(old) | set(new)):
            a, b = old.get(k), new.get(k)
            if isinstance(a, bool) or isinstance(b, bool) or not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
                if a != b: changed.append(k)
                continue
            if k.rsplit("/", 1)[-1] in ("seconds", "time", "elapsed"): timing.append(k); continue
            nums += 1
            if a == b or (math.isnan(a) and math.isnan(b)): same += 1; continue
            if math.isinf(a) or math.isinf(b): changed.append(k); continue
            rel = abs(a - b) / max(abs(a), 1e-300); worst = max(worst, rel); changed.append(k)
        report[f"{part}/{fn}"] = dict(numeric=nums, identical=same, max_rel=worst, changed=len(changed), timing=len(timing),
                                      examples=changed[:5])
json.dump(report, open(os.path.join(H, "compare.json"), "w"), indent=1)
for k, v in report.items():
    print(k, {a: b for a, b in v.items() if a != "examples"}, v.get("examples", [])[:3])
