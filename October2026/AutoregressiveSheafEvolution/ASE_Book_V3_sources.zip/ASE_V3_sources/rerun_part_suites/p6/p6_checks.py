"""Numerical checks and explorations for ASE Part VI: evidence and computation. Seed 20261024. Writes p6_checks.json."""
import json, math, os
import numpy as np
from scipy.stats import norm
H = os.path.dirname(os.path.abspath(__file__))
rng = np.random.default_rng(20261024)
R = {}
u = np.finfo(float).eps / 2


# 1 Proposition 2.2: stable log-sum-exp reads against naive softmax and an extended-precision reference
def read_stable(z, Y, lw, s):
    l = lw - ((Y - z) ** 2).sum(1) / (2 * s * s); l = l - l.max(); a = np.exp(l); a /= a.sum(); return a @ Y
def read_naive(z, Y, lw, s):
    with np.errstate(all="ignore"):
        a = np.exp(lw - ((Y - z) ** 2).sum(1) / (2 * s * s)); a = a / a.sum(); return a @ Y
def read_ref(z, Y, lw, s):
    Yl = Y.astype(np.longdouble); l = lw.astype(np.longdouble) - ((Yl - z) ** 2).sum(1) / (2 * np.longdouble(s) ** 2)
    l = l - l.max(); a = np.exp(l); a /= a.sum(); return (a @ Yl).astype(float)
rows = []
for s in (1.0, 0.1, 0.03, 0.01, 0.003):
    fail = 0; err = 0.0
    for t in range(500):
        Y = rng.normal(size=(50, 3)); lw = rng.normal(0, 1, 50); z = rng.normal(0, 2, 3)
        m = read_naive(z, Y, lw, s); fail += not np.all(np.isfinite(m))
        e = np.abs(read_stable(z, Y, lw, s) - read_ref(z, Y, lw, s)).max() / (1 + np.abs(Y).max()); err = max(err, float(e))
    rows.append(dict(s=s, naive_fail=fail / 500, stable_err=err))
R["c1_lse"] = rows

# 2 Proposition 2.3: truncation certificate for the read
cert = []
n, D, s = 2000, 4, 0.5
for k in (8, 32, 128, 512):
    worst = 0.0; viol = 0; shares = []
    for t in range(300):
        Y = rng.normal(size=(n, D)); lw = rng.normal(0, .5, n); z = rng.normal(0, 1.2, D)
        l = lw - ((Y - z) ** 2).sum(1) / (2 * s * s)
        d2 = ((Y - z) ** 2).sum(1); near = np.argsort(d2)[:k]; far = np.setdiff1d(np.arange(n), near)
        full = read_stable(z, Y, lw, s)
        lk = l[near]; a = np.exp(lk - lk.max()); trunc = (a / a.sum()) @ Y[near]
        # certificate: omitted log mass bounded by (n-k) * max prior weight * exp(-d_(k+1)^2 / 2s^2)
        L_kept = lk.max() + math.log(a.sum())
        L_omit_bound = math.log(n - k) + lw.max() - np.sort(d2)[k] / (2 * s * s)
        share = 1 / (1 + math.exp(L_kept - L_omit_bound))       # certified upper bound on omitted share
        diam = float(np.sqrt(((Y.max(0) - Y.min(0)) ** 2).sum()))
        bound = share * diam
        e = float(np.linalg.norm(full - trunc)); viol += e > bound + 1e-12
        shares.append(share); worst = max(worst, e / bound if bound > 0 else 0)
    cert.append(dict(k=k, cost_share=k / n, median_share=float(np.median(shares)), max_share=float(np.max(shares)),
                     violations=int(viol), max_ratio=worst))
R["c2_truncation"] = cert

# 3 Proposition 2.4: summation order and the Higham bound
worst = 0.0
for t in range(200):
    x = rng.normal(size=10_000) * np.exp(rng.normal(0, 3, 10_000))
    a = float(np.sum(x)); b = 0.0
    for v in rng.permutation(x): b += v
    c = math.fsum(x)
    nn = len(x); gamma = (nn - 1) * u / (1 - (nn - 1) * u)
    worst = max(worst, abs(b - c) / (gamma * np.abs(x).sum()))
R["c3_sum"] = dict(trials=200, max_ratio_to_bound=float(worst))

# 4 Proposition 3.1: paired sample size achieves its power
alpha, power, delta, sd = 0.05, 0.8, 0.02, 0.06
za, zb = norm.ppf(1 - alpha), norm.ppf(power)
n_req = math.ceil((za + zb) ** 2 * sd ** 2 / delta ** 2)
reps = 20000; d = rng.normal(delta, sd, (reps, n_req))
tstat = d.mean(1) / (d.std(1, ddof=1) / math.sqrt(n_req))
from scipy.stats import t as tdist
R["c4_power"] = dict(n=n_req, power=float((tstat > tdist.ppf(1 - alpha, n_req - 1)).mean()), size=float(
    ((rng.normal(0, sd, (reps, n_req)).mean(1) / (sd / math.sqrt(n_req))) > za).mean()))

# 5 Proposition 3.2: family-wise error with 72 null comparisons, naive against Holm
m = 72; reps = 20000; P = rng.random((reps, m))
naive = (P < 0.05).any(1).mean()
Ps = np.sort(P, 1); thr = 0.05 / (m - np.arange(m)); rej = np.cumprod(Ps <= thr, 1).any(1)
R["c5_holm"] = dict(m=m, naive_fwer=float(naive), holm_fwer=float(rej.mean()), naive_theory=1 - 0.95 ** m)

# 6 Proposition 3.3: selection optimism
opt = []
for m in (2, 7, 40):
    Z = rng.normal(size=(200000, m)).max(1)
    opt.append(dict(m=m, mean_max=float(Z.mean()), sqrt2log=math.sqrt(2 * math.log(m))))
R["c6_optimism"] = opt

# 7 Exploration: choosing an importance width by in-sample effective size (Part IV double well)
P4 = json.load(open(os.path.join(H, "..", "p4", "p4_checks.json")))
scan = P4["scan"]["rows"]; widths = np.array([r_["s"] for r_ in scan]); true_m2 = np.array([r_["m2"] for r_ in scan])
thr4 = P4["extras"]["threshold"]
r4 = np.random.default_rng(20261021)
Yr = r4.normal(0, 2, (40, 2))                                   # the Part IV archive, same first draw
J = lambda X: (X[:, 0] ** 2 - 1) ** 2 + 0.5 * X[:, 1] ** 2; lwY = -4 * J(Yr); lb = lwY - np.logaddexp.reduce(lwY)
def logq(X, s):
    d2 = ((X[:, None] - Yr[None]) ** 2).sum(-1)
    return np.logaddexp.reduce(lb[None] - d2 / (2 * s * s) - math.log(2 * math.pi * s * s), axis=1)
logt = lambda X: -(X ** 2).sum(1) / 8 - 4 * J(X)
sel = {}
for nn in (100, 500, 2000):
    chosen = []; insample = []; truthc = []
    for rep in range(200):
        best = None
        for s_, tm in zip(widths, true_m2):
            comp = rng.choice(40, nn, p=np.exp(lb)); X = Yr[comp] + s_ * rng.normal(size=(nn, 2))
            lw_ = logt(X) - logq(X, s_); w = np.exp(lw_ - lw_.max()); est = nn * (w ** 2).sum() / w.sum() ** 2
            if best is None or est < best[0]:
                best = (est, s_, tm)
        insample.append(best[0]); chosen.append(best[1]); truthc.append(best[2])
    chosen = np.array(chosen); truthc = np.array(truthc)
    sel[nn] = dict(below_threshold=float((chosen <= thr4).mean()), median_chosen=float(np.median(chosen)),
                   median_insample=float(np.median(insample)),
                   median_true=float(np.median(truthc)), share_true_infinite=float(np.isinf(truthc).mean()))
# held-out confirmation: estimate m2 of the chosen width on fresh draws (n = 2000) for 50 selections at n = 100
R["explore_selection"] = dict(results=sel, best_true=float(np.nanmin(true_m2)), best_true_s=float(widths[np.nanargmin(true_m2)]),
                              threshold=thr4)

json.dump(R, open(os.path.join(H, "p6_checks.json"), "w"), indent=1, default=float)
for k, v in R.items():
    print(k, json.dumps(v, default=float)[:700])
