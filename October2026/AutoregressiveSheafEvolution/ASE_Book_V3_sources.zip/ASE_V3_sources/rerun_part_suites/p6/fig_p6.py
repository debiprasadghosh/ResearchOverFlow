"""Figures of Part VI, drawn from p6_checks.json."""
import json, os
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
H = os.path.dirname(os.path.abspath(__file__)); R = json.load(open(os.path.join(H, "p6_checks.json")))
B, O, A, INK, MUT = "#2a78d6", "#eb6834", "#1baf7a", "#222222", "#6b6b6b"
plt.rcParams.update({"font.size": 8.5, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": MUT,
                     "xtick.color": MUT, "ytick.color": MUT, "axes.grid": True, "grid.color": "#e8e8e8", "grid.linewidth": .6})
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 2.8))
c1 = R["c1_lse"]; s = [r["s"] for r in c1]
a1.semilogx(s, [r["naive_fail"] for r in c1], "o-", color=O, lw=2, ms=4, label="unshifted exponentials")
a1.semilogx(s, [0] * len(s), "o-", color=B, lw=2, ms=4, label="shifted (log-sum-exp)")
a1.set_xlabel("scale $s$"); a1.set_ylabel("share of reads that fail"); a1.invert_xaxis(); a1.legend(frameon=False, fontsize=7)
a1.set_title("(a) underflow at fine scales", fontsize=8.5, color=INK)
c2 = R["c2_truncation"]; k = [r["k"] for r in c2]
a2.semilogx(k, [r["median_share"] for r in c2], "o-", color=B, lw=2, ms=4, label="certified omitted share (median)")
a2.semilogx(k, [r["max_ratio"] for r in c2], "o-", color=O, lw=2, ms=4, label="largest error / certified bound")
a2.set_xlabel("records read, $k$ of 2,000"); a2.set_ylim(0, 1.05); a2.legend(frameon=False, fontsize=7)
a2.set_title("(b) truncation certificate", fontsize=8.5, color=INK)
fig.tight_layout(); fig.savefig(os.path.join(H, "fig", "computation.png"), dpi=220); plt.close(fig)
E = R["explore_selection"]["results"]; ns = ["100", "500", "2000"]
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 2.8))
a1.bar(ns, [E[n]["share_true_infinite"] for n in ns], color=O, width=.55)
for i, n in enumerate(ns): a1.text(i, E[n]["share_true_infinite"] + .02, f'{E[n]["share_true_infinite"]:.3f}', ha="center", fontsize=7.5)
a1.set_ylim(0, 1); a1.set_xlabel("draws per width"); a1.set_ylabel("selected width has infinite $m_2$")
a1.set_title("(a) selection by in-sample effective size", fontsize=8.5, color=INK)
a2.bar(np.arange(3) - .18, [E[n]["median_insample"] for n in ns], .36, color=B, label="in-sample $\\hat m_2$ of the winner")
a2.axhline(R["explore_selection"]["best_true"], color=INK, ls="--", lw=1, label="smallest true $m_2$")
a2.set_xticks(range(3)); a2.set_xticklabels(ns); a2.set_xlabel("draws per width"); a2.set_ylabel("median")
a2.legend(frameon=False, fontsize=7); a2.set_title("(b) the winner looks better than any width is", fontsize=8.5, color=INK)
fig.tight_layout(); fig.savefig(os.path.join(H, "fig", "selection.png"), dpi=220); plt.close(fig)
print("ok")
