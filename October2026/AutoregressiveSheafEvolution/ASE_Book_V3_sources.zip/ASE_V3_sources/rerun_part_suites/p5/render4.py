"""Fill file and table placeholders, add gaps after statement tags, write paper.md."""
import json, os, re
H = os.path.dirname(os.path.abspath(__file__))
s = open(os.path.join(H, "src", "paper_src.md"), encoding="utf-8").read()
v = json.load(open(os.path.join(H, "cs_validate.json")))
SUP = str.maketrans("-0123456789", "⁻⁰¹²³⁴⁵⁶⁷⁸⁹")
def e1(x):
    if x == 0: return "identical"
    m, ex = f"{x:.1e}".split("e"); return f"{m} × 10{str(int(ex)).translate(SUP)}"
nb = lambda t: t.replace(" -", " -⁠").replace("E-", "E-⁠").replace("e-", "e-⁠")
rows = "\n".join(f"| `{nb(r['csharp'])}` | `{nb(r['python'])}` | {(e1(r['rel']) if r['rel'] < 1e-9 else 'absolute ' + e1(r['absd']))} |" for r in v["rows"])
s = s.replace("{{cs_rows}}", rows)
s = re.sub(r"\{\{file:(.+?)\}\}", lambda m: open(os.path.join(H, m[1]), encoding="utf-8").read().rstrip("\n"), s)
s = re.sub(r'(::: \{custom-style="Statement Tag"\}\n.*?\n:::\n)', r'\1\n::: {custom-style="Gap"}\n&nbsp;\n:::\n', s, flags=re.S)
assert "{{" not in s
open(os.path.join(H, "paper.md"), "w", encoding="utf-8").write(s)
print("words", len(s.split()))
