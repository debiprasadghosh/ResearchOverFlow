"""Numerical checks and explorations for ASE Part V: fusion and constraints. Seed 20261023. Writes p5_checks.json."""
import json, math, os
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
rng = np.random.default_rng(20261023)
R = {}


def spd(d, cond=10.0):
    Q, _ = np.linalg.qr(rng.normal(size=(d, d)))
    return Q @ np.diag(np.exp(rng.uniform(0, math.log(cond), d))) @ Q.T


def poe(mus, Ls):
    L = sum(Ls); return np.linalg.solve(L, sum(Lk @ m for Lk, m in zip(Ls, mus))), L


# 1 Proposition 2.2: PoE equals the normalised product of densities (pointwise log-density check)
worst = 0.0
for t in range(300):
    d = rng.integers(1, 5); k = rng.integers(2, 5)
    mus = [rng.normal(size=d) for _ in range(k)]; Ls = [spd(d) for _ in range(k)]
    m, L = poe(mus, Ls)
    xs = rng.normal(size=(3, d))
    lp = [sum(-0.5 * (x - mu) @ Lk @ (x - mu) for mu, Lk in zip(mus, Ls)) for x in xs]
    lq = [-0.5 * (x - m) @ L @ (x - m) for x in xs]
    diff = np.array(lp) - np.array(lq)                     # must be constant in x
    worst = max(worst, float(np.ptp(diff) / (1 + np.abs(diff).max())))
R["c1_poe"] = dict(cases=300, max_nonconstant=worst)

# 2 Proposition 2.3: shared evidence double counting, exact correction
d = 3; P0 = spd(d); m0 = rng.normal(size=d); Ld = spd(d); yd = rng.normal(size=d)
Lk = [spd(d) for _ in range(4)]; yk = [rng.normal(size=d) for _ in range(4)]
P0i = np.linalg.inv(P0)
exactL = P0i + Ld + sum(Lk); exact = np.linalg.solve(exactL, P0i @ m0 + Ld @ yd + sum(L @ y for L, y in zip(Lk, yk)))
experts = [(np.linalg.solve(P0i + Ld + L, P0i @ m0 + Ld @ yd + L @ y), P0i + Ld + L) for L, y in zip(Lk, yk)]
naive_m, naive_L = poe([e[0] for e in experts], [e[1] for e in experts])
shared = (np.linalg.solve(P0i + Ld, P0i @ m0 + Ld @ yd), P0i + Ld)
corr_L = naive_L - 3 * shared[1]
corr_m = np.linalg.solve(corr_L, naive_L @ naive_m - 3 * shared[1] @ shared[0])
R["c2_double"] = dict(k=4, naive_trace_ratio=float(np.trace(np.linalg.inv(naive_L)) / np.trace(np.linalg.inv(exactL))),
                      naive_mean_err=float(np.linalg.norm(naive_m - exact)),
                      corrected_err=float(max(np.abs(corr_m - exact).max(), np.abs(corr_L - exactL).max())))

# 3 Proposition 2.4: covariance intersection is consistent; naive PoE is not, under unknown correlation
rows = []; viol_ci = 0; under_naive = 0; trials = 400
for t in range(trials):
    d = 2; A = spd(d); B = spd(d)
    c = rng.uniform(-1, 1)                                # cross-correlation scale
    LA, LB = np.linalg.cholesky(A), np.linalg.cholesky(B)
    # joint error covariance [[A, Cx],[Cx^T, B]] with Cx = c * LA @ LB^T (valid for |c| < 1)
    Cx = c * LA @ LB.T
    Ai, Bi = np.linalg.inv(A), np.linalg.inv(B)
    ws = np.linspace(0.001, 0.999, 999)
    best = min(ws, key=lambda w: np.trace(np.linalg.inv(w * Ai + (1 - w) * Bi)))
    Pci = np.linalg.inv(best * Ai + (1 - best) * Bi)
    K1 = Pci @ (best * Ai); K2 = Pci @ ((1 - best) * Bi)
    true = K1 @ A @ K1.T + K2 @ B @ K2.T + K1 @ Cx @ K2.T + K2 @ Cx.T @ K1.T
    viol_ci += np.linalg.eigvalsh(Pci - true).min() < -1e-10
    Pn = np.linalg.inv(Ai + Bi); G1 = Pn @ Ai; G2 = Pn @ Bi
    truen = G1 @ A @ G1.T + G2 @ B @ G2.T + G1 @ Cx @ G2.T + G2 @ Cx.T @ G1.T
    under_naive += np.linalg.eigvalsh(Pn - truen).min() < -1e-10
    rows.append(dict(c=c, naive_ratio=float(np.trace(truen) / np.trace(Pn)), ci_ratio=float(np.trace(true) / np.trace(Pci))))
R["c3_ci"] = dict(trials=trials, ci_violations=int(viol_ci), naive_underestimates=int(under_naive),
                  naive_ratio_max=max(r["naive_ratio"] for r in rows), ci_ratio_max=max(r["ci_ratio"] for r in rows),
                  pos=[(r["c"], r["naive_ratio"], r["ci_ratio"]) for r in rows])

# 4 Proposition 2.5: PoE mean leaves the hull of the means
m1, m2 = np.array([1.0, 0]), np.array([0.0, 1])
L1, L2 = np.diag([1.0, 100]), np.diag([100.0, 1])
mf, _ = poe([m1, m2], [L1, L2])
outside = 0
for t in range(2000):
    k = 3; mus = [rng.normal(size=2) for _ in range(k)]; Ls = [spd(2, 50) for _ in range(k)]
    m, _ = poe(mus, Ls)
    from scipy.optimize import nnls
    A = np.vstack([np.column_stack(mus), np.ones(k) * 100]); b = np.concatenate([m, [100]])
    _, res = nnls(A, b); outside += res > 1e-6
one_d = 0
for t in range(2000):
    mus = list(rng.normal(size=3)); ls = list(rng.uniform(.1, 10, 3))
    m = sum(l * x for l, x in zip(ls, mus)) / sum(ls); one_d += not (min(mus) - 1e-12 <= m <= max(mus) + 1e-12)
R["c4_hull"] = dict(example=mf.tolist(), sum=float(mf.sum()), random_outside=int(outside), random=2000, one_d_outside=int(one_d))

# 5 Theorem 3.1: PoE of consistent clique marginals doubles the separator precision
worst = 0.0; ratio = []
for t in range(300):
    da, ds, db = rng.integers(1, 3, 3)
    n = da + ds + db; S = spd(n); mu = rng.normal(size=n)
    iA = list(range(da)); iS = list(range(da, da + ds)); iB = list(range(da + ds, n))
    AS = iA + iS; SB = iS + iB
    # PoE of the two marginal densities as factors on the full space: precision embedding
    def emb(idx):
        L = np.zeros((n, n)); L[np.ix_(idx, idx)] = np.linalg.inv(S[np.ix_(idx, idx)]); return L
    Lq = emb(AS) + emb(SB); Lext = emb(AS) + emb(SB) - emb(iS)
    # extension = joint only when S separates A and B; build such a joint: impose conditional independence
    # check on the extension law itself: its (A,S) and (S,B) marginals equal the given ones
    Sext = np.linalg.inv(Lext)
    worst = max(worst, float(max(np.abs(Sext[np.ix_(AS, AS)] - S[np.ix_(AS, AS)]).max(), np.abs(Sext[np.ix_(SB, SB)] - S[np.ix_(SB, SB)]).max())))
    Sq = np.linalg.inv(Lq)
    ratio.append(float(np.linalg.det(S[np.ix_(iS, iS)]) / np.linalg.det(Sq[np.ix_(iS, iS)])) ** (1 / ds))
R["c5_separator"] = dict(cases=300, extension_marginal_err=worst, separator_variance_ratio_min=min(ratio), max=max(ratio))

# 6 Proposition 3.2: pairwise-consistent marginals on a cycle with no joint
eig = {}
for r_ in (-0.4, -0.5, -0.6, -0.9):
    C = np.array([[1, r_, r_], [r_, 1, r_], [r_, r_, 1]]); eig[str(r_)] = float(np.linalg.eigvalsh(C).min())
R["c6_cycle"] = dict(min_eig=eig, threshold=-0.5)

# 7 Proposition 4.1 and 8 Proposition 4.2: hard constraint by conditioning; penalty rate 1/gamma
d = 4; Sg = spd(d); mu = rng.normal(size=d); A = rng.normal(size=(2, d)); b = rng.normal(size=2)
mc = mu - Sg @ A.T @ np.linalg.solve(A @ Sg @ A.T, A @ mu - b)
# Monte Carlo conditioning check via the Gaussian conditional of (x, Ax)
pen = []
for g in (1, 10, 100, 1000, 10000):
    Lg = np.linalg.inv(Sg) + g * A.T @ A
    mg = np.linalg.solve(Lg, np.linalg.solve(Sg, mu) + g * A.T @ b)
    bound = np.linalg.norm(Sg @ A.T, 2) * np.linalg.norm(np.linalg.inv(A @ Sg @ A.T), 2) ** 2 * np.linalg.norm(A @ mu - b) / g
    pen.append(dict(gamma=g, err=float(np.linalg.norm(mg - mc)), bound=float(bound)))
R["c7_constraint"] = dict(residual=float(np.abs(A @ mc - b).max()), penalty=pen,
                          slope=float(np.polyfit(np.log([p["gamma"] for p in pen[1:]]), np.log([p["err"] for p in pen[1:]]), 1)[0]))

# 9 Proposition 4.3: restricted second moment identity, Monte Carlo
sp, sq = 1.0, 1.5; c0 = 0.8                                   # K = {x > c0}
from scipy.stats import norm
from scipy.integrate import quad
piK = norm.sf(c0, scale=sp); qK = norm.sf(c0, scale=sq)
ig = lambda x: math.exp(2 * norm.logpdf(x, scale=sp) - norm.logpdf(x, scale=sq))
intK = quad(ig, c0, 40)[0]; intAll = quad(ig, -40, 40)[0]
x = rng.normal(0, sq, 4_000_000); x = x[x > c0]
w = (norm.pdf(x, scale=sp) / piK) / (norm.pdf(x, scale=sq) / qK)
R["c9_restricted"] = dict(identity=float(qK * intK / piK ** 2), mc=float((w ** 2).mean()), unrestricted_bound=float(qK * intAll / piK ** 2), m2_unrestricted=float(intAll), piK=float(piK),
                          acceptance=float(qK))

# 10 Theorem 4.4: coordinate recombination and boxes; exploration of feasibility of children
def child(x, y):
    m = rng.random(x.shape) < 0.5; return np.where(m, x, y)

def unif_simplex(n, D):
    e = rng.exponential(size=(n, D + 1)); return (e / e.sum(1, keepdims=True))[:, :D]

def unif_ball(n, D):
    g_ = rng.normal(size=(n, D)); g_ /= np.linalg.norm(g_, axis=1, keepdims=True); return g_ * rng.random((n, 1)) ** (1 / D)

feas = {"box": [], "ball": [], "simplex": []}; Ds = [1, 2, 3, 4, 6, 8, 12, 16]
for D in Ds:
    n = 40000
    X = rng.random((n, D)); Yb = rng.random((n, D)); feas["box"].append(float(np.all((0 <= child(X, Yb)) & (child(X, Yb) <= 1), 1).mean()))
    X = unif_ball(n, D); Yb = unif_ball(n, D); feas["ball"].append(float((np.linalg.norm(child(X, Yb), axis=1) <= 1).mean()))
    X = unif_simplex(n, D); Yb = unif_simplex(n, D); C_ = child(X, Yb); feas["simplex"].append(float(((C_ >= 0).all(1) & (C_.sum(1) <= 1)).mean()))
R["c10_recombination"] = dict(dims=Ds, feasible=feas)

# 11 Proposition 4.5: convex reads stay feasible, PoE fusion need not
K = lambda z: z.sum() >= 0.5
R["c11_convex"] = dict(means_feasible=[bool(K(m1)), bool(K(m2))], poe_mean=mf.tolist(), poe_feasible=bool(K(mf)),
                       read_feasible=bool(K(0.5 * m1 + 0.5 * m2)))

# 12 Exploration: calibration of fusion rules for correlated experts (coverage of 90% ellipse), D = 2
from scipy.stats import chi2
cov = {}
for rule in ("naive", "ci", "exact"):
    cov[rule] = []
for c in (0.0, 0.3, 0.6, 0.9):
    hits = {r_: 0 for r_ in cov}; N = 4000
    A_, B_ = np.diag([1.0, 0.3]), np.diag([0.3, 1.0]); LA, LB = np.linalg.cholesky(A_), np.linalg.cholesky(B_)
    Cx = c * LA @ LB.T
    J_ = np.block([[A_, Cx], [Cx.T, B_]]); Lj = np.linalg.cholesky(J_)
    Ai, Bi = np.linalg.inv(A_), np.linalg.inv(B_)
    w = min(np.linspace(.001, .999, 999), key=lambda w_: np.trace(np.linalg.inv(w_ * Ai + (1 - w_) * Bi)))
    Pci = np.linalg.inv(w * Ai + (1 - w) * Bi); Kc1, Kc2 = Pci @ (w * Ai), Pci @ ((1 - w) * Bi)
    Pn = np.linalg.inv(Ai + Bi); G1, G2 = Pn @ Ai, Pn @ Bi
    H = np.vstack([np.eye(2), np.eye(2)]); Ji = np.linalg.inv(J_); Pe = np.linalg.inv(H.T @ Ji @ H); Ge = Pe @ H.T @ Ji
    q90 = chi2.ppf(0.9, 2)
    for t in range(N):
        e = Lj @ rng.normal(size=4); ea, eb = e[:2], e[2:]
        for r_, (K1, K2, P) in {"naive": (G1, G2, Pn), "ci": (Kc1, Kc2, Pci), "exact": (Ge[:, :2], Ge[:, 2:], Pe)}.items():
            err = K1 @ ea + K2 @ eb; hits[r_] += err @ np.linalg.solve(P, err) <= q90
    for r_ in cov:
        cov[r_].append(hits[r_] / N)
R["explore_calibration"] = dict(corr=[0.0, 0.3, 0.6, 0.9], coverage=cov, nominal=0.9)

json.dump(R, open(os.path.join(HERE, "p5_checks.json"), "w"), indent=1, default=float)
for k, v in R.items():
    print(k, json.dumps(v, default=float)[:600])
