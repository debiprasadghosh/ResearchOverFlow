"""Recompute every line of the Part V C# driver with NumPy; write cs_validate.json."""
import json, math, os
import numpy as np
H = os.path.dirname(os.path.abspath(__file__)); M64 = (1 << 64) - 1
out = []
def poe(ms, Ls):
    L = sum(Ls); return np.linalg.solve(L, sum(l @ m for l, m in zip(Ls, ms))), L
m, _ = poe([np.array([1., 0]), np.array([0., 1])], [np.diag([1., 100]), np.diag([100., 1])]); out.append(("poe_mean", m))
Ls = np.array([[2, .5], [.5, 2.]]); ms = np.array([.5, -.2])
owns = [(np.diag([1 + k, 2 - .3 * k]), np.array([k * .3, 1 - k * .2])) for k in range(4)]
ex = [(np.linalg.solve(Ls + o, Ls @ ms + o @ y), Ls + o) for o, y in owns]
nm, nL = poe([e[0] for e in ex], [e[1] for e in ex]); out.append(("naive_mean", nm))
L = Ls + sum(o for o, _ in owns); h = Ls @ ms + sum(o @ y for o, y in owns)   # exact: shared factor once
xm = np.linalg.solve(L, h); out.append(("corrected_mean", [*xm, np.trace(L)]))
A, B = np.diag([1., .3]), np.diag([.3, 1.]); ia, ib = np.linalg.inv(A), np.linalg.inv(B)
ws = [i / 1000 for i in range(1, 1000)]; w = min(ws, key=lambda x: np.trace(np.linalg.inv(x * ia + (1 - x) * ib)))
l = w * ia + (1 - w) * ib; cm = np.linalg.solve(l, w * ia @ [1, 0] + (1 - w) * ib @ [0, 1])
out.append(("covariance_intersection", [*cm, np.trace(np.linalg.inv(l)), w]))
S = np.full((3, 3), .3) + np.diag([.7, 1.7, 2.7]); a = np.ones((1, 3)); mu = np.array([.2, -.4, 1.1])
c = mu - S @ a.T @ np.linalg.solve(a @ S @ a.T, a @ mu - 1); out.append(("condition", [*c, c.sum()]))
for g in (1.0, 100.0, 10000.0):
    p = np.linalg.solve(np.linalg.inv(S) + g * a.T @ a, np.linalg.solve(S, mu) + g * a.T @ [1])
    out.append((f"penalty_{g:g}" if g != 1.0 else "penalty_1", [np.linalg.norm(p - c)]))
s = 20261023
def u():
    global s
    s = (s + 0x9E3779B97F4A7C15) & M64; z = s
    z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64; z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
    return ((z ^ (z >> 31)) >> 11) * (1.0 / 9007199254740992.0)
feas = 0
for t in range(20000):
    def draw():
        e = [-math.log(1 - u()) for _ in range(7)]; tot = sum(e); return [v / tot for v in e[:6]]
    x, y = draw(), draw(); mask = [u() < .5 for _ in range(6)]
    ch = [xi if mk else yi for xi, yi, mk in zip(x, y, mask)]
    feas += all(v >= 0 for v in ch) and sum(ch) <= 1
out.append(("simplex_children_feasible", [feas / 20000]))
cs = [l.split() for l in open(os.path.join(H, "cs", "cs_out.txt")).read().splitlines() if l.strip()]
rows = []; ok = True
for (name, py), c_ in zip(out, cs):
    name = name.replace("penalty_100", "penalty_100").replace("penalty_10000", "penalty_10000")
    assert c_[0] == name, (c_[0], name)
    cv = [float(t) for t in c_[1:]]; py = [float(v) for v in np.ravel(py)]
    rel = max(abs(x - y) / max(abs(y), 1e-300) for x, y in zip(cv, py))
    absd = max(abs(x - y) for x, y in zip(cv, py)); ok = bool(ok and (rel < 1e-9 or absd < 1e-12))
    rows.append(dict(name=name, csharp=" ".join(c_), python=name + " " + " ".join(repr(v) for v in py), rel=float(rel), absd=float(absd)))
json.dump(dict(rows=rows, all_agree=ok, max_rel=max(r["rel"] for r in rows)), open(os.path.join(H, "cs_validate.json"), "w"), indent=1)
[print(r["name"], r["rel"]) for r in rows]; print("ALL", ok)
