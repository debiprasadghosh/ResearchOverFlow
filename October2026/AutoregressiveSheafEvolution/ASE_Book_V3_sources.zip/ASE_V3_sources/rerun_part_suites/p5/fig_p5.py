"""Figures of Part V, drawn from p5_checks.json; ellipses and eigenvalue curves are analytic."""
import json, os
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
H = os.path.dirname(os.path.abspath(__file__)); R = json.load(open(os.path.join(H, "p5_checks.json")))
B, O, A, INK, MUT = "#2a78d6", "#eb6834", "#1baf7a", "#222222", "#6b6b6b"
plt.rcParams.update({"font.size": 8.5, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": MUT,
                     "xtick.color": MUT, "ytick.color": MUT, "axes.grid": True, "grid.color": "#e8e8e8", "grid.linewidth": .6})
def ell(ax, m, P, col, lab):
    t = np.linspace(0, 2 * np.pi, 200); w, V = np.linalg.eigh(np.linalg.inv(P))
    pts = m[:, None] + V @ (np.sqrt(w)[:, None] * np.vstack([np.cos(t), np.sin(t)]))
    ax.plot(pts[0], pts[1], color=col, lw=1.5, label=lab); ax.plot(*m, "o", color=col, ms=4)
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 3.0))
m1, m2 = np.array([1., 0]), np.array([0., 1]); L1, L2 = np.diag([1., 100]), np.diag([100., 1]); mf = np.array(R["c4_hull"]["example"])
ell(a1, m1, L1, B, "expert 1"); ell(a1, m2, L2, A, "expert 2"); ell(a1, mf, L1 + L2, O, "product")
a1.plot([1, 0], [0, 1], color=MUT, lw=1, ls="--", label="hull of the means")
xx = np.linspace(-1.5, 2, 2); a1.fill_between(xx, 0.5 - xx, -1.5, color="#f3d6cb", alpha=.6, lw=0, label="infeasible, $x_1+x_2<0.5$")
a1.set_xlim(-1.3, 2.2); a1.set_ylim(-1.3, 2.2); a1.set_aspect("equal"); a1.legend(frameon=False, fontsize=6.5, loc="upper right")
a1.set_title("(a) a product of experts leaves the hull", fontsize=8.5, color=INK)
r = np.linspace(-0.95, 0.95, 400); a2.plot(r, np.minimum(1 - r, 1 + 2 * r), color=B, lw=2)
a2.axhline(0, color=INK, lw=.8); a2.axvline(-0.5, color=O, lw=1, ls=":")
a2.text(-0.52, 0.6, "no joint law\nbelow $-1/2$", ha="right", fontsize=7.5, color=O)
a2.set_xlabel("pairwise correlation $r$ on the 3-cycle"); a2.set_ylabel("smallest eigenvalue")
a2.set_title("(b) consistent pairs, no global law", fontsize=8.5, color=INK)
fig.tight_layout(); fig.savefig(os.path.join(H, "fig", "fusion.png"), dpi=220); plt.close(fig)

fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 2.8))
cal = R["explore_calibration"]
for k, col, lab in (("naive", O, "product of experts"), ("ci", A, "covariance intersection"), ("exact", B, "exact, known correlation")):
    a1.plot(cal["corr"], cal["coverage"][k], "o-", color=col, lw=2, ms=4, label=lab)
a1.axhline(0.9, color=MUT, ls="--", lw=1); a1.set_xlabel("error correlation $c$"); a1.set_ylabel("coverage of the 90% ellipse")
a1.legend(frameon=False, fontsize=7); a1.set_title("(a) calibration of fusion rules", fontsize=8.5, color=INK)
rc = R["c10_recombination"]
for k, col in (("box", B), ("ball", A), ("simplex", O)):
    a2.plot(rc["dims"], rc["feasible"][k], "o-", color=col, lw=2, ms=4, label=k)
a2.set_xlabel("dimension $D$"); a2.set_ylabel("feasible children"); a2.set_ylim(0.5, 1.03)
a2.legend(frameon=False, fontsize=7); a2.set_title("(b) coordinate recombination", fontsize=8.5, color=INK)
fig.tight_layout(); fig.savefig(os.path.join(H, "fig", "calibration.png"), dpi=220); plt.close(fig)
print("ok")
