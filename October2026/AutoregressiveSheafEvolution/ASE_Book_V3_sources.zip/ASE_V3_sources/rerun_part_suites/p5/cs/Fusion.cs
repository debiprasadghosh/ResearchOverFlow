// ASE Part V reference kernel: Gaussian fusion rules and linear constraints.
// Immutable values and pure functions; the solver works on private copies.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AsePartFive;

/// <summary>A dense real matrix stored row-major.</summary>
public sealed record Mat(int Rows, int Cols, Vec Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Mat Of(int r, int c, Func<int, int, double> f) =>
        new(r, c, Enumerable.Range(0, r * c).Select(k => f(k / c, k % c)).ToImmutableArray());

    public static Mat Identity(int n) => Of(n, n, (i, j) => i == j ? 1 : 0);
    public static Mat Diag(params double[] d) => Of(d.Length, d.Length, (i, j) => i == j ? d[i] : 0);
    public Mat T => Of(Cols, Rows, (i, j) => this[j, i]);
    public Mat Mul(Mat b) => Of(Rows, b.Cols,
        (i, j) => Enumerable.Range(0, Cols).Sum(k => this[i, k] * b[k, j]));
    public Vec Apply(Vec v) => Enumerable.Range(0, Rows)
        .Select(i => Enumerable.Range(0, Cols).Sum(k => this[i, k] * v[k])).ToImmutableArray();
    public Mat Add(Mat b, double s = 1) => Of(Rows, Cols, (i, j) => this[i, j] + s * b[i, j]);
    public Mat Scale(double s) => Of(Rows, Cols, (i, j) => s * this[i, j]);
    public double Trace => Enumerable.Range(0, Rows).Sum(i => this[i, i]);

    /// <summary>Solves this X = B by Gauss-Jordan elimination with partial pivoting.</summary>
    public Mat Solve(Mat b)
    {
        int n = Rows, m = b.Cols;
        var a = Enumerable.Range(0, n).Select(i => Enumerable.Range(0, n).Select(j => this[i, j])
            .Concat(Enumerable.Range(0, m).Select(j => b[i, j])).ToArray()).ToArray();
        for (int c = 0; c < n; c++)
        {
            int p = Enumerable.Range(c, n - c).OrderByDescending(r => Math.Abs(a[r][c])).First();
            (a[c], a[p]) = (a[p], a[c]);
            for (int r = 0; r < n; r++)
            {
                if (r == c) continue;
                double f = a[r][c] / a[c][c];
                for (int k = c; k < n + m; k++) a[r][k] -= f * a[c][k];
            }
        }
        return Of(n, m, (i, j) => a[i][n + j] / a[i][i]);
    }

    public Mat Inverse() => Solve(Identity(Rows));
    public Vec SolveVec(Vec v) => Solve(Of(v.Length, 1, (i, _) => v[i])).Data;
}

/// <summary>A Gaussian expert in information form: mean and precision.</summary>
public sealed record Expert(Vec Mean, Mat Precision);

public static class Fusion
{
    /// <summary>Product of experts (Proposition 2.2): precisions add, means are
    /// precision-weighted.</summary>
    public static Expert Product(ImmutableArray<Expert> es)
    {
        var l = es.Skip(1).Aggregate(es[0].Precision, (acc, e) => acc.Add(e.Precision));
        var h = es.Select(e => e.Precision.Apply(e.Mean))
                  .Aggregate((a, b) => a.Zip(b, (x, y) => x + y).ToImmutableArray());
        return new Expert(l.SolveVec(h), l);
    }

    /// <summary>Removes a factor that k experts share, counted k - 1 times too often
    /// (Proposition 2.3).</summary>
    public static Expert Divide(Expert fused, Expert shared, int extraCount)
    {
        var l = fused.Precision.Add(shared.Precision, -extraCount);
        var h = fused.Precision.Apply(fused.Mean)
            .Zip(shared.Precision.Apply(shared.Mean), (a, b) => a - extraCount * b)
            .ToImmutableArray();
        return new Expert(l.SolveVec(h), l);
    }

    /// <summary>Covariance intersection of two estimates (Proposition 2.4), with the
    /// weight chosen on a grid to minimise the trace of the fused covariance.</summary>
    public static (Vec Mean, Mat Covariance, double Omega) Intersect(
        Vec a, Mat pa, Vec b, Mat pb, int grid = 999)
    {
        Mat ia = pa.Inverse(), ib = pb.Inverse();
        double w = Enumerable.Range(1, grid).Select(i => i / (grid + 1.0))
            .OrderBy(x => ia.Scale(x).Add(ib, 1 - x).Inverse().Trace).First();
        var l = ia.Scale(w).Add(ib, 1 - w);
        var h = ia.Scale(w).Apply(a).Zip(ib.Scale(1 - w).Apply(b), (x, y) => x + y)
                  .ToImmutableArray();
        return (l.SolveVec(h), l.Inverse(), w);
    }

    /// <summary>Hard linear constraint A x = b by conditioning (Proposition 4.1).</summary>
    public static Vec Condition(Vec mu, Mat sigma, Mat a, Vec b)
    {
        var sat = sigma.Mul(a.T);
        var r = a.Apply(mu).Zip(b, (x, y) => x - y).ToImmutableArray();
        var c = sat.Apply(a.Mul(sat).SolveVec(r));
        return mu.Zip(c, (x, y) => x - y).ToImmutableArray();
    }

    /// <summary>Soft penalty exp(-gamma |A x - b|^2 / 2) (Proposition 4.2).</summary>
    public static Vec Penalise(Vec mu, Mat sigma, Mat a, Vec b, double gamma)
    {
        var l = sigma.Inverse().Add(a.T.Mul(a), gamma);
        var h = sigma.SolveVec(mu).Zip(a.T.Apply(b), (x, y) => x + gamma * y)
                     .ToImmutableArray();
        return l.SolveVec(h);
    }

    /// <summary>A child taking each coordinate from x where mask is true, else from y.</summary>
    public static Vec Recombine(Vec x, Vec y, ImmutableArray<bool> mask) =>
        x.Select((v, i) => mask[i] ? v : y[i]).ToImmutableArray();
}

/// <summary>SplitMix64 stream with uniform draws; each draw returns the next state.</summary>
public sealed record Rng(ulong State)
{
    public (double Value, Rng Next) Uniform()
    {
        ulong s = State + 0x9E3779B97F4A7C15UL, z = s;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
        return (((z ^ (z >> 31)) >> 11) * (1.0 / 9007199254740992.0), new Rng(s));
    }
}
