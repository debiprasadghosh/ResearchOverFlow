// Driver for the Part V kernel. Every line is recomputed by cs_validate.py.
using System;
using System.Collections.Immutable;
using System.Globalization;
using System.Linq;
using AsePartFive;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

static string F(double x) => x.ToString("R", CultureInfo.InvariantCulture);
static void Print(string name, params double[] xs) =>
    Console.WriteLine(name + " " + string.Join(" ", xs.Select(F)));
static Vec V(params double[] x) => x.ToImmutableArray();

// Proposition 2.5: two experts, each sure of the coordinate the other is unsure of
var fused = Fusion.Product(ImmutableArray.Create(
    new Expert(V(1, 0), Mat.Diag(1, 100)), new Expert(V(0, 1), Mat.Diag(100, 1))));
Print("poe_mean", fused.Mean[0], fused.Mean[1]);

// Proposition 2.3: four experts sharing a prior factor; dividing it out three times
var shared = new Expert(V(0.5, -0.2), Mat.Of(2, 2, (i, j) => i == j ? 2.0 : 0.5));
var experts = Enumerable.Range(0, 4).Select(k =>
{
    var own = Mat.Diag(1 + k, 2 - 0.3 * k);
    var y = V(k * 0.3, 1 - k * 0.2);
    var l = shared.Precision.Add(own);
    var h = shared.Precision.Apply(shared.Mean).Zip(own.Apply(y), (a, b) => a + b)
                  .ToImmutableArray();
    return new Expert(l.SolveVec(h), l);
}).ToImmutableArray();
var naive = Fusion.Product(experts);
var corrected = Fusion.Divide(naive, shared, 3);
Print("naive_mean", naive.Mean[0], naive.Mean[1]);
Print("corrected_mean", corrected.Mean[0], corrected.Mean[1], corrected.Precision.Trace);

// Proposition 2.4: covariance intersection
var (cm, cc, w) = Fusion.Intersect(V(1, 0), Mat.Diag(1, 0.3), V(0, 1), Mat.Diag(0.3, 1));
Print("covariance_intersection", cm[0], cm[1], cc.Trace, w);

// Propositions 4.1 and 4.2: conditioning and the penalty path
var sigma = Mat.Of(3, 3, (i, j) => i == j ? 1.0 + i : 0.3);
var a = Mat.Of(1, 3, (_, j) => 1.0);
var mu = V(0.2, -0.4, 1.1);
var cond = Fusion.Condition(mu, sigma, a, V(1));
Print("condition", cond[0], cond[1], cond[2], cond.Sum());
foreach (var g in new[] { 1.0, 100.0, 10000.0 })
{
    var p = Fusion.Penalise(mu, sigma, a, V(1), g);
    Print($"penalty_{g.ToString(CultureInfo.InvariantCulture)}",
          Math.Sqrt(p.Zip(cond, (x, y) => (x - y) * (x - y)).Sum()));
}

// Theorem 4.4: recombination of uniform simplex points in R^6 (from the uniform stream)
var rng = new Rng(20261023UL);
int feasible = 0, trials = 20000;
for (int t = 0; t < trials; t++)
{
    Vec Draw()
    {
        var e = new double[7];
        for (int i = 0; i < 7; i++) { double u; (u, rng) = rng.Uniform(); e[i] = -Math.Log(1 - u); }
        double s = e.Sum();
        return e.Take(6).Select(v => v / s).ToImmutableArray();
    }
    var x = Draw(); var y = Draw();
    var mask = ImmutableArray.CreateBuilder<bool>(6);
    for (int i = 0; i < 6; i++) { double u; (u, rng) = rng.Uniform(); mask.Add(u < 0.5); }
    var c = Fusion.Recombine(x, y, mask.MoveToImmutable());
    if (c.All(v => v >= 0) && c.Sum() <= 1) feasible++;
}
Print("simplex_children_feasible", feasible / (double)trials);
