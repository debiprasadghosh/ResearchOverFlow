#!/bin/bash
# Fresh re-execution of all six part suites and their C# kernels.
cd "$(dirname "$0")"
run() { local d=$1; shift; for s in "$@"; do echo "== $d/$s"; ( cd $d && /usr/bin/time -f "%e s" python3 $s > ${s%.py}.log 2>&1; echo "exit $?" ); done; }
run p1 p1_checks.py p1_extras.py tangent_mech.py
run p2 p2_checks.py p2_extras.py
run p3 p3_checks.py p3_extras.py p3_explore.py
run p4 p4_checks.py p4_extras.py
run p5 p5_checks.py
run p6 p6_checks.py
for d in p1 p2 p3 p4 p5 p6; do
  echo "== $d C#"; ( cd $d/cs && dotnet build -c Release 2>&1 | grep -E "Build succeeded| error " | head -3;
    dll=$(ls bin/Release/net8.0/*.dll | grep -v nuget | head -1); prj=$(basename *.csproj .csproj);
    dotnet bin/Release/net8.0/$prj.dll > cs_out.txt; echo "exit $?"; diff -q cs_out.txt cs_out_recorded.txt && echo "C# output identical to recorded" )
  ( cd $d && python3 cs_validate.py > cs_validate.log 2>&1; echo "validate exit $?"; tail -2 cs_validate.log )
done
echo ALLDONE
