#!/bin/bash
cd "$(dirname "$0")"
run() { local d=$1; shift; for s in "$@"; do st=$(date +%s); ( cd $d && python3 $s > ${s%.py}.log 2>&1 ); e=$?; echo "== $d/$s exit $e $(( $(date +%s) - st )) s"; done; }
run p1 p1_checks.py p1_extras.py tangent_mech.py
run p2 p2_checks.py p2_extras.py
run p3 p3_checks.py p3_extras.py p3_explore.py
run p4 p4_checks.py p4_extras.py
run p5 p5_checks.py
run p6 p6_checks.py
for d in p1 p2 p3 p4 p5 p6; do ( cd $d && python3 cs_validate.py > cs_validate.log 2>&1; echo "== $d validate exit $?" ); done
echo PYDONE
