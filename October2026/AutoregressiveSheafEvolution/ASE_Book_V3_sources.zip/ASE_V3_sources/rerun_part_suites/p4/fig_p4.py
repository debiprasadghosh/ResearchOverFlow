"""Figures of Part IV, drawn from p4_checks.json; panel (a) of Figure 1 recomputes the target on a grid."""
import json, math, os
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.spatial import ConvexHull
HERE = os.path.dirname(os.path.abspath(__file__)); R = json.load(open(os.path.join(HERE, "p4_checks.json")))
B, O, A, Y4, INK, MUT = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#222222", "#6b6b6b"
plt.rcParams.update({"font.size": 8.5, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": MUT,
                     "xtick.color": MUT, "ytick.color": MUT, "axes.grid": True, "grid.color": "#e8e8e8", "grid.linewidth": .6})
rng = np.random.default_rng(20261021)
J = lambda X: (X[..., 0] ** 2 - 1) ** 2 + 0.5 * X[..., 1] ** 2
Y = rng.normal(0, 2, (40, 2)); lw = -4 * J(Y)
g = np.linspace(-3, 3, 401); GX, GY = np.meshgrid(g, g); P = np.exp(-(GX ** 2 + GY ** 2) / 8 - 4 * J(np.dstack([GX, GY])))

fig, ax = plt.subplots(1, 3, figsize=(7.0, 2.6), gridspec_kw={"width_ratios": [1, 1, 1.1]})
for a, k, title in ((ax[0], 40, "(a) all 40 records"), (ax[1], 8, "(b) the 8 elite records")):
    a.contourf(GX, GY, P, levels=12, cmap="Blues"); a.grid(False)
    top = Y[np.argsort(-lw)[:k]]
    a.scatter(Y[:, 0], Y[:, 1], s=6, color=MUT, zorder=3)
    a.scatter(top[:, 0], top[:, 1], s=14, color=O, zorder=4)
    hl = ConvexHull(top); vv = np.append(hl.vertices, hl.vertices[0])
    a.plot(top[vv, 0], top[vv, 1], color=O, lw=1.2)
    a.set_xlim(-3, 3); a.set_ylim(-3, 3); a.set_aspect("equal"); a.set_title(title, fontsize=8.5, color=INK)
el = R["extras"]["elites"]
ax[2].bar([str(e["k"]) for e in el], [e["missing"] for e in el], color=B, width=.6)
for i, e in enumerate(el):
    ax[2].text(i, e["missing"] + .02, f'{e["missing"]:.2f}' if e["missing"] > 1e-3 else "<10⁻⁸", ha="center", fontsize=7.5)
ax[2].set_ylim(0, 1); ax[2].set_xlabel("records read at the clean top"); ax[2].set_ylabel("target mass outside the hull")
ax[2].set_title("(c) mass a clean top cannot propose", fontsize=8.5, color=INK)
fig.tight_layout(); fig.savefig(os.path.join(HERE, "fig", "support.png"), dpi=220); plt.close(fig)

rows = R["scan"]["rows"]; s = np.array([r["s"] for r in rows])
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 2.8))
fin = np.array([r["finite"] for r in rows])
a1.semilogy(s[fin], [r["m2"] for r in rows if r["finite"]], color=B, lw=2, label="archive proposal $p_s$")
a1.semilogy(s, [r["m2_def0.1"] for r in rows], color=O, lw=1.6, label="defensive, $\\varepsilon=0.1$")
a1.semilogy(s, [r["m2_def0.3"] for r in rows], color=A, lw=1.6, label="defensive, $\\varepsilon=0.3$")
a1.axhline(R["scan"]["rho_only_m2"], color=MUT, ls="--", lw=1, label="base law $\\rho$ alone")
a1.axvline(R["extras"]["threshold"], color=INK, lw=.8, ls=":")
a1.text(R["extras"]["threshold"] * 0.93, 300, "infinite\nbelow", ha="right", fontsize=7.5, color=INK)
a1.set_xscale("log"); a1.set_ylim(5, 600); a1.set_xlabel("proposal width $s$"); a1.set_ylabel("$E_q[(\\pi/q)^2]=1+\\chi^2$")
a1.legend(frameon=False, fontsize=7); a1.set_title("(a) width scan on the double well", fontsize=8.5, color=INK)
c4 = R["c4_gauss_chi2"]
a2.semilogy(c4["dims"], c4["ess_fraction"], color=B, lw=2)
a2.set_xlabel("dimension $D$"); a2.set_ylabel("$1/(1+\\chi^2)$")
a2.set_title("(b) proposal 1.5 times too wide, per coordinate", fontsize=8.5, color=INK)
fig.tight_layout(); fig.savefig(os.path.join(HERE, "fig", "width.png"), dpi=220); plt.close(fig)

L = R["c10_ledger"]
fig, ax = plt.subplots(figsize=(6.2, 2.8))
for eps, col in ((0.0, B), (0.05, O), (0.2, A)):
    rr = [r for r in L if r["eps"] == eps]; n = [r["n"] for r in rr]
    ax.loglog(n, [r["rmse"] for r in rr], color=col, lw=2, marker="o", ms=4, label=f"measured RMSE, $\\varepsilon={eps:g}$")
    ax.loglog(n, [r["bound"] for r in rr], color=col, lw=1, ls="--")
    if eps > 0:
        ax.axhline(rr[0]["limit_bias"], color=col, lw=.8, ls=":")
ax.set_xlabel("importance samples $n$"); ax.set_ylabel("error in $P(x_1>0.5)$")
ax.legend(frameon=False, fontsize=7, loc="lower left"); ax.set_ylim(0.008, 1.2)
fig.tight_layout(); fig.savefig(os.path.join(HERE, "fig", "ledger.png"), dpi=220); plt.close(fig)
print("ok")
