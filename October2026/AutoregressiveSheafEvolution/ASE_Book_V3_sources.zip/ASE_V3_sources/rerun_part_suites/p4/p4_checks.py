"""Numerical checks and explorations for ASE Part IV: targets and estimation.
Writes p4_checks.json. Seed 20261021."""
import json, math, os
import numpy as np
from scipy.stats import ks_2samp
import p3_core as P3

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261021
rng = np.random.default_rng(SEED)
R = {}


def mix_logpdf(X, Y, lw, s, chunk=None):
    """log of sum_i beta_i N(x; y_i, s^2 I), beta = softmax(lw), computed in chunks."""
    chunk = chunk or max(500, 4_000_000 // len(Y))
    if len(X) > chunk:
        return np.concatenate([mix_logpdf(X[i:i + chunk], Y, lw, s) for i in range(0, len(X), chunk)])
    D = Y.shape[1]
    lb = lw - np.logaddexp.reduce(lw)
    d2 = ((X[:, None, :] - Y[None]) ** 2).sum(-1)
    L = lb[None] - d2 / (2 * s * s) - D / 2 * math.log(2 * math.pi * s * s)
    return np.logaddexp.reduce(L, axis=1)


# ---------------------------------------------------------------- the 2-D double-well target
BETA, RHO_SD = 4.0, 2.0
J = lambda X: (X[:, 0] ** 2 - 1) ** 2 + 0.5 * X[:, 1] ** 2
log_rho = lambda X: -(X ** 2).sum(1) / (2 * RHO_SD ** 2) - math.log(2 * math.pi * RHO_SD ** 2)
g = np.linspace(-6, 6, 961); h = g[1] - g[0]
GX, GY = np.meshgrid(g, g, indexing="ij"); G = np.column_stack([GX.ravel(), GY.ravel()])
lu = log_rho(G) - BETA * J(G)                               # unnormalised log target
Z = np.exp(lu).sum() * h * h
pi = np.exp(lu) / Z
E = lambda f: float((pi * f).sum() * h * h)
f1 = G[:, 0] ** 2; f2 = (G[:, 0] > 0.5).astype(float)
R["target"] = dict(beta=BETA, rho_sd=RHO_SD, Z=Z, mean_x1sq=E(f1), p_x1_gt_half=E(f2), mass=E(np.ones(len(G))))

# archive: 40 records from rho with weights exp(-beta J) (Proposition 2.3 with q = rho)
n_arc = 40
Y = rng.normal(0, RHO_SD, (n_arc, 2)); lwY = -BETA * J(Y)
R["archive"] = dict(n=n_arc, ess=float(np.exp(lwY).sum() ** 2 / np.exp(2 * lwY).sum()))

# ---------------------------------------------------------------- check 1: Proposition 2.3, Gaussian case
b1 = 1.0; n1 = 400_000
y1 = rng.normal(0, 1, (n1, 1)); lw1 = -b1 * y1[:, 0] ** 2 / 2
xs = np.linspace(-2, 2, 9)[:, None]; out = []
for s in (0.1, 0.3, 1.0):
    est = np.exp(mix_logpdf(xs, y1, lw1, s))
    var = 1 / (1 + b1) + s * s
    true = np.exp(-xs[:, 0] ** 2 / (2 * var)) / math.sqrt(2 * math.pi * var)
    out.append(float(np.abs(est / true - 1).max()))
R["c1_smoothed_target"] = dict(n=n1, scales=[0.1, 0.3, 1.0], max_rel_err=out)

# ---------------------------------------------------------------- check 2: Theorem 3.1, support of clean-top proposals
D5, n5 = 5, 4; worst = 0.0
for t in range(200):
    Yr = rng.normal(0, 1, (n5, D5)); lwr = rng.normal(0, .5, n5)
    sch = np.geomspace(0.05, 10, 9); s = np.concatenate([[0.0], sch])
    z = rng.normal(0, 10, (1, D5))
    noise = {k: rng.normal(size=(1, D5)) for k in range(1, len(s))}
    out0 = P3.run_stack(z, Yr, lwr, s, rng.uniform(), noise)
    A = (Yr[1:] - Yr[0]).T; coef = np.linalg.lstsq(A, (out0[0] - Yr[0]), rcond=None)[0]
    worst = max(worst, float(np.linalg.norm(A @ coef - (out0[0] - Yr[0]))))
from scipy.spatial import Delaunay
hull = Delaunay(Y)
outside = hull.find_simplex(G) < 0
R["c2_clean_top"] = dict(cases=200, max_dist_to_span=worst, missing_mass=float((pi * outside).sum() * h * h),
                         missing_mass_f2=float((pi * outside * f2).sum() * h * h))

# ---------------------------------------------------------------- check 3: Proposition 3.2, exact sampler vs finite stack
y6 = np.array([[-3.0], [-1.2], [0.0], [0.7], [2.2], [3.5]]); lw6 = np.log(np.array([.1, .25, .15, .2, .2, .1]))
N3, s0, sT = 40_000, 0.3, 20.0
pick = rng.choice(6, N3, p=np.exp(lw6)); direct = y6[pick, 0] + s0 * rng.normal(size=N3)
ref = y6[rng.choice(6, N3, p=np.exp(lw6)), 0] + s0 * rng.normal(size=N3)
zT = y6[rng.choice(6, N3, p=np.exp(lw6))] + sT * rng.normal(size=(N3, 1))
ks = {}
for T in (4, 16, 64):
    s = np.concatenate([[s0], np.geomspace(s0, sT, T + 1)[1:]]); s[0] = s0
    s = np.geomspace(s0, sT, T + 1)
    o = P3.run_stack(zT.copy(), y6, lw6, s, 0.0)[:, 0]
    ks[T] = float(ks_2samp(o, ref).statistic)
R["c3_direct"] = dict(tokens=N3, ks_direct=float(ks_2samp(direct, ref).statistic), ks_stack=ks,
                      floor=float(1.36 * math.sqrt(2 / N3)))


# ---------------------------------------------------------------- check 4: Proposition 3.3, Gaussian chi-square
def chi2_gauss(Sp, Sq):
    M = 2 * Sq - Sp
    if np.linalg.eigvalsh(M).min() <= 0:
        return math.inf
    return float(np.linalg.det(Sq) / math.sqrt(np.linalg.det(Sp) * np.linalg.det(M)) - 1)


rows = []
for (sp, sq) in ((1.0, 1.5), (1.0, 0.8), (1.0, 3.0), (2.0, 1.6)):
    cf = chi2_gauss(np.eye(1) * sp ** 2, np.eye(1) * sq ** 2)
    x = rng.normal(0, sq, 2_000_000)
    w = np.exp(-x ** 2 / (2 * sp ** 2) + x ** 2 / (2 * sq ** 2)) * sq / sp
    rows.append(dict(sp=sp, sq=sq, closed=cf, mc=float((w ** 2).mean() - 1)))
dims = list(range(1, 33)); r = 1.5
ess_dim = [1 / (1 + chi2_gauss(np.eye(1), np.eye(1) * r * r)) ** d for d in dims]
R["c4_gauss_chi2"] = dict(rows=rows, ratio=r, dims=dims, ess_fraction=ess_dim,
                          threshold=1 / math.sqrt(2))

# ---------------------------------------------------------------- exploration and checks 5-6: width scan on the double well
def second_moment(logq):
    """E_q[(pi/q)^2] = int pi^2/q, by quadrature."""
    return float(np.exp(2 * np.log(np.maximum(pi, 1e-300)) - logq).sum() * h * h)


scales = np.geomspace(0.05, 3.0, 40); scan = []
log_rho_G = log_rho(G)
for s in scales:
    lq = mix_logpdf(G, Y, lwY, s)
    row = dict(s=float(s), m2=second_moment(lq))
    for eps in (0.1, 0.3):
        ld = np.logaddexp(math.log(1 - eps) + lq, math.log(eps) + log_rho_G)
        row[f"m2_def{eps}"] = second_moment(ld)
        row[f"bound_def{eps}"] = 1 / (eps * Z)
        row[f"maxw_def{eps}"] = float(np.exp(np.log(np.maximum(pi, 1e-300)) - ld).max())
    scan.append(row)
best = min(scan, key=lambda r_: r_["m2"])
R["scan"] = dict(rows=scan, best_s=best["s"], best_m2=best["m2"], rho_only_m2=second_moment(log_rho_G),
                 m2_def_violations=sum(r_["maxw_def0.1"] > r_["bound_def0.1"] * (1 + 1e-9) or
                                       r_["maxw_def0.3"] > r_["bound_def0.3"] * (1 + 1e-9) for r_ in scan))

# check 6: Agapiou et al. bounds for SNIS at the best scale and with a poor scale
f_test = lambda X: (X[:, 0] > 0.5).astype(float)
truth = E(f2)
agap = []
for s in (best["s"], 0.08, 2.5):
    m2 = second_moment(mix_logpdf(G, Y, lwY, s))
    for n in (100, 1000):
        reps = 2000
        comp = rng.choice(n_arc, (reps, n), p=np.exp(lwY - np.logaddexp.reduce(lwY)))
        X = Y[comp] + s * rng.normal(size=(reps, n, 2))
        Xf = X.reshape(-1, 2)
        lw = (log_rho(Xf) - BETA * J(Xf) - mix_logpdf(Xf, Y, lwY, s)).reshape(reps, n)
        w = np.exp(lw - lw.max(1, keepdims=True))
        est = (w * f_test(Xf).reshape(reps, n)).sum(1) / w.sum(1)
        mse = float(((est - truth) ** 2).mean()); bias = float(abs(est.mean() - truth))
        agap.append(dict(s=float(s), n=n, m2=m2, mse=mse, mse_bound=4 * m2 / n, bias=bias, bias_bound=12 * m2 / n,
                         ess_mean=float(((w.sum(1) ** 2) / (w ** 2).sum(1)).mean() / n)))
R["c6_agapiou"] = agap


# ---------------------------------------------------------------- check 7: Proposition 4.1, bounded critic error
def tv(a, b): return 0.5 * np.abs(a - b).sum()


worst = 0.0
for t in range(4000):
    k = rng.integers(2, 12); a = rng.dirichlet(np.ones(k) * rng.uniform(.2, 3)); be, ep = rng.uniform(.1, 5), rng.uniform(.01, 1)
    d = rng.uniform(-ep, ep, k); d[rng.random(k) < .3] = ep * rng.choice([-1, 1])
    b = a * np.exp(-be * d); b /= b.sum()
    worst = max(worst, tv(a, b) / math.tanh(be * ep / 2))
be, ep = 2.0, 0.7; p = 1 / (1 + math.exp(be * ep)); a = np.array([p, 1 - p]); b = a * np.exp(-be * np.array([-ep, ep])); b /= b.sum()
# continuous: double-well target with a bounded critic error
eps_c = 0.1; delta = eps_c * np.sin(3 * G[:, 0]) * np.cos(2 * G[:, 1])
pi2 = pi * np.exp(-BETA * delta); pi2 /= pi2.sum() * h * h
R["c7_critic"] = dict(trials=4000, max_ratio=worst, two_atom=[tv(a, b), math.tanh(be * ep / 2)],
                      continuous_tv=float(0.5 * np.abs(pi - pi2).sum() * h * h), continuous_bound=math.tanh(BETA * eps_c / 2))

# ---------------------------------------------------------------- check 8: Proposition 4.2, heteroscedastic tilt
b8 = 1.0; sig = lambda x: 0.5 + 0.5 * np.abs(x)
x8 = np.linspace(-12, 12, 200001); h8 = x8[1] - x8[0]
base = np.exp(-x8 ** 2 / 2 - b8 * x8 ** 2 / 2)
tilt = base * np.exp(b8 ** 2 * sig(x8) ** 2 / 2)
m_true = float((base * x8 ** 2).sum() / base.sum()); m_tilt = float((tilt * x8 ** 2).sum() / tilt.sum())
N8 = 4_000_000; x = rng.normal(0, 1, N8)                      # proposal rho = N(0, 1)
Jn = x ** 2 / 2 + sig(x) * rng.normal(size=N8)
w = np.exp(-b8 * Jn); est = float((w * x ** 2).sum() / w.sum())
lam = 0.5 * b8 ** 2 * sig(x) ** 2; w_hom = np.exp(-b8 * (x ** 2 / 2 + 0.7 * rng.normal(size=N8)))
R["c8_tilt"] = dict(true=m_true, tilted=m_tilt, snis_noisy=est,
                    snis_homoscedastic=float((w_hom * x ** 2).sum() / w_hom.sum()))

# ---------------------------------------------------------------- check 9: Lemma 5.1 and the truncation instance
worst = 0.0
for t in range(4000):
    k = rng.integers(2, 12); a = rng.dirichlet(np.ones(k)); kap = rng.uniform(.01, 4)
    u = rng.uniform(0, kap, k); u[rng.random(k) < .4] = rng.choice([0, kap])
    b = a * np.exp(u); b /= b.sum(); worst = max(worst, tv(a, b) / math.tanh(kap / 4))
trunc = []
s_tr = best["s"]
lp = mix_logpdf(G, Y, lwY, s_tr)
lb = lwY - np.logaddexp.reduce(lwY)
d2 = ((G[:, None, :] - Y[None]) ** 2).sum(-1)       # 923k x 40, fine
Lfull = lb[None] - d2 / (2 * s_tr ** 2) - math.log(2 * math.pi * s_tr ** 2)
for kk in (5, 10, 20):
    idx = np.argsort(d2, axis=1)[:, :kk]
    lph = np.logaddexp.reduce(np.take_along_axis(Lfull, idx, 1), axis=1)
    ratio = np.exp(lp - lph)                                  # p / p_hat >= 1
    kap = float(np.log(ratio.max()))
    lim = pi * ratio; lim /= lim.sum() * h * h                # SNIS limit with weights pi/p_hat under q = p
    trunc.append(dict(k=kk, kappa=kap, tv=float(0.5 * np.abs(lim - pi).sum() * h * h), bound=math.tanh(kap / 4)))
R["c9_lemma"] = dict(trials=4000, max_ratio=worst, truncation=trunc)

# ---------------------------------------------------------------- check 10: Theorem 5.2, the error ledger
ledger = []
s = best["s"]; m2c = None
for eps_c in (0.0, 0.05, 0.2):
    deltaG = eps_c * np.sign(np.sin(5 * G[:, 0]))
    piP = pi * np.exp(-BETA * deltaG); piP /= piP.sum() * h * h
    truthP = float((piP * f2).sum() * h * h)
    lqG = mix_logpdf(G, Y, lwY, s)
    m2P = float(np.exp(2 * np.log(np.maximum(piP, 1e-300)) - lqG).sum() * h * h)
    for n in (100, 1000, 10000):
        reps = 200 if n == 10000 else 1000
        comp = rng.choice(n_arc, (reps, n), p=np.exp(lwY - np.logaddexp.reduce(lwY)))
        Xf = (Y[comp] + s * rng.normal(size=(reps, n, 2))).reshape(-1, 2)
        lw = (log_rho(Xf) - BETA * (J(Xf) + eps_c * np.sign(np.sin(5 * Xf[:, 0]))) - mix_logpdf(Xf, Y, lwY, s)).reshape(reps, n)
        w = np.exp(lw - lw.max(1, keepdims=True))
        est = (w * f_test(Xf).reshape(reps, n)).sum(1) / w.sum(1)
        rmse = float(np.sqrt(((est - truth) ** 2).mean()))
        bound = math.tanh(2 * BETA * eps_c / 4) + 2 * math.sqrt(m2P / n)
        ledger.append(dict(eps=eps_c, n=n, rmse=rmse, bound=bound, critic_part=math.tanh(BETA * eps_c / 2),
                           sampling_part=2 * math.sqrt(m2P / n), limit_bias=abs(truthP - truth)))
R["c10_ledger"] = ledger

# ---------------------------------------------------------------- archive-as-target smoothing bias (Section 2)
arc_bias = []
for s in (0.05, 0.2, 0.5, 1.0):
    q = np.exp(mix_logpdf(G, Y, lwY, s))
    arc_bias.append(dict(s=s, f2=float((q * f2).sum() * h * h), tv=float(0.5 * np.abs(q - pi).sum() * h * h)))
big = rng.normal(0, RHO_SD, (4000, 2)); lwb = -BETA * J(big)
for s in (0.05, 0.2):
    q = np.exp(mix_logpdf(G, big, lwb, s))
    arc_bias.append(dict(s=s, n=4000, f2=float((q * f2).sum() * h * h), tv=float(0.5 * np.abs(q - pi).sum() * h * h)))
R["archive_as_target"] = arc_bias

json.dump(R, open(os.path.join(HERE, "p4_checks.json"), "w"), indent=1, default=float)
print(json.dumps({k: v for k, v in R.items() if k not in ("scan",)}, default=float, indent=0)[:6000])
print("best s", best["s"], best["m2"], "rho", R["scan"]["rho_only_m2"])
