// ASE Part IV reference kernel: targets, proposals and self-normalised importance sampling.
// Immutable values and pure functions; the random stream is itself a value.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AsePartFour;

/// <summary>SplitMix64 stream with Box-Muller normals; each draw returns the next state.</summary>
public sealed record Rng(ulong State)
{
    public (ulong Value, Rng Next) NextU64()
    {
        ulong s = State + 0x9E3779B97F4A7C15UL, z = s;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
        return (z ^ (z >> 31), new Rng(s));
    }

    public (double Value, Rng Next) Uniform()
    {
        var (v, n) = NextU64();
        return ((v >> 11) * (1.0 / 9007199254740992.0), n);
    }

    public (double Value, Rng Next) Normal()
    {
        var (u1, r1) = Uniform();
        var (u2, r2) = r1.Uniform();
        return (Math.Sqrt(-2 * Math.Log(1 - u1)) * Math.Cos(2 * Math.PI * u2), r2);
    }

    /// <summary>Index drawn with probabilities proportional to exp(logWeights), by inversion.</summary>
    public (int Value, Rng Next) Categorical(Vec logWeights)
    {
        var p = Num.Softmax(logWeights);
        var (u, n) = Uniform();
        double acc = 0;
        for (int i = 0; i < p.Length; i++)
        {
            acc += p[i];
            if (u < acc) return (i, n);
        }
        return (p.Length - 1, n);
    }
}

/// <summary>Records y_i with log prior weights: the archive density p_s is
/// sum_i beta_i N(y_i, s^2 I) with beta = softmax(log weights).</summary>
public sealed record Archive(ImmutableArray<Vec> Records, Vec LogWeights)
{
    public int Dim => Records[0].Length;

    public double LogDensity(Vec x, double s)
    {
        double lz = Num.LogSumExp(LogWeights), d = Dim;
        var terms = Records.Select((y, i) => LogWeights[i] - lz
            - Num.SqDist(x, y) / (2 * s * s) - d / 2 * Math.Log(2 * Math.PI * s * s))
            .ToImmutableArray();
        return Num.LogSumExp(terms);
    }

    /// <summary>Exact draw from p_s: pick a record, add N(0, s^2 I) (Proposition 3.2).</summary>
    public (Vec Value, Rng Next) Sample(Rng rng, double s)
    {
        var (i, r) = rng.Categorical(LogWeights);
        var x = ImmutableArray.CreateBuilder<double>(Dim);
        for (int j = 0; j < Dim; j++)
        {
            double e; (e, r) = r.Normal();
            x.Add(Records[i][j] + s * e);
        }
        return (x.MoveToImmutable(), r);
    }
}

/// <summary>Gibbs target pi(x) proportional to rho(x) exp(-beta J(x)), with an
/// isotropic Gaussian base rho = N(0, rhoSd^2 I).</summary>
public sealed record GibbsTarget(Func<Vec, double> Loss, double Beta, double RhoSd)
{
    public double LogRho(Vec x) => -x.Sum(v => v * v) / (2 * RhoSd * RhoSd)
        - x.Length / 2.0 * Math.Log(2 * Math.PI * RhoSd * RhoSd);

    public double LogUnnormalised(Vec x) => LogRho(x) - Beta * Loss(x);
}

/// <summary>Result of a self-normalised importance-sampling run.</summary>
public sealed record SnisResult(double Estimate, double EssFraction, double MaxWeightShare);

public static class Estimation
{
    /// <summary>Self-normalised importance sampling from log target and log proposal values.</summary>
    public static SnisResult Snis(Vec logTarget, Vec logProposal, Vec f)
    {
        var lw = logTarget.Zip(logProposal, (a, b) => a - b).ToImmutableArray();
        var w = Num.Softmax(lw);
        double est = w.Zip(f, (a, b) => a * b).Sum();
        double ess = 1.0 / w.Sum(v => v * v) / w.Length;
        return new SnisResult(est, ess, w.Max());
    }

    /// <summary>Proposition 3.3: 1 + chi^2 for N(0, sp^2) against N(0, sq^2) in each of
    /// d independent coordinates; infinite unless 2 sq^2 &gt; sp^2.</summary>
    public static double GaussianSecondMoment(double sp, double sq, int d) =>
        2 * sq * sq <= sp * sp ? double.PositiveInfinity
            : Math.Pow(sq * sq / (sp * Math.Sqrt(2 * sq * sq - sp * sp)), d);

    /// <summary>Theorem 3.5: weight bound 1/(eps Z) of the defensive mixture
    /// (1 - eps) q + eps rho, when the loss is non-negative.</summary>
    public static double DefensiveBound(double eps, double z) => 1.0 / (eps * z);

    /// <summary>Lemma 4.1 and Proposition 4.2: total-variation bound when every
    /// multiplicative weight error lies in an interval of log-width kappa.</summary>
    public static double TvBound(double kappa) => Math.Tanh(kappa / 4);

    public static double Tv(Vec a, Vec b) => 0.5 * a.Zip(b, (p, q) => Math.Abs(p - q)).Sum();

    /// <summary>Reweights a finite law by exp(logFactor) and renormalises.</summary>
    public static Vec Reweight(Vec p, Vec logFactor) =>
        Num.Softmax(p.Zip(logFactor, (a, l) => Math.Log(a) + l).ToImmutableArray());
}

public static class Num
{
    public static double LogSumExp(Vec v)
    {
        double m = v.Max();
        return m + Math.Log(v.Sum(x => Math.Exp(x - m)));
    }

    public static Vec Softmax(Vec v)
    {
        double l = LogSumExp(v);
        return v.Select(x => Math.Exp(x - l)).ToImmutableArray();
    }

    public static double SqDist(Vec a, Vec b) => a.Zip(b, (p, q) => (p - q) * (p - q)).Sum();
}
