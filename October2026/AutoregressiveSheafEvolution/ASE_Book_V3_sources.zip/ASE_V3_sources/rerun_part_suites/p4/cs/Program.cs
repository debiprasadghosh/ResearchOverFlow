// Driver for the Part IV kernel. Every line is recomputed by cs_validate.py from the same stream.
using System;
using System.Collections.Immutable;
using System.Globalization;
using System.Linq;
using AsePartFour;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

static string F(double x) => x.ToString("R", CultureInfo.InvariantCulture);
static void Print(string name, params double[] xs) =>
    Console.WriteLine(name + " " + string.Join(" ", xs.Select(F)));
static Vec V(params double[] x) => x.ToImmutableArray();

var rng = new Rng(20261021UL);
var target = new GibbsTarget(x => Math.Pow(x[0] * x[0] - 1, 2) + 0.5 * x[1] * x[1], 4.0, 2.0);

// an archive of 40 records drawn from rho, weighted by exp(-beta J) (Proposition 2.3)
var recs = ImmutableArray.CreateBuilder<Vec>(40);
for (int i = 0; i < 40; i++)
{
    double a, b; (a, rng) = rng.Normal(); (b, rng) = rng.Normal();
    recs.Add(V(2.0 * a, 2.0 * b));
}
var records = recs.MoveToImmutable();
var archive = new Archive(records,
    records.Select(y => -target.Beta * target.Loss(y)).ToImmutableArray());
Print("archive_first", records[0][0], records[0][1], archive.LogWeights[0]);
Print("log_density", archive.LogDensity(V(0.9, 0.1), 0.5), archive.LogDensity(V(-1.1, 0.4), 0.2));

// self-normalised importance sampling of P(x1 > 0.5) from p_s and from a defensive mixture
foreach (var s in new[] { 0.2, 0.5, 1.0 })
{
    var xs = ImmutableArray.CreateBuilder<Vec>(2000);
    for (int k = 0; k < 2000; k++) { Vec x; (x, rng) = archive.Sample(rng, s); xs.Add(x); }
    var X = xs.MoveToImmutable();
    var lt = X.Select(target.LogUnnormalised).ToImmutableArray();
    var lq = X.Select(x => archive.LogDensity(x, s)).ToImmutableArray();
    var f = X.Select(x => x[0] > 0.5 ? 1.0 : 0.0).ToImmutableArray();
    var r = Estimation.Snis(lt, lq, f);
    Print($"snis_s{s.ToString(CultureInfo.InvariantCulture)}", r.Estimate, r.EssFraction, r.MaxWeightShare);
}

// Proposition 3.3 and Theorem 3.4
Print("gauss_second_moment", Estimation.GaussianSecondMoment(1, 1.5, 1),
      Estimation.GaussianSecondMoment(1, 1.5, 16), Estimation.GaussianSecondMoment(1, 0.7, 1));
Print("defensive_bound", Estimation.DefensiveBound(0.1, 0.25), Estimation.DefensiveBound(0.3, 0.25));

// Proposition 4.1: the two-atom case attains tanh(beta eps / 2)
double be = 2.0, ep = 0.7, p = 1 / (1 + Math.Exp(be * ep));
var two = V(p, 1 - p);
var moved = Estimation.Reweight(two, V(be * ep, -be * ep));
Print("two_atom", Estimation.Tv(two, moved), Estimation.TvBound(2 * be * ep));

// Lemma 5.1 on 1000 random finite laws
double worst = 0;
for (int t = 0; t < 1000; t++)
{
    var lw = ImmutableArray.CreateBuilder<double>(6);
    var lf = ImmutableArray.CreateBuilder<double>(6);
    double kap; (kap, rng) = rng.Uniform(); kap = 0.01 + 3 * kap;
    for (int i = 0; i < 6; i++)
    {
        double a, u; (a, rng) = rng.Normal(); (u, rng) = rng.Uniform();
        lw.Add(a); lf.Add(kap * (u < 0.5 ? 0.0 : 1.0));
    }
    var law = Num.Softmax(lw.MoveToImmutable());
    var tv = Estimation.Tv(law, Estimation.Reweight(law, lf.MoveToImmutable()));
    worst = Math.Max(worst, tv / Estimation.TvBound(kap));
}
Print("lemma_worst_ratio", worst);
