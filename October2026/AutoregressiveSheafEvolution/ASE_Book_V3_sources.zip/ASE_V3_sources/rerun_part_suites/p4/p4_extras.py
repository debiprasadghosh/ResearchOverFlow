"""Supplementary results for Part IV, read from and added to p4_checks.json: elite hulls, the width
threshold of Proposition 3.5, the three bounds of Theorem 3.4, and the ledger verdicts."""
import json, math, os
import numpy as np
from scipy.spatial import Delaunay
HERE = os.path.dirname(os.path.abspath(__file__))
R = json.load(open(os.path.join(HERE, "p4_checks.json")))
rng = np.random.default_rng(20261021)
BETA, RHO_SD = 4.0, 2.0
J = lambda X: (X[:, 0] ** 2 - 1) ** 2 + 0.5 * X[:, 1] ** 2
Y = rng.normal(0, RHO_SD, (40, 2)); lw = -BETA * J(Y)          # same first draw as p4_checks.py
g = np.linspace(-6, 6, 961); h = g[1] - g[0]
GX, GY = np.meshgrid(g, g, indexing="ij"); G = np.column_stack([GX.ravel(), GY.ravel()])
lu = -(G ** 2).sum(1) / 8 - BETA * J(G); pi = np.exp(lu); pi /= pi.sum() * h * h
f2 = (G[:, 0] > 0.5)
el = []
for k in (4, 8, 16, 40):
    top = Y[np.argsort(-lw)[:k]]
    if k == 4 or np.linalg.matrix_rank(top[1:] - top[0]) < 2:
        pass
    out = Delaunay(top).find_simplex(G) < 0
    el.append(dict(k=k, missing=float((pi * out).sum() * h * h), f2_inside=float((pi * ~out * f2).sum() / (pi * ~out).sum())))
sig2 = 1 / (2 * (1 / (2 * RHO_SD ** 2) + BETA * 0.5))
thr = math.sqrt(sig2) / math.sqrt(2)
rows = R["scan"]["rows"]
for r in rows:
    r["finite"] = r["s"] > thr
    if not r["finite"]:
        r["m2"] = math.inf
fin = [r for r in rows if r["finite"]]
m2rho = R["scan"]["rho_only_m2"]
viol = sum(r["m2_def0.1"] > min(r["m2"] / 0.9, 1 / (0.1 * R["target"]["Z"]), m2rho / 0.1) * (1 + 1e-9)
           or r["m2_def0.3"] > min(r["m2"] / 0.7, 1 / (0.3 * R["target"]["Z"]), m2rho / 0.3) * (1 + 1e-9) for r in rows)
R["extras"] = dict(elites=el, threshold=thr, sigma2=math.sqrt(sig2), def_bound_violations=viol,
                   ledger_violations=sum(r["rmse"] > r["bound"] for r in R["c10_ledger"]),
                   first_finite=min(r["s"] for r in fin))
R["scan"]["rows"] = rows
json.dump(R, open(os.path.join(HERE, "p4_checks.json"), "w"), indent=1, default=float)
print(json.dumps(R["extras"], indent=1))
