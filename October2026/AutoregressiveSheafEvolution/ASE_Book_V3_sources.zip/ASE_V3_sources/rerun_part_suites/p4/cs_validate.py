"""Recompute every line of the C# driver with NumPy from the same SplitMix64 stream; write cs_validate.json."""
import json, math, os
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
M64 = (1 << 64) - 1


class Rng:
    def __init__(self, s): self.s = s
    def u64(self):
        self.s = (self.s + 0x9E3779B97F4A7C15) & M64; z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return z ^ (z >> 31)
    def uniform(self): return (self.u64() >> 11) * (1.0 / 9007199254740992.0)
    def normal(self):
        u1 = self.uniform(); u2 = self.uniform()
        return math.sqrt(-2 * math.log(1 - u1)) * math.cos(2 * math.pi * u2)
    def categorical(self, lw):
        p = np.exp(lw - np.logaddexp.reduce(lw)); u = self.uniform(); c = np.cumsum(p)
        i = int(np.searchsorted(c, u, side="right")); return min(i, len(p) - 1)


J = lambda x: (x[..., 0] ** 2 - 1) ** 2 + 0.5 * x[..., 1] ** 2
beta, sd = 4.0, 2.0
logt = lambda X: -(X ** 2).sum(-1) / (2 * sd * sd) - math.log(2 * math.pi * sd * sd) - beta * J(X)
def logq(X, Y, lw, s):
    lb = lw - np.logaddexp.reduce(lw); d2 = ((X[:, None] - Y[None]) ** 2).sum(-1)
    return np.logaddexp.reduce(lb[None] - d2 / (2 * s * s) - math.log(2 * math.pi * s * s), axis=1)

rng = Rng(20261021); out = []
Y = np.array([[2 * rng.normal(), 2 * rng.normal()] for _ in range(40)]); lw = -beta * J(Y)
out.append(("archive_first", [Y[0, 0], Y[0, 1], lw[0]]))
out.append(("log_density", [logq(np.array([[0.9, 0.1]]), Y, lw, .5)[0], logq(np.array([[-1.1, .4]]), Y, lw, .2)[0]]))
for s in (0.2, 0.5, 1.0):
    X = []
    for _ in range(2000):
        i = rng.categorical(lw); X.append([Y[i, 0] + s * rng.normal(), Y[i, 1] + s * rng.normal()])
    X = np.array(X); l = logt(X) - logq(X, Y, lw, s); w = np.exp(l - np.logaddexp.reduce(l))
    out.append((f"snis_s{s:g}", [float((w * (X[:, 0] > .5)).sum()), 1 / (w ** 2).sum() / len(w), w.max()]))
m2 = lambda sp, sq, d: math.inf if 2 * sq * sq <= sp * sp else (sq * sq / (sp * math.sqrt(2 * sq * sq - sp * sp))) ** d
out.append(("gauss_second_moment", [m2(1, 1.5, 1), m2(1, 1.5, 16), m2(1, .7, 1)]))
out.append(("defensive_bound", [1 / (.1 * .25), 1 / (.3 * .25)]))
p = 1 / (1 + math.exp(1.4)); a = np.array([p, 1 - p]); b = a * np.exp([1.4, -1.4]); b /= b.sum()
out.append(("two_atom", [0.5 * abs(a - b).sum(), math.tanh(2 * 1.4 / 4)]))
worst = 0
for _ in range(1000):
    kap = 0.01 + 3 * rng.uniform(); l = []; f = []
    for i in range(6):
        l.append(rng.normal()); f.append(0.0 if rng.uniform() < .5 else kap)
    law = np.exp(np.array(l) - np.logaddexp.reduce(l)); nb = law * np.exp(f); nb /= nb.sum()
    worst = max(worst, 0.5 * abs(law - nb).sum() / math.tanh(kap / 4))
out.append(("lemma_worst_ratio", [worst]))

cs = [l.split() for l in open(os.path.join(HERE, "cs", "cs_out.txt")).read().splitlines() if l.strip()]
rows = []; ok = True
for (name, py), c in zip(out, cs):
    assert c[0] == name, (c[0], name)
    cv = [float(t) for t in c[1:]]
    rel = max(0.0 if (math.isinf(x) and math.isinf(y)) else abs(x - y) / max(abs(y), 1e-300) for x, y in zip(cv, py))
    ok = bool(ok and rel < 1e-12)
    rows.append(dict(name=name, csharp=" ".join(c), python=name + " " + " ".join(repr(float(v)) for v in py), rel=float(rel)))
json.dump(dict(rows=rows, all_agree=ok, max_rel=max(r["rel"] for r in rows)), open(os.path.join(HERE, "cs_validate.json"), "w"), indent=1)
for r in rows: print(r["name"], r["rel"])
print("ALL", ok)
