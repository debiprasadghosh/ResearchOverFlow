# Further checks for ASE Part II: results derived after the first register. Every number is written to p2_extras.json.
import json, math, os
import numpy as np
import p2_checks as P

here = os.path.dirname(os.path.abspath(__file__))
rng = np.random.default_rng(20261021)
P.rng = rng                                  # random_setup draws from this generator as well
X = {}
KINDS = ["general", "mask", "partial", "orth"]


def null_basis(H, tol=1e-9):
    w, V = np.linalg.eigh(H)
    return V[:, w <= tol * max(1.0, w.max())]


def normal_parts(z, Qs, obs, a):
    H = sum(ai * Q.T @ Q for ai, Q in zip(a, Qs)); b = sum(ai * Q.T @ o for ai, Q, o in zip(a, Qs, obs))
    return H, b


# ---------------------------------------------------------------- E0. minimal star energy is a Schur complement
def check_schur_energy():
    err = 0.0
    for _ in range(300):
        D, Qs, _, _ = P.random_setup("general")
        n = len(Qs); c = rng.uniform(0.2, 2.0, n); dims = [int(rng.integers(1, 4)) for _ in range(n)]
        Rs = [rng.standard_normal((Q.shape[0], d)) for Q, d in zip(Qs, dims)]
        ys = [rng.standard_normal(d) for d in dims]
        off = np.concatenate([[0, D], D + np.cumsum(dims)]); rows = []
        for i, (Q, Rr) in enumerate(zip(Qs, Rs)):
            blk = np.zeros((Q.shape[0], off[-1])); blk[:, :D] = -Q; blk[:, off[i + 1]:off[i + 2]] = Rr
            rows.append(np.sqrt(c[i]) * blk)
        d = np.vstack(rows); L = d.T @ d; yb = np.concatenate(ys)
        S = L[D:, D:] - L[D:, :D] @ np.linalg.solve(L[:D, :D], L[:D, D:])
        G = sum(ci * Q.T @ Q for ci, Q in zip(c, Qs))
        m = np.linalg.solve(G, sum(ci * Q.T @ Rr @ y for ci, Q, Rr, y in zip(c, Qs, Rs, ys)))
        fmin = sum(ci * float(np.sum((Q @ m - Rr @ y) ** 2)) for ci, Q, Rr, y in zip(c, Qs, Rs, ys))
        err = max(err, abs(fmin - float(yb @ S @ yb)) / (1 + abs(fmin)))
    X["schur_energy"] = dict(cases=300, rel_err=err)


# ---------------------------------------------------------------- E1. the retention read
def check_retention():
    """Compare the read with an independent nearest minimiser (least squares plus a projection), and test the
    token-anchored ridge limit at ridge strengths relative to the smallest resolved eigenvalue."""
    res = near = 0.0; ridge = {1e-2: 0.0, 1e-4: 0.0, 1e-6: 0.0}; cases = 0
    for _ in range(300):
        D = int(rng.integers(3, 7)); r = int(rng.integers(1, D)); B = np.linalg.qr(rng.standard_normal((D, r)))[0]
        n = int(rng.integers(2, 7))
        Qs = [rng.standard_normal((int(rng.integers(1, r + 1)), r)) @ B.T for _ in range(n)]
        obs = [Q @ rng.standard_normal(D) + 0.3 * rng.standard_normal(Q.shape[0]) for Q in Qs]
        logw = rng.normal(0, 0.5, n); z = rng.standard_normal(D); s = float(rng.uniform(0.5, 2.0))
        a, H, b, m = P.read(z, Qs, obs, logw, s)
        w, V = np.linalg.eigh(H); cut = 1e-10 * max(1.0, w.max()); keep = w > cut
        if keep.all():
            continue
        cases += 1
        mk = z + V[:, keep] @ ((V[:, keep].T @ (b - H @ z)) / w[keep])          # the kernel's rule
        x0 = np.linalg.lstsq(H, b, rcond=None)[0]
        U, sv, Vt = np.linalg.svd(H); N = Vt[sv <= cut].T
        xs = x0 + N @ (N.T @ (z - x0))                                        # nearest minimiser, computed independently
        near = max(near, float(np.abs(xs - mk).max()) / (1 + float(np.abs(mk).max())))
        res = max(res, float(np.abs(V[:, keep].T @ (H @ mk - b)).max()))
        step = float(np.linalg.norm(mk - z)); lp = float(w[keep].min())
        for tr in ridge:
            tau = tr * lp; mt = np.linalg.solve(H + tau * np.eye(D), b + tau * z)
            Vk = V[:, keep]                                                    # compare on the resolved directions
            ridge[tr] = max(ridge[tr], float(np.linalg.norm(Vk.T @ (mt - mk))) / max(step, 1e-300))
    X["retention"] = dict(cases=cases, resolved_residual=res, nearest_minimiser_err=near,
                          ridge_rel_err={f"{k:g}": v for k, v in ridge.items()})


# ---------------------------------------------------------------- E2. chart posterior versus sheaf read
def check_chart_vs_sheaf():
    err = werr = 0.0; gaps = []
    for _ in range(200):
        D = int(rng.integers(2, 7)); k = int(rng.integers(1, D))
        U = np.linalg.qr(rng.standard_normal((D, k)))[0]; A = np.diag(1 / rng.uniform(0.5, 2.0, k)) @ U.T
        n = int(rng.integers(3, 10)); Y = 1.5 * rng.standard_normal((n, D)); logw = rng.normal(0, 0.5, n)
        z = rng.standard_normal(D); s = float(rng.uniform(0.5, 2.0))
        a = P.softmax(logw - np.sum((Y @ A.T - A @ z) ** 2, 1) / (2 * s * s))
        m_chart = a @ Y
        at = 1 / (1 + s * s); q = math.sqrt(at) * A @ z                       # the ADE level with s^2 = (1 - a)/a
        a_ade = P.softmax(logw - np.sum((q - math.sqrt(at) * Y @ A.T) ** 2, 1) / (2 * (1 - at)))
        werr = max(werr, float(np.abs(a - a_ade).max()))
        _, H, b, m_sheaf = P.read(z, [A] * n, [A @ y for y in Y], logw, s)
        Pa = np.linalg.pinv(A) @ A
        err = max(err, float(np.abs(m_chart - m_sheaf - (np.eye(D) - Pa) @ (m_chart - z)).max()))
        gaps.append(float(np.linalg.norm(m_chart - m_sheaf)))
    X["chart_vs_sheaf"] = dict(cases=200, weight_err=werr, difference_err=err, median_gap=float(np.median(gaps)))


# ---------------------------------------------------------------- E3. a bound on the Jacobian of sheaf attention
def diam(vs):
    return max((float(np.linalg.norm(p - q)) for p in vs for q in vs), default=0.0)


def check_jacobian_bound():
    viol = 0; worst = 0.0; orth = []; cent = 0.0; cases = 0; chain = 0
    for t in range(600):
        kind = KINDS[t % 4]
        D, Qs, obs, logw = P.random_setup(kind)
        z = rng.standard_normal(D); s = float(rng.uniform(0.5, 3.0))
        J, a, H, m = P.jacobian_formula(z, Qs, obs, logw, s)
        if np.linalg.cond(H) > 1e8:
            continue
        cases += 1
        u = [Q.T @ (Q @ m - o) for Q, o in zip(Qs, obs)]; g = [Q.T @ (Q @ z - o) for Q, o in zip(Qs, obs)]
        cent = max(cent, float(np.linalg.norm(sum(ai * ui for ai, ui in zip(a, u)))))
        gb = sum(ai * gi for ai, gi in zip(a, g))
        Cu = sum(ai * np.outer(ui, ui) for ai, ui in zip(a, u)); Cg = sum(ai * np.outer(gi - gb, gi - gb) for ai, gi in zip(a, g))
        lam = float(np.linalg.eigvalsh(H).min())
        B1 = math.sqrt(np.linalg.norm(Cu, 2) * np.linalg.norm(Cg, 2)) / (s * s * lam)
        B2 = diam(u) * diam(g) / (4 * s * s * lam)
        nJ = float(np.linalg.norm(J, 2))
        viol += nJ > B1 * (1 + 1e-9) + 1e-12; chain += B1 > B2 * (1 + 1e-9) + 1e-12
        if B1 > 1e-12:
            worst = max(worst, nJ / B1)
        if kind == "orth":
            orth.append(nJ / B1)
    X["jacobian_bound"] = dict(cases=cases, violations=viol, chain_violations=chain, worst_ratio=worst,
                               orth_cases=len(orth), orth_ratio_min=float(min(orth)), orth_ratio_max=float(max(orth)),
                               centring_err=cent)


# ---------------------------------------------------------------- E4. an a posteriori certificate for rectangular truncation
def check_rect_certificate():
    out = {}
    for family in ["full-rank maps", "mixed-rank maps"]:
        tests = vac = sing = viol = 0; ratios = []; rows = {}
        for arch in range(16):
            D = int(rng.integers(2, 5)); n = 300
            Qs = []
            for _ in range(n):
                k = D if family == "full-rank maps" else int(rng.integers(1, D + 1))
                Qs.append(rng.standard_normal((k, D)) * rng.uniform(0.6, 1.2))
            Y = rng.uniform(0, 10, (n, D)); obs = [Q @ y for Q, y in zip(Qs, Y)]
            w = rng.uniform(0.5, 1.5, n); Wtot = float(w.sum())
            Aflat = np.array([(Q.T @ Q).ravel() for Q in Qs]); cH = 0.0
            for i in range(n - 1):
                cH = max(cH, float(np.max(np.linalg.norm((Aflat[i + 1:] - Aflat[i]).reshape(-1, D, D), 2, axis=(1, 2)))))
            C = np.array([Q.T @ o for Q, o in zip(Qs, obs)]); Rb = float(max(np.linalg.norm(C - c, axis=1).max() for c in C))
            for _ in range(8):
                z = rng.uniform(0, 10, D); s = float(rng.choice([0.5, 1.0, 2.0]))
                e = np.array([0.5 * float(np.sum((Q @ z - o) ** 2)) for Q, o in zip(Qs, obs)])
                lk = np.log(w) - e / (s * s); kk = np.exp(lk - lk.max()); scale = math.exp(lk.max())
                a = kk / kk.sum(); H, b = normal_parts(z, Qs, obs, a); m = np.linalg.solve(H, b)
                for c in [2.0, 3.0, 4.0, 5.0, 6.0]:
                    rho = c * s; S = e <= rho * rho / 2
                    if not S.any():
                        continue
                    aS = np.where(S, kk, 0.0); KS = float(aS.sum()) * scale; aS = aS / aS.sum()
                    HS, bS = normal_parts(z, Qs, obs, aS); lamS = float(np.linalg.eigvalsh(HS).min())
                    tests += 1
                    if lamS < 1e-9:
                        sing += 1; continue
                    mS = np.linalg.solve(HS, bS)
                    Fbar = min(1.0, (Wtot - float(w[S].sum())) * math.exp(-rho * rho / (2 * s * s)) / KS)
                    den = lamS - Fbar * cH
                    if den <= 0:
                        vac += 1; continue
                    cert = Fbar * (Rb + cH * float(np.linalg.norm(mS))) / den
                    err = float(np.linalg.norm(m - mS)); viol += err > cert * (1 + 1e-9) + 1e-12
                    ratios.append(err / cert if cert > 0 else 0.0)
                    rows.setdefault(f"{s:g}|{c:g}", []).append((float(S.mean()), cert / Rb))
        out[family] = dict(archives=16, records=300, tests=tests, singular_star=sing, vacuous=vac, finite=len(ratios),
                           violations=viol, worst_ratio=float(max(ratios)), median_ratio=float(np.median(ratios)),
                           by_radius={k: dict(n=len(v), mean_share=float(np.mean([x[0] for x in v])),
                                              median_cert_over_Rb=float(np.median([x[1] for x in v])))
                                      for k, v in sorted(rows.items(), key=lambda kv: tuple(map(float, kv[0].split("|"))))})
    X["rect_certificate"] = out


# ---------------------------------------------------------------- E5. tilting the product law in a stalk
def check_tilt_law():
    err = 0.0
    for _ in range(100):
        U = np.linalg.qr(rng.standard_normal((2, 2)))[0]; H = U @ np.diag(rng.uniform(0.3, 2.0, 2)) @ U.T
        m = rng.standard_normal(2); s = float(rng.uniform(0.5, 1.5)); beta = float(rng.uniform(0.1, 2.0))
        a = rng.standard_normal(2); mu = m - beta * s * s * np.linalg.solve(H, a)
        Sig = s * s * np.linalg.inv(H); sd = np.sqrt(np.diag(Sig))
        g1 = np.linspace(mu[0] - 10 * sd[0], mu[0] + 10 * sd[0], 801); g2 = np.linspace(mu[1] - 10 * sd[1], mu[1] + 10 * sd[1], 801)
        X1, X2 = np.meshgrid(g1, g2); Pt = np.stack([X1.ravel(), X2.ravel()], 1); d = Pt - m
        lw = -np.einsum("ij,jk,ik->i", d, H, d) / (2 * s * s) - beta * Pt @ a
        wt = np.exp(lw - lw.max()); mean = wt @ Pt / wt.sum()
        err = max(err, float(np.abs(mean - mu).max() / (1 + np.abs(mu).max())))
    masses = {}
    for name, a in [("slope along the unobserved axis", np.array([0.3, 0.5])), ("no slope there", np.array([0.3, 0.0]))]:
        out = []
        for L in [5, 10, 20, 40]:
            g = np.linspace(-L, L, 1601); X1, X2 = np.meshgrid(g, g)
            val = np.exp(-X1 ** 2 / 2 - (a[0] * X1 + a[1] * X2))
            out.append(float(val.sum() * (g[1] - g[0]) ** 2))
        masses[name] = out
    X["tilt_law"] = dict(cases=100, mean_rel_err=err, box_half_widths=[5, 10, 20, 40], masses=masses)


# ---------------------------------------------------------------- E6. the projector read under bounded measurement error
def check_projector_measurement():
    v1 = v2 = 0; w1 = w2 = 0.0; trials = 400
    for _ in range(trials):
        D, k = int(rng.integers(3, 7)), int(rng.integers(1, 3))
        base = np.linalg.qr(rng.standard_normal((D, k)))[0]; Ps = []
        for _ in range(int(rng.integers(3, 9))):
            U = np.linalg.qr(base + 0.4 * rng.standard_normal((D, k)))[0]; Ps.append(U @ U.T)
        a = P.softmax(rng.normal(0, 1, len(Ps))); beta, eps = float(rng.uniform(0.1, 5)), float(rng.uniform(0.01, 0.5))
        a2 = a * np.exp(-beta * rng.uniform(-eps, eps, len(a))); a2 /= a2.sum()
        Pb = sum(x * p for x, p in zip(a, Ps)); Pb2 = sum(x * p for x, p in zip(a2, Ps))
        tv = 0.5 * float(np.abs(a - a2).sum()); pmax = max(float(np.linalg.norm(p - q, 2)) for p in Ps for q in Ps)
        dP = float(np.linalg.norm(Pb2 - Pb, 2))
        v1 += dP > tv * pmax + 1e-12
        if tv * pmax > 1e-12:
            w1 = max(w1, dP / (tv * pmax))
        w, V = np.linalg.eigh(Pb); w_, V_ = np.linalg.eigh(Pb2); gap = w[-k] - w[-k - 1]
        U1, U2 = V[:, -k:], V_[:, -k:]; sin = float(np.linalg.norm(U2 - U1 @ (U1.T @ U2), 2))
        bound = 2 * math.tanh(beta * eps / 2) * pmax / gap
        v2 += sin > bound + 1e-12; w2 = max(w2, sin / bound)
    X["projector_measurement"] = dict(trials=trials, perturbation_violations=v1, perturbation_worst=w1,
                                      subspace_violations=v2, subspace_worst=w2)


# ---------------------------------------------------------------- E7. deterministic ADE layers descend at their own scale
def check_ade_descent():
    T = 16; a = np.cos(np.pi * np.arange(T + 1) / (2 * T)) ** 2; a[T] = 1e-4
    lam = np.array([1 - math.sqrt(a[t] * (1 - a[t - 1]) / (a[t - 1] * (1 - a[t]))) for t in range(1, T + 1)])
    steps = viol = 0; worst = math.inf
    for _ in range(100):
        D, n = int(rng.integers(1, 6)), int(rng.integers(3, 30))
        Y = 2 * rng.standard_normal((n, D)); logw = rng.normal(0, 1, n); z = rng.standard_normal(D) / math.sqrt(a[T])
        for t in range(T, 0, -1):
            s = math.sqrt((1 - a[t]) / a[t]); l = lam[t - 1]
            _, _, _, m = P.read(z, [np.eye(D)] * n, list(Y), logw, s)
            E0 = P.energy(z, [np.eye(D)] * n, list(Y), logw, s); zn = (1 - l) * z + l * m
            E1 = P.energy(zn, [np.eye(D)] * n, list(Y), logw, s); g = 0.5 * l * (2 - l) * float(np.sum((z - m) ** 2))
            steps += 1; viol += E1 > E0 - g + 1e-10 * (1 + abs(E0))
            if g > 1e-9:
                worst = min(worst, (E0 - E1) / g)
            z = zn
    X["ade_descent"] = dict(layers=T, lambda_min=float(lam.min()), lambda_max=float(lam.max()), lambdas=lam.tolist(),
                            archives=100, steps=steps, violations=viol, worst_ratio=worst)


# ---------------------------------------------------------------- E8. the exact spectrum of c1 P1 + c2 P2
def check_two_subspace_spectrum():
    err = 0.0; trials = 500; mids = 0
    for _ in range(trials):
        D = int(rng.integers(2, 8)); k1 = int(rng.integers(1, D + 1)); k2 = int(rng.integers(1, D + 1))
        U1 = np.linalg.qr(rng.standard_normal((D, k1)))[0]; U2 = np.linalg.qr(rng.standard_normal((D, k2)))[0]
        if rng.random() < 0.3:
            U2[:, 0] = U1[:, 0]; U2 = np.linalg.qr(U2)[0]
        if rng.random() < 0.2 and k1 + k2 <= D:
            U2 = np.linalg.qr(U2 - U1 @ (U1.T @ U2))[0]
        c1, c2 = rng.uniform(0.1, 3.0, 2)
        ev = np.sort(np.linalg.eigvalsh(c1 * U1 @ U1.T + c2 * U2 @ U2.T))
        cos = np.clip(np.linalg.svd(U1.T @ U2, compute_uv=False), 0, 1)
        zero = int((cos > 1 - 1e-9).sum()); right = int((cos < 1e-9).sum())
        mid = [math.acos(x) for x in cos if 1e-9 <= x <= 1 - 1e-9]; mids += len(mid)
        pred = [c1 + c2] * zero
        if k1 <= k2:
            pred += [c1] * right + [c2] * (k2 - zero - len(mid))
        else:
            pred += [c2] * right + [c1] * (k1 - zero - len(mid))
        for th in mid:
            r = math.sqrt((c1 + c2) ** 2 - 4 * c1 * c2 * math.sin(th) ** 2)
            pred += [(c1 + c2 + r) / 2, (c1 + c2 - r) / 2]
        pred += [0.0] * (D - len(pred))
        err = max(err, float(np.abs(np.sort(pred) - ev).max()))
    X["two_subspace_spectrum"] = dict(trials=trials, interior_angles=mids, max_err=err)


# ---------------------------------------------------------------- E9. the coordinatewise ceiling and beating the best record
def check_coordinate_ceiling():
    viol = beat = cases = 0
    for _ in range(400):
        D, n = 4, 6
        while True:
            masks = [np.sort(rng.choice(D, int(rng.integers(1, D)), replace=False)) for _ in range(n)]
            if len(set(np.concatenate(masks))) == D:
                break
        Qs = [np.eye(D)[S] for S in masks]; ys = [rng.standard_normal(D) for _ in range(n)]
        obs = [Q @ y for Q, y in zip(Qs, ys)]; z = rng.standard_normal(D); s = float(rng.uniform(0.5, 3.0))
        logw = rng.normal(0, 0.5, n); a, H, b, m = P.read(z, Qs, obs, logw, s)
        cover = [sum(a[i] for i in range(n) if j in masks[i]) for j in range(D)]
        if min(cover) < 1e-8:
            continue
        cases += 1; c = rng.standard_normal(D)
        floor = sum(min(c[j] * ys[i][j] for i in range(n) if j in masks[i]) for j in range(D))
        viol += float(c @ m) < floor - 1e-12; beat += float(c @ m) < min(float(c @ y) for y in ys)
    X["coordinate_ceiling"] = dict(cases=cases, floor_violations=viol, beats_best_record=beat)


# ---------------------------------------------------------------- E10. the Hessian of the soft energy and the Euclidean step
def check_hessian_and_step():
    herr = 0.0; viol = 0; worst = math.inf; trials = 300
    for t in range(trials):
        D, Qs, obs, logw = P.random_setup(KINDS[t % 4])
        z = rng.standard_normal(D); s = float(rng.uniform(0.5, 3.0))
        a, H, b, m = P.read(z, Qs, obs, logw, s)
        g = [Q.T @ (Q @ z - o) for Q, o in zip(Qs, obs)]; gb = sum(ai * gi for ai, gi in zip(a, g))
        Hess = H - sum(ai * np.outer(gi - gb, gi - gb) for ai, gi in zip(a, g)) / (s * s)
        grad = lambda x: (lambda r: r[1] @ (x - r[3]))(P.read(x, Qs, obs, logw, s))
        h = 1e-6; Hfd = np.column_stack([(grad(z + h * e) - grad(z - h * e)) / (2 * h) for e in np.eye(D)])
        herr = max(herr, float(np.abs(Hfd - Hess).max() / (1 + np.abs(Hess).max())))
        cA = max(float(np.linalg.norm(Q.T @ Q, 2)) for Q in Qs); gr = H @ (z - m)
        lam = float(rng.uniform(0.0, 2.0 / cA)); E0 = P.energy(z, Qs, obs, logw, s)
        E1 = P.energy(z - lam * gr, Qs, obs, logw, s); guaranteed = lam * (1 - lam * cA / 2) * float(gr @ gr)
        viol += E1 > E0 - guaranteed + 1e-10 * (1 + abs(E0))
        if guaranteed > 1e-9:
            worst = min(worst, (E0 - E1) / guaranteed)
    X["hessian_and_step"] = dict(trials=trials, hessian_rel_err=herr, step_violations=viol, step_worst_ratio=worst)


# ---------------------------------------------------------------- E11. repeated imputation converges to the harmonic read
def check_cimmino():
    rate_viol = 0; final = 0.0; conv = 0; trials = 200
    for t in range(trials):
        D, Qs, obs, logw = P.random_setup(["mask", "partial"][t % 2])
        z = rng.standard_normal(D); s = float(rng.uniform(0.5, 3.0))
        a, H, b, m = P.read(z, Qs, obs, logw, s); lam = float(np.linalg.eigvalsh(H).min())
        x = z.copy(); e0 = float(np.linalg.norm(z - m))
        for k in range(1, 2001):
            x = sum(ai * (Q.T @ o + x - Q.T @ (Q @ x)) for ai, Q, o in zip(a, Qs, obs))
            if k == 50:
                rate_viol += float(np.linalg.norm(x - m)) > (1 - lam) ** 50 * e0 * (1 + 1e-9) + 1e-12
        if lam > 0.05:
            conv += 1; final = max(final, float(np.linalg.norm(x - m)))
    X["cimmino"] = dict(trials=trials, rate_violations_at_50=rate_viol, well_covered=conv, final_err=final)


# ---------------------------------------------------------------- E12. stationary points: minima attract, saddles repel
def check_stationary():
    ident = 0.0; rho_max = 0.0; minima = 0
    for t in range(80):
        D, Qs, obs, logw = P.random_setup(["general", "mask", "partial"][t % 3])
        s = float(rng.uniform(0.7, 2.0)); z = rng.standard_normal(D)
        for _ in range(3000):
            z = P.read(z, Qs, obs, logw, s)[3]
        J, a, H, m = P.jacobian_formula(z, Qs, obs, logw, s)
        if np.linalg.eigvalsh(H).min() < 1e-6:
            continue
        g = [Q.T @ (Q @ z - o) for Q, o in zip(Qs, obs)]; gb = sum(ai * gi for ai, gi in zip(a, g))
        Hess = H - sum(ai * np.outer(gi - gb, gi - gb) for ai, gi in zip(a, g)) / (s * s)
        if np.linalg.eigvalsh(Hess).min() <= 1e-9:
            continue
        minima += 1
        ident = max(ident, float(np.abs(J - (np.eye(D) - np.linalg.solve(H, Hess))).max()))
        rho_max = max(rho_max, float(np.abs(np.linalg.eigvals(J)).max()))
    saddles = []
    for s in [0.5, 0.8]:
        Qs = [np.array([[1.0, 0.0]]), np.array([[1.0, 0.0]]), np.array([[0.0, 1.0]])]
        obs = [np.array([1.0]), np.array([-1.0]), np.array([0.5])]; logw = np.zeros(3); z = np.array([0.0, 0.5])
        J, a, H, m = P.jacobian_formula(z, Qs, obs, logw, s)
        saddles.append(dict(s=s, stationary_err=float(np.abs(m - z).max()),
                            leading_eigenvalue=float(np.abs(np.linalg.eigvals(J)).max())))
    X["stationary"] = dict(minima=minima, identity_err=ident, spectral_radius_max=rho_max, saddles=saddles)


# ---------------------------------------------------------------- E13. indexing modulo a finite group
def canon_dihedral(x, k=6):
    r = np.hypot(x[:, 0], x[:, 1]); ph = np.mod(np.arctan2(x[:, 1], x[:, 0]), 2 * math.pi / k)
    ph = np.where(ph > math.pi / k, 2 * math.pi / k - ph, ph)
    return np.stack([r * np.cos(ph), r * np.sin(ph)], 1)


def orbit_dist(G, x, Y):
    return np.min(np.stack([np.linalg.norm(Y @ g.T - x, axis=1) for g in G]), 0)


def check_quotient_index():
    out = {}
    G = P.dihedral(6); xs = rng.standard_normal((2000, 2)); ys = rng.standard_normal((2000, 2))
    dG = np.array([orbit_dist(G, x, y[None])[0] for x, y in zip(xs, ys)])
    dc = np.linalg.norm(canon_dihedral(xs) - canon_dihedral(ys), axis=1)
    out["reflection group (dihedral, order 12)"] = dict(pairs=2000, max_err=float(np.abs(dG - dc).max()))
    J6 = np.eye(6)[::-1]
    cases = {"sign group in R^6": ([np.eye(6), -np.eye(6)], lambda x: x * np.where(x[:, :1] >= 0, 1.0, -1.0)),
             "mirror reversal in R^6": ([np.eye(6), J6],
                                        lambda x: np.where((x[:, 0] - x[:, 5])[:, None] >= 0, x, x @ J6.T))}
    for name, (Gs, canon) in cases.items():
        Y = rng.standard_normal((500, 6)); Yc = canon(Y); miss = 0; seam = 0; nq = 2000
        for _ in range(nq):
            j = int(rng.integers(500)); g = Gs[int(rng.integers(len(Gs)))]
            q = g @ Y[j] + 0.15 * rng.standard_normal(6)
            exact = orbit_dist(Gs, q, Y); best = float(exact.min())
            qc = canon(q[None])[0]; found = int(np.argmin(np.linalg.norm(Yc - qc, axis=1)))
            miss += exact[found] > best + 1e-12
            seam += float(np.linalg.norm(Yc[found] - qc)) > best + 1e-9
        out[name] = dict(queries=nq, nearest_missed=miss, distance_overstated=seam)
    X["quotient_index"] = out


if __name__ == "__main__":
    for fn in [check_schur_energy, check_retention, check_chart_vs_sheaf, check_jacobian_bound, check_rect_certificate,
               check_tilt_law, check_projector_measurement, check_ade_descent, check_two_subspace_spectrum,
               check_coordinate_ceiling, check_hessian_and_step, check_cimmino, check_stationary, check_quotient_index]:
        fn(); print("done", fn.__name__, flush=True)
    json.dump(X, open(os.path.join(here, "p2_extras.json"), "w"), indent=1,
              default=lambda o: o.tolist() if hasattr(o, "tolist") else (int(o) if isinstance(o, np.integer) else str(o)))
    print(json.dumps(X, indent=1, default=str))
