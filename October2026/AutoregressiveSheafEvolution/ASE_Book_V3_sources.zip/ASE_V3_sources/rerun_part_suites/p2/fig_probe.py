# probe the sheaf mean-shift example for Figure 2 before drawing it
import numpy as np, math
import p2_checks as P
Qs = [np.eye(2), np.eye(2), np.array([[0.6, 0.8]]), np.array([[1.0, 0.0]]), np.array([[0.0, 1.0]])]
obs = [np.array([-1.3, 0.9]), np.array([1.1, -0.8]), np.array([0.9]), np.array([-0.4]), np.array([-1.0])]
logw = np.zeros(5); s = 0.6
starts = [np.array([-2.0, 2.0]), np.array([2.0, 1.6]), np.array([1.8, -2.0]), np.array([-2.0, -1.8]), np.array([0.2, 0.3])]
for z0 in starts:
    z = z0.copy()
    for _ in range(200):
        z = P.read(z, Qs, obs, logw, s)[3]
    print(z0, "->", np.round(z, 4), "E", round(P.energy(z, Qs, obs, logw, s), 5))
z0 = np.array([2.0, 1.6])
for lam in [0.5, 1.0, 1.5, 1.9, 2.4, 2.8]:
    z = z0.copy(); Es = [P.energy(z, Qs, obs, logw, s)]
    for _ in range(25):
        m = P.read(z, Qs, obs, logw, s)[3]; z = z + lam * (m - z); Es.append(P.energy(z, Qs, obs, logw, s))
    inc = sum(Es[k + 1] > Es[k] + 1e-12 for k in range(25))
    print(lam, "increases", inc, "final", round(Es[-1], 5), [round(e, 3) for e in Es[:8]])
