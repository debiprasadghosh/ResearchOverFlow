import numpy as np, math
import p2_checks as P
rng = np.random.default_rng(5); P.rng = rng
bad = 0
for t in range(300):
    D = int(rng.integers(3, 7)); r = int(rng.integers(1, D)); B = np.linalg.qr(rng.standard_normal((D, r)))[0]
    n = int(rng.integers(2, 7))
    Qs = [rng.standard_normal((int(rng.integers(1, r + 1)), r)) @ B.T for _ in range(n)]
    obs = [Q @ rng.standard_normal(D) + 0.3 * rng.standard_normal(Q.shape[0]) for Q in Qs]
    logw = rng.normal(0, 0.5, n); z = rng.standard_normal(D); s = float(rng.uniform(0.5, 2.0))
    a, H, b, m = P.read(z, Qs, obs, logw, s)
    w, V = np.linalg.eigh(H)
    tau = 1e-6
    mt = np.linalg.solve(H + tau * np.eye(D), b + tau * z)
    err = np.linalg.norm(mt - m)
    if err > 1e-3 and bad < 4:
        bad += 1
        print("D r n", D, r, n, "eig", w, "alpha", np.round(a, 4))
        print("  coef of b-Hz on eigvecs", V.T @ (b - H @ z))
        print("  m", m, "mt", mt)
