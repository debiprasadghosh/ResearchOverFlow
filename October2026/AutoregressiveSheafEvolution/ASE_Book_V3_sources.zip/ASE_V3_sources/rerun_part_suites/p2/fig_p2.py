# Figures for Part II. Plotted register values come from p2_checks.json; illustrative panels are recomputed here with
# fixed seeds from the same constructions, and their captions say so.
import json, math, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch, Rectangle
import p2_checks as P

here = os.path.dirname(os.path.abspath(__file__))
os.makedirs(os.path.join(here, "fig"), exist_ok=True)
BLUE, FILL, OR, ORF, GREY, INK, MUTED = "#2a78d6", "#eef3fb", "#eb6834", "#fdeee7", "#9a9893", "#222222", "#555555"
DARK = "#5f5e5a"
RAMP = ["#8fb9e8", "#2a78d6", "#14457f"]                  # sequential blue for the three scales
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.edgecolor": "#bdbbb6", "axes.linewidth": 0.6,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.labelcolor": INK, "mathtext.fontset": "dejavusans",
                     "axes.titlesize": 8.5, "axes.titleweight": "bold", "axes.titlelocation": "left",
                     "legend.frameon": False, "legend.fontsize": 7})
C = json.load(open(os.path.join(here, "p2_checks.json")))


def tidy(ax, grid=True):
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    if grid:
        ax.grid(True, color="#ecebe8", lw=0.5, zorder=0)
    ax.tick_params(length=2.5, width=0.5)


def arrow(ax, a, b, color=INK, lw=0.8, ms=7, ls="-", z=5):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=ms, color=color, lw=lw, linestyle=ls,
                                 zorder=z, shrinkA=1.5, shrinkB=1.5))


# ------------------------------------------------------------------ Figure 1: the star, recombination, conditioning
def fig_star(path):
    fig = plt.figure(figsize=(6.6, 2.35), dpi=300)
    ax = fig.add_axes([0.0, 0.02, 0.33, 0.88]); ax.set_xlim(-0.2, 3.3); ax.set_ylim(-1.75, 1.75); ax.axis("off")
    ax.set_title("(a) the observation star", x=0.04)
    tok = (0.5, 0.0)
    leaves = [(2.75, 1.35), (2.95, 0.55), (3.0, -0.25), (2.85, -1.0), (2.45, -1.55)]
    for i, (x, y) in enumerate(leaves):
        mx, my = (tok[0] + x) / 2 + 0.25, (tok[1] + y) / 2
        ax.plot([tok[0], mx], [tok[1], my], color=BLUE, lw=0.9, zorder=2)
        ax.plot([mx, x], [my, y], color=OR, lw=0.9, zorder=2)
        ax.add_patch(Rectangle((mx - 0.07, my - 0.07), 0.14, 0.14, fc="white", ec=INK, lw=0.6, zorder=4))
        ax.add_patch(Circle((x, y), 0.11, fc=ORF, ec=OR, lw=0.8, zorder=4))
        ax.text(x + 0.17, y, f"y$_{i + 1}$", va="center", fontsize=7.5, color=INK)
        if i == 0:
            ax.text((tok[0] + mx) / 2 - 0.12, (tok[1] + my) / 2 + 0.17, "Q$_1$", fontsize=7.5, color=BLUE)
            ax.text((mx + x) / 2 - 0.05, (my + y) / 2 + 0.16, "R$_1$", fontsize=7.5, color=OR)
            ax.annotate("edge stalk ℝ$^{k_1}$", (mx, my + 0.08), (0.55, 1.45), fontsize=6.8, color=MUTED,
                        arrowprops=dict(arrowstyle="-", color=GREY, lw=0.5))
    ax.add_patch(Circle(tok, 0.17, fc=FILL, ec=BLUE, lw=1.0, zorder=5))
    ax.text(0.0, tok[1] - 0.42, "token z ∈ ℝ$^D$", ha="left", fontsize=7.2, color=INK)
    ax.text(0.05, -1.62, "e$_i$ = ½‖Q$_i$z − R$_i$y$_i$‖²", fontsize=7.2, color=MUTED)

    ax = fig.add_axes([0.40, 0.17, 0.26, 0.66]); tidy(ax)
    ax.set_title("(b) recombination", x=-0.08)
    y1, y2 = np.array([1.0, 0.1]), np.array([0.1, 1.0]); m = np.array([1.0, 1.0])
    ax.text(-0.06, 0.03, "cost −x$_1$ − x$_2$:\nrecords −1.1, read −2.0", fontsize=6.0, color=MUTED)
    ax.axvline(1.0, color=BLUE, lw=0.9, ls=(0, (3, 2)), zorder=2); ax.axhline(1.0, color=OR, lw=0.9, ls=(0, (3, 2)), zorder=2)
    ax.plot(*np.array([y1, y2]).T, color=GREY, lw=1.6, zorder=3, solid_capstyle="round")
    ax.plot(*y1, "o", ms=4.5, color=BLUE, zorder=4); ax.plot(*y2, "o", ms=4.5, color=OR, zorder=4)
    ax.plot(*m, "*", ms=9, color=INK, mec="white", mew=0.5, zorder=5)
    ax.text(1.04, 0.06, "y$_1$ sees x$_1$", fontsize=6.8, color=BLUE)
    ax.text(0.14, 1.06, "y$_2$ sees x$_2$", fontsize=6.8, color=OR)
    ax.text(1.03, 1.1, "read", fontsize=6.8, color=INK)
    ax.text(0.47, 0.66, "archive hull", fontsize=6.5, color=MUTED, rotation=-45, rotation_mode="anchor")
    ax.set_xlim(-0.1, 1.45); ax.set_ylim(-0.1, 1.45); ax.set_xlabel("x$_1$"); ax.set_ylabel("x$_2$", labelpad=1)
    ax.set_aspect("equal")

    ax = fig.add_axes([0.75, 0.17, 0.235, 0.66]); tidy(ax)
    ax.set_title("(c) two lines at angle θ", x=-0.12)
    th = np.linspace(0.03, math.pi / 2, 300)
    ax.plot(th, 1 / np.sin(th), color=BLUE, lw=1.4, label="read displacement 1/sin θ")
    ax.plot(th, 1 / np.sqrt(1 - np.cos(th)), color=OR, lw=1.2, ls=(0, (4, 2)), label="bound (1/λ$_{min}$)$^{1/2}$")
    pts = C["conditioning"]["two_lines"]
    ax.plot([p["theta"] for p in pts], [p["displacement"] for p in pts], "o", ms=3.5, color=BLUE, mec="white", mew=0.5)
    ax.set_yscale("log"); ax.set_xlabel("angle θ (rad)"); ax.set_ylabel("displacement per unit move", labelpad=1)
    ax.legend(loc="upper right", handlelength=2.2)
    fig.savefig(path, dpi=300); plt.close(fig)


# ------------------------------------------------------------------ Figure 2: sheaf mean shift
def fig_meanshift(path):
    Qs = [np.eye(2), np.eye(2), np.array([[0.6, 0.8]]), np.array([[1.0, 0.0]]), np.array([[0.0, 1.0]])]
    obs = [np.array([-1.3, 0.9]), np.array([1.1, -0.8]), np.array([0.9]), np.array([-0.4]), np.array([-1.0])]
    logw = np.zeros(5); s = 0.6
    fig = plt.figure(figsize=(6.6, 2.75), dpi=300)
    ax = fig.add_axes([0.06, 0.14, 0.40, 0.74])
    g = np.linspace(-2.2, 2.2, 221); Xg, Yg = np.meshgrid(g, g)
    E = np.array([[P.energy(np.array([x, y]), Qs, obs, logw, s) for x in g] for y in g])
    cs = ax.contourf(Xg, Yg, E, levels=np.linspace(E.min(), 1.6, 15), cmap="Blues_r", alpha=0.55, extend="max")
    ax.contour(Xg, Yg, E, levels=np.linspace(E.min(), 1.6, 15), colors="white", linewidths=0.35)
    t = np.linspace(-2.2, 2.2, 2)
    ax.plot(t, (0.9 - 0.6 * t) / 0.8, color=DARK, lw=0.9); ax.axvline(-0.4, color=DARK, lw=0.9); ax.axhline(-1.0, color=DARK, lw=0.9)
    ax.plot([-1.3, 1.1], [0.9, -0.8], "o", ms=4, color=INK, mec="white", mew=0.5)
    ax.text(0.75, 0.82, "0.6x$_1$ + 0.8x$_2$ = 0.9", fontsize=6.3, color=DARK, rotation=-36.9, rotation_mode="anchor")
    ax.text(-0.36, 1.95, "x$_1$ = −0.4", fontsize=6.3, color=DARK); ax.text(-2.15, -1.2, "x$_2$ = −1", fontsize=6.3, color=DARK)
    starts = [np.array([-2.0, 2.0]), np.array([2.0, 1.6]), np.array([1.8, -2.0]), np.array([-2.0, -1.8])]
    for z0 in starts:
        path_ = [z0]
        for _ in range(30):
            path_.append(P.read(path_[-1], Qs, obs, logw, s)[3])
        path_ = np.array(path_)
        ax.plot(*path_.T, "-", color=OR, lw=0.9, zorder=4); ax.plot(*path_[:6].T, "o", ms=2.2, color=OR, zorder=5)
        ax.plot(*path_[-1], "*", ms=8, color=INK, mec="white", mew=0.5, zorder=6)
    ax.set_xlim(-2.2, 2.2); ax.set_ylim(-2.2, 2.2); ax.set_aspect("equal"); ax.set_xlabel("x$_1$"); ax.set_ylabel("x$_2$", labelpad=1)
    ax.set_title("(a) soft energy, records and read iterations", x=-0.02)
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.tick_params(length=2, width=0.5)

    ax = fig.add_axes([0.60, 0.14, 0.375, 0.74]); tidy(ax)
    z0 = np.array([2.0, 1.6])
    styles = [(0.5, RAMP[0], "-"), (1.0, RAMP[1], "-"), (1.5, RAMP[2], "-"), (2.4, OR, (0, (3, 1.6)))]
    for lam, col, ls in styles:
        z = z0.copy(); Es = [P.energy(z, Qs, obs, logw, s)]
        for _ in range(25):
            m = P.read(z, Qs, obs, logw, s)[3]; z = z + lam * (m - z); Es.append(P.energy(z, Qs, obs, logw, s))
        ax.plot(range(26), Es, ls=ls, color=col, lw=1.2, marker="o", ms=2.2, label=f"λ = {lam:g}")
    ax.set_ylim(-0.33, 0.12); ax.set_xlim(0, 25)
    ax.text(7.0, -0.2, "all runs start at E = 1.24,\nfrom the same token", fontsize=6.5, color=MUTED)
    ax.set_xlabel("iteration"); ax.set_ylabel("soft energy E$_s$(z$_t$)", labelpad=1)
    ax.set_title("(b) descent for 0 < λ < 2, not beyond", x=-0.02)
    ax.legend(loc="upper right", ncol=2, handlelength=2.0, columnspacing=1.0, bbox_to_anchor=(1.0, 0.93))
    fig.savefig(path, dpi=300); plt.close(fig)


# ------------------------------------------------------------------ Figure 3: Gaussian stalks
def fig_stalks(path):
    fig = plt.figure(figsize=(6.6, 2.35), dpi=300)
    ax = fig.add_axes([0.0, 0.08, 0.33, 0.80]); ax.set_title("(a) imputation and its limit", x=0.06)
    phi = 0.62; n1, o1 = np.array([1.0, 0.0]), 1.0; n2 = np.array([-math.sin(phi), math.cos(phi)]); o2 = 0.3
    Hn = 0.5 * (np.outer(n1, n1) + np.outer(n2, n2)); mB = np.linalg.solve(Hn, 0.5 * (n1 * o1 + n2 * o2))
    z = np.array([-1.0, -1.1])
    proj = lambda x, n, o: x - n * (n @ x - o)
    t = np.linspace(-2, 3, 2)
    ax.plot([o1, o1], [-1.6, 1.8], color=BLUE, lw=1.0)
    base = n2 * o2; d2 = np.array([math.cos(phi), math.sin(phi)])
    ax.plot(*(base[:, None] + d2[:, None] * np.array([[-2.6, 2.6]])), color=OR, lw=1.0)
    p1, p2 = proj(z, n1, o1), proj(z, n2, o2); mA = 0.5 * (p1 + p2)
    for p, c in [(p1, BLUE), (p2, OR)]:
        ax.plot([z[0], p[0]], [z[1], p[1]], color=c, lw=0.6, ls=(0, (2, 1.5)))
        ax.plot(*p, "s", ms=3.2, color=c, zorder=5)
    xs = [z]
    for _ in range(40):
        x = xs[-1]; xs.append(0.5 * (proj(x, n1, o1) + proj(x, n2, o2)))
    xs = np.array(xs)
    ax.plot(*xs.T, "-", color=GREY, lw=0.7, zorder=3); ax.plot(*xs[1:12].T, "o", ms=2.0, color=DARK, zorder=4)
    ax.plot(*z, "o", ms=5, color=FILL, mec=BLUE, mew=1.0, zorder=6); ax.text(z[0] - 0.12, z[1] - 0.3, "z", fontsize=7.5)
    ax.plot(*mA, "o", ms=4.5, color=OR, mec="white", mew=0.5, zorder=6)
    ax.annotate("one imputation\n= unit gradient step", mA, (mA[0] - 0.55, mA[1] - 0.75), fontsize=6.4, color=INK,
                arrowprops=dict(arrowstyle="-", color=GREY, lw=0.5))
    ax.plot(*mB, "*", ms=9, color=INK, mec="white", mew=0.5, zorder=7)
    ax.annotate("harmonic read\n= the limit", mB, (-1.6, 1.05), fontsize=6.4, color=INK,
                arrowprops=dict(arrowstyle="-", color=GREY, lw=0.5))
    ax.set_xlim(-1.7, 2.3); ax.set_ylim(-1.9, 1.6); ax.set_aspect("equal"); ax.axis("off")

    ax = fig.add_axes([0.40, 0.17, 0.25, 0.68]); tidy(ax); ax.set_title("(b) selection tilt and coverage", x=-0.1)
    tc = C["tilt_coverage"]; b = np.array(tc["betas"], float)
    ax.plot(b, tc["min_eig"]["elite partial"], "o-", ms=3, color=OR, lw=1.2, label="elite sees 2 of 4 coordinates")
    ax.plot(b, tc["min_eig"]["elite full"], "s-", ms=3, color=BLUE, lw=1.2, label="elite sees all 4")
    ax.set_xscale("symlog", linthresh=1); ax.set_yscale("log"); ax.set_ylim(1e-72, 10)
    ax.set_xlabel("selection strength β"); ax.set_ylabel("λ$_{min}$(H)", labelpad=1)
    ax.legend(loc="lower left", handlelength=1.8)

    ax = fig.add_axes([0.745, 0.17, 0.225, 0.68]); tidy(ax); ax.set_title("(c) measurement error", x=-0.1)
    r = np.random.default_rng(7); xs_, tv_ = [], []
    for t in range(1500):
        n = int(r.integers(2, 12)); al = P.softmax(r.normal(0, 2, n)); beta, eps = float(r.uniform(0.1, 10)), float(r.uniform(0.01, 1))
        dJ = r.uniform(-eps, eps, n) if t % 2 else eps * r.choice([-1.0, 1.0], n)
        a2 = al * np.exp(-beta * dJ); a2 /= a2.sum(); xs_.append(beta * eps); tv_.append(0.5 * float(np.abs(al - a2).sum()))
    ax.plot(xs_, tv_, "o", ms=1.4, color=GREY, alpha=0.6, mew=0, label="random trials")
    u = np.linspace(0, 10, 300); ax.plot(u, np.tanh(u / 2), color=BLUE, lw=1.4, label="tanh(βε/2)")
    ax.set_xlabel("βε"); ax.set_ylabel("TV(α, α′)", labelpad=1); ax.set_ylim(0, 1.02); ax.set_xlim(0, 10); ax.set_xticks([0, 2, 4, 6, 8, 10])
    ax.legend(loc="lower right", handlelength=1.8, markerscale=2.5)
    fig.savefig(path, dpi=300); plt.close(fig)


# ------------------------------------------------------------------ Figure 4: locality
def fig_locality(path):
    r = np.random.default_rng(11)
    Y = r.uniform(0, 10, (400, 2)); w = r.uniform(0.5, 1.5, 400); Wtot = float(w.sum())
    R = max(float(np.linalg.norm(Y[i] - Y[j])) for i in range(400) for j in range(i + 1, 400))
    cs = np.arange(1.0, 8.01, 0.25)
    fig = plt.figure(figsize=(6.6, 2.5), dpi=300)
    ax1 = fig.add_axes([0.08, 0.16, 0.39, 0.70]); tidy(ax1); ax1.set_title("(a) truncation error and certificate", x=-0.02)
    ax2 = fig.add_axes([0.60, 0.16, 0.38, 0.70]); tidy(ax2); ax2.set_title("(b) archive share of the star", x=-0.02)
    for s, col in zip([0.1, 0.3, 1.0], RAMP):
        cert = np.zeros((60, len(cs))); err = np.zeros_like(cert); share = np.zeros_like(cert); cr = []
        for q in range(60):
            z = r.uniform(0, 10, 2); d2 = np.sum((Y - z) ** 2, 1); k = w * np.exp(-d2 / (2 * s * s))
            m = k @ Y / k.sum(); found = None
            for j, c in enumerate(cs):
                S = d2 <= (c * s) ** 2
                if not S.any():
                    cert[q, j] = R; err[q, j] = np.nan; share[q, j] = 0.0; continue
                mS = k[S] @ Y[S] / k[S].sum()
                cert[q, j] = R * min(1.0, (Wtot - float(w[S].sum())) * math.exp(-c * c / 2) / float(k[S].sum()))
                err[q, j] = float(np.linalg.norm(m - mS)); share[q, j] = float(S.mean())
                if found is None and cert[q, j] <= 1e-3 * R:
                    found = c
            if found is not None:
                cr.append(found)
        ax1.plot(cs, np.median(cert, 0) / R, color=col, lw=1.4, label=f"s = {s:g}")
        ax1.plot(cs, np.maximum(np.nanmedian(err, 0) / R, 1e-17), color=col, lw=0.9, ls=(0, (1.5, 1.2)))
        ax2.plot(cs, 100 * share.mean(0), color=col, lw=1.4, label=f"s = {s:g}")
        c_med = float(np.median(cr)); j = int(np.argmin(np.abs(cs - c_med)))
        ax2.plot([c_med], [100 * share.mean(0)[j]], "o", ms=4.5, color=col, mec="white", mew=0.6, zorder=5)
    ax1.axhline(1e-3, color=OR, lw=0.8, ls=(0, (3, 2))); ax1.text(7.0, 2.2e-3, "η = 10⁻³", fontsize=6.5, color=OR)
    ax1.set_yscale("log"); ax1.set_ylim(1e-17, 2); ax1.set_xlim(1, 8)
    ax1.set_xlabel("star radius ρ/s"); ax1.set_ylabel("error / R", labelpad=1)
    ax1.text(5.75, 4e-2, "solid: median certificate\ndotted: median true error", fontsize=6.0, color=MUTED)
    ax1.legend(loc="lower left", handlelength=1.8)
    ax2.set_yscale("log"); ax2.set_xlim(1, 8); ax2.set_xlabel("star radius ρ/s"); ax2.set_ylabel("records in the star (%)", labelpad=1)
    ax2.text(1.1, 75, "dots: median certified radius, η = 10⁻³", fontsize=6.0, color=MUTED); ax2.set_ylim(1e-2, 2e2)
    ax2.legend(loc="lower right", handlelength=1.8)
    fig.savefig(path, dpi=300); plt.close(fig)


# ------------------------------------------------------------------ Figure 5: topology of design spaces
def fig_topology(path):
    fig = plt.figure(figsize=(6.6, 4.9), dpi=300)
    # (a) two branches
    ax = fig.add_axes([0.08, 0.60, 0.38, 0.33]); tidy(ax); ax.set_title("(a) two branches and the gap", x=-0.02)
    w_, g_ = 0.3, 1.4; r = np.random.default_rng(3)
    y1 = np.sort(r.uniform(-w_, 0, 5)); y2 = np.sort(r.uniform(g_, g_ + w_, 5)); ys = np.concatenate([y1, y2]); s = 0.45
    zq = np.linspace(-0.8, 2.2, 400); M = []; M1 = []; M2 = []; inside = []
    for zz in zq:
        a = P.softmax(-(zz - ys) ** 2 / (2 * s * s)); M.append(a @ ys)
        M1.append(a[:5] @ y1 / a[:5].sum()); M2.append(a[5:] @ y2 / a[5:].sum()); p2 = a[5:].sum()
        inside.append(w_ / (g_ + w_) < p2 < g_ / (g_ + w_))
    ax.axhspan(0, g_, color="#f4f3f0", zorder=0); ax.text(-0.75, 0.62, "gap: no feasible design", fontsize=6.4, color=MUTED)
    ax.plot(zq, M, color=INK, lw=1.4, label="shared read")
    ax.plot(zq, M1, color=BLUE, lw=1.1, label="branch-1 read"); ax.plot(zq, M2, color=OR, lw=1.1, label="branch-2 read")
    ins = np.array(inside); ax.fill_between(zq, -0.62, -0.55, where=ins, color=DARK, lw=0)
    ax.text(0.98, -0.5, "sufficient condition holds", fontsize=6.0, color=DARK, ha="center")
    for y in y1:
        ax.plot([-0.8], [y], marker=">", ms=3, color=BLUE, clip_on=False)
    for y in y2:
        ax.plot([-0.8], [y], marker=">", ms=3, color=OR, clip_on=False)
    ax.set_xlim(-0.8, 2.2); ax.set_ylim(-0.65, 1.95); ax.set_xlabel("query z"); ax.set_ylabel("read", labelpad=1)
    ax.legend(loc="center right", handlelength=1.6, bbox_to_anchor=(1.0, 0.42))

    # (b) angles near the cut
    ax = fig.add_axes([0.60, 0.60, 0.38, 0.33]); tidy(ax); ax.set_title("(b) reading angles across the cut", x=-0.02)
    r = np.random.default_rng(5)
    th = np.concatenate([r.normal(0.15, 0.1, 10) % (2 * math.pi), r.normal(2 * math.pi - 0.15, 0.1, 10) % (2 * math.pi)])
    s = 0.5; wrap = lambda x: (x + math.pi) % (2 * math.pi) - math.pi
    q = np.linspace(-0.5, 0.5, 801)
    cut = [wrap(float(P.softmax(-((qq % (2 * math.pi)) - th) ** 2 / (2 * s * s)) @ th)) for qq in q]
    loc = []
    for qq in q:
        d = np.array([wrap(t - qq) for t in th]); loc.append(wrap(qq + float(P.softmax(-d ** 2 / (2 * s * s)) @ d)))
    cut = np.array(cut); jump = np.where(np.abs(np.diff(cut)) > 0.1)[0]
    for seg in np.split(np.arange(len(q)), jump + 1):
        ax.plot(q[seg], cut[seg], color=OR, lw=1.4, label="cut coordinate [0, 2π)" if seg[0] == 0 else None)
    ax.plot(q, loc, color=BLUE, lw=1.4, label="local displacement read")
    ax.axvline(0, color=GREY, lw=0.6, ls=(0, (2, 2))); ax.text(0.01, -0.27, "the cut", fontsize=6.4, color=MUTED)
    ax.set_xlabel("query angle (rad)"); ax.set_ylabel("read angle (rad)", labelpad=1); ax.set_xlim(-0.5, 0.5); ax.set_ylim(-0.3, 0.3)
    ax.legend(loc="upper left", handlelength=1.6)

    # (c) nearest-image reads under finite groups
    ax = fig.add_axes([0.08, 0.10, 0.38, 0.33]); tidy(ax); ax.set_title("(c) nearest-image read: error and bound", x=-0.02)
    groups = [("sign flips, ℝ⁶", [np.eye(6), -np.eye(6)], BLUE, "o"), ("mirror reversal, ℝ⁶", [np.eye(6), np.eye(6)[::-1]], OR, "^"),
              ("dihedral, order 12, ℝ²", P.dihedral(6), DARK, "s")]
    r = np.random.default_rng(9)
    for name, G, col, mk in groups:
        D = G[0].shape[0]; E_, B_ = [], []
        for _ in range(250):
            n = int(r.integers(3, 10)); ys_ = r.standard_normal((n, D)); lw = r.normal(0, 0.5, n)
            z = r.standard_normal(D); s = float(r.uniform(0.2, 1.5))
            ma, mn, gap2 = P.image_reads(z, ys_, lw, G, s); qq = math.exp(-gap2 / (2 * s * s)); k = len(G) - 1
            bound = 2 * k * qq / (1 + k * qq) * float(np.linalg.norm(ys_, axis=1).max())
            if bound > 1e-12:
                E_.append(max(float(np.linalg.norm(ma - mn)), 1e-18)); B_.append(bound)
        ax.plot(B_, E_, mk, ms=2.2, color=col, alpha=0.75, mew=0, label=name)
    t = np.logspace(-12, 1, 2); ax.plot(t, t, color=INK, lw=0.8); ax.text(3e-8, 2e-10, "error = bound", fontsize=6.4, rotation=28, color=INK)
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(1e-10, 10); ax.set_ylim(1e-16, 10)
    ax.set_xlabel("bound 2ε max‖y‖"); ax.set_ylabel("‖m$_{all}$ − m$_{near}$‖", labelpad=1)
    ax.legend(loc="upper left", handlelength=1.0, markerscale=2.2)

    # (d) the seam of a canonical half-space for the sign group
    ax = fig.add_axes([0.60, 0.10, 0.38, 0.33]); ax.set_title("(d) a canonical index has a seam", x=-0.02)
    ax.axvspan(0, 1.5, color="#f4f3f0", zorder=0); ax.axvline(0, color=GREY, lw=0.8)
    yv, qv = np.array([-0.15, 0.9]), np.array([0.12, 0.85])
    ax.plot(*yv, "o", ms=5, color=OR, zorder=5); ax.text(yv[0] - 0.33, yv[1] + 0.12, "record y", fontsize=6.6, color=OR)
    ax.plot(*(-yv), "o", ms=5, color=OR, mfc="white", zorder=5); ax.text(-yv[0] + 0.12, -yv[1] - 0.03, "−y, stored\nas canonical", fontsize=6.4, color=OR, va="center")
    arrow(ax, yv, -yv, color=OR, lw=0.7, ls=(0, (2, 1.5)))
    ax.plot(*qv, "o", ms=5, color=BLUE, zorder=6); ax.text(qv[0] + 0.07, qv[1] + 0.1, "query q", fontsize=6.6, color=BLUE)
    ax.plot(*np.array([qv, yv]).T, color=INK, lw=0.9)
    dG = min(np.linalg.norm(qv - yv), np.linalg.norm(qv + yv)); dc = np.linalg.norm(qv + yv)
    ax.text(-2.05, -0.45, f"orbit distance {dG:.2f}\ncanonical distance {dc:.2f}", fontsize=6.6, color=INK)
    ax.text(0.78, 0.25, "canonical\nhalf-space\nx$_1$ ≥ 0", fontsize=6.3, color=MUTED, ha="center")
    ax.set_xlim(-2.1, 1.5); ax.set_ylim(-1.35, 1.3); ax.set_aspect("equal"); ax.set_xticks([]); ax.set_yticks([])
    for sp in ax.spines.values():
        sp.set_visible(False)
    fig.savefig(path, dpi=300); plt.close(fig)


if __name__ == "__main__":
    fig_star(os.path.join(here, "fig", "star.png")); print("star")
    fig_meanshift(os.path.join(here, "fig", "meanshift.png")); print("meanshift")
    fig_stalks(os.path.join(here, "fig", "stalks.png")); print("stalks")
    fig_locality(os.path.join(here, "fig", "locality.png")); print("locality")
    fig_topology(os.path.join(here, "fig", "topology.png")); print("topology")
