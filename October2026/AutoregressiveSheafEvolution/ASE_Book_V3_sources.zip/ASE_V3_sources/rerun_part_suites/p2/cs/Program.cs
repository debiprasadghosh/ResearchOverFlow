// Validation run of the Part II kernel; cs_validate.py recomputes every printed
// number with NumPy.
using System;
using System.Collections.Immutable;
using System.Globalization;
using System.Linq;
using AsePartTwo;

static ImmutableArray<double> V(params double[] x) => ImmutableArray.Create(x);
static string F(double x) => x.ToString("G15", CultureInfo.InvariantCulture);
static void Print(string name, params double[] xs) =>
    Console.WriteLine(name + " " + string.Join(" ", xs.Select(F)));

var records = ImmutableArray.Create(
    new ObservedRecord(Matrix.Of(2, 3, 1, 0, 0, 0, 1, 0), V(1.0, -0.5), 0.0),
    new ObservedRecord(Matrix.Of(1, 3, 0, 0, 1), V(2.0), -0.3),
    new ObservedRecord(Matrix.Of(2, 3, 0.6, 0.8, 0, 0, 0, 1), V(0.4, 1.5), 0.2),
    new ObservedRecord(Matrix.Of(1, 3, 1, -1, 0.5), V(0.3), 0.1));

// a resolved read and three damped steps
var z = V(0.2, -0.1, 0.5);
const double s = 0.8;
var read = SheafAttention.Read(z, records, s);
Print("weights", read.Weights.ToArray());
Print("read", read.Value.ToArray());
Print("min_eig", read.MinEigenvalue);
Print("energy", SheafAttention.Energy(z, records, s));
foreach (var lambda in new[] { 0.5, 1.0, 1.5 })
    Print($"step_{lambda.ToString(CultureInfo.InvariantCulture)}",
          SheafAttention.Energy(SheafAttention.Step(z, read, lambda), records, s),
          SheafAttention.GuaranteedDecrease(z, read, lambda));

// an unresolved read: the weight sits on a record that sees only coordinate 3
var zu = V(5.0, 5.0, 2.0);
var ru = SheafAttention.Read(zu, records, 0.05);
Print("unresolved", ru.Unresolved ? 1.0 : 0.0);
Print("read_unresolved", ru.Value.ToArray());

// nearest-image and all-image reads under the mirror that reverses coordinates
var group = ImmutableArray.Create(Matrix.Of(3, 3, 1, 0, 0, 0, 1, 0, 0, 0, 1),
                                  Matrix.Of(3, 3, 0, 0, 1, 0, 1, 0, 1, 0, 0));
var ys = ImmutableArray.Create(V(1.0, 0.2, -0.5), V(-0.3, 0.8, 1.1),
                               V(0.5, -1.0, 0.0));
var (all, nearest) =
    SymmetricReads.Read(V(0.9, 0.1, -0.2), ys, V(0.0, 0.2, -0.1), group, 0.6);
Print("image_all", all.ToArray());
Print("image_nearest", nearest.ToArray());

// truncation certificate on a small planar archive
var pts = new[] { (0.0, 0.0), (0.4, 0.1), (1.0, 0.8), (2.5, 2.0), (3.0, 0.5),
                  (0.2, 1.6), (4.0, 4.0), (1.4, 0.2) };
var wts = new[] { 1.0, 0.8, 1.2, 0.9, 1.1, 0.7, 1.3, 1.0 };
double zx = 0.3, zy = 0.3, sc = 0.5, rho = 1.5;
static double Sq(double x) => x * x;
var d2 = pts.Select(p => Sq(p.Item1 - zx) + Sq(p.Item2 - zy)).ToArray();
var k = d2.Select((v, i) => wts[i] * Math.Exp(-v / (2 * sc * sc))).ToArray();
var inStar = d2.Select(v => v <= rho * rho).ToArray();
double diam = pts.SelectMany(p => pts,
    (p, q) => Math.Sqrt(Sq(p.Item1 - q.Item1) + Sq(p.Item2 - q.Item2))).Max();
double DS = k.Where((v, i) => inStar[i]).Sum();
double WS = wts.Where((v, i) => inStar[i]).Sum();
double mx = k.Select((v, i) => v * pts[i].Item1).Sum() / k.Sum();
double my = k.Select((v, i) => v * pts[i].Item2).Sum() / k.Sum();
double sx = k.Select((v, i) => inStar[i] ? v * pts[i].Item1 : 0.0).Sum() / DS;
double sy = k.Select((v, i) => inStar[i] ? v * pts[i].Item2 : 0.0).Sum() / DS;
Print("truncation", Math.Sqrt((mx - sx) * (mx - sx) + (my - sy) * (my - sy)),
      SheafAttention.TruncationCertificate(diam, wts.Sum(), WS, DS, rho, sc));
