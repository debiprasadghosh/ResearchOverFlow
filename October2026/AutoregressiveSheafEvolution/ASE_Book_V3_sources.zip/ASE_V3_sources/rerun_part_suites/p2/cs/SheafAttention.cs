// ASE Part II reference kernel: sheaf attention on an observation star.
// Immutable values and pure functions; numerical routines use private copies.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AsePartTwo;

/// <summary>A dense real matrix stored row-major.</summary>
public sealed record Matrix(int Rows, int Cols, Vec Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Matrix Of(int rows, int cols, params double[] data) =>
        new(rows, cols, ImmutableArray.Create(data));

    public static Matrix Zero(int n) =>
        new(n, n, ImmutableArray.CreateRange(new double[n * n]));

    public Matrix Transpose() =>
        new(Cols, Rows, Enumerable.Range(0, Rows * Cols)
            .Select(k => this[k % Rows, k / Rows]).ToImmutableArray());

    public Matrix Times(Matrix b) =>
        new(Rows, b.Cols, Enumerable.Range(0, Rows * b.Cols)
            .Select(k => Enumerable.Range(0, Cols)
                .Sum(j => this[k / b.Cols, j] * b[j, k % b.Cols]))
            .ToImmutableArray());

    public Matrix Plus(Matrix b) =>
        this with { Data = Data.Zip(b.Data, (p, q) => p + q).ToImmutableArray() };

    public Matrix Scale(double s) =>
        this with { Data = Data.Select(x => s * x).ToImmutableArray() };

    public Vec Apply(Vec x) =>
        Enumerable.Range(0, Rows)
            .Select(r => Enumerable.Range(0, Cols).Sum(c => this[r, c] * x[c]))
            .ToImmutableArray();

    /// <summary>Eigenvalues and eigenvectors (columns) of a symmetric matrix,
    /// by cyclic Jacobi rotations on a private copy.</summary>
    public (Vec Values, Matrix Vectors) SymmetricEigen()
    {
        int n = Rows;
        var a = Data.ToArray();
        var v = new double[n * n];
        for (int i = 0; i < n; i++) v[i * n + i] = 1.0;
        void Rotate(double[] m, int i, int j, double c, double s)
        {
            (m[i], m[j]) = (c * m[i] - s * m[j], s * m[i] + c * m[j]);
        }
        for (int sweep = 0; sweep < 100; sweep++)
        {
            double off = 0.0;
            for (int p = 0; p < n; p++)
                for (int q = p + 1; q < n; q++) off += a[p * n + q] * a[p * n + q];
            if (off < 1e-300) break;
            for (int p = 0; p < n - 1; p++)
                for (int q = p + 1; q < n; q++)
                {
                    double apq = a[p * n + q];
                    if (apq == 0.0) continue;
                    double th = (a[q * n + q] - a[p * n + p]) / (2.0 * apq);
                    double t = th == 0.0 ? 1.0
                        : Math.Sign(th) / (Math.Abs(th) + Math.Sqrt(th * th + 1.0));
                    double c = 1.0 / Math.Sqrt(t * t + 1.0), s = t * c;
                    for (int k = 0; k < n; k++)
                    {
                        Rotate(a, k * n + p, k * n + q, c, s);
                        Rotate(v, k * n + p, k * n + q, c, s);
                    }
                    for (int k = 0; k < n; k++)
                        Rotate(a, p * n + k, q * n + k, c, s);
                }
        }
        return (Enumerable.Range(0, n).Select(i => a[i * n + i]).ToImmutableArray(),
                new Matrix(n, n, v.ToImmutableArray()));
    }
}

/// <summary>One leaf of the star: edge map Q, observation R y and log prior
/// weight.</summary>
public sealed record ObservedRecord(Matrix Q, Vec Observation, double LogWeight);

/// <summary>One read: weights, normal matrix H, right side b, the read value
/// and diagnostics.</summary>
public sealed record SheafRead(Vec Weights, Matrix Normal, Vec Rhs, Vec Value,
                               double MinEigenvalue, bool Unresolved);

public static class SheafAttention
{
    static double Discrepancy(ObservedRecord r, Vec z) =>
        0.5 * r.Q.Apply(z).Zip(r.Observation, (p, o) => (p - o) * (p - o)).Sum();

    static Vec Logits(Vec z, ImmutableArray<ObservedRecord> records, double s) =>
        records.Select(r => r.LogWeight - Discrepancy(r, z) / (s * s))
               .ToImmutableArray();

    static Vec Add(Vec x, Vec y) => x.Zip(y, (p, q) => p + q).ToImmutableArray();

    /// <summary>E_s(z) = -s^2 log sum_i w_i exp(-e_i(z) / s^2).</summary>
    public static double Energy(Vec z, ImmutableArray<ObservedRecord> records,
                                double s)
    {
        var l = Logits(z, records, s);
        double peak = l.Max();
        return -s * s * (peak + Math.Log(l.Sum(v => Math.Exp(v - peak))));
    }

    /// <summary>The read m = z + H^+ (b - H z): H^{-1} b when H is positive
    /// definite, and the token's own value in unresolved directions otherwise.
    /// </summary>
    public static SheafRead Read(Vec z, ImmutableArray<ObservedRecord> records,
                                 double s, double relTol = 1e-10)
    {
        if (z.IsDefaultOrEmpty || records.IsDefaultOrEmpty || !(s > 0))
            throw new ArgumentException("Invalid read input");
        var l = Logits(z, records, s);
        double peak = l.Max();
        var un = l.Select(v => Math.Exp(v - peak)).ToImmutableArray();
        var alpha = un.Select(v => v / un.Sum()).ToImmutableArray();
        int d = z.Length;
        var H = records.Select((r, i) => r.Q.Transpose().Times(r.Q).Scale(alpha[i]))
                       .Aggregate(Matrix.Zero(d), (x, y) => x.Plus(y));
        var b = records
            .Select((r, i) => r.Q.Transpose().Apply(r.Observation)
                .Select(v => alpha[i] * v).ToImmutableArray())
            .Aggregate(ImmutableArray.CreateRange(new double[d]), Add);
        var (values, vectors) = H.SymmetricEigen();
        double cut = relTol * Math.Max(1.0, values.Max());
        var res = b.Zip(H.Apply(z), (p, q) => p - q).ToImmutableArray();
        var coef = Enumerable.Range(0, d)
            .Select(k => values[k] <= cut ? 0.0
                : Enumerable.Range(0, d).Sum(j => vectors[j, k] * res[j])
                  / values[k])
            .ToImmutableArray();
        var m = Enumerable.Range(0, d)
            .Select(j => z[j]
                + Enumerable.Range(0, d).Sum(k => vectors[j, k] * coef[k]))
            .ToImmutableArray();
        return new SheafRead(alpha, H, b, m, values.Min(), values.Min() <= cut);
    }

    /// <summary>Damped step z + lambda (m - z); it lowers E_s
    /// for 0 &lt; lambda &lt; 2.</summary>
    public static Vec Step(Vec z, SheafRead read, double lambda) =>
        z.Zip(read.Value, (p, m) => (1 - lambda) * p + lambda * m)
         .ToImmutableArray();

    /// <summary>Guaranteed decrease lambda (2 - lambda) |z - m|_H^2 / 2.</summary>
    public static double GuaranteedDecrease(Vec z, SheafRead read, double lambda)
    {
        var d = z.Zip(read.Value, (p, m) => p - m).ToImmutableArray();
        double q = d.Zip(read.Normal.Apply(d), (p, h) => p * h).Sum();
        return 0.5 * lambda * (2 - lambda) * q;
    }

    /// <summary>Truncation certificate
    /// R min(1, (W - W_S) exp(-rho^2 / 2 s^2) / D_S).</summary>
    public static double TruncationCertificate(double diameter, double totalWeight,
                                               double starWeight, double starMass,
                                               double rho, double s) =>
        diameter * Math.Min(1.0, (totalWeight - starWeight)
                                 * Math.Exp(-rho * rho / (2 * s * s)) / starMass);
}

public static class SymmetricReads
{
    static double Dist2(Vec a, Vec b) =>
        a.Zip(b, (p, q) => (p - q) * (p - q)).Sum();

    static Vec Mean(Vec logits, ImmutableArray<Vec> points)
    {
        double peak = logits.Max();
        var w = logits.Select(v => Math.Exp(v - peak)).ToImmutableArray();
        return Enumerable.Range(0, points[0].Length)
            .Select(j => Enumerable.Range(0, points.Length)
                .Sum(i => w[i] * points[i][j]) / w.Sum())
            .ToImmutableArray();
    }

    /// <summary>Reads over all group images, and over the nearest image
    /// of each record.</summary>
    public static (Vec All, Vec Nearest) Read(
        Vec z, ImmutableArray<Vec> records, Vec logWeights,
        ImmutableArray<Matrix> group, double s)
    {
        double Logit(int i, Vec x) => logWeights[i] - Dist2(z, x) / (2 * s * s);
        var images = records
            .Select(y => group.Select(g => g.Apply(y)).ToImmutableArray())
            .ToImmutableArray();
        var all = images.SelectMany((im, i) => im.Select(x => (x, l: Logit(i, x))))
                        .ToImmutableArray();
        var near = images.Select(im => im.OrderBy(x => Dist2(z, x)).First())
                         .ToImmutableArray();
        return (Mean(all.Select(p => p.l).ToImmutableArray(),
                     all.Select(p => p.x).ToImmutableArray()),
                Mean(near.Select((x, i) => Logit(i, x)).ToImmutableArray(), near));
    }
}
