import math, numpy as np, sys
sys.path.insert(0, ".")
import p2_checks as P
rng = np.random.default_rng(5)
P.rng = rng
worst = []
for t in range(300):
    D, Qs, obs, logw = P.random_setup(["general", "mask", "partial"][t % 3])
    z = rng.standard_normal(D); s = float(rng.uniform(0.7, 3.0))
    J, a, H, m = P.jacobian_formula(z, Qs, obs, logw, s)
    lmin = np.linalg.eigvalsh(H).min()
    for h in [1e-4, 1e-6]:
        Jfd = np.column_stack([(P.read(z + h * e, Qs, obs, logw, s)[3] - P.read(z - h * e, Qs, obs, logw, s)[3]) / (2 * h) for e in np.eye(D)])
        err = float(np.abs(J - Jfd).max() / (1 + np.abs(Jfd).max()))
        worst.append((err, h, lmin, np.linalg.cond(H), t % 3))
worst.sort(reverse=True)
for w in worst[:6]: print(w)
# angle jump bound violations
def wrap(x): return (x + math.pi) % (2 * math.pi) - math.pi
cnt = 0
for _ in range(300):
    n = int(rng.integers(2, 10)); th = rng.uniform(0, 2 * math.pi, n); logw = rng.normal(0, 0.5, n)
    s = float(rng.uniform(0.4, 1.5)); k = int(rng.integers(n))
    tz0 = th[k] + math.pi
    dd = np.array([wrap(t - tz0) for t in th])
    a = P.softmax(logw - dd ** 2 / (2 * s * s))
    others = np.delete(np.arange(n), k)
    jstar = others[np.argmin(np.abs(dd[others]))]
    bound = 2 * math.pi * math.exp(logw[k] - logw[jstar] - (math.pi ** 2 - dd[jstar] ** 2) / (2 * s * s))
    if 2 * math.pi * a[k] > bound + 1e-9:
        cnt += 1
        if cnt < 4: print("viol", dd[k], dd[jstar], a[k], bound / (2 * math.pi))
print("violations", cnt)
