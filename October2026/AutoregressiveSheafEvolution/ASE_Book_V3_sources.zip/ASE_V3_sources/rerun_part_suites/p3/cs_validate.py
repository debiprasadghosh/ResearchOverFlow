# Recompute every number printed by the Part III C# kernel (cs/cs_out.txt) with an independent NumPy implementation.
import json, math, os
import numpy as np

here = os.path.dirname(os.path.abspath(__file__))
fmt = lambda name, xs: name + " " + " ".join(f"{float(x):.15g}" for x in xs)


def coeffs(s, eta):
    T = len(s) - 1; lam = np.zeros(T + 1); sig = np.zeros(T + 1)
    for t in range(1, T + 1):
        v = eta ** 2 * s[t - 1] ** 2 * (s[t] ** 2 - s[t - 1] ** 2) / s[t] ** 2
        lam[t] = 1 - math.sqrt(max(s[t - 1] ** 2 - v, 0.0)) / s[t]; sig[t] = math.sqrt(v)
    pi = np.array([0.0] + [np.prod(1 - lam[1:t]) for t in range(1, T + 1)])
    return lam, sig, pi, lam * pi, float(np.prod(1 - lam[1:]))


def read(z, Y, lw, s):
    l = lw - np.sum((Y - z) ** 2, 1) / (2 * s * s); a = np.exp(l - l.max()); a /= a.sum()
    m = a @ Y; d = Y - m
    return a, m, (a[:, None] * d).T @ d


def stack(zT, Y, lw, s, eta, noise):
    lam, sig, *_ = coeffs(s, eta); z = zT.copy(); K = np.eye(len(z)); steps = []
    for t in range(len(s) - 1, 0, -1):
        a, m, C = read(z, Y, lw, s[t]); J = (1 - lam[t]) * np.eye(len(z)) + lam[t] * C / s[t] ** 2
        steps.append((t, z.copy(), m, C, J))
        z = (1 - lam[t]) * z + lam[t] * m + (sig[t] * noise[t - 1] if sig[t] > 0 else 0.0); K = J @ K
    return z, steps, K


lines = []
s = np.array([0.2, 0.35, 0.6, 1.0, 1.7, 3.0])
lam, sig, pi, om, ws = coeffs(s, 0.5)
lines += [fmt("lambda", lam[1:]), fmt("noise_std", sig[1:]), fmt("omega", om[1:]), fmt("omega_star", [ws]),
          fmt("noise_budget", [np.sum(pi[1:] ** 2 * sig[1:] ** 2), s[0] ** 2 - ws ** 2 * s[-1] ** 2])]
st = np.tan(np.pi * np.arange(1, 16) / 32)                       # scales of levels cos^2(pi t / 32), t = 1..15
w = [st[0] * (1 / st[t - 1] - 1 / st[t]) for t in range(1, 15)]  # weights of reads at layers 2..15 in z_1
lines.append(fmt("cosine_weights_in_z1", [w[0], w[1], w[2], w[3], sum(w[4:]) + st[0] / st[14]]))
Y = np.array([[0.0, 0.0], [1.0, 0.2], [0.4, 1.1], [2.2, 1.5], [-0.8, 0.9]]); lw = np.array([0.0, 0.3, -0.2, 0.1, -0.4])
noise = [np.array([math.sin(1.7 * t + 0.3), math.sin(1.7 * t + 1.2)]) for t in range(1, 6)]
zT = np.array([2.5, -1.2])
out, steps, _ = stack(zT, Y, lw, s, 0.5, noise)
sep = ws * zT + sum(om[t] * m + pi[t] * sig[t] * noise[t - 1] for t, _, m, _, _ in steps)
lines += [fmt("noisy_output", out), fmt("separation_residual", [np.abs(out - sep).max()])]
dout, dsteps, K = stack(zT, Y, lw, s, 0.0, None)
sv = np.linalg.svd(K, compute_uv=False)
ev = [np.linalg.eigvalsh(J) for *_, J in dsteps]
lines += [fmt("det_output", dout), fmt("singular_values", sv),
          fmt("product_bounds", [np.prod([e[0] for e in ev]), np.prod([e[-1] for e in ev])]),
          fmt("schedule_floor", [s[0] / s[-1]]),
          fmt("log_volume", [sum(np.sum(np.log(np.abs(e))) for e in ev), np.sum(np.log(sv))])]
sc = np.sqrt((1 - np.cos(np.pi * np.arange(8) / 16) ** 2) / np.cos(np.pi * np.arange(8) / 16) ** 2)
cout, csteps, Kc = stack(zT, Y, lw, sc, 0.0, None)
c1 = np.sort(np.linalg.eigvalsh(csteps[-1][3]))[::-1]
lines += [fmt("clean_output", cout), fmt("clean_singular_values", np.linalg.svd(Kc, compute_uv=False)),
          fmt("clean_lower", c1 / (sc[1] * sc[7]))]
P = np.array([[-1.0, 0.0], [1.0, 0.0]]); lwp = np.zeros(2)
lines.append(fmt("expanding", [int(np.sum(np.linalg.eigvalsh(read(np.zeros(2), P, lwp, x)[2]) / x ** 2 > 1 + 1e-9))
                               for x in (0.8, 1.2)]))
z = np.array([0.7, 0.4]); a, m, C = read(z, Y, lw, 0.6); d = Y - m
lines.append(fmt("curvature", (C @ (z - m) - (a * np.sum(d ** 2, 1)) @ d) / 0.6 ** 4))

got = [ln.split() for ln in open(os.path.join(here, "cs", "cs_out.txt")) if ln.strip()]
exp = [ln.split() for ln in lines]
worst, agree, per_line, identical = 0.0, 0, [], 0
for g, e in zip(got, exp):
    ok = g[0] == e[0] and len(g) == len(e); line_worst = 0.0
    for x, y in zip(g[1:], e[1:]):
        scale = max(abs(float(y)), 1e-12) if e[0] != "separation_residual" else 1.0
        rel = abs(float(x) - float(y)) / scale
        line_worst = max(line_worst, rel); ok &= rel < 1e-9
    worst = max(worst, line_worst); agree += ok; per_line.append(line_worst)
    identical += [float(x) for x in g[1:]] == [float(y) for y in e[1:]] and g[0] == e[0]
res = dict(lines=len(exp), agree=agree, identical=identical, worst_rel_diff=worst, per_line=per_line,
           csharp=[" ".join(g) for g in got], python=lines)
json.dump(res, open(os.path.join(here, "cs_validate.json"), "w"), indent=1)
print(json.dumps({k: v for k, v in res.items() if k in ("lines", "agree", "identical", "worst_rel_diff")}))
for g, e, r in zip(res["csharp"], res["python"], per_line):
    print(f"{r:9.2e} | {g}\n          | {e}")
