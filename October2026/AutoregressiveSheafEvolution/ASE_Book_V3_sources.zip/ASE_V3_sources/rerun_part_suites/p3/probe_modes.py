import numpy as np
def reads(Z, Y, lw, s):
    d2 = ((Z[:, None, :] - Y[None]) ** 2).sum(-1); L = lw[None] - d2 / (2 * s * s); L -= L.max(1, keepdims=True)
    A = np.exp(L); A /= A.sum(1, keepdims=True); return A @ Y, A
def modes(Y, lw, s, grid=60, iters=3000):
    lo, hi = Y.min(0) - 3 * s, Y.max(0) + 3 * s
    g = np.stack(np.meshgrid(*[np.linspace(lo[k], hi[k], grid) for k in range(Y.shape[1])]), -1).reshape(-1, Y.shape[1])
    Z = np.vstack([g, Y])
    for _ in range(iters):
        Zn, _ = reads(Z, Y, lw, s)
        if np.abs(Zn - Z).max() < 1e-12: Z = Zn; break
        Z = Zn
    pts = []
    for z in Z:
        if not any(np.linalg.norm(z - p) < 1e-4 for p in pts): pts.append(z)
    out = []
    for p in pts:
        m, A = reads(p[None], Y, lw, s); C = (A[0][:, None] * (Y - m[0])).T @ (Y - m[0])
        if np.linalg.eigvalsh(C).max() < s * s - 1e-9: out.append(p)
    return out
Y = np.array([[0, 0], [1, 0], [0.5, np.sqrt(3) / 2]]); lw = np.zeros(3)
for s in np.linspace(0.40, 0.62, 23):
    ms = modes(Y, lw, s, grid=45)
    print(round(s, 3), len(ms))
