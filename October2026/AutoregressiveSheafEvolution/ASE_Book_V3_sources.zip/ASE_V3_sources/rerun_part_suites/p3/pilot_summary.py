# Derived quantities and tables for Section 5.3, computed from p3_explore.json.
import numpy as np
from scipy.stats import spearmanr

NAMES = {"cosine": "cosine", "geometric": "geometric", "edm": "EDM, $\\rho=7$", "barcode": "barcode, quantiles",
         "barcode_coarse": "barcode, longest bars", "barcode_mass": "barcode, mass-weighted", "curvature": "curvature, $\\rho\\propto\\sqrt g$"}
BAR = ["barcode", "barcode_coarse", "barcode_mass"]


def pooled(e, reg, kind, k, m):
    return float(np.mean([e["summary"][reg][str(D)][f"{kind}|{k}"][m] for D in e["dims"]]))


def spearman(e, reg):
    """Rank correlation between the model error (5.4) and the observed loss, per instance and layer count."""
    rs = []
    for r in e["per_instance"]:
        for k in [8, 16, 32]:
            mod = [r["results"][reg][f"{kind}|{k}"]["model"] for kind in e["schedules"]]
            los = [r["results"][reg][f"{kind}|{k}"]["loss"] for kind in e["schedules"]]
            rs.append(spearmanr(mod, los).correlation)
    return float(np.median(rs)), float(np.mean(np.array(rs) > 0))


def derive(e):
    c3 = e["c3"]
    fine = [r for r in c3 if r["regime"] == "fine"]
    out = dict(pilot_instances=len(e["per_instance"]))
    for reg in ["fine", "coarse"]:
        rows = [r for r in c3 if r["regime"] == reg]
        for kind in BAR + ["curvature"]:
            sub = [r for r in rows if r["schedule"] == kind]
            out[f"n_{reg}_{kind}"] = len(sub)
            for verdict in ["refuted", "supported", "inconclusive"]:
                out[f"{verdict}_{reg}_{kind}"] = sum(r["verdict"] == verdict for r in sub)
            out[f"min_deg_{reg}_{kind}"] = min(r["loss_vs_cosine_2k"]["est"] for r in sub)
            out[f"max_deg_{reg}_{kind}"] = max(r["loss_vs_cosine_2k"]["est"] for r in sub)
            out[f"geo_better_{reg}_{kind}"] = sum(r["loss_vs_geometric_k"]["hi"] < 0 for r in sub)
            out[f"geo_worse_{reg}_{kind}"] = sum(r["loss_vs_geometric_k"]["lo"] > 0 for r in sub)
        med, pos = spearman(e, reg)
        out[f"spearman_{reg}"] = med; out[f"spearman_pos_{reg}"] = pos
        for kind in e["schedules"]:
            out[f"eff_{reg}_{kind}"] = float(np.median([e["summary"][reg][str(D)][f"{kind}|16"]["efficiency_median"] for D in e["dims"]]))
            for k in e["layer_counts"]:
                out[f"loss_{reg}_{kind}_{k}"] = pooled(e, reg, kind, k, "loss")
                out[f"novel_{reg}_{kind}_{k}"] = pooled(e, reg, kind, k, "novel")
                out[f"branch_{reg}_{kind}_{k}"] = pooled(e, reg, kind, k, "branch")
    # post hoc: curvature against cosine with the same number of layers (paired bootstrap, fixed seed)
    rng = np.random.default_rng(20261025); better = worse = total = 0; ests = []
    for reg in ["fine", "coarse"]:
        for D in e["dims"]:
            rs = [r for r in e["per_instance"] if r["D"] == D]
            for k in e["layer_counts"]:
                a = np.array([r["results"][reg][f"curvature|{k}"]["loss"] for r in rs])
                b = np.array([r["results"][reg][f"cosine|{k}"]["loss"] for r in rs])
                idx = rng.integers(0, len(a), (10000, len(a))); bs = a[idx].mean(1) / b[idx].mean(1) - 1
                lo, hi = np.quantile(bs, [0.025, 0.975]); est = a.mean() / b.mean() - 1
                total += 1; better += hi < 0; worse += lo > 0; ests.append(est)
    out.update(eq_total=total, eq_better=int(better), eq_worse=int(worse), eq_best=float(min(ests)), eq_worst=float(max(ests)))
    # degradation of the curvature schedule against cosine with twice the layers, fine top
    cu = [r["loss_vs_cosine_2k"]["est"] for r in fine if r["schedule"] == "curvature"]
    out.update(cu2_min=float(min(cu)), cu2_max=float(max(cu)))
    bq = [r["loss_vs_cosine_2k"]["est"] for r in c3 if r["schedule"] in BAR]
    out.update(bar2_min=float(min(bq)), bar2_max=float(max(bq)), bar_total=len(bq),
               bar_refuted=sum(r["verdict"] == "refuted" for r in c3 if r["schedule"] in BAR))
    nov = [r for r in fine if r["schedule"] == "barcode"]
    out["nov_outside"] = sum(r["novel_vs_cosine_2k"]["hi"] < -2 or r["novel_vs_cosine_2k"]["lo"] > 2 for r in nov)
    out["loss_only"] = sum(r["loss_vs_cosine_2k"]["lo"] > 0.02 for r in nov)
    # reference novelty shares, when recorded
    for reg in ["fine", "coarse"]:
        vals = [e["summary"][reg][str(D)].get("novel_ref") for D in e["dims"]]
        if all(v is not None for v in vals):
            for D, val in zip(e["dims"], vals):
                out[f"novel_ref_{reg}_{D}"] = val
            out[f"novel_ref_{reg}"] = float(np.mean(vals))
        for kind in e["schedules"]:
            for k in e["layer_counts"]:
                for D in e["dims"]:
                    out[f"novel_{reg}_{kind}_{k}_D{D}"] = e["summary"][reg][str(D)][f"{kind}|{k}"]["novel"]
    # how much a halving of layers costs the cosine schedule itself, pooled, fine top
    out["cos_halving"] = [out[f"loss_fine_cosine_{k}"] / out[f"loss_fine_cosine_{2 * k}"] for k in [8, 16, 32]]
    out["cos_halving_min"] = min(out["cos_halving"]); out["cos_halving_max"] = max(out["cos_halving"])
    cells = best_cells = 0
    for reg in ["fine", "coarse"]:
        for D in e["dims"]:
            for k in e["layer_counts"]:
                vals = {kind: e["summary"][reg][str(D)][f"{kind}|{k}"]["loss"] for kind in e["schedules"]}
                cells += 1; best_cells += min(vals, key=vals.get) == "curvature"
    out.update(best_cells=best_cells, cells=cells, pooled_best=all(
        min(e["schedules"], key=lambda kind: out[f"loss_{reg}_{kind}_{k}"]) == "curvature"
        for reg in ["fine", "coarse"] for k in e["layer_counts"]))
    pc = lambda x: f"{100 * x:.1f}%"
    cos = [pc(out[f"novel_fine_cosine_64_D{D}"]) for D in e["dims"]]
    geo = [pc(out[f"novel_fine_geometric_64_D{D}"]) for D in e["dims"]]
    if "novel_ref_fine" in out:
        ref = [pc(out[f"novel_ref_fine_{D}"]) for D in e["dims"]]
        lead = (f"Novelty needs a caveat. With a fine top, the share of novel outputs of the reference transport was "
                f"{ref[0]}, {ref[1]} and {ref[2]} in dimensions 2, 4 and 8. ")
    else:
        lead = "Novelty needs a caveat. "
    out["novelty_paragraph"] = (lead + f"Cosine with 64 layers still produced {cos[0]}, {cos[1]} and {cos[2]} novel outputs, "
        f"against {geo[0]}, {geo[1]} and {geo[2]} for geometric spacing. Cosine spacing ends with a long step to the finest "
        "scale, and the final read then blends neighbouring records. Matching the novelty share of cosine with $2k$ layers "
        "is therefore not the same as matching the transport, and the novelty half of C3 should be stated against the "
        "continuum reference.")
    out["conclusion_pilot"] = (f"An exploratory pilot refuted hypothesis C3 in all {out['bar_total']} comparisons, because "
        "merge radii crowd the fine scales, while a curvature schedule computed from the archive alone was the best of seven "
        "at equal numbers of layers.")
    out["c3_summary"] = (f"{out['bar_refuted']} of {out['bar_total']} barcode comparisons refuted; "
                         f"curvature schedule best at every layer count")
    out["eff_rank_text"] = (f"median Spearman {out['spearman_fine']:.2f} and {out['spearman_coarse']:.2f}; "
                            f"positive in every archive")
    rc = e["reference_check"]
    out["ref_change_max"] = max(v["fine_changed"] for v in rc.values())
    out["ref_dev_max"] = max(max(v["fine"], v["coarse"]) for v in rc.values())
    return out


def table(e, name):
    d = derive(e)
    if name == "loss":                     # pooled mean loss by schedule and layer count, fine and coarse tops
        lines = []
        for kind in e["schedules"]:
            cells = [f"{d[f'loss_fine_{kind}_{k}']:.3f}" for k in e["layer_counts"]]
            lines.append(f"| {NAMES[kind]} | " + " | ".join(cells) + f" | {d[f'eff_fine_{kind}']:.2f} | {d[f'loss_coarse_{kind}_16']:.3f} |")
        return "\n".join(lines)
    if name == "c3":                       # quantile barcode with k layers against cosine with 2k layers, fine top
        lines = []
        for r in [q for q in e["c3"] if q["regime"] == "fine" and q["schedule"] == "barcode"]:
            l, n, g = r["loss_vs_cosine_2k"], r["novel_vs_cosine_2k"], r["loss_vs_geometric_k"]
            cu = [q for q in e["c3"] if q["regime"] == "fine" and q["schedule"] == "curvature" and q["D"] == r["D"] and q["k"] == r["k"]][0]
            pc = lambda x: f"{100 * x:+.0f}".replace("-", "−")
            pp = lambda x: f"{x:+.1f}".replace("-", "−")
            lines.append(f"| {r['D']} | {r['k']} | {pc(l['est'])} ({pc(l['lo'])}, {pc(l['hi'])}) | "
                         f"{pp(n['est'])} ({pp(n['lo'])}, {pp(n['hi'])}) | {r['verdict']} | {pc(g['est'])} | "
                         f"{pc(cu['loss_vs_cosine_2k']['est'])} |")
        return "\n".join(lines)
    raise KeyError(name)
