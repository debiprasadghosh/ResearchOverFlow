# Supplementary checks for ASE Part III: the tangent sandwich on the experiment of Part I, thresholded ranks along realised
# fibre diagrams, the concentration bound for path curvature, and the Morse balance of the equilateral triangle.
import json, math, os, sys
import numpy as np
from p3_core import reads, covariance, barcode_from_ranks

here = os.path.dirname(os.path.abspath(__file__))
X = {}


# ---------------------------------------------------------------- A. the experiment of Part I, Figure 4, replayed exactly
def part_one_tokens():
    """Replay the random stream of the Part I main script up to its tangent check, then rebuild that archive and those tokens."""
    p1 = os.path.join(here, "part_one")                 # the code archive ships Part I's script here
    if not os.path.exists(os.path.join(p1, "p1_checks.py")):
        p1 = os.path.join(here, "..", "p1")
    sys.path.insert(0, p1)
    cwd = os.getcwd(); os.chdir(p1)
    import p1_checks as PC
    for fn in [PC.check_delta_squared, PC.check_hodge_residual, PC.check_holonomy, PC.check_triangle_flat, PC.check_harary,
               PC.check_contexts, PC.check_two_arcs, PC.check_pullback, PC.check_barcodes]:
        fn()
    os.chdir(cwd)
    rng = PC.rng
    centres = np.array([[0.0, 0.0], [2.5, 0.0], [1.2, 2.2]])
    Y = np.concatenate([c + 0.35 * rng.standard_normal((10, 2)) for c in centres])
    starts = []
    T = 16; a = [math.cos(math.pi * t / (2 * T)) ** 2 for t in range(T)]
    for tok in range(1000):
        starts.append(rng.standard_normal(2) / math.sqrt(a[T - 1]))   # the Part I loop draws nothing else per token
    return Y, np.array(starts), a


def path_jacobians(z, Y, a):
    """Layer Jacobians J_t, t = 15..1, along the deterministic clean-top path of Part I."""
    T = len(a); s = [math.sqrt((1 - x) / x) for x in a]; s[0] = 0.0
    lw = np.zeros(len(Y)); Js = {}; Cs = {}
    for t in range(T - 1, 0, -1):
        lam = 1 - s[t - 1] / s[t]
        m, A = reads(z[None], Y, lw, s[t]); C = covariance(A[0], Y, m[0])
        Js[t] = (1 - lam) * np.eye(2) + lam * C / s[t] ** 2; Cs[t] = C
        z = (1 - lam) * z + lam * m[0]
    return Js, Cs, s


def extra_part_one():
    Y, starts, a = part_one_tokens()
    lower_ok = upper_ok = 0; ratio = {0: [], 1: []}; excess = []; c1s = {0: [], 1: []}; svs = {0: [], 1: []}
    neg = {"0.01": 0, "0.001": 0}; exact_neg = 0; expand = []
    for z in starts:
        Js, Cs, s = path_jacobians(z.copy(), Y, a)
        K = np.eye(2)
        for t in range(15, 0, -1):
            K = Js[t] @ K
        sv = np.linalg.svd(K, compute_uv=False); tol = 1e-12 * sv[0]
        c1 = np.sort(np.linalg.eigvalsh(Cs[1]))[::-1]
        expand.append([np.linalg.eigvalsh(Cs[t]).max() / s[t] ** 2 > 1 for t in range(15, 0, -1)])
        E = np.prod([np.linalg.eigvalsh(Js[t])[-1] / (s[t - 1] / s[t]) for t in range(2, 16)])
        lower = c1 / (s[1] * s[15]); upper = lower * E
        lower_ok += bool(np.all(sv >= lower - tol)); upper_ok += bool(np.all(sv <= upper * (1 + 1e-12) + tol))
        excess.append(E)
        for k in (0, 1):
            c1s[k].append(c1[k]); svs[k].append(sv[k])
            if c1[k] > 1e-12:
                ratio[k].append(sv[k] / lower[k])
        # rank functions of the realised fibre diagram V_15 -> ... -> V_0, all equal to R^2
        def composite(a_, b):
            M = np.eye(2)
            for t in range(a_, b, -1):
                M = Js[t] @ M
            return M
        cache = {(a_, b): np.linalg.svd(composite(a_, b), compute_uv=False) for a_ in range(16) for b in range(a_ + 1)}
        for key, tau in (("0.01", 1e-2), ("0.001", 1e-3)):
            r = lambda a_, b: int(np.sum(cache[(a_, b)] > tau))
            neg[key] += min(barcode_from_ranks(r, 15).values()) < 0
        rex = lambda a_, b: int(np.sum(cache[(a_, b)] > 1e-14 * max(1.0, cache[(a_, b)][0])))
        exact_neg += min(barcode_from_ranks(rex, 15).values()) < 0
    X["part_one"] = dict(tokens=len(starts), s1_times_s15=float(math.tan(math.pi / 32) * math.tan(15 * math.pi / 32)),
                         lower_holds=lower_ok, upper_holds=upper_ok,
                         median_sv=[float(np.median(svs[0])), float(np.median(svs[1]))],
                         median_c1=[float(np.median(c1s[0])), float(np.median(c1s[1]))],
                         median_ratio=[float(np.median(ratio[0])), float(np.median(ratio[1]))],
                         excess_median=float(np.median(excess)), excess_q90=float(np.quantile(excess, 0.9)),
                         excess_max=float(np.max(excess)),
                         negative_multiplicity_tokens=neg, exact_negative_tokens=int(exact_neg),
                         expanding_share=np.mean(expand, 0).tolist(), expanding_any=float(np.mean(np.any(expand, 1))),
                         first_expanding_layer=int(15 - np.argmax(np.mean(expand, 0) > 0)))


# ---------------------------------------------------------------- B. curvature of token paths is small when the read is concentrated
def extra_curvature_bound():
    rng = np.random.default_rng(20261023)
    viol = 0; cases = 4000; ratios = []
    for _ in range(cases):
        D, n = int(rng.integers(1, 5)), int(rng.integers(2, 11))
        Y = 2 * rng.standard_normal((n, D)); lw = rng.normal(0, 0.5, n)
        s = float(np.exp(rng.uniform(math.log(0.05), math.log(5)))); z = Y[int(rng.integers(n))] + s * rng.standard_normal(D) * rng.uniform(0, 3)
        m, A = reads(z[None], Y, lw, s); C = covariance(A[0], Y, m[0])
        dev = Y - m[0]; M3 = (A[0] * np.sum(dev ** 2, 1)) @ dev
        zpp = (C @ (z - m[0]) - M3) / s ** 4
        j = int(np.argmax(A[0])); eps = float(np.sum(np.delete(A[0], j)))   # off-record mass, summed directly
        Rd = max(np.linalg.norm(p - q) for p in Y for q in Y)
        bound = eps * (Rd ** 2 * np.linalg.norm(z - m[0]) + Rd ** 3 * (1 + eps ** 2)) / s ** 4
        viol += np.linalg.norm(zpp) > bound * (1 + 1e-10) + 1e-300
        if bound > 0:
            ratios.append(np.linalg.norm(zpp) / bound)
    X["curvature_bound"] = dict(cases=cases, violations=int(viol), ratio_max=float(max(ratios)), ratio_median=float(np.median(ratios)))


# ---------------------------------------------------------------- C. the Morse balance of the equilateral triangle across scales
def newton(z, Y, lw, s, iters=100):
    for _ in range(iters):
        m, A = reads(z[None], Y, lw, s); C = covariance(A[0], Y, m[0])
        F = m[0] - z; Jf = C / s ** 2 - np.eye(len(z))
        try:
            step = np.linalg.solve(Jf, -F)
        except np.linalg.LinAlgError:
            return None
        if np.linalg.norm(step) > 1.0:
            step = step / np.linalg.norm(step)
        z = z + step
        if np.linalg.norm(step) < 1e-14:
            break
    return z if np.linalg.norm(reads(z[None], Y, lw, s)[0][0] - z) < 1e-10 else None


def extra_triangle_morse():
    Y = np.array([[0.0, 0.0], [1.0, 0.0], [0.5, math.sqrt(3) / 2]]); lw = np.zeros(3)
    rows = []
    for s in [0.30, 0.35, 0.39, 0.40, 0.405, 0.41, 0.415, 0.42, 0.425, 0.43, 0.45, 0.50]:
        found = []
        for x in np.linspace(-0.4, 1.4, 46):
            for y in np.linspace(-0.4, 1.3, 46):
                z = newton(np.array([x, y]), Y, lw, s)
                if z is not None and not any(np.linalg.norm(z - p) < 1e-7 for p in found):
                    found.append(z)
        cnt = [0, 0, 0]; centroid_eig = None
        for z in found:
            m, A = reads(z[None], Y, lw, s); C = covariance(A[0], Y, m[0]); ev = np.linalg.eigvalsh(C) / s ** 2
            cnt[int(np.sum(ev > 1 + 1e-9))] += 1
            if np.linalg.norm(z - Y.mean(0)) < 1e-6:
                centroid_eig = float(ev.max())
        rows.append(dict(s=s, energy_minima=cnt[0], saddles=cnt[1], energy_maxima=cnt[2], balance=cnt[0] - cnt[1] + cnt[2],
                         centroid_tangent=centroid_eig))
    # the centroid changes type where C/s^2 there equals one; by symmetry C(centroid) = (side^2/6) I at every scale
    m, A = reads(Y.mean(0)[None], Y, lw, 0.4); Cc = covariance(A[0], Y, m[0])
    # the fold: on the ray from the centroid to a vertex, F(r) = u.(m - z) has a positive bump between the saddle and
    # the vertex mode while both exist; the fold is the scale at which the bump touches zero
    c = Y.mean(0); u = (Y[2] - c) / np.linalg.norm(Y[2] - c); r = np.linspace(0.02, 0.8, 40001)
    def bump(sc):
        Z = c[None] + r[:, None] * u[None]; mm, _ = reads(Z, Y, lw, sc)
        return float(np.max((mm - Z) @ u))
    lo, hi = 0.42, 0.43
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        lo, hi = (mid, hi) if bump(mid) > 0 else (lo, mid)
    X["triangle_morse"] = dict(rows=rows, centroid_covariance=float(Cc[0, 0]), centroid_switch_scale=float(math.sqrt(Cc[0, 0])),
                               fold_scale=0.5 * (lo + hi), circumradius_units=dict(switch=float(math.sqrt(Cc[0, 0]) * math.sqrt(3)),
                                                                             fold=0.5 * (lo + hi) * math.sqrt(3)))


if __name__ == "__main__":
    for fn in [extra_curvature_bound, extra_triangle_morse, extra_part_one]:
        fn(); print("done", fn.__name__, flush=True)
    json.dump(X, open(os.path.join(here, "p3_extras.json"), "w"), indent=1,
              default=lambda o: o.tolist() if hasattr(o, "tolist") else (int(o) if isinstance(o, np.integer) else str(o)))
    print(json.dumps(X, indent=1, default=str))
