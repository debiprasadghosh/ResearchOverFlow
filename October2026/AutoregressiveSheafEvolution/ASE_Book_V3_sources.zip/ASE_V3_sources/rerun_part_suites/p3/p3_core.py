# Shared primitives for ASE Part III: schedules in scaled coordinates, the layer recurrence, reads, tangents and modes.
import math
import numpy as np


def scales_from_levels(a):
    """Signal levels a_0..a_T (a_0 at the top) to scales s_t = sqrt((1 - a_t)/a_t)."""
    a = np.asarray(a, float)
    return np.sqrt((1 - a) / a)


def coefficients(s, eta):
    """Interpolation weights lambda_t and scaled noise standard deviations for t = 1..T (index 0 unused).
    s[0] is the top scale (smallest) and s[T] the bottom scale (largest)."""
    T = len(s) - 1
    lam = np.zeros(T + 1); sig = np.zeros(T + 1)
    for t in range(1, T + 1):
        sig2 = eta ** 2 * s[t - 1] ** 2 * (s[t] ** 2 - s[t - 1] ** 2) / s[t] ** 2
        lam[t] = 1 - math.sqrt(max(s[t - 1] ** 2 - sig2, 0.0)) / s[t]
        sig[t] = math.sqrt(sig2)
    return lam, sig


def separation_weights(lam):
    """pi_t, omega_t for t = 1..T and omega_star (index 0 unused)."""
    T = len(lam) - 1
    pi = np.zeros(T + 1); om = np.zeros(T + 1); run = 1.0
    for t in range(1, T + 1):
        pi[t] = run; om[t] = lam[t] * run; run *= 1 - lam[t]
    return pi, om, run


def reads(Z, Y, lw, s):
    """Gaussian reads with identity maps for a batch of tokens Z (N x D) and records Y (n x D)."""
    d2 = ((Z[:, None, :] - Y[None]) ** 2).sum(-1)
    L = lw[None] - d2 / (2 * s * s)
    L = L - L.max(1, keepdims=True)
    A = np.exp(L); A /= A.sum(1, keepdims=True)
    return A @ Y, A


def covariance(a, Y, m):
    d = Y - m
    return (a[:, None] * d).T @ d


def run_stack(Z, Y, lw, s, eta, noise=None, keep=False):
    """Run the layer recurrence from the bottom (t = T) to the top. noise[t] has the shape of Z."""
    lam, sig = coefficients(s, eta)
    T = len(s) - 1
    traj = [Z.copy()]; rd = {}
    for t in range(T, 0, -1):
        m, _ = reads(Z, Y, lw, s[t]) if s[t] > 0 else (Z, None)
        rd[t] = m
        Z = (1 - lam[t]) * Z + lam[t] * m + (sig[t] * noise[t] if noise is not None and sig[t] > 0 else 0.0)
        if keep:
            traj.append(Z.copy())
    return (Z, traj, rd) if keep else Z


def layer_jacobian(z, Y, lw, s, lam):
    m, A = reads(z[None], Y, lw, s)
    C = covariance(A[0], Y, m[0])
    return (1 - lam) * np.eye(len(z)) + lam * C / (s * s), C


def kde_sample(Y, lw, s, N, rng):
    w = np.exp(lw - lw.max()); w /= w.sum()
    idx = rng.choice(len(Y), size=N, p=w)
    return Y[idx] + s * rng.standard_normal((N, Y.shape[1])), idx


def mixture_cdf_1d(x, Y, lw, s):
    from math import erf
    w = np.exp(lw - lw.max()); w /= w.sum()
    x = np.asarray(x)[:, None]
    return (w[None] * 0.5 * (1 + np.vectorize(erf)((x - Y[None, :, 0]) / (s * math.sqrt(2))))).sum(1)


def modes(Y, lw, s, starts=None, grid=40, iters=4000, tol=1e-4):
    """Local maxima of the archive density at scale s, by the read iteration from many starts."""
    D = Y.shape[1]
    if starts is None:
        lo, hi = Y.min(0) - 2 * s, Y.max(0) + 2 * s
        axes = [np.linspace(lo[k], hi[k], grid if D <= 2 else 8) for k in range(D)]
        starts = np.vstack([np.stack(np.meshgrid(*axes), -1).reshape(-1, D), Y])
    Z = starts.copy()
    for _ in range(iters):
        Zn, _ = reads(Z, Y, lw, s)
        done = np.abs(Zn - Z).max() < 1e-13
        Z = Zn
        if done:
            break
    pts = []
    for z in Z:
        if not any(np.linalg.norm(z - p) < tol for p in pts):
            pts.append(z)
    out = []
    for p in pts:
        m, A = reads(p[None], Y, lw, s)
        if np.linalg.norm(m[0] - p) > 1e-6:
            continue
        C = covariance(A[0], Y, m[0])
        if np.linalg.eigvalsh(C).max() < s * s * (1 - 1e-9):
            out.append(p)
    return out


def barcode_from_ranks(r, T):
    """Multiplicities m[b,d] from a rank function r(a, b) on layers T..0 (Part I, formula 4.1)."""
    def R(a, b):
        if a > T or b < 0 or a < b:
            return 0
        return r(a, b)
    out = {}
    for b in range(T, -1, -1):
        for d in range(b, -1, -1):
            out[(b, d)] = R(b, d) - R(b + 1, d) - R(b, d - 1) + R(b + 1, d - 1)
    return out
