# Exploratory pilot of hypothesis C3 of V2 in the transport setting of Part III.
# It is not the confirmatory C3 test: there is no objective, no optimiser and no preregistration. The metrics and the
# decision rule were fixed before the first run. After a trial on one instance, the flow-based pilot of the curvature
# schedule was replaced by an archive-only Monte Carlo estimate, and the mass-weighted barcode schedule was added.
# Every schedule that was run is reported.
import json, math, os, time
import numpy as np
from scipy.cluster.hierarchy import linkage
from p3_core import reads, kde_sample, run_stack

here = os.path.dirname(os.path.abspath(__file__))
SEED = 20261024
DIMS = [2, 4, 8]; INSTANCES = 20; TOKENS = 1000; KS = [4, 8, 16, 32, 64]; H = 0.004
SCHEDULES = ["cosine", "geometric", "edm", "barcode", "barcode_coarse", "barcode_mass", "curvature"]
BARCODES = ["barcode", "barcode_coarse", "barcode_mass"]; GRID = 160


def make_archive(D, rng):
    """Three levels of clusters (3 x 3 x 3 records), spreads 4, 1 and 0.25, then unit pooled per-coordinate deviation."""
    sup = 4.0 * rng.standard_normal((3, D))
    sub = np.repeat(sup, 3, 0) + 1.0 * rng.standard_normal((9, D))
    Y = np.repeat(sub, 3, 0) + 0.25 * rng.standard_normal((27, D))
    Y = (Y - Y.mean(0)) / Y.std()
    return Y, rng.normal(0, 0.5, 27)


def fill_log_gaps(points, lo, hi, extra):
    """Insert `extra` scales by repeatedly halving (geometrically) the largest gap of lo < points < hi."""
    pts = sorted(set([lo, hi] + list(points)))
    for _ in range(extra):
        g = np.diff(np.log(pts)); i = int(np.argmax(g))
        pts.insert(i + 1, math.sqrt(pts[i] * pts[i + 1]))
    return [p for p in pts if lo < p < hi]


def merge_masses(Y, lw, L):
    """Prior mass of the component formed at each single-linkage merge (rows of the linkage matrix L)."""
    w = np.exp(lw - lw.max()); w /= w.sum(); n = len(Y); mass = list(w)
    for a, b, _, _ in L:
        mass.append(mass[int(a)] + mass[int(b)])
    return np.array(mass[n:])


def curvature_density(Y, lw, grid, rng, draws=300):
    """g(s) = E||z''|| for z ~ p_s, from (5.2); along the exact flow the token at scale s has law p_s."""
    g = []
    for s in grid:
        Z, _ = kde_sample(Y, lw, s, draws, rng); m, A = reads(Z, Y, lw, s); dev = Y[None] - m[:, None]
        Cz = np.einsum("ni,nid,nie,ne->nd", A, dev, dev, Z - m)
        M3 = np.einsum("ni,ni,nid->nd", A, (dev ** 2).sum(-1), dev)
        g.append(float(np.mean(np.linalg.norm((Cz - M3) / s ** 4, axis=1))))
    return np.array(g)


def schedule(kind, k, s_min, s_max, radii=None, cum=None, masses=None):
    """Positive scales s_1 = s_min < ... < s_k = s_max; the clean top s_0 = 0 is prepended by the caller."""
    j = np.arange(k) / (k - 1)
    if kind == "cosine":
        th = math.atan(s_min) + j * (math.atan(s_max) - math.atan(s_min)); s = np.tan(th)
    elif kind == "geometric":
        s = np.exp(math.log(s_min) + j * (math.log(s_max) - math.log(s_min)))
    elif kind == "edm":
        r = 7.0; s = (s_min ** (1 / r) + j * (s_max ** (1 / r) - s_min ** (1 / r))) ** r
    elif kind in BARCODES:
        inside = np.array([r for r in radii if s_min < r < s_max]); m = k - 2
        if m <= 0:
            interior = []
        elif m <= len(inside):
            if kind == "barcode":                                   # evenly spaced ranks of the merge radii
                idx = np.unique(np.floor((np.arange(m) + 0.5) * len(inside) / m).astype(int))
                interior = list(inside[idx])
            elif kind == "barcode_coarse":                          # the m longest bars, that is the largest radii
                interior = list(np.sort(inside)[-m:])
            else:                                                   # quantiles weighted by the mass that splits there
                keep = (radii > s_min) & (radii < s_max); c = np.cumsum(masses[keep]); c = c / c[-1]
                q = (np.arange(m) + 0.5) / m
                interior = list(np.unique(np.exp(np.interp(q, c, np.log(radii[keep])))))
            if len(interior) < m:
                interior = fill_log_gaps(interior, s_min, s_max, m - len(interior))
        else:
            interior = fill_log_gaps(list(inside), s_min, s_max, m - len(inside))
        s = np.array(sorted([s_min] + list(interior) + [s_max]))
    elif kind == "curvature":                                       # equidistribute the square root of the curvature density
        grid, G = cum
        s = np.interp(j, G, grid)
    s = np.array(sorted(s)); s[0], s[-1] = s_min, s_max
    assert len(s) == k and np.all(np.diff(s) > 0), (kind, k)
    return np.concatenate([[0.0], s])


def rk4_flow(Z, Y, lw, v0, v1, curvature=False):
    """Probability-flow ODE in v = -log s: dz/dv = m - z. Optionally record the mean curvature norm along the way."""
    n = max(1, int(math.ceil((v1 - v0) / H))); h = (v1 - v0) / n; v = v0; rec = []
    f = lambda Z_, v_: reads(Z_, Y, lw, math.exp(-v_))[0] - Z_
    for _ in range(n):
        if curvature:
            s = math.exp(-v); m, A = reads(Z, Y, lw, s); dev = Y[None] - m[:, None]
            Cz = np.einsum("ni,nid,nie,ne->nd", A, dev, dev, Z - m)
            M3 = np.einsum("ni,ni,nid->nd", A, (dev ** 2).sum(-1), dev)
            rec.append((s, float(np.mean(np.linalg.norm((Cz - M3) / s ** 4, axis=1)))))
        k1 = f(Z, v); k2 = f(Z + 0.5 * h * k1, v + 0.5 * h); k3 = f(Z + 0.5 * h * k2, v + 0.5 * h); k4 = f(Z + h * k3, v + h)
        Z = Z + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4); v += h
    return Z, rec


def metrics(z0, ref, Y, d_nn):
    dist = np.linalg.norm(z0[:, None] - Y[None], axis=2); near = dist.argmin(1); novel = dist.min(1) > 1e-3 * d_nn
    dref = np.linalg.norm(ref[:, None] - Y[None], axis=2); nref = dref.argmin(1); novref = dref.min(1) > 1e-3 * d_nn
    cat = np.where(novel, len(Y), near); catr = np.where(novref, len(Y), nref)
    f = np.bincount(cat, minlength=len(Y) + 1) / len(cat); fr = np.bincount(catr, minlength=len(Y) + 1) / len(catr)
    return dict(loss=float(np.mean(np.linalg.norm(z0 - ref, axis=1)) / d_nn), novel=float(novel.mean()),
                branch=float(np.mean(near == nref)), tv=float(0.5 * np.abs(f - fr).sum()), novel_ref=float(novref.mean()))


def run_instance(D, inst):
    rng = np.random.default_rng([SEED, D, inst])
    Y, lw = make_archive(D, rng)
    radii = np.sort(linkage(Y, "single")[:, 2]) / 2
    nn = np.sort(np.linalg.norm(Y[:, None] - Y[None], axis=2), 1)[:, 1]; d_nn = float(np.median(nn))
    s_max = 2 * radii[-1]
    regimes = {"fine": radii[0] / 2, "coarse": float(np.median(radii))}
    L = linkage(Y, "single"); masses = merge_masses(Y, lw, L)
    Z, _ = kde_sample(Y, lw, s_max, TOKENS, rng)
    sg = np.exp(np.linspace(math.log(regimes["fine"]), math.log(s_max), GRID)); g = curvature_density(Y, lw, sg, rng)
    # reference: the exact flow down to each regime's finest positive scale, followed by the clean-top read there
    v0 = -math.log(s_max); vc = -math.log(regimes["coarse"]); vf = -math.log(regimes["fine"])
    Zc, _ = rk4_flow(Z, Y, lw, v0, vc); Zf, _ = rk4_flow(Zc, Y, lw, vc, vf)
    ref = {"coarse": reads(Zc, Y, lw, regimes["coarse"])[0], "fine": reads(Zf, Y, lw, regimes["fine"])[0]}
    out = dict(D=D, instance=inst, d_nn=d_nn, s_max=float(s_max), s_min=regimes, radii=radii.tolist(), results={})
    for reg, s_min in regimes.items():
        grid = np.unique(np.concatenate([[s_min], sg[(sg > s_min) & (sg < s_max)], [s_max]]))
        gg = np.maximum(np.interp(grid, sg, g), 0.0); rt = np.sqrt(gg)
        G = np.concatenate([[0], np.cumsum(0.5 * (rt[1:] + rt[:-1]) * np.diff(grid))])      # integral of sqrt(g)
        G1 = np.concatenate([[0], np.cumsum(0.5 * (gg[1:] + gg[:-1]) * np.diff(grid))])     # integral of g
        root_int = float(G[-1])
        Gs = G + 1e-9 * G[-1] * np.arange(len(G)) / (len(G) - 1)                            # strictly increasing
        G = Gs / Gs[-1]
        res = {}
        for kind in SCHEDULES:
            for k in KS:
                s = schedule(kind, k, s_min, s_max, radii=radii, cum=(grid, G), masses=masses)
                z0 = run_stack(Z.copy(), Y, lw, s, 0.0)
                sp = s[1:]; Gi = np.interp(sp, grid, G1)
                model = float(np.sum(0.5 * np.diff(sp) * np.diff(Gi)))       # leading-order error model (5.5)
                best = root_int ** 2 / (2 * (k - 1))                           # its minimum over k-layer schedules
                res[f"{kind}|{k}"] = dict(metrics(z0, ref[reg], Y, d_nn), scales=s[1:].tolist(), model=model,
                                          efficiency=best / model)
        out["results"][reg] = res
        if inst == 0 and D == 2:
            out["curvature"] = dict(s=sg.tolist(), g=g.tolist())
    if inst == 0:                                                    # convergence of the reference with half the step
        global H
        H0 = H; H = H0 / 2
        Zc2, _ = rk4_flow(Z, Y, lw, v0, vc); Zf2, _ = rk4_flow(Zc2, Y, lw, vc, vf); H = H0
        r2c = reads(Zc2, Y, lw, regimes["coarse"])[0]; r2f = reads(Zf2, Y, lw, regimes["fine"])[0]
        out["reference_check"] = dict(coarse=float(np.abs(r2c - ref["coarse"]).max() / d_nn),
                                      fine=float(np.abs(r2f - ref["fine"]).max() / d_nn),
                                      fine_changed=float(np.mean(np.linalg.norm(r2f - ref["fine"], axis=1) > 1e-3 * d_nn)))
    return out


def bootstrap(a, b, kind, rng, B=10000):
    """Paired bootstrap over instances: ratio of means minus one (loss), or difference of means in points (novelty)."""
    a, b = np.asarray(a), np.asarray(b); n = len(a); idx = rng.integers(0, n, (B, n))
    if kind == "ratio":
        est = a.mean() / b.mean() - 1; bs = a[idx].mean(1) / b[idx].mean(1) - 1
    else:
        est = 100 * (a.mean() - b.mean()); bs = 100 * (a[idx].mean(1) - b[idx].mean(1))
    lo, hi = np.quantile(bs, [0.025, 0.975])
    return dict(est=float(est), lo=float(lo), hi=float(hi))


def verdict(loss, nov):
    if loss["lo"] > 0.02 or nov["lo"] > 2 or nov["hi"] < -2:
        return "refuted"
    if loss["hi"] <= 0.02 and -2 <= nov["lo"] and nov["hi"] <= 2:
        return "supported"
    return "inconclusive"


if __name__ == "__main__":
    t0 = time.time(); runs = []
    for D in DIMS:
        for inst in range(INSTANCES):
            runs.append(run_instance(D, inst)); print("D", D, "instance", inst, round(time.time() - t0, 1), flush=True)
    brng = np.random.default_rng(SEED + 1)
    summary = {}; c3 = []
    for reg in ["fine", "coarse"]:
        summary[reg] = {}
        for D in DIMS:
            rs = [r for r in runs if r["D"] == D]
            tab = {}
            for kind in SCHEDULES:
                for k in KS:
                    vals = {m: [r["results"][reg][f"{kind}|{k}"][m] for r in rs]
                            for m in ["loss", "novel", "branch", "tv", "model", "efficiency"]}
                    tab[f"{kind}|{k}"] = {m: float(np.mean(v)) for m, v in vals.items()}
                    tab[f"{kind}|{k}"]["efficiency_median"] = float(np.median(vals["efficiency"]))
            tab["novel_ref"] = float(np.mean([r["results"][reg]["cosine|4"]["novel_ref"] for r in rs]))
            summary[reg][str(D)] = tab
            for cand in BARCODES + ["curvature"]:
                for k in [4, 8, 16, 32]:
                    get = lambda kind, kk, m: [r["results"][reg][f"{kind}|{kk}"][m] for r in rs]
                    lc = bootstrap(get(cand, k, "loss"), get("cosine", 2 * k, "loss"), "ratio", brng)
                    nc = bootstrap(get(cand, k, "novel"), get("cosine", 2 * k, "novel"), "diff", brng)
                    lg = bootstrap(get(cand, k, "loss"), get("geometric", k, "loss"), "ratio", brng)
                    ng = bootstrap(get(cand, k, "novel"), get("geometric", k, "novel"), "diff", brng)
                    c3.append(dict(regime=reg, D=D, k=k, schedule=cand, loss_vs_cosine_2k=lc, novel_vs_cosine_2k=nc,
                                   verdict=verdict(lc, nc), loss_vs_geometric_k=lg, novel_vs_geometric_k=ng))
    out = dict(status="exploratory pilot of C3 in the transport setting; not the confirmatory test", seed=SEED,
               dims=DIMS, instances=INSTANCES, tokens=TOKENS, curvature_draws=300, curvature_grid=GRID, layer_counts=KS, rk4_step=H,
               schedules=SCHEDULES, summary=summary, c3=c3,
               reference_check={str(r["D"]): r["reference_check"] for r in runs if "reference_check" in r},
               example=dict(radii=runs[0]["radii"], s_min=runs[0]["s_min"], s_max=runs[0]["s_max"], d_nn=runs[0]["d_nn"],
                            curvature=runs[0]["curvature"],
                            scales={reg: {kind: runs[0]["results"][reg][f"{kind}|8"]["scales"] for kind in SCHEDULES}
                                    for reg in ["fine", "coarse"]}),
               per_instance=[{"D": r["D"], "instance": r["instance"],
                              "novel_ref": {reg: r["results"][reg]["cosine|4"]["novel_ref"] for reg in r["results"]},
                              "results": {reg: {key: {m: v[m] for m in ["loss", "novel", "branch", "tv", "model", "efficiency"]}
                                                for key, v in r["results"][reg].items()} for reg in r["results"]}}
                             for r in runs],
               seconds=round(time.time() - t0, 1))
    json.dump(out, open(os.path.join(here, "p3_explore.json"), "w"), indent=1)
    for row in c3:
        print(row["regime"], row["D"], row["k"], row["schedule"], row["verdict"], {k: round(v, 4) for k, v in row["loss_vs_cosine_2k"].items()},
              {k: round(v, 2) for k, v in row["novel_vs_cosine_2k"].items()}, {k: round(v, 4) for k, v in row["loss_vs_geometric_k"].items()})
