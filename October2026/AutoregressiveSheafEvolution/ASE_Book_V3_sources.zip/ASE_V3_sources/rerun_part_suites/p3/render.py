# Assemble the Part III source and fill every {{...}} placeholder from the machine-readable results.
import json, math, os, re, subprocess

here = os.path.dirname(os.path.abspath(__file__))
parts = ["a_front.md", "b_recurrence.md", "c_tangent.md", "d_persistence.md", "e_pilot.md", "f_end.md"]
src = "\n".join(open(os.path.join(here, "src", p), encoding="utf-8").read() for p in parts)

c = json.load(open(os.path.join(here, "p3_checks.json")))
x = json.load(open(os.path.join(here, "p3_extras.json")))
e = json.load(open(os.path.join(here, "p3_explore.json")))
v = json.load(open(os.path.join(here, "cs_validate.json")))
rows = c["continuum"]["rows"]
ks = {(r["layers"], r["eta"]): r["ks"] for r in rows}
import pilot_summary as PS                                    # derived pilot quantities, computed from p3_explore.json
d = dict(
    n_main=len(c), n_extra=len(x), n_checks=len(c) + len(x),
    ks4=ks[(4, 0.0)], ks16=ks[(16, 0.0)], ks64=ks[(64, 0.0)], ks256=ks[(256, 0.0)],
    ks4n=ks[(4, 1.0)], ks16n=ks[(16, 1.0)], ks64n=ks[(64, 1.0)], ks256n=ks[(256, 1.0)],
    clean_share=c["clean_top"]["share_on_records"], clean_cases=c["composite"]["cases"] // 2,
    neg_1e2=x["part_one"]["negative_multiplicity_tokens"]["0.01"], neg_1e3=x["part_one"]["negative_multiplicity_tokens"]["0.001"],
    neg_share=x["part_one"]["negative_multiplicity_tokens"]["0.01"] / x["part_one"]["tokens"],
    expand_min=min(v for v in x["part_one"]["expanding_share"] if v > 0), expand_max=max(x["part_one"]["expanding_share"]),
)
d.update(PS.derive(e))
import numpy, matplotlib, platform, scipy
dotnet = subprocess.run(["dotnet", "--version"], capture_output=True, text=True).stdout.strip()
env = dict(python=platform.python_version(), numpy=numpy.__version__, scipy=scipy.__version__,
           matplotlib=matplotlib.__version__, dotnet=dotnet)
data = dict(c=c, x=x, e=e, v=v, d=d, env=env)

SUP = str.maketrans("-0123456789", "⁻⁰¹²³⁴⁵⁶⁷⁸⁹")


def lookup(path):
    head, *rest = path.split(".")
    val = data[head]
    for key in rest:
        if isinstance(val, list):
            val = val[int(key)]
        elif key in val:
            val = val[key]
        else:
            raise KeyError(f"missing key {key!r} in {path}")
    return val


def num(val):
    if isinstance(val, bool):
        return int(val)
    if isinstance(val, str) and re.fullmatch(r"-?\d+(\.\d+)?", val):
        return float(val) if "." in val else int(val)
    return val


def fmt(val, f):
    val = num(val)
    if f in ("", None):
        if isinstance(val, float) and val.is_integer():
            val = int(val)
        s = f"{val:,}" if isinstance(val, int) and abs(val) >= 1000 else str(val)
        return s.replace("-", "−") if isinstance(val, (int, float)) else s
    if f == "d":
        return f"{int(round(float(val))):,}".replace("-", "−")
    if re.fullmatch(r"f\d+", f):
        return f"{float(val):.{int(f[1:])}f}".replace("-", "−")
    if f in ("g2", "g3", "g4", "g6"):
        if float(val) == 0:
            return "0"
        s = f"{float(val):.{f[1]}g}"
        if "e" in s:
            m, ex = s.split("e")
            return f"{m} × 10{str(int(ex)).translate(SUP)}"
        return s.replace("-", "−")
    if f in ("e1", "e2"):
        if float(val) == 0:
            return "0"
        m, ex = f"{float(val):.{f[1]}e}".split("e")
        m = m.replace("-", "−")
        return f"{m} × 10{str(int(ex)).translate(SUP)}"
    if f in ("pct0", "pct1"):
        return f"{100 * float(val):.{f[3]}f}%"
    if f == "pp1":                                              # signed percentage points
        return f"{float(val):+.1f}".replace("-", "−")
    if f == "pc1":                                              # signed per cent
        return f"{100 * float(val):+.1f}%".replace("-", "−")
    if f == "pc0":
        return f"{100 * float(val):+.0f}%".replace("-", "−")
    raise ValueError(f"unknown format {f}")


def same(a, b):
    ga, gb = a.split(), b.split()
    return ga[0] == gb[0] and [float(t) for t in ga[1:]] == [float(t) for t in gb[1:]]


def fill(m):
    body = m.group(1).replace("\\|", "|")
    if body.startswith("file:"):
        return open(os.path.join(here, body[5:]), encoding="utf-8").read().rstrip("\n")
    if body == "cs_rows":
        nb = lambda t: t.replace(" -", " -\u2060").replace("E-", "E-\u2060").replace("e-", "e-\u2060")   # keep signs with numbers
        return "\n".join(f"| `{nb(a)}` | `{nb(b)}` | {'identical' if same(a, b) else fmt(r, 'e1')} |"
                         for a, b, r in zip(v["csharp"], v["python"], v["per_line"]))
    if body.startswith("table:"):
        return PS.table(e, body[6:])
    path, _, f = body.partition("|")
    return fmt(lookup(path.strip()), f.strip())


out = re.sub(r"\{\{(.+?)\}\}", fill, src)
out = re.sub(r"\{\{(.+?)\}\}", fill, out)                    # placeholders produced by derived text
out = out.replace("$\\blacksquare$", "∎")
out = re.sub(r'(::: \{custom-style="Statement Tag"\}\n.*?\n:::\n)', r'\1\n::: {custom-style="Gap"}\n&nbsp;\n:::\n', out, flags=re.S)
left = re.findall(r"\{\{\s*[a-z]", out)
assert not left, "unfilled placeholders remain"
open(os.path.join(here, "paper.md"), "w", encoding="utf-8").write(out)
print("paper.md written;", len(out.split()), "words")
