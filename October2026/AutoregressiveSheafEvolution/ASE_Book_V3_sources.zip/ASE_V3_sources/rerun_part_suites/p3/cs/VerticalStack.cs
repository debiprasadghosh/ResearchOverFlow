// ASE Part III reference kernel: the vertical stack of identity-map layers.
// Immutable values and pure functions; numerical routines use private copies.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AsePartThree;

/// <summary>A dense real matrix stored row-major.</summary>
public sealed record Matrix(int Rows, int Cols, Vec Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Matrix Identity(int n) =>
        new(n, n, Enumerable.Range(0, n * n)
            .Select(k => k / n == k % n ? 1.0 : 0.0).ToImmutableArray());

    public Matrix Transpose() =>
        new(Cols, Rows, Enumerable.Range(0, Rows * Cols)
            .Select(k => this[k % Rows, k / Rows]).ToImmutableArray());

    public Matrix Times(Matrix b) =>
        new(Rows, b.Cols, Enumerable.Range(0, Rows * b.Cols)
            .Select(k => Enumerable.Range(0, Cols)
                .Sum(j => this[k / b.Cols, j] * b[j, k % b.Cols]))
            .ToImmutableArray());

    public Matrix Combine(double a, Matrix b, double c) =>
        this with { Data = Data.Zip(b.Data, (p, q) => a * p + c * q)
                               .ToImmutableArray() };

    /// <summary>Eigenvalues (ascending) of a symmetric matrix, by cyclic
    /// Jacobi rotations on a private copy.</summary>
    public Vec SymmetricEigenvalues()
    {
        int n = Rows;
        var a = Data.ToArray();
        for (int sweep = 0; sweep < 100; sweep++)
        {
            double off = 0.0;
            for (int p = 0; p < n; p++)
                for (int q = p + 1; q < n; q++) off += a[p * n + q] * a[p * n + q];
            if (off < 1e-300) break;
            for (int p = 0; p < n - 1; p++)
                for (int q = p + 1; q < n; q++)
                {
                    double apq = a[p * n + q];
                    if (apq == 0.0) continue;
                    double th = (a[q * n + q] - a[p * n + p]) / (2.0 * apq);
                    double t = th == 0.0 ? 1.0
                        : Math.Sign(th) / (Math.Abs(th) + Math.Sqrt(th * th + 1.0));
                    double c = 1.0 / Math.Sqrt(t * t + 1.0), s = t * c;
                    for (int k = 0; k < n; k++)
                        (a[k * n + p], a[k * n + q]) =
                            (c * a[k * n + p] - s * a[k * n + q],
                             s * a[k * n + p] + c * a[k * n + q]);
                    for (int k = 0; k < n; k++)
                        (a[p * n + k], a[q * n + k]) =
                            (c * a[p * n + k] - s * a[q * n + k],
                             s * a[p * n + k] + c * a[q * n + k]);
                }
        }
        return Enumerable.Range(0, n).Select(i => a[i * n + i]).OrderBy(v => v)
                         .ToImmutableArray();
    }
}

/// <summary>Scales s_0 (top, possibly 0) &lt; s_1 &lt; ... &lt; s_T and the
/// noise parameter eta in [0, 1]. Index t of the derived arrays is layer t;
/// entry 0 is unused.</summary>
public sealed record Schedule(Vec Scales, double Eta)
{
    public int Layers => Scales.Length - 1;

    /// <summary>Signal levels a_0 &gt;= ... &gt;= a_T to s_t = sqrt((1-a_t)/a_t).
    /// </summary>
    public static Schedule FromLevels(Vec levels, double eta) =>
        new(levels.Select(a => Math.Sqrt((1 - a) / a)).ToImmutableArray(), eta);

    double Gamma2(int t)
    {
        double lo = Scales[t - 1], hi = Scales[t];
        return Eta * Eta * lo * lo * (hi * hi - lo * lo) / (hi * hi);
    }

    public Vec NoiseStd => Enumerable.Range(0, Layers + 1)
        .Select(t => t == 0 ? 0.0 : Math.Sqrt(Gamma2(t))).ToImmutableArray();

    public Vec Lambda => Enumerable.Range(0, Layers + 1)
        .Select(t => t == 0 ? 0.0
            : 1 - Math.Sqrt(Math.Max(Scales[t - 1] * Scales[t - 1] - Gamma2(t), 0))
                  / Scales[t])
        .ToImmutableArray();

    /// <summary>pi_t, omega_t = lambda_t pi_t and omega_* (V2 Theorem 7.1).
    /// </summary>
    public (Vec Pi, Vec Omega, double OmegaStar) Separation()
    {
        var lam = Lambda;
        var pi = Enumerable.Range(0, Layers + 1)
            .Select(t => t == 0 ? 0.0
                : Enumerable.Range(1, t - 1)
                    .Aggregate(1.0, (p, u) => p * (1 - lam[u])))
            .ToImmutableArray();
        var omega = pi.Select((p, t) => lam[t] * p).ToImmutableArray();
        double star = Enumerable.Range(1, Layers)
            .Aggregate(1.0, (p, u) => p * (1 - lam[u]));
        return (pi, omega, star);
    }

    /// <summary>The explicit noise variance sum_t pi_t^2 gamma_t^2 and its
    /// closed form s_0^2 - omega_*^2 s_T^2 (Theorem 3.2).</summary>
    public (double Sum, double ClosedForm) NoiseBudget()
    {
        var (pi, _, star) = Separation();
        var sig = NoiseStd;
        double sum = Enumerable.Range(1, Layers)
            .Sum(t => pi[t] * pi[t] * sig[t] * sig[t]);
        double sT = Scales[Layers];
        return (sum, Scales[0] * Scales[0] - star * star * sT * sT);
    }
}

/// <summary>Records y_i with log prior weights; identity edge maps.</summary>
public sealed record Archive(ImmutableArray<Vec> Records, Vec LogWeights);

/// <summary>Posterior weights, read m = sum alpha_i y_i and covariance C.</summary>
public sealed record Read(Vec Weights, Vec Mean, Matrix Covariance);

/// <summary>One layer of a realised path: the state it received, its read and
/// its Jacobian (1 - lambda) I + lambda C / s^2.</summary>
public sealed record LayerStep(int Layer, Vec State, Read Read, Matrix Jacobian);

public sealed record StackRun(Vec Output, ImmutableArray<LayerStep> Steps,
                              Matrix Composite);

public static class Reads
{
    public static Read At(Vec z, Archive a, double s)
    {
        var l = a.Records.Select((y, i) => a.LogWeights[i]
            - y.Zip(z, (p, q) => (p - q) * (p - q)).Sum() / (2 * s * s)).ToArray();
        double peak = l.Max();
        var w = l.Select(v => Math.Exp(v - peak)).ToArray();
        var alpha = w.Select(v => v / w.Sum()).ToImmutableArray();
        int d = z.Length;
        var m = Enumerable.Range(0, d)
            .Select(j => a.Records.Select((y, i) => alpha[i] * y[j]).Sum())
            .ToImmutableArray();
        var cov = Enumerable.Range(0, d * d)
            .Select(k => a.Records.Select((y, i) =>
                alpha[i] * (y[k / d] - m[k / d]) * (y[k % d] - m[k % d])).Sum())
            .ToImmutableArray();
        return new Read(alpha, m, new Matrix(d, d, cov));
    }
}

public static class Stack
{
    /// <summary>Runs z_{t-1} = (1 - lambda_t) z_t + lambda_t m_t + gamma_t xi_t
    /// from t = T to 1, with noise[t - 1] for layer t, and multiplies the layer
    /// Jacobians along the realised path.</summary>
    public static StackRun Run(Vec zT, Archive a, Schedule sch,
                               ImmutableArray<Vec> noise)
    {
        var lam = sch.Lambda;
        var sig = sch.NoiseStd;
        int d = zT.Length;
        var init = (z: zT, steps: ImmutableArray<LayerStep>.Empty,
                    k: Matrix.Identity(d));
        var final = Enumerable.Range(1, sch.Layers).Reverse().Aggregate(init,
            (acc, t) =>
            {
                double s = sch.Scales[t];
                var read = Reads.At(acc.z, a, s);
                var jac = Matrix.Identity(d).Combine(1 - lam[t], read.Covariance,
                                                     lam[t] / (s * s));
                var next = Enumerable.Range(0, d)
                    .Select(j => (1 - lam[t]) * acc.z[j] + lam[t] * read.Mean[j]
                                 + (sig[t] > 0 ? sig[t] * noise[t - 1][j] : 0.0))
                    .ToImmutableArray();
                return (next, acc.steps.Add(new LayerStep(t, acc.z, read, jac)),
                        jac.Times(acc.k));
            });
        return new StackRun(final.z, final.steps, final.k);
    }

    /// <summary>The right side of the separation identity, recomputed from the
    /// recorded reads: omega_* z_T + sum omega_t m_t + sum pi_t gamma_t xi_t.
    /// </summary>
    public static Vec Separate(Vec zT, StackRun run, Schedule sch,
                               ImmutableArray<Vec> noise)
    {
        var (pi, omega, star) = sch.Separation();
        var sig = sch.NoiseStd;
        return Enumerable.Range(0, zT.Length)
            .Select(j => star * zT[j]
                + run.Steps.Sum(st => omega[st.Layer] * st.Read.Mean[j]
                    + (sig[st.Layer] > 0
                        ? pi[st.Layer] * sig[st.Layer] * noise[st.Layer - 1][j]
                        : 0.0)))
            .ToImmutableArray();
    }
}

public static class Tangent
{
    /// <summary>Singular values, descending, from the eigenvalues of K^T K.
    /// </summary>
    public static Vec SingularValues(Matrix k) =>
        k.Transpose().Times(k).SymmetricEigenvalues()
         .Select(v => Math.Sqrt(Math.Max(v, 0))).Reverse().ToImmutableArray();

    /// <summary>Products of the smallest and largest layer eigenvalues, which
    /// bracket every singular value of the composite (Theorem 4.2).</summary>
    public static (double Floor, double Ceiling) ProductBounds(StackRun run) =>
        run.Steps.Aggregate((f: 1.0, c: 1.0), (acc, st) =>
        {
            var ev = st.Jacobian.SymmetricEigenvalues();
            return (acc.f * ev[0], acc.c * ev[ev.Length - 1]);
        });

    /// <summary>log |det K| as a sum over layers and eigenvalues (4.2).</summary>
    public static double LogVolume(StackRun run) =>
        run.Steps.Sum(st => st.Jacobian.SymmetricEigenvalues()
                                .Sum(v => Math.Log(Math.Abs(v))));

    /// <summary>Directions a layer expands: eigenvalues of C / s^2 above one.
    /// At a stationary point this is the Morse index of E_s (Proposition 4.4).
    /// </summary>
    public static int ExpandingDirections(Matrix covariance, double s,
                                          double tol = 1e-9) =>
        covariance.SymmetricEigenvalues().Count(v => v / (s * s) > 1 + tol);

    /// <summary>Path curvature z'' = (C (z - m) - M_3) / s^4 along the
    /// probability-flow ODE (5.2).</summary>
    public static Vec PathCurvature(Vec z, Archive a, double s)
    {
        var r = Reads.At(z, a, s);
        int d = z.Length;
        var dz = z.Zip(r.Mean, (p, q) => p - q).ToImmutableArray();
        return Enumerable.Range(0, d).Select(j =>
        {
            double cz = Enumerable.Range(0, d)
                .Sum(k => r.Covariance[j, k] * dz[k]);
            double m3 = a.Records.Select((y, i) => r.Weights[i]
                * y.Zip(r.Mean, (p, q) => (p - q) * (p - q)).Sum()
                * (y[j] - r.Mean[j])).Sum();
            return (cz - m3) / Math.Pow(s, 4);
        }).ToImmutableArray();
    }
}
