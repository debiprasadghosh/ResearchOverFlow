// Validation run of the Part III kernel; cs_validate.py recomputes every
// printed number with NumPy.
using System;
using System.Collections.Immutable;
using System.Globalization;
using System.Linq;
using AsePartThree;

static ImmutableArray<double> V(params double[] x) => ImmutableArray.Create(x);
static string F(double x) => x.ToString("G15", CultureInfo.InvariantCulture);
static void Print(string name, params double[] xs) =>
    Console.WriteLine(name + " " + string.Join(" ", xs.Select(F)));

// a five-layer schedule with eta = 0.5: coefficients, weights, noise budget
var scales = V(0.2, 0.35, 0.6, 1.0, 1.7, 3.0);
var noisy = new Schedule(scales, 0.5);
Print("lambda", noisy.Lambda.Skip(1).ToArray());
Print("noise_std", noisy.NoiseStd.Skip(1).ToArray());
var (_, omega, star) = noisy.Separation();
Print("omega", omega.Skip(1).ToArray());
Print("omega_star", star);
var (sum, closed) = noisy.NoiseBudget();
Print("noise_budget", sum, closed);

// the limiting sixteen-layer cosine schedule a_t = cos^2(pi t / 32): weights of
// the reads at layers 2 to 5, and of layers 6 to 16 together, in the query z_1
var sub = Schedule.FromLevels(Enumerable.Range(1, 15)
    .Select(t => Math.Pow(Math.Cos(Math.PI * t / 32), 2)).ToImmutableArray(), 0.0);
var (_, cw, cstar) = sub.Separation();
Print("cosine_weights_in_z1", cw[1], cw[2], cw[3], cw[4],
      cw.Skip(5).Sum() + cstar);

// eight cosine levels a_t = cos^2(pi t / 16), t = 0..7, with a clean top
var cosine = Schedule.FromLevels(Enumerable.Range(0, 8)
    .Select(t => Math.Pow(Math.Cos(Math.PI * t / 16), 2)).ToImmutableArray(), 0.0);

// a realised noisy path and the separation identity along it
var archive = new Archive(
    ImmutableArray.Create(V(0.0, 0.0), V(1.0, 0.2), V(0.4, 1.1), V(2.2, 1.5),
                          V(-0.8, 0.9)),
    V(0.0, 0.3, -0.2, 0.1, -0.4));
var noise = Enumerable.Range(1, 5)
    .Select(t => V(Math.Sin(1.7 * t + 0.3), Math.Sin(1.7 * t + 1.2)))
    .ToImmutableArray();
var zT = V(2.5, -1.2);
var run = Stack.Run(zT, archive, noisy, noise);
var sep = Stack.Separate(zT, run, noisy, noise);
Print("noisy_output", run.Output.ToArray());
Print("separation_residual",
      run.Output.Zip(sep, (p, q) => Math.Abs(p - q)).Max());

// the deterministic path: composite tangent, its bounds and its volume
var det = new Schedule(scales, 0.0);
var none = ImmutableArray<ImmutableArray<double>>.Empty;
var drun = Stack.Run(zT, archive, det, none);
var sv = Tangent.SingularValues(drun.Composite);
var (floor, ceiling) = Tangent.ProductBounds(drun);
Print("det_output", drun.Output.ToArray());
Print("singular_values", sv.ToArray());
Print("product_bounds", floor, ceiling);
Print("schedule_floor", scales[0] / scales[5]);
Print("log_volume", Tangent.LogVolume(drun), sv.Sum(Math.Log));

// a clean top: the composite is pinned by the top posterior covariance
var crun = Stack.Run(zT, archive, cosine, none);
var csv = Tangent.SingularValues(crun.Composite);
var top = crun.Steps.Last();
var c1 = top.Read.Covariance.SymmetricEigenvalues().Reverse().ToArray();
double s1 = cosine.Scales[1], sT = cosine.Scales[7];
Print("clean_output", crun.Output.ToArray());
Print("clean_singular_values", csv.ToArray());
Print("clean_lower", c1.Select(c => c / (s1 * sT)).ToArray());

// expanding directions at the midpoint of two equal records, below and above
// the pitchfork scale d / 2 = 1
var pair = new Archive(ImmutableArray.Create(V(-1.0, 0.0), V(1.0, 0.0)),
                       V(0.0, 0.0));
static int Expanding(Archive a, double s) =>
    Tangent.ExpandingDirections(Reads.At(V(0.0, 0.0), a, s).Covariance, s);
Print("expanding", Expanding(pair, 0.8), Expanding(pair, 1.2));

// curvature of a token path
Print("curvature", Tangent.PathCurvature(V(0.7, 0.4), archive, 0.6).ToArray());
