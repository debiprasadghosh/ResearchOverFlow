# Numerical checks for ASE Part III, "The Vertical Stack". Every number quoted in the paper is read from p3_checks.json.
import json, math, os, sys
import numpy as np
from scipy.optimize import linprog
from p3_core import (scales_from_levels, coefficients, separation_weights, reads, covariance, run_stack, layer_jacobian,
                     kde_sample, mixture_cdf_1d, modes, barcode_from_ranks)

here = os.path.dirname(os.path.abspath(__file__))
rng = np.random.default_rng(20261022)
R = {}


def random_scales(T, clean_top=False):
    s = np.sort(np.exp(rng.uniform(math.log(0.02), math.log(30.0), T + 1)))
    if clean_top:
        s[0] = 0.0
    return s


def random_archive(D, n, spread=2.0):
    return spread * rng.standard_normal((n, D)), rng.normal(0, 0.5, n)


# ---------------------------------------------------------------- 1. variance bookkeeping and the Mathematics book coefficients
def check_variance_bookkeeping():
    err = coef_err = 0.0; lam_ok = True; cases = 500
    for k in range(cases):
        T = int(rng.integers(2, 21)); s = random_scales(T, clean_top=(k % 4 == 0)); eta = float(rng.uniform(0, 1))
        lam, sig = coefficients(s, eta)
        a = 1 / (1 + s ** 2)
        for t in range(1, T + 1):
            err = max(err, abs((1 - lam[t]) ** 2 * s[t] ** 2 + sig[t] ** 2 - s[t - 1] ** 2) / (1 + s[t - 1] ** 2))
            lam_ok &= -1e-12 <= lam[t] <= 1 + 1e-12
            sig2 = eta ** 2 * (1 - a[t - 1]) * (1 - a[t] / a[t - 1]) / (1 - a[t])        # Mathematics book (19.2)
            A = math.sqrt(max(1 - a[t - 1] - sig2, 0) / (1 - a[t]))
            coef_err = max(coef_err, abs(math.sqrt(sig2 / a[t - 1]) - sig[t]), abs(1 - A * math.sqrt(a[t] / a[t - 1]) - lam[t]))
    R["variance_bookkeeping"] = dict(schedules=cases, max_rel_err=err, coefficient_err=coef_err, lambda_in_unit_interval=bool(lam_ok))


# ---------------------------------------------------------------- 2. separation identity along realised paths
def check_separation():
    err = sum_err = 0.0; cases = 300
    for _ in range(cases):
        D, n, T = int(rng.integers(1, 5)), int(rng.integers(2, 10)), int(rng.integers(2, 17))
        Y, lw = random_archive(D, n); s = random_scales(T, clean_top=bool(rng.random() < 0.3)); eta = float(rng.uniform(0, 1))
        Z = s[-1] * rng.standard_normal((5, D)); noise = {t: rng.standard_normal((5, D)) for t in range(1, T + 1)}
        z0, traj, rd = run_stack(Z, Y, lw, s, eta, noise, keep=True)
        lam, sig = coefficients(s, eta); pi, om, ws = separation_weights(lam)
        rec = ws * Z + sum(om[t] * rd[t] for t in range(1, T + 1)) + sum(pi[t] * sig[t] * noise[t] for t in range(1, T + 1))
        err = max(err, float(np.abs(rec - z0).max() / (1 + np.abs(z0).max())))
        sum_err = max(sum_err, abs(ws + om[1:].sum() - 1))
    R["separation"] = dict(cases=cases, max_rel_err=err, weight_sum_err=sum_err)


# ---------------------------------------------------------------- 3. the noise budget of a stack
def check_noise_budget():
    err = 0.0; cases = 500
    for k in range(cases):
        T = int(rng.integers(2, 25)); s = random_scales(T, clean_top=(k % 5 == 0)); eta = float(rng.uniform(0, 1))
        lam, sig = coefficients(s, eta); pi, om, ws = separation_weights(lam)
        lhs = float(np.sum(pi[1:] ** 2 * sig[1:] ** 2)); rhs = s[0] ** 2 - ws ** 2 * s[-1] ** 2
        err = max(err, abs(lhs - rhs) / (1 + s[0] ** 2))
    # oracle reads: a stack that always reads the true record maps y + s_T noise to y + s_0 noise for every eta
    mc = []
    for eta in [0.0, 0.5, 1.0]:
        s = np.exp(np.linspace(math.log(0.3), math.log(10.0), 13)); lam, sig = coefficients(s, eta)
        N = 200000; z = 1.5 + s[-1] * rng.standard_normal(N)
        for t in range(len(s) - 1, 0, -1):
            z = (1 - lam[t]) * z + lam[t] * 1.5 + sig[t] * rng.standard_normal(N)
        mc.append(dict(eta=eta, target_sd=float(s[0]), output_sd=float(z.std()), output_mean=float(z.mean())))
    R["noise_budget"] = dict(schedules=cases, max_rel_err=err, oracle=mc)


# ---------------------------------------------------------------- 4. deterministic coefficients and the cosine table of V2
def check_deterministic_weights():
    e1 = e2 = 0.0
    for _ in range(300):
        T = int(rng.integers(2, 21)); s = random_scales(T)
        lam, sig = coefficients(s, 0.0); pi, om, ws = separation_weights(lam)
        e1 = max(e1, abs(ws - s[0] / s[-1]))
        e2 = max(e2, float(np.abs(om[1:] - np.array([s[0] * (1 / s[t - 1] - 1 / s[t]) for t in range(1, T + 1)])).max()))
    T = 16; st = np.tan(np.pi * np.arange(T + 1) / (2 * T))          # limiting cosine schedule, scales tan(pi t / 2T)
    w = [st[1] * (1 / st[t - 1] - 1 / st[t]) for t in range(2, T)]  # weights of reads 2..15 in the top query z_1
    R["deterministic_weights"] = dict(cases=300, omega_star_err=e1, omega_err=e2,
                                      cosine_top_query=dict(t2=w[0], t3=w[1], t4=w[2], t5=w[3], t6_to_16=float(sum(w[4:]) + st[1] / st[T - 1]),
                                                            total=float(sum(w) + st[1] / st[T - 1]), s1=float(st[1])))


# ---------------------------------------------------------------- 5. exact ADE recovery along whole stacks
def check_ade_stack():
    err = 0.0; cases = 200
    for _ in range(cases):
        D, n, T = int(rng.integers(1, 5)), int(rng.integers(2, 10)), int(rng.integers(2, 17))
        Y, lw = random_archive(D, n); eta = float(rng.uniform(0, 1))
        a = np.sort(rng.uniform(0.02, 0.98, T + 1))[::-1]; a[0] = float(rng.choice([1.0, a[0]]))
        s = scales_from_levels(a); lam, sig = coefficients(s, eta)
        qT = rng.standard_normal((4, D)); noise = {t: rng.standard_normal((4, D)) for t in range(1, T + 1)}
        q = qT.copy()
        for t in range(T, 0, -1):
            L = lw[None] - ((q[:, None, :] - math.sqrt(a[t]) * Y[None]) ** 2).sum(-1) / (2 * (1 - a[t]))
            L -= L.max(1, keepdims=True); A = np.exp(L); A /= A.sum(1, keepdims=True); m = A @ Y
            sg2 = eta ** 2 * (1 - a[t - 1]) * (1 - a[t] / a[t - 1]) / (1 - a[t]); At = math.sqrt(max(1 - a[t - 1] - sg2, 0) / (1 - a[t]))
            q = At * q + (math.sqrt(a[t - 1]) - At * math.sqrt(a[t])) * m + math.sqrt(sg2) * noise[t]
        z = run_stack(qT / math.sqrt(a[-1]), Y, lw, s, eta, {t: noise[t] for t in noise})
        err = max(err, float(np.abs(z - q / math.sqrt(a[0])).max() / (1 + np.abs(z).max())))
    R["ade_stack"] = dict(cases=cases, max_rel_err=err)


# ---------------------------------------------------------------- 6. a deterministic layer is an Euler step of the probability-flow ODE
def check_euler_identity():
    err = 0.0
    for _ in range(300):
        D, n = int(rng.integers(1, 5)), int(rng.integers(2, 10)); Y, lw = random_archive(D, n)
        s_hi = float(rng.uniform(0.1, 10)); s_lo = float(rng.uniform(0.01, s_hi)); z = s_hi * rng.standard_normal((3, D))
        lam, _ = coefficients(np.array([s_lo, s_hi]), 0.0)
        m, _ = reads(z, Y, lw, s_hi)
        layer = (1 - lam[1]) * z + lam[1] * m
        euler = z + (s_lo - s_hi) * (z - m) / s_hi
        score = z + (1 - s_lo / s_hi) * (m - z)                    # Mathematics book (19.5) with s^2 grad log p = m - z
        err = max(err, float(np.abs(layer - euler).max()), float(np.abs(layer - score).max()))
    R["euler_identity"] = dict(cases=300, max_err=err)


# ---------------------------------------------------------------- 7. the continuum limit transports p_{s_T} to p_{s_0}
def ks_to_mixture(x, Y, lw, s0):
    x = np.sort(x); F = mixture_cdf_1d(x, Y, lw, s0); n = len(x)
    return float(max(np.max(np.arange(1, n + 1) / n - F), np.max(F - np.arange(n) / n)))


def check_continuum():
    Y = np.array([[-4.0], [-1.5], [0.0], [0.7], [3.0], [5.5]]); lw = np.log(np.array([1.0, 2.0, 0.5, 1.5, 1.0, 0.8]))
    sT, s0, N = 20.0, 0.3, 40000
    zT, _ = kde_sample(Y, lw, sT, N, rng)
    rows = []
    for T in [4, 16, 64, 256]:
        s = np.exp(np.linspace(math.log(s0), math.log(sT), T + 1))
        for eta in [0.0, 1.0]:
            noise = {t: rng.standard_normal((N, 1)) for t in range(1, T + 1)} if eta > 0 else None
            z0 = run_stack(zT.copy(), Y, lw, s, eta, noise)
            rows.append(dict(layers=T, eta=eta, ks=ks_to_mixture(z0[:, 0], Y, lw, s0)))
    ref = ks_to_mixture(kde_sample(Y, lw, s0, N, rng)[0][:, 0], Y, lw, s0)       # sampling noise floor
    # the ADE start q_T ~ N(0, I) is not exactly p_{s_T}: the bottom mismatch
    s = np.exp(np.linspace(math.log(s0), math.log(sT), 257)); zg = math.sqrt(1 + sT ** 2) * rng.standard_normal((N, 1))
    mis = ks_to_mixture(run_stack(zg, Y, lw, s, 0.0)[:, 0], Y, lw, s0)
    R["continuum"] = dict(records=len(Y), tokens=N, s_bottom=sT, s_top=s0, rows=rows, sampling_floor=ref, gaussian_start_ks=mis)


# ---------------------------------------------------------------- 8. a clean top re-selects archived records in proportion to weight
def check_clean_top():
    Y = np.array([[-4.0], [-1.5], [0.0], [0.7], [3.0], [5.5]]); w = np.array([1.0, 2.0, 0.5, 1.5, 1.0, 0.8]); lw = np.log(w)
    N = 40000; zT, _ = kde_sample(Y, lw, 20.0, N, rng)
    s = np.concatenate([[0.0], np.exp(np.linspace(math.log(0.01), math.log(20.0), 256))])
    z0 = run_stack(zT, Y, lw, s, 0.0)[:, 0]
    d = np.abs(z0[:, None] - Y[None, :, 0]); near = d.min(1) < 1e-6
    freq = np.bincount(d.argmin(1), minlength=len(Y)) / N
    R["clean_top"] = dict(tokens=N, share_on_records=float(near.mean()), max_frequency_error=float(np.abs(freq - w / w.sum()).max()),
                          frequencies=freq.tolist(), weights=(w / w.sum()).tolist())


# ---------------------------------------------------------------- 9. hulls: identity reads stay in the hull, masked reads leave it
def in_hull(P, x):
    n = len(P)
    res = linprog(np.zeros(n), A_eq=np.vstack([np.array(P).T, np.ones(n)]), b_eq=np.append(x, 1.0), bounds=[(0, None)] * n, method="highs")
    return res.status == 0


def masked_read(z, Y, masks, lw, s):
    e = np.array([0.5 * np.sum((z[mk] - y[mk]) ** 2) for mk, y in zip(masks, Y)])
    a = np.exp(lw - e / s ** 2 - np.max(lw - e / s ** 2)); a /= a.sum()
    out = z.copy()
    for j in range(len(z)):
        idx = [i for i, mk in enumerate(masks) if j in mk]
        k = sum(a[i] for i in idx)
        if k > 1e-12:
            out[j] = sum(a[i] * Y[i][j] for i in idx) / k
    return out


def check_hulls():
    viol = 0; cases = 200; outside = 0; mcases = 200
    for _ in range(cases):
        D, n, T = int(rng.integers(2, 4)), int(rng.integers(3, 7)), int(rng.integers(3, 10))
        Y, lw = random_archive(D, n); s = random_scales(T); z = s[-1] * rng.standard_normal((1, D))
        z0 = run_stack(z.copy(), Y, lw, s, 0.0)
        viol += not in_hull(list(Y) + [z[0]], z0[0])
    for _ in range(mcases):
        D, n, T = 3, 5, 8
        Y = rng.standard_normal((n, D)); lw = np.zeros(n)
        masks = [np.sort(rng.choice(D, int(rng.integers(1, D)), replace=False)) for _ in range(n)]
        s = np.exp(np.linspace(math.log(0.05), math.log(5), T + 1)); lam, _ = coefficients(s, 0.0)
        z = 0.3 * rng.standard_normal(D); z0 = z.copy()
        for t in range(T, 0, -1):
            z = (1 - lam[t]) * z + lam[t] * masked_read(z, Y, masks, lw, s[t])
        outside += not in_hull(list(Y) + [z0], z)
    R["hulls"] = dict(identity_cases=cases, identity_violations=viol, masked_cases=mcases, masked_outside=outside)


# ---------------------------------------------------------------- 10. the layer Jacobian
def check_layer_jacobian():
    err = 0.0; bound_viol = 0; cases = 300
    for _ in range(cases):
        D, n = int(rng.integers(1, 5)), int(rng.integers(2, 10)); Y, lw = random_archive(D, n)
        s = float(rng.uniform(0.3, 5)); lam = float(rng.uniform(0, 1)); z = Y.mean(0) + s * rng.standard_normal(D)
        J, C = layer_jacobian(z, Y, lw, s, lam)
        h = 1e-6
        f = lambda x: (1 - lam) * x + lam * reads(x[None], Y, lw, s)[0][0]
        Jfd = np.column_stack([(f(z + h * e) - f(z - h * e)) / (2 * h) for e in np.eye(D)])
        err = max(err, float(np.abs(J - Jfd).max() / (1 + np.abs(J).max())))
        Rd = max(np.linalg.norm(p - q) for p in Y for q in Y); ev = np.linalg.eigvalsh(J)
        bound_viol += ev.min() < 1 - lam - 1e-12 or ev.max() > 1 - lam + lam * Rd ** 2 / (4 * s * s) + 1e-12
    R["layer_jacobian"] = dict(cases=cases, fd_rel_err=err, bound_violations=int(bound_viol))


# ---------------------------------------------------------------- 11. composite tangents: floor, ceiling and volume
def composite(z, Y, lw, s, eta=0.0, noise=None):
    lam, sig = coefficients(s, eta); T = len(s) - 1; D = len(z); K = np.eye(D); Js = {}
    for t in range(T, 0, -1):
        if s[t - 1] == 0 and t == 1:
            m, A = reads(z[None], Y, lw, s[t]); C = covariance(A[0], Y, m[0]); J = C / s[t] ** 2
        else:
            J, C = layer_jacobian(z, Y, lw, s[t], lam[t])
        Js[t] = (J, C)
        m, _ = reads(z[None], Y, lw, s[t])
        z = (1 - lam[t]) * z + lam[t] * m[0] + (sig[t] * noise[t] if noise is not None else 0.0)
        K = J @ K
    return K, Js, z


def check_composite():
    """Theorem 4.2 and Corollary 4.3. Singular values are compared with a tolerance of 1e-12 times the largest one,
    because the singular values of a numerically singular composite are only known to that absolute accuracy."""
    rows = dict(floor_violations=0, ceiling_violations=0, det_floor_violations=0, complement_cases=0, complement_err=0.0,
                clean_lower_violations=0, clean_upper_violations=0, volume_err=0.0, fd_err=0.0, eta_floor_violations=0)
    cases = 300; ratios = []; clean_ratio = []
    for k in range(cases):
        D, n, T = int(rng.integers(2, 5)), int(rng.integers(3, 12)), int(rng.integers(6, 21))
        Y, lw = random_archive(D, n); clean = k % 2 == 1
        if clean:                                                          # a clean top above the last positive scale 0.5
            s = np.concatenate([[0.0], np.exp(np.linspace(math.log(0.5), math.log(20), T))])
        else:
            s = np.exp(np.linspace(math.log(0.05), math.log(20), T + 1))
        z = kde_sample(Y, lw, s[-1], 1, rng)[0][0]
        K, Js, _ = composite(z.copy(), Y, lw, s)
        sv = np.linalg.svd(K, compute_uv=False); tol = 1e-12 * sv[0]
        ev = {t: np.linalg.eigvalsh(Js[t][0]) for t in Js}
        lo = np.prod([ev[t][0] for t in Js]); hi = np.prod([ev[t][-1] for t in Js])
        rows["floor_violations"] += sv[-1] < lo - tol
        rows["ceiling_violations"] += sv[0] > hi * (1 + 1e-12)
        if not clean:
            fl = s[0] / s[-1]
            rows["det_floor_violations"] += sv[-1] < fl * (1 - 1e-12) - tol
            ratios.append(sv[-1] / fl)
            logdet = sum(np.sum(np.log(ev[t])) for t in Js)                # (4.4): a sum over layers and eigenvalues
            rows["volume_err"] = max(rows["volume_err"], abs(logdet - np.sum(np.log(sv))) / (1 + abs(logdet)))
            if n - 1 < D:                                                  # directions in which the archive does not vary
                U, S, _ = np.linalg.svd((Y[1:] - Y[0]).T)
                comp = U[:, int(np.sum(S > 1e-10 * S[0])):]
                rows["complement_cases"] += 1
                rows["complement_err"] = max(rows["complement_err"], float(np.abs(K @ comp - fl * comp).max() / fl))
        else:
            c1 = np.sort(np.linalg.eigvalsh(Js[1][1]))[::-1]
            upper_factor = np.prod([ev[t][-1] for t in Js if t >= 2])
            lower = c1 / (s[1] * s[-1]); upper = c1 / s[1] ** 2 * upper_factor
            rows["clean_lower_violations"] += bool(np.any(sv < lower - tol))
            rows["clean_upper_violations"] += bool(np.any(sv > upper * (1 + 1e-12) + tol))
            if c1[-1] > 1e-8 * c1[0]:
                clean_ratio.append(float(sv[-1] / lower[-1]))
        if k < 40:
            h = 1e-6
            f = lambda x: run_stack(x[None], Y, lw, s, 0.0)[0]
            Kfd = np.column_stack([(f(z + h * e) - f(z - h * e)) / (2 * h) for e in np.eye(D)])
            rows["fd_err"] = max(rows["fd_err"], float(np.abs(K - Kfd).max() / (1 + np.abs(K).max())))
    # with noise the floor is omega_star along every realised path
    for _ in range(100):
        D, n, T = int(rng.integers(2, 5)), int(rng.integers(3, 12)), int(rng.integers(6, 21))
        Y, lw = random_archive(D, n); s = np.exp(np.linspace(math.log(0.05), math.log(20), T + 1)); eta = float(rng.uniform(0.2, 1))
        noise = {t: rng.standard_normal(D) for t in range(1, T + 1)}
        lam, sig = coefficients(s, eta); _, _, ws = separation_weights(lam)
        z = kde_sample(Y, lw, s[-1], 1, rng)[0][0]
        Kn, _, _ = composite(z.copy(), Y, lw, s, eta, noise)
        svn = np.linalg.svd(Kn, compute_uv=False)
        rows["eta_floor_violations"] += svn[-1] < ws * (1 - 1e-12) - 1e-12 * svn[0]
    rows["cases"] = cases; rows["noisy_cases"] = 100
    rows["floor_ratio_min"] = float(min(ratios)); rows["floor_ratio_median"] = float(np.median(ratios))
    rows["clean_ratio_median"] = float(np.median(clean_ratio)); rows["clean_cases_nondegenerate"] = len(clean_ratio)
    for key in ["floor_violations", "ceiling_violations", "det_floor_violations", "clean_lower_violations",
                "clean_upper_violations", "eta_floor_violations"]:
        rows[key] = int(rows[key])
    R["composite"] = rows


# ---------------------------------------------------------------- 12. expanding directions equal the Morse index
def newton_stationary(z, Y, lw, s, iters=80):
    for _ in range(iters):
        m, A = reads(z[None], Y, lw, s); C = covariance(A[0], Y, m[0])
        Fz = m[0] - z; Jf = C / s ** 2 - np.eye(len(z))
        try:
            step = np.linalg.solve(Jf, -Fz)
        except np.linalg.LinAlgError:
            return None
        z = z + step
        if np.linalg.norm(step) < 1e-13:
            return z
    return z if np.linalg.norm(reads(z[None], Y, lw, s)[0][0] - z) < 1e-9 else None


def check_morse():
    """Expanding directions of a layer at a stationary point against the Morse index of E_s from a finite-difference
    Hessian of log p_s; and the Morse balance  #minima - #saddles + #maxima = 1  of the coercive energy E_s in R^2."""
    agree = total = 0; kinds = {0: 0, 1: 0, 2: 0}; balanced = 0; archives = 60
    for _ in range(archives):
        n = int(rng.integers(3, 7)); Y, lw = random_archive(2, n, spread=1.0); s = float(rng.uniform(0.3, 1.0))
        found = []
        starts = [Y.mean(0) + 1.5 * rng.standard_normal(2) for _ in range(60)]
        lo, hi = Y.min(0) - 0.5, Y.max(0) + 0.5
        starts += [np.array([x, y]) for x in np.linspace(lo[0], hi[0], 15) for y in np.linspace(lo[1], hi[1], 15)]
        for z0 in starts:
            z = newton_stationary(z0, Y, lw, s)
            if z is not None and not any(np.linalg.norm(z - p) < 1e-6 for p in found):
                found.append(z)
        cnt = {0: 0, 1: 0, 2: 0}
        for z in found:
            m, A = reads(z[None], Y, lw, s); C = covariance(A[0], Y, m[0])
            expand = int(np.sum(np.linalg.eigvalsh(C) / s ** 2 > 1 + 1e-9))
            lp = lambda x: math.log(np.sum(np.exp(lw - np.sum((x - Y) ** 2, 1) / (2 * s * s))))
            h = 1e-4; Hs = np.zeros((2, 2))
            for i in range(2):
                for j in range(2):
                    ei, ej = np.eye(2)[i] * h, np.eye(2)[j] * h
                    Hs[i, j] = (lp(z + ei + ej) - lp(z + ei - ej) - lp(z - ei + ej) + lp(z - ei - ej)) / (4 * h * h)
            morse = int(np.sum(np.linalg.eigvalsh(Hs) > 1e-6))          # ascending directions of log p = descending of E_s
            total += 1; agree += expand == morse; kinds[expand] += 1; cnt[expand] += 1
        balanced += cnt[0] - cnt[1] + cnt[2] == 1
    R["morse"] = dict(archives=archives, stationary_points=total, agree=agree, energy_minima=kinds[0], saddles=kinds[1],
                      energy_maxima=kinds[2], balanced_archives=int(balanced))


# ---------------------------------------------------------------- 13. bifurcations happen where the tangent has eigenvalue one
def stationary_1d(Y, lw, s, lo=-3, hi=3, grid=4001):
    x = np.linspace(lo, hi, grid); m, _ = reads(x[:, None], Y, lw, s); F = m[:, 0] - x
    roots = []
    for i in range(grid - 1):
        if F[i] == 0 or F[i] * F[i + 1] < 0:
            a, b = x[i], x[i + 1]
            for _ in range(80):
                c = 0.5 * (a + b); fc = reads(np.array([[c]]), Y, lw, s)[0][0, 0] - c
                fa = reads(np.array([[a]]), Y, lw, s)[0][0, 0] - a
                if fa * fc <= 0:
                    b = c
                else:
                    a = c
            roots.append(0.5 * (a + b))
    return roots


def check_bifurcation():
    Y = np.array([[-1.0], [1.0]]); lw = np.zeros(2)
    counts = {round(s, 2): len(stationary_1d(Y, lw, s)) for s in [0.8, 0.9, 0.99, 1.01, 1.1, 1.3]}
    m, A = reads(np.zeros((1, 1)), Y, lw, 1.0); c_at = float(covariance(A[0], Y, m[0])[0, 0])
    # unequal weights: a fold, located by bisection on the number of stationary points
    lw2 = np.log(np.array([0.7, 0.3])); lo, hi = 0.5, 1.2
    for _ in range(50):
        mid = 0.5 * (lo + hi)
        if len(stationary_1d(Y, lw2, mid)) >= 3:
            lo = mid
        else:
            hi = mid
    sf = lo; roots = stationary_1d(Y, lw2, sf)
    vals = []
    for r in roots:
        m, A = reads(np.array([[r]]), Y, lw2, sf); vals.append(float(covariance(A[0], Y, m[0])[0, 0] / sf ** 2))
    R["bifurcation"] = dict(equal_counts=counts, equal_tangent_at_midpoint=c_at, unequal_fold_scale=sf,
                            unequal_tangent_eigenvalues=vals, closest_to_one=float(min(abs(v - 1) for v in vals)))


# ---------------------------------------------------------------- 14. one-dimensional causality of mode counts
def check_causality_1d():
    viol = 0; archives = 150; grid = np.exp(np.linspace(math.log(0.05), math.log(5), 30))
    for _ in range(archives):
        n = int(rng.integers(3, 10)); Y = rng.uniform(-3, 3, (n, 1)); lw = rng.normal(0, 0.7, n)
        cnt = [len(modes(Y, lw, s, starts=np.linspace(-6, 6, 400)[:, None], iters=3000)) for s in grid]
        viol += any(cnt[i + 1] > cnt[i] for i in range(len(cnt) - 1))
    R["causality_1d"] = dict(archives=archives, scales=len(grid), violations=int(viol))


# ---------------------------------------------------------------- 15. in two dimensions a mode can be created as the scale grows
def check_triangle():
    Y = np.array([[0.0, 0.0], [1.0, 0.0], [0.5, math.sqrt(3) / 2]]); lw = np.zeros(3)
    grid = np.round(np.arange(0.395, 0.4351, 0.0025), 4)
    counts = {float(s): len(modes(Y, lw, float(s), grid=41, iters=6000)) for s in grid}
    four = [s for s, c in counts.items() if c == 4]
    R["triangle"] = dict(side=1.0, counts=counts, four_mode_from=min(four), four_mode_to=max(four))


# ---------------------------------------------------------------- 16. thresholded ranks are not rank invariants
def check_effective_rank():
    J1, J2 = np.diag([10.0, 0.05]), np.diag([0.05, 10.0]); tau = 0.1
    eff = lambda M: int(np.sum(np.linalg.svd(M, compute_uv=False) > tau))
    maps = {(2, 1): J2, (1, 0): J1}
    def r(a, b):
        if a == b:
            return 2
        M = np.eye(2)
        for t in range(a, b, -1):
            M = maps[(t, t - 1)] @ M
        return eff(M)
    mult = barcode_from_ranks(r, 2)
    # a uniform contraction: every single map keeps both directions above tau, their composite keeps none
    c1 = 0.7 * np.eye(2); tau2 = 0.6
    def rc(a, b):
        M = np.linalg.matrix_power(c1, a - b)
        return int(np.sum(np.linalg.svd(M, compute_uv=False) > tau2))
    mult_c = barcode_from_ranks(rc, 2)
    neg = 0; trials = 2000; exact_neg = 0; deficient = 0
    for _ in range(trials):
        mats = {}
        for t in range(3, 0, -1):
            U, _ = np.linalg.qr(rng.standard_normal((3, 3))); V, _ = np.linalg.qr(rng.standard_normal((3, 3)))
            sv = np.exp(rng.normal(0, 2, 3))
            if rng.random() < 0.5:                                      # half of the maps lose rank exactly
                sv[int(rng.integers(0, 3))] = 0.0; deficient += 1
            mats[(t, t - 1)] = U @ np.diag(sv) @ V.T
        def reff(a, b):
            M = np.eye(3)
            for t in range(a, b, -1):
                M = mats[(t, t - 1)] @ M
            return int(np.sum(np.linalg.svd(M, compute_uv=False) > 1.0))
        def rex(a, b):
            M = np.eye(3)
            for t in range(a, b, -1):
                M = mats[(t, t - 1)] @ M
            return int(np.linalg.matrix_rank(M, tol=1e-9 * max(1.0, np.abs(M).max())))
        neg += min(barcode_from_ranks(reff, 3).values()) < 0
        exact_neg += min(barcode_from_ranks(rex, 3).values()) < 0
    R["effective_rank"] = dict(example_multiplicities={f"[{b},{d}]": v for (b, d), v in mult.items() if v != 0},
                               contraction_multiplicities={f"[{b},{d}]": v for (b, d), v in mult_c.items() if v != 0},
                               random_chains=trials, rank_deficient_maps=deficient,
                               chains_with_negative_multiplicity=int(neg), exact_negative=int(exact_neg))


# ---------------------------------------------------------------- 17. the Euler error density
def check_euler_density():
    errs = []; ident = []
    for _ in range(40):
        D, n = 2, int(rng.integers(3, 9)); Y, lw = random_archive(D, n)
        s_grid = np.exp(np.linspace(math.log(0.2), math.log(10), 40001)); z = kde_sample(Y, lw, 10.0, 1, rng)[0][0]
        zs = [z.copy()]
        for k in range(len(s_grid) - 1, 0, -1):                     # fine Euler as the reference flow, from s=10 down
            m, _ = reads(z[None], Y, lw, s_grid[k]); z = z + (s_grid[k - 1] - s_grid[k]) * (z - m[0]) / s_grid[k]; zs.append(z.copy())
        zs = np.array(zs[::-1])                                     # increasing s
        for k in [8000, 20000, 32000]:
            s = s_grid[k]; hl, hr = s - s_grid[k - 1], s_grid[k + 1] - s
            fd = 2 * (zs[k + 1] * hl - zs[k] * (hl + hr) + zs[k - 1] * hr) / (hl * hr * (hl + hr))
            z0 = zs[k]; m, A = reads(z0[None], Y, lw, s); C = covariance(A[0], Y, m[0]); Dm = C / s ** 2
            e = 0.5 * np.sum((z0 - Y) ** 2, 1); ebar = A[0] @ e
            dsm = (2 / s ** 3) * ((A[0] * (e - ebar)) @ Y)
            formula = -Dm @ (z0 - m[0]) / s ** 2 - dsm / s
            dev = Y - m[0]; M3 = (A[0] * np.sum(dev ** 2, 1)) @ dev        # third central moment vector of the posterior
            moment = (C @ (z0 - m[0]) - M3) / s ** 4                         # form (5.2)
            errs.append(float(np.abs(fd - formula).max() / (1e-3 + np.abs(formula).max())))
            Rd = max(np.linalg.norm(p - q) for p in Y for q in Y)
            scale = (Rd ** 2 * np.linalg.norm(z0 - m[0]) + Rd ** 3) / s ** 4      # the scale of bound (5.3)
            ident.append(float(np.abs(moment - formula).max() / scale))
    R["euler_density"] = dict(points=len(errs), max_rel_err=float(max(errs)), median_rel_err=float(np.median(errs)),
                              moment_form_err=float(max(ident)))


# ---------------------------------------------------------------- 18. component births against mode changes
def components(Y, r):
    n = len(Y); parent = list(range(n))
    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]; i = parent[i]
        return i
    for i in range(n):
        for j in range(i + 1, n):
            if np.linalg.norm(Y[i] - Y[j]) < 2 * r:
                parent[find(i)] = find(j)
    return len({find(i) for i in range(n)})


def check_components_vs_modes():
    agree = total = 0; archives = 30; grid = np.exp(np.linspace(math.log(0.03), math.log(0.6), 16))
    for _ in range(archives):
        Y = rng.uniform(0, 1, (8, 2)); lw = np.zeros(8)
        for s in grid:
            total += 1; agree += components(Y, s) == len(modes(Y, lw, s, grid=22, iters=2500))
    R["components_vs_modes"] = dict(archives=archives, scales=len(grid), pairs=total, agree=agree, share=agree / total)


if __name__ == "__main__":
    for fn in [check_variance_bookkeeping, check_separation, check_noise_budget, check_deterministic_weights, check_ade_stack,
               check_euler_identity, check_continuum, check_clean_top, check_hulls, check_layer_jacobian, check_composite,
               check_morse, check_bifurcation, check_causality_1d, check_triangle, check_effective_rank, check_euler_density,
               check_components_vs_modes]:
        fn(); print("done", fn.__name__, flush=True)
    json.dump(R, open(os.path.join(here, "p3_checks.json"), "w"), indent=1,
              default=lambda o: o.tolist() if hasattr(o, "tolist") else (int(o) if isinstance(o, np.integer) else str(o)))
    print(json.dumps(R, indent=1, default=str))
