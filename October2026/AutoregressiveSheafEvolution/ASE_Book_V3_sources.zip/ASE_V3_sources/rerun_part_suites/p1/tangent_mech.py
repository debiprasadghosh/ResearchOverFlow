# Why is the composite tangent numerically rank-deficient for a few tokens? Record the final posterior concentration.
import json, math, os, sys
import numpy as np
here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, here)
import p1_checks as PC

# replay the main script up to the tangent check so that the random stream is identical
for fn in [PC.check_delta_squared, PC.check_hodge_residual, PC.check_holonomy, PC.check_triangle_flat, PC.check_harary,
           PC.check_contexts, PC.check_two_arcs, PC.check_pullback, PC.check_barcodes]:
    fn()
rng = PC.rng
T = 16
a = [math.cos(math.pi * t / (2 * T)) ** 2 for t in range(T)]
scale = lambda x: math.sqrt((1 - x) / x)
centres = np.array([[0.0, 0.0], [2.5, 0.0], [1.2, 2.2]])
Y = np.concatenate([c + 0.35 * rng.standard_normal((10, 2)) for c in centres])
rows = []
for tok in range(1000):
    z = rng.standard_normal(2) / math.sqrt(a[T - 1])
    Mc = np.eye(2)
    for t in range(T - 1, 0, -1):
        st = scale(a[t]); sp = scale(a[t - 1]) if t > 1 else 0.0
        lam = 1 - sp / st
        l = -((z - Y) ** 2).sum(1) / (2 * st * st); al = np.exp(l - l.max()); al /= al.sum()
        m = al @ Y; C = (al[:, None] * Y).T @ Y - np.outer(m, m)
        J = (1 - lam) * np.eye(2) + lam / st ** 2 * C
        Mc = J @ Mc
        z = (1 - lam) * z + lam * m
    s = np.linalg.svd(Mc, compute_uv=False)
    sup = np.where(al > 1e-16)[0]                       # records whose weight survives in double precision
    aff = PC.rank((Y[sup[1:]] - Y[sup[0]]).T, 1e-9) if len(sup) > 1 else 0
    ev = np.linalg.eigvalsh(C)
    rows.append((PC.rank(Mc, 1e-14), 1.0 - al.max(), s[-1], len(sup), aff, int((al > 1e-8).sum()), float(ev[0])))
full = [r for r in rows if r[0] == 2]; low = [r for r in rows if r[0] < 2]
out = dict(tokens=len(rows), full_share=len(full) / len(rows), deficient=len(low),
           deficient_offmass_max=max(r[1] for r in low) if low else None,
           full_offmass_min=min(r[1] for r in full),
           deficient_support_sizes=sorted({r[3] for r in low}),
           deficient_rank_equals_support_affine_dim=sum(r[0] == r[4] for r in low),
           full_support_min=min(r[3] for r in full),
           full_rank_equals_support_affine_dim=sum(r[0] == r[4] for r in full),
           deficient_weights_above_1e8=sorted({r[5] for r in low}),
           deficient_min_eig_C1_max=max(r[6] for r in low),
           full_min_eig_C1_min=min(r[6] for r in full),
           deficient_smin_max=max(r[2] for r in low))
print(json.dumps(out, indent=1))
json.dump(out, open(os.path.join(here, "tangent_mech.json"), "w"), indent=1)
