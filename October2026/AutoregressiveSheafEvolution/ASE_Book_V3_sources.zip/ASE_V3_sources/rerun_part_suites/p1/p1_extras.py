# Supplementary checks for Part I, added while writing the paper. Results go to p1_extras.json.
import itertools, json, math, os, sys
import numpy as np

here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, here)
from p1_checks import CellSheaf, faces, closure, barcode, PosetFunctor, face_poset_functor, rank

rng = np.random.default_rng(20261019)
X = {}


def null(M):
    if M.shape[0] == 0:
        return np.eye(M.shape[1])
    _, s, vt = np.linalg.svd(M)
    return vt[rank(M):].T


def perm_sign(order):
    order = list(order); sign = 1
    for i in range(len(order)):
        for j in range(i + 1, len(order)):
            if order[i] > order[j]:
                sign = -sign
    return sign


def bars_from_rank(n, r):
    """Interval multiplicities from a rank function on positions 1..n (bottom to top)."""
    R_ = lambda i, j: 0 if (i < 1 or j > n or i > j) else r(i, j)
    out = {}
    for i in range(1, n + 1):
        for j in range(i, n + 1):
            m = R_(i, j) - R_(i - 1, j) - R_(i, j + 1) + R_(i - 1, j + 1)
            if m:
                out[(i, j)] = m
    return out


# ---------------------------------------------------------------- 1. homogenised affine chains add exactly one full bar
def check_affine_bars():
    agree, trials = 0, 500
    for _ in range(trials):
        n, D = int(rng.integers(3, 7)), int(rng.integers(1, 5))
        A, Hm = [], []
        for _k in range(n - 1):
            rk = int(rng.integers(0, D + 1))
            a = rng.standard_normal((D, rk)) @ rng.standard_normal((rk, D))
            b = rng.standard_normal(D) * float(rng.random() < 0.8)
            M = np.eye(D + 1); M[:D, :D] = a; M[:D, D] = b
            A.append(a); Hm.append(M)
        bA, _ = barcode([D] * n, A)
        bH, _ = barcode([D + 1] * n, Hm)
        expect = dict(bA); expect[(1, n)] = expect.get((1, n), 0) + 1
        agree += bH == expect
    X["affine_bars"] = dict(trials=trials, agree=agree)


# ---------------------------------------------------------------- 2. vertical acyclicity on random subquotient towers; a zigzag is not acyclic
def orth(M, tol=1e-9):
    if M.size == 0 or M.shape[1] == 0:
        return np.zeros((M.shape[0], 0))
    U, s, _ = np.linalg.svd(M, full_matrices=False)
    return U[:, :int((s > tol * max(1.0, s[0])).sum())]


def complement(Wb, Kb):
    if Wb.shape[1] == 0:
        return Wb
    return orth(Wb - Kb @ (Kb.T @ Wb)) if Kb.shape[1] else Wb


def random_tower(simplices, H, m, twist):
    """Stalks W/K for increasing subspaces K <= W of R^m (increasing along faces and layers); maps induced by identity."""
    W, K = {}, {}
    shared = rng.standard_normal((m, int(rng.integers(1, 3))))      # a common subspace makes global sections likely
    for h in range(H):
        for s in simplices:
            fw = [W[(f, h)] for f in faces(s)] + ([W[(s, h - 1)]] if h else [])
            fk = [K[(f, h)] for f in faces(s)] + ([K[(s, h - 1)]] if h else [])
            base_w = np.hstack(fw) if fw else np.zeros((m, 0))
            extra_w = shared if (not fw and rng.random() < 0.6) else rng.standard_normal((m, int(rng.integers(0, 2 if fw else 3))))
            Wb = orth(np.hstack([base_w, extra_w]))
            base_k = np.hstack(fk) if fk else np.zeros((m, 0))
            nk = int(rng.random() < 0.3)
            extra_k = Wb @ rng.standard_normal((Wb.shape[1], nk)) if Wb.shape[1] else np.zeros((m, 0))
            W[(s, h)], K[(s, h)] = Wb, orth(np.hstack([base_k, extra_k]))
    B = {key: complement(W[key], K[key]) for key in W}
    sgn = lambda f, s: -1.0 if (f, s) in twist else 1.0
    layers = [CellSheaf(simplices, {s: B[(s, h)].shape[1] for s in simplices},
                        {(f, s): sgn(f, s) * B[(s, h)].T @ B[(f, h)] for s in simplices for f in faces(s)}) for h in range(H)]
    elems = [(s, h) for h in range(H) for s in simplices]
    leq = lambda x, y: set(x[0]) <= set(y[0]) and x[1] <= y[1]
    dims = lambda x: B[x].shape[1]
    mapfn = lambda x, y: sgn(x[0], y[0]) * B[y].T @ B[x]
    return layers, PosetFunctor(elems, leq, dims, mapfn)


def check_product_random():
    complexes = {
        "hollow triangle": closure([(0, 1), (1, 2), (0, 2)]),
        "filled triangle with a pendant edge": closure([(0, 1, 2), (2, 3)]),
        "filled and hollow triangle on a shared edge": closure([(0, 1, 2), (1, 3), (2, 3)]),
        "four-cycle": closure([(0, 1), (1, 2), (2, 3), (0, 3)]),
    }
    rows, agree, total, nonzero_h1, nonzero_h0, upper_differs = [], 0, 0, 0, 0, 0
    for name, simp in complexes.items():
        top = max(len(s) for s in simp) - 1
        for trial in range(20):
            twist = set()
            if top == 1 and rng.random() < 0.5:
                e = simp[[len(s) for s in simp].index(2) + int(rng.integers(0, sum(len(s) == 2 for s in simp)))]
                twist = {((e[1],), e)}
            layers, prod = random_tower(simp, 3, 4, twist)
            derived = prod.derived_limits(2)
            bottom = layers[0].betti(2)
            total += 1; agree += derived == bottom; nonzero_h1 += bottom[1] > 0; nonzero_h0 += bottom[0] > 0
            upper_differs += any(L.betti(2) != bottom for L in layers[1:])
            if trial < 2:
                rows.append(dict(complex=name, derived=derived, bottom=bottom, layer_betti=[L.betti(2) for L in layers]))
    # zigzag a <= c >= b: two minimal elements, so the limit is not an evaluation
    dims = {"a": 1, "b": 1, "c": 2}
    e1 = np.array([[1.0], [0.0]])
    zz = PosetFunctor(["a", "c", "b"], lambda x, y: x == y or y == "c", lambda x: dims[x],
                      lambda x, y: np.eye(dims[x]) if x == y else e1).derived_limits(2)
    X["product_random"] = dict(trials=total, agree=agree, bottom_h0_nonzero=nonzero_h0, bottom_h1_nonzero=nonzero_h1,
                               upper_layers_differ=upper_differs, examples=rows, zigzag=zz)


# ---------------------------------------------------------------- 3. a sheaf of feasible sets with no global section
def check_feasible_cycle():
    ctx = [(0, 1), (1, 2), (0, 2)]
    local = {c: [(u, v) for u in (0, 1) for v in (0, 1) if u != v] for c in ctx}
    glob = [x for x in itertools.product((0, 1), repeat=3) if all(x[i] != x[j] for i, j in ctx)]
    pairwise = all(any(s[c1.index(j)] == t[c2.index(j)] for t in local[c2])
                   for c1 in ctx for c2 in ctx if c1 != c2 for j in set(c1) & set(c2) for s in local[c1])
    X["feasible_cycle"] = dict(local_sizes=[len(local[c]) for c in ctx], global_sections=len(glob), pairwise_extendable=pairwise)


# ---------------------------------------------------------------- 4. Gaussian posterior covariance: rank and concentration
def check_covariance():
    ok_rank = ok_eps = 0; trials = 400; worst = 0.0
    for _ in range(trials):
        D, n = 4, int(rng.integers(2, 9)); k = int(rng.integers(0, min(D, n - 1) + 1))
        U = np.linalg.qr(rng.standard_normal((D, D)))[0][:, :k]
        V = rng.standard_normal(D) + (rng.standard_normal((n, k)) @ U.T if k else np.zeros((n, D)))
        lg = rng.normal(0, 1.5, n); al = np.exp(lg - lg.max()); al /= al.sum()
        m = al @ V; C = (al[:, None] * (V - m)).T @ (V - m)
        ok_rank += rank(C, 1e-9) == rank((V[1:] - V[0]).T, 1e-9) == k
        eps, j = float(rng.uniform(1e-4, 0.3)), int(rng.integers(n))
        w = rng.random(n); w[j] = 0.0; w = eps * w / w.sum(); w[j] = 1 - eps
        mm = w @ V; CC = (w[:, None] * (V - mm)).T @ (V - mm)
        diam = max(np.linalg.norm(V[a] - V[b]) for a in range(n) for b in range(n))
        ratio = np.linalg.norm(CC, 2) / (eps * diam ** 2) if diam > 0 else 0.0
        worst = max(worst, ratio); ok_eps += ratio <= 1 + 1e-12
    X["covariance"] = dict(trials=trials, rank_equals_affine_dim=ok_rank, eps_bound_holds=ok_eps, worst_ratio=float(worst))


# ---------------------------------------------------------------- 5. circle covers: a coarse cover whose nerve misses the loop
TWO_PI, NS = 2 * math.pi, 7200
theta = np.arange(NS) * TWO_PI / NS


def arc_mask(a, b):
    return np.mod(theta - a, TWO_PI) < (b - a)


def circle_components(mask):
    if mask.all():
        return np.zeros(NS, int), 1
    if not mask.any():
        return -np.ones(NS, int), 0
    lab, c, prev, start = -np.ones(NS, int), -1, False, int(np.argmin(mask))
    for k in range(1, NS + 1):
        i = (start + k) % NS
        if mask[i]:
            if not prev:
                c += 1
            lab[i] = c
        prev = bool(mask[i])
    return lab, c + 1


def cech_layer(arcs, data):
    masks = [arc_mask(a, b) for a, b in arcs]
    simp, comp = [], {}
    for r in (1, 2, 3):
        for s in itertools.combinations(range(len(arcs)), r):
            lab, cnt = circle_components(np.logical_and.reduce([masks[i] for i in s]))
            if cnt:
                simp.append(s); comp[s] = (lab, cnt)
    dims = {s: (comp[s][1] if data else 1) for s in simp}
    maps = {}
    for t in simp:
        for f in faces(t):
            if data:
                (lt, ct), (lf, cf) = comp[t], comp[f]
                M = np.zeros((ct, cf))
                for c in range(ct):
                    M[c, lf[np.where(lt == c)[0][0]]] = 1.0
            else:
                M = np.eye(1)
            maps[(f, t)] = M
    return dict(sheaf=CellSheaf(simp, dims, maps), masks=masks, comp=comp, data=data)


def refinement(coarse, fine):
    return [next(i for i, mc in enumerate(coarse["masks"]) if not (mf & ~mc).any()) for mf in fine["masks"]]


def cech_map(coarse, fine, phi, k):
    """Cochain map C^k(coarse) -> C^k(fine) induced by the refinement map phi (degenerate images give zero)."""
    Sc, Sf = coarse["sheaf"], fine["sheaf"]
    rows, nr = Sf.offsets(k); cols, nc = Sc.offsets(k)
    M = np.zeros((nr, nc))
    for s in Sf.cells(k):
        img = [phi[v] for v in s]
        if len(set(img)) < len(img):
            continue
        t, sign = tuple(sorted(img)), perm_sign(np.argsort(img))
        if coarse["data"]:
            (lt, _), (ls, cs) = coarse["comp"][t], fine["comp"][s]
            Bk = np.zeros((cs, coarse["comp"][t][1]))
            for c in range(cs):
                Bk[c, lt[np.where(ls == c)[0][0]]] = 1.0
        else:
            Bk = np.eye(1)
        M[rows[s]:rows[s] + Sf.dims[s], cols[t]:cols[t] + Sc.dims[t]] = sign * Bk
    return M


def induced_rank(Ca, Cb, F, k):
    Z = null(Ca.delta(k))
    Bb = Cb.delta(k - 1) if k > 0 else np.zeros((Cb.offsets(0)[1], 0))
    return rank(np.hstack([F @ Z, Bb])) - rank(Bb)


def check_circle():
    covers = [[(-1.2, math.pi + 1.2), (math.pi - 1.2, TWO_PI + 1.2)],
              [(TWO_PI * j / 3 - 0.1, TWO_PI * (j + 1) / 3 + 0.1) for j in range(3)],
              [(TWO_PI * j / 6 - 0.05, TWO_PI * (j + 1) / 6 + 0.05) for j in range(6)]]
    out = {}
    for data in (False, True):
        L = [cech_layer(c, data) for c in covers]
        phis = [refinement(L[i], L[i + 1]) for i in range(2)]
        F = {k: [cech_map(L[i], L[i + 1], phis[i], k) for i in range(2)] for k in (0, 1)}
        chain_err = max(float(np.abs(L[i + 1]["sheaf"].delta(0) @ F[0][i] - F[1][i] @ L[i]["sheaf"].delta(0)).max()) for i in range(2))
        res = dict(betti=[L[i]["sheaf"].betti(1) for i in range(3)], chain_map_error=chain_err, refinement_maps=phis,
                   bottom_overlap_components=L[0]["comp"][(0, 1)][1])
        for k in (0, 1):
            def r(i, j, k=k):
                if i == j:
                    return L[i - 1]["sheaf"].betti(1)[k]
                Fm = np.eye(L[i - 1]["sheaf"].offsets(k)[1])
                for q in range(i - 1, j - 1):
                    Fm = F[k][q] @ Fm
                return induced_rank(L[i - 1]["sheaf"], L[j - 1]["sheaf"], Fm, k)
            res[f"H{k}_bars"] = {f"[{a},{b}]": v for (a, b), v in sorted(bars_from_rank(3, r).items())}
        out["data_sheaf" if data else "plain_nerve"] = res
    X["circle"] = out


# ---------------------------------------------------------------- 6. H0 barcode of a nested ball filtration (three-scale archive)
def barcode_archive():
    """The archive of the proposal's check 21: three clusters of three sub-clusters of four records."""
    rng2 = np.random.default_rng(7)
    tops = np.array([[0.0, 0.0], [6.5, 0.5], [3.0, 5.8]])
    pts = []
    for c in tops:
        phi = rng2.uniform(0, 2 * math.pi)
        for k in range(3):
            sc = c + 1.25 * np.array([math.cos(phi + 2 * math.pi * k / 3), math.sin(phi + 2 * math.pi * k / 3)])
            pts.append(sc + 0.07 * rng2.standard_normal((4, 2)))
    return np.concatenate(pts)


def labels_at(Y, thr):
    n = len(Y); parent = list(range(n))
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]; x = parent[x]
        return x
    for i in range(n):
        for j in range(i + 1, n):
            if np.linalg.norm(Y[i] - Y[j]) < thr:
                parent[find(i)] = find(j)
    roots = sorted({find(i) for i in range(n)})
    return np.array([roots.index(find(i)) for i in range(n)])


def check_archive_barcode():
    Y = barcode_archive(); T = 16
    layers = list(range(T - 1, 0, -1))                       # 15 (bottom) ... 1; the clean top has radius zero
    s = {t: math.tan(math.pi * t / (2 * T)) for t in layers}
    lab = {t: labels_at(Y, 2 * s[t]) for t in layers}
    comps = {t: int(lab[t].max() + 1) for t in layers}
    n = len(layers)
    def restriction(ta, tb):                                 # H0 at layer ta -> H0 at layer tb above it
        M = np.zeros((comps[tb], comps[ta]))
        for i in range(len(Y)):
            M[lab[tb][i], lab[ta][i]] = 1.0
        return M
    def r(i, j):
        return comps[layers[i - 1]] if i == j else rank(restriction(layers[i - 1], layers[j - 1]))
    bars = bars_from_rank(n, r)
    births = {}
    for (a, b), v in bars.items():
        births[layers[a - 1]] = births.get(layers[a - 1], 0) + v
    X["archive_barcode"] = dict(records=len(Y), components={str(t): comps[t] for t in layers}, scales={str(t): s[t] for t in layers},
                                births={str(t): v for t, v in sorted(births.items(), reverse=True)},
                                all_reach_top=all(b == n for (a, b) in bars), injective=all(
                                    rank(restriction(layers[i], layers[i + 1])) == comps[layers[i]] for i in range(n - 1)))


if __name__ == "__main__":
    for fn in [check_affine_bars, check_product_random, check_feasible_cycle, check_covariance, check_circle, check_archive_barcode]:
        fn(); print("done", fn.__name__, flush=True)
    json.dump(X, open(os.path.join(here, "p1_extras.json"), "w"), indent=1, default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o))
    print(json.dumps(X, indent=1, default=str))
