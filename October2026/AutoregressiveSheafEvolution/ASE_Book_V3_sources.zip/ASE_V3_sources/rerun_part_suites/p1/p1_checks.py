# Numerical checks for "Horizontally Topological, Vertically Algebraic" (ASE, Part I).
# Every number quoted in the paper comes from p1_checks.json, written by this script.
import itertools, json, math, sys
from collections import defaultdict
import numpy as np

rng = np.random.default_rng(20261018)
R = {}


def rank(M, tol=1e-9):
    if M.size == 0:
        return 0
    s = np.linalg.svd(M, compute_uv=False)
    return int((s > tol * max(1.0, s[0])).sum())


def rand_orth(d):
    Q, Rr = np.linalg.qr(rng.standard_normal((d, d)))
    return Q * np.sign(np.diag(Rr))


# ---------------------------------------------------------------- cellular sheaves on simplicial complexes
class CellSheaf:
    """Cellular sheaf on a simplicial complex: simplices are sorted tuples; maps[(s, t)] for s a codim-1 face of t."""

    def __init__(self, simplices, dims, maps):
        self.simplices = sorted(set(simplices), key=lambda s: (len(s), s))
        self.dims, self.maps = dims, maps

    def cells(self, k):
        return [s for s in self.simplices if len(s) == k + 1]

    def offsets(self, k):
        off, o = {}, 0
        for s in self.cells(k):
            off[s] = o; o += self.dims[s]
        return off, o

    def delta(self, k):
        rows, nr = self.offsets(k + 1)
        cols, nc = self.offsets(k)
        D = np.zeros((nr, nc))
        for t in self.cells(k + 1):
            for i in range(len(t)):
                s = t[:i] + t[i + 1:]
                D[rows[t]:rows[t] + self.dims[t], cols[s]:cols[s] + self.dims[s]] += (-1) ** i * self.maps[(s, t)]
        return D

    def betti(self, kmax=None):
        top = max(len(s) for s in self.simplices) - 1
        kmax = top if kmax is None else kmax
        K = max(top, kmax)
        dims = [self.offsets(k)[1] for k in range(K + 1)]
        ranks = [rank(self.delta(k)) if k < top else 0 for k in range(K + 1)]
        return [dims[k] - ranks[k] - (ranks[k - 1] if k > 0 else 0) for k in range(kmax + 1)]


def faces(simplex):
    return [simplex[:i] + simplex[i + 1:] for i in range(len(simplex))] if len(simplex) > 1 else []


def closure(maximal):
    out = set()
    for s in maximal:
        for r in range(1, len(s) + 1):
            out.update(itertools.combinations(sorted(s), r))
    return sorted(out, key=lambda s: (len(s), s))


# ---------------------------------------------------------------- A. coboundary squares to zero only with compatible maps
def check_delta_squared():
    tri = closure([(0, 1, 2)])
    p, m = 2, 2
    dims, maps = {}, {}
    A = {}
    for v in [(0,), (1,), (2,)]:
        dims[v] = int(rng.integers(2, 4)); A[v] = rng.standard_normal((p, dims[v]))
    dims[(0, 1, 2)] = p
    for e in [(0, 1), (1, 2), (0, 2)]:
        dims[e] = p + m
        maps[(e, (0, 1, 2))] = np.hstack([np.eye(p), np.zeros((p, m))])
        for v in faces(e):
            maps[(v, e)] = np.vstack([A[v], rng.standard_normal((m, dims[v]))])
    S = CellSheaf(tri, dims, maps)
    err_compatible = float(np.abs(S.delta(1) @ S.delta(0)).max())
    bad = dict(maps)
    bad[((0,), (0, 1))] = rng.standard_normal(maps[((0,), (0, 1))].shape)
    Sb = CellSheaf(tri, dims, bad)
    err_incompatible = float(np.abs(Sb.delta(1) @ Sb.delta(0)).max())
    b = S.betti()
    chi_cells = sum((-1) ** k * S.offsets(k)[1] for k in range(3))
    R["delta_squared"] = dict(compatible_max=err_compatible, incompatible_max=err_incompatible,
                              betti=b, euler_cells=chi_cells, euler_cohomology=b[0] - b[1] + b[2])


# ---------------------------------------------------------------- graph sheaves
def graph_sheaf(n, edges, Fu, Fv, vdim, edim):
    simp = [(i,) for i in range(n)] + [tuple(sorted(e)) for e in edges]
    dims = {(i,): vdim[i] for i in range(n)}
    maps = {}
    for k, (u, v) in enumerate(edges):
        e = (u, v) if u < v else (v, u)
        dims[e] = edim[k]
        a, b = (u, v) if u < v else (v, u)
        maps[((a,), e)] = Fu[k] if u < v else Fv[k]
        maps[((b,), e)] = Fv[k] if u < v else Fu[k]
    return CellSheaf(simp, dims, maps)


def random_connected_graph(n, m):
    while True:
        edges = set()
        perm = rng.permutation(n)
        for i in range(1, n):
            a, b = int(perm[i]), int(perm[rng.integers(0, i)])
            edges.add((min(a, b), max(a, b)))
        while len(edges) < m:
            a, b = rng.choice(n, 2, replace=False)
            edges.add((int(min(a, b)), int(max(a, b))))
        return sorted(edges)


def check_hodge_residual():
    n, m, d = 8, 13, 2
    E = random_connected_graph(n, m)
    rows = []
    for name in ["trivial", "random"]:
        Q = [rand_orth(d) for _ in range(n)]
        Fu = [Q[u].T for (u, v) in E] if name == "trivial" else [np.eye(d) for _ in E]
        Fv = [Q[v].T for (u, v) in E] if name == "trivial" else [rand_orth(d) for _ in E]
        S = graph_sheaf(n, E, Fu, Fv, [d] * n, [d] * m)
        Dl = S.delta(0)
        w = rng.uniform(0.5, 2.0, m)
        W = np.diag(np.repeat(w, d))
        L = Dl.T @ W @ Dl
        ev = np.linalg.eigvalsh(L); tol = 1e-9 * ev.max()
        lam2, lmax = ev[ev > tol].min(), ev.max()
        K = np.linalg.svd(Dl)[2][rank(Dl):].T
        viol, ratios_lo, ratios_hi = 0, [], []
        for _ in range(500):
            x = rng.standard_normal(n * d)
            dist = np.linalg.norm(x - K @ (K.T @ x)) if K.size else np.linalg.norm(x)
            res = math.sqrt(float((Dl @ x) @ W @ (Dl @ x)))
            lo, hi = res / math.sqrt(lmax), res / math.sqrt(lam2)
            viol += not (lo <= dist * (1 + 1e-12) and dist <= hi * (1 + 1e-12))
            ratios_lo.append(dist / lo); ratios_hi.append(dist / hi)
        # Hodge on edges: C1 = im(delta) + ker(delta^T W) (W-orthogonal); harmonic dimension = H1
        h1 = Dl.shape[0] - rank(Dl)
        harm = Dl.shape[0] - rank(Dl.T @ W)
        rows.append(dict(sheaf=name, H0=S.betti()[0], H1=h1, harmonic_dim=harm, violations=viol,
                         min_ratio_to_lower=float(min(ratios_lo)), max_ratio_to_upper=float(max(ratios_hi))))
    R["hodge_residual"] = rows


# ---------------------------------------------------------------- D. holonomy theorem
def holonomy_dims(n, E, O, d):
    """Sheaf: F(u<=e) = I, F(v<=e) = O_e for e = (u, v), u < v; sections satisfy x_u = O_e x_v."""
    adj = defaultdict(list)
    for k, (u, v) in enumerate(E):
        adj[u].append((v, k)); adj[v].append((u, k))
    g = {0: np.eye(d)}; tree = set(); stack = [0]
    while stack:
        a = stack.pop()
        for b, k in adj[a]:
            if b not in g:
                u, v = E[k]
                # along a section, x_v = O_e^T x_u and x_u = O_e x_v; x_b = g_b x_0
                g[b] = O[k].T @ g[a] if E[k][1] == b else O[k] @ g[a]
                tree.add(k); stack.append(b)
    hol = [g[E[k][0]].T @ O[k] @ g[E[k][1]] for k in range(len(E)) if k not in tree]
    fixed = d - rank(np.vstack([h - np.eye(d) for h in hol])) if hol else d
    S = graph_sheaf(n, E, [np.eye(d) for _ in E], O, [d] * n, [d] * len(E))
    return fixed, S.betti()[0], len(hol), d * (len(E) - n) + S.betti()[0], S.betti()[1]


def check_holonomy():
    rows = []
    for d in [2, 3]:
        n, m = 7, 11
        E = random_connected_graph(n, m)
        Q = [rand_orth(d) for _ in range(n)]
        trivial = [Q[u] @ Q[v].T for (u, v) in E]
        cases = {"trivial": trivial, "random": [rand_orth(d) for _ in E]}
        # one twisted non-tree edge: rotation about an axis (d = 3) or reflection (d = 2)
        tw = list(trivial)
        k = len(E) - 1
        if d == 2:
            Rf = np.array([[1.0, 0.0], [0.0, -1.0]])
        else:
            c, s = math.cos(1.1), math.sin(1.1)
            Rf = np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])
        tw[k] = Q[E[k][0]] @ Rf @ Q[E[k][1]].T
        cases["one twisted edge"] = tw
        for name, O in cases.items():
            fixed, h0, cycles, h1_formula, h1 = holonomy_dims(n, E, O, d)
            rows.append(dict(d=d, case=name, cycles=cycles, fixed_dim=fixed, H0=h0, H1=h1, H1_euler=h1_formula))
    R["holonomy"] = rows


def check_triangle_flat():
    errs = []
    for _ in range(200):
        d = int(rng.integers(2, 5))
        Ov = {v: rand_orth(d) for v in range(3)}
        B = {e: rand_orth(d) for e in [(0, 1), (1, 2), (0, 2)]}
        Fv_e = {(v, e): B[e].T @ Ov[v] for e in B for v in e}       # F(v<=e) so that F(e<=f)F(v<=e) = F(v<=f)
        T = lambda a, b, e: Fv_e[(b, e)].T @ Fv_e[(a, e)]             # transport from a to b along e
        hol = T(2, 0, (0, 2)) @ T(1, 2, (1, 2)) @ T(0, 1, (0, 1))
        errs.append(np.abs(hol - np.eye(d)).max())
    R["triangle_flat_max_err"] = float(max(errs))


# ---------------------------------------------------------------- F. Harary balance
def check_harary():
    agree = total = 0
    for _ in range(600):
        n = 8; m = int(rng.integers(8, 15))
        E = random_connected_graph(n, m)
        s = rng.choice([-1.0, 1.0], len(E), p=[0.25, 0.75])
        S = graph_sheaf(n, E, [np.eye(1) for _ in E], [np.array([[x]]) for x in s], [1] * n, [1] * len(E))
        h0 = S.betti()[0]
        # balance: 2-colouring with eps_u = s_e eps_v along every edge
        eps = {0: 1.0}; ok = True; stack = [0]
        adj = defaultdict(list)
        for k, (u, v) in enumerate(E):
            adj[u].append((v, s[k])); adj[v].append((u, s[k]))
        while stack and ok:
            a = stack.pop()
            for b, sg in adj[a]:
                want = sg * eps[a]
                if b in eps:
                    ok &= eps[b] == want
                else:
                    eps[b] = want; stack.append(b)
        total += 1; agree += (h0 == 1) == ok
    R["harary"] = dict(graphs=total, agree=agree)


# ---------------------------------------------------------------- G. context sheaves: pairwise graph versus full nerve
def context_sheaf(contexts, full=True):
    idx = range(len(contexts))
    simp = [(i,) for i in idx]
    inter = lambda s: sorted(set.intersection(*[set(contexts[i]) for i in s]))
    for r in ([2, 3] if full else [2]):
        for s in itertools.combinations(idx, r):
            if inter(s):
                simp.append(s)
    dims = {s: len(inter(s)) for s in simp}
    maps = {}
    for t in simp:
        for f in faces(t):
            a, b = inter(f), inter(t)
            M = np.zeros((len(b), len(a)))
            for r_, j in enumerate(b):
                M[r_, a.index(j)] = 1.0
            maps[(f, t)] = M
    return CellSheaf(simp, dims, maps)


def check_contexts():
    rows, ok = [], True
    for trial in range(300):
        D = int(rng.integers(4, 8)); k = int(rng.integers(3, 7))
        ctx = [sorted(rng.choice(D, int(rng.integers(2, 4)), replace=False).tolist()) for _ in range(k)]
        covered = sorted(set(itertools.chain(*ctx)))
        nj = [sum(j in c for c in ctx) for j in covered]
        pred_h1 = sum((x - 1) * (x - 2) // 2 for x in nj)
        bp = context_sheaf(ctx, full=False).betti(1)
        bf = context_sheaf(ctx, full=True).betti(1)
        ok &= bp[0] == len(covered) and bp[1] == pred_h1 and bf[0] == len(covered) and bf[1] == 0
    ex = [[0, 1], [0, 2], [0, 3]]
    R["contexts"] = dict(trials=300, formula_holds=bool(ok),
                         example_pairwise=context_sheaf(ex, False).betti(1), example_full=context_sheaf(ex, True).betti(1),
                         cycle_example_pairwise=context_sheaf([[0, 1], [1, 2], [0, 2]], False).betti(1))


# ---------------------------------------------------------------- H. Cech data sheaf of two arcs on a circle
def check_two_arcs():
    # U0, U1 connected; U0 cap U1 has two components; constant coefficients R
    dims = {(0,): 1, (1,): 1, (0, 1): 2}
    maps = {((0,), (0, 1)): np.array([[1.0], [1.0]]), ((1,), (0, 1)): np.array([[1.0], [1.0]])}
    S = CellSheaf([(0,), (1,), (0, 1)], dims, maps)
    R["two_arcs"] = dict(betti=S.betti(), nerve_betti=CellSheaf([(0,), (1,), (0, 1)], {(0,): 1, (1,): 1, (0, 1): 1},
                                                               {((0,), (0, 1)): np.eye(1), ((1,), (0, 1)): np.eye(1)}).betti())


# ---------------------------------------------------------------- I. pullback along a simplicial map with a degenerate face
def check_pullback():
    # L = edge [a, b] with a = 0, b = 1; f: K -> L on the filled triangle, f(0) = 0, f(1) = f(2) = 1
    G = {"dims": {(0,): 2, (1,): 2, (0, 1): 3}}
    Ga, Gb = rng.standard_normal((3, 2)), rng.standard_normal((3, 2))
    Lsh = CellSheaf([(0,), (1,), (0, 1)], G["dims"], {((0,), (0, 1)): Ga, ((1,), (0, 1)): Gb})
    fmap = {0: 0, 1: 1, 2: 1}
    img = lambda s: tuple(sorted(set(fmap[v] for v in s)))
    K = closure([(0, 1, 2)])
    dims = {s: G["dims"][img(s)] for s in K}
    def gmap(a, b):
        if a == b:
            return np.eye(G["dims"][a])
        return {((0,), (0, 1)): Ga, ((1,), (0, 1)): Gb}[(a, b)]
    maps = {(s, t): gmap(img(s), img(t)) for t in K for s in faces(t)}
    Ksh = CellSheaf(K, dims, maps)
    def fsharp(k):
        rows, nr = Ksh.offsets(k); cols, nc = Lsh.offsets(k)
        M = np.zeros((nr, nc))
        for s in Ksh.cells(k):
            t = img(s)
            if len(t) == len(s):
                sign = 1.0  # f preserves the vertex order here
                M[rows[s]:rows[s] + dims[s], cols[t]:cols[t] + G["dims"][t]] = sign * np.eye(dims[s])
        return M
    e0 = np.abs(Ksh.delta(0) @ fsharp(0) - fsharp(1) @ Lsh.delta(0)).max()
    e1 = np.abs(Ksh.delta(1) @ fsharp(1)).max()     # L has no 2-simplices, so f# delta = 0 in degree 1
    compat = np.abs(Ksh.delta(1) @ Ksh.delta(0)).max()
    R["pullback"] = dict(commute_deg0=float(e0), commute_deg1=float(e1), pulled_back_compatible=float(compat))


# ---------------------------------------------------------------- J, K. barcodes from the rank invariant
def barcode(dims, maps):
    """dims[0..n-1] bottom to top; maps[i]: V_i -> V_{i+1}. Returns {(b, d): multiplicity}, 1-based."""
    n = len(dims)
    def r(i, j):
        if i < 1 or j > n or i > j:
            return 0
        if i == j:
            return dims[i - 1]
        M = np.eye(dims[i - 1])
        for k in range(i - 1, j - 1):
            M = maps[k] @ M
        return rank(M)
    bars = {}
    for i in range(1, n + 1):
        for j in range(i, n + 1):
            mult = r(i, j) - r(i - 1, j) - r(i, j + 1) + r(i - 1, j + 1)
            if mult:
                bars[(i, j)] = mult
    return bars, r


def check_barcodes():
    nonneg = recon = True
    for _ in range(1500):
        n = int(rng.integers(3, 7))
        dims = [int(rng.integers(1, 5)) for _ in range(n)]
        maps = []
        for k in range(n - 1):
            rk = int(rng.integers(0, min(dims[k], dims[k + 1]) + 1))
            maps.append(rng.standard_normal((dims[k + 1], rk)) @ rng.standard_normal((rk, dims[k])))
        bars, r = barcode(dims, maps)
        nonneg &= all(v > 0 for v in bars.values())
        for i in range(1, n + 1):
            for j in range(i, n + 1):
                recon &= sum(v for (b, d), v in bars.items() if b <= i and d >= j) == r(i, j)
    # births at the top: invertible maps below, rank-r top map
    Dd, n, rtop = 4, 5, 2
    maps = [rng.standard_normal((Dd, Dd)) for _ in range(n - 2)]
    maps.append(rng.standard_normal((Dd, rtop)) @ rng.standard_normal((rtop, Dd)))
    bars, _ = barcode([Dd] * n, maps)
    R["barcodes"] = dict(random_chains=1500, multiplicities_nonnegative=bool(nonneg), ranks_reconstructed=bool(recon),
                         top_example={f"[{b},{d}]": v for (b, d), v in sorted(bars.items())})


# ---------------------------------------------------------------- L. exact versus effective rank of a tangent chain
def check_tangent_chain():
    T = 16
    a = [math.cos(math.pi * t / (2 * T)) ** 2 for t in range(T)]
    scale = lambda x: math.sqrt((1 - x) / x)
    centres = np.array([[0.0, 0.0], [2.5, 0.0], [1.2, 2.2]])
    Y = np.concatenate([c + 0.35 * rng.standard_normal((10, 2)) for c in centres])
    out, sv_paths = [], []
    for tok in range(1000):
        z = rng.standard_normal(2) / math.sqrt(a[T - 1])
        Mc = np.eye(2); svs = []
        for t in range(T - 1, 0, -1):
            st = scale(a[t]); sp = scale(a[t - 1]) if t > 1 else 0.0
            lam = 1 - sp / st
            l = -((z - Y) ** 2).sum(1) / (2 * st * st); al = np.exp(l - l.max()); al /= al.sum()
            m = al @ Y; C = (al[:, None] * Y).T @ Y - np.outer(m, m)
            J = (1 - lam) * np.eye(2) + lam / st ** 2 * C
            Mc = J @ Mc; svs.append(np.linalg.svd(Mc, compute_uv=False))
            z = (1 - lam) * z + lam * m
        s = svs[-1]
        out.append((rank(Mc, 1e-14), int((s > 1e-3).sum()), int((s > 1e-2).sum()), s[0], s[1]))
        if tok < 200:
            sv_paths.append(np.array(svs))
    ex = np.array([o[0] for o in out]); e3 = np.array([o[1] for o in out]); e2 = np.array([o[2] for o in out])
    med = np.median(np.array(sv_paths), axis=0)      # median singular values of the composite, layer by layer
    R["tangent"] = dict(tokens=len(out), exact_full_rank=float(np.mean(ex == 2)),
                        effective_rank_1e3={str(k): float(np.mean(e3 == k)) for k in [0, 1, 2]},
                        effective_rank_1e2={str(k): float(np.mean(e2 == k)) for k in [0, 1, 2]},
                        median_smin=float(np.median([o[4] for o in out])), median_smax=float(np.median([o[3] for o in out])),
                        median_path_layers=list(range(T - 2, -1, -1)), median_path=med.tolist())


# ---------------------------------------------------------------- M. stability of H0 under perturbation
def components(Y, thr):
    n = len(Y); parent = list(range(n))
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]; x = parent[x]
        return x
    for i in range(n):
        for j in range(i + 1, n):
            if np.linalg.norm(Y[i] - Y[j]) <= thr:
                parent[find(i)] = find(j)
    return len({find(i) for i in range(n)})


def check_stability():
    viol = cases = 0
    for _ in range(80):
        Y = rng.uniform(0, 10, (40, 2)); eps = float(rng.uniform(0.02, 0.4))
        dirs = rng.standard_normal((40, 2)); dirs /= np.linalg.norm(dirs, axis=1)[:, None]
        Yp = Y + dirs * rng.uniform(0, eps, (40, 1))
        for r_ in np.linspace(0.3, 4.0, 15):
            lo = components(Y, r_ + 2 * eps); mid = components(Yp, r_); hi = components(Y, max(r_ - 2 * eps, 0.0))
            cases += 1; viol += not (lo <= mid <= hi)
    R["stability"] = dict(cases=cases, violations=viol)


# ---------------------------------------------------------------- N. vertical acyclicity via derived limits
class PosetFunctor:
    def __init__(self, elems, leq, dims, mapfn):
        self.elems, self.leq, self.dims, self.mapfn = elems, leq, dims, mapfn

    def derived_limits(self, kmax=3):
        E = self.elems
        chains = {0: [(p,) for p in E]}
        for n in range(1, kmax + 2):
            chains[n] = [c + (q,) for c in chains[n - 1] for q in E if q != c[-1] and self.leq(c[-1], q)]
        def off(n):
            o, d = {}, 0
            for c in chains[n]:
                o[c] = d; d += self.dims(c[-1])
            return o, d
        def dmat(n):
            ro, nr = off(n + 1); co, nc = off(n)
            M = np.zeros((nr, nc))
            for c in chains[n + 1]:
                r0, dr = ro[c], self.dims(c[-1])
                for k in range(n + 1):                   # delete an element that is not the last
                    f = c[:k] + c[k + 1:]
                    M[r0:r0 + dr, co[f]:co[f] + self.dims(f[-1])] += (-1) ** k * np.eye(dr)
                f = c[:-1]                               # delete the last element, then push forward
                M[r0:r0 + dr, co[f]:co[f] + self.dims(f[-1])] += (-1) ** (n + 1) * self.mapfn(f[-1], c[-1])
            return M, nr, nc
        out = []
        mats = [dmat(n) for n in range(kmax + 1)]
        for n in range(kmax + 1):
            M, nr, nc = mats[n]
            prev_rank = rank(mats[n - 1][0]) if n > 0 else 0
            out.append(nc - rank(M) - prev_rank)
        return out


def face_poset_functor(S):
    elems = S.simplices
    leq = lambda s, t: set(s) <= set(t)
    def mapfn(s, t):
        M = np.eye(S.dims[s]); cur = s
        # compose codim-1 restriction maps along any maximal chain s < ... < t (compatibility makes it unique)
        rest = [v for v in t if v not in s]
        for v in rest:
            nxt = tuple(sorted(cur + (v,)))
            M = S.maps[(cur, nxt)] @ M; cur = nxt
        return M
    return elems, leq, (lambda s: S.dims[s]), mapfn


def check_vertical_acyclicity():
    hollow = [(0,), (1,), (2,), (0, 1), (1, 2), (0, 2)]
    def const(dim, sign_edge=None, sign=-1.0):
        dims = {s: dim for s in hollow}
        maps = {}
        for e in [(0, 1), (1, 2), (0, 2)]:
            for v in faces(e):
                maps[(v, e)] = np.eye(dim) * (sign if (e == sign_edge and v == (e[1],)) else 1.0)
        return CellSheaf(hollow, dims, maps)
    rows = []
    # sanity: derived limits over the face poset equal cellular cohomology
    for name, S in [("constant", const(1)), ("twisted", const(1, (0, 2)))]:
        el, leq, dm, mp = face_poset_functor(S)
        rows.append(dict(case=f"face poset, {name}", derived=PosetFunctor(el, leq, dm, mp).derived_limits(2), cellular=S.betti()))
    filled = closure([(0, 1, 2)])
    Sf = CellSheaf(filled, {s: 1 for s in filled}, {(f, t): np.eye(1) for t in filled for f in faces(t)})
    el, leq, dm, mp = face_poset_functor(Sf)
    rows.append(dict(case="face poset, filled triangle", derived=PosetFunctor(el, leq, dm, mp).derived_limits(2), cellular=Sf.betti()))

    def product(layers, vert):
        """layers[h]: CellSheaf on the hollow triangle (h = 0 bottom); vert[h]: dict simplex -> matrix F_h -> F_{h+1}."""
        H = len(layers)
        elems = [(s, h) for h in range(H) for s in hollow]
        leq = lambda x, y: set(x[0]) <= set(y[0]) and x[1] <= y[1]
        dims = lambda x: layers[x[1]].dims[x[0]]
        def mapfn(x, y):
            (s, h), (t, h2) = x, y
            _, _, _, mp = face_poset_functor(layers[h])
            M = mp(s, t)
            for k in range(h, h2):
                M = vert[k][t] @ M
            return M
        return PosetFunctor(elems, leq, dims, mapfn)

    # E1: constant R^2 at three layers, random vertical matrices (natural because restrictions are identities)
    L1 = [const(2) for _ in range(3)]
    V1 = [{s: rng.standard_normal((2, 2)) for s in hollow} for _ in range(2)]
    for k in range(2):
        A = rng.standard_normal((2, 2)); V1[k] = {s: A for s in hollow}
    # E2: twisted bottom, constant above, zero vertical maps
    L2 = [const(1, (0, 2)), const(1), const(1)]
    V2 = [{s: np.zeros((1, 1)) for s in hollow} for _ in range(2)]
    # E3: constant bottom, twisted above, zero vertical maps
    L3 = [const(1), const(1, (0, 2)), const(1, (0, 2))]
    # E4: twisted at every layer with scalar vertical maps
    L4 = [const(1, (0, 2)) for _ in range(3)]
    V4 = [{s: np.array([[c]]) for s in hollow} for c in rng.uniform(0.5, 2, 2)]
    for name, Ls, Vs in [("constant R^2, random vertical maps", L1, V1), ("twisted bottom, constant above", L2, V2),
                         ("constant bottom, twisted above", L3, V2), ("twisted, scalar vertical maps", L4, V4)]:
        rows.append(dict(case=f"product, {name}", derived=product(Ls, Vs).derived_limits(3), bottom_cellular=Ls[0].betti(1)))
    R["vertical_acyclicity"] = rows


# ---------------------------------------------------------------- P. affine chains and homogenisation
def check_affine():
    errs = []
    for _ in range(200):
        D, T = 3, 8
        A = [rng.standard_normal((D, D)) * 0.5 for _ in range(T)]
        b = [rng.standard_normal(D) for _ in range(T)]
        zT = rng.standard_normal(D)
        z = zT.copy()
        for t in range(T - 1, -1, -1):
            z = A[t] @ z + b[t]
        P = np.eye(D); pred = np.zeros(D)
        for t in range(T):                       # z_0 = A_0 ... A_{T-1} z_T + sum_t A_0 ... A_{t-1} b_t
            pred += P @ b[t]; P = P @ A[t]
        pred += P @ zT
        Hm = np.eye(D + 1)
        for t in range(T):
            Ht = np.eye(D + 1); Ht[:D, :D] = A[t]; Ht[:D, D] = b[t]
            Hm = Hm @ Ht
        hom = (Hm @ np.append(zT, 1.0))[:D]
        errs.append(max(np.abs(pred - z).max(), np.abs(hom - z).max()))
    R["affine_max_err"] = float(max(errs))


# ---------------------------------------------------------------- Q. the three obstructions
def check_obstructions():
    tri = [(0,), (1,), (2,), (0, 1), (1, 2), (0, 2)]
    const = CellSheaf(tri, {s: 1 for s in tri}, {(v, e): np.eye(1) for e in tri if len(e) == 2 for v in faces(e)})
    D0 = const.delta(0)
    c = np.array([0.0, 0.0, -2 * math.pi])          # edge order (01, 02, 12) as sorted; the 2pi sits on edge 02
    order = const.cells(1)
    c = np.zeros(3); c[order.index((0, 2))] = -2 * math.pi
    x = np.linalg.lstsq(D0, c, rcond=None)[0]
    resid = float(np.linalg.norm(D0 @ x - c))
    v = [np.array([math.cos(k * math.pi / 3), math.sin(k * math.pi / 3)]) for k in range(3)]
    signs = {(0, 1): np.sign(v[0] @ v[1]), (1, 2): np.sign(v[1] @ v[2]), (0, 2): np.sign(v[0] @ v[2])}
    tw = CellSheaf(tri, {s: 1 for s in tri}, {(v_, e): (np.eye(1) if v_ == (e[0],) else np.eye(1) * signs[e])
                                               for e in signs for v_ in faces(e)})
    R["obstructions"] = dict(angle_residual=resid, angle_residual_formula=2 * math.pi / math.sqrt(3),
                             constant_betti=const.betti(), twisted_betti=tw.betti(),
                             holonomy=float(signs[(0, 1)] * signs[(1, 2)] * signs[(0, 2)]))


if __name__ == "__main__":
    for fn in [check_delta_squared, check_hodge_residual, check_holonomy, check_triangle_flat, check_harary, check_contexts,
               check_two_arcs, check_pullback, check_barcodes, check_tangent_chain, check_stability,
               check_vertical_acyclicity, check_affine, check_obstructions]:
        fn(); print("done", fn.__name__, flush=True)
    with open(sys.argv[1] if len(sys.argv) > 1 else "p1_checks.json", "w") as fh:
        json.dump(R, fh, indent=1, default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o))
    print(json.dumps({k: v for k, v in R.items() if k != "tangent"}, indent=1, default=str))
    print(json.dumps({k: v for k, v in R["tangent"].items() if k not in ("median_path",)}, indent=1))
