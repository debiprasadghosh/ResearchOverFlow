# Build the pandoc reference document: A4, Cambria, navy headings, boxed statements, tables, header and page numbers.
import sys
from docx import Document
from docx.shared import Pt, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

SRC, OUT, HEADER = sys.argv[1], sys.argv[2], sys.argv[3]
NAVY, ACCENT, GREY, INK = "1C3F6E", "2A78D6", "52514E", "222222"
doc = Document(SRC)
TW = 635  # EMU per twip

for s in doc.sections:
    s.page_width, s.page_height = Emu(11906 * TW), Emu(16838 * TW)
    s.left_margin = s.right_margin = Emu(1300 * TW)
    s.top_margin, s.bottom_margin = Emu(1250 * TW), Emu(1250 * TW)
    s.header_distance = s.footer_distance = Emu(600 * TW)

styles = doc.styles


def get(name, kind=WD_STYLE_TYPE.PARAGRAPH, base=None):
    try:
        return styles[name]
    except KeyError:
        st = styles.add_style(name, kind)
        if base:
            st.base_style = styles[base]
        return st


def fonts(st, name="Cambria", size=None, bold=None, italic=None, color=None):
    f = st.font
    f.name = name
    rpr = st.element.get_or_add_rPr()
    rf = rpr.find(qn("w:rFonts"))
    if rf is None:
        rf = OxmlElement("w:rFonts"); rpr.insert(0, rf)
    for a in ["w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"]:
        rf.set(qn(a), name)
    for a in ["w:asciiTheme", "w:hAnsiTheme", "w:cstheme", "w:eastAsiaTheme"]:
        if rf.get(qn(a)) is not None:
            del rf.attrib[qn(a)]
    if size: f.size = Pt(size)
    if bold is not None: f.bold = bold
    if italic is not None: f.italic = italic
    if color: f.color.rgb = RGBColor.from_string(color)


def para(st, align=None, before=None, after=None, line=None, keep_next=None, left=None, right=None, keep_lines=None):
    pf = st.paragraph_format
    if align is not None: pf.alignment = align
    if before is not None: pf.space_before = Pt(before)
    if after is not None: pf.space_after = Pt(after)
    if line is not None: pf.line_spacing = line
    if keep_next is not None: pf.keep_with_next = keep_next
    if keep_lines is not None: pf.keep_together = keep_lines
    if left is not None: pf.left_indent = Emu(int(left * TW))
    if right is not None: pf.right_indent = Emu(int(right * TW))


def shade_border(st, fill, top=None, bottom=None, left=None, right=None, space=4):
    ppr = st.element.get_or_add_pPr()
    for tag in ["w:pBdr", "w:shd"]:
        old = ppr.find(qn(tag))
        if old is not None:
            ppr.remove(old)
    bdr = OxmlElement("w:pBdr")
    for side, spec in [("top", top), ("left", left), ("bottom", bottom), ("right", right)]:
        if spec:
            el = OxmlElement(f"w:{side}")
            el.set(qn("w:val"), "single"); el.set(qn("w:sz"), str(spec[0])); el.set(qn("w:space"), str(space))
            el.set(qn("w:color"), spec[1]); bdr.append(el)
    ppr.append(bdr)
    shd = OxmlElement("w:shd"); shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), fill)
    ppr.append(shd)


J = WD_ALIGN_PARAGRAPH.JUSTIFY
fonts(styles["Normal"], size=11, color=INK)
for name in ["Body Text", "First Paragraph"]:
    st = get(name); fonts(st, size=11); para(st, align=J, before=0, after=6, line=1.12)
st = get("Compact"); fonts(st, size=11); para(st, align=J, before=0, after=3, line=1.1)
st = get("Title"); fonts(st, size=20, bold=True, color=NAVY); para(st, align=WD_ALIGN_PARAGRAPH.CENTER, before=6, after=8, line=1.0)
st = get("Subtitle"); fonts(st, size=12.5, italic=True, color=GREY, bold=False); para(st, align=WD_ALIGN_PARAGRAPH.CENTER, before=0, after=14, line=1.05)
st = get("Author"); fonts(st, size=11.5, color=INK); para(st, align=WD_ALIGN_PARAGRAPH.CENTER, before=0, after=2, line=1.0)
st = get("Date"); fonts(st, size=10, italic=True, color=GREY); para(st, align=WD_ALIGN_PARAGRAPH.CENTER, before=0, after=12, line=1.0)
st = get("Abstract Title"); fonts(st, size=11, bold=True, color=NAVY); para(st, align=WD_ALIGN_PARAGRAPH.LEFT, before=6, after=4, keep_next=True, left=300, right=300)
st = get("Abstract"); fonts(st, size=10, color=INK); para(st, align=J, before=0, after=5, line=1.08, left=300, right=300)
for lvl, size, before, after, ital in [(1, 14, 16, 7, False), (2, 12, 12, 5, False), (3, 11, 9, 4, True)]:
    st = get(f"Heading {lvl}"); fonts(st, size=size, bold=True, italic=ital, color=NAVY)
    para(st, align=WD_ALIGN_PARAGRAPH.LEFT, before=before, after=after, keep_next=True, line=1.0)
    rpr = st.element.get_or_add_rPr()
    for t in ["w:color"]:
        pass
st = get("Block Text"); fonts(st, size=10.5, italic=True, color=INK); para(st, align=J, before=2, after=8, left=400, right=400)
for name in ["Caption", "Table Caption", "Image Caption"]:
    st = get(name); fonts(st, size=9.5, italic=False, color=INK); para(st, align=J, before=3, after=10, line=1.05)
get("Table Caption").paragraph_format.keep_with_next = True
st = get("Figure"); para(st, align=WD_ALIGN_PARAGRAPH.CENTER, before=6, after=2, keep_next=True)
st = get("Captioned Figure"); para(st, align=WD_ALIGN_PARAGRAPH.CENTER, before=6, after=2, keep_next=True)
st = get("Bibliography"); fonts(st, size=9.5); para(st, align=WD_ALIGN_PARAGRAPH.LEFT, before=0, after=3, line=1.05, left=440)
st.paragraph_format.first_line_indent = Emu(-440 * TW)

# code
st = get("Source Code", base="Normal"); fonts(st, name="Consolas", size=7.5, color="1E1E1E")
para(st, align=WD_ALIGN_PARAGRAPH.LEFT, before=2, after=8, line=1.0, keep_lines=False)
shade_border(st, "F6F6F4")
st = get("Verbatim Char", WD_STYLE_TYPE.CHARACTER); fonts(st, name="Consolas", size=9)

# statements: shaded box with blue rules above and below
st = get("Statement", base="Body Text"); fonts(st, size=10.5)
para(st, align=WD_ALIGN_PARAGRAPH.LEFT, before=0, after=4, line=1.1, left=120, right=120, keep_next=True)
shade_border(st, "F3F6FB", top=(8, ACCENT), bottom=(8, ACCENT), space=5)
st = get("Statement Tag", base="Statement"); fonts(st, size=8.5, italic=True, color=GREY)
para(st, align=WD_ALIGN_PARAGRAPH.RIGHT, before=0, after=2, keep_next=False)
shade_border(st, "F3F6FB", top=(8, ACCENT), bottom=(8, ACCENT), space=5)
st = get("Gap", base="Normal"); fonts(st, size=2); para(st, before=0, after=0, line=1.0)
st = get("Check", base="Body Text"); fonts(st, size=9.5, color="333333"); para(st, align=J, before=0, after=7, line=1.08)
st = get("Summary", base="Body Text"); fonts(st, size=10.5)
para(st, align=J, before=0, after=4, line=1.1, left=120, right=120)
shade_border(st, "EEF3FB", top=(8, ACCENT), bottom=(8, ACCENT), space=5)


# display equations: centred maths with a right-aligned number (tabs are inserted by postprocess.py)
def tabs(st, stops):
    ppr = st.element.get_or_add_pPr()
    old = ppr.find(qn("w:tabs"))
    if old is not None:
        ppr.remove(old)
    t = OxmlElement("w:tabs")
    for kind, pos in stops:
        el = OxmlElement("w:tab"); el.set(qn("w:val"), kind); el.set(qn("w:pos"), str(pos)); t.append(el)
    ppr.append(t)

W = 11906 - 2 * 1300
st = get("Equation", base="Body Text"); fonts(st, size=11)
para(st, align=WD_ALIGN_PARAGRAPH.LEFT, before=4, after=8, line=1.0, keep_lines=True)
tabs(st, [("center", W // 2), ("right", W)])
st = get("Statement Equation", base="Statement"); fonts(st, size=10.5)
para(st, align=WD_ALIGN_PARAGRAPH.LEFT, before=2, after=6, line=1.0, keep_lines=True, keep_next=True)
shade_border(st, "F3F6FB", top=(8, ACCENT), bottom=(8, ACCENT), space=5)
tabs(st, [("center", W // 2), ("right", W - 240)])

# table style: thin grey grid, shaded bold header row
tst = styles["Table"]
tblPr = tst.element.find(qn("w:tblPr"))
if tblPr is None:
    tblPr = OxmlElement("w:tblPr"); tst.element.append(tblPr)
for old in tblPr.findall(qn("w:tblBorders")):
    tblPr.remove(old)
b = OxmlElement("w:tblBorders")
for side in ["top", "left", "bottom", "right", "insideH", "insideV"]:
    el = OxmlElement(f"w:{side}"); el.set(qn("w:val"), "single"); el.set(qn("w:sz"), "4"); el.set(qn("w:space"), "0")
    el.set(qn("w:color"), "BFBFBF"); b.append(el)
tblPr.append(b)
for old in tblPr.findall(qn("w:tblCellMar")):
    tblPr.remove(old)
mar = OxmlElement("w:tblCellMar")
for side, v in [("top", 40), ("left", 90), ("bottom", 40), ("right", 90)]:
    el = OxmlElement(f"w:{side}"); el.set(qn("w:w"), str(v)); el.set(qn("w:type"), "dxa"); mar.append(el)
tblPr.append(mar)
rpr = tst.element.get_or_add_rPr()
sz = OxmlElement("w:sz"); sz.set(qn("w:val"), "19"); rpr.append(sz)
for old in tst.element.findall(qn("w:tblStylePr")):
    tst.element.remove(old)
fr = OxmlElement("w:tblStylePr"); fr.set(qn("w:type"), "firstRow")
frp = OxmlElement("w:rPr"); bb = OxmlElement("w:b"); frp.append(bb); fr.append(frp)
tcp = OxmlElement("w:tcPr"); shd = OxmlElement("w:shd"); shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), "E8EEF7")
tcp.append(shd); fr.append(tcp)
tst.element.append(fr)

# header and footer
sec = doc.sections[0]
hp = sec.header.paragraphs[0] if sec.header.paragraphs else sec.header.add_paragraph()
hp.text = ""
r = hp.add_run(HEADER); r.italic = True; r.font.size = Pt(8.5); r.font.color.rgb = RGBColor.from_string(GREY); r.font.name = "Cambria"
hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
fp = sec.footer.paragraphs[0] if sec.footer.paragraphs else sec.footer.add_paragraph()
fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
fld = OxmlElement("w:fldSimple"); fld.set(qn("w:instr"), "PAGE")
rr = OxmlElement("w:r"); rp = OxmlElement("w:rPr"); s9 = OxmlElement("w:sz"); s9.set(qn("w:val"), "19"); rp.append(s9); rr.append(rp)
tt = OxmlElement("w:t"); tt.text = "1"; rr.append(tt); fld.append(rr); fp._p.append(fld)
doc.save(OUT)
print("reference written", OUT)
