// Validation run of the Part I kernel; p1_cs_validate.py recomputes every printed number with NumPy.
using System;
using System.Collections.Immutable;
using System.Linq;
using AsePartOne;

static Matrix S(double x) => Matrix.Of(1, 1, x);
static GraphSheaf Signed(params (int U, int V, double Sign)[] edges) =>
    new(ImmutableArray.Create(1, 1, 1), ImmutableArray.CreateRange(edges.Select(e => new Edge(e.U, e.V, S(1.0), S(e.Sign)))));

var constant = Signed((0, 1, 1.0), (1, 2, 1.0), (0, 2, 1.0));
var twisted = Signed((0, 1, 1.0), (1, 2, 1.0), (0, 2, -1.0));
static double Dot(double a, double b) => Math.Cos(a) * Math.Cos(b) + Math.Sin(a) * Math.Sin(b);
double[] lines = { 0.0, Math.PI / 3, 2 * Math.PI / 3 };
var threeLines = Signed((0, 1, Math.Sign(Dot(lines[0], lines[1]))), (1, 2, Math.Sign(Dot(lines[1], lines[2]))),
                        (0, 2, Math.Sign(Dot(lines[0], lines[2]))));

// Coordinate sheaf of the contexts {1,2}, {1,3}, {1,4} on its pairwise graph (shared coordinate 1).
var pick = Matrix.Of(1, 2, 1.0, 0.0);
var contexts = new GraphSheaf(ImmutableArray.Create(2, 2, 2),
    ImmutableArray.Create(new Edge(0, 1, pick, pick), new Edge(1, 2, pick, pick), new Edge(0, 2, pick, pick)));

// Orthogonal sheaf on a 4-cycle whose holonomy is a reflection: the fixed subspace is one-dimensional.
var I2 = Matrix.Identity(2);
var reflection = Matrix.Of(2, 2, 1.0, 0.0, 0.0, -1.0);
var cycle = new GraphSheaf(ImmutableArray.Create(2, 2, 2, 2),
    ImmutableArray.Create(new Edge(0, 1, I2, I2), new Edge(1, 2, I2, I2), new Edge(2, 3, I2, I2), new Edge(0, 3, I2, reflection)));

foreach (var (name, sheaf) in new[] { ("constant", constant), ("twisted", twisted), ("three_lines", threeLines),
                                       ("contexts", contexts), ("reflection_cycle", cycle) })
{
    var (h0, h1) = sheaf.Cohomology();
    Console.WriteLine($"{name} {h0} {h1}");
}

// Births at a clean top: invertible maps below, a rank-one top map (dimension 3, four positions).
var a = Matrix.Of(3, 3, 2, 1, 0, 0, 1, 1, 1, 0, 3);
var b = Matrix.Of(3, 3, 1, 0, 2, 0, 3, 0, 1, 1, 1);
var top = Matrix.Of(3, 1, 1, 2, 3).Times(Matrix.Of(1, 3, 1, -1, 2));
foreach (var bar in Barcodes.FromChain(ImmutableArray.Create(3, 3, 3, 3), ImmutableArray.Create(a, b, top)))
    Console.WriteLine($"bar {bar.Birth} {bar.Death} {bar.Multiplicity}");

// A chain with dimensions 2, 3, 2, 2 and maps of ranks 2, 1, 1.
var m1 = Matrix.Of(3, 2, 1, 0, 0, 1, 1, 1);
var m2 = Matrix.Of(2, 3, 1, 1, 2, 2, 2, 4);
var m3 = Matrix.Of(2, 2, 0, 1, 0, 1);
foreach (var bar in Barcodes.FromChain(ImmutableArray.Create(2, 3, 2, 2), ImmutableArray.Create(m1, m2, m3)))
    Console.WriteLine($"chain {bar.Birth} {bar.Death} {bar.Multiplicity}");
