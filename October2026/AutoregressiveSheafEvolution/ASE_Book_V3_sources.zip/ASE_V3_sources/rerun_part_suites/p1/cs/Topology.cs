// ASE Part I reference kernel: graph data sheaves and barcodes of chains.
// Immutable values and pure functions; Rank works on a private copy.
using System;
using System.Collections.Immutable;
using System.Linq;

namespace AsePartOne;

/// <summary>A dense real matrix stored row-major.</summary>
public sealed record Matrix(int Rows, int Cols, ImmutableArray<double> Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Matrix Of(int rows, int cols, params double[] data) =>
        new(rows, cols, ImmutableArray.Create(data));

    public static Matrix Identity(int n) =>
        new(n, n, Enumerable.Range(0, n * n)
            .Select(k => k / n == k % n ? 1.0 : 0.0).ToImmutableArray());

    public Matrix Times(Matrix b) =>
        new(Rows, b.Cols, Enumerable.Range(0, Rows * b.Cols)
            .Select(k => Enumerable.Range(0, Cols)
                .Sum(j => this[k / b.Cols, j] * b[j, k % b.Cols]))
            .ToImmutableArray());

    /// <summary>Rank by Gaussian elimination, relative tolerance.</summary>
    public int Rank(double relTol = 1e-10)
    {
        var a = Data.ToArray();
        double scale = Math.Max(1.0, a.Select(Math.Abs).DefaultIfEmpty(0).Max());
        int rank = 0;
        for (int c = 0; c < Cols && rank < Rows; c++)
        {
            int p = Enumerable.Range(rank, Rows - rank)
                .OrderByDescending(r => Math.Abs(a[r * Cols + c])).First();
            if (Math.Abs(a[p * Cols + c]) <= relTol * scale) continue;
            for (int j = 0; j < Cols; j++)
                (a[p * Cols + j], a[rank * Cols + j]) =
                    (a[rank * Cols + j], a[p * Cols + j]);
            for (int r = rank + 1; r < Rows; r++)
            {
                double f = a[r * Cols + c] / a[rank * Cols + c];
                for (int j = c; j < Cols; j++)
                    a[r * Cols + j] -= f * a[rank * Cols + j];
            }
            rank++;
        }
        return rank;
    }
}

/// <summary>An oriented edge U -> V with restrictions from both stalks.</summary>
public sealed record Edge(int U, int V, Matrix FromU, Matrix FromV)
{
    public int Dim => FromU.Rows;
}

/// <summary>A data sheaf on a graph: vertex stalk dimensions and edges.</summary>
public sealed record GraphSheaf(ImmutableArray<int> VertexDims,
                                ImmutableArray<Edge> Edges)
{
    /// <summary>(delta x)_e = FromV x_V - FromU x_U.</summary>
    public Matrix Coboundary()
    {
        var col = VertexDims.Select((_, i) => VertexDims.Take(i).Sum())
            .ToImmutableArray();
        var row = Edges.Select((_, k) => Edges.Take(k).Sum(f => f.Dim))
            .ToImmutableArray();
        int rows = Edges.Sum(e => e.Dim), cols = VertexDims.Sum();
        double Entry(int r, int c)
        {
            int k = row.LastIndexOf(row.Last(o => o <= r));
            var e = Edges[k];
            int i = r - row[k];
            double Block(int v, Matrix m, double sign) =>
                c >= col[v] && c < col[v] + VertexDims[v]
                    ? sign * m[i, c - col[v]] : 0.0;
            return Block(e.V, e.FromV, 1.0) + Block(e.U, e.FromU, -1.0);
        }
        return new Matrix(rows, cols, Enumerable.Range(0, rows * cols)
            .Select(k => Entry(k / cols, k % cols)).ToImmutableArray());
    }

    /// <summary>dim H0 and dim H1 from the rank of delta.</summary>
    public (int H0, int H1) Cohomology()
    {
        int r = Coboundary().Rank();
        return (VertexDims.Sum() - r, Edges.Sum(e => e.Dim) - r);
    }
}

/// <summary>An interval [Birth, Death], positions from the bottom (1).</summary>
public sealed record Bar(int Birth, int Death, int Multiplicity);

public static class Barcodes
{
    /// <summary>Bars of V_1 -> ... -> V_n from the rank invariant:
    /// m(i, j) = r(i, j) - r(i-1, j) - r(i, j+1) + r(i-1, j+1).</summary>
    public static ImmutableArray<Bar> FromChain(ImmutableArray<int> dims,
                                                ImmutableArray<Matrix> maps)
    {
        int n = dims.Length;
        Matrix Composite(int i, int j) => Enumerable.Range(i - 1, j - i)
            .Aggregate(Matrix.Identity(dims[i - 1]), (m, k) => maps[k].Times(m));
        int R(int i, int j) =>
            i < 1 || j > n || i > j ? 0
            : i == j ? dims[i - 1]
            : Composite(i, j).Rank();
        return (from i in Enumerable.Range(1, n)
                from j in Enumerable.Range(i, n - i + 1)
                let mult = R(i, j) - R(i - 1, j) - R(i, j + 1) + R(i - 1, j + 1)
                where mult != 0
                select new Bar(i, j, mult)).ToImmutableArray();
    }
}
