# Recompute every number printed by the C# kernel (cs/cs_out.txt) with an independent NumPy implementation.
import json, math, os, sys
import numpy as np

here = os.path.dirname(os.path.abspath(__file__))


def rank(M, tol=1e-10):
    if M.size == 0:
        return 0
    s = np.linalg.svd(M, compute_uv=False)
    return int((s > tol * max(1.0, s[0])).sum())


def cohomology(vdims, edges):
    """edges: (u, v, FromU, FromV); (delta x)_e = FromV x_v - FromU x_u."""
    off = np.concatenate([[0], np.cumsum(vdims)])
    rows = []
    for (u, v, Fu, Fv) in edges:
        blk = np.zeros((Fu.shape[0], off[-1]))
        blk[:, off[u]:off[u + 1]] -= Fu
        blk[:, off[v]:off[v + 1]] += Fv
        rows.append(blk)
    D = np.vstack(rows)
    r = rank(D)
    return off[-1] - r, D.shape[0] - r


def bars(dims, maps):
    n = len(dims)
    def r(i, j):
        if i < 1 or j > n or i > j:
            return 0
        M = np.eye(dims[i - 1])
        for k in range(i - 1, j - 1):
            M = maps[k] @ M
        return dims[i - 1] if i == j else rank(M)
    return [(i, j, r(i, j) - r(i - 1, j) - r(i, j + 1) + r(i - 1, j + 1))
            for i in range(1, n + 1) for j in range(i, n + 1) if r(i, j) - r(i - 1, j) - r(i, j + 1) + r(i - 1, j + 1)]


S = lambda x: np.array([[float(x)]])
signed = lambda sg: ([1, 1, 1], [(0, 1, S(1), S(sg[0])), (1, 2, S(1), S(sg[1])), (0, 2, S(1), S(sg[2]))])
ang = [0.0, math.pi / 3, 2 * math.pi / 3]
sgn = lambda a, b: float(np.sign(math.cos(a - b)))
pick = np.array([[1.0, 0.0]])
I2, Ref = np.eye(2), np.diag([1.0, -1.0])
cases = {
    "constant": signed([1, 1, 1]),
    "twisted": signed([1, 1, -1]),
    "three_lines": signed([sgn(ang[0], ang[1]), sgn(ang[1], ang[2]), sgn(ang[0], ang[2])]),
    "contexts": ([2, 2, 2], [(0, 1, pick, pick), (1, 2, pick, pick), (0, 2, pick, pick)]),
    "reflection_cycle": ([2, 2, 2, 2], [(0, 1, I2, I2), (1, 2, I2, I2), (2, 3, I2, I2), (0, 3, I2, Ref)]),
}
expected = [f"{name} {h0} {h1}" for name, (vd, ed) in cases.items() for (h0, h1) in [cohomology(vd, ed)]]
A = np.array([[2, 1, 0], [0, 1, 1], [1, 0, 3]], float)
B = np.array([[1, 0, 2], [0, 3, 0], [1, 1, 1]], float)
top = np.array([[1], [2], [3]], float) @ np.array([[1, -1, 2]], float)
expected += [f"bar {i} {j} {m}" for (i, j, m) in bars([3, 3, 3, 3], [A, B, top])]
m1 = np.array([[1, 0], [0, 1], [1, 1]], float)
m2 = np.array([[1, 1, 2], [2, 2, 4]], float)
m3 = np.array([[0, 1], [0, 1]], float)
expected += [f"chain {i} {j} {m}" for (i, j, m) in bars([2, 3, 2, 2], [m1, m2, m3])]

got = [ln.strip() for ln in open(os.path.join(here, "cs", "cs_out.txt")) if ln.strip()]
agree = sum(a == b for a, b in zip(got, expected)) if len(got) == len(expected) else 0
res = dict(lines=len(expected), agree=agree, csharp=got, python=expected)
json.dump(res, open(os.path.join(here, "cs_validate.json"), "w"), indent=1)
print(json.dumps(res, indent=1))
