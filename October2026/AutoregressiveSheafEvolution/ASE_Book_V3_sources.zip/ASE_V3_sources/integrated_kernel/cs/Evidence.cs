// Part VI of the integrated edition, and the repeated-run studies that its conjectures ask for:
// budget allocation, release bounds, the tail obstruction, confidence sequences and the
// coverage experiments for IV-C2, IV-C3 and V-C3.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AseBook;

public static class Evidence
{
    /// <summary>Optimal tolerances (3.6) and the model costs of three allocations.</summary>
    public static (Vec Eps, double Cost, double EqualContribution, double EqualLocal) Allocate(Vec g, Vec a, double p, double budget)
    {
        double den = g.Zip(a, (gi, ai) => Math.Pow(ai, 1 / (p + 1)) * Math.Pow(gi, p / (p + 1))).Sum();
        var eps = g.Zip(a, (gi, ai) => budget * Math.Pow(ai, 1 / (p + 1)) * Math.Pow(gi, -1 / (p + 1)) / den).ToImmutableArray();
        double Cost(Vec e) => a.Zip(e, (ai, ei) => ai * Math.Pow(ei, -p)).Sum();
        var eqc = g.Select(gi => budget / g.Length / gi).ToImmutableArray();
        double local = budget / g.Sum();
        return (eps, Cost(eps), Cost(eqc), Cost(g.Select(_ => local).ToImmutableArray()));
    }

    /// <summary>Robust release: upper bounds g + eta and the release decision (Proposition 7.2).</summary>
    public static (Vec Upper, bool Release) Release(Vec estimate, Vec error)
    {
        var up = estimate.Zip(error, (g, e) => g + e).ToImmutableArray();
        return (up, up.All(u => u <= 0));
    }

    /// <summary>Probability that n uniform draws all miss an interval of length eps (Theorem 5.2).</summary>
    public static double Identical(int n, double eps) => Math.Exp(n * double.LogP1(-eps));

    /// <summary>Radius (6.1) of the simultaneous confidence sequence.</summary>
    public static double CsRadius(double range, int m, int k, double delta) =>
        range * Math.Sqrt(Math.Log(2.0 * m * k * (k + 1.0) / delta) / (2.0 * k));

    /// <summary>Repeated confidence-sequence runs: m candidates with indicator differences against a
    /// common baseline indicator. Returns the share of runs with any miss, and for run 0 the first
    /// round at which each candidate's lower bound clears the margin (0 if never).</summary>
    public static (double MissRate, ImmutableArray<int> FirstClear, double FinalRadius, Rng Next) CsStudy(
        Rng rng, double p0, Vec effects, int rounds, int runs, double delta, double margin)
    {
        int m = effects.Length, misses = 0; var first = new int[m];
        for (int run = 0; run < runs; run++)
        {
            var sums = new double[m]; bool miss = false;
            for (int k = 1; k <= rounds; k++)
            {
                double u0; (u0, rng) = rng.Uniform(); double b0 = u0 < p0 ? 1 : 0;
                double r = CsRadius(2, m, k, delta);
                for (int j = 0; j < m; j++)
                {
                    double u; (u, rng) = rng.Uniform();
                    sums[j] += (u < p0 + effects[j] ? 1 : 0) - b0;
                    double mean = sums[j] / k;
                    if (Math.Abs(mean - effects[j]) > r) miss = true;
                    if (run == 0 && first[j] == 0 && mean - r > margin) first[j] = k;
                }
            }
            if (miss) misses++;
        }
        return (misses / (double)runs, first.ToImmutableArray(), CsRadius(2, m, rounds, delta), rng);
    }

    /// <summary>IV-C3: repeated runs of the predictable defensive proposal of Part IV, Section 11.2,
    /// checking the anytime certificate (9.2) at every prefix. Target pi = N(0, 1/2) from
    /// rho = N(0,1), J = x^2/2, beta = 1; f = 1{x &gt; 0.5}; defensive share 0.25.</summary>
    public static (double FailureRate, double MedianMaxRatio, double MeanFinalError, Rng Next) AdaptiveStudy(
        Rng rng, int runs, int draws, double delta)
    {
        double truth = 0.5 * SpecialErfc(0.5);
        const double eta = 0.25; int fails = 0; var ratios = new double[runs]; double errSum = 0;
        for (int run = 0; run < runs; run++)
        {
            double m = 0, sw = 0, swf = 0, worst = 0;
            for (int t = 1; t <= draws; t++)
            {
                double u, z; (u, rng) = rng.Uniform(); (z, rng) = rng.Normal();
                double x = u < eta ? z : m + 0.8 * z;
                double q = eta * Phi(x, 0, 1) + (1 - eta) * Phi(x, m, 0.8);
                double w = Phi(x, 0, 1) * Math.Exp(-x * x / 2) / q;
                sw += w; swf += x > 0.5 ? w : 0;
                double an = Math.Sqrt(Math.Log(2.0 * t * (t + 1.0) / delta) / (2.0 * t * eta * eta));
                double bound = Math.Min(1, an / (sw / t)), err = Math.Abs(swf / sw - truth);
                worst = Math.Max(worst, err / bound);
                m = 0.99 * m + 0.01 * Math.Tanh(x);
            }
            if (worst > 1) fails++;
            ratios[run] = worst; errSum += Math.Abs(swf / sw - truth);
        }
        var sorted = ratios.OrderBy(v => v).ToArray();
        return (fails / (double)runs, 0.5 * (sorted[(runs - 1) / 2] + sorted[runs / 2]), errSum / runs, rng);
    }

    /// <summary>IV-C2: known-variance correction (8.1) against the uncorrected heteroscedastic
    /// estimate, with the empirical and predicted (8.2) normalised second moments.</summary>
    public static (double Corrected, double Uncorrected, double EmpiricalM2, Rng Next) CriticStudy(
        Rng rng, int n, int k, double beta = 1)
    {
        double sw = 0, swx = 0, sw2 = 0, su = 0, sux = 0;
        for (int i = 0; i < n; i++)
        {
            double x; (x, rng) = rng.Normal();                  // proposal q = rho = N(0,1)
            double v = Math.Pow(0.5 + 0.5 * Math.Abs(x), 2), jbar = 0;
            for (int r = 0; r < k; r++) { double e; (e, rng) = rng.Normal(); jbar += x * x / 2 + Math.Sqrt(v) * e; }
            jbar /= k;
            double wc = Math.Exp(-beta * jbar - beta * beta * v / (2 * k)), wu = Math.Exp(-beta * jbar);
            sw += wc; swx += wc * x * x; sw2 += wc * wc; su += wu; sux += wu * x * x;
        }
        return (swx / sw, sux / su, n * sw2 / (sw * sw), rng);
    }

    /// <summary>Predicted normalised second moment (8.2) for the same model, by quadrature.</summary>
    public static double CriticM2(int k, double beta = 1)
    {
        double Z = 1 / Math.Sqrt(1 + beta);                   // integral of rho e^{-beta x^2/2}
        double Pi(double x) => Math.Exp(-(1 + beta) * x * x / 2) / Math.Sqrt(2 * Math.PI) / Z;
        double Q(double x) => Math.Exp(-x * x / 2) / Math.Sqrt(2 * Math.PI);
        return Quad.Simpson(x => Pi(x) * Pi(x) / Q(x) * Math.Exp(beta * beta * Math.Pow(0.5 + 0.5 * Math.Abs(x), 2) / k), -14, 14, 560000);
    }

    /// <summary>V-C3: coverage of the repaired Gaussian ellipse after fixed-weight covariance
    /// intersection of three jointly Gaussian unbiased estimators, against the same repair applied
    /// to a product of experts that ignores the correlation c.</summary>
    public static (double CiCoverage, double PoeCoverage, Rng Next) RepairStudy(Rng rng, Mat[] p, Mat c, double corr, int n, double q90)
    {
        int d = p[0].Rows, k = p.Length;
        var chol = p.Select(Chol).ToArray();
        var w = Enumerable.Repeat(1.0 / k, k).ToArray();
        var pw = p.Select((pk, i) => pk.Inverse().Scale(w[i])).Aggregate((x, y) => x.Add(y)).Inverse();
        var pp = p.Select(pk => pk.Inverse()).Aggregate((x, y) => x.Add(y)).Inverse();
        (Mat Gain, Mat T) Repair(Mat cov) {
            var t = Mat.Identity(d).Add(cov.Mul(c.T).Mul(c.Mul(cov).Mul(c.T).Inverse()).Mul(c), -1);
            return (t, t); }
        var nb = Lin.NullBasis(c);
        Mat Tangent(Mat cov) { var t = Repair(cov).T; var s = t.Mul(cov).Mul(t.T); return nb.T.Mul(s).Mul(nb).Inverse(); }
        var tCi = Repair(pw).T; var tPo = Repair(pp).T; var iCi = Tangent(pw); var iPo = Tangent(pp);
        int hitCi = 0, hitPo = 0;
        for (int it = 0; it < n; it++)
        {
            var g0 = new double[d];
            for (int j = 0; j < d; j++) (g0[j], rng) = rng.Normal();
            var errs = new Vec[k];
            for (int e = 0; e < k; e++)
            {
                var gi = new double[d];
                for (int j = 0; j < d; j++) { double z; (z, rng) = rng.Normal(); gi[j] = Math.Sqrt(corr) * g0[j] + Math.Sqrt(1 - corr) * z; }
                errs[e] = chol[e].Apply(gi.ToImmutableArray());
            }
            var eci = pw.Apply(Enumerable.Range(0, k).Select(e => p[e].Inverse().Scale(w[e]).Apply(errs[e]))
                .Aggregate((x, y) => Lin.AddV(x, y)));
            var epo = pp.Apply(Enumerable.Range(0, k).Select(e => p[e].Inverse().Apply(errs[e]))
                .Aggregate((x, y) => Lin.AddV(x, y)));
            var uci = nb.T.Apply(tCi.Apply(eci)); var upo = nb.T.Apply(tPo.Apply(epo));
            if (Lin.Dot(uci, iCi.Apply(uci)) <= q90) hitCi++;
            if (Lin.Dot(upo, iPo.Apply(upo)) <= q90) hitPo++;
        }
        return (hitCi / (double)n, hitPo / (double)n, rng);
    }

    public static Mat Chol(Mat a)
    {
        int n = a.Rows; var l = new double[n, n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j <= i; j++)
            {
                double s = a[i, j];
                for (int k = 0; k < j; k++) s -= l[i, k] * l[j, k];
                l[i, j] = i == j ? Math.Sqrt(s) : s / l[j, j];
            }
        return Mat.Of(n, n, (i, j) => l[i, j]);
    }

    static double Phi(double x, double m, double s) => Math.Exp(-(x - m) * (x - m) / (2 * s * s)) / (s * Math.Sqrt(2 * Math.PI));

    /// <summary>Complementary error function (W. J. Cody's rational approximation is not needed here:
    /// erfc(0.5) is evaluated by a convergent series to full double precision).</summary>
    public static double SpecialErfc(double x)
    {
        double sum = 0, term = x; int n = 0;
        while (Math.Abs(term) > 1e-18 * Math.Abs(sum) || n < 5)
        {
            sum += term / (2 * n + 1); n++; term *= -x * x / n;
        }
        return 1 - 2 / Math.Sqrt(Math.PI) * sum;
    }
}
