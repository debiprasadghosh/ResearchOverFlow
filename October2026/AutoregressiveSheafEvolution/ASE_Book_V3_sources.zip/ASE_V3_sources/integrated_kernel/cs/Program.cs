// Driver for the third-edition kernel. Every line is recomputed by validate.py with NumPy/SciPy,
// regenerating random inputs from the same SplitMix64 counters.
using System;
using System.Collections.Immutable;
using System.Globalization;
using System.Linq;
using AseBook;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

static string F(double x) => x.ToString("R", CultureInfo.InvariantCulture);
static void P(string name, params double[] xs) => Console.WriteLine(name + " " + string.Join(" ", xs.Select(F)));
static Vec V(params double[] x) => x.ToImmutableArray();

// ---------------- Part VI, Section 2.2: the extreme-logit defect and the input contract
var logits = V(-1e20, -1e20);
P("softmax_extreme_divfree", Softmax.DivisionFree(logits).ToArray());
P("softmax_extreme_shiftdivide", Softmax.ShiftDivide(logits).ToArray());
P("read_extreme", Reads.Barycentre(V(1, 3), logits, true), Reads.Barycentre(V(1, 3), logits, false));
var tiny = new Archive(ImmutableArray.Create(V(0.0, 0.0), V(1.0, 0.0), V(0.0, 1.0)), V(0, 0, 0));
int Rejects(Action a) { try { a(); return 0; } catch (ArgumentException) { return 1; } }
P("contract_rejections",
  Rejects(() => Reads.Read(V(0.2, 0.2), tiny, 0)), Rejects(() => Reads.Read(V(0.2, 0.2), tiny, -1)),
  Rejects(() => Reads.Read(V(0.2, 0.2), tiny, double.NaN)), Rejects(() => Reads.Read(V(0.2, 0.2, 0.2), tiny, 1)),
  Rejects(() => Reads.Read(V(double.PositiveInfinity, 0), tiny, 1)),
  Rejects(() => Reads.Read(V(0.2, 0.2), new Archive(ImmutableArray<Vec>.Empty, V()), 1)),
  Rejects(() => Reads.Read(V(0.2, 0.2), tiny, 1)));
P("certificate_k_equals_n", Reads.OmittedShare(V(0.2, 0.2), tiny, 0.5, 3), Reads.OmittedShare(V(0.2, 0.2), tiny, 0.5, 2));

// ---------------- Part IV reproductions
var (ep, ex, ind) = Estimation.PathExample(0.6, 0.8);
P("iv_path_m2", ep, ex, ind);
foreach (var r in new[] { 2.0, 4, 8, 12 })
    P($"iv_critical_R{r.ToString(CultureInfo.InvariantCulture)}",
      Estimation.CriticalIntegral(V(-1, 1), r), Estimation.CriticalIntegral(V(0), r));
P("iv_critical_closed", Math.E * Math.Sqrt(Math.PI) / 4);
foreach (var k in new[] { 2, 4, 8 })
    P($"iv_plugin_k{k}", Estimation.PlugInSecondMoment(k), Estimation.ResidualTilt(1, 1, k));
var tm = Estimation.Tempering(V(0.2, 0.5, 0.3), V(0, 1, 4), 0.8, 0.2);
P("iv_tempering", tm.M2, tm.M2Bound, tm.Tv, tm.TvBound);
var basis = Mat.FromRows(new[] { 1 / Math.Sqrt(2), 1 / Math.Sqrt(6) }, new[] { -1 / Math.Sqrt(2), 1 / Math.Sqrt(6) }, new[] { 0.0, -2 / Math.Sqrt(6) });
P("iv_gram", Estimation.GramFactor(basis.Mul(Mat.Diag(2, 3))));
var fr = Estimation.FamilyRadius(1, 0.25, 6, 13, 2, 0.05, 1600, 0.12786);
P("iv_family_radius", fr.Radius, fr.NeededN);
foreach (var b in new[] { 2.0, 8, 32, 128 })
{
    var c = Estimation.Concentration(b, 0.25, 0.125);
    P($"iv_concentration_b{b.ToString(CultureInfo.InvariantCulture)}", c.Tail, c.Bound);
}

// ---------------- Part V reproductions
var chain = Fusion.ChainExtension(V(0.35, 0.65), new[] {
    Mat.FromRows(new[] { 0.8, 0.2 }, new[] { 0.25, 0.75 }), Mat.FromRows(new[] { 0.6, 0.4 }, new[] { 0.1, 0.9 }),
    Mat.FromRows(new[] { 0.7, 0.3 }, new[] { 0.2, 0.8 }) });
P("v_chain_tv", chain.NaiveTv, chain.TreeTv);
var rep = Fusion.SymmetricRepair(5, -0.4);
P("v_repair", rep.MinEig, rep.Repaired, rep.Distance);
var cpen = Mat.FromRows(new[] { 1 / Math.Sqrt(2), 1 / Math.Sqrt(2), 0 });
foreach (var g in new[] { 1.0, 10, 100, 1000, 10000 })
{
    var pz = Fusion.PenaltyIsotropic(cpen, 0.3, V(1, 0, 0.4), g);
    P($"v_penalty_g{g.ToString(CultureInfo.InvariantCulture)}", pz.Mean, pz.W2);
}
var c5 = Mat.FromRows(new[] { 1.0, 1, 0, 0, 0 }, new[] { 0.0, 0, 0, 1, 1 });
var mixed = Mat.FromRows(new[] { 2.0, 2, 0, 3, 3 }, new[] { 1.0, 1, 0, -1, -1 });
P("v_blocks", Fusion.Blocks(c5).Select(i => (double)i).ToArray());
P("v_blocks_mixed_basis", Fusion.Blocks(mixed).Select(i => (double)i).ToArray());
P("v_leakage", Fusion.Leakage(c5, ImmutableArray.Create(0)),
  Fusion.Leakage(Mat.FromRows(new[] { 1.0, 1e-6 }), ImmutableArray.Create(0)));
P("v_five_point_coverage", Fusion.FivePointCoverage());
P("v_cycle_residual", Fusion.CycleResidual(V(1, 1, 1)));
var objs = new[] { V(0, 2), V(1, 1.5), V(2, 0) };
P("v_chebyshev", Fusion.Chebyshev(objs, V(-1, -1), V(0.5, 0.4)).ToArray());
P("v_weighted_sum_support", Enumerable.Range(0, 3).Select(k => Fusion.SupportedByWeightedSum(objs, k) ? 1.0 : 0.0).ToArray());
var pref = Fusion.PreferenceMixture(V(0.25, 0.25, 0.25, 0.25), V(0, 1, 2, 3), V(1.5, 1.5, 0.2, 2.5), 1.0, 0.5);
P("v_preference", pref.FirstMassNaive, pref.FirstMassCorrect);
var hInd = Mat.Diag(-2, 1, 3); var cInd = Mat.FromRows(new[] { 1.0, 0, 0 });
P("v_indefinite", Fusion.NullspaceSolve(hInd, V(0, 1, 2), cInd, V(0.5), V(0.5, 0, 0)).ToArray());

// 120 random constrained sections: Schur route here, nullspace route in NumPy
var rng = new Rng(20261022UL);
double worstFeas = 0, worstStat = 0, worstRatio = 0; var firstX = V();
for (int t = 0; t < 120; t++)
{
    double[] Draw(int n) { var a = new double[n]; for (int i = 0; i < n; i++) (a[i], rng) = rng.Normal(); return a; }
    var g0 = Mat.Of(7, 7, (i, j) => 0).Data; var gm = Draw(49); var gmat = Mat.Of(7, 7, (i, j) => gm[i * 7 + j]);
    var h = gmat.T.Mul(gmat).Add(Mat.Identity(7)); var cc = Draw(21); var cmat = Mat.Of(3, 7, (i, j) => cc[i * 7 + j]);
    var gv = Draw(7).ToImmutableArray(); var dv = Draw(3).ToImmutableArray();
    var (x, lam) = Fusion.SchurSolve(h, gv, cmat, dv);
    if (t == 0) firstX = x;
    worstFeas = Math.Max(worstFeas, Lin.Norm(Lin.Sub(cmat.Apply(x), dv)));
    var stat = Lin.AddV(Lin.Sub(h.Apply(x), gv), cmat.T.Apply(lam));
    worstStat = Math.Max(worstStat, Lin.Norm(stat));
    // certificate (13.3) on a perturbed feasible candidate
    var nb = Lin.NullBasis(cmat); var pert = Draw(4).ToImmutableArray();
    var xh = Lin.AddV(x, nb.Apply(pert), 1e-3);
    var rr = Lin.AddV(Lin.Sub(h.Apply(xh), gv), cmat.T.Apply(lam));
    double mu = Lin.SymEig(nb.T.Mul(h).Mul(nb)).Values.Min();
    worstRatio = Math.Max(worstRatio, Lin.Norm(Lin.Sub(xh, x)) / (Lin.Norm(nb.T.Apply(rr)) / mu));
}
P("v_sections", worstFeas, worstStat, worstRatio);
P("v_sections_first", firstX.ToArray());

// ---------------- Part VI reproductions
var al = Evidence.Allocate(V(8, 2, 1), V(1, 4, 1), 1, 0.01);
P("vi_allocation", al.Eps[0], al.Eps[1], al.Eps[2], al.Cost, al.EqualContribution, al.EqualLocal);
var rel = Evidence.Release(V(-0.004, -0.001), V(0.002, 0.003));
P("vi_release", rel.Upper[0], rel.Upper[1], rel.Release ? 1 : 0);
P("vi_identical", Evidence.Identical(1000, 1e-6));
P("vi_cs_radius", Evidence.CsRadius(2, 3, 10000, 0.05));

// ---------------- Explorations
var cs = Evidence.CsStudy(new Rng(20261031UL), 0.5, V(0.05, 0.10, 0.18), 10000, 200, 0.05, 0.05);
P("x_cs_study", cs.MissRate, cs.FirstClear[0], cs.FirstClear[1], cs.FirstClear[2], cs.FinalRadius);
var ad = Evidence.AdaptiveStudy(new Rng(20261032UL), 400, 16000, 0.05);
P("x_adaptive_study", ad.FailureRate, ad.MedianMaxRatio, ad.MeanFinalError);
foreach (var k in new[] { 1, 4 })
{
    var cr = Evidence.CriticStudy(new Rng(20261033UL + (ulong)k), 2_000_000, k);
    P($"x_critic_k{k}", cr.Corrected, cr.Uncorrected, cr.EmpiricalM2, Evidence.CriticM2(k));
}
var pcov = new[] { Mat.FromRows(new[] { 1.0, 0.3, 0 }, new[] { 0.3, 0.5, 0.1 }, new[] { 0, 0.1, 0.8 }),
                   Mat.FromRows(new[] { 0.6, -0.2, 0.1 }, new[] { -0.2, 1.2, 0 }, new[] { 0.1, 0, 0.7 }),
                   Mat.FromRows(new[] { 0.9, 0, -0.3 }, new[] { 0, 0.4, 0.1 }, new[] { -0.3, 0.1, 1.1 }) };
var crep = Mat.FromRows(new[] { 1.0, 1, 1 });
double q90 = -2 * Math.Log(0.1);
foreach (var corr in new[] { 0.0, 0.5, 0.9 })
{
    var rs = Evidence.RepairStudy(new Rng(20261034UL), pcov, crep, corr, 40000, q90);
    P($"x_repair_c{corr.ToString(CultureInfo.InvariantCulture)}", rs.CiCoverage, rs.PoeCoverage);
}
foreach (var d in new[] { 2, 4, 8, 16 })
{
    var r2 = new Rng(20261040UL + (ulong)d);
    var recs = ImmutableArray.CreateBuilder<Vec>(4096);
    for (int i = 0; i < 4096; i++) { var y = new double[d]; for (int j = 0; j < d; j++) (y[j], r2) = r2.Uniform(); recs.Add(y.ToImmutableArray()); }
    var arc = new Archive(recs.MoveToImmutable(), Enumerable.Repeat(0.0, 4096).ToImmutableArray());
    var root = SpatialIndex.Build(arc, Enumerable.Range(0, 4096).ToImmutableArray(), 16);
    double spacing = Math.Pow(4096, -1.0 / d);
    foreach (var cfac in new[] { 0.25, 0.5, 1.0 })
    {
        var fracs = new double[20]; var nodes = new double[20]; int viol = 0;
        for (int qi = 0; qi < 20; qi++)
        {
            var z = new double[d]; for (int j = 0; j < d; j++) { double u; (u, r2) = r2.Uniform(); z[j] = 0.25 + 0.5 * u; }
            var tr = SpatialIndex.CertifiedRead(root, arc, z.ToImmutableArray(), cfac * spacing, 1e-3);
            fracs[qi] = tr.RecordsRead / 4096.0; nodes[qi] = tr.NodesVisited;
            if (tr.TrueShare > tr.ShareBound + 1e-12 || tr.ReadError > tr.ErrorBound + 1e-12) viol++;
        }
        var sf = fracs.OrderBy(v => v).ToArray(); var sn = nodes.OrderBy(v => v).ToArray();
        P($"x_index_d{d}_c{cfac.ToString(CultureInfo.InvariantCulture)}", 0.5 * (sf[9] + sf[10]), sf[19], 0.5 * (sn[9] + sn[10]), viol);
    }
}
