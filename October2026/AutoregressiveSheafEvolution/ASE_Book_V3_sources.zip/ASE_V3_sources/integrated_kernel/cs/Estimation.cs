// Part IV, Sections 6-13 of the integrated edition: path weights, Gaussian tail criteria,
// noisy-critic correction, predictable defence, tempering, intrinsic volume, finite-family
// read control and target concentration.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AseBook;

public static class Estimation
{
    /// <summary>Second moment of N(0, Sp) weighted against N(0, Sq): det Sq / sqrt(det Sp det(2Sq - Sp)),
    /// infinite when 2Sq - Sp is not positive definite (Part IV, Proposition 3.3).</summary>
    public static double GaussianM2(Mat sp, Mat sq)
    {
        var k = sq.Scale(2).Add(sp, -1);
        if (Lin.SymEig(k).Values.Min() <= 0) return double.PositiveInfinity;
        return sq.Det / Math.Sqrt(sp.Det * k.Det);
    }

    /// <summary>The scalar two-level path example of Part IV, Section 6.2: endpoint, exact
    /// conditional and independent auxiliary second moments.</summary>
    public static (double Endpoint, double Exact, double Independent) PathExample(double a, double b)
    {
        // Proposal Q: z1 ~ N(0,1), z0 = a z1 + b xi. Coordinates (z0, z1).
        var q = Mat.FromRows(new[] { a * a + b * b, a }, new[] { a, 1.0 });
        double v0 = 0.5;                                     // target N(0, 1/2) for z0
        // The exact auxiliary conditional is the proposal's z1 | z0 law: mean c z0, variance cv.
        double c = a / (a * a + b * b), cv = 1 - a * a / (a * a + b * b);
        var exact = Mat.FromRows(new[] { v0, c * v0 }, new[] { c * v0, cv + c * c * v0 });
        var indep = Mat.FromRows(new[] { v0, 0.0 }, new[] { 0.0, 1.0 });
        return (GaussianM2(Mat.Diag(v0), Mat.Diag(a * a + b * b)), GaussianM2(exact, q), GaussianM2(indep, q));
    }

    /// <summary>Truncated critical-width integral of pi^2/q for pi = N(0,1) and a mixture of
    /// N(c_i, 1/2) components with equal weights (Part IV, Section 7).</summary>
    public static double CriticalIntegral(Vec centres, double r, int panels = 400000)
    {
        double Pi(double x) => Math.Exp(-x * x / 2) / Math.Sqrt(2 * Math.PI);
        double Q(double x) => centres.Average(c => Math.Exp(-(x - c) * (x - c)) / Math.Sqrt(Math.PI));
        return Quad.Simpson(x => Pi(x) * Pi(x) / Q(x), -r, r, panels);
    }

    /// <summary>Residual log tilt r_k(x) of the sample-variance correction (Part IV, (8.3)).</summary>
    public static double ResidualTilt(double beta, double v, int k)
    {
        double a = beta * beta * v / (2 * k), nu = k - 1;
        return a - nu / 2 * Math.Log(1 + 2 * a / nu);
    }

    /// <summary>E x^2 under the plug-in target rho e^{-beta J} e^{r_k(x)}, with rho = N(0,1),
    /// J = x^2/2 and v(x) = (0.5 + 0.5|x|)^2 (Part IV, Table 5).</summary>
    public static double PlugInSecondMoment(int k, double beta = 1)
    {
        double Dens(double x) => Math.Exp(-x * x / 2 - beta * x * x / 2 + ResidualTilt(beta, Math.Pow(0.5 + 0.5 * Math.Abs(x), 2), k));
        double num = Quad.Simpson(x => x * x * Dens(x), -14, 14, 560000);
        double den = Quad.Simpson(Dens, -14, 14, 560000);
        return num / den;
    }

    /// <summary>Tempering on a finite space: exact second moment, the bound e^{h^2R^2/4},
    /// total variation and its bound tanh(hR/4) (Part IV, Proposition 9.2).</summary>
    public static (double M2, double M2Bound, double Tv, double TvBound) Tempering(Vec mass, Vec loss, double b, double h)
    {
        double Z(double t) => mass.Zip(loss, (m, j) => m * Math.Exp(-t * j)).Sum();
        double m2 = Z(b) * Z(b + 2 * h) / (Z(b + h) * Z(b + h));
        var p = mass.Zip(loss, (m, j) => m * Math.Exp(-b * j) / Z(b)).ToArray();
        var q = mass.Zip(loss, (m, j) => m * Math.Exp(-(b + h) * j) / Z(b + h)).ToArray();
        double r = loss.Max() - loss.Min();
        return (m2, Math.Exp(h * h * r * r / 4), 0.5 * p.Zip(q, (x, y) => Math.Abs(x - y)).Sum(), Math.Tanh(h * r / 4));
    }

    /// <summary>Gram factor sqrt det(V^T V) of an intrinsic chart (Part IV, Proposition 6.4).</summary>
    public static double GramFactor(Mat v) => Math.Sqrt(v.T.Mul(v).Det);

    /// <summary>Simultaneous coefficient radius (12.1) and the smallest n making d r_n &lt; mu.</summary>
    public static (double Radius, long NeededN) FamilyRadius(double l, double eps, int families, int queries,
                                                              int d, double delta, int n, double mu)
    {
        double nf = families * queries * (d * d + d), lg = Math.Log(2 * nf / delta);
        double r = l / eps * Math.Sqrt(2 * lg / n);
        long need = (long)Math.Floor(2 * lg * Math.Pow(l * d / (eps * mu), 2)) + 1;
        return (r, need);
    }

    /// <summary>Objective-gap tail of the uniform-reference Gibbs law for J = x^2 on [-1,1]
    /// and the bound (13.1).</summary>
    public static (double Tail, double Bound) Concentration(double beta, double eta, double alpha)
    {
        double Mass(double lo, double hi) => Quad.Simpson(x => Math.Exp(-beta * x * x), lo, hi, 200000);
        double z = Mass(-1, 1), cut = Math.Sqrt(eta);
        double tail = 2 * Mass(cut, 1) / z;
        double sAlpha = Math.Sqrt(alpha);                      // uniform reference mass of {x^2 <= alpha} is sqrt(alpha)
        return (tail, Math.Exp(-beta * (eta - alpha)) / sAlpha);
    }
}
