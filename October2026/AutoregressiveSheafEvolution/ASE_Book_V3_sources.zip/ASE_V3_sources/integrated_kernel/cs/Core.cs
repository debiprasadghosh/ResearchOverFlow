// ASE book, revised third edition: shared immutable core for the integrated numerical kernel.
// Values are records over immutable arrays; functions are pure. Numerical routines that need
// scratch space work on private copies and never expose them.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AseBook;

/// <summary>SplitMix64 stream held as a value: the k-th output depends only on seed + (k+1)·gamma,
/// which lets NumPy regenerate any block of draws without replaying the sequence.</summary>
public sealed record Rng(ulong State)
{
    public const ulong Gamma = 0x9E3779B97F4A7C15UL;

    public (ulong Value, Rng Next) NextU64()
    {
        ulong s = State + Gamma, z = s;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
        return (z ^ (z >> 31), new Rng(s));
    }

    public (double Value, Rng Next) Uniform()
    {
        var (v, n) = NextU64();
        return ((v >> 11) * (1.0 / 9007199254740992.0), n);
    }

    /// <summary>Standard normal by Box-Muller, consuming exactly two uniforms.</summary>
    public (double Value, Rng Next) Normal()
    {
        var (u1, r1) = Uniform();
        var (u2, r2) = r1.Uniform();
        return (Math.Sqrt(-2 * Math.Log(1 - u1)) * Math.Cos(2 * Math.PI * u2), r2);
    }
}

/// <summary>A dense real matrix stored row-major.</summary>
public sealed record Mat(int Rows, int Cols, Vec Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Mat Of(int r, int c, Func<int, int, double> f) =>
        new(r, c, Enumerable.Range(0, r * c).Select(k => f(k / c, k % c)).ToImmutableArray());

    public static Mat FromRows(params double[][] rows) =>
        Of(rows.Length, rows[0].Length, (i, j) => rows[i][j]);

    public static Mat Identity(int n) => Of(n, n, (i, j) => i == j ? 1 : 0);
    public static Mat Diag(params double[] d) => Of(d.Length, d.Length, (i, j) => i == j ? d[i] : 0);
    public Mat T => Of(Cols, Rows, (i, j) => this[j, i]);
    public Mat Mul(Mat b) => Of(Rows, b.Cols,
        (i, j) => Enumerable.Range(0, Cols).Sum(k => this[i, k] * b[k, j]));
    public Vec Apply(Vec v) => Enumerable.Range(0, Rows)
        .Select(i => Enumerable.Range(0, Cols).Sum(k => this[i, k] * v[k])).ToImmutableArray();
    public Mat Add(Mat b, double s = 1) => Of(Rows, Cols, (i, j) => this[i, j] + s * b[i, j]);
    public Mat Scale(double s) => Of(Rows, Cols, (i, j) => s * this[i, j]);
    public double Trace => Enumerable.Range(0, Rows).Sum(i => this[i, i]);

    /// <summary>Solves this X = B by Gauss-Jordan elimination with partial pivoting.</summary>
    public Mat Solve(Mat b)
    {
        int n = Rows, m = b.Cols;
        var a = Enumerable.Range(0, n).Select(i => Enumerable.Range(0, n).Select(j => this[i, j])
            .Concat(Enumerable.Range(0, m).Select(j => b[i, j])).ToArray()).ToArray();
        for (int c = 0; c < n; c++)
        {
            int p = Enumerable.Range(c, n - c).OrderByDescending(r => Math.Abs(a[r][c])).First();
            (a[c], a[p]) = (a[p], a[c]);
            for (int r = 0; r < n; r++)
            {
                if (r == c) continue;
                double f = a[r][c] / a[c][c];
                for (int k = c; k < n + m; k++) a[r][k] -= f * a[c][k];
            }
        }
        return Of(n, m, (i, j) => a[i][n + j] / a[i][i]);
    }

    public Mat Inverse() => Solve(Identity(Rows));
    public Vec SolveVec(Vec v) => Solve(Of(v.Length, 1, (i, _) => v[i])).Data;
    public double Det => Lin.Det(this);
}

public static class Lin
{
    public static double Dot(Vec a, Vec b) => a.Zip(b, (x, y) => x * y).Sum();
    public static double Norm(Vec a) => Math.Sqrt(Dot(a, a));
    public static Vec Sub(Vec a, Vec b) => a.Zip(b, (x, y) => x - y).ToImmutableArray();
    public static Vec AddV(Vec a, Vec b, double s = 1) => a.Zip(b, (x, y) => x + s * y).ToImmutableArray();
    public static Vec Of(params double[] x) => x.ToImmutableArray();

    /// <summary>Determinant by partial-pivot elimination on a private copy.</summary>
    public static double Det(Mat m)
    {
        int n = m.Rows; var a = Enumerable.Range(0, n).Select(i =>
            Enumerable.Range(0, n).Select(j => m[i, j]).ToArray()).ToArray();
        double det = 1;
        for (int c = 0; c < n; c++)
        {
            int p = Enumerable.Range(c, n - c).OrderByDescending(r => Math.Abs(a[r][c])).First();
            if (a[p][c] == 0) return 0;
            if (p != c) { (a[c], a[p]) = (a[p], a[c]); det = -det; }
            det *= a[c][c];
            for (int r = c + 1; r < n; r++)
            {
                double f = a[r][c] / a[c][c];
                for (int k = c; k < n; k++) a[r][k] -= f * a[c][k];
            }
        }
        return det;
    }

    /// <summary>Eigenvalues (ascending) and eigenvectors (columns) of a symmetric matrix,
    /// by cyclic Jacobi rotations on private copies.</summary>
    public static (Vec Values, Mat Vectors) SymEig(Mat m)
    {
        int n = m.Rows;
        var a = m.Data.ToArray(); var v = Mat.Identity(n).Data.ToArray();
        for (int sweep = 0; sweep < 100; sweep++)
        {
            double off = 0;
            for (int p = 0; p < n; p++) for (int q = p + 1; q < n; q++) off += a[p * n + q] * a[p * n + q];
            if (off < 1e-30) break;
            for (int p = 0; p < n - 1; p++)
                for (int q = p + 1; q < n; q++)
                {
                    double apq = a[p * n + q];
                    if (Math.Abs(apq) < 1e-300) continue;
                    double th = (a[q * n + q] - a[p * n + p]) / (2 * apq);
                    double t = Math.Sign(th == 0 ? 1 : th) / (Math.Abs(th) + Math.Sqrt(th * th + 1));
                    double c = 1 / Math.Sqrt(t * t + 1), s = t * c;
                    for (int k = 0; k < n; k++)
                        (a[k * n + p], a[k * n + q]) = (c * a[k * n + p] - s * a[k * n + q], s * a[k * n + p] + c * a[k * n + q]);
                    for (int k = 0; k < n; k++)
                        (a[p * n + k], a[q * n + k]) = (c * a[p * n + k] - s * a[q * n + k], s * a[p * n + k] + c * a[q * n + k]);
                    for (int k = 0; k < n; k++)
                        (v[k * n + p], v[k * n + q]) = (c * v[k * n + p] - s * v[k * n + q], s * v[k * n + p] + c * v[k * n + q]);
                }
        }
        var order = Enumerable.Range(0, n).OrderBy(i => a[i * n + i]).ToArray();
        return (order.Select(i => a[i * n + i]).ToImmutableArray(),
                Mat.Of(n, n, (r, c) => v[r * n + order[c]]));
    }

    /// <summary>Orthogonal projector onto the row space of C, from the eigenvectors of C^T C
    /// whose eigenvalues exceed tol times the largest one.</summary>
    public static Mat RowSpaceProjector(Mat c, double tol = 1e-12)
    {
        var (vals, vecs) = SymEig(c.T.Mul(c));
        double top = vals.Max();
        var keep = Enumerable.Range(0, vals.Length).Where(i => vals[i] > tol * top).ToArray();
        return Mat.Of(c.Cols, c.Cols, (i, j) => keep.Sum(k => vecs[i, k] * vecs[j, k]));
    }

    /// <summary>Orthonormal basis of ker C, as columns.</summary>
    public static Mat NullBasis(Mat c, double tol = 1e-12)
    {
        var (vals, vecs) = SymEig(c.T.Mul(c));
        double top = vals.Max();
        var keep = Enumerable.Range(0, vals.Length).Where(i => vals[i] <= tol * top).ToArray();
        return Mat.Of(c.Cols, keep.Length, (i, j) => vecs[i, keep[j]]);
    }
}

/// <summary>Simpson quadrature of a smooth function on [a, b] with an even number of panels.</summary>
public static class Quad
{
    public static double Simpson(Func<double, double> f, double a, double b, int panels)
    {
        double h = (b - a) / panels, s = f(a) + f(b);
        for (int i = 1; i < panels; i++) s += (i % 2 == 1 ? 4 : 2) * f(a + i * h);
        return s * h / 3;
    }
}
