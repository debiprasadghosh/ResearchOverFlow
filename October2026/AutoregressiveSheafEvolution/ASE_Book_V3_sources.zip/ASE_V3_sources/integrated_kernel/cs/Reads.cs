// Identity-map reads: the guarded shift-and-divide softmax of Part VI, Proposition 2.2, the
// division-free form whose extreme-logit defect Part VI, Section 2.2 reports, the omitted-mass
// certificate (Proposition 2.3) and a certified best-first index traversal (Proposition 3.2).
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AseBook;

public sealed record Archive(ImmutableArray<Vec> Records, Vec LogWeights)
{
    public int Count => Records.Length;
    public int Dim => Records[0].Length;
}

public static class Softmax
{
    /// <summary>Shift, exponentiate, divide (Part VI, Proposition 2.2).</summary>
    public static Vec ShiftDivide(Vec logits)
    {
        if (logits.Length == 0 || logits.Any(x => !double.IsFinite(x)))
            throw new ArgumentException("Logits must be finite and nonempty");
        double peak = logits.Max();
        var raw = logits.Select(x => Math.Exp(x - peak)).ToArray();
        double total = raw.Sum();
        return raw.Select(x => x / total).ToImmutableArray();
    }

    /// <summary>The division-free form alpha_i = exp(l_i - L), L = M + log sum exp(l - M).
    /// Algebraically identical; retained only to reproduce its extreme-logit defect.</summary>
    public static Vec DivisionFree(Vec logits)
    {
        double peak = logits.Max();
        double l = peak + Math.Log(logits.Sum(x => Math.Exp(x - peak)));
        return logits.Select(x => Math.Exp(x - l)).ToImmutableArray();
    }
}

public static class Reads
{
    static double Sq(Vec a, Vec b) => a.Zip(b, (p, q) => (p - q) * (p - q)).Sum();

    /// <summary>Guarded read: rejects an empty archive, nonpositive or nonfinite scale,
    /// a dimension mismatch and nonfinite coordinates, as the revised contract requires.</summary>
    public static Vec Read(Vec z, Archive a, double s)
    {
        if (a.Count == 0) throw new ArgumentException("empty archive");
        if (!(s > 0) || !double.IsFinite(s)) throw new ArgumentException("scale must be positive and finite");
        if (z.Length != a.Dim || a.Records.Any(y => y.Length != a.Dim))
            throw new ArgumentException("dimension mismatch");
        if (z.Any(x => !double.IsFinite(x)) || a.Records.Any(y => y.Any(x => !double.IsFinite(x))))
            throw new ArgumentException("nonfinite coordinate");
        var w = Softmax.ShiftDivide(a.Records.Select((y, i) => a.LogWeights[i] - Sq(z, y) / (2 * s * s))
                                               .ToImmutableArray());
        return Enumerable.Range(0, a.Dim).Select(j => a.Records.Select((y, i) => w[i] * y[j]).Sum())
                         .ToImmutableArray();
    }

    /// <summary>Barycentre of scalar records under given logits, by either softmax form.</summary>
    public static double Barycentre(Vec values, Vec logits, bool divisionFree)
    {
        var w = divisionFree ? Softmax.DivisionFree(logits) : Softmax.ShiftDivide(logits);
        return w.Zip(values, (p, v) => p * v).Sum();
    }

    /// <summary>Omitted-share certificate of Proposition 2.3 for the k nearest records;
    /// k = n returns a zero share without an omitted-distance query.</summary>
    public static double OmittedShare(Vec z, Archive a, double s, int k)
    {
        if (k < 1 || k > a.Count) throw new ArgumentException("k out of range");
        if (k == a.Count) return 0.0;
        var order = Enumerable.Range(0, a.Count).OrderBy(i => Sq(z, a.Records[i])).ToArray();
        var kept = order.Take(k).Select(i => a.LogWeights[i] - Sq(z, a.Records[i]) / (2 * s * s)).ToArray();
        double peak = kept.Max(), lk = peak + Math.Log(kept.Sum(x => Math.Exp(x - peak)));
        double lo = Math.Log(a.Count - k) + order.Skip(k).Max(i => a.LogWeights[i])
                    - Sq(z, a.Records[order[k]]) / (2 * s * s);
        return 1 / (1 + Math.Exp(lk - lo));
    }
}

/// <summary>A k-d tree node with its bounding box and aggregate prior weight.</summary>
public sealed record Node(Vec Lo, Vec Hi, double LogMass, ImmutableArray<int> Items,
                          Node? Left, Node? Right)
{
    public bool IsLeaf => Left is null;
}

public sealed record Traversal(int RecordsRead, int NodesVisited, double ShareBound, double TrueShare,
                               double ReadError, double ErrorBound);

public static class SpatialIndex
{
    public static Node Build(Archive a, ImmutableArray<int> items, int leafSize, int depth = 0)
    {
        int d = a.Dim;
        var lo = Enumerable.Range(0, d).Select(j => items.Min(i => a.Records[i][j])).ToImmutableArray();
        var hi = Enumerable.Range(0, d).Select(j => items.Max(i => a.Records[i][j])).ToImmutableArray();
        double peak = items.Max(i => a.LogWeights[i]);
        double logMass = peak + Math.Log(items.Sum(i => Math.Exp(a.LogWeights[i] - peak)));
        if (items.Length <= leafSize) return new Node(lo, hi, logMass, items, null, null);
        int axis = Enumerable.Range(0, d).OrderByDescending(j => hi[j] - lo[j]).ThenBy(j => j).First();
        var sorted = items.OrderBy(i => a.Records[i][axis]).ThenBy(i => i).ToImmutableArray();
        int half = sorted.Length / 2;
        return new Node(lo, hi, logMass, items,
                        Build(a, sorted.Take(half).ToImmutableArray(), leafSize, depth + 1),
                        Build(a, sorted.Skip(half).ToImmutableArray(), leafSize, depth + 1));
    }

    static double BoxDist2(Node n, Vec z) => Enumerable.Range(0, z.Length).Sum(j =>
    {
        double g = z[j] < n.Lo[j] ? n.Lo[j] - z[j] : z[j] > n.Hi[j] ? z[j] - n.Hi[j] : 0;
        return g * g;
    });

    /// <summary>Best-first certified read (Part VI, Proposition 3.2): expand the frontier node
    /// with the largest mass bound until the omitted share bound is at most tol.</summary>
    public static Traversal CertifiedRead(Node root, Archive a, Vec z, double s, double tol)
    {
        double Bound(Node n) => n.LogMass - BoxDist2(n, z) / (2 * s * s);
        var frontier = new List<(double B, Node N)> { (Bound(root), root) };
        var kept = new List<int>(); int visited = 0;
        double keptMax = double.NegativeInfinity;
        double LogSum(IEnumerable<double> xs)
        {
            var arr = xs.ToArray(); if (arr.Length == 0) return double.NegativeInfinity;
            double m = arr.Max(); return m + Math.Log(arr.Sum(x => Math.Exp(x - m)));
        }
        double Logit(int i) => a.LogWeights[i] - a.Records[i].Zip(z, (p, q) => (p - q) * (p - q)).Sum() / (2 * s * s);
        double share = 1;
        while (true)
        {
            double lk = LogSum(kept.Select(Logit)), lo = LogSum(frontier.Select(f => f.B));
            share = double.IsNegativeInfinity(lo) ? 0 : double.IsNegativeInfinity(lk) ? 1 : 1 / (1 + Math.Exp(lk - lo));
            if (share <= tol || frontier.Count == 0) break;
            int best = 0;
            for (int i = 1; i < frontier.Count; i++) if (frontier[i].B > frontier[best].B) best = i;
            var node = frontier[best].N; frontier.RemoveAt(best); visited++;
            if (node.IsLeaf) kept.AddRange(node.Items);
            else { frontier.Add((Bound(node.Left!), node.Left!)); frontier.Add((Bound(node.Right!), node.Right!)); }
        }
        var all = Enumerable.Range(0, a.Count).Select(Logit).ToArray();
        double lAll = LogSum(all), lKept = LogSum(kept.Select(Logit));
        double trueShare = 1 - Math.Exp(lKept - lAll);
        Vec Mean(IEnumerable<int> idx)
        {
            var ids = idx.ToArray(); var w = Softmax.ShiftDivide(ids.Select(Logit).ToImmutableArray());
            return Enumerable.Range(0, a.Dim).Select(j => ids.Select((i, k) => w[k] * a.Records[i][j]).Sum()).ToImmutableArray();
        }
        var full = Mean(Enumerable.Range(0, a.Count)); var part = Mean(kept);
        double diam = Math.Sqrt(Enumerable.Range(0, a.Dim).Sum(j =>
            Math.Pow(a.Records.Max(y => y[j]) - a.Records.Min(y => y[j]), 2)));
        return new Traversal(kept.Count, visited, share, trueShare, Lin.Norm(Lin.Sub(full, part)), share * diam);
    }
}
