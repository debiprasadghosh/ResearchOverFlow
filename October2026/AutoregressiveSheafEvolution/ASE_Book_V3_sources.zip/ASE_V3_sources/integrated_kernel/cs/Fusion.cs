// Part V, Sections 6-13 of the integrated edition: junction-tree extension, covariance repair,
// penalty laws, canonical feasible blocks, cycle residuals, preferences and constrained sections.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AseBook;

public static class Fusion
{
    /// <summary>Four-variable binary Markov chain: total variation between the naive product of
    /// its edge marginals (normalised) and the junction-tree extension, which equals the joint.</summary>
    public static (double NaiveTv, double TreeTv) ChainExtension(Vec init, Mat[] trans)
    {
        double Joint(int[] x) => init[x[0]] * trans[0][x[0], x[1]] * trans[1][x[1], x[2]] * trans[2][x[2], x[3]];
        var states = Enumerable.Range(0, 16).Select(k => new[] { k >> 3 & 1, k >> 2 & 1, k >> 1 & 1, k & 1 }).ToArray();
        var p = states.Select(Joint).ToArray();
        double Edge(int e, int u, int v) => states.Select((x, k) => x[e] == u && x[e + 1] == v ? p[k] : 0).Sum();
        double Node(int i, int u) => states.Select((x, k) => x[i] == u ? p[k] : 0).Sum();
        var tree = states.Select(x => Edge(0, x[0], x[1]) * Edge(1, x[1], x[2]) * Edge(2, x[2], x[3])
                                      / (Node(1, x[1]) * Node(2, x[2]))).ToArray();
        var naive = states.Select(x => Edge(0, x[0], x[1]) * Edge(1, x[1], x[2]) * Edge(2, x[2], x[3])).ToArray();
        double zn = naive.Sum();
        return (0.5 * p.Zip(naive, (a, b) => Math.Abs(a - b / zn)).Sum(), 0.5 * p.Zip(tree, (a, b) => Math.Abs(a - b)).Sum());
    }

    /// <summary>Symmetric correlation repair (Part V, Proposition 6.4).</summary>
    public static (double MinEig, double Repaired, double Distance) SymmetricRepair(int n, double r)
    {
        double lo = -1.0 / (n - 1), rs = Math.Min(1, Math.Max(lo, r));
        return (Math.Min(1 + (n - 1) * r, 1 - r), rs, Math.Sqrt(n * (n - 1.0)) * Math.Abs(r - rs));
    }

    /// <summary>Mean displacement and exact W2 for the isotropic penalty example (Part V, Table 4):
    /// Sigma = I, so the projection coupling is optimal.</summary>
    public static (double Mean, double W2) PenaltyIsotropic(Mat c, double b, Vec mu, double gamma)
    {
        double cnorm2 = Lin.Dot(c.Data, c.Data);              // single row: M = |c|^2
        double r0 = Lin.Dot(c.Data, mu) - b, rg = r0 / (1 + gamma * cnorm2), vg = cnorm2 / (1 + gamma * cnorm2);
        double dnorm = 1 / Math.Sqrt(cnorm2);
        return (dnorm * Math.Abs(rg), dnorm * Math.Sqrt(rg * rg + vg));
    }

    /// <summary>Finest safe coordinate blocks from the row-space projector (Part V, Corollary 8.2).</summary>
    public static ImmutableArray<int> Blocks(Mat c, double tol = 1e-12)
    {
        var q = Lin.RowSpaceProjector(c); int n = c.Cols;
        var label = Enumerable.Range(0, n).ToArray();
        int Find(int i) { while (label[i] != i) i = label[i]; return i; }
        for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++)
            if (Math.Abs(q[i, j]) > tol) { int a = Find(i), b = Find(j); if (a != b) label[Math.Max(a, b)] = Math.Min(a, b); }
        return Enumerable.Range(0, n).Select(Find).ToImmutableArray();
    }

    /// <summary>Sharp leakage ||Q P_B (I - Q)|| of one block replacement (Proposition 8.3).</summary>
    public static double Leakage(Mat c, ImmutableArray<int> block)
    {
        var q = Lin.RowSpaceProjector(c); int n = c.Cols;
        var pb = Mat.Of(n, n, (i, j) => i == j && block.Contains(i) ? 1 : 0);
        var op = q.Mul(pb).Mul(Mat.Identity(n).Add(q, -1));
        return Math.Sqrt(Math.Max(0, Lin.SymEig(op.T.Mul(op)).Values.Max()));
    }

    /// <summary>Exact coverage of the Gaussian 90% ellipse by the five-point unit-covariance law.</summary>
    public static double FivePointCoverage()
    {
        double q90 = -2 * Math.Log(0.1);                       // chi-square(2) 90% quantile
        var pts = new[] { (0.0, 0.0, 0.8), (Math.Sqrt(10), 0, 0.05), (-Math.Sqrt(10), 0, 0.05), (0, Math.Sqrt(10), 0.05), (0, -Math.Sqrt(10), 0.05) };
        return pts.Where(p => p.Item1 * p.Item1 + p.Item2 * p.Item2 <= q90).Sum(p => p.Item3);
    }

    /// <summary>Harmonic residual of an edge observation on the triangle: ||P_{ker C^T} b||.</summary>
    public static double CycleResidual(Vec b)
    {
        var c = Mat.FromRows(new[] { -1.0, 1, 0 }, new[] { 0.0, -1, 1 }, new[] { 1.0, 0, -1 });
        var q = Lin.RowSpaceProjector(c.T);                    // projector onto im C
        return Lin.Norm(Lin.Sub(b, q.Apply(b)));
    }

    /// <summary>Weighted Chebyshev values relative to a utopian reference (Part V, Proposition 12.3).</summary>
    public static Vec Chebyshev(Vec[] objectives, Vec r, Vec lambda) =>
        objectives.Select(f => Enumerable.Range(0, f.Length).Max(j => lambda[j] * (f[j] - r[j]))).ToImmutableArray();

    /// <summary>Whether any positive weight vector on a grid makes point k the weighted-sum minimiser.</summary>
    public static bool SupportedByWeightedSum(Vec[] objectives, int k, int grid = 10000) =>
        Enumerable.Range(1, grid - 1).Any(g =>
        {
            double l1 = g / (double)grid, l2 = 1 - l1;
            double vk = l1 * objectives[k][0] + l2 * objectives[k][1];
            return objectives.All(f => vk <= l1 * f[0] + l2 * f[1] + 1e-15);
        });

    /// <summary>Preference mixture on a finite design space: label masses after normalising the joint
    /// unnormalised density, against the intended label law (Part V, Proposition 12.4).</summary>
    public static (double FirstMassNaive, double FirstMassCorrect) PreferenceMixture(Vec rho, Vec j1, Vec j2, double beta, double nu1)
    {
        double z1 = rho.Zip(j1, (r, j) => r * Math.Exp(-beta * j)).Sum(), z2 = rho.Zip(j2, (r, j) => r * Math.Exp(-beta * j)).Sum();
        return (nu1 * z1 / (nu1 * z1 + (1 - nu1) * z2), nu1);
    }

    /// <summary>Constrained quadratic section optimum by the Schur route (13.2), with the
    /// multiplier, feasibility residual and tangent-residual certificate inputs.</summary>
    public static (Vec X, Vec Lambda) SchurSolve(Mat h, Vec g, Mat c, Vec d)
    {
        var hi = h.Inverse();
        var s = c.Mul(hi).Mul(c.T);
        var lam = s.SolveVec(Lin.Sub(c.Mul(hi).Apply(g), d));
        var x = hi.Apply(Lin.Sub(g, c.T.Apply(lam)));
        return (x, lam);
    }

    /// <summary>Nullspace route (13.1), used for the ambient-indefinite example.</summary>
    public static Vec NullspaceSolve(Mat h, Vec g, Mat c, Vec d, Vec xp)
    {
        var n = Lin.NullBasis(c);
        var hn = n.T.Mul(h).Mul(n);
        var u = hn.SolveVec(n.T.Apply(Lin.Sub(g, h.Apply(xp))));
        return Lin.AddV(xp, n.Apply(u));
    }
}
