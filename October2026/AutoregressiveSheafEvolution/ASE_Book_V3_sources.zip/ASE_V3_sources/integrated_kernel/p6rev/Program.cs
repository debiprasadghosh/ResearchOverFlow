// Driver for the Part VI kernel. Every line is recomputed by cs_validate.py.
using System;
using System.Collections.Immutable;
using System.Globalization;
using System.Linq;
using AsePartSix;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

static string F(double x) => x.ToString("R", CultureInfo.InvariantCulture);
static void Print(string name, params double[] xs) =>
    Console.WriteLine(name + " " + string.Join(" ", xs.Select(F)));

var rng = new Rng(20261024UL);
var ys = ImmutableArray.CreateBuilder<Vec>(400);
var lw = ImmutableArray.CreateBuilder<double>(400);
for (int i = 0; i < 400; i++)
{
    var y = new double[3];
    for (int j = 0; j < 3; j++) (y[j], rng) = rng.Normal();
    ys.Add(y.ToImmutableArray());
    double w; (w, rng) = rng.Normal(); lw.Add(0.5 * w);
}
var Y = ys.MoveToImmutable(); var L = lw.MoveToImmutable();
var z = ImmutableArray.Create(0.4, -0.3, 0.8);

// Proposition 2.2: a read at a scale where unshifted exponentials underflow
var tiny = Reads.Stable(z, Y, L, 0.01);
Print("stable_read_s0.01", tiny[0], tiny[1], tiny[2]);
var full = Reads.Stable(z, Y, L, 0.5);
Print("full_read", full[0], full[1], full[2]);
foreach (var k in new[] { 16, 64 })
{
    var c = Reads.Truncated(z, Y, L, 0.5, k);
    double err = Math.Sqrt(c.Mean.Zip(full, (a, b) => (a - b) * (a - b)).Sum());
    Print($"truncated_k{k}", err, c.OmittedShareBound, c.ErrorBound);
}

Print("sample_size", Evidence.PairedSampleSize(1.6448536269514722, 0.8416212335729143, 0.02, 0.06));
var p = ImmutableArray.Create(0.001, 0.04, 0.012, 0.3, 0.009, 0.02);
Print("holm", Evidence.Holm(p, 0.05).Select(b => b ? 1.0 : 0.0).ToArray());
double e7; (e7, rng) = Evidence.ExpectedMax(rng, 7, 20000);
Print("expected_max_7", e7);

// Third-revision regressions for the repaired normalisation and the input contract.
var two = ImmutableArray.Create(ImmutableArray.Create(1.0), ImmutableArray.Create(3.0));
Print("regress_extreme_logits", Reads.ReadLogits(two, ImmutableArray.Create(-1e20, -1e20))[0]);
var allK = Reads.Truncated(z, Y, L, 0.5, 400);
double dfull = Math.Sqrt(allK.Mean.Zip(full, (a, b) => (a - b) * (a - b)).Sum());
Print("regress_k_equals_n", allK.OmittedShareBound, allK.ErrorBound, dfull);
int Rej(Action act) { try { act(); return 0; } catch (ArgumentException) { return 1; } }
Print("regress_contract", Rej(() => Reads.Stable(z, Y, L, 0)), Rej(() => Reads.Stable(z, Y, L, -1)),
      Rej(() => Reads.Stable(z, Y, L, double.NaN)), Rej(() => Reads.Stable(ImmutableArray.Create(0.1, 0.2), Y, L, 0.5)),
      Rej(() => Reads.Stable(z, ImmutableArray<Vec>.Empty, ImmutableArray<double>.Empty, 0.5)),
      Rej(() => Reads.Truncated(z, Y, L, 0.5, 0)), Rej(() => Reads.Truncated(z, Y, L, 0.5, 401)));
