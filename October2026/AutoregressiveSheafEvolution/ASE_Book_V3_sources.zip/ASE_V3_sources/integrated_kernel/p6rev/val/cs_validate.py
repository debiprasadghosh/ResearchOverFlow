"""Recompute every line of the Part VI C# driver with NumPy; write cs_validate.json."""
import json, math, os
import numpy as np
from scipy.special import logsumexp
H = os.path.dirname(os.path.abspath(__file__)); M64 = (1 << 64) - 1
class Rng:
    def __init__(s, x): s.s = x
    def uniform(s):
        s.s = (s.s + 0x9E3779B97F4A7C15) & M64; z = s.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64; z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return ((z ^ (z >> 31)) >> 11) * (1.0 / 9007199254740992.0)
    def normal(s):
        a = s.uniform(); b = s.uniform(); return math.sqrt(-2 * math.log(1 - a)) * math.cos(2 * math.pi * b)
r = Rng(20261024); Y = []; L = []
for i in range(400):
    Y.append([r.normal() for _ in range(3)]); L.append(0.5 * r.normal())
Y = np.array(Y); L = np.array(L); z = np.array([.4, -.3, .8])
def read(idx, s):
    l = L[idx] - ((Y[idx] - z) ** 2).sum(1) / (2 * s * s); a = np.exp(l - logsumexp(l)); return a @ Y[idx], logsumexp(l)
out = [("stable_read_s0.01", read(np.arange(400), .01)[0]), ("full_read", read(np.arange(400), .5)[0])]
full = out[1][1]; d2 = ((Y - z) ** 2).sum(1); order = np.argsort(d2, kind="stable")
diam = math.sqrt(((Y.max(0) - Y.min(0)) ** 2).sum())
for k in (16, 64):
    m, kept = read(order[:k], .5); om = math.log(400 - k) + L.max() - d2[order[k]] / (2 * .25)
    sh = 1 / (1 + math.exp(kept - om)); out.append((f"truncated_k{k}", [np.linalg.norm(m - full), sh, sh * diam]))
from scipy.stats import norm
out.append(("sample_size", [math.ceil((norm.ppf(.95) + norm.ppf(.8)) ** 2 * .06 ** 2 / .02 ** 2)]))
p = np.array([.001, .04, .012, .3, .009, .02]); o = np.argsort(p); rej = np.zeros(6)
for k, i in enumerate(o):
    if p[i] > .05 / (6 - k): break
    rej[i] = 1
out.append(("holm", rej))
tot = 0.0
for t in range(20000):
    tot += max(r.normal() for _ in range(7))
out.append(("expected_max_7", [tot / 20000]))
cs = [l.split() for l in open(os.path.join(H, "cs", "cs_out.txt")).read().splitlines() if l.strip()]
rows = []; ok = True
for (name, py), c in zip(out, cs):
    assert c[0] == name, (c[0], name)
    cv = [float(t) for t in c[1:]]; py = [float(v) for v in np.ravel(py)]
    rel = max(abs(x - y) / max(abs(y), 1e-300) if y != 0 else abs(x) for x, y in zip(cv, py)); absd = max(abs(x - y) for x, y in zip(cv, py))
    ok = bool(ok and (rel < 1e-9 or absd < 1e-12))
    rows.append(dict(name=name, csharp=" ".join(c), python=name + " " + " ".join(repr(v) for v in py), rel=float(rel), absd=float(absd)))
json.dump(dict(rows=rows, all_agree=ok, max_rel=max(r_["rel"] for r_ in rows)), open(os.path.join(H, "cs_validate.json"), "w"), indent=1)
[print(r_["name"], r_["rel"]) for r_ in rows]; print("ALL", ok)
