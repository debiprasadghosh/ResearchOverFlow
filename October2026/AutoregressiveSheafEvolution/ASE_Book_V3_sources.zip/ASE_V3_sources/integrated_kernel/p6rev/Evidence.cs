// ASE Part VI reference kernel: stable and certified reads, and the arithmetic of evidence.
// Immutable values and pure functions; the random stream is itself a value.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AsePartSix;

/// <summary>A read with its certificate: the bound on the omitted posterior share and on
/// the distance from the full read (Proposition 2.3).</summary>
public sealed record CertifiedRead(Vec Mean, double OmittedShareBound, double ErrorBound, int Used);

public static class Reads
{
    static double LogSumExp(Vec v)
    {
        double m = v.Max();
        return m + Math.Log(v.Sum(x => Math.Exp(x - m)));
    }

    static double SqDist(Vec a, Vec b) => a.Zip(b, (p, q) => (p - q) * (p - q)).Sum();

    static Vec Weighted(ImmutableArray<Vec> ys, Vec logits)
    {
        double peak = logits.Max();
        if (!double.IsFinite(peak) || logits.Any(x => !double.IsFinite(x)))
            throw new ArithmeticException("Nonfinite logits; rescale inputs");
        var raw = logits.Select(x => Math.Exp(x - peak)).ToArray();
        double total = raw.Sum();
        var a = raw.Select(x => x / total).ToArray();
        return Enumerable.Range(0, ys[0].Length)
            .Select(j => ys.Select((y, i) => a[i] * y[j]).Sum()).ToImmutableArray();
    }

    /// <summary>Regression access to the barycentre for given logits.</summary>
    public static Vec ReadLogits(ImmutableArray<Vec> ys, Vec logits) => Weighted(ys, logits);

    static void Guard(Vec z, ImmutableArray<Vec> ys, Vec logW, double s)
    {
        if (ys.Length == 0) throw new ArgumentException("empty archive");
        if (!(s > 0) || !double.IsFinite(s)) throw new ArgumentException("scale must be positive and finite");
        if (logW.Length != ys.Length || ys.Any(y => y.Length != z.Length)) throw new ArgumentException("dimension mismatch");
    }

    /// <summary>The Gaussian read with identity maps, by shifted exponentials (Proposition 2.2).</summary>
    public static Vec Stable(Vec z, ImmutableArray<Vec> ys, Vec logW, double s)
    {
        Guard(z, ys, logW, s);
        return Weighted(ys, ys.Select((y, i) => logW[i] - SqDist(z, y) / (2 * s * s)).ToImmutableArray());
    }

    /// <summary>The read over the k nearest records, with the certificate of Proposition 2.3.</summary>
    public static CertifiedRead Truncated(Vec z, ImmutableArray<Vec> ys, Vec logW, double s, int k)
    {
        Guard(z, ys, logW, s);
        if (k < 1 || k > ys.Length) throw new ArgumentException("k out of range");
        if (k == ys.Length) return new CertifiedRead(Stable(z, ys, logW, s), 0, 0, k);
        var order = Enumerable.Range(0, ys.Length).OrderBy(i => SqDist(z, ys[i])).ToArray();
        var near = order.Take(k).ToImmutableArray();
        var logits = near.Select(i => logW[i] - SqDist(z, ys[i]) / (2 * s * s)).ToImmutableArray();
        double kept = LogSumExp(logits);
        double omitted = Math.Log(ys.Length - k) + logW.Max()
                         - SqDist(z, ys[order[k]]) / (2 * s * s);
        double share = 1 / (1 + Math.Exp(kept - omitted));
        int d = ys[0].Length;
        double diam = Math.Sqrt(Enumerable.Range(0, d).Sum(j =>
        {
            double lo = ys.Min(y => y[j]), hi = ys.Max(y => y[j]);
            return (hi - lo) * (hi - lo);
        }));
        return new CertifiedRead(Weighted(near.Select(i => ys[i]).ToImmutableArray(), logits),
                                 share, share * diam, k);
    }
}

public static class Evidence
{
    /// <summary>Paired sample size for a one-sided test of mean difference delta with
    /// standard deviation sd, from the two normal quantiles (Proposition 3.1).</summary>
    public static int PairedSampleSize(double zAlpha, double zPower, double delta, double sd) =>
        (int)Math.Ceiling(Math.Pow(zAlpha + zPower, 2) * sd * sd / (delta * delta));

    /// <summary>Holm's step-down procedure: which hypotheses are rejected at level alpha
    /// (Proposition 3.2).</summary>
    public static ImmutableArray<bool> Holm(Vec pValues, double alpha)
    {
        int m = pValues.Length;
        var order = Enumerable.Range(0, m).OrderBy(i => pValues[i]).ToArray();
        var reject = new bool[m];
        for (int r = 0; r < m; r++)
        {
            if (pValues[order[r]] > alpha / (m - r)) break;
            reject[order[r]] = true;
        }
        return reject.ToImmutableArray();
    }

    /// <summary>Monte Carlo mean of the largest of m standard normals (Proposition 3.3).</summary>
    public static (double Mean, Rng Next) ExpectedMax(Rng rng, int m, int reps)
    {
        double sum = 0;
        for (int t = 0; t < reps; t++)
        {
            double best = double.NegativeInfinity;
            for (int i = 0; i < m; i++) { double z; (z, rng) = rng.Normal(); best = Math.Max(best, z); }
            sum += best;
        }
        return (sum / reps, rng);
    }
}

/// <summary>SplitMix64 stream with Box-Muller normals; each draw returns the next state.</summary>
public sealed record Rng(ulong State)
{
    public (double Value, Rng Next) Uniform()
    {
        ulong s = State + 0x9E3779B97F4A7C15UL, z = s;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
        return (((z ^ (z >> 31)) >> 11) * (1.0 / 9007199254740992.0), new Rng(s));
    }

    public (double Value, Rng Next) Normal()
    {
        var (u1, r1) = Uniform();
        var (u2, r2) = r1.Uniform();
        return (Math.Sqrt(-2 * Math.Log(1 - u1)) * Math.Cos(2 * Math.PI * u2), r2);
    }
}
