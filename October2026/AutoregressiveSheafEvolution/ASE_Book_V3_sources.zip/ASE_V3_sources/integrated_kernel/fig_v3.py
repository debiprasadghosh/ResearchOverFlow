"""Figure B.2 of the third revision, drawn from the validated kernel output."""
import json, os
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
H = os.path.dirname(os.path.abspath(__file__))
rows = {r["name"]: r["csharp"] for r in json.load(open(os.path.join(H, "validate.json")))["rows"]}
B, O, A, INK, MUT = "#2a78d6", "#eb6834", "#1baf7a", "#222222", "#6b6b6b"
plt.rcParams.update({"font.size": 8.5, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": MUT,
                     "xtick.color": MUT, "ytick.color": MUT, "axes.grid": True, "grid.color": "#e8e8e8", "grid.linewidth": .6})
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 2.8))
dims = [2, 4, 8, 16]
for c, col in (("0.25", B), ("0.5", A), ("1", O)):
    med = [rows[f"x_index_d{d}_c{c}"][0] for d in dims]; mx = [rows[f"x_index_d{d}_c{c}"][1] for d in dims]
    a1.plot(dims, med, "o-", color=col, lw=2, ms=4, label=f"scale {c} × spacing")
    a1.plot(dims, mx, ":", color=col, lw=1)
a1.axhline(0.10, color=INK, lw=.8, ls="--"); a1.text(16, 0.115, "C5 share 10%", ha="right", fontsize=7.5, color=INK)
a1.set_xscale("log", base=2); a1.set_xticks(dims); a1.set_xticklabels(dims)
a1.set_xlabel("dimension $D$ (4,096 uniform records)"); a1.set_ylabel("share of records read")
a1.legend(frameon=False, fontsize=7, loc="center right"); a1.set_title("(a) certified index traversal", fontsize=8.5, color=INK)
cs = [0, 0.5, 0.9]
a2.plot(cs, [rows[f"x_repair_c{c:g}"][0] for c in cs], "o-", color=A, lw=2, ms=4, label="covariance intersection, repaired")
a2.plot(cs, [rows[f"x_repair_c{c:g}"][1] for c in cs], "o-", color=O, lw=2, ms=4, label="product of experts, repaired")
a2.axhline(0.9, color=MUT, ls="--", lw=1); a2.set_ylim(0.5, 1.02)
a2.set_xlabel("common error correlation"); a2.set_ylabel("coverage of the 90% ellipse")
a2.legend(frameon=False, fontsize=7, loc="lower left"); a2.set_title("(b) V-C3: repaired ellipses", fontsize=8.5, color=INK)
fig.tight_layout(); fig.savefig(os.path.join(H, "fig", "v3_index_repair.png"), dpi=220); plt.close(fig)
print("ok")
