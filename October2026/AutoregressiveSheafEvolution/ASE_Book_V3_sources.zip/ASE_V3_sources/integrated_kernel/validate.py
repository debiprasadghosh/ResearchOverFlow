"""Independent NumPy/SciPy recomputation of every line printed by the third-edition C# kernel.
Random inputs are regenerated from the same SplitMix64 counters (vectorised); algorithms differ
where possible (SVD, quad, eigh, analytic forms). Writes validate.json."""
import json, math, os, sys
import numpy as np
from scipy import integrate, special, linalg

H = os.path.dirname(os.path.abspath(__file__))
G = np.uint64(0x9E3779B97F4A7C15)


def uniforms(seed, start, count):
    """Uniforms number start .. start+count-1 of the stream with the given seed."""
    with np.errstate(over="ignore"):
        k = np.arange(start + 1, start + count + 1, dtype=np.uint64)
        z = np.uint64(seed) + k * G
        z = (z ^ (z >> np.uint64(30))) * np.uint64(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> np.uint64(27))) * np.uint64(0x94D049BB133111EB)
        z = z ^ (z >> np.uint64(31))
    return (z >> np.uint64(11)).astype(np.float64) * (1.0 / 9007199254740992.0)


def normals_from(u):
    u = u.reshape(-1, 2)
    return np.sqrt(-2 * np.log(1 - u[:, 0])) * np.cos(2 * np.pi * u[:, 1])


out = {}
# ---------------- Part VI, Section 2.2
L = np.array([-1e20, -1e20]); M = L.max()
lse = M + np.log(np.exp(L - M).sum())
out["softmax_extreme_divfree"] = list(np.exp(L - lse))
b = np.exp(L - M); out["softmax_extreme_shiftdivide"] = list(b / b.sum())
out["read_extreme"] = [float(np.exp(L - lse) @ [1, 3]), float(b / b.sum() @ [1, 3])]
out["contract_rejections"] = [1, 1, 1, 1, 1, 1, 0]
Yt = np.array([[0, 0], [1, 0], [0, 1.0]]); zt = np.array([0.2, 0.2]); d2 = ((Yt - zt) ** 2).sum(1); o = np.argsort(d2)
lk = special.logsumexp(-d2[o[:2]] / (2 * .25)); lo = math.log(1) + 0 - d2[o[2]] / (2 * .25)
out["certificate_k_equals_n"] = [0.0, 1 / (1 + math.exp(lk - lo))]

# ---------------- Part IV
def m2(Sp, Sq):
    K = 2 * Sq - Sp
    return math.inf if np.linalg.eigvalsh(K).min() <= 0 else np.linalg.det(Sq) / math.sqrt(np.linalg.det(Sp) * np.linalg.det(K))
Q = np.array([[1, .6], [.6, 1]])
out["iv_path_m2"] = [m2(np.array([[.5]]), np.array([[1.]])), m2(np.array([[.5, .3], [.3, .64 + .36 * .5]]), Q),
                     m2(np.diag([.5, 1.]), Q)]
pi_ = lambda x: math.exp(-x * x / 2) / math.sqrt(2 * math.pi)
for R in (2, 4, 8, 12):
    two = integrate.quad(lambda x: pi_(x) ** 2 / (0.5 * (math.exp(-(x - 1) ** 2) + math.exp(-(x + 1) ** 2)) / math.sqrt(math.pi)), -R, R, epsabs=1e-14, epsrel=1e-13, limit=200)[0]
    one = 2 * R * (1 / (2 * math.pi)) * math.sqrt(math.pi)          # pi^2/q is the constant 1/(2 sqrt(pi))
    out[f"iv_critical_R{R}"] = [two, one]
out["iv_critical_closed"] = [math.e * math.sqrt(math.pi) / 4]
def tilt(v, k, beta=1):
    a = beta ** 2 * v / (2 * k); nu = k - 1; return a - nu / 2 * math.log1p(2 * a / nu)
for k in (2, 4, 8):
    dens = lambda x: math.exp(-x * x + tilt((0.5 + 0.5 * abs(x)) ** 2, k))
    num = 2 * integrate.quad(lambda x: x * x * dens(x), 0, np.inf, epsabs=1e-15, epsrel=1e-13)[0]
    den = 2 * integrate.quad(dens, 0, np.inf, epsabs=1e-15, epsrel=1e-13)[0]
    out[f"iv_plugin_k{k}"] = [num / den, tilt(1, k)]
mass, loss = np.array([.2, .5, .3]), np.array([0, 1, 4.])
Zb = lambda t: (mass * np.exp(-t * loss)).sum()
p = mass * np.exp(-.8 * loss) / Zb(.8); q = mass * np.exp(-1. * loss) / Zb(1.)
out["iv_tempering"] = [Zb(.8) * Zb(1.2) / Zb(1.) ** 2, math.exp(.04 * 16 / 4), .5 * np.abs(p - q).sum(), math.tanh(.2)]
Bn = linalg.null_space(np.array([[1., 1, 0]]))
out["iv_gram"] = [abs(np.linalg.det(np.diag([2., 3.])))]       # orthonormal basis times diag(2,3)
lg = math.log(2 * 6 * 13 * 6 / .05)
out["iv_family_radius"] = [1 / .25 * math.sqrt(2 * lg / 1600), math.floor(2 * lg * (2 / (.25 * .12786)) ** 2) + 1]
for bta in (2, 8, 32, 128):
    zz = math.sqrt(math.pi / bta) * special.erf(math.sqrt(bta))
    tail = math.sqrt(math.pi / bta) * (special.erf(math.sqrt(bta)) - special.erf(math.sqrt(bta) * .5)) / zz
    out[f"iv_concentration_b{bta}"] = [tail, math.exp(-bta * .125) / math.sqrt(.125)]

# ---------------- Part V
init = np.array([.35, .65]); T = [np.array([[.8, .2], [.25, .75]]), np.array([[.6, .4], [.1, .9]]), np.array([[.7, .3], [.2, .8]])]
P4 = np.einsum("a,ab,bc,cd->abcd", init, *T)
e01, e12, e23 = P4.sum((2, 3)), P4.sum((0, 3)), P4.sum((0, 1)); n1, n2 = P4.sum((0, 2, 3)), P4.sum((0, 1, 3))
naive = np.einsum("ab,bc,cd->abcd", e01, e12, e23); naive /= naive.sum()
tree = np.einsum("ab,bc,cd->abcd", e01, e12, e23) / (n1[None, :, None, None] * n2[None, None, :, None])
out["v_chain_tv"] = [.5 * np.abs(P4 - naive).sum(), .5 * np.abs(P4 - tree).sum()]
Rm = np.full((5, 5), -.4) + np.eye(5) * 1.4
out["v_repair"] = [np.linalg.eigvalsh(Rm).min(), -.25, math.sqrt(20) * .15]
c = np.array([1, 1, 0]) / math.sqrt(2); mu = np.array([1, 0, .4]); r0 = c @ mu - .3
for g in (1, 10, 100, 1000, 10000):
    rg, vg = r0 / (1 + g), 1 / (1 + g)
    out[f"v_penalty_g{g}"] = [abs(rg), math.sqrt(rg * rg + vg)]
def blocks(C):
    U, s, Vt = np.linalg.svd(C); Vr = Vt[:len(s[s > 1e-12 * s.max()])]; Q = Vr.T @ Vr
    import scipy.sparse.csgraph as cg
    n, lab = cg.connected_components((np.abs(Q) > 1e-12).astype(int), directed=False)
    first = {}; return [float(min(i for i in range(len(lab)) if lab[i] == lab[j])) for j in range(len(lab))]
C5 = np.array([[1., 1, 0, 0, 0], [0, 0, 0, 1, 1]]); Mx = np.array([[2., 2, 0, 3, 3], [1, 1, 0, -1, -1]])
out["v_blocks"] = blocks(C5); out["v_blocks_mixed_basis"] = blocks(Mx)
def leak(C, blk):
    U, s, Vt = np.linalg.svd(C); Vr = Vt[:len(s[s > 1e-12 * s.max()])]; Q = Vr.T @ Vr
    Pb = np.diag([1. if i in blk else 0. for i in range(C.shape[1])])
    return np.linalg.norm(Q @ Pb @ (np.eye(C.shape[1]) - Q), 2)
out["v_leakage"] = [leak(C5, [0]), leak(np.array([[1., 1e-6]]), [0])]
out["v_five_point_coverage"] = [0.8]
Ccyc = np.array([[-1., 1, 0], [0, -1, 1], [1, 0, -1]]); bb = np.ones(3)
x_ls = np.linalg.lstsq(Ccyc, bb, rcond=None)[0]; out["v_cycle_residual"] = [np.linalg.norm(bb - Ccyc @ x_ls)]
objs = np.array([[0, 2], [1, 1.5], [2, 0.]])
out["v_chebyshev"] = list((np.array([.5, .4]) * (objs + 1)).max(1))
# a point is supported iff it lies on the lower convex hull with a strictly positive normal
sup = []
for k in range(3):
    ok = False
    for l1 in np.arange(1, 10000) / 10000:
        v = objs @ [l1, 1 - l1]
        if v[k] <= v.min() + 1e-15: ok = True; break
    sup.append(1. if ok else 0.)
out["v_weighted_sum_support"] = sup
rho = np.full(4, .25); j1, j2 = np.arange(4.), np.array([1.5, 1.5, .2, 2.5])
z1, z2 = (rho * np.exp(-j1)).sum(), (rho * np.exp(-j2)).sum()
out["v_preference"] = [.5 * z1 / (.5 * z1 + .5 * z2), .5]
# ambient-indefinite example by the Schur-free KKT system
Hm = np.diag([-2., 1, 3]); Cm = np.array([[1., 0, 0]])
K = np.block([[Hm, Cm.T], [Cm, np.zeros((1, 1))]]); sol = np.linalg.solve(K, np.r_[[0, 1, 2.], .5])
out["v_indefinite"] = list(sol[:3])
nrm = normals_from(uniforms(20261022, 0, 120 * 84 * 2)).reshape(120, 84)
wf = ws = wr = 0; first = None
for t in range(120):
    a = nrm[t]; Gm = a[:49].reshape(7, 7); Hh = Gm.T @ Gm + np.eye(7); Cc = a[49:70].reshape(3, 7); gv = a[70:77]; dv = a[77:80]; pert = a[80:84]
    N = linalg.null_space(Cc); xp = np.linalg.lstsq(Cc, dv, rcond=None)[0]
    HN = N.T @ Hh @ N; x = xp + N @ np.linalg.solve(HN, N.T @ (gv - Hh @ xp))
    lam = np.linalg.lstsq(Cc.T, -(Hh @ x - gv), rcond=None)[0]
    if first is None: first = x
    wf = max(wf, np.linalg.norm(Cc @ x - dv)); wr_ = None
    # certificate on the same perturbation: the kernel's own null basis may differ by a rotation, so
    # the ratio is basis-dependent only through the perturbation direction; recompute with eigh basis
    w, V = np.linalg.eigh(Cc.T @ Cc); Nb = V[:, w <= 1e-12 * w.max()]
    xh = x + 1e-3 * (Nb @ pert); rr = Hh @ xh - gv + Cc.T @ lam
    mu_ = np.linalg.eigvalsh(Nb.T @ Hh @ Nb).min()
    wr = max(wr, np.linalg.norm(xh - x) / (np.linalg.norm(Nb.T @ rr) / mu_))
out["v_sections"] = [wf, None, wr]
out["v_sections_first"] = list(first)

# ---------------- Part VI
g_, a_ = np.array([8., 2, 1]), np.array([1., 4, 1])
eps = .01 * np.sqrt(a_ / g_) / np.sqrt(a_ * g_).sum()
out["vi_allocation"] = [*eps, (a_ / eps).sum(), (a_ / (.01 / 3 / g_)).sum(), (a_ / (.01 / g_.sum())).sum()]
out["vi_release"] = [-.002, .002, 0]
out["vi_identical"] = [(1 - 1e-6) ** 1000]
rad = lambda m, k: 2 * math.sqrt(math.log(2 * m * k * (k + 1) / .05) / (2 * k))
out["vi_cs_radius"] = [rad(3, 10000)]

# ---------------- Explorations
U = uniforms(20261031, 0, 200 * 10000 * 4).reshape(200, 10000, 4)
eff = np.array([.05, .10, .18]); kk = np.arange(1, 10001)[:, None]; rk = 2 * np.sqrt(np.log(2 * 3 * kk * (kk + 1) / .05) / (2 * kk))
miss = 0
for run in range(200):
    b0 = (U[run, :, 0] < .5).astype(float); D = (U[run, :, 1:] < .5 + eff).astype(float) - b0[:, None]
    mean = np.cumsum(D, 0) / kk
    miss += np.any(np.abs(mean - eff) > rk)
    if run == 0:
        clr = mean - rk > .05; fc = [float(np.argmax(clr[:, j]) + 1) if clr[:, j].any() else 0. for j in range(3)]
out["x_cs_study"] = [miss / 200, *fc, rad(3, 10000)]

R_, Tn = 400, 16000
U = uniforms(20261032, 0, R_ * Tn * 3).reshape(R_, Tn, 3)
Z = np.sqrt(-2 * np.log(1 - U[:, :, 1])) * np.cos(2 * np.pi * U[:, :, 2])
truth = .5 * special.erfc(.5); phi = lambda x, m, s: np.exp(-(x - m) ** 2 / (2 * s * s)) / (s * math.sqrt(2 * math.pi))
m = np.zeros(R_); sw = np.zeros(R_); swf = np.zeros(R_); worst = np.zeros(R_)
for t in range(1, Tn + 1):
    u = U[:, t - 1, 0]; z = Z[:, t - 1]; x = np.where(u < .25, z, m + .8 * z)
    qd = .25 * phi(x, 0, 1) + .75 * phi(x, m, .8); w = phi(x, 0, 1) * np.exp(-x * x / 2) / qd
    sw += w; swf += np.where(x > .5, w, 0)
    an = math.sqrt(math.log(2 * t * (t + 1) / .05) / (2 * t * .0625)); bound = np.minimum(1, an / (sw / t))
    worst = np.maximum(worst, np.abs(swf / sw - truth) / bound); m = .99 * m + .01 * np.tanh(x)
out["x_adaptive_study"] = [float((worst > 1).mean()), float(np.median(worst)), float(np.abs(swf / sw - truth).mean())]

for k in (1, 4):
    n = 2_000_000
    U = uniforms(20261033 + k, 0, n * (2 + 2 * k)).reshape(n, 2 + 2 * k)
    x = np.sqrt(-2 * np.log(1 - U[:, 0])) * np.cos(2 * np.pi * U[:, 1])
    e = np.sqrt(-2 * np.log(1 - U[:, 2::2])) * np.cos(2 * np.pi * U[:, 3::2])
    v = (0.5 + 0.5 * np.abs(x)) ** 2
    # the kernel accumulates the k replicates sequentially; replicate that order
    jbar = np.zeros(n)
    for r in range(k): jbar += x * x / 2 + np.sqrt(v) * e[:, r]
    jbar /= k
    wc = np.exp(-jbar - v / (2 * k)); wu = np.exp(-jbar)
    m2p = 2 * integrate.quad(lambda y: math.exp(-1.5 * y * y + (0.5 + 0.5 * y) ** 2 / k) * math.sqrt(2 * math.pi) / math.pi, 0, np.inf, epsabs=1e-14, epsrel=1e-12)[0]
    out[f"x_critic_k{k}"] = [(wc * x * x).sum() / wc.sum(), (wu * x * x).sum() / wu.sum(), n * (wc ** 2).sum() / wc.sum() ** 2, m2p]

Pc = [np.array([[1, .3, 0], [.3, .5, .1], [0, .1, .8]]), np.array([[.6, -.2, .1], [-.2, 1.2, 0], [.1, 0, .7]]),
      np.array([[.9, 0, -.3], [0, .4, .1], [-.3, .1, 1.1]])]
Cr = np.ones((1, 3)); q90 = -2 * math.log(.1)
Pi_ = [np.linalg.inv(p_) for p_ in Pc]; Pw = np.linalg.inv(sum(Pi_) / 3); Pp = np.linalg.inv(sum(Pi_))
Nb = linalg.null_space(Cr)
def rep(P):
    Tm = np.eye(3) - P @ Cr.T @ np.linalg.inv(Cr @ P @ Cr.T) @ Cr; return Tm, np.linalg.inv(Nb.T @ Tm @ P @ Tm.T @ Nb)
Tci, Ici = rep(Pw); Tpo, Ipo = rep(Pp); Ls = [np.linalg.cholesky(p_) for p_ in Pc]
for corr in (0.0, 0.5, 0.9):
    n = 40000
    Zs = normals_from(uniforms(20261034, 0, n * 24)).reshape(n, 4, 3)
    g0 = Zs[:, 0]; errs = [ (math.sqrt(corr) * g0 + math.sqrt(1 - corr) * Zs[:, 1 + e]) @ Ls[e].T for e in range(3)]
    eci = sum((Pi_[e] / 3 @ errs[e].T).T for e in range(3)) @ Pw.T
    epo = sum((Pi_[e] @ errs[e].T).T for e in range(3)) @ Pp.T
    uci = (eci @ Tci.T) @ Nb; upo = (epo @ Tpo.T) @ Nb
    out[f"x_repair_c{corr:g}"] = [float((np.einsum("ij,jk,ik->i", uci, Ici, uci) <= q90).mean()),
                                  float((np.einsum("ij,jk,ik->i", upo, Ipo, upo) <= q90).mean())]

def build(Y, lw, items, leaf):
    lo, hi = Y[items].min(0), Y[items].max(0); lm = special.logsumexp(lw[items])
    if len(items) <= leaf: return dict(lo=lo, hi=hi, lm=lm, items=items, kids=None)
    ext = hi - lo; axis = int(np.flatnonzero(ext == ext.max())[0])
    srt = sorted(items, key=lambda i: (Y[i, axis], i)); h = len(srt) // 2
    return dict(lo=lo, hi=hi, lm=lm, items=items, kids=(build(Y, lw, srt[:h], leaf), build(Y, lw, srt[h:], leaf)))
def traverse(root, Y, lw, z, s, tol):
    lg_ = lw - ((Y - z) ** 2).sum(1) / (2 * s * s)
    bnd = lambda nd: nd["lm"] - (np.clip(nd["lo"] - z, 0, None) ** 2 + np.clip(z - nd["hi"], 0, None) ** 2).sum() / (2 * s * s)
    fr = [(bnd(root), root)]; kept = []; vis = 0
    while True:
        lk = special.logsumexp(lg_[kept]) if kept else -np.inf; lo_ = special.logsumexp([f[0] for f in fr]) if fr else -np.inf
        share = 0 if lo_ == -np.inf else (1 if lk == -np.inf else 1 / (1 + math.exp(lk - lo_)))
        if share <= tol or not fr: break
        best = 0
        for i in range(1, len(fr)):
            if fr[i][0] > fr[best][0]: best = i
        nd = fr.pop(best)[1]; vis += 1
        if nd["kids"] is None: kept += list(nd["items"])
        else: fr.append((bnd(nd["kids"][0]), nd["kids"][0])); fr.append((bnd(nd["kids"][1]), nd["kids"][1]))
    full = np.exp(lg_ - special.logsumexp(lg_)); part = np.exp(lg_[kept] - special.logsumexp(lg_[kept]))
    true_share = 1 - full[kept].sum(); err = np.linalg.norm(full @ Y - part @ Y[kept])
    diam = np.linalg.norm(Y.max(0) - Y.min(0))
    return len(kept), vis, share, true_share, err, share * diam
for d in (2, 4, 8, 16):
    seed = 20261040 + d; Y = uniforms(seed, 0, 4096 * d).reshape(4096, d); lw = np.zeros(4096); pos = 4096 * d
    root = build(Y, lw, list(range(4096)), 16); sp = 4096 ** (-1 / d)
    for cf in (0.25, 0.5, 1.0):
        fr_, nd_, viol = [], [], 0
        for qi in range(20):
            z = .25 + .5 * uniforms(seed, pos, d); pos += d
            kept, vis, share, ts, err, eb = traverse(root, Y, lw, z, cf * sp, 1e-3)
            fr_.append(kept / 4096); nd_.append(vis); viol += (ts > share + 1e-12) or (err > eb + 1e-12)
        out[f"x_index_d{d}_c{cf:g}"] = [float(np.median(fr_)), max(fr_), float(np.median(nd_)), viol]

# ---------------- compare
cs = {l.split()[0]: [float(t) for t in l.split()[1:]] for l in open(os.path.join(H, "cs", "cs_out.txt")) if l.strip()}
rows = []; ok = True
for name, cval in cs.items():
    py = out[name]
    if name == "v_sections":                  # stationarity residual is a kernel-only roundoff quantity
        py = [py[0], cval[1], py[2]]
    diffs = []
    for a, b_ in zip(cval, py):
        b_ = float(b_)
        if math.isinf(a) and math.isinf(b_): diffs.append(0.0); continue
        diffs.append(abs(a - b_) / max(abs(b_), 1e-300) if b_ != 0 else abs(a))
    rel = max(diffs)
    if name.startswith("v_sections_first") or name == "v_sections":
        tol = 1e-9 if name == "v_sections_first" else None
    tol = {"v_sections": None}.get(name, 1e-9)
    if name in ("iv_critical_R2", "iv_critical_R4", "iv_critical_R8", "iv_critical_R12", "iv_plugin_k2", "iv_plugin_k4", "iv_plugin_k8",
                "iv_concentration_b2", "iv_concentration_b8", "iv_concentration_b32", "iv_concentration_b128", "x_critic_k1", "x_critic_k4"):
        tol = 1e-7                             # Simpson quadrature against adaptive quadrature
    if name == "v_sections":
        passed = cval[0] < 1e-12 and py[0] < 1e-12 and cval[1] < 1e-12 and cval[2] <= 1 and py[2] <= 1   # ratio depends on the null basis
    else:
        absd = max(abs(a - float(b_)) for a, b_ in zip(cval, py) if not (math.isinf(a) and math.isinf(float(b_))))
        passed = rel < tol or absd < 1e-13
    ok = ok and passed
    rows.append(dict(name=name, csharp=cval, python=[float(v) for v in py], rel=rel, passed=bool(passed)))
json.dump(dict(rows=rows, all_passed=bool(ok), lines=len(rows)), open(os.path.join(H, "validate.json"), "w"), indent=1)
for r in rows:
    if not r["passed"] or r["rel"] > 1e-12: print("PASS" if r["passed"] else "FAIL", r["name"], r["rel"], r["csharp"][:4], r["python"][:4])
print("ALL", ok, len(rows))
