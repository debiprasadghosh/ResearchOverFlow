# ADC Version 2 additions

Version 2 adds four exact studies (paper Section 10) without changing the Version 1 suite.

- `kernel/DoNumerics.cs`: response-function witness synthesis, exact rational simplex for fibre bounds,
  the event-replacement census and the frozen clock-deletion test. Run with the `--v2` flag.
- `validate_v2.py` (+ `_shared_v1.py`, copied verbatim from `validate_adc.py`): independent validation.
- `cs_v2.txt`, `validation_v2.json`, `out_v2/`: summary lines, validation record and result files.
- `fig_v2.py`, `figures/v2_fibres_replacement.png`: Figure 3.
- `build_v2.py`: splices Section 10 and the related updates into the Version 1 Word file.

```bash
dotnet build kernel/Adc.csproj -c Release
dotnet kernel/bin/Release/net8.0/Adc.dll output > cs_results.txt          # Version 1, unchanged
dotnet kernel/bin/Release/net8.0/Adc.dll out_v2 --v2 > cs_v2.txt          # Version 2 studies
python validate_adc.py                                                      # Version 1 validator
python validate_v2.py cs_v2.txt out_v2 validation_v2.json                  # Version 2 validator
```

Verified with .NET SDK 8.0.131, Python 3.13.16, SymPy 1.14.0, SciPy 1.18.1, NumPy 2.5.3 and y0 0.2.11.
Seeds: 20261030070 (witness base models), 20261030071 (fibre models), 20261030072 (census), 20261030073 (clock narratives).
