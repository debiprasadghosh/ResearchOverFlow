"""Build Version 2 of 'Autoregressive Do Calculus (ADC)' from the supplied V1 Word file.

V1 is edited in place: its text, equations, tables and figures are kept. New material is converted
by Pandoc with V1 as the reference document; tables copy V1's table look. Every number is read
from the validated --v2 kernel output or its JSON/CSV files."""
import copy, json, os, re, subprocess, sys, tempfile, zipfile, shutil
from fractions import Fraction as F
from docx import Document
from docx.shared import Inches
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from lxml import etree

H = os.path.dirname(os.path.abspath(__file__)); SRC = os.path.join(os.path.dirname(H), "in", "v1.docx")
OUT = os.path.join(H, "ADC_V2.docx"); O2 = os.path.join(H, "out_v2")
cs = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1].split() for l in open(os.path.join(H, "cs_v2.txt"))}
val = json.load(open(os.path.join(H, "validation_v2.json"))); assert val["all_passed"]
W_ = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"; WNS = f'xmlns:w="{W_}"'

def num(x): return f"{x:,}"
def pct(a, b, d=1): return f"{100 * a / b:.{d}f}%"
def fr(t):
    q = F(t); return str(q.numerator) if q.denominator == 1 else f"{q.numerator}/{q.denominator}"

# ------------------------------------------------------------------ numbers
w3 = list(map(int, cs["witness_n3"][:8])); w4 = list(map(int, cs["witness_n4"][:8]))
later = int(cs["witness_n3"][9]) + int(cs["witness_n4"][9])
fb = list(map(int, cs["fibre_bounds"])); fw = cs["fibre_widths"]
bow = cs["fibre_bow"]; iv = cs["fibre_iv"]
rc = list(map(int, cs["replacement_census"])); rg = cs["replacement_gaps"]
cd = list(map(int, cs["clock_deletion"]))
W = json.load(open(os.path.join(O2, "witnesses.json")))
from collections import Counter
sizes = Counter(bin(q["district"]).count("1") for q in W["queries"] if q["district"])
pairwise = sum(1 for q in W["queries"] if q["district"] and all(bin(m).count("1") <= 2 for m in W["graphs"][q["graph"]]["districts"]))
R = json.load(open(os.path.join(O2, "fibres.json")))
nonid_tighter = sum(1 for r in R if not r["identified"] and (F(r["naturalLo"]) < F(r["lo"]) or F(r["hi"]) < F(r["naturalHi"])))
nonid_equal = sum(1 for r in R if not r["identified"] and F(r["naturalLo"]) == F(r["lo"]) and F(r["hi"]) == F(r["naturalHi"]))
y0d = next(c for c in val["checks"] if c["name"] == "witness_y0_decisions")["detail"]
y0n, y0e = re.findall(r"\d+", y0d)[0], re.findall(r"\d+", y0d)[-1]
witness_total = w3[4] + w4[4]; fail_total = w3[3] + w4[3]; q_total = w3[1] + w4[1]
forbidden_strict = cd[3] - cd[5]

doc = Document(SRC); body = doc.element.body

def fragment(md):
    with tempfile.TemporaryDirectory() as td:
        open(os.path.join(td, "f.md"), "w", encoding="utf-8").write(md)
        subprocess.run(["pandoc", "f.md", "-f", "markdown+tex_math_dollars-auto_identifiers", "-o", "f.docx", f"--reference-doc={SRC}"], cwd=td, check=True)
        f = Document(os.path.join(td, "f.docx"))
        els = [copy.deepcopy(e) for e in f.element.body if e.tag != qn("w:sectPr")]
    for e in els:
        for b in list(e.iter(qn("w:bookmarkStart"))) + list(e.iter(qn("w:bookmarkEnd"))): b.getparent().remove(b)
    return els

def style_table(tbl, widths):
    tp = tbl.find(qn("w:tblPr"))
    for ch in list(tp): tp.remove(ch)
    for ch in etree.fromstring(f'<w:tblPr {WNS}><w:tblW w:w="9648" w:type="dxa"/><w:jc w:val="center"/><w:tblBorders>' +
                               "".join(f'<w:{s} w:val="single" w:sz="4" w:color="D9D9D9"/>' for s in ("top", "left", "bottom", "right", "insideH", "insideV")) +
                               '</w:tblBorders><w:tblLayout w:type="fixed"/></w:tblPr>'): tp.append(ch)
    for gc, w in zip(tbl.find(qn("w:tblGrid")).findall(qn("w:gridCol")), widths): gc.set(qn("w:w"), str(w))
    for ri, tr in enumerate(tbl.findall(qn("w:tr"))):
        trpr = tr.find(qn("w:trPr"))
        if trpr is None: trpr = OxmlElement("w:trPr"); tr.insert(0, trpr)
        for ch in list(trpr): trpr.remove(ch)
        trpr.append(OxmlElement("w:cantSplit"))
        if ri == 0: trpr.append(OxmlElement("w:tblHeader"))
        for tc, w in zip(tr.findall(qn("w:tc")), widths):
            tcpr = tc.find(qn("w:tcPr"))
            if tcpr is None: tcpr = OxmlElement("w:tcPr"); tc.insert(0, tcpr)
            for ch in list(tcpr): tcpr.remove(ch)
            fill = "EDF0F2" if ri == 0 else "FFFFFF"
            for ch in etree.fromstring(f'<w:tcPr {WNS}><w:tcW w:w="{w}" w:type="dxa"/><w:shd w:val="clear" w:fill="{fill}"/><w:tcMar><w:top w:w="85" w:type="dxa"/>'
                                       '<w:left w:w="85" w:type="dxa"/><w:bottom w:w="85" w:type="dxa"/><w:right w:w="85" w:type="dxa"/></w:tcMar><w:vAlign w:val="center"/></w:tcPr>'): tcpr.append(ch)
            for p in tc.findall(qn("w:p")):
                ppr = p.find(qn("w:pPr"))
                if ppr is None: ppr = OxmlElement("w:pPr"); p.insert(0, ppr)
                for ch in list(ppr): ppr.remove(ch)
                for ch in etree.fromstring(f'<w:pPr {WNS}><w:pStyle w:val="BodyText"/><w:keepNext w:val="0"/><w:spacing w:before="0" w:after="30" w:line="252" w:lineRule="auto"/><w:jc w:val="left"/></w:pPr>'): ppr.append(ch)
                for r in p.findall(qn("w:r")):
                    rpr = r.find(qn("w:rPr"))
                    if rpr is None: rpr = OxmlElement("w:rPr"); r.insert(0, rpr)
                    for x in rpr.findall(qn("w:b")): rpr.remove(x)
                    b = OxmlElement("w:b")
                    if ri != 0: b.set(qn("w:val"), "0")
                    rpr.insert(0, b)
                    if rpr.find(qn("w:sz")) is None: sz = OxmlElement("w:sz"); sz.set(qn("w:val"), "20"); rpr.append(sz)

def caption(text, keep=True):
    p = OxmlElement("w:p"); ppr = OxmlElement("w:pPr"); ps = OxmlElement("w:pStyle"); ps.set(qn("w:val"), "Caption"); ppr.append(ps)
    kn = OxmlElement("w:keepNext")
    if not keep: kn.set(qn("w:val"), "0")
    ppr.append(kn); p.append(ppr)
    r = OxmlElement("w:r"); t = OxmlElement("w:t"); t.text = text; t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve"); r.append(t); p.append(r)
    return p

def table(rows, widths, cap):
    els = fragment("\n".join(rows) + "\n")
    for e in els:
        if e.tag == qn("w:tbl"): style_table(e, widths)
    return [caption(cap)] + els

def figure(path, cap, alt):
    p = doc.add_paragraph(style="Body Text"); p.alignment = 1
    run = p.add_run(); run.add_picture(path, width=Inches(6.45))
    el = p._p; el.getparent().remove(el)
    ppr = el.find(qn("w:pPr")); ps = ppr.find(qn("w:pStyle")); ps.addnext(OxmlElement("w:keepNext"))
    for d in el.iter("{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}docPr"): d.set("descr", alt)
    return [el, caption(cap, keep=False)]

def find(start, style=None):
    for p in doc.paragraphs:
        if p.text.replace("\xa0", " ").replace("\u2019", "'").startswith(start) and (style is None or p.style.name == style): return p
    raise KeyError(start)

def after(anchor, els):
    ref = anchor
    for e in els: ref.addnext(e); ref = e

def append_text(p, text):
    r = OxmlElement("w:r"); t = OxmlElement("w:t"); t.text = text
    t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve"); r.append(t); p._p.append(r)

def set_text(p, text):
    ts = list(p._p.iter(qn("w:t")))
    for t in ts: t.text = ""
    ts[0].text = text

# ------------------------------------------------------------------ front matter
set_text(find("30 October 2026", "Date"), "Version 2 · 30 October 2026")
append_text(find("Autoregressive models provide observational conditionals"), (
    f" Version 2 adds four exact studies in C#. A response-function construction produced an exact pair of positive "
    f"models with equal observational laws and different query values for every one of {num(fail_total)} ID failures among "
    f"{num(q_total)} joint queries on three- and four-event graphs with clique districts, and for no identified query. "
    f"Exact linear programming over observational fibres returned zero width for all {fb[2]} identified queries and positive "
    f"width for all {fb[5]} non-identified ones. Across {num(rc[0])} event-replacement cases, the certificate held in "
    f"{num(rc[1])} with zero error, and every uncertified case erred, including {num(rc[5])} whose joint intervention was identified. "
    f"In a frozen test of clock-licensed action deletion, point dates produced invalid deletions in {pct(cd[3], cd[1])} of "
    f"{num(cd[1])} queries, while certified deletions retained {pct(cd[8], cd[6])} of those the true dates allow and none was invalid."))
append_text(find("The numerical material consists of finite mathematical checks."), (
    " Version 2 turns two of the paper's stated limits into computations: carried non-identification witnesses are now "
    "synthesised for a stated graph class, and the clock comparison C2 is tested with causal queries rather than event pairs. "
    "It also computes sharp bounds on observational fibres and a census of event-replacement errors (Section 10)."))
set_text(find("Section 2 defines the model and query types."), (
    "Section 2 defines the model and query types. Section 3 separates the mechanism sheaf from the law presheaf. Sections 4 "
    "and 5 develop certified derivations and autoregressive identification factors. Sections 6 and 7 treat clocks and "
    "generator interventions. Section 8 establishes credal precision results. Section 9 reports the finite checks and the "
    "status of the proposed comparisons. Section 10 adds the Version 2 studies: exact witnesses, fibre bounds, a replacement "
    "census and a semantic clock test. Section 11 concludes. Appendix A lists assumptions, and Appendix B specifies the "
    "reference kernel and reproduction record."))
append_text(find("A graph's arrows describe allowed inputs, so model A may ignore them."),
            " Version 2 synthesises such pairs automatically for graphs whose districts are bidirected cliques (Section 10.1).")
append_text(find("C2 hypothesis on clock-aware causal answers."),
            f" Version 2 runs this test with causal queries and reports its outcome against the proposal's frozen thresholds in Section 10.4.")
append_text(find("C3 conjecture on learned autoregressive models."),
            " Section 10.3 computes the exact limiting gap Δ for every position of every four-event ADMG in a fixed mechanism family.")
append_text(find("A failure trace is not an automatically synthesized pair of models."),
            " Section 10.1 narrows this limit: for clique-district graphs the kernel now returns an exact pair of models with every failure.")

# ------------------------------------------------------------------ Section 10
S10a = f"""
# 10 Extended do-numerics

Version 2 adds four exact studies. Each one turns a statement or a stated limit of the earlier sections into a computation with an independent check. The kernel runs them with a separate flag, so the Version 1 suite and its 21 summary lines reproduce byte for byte. A second Python program recomputes every new line; Appendix B.4 records the routes.

## 10.1 Exact non-identification witnesses

Theorem 3.4 makes a pair of models with equal observational laws and different query values a complete semantic certificate of non-identification. Section 5.3 supplied one such pair by hand. Response functions make the construction mechanical for a broad class (Balke & Pearl, 1997).

**Proposition 10.1 (witnesses from one district).** Let every district of $G$ be a bidirected clique, and let each district $D$ carry one latent variable whose values are the joint deterministic response types of its binary members, with law $q_D$. Fix the laws of the other districts. For each $v$ and $t$, write $a_{{vt}}=1$ when type $t$ reproduces $v_D$ from $v$, and $c_t$ for the coefficient of $q_D(t)$ in the query value. If $\\sum_t a_{{vt}}\\delta_t=0$ for every $v$ and $c\\cdot\\delta\\neq0$, then $q_D$ and $q_D+\\varepsilon\\delta$, with $0<\\varepsilon<\\min_t q_D(t)/\\max_t|\\delta_t|$, define two positive models with equal observational laws whose query values differ by $\\varepsilon|c\\cdot\\delta|$.

*Proof.* By the factorisation of Theorem 5.1, each observational cell is the product of the other districts' fixed factors and $\\sum_t a_{{vt}}q_D(t)$. The fixed factors are positive and do not depend on $q_D$, so the perturbation leaves every cell unchanged. The query value is likewise linear in $q_D$ with coefficients $c_t$, and changes by $\\varepsilon\\,c\\cdot\\delta$. The bound on $\\varepsilon$ keeps every type probability positive. Theorem 3.4 then proves non-identification. ∎

For a two-member district the latent is the shared primitive of Definition 2.1. For a larger clique it is a common latent of the whole district, the usual latent-projection reading of a bidirected clique, and the class is broader than Definition 2.1's pairwise primitives. A witness proves non-identification in the class it belongs to. The kernel finds $\\delta$ by exact rational row reduction of the matrix $(a_{{vt}})$, testing each query cell against its row space. The other districts' laws are random positive rationals. If a draw happens to make all query rows dependent, the kernel retries with up to two further draws.

The study covers every graph on three and four ordered events whose districts are cliques and whose members have at most two parents, so that each member has at most 16 response types. That gives {w3[0]} and {w4[0]} graphs, and every nonempty disjoint action and outcome set, {num(q_total)} joint queries in all (Table 4).
"""
t4 = ["| Events | Graphs | Joint queries | ID identifies | ID fails | Exact witness pairs | Witness on an identified query | Largest district type count |",
      "|:--|:--|:--|:--|:--|:--|:--|:--|",
      f"| 3 | {w3[0]} | {num(w3[1])} | {num(w3[2])} | {w3[3]} | {w3[4]} | {w3[5]} | {w3[7]} |",
      f"| 4 | {w4[0]} | {num(w4[1])} | {num(w4[2])} | {num(w4[3])} | {num(w4[4])} | {w4[5]} | {num(w4[7])} |"]
S10a2 = f"""
Every ID failure received an exact witness pair, and no identified query did. Of the witnesses, {later} needed a second random draw of the other districts. The witness district had two members in {num(sizes[2])} pairs, three in {num(sizes[3])} and four in {num(sizes[4])}. In {num(pairwise)} pairs every district of the graph has at most two members, so both models lie in the pairwise class of Definition 2.1. The smallest certified difference between the two query values was {fr(cs['witness_n4'][8])}.

The Python validator decodes the response types independently and checks each certificate exactly: the perturbation annihilates every observational cell, changes the query by the reported amount, and keeps the second model positive. For {num(int(re.findall(r'[0-9]+', next(c for c in val['checks'] if c['name'] == 'witness_full_enumeration')['detail'])[0]))} pairs it also enumerates both complete models and compares their observational and interventional laws directly. Its own ID recursion agrees on all {num(q_total)} decisions, and y0 agrees on all {num(int(y0n))} queries it completed in a sample. A further {y0e} sampled queries stopped with an internal y0 error on graphs that contain a vertex without directed edges; they are excluded and reported, not counted as agreement.

This is an empirical completeness result for the witness search on these graphs, not a theorem for all ADMGs. The search perturbs one district at a time; a query whose non-identification needed simultaneous changes in two districts would be missed. None occurred here.
"""

S10b = f"""
## 10.2 Sharp bounds on observational fibres

Theorem 3.4 says a query is identified exactly when it is constant on each observational fibre. When it is not, the range of the query over a fibre is the sharpest statement the observational law supports. For one confounded district that range is a linear programme.

**Proposition 10.2 (fibre range with one confounded district).** Suppose exactly one district $D$ of $G$ has more than one member, $D$ is a clique, and the model class is that of Proposition 10.1. For a positive observational law $p$ of that class, the set of values of $P(Y=y\\mid do(X=x))$ over the fibre of $p$ is the interval between the minimum and maximum of $c\\cdot q$ subject to $Aq=p$ and $q\\ge0$. Here $A$ and $c$ are determined by $p$ and $G$ alone.

*Proof.* By Theorem 5.1, $p$ is the product of $Q[D]$ and the singleton factors $Q[\\{{i\\}}]$, all of which are identified. A singleton factor is unchanged by an intervention on other events and equals one at a target. The query is therefore a sum over assignments of identified singleton factors times $\\sum_t q_D(t)$ over types reproducing $v_D$ under the action, which is linear in $q_D$ with coefficients fixed by $p$. A law $q_D$ lies in the fibre exactly when it reproduces $Q[D]$, which after multiplying by the positive singleton factors is $Aq=p$. Any feasible $q_D$, combined with singleton response laws that reproduce their factors, is a model in the fibre. ∎

The kernel solves these programmes exactly over the rationals with a two-phase simplex method under Bland's rule (Bland, 1977). The study takes the bow and all {fb[0] - 1} three-event graphs with exactly one confounded clique district, draws one random positive response model for each, and bounds $P(Y=1\\mid do(X=x))$ for every ordered pair of events and both action values. That gives {fb[1] // 2} queries and {fb[1]} programmes.

All {fb[2]} identified queries gave zero width, and each bound equalled the value returned by ID. All {fb[5]} non-identified queries gave positive width; the smallest was {fr(fw[0])} and the mean {float(fw[1]):.3f}. Every interval contained the generating model's value and lay inside the natural bounds $[P(x,y),\\,P(x,y)+1-P(x)]$ (Manski, 1990). For the bow, the exact programme returned $[{fr(bow[0])},\\,{fr(bow[1])}]$, which equals the natural bounds, as expected for a single confounded pair. For the instrument graph $Z\\to X\\to Y$ with $X\\leftrightarrow Y$, it returned $[{fr(iv[0])},\\,{fr(iv[1])}]$ against natural bounds $[{fr(iv[2])},\\,{fr(iv[3])}]$, the tightening that instrument inequalities provide (Balke & Pearl, 1997). Among the non-identified queries, {nonid_equal} met the natural bounds exactly and {nonid_tighter} were strictly tighter (Figure 3a). The validator re-solves every programme with HiGHS in floating point and agrees within $10^{{-8}}$.

A width of zero on one observational law does not prove identification, because the decision quantifies over all laws. The study uses the converse: an identified query must give zero width on every law, and a positive width on any law is a semantic non-identification witness.
"""

S10c = f"""
## 10.3 A census of event-replacement gaps

Corollary 7.2 makes event replacement exact when the clamped event is last in its district. Section 7.2 showed two ways it fails. The census asks how often replacement errs when the certificate fails, in a fixed mechanism family.

It covers all 4,096 four-event ADMGs and all four positions, {num(rc[0])} cases. Each event is the exclusive-or of its parents, incident latent bits and a private bit. Private and latent bits have probability $1/4$ or $3/4$, drawn per graph; the fair value $1/2$ is excluded because it makes an event independent of its parents. Replacement uses the exact observational conditionals in the topological order, and the truth is computed by mechanism replacement.

The certificate held in {num(rc[1])} cases, and every one had zero total-variation gap. It failed in {num(rc[3])} cases, and every one had a positive gap: the median was {fr(rg[0])}, the largest {fr(rg[1])} and the mean {float(F(rg[2])):.4f}. Among the failures, {num(rc[5])} had an identified joint intervention law. In all {num(rc[7])} identified cases, executing the ID expression reproduced the true interventional joint exactly, while replacement erred in each of those {num(rc[5])} uncertified cases (Figure 3b).
"""
S10c2 = f"""
In this family the certificate is not only sufficient but also sharp. No uncertified case escaped error through cancellation. This does not contradict the remark after Corollary 7.2: the exclusive-or mechanisms with non-fair noise are generic enough to transmit every open path, and ignored inputs or cancelling parameters can still produce exact replacement outside this family. For conjecture C3 the census fixes the floor that token replacement cannot beat even with perfect conditionals. In {pct(rc[5], rc[3])} of the uncertified cases the identified formula meets the truth exactly where replacement does not.
"""

S10d = f"""
## 10.4 A semantic test of clock-licensed deletion

Section 9.5 states what a valid test of C2 must fix: the event and graph family, the deletion queries and the treatment of ties. The proposal's thresholds were frozen before this run. Forbidden deletions were predicted in at least 5% of queries, with contradiction below 1%. Certified deletion was predicted to keep at least half of the deletions that the true dates allow, with contradiction below a quarter. The protocol below was written into the kernel before its single run and was not tuned afterwards.

The test uses {cd[0]} narratives of six events. True dates increase in steps of $k/48$ year with $k\\in\\{{1,\\ldots,38\\}}$, so the generation order is topological. Each forward pair is a directed edge with probability $0.3$, with one to three bidirected edges. Mechanisms are exclusive-or with non-fair noise, as in Section 10.3. Every directed edge carries a true minimum lag rounded down to a quarter year, and with probability one half a maximum lag half a year above it. Other pairs carry such lag constraints with probability $0.3$. Dates are reported to the year with probability $0.7$ and otherwise to the month, and text order is shuffled.

A query deletes action $A$ from $P(y,c\\mid do(a))$, for outcome $Y$, action $A$ and an optional condition $C$. The point-date extractor deletes when $Y$ and $C$ precede $A$ by the start of their reported periods, with equal starts broken by text order. Certified deletion uses Corollary 6.3. A deletion is invalid when the joint law of $(Y,C)$ under either value of the action differs from its observational law, checked exactly.
"""
t5 = ["| Quantity | Count | Share |", "|:--|:--|:--|",
      f"| Queries | {num(cd[1])} | 100% |",
      f"| Point-date deletions | {num(cd[2])} | {pct(cd[2], cd[1])} of queries |",
      f"| Invalid point-date deletions | {num(cd[3])} | {pct(cd[3], cd[1], 2)} of queries; {pct(cd[3], cd[2])} of point-date deletions |",
      f"| Point-date deletions decided by text order | {num(cd[4])} | {pct(cd[5], cd[4])} of them invalid ({num(cd[5])}) |",
      f"| Deletions allowed by the true dates | {num(cd[6])} | {cd[7]} invalid |",
      f"| Certified deletions | {num(cd[8])} | {pct(cd[8], cd[6])} of those the true dates allow; {cd[9]} invalid |"]
S10d2 = f"""
Certified deletion produced no invalid deletion and kept {pct(cd[8], cd[6])} of the deletions the true dates allow, so the second part of C2 holds with margin. Point dates produced invalid deletions in {pct(cd[3], cd[1], 2)} of queries. That falls short of the predicted 5% but stays above the 1% contradiction threshold, so by the frozen rule the first part is neither confirmed nor refuted.

The source of the errors is instructive. Of the {num(cd[3])} invalid deletions, {num(cd[5])} came from ties broken by text order. The remaining {num(forbidden_strict)} came from strict comparisons between the starts of periods of different lengths. A year-dated event starts on 1 January even when it occurred in November, so it can appear to precede a month-dated event that it actually follows. A period start is therefore not order-preserving once resolutions are mixed. Interval dates avoid both failures by construction.
"""
S10e = """
## 10.5 What the extended studies establish

The four studies are exact computations on declared finite families. They show that the witness search, the fibre programmes and the replacement certificate behave as the propositions require on every case examined, and they record where the stated predictions held or fell short. They do not extend identification beyond ID and IDC, prove completeness of the witness search for arbitrary graphs, or measure a trained generator. Conjecture C3 still requires the learned-model experiment of Section 9.5.
"""

anchor = find("10 Conclusion", "Heading 1")
new = []
new += fragment(S10a)
new += table(t4, [950, 900, 1100, 1150, 950, 1450, 1500, 1648], "Table 4 Exact witness synthesis on clique-district graphs")
new += fragment(S10a2)
new += fragment(S10b)
new += fragment(S10c)
new += figure(os.path.join(H, "figures", "v2_fibres_replacement.png"),
              "Figure 3 Sharp fibre bounds and event-replacement gaps",
              "Left: exact linear-programme bounds for the 56 non-identified queries against the natural bounds, with the generating model's value. Right: total-variation gaps of event replacement in the uncertified cases, split by whether the joint intervention law is identified.")
new += fragment(S10c2)
new += fragment(S10d)
new += table(t5, [3600, 1500, 4548], "Table 5 Frozen semantic test of clock-licensed action deletion")
new += fragment(S10d2)
new += fragment(S10e)
after(anchor._p.getprevious(), new)

set_text(find("10 Conclusion", "Heading 1"), "11 Conclusion")
concl = find("Precision requires an equally explicit contract.")
after(concl._p, fragment(
    f"The Version 2 studies make three of these contracts computational. A failed identification now comes with an exact pair of "
    f"models on clique-district graphs, and a non-identified query with its sharp fibre bounds when one district is confounded. "
    f"The replacement certificate was exact in every certified case and violated in every uncertified one of the census. Clock "
    f"certificates never licensed an invalid deletion, while start-of-period dates did through ties and mixed resolutions.\n"))

# ------------------------------------------------------------------ Appendix A rows
tbl = None
for t in doc.tables:
    if t.rows[0].cells[0].text.strip() == "Statement": tbl = t._tbl
last = tbl.findall(qn("w:tr"))[-1]
for cells in (("10.1 Witness synthesis", "Clique districts; one latent per district over response types; positive base laws", "Exact pair of models with equal observational laws and different query values"),
              ("10.2 Fibre bounds", "Exactly one confounded clique district; positive observational law in that class", "Sharp range of the query over the observational fibre")):
    tr = copy.deepcopy(last)
    for tc, txt in zip(tr.findall(qn("w:tc")), cells):
        ts = list(tc.iter(qn("w:t"))); ts[0].text = txt
        for t in ts[1:]: t.text = ""
    last.addnext(tr); last = tr

# ------------------------------------------------------------------ Appendix B.4
refs = find("References", "Heading 1")
appb = fragment(f"""
## B.4 Version 2 additions

The new studies live in `DoNumerics.cs` and run with the flag `--v2`, which writes {len(cs)} summary lines and four result files: witnesses, fibre programmes, the replacement census and the clock-deletion narratives. Public values remain immutable records; row reduction and the simplex method use private scratch arrays. The default run is unchanged. In the Version 2 environment it reproduced the Version 1 summary and all five result files byte for byte, and the Version 1 validator passed again.

The validator `validate_v2.py` reuses the Version 1 validator's graph, ID and exogenous-enumeration routines and adds independent response-type decoding, exact witness certificates, complete enumeration for a sample of witness pairs, HiGHS re-solution of every programme, and exact replays of the three new random streams. It passed all {len(val['checks'])} checks. The streams use seeds 20261030070 to 20261030073. The verified environment was .NET SDK 8.0.131, Python 3.13.16, SymPy 1.14.0, SciPy 1.18.1, NumPy 2.5.3 and y0 0.2.11.
""")
after(refs._p.getprevious(), appb)
b3 = find("A clean replay reproduces all summary lines")
append_text(b3, f" The Version 2 lines are checked by a separate validator described in B.4.")

# ------------------------------------------------------------------ references
tmpl = find("Abramsky, S., & Brandenburger, A. (2011).")
def ref(md):
    p = fragment(md + "\n")[0]
    ppr = p.find(qn("w:pPr")); p.remove(ppr); p.insert(0, copy.deepcopy(tmpl._p.find(qn("w:pPr")))); return p
after(find("Abramsky, S., & Brandenburger, A. (2011).")._p, [
    ref("Balke, A., & Pearl, J. (1997). Bounds on treatment effects from studies with imperfect compliance. *Journal of the American Statistical Association, 92*(439), 1171–1176. https://doi.org/10.1080/01621459.1997.10474074"),
    ref("Bland, R. G. (1977). New finite pivoting rules for the simplex method. *Mathematics of Operations Research, 2*(2), 103–107. https://doi.org/10.1287/moor.2.2.103")])
after(find("Mahadevan, S. (2025).")._p, [
    ref("Manski, C. F. (1990). Nonparametric bounds on treatment effects. *American Economic Review, 80*(2), 319–323.")])

# ------------------------------------------------------------------ tidy and save
M = "http://schemas.openxmlformats.org/officeDocument/2006/math"
def reorder(parent, order):
    kids = sorted(list(parent), key=lambda e: order.index(etree.QName(e).localname) if etree.QName(e).localname in order else 99)
    for k in kids: parent.append(k)
PPR = ("pStyle keepNext keepLines pageBreakBefore framePr widowControl numPr suppressLineNumbers pBdr shd tabs suppressAutoHyphens "
       "kinsoku wordWrap overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi adjustRightInd snapToGrid spacing ind "
       "contextualSpacing mirrorIndents suppressOverlap jc textDirection textAlignment textboxTightWrap outlineLvl divId "
       "cnfStyle rPr sectPr pPrChange").split()
for x in body.iter(qn("w:pPr")): reorder(x, PPR)
for x in body.iter(f"{{{M}}}dPr"): reorder(x, ["begChr", "sepChr", "endChr", "grow", "shp", "ctrlPr"])
for x in body.iter(f"{{{M}}}mcPr"): reorder(x, ["count", "mcJc"])
for x in body.iter(f"{{{M}}}rPr"): reorder(x, ["lit", "nor", "scr", "sty", "brk", "aln"])
for shd in body.iter(qn("w:shd")):
    if shd.get(qn("w:val")) is None: shd.set(qn("w:val"), "clear")
for x in body.iter(f"{{{M}}}rPr"):
    if x.find(f"{{{M}}}nor") is not None:
        for s in x.findall(f"{{{M}}}sty") + x.findall(f"{{{M}}}scr"): x.remove(s)
cp = doc.core_properties; cp.title = "Autoregressive Do Calculus (ADC)"; cp.subject = "Version 2 with extended do-numerics"
doc.save(OUT)
# ======================================================================= schema order fixes in parts V1 already carried
import zipfile, shutil
ORDER = ("writeProtection view zoom removePersonalInformation removeDateAndTime doNotDisplayPageBoundaries displayBackgroundShape "
         "printPostScriptOverText printFractionalCharacterWidth printFormsData embedTrueTypeFonts embedSystemFonts saveSubsetFonts "
         "saveFormsData mirrorMargins alignBordersAndEdges bordersDoNotSurroundHeader bordersDoNotSurroundFooter gutterAtTop "
         "hideSpellingErrors hideGrammaticalErrors activeWritingStyle proofState formsDesign attachedTemplate linkStyles "
         "stylePaneFormatFilter stylePaneSortMethod documentType mailMerge revisionView trackRevisions doNotTrackMoves "
         "doNotTrackFormatting documentProtection autoFormatOverride styleLockTheme styleLockQFSet defaultTabStop autoHyphenation "
         "consecutiveHyphenLimit hyphenationZone doNotHyphenateCaps showEnvelope summaryLength clickAndTypeStyle defaultTableStyle "
         "evenAndOddHeaders bookFoldRevPrinting bookFoldPrinting bookFoldPrintingSheets drawingGridHorizontalSpacing "
         "drawingGridVerticalSpacing displayHorizontalDrawingGridEvery displayVerticalDrawingGridEvery "
         "doNotUseMarginsForDrawingGridOrigin drawingGridHorizontalOrigin drawingGridVerticalOrigin doNotShadeFormData "
         "noPunctuationKerning characterSpacingControl printTwoOnOne strictFirstAndLastChars noLineBreaksAfter noLineBreaksBefore "
         "savePreviewPicture doNotValidateAgainstSchema saveInvalidXml ignoreMixedContent alwaysShowPlaceholderText "
         "doNotDemarcateInvalidXml saveXmlDataOnly useXSLTWhenSaving saveThroughXslt showXMLTags alwaysMergeEmptyNamespace "
         "updateFields hdrShapeDefaults footnotePr endnotePr compat docVars rsids mathPr attachedSchema themeFontLang "
         "clrSchemeMapping doNotIncludeSubdocsInStats doNotAutoCompressPictures forceUpgrade captions readModeInkLockDown "
         "smartTagType schemaLibrary shapeDefaults doNotEmbedSmartTags decimalSymbol listSeparator").split()
tmp = OUT + ".tmp"
with zipfile.ZipFile(OUT) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
    for item in zin.infolist():
        data = zin.read(item.filename)
        if item.filename == "word/settings.xml":
            root = etree.fromstring(data)
            kids = sorted(list(root), key=lambda e: ORDER.index(etree.QName(e).localname) if etree.QName(e).localname in ORDER else len(ORDER))
            for k in kids: root.append(k)
            W_ = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
            for z in root.findall(W_ + "zoom"):
                if z.get(W_ + "percent") is None: z.set(W_ + "percent", "100")
            data = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
        if item.filename == "word/numbering.xml":
            data = re.sub(rb'(<w:nsid w:val=")([0-9A-Fa-f]{1,7})(")', lambda m: m.group(1) + m.group(2).rjust(8, b"0") + m.group(3), data)
        zout.writestr(item, data)
shutil.move(tmp, OUT)
print("saved", OUT)
