class Graph:
    def __init__(self,n,d,b,vertices=None):
        self.n=n;self.v=set(range(n)) if vertices is None else set(vertices)
        self.d={tuple(e) for e in d if set(e)<=self.v};self.b={tuple(sorted(e)) for e in b if set(e)<=self.v}
    def sub(self,v):return Graph(self.n,self.d,self.b,self.v&set(v))
    def cut(self,inc=(),out=()):
        inc,out=set(inc),set(out)
        return Graph(self.n,[(a,b) for a,b in self.d if b not in inc and a not in out],
                     [(a,b) for a,b in self.b if a not in inc and b not in inc],self.v)
    def ancestors(self,a):
        a=set(a)&self.v
        while True:
            new=a|{i for i,j in self.d if j in a}
            if new==a:return a
            a=new
    def districts(self):
        remain=set(self.v);ds=[]
        while remain:
            c={min(remain)}
            while True:
                new=c|{v for e in self.b if set(e)&c for v in e}
                if new==c:break
                c=new
            ds.append(c);remain-=c
        return ds
    def separated(self,y,z,c):
        """Enumerate simple m-active paths directly, independent of C# latent moralisation."""
        y,z,c=set(y),set(z),set(c)
        if not y or not z:return True
        anc=self.ancestors(c);adj=defaultdict(list)
        for a,b in self.d:
            adj[a].append((b,False,True));adj[b].append((a,True,False))
        for a,b in self.b:
            adj[a].append((b,True,True));adj[b].append((a,True,True))
        def dfs(v,arrival,seen):
            if v in z:return True
            for w,head_v,head_w in adj[v]:
                if w in seen:continue
                if arrival is not None:
                    collider=arrival and head_v
                    if (collider and v not in anc) or (not collider and v in c):continue
                if dfs(w,head_w,seen|{w}):return True
            return False
        return not any(dfs(s,None,{s}) for s in y)
    def rule(self,r,y,x,z,w):
        h=self.cut(x)
        g=h if r==1 else self.cut(x,z) if r==2 else self.cut(set(x)|(set(z)-h.ancestors(w)))
        return g.separated(y,z,set(x)|set(w))

def bits(mask):return {i for i in range(16) if mask>>i&1}
def mask(v):return sum(1<<i for i in v)

class Kernel:
    def __init__(self,a):self.a=tuple(a);self.n=len(self.a).bit_length()-1;self.cache={}
    def marginal(self,variables):
        variables=frozenset(variables)
        if not variables:return self
        if variables in self.cache:return self.cache[variables]
        remove=mask(variables);bucket=defaultdict(F)
        for b,q in enumerate(self.a):bucket[b&~remove]+=q
        result=Kernel(bucket[b&~remove] for b in range(len(self.a)))
        self.cache[variables]=result;return result
    def divide(self,k):
        assert all(q>0 for q in k.a)
        return Kernel(a/b for a,b in zip(self.a,k.a))
    def prefix_factor(self,active,i):
        later={j for j in active if j>i}
        return self.marginal(later).divide(self.marginal(later|{i}))
    @staticmethod
    def multiply(n,ks):
        ks=list(ks)
        return Kernel(math.prod((k.a[b] for k in ks),start=F(1)) for b in range(1<<n))

class Failure(Exception):pass
def identify(y,x,p,g):
    y,x=set(y),set(x);v=g.v
    if not x:return p.marginal(v-y)
    a=g.ancestors(y)
    if a!=v:return identify(y,x&a,p.marginal(v-a),g.sub(a))
    w=(v-x)-g.sub(v-x).ancestors(y)
    if w:return identify(y,x|w,p,g)
    ds=g.sub(v-x).districts()
    if len(ds)>1:return Kernel.multiply(g.n,[identify(s,v-s,p,g) for s in ds]).marginal(v-(x|y))
    s=ds[0];original=g.districts()
    if len(original)==1:raise Failure()
    if s in original:return Kernel.multiply(g.n,[p.prefix_factor(v,i) for i in sorted(s)]).marginal(s-y)
    larger=next(c for c in original if s<c)
    return identify(y,x&larger,Kernel.multiply(g.n,[p.prefix_factor(v,i) for i in sorted(larger)]),g.sub(larger))
def idc(y,x,z,p,g):
    y,x,z=set(y),set(x),set(z)
    if not z:return identify(y,x,p,g)
    for i in sorted(z):
        if g.rule(2,y,x,{i},z-{i}):return idc(y,x|{i},z-{i},p,g)
    joint=identify(y|z,x,p,g)
    return joint.divide(joint.marginal(y))

class Model:
    def __init__(self,record):
        self.record=record;self.n=record["n"];self.g=Graph(self.n,record["directed"],record["bidirected"])
        self.d=list(map(tuple,record["directed"]));self.b=list(map(tuple,record["bidirected"]))
        self.k=record["privateK"];self.h=record["latentK"];self.cache={}
    def law(self,actions=0,values=0):
        key=(actions,values&actions)
        if key in self.cache:return self.cache[key]
        n,m=self.n,len(self.b);counts=[0]*(1<<n);den=4**(n+m)
        for u in range(1<<m):
            wh=math.prod(k if u>>j&1 else 4-k for j,k in enumerate(self.h))
            for noise in range(1<<n):
                weight=wh*math.prod(k if noise>>j&1 else 4-k for j,k in enumerate(self.k))
                v=0
                for i in range(n):
                    if actions>>i&1:bit=(values>>i)&1
                    else:
                        bit=(noise>>i)&1
                        for a,b in self.d:
                            if b==i:bit^=(v>>a)&1
                        for j,e in enumerate(self.b):
                            if i in e:bit^=(u>>j)&1
                    v|=bit<<i
                counts[v]+=weight
        p=Kernel(F(c,den) for c in counts)
        assert sum(p.a)==1
        self.cache[key]=p;return p

@lru_cache(None)
def mass(a,selected,values):
    return sum((q for b,q in enumerate(a) if ((b^values)&selected)==0),F(0))
def conditional(p,y,value,w):
    return mass(p.a,y|w,value)/mass(p.a,w,value)
def replacement(p,position,value,order=None):
    order=list(range(p.n)) if order is None else order;answer=[]
    for b in range(1<<p.n):
        q=F(1);prefix=0
        for i in order:
            q*=int((b>>i&1)==value) if i==position else conditional(p,1<<i,b,prefix)
            prefix|=1<<i
        answer.append(q)
    return Kernel(answer)
def tv(a,b):return sum((abs(x-y) for x,y in zip(a.a,b.a)),F(0))/2
