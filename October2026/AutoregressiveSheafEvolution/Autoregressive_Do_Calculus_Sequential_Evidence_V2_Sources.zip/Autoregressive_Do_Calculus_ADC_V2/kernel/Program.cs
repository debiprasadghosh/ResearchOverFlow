using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text.Json;

namespace Tcr;

public readonly record struct RationalInterval(Q Lo,Q Hi)
{
    public static implicit operator RationalInterval(int v)=>new(v,v);
    public static RationalInterval operator +(RationalInterval a,RationalInterval b)=>new(a.Lo+b.Lo,a.Hi+b.Hi);
    public static RationalInterval operator -(RationalInterval a,RationalInterval b)=>new(a.Lo-b.Hi,a.Hi-b.Lo);
    public static RationalInterval operator *(RationalInterval a,RationalInterval b)
    {
        Q[] p={a.Lo*b.Lo,a.Lo*b.Hi,a.Hi*b.Lo,a.Hi*b.Hi};return new(p.Min(),p.Max());
    }
    public static RationalInterval operator /(RationalInterval a,RationalInterval b)
    {
        if(b.Lo<=Q.Zero && b.Hi>=Q.Zero)throw new ArgumentException("zero denominator");
        Q[] p={a.Lo/b.Lo,a.Lo/b.Hi,a.Hi/b.Lo,a.Hi/b.Hi};return new(p.Min(),p.Max());
    }
    public Q Width=>Hi-Lo;
}
public static class Program
{
    static readonly JsonSerializerOptions JsonOptions=new(){PropertyNamingPolicy=JsonNamingPolicy.CamelCase,WriteIndented=true};
    static void Emit(string key,params object[] values)
    {
        string Format(object o)=>o switch {
            bool b=>b?"1":"0",double d=>d.ToString("R",CultureInfo.InvariantCulture),
            IFormattable f=>f.ToString(null,CultureInfo.InvariantCulture),_=>o.ToString()??""
        };
        Console.WriteLine(key+"\t"+string.Join(" ",values.Select(Format)));
    }
    static Edge[] Pairs(int n)=>(from i in Enumerable.Range(0,n) from j in Enumerable.Range(i+1,n-i-1) select new Edge(i,j)).ToArray();
    static Q Fd(Q[] q)
    {
        Q p=q[0],r=q[1];
        return (1-r)*((1-p)*q[2]+p*q[3])+r*((1-p)*q[4]+p*q[5]);
    }
    static RationalInterval FdI(RationalInterval[] q,int form=0)
    {
        var p=q[0];var r=q[1];
        return form switch {
            0=>(1-r)*((1-p)*q[2]+p*q[3])+r*((1-p)*q[4]+p*q[5]),
            1=>(1-r)*(1-p)*q[2]+(1-r)*p*q[3]+r*(1-p)*q[4]+r*p*q[5],
            2=>(1-p)*((1-r)*q[2]+r*q[4])+p*((1-r)*q[3]+r*q[5]),
            _=>throw new ArgumentException()
        };
    }
    static Iv FdOut(Iv[] q)
    {
        var p=q[0];var r=q[1];var one=Iv.Point(1);
        return (one-r)*((one-p)*q[2]+p*q[3])+r*((one-p)*q[4]+p*q[5]);
    }
    static (Q Lo,Q Hi) Corners((Q Lo,Q Hi)[] box,Func<Q[],Q> f)
    {
        Q lo=0,hi=0;
        for(int mask=0;mask<(1<<box.Length);mask++)
        {
            Q value=f(box.Select((b,i)=>((mask>>i)&1)==0?b.Lo:b.Hi).ToArray());
            if(mask==0){lo=hi=value;}else{lo=Q.Min(lo,value);hi=Q.Max(hi,value);}
        }
        return(lo,hi);
    }
    static double Median(IEnumerable<double> source)
    {
        var a=source.Order().ToArray();return (a[(a.Length-1)/2]+a[a.Length/2])/2;
    }
    static object ModelInfo(string id,BinaryScm model)=>new {
        id,n=model.Graph.N,directed=model.Graph.D.Select(e=>new[]{e.From,e.To}).ToArray(),
        bidirected=model.Graph.B.Select(e=>new[]{e.From,e.To}).ToArray(),
        privateK=model.PrivateK,latentK=model.LatentK
    };
    static BinaryScm Model(int n,Edge[] d,Edge[] b,int[]? k=null,int[]? h=null) =>
        new(Admg.Make(n,d,b),(k??Enumerable.Repeat(1,n).ToArray()).ToImmutableArray(),
            (h??Enumerable.Repeat(1,b.Length).ToArray()).ToImmutableArray());
    static (int Reachable,bool Observational) RuleReachability(Admg g,int y,int x,int w)
    {
        IEnumerable<int> Subs(int a){for(int s=a;s!=0;s=(s-1)&a)yield return s;}
        var seen=new HashSet<(int X,int W)>{(x,w)};var queue=new Queue<(int X,int W)>(seen);
        while(queue.Count!=0)
        {
            var state=queue.Dequeue();int absent=g.V&~(y|state.X|state.W);
            void Add(int a,int b){if(seen.Add((a,b)))queue.Enqueue((a,b));}
            foreach(int z in Subs(absent))
            {
                if(g.Rule(1,y,state.X,z,state.W))Add(state.X,state.W|z);
                if(g.Rule(3,y,state.X,z,state.W))Add(state.X|z,state.W);
            }
            foreach(int z in Subs(state.W))
            {
                if(g.Rule(1,y,state.X,z,state.W&~z))Add(state.X,state.W&~z);
                if(g.Rule(2,y,state.X,z,state.W&~z))Add(state.X|z,state.W&~z);
            }
            foreach(int z in Subs(state.X))
            {
                if(g.Rule(3,y,state.X&~z,z,state.W))Add(state.X&~z,state.W);
                if(g.Rule(2,y,state.X&~z,z,state.W))Add(state.X&~z,state.W|z);
            }
        }
        return(seen.Count,seen.Any(s=>s.X==0));
    }

    public static void Main(string[] args)
    {
        string dir=args.Length>0?args[0]:"output";Directory.CreateDirectory(dir);
        if(args.Contains("--v2")){DoNumerics.Run(dir);return;}
        var modelInfo=new List<object>();var queryInfo=new List<object>();
        int goodId=0,badId=0,assignments=0,formulaMismatch=0,ruleBindings=0;
        var named=new[] {
            ("backdoor",Model(3,new[]{new Edge(0,1),new Edge(0,2),new Edge(1,2)},Array.Empty<Edge>()),1,2),
            ("frontdoor",Model(3,new[]{new Edge(0,1),new Edge(1,2)},new[]{new Edge(0,2)}),0,2),
            ("bow",Model(2,new[]{new Edge(0,1)},new[]{new Edge(0,1)}),0,1),
            ("last_district",Model(3,new[]{new Edge(0,2),new Edge(1,2)},new[]{new Edge(0,1)}),1,2),
            ("prefix_collider",Model(3,Array.Empty<Edge>(),new[]{new Edge(0,1),new Edge(0,2)}),1,2)
        };
        void Query(string id,BinaryScm model,int x,int y)
        {
            var obs=model.Law();var answer=Identification.Run(1<<y,1<<x,obs,model.Graph);
            var truth0=model.Law(1<<x,0);var truth1=model.Law(1<<x,1<<x);
            Q value0=BinaryScm.Mass(truth0,1<<y,1<<y),value1=BinaryScm.Mass(truth1,1<<y,1<<y);
            if(answer.Identified)
            {
                goodId++;
                for(int b=0;b<(1<<model.Graph.N);b++)
                {
                    Q truth=BinaryScm.Mass(((b>>x)&1)==0?truth0:truth1,1<<y,b);
                    if(answer.Kernel!.Values[b]!=truth)formulaMismatch++;
                    assignments++;
                }
            } else badId++;
            queryInfo.Add(new {
                model=id,x,y,identified=answer.Identified,
                p0=answer.Identified?value0.ToString():null,p1=answer.Identified?value1.ToString():null,
                truth0=value0.ToString(),truth1=value1.ToString(),trace=answer.Trace,
                failureVertices=answer.FailureVertices,failureDistrict=answer.FailureDistrict
            });
        }
        foreach(var (name,m,x,y) in named)
        {
            modelInfo.Add(ModelInfo(name,m));Query(name,m,x,y);
            var rep=BinaryScm.Replacement(m.Law(),x,1);var truth=m.Law(1<<x,1<<x);
            Emit("named_"+name,Identification.Run(1<<y,1<<x,m.Law(),m.Graph).Identified,
                BinaryScm.Mass(truth,1<<y,1<<y),BinaryScm.Mass(rep,1<<y,1<<y),
                BinaryScm.Tv(rep,truth),m.Graph.PrefixExchange(x),m.Graph.LastInDistrict(x));
        }
        var frontdoorReach=RuleReachability(named[1].Item2.Graph,4,1,0);
        Emit("rule_path_frontdoor",frontdoorReach.Reachable,frontdoorReach.Observational,
            Identification.Run(4,1,named[1].Item2.Law(),named[1].Item2.Graph).Identified);
        var rng=new Rng(20261030041UL);int randomModels=0;
        for(int n=5;n<=8;n++)for(int instance=0;instance<3;instance++)
        {
            var pairs=Pairs(n);var d=new List<Edge>();
            foreach(var e in pairs){double u;(u,rng)=rng.Uniform();if(u<0.30)d.Add(e);}
            var shuffled=pairs.ToArray();
            for(int j=shuffled.Length-1;j>0;j--){int k;(k,rng)=rng.Int(0,j);(shuffled[j],shuffled[k])=(shuffled[k],shuffled[j]);}
            int m;(m,rng)=rng.Int(1,3);var b=shuffled.Take(m).ToArray();
            var pk=new int[n];var hk=new int[m];
            for(int j=0;j<n;j++)(pk[j],rng)=rng.Int(1,3);
            for(int j=0;j<m;j++)(hk[j],rng)=rng.Int(1,3);
            var model=Model(n,d.ToArray(),b,pk,hk);string id=$"random_{n}_{instance}";
            modelInfo.Add(ModelInfo(id,model));randomModels++;
            for(int x=0;x<n;x++)for(int y=0;y<n;y++)if(x!=y)Query(id,model,x,y);
        }
        Emit("id_models_queries",named.Length,randomModels,goodId+badId,goodId,badId,assignments,formulaMismatch);
        if(formulaMismatch!=0)throw new InvalidOperationException("ID formula disagrees with mechanism replacement");
        File.WriteAllText(Path.Combine(dir,"models.json"),JsonSerializer.Serialize(modelInfo,JsonOptions));
        File.WriteAllText(Path.Combine(dir,"id_queries.json"),JsonSerializer.Serialize(queryInfo,JsonOptions));

        // Every ordered four-node ADMG, with all four replacement positions.
        int graphCases=0,certificate=0,last=0,mismatch=0;var four=Pairs(4);
        using(var sw=new StreamWriter(Path.Combine(dir,"prefix_graphs.csv")))
        {
            sw.WriteLine("directed,bidirected,position,separated,last");
            for(int d=0;d<(1<<four.Length);d++)for(int b=0;b<(1<<four.Length);b++)
            {
                var g=Admg.Make(4,four.Where((_,i)=>(d&(1<<i))!=0),four.Where((_,i)=>(b&(1<<i))!=0));
                for(int s=0;s<4;s++)
                {
                    bool a=g.PrefixExchange(s),c=g.LastInDistrict(s);
                    graphCases++;if(a)certificate++;if(c)last++;if(a!=c)mismatch++;
                    sw.WriteLine($"{d},{b},{s},{(a?1:0)},{(c?1:0)}");
                }
            }
        }
        Emit("prefix_graph_equivalence",graphCases,certificate,last,mismatch);

        int[] licensed=new int[3],equal=new int[3];var three=Pairs(3);
        for(int d=0;d<8;d++)for(int b=0;b<8;b++)
        {
            var g=Admg.Make(3,three.Where((_,i)=>(d&(1<<i))!=0),three.Where((_,i)=>(b&(1<<i))!=0));
            var model=new BinaryScm(g,ImmutableArray.Create(1,2,3),Enumerable.Repeat(1,g.B.Length).ToImmutableArray());
            var laws=new Dictionary<(int,int),TabKernel>();
            TabKernel Law(int act,int bits)
            {
                var key=(act,bits&act);
                if(!laws.TryGetValue(key,out var p)){p=model.Law(act,bits);laws.Add(key,p);}return p;
            }
            for(int y=0;y<3;y++)for(int z=0;z<3;z++)if(y!=z)
            {
                int other=3-y-z;
                for(int role=0;role<3;role++)
                {
                    int yy=1<<y,zz=1<<z,xx=role==1?1<<other:0,ww=role==2?1<<other:0;
                    for(int rule=1;rule<=3;rule++)
                    {
                        ruleBindings++;
                        if(!g.Rule(rule,yy,xx,zz,ww))continue;licensed[rule-1]++;
                        bool ok=true;
                        for(int values=0;values<8;values++)
                        {
                            Q left,right;
                            if(rule==1)
                            {
                                left=BinaryScm.Conditional(Law(xx,values),yy,values,zz|ww);
                                right=BinaryScm.Conditional(Law(xx,values),yy,values,ww);
                            }
                            else
                            {
                                left=BinaryScm.Conditional(Law(xx|zz,values),yy,values,ww);
                                right=BinaryScm.Conditional(Law(xx,values),yy,values,rule==2?zz|ww:ww);
                            }
                            ok&=left==right;
                        }
                        if(ok)equal[rule-1]++;
                    }
                }
            }
        }
        Emit("three_rule_soundness",ruleBindings,licensed[0],equal[0],licensed[1],equal[1],licensed[2],equal[2]);

        // Positive observational witness: two worlds agree at every observed cell.
        TabKernel Witness(bool second,int action=-1)
        {
            var a=Enumerable.Repeat(Q.Zero,4).ToArray();
            for(int u=0;u<2;u++)for(int noise=0;noise<2;noise++)
            {
                int x=action<0?u:action,y=second && x!=u?x:noise;
                a[x|(y<<1)]+=Q.Of(1,4);
            }
            return new(2,a.ToImmutableArray(),new Joint());
        }
        Emit("positive_witness",Witness(false).Values.SequenceEqual(Witness(true).Values),
            Witness(false).Values.All(q=>q>Q.Zero),
            BinaryScm.Mass(Witness(false,1),2,2),BinaryScm.Mass(Witness(true,1),2,2),
            BinaryScm.Mass(Witness(false,0),2,2),BinaryScm.Mass(Witness(true,0),2,2));
        var conditionalModel=Model(3,new[]{new Edge(0,1),new Edge(1,2)},new[]{new Edge(0,1)});
        var conditionalObs=conditionalModel.Law();
        var jointAnswer=Identification.Run(2|4,1,conditionalObs,conditionalModel.Graph);
        var conditionalAnswer=Identification.Conditional(4,1,2,conditionalObs,conditionalModel.Graph);
        int conditionalMatches=0;
        for(int v=0;v<8;v++)
            if(conditionalAnswer.Kernel!.Values[v]==BinaryScm.Conditional(conditionalModel.Law(1,v),4,v,2))conditionalMatches++;
        Emit("conditional_without_joint",jointAnswer.Identified,conditionalAnswer.Identified,conditionalMatches,
            conditionalAnswer.Kernel!.Values[6],conditionalAnswer.Kernel.Values[4]);
        var chain=Model(2,new[]{new Edge(0,1)},Array.Empty<Edge>(),new[]{2,1});
        var nonTopo=BinaryScm.Replacement(chain.Law(),0,1,new[]{1,0});
        Emit("non_topological_replacement",BinaryScm.Mass(nonTopo,2,2),BinaryScm.Mass(chain.Law(1,1),2,2),BinaryScm.Tv(nonTopo,chain.Law(1,1)));
        var selection=Model(3,new[]{new Edge(0,2),new Edge(1,2)},Array.Empty<Edge>(),new[]{2,2,1});
        Emit("later_selection",BinaryScm.Conditional(selection.Law(),1,5,4),
            BinaryScm.Conditional(selection.Law(2,0),1,5,4));
        Q Interior(Q p)=>p/(p*p+Q.Of(1,4));
        Emit("rational_interior",Interior(Q.Of(1,10)),Interior(Q.Of(1,2)),Interior(Q.One));
        var unit=new RationalInterval(0,1);
        var fewer=unit*(1-unit);
        var centered=unit-new RationalInterval(Q.Of(1,2),Q.Of(1,2));
        var more=new RationalInterval(Q.Of(1,4),Q.Of(1,4))-centered*centered
            +new RationalInterval(Q.Of(1,100),Q.Of(1,100))*(unit-unit);
        Emit("repeat_counterexample",fewer.Lo,fewer.Hi,more.Lo,more.Hi,Q.Of(1,4));
        Emit("compatibility_relaxation",Q.Of(1,5),Q.Of(2,5),Q.Of(1,5),Q.Of(3,5),Q.Of(1,5),Q.Of(4,5));
        Emit("sequential_tv_bound",Q.One-(1-Q.Of(1,10))*(1-Q.Of(1,5)),Q.Of(3,10));

        // Clock certificates. Labels use abstract years with 12 equal reporting periods.
        var clocks=new List<object>();int narratives=128,pairsTotal=0,certified=0,wrongCert=0,textWrong=0,consistent=0;
        var crng=new Rng(20261030042UL);Q originalWidth=0,tightWidth=0;
        for(int it=0;it<narratives;it++)
        {
            const int n=6;var truth=new Q[n];truth[0]=0;
            for(int i=1;i<n;i++){int k;(k,crng)=crng.Int(1,38);truth[i]=truth[i-1]+Q.Of(k,48);}
            var dates=new List<(int Ev,Q Lo,Q Hi)>();
            for(int i=0;i<n;i++)
            {
                double u;(u,crng)=crng.Uniform();int periods=u<.7?1:12;
                Q l=Q.Floor(truth[i]*periods)/periods;dates.Add((i+1,l,l+Q.One/periods));
                originalWidth+=Q.One/periods;
            }
            var lags=new List<(int From,int To,Q MinLag,Q? MaxLag)>();
            for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)
            {
                double u;(u,crng)=crng.Uniform();if(u>=.5)continue;
                Q l=Q.Floor((truth[j]-truth[i])*4)/4;
                double z;(z,crng)=crng.Uniform();lags.Add((i+1,j+1,l,z<.5?l+Q.Of(1,2):null));
            }
            var stn=Stn.Build(n,dates,lags);var distance=stn.Distances();
            if(Stn.Consistent(distance))consistent++;
            for(int i=0;i<n;i++){var w=Stn.Window(distance,i+1);tightWidth+=w.Hi-w.Lo;}
            var order=Enumerable.Range(0,n).ToArray();
            for(int i=n-1;i>0;i--){int j;(j,crng)=crng.Int(0,i);(order[i],order[j])=(order[j],order[i]);}
            var rank=new int[n];for(int i=0;i<n;i++)rank[order[i]]=i;
            for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)
            {
                pairsTotal++;
                if(Stn.MinGap(distance,i+1,j+1) is Q gap && gap>Q.Zero)
                {certified++;if(!(truth[i]<truth[j]))wrongCert++;}
                if(rank[i]>rank[j])textWrong++;
            }
            clocks.Add(new {truth=truth.Select(q=>q.ToString()).ToArray(),textOrder=order,
                constraints=stn.Cons.Select(c=>new object[]{c.I,c.J,c.C.ToString()}).ToArray()});
        }
        Emit("clock_certificates",narratives,consistent,pairsTotal,certified,wrongCert,textWrong,
            (originalWidth/(narratives*6)).ToDouble(),(tightWidth/(narratives*6)).ToDouble());
        File.WriteAllText(Path.Combine(dir,"clocks.json"),JsonSerializer.Serialize(clocks,JsonOptions));

        var precision=new List<object>();var ratios=new List<double>();var conditionalRatios=new List<double>();
        int fpass=0,cpass=0,sharppass=0,positiveEqual=0;var prng=new Rng(20261030043UL);
        for(int it=0;it<40;it++)
        {
            var box=new (Q Lo,Q Hi)[8];
            for(int j=0;j<8;j++)
            {
                int center;(center,prng)=prng.Int(4,11);
                Q mid=Q.Of(center,16);box[j]=(mid-Q.Of(1,64),mid+Q.Of(1,64));
            }
            var exact=Corners(box.Take(6).ToArray(),Fd);
            var iv=box.Select(b=>new RationalInterval(b.Lo,b.Hi)).ToArray();
            var forms=Enumerable.Range(0,3).Select(i=>FdI(iv,i)).ToArray();
            if(forms.All(f=>f==forms[0]))positiveEqual++;
            var floating=box.Select(b=>Iv.Of(b.Lo,b.Hi)).ToArray();var outer=FdOut(floating);
            if(outer.Contains(exact.Lo)&&outer.Contains(exact.Hi))fpass++;
            Q Sharp(bool upper)
            {
                var a=box.Take(6).Select(b=>upper?b.Hi:b.Lo).ToArray();var values=new List<Q>();
                for(int m=0;m<4;m++){a[0]=(m&1)==0?box[0].Lo:box[0].Hi;a[1]=(m&2)==0?box[1].Lo:box[1].Hi;values.Add(Fd(a));}
                return upper?values.Max():values.Min();
            }
            Q fl=Sharp(false),fh=Sharp(true);
            if(fl==exact.Lo&&fh==exact.Hi)sharppass++;
            Q Selected(Q[] a){Q f=Fd(a);return f*a[7]/(f*a[7]+(1-f)*a[6]);}
            var selected=Corners(box,Selected);
            var sIdeal=forms[0]*iv[7]/(forms[0]*iv[7]+(1-forms[0])*iv[6]);
            var sOuter=outer*floating[7]/(outer*floating[7]+(Iv.Point(1)-outer)*floating[6]);
            Q low=fl*box[7].Lo/(fl*box[7].Lo+(1-fl)*box[6].Hi);
            Q high=fh*box[7].Hi/(fh*box[7].Hi+(1-fh)*box[6].Lo);
            if(sOuter.Contains(selected.Lo)&&sOuter.Contains(selected.Hi)&&low==selected.Lo&&high==selected.Hi)cpass++;
            ratios.Add((forms[0].Width/(exact.Hi-exact.Lo)).ToDouble());
            conditionalRatios.Add((sIdeal.Width/(selected.Hi-selected.Lo)).ToDouble());
            precision.Add(new {lo=box.Select(b=>b.Lo.ToString()).ToArray(),hi=box.Select(b=>b.Hi.ToString()).ToArray(),
                exact=new[]{exact.Lo.ToString(),exact.Hi.ToString()},naive=new[]{forms[0].Lo.ToString(),forms[0].Hi.ToString()},
                outer=new[]{outer.Lo,outer.Hi},conditionalExact=new[]{selected.Lo.ToString(),selected.Hi.ToString()},
                conditionalNaive=new[]{sIdeal.Lo.ToString(),sIdeal.Hi.ToString()},conditionalOuter=new[]{sOuter.Lo,sOuter.Hi}});
        }
        Emit("credal_checks",40,fpass,cpass,sharppass,positiveEqual,64,256);
        Emit("credal_width_ratios",Median(ratios),ratios.Max(),Median(conditionalRatios),conditionalRatios.Max());
        var qv=Enumerable.Range(0,8).Select(Poly.Var).ToArray();var oneP=Poly.Const(1);
        var fpoly=(oneP-qv[1])*((oneP-qv[0])*qv[2]+qv[0]*qv[3])+qv[1]*((oneP-qv[0])*qv[4]+qv[0]*qv[5]);
        var numerator=fpoly*qv[7];var denominator=numerator+(oneP-fpoly)*qv[6];
        Emit("multi_affine_certificate",fpoly.MaxDegreeInAnyVar,numerator.MaxDegreeInAnyVar,denominator.MaxDegreeInAnyVar);
        File.WriteAllText(Path.Combine(dir,"precision.json"),JsonSerializer.Serialize(precision,JsonOptions));
    }
}
