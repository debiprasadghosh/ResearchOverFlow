// Version 2 do-numerics: exact response-function witnesses, sharp fibre bounds by exact linear
// programming, a census of event-replacement gaps and a semantic test of clock-licensed deletion.
// Public values are immutable records; elimination and simplex routines use private scratch arrays.
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace Tcr;

/// <summary>A district of a canonical (response-function) model. Each member with k binary
/// parents has 2^(2^k) deterministic response types; a type tuple is a mixed-radix index.</summary>
public sealed record District(int Mask, ImmutableArray<int> Members, ImmutableArray<ImmutableArray<int>> Parents)
{
    public ImmutableArray<int> Radix => Members.Select((_, j) => 1 << (1 << Parents[j].Length)).ToImmutableArray();
    public int Types => Radix.Aggregate(1, (a, r) => checked(a * r));

    public static District Of(Admg g, int mask) =>
        new(mask, SetBits.Of(mask).ToImmutableArray(),
            SetBits.Of(mask).Select(i => g.D.Where(e => e.To == i).Select(e => e.From).OrderBy(p => p).ToImmutableArray()).ToImmutableArray());

    /// <summary>Does type tuple t reproduce assignment v at every member outside the action mask?</summary>
    public bool Consistent(int t, int v, int actions)
    {
        for (int j = 0; j < Members.Length; j++)
        {
            int r = Radix[j], tj = t % r; t /= r;
            int i = Members[j];
            if ((actions >> i & 1) != 0) continue;
            int idx = 0;
            for (int k = 0; k < Parents[j].Length; k++) idx |= (v >> Parents[j][k] & 1) << k;
            if ((tj >> idx & 1) != (v >> i & 1)) return false;
        }
        return true;
    }
}

/// <summary>Exact rational row reduction for rowspace membership and nullspace vectors.</summary>
public sealed record Rref(int Cols, ImmutableArray<ImmutableArray<Q>> Rows, ImmutableArray<int> Pivots)
{
    public static Rref Of(IReadOnlyList<Q[]> rows, int cols)
    {
        var m = rows.Select(r => (Q[])r.Clone()).ToList(); var piv = new List<int>(); int rank = 0;
        for (int c = 0; c < cols && rank < m.Count; c++)
        {
            int p = -1; for (int r = rank; r < m.Count; r++) if (!m[r][c].IsZero) { p = r; break; }
            if (p < 0) continue;
            (m[rank], m[p]) = (m[p], m[rank]);
            var inv = Q.One / m[rank][c];
            for (int j = c; j < cols; j++) if (!m[rank][j].IsZero) m[rank][j] = m[rank][j] * inv;
            for (int r = 0; r < m.Count; r++)
            {
                if (r == rank || m[r][c].IsZero) continue;
                var f = m[r][c];
                for (int j = c; j < cols; j++) if (!m[rank][j].IsZero) m[r][j] = m[r][j] - f * m[rank][j];
            }
            piv.Add(c); rank++;
        }
        return new(cols, m.Take(rank).Select(r => r.ToImmutableArray()).ToImmutableArray(), piv.ToImmutableArray());
    }
    /// <summary>Residual of a row after reduction; zero iff the row lies in the rowspace.</summary>
    public Q[] Residual(Q[] row)
    {
        var x = (Q[])row.Clone();
        for (int k = 0; k < Pivots.Length; k++)
        {
            var f = x[Pivots[k]]; if (f.IsZero) continue;
            for (int j = 0; j < Cols; j++) if (!Rows[k][j].IsZero) x[j] = x[j] - f * Rows[k][j];
        }
        return x;
    }
    /// <summary>The nullspace basis vector whose free column is <paramref name="free"/> (sparse).</summary>
    public ImmutableArray<(int Col, Q Val)> NullVector(int free)
    {
        var v = new List<(int, Q)> { (free, Q.One) };
        for (int k = 0; k < Pivots.Length; k++) if (!Rows[k][free].IsZero) v.Add((Pivots[k], -Rows[k][free]));
        return v.OrderBy(t => t.Item1).ToImmutableArray();
    }
}

/// <summary>Dense exact simplex (two phases, Bland's rule) for max c.q subject to A q = b, q >= 0.</summary>
public static class ExactLp
{
    public static Q? Maximize(IReadOnlyList<Q[]> a, Q[] b, Q[] c)
    {
        int m = a.Count, n = c.Length, w = n + m + 1;
        var t = new Q[m + 1, w];
        for (int i = 0; i < m; i++)
        {
            bool flip = b[i].Sign < 0;
            for (int j = 0; j < n; j++) t[i, j] = flip ? -a[i][j] : a[i][j];
            for (int j = n; j < n + m; j++) t[i, j] = j - n == i ? Q.One : Q.Zero;
            t[i, w - 1] = flip ? -b[i] : b[i];
        }
        var basis = Enumerable.Range(n, m).ToArray();
        // phase 1 objective row: maximise -sum(artificials), expressed in nonbasic terms
        for (int j = 0; j < w; j++) { Q s = Q.Zero; for (int i = 0; i < m; i++) if (j < n || j == w - 1) s = s + t[i, j]; t[m, j] = j < n ? -s : j == w - 1 ? -s : Q.Zero; }
        Run(t, basis, m, n + m, w);
        if (!t[m, w - 1].IsZero) return null;                       // infeasible
        for (int i = 0; i < m; i++)                                  // drive artificials out of the basis
        {
            if (basis[i] < n) continue;
            int col = Enumerable.Range(0, n).FirstOrDefault(j => !t[i, j].IsZero, -1);
            if (col >= 0) Pivot(t, basis, i, col, m + 1, w);
        }
        var keep = Enumerable.Range(0, m).Where(i => basis[i] < n).ToArray();
        int m2 = keep.Length; var t2 = new Q[m2 + 1, n + 1]; var basis2 = keep.Select(i => basis[i]).ToArray();
        for (int r = 0; r < m2; r++) { for (int j = 0; j < n; j++) t2[r, j] = t[keep[r], j]; t2[r, n] = t[keep[r], w - 1]; }
        for (int j = 0; j <= n; j++) t2[m2, j] = j < n ? -c[j] : Q.Zero;
        for (int r = 0; r < m2; r++)
        {
            var f = t2[m2, basis2[r]]; if (f.IsZero) continue;
            for (int j = 0; j <= n; j++) t2[m2, j] = t2[m2, j] - f * t2[r, j];
        }
        if (!Run(t2, basis2, m2, n, n + 1)) throw new InvalidOperationException("unbounded LP");
        return t2[m2, n];
    }
    static bool Run(Q[,] t, int[] basis, int m, int nVars, int w)
    {
        while (true)
        {
            int col = -1; for (int j = 0; j < nVars; j++) if (t[m, j].Sign < 0) { col = j; break; }   // Bland: lowest index
            if (col < 0) return true;
            int row = -1; Q best = Q.Zero;
            for (int i = 0; i < m; i++)
            {
                if (t[i, col].Sign <= 0) continue;
                var ratio = t[i, w - 1] / t[i, col];
                if (row < 0 || ratio < best || (ratio == best && basis[i] < basis[row])) { row = i; best = ratio; }
            }
            if (row < 0) return false;
            Pivot(t, basis, row, col, m + 1, w);
        }
    }
    static void Pivot(Q[,] t, int[] basis, int row, int col, int rows, int w)
    {
        var inv = Q.One / t[row, col];
        for (int j = 0; j < w; j++) t[row, j] = t[row, j] * inv;
        for (int i = 0; i < rows; i++)
        {
            if (i == row || t[i, col].IsZero) continue;
            var f = t[i, col];
            for (int j = 0; j < w; j++) if (!t[row, j].IsZero) t[i, j] = t[i, j] - f * t[row, j];
        }
        basis[row] = col;
    }
}

public static class DoNumerics
{
    static readonly JsonSerializerOptions Json = new() { WriteIndented = false };
    static string F(object o) => o switch
    {
        bool b => b ? "1" : "0", double d => d.ToString("R", CultureInfo.InvariantCulture),
        IFormattable f => f.ToString(null, CultureInfo.InvariantCulture), _ => o.ToString() ?? ""
    };
    static void Emit(string key, params object[] v) => Console.WriteLine(key + "\t" + string.Join(" ", v.Select(F)));
    static readonly Edge[] Pairs4 = { new(0, 1), new(0, 2), new(0, 3), new(1, 2), new(1, 3), new(2, 3) };
    static IEnumerable<int> NonEmptySubsets(int mask) { for (int s = mask; s != 0; s = (s - 1) & mask) yield return s; }

    /// <summary>Set partitions of {0..n-1} as block masks; each block becomes a bidirected clique.</summary>
    static IEnumerable<ImmutableArray<int>> Partitions(int n)
    {
        IEnumerable<ImmutableArray<int>> Go(int i, ImmutableArray<int> blocks)
        {
            if (i == n) { yield return blocks; yield break; }
            for (int k = 0; k < blocks.Length; k++) foreach (var r in Go(i + 1, blocks.SetItem(k, blocks[k] | 1 << i))) yield return r;
            foreach (var r in Go(i + 1, blocks.Add(1 << i))) yield return r;
        }
        return Go(0, ImmutableArray<int>.Empty);
    }
    static Admg CliqueGraph(int n, IEnumerable<Edge> directed, ImmutableArray<int> blocks) =>
        Admg.Make(n, directed, blocks.SelectMany(b => from i in SetBits.Of(b) from j in SetBits.Of(b) where i < j select new Edge(i, j)));

    public static void Run(string dir)
    {
        Directory.CreateDirectory(dir);
        Witnesses(dir);
        FibreBounds(dir);
        ReplacementCensus(dir);
        ClockDeletion(dir);
    }

    // ------------------------------------------------------------------ N7: witnesses
    static void Witnesses(string dir)
    {
        var graphsOut = new List<object>(); var records = new List<object>(); var rng = new Rng(20261030070UL);
        foreach (int n in new[] { 3, 4 })
        {
            var pairs = Pairs4.Where(e => e.To < n).ToArray();
            int graphs = 0, queries = 0, idYes = 0, idNo = 0, witness = 0, witnessOnIdentified = 0, failedWithout = 0, maxTypes = 0, laterBase = 0;
            Q smallestGap = Q.One;
            foreach (var blocks in Partitions(n))
            for (int dm = 0; dm < 1 << pairs.Length; dm++)
            {
                var directed = pairs.Where((_, k) => (dm >> k & 1) != 0).ToArray();
                if (Enumerable.Range(0, n).Any(i => directed.Count(e => e.To == i) > 2)) continue;   // types stay <= 16 per member
                var g = CliqueGraph(n, directed, blocks); graphs++; int gid = graphsOut.Count;
                var districts = g.Districts().Select(d => District.Of(g, d)).ToArray();
                maxTypes = Math.Max(maxTypes, districts.Max(d => d.Types));
                const int bases = 3;   // independent random base models; a later one is used only if an earlier one finds no witness
                var weights = Enumerable.Range(0, bases).Select(_ => districts.Select(d => { var w = new int[d.Types]; for (int t = 0; t < w.Length; t++) { int u; (u, rng) = rng.Int(1, 9); w[t] = u; } return w; }).ToArray()).ToArray();
                var qs = weights.Select(ws => ws.Select(w => { int tot = w.Sum(); return w.Select(u => Q.Of(u, tot)).ToArray(); }).ToArray()).ToArray();
                graphsOut.Add(new { n, directed = directed.Select(e => new[] { e.From, e.To }).ToArray(), blocks = blocks.ToArray(),
                    districts = districts.Select(d => d.Mask).ToArray(), weights });
                var uniform = new TabKernel(n, Enumerable.Repeat(Q.Of(1, 1 << n), 1 << n).ToImmutableArray(), new Joint());
                // consistency of every type tuple with every assignment, as a bit mask over assignments, per action set
                var cons = districts.Select(d => Enumerable.Range(0, 1 << n).Select(act => (act & ~d.Mask) != 0 ? null :
                    Enumerable.Range(0, d.Types).Select(t => Enumerable.Range(0, 1 << n).Aggregate(0, (m, v) => d.Consistent(t, v, act) ? m | 1 << v : m)).ToArray()).ToArray()).ToArray();
                // district factor of each district at each assignment, under each action set
                var facs = qs.Select(q => districts.Select((d, di) => Enumerable.Range(0, 1 << n).Select(act => Enumerable.Range(0, 1 << n).Select(v =>
                    Enumerable.Range(0, d.Types).Where(t => (cons[di][act & d.Mask]![t] >> v & 1) != 0).Aggregate(Q.Zero, (acc, t) => acc + q[di][t])).ToArray()).ToArray()).ToArray()).ToArray();
                var reductions = districts.Select((d, di) => Rref.Of(Enumerable.Range(0, 1 << n)
                    .Select(v => Enumerable.Range(0, d.Types).Select(t => (cons[di][0]![t] >> v & 1) != 0 ? Q.One : Q.Zero).ToArray()).ToList(), d.Types)).ToArray();
                for (int x = 1; x < 1 << n; x++)
                foreach (int y in NonEmptySubsets(((1 << n) - 1) & ~x))
                {
                    queries++;
                    bool id = Identification.Run(y, x, uniform, g).Identified;
                    if (id) idYes++; else idNo++;
                    (int D, int Xv, int Yv, ImmutableArray<(int Col, Q Val)> Delta, Q Gap, int Base)? found = null;
                    for (int bi = 0; bi < bases && found is null; bi++)
                    for (int di = 0; di < districts.Length && found is null; di++)
                    {
                        var fac = facs[bi];
                        var d = districts[di]; var cm = cons[di][x & d.Mask]!;
                        var w = Enumerable.Range(0, 1 << n).Select(v => Enumerable.Range(0, districts.Length).Where(dj => dj != di)
                            .Aggregate(Q.One, (acc, dj) => acc * fac[dj][x][v])).ToArray();
                        for (int xv = 0; xv < 1 << n && found is null; xv++)
                        {
                            if ((xv & ~x) != 0) continue;
                            for (int yv = 0; yv < 1 << n && found is null; yv++)
                            {
                                if ((yv & ~y) != 0) continue;
                                var sel = Enumerable.Range(0, 1 << n).Where(v => (v & x) == xv && (v & y) == yv).ToArray();
                                var row = new Q[d.Types];
                                for (int t = 0; t < d.Types; t++) { Q acc = Q.Zero; foreach (int v in sel) if ((cm[t] >> v & 1) != 0) acc += w[v]; row[t] = acc; }
                                var res = reductions[di].Residual(row);
                                int free = Array.FindIndex(res, z => !z.IsZero);
                                if (free < 0) continue;
                                var delta = reductions[di].NullVector(free);
                                Q gap = delta.Aggregate(Q.Zero, (acc, e) => acc + e.Val * row[e.Col]);
                                found = (di, xv, yv, delta, gap, bi);
                            }
                        }
                    }
                    if (found is { } f)
                    {
                        witness++; if (id) witnessOnIdentified++; if (f.Base > 0) laterBase++;
                        var d = districts[f.D]; Q maxAbs = f.Delta.Max(e => e.Val.Sign < 0 ? -e.Val : e.Val);
                        Q eps = qs[f.Base][f.D].Aggregate(Q.Min) / (2 * maxAbs);       // keeps model B strictly positive
                        Q diff = eps * f.Gap; if (diff.Sign < 0) diff = -diff;
                        if (diff < smallestGap) smallestGap = diff;
                        records.Add(new { graph = gid, x, y, identified = id, district = d.Mask, xv = f.Xv, yv = f.Yv, baseModel = f.Base,
                            delta = f.Delta.Select(e => new[] { e.Col.ToString(), e.Val.ToString() }).ToArray(),
                            eps = eps.ToString(), queryDifference = diff.ToString() });
                    }
                    else
                    {
                        if (!id) failedWithout++;
                        records.Add(new { graph = gid, x, y, identified = id, district = 0 });
                    }
                }
            }
            Emit($"witness_n{n}", graphs, queries, idYes, idNo, witness, witnessOnIdentified, failedWithout, maxTypes, smallestGap, laterBase);
        }
        File.WriteAllText(Path.Combine(dir, "witnesses.json"), JsonSerializer.Serialize(new { graphs = graphsOut, queries = records }, Json));
    }

    // ------------------------------------------------------------------ N8: sharp fibre bounds
    static void FibreBounds(string dir)
    {
        var rng = new Rng(20261030071UL); var records = new List<object>();
        int graphs = 0, lps = 0, idZero = 0, idTotal = 0, idMatch = 0, nonId = 0, nonIdPositive = 0, truthInside = 0, insideNatural = 0, strictlyTighter = 0;
        double widthSum = 0; Q minNonIdWidth = Q.One;
        var cases = new List<(string Name, Admg G)>();
        cases.Add(("bow", Admg.Make(2, new[] { new Edge(0, 1) }, new[] { new Edge(0, 1) })));
        foreach (var blocks in Partitions(3).Where(b => b.Count(m => SetBits.Count(m) > 1) == 1))
            for (int dm = 0; dm < 8; dm++)
                cases.Add(($"g3_{string.Join("_", blocks)}_{dm}", CliqueGraph(3, new[] { new Edge(0, 1), new Edge(0, 2), new Edge(1, 2) }.Where((_, k) => (dm >> k & 1) != 0), blocks)));
        Q bowLo = 0, bowHi = 0, bowNatLo = 0, bowNatHi = 0; Q ivLo = 0, ivHi = 0, ivNatLo = 0, ivNatHi = 0;
        foreach (var (name, g) in cases)
        {
            graphs++; int n = g.N;
            var districts = g.Districts().Select(d => District.Of(g, d)).ToArray();
            int big = Array.FindIndex(districts, d => d.Members.Length > 1);
            // a random positive canonical model: integer weights 1..9 on every type tuple
            var q = new Q[districts.Length][];
            for (int k = 0; k < districts.Length; k++)
            {
                var wts = new int[districts[k].Types];
                for (int t = 0; t < wts.Length; t++) { int u; (u, rng) = rng.Int(1, 9); wts[t] = u; }
                int total = wts.Sum(); q[k] = wts.Select(u => Q.Of(u, total)).ToArray();
            }
            Q Factor(int k, int v, int actions) =>
                Enumerable.Range(0, districts[k].Types).Where(t => districts[k].Consistent(t, v, actions)).Aggregate(Q.Zero, (s, t) => s + q[k][t]);
            Q Prob(int v, int actions, int values) =>
                (v & actions) != (values & actions) ? Q.Zero : Enumerable.Range(0, districts.Length).Aggregate(Q.One, (s, k) => s * Factor(k, v, actions));
            var obs = Enumerable.Range(0, 1 << n).Select(v => Prob(v, 0, 0)).ToArray();
            var law = new TabKernel(n, obs.ToImmutableArray(), new Joint());
            var d = districts[big];
            var others = Enumerable.Range(0, districts.Length).Where(k => k != big).ToArray();
            var aRows = new List<Q[]>(); var bVals = new List<Q>();
            for (int v = 0; v < 1 << n; v++)
            {
                Q other = others.Aggregate(Q.One, (s, k) => s * Factor(k, v, 0));
                aRows.Add(Enumerable.Range(0, d.Types).Select(t => d.Consistent(t, v, 0) ? other : Q.Zero).ToArray());
                bVals.Add(obs[v]);
            }
            for (int xi = 0; xi < n; xi++) for (int yi = 0; yi < n; yi++)
            {
                if (xi == yi) continue;
                for (int xv = 0; xv <= 1; xv++)
                {
                    int x = 1 << xi, xvals = xv << xi;
                    var c = new Q[d.Types];
                    for (int t = 0; t < d.Types; t++)
                    {
                        Q s = Q.Zero;
                        for (int v = 0; v < 1 << n; v++)
                        {
                            if ((v & x) != xvals || (v >> yi & 1) != 1 || !d.Consistent(t, v, x)) continue;
                            s += others.Aggregate(Q.One, (acc, k) => acc * Factor(k, v, x));
                        }
                        c[t] = s;
                    }
                    var hi = ExactLp.Maximize(aRows, bVals.ToArray(), c) ?? throw new InvalidOperationException("infeasible fibre");
                    var lo = -(ExactLp.Maximize(aRows, bVals.ToArray(), c.Select(z => -z).ToArray()) ?? throw new InvalidOperationException());
                    lps += 2;
                    Q truth = Enumerable.Range(0, 1 << n).Where(v => (v >> yi & 1) == 1).Aggregate(Q.Zero, (s, v) => s + Prob(v, x, xvals));
                    var ans = Identification.Run(1 << yi, x, law, g);
                    Q pxy = BinaryScm.Mass(law, x | 1 << yi, xvals | 1 << yi), px = BinaryScm.Mass(law, x, xvals);
                    Q natLo = pxy, natHi = pxy + 1 - px;
                    if (lo <= truth && truth <= hi) truthInside++;
                    if (natLo <= lo && hi <= natHi) insideNatural++;
                    if (natLo < lo || hi < natHi) strictlyTighter++;
                    if (ans.Identified)
                    {
                        idTotal++; if (lo == hi) idZero++;
                        Q idv = Enumerable.Range(0, 1 << n).Where(v => (v & x) == xvals && (v >> yi & 1) == 1).Select(v => ans.Kernel!.Values[v]).First();
                        if (idv == lo && idv == hi) idMatch++;
                    }
                    else
                    {
                        nonId++; if (hi > lo) nonIdPositive++;
                        if (hi - lo < minNonIdWidth) minNonIdWidth = hi - lo;
                        widthSum += (hi - lo).ToDouble();
                    }
                    if (name == "bow" && xv == 1 && yi == 1) { bowLo = lo; bowHi = hi; bowNatLo = natLo; bowNatHi = natHi; }
                    if (name == "g3_1_6_5" && xi == 1 && yi == 2 && xv == 1) { ivLo = lo; ivHi = hi; ivNatLo = natLo; ivNatHi = natHi; }
                    records.Add(new { graph = name, n, directed = g.D.Select(e => new[] { e.From, e.To }).ToArray(), bidirected = g.B.Select(e => new[] { e.From, e.To }).ToArray(),
                        q = q.Select(r => r.Select(z => z.ToString()).ToArray()).ToArray(), x = xi, y = yi, xv, lo = lo.ToString(), hi = hi.ToString(),
                        truth = truth.ToString(), identified = ans.Identified, naturalLo = natLo.ToString(), naturalHi = natHi.ToString() });
                }
            }
        }
        Emit("fibre_bounds", graphs, lps, idTotal, idZero, idMatch, nonId, nonIdPositive, truthInside, insideNatural, strictlyTighter);
        Emit("fibre_widths", minNonIdWidth, widthSum / nonId);
        Emit("fibre_bow", bowLo, bowHi, bowNatLo, bowNatHi);
        Emit("fibre_iv", ivLo, ivHi, ivNatLo, ivNatHi);
        File.WriteAllText(Path.Combine(dir, "fibres.json"), JsonSerializer.Serialize(records, Json));
    }

    // ------------------------------------------------------------------ N9: replacement census
    static void ReplacementCensus(string dir)
    {
        var rng = new Rng(20261030072UL); var rows = new List<string> { "directed,bidirected,position,certified,identified,tv,id_exact" };
        int cases = 0, cert = 0, certNonzero = 0, uncert = 0, uncertNonzero = 0, uncertId = 0, uncertIdNonzero = 0, idExact = 0, idTotal = 0;
        var tvs = new List<Q>();
        for (int dm = 0; dm < 64; dm++) for (int bm = 0; bm < 64; bm++)
        {
            var g = Admg.Make(4, Pairs4.Where((_, k) => (dm >> k & 1) != 0), Pairs4.Where((_, k) => (bm >> k & 1) != 0));
            var pk = new int[4]; for (int i = 0; i < 4; i++) { int u; (u, rng) = rng.Int(1, 3); pk[i] = u == 2 ? 1 : u; }
            var lk = new int[g.B.Length]; for (int j = 0; j < lk.Length; j++) { int u; (u, rng) = rng.Int(1, 3); lk[j] = u == 2 ? 3 : u; }
            var model = new BinaryScm(g, pk.ToImmutableArray(), lk.ToImmutableArray());
            var obs = model.Law();
            for (int s = 0; s < 4; s++)
            {
                cases++;
                var truth = model.Law(1 << s, 1 << s); var repl = BinaryScm.Replacement(obs, s, 1); var tv = BinaryScm.Tv(repl, truth);
                bool certified = g.LastInDistrict(s);
                var ans = Identification.Run(g.V & ~(1 << s), 1 << s, obs, g);
                bool exact = false;
                if (ans.Identified)
                {
                    idTotal++;
                    exact = Enumerable.Range(0, 16).Where(b => (b >> s & 1) == 1).All(b => ans.Kernel!.Values[b] == truth.Values[b]);
                    if (exact) idExact++;
                }
                if (certified) { cert++; if (!tv.IsZero) certNonzero++; }
                else
                {
                    uncert++; if (!tv.IsZero) { uncertNonzero++; tvs.Add(tv); }
                    if (ans.Identified) { uncertId++; if (!tv.IsZero) uncertIdNonzero++; }
                }
                rows.Add($"{dm},{bm},{s},{(certified ? 1 : 0)},{(ans.Identified ? 1 : 0)},{tv},{(exact ? 1 : 0)}");
            }
        }
        var sorted = tvs.OrderBy(t => t).ToArray();
        Emit("replacement_census", cases, cert, certNonzero, uncert, uncertNonzero, uncertId, uncertIdNonzero, idTotal, idExact);
        Emit("replacement_gaps", sorted[(sorted.Length - 1) / 2], sorted[^1], sorted.Aggregate(Q.Zero, (a, b) => a + b) / sorted.Length);
        File.WriteAllLines(Path.Combine(dir, "replacement_census.csv"), rows);
    }

    // ------------------------------------------------------------------ N10: clock-licensed deletion
    static void ClockDeletion(string dir)
    {
        var rng = new Rng(20261030073UL); const int narratives = 256, n = 6;
        int queries = 0, extractorDel = 0, extractorBad = 0, truthAllowed = 0, truthAllowedBad = 0, certifiedDel = 0, certifiedBad = 0, tieDecided = 0, tieBad = 0;
        var records = new List<object>();
        var pairs = (from i in Enumerable.Range(0, n) from j in Enumerable.Range(i + 1, n - i - 1) select new Edge(i, j)).ToArray();
        for (int it = 0; it < narratives; it++)
        {
            var truth = new Q[n]; truth[0] = 0;
            for (int i = 1; i < n; i++) { int k; (k, rng) = rng.Int(1, 38); truth[i] = truth[i - 1] + Q.Of(k, 48); }
            var directed = new List<Edge>();
            foreach (var e in pairs) { double u; (u, rng) = rng.Uniform(); if (u < .3) directed.Add(e); }
            int nb; (nb, rng) = rng.Int(1, 3); var bid = new List<Edge>();
            while (bid.Count < nb) { int k; (k, rng) = rng.Int(0, pairs.Length - 1); if (!bid.Contains(pairs[k])) bid.Add(pairs[k]); }
            var g = Admg.Make(n, directed, bid);
            var pk = new int[n]; for (int i = 0; i < n; i++) { int u; (u, rng) = rng.Int(1, 3); pk[i] = u == 2 ? 1 : u; }
            var lk = new int[bid.Count]; for (int j = 0; j < lk.Length; j++) { int u; (u, rng) = rng.Int(1, 3); lk[j] = u == 2 ? 3 : u; }
            var model = new BinaryScm(g, pk.ToImmutableArray(), lk.ToImmutableArray());
            var dates = new List<(int Ev, Q Lo, Q Hi)>(); var point = new Q[n];
            for (int i = 0; i < n; i++)
            {
                double u; (u, rng) = rng.Uniform(); int periods = u < .7 ? 1 : 12;
                Q l = Q.Floor(truth[i] * periods) / periods; dates.Add((i + 1, l, l + Q.One / periods)); point[i] = l;
            }
            var lags = new List<(int From, int To, Q MinLag, Q? MaxLag)>();
            foreach (var e in pairs)
            {
                bool edge = directed.Contains(e); double u; (u, rng) = rng.Uniform();
                if (!edge && u >= .3) continue;
                Q l = Q.Floor((truth[e.To] - truth[e.From]) * 4) / 4; double z; (z, rng) = rng.Uniform();
                lags.Add((e.From + 1, e.To + 1, l, z < .5 ? l + Q.Of(1, 2) : null));
            }
            var dist = Stn.Build(n, dates, lags).Distances();
            if (!Stn.Consistent(dist)) throw new InvalidOperationException("clock network must be consistent");
            var order = Enumerable.Range(0, n).ToArray();
            for (int i = n - 1; i > 0; i--) { int j; (j, rng) = rng.Int(0, i); (order[i], order[j]) = (order[j], order[i]); }
            var rank = new int[n]; for (int i = 0; i < n; i++) rank[order[i]] = i;
            bool ExtractorEarlier(int a, int b) => point[a] < point[b] || (point[a] == point[b] && rank[a] < rank[b]);
            bool Certified(int a, int b) => Stn.MinGap(dist, a + 1, b + 1) is Q gap && gap > Q.Zero;
            var obs = model.Law();
            var doLaws = Enumerable.Range(0, n).Select(a => new[] { model.Law(1 << a, 0), model.Law(1 << a, 1 << a) }).ToArray();
            for (int y = 0; y < n; y++) for (int a = 0; a < n; a++)
            {
                if (y == a) continue;
                for (int c = -1; c < n; c++)
                {
                    if (c == y || c == a) continue;
                    queries++;
                    int mask = 1 << y | (c >= 0 ? 1 << c : 0);
                    bool valid = doLaws[a].All(law => Enumerable.Range(0, 1 << n).Where(b => (b & ~mask) == 0)
                        .All(b => BinaryScm.Mass(law, mask, b) == BinaryScm.Mass(obs, mask, b)));
                    bool ext = ExtractorEarlier(y, a) && (c < 0 || ExtractorEarlier(c, a));
                    bool tru = truth[y] < truth[a] && (c < 0 || truth[c] < truth[a]);
                    bool cer = Certified(y, a) && (c < 0 || Certified(c, a));
                    bool tie = point[y] == point[a] || (c >= 0 && point[c] == point[a]);
                    if (ext) { extractorDel++; if (!valid) extractorBad++; if (tie) { tieDecided++; if (!valid) tieBad++; } }
                    if (tru) { truthAllowed++; if (!valid) truthAllowedBad++; }
                    if (cer) { certifiedDel++; if (!valid) certifiedBad++; }
                }
            }
            records.Add(new { truth = truth.Select(z => z.ToString()).ToArray(), directed = directed.Select(e => new[] { e.From, e.To }).ToArray(),
                bidirected = bid.Select(e => new[] { e.From, e.To }).ToArray(), privateK = pk, latentK = lk,
                dates = dates.Select(d => new[] { d.Lo.ToString(), d.Hi.ToString() }).ToArray(),
                lags = lags.Select(l => new[] { l.From.ToString(), l.To.ToString(), l.MinLag.ToString(), l.MaxLag?.ToString() ?? "" }).ToArray(), textOrder = order });
        }
        Emit("clock_deletion", narratives, queries, extractorDel, extractorBad, tieDecided, tieBad, truthAllowed, truthAllowedBad, certifiedDel, certifiedBad);
        File.WriteAllText(Path.Combine(dir, "clock_deletion.json"), JsonSerializer.Serialize(records, Json));
    }
}
