"""Independent validation of the Version 2 do-numerics (kernel run with --v2).

Reuses the V1 validator's own graph, ID and exogenous-enumeration routines (copied verbatim into
_shared_v1.py) and adds independent response-type decoding, witness certificate checks, LP
re-solution with HiGHS, and exact replays of the random streams. Usage:
    python validate_v2.py <cs_v2.txt> <output dir> <validation json>"""
from __future__ import annotations
import itertools, json, math, random, sys, time
from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import numpy as np
from scipy.optimize import linprog

exec(Path(__file__).with_name("_shared_v1.py").read_text())
cs = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1].split() for l in open(sys.argv[1])}
out = Path(sys.argv[2]); checks = []


def check(name, ok, detail=""):
    checks.append(dict(name=name, passed=bool(ok), detail=str(detail)[:400]))
    print(("PASS " if ok else "FAIL ") + name, str(detail)[:200], flush=True)


class Rng:
    def __init__(s, st): s.s = st
    def next(s):
        s.s = (s.s + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF; z = s.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & 0xFFFFFFFFFFFFFFFF
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & 0xFFFFFFFFFFFFFFFF
        return z ^ (z >> 31)
    def uniform(s): return (s.next() >> 11) * (1.0 / 9007199254740992.0)
    def int(s, lo, hi): return lo + math.floor(s.uniform() * (hi - lo + 1))


class Dist:
    """Response-type district, decoded independently: members ascending, parents ascending,
    member j has radix 2^(2^k_j), first member least significant."""
    def __init__(s, mask_, directed):
        s.mask = mask_; s.members = sorted(bits(mask_))
        s.parents = [sorted(a for a, b in directed if b == i) for i in s.members]
        s.radix = [1 << (1 << len(p)) for p in s.parents]; s.types = math.prod(s.radix)
    def decode(s, t):
        out = []
        for r in s.radix: out.append(t % r); t //= r
        return out
    def cons(s, t, v, act):
        for tj, i, pa in zip(s.decode(t), s.members, s.parents):
            if act >> i & 1: continue
            idx = sum((v >> p & 1) << k for k, p in enumerate(pa))
            if (tj >> idx & 1) != (v >> i & 1): return False
        return True


def fac(d, q, v, act):
    return sum((q[t] for t in range(d.types) if d.cons(t, v, act & d.mask)), F(0))


# ===================================================================== N7 witnesses
t0 = time.time()
W = json.loads((out / "witnesses.json").read_text())
rng = Rng(20261030070); graphs = []
weights_ok = True
for g in W["graphs"]:
    n = g["n"]; G = Graph(n, g["directed"], [(i, j) for b in g["blocks"] for i in bits(b) for j in bits(b) if i < j])
    ds = [Dist(mask(c), g["directed"]) for c in G.districts()]
    if [d.mask for d in ds] != g["districts"]: weights_ok = False
    ws = [[[rng.int(1, 9) for _ in range(d.types)] for d in ds] for _ in range(3)]
    if ws != g["weights"]: weights_ok = False
    qs = [[[F(u, sum(w)) for u in w] for w in base] for base in ws]
    graphs.append((n, G, ds, qs))
check("witness_stream_and_districts", weights_ok, len(graphs))

dec_ok = cert_ok = True; stats = defaultdict(lambda: [0] * 9); smallest = {3: None, 4: None}; later = defaultdict(int)
y0_checked = y0_agree = 0
full_checked = full_ok = 0
random.seed(7)
for rec in W["queries"]:
    n, G, ds, qs = graphs[rec["graph"]]
    x, y = rec["x"], rec["y"]
    uni = Kernel([F(1, 1 << n)] * (1 << n))
    try: identify(bits(y), bits(x), uni, G); ident = True
    except Failure: ident = False
    if ident != rec["identified"]: dec_ok = False
    st = stats[n]; st[0] += 1; st[1 if ident else 2] += 1
    if rec["district"] == 0:
        if not ident: st[3] += 1           # failure without witness
        continue
    st[4] += 1
    if ident: st[5] += 1
    di = next(k for k, d in enumerate(ds) if d.mask == rec["district"]); d = ds[di]
    base = rec["baseModel"]; q = qs[base]
    if base > 0: later[n] += 1
    delta = [(int(c), F(v)) for c, v in rec["delta"]]; eps = F(rec["eps"])
    # (a) the perturbation leaves every observational cell unchanged
    a_ok = all(sum((val for t, val in delta if d.cons(t, v, 0)), F(0)) == 0 for v in range(1 << n))
    # (b) it changes the query value at (xv, yv) by exactly the reported amount
    sel = [v for v in range(1 << n) if (v & x) == rec["xv"] and (v & y) == rec["yv"]]
    def weight(v): return math.prod((fac(ds[k], q[k], v, x) for k in range(len(ds)) if k != di), start=F(1))
    gap = sum((val * sum((weight(v) for v in sel if d.cons(t, v, x)), F(0)) for t, val in delta), F(0))
    diff = abs(eps * gap)
    b_ok = diff == F(rec["queryDifference"]) and diff != 0
    # (c) model B stays strictly positive
    c_ok = eps * max(abs(v) for _, v in delta) < min(q[di])
    if not (a_ok and b_ok and c_ok): cert_ok = False
    smallest[n] = diff if smallest[n] is None else min(smallest[n], diff)
    # full joint enumeration of both models for a sample
    tot_types = math.prod(dd.types for dd in ds)
    if tot_types <= 4096 and (n == 3 or random.random() < 0.04):
        full_checked += 1
        qb = [list(r) for r in q]
        for t, val in delta: qb[di][t] += eps * val
        def laws(qq, act, vals):
            p = [F(0)] * (1 << n)
            for tup in itertools.product(*[range(dd.types) for dd in ds]):
                wgt = math.prod((qq[k][tup[k]] for k in range(len(ds))), start=F(1))
                for v in range(1 << n):
                    if (v & act) != (vals & act): continue
                    if all(ds[k].cons(tup[k], v, act & ds[k].mask) for k in range(len(ds))): p[v] += wgt
            return p
        oa, ob = laws(q, 0, 0), laws(qb, 0, 0)
        da, db = laws(q, x, rec["xv"]), laws(qb, x, rec["xv"])
        qa_ = sum((da[v] for v in range(1 << n) if (v & y) == rec["yv"]), F(0)); qb_ = sum((db[v] for v in range(1 << n) if (v & y) == rec["yv"]), F(0))
        if oa == ob and abs(qa_ - qb_) == diff and min(min(r) for r in qb) > 0 and sum(oa) == 1: full_ok += 1
check("witness_python_id_agrees", dec_ok)
check("witness_certificates", cert_ok)
check("witness_full_enumeration", full_checked == full_ok and full_checked > 0, (full_checked, full_ok))
for n in (3, 4):
    g_count = sum(1 for gg in graphs if gg[0] == n); st = stats[n]
    want = [g_count, st[0], st[1], st[2], st[4], st[5], st[3]]
    got = cs[f"witness_n{n}"]
    check(f"witness_n{n}", [int(v) for v in got[:7]] == want and F(got[8]) == smallest[n] and int(got[9]) == later[n], (got, want, smallest[n], later[n]))
# y0 as a third decision route on every three-vertex query and a sample of four-vertex queries
from y0.dsl import Variable
from y0.graph import NxMixedGraph
from y0.algorithm.identify import identify_outcomes
random.seed(11); y0_error = 0
for rec in W["queries"]:
    n, G, ds, qs = graphs[rec["graph"]]
    if n == 4 and random.random() > 0.05: continue
    nodes = [Variable("V" + str(i)) for i in range(n)]
    yg = NxMixedGraph.from_edges(nodes=nodes, directed=[(nodes[a], nodes[b]) for a, b in G.d], undirected=[(nodes[a], nodes[b]) for a, b in G.b])
    yg.directed.add_nodes_from(nodes); yg.undirected.add_nodes_from(nodes)
    try: ok = identify_outcomes(yg, treatments={nodes[i] for i in bits(rec["x"])}, outcomes={nodes[i] for i in bits(rec["y"])}) is not None
    except Exception: y0_error += 1; continue
    y0_checked += 1; y0_agree += ok == rec["identified"]
check("witness_y0_decisions", y0_checked > 0 and y0_checked == y0_agree, (y0_checked, y0_agree, "y0 internal errors", y0_error))
print("witness time", round(time.time() - t0, 1), flush=True)

# ===================================================================== N8 fibre bounds
t0 = time.time()
R = json.loads((out / "fibres.json").read_text())
agg = [0] * 10; graphs_seen = []; widths = []; minw = None; lp_ok = True; exact_ok = True; bow = iv = None
for r in R:
    n = r["n"]; G = Graph(n, r["directed"], r["bidirected"])
    if r["graph"] not in graphs_seen: graphs_seen.append(r["graph"])
    ds = [Dist(mask(c), r["directed"]) for c in G.districts()]
    q = [[F(z) for z in row] for row in r["q"]]
    big = next(k for k, d in enumerate(ds) if len(d.members) > 1); d = ds[big]; others = [k for k in range(len(ds)) if k != big]
    obs = [math.prod((fac(ds[k], q[k], v, 0) for k in range(len(ds))), start=F(1)) for v in range(1 << n)]
    xi, yi, xv = r["x"], r["y"], r["xv"]; x = 1 << xi; xvals = xv << xi
    A = np.array([[float(math.prod((fac(ds[k], q[k], v, 0) for k in others), start=F(1))) if d.cons(t, v, 0) else 0.0 for t in range(d.types)] for v in range(1 << n)])
    b = np.array([float(p) for p in obs])
    c = np.array([float(sum((math.prod((fac(ds[k], q[k], v, x) for k in others), start=F(1)) for v in range(1 << n)
                            if (v & x) == xvals and v >> yi & 1 and d.cons(t, v, x)), F(0))) for t in range(d.types)])
    hi = -linprog(-c, A_eq=A, b_eq=b, bounds=(0, None), method="highs").fun
    lo = linprog(c, A_eq=A, b_eq=b, bounds=(0, None), method="highs").fun
    clo, chi = F(r["lo"]), F(r["hi"])
    if abs(float(clo) - lo) > 1e-8 or abs(float(chi) - hi) > 1e-8: lp_ok = False
    truth = sum((math.prod((fac(ds[k], q[k], v, x) for k in range(len(ds))), start=F(1)) for v in range(1 << n) if (v & x) == xvals and v >> yi & 1), F(0))
    if truth != F(r["truth"]): exact_ok = False
    pk = Kernel(obs)
    try:
        kern = identify({yi}, {xi}, pk, G); ident = True
        idv = next(kern.a[v] for v in range(1 << n) if (v & x) == xvals and v >> yi & 1)
    except Failure: ident = False
    if ident != r["identified"]: exact_ok = False
    pxy = sum((obs[v] for v in range(1 << n) if (v & x) == xvals and v >> yi & 1), F(0)); px = sum((obs[v] for v in range(1 << n) if (v & x) == xvals), F(0))
    nlo, nhi = pxy, pxy + 1 - px
    if (nlo, nhi) != (F(r["naturalLo"]), F(r["naturalHi"])): exact_ok = False
    agg[1] += 2
    if clo <= truth <= chi: agg[7] += 1
    if nlo <= clo and chi <= nhi: agg[8] += 1
    if nlo < clo or chi < nhi: agg[9] += 1
    if ident:
        agg[2] += 1; agg[3] += clo == chi; agg[4] += clo == chi == idv
    else:
        agg[5] += 1; agg[6] += chi > clo; widths.append(chi - clo); minw = chi - clo if minw is None else min(minw, chi - clo)
    if r["graph"] == "bow" and xv == 1 and yi == 1: bow = (clo, chi, nlo, nhi)
    if r["graph"] == "g3_1_6_5" and xi == 1 and yi == 2 and xv == 1: iv = (clo, chi, nlo, nhi)
agg[0] = len(graphs_seen)
check("fibre_lp_highs", lp_ok); check("fibre_exact_inputs", exact_ok)
check("fibre_bounds", [int(v) for v in cs["fibre_bounds"]] == agg, (cs["fibre_bounds"], agg))
check("fibre_widths", F(cs["fibre_widths"][0]) == minw and abs(float(cs["fibre_widths"][1]) - float(sum(widths)) / len(widths)) < 1e-12)
check("fibre_bow", [F(v) for v in cs["fibre_bow"]] == list(bow) and bow[0] == bow[2] and bow[1] == bow[3], bow)
check("fibre_iv", [F(v) for v in cs["fibre_iv"]] == list(iv) and iv[2] < iv[0] and iv[1] < iv[3], iv)
print("fibre time", round(time.time() - t0, 1), flush=True)

# ===================================================================== N9 replacement census
t0 = time.time()
P4 = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
rng = Rng(20261030072); rows = []; agg = [0] * 9; gaps = []
csv_rows = (out / "replacement_census.csv").read_text().splitlines()[1:]
for dm in range(64):
    for bm in range(64):
        d = [P4[k] for k in range(6) if dm >> k & 1]; b = [P4[k] for k in range(6) if bm >> k & 1]
        pk = [1 if (u := rng.int(1, 3)) == 2 else u for _ in range(4)]
        lk = [3 if (u := rng.int(1, 3)) == 2 else u for _ in range(len(b))]
        m = Model(dict(n=4, directed=d, bidirected=b, privateK=pk, latentK=lk)); obs = m.law(); G = m.g
        for s in range(4):
            truth = m.law(1 << s, 1 << s); rep = replacement(obs, s, 1); gap = tv(rep, truth)
            cert = not (next(c for c in G.districts() if s in c) & set(range(s + 1, 4)))
            try:
                kern = identify(set(range(4)) - {s}, {s}, obs, G); ident = True
                exact = all(kern.a[v] == truth.a[v] for v in range(16) if v >> s & 1)
            except Failure: ident = False; exact = False
            agg[0] += 1
            if ident: agg[7] += 1; agg[8] += exact
            if cert: agg[1] += 1; agg[2] += gap != 0
            else:
                agg[3] += 1
                if gap != 0: agg[4] += 1; gaps.append(gap)
                if ident: agg[5] += 1; agg[6] += gap != 0
            rows.append(f"{dm},{bm},{s},{int(cert)},{int(ident)},{gap.numerator if gap.denominator == 1 else f'{gap.numerator}/{gap.denominator}'},{int(exact)}")
check("replacement_csv_rows", rows == csv_rows, sum(a != b for a, b in zip(rows, csv_rows)))
check("replacement_census", [int(v) for v in cs["replacement_census"]] == agg, (cs["replacement_census"], agg))
gs = sorted(gaps)
check("replacement_gaps", [F(v) for v in cs["replacement_gaps"]] == [gs[(len(gs) - 1) // 2], gs[-1], sum(gs, F(0)) / len(gs)])
print("census time", round(time.time() - t0, 1), flush=True)

# ===================================================================== N10 clock-licensed deletion
t0 = time.time()
rng = Rng(20261030073); n = 6; pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
agg = [256, 0, 0, 0, 0, 0, 0, 0, 0, 0]; recs = json.loads((out / "clock_deletion.json").read_text()); same = True


def floyd(N, cons):
    dd = [[F(0) if i == j else None for j in range(N)] for i in range(N)]
    for i, j, c in cons:
        if dd[i][j] is None or c < dd[i][j]: dd[i][j] = c
    for k in range(N):
        for i in range(N):
            for j in range(N):
                if dd[i][k] is not None and dd[k][j] is not None and (dd[i][j] is None or dd[i][k] + dd[k][j] < dd[i][j]): dd[i][j] = dd[i][k] + dd[k][j]
    return dd


for it in range(256):
    truth = [F(0)]
    for i in range(1, n): truth.append(truth[-1] + F(rng.int(1, 38), 48))
    directed = [e for e in pairs if rng.uniform() < .3]
    nb = rng.int(1, 3); bid = []
    while len(bid) < nb:
        k = rng.int(0, len(pairs) - 1)
        if pairs[k] not in bid: bid.append(pairs[k])
    pk = [1 if (u := rng.int(1, 3)) == 2 else u for _ in range(n)]
    lk = [3 if (u := rng.int(1, 3)) == 2 else u for _ in range(len(bid))]
    dates, point = [], []
    for i in range(n):
        per = 1 if rng.uniform() < .7 else 12
        l = F(math.floor(truth[i] * per), per); dates.append((i + 1, l, l + F(1, per))); point.append(l)
    lags = []
    for e in pairs:
        edge = e in directed; u = rng.uniform()
        if not edge and u >= .3: continue
        l = F(math.floor((truth[e[1]] - truth[e[0]]) * 4), 4); z = rng.uniform()
        lags.append((e[0] + 1, e[1] + 1, l, l + F(1, 2) if z < .5 else None))
    cons = []
    for ev, lo, hi in dates: cons += [(0, ev, hi), (ev, 0, -lo)]
    for f_, t_, mn, mx in lags:
        cons.append((t_, f_, -mn))
        if mx is not None: cons.append((f_, t_, mx))
    dist = floyd(n + 1, cons); assert all(dist[i][i] >= 0 for i in range(n + 1))
    order = list(range(n))
    for i in range(n - 1, 0, -1):
        j = rng.int(0, i); order[i], order[j] = order[j], order[i]
    rank = [0] * n
    for i, o in enumerate(order): rank[o] = i
    rec = recs[it]
    if [F(v) for v in rec["truth"]] != truth or [tuple(e) for e in rec["directed"]] != directed or rec["textOrder"] != order: same = False
    # LatentK pairs with the sorted bidirected list, as in the C# model record
    m = Model(dict(n=n, directed=directed, bidirected=sorted(bid), privateK=pk, latentK=lk))
    obs = m.law(); dos = [[m.law(1 << a, 0), m.law(1 << a, 1 << a)] for a in range(n)]
    ext_e = lambda a, b: point[a] < point[b] or (point[a] == point[b] and rank[a] < rank[b])
    cert = lambda a, b: dist[b + 1][a + 1] is not None and -dist[b + 1][a + 1] > 0
    for y in range(n):
        for a in range(n):
            if y == a: continue
            for c in range(-1, n):
                if c in (y, a): continue
                agg[1] += 1; msk = 1 << y | ((1 << c) if c >= 0 else 0)
                valid = all(mass(law.a, msk, bb) == mass(obs.a, msk, bb) for law in dos[a] for bb in range(1 << n) if bb & ~msk == 0)
                ext = ext_e(y, a) and (c < 0 or ext_e(c, a)); tru = truth[y] < truth[a] and (c < 0 or truth[c] < truth[a])
                cer = cert(y, a) and (c < 0 or cert(c, a)); tie = point[y] == point[a] or (c >= 0 and point[c] == point[a])
                if ext:
                    agg[2] += 1; agg[3] += not valid
                    if tie: agg[4] += 1; agg[5] += not valid
                if tru: agg[6] += 1; agg[7] += not valid
                if cer: agg[8] += 1; agg[9] += not valid
check("clock_deletion_stream", same)
check("clock_deletion", [int(v) for v in cs["clock_deletion"]] == agg, (cs["clock_deletion"], agg))
print("clock time", round(time.time() - t0, 1), flush=True)

missing = [k for k in cs if not any(c["name"] == k for c in checks)]
for k in missing: check(k, False, "not validated")
json.dump(dict(checks=checks, all_passed=all(c["passed"] for c in checks), lines=len(cs)), open(sys.argv[3], "w"), indent=1)
print("ALL", all(c["passed"] for c in checks), "lines", len(cs), "checks", len(checks))
