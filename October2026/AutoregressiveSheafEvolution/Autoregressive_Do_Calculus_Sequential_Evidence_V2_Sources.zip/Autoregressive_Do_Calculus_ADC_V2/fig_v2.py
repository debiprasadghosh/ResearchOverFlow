"""Figure 3 of ADC V2, drawn from the validated --v2 kernel outputs."""
import json, sys
from fractions import Fraction as F
from pathlib import Path
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
H = Path(__file__).resolve().parent; out = H / "out_v2"
B, O, A, INK, MUT, GR = "#2a78d6", "#eb6834", "#1baf7a", "#222222", "#6b6b6b", "#c9ced4"
plt.rcParams.update({"font.size": 8.5, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": MUT,
                     "xtick.color": MUT, "ytick.color": MUT, "axes.grid": True, "grid.color": "#ececec", "grid.linewidth": .6})
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 3.35), gridspec_kw=dict(width_ratios=[1.1, 1]))
R = [r for r in json.loads((out / "fibres.json").read_text()) if not r["identified"]]
R.sort(key=lambda r: float(F(r["hi"]) - F(r["lo"])))
for k, r in enumerate(R):
    a1.plot([float(F(r["naturalLo"])), float(F(r["naturalHi"]))], [k, k], color=GR, lw=3, solid_capstyle="butt", zorder=1)
    tight = F(r["naturalLo"]) < F(r["lo"]) or F(r["hi"]) < F(r["naturalHi"])
    a1.plot([float(F(r["lo"])), float(F(r["hi"]))], [k, k], color=O if tight else B, lw=1.4, zorder=2)
    a1.plot(float(F(r["truth"])), k, "o", ms=2.2, color=INK, zorder=3)
a1.set_yticks([]); a1.set_xlim(0, 1); a1.set_xlabel("P(Y = 1 | do(X = x))")
a1.set_title(f"(a) sharp fibre bounds, {len(R)} non-identified queries", fontsize=8.5, color=INK)
a1.plot([], [], color=GR, lw=3, label="natural bounds"); a1.plot([], [], color=B, lw=1.4, label="LP bound = natural")
a1.plot([], [], color=O, lw=1.4, label="LP bound tighter"); a1.plot([], [], "o", ms=3, color=INK, label="generating model")
a1.legend(frameon=False, fontsize=6.8, loc="upper center", bbox_to_anchor=(0.5, -0.17), ncol=2); a1.grid(axis="y", visible=False)
rows = [l.split(",") for l in (out / "replacement_census.csv").read_text().splitlines()[1:]]
unc = [r for r in rows if r[3] == "0"]
gi = [float(F(r[5])) for r in unc if r[4] == "1"]; gn = [float(F(r[5])) for r in unc if r[4] == "0"]
bins = [i / 160 for i in range(0, 22)]
a2.hist([gi, gn], bins=bins, stacked=True, color=[A, O], label=[f"identified joint ({len(gi):,})", f"not identified ({len(gn):,})"], edgecolor="white", linewidth=.4)
a2.set_xlabel("total variation, replacement vs true intervention"); a2.set_ylabel("uncertified cases")
a2.set_title("(b) replacement gaps without the certificate", fontsize=8.5, color=INK)
cert = sum(1 for r in rows if r[3] == "1")
a2.text(0.98, 0.97, f"{cert:,} certified cases:\nevery gap exactly 0", transform=a2.transAxes, ha="right", va="top", fontsize=7, color=INK)
a2.legend(frameon=False, fontsize=6.8, loc="upper right", bbox_to_anchor=(1.0, 0.84))
fig.tight_layout(); fig.savefig(H / "figures" / "v2_fibres_replacement.png", dpi=220); plt.close(fig)
print("ok")
