# Autoregressive Sheaf Evolution, Part I: code and results

Companion files for the paper "Horizontally Topological, Vertically Algebraic" (18 October 2026).
Every number in the paper is read from the JSON files in this folder when the document is built.

| File | Purpose |
|------|---------|
| `p1_checks.py` | Fourteen numerical checks (seed 20261018); writes `p1_checks.json` |
| `p1_extras.py` | Six supplementary checks (seed 20261019); writes `p1_extras.json` |
| `tangent_mech.py` | Replays the main random stream to diagnose the numerically rank-deficient tangents; writes `tangent_mech.json` |
| `cs/` | .NET 8 reference kernel (`Topology.cs`) and validation program (`Program.cs`); `cs_out.txt` is its output |
| `cs_validate.py` | Recomputes every line of `cs/cs_out.txt` with NumPy; writes `cs_validate.json` |
| `fig_p1.py` | Draws Figures 1 to 6 into `fig/` |
| `src/*.md`, `render.py` | Paper source; `render.py` fills every number from the JSON files and writes `paper.md` |
| `make_ref.py`, `ref.docx`, `postprocess.py` | Word styles, and post-processing that centres numbered equations and puts XML elements in schema order |

Order of execution: `p1_checks.py`, `p1_extras.py`, `tangent_mech.py`; build and run the C# project and save its
output as `cs/cs_out.txt`; `cs_validate.py`; `fig_p1.py`; `render.py`; pandoc with `--reference-doc=ref.docx`;
`postprocess.py`.

Versions used: Python 3.13.16, NumPy 2.5.3, Matplotlib 3.11.2, .NET SDK 8.0.131, pandoc 3.1.3.
