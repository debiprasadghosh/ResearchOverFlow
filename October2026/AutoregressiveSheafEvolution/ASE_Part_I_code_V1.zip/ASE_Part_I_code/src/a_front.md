---
title: "Horizontally Topological, Vertically Algebraic"
subtitle: "The two axes of Autoregressive Sheaf Evolution. Part I: sheaves on covers and representations of the layer order"
author:
  - "Debi Prasad Ghosh"
  - "Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India"
date: "Defensible Intelligence series · Autoregressive Sheaf Evolution, Part I · 18 October 2026 · “Respect science. Import emotion.”"
abstract: |
  Autoregressive Sheaf Evolution (ASE) replaces the single Euclidean retrieval geometry of Autoregressive Diffusion Evolution (ADE) by local data spaces on every layer of a stack. Its organising principle is that each layer is horizontally topological and each token's journey is vertically algebraic. This paper, the first part of the ASE book, makes the principle precise, proves what it delivers and marks where it stops. The horizontal axis is a cellular data sheaf on the nerve of a layer cover. Its stalks are data spaces, not charts; its sections are compatible assignments; residuals are coboundaries; cohomology measures the edge data that no assignment explains. We prove residual bounds with declared units, a holonomy theorem for orthogonal sheaves that contains Harary's balance theorem, and a cohomology formula for coordinate sheaves on variable contexts. We also separate three obstructions that are easily conflated: linear H¹ classes, additive angle torsors and multiplicative sign holonomy. The vertical axis is a representation of the layer order. Every specified transport, tangent or homogenised affine diagram decomposes into interval modules. We show that a clean top produces births at the top, that homogenisation adds exactly one full bar, that exact bars usually survive while sensitivity contracts, and that layer cohomology has only full bars when the layers use nested Leray covers of one space. The central new result is vertical acyclicity: for every sheaf on the product of a base with the layer order, cohomology equals that of the bottom layer. The vertical axis therefore carries no cohomology, and its information lives in barcodes; the slogan becomes a theorem. A zigzag of layers is not acyclic. ADE is the trivial product with a separate observation star. Twenty numerical checks, and an immutable C# kernel that matches an independent NumPy implementation line for line, support every quantitative statement.
---

# 1 Introduction

Autoregressive Diffusion Evolution (ADE) treats an archive of evaluated designs as the memory of a denoising stack [16, 17]. A token starts at the bottom of a stack of layers $t=T,\ldots,1,0$. At each layer it reads the archive through a Gaussian kernel at scale $s_t$ and moves towards the read. In the scaled coordinate used by the conversion proposal [19, Proposition 6.2], with records $y_i$, prior weights $w_i$ and $s_t^2=(1-a_t)/a_t$,

::: {custom-style="Equation"}
$m_t(z)=\sum_i \alpha_i(z)\,y_i,\quad \alpha_i(z)\propto w_i\exp\left(-\frac{\|z-y_i\|^2}{2s_t^2}\right),\quad z_{t-1}=(1-\lambda_t)\,z_t+\lambda_t\,m_t(z_t)+\nu_t$ (1.1)
:::

where $\nu_t$ is the scaled noise increment. Every layer uses the same retrieval geometry: one Euclidean space, one distance and one global read.

The revised conversion proposal [19], cited below as V2, replaces that single geometry by local data spaces, compatibility maps and scale-dependent covers. It states the organising principle in one line: horizontal topology within each layer and vertical algebra across layers (Figure 1). This paper is Part I of the resulting six-part book, covering its first two chapters: sheaves on covers, and representations of the layer order. Its task is to make the principle mathematically precise, to prove what it delivers and to mark where it stops.

![**Figure 1.** The two axes. Each layer carries a cover at its scale, the nerve of the cover and a data sheaf on the nerve (left). A token visits one cell per layer; the data spaces of the visited cells and the maps between them form the token's vertical fibre diagram, a representation of the layer order (right). The small squares mark the stalk at the visited cell.](fig/stack.png){width=96%}

## 1.1 The principle as mathematics

*Horizontal.* A layer is a base with a finite cover. The nerve of the cover carries a cellular data sheaf. Stalks are data spaces attached to cells, and restriction maps say how the data on a cell are observed on an overlap. A section is a compatible assignment, a residual is a coboundary, and cohomology measures what cannot be made compatible.

*Vertical.* A token's journey produces a diagram of linear maps indexed by the layer order. Such a diagram is a representation of a finite linear order and decomposes into interval modules; its barcode is a complete invariant. The cohomology of the layers, compared across layers, forms another such representation.

*Product.* The two axes combine into one sheaf on the product of a base with the layer order. The main new theorem of this paper, Theorem 5.3, says that the cohomology of every such sheaf equals the cohomology of its bottom layer. Whatever the stack does above the bottom is invisible to the cohomology of the product and visible only to the representation theory of the layer order. Vertical algebra is therefore not a modelling preference: it is the only place where vertical information can be read.

## 1.2 Contributions

- **A typed vocabulary.** Four bases are kept distinct: the cover nerve, the context nerve, the layer order and the observation star (Definition 2.4). Stalks are data spaces, restrictions run from vertices to overlaps, and residuals carry declared units.
- **Horizontal results.** We show that the coboundary squares to zero exactly when every diamond of restriction maps commutes, which in degree one are the triangle compatibility identities (Proposition 3.5), and prove a residual sandwich with its Hodge split (Proposition 3.7). We also give nerves with coefficients, including a two-arc example in which the coefficients rather than the nerve carry the loop (Theorem 3.9, Example 3.10). For orthogonal sheaves we prove a holonomy theorem with a dimension formula and Harary's theorem as a corollary (Theorem 3.12, Corollary 3.13), and show that filled triangles are flat (Proposition 3.14). Three obstructions are separated (Proposition 3.16), and coordinate sheaves on contexts receive a cohomology formula (Proposition 3.19).
- **Vertical results.** Homogenisation adds exactly one full bar (Proposition 4.4), and a clean top produces births at the top (Proposition 4.5). The tangent rank equals the affine dimension of the records, so exact bars survive while effective rank contracts (Proposition 4.6). Leray covers give full bars in layer cohomology (Proposition 4.8). Component counts are stable under perturbation (Proposition 4.11).
- **The product.** We give a slice description of the fixed-base product (Proposition 5.1) and prove vertical acyclicity (Theorem 5.3). A zigzag counterexample shows that the theorem needs a least element (Remark 5.5). Moving tokens become fixed-base diagrams in Lagrangian coordinates (Proposition 5.7), and ADE is the trivial product (Proposition 5.9).
- **Evidence.** Twenty numerical checks reproduce every quantitative statement (Table 3), and an immutable C# kernel agrees line for line with an independent NumPy implementation (Appendix A).

## 1.3 Scope and status of statements

Part I is foundational. It makes no claim about search performance, sampling validity or engineering feasibility; those belong to Parts II to VI, and V2 lists the falsifiable hypotheses C1 to C5 that will test them. Every statement in a shaded box ends with a provenance tag. *Classical* means a known result restated in ASE notation. *V2* means a statement of the conversion proposal, sometimes with a new proof. *New in Part I* means a statement proved here for the first time in this programme. New statements carry proofs and numerical checks. All vector spaces are finite dimensional and real. The algebraic statements hold over any field; orthogonality, norms and eigenvalues use the real inner product.

## 1.4 Conventions and notation

Table: **Table 1.** Notation used throughout Part I.

| Symbol | Meaning |
|:--------------|:--------------------------------------------------------------|
| $t=T,\ldots,0$ | layers, traversed from the bottom ($T$) to the top ($0$) |
| $P$ | the layer order $T<T-1<\cdots<0$ with the Alexandrov topology of up-sets |
| $\uparrow t$ | the up-set $\{t,t-1,\ldots,0\}$, the smallest open set containing $t$ |
| $X_t,\ 𝒰_t,\ N_t$ | base, finite open cover and nerve at layer $t$ |
| $F(\sigma),\ r_{\sigma\tau}$ | stalk on the cell $\sigma$ and restriction for $\sigma\le\tau$ |
| $C^k,\ \delta,\ H^k$ | cochains, coboundary and cohomology |
| $W,\ L=\delta^{\top}W\delta$ | positive definite edge weights in declared units, sheaf Laplacian |
| $V_t,\ \rho_t$ | data space of the visited cell, vertical map $V_t\to V_{t-1}$ |
| $𝕀[b,d]$ | interval module born at layer $b$ and alive up to layer $d$, with $b\ge d$ |
| $\Phi_t,\ \Phi_t^{-1}$ | deterministic step $X\to X$ and inverse image of sheaves |
| $Q$ | a finite poset, usually the face poset of a nerve |

# 2 Finite posets and the bases of ASE

Every base in ASE is either a finite poset or is replaced by one for computation, usually the face poset of a nerve. Finite posets carry a topology in which sheaves become diagrams of vector spaces, so that all sheaf theory used in Part I reduces to linear algebra.

::: {custom-style="Statement"}
**Definition 2.1** (Alexandrov topology [2]). Let $(Q,\le)$ be a finite poset. A subset $U\subseteq Q$ is open when it is an up-set: $p\in U$ and $p\le q$ imply $q\in U$. The set $\uparrow p=\{q: q\ge p\}$ is the smallest open set containing $p$, and these sets form a basis.
:::

::: {custom-style="Statement Tag"}
Classical.
:::

::: {custom-style="Statement"}
**Proposition 2.2** (sheaves on a finite poset). Let $Q$ be a finite poset with its Alexandrov topology.
:::

::: {custom-style="Statement"}
\(i) The assignment $ℱ\mapsto F$, $F(p)=ℱ(\uparrow p)$, is an equivalence between sheaves of real vector spaces on $Q$ and functors $F:Q\to\text{Vect}$, where $Q$ has one arrow $p\to q$ whenever $p\le q$. The stalk at $p$ is $F(p)$, and the restriction for $p\le q$ is the map $F(p\le q):F(p)\to F(q)$.
:::

::: {custom-style="Statement"}
\(ii) Global sections are the limit: $\Gamma(Q;F)=\text{lim}_Q F=\{(x_p)\in\prod_p F(p): F(p\le q)\,x_p=x_q\}$.
:::

::: {custom-style="Statement"}
\(iii) Sheaf cohomology is the derived limit, $H^k(Q;F)\cong R^k\text{lim}_Q F$. It is computed by the cochain complex whose degree-$n$ term is the product of the spaces $F(p_n)$ over the strictly increasing chains $p_0<\cdots<p_n$, with differential
:::

::: {custom-style="Statement Equation"}
$(dx)(c)=\sum_{k=0}^{n}(-1)^k\,x(\partial_kc)+(-1)^{n+1}F(p_n\le p_{n+1})\,x(\partial_{n+1}c)$ (2.1)
:::

::: {custom-style="Statement"}
Here $c=(p_0<\cdots<p_{n+1})$ and $\partial_kc$ deletes $p_k$ from the chain.
:::

::: {custom-style="Statement Tag"}
Classical [8, 14, 25].
:::

*Proof.* Every open cover of $\uparrow p$ contains $\uparrow p$ itself, because some member contains $p$ and is an up-set. The sheaf condition on basic open sets is therefore empty, and a sheaf is the same as a presheaf on the basis. Since $\uparrow q\subseteq\uparrow p$ exactly when $p\le q$, that basis category is $Q$. Gluing over the cover $\{\uparrow p\}_{p\in U}$ gives $ℱ(U)=\text{lim}_{p\in U}F(p)$, which proves (i) and, for $U=Q$, (ii). Sheaf cohomology is the right derived functor of global sections, here the derived limit. The Bousfield–Kan cosimplicial replacement computes derived limits [8], and normalisation keeps only strictly increasing chains, which gives (2.1). $\blacksquare$

::: {custom-style="Statement"}
**Proposition 2.3** (cellular cohomology is sheaf cohomology). Let $K$ be a finite simplicial complex with face poset $𝒫(K)$ and let $F$ be a cellular sheaf on $K$ (Definition 3.2). The cohomology of the cellular cochain complex of Definition 3.4 is isomorphic to $R^k\text{lim}_{𝒫(K)}F$.
:::

::: {custom-style="Statement Tag"}
Classical [14, 29].
:::

::: {custom-style="Check"}
*Numerical check.* The complex (2.1) and the cellular complex were computed independently on three sheaves on a triangle. The constant sheaf on the hollow triangle gives $(1,1,0)$ against cellular $(1,1)$; a sign-twisted sheaf gives $(0,0,0)$ against $(0,0)$; the constant sheaf on the filled triangle gives $(1,0,0)$ against $(1,0,0)$.
:::

ASE uses four different bases. They are all finite posets, and they answer different questions. Confusing them is the most common source of wrong statements in the earlier drafts, so we fix them now.

::: {custom-style="Statement"}
**Definition 2.4** (the four bases of ASE). Each sheaf in an ASE implementation records which of the following bases it lives on.
:::

::: {custom-style="Statement"}
\(a) *Cover base.* At layer $t$, a finite open cover $𝒰_t$ of the region of $X_t$ visited by tokens, its nerve $N_t$ and the face poset of $N_t$. It describes spatial locality, and the horizontal data sheaves live on it.
:::

::: {custom-style="Statement"}
\(b) *Context base.* A family of variable subsets $S_1,\ldots,S_k\subseteq\{1,\ldots,D\}$, with its nerve (a simplex whenever the contexts share a variable) or its pairwise graph. It describes partial information and objective incidence. An incidence hypergraph is not automatically the nerve of an open cover of design space.
:::

::: {custom-style="Statement"}
\(c) *Layer order.* The chain $P$ of Table 1. It describes computation depth, and the vertical diagrams live on it.
:::

::: {custom-style="Statement"}
\(d) *Observation star.* At one layer, a token vertex joined to one leaf per retrieved record. The token stalk is the token frame, a leaf stalk is the record space and an edge stalk is a common observation space, reached from the token by $Q_i$ and from the record by $R_i$. The harmonic read of Part II is the harmonic extension of the record values over this star [19, Proposition 5.1]. The star is auxiliary and is never the cover nerve.
:::

::: {custom-style="Statement Tag"}
V2 Section 1, made a definition.
:::

![**Figure 2.** The four bases. (a) A cover by four disks and its nerve, with both triangles filled because their triple intersections are nonempty. (b) Three contexts that share the variable 1. (c) The layer order from the bottom $T$ to the top $0$. (d) The observation star of one token and seven retrieved records.](fig/bases.png){width=100%}

The distinction between (a) and (d) resolves an apparent paradox noted in V2. ADE has a one-vertex cover nerve at every layer, yet it reads a nontrivial archive. The nerve describes the base geometry; the star describes the observations attached to it (Proposition 5.9).
