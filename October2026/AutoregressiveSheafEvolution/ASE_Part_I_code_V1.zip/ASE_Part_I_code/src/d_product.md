
# 5 The product: one sheaf for the whole stack

The two axes combine into one object: a sheaf on the product of a base with the layer order. This section describes such sheaves, computes their cohomology and draws the consequence for the principle.

::: {custom-style="Statement"}
**Proposition 5.1** (fixed-base product). Let $X$ be a topological space and give $P$ its Alexandrov topology.
:::

::: {custom-style="Statement"}
\(i) A set $W\subseteq X\times P$ is open exactly when every slice $W_t=\{x:(x,t)\in W\}$ is open and $W_t\subseteq W_{t'}$ whenever $t\le t'$ in $P$, that is, whenever $t'$ lies above $t$.
:::

::: {custom-style="Statement"}
\(ii) Sheaves $G$ on $X\times P$ correspond to diagrams $G_T\to G_{T-1}\to\cdots\to G_0$ of sheaves on $X$, through $G_t(U)=G(U\times\uparrow t)$; the vertical arrow is restriction along $U\times\uparrow(t-1)\subseteq U\times\uparrow t$. Conversely,
:::

::: {custom-style="Statement Equation"}
$G(W)=\{(s_t)_t\in\prod_tG_t(W_t):\ \rho_{t\to t'}(s_t)=\text{res}_{W_t}(s_{t'})\ \text{whenever}\ t\le t'\ \text{in}\ P\}$ (5.1)
:::

::: {custom-style="Statement Tag"}
V2 Proposition 3.2, with a new proof through slices; compare Russold's correspondence between linear diagrams of sheaves and sheaves of graded modules [28].
:::

*Proof.* (i) Basic open sets $U\times V$, with $V$ an up-set, have open and monotone slices, and unions preserve both properties. Conversely, a set with open monotone slices equals $\bigcup_t W_t\times\uparrow t$. (ii) A cover of $U$ gives a cover of $U\times\uparrow t$, so each $G_t$ is a sheaf, and the inclusions give the vertical maps. Given a diagram, cover $W$ by the sets $W_t\times\uparrow t$. Two of them, with $t\le t'$, intersect in $W_t\times\uparrow t'$, and the gluing condition there is exactly the condition in (5.1). On $W=U\times\uparrow t_0$, (5.1) returns $G_{t_0}(U)$, because the sections above $t_0$ are determined by $s_{t_0}$. The two constructions are inverse up to natural isomorphism. $\blacksquare$

::: {custom-style="Statement"}
**Proposition 5.2** (the finite case). For a finite poset $Q$, the product topology on $Q\times P$ is the Alexandrov topology of the product order. Sheaves on $Q\times P$ are functors $Q\times P\to\text{Vect}$, that is, layer sheaves $G_t:Q\to\text{Vect}$ with natural maps $G_t\Rightarrow G_{t-1}$. Naturality says that horizontal restrictions and vertical maps commute on every square (Figure 6b). A family of unrelated layer sheaves is not a sheaf on the product.
:::

::: {custom-style="Statement Tag"}
V2 Section 3, made precise.
:::

*Proof.* Products of up-sets are up-sets of the product order, and every up-set is the union of the products $\uparrow q\times\uparrow t$ over its elements. Proposition 2.2 then identifies sheaves with functors, and a functor on a product of posets is a commuting diagram. $\blacksquare$

::: {custom-style="Statement"}
**Theorem 5.3** (vertical acyclicity). Let $X$ be a topological space and $G$ a sheaf of real vector spaces on $X\times P$, with bottom layer $G_T$. For every $k\ge 0$, naturally in $G$,
:::

::: {custom-style="Statement Equation"}
$H^k(X\times P;\,G)\cong H^k(X;\,G_T)$ (5.2)
:::

::: {custom-style="Statement"}
In particular $\Gamma(X\times P;G)=\Gamma(X;G_T)$, and for a finite poset $Q$, $H^k(Q\times P;G)\cong H^k(Q;G_T)$.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

*Proof.* Let $e$ send a sheaf $G$ on $X\times P$ to its bottom layer $G_T$, and let $\pi:X\times P\to X$ be the projection.

*Step 1: $e$ is exact.* The smallest open subset of $P$ containing $T$ is $\uparrow T=P$, so the sets $U\times P$ form a neighbourhood basis of $(x,T)$. Hence the stalk of $G_T$ at $x$ equals the stalk of $G$ at $(x,T)$, and exactness is tested on stalks.

*Step 2: $\pi^{-1}$ is an exact left adjoint of $e$.* Under Proposition 5.1, $\pi^{-1}F$ is the constant diagram $F\to F\to\cdots\to F$ with identity maps. A morphism from it to $(G_t)$ is a family $\varphi_t:F\to G_t$ with $\rho_t\varphi_t=\varphi_{t-1}$, which is determined by $\varphi_T$. Inverse images are exact.

*Step 3: $e$ preserves injectives,* because it has an exact left adjoint [33].

*Step 4: global sections factor through $e$.* $\Gamma(X\times P;G)=G(X\times\uparrow T)=G_T(X)$.

For an injective resolution $G\to I^{\bullet}$, Steps 1 and 3 make $e\,I^{\bullet}$ an injective resolution of $G_T$. Step 4 then gives $H^k(X\times P;G)=H^k\,\Gamma(X;e\,I^{\bullet})=H^k(X;G_T)$. $\blacksquare$

For finite bases, the same result is a collapse of the Grothendieck spectral sequence [33] for $\text{lim}_{Q\times P}=\text{lim}_Q\circ\text{lim}_P$. The functor $\text{lim}_P$ is evaluation at the least element $T$, which is exact.

::: {custom-style="Check"}
*Numerical check.* Derived limits over $Q\times P$ were computed from (2.1) and compared with the cellular cohomology of the bottom layer. The base was a hollow triangle with three layers, in four hand-built stacks. With constant $ℝ^2$ and common random vertical maps the result was $({{c.vertical_acyclicity.3.derived.0}},{{c.vertical_acyclicity.3.derived.1}},{{c.vertical_acyclicity.3.derived.2}},{{c.vertical_acyclicity.3.derived.3}})$. A twisted bottom under constant layers gave $({{c.vertical_acyclicity.4.derived.0}},{{c.vertical_acyclicity.4.derived.1}},{{c.vertical_acyclicity.4.derived.2}},{{c.vertical_acyclicity.4.derived.3}})$, and a constant bottom under twisted layers gave $({{c.vertical_acyclicity.5.derived.0}},{{c.vertical_acyclicity.5.derived.1}},{{c.vertical_acyclicity.5.derived.2}},{{c.vertical_acyclicity.5.derived.3}})$. A stack twisted at every layer, with scalar vertical maps, gave $({{c.vertical_acyclicity.6.derived.0}},{{c.vertical_acyclicity.6.derived.1}},{{c.vertical_acyclicity.6.derived.2}},{{c.vertical_acyclicity.6.derived.3}})$. Each equals the bottom layer's cohomology. We also built {{x.product_random.trials}} random stacks of subquotient sheaves on four complexes (hollow triangle; filled triangle with a pendant edge; a filled and a hollow triangle sharing an edge; four-cycle), with three layers and random twists. In {{x.product_random.upper_layers_differ}} of them some upper layer had cohomology different from the bottom. The derived limits equalled the bottom cohomology in {{x.product_random.agree}} of {{x.product_random.trials}} stacks.
:::

![**Figure 6.** The product and what each invariant sees. (a) A sheaf on $Q\times P$ is a stack of layer sheaves joined by vertical maps. (b) Every square formed by a restriction and two vertical maps commutes. (c) The cohomology of the product is the bottom term of the persistence module $t\mapsto H^k(Q;G_t)$; the barcode of that module is the vertical invariant.](fig/product.png){width=100%}

::: {custom-style="Statement"}
**Corollary 5.4** (what the cohomology of a stack sees). Every global section of a stack is a bottom-layer section propagated upward, and every class in $H^k(X\times P;G)$ is determined at the bottom. Two stacks with the same bottom layer have isomorphic product cohomology, whatever happens above. The persistence module $t\mapsto H^k(X;G_t)$ of Proposition 4.7 has $H^k(X;G_T)$ as its bottom term, so its barcode carries strictly more information than the cohomology of the product.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

For instance, the stack with a constant bottom and twisted layers above has product cohomology $(1,1)$, the same as a stack that is constant throughout. In its persistence module, however, both classes die after the bottom layer, while in the constant stack they persist to the top. Vertical information is invisible to the cohomology of the product and visible to barcodes. This is the precise sense in which ASE is vertically algebraic.

::: {custom-style="Statement"}
**Remark 5.5** (orientation, cosheaves and zigzags). \(i) The theorem depends on the direction of the layer order. With the opposite orientation, where information flows from the top down, evaluation happens at the top. For cosheaves, which use colimits, the dual statement evaluates at the terminal layer. \(ii) Acyclicity is a property of a least element, not of layering as such. On the zigzag $a\le c\ge b$, put $G(a)=G(b)=ℝ$ and $G(c)=ℝ^2$, with both maps onto the same line. Then $R^0\text{lim}=ℝ$ and $R^1\text{lim}=ℝ$: the vertical axis carries a class, the direction of $G(c)$ that neither side reaches. Zigzag stacks (Remark 4.12) must therefore be analysed with zigzag barcodes rather than product cohomology.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

::: {custom-style="Check"}
*Numerical check.* The derived limits of the zigzag are $({{x.product_random.zigzag.0}},{{x.product_random.zigzag.1}},{{x.product_random.zigzag.2}})$.
:::

Moving tokens fit the same framework once the inverse image is typed correctly.

::: {custom-style="Statement"}
**Definition 5.6** (tower). A tower on $X$ consists of sheaves $F_t$ on $X$, deterministic steps $\Phi_t:X\to X$ and morphisms $\varphi_t:F_t\to\Phi_t^{-1}F_{t-1}$. Since $(\Phi_t^{-1}F_{t-1})_x=(F_{t-1})_{\Phi_t(x)}$, the morphism maps the stalk at $x$ into the stalk at $\Phi_t(x)$. Under a fixed noise realisation, the same description applies pathwise.
:::

::: {custom-style="Statement Tag"}
V2 Section 3.
:::

::: {custom-style="Statement"}
**Proposition 5.7** (Lagrangian coordinates). Let $\Psi_T=\text{id}$ and $\Psi_{t-1}=\Phi_t\circ\Psi_t$ be the flow from the bottom. The sheaves $G_t=\Psi_t^{-1}F_t$, with the maps $\Psi_t^{-1}\varphi_t:G_t\to\Psi_t^{-1}\Phi_t^{-1}F_{t-1}\cong G_{t-1}$, form a fixed-base diagram, hence a sheaf on $X\times P$. Its stalk diagram at $x$ is the vertical fibre diagram of the token that starts at $x$:
:::

::: {custom-style="Statement Equation"}
$(F_T)_{x}\to(F_{T-1})_{\Psi_{T-1}(x)}\to\cdots\to(F_0)_{\Psi_0(x)}$ (5.3)
:::

::: {custom-style="Statement"}
Consequently every tower satisfies $H^k(X\times P;G)\cong H^k(X;F_T)$.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

*Proof.* Inverse images compose, $(g\circ f)^{-1}\cong f^{-1}g^{-1}$, and have stalks $(f^{-1}F)_x=F_{f(x)}$ [24]. Since $\Psi_T=\text{id}$, $G_T=F_T$, and Theorem 5.3 applies. $\blacksquare$

A moving token is therefore one stalk diagram of a fixed-base product, written in the coordinates of the bottom layer and labelled by where the token started. The typing matters: the morphism goes into $\Phi_t^{-1}F_{t-1}$, so the stalk at $x$ maps into the stalk at $\Phi_t(x)$. Different bases at different layers first require pullbacks to a common base, a specified correspondence or another explicit comparison.

::: {custom-style="Statement"}
**Remark 5.8** (two parameters are wild). Pairing the layer order with a second filtration, such as a scale within each layer, gives a representation of a product of two chains. Such multiparameter persistence modules admit no complete discrete invariant in general [11]. ASE therefore reads barcodes one parameter at a time and reports rank invariants otherwise.
:::

::: {custom-style="Statement Tag"}
Classical.
:::

::: {custom-style="Statement"}
**Proposition 5.9** (ADE is the trivial product). Take $X_t=ℝ^D$ and the one-element cover $𝒰_t=\{ℝ^D\}$ at every layer, so that every nerve is a single vertex, with constant stalk $ℝ^D$. Take as vertical maps the realised tangent or homogenised affine maps of the ADE update. Add, separately, an observation star at each layer with one leaf per record and identity restrictions. Then:
:::

::: {custom-style="Statement"}
\(i) every layer has $H^0=ℝ^D$ and $H^k=0$ for $k\ge 1$;
:::

::: {custom-style="Statement"}
\(ii) the product has $H^0=ℝ^D$ and no higher cohomology;
:::

::: {custom-style="Statement"}
\(iii) the harmonic read on the star equals the ADE Gaussian read at $q_t=\sqrt{a_t}\,z_t$ [19, Proposition 6.2];
:::

::: {custom-style="Statement"}
\(iv) all vertical structure lies in the fibre diagrams, whose barcodes obey Propositions 4.4 to 4.6.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 6.2, specialised.
:::

*Proof.* A one-vertex nerve has a cochain complex concentrated in degree zero, which gives (i); Theorem 5.3 gives (ii); (iii) is V2 Proposition 6.2; (iv) is Section 4. $\blacksquare$

ADE is horizontally trivial and vertically algebraic. ASE adds horizontal topology without changing the vertical algebra. Every horizontal construction of Section 3 reduces to ADE when the cover has one element and the restrictions are identities, and every vertical statement of Section 4 applies to ADE unchanged.

# 6 Register of numerical checks

Table 3 lists every numerical check in Part I. Fourteen checks come from one script and six from a supplementary script. Both scripts write machine-readable results, and every number in this paper is read from those files when the document is built. The checks support the implementations and illustrate the statements; the proofs establish them.

Table: **Table 3.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 2.3 | derived limits against cellular cohomology | equal in 3 of 3 sheaves |
| 2 | Proposition 3.5 | $\delta^1\delta^0$ with compatible and incompatible maps | {{c.delta_squared.compatible_max\|g3}} and {{c.delta_squared.incompatible_max\|f2}}; Euler sums equal |
| 3 | Proposition 3.7 | residual sandwich, 2 sheaves, 500 assignments each | no violation; harmonic dimension equals $H^1$ |
| 4 | Example 3.10 | two arcs | data sheaf (1, 1); plain nerve (1, 0) |
| 5 | Theorem 3.12 | holonomy, 6 orthogonal sheaves | fixed dimension equals $H^0$; (3.8) in 6 of 6 |
| 6 | Corollary 3.13 | Harary balance, {{c.harary.graphs}} signed graphs | {{c.harary.agree}} of {{c.harary.graphs}} |
| 7 | Proposition 3.14 | flat triangles, 200 cases | largest defect {{c.triangle_flat_max_err\|e1}} |
| 8 | Proposition 3.16 | three obstructions | residual {{c.obstructions.angle_residual\|f4}}; (1, 1) and (0, 0); holonomy $-1$ |
| 9 | Example 3.18 | binary three-cycle | {{x.feasible_cycle.global_sections}} global sections of 8 |
| 10 | Proposition 3.19 | context sheaves, {{c.contexts.trials}} families | formula exact in every family |
| 11 | Proposition 3.20 | inverse-image cochain map | commutation defects 0 and 0 |
| 12 | Theorem 4.2 | {{c.barcodes.random_chains}} random chains | multiplicities nonnegative; ranks reconstructed |
| 13 | Proposition 4.4 | affine composites; homogenised barcodes | {{c.affine_max_err\|e1}}; {{x.affine_bars.agree}} of {{x.affine_bars.trials}} |
| 14 | Proposition 4.5 | births at the top | bars as predicted |
| 15 | Proposition 4.6 | covariance rank and bound (4.4) | {{x.covariance.rank_equals_affine_dim}} and {{x.covariance.eps_bound_holds}} of {{x.covariance.trials}} |
| 16 | Proposition 4.6 | {{c.tangent.tokens}} tokens on a cosine stack | numerically full rank {{c.tangent.exact_full_rank\|pct1}}; effective rank depends on $\tau$ |
| 17 | Example 4.9 | circle covers | plain nerve $H^1$ born mid-stack; data sheaf full |
| 18 | Proposition 4.10 | archive filtration | births at 15, 11, 8, 7; all reach the top |
| 19 | Proposition 4.11 | {{c.stability.cases}} perturbation cases | {{c.stability.violations}} violations |
| 20 | Theorem 5.3, Remark 5.5 | 4 hand-built and {{x.product_random.trials}} random stacks; zigzag | all equal the bottom; zigzag (1, 1, 0) |
| 21 | Appendix A | C# kernel against NumPy | {{v.agree}} of {{v.lines}} output lines identical |

# 7 Discussion

## 7.1 What Part I supplies to the rest of the book

Part II, the horizontal layer, builds the harmonic read on the observation star of Definition 2.4(d). Its normal equations are a harmonic extension problem with fixed boundary values, so Propositions 3.6 to 3.8 supply its residual, conditioning and consensus language. Section 3.5 organises the chapter on design-space topology: branches, angles, signs and subspaces are different coefficient systems. Proposition 3.19 explains why a pairwise context graph over-counts cycles, a point that matters when recombination is read from context overlaps.

Part III, the vertical stack, studies the token recurrence. The separation identity of V2 is the affine composite (4.2) for scalar coefficients, and Proposition 4.4 says that its barcode is the barcode of the linear part. The tangent chapter inherits the distinction between exact and effective rank (Propositions 4.5 and 4.6). The persistence chapter inherits Propositions 4.7 to 4.11 and the zigzag caveat.

Parts IV to VI concern targets, fusion and evidence. Theorem 5.3 has a negative consequence there: no statement about targets, laws or feasibility can be read from the cohomology of the product, because that cohomology sees only the bottom layer. Example 3.18 previews the marginal extension problem. The dependency order of V2 Section 16 is another finite Alexandrov space, to which Proposition 2.2 applies unchanged.

## 7.2 Diagnostics an implementation should report

Defensibility requires that every ASE run report the objects these results depend on:

- the base on which each sheaf lives (Definition 2.4);
- units and edge weights $W$ (Remark 3.3);
- per layer, $\text{dim}\,H^0$ together with the holonomy or $ℤ_2$ class where it applies (Theorem 3.12, Proposition 3.16);
- the residual bounds $\lambda_2$ and $\lambda_{\text{max}}$ (Proposition 3.7);
- the Leray status of every cover, at least whether intersections are connected (Theorem 3.9);
- barcodes together with their conventions: open or closed thresholds, and the tolerance $\tau$ of every effective rank (Propositions 4.6 and 4.10);
- which vertical maps were used: transport, tangent or affine (Definition 4.3).

## 7.3 Open problems

1. **Nonlinear stalks.** Modal subspaces live on Grassmannians and angles on circles. Linear cohomology must be replaced by nonabelian first cohomology, that is, by torsors and their classes. Which parts of Section 3 survive, with which bounds?
2. **Learned covers.** When covers are fitted to data, consecutive layers form a zigzag. Stability of zigzag barcodes under perturbation of the fitted covers is needed before births can guide schedules (hypothesis C3 of V2).
3. **Symmetry.** Mirror-symmetric designs (hypothesis C4) call for equivariant sheaves or sheaves on quotient stacks $[X/G]$. Novelty modulo symmetry should be measured on the quotient, and its relation to sections on $X$ needs a theorem.
4. **Two-parameter summaries.** Remark 5.8 rules out complete invariants for layer and scale together. Which rank-invariant summaries are stable and informative for schedules?
5. **Frustration bounds.** For an orthogonal sheaf with $H^0=0$, the smallest eigenvalue of $L$ measures how far the best assignment is from consistent. The Cheeger inequality for the connection Laplacian [4] relates it to a combinatorial frustration constant. An extension to weighted, rectangular and unit-scaled sheaves would give ASE a certified horizontal diagnostic.
6. **Stability of effective bars.** Proposition 4.6(iv) is pointwise. A perturbation theory for tangent barcodes under changes of the archive, in the language of interleavings [12], would turn effective rank into a stable statistic.

## 7.4 Conclusion

The principle *horizontally topological, vertically algebraic* now has a precise form in three parts. Horizontally, each layer carries a typed data sheaf whose sections, residuals, holonomy and cohomology are computable, with declared units and distinct bases. Vertically, every specified linear diagram along a token's path, and the cohomology of the layers themselves, decomposes into intervals whose births and deaths have exact meanings and effective counterparts. Joined, the two axes form a product whose cohomology is that of its bottom layer, so vertical information is necessarily algebraic. ADE is the special case in which the horizontal axis is trivial. Part II begins from the observation star and the harmonic read.

# References

::: {custom-style="Bibliography"}
[1] Abramsky, S. and Brandenburger, A. (2011). The sheaf-theoretic structure of non-locality and contextuality. *New Journal of Physics* 13, 113036.

[2] Alexandroff, P. (1937). Diskrete Räume. *Matematicheskii Sbornik (N.S.)* 2(44), 501–519.

[3] Ayzenberg, A., Gebhart, T., Magai, G. and Solomadin, G. (2025). Sheaf theory: from deep geometry to deep learning. arXiv:2502.15476.

[4] Bandeira, A. S., Singer, A. and Spielman, D. A. (2013). A Cheeger inequality for the graph connection Laplacian. *SIAM Journal on Matrix Analysis and Applications* 34(4), 1611–1630.

[5] Bodnar, C., Di Giovanni, F., Chamberlain, B. P., Liò, P. and Bronstein, M. M. (2022). Neural sheaf diffusion: a topological perspective on heterophily and oversmoothing in GNNs. *Advances in Neural Information Processing Systems* 35. arXiv:2202.04579.

[6] Bott, R. and Tu, L. W. (1982). *Differential Forms in Algebraic Topology*. Graduate Texts in Mathematics 82. Springer.

[7] Bourgerie, R., Girdzijauskas, Š. and Fodor, V. (2026). Deep neural sheaf diffusion. arXiv:2605.19021.

[8] Bousfield, A. K. and Kan, D. M. (1972). *Homotopy Limits, Completions and Localizations*. Lecture Notes in Mathematics 304. Springer.

[9] Bredon, G. E. (1997). *Sheaf Theory*, 2nd edn. Graduate Texts in Mathematics 170. Springer.

[10] Carlsson, G. and de Silva, V. (2010). Zigzag persistence. *Foundations of Computational Mathematics* 10(4), 367–405.

[11] Carlsson, G. and Zomorodian, A. (2009). The theory of multidimensional persistence. *Discrete & Computational Geometry* 42(1), 71–93.

[12] Cohen-Steiner, D., Edelsbrunner, H. and Harer, J. (2007). Stability of persistence diagrams. *Discrete & Computational Geometry* 37(1), 103–120.

[13] Crawley-Boevey, W. (2015). Decomposition of pointwise finite-dimensional persistence modules. *Journal of Algebra and Its Applications* 14(5), 1550066.

[14] Curry, J. (2014). *Sheaves, Cosheaves and Applications*. PhD thesis, University of Pennsylvania. arXiv:1303.3255.

[15] Gabriel, P. (1972). Unzerlegbare Darstellungen I. *Manuscripta Mathematica* 6, 71–103.

[16] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[17] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[18] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 1, 17 October 2026.

[19] Ghosh, D. P. (2026d). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[20] Hansen, J. and Ghrist, R. (2019). Toward a spectral theory of cellular sheaves. *Journal of Applied and Computational Topology* 3(4), 315–358.

[21] Harary, F. (1953). On the notion of balance of a signed graph. *Michigan Mathematical Journal* 2(2), 143–146.

[22] Hatcher, A. (2002). *Algebraic Topology*. Cambridge University Press.

[23] Horn, R. A. and Johnson, C. R. (2013). *Matrix Analysis*, 2nd edn. Cambridge University Press.

[24] Kashiwara, M. and Schapira, P. (1990). *Sheaves on Manifolds*. Grundlehren der mathematischen Wissenschaften 292. Springer.

[25] Mac Lane, S. and Moerdijk, I. (1992). *Sheaves in Geometry and Logic: A First Introduction to Topos Theory*. Universitext. Springer.

[26] Oudot, S. Y. (2015). *Persistence Theory: From Quiver Representations to Data Analysis*. Mathematical Surveys and Monographs 209. American Mathematical Society.

[27] Robinson, M. (2017). Sheaves are the canonical data structure for sensor integration. *Information Fusion* 36, 208–224.

[28] Russold, F. (2022). Persistent sheaf cohomology. arXiv:2204.13446.

[29] Shepard, A. D. (1985). *A Cellular Description of the Derived Category of a Stratified Space*. PhD thesis, Brown University.

[30] Singer, A. and Wu, H.-T. (2012). Vector diffusion maps and the connection Laplacian. *Communications on Pure and Applied Mathematics* 65(8), 1067–1144.

[31] Steenrod, N. E. (1943). Homology with local coefficients. *Annals of Mathematics* 44(4), 610–627.

[32] Vorob'ev, N. N. (1962). Consistent families of measures and their extensions. *Theory of Probability and Its Applications* 7(2), 147–163.

[33] Weibel, C. A. (1994). *An Introduction to Homological Algebra*. Cambridge Studies in Advanced Mathematics 38. Cambridge University Press.

[34] Zomorodian, A. and Carlsson, G. (2005). Computing persistent homology. *Discrete & Computational Geometry* 33(2), 249–274.
:::

# Appendix A: an immutable C# reference kernel

The kernel below computes the coboundary and the cohomology dimensions of a graph sheaf, and the barcode of a chain from its rank invariant. Values are immutable records; functions are pure, and the rank computation works on a private copy of its input. It targets .NET 8 and has no dependencies beyond the base class library.

```csharp
{{file:cs/Topology.cs}}
```

A small program builds seven cases: the constant and sign-twisted triangles, the three-line example, the coordinate sheaf of Figure 2b, an orthogonal four-cycle with reflection holonomy, the clean-top chain of Proposition 4.5 with $D=3$, and a chain with dimensions $2,3,2,2$. An independent NumPy implementation recomputes every printed line. Table 4 compares the two.

Table: **Table 4.** Output of the C# kernel and of the NumPy recomputation. Cohomology lines give $\text{dim}\,H^0$ and $\text{dim}\,H^1$; bar lines give birth position, death position and multiplicity, counted from the bottom (1) to the top.

| C# kernel | NumPy | Match |
|:-----------------|:-----------------|:--|
{{cs_rows}}

# Appendix B: reproducibility

Two Python scripts write every number in this paper to machine-readable files. The main script runs fourteen checks with seed 20261018. The supplementary script runs six more, with seed 20261019: affine barcodes, random stacks with the zigzag, feasible sets, covariance rank, circle covers and the archive filtration. A third script recomputes the C# output, a fourth draws Figures 1 to 6 from the same files, and a fifth replays the random stream of the main script to diagnose the numerically rank-deficient tokens of Section 4.4. The document itself is generated from a source in which every quantity is a reference into those files, so no number was typed by hand. The computations used Python {{env.python}}, NumPy {{env.numpy}}, Matplotlib {{env.matplotlib}} and the .NET SDK {{env.dotnet}}. All scripts, results and the C# project accompany this paper.
