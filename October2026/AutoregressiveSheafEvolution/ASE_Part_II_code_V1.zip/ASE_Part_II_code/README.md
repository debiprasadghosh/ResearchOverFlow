# Autoregressive Sheaf Evolution, Part II: code and results

Companion files for the paper "The Horizontal Layer" (18 October 2026).
Every number in the paper is read from the JSON files in this folder when the document is built.

| File | Purpose |
|------|---------|
| `p2_checks.py` | Twenty numerical checks (seed 20261020); writes `p2_checks.json` |
| `p2_extras.py` | Fourteen supplementary checks (seed 20261021); imports the primitives of `p2_checks.py`; writes `p2_extras.json` |
| `cs/` | .NET 8 reference kernel (`SheafAttention.cs`) and validation program (`Program.cs`); `cs_out.txt` is its output |
| `cs_validate.py` | Recomputes every line of `cs/cs_out.txt` with NumPy; writes `cs_validate.json` |
| `fig_p2.py` | Draws Figures 1 to 5 into `fig/` |
| `src/*.md`, `render.py` | Paper source; `render.py` fills every number from the JSON files and writes `paper.md` |
| `make_ref.py`, `ref.docx`, `postprocess.py` | Word styles, and post-processing that centres numbered equations and puts XML elements in schema order |
| `build.sh` | Render, convert with pandoc, post-process and validate |

Order of execution: `p2_checks.py`, `p2_extras.py`; build and run the C# project (`dotnet run -c Release` in `cs/`)
and save its output as `cs/cs_out.txt`; `cs_validate.py`; `fig_p2.py`; `render.py`; pandoc with
`--reference-doc=ref.docx`; `postprocess.py`.

Versions used: Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1, Matplotlib 3.11.2, .NET SDK 8.0.131, pandoc 3.1.3.
