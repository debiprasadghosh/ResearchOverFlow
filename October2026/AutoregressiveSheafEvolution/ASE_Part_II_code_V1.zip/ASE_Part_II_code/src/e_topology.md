
# 6 Topology of design spaces

Engineering design spaces are rarely a single Euclidean space. Discrete choices split them into branches. Angles live on circles. Mode shapes are lines or subspaces, defined only up to sign or rotation. Symmetric structures identify designs that are mirror images of each other. Part I separated the obstructions these create [15, Section 3.5]. This section studies what they do to the read.

## 6.1 Branches

::: {custom-style="Statement"}
**Proposition 6.1** (branch purity and branch-conditional reads). (i) If every cover element lies in one branch, and all maps, updates, noise models and decoders preserve branches, a token stays in its branch. (ii) With identity maps, let $\pi_b=\sum_{i\in b}\alpha_i$ be the weight of branch $b$ and $m_b$ the branch-conditional read, the read renormalised to the records of branch $b$. Then the shared read is $m=\sum_b\pi_bm_b$, and each $m_b$ lies in the hull of its own branch.
:::

::: {custom-style="Statement Tag"}
\(i) V2 Proposition 9.2; (ii) Mathematics book Theorem 3.10 and Proposition 5.16.
:::

::: {custom-style="Statement"}
**Proposition 6.2** (shared reads land in gaps). In one dimension, let the records of branch 1 lie in $[-w,0]$ and those of branch 2 in $[g,g+w]$, with gap $g>0$ and width $w>0$. If
:::

::: {custom-style="Statement Equation"}
$\frac{w}{g+w}<\pi_2<\frac{g}{g+w}$ (6.1)
:::

::: {custom-style="Statement"}
then the shared read lies in the gap $(0,g)$, where no design is feasible.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* $m=\pi_1m_1+\pi_2m_2$ with $m_1\in[-w,0]$ and $m_2\in[g,g+w]$. The smallest possible value is $-\pi_1w+\pi_2g$, which is positive when $\pi_2>w/(g+w)$. The largest is $\pi_2(g+w)$, which is below $g$ when $\pi_2<g/(g+w)$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{c.branches.cases}} random two-branch archives with random queries and scales, no branch-conditional read left its branch. Condition (6.1) held in {{c.branches.condition_met}} cases, and the shared read landed in the gap in {{c.branches.landed_in_gap}} of them. Overall, {{c.branches.shared_in_gap}} shared reads landed in the gap, so (6.1) is sufficient but not necessary.
:::

::: {custom-style="Statement"}
**Proposition 6.3** (connectedness and atoms). (i) No continuous map from a connected latent space onto a disconnected set of designs exists. The nearest-point projection onto a union of intervals jumps at every gap midpoint and creates atoms at the gap ends. (ii) Projection, clipping, repair onto a boundary and inactive coordinates create atoms, so exact recurrence of a design has positive probability even when continuous variables are present.
:::

::: {custom-style="Statement Tag"}
Mathematics book Theorem 15.1 and Proposition 15.4.
:::

*Engineering meaning.* On a design space with a discrete topology choice and continuous sizing, the shared read proposes designs that belong to no branch whenever both branches carry weight. Branch-conditional reads, with an explicit branch choice and an exploration floor for unrepresented branches [14, Section 9], avoid the gap. Because the branch is chosen explicitly, they also avoid the decoder obstruction of Proposition 6.3(i).

![**Figure 5.** (a) Reads against the query for two branches, with $w=0.3$, $g=1.4$ and $s=0.45$. The shared read crosses the infeasible gap; the branch-conditional reads stay in their branches. The bar marks the queries at which (6.1) holds. (b) Twenty records near angle 0 at $s=0.5$. The read in the cut coordinate, which runs from 0 to $2\pi$, jumps as the query crosses the cut; the local displacement read is continuous (Proposition 6.5). (c) The all-image read against the nearest-image read for three finite groups, with the bound of Theorem 6.6, for 250 random archives per group drawn for the figure. (d) A record just left of the canonical half-space of the sign group is stored as its negative, far from a nearby query, so a canonical index misses it (Proposition 6.10(iv)).](fig/topology.png){width=100%}

## 6.2 Angles

An angle is stored as a coordinate with a cut, but it lives on a circle. V2 replaces the cut coordinate by local displacements $d_i=\text{wrap}(\theta_i-\theta)$ from the query, with $-\pi<d_i\le\pi$ [14, Section 10]. The read is then $r(\theta)=\theta+\sum_i\alpha_id_i$ with $\alpha_i\propto w_i\exp(-d_i^2/2s^2)$, taken modulo $2\pi$ [22].

::: {custom-style="Statement"}
**Proposition 6.4** (nearest-lift approximation). Let $|d_i|\le\pi-\delta$ for some $\delta>0$. Compare the weighted mean displacement using only the nearest lifts $d_i$ with the one using all lifts $d_i+2\pi k$ and their Gaussian factors. With $q=\exp(-2\pi\delta/s^2)<1$,
:::

::: {custom-style="Statement Equation"}
$|m_{\text{all}}-m_{\text{near}}|\le\frac{4\pi q(2-q)}{(1-q)^2}$ (6.2)
:::

::: {custom-style="Statement Tag"}
V2 Proposition 10.1.
:::

::: {custom-style="Check"}
*Numerical check.* In {{c.angles.lift_trials}} random configurations with $q<1/2$ and lifts up to $|k|=30$, (6.2) was never violated, and the largest ratio to the bound was {{c.angles.lift_worst_ratio|f3}}.
:::

::: {custom-style="Statement"}
**Proposition 6.5** (the local angle read jumps only at antipodes). The local read $r$ is continuous on the circle except at the antipodes $\theta_k+\pi$ of the records. There it jumps by $2\pi\alpha_k$ modulo $2\pi$, and for every other record $j$,
:::

::: {custom-style="Statement Equation"}
$\alpha_k\le\frac{w_k}{w_j}\exp\Big(-\frac{\pi^2-d_j^2}{2s^2}\Big)$ (6.3)
:::

::: {custom-style="Statement"}
By contrast, the read in a cut coordinate $0\le\theta<2\pi$ jumps at the cut whenever records lie on both sides of it.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* Each $d_i$ is continuous except where $\theta=\theta_i+\pi$, at which it jumps between $\pi$ and $-\pi$. Since $d_i^2$ is continuous, so are all the weights. Hence $r$ jumps only through the term $\alpha_kd_k$, by $2\pi\alpha_k$. At the antipode $|d_k|=\pi$, so $\alpha_k/\alpha_j=(w_k/w_j)\exp(-(\pi^2-d_j^2)/2s^2)$, and $\alpha_j\le 1$. In a cut coordinate, the coordinate distance to a record changes by $2\pi$ when the query crosses the cut, and so do the weights. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{c.angles.jump_cases}} random configurations, the jump across an antipode, measured by a straddle of $\pm10^{-9}$, equalled $2\pi\alpha_k$ to {{c.angles.jump_formula_err|e1}}, and (6.3) was never violated. For twenty records near $0.15$ and $-0.15$ at $s=0.5$, the cut-coordinate read jumped by {{c.angles.cut_jump|f2}} rad in the coordinate, or {{d.cut_jump_circle|f2}} rad on the circle, while the local read changed by {{c.angles.local_jump|e1}} (Figure 5b).
:::

The local read therefore has discontinuities, but only where a record sits exactly opposite the query, and they are exponentially small whenever another record is nearer than the antipode. This is the precise sense in which local displacements repair the cut.

## 6.3 Signs and finite symmetry groups

A vibration mode is a line, not a vector: $u$ and $-u$ are the same mode. A mirror-symmetric structure identifies a design with its mirror image. Both are actions of a finite group of orthogonal maps, and one theorem covers them.

::: {custom-style="Statement"}
**Theorem 6.6** (nearest-image reads for a finite group). Let $G$ be a finite group of orthogonal matrices acting on records $y_i\in ℝ^D$ with weights $w_i$. The all-image read $m_{\text{all}}$ replaces each record by its $|G|$ images $gy_i$, each with weight $w_i$. The nearest-image read $m_{\text{near}}$ replaces each record by its image nearest to $z$. Let $\Delta^2$ be the smallest, over records, gap between the nearest and second-nearest squared image distances. Put $q=e^{-\Delta^2/2s^2}$ and $\varepsilon=(|G|-1)q/(1+(|G|-1)q)$. Then:
:::

::: {custom-style="Statement"}
\(i) $\|m_{\text{all}}-m_{\text{near}}\|\le 2\varepsilon\,\text{max}_i\|y_i\|$;
:::

::: {custom-style="Statement"}
\(ii) $m_{\text{all}}(gz)=g\,m_{\text{all}}(z)$ for every $g\in G$;
:::

::: {custom-style="Statement"}
\(iii) $m_{\text{near}}(gz)=g\,m_{\text{near}}(z)$ wherever the nearest images are unique.
:::

::: {custom-style="Statement Tag"}
New in Part II. The group $\{\pm I\}$ gives the sign alignment of V2 Section 11; the angle lifts of Proposition 6.4 are the analogue for the infinite group $2\pi ℤ$.
:::

*Proof.* (i) Let $\pi_i$ be the kernel weight of the nearest image $n_i$ of record $i$, and $Z=\sum_i\pi_i$. Every other image has relative weight at most $q$, so the extra mass $Y$ satisfies $Y\le(|G|-1)qZ$. Then $m_{\text{all}}-m_{\text{near}}$ is a weighted sum of the vectors $gy_i-m_{\text{near}}$ over non-nearest images, with total weight $Y/(Z+Y)\le\varepsilon$. Each vector has norm at most $\|y_i\|+\|m_{\text{near}}\|\le 2\,\text{max}_i\|y_i\|$, because orthogonal maps preserve norms and $m_{\text{near}}$ is a convex combination of images. (ii) $\|gz-hy_i\|=\|z-g^{-1}hy_i\|$, so reindexing the images by $h=gh'$ maps the weighted image set at $z$ onto $g$ times itself. (iii) The image of $y_i$ nearest to $gz$ is $g$ times the image nearest to $z$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* For sign flips in $ℝ^6$, mirror reversal of the coordinates in $ℝ^6$ and the dihedral group of order 12 in $ℝ^2$, 500 random archives each gave no violation of (i). The largest ratios to the bound were {{d.ni_sign.worst_ratio|f3}}, {{d.ni_mirror.worst_ratio|f3}} and {{d.ni_dihedral.worst_ratio|f3}}. Equivariance held to {{d.ni_eq_all|e1}} for the all-image read and to {{d.ni_eq_near|e1}} for the nearest-image read (Figure 5c).
:::

::: {custom-style="Statement"}
**Example 6.7** (sign transport, re-run). Take fifty unit vectors in $ℝ^6$ near a reference direction $u$, with random signs. At $s=2$, the raw read has norm {{c.sign_example.1.raw_norm|f3}} and cosine {{c.sign_example.1.raw_cos|f3}} with $u$, while the sign-aligned read has norm {{c.sign_example.1.aligned_norm|f3}} and cosine {{c.sign_example.1.aligned_cos|f3}}. At $s=0.5$ they are {{c.sign_example.0.raw_norm|f3}} ({{c.sign_example.0.raw_cos|f3}}) and {{c.sign_example.0.aligned_norm|f3}} ({{c.sign_example.0.aligned_cos|f3}}), because a small scale already selects the nearest images.
:::

::: {custom-style="Statement Tag"}
V2 Section 11; this is a new random instance, so the numbers differ from the proposal's while the conclusion stands.
:::

## 6.4 Lines and subspaces

Repeated or nearly repeated eigenvalues define a modal subspace in which individual eigenvectors rotate freely. The stable object is the orthogonal projector onto the subspace, and the read is the weighted projector average $P_\alpha=\sum_i\alpha_iP_i$, whose top eigenvectors span the read subspace [14, Section 11].

::: {custom-style="Statement"}
**Proposition 6.8** (projector reads).
:::

::: {custom-style="Statement"}
\(i) For lines in the plane at angles $\phi_i$, measured from a reference direction with $\text{max}_i|\phi_i|=\psi$, let $\theta_P$ be the principal direction of $P_\alpha$ and $\theta_m$ the direction of the sign-aligned mean $\sum_i\alpha_i(\cos\phi_i,\sin\phi_i)$. With $\mu=\sum_i\alpha_i\phi_i$ and $\kappa_3=\sum_i\alpha_i(\phi_i-\mu)^3$,
:::

::: {custom-style="Statement Equation"}
$\theta_P-\theta_m=-\tfrac12\kappa_3+O(\psi^5)$ (6.4)
:::

::: {custom-style="Statement"}
\(ii) If $P_\alpha$ is perturbed to $P_\alpha+E$, and $\gamma=\lambda_k(P_\alpha)-\lambda_{k+1}(P_\alpha)>0$ is the gap below the top $k$ eigenvalues, then the read subspaces satisfy $\|\sin\Theta\|\le 2\|E\|/\gamma$.
:::

::: {custom-style="Statement"}
\(iii) Under the bounded measurement error of Theorem 4.8, $\|E\|\le\text{TV}(\alpha,\alpha')\,\text{max}_{i,j}\|P_i-P_j\|$, so $\|\sin\Theta\|\le 2\tanh(\beta\varepsilon/2)\,\text{max}_{i,j}\|P_i-P_j\|/\gamma$.
:::

::: {custom-style="Statement Tag"}
\(i) and (iii) New in Part II; (ii) Classical [9, 25].
:::

*Proof.* (i) Write $\phi_i=\mu+\delta_i$ with $\sum_i\alpha_i\delta_i=0$. Expanding, $\sum_i\alpha_i\sin\delta_i=-\kappa_3/6+O(\psi^5)$ and $\sum_i\alpha_i\cos\delta_i=1+O(\psi^2)$, so $\theta_m=\mu-\kappa_3/6+O(\psi^5)$. Likewise $\sum_i\alpha_i\sin 2\delta_i=-\tfrac43\kappa_3+O(\psi^5)$, so $\theta_P=\mu+\tfrac12\text{atan2}(\sum_i\alpha_i\sin 2\delta_i,\sum_i\alpha_i\cos 2\delta_i)=\mu-\tfrac23\kappa_3+O(\psi^5)$. Subtract. (ii) If $\|E\|\ge\gamma/2$, the bound exceeds 1, and $\|\sin\Theta\|\le 1$ always. Otherwise, Weyl's inequality separates the perturbed top-$k$ eigenvalues from the remaining unperturbed spectrum by at least $\gamma-\|E\|\ge\gamma/2$. The Davis–Kahan $\sin\Theta$ theorem then gives $\|\sin\Theta\|\le\|E\|/(\gamma/2)$ [9, 25]. (iii) $E=\sum_i(\alpha'_i-\alpha_i)P_i$ is $\text{TV}$ times the difference of two convex combinations of projectors. That difference has norm at most $\text{max}_{i,j}\|P_i-P_j\|$, because the norm is convex. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{c.projector.line_cases}} random sets of lines with spread up to {{c.projector.max_spread|f2}} rad, $|\theta_P-\theta_m+\kappa_3/2|/\psi^5$ was at most {{c.projector.third_order_residual_max|f3}}. In {{c.projector.dk_cases}} random subspace perturbations, (ii) was never violated, with largest ratio {{c.projector.dk_worst_ratio|f3}}. In {{x.projector_measurement.trials}} trials with bounded measurement error, both inequalities of (iii) held, with largest ratios {{x.projector_measurement.perturbation_worst|f3}} and {{x.projector_measurement.subspace_worst|f3}}.
:::

Sign alignment and projector averaging therefore agree to second order, and differ at third order by half the third central moment of the angles. When the records are skewed around the mean mode, the two reads disagree measurably. When the modal gap $\gamma$ closes, only the projector read keeps a stability guarantee.

## 6.5 Physical quotients

A reflected copy of an archived design is a new coordinate vector but often the same engineering design. Hypothesis C4 of V2 asks that novelty be reported modulo symmetry [14, Section 18].

::: {custom-style="Statement"}
**Definition 6.9** (orbit distance and novelty modulo symmetry). For a finite group $G$ of orthogonal matrices, the orbit distance is $d_G(x,y)=\text{min}_{g\in G}\|x-gy\|$. A candidate $x$ is coordinate-novel at tolerance $\tau$ if $\|x-y_i\|>\tau$ for every archived $y_i$, and orbit-novel if $d_G(x,y_i)>\tau$ for every $i$.
:::

::: {custom-style="Statement Tag"}
V2 Section 18, hypothesis C4, made a definition.
:::

::: {custom-style="Statement"}
**Proposition 6.10** (indexing modulo a finite group).
:::

::: {custom-style="Statement"}
\(i) $d_G$ is a metric on the orbit space $ℝ^D/G$, and orbit novelty implies coordinate novelty.
:::

::: {custom-style="Statement"}
\(ii) A range query of radius $\tau$ in $d_G$ is answered exactly by $|G|$ ordinary range queries of radius $\tau$ at the points $g^{-1}x$, followed by removal of duplicate records.
:::

::: {custom-style="Statement"}
\(iii) If $G$ is generated by reflections, let $𝒞$ be a closed fundamental chamber and $c(x)$ the unique point of the orbit $Gx$ in $𝒞$. Then $d_G(x,y)=\|c(x)-c(y)\|$, so one ordinary index on canonical representatives is exact.
:::

::: {custom-style="Statement"}
\(iv) Let $G=\{I,g\}$ with $g$ an involution whose $-1$ eigenspace has dimension at least 2. Then no continuous map $c$ on the set of points not fixed by $g$ satisfies $c(x)\in\{x,gx\}$ and $c(gx)=c(x)$. In particular, every index on canonical representatives has a seam across which near neighbours are missed. This applies to the sign group in $ℝ^D$ for $D\ge 2$, and to mirror reversal of a design with at least two mirrored pairs of coordinates.
:::

::: {custom-style="Statement Tag"}
\(i) and (ii) Classical; (iii) from [20, Section 1.12]; (iv) New in Part II.
:::

*Proof.* (i) Orthogonality gives $\|x-gy\|=\|g^{-1}x-y\|$, hence symmetry, and the triangle inequality follows from $\|x-ghz\|\le\|x-gy\|+\|y-hz\|$. The minimum over a finite group is attained, so $d_G(x,y)=0$ only when $x$ and $y$ lie on one orbit. Orbit novelty implies coordinate novelty because $d_G\le\|\cdot\|$. (ii) $\|x-gy\|=\|g^{-1}x-y\|$. (iii) For $x,y\in 𝒞$ and $w\in G$, the conjugate of $wy$ in $𝒞$ is $y$, and $y-wy$ is a nonnegative combination of simple roots [20, Lemma and Theorem 1.12]. Since $x\in 𝒞$ has nonnegative inner product with every simple root, $\langle x,y-wy\rangle\ge 0$, so $\|x-wy\|^2-\|x-y\|^2=2\langle x,y-wy\rangle\ge 0$. Thus $d_G(x,y)=\|x-y\|$ on $𝒞$, and $d_G$ is constant on orbits. (iv) Write $x=x_s+x_a$ with $x_s$ in the $+1$ and $x_a$ in the $-1$ eigenspace of $g$. The points not fixed by $g$ are those with $x_a\ne 0$, a connected set because $x_a$ ranges over a space of dimension at least 2 with the origin removed. On it, $c(x)=x$ or $c(x)=gx$, and the choice is a continuous function into $\{1,-1\}$, hence constant. If $c(x)=x$ everywhere, then $c(gx)=gx\ne x=c(x)$; if $c(x)=gx$ everywhere, then $c(gx)=x\ne gx=c(x)$. For the sign group the $-1$ eigenspace is $ℝ^D$. For mirror reversal its dimension is the number of mirrored pairs. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* For the dihedral group of order 12, a reflection group, $d_G$ and the canonical distance agreed to {{d.qi_refl.max_err|e1}} on {{d.qi_refl.pairs}} random pairs. Queries were placed near random images of 500 archived designs, with noise of standard deviation 0.15. Over 2,000 queries, an index on a canonical half-space missed the true nearest orbit neighbour in {{d.qi_sign.nearest_missed}} queries ({{d.qi_miss_rate_sign|pct1}}) for sign flips in $ℝ^6$, and in {{d.qi_mirror.nearest_missed}} ({{d.qi_miss_rate_mirror|pct1}}) for mirror reversal in $ℝ^6$ (Figure 5d).
:::

*Engineering meaning.* Re-selection and novelty under symmetry should be measured with $d_G$, computed exactly by $|G|$ queries, or by a chamber index when the group is generated by reflections. Storing canonical orbit representatives, as hypothesis C4 suggests, is exact for a single mirrored pair of members. A symmetric truss with two or more mirrored pairs has no continuous canonical form, so a canonical index will occasionally report a reflected design as novel.
