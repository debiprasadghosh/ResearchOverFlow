
# 7 Register of numerical checks

Table 6 lists every numerical check in Part II. A main script produced {{d.n_main}} checks and a supplementary script {{d.n_extra}}. Both write machine-readable results, and every number in this paper is read from those files when the document is built. The checks test the implementations and illustrate the statements; the proofs establish them. Random archives are synthetic, so the ratios to bounds describe these constructions, not engineering archives in general.

Table: **Table 6.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 3.1 | harmonic extension, {{c.harmonic_extension.trials}} stars | {{c.harmonic_extension.schur_max_err\|e1}}; {{c.harmonic_extension.better_found}} of {{c.harmonic_extension.perturbations}} perturbations lower the energy |
| 2 | Proposition 3.1(ii) | Schur-complement minimum, {{x.schur_energy.cases}} stars | relative {{x.schur_energy.rel_err\|e1}} |
| 3 | Proposition 3.2 | retention read, {{x.retention.cases}} singular stars | nearest minimiser to {{x.retention.nearest_minimiser_err\|e1}}; bound (3.2) attained |
| 4 | Proposition 3.3 | matrix weights, {{c.matrix_weights.trials}} stars | sum {{c.matrix_weights.sum_to_identity_err\|e1}}; lifts {{c.matrix_weights.lift_invariance_err\|e1}} |
| 5 | Corollary 3.4, Proposition 3.5 | hulls, boxes, crossovers | {{c.hulls.box_violations}} box violations; {{c.hulls.outside_hull}} outside hull; {{c.hulls.crossover_outside}} of {{c.hulls.crossover_cases}} crossovers outside |
| 6 | Proposition 3.5(iii) | coordinatewise ceiling, {{x.coordinate_ceiling.cases}} stars | {{x.coordinate_ceiling.floor_violations}} violations; {{x.coordinate_ceiling.beats_best_record}} beat the best record |
| 7 | Proposition 3.6 | bounds (3.5), {{c.conditioning.angle_trials}} pairs | {{c.conditioning.lower_violations}} and {{c.conditioning.upper_violations}} violations; ratio from {{c.conditioning.ratio_min\|f7}} |
| 8 | Proposition 3.6(i) | spectrum (3.4), {{x.two_subspace_spectrum.trials}} pairs | {{x.two_subspace_spectrum.max_err\|e1}} |
| 9 | Proposition 3.7 | amplification, coverage, two lines | largest ratio {{c.conditioning.amplification_worst\|f4}}; coverage exact; $1/\sin\theta$ exact |
| 10 | Proposition 3.8 | residual trace, {{c.residual_trace.cases}} stars | {{c.residual_trace.max_err\|e1}} |
| 11 | Propositions 3.9, 4.1 | gradient and Tweedie identities | {{c.gradient_tweedie.gradient_rel_err\|e1}} and {{c.gradient_tweedie.tweedie_err\|e1}} |
| 12 | Propositions 3.9, 3.13 | Hessian and Euclidean step, {{x.hessian_and_step.trials}} stars | Hessian {{x.hessian_and_step.hessian_rel_err\|e1}}; {{x.hessian_and_step.step_violations}} violations |
| 13 | Theorem 3.10 | majorise–minimise, {{c.mm.trials}} stars, {{c.mm.runs}} runs | {{c.mm.violations}} violations; all runs monotone; rises beyond $\lambda=2$ in {{d.over_two_rate\|pct0}} |
| 14 | Proposition 3.11 | ADE recovery, {{c.ade_recovery.cases}} cases | {{c.ade_recovery.max_err\|e1}} |
| 15 | Corollary 3.12 | ADE layers, {{x.ade_descent.steps}} steps | {{x.ade_descent.violations}} violations |
| 16 | Proposition 4.2 | chart posterior, {{x.chart_vs_sheaf.cases}} charts | (4.2) to {{x.chart_vs_sheaf.difference_err\|e1}} |
| 17 | Proposition 4.3 | properness | $2\pi$ for a full record; linear growth for a partial one |
| 18 | Proposition 4.4(i), (ii) | imputation, {{c.imputation.cases}} stars | {{c.imputation.gradient_identity_err\|e1}} and {{c.imputation.preconditioning_identity_err\|e1}} |
| 19 | Proposition 4.4(iii) | Cimmino sweeps, {{x.cimmino.trials}} stars | {{x.cimmino.rate_violations_at_50}} rate violations; {{x.cimmino.final_err\|e1}} |
| 20 | Proposition 4.5 | tilted product law | {{x.tilt_law.mean_rel_err\|e1}}; exponential mass growth with slope |
| 21 | Proposition 4.6 | selection tilt | $\lambda_{\text{min}}$ {{d.tilt_p.5\|e1}} against {{d.tilt_f.5\|f3}} at $\beta=100$ |
| 22 | Theorem 4.8 | measurement, {{c.measurement.trials}} and {{c.measurement.rect_trials}} trials | {{c.measurement.tv_violations}} violations; two-point case attains the bound |
| 23 | Proposition 5.1, Corollary 5.2 | truncation, 540 queries | {{c.truncation.violations}} violations; certified radii {{c.truncation.certified.0.median_c\|f2}}$s$, {{c.truncation.certified.1.median_c\|f2}}$s$, {{c.truncation.certified.2.median_c\|f2}}$s$ |
| 24 | Theorem 5.3(i) | rectangular truncation, {{c.rect_truncation.trials}} stars | {{c.rect_truncation.violations}} violations; largest ratio {{c.rect_truncation.worst_ratio\|f3}} |
| 25 | Theorem 5.3(ii) | rectangular certificate, {{d.rc_tests}} tests | {{d.rc_finite}} finite, none violated; largest ratio {{d.rc_worst\|f3}} |
| 26 | Proposition 5.4(i)–(iii) | Jacobian, {{c.jacobian.cases}} stars | {{c.jacobian.fd_rel_err\|e1}} worst; orthogonal {{c.jacobian.orth_err\|e1}} |
| 27 | Proposition 5.4(iv) | Jacobian bound, {{x.jacobian_bound.cases}} stars | {{x.jacobian_bound.violations}} violations; equality on orthogonal stars |
| 28 | Corollary 5.5 | stationary points | {{x.stationary.minima}} minima with $\rho(Dm)\le$ {{x.stationary.spectral_radius_max\|f3}}; saddles at $1/s^2$ |
| 29 | Proposition 6.2 | branches, {{c.branches.cases}} archives | {{c.branches.landed_in_gap}} of {{c.branches.condition_met}} in the gap |
| 30 | Propositions 6.4, 6.5 | angle lifts and antipodal jumps | {{c.angles.lift_violations}} and {{c.angles.jump_bound_violations}} violations; cut jump {{c.angles.cut_jump\|f2}} rad |
| 31 | Theorem 6.6 | nearest images, three groups | {{d.nim_viol}} violations in {{d.ni_trials}} trials |
| 32 | Example 6.7 | sign transport | read norm {{c.sign_example.1.raw_norm\|f3}} raw against {{c.sign_example.1.aligned_norm\|f3}} aligned |
| 33 | Proposition 6.8 | projector reads, {{c.projector.line_cases}} and {{x.projector_measurement.trials}} trials | residual at most {{c.projector.third_order_residual_max\|f3}}$\psi^5$; {{c.projector.dk_violations}} violations |
| 34 | Proposition 6.10 | orbit indexes | reflection group {{d.qi_refl.max_err\|e1}}; misses {{d.qi_miss_rate_sign\|pct1}} and {{d.qi_miss_rate_mirror\|pct1}} |
| 35 | Appendix A | C# kernel against NumPy | {{v.agree}} of {{v.lines}} lines agree; {{v.identical}} identical to 15 digits |

# 8 Discussion

## 8.1 What Part II supplies to the rest of the book

Part III, the vertical stack, studies the token recurrence. Its layer updates are those of Table 3, and Corollary 3.12 adds that every deterministic ADE layer is a guaranteed-descent step at its own scale. Proposition 5.4 gives the tangent map of one layer. Products of these maps along a token's path are the tangent fibre diagrams of Part I, and the eigenvalue description of Corollary 5.5 says which tangent directions contract at a converged layer. The Lipschitz bound of Proposition 5.4(iv), multiplied along a stack, is the end-to-end perturbation bound that V2 asks for before hypothesis C5 can be tested [14, Section 12].

Part IV, on targets and estimation, inherits the distinction between mixture and product laws (Proposition 4.3). A local law is a probability law only under the stated conditions, and only a proper law can serve as an importance proposal. Proposition 4.5 adds that a tilted proposal needs coverage in every direction of objective slope, and Theorem 4.8 gives a worst-case budget for critic error. The truncation certificates separate truncation error from estimation error in any consistency argument.

Part V, on fusion and constraints, must keep products of experts apart from the junction-tree marginal extension of V2 [14, Section 16], since they are different operations with different conclusions. The coordinatewise ceiling of Proposition 3.5(iii) bounds what recombination alone can achieve before constraints act. Part VI, on evidence and computation, takes the retention rule, the eigenvalue threshold, the certificates and the index contract of Table 5 as kernel specifications. Appendix A gives the first implementation.

## 8.2 Diagnostics a layer should report

Defensibility requires that every read carry the quantities its guarantees depend on (Table 7).

Table: **Table 7.** Diagnostics reported with every read.

| Diagnostic | Source | Action when it is poor |
|:-------------------|:-------------------|:-------------------------------|
| $\lambda_{\text{min}}(H)$ or the smallest coverage | Propositions 3.6, 3.7, 4.6 | enlarge the star, add a declared prior, or anneal $\beta$ |
| dimension of the unresolved space | Proposition 3.2 | report it; never invent values |
| guaranteed decrease, the right side of (3.8) | Theorem 3.10 | keep $0<\lambda<2$ |
| truncation certificate and star share | Proposition 5.1, Theorem 5.3 | grow the star or fall back to the full read |
| Jacobian bound | Proposition 5.4(iv) | flag sensitive reads |
| branch weights $\pi_b$ | Propositions 6.1, 6.2 | read per branch when (6.1) holds |
| largest antipodal weight | Proposition 6.5 | none while it is exponentially small |
| orbit distance $d_G$ to the archive | Proposition 6.10 | report orbit novelty, not coordinate novelty |

## 8.3 What is not claimed

The descent of Theorem 3.10 holds at one layer, for fixed records, maps and prior weights. It does not imply that the iterates converge, and it says nothing about search across layers. The prior weights are fixed at the query; learned or query-dependent maps and weights add terms to every derivative used here [14, Section 6]. The certificates assume a complete star and were conservative by two to six orders of magnitude in the experiments. None of hypotheses C1 to C5 is tested. In particular, the recombination results of Section 3.3 describe single reads, not search outcomes.

## 8.4 Open problems

1. **Convergence of iterates.** Prove that sheaf mean-shift iterates converge for rectangular maps under conditions comparable to those known for Gaussian mean shift [5].
2. **Sharper certificates.** Use second moments of the far field, or a hierarchical index, to tighten (5.1) and (5.2) by orders of magnitude without losing their a posteriori character.
3. **Compact symmetry groups.** Rotational symmetries of components form compact groups such as $SO(2)$ and $SO(3)$. Extend Theorem 6.6, with Haar averages in place of finite sums, and Proposition 6.10 to their orbit spaces.
4. **Adaptive maps.** Add the Jacobian terms of query-dependent maps to Proposition 5.4, and certify truncation when the maps themselves are uncertain.
5. **Selection against critic error.** Design annealing schedules for $\beta$ that respect the budget of Theorem 4.8 while keeping the coverage of Proposition 4.6, and test them within hypothesis C2.
6. **Grassmannian reads.** Compare the projector read with Karcher means on the Grassmannian, and determine when the third-order disagreement of Proposition 6.8(i) matters for mode tracking.

## 8.5 Conclusion

One layer of ASE is one operation: a read through maps on an observation star. Part II shows that this read is a harmonic extension, a matrix-weighted combination, a recombination operator with a provable ceiling, and a majorise–minimise step on the soft energy, of which every deterministic ADE layer is an instance. Its local laws, tilts and measurement errors obey exact statements, and so do its locality and sensitivity. On structured design spaces its failure modes are explicit and its repairs proved: gaps between branches, cuts in angles, signs and symmetries. Part III now stacks these layers.

# References

::: {custom-style="Bibliography"}
[1] Barbero, F., Bodnar, C., Sáez de Ocáriz Borde, H. and Liò, P. (2022). Sheaf attention networks. *NeurIPS 2022 Workshop on Symmetry and Geometry in Neural Representations*.

[2] Bhatia, R. and Davis, C. (2000). A better bound on the variance. *The American Mathematical Monthly* 107(4), 353–357.

[3] Björck, Å. and Golub, G. H. (1973). Numerical methods for computing angles between linear subspaces. *Mathematics of Computation* 27(123), 579–594.

[4] Bodnar, C., Di Giovanni, F., Chamberlain, B. P., Liò, P. and Bronstein, M. M. (2022). Neural sheaf diffusion: a topological perspective on heterophily and oversmoothing in GNNs. *Advances in Neural Information Processing Systems* 35. arXiv:2202.04579.

[5] Carreira-Perpiñán, M. Á. (2007). Gaussian mean-shift is an EM algorithm. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 29(5), 767–776.

[6] Cheng, Y. (1995). Mean shift, mode seeking, and clustering. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 17(8), 790–799.

[7] Cimmino, G. (1938). Calcolo approssimato per le soluzioni dei sistemi di equazioni lineari. *La Ricerca Scientifica ed il Progresso Tecnico nell'Economia Nazionale*, Serie II, 1, 326–333.

[8] Comaniciu, D. and Meer, P. (2002). Mean shift: a robust approach toward feature space analysis. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 24(5), 603–619.

[9] Davis, C. and Kahan, W. M. (1970). The rotation of eigenvectors by a perturbation. III. *SIAM Journal on Numerical Analysis* 7(1), 1–46.

[10] Efron, B. (2011). Tweedie's formula and selection bias. *Journal of the American Statistical Association* 106(496), 1602–1614.

[11] Fashing, M. and Tomasi, C. (2005). Mean shift is a bound optimization. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 27(3), 471–474.

[12] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[13] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[14] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[15] Ghosh, D. P. (2026d). *Horizontally Topological, Vertically Algebraic: The Two Axes of Autoregressive Sheaf Evolution. Part I: Sheaves on Covers and Representations of the Layer Order*. 18 October 2026.

[16] Halmos, P. R. (1969). Two subspaces. *Transactions of the American Mathematical Society* 144, 381–389.

[17] Hansen, J. and Ghrist, R. (2019). Toward a spectral theory of cellular sheaves. *Journal of Applied and Computational Topology* 3(4), 315–358.

[18] Hinton, G. E. (2002). Training products of experts by minimizing contrastive divergence. *Neural Computation* 14(8), 1771–1800.

[19] Horn, R. A. and Johnson, C. R. (2013). *Matrix Analysis*, 2nd edn. Cambridge University Press.

[20] Humphreys, J. E. (1990). *Reflection Groups and Coxeter Groups*. Cambridge Studies in Advanced Mathematics 29. Cambridge University Press.

[21] Hunter, D. R. and Lange, K. (2004). A tutorial on MM algorithms. *The American Statistician* 58(1), 30–37.

[22] Mardia, K. V. and Jupp, P. E. (2000). *Directional Statistics*. Wiley.

[23] Ramsauer, H., Schäfl, B., Lehner, J., Seidl, P., Widrich, M., Adler, T., Gruber, L., Holzleitner, M., Pavlović, M., Sandve, G. K., Greiff, V., Kreil, D., Kopp, M., Klambauer, G., Brandstetter, J. and Hochreiter, S. (2021). Hopfield networks is all you need. *International Conference on Learning Representations*. arXiv:2008.02217.

[24] Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, J., Jones, L., Gomez, A. N., Kaiser, Ł. and Polosukhin, I. (2017). Attention is all you need. *Advances in Neural Information Processing Systems* 30.

[25] Yu, Y., Wang, T. and Samworth, R. J. (2015). A useful variant of the Davis–Kahan theorem for statisticians. *Biometrika* 102(2), 315–323.

[26] Yuille, A. L. and Rangarajan, A. (2003). The concave-convex procedure. *Neural Computation* 15(4), 915–936.
:::

# Appendix A: an immutable C# reference kernel

The kernel computes sheaf attention with the retention rule, the soft energy, relaxed steps with their guaranteed decrease, the scalar truncation certificate, and all-image and nearest-image reads under a finite group. Values are immutable records and functions are pure; the symmetric eigensolver, a cyclic Jacobi method, works on a private copy of its input. The kernel targets .NET 8 and uses only the base class library.

```csharp
{{file:cs/SheafAttention.cs}}
```

A driver program exercises the kernel on four records in $ℝ^3$: a coordinate mask, a single coordinate, a partial isometry with two rows, and one general row. It prints a resolved read with three relaxed steps, an unresolved read at a small scale, both group reads under coordinate reversal, and a truncation certificate. An independent NumPy script recomputes every printed number (Table A1). Eleven of the twelve lines are identical to 15 significant digits. The remaining line is the error of a truncated read, a difference of two nearly equal means, and it agrees to a relative {{v.worst_rel_diff|e1}}.

Table: **Table A1.** C# kernel output against the NumPy recomputation.

| C# | NumPy | Agreement |
|:------------------|:------------------|:----------|
{{cs_rows}}

# Appendix B: reproducibility

All results were produced with Python {{env.python}}, NumPy {{env.numpy}}, SciPy {{env.scipy}}, Matplotlib {{env.matplotlib}} and .NET SDK {{env.dotnet}}. The script `p2_checks.py` runs the twenty main checks with seed 20261020 and writes `p2_checks.json`. The script `p2_extras.py` runs the fourteen supplementary checks with seed 20261021 and writes `p2_extras.json`. The script `fig_p2.py` draws the figures. Panels marked as recomputed use their own fixed seeds; all other plotted values are read from the result files. The C# project in `cs/` builds the kernel and its driver, and `cs_validate.py` compares the driver's output with NumPy and writes `cs_validate.json`. The document is assembled by `render.py`, which reads every quoted number from these files, converted to Word by Pandoc, and post-processed for equation layout and schema order. A code archive accompanies this paper.
