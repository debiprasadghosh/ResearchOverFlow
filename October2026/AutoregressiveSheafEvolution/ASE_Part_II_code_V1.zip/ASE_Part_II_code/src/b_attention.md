
# 3 Sheaf attention

## 3.1 The read is a harmonic extension

On the star, give the token vertex the stalk $ℝ^D$, the leaf of record $i$ the stalk $ℝ^{d_i}$ and the edge joining them the stalk $ℝ^{k_i}$. The coboundary of an assignment $(x_0,x_1,\ldots,x_n)$ is $(\delta x)_i=R_ix_i-Q_ix_0$, and fixed coefficients $c_i>0$ define the weighted sheaf Laplacian $L=\delta^{\top}C\delta$ [17]. Partition $L$ into the token block $t$ and the leaf block $\ell$.

::: {custom-style="Statement"}
**Proposition 3.1** (harmonic extension and its Schur complement). Suppose $G=\sum_ic_iQ_i^{\top}Q_i\succ 0$ and fix the leaves at $y=(y_1,\ldots,y_n)$.
:::

::: {custom-style="Statement"}
\(i) The unique minimiser of $\sum_ic_i\|Q_ix_0-R_iy_i\|^2$ over the token value is $x_0=G^{-1}\sum_ic_iQ_i^{\top}R_iy_i=-L_{tt}^{-1}L_{t\ell}\,y$. It is the harmonic extension of $y$: the token component of $L(x_0,y)$ vanishes.
:::

::: {custom-style="Statement"}
\(ii) The minimum value is the Schur-complement form
:::

::: {custom-style="Statement Equation"}
$\text{min}_{x_0}\sum_ic_i\|Q_ix_0-R_iy_i\|^2=y^{\top}(L_{\ell\ell}-L_{\ell t}L_{tt}^{-1}L_{t\ell})\,y$ (3.1)
:::

::: {custom-style="Statement Tag"}
\(i) V2 Proposition 5.1; (ii) Classical [17, 19].
:::

*Proof.* The energy is $(x_0,y)^{\top}L(x_0,y)$ with $L_{tt}=\sum_ic_iQ_i^{\top}Q_i=G$ and $L_{t\ell}\,y=-\sum_ic_iQ_i^{\top}R_iy_i$. It is a strictly convex quadratic in $x_0$, minimised where $L_{tt}x_0+L_{t\ell}y=0$, which is the harmonic condition at the token vertex. Substituting the minimiser gives the Schur complement. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{c.harmonic_extension.trials}} random stars with general rectangular maps, the normal-equation read and $-L_{tt}^{-1}L_{t\ell}y$ agreed to {{c.harmonic_extension.schur_max_err|e1}}. Among {{c.harmonic_extension.perturbations}} random perturbations of size $10^{-3}$, {{c.harmonic_extension.better_found}} lowered the energy. In {{x.schur_energy.cases}} further stars, the minimum value matched (3.1) to a relative {{x.schur_energy.rel_err|e1}}.
:::

The retention rule of Definition 2.2 is needed whenever the retrieved records do not jointly observe every direction of the token frame. The next proposition says what it computes.

::: {custom-style="Statement"}
**Proposition 3.2** (the retention read). Freeze the weights at $z$ and let $M(x)=\sum_i\alpha_ie_i(x)$ be the frozen star energy. Then:
:::

::: {custom-style="Statement"}
\(i) $b\in\text{range}\,H$, so the minimisers of $M$ form the affine set $m+\text{ker}\,H$;
:::

::: {custom-style="Statement"}
\(ii) the read (2.3) is the minimiser of $M$ nearest to $z$;
:::

::: {custom-style="Statement"}
\(iii) for $\tau>0$, the token-anchored ridge read $m_\tau=(H+\tau I)^{-1}(b+\tau z)$ satisfies
:::

::: {custom-style="Statement Equation"}
$\|m_\tau-m\|\le\frac{\tau}{\lambda_r+\tau}\,\|m-z\|$ (3.2)
:::

::: {custom-style="Statement"}
where $\lambda_r$ is the smallest positive eigenvalue of $H$, so $m_\tau\to m$ as $\tau\to 0$;
:::

::: {custom-style="Statement"}
\(iv) if $H\succ 0$, then $m=H^{-1}b$.
:::

::: {custom-style="Statement Tag"}
New in Part II. V2 Section 4 states the rule.
:::

*Proof.* (i) Every $\alpha_i$ is positive, so $\text{range}\,H=\sum_i\text{range}\,Q_i^{\top}$, which contains $b$. Since $M(x)=\tfrac12x^{\top}Hx-b^{\top}x+\text{const}$, its minimisers are the solutions of $Hx=b$. (ii) Because $b-Hz\in\text{range}\,H$, $Hm=Hz+HH^{\dagger}(b-Hz)=b$, so $m$ is a minimiser. Moreover $m-z=H^{\dagger}(b-Hz)\in\text{range}\,H=(\text{ker}\,H)^{\perp}$, which characterises the orthogonal projection of $z$ onto $m+\text{ker}\,H$. (iii) $m_\tau-z=(H+\tau I)^{-1}(b-Hz)$ and $m-z=H^{\dagger}(b-Hz)$. In an eigenbasis of $H$, the component along an eigenvalue $\lambda>0$ changes by the factor $\lambda/(\lambda+\tau)$, that is, by $\tau/(\lambda+\tau)\le\tau/(\lambda_r+\tau)$ of itself. The components along $\text{ker}\,H$ vanish in both. (iv) Here $H^{\dagger}=H^{-1}$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{x.retention.cases}} stars whose maps observe a random proper subspace, the read agreed with an independently computed nearest minimiser, obtained from a least-squares solution projected along $\text{ker}\,H$, to a relative {{x.retention.nearest_minimiser_err|e1}}. The normal residual on resolved directions was {{x.retention.resolved_residual|e1}}. At $\tau/\lambda_r=10^{-2}$, $10^{-4}$ and $10^{-6}$, the largest values of $\|m_\tau-m\|/\|m-z\|$ were {{d.ridge2|g4}}, {{d.ridge4|g4}} and {{d.ridge6|g4}}, so bound (3.2) is attained.
:::

*Engineering meaning.* The retention read never invents a value in a direction that no retrieved record observes; that direction keeps the token's own value. A ridge prior is the alternative V2 allows. Proposition 3.2 shows that the retention read is the vanishing-ridge limit, and that any positive $\tau$ is a declared prior that changes the read.

## 3.2 Matrix weights

::: {custom-style="Statement"}
**Proposition 3.3** (matrix weights). Let $G=\sum_ic_iQ_i^{\top}Q_i\succ 0$ and $A_i=G^{-1}c_iQ_i^{\top}Q_i$.
:::

::: {custom-style="Statement"}
\(i) $\sum_iA_i=I$.
:::

::: {custom-style="Statement"}
\(ii) Let $v_i$ be any lift of record $i$, that is, any vector with $Q_iv_i=Q_iQ_i^{\dagger}o_i$, the projection of $o_i$ onto $\text{range}\,Q_i$. Then
:::

::: {custom-style="Statement Equation"}
$m=\sum_iA_iv_i$ (3.3)
:::

::: {custom-style="Statement"}
and the read does not depend on the choice of lifts.
:::

::: {custom-style="Statement"}
\(iii) Each $A_i$ is self-adjoint in the inner product $\langle x,y\rangle_G=x^{\top}Gy$ and satisfies $0\preceq A_i\preceq I$ there. Equivalently, $A_i$ is similar to the positive semidefinite matrix $G^{-1/2}c_iQ_i^{\top}Q_iG^{-1/2}$, and its eigenvalues lie in $[0,1]$.
:::

::: {custom-style="Statement Tag"}
\(i) V2 check 5; (ii) and (iii) New in Part II.
:::

*Proof.* (i) Sum the definition. (ii) $Q_iQ_i^{\dagger}$ is the orthogonal projector onto $\text{range}\,Q_i$, and $Q_i^{\top}$ vanishes on the orthogonal complement of that range. Hence $Q_i^{\top}o_i=Q_i^{\top}Q_iQ_i^{\dagger}o_i=Q_i^{\top}Q_iv_i$, and $m=G^{-1}\sum_ic_iQ_i^{\top}Q_iv_i=\sum_iA_iv_i$. Adding a vector of $\text{ker}\,Q_i$ to $v_i$ does not change $Q_i^{\top}Q_iv_i$. (iii) $GA_i=c_iQ_i^{\top}Q_i$ is symmetric, which is $G$-self-adjointness. The matrices $B_i=G^{1/2}A_iG^{-1/2}=G^{-1/2}c_iQ_i^{\top}Q_iG^{-1/2}$ are positive semidefinite and sum to $I$, so $0\preceq B_i\preceq I$. $\blacksquare$

With identity maps, $A_i=\alpha_iI$ and (3.3) is the convex read of ADE. In general, the read is a convex combination with operator-valued weights, convex in the geometry of $G$ rather than the Euclidean one.

::: {custom-style="Check"}
*Numerical check.* In {{c.matrix_weights.trials}} random stars, $\sum_iA_i=I$ held to {{c.matrix_weights.sum_to_identity_err|e1}} and (3.3) to {{c.matrix_weights.read_err|e1}}. Adding random kernel components to every lift changed the read by at most {{c.matrix_weights.lift_invariance_err|e1}}. The smallest eigenvalue of any $B_i$ was {{c.matrix_weights.min_eig_symmetrised|e1}}, which is zero to rounding.
:::

## 3.3 Hulls, boxes and recombination

::: {custom-style="Statement"}
**Corollary 3.4** (transported hull and ceiling). If every $Q_i$ is square orthogonal, then $H=I$ and $m=\sum_i\alpha_iv_i$ with $v_i=Q_i^{\top}o_i$. The read lies in the convex hull of the transported records, and for every linear cost $c$, $c(m)\ge\text{min}_i\,c(v_i)$.
:::

::: {custom-style="Statement Tag"}
V2 Corollary 5.2; Mathematics book Corollary 6.1.
:::

::: {custom-style="Check"}
*Numerical check.* In {{c.hulls.orth_cases}} random orthogonal stars, $m-\sum_i\alpha_iv_i$ was at most {{c.hulls.orth_convex_err|e1}}.
:::

::: {custom-style="Statement"}
**Proposition 3.5** (recombination and the coordinatewise ceiling). Let $Q_i=R_i$ select the coordinates $S_i$ of a full design, and let every coordinate have positive coverage $\kappa_j=\sum_{i:\,j\in S_i}\alpha_i$.
:::

::: {custom-style="Statement"}
\(i) $m_j=\kappa_j^{-1}\sum_{i:\,j\in S_i}\alpha_iy_{ij}$. Hence the read lies in the coordinate box spanned by the observed values, but not necessarily in the convex hull of the archived designs.
:::

::: {custom-style="Statement"}
\(ii) For two records with complementary masks $S$ and $S^c$, the read lies outside the segment joining $y_1$ and $y_2$ unless the two records agree on $S$ or on $S^c$.
:::

::: {custom-style="Statement"}
\(iii) For a linear cost $c(x)=\sum_ja_jx_j$, $c(m)\ge\sum_j\text{min}_{i:\,j\in S_i}a_jy_{ij}$. The read can beat the best archived design, but never the best coordinatewise combination of observed values.
:::

::: {custom-style="Statement Tag"}
\(i) V2 Proposition 5.3; (ii) and (iii) New in Part II.
:::

*Proof.* (i) $H$ is diagonal with entries $\kappa_j$, and the normal equations decouple coordinate by coordinate. (ii) A point of the segment is $(1-t)y_1+ty_2$. It agrees with the read on $S$ only if $t\,(y_2-y_1)_S=0$, and on $S^c$ only if $(1-t)(y_1-y_2)_{S^c}=0$. If both differences are nonzero, these force $t=0$ and $t=1$. (iii) By (i), each term $a_jm_j$ is a convex combination of the values $a_jy_{ij}$ with $j\in S_i$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{c.hulls.mask_cases}} random masked stars in $ℝ^4$ ({{c.hulls.mask_skipped}} further stars had a coverage below $10^{-8}$ and were skipped), no read left its coordinate box, and {{c.hulls.outside_hull}} left the archive hull according to a linear-programming test. All {{c.hulls.crossover_outside}} of {{c.hulls.crossover_cases}} complementary pairs read outside their segment. In {{x.coordinate_ceiling.cases}} masked stars with random linear costs, the floor of (iii) was never violated, and the read beat the best archived design in {{x.coordinate_ceiling.beats_best_record}} of them ({{d.beat_rate|pct1}}).
:::

*Engineering meaning.* Coordinate recombination breaks the ceiling of Corollary 3.4: a record contributes its strong subassembly without its weak ones (Figure 1b). This is the mechanism behind hypothesis C2 of V2. It creates candidates, not feasible designs: coupled loads, interfaces and global stability must be re-evaluated [14, Section 5]. Part (iii) bounds the gain, since recombination cannot extrapolate beyond the observed values of each coordinate.

## 3.4 Conditioning

The read is well conditioned when the observation spaces of the retrieved records meet at large angles. Principal angles between subspaces make this exact [3].

::: {custom-style="Statement"}
**Proposition 3.6** (two weighted subspaces). Let $P_1,P_2$ be orthogonal projectors onto subspaces $S_1,S_2\subseteq ℝ^D$ of dimensions $k_1\le k_2$, let $c_1,c_2>0$, and let $\theta_1,\ldots,\theta_{k_1}$ be the principal angles between $S_1$ and $S_2$.
:::

::: {custom-style="Statement"}
\(i) The spectrum of $c_1P_1+c_2P_2$ consists of $c_1+c_2$ once for each zero angle; $c_1$ once for each right angle; $c_2$ with multiplicity $k_2-n_0-n_m$, where $n_0$ counts the zero angles and $n_m$ the angles strictly between $0$ and $\pi/2$; for each $\theta_j\in(0,\pi/2)$ the pair
:::

::: {custom-style="Statement Equation"}
$\tfrac12\Big[(c_1+c_2)\pm\sqrt{(c_1+c_2)^2-4c_1c_2\sin^2\theta_j}\,\Big]$ (3.4)
:::

::: {custom-style="Statement"}
and $0$ for the remaining dimensions.
:::

::: {custom-style="Statement"}
\(ii) Suppose $S_1+S_2=ℝ^D$. Let $\theta_F$ be the smallest nonzero principal angle, or $\pi/2$ if every principal angle is zero, and let $h=2c_1c_2/(c_1+c_2)$. Then
:::

::: {custom-style="Statement Equation"}
$\tfrac12h\sin^2\theta_F\le\lambda_{\text{min}}(c_1P_1+c_2P_2)\le h\sin^2\theta_F$ (3.5)
:::

::: {custom-style="Statement"}
where the upper bound requires $\theta_F<\pi/2$. The constant $\tfrac12$ is sharp as $\theta_F\to 0$.
:::

::: {custom-style="Statement Tag"}
\(i) Classical: the two-subspace decomposition [16] made explicit; (ii) New in Part II.
:::

*Proof.* (i) By Halmos's theorem, $ℝ^D$ splits orthogonally into $S_1\cap S_2$, $S_1\cap S_2^{\perp}$, $S_1^{\perp}\cap S_2$, $S_1^{\perp}\cap S_2^{\perp}$ and a sum of two-dimensional subspaces invariant under both projectors. There is one such subspace for each principal angle in $(0,\pi/2)$, and on it $P_1$ and $P_2$ project onto two lines at that angle [16]. The first four summands contribute $c_1+c_2$, $c_1$, $c_2$ and $0$, with the stated multiplicities: zero angles count $S_1\cap S_2$, right angles count $S_1\cap S_2^{\perp}$ because $k_1\le k_2$, and the rest of $S_2$ lies in $S_1^{\perp}\cap S_2$. On each two-dimensional block the trace is $c_1+c_2$ and the determinant is $c_1c_2\sin^2\theta_j$, which gives (3.4). (ii) The smaller root of (3.4) equals $2c_1c_2\sin^2\theta/[(c_1+c_2)+\sqrt{(c_1+c_2)^2-4c_1c_2\sin^2\theta}\,]$. The denominator lies between $c_1+c_2$ and $2(c_1+c_2)$, so the root lies between $\tfrac12h\sin^2\theta$ and $h\sin^2\theta$, and it increases with $\theta$. Spanning excludes the eigenvalue $0$. The eigenvalues $c_1$, $c_2$ and $c_1+c_2$ are at least $\text{min}(c_1,c_2)\ge\tfrac12h$. Hence the lower bound holds, and the upper bound holds whenever a block exists. As $\theta\to 0$, the denominator tends to $2(c_1+c_2)$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{c.conditioning.angle_trials}} random spanning pairs, {{c.conditioning.interior_angle_trials}} of them with an interior angle, bound (3.5) was never violated. The ratio $\lambda_{\text{min}}/(h\sin^2\theta_F)$ ranged from {{c.conditioning.ratio_min|f7}} to {{c.conditioning.ratio_max|f3}}. In {{x.two_subspace_spectrum.trials}} further pairs with {{x.two_subspace_spectrum.interior_angles}} interior angles, the spectrum (i) matched the computed eigenvalues to {{x.two_subspace_spectrum.max_err|e1}}.
:::

::: {custom-style="Statement"}
**Proposition 3.7** (amplification and coverage). Let $G=\sum_ic_iQ_i^{\top}Q_i\succ 0$ with fixed coefficients $c_i>0$, and let $m=G^{-1}\sum_ic_iQ_i^{\top}o_i$.
:::

::: {custom-style="Statement"}
\(i) The read moves with record $i$'s observation through $\partial m/\partial o_i=G^{-1}c_iQ_i^{\top}$, and $\|G^{-1}c_iQ_i^{\top}\|\le(c_i/\lambda_{\text{min}}(G))^{1/2}$.
:::

::: {custom-style="Statement"}
\(ii) For coordinate masks with $c_i=\alpha_i$, $\lambda_{\text{min}}(H)=\text{min}_j\,\kappa_j$.
:::

::: {custom-style="Statement"}
\(iii) For two lines in the plane with unit normals at an angle $\theta$ and $c_1=c_2=1$, a unit move of $o_1$ moves the read by exactly $1/\sin\theta$.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* (i) Write $X=G^{-1}c_iQ_i^{\top}$. Then $XX^{\top}=c_i\,G^{-1}(c_iQ_i^{\top}Q_i)G^{-1}\preceq c_i\,G^{-1}GG^{-1}=c_iG^{-1}$, because $c_iQ_i^{\top}Q_i\preceq G$ and congruence preserves order. Hence $\|X\|^2\le c_i/\lambda_{\text{min}}(G)$. (ii) $H$ is diagonal with entries $\kappa_j$. (iii) Take $n_1=e_1$ and $n_2=(\cos\theta,\sin\theta)$. Then $G^{-1}n_1=(1,-\cot\theta)$, whose norm is $1/\sin\theta$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{c.conditioning.amplification_trials}} random stars, (i) held for every record, with largest ratio {{c.conditioning.amplification_worst|f4}}. In {{c.conditioning.coverage_cases}} masked stars, $\lambda_{\text{min}}(H)$ equalled the smallest coverage to {{c.conditioning.coverage_err|g3}}. For two lines at $\theta=\pi/2,\pi/4,\pi/8,\pi/16$ and $\pi/32$, the displacement was {{c.conditioning.two_lines.0.displacement|f3}}, {{c.conditioning.two_lines.1.displacement|f3}}, {{c.conditioning.two_lines.2.displacement|f3}}, {{c.conditioning.two_lines.3.displacement|f3}} and {{c.conditioning.two_lines.4.displacement|f3}}, against the bound (i) of {{c.conditioning.two_lines.0.bound|f3}}, {{c.conditioning.two_lines.1.bound|f3}}, {{c.conditioning.two_lines.2.bound|f3}}, {{c.conditioning.two_lines.3.bound|f3}} and {{c.conditioning.two_lines.4.bound|f3}} (Figure 1c).
:::

*Engineering meaning.* Nearly parallel observation spaces make the read hypersensitive. Two gauges that measure almost the same combination of member forces locate the design poorly in the orthogonal direction. Coverage is the masked form of the same effect. A layer therefore reports $\lambda_{\text{min}}(H)$, or the smallest coverage, with every read, and a small value triggers the conditioning control of V2: enlarge the star, add a declared prior, or retain the token's value.

## 3.5 Residual and soft energy

::: {custom-style="Statement"}
**Proposition 3.8** (residual at the read). If $H\succ 0$, then $\sum_i\alpha_i\|Q_im-o_i\|^2=\sum_i\alpha_i\|o_i\|^2-b^{\top}H^{-1}b$. For square orthogonal maps, this equals $\text{tr}\,C$ with $C=\sum_i\alpha_i(v_i-m)(v_i-m)^{\top}$, the weighted spread of the transported records.
:::

::: {custom-style="Statement Tag"}
Classical least squares; the trace form is its orthogonal case.
:::

::: {custom-style="Check"}
*Numerical check.* In {{c.residual_trace.cases}} random orthogonal stars, the residual and $\text{tr}\,C$ agreed to {{c.residual_trace.max_err|e1}}.
:::

The read is also a step on an energy. With query-independent weights $w_i$ on a region where the star and maps are fixed, V2 defines the soft discrepancy energy

::: {custom-style="Equation"}
$E_s(z)=-s^2\log\sum_iw_i\exp(-e_i(z)/s^2)$ (3.6)
:::

::: {custom-style="Statement"}
**Proposition 3.9** (gradient and Hessian of the soft energy). Let $g_i=Q_i^{\top}(Q_iz-o_i)$, the gradient of $e_i$, and let $c_A=\text{max}_i\,\lambda_{\text{max}}(Q_i^{\top}Q_i)$. Then
:::

::: {custom-style="Statement Equation"}
$\nabla E_s(z)=H\,(z-m),\qquad \nabla^2E_s(z)=H-s^{-2}\,\text{Cov}_\alpha(g)\preceq H\preceq c_AI$ (3.7)
:::

::: {custom-style="Statement"}
where $\text{Cov}_\alpha(g)=\sum_i\alpha_i(g_i-\langle g\rangle)(g_i-\langle g\rangle)^{\top}$. The gradient identity holds with the retention read when $H$ is singular.
:::

::: {custom-style="Statement Tag"}
Gradient: V2 Proposition 6.1; Hessian: New in Part II.
:::

*Proof.* $\nabla E_s=\sum_i\alpha_ig_i=Hz-b$, and $b=Hm$ by Proposition 3.2. Differentiating again, $\nabla g_i=Q_i^{\top}Q_i$ and $\nabla\alpha_i=-s^{-2}\alpha_i(g_i-\langle g\rangle)$, so $\nabla^2E_s=H-s^{-2}\sum_i\alpha_i(g_i-\langle g\rangle)g_i^{\top}$, which is the stated covariance form. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{c.gradient_tweedie.gradient_cases}} random stars, central differences matched the gradient to a relative {{c.gradient_tweedie.gradient_rel_err|e1}}. In {{x.hessian_and_step.trials}} stars, finite differences of the gradient matched the Hessian to a relative {{x.hessian_and_step.hessian_rel_err|e1}}.
:::

## 3.6 Sheaf mean shift

::: {custom-style="Statement"}
**Theorem 3.10** (sheaf attention is a majorise–minimise step). Fix $z$, and compute $\alpha$, $H$, $b$ and the read $m$ at $z$.
:::

::: {custom-style="Statement"}
\(i) For every $\lambda\in[0,2]$,
:::

::: {custom-style="Statement Equation"}
$E_s(z+\lambda(m-z))\le E_s(z)-\tfrac12\lambda(2-\lambda)\,\|z-m\|_H^2$ (3.8)
:::

::: {custom-style="Statement"}
with $\|x\|_H^2=x^{\top}Hx$, and with equality for every $\lambda$ when the star has a single record.
:::

::: {custom-style="Statement"}
\(ii) $m=z$ if and only if $\nabla E_s(z)=0$, also when $H$ is singular.
:::

::: {custom-style="Statement"}
\(iii) Let $z_{t+1}=z_t+\lambda_t(m(z_t)-z_t)$ with $\epsilon\le\lambda_t\le 2-\epsilon$ for some $\epsilon>0$. Then $E_s(z_t)$ is non-increasing, $\sum_t\|z_t-m(z_t)\|_{H(z_t)}^2<\infty$, and $\nabla E_s(z_t)\to 0$.
:::

::: {custom-style="Statement Tag"}
New in Part II; an instance of the majorise–minimise principle [21]. For identity maps and $\lambda=1$ it is the bound-optimisation and EM view of Gaussian mean shift [5, 6, 8, 11] and the concave–convex view of modern Hopfield retrieval [23, 26].
:::

*Proof.* (i) The function $F(e)=-s^2\log\sum_iw_ie^{-e_i/s^2}$ is concave on $ℝ^n$, being $-s^2$ times a log-sum-exp of affine functions of $e$, and $\partial F/\partial e_i=\alpha_i$. The tangent inequality at $e(z)$ gives $F(e')\le F(e(z))+\sum_i\alpha_i(e'_i-e_i(z))$. Putting $e'=e(x)$ yields $E_s(x)\le E_s(z)+M(x)-M(z)$ with the frozen quadratic $M$ of Proposition 3.2. Since $m$ minimises $M$, $M(x)-M(m)=\tfrac12\|x-m\|_H^2$ for every $x$. For $x=z+\lambda(m-z)$ we have $x-m=(1-\lambda)(z-m)$, so $M(x)-M(z)=-\tfrac12\lambda(2-\lambda)\|z-m\|_H^2$. With one record, $F$ is affine and the tangent inequality is an equality. (ii) $\nabla E_s(z)=Hz-b$. If $m=z$, then $Hz=Hm=b$. Conversely, if $Hz=b$, then $m=z+H^{\dagger}\cdot 0=z$. (iii) Each $e_i\ge 0$, so $E_s\ge -s^2\log\sum_iw_i$ is bounded below. Summing (3.8), and using $\tfrac12\lambda_t(2-\lambda_t)\ge\tfrac12\epsilon(2-\epsilon)$, gives the finite sum. Finally, $\|\nabla E_s(z_t)\|^2=\|H_t(z_t-m_t)\|^2\le\|H_t\|\,\|z_t-m_t\|_{H_t}^2\le c_A\|z_t-m_t\|_{H_t}^2\to 0$. $\blacksquare$

The theorem guarantees descent, not convergence of the iterates. Convergence of Gaussian mean-shift iterates needs further conditions even for identity maps [5]. The interval $[0,2]$ cannot be enlarged in general: for a single record (3.8) is an equality, and the energy rises for every $\lambda>2$. Over-relaxed steps with $1<\lambda<2$ remain guaranteed descent steps.

::: {custom-style="Check"}
*Numerical check.* In {{c.mm.trials}} random stars drawn equally from the four map classes, with random $\lambda\in(0,2)$, inequality (3.8) was never violated. The smallest ratio of actual to guaranteed decrease was {{c.mm.worst_ratio|f12}}, so the bound is attained to rounding. For $\lambda\in(2.05,3)$, the energy rose in {{c.mm.over_two_increases}} of {{c.mm.over_two_trials}} trials ({{d.over_two_rate|pct0}}). In {{c.mm.runs}} runs of 400 read iterations, every energy sequence was non-increasing, the largest final gradient was {{c.mm.max_final_grad|e1}}, and {{c.mm.runs_singular}} runs ended at a singular $H$, where the retention read applied.
:::

![**Figure 2.** Sheaf mean shift in the plane with two full records (dots) and three partial records, each observing one linear combination (lines), at $s=0.6$. (a) Contours of the soft energy and the read iteration from four starts. The stars are the three local minima. (b) The soft energy along the relaxed iteration from one start. It decreases monotonically for $\lambda=0.5$, $1$ and $1.5$, as Theorem 3.10 guarantees. At $\lambda=2.4$ it rises in 10 of 25 steps and never settles.](fig/meanshift.png){width=100%}

ADE is the special case with identity maps. The next statement restates the exact reduction of V2 in the present notation, so that Theorem 3.10 can be applied to it.

::: {custom-style="Statement"}
**Proposition 3.11** (ADE is the identity star). Take identity maps, the ADE archive weights, $s_t^2=(1-a_t)/a_t$ and $q_t=\sqrt{a_t}\,z_t$. With $0\le\eta\le 1$,
:::

::: {custom-style="Statement Equation"}
$\sigma_t^2=\eta^2\frac{1-a_{t-1}}{1-a_t}\Big(1-\frac{a_t}{a_{t-1}}\Big),\quad A_t=\sqrt{\frac{1-a_{t-1}-\sigma_t^2}{1-a_t}},\quad \lambda_t=1-A_t\sqrt{\frac{a_t}{a_{t-1}}}$ (3.9)
:::

::: {custom-style="Statement"}
the ADE update $q_{t-1}=A_tq_t+B_tm_t+\sigma_t\xi_t$, with $B_t=\sqrt{a_{t-1}}-A_t\sqrt{a_t}$, equals $z_{t-1}=(1-\lambda_t)z_t+\lambda_tm_t(z_t)+\sigma_t\xi_t/\sqrt{a_{t-1}}$ in the scaled coordinate.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 6.2.
:::

::: {custom-style="Check"}
*Numerical check.* In {{c.ade_recovery.cases}} random archives and schedules, the two updates agreed to {{c.ade_recovery.max_err|e1}}.
:::

::: {custom-style="Statement"}
**Corollary 3.12** (every deterministic ADE layer descends at its own scale). Let $\eta=0$ and $0<a_t<a_{t-1}\le 1$. Then $\lambda_t=1-\sqrt{a_t(1-a_{t-1})/(a_{t-1}(1-a_t))}$ satisfies $0<\lambda_t\le 1$, and the deterministic ADE layer satisfies
:::

::: {custom-style="Statement Equation"}
$E_{s_t}(z_{t-1})\le E_{s_t}(z_t)-\tfrac12\lambda_t(2-\lambda_t)\,\|z_t-m_t(z_t)\|^2$ (3.10)
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* With $\sigma_t=0$, the formula for $\lambda_t$ follows from (3.9). The ratio under the root is nonnegative, and it is below 1 exactly when $a_t<a_{t-1}$. Apply Theorem 3.10 with identity maps, for which $H=I$. $\blacksquare$

The scale changes from layer to layer, so (3.10) compares two points on one energy and not energies of different layers. An ADE stack is a sequence of guaranteed-descent steps on a sequence of annealed energies.

::: {custom-style="Check"}
*Numerical check.* On the 16-layer cosine schedule with the bottom cut off at $a_{16}=10^{-4}$, the coefficients $\lambda_t$ ranged from {{x.ade_descent.lambda_min|f4}} to {{x.ade_descent.lambda_max|f4}}. Along deterministic trajectories in {{x.ade_descent.archives}} random archives ({{x.ade_descent.steps}} layer steps), (3.10) was never violated, and the smallest ratio of actual to guaranteed decrease was {{x.ade_descent.worst_ratio|f12}}.
:::

::: {custom-style="Statement"}
**Proposition 3.13** (the Euclidean energy step). For $0\le\lambda\le 2/c_A$,
:::

::: {custom-style="Statement Equation"}
$E_s(z-\lambda\nabla E_s(z))\le E_s(z)-\lambda(1-\tfrac12\lambda c_A)\|\nabla E_s(z)\|^2$ (3.11)
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* By (3.7), $\nabla^2E_s\preceq c_AI$ everywhere. Taylor's formula with integral remainder along the segment gives $E_s(z+d)\le E_s(z)+\nabla E_s(z)^{\top}d+\tfrac12c_A\|d\|^2$. Put $d=-\lambda\nabla E_s(z)$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{x.hessian_and_step.trials}} random stars with random $\lambda\in(0,2/c_A)$, inequality (3.11) was never violated; the smallest ratio of actual to guaranteed decrease was {{x.hessian_and_step.step_worst_ratio|f5}}.
:::

Table 3 collects the three updates of V2 and the guarantee that this section proves for each.

Table: **Table 3.** Layer updates and their guarantees. The noise term is omitted.

| Update | Formula | Interpretation | Guarantee |
|:----------------|:------------------|:-------------------|:-------------------|
| orthogonal transport | $z'=(1-\lambda)z+\lambda m$ | gradient step $z-\lambda\nabla E_s$, since $H=I$ | descent for $0<\lambda<2$ (Theorem 3.10) |
| harmonic interpolation | $z'=(1-\lambda)z+\lambda m$ | preconditioned step $z-\lambda H^{-1}\nabla E_s$ | descent for $0<\lambda<2$ (Theorem 3.10) |
| Euclidean energy step | $z'=z-\lambda H(z-m)$ | gradient step $z-\lambda\nabla E_s$ | descent for $0<\lambda<2/c_A$ (Proposition 3.13) |
