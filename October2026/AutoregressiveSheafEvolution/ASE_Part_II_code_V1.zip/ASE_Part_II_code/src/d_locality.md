
# 5 Scale, locality and covers

A layer at scale $s$ should touch only the records near the token. Two questions follow. How much does truncating the read to a star change it? And how sensitive is the read to the token itself? This section answers both, and states the index contract the answers need.

## 5.1 Truncation

::: {custom-style="Statement"}
**Proposition 5.1** (truncating a transported read). In one token frame with transported values $v_i$, weights $w_i$ and scale $s$, let $S=\{i:\|z-v_i\|\le\rho\}$ be a nonempty star with complement $F$. Let $D_S=\sum_{i\in S}w_i\exp(-\|z-v_i\|^2/2s^2)$ and $D_F$ be the star and far kernel masses, $W_S$ the star weight, $W$ the total archive weight and $R$ the diameter of the transported archive. Then the full read $m$ and the star read $m_S$ satisfy
:::

::: {custom-style="Statement Equation"}
$\|m-m_S\|\le R\,\frac{D_F}{D_S+D_F}\le R\,\text{min}\Big\{1,\ \frac{W-W_S}{D_S}\,e^{-\rho^2/2s^2}\Big\}$ (5.1)
:::

::: {custom-style="Statement"}
The right-hand side is computable from the star and the running total $W$, without visiting the far field.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 12.1; the a posteriori form is New in Part II.
:::

*Proof.* The full read splits as $m=(D_Sm_S+D_Fm_F)/(D_S+D_F)$, so $m-m_S=D_F(m_F-m_S)/(D_S+D_F)$, and both conditional reads lie in the transported hull. Every far kernel is at most $w_ie^{-\rho^2/2s^2}$, so $D_F\le(W-W_S)e^{-\rho^2/2s^2}$, and $D_F/(D_S+D_F)\le\text{min}\{1,D_F/D_S\}$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* An archive of {{c.truncation.records}} records drawn uniformly in $[0,10]^2$ with weights in $[0.5,1.5]$ has diameter $R={{c.truncation.diameter|f2}}$. For $s=0.1$, $0.3$ and $1$, $\rho=2s$, $3s$ and $4s$, and 60 random queries each, neither bound in (5.1) was violated ({{c.truncation.violations}} and {{c.truncation.certificate_violations}} violations). Table 4 lists the details.
:::

Table: **Table 4.** Truncating a transported read: 400 records in $[0,10]^2$, 60 queries per row. The last two columns give the largest ratio of the true error to the first bound in (5.1), and the median certificate as a fraction of $R$, where 1 means the certificate is vacuous.

| $s$ | $\rho/s$ | star share | largest error / bound | median certificate / $R$ |
|:--|:--|:--|:--|:--|
{{trunc_rows}}

::: {custom-style="Statement"}
**Corollary 5.2** (certified radius). For a tolerance $\eta>0$, grow the star until the right-hand side of (5.1) is at most $\eta R$. The radius reached certifies $\|m-m_S\|\le\eta R$ at that query, before any far record is read.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

::: {custom-style="Check"}
*Numerical check.* At $\eta=10^{-3}$, on a grid of radii from $s$ to $8s$ in steps of $s/4$, the median certified radius was {{c.truncation.certified.0.median_c|f3}}$s$, {{c.truncation.certified.1.median_c|f2}}$s$ and {{c.truncation.certified.2.median_c|f2}}$s$ at $s=0.1$, $0.3$ and $1$. The mean star shares were {{c.truncation.certified.0.mean_share|pct1}}, {{c.truncation.certified.1.mean_share|pct1}} and {{c.truncation.certified.2.mean_share|pct1}}, and every certified read was within $\eta R$ of the full read.
:::

![**Figure 4.** Truncation in an archive of 400 records drawn as in the check, recomputed for the figure with its own seed. (a) Median certificate (solid) and median true error (dotted), relative to the archive diameter, against the star radius for three scales. The certificate is conservative by several orders of magnitude, and no query's error exceeded its own certificate. (b) Mean share of the archive in the star, on a logarithmic scale; dots mark the median certified radius at $\eta=10^{-3}$.](fig/locality.png){width=100%}

The a priori radius $3s$ of hypothesis C5 [14, Section 18] is not certified at $\eta=10^{-3}$ in this archive. At $3s$, the median certificate is still vacuous for $s=0.1$ and $s=0.3$, although the true error was at most {{c.truncation.rows.1.max_ratio|f3}} of the first bound. The certificate is conservative because it charges every far record with the kernel at the boundary and every far read with the full diameter. Locality pays most at small scales, in the upper layers, where the certified star holds about 1% of the archive. It pays least at large scales, in the lower layers, where it holds over 40%.

::: {custom-style="Statement"}
**Theorem 5.3** (truncating a rectangular read). Let $S=\{i:e_i(z)\le\rho^2/2\}$ be nonempty, and let $H_S$, $b_S$ and $m_S$ be the normal matrix, right side and read of the star with renormalised weights. Suppose $H\succ 0$ and $H_S\succ 0$.
:::

::: {custom-style="Statement"}
\(i) $\|m-m_S\|\le(\|b-b_S\|+\|H-H_S\|\,\|m_S\|)/\lambda_{\text{min}}(H)$.
:::

::: {custom-style="Statement"}
\(ii) Let $D_S=\sum_{i\in S}w_ie^{-e_i(z)/s^2}$ and $\Phi_S=\text{min}\{1,(W-W_S)e^{-\rho^2/2s^2}/D_S\}$. Take archive constants $c_H\ge\text{max}_{i,j}\|Q_i^{\top}Q_i-Q_j^{\top}Q_j\|$ and $R_b\ge\text{diam}\{Q_i^{\top}o_i\}$. If $\lambda_{\text{min}}(H_S)>\Phi_Sc_H$, then
:::

::: {custom-style="Statement Equation"}
$\|m-m_S\|\le\frac{\Phi_S\,(R_b+c_H\|m_S\|)}{\lambda_{\text{min}}(H_S)-\Phi_Sc_H}$ (5.2)
:::

::: {custom-style="Statement"}
For square orthogonal maps, $c_H=0$ and $H_S=I$, and (5.2) reduces to (5.1).
:::

::: {custom-style="Statement Tag"}
\(i) V2 Section 12; (ii) New in Part II.
:::

*Proof.* (i) $H(m-m_S)=(b-b_S)-(H-H_S)m_S$. (ii) Let $F=D_F/(D_S+D_F)$ be the far posterior mass; as in Proposition 5.1, $F\le\Phi_S$. With the far conditional quantities $H_F$ and $b_F$, we have $H=(1-F)H_S+FH_F$ and $b=(1-F)b_S+Fb_F$, so $H-H_S=F(H_F-H_S)$ and $b-b_S=F(b_F-b_S)$. The matrix $H_F-H_S$ is the difference of two convex combinations of the $Q_i^{\top}Q_i$, so its norm is at most $c_H$; likewise $\|b_F-b_S\|\le R_b$. Weyl's inequality gives $\lambda_{\text{min}}(H)\ge\lambda_{\text{min}}(H_S)-Fc_H$ [19]. Substitute into (i). The resulting bound increases with $F$, so $F$ may be replaced by $\Phi_S$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* For (i), {{c.rect_truncation.trials}} stars of 30 records were truncated to their 12 heaviest records: there were {{c.rect_truncation.violations}} violations, and the largest ratio was {{c.rect_truncation.worst_ratio|f3}}. For (ii), two families of 16 archives of 300 records in $[0,10]^D$, $D=2$ to $4$, with full-rank or mixed-rank random maps, were queried 8 times each at $s=0.5$, $1$ and $2$ with $\rho=2s$ to $6s$. Of {{d.rc_tests}} tests, {{d.rc_finite}} certificates were finite and {{d.rc_vacuous}} vacuous, and no finite certificate was violated. The largest ratio of error to certificate was {{d.rc_worst|f3}}. At $s=0.5$ and $\rho=5s$, the star held on average {{d.rc_full_05_5.mean_share|pct0}} (full rank) and {{d.rc_mixed_05_5.mean_share|pct0}} (mixed rank) of the archive, and the median certificates were {{d.rc_full_05_5.median_cert_over_Rb|e1}} $R_b$ and {{d.rc_mixed_05_5.median_cert_over_Rb|e1}} $R_b$.
:::

Rectangular archives are less local than transported ones. A record whose map has a weak direction is near every token along that direction, so stars are larger at the same $\rho/s$. The certificate also needs the margin $\lambda_{\text{min}}(H_S)>\Phi_Sc_H$, which small stars rarely provide.

## 5.2 Sensitivity of the read

The Jacobian of the read controls how errors in one layer propagate to the next, which is the subject of Part III. For identity maps it is a covariance [13, Proposition 6.2]. For general maps it is a covariance between residuals and gradients, preconditioned by $H$.

::: {custom-style="Statement"}
**Proposition 5.4** (the Jacobian of sheaf attention). Let $H\succ 0$, and put $g_i=Q_i^{\top}(Q_iz-o_i)$ and $u_i=Q_i^{\top}(Q_im-o_i)$.
:::

::: {custom-style="Statement"}
\(i) $\sum_i\alpha_iu_i=0$, and
:::

::: {custom-style="Statement Equation"}
$Dm(z)=s^{-2}H^{-1}\sum_i\alpha_i\,u_i\,(g_i-\langle g\rangle)^{\top}$ (5.3)
:::

::: {custom-style="Statement"}
\(ii) For square orthogonal maps, $Dm=s^{-2}C$, with $C$ the weighted covariance of the transported records.
:::

::: {custom-style="Statement"}
\(iii) At a stationary point, $Dm=s^{-2}H^{-1}C_u$, with $C_u=\sum_i\alpha_iu_iu_i^{\top}$.
:::

::: {custom-style="Statement"}
\(iv) $\|Dm\|\le\|\text{Cov}_\alpha(u)\|^{1/2}\,\|\text{Cov}_\alpha(g)\|^{1/2}/(s^2\lambda_{\text{min}}(H))\le\text{diam}\{u_i\}\,\text{diam}\{g_i\}/(4s^2\lambda_{\text{min}}(H))$. The first inequality is an equality for square orthogonal maps.
:::

::: {custom-style="Statement Tag"}
\(ii) Mathematics book Proposition 6.2, in the scaled coordinate; (i), (iii) and (iv) New in Part II.
:::

*Proof.* (i) $\sum_i\alpha_iu_i=Hm-b=0$. Differentiate $m=H^{-1}b$ with $\nabla\alpha_i=-s^{-2}\alpha_i(g_i-\langle g\rangle)$: $dm=H^{-1}(db-dH\,m)=-H^{-1}\sum_id\alpha_i\,u_i$, which is (5.3). (ii) Here $H=I$ and $u_i=m-v_i=g_i-\langle g\rangle$. (iii) At $z=m$ we have $g_i=u_i$ and $\langle g\rangle=0$. (iv) For unit vectors $x$ and $y$, the Cauchy–Schwarz inequality gives $|\sum_i\alpha_i(x^{\top}u_i)((g_i-\langle g\rangle)^{\top}y)|\le(x^{\top}\text{Cov}_\alpha(u)\,x)^{1/2}(y^{\top}\text{Cov}_\alpha(g)\,y)^{1/2}$, using (i) for the first factor. The variance of a law on an interval of length $\ell$ is at most $\ell^2/4$ [2], which gives the second inequality. For square orthogonal maps, $Dm=s^{-2}C\succeq 0$, and both covariances equal $C$. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* In {{c.jacobian.cases}} random stars ({{c.jacobian.excluded_ill_conditioned}} with condition number above $10^6$ were excluded), central differences matched (5.3) to {{c.jacobian.fd_rel_err|e1}} at worst and {{c.jacobian.fd_rel_err_median|e1}} in the median. Part (ii) held to {{c.jacobian.orth_err|e1}} in {{c.jacobian.orth_cases}} orthogonal stars, and (iii) to {{c.jacobian.stationary_err|e1}} at {{c.jacobian.stationary_cases}} stationary points. In {{x.jacobian_bound.cases}} further stars, neither inequality of (iv) was violated. The ratio of $\|Dm\|$ to the first bound was 1 to within $10^{-15}$ on all {{x.jacobian_bound.orth_cases}} orthogonal stars, and $\sum_i\alpha_iu_i$ vanished to {{x.jacobian_bound.centring_err|e1}}.
:::

::: {custom-style="Statement"}
**Corollary 5.5** (minima attract, saddles repel). Let $\zeta$ be a stationary point of $E_s$ with $H\succ 0$. Then $Dm(\zeta)=I-H^{-1}\nabla^2E_s(\zeta)$, and its eigenvalues are real and nonnegative. If $\nabla^2E_s(\zeta)\succ 0$, every eigenvalue $\mu$ satisfies $0\le\mu<1$, and the read iteration converges linearly near $\zeta$. If $\nabla^2E_s(\zeta)$ has a negative eigenvalue, then $Dm(\zeta)$ has an eigenvalue greater than $1$, and $\zeta$ repels the iteration.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

*Proof.* At $\zeta$, $\text{Cov}_\alpha(g)=C_u$, so (3.7) gives $\nabla^2E_s=H-s^{-2}C_u$, and Proposition 5.4(iii) gives $Dm=s^{-2}H^{-1}C_u=I-H^{-1}\nabla^2E_s$. This matrix is similar to $K=s^{-2}H^{-1/2}C_uH^{-1/2}\succeq 0$, so its eigenvalues are real and nonnegative. Moreover $I-K=H^{-1/2}\nabla^2E_sH^{-1/2}$ is congruent to $\nabla^2E_s$ and has the same inertia [19]. If $\nabla^2E_s\succ 0$, every eigenvalue of $K$ is below 1. If $\nabla^2E_s$ has a negative eigenvalue, $K$ has an eigenvalue above 1. $\blacksquare$

::: {custom-style="Check"}
*Numerical check.* At {{x.stationary.minima}} minima reached by 3,000 read iterations from random starts, the identity held to {{x.stationary.identity_err|e1}}, and the largest spectral radius of $Dm$ was {{x.stationary.spectral_radius_max|f3}}. At the saddle formed by two records observing $x_1=\pm1$ and one observing $x_2=0.5$, the leading eigenvalue was {{x.stationary.saddles.0.leading_eigenvalue|f4}} at $s=0.5$ and {{x.stationary.saddles.1.leading_eigenvalue|f4}} at $s=0.8$, which is $1/s^2$ in both cases.
:::

*Engineering meaning.* Near a stationary point, the read iteration is a quasi-Newton method whose Hessian model is $H$. It is fast where the records agree, because the residual spread $C_u$ is small. It is slow where they disagree, and it is repelled at saddles between modes. The relaxed step of Theorem 3.10 changes the local rate to $1-\lambda(1-\mu)$ for each eigenvalue $\mu$ of $Dm$. Over-relaxation with $\lambda>1$ therefore accelerates convergence when the eigenvalues of $Dm$ cluster near 1, which is the slow case.

## 5.3 Cost and index contracts

Table 2 gives the cost of one read. The certificates add $O(n)$ operations for a transported read, plus one smallest-eigenvalue computation, $O(D^3)$, for a rectangular read. They also impose an index contract (Table 5). The star must contain every record with $e_i(z)\le\rho^2/2$. For records that share a map $Q$, this is a range query of radius $\rho$ around $Qz$ in that map's observation space, so each chart needs its own index. Masked records need one index per mask pattern, built on the observed coordinates. An approximate nearest-neighbour index voids both certificates, unless its miss probability is accounted for separately.

Table: **Table 5.** The index contract of a certified read.

| Ingredient | Requirement | Used by |
|:----------------|:-----------------------------|:----------------|
| star | every record with $e_i(z)\le\rho^2/2$, by a complete range query per chart | (5.1), (5.2) |
| total weight $W$ | running sum over the archive, versioned with it | (5.1), (5.2) |
| constants $c_H$, $R_b$ | running maxima; they never decrease when records are appended | (5.2) |
| scale and radius | $s$ and $\rho/s$ stored with every read | reproducibility |
| map versions | stored per record and frozen for the token | all reads |
