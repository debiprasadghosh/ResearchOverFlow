---
title: "The Horizontal Layer"
subtitle: "One layer of Autoregressive Sheaf Evolution. Part II: sheaf attention, Gaussian stalks, locality and the topology of design spaces"
author:
  - "Debi Prasad Ghosh"
  - "Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India"
date: "Defensible Intelligence series · Autoregressive Sheaf Evolution, Part II · 18 October 2026 · “Respect science. Import emotion.”"
abstract: |
  Part I of Autoregressive Sheaf Evolution (ASE) fixed the two axes of a layer stack: sheaves on covers within a layer, and representations of the layer order across layers. This paper, Part II of the book, works out a single layer. A token reads an archive through an observation star. Each record is seen through an edge map, and the read is the harmonic extension of the observations to the token; we call this read sheaf attention. The read is a matrix-weighted combination of lifted records, and its weights are self-adjoint in the normal-matrix geometry and sum to the identity. When the normal matrix is singular, the read keeps the token's own value in the unresolved directions and is the nearest minimiser of the star energy. Under coordinate masks the read leaves the archive hull and can beat the best archived design on a linear cost, but never the best coordinatewise combination. For two observation spaces, principal angles determine its conditioning exactly; for coordinate masks, coverage does. The central new result is that sheaf attention is a majorise–minimise step. Every relaxed step $z+\lambda(m-z)$ with $0\le\lambda\le 2$ lowers the soft discrepancy energy by at least $\tfrac12\lambda(2-\lambda)\|z-m\|_H^2$, fixed points are exactly stationary points, and every deterministic ADE layer is such a step at its own scale. In a stalk, Tweedie's identity holds in preconditioned form. One imputation is a gradient step, and repeated imputation converges to the harmonic read. Mixtures of partial records are improper, while products are proper exactly under coverage. Selection tilting collapses coverage. Bounded measurement error moves the weights by at most $\tanh(\beta\varepsilon/2)$ in total variation, and this bound is sharp. For locality we give a posteriori truncation certificates for scalar and rectangular reads, an exact Jacobian with a covariance bound, and the classification of stationary points as attracting minima and repelling saddles. For topology we prove four results. Shared reads land in the gap between branches. Local angle reads jump only at antipodes. Nearest-image reads approximate orbit reads for any finite symmetry group, with an explicit bound. An index on canonical representatives is exact for reflection groups, but every continuous canonicalisation fails for sign and mirror symmetries with two or more antisymmetric directions. Thirty-four numerical checks, and an immutable C# kernel that matches an independent NumPy implementation, support every quantitative statement.
---

# 1 Introduction

Autoregressive Diffusion Evolution (ADE) reads an archive of evaluated designs through a Gaussian kernel at every layer of a denoising stack [12, 13]. Autoregressive Sheaf Evolution (ASE) replaces the single Euclidean retrieval geometry of ADE by local data spaces, compatibility maps and scale-dependent covers [14]. Part I made the organising principle precise: each layer is horizontally topological, and each token's journey through the layers is vertically algebraic [15]. It also separated four bases that are easily confused. One of them is the observation star, a token vertex joined to one leaf per retrieved record [15, Definition 2.4(d)]. This paper, Part II of the book, studies what happens on that star. It covers chapters 3 to 6 of the book plan: sheaf attention, Gaussian models in a stalk, scale locality and covers, and the topology of design spaces [14, Section 21].

A layer does one thing to a token. It reads records through maps and moves towards the read. With record observations $o_i=R_iy_i$, token-side edge maps $Q_i$, prior weights $w_i$ and scale $s$, the read is

::: {custom-style="Equation"}
$e_i(z)=\tfrac12\|Q_iz-o_i\|^2,\quad \alpha_i\propto w_i\,e^{-e_i(z)/s^2},\quad H=\sum_i\alpha_iQ_i^{\top}Q_i,\quad b=\sum_i\alpha_iQ_i^{\top}o_i,\quad m=H^{-1}b$ (1.1)
:::

when $H$ is invertible. With identity maps, (1.1) is the ADE read and also biased softmax attention [13, Proposition 5.1; 24]. With general maps, it is the harmonic extension of the observations from the leaves of the star to the token [14, Proposition 5.1]. We call (1.1), with the retention rule of Definition 2.2 for singular $H$, *sheaf attention*. Barbero and co-authors used the phrase earlier for a graph neural network layer that learns attention coefficients on a cellular sheaf [1, 4]. Ours is a different object: a read on an observation star, with fixed maps and weights computed from discrepancies.

![**Figure 1.** (a) The observation star of one token. Each edge carries an edge stalk $ℝ^{k_i}$, reached from the token by $Q_i$ and from the record by $R_i$. (b) Two records with complementary coordinate masks: the read takes $x_1$ from the first and $x_2$ from the second, and lands outside the archive hull. On the cost $-x_1-x_2$ both records score $-1.1$ and the read scores $-2.0$ (Proposition 3.5). (c) Two records whose observation spaces are lines at an angle $\theta$. A unit move of one observation moves the read by exactly $1/\sin\theta$, below the general bound of Proposition 3.7.](fig/star.png){width=100%}

## 1.1 Contributions

- **Sheaf attention as an operator (Section 3).** We give the Schur-complement form of the harmonic extension (Proposition 3.1) and the retention read for singular normal matrices (Proposition 3.2). Matrix weights are invariant under lifts and self-adjoint in the $H$-geometry (Proposition 3.3). We prove hulls, coordinate boxes, a crossover property and a coordinatewise ceiling (Corollary 3.4, Proposition 3.5), and the exact spectrum of two weighted projectors with two-sided conditioning bounds (Proposition 3.6). The central result is the majorise–minimise theorem (Theorem 3.10). It gives guaranteed descent for every relaxation $0\le\lambda\le 2$, and every deterministic ADE layer descends at its own scale (Corollary 3.12).
- **Gaussian stalks (Section 4).** Tweedie's identity holds in preconditioned form (Proposition 4.1). The chart posterior of the mathematics book and sheaf attention differ exactly off the chart (Proposition 4.2). Mixtures of partial records are improper, while products of experts are proper exactly under coverage (Proposition 4.3). One imputation is a gradient step, and repeated imputation is Cimmino's method converging to the harmonic read (Proposition 4.4). Selection tilting collapses coverage (Proposition 4.6). Bounded measurement error has a sharp $\tanh$ bound (Theorem 4.8).
- **Locality (Section 5).** We give a posteriori truncation certificates for transported reads, with certified radii, and for rectangular reads (Proposition 5.1, Corollary 5.2, Theorem 5.3). The Jacobian of the read is exact and has a covariance bound (Proposition 5.4). Stationary points are classified into attracting minima and repelling saddles (Corollary 5.5). Section 5.3 states the cost and index contracts that the certificates need.
- **Topology (Section 6).** Shared reads land in the gap between branches (Proposition 6.2). Local angle reads jump only at antipodes, by an exponentially small amount (Proposition 6.5). Nearest-image reads approximate all-image reads for every finite orthogonal group (Theorem 6.6), and projector reads are stable under measurement error (Proposition 6.8). Orbit indexes are exact for reflection groups, and every continuous canonicalisation fails for involutions with two or more antisymmetric directions (Proposition 6.10).
- **Evidence.** There are {{d.n_checks}} numerical checks (Table 6): {{d.n_main}} from a main script and {{d.n_extra}} from a supplementary script. An immutable C# kernel agrees with an independent NumPy implementation on every output line (Appendix A).

## 1.2 Scope and status of statements

Part II concerns one layer at one query. It makes no claim about search performance, sampling validity or the feasibility of proposed designs. The hypotheses C1 to C5 of V2 remain open, and nothing here tests them [14, Sections 17–18]. Every statement in a shaded box ends with a provenance tag. *Classical* marks a known result restated in ASE notation. *V2* marks a statement of the conversion proposal [14], sometimes with a new proof. *Mathematics book* marks a result retained from [13], with its number there. *New in Part II* marks a statement proved here for the first time in this programme; each comes with a proof and a numerical check. Unless stated otherwise, weights are frozen at the query. All spaces are finite-dimensional and real.

## 1.3 Conventions and notation

Table: **Table 1.** Notation used throughout Part II.

| Symbol | Meaning |
|:--------------|:--------------------------------------------------------------|
| $z\in ℝ^D$ | token state in the token frame |
| $y_i,\ R_i,\ o_i=R_iy_i$ | record value, record-side map and observation |
| $Q_i:ℝ^D\to ℝ^{k_i}$ | token-side edge map of record $i$ |
| $w_i,\ s$ | prior weight of record $i$ and the scale of the layer |
| $e_i,\ \alpha_i$ | discrepancy and attention weight (2.1) |
| $H,\ b,\ m$ | normal matrix, right side and read (2.2), (2.3) |
| $E_s$ | soft discrepancy energy (3.6) |
| $\kappa_j$ | coverage of coordinate $j$ under masks |
| $c_A$ | the largest $\lambda_{\text{max}}(Q_i^{\top}Q_i)$ over the records |
| $S,\ W,\ W_S,\ D_S$ | star, total archive weight, star weight and star kernel mass |
| $G,\ d_G$ | finite group of orthogonal symmetries and its orbit distance |
| $\langle g\rangle$ | the $\alpha$-weighted mean $\sum_i\alpha_ig_i$ |

# 2 The observation star and the layer contract

An ASE layer consumes a token, a versioned archive, declared edge maps and schedule coefficients. It produces a proposal together with its read, its star and numerical diagnostics [14, Section 4]. The read is computed on an auxiliary graph, the observation star. The cover nerve describes the base geometry, while the star describes the observations attached to it. ADE has a one-vertex nerve and a star with one leaf per record [15, Proposition 5.9].

::: {custom-style="Statement"}
**Definition 2.1** (observation star). At one layer, fix a token frame $ℝ^D$ and retrieved records $i=1,\ldots,n$ with values $y_i\in ℝ^{d_i}$, edge maps $Q_i:ℝ^D\to ℝ^{k_i}$ and $R_i:ℝ^{d_i}\to ℝ^{k_i}$, observations $o_i=R_iy_i$, prior weights $w_i>0$ and a scale $s>0$. The discrepancy and attention weight of record $i$ at the token $z$ are
:::

::: {custom-style="Statement Equation"}
$e_i(z)=\tfrac12\|Q_iz-o_i\|^2,\qquad \alpha_i(z)=\frac{w_i\exp(-e_i(z)/s^2)}{\sum_jw_j\exp(-e_j(z)/s^2)}$ (2.1)
:::

::: {custom-style="Statement"}
and the normal matrix and right side are
:::

::: {custom-style="Statement Equation"}
$H(z)=\sum_i\alpha_i(z)\,Q_i^{\top}Q_i,\qquad b(z)=\sum_i\alpha_i(z)\,Q_i^{\top}o_i$ (2.2)
:::

::: {custom-style="Statement Tag"}
V2 Section 4, made a definition.
:::

::: {custom-style="Statement"}
**Definition 2.2** (sheaf attention). The read at $z$ is
:::

::: {custom-style="Statement Equation"}
$m(z)=z+H^{\dagger}(b-Hz)$ (2.3)
:::

::: {custom-style="Statement"}
where $H^{\dagger}$ is the Moore–Penrose pseudo-inverse. If $H\succ 0$, then $m=H^{-1}b$. The eigenvectors of $H$ with eigenvalue zero span the unresolved directions, in which the read keeps the token's own value. In floating point, eigenvalues at most $\epsilon\,\text{max}(1,\lambda_{\text{max}}(H))$ are treated as zero, and the layer raises an unresolved flag. The kernel of Appendix A uses $\epsilon=10^{-10}$.
:::

::: {custom-style="Statement Tag"}
V2 Definition 4.1, with the retention rule of V2 Section 4 made explicit.
:::

The weights are frozen at the query. Each record contributes through its own observation space, so a record can contribute a strong subassembly without contributing anything else. A coordinate mask records what a record actually observed; an unobserved coordinate receives no invented value [14, Section 4]. Table 2 lists the map classes that recur below.

Table: **Table 2.** Classes of edge maps. Here $n$ is the number of records in the star; costs count arithmetic operations per read, with transports $Q_i^{\top}o_i$ and normal blocks $Q_i^{\top}Q_i$ stored with the records.

| Edge maps | Normal matrix | Read | Where the read lies | Cost per read |
|:----------------|:--------------|:----------------|:----------------|:----------------|
| identity | $H=I$ | $\sum_i\alpha_iy_i$, the ADE read | archive hull | $O(nD)$ |
| orthogonal transport | $H=I$ | $\sum_i\alpha_iQ_i^{\top}o_i$ | transported hull | $O(nD)$ |
| coordinate mask | diagonal coverage | coordinatewise weighted means | coordinate box | $O(\sum_ik_i+D)$ |
| partial isometry | $0\preceq H\preceq I$ | limit of repeated imputation | no hull in general | $O(nD^2+D^3)$ |
| general rectangular | $H\succeq 0$ | $z+H^{\dagger}(b-Hz)$ | no hull in general | $O(nD^2+D^3)$ |
