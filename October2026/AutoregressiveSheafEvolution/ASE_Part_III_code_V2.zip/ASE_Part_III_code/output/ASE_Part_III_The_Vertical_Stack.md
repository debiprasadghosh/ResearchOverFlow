---
title: "The Vertical Stack of Autoregressive Sheaf Evolution"
subtitle: "Part III Token Recurrence Tangent Dynamics and Persistence Across Layers"
author:
  - "Debi Prasad Ghosh"
  - "Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India"
date: "19 October 2026"
abstract: |
  We develop Part III of Autoregressive Sheaf Evolution, covering the token recurrence, tangent dynamics and persistence across layers. In one common affine coordinate system, arbitrary reads obey a schedule-only separation identity. For the DDIM coefficient family the explicit innovation term has variance exactly $s_0^2-\omega_\star^2s_T^2$ per coordinate. This is an accounting law; the moving reads remain dependent on the same noise. With a frozen Gaussian archive, the deterministic stack is Euler discretisation of its probability-flow equation. We also identify the stochastic limiting SDE and prove mean-square convergence at fixed positive cutoffs. Both limits have the declared archive marginals when correctly initialised. A clean endpoint gives weighted archive re-selection only in the iterated continuum and vanishing-bandwidth limit, not for an arbitrary finite stack. Layer Jacobians connect negative energy curvature with expansion, and their products give singular-value floors, ceilings and a clean-top covariance sandwich. Exact tangent barcodes remain distinct from numerical sensitivity; thresholded ranks can yield negative interval multiplicities. A typed extension carries the recurrence across changing data spaces and states the commuting conditions needed for compatible sections. Component persistence supplies valid comparison maps, whereas mode counts alone do not. The curvature of probability-flow paths yields a continuum allocation model with optimal layer density proportional to the square root of mean curvature. Its layer-halving threshold is a necessary condition for the surrogate, not a proved bound for actual endpoint error. In the supplied synthetic transport protocol, all 72 barcode half-layer comparisons fail its margin; the original optimisation conjecture C3 remains untested. We report 24 construction check groups, a rerun of the scheduling pilot, and a NumPy comparison with the supplied C# output trace.
---

# 1 Introduction

Autoregressive Diffusion Evolution (ADE) proposes designs by running tokens down a denoising stack whose layers read an archive of evaluated designs [7, 8]. Autoregressive Sheaf Evolution (ASE) generalises each read to an observation star with edge maps and scale-dependent covers [9]. Part I separated the two axes of the stack: horizontally topological within a layer, vertically algebraic across layers [10]. Part II worked out one layer. Its read is a harmonic extension, and every deterministic ADE layer is a majorise–minimise step on the soft energy at its own scale [11]. This paper, Part III of the book, stacks the layers. It covers chapters 7 to 9 of the book plan: the token recurrence, tangent dynamics, and persistence across layers [9, Section 21].

A stack mixes each token with the reads it collects in proportions fixed by its schedule. With the Gaussian identity-map model and a matched starting law, its continuum limit transports a population from a coarse archive density to a fine one. The realised Jacobian chain separately describes sensitivity. These descriptions distinguish an exact finite recurrence from a limiting sampling law and from a linear tangent representation. In the scaled coordinates of V2, a stack with identity maps is the recurrence

::: {custom-style="Equation"}
$z_{t-1}=(1-\lambda_t)\,z_t+\lambda_t\,m_t(z_t)+\gamma_t\,\xi_t,\qquad t=T,\ldots,1$ (1.1)
:::

with $m_t(z)=\sum_i\alpha_i(z,s_t)\,y_i$ the Gaussian read at scale $s_t$, independent standard normal increments $\xi_t$, and coefficients $\lambda_t,\gamma_t$ that depend only on the scales $s_0<s_1<\cdots<s_T$ and a noise parameter $\eta$ (Definition 2.1). The three descriptions are the following. Unrolling (1.1) separates the output into a starting term, a convex combination of reads, and a noise term with a fixed budget (Section 3.1). In precision coordinates $\tau=1/s$, a deterministic layer is a forward Euler step of the probability-flow equation of the archive density (Section 3.2). And the Jacobian of a layer is one minus a multiple of the Hessian of its energy, so that tangents expand exactly along directions of negative curvature (Section 4).

![**Figure 1.** (a) Weights of the reads in the output of an eight-layer geometric stack from $s_8=4$ to $s_0=0.1$ (Theorem 3.1). Noise moves weight towards the top layers and shrinks the weight $\omega_\star$ of the starting state. (b) The noise budget of the same stack (Theorem 3.2). The two algebraic budget terms in (3.2), normalised by $s_0^2$, sum to one; this is not a decomposition of total output variance. (c) A deterministic layer is a forward Euler step in the precision $\tau=1/s$ (Proposition 3.4). The shaded area is $\sum_t\Delta\tau_t\,m_t$, and the stack output is $z_0=s_0(z_T/s_T+\sum_t\Delta\tau_t\,m_t)$; the black curve is the read along the exact flow, recomputed for two records at $\pm1$ with weights 0.45 and 0.55.](fig/separation.png){width=100%}

## 1.1 Contributions

- **The token recurrence (Section 3).** We prove a noise budget: the explicit noise reaching the output is exactly $N(0,(s_0^2-\omega_\star^2s_T^2)I)$ (Theorem 3.2). Hence the starting state has weight at most $s_0/s_T$, a one-record stack is exactly calibrated for every schedule and every $\eta$, and a clean top removes both explicit terms; earlier randomness still affects its read. In precision coordinates the separation identity is a Riemann sum (Proposition 3.4). The deterministic stack discretises the probability-flow equation $\text{d}z/\text{d}s=-s\nabla\log p_s$, which carries $p_{s_T}$ to $p_{s_0}$, with local error caused only by the motion of the read (Theorem 3.5). With a clean top, the continuum stack re-selects archived records with probabilities equal to their prior weights (Proposition 3.6), and Proposition 3.7 separates the sources of novelty. Theorem 3.8 extends the continuum argument to stochastic stacks at positive cutoffs.
- **Tangent dynamics (Section 4).** A layer is a gradient step, and it expands exactly along directions of negative curvature of its energy (Proposition 4.1). Every singular value of a composite lies between products of layer eigenvalues. The deterministic floor $s_0/s_T$ is attained in directions the archive does not span (Theorem 4.2). With a clean top, the $k$-th singular value is pinned to the $k$-th eigenvalue of the top posterior covariance, up to the factor $1/(s_1s_T)$ and an expansion excess (Corollary 4.3). This explains the contraction reported in Part I. Stationary points can change number or type only where a tangent eigenvalue equals one, and they obey a Morse balance (Proposition 4.4). Thresholded ranks are not rank invariants and can give negative barcode multiplicities (Proposition 4.6).
- **Persistence across layers (Section 5).** Component barcodes are filtrations. Mode counts are monotone in one dimension, but not in two: for three equal records a fourth mode is born at exactly $s=\text{side}/\sqrt6$ (Example 5.3). Posterior concentration bounds token-path curvature on positive scale intervals (Theorem 5.4). This gives an error model whose optimal layer density is proportional to $\sqrt{g}$, and a layer-halving bound (Proposition 5.5). All 72 barcode comparisons fail the chosen transport pilot margin. This does not decide C3, whose endpoint is optimisation quality (Section 5.3).
- **Evidence.** There are 24 construction check groups across three scripts, besides the pilot (Table 5). The supplied immutable C# kernel has a saved trace that agrees with an independent NumPy recomputation on every output line; no fresh C# compilation is claimed (Appendix A).

## 1.2 Scope and status of statements

The exact statements concern identity edge maps, which give the ADE geometry. The fixed-frame identities carry over to orthogonal transport when the transported archive and maps are fixed throughout the comparison. Query-dependent frames need additional derivative and transport terms. General maps change the Jacobian of a read (Part II, Proposition 5.4) and the hull in which reads lie (Part II, Proposition 3.5). Where a statement needs identity maps, it says so. Prior weights are fixed. The paper proves statements about sampling and sensitivity of the stack; it makes no claim about search performance. Section 5.3 reports an exploratory pilot related to hypothesis C3 of V2 [9, Section 18]. It is not the confirmatory test that V2 specifies, and its outcome is labelled as exploratory throughout.

Every displayed statement ends with a provenance note. *Classical* marks a known result restated in ASE notation. *V2* marks a statement of the conversion proposal [9], sometimes with a new proof. *Mathematics book* marks a result retained from [8], with its number there. *Part I* and *Part II* refer to [10] and [11]. *Derived here* marks a deduction developed in this paper. These labels locate results within the programme and do not assert priority in the wider literature. All spaces are finite-dimensional and real.

## 1.3 Conventions and notation

Layers are numbered from the bottom, $t=T$, to the top, $t=1$; the token enters layer $t$ as $z_t$ and leaves it as $z_{t-1}$, so $z_0$ is the output. The scale of layer $t$ is $s_t$. "Coarse" means large $s$ and "fine" means small $s$.

Table: **Table 1.** Notation used throughout Part III.

| Symbol | Meaning |
|:--------------------------|:--------------------------------------------------|
| $y_i,\ w_i,\ \beta_i$ | records, prior weights and normalised weights $\beta_i=w_i/\sum_jw_j$ |
| $s_0<s_1<\cdots<s_T$ | scales; a clean top has $s_0=0$ |
| $\eta,\ \lambda_t,\ \gamma_t$ | noise parameter, interpolation weight and scaled noise deviation (2.1) |
| $\alpha_i(z,s),\ m(z,s),\ C(z,s)$ | posterior weights, read and posterior covariance at scale $s$ |
| $p_s$ | archive density $\sum_i\beta_iN(y_i,s^2I)$ |
| $E_s$ | layer energy (2.3) |
| $\pi_t,\ \omega_t,\ \omega_\star$ | separation weights of Theorem 3.1 |
| $\tau=1/s,\ w=z/s$ | precision and precision-scaled state (Proposition 3.4) |
| $J_t,\ K$ | layer Jacobian and composite tangent $K=J_1\cdots J_T$ |
| $c_{t,k}$ | eigenvalues of $C$ at layer $t$, in decreasing order |
| $M_3$ | posterior third moment (5.1) |
| $R$ | diameter of the records |


# 2 The stack and its schedule

V2 converts ADE into scaled coordinates, in which every layer interpolates between the token and its read [9, Proposition 6.2]. The scalar schedule enters through its scales and noise parameter. We use the scale sequence as the primary object; the reads retain their dependence on the archive and query.

::: {custom-style="Statement"}
**Definition 2.1** (schedule and stack). Fix records $y_1,\ldots,y_n\in ℝ^D$ with prior weights $w_i>0$. A *schedule* consists of scales $0\le s_0<s_1<\cdots<s_T$ and a noise parameter $0\le\eta\le1$. Its coefficients are
:::

::: {custom-style="Statement Equation"}
$\gamma_t^2=\eta^2s_{t-1}^2\,\frac{s_t^2-s_{t-1}^2}{s_t^2},\qquad 1-\lambda_t=\frac{\sqrt{s_{t-1}^2-\gamma_t^2}}{s_t},\qquad t=1,\ldots,T$ (2.1)
:::

::: {custom-style="Statement"}
The *stack* is the recurrence (1.1), with $\xi_1,\ldots,\xi_T$ independent standard normal vectors, independent of the starting state $z_T$. The read of layer $t$ is $m_t(z)=m(z,s_t)$, where
:::

::: {custom-style="Statement Equation"}
$\alpha_i(z,s)=\frac{w_ie^{-\Vert z-y_i\Vert^2/2s^2}}{\sum_jw_je^{-\Vert z-y_j\Vert^2/2s^2}},\quad m(z,s)=\sum_i\alpha_iy_i,\quad C(z,s)=\sum_i\alpha_i(y_i-m)(y_i-m)^{\top}$ (2.2)
:::

::: {custom-style="Statement"}
The top is *clean* when $s_0=0$. The archive density at scale $s>0$ is $p_s=\sum_i\beta_iN(y_i,s^2I)$, and the layer energy is
:::

::: {custom-style="Statement Equation"}
$E_s(z)=-s^2\log\sum_iw_ie^{-\Vert z-y_i\Vert^2/2s^2}$ (2.3)
:::

::: {custom-style="Statement Tag"}
V2 Proposition 6.2 and Section 7, with the scale sequence made primary; (2.3) is the soft energy of Part II with identity maps.
:::

With identity maps, $E_s=-s^2\log p_s+\text{const}$, its gradient is $z-m$ and its Hessian is $I-C/s^2$ (Part II, Proposition 3.9). The read (2.2) is sheaf attention with identity edge maps (Part II, Definition 2.2).

::: {custom-style="Statement"}
**Proposition 2.2** (coefficients and variance bookkeeping). Let $r_t=s_{t-1}/s_t$.
:::

::: {custom-style="Statement"}
\(i) $0\le\gamma_t^2\le s_{t-1}^2(1-r_t^2)$ and $1-r_t\le\lambda_t\le1-r_t^2$. In particular $0\le\lambda_t\le1$, and $\lambda_t$ increases with $\eta$, from $1-r_t$ at $\eta=0$ to $1-r_t^2$ at $\eta=1$.
:::

::: {custom-style="Statement"}
\(ii) $(1-\lambda_t)^2s_t^2+\gamma_t^2=s_{t-1}^2$.
:::

::: {custom-style="Statement"}
\(iii) If $s_t^2=(1-a_t)/a_t$ for signal levels $1\ge a_0\ge a_1\ge\cdots\ge a_T>0$, then $\gamma_t=\sigma_t/\sqrt{a_{t-1}}$ and $\lambda_t=1-A_t\sqrt{a_t/a_{t-1}}$, where $\sigma_t$ and $A_t$ are the coefficients (19.2) of the Mathematics book.
:::

::: {custom-style="Statement"}
\(iv) At a clean top, $\lambda_1=1$ and $\gamma_1=0$, so $z_0=m_1(z_1)$.
:::

::: {custom-style="Statement Tag"}
\(i), (ii) Derived here in this form; (iii) Mathematics book Propositions 19.2 and 19.3, V2 Proposition 6.2; (iv) V2 Corollary 7.2.
:::

*Proof.* (i) $\gamma_t^2=\eta^2s_{t-1}^2(1-r_t^2)$, so the radicand in (2.1) is $s_{t-1}^2\,(1-\eta^2(1-r_t^2))$, which lies between $s_{t-1}^2r_t^2$ and $s_{t-1}^2$ and decreases in $\eta$. Taking the square root and dividing by $s_t$ gives $r_t^2\le1-\lambda_t\le r_t$. (ii) Square the second identity in (2.1). (iii) Substitute $s^2=(1-a)/a$: $\gamma_t^2=\eta^2\frac{1-a_{t-1}}{a_{t-1}}\cdot\frac{a_{t-1}-a_t}{a_{t-1}(1-a_t)}=\sigma_t^2/a_{t-1}$, and $\sqrt{s_{t-1}^2-\gamma_t^2}/s_t=\sqrt{(1-a_{t-1}-\sigma_t^2)\,a_t/((1-a_t)\,a_{t-1})}=A_t\sqrt{a_t/a_{t-1}}$. (iv) Here $r_1=0$. ∎

Identity (ii) is the defining property of the family of Song, Meng and Ermon [18]: if the read were the true record, a layer would map noise of scale $s_t$ to noise of scale $s_{t-1}$. Theorem 3.2 below sums it over a stack.

::: {custom-style="Check"}
*Numerical check.* In 500 random schedules with 2 to 20 layers, scales between 0.02 and 30, a clean top in one case in four and random $\eta$, identity (ii) held to a relative 1.2 × 10⁻¹⁵, every $\lambda_t$ lay in the unit interval, and the coefficients of (iii) matched (19.2) to 3.3 × 10⁻¹³.
:::

::: {custom-style="Statement"}
**Proposition 2.3** (a stack is ADE in scaled coordinates). Let $s_t^2=(1-a_t)/a_t$ and $q_t=\sqrt{a_t}\,z_t$. For every realisation of the noise, the stack (1.1) with identity maps reproduces $T$ consecutive ADE proposal steps (19.1) of the Mathematics book, with the same retrieval weights at every layer and noise $\sigma_t\xi_t$.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 6.2, applied layer by layer.
:::

*Proof.* The weights agree because $\Vert q_t-\sqrt{a_t}y_i\Vert^2/(1-a_t)=\Vert z_t-y_i\Vert^2/s_t^2$. Dividing the ADE step $q_{t-1}=A_tq_t+B_tm_t+\sigma_t\xi_t$ by $\sqrt{a_{t-1}}$ and using Proposition 2.2(iii) gives (1.1) for one layer, and the layers compose. ∎

The ADE bottom $a_T=0$ has $s_T=\infty$, so a stack in scaled coordinates needs a positive cutoff $a_T>0$ [9, Section 8]. The cutoff is where the starting state enters, and Section 3.3 shows that it is one of the channels of novelty.

::: {custom-style="Check"}
*Numerical check.* In 200 random stacks with 2 to 16 layers, random levels, a clean top in about half of them and random $\eta$, the scaled stack and the ADE recursion in $q$ agreed to a relative 1.8 × 10⁻¹³ along the same noise paths.
:::


## 2.1 The recurrence on sheaf data spaces

The calculations below use a common vector space only after its coordinates and metric have been fixed. For engineering variables, first select units or nondimensionalisation, then define norms and residuals. Singular values depend on this metric choice; algebraic rank does not. A stalk is one data space. The token carries a vertical fibre diagram, or the tangent diagram of its realised nonlinear path, rather than being a single stalk stretched through the layers.

Keep four bases distinct. The cover nerve describes spatial overlap; the variable-context base describes partial observations; the observation star describes one read; the layer order describes computation. Components of a cover nerve, cohomology with sheaf coefficients and tangents of token updates are different diagrams. A map between them requires a construction.

On a fixed base let $r^t_{ve}:F_t(v)\to F_t(e)$ be a horizontal restriction. A linear vertical morphism has components $P_t^v$ and $P_t^e$ satisfying

::: {custom-style="Equation"}
$r^{t-1}_{ve}P_t^v=P_t^e r^t_{ve}$ (2.4)
:::

Every relevant square must commute. On changing bases with $\Phi_t:X_t\to X_{t-1}$, the typed arrow is $F_t\to\Phi_t^{-1}F_{t-1}$; its stalk at $x$ maps to the target stalk at $\Phi_t(x)$. The inverse image is a sheaf operation and does not require an inverse function. Common refinements or declared correspondences are needed for unrelated learned covers. Only a compatible fixed-base diagram supports the product-sheaf interpretation of Part I.

::: {custom-style="Statement"}
**Proposition 2.4** (transported separation and compatibility). Let $P_t:V_t\to V_{t-1}$ be fixed linear maps and $\lambda_t$ deterministic schedule coefficients. Put $b_t=\lambda_t m_t+\nu_t\in V_{t-1}$, $A_t=(1-\lambda_t)P_t$ and $B_t=A_1\cdots A_{t-1}$, with $B_1=I_{V_0}$. Then the recurrence $z_{t-1}=A_tz_t+b_t$ has the pathwise identity
:::

::: {custom-style="Statement Equation"}
$z_0=A_1\cdots A_Tz_T+\sum_{t=1}^T B_t b_t$ (2.5)
:::

::: {custom-style="Statement"}
If $V_t$ are cochain spaces with coboundaries $\delta_t$ and $\delta_{t-1}P_t=Q_t\delta_t$, then compatible $z_T$, $m_t$ and $\nu_t$ produce compatible states at every step. If $\nu_t=G_t\xi_t$ with deterministic $G_t$, independent standard Gaussian $\xi_t$ and deterministic transports, the explicit noise term has covariance
:::

::: {custom-style="Statement Equation"}
$\operatorname{Cov}\!\left(\sum_t B_tG_t\xi_t\right)=\sum_tB_tG_tG_t^\top B_t^\top$ (2.6)
:::

::: {custom-style="Statement Tag"}
Derived here from affine unrolling and the chain-map identity. Fixed transports are essential to the unconditional Gaussian assertion.
:::

*Proof.* Substitute the recurrence successively, preserving the order of the matrix products, to obtain (2.5). Applying $\delta_{t-1}$ gives $(1-\lambda_t)Q_t\delta_tz_t+\lambda_t\delta_{t-1}m_t+\delta_{t-1}\nu_t=0$, proving compatibility by induction. Independence and deterministic coefficients eliminate cross-covariances in (2.6). ∎

With $P_t=I$, the products become the scalar coefficients of Theorem 3.1. General transports produce matrix weights, so a common-frame convex-hull interpretation and the scalar budget (3.2) require additional assumptions. Compatible Gaussian noise must satisfy $\delta_{t-1}G_t=0$. Independent noise in every local view usually violates this condition; shared views of one token may require correlated innovations. Different generated tokens can still use independent noise.

For state-dependent transports, (2.5) remains an algebraic identity along a realised path, but its random matrix coefficients need not yield a Gaussian explicit term. Differentiation also produces derivatives of the transports. An arbitrary harmonic read is not automatically compatible with every other horizontal constraint. Compatibility must be imposed by a joint section solve or measured explicitly.

*Numerical check.* In 200 varying-dimensional chains, transported unrolling had maximum absolute discrepancy 5.0 × 10⁻¹⁶. The largest commuting defect was 1.2 × 10⁻¹⁵ and the largest section residual 1.6 × 10⁻¹⁵.

# 3 The token recurrence

## 3.1 Separation and the noise budget

Unrolling (1.1) separates what the schedule does from what the reads do.

::: {custom-style="Statement"}
**Theorem 3.1** (separation). Let realised reads $m_t$ and increments $\nu_t$ satisfy $z_{t-1}=(1-\lambda_t)z_t+\lambda_tm_t+\nu_t$ with $0\le\lambda_t\le1$. With $\pi_t=\prod_{u=1}^{t-1}(1-\lambda_u)$, $\omega_t=\lambda_t\pi_t$ and $\omega_\star=\prod_{u=1}^{T}(1-\lambda_u)$,
:::

::: {custom-style="Statement Equation"}
$z_0=\omega_\star z_T+\sum_{t=1}^{T}\omega_tm_t+\sum_{t=1}^{T}\pi_t\nu_t,\qquad \omega_\star+\sum_{t=1}^{T}\omega_t=1$ (3.1)
:::

::: {custom-style="Statement Tag"}
V2 Theorem 7.1.
:::

*Proof.* Set $P_t=I$ in Proposition 2.4. Since $\omega_t=\pi_t-\pi_{t+1}$, the weight sum telescopes to one. ∎

The weights depend only on the schedule, but the identity is pathwise: later reads depend on earlier ones through the queries, so (3.1) is an accounting identity, not a decomposition into independent effects [9, Section 7].

::: {custom-style="Check"}
*Numerical check.* Along 300 realised paths in dimensions 1 to 4, with up to 16 layers and random $\eta$, the right side of (3.1) reproduced the output to a relative 5.2 × 10⁻¹⁶, and the weights summed to one within 4.4 × 10⁻¹⁶.
:::

For the coefficients (2.1), the noise term of (3.1) is $N=\sum_t\pi_t\gamma_t\xi_t$. Its size is fixed by the two end scales.

::: {custom-style="Statement"}
**Theorem 3.2** (the noise budget). For every schedule,
:::

::: {custom-style="Statement Equation"}
$\sum_{t=1}^{T}\pi_t^2\gamma_t^2=s_0^2-\omega_\star^2s_T^2$ (3.2)
:::

::: {custom-style="Statement"}
Consequently:
:::

::: {custom-style="Statement"}
\(i) $\omega_\star\le s_0/s_T$, with equality if and only if $\eta=0$ or $s_0=0$;
:::

::: {custom-style="Statement"}
\(ii) whatever the reads, the explicit noise $N$ has the law $N(0,(s_0^2-\omega_\star^2s_T^2)\,I)$, and it vanishes at a clean top;
:::

::: {custom-style="Statement"}
\(iii) if every read equals one point $y$, as for a one-record archive, and $z_T\sim N(y,s_T^2I)$, then $z_0\sim N(y,s_0^2I)$, for every schedule, every $\eta$ and every number of layers.
:::

::: {custom-style="Statement Tag"}
Derived here.
:::

*Proof.* Since $\pi_{t+1}=(1-\lambda_t)\pi_t$, Proposition 2.2(ii) gives $\pi_t^2\gamma_t^2=\pi_t^2s_{t-1}^2-\pi_{t+1}^2s_t^2$. The sum telescopes to $\pi_1^2s_0^2-\pi_{T+1}^2s_T^2$, with $\pi_1=1$ and $\pi_{T+1}=\omega_\star$. (i) The left side of (3.2) is nonnegative. If $\eta>0$ and $s_0>0$, its first term is $\gamma_1^2=\eta^2s_0^2(1-s_0^2/s_1^2)>0$; otherwise every $\gamma_t\pi_t$ vanishes, since $\eta=0$ or, at a clean top, $\gamma_1=0$ and $\pi_t=0$ for $t\ge2$. (ii) $N$ is a fixed linear combination of independent standard normal vectors. (iii) By (3.1) and $\sum_t\omega_t=1-\omega_\star$, $z_0-y=\omega_\star(z_T-y)+N$, a sum of independent centred Gaussians with variances $\omega_\star^2s_T^2$ and $s_0^2-\omega_\star^2s_T^2$ per coordinate. ∎

The explicit Gaussian term has variance at most $s_0^2$, and the schedule fixes its algebraic split with the starting contribution (Figure 1b). It is generally correlated with the realised reads, so (3.2) is not a decomposition of total output variance. At a clean top the explicit starting and noise terms disappear from (3.1), but earlier randomness still affects $z_1$ and therefore the final read. The calibration (iii) is exact for every finite stack, but only for one record. With several records the reads move with the token, and calibration becomes a continuum statement (Theorem 3.5).

::: {custom-style="Check"}
*Numerical check.* In 500 random schedules, (3.2) held to a relative 2.7 × 10⁻¹⁶. With an oracle read $y=1.5$, twelve geometric layers from $s_T=10$ to $s_0=0.3$ and 200,000 tokens, the output standard deviation was 0.2997, 0.2998 and 0.3007 for $\eta=0$, 0.5 and 1, against $s_0=0.3$.
:::

::: {custom-style="Statement"}
**Corollary 3.3** (deterministic weights). For $\eta=0$, $1-\lambda_t=s_{t-1}/s_t$, $\pi_t=s_0/s_{t-1}$ and
:::

::: {custom-style="Statement Equation"}
$\omega_t=s_0\left(\frac{1}{s_{t-1}}-\frac{1}{s_t}\right),\qquad \omega_\star=\frac{s_0}{s_T}$ (3.3)
:::

::: {custom-style="Statement"}
with the product form of $\pi_t$ used at a clean top. For the formal limiting sixteen-layer cosine schedule $s_t=\tan(\pi t/32)$, the reads of layers 2, 3, 4, 5 and the remaining coarse contribution carry the weights 0.5049, 0.1705, 0.0869, 0.0535 and 0.1843 in the query $z_1$.
:::

::: {custom-style="Statement Tag"}
V2 Corollary 7.2 and the table of V2 Section 8.
:::

::: {custom-style="Check"}
*Numerical check.* In 300 random deterministic schedules, (3.3) held to 2.2 × 10⁻¹⁶ and $\omega_\star=s_0/s_T$ to 5.6 × 10⁻¹⁷. At the singular coarse endpoint these are formal limiting weights; a finite implementation stops at a positive signal level. The recomputed cosine weights were 0.5049, 0.1705, 0.0869, 0.0535 and 0.1843, as in V2.
:::

## 3.2 The deterministic stack is a discretised transport

::: {custom-style="Statement"}
**Proposition 3.4** (precision coordinates). Let $\eta=0$ and $s_{t-1}>0$. With the precision $\tau_t=1/s_t$ and $w_t=z_t/s_t$, layer $t$ of (1.1) is
:::

::: {custom-style="Statement Equation"}
$w_{t-1}=w_t+(\tau_{t-1}-\tau_t)\,m_t(z_t)$ (3.4)
:::

::: {custom-style="Statement"}
the forward Euler step for $\text{d}w/\text{d}\tau=m$. Equivalently, $z_{t-1}=z_t+(s_{t-1}-s_t)(z_t-m_t)/s_t$, the forward Euler step for
:::

::: {custom-style="Statement Equation"}
$\frac{\text{d}z}{\text{d}s}=\frac{z-m(z,s)}{s}$ (3.5)
:::

::: {custom-style="Statement"}
and this step solves (3.5) exactly when the read is frozen at $m_t$ over the step. Summing (3.4) gives (3.3) as a left Riemann sum: $z_0=s_0\left(z_T/s_T+\sum_t(\tau_{t-1}-\tau_t)\,m_t\right)$.
:::

::: {custom-style="Statement Tag"}
(3.4) Derived here; the Euler form Mathematics book Proposition 19.6, as a fractional score step, and Karras et al. [14], who list DDIM as Euler's method for $\sigma(t)=t$; the frozen-read form is first-order DPM-Solver, which equals DDIM [15].
:::

*Proof.* Divide the deterministic layer by $s_{t-1}$ and use $(1-\lambda_t)/s_{t-1}=1/s_t$ and $\lambda_t/s_{t-1}=1/s_{t-1}-1/s_t$. With $m$ frozen, (3.5) is linear with solution $z(s)=m+(s/s_t)(z_t-m)$, which at $s=s_{t-1}$ is the layer. Summing (3.4) from $t=T$ to 1 and multiplying by $s_0$ gives the last formula. ∎

Figure 1c shows (3.4) for two records. The weights of Theorem 3.1 are the widths $s_0\Delta\tau_t$ of the Riemann sum, and the read curve that the sum approximates is the read along the exact flow of (3.5).

::: {custom-style="Statement"}
**Theorem 3.5** (the deterministic stack discretises a transport). Use identity maps and $s_0>0$.
:::

::: {custom-style="Statement"}
\(i) $m(z,s)-z=s^2\nabla\log p_s(z)$, so (3.5) is the probability-flow equation $\text{d}z/\text{d}s=-s\nabla\log p_s(z)$.
:::

::: {custom-style="Statement"}
\(ii) The densities satisfy $\partial_sp_s=s\Delta p_s$, and for $0<s<s'$ the flow map $\Phi_{s'\to s}$ of (3.5) pushes $p_{s'}$ forward to $p_s$.
:::

::: {custom-style="Statement"}
\(iii) If $z(\cdot)$ solves (3.5) with $z(s_t)=z_t$, the local error of the layer is
:::

::: {custom-style="Statement Equation"}
$z(s_{t-1})-z_{t-1}=s_{t-1}\int_{\tau_t}^{\tau_{t-1}}\left(m(z(\tau),1/\tau)-m_t\right)\text{d}\tau,\qquad \Vert z(s_{t-1})-z_{t-1}\Vert\le\frac{1}{2}(s_t-s_{t-1})^2\,\text{max}\,\Vert z''\Vert$ (3.6)
:::

::: {custom-style="Statement"}
with the maximum over the step: the error is caused only by the motion of the read.
:::

::: {custom-style="Statement"}
\(iv) As the largest step tends to zero with $s_0$ and $s_T$ fixed, the stack output tends to $\Phi_{s_T\to s_0}(z_T)$, uniformly on compact sets and at first order. If $z_T\sim p_{s_T}$, the law of the output tends to $p_{s_0}$.
:::

::: {custom-style="Statement Tag"}
\(i) Classical, Tweedie's formula [6] (Part II, Proposition 4.1); (ii) classical [19, 14]; (iii) Derived here; (iv) classical [12].
:::

*Proof.* (i) Differentiate $p_s$: $\nabla p_s=\sum_i\beta_iN(z;y_i,s^2I)(y_i-z)/s^2$, so $\nabla\log p_s=(m-z)/s^2$. (ii) Each $N(y_i,s^2I)$ satisfies $\partial_s=s\Delta$, since its variance is $s^2$. With the velocity $v=-s\nabla\log p_s$, $\nabla\cdot(p_sv)=-s\Delta p_s=-\partial_sp_s$, so $p_s$ solves the continuity equation of the flow. The velocity is smooth with $\Vert Dv\Vert\le(1+R^2/4s^2)/s$ (Part II, Proposition 5.4), so the flow exists globally for $s\ge s_0$ and transports densities [19]. (iii) In precision coordinates the exact flow satisfies $w(\tau_{t-1})=w(\tau_t)+\int m\,\text{d}\tau$, while (3.4) uses $m_t$; subtract and multiply by $s_{t-1}$. The norm bound is Taylor's theorem with integral remainder for the Euler step in $s$. (iv) On the finite scale interval, the velocity is globally Lipschitz in $z$ and has linear growth. Its required derivatives are bounded on the compact trajectory sets reached from compact initial sets, so Euler's method converges at first order [12]; uniform convergence of the maps on compacts gives convergence of the pushed-forward laws. ∎

The corresponding stochastic limit is stated and proved in Theorem 3.8 below. Figure 2b checks marginal behaviour, while the additional coupled-noise experiment checks pathwise convergence against a finer discretisation.

::: {custom-style="Check"}
*Numerical check.* In 300 random layers, the layer, the Euler step and the score form (19.5) agreed to 4.0 × 10⁻¹⁵. For six records in one dimension, 40,000 tokens drawn from $p_{20}$ and geometric stacks down to $s_0=0.3$, the Kolmogorov–Smirnov distance to $p_{s_0}$ fell from 0.093 with 4 layers to 0.025, 0.0098 and 0.0064 with 16, 64 and 256 layers, against one Monte Carlo reference distance of 0.0041. With $\eta=1$ the values were 0.132, 0.034, 0.0113 and 0.0052. A Gaussian start with the ADE variance $1+s_T^2$ instead of $p_{s_T}$ raised the 256-layer distance to 0.0097.
:::

![**Figure 2.** (a) Outputs of deterministic stacks with 4 and 64 geometric layers from $s_T=20$ to $s_0=0.3$, for 40,000 tokens drawn from $p_{20}$, against the density $p_{s_0}$ of six weighted records (recomputed with a fixed seed). (b) Kolmogorov–Smirnov distance to $p_{s_0}$ against the number of layers, for $\eta=0$ and $\eta=1$ (Theorem 3.5). (c) With a clean top, 256 geometric layers down to $s_1=0.01$ re-select the records with frequencies close to their prior weights (Proposition 3.6).](fig/transport.png){width=100%}

## 3.3 Re-selection and the channels of novelty

::: {custom-style="Statement"}
**Proposition 3.6** (a clean top re-selects). Let $s_0=0$ and let the records be distinct.
:::

::: {custom-style="Statement"}
\(i) For every $\eta$ and every path, $z_0=m_1(z_1)$ lies in the convex hull of the records.
:::

::: {custom-style="Statement"}
\(ii) If $z_1\sim p_{s_1}$, then as $s_1\to0$ the output tends almost surely to the record from whose component $z_1$ was drawn. The law of $z_0$ tends to $\sum_i\beta_i\delta_{y_i}$.
:::

::: {custom-style="Statement"}
\(iii) First take the positive-scale mesh to zero with $s_1$ fixed and correct initial law, then let $s_1\to0$ and close with the clean-top read. The output laws converge weakly to the weighted atomic archive. This iterated limit re-selects records; a finite stack need not do so.
:::

::: {custom-style="Statement Tag"}
\(i) V2 Corollary 7.2; (ii) and (iii) Derived here.
:::

*Proof.* (i) Proposition 2.2(iv). (ii) Write $z_1=y_J+s_1\varepsilon$ with $P(J=i)=\beta_i$ and $\varepsilon\sim N(0,I)$. For $i\ne J$, $\alpha_i/\alpha_J=(w_i/w_J)\exp(-(\Vert y_J-y_i\Vert^2+2s_1\varepsilon^{\top}(y_J-y_i))/2s_1^2)$, which tends to zero almost surely, so $m_1(z_1)\to y_J$. (iii) For each fixed $s_1>0$, Theorem 3.5(iv) gives $p_{s_1}$ in the first limit. The final read is continuous at that scale. Apply (ii) in the second limit. The stochastic version follows in law from Theorem 3.8 under the same order of limits. ∎

::: {custom-style="Check"}
*Numerical check.* For the six records of Figure 2, 40,000 tokens from $p_{20}$ and 256 geometric layers down to $s_1=0.01$ followed by a clean top, 100.0% of the outputs lay within $10^{-6}$ of a record. The largest difference between a re-selection frequency and its prior weight was 0.0040, about twice the binomial standard error of the largest weight.
:::

V2 lists noise, the starting state, and transformed or recombined reads as distinct sources of novelty [9, Section 7]. Theorems 3.1 and 3.2 make the list exhaustive for identity maps and give each channel its size.

::: {custom-style="Statement"}
**Proposition 3.7** (the channels of novelty). Use identity maps in (i) to (iii) and write $H=\text{conv}\{y_1,\ldots,y_n\}$.
:::

::: {custom-style="Statement"}
\(i) *Starting state.* $z_0-N$ lies in $\text{conv}(\{z_T\}\cup H)$, with weight $\omega_\star\le s_0/s_T$ on $z_T$.
:::

::: {custom-style="Statement"}
\(ii) *Noise.* $N$ has the law $N(0,(s_0^2-\omega_\star^2s_T^2)I)$ (Theorem 3.2).
:::

::: {custom-style="Statement"}
\(iii) *Blending.* The reads lie in $H$, and a read can blend distinct records; at a clean top the blending of the last read is the only channel left, and it closes under the matched-law iterated limit of Proposition 3.6.
:::

::: {custom-style="Statement"}
\(iv) *Maps.* Non-identity maps can place reads outside $H$; coordinate masks can do so by combining complementary observations (Part II, Proposition 3.5). For deterministic identity-map stacks, discretisation changes the mixture weights implicitly through the queries but does not enlarge this hull. It can change finite-scale novelty within the hull.
:::

::: {custom-style="Statement Tag"}
Derived here; the list of channels is V2 Section 7.
:::

*Proof.* (i) In (3.1) every $\omega_t\ge0$, every read lies in $H$ and the weights of $z_T$ and the reads sum to one; Theorem 3.2(i) bounds $\omega_\star$. (ii) Theorem 3.2(ii). (iii) Proposition 3.6. (iv) Part II, Proposition 3.5, and (i) for any schedule. ∎

::: {custom-style="Check"}
*Numerical check.* A linear program found the output of each of 200 deterministic stacks with identity maps inside $\text{conv}(\{z_T\}\cup H)$; there were 0 exceptions. With random coordinate masks in $ℝ^3$, 156 of 200 outputs lay outside that hull.
:::



## 3.4 The stochastic continuum limit

::: {custom-style="Statement"}
**Theorem 3.8** (stochastic limit at positive cutoffs). Fix a finite Gaussian archive, query-independent positive weights, $0<s_{\min}<s_{\max}<\infty$ and $\eta\in[0,1]$. Put $u=s_{\max}-s$ and couple every layer innovation to a Brownian increment over its interval of length $h_t=s_t-s_{t-1}$. As $h_{\max}\to0$, the stack converges to
:::

::: {custom-style="Statement Equation"}
$\mathrm dZ_u=\frac{(1+\eta^2)(m(Z_u,s)-Z_u)}{s}\,\mathrm du+\eta\sqrt{2s}\,\mathrm dB_u$ (3.7)
:::

::: {custom-style="Statement"}
For a square-integrable common initial state, the mean squared error maximised over grid times is at most $C h_{\max}$ for a constant depending on the fixed cutoffs, archive and initial second moment. If $Z_0\sim p_{s_{\max}}$, the SDE has marginal density $p_s$ at scale $s$. At $\eta=0$ it is the deterministic probability flow, whose stronger first-order rate is given by Theorem 3.5.
:::

::: {custom-style="Statement Tag"}
Derived here for the stated coefficient family using standard Euler–Maruyama convergence [20]. The marginal family is the score-SDE probability-flow family [1, 19]. No rate uniform in a vanishing cutoff is asserted.
:::

*Proof.* Uniformly for $s\in[s_{\min},s_{\max}]$, Taylor expansion of (2.1) gives

::: {custom-style="Equation"}
$\lambda_t=(1+\eta^2)h_t/s_t+O(h_t^2),\qquad \gamma_t^2=2\eta^2s_th_t+O(h_t^2)$ (3.8)
:::

For fixed $\eta>0$, $\gamma_t/\sqrt{h_t}=\eta\sqrt{2s_t}+O(h_t)$; for $\eta=0$ both diffusion coefficients vanish. The drift of (3.7) is globally Lipschitz in $z$, because $D_zm=C/s^2$ is uniformly bounded by $R^2/(4s_{\min}^2)$, and it has linear growth because $m$ lies in a fixed compact hull. Its coefficients are regular in time on the stated interval. Euler–Maruyama therefore has mean-square order one half in root error [20]. Compared with its update, the stack has drift coefficient error $O(h_t^2)(1+\|Z\|)$ and deterministic diffusion coefficient error $O(h_t)$ multiplying the Brownian increment. Bounded second moments, martingale orthogonality and discrete Gronwall show that these perturbations have mean squared grid error $O(h_{\max}^2)$. Combining the two estimates proves the stated, conservative $O(h_{\max})$ mean squared bound.

For the marginal statement, write the drift as $(1+\eta^2)s\nabla\log p_s$. Its Fokker–Planck right side, evaluated at $p_s$, is

::: {custom-style="Equation"}
$-(1+\eta^2)s\Delta p_s+\eta^2s\Delta p_s=-s\Delta p_s=\partial_u p_s$ (3.9)
:::

The initial law matches, and uniqueness for the stated globally Lipschitz diffusion identifies its marginals. ∎

This result justifies a continuum sampling law at positive cutoffs. It does not make a finite multi-record stack an exact sampler, and it does not identify a fitness-driven changing archive with one fixed forward diffusion. At a clean top, first take the positive-scale limit, then the limit in Proposition 3.6.

*Numerical check.* With $\eta=0.7$, 2,000 shared initial tokens and Brownian paths, the root mean squared differences from a 4,096-layer stack were 0.1660, 0.0906, 0.0477, 0.0241 and 0.0117 at 16, 32, 64, 128 and 256 layers. This checks refinement behaviour against a finite reference, not the asymptotic rate theorem itself.

# 4 Tangent dynamics

Along a realised path, with the noise held fixed, the derivative of the output with respect to the starting state is the product of the layer Jacobians. These products are the tangent fibre diagrams of Part I, and their exact barcodes and effective ranks were compared there [10, Section 4.4]. This section bounds their singular values, locates where they contract and expand, and shows why thresholded ranks cannot replace exact ones.

## 4.1 One layer

::: {custom-style="Statement"}
**Proposition 4.1** (a layer is a gradient step). Use identity maps and $s_t>0$. Without noise, layer $t$ is the gradient step $z\mapsto z-\lambda_t\nabla E_{s_t}(z)$, and its Jacobian is
:::

::: {custom-style="Statement Equation"}
$J_t(z)=(1-\lambda_t)I+\lambda_t\,C(z,s_t)/s_t^2=I-\lambda_t\nabla^2E_{s_t}(z)$ (4.1)
:::

::: {custom-style="Statement"}
It is symmetric, with eigenvalues $1-\lambda_t+\lambda_tc/s_t^2$ for the eigenvalues $c$ of $C$, all in $[1-\lambda_t,\ 1-\lambda_t+\lambda_tR^2/4s_t^2]$. If $\lambda_t>0$, the layer expands along an eigenvector $u$ of $C$ if and only if $c>s_t^2$, that is, if and only if $u$ is a direction of negative curvature of $E_{s_t}$ at $z$. In every direction orthogonal to the affine span of the records it multiplies by exactly $1-\lambda_t$.
:::

::: {custom-style="Statement Tag"}
The Jacobian and its bound V2 Proposition 13.1 and Part II Proposition 5.4; the gradient form Part II Proposition 3.9 and Corollary 3.12; the expansion criterion Derived here.
:::

*Proof.* $\nabla E_s=z-m$ and $\nabla^2E_s=I-C/s^2$ (Part II, Proposition 3.9), so $(1-\lambda)z+\lambda m=z-\lambda\nabla E_s$ and (4.1) follows. The variance of the records along a unit vector is at most $R^2/4$. An eigenvalue exceeds one exactly when $\lambda(c/s^2-1)>0$. The range of $C$ is the direction space of the affine span of the records (Part I, Proposition 4.6(i)), so $Cu=0$ for $u$ orthogonal to it. ∎

::: {custom-style="Check"}
*Numerical check.* In 300 random layers in dimensions 1 to 4, (4.1) matched central differences to a relative 6.8 × 10⁻¹⁰, and the eigenvalue bounds had 0 violations.
:::

## 4.2 Composite tangents

::: {custom-style="Statement"}
**Theorem 4.2** (floor, ceiling and volume). Use identity maps. Along a realised path, with the noise fixed, let $K=J_1J_2\cdots J_T$ be the Jacobian of $z_0$ with respect to $z_T$.
:::

::: {custom-style="Statement"}
\(i) $\prod_t\lambda_{\text{min}}(J_t)\le\sigma_{\text{min}}(K)\le\sigma_{\text{max}}(K)\le\prod_t\lambda_{\text{max}}(J_t)$.
:::

::: {custom-style="Statement"}
\(ii) $\sigma_{\text{min}}(K)\ge\omega_\star$, which is $s_0/s_T$ when $\eta=0$. If $u$ is orthogonal to the affine span of the records, then $Ku=\omega_\star u$, so the floor is attained whenever the records do not affinely span $ℝ^D$.
:::

::: {custom-style="Statement"}
\(iii) With $c_{t,k}$ the eigenvalues of $C$ at layer $t$,
:::

::: {custom-style="Statement Equation"}
$\log|\text{det}\,K|=\sum_{t=1}^{T}\sum_{k=1}^{D}\log\left(1-\lambda_t+\lambda_tc_{t,k}/s_t^2\right)\ge D\log\omega_\star$ (4.2)
:::

::: {custom-style="Statement Tag"}
Derived here; V2 Section 13 gives the bound for one layer.
:::

*Proof.* The noise enters additively, so the Jacobian of a noisy layer is (4.1) evaluated on the noisy path. (i) Each $J_t$ is symmetric positive semidefinite, so its singular values are its eigenvalues, and $\sigma_{\text{min}}(AB)\ge\sigma_{\text{min}}(A)\sigma_{\text{min}}(B)$ and $\sigma_{\text{max}}(AB)\le\sigma_{\text{max}}(A)\sigma_{\text{max}}(B)$ [13]. (ii) $\lambda_{\text{min}}(J_t)\ge1-\lambda_t$ and $\prod_t(1-\lambda_t)=\omega_\star$; Corollary 3.3 gives the deterministic value. For $u$ orthogonal to the affine span, $J_tu=(1-\lambda_t)u$ at every layer by Proposition 4.1. (iii) The determinant is multiplicative, and every factor is at least $1-\lambda_t$. Interpret $\log0=-\infty$ if a factor is singular. The informative finite log-volume formula applies when the determinant is nonzero. ∎

In scaled coordinates a deterministic stack can therefore contract a tangent by at most the schedule ratio $s_0/s_T$. The reads only ever push singular values up from that floor, and they push hardest near branch decisions (Figure 3a).

::: {custom-style="Check"}
*Numerical check.* In 300 random stacks in dimensions 2 to 4 with 6 to 20 layers, half of them with a clean top, (i) had 0 and 0 violations and (4.2) held to a relative 1.4 × 10⁻¹⁵. The deterministic floor had 0 violations; the ratio $\sigma_{\text{min}}(K)/(s_0/s_T)$ had median 1.065 and minimum 1.000000, attained in the 20 stacks whose records did not affinely span the space, where $Ku=\omega_\star u$ held to 5.3 × 10⁻¹⁴. In 100 noisy stacks the floor $\omega_\star$ had 0 violations. Central differences matched $K$ to a relative 1.8 × 10⁻⁹. Singular-value bound checks allow an absolute tolerance of $10^{-12}\sigma_{\max}$; zero recorded violations does not imply exact floating-point inequalities.
:::

::: {custom-style="Statement"}
**Corollary 4.3** (contraction beyond the schedule happens at the top). Let $\eta=0$ and $s_0=0$, and let $c_{1,1}\ge\cdots\ge c_{1,D}$ be the eigenvalues of the top posterior covariance $C(z_1,s_1)$. Then for every $k$
:::

::: {custom-style="Statement Equation"}
$\frac{c_{1,k}}{s_1s_T}\le\sigma_k(K)\le\frac{c_{1,k}}{s_1s_T}\,X,\qquad X=\prod_{t=2}^{T}\frac{\lambda_{\text{max}}(J_t)}{1-\lambda_t}\ge1$ (4.3)
:::

::: {custom-style="Statement"}
and the rank of $K$ is the rank of $C(z_1,s_1)$, the affine dimension of the records when every weight is positive. The expansion excess $X$ equals one only if every posterior covariance below the top vanishes.
:::

::: {custom-style="Statement Tag"}
Derived here; the rank statement is Part I Proposition 4.6.
:::

*Proof.* At a clean top $J_1=C(z_1,s_1)/s_1^2$, whose $k$-th singular value is $c_{1,k}/s_1^2$. For $B=J_2\cdots J_T$, $\sigma_k(J_1)\sigma_{\text{min}}(B)\le\sigma_k(J_1B)\le\sigma_k(J_1)\Vert B\Vert$ [13]. Theorem 4.2 gives $\sigma_{\text{min}}(B)\ge\prod_{t\ge2}(1-\lambda_t)=s_1/s_T$ and $\Vert B\Vert\le\prod_{t\ge2}\lambda_{\text{max}}(J_t)=(s_1/s_T)X$. $B$ is invertible, so $\text{rank}\,K=\text{rank}\,J_1$. ∎

Part I ran 1,000 tokens through a sixteen-layer cosine stack with a clean top, starting from layer 15, and found median singular values 0.0353 and $6.4\times10^{-4}$ for the composite [10, Section 4.4]. For that schedule $s_1s_{15}=\tan(\pi/32)\tan(15\pi/32)=1$, so (4.3) says that each singular value is the corresponding eigenvalue of the top posterior covariance, multiplied by a factor between 1 and $X$. Replaying the same archive and tokens confirms it (Figure 3b). The contraction Part I observed is the concentration of the top read, inflated by the expansion of the layers below.

::: {custom-style="Check"}
*Numerical check.* In the 150 clean-top stacks of the previous check, (4.3) had 0 lower and 0 upper violations. On Part I's experiment, replayed from its random stream, both sides held for 1,000 of 1,000 tokens. The median singular values were 0.0353 and 6.41 × 10⁻⁴, the median top eigenvalues 6.13 × 10⁻³ and 1.86 × 10⁻⁴, and the median ratios $\sigma_k/c_{1,k}$ were 6.44 and 3.07. The excess $X$ had median 8.5 and 90th percentile 31.8.
:::

![**Figure 3.** (a) Largest and smallest singular values of the composite $K_{T\to t}$ for 40 tokens climbing a sixteen-layer geometric stack from $s_T=20$ to $s_0=0.05$ over three clusters of ten records in $ℝ^2$ (recomputed with a fixed seed). No singular value falls below the floor $s_t/s_T$ (Theorem 4.2). (b) The experiment of Part I, replayed: singular values of the composite against the eigenvalues of the top posterior covariance. Every point lies above the bound of Corollary 4.3, here the lower bound is $\sigma_k\ge c_{1,k}$ because $s_1s_{15}=1$. (c) The largest eigenvalue of $C_t/s_t^2$ along 300 of those paths. A layer expands where the curve exceeds one (Proposition 4.1). Over all 1,000 tokens, no layer coarser than layer 8 expanded; from that layer to the top, 18% to 37% of the tokens expanded at each layer, and 73% expanded at some layer.](fig/tangent.png){width=100%}

## 4.3 Fixed points, Morse index and bifurcations

At a fixed scale, the fixed points of the read are the stationary points of $E_s$. Their type, and the scales at which they appear and disappear, are what a mode-based barcode would record.

::: {custom-style="Statement"}
**Proposition 4.4** (fixed points, Morse index and bifurcations). Use identity maps and fix $s>0$.
:::

::: {custom-style="Statement"}
\(i) $m(z^\star,s)=z^\star$ if and only if $\nabla E_s(z^\star)=0$. Every layer at scale $s$ with $\lambda>0$ then fixes $z^\star$, and the number of its expanding directions equals the Morse index of $E_s$ at $z^\star$. Nondegenerate minima of $E_s$, the modes of $p_s$, attract.
:::

::: {custom-style="Statement"}
\(ii) (Morse balance) If every stationary point of $E_s$ is nondegenerate, then $\sum_k(-1)^kN_k=1$, where $N_k$ is the number of stationary points of index $k$.
:::

::: {custom-style="Statement"}
\(iii) (bifurcations) If 1 is not an eigenvalue of $C(z^\star,\varsigma)/\varsigma^2$ at a stationary point $z^\star$ for the scale $\varsigma$, then for $s$ near $\varsigma$ there is exactly one stationary point near $z^\star$; it depends smoothly on $s$ and keeps its index. Stationary points can therefore appear, disappear or change type only at scales where a stationary point has a tangent eigenvalue $c/s^2=1$, the expansion threshold of Proposition 4.1.
:::

::: {custom-style="Statement"}
\(iv) For two records of equal weight at distance $d$, the midpoint is a stationary point with $C/s^2=d^2/4s^2$, and the pitchfork occurs at $s=d/2$. For three equal records at the vertices of an equilateral triangle with side $\ell$, the centroid has $C=(\ell^2/6)\,I$ at every scale, so it changes type at $s=\ell/\sqrt6$.
:::

::: {custom-style="Statement Tag"}
\(i) Part II Corollary 5.5, with Proposition 4.1; (ii) classical, the Poincaré–Hopf theorem [16]; (iii) classical, the implicit function theorem, with the identification of the threshold Derived here; (iv) the pitchfork V2 Proposition 14.2, the centroid Derived here.
:::

*Proof.* (i) $\nabla E_s=z-m$. At $z^\star$, the eigenvalues of $J$ are $1-\lambda+\lambda c/s^2$, and the Hessian $I-C/s^2$ has a negative eigenvalue exactly when $c>s^2$. At a nondegenerate minimum every $c<s^2$, so $J$ has spectral radius below one. (ii) On a large ball, $\nabla E_s=z-m$ points outward because $m$ stays in the hull of the records. The Poincaré–Hopf theorem gives $\sum\text{sign}\,\text{det}\,\nabla^2E_s=\chi(\text{ball})=1$, and the sign is $(-1)^k$ at a point of index $k$ [16]. (iii) Apply the implicit function theorem to $F(z,s)=m(z,s)-z$, whose $z$-derivative $C/s^2-I$ is invertible at $(z^\star,\varsigma)$; the eigenvalues vary continuously and cannot cross one along the branch. (iv) At the midpoint the two weights are equal, so $C=(d/2)^2$ along the line of the records and zero across it. At the centroid the three weights are equal, and the second moment of the vertices about the centroid is $(r^2/2)I$, with circumradius $r=\ell/\sqrt3$. ∎

::: {custom-style="Statement"}
**Example 4.5** (pitchfork and fold). For records at $\pm1$ with equal weights, there are three stationary points for $0<s<1$ and one for $s>1$. With weights in the ratio 7 to 3, the symmetry breaks and the pitchfork becomes a fold: the lighter record's mode and the unstable stationary point between the records meet and vanish together (Figure 4a).
:::

::: {custom-style="Check"}
*Numerical check.* In 60 random archives in $ℝ^2$, Newton's method from 285 starts found 184 stationary points: 120 minima, 62 saddles and 2 maxima of $E_s$. The number of expanding directions equalled the number of positive eigenvalues of a finite-difference Hessian of $\log p_s$, which equals the Morse index of $E_s$ at all 184, and the Morse balance held in 60 of 60 archives. For records at $\pm1$, the counts at $s=0.8$, 0.9 and 0.99 were 3 and at 1.01, 1.1 and 1.3 were 1, and the midpoint tangent at $s=1$ was 1.0000. With weights 7 to 3 the fold lay at $s=0.7368$, at the last resolved scale below the fold the two nearby points had tangent eigenvalues 1.0009 and 0.9991.
:::

## 4.4 Exact and effective rank

Part I showed that the exact barcode of a Gaussian tangent diagram is usually full, while sensitivity contracts by orders of magnitude [10, Proposition 4.6]. It is tempting to repair this by computing barcodes from thresholded ranks. That repair fails.

::: {custom-style="Statement"}
**Proposition 4.6** (thresholded ranks are not rank invariants). For a chain of linear maps and a tolerance $\tau>0$, let $r_\tau(a,b)$ be the number of singular values of the composite from layer $a$ to layer $b$ that exceed $\tau$.
:::

::: {custom-style="Statement"}
\(i) $r_\tau$ can increase under composition. For $J_1=\text{diag}(10,0.05)$, $J_2=\text{diag}(0.05,10)$ and $\tau=0.1$, $r_\tau(2,1)=r_\tau(1,0)=1$ but $r_\tau(2,0)=2$.
:::

::: {custom-style="Statement"}
\(ii) Even for contractions, $r_\tau$ violates Sylvester's inequality $r(a,c)\ge r(a,b)+r(b,c)-\text{dim}\,V_b$. For $J_1=J_2=0.7\,I_2$ and $\tau=0.6$, $r_\tau(2,1)=r_\tau(1,0)=2$ but $r_\tau(2,0)=0$.
:::

::: {custom-style="Statement"}
\(iii) In both examples, formula (4.1) of Part I returns negative multiplicities: $m[2,1]=m[1,0]=-1$ in (i) and $m[1,1]=-2$ in (ii). Exact ranks never do (Part I, Theorem 4.2).
:::

::: {custom-style="Statement Tag"}
Derived here; exact ranks Part I Theorem 4.2 [10].
:::

*Proof.* (i) $J_2J_1=0.5\,I$. (ii) $J_2J_1=0.49\,I$. (iii) Substitute into Part I (4.1): in (i), $m[2,1]=r(2,1)-r(2,0)=-1$ and $m[1,0]=r(1,0)-r(2,0)=-1$; in (ii), $m[1,1]=2-r(2,1)-r(1,0)+r(2,0)=-2$. For exact ranks, every chain decomposes into intervals, and the multiplicities are counts. ∎

A thresholded "effective barcode" is therefore not a barcode. The defensible report has two parts: the exact barcode, which is a complete invariant and usually trivial, and the singular-value profile of the composites, which is stable under perturbation (Part I, Proposition 4.6(iv)) and is bounded by Theorem 4.2 and Corollary 4.3.

::: {custom-style="Check"}
*Numerical check.* Formula (4.1) of Part I returned the multiplicities stated in (iii). Among 2,000 random chains of three maps on $ℝ^3$ with log-normal singular values, about half constructed with a prescribed zero singular value before floating-point assembly, 1,989 had a negative multiplicity at $\tau=1$, and none with the tighter numerical rank tolerance. The latter is a floating-point check, not an exact-arithmetic calculation. Along the 1,000 realised sixteen-layer tangent diagrams of Part I's experiment, thresholded ranks gave negative multiplicities for 552 tokens at $\tau=10^{-2}$ and 259 at $\tau=10^{-3}$. At a relative tolerance of $10^{-14}$, 9 tokens still did; independent thresholding of these floating-point composites therefore violates rank identities even at this small tolerance. In exact arithmetic the full-span Gaussian diagram has full rank throughout; there is no contradiction with its exact barcode.
:::



## 4.5 What the exact tangent diagram records

::: {custom-style="Statement"}
**Proposition 4.7** (clean-top intervals and positive-cutoff invertibility). For a fixed identity-map archive, all lower maps $J_t$, $t\ge2$, are invertible. If the clean-top map $J_1$ has rank $r$, its tangent diagram on $V_T\to\cdots\to V_0$, with $V_t=\mathbb R^D$, has $r$ full intervals, $D-r$ intervals ending at layer 1 and $D-r$ intervals supported only at layer 0. If $s_0>0$, every finite realised stack with additive noise held fixed is a global smooth diffeomorphism of $\mathbb R^D$.
:::

::: {custom-style="Statement Tag"}
The interval statement is Part I specialised to this stack. The global statement is derived here for a fixed archive and positive cutoff, without chart switching.
:::

*Proof.* Lower maps have $\lambda_t<1$, so (4.1) is positive definite. Identify all lower spaces through these isomorphisms. The only remaining map is a rank-$r$ map into $V_0$; choose bases putting it into a rank-normal form. Its reached directions give full intervals, its kernel gives intervals ending before the top, and its cokernel gives the isolated top intervals.

At positive cutoff every layer has $\lambda_t<1$. Its map $F(z)=(1-\lambda)z+\lambda m(z)+\nu$ is the gradient of a smooth function with Hessian $J\succeq(1-\lambda)I$. Thus $F$ is strongly monotone and injective. For any target $b$, the strongly convex potential minus $b^\top z$ is coercive and has a unique minimiser, so $F(z)=b$ is solvable. Its derivative is invertible everywhere, giving a smooth inverse. Composition proves the stack claim. ∎

With positive finite Gaussian weights, $r$ equals the affine dimension of the records. A full-span archive therefore has $D$ full bars even at a clean top, however small its singular values become. Numerical zeros and underflow do not prove exact interval deaths. The $D-r$ terminal births in a rank-deficient example represent output directions not reached by perturbations from lower layers.

For a positive-cutoff deterministic stack, or conditional on a fixed innovation path, the change-of-variables formula gives the endpoint density through the inverse map and $|\det K|$. The unconditional noisy law requires integration over innovation paths; the explicit Gaussian term of Theorem 3.2 cannot be substituted as an independent output convolution. Across changing charts or branches, the relevant Jacobians and branch probabilities must be included.

A finite-temperature read can also equal an archived point without concentrated weights. For the records $-1$, $0$ and $1$ at $z=0$, symmetry gives $m=0$ while every posterior weight is positive. The additional check records weights between 0.274 and 0.452. Re-selection by proximity, posterior concentration and exact rank are therefore separate diagnostics.

# 5 Persistence across layers

Part I described two vertical persistence modules: the tangent fibre diagram of a token, and the cohomology of layer covers along a filtration [10, Sections 4.4–4.5]. Section 4.4 showed that the first must be read with exact ranks. This section asks which scale summaries of the archive form filtrations at all, because a barcode requires a specified linear diagram, including a zigzag when appropriate, and then asks where in the scale range the layers of a stack actually matter. The second question is the subject of hypothesis C3 of V2.

## 5.1 Which scale summaries are filtrations

::: {custom-style="Statement"}
**Proposition 5.1** (component barcodes). Fix the records and open balls $B(y_i,r)$.
:::

::: {custom-style="Statement"}
\(i) For strictly positive radii $r_0\le\cdots\le r_T$ and distinct centres the ball nerves are nested, and in the token direction the degree-zero maps are injective; every bar reaches the top (Part I, Proposition 4.10).
:::

::: {custom-style="Statement"}
\(ii) The number of components at radius $r$ is $n$ minus the number of merge heights $h_j<2r$, where $h_1\le\cdots\le h_{n-1}$ are the merge heights of single-linkage clustering of the records. In the token direction a bar is born at each merge radius $h_j/2$.
:::

::: {custom-style="Statement"}
\(iii) For two records at distance $d$ the merge radius $d/2$ is the pitchfork scale of Proposition 4.4(iv).
:::

::: {custom-style="Statement Tag"}
\(i) Part I Proposition 4.10; (ii) classical [3]; (iii) V2 Proposition 14.2.
:::

*Proof.* (ii) Two open balls of radius $r$ meet exactly when their centres are closer than $2r$, so the components of their union are the components of the graph that joins records at distance below $2r$. Single linkage merges components exactly at those thresholds. (iii) Proposition 4.4(iv). ∎

Components are thus a filtration whose barcode the archive determines once and for all. Modes of $p_s$ are a different matter.

::: {custom-style="Statement"}
**Proposition 5.2** (in one dimension modes are only born in the token direction). For $D=1$ and positive weights, the number of modes of $p_s$ does not increase with $s$.
:::

::: {custom-style="Statement Tag"}
Classical [17, 2].
:::

::: {custom-style="Check"}
*Numerical check.* For 150 random one-dimensional archives of 3 to 9 records with random weights, the mode count on 30 geometric scales from 0.05 to 5 never increased; there were 0 exceptions.
:::

::: {custom-style="Statement"}
**Example 5.3** (in two dimensions a mode is born as the scale grows). Place three records of equal weight at the vertices of an equilateral triangle with unit side. Then $p_s$ has three modes for $s<1/\sqrt6\approx0.4082$, four for $1/\sqrt6<s<s_f$, and one for $s>s_f$, where the fold scale is numerically $s_f\approx0.42674$. In units of the circumradius the two transitions are $\sqrt2/2$ and 0.7391, as found by Carreira-Perpiñán and Williams [5]. At $s=1/\sqrt6$ the tangent at the centroid reaches the expansion threshold in both directions at once (Proposition 4.4(iv)): the three saddles, approaching from the sides, pass through the centroid and leave towards the vertices, and the centroid turns from a minimum of the density into a mode. At $s\approx0.4267$ each vertex mode meets a saddle in a fold. The Morse balance holds throughout: $3-3+1=4-3+0=1-0+0=1$.
:::

::: {custom-style="Statement Tag"}
The mode counts Carreira-Perpiñán and Williams [5], who credit the example to Duistermaat, see also [4]; the mechanism and the exact first transition Derived here.
:::

::: {custom-style="Check"}
*Numerical check.* Mode finding by the read iteration from a 41 by 41 grid gave three modes up to $s=0.4075$, four from 0.41 to 0.425 and one from 0.4275, in steps of 0.0025. Newton's method from 2,116 starts at twelve scales recovered the expected counts of minima, saddles and maxima, with balance 1 at every scale. Bisection placed the fold at 0.42674, that is 0.7391 circumradii, and the centroid switch at 0.40825.
:::

So in two dimensions the mode count is not monotone in $s$, the mode counts alone supply no inclusion maps or other canonical linear comparison, and inclusion–exclusion on those counts does not produce a barcode. Even monotone one-dimensional counts do not by themselves specify a persistence module. A constructed correspondence, level-set persistence or zigzag is a separate object. The component barcode of the same three records is unaffected: the balls merge once, at $r=1/2$. V2 reported agreement between component counts and mode counts of 76% in one dimension and 80% in two, and called it a proxy rather than a theorem [9, Section 14]. For 30 random archives of 8 equal records in the unit square and 16 scales from 0.03 to 0.6, with radius equal to scale, the counts agreed in 393 of 480 pairs (81.9%).

![**Figure 4.** (a) Stationary points of $E_s$ for records at $\pm1$: with equal weights a pitchfork at $s=1$, with weights 7 to 3 a fold at $s\approx0.737$ (Example 4.5). Grey points are unstable stationary points, where a layer expands. (b) Three equal records at the vertices of a unit triangle, with contours of $p_s$, modes, saddles and the density minimum at three scales. Between $s=1/\sqrt6$ and 0.4267 the centroid is a fourth mode (Example 5.3). (c) Counts of modes and saddles against $s$; the dotted line marks $s=1/\sqrt6$.](fig/modes.png){width=100%}

## 5.2 Where layers matter

Theorem 3.5(iii) locates the error of a layer in the motion of the read along its step. The next theorem says how fast the read moves.

::: {custom-style="Statement"}
**Theorem 5.4** (curvature of token paths). Use identity maps. Along a solution of (3.5), with $\alpha_i$, $m$ and $C$ evaluated at $(z(s),s)$, let
:::

::: {custom-style="Statement Equation"}
$M_3=\sum_i\alpha_i\Vert y_i-m\Vert^2\,(y_i-m)$ (5.1)
:::

::: {custom-style="Statement"}
\(i) The path curves as fast as the read moves:
:::

::: {custom-style="Statement Equation"}
$z''=\frac{C(z-m)-M_3}{s^4}=-\frac{1}{s}\,\frac{\text{d}m}{\text{d}s}$ (5.2)
:::

::: {custom-style="Statement"}
\(ii) If one record has posterior mass at least $1-\varepsilon$ and $R$ is the diameter of the records, then
:::

::: {custom-style="Statement Equation"}
$\Vert z''\Vert\le\frac{\varepsilon\left(R^2\Vert z-m\Vert+(1+\varepsilon^2)R^3\right)}{s^4}$ (5.3)
:::

::: {custom-style="Statement"}
\(iii) Hence, by (3.6), a layer whose step keeps the posterior concentrated on one record is exact up to $O(\varepsilon)$: the local curvature is small under the stated concentration bound at fixed positive scales. Exact straightness holds for a constant read; posterior spread is not by itself sufficient for nonzero curvature, and the factor $s^{-4}$ precludes a uniform claim as $s\to0$.
:::

::: {custom-style="Statement Tag"}
Derived here.
:::

*Proof.* (i) Differentiating $z'=(z-m)/s$ gives $z''=(z'-m')/s-(z-m)/s^2=-m'/s$, where $m'=\text{d}m/\text{d}s=(C/s^2)z'+\partial_sm$. Differentiating the softmax gives $\partial_s\alpha_i=(2/s^3)\alpha_i(e_i-\langle e\rangle)$ with $e_i=\tfrac12\Vert z-y_i\Vert^2$, so $\partial_sm=(2/s^3)\sum_i\alpha_i(e_i-\langle e\rangle)(y_i-m)$. Expanding $e_i$ about $m$, $e_i-\langle e\rangle=-(z-m)^{\top}(y_i-m)+\tfrac12(\Vert y_i-m\Vert^2-\langle\Vert y-m\Vert^2\rangle)$, hence $\partial_sm=(M_3-2C(z-m))/s^3$ and $m'=(M_3-C(z-m))/s^3$. (ii) $\Vert C\Vert\le\varepsilon R^2$ by Part I, Proposition 4.6(ii). For the dominant record $j$, $\Vert y_j-m\Vert\le\varepsilon R$, and $\Vert y_i-m\Vert\le R$ for every $i$, so $\Vert M_3\Vert\le(\varepsilon R)^3+\varepsilon R^3$. (iii) Insert (5.3) in (3.6). ∎

::: {custom-style="Check"}
*Numerical check.* At 120 points on finely resolved flows in $ℝ^2$, second differences of the paths matched (5.2) to a median relative 8.1 × 10⁻⁵ (largest 1.2 × 10⁻³, set by the reference flow), and the two forms of (5.2) agreed to 1.6 × 10⁻¹⁶ of the scale of (5.3). In 4,000 random configurations, (5.3) had 0 violations; the largest ratio to the bound was 1.0000 and the median 0.025.
:::

Along the exact flow the token at scale $s$ has the law $p_s$ (Theorem 3.5(ii)). The mean curvature $g(s)=E_{z\sim p_s}\Vert z''\Vert$ can therefore be estimated from the archive alone, by sampling $p_s$ and evaluating (5.2), without running any flow.

::: {custom-style="Statement"}
**Proposition 5.5** (an error model and the layer-halving bound). For positive scales $s_1<\cdots<s_k$, define a nonnegative discrete surrogate by replacing $\text{max}\,\Vert z''\Vert$ in (3.6) by $g$ and sum the local errors:
:::

::: {custom-style="Statement Equation"}
$ℰ(s_1,\ldots,s_k)=\sum_{t=2}^{k}\frac{1}{2}(s_t-s_{t-1})\int_{s_{t-1}}^{s_t}g(s)\,\text{d}s$ (5.4)
:::

::: {custom-style="Statement"}
\(i) For a layer density $\rho$ with $\int\rho\,\text{d}s=k-1$, the continuum form $\tfrac12\int g/\rho\,\text{d}s$ of (5.4) is minimised by $\rho\propto\sqrt{g}$, with minimum
:::

::: {custom-style="Statement Equation"}
$ℰ_{\text{min}}(k)=\frac{1}{2(k-1)}\left(\int_{s_1}^{s_k}\sqrt{g(s)}\,\text{d}s\right)^2$ (5.5)
:::

::: {custom-style="Statement"}
\(ii) For the discrete surrogate as well as the continuum functional, $ℰ\ge ℰ_{\text{min}}(k)$. Call $e=ℰ_{\text{min}}(k)/ℰ\in(0,1]$ the model efficiency when the denominator is positive. A $k$-scale schedule can match a $2k$-scale baseline under this surrogate only if the baseline's efficiency is at most $(k-1)/(2k-1)$, which is less than one half.
:::

::: {custom-style="Statement Tag"}
\(i) Classical in form, the equidistribution of local error [12]; (ii) Derived here.
:::

*Proof.* (i) By the Cauchy–Schwarz inequality, $\left(\int\sqrt{g}\right)^2=\left(\int\sqrt{g/\rho}\,\sqrt{\rho}\right)^2\le\int(g/\rho)\int\rho$, with equality if and only if $\rho\propto\sqrt{g}$. (ii) For the discrete surrogate, choose $\rho(s)=1/(s_t-s_{t-1})$ on each interval. Then $\int\rho=k-1$ and $\tfrac12\int g/\rho$ is exactly (5.4), so (i) is a lower bound for every finite partition. A $k$-scale schedule therefore has $ℰ\ge ℰ_{\text{min}}(k)$, while a $2k$-scale baseline of model efficiency $e$ has $ℰ=ℰ_{\text{min}}(2k)/e$. By (5.5), $ℰ_{\text{min}}(k)\le ℰ_{\text{min}}(2k)/e$ if and only if $e\le(k-1)/(2k-1)$. ∎

The model ignores how later layers propagate an error, which Theorem 4.2 shows can contract or expand it, and it replaces the worst case by the mean. It is a model, not a bound. Its value is that it makes the question behind C3 quantitative. The threshold is exact as a necessary condition for this nonnegative error surrogate. It is not a lower bound for actual endpoint error. The final clean-top read and error propagation are absent from the model. When $g$ vanishes, use limits or regularise the allocation density; if $g$ is identically zero, every local surrogate is zero and the efficiency ratio is undefined.


## 5.3 An exploratory pilot of hypothesis C3

V2 states hypothesis C3 as follows: a $k$-layer schedule chosen from component persistence scales matches a $2k$-layer cosine schedule within 2% in declared output loss and novel-output share, on frozen multimodal families in dimensions 2, 4 and 8, with shared endpoint and cutoff rules; a $k$-layer geometric schedule is the control for layer thinning [9, Section 18]. The confirmatory test needs the optimisation families and output losses of V2. In the transport setting of Theorem 3.5, however, the quality of a schedule can be assessed against a finely resolved reference flow from the same starting tokens. We ran that comparison as an exploratory pilot. The supplied script records the metrics, seeds and decision rule. Its comments describe changes after an initial trial: an archive-only curvature estimate replaced a flow estimate, and mass weighting was added. There was no independent preregistration. We rerun the final seven-schedule protocol and report it as exploratory.

**Families and shared rules.** In each dimension $D\in\{2,4,8\}$ we froze 20 archives of 27 records in three nested levels of clusters, with spreads 4, 1 and 0.25 before normalising to unit pooled deviation per coordinate, and log prior weights with standard deviation 0.5. Every schedule has a clean top, $s_0=0$, the coarse start $s_k$ equal to twice the largest merge radius, and a common finest positive scale $s_1$. With a *fine top*, $s_1$ is half the smallest merge radius, to give a finer geometric cutoff. This does not guarantee a one-hot final posterior. With a *coarse top*, $s_1$ is the median merge radius. 1,000 tokens per archive were drawn from $p_{s_k}$ and shared by all schedules, so every comparison is paired. The reference output of a token is the clean-top read at $s_1$ of a numerical reference for the flow (3.5), integrated by the classical Runge–Kutta method in $\log s$ with step 0.004; on one instance in each dimension, halving the step moved the reference outputs by at most 9.2 × 10⁻⁹ nearest-neighbour distances.

Table: **Table 2.** Schedules in the pilot. All share $s_0=0$, $s_1$ and $s_k$; the rules place the $k-2$ interior scales.

| Schedule | Interior scales | Role |
|:---------------|:------------------------------------|:-----------------------|
| cosine | $\arctan s$ uniformly spaced | the C3 baseline, at $2k$ layers |
| geometric | $\log s$ uniformly spaced | the C3 control for thinning |
| EDM, $\rho=7$ | $s^{1/7}$ uniformly spaced [14] | a common sampler schedule |
| barcode, quantiles | merge radii at evenly spaced ranks | the C3 schedule |
| barcode, longest bars | the $k-2$ largest merge radii | a second reading of C3 |
| barcode, mass-weighted | quantiles of merge radii weighted by the mass of the merged component at that height | added after the trial |
| curvature | density proportional to $\sqrt g$, with $g$ from 300 draws of $p_s$ at 160 scales | Proposition 5.5, archive only |

**Metrics.** The *path loss* is the mean distance between a schedule's output and the reference output, in units of the median nearest-neighbour distance $d_{nn}$ of the records. The *novel-output share* is the share of outputs farther than $10^{-3}d_{nn}$ from every record. For C3 we compared each barcode schedule with $k$ layers against cosine with $2k$ layers, for $k=4$, 8, 16 and 32. Degradation is the ratio of archive-mean losses minus one, and the novelty difference is in percentage points; both carry paired bootstrap 95% intervals over the archives, with 10,000 resamples. A comparison *meets the pilot margin* if the loss interval lies below +2% and the novelty interval within ±2 points. It *fails the pilot margin* if the loss interval lies above +2% or the novelty interval lies outside ±2 points. Otherwise it is *inconclusive*. These are pointwise descriptive intervals; no simultaneous confirmatory inference about C3 is made. Curvature estimation uses 48,000 additional archive-read queries per archive. That construction cost is excluded from the plotted layer count, so equal-layer path loss does not establish an end-to-end computational gain.

Table: **Table 3.** Path loss pooled over $D=2$, 4 and 8, by schedule and number of layers $k$, with a fine top; the median discrete efficiency proxy from Proposition 5.5 at $k=16$; and the loss at $k=16$ with a coarse top.

| Schedule | $k=4$ | 8 | 16 | 32 | 64 | $e$ | coarse top |
|:----------------------|:------|:------|:------|:------|:------|:-----|:----------|
| cosine | 1.434 | 0.588 | 0.264 | 0.121 | 0.058 | 0.93 | 0.225 |
| geometric | 2.388 | 0.948 | 0.438 | 0.212 | 0.103 | 0.70 | 0.262 |
| EDM, $\rho=7$ | 1.854 | 0.754 | 0.348 | 0.168 | 0.077 | 0.82 | 0.241 |
| barcode, quantiles | 3.624 | 2.517 | 1.208 | 0.483 | 0.121 | 0.27 | 0.652 |
| barcode, longest bars | 1.899 | 1.060 | 0.953 | 0.483 | 0.121 | 0.34 | 0.652 |
| barcode, mass-weighted | 2.154 | 1.068 | 0.739 | 0.483 | 0.121 | 0.42 | 0.652 |
| curvature, $\rho\propto\sqrt g$ | 1.404 | 0.554 | 0.252 | 0.117 | 0.058 | 1.00 | 0.215 |

Table: **Table 4.** The transport comparison motivated by C3 with a fine top: the barcode schedule with quantile placement and $k$ layers against cosine with $2k$ layers. Intervals are paired bootstrap 95% intervals. The last two columns give the degradation of the same barcode schedule against geometric with $k$ layers, and of the curvature schedule with $k$ layers against cosine with $2k$ layers.

| $D$ | $k$ | loss degradation, % | novelty difference, points | verdict | against geometric, % | curvature against cosine, % |
|:--|:--|:----------------|:----------------|:--------|:----------|:----------|
| 2 | 4 | +535 (+483, +586) | −4.7 (−6.8, −2.8) | fails | +31 | +131 |
| 2 | 8 | +874 (+767, +972) | −5.6 (−7.8, −3.7) | fails | +138 | +105 |
| 2 | 16 | +926 (+809, +1061) | −5.9 (−7.6, −4.3) | fails | +138 | +122 |
| 2 | 32 | +833 (+733, +945) | −4.2 (−5.4, −3.2) | fails | +120 | +111 |
| 4 | 4 | +511 (+475, +549) | −19.6 (−23.7, −15.5) | fails | +74 | +134 |
| 4 | 8 | +851 (+759, +951) | −13.9 (−17.0, −10.9) | fails | +186 | +113 |
| 4 | 16 | +866 (+761, +993) | −8.1 (−9.9, −6.3) | fails | +199 | +97 |
| 4 | 32 | +630 (+561, +703) | −3.7 (−4.4, −2.9) | fails | +128 | +87 |
| 8 | 4 | +496 (+461, +534) | −18.8 (−21.5, −16.0) | fails | +67 | +155 |
| 8 | 8 | +829 (+759, +904) | −10.5 (−12.7, −8.3) | fails | +195 | +116 |
| 8 | 16 | +907 (+804, +1033) | −4.3 (−5.7, −2.8) | fails | +223 | +103 |
| 8 | 32 | +681 (+561, +837) | −1.7 (−2.3, −1.2) | fails | +145 | +100 |

**Results.** All 72 comparisons of a barcode schedule with $k$ layers against cosine with $2k$ layers failed the transport pilot margin: three readings of the barcode rule, three dimensions, four layer counts and two top rules. Table 4 shows the quantile reading with a fine top. Loss degradations ranged from +154% to +926%, so the loss criterion alone was decisive; the novelty interval also lay outside ±2 points in 11 of the 12 rows of Table 4. The quantile barcode was worse than geometric spacing with the same number of layers in all 12 fine-top comparisons. In this setting, therefore, choosing scales by topology did worse than thinning the layers. At 32 and 64 layers the three barcode schedules coincide, because every merge radius is then used.

The error model of Proposition 5.5 is associated with the observed ranking (Figure 5d). Across the seven schedules, the model ranked the observed losses with a median Spearman correlation of 1.00 with a fine top and 0.96 with a coarse top, and the correlation was positive for every archive and layer count. At $k=16$ the median efficiencies were 0.27, 0.34 and 0.42 for the three barcode schedules, 0.70 for geometric, 0.82 for EDM, 0.93 for cosine and 1.00 for the curvature schedule. The reason is visible in Figure 5a. Merge radii crowd the fine scales, where most merges join neighbouring records and affect only the few tokens near them. The curvature of a typical path lies at intermediate and coarse scales, where whole clusters separate and every token takes a branch. The mass-weighted reading moves layers towards those scales and improves on the quantile reading, but not enough.

The computed model efficiency of cosine spacing exceeds one half. Proposition 5.5(ii) then rules out matching its surrogate with half the scales. This is not a lower bound for actual endpoint error. In the observed transport errors, halving the layers of cosine itself multiplied its pooled loss by 2.06 to 2.23. Even the curvature schedule with $k$ layers had between +87% and +155% more loss than cosine with $2k$, so it too fails the transport pilot margin. At equal numbers of layers, however, it was the best schedule: it had the lowest pooled loss at every layer count with both top rules, and the lowest loss in 28 of 30 cells by dimension, the other two going to cosine. In a post hoc paired comparison with cosine at equal $k$, its loss was lower with an interval excluding zero in 17 of 30 comparisons and higher in 0. The differences ranged from −9.0% to +4.8%.

Novelty needs a caveat. With a fine top, the share of novel outputs of the reference transport was 2.6%, 6.0% and 8.4% in dimensions 2, 4 and 8. Cosine with 64 layers still produced 7.6%, 12.0% and 13.8% novel outputs, against 2.8%, 6.7% and 9.3% for geometric spacing. Cosine spacing ends with a long step to the finest scale, and the final read then blends neighbouring records. Matching the novelty share of cosine with $2k$ layers is therefore not the same as matching the transport, and the novelty half of C3 should be stated against the continuum reference.

**Verdict.** All barcode rules tried here failed the exploratory transport margin. C3 concerns optimisation quality and remains untested by this protocol. In these nested synthetic archives, the persistence scales concentrated reads at fine scales where most sampled paths had little curvature. The pilot motivates supplementing C3 with two statements that the theory supports and that a confirmatory study can test. The first is that the efficiency $e$, computed from the archive alone, predicts the ranking of schedules. The second is that a schedule with density proportional to $\sqrt g$ is non-inferior to the cosine schedule with the same number of layers. Neither is established here. Both belong in the confirmatory protocol, with the output losses of V2 in place of the transport metric.

![**Figure 5.** The schedule pilot. (a) For one archive in $ℝ^2$: the square root of the curvature density $g$, the 26 merge radii, and the scales of the seven schedules with eight layers. Most merge radii are fine, while most curvature lies at coarse scales. (b) Path loss against the number of layers, pooled over $D=2$, 4 and 8, with a fine top. (c) The transport comparison motivated by C3: loss of the quantile barcode schedule and of the curvature schedule with $k$ layers, divided by the loss of cosine with $2k$ layers, with bootstrap 95% intervals; the dashed line is the 2% margin. (d) For every archive and $k=8$, 16 and 32, the error model (5.4) of each schedule against its path loss, both relative to cosine with the same $k$.](fig/schedules.png){width=100%}


# 6 Register of numerical checks

Table 5 lists every numerical check in Part III. The main script supplies 18 groups, the supplementary script 3 and the added script three; the pilot of Section 5.3 and the kernel comparison of Appendix A complete the list. All scripts write machine-readable results, and every number in this paper is drawn from the saved result files or stated mathematical constants; computed tables are populated when the document is built. The checks test the implementations and illustrate the statements; the proofs establish them. Random archives are synthetic, so ratios to bounds describe these constructions, not engineering archives in general.

Table: **Table 5.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 2.2 | coefficients, 500 schedules | bookkeeping 1.2 × 10⁻¹⁵; (19.2) to 3.3 × 10⁻¹³ |
| 2 | Proposition 2.3 | ADE recovery, 200 stacks | 1.8 × 10⁻¹³ |
| 3 | Theorem 3.1 | separation, 300 paths | 5.2 × 10⁻¹⁶ |
| 4 | Theorem 3.2 | noise budget, 500 schedules; oracle | 2.7 × 10⁻¹⁶; output deviation within 0.3% of $s_0$ |
| 5 | Corollary 3.3 | deterministic weights, cosine table | 2.2 × 10⁻¹⁶; V2 table reproduced |
| 6 | Proposition 3.4 | Euler and score forms, 300 layers | 4.0 × 10⁻¹⁵ |
| 7 | Theorem 3.5 | continuum limit, 40,000 tokens | KS 0.093 to 0.0064 from 4 to 256 layers |
| 8 | Proposition 3.6 | clean-top re-selection | 100.0% within $10^{-6}$; frequencies within 0.0040 |
| 9 | Proposition 3.7 | hulls, 200 and 200 stacks | 0 identity outputs outside; 156 masked outputs outside |
| 10 | Proposition 4.1 | layer Jacobian, 300 layers | 6.8 × 10⁻¹⁰; 0 bound violations |
| 11 | Theorem 4.2 | composites, 300 and 100 stacks | 0 violations; floor attained; volume 1.4 × 10⁻¹⁵ |
| 12 | Corollary 4.3 | clean-top sandwich; Part I replayed | 0 and 0 violations; 1,000 of 1,000 tokens |
| 13 | Proposition 4.4(i), (ii) | Morse index and balance, 60 archives | 184 of 184 points; 60 balanced |
| 14 | Proposition 4.4(iii), Example 4.5 | pitchfork and fold | tangent 1.0000; fold at 0.7368 |
| 15 | Proposition 4.6 | thresholded ranks, 2,000 chains; Part I | 1,989 negative; tight tolerance 0; 552 tokens at $10^{-2}$ |
| 16 | Proposition 5.2 | one-dimensional modes, 150 archives | 0 increases |
| 17 | Example 5.3 | triangle counts and Morse balance | four modes from 0.41 to 0.425; fold 0.4267 |
| 18 | Section 5.1 | components against modes, 480 pairs | 81.9% agree |
| 19 | Theorem 5.4(i) | path curvature, 120 points | median 8.1 × 10⁻⁵; forms 1.6 × 10⁻¹⁶ |
| 20 | Theorem 5.4(ii) | curvature bound, 4,000 cases | 0 violations; largest ratio 1.0000 |
| 21 | Proposition 5.5 | efficiency against loss, pilot | median Spearman 1.00 and 0.96; positive in every archive |
| 22 | Section 5.3 | C3 pilot, 60 archives | 72 of 72 barcode comparisons failed the pilot margin; curvature schedule best at every layer count |
| 23 | Appendix A | supplied C# trace against fresh NumPy | 18 of 18 lines agree; 16 identical to 15 digits |
| 24 | Proposition 2.4 | 200 typed chains | unrolling 5.0 × 10⁻¹⁶; compatible states |
| 25 | Theorem 3.8 | coupled Brownian refinements | RMS 0.1660 to 0.0117 |
| 26 | Section 4.5 | finite-temperature equality with a record | positive weights; mean equals central record |

# 7 Discussion

## 7.1 What Part III supplies to the rest of the book

Part IV, on targets and estimation, needs the law of the proposals. Theorem 3.5 identifies it in the continuum limit: a deterministic stack with identity maps proposes from $p_{s_0}$, the archive density at the top scale. Its discretisation error is controlled by the curvature of Theorem 5.4. With a clean top, Proposition 3.6 gives archive re-selection in its iterated limit. The noise budget identifies an explicit, generally read-correlated Gaussian term for deterministic schedule coefficients. Theorem 3.8 gives the stochastic limiting law under its separate assumptions. These are the facts an importance weight or a Gibbs target must be built on.

Part V, on fusion and constraints, needs end-to-end sensitivities. Theorem 4.2 gives two-sided bounds for every singular value of a composite. Corollary 4.3 shows that at a clean top the singular values of the composite are bracketed by corresponding top-covariance eigenvalues and explicit factors, so the sensitivity of an output design to its starting query is decided by how concentrated the last read is. Part VI, on evidence and computation, takes the diagnostics of Table 6 and the kernel of Appendix A as specifications.

For the hypotheses of V2, the pilot of Section 5.3 bears on C3, and Proposition 5.5 gives it a quantitative form: whether a schedule can halve its layers depends on the efficiency of the baseline, which the archive can estimate within the continuum surrogate; actual endpoint error also involves propagation and the clean-top map.

## 7.2 Diagnostics a stack should report

Table: **Table 6.** Diagnostics reported with every stack.

| Diagnostic | Source | Action when it is poor |
|:-------------------|:-------------------|:-------------------------------|
| weight $\omega_\star$ and the noise budget split | Theorem 3.2 | report both shares of $s_0^2$ |
| eigenvalues of the top posterior covariance and the excess $X$ | Corollary 4.3 | report with every sensitivity claim |
| layers where $c>s^2$ along each path | Proposition 4.1 | report expanding directions with their scale and tolerance |
| exact barcode and singular-value profile | Proposition 4.6 | never report a thresholded barcode |
| component barcode, not mode counts, in two or more dimensions | Proposition 5.1, Example 5.3 | use modes only as a proxy, with its agreement rate |
| curvature density $g$ and schedule efficiency $e$ | Proposition 5.5 | test curvature allocation with its construction cost included |
| re-selection share and the size of each novelty channel | Propositions 3.6, 3.7 | report the accounting terms and their dependence |

## 7.3 What is not claimed

The Gaussian transport statements use a fixed identity-map archive. General harmonic reads need not equal a score displacement; changing masks, maps or priors requires a separate probability model and its consistency across scales. The deterministic limit has first-order error on fixed positive intervals. The stochastic theorem states a conservative root mean square order of one half; neither rate is uniform down to zero. Theorem 3.8 proves stochastic convergence at fixed positive cutoffs under its stated coupling and regularity assumptions; it does not cover a simultaneous zero-cutoff limit. The error model of Proposition 5.5 omits error propagation and is tested only empirically. The pilot is exploratory: it uses a transport metric instead of the optimisation outcomes of V2, and it does not settle C3. No statement here concerns search performance.

## 7.4 Open problems

1. **The vanishing cutoff.** Extend Theorem 3.8 to a simultaneous shrinking finest scale and refined mesh, with bounds on constants that diverge near zero.
2. **Transport with maps.** Characterise mapped read displacements that are gradients of log densities and whose marginals agree with one forward process. A harmonic normal equation alone does not provide either condition.
3. **Propagation-aware schedules.** Weight the curvature density by the composite tangents of Theorem 4.2, and compare with second-order layers that spend two reads per step.
4. **Mode zigzags.** Describe the births and deaths of modes across scales in two and more dimensions as a zigzag module, using the eigenvalue-one crossings of Proposition 4.4.
5. **A stable sensitivity summary.** Find a summary of numerical sensitivity along a tangent diagram that is stable under perturbation and consistent with rank invariants.
6. **C3 in the optimisation setting.** Run the confirmatory C3 protocol of V2, with output loss on the design objective, and add the curvature schedule as a declared comparator.

## 7.5 Consequences for the remaining book

A stack of ASE layers is a schedule acting on reads. The schedule fixes how outputs mix starting state, reads and noise, and it fixes the noise budget. In the continuum limit the deterministic stack transports the coarse archive density to the fine one, and a clean top turns it into a weighted re-selection of the archive. Tangents never contract below the schedule's own ratio except at the top read, and they expand exactly where the energy has negative curvature, while stationary-point bifurcations require the boundary where the corresponding eigenvalue reaches one. Components form a filtration across layers; modes do not, and thresholded ranks do not either. Posterior concentration controls path curvature on a fixed positive scale interval, which tells a schedule where its layers matter. The exploratory transport pilot failed its margin in all 72 comparisons, because merge radii crowd the fine scales, while a curvature schedule computed from the archive alone was the best of seven at equal numbers of layers. Part IV now turns from the stack to the targets it serves.

# References

::: {custom-style="Bibliography"}
[1] Anderson, B. D. O. (1982). Reverse-time diffusion equation models. *Stochastic Processes and their Applications* 12(3), 313–326.

[2] Babaud, J., Witkin, A. P., Baudin, M. and Duda, R. O. (1986). Uniqueness of the Gaussian kernel for scale-space filtering. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 8(1), 26–33.

[3] Carlsson, G. (2009). Topology and data. *Bulletin of the American Mathematical Society* 46(2), 255–308.

[4] Carreira-Perpiñán, M. Á. and Williams, C. K. I. (2003a). On the number of modes of a Gaussian mixture. In *Scale Space Methods in Computer Vision*, Lecture Notes in Computer Science 2695, 625–640. Springer.

[5] Carreira-Perpiñán, M. Á. and Williams, C. K. I. (2003b). An isotropic Gaussian mixture can have more modes than components. Technical report EDI-INF-RR-0185, School of Informatics, University of Edinburgh. https://www.inf.ed.ac.uk/publications/report/0185.html

[6] Efron, B. (2011). Tweedie's formula and selection bias. *Journal of the American Statistical Association* 106(496), 1602–1614.

[7] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[8] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[9] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[10] Ghosh, D. P. (2026d). *Horizontally Topological, Vertically Algebraic: The Two Axes of Autoregressive Sheaf Evolution. Part I: Sheaves on Covers and Representations of the Layer Order*. 18 October 2026.

[11] Ghosh, D. P. (2026e). *The Horizontal Layer: One Layer of Autoregressive Sheaf Evolution. Part II: Sheaf Attention, Gaussian Stalks, Locality and the Topology of Design Spaces*. 18 October 2026.

[12] Hairer, E., Nørsett, S. P. and Wanner, G. (1993). *Solving Ordinary Differential Equations I: Nonstiff Problems*, 2nd revised edn. Springer Series in Computational Mathematics 8. Springer.

[13] Horn, R. A. and Johnson, C. R. (1991). *Topics in Matrix Analysis*. Cambridge University Press.

[14] Karras, T., Aittala, M., Aila, T. and Laine, S. (2022). Elucidating the design space of diffusion-based generative models. *Advances in Neural Information Processing Systems* 35. arXiv:2206.00364. https://arxiv.org/abs/2206.00364

[15] Lu, C., Zhou, Y., Bao, F., Chen, J., Li, C. and Zhu, J. (2022). DPM-Solver: a fast ODE solver for diffusion probabilistic model sampling in around 10 steps. *Advances in Neural Information Processing Systems* 35. arXiv:2206.00927. https://arxiv.org/abs/2206.00927

[16] Milnor, J. W. (1965). *Topology from the Differentiable Viewpoint*. University Press of Virginia.

[17] Silverman, B. W. (1981). Using kernel density estimates to investigate multimodality. *Journal of the Royal Statistical Society, Series B* 43(1), 97–99. https://doi.org/10.1111/j.2517-6161.1981.tb01155.x

[18] Song, J., Meng, C. and Ermon, S. (2021). Denoising diffusion implicit models. *International Conference on Learning Representations*. arXiv:2010.02502. https://arxiv.org/abs/2010.02502

[19] Song, Y., Sohl-Dickstein, J., Kingma, D. P., Kumar, A., Ermon, S. and Poole, B. (2021). Score-based generative modeling through stochastic differential equations. *International Conference on Learning Representations*. arXiv:2011.13456. https://arxiv.org/abs/2011.13456

[20] Higham, D. J. (2001). An algorithmic introduction to numerical simulation of stochastic differential equations. *SIAM Review* 43(3), 525–546. https://doi.org/10.1137/S0036144500378302
:::

# Appendix A Immutable C sharp reference kernel

The companion `cs/VerticalStack.cs` contains the .NET 8 kernel and `cs/Program.cs` its driver. Inputs and outputs use immutable arrays and records; numerical routines mutate only private work arrays. The kernel exposes schedule coefficients, separation weights, the noise budget, Gaussian reads, realised paths, tangent products, product bounds, log-volume, expanding directions and path curvature. Its core update is shown below; the complete definitions and validation driver accompany the paper.

```csharp
var read = Reads.At(acc.z, a, s);
var jac = Matrix.Identity(d).Combine(
    1 - lam[t], read.Covariance, lam[t] / (s * s));
var next = Enumerable.Range(0, d)
    .Select(j => (1 - lam[t]) * acc.z[j]
        + lam[t] * read.Mean[j]
        + (sig[t] > 0 ? sig[t] * noise[t - 1][j] : 0.0))
    .ToImmutableArray();
return (next, acc.steps.Add(
    new LayerStep(t, acc.z, read, jac)), jac.Times(acc.k));
```

The supplied C# output trace is compared with a fresh independent NumPy recomputation. All 18 lines agree under the declared relative tolerance $10^{-9}$; 16 are identical after rounding to 15 significant digits. The largest scaled discrepancy is 7.5 × 10⁻¹⁵. The residual line uses absolute scale one; other lines use the larger of the reference magnitude and $10^{-12}$. No fresh C# build was run in this revision, so this validates the supplied trace against NumPy rather than a new compiler execution.

The reference singular-value routine diagonalises $K^\top K$, which squares the condition number. It should not decide near-singular ranks. A production implementation should use direct SVD or a rank-revealing factorisation, report residuals and tolerances, and validate dimensions and finite inputs. The trace comparison exercises benign examples and is not a stability guarantee.

# Appendix B Reproducibility and evidence status

The rerun uses Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 and Matplotlib 3.10.8. The original supplied traces state a different runtime; both the archived results and the current results are retained. Random seeds identify streams and need not represent execution dates. The main and supplementary scripts are rerun from their fixed seeds. The pilot reruns all 60 archives, each with 1,000 paired tokens, across seven schedules and five layer counts. Independent archives execute in four worker processes, with deterministic instance seeds and ordered aggregation. Elapsed seconds are metadata and are excluded from numerical comparison.

The companion `reproduction.json` compares the new and supplied results, and `validation.json` records package and native-equation checks. Floating-point differences across runtime versions are reported rather than described as byte-identical reproduction. `p3_additions.py` records the changing-space construction, coupled stochastic refinement and finite-temperature counterexample. `cs_validate.py` recomputes every line of the supplied C# trace and verifies the line count and numeric tolerance.

The paper is assembled from Markdown with values populated from the result files. Pandoc creates editable native Word equations. The final package is checked for valid XML, internal relationships, numbering, figures and unfilled placeholders, then rendered and inspected page by page. These checks are not full OOXML schema validation. The scripts, results, figures, build files and mathematical review notes accompany the Word paper.
