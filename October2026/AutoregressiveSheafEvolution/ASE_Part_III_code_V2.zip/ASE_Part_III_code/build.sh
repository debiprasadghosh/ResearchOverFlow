#!/bin/sh
set -eu
cd "$(dirname "$0")"
ase_python="${ASE_PYTHON:-python3}"
"$ase_python" render.py
"$ase_python" build_docx.py
"$ase_python" verify.py
