"""Additional Part III checks for typed transport and the stochastic limit.

These finite computations support the constructions; they are not proofs of
convergence rates. Random seeds are identifiers, not calendar dates.
"""
from pathlib import Path
import json
import numpy as np
from p3_core import coefficients, reads, kde_sample

P=Path(__file__).resolve().parent
rng=np.random.default_rng(20261019)
out={}

# A fixed section subspace is compared across varying cochain dimensions.
err=square=resid=0.0
for _ in range(200):
    dims=[int(rng.integers(3,8)) for t in range(7)]
    U=[np.linalg.qr(rng.standard_normal((d,2)))[0] for d in dims]
    delta=[np.eye(d)-u@u.T for d,u in zip(dims,U)]
    A={};ms={};ns={};lam={}
    zstart=U[-1]@rng.standard_normal(2);z=zstart.copy()
    for t in range(6,0,-1):
        V=U[t-1]@U[t].T
        # delta[t-1] V = 0 = 0 delta[t], a chain map with zero edge map.
        square=max(square,float(np.linalg.norm(delta[t-1]@V)))
        lam[t]=float(rng.uniform(.05,.8));A[t]=(1-lam[t])*V
        ms[t]=U[t-1]@rng.standard_normal(2)
        ns[t]=.1*U[t-1]@rng.standard_normal(2)
        z=A[t]@z+lam[t]*ms[t]+ns[t]
        resid=max(resid,float(np.linalg.norm(delta[t-1]@z)))
    B=np.eye(dims[0]);recon=np.zeros(dims[0])
    for t in range(1,7):
        recon+=B@(lam[t]*ms[t]+ns[t]);B=B@A[t]
    recon+=B@zstart
    err=max(err,float(np.linalg.norm(recon-z)))
out['typed_transport']=dict(cases=200,unrolling_max_abs=err,
                           commuting_square_max_abs=square,section_residual_max_abs=resid)

# The finite-step coefficients have the declared infinitesimal drift and variance.
s=2.3;eta=.7;rows=[]
for h in [.08,.04,.02,.01,.005]:
    lam,gam=coefficients(np.array([s-h,s]),eta)
    rows.append(dict(h=h,drift_coefficient_error=float(abs(lam[1]/h-(1+eta**2)/s)),
                     variance_rate_error=float(abs(gam[1]**2/h-2*eta**2*s))))
assert all(rows[i+1]['drift_coefficient_error']<rows[i]['drift_coefficient_error'] for i in range(4))
assert all(rows[i+1]['variance_rate_error']<rows[i]['variance_rate_error'] for i in range(4))

# Coarse and fine stacks share the same Brownian path on a uniform scale grid.
Y=np.array([[-2.],[-.4],[1.2],[2.1]])
lw=np.log(np.array([.15,.3,.35,.2]));N=2000;Nref=4096
smax,smin=4.,.4;H=(smax-smin)/Nref
Z,_=kde_sample(Y,lw,smax,N,rng)
dB=np.sqrt(H)*rng.standard_normal((Nref,N,1))
def coupled(k):
    scales=np.linspace(smin,smax,k+1);lam,gam=coefficients(scales,eta)
    ratio=Nref//k;noise=dB.reshape(k,ratio,N,1).sum(1)
    z=Z.copy();h=(smax-smin)/k
    for j,t in enumerate(range(k,0,-1)):
        m,_=reads(z,Y,lw,scales[t])
        z=(1-lam[t])*z+lam[t]*m+gam[t]*noise[j]/np.sqrt(h)
    return z
ref=coupled(Nref)
strong=[dict(layers=k,rms_to_reference=float(np.sqrt(np.mean((coupled(k)-ref)**2))))
        for k in [16,32,64,128,256]]
assert strong[-1]['rms_to_reference']<strong[0]['rms_to_reference']
out['stochastic_limit']=dict(eta=eta,tokens=N,reference_layers=Nref,
                             coefficient_rows=rows,coupled_rows=strong,
                             all_coefficient_errors_decrease=True)

# A finite-temperature read can equal a central archive record without one-hot weights.
Q=np.array([[-1.],[0.],[1.]])
m,a=reads(np.zeros((1,1)),Q,np.zeros(3),1.)
assert m[0,0]==0 and np.all(a>0)
out['finite_blending']=dict(read=float(m[0,0]),minimum_weight=float(a.min()),
                            maximum_weight=float(a.max()))
(P/'p3_additions.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
