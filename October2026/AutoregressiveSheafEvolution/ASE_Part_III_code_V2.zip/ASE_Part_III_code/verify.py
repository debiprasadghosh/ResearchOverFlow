"""Numerical evidence and DOCX structure audit, not full schema validation."""
from pathlib import Path
import hashlib,json,posixpath,re,zipfile
from urllib.parse import unquote
from lxml import etree
from docx import Document
P=Path(__file__).resolve().parent
c=json.loads((P/'p3_checks.json').read_text());x=json.loads((P/'p3_extras.json').read_text());a=json.loads((P/'p3_additions.json').read_text());e=json.loads((P/'p3_explore.json').read_text());v=json.loads((P/'cs_validate.json').read_text())
assert len(c)==18 and len(x)==3 and len(a)==3
assert c['variance_bookkeeping']['lambda_in_unit_interval']
for group,key in [('hulls','identity_violations'),('layer_jacobian','bound_violations'),('causality_1d','violations')]:assert c[group][key]==0
for k,val in c['composite'].items():
 if k.endswith('violations'):assert val==0,(k,val)
assert c['morse']['agree']==c['morse']['stationary_points']
assert c['morse']['balanced_archives']==c['morse']['archives']
assert x['curvature_bound']['violations']==0
assert x['part_one']['lower_holds']==x['part_one']['upper_holds']==1000
assert v['lines']==v['agree']==18
assert a['typed_transport']['unrolling_max_abs']<1e-12
assert a['typed_transport']['section_residual_max_abs']<1e-12
assert a['stochastic_limit']['coupled_rows'][-1]['rms_to_reference']<a['stochastic_limit']['coupled_rows'][0]['rms_to_reference']
bar=[r for r in e['c3'] if r['schedule'] in ['barcode','barcode_coarse','barcode_mass']]
assert len(e['per_instance'])==60 and len(bar)==72 and all(r['verdict']=='refuted' for r in bar)
# Retain exact differences across runtimes, with elapsed time separated.
repro=dict(runtime=json.loads((P/'runtime.json').read_text()),main_receipt=json.loads((P/'rerun_receipt.json').read_text()),files={})
def diff(x,y,where=''):
 out=[]
 if isinstance(x,dict):
  assert x.keys()==y.keys(),where
  for k in x:out+=diff(x[k],y[k],where+'.'+k)
 elif isinstance(x,list):
  assert len(x)==len(y),where
  for i,(q,r) in enumerate(zip(x,y)):out+=diff(q,r,where+f'[{i}]')
 elif x!=y:out.append(dict(path=where,supplied=x,rerun=y))
 return out
for n in ['p3_checks.json','p3_extras.json','p3_explore.json','cs_validate.json']:
 delta=diff(json.loads((P/'archive'/n).read_text()),json.loads((P/n).read_text()))
 numerical=[d for d in delta if d['path']!='.seconds']
 repro['files'][n]=dict(sha256=hashlib.sha256((P/n).read_bytes()).hexdigest(),numeric_differences=numerical,metadata_differences=[d for d in delta if d['path']=='.seconds'])
assert len(repro['files']['p3_checks.json']['numeric_differences'])==4
assert not repro['files']['p3_extras.json']['numeric_differences']
assert not repro['files']['p3_explore.json']['numeric_differences']
(P/'reproduction.json').write_text(json.dumps(repro,indent=2)+'\n')
f=P/'output/ASE_Part_III_The_Vertical_Stack.docx'
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
with zipfile.ZipFile(f) as z:
 assert z.testzip() is None
 names=set(z.namelist());parts={n:etree.fromstring(z.read(n)) for n in names if n.endswith(('.xml','.rels'))}
 for n,root in parts.items():
  if not n.endswith('.rels'):continue
  base='' if n=='_rels/.rels' else posixpath.dirname(posixpath.dirname(n))
  for rel in root:
   if rel.get('TargetMode')=='External':continue
   t=unquote(rel.get('Target','')).split('#')[0]
   resolved=t.lstrip('/') if t.startswith('/') else posixpath.normpath(posixpath.join(base,t))
   assert not t or resolved in names,(n,resolved)
 root=parts['word/document.xml'];nums=[]
 for p in root.xpath('//w:p',namespaces=ns):
  style=p.xpath('./w:pPr/w:pStyle/@w:val',namespaces=ns)
  if style and style[0] in ['Equation','StatementEquation']:
   txt=''.join(p.xpath('.//w:t/text()',namespaces=ns));m=re.search(r'\((\d+\.\d+)\)\s*$',txt)
   if m:nums.append(m[1])
 expected=['1.1']+[f'2.{i}' for i in range(1,7)]+[f'3.{i}' for i in range(1,10)]+[f'4.{i}' for i in range(1,4)]+[f'5.{i}' for i in range(1,6)]
 assert nums==expected,(nums,expected)
 math=len(root.xpath('//m:oMath',namespaces=ns));assert math>300
 assert len(root.xpath('//w:drawing',namespaces=ns))==5
 tables=root.xpath('//w:tbl',namespaces=ns);assert len(tables)==6
 for t in tables:
  assert set(t.xpath('./w:tblPr/w:tblBorders/*/@w:color',namespaces=ns))=={'D9D9D9'}
  assert t.xpath('./w:tr[1]/w:trPr/w:tblHeader',namespaces=ns)
 txt=''.join(root.xpath('//w:t/text()',namespaces=ns));assert not re.search(r'\{\{[^}]+\}\}|\\(?:frac|begin|text)\b',txt)
 assert 'refutes C3' not in txt and 'refuted hypothesis C3' not in txt
 assert not root.xpath('//w:pPr/w:pBdr',namespaces=ns)
D=Document(f);assert D.sections[0].page_width.inches==8.5 and D.sections[0].page_height.inches==11
report=dict(file=f.name,sha256=hashlib.sha256(f.read_bytes()).hexdigest(),zip_integrity=True,XML_parts=len(parts),internal_relationships_resolve=True,numbered_equations=nums,native_math_objects=math,figures=5,tables=6,construction_check_groups=24,pilot_archive_instances=60,barcode_pilot_failures=72,supplied_Csharp_trace_lines_match=18,fresh_Csharp_compilation=False,full_OOXML_schema_validation=False)
(P/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
