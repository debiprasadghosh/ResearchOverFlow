"""Execute each main check and checkpoint the result after its completion."""
import json,time
from pathlib import Path
import numpy as np
import p3_checks as C
P=Path(__file__).resolve().parent
functions=[C.check_variance_bookkeeping,C.check_separation,C.check_noise_budget,C.check_deterministic_weights,C.check_ade_stack,C.check_euler_identity,C.check_continuum,C.check_clean_top,C.check_hulls,C.check_layer_jacobian,C.check_composite,C.check_morse,C.check_bifurcation,C.check_causality_1d,C.check_triangle,C.check_effective_rank,C.check_euler_density,C.check_components_vs_modes]
started=time.time();done=[]
for fn in functions:
 fn();done.append(fn.__name__)
 (P/'rerun_progress.json').write_text(json.dumps(dict(completed=done,elapsed_seconds=time.time()-started)))
 print(fn.__name__,round(time.time()-started,2),flush=True)
(P/'p3_checks.json').write_text(json.dumps(C.R,indent=1,default=lambda o:o.tolist() if hasattr(o,'tolist') else int(o) if isinstance(o,np.integer) else str(o)))
(P/'rerun_receipt.json').write_text(json.dumps(dict(complete=True,check_groups=len(done),elapsed_seconds=time.time()-started),indent=2))
