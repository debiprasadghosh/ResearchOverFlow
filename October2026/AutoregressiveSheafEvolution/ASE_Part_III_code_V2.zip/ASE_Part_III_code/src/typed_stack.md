
## 2.1 The recurrence on sheaf data spaces

The calculations below use a common vector space only after its coordinates and metric have been fixed. For engineering variables, first select units or nondimensionalisation, then define norms and residuals. Singular values depend on this metric choice; algebraic rank does not. A stalk is one data space. The token carries a vertical fibre diagram, or the tangent diagram of its realised nonlinear path, rather than being a single stalk stretched through the layers.

Keep four bases distinct. The cover nerve describes spatial overlap; the variable-context base describes partial observations; the observation star describes one read; the layer order describes computation. Components of a cover nerve, cohomology with sheaf coefficients and tangents of token updates are different diagrams. A map between them requires a construction.

On a fixed base let $r^t_{ve}:F_t(v)\to F_t(e)$ be a horizontal restriction. A linear vertical morphism has components $P_t^v$ and $P_t^e$ satisfying

::: {custom-style="Equation"}
$r^{t-1}_{ve}P_t^v=P_t^e r^t_{ve}$ (2.4)
:::

Every relevant square must commute. On changing bases with $\Phi_t:X_t\to X_{t-1}$, the typed arrow is $F_t\to\Phi_t^{-1}F_{t-1}$; its stalk at $x$ maps to the target stalk at $\Phi_t(x)$. The inverse image is a sheaf operation and does not require an inverse function. Common refinements or declared correspondences are needed for unrelated learned covers. Only a compatible fixed-base diagram supports the product-sheaf interpretation of Part I.

::: {custom-style="Statement"}
**Proposition 2.4** (transported separation and compatibility). Let $P_t:V_t\to V_{t-1}$ be fixed linear maps and $\lambda_t$ deterministic schedule coefficients. Put $b_t=\lambda_t m_t+\nu_t\in V_{t-1}$, $A_t=(1-\lambda_t)P_t$ and $B_t=A_1\cdots A_{t-1}$, with $B_1=I_{V_0}$. Then the recurrence $z_{t-1}=A_tz_t+b_t$ has the pathwise identity
:::

::: {custom-style="Statement Equation"}
$z_0=A_1\cdots A_Tz_T+\sum_{t=1}^T B_t b_t$ (2.5)
:::

::: {custom-style="Statement"}
If $V_t$ are cochain spaces with coboundaries $\delta_t$ and $\delta_{t-1}P_t=Q_t\delta_t$, then compatible $z_T$, $m_t$ and $\nu_t$ produce compatible states at every step. If $\nu_t=G_t\xi_t$ with deterministic $G_t$, independent standard Gaussian $\xi_t$ and deterministic transports, the explicit noise term has covariance
:::

::: {custom-style="Statement Equation"}
$\operatorname{Cov}\!\left(\sum_t B_tG_t\xi_t\right)=\sum_tB_tG_tG_t^\top B_t^\top$ (2.6)
:::

::: {custom-style="Statement Tag"}
Derived here from affine unrolling and the chain-map identity. Fixed transports are essential to the unconditional Gaussian assertion.
:::

*Proof.* Substitute the recurrence successively, preserving the order of the matrix products, to obtain (2.5). Applying $\delta_{t-1}$ gives $(1-\lambda_t)Q_t\delta_tz_t+\lambda_t\delta_{t-1}m_t+\delta_{t-1}\nu_t=0$, proving compatibility by induction. Independence and deterministic coefficients eliminate cross-covariances in (2.6). ∎

With $P_t=I$, the products become the scalar coefficients of Theorem 3.1. General transports produce matrix weights, so a common-frame convex-hull interpretation and the scalar budget (3.2) require additional assumptions. Compatible Gaussian noise must satisfy $\delta_{t-1}G_t=0$. Independent noise in every local view usually violates this condition; shared views of one token may require correlated innovations. Different generated tokens can still use independent noise.

For state-dependent transports, (2.5) remains an algebraic identity along a realised path, but its random matrix coefficients need not yield a Gaussian explicit term. Differentiation also produces derivatives of the transports. An arbitrary harmonic read is not automatically compatible with every other horizontal constraint. Compatibility must be imposed by a joint section solve or measured explicitly.

*Numerical check.* In {{a.typed_transport.cases}} varying-dimensional chains, transported unrolling had maximum absolute discrepancy {{a.typed_transport.unrolling_max_abs|e1}}. The largest commuting defect was {{a.typed_transport.commuting_square_max_abs|e1}} and the largest section residual {{a.typed_transport.section_residual_max_abs|e1}}.
