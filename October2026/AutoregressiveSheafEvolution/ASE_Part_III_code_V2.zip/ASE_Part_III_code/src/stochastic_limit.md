
## 3.4 The stochastic continuum limit

::: {custom-style="Statement"}
**Theorem 3.8** (stochastic limit at positive cutoffs). Fix a finite Gaussian archive, query-independent positive weights, $0<s_{\min}<s_{\max}<\infty$ and $\eta\in[0,1]$. Put $u=s_{\max}-s$ and couple every layer innovation to a Brownian increment over its interval of length $h_t=s_t-s_{t-1}$. As $h_{\max}\to0$, the stack converges to
:::

::: {custom-style="Statement Equation"}
$\mathrm dZ_u=\frac{(1+\eta^2)(m(Z_u,s)-Z_u)}{s}\,\mathrm du+\eta\sqrt{2s}\,\mathrm dB_u$ (3.7)
:::

::: {custom-style="Statement"}
For a square-integrable common initial state, the mean squared error maximised over grid times is at most $C h_{\max}$ for a constant depending on the fixed cutoffs, archive and initial second moment. If $Z_0\sim p_{s_{\max}}$, the SDE has marginal density $p_s$ at scale $s$. At $\eta=0$ it is the deterministic probability flow, whose stronger first-order rate is given by Theorem 3.5.
:::

::: {custom-style="Statement Tag"}
Derived here for the stated coefficient family using standard Euler–Maruyama convergence [20]. The marginal family is the score-SDE probability-flow family [1, 19]. No rate uniform in a vanishing cutoff is asserted.
:::

*Proof.* Uniformly for $s\in[s_{\min},s_{\max}]$, Taylor expansion of (2.1) gives

::: {custom-style="Equation"}
$\lambda_t=(1+\eta^2)h_t/s_t+O(h_t^2),\qquad \gamma_t^2=2\eta^2s_th_t+O(h_t^2)$ (3.8)
:::

For fixed $\eta>0$, $\gamma_t/\sqrt{h_t}=\eta\sqrt{2s_t}+O(h_t)$; for $\eta=0$ both diffusion coefficients vanish. The drift of (3.7) is globally Lipschitz in $z$, because $D_zm=C/s^2$ is uniformly bounded by $R^2/(4s_{\min}^2)$, and it has linear growth because $m$ lies in a fixed compact hull. Its coefficients are regular in time on the stated interval. Euler–Maruyama therefore has mean-square order one half in root error [20]. Compared with its update, the stack has drift coefficient error $O(h_t^2)(1+\|Z\|)$ and deterministic diffusion coefficient error $O(h_t)$ multiplying the Brownian increment. Bounded second moments, martingale orthogonality and discrete Gronwall show that these perturbations have mean squared grid error $O(h_{\max}^2)$. Combining the two estimates proves the stated, conservative $O(h_{\max})$ mean squared bound.

For the marginal statement, write the drift as $(1+\eta^2)s\nabla\log p_s$. Its Fokker–Planck right side, evaluated at $p_s$, is

::: {custom-style="Equation"}
$-(1+\eta^2)s\Delta p_s+\eta^2s\Delta p_s=-s\Delta p_s=\partial_u p_s$ (3.9)
:::

The initial law matches, and uniqueness for the stated globally Lipschitz diffusion identifies its marginals. ∎

This result justifies a continuum sampling law at positive cutoffs. It does not make a finite multi-record stack an exact sampler, and it does not identify a fitness-driven changing archive with one fixed forward diffusion. At a clean top, first take the positive-scale limit, then the limit in Proposition 3.6.

*Numerical check.* With $\eta={{a.stochastic_limit.eta}}$, {{a.stochastic_limit.tokens}} shared initial tokens and Brownian paths, the root mean squared differences from a {{a.stochastic_limit.reference_layers}}-layer stack were {{a.stochastic_limit.coupled_rows.0.rms_to_reference|f4}}, {{a.stochastic_limit.coupled_rows.1.rms_to_reference|f4}}, {{a.stochastic_limit.coupled_rows.2.rms_to_reference|f4}}, {{a.stochastic_limit.coupled_rows.3.rms_to_reference|f4}} and {{a.stochastic_limit.coupled_rows.4.rms_to_reference|f4}} at 16, 32, 64, 128 and 256 layers. This checks refinement behaviour against a finite reference, not the asymptotic rate theorem itself.
