
# 6 Register of numerical checks

Table 5 lists every numerical check in Part III. The main script supplies {{d.n_main}} groups, the supplementary script {{d.n_extra}} and the added script three; the pilot of Section 5.3 and the kernel comparison of Appendix A complete the list. All scripts write machine-readable results, and every number in this paper is drawn from the saved result files or stated mathematical constants; computed tables are populated when the document is built. The checks test the implementations and illustrate the statements; the proofs establish them. Random archives are synthetic, so ratios to bounds describe these constructions, not engineering archives in general.

Table: **Table 5.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 2.2 | coefficients, {{c.variance_bookkeeping.schedules}} schedules | bookkeeping {{c.variance_bookkeeping.max_rel_err\|e1}}; (19.2) to {{c.variance_bookkeeping.coefficient_err\|e1}} |
| 2 | Proposition 2.3 | ADE recovery, {{c.ade_stack.cases}} stacks | {{c.ade_stack.max_rel_err\|e1}} |
| 3 | Theorem 3.1 | separation, {{c.separation.cases}} paths | {{c.separation.max_rel_err\|e1}} |
| 4 | Theorem 3.2 | noise budget, {{c.noise_budget.schedules}} schedules; oracle | {{c.noise_budget.max_rel_err\|e1}}; output deviation within 0.3% of $s_0$ |
| 5 | Corollary 3.3 | deterministic weights, cosine table | {{c.deterministic_weights.omega_err\|e1}}; V2 table reproduced |
| 6 | Proposition 3.4 | Euler and score forms, {{c.euler_identity.cases}} layers | {{c.euler_identity.max_err\|e1}} |
| 7 | Theorem 3.5 | continuum limit, 40,000 tokens | KS {{d.ks4\|f3}} to {{d.ks256\|f4}} from 4 to 256 layers |
| 8 | Proposition 3.6 | clean-top re-selection | {{d.clean_share\|pct1}} within $10^{-6}$; frequencies within {{c.clean_top.max_frequency_error\|f4}} |
| 9 | Proposition 3.7 | hulls, {{c.hulls.identity_cases}} and {{c.hulls.masked_cases}} stacks | {{c.hulls.identity_violations}} identity outputs outside; {{c.hulls.masked_outside}} masked outputs outside |
| 10 | Proposition 4.1 | layer Jacobian, {{c.layer_jacobian.cases}} layers | {{c.layer_jacobian.fd_rel_err\|e1}}; {{c.layer_jacobian.bound_violations}} bound violations |
| 11 | Theorem 4.2 | composites, {{c.composite.cases}} and {{c.composite.noisy_cases}} stacks | {{c.composite.floor_violations}} violations; floor attained; volume {{c.composite.volume_err\|e1}} |
| 12 | Corollary 4.3 | clean-top sandwich; Part I replayed | {{c.composite.clean_lower_violations}} and {{c.composite.clean_upper_violations}} violations; {{x.part_one.lower_holds}} of {{x.part_one.tokens}} tokens |
| 13 | Proposition 4.4(i), (ii) | Morse index and balance, {{c.morse.archives}} archives | {{c.morse.agree}} of {{c.morse.stationary_points}} points; {{c.morse.balanced_archives}} balanced |
| 14 | Proposition 4.4(iii), Example 4.5 | pitchfork and fold | tangent {{c.bifurcation.equal_tangent_at_midpoint\|f4}}; fold at {{c.bifurcation.unequal_fold_scale\|f4}} |
| 15 | Proposition 4.6 | thresholded ranks, {{c.effective_rank.random_chains}} chains; Part I | {{c.effective_rank.chains_with_negative_multiplicity}} negative; tight tolerance {{c.effective_rank.exact_negative}}; {{d.neg_1e2}} tokens at $10^{-2}$ |
| 16 | Proposition 5.2 | one-dimensional modes, {{c.causality_1d.archives}} archives | {{c.causality_1d.violations}} increases |
| 17 | Example 5.3 | triangle counts and Morse balance | four modes from 0.41 to 0.425; fold {{x.triangle_morse.fold_scale\|f4}} |
| 18 | Section 5.1 | components against modes, {{c.components_vs_modes.pairs}} pairs | {{c.components_vs_modes.share\|pct1}} agree |
| 19 | Theorem 5.4(i) | path curvature, {{c.euler_density.points}} points | median {{c.euler_density.median_rel_err\|e1}}; forms {{c.euler_density.moment_form_err\|e1}} |
| 20 | Theorem 5.4(ii) | curvature bound, {{x.curvature_bound.cases}} cases | {{x.curvature_bound.violations}} violations; largest ratio {{x.curvature_bound.ratio_max\|f4}} |
| 21 | Proposition 5.5 | efficiency against loss, pilot | {{d.eff_rank_text}} |
| 22 | Section 5.3 | C3 pilot, {{d.pilot_instances}} archives | {{d.c3_summary}} |
| 23 | Appendix A | supplied C# trace against fresh NumPy | {{v.agree}} of {{v.lines}} lines agree; {{v.identical}} identical to 15 digits |
| 24 | Proposition 2.4 | {{a.typed_transport.cases}} typed chains | unrolling {{a.typed_transport.unrolling_max_abs\|e1}}; compatible states |
| 25 | Theorem 3.8 | coupled Brownian refinements | RMS {{a.stochastic_limit.coupled_rows.0.rms_to_reference\|f4}} to {{a.stochastic_limit.coupled_rows.4.rms_to_reference\|f4}} |
| 26 | Section 4.5 | finite-temperature equality with a record | positive weights; mean equals central record |

# 7 Discussion

## 7.1 What Part III supplies to the rest of the book

Part IV, on targets and estimation, needs the law of the proposals. Theorem 3.5 identifies it in the continuum limit: a deterministic stack with identity maps proposes from $p_{s_0}$, the archive density at the top scale. Its discretisation error is controlled by the curvature of Theorem 5.4. With a clean top, Proposition 3.6 gives archive re-selection in its iterated limit. The noise budget identifies an explicit, generally read-correlated Gaussian term for deterministic schedule coefficients. Theorem 3.8 gives the stochastic limiting law under its separate assumptions. These are the facts an importance weight or a Gibbs target must be built on.

Part V, on fusion and constraints, needs end-to-end sensitivities. Theorem 4.2 gives two-sided bounds for every singular value of a composite. Corollary 4.3 shows that at a clean top the singular values of the composite are bracketed by corresponding top-covariance eigenvalues and explicit factors, so the sensitivity of an output design to its starting query is decided by how concentrated the last read is. Part VI, on evidence and computation, takes the diagnostics of Table 6 and the kernel of Appendix A as specifications.

For the hypotheses of V2, the pilot of Section 5.3 bears on C3, and Proposition 5.5 gives it a quantitative form: whether a schedule can halve its layers depends on the efficiency of the baseline, which the archive can estimate within the continuum surrogate; actual endpoint error also involves propagation and the clean-top map.

## 7.2 Diagnostics a stack should report

Table: **Table 6.** Diagnostics reported with every stack.

| Diagnostic | Source | Action when it is poor |
|:-------------------|:-------------------|:-------------------------------|
| weight $\omega_\star$ and the noise budget split | Theorem 3.2 | report both shares of $s_0^2$ |
| eigenvalues of the top posterior covariance and the excess $X$ | Corollary 4.3 | report with every sensitivity claim |
| layers where $c>s^2$ along each path | Proposition 4.1 | report expanding directions with their scale and tolerance |
| exact barcode and singular-value profile | Proposition 4.6 | never report a thresholded barcode |
| component barcode, not mode counts, in two or more dimensions | Proposition 5.1, Example 5.3 | use modes only as a proxy, with its agreement rate |
| curvature density $g$ and schedule efficiency $e$ | Proposition 5.5 | test curvature allocation with its construction cost included |
| re-selection share and the size of each novelty channel | Propositions 3.6, 3.7 | report the accounting terms and their dependence |

## 7.3 What is not claimed

The Gaussian transport statements use a fixed identity-map archive. General harmonic reads need not equal a score displacement; changing masks, maps or priors requires a separate probability model and its consistency across scales. The deterministic limit has first-order error on fixed positive intervals. The stochastic theorem states a conservative root mean square order of one half; neither rate is uniform down to zero. Theorem 3.8 proves stochastic convergence at fixed positive cutoffs under its stated coupling and regularity assumptions; it does not cover a simultaneous zero-cutoff limit. The error model of Proposition 5.5 omits error propagation and is tested only empirically. The pilot is exploratory: it uses a transport metric instead of the optimisation outcomes of V2, and it does not settle C3. No statement here concerns search performance.

## 7.4 Open problems

1. **The vanishing cutoff.** Extend Theorem 3.8 to a simultaneous shrinking finest scale and refined mesh, with bounds on constants that diverge near zero.
2. **Transport with maps.** Characterise mapped read displacements that are gradients of log densities and whose marginals agree with one forward process. A harmonic normal equation alone does not provide either condition.
3. **Propagation-aware schedules.** Weight the curvature density by the composite tangents of Theorem 4.2, and compare with second-order layers that spend two reads per step.
4. **Mode zigzags.** Describe the births and deaths of modes across scales in two and more dimensions as a zigzag module, using the eigenvalue-one crossings of Proposition 4.4.
5. **A stable sensitivity summary.** Find a summary of numerical sensitivity along a tangent diagram that is stable under perturbation and consistent with rank invariants.
6. **C3 in the optimisation setting.** Run the confirmatory C3 protocol of V2, with output loss on the design objective, and add the curvature schedule as a declared comparator.

## 7.5 Consequences for the remaining book

A stack of ASE layers is a schedule acting on reads. The schedule fixes how outputs mix starting state, reads and noise, and it fixes the noise budget. In the continuum limit the deterministic stack transports the coarse archive density to the fine one, and a clean top turns it into a weighted re-selection of the archive. Tangents never contract below the schedule's own ratio except at the top read, and they expand exactly where the energy has negative curvature, while stationary-point bifurcations require the boundary where the corresponding eigenvalue reaches one. Components form a filtration across layers; modes do not, and thresholded ranks do not either. Posterior concentration controls path curvature on a fixed positive scale interval, which tells a schedule where its layers matter. {{d.conclusion_pilot}} Part IV now turns from the stack to the targets it serves.

# References

::: {custom-style="Bibliography"}
[1] Anderson, B. D. O. (1982). Reverse-time diffusion equation models. *Stochastic Processes and their Applications* 12(3), 313–326.

[2] Babaud, J., Witkin, A. P., Baudin, M. and Duda, R. O. (1986). Uniqueness of the Gaussian kernel for scale-space filtering. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 8(1), 26–33.

[3] Carlsson, G. (2009). Topology and data. *Bulletin of the American Mathematical Society* 46(2), 255–308.

[4] Carreira-Perpiñán, M. Á. and Williams, C. K. I. (2003a). On the number of modes of a Gaussian mixture. In *Scale Space Methods in Computer Vision*, Lecture Notes in Computer Science 2695, 625–640. Springer.

[5] Carreira-Perpiñán, M. Á. and Williams, C. K. I. (2003b). An isotropic Gaussian mixture can have more modes than components. Technical report EDI-INF-RR-0185, School of Informatics, University of Edinburgh. https://www.inf.ed.ac.uk/publications/report/0185.html

[6] Efron, B. (2011). Tweedie's formula and selection bias. *Journal of the American Statistical Association* 106(496), 1602–1614.

[7] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[8] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[9] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[10] Ghosh, D. P. (2026d). *Horizontally Topological, Vertically Algebraic: The Two Axes of Autoregressive Sheaf Evolution. Part I: Sheaves on Covers and Representations of the Layer Order*. 18 October 2026.

[11] Ghosh, D. P. (2026e). *The Horizontal Layer: One Layer of Autoregressive Sheaf Evolution. Part II: Sheaf Attention, Gaussian Stalks, Locality and the Topology of Design Spaces*. 18 October 2026.

[12] Hairer, E., Nørsett, S. P. and Wanner, G. (1993). *Solving Ordinary Differential Equations I: Nonstiff Problems*, 2nd revised edn. Springer Series in Computational Mathematics 8. Springer.

[13] Horn, R. A. and Johnson, C. R. (1991). *Topics in Matrix Analysis*. Cambridge University Press.

[14] Karras, T., Aittala, M., Aila, T. and Laine, S. (2022). Elucidating the design space of diffusion-based generative models. *Advances in Neural Information Processing Systems* 35. arXiv:2206.00364. https://arxiv.org/abs/2206.00364

[15] Lu, C., Zhou, Y., Bao, F., Chen, J., Li, C. and Zhu, J. (2022). DPM-Solver: a fast ODE solver for diffusion probabilistic model sampling in around 10 steps. *Advances in Neural Information Processing Systems* 35. arXiv:2206.00927. https://arxiv.org/abs/2206.00927

[16] Milnor, J. W. (1965). *Topology from the Differentiable Viewpoint*. University Press of Virginia.

[17] Silverman, B. W. (1981). Using kernel density estimates to investigate multimodality. *Journal of the Royal Statistical Society, Series B* 43(1), 97–99. https://doi.org/10.1111/j.2517-6161.1981.tb01155.x

[18] Song, J., Meng, C. and Ermon, S. (2021). Denoising diffusion implicit models. *International Conference on Learning Representations*. arXiv:2010.02502. https://arxiv.org/abs/2010.02502

[19] Song, Y., Sohl-Dickstein, J., Kingma, D. P., Kumar, A., Ermon, S. and Poole, B. (2021). Score-based generative modeling through stochastic differential equations. *International Conference on Learning Representations*. arXiv:2011.13456. https://arxiv.org/abs/2011.13456

[20] Higham, D. J. (2001). An algorithmic introduction to numerical simulation of stochastic differential equations. *SIAM Review* 43(3), 525–546. https://doi.org/10.1137/S0036144500378302
:::

# Appendix A Immutable C sharp reference kernel

The companion `cs/VerticalStack.cs` contains the .NET 8 kernel and `cs/Program.cs` its driver. Inputs and outputs use immutable arrays and records; numerical routines mutate only private work arrays. The kernel exposes schedule coefficients, separation weights, the noise budget, Gaussian reads, realised paths, tangent products, product bounds, log-volume, expanding directions and path curvature. Its core update is shown below; the complete definitions and validation driver accompany the paper.

```csharp
var read = Reads.At(acc.z, a, s);
var jac = Matrix.Identity(d).Combine(
    1 - lam[t], read.Covariance, lam[t] / (s * s));
var next = Enumerable.Range(0, d)
    .Select(j => (1 - lam[t]) * acc.z[j]
        + lam[t] * read.Mean[j]
        + (sig[t] > 0 ? sig[t] * noise[t - 1][j] : 0.0))
    .ToImmutableArray();
return (next, acc.steps.Add(
    new LayerStep(t, acc.z, read, jac)), jac.Times(acc.k));
```

The supplied C# output trace is compared with a fresh independent NumPy recomputation. All {{v.lines}} lines agree under the declared relative tolerance $10^{-9}$; {{v.identical}} are identical after rounding to 15 significant digits. The largest scaled discrepancy is {{v.worst_rel_diff|e1}}. The residual line uses absolute scale one; other lines use the larger of the reference magnitude and $10^{-12}$. No fresh C# build was run in this revision, so this validates the supplied trace against NumPy rather than a new compiler execution.

The reference singular-value routine diagonalises $K^\top K$, which squares the condition number. It should not decide near-singular ranks. A production implementation should use direct SVD or a rank-revealing factorisation, report residuals and tolerances, and validate dimensions and finite inputs. The trace comparison exercises benign examples and is not a stability guarantee.

# Appendix B Reproducibility and evidence status

The rerun uses Python {{env.python}}, NumPy {{env.numpy}}, SciPy {{env.scipy}} and Matplotlib {{env.matplotlib}}. The original supplied traces state a different runtime; both the archived results and the current results are retained. Random seeds identify streams and need not represent execution dates. The main and supplementary scripts are rerun from their fixed seeds. The pilot reruns all 60 archives, each with 1,000 paired tokens, across seven schedules and five layer counts. Independent archives execute in four worker processes, with deterministic instance seeds and ordered aggregation. Elapsed seconds are metadata and are excluded from numerical comparison.

The companion `reproduction.json` compares the new and supplied results, and `validation.json` records package and native-equation checks. Floating-point differences across runtime versions are reported rather than described as byte-identical reproduction. `p3_additions.py` records the changing-space construction, coupled stochastic refinement and finite-temperature counterexample. `cs_validate.py` recomputes every line of the supplied C# trace and verifies the line count and numeric tolerance.

The paper is assembled from Markdown with values populated from the result files. Pandoc creates editable native Word equations. The final package is checked for valid XML, internal relationships, numbering, figures and unfilled placeholders, then rendered and inspected page by page. These checks are not full OOXML schema validation. The scripts, results, figures, build files and mathematical review notes accompany the Word paper.
