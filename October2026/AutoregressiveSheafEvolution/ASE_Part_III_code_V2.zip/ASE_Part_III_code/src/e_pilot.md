
## 5.3 An exploratory pilot of hypothesis C3

V2 states hypothesis C3 as follows: a $k$-layer schedule chosen from component persistence scales matches a $2k$-layer cosine schedule within 2% in declared output loss and novel-output share, on frozen multimodal families in dimensions 2, 4 and 8, with shared endpoint and cutoff rules; a $k$-layer geometric schedule is the control for layer thinning [9, Section 18]. The confirmatory test needs the optimisation families and output losses of V2. In the transport setting of Theorem 3.5, however, the quality of a schedule can be assessed against a finely resolved reference flow from the same starting tokens. We ran that comparison as an exploratory pilot. The supplied script records the metrics, seeds and decision rule. Its comments describe changes after an initial trial: an archive-only curvature estimate replaced a flow estimate, and mass weighting was added. There was no independent preregistration. We rerun the final seven-schedule protocol and report it as exploratory.

**Families and shared rules.** In each dimension $D\in\{2,4,8\}$ we froze {{e.instances}} archives of 27 records in three nested levels of clusters, with spreads 4, 1 and 0.25 before normalising to unit pooled deviation per coordinate, and log prior weights with standard deviation 0.5. Every schedule has a clean top, $s_0=0$, the coarse start $s_k$ equal to twice the largest merge radius, and a common finest positive scale $s_1$. With a *fine top*, $s_1$ is half the smallest merge radius, to give a finer geometric cutoff. This does not guarantee a one-hot final posterior. With a *coarse top*, $s_1$ is the median merge radius. {{e.tokens}} tokens per archive were drawn from $p_{s_k}$ and shared by all schedules, so every comparison is paired. The reference output of a token is the clean-top read at $s_1$ of a numerical reference for the flow (3.5), integrated by the classical Runge–Kutta method in $\log s$ with step {{e.rk4_step}}; on one instance in each dimension, halving the step moved the reference outputs by at most {{d.ref_dev_max|e1}} nearest-neighbour distances.

Table: **Table 2.** Schedules in the pilot. All share $s_0=0$, $s_1$ and $s_k$; the rules place the $k-2$ interior scales.

| Schedule | Interior scales | Role |
|:---------------|:------------------------------------|:-----------------------|
| cosine | $\arctan s$ uniformly spaced | the C3 baseline, at $2k$ layers |
| geometric | $\log s$ uniformly spaced | the C3 control for thinning |
| EDM, $\rho=7$ | $s^{1/7}$ uniformly spaced [14] | a common sampler schedule |
| barcode, quantiles | merge radii at evenly spaced ranks | the C3 schedule |
| barcode, longest bars | the $k-2$ largest merge radii | a second reading of C3 |
| barcode, mass-weighted | quantiles of merge radii weighted by the mass of the merged component at that height | added after the trial |
| curvature | density proportional to $\sqrt g$, with $g$ from 300 draws of $p_s$ at {{e.curvature_grid}} scales | Proposition 5.5, archive only |

**Metrics.** The *path loss* is the mean distance between a schedule's output and the reference output, in units of the median nearest-neighbour distance $d_{nn}$ of the records. The *novel-output share* is the share of outputs farther than $10^{-3}d_{nn}$ from every record. For C3 we compared each barcode schedule with $k$ layers against cosine with $2k$ layers, for $k=4$, 8, 16 and 32. Degradation is the ratio of archive-mean losses minus one, and the novelty difference is in percentage points; both carry paired bootstrap 95% intervals over the archives, with 10,000 resamples. A comparison *meets the pilot margin* if the loss interval lies below +2% and the novelty interval within ±2 points. It *fails the pilot margin* if the loss interval lies above +2% or the novelty interval lies outside ±2 points. Otherwise it is *inconclusive*. These are pointwise descriptive intervals; no simultaneous confirmatory inference about C3 is made. Curvature estimation uses {{d.curvature_queries}} additional archive-read queries per archive. That construction cost is excluded from the plotted layer count, so equal-layer path loss does not establish an end-to-end computational gain.

Table: **Table 3.** Path loss pooled over $D=2$, 4 and 8, by schedule and number of layers $k$, with a fine top; the median discrete efficiency proxy from Proposition 5.5 at $k=16$; and the loss at $k=16$ with a coarse top.

| Schedule | $k=4$ | 8 | 16 | 32 | 64 | $e$ | coarse top |
|:----------------------|:------|:------|:------|:------|:------|:-----|:----------|
{{table:loss}}

Table: **Table 4.** The transport comparison motivated by C3 with a fine top: the barcode schedule with quantile placement and $k$ layers against cosine with $2k$ layers. Intervals are paired bootstrap 95% intervals. The last two columns give the degradation of the same barcode schedule against geometric with $k$ layers, and of the curvature schedule with $k$ layers against cosine with $2k$ layers.

| $D$ | $k$ | loss degradation, % | novelty difference, points | verdict | against geometric, % | curvature against cosine, % |
|:--|:--|:----------------|:----------------|:--------|:----------|:----------|
{{table:c3}}

{{file:src/pilot_results.md}}

![**Figure 5.** The schedule pilot. (a) For one archive in $ℝ^2$: the square root of the curvature density $g$, the 26 merge radii, and the scales of the seven schedules with eight layers. Most merge radii are fine, while most curvature lies at coarse scales. (b) Path loss against the number of layers, pooled over $D=2$, 4 and 8, with a fine top. (c) The transport comparison motivated by C3: loss of the quantile barcode schedule and of the curvature schedule with $k$ layers, divided by the loss of cosine with $2k$ layers, with bootstrap 95% intervals; the dashed line is the 2% margin. (d) For every archive and $k=8$, 16 and 32, the error model (5.4) of each schedule against its path loss, both relative to cosine with the same $k$.](fig/schedules.png){width=100%}
