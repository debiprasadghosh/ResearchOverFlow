
## 4.5 What the exact tangent diagram records

::: {custom-style="Statement"}
**Proposition 4.7** (clean-top intervals and positive-cutoff invertibility). For a fixed identity-map archive, all lower maps $J_t$, $t\ge2$, are invertible. If the clean-top map $J_1$ has rank $r$, its tangent diagram on $V_T\to\cdots\to V_0$, with $V_t=\mathbb R^D$, has $r$ full intervals, $D-r$ intervals ending at layer 1 and $D-r$ intervals supported only at layer 0. If $s_0>0$, every finite realised stack with additive noise held fixed is a global smooth diffeomorphism of $\mathbb R^D$.
:::

::: {custom-style="Statement Tag"}
The interval statement is Part I specialised to this stack. The global statement is derived here for a fixed archive and positive cutoff, without chart switching.
:::

*Proof.* Lower maps have $\lambda_t<1$, so (4.1) is positive definite. Identify all lower spaces through these isomorphisms. The only remaining map is a rank-$r$ map into $V_0$; choose bases putting it into a rank-normal form. Its reached directions give full intervals, its kernel gives intervals ending before the top, and its cokernel gives the isolated top intervals.

At positive cutoff every layer has $\lambda_t<1$. Its map $F(z)=(1-\lambda)z+\lambda m(z)+\nu$ is the gradient of a smooth function with Hessian $J\succeq(1-\lambda)I$. Thus $F$ is strongly monotone and injective. For any target $b$, the strongly convex potential minus $b^\top z$ is coercive and has a unique minimiser, so $F(z)=b$ is solvable. Its derivative is invertible everywhere, giving a smooth inverse. Composition proves the stack claim. ∎

With positive finite Gaussian weights, $r$ equals the affine dimension of the records. A full-span archive therefore has $D$ full bars even at a clean top, however small its singular values become. Numerical zeros and underflow do not prove exact interval deaths. The $D-r$ terminal births in a rank-deficient example represent output directions not reached by perturbations from lower layers.

For a positive-cutoff deterministic stack, or conditional on a fixed innovation path, the change-of-variables formula gives the endpoint density through the inverse map and $|\det K|$. The unconditional noisy law requires integration over innovation paths; the explicit Gaussian term of Theorem 3.2 cannot be substituted as an independent output convolution. Across changing charts or branches, the relevant Jacobians and branch probabilities must be included.

A finite-temperature read can also equal an archived point without concentrated weights. For the records $-1$, $0$ and $1$ at $z=0$, symmetry gives $m=0$ while every posterior weight is positive. The additional check records weights between {{a.finite_blending.minimum_weight|f3}} and {{a.finite_blending.maximum_weight|f3}}. Re-selection by proximity, posterior concentration and exact rank are therefore separate diagnostics.
