# Figure 5: the schedule pilot. Every plotted value is read from p3_explore.json.
import json, math, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

here = os.path.dirname(os.path.abspath(__file__))
BLUE, OR, AQUA, YEL, MAG, GRN, VIO = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6"
GREY, INK, MUTED, LIGHT = "#9a9893", "#222222", "#555555", "#c9d9ef"
STYLE = {"cosine": (BLUE, "o", "-", "cosine"), "geometric": (OR, "s", "-", "geometric"), "edm": (AQUA, "^", "-", "EDM, ρ = 7"),
         "barcode": (YEL, "v", (0, (3, 1.5)), "barcode, quantiles"),
         "barcode_coarse": (MAG, "D", (0, (3, 1.5)), "barcode, longest bars"),
         "barcode_mass": (GRN, "P", (0, (3, 1.5)), "barcode, mass-weighted"),
         "curvature": (VIO, "*", "-", "curvature, ρ ∝ √g")}


def tidy(ax, grid=True):
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    if grid:
        ax.grid(True, color="#ecebe8", lw=0.5, zorder=0)
    ax.tick_params(length=2.5, width=0.5)


def draw(path):
    E = json.load(open(os.path.join(here, "p3_explore.json")))
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.edgecolor": "#bdbbb6", "axes.linewidth": 0.6,
                         "xtick.color": MUTED, "ytick.color": MUTED, "axes.labelcolor": INK, "mathtext.fontset": "dejavusans",
                         "axes.titlesize": 8.5, "axes.titleweight": "bold", "axes.titlelocation": "left",
                         "legend.frameon": False, "legend.fontsize": 7})
    fig = plt.figure(figsize=(6.6, 4.9), dpi=300)
    from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator
    ex = E["example"]; s_min = ex["s_min"]["fine"]; s_max = ex["s_max"]
    # (a) top: curvature density and merge radii of one archive
    ax = fig.add_axes([0.21, 0.815, 0.30, 0.115]); tidy(ax)
    sg = np.array(ex["curvature"]["s"]); g = np.array(ex["curvature"]["g"]); keep = sg >= s_min
    rg = np.sqrt(g[keep]); ax.plot(sg[keep], rg / rg.max(), color=VIO, lw=1.2)
    for r in ex["radii"]:
        ax.plot([r, r], [0, 0.18], color=INK, lw=0.6)
    ax.set_xscale("log"); ax.set_xlim(s_min * 0.8, s_max * 1.25); ax.set_ylim(0, 1.08); ax.set_yticks([0, 1])
    ax.set_xticklabels([]); ax.set_ylabel("√g, scaled", fontsize=7)
    fig.text(0.01, 0.955, "(a) one archive in ℝ², eight layers", fontsize=8.5, fontweight="bold")
    ax.text(ex["radii"][0] * 1.05, 0.25, "merge radii", fontsize=6.3, color=INK)
    # (a) bottom: schedule strips
    ax = fig.add_axes([0.21, 0.585, 0.30, 0.22]); tidy(ax, grid=False)
    kinds = list(STYLE)
    for i, kind in enumerate(kinds):
        col, mk, _, lab = STYLE[kind]; sc = ex["scales"]["fine"][kind]
        ax.plot(sc, [len(kinds) - 1 - i] * len(sc), lw=0, marker="|", ms=7, mew=1.3, color=col)
        ax.text(s_min * 0.75, len(kinds) - 1 - i, lab, ha="right", va="center", fontsize=6.3, color=INK)
    ax.set_xscale("log"); ax.set_xlim(s_min * 0.8, s_max * 1.25); ax.set_yticks([]); ax.set_ylim(-0.6, len(kinds) - 0.4)
    ax.spines["left"].set_visible(False); ax.set_xlabel("scale s")
    # (b) loss against layers, pooled over dimensions, fine top
    ax = fig.add_axes([0.63, 0.585, 0.355, 0.345]); tidy(ax)
    KS = E["layer_counts"]
    for kind in kinds:
        col, mk, ls, lab = STYLE[kind]
        y = [np.mean([E["summary"]["fine"][str(D)][f"{kind}|{k}"]["loss"] for D in E["dims"]]) for k in KS]
        ax.plot(KS, y, color=col, marker=mk, ms=3.5 if mk != "*" else 5.5, lw=1.1, ls=ls, label=lab)
    ax.set_xscale("log", base=2); ax.set_yscale("log"); ax.set_xticks(KS); ax.set_xticklabels([str(k) for k in KS])
    ax.set_xlabel("layers k"); ax.set_ylabel("mean path loss, units of $d_{nn}$")
    fig.text(0.56, 0.955, "(b) loss against layers", fontsize=8.5, fontweight="bold")
    ax.legend(loc="lower left", fontsize=6.0, handlelength=2.2)
    # (c) C3: barcode with k layers against cosine with 2k layers, per dimension
    ax = fig.add_axes([0.16, 0.07, 0.35, 0.33]); tidy(ax)
    rows = [r for r in E["c3"] if r["regime"] == "fine" and r["schedule"] in ("barcode", "curvature")]
    ytick, ylab = [], []
    y0 = 0
    for D in E["dims"]:
        for k in [4, 8, 16, 32]:
            for j, kind in enumerate(["barcode", "curvature"]):
                r = [q for q in rows if q["D"] == D and q["k"] == k and q["schedule"] == kind][0]["loss_vs_cosine_2k"]
                col = STYLE[kind][0]; yy = y0 - 0.22 + 0.44 * j
                ax.plot([1 + r["lo"], 1 + r["hi"]], [yy, yy], color=col, lw=1.4)
                ax.plot(1 + r["est"], yy, marker=STYLE[kind][1], color=col, ms=3.5 if kind != "curvature" else 5.5, lw=0)
            ytick.append(y0); ylab.append(f"D = {D}, k = {k}"); y0 -= 1
        y0 -= 0.5
    ax.axvline(1.02, color=INK, lw=0.8, ls=(0, (3, 2))); ax.axvline(1.0, color=GREY, lw=0.5)
    ax.text(1.03, 0.6, "2% margin", fontsize=6.3, color=INK)
    ax.set_xscale("log"); ax.set_yticks(ytick); ax.set_yticklabels(ylab, fontsize=6.3)
    ax.xaxis.set_major_locator(FixedLocator([1, 2, 5, 10])); ax.xaxis.set_major_formatter(FixedFormatter(["1", "2", "5", "10"]))
    ax.xaxis.set_minor_locator(NullLocator())
    ax.set_xlabel("loss with k layers ÷ loss of cosine with 2k layers")
    fig.text(0.01, 0.455, "(c) transport comparison, fine top", fontsize=8.5, fontweight="bold")
    ax.legend(handles=[Line2D([], [], color=STYLE[k][0], marker=STYLE[k][1], lw=1.4, label=STYLE[k][3]) for k in ["barcode", "curvature"]],
              loc="lower center", bbox_to_anchor=(0.45, 1.0), ncol=2, fontsize=6.3, handlelength=1.6)
    # (d) efficiency of the model against the observed loss
    ax = fig.add_axes([0.63, 0.07, 0.355, 0.35]); tidy(ax)
    for kind in kinds:
        col, mk, _, lab = STYLE[kind]
        xs, ys = [], []
        for r in E["per_instance"]:
            for k in [8, 16, 32]:
                q = r["results"]["fine"][f"{kind}|{k}"]; cos = r["results"]["fine"][f"cosine|{k}"]
                xs.append(q["model"] / cos["model"]); ys.append(q["loss"] / cos["loss"])
        ax.scatter(xs, ys, s=3 if mk != "*" else 6, marker=mk, color=col, alpha=0.5, lw=0)
    ax.set_xscale("log"); ax.set_yscale("log"); ax.plot([0.5, 20], [0.5, 20], color=GREY, lw=0.6)
    ax.set_xlim(0.7, 8); ax.set_ylim(0.6, 12)
    for axis, ticks in ((ax.xaxis, [1, 2, 4, 8]), (ax.yaxis, [1, 2, 4, 8])):
        axis.set_major_locator(FixedLocator(ticks)); axis.set_major_formatter(FixedFormatter([str(t) for t in ticks]))
        axis.set_minor_locator(NullLocator())
    ax.set_xlabel("model error (5.4) relative to cosine"); ax.set_ylabel("path loss relative to cosine")
    fig.text(0.56, 0.455, "(d) the error model ranks schedules", fontsize=8.5, fontweight="bold")
    fig.savefig(path); plt.close(fig)


if __name__ == "__main__":
    draw(os.path.join(here, "fig", "schedules.png"))
