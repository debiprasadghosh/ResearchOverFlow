"""Native Word equations through Pandoc with a restrained scholarly layout."""
from pathlib import Path
import re,sys,subprocess
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph
P=Path(__file__).resolve().parent
D=Document(P/'ref.docx')
for child in list(D._element.body):
 if child.tag!=qn('w:sectPr'):D._element.body.remove(child)
for sec in D.sections:
 sec.page_width=Inches(8.5);sec.page_height=Inches(11)
 sec.left_margin=sec.right_margin=Inches(.78)
 sec.top_margin=sec.bottom_margin=Inches(.7)
 sec.header_distance=sec.footer_distance=Inches(.3)
 for part in (sec.header,sec.first_page_header,sec.even_page_header,sec.footer,sec.first_page_footer,sec.even_page_footer):
  for p in part.paragraphs:p.clear()
 p=sec.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');p._p.append(field)
for st in D.styles:
 if st.type in (1,2):
  st.font.color.rgb=RGBColor(0,0,0)
 for node in list(st.element.iter()):
  if node.tag in (qn('w:pBdr'),qn('w:shd')):node.getparent().remove(node)
 for col in st.element.iter(qn('w:color')):
  col.set(qn('w:val'),'000000')
  for a in ('w:themeColor','w:themeTint','w:themeShade'):
   col.attrib.pop(qn(a),None)
for name in ('Normal','Body Text','First Paragraph','Compact','Statement','Check'):
 if name not in D.styles:continue
 st=D.styles[name];st.font.name='Liberation Serif';st.font.size=Pt(11)
 st.paragraph_format.line_spacing=1.12;st.paragraph_format.space_after=Pt(6)
 st.paragraph_format.left_indent=st.paragraph_format.right_indent=Inches(0)
 st.paragraph_format.keep_with_next=False
 st.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
D.styles['Statement'].paragraph_format.space_after=Pt(4)
D.styles['Statement Tag'].font.size=Pt(9)
D.styles['Statement Tag'].paragraph_format.keep_with_next=False
D.styles['Statement Tag'].paragraph_format.left_indent=Inches(0)
D.styles['Statement Tag'].paragraph_format.right_indent=Inches(0)
D.styles['Statement Tag'].paragraph_format.space_after=Pt(8)
for name in ('Title','Subtitle','Author','Date'):
 D.styles[name].paragraph_format.keep_with_next=True
D.styles['Title'].font.size=Pt(24)
D.styles['Subtitle'].font.size=Pt(13)
D.styles['Date'].paragraph_format.space_after=Pt(12)
D.styles['Abstract'].font.name='Liberation Serif';D.styles['Abstract'].font.size=Pt(10.5)
D.styles['Abstract'].paragraph_format.left_indent=D.styles['Abstract'].paragraph_format.right_indent=Inches(0)
D.styles['Bibliography'].font.size=Pt(9.8)
D.styles['Source Code'].font.name='Liberation Mono';D.styles['Source Code'].font.size=Pt(9)
D.styles['Source Code'].paragraph_format.keep_together=True
for name in ('Equation','Statement Equation'):
 pf=D.styles[name].paragraph_format;pf.space_before=Pt(3);pf.space_after=Pt(7);pf.line_spacing=1.0
 pf.keep_together=True;pf.keep_with_next=False;pf.left_indent=pf.right_indent=Inches(0)
 pr=D.styles[name].element.get_or_add_pPr()
 for old in pr.findall(qn('w:tabs')):pr.remove(old)
 tabs=OxmlElement('w:tabs')
 for value,pos in [('center',4997),('right',9994)]:
  el=OxmlElement('w:tab');el.set(qn('w:val'),value);el.set(qn('w:pos'),str(pos));tabs.append(el)
 pr.append(tabs)
D.save(P/'reference.docx')
s=(P/'paper.md').read_text()
# Keep native math while splitting the longest source displays into readable lines.
replacements={
 '$\\alpha_i(z,s)=\\frac{w_ie^{-\\Vert z-y_i\\Vert^2/2s^2}}{\\sum_jw_je^{-\\Vert z-y_j\\Vert^2/2s^2}},\\quad m(z,s)=\\sum_i\\alpha_iy_i,\\quad C(z,s)=\\sum_i\\alpha_i(y_i-m)(y_i-m)^{\\top}$ (2.2)':
 '$\\alpha_i(z,s)=\\frac{w_ie^{-\\Vert z-y_i\\Vert^2/2s^2}}{\\sum_jw_je^{-\\Vert z-y_j\\Vert^2/2s^2}},\\quad m(z,s)=\\sum_i\\alpha_iy_i$\n:::\n\n::: {custom-style="Statement Equation"}\n$C(z,s)=\\sum_i\\alpha_i(y_i-m)(y_i-m)^{\\top}$ (2.2)',
 '$z(s_{t-1})-z_{t-1}=s_{t-1}\\int_{\\tau_t}^{\\tau_{t-1}}\\left(m(z(\\tau),1/\\tau)-m_t\\right)\\text{d}\\tau,\\qquad \\Vert z(s_{t-1})-z_{t-1}\\Vert\\le\\frac{1}{2}(s_t-s_{t-1})^2\\,\\text{max}\\,\\Vert z\'\'\\Vert$ (3.6)':
 '$z(s_{t-1})-z_{t-1}=s_{t-1}\\int_{\\tau_t}^{\\tau_{t-1}}\\left(m(z(\\tau),1/\\tau)-m_t\\right)\\text{d}\\tau$\n:::\n\n::: {custom-style="Statement Equation"}\n$\\Vert z(s_{t-1})-z_{t-1}\\Vert\\le\\frac{1}{2}(s_t-s_{t-1})^2\\,\\text{max}\\,\\Vert z\'\'\\Vert$ (3.6)'
}
for old,new in replacements.items():
 assert old in s,old[:70];s=s.replace(old,new)
# Punctuation belongs to math so line ends do not acquire isolated punctuation.
s=re.sub(r'(?<!\$)\$([^$\n]+)\$([,.;:])(?!\w)',lambda m:'$'+m[1]+r'\text{'+m[2]+'}$',s)
# Descriptive headings use words and numeric identifiers without punctuation.
s=re.sub(r'(?m)^(#{1,3}) (.+)$',lambda m:m[1]+' '+re.sub(r'[^\w\s]',' ',m[2]).replace('_',' '),s)
(P/'build.md').write_text(s)
subprocess.run(['pandoc','build.md','-o','raw.docx','--reference-doc=reference.docx','--resource-path=.','--no-highlight'],cwd=P,check=True)
D=Document(P/'raw.docx');D.core_properties.title='The Vertical Stack of Autoregressive Sheaf Evolution';D.core_properties.author='Debi Prasad Ghosh'
D.core_properties.subject='ASE Part III Chapters 7 to 9'
for p in D.paragraphs:
 if p.style.name=='Title':p.text='The Vertical Stack of\nAutoregressive Sheaf Evolution'
 if p.text.startswith(('Definition ','Proposition ','Theorem ','Corollary ','Example ')) and len(p.text)<260:
  p.paragraph_format.keep_with_next=True
 if p.style.name in ('Equation','Statement Equation'):
  p.paragraph_format.keep_with_next=not bool(re.search(r'\(\d+\.\d+\)\s*$',p.text))
 if p._p.xpath('.//w:drawing'):p.paragraph_format.keep_with_next=True
 if p.style.name in ('Caption','Image Caption','Table Caption'):p.paragraph_format.keep_together=True
 if p.text=='References' or p.text.startswith('Appendix A '):p.paragraph_format.page_break_before=True
 if p.style.name=='Source Code':
  p.paragraph_format.keep_together=True
  for run in p.runs:
   run.font.name='Liberation Mono';run.font.size=Pt(9)
   rf=run._r.get_or_add_rPr().find(qn('w:rFonts'))
   for key in ('w:ascii','w:hAnsi','w:cs','w:eastAsia'):rf.set(qn(key),'Liberation Mono')
widths=[[2.1,4.84],[1.6,3.55,1.79],[2.05,.62,.62,.62,.62,.62,.46,.73],[.33,.33,1.6,1.55,.6,1.22,1.31],[.32,1.25,2.53,2.84],[2.8,1.55,2.59]]
assert len(D.tables)==len(widths),(len(D.tables),len(widths))
for ti,(tbl,ws) in enumerate(zip(D.tables,widths)):
 tbl.autofit=False
 for c,w in zip(tbl.columns,ws):c.width=Inches(w)
 pr=tbl._tbl.tblPr
 for old in pr.findall(qn('w:tblBorders')):pr.remove(old)
 borders=OxmlElement('w:tblBorders')
 for side in ('top','left','bottom','right','insideH','insideV'):
  el=OxmlElement('w:'+side);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'4');el.set(qn('w:color'),'D9D9D9');borders.append(el)
 pr.append(borders)
 for ri,row in enumerate(tbl.rows):
  trpr=row._tr.get_or_add_trPr();trpr.append(OxmlElement('w:cantSplit'))
  if ri==0:trpr.append(OxmlElement('w:tblHeader'))
  for ci,(cell,w) in enumerate(zip(row.cells,ws)):
   cell.width=Inches(w);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   tcpr=cell._tc.get_or_add_tcPr()
   shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E7EBEF' if ri==0 else ('F7F8F9' if ri%2==0 else 'FFFFFF'));tcpr.append(shade)
   mar=OxmlElement('w:tcMar')
   for side,val in [('top',70),('bottom',70),('start',75),('end',75)]:
    el=OxmlElement('w:'+side);el.set(qn('w:w'),str(val));el.set(qn('w:type'),'dxa');mar.append(el)
   tcpr.append(mar)
   for p in cell.paragraphs:
    p.paragraph_format.space_after=Pt(2);p.paragraph_format.space_before=Pt(1);p.paragraph_format.line_spacing=1.03
    p.paragraph_format.keep_with_next=ri==0
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER if (ti==2 and ci>0) or (ti==3 and ci<2) or (ti==4 and ci==0) else WD_ALIGN_PARAGRAPH.LEFT
    for run in p.runs:run.font.size=Pt(9 if ti in (2,3) else 9.7);run.bold=ri==0
  if ri==0:
   for c in row.cells:
    for p in c.paragraphs:p.paragraph_format.keep_with_next=True
 after=tbl._tbl.getnext()
 if after is not None and after.tag==qn('w:p'):Paragraph(after,D._body).paragraph_format.space_before=Pt(6)
for shape,desc in zip(D.inline_shapes,['Read weights noise budget and precision coordinates','Transport approximation and clean top re selection','Composite singular values and posterior covariance','Bifurcations and modes of the Gaussian archive','Schedule placements and exploratory transport comparisons']):
 shape._inline.docPr.set('descr',desc)
D.save(P/'layout.docx')
(P/'output').mkdir(exist_ok=True)
subprocess.run([sys.executable,'postprocess.py','layout.docx','output/ASE_Part_III_The_Vertical_Stack.docx'],cwd=P,check=True)
(P/'output/ASE_Part_III_The_Vertical_Stack.md').write_text((P/'paper.md').read_text())
print('Word paper built')
