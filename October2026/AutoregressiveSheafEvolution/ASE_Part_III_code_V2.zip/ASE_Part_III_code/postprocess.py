# Post-process the pandoc output: centre display equations with right-aligned numbers, then put every
# property element in the order the OOXML schema requires, so that Word opens the file without repair.
import re, sys, zipfile
from lxml import etree

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M = "http://schemas.openxmlformats.org/officeDocument/2006/math"
ns = {"w": W, "m": M}

PPR = ("pStyle keepNext keepLines pageBreakBefore framePr widowControl numPr suppressLineNumbers pBdr shd tabs "
       "suppressAutoHyphens kinsoku wordWrap overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi adjustRightInd "
       "snapToGrid spacing ind contextualSpacing mirrorIndents suppressOverlap jc textDirection textAlignment "
       "textboxTightWrap outlineLvl divId cnfStyle rPr sectPr pPrChange").split()
RPR = ("ins del moveFrom moveTo rStyle rFonts b bCs i iCs caps smallCaps strike dstrike outline shadow emboss imprint "
       "noProof snapToGrid vanish webHidden color spacing w kern position sz szCs highlight u effect bdr shd fitText "
       "vertAlign rtl cs em lang eastAsianLayout specVanish oMath rPrChange").split()
TBLPR = ("tblStyle tblpPr tblOverlap bidiVisual tblStyleRowBandSize tblStyleColBandSize tblW jc tblCellSpacing tblInd "
         "tblBorders shd tblLayout tblCellMar tblLook tblCaption tblDescription tblPrChange").split()
STYLE = ("name aliases basedOn next link autoRedefine hidden uiPriority semiHidden unhideWhenUsed qFormat locked "
         "personal personalCompose personalReply rsid pPr rPr tblPr trPr tcPr tblStylePr").split()
TBLSTYLEPR = "pPr rPr tblPr trPr tcPr".split()
TCPR = ("cnfStyle tcW gridSpan hMerge vMerge tcBorders shd noWrap tcMar textDirection tcFitText vAlign hideMark "
        "headers cellIns cellDel cellMerge tcPrChange").split()
MCPR = "count mcJc".split()
SETTINGS = ("writeProtection view zoom removePersonalInformation removeDateAndTime doNotDisplayPageBoundaries "
            "displayBackgroundShape printPostScriptOverText printFractionalCharacterWidth printFormsData embedTrueTypeFonts "
            "embedSystemFonts saveSubsetFonts saveFormsData mirrorMargins alignBordersAndEdges bordersDoNotSurroundHeader "
            "bordersDoNotSurroundFooter gutterAtTop hideSpellingErrors hideGrammaticalErrors activeWritingStyle proofState "
            "formsDesign attachedTemplate linkStyles stylePaneFormatFilter stylePaneSortMethod documentType mailMerge "
            "revisionView trackRevisions doNotTrackMoves doNotTrackFormatting documentProtection autoFormatOverride "
            "styleLockTheme styleLockQFSet defaultTabStop autoHyphenation consecutiveHyphenLimit hyphenationZone "
            "doNotHyphenateCaps showEnvelope summaryLength clickAndTypeStyle defaultTableStyle evenAndOddHeaders "
            "bookFoldRevPrinting bookFoldPrinting bookFoldPrintingSheets drawingGridHorizontalSpacing "
            "drawingGridVerticalSpacing displayHorizontalDrawingGridEvery displayVerticalDrawingGridEvery "
            "doNotUseMarginsForDrawingGridOrigin drawingGridHorizontalOrigin drawingGridVerticalOrigin doNotShadeFormData "
            "noPunctuationKerning characterSpacingControl printTwoOnOne strictFirstAndLastChars noLineBreaksAfter "
            "noLineBreaksBefore savePreviewPicture doNotValidateAgainstSchema saveInvalidXml ignoreMixedContent "
            "alwaysShowPlaceholderText doNotDemarcateInvalidXml saveXmlDataOnly useXSLTWhenSaving saveThroughXslt "
            "showXMLTags alwaysMergeEmptyNamespace updateFields hdrShapeDefaults footnotePr endnotePr compat docVars rsids "
            "mathPr attachedSchema themeFontLang clrSchemeMapping doNotIncludeSubdocsInStats doNotAutoCompressPictures "
            "forceUpgrade captions readModeInkLockDown smartTagType schemaLibrary shapeDefaults doNotEmbedSmartTags "
            "decimalSymbol listSeparator").split()
ORDER = {(W, "pPr"): PPR, (W, "rPr"): RPR, (W, "tblPr"): TBLPR, (W, "style"): STYLE, (W, "tblStylePr"): TBLSTYLEPR,
         (W, "tcPr"): TCPR, (M, "mcPr"): MCPR, (W, "settings"): SETTINGS,
         (M, "dPr"): "begChr sepChr endChr grow shp ctrlPr".split(),
         (M, "naryPr"): "chr limLoc grow subHide supHide ctrlPr".split(),
         (M, "rPr"): "lit nor scr sty brk aln".split()}


def reorder(root):
    moved = 0
    for el in root.iter():
        if not isinstance(el.tag, str):
            continue
        q = etree.QName(el)
        seq = ORDER.get((q.namespace, q.localname))
        if seq is None:
            continue
        kids = [k for k in el if isinstance(k.tag, str)]
        rank = {name: i for i, name in enumerate(seq)}
        key = lambda k: rank.get(etree.QName(k).localname, len(seq))
        ordered = sorted(kids, key=key)          # stable: repeated or unknown elements keep their order
        if ordered != kids:
            for k in kids:
                el.remove(k)
            for k in ordered:
                el.append(k)
            moved += 1
    return moved


def tables(root, short=0):
    """Rows never split across pages; short tables are kept on one page."""
    n = 0
    for tbl in root.iter(f"{{{W}}}tbl"):
        rows = tbl.findall("w:tr", ns)
        for k, tr in enumerate(rows):
            trPr = tr.find("w:trPr", ns)
            if trPr is None:
                trPr = etree.SubElement(tr, f"{{{W}}}trPr"); tr.remove(trPr); tr.insert(0, trPr)
            if trPr.find("w:cantSplit", ns) is None:
                trPr.insert(0, etree.Element(f"{{{W}}}cantSplit"))
            if len(rows) <= short and k < len(rows) - 1:
                for p in tr.iter(f"{{{W}}}p"):
                    pPr = p.find("w:pPr", ns)
                    if pPr is None:
                        pPr = etree.Element(f"{{{W}}}pPr"); p.insert(0, pPr)
                    if pPr.find("w:keepNext", ns) is None:
                        pPr.append(etree.Element(f"{{{W}}}keepNext"))
        n += 1
    return n


def equations(root):
    count = 0
    for p in root.iter(f"{{{W}}}p"):
        st = p.find("w:pPr/w:pStyle", ns)
        if st is None or st.get(f"{{{W}}}val") not in ("Equation", "StatementEquation"):
            continue
        kids = [k for k in p if k.tag != f"{{{W}}}pPr"]
        if not kids:
            continue
        tab = lambda: etree.fromstring(f'<w:r xmlns:w="{W}"><w:tab/></w:r>')
        p.insert(p.index(kids[0]), tab())
        runs = [k for k in p if k.tag == f"{{{W}}}r" and k.find("w:t", ns) is not None]
        if runs:
            last = runs[-1]; t = last.find("w:t", ns)
            if re.match(r"^\s*\(\d+\.\d+\)\s*$", t.text or ""):
                t.text = t.text.strip()
                prev = last.getprevious()
                while (prev is not None and prev.tag == f"{{{W}}}r" and prev.find("w:t", ns) is not None
                       and not (prev.find("w:t", ns).text or "").strip()):
                    nxt = prev.getprevious(); p.remove(prev); prev = nxt
                p.insert(p.index(last), tab())
                count += 1
    return count


src, dst = sys.argv[1], sys.argv[2]
zin = zipfile.ZipFile(src)
names = zin.namelist()
out_parts, report = {}, {}
for name in names:
    data = zin.read(name)
    if name.startswith("word/") and name.endswith(".xml"):
        root = etree.fromstring(data)
        if name == "word/document.xml":
            report["numbered equations"] = equations(root)
            report["tables"] = tables(root)
        report[name] = reorder(root)
        for rp in root.iter(f"{{{M}}}rPr"):          # m:nor and m:sty are alternatives; keep m:nor
            if rp.find("m:nor", ns) is not None:
                for sty in rp.findall("m:sty", ns):
                    rp.remove(sty)
        for pg in root.iter(f"{{{W}}}pgMar"):
            if pg.get(f"{{{W}}}gutter") is None:
                pg.set(f"{{{W}}}gutter", "0")
        if name == "word/numbering.xml":
            for el in root.iter(f"{{{W}}}nsid"):
                v = el.get(f"{{{W}}}val")
                el.set(f"{{{W}}}val", v.zfill(8)[-8:].upper())
        data = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
    if name == "[Content_Types].xml":
        root = etree.fromstring(data)
        CT = "http://schemas.openxmlformats.org/package/2006/content-types"
        have = {d.get("Extension").lower() for d in root.findall(f"{{{CT}}}Default")}
        exts = {n.rsplit(".", 1)[-1].lower() for n in names if n.startswith("word/media/")}
        for ext in sorted(exts - have):
            mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif"}.get(ext)
            if mime:
                d = etree.SubElement(root, f"{{{CT}}}Default"); d.set("Extension", ext); d.set("ContentType", mime)
                root.insert(0, d)
        data = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
    out_parts[name] = data
zout = zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED)
for item in zin.infolist():
    zout.writestr(item, out_parts[item.filename])
zout.close()
print("numbered equations:", report.pop("numbered equations", 0), "| tables:", report.pop("tables", 0), "| reordered:", {k: v for k, v in report.items() if v})
