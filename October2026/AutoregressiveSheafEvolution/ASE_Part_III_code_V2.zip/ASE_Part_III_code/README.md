# The Vertical Stack of Autoregressive Sheaf Evolution

Part III of the six-part ASE book, covering Chapters 7–9. Revised 19 October
2026. The Word paper develops the recurrence, tangent dynamics and persistence
across layers. It includes a typed transport extension, a stochastic convergence
theorem at positive cutoffs, and exact clean-top interval and invertibility results.

## Rebuild

The recorded environment is Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0,
Matplotlib 3.10.8, python-docx and lxml. Pandoc must be installed.
Run from this directory with the Python environment of your choice:

```bash
python rerun_main.py
python p3_extras.py
python p3_additions.py
python p3_explore.py
python cs_validate.py
python fig_p3.py
python fig_schedules.py
python render.py
python build_docx.py
python verify.py
```

`p3_explore.py` runs four independent worker processes. Every instance has its
own fixed random seed; ordered aggregation and bootstrap seeds are preserved.
For reproducible resource use, set OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1.
The archived supplied results are in `archive/`. The current main checks have
four roundoff differences, the supplementary values match, and all numerical
pilot values match; elapsed seconds differ. `reproduction.json` records them.
The new checks are in `p3_additions.json`.

`cs/VerticalStack.cs` is the supplied immutable C# reference kernel.
`cs/cs_out.txt` is its supplied output trace. All 18 lines match a fresh NumPy
recomputation. This revision did not compile or execute C#; building its .NET 8
project is an additional check available to readers with that SDK installed.
The reference Gram-matrix singular-value method is not a production rank solver.

The 24 construction groups are distinct from the exploratory pilot and trace
comparison. All 72 barcode comparisons fail the transport pilot margin. This
is not a confirmatory refutation of the optimisation conjecture C3. Curvature
schedule construction cost is excluded from the plotted layer count.

`reference.docx`, `render.py`, `build_docx.py` and `postprocess.py` build native
Word equations. `verify.py` checks numeric evidence, ZIP integrity, XML,
relationships, equation numbering, figures and tables. These are not full OOXML
schema validation. Rendered pages are separately inspected in the document
workflow; QA PDFs and images are not included as deliverables.
