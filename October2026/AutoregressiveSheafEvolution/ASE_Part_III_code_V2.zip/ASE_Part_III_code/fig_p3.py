# Figures for Part III. Register values come from p3_checks.json, p3_extras.json and p3_explore.json; illustrative
# panels are recomputed here with fixed seeds from the same constructions, and their captions say so.
import json, math, os, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from p3_core import coefficients, separation_weights, reads, covariance, run_stack, kde_sample, mixture_cdf_1d

here = os.path.dirname(os.path.abspath(__file__))
os.makedirs(os.path.join(here, "fig"), exist_ok=True)
BLUE, OR, AQUA, YEL, MAG, GRN, VIO, RED = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"
FILL, GREY, INK, MUTED, LIGHT = "#eef3fb", "#9a9893", "#222222", "#555555", "#c9d9ef"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.edgecolor": "#bdbbb6", "axes.linewidth": 0.6,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.labelcolor": INK, "mathtext.fontset": "dejavusans",
                     "axes.titlesize": 8.5, "axes.titleweight": "bold", "axes.titlelocation": "left",
                     "legend.frameon": False, "legend.fontsize": 7})
C = json.load(open(os.path.join(here, "p3_checks.json")))
X = json.load(open(os.path.join(here, "p3_extras.json")))


def tidy(ax, grid=True):
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    if grid:
        ax.grid(True, color="#ecebe8", lw=0.5, zorder=0)
    ax.tick_params(length=2.5, width=0.5)


# ------------------------------------------------------------------ Figure 1: separation, noise budget, precision coordinates
def fig_separation(path):
    fig, axs = plt.subplots(1, 3, figsize=(6.6, 2.25), dpi=300, gridspec_kw=dict(width_ratios=[1.05, 1, 1.15]))
    s = np.exp(np.linspace(math.log(0.1), math.log(4.0), 9))
    ax = axs[0]; tidy(ax)
    for j, (eta, col) in enumerate([(0.0, BLUE), (1.0, OR)]):
        lam, _ = coefficients(s, eta); _, om, ws = separation_weights(lam)
        ax.bar(np.arange(1, 9) + (j - 0.5) * 0.38, om[1:], width=0.36, color=col, zorder=3,
               label=f"η = {eta:g}, ω$_*$ = {ws:.3f}")
    ax.set_xlabel("layer t (1 is the top)"); ax.set_ylabel("weight ω$_t$ of the read m$_t$ in z$_0$")
    ax.set_xticks(range(1, 9)); ax.legend(loc="upper right", handlelength=1.0)
    ax.set_title("(a) separation weights")
    ax = axs[1]; tidy(ax)
    etas = np.linspace(0, 1, 101); start = []; noise = []
    for eta in etas:
        lam, sig = coefficients(s, eta); pi, om, ws = separation_weights(lam)
        start.append(ws ** 2 * s[-1] ** 2 / s[0] ** 2); noise.append(np.sum(pi[1:] ** 2 * sig[1:] ** 2) / s[0] ** 2)
    ax.plot(etas, start, color=BLUE, lw=1.6, label="starting state, ω$_*^2$s$_T^2$/s$_0^2$")
    ax.plot(etas, noise, color=OR, lw=1.6, label="explicit noise, Σπ$_t^2$σ$_t^2$/s$_0^2$")
    ax.plot(etas, np.array(start) + np.array(noise), color=INK, lw=0.8, ls=(0, (3, 2)), label="sum")
    ax.set_ylim(-0.03, 1.62); ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0]); ax.set_xlabel("noise parameter η")
    ax.set_ylabel("share of the top variance s$_0^2$")
    ax.legend(loc="upper center", handlelength=1.4, fontsize=6.3, borderaxespad=0.1)
    ax.set_title("(b) the noise budget")
    # (c) the deterministic stack integrates the read in precision tau = 1/s (recomputed: records at -1 and 1)
    ax = axs[2]; tidy(ax)
    Y = np.array([[-1.0], [1.0]]); lw = np.log(np.array([0.45, 0.55])); z0 = np.array([[0.35]])
    sf = np.exp(np.linspace(math.log(0.25), math.log(3.0), 4001)); z = z0.copy(); tau, mm = [], []
    for k in range(len(sf) - 1, 0, -1):
        m, _ = reads(z, Y, lw, sf[k]); tau.append(1 / sf[k]); mm.append(m[0, 0])
        z = z + (sf[k - 1] - sf[k]) * (z - m) / sf[k]
    ax.plot(tau, mm, color=INK, lw=1.2, label="read along the exact flow", zorder=4)
    sl = np.exp(np.linspace(math.log(0.25), math.log(3.0), 7)); z = z0.copy()
    for t in range(len(sl) - 1, 0, -1):
        m, _ = reads(z, Y, lw, sl[t]); a_, b_ = 1 / sl[t], 1 / sl[t - 1]
        ax.fill_between([a_, b_], 0, m[0, 0], color=LIGHT, step="pre", zorder=2, lw=0)
        ax.plot([a_, b_], [m[0, 0]] * 2, color=BLUE, lw=1.4, zorder=3)
        z = (1 - (1 - sl[t - 1] / sl[t])) * z + (1 - sl[t - 1] / sl[t]) * m
    ax.plot([], [], color=BLUE, lw=1.4, label="six-layer stack: Δτ$_t$ m$_t$")
    ax.axhline(0, color=GREY, lw=0.5)
    ax.set_xlabel("precision τ = 1/s"); ax.set_ylabel("read m")
    ax.legend(loc="lower right", fontsize=6.3, handlelength=1.4)
    ax.set_title("(c) Riemann steps in τ")
    fig.tight_layout(w_pad=1.2); fig.savefig(path); plt.close(fig)


# ------------------------------------------------------------------ Figure 2: continuum limit and re-selection
def fig_transport(path):
    fig, axs = plt.subplots(1, 3, figsize=(6.6, 2.2), dpi=300, gridspec_kw=dict(width_ratios=[1.25, 1, 1]))
    Y = np.array([[-4.0], [-1.5], [0.0], [0.7], [3.0], [5.5]]); w = np.array([1.0, 2.0, 0.5, 1.5, 1.0, 0.8]); lw = np.log(w)
    rng = np.random.default_rng(7); N = 40000; zT, _ = kde_sample(Y, lw, 20.0, N, rng)
    ax = axs[0]; tidy(ax)
    xs = np.linspace(-6.5, 7.5, 600); dens = np.gradient(mixture_cdf_1d(xs, Y, lw, 0.3), xs)
    bins = np.linspace(-6.5, 7.5, 141)
    for T, col, lab in [(4, OR, "4 layers"), (64, BLUE, "64 layers")]:
        z0 = run_stack(zT.copy(), Y, lw, np.exp(np.linspace(math.log(0.3), math.log(20.0), T + 1)), 0.0)[:, 0]
        h, e = np.histogram(z0, bins=bins, density=True)
        ax.step(e[:-1], h, where="post", color=col, lw=0.9, label=lab, zorder=3 if T == 64 else 2)
    ax.plot(xs, dens, color=INK, lw=0.8, ls=(0, (2, 1.5)), label="p$_{s_0}$, s$_0$ = 0.3", zorder=4)
    ax.set_xlabel("output z$_0$"); ax.set_ylabel("density"); ax.legend(loc="upper right", fontsize=6.3, handlelength=1.3)
    ax.set_title("(a) outputs of deterministic stacks")
    ax = axs[1]; tidy(ax)
    rows = C["continuum"]["rows"]
    for eta, col, mk in [(0.0, BLUE, "o"), (1.0, OR, "s")]:
        r = [x for x in rows if x["eta"] == eta]
        ax.plot([x["layers"] for x in r], [x["ks"] for x in r], color=col, marker=mk, ms=3.5, lw=1.2, label=f"η = {eta:g}")
    ax.axhline(C["continuum"]["sampling_floor"], color=GREY, lw=0.8, ls=(0, (2, 2)))
    ax.text(4.2, C["continuum"]["sampling_floor"] * 1.15, "sample reference", fontsize=6.3, color=MUTED)
    ax.set_xscale("log", base=2); ax.set_yscale("log"); ax.set_xlabel("layers T"); ax.set_ylabel("KS distance to p$_{s_0}$")
    ax.legend(loc="upper right"); ax.set_title("(b) the continuum limit")
    ax = axs[2]; tidy(ax)
    f = np.array(C["clean_top"]["frequencies"]); wt = np.array(C["clean_top"]["weights"]); x = np.arange(len(f))
    ax.bar(x - 0.19, wt, width=0.36, color=LIGHT, edgecolor=BLUE, lw=0.6, label="prior weight", zorder=3)
    ax.bar(x + 0.19, f, width=0.36, color=BLUE, label="re-selection frequency", zorder=3)
    ax.set_xticks(x); ax.set_xticklabels([f"y$_{i + 1}$" for i in x]); ax.set_ylabel("share of tokens")
    ax.legend(loc="upper right", fontsize=6.3); ax.set_ylim(0, 0.38); ax.set_title("(c) re-selection")
    fig.tight_layout(w_pad=1.0); fig.savefig(path); plt.close(fig)


# ------------------------------------------------------------------ Figure 3: tangent dynamics
def part_one_data():
    sys.path.insert(0, here)
    import p3_extras as PE
    Y, starts, a = PE.part_one_tokens()
    out = []
    for z in starts:
        Js, Cs, s = PE.path_jacobians(z.copy(), Y, a)
        K = np.eye(2)
        for t in range(15, 0, -1):
            K = Js[t] @ K
        sv = np.linalg.svd(K, compute_uv=False); c1 = np.sort(np.linalg.eigvalsh(Cs[1]))[::-1]
        ratio = [np.linalg.eigvalsh(Cs[t]).max() / s[t] ** 2 for t in range(15, 0, -1)]
        out.append((sv, c1, ratio))
    return Y, out


def fig_tangent(path):
    fig, axs = plt.subplots(1, 3, figsize=(6.6, 2.3), dpi=300)
    # (a) composite singular values against the schedule floor (recomputed: three clusters in R^2, geometric scales)
    rng = np.random.default_rng(11); ax = axs[0]; tidy(ax)
    centres = np.array([[0.0, 0.0], [2.5, 0.0], [1.2, 2.2]]); Y = np.concatenate([c + 0.35 * rng.standard_normal((10, 2)) for c in centres])
    lw = np.zeros(len(Y)); T = 16; s = np.exp(np.linspace(math.log(0.05), math.log(20.0), T + 1)); lam, _ = coefficients(s, 0.0)
    for i in range(40):
        z = kde_sample(Y, lw, s[-1], 1, rng)[0][0]; K = np.eye(2); smin, smax = [1.0], [1.0]
        for t in range(T, 0, -1):
            m, A = reads(z[None], Y, lw, s[t]); Cm = covariance(A[0], Y, m[0])
            K = ((1 - lam[t]) * np.eye(2) + lam[t] * Cm / s[t] ** 2) @ K; z = (1 - lam[t]) * z + lam[t] * m[0]
            sv = np.linalg.svd(K, compute_uv=False); smin.append(sv[-1]); smax.append(sv[0])
        layers = np.arange(T, -1, -1)
        ax.plot(layers, smax, color=OR, lw=0.5, alpha=0.5); ax.plot(layers, smin, color=BLUE, lw=0.5, alpha=0.5)
    ax.plot(np.arange(T, -1, -1), s[::-1][0:1] * 0 + s[np.arange(T, -1, -1)] / s[-1], color=INK, lw=1.1, ls=(0, (3, 2)))
    ax.text(7.0, 0.0105, "floor s$_t$/s$_T$", fontsize=6.5, color=INK, rotation=-27)
    ax.set_yscale("log"); ax.invert_xaxis(); ax.set_xlabel("layer t reached"); ax.set_ylabel("singular values of K$_{T→t}$")
    ax.legend(handles=[Line2D([], [], color=OR, lw=1, label="largest"), Line2D([], [], color=BLUE, lw=1, label="smallest")],
              loc="lower left", fontsize=6.5)
    ax.set_title("(a) never below the floor")
    # (b) Part I's experiment: singular values against the top covariance
    Y1, data = part_one_data(); ax = axs[1]; tidy(ax)
    for k, col, lab in [(0, OR, "k = 1"), (1, BLUE, "k = 2")]:
        c = np.array([d[1][k] for d in data]); sv = np.array([d[0][k] for d in data]); ok = c > 1e-16
        ax.scatter(c[ok], sv[ok], s=2.5, color=col, alpha=0.55, lw=0, label=lab, zorder=3)
    lo, hi = 1e-16, 1.0; ax.plot([lo, hi], [lo, hi], color=INK, lw=0.8, ls=(0, (3, 2)), label="bound σ$_k$ = c$_{1,k}$")
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(1e-16, 1); ax.set_ylim(1e-16, 1)
    ax.set_xlabel("eigenvalue c$_{1,k}$ of the top covariance"); ax.set_ylabel("σ$_k$ of the composite")
    ax.legend(loc="upper left", markerscale=3); ax.set_title("(b) Part I, explained")
    # (c) expansion along the paths of Part I: the largest eigenvalue of C_t / s_t^2, layer by layer
    ax = axs[2]; tidy(ax)
    R = np.array([d[2] for d in data[:300]]); layers = np.arange(15, 0, -1)
    for r in R:
        ax.plot(layers, r, color=BLUE, lw=0.35, alpha=0.25)
    ax.plot(layers, np.median(np.array([d[2] for d in data]), 0), color=INK, lw=1.2, label="median")
    ax.axhline(1, color=OR, lw=1.0); ax.text(14.8, 2.3, "expansion threshold c = s$^2$", fontsize=6.3, color=OR)
    ax.set_yscale("log"); ax.invert_xaxis(); ax.set_ylim(1e-9, 30)
    ax.set_xlabel("layer t"); ax.set_ylabel("largest eigenvalue of C$_t$/s$_t^2$"); ax.legend(loc="lower left", fontsize=6.5)
    ax.set_title("(c) expansion")
    fig.tight_layout(w_pad=1.0); fig.savefig(path); plt.close(fig)


# ------------------------------------------------------------------ Figure 4: bifurcations and modes
def stationary_1d(Y, lw, s, lo=-1.6, hi=1.6, grid=3200):
    x = np.linspace(lo, hi, grid); m, _ = reads(x[:, None], Y, lw, s); F = m[:, 0] - x; out = []
    for i in range(grid - 1):
        if F[i] * F[i + 1] < 0:
            a, b = x[i], x[i + 1]
            for _ in range(60):
                c = 0.5 * (a + b)
                if (reads(np.array([[a]]), Y, lw, s)[0][0, 0] - a) * (reads(np.array([[c]]), Y, lw, s)[0][0, 0] - c) <= 0:
                    b = c
                else:
                    a = c
            r = 0.5 * (a + b); mm, A = reads(np.array([[r]]), Y, lw, s)
            out.append((r, covariance(A[0], Y, mm[0])[0, 0] / s ** 2))
    return out


def critical_points(Y, lw, s):
    sys.path.insert(0, here)
    import p3_extras as PE
    found = []
    for x in np.linspace(-0.4, 1.4, 37):
        for y in np.linspace(-0.4, 1.3, 35):
            z = PE.newton(np.array([x, y]), Y, lw, s)
            if z is not None and not any(np.linalg.norm(z - p) < 1e-7 for p in found):
                found.append(z)
    out = []
    for z in found:
        m, A = reads(z[None], Y, lw, s); ev = np.linalg.eigvalsh(covariance(A[0], Y, m[0])) / s ** 2
        out.append((z, int(np.sum(ev > 1 + 1e-9))))
    return out


def fig_modes(path):
    fig = plt.figure(figsize=(6.6, 2.45), dpi=300)
    ax = fig.add_axes([0.085, 0.17, 0.235, 0.7]); tidy(ax)
    Y = np.array([[-1.0], [1.0]])
    for lw_, col, lab in [(np.zeros(2), BLUE, "weights 1:1"), (np.log(np.array([0.7, 0.3])), OR, "weights 7:3")]:
        for s in np.linspace(0.45, 1.5, 240):
            for r, c in stationary_1d(Y, lw_, s):
                ax.plot(s, r, marker="o", ms=0.9 if c < 1 else 0.6, color=col if c < 1 else GREY, lw=0, zorder=3)
        ax.plot([], [], color=col, marker="o", ms=3, lw=0, label=lab)
    ax.plot([], [], color=GREY, marker="o", ms=3, lw=0, label="unstable (c > s²)")
    ax.axvline(1.0, color=BLUE, lw=0.5, ls=(0, (2, 2))); ax.axvline(C["bifurcation"]["unequal_fold_scale"], color=OR, lw=0.5, ls=(0, (2, 2)))
    ax.set_xlabel("scale s"); ax.set_ylabel("stationary points of E$_s$")
    ax.legend(loc="upper right", fontsize=6.0, handletextpad=0.2, bbox_to_anchor=(1.02, 0.97))
    ax.set_title("(a) pitchfork and fold")
    Yt = np.array([[0.0, 0.0], [1.0, 0.0], [0.5, math.sqrt(3) / 2]]); lwt = np.zeros(3)
    gx, gy = np.meshgrid(np.linspace(-0.45, 1.45, 160), np.linspace(-0.4, 1.3, 150))
    fig.text(0.355, 0.905, "(b) three equal records", fontsize=8.5, fontweight="bold")
    for j, s in enumerate([0.37, 0.418, 0.44]):
        ax = fig.add_axes([0.35 + j * 0.162, 0.2, 0.16, 0.66]); ax.set_aspect("equal"); ax.axis("off")
        P = np.zeros_like(gx)
        for y in Yt:
            P += np.exp(-((gx - y[0]) ** 2 + (gy - y[1]) ** 2) / (2 * s * s))
        ax.contour(gx, gy, P, levels=12, colors=[LIGHT], linewidths=0.5)
        for z, idx in critical_points(Yt, lwt, s):
            st = {0: dict(marker="o", color=BLUE, ms=4), 1: dict(marker="x", color=OR, ms=4, mew=1.0),
                  2: dict(marker="o", mfc="white", mec=INK, color=INK, ms=4, mew=0.8)}[idx]
            ax.plot(z[0], z[1], lw=0, zorder={0: 6, 1: 5, 2: 4}[idx], **st)
        ax.text(0.5, -0.47, f"s = {s:g}", fontsize=7.2, ha="center", color=INK)
    fig.legend(handles=[Line2D([], [], marker="o", color=BLUE, lw=0, ms=4, label="mode"),
                        Line2D([], [], marker="x", color=OR, lw=0, ms=4, mew=1.0, label="saddle"),
                        Line2D([], [], marker="o", mfc="white", mec=INK, color=INK, lw=0, ms=4, label="density minimum")],
               loc="lower center", bbox_to_anchor=(0.6, 0.0), ncol=3, fontsize=6.5)
    ax = fig.add_axes([0.85, 0.17, 0.14, 0.7]); tidy(ax)
    rows = X["triangle_morse"]["rows"]; ss = [r["s"] for r in rows]
    ax.step(ss, [r["energy_minima"] for r in rows], where="mid", color=BLUE, lw=1.2, label="modes")
    ax.step(ss, [r["saddles"] for r in rows], where="mid", color=OR, lw=1.0, label="saddles")
    ax.axvline(X["triangle_morse"]["centroid_switch_scale"], color=INK, lw=0.6, ls=(0, (2, 2)))
    ax.set_xlim(0.38, 0.45); ax.set_xticks([0.38, 0.41, 0.44]); ax.set_yticks([0, 1, 2, 3, 4])
    ax.set_xlabel("scale s"); ax.legend(loc="center right", fontsize=6.0); ax.set_title("(c) counts", x=-0.1)
    fig.savefig(path); plt.close(fig)


if __name__ == "__main__":
    which = sys.argv[1:] or ["separation", "transport", "tangent", "modes", "schedules"]
    if "separation" in which:
        fig_separation(os.path.join(here, "fig", "separation.png"))
    if "transport" in which:
        fig_transport(os.path.join(here, "fig", "transport.png"))
    if "tangent" in which:
        fig_tangent(os.path.join(here, "fig", "tangent.png"))
    if "modes" in which:
        fig_modes(os.path.join(here, "fig", "modes.png"))
    if "schedules" in which and os.path.exists(os.path.join(here, "p3_explore.json")):
        import fig_schedules
        fig_schedules.draw(os.path.join(here, "fig", "schedules.png"))
    print("figures written")
