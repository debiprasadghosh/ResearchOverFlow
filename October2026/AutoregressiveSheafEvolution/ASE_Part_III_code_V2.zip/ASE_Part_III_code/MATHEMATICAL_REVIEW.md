# Mathematical review of Part III

The paper retains the six-part book's scope and terminology. A stalk is a data
space; a token has a vertical fibre diagram. Moving-base maps use the inverse
image, and fixed-base horizontal-vertical squares must commute. Units and metrics
precede residuals and singular values. Cover, context, observation-star and layer
bases are kept distinct.

The general transported recurrence is matrix-valued and has the stated section
compatibility conditions. Its unconditional Gaussian accounting law requires
deterministic transport coefficients. The scalar identity-map noise budget is
an explicit-term identity; reads are dependent on the same innovations.

The deterministic probability-flow result assumes a frozen Gaussian archive and
correct initial marginal. The added stochastic theorem uses positive fixed
cutoffs, Brownian coupling, globally Lipschitz drift with linear growth, and
standard Euler–Maruyama convergence. The root mean square half-order rate is
conservative. It is not uniform as the cutoff shrinks. Clean archive re-selection
requires an iterated mesh-refinement and shrinking-cutoff limit.

The clean-top sandwich concerns singular values, not matrix equality. Exact
intervals are computed from linear diagrams; independent thresholded ranks can
violate rank identities. Prescribed zero singular values in a floating-point
construction are not exact arithmetic rank computations. Positive-cutoff maps
are global diffeomorphisms only for the fixed common-frame Gaussian model with
additive noise fixed along the path.

The error surrogate has a rigorous allocation lower bound: piecewise density
1/h on each interval turns the discrete surrogate exactly into the continuum
functional. This does not bound actual endpoint error. It omits propagation and
the final clean-top read. Mode counts alone supply no comparison maps, even when
monotone. The known triangle example illustrates two-dimensional nonmonotonicity.

The full scheduling pilot was rerun. Its 72 failing transport margins are not
an optimisation experiment and do not refute C3. Intervals are descriptive and
pointwise. Curvature preprocessing costs 48,000 additional query reads per
archive and is not in the plotted denoising layer count. No trained-model,
neuroscience or engineering optimisation result is claimed.

Primary references checked online include DDIM, score-SDEs, Karras et al.,
DPM-Solver, the Carreira-Perpiñán–Williams report and Higham's SDE numerical
introduction. Mathematical derivations are supplied in the paper; provenance
labels locate results in this research programme without a literature-priority
claim. The supplied C# trace, not a fresh compilation, is validated against NumPy.
