"""Figure 2 of Version 2, drawn from the validated C# output cs_flow.txt."""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

H = Path(__file__).resolve().parent
cs = {l.split("\t")[0]: [float(v) for v in l.rstrip("\n").split("\t")[1].split()] for l in open(H / "cs_flow.txt")}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.titlesize": 11, "axes.labelsize": 10,
                     "axes.spines.top": False, "axes.spines.right": False, "savefig.facecolor": "white"})
NAVY, RUST, GREY = "#263746", "#a95235", "#9aa6ad"
fig, ax = plt.subplots(1, 2, figsize=(9.6, 3.9), layout="constrained")
rows = [("coherent", "Coherent teacher"), ("l1_shift_005", "L1 cell moved by 0.05"), ("l2_shift_005", "L2 value moved by 0.05"),
        ("benefit_in_range", "Benefit inside its range"), ("benefit_harm_upper", "Benefit and harm at\ntheir upper ends"),
        ("conditional_in_range", "Conditional inside its range")]
y = list(range(len(rows)))[::-1]
vals = [100 * cs[f"flow_coherence_{k}"][2] / cs[f"flow_coherence_{k}"][0] for k, _ in rows]
cols = [NAVY if k == "coherent" else RUST for k, _ in rows]
ax[0].barh(y, vals, color=cols, height=0.6)
for yi, v in zip(y, vals): ax[0].text(v - 2 if v > 50 else v + 1.5, yi, f"{v:.1f}%", va="center", ha="right" if v > 50 else "left", fontsize=8.5, color="white" if v > 50 else "black")
ax[0].set_yticks(y, [l for _, l in rows], fontsize=8.5); ax[0].set_xlim(0, 105)
ax[0].set_xlabel("Transcripts with a common response law (%)")
ax[0].set_title("A  One shared law, not separate ranges")
lv = [("L1", "L1 only"), ("L2", "L1 and L2"), ("L2_plus_one_L3", "L2 and one\ncoupling record")]
x = range(3); w = 0.27
series = [(6, "Sharp interval width", GREY), (7, "Error of solver-selected student", RUST), (8, "Error of interval midpoint", NAVY)]
for i, (idx, lab, col) in enumerate(series):
    v = [cs[f"flow_status_{k}"][idx] for k, _ in lv]
    b = ax[1].bar([xi + (i - 1) * w for xi in x], v, w * 0.92, color=col, label=lab)
    for bb, vv in zip(b, v):
        if vv > 0: ax[1].text(bb.get_x() + bb.get_width() / 2, vv + 0.008, f"{vv:.3f}", ha="center", fontsize=7.5)
ax[1].text(2, 0.02, "all zero:\nidentified", ha="center", fontsize=8)
ax[1].set_xticks(list(x), [l for _, l in lv]); ax[1].set_ylabel("Mean over 1,000 teachers"); ax[1].set_ylim(0, 0.56)
ax[1].legend(frameon=False, fontsize=8, loc="upper right"); ax[1].set_title("B  P(Y₁=1, Y₀=0) by information level")
(H / "fig").mkdir(exist_ok=True)
fig.savefig(H / "fig/flow_coherence_and_status.png", dpi=240); fig.savefig(H / "fig/flow_coherence_and_status.svg"); plt.close(fig)
