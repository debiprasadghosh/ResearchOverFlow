"""Build Version 2 of 'Causal Flow Distillation in Autoregressive Do Calculus' from the supplied Version 1 Word file.

Version 1 is edited in place: its text, native equations, tables and figure are kept. New material is converted by
Pandoc with Version 1 as reference document; new tables copy Version 1's table look. Every number is read from
the validated C# output cs_flow.txt."""
import copy, json, os, re, shutil, subprocess, tempfile, zipfile
from docx import Document
from docx.shared import Inches
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from lxml import etree

H = os.path.dirname(os.path.abspath(__file__)); SRC = os.path.join(os.path.dirname(H), "in", "v1.docx")
OUT = os.path.join(H, "Causal_Flow_Distillation_in_ADC_V2.docx")
cs = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1].split() for l in open(os.path.join(H, "cs_flow.txt"))}
val = json.load(open(os.path.join(H, "validation_flow.json"))); assert val["all_passed"]
NCHK = len(val["checks"]); WORST = float(next(c for c in val["checks"] if c["name"] == "flow_float_crosscheck")["detail"])
W_ = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"; WNS = f'xmlns:w="{W_}"'
XML = "{http://www.w3.org/XML/1998/namespace}space"
I = lambda k: [int(float(v)) for v in cs[k]]
num = lambda x: f"{x:,}"
pc = lambda a, b, d=1: f"{100 * a / b:.{d}f}%"
co = {k: I(f"flow_coherence_{k}") for k in ("coherent", "l1_shift_001", "l1_shift_005", "l2_shift_001", "l2_shift_005", "benefit_in_range", "benefit_harm_upper", "conditional_in_range")}
stt = {k: cs[f"flow_status_{k}"] for k in ("L1", "L2", "L2_plus_one_L3")}
idn = I("flow_identification"); mr = I("flow_missing_rank")
tu, tg, sg = I("flow_triangle_uniform"), I("flow_triangle_general"), I("flow_star_gluing")
doc = Document(SRC)

# ------------------------------------------------------------------ helpers in the Version 1 look
def fragment(md):
    with tempfile.TemporaryDirectory() as td:
        open(os.path.join(td, "f.md"), "w", encoding="utf-8").write(md)
        subprocess.run(["pandoc", "f.md", "-f", "markdown+tex_math_dollars-auto_identifiers-fancy_lists", "-o", "f.docx", f"--reference-doc={SRC}"], cwd=td, check=True)
        f = Document(os.path.join(td, "f.docx"))
        els = [copy.deepcopy(e) for e in f.element.body if e.tag != qn("w:sectPr")]
    for e in els:
        for b in list(e.iter(qn("w:bookmarkStart"))) + list(e.iter(qn("w:bookmarkEnd"))): b.getparent().remove(b)
        if e.tag == qn("w:p"):
            ppr = e.find(qn("w:pPr")); ps = ppr.find(qn("w:pStyle")) if ppr is not None else None
            if ps is not None and ps.get(qn("w:val")) in ("BodyText", "FirstParagraph"):
                ps.set(qn("w:val"), "BodyText")
                if ppr.find(qn("w:jc")) is None and e.find(qn("m:oMathPara")) is None:
                    jc = OxmlElement("w:jc"); jc.set(qn("w:val"), "both"); ppr.append(jc)
    return els

def style_table(tbl, widths):
    tp = tbl.find(qn("w:tblPr"))
    for ch in list(tp): tp.remove(ch)
    for ch in etree.fromstring(f'<w:tblPr {WNS}><w:tblW w:type="dxa" w:w="{sum(widths)}"/><w:jc w:val="center"/><w:tblBorders>' +
                               "".join(f'<w:{s} w:val="single" w:sz="4" w:space="0" w:color="D9D9D9"/>' for s in ("top", "left", "bottom", "right", "insideH", "insideV")) +
                               '</w:tblBorders><w:tblLayout w:type="fixed"/><w:tblCellMar><w:top w:w="95" w:type="dxa"/><w:left w:w="110" w:type="dxa"/>'
                               '<w:bottom w:w="95" w:type="dxa"/><w:right w:w="110" w:type="dxa"/></w:tblCellMar><w:tblLook w:val="0020" w:firstRow="1" w:lastRow="0" '
                               'w:firstColumn="0" w:lastColumn="0" w:noHBand="0" w:noVBand="0"/></w:tblPr>'): tp.append(ch)
    for gc, w in zip(tbl.find(qn("w:tblGrid")).findall(qn("w:gridCol")), widths): gc.set(qn("w:w"), str(w))
    rows = tbl.findall(qn("w:tr"))
    for ri, tr in enumerate(rows):
        trpr = tr.find(qn("w:trPr"))
        if trpr is None: trpr = OxmlElement("w:trPr"); tr.insert(0, trpr)
        for ch in list(trpr): trpr.remove(ch)
        trpr.append(OxmlElement("w:cantSplit"))
        if ri == 0: trpr.append(OxmlElement("w:tblHeader"))
        fill = "263746" if ri == 0 else ("FFFFFF" if ri % 2 else "F3F5F7")
        for ci, (tc, w) in enumerate(zip(tr.findall(qn("w:tc")), widths)):
            tcpr = tc.find(qn("w:tcPr"))
            if tcpr is None: tcpr = OxmlElement("w:tcPr"); tc.insert(0, tcpr)
            for ch in list(tcpr): tcpr.remove(ch)
            for ch in etree.fromstring(f'<w:tcPr {WNS}><w:tcW w:type="dxa" w:w="{w}"/><w:shd w:val="clear" w:color="auto" w:fill="{fill}"/><w:vAlign w:val="center"/></w:tcPr>'): tcpr.append(ch)
            for p in tc.findall(qn("w:p")):
                ppr = p.find(qn("w:pPr"))
                if ppr is None: ppr = OxmlElement("w:pPr"); p.insert(0, ppr)
                for ch in list(ppr): ppr.remove(ch)
                keep = '<w:keepNext/>' if ri < len(rows) - 1 else ''
                for ch in etree.fromstring(f'<w:pPr {WNS}><w:pStyle w:val="BodyText"/>{keep}<w:spacing w:before="0" w:after="60" w:line="245" w:lineRule="auto"/>'
                                           f'<w:jc w:val="{"left" if ci == 0 else "center"}"/></w:pPr>'): ppr.append(ch)
                for r in p.findall(qn("w:r")):
                    rpr = r.find(qn("w:rPr"))
                    if rpr is None: rpr = OxmlElement("w:rPr"); r.insert(0, rpr)
                    for ch in list(rpr): rpr.remove(ch)
                    for ch in etree.fromstring(f'<w:rPr {WNS}><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman"/>' +
                                               ('<w:b/><w:color w:val="FFFFFF"/>' if ri == 0 else '<w:b w:val="0"/><w:color w:val="000000"/>') + '<w:sz w:val="20"/></w:rPr>'): rpr.append(ch)

def caption(text, keep=True, desc=None):
    p = etree.fromstring(f'<w:p {WNS}><w:pPr><w:pStyle w:val="Caption"/>{"<w:keepNext/>" if keep else ""}<w:jc w:val="center"/></w:pPr>'
                         f'<w:r><w:rPr><w:iCs/><w:i/></w:rPr><w:t xml:space="preserve"></w:t></w:r></w:p>')
    p.find(f".//{qn('w:t')}").text = text
    if desc:
        r = OxmlElement("w:r"); r.append(OxmlElement("w:br")); t = OxmlElement("w:t"); t.text = desc; t.set(XML, "preserve"); r.append(t); p.append(r)
    return p

def table(rows, widths, cap):
    els = fragment("\n".join(rows) + "\n")
    for e in els:
        if e.tag == qn("w:tbl"): style_table(e, widths)
    return [caption(cap)] + els

def figure(path, title, desc, alt):
    p = doc.add_paragraph(style="Body Text"); p.alignment = 1
    p.add_run().add_picture(path, width=Inches(6.4))
    el = p._p; el.getparent().remove(el)
    ppr = el.find(qn("w:pPr")); ppr.find(qn("w:pStyle")).addnext(OxmlElement("w:keepNext"))
    for d in el.iter("{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}docPr"): d.set("descr", alt)
    return [el, caption(title, keep=False, desc=desc)]

norm = lambda s: (s or "").replace("\xa0", " ").replace("’", "'")
def find(start, style=None):
    for p in doc.paragraphs:
        if norm(p.text).startswith(start) and (style is None or p.style.name == style): return p
    raise KeyError(start)
def after(anchor, els):
    ref = anchor._p if hasattr(anchor, "_p") else anchor
    for e in els: ref.addnext(e); ref = e
    return ref
def run_like(text, model=None):
    r = OxmlElement("w:r")
    if model is not None and model.find(qn("w:rPr")) is not None: r.append(copy.deepcopy(model.find(qn("w:rPr"))))
    t = OxmlElement("w:t"); t.text = text; t.set(XML, "preserve"); r.append(t); return r
def replace_in(p, old, new):
    for t in p._p.iter(qn("w:t")):
        if old in (t.text or ""): t.text = t.text.replace(old, new); return
    raise KeyError(old)
def insert_before(p, needle, text):
    for t in p._p.iter(qn("w:t")):
        if needle in (t.text or ""):
            r = t.getparent(); i = t.text.index(needle)
            head, tail = t.text[:i], t.text[i:]
            t.text = tail; t.set(XML, "preserve")
            if head: r.addprevious(run_like(head, r))
            r.addprevious(run_like(text, r)); return
    raise KeyError(needle)
def append_text(p, text):
    rs = p._p.findall(qn("w:r")); p._p.append(run_like(text, rs[-1] if rs else None))

# ------------------------------------------------------------------ front matter
dp = next(p for p in doc.paragraphs if p.style.name == "Date")
ts = list(dp._p.iter(qn("w:t"))); ts[0].text = "Version 2, 1 November 2026"
for t in ts[1:]: t.getparent().remove(t)
ab = find("Distillation of Autoregressive Do Calculus (ADC) should preserve")
s2 = stt["L2"]
insert_before(ab, "Neuroscience findings motivate",
    f"Version 2 adds an immutable C# kernel, three further algorithms and an exact census on 1,000 instrumental-variable teachers. "
    f"Every coherent transcript was accepted with a witness, and every rejection carried an exact Farkas refutation. Moving one observational "
    f"cell by 0.05 left {pc(co['l1_shift_005'][2], co['l1_shift_005'][0])} of transcripts coherent, whereas moving an interventional value by 0.01 was "
    f"always refuted once benefit and harm records were present. A benefit value drawn inside its own sharp range was jointly coherent in "
    f"{pc(co['benefit_in_range'][2], co['benefit_in_range'][0])} of transcripts. With observational and interventional records only, a solver-selected "
    f"compatible student erred by {float(s2[7]):.3f} on average, three times the midpoint error of {float(s2[8]):.3f}; one coupling record identified the "
    f"query for every teacher. An identification test on the affine hull agreed with exact interval width in all {num(idn[0])} queries. Among "
    f"{num(tu[0])} pairwise-consistent uniform triangles, {num(tu[1])} admitted a global law, exactly the cut-polytope count. An independent Python "
    f"program passes {NCHK} checks. ")
after(find("The accompanying checks are exact finite examples"), fragment(
    "Version 2 recompiles these questions in an immutable C# kernel. It adds an exact census of transcript coherence with checkable refutations, "
    "of the three transfer statuses, of identification on a polytope and of gluing on cyclic and tree covers (Section 11, from *A C# census at scale*). "
    "Propositions 4.7 and 6.7 and Algorithms 5 to 7 are new. Every census line is recomputed by an independent Python program. The census still "
    "trains no neural student and queries no frontier model."))
replace_in(find("Section 2 fixes the semantic contract"), "Section 11 reports exact checks.", "Section 11 reports exact checks and the Version 2 census.")

# ------------------------------------------------------------------ Section 4: Proposition 4.7
after(find("This is the central acceptance rule"), fragment(r"""**Proposition 4.7 (coupling records make marginal errors refutable; coherence is not correctness).** In the binary two-world response model the rows satisfy

$$\mathbf{1}\{Y_1 = 1, Y_0 = 0\} - \mathbf{1}\{Y_1 = 0, Y_0 = 1\} = \mathbf{1}\{Y_1 = 1\} - \mathbf{1}\{Y_0 = 1\}.\quad\quad\text{~~~~(13)}$$

A transcript reporting the benefit $\beta$, the harm $\eta$ and the interventional values $a = P(Y_1 = 1)$ and $b = P(Y_0 = 1)$ is coherent only if $\beta - \eta = a - b$. Changing any one of these four values with the other three fixed is therefore always refuted. A change to a record whose row is not determined by the others can remain coherent: the transcript then describes some admissible teacher, not necessarily the one that produced the original records.

**Proof.** For each response type the two sides of (13) agree: both equal one when $Y_1 = 1, Y_0 = 0$, minus one when $Y_1 = 0, Y_0 = 1$ and zero otherwise. Taking expectations under any common law gives the stated equality, so a single changed value violates it. Theorem 4.2 then supplies a refutation. For the converse, Section 11 exhibits many coherent transcripts whose observational cells were moved. $▫$

Coherence is a statement about the existence of a common law. Correctness relative to the actual teacher requires the records themselves to be correct, which no checker can infer from their consistency."""))

# ------------------------------------------------------------------ Section 6: Proposition 6.7
after(find("Teacher queries should therefore be chosen"), fragment(r"""**Proposition 6.7 (identification uses the implicit equalities of the polytope).** Let $K = \{q \ge 0 : Mq = d,\ \mathbf{1}^{\top} q = 1\}$ be nonempty, and let $Z$ contain the response atoms $k$ with $q_k = 0$ for every $q \in K$. A linear query $c^{\top} q$ is constant on $K$ exactly when

$$c \in \operatorname{rowspan}\big(M,\ \mathbf{1}^{\top},\ \{e_k^{\top}\}_{k \in Z}\big).\quad\quad\text{~~~~(14)}$$

The test on the full simplex, which omits the rows $e_k^{\top}$, is sufficient but not necessary.

**Proof.** The affine hull of a nonempty polyhedron is the solution set of its implicit equalities (Schrijver, 1986). Here these are $Mq = d$, normalization and $q_k = 0$ for $k \in Z$; every other inequality $q_k \ge 0$ is strict somewhere on $K$, and averaging finitely many such points gives a relative-interior point at which all of them are strict. A linear function is constant on $K$ exactly when it is constant on the affine hull, which holds exactly when $c$ is orthogonal to its direction space, the null space of the rows in (14). This is the row-space condition. Omitting rows can only shrink the row space. $▫$

Theorem 6.3 uses the variation space $T = \operatorname{span}(K - K)$; Proposition 6.7 computes it. Response atoms that the evidence forces to zero are invisible to a rank test on the full simplex, yet they can identify a query."""))

# ------------------------------------------------------------------ Section 9: Algorithms 5 to 7
after(find("Algorithm 4 (certify and deploy)."), fragment(r"""**Algorithm 5 (coherence with a refutation).** Write the transcript in standard form $Ax = b$, $x \ge 0$, with slack variables for inequality records and the normalization row, and flip rows so that $b \ge 0$. Add one artificial variable per row and maximize minus their sum by an exact simplex method. A zero optimum returns the response-law part of the solution as a common witness. A negative optimum returns the dual vector $y$ of the optimal basis. Unflipped, it gives multipliers with $y_i \ge 0$ on inequality records, $\sum_i y_i\,\mathrm{row}_i + \nu \mathbf{1} \ge 0$ coordinatewise and $\sum_i y_i\,\mathrm{rhs}_i + \nu < 0$, which is the certificate (5). The checker verifies either object with exact arithmetic, independently of the solver.

**Algorithm 6 (identification test).** For a feasible target set $K$, find $Z$ by maximizing each atom mass and keeping the atoms whose maximum is zero. Test (14) by exact rank. If the test succeeds, supervise the common value; otherwise compute the sharp range and assign a status by Algorithm 2.

**Algorithm 7 (gluing check).** If the local laws are indexed by a junction tree, build the global law by (6) and verify its marginals exactly. Otherwise run Algorithm 5 on the joint atoms of the union of contexts, which returns a global law or a refutation."""))

# ------------------------------------------------------------------ Section 11 census
anchor = find("Further exact checks cover")
replace_in(anchor, "No C# execution or independent neural training is reported for this paper.",
           "Version 1 reported no C# execution; the census below adds it. No neural training is reported.")
rowco = lambda k, lab, sep: f"| {lab} | {num(co[k][0])} | {sep} | {pc(co[k][2], co[k][0])} | {num(co[k][0] - co[k][2])} |"
t5 = table(["| Transcript | Teachers | Each record inside its own sharp range | Common law exists | Refuted with an exact certificate |", "|---|---|---|---|---|",
            rowco("coherent", "Coherent teacher records", "Yes"), rowco("l1_shift_001", "One observational cell moved by 0.01", "Not tested"),
            rowco("l1_shift_005", "One observational cell moved by 0.05", "Not tested"), rowco("l2_shift_001", "One interventional value moved by 0.01", "Not tested"),
            rowco("l2_shift_005", "One interventional value moved by 0.05", "Not tested"), rowco("benefit_in_range", "Benefit drawn inside its range", "Yes"),
            rowco("benefit_harm_upper", "Benefit and harm at their upper ends", "Yes"), rowco("conditional_in_range", "P(Y₁=1 \\| Y₀=0) drawn inside its range", "Yes")],
           [3000, 1100, 1900, 1500, 1860], "Table 5 Coherence of teacher and student transcripts (1,000 teachers each)")
def rowst(k, lab):
    s = stt[k]; c = [int(float(v)) for v in s[:6]]
    return (f"| {lab} | {float(s[6]):.3f} | {pc(c[1], c[0])} | {pc(c[2], c[0])} | {float(s[7]):.3f} | {pc(c[3], c[0])} | {pc(c[4], c[0])} | {float(s[8]):.3f} |")
t6 = table(["| Information | Mean sharp width | Identified | Truth inside interval | Solver-selected student: mean error | Error above 0.1 | Exact | Midpoint: mean error |",
            "|---|---|---|---|---|---|---|---|", rowst("L1", "Observational records"), rowst("L2", "Observational and interventional records"),
            rowst("L2_plus_one_L3", "Both, plus P(Y₁=1, Y₀=1)")],
           [1860, 1000, 1180, 1000, 1260, 1000, 900, 1160], "Table 6 Three transfer statuses for the benefit P(Y₁=1, Y₀=0)")
t7 = table(["| Cover | Systems | Global law exists | Refuted with an exact certificate | Independent check |", "|---|---|---|---|---|",
            f"| Triangle, uniform marginals, agreements in twentieths | {num(tu[0])} | {num(tu[1])} ({pc(tu[1], tu[0])}) | {num(tu[0] - tu[1])} | Cut-polytope inequalities |",
            f"| Triangle, marginals in quarters, joint cells in twentieths | {num(tg[0])} | {num(tg[1])} ({pc(tg[1], tg[0])}) | {num(tg[0] - tg[1])} | HiGHS feasibility |",
            f"| Star cover, a junction tree | {num(sg[0])} | {num(sg[1])} ({pc(sg[1], sg[0])}) | 0 | Product construction |"],
           [3260, 1200, 1700, 1700, 1500], "Table 7 Global extension of pairwise-consistent local laws")
fig2 = figure(os.path.join(H, "fig", "flow_coherence_and_status.png"), "Figure 2 Joint coherence and the three transfer statuses",
              "Left: share of transcripts admitting one common response law. Every record in the last three rows lies inside its own sharp range. "
              "Right: sharp interval width for the benefit, and the mean error of a solver-selected compatible student and of the interval midpoint. "
              "Exact census over 1,000 instrumental-variable teachers; not a neural experiment.",
              "Horizontal bars of joint coherence rates by transcript type, and grouped bars of interval width and student errors at three information levels.")
l1, l2v = stt["L1"], stt["L2"]
sec = fragment(rf"""## A C# census at scale

The census uses the binary instrumental-variable response model with 16 response types, four for the treatment as a function of the instrument and four for the outcome as a function of the treatment (Balke & Pearl, 1997). Each of 1,000 teachers draws a response law with integer weights from 0 to 4. A teacher's records are its six observational cells, the interventional values $P(Y_1 = 1)$ and $P(Y_0 = 1)$, the benefit $P(Y_1 = 1, Y_0 = 0)$, the harm $P(Y_1 = 0, Y_0 = 1)$ and the conditional $P(Y_1 = 1 \mid Y_0 = 0)$ written in the form (4) with a support floor of half the true evidence mass. All arithmetic is exact. Feasibility, ranges and certificates come from Algorithms 5 to 7 on an exact two-phase simplex method with Bland's rule. The kernel is part of the series' immutable C# code.

## Transcript coherence

Table 5 and Figure 2A report Algorithm 5. Every coherent transcript was accepted with a witness, and every rejection carried an exact refutation of form (5). Moving one observational cell by 0.05 left {pc(co['l1_shift_005'][2], co['l1_shift_005'][0])} of transcripts coherent: another admissible teacher could have produced them. Moving one interventional value by 0.01 was refuted in every transcript, because the benefit and harm records fix its difference by Proposition 4.7. A benefit drawn inside its own sharp range passed a separate interval check by construction, yet only {pc(co['benefit_in_range'][2], co['benefit_in_range'][0])} of such transcripts admitted one common law. Setting benefit and harm both at the upper ends of their own ranges, the situation of Proposition 4.5, left {pc(co['benefit_harm_upper'][2], co['benefit_harm_upper'][0])} coherent. The few accepted cases are those in which the drawn value equals the teacher's.

## Three transfer statuses

Table 6 and Figure 2B compare the statuses of Definition 4.4 for the benefit. With observational records only, the sharp interval had mean width {float(l1[6]):.3f}; with interventional records it narrowed to {float(l2v[6]):.3f}, and no teacher was identified at either level. A compatible student selected as the witness of Algorithm 5 is a vertex of the target set. Its mean error was {float(l2v[7]):.3f} with interventional records, and above 0.1 for {pc(int(l2v[3]), int(l2v[0]))} of teachers. The interval midpoint erred by {float(l2v[8]):.3f}, never more than half the width, as Corollary 3.4 states. A solver's choice is not a neutral estimate: it tends to sit at an extreme of the admissible set. Adding the single coupling record $P(Y_1 = 1, Y_0 = 1)$ identified the benefit for every teacher, as Example 6.2 predicts: interventional records fix two of the three coordinates of the binary pair law.

## Identification on the affine hull

For each teacher, Algorithm 6 tested five targets with observational and interventional records: benefit, harm, $P(Y_1 = 1, Y_0 = 1)$, the complier mass and the complier benefit. The affine-hull test (14) agreed with exact interval width in all {num(idn[0])} cases. The full-simplex test identified none of them. {num(idn[6])} queries were identified only through atoms forced to zero, and {num(idn[7])} teachers had such atoms. The rank of the missing directions was exactly one for the outcome-pair family in every teacher, and two for the complier family in {num(mr[5])} teachers (one in {num(mr[4])}). These are the numbers of additional independent linear records a curriculum must supply (Corollary 6.4).

## Gluing on cyclic and tree covers

Table 7 reports Algorithm 7. For three binary variables with uniform marginals and pairwise agreement probabilities on a grid of twentieths, every one of the {num(tu[0])} systems is pairwise consistent. Only {num(tu[1])} ({pc(tu[1], tu[0])}) admitted a global law; each of the others was refuted by an exact certificate. The count equals that of the cut-polytope inequalities on the pairwise disagreements, which the validator evaluates independently (Deza & Laurent, 1997). With unequal marginals, {pc(tg[1], tg[0])} of {num(tg[0])} locally consistent systems were extendable. On star covers, which are junction trees, construction (6) produced a global law with the required marginals in all {num(sg[0])} cases, including {num(sg[2])} with a zero separator mass. Overlap agreement suffices on a tree and fails on a cycle, as Section 5 states.

## Independent validation

An independent Python program recomputes every census line. It re-checks every exported witness and every Farkas refutation exactly, rebuilds every transcript from its teacher law or checks a drawn value against an independently computed sharp range, recomputes feasibility, ranges and forced-zero atoms with the HiGHS solver in SciPy, and recomputes ranks by a separate fraction-based elimination. It evaluates the uniform triangles by the cut-polytope inequalities rather than a linear programme, and the star covers by a separate product construction. All {NCHK} checks pass, with a largest floating-point discrepancy of {WORST:.1e}.
""")
def split_at(els, heading):
    i = next(i for i, e in enumerate(els) if heading in "".join(e.itertext())); return els[:i], els[i:]
a, rest = split_at(sec, "Three transfer statuses")
b, rest = split_at(rest, "Identification on the affine hull")
c, rest = split_at(rest, "Gluing on cyclic and tree covers")
d, e = split_at(rest, "Independent validation")
after(anchor, a + t5 + b + t6 + fig2 + c + d + t7 + e)

# ------------------------------------------------------------------ hypotheses, limits, appendix, references
after(find("H1 (common-flow acceptance)."), fragment(
    "*Census note.* On 8,000 transcripts in Section 11, every coherent transcript was accepted and every rejection carried a verified exact "
    "refutation. This checks the exact checker on one model class; it does not test a statistical or neural implementation."))
after(find("H2 (honest hierarchy transfer)."), fragment(
    f"*Census note.* With observational and interventional records, no benefit query was identified, and a solver-selected student erred by more "
    f"than 0.1 for {pc(int(l2v[3]), int(l2v[0]))} of teachers. A procedure that reports that student's value as recovered would fail H2."))
after(find("The present paper establishes an interface"), fragment(
    "The Version 2 census covers one response model with 16 types, one family of records and one grid of teacher laws. Its rates describe that "
    "family. Exact rank and feasibility tests scale with the number of response atoms, which grows quickly with the number of variables. The "
    "certificates are exact only for exactly specified records; rounded or sampled records need the interval contracts of Section 4."))
after(find("The checks include independent product-factorization counts"), fragment(
    "Version 2 adds kernel/Flow.cs to the series' C# project. Run dotnet run -c Release --project kernel -- out --flow to produce cs_flow.txt and "
    "out/flow_records.json in under twenty seconds. Then run python validate_flow.py cs_flow.txt out/flow_records.json validation_flow.json, "
    "fig_flow.py for Figure 2 and build_v2.py for this document. The kernel targets .NET 8; the validator uses Python 3 with NumPy and SciPy."))
set_cap = find("Table 4 Scope of the guarantees")
for t in set_cap._p.iter(qn("w:t")):
    if "Table 4" in (t.text or ""): t.text = t.text.replace("Table 4", "Table 8")
def ref_after(start, text, italic_part=None):
    p = find(start); new = copy.deepcopy(p._p)
    for r in list(new.findall(qn("w:r"))) + list(new.findall(qn("w:hyperlink"))): new.remove(r)
    parts = text.split("*")
    for i, part in enumerate(parts):
        if not part: continue
        r = OxmlElement("w:r")
        if i % 2 == 1: rp = OxmlElement("w:rPr"); rp.append(OxmlElement("w:i")); r.append(rp)
        t = OxmlElement("w:t"); t.text = part; t.set(XML, "preserve"); r.append(t); new.append(r)
    p._p.addnext(new)
ref_after("Deng, X., & Zhang, Z. (2021).", "Deza, M. M., & Laurent, M. (1997). *Geometry of cuts and metrics*. Springer. https://doi.org/10.1007/978-3-642-04295-9")
ref_after("Rubenstein, P. K.", "Schrijver, A. (1986). *Theory of linear and integer programming*. Wiley.")
doc.core_properties.title = "Causal Flow Distillation in Autoregressive Do Calculus, Version 2"
doc.save(OUT); print("saved", OUT)

# ------------------------------------------------------------------ OOXML order fixes (math, settings, numbering)
M_ = "http://schemas.openxmlformats.org/officeDocument/2006/math"
ORDER = {"dPr": ["begChr", "sepChr", "endChr", "grow", "shp", "ctrlPr"], "rPr": ["lit", "nor", "scr", "sty", "brk", "aln"]}
SORDER = ("writeProtection view zoom removePersonalInformation removeDateAndTime doNotDisplayPageBoundaries displayBackgroundShape printPostScriptOverText "
          "printFractionalCharacterWidth printFormsData embedTrueTypeFonts embedSystemFonts saveSubsetFonts saveFormsData mirrorMargins alignBordersAndEdges "
          "bordersDoNotSurroundHeader bordersDoNotSurroundFooter gutterAtTop hideSpellingErrors hideGrammaticalErrors activeWritingStyle proofState formsDesign "
          "attachedTemplate linkStyles stylePaneFormatFilter stylePaneSortMethod documentType mailMerge revisionView trackRevisions doNotTrackMoves "
          "doNotTrackFormatting documentProtection autoFormatOverride styleLockTheme styleLockQFSet defaultTabStop autoHyphenation consecutiveHyphenLimit "
          "hyphenationZone doNotHyphenateCaps showEnvelope summaryLength clickAndTypeStyle defaultTableStyle evenAndOddHeaders bookFoldRevPrinting "
          "bookFoldPrinting bookFoldPrintingSheets drawingGridHorizontalSpacing drawingGridVerticalSpacing displayHorizontalDrawingGridEvery "
          "displayVerticalDrawingGridEvery doNotUseMarginsForDrawingGridOrigin drawingGridHorizontalOrigin drawingGridVerticalOrigin doNotShadeFormData "
          "noPunctuationKerning characterSpacingControl printTwoOnOne strictFirstAndLastChars noLineBreaksAfter noLineBreaksBefore savePreviewPicture "
          "doNotValidateAgainstSchema saveInvalidXml ignoreMixedContent alwaysShowPlaceholderText doNotDemarcateInvalidXml saveXmlDataOnly useXSLTWhenSaving "
          "saveThroughXslt showXMLTags alwaysMergeEmptyNamespace updateFields hdrShapeDefaults footnotePr endnotePr compat docVars rsids mathPr attachedSchema "
          "themeFontLang clrSchemeMapping doNotIncludeSubdocsInStats doNotAutoCompressPictures forceUpgrade captions readModeInkLockDown smartTagType "
          "schemaLibrary shapeDefaults doNotEmbedSmartTags decimalSymbol listSeparator").split()
def fix(name, data):
    if name == "word/document.xml":
        root = etree.fromstring(data)
        for nm, order in ORDER.items():
            for el in root.iter(f"{{{M_}}}{nm}"):
                kids = list(el)
                for k in kids: el.remove(k)
                if nm == "rPr" and any(etree.QName(k).localname == "nor" for k in kids):
                    kids = [k for k in kids if etree.QName(k).localname not in ("sty", "scr")]
                for k in sorted(kids, key=lambda k: order.index(etree.QName(k).localname) if etree.QName(k).localname in order else 99): el.append(k)
        for rr in root.iter(f"{{{M_}}}r"):
            t = rr.find(f"{{{M_}}}t"); rp = rr.find(f"{{{M_}}}rPr")
            if t is not None and rp is not None and re.fullmatch(r"\s*\(\d+\)", t.text or "") and rp.find(f"{{{M_}}}nor") is not None:
                for k in list(rp): rp.remove(k)
                etree.SubElement(rp, f"{{{M_}}}sty").set(f"{{{M_}}}val", "p")
        for sh in root.iter(f"{{{W_}}}shd"):
            if sh.get(f"{{{W_}}}val") is None: sh.set(f"{{{W_}}}val", "clear")
        WORD = {"tblPr": "tblStyle tblpPr tblOverlap bidiVisual tblStyleRowBandSize tblStyleColBandSize tblW jc tblCellSpacing tblInd tblBorders shd tblLayout tblCellMar tblLook tblCaption tblDescription".split(),
                "tcPr": "cnfStyle tcW gridSpan hMerge vMerge tcBorders shd noWrap tcMar textDirection tcFitText vAlign hideMark".split()}
        for nm, order in WORD.items():
            for el in root.iter(f"{{{W_}}}{nm}"):
                kids = list(el)
                for k in kids: el.remove(k)
                for k in sorted(kids, key=lambda k: order.index(etree.QName(k).localname) if etree.QName(k).localname in order else 99): el.append(k)
        return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
    if name == "word/settings.xml":
        root = etree.fromstring(data); kids = list(root)
        for k in kids: root.remove(k)
        for k in sorted(kids, key=lambda k: SORDER.index(etree.QName(k).localname) if etree.QName(k).localname in SORDER else 999): root.append(k)
        for z in root.iter(f"{{{W_}}}zoom"):
            if z.get(f"{{{W_}}}percent") is None: z.set(f"{{{W_}}}percent", "100")
        return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
    if name == "word/numbering.xml":
        root = etree.fromstring(data)
        for e in list(root.iter(f"{{{W_}}}nsid")) + list(root.iter(f"{{{W_}}}tmpl")): e.set(f"{{{W_}}}val", e.get(f"{{{W_}}}val").zfill(8))
        return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
    return data
tmp = OUT + ".tmp"
with zipfile.ZipFile(OUT) as zi, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zo:
    for it in zi.infolist(): zo.writestr(it, fix(it.filename, zi.read(it.filename)))
shutil.move(tmp, OUT); print("schema order fixed")
