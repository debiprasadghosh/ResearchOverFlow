# Causal Flow Distillation in ADC — Version 2 (1 November 2026)

Version 2 keeps the Version 1 text, equations, tables and figure, and adds an exact C# census.

New material
- Proposition 4.7 (coupling records make marginal errors refutable; coherence is not correctness).
- Proposition 6.7 (identification uses the implicit equalities of the polytope).
- Algorithms 5–7 (coherence with an exact Farkas refutation; identification test; gluing check).
- Section 11, from "A C# census at scale": Tables 5–7 and Figure 2. The guarantee ledger is renumbered Table 8.

Files
- kernel/ — C# (.NET 8). Flow.cs is new; Idc.cs (exact simplex), Exact.cs, Graph.cs, Distill.cs, Marginals.cs are series files.
- cs_flow.txt, out/flow_records.json — census output with every witness and refutation.
- validate_flow.py, validation_flow.json, validate_flow.log — independent Python validation (19 checks, all pass).
- fig_flow.py, fig/ — Figure 2.  build_v2.py — edits the Version 1 Word file into Version 2.
- inherited_v1/ — the supplied Version 1 sources, unchanged.

Reproduce
    dotnet run -c Release --project kernel -- out --flow > cs_flow.txt
    python validate_flow.py cs_flow.txt out/flow_records.json validation_flow.json
    python fig_flow.py && python build_v2.py     # needs Pandoc and the Version 1 docx at ../in/v1.docx

Limits: one 16-type instrumental-variable response model and one record family; exact records only;
no neural student trained and no frontier model queried.
