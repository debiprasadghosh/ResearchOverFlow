"""Independent validation of the causal-flow distillation census (cs_flow.txt, out/flow_records.json).

Every witness and every Farkas refutation exported by the C# kernel is re-checked exactly with Python fractions.
Transcripts are rebuilt from the teacher law where their values are determined; drawn in-range values are checked
against independently computed sharp ranges. Feasibility, ranges and support zeros are recomputed with SciPy's
HiGHS solver, ranks with a separate fraction-based elimination, the uniform triangle against the cut-polytope
inequalities, and the star covers by an independent product construction.
Usage: python validate_flow.py cs_flow.txt out/flow_records.json validation_flow.json"""
import json, math, sys
from fractions import Fraction as F
import numpy as np
from scipy.optimize import linprog

cs = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1].split() for l in open(sys.argv[1])}
R = json.load(open(sys.argv[2])); checks = []
def check(name, ok, detail=""):
    checks.append(dict(name=name, passed=bool(ok), detail=str(detail)[:300])); print(("PASS " if ok else "FAIL ") + name, str(detail)[:150], flush=True)
def eq(name, vals, tol=1e-9):
    got = cs[name]
    ok = len(got) == len(vals) and all((abs(float(g) - v) <= tol * max(1, abs(v))) if isinstance(v, float) else int(g) == v for g, v in zip(got, vals))
    check(name, ok, (got, vals))

T = 16
Xof = lambda k, z: (k >> 2) >> z & 1
Yof = lambda k, x: (k & 3) >> x & 1
CELLS = [(0, 0, 0), (0, 0, 1), (0, 1, 0), (1, 0, 0), (1, 0, 1), (1, 1, 0)]
DROWS = [[F(1) if Xof(k, z) == x and Yof(k, x) == y else F(0) for k in range(T)] for z, x, y in CELLS]
ind = lambda f: [F(1) if f(k) else F(0) for k in range(T)]
Y1 = ind(lambda k: Yof(k, 1)); Y0 = ind(lambda k: Yof(k, 0))
BEN = ind(lambda k: Yof(k, 1) and not Yof(k, 0)); HARM = ind(lambda k: not Yof(k, 1) and Yof(k, 0)); BOTH = ind(lambda k: Yof(k, 1) and Yof(k, 0))
Y0NO = ind(lambda k: not Yof(k, 0)); COMP = ind(lambda k: Xof(k, 1) and not Xof(k, 0)); CB = [a * b for a, b in zip(COMP, BEN)]
dot = lambda a, q: sum(x * y for x, y in zip(a, q))

def exact_check(rows, res):
    """rows: list of (row, rhs, eq). Re-check a witness or a Farkas refutation exactly."""
    if res["feasible"]:
        w = [F(v) for v in res["w"]]
        return all(v >= 0 for v in w) and sum(w) == 1 and all((dot(r, w) == b) if e else (dot(r, w) <= b) for r, b, e in rows)
    y = [F(v) for v in res["y"]]; nu = F(res["nu"])
    if any(not e and yi < 0 for (r, b, e), yi in zip(rows, y)): return False
    if any(nu + sum(yi * r[k] for (r, b, e), yi in zip(rows, y)) < 0 for k in range(len(rows[0][0]))): return False
    return nu + sum(yi * b for (r, b, e), yi in zip(rows, y)) < 0

def lp(rows, c=None, sense=1):
    n = len(rows[0][0]) if rows else T
    Aeq = [[float(x) for x in r] for r, b, e in rows if e] + [[1.0] * n]; beq = [float(b) for r, b, e in rows if e] + [1.0]
    Aub = [[float(x) for x in r] for r, b, e in rows if not e]; bub = [float(b) for r, b, e in rows if not e]
    res = linprog(np.zeros(n) if c is None else -sense * np.array([float(x) for x in c]), A_eq=np.array(Aeq), b_eq=np.array(beq),
                  A_ub=np.array(Aub) if Aub else None, b_ub=np.array(bub) if bub else None, bounds=(0, None), method="highs")
    if c is None: return res.status == 0
    assert res.status == 0
    return -sense * res.fun

def rank(rows):
    m = [list(r) for r in rows]; rk = 0; ncol = len(m[0])
    for col in range(ncol):
        piv = next((i for i in range(rk, len(m)) if m[i][col] != 0), None)
        if piv is None: continue
        m[rk], m[piv] = m[piv], m[rk]
        for i in range(len(m)):
            if i != rk and m[i][col] != 0:
                f = m[i][col] / m[rk][col]; m[i] = [a - f * b for a, b in zip(m[i], m[rk])]
        rk += 1
    return rk

def L1(q): return [(r, dot(r, q), True) for r in DROWS]
def L2(q): return L1(q) + [(Y1, dot(Y1, q), True), (Y0, dot(Y0, q), True)]
def full(q, b1, h1, c1, basis):
    rows = basis + [(BEN, b1, True), (HARM, h1, True)]
    p0 = dot(Y0NO, q)
    if p0 > 0: rows += [([a - c1 * b for a, b in zip(BEN, Y0NO)], F(0), True), ([-x for x in Y0NO], -p0 / 2, False)]
    return rows
def same_rows(mine, theirs):
    return len(mine) == len(theirs) and all([F(x) for x in tr[0]] == list(r) and F(tr[1]) == b and tr[2] == e for (r, b, e), tr in zip(mine, theirs))

kinds = ["coherent", "l1_shift_001", "l1_shift_005", "l2_shift_001", "l2_shift_005", "benefit_in_range", "benefit_harm_upper", "conditional_in_range"]
acc = {k: [0, 0, 0, 0] for k in kinds}; rebuilt = True; scipy_ok = True; worst = 0.0
levels = ["L1", "L2", "L2_plus_one_L3"]; st = {l: [0] * 6 for l in levels}; stw = {l: [0.0, 0.0, 0.0] for l in levels}
idc = [0] * 8; missing = [0] * 6
for rec in R:
    q = [F(v) for v in rec["q"]]; J = rec["judged"]
    ben, harm, p0 = dot(BEN, q), dot(HARM, q), dot(Y0NO, q); cond = ben / p0 if p0 else F(0)
    l2 = L2(q)
    bl, bh = lp(l2, BEN, -1), lp(l2, BEN, 1); hl, hh = lp(l2, HARM, -1), lp(l2, HARM, 1)
    for k in kinds:
        if k not in J: continue
        res = J[k]; rows = [([F(x) for x in r], F(b), e) for r, b, e in res["rows"]]
        if k == "coherent": rebuilt &= same_rows(full(q, ben, harm, cond, l2), res["rows"])
        elif k.startswith("l1_shift"):
            d = F(1, 100) if k.endswith("001") else F(1, 20); data = [dot(r, q) for r in DROWS]
            fr = 0 if data[0] >= d else 1; to = 1 - fr
            basis = [(r, data[i] - d if i == fr else data[i] + d if i == to else data[i], True) for i, r in enumerate(DROWS)] + [(Y1, dot(Y1, q), True), (Y0, dot(Y0, q), True)]
            rebuilt &= same_rows(full(q, ben, harm, cond, basis), res["rows"])
        elif k.startswith("l2_shift"):
            d = F(1, 100) if k.endswith("001") else F(1, 20); v1 = dot(Y1, q); nv = v1 + d if v1 + d <= 1 else v1 - d
            rebuilt &= same_rows(full(q, ben, harm, cond, L1(q) + [(Y1, nv, True), (Y0, dot(Y0, q), True)]), res["rows"])
        elif k == "benefit_in_range":
            pick = rows[8][1]; rebuilt &= bl - 1e-9 <= float(pick) <= bh + 1e-9
        elif k == "benefit_harm_upper":
            worst = max(worst, abs(float(rows[8][1]) - bh), abs(float(rows[9][1]) - hh))
        elif k == "conditional_in_range":
            c1 = -rows[10][0][0]; rebuilt &= bl / float(p0) - 1e-9 <= float(c1) <= bh / float(p0) + 1e-9 and rows[10][0][1] == 0
        a = acc[k]; a[0] += 1; a[1] += 1; a[2] += res["feasible"]; a[3] += exact_check(rows, res)
        scipy_ok &= lp(rows) == res["feasible"]
    # three statuses
    lv = [L1(q), l2, l2 + [(BOTH, dot(BOTH, q), True)]]
    for li, (l, srec) in enumerate(zip(levels, rec["status"])):
        lo, hi = F(srec["lo"]), F(srec["hi"]); w = [F(x) for x in srec["w"]]; s = dot(BEN, w)
        worst = max(worst, abs(float(lo) - lp(lv[li], BEN, -1)), abs(float(hi) - lp(lv[li], BEN, 1)))
        rebuilt &= exact_check(lv[li], dict(feasible=True, w=srec["w"])) and s == F(srec["student"])
        a = st[l]; a[0] += 1; a[1] += lo == hi; a[2] += lo <= ben <= hi; err = abs(s - ben); a[3] += err > F(1, 10); a[4] += err == 0
        mid = (lo + hi) / 2; a[5] += abs(mid - ben) <= (hi - lo) / 2
        stw[l][0] += float(hi - lo); stw[l][1] += float(err); stw[l][2] += float(abs(mid - ben))
    # identification
    probe = [[F(1)] * T] + DROWS + [Y1, Y0]
    zeros = [k for k in range(T) if lp(l2, [F(1) if j == k else F(0) for j in range(T)], 1) <= 1e-12]
    rebuilt &= zeros == rec["zeros"]
    hull = probe + [[F(1) if j == k else F(0) for j in range(T)] for k in zeros]
    rp, rh = rank(probe), rank(hull)
    for (name, c), mine in zip((("benefit", BEN), ("harm", HARM), ("both", BOTH), ("complier", COMP), ("complier_benefit", CB)), rec["ident"]):
        naive, aff = rank(probe + [c]) == rp, rank(hull + [c]) == rh
        w0 = abs(lp(l2, c, 1) - lp(l2, c, -1)) <= 1e-12
        idc[0] += 1; idc[1] += naive; idc[2] += aff; idc[3] += w0; idc[4] += aff == w0; idc[5] += naive and not w0; idc[6] += w0 and not naive
        rebuilt &= mine == [name, naive, aff, w0]
    idc[7] += bool(zeros)
    my = rank(hull + [BEN, HARM, BOTH]) - rh; mc = rank(hull + [COMP, CB]) - rh
    missing[min(my, 2)] += 1; missing[3 + min(mc, 2)] += 1

check("flow_transcripts_rebuilt", rebuilt)
check("flow_feasibility_scipy_agrees", scipy_ok)
check("flow_float_crosscheck", worst < 1e-9, worst)
for k in kinds: eq(f"flow_coherence_{k}", acc[k])
for l in levels: eq(f"flow_status_{l}", st[l] + [stw[l][0] / len(R), stw[l][1] / len(R), stw[l][2] / len(R)])
eq("flow_identification", idc); eq("flow_missing_rank", missing)

# uniform triangle: the cut-polytope inequalities on disagreements d = 1 - e decide extendability
tot = feas = 0
for e1 in range(21):
    for e2 in range(21):
        for e3 in range(21):
            d = [1 - F(e1, 20), 1 - F(e2, 20), 1 - F(e3, 20)]   # pairs (0,1), (0,2), (1,2)
            ok = sum(d) <= 2 and d[0] <= d[1] + d[2] and d[1] <= d[0] + d[2] and d[2] <= d[0] + d[1]
            tot += 1; feas += ok
eq("flow_triangle_uniform", [tot, feas, tot])
# general triangle: HiGHS feasibility over the eight atoms
tot = feas = 0; M = [F(1, 4), F(1, 2), F(3, 4)]; PR = [(0, 1), (0, 2), (1, 2)]
for p1 in M:
    for p2 in M:
        for p3 in M:
            ps = [p1, p2, p3]
            rng_ = [[F(k, 20) for k in range(21) if max(F(0), ps[i] + ps[j] - 1) <= F(k, 20) <= min(ps[i], ps[j])] for i, j in PR]
            for c12 in rng_[0]:
                for c13 in rng_[1]:
                    for c23 in rng_[2]:
                        rows = [([F(1) if v >> i & 1 else F(0) for v in range(8)], ps[i], True) for i in range(3)]
                        rows += [([F(1) if (v >> i & 1 and v >> j & 1) else F(0) for v in range(8)], c, True) for (i, j), c in zip(PR, (c12, c13, c23))]
                        tot += 1; feas += lp(rows)
eq("flow_triangle_general", [tot, feas, tot])

# star covers: replay the stream and glue by an independent product construction
class Rng:
    def __init__(s, st): s.s = st
    def next(s):
        s.s = (s.s + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF; z = s.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & 0xFFFFFFFFFFFFFFFF
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & 0xFFFFFFFFFFFFFFFF
        return z ^ (z >> 31)
    def int(s, lo, hi): return lo + math.floor((s.next() >> 11) * (1.0 / 9007199254740992.0) * (hi - lo + 1))
rng = Rng(20261101004); stars = ok_n = zs = 0
for t in range(2000):
    pa = F(rng.int(0, 4), 4); cond = [[F(rng.int(0, 4), 4), F(rng.int(0, 4), 4)] for _ in range(3)]
    zs += pa in (0, 1)
    pA = {1: pa, 0: 1 - pa}
    joint = {}
    for a in (0, 1):
        for xs in range(8):
            joint[(a, xs)] = pA[a] * math.prod((cond[o][a] if xs >> o & 1 else 1 - cond[o][a]) for o in range(3))
    ok = sum(joint.values()) == 1 and all(v >= 0 for v in joint.values())
    for o in range(3):
        for a in (0, 1):
            for x in (0, 1):
                m = sum(v for (aa, xs), v in joint.items() if aa == a and (xs >> o & 1) == x)
                ok &= m == pA[a] * (cond[o][a] if x else 1 - cond[o][a])
    stars += 1; ok_n += ok
eq("flow_star_gluing", [stars, ok_n, zs])
missing_ = [k for k in cs if not any(c["name"] == k for c in checks)]
for k in missing_: check(k, False, "not validated")
json.dump(dict(checks=checks, all_passed=all(c["passed"] for c in checks), lines=len(cs)), open(sys.argv[3], "w"), indent=1)
print("ALL", all(c["passed"] for c in checks), "lines", len(cs), "checks", len(checks))
