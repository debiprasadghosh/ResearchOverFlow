// Causal-flow distillation numerics. All values exact rationals; public values immutable records.
// (A) Transcript coherence on the instrumental-variable response space: feasibility witness or an exact
//     Farkas refutation (Algorithm 5), under coherent and corrupted teacher or student transcripts.
// (B) Three transfer statuses: certified clone, compatible student, uncertainty-preserving student.
// (C) Identification scope: span test on the full simplex, span test on the affine hull of K, and LP width.
// (D) Probability gluing: binary triangle covers against the cut polytope; star covers by junction-tree construction.
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace Tcr;

/// <summary>A linear record row·q = rhs (Eq) or row·q ≤ rhs.</summary>
public sealed record LinRow(ImmutableArray<Q> Row, Q Rhs, bool Eq);

/// <summary>Outcome of a coherence check: a common witness, or paper-form multipliers (y, ν) with
/// Σ y_i row_i + ν 1 ≥ 0 coordinatewise, y_i ≥ 0 on inequality rows, and Σ y_i rhs_i + ν &lt; 0.</summary>
public sealed record Coherence(bool Feasible, ImmutableArray<Q> Witness, ImmutableArray<Q> Y, Q Nu);

/// <summary>A response-law polytope {q ≥ 0, 1·q = 1, rows}.</summary>
public sealed record Poly(int N, ImmutableArray<LinRow> Rows)
{
    public Poly With(params LinRow[] more) => this with { Rows = Rows.AddRange(more) };

    (List<Q[]> A, List<Q> B, int Nv) Standard()
    {
        int ni = Rows.Count(r => !r.Eq), nv = N + ni, s = 0;
        var a = new List<Q[]>(); var b = new List<Q>();
        foreach (var r in Rows)
        {
            var row = new Q[nv]; for (int j = 0; j < nv; j++) row[j] = j < N ? r.Row[j] : Q.Zero;
            if (!r.Eq) { row[N + s] = Q.One; s++; }
            a.Add(row); b.Add(r.Rhs);
        }
        a.Add(Enumerable.Range(0, nv).Select(j => j < N ? Q.One : Q.Zero).ToArray()); b.Add(Q.One);
        return (a, b, nv);
    }

    /// <summary>Algorithm 5: maximise −Σ artificials. Zero gives a witness; a positive deficit gives Farkas multipliers.</summary>
    public Coherence Check()
    {
        var (a, b, nv) = Standard(); int m = a.Count;
        var flip = b.Select(v => v.Sign < 0).ToArray();
        var rows = Enumerable.Range(0, m).Select(i => Enumerable.Range(0, nv + m).Select(j =>
            j < nv ? (flip[i] ? -a[i][j] : a[i][j]) : (j - nv == i ? Q.One : Q.Zero)).ToArray()).ToList();
        var rhs = Enumerable.Range(0, m).Select(i => flip[i] ? -b[i] : b[i]).ToArray();
        var c = Enumerable.Range(0, nv + m).Select(j => j < nv ? Q.Zero : -Q.One).ToArray();
        var s = Lp.Max(rows, rhs, c);
        if (s.Value.IsZero) return new(true, s.X.Take(N).ToImmutableArray(), ImmutableArray<Q>.Empty, Q.Zero);
        // reduced costs give −y·[A|I] ≤ 0 on the flipped system; unflip and change sign to the paper form
        var y = Enumerable.Range(0, m).Select(i => flip[i] ? -s.Y[i] : s.Y[i]).ToArray();
        var cert = new Coherence(false, ImmutableArray<Q>.Empty, y.Take(m - 1).ToImmutableArray(), y[m - 1]);
        if (!Verifies(cert)) throw new InvalidOperationException("Farkas certificate failed");
        return cert;
    }

    public bool Verifies(Coherence c)
    {
        if (c.Feasible) return Contains(c.Witness);
        for (int i = 0; i < Rows.Length; i++) if (!Rows[i].Eq && c.Y[i].Sign < 0) return false;
        for (int k = 0; k < N; k++)
        {
            Q s = c.Nu; for (int i = 0; i < Rows.Length; i++) s += c.Y[i] * Rows[i].Row[k];
            if (s.Sign < 0) return false;
        }
        Q d = c.Nu; for (int i = 0; i < Rows.Length; i++) d += c.Y[i] * Rows[i].Rhs;
        return d.Sign < 0;
    }

    public bool Contains(IReadOnlyList<Q> q)
    {
        if (q.Count != N || q.Any(v => v.Sign < 0) || q.Aggregate(Q.Zero, (s, v) => s + v) != Q.One) return false;
        foreach (var r in Rows) { Q v = Dot(r.Row, q); if (r.Eq ? v != r.Rhs : v > r.Rhs) return false; }
        return true;
    }

    public static Q Dot(IReadOnlyList<Q> a, IReadOnlyList<Q> q) { Q s = Q.Zero; for (int k = 0; k < a.Count; k++) s += a[k] * q[k]; return s; }

    /// <summary>Exact maximum of c·q on a nonempty polytope. Linearly dependent consistent rows are pruned first.</summary>
    public Q Max(IReadOnlyList<Q> c)
    {
        var (a, b, nv) = Standard();
        var keepA = new List<Q[]>(); var keepB = new List<Q>(); int rank = 0;
        for (int i = 0; i < a.Count; i++)
        {
            var trial = keepA.Append(a[i]).ToList();
            int r = QMat.Of(trial.Count, nv, (x, y) => trial[x][y]).Rank();
            if (r > rank) { keepA.Add(a[i]); keepB.Add(b[i]); rank = r; }
        }
        return Lp.Max(keepA, keepB.ToArray(), Enumerable.Range(0, nv).Select(j => j < N ? c[j] : Q.Zero).ToArray()).Value;
    }
    public (Q Lo, Q Hi) Range(IReadOnlyList<Q> c) => (-Max(c.Select(v => -v).ToArray()), Max(c));
}

public static class FlowCensus
{
    const int T = IvPolytope.T;
    static Q[] Ind(Func<int, bool> f) => Enumerable.Range(0, T).Select(k => f(k) ? Q.One : Q.Zero).ToArray();
    static LinRow EqRow(Q[] r, Q v) => new(r.ToImmutableArray(), v, true);
    static LinRow Le(Q[] r, Q v) => new(r.ToImmutableArray(), v, false);
    static LinRow Ge(Q[] r, Q v) => new(r.Select(x => -x).ToImmutableArray(), -v, false);
    static string S(Q q) => q.ToString();

    static readonly Q[] Y1 = Ind(k => IvPolytope.Yof(k, 1) == 1), Y0 = Ind(k => IvPolytope.Yof(k, 0) == 1);
    static readonly Q[] Benefit = Ind(k => IvPolytope.Yof(k, 1) == 1 && IvPolytope.Yof(k, 0) == 0);
    static readonly Q[] Harm = Ind(k => IvPolytope.Yof(k, 1) == 0 && IvPolytope.Yof(k, 0) == 1);
    static readonly Q[] Both = Ind(k => IvPolytope.Yof(k, 1) == 1 && IvPolytope.Yof(k, 0) == 1);
    static readonly Q[] Y0no = Ind(k => IvPolytope.Yof(k, 0) == 0);
    static readonly Q[] Complier = Ind(k => IvPolytope.Xof(k, 1) == 1 && IvPolytope.Xof(k, 0) == 0);
    static readonly Q[] CompBen = Ind(k => IvPolytope.Xof(k, 1) == 1 && IvPolytope.Xof(k, 0) == 0 && IvPolytope.Yof(k, 1) == 1 && IvPolytope.Yof(k, 0) == 0);

    static Poly L1(IReadOnlyList<Q> q) => new(T, Enumerable.Range(0, 6).Select(r => EqRow(IvPolytope.DataRow(r), Poly.Dot(IvPolytope.DataRow(r), q))).ToImmutableArray());
    static Poly L2(IReadOnlyList<Q> q) => L1(q).With(EqRow(Y1, Poly.Dot(Y1, q)), EqRow(Y0, Poly.Dot(Y0, q)));

    public static void Run(string dir, Action<string, object[]> emit)
    {
        var recs = new List<Dictionary<string, object>>();
        Coherence_(emit, recs);
        Gluing(emit);
        File.WriteAllText(Path.Combine(dir, "flow_records.json"), JsonSerializer.Serialize(recs));
    }

    static void Coherence_(Action<string, object[]> emit, List<Dictionary<string, object>> recs)
    {
        const int N = 1000;
        var rng = new Rng(20261101003UL);
        int Draw(int lo, int hi) { int k; (k, rng) = rng.Int(lo, hi); return k; }
        var kinds = new[] { "coherent", "l1_shift_001", "l1_shift_005", "l2_shift_001", "l2_shift_005", "benefit_in_range", "benefit_harm_upper", "conditional_in_range" };
        var acc = kinds.ToDictionary(k => k, _ => new long[4]);              // cases, separate pass, joint feasible, certificates verified
        var levels = new[] { "L1", "L2", "L2_plus_one_L3" };
        var st = levels.ToDictionary(k => k, _ => new long[6]); var stw = levels.ToDictionary(k => k, _ => new double[3]);
        var targets = new[] { ("benefit", Benefit), ("harm", Harm), ("both", Both), ("complier", Complier), ("complier_benefit", CompBen) };
        var idc = new long[8]; var missing = new long[6];
        for (int inst = 0; inst < N; inst++)
        {
            var wts = Enumerable.Range(0, T).Select(_ => Draw(0, 4)).ToArray(); if (wts.Sum() == 0) wts[Draw(0, 15)] = 1;
            var q = wts.Select(v => Q.Of(v, wts.Sum())).ToImmutableArray();
            var rec = new Dictionary<string, object> { ["q"] = q.Select(S).ToArray() };
            Q ben = Poly.Dot(Benefit, q), harm = Poly.Dot(Harm, q), p0no = Poly.Dot(Y0no, q);
            var l2 = L2(q);
            var (bl, bh) = l2.Range(Benefit); var (hl, hh) = l2.Range(Harm);
            Q cond = p0no.IsZero ? Q.Zero : ben / p0no;
            // the full coherent transcript: L1, L2, benefit, harm, P(Y1 = 1 | Y0 = 0) with a support floor
            Poly Full(Q b1, Q h1, Q c1, Poly basis)
            {
                var p = basis.With(EqRow(Benefit, b1), EqRow(Harm, h1));
                if (p0no.Sign > 0) p = p.With(EqRow(Benefit.Zip(Y0no, (a, b) => a - c1 * b).ToArray(), Q.Zero), Ge(Y0no, p0no / 2));
                return p;
            }
            void Judge(string kind, Poly p, bool separate, Dictionary<string, object> r)
            {
                var a = acc[kind]; a[0]++; if (separate) a[1]++;
                var c = p.Check(); if (c.Feasible) a[2]++; if (p.Verifies(c)) a[3]++;
                r[kind] = new Dictionary<string, object> { ["rows"] = p.Rows.Select(x => new object[] { x.Row.Select(S).ToArray(), S(x.Rhs), x.Eq }).ToArray(),
                    ["feasible"] = c.Feasible, ["w"] = c.Witness.Select(S).ToArray(), ["y"] = c.Y.Select(S).ToArray(), ["nu"] = S(c.Nu) };
            }
            var jr = new Dictionary<string, object>();
            Judge("coherent", Full(ben, harm, cond, l2), true, jr);
            foreach (var (kind, d) in new[] { ("l1_shift_001", Q.Of(1, 100)), ("l1_shift_005", Q.Of(1, 20)) })
            {
                // move mass d between the first two cells of instrument level Z = 0 (stays a valid distribution)
                var data = IvPolytope.DataOf(q); int from = data[0] >= d ? 0 : 1, to = 1 - from;
                if (data[from] < d) { acc[kind][0]++; continue; }
                var rows = Enumerable.Range(0, 6).Select(r => EqRow(IvPolytope.DataRow(r), r == from ? data[r] - d : r == to ? data[r] + d : data[r])).ToImmutableArray();
                var basis = new Poly(T, rows).With(EqRow(Y1, Poly.Dot(Y1, q)), EqRow(Y0, Poly.Dot(Y0, q)));
                Judge(kind, Full(ben, harm, cond, basis), true, jr);
            }
            foreach (var (kind, d) in new[] { ("l2_shift_001", Q.Of(1, 100)), ("l2_shift_005", Q.Of(1, 20)) })
            {
                Q v1 = Poly.Dot(Y1, q); Q nv = v1 + d <= Q.One ? v1 + d : v1 - d;
                var basis = L1(q).With(EqRow(Y1, nv), EqRow(Y0, Poly.Dot(Y0, q)));
                Judge(kind, Full(ben, harm, cond, basis), true, jr);
            }
            // a benefit value drawn inside its own sharp L2 range: separately acceptable, jointly tested
            Q bpick = bl + (bh - bl) * Q.Of(Draw(0, 20), 20);
            Judge("benefit_in_range", Full(bpick, harm, cond, l2), true, jr);
            // Proposition 4.5 at scale: benefit and harm each at the top of their own sharp ranges
            Judge("benefit_harm_upper", Full(bh, hh, cond, l2), true, jr);
            if (p0no.Sign > 0)
            {
                var (cl, ch) = (bl / p0no, bh / p0no);                       // P(Y0 = 0) is fixed by L2
                Judge("conditional_in_range", Full(ben, harm, cl + (ch - cl) * Q.Of(Draw(0, 20), 20), l2), true, jr);
            }
            rec["judged"] = jr;

            // (B) three statuses for the benefit at three information levels
            var lv = new[] { L1(q), l2, l2.With(EqRow(Both, Poly.Dot(Both, q))) };
            var stat = new List<object>();
            for (int li = 0; li < 3; li++)
            {
                var (lo, hi) = lv[li].Range(Benefit); var w = lv[li].Check().Witness; Q student = Poly.Dot(Benefit, w);
                var a = st[levels[li]]; a[0]++; if (lo == hi) a[1]++; if (lo <= ben && ben <= hi) a[2]++;
                Q err = Rounding.Abs(student - ben); if (err > Q.Of(1, 10)) a[3]++; if (err.IsZero) a[4]++;
                Q mid = (lo + hi) / 2; if (Rounding.Abs(mid - ben) <= (hi - lo) / 2) a[5]++;
                stw[levels[li]][0] += (hi - lo).ToDouble(); stw[levels[li]][1] += err.ToDouble(); stw[levels[li]][2] += Rounding.Abs(mid - ben).ToDouble();
                stat.Add(new Dictionary<string, object> { ["lo"] = S(lo), ["hi"] = S(hi), ["student"] = S(student), ["w"] = w.Select(S).ToArray() });
            }
            rec["status"] = stat;

            // (C) identification scope at L2: full-simplex span, affine-hull span and LP width
            var probe = new List<Q[]> { Enumerable.Repeat(Q.One, T).ToArray() };
            for (int r = 0; r < 6; r++) probe.Add(IvPolytope.DataRow(r));
            probe.Add(Y1); probe.Add(Y0);
            var zeros = Enumerable.Range(0, T).Where(k => l2.Max(Enumerable.Range(0, T).Select(j => j == k ? Q.One : Q.Zero).ToArray()).IsZero).ToArray();
            var hull = probe.Concat(zeros.Select(k => Enumerable.Range(0, T).Select(j => j == k ? Q.One : Q.Zero).ToArray())).ToList();
            int RankOf(List<Q[]> rows) => QMat.Of(rows.Count, T, (i, j) => rows[i][j]).Rank();
            int rp = RankOf(probe), rh = RankOf(hull);
            var idr = new List<object>();
            foreach (var (name, c) in targets)
            {
                bool naive = RankOf(probe.Append(c).ToList()) == rp, aff = RankOf(hull.Append(c).ToList()) == rh;
                var (lo, hi) = l2.Range(c); bool width0 = lo == hi;
                idc[0]++; if (naive) idc[1]++; if (aff) idc[2]++; if (width0) idc[3]++;
                if (aff == width0) idc[4]++; if (naive && !width0) idc[5]++; if (width0 && !naive) idc[6]++;
                idr.Add(new object[] { name, naive, aff, width0 });
            }
            if (zeros.Length > 0) idc[7]++;
            rec["zeros"] = zeros; rec["ident"] = idr;
            // missing linear coordinates for the whole Y-coupling family and for the complier family (Theorem 6.1 on the hull)
            var famY = new List<Q[]> { Benefit, Harm, Both }; var famC = new List<Q[]> { Complier, CompBen };
            int my = RankOf(hull.Concat(famY).ToList()) - rh, mc = RankOf(hull.Concat(famC).ToList()) - rh;
            missing[Math.Min(my, 2)]++; missing[3 + Math.Min(mc, 2)]++;
            recs.Add(rec);
        }
        foreach (var k in kinds) emit($"flow_coherence_{k}", new object[] { acc[k] });
        foreach (var l in levels) emit($"flow_status_{l}", new object[] { st[l], stw[l][0] / N, stw[l][1] / N, stw[l][2] / N });
        emit("flow_identification", new object[] { idc });
        emit("flow_missing_rank", new object[] { missing });
    }

    /// <summary>(D) Binary triangle covers with pairwise-consistent laws, and star covers glued by equation (6).</summary>
    static void Gluing(Action<string, object[]> emit)
    {
        // atoms abc in binary order; pairwise laws fixed through P(i = 1) and P(i = 1, j = 1)
        Q[] Atom(Func<int, bool> f) => Enumerable.Range(0, 8).Select(v => f(v) ? Q.One : Q.Zero).ToArray();
        long tri = 0, triFeasible = 0, triCert = 0;
        // uniform marginals; agreements P(i = j) on twentieths
        for (int e1 = 0; e1 <= 20; e1++) for (int e2 = 0; e2 <= 20; e2++) for (int e3 = 0; e3 <= 20; e3++)
        {
            var e = new[] { Q.Of(e1, 20), Q.Of(e2, 20), Q.Of(e3, 20) }; var pr = new[] { (0, 1), (0, 2), (1, 2) };
            var rows = new List<LinRow>();
            for (int i = 0; i < 3; i++) rows.Add(EqRow(Atom(v => (v >> i & 1) == 1), Q.Of(1, 2)));
            for (int k = 0; k < 3; k++) { var (i, j) = pr[k]; rows.Add(EqRow(Atom(v => (v >> i & 1) == (v >> j & 1)), e[k])); }
            var p = new Poly(8, rows.ToImmutableArray()); var c = p.Check(); tri++;
            if (c.Feasible) triFeasible++; if (p.Verifies(c)) triCert++;
        }
        emit("flow_triangle_uniform", new object[] { tri, triFeasible, triCert });
        // general marginals in quarters, P(i = 1, j = 1) on twentieths within the pairwise Fréchet bounds
        long gen = 0, genFeasible = 0, genCert = 0;
        var marg = new[] { Q.Of(1, 4), Q.Of(1, 2), Q.Of(3, 4) };
        foreach (var p1 in marg) foreach (var p2 in marg) foreach (var p3 in marg)
        {
            var ps = new[] { p1, p2, p3 }; var pr = new[] { (0, 1), (0, 2), (1, 2) };
            var ranges = pr.Select(t => Enumerable.Range(0, 21).Select(k => Q.Of(k, 20))
                .Where(c => c >= Q.Max(Q.Zero, ps[t.Item1] + ps[t.Item2] - Q.One) && c <= Q.Min(ps[t.Item1], ps[t.Item2])).ToArray()).ToArray();
            foreach (var c12 in ranges[0]) foreach (var c13 in ranges[1]) foreach (var c23 in ranges[2])
            {
                var cs = new[] { c12, c13, c23 }; var rows = new List<LinRow>();
                for (int i = 0; i < 3; i++) rows.Add(EqRow(Atom(v => (v >> i & 1) == 1), ps[i]));
                for (int k = 0; k < 3; k++) { var (i, j) = pr[k]; rows.Add(EqRow(Atom(v => (v >> i & 1) == 1 && (v >> j & 1) == 1), cs[k])); }
                var p = new Poly(8, rows.ToImmutableArray()); var c = p.Check(); gen++;
                if (c.Feasible) genFeasible++; if (p.Verifies(c)) genCert++;
            }
        }
        emit("flow_triangle_general", new object[] { gen, genFeasible, genCert });
        // star covers {A,B},{A,C},{A,D}: random consistent local laws, extension by equation (6), exact marginal check
        var rng = new Rng(20261101004UL); long stars = 0, starOk = 0, zeroSep = 0;
        for (int t = 0; t < 2000; t++)
        {
            int Draw(int lo, int hi) { int k; (k, rng) = rng.Int(lo, hi); return k; }
            var pa = Q.Of(Draw(0, 4), 4);
            // P(other = 1 | A = a) on quarters, giving pairwise laws consistent on the separator A
            var cond = Enumerable.Range(0, 3).Select(_ => new[] { Q.Of(Draw(0, 4), 4), Q.Of(Draw(0, 4), 4) }).ToArray();
            Q Pair(int o, int a, int x) { Q pa_ = a == 1 ? pa : Q.One - pa; Q pc = cond[o][a]; return pa_ * (x == 1 ? pc : Q.One - pc); }
            if (pa.IsZero || pa == Q.One) zeroSep++;
            var joint = new Q[16];
            for (int v = 0; v < 16; v++)
            {
                int a = v & 1; Q sep = a == 1 ? pa : Q.One - pa;
                if (sep.IsZero) { joint[v] = Q.Zero; continue; }
                Q x = Pair(0, a, v >> 1 & 1);
                for (int o = 1; o < 3; o++) x = x * Pair(o, a, v >> (o + 1) & 1) / sep;
                joint[v] = x;
            }
            bool ok = joint.All(x => x.Sign >= 0) && joint.Aggregate(Q.Zero, (s, x) => s + x) == Q.One;
            for (int o = 0; o < 3 && ok; o++)
                for (int a = 0; a <= 1; a++) for (int x = 0; x <= 1; x++)
                {
                    Q m = Q.Zero; for (int v = 0; v < 16; v++) if ((v & 1) == a && (v >> (o + 1) & 1) == x) m += joint[v];
                    if (m != Pair(o, a, x)) ok = false;
                }
            stars++; if (ok) starOk++;
        }
        emit("flow_star_gluing", new object[] { stars, starOk, zeroSep });
    }
}
