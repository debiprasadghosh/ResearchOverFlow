// All marginal masses of a five-event law (from the Version 3 operation census).
using System.Collections.Immutable;
using System.Linq;

namespace Tcr;

/// <summary>All marginal masses of a law on five binary events, indexed by (mask, values on mask).</summary>
public sealed record Marginals(ImmutableArray<Q> M)
{
    public const int N = 5;
    public static Marginals Of(ImmutableArray<Q> law)
    {
        var acc = Enumerable.Repeat(Q.Zero, 1 << 2 * N).ToArray();
        for (int v = 0; v < 1 << N; v++)
            for (int mask = 0; mask < 1 << N; mask++) acc[mask << N | (v & mask)] += law[v];
        return new(acc.ToImmutableArray());
    }
    public Q Mass(int mask, int vals) => M[mask << N | (vals & mask)];
    /// <summary>P(Y = 1 | mask = vals); y must lie outside mask.</summary>
    public Q Cond(int y, int mask, int vals) => Mass(mask | 1 << y, vals | 1 << y) / Mass(mask, vals);
}

