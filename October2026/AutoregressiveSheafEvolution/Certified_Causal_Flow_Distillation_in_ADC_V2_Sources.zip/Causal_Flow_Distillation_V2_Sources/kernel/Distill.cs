// Verified transitions for teacher-to-ADC training data: exact positive binary DAG models, the
// complete adjustment criterion, typed adjustment derivations with corruptions, and four checkers
// (exact answer, rounded answer, overlap residual, transition certificate). Public values are
// immutable records; enumeration uses local scratch storage only.
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Globalization;
using System.Linq;
using System.Numerics;

namespace Tcr;

/// <summary>A positive binary DAG model. Cpt[i][c] = P(V_i = 1 | parent configuration c), parents ascending.</summary>
public sealed record CptModel(Admg Graph, ImmutableArray<ImmutableArray<int>> Parents, ImmutableArray<ImmutableArray<Q>> Cpt)
{
    public int N => Graph.N;

    public static (CptModel Model, Rng Next) Random(Admg g, Rng rng, int grid = 10)
    {
        var parents = Enumerable.Range(0, g.N).Select(i => g.D.Where(e => e.To == i).Select(e => e.From).OrderBy(p => p).ToImmutableArray()).ToImmutableArray();
        var cpt = ImmutableArray.CreateBuilder<ImmutableArray<Q>>();
        for (int i = 0; i < g.N; i++)
        {
            var row = ImmutableArray.CreateBuilder<Q>();
            for (int c = 0; c < 1 << parents[i].Length; c++) { int k; (k, rng) = rng.Int(1, grid - 1); row.Add(Q.Of(k, grid)); }
            cpt.Add(row.ToImmutable());
        }
        return (new CptModel(g, parents, cpt.ToImmutable()), rng);
    }

    Q Factor(int i, int v)
    {
        int c = 0; for (int k = 0; k < Parents[i].Length; k++) c |= (v >> Parents[i][k] & 1) << k;
        var p = Cpt[i][c]; return (v >> i & 1) != 0 ? p : Q.One - p;
    }

    /// <summary>Joint law, optionally under do(X = xv) for a single action vertex x (x &lt; 0: none).</summary>
    public ImmutableArray<Q> Law(int x = -1, int xv = 0) => Enumerable.Range(0, 1 << N).Select(v =>
        x >= 0 && (v >> x & 1) != xv ? Q.Zero
        : Enumerable.Range(0, N).Where(i => i != x).Aggregate(Q.One, (acc, i) => acc * Factor(i, v))).ToImmutableArray();

    public static Q Mass(ImmutableArray<Q> law, int mask, int values) =>
        law.Where((_, v) => (v & mask) == (values & mask)).Aggregate(Q.Zero, (a, b) => a + b);
}

/// <summary>The complete adjustment criterion for a single action and outcome in a DAG
/// (Shpitser, VanderWeele and Robins, 2010; Perkovic et al., 2015), and the classical back-door criterion.</summary>
public static class Adjustment
{
    static int Descendants(Admg g, int s)
    {
        int old; do { old = s; foreach (var e in g.D) if ((s >> e.From & 1) != 0) s |= 1 << e.To; } while (s != old);
        return s;
    }
    public static bool Valid(Admg g, int x, int y, int z)
    {
        int causal = Descendants(g, 1 << x) & g.Ancestors(1 << y) & ~(1 << x);      // vertices on proper causal paths, without x
        int forb = Descendants(g, causal) | 1 << x;
        if ((z & forb) != 0) return false;
        var pbd = Admg.Make(g.N, g.D.Where(e => !(e.From == x && (causal >> e.To & 1) != 0)), g.B);
        return pbd.Separated(1 << y, 1 << x, z);
    }
    public static bool BackDoor(Admg g, int x, int y, int z) =>
        (z & Descendants(g, 1 << x)) == 0 && g.Mutilate(0, 1 << x).Separated(1 << y, 1 << x, z);
}

/// <summary>A typed adjustment derivation: the claimed set, three local tables and the answer.
/// T0 = P(x, z) over (x, z); T1 = P(z); T2 = P(Y = 1 | x, z) at the action value.</summary>
public sealed record Derivation(int Z, ImmutableArray<Q> T0, ImmutableArray<Q> T1, ImmutableArray<Q> T2, Q Answer)
{
    static int Embed(int zmask, int k) { int v = 0, j = 0; foreach (int i in SetBits.Of(zmask)) { v |= (k >> j & 1) << i; j++; } return v; }

    /// <summary>The honest derivation for set z, computed from the observational law.</summary>
    public static Derivation Honest(ImmutableArray<Q> law, int x, int xv, int y, int z)
    {
        int nz = SetBits.Count(z), m = 1 << nz;
        var t1 = Enumerable.Range(0, m).Select(k => CptModel.Mass(law, z, Embed(z, k))).ToImmutableArray();
        var t0 = Enumerable.Range(0, 2 * m).Select(k => CptModel.Mass(law, z | 1 << x, Embed(z, k >> 1) | (k & 1) << x)).ToImmutableArray();
        var t2 = Enumerable.Range(0, m).Select(k =>
        {
            int cond = z | 1 << x, vals = Embed(z, k) | xv << x;
            return CptModel.Mass(law, cond | 1 << y, vals | 1 << y) / CptModel.Mass(law, cond, vals);
        }).ToImmutableArray();
        var ans = Enumerable.Range(0, m).Aggregate(Q.Zero, (s, k) => s + t2[k] * t1[k]);
        return new(z, t0, t1, t2, ans);
    }
    /// <summary>Overlap residual: the Z-marginal of T0 must equal T1, and T1 must sum to one.</summary>
    public bool OverlapAgrees() =>
        Enumerable.Range(0, T1.Length).All(k => T0[2 * k] + T0[2 * k + 1] == T1[k]) && T1.Aggregate(Q.Zero, (a, b) => a + b) == Q.One;
    /// <summary>Transition certificate: graph premise, every table recomputed exactly, and the final sum.</summary>
    public bool Certified(Admg g, ImmutableArray<Q> law, int x, int xv, int y)
    {
        if (!Adjustment.Valid(g, x, y, Z)) return false;
        var h = Honest(law, x, xv, y, Z);
        return h.T0.SequenceEqual(T0) && h.T1.SequenceEqual(T1) && h.T2.SequenceEqual(T2)
            && Enumerable.Range(0, T1.Length).Aggregate(Q.Zero, (s, k) => s + T2[k] * T1[k]) == Answer;
    }
}

public static class Rounding
{
    /// <summary>Round half up to d decimals, exactly.</summary>
    public static BigInteger Round(Q q, int d)
    {
        var s = BigInteger.Pow(10, d); var t = q * new Q(s, 1) + Q.Of(1, 2);
        return BigInteger.Divide(t.Num - (t.Num.Sign < 0 ? t.Den - 1 : 0), t.Den);
    }
    public static Q Abs(Q q) => q.Sign < 0 ? -q : q;
}
