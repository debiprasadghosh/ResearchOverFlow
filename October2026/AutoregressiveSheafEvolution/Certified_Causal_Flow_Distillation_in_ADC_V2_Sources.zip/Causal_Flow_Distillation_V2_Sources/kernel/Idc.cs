// Interval Do Calculus numerics. (S) surgery census on the inherited 6,144 DAG models: baseline transmission
// (Lemma 2.2) and the order of incoming-clamp and outgoing-baseline responses (Proposition 2.3).
// (W) a sequential-evidence workload on the instrumental-variable response polytope: sharp bounds by an exact
// simplex that returns primal witnesses and dual multipliers; witness reuse (Theorem 5.2, Corollary 5.3);
// multiplier repair after changed data (Theorem 5.4); query transport (Proposition 6.2); joint versus marginal
// decision certificates (Theorem 7.3). Public values are immutable records; tableaux are local scratch storage.
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace Tcr;

/// <summary>An exact optimum of max c·x over {Ax = b, x ≥ 0}: value, primal witness, dual multipliers, pivots.</summary>
public sealed record LpSolution(Q Value, ImmutableArray<Q> X, ImmutableArray<Q> Y, int Pivots);

public static class Lp
{
    public static LpSolution Max(IReadOnlyList<Q[]> a, Q[] b, Q[] c)
    {
        int m = a.Count, n = c.Length, w = n + m + 1, piv = 0;
        var t = new Q[m + 1, w];
        for (int i = 0; i < m; i++)
        {
            bool flip = b[i].Sign < 0;
            for (int j = 0; j < n; j++) t[i, j] = flip ? -a[i][j] : a[i][j];
            for (int j = n; j < n + m; j++) t[i, j] = j - n == i ? Q.One : Q.Zero;
            t[i, w - 1] = flip ? -b[i] : b[i];
        }
        var basis = Enumerable.Range(n, m).ToArray();
        for (int j = 0; j < w; j++)
        {
            Q s = Q.Zero; if (j < n || j == w - 1) for (int i = 0; i < m; i++) s += t[i, j];
            t[m, j] = j < n || j == w - 1 ? -s : Q.Zero;
        }
        piv += Run(t, basis, m, n + m, w);
        if (!t[m, w - 1].IsZero) throw new InvalidOperationException("infeasible");
        for (int i = 0; i < m; i++)
        {
            if (basis[i] < n) continue;
            int col = Enumerable.Range(0, n).FirstOrDefault(j => !t[i, j].IsZero, -1);
            if (col < 0) throw new InvalidOperationException("redundant row");
            Pivot(t, basis, i, col, m + 1, w); piv++;
        }
        var t2 = new Q[m + 1, n + 1];
        for (int r = 0; r < m; r++) { for (int j = 0; j < n; j++) t2[r, j] = t[r, j]; t2[r, n] = t[r, w - 1]; }
        for (int j = 0; j <= n; j++) t2[m, j] = j < n ? -c[j] : Q.Zero;
        for (int r = 0; r < m; r++)
        {
            var f = t2[m, basis[r]]; if (f.IsZero) continue;
            for (int j = 0; j <= n; j++) t2[m, j] -= f * t2[r, j];
        }
        int p2 = Run(t2, basis, m, n, n + 1); if (p2 < 0) throw new InvalidOperationException("unbounded"); piv += p2;
        var x = new Q[n]; for (int j = 0; j < n; j++) x[j] = Q.Zero;
        for (int r = 0; r < m; r++) x[basis[r]] = t2[r, n];
        // duals: Bᵀ y = c_B on the optimal basis, then check every reduced cost and the duality gap exactly
        var bt = QMat.Of(m, m, (i, k) => a[k][basis[i]]);
        var y = bt.Inverse().Mul(QMat.Of(m, 1, (i, _) => c[basis[i]]));
        var ys = Enumerable.Range(0, m).Select(i => y[i, 0]).ToImmutableArray();
        for (int j = 0; j < n; j++)
        {
            Q red = c[j]; for (int i = 0; i < m; i++) red -= ys[i] * a[i][j];
            if (red.Sign > 0) throw new InvalidOperationException("dual infeasible");
        }
        Q val = t2[m, n], dv = Q.Zero; for (int i = 0; i < m; i++) dv += ys[i] * b[i];
        if (dv != val) throw new InvalidOperationException("duality gap");
        return new(val, x.ToImmutableArray(), ys, piv);
    }
    /// <summary>Phase one only: is {Ax = b, x ≥ 0} nonempty? Returns the answer and the pivots spent.</summary>
    public static (bool Feasible, int Pivots) Phase1(IReadOnlyList<Q[]> a, Q[] b)
    {
        int m = a.Count, n = a[0].Length, w = n + m + 1;
        var t = new Q[m + 1, w];
        for (int i = 0; i < m; i++)
        {
            bool flip = b[i].Sign < 0;
            for (int j = 0; j < n; j++) t[i, j] = flip ? -a[i][j] : a[i][j];
            for (int j = n; j < n + m; j++) t[i, j] = j - n == i ? Q.One : Q.Zero;
            t[i, w - 1] = flip ? -b[i] : b[i];
        }
        var basis = Enumerable.Range(n, m).ToArray();
        for (int j = 0; j < w; j++)
        {
            Q s = Q.Zero; if (j < n || j == w - 1) for (int i = 0; i < m; i++) s += t[i, j];
            t[m, j] = j < n || j == w - 1 ? -s : Q.Zero;
        }
        int piv = Run(t, basis, m, n + m, w);
        return (t[m, w - 1].IsZero, piv);
    }
    static int Run(Q[,] t, int[] basis, int m, int nVars, int w)
    {
        int k = 0;
        while (true)
        {
            int col = -1; for (int j = 0; j < nVars; j++) if (t[m, j].Sign < 0) { col = j; break; }
            if (col < 0) return k;
            int row = -1; Q best = Q.Zero;
            for (int i = 0; i < m; i++)
            {
                if (t[i, col].Sign <= 0) continue;
                var ratio = t[i, w - 1] / t[i, col];
                if (row < 0 || ratio < best || (ratio == best && basis[i] < basis[row])) { row = i; best = ratio; }
            }
            if (row < 0) return -1;
            Pivot(t, basis, row, col, m + 1, w); k++;
        }
    }
    static void Pivot(Q[,] t, int[] basis, int row, int col, int rows, int w)
    {
        var inv = Q.One / t[row, col];
        for (int j = 0; j < w; j++) t[row, j] *= inv;
        for (int i = 0; i < rows; i++)
        {
            if (i == row || t[i, col].IsZero) continue;
            var f = t[i, col];
            for (int j = 0; j < w; j++) if (!t[row, j].IsZero) t[i, j] -= f * t[row, j];
        }
        basis[row] = col;
    }
}

/// <summary>The instrumental-variable response polytope: 16 response types (X type × Y type), six data rows,
/// normalisation, and interval reports lo ≤ s·q ≤ hi on groups of types. Rows are kept in the paper's form
/// (equalities E q = f, inequalities A q ≤ b) and converted to standard form with slacks for the simplex.</summary>
public sealed record IvPolytope(ImmutableArray<Q> Data, ImmutableArray<(int Mask, Q Lo, Q Hi)> Reports)
{
    public const int T = 16;
    public static int Xof(int k, int z) => (k >> 2) >> z & 1;
    public static int Yof(int k, int x) => (k & 3) >> x & 1;
    public static readonly (int Z, int X, int Y)[] Cells = { (0, 0, 0), (0, 0, 1), (0, 1, 0), (1, 0, 0), (1, 0, 1), (1, 1, 0) };
    public static Q[] DataRow(int r) => Enumerable.Range(0, T).Select(k => Xof(k, Cells[r].Z) == Cells[r].X && Yof(k, Cells[r].X) == Cells[r].Y ? Q.One : Q.Zero).ToArray();
    public static ImmutableArray<Q> DataOf(IReadOnlyList<Q> q) => Enumerable.Range(0, 6).Select(r => DataRow(r).Zip(q, (a, b) => a * b).Aggregate(Q.Zero, (s, v) => s + v)).ToImmutableArray();
    public static Q[] Group(int mask) => Enumerable.Range(0, T).Select(k => (mask >> k & 1) != 0 ? Q.One : Q.Zero).ToArray();
    /// <summary>Paper-form rows: 6 data equalities, then for each report the rows s·q ≤ hi and −s·q ≤ −lo.</summary>
    public (List<Q[]> Rows, List<Q> Rhs, int Eq) PaperRows()
    {
        var rows = new List<Q[]>(); var rhs = new List<Q>();
        for (int r = 0; r < 6; r++) { rows.Add(DataRow(r)); rhs.Add(Data[r]); }
        foreach (var (mask, lo, hi) in Reports) { var g = Group(mask); rows.Add(g); rhs.Add(hi); rows.Add(g.Select(v => -v).ToArray()); rhs.Add(-lo); }
        return (rows, rhs, 6);
    }
    /// <summary>Solve max c·q. Returns the optimum with paper-form multipliers (normalisation multiplier dropped).</summary>
    public LpSolution Max(Q[] c)
    {
        var (rows, rhs, eq) = PaperRows(); int ni = rows.Count - eq, n = T + ni;
        var a = new List<Q[]>(); var b = new List<Q>();
        for (int i = 0; i < rows.Count; i++)
        {
            var row = new Q[n]; for (int j = 0; j < n; j++) row[j] = j < T ? rows[i][j] : (i >= eq && j - T == i - eq ? Q.One : Q.Zero);
            a.Add(row); b.Add(rhs[i]);
        }
        a.Add(Enumerable.Range(0, n).Select(j => j < T ? Q.One : Q.Zero).ToArray()); b.Add(Q.One);
        var s = Lp.Max(a, b.ToArray(), c.Concat(Enumerable.Repeat(Q.Zero, ni)).ToArray());
        return s with { X = s.X.Take(T).ToImmutableArray(), Y = s.Y.Take(rows.Count).ToImmutableArray() };
    }
    /// <summary>Theorem 5.2 as an algorithm: the old endpoint value v is still attained iff K ∩ {c·q = v} is nonempty.</summary>
    public (bool Feasible, int Pivots) FaceFeasible(Q[] c, Q v)
    {
        var (rows, rhs, eq) = PaperRows(); int ni = rows.Count - eq, n = T + ni;
        var a = new List<Q[]>(); var b = new List<Q>();
        for (int i = 0; i < rows.Count; i++)
        {
            var row = new Q[n]; for (int j = 0; j < n; j++) row[j] = j < T ? rows[i][j] : (i >= eq && j - T == i - eq ? Q.One : Q.Zero);
            a.Add(row); b.Add(rhs[i]);
        }
        a.Add(Enumerable.Range(0, n).Select(j => j < T ? Q.One : Q.Zero).ToArray()); b.Add(Q.One);
        a.Add(Enumerable.Range(0, n).Select(j => j < T ? c[j] : Q.Zero).ToArray()); b.Add(v);
        return Lp.Phase1(a, b.ToArray());
    }
    /// <summary>Theorem 5.4: B_λ(c; A, b) = λ·b + max_i (c − Aᵀλ)_i, with free signs on the equality rows.</summary>
    public Q Repair(Q[] c, IReadOnlyList<Q> lam)
    {
        var (rows, rhs, eq) = PaperRows();
        for (int i = eq; i < rows.Count; i++) if (lam[i].Sign < 0) throw new ArgumentException("negative inequality multiplier");
        Q s = Q.Zero; for (int i = 0; i < rows.Count; i++) s += lam[i] * rhs[i];
        return s + Enumerable.Range(0, T).Select(k => { Q r = c[k]; for (int i = 0; i < rows.Count; i++) r -= lam[i] * rows[i][k]; return r; }).Max();
    }
    public bool Feasible(IReadOnlyList<Q> q)
    {
        var (rows, rhs, eq) = PaperRows();
        for (int i = 0; i < rows.Count; i++)
        {
            Q v = Q.Zero; for (int k = 0; k < T; k++) v += rows[i][k] * q[k];
            if (i < eq ? v != rhs[i] : v > rhs[i]) return false;
        }
        return q.All(v => v.Sign >= 0) && q.Aggregate(Q.Zero, (s, v) => s + v) == Q.One;
    }
}

public static class IdcCensus
{
    static Q[] Y1 => Enumerable.Range(0, IvPolytope.T).Select(k => IvPolytope.Yof(k, 1) == 1 ? Q.One : Q.Zero).ToArray();
    static Q[] Y0 => Enumerable.Range(0, IvPolytope.T).Select(k => IvPolytope.Yof(k, 0) == 1 ? Q.One : Q.Zero).ToArray();
    static Q[] Neg(Q[] c) => c.Select(v => -v).ToArray();
    static string S(Q q) => q.ToString();

    public static void Run(string dir, Action<string, object[]> emit)
    {
        Surgery(emit);
        Workload(dir, emit);
    }

    /// <summary>Outgoing baseline replacement versus do(X = x0) on the inherited DAG family.</summary>
    static void Surgery(Action<string, object[]> emit)
    {
        const int n = 5;
        var pairs = (from i in Enumerable.Range(0, n) from j in Enumerable.Range(i + 1, n - i - 1) select new Edge(i, j)).ToArray();
        foreach (var (tag, grid, seed) in new[] { ("tenths", 10, 20261031001UL), ("hundredths", 100, 20261031002UL) })
        {
            var rng = new Rng(seed);
            long regimes = 0, marginalEqual = 0, jointDiffers = 0, ordered = 0, up = 0, down = 0, tie = 0, graphsBoth = 0;
            for (int dm = 0; dm < 1 << pairs.Length; dm++)
            {
                var g = Admg.Make(n, pairs.Where((_, k) => (dm >> k & 1) != 0), Array.Empty<Edge>());
                var seenUp = new HashSet<(int, int)>(); var seenDown = new HashSet<(int, int)>();
                for (int r = 0; r < 3; r++)
                {
                    CptModel model; (model, rng) = CptModel.Random(g, rng, grid);
                    for (int x = 0; x < n; x++)
                        for (int xv = 0; xv <= 1; xv++)
                        {
                            regimes++;
                            var dol = model.Law(x, xv);
                            // outgoing replacement: every child reads xv in place of X; X keeps its own mechanism
                            var outl = Enumerable.Range(0, 1 << n).Select(v => Enumerable.Range(0, n).Aggregate(Q.One, (acc, i) =>
                            {
                                int arg = i == x ? v : (v & ~(1 << x)) | xv << x;
                                int c = 0; for (int k = 0; k < model.Parents[i].Length; k++) c |= (arg >> model.Parents[i][k] & 1) << k;
                                var p = model.Cpt[i][c]; return acc * ((v >> i & 1) != 0 ? p : Q.One - p);
                            })).ToImmutableArray();
                            int rest = (1 << n) - 1 & ~(1 << x);
                            bool same = Enumerable.Range(0, 1 << n).Where(v => (v & ~rest) == 0).All(v => CptModel.Mass(dol, rest, v) == CptModel.Mass(outl, rest, v));
                            if (same) marginalEqual++;
                            if (!dol.SequenceEqual(outl)) jointDiffers++;
                        }
                    for (int x = 0; x < n; x++) for (int y = x + 1; y < n; y++)
                    {
                        if ((g.Ancestors(1 << y) >> x & 1) == 0) continue;
                        ordered++;
                        Q p1 = CptModel.Mass(model.Law(x, 1), 1 << y, 1 << y), p0 = CptModel.Mass(model.Law(x, 0), 1 << y, 1 << y);
                        if (p1 > p0) { up++; seenUp.Add((x, y)); } else if (p1 < p0) { down++; seenDown.Add((x, y)); } else tie++;
                    }
                }
                graphsBoth += seenUp.Intersect(seenDown).Count();
            }
            emit($"{tag}_surgery", new object[] { regimes, marginalEqual, jointDiffers, ordered, up, down, tie, graphsBoth });
        }
    }

    sealed class Tally { public long[] V = new long[24]; }

    /// <summary>Sequential evidence on the IV polytope with both a fresh-solve policy and the IDC reuse policy.</summary>
    static void Workload(string dir, Action<string, object[]> emit)
    {
        const int N = 1000, Steps = 6;
        var rng = new Rng(20261101001UL);
        int Draw(int lo, int hi) { int k; (k, rng) = rng.Int(lo, hi); return k; }
        var t = new long[40]; var repT = new long[2, 6]; long pivFresh = 0, pivIdc = 0, pivFace = 0;
        var trans = new long[4]; double widthRatioSum = 0;
        var records = new List<Dictionary<string, object>>();
        Q[] c1 = Y1, c0 = Y0, ate = c1.Zip(c0, (a, b) => a - b).ToArray();
        for (int inst = 0; inst < N; inst++)
        {
            var wts = Enumerable.Range(0, IvPolytope.T).Select(_ => Draw(0, 4)).ToArray(); if (wts.Sum() == 0) wts[Draw(0, 15)] = 1;
            var qs = wts.Select(v => Q.Of(v, wts.Sum())).ToImmutableArray();
            var poly = new IvPolytope(IvPolytope.DataOf(qs), ImmutableArray<(int, Q, Q)>.Empty);
            var rec = new Dictionary<string, object> { ["q"] = qs.Select(S).ToArray() };
            var steps = new List<Dictionary<string, object>>();
            LpSolution up = poly.Max(c1), lo = poly.Max(Neg(c1));
            pivFresh += up.Pivots + lo.Pivots; pivIdc += up.Pivots + lo.Pivots; pivFace += up.Pivots + lo.Pivots;
            bool decidedJoint = false, decidedMarg = false; int firstJ = -1, firstM = -1;
            for (int s = 0; s <= Steps; s++)
            {
                if (s > 0)
                {
                    int mask; do mask = Draw(1, (1 << 16) - 2); while (mask == 0);
                    Q v = IvPolytope.Group(mask).Zip(qs, (a, b) => a * b).Aggregate(Q.Zero, (x, y) => x + y);
                    Q rlo = Q.Max(Q.Zero, v - Q.Of(Draw(0, 3), 40)), rhi = Q.Min(Q.One, v + Q.Of(Draw(0, 3), 40));
                    var next = poly with { Reports = poly.Reports.Add((mask, rlo, rhi)) };
                    LpSolution nu = next.Max(c1), nl = next.Max(Neg(c1));
                    pivFresh += nu.Pivots + nl.Pivots; t[0]++;
                    // Theorem 5.1: the old interval still encloses; Theorem 5.2 / Corollary 5.3: stored witnesses
                    if (-nl.Value >= -lo.Value && nu.Value <= up.Value) t[1]++;
                    bool wu = next.Feasible(up.X), wl = next.Feasible(lo.X);
                    if (wu) t[2]++; if (wl) t[3]++; if (wu && wl) t[4]++;
                    if (!wu && nu.Value == up.Value) t[5]++; if (!wl && nl.Value == lo.Value) t[6]++;
                    if (wu && nu.Value != up.Value) t[7]++; if (wl && nl.Value != lo.Value) t[7]++;
                    if (nu.Value != up.Value) t[8]++; if (nl.Value != lo.Value) t[9]++;
                    // IDC policy: re-solve only an endpoint whose witness failed
                    t[10] += (wu ? 0 : 1) + (wl ? 0 : 1); if (!wu) pivIdc += nu.Pivots; if (!wl) pivIdc += nl.Pivots;
                    // IDC with the face test: witness, then phase-one feasibility of K' ∩ {c·q = old endpoint}, then a solve
                    foreach (var (ok, cc, old, fresh) in new[] { (wu, c1, up.Value, nu), (wl, Neg(c1), lo.Value, nl) })
                    {
                        if (ok) continue;
                        var (ff, fp) = next.FaceFeasible(cc, old); t[22]++; pivFace += fp;
                        if (ff) { t[23]++; if (fresh.Value == old) t[24]++; } else { t[25]++; pivFace += fresh.Pivots; if (fresh.Value != old) t[26]++; }
                    }
                    // multiplier repair with zero multipliers on the added rows reproduces the old endpoint exactly
                    var lamU = up.Y.AddRange(new[] { Q.Zero, Q.Zero }); if (next.Repair(c1, lamU) == up.Value) t[11]++;
                    poly = next; up = nu; lo = nl;
                }
                // decision: treat if P(Y1=1) − P(Y0=1) > 0; joint contrast versus marginal subtraction
                LpSolution au = poly.Max(ate), al = poly.Max(Neg(ate)), u0 = poly.Max(c0), l0 = poly.Max(Neg(c0));
                Q jlo = -al.Value, jhi = au.Value, mlo = -lo.Value - u0.Value, mhi = up.Value + l0.Value;
                bool dj = jlo.Sign > 0 || jhi.Sign < 0, dmg = mlo.Sign > 0 || mhi.Sign < 0;
                t[12]++; if (dj) t[13]++; if (dmg) t[14]++; if (dj && !dmg) t[15]++; if (dmg && !dj) t[16]++;
                if (dj && firstJ < 0) firstJ = s; if (dmg && firstM < 0) firstM = s;
                if (mhi - mlo >= jhi - jlo) t[17]++;
                steps.Add(new() { ["mask"] = s == 0 ? 0 : poly.Reports[^1].Mask, ["lo"] = s == 0 ? "0" : S(poly.Reports[^1].Lo), ["hi"] = s == 0 ? "0" : S(poly.Reports[^1].Hi),
                    ["U1"] = S(up.Value), ["L1"] = S(-lo.Value), ["xU"] = up.X.Select(S).ToArray(), ["xL"] = lo.X.Select(S).ToArray(),
                    ["yU"] = up.Y.Select(S).ToArray(), ["yL"] = lo.Y.Select(S).ToArray(), ["U0"] = S(u0.Value), ["L0"] = S(-l0.Value), ["Uate"] = S(jhi), ["Late"] = S(jlo) });
            }
            if (firstJ >= 0) t[18]++; if (firstM >= 0) t[19]++; if (firstJ >= 0 && (firstM < 0 || firstJ < firstM)) t[20]++;
            if (firstM >= 0 && firstJ > firstM) t[21]++;
            rec["steps"] = steps;

            // Theorem 5.4 after changed data: move mass between two types, reuse the step-0 multipliers
            var p0 = new IvPolytope(IvPolytope.DataOf(qs), ImmutableArray<(int, Q, Q)>.Empty);
            LpSolution u = p0.Max(c1), l = p0.Max(Neg(c1));
            var repairs = new List<object>();
            for (int mi = 0; mi < 2; mi++)
            {
                Q mv = mi == 0 ? Q.Of(1, 100) : Q.Of(1, 20);
                var donors = Enumerable.Range(0, 16).Where(k => qs[k] >= mv).ToArray();
                int i = donors[Draw(0, donors.Length - 1)], j; do j = Draw(0, 15); while (j == i);
                var q2 = qs.SetItem(i, qs[i] - mv).SetItem(j, qs[j] + mv);
                var p2 = new IvPolytope(IvPolytope.DataOf(q2), ImmutableArray<(int, Q, Q)>.Empty);
                LpSolution fu = p2.Max(c1), fl = p2.Max(Neg(c1));
                Q bu = p2.Repair(c1, u.Y), bl = -p2.Repair(Neg(c1), l.Y);
                Q gap = Q.Max(bu - fu.Value, -fl.Value - bl);
                repT[mi, 0]++;
                if (bu >= fu.Value && bl <= -fl.Value) repT[mi, 1]++;
                if (gap.IsZero) repT[mi, 2]++; if (gap <= Q.Of(1, 100)) repT[mi, 3]++; if (gap <= Q.Of(1, 20)) repT[mi, 4]++;
                if (fu.Value > u.Value || -fl.Value < -l.Value) repT[mi, 5]++;          // the old numbers are no longer valid bounds
                repairs.Add(new Dictionary<string, object> { ["i"] = i, ["j"] = j, ["m"] = S(mv), ["BU"] = S(bu), ["BL"] = S(bl), ["U"] = S(fu.Value), ["L"] = S(-fl.Value) });
            }
            rec["repairs"] = repairs;
            // Proposition 6.2: query transport for c' = c1 + d
            var d = Enumerable.Range(0, 16).Select(_ => Q.Of(Draw(-1, 1), 20)).ToArray();
            var cp = c1.Zip(d, (a, b) => a + b).ToArray();
            LpSolution tu = p0.Max(cp), tl = p0.Max(Neg(cp));
            Q tlo = -l.Value + d.Min(), thi = u.Value + d.Max();
            trans[0]++; if (tlo <= -tl.Value && tu.Value <= thi) trans[1]++;
            if (tlo == -tl.Value && thi == tu.Value) trans[2]++;
            Q fw = tu.Value + tl.Value; if (fw.Sign > 0) { widthRatioSum += ((thi - tlo) / fw).ToDouble(); trans[3]++; }
            rec["d"] = d.Select(S).ToArray(); rec["TU"] = S(tu.Value); rec["TL"] = S(-tl.Value);
            records.Add(rec);
        }
        emit("iv_refinement", new object[] { t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7], t[8], t[9], t[10], t[11] });
        emit("iv_solver_work", new object[] { 2 * t[0], t[10], pivFresh, pivIdc });
        emit("iv_face_test", new object[] { t[22], t[23], t[24], t[25], t[26], pivFace });
        emit("iv_decision", new object[] { t[12], t[13], t[14], t[15], t[16], t[17], t[18], t[19], t[20], t[21] });
        for (int mi = 0; mi < 2; mi++) emit($"iv_repair_m{mi}", new object[] { repT[mi, 0], repT[mi, 1], repT[mi, 2], repT[mi, 3], repT[mi, 4], repT[mi, 5] });
        emit("iv_transport", new object[] { trans[0], trans[1], trans[2], trans[3], widthRatioSum / trans[3] });
        File.WriteAllText(Path.Combine(dir, "iv_records.json"), JsonSerializer.Serialize(records));
    }
}
