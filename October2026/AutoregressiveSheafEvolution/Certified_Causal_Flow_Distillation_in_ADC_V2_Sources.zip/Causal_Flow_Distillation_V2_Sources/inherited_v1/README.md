# Causal Flow Distillation in Autoregressive Do Calculus

Debi Prasad Ghosh, 1 November 2026.

This bundle reproduces the exact finite examples and the Word paper. It contains no trained neural model and no measured agent speed-up.

## Contents

- `manuscript.template.md` contains the authored text and result placeholders.
- `paper.md` is the filled, readable manuscript with LaTeX equation sources.
- `check_distillation.py` generates the exact finite result file.
- `results.json` contains all 27 named checks and their quantitative results.
- `results_rerun.json` is the byte-identical result from a clean second process.
- `build_paper.py` inserts result values, generates the scientific graph and builds native Word equations with Pandoc.
- `reference_style.docx` is a minimal portable style reference. Its inherited typography comes from the related counterfactual-branches paper; it contains none of that paper's body text.
- `flow_graph.png` and `flow_graph.svg` are the generated five-event graph.
- `audit_paper.py` and `qa_report.json` document structural OOXML and rendered-text checks. They are not a full OOXML XSD validation.
- `requirements.txt` lists the artifact dependencies. The mathematical checker uses only Python's standard library.
- `source_notes.md` records the primary-source basis and the limits of the experimental claims.
- `SHA256SUMS.txt` lists the packaged files' hashes.

## Reproduce the arithmetic

From this directory with Python 3.12 or a compatible Python 3 version:

```bash
python check_distillation.py results_fresh.json
```

Compare the bytes of `results_fresh.json` with `results.json`. All calculations use exact integers or `fractions.Fraction`. The response-law grid, Fréchet endpoints, pairwise and triple-world examples, conditioning bound and five-event world laws are finite mathematical checks. Independent factorization of conditional counts crosschecks every five-event intervention law. This is not an independent second implementation of every theorem, and no C# compilation is claimed.

## Rebuild the paper

Install the listed Python packages and Pandoc, then run:

```bash
python build_paper.py
```

The builder expects `results.json`, `manuscript.template.md` and `reference_style.docx` beside it. It creates `Causal_Flow_Distillation_in_ADC.docx`, `paper.md` and the figure. Word equations are native OMML. Render and inspect the rebuilt document with Word or LibreOffice; font and renderer versions can change pagination. The delivered version was rendered and every page reviewed.

The optional structural audit requires a locally rendered PDF as its positional argument:

```bash
python audit_paper.py path/to/Causal_Flow_Distillation_in_ADC.pdf
```

The audit also expects `results_rerun.json` beside the source files. The final PDF and page images are layout-review intermediates and are not part of this source bundle.

## Scientific status

The proofs apply to their declared finite semantic classes. The 27 checks illustrate those claims and detect arithmetic mistakes; they do not establish neural generalization, brain mechanisms or a wall-clock advantage. The student in the five-event example is a compiled semantic table, not a trained language model. The paper's H-series and N-series are prospective tests.
