"""Structural OOXML and rendered-text checks; not a full OOXML XSD validator."""
from pathlib import Path
from zipfile import ZipFile
from lxml import etree
import json,re,hashlib,importlib.metadata,platform,sys
import fitz
ROOT=Path(__file__).resolve().parent
pdfpath=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'render_release/Causal_Flow_Distillation_in_ADC.pdf'
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
docx=ROOT/'Causal_Flow_Distillation_in_ADC.docx'
checks=[]
def check(n,v):
    if not v:raise AssertionError(n)
    checks.append({'name':n,'status':'pass'})
with ZipFile(docx) as z:
    check('ZIP CRC',z.testzip() is None)
    for n in z.namelist():
        if n.endswith('.xml') or n.endswith('.rels'):etree.fromstring(z.read(n))
    check('all XML well formed',True)
    root=etree.fromstring(z.read('word/document.xml'))
    plain=''.join(root.xpath('.//w:t/text()',namespaces=ns))
    check('no template placeholders','@@' not in plain)
    check('no raw dollar delimiters','$' not in plain)
    check('no tool citation markers',not any(x in plain for x in ('genui','turn171','codex-file-citation')))
    math=root.findall('.//m:oMath',ns)
    check('native equations retained',len(math)>=240)
    check('twelve displayed equations',len(root.findall('.//m:oMathPara',ns))==12)
    runs=root.findall('.//m:r',ns)
    check('math run property order',all(r.find('m:rPr',ns) is None or r[0].tag=='{'+ns['m']+'}rPr' for r in runs))
    tables=root.findall('.//w:tbl',ns)
    check('four real data tables',len(tables)==4)
    check('all table headers repeat',all(t.find('w:tr/w:trPr/w:tblHeader',ns) is not None for t in tables))
    check('table rows do not split',all(r.find('w:trPr/w:cantSplit',ns) is not None for t in tables for r in t.findall('w:tr',ns)))
    for t in tables:
        for r in t.findall('w:tr',ns):
            for cell in r.findall('w:tc',ns):check('nonempty table cell',bool(''.join(cell.itertext()).strip()))
    check('image alternative text',all(x.get('descr') for x in root.findall('.//{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}docPr')))
    check('one scientific figure',len(root.findall('.//w:drawing',ns))==1)
    sty=etree.fromstring(z.read('word/styles.xml'))
    for st in sty.findall('w:style',ns):
        if st.get('{'+ns['w']+'}styleId') in ('Title','Subtitle','Heading1','Heading2','Heading3'):
            color=st.find('w:rPr/w:color',ns)
            check('black heading style '+st.get('{'+ns['w']+'}styleId'),color is not None and color.get('{'+ns['w']+'}val')=='000000')
    # Every display number occurs exactly once within a native equation text run.
    labels=[x for x in root.xpath('.//m:oMathPara//m:t/text()',namespaces=ns) if re.fullmatch(r'\s*\(\d+\)',x)]
    check('display numbering complete',[int(re.search(r'\d+',x).group()) for x in labels]==list(range(1,13)))
pdf=fitz.open(pdfpath)
alltext=' '.join(('\n'.join(p.get_text() for p in pdf)).split())
check('render has sustained paper length',18<=len(pdf)<=26)
check('all numerical checks reported','27' in alltext and '6,209' in alltext and '248,832' in alltext)
check('all major sections rendered',all(f'{i} ' in alltext for i in range(1,15)))
check('references rendered','Hippocampal output suppresses' in alltext and 'Consistent families of measures' in alltext)
check('result file exactly reproduced',(ROOT/'results.json').read_bytes()==(ROOT/'results_rerun.json').read_bytes())
issues=[]
for i,p in enumerate(pdf):
    for block in p.get_text('dict')['blocks']:
        if block['type']!=0:continue
        for line in block['lines']:
            for span in line['spans']:
                x0,y0,x1,y1=span['bbox']
                if x0<65 or x1>548 or y0<35 or y1>780:issues.append({'page':i+1,'text':span['text'],'bbox':span['bbox']})
check('rendered text remains inside printable bounds',not issues)
result={'status':'pass','structural_checks':len(checks),'pages':len(pdf),'native_equations':len(math),'checks':checks,'full_XSD_validation':False,'python':platform.python_version(),'packages':{x:importlib.metadata.version(x) for x in ('python-docx','lxml','matplotlib','PyMuPDF')},'docx_sha256':hashlib.sha256(docx.read_bytes()).hexdigest(),'results_sha256':hashlib.sha256((ROOT/'results.json').read_bytes()).hexdigest()}
(ROOT/'qa_report.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
