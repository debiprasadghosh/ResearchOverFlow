"""Build the native-equation Word paper from checked results and a portable template."""
from pathlib import Path
import json, re, subprocess, shutil
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
DATA=json.loads((ROOT/'results.json').read_text())
LOOK={x['name']:x for x in DATA['checks']}
VAL={
'CHECKCOUNT':DATA['checks_passed'],
'WORLDS':LOOK['all five event intervention laws agree']['interventions'],
'BACKGROUNDS':f"{LOOK['all five event intervention laws agree']['background_states']:,}",
'ASSIGNMENTS':f"{LOOK['compiled student preserves shared background profile']['matched_world_assignments']:,}",
'LAWS':LOOK['response census counts']['laws'],
'PROFILES':LOOK['response census counts']['L2_profiles'],
'AMBIGUOUS':LOOK['response census counts']['ambiguous_profiles'],
'DIRECT':LOOK['five event counterfactual separates L2 student']['direct'],
'COMPILED':LOOK['five event counterfactual separates L2 student']['compiled'],
'SHIFTED':LOOK['five event counterfactual separates L2 student']['shifted'],
'TVPAIRS':LOOK['total variation conditional bound']['law_pairs'],
'TVLAWS':LOOK['total variation conditional bound']['laws'],
'TVEVENTS':f"{LOOK['total variation conditional bound']['positive_support_events']:,}",
}
text=(ROOT/'manuscript.template.md').read_text()
for k,v in VAL.items(): text=text.replace('@@'+k+'@@',str(v))
assert '@@' not in text
# Display tags use a native math text run, compatible with Word and LibreOffice.
text=re.sub(r'\\tag\{(\d+)\}',lambda m:r'\qquad\text{('+m.group(1)+')}',text)
(ROOT/'paper.md').write_text(text)

plt.rcParams.update({'font.family':'DejaVu Serif','font.size':13})
fig,ax=plt.subplots(figsize=(4.6,2.35))
pos={'X':(0,1),'A':(1.25,1.55),'B':(1.25,.45),'C':(2.5,1),'Y':(3.75,1)}
edges=[('X','A'),('X','B'),('A','C'),('B','C'),('C','Y')]
for a,b in edges:
    ax.annotate('',xy=pos[b],xytext=pos[a],arrowprops=dict(arrowstyle='->',lw=1.4,color='black',shrinkA=17,shrinkB=17))
for k,(x,y) in pos.items():
    ax.text(x,y,k,ha='center',va='center',bbox=dict(boxstyle='circle,pad=.40',fc='white',ec='black',lw=1.2),fontsize=14)
ax.set(xlim=(-.45,4.2),ylim=(.0,2));ax.axis('off');fig.tight_layout(pad=.1)
fig.savefig(ROOT/'flow_graph.png',dpi=220,bbox_inches='tight',pad_inches=.05)
fig.savefig(ROOT/'flow_graph.svg',bbox_inches='tight',pad_inches=.05)
plt.close(fig)

ref=ROOT/'reference_style.docx'
assert ref.exists(), 'The included style reference is required'
output=ROOT/'Causal_Flow_Distillation_in_ADC.docx'
subprocess.run(['pandoc',str(ROOT/'paper.md'),'--from=markdown+tex_math_dollars-implicit_figures','--to=docx','--standalone','--reference-doc='+str(ref),'--resource-path='+str(ROOT),'-o',str(output)],check=True)
d=Document(output)
for s in d.sections:
    s.page_width=Inches(8.5);s.page_height=Inches(11)
    s.left_margin=s.right_margin=Inches(1)
    s.top_margin=s.bottom_margin=Inches(.8)
    s.header_distance=Inches(.3);s.footer_distance=Inches(.3)
for sn in ('Normal','Body Text','First Paragraph','Compact','Title','Subtitle','Author','Date','Heading 1','Heading 2','Heading 3','Caption'):
    if sn not in d.styles:
        newstyle=d.styles.add_style(sn,WD_STYLE_TYPE.PARAGRAPH)
        newstyle.base_style=d.styles['Normal']
    st=d.styles[sn];st.font.name='Times New Roman';st.font.color.rgb=RGBColor(0,0,0)
    for tag in ('w:color',):
        for el in list(st.element.iter(qn(tag))):
            for attr in ('w:themeColor','w:themeTint','w:themeShade'):
                el.attrib.pop(qn(attr),None)
    if sn in ('Normal','Body Text','First Paragraph','Compact'):
        st.font.size=Pt(11.5);st.paragraph_format.line_spacing=1.08
        st.paragraph_format.space_after=Pt(6);st.paragraph_format.space_before=Pt(0)
        st.paragraph_format.widow_control=True
    elif sn.startswith('Heading'):
        st.font.size=Pt(14 if sn=='Heading 1' else 12)
        st.font.bold=True;st.paragraph_format.space_before=Pt(12)
        st.paragraph_format.space_after=Pt(6);st.paragraph_format.keep_with_next=True
    elif sn=='Title':
        st.font.size=Pt(21);st.font.bold=True;st.paragraph_format.space_after=Pt(8)
    elif sn=='Subtitle': st.font.size=Pt(12);st.paragraph_format.space_after=Pt(10)
    elif sn in ('Author','Date'): st.font.size=Pt(11.5);st.paragraph_format.space_after=Pt(5)
    elif sn=='Caption': st.font.size=Pt(10);st.paragraph_format.space_after=Pt(8)
for p in d.paragraphs:
    if p.style.name=='Title':
        p.text='Causal Flow Distillation\nin Autoregressive Do Calculus'
    if p.style.name in ('Title','Subtitle','Author','Date') or p.text in ('Debi Prasad Ghosh','1 November 2026'):
        p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    elif p.text.startswith('Founder and Principal'):
        p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        for r in p.runs:r.font.size=Pt(10.5)
        p.paragraph_format.space_after=Pt(15)
    elif p.style.name.startswith('Heading'): p.alignment=WD_ALIGN_PARAGRAPH.LEFT
    else:p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
    if p.text=='1 Introduction':p.paragraph_format.page_break_before=True
    if re.match(r'^(Table \d+ (Semantic strengths|Responsibilities|Exact counterfactual|Scope of)|Figure \d+ The five event)',p.text):
        p.style='Caption';p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        if p.text.startswith('Table '):
            prev=p._p.getprevious()
            if prev is not None and prev.tag==qn('w:tbl'):
                prev.addprevious(p._p)
                p.paragraph_format.keep_with_next=True
    if p.text.startswith(('Definition ','Principle ','Theorem ','Lemma ','Corollary ','Proposition ','Observation ','Example ','Algorithm ','H1 ','H2 ','H3 ','H4 ','H5 ','H6 ','N1 ','N2 ','N3 ')):
        p.paragraph_format.keep_together=True
    if p.text.startswith('Proof.') and len(p.text.split())<130:
        p.paragraph_format.keep_together=True
    # Math objects are native OMML and use Cambria Math, preserving editable notation.
    for omath in p._p.iter(qn('m:oMath')):
        for run in omath.iter(qn('m:r')):
            wrpr=run.find(qn('w:rPr'))
            if wrpr is None:
                wrpr=OxmlElement('w:rPr');run.insert(1 if run.find(qn('m:rPr')) is not None else 0,wrpr)
            mrpr=run.find(qn('m:rPr'))
            if mrpr is not None and run[0] is not mrpr:
                run.remove(mrpr);run.insert(0,mrpr)
            fonts=wrpr.find(qn('w:rFonts'))
            if fonts is None:fonts=OxmlElement('w:rFonts');wrpr.insert(0,fonts)
            fonts.set(qn('w:ascii'),'Cambria Math');fonts.set(qn('w:hAnsi'),'Cambria Math')
    # Keep the equation number apart from the formula in renderers that drop TeX spacing.
    if p._p.find(qn('m:oMathPara')) is not None:
        for mt in p._p.iter(qn('m:t')):
            if re.fullmatch(r'\(\d+\)',mt.text or ''):
                mt.text='\u00a0\u00a0\u00a0\u00a0'+mt.text
                mt.set(qn('xml:space'),'preserve')
    # Strip incidental paragraph borders inherited from any template title.
    ppr=p._p.pPr
    if ppr is not None:
        for el in list(ppr):
            if el.tag in (qn('w:pBdr'),qn('w:shd')):ppr.remove(el)

widths=[[1.15,2.65,2.70],[1.27,2.55,2.68],[2.20,1.80,2.50],[1.65,2.45,2.40]]
for ti,table in enumerate(d.tables):
    table.alignment=WD_TABLE_ALIGNMENT.CENTER;table.autofit=False
    tblpr=table._tbl.tblPr
    for tag in ('w:tblBorders','w:tblCellMar','w:tblStyle'):
        el=tblpr.find(qn(tag))
        if el is not None:tblpr.remove(el)
    borders=OxmlElement('w:tblBorders')
    for edge in ('top','left','bottom','right','insideH','insideV'):
        e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
    tblpr.append(borders)
    mar=OxmlElement('w:tblCellMar')
    for edge,val in (('top',95),('left',110),('bottom',95),('right',110)):
        e=OxmlElement('w:'+edge);e.set(qn('w:w'),str(val));e.set(qn('w:type'),'dxa');mar.append(e)
    tblpr.append(mar)
    for ri,row in enumerate(table.rows):
        trpr=row._tr.get_or_add_trPr()
        if trpr.find(qn('w:cantSplit')) is None:trpr.append(OxmlElement('w:cantSplit'))
        for ht in list(trpr.findall(qn('w:trHeight'))):trpr.remove(ht)
        if ri==0:
            hdr=OxmlElement('w:tblHeader');trpr.append(hdr)
        for ci,cell in enumerate(row.cells):
            cell.width=Inches(widths[ti][ci]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcpr=cell._tc.get_or_add_tcPr()
            for s in list(tcpr.findall(qn('w:shd'))):tcpr.remove(s)
            shd=OxmlElement('w:shd');shd.set(qn('w:fill'),'263746' if ri==0 else ('F3F5F7' if ri%2==0 else 'FFFFFF'));tcpr.append(shd)
            for p in cell.paragraphs:
                p.style='Body Text';p.alignment=WD_ALIGN_PARAGRAPH.CENTER if (ti==2 and ci>0) else WD_ALIGN_PARAGRAPH.LEFT
                p.paragraph_format.space_before=Pt(0);p.paragraph_format.space_after=Pt(3);p.paragraph_format.line_spacing=1.02
                for r in p.runs:
                    r.font.name='Times New Roman';r.font.size=Pt(10.5);r.font.bold=(ri==0)
                    r.font.color.rgb=RGBColor(255,255,255) if ri==0 else RGBColor(0,0,0)
                for mr in p._p.iter(qn('m:r')):
                    wrpr=mr.find(qn('w:rPr'))
                    if wrpr is None:
                        wrpr=OxmlElement('w:rPr');mr.insert(1 if mr.find(qn('m:rPr')) is not None else 0,wrpr)
                    color=wrpr.find(qn('w:color'))
                    if color is None:color=OxmlElement('w:color');wrpr.append(color)
                    color.set(qn('w:val'),'FFFFFF' if ri==0 else '000000')
    for ci,col in enumerate(table.columns):col.width=Inches(widths[ti][ci])
    # Caption follows the table, so leave natural space without joining the next section.
    for p in table.rows[-1].cells[0].paragraphs:p.paragraph_format.keep_with_next=False

for p in d.paragraphs:
    prev=p._p.getprevious()
    if prev is not None and prev.tag==qn('w:tbl'):
        p.paragraph_format.space_before=Pt(8)

inrefs=False
for p in d.paragraphs:
    if p.text=='References':
        inrefs=True;p.paragraph_format.page_break_before=True;continue
    if inrefs:
        p.alignment=WD_ALIGN_PARAGRAPH.LEFT;p.paragraph_format.left_indent=Inches(.22);p.paragraph_format.first_line_indent=Inches(-.22)
        p.paragraph_format.space_after=Pt(8);p.paragraph_format.line_spacing=1.08
        for r in p.runs:r.font.size=Pt(11.5)
        # Hyperlink runs live below separate XML containers.
        for rpr in p._p.iter(qn('w:rPr')):
            size=rpr.find(qn('w:sz'))
            if size is None:size=OxmlElement('w:sz');rpr.append(size)
            size.set(qn('w:val'),'23')

for sec in d.sections:
    for p in list(sec.header.paragraphs):p.clear()
    footer=sec.footer
    for p in footer.paragraphs:p.clear()
    p=footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    run=p.add_run();fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');run._r.addnext(fld)
    run.font.size=Pt(9)
for shape in d.inline_shapes:
    if shape.width>Inches(4.6):
        scale=Inches(4.6)/shape.width;shape.width=Inches(4.6);shape.height=int(shape.height*scale)
    shape._inline.docPr.set('descr','Five event graph with edges X to A and B, A and B to C, and C to Y')
    parent=shape._inline.getparent()
    while parent is not None and parent.tag!=qn('w:p'):parent=parent.getparent()
    if parent is not None:
        from docx.text.paragraph import Paragraph
        picp=Paragraph(parent,d._body)
        picp.alignment=WD_ALIGN_PARAGRAPH.CENTER
        picp.paragraph_format.keep_with_next=True
d.core_properties.title='Causal Flow Distillation in Autoregressive Do Calculus'
d.core_properties.subject='Implementation independent transfer with coherent counterfactual guarantees'
d.core_properties.author='Debi Prasad Ghosh'
d.core_properties.keywords='ADC, causal flow, distillation, counterfactuals, sheaves, neuroscience'
d.core_properties.comments=''
d.save(output)
print(json.dumps({'output':str(output),'words':len(text.split()),'tables':len(d.tables),'native_math':len(list(d.element.iter(qn('m:oMath')))),'checks':DATA['checks_passed']},indent=2))
