"""Exact finite checks for Causal Flow Distillation in ADC. Python 3.12 stdlib."""
from fractions import Fraction as F
from itertools import product, combinations
from collections import defaultdict, Counter
from pathlib import Path
import json, sys

OUT = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('results.json')
checks=[]
def check(name, condition, **details):
    if not condition: raise AssertionError(name)
    checks.append(dict(name=name,status='pass',**details))
def dot(a,b): return sum((x*y for x,y in zip(a,b)), F(0))
def tv(a,b): return sum((abs(x-y) for x,y in zip(a,b)), F(0))/2
def rank(a):
    a=[list(map(F,r)) for r in a]; r=0
    if not a: return 0
    for j in range(len(a[0])):
        p=next((i for i in range(r,len(a)) if a[i][j]),None)
        if p is None: continue
        a[r],a[p]=a[p],a[r]; s=a[r][j]; a[r]=[x/s for x in a[r]]
        for i in range(len(a)):
            if i!=r:
                s=a[i][j]; a[i]=[x-s*y for x,y in zip(a[i],a[r])]
        r+=1
        if r==len(a): break
    return r
def compositions(n,k):
    if k==1: yield (n,); return
    for j in range(n+1):
        for tail in compositions(n-j,k-1): yield (j,)+tail
def conditional(q,event,target):
    den=sum(q[i] for i in range(len(q)) if event(i))
    return None if not den else sum(q[i] for i in range(len(q)) if event(i) and target(i))/den

# Response order 00 01 10 11, where bits are Y0 and Y1.
atoms=list(product((0,1),repeat=2))
q_same=(F(1,2),F(0),F(0),F(1,2))
q_flip=(F(0),F(1,2),F(1,2),F(0))
p0=[F(a[0]) for a in atoms]; p1=[F(a[1]) for a in atoms]
check('same L2 marginals',dot(p0,q_same)==dot(p0,q_flip)==F(1,2) and dot(p1,q_same)==dot(p1,q_flip)==F(1,2))
cfs=[conditional(q,lambda i:atoms[i][0]==1,lambda i:atoms[i][1]==1) for q in (q_same,q_flip)]
check('different L3 laws',cfs==[F(1),F(0)],values=cfs)
check('minimax point radius',max(abs(F(1,2)-x) for x in cfs)==F(1,2))
grid=list(compositions(12,4)); groups=defaultdict(list)
for z in grid:
    q=tuple(F(x,12) for x in z); groups[(dot(p0,q),dot(p1,q))].append(q)
ambiguous=sum(len(v)>1 for v in groups.values())
check('response census counts',len(grid)==455 and len(groups)==169 and ambiguous==121,atoms=4,laws=len(grid),L2_profiles=len(groups),ambiguous_profiles=ambiguous)
for (a,b),qs in groups.items():
    z=[q[3] for q in qs]
    assert min(z)==max(F(0),a+b-1) and max(z)==min(a,b)
check('all Frechet endpoints on twelfths grid',True,profiles=len(groups))

# Same every one and two world marginal, different three world parity.
bits=list(product((0,1),repeat=3))
even=[F(int(sum(b)%2==0),4) for b in bits]
odd=[F(int(sum(b)%2==1),4) for b in bits]
for subset in combinations(range(3),2):
    for vals in product((0,1),repeat=2):
        assert sum(q for q,b in zip(even,bits) if tuple(b[j] for j in subset)==vals)==F(1,4)
        assert sum(q for q,b in zip(odd,bits) if tuple(b[j] for j in subset)==vals)==F(1,4)
check('all three pairwise world laws agree',True,pair_tables=3)
check('three world law differs',sum(q for q,b in zip(even,bits) if sum(b)%2==0)==1 and sum(q for q,b in zip(odd,bits) if sum(b)%2==0)==0)
check('triangle disagreement obstruction',max(sum(b[i]!=b[j] for i,j in ((0,1),(1,2),(0,2))) for b in bits)==2,reported_sum=3,maximum_possible_sum=2)

# Junction tree construction for AB and BC, positive and zero separators.
pab={(a,b):F((1+a+2*b),12) for a,b in product((0,1),repeat=2)}
# Normalize rather than relying on the arbitrary denominator.
s=sum(pab.values()); pab={k:v/s for k,v in pab.items()}
pb={b:sum(v for (a,j),v in pab.items() if j==b) for b in (0,1)}
pbc={(b,c):pb[b]*F(1+c,3) for b,c in product((0,1),repeat=2)}
joint={(a,b,c):pab[a,b]*pbc[b,c]/pb[b] for a,b,c in bits}
check('junction tree gluing',sum(joint.values())==1 and all(sum(joint[a,b,c] for c in (0,1))==pab[a,b] for a,b in pab) and all(sum(joint[a,b,c] for a in (0,1))==pbc[b,c] for b,c in pbc))
zero={(a,b,c):F(1,4) if b==0 else F(0) for a,b,c in bits}
check('zero separator convention',sum(zero.values())==1 and all(zero[a,1,c]==0 for a,c in product((0,1),repeat=2)))

# Contradictory duplicate teacher report and exact Farkas multiplier.
M=[p0,[-x for x in p0]]; d=[F(2,5),-F(3,5)]; y=[F(1),F(1)]
check('Farkas refutation',all(sum(y[j]*M[j][i] for j in range(2))==0 for i in range(4)) and dot(y,d)==-F(1,5),dual_value=dot(y,d))
check('rounded report boxes have witness',F(49,100)<=dot(p0,q_same)<=F(51,100))
check('zero support conditional rejected',conditional((F(1),F(0),F(0),F(0)),lambda i:atoms[i][0]==1,lambda i:atoms[i][1]==1) is None)

C=[p0,p1,[F(0),F(0),F(0),F(1)]]
check('linear moment rank',rank([[1]*4]+C)-1==3 and rank([[1]*4,p0,p1])-1==2,full_moment_coordinates=3,L2_coordinates=2)
v=[F(1),-F(1),-F(1),F(1)]
check('unobserved L3 direction',sum(v)==dot(p0,v)==dot(p1,v)==0 and dot(C[2],v)==1)
check('adding informative row raises rank',rank([[1]*4,p0,p1,C[2]])==4)
qA=[F(1,4),F(1,4),F(1,2),F(0)]; qB=[F(1,4),F(1,2),F(1,4),F(0)]
check('future ratio needs denominator',qA[0]==qB[0] and qA[0]/(qA[0]+qA[1])==F(1,2) and qB[0]/(qB[0]+qB[1])==F(1,3))

# Conditioning stability over every quarters-grid pair and nonempty subset.
# Four atoms and 455 laws: the complete pair/subset scan is exact.
stability_pairs=0; event_checks=0
small=[tuple(F(x,4) for x in z) for z in compositions(4,4)]
for p,q in combinations(small,2):
    delta=tv(p,q); stability_pairs+=1
    for mask in range(1,16):
        E=[i for i in range(4) if mask>>i&1]
        bp=sum(p[i] for i in E); bq=sum(q[i] for i in E)
        if not bp or not bq: continue
        pc=[p[i]/bp if i in E else F(0) for i in range(4)]
        qc=[q[i]/bq if i in E else F(0) for i in range(4)]
        assert tv(pc,qc)<=min(F(1),delta/max(bp,bq)); event_checks+=1
check('total variation conditional bound',True,laws=len(small),law_pairs=stability_pairs,positive_support_events=event_checks)
p=[F(1,10),F(0),F(9,10)]; q=[F(9,100),F(1,100),F(9,10)]
check('conditioning bound attained',tv(p,q)==F(1,100) and abs(p[0]/sum(p[:2])-q[0]/sum(q[:2]))==F(1,10),response_TV=tv(p,q),evidence_probability=F(1,10),conditional_error=F(1,10))
# Example of the looser moment residual certificate.
nT,bT,nS,bS=F(2,5),F(1,2),F(39,100),F(49,100)
check('moment residual ratio bound',abs(nT/bT-nS/bS)<=((abs(nT-nS)+abs(bT-bS))/bS))
check('no uniform rare event continuity',all((lambda beta:(tv([beta,0,1-beta],[0,beta,1-beta])==beta and abs(F(1)-F(0))==1))(F(1,n)) for n in (10,100,1000)))

# Different implementation of the same flow, including internal interventions.
# High state (A,B), B=A xor U. Low state (A,U, B xor 1), tau flips the code.
commute=0
for u,a in product((0,1),repeat=2):
    high=(a,a^u); low=(a,u,(a^u)^1)
    assert (low[0],low[2]^1)==high; commute+=1
check('semantic abstraction commutes',True,cases=commute)
def bypass(a,u,internal_B=None,external_B=None):
    hidden_B=(a^u) if internal_B is None else internal_B
    reported_B=(a^u) if external_B is None else external_B  # interface uses its own correct semantic interpreter
    return hidden_B,reported_B
assert all(bypass(a,u)[1]==(a^u) for a,u in product((0,1),repeat=2))
assert all(bypass(a,u,external_B=b)[1]==b for a,u,b in product((0,1),repeat=3))
check('lookup bypass fails internal claim',bypass(0,0,internal_B=1)[0]==1 and bypass(0,0,internal_B=1)[1]==0)
check('constraint refinement preserves outer range',min(cfs)==0 and max(cfs)==1 and min([F(1)])>=min(cfs) and max([F(1)])<=max(cfs))

# A five event diamond chain. Backgrounds are five independent uniforms on 0..3.
# T: shared threshold per parent configuration. S2: cyclically shifted thresholds.
# Compiled T table is an implementation different from direct parent arithmetic.
parents=[(),(0,),(0,),(1,2),(3,)]
thresholds=[(2,),(1,3),(1,3),(1,2,3,2),(1,3)]
backgrounds=list(product(range(4),repeat=5))
worlds=list(product((None,0,1),repeat=5))
compiled=[[[int(u<thresholds[i][j]) for u in range(4)] for j in range(len(thresholds[i]))] for i in range(5)]
def evaluate(u,action,kind):
    out=[]
    for i,pa in enumerate(parents):
        if action[i] is not None: out.append(action[i]); continue
        idx=0
        for j in pa: idx=idx*2+out[j]
        if kind=='compiled': val=compiled[i][idx][u[i]]
        else:
            noise=(u[i]+(2*(idx.bit_count()%2) if kind=='shifted' else 0))%4
            val=int(noise<thresholds[i][idx])
        out.append(val)
    return tuple(out)
for action in worlds:
    direct=Counter(evaluate(u,action,'direct') for u in backgrounds)
    compiled_law=Counter(evaluate(u,action,'compiled') for u in backgrounds)
    shifted=Counter(evaluate(u,action,'shifted') for u in backgrounds)
    assert direct==compiled_law==shifted
    assert all(evaluate(u,action,'direct')==evaluate(u,action,'compiled') for u in backgrounds)
    # Independent one-world factorization uses conditional counts, not backgrounds.
    factorized={}
    for state in product((0,1),repeat=5):
        if any(a is not None and state[i]!=a for i,a in enumerate(action)): continue
        count=1
        for i,pa in enumerate(parents):
            if action[i] is not None: count*=4; continue
            idx=0
            for j in pa: idx=idx*2+state[j]
            t=thresholds[i][idx]
            count*=t if state[i] else 4-t
        factorized[state]=count
    assert dict(direct)==factorized
check('all five event intervention laws agree',True,events=5,background_states=len(backgrounds),interventions=len(worlds),world_evaluations_per_model=len(worlds)*len(backgrounds))
check('compiled student preserves shared background profile',True,matched_world_assignments=len(worlds)*len(backgrounds),independent_factorizations=len(worlds))
factual=(None,)*5; alternative=(1,None,None,None,None)
cf={}
for kind in ('direct','compiled','shifted'):
    den=num=0
    for u in backgrounds:
        f=evaluate(u,factual,kind); w=evaluate(u,alternative,kind)
        if f[0]==0 and f[4]==0:
            den+=1; num+=int(w[4]==1)
    cf[kind]=F(num,den)
check('five event counterfactual separates L2 student',cf['direct']==cf['compiled'] and cf['direct']!=cf['shifted'],**cf)

def encode(x):
    if isinstance(x,F): return str(x)
    raise TypeError(type(x).__name__)
result={'status':'pass','arithmetic':'fractions.Fraction and exact integer enumeration','checks_passed':len(checks),'checks':checks}
OUT.write_text(json.dumps(result,default=encode,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,default=encode,indent=2,sort_keys=True))
