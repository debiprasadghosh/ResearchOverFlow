# Source and claim notes

The related manuscript consulted was *Certified Counterfactual Branches in Autoregressive Do Calculus*, Version 2, 1 November 2026, current author-provided file. The user supplied its DOI, 10.13140/RG.2.2.19065.22885. Its earlier census was not rerun or imported as a new experiment here. The related task-observability manuscript was read for its distinction between value agreement and realized causal execution.

Primary sources checked for the present paper include the official PMLR records for Rubenstein et al. (2017), Geiger et al. (2022) and Chatzi et al. (2025); the author PDF of Beckers and Halpern (2019); official NeurIPS records for Geiger et al. (2021), Deng and Zhang (2021) and Hamman et al. (2025); the JMLR record for Shpitser and Pearl (2008); and the author version of Bareinboim et al.'s hierarchy chapter. Hinton et al. (2015) was checked through the Google Research publication record. These precedents prevent attributing causal abstraction, causal distillation or the hierarchy separation to this paper as new general ideas.

Vorob'ev's primary SIAM record confirms the 1962 marginal-extension paper, pages 147–163 and DOI 10.1137/1107014. The junction-tree construction in this paper is proved explicitly and does not claim a novel probability-extension theorem.

The neuroscience discussion uses the author PDF and publisher record for Mızrak et al. (2021), the author laboratory record for Driscoll et al. (2017), and the primary Nature Neuroscience/PubMed records for Zong et al. (2025). The Zong result constrains a simple serial hippocampus-to-cortex teacher analogy: ventral-subiculum inactivation had different effects after learning and during transfer. No cited experiment establishes neural interval certificates, literal response-type storage or immutable cortical logs.

Agent Lightning and SWE-agent were checked through their primary arXiv records. Their modular training or interface findings do not certify the ADC harness proposed here.

The response-grid counts, conditional stability checks and five-event comparison were generated for this paper. Result values are inserted by the builder directly from the JSON. The proofs are finite probability, linear algebra, marginal extension and abstraction arguments integrated with the ADC interface. A complete exact optimization engine and a learned scheduler are proposed components, not claimed implemented results.
