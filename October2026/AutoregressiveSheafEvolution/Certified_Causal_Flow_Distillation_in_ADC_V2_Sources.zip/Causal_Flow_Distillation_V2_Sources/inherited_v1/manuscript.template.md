---
title: Causal Flow Distillation in Autoregressive Do Calculus
subtitle: Implementation independent transfer with coherent counterfactual guarantees
author: Debi Prasad Ghosh
date: 1 November 2026
---

Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India

## Abstract

Distillation of Autoregressive Do Calculus (ADC) should preserve a declared causal flow while allowing the student to choose its own implementation. We define that flow by the joint law of semantic outcomes under specified interventions for the same background circumstances. A finite response model represents this law without referring to the teacher’s architecture, weights or reasoning trace. The target is an equivalence class for a query family, rather than a uniquely recoverable graph and response distribution. We distinguish a certified flow clone, a student compatible with one possible teacher flow and a student retaining uncertainty over several flows. Exact observational and interventional agreement does not generally transfer counterfactuals. Moreover, even every two-world law can agree while a three-world law differs. Teacher transcripts and student answers therefore require a common global extension; separate interval membership is insufficient. We give finite feasibility and refutation certificates, a junction-tree gluing result, a linear moment compression criterion, a continuation quotient and a sharp total-variation bound for conditioning. A student claiming internal causal execution must separately exhibit intervention commutation through its own abstraction map. @@CHECKCOUNT@@ exact checks include a five-event example with @@WORLDS@@ intervention regimes and a response-law census with @@LAWS@@ laws. A student matching all those intervention laws nevertheless returns @@SHIFTED@@ where the teacher’s same-case counterfactual is @@DIRECT@@. Neuroscience findings motivate functional hypotheses about structure transfer and changing neural codes; they do not establish cortical execution of ADC. A proposed harness separates teacher proposals, coherent targets, student training and certified answers. Neural distillation, biological mappings and runtime gains remain prospective.

**Keywords** causal abstraction; knowledge distillation; response types; counterfactuals; partial identification; sheaves; sufficient memory; neuroscience; AI harness

# 1 Introduction

The object to transfer is a causal model’s flow at a declared level of description. The student may use a different architecture, different latent coordinates and a different sequence of numerical operations. What matters is whether the same semantic observations, interventions and counterfactual questions receive the answers warranted by that flow. This target is narrower than cloning the teacher as a physical or computational system and stronger than imitating a collection of final numbers.

Consider a teacher that models a machine through five events: a switch, two intermediate responses, a combined state and an outcome. Its implementation could be a structural-equation interpreter. A student could instead use a compiled response table. If both attach the same joint law to all declared alternative outcomes for one case, their causal flows agree even though their implementations differ. A second student could match every intervention experiment and still connect the alternative outcomes differently. That student has preserved less information. The distinction concerns the coupling of worlds, not the length or fluency of a generated explanation.

ADC separates factual evidence, mechanism replacement and prediction for the same case (Ghosh, 2026b). Certified counterfactual branches require a shared background model and an explicit scope for their certificates (Ghosh, 2026a). Distillation adds a transfer question: which part of that model must a student retain, and what evidence justifies saying that it has retained it? We answer in a finite, declared semantic model. The results are conditional on the meanings and model class being correct.

## Literature survey

Knowledge distillation transfers predictive behavior from a teacher or ensemble to another model without requiring identical parameters (Hinton et al., 2015). Causal and counterfactual distillation already have substantial precedents. Deng and Zhang (2021) use causal intervention to improve representation transfer and reduce contextual bias. Hamman et al. (2025) use counterfactual explanations near prediction boundaries for few-shot distillation. A prediction-flipping input perturbation is not automatically a same-case counterfactual in a structural causal model. The present contract concerns a declared family of structural interventions and joint alternative-world laws; it does not claim to introduce causal knowledge distillation as a general idea.

Causal abstraction supplies the relevant implementation-independent language. Rubenstein et al. (2017) formalize transformations preserving interventional predictions. Beckers and Halpern (2019) distinguish stronger abstraction requirements that prevent a chosen distribution from hiding structural differences. Geiger et al. (2021) test alignments through interchange interventions; Geiger et al. (2022) train such alignments. Our internal-execution criterion is a scoped specialization of this programme. It requires a student-to-semantic map and does not require alignment with the teacher’s hidden units.

The causal hierarchy separates observations, interventions and multiworld counterfactuals (Shpitser & Pearl, 2008; Bareinboim et al., 2022). Response-function representations and probabilities-of-causation bounds are established tools (Balke & Pearl, 1997; Tian & Pearl, 2000). Marginal extension is a classical problem: consistent local probability tables need not admit a global law (Vorob’ev, 1962). These facts constrain what lower-level teacher data can transfer. Counterfactual token generation also has an explicit structural model (Chatzi et al., 2025); it concerns the generator’s declared noise coupling and need not identify the world described by its text.

## Contribution and status

We define a flow contract, three transfer statuses and a certificate boundary for ADC distillation. The main mathematical contributions here are their integration: a global extension test for teacher and student claims; an explicit two-world limitation; query-dependent compression and adaptive probe criteria; conditional error control; and a separation of behavioral flow transfer from internal realization. The proofs use standard finite probability, linear algebra, linear programming and causal abstraction. They are not a new general identification algorithm or a claim that arbitrary causal models reduce to linear programmes.

The accompanying checks are exact finite examples. They train no language model, query no frontier model and measure no end-to-end latency. The earlier counterfactual-branches census is background evidence reported in its own paper, not a newly generated result here. Neuroscience interpretations and proposed training gains are labelled hypotheses. Distillation fidelity also does not establish that the teacher’s causal assumptions describe reality.

## Structure

Section 2 fixes the semantic contract. Sections 3 and 4 distinguish flow equivalence, hierarchy levels and coherent targets. Section 5 explains horizontal compatibility and global probability extension. Section 6 develops compression and probe selection. Sections 7 and 8 treat approximation and internal execution. Sections 9 and 10 specify training and the harness. Section 11 reports exact checks. Sections 12 and 13 develop neuroscience interpretations and falsifiable tests. Section 14 states limitations and the resulting research programme.

# 2 The semantic contract

**Definition 2.1 (declared model).** Let $V=(V_1,\ldots,V_n)$ have finite value sets, let $G$ be an acyclic graph, and let $\mathcal I$ be a specified family of perfect interventions, including the empty intervention. A response atom $r\in\Omega$ assigns one deterministic function $r_i$ to each node. For background atom $r$, evaluation follows

$$V_i=r_i(V_{\mathrm{pa}(i)}),\qquad V^I=F_I(r). \tag{1}$$

An intervention replaces the assignments of its target nodes with the specified constants. The law $q\in\Delta(\Omega)$ links all worlds through the same $r$. Variable meanings, units, mechanism versions and intervention meanings belong to the contract. A response atom is a semantic table of possible responses, not a record of the teacher’s machine instructions.

The unrestricted simplex over global response atoms permits dependence among node response functions. If the model requires independent exogenous blocks, it must impose that requirement. Independence generally gives nonlinear constraints on $q$. The polyhedral results below apply only to the declared linear response class, or to an explicitly labelled outer relaxation. A DAG used as an order for evaluation does not by itself certify the absence of latent confounding.

**Definition 2.2 (world profile and flow).** For a finite world family $W\subseteq\mathcal I$, define $\Phi_W(r)=(F_I(r))_{I\in W}$. Its flow is the pushforward law

$$\mu_W=(\Phi_W)_\#q. \tag{2}$$

This is one joint law, not a list of unrelated marginal laws. A query family $\mathcal Q$ specifies which functions of these profiles can be requested, which factual events can be conditioned upon and which future evidence updates are allowed. A conditional query is defined only when its factual event has positive probability.

**Definition 2.3 (flow equivalence).** Two declared models are $\mathcal Q$-equivalent if they agree on every defined query in $\mathcal Q$, including its support status. Full flow equivalence on $W$ means equality of $\mu_W$. Distillation of the flow transfers this equivalence class. A more detailed query family can separate models that a coarser family cannot distinguish.

**Principle 2.4 (scope precedes fidelity).** Every claim of exact or approximate transfer states $V$, $\mathcal I$, the world families, the evidence contract and the model class. An intervention outside this interface is outside the claim. The student’s parameter count, attention patterns, cache representation and hidden numerical route are not part of the flow target.

Several indexing domains must remain separate. The causal graph orders semantic dependence. A horizontal cover indexes overlapping descriptions. The response space indexes background circumstances. Token position, physical event time and a network’s layer order are additional indices, not substitutes for any of these. A claim about one order does not automatically apply to the others. In the sheaf terminology, stalks are local data spaces; a token carries a vertical fibre diagram. Neither term should be used for a causal event merely because it appears in a sequence.

# 3 What flow distillation preserves

**Theorem 3.1 (implementation invariance).** Suppose two implementations induce the same law $\mu_W$ on their declared semantic profiles. Then every unconditional profile event and every conditional profile event with positive support has the same probability in both implementations. Consequently any decision rule that depends only on those probabilities gives the same result, provided its tie convention is fixed.

**Proof.** An unconditional event is a subset of the finite profile space and its probability is determined by $\mu_W$. A conditional event is the ratio of the probability of an intersection to the positive probability of the conditioning event. Both terms agree. Applying the same deterministic decision rule preserves its result. No statement about the internal computations is used. $\square$

**Corollary 3.2 (a response law is sufficient).** For a fixed response space and graph, equal $q$ gives equal full flow. Equality of $q$ is not necessary when different atoms induce the same declared profiles. A response-coordinate relabelling that preserves the profile map leaves the flow unchanged.

**Proof.** Equation (2) supplies the sufficient direction. For the second assertion, shifting mass between atoms in the same fibre of $\Phi_W$ leaves its pushforward unchanged. Relabelling is a special case. $\square$

The pair $(G,q)$ is therefore a useful sufficient representation, not a uniquely identifiable or minimal definition of flow. Redundant parents can be added to a mechanism that ignores them. Different latent parametrizations can yield the same profile law. If all response coordinates can be exposed by the permitted interventions, the full profile may determine $q$ on that response space; a restricted interface may leave many invisible directions. Graph copying should only be demanded when the graph itself is a declared structural object to be transferred.

Table 1 compares three transfer contracts. Their difference is the information preserved, not a ranking of architectures.

| Contract | Required semantic object | Information not fixed by that object alone |
|:--|:--|:--|
| L1 observational | The declared observational joint law | Intervention effects and cross-world dependence |
| L2 interventional | The declared law for every allowed single-world intervention | Coupling of responses across worlds |
| L3 counterfactual | Joint world profiles needed by the query family | Finer interventions or larger world families outside that scope |

*Table 1 Semantic strengths of distillation*

Ordinary next-token distillation does not automatically recover the entire observational law of a world model. It matches the teacher’s output distributions on the training interface. Assigning an L1 causal interpretation already requires semantic variables and a justified mapping from text to observations.

**Theorem 3.3 (lower-level indistinguishability).** There exist finite SCMs with identical observational and all perfect-intervention laws but different same-case counterfactuals. No learner using only that common L1 and L2 oracle can guarantee the correct counterfactual point value for both models.

**Proof.** Let $X$ and $U$ be independent fair bits. Model A has $Y=U$; model B has $Y=X\mathbin{\oplus}U$. In either model $Y$ is fair conditional on each $X$; interventions on $X$, on $Y$ or on both give the same laws. Their observational joint laws agree. However,

$$P_A(Y_1=1\mid X=0,Y=1)=1,\qquad P_B(Y_1=1\mid X=0,Y=1)=0. \tag{3}$$

Every oracle transcript, including an adaptively chosen sequence of interventions, is identical in distribution under A and B. A learner cannot always return both distinct values for the same transcript. Randomization does not remove this indistinguishability. $\square$

**Corollary 3.4 (unavoidable point error).** For a scalar query whose attainable values over a nonempty compact model class form $[L,U]$, every constant point estimate has worst-case absolute error at least $(U-L)/2$. The midpoint attains that bound. A certified interval retains the ambiguity instead of claiming point identification.

**Proof.** The larger distance to the two endpoints is at least half their separation, with equality at their midpoint. For the positive-support polyhedral classes below, continuity and connectedness ensure the stated scalar interval. $\square$

**Proposition 3.5 (two worlds do not determine three).** A teacher and student can agree on every two-world law and disagree on a three-world law.

**Proof.** Let an action have three settings and let $(Y_0,Y_1,Y_2)$ be uniform on the four even-parity binary triples for one model and on the four odd-parity triples for another. Every pair is uniform on its four binary values in both models. Yet $P(Y_0\oplus Y_1\oplus Y_2=0)$ is respectively one and zero. These are coherent response distributions for a single mechanism with three parent settings. Adding an independent factual action preserves equality of the corresponding two-world laws. $\square$

Thus “match the twin network” must specify which twin queries are included. It does not certify every possible multiworld question. Even complete two-world behavior can leave higher-order coupling unidentified. This sharpens the world-scope requirement in the counterfactual-branches paper (Ghosh, 2026a).

# 4 A teacher transcript defines a feasible target

**Definition 4.1 (certified teacher class).** In a finite linear response model, let the teacher provide unconditional event bounds and conditional event bounds. Each conditional record includes a support floor $b_j^\top q\ge\beta_j>0$. For $0\le a_j\le b_j\le1$, a report $\ell_j\le P(A_j\mid E_j)\le u_j$ means

$$\ell_j b_j^\top q\le a_j^\top q\le u_j b_j^\top q. \tag{4}$$

Together with the structural constraints and $q\in\Delta(\Omega)$, these inequalities define $K_T$. Exact answers are equal lower and upper bounds. Rounded answers require rounding intervals; sampled answers require a stated simultaneous confidence contract. Those intervals must be set before treating their intersection as an authoritative target.

**Theorem 4.2 (finite transcript coherence).** With the support floors fixed, a finite transcript is compatible with one model in the declared linear class exactly when $K_T$ is nonempty. A feasible $q$ is a common witness. If $K_T=\varnothing$, linear infeasibility admits a checkable refutation certificate. This establishes transcript compatibility or incompatibility within the class; it does not certify the teacher’s unseen future answers or its internal causal implementation.

**Proof.** On positive support, multiplying each conditional inequality by its denominator is reversible. Thus every model satisfying the transcript satisfies (4), and every feasible $q$ supplies all the reports simultaneously. For rational linear constraints, the alternative theorem for linear systems gives a rational infeasibility certificate. For example, write the system as $Mq\le d$, $q\ge0$, $\mathbf1^\top q=1$. Multipliers $y\ge0$ and a free scalar $\nu$ refute feasibility if

$$M^\top y+\nu\mathbf1\ge0,\qquad d^\top y+\nu<0. \tag{5}$$

Any feasible $q$ would make the left scalar expression nonnegative by the first inequality and strictly negative by the constraints, a contradiction. Completeness follows from finite-dimensional linear duality. $\square$

**Lemma 4.3 (positive support without a supplied floor).** For finitely many required conditional events, feasibility with all $b_j^\top q>0$ can be checked by maximizing a common $\zeta\in[0,1]$ subject to the transcript constraints and $b_j^\top q\ge\zeta$. Strict-support feasibility holds exactly when the optimum is positive.

**Proof.** A feasible finite collection of positive event masses has a positive minimum, which is an admissible $\zeta$. Conversely a positive feasible $\zeta$ supplies positive mass for each event. Compactness gives attainment of the maximum. $\square$

The optimum in Lemma 4.3 proves existence of a supported model; it is not a uniform support floor for every compatible model. Such a floor must be assumed or certified by minimizing each event mass over the retained class. A zero optimum in this test does not make a conditional probability equal to zero. It means that no model meeting the other conditions gives all required events positive support. A solver timeout is also distinct from certified infeasibility. The harness must retain these statuses.

**Definition 4.4 (three transfer statuses).** A *certified flow clone* matches a specified teacher flow on $\mathcal Q$, or matches a family $K_T$ on queries identified throughout that family. A *compatible flow student* supplies one common law $q_S\in K_T$; its unidentified predictions are conditional on that selection. An *uncertainty-preserving student* retains $K_T$, or a certified outer family containing it, and returns query enclosures valid for every retained possibility.

If $\mathcal Q$ includes unidentified queries, certified cloning of that entire family requires additional information or assumptions. Choosing one $q_S\in K_T$ does not prove that the teacher’s actual counterfactual coupling has been cloned. Nor does returning the midpoint of each sharp interval supply a coherent joint model. The selected point answers must themselves admit one common law if a model-level claim is made. An uncertainty-preserving student may answer different queries with different extremizing witnesses, because it asserts bounds over a shared family rather than one world-generating law.

**Proposition 4.5 (marginal acceptance is insufficient).** Separate acceptance of each student answer inside its permitted interval does not imply that all answers are compatible with one retained flow.

**Proof.** Three binary responses can each be fair. For each pair, disagreement probability one is individually achievable. If a student reports all three disagreement probabilities as one, then their sum is three. At every binary triple at most two pairs disagree, so every joint law gives a sum at most two. All answers pass their separate ranges, but no common joint law exists. $\square$

**Corollary 4.6 (certificate for a student transcript).** Append all proposed student point answers as constraints to $K_T$. Nonemptiness certifies common compatibility for that transcript; emptiness refutes it. A query answered outside this transcript needs its own guarantee or must be generated from the same checked student law.

This is the central acceptance rule for causal-flow distillation. A small loss averaged across query records can hide a globally impossible set of answers. The checker therefore works on a shared semantic model, rather than treating every output as a separate imitation problem.

# 5 Horizontal compatibility and probability gluing

The horizontal sheaf supplies an interface for overlapping semantic descriptions. It does not supply a cross-world probability coupling for free. Let $J$ index finite response coordinates such as $r_i(p)$, the response of mechanism $i$ at parent setting $p$. For a context $C\subseteq J$, let $\mathcal E(C)$ be the assignments to those coordinates. Restriction is coordinate projection. Compatible assignments glue uniquely on their union. This is the elementary assignment sheaf on the context cover.

Local probability laws form a different object: $p_C$ restricts by marginalization. Agreement on overlaps is necessary for a joint distribution, but Proposition 4.5 shows that it is not sufficient on a cyclic cover. Calling these local laws “a sheaf” does not remove the extension problem. In finite ADC the common-response feasibility problem is the precise global check. A stalk remains a local data space; compatibility of its elements and existence of a joint probability law are separate claims.

**Theorem 5.1 (gluing on a junction tree).** Suppose the contexts form a tree with the running-intersection property: every coordinate occurs in a connected set of contexts. Assume the global response space is the full product of coordinate value sets. If adjacent probability laws have identical separator marginals, they have a global joint extension.

**Proof.** Root the tree and start with its root law. Add a leaf context $D$ whose overlap with the already assembled union is its separator $S$ with its parent. If the current law is $p_A$ and the leaf law is $p_D$, define

$$p_{A\cup D}(x)=p_A(x_A)p_D(x_D)/p_S(x_S)\quad\text{when }p_S(x_S)>0. \tag{6}$$

When the separator mass is zero, set the joint mass to zero. Both relevant marginal masses are then zero. Summing over the newly introduced coordinates recovers $p_A$; summing over the old coordinates outside the separator recovers $p_D$. The resulting law is normalized and nonnegative. The running-intersection property justifies the stated overlap at each leaf addition. Induction finishes the construction. $\square$

The theorem guarantees an extension, not uniqueness of the teacher’s flow. Equation (6) chooses a conditional-independence extension. Even two contexts with a shared separator can admit other couplings of their nonshared variables. If $\Omega$ has additional global support exclusions or nonlinear latent-independence restrictions, the constructed extension must be checked against them. Local gluing alone does not certify those restrictions.

**Observation 5.2 (what distillation stores horizontally).** The student may retain local response tables, their meanings, overlap maps and a global extension certificate. These objects are independent of the teacher’s hidden coordinates. If a student uses another cover, it needs checked restriction or abstraction maps that preserve the semantic sections used by its queries. Equal coordinate labels do not establish equal meaning.

World identity also belongs in the indexing. Within a factual world, two charts describing the same quantity must agree after restriction. Across an intervention, the factual and counterfactual values of that quantity may differ. The cross-world connection is the shared response atom; it is not an equality constraint on the two outcomes. In particular, horizontal gluing must not force an intervention to have no effect.

# 6 Compressing the flow and selecting probes

Let $K$ be a nonempty convex set of response laws and let $T=\operatorname{span}(K-K)$ be its space of possible variation. A finite matrix $C$ contains the moment rows needed by the declared query contract. For a future conditional query, it includes its joint numerator and denominator, rather than just the previously computed ratio. Suppose the stored real coordinates are $z=Lq$.

**Theorem 6.1 (exact linear moment compression).** The coordinates $Lq$ determine $Cq$ for every $q\in K$ exactly when

$$\ker L\cap T\subseteq\ker C. \tag{7}$$

The least number of real linear coordinates for this moment contract is $\operatorname{rank}(C|_T)$. On the full response simplex it is $\operatorname{rank}([\mathbf1^\top;C])-1$.

**Proof.** If two laws in $K$ have equal stored coordinates, their difference belongs to $\ker L\cap T$; (7) makes their required moments equal. Conversely, if a vector $v\in\ker L\cap T$ has $Cv\ne0$, choose a point in the relative interior of $K$. A sufficiently short segment in direction $v$ remains in $K$ and gives indistinguishable memories with distinct required moments. Equivalently, the affine map $Cq$ must factor through $Lq$ on the affine hull of $K$. This requires at least its rank on $T$, and a basis of that image attains the bound. Including the fixed normalization coordinate gives the simplex formula. $\square$

This is a minimum for exact real linear storage of the stated moments. It is not a minimum student parameter count, a bit-complexity bound, or a result for every nonlinear encoder. If only ratios are required, their invariances can reduce the necessary information. Storing enough moments is a sufficient design that also supports later reconditioning within the declared family.

**Example 6.2 (the missing coupling coordinate).** For a binary response pair ordered as $00,01,10,11$, define $p_0=P(Y_0=1)$, $p_1=P(Y_1=1)$ and $c=P(Y_0=1,Y_1=1)$. L2 fixes two coordinates; the full joint law requires three. Its remaining coordinate obeys

$$\max(0,p_0+p_1-1)\le c\le\min(p_0,p_1). \tag{8}$$

Every value in this interval is attained by the law $(1-p_0-p_1+c,\ p_1-c,\ p_0-c,\ c)$. A student that retains only $p_0,p_1$ has deliberately dropped a counterfactual coupling coordinate. More L2 demonstrations cannot restore a direction to which every L2 query is insensitive.

**Theorem 6.3 (probe span and an information barrier).** Let accessible exact linear teacher probes have row span $A$, including normalization. On a convex family with variation space $T$, these probes determine a required linear row $c$ exactly if every $v\in T$ annihilated by $A$ also satisfies $cv=0$. If this fails, two laws agree on every accessible probe and disagree on the task. No adaptive sequence of those probes can distinguish them.

**Proof.** The factorization argument of Theorem 6.1 gives the first statement. For failure, use a relative-interior point and the undetected direction to construct two laws. Every accessible answer agrees. Induction on an adaptive policy’s history shows that its next probe and response history cannot separate the two. $\square$

**Corollary 6.4 (a finite informative curriculum).** If accessible rows span the required moment directions on $T$, a basis of those directions supplies a finite exact curriculum. Each independent added row removes one invisible linear direction relevant to that basis. Redundant rows do not increase this rank. Statistical sample requirements and conditioning of the chosen basis are additional concerns.

Teacher queries should therefore be chosen for what they separate. A very long reasoning trace may contain thousands of paraphrases of the same constraint. A single admissible multiworld measurement may supply a direction none of those traces can identify. Active selection can maximize certified reduction in a task interval per measured cost; this is a scheduling proposal, not an optimality theorem for arbitrary teachers.

## Memory for sequential operations

**Definition 6.5 (continuation equivalence).** In a finite interpreter with a declared set of future operations, two semantic states are equivalent when every allowed future operation sequence produces the same answer and support-status trace from both. Operations include the evidence updates that the contract permits.

**Proposition 6.6 (continuation quotient).** Continuation-equivalent states remain equivalent after any allowed first operation. Their equivalence classes form a sufficient deterministic state for every continuation. Any exact deterministic finite memory that supports all continuations must distinguish inequivalent classes.

**Proof.** A future sequence after the first operation is also a continuation before it, proving stability. The quotient transition and output are consequently well defined. If two inequivalent states shared one deterministic memory state, the distinguishing continuation would force that state to produce two different traces. $\square$

This is the finite-interpreter counterpart of task-sufficient flow compression. It allows a different internal implementation while preserving semantic transitions. A lookup table for current answers alone need not be closed under evidence updates. Expanding the allowed query family can split old classes and require more memory; the earlier compressed state then needs new evidence or a declared loss of scope.

# 7 Approximate flow transfer and rare evidence

Exact equality is a useful contract boundary, but training and measurement usually produce errors. The relevant metric must control the actual queries. Average next-token loss does not by itself certify a worst-case conditional causal error.

**Lemma 7.1 (moment error under conditioning).** Suppose teacher and student have numerator and denominator moments $(n_T,b_T)$ and $(n_S,b_S)$, with $0\le n\le b$, $b_T>0$ and $b_S\ge\beta>0$. If $|n_S-n_T|\le\delta_n$ and $|b_S-b_T|\le\delta_b$, then

$$\left|\frac{n_S}{b_S}-\frac{n_T}{b_T}\right|\le\min\left(1,\frac{\delta_n+\delta_b}{\beta}\right). \tag{9}$$

**Proof.** Put $p_T=n_T/b_T\in[0,1]$. The difference equals $[(n_S-n_T)-p_T(b_S-b_T)]/b_S$. Bound its numerator by $\delta_n+\delta_b$ and use the support floor. Both probabilities lie in $[0,1]$. $\square$

**Theorem 7.2 (sharp conditioning stability from a common flow metric).** Let $P,Q$ be two laws on the same finite profile space and let $\delta=\operatorname{TV}(P,Q)$. For an event $E$ with masses $p=P(E)>0$ and $q=Q(E)>0$,

$$\operatorname{TV}(P(\cdot\mid E),Q(\cdot\mid E))\le\min\left(1,\frac{\delta}{\max(p,q)}\right). \tag{10}$$

Consequently every conditional event probability differs by at most $\min(1,\varepsilon/\beta)$ when $\delta\le\varepsilon$ and both evidence masses are at least $\beta$. The factor $1/\beta$ is attainable.

**Proof.** Assume $p\ge q$. Let $m=\sum_{x\in E}\min(P(x),Q(x))$. The overlap of the two conditional laws is at least $m/p$, because $\min(P(x)/p,Q(x)/q)\ge\min(P(x),Q(x))/p$. Their total variation is at most $(p-m)/p$. The total overlap outside $E$ is at most $1-p$, so $\delta\ge p-m$. This proves (10); exchange the laws for the other order. For sharpness, place masses $\beta,0,1-\beta$ on three atoms for $P$, and $\beta-\varepsilon,\varepsilon,1-\beta$ for $Q$, where $0\le\varepsilon\le\beta$. Condition on the first two atoms. The unconditional distance is $\varepsilon$ and the conditional event error is $\varepsilon/\beta$. $\square$

**Corollary 7.3 (no uniform rare-event guarantee).** Without a positive evidence floor, arbitrarily small flow error can coexist with conditional error one.

**Proof.** Use $P=(\beta,0,1-\beta)$ and $Q=(0,\beta,1-\beta)$ and let $\beta$ approach zero. Their total variation is $\beta$, while conditioning on the first two atoms gives disjoint point masses. $\square$

A total-variation bound on response laws implies the same or a smaller bound on their deterministic semantic pushforwards. A bound on L2 marginals alone does not imply this multiworld premise. The example in Theorem 3.3 has zero L2 error and counterfactual error one. A harness should therefore record which metric was certified and avoid substituting a training average for a joint-flow guarantee.

**Proposition 7.4 (approximate commuting realization).** Suppose a coupling of the teacher’s and student’s background variables makes their declared joint world profiles disagree with probability at most $\eta$. Then the profile laws have total variation at most $\eta$. Conditional query error is bounded by (10) with $\delta\le\eta$. If each of finitely many worlds fails with probability at most $\eta_I$, the sum $\sum_I\eta_I$ is a sufficient joint disagreement bound.

**Proof.** Under a coupling, any event can differ only when the coupled profiles differ. This bounds total variation. Apply Theorem 7.2. The union bound supplies the last assertion. $\square$

This proposition permits approximate internal testing to support a scoped probability guarantee when its premises are established. A finite probe set alone does not establish the required failure probability for all worlds. Exhaustive finite validation, a verified invariant, or a statistical sampling contract is still needed.

# 8 Behavioral transfer and internal causal execution

An externally certified flow interface is already a valid implementation-independent target. It need not explain which student neuron represents a mechanism. A stronger statement that the student internally executes the semantic flow needs its own evidence. Requiring that evidence does not require cloning the teacher’s implementation: the student supplies its own map.

**Definition 8.1 (student realization).** Let $F^S_J(u)$ evaluate the student under a declared internal intervention $J$. Let $H$ be the semantic model, with evaluations $F^H_I(v)$. A realization supplies a background map $\eta$, a state abstraction $\tau$ and an intervention map $\omega$ on an explicitly declared domain. They must satisfy

$$\tau(F^S_J(u))=F^H_{\omega(J)}(\eta(u)) \tag{11}$$

for every allowed background and intervention, with $\eta_\#P_U=P^H_{\mathrm{bg}}$. The empty intervention is included. Factual evidence and requested outcomes must be pullbacks under the same abstraction.

**Theorem 8.2 (commutation transfers conditional flow).** Under (11), the background-law condition and positive factual support, the student and semantic model agree on all declared conditional multiworld events.

**Proof.** Evaluate all required interventions at the same student background $u$. Pointwise commutation makes the resulting abstract profile equal to the semantic profile at $\eta(u)$. Pushing forward the background law gives equality of joint profile laws. Pullback evidence makes their conditioning events identical in meaning and probability. Theorem 3.1 supplies conditional equality. $\square$

Only one student-to-semantic square is required; it may have no direct relationship to the teacher’s hidden coordinates. Changing student coordinates by a bijection simply changes $\tau$ by composition with its inverse. Thus internal realization can be certified without demanding a copy of the teacher’s architecture or algorithm.

**Proposition 8.3 (behavior does not prove a proposed internal alignment).** A system can answer every external flow query correctly while failing an advertised internal intervention map.

**Proof.** Let a system compute $B=A\oplus U$ both in a nominal internal register and independently in its readout. The readout ignores the register. A correct semantic response table handles all external intervention queries, including their shared-background joint laws, independently of that register. Its external outputs match the semantic model. Replacing the register by one when $A=U=0$ leaves the output zero, whereas $do(B=1)$ requires one. The advertised alignment fails (11). Correct external answers alone did not reveal the bypass. $\square$

This does not disqualify an external answer service from behavioral flow distillation. It refutes the stronger claim about that internal register. Interchange interventions and their training variants supply relevant methods for testing this distinction (Geiger et al., 2021, 2022). Their guarantees apply on their stated intervention domains; success on a sample is not a universal theorem about all representations.

# 9 A training programme for the declared flow

Distillation begins with a semantic registry, not a transcript of unexamined reasoning. Teacher-generated text can propose variables, mechanisms and proof steps. Each accepted record must specify its meaning, support contract, world identities and status. The teacher’s architecture and private implementation are not requested or supervised. A student remains free to implement the accepted semantics with a neural network, a circuit, a response table or a hybrid.

**Algorithm 1 (construct a target).** Fix the registry and model class. Collect teacher reports with their numerical precision or statistical intervals. Convert supported event reports into the common response constraints of Section 4. Check feasibility and save a common witness or an infeasibility certificate. If infeasible, identify conflicting records and return the conflict. A relaxed or repaired target must be labelled as a new target under a declared reliability rule; it is not a faithful clone of the inconsistent transcript.

**Algorithm 2 (choose the transfer strength).** For each requested query, compute its attainable range on $K_T$. If identified, supervise its common value. If not identified, either request informative L3 evidence, declare an additional causal assumption, retain the uncertainty or explicitly choose one possible model. Do not label the selected coupling as recovered from L2 data. Group related student answers in a common-extension check.

**Algorithm 3 (train an implementation).** Choose an arbitrary student implementation and a semantic readout. Train on accepted observations, interventions and declared world profiles. A moment-based objective can minimize weighted discrepancies in $Cq_S$ under a feasible student parameterization. If the student only proposes outputs, a checker must evaluate their common compatibility. If internal realization is claimed, train and independently evaluate the student’s own intervention map and abstraction. Trace style or hidden-state similarity to the teacher is optional and supplies no causal guarantee by itself.

For a finite moment family, a representative objective is

$$\min_{\theta}\ \sum_j w_j\,|c_j^\top q_\theta-m_j|^2+\lambda\,\mathcal L_{\mathrm{int}}(\theta),\qquad q_\theta\in K_{\mathrm{struct}}. \tag{12}$$

Here $m_j$ is an accepted moment, $w_j\ge0$ is a declared training weight and $\mathcal L_{\mathrm{int}}$ is an intervention-alignment loss used only for the internal claim. An interval target replaces point error by distance to its accepted interval, but zero separate interval loss does not imply common-flow validity. The parameterization or checker must enforce that validity. Optimizing (12) is a proposal; no optimizer convergence guarantee is assumed.

**Algorithm 4 (certify and deploy).** Freeze a student version and evaluate its declared flow contract. Produce one of the three statuses in Definition 4.4. Store proof dependencies and allowed future updates. At runtime, answer only within the certified scope, otherwise acquire evidence, refine the model class, solve a new bound or return an unresolved status. A fluent explanation can accompany an answer; its length does not determine whether the answer is accepted.

## What long reasoning traces contribute

Long teacher traces are candidate supervision for semantic parsing, operation proposal, graph-licensed transformations and scheduling. They can show a useful route through the problem. Each proposed operation should carry its premises, affected variables, source records and certificate. Traces become training data after these components are checked. Repeated correct final numbers do not validate an unlicensed do-calculus step, and the three rules do not by themselves identify every multiworld query. Appropriate counterfactual identification or response-model assumptions remain necessary (Shpitser & Pearl, 2008).

The student can learn to retrieve a valid bound, test a witness, repair a certificate, request an informative probe or stop. Those are implementation choices. Supervision should reward the declared semantic outcome and measured resource use, with certification as a required condition. A policy that chooses a cheap valid route is useful; a policy that omits a premise has not distilled an accepted operation. Task observability supplies a related separation between decoded answers and realized operations (Ghosh, 2026c).

# 10 The AI harness and immutable records

The harness is the operational setting in which flow distillation can be used. Agent Lightning separates agent execution from reinforcement training (Luo et al., 2025); SWE-agent shows that model–tool interfaces affect agent behavior (Yang et al., 2024). These precedents support modular execution and training. Neither supplies the particular common-response coherence certificate required here.

| Component | Authoritative responsibility | Stored or returned object |
|:--|:--|:--|
| Semantic registry | Fix meanings and allowed changes | Variable, graph, unit, regime and intervention versions |
| Teacher and proposal policy | Suggest data and operations | Candidate answers, traces and probe requests |
| Coherence checker | Test common-model compatibility | Witness, refutation or unverified status |
| Student | Implement the accepted contract | Semantic predictions and declared realization maps |
| Interval engine | Bound unresolved queries | Endpoints, support checks and certificates |
| Operation store | Preserve accepted history | Immutable records with scope and dependencies |
| Scheduler | Choose further work | Retrieve, check, refine, query, solve or stop |

*Table 2 Responsibilities in the proposed harness*

An accepted record contains the query and its semantics, case identity, factual evidence snapshot, world family, intervention definitions, model and student versions, coupling contract, support status, precision, value or interval, certificate and dependency identifiers. The record’s scope is part of its meaning. An embedding can suggest a candidate record; it cannot decide semantic equivalence or certify reuse.

**Proposition 10.1 (reuse under refinement).** For a fixed query, including its factual conditioning event, if a nonempty retained family changes from $K$ to $K'\subseteq K$, every previously valid outer interval remains valid. If the event changes, this conclusion does not follow merely from adding facts about the case.

**Proof.** Taking extrema over a subset cannot enlarge the range of the same function. Changing the conditioning event changes that function, so the subset argument no longer compares the same query. $\square$

The interval reuse contract follows the IDC programme (Ghosh, 2026d). A correction appends a new record and marks which earlier scope it supersedes. It does not change the bytes of the accepted record. This computational immutability supports reproducibility and dependency checking. It does not require unchanging model parameters or verbatim retention of all tokens. A sufficient state or continuation quotient can replace a long trace for a fixed task contract. If evidence needed by a later query was discarded, the harness must narrow its claim or reacquire information.

## Requests and certificate cost

On a request, the harness resolves the context, rejects inconsistent model constraints, checks support and searches the operation store. It verifies any applicable certificate before reuse. A sharp counterfactual interval may already settle a decision. For example, an action is certified preferable when the lower bound of its advantage is positive; joint advantage bounds can be tighter than subtraction of two independent outer intervals. If the decision remains unresolved, the scheduler compares the cost of a new probe with solving or refining the current model.

The store should distinguish exact arithmetic, identified values, sharp bounds, outer bounds, selected-model predictions, statistical guarantees, undefined conditioning, inconsistent premises and unverified computation. “Exact” describes arithmetic or an equality proof; it does not imply identification from the evidence. “Sharp” is always relative to the declared class. A selected model can return an exact rational counterfactual that is not the teacher’s uniquely identified answer.

**Observation 10.2 (no speed theorem from flow equivalence).** Implementation independence permits a faster student but does not entail one. Compilation may increase memory, certification may dominate arithmetic, and inference over response laws can be exponential. Evaluation must measure total latency, solver time, memory, external measurements and checker work separately. The five-event compiled table below is a fidelity example; its size is not a compression result.

## Training the scheduler

Each accepted run produces a labelled route through retrieval, support checking, witness testing, repair, solving and evidence acquisition. A learned scheduler can train on those records, while the same checker remains authoritative. The reward should charge measured resources and separately enforce coverage and scope. Penalizing text length alone can move work into expensive tools or encourage omitted certificates. Persistent training records must therefore include rejected operations and costs as well as successful final answers.

For statistical teacher reports, repeated reuse should track distinct source claims and their joint coverage assumptions. Reusing one accepted record does not create independent new evidence. Conversely, adaptively obtaining new measurements requires a valid sequential coverage scheme; a list of unrelated nominal confidence intervals does not automatically give a certified global model class.

# 11 Exact finite checks

All numbers in this section are generated by `check_distillation.py` and inserted from `results.json`. The implementation uses Python’s exact integers and rational fractions. The examples check mathematical identities and finite models; they are not a neural-model benchmark. The script is rerun from scratch and its JSON compared byte for byte. There are @@CHECKCOUNT@@ named checks and none fails.

## A complete small response grid

We enumerate all four-atom response laws with probabilities in twelfths. There are @@LAWS@@ laws and @@PROFILES@@ distinct pairs $(p_0,p_1)$. Of those L2 profiles, @@AMBIGUOUS@@ admit multiple grid response laws. Every profile’s minimum and maximum $P(Y_0=1,Y_1=1)$ agree exactly with (8). This is a census of a finite probability grid, not of every causal graph or all continuous response distributions. The analytic construction after (8) establishes the continuous endpoints.

The same-response and opposite-response laws in (3) yield conditional values one and zero. The moment-rank calculation gives two coordinates for the L2 marginals and three for the binary joint response law. The invisible direction $(1,-1,-1,1)$ preserves normalization and both marginal moments while changing the joint-response moment. The parity example verifies equality of every pair law and the disagreement of the triple law. The triangle example verifies the global obstruction.

## A five event transfer example

The graph is $X\to A$, $X\to B$, $A\to C$, $B\to C$, $C\to Y$. Each event has an independent uniform background on $\{0,1,2,3\}$. The threshold counts, in binary parent order, are $2$ for $X$; $(1,3)$ for $A$ and $B$; $(1,2,3,2)$ for $C$; and $(1,3)$ for $Y$. A node equals one when its background is below the relevant threshold.

![Five event causal graph](flow_graph.png)

*Figure 1 The five event graph used in the exact transfer example*

The teacher evaluates these assignments directly. The flow-preserving student uses separately compiled response tables indexed by the same background. Pointwise equality is checked for all @@ASSIGNMENTS@@ world assignments across @@WORLDS@@ perfect-intervention regimes and @@BACKGROUNDS@@ background states. Thus this student preserves the complete world profile for this finite model. Its numerical route differs; no hidden teacher activations are copied.

A second student shifts a node’s background by two modulo four whenever its parent configuration has odd parity. Each background is still uniform at any fixed parent configuration, so the same conditional probabilities and all single-world intervention laws remain. Integer enumeration verifies this, and a separate product of conditional counts independently checks every regime’s distribution. The cross-world dependence changes.

The comparison asks for $P(Y_{do(X=1)}=1\mid X=0,Y=0)$, preserving the same case background after conditioning on its factual switch and outcome.

| System | All declared L1 and L2 laws | Same case counterfactual |
|:--|:--:|:--:|
| Direct teacher | Reference | $@@DIRECT@@$ |
| Compiled flow student | Exact match | $@@COMPILED@@$ |
| Shifted L2 student | Exact match | $@@SHIFTED@@$ |

*Table 3 Exact counterfactual separation after perfect L2 matching*

The difference between the last two counterfactuals is $4/35$. This is a failure of L3 transfer despite complete L2 agreement on this declared five-event model. It is not evidence that a particular neural distillation method fails at that rate, nor a test over the earlier 1,024-graph family.

## Support and certificate checks

The conditioning bound is tested on all @@TVPAIRS@@ unordered pairs from @@TVLAWS@@ four-atom laws in quarters, across @@TVEVENTS@@ event choices with positive support in both laws. Every conditional total-variation distance satisfies (10). A separate sharp example has response distance $1/100$, evidence mass $1/10$ and conditional error $1/10$. The rare-event construction checks conditional error one while the unconditioned distance decreases.

Further exact checks cover a Farkas contradiction with dual value $-1/5$, a rounding interval containing a feasible witness, undefined conditioning at zero support, a positive and a zero separator in junction-tree gluing, and an explicit internal bypass. These are transparent arithmetic checks of the examples, not exhaustive verification of the general theorems. No C# execution or independent neural training is reported for this paper.

# 12 Neuroscience as a functional hypothesis

The neuroscience interpretation concerns preservation of task structure across different implementations and changing representations. It does not assert that the brain stores a response simplex, computes do-calculus certificates or retains literal immutable records. The causal flow in this paper is a declared computational object; matching behavior in a laboratory task would be evidence for a functional hypothesis, not identification of a neural algorithm.

Mızrak et al. (2021) found that human hippocampal and lateral orbitofrontal representations differentiated task substructures and that their differentiation was correlated. Their task involved context-determined and context-invariant associations. This supports studying transfer of task relationships beyond individual stimuli. It does not show recovery of a unique causal graph or preservation of a counterfactual coupling. The ADC analogue is a semantic structure that can survive a change of sensory labels while retaining declared query behavior.

Zong et al. (2025) provide a constraint on a simple serial teacher–student analogy. In rats, inactivation of ventral subiculum left learned orbitofrontal schema correlates unaffected and accelerated their formation during transfer. The authors interpret the findings as favoring parallel extraction of different features by hippocampus and orbitofrontal cortex. Consequently this paper does not identify hippocampus as a teacher whose implementation is copied into neocortex. Biological structure transfer may involve parallel learning and selective interaction.

Driscoll et al. (2017) observed major reorganization of posterior parietal activity patterns over weeks of stable task performance in mice. Population information was more stable than the identities of informative neurons. This motivates measuring functional invariants under changing neural coordinates. It does not prove a pointwise causal abstraction. In ADC terms, changing representations can preserve the semantic contract if a valid map changes with them; evidence for such a map requires intervention-sensitive testing rather than decoding alone.

These findings motivate three research directions. First, measure whether learned relations transfer across new stimuli with the same mechanism structure. Second, distinguish knowledge of separate intervention outcomes from knowledge of their same-case dependence. Third, ask whether a task-relevant relational code remains usable when the neural implementation changes. Theorems about a declared SCM do not predict that every biological memory must retain all these details.

## The information that consolidation would need

The rank criterion gives a scoped computational prediction: if a future question requires a direction absent from the retained moment code, no decoder using only that code can answer it exactly throughout the declared family. An observed failure could therefore reflect lost dependence information even when marginal recall remains intact. Conversely, successful marginal recall does not demonstrate preservation of a multiworld coupling. This is a task design principle, not a theorem that cortical consolidation inevitably destroys counterfactual information.

An engineered consolidation scheme can preserve accepted relations and support contracts while discarding repeated surface traces. New records supersede old scopes rather than overwriting history. A biological memory can reconsolidate and change, so only the information-level proposal carries over: what must remain sufficient for a specified future task? Brain regions, synapses and neural codes must be investigated on their own terms.

# 13 Falsifiable hypotheses and evaluation

The computational H-series concerns proposed distillation and harness implementations. The N-series concerns prospective behavioral or neural experiments. Learned improvements require preregistered datasets, held-out cases, matched budgets and a minimum meaningful effect. Mathematical exactness checks are treated separately from those empirical effect sizes.

**H1 (common-flow acceptance).** On coherent and deliberately corrupted finite teacher transcripts generated from a known model class, the checker will accept every feasible transcript and reject every transcript with a supplied exact infeasibility certificate. Any false acceptance of a certified contradiction or rejection of a supplied feasible witness refutes the checker implementation. Report unresolved computations separately from rejection.

**H2 (honest hierarchy transfer).** On held-out teachers that are L2-equivalent but L3-distinct, an L2-only student will retain a counterfactual interval or disclose its selected coupling. Claiming that an unidentified point was recovered from those lower-level data refutes its certification procedure. A predictive guess can be scored as a guess; it is not a recovered flow.

**H3 (additional informative supervision).** At matched training and measurement budgets, accepted L3 or response-profile supervision will reduce held-out counterfactual error relative to L2-only supervision by a preregistered effect $\Delta_H>0$ on an explicitly nonidentified task family. Fix the family before training and report interval coverage and width as well as point error. An upper confidence limit below $\Delta_H$ refutes that quantitative learning prediction; it does not refute the indistinguishability theorem.

**H4 (implementation independence).** A compiled or otherwise different student passing the common semantic contract will preserve held-out queries in the certified scope without teacher activation matching. One within-scope mismatch under the stated exact assumptions refutes the transfer certificate. An out-of-scope query does not test it. The full finite scope can be checked exhaustively; neural cases require their own declared validation contract.

**H5 (measured harness benefit).** At matched correctness, coverage and query scope, the proposed reuse scheduler will reduce total measured request latency by at least a preregistered fraction $\rho>0$ relative to recomputation. Include checking, retrieval, model evaluation, solving and external measurements. A confidence interval whose upper improvement endpoint is below $\rho$ refutes that speed prediction. Fewer solves alone does not establish it.

**H6 (support-sensitive approximation).** On synthetic common-profile perturbations with a verified total-variation radius and positive support floor, every reported conditional error enclosure will satisfy (10). One violation refutes the implementation or the claimed metric certificate. Separately vary evidence rarity to test whether an empirically learned student achieves its registered accuracy; that learning claim is not implied by (10).

**N1 (structure transfer across surface changes).** After matched training, humans will generalize intervention outcomes better to new stimuli that preserve the learned mechanism structure than to stimuli with a structure-breaking relabelling, by at least a preregistered $\Delta_1>0$. Match associative exposure and reward information. An upper confidence endpoint below $\Delta_1$ refutes this quantitative functional prediction. Success supports structure transfer, not a claim of full L3 distillation.

**N2 (learning the cross-world relation).** Participants trained on two tasks with matched intervention marginals but different explicitly taught shared-cause couplings will give different same-case counterfactual judgments in the predicted direction, by at least $\Delta_2>0$, while their intervention estimates remain within a registered equivalence band. The coupling must be taught through a legitimate shared-cause mechanism or diagnostic evidence; ordinary observation does not reveal both potential outcomes of one case. Failure to separate the counterfactual judgments refutes this task-specific transfer prediction.

**N3 (functional stability under changing codes).** In longitudinal learning with stable task performance, an independently fitted, time-specific representation map will preserve intervention-sensitive task relations better than a fixed-neuron alignment, by at least $\Delta_3>0$. Control decoder capacity, attention and sampling. An upper confidence endpoint below $\Delta_3$ refutes that mapping prediction. Decoding success alone remains insufficient evidence for the pointwise commutation of (11).

For N1–N3, register the sample, exclusion rules, delay, power and contrasts before data collection. A result that does not resolve the prespecified effect is inconclusive. These experiments can refute the proposed biological interpretation without refuting a theorem whose mathematical premises hold.

# 14 Limits and research programme

Causal-flow distillation is always relative to a declared description. A teacher and student may agree perfectly on that description and disagree at a finer level. A correct coherence checker can also certify a consistently wrong causal model of the world. Observations, intervention definitions, latent assumptions and data quality therefore remain substantive scientific commitments. A graph and a response law are sufficient coordinates for a finite model, not an architecture-free guarantee of truth.

The exact polyhedral methods assume finite response atoms and linear constraints. Large spaces can be exponentially costly; latent independence and continuous mechanisms can require different algorithms. A relaxation can give a valid outer bound when inclusion is certified, but its endpoints need not be sharp for the intended class. Statistically estimated teacher data need simultaneous coverage. Numerical feasibility without validated arithmetic is not an exact certificate.

The present paper establishes an interface and its proof obligations. It does not demonstrate general neural compression, an efficient universal causal compiler, cortical implementation or faster end-to-end agents. The next implemented study should distinguish three student targets: L2 marginals, a selected coherent response law, and a retained certified flow family. It should hold the semantic task fixed while changing the student implementation, then test multiworld fidelity, evidence updates, certificate cost and unseen-query scope.

Distillation of ADC can therefore preserve causal flow alone. The transferable object is the declared relation between facts, interventions and joint alternative outcomes. The implementation remains the student’s choice. Counterfactual transfer requires the cross-world information that the chosen query family actually uses; where the teacher has not supplied it, an interval or an explicit coupling assumption is part of the honest result.

# Appendix A Reproduction and arithmetic

The source bundle contains the Markdown template, the filled manuscript, `check_distillation.py`, its exact `results.json`, the Word builder and its reference style document. Run the checker to regenerate the result file, then run the builder to insert those values and create the Word document. The builder requires Python with python-docx, lxml and matplotlib, plus Pandoc. The checker requires only the Python standard library. The supplied commands use the working directory containing these files and no earlier project path.

The checks include independent product-factorization counts for the five-event intervention distributions. They do not constitute a second independent implementation of every theorem or a C# replication. Reproduction of exact result bytes is distinguished from proof and from independent empirical validation. Word pagination can vary across renderers; native equations remain editable. The internal visual render is not an additional experiment.

# Appendix B The guarantee ledger

| Claim | Needed premise | What it does not establish |
|:--|:--|:--|
| Exact flow equivalence | Equal declared joint profile laws | Finer causal truth or identical implementations |
| Transcript coherence | One feasible law in the declared class | Universal coherence of unseen teacher answers |
| Sharp interval | Exact optimization over the stated class | Sharpness for an omitted independence restriction |
| Linear compression rank | Convex family and specified linear moments | Minimum neural parameters or general nonlinear memory |
| Conditional stability | Common profile metric and positive support | L3 control from L2 error alone |
| Internal realization | Declared intervention commutation and background law | Teacher hidden-state copying |
| Neural or runtime improvement | Controlled implementation study | A consequence of semantic equivalence alone |

*Table 4 Scope of the guarantees*

# References

Balke, A., & Pearl, J. (1997). Bounds on treatment effects from studies with imperfect compliance. *Journal of the American Statistical Association, 92*(439), 1171–1176. https://doi.org/10.1080/01621459.1997.10474074

Bareinboim, E., Correa, J. D., Ibeling, D., & Icard, T. (2022). On Pearl’s hierarchy and the foundations of causal inference. In H. Geffner, R. Dechter, & J. Y. Halpern (Eds.), *Probabilistic and causal inference: The works of Judea Pearl* (pp. 507–556). ACM. https://doi.org/10.1145/3501714.3501743

Beckers, S., & Halpern, J. Y. (2019). Abstracting causal models. *Proceedings of the AAAI Conference on Artificial Intelligence, 33*(1), 2678–2685. https://doi.org/10.1609/aaai.v33i01.33012678

Chatzi, I., Corvelo Benz, N. L., Straitouri, E., Tsirtsis, S., & Gomez-Rodriguez, M. (2025). Counterfactual token generation in large language models. *Proceedings of the Fourth Conference on Causal Learning and Reasoning, PMLR 275*, 1291–1315. https://proceedings.mlr.press/v275/chatzi25a.html

Deng, X., & Zhang, Z. (2021). Comprehensive knowledge distillation with causal intervention. *Advances in Neural Information Processing Systems, 34*. https://papers.neurips.cc/paper_files/paper/2021/hash/b9f35816f460ab999cbc168c4da26ff3-Abstract.html

Driscoll, L. N., Pettit, N. L., Minderer, M., Chettih, S. N., & Harvey, C. D. (2017). Dynamic reorganization of neuronal activity patterns in parietal cortex. *Cell, 170*(5), 986–999.e16. https://doi.org/10.1016/j.cell.2017.07.021

Geiger, A., Lu, H., Icard, T., & Potts, C. (2021). Causal abstractions of neural networks. *Advances in Neural Information Processing Systems, 34*, 9574–9586. https://papers.nips.cc/paper/2021/hash/4f5c422f4d49a5a807eda27434231040-Abstract.html

Geiger, A., Wu, Z., Lu, H., Rozner, J., Kreiss, E., Icard, T., Goodman, N., & Potts, C. (2022). Inducing causal structure for interpretable neural networks. *Proceedings of the 39th International Conference on Machine Learning, PMLR 162*, 7324–7338. https://proceedings.mlr.press/v162/geiger22a.html

Ghosh, D. (2026a). *Certified Counterfactual Branches in Autoregressive Do Calculus*. https://doi.org/10.13140/RG.2.2.19065.22885

Ghosh, D. (2026b). *Autoregressive Do Calculus with Sequential Evidence*. https://doi.org/10.13140/RG.2.2.24386.75209

Ghosh, D. (2026c). *Task Observability in Latent Causal Reasoning*. https://doi.org/10.13140/RG.2.2.25697.47204

Ghosh, D. (2026d). *Certified Causal Memory with Interval Do Calculus*. https://doi.org/10.13140/RG.2.2.11436.83848

Hamman, F., Dissanayake, P., Fu, Y., & Dutta, S. (2025). Few-shot knowledge distillation of LLMs with counterfactual explanations. *Advances in Neural Information Processing Systems, 38*. https://doi.org/10.52202/085713-4999

Hinton, G., Vinyals, O., & Dean, J. (2015). *Distilling the knowledge in a neural network*. arXiv. https://arxiv.org/abs/1503.02531

Luo, X., Zhang, Y., He, Z., Wang, Z., Zhao, S., Li, D., Qiu, L. K., & Yang, Y. (2025). *Agent Lightning: Train ANY AI agents with reinforcement learning*. arXiv. https://arxiv.org/abs/2508.03680

Mızrak, E., Bouffard, N. R., Libby, L. A., Boorman, E. D., & Ranganath, C. (2021). The hippocampus and orbitofrontal cortex jointly represent task structure during memory-guided decision making. *Cell Reports, 37*(9), 110065. https://doi.org/10.1016/j.celrep.2021.110065

Rubenstein, P. K., Weichwald, S., Bongers, S., Mooij, J. M., Janzing, D., Grosse-Wentrup, M., & Schölkopf, B. (2017). Causal consistency of structural equation models. *Proceedings of the 33rd Conference on Uncertainty in Artificial Intelligence*, 151–160. https://proceedings.mlr.press/r15/rubenstein-17a.html

Shpitser, I., & Pearl, J. (2008). Complete identification methods for the causal hierarchy. *Journal of Machine Learning Research, 9*, 1941–1979. https://jmlr.org/papers/v9/shpitser08a.html

Tian, J., & Pearl, J. (2000). Probabilities of causation: Bounds and identification. *Annals of Mathematics and Artificial Intelligence, 28*, 287–313. https://doi.org/10.1023/A:1018912507879

Vorob’ev, N. N. (1962). Consistent families of measures and their extensions. *Theory of Probability and Its Applications, 7*(2), 147–163. https://doi.org/10.1137/1107014

Yang, J., Jimenez, C. E., Wettig, A., Lieret, K., Yao, S., Narasimhan, K., & Press, O. (2024). SWE-agent: Agent-computer interfaces enable automated software engineering. *Advances in Neural Information Processing Systems, 37*. https://arxiv.org/abs/2405.15793

Zong, W., Zhou, J., Gardner, M. P. H., Zhang, Z., Costa, K. M., & Schoenbaum, G. (2025). Hippocampal output suppresses orbitofrontal cortex schema cell formation. *Nature Neuroscience, 28*, 1048–1060. https://doi.org/10.1038/s41593-025-01928-z
