"""Independent exact checks. Python simulates exogenous states; C# sums latent-state densities."""
from __future__ import annotations
import csv,itertools,json,math,statistics,sys,time
from collections import defaultdict,Counter
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import sympy as sp
from y0.dsl import Variable
from y0.graph import NxMixedGraph
from y0.algorithm.identify import identify_outcomes

P=Path(__file__).resolve().parent
data=P/"output";cs={l.split("\t")[0]:l.strip().split("\t")[1].split() for l in (P/"cs_results.txt").read_text().splitlines()}
checks=[]
def check(name,ok,detail=""):
    checks.append({"name":name,"passed":bool(ok),"detail":str(detail)})
    if not ok:raise AssertionError((name,detail))
def exact(name,expected):
    actual=[F(x) for x in cs[name]]
    check(name,actual==list(map(F,expected)),(actual,expected))

class Graph:
    def __init__(self,n,d,b,vertices=None):
        self.n=n;self.v=set(range(n)) if vertices is None else set(vertices)
        self.d={tuple(e) for e in d if set(e)<=self.v};self.b={tuple(sorted(e)) for e in b if set(e)<=self.v}
    def sub(self,v):return Graph(self.n,self.d,self.b,self.v&set(v))
    def cut(self,inc=(),out=()):
        inc,out=set(inc),set(out)
        return Graph(self.n,[(a,b) for a,b in self.d if b not in inc and a not in out],
                     [(a,b) for a,b in self.b if a not in inc and b not in inc],self.v)
    def ancestors(self,a):
        a=set(a)&self.v
        while True:
            new=a|{i for i,j in self.d if j in a}
            if new==a:return a
            a=new
    def districts(self):
        remain=set(self.v);ds=[]
        while remain:
            c={min(remain)}
            while True:
                new=c|{v for e in self.b if set(e)&c for v in e}
                if new==c:break
                c=new
            ds.append(c);remain-=c
        return ds
    def separated(self,y,z,c):
        """Enumerate simple m-active paths directly, independent of C# latent moralisation."""
        y,z,c=set(y),set(z),set(c)
        if not y or not z:return True
        anc=self.ancestors(c);adj=defaultdict(list)
        for a,b in self.d:
            adj[a].append((b,False,True));adj[b].append((a,True,False))
        for a,b in self.b:
            adj[a].append((b,True,True));adj[b].append((a,True,True))
        def dfs(v,arrival,seen):
            if v in z:return True
            for w,head_v,head_w in adj[v]:
                if w in seen:continue
                if arrival is not None:
                    collider=arrival and head_v
                    if (collider and v not in anc) or (not collider and v in c):continue
                if dfs(w,head_w,seen|{w}):return True
            return False
        return not any(dfs(s,None,{s}) for s in y)
    def rule(self,r,y,x,z,w):
        h=self.cut(x)
        g=h if r==1 else self.cut(x,z) if r==2 else self.cut(set(x)|(set(z)-h.ancestors(w)))
        return g.separated(y,z,set(x)|set(w))

def bits(mask):return {i for i in range(16) if mask>>i&1}
def mask(v):return sum(1<<i for i in v)

class Kernel:
    def __init__(self,a):self.a=tuple(a);self.n=len(self.a).bit_length()-1;self.cache={}
    def marginal(self,variables):
        variables=frozenset(variables)
        if not variables:return self
        if variables in self.cache:return self.cache[variables]
        remove=mask(variables);bucket=defaultdict(F)
        for b,q in enumerate(self.a):bucket[b&~remove]+=q
        result=Kernel(bucket[b&~remove] for b in range(len(self.a)))
        self.cache[variables]=result;return result
    def divide(self,k):
        assert all(q>0 for q in k.a)
        return Kernel(a/b for a,b in zip(self.a,k.a))
    def prefix_factor(self,active,i):
        later={j for j in active if j>i}
        return self.marginal(later).divide(self.marginal(later|{i}))
    @staticmethod
    def multiply(n,ks):
        ks=list(ks)
        return Kernel(math.prod((k.a[b] for k in ks),start=F(1)) for b in range(1<<n))

class Failure(Exception):pass
def identify(y,x,p,g):
    y,x=set(y),set(x);v=g.v
    if not x:return p.marginal(v-y)
    a=g.ancestors(y)
    if a!=v:return identify(y,x&a,p.marginal(v-a),g.sub(a))
    w=(v-x)-g.sub(v-x).ancestors(y)
    if w:return identify(y,x|w,p,g)
    ds=g.sub(v-x).districts()
    if len(ds)>1:return Kernel.multiply(g.n,[identify(s,v-s,p,g) for s in ds]).marginal(v-(x|y))
    s=ds[0];original=g.districts()
    if len(original)==1:raise Failure()
    if s in original:return Kernel.multiply(g.n,[p.prefix_factor(v,i) for i in sorted(s)]).marginal(s-y)
    larger=next(c for c in original if s<c)
    return identify(y,x&larger,Kernel.multiply(g.n,[p.prefix_factor(v,i) for i in sorted(larger)]),g.sub(larger))
def idc(y,x,z,p,g):
    y,x,z=set(y),set(x),set(z)
    if not z:return identify(y,x,p,g)
    for i in sorted(z):
        if g.rule(2,y,x,{i},z-{i}):return idc(y,x|{i},z-{i},p,g)
    joint=identify(y|z,x,p,g)
    return joint.divide(joint.marginal(y))

class Model:
    def __init__(self,record):
        self.record=record;self.n=record["n"];self.g=Graph(self.n,record["directed"],record["bidirected"])
        self.d=list(map(tuple,record["directed"]));self.b=list(map(tuple,record["bidirected"]))
        self.k=record["privateK"];self.h=record["latentK"];self.cache={}
    def law(self,actions=0,values=0):
        key=(actions,values&actions)
        if key in self.cache:return self.cache[key]
        n,m=self.n,len(self.b);counts=[0]*(1<<n);den=4**(n+m)
        for u in range(1<<m):
            wh=math.prod(k if u>>j&1 else 4-k for j,k in enumerate(self.h))
            for noise in range(1<<n):
                weight=wh*math.prod(k if noise>>j&1 else 4-k for j,k in enumerate(self.k))
                v=0
                for i in range(n):
                    if actions>>i&1:bit=(values>>i)&1
                    else:
                        bit=(noise>>i)&1
                        for a,b in self.d:
                            if b==i:bit^=(v>>a)&1
                        for j,e in enumerate(self.b):
                            if i in e:bit^=(u>>j)&1
                    v|=bit<<i
                counts[v]+=weight
        p=Kernel(F(c,den) for c in counts)
        assert sum(p.a)==1
        self.cache[key]=p;return p

@lru_cache(None)
def mass(a,selected,values):
    return sum((q for b,q in enumerate(a) if ((b^values)&selected)==0),F(0))
def conditional(p,y,value,w):
    return mass(p.a,y|w,value)/mass(p.a,w,value)
def replacement(p,position,value,order=None):
    order=list(range(p.n)) if order is None else order;answer=[]
    for b in range(1<<p.n):
        q=F(1);prefix=0
        for i in order:
            q*=int((b>>i&1)==value) if i==position else conditional(p,1<<i,b,prefix)
            prefix|=1<<i
        answer.append(q)
    return Kernel(answer)
def tv(a,b):return sum((abs(x-y) for x,y in zip(a.a,b.a)),F(0))/2

records=json.loads((data/"models.json").read_text());models={r["id"]:Model(r) for r in records}
queries=json.loads((data/"id_queries.json").read_text())
names=[("backdoor",1,2),("frontdoor",0,2),("bow",0,1),("last_district",1,2),("prefix_collider",1,2)]
for name,x,y in names:
    m=models[name];p=m.law()
    try:identify({y},{x},p,m.g);identified=True
    except Failure:identified=False
    rep=replacement(p,x,1);truth=m.law(1<<x,1<<x)
    separated=m.g.cut(out={x}).separated(set(range(x+1,m.n)),{x},set(range(x)))
    last=not(next(c for c in m.g.districts() if x in c)&set(range(x+1,m.n)))
    exact("named_"+name,[identified,mass(truth.a,1<<y,1<<y),mass(rep.a,1<<y,1<<y),tv(rep,truth),separated,last])

g=models["frontdoor"].g;seen={(frozenset({0}),frozenset())};pending=list(seen)
def subsets(s):
    a=sorted(s)
    return [set(c) for k in range(1,len(a)+1) for c in itertools.combinations(a,k)]
while pending:
    x,w=map(set,pending.pop());absent=g.v-({2}|x|w)
    def add(a,b):
        state=(frozenset(a),frozenset(b))
        if state not in seen:seen.add(state);pending.append(state)
    for z in subsets(absent):
        if g.rule(1,{2},x,z,w):add(x,w|z)
        if g.rule(3,{2},x,z,w):add(x|z,w)
    for z in subsets(w):
        if g.rule(1,{2},x,z,w-z):add(x,w-z)
        if g.rule(2,{2},x,z,w-z):add(x|z,w-z)
    for z in subsets(x):
        if g.rule(3,{2},x-z,z,w):add(x-z,w)
        if g.rule(2,{2},x-z,z,w):add(x-z,w|z)
exact("rule_path_frontdoor",[len(seen),any(not x for x,w in seen),True])

identified_count=assignments=external_agree=0;fail_count=0
for q in queries:
    m=models[q["model"]];p=m.law();x,y=q["x"],q["y"]
    try:
        answer=identify({y},{x},p,m.g);identified=True;identified_count+=1
    except Failure:identified=False;fail_count+=1
    assert identified==q["identified"],q
    for action in (0,1):
        t=m.law(1<<x,action<<x);value=mass(t.a,1<<y,1<<y)
        assert value==F(q["truth"+str(action)])
        if identified:assert value==F(q["p"+str(action)])
    if identified:
        for b,value in enumerate(answer.a):
            truth=m.law(1<<x,b)
            assert value==mass(truth.a,1<<y,b),(q,b,value)
            assignments+=1
    nodes=[Variable("V"+str(i)) for i in range(m.n)]
    yg=NxMixedGraph.from_edges(nodes=nodes,directed=[(nodes[a],nodes[b]) for a,b in m.d],
                              undirected=[(nodes[a],nodes[b]) for a,b in m.b])
    oracle=identify_outcomes(yg,treatments={nodes[x]},outcomes={nodes[y]}) is not None
    assert oracle==identified,(q,"external oracle")
    external_agree+=1
exact("id_models_queries",[len(names),len(models)-len(names),len(queries),identified_count,fail_count,assignments,0])

four=list(itertools.combinations(range(4),2));graph_count=cert_count=last_count=0
cache={}
with (data/"prefix_graphs.csv").open() as f:
    for row in csv.DictReader(f):
        d,b,s=map(int,[row["directed"],row["bidirected"],row["position"]])
        if (d,b) not in cache:cache[d,b]=Graph(4,[e for i,e in enumerate(four) if d>>i&1],[e for i,e in enumerate(four) if b>>i&1])
        g=cache[d,b]
        sep=g.cut(out={s}).separated(set(range(s+1,4)),{s},set(range(s)))
        last=not(next(c for c in g.districts() if s in c)&set(range(s+1,4)))
        assert sep==last==bool(int(row["separated"]))==bool(int(row["last"])),row
        graph_count+=1;cert_count+=sep;last_count+=last
exact("prefix_graph_equivalence",[graph_count,cert_count,last_count,0])

licensed=[0]*3;equal=[0]*3;bindings=0;three=list(itertools.combinations(range(3),2))
for dm in range(8):
    for bm in range(8):
        d=[e for i,e in enumerate(three) if dm>>i&1];b=[e for i,e in enumerate(three) if bm>>i&1]
        model=Model({"n":3,"directed":d,"bidirected":b,"privateK":[1,2,3],"latentK":[1]*len(b)})
        for y,z in itertools.permutations(range(3),2):
            other=3-y-z
            for role in range(3):
                x={other} if role==1 else set();w={other} if role==2 else set()
                for r in (1,2,3):
                    bindings+=1
                    if not model.g.rule(r,{y},x,{z},w):continue
                    licensed[r-1]+=1;ok=True
                    for values in range(8):
                        if r==1:
                            p=model.law(mask(x),values)
                            left=conditional(p,1<<y,values,(1<<z)|mask(w));right=conditional(p,1<<y,values,mask(w))
                        else:
                            p=model.law(mask(x)|1<<z,values)
                            left=conditional(p,1<<y,values,mask(w))
                            right=conditional(model.law(mask(x),values),1<<y,values,mask(w)|(1<<z if r==2 else 0))
                        ok&=left==right
                    equal[r-1]+=ok
exact("three_rule_soundness",[bindings,licensed[0],equal[0],licensed[1],equal[1],licensed[2],equal[2]])

def witness(second,act=None):
    a=[F(0)]*4
    for u,noise in itertools.product(range(2),repeat=2):
        x=u if act is None else act;y=x if second and x!=u else noise;a[x|(y<<1)]+=F(1,4)
    return Kernel(a)
exact("positive_witness",[witness(0).a==witness(1).a,all(q>0 for q in witness(0).a),
       mass(witness(0,1).a,2,2),mass(witness(1,1).a,2,2),mass(witness(0,0).a,2,2),mass(witness(1,0).a,2,2)])
cm=Model({"n":3,"directed":[[0,1],[1,2]],"bidirected":[[0,1]],"privateK":[1,1,1],"latentK":[1]})
try:identify({1,2},{0},cm.law(),cm.g);joint=True
except Failure:joint=False
cp=idc({2},{0},{1},cm.law(),cm.g)
cc=sum(cp.a[v]==conditional(cm.law(1,v),4,v,2) for v in range(8))
yg=NxMixedGraph.from_edges(nodes=[Variable("X"),Variable("Z"),Variable("Y")],
    directed=[(Variable("X"),Variable("Z")),(Variable("Z"),Variable("Y"))],
    undirected=[(Variable("X"),Variable("Z"))])
assert identify_outcomes(yg,treatments={Variable("X")},outcomes={Variable("Y")},conditions={Variable("Z")}) is not None
exact("conditional_without_joint",[joint,True,cc,cp.a[6],cp.a[4]])
chain=Model({"n":2,"directed":[[0,1]],"bidirected":[],"privateK":[2,1],"latentK":[]})
rep=replacement(chain.law(),0,1,[1,0]);truth=chain.law(1,1)
exact("non_topological_replacement",[mass(rep.a,2,2),mass(truth.a,2,2),tv(rep,truth)])
selection=Model({"n":3,"directed":[[0,2],[1,2]],"bidirected":[],"privateK":[2,2,1],"latentK":[]})
exact("later_selection",[conditional(selection.law(),1,5,4),conditional(selection.law(2,0),1,5,4)])
exact("rational_interior",[F(5,13),1,F(4,5)])
exact("repeat_counterexample",[0,1,F(-1,100),F(51,100),F(1,4)])
exact("compatibility_relaxation",[F(1,5),F(2,5),F(1,5),F(3,5),F(1,5),F(4,5)])
exact("sequential_tv_bound",[1-(1-F(1,10))*(1-F(1,5)),F(1,10)+F(1,5)])

clock_records=json.loads((data/"clocks.json").read_text())
pair_count=certified=wrong=text_wrong=consistent=0;orig_width=tight_width=F(0)
for record in clock_records:
    truth=[F(0)]+list(map(F,record["truth"]));n=len(truth)
    d=[[None]*n for _ in range(n)]
    for i in range(n):d[i][i]=F(0)
    edges=[(i,j,F(c)) for i,j,c in record["constraints"]]
    for i,j,c in edges:
        assert truth[j]-truth[i]<=c
        if d[i][j] is None or c<d[i][j]:d[i][j]=c
        if i==0 or j==0:orig_width+=c
    for k in range(n):
        for i in range(n):
            for j in range(n):
                if d[i][k] is not None and d[k][j] is not None:
                    new=d[i][k]+d[k][j]
                    if d[i][j] is None or new<d[i][j]:d[i][j]=new
    consistent+=all(d[i][i]>=0 for i in range(n))
    for i in range(1,n):tight_width+=d[0][i]+d[i][0]
    rank={v:i for i,v in enumerate(record["textOrder"])}
    for i,j in itertools.combinations(range(1,n),2):
        pair_count+=1
        if -d[j][i]>0:certified+=1;wrong+=not(truth[i]<truth[j])
        text_wrong+=rank[i-1]>rank[j-1]
    for i,j in itertools.permutations(range(1,n),2):
        if -d[j][i]>0:assert truth[i]<truth[j]
row=cs["clock_certificates"]
check("clock_certificates",list(map(int,row[:6]))==[len(clock_records),consistent,pair_count,certified,wrong,text_wrong]
      and abs(float(row[6])-float(orig_width/(len(clock_records)*6)))<1e-14
      and abs(float(row[7])-float(tight_width/(len(clock_records)*6)))<1e-14)

class Interval:
    def __init__(self,lo,hi=None):self.lo=F(lo);self.hi=F(lo if hi is None else hi)
    def __add__(self,o):
        if not isinstance(o,Interval):o=Interval(o)
        return Interval(self.lo+o.lo,self.hi+o.hi)
    __radd__=__add__
    def __neg__(self):return Interval(-self.hi,-self.lo)
    def __sub__(self,o):return self+(-o if isinstance(o,Interval) else -F(o))
    def __rsub__(self,o):return Interval(o)+(-self)
    def __mul__(self,o):
        if not isinstance(o,Interval):o=Interval(o)
        a=[x*y for x in [self.lo,self.hi] for y in [o.lo,o.hi]];return Interval(min(a),max(a))
    __rmul__=__mul__
    def __truediv__(self,o):
        assert not o.lo<=0<=o.hi
        a=[x/y for x in [self.lo,self.hi] for y in [o.lo,o.hi]];return Interval(min(a),max(a))
    def endpoints(self):return self.lo,self.hi
    def width(self):return self.hi-self.lo
def fd(a):
    # Explicit mixture over latent treatment propensity and mediator, rather than nested C# evaluation.
    return sum((([1-a[0],a[0]][u])*([1-a[1],a[1]][z])*a[2+u+2*z]
                for u,z in itertools.product(range(2),repeat=2)),F(0))
def fdi(a,form):
    p,r,a0,a1,b0,b1=a[:6]
    if form==0:return (1-r)*((1-p)*a0+p*a1)+r*((1-p)*b0+p*b1)
    if form==1:return (1-r)*(1-p)*a0+(1-r)*p*a1+r*(1-p)*b0+r*p*b1
    return (1-p)*((1-r)*a0+r*b0)+p*((1-r)*a1+r*b1)
def corners(lo,hi):return ([hi[i] if b else lo[i] for i,b in enumerate(bits)] for bits in itertools.product((0,1),repeat=len(lo)))
def outer_check(got,ideal):
    lo,hi=map(float,got)
    return F(lo)<=ideal.lo and ideal.hi<=F(hi) and hi-lo-float(ideal.width())<=1e-12*max(1,abs(float(ideal.width())))
prec=json.loads((data/"precision.json").read_text());fratios=[];cratios=[]
fpass=cpass=sharp=same=0
for r in prec:
    lo,hi=list(map(F,r["lo"])),list(map(F,r["hi"]));ivs=[Interval(a,b) for a,b in zip(lo,hi)]
    fv=[fd(a) for a in corners(lo[:6],hi[:6])];fmin,fmax=min(fv),max(fv)
    assert [fmin,fmax]==list(map(F,r["exact"]))
    forms=[fdi(ivs,k) for k in range(3)];same+=len({x.endpoints() for x in forms})==1
    assert forms[0].endpoints()==tuple(map(F,r["naive"]))
    fpass+=outer_check(r["outer"],forms[0])
    lows=[fd([p,z]+lo[2:6]) for p,z in itertools.product((lo[0],hi[0]),(lo[1],hi[1]))]
    highs=[fd([p,z]+hi[2:6]) for p,z in itertools.product((lo[0],hi[0]),(lo[1],hi[1]))]
    sharp+=(min(lows),max(highs))==(fmin,fmax)
    def selected(a):
        f=fd(a);return f*a[7]/(f*a[7]+(1-f)*a[6])
    vals=[selected(a) for a in corners(lo,hi)];smin,smax=min(vals),max(vals)
    assert [smin,smax]==list(map(F,r["conditionalExact"]))
    ci=forms[0]*ivs[7]/(forms[0]*ivs[7]+(1-forms[0])*ivs[6])
    assert ci.endpoints()==tuple(map(F,r["conditionalNaive"]))
    cpass+=outer_check(r["conditionalOuter"],ci) and smin==fmin*lo[7]/(fmin*lo[7]+(1-fmin)*hi[6]) and smax==fmax*hi[7]/(fmax*hi[7]+(1-fmax)*lo[6])
    fratios.append(float(forms[0].width()/(fmax-fmin)));cratios.append(float(ci.width()/(smax-smin)))
exact("credal_checks",[len(prec),fpass,cpass,sharp,same,2**6,2**8])
expected=[statistics.median(fratios),max(fratios),statistics.median(cratios),max(cratios)]
check("credal_width_ratios",all(abs(float(a)-b)<1e-12 for a,b in zip(cs["credal_width_ratios"],expected)))
q=sp.symbols("q0:8")
f=(1-q[1])*((1-q[0])*q[2]+q[0]*q[3])+q[1]*((1-q[0])*q[4]+q[0]*q[5])
num=f*q[7];den=num+(1-f)*q[6]
degrees=[max(sp.Poly(p,q).degree(x) for x in q) for p in (f,num,den)]
exact("multi_affine_certificate",degrees)
assert set(cs)=={r["name"] for r in checks},set(cs)-{r["name"] for r in checks}
result={"all_passed":all(r["passed"] for r in checks),"summary_lines":len(cs),"checks":checks,
        "external_y0_version":"0.2.11","external_id_decisions":external_agree,"external_id_agreements":external_agree,
        "external_conditional_decisions":1,"random_models":len(models)-len(names),"id_queries":len(queries),
        "identified_queries":identified_count,"unidentified_queries":fail_count,"formula_assignments":assignments,
        "prefix_graph_cases":graph_count,"prefix_graph_certificates":cert_count,
        "licensed_rule_bindings":sum(licensed),"probability_identity_assignments":8*sum(licensed),
        "clock_certified_fraction":certified/pair_count,"clock_text_false_fraction":text_wrong/pair_count,
        "credal_fd_median_ratio":statistics.median(fratios),"credal_conditional_median_ratio":statistics.median(cratios),
        "python":sys.version.split()[0],"sympy":sp.__version__}
(P/"validation_results.json").write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!="checks"},indent=2))
