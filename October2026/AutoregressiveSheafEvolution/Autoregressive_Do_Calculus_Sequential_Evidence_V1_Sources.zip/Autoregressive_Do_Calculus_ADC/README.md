# Autoregressive Do Calculus (ADC)

Companion sources for the paper by Debi Prasad Ghosh, 30 October 2026.

## Files

- `kernel/`: .NET 8 project with exact rational structural models, graph tests, ID/IDC, interval clocks and interval precision studies.
- `validate_adc.py`: independent exact Python simulator and validator; y0 is an additional identification-decision oracle.
- `cs_results.txt`: 21 tab-separated output records, all independently checked.
- `output/`: complete model specifications, query results and traces, exhaustive graph cases, clock constraints and precision boxes.
- `validation_results.json`: every summary-line comparison and aggregate counts.
- `replay.py`, `replay_results.json`: isolated fresh-build byte comparison, including SHA-256 hashes.
- `paper.md`, `paper_filled.md`, `build_adc.py`: manuscript, resolved manuscript and Word builder.
- `figures/`: the two scientific figures generated from the definitions and results.
- `document_audit.json`: XML/ZIP checks, native-equation counts and statement inventory.
- `PROJECT_NOTE.md`: mathematical corrections, completed checks and open comparisons.
- `proposal.txt`: the initial proposal for historical context; the final paper supersedes its unproved and corrected claims.

## Reproduce the numerical suite

Use a .NET 8 SDK and Python 3.12. The verified versions are SDK 8.0.427,
runtime 8.0.33, Python 3.12.14, SymPy 1.14.0 and y0 0.2.11.
Install the pinned validation dependencies in an isolated Python environment:

```bash
python -m pip install -r requirements_validation.txt
dotnet build kernel/Adc.csproj -c Release
dotnet kernel/bin/Release/net8.0/Adc.dll output > cs_results.txt
python validate_adc.py
```

The C# project uses no third-party NuGet packages. `nuget.config` clears package
feeds because the installed .NET 8 reference packs are sufficient. The summary
and JSON/CSV files are deterministic. The three SplitMix64 seeds are
20261030041 (models), 20261030042 (clocks) and 20261030043 (credal boxes).

To build again in a fresh temporary directory and compare the generated files:

```bash
python replay.py
```

`ADC_DOTNET` may name an absolute path to the .NET executable when it is not on
PATH. The replay first checks every file; a platform process-stat failure in
`dotnet --version` can be handled by recording the sole installed SDK directory.
That version-query fallback does not change the mathematical replay.

Exact equalities have zero tolerance. Interval endpoints are converted back to
exact Python fractions for containment. Their width excess over ideal interval
evaluation is limited to `1e-12 * max(1, ideal_width)`. The validator independently
recomputes all 21 summary records, all 449 joint decisions, the conditional-only
example, and all 65,632 reported identified-formula evaluations.

## Build the Word paper

After the numerical validation and replay pass, install the additional packages
in `requirements_document.txt`. Pandoc 3.1.3 was used. A system installation of
Pandoc is required:

```bash
python build_adc.py
```

This creates `deliverables/Autoregressive_Do_Calculus_ADC.docx`, with native Word
equations and four result tables. The builder checks XML well-formedness and ZIP
integrity; it does not claim complete OOXML schema validation.

The supplied Word paper was also rendered in LibreOffice and every page was
visually reviewed. Rebuilding on different font/Office versions can change line
and page breaks; review the new render before distribution. The PDF is a
reading copy, and the Word file retains editable equations.

## Scope

These are finite mathematical checks, not transformer training experiments.
The current graph implementation accepts at most 12 events; the executed model
suite uses at most eight. No general hedge-witness-pair constructor is included.
The failure trace and the explicit positive bow witness are different
certificates. ID/IDC completeness is inherited from classical work, not a new
completeness theorem for arbitrary sheaves.

The namespace `Tcr` is retained from the corrected arithmetic and temporal
kernel of *Dependency Preserving Temporal Causal Computation* (Ghosh, 2026),
https://doi.org/10.13140/RG.2.2.33732.18568.
