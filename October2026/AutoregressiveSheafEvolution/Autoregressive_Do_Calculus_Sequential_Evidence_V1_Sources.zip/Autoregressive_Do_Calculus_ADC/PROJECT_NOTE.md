# Results and claim status

## Paper

Title: **Autoregressive Do Calculus (ADC)**  
Subtitle: **Clock certificates and credal precision for event generators**  
Date: 30 October 2026.

The paper distinguishes a genuine mechanism incidence sheaf from a marginal-law
presheaf. Stalks are data spaces. A token carries a vertical fibre diagram in
ASE; the physical clock, event generation order and inference depth remain
separate. The decoder proposition states an additional probabilistic commuting
condition rather than deriving intervention semantics from local agreement.

## Corrections to the initial proposal

1. Marginal laws need not glue uniquely, or at all. They are not automatically
   a sheaf. A model class indexing fixed-model sheaves is not the state-section
   space of a single mechanism sheaf.
2. Causal rules give typed equalities under graph premises, rather than literal
   identities between whole stalk spaces. A rule-only query path does not
   implement complete identification; probability algebra is necessary.
3. Complete conditional identification needs IDC, rather than joint ID followed
   only by normalization.
4. Strict clock order needs nonnegative directed lags. Strictly positive lags
   are unnecessary for that theorem. Outcomes and conditioning events must
   both precede the added action, and the clock is fixed across regimes.
5. The graph criterion for whole-continuation exchange is exactly “last in
   district.” It is a sufficient causal replacement certificate, not an iff
   test for equality in a particular parameterized model.
6. Separately affine ratios with positive denominators have product-vertex
   extrema. Arbitrary rational functions and repeated/tied polynomial
   parameters need not have this property.
7. Fewer repeated occurrences do not universally narrow a natural interval.
   Graph compatibility, parameter constraints and occurrence relaxation are
   separate issues.
8. The Gogioso–Pinzani 2021 preprint was withdrawn; the paper identifies that
   status and uses the subsequent input-history foundations.

## Completed checks

- 21 summary lines agree between C# and independent Python.
- 449 joint ID decisions: 438 identified, 11 failed; all external y0 decisions
  agree, and 65,632 identified-expression values agree with exact mechanism
  replacement.
- One conditional-only IDC example agrees with the independent code and y0.
- 16,384 ordered four-vertex prefix graph cases agree with the district test.
- 1,372 licensed rule bindings give 10,976 exact assignment comparisons.
- 128 consistent interval-clock narratives certify 1,552 of 1,920 true pair
  orders with no false certificate. Text order reverses 993 pairs; this is
  not a measured causal-answer error rate.
- 40 compatible front-door boxes and their selected-outcome extensions pass
  all exact endpoint and outward enclosure checks. Median natural/exact
  width ratios are approximately 2.261 and 3.283, respectively.
- A fresh isolated C# build reproduces every JSON/CSV file and summary record
  byte for byte. Hashes are in `replay_results.json`.

## Comparison outcomes

**C1:** The unrestricted repeat-count ranking is refuted by an exact
counterexample. The three positive front-door regroupings have identical ideal
interval bounds in all 40 boxes. The initial predicted halving of excess width
is not established. A normalized, graph-derived ranking remains a future
empirical question.

**C2:** Clock-order certification is checked. The predicted rate of forbidden
causal action deletions is untested because the current study measures event
pairs, not query-specific interventional equalities.

**C3:** No transformer was trained. The learned-model comparison remains a
conjecture, with a prespecified metric and refutation criterion in Section 9.5.
The exact replacement gap is an asymptotic benchmark under observational
consistency, not an unconditional finite-estimation error floor.

## Limits

The supplied causal graph and event semantics are assumptions. There is no
causal discovery from prose, arbitrary feedback model, generic rational
hedge-witness construction, neural performance comparison, or full formal
verification of the C# implementation. Numerical and graphical checks support
the declared finite suite. Vertex enumeration is exponential in general.
