"""Build in an isolated directory and compare every generated result byte for byte."""
from __future__ import annotations
import hashlib, json, os, shutil, subprocess, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
dotnet = os.environ.get("ADC_DOTNET", "dotnet")
env = dict(os.environ, DOTNET_CLI_TELEMETRY_OPTOUT="1")
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

with tempfile.TemporaryDirectory(prefix="adc_replay_") as td:
    td = Path(td)
    project = td / "kernel"
    project.mkdir()
    for p in (ROOT / "kernel").iterdir():
        if p.is_file():
            shutil.copy2(p, project / p.name)
    built = subprocess.run([dotnet, "build", str(project / "Adc.csproj"), "-c", "Release", "--verbosity", "minimal"],
                           env=env, capture_output=True, text=True, check=True)
    (ROOT / "replay_build.log").write_text(built.stdout + built.stderr)
    result = td / "results"
    result.mkdir()
    run = subprocess.run([dotnet, str(project / "bin/Release/net8.0/Adc.dll"), str(result)],
                         env=env, capture_output=True, check=True)
    (result / "cs_results.txt").write_bytes(run.stdout)
    assert not run.stderr, run.stderr
    names = ["clocks.json", "models.json", "id_queries.json", "prefix_graphs.csv", "precision.json"]
    records = []
    for name in names + ["cs_results.txt"]:
        original = ROOT / "cs_results.txt" if name == "cs_results.txt" else ROOT / "output" / name
        new = result / name
        records.append({"file": name, "bytes": original.stat().st_size,
                        "sha256": digest(original), "replay_sha256": digest(new),
                        "identical": original.read_bytes() == new.read_bytes()})
    assert all(r["identical"] for r in records)
    version = subprocess.run([dotnet, "--version"], env=env, capture_output=True, text=True)
    if version.returncode == 0:
        sdk = version.stdout.strip()
        sdk_source = "dotnet --version"
    else:
        installed = [p.name for p in (Path(dotnet).resolve().parent / "sdk").iterdir() if p.is_dir()]
        assert len(installed) == 1, (version.stderr, installed)
        sdk = installed[0]
        sdk_source = "sole installed SDK directory; version query encountered a process-stat error"
    report = {"all_identical": True, "method": "isolated fresh project build and deterministic execution",
              "sdk": sdk, "sdk_source": sdk_source,
              "files": records}
    (ROOT / "replay_results.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
