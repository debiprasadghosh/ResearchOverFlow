---
title: Autoregressive Do Calculus (ADC)
subtitle: Clock certificates and credal precision for event generators
author: Debi Prasad Ghosh
date: 30 October 2026
---

Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India

## Abstract

Autoregressive models provide observational conditionals, whereas a causal intervention replaces a mechanism. Autoregressive Do Calculus (ADC) is a finite framework for compiling the latter into computations using the former. It combines classical do-calculus and identification with a mechanism sheaf, an explicitly separate presheaf of probability laws, interval clocks and credal uncertainty. The distinction matters: compatible marginal laws need not glue uniquely, and a graph of rule rewrites alone does not implement identification. We give a typed derivation semantics and inherit identification completeness from ID and IDC under their classical assumptions. Three developments concern execution. First, a clock certificate licenses deletion of an action from a strictly earlier joint event and its conditioning context; nonnegative directed lags suffice, so strictly positive lags are unnecessary for this case. Second, for a topological generation order, exchanging a clamped event with observation is graphically certified for the entire continuation exactly when its district has no later member. This yields a sufficient condition for token replacement to equal intervention and a bound separating structural replacement error from conditional estimation error. Third, exact credal extrema occur at product vertices for separately affine expressions and for ratios with separately affine numerator and denominator and a positive denominator. We distinguish graph compatibility, parameter ties and occurrence relaxation. Exact C# and independent Python calculations agree on {{SUMMARY_LINES}} summary lines, {{ID_QUERIES}} joint identification decisions, {{GRAPH_CASES}} prefix graph cases and {{LICENSED_RULES}} licensed rule bindings. An external implementation agrees on every joint decision and the conditional example. The paper claims an execution discipline, not a new class of identifiable effects. Transformer training and comparative performance remain open.

**Keywords** autoregressive generation; do-calculus; causal identification; mechanism sheaves; interval clocks; credal sets; intervention; certified computation

# 1 Introduction

An autoregressive generator can evaluate a chain of conditionals accurately and still answer an intervention incorrectly. Conditioning asks what follows among cases in which an event has a value. An intervention asks what follows when the mechanism producing that event is replaced. A hidden common cause can make the two laws different even when the observational distribution is known exactly.

ADC connects event generation to an established intervention calculus. Its input is a declared event model or graph, an observational law, a query, and any clock or precision constraints to be used. Its output is an identified expression with a derivation and an enclosure, or a qualified failure result. It does not discover causal arrows from the order of text, infer an exogenous law from local agreement, or treat a language-model token as a causal variable without a semantic map.

The horizontal structure supplies local mechanism contexts and shared variable identities. The autoregressive order supplies computational factors. A physical clock restricts possible ancestry. An interval describes admissible values rather than a probability of error. These objects interact through stated maps and hypotheses. Their distinction is the central design choice of ADC.

## 1.1 Literature survey

Pearl's calculus supplies the three graphical transformations of interventional probabilities (Pearl, 1995, 2009). Tian and Pearl (2002) identify district factors as products of observational conditionals in a topological order. Shpitser and Pearl give complete algorithms for joint and conditional interventional identification (2006a, 2006b). ADC uses those results with attribution. Its term calculus refers to a typed execution of them.

A categorical or sheaf reformulation is already part of the literature. Jacobs et al. (2019) distinguish string-diagram syntax from stochastic semantics and represent intervention by surgery. Fritz and Klingler (2023) establish a categorical d-separation criterion. Mahadevan's regime-indexed formulation applies chartwise causal rules and descends compatible equalities under explicit restriction and sheaf assumptions; the current revision makes no general identification-completeness claim for arbitrary sites (Mahadevan, 2025, revised 2026). These precedents preclude a claim that placing do-calculus beside sheaves is itself new.

Yvernes et al. (2026) characterize the equivalence of observational and interventional probability expressions through derivation graphs and give a procedure using at most four rule applications for that equivalence problem. Equivalence of such probability expressions and construction of an identification formula are distinct tasks. The latter also uses marginalization, products and conditioning. Section 4 supplies a finite example where an identified query has no rule-only route to an observational query with the same outcome.

The 2021 Gogioso–Pinzani paper cited in the proposal was withdrawn. Its withdrawal notice replaces its locale-of-inputs construction with spaces of input histories. We therefore use the later combinatorial and topological treatments as the relevant foundations for causal histories (Gogioso & Pinzani, 2022, 2023). The withdrawn paper is a historical reference, not a premise of any result below.

Ghosh (2026) separates mechanism relations, shared-circumstance counterfactuals, physical clocks, inference layers and interval dependencies. ADC extends that finite setting to general interventional identification. Credal networks supply sets of admissible probability specifications (Cozman, 2000), while temporal constraint networks supply exact date and lag projections (Dechter et al., 1991). Our ratio-extremum argument uses the convex-weight principle underlying linear fractional programming (Charnes & Cooper, 1962). The possibility that compatible probability marginals fail to extend is fundamental to sheaf approaches to contextuality (Abramsky & Brandenburger, 2011).

## 1.2 Contribution and status

The contribution is a finite specification joining four requirements: causal derivations must be sound; a generator must justify replacing a mechanism by a clamp; clocks must certify any order used; and an uncertainty calculation must state which dependencies it retains. We prove the supporting propositions and distinguish inherited identification theorems from ADC's execution consequences. No literature-wide priority is claimed for their ingredients.

The most useful generator result is an exact characterization of its graphical exchange certificate. The most useful precision result extends vertex optimization to a certified class of ratios. Two proposed simplifications fail: marginal laws are not automatically a sheaf, and fewer repeated terms do not universally give a narrower interval. The paper records those failures rather than making them assumptions.

The numerical material consists of finite mathematical checks. It includes an independent exogenous-state simulator, a separate ID implementation, direct m-active-path enumeration and an external identification oracle. It contains no trained transformer and supplies no evidence of a learned-system performance advantage.

## 1.3 Structure

Section 2 defines the model and query types. Section 3 separates the mechanism sheaf from the law presheaf. Sections 4 and 5 develop certified derivations and autoregressive identification factors. Sections 6 and 7 treat clocks and generator interventions. Section 8 establishes credal precision results. Section 9 reports the finite checks and the status of the proposed comparisons. Section 10 concludes. Appendix A lists assumptions, and Appendix B specifies the reference kernel and reproduction record.

# 2 Finite models and typed queries

**Definition 2.1 (finite semi-Markovian event model).** Let $V=\{V_1,\ldots,V_n\}$ have finite state spaces. The directed part of $G$ is acyclic. A private exogenous variable may enter one mechanism, and a shared exogenous variable may enter the two endpoints of a bidirected edge. The exogenous primitives are mutually independent. A model $M$ fixes their laws and total functions

$$
V_i=f_i(V_{\operatorname{pa}(i)},U_i).
\qquad\text{(2.1)}
$$

The notation $U_i$ denotes all primitive exogenous inputs of that mechanism; the same primitive can occur in two such lists. A bidirected edge represents a possible hidden common cause, not mutual directed causation. Mechanisms may ignore inputs, so faithfulness is not assumed. A generation order $\pi$ is a permutation of the events. It is topological when every directed parent occurs earlier.

For $X\subseteq V$, a perfect intervention $\operatorname{do}(X=x)$ replaces $f_i$ by the constant $x_i$ at its targets. Other mechanisms, variable meanings and exogenous laws are retained. In an ADMG, $G_{\bar X}$ removes incoming directed edges and bidirected edges incident to $X$. The graph $G_{\underline Z}$ removes outgoing directed edges from $Z$. Separation in an ADMG means m-separation, equivalently d-separation in its explicit latent-parent expansion.

**Lemma 2.2 (existence and coupling).** For a fixed exogenous assignment and intervention, a finite acyclic model has one endogenous solution. Two regimes retaining the exogenous primitives can be evaluated on the same assignment.

*Proof.* Visit nodes in topological order. A target is assigned its clamp; every other node has all parent values available and its total function supplies one value. Induction proves existence and uniqueness. Reusing the exogenous assignment supplies the stated coupling. ∎

**Definition 2.3 (query type).** A query is a disjoint triple $(Y,X,C)$ with a family of values $(y,x,c)$ and evaluation

$$
q^M_{Y;X\mid C}(y;x,c)
=P_M(Y=y\mid\operatorname{do}(X=x),C=c).
\qquad\text{(2.2)}
$$

An action parameter and an observed condition occupy different fields. A query is observational when $X=\varnothing$. A conditional query also records the event whose probability normalizes it. Empty or uncertified normalizing mass is a domain failure, not a numerical value.

We assume a strictly positive observational joint law when using unrestricted tabular conditionals. This assumption has a useful finite consequence.

**Lemma 2.4 (support after a perfect intervention).** If $P_M(v)>0$ for every observed joint assignment, then every assignment of the non-target events has positive probability under every perfect intervention.

*Proof.* Exogenous states that naturally generate $(X=x,V\smallsetminus X=v)$ still generate $v$ after clamping $X=x$, by Lemma 2.2. Their set is included in the intervened event. Therefore

$$
P_M(v\mid\operatorname{do}(x))\geq P_M(v,x)>0.
\qquad\text{(2.3)}
$$

Marginalization gives positive mass to every non-target conditioning assignment. ∎

A known positive law at one parameter value does not certify positivity throughout an uncertainty set. Section 8 separately requires positive denominators on the whole set being optimized.

# 3 Mechanism sheaves and law presheaves

## 3.1 A genuine horizontal sheaf

**Definition 3.1 (mechanism incidence sheaf).** For a fixed $M$, introduce a context point $c_i$ for each mechanism and a point for every endogenous or exogenous variable. Put $c_i\leq a$ when variable $a$ occurs in that complete mechanism scope. On the Alexandrov topology of upward closed sets, assign the relation

$$
R_i^M=\{(v_i,v_{\operatorname{pa}(i)},u_i):
v_i=f_i(v_{\operatorname{pa}(i)},u_i)\}
\qquad\text{(3.1)}
$$

to $c_i$, the appropriate state space to each variable point, and coordinate projections to the incidence arrows. Sections are compatible tuples. This defines a sheaf of sets, denoted $\mathcal S_M$.

**Proposition 3.2 (state gluing).** Global sections of $\mathcal S_M$ are exactly the complete state assignments satisfying every mechanism. Replacing target relations gives the intervened solution sheaf.

*Proof.* Projection agreement identifies every entry of a context tuple with its shared variable value. Membership in $R_i^M$ is precisely its mechanism equation. Conversely, a solution fills each tuple and all its projections consistently. Gluing on open covers is componentwise union and is unique. Replacing a relation implements the clamp of Lemma 2.2. ∎

Stalks are data spaces. A token is an inference state, not a stalk. The probability law on exogenous states is additional model information. State gluing does not infer that law or a causal mechanism from an observational marginal.

## 3.2 Probability marginalization has weaker gluing

For a fixed action set $X$, define a presheaf on outcome subsets by

$$
\mathcal L^X(A)
=\operatorname{Ker}\!\left(\mathcal X_X,\Delta(\mathcal X_A)\right),
\quad A\subseteq V\smallsetminus X,
\qquad\text{(3.2)}
$$

with pointwise marginalization as restriction. Here $\mathcal X_A$ is the product state space and $\Delta$ its probability simplex. A model supplies one compatible family of interventional marginals. Changing a conditioning set requires joint masses and normalization; it is not an outcome marginalization map.

**Proposition 3.3 (marginal laws need not form a sheaf).** Under covers by variable subsets, compatible probability marginals can have multiple joint extensions or no joint extension.

*Proof.* Uniform binary marginals for $A$ and $B$ extend both to independent fair bits and to $A=B$ with a fair common value. Thus uniqueness fails. For nonexistence, take uniform binary pair laws satisfying $A=B$, $B=C$ and $A\ne C$ on the three pair contexts. They agree on every singleton overlap, but the three relations cannot hold in one joint assignment. Hence no joint law realizes them all. ∎

ADC therefore keeps $\mathcal S_M$ and $\mathcal L^X$ separate. A conditional product or district factorization uses probabilistic assumptions in addition to overlap agreement. An unrestricted marginal presheaf cannot acquire a unique joint law merely by being called a sheaf.

## 3.3 Identification is a factorization on models

Let $\mathfrak M_G$ be the class of compatible models and let $\operatorname{obs}(M)=P_M(V)$. This is a model space indexing the family $\mathcal S_M$; it is not the state-section space of one fixed $\mathcal S_M$.

**Theorem 3.4 (identification and observational fibres).** A query evaluation $q$ is identified on $\mathfrak M_G$ exactly when it is constant on each fibre of $\operatorname{obs}$. Equivalently, there is a function $F$ on the attainable observational laws such that

$$
q=F\circ\operatorname{obs}.
\qquad\text{(3.3)}
$$

*Proof.* A factorization gives equal query values whenever the observational laws are equal. Conversely, define $F(p)$ to be $q(M)$ for any model with $\operatorname{obs}(M)=p$. Constancy on the fibre makes this well defined. ∎

Two exact models with the same observational law and different target values refute such a factorization. This is a semantic witness. A graphical non-identification result and an explicitly supplied pair of models are different forms of certificate; an implementation should state which it carries.

## 3.4 Relation to ASE

ASE's latent cover base, variable context base, inference layer order and observation star remain distinct. The incidence space above models variable contexts. Physical time labels events; the generation order lists event variables; the evaluation order of a proof program lists arithmetic operations. None is the inference depth of ASE.

When a representation changes base, the old sheaf on the new base is $\Phi_\ell^{-1}\mathcal S_\ell$, and a coefficient update must commute with restrictions. A token carries its vertical fibre diagram through such changes. ADC additionally requires any event decoder to preserve the meanings of clamps and observations. Units and coordinate meanings are declared before residuals or clock comparisons. Probability coordinates are dimensionless; clock constraints use one declared time unit.

# 4 Rules and certified derivations

## 4.1 The three inherited causal identities

Let $Y,X,Z,W$ be pairwise disjoint. Conditional equalities below are asserted on their defined support. The three rules retain their classical graph premises.

**Lemma 4.1 (observation insertion or deletion).** If $(Y\perp Z\mid X,W)_{G_{\bar X}}$, then

$$
P(y\mid\operatorname{do}(x),z,w)
=P(y\mid\operatorname{do}(x),w).
\qquad\text{(4.1)}
$$

*Proof.* The intervened model is Markov to its mutilated latent DAG. The separation premise gives conditional independence in that regime. Conditioning on fixed targets $X=x$ is redundant, yielding the equality. This is Pearl's first rule. ∎

**Lemma 4.2 (action and observation exchange).** If $(Y\perp Z\mid X,W)_{G_{\bar X,\underline Z}}$, then

$$
P(y\mid\operatorname{do}(x,z),w)
=P(y\mid\operatorname{do}(x),z,w).
\qquad\text{(4.2)}
$$

*Proof.* Introduce independent regime indicators that select the ordinary mechanism or the clamp at $Z$. When $Z$ is conditioned on, an active path from an indicator must leave its target through an incoming arrow: otherwise that conditioned target is a blocking noncollider. Such paths are exactly the potential back-door connections tested after outgoing arrows from $Z$ are removed. The stated separation blocks them. Thus the conditional law of $Y$ given $X,Z,W$ is invariant between the observational and clamped regimes. In the latter, $Z=z$ is fixed, giving (4.2). This is the standard regime-indicator proof of Pearl's second rule. ∎

**Lemma 4.3 (action insertion or deletion).** Define $Z(W)=Z\smallsetminus\operatorname{An}_{G_{\bar X}}(W)$. If $(Y\perp Z\mid X,W)_{G_{\bar X,\overline{Z(W)}}}$, then

$$
P(y\mid\operatorname{do}(x,z),w)
=P(y\mid\operatorname{do}(x),w).
\qquad\text{(4.3)}
$$

*Proof.* Use the same regime indicators without conditioning on $Z$. For a target outside the ancestors of $W$, a collider at that target cannot be activated by $W$; incoming arrows there may therefore be removed in the separation test. Targets ancestral to $W$ retain their incoming arrows because selection through $W$ can matter. Any remaining active indicator-to-$Y$ path would yield an active path from a member of $Z$ to $Y$ in the displayed mutilated graph, by starting after the last removed incoming arrow if necessary. The premise excludes it. Invariance to the indicators proves the equality. This is Pearl's third rule, with its ancestor exception retained. ∎

These lemmas invoke classical causal soundness, not a new topos axiom. Their kernels and conditioning operations must be defined. Sheaf restriction does not erase their graph hypotheses.

## 4.2 A derivation needs probability algebra

**Definition 4.4 (ADC proof program).** An ADC program is a finite directed acyclic expression graph with typed kernels as values. Its leaves are observational laws or observational conditionals derived by certified normalization. Internal nodes perform a recorded application of Lemmas 4.1–4.3, marginalization, a justified conditional product, or division by a positive normalizing mass. A rule node carries its graph, mutilation, disjoint query sets and separation certificate. Bound variables and fixed action parameters are recorded explicitly.

A product node is justified by a chain rule, district factorization or another proved equality. It cannot turn unrelated marginals into a joint law. Reuse of a node preserves the identity of its parameters. A numerical interval relaxation may later forget that identity, but the proof program itself does not.

**Theorem 4.5 (program soundness).** If every leaf and node has its declared semantics and every graph and denominator premise holds, the program's output equals its stated causal query in every compatible model.

*Proof.* Induct over an evaluation order of the expression graph. Observational leaves have their declared values. Each causal rewrite preserves evaluation by Lemmas 4.1–4.3. Probability nodes preserve evaluation by their stated marginalization, product or conditioning identities. The output therefore equals the query. If all leaves are observational, its evaluation factors through $\operatorname{obs}$ as in Theorem 3.4. ∎

**Proposition 4.6 (a rule-only graph is insufficient).** A query can be identified even though no path of the three causal rules alone reaches an observational query with that fixed outcome.

*Proof.* In the front-door graph $X\to Z\to Y$, $X\leftrightarrow Y$, start with $P(y\mid\operatorname{do}(x))$. Rule 2 cannot exchange $X$ because the bidirected path to $Y$ remains. Rule 1 cannot insert $Z$ because $Z\to Y$ remains active. Rule 3 cannot insert $Z$ for the same reason, or delete $X$ because its directed path to $Y$ remains. No initial rule-only move is licensed. Nevertheless the front-door expression

$$
\sum_z P(z\mid x)\sum_{x'}P(y\mid x',z)P(x')
\qquad\text{(4.4)}
$$

identifies the query. The finite rule graph has {{RULE_PATH_STATES}} reachable query and no observational endpoint, while ID returns a valid expression. The sums and products in (4.4) supply operations absent from that graph. ∎

This corrects the proposed identification-as-a-path statement. A hypergraph of certified expressions or an expression DAG is sufficient syntax. The equivalence problem studied by Yvernes et al. (2026) can help choose equivalent starting queries, while ID or IDC performs identification.

# 5 Autoregressive factors and identification

## 5.1 District kernels

For a topological order, write $H_i=\{V_1,\ldots,V_{i-1}\}$ and $p_i=P(v_i\mid h_i)$. A district is a connected component of the bidirected part of $G$.

**Theorem 5.1 (district factorization, Tian and Pearl).** For every district $D$,

$$
Q[D](v)=P_{V\smallsetminus D}(v_D)
=\prod_{i:V_i\in D}p_i(v_i\mid h_i).
\qquad\text{(5.1)}
$$

The joint law is the product of these district kernels: $P(v)=\prod_{D\in\mathcal D(G)}Q[D](v)$.

*Proof.* With external observed values held fixed, group the latent-variable factorization by districts. A shared exogenous primitive has both observed endpoints in one district, so the exogenous sums separate across those groups. Their product is $P(v)$. To recover a group's factors observationally, eliminate variables from the end of the topological order. At the final variable, summation normalizes its mechanism and its remaining district factor becomes the product of the corresponding factors in the preceding marginal. Dividing the full-prefix marginal by that preceding marginal gives $p_i$. Induction assigns each such conditional to its district and proves the first equality. This is the finite c-factor argument of Tian and Pearl (2002). ∎

An autoregressive model computes the $p_i$. Their causal use depends on the graph and order, rather than on the generator architecture. In recursive identification, the current kernel can already represent an intervention. Its prefix factors are then ratios of marginals of that current kernel. Reusing the original observational conditionals after changing the kernel is an incorrect shortcut.

## 5.2 Classical completeness and its scope

**Theorem 5.2 (inherited identification completeness).** In the nonparametric recursive semi-Markovian setting, ID identifies every identifiable joint interventional query. IDC supplies the corresponding complete conditional-query procedure. Their soundness and completeness are the classical results of Shpitser and Pearl (2006a, 2006b).

The reference implementation follows these algorithms. ID removes irrelevant ancestors, adds actions on irrelevant remaining variables, separates districts, extracts a district kernel or recurses within a larger district. Its failure record retains the active graph and district. IDC first tries Rule 2 to transfer conditioning variables to actions; otherwise it identifies the required joint and normalizes it.

Conditional identification is more general than identifying a joint and taking its ratio. For $X\to Z\to Y$ with $X\leftrightarrow Z$, the joint $P_x(z,y)$ is not generally identified, but

$$
P_x(y\mid z)=P(y\mid z).
\qquad\text{(5.2)}
$$

Rule 2 moves $Z$ to an action, after which the mechanism of $Y$ is identified. The kernel and external oracle verify this example. Theorem 5.2 is invoked rather than reproved; ADC claims no enlargement of its identifiable-query class.

## 5.3 A carried non-identification witness

**Proposition 5.3 (a positive rational bow witness).** There are two binary models compatible with $X\to Y$, $X\leftrightarrow Y$, whose observational laws agree and are strictly positive, but whose intervention laws differ.

*Proof.* Let $U,N$ be independent fair bits and set $X=U$. In model A, put $Y=N$. In model B, put $Y=N$ when $X=U$, and $Y=X$ otherwise. Naturally $X=U$, so both observational laws assign $1/4$ to each $(x,y)$. Under $\operatorname{do}(X=1)$, model A has $P(Y=1)=1/2$. In B, half the exogenous states have $U=1$ and retain fair $N$; the other half have $U=0$ and produce $Y=1$. Its probability is $3/4$. Under $\operatorname{do}(X=0)$ the corresponding probabilities are $1/2$ and $1/4$. Theorem 3.4 proves non-identification. ∎

A graph's arrows describe allowed inputs, so model A may ignore them. This construction uses no faithfulness assumption. The complete hedge theorem provides general graphical obstructions. The present kernel carries an ID failure trace for each failed query and an explicit model pair for this example; it does not claim to generate a rational witness pair for every possible hedge.

# 6 Clock certificates

## 6.1 No retroactive change to an earlier joint context

The clock is fixed across regimes. Clamping an event value does not reschedule events. Suppose each permitted causal edge $i\to j$ obeys $\tau_j-\tau_i\geq d_{ij}\geq0$. Event dates and lag constraints are measured in a common unit. Exogenous common causes remain admissible; the hypothesis constrains directed ancestry.

**Theorem 6.1 (clocked prefix invariance).** Let $Y,X,C,A$ be disjoint. Suppose every event in $Y\cup C$ is strictly earlier than every event in $A$. In every model satisfying the clock hypothesis,

$$
\begin{aligned}
P(y,c\mid\operatorname{do}(x,a))
&=P(y,c\mid\operatorname{do}(x)),\\
P(y\mid\operatorname{do}(x,a),c)
&=P(y\mid\operatorname{do}(x),c).
\end{aligned}
\qquad\text{(6.1)}
$$

*Proof.* A directed path from $A$ to $Y\cup C$ would have nonnegative total lag and would make its endpoint no earlier than its starting point, contradicting the strict order. Thus no target in $A$ is an ancestor of $Y\cup C$. Couple the two regimes using the same exogenous assignment and the same clamps on $X$. Topological induction on ancestors of $Y\cup C$ gives identical values in both regimes. Their joint laws agree. Marginalize to $C$ and divide by its positive mass to obtain the conditional equality. ∎

The proof permits zero-lag edges. Positive minimum lags are stronger than necessary when the compared events are strictly ordered. Bidirected edges do not invalidate the argument: a perfect intervention leaves the common exogenous circumstances fixed.

**Proposition 6.2 (later conditioning can invalidate deletion).** Earlier outcomes alone do not justify deleting an action from a conditional query.

*Proof.* Let $Y,W$ be independent fair bits, and let $S=Y\oplus W\oplus N$, where $N$ is an independent Bernoulli bit with probability $1/4$. Give the events times $\tau_Y<\tau_W<\tau_S$. Then $P(Y=1\mid S=1)=1/2$, whereas $P(Y=1\mid\operatorname{do}(W=0),S=1)=3/4$. The earlier marginal of $Y$ is invariant; selecting the later event $S$ changes the conditional question. ∎

If equal-time comparisons are admitted, zero-lag edges require care. A zero-lag edge $W\to Y$ can connect simultaneous events and a clamp can change $Y$. Strict query order in Theorem 6.1 avoids that case. With strictly positive directed lags, even a certified equality of times excludes directed ancestry between those events.

## 6.2 Finite date resolution

Write clock constraints as $\tau_j-\tau_i\leq c_{ij}$, with origin $\tau_0=0$. Finite lower and upper dates connect every event to the origin. In a consistent network, shortest-path distances give exact attainable bounds (Dechter et al., 1991):

$$
\tau_v\in[-d(v,0),d(0,v)],
\qquad
\tau_b-\tau_a\geq-d(b,a).
\qquad\text{(6.2)}
$$

**Corollary 6.3 (certified action deletion).** If the clock network is consistent and $-d(a,b)>0$ for every $b\in Y\cup C$, $a\in A$, then (6.1) holds for every compatible clock and every compatible causal model respecting nonnegative directed lags.

*Proof.* Equation (6.2) bounds $\tau_a-\tau_b$ from below by $-d(a,b)$. All required strict orders therefore hold throughout the feasible clock set. Apply Theorem 6.1 pointwise in that set. ∎

A negative cycle means the declared clock constraints are inconsistent. Failure to certify an order means that this clock argument is inconclusive; a graph-based rule can still justify deletion. For a fixed, complete causal graph, ancestry and do-calculus already decide the relevant causal premise. Clocks do not create a new class of identifiable effects. Their added role is a checkable order certificate, especially across a family of partially specified graphs that must all respect the same clock constraints.

Year and month reports are represented by closed hulls of their periods. This is a conservative convention for non-strict difference constraints and can leave endpoint distinctions undecided. Text order supplies no substitute for a missing clock certificate.

# 7 When event replacement is intervention

## 7.1 The whole prefix matters

Fix a positive observational law and a topological order, relabelled $V_1,\ldots,V_n$. An event generator emits one token per declared event variable. Let $S=V_s$, $H=\{V_i:i<s\}$ and $F=\{V_i:i>s\}$. Replacing the event at position $s$ by $a$ and continuing with the observational conditionals produces

$$
\widetilde p_a(h,s,f)
=p(h)\,\mathbf 1_{\{s=a\}}\,p(f\mid h,s=a).
\qquad\text{(7.1)}
$$

This law is defined by multiplying all non-clamped autoregressive factors. It is not, by definition, an interventional law.

**Theorem 7.1 (exact graphical exchange certificate).** In a topological order,

$$
(F\perp S\mid H)_{G_{\underline S}}
\quad\Longleftrightarrow\quad
\operatorname{district}_G(S)\subseteq H\cup\{S\}.
\qquad\text{(7.2)}
$$

Thus the entire continuation admits Rule 2 exchange precisely when the clamped event is the last member of its district in this order.

*Proof.* Suppose its district contains a future event. Choose a simple bidirected path from $S$ and stop at its first future vertex. Every internal vertex is earlier than $S$, hence belongs to $H$. Each is a collider on the path and is conditioned on. The path is m-active given $H$, so separation fails.

Conversely, suppose there is an m-active path from $S$ to some vertex in $F$ in $G_{\underline S}$. Stop at the first future vertex. All internal vertices belong to $H$ and must be colliders. The path cannot begin with $S\leftarrow h$: the earlier vertex $h$ would be a conditioned noncollider because that edge has a tail at $h$. Outgoing edges from $S$ have been removed, so the first edge is bidirected. At an earlier internal collider $h$, the next edge must have an arrowhead at $h$. It is either bidirected or $v\to h$. The latter would have an earlier $v$ by topological order, with a tail at $v$ on the path, making $v$ a conditioned noncollider. It is impossible on an active path. Induction makes every edge up to the first future vertex bidirected. That vertex belongs to the district of $S$, contradicting the right-hand condition. ∎

**Corollary 7.2 (certified event replacement).** Under the right-hand condition in (7.2), $\widetilde p_a$ equals $P_M(V\mid\operatorname{do}(S=a))$ in every compatible model with positive observational law.

*Proof.* Earlier events cannot descend from $S$ in a topological order, so their joint law is invariant under its clamp by the coupling of Lemma 2.2. Theorem 7.1 and Rule 2 give

$$
P_M(f\mid h,S=a)
=P_M(f\mid\operatorname{do}(S=a),h).
\qquad\text{(7.3)}
$$

Multiply this conditional by the common prefix law $p(h)$ and the fixed target mass. The result is (7.1). ∎

The equivalence in Theorem 7.1 characterizes a graph test. Corollary 7.2 is a sufficient condition for equality of distributions. We do not assert that equality in a particular parameterized model requires that test: an allowed edge can be ignored, effects can cancel, or a projected outcome can agree while the full continuation does not.

## 7.2 Two distinct replacement failures

**Proposition 7.3 (order and district counterexamples).** A positive observational law does not make arbitrary generation order safe. Checking only direct hidden links from $S$ to the future is also insufficient.

*Proof.* First take $X$ fair and $Y=X\mathbin{\mathrm{xor}}N$ with independent $N\sim\operatorname{Bernoulli}(1/4)$. The graph is $X\to Y$. Emit $Y$ before $X$ and force $X=1$. The already emitted $Y$ remains fair, whereas $P(Y=1\mid\operatorname{do}(X=1))=3/4$. The total variation gap is $1/4$.

For the second claim, use order $(A,X,Y)$, no directed edges, and bidirected edges $A\leftrightarrow X$, $A\leftrightarrow Y$. Let all five primitive bits $U_{AX},U_{AY},N_A,N_X,N_Y$ be independent Bernoulli$(1/4)$ and put

$$
\begin{aligned}
A&=U_{AX}\mathbin{\mathrm{xor}}U_{AY}\mathbin{\mathrm{xor}}N_A,\\
X&=U_{AX}\mathbin{\mathrm{xor}}N_X,\qquad
Y=U_{AY}\mathbin{\mathrm{xor}}N_Y.
\end{aligned}
\qquad\text{(7.4)}
$$

There is no direct $X\leftrightarrow Y$. However, conditioning on the full prefix $A$ opens the bidirected collider path. Exact enumeration gives a full-joint replacement gap of $3/64$ for $X=1$. Both laws happen to have $P(Y=1)=3/8$. Equality of that one marginal therefore misses the continuation error. Every observational cell is positive because all private noises have both values in their support. ∎

[[FIGURE_GRAPHS]]

The example explains why “no hidden common cause with a later variable” is ambiguous. For continuation after an observed prefix, it is district connectivity that matters. A chain of hidden links through earlier conditioned events can be enough.

## 7.3 Approximate conditionals and structural error

Let $p_i(\cdot\mid h_i)$ be the true observational factors and $\widehat p_i$ their estimates. Use the same clamp in both generators. Suppose that, for every history that can occur before a non-clamped step,

$$
\operatorname{TV}\!\left(\widehat p_i(\cdot\mid h_i),
p_i(\cdot\mid h_i)\right)\leq\delta_i,\qquad 0\leq\delta_i\leq1.
\qquad\text{(7.5)}
$$

**Theorem 7.4 (two sources of causal error).** Let $\widehat p_a$ be estimated-factor replacement, $\widetilde p_a$ exact observational replacement and $p_a^{\mathrm{do}}$ the true intervention. Set $\Delta=\operatorname{TV}(\widetilde p_a,p_a^{\mathrm{do}})$ and $\epsilon=1-\prod_{i\ne s}(1-\delta_i)$. Then

$$
\begin{aligned}
\operatorname{TV}(\widehat p_a,\widetilde p_a)
&\leq\epsilon\leq\sum_{i\ne s}\delta_i,\\
\max(0,\Delta-\epsilon)
&\leq\operatorname{TV}(\widehat p_a,p_a^{\mathrm{do}})
\leq\min(1,\Delta+\epsilon).
\end{aligned}
\qquad\text{(7.6)}
$$

*Proof.* Couple the two generators sequentially. When their histories agree, use a maximal coupling of their next conditional laws, agreeing with probability at least $1-\delta_i$. The clamped values always agree. The probability that every non-clamped step agrees is at least the product in the definition of $\epsilon$. The coupling inequality proves the first bound, and the union bound gives the sum. The triangle inequality and its reverse give the second line. ∎

If observational conditional estimation is consistent so that $\epsilon\to0$, the causal error of replacement converges to $\Delta$. This is its structural limiting error. It is not an unconditional error floor for every finite approximation: estimation errors can partially cancel structural error. Under Corollary 7.2, $\Delta=0$, and (7.6) is a direct intervention guarantee.

For an identified expression with several divisions, a learned-model guarantee also needs denominator lower bounds. Accurate observational likelihood alone does not bound the conditioning ratios uniformly near zero. ADC therefore records a positivity certificate beside every normalization.

## 7.4 A decoder contract for latent generation

An ASE implementation may generate latent states rather than event values directly. Let its step kernels be $K_i(\cdot\mid z_{<i})$ on finite latent spaces, with event decoders $d_i:\mathcal Z_i\to\mathcal X_i$. Write $d_{<i}$ for the componentwise prefix decoder.

**Proposition 7.5 (decoded event replacement).** Suppose that, at each non-clamped step and for every history reachable under the replacement procedure,

$$
(d_i)_\#K_i(\cdot\mid z_{<i})
=p_i(\cdot\mid d_{<i}(z_{<i})).
\qquad\text{(7.7)}
$$

At step $s$, replace the kernel by any kernel supported on $d_s^{-1}(\{a\})$. The decoded joint law is then $\widetilde p_a$ of (7.1). Under Corollary 7.2 it is the true intervention. If the left and right sides of (7.7) differ by at most $\delta_i$ in total variation, the decoded laws obey Theorem 7.4.

*Proof.* Conditional on any decoded prefix, the latent prefixes form a mixture supported in its decoder fibre. Each component has the same next-event distribution by (7.7). Averaging retains $p_i$; the clamped step has decoded value $a$. Induction gives the product defining $\widetilde p_a$. In the approximate case, convexity of total variation bounds the mixture row by $\delta_i$, and sequential coupling gives (7.6). ∎

Equation (7.7) is a probabilistic commuting condition. Horizontal coordinate consistency alone does not imply it. In particular, choosing a latent vector or a word whose displayed value is $a$ does not certify the next-event kernels on its decoder fibre. This is the extra contract needed to connect an ASE representation to ADC's event semantics.

# 8 Credal precision and dependency preservation

## 8.1 Three different uncertainty sets

**Definition 8.1 (credal blocks).** Let $K=K_1\times\cdots\times K_m$, where each $K_j$ is a nonempty compact convex polytope of probability parameters. Entries within a block retain all simplex equalities and declared ties. Distinct blocks can vary independently. A scalar expression is separately affine when fixing all other blocks makes it an affine function of the remaining block.

Three operations must be distinguished. A graph-compatible credal set contains only laws attainable from the declared causal model class. A rectangular parameter relaxation may additionally contain laws violating graph constraints. Natural interval evaluation then performs another relaxation by allowing separate occurrences of the same numerical parameter to vary independently. The source of a wide answer cannot be diagnosed without saying which operation occurred.

**Theorem 8.2 (product vertex extrema).** A continuous separately affine expression on $K$ attains its minimum and maximum at product vertices.

*Proof.* Compactness gives a maximizing point. Fix every block except the first. An affine function on that first polytope has a maximizing vertex, so replace the first block without lowering the value. Repeat for every block. The resulting product vertex still maximizes the expression. Apply the same argument to its negative for the minimum. ∎

This is the standard finite multilinear principle used in credal optimization. A division-free expression is not automatically separately affine: reusing a Bernoulli parameter in $p(1-p)$ creates degree two. On $[0,1]$ its maximum $1/4$ is attained at $p=1/2$, while both vertices give zero.

## 8.2 A ratio certificate

**Theorem 8.3 (separately linear fractional extrema).** Suppose $N$ and $D$ are separately affine on $K$ and $D>0$ throughout $K$. The ratio $R=N/D$ attains both extrema at product vertices.

*Proof.* For one block write $\theta=\sum_v\lambda_vv$ as a convex combination of its vertices, holding the others fixed. Affinity gives

$$
R(\theta)
=\sum_v
\frac{\lambda_vD(v)}{\sum_w\lambda_wD(w)}\,R(v).
\qquad\text{(8.1)}
$$

The displayed coefficients are nonnegative and sum to one. Thus some vertex has ratio at least $R(\theta)$ and some has ratio at most it. Start from a global maximizer, which exists by compactness and denominator positivity, and move one block at a time to a maximizing vertex. Apply the same procedure to a minimizer. ∎

The denominator may depend on every block; it need not be constant. The required property is separate affinity of both parts after algebraic simplification, with the same declared blocks. Repeated syntax and nested ratios can obscure or destroy that property. For scalar boxes the kernel certifies it by expanding exact polynomials and checking that each variable has degree at most one. General simplex blocks require affinity in the entire block, not merely degree one in each entry.

Positive denominators alone do not suffice. The function

$$
R(p)=\frac{p}{p^2+1/4},\qquad p\in[1/10,1],
\qquad\text{(8.2)}
$$

has endpoint values $5/13$ and $4/5$ but reaches its maximum $1$ at $p=1/2$. Its denominator is positive but quadratic in that block. Equation (8.2) marks the boundary of the ratio theorem rather than a failure of it.

## 8.3 An exact front-door calculation

For the binary front-door graph fix the action $X=1$. Define independent scalar parameters

$$
\begin{aligned}
p&=P(X=1),& r&=P(Z=1\mid X=1),\\
a_u&=P(Y=1\mid X=u,Z=0),&
b_u&=P(Y=1\mid X=u,Z=1),\quad u\in\{0,1\}.
\end{aligned}
\qquad\text{(8.3)}
$$

The unused row $P(Z=1\mid X=0)$ is fixed in $(0,1)$. Its value does not enter the target. The front-door effect is

$$
F=(1-r)\{(1-p)a_0+pa_1\}
+r\{(1-p)b_0+pb_1\}.
\qquad\text{(8.4)}
$$

These observational parameters can range independently within positive intervals without violating this graph's observational model. To see this, let a hidden variable $U$ encode the natural value of $X$, set $X=U$, generate $Z$ from its two specified rows and generate $Y$ from the row indexed by $(U,Z)$. Independent finite noises realize every rational specification used here; a uniform noise realizes arbitrary real specifications. This constructs the required compatible models.

**Proposition 8.4 (sharp bounds with a selected outcome).** For positive boxes in the six parameters of (8.3), the exact bounds $F_-,F_+$ are found by setting $a_0,a_1,b_0,b_1$ all to their lower endpoints for the minimum and all to their upper endpoints for the maximum, checking the four corners of $(p,r)$ in each case. Add a child $S$ of $Y$, with independent positive rows $c=P(S=1\mid Y=0)$ and $d=P(S=1\mid Y=1)$. Then

$$
\begin{aligned}
T&=P(Y=1\mid\operatorname{do}(X=1),S=1)
=\frac{Fd}{Fd+(1-F)c},\\
T_-&=\frac{F_-d_-}{F_-d_-+(1-F_-)c_+},\\
T_+&=\frac{F_+d_+}{F_+d_++(1-F_+)c_-}.
\end{aligned}
\qquad\text{(8.5)}
$$

*Proof.* Equation (8.4) is separately affine and nondecreasing in each outcome-row parameter. Their endpoint choices are therefore simultaneous optimizers. The remaining bilinear function of $(p,r)$ reaches its extrema at their four corners. For (8.5), the numerator and denominator are separately affine in all eight parameters, and the denominator is at least $\min(c,d)>0$. Theorem 8.3 applies. More specifically, differentiating the ratio shows it is nondecreasing in $F,d$ and nonincreasing in $c$. Its extrema are the displayed combinations, each attainable because the blocks are independent. ∎

This reduces a six-parameter search from $64$ corners to eight evaluations. The eight-parameter conditional expression has $256$ corners, but its two exact endpoints follow from those same bounds and two ratio evaluations. This is a specialized simplification, not a polynomial-time method for all identification formulas.

## 8.4 Graph compatibility precedes interval precision

**Proposition 8.5 (equivalent estimands can have different relaxed ranges).** Two observational expressions that identify the same query on a graph can have different exact ranges on a rectangular relaxation of the compatible laws.

*Proof.* Consider two independent binary events, so the causal graph has no edges. Fix $P(X=1)=1/2$, let $p_0=P(Y=1\mid X=0)\in[1/5,4/5]$ and $p_1=P(Y=1\mid X=1)\in[1/5,2/5]$. Graph compatibility imposes $p_0=p_1$. The two estimands $P(Y=1)$ and $P(Y=1\mid X=0)$ both equal the query $P(Y=1\mid\operatorname{do}(X=x))$ on compatible laws, and its compatible range is $[1/5,2/5]$. On the unrestricted rectangle, their ranges are respectively

$$
\operatorname{range}\{(p_0+p_1)/2\}=[1/5,3/5],
\quad
\operatorname{range}\{p_0\}=[1/5,4/5].
\qquad\text{(8.6)}
$$

The difference is present before any occurrence-wise interval evaluation. ∎

Theorem 8.2 supplies an exact range for an expression on its declared product set. That set need not be the sharp causal uncertainty set. An answer should therefore name both its domain and its relaxation. In the front-door study the explicit construction above establishes compatibility, so this distinction introduces no hidden relaxation.

## 8.5 Occurrence counts do not order precision

**Proposition 8.6 (failure of a universal repeat-count ranking).** The number of occurrences of an uncertain parameter does not universally order the widths of natural interval evaluations of equal expressions.

*Proof.* On $p\in[0,1]$, compare the polynomially equal forms

$$
\begin{aligned}
E_1&=p(1-p),\\
E_2&=\tfrac14-(p-\tfrac12)(p-\tfrac12)
+\tfrac1{100}(p-p).
\end{aligned}
\qquad\text{(8.7)}
$$

Natural interval arithmetic gives $E_1\in[0,1]$. In the second form, $(p-1/2)$ ranges over $[-1/2,1/2]$, its occurrence-wise product over $[-1/4,1/4]$, and the last term over $[-1/100,1/100]$. Thus $E_2\in[-1/100,51/100]$, with width $13/25<1$. The second form has four occurrences instead of two, yet a narrower interval. Their common exact range is $[0,1/4]$. ∎

The counterexample refutes the unrestricted ranking. It does not preclude a useful heuristic on a prescribed normalized class. In the positive front-door expressions, three regroupings with different repetition patterns have exactly the same ideal interval bounds. Positive interval addition and multiplication distribute, so rearrangement alone provides no improvement there. Keeping $p$ and $1-p$ tied, and retaining the shared parameter across mixtures, gives the improvement proved in Proposition 8.4.

Outward binary64 intervals add an arithmetic enclosure around the ideal interval calculation. The reference kernel uses exact rational-to-binary64 adjacent brackets and outward-rounded finite operations inherited from Ghosh (2026). A denominator crossing zero or an unsupported nonfinite result is rejected. Arithmetic enclosure, sharp optimization on a product set and sharp causal uncertainty remain three separate claims.

# 9 Exact finite checks and open comparisons

## 9.1 What was run

The C# implementation uses exact rational probabilities for the causal checks. Its public graph and kernel values are immutable; temporary arrays and lists are private scratch storage. A separate Python program recomputes the results using fractions, direct exogenous-state enumeration, its own set-based ID recursion and direct enumeration of m-active paths. Symbolic degrees are checked with SymPy. External y0 version {{Y0_VERSION}} is used as an additional decision oracle for ID and the conditional example. It is not used to validate the numerical values of our formula expressions.

[[TABLE_CHECKS]]

The five named models and twelve seeded random models have binary variables. Each random size from five through eight contributes three models. Directed edges respect the declared order and are independently proposed with probability $0.30$. Each graph has one to three bidirected edges. Private and shared noises have Bernoulli probabilities in $\{1/4,1/2,3/4\}$; each endogenous variable is the exclusive-or of its parents, incident shared noises and private noise. These choices ensure positivity and keep exact enumeration feasible. They are a finite test family, not a representative sample of all structural mechanisms.

Across the {{ID_QUERIES}} joint queries, {{IDENTIFIED}} were identified and {{UNIDENTIFIED}} returned an ID failure. The identified expression values matched direct mechanism replacement on {{ASSIGNMENTS}} global assignments, with zero mismatch. The C# current-kernel recursion and independent Python implementation agreed, as did all external joint decisions. The conditional-only example of Section 5 was also identified by both implementations and the oracle, although its required full joint was not identified. The explicit witness of Proposition 5.3 is independently checked; arbitrary witness-pair construction is not implemented.

[[TABLE_NAMED]]

The named front-door example is identified despite failing the clamp certificate. The indirect prefix-collider example preserves the selected $Y$ marginal while changing the joint. These results make it necessary to state whether an error concerns a target marginal or the whole generated continuation.

## 9.2 Exhaustive graph and rule checks

There are $2^6$ choices of ordered directed edges and $2^6$ choices of bidirected edges on four labelled vertices, giving $4,096$ ADMGs. At each of the four positions, the C# separation routine and the independent direct-path checker test (7.2). All {{GRAPH_CASES}} cases agree with the district criterion; {{GRAPH_CERTIFICATES}} are certified and there are zero discrepancies.

For the causal rules, all $64$ ordered three-vertex ADMGs are tested. For each rule, choose distinct singleton outcome and transferred event; the third event is absent, an existing action or an observed condition. This gives $3,456$ rule-premise bindings in total. Rules 1, 2 and 3 license {{RULE1}}, {{RULE2}} and {{RULE3}} bindings respectively. Every licensed identity holds on all eight assignments in its positive rational test model: {{RULE_ASSIGNMENTS}} exact comparisons in total. This is an implementation check supporting the inherited soundness, not a replacement for its general proof.

The rule-only front-door search visits just one query type and reaches no observational endpoint. ID succeeds. This independently confirms the syntax distinction in Proposition 4.6 without attributing a limitation to full do-calculus with probability algebra.

## 9.3 Clock resolution

The clock study has {{NARRATIVES}} narratives of six events, with strictly increasing hidden true dates. True increments are multiples of $1/48$ of an abstract year. Reports use either a whole-year closed hull or one of twelve equal month hulls; randomly supplied lower and upper lag constraints are chosen to include the truth. Narrative text order is independently shuffled. All {{NARRATIVES}} networks are consistent by construction.

Of {{CLOCK_PAIRS}} truly ordered pairs, the exact network certifies {{CLOCK_CERTIFIED}} ({{CLOCK_PERCENT}}%) with no false order. Mean event-window width changes from {{WIDTH_BEFORE}} to {{WIDTH_AFTER}} abstract years. Text order reverses {{TEXT_FALSE}} pairs ({{TEXT_PERCENT}}%). These are false chronological orders, not a measured rate of false causal answers. To turn such an order into an action-deletion error requires a query and an actual causal mechanism linking the events. The present study does not supply that semantic experiment.

## 9.4 Credal widths

The precision study uses {{BOXES}} positive front-door boxes. Each active scalar parameter has a dyadic centre $k/16$, $k\in\{4,\ldots,11\}$, and radius $1/64$. The six-parameter effect is checked at all $64$ vertices. Adding the two selection rows gives $256$ vertices. Both the optimized endpoint formulas and the outward C# enclosures pass in every case.

[[TABLE_PRECISION]]

The medians compare ideal natural-interval widths with exact ranges on the same compatible boxes. They do not measure estimation variance. In these boxes the naive conditional intervals already lie inside $[0,1]$, so probability clipping would leave these reported ratios unchanged. The three positive polynomial regroupings give identical ideal intervals in all {{BOXES}} cases, although their syntax repeats the parameters differently.

[[FIGURE_PRECISION]]

The gain comes from preserving dependency constraints, including the simplex complement and the common mixing weights. There is no evidence here that selecting the expression with the fewest repeats improves precision. The separately affine degrees of the effect, the conditional numerator and the conditional denominator are all one in each scalar parameter, independently certified symbolically.

## 9.5 Status of the proposed comparisons

**C1 revised hypothesis on estimand choice.** The unrestricted claim that fewer repeated terms always narrow an interval is false by Proposition 8.6. On the positive front-door family, regrouping does not change the ideal enclosure. The proposal's predicted halving of excess width is therefore not established. A future heuristic must freeze a normalized expression class, admissible algebraic rewrites, parameter blocks and interval evaluator before testing any ranking. A structural certificate such as Theorem 8.3 takes precedence over a syntax score.

**C2 hypothesis on clock-aware causal answers.** Clock certificates are sound under Theorem 6.1, and this study retains more than half the true pair orders. The proposal's prediction of forbidden action deletions from text tie-breaking is not tested: its unit was a causal query, whereas the present measurement is an event pair. A valid future test must freeze the event and graph family, the action-deletion queries and the treatment of ties, then evaluate deleted and retained actions against the actual intervened laws. A false chronological order is counted as a semantic failure only if the corresponding causal equality fails.

**C3 conjecture on learned autoregressive models.** On a prespecified family of identified confounded queries, executing the identified expression from a trained generator's observational conditionals will have at most half the mean interventional total variation error of event replacement, at matched data, parameters and declared inference budget. Freeze the SCM distribution, graph access, train/test splits, estimator smoothing, denominator thresholds and query weights before training. Exclude a zero replacement-error baseline from the ratio test and report it separately. An uncertainty interval wholly above $0.5$ refutes the prediction; one crossing $0.5$ is inconclusive. No trained-model experiment is reported here. The exact replacement gap $\Delta$ is a limiting benchmark under observational consistency, as Theorem 7.4 specifies.

## 9.6 Scope and limitations

The causal graph and event semantics are supplied. ADC does not identify them from prose, prove that a neural decoder preserves them, handle feedback or equilibrium interventions, or establish cross-world counterfactual identification. Its finite semi-Markovian model is narrower than an arbitrary sheaf or topos. The sheaf supplies shared variable consistency, while causal completeness comes from ID and IDC.

A failure trace is not an automatically synthesized pair of models. A credal range is conditional on its uncertainty set. Vertex enumeration remains exponential in the number of blocks and vertices, even though Proposition 8.4 is inexpensive. The ratio theorem requires a certified form and positive denominator throughout the domain; it is not a general solver for rational identification formulas.

Finally, the mechanism incidence sheaf has deliberately modest computational responsibilities. Removing its terminology leaves the probability and graph results meaningful. Its value within ASE is to keep mechanism scopes, shared coordinates and intervention replacements explicit when these calculations are embedded in a layered representation. That value must ultimately be tested by a decoder and task, rather than inferred from the name of the construction.

# 10 Conclusion

ADC gives event generators a precise contract for causal computation. The observational factors are executable data; do-calculus and identification supply their permitted causal uses. The horizontal mechanism sheaf records local solutions and shared variables, while probability marginalization remains a generally weaker presheaf. Clocks certify selected action deletions, and the last-in-district condition certifies when topological event replacement already implements a perfect intervention.

Precision requires an equally explicit contract. Separately affine effects and certified ratios have exact product-vertex bounds. Graph compatibility, probability-row ties and occurrence relaxation are different constraints, so an interval width is meaningful only with its domain stated. The exact checks support the implementation and expose failed simplifications. The remaining empirical question is whether this discipline improves learned causal answers at an acceptable computational cost.

# Appendix A Assumptions and claim boundaries

[[TABLE_ASSUMPTIONS]]

Theorems 3.4, 4.5, 8.2 and 8.3 are elementary structural or optimization statements. Lemmas 4.1–4.3 and Theorems 5.1–5.2 are inherited causal results, included to specify ADC's semantics. The clock and generator consequences are proved in their finite setting; no claim of being the first formulation of every component is made.

# Appendix B Reference kernel and reproduction

## B.1 Immutable values and explicit failures

The reference code targets .NET 8 without third-party NuGet packages. Exact rationals are reduced pairs of arbitrary-precision integers. Ordered graph values contain immutable vertex and edge arrays. The current graph representation accepts at most twelve events; the executed suite uses at most eight. Query results contain a formula graph, its evaluated exact kernel and a recursion trace, or a failure record naming the active graph and district. IDC uses the same graph operations and kernel representation.

The formula language distinguishes observational joint data, marginalization, products and positive division. In every recursive call, district factors are extracted from prefix ratios of the current kernel. Exact parameter identity is retained in the symbolic precision calculation. Local mutation is confined to temporary storage; no graph, law, rational or interval value is changed after publication.

The arithmetic layer rejects a zero denominator, an interval divisor containing zero and unsupported nonfinite arithmetic. Clock inconsistency is returned separately from a successful but inconclusive order test. Non-identification is a property of the query and model class; these arithmetic or clock failures must not be mislabeled non-identification.

## B.2 Independent routes

C# ground truth sums latent-state densities over endogenous assignments, omitting the clamped target mechanisms. Python instead enumerates all exogenous noise assignments and solves the remaining mechanisms in order. C# separation uses moralization of the ancestral explicit latent DAG. Python enumerates m-active paths directly in the mixed graph. Both implement ID and IDC independently; y0 supplies a third decision route.

For interval checks, Python evaluates exact rational intervals and exact vertex values. It verifies containment using the exact rational value of each returned binary64 endpoint. The allowed excess width over the ideal interval calculation is at most $10^{-12}\max(1,w)$, where $w$ is its ideal width. Exact causal identities use zero tolerance. Symbolic checks expand polynomials and confirm the degree certificate.

The verified environments are .NET SDK {{DOTNET_SDK}} with runtime {{DOTNET_RUNTIME}}, Python {{PYTHON_VERSION}}, SymPy {{SYMPY_VERSION}} and y0 {{Y0_VERSION}}. The source archive includes the C# project, the independent validator, input and result files, this manuscript, its Word builder, and a project note recording the status of C1–C3. The SDK and third-party dependency installations are not bundled.

## B.3 Reproduction contract

Build the C# project in release mode, run its executable with the output directory argument and capture the tab-separated summary. Run the independent validator in the same source directory with its listed Python dependencies. The supplied README gives the exact commands and package versions. The three deterministic random streams separately generate models, clocks and credal boxes.

A clean replay reproduces all summary lines and generated JSON and CSV result files byte for byte; the independent validator passes all {{SUMMARY_LINES}} summary lines. The checks establish agreement for this declared finite suite. They do not constitute formal verification of arbitrary code paths, a generic hedge-witness generator or a learned-system evaluation.

# References

Abramsky, S., & Brandenburger, A. (2011). The sheaf-theoretic structure of non-locality and contextuality. *New Journal of Physics, 13*, 113036. https://doi.org/10.1088/1367-2630/13/11/113036

Charnes, A., & Cooper, W. W. (1962). Programming with linear fractional functionals. *Naval Research Logistics Quarterly, 9*(3–4), 181–186. https://doi.org/10.1002/nav.3800090303

Cozman, F. G. (2000). Credal networks. *Artificial Intelligence, 120*(2), 199–233. https://doi.org/10.1016/S0004-3702(00)00029-1

Dechter, R., Meiri, I., & Pearl, J. (1991). Temporal constraint networks. *Artificial Intelligence, 49*(1–3), 61–95. https://doi.org/10.1016/0004-3702(91)90006-6

Fritz, T., & Klingler, A. (2023). The d-separation criterion in categorical probability. *Journal of Machine Learning Research, 24*(46), 1–49. https://jmlr.org/papers/v24/22-0916.html

Ghosh, D. P. (2026). *Dependency preserving temporal causal computation: Horizontal sheaves, interval ranges and temporal smoothing*. https://doi.org/10.13140/RG.2.2.33732.18568

Gogioso, S., & Pinzani, N. (2021). *The sheaf-theoretic structure of definite causality* [Withdrawn preprint]. arXiv. https://arxiv.org/abs/2103.13771

Gogioso, S., & Pinzani, N. (2022). *The combinatorics of causality* [Preprint, version 4, revised 2023]. arXiv. https://arxiv.org/abs/2206.08911v4

Gogioso, S., & Pinzani, N. (2023). *The topology of causality* [Preprint, version 2]. arXiv. https://arxiv.org/abs/2303.07148v2

Jacobs, B., Kissinger, A., & Zanasi, F. (2019). Causal inference by string diagram surgery. In *Foundations of Software Science and Computation Structures* (Vol. 11425, pp. 313–329). Springer. https://doi.org/10.1007/978-3-030-17127-8_18

Mahadevan, S. (2025). *Intuitionistic j-do-calculus in topos causal models* [Preprint, version 2, revised 2026]. arXiv. https://arxiv.org/abs/2510.17944v2

Pearl, J. (1995). Causal diagrams for empirical research. *Biometrika, 82*(4), 669–688. https://doi.org/10.1093/biomet/82.4.669

Pearl, J. (2009). *Causality: Models, reasoning, and inference* (2nd ed.). Cambridge University Press. https://doi.org/10.1017/CBO9780511803161

Shpitser, I., & Pearl, J. (2006a). Identification of conditional interventional distributions. In *Proceedings of the Twenty-Second Conference on Uncertainty in Artificial Intelligence* (pp. 437–444). AUAI Press. https://arxiv.org/abs/1206.6876

Shpitser, I., & Pearl, J. (2006b). Identification of joint interventional distributions in recursive semi-Markovian causal models. In *Proceedings of the Twenty-First AAAI Conference on Artificial Intelligence* (pp. 1219–1226). AAAI Press. https://ftp.cs.ucla.edu/pub/stat_ser/r327.pdf

Tian, J., & Pearl, J. (2002). A general identification condition for causal effects. In *Proceedings of the Eighteenth National Conference on Artificial Intelligence* (pp. 567–573). AAAI Press. https://cdn.aaai.org/AAAI/2002/AAAI02-085.pdf

y0 contributors. (n.d.). *y0* (Version 0.2.11) [Computer software]. https://github.com/y0-causal-inference/y0

Yvernes, C., Devijver, E., Clausel, M., & Gaussier, E. (2026). Unveiling the structure of do-calculus reasoning via derivation graphs. In *Proceedings of the 43rd International Conference on Machine Learning* (Vol. 306, pp. 152645–152672). PMLR. https://proceedings.mlr.press/v306/yvernes26a.html
