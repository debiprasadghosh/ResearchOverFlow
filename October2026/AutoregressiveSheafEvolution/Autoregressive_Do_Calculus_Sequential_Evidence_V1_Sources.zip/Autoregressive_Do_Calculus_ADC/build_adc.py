"""Build a formal Word paper with editable OMML and tables from verified result files."""
from __future__ import annotations
import json, math, re, subprocess, zipfile
from datetime import datetime, timezone
from fractions import Fraction as Q
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from lxml import etree

ROOT=Path(__file__).resolve().parent
OUT=ROOT/"deliverables"
OUT.mkdir(exist_ok=True)
FIG=ROOT/"figures"
FIG.mkdir(exist_ok=True)
V=json.loads((ROOT/"validation_results.json").read_text())
REPLAY=json.loads((ROOT/"replay_results.json").read_text())
assert V["all_passed"] and REPLAY["all_identical"]
C={l.split("\t")[0]:l.rstrip().split("\t")[1].split() for l in (ROOT/"cs_results.txt").read_text().splitlines()}
assert len(C)==V["summary_lines"]
comma=lambda x:f"{int(x):,}"

fills={
 "SUMMARY_LINES":V["summary_lines"],"ID_QUERIES":comma(V["id_queries"]),"GRAPH_CASES":comma(V["prefix_graph_cases"]),
 "LICENSED_RULES":comma(V["licensed_rule_bindings"]),"RULE_PATH_STATES":C["rule_path_frontdoor"][0],
 "IDENTIFIED":comma(V["identified_queries"]),"UNIDENTIFIED":comma(V["unidentified_queries"]),
 "ASSIGNMENTS":comma(V["formula_assignments"]),"GRAPH_CERTIFICATES":comma(V["prefix_graph_certificates"]),
 "RULE1":C["three_rule_soundness"][1],"RULE2":C["three_rule_soundness"][3],"RULE3":C["three_rule_soundness"][5],
 "RULE_ASSIGNMENTS":comma(V["probability_identity_assignments"]),
 "NARRATIVES":C["clock_certificates"][0],"CLOCK_PAIRS":comma(C["clock_certificates"][2]),
 "CLOCK_CERTIFIED":comma(C["clock_certificates"][3]),"CLOCK_PERCENT":f'{100*V["clock_certified_fraction"]:.2f}',
 "WIDTH_BEFORE":f'{float(C["clock_certificates"][6]):.4f}',"WIDTH_AFTER":f'{float(C["clock_certificates"][7]):.4f}',
 "TEXT_FALSE":comma(C["clock_certificates"][5]),"TEXT_PERCENT":f'{100*V["clock_text_false_fraction"]:.2f}',
 "BOXES":C["credal_checks"][0],"Y0_VERSION":V["external_y0_version"],"SYMPY_VERSION":V["sympy"],
 "PYTHON_VERSION":V["python"],"DOTNET_SDK":REPLAY["sdk"],"DOTNET_RUNTIME":"8.0.33"
}
md=(ROOT/"paper.md").read_text()
for k,v in fills.items():md=md.replace("{{"+k+"}}",str(v))
assert not re.search(r"\{\{[A-Z_]+\}\}",md)
(ROOT/"paper_filled.md").write_text(md)

# Formal typography and Letter portrait layout.
ref=Document()
sec=ref.sections[0]
sec.page_width=Inches(8.5);sec.page_height=Inches(11)
sec.left_margin=sec.right_margin=Inches(.9)
sec.top_margin=sec.bottom_margin=Inches(.72)
sec.header_distance=Inches(.25);sec.footer_distance=Inches(.3)
for name in ("Normal","Body Text","First Paragraph","Abstract"):
    try:st=ref.styles[name]
    except KeyError:st=ref.styles.add_style(name,1)
    st.font.name="Times New Roman";st.font.size=Pt(11.5);st.font.color.rgb=RGBColor(0,0,0)
    pf=st.paragraph_format
    pf.space_after=Pt(5.5);pf.line_spacing=1.10;pf.first_line_indent=Inches(0)
    pf.widow_control=True
for name,size in [("Title",22),("Subtitle",12),("Heading 1",14),("Heading 2",12),("Heading 3",11.5)]:
    st=ref.styles[name];st.font.name="Times New Roman";st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0)
    st.font.bold=(name!="Subtitle")
    pf=st.paragraph_format;pf.space_before=Pt(13 if name.startswith("Heading") else 0)
    pf.space_after=Pt(7);pf.keep_with_next=True;pf.keep_together=True
    pf.line_spacing=1.05
    if name in ("Title","Subtitle"):pf.alignment=WD_ALIGN_PARAGRAPH.CENTER
for name in ("Author","Date"):
    try:st=ref.styles[name]
    except KeyError:st=ref.styles.add_style(name,1)
    st.font.name="Times New Roman";st.font.size=Pt(11.5);st.font.color.rgb=RGBColor(0,0,0)
    st.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
    st.paragraph_format.space_after=Pt(4)
    st.paragraph_format.keep_with_next=True
ref.styles["Caption"].font.name="Times New Roman"
ref.styles["Caption"].font.size=Pt(10)
ref.styles["Caption"].font.color.rgb=RGBColor(0,0,0)
ref.styles["Caption"].font.italic=True
ref.styles["Caption"].paragraph_format.line_spacing=1.05
ref.styles["Caption"].paragraph_format.space_after=Pt(6)
ref.styles["Caption"].paragraph_format.space_before=Pt(8)
hyper=ref.styles.add_style("Hyperlink",2) if "Hyperlink" not in ref.styles else ref.styles["Hyperlink"]
hyper.font.color.rgb=RGBColor(0,0,0)
hyper.font.underline=False
refpath=ROOT/"reference.docx";ref.save(refpath)
target=OUT/"Autoregressive_Do_Calculus_ADC.docx"
proc=subprocess.run(["pandoc",str(ROOT/"paper_filled.md"),"-f","markdown+tex_math_dollars-auto_identifiers",
                     "-o",str(target),f"--reference-doc={refpath}","--no-highlight"],
                    capture_output=True,text=True,check=True)
(ROOT/"pandoc.log").write_text(proc.stdout+proc.stderr)
doc=Document(target)
sec=doc.sections[0]
sec.left_margin=sec.right_margin=Inches(.9)
sec.top_margin=sec.bottom_margin=Inches(.72)
sec.page_width=Inches(8.5);sec.page_height=Inches(11)
sec.footer_distance=Inches(.3)
footer=sec.footer.paragraphs[0]
footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
run=footer.add_run();run.font.name="Times New Roman";run.font.size=Pt(9)
field=OxmlElement("w:fldSimple");field.set(qn("w:instr"),"PAGE")
rr=OxmlElement("w:r");tt=OxmlElement("w:t");tt.text="1";rr.append(tt);field.append(rr);footer._p.append(field)

def marker(text):
    return next(p for p in doc.paragraphs if p.text.strip()==text)
def put_before(anchor,el):anchor._p.addprevious(el)
def caption(text,before=True):
    p=doc.add_paragraph(text,style="Caption")
    p.paragraph_format.keep_with_next=before
    e=p._p;e.getparent().remove(e);return e
def table(mark,rows,widths,cap,notes=None):
    anchor=marker(mark)
    put_before(anchor,caption(cap,True))
    t=doc.add_table(rows=0,cols=len(widths))
    t.autofit=False
    for row in rows:
        cells=t.add_row().cells
        for cell,s in zip(cells,row):cell.text=str(s)
    tp=t._tbl.tblPr
    for e in list(tp):tp.remove(e)
    total=sum(widths)
    for tag,attrs in [("tblW",{"w":str(total),"type":"dxa"}),("jc",{"val":"center"})]:
        x=OxmlElement("w:"+tag)
        for k,v in attrs.items():x.set(qn("w:"+k),v)
        tp.append(x)
    borders=OxmlElement("w:tblBorders")
    for side in ("top","left","bottom","right","insideH","insideV"):
        e=OxmlElement("w:"+side)
        for k,v in {"val":"single","sz":"4","color":"D9D9D9"}.items():e.set(qn("w:"+k),v)
        borders.append(e)
    tp.append(borders)
    layout=OxmlElement("w:tblLayout");layout.set(qn("w:type"),"fixed");tp.append(layout)
    for grid,w in zip(t._tbl.tblGrid.gridCol_lst,widths):grid.set(qn("w:w"),str(w))
    for ri,row in enumerate(t.rows):
        trpr=row._tr.get_or_add_trPr();trpr.append(OxmlElement("w:cantSplit"))
        if ri==0:trpr.append(OxmlElement("w:tblHeader"))
        for ci,(cell,w) in enumerate(zip(row.cells,widths)):
            cp=cell._tc.get_or_add_tcPr()
            for e in list(cp):cp.remove(e)
            e=OxmlElement("w:tcW");e.set(qn("w:w"),str(w));e.set(qn("w:type"),"dxa");cp.append(e)
            e=OxmlElement("w:shd");e.set(qn("w:val"),"clear");e.set(qn("w:fill"),"EDF0F2" if ri==0 else "FFFFFF");cp.append(e)
            margins=OxmlElement("w:tcMar")
            for side in ("top","left","bottom","right"):
                e=OxmlElement("w:"+side);e.set(qn("w:w"),"85");e.set(qn("w:type"),"dxa");margins.append(e)
            cp.append(margins)
            e=OxmlElement("w:vAlign");e.set(qn("w:val"),"center");cp.append(e)
            for p in cell.paragraphs:
                p.style=doc.styles["Body Text"];pf=p.paragraph_format
                pf.space_before=Pt(0);pf.space_after=Pt(1.5);pf.line_spacing=1.05
                pf.keep_with_next=False
                pf.alignment=WD_ALIGN_PARAGRAPH.LEFT if ci==0 or mark=="[[TABLE_ASSUMPTIONS]]" or (mark=="[[TABLE_CHECKS]]" and ci==2) else WD_ALIGN_PARAGRAPH.CENTER
                for r in p.runs:r.font.size=Pt(10);r.font.bold=(ri==0)
    e=t._tbl;e.getparent().remove(e);put_before(anchor,e)
    if notes:
        p=doc.add_paragraph(notes,style="Body Text")
        p.paragraph_format.space_before=Pt(4)
        for r in p.runs:r.font.size=Pt(10)
        e=p._p;e.getparent().remove(e);put_before(anchor,e)
    anchor._p.getparent().remove(anchor._p)

table("[[TABLE_CHECKS]]",[
 ["Check","Cases","Result"],
 ["Joint ID decisions",comma(V["id_queries"]),f'{comma(V["identified_queries"])} identified; {comma(V["unidentified_queries"])} failed; all external decisions agree'],
 ["Identified formula evaluations",comma(V["formula_assignments"]),"Exact equality to mechanism replacement"],
 ["Prefix graph criterion",comma(V["prefix_graph_cases"]),"No discrepancy between separation and district tests"],
 ["Licensed rule bindings",comma(V["licensed_rule_bindings"]),f'{comma(V["probability_identity_assignments"])} exact value comparisons; all agree'],
 ["Interval clock narratives",fills["NARRATIVES"],f'{fills["CLOCK_CERTIFIED"]} of {fills["CLOCK_PAIRS"]} pair orders certified; none false'],
 ["Credal effect boxes",fills["BOXES"],"All sharp bounds and outward enclosures pass"],
 ["Credal selected-outcome boxes",fills["BOXES"],"All 256-vertex ranges and sharp ratios agree"],
 ["Summary output agreement",V["summary_lines"],"Every C# line independently checked in Python"],
 ],[2700,1100,5848],"Table 1 Finite verification suite")

labels=[("backdoor","Back-door"),("frontdoor","Front-door"),("bow","Bow"),
        ("last_district","Last in district"),("prefix_collider","Prefix collider")]
rows=[["Model","ID","True do","Replacement","Full TV","Certified"]]
for key,label in labels:
    a=C["named_"+key]
    rows.append([label,"Yes" if a[0]=="1" else "No",a[1],a[2],a[3],"Yes" if a[4]=="1" else "No"])
table("[[TABLE_NAMED]]",rows,[2400,650,1550,1750,1398,1500],
      "Table 2 Named exact models with the action fixed at one",
      "True do and replacement are the selected outcome probabilities at value one. Full TV compares the complete joint laws. Certified means the graph test of Theorem 7.1 holds. Graphs and parameter values are supplied in models.json.")

rat=list(map(float,C["credal_width_ratios"]))
table("[[TABLE_PRECISION]]",[
 ["Target","Vertices","Median width ratio","Largest width ratio","Sharp checks"],
 ["Front-door effect",C["credal_checks"][5],f"{rat[0]:.3f}",f"{rat[1]:.3f}",f'{fills["BOXES"]}/{fills["BOXES"]}'],
 ["Selected outcome",C["credal_checks"][6],f"{rat[2]:.3f}",f"{rat[3]:.3f}",f'{fills["BOXES"]}/{fills["BOXES"]}'],
 ],[2600,1000,2200,2200,1248],
      "Table 3 Ideal natural interval width divided by the exact compatible range")

table("[[TABLE_ASSUMPTIONS]]",[
 ["Statement","Required assumptions","What is certified"],
 ["3.2 State gluing","Fixed total mechanism relations on the incidence space","Solutions and local compatibility; no inferred probability law"],
 ["3.4 Identification","Fixed model class and observational map","Constancy on observational fibres"],
 ["4.1–4.5 Rules and programs","Correct mutilation, separation, typed probability algebra and defined support","Semantic equality of each certified program"],
 ["5.1–5.2 Identification algorithms","Classical acyclic semi-Markovian setting; positive tabular support where divided","Inherited joint ID and conditional IDC completeness"],
 ["6.1 and 6.3 Clock deletion","Fixed feasible clock; nonnegative directed lags; strict earlier order for outcomes and conditions","Invariance across compatible clocks and models"],
 ["7.1–7.2 Event replacement","Topological order; positive law; target last in its district","Whole-continuation exchange and intervention equality"],
 ["7.4–7.5 Approximation and decoding","Uniform row-TV bounds; decoder-fibre pushforward contract","Accumulated distribution error and decoded event semantics"],
 ["8.2 Product vertices","Independent compact polytope blocks; separate affinity","Exact expression extrema on that product set"],
 ["8.3 Ratio vertices","Same blocks; separately affine numerator and denominator; positive denominator","Exact ratio extrema on that product set"],
 ["8.4 Specialized sharp bounds","Compatible positive front-door boxes and independent selection rows","Attainable causal range for the specified query"],
 ],[2300,3600,3748],"Table A1 Claim assumptions and limits")

# Exact diagrams drawn from the graph definitions, with no generated imagery.
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9.5,"text.color":"black",
                     "axes.labelcolor":"black","axes.spines.top":False,"axes.spines.right":False})
fig,axs=plt.subplots(1,2,figsize=(6.45,2.45))
for ax in axs:ax.set(xlim=(-.4,2.4),ylim=(-.75,1.2));ax.axis("off")
def node(ax,xy,label):
    ax.add_patch(Circle(xy,.18,facecolor="white",edgecolor="black",lw=1.1,zorder=3))
    ax.text(*xy,label,ha="center",va="center",fontsize=12,zorder=4)
def arrow(ax,a,b,bi=False,rad=0):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle="<->" if bi else "-|>",mutation_scale=12,
                                shrinkA=13,shrinkB=13,connectionstyle=f"arc3,rad={rad}",
                                lw=1.1,linestyle="--" if bi else "-",color="black",zorder=2))
for label,x in zip(("X","Z","Y"),(0,1,2)):node(axs[0],(x,.35),label)
arrow(axs[0],(0,.35),(1,.35));arrow(axs[0],(1,.35),(2,.35))
arrow(axs[0],(0,.35),(2,.35),True,-.6)
axs[0].text(1,-.50,"(a) Identified front-door effect\nClamp certificate fails",ha="center",va="center",fontsize=9.2)
for label,x in zip(("A","X","Y"),(0,1,2)):node(axs[1],(x,.35),label)
arrow(axs[1],(0,.35),(1,.35),True)
arrow(axs[1],(0,.35),(2,.35),True,-.6)
axs[1].text(1,-.50,"(b) Conditioned prefix A opens\nX–A–Y despite no X–Y edge",ha="center",va="center",fontsize=9.2)
fig.subplots_adjust(left=.01,right=.99,bottom=.02,top=.99,wspace=.12)
graphpath=FIG/"generator_graphs.png";fig.savefig(graphpath,dpi=240,facecolor="white");plt.close(fig)

prec=json.loads((ROOT/"output/precision.json").read_text())
width=lambda a:float(Q(a[1])-Q(a[0]))
fx=[width(r["exact"]) for r in prec];fy=[width(r["naive"]) for r in prec]
tx=[width(r["conditionalExact"]) for r in prec];ty=[width(r["conditionalNaive"]) for r in prec]
fig,axs=plt.subplots(1,2,figsize=(6.45,2.8))
for ax,x,y,title in zip(axs,(fx,tx),(fy,ty),("(a) Front-door effect","(b) Selected outcome")):
    mx=max(y)*1.06
    ax.plot([0,mx],[0,mx],color="#808080",lw=.9,ls="--",label="Equal width")
    ax.scatter(x,y,color="#244964",s=16,alpha=.85,edgecolors="none")
    ax.set(xlim=(0,mx),ylim=(0,mx),xlabel="Exact compatible width",ylabel="Natural interval width",title=title)
    ax.set_aspect("equal");ax.grid(alpha=.16)
    ax.tick_params(labelsize=8)
axs[0].legend(frameon=False,fontsize=8,loc="lower right")
fig.tight_layout(pad=.7,w_pad=2.0)
precpath=FIG/"credal_widths.png";fig.savefig(precpath,dpi=240,facecolor="white");plt.close(fig)
def picture(mark,path,cap,description):
    anchor=marker(mark)
    p=doc.add_paragraph(style="Body Text");p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next=True
    shape=p.add_run().add_picture(str(path),width=Inches(6.45))
    shape._inline.docPr.set("descr",description)
    e=p._p;e.getparent().remove(e);put_before(anchor,e)
    put_before(anchor,caption(cap,False))
    anchor._p.getparent().remove(anchor._p)
picture("[[FIGURE_GRAPHS]]",graphpath,
        "Figure 1 Bidirected connectivity controls the prefix certificate",
        "Front-door graph X to Z to Y with hidden X–Y confounding; and a graph with A bidirected to X and Y, whose conditioned A activates a collider path.")
picture("[[FIGURE_PRECISION]]",precpath,
        "Figure 2 Exact and natural interval widths on all forty compatible boxes",
        "Every point lies above the equal-width line. Left: front-door effects. Right: selected-outcome ratios. Data are the exact rational intervals in precision.json.")

# Paragraph details and native math normalization.
in_refs=False
for p in doc.paragraphs:
    if p.text.startswith("Founder and Principal Engineer"):
        p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after=Pt(8)
        p.paragraph_format.keep_with_next=True
    if p.text=="1 Introduction":p.paragraph_format.page_break_before=True
    if p.text=="References":
        in_refs=True
        p.paragraph_format.page_break_before=True
        continue
    if in_refs:
        if "Bibliography" not in doc.styles:
            b=doc.styles.add_style("Bibliography",1)
            b.base_style=doc.styles["Body Text"]
            b.font.name="Times New Roman";b.font.size=Pt(11)
        p.style=doc.styles["Bibliography"]
        p.paragraph_format.left_indent=Inches(.22)
        p.paragraph_format.first_line_indent=Inches(-.22)
        p.paragraph_format.line_spacing=1.02
        p.paragraph_format.space_after=Pt(5)
        p.paragraph_format.keep_together=True
    if re.match(r"^(Definition|Theorem|Proposition|Lemma|Corollary) \d",p.text):
        p.paragraph_format.keep_with_next=True
    if p._p.find(qn("m:oMathPara")) is not None:
        p.paragraph_format.keep_together=True
        p.paragraph_format.space_before=Pt(4)
        p.paragraph_format.space_after=Pt(7)
    if p.style.name.startswith(("Heading","Title","Subtitle")):
        for r in p.runs:
            r.font.color.rgb=RGBColor(0,0,0)
            r.font.underline=False
            for b in list(r._r.findall(qn("w:rPr")+"/"+qn("w:color"))):b.attrib.pop(qn("w:themeColor"),None)
# Remove inherited theme fonts and the stock Title bottom border.
for st in doc.styles:
    for fonts in st.element.iter(qn("w:rFonts")):
        for attr in list(fonts.attrib):
            if etree.QName(attr).localname.lower().endswith("theme"):
                del fonts.attrib[attr]
    for border in list(st.element.iter(qn("w:pBdr"))):
        border.getparent().remove(border)
for name in ("Title","Subtitle","Heading 1","Heading 2","Heading 3"):
    st=doc.styles[name]
    st.font.name="Times New Roman";st.font.color.rgb=RGBColor(0,0,0);st.font.underline=False
    for spacing in list(st.element.findall(".//"+qn("w:rPr")+"/"+qn("w:spacing"))):
        spacing.getparent().remove(spacing)
doc.styles["Subtitle"].font.italic=False
for p in doc.paragraphs:
    if p.style.name in ("Title","Subtitle"):
        for border in list(p._p.iter(qn("w:pBdr"))):border.getparent().remove(border)
    if p._p.getprevious() is not None and p._p.getprevious().tag==qn("w:tbl"):
        p.paragraph_format.space_before=Pt(6)
M="http://schemas.openxmlformats.org/officeDocument/2006/math"
PPR=("pStyle keepNext keepLines pageBreakBefore framePr widowControl numPr suppressLineNumbers pBdr shd tabs suppressAutoHyphens "
     "kinsoku wordWrap overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi adjustRightInd snapToGrid spacing ind "
     "contextualSpacing mirrorIndents suppressOverlap jc textDirection textAlignment textboxTightWrap outlineLvl divId "
     "cnfStyle rPr sectPr pPrChange").split()
def reorder(parent,order):
    for e in sorted(list(parent),key=lambda x:order.index(etree.QName(x).localname) if etree.QName(x).localname in order else 99):
        parent.append(e)
for p in doc.element.body.iter(qn("w:pPr")):reorder(p,PPR)
for pr in doc.element.body.iter(f"{{{M}}}rPr"):
    if pr.find(f"{{{M}}}nor") is not None:
        for e in pr.findall(f"{{{M}}}sty")+pr.findall(f"{{{M}}}scr"):pr.remove(e)
    reorder(pr,["lit","nor","scr","sty","brk","aln"])
for pr in doc.element.body.iter(f"{{{M}}}dPr"):reorder(pr,["begChr","sepChr","endChr","grow","shp","ctrlPr"])
for pr in doc.element.body.iter(f"{{{M}}}mcPr"):reorder(pr,["count","mcJc"])
for r in doc.element.body.iter(f"{{{M}}}r"):
    if re.fullmatch(r"\(\d+\.\d+\)",r.findtext(f"{{{M}}}t") or ""):
        pr=r.find(f"{{{M}}}rPr")
        if pr is None:pr=etree.Element(f"{{{M}}}rPr");r.insert(0,pr)
        for e in list(pr):pr.remove(e)
        sty=etree.SubElement(pr,f"{{{M}}}sty");sty.set(f"{{{M}}}val","p")
doc.core_properties.title="Autoregressive Do Calculus (ADC)"
doc.core_properties.subject="Clock certificates and credal precision for event generators"
doc.core_properties.author="Debi Prasad Ghosh"
doc.core_properties.keywords="do-calculus; autoregressive generation; causal identification; sheaves; credal sets"
doc.core_properties.created=doc.core_properties.modified=datetime(2026,10,30,tzinfo=timezone.utc)
doc.save(target)

with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for name in z.namelist():
        if name.endswith(".xml"):etree.fromstring(z.read(name))
    x=etree.fromstring(z.read("word/document.xml"))
    text=" ".join(x.itertext())
    assert not re.search(r"\{\{[A-Z_]+\}\}|\[\[(TABLE|FIGURE)_|\bgenui\b",text)
    counts={"inline_and_display_equations":len(x.findall(".//"+qn("m:oMath"))),
            "display_equations":len(x.findall(".//"+qn("m:oMathPara"))),
            "tables":len(x.findall(".//"+qn("w:tbl"))),
            "figures":len(x.findall(".//"+qn("w:drawing")))}
audit={"zip_and_xml":True,"counts":counts,"filled_values":fills,
       "statement_inventory":re.findall(r"^\*\*((?:Definition|Theorem|Proposition|Lemma|Corollary) \d+\.\d+)",md,re.M)}
assert len(audit["statement_inventory"])==len(set(audit["statement_inventory"]))
(ROOT/"document_audit.json").write_text(json.dumps(audit,indent=2))
print(json.dumps({"path":str(target),"words":len(md.split()),**counts},indent=2))
