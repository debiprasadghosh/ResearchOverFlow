// The seven-line ID recursion of Shpitser and Pearl (2006), evaluated as exact finite kernels.
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;

namespace Tcr;

public abstract record Formula;
public sealed record Joint : Formula;
public sealed record Marginal(int Variables,Formula Child) : Formula;
public sealed record Product(ImmutableArray<Formula> Children) : Formula;
public sealed record Ratio(Formula Numerator,Formula Denominator) : Formula;
public sealed record TabKernel(int N,ImmutableArray<Q> Values,Formula Expression)
{
    public TabKernel Sum(int variables)
    {
        if(variables==0)return this;
        var a=Values.ToArray();
        foreach(int i in SetBits.Of(variables))
            for(int b=0;b<a.Length;b++)if((b&(1<<i))==0)
            {Q s=a[b]+a[b|(1<<i)];a[b]=s;a[b|(1<<i)]=s;}
        return new(N,a.ToImmutableArray(),new Marginal(variables,Expression));
    }
    public TabKernel Divide(TabKernel other)
    {
        if(other.N!=N || other.Values.Any(q=>q<=Q.Zero))throw new ArgumentException("positive compatible denominator required");
        return new(N,Values.Select((q,i)=>q/other.Values[i]).ToImmutableArray(),new Ratio(Expression,other.Expression));
    }
    public static TabKernel Multiply(int n,IEnumerable<TabKernel> kernels)
    {
        var k=kernels.ToImmutableArray();
        return new(n,Enumerable.Range(0,1<<n).Select(i=>k.Aggregate(Q.One,(a,b)=>a*b.Values[i])).ToImmutableArray(),
            new Product(k.Select(t=>t.Expression).ToImmutableArray()));
    }
    public TabKernel PrefixFactor(int active,int i)
    {
        int after=active&~((1<<(i+1))-1);
        return Sum(after).Divide(Sum(after|(1<<i)));
    }
}
public readonly record struct IdCall(int Line,int Vertices,int Outcomes,int Actions,int Conditioning=0,int Exchanged=0);
public sealed record IdAnswer(bool Identified,TabKernel? Kernel,ImmutableArray<IdCall> Trace,int FailureVertices,int FailureDistrict);
public sealed class IdFailure(int vertices,int district) : Exception
{
    public int Vertices {get;}=vertices;
    public int District {get;}=district;
}
public static class Identification
{
    // IDC first applies Rule 2, then normalises a joint ID result. Classical conditional completeness.
    public static IdAnswer Conditional(int y,int x,int z,TabKernel p,Admg g)
    {
        if(((x&y)|(x&z)|(y&z))!=0)throw new ArgumentException("disjoint query sets required");
        if(z==0)return Run(y,x,p,g);
        foreach(int i in SetBits.Of(z))
        {
            int bit=1<<i;
            if(!g.Rule(2,y,x,bit,z&~bit))continue;
            var next=Conditional(y,x|bit,z&~bit,p,g);
            return next with {Trace=next.Trace.Insert(0,new(8,g.V,y,x,z,bit))};
        }
        var joint=Run(y|z,x,p,g);
        if(!joint.Identified)return joint;
        return joint with {Kernel=joint.Kernel!.Divide(joint.Kernel.Sum(y)),
            Trace=joint.Trace.Add(new(9,g.V,y,x,z))};
    }
    public static IdAnswer Run(int y,int x,TabKernel p,Admg g)
    {
        var trace=new List<IdCall>();
        TabKernel Go(int yy,int xx,TabKernel pp,Admg gg)
        {
            int v=gg.V;
            void Note(int line)=>trace.Add(new(line,v,yy,xx));
            if(xx==0){Note(1);return pp.Sum(v&~yy);}
            int a=gg.Ancestors(yy);
            if(a!=v){Note(2);return Go(yy,xx&a,pp.Sum(v&~a),gg.Induced(a));}
            int w=(v&~xx)&~gg.Induced(v&~xx).Ancestors(yy);
            if(w!=0){Note(3);return Go(yy,xx|w,pp,gg);}
            var districts=gg.Induced(v&~xx).Districts();
            if(districts.Length>1)
            {
                Note(4);
                return TabKernel.Multiply(gg.N,districts.Select(s=>Go(s,v&~s,pp,gg))).Sum(v&~(yy|xx));
            }
            int s=districts.Single();var original=gg.Districts();
            if(original.Length==1){Note(5);throw new IdFailure(v,s);}
            if(original.Contains(s))
            {
                Note(6);
                return TabKernel.Multiply(gg.N,SetBits.Of(s).Select(i=>pp.PrefixFactor(v,i))).Sum(s&~yy);
            }
            int larger=original.Single(c=>(c&s)==s);
            Note(7);
            var q=TabKernel.Multiply(gg.N,SetBits.Of(larger).Select(i=>pp.PrefixFactor(v,i)));
            return Go(yy,xx&larger,q,gg.Induced(larger));
        }
        if((y&x)!=0 || ((y|x)&~g.V)!=0)throw new ArgumentException("invalid query");
        try{return new(true,Go(y,x,p,g),trace.ToImmutableArray(),0,0);}
        catch(IdFailure f){return new(false,null,trace.ToImmutableArray(),f.Vertices,f.District);}
    }
}
