// Finite ordered ADMGs. Public values are immutable; moralisation uses local scratch storage.
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;

namespace Tcr;

public readonly record struct Edge(int From, int To);
public static class SetBits
{
    public static IEnumerable<int> Of(int s) => Enumerable.Range(0, 30).Where(i => (s & (1 << i)) != 0);
    public static int Count(int s) => Of(s).Count();
}
public sealed record Admg(int N, int V, ImmutableArray<Edge> D, ImmutableArray<Edge> B)
{
    public static Admg Make(int n, IEnumerable<Edge> directed, IEnumerable<Edge> bidirected)
    {
        if (n < 1 || n > 12) throw new ArgumentOutOfRangeException(nameof(n));
        var d = directed.Distinct().OrderBy(e => e.From).ThenBy(e => e.To).ToImmutableArray();
        var b = bidirected.Select(e => new Edge(Math.Min(e.From,e.To),Math.Max(e.From,e.To)))
            .Distinct().OrderBy(e => e.From).ThenBy(e => e.To).ToImmutableArray();
        if (d.Concat(b).Any(e => e.From < 0 || e.To >= n || e.From >= e.To))
            throw new ArgumentException("Use distinct vertices and a topological numbering");
        return new(n,(1<<n)-1,d,b);
    }
    public Admg Induced(int s)
    {
        s &= V;
        bool Both(Edge e) => ((s >> e.From)&1)!=0 && ((s >> e.To)&1)!=0;
        return this with { V=s,D=D.Where(Both).ToImmutableArray(),B=B.Where(Both).ToImmutableArray() };
    }
    public Admg Mutilate(int incoming, int outgoing)
    {
        return this with {
            D=D.Where(e => ((incoming >> e.To)&1)==0 && ((outgoing >> e.From)&1)==0).ToImmutableArray(),
            B=B.Where(e => ((incoming >> e.From)&1)==0 && ((incoming >> e.To)&1)==0).ToImmutableArray()
        };
    }
    public int Ancestors(int s)
    {
        s &= V; int old;
        do { old=s; foreach(var e in D) if((s&(1<<e.To))!=0)s|=1<<e.From; } while(s!=old);
        return s;
    }
    public ImmutableArray<int> Districts()
    {
        var answer=ImmutableArray.CreateBuilder<int>(); int remain=V;
        while(remain!=0)
        {
            int s=1<<SetBits.Of(remain).First(),old;
            do
            {
                old=s;
                foreach(var e in B)
                    if((s&((1<<e.From)|(1<<e.To)))!=0)s|=(1<<e.From)|(1<<e.To);
            }while(s!=old);
            answer.Add(s);remain&=~s;
        }
        return answer.ToImmutable();
    }
    public bool Separated(int y,int z,int conditioned)
    {
        y&=V;z&=V;conditioned&=V;
        if((y&z)!=0 || ((y|z)&conditioned)!=0)throw new ArgumentException("disjoint query sets required");
        if(y==0 || z==0)return true;
        int size=N+B.Length;
        var arrows=D.ToList();
        for(int k=0;k<B.Length;k++)
        {
            arrows.Add(new(N+k,B[k].From));arrows.Add(new(N+k,B[k].To));
        }
        var ancestors=new HashSet<int>(SetBits.Of(y|z|conditioned));
        bool changed;
        do
        {
            changed=false;
            foreach(var e in arrows)if(ancestors.Contains(e.To))changed|=ancestors.Add(e.From);
        }while(changed);
        var moral=new bool[size,size];
        foreach(int child in ancestors)
        {
            var parents=arrows.Where(e=>e.To==child).Select(e=>e.From).ToArray();
            foreach(int parent in parents)moral[parent,child]=moral[child,parent]=true;
            foreach(int a in parents)foreach(int b in parents)if(a!=b)moral[a,b]=true;
        }
        var seen=new HashSet<int>(SetBits.Of(y));var queue=new Queue<int>(seen);
        while(queue.Count!=0)
        {
            int v=queue.Dequeue();if(v<N && (z&(1<<v))!=0)return false;
            foreach(int w in ancestors)
                if(moral[v,w] && !(w<N && (conditioned&(1<<w))!=0) && seen.Add(w))queue.Enqueue(w);
        }
        return true;
    }
    public bool Rule(int rule,int y,int x,int z,int w)
    {
        if(new[]{y,x,z,w}.SelectMany(SetBits.Of).GroupBy(i=>i).Any(g=>g.Count()>1))
            throw new ArgumentException("rule sets must be disjoint");
        var h=Mutilate(x,0);
        return rule switch {
            1 => h.Separated(y,z,x|w),
            2 => Mutilate(x,z).Separated(y,z,x|w),
            3 => Mutilate(x|(z&~h.Ancestors(w)),0).Separated(y,z,x|w),
            _ => throw new ArgumentOutOfRangeException(nameof(rule))
        };
    }
    public bool PrefixExchange(int s)
    {
        int h=V&((1<<s)-1),future=V&~((1<<(s+1))-1);
        return Mutilate(0,1<<s).Separated(future,1<<s,h);
    }
    public bool LastInDistrict(int s) =>
        (Districts().Single(d=>(d&(1<<s))!=0)&~((1<<(s+1))-1))==0;
}
