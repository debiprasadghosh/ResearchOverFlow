// Clocks: the earliest-clock recursion of Theorem 3.2 and its path witness, and the simple
// temporal network (difference constraints) with interval dates, upper lags and exact minimal
// networks by Floyd-Warshall over the rationals (Dechter, Meiri and Pearl, 1991).
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;

namespace Tcr;

public static class Clock
{
    /// <summary>Theorem 3.2 with predecessor pointers. Returns the earliest clock, feasibility and,
    /// if infeasible, the witness path ending at the first violating node.</summary>
    public static (ImmutableArray<Q> E, bool Feasible, ImmutableArray<int> Witness) Earliest(
        int n, ImmutableArray<(int From, int To, Q Lag)> edges, ImmutableArray<Q> lo, ImmutableArray<Q> hi)
    {
        var e = new Q[n]; var pred = new int[n];
        var incoming = edges.ToLookup(x => x.To);
        for (int v = 0; v < n; v++)
        {
            (e[v], pred[v]) = (lo[v], -1);
            foreach (var ed in incoming[v])
                if (e[ed.From] + ed.Lag > e[v]) (e[v], pred[v]) = (e[ed.From] + ed.Lag, ed.From);
        }
        int bad = Enumerable.Range(0, n).FirstOrDefault(v => e[v] > hi[v], -1);
        var path = new List<int>();
        for (int v = bad; v >= 0; v = pred[v]) path.Add(v);
        path.Reverse();
        return (e.ToImmutableArray(), bad < 0, path.ToImmutableArray());
    }
}

/// <summary>A simple temporal network over event times t_1..t_n and the origin t_0 = 0.
/// Constraint (i, j, c) means t_j - t_i &lt;= c.</summary>
public sealed record Stn(int N, ImmutableArray<(int I, int J, Q C)> Cons)
{
    public static Stn Build(int n, IEnumerable<(int Ev, Q Lo, Q Hi)> dates,
        IEnumerable<(int From, int To, Q MinLag, Q? MaxLag)> lags)
    {
        var c = new List<(int, int, Q)>();
        foreach (var (ev, l, h) in dates) { c.Add((0, ev, h)); c.Add((ev, 0, -l)); }
        foreach (var (f, t, mn, mx) in lags) { c.Add((t, f, -mn)); if (mx is Q m) c.Add((f, t, m)); }
        return new(n + 1, c.ToImmutableArray());
    }

    /// <summary>All-pairs shortest distances; null entries are +infinity.</summary>
    public Q?[,] Distances()
    {
        var d = new Q?[N, N];
        for (int i = 0; i < N; i++) d[i, i] = Q.Zero;
        foreach (var (i, j, c) in Cons) if (d[i, j] is not Q x || c < x) d[i, j] = c;
        for (int k = 0; k < N; k++) for (int i = 0; i < N; i++) for (int j = 0; j < N; j++)
            if (d[i, k] is Q a && d[k, j] is Q b && (d[i, j] is not Q x || a + b < x)) d[i, j] = a + b;
        return d;
    }
    public static bool Consistent(Q?[,] d) => Enumerable.Range(0, d.GetLength(0)).All(i => d[i, i] is Q x && x.Sign >= 0);

    /// <summary>Minimal-network bounds of t_v: [-d(v,0), d(0,v)].</summary>
    public static (Q Lo, Q Hi) Window(Q?[,] d, int v) => !Consistent(d)
        ? throw new InvalidOperationException("inconsistent temporal network")
        : (-(d[v, 0] ?? throw new InvalidOperationException()), d[0, v] ?? throw new InvalidOperationException());

    /// <summary>Lower bound of t_b - t_a in the minimal network, i.e. -d(b, a).</summary>
    public static Q? MinGap(Q?[,] d, int a, int b) => !Consistent(d)
        ? throw new InvalidOperationException("inconsistent temporal network")
        : d[b, a] is Q x ? -x : null;

    /// <summary>A negative cycle as a node list, by Bellman-Ford from a virtual source.</summary>
    public ImmutableArray<int> NegativeCycle()
    {
        var dist = Enumerable.Repeat(Q.Zero, N).ToArray(); var pred = Enumerable.Repeat(-1, N).ToArray(); int last = -1;
        for (int it = 0; it < N; it++)
        {
            last = -1;
            foreach (var (i, j, c) in Cons) if (dist[i] + c < dist[j]) { dist[j] = dist[i] + c; pred[j] = i; last = j; }
        }
        if (last < 0) return ImmutableArray<int>.Empty;
        int y = last; for (int k = 0; k < N; k++) y = pred[y];
        var cyc = new List<int> { y };
        for (int v = pred[y]; v != y; v = pred[v]) cyc.Insert(0, v);
        cyc.Insert(0, y);
        return cyc.ToImmutableArray();
    }
}
