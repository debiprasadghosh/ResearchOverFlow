// Exact arithmetic for the temporal causal sheaf: rationals over BigInteger, outward-rounded
// intervals over double, and exact rank by Gaussian elimination over the rationals. Values are immutable.
using System;
using System.Collections.Immutable;
using System.Linq;
using System.Numerics;

namespace Tcr;

/// <summary>An exact rational number in lowest terms with positive denominator.</summary>
public readonly record struct Q : IComparable<Q>
{
    public BigInteger Num { get; }
    public BigInteger Den { get; }

    public Q(BigInteger num, BigInteger den)
    {
        if (den.IsZero) throw new DivideByZeroException("zero denominator");
        if (den.Sign < 0) { num = -num; den = -den; }
        var g = BigInteger.GreatestCommonDivisor(num, den);
        if (!g.IsOne && !g.IsZero) { num /= g; den /= g; }
        Num = num; Den = num.IsZero ? BigInteger.One : den;
    }

    public static readonly Q Zero = new(0, 1), One = new(1, 1);
    public static implicit operator Q(int k) => new(k, 1);
    public static Q Of(long p, long q = 1) => new(p, q);
    public static Q operator +(Q a, Q b) => new(a.Num * b.Den + b.Num * a.Den, a.Den * b.Den);
    public static Q operator -(Q a, Q b) => new(a.Num * b.Den - b.Num * a.Den, a.Den * b.Den);
    public static Q operator -(Q a) => new(-a.Num, a.Den);
    public static Q operator *(Q a, Q b) => new(a.Num * b.Num, a.Den * b.Den);
    public static Q operator /(Q a, Q b) => new(a.Num * b.Den, a.Den * b.Num);
    public static bool operator <(Q a, Q b) => a.CompareTo(b) < 0;
    public static bool operator >(Q a, Q b) => a.CompareTo(b) > 0;
    public static bool operator <=(Q a, Q b) => a.CompareTo(b) <= 0;
    public static bool operator >=(Q a, Q b) => a.CompareTo(b) >= 0;
    public int CompareTo(Q o) => (Num * o.Den).CompareTo(o.Num * Den);
    public bool IsZero => Num.IsZero;
    public int Sign => Num.Sign;
    public static Q Max(Q a, Q b) => a >= b ? a : b;
    public static Q Min(Q a, Q b) => a <= b ? a : b;
    public static Q Floor(Q a) => new(BigInteger.Divide(a.Num - (a.Num.Sign < 0 ? a.Den - 1 : 0), a.Den), 1);
    /// <summary>Approximation for display and bounded dyadic studies, not a certificate predicate.</summary>
    public double ToDouble() => (double)Num / (double)Den;
    /// <summary>The exact rational value of a finite IEEE binary64 datum.</summary>
    public static Q FromDouble(double x)
    {
        if (!double.IsFinite(x)) throw new ArgumentOutOfRangeException(nameof(x), "finite datum required");
        ulong bits = unchecked((ulong)BitConverter.DoubleToInt64Bits(x));
        int e = (int)((bits >> 52) & 0x7ff);
        ulong fraction = bits & 0x000fffffffffffffUL;
        BigInteger n = e == 0 ? fraction : fraction | (1UL << 52);
        if ((bits >> 63) != 0) n = -n;
        int power = e == 0 ? -1074 : e - 1023 - 52;
        return power >= 0 ? new(n << power, BigInteger.One) : new(n, BigInteger.One << -power);
    }
    public override string ToString() => Den.IsOne ? Num.ToString() : $"{Num}/{Den}";
}

/// <summary>A closed interval [Lo, Hi] of reals. Every operation rounds outward by one unit in the
/// last place at each endpoint, so the result encloses the exact real range of the operation on
/// the exact endpoints.</summary>
public readonly record struct Iv
{
    public double Lo { get; }
    public double Hi { get; }
    /// <summary>This kernel supports finite closed endpoints and rejects invalid or overflowing results.</summary>
    public Iv(double lo, double hi)
    {
        if (!double.IsFinite(lo) || !double.IsFinite(hi) || lo > hi)
            throw new ArgumentOutOfRangeException(nameof(lo), "ordered finite interval endpoints required");
        Lo = lo; Hi = hi;
    }
    public static Iv Point(double x) => new(x, x);
    static double Dn(double x) => Math.BitDecrement(x);
    static double Up(double x) => Math.BitIncrement(x);

    /// <summary>Adjacent binary64 brackets of an exact rational, by integer division on the
    /// appropriate binary grid. Handles subnormals without converting either BigInteger to double.</summary>
    public static Iv Of(Q q)
    {
        if (q.Den.Sign <= 0) throw new ArgumentException("valid rational required");
        if (q.IsZero) return Point(0);
        if (q.Sign < 0) return -Of(-q);
        if (q > Q.FromDouble(double.MaxValue)) throw new OverflowException("no finite binary64 enclosure");
        int power;
        if (q < Q.FromDouble(Math.ScaleB(1.0, -1022))) power = -1074;
        else
        {
            int e = checked((int)(q.Num.GetBitLength() - q.Den.GetBitLength()));
            bool below = e >= 0 ? q.Num < (q.Den << e) : (q.Num << -e) < q.Den;
            if (below) e--;
            power = e - 52;
        }
        BigInteger numerator = q.Num, denominator = q.Den;
        if (power < 0) numerator <<= -power; else denominator <<= power;
        BigInteger k = BigInteger.DivRem(numerator, denominator, out var remainder);
        double lo = Math.ScaleB((double)k, power);
        return new(lo, remainder.IsZero ? lo : Math.BitIncrement(lo));
    }
    public static Iv Of(Q lo, Q hi) => lo > hi ? throw new ArgumentException("reversed rational interval") : new(Of(lo).Lo, Of(hi).Hi);
    public static Iv operator +(Iv a, Iv b) => new(Dn(a.Lo + b.Lo), Up(a.Hi + b.Hi));
    public static Iv operator -(Iv a, Iv b) => new(Dn(a.Lo - b.Hi), Up(a.Hi - b.Lo));
    public static Iv operator -(Iv a) => new(-a.Hi, -a.Lo);
    public static Iv operator *(Iv a, Iv b)
    {
        var p = new[] { a.Lo * b.Lo, a.Lo * b.Hi, a.Hi * b.Lo, a.Hi * b.Hi };
        return new(Dn(p.Min()), Up(p.Max()));
    }
    public static Iv operator /(Iv a, Iv b)
    {
        if (b.Lo <= 0 && b.Hi >= 0) throw new ArgumentException("divisor interval contains zero");
        var p = new[] { a.Lo / b.Lo, a.Lo / b.Hi, a.Hi / b.Lo, a.Hi / b.Hi };
        return new(Dn(p.Min()), Up(p.Max()));
    }
    public double Width => Hi - Lo;
    public bool Contains(Q q) => q.Den.Sign <= 0 ? throw new ArgumentException("valid rational required")
        : Q.FromDouble(Lo) <= q && q <= Q.FromDouble(Hi);
    public static Iv Hull(Iv a, Iv b) => new(Math.Min(a.Lo, b.Lo), Math.Max(a.Hi, b.Hi));
    public override string ToString() => $"{Lo:R} {Hi:R}";
}

/// <summary>A dense rational matrix held as an immutable row-major array.</summary>
public sealed record QMat(int Rows, int Cols, ImmutableArray<Q> A)
{
    public Q this[int i, int j] => A[i * Cols + j];
    public static QMat Of(int r, int c, Func<int, int, Q> f) =>
        new(r, c, Enumerable.Range(0, r * c).Select(k => f(k / c, k % c)).ToImmutableArray());
    public static QMat Identity(int n) => Of(n, n, (i, j) => i == j ? Q.One : Q.Zero);
    public QMat Mul(QMat b) => Of(Rows, b.Cols, (i, j) =>
        Enumerable.Range(0, Cols).Aggregate(Q.Zero, (s, k) => s + this[i, k] * b[k, j]));
    public QMat Sub(QMat b) => Of(Rows, Cols, (i, j) => this[i, j] - b[i, j]);
    public QMat Scale(Q s) => Of(Rows, Cols, (i, j) => s * this[i, j]);

    /// <summary>Exact rank by Gaussian elimination over the rationals (scratch copy only).</summary>
    public int Rank()
    {
        var m = A.ToArray(); int rank = 0;
        for (int col = 0; col < Cols && rank < Rows; col++)
        {
            int piv = Enumerable.Range(rank, Rows - rank).FirstOrDefault(r => !m[r * Cols + col].IsZero, -1);
            if (piv < 0) continue;
            for (int j = 0; j < Cols; j++) (m[rank * Cols + j], m[piv * Cols + j]) = (m[piv * Cols + j], m[rank * Cols + j]);
            for (int r = 0; r < Rows; r++)
            {
                if (r == rank || m[r * Cols + col].IsZero) continue;
                var f = m[r * Cols + col] / m[rank * Cols + col];
                for (int j = col; j < Cols; j++) m[r * Cols + j] = m[r * Cols + j] - f * m[rank * Cols + j];
            }
            rank++;
        }
        return rank;
    }

    /// <summary>Exact inverse by Gauss-Jordan elimination (throws if singular).</summary>
    public QMat Inverse()
    {
        int n = Rows; var m = new Q[n, 2 * n];
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) { m[i, j] = this[i, j]; m[i, n + j] = i == j ? Q.One : Q.Zero; }
        for (int c = 0; c < n; c++)
        {
            int p = Enumerable.Range(c, n - c).First(r => !m[r, c].IsZero);
            for (int j = 0; j < 2 * n; j++) (m[c, j], m[p, j]) = (m[p, j], m[c, j]);
            var inv = Q.One / m[c, c];
            for (int j = 0; j < 2 * n; j++) m[c, j] = m[c, j] * inv;
            for (int r = 0; r < n; r++)
            {
                if (r == c || m[r, c].IsZero) continue;
                var f = m[r, c];
                for (int j = 0; j < 2 * n; j++) m[r, j] = m[r, j] - f * m[c, j];
            }
        }
        return Of(n, n, (i, j) => m[i, n + j]);
    }
}

/// <summary>SplitMix64 counter stream; the k-th draw depends only on the seed and k.</summary>
public readonly record struct Rng(ulong State)
{
    public (ulong, Rng) Next()
    {
        ulong s = State + 0x9E3779B97F4A7C15UL, z = s;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
        return (z ^ (z >> 31), new Rng(s));
    }
    public (double, Rng) Uniform() { var (u, r) = Next(); return ((u >> 11) * (1.0 / 9007199254740992.0), r); }
    /// <summary>Integer uniform on [lo, hi] by the top 53 bits (bias below 2^-40 for small ranges).</summary>
    public (int, Rng) Int(int lo, int hi) { var (u, r) = Uniform(); return (lo + (int)Math.Floor(u * (hi - lo + 1)), r); }
}
