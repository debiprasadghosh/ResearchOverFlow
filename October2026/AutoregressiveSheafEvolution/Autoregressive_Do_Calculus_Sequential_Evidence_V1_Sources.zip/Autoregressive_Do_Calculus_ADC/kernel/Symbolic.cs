// Symbolic computation: exact multivariate polynomials over the rationals, expression trees whose
// interval evaluation exposes the dependency problem, and a greedy Horner factorisation that
// reduces repeated occurrences of a variable.
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;

namespace Tcr;

/// <summary>A monomial as a sorted list of (variable, power) pairs.</summary>
public sealed record Mono(ImmutableArray<(int Var, int Pow)> Factors)
{
    public static readonly Mono Unit = new(ImmutableArray<(int, int)>.Empty);
    public static Mono Of(int v) => new(ImmutableArray.Create((v, 1)));
    public string Key => string.Join("*", Factors.Select(f => $"{f.Var}^{f.Pow}"));
    public int Degree(int v) => Factors.Where(f => f.Var == v).Select(f => f.Pow).DefaultIfEmpty(0).Single();
    public Mono Times(Mono o) => new(Factors.Concat(o.Factors).GroupBy(f => f.Var)
        .Select(g => (g.Key, g.Sum(f => f.Pow))).OrderBy(f => f.Key).ToImmutableArray());
    public Mono Without(int v) => new(Factors.Select(f => f.Var == v ? (f.Var, f.Pow - 1) : f)
        .Where(f => f.Item2 > 0).ToImmutableArray());
    public bool Equals(Mono? o) => o is not null && Key == o.Key;
    public override int GetHashCode() => Key.GetHashCode();
}

/// <summary>A polynomial: an immutable map from monomials to nonzero rational coefficients.</summary>
public sealed record Poly(ImmutableDictionary<Mono, Q> Terms)
{
    public static readonly Poly Zero = new(ImmutableDictionary<Mono, Q>.Empty);
    public static Poly Const(Q c) => c.IsZero ? Zero : new(ImmutableDictionary<Mono, Q>.Empty.Add(Mono.Unit, c));
    public static Poly Var(int v) => new(ImmutableDictionary<Mono, Q>.Empty.Add(Mono.Of(v), Q.One));
    public static Poly operator +(Poly a, Poly b) => new(b.Terms.Aggregate(a.Terms, (d, t) =>
    {
        var c = (d.TryGetValue(t.Key, out var x) ? x : Q.Zero) + t.Value;
        return c.IsZero ? d.Remove(t.Key) : d.SetItem(t.Key, c);
    }));
    public static Poly operator *(Poly a, Poly b) => a.Terms.SelectMany(s => b.Terms.Select(t =>
        new Poly(ImmutableDictionary<Mono, Q>.Empty.Add(s.Key.Times(t.Key), s.Value * t.Value))))
        .Aggregate(Zero, (x, y) => x + y);
    public static Poly operator -(Poly a, Poly b) => a + b * Const(-1);
    public IEnumerable<int> Vars => Terms.Keys.SelectMany(m => m.Factors.Select(f => f.Var)).Distinct().OrderBy(v => v);
    public int MaxDegreeInAnyVar => Terms.Keys.SelectMany(m => m.Factors.Select(f => f.Pow)).DefaultIfEmpty(0).Max();
    public Q Eval(Func<int, Q> x) => Terms.Aggregate(Q.Zero, (s, t) =>
        s + t.Key.Factors.Aggregate(t.Value, (p, f) => Enumerable.Range(0, f.Pow).Aggregate(p, (pp, _) => pp * x(f.Var))));
    public double EvalD(Func<int, double> x) => Terms.Sum(t =>
        t.Key.Factors.Aggregate(t.Value.ToDouble(), (p, f) => p * Math.Pow(x(f.Var), f.Pow)));
    /// <summary>Univariate coefficient list, lowest power first.</summary>
    public ImmutableArray<Q> Coefficients(int v)
    {
        int d = Terms.Keys.Select(m => m.Degree(v)).DefaultIfEmpty(0).Max();
        return Enumerable.Range(0, d + 1).Select(k => Terms.Where(t => t.Key.Degree(v) == k)
            .Aggregate(Q.Zero, (s, t) => s + t.Value)).ToImmutableArray();
    }
    public bool Equal(Poly o) => (this - o).Terms.Count == 0;
    public override string ToString() => Terms.Count == 0 ? "0" : string.Join(" + ", Terms
        .OrderBy(t => t.Key.Key).Select(t => $"{t.Value}" + (t.Key.Factors.Length == 0 ? "" : "·" + t.Key.Key)));
}

/// <summary>An expression tree. Interval evaluation treats every occurrence of a variable as
/// independent, which is why the form of an expression changes the width of its enclosure.</summary>
public abstract record Expr
{
    public sealed record C(Q Value) : Expr;
    public sealed record V(int Index) : Expr;
    public sealed record Sum(ImmutableArray<Expr> Items) : Expr;
    public sealed record Prod(ImmutableArray<Expr> Items) : Expr;

    public static Expr Add(params Expr[] e) => e.Length == 1 ? e[0] : new Sum(e.ToImmutableArray());
    public static Expr Mul(params Expr[] e) => e.Length == 1 ? e[0] : new Prod(e.ToImmutableArray());
    public static Expr Neg(Expr e) => Mul(new C(-1), e);

    public Iv Eval(Func<int, Iv> x) => this switch
    {
        C c => Iv.Of(c.Value),
        V v => x(v.Index),
        Sum s => s.Items.Skip(1).Aggregate(s.Items[0].Eval(x), (a, e) => a + e.Eval(x)),
        Prod p => p.Items.Skip(1).Aggregate(p.Items[0].Eval(x), (a, e) => a * e.Eval(x)),
        _ => throw new InvalidOperationException()
    };
    public Q EvalQ(Func<int, Q> x) => this switch
    {
        C c => c.Value, V v => x(v.Index),
        Sum s => s.Items.Aggregate(Q.Zero, (a, e) => a + e.EvalQ(x)),
        Prod p => p.Items.Aggregate(Q.One, (a, e) => a * e.EvalQ(x)),
        _ => throw new InvalidOperationException()
    };
    public Poly ToPoly() => this switch
    {
        C c => Poly.Const(c.Value), V v => Poly.Var(v.Index),
        Sum s => s.Items.Aggregate(Poly.Zero, (a, e) => a + e.ToPoly()),
        Prod p => p.Items.Aggregate(Poly.Const(Q.One), (a, e) => a * e.ToPoly()),
        _ => throw new InvalidOperationException()
    };
    /// <summary>Number of leaves naming each variable (a tree size, counting shared subtrees once per use).</summary>
    public int Occurrences(int v) => this switch
    {
        V x => x.Index == v ? 1 : 0, C => 0,
        Sum s => s.Items.Sum(e => e.Occurrences(v)), Prod p => p.Items.Sum(e => e.Occurrences(v)),
        _ => 0
    };
    public int MaxOccurrence(IEnumerable<int> vars) => vars.Select(Occurrences).DefaultIfEmpty(0).Max();

    /// <summary>The expanded form: a sum of monomials, each a product of its variables.</summary>
    public static Expr Expanded(Poly p) => p.Terms.Count == 0 ? new C(Q.Zero) : Add(p.Terms.OrderBy(t => t.Key.Key)
        .Select(t => MonoExpr(t.Key, t.Value)).ToArray());
    static Expr MonoExpr(Mono m, Q c)
    {
        var vs = m.Factors.SelectMany(f => Enumerable.Repeat<Expr>(new V(f.Var), f.Pow)).ToList();
        if (vs.Count == 0) return new C(c);
        if (c != Q.One) vs.Insert(0, new C(c));
        return Mul(vs.ToArray());
    }

    /// <summary>Greedy Horner factorisation: repeatedly pull out the variable shared by the most
    /// monomials. The result is algebraically identical to the polynomial.</summary>
    public static Expr Horner(Poly p)
    {
        if (p.Terms.Count <= 1) return Expanded(p);
        var best = p.Vars.Select(v => (v, n: p.Terms.Keys.Count(m => m.Degree(v) > 0)))
            .OrderByDescending(t => t.n).ThenBy(t => t.v).First();
        if (best.n < 2) return Expanded(p);
        var with = new Poly(p.Terms.Where(t => t.Key.Degree(best.v) > 0)
            .ToImmutableDictionary(t => t.Key.Without(best.v), t => t.Value));
        var rest = new Poly(p.Terms.Where(t => t.Key.Degree(best.v) == 0).ToImmutableDictionary());
        var head = Mul(new V(best.v), Horner(with));
        return rest.Terms.Count == 0 ? head : Add(head, Horner(rest));
    }
}

/// <summary>Exact range of a multilinear polynomial over a box, by enumeration of the vertices.
/// A multilinear function is affine in each variable separately, so its extremes over a box are
/// attained at vertices.</summary>
public static class Vertex
{
    public static (Q Lo, Q Hi) Range(Poly p, Func<int, (Q Lo, Q Hi)> box)
    {
        var vars = p.Vars.ToArray();
        if (p.MaxDegreeInAnyVar > 1) throw new ArgumentException("polynomial is not multilinear");
        if (vars.Length >= 63) throw new ArgumentOutOfRangeException(nameof(p), "signed 64-bit vertex mask supports at most 62 variables");
        Q lo = Q.Zero, hi = Q.Zero; bool first = true;
        for (long mask = 0; mask < 1L << vars.Length; mask++)
        {
            var pick = vars.Select((v, i) => (v, ((mask >> i) & 1) == 0 ? box(v).Lo : box(v).Hi)).ToDictionary(t => t.v, t => t.Item2);
            var val = p.Eval(v => pick[v]);
            if (first) { lo = hi = val; first = false; } else { lo = Q.Min(lo, val); hi = Q.Max(hi, val); }
        }
        return (lo, hi);
    }

    /// <summary>The same enumeration in double arithmetic, exact when every vertex value is a
    /// short dyadic sum (asserted by the caller).</summary>
    public static (double Lo, double Hi) RangeD(Poly p, Func<int, (double Lo, double Hi)> box)
    {
        if (p.MaxDegreeInAnyVar > 1) throw new ArgumentException("polynomial is not multilinear");
        var vars = p.Vars.ToArray(); var idx = vars.Select((v, i) => (v, i)).ToDictionary(t => t.v, t => t.i);
        if (vars.Length >= 63) throw new ArgumentOutOfRangeException(nameof(p), "signed 64-bit vertex mask supports at most 62 variables");
        var terms = p.Terms.Select(t => (c: t.Value.ToDouble(), f: t.Key.Factors.Select(f => idx[f.Var]).ToArray())).ToArray();
        double lo = double.PositiveInfinity, hi = double.NegativeInfinity; var x = new double[vars.Length];
        for (long mask = 0; mask < 1L << vars.Length; mask++)
        {
            for (int i = 0; i < vars.Length; i++) x[i] = ((mask >> i) & 1) == 0 ? box(vars[i]).Lo : box(vars[i]).Hi;
            double val = 0;
            foreach (var (c, f) in terms) { double m = c; foreach (var k in f) m *= x[k]; val += m; }
            lo = Math.Min(lo, val); hi = Math.Max(hi, val);
        }
        return (lo, hi);
    }
}
