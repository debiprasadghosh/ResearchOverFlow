// Positive binary semi-Markovian models. Exact enumeration sums latent states with integer weights.
using System;
using System.Collections.Immutable;
using System.Linq;
using System.Numerics;

namespace Tcr;

public sealed record BinaryScm(Admg Graph,ImmutableArray<int> PrivateK,ImmutableArray<int> LatentK)
{
    public TabKernel Law(int actionMask=0,int values=0)
    {
        int n=Graph.N,m=Graph.B.Length;
        if(PrivateK.Length!=n || LatentK.Length!=m || PrivateK.Concat(LatentK).Any(k=>k<1 || k>3))
            throw new ArgumentException("Bernoulli numerators must lie in {1,2,3}");
        var result=ImmutableArray.CreateBuilder<Q>(1<<n);
        BigInteger denominator=BigInteger.Pow(4,n-SetBits.Count(actionMask)+m);
        for(int v=0;v<(1<<n);v++)
        {
            if(((v^values)&actionMask)!=0){result.Add(Q.Zero);continue;}
            BigInteger total=0;
            for(int u=0;u<(1<<m);u++)
            {
                BigInteger weight=1;
                for(int j=0;j<m;j++)weight*=((u>>j)&1)!=0?LatentK[j]:4-LatentK[j];
                for(int i=0;i<n;i++)
                {
                    if((actionMask&(1<<i))!=0)continue;
                    int noise=(v>>i)&1;
                    foreach(var e in Graph.D)if(e.To==i)noise^=(v>>e.From)&1;
                    for(int j=0;j<m;j++)if(Graph.B[j].From==i || Graph.B[j].To==i)noise^=(u>>j)&1;
                    weight*=noise!=0?PrivateK[i]:4-PrivateK[i];
                }
                total+=weight;
            }
            result.Add(new(total,denominator));
        }
        var a=result.ToImmutable();
        if(a.Aggregate(Q.Zero,(x,y)=>x+y)!=Q.One)throw new InvalidOperationException("law not normalized");
        return new(n,a,new Joint());
    }
    public static Q Mass(TabKernel law,int mask,int assignment) =>
        law.Values.Where((_,b)=>((b^assignment)&mask)==0).Aggregate(Q.Zero,(a,b)=>a+b);
    public static Q Conditional(TabKernel law,int y,int assignment,int w) =>
        Mass(law,y|w,assignment)/Mass(law,w,assignment);
    public static TabKernel Replacement(TabKernel p,int position,int value,int[]? order=null)
    {
        order ??= Enumerable.Range(0,p.N).ToArray();
        var result=ImmutableArray.CreateBuilder<Q>(1<<p.N);
        for(int b=0;b<(1<<p.N);b++)
        {
            Q q=Q.One;int prefix=0;
            foreach(int v in order)
            {
                q*=v==position?(((b>>v)&1)==value?Q.One:Q.Zero):Conditional(p,1<<v,b,prefix);
                prefix|=1<<v;
            }
            result.Add(q);
        }
        return new(p.N,result.ToImmutable(),new Joint());
    }
    public static Q Tv(TabKernel a,TabKernel b) =>
        a.Values.Select((q,i)=>(q-b.Values[i]).Sign<0?b.Values[i]-q:q-b.Values[i]).Aggregate(Q.Zero,(x,y)=>x+y)/2;
}
