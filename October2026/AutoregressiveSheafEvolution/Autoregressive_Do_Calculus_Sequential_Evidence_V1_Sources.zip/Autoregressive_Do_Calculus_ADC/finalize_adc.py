"""Audit the inspected artifact and assemble its reproducible source archive."""
from __future__ import annotations
import hashlib,json,re,shutil,zipfile
from pathlib import Path
from lxml import etree
import fitz

ROOT=Path(__file__).resolve().parent
DEST=ROOT/"deliverables"
DOCX=DEST/"Autoregressive_Do_Calculus_ADC.docx"
PDF=DEST/"Autoregressive_Do_Calculus_ADC.pdf"
shutil.copy2(ROOT/"render_verified"/PDF.name,PDF)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pages=fitz.open(PDF);flags=[];nonblack=[]
for i,page in enumerate(pages):
    assert "¿" not in page.get_text() and "\ufffd" not in page.get_text()
    for word in page.get_text("words"):
        if word[1]>745 or not word[4].strip():continue
        if word[0]<62.8 or word[2]>549.2 or word[1]<45 or word[3]>742:
            flags.append([i+1,*word[:5]])
    for block in page.get_text("dict")["blocks"]:
        for line in block.get("lines",[]):
            for span in line["spans"]:
                if span["color"]!=0:nonblack.append([i+1,span["text"],span["color"]])
assert len(pages)==22 and not flags and not nonblack,(flags,nonblack)
NS={"w":"http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "m":"http://schemas.openxmlformats.org/officeDocument/2006/math"}
with zipfile.ZipFile(DOCX) as z:
    assert z.testzip() is None
    for name in z.namelist():
        if name.endswith(".xml"):etree.fromstring(z.read(name))
    x=etree.fromstring(z.read("word/document.xml"))
    styles=etree.fromstring(z.read("word/styles.xml"))
    assert not styles.xpath("//w:style[@w:styleId='Title']//w:pBdr",namespaces=NS)
    assert not x.xpath("//m:rPr[m:nor and (m:sty or m:scr)]",namespaces=NS)
    alltext=" ".join(x.itertext())
    assert not re.search(r"\{\{[A-Z_]+\}\}|\[\[(?:TABLE|FIGURE)_|\bgenui\b|\\(?:setminus|operatorname|begin|qquad)",alltext)
    eqs=len(x.xpath("//m:oMath",namespaces=NS))
    assert eqs==328
    assert len(x.xpath("//w:tbl",namespaces=NS))==4
    for t in x.xpath("//w:tbl",namespaces=NS):
        assert t.xpath("./w:tr[1]/w:trPr/w:tblHeader",namespaces=NS)
        colors=t.xpath("./w:tblPr/w:tblBorders/*/@w:color",namespaces=NS)
        assert colors==["D9D9D9"]*6
assert not (ROOT/"pandoc.log").read_text().strip()
v=json.loads((ROOT/"validation_results.json").read_text())
r=json.loads((ROOT/"replay_results.json").read_text())
assert v["all_passed"] and r["all_identical"]
reviewed={1,2,3,8}
for n in reviewed:
    assert (ROOT/f"render_verified/page-{n}.png").read_bytes()==(ROOT/f"render_final/page-{n}.png").read_bytes()
qa={"pages":len(pages),"visually_reviewed_pages":list(range(1,23)),
    "identical_reused_review_pages":sorted(reviewed),"missing_symbol_flags":False,"margin_flags":flags,
    "nonblack_text":nonblack,"zip_and_xml_valid":True,"full_ooxml_schema_validation_claimed":False,
    "native_equations":eqs,"formal_statements":len(json.loads((ROOT/"document_audit.json").read_text())["statement_inventory"]),
    "docx_sha256":sha(DOCX),"pdf_sha256":sha(PDF),
    "page_image_sha256":{str(n):sha(ROOT/f"render_verified/page-{n}.png") for n in range(1,23)}}
(ROOT/"final_qa.json").write_text(json.dumps(qa,indent=2)+"\n")

# Keep the source bundle reproducible and exclude installed dependencies, SDKs and QA renders.
relative=["README.md","PROJECT_NOTE.md","requirements_validation.txt","requirements_document.txt",
          "validate_adc.py","build_adc.py","replay.py","finalize_adc.py",
          "paper.md","paper_filled.md","cs_results.txt","validation_results.json","validation.log",
          "replay_results.json","replay_build.log","document_audit.json","final_qa.json"]
files=[(ROOT/p,Path(p)) for p in relative]
for sub in ("kernel","output","figures"):
    for p in sorted((ROOT/sub).iterdir()):
        if p.is_file():files.append((p,p.relative_to(ROOT)))
files.append((ROOT.parent/"research/proposal.txt",Path("proposal.txt")))
assert all(p.is_file() for p,_ in files)
manifest={str(rel):sha(p) for p,rel in files}
archive=DEST/"Autoregressive_Do_Calculus_ADC_Sources.zip"
with zipfile.ZipFile(archive,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    prefix="Autoregressive_Do_Calculus_ADC/"
    for p,rel in files:z.write(p,prefix+str(rel))
    z.writestr(prefix+"MANIFEST_SHA256.json",json.dumps(manifest,indent=2)+"\n")
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for p,rel in files:
        assert hashlib.sha256(z.read("Autoregressive_Do_Calculus_ADC/"+str(rel))).hexdigest()==sha(p)
print(json.dumps({"pages":len(pages),"formal_statements":qa["formal_statements"],"files":[
    {"path":str(p),"bytes":p.stat().st_size,"sha256":sha(p)} for p in (DOCX,PDF,archive)]},indent=2))
