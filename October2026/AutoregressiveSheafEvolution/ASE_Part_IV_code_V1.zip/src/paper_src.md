---
title: "Targets and Estimation"
subtitle: "What Autoregressive Sheaf Evolution can estimate. Part IV: Gibbs targets, proposal laws, importance weights and error budgets"
author:
  - "Debi Prasad Ghosh"
  - "Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India"
date: "Defensible Intelligence series · Autoregressive Sheaf Evolution, Part IV · 21 October 2026 · “Respect science. Import emotion.”"
abstract: |
  Parts I to III of Autoregressive Sheaf Evolution (ASE) described what a layer stack computes. This paper, Part IV of the book, asks what it can estimate. The target is a Gibbs law $\pi_\beta\propto\rho\,e^{-\beta J}$ on designs, with a declared base law $\rho$ and loss $J$. A weighted archive estimates only the smoothed target $\pi_\beta*N(0,s^2I)$, and only as fast as its weights allow: in a two-dimensional double well, 40 records had an effective size of 2.7 and missed the target by 0.61 in total variation at the best width. The archive should therefore be a proposal, not a target. We prove that a clean-top stack cannot be one. Its outputs lie in the convex hull of the records it reads. When those records span fewer than $D$ dimensions, its law is singular and no importance weight exists. Reading the 8 best of 40 records left 79.5% of the target outside the hull. The archive density $p_s$ itself is exactly samplable with a known density, so estimation should draw from it directly rather than run a finite stack. For Gaussian mixtures, the second moment of the importance weights is finite when the width exceeds $\sigma/\sqrt2$, for the narrowest Gaussian direction $\sigma$ of the target, and infinite when it is below. A defensive component removes the infinity with the bound $1/(\varepsilon Z)$. Bounded critic error $\varepsilon$ moves the target by at most $\tanh(\beta\varepsilon/2)$ in total variation, and the bound is attained. Heteroscedastic Gaussian critic noise tilts the target by $e^{\beta^2\sigma(x)^2/2k}$; homoscedastic noise does not. Truncated proposal densities obey the same lemma with their log ratio. An error ledger combines these terms with the finite-sample bound of Agapiou and co-authors. In 9 configurations it was never exceeded, and it showed the error settling at the critic bias, not at the sampling error. There are 16 numerical checks and a width exploration, and an immutable C# kernel matches an independent NumPy implementation on every output line.
---

# 1 Introduction

Autoregressive Diffusion Evolution (ADE) proposes designs by running tokens down a denoising stack whose layers read an archive of evaluated designs [7, 8]. Autoregressive Sheaf Evolution (ASE) generalises each read to an observation star with edge maps and scale-dependent covers [9]. Part I separated the two axes of the stack [10]. Part II worked out one layer [11]. Part III stacked the layers and identified the law of the proposals: in the continuum limit, a deterministic stack with identity maps proposes from the archive density $p_{s_0}$, and a clean top re-selects archived records [12]. This paper, Part IV of the book, turns from the stack to the targets it serves. It asks which law a run is meant to sample, what an archive estimates, which proposals can be importance-weighted, and how errors in the critic and in the proposal density enter an estimate.

The questions matter because ADE and ASE are search procedures that are easily read as samplers. An archive weighted by $e^{-\beta J}$ looks like a sample from a Gibbs law, and a stack that transports one density to another looks like a generative model. Neither reading is automatic. Each needs a declared target, a proposal with a known density and full support, and an account of every source of error. Part IV supplies these for the identity-map geometry, and it records where the archive and the stack fail as estimators.

## 1.1 Contributions

- **Targets (Section 2).** We fix the Gibbs target $\pi_\beta\propto\rho\,e^{-\beta J}$ with a declared base law $\rho$. A weighted archive converges to the smoothed target $\pi_\beta*N(0,s^2I)$, not to $\pi_\beta$ (Proposition 2.3). Smoothing and a small effective archive size together make the archive a poor estimator of the target, so ASE should treat it as a proposal.
- **Proposals (Section 3).** A clean-top stack proposes only inside the convex hull of the records it reads. Its law is singular when they span fewer than $D$ dimensions, so it cannot be importance-weighted (Theorem 3.1). The archive density $p_s$ is exactly samplable with an explicit density (Proposition 3.2). For Gaussian mixtures we give the width threshold below which the weights have infinite second moment, whatever the records (Proposition 3.4). Defensive mixtures remove that infinity at a bounded cost (Theorem 3.5). A width scan on a double well locates the best proposal and compares it with the base law.
- **Critic and density error (Section 4).** One lemma covers every multiplicative weight error: if the log error spans an interval of width $\kappa$, the limiting law moves by at most $\tanh(\kappa/4)$ in total variation, and the bound is attained (Lemma 4.1). It gives the effect of bounded critic error (Proposition 4.2) and of truncated proposal densities (Proposition 4.4). Gaussian critic noise tilts the target exactly when it is heteroscedastic (Proposition 4.3).
- **An error ledger (Section 5).** Theorem 5.1 bounds the root-mean-square error of a self-normalised estimate by a critic term that does not shrink and a sampling term that does. It tells a run when to spend evaluations on the critic rather than on more samples.
- **Evidence.** There are 16 numerical checks besides the width exploration (Table 3). An immutable C# kernel agrees with an independent NumPy implementation on every output line (Appendix A).

## 1.2 Scope and status of statements

Statements use identity edge maps unless they say otherwise, and Gaussian components of a common width. Masks and general maps change the hull in which reads lie (Part II, Proposition 3.5), and Section 6.3 says what that does to the results. The paper proves statements about estimation; it makes no claim about search performance. The width exploration of Section 3.4 is a computation on one declared example, not a benchmark.

Every statement in a shaded box ends with a provenance tag. *Classical* marks a known result restated in ASE notation. *Part I*, *Part II* and *Part III* refer to [10], [11] and [12]. *New in Part IV* marks a statement proved here for the first time in this programme; each comes with a proof and a numerical check. All spaces are finite-dimensional and real, and all densities are with respect to Lebesgue measure.

## 1.3 Notation

Table: **Table 1.** Notation used throughout Part IV.

| Symbol | Meaning |
|:--------------------------|:--------------------------------------------------|
| $J\ge0,\ \rho,\ \beta$ | loss of a design, declared base law, inverse temperature |
| $\pi_\beta,\ Z$ | Gibbs target $\rho e^{-\beta J}/Z$ and its normaliser (Definition 2.1) |
| $y_i,\ w_i$ | archived records and their weights |
| $p_s$ | archive density $\sum_i\beta_iN(y_i,s^2I)$, $\beta_i=w_i/\sum_jw_j$ |
| $\varphi_s$ | the density of $N(0,s^2I)$ |
| $q,\ q_\varepsilon$ | proposal density and defensive mixture $(1-\varepsilon)q+\varepsilon\rho$ |
| $m_2(q)$ | second moment $E_q[(\pi_\beta/q)^2]=1+\chi^2(\pi_\beta\Vert q)$ |
| $\hat I_n(f)$ | self-normalised importance-sampling estimate from $n$ draws |
| $\text{TV}$ | total-variation distance |
| $\kappa$ | log-width of a multiplicative weight error (Lemma 4.1) |


# 2 Targets

## 2.1 The Gibbs target

ADE weights records by $e^{-\beta J}$ and calls the result a selection pressure [7]. A selection pressure is not yet a target. To estimate anything, a run must name the law it is estimating and the reference against which $e^{-\beta J}$ is a density.

::: {custom-style="Statement"}
**Definition 2.1** (Gibbs target). Let $J\ge0$ be a measurable loss on $ℝ^D$ and $\rho$ a declared probability density on $ℝ^D$, the base law. For $\beta>0$ with $Z=\int\rho\,e^{-\beta J}\,\text{d}x$, the *Gibbs target* is $\pi_\beta=\rho\,e^{-\beta J}/Z$. A run *estimates* $E_{\pi_\beta}f$ for declared test functions $f$.
:::

::: {custom-style="Statement Tag"}
Classical; the base law is the Mathematics book's reference measure [8], made explicit.
:::

The base law is a modelling choice with consequences. With $\rho$ uniform on a box, the target is the familiar Boltzmann law of the loss; with a Gaussian $\rho$, it is a posterior whose prior is $\rho$ and whose likelihood is $e^{-\beta J}$. Two runs with different $\rho$ estimate different targets, even with the same loss and temperature.

**The running example.** Throughout, $D=2$, $J(x)=(x_1^2-1)^2+\tfrac12x_2^2$, $\rho=N(0,4I)$ and $\beta=4$. The target has two modes, near $x_1=\pm1$, and it factorises: its $x_2$ factor is $N(0,\sigma^2)$ with $\sigma^2=1/(2(1/8+2))$, so $\sigma=0.485$. Quadrature on a grid of $961\times961$ points over $[-6,6]^2$ gives $Z=0.04093$, $E\,x_1^2=0.9004$ and $P(x_1>0.5)=0.4763$. The archive has 40 records drawn from $\rho$ and weighted by $e^{-\beta J}$, as Proposition 2.3 prescribes for records drawn from the base law.

## 2.2 What a weighted archive estimates

::: {custom-style="Statement"}
**Definition 2.2** (archive density). For records $y_1,\ldots,y_n$ with weights $w_i>0$ and a width $s>0$, the archive density is $p_s=\sum_i\beta_i\varphi_s(\cdot-y_i)$ with $\beta_i=w_i/\sum_jw_j$. Its effective size is $n_{\text{eff}}=(\sum_iw_i)^2/\sum_iw_i^2$.
:::

::: {custom-style="Statement Tag"}
Part III, Definition 2.1; the effective size is Kong's [4].
:::

::: {custom-style="Statement"}
**Proposition 2.3** (a weighted archive estimates the smoothed target). Let $y_1,y_2,\ldots$ be independent draws from a density $q$ that is positive wherever $\rho$ is, and let $w_i=\rho(y_i)e^{-\beta J(y_i)}/q(y_i)$. Then for every $s>0$ and every $x$, almost surely,
:::

::: {custom-style="Statement Equation"}
$p_s(x)\to(\pi_\beta*\varphi_s)(x)\qquad\text{as }n\to\infty$ (2.1)
:::

::: {custom-style="Statement"}
For $D=1$, $\rho=N(0,1)$ and $J(x)=x^2/2$, the limit is the density of $N(0,1/(1+\beta)+s^2)$.
:::

::: {custom-style="Statement Tag"}
Classical, the strong law for self-normalised importance weights [16] applied to a kernel estimate [15].
:::

*Proof.* By the strong law, $n^{-1}\sum_iw_i\varphi_s(x-y_i)\to\int q\,(\rho e^{-\beta J}/q)\,\varphi_s(x-\cdot)=Z\,(\pi_\beta*\varphi_s)(x)$ and $n^{-1}\sum_iw_i\to Z>0$. Take the ratio. In the Gaussian case $\pi_\beta=N(0,1/(1+\beta))$, and convolution with $\varphi_s$ adds $s^2$ to the variance. ∎

::: {custom-style="Check"}
*Numerical check.* In the Gaussian case with $\beta=1$ and 400,000 records, the archive density matched the limit at nine points in $[-2,2]$ to a largest relative error of 0.0148, 0.0101 and 0.0024 for $s=0.1$, 0.3 and 1.
:::

So an archive used as a target carries two errors: the smoothing bias of $\varphi_s$, which shrinks with $s$, and the sampling error of the weights, which grows as $s$ shrinks and is governed by $n_{\text{eff}}$, not by $n$. Selection makes the second error severe. The 40 records of the running example have $n_{\text{eff}}=2.7$. As a target, their archive density was off by 0.61 to 0.95 in total variation for widths from 0.05 to 1. It put the probability of $x_1>0.5$ between 0.65 and 0.85, against 0.476. With 4,000 records from the same base law the total variation fell to 0.19, and the probability estimates to 0.455 and 0.471 at widths 0.2 and 0.05. An archive is a record of what was evaluated, shaped by selection. The rest of this paper therefore uses it as a proposal and corrects it with fresh evaluations of $J$.


# 3 Proposals

## 3.1 A clean top cannot propose for estimation

::: {custom-style="Statement"}
**Theorem 3.1** (support of clean-top proposals). Use identity maps and a clean top, $s_0=0$, with any noise parameter and any number of layers. Let $H$ be the convex hull of the records read at the top layer.
:::

::: {custom-style="Statement"}
\(i) Every output lies in $H$.
:::

::: {custom-style="Statement"}
\(ii) If the records read at the top span an affine subspace of dimension less than $D$, the law of the output is concentrated on a Lebesgue-null set. It is singular with respect to $\pi_\beta$, and no importance weight $\text{d}\pi_\beta/\text{d}\mu$ exists.
:::

::: {custom-style="Statement"}
\(iii) For every law $\mu$ supported on $H$, $\text{TV}(\mu,\pi_\beta)\ge\pi_\beta(H^{\text{c}})$, where $H^{\text{c}}$ is the complement of $H$. No reweighting of clean-top outputs can estimate $E_{\pi_\beta}f$ for all bounded $f$ to better than this.
:::

::: {custom-style="Statement Tag"}
\(i) Part III, Proposition 3.6(i); (ii) and (iii) New in Part IV.
:::

*Proof.* (i) At a clean top the output is the read $m_1(z_1)$, a convex combination of the records read there. (ii) The output lies in the affine span of those records, a proper affine subspace, which has Lebesgue measure zero. $\pi_\beta$ has a density, so it gives that set measure zero, while $\mu$ gives it measure one. (iii) Take the set $H^{\text{c}}$: $\mu$ gives it measure zero and $\pi_\beta$ gives it $\pi_\beta(H^{\text{c}})$. ∎

ADE practice reads an elite subset of the archive at the finest layers. Theorem 3.1 says what that costs an estimator (Figure 1). In the running example, the convex hull of all 40 records misses less than $10^{-8}$ of the target. The hull of the 16 best records misses 0.19 of it, and the hull of the 8 best misses 0.795. All 8 of those records lie near the right-hand mode, so inside their hull the probability of $x_1>0.5$ is 0.952, against 0.476 overall. With 4 records the hull is still a polygon of positive area in $ℝ^2$. In higher dimensions, fewer than $D+1$ elite records make the law singular.

::: {custom-style="Check"}
*Numerical check.* For 200 random stacks in $ℝ^5$ reading four records, with random noise parameters, nine geometric layers and a clean top, every output lay in the affine span of the records to within 2.1 × 10⁻¹⁴. Target masses outside the hulls in the running example were computed by quadrature: 0.797, 0.795, 0.189 and 4.4 × 10⁻⁹ for the 4, 8, 16 and 40 best records.
:::

![**Figure 1.** (a) The double-well target, its 40 records and their convex hull. (b) The 8 records with the largest weights, all near the right-hand mode, and their hull. (c) The target mass outside the hull of the $k$ best records, which a clean top that reads only those records can never propose (Theorem 3.1).](fig/support.png){width=100%}

## 3.2 The archive density is an exact proposal

::: {custom-style="Statement"}
**Proposition 3.2** (exact proposals). Draw an index $I$ with $P(I=i)=\beta_i$ and set $x=y_I+s\,\xi$ with $\xi\sim N(0,I)$. Then $x$ has the law $p_s$ exactly, and its density is computable at every point. A deterministic stack with identity maps, started from $p_{s_T}$, has the law $p_{s_0}$ only in the continuum limit; for a finite stack the output density is not available in closed form.
:::

::: {custom-style="Statement Tag"}
The sampler is classical; the comparison with the stack uses Part III, Theorem 3.5.
:::

*Proof.* The first statement is the definition of a mixture. The second is Part III, Theorem 3.5(iv), which gives convergence of laws as the largest step tends to zero, and no finite-step identity. ∎

So for estimation the stack is not needed. Its proposal law is, at best, a law that can be sampled exactly and more cheaply by Proposition 3.2. The stack's value lies elsewhere: it carries a particular query to a particular output, the property used for search, recombination and the sensitivities of Part III. An estimator built on stack outputs must either take the continuum limit on trust or estimate a density it does not have. Part IV takes the direct route.

::: {custom-style="Check"}
*Numerical check.* For the six weighted records of Part III, Figure 2, with $s_0=0.3$ and $s_T=20$, 40,000 direct draws had a Kolmogorov–Smirnov distance of 0.0071 to an independent sample of $p_{s_0}$. The 95% critical value is 0.0096. Deterministic geometric stacks with 4, 16 and 64 layers, started from 40,000 draws of $p_{s_T}$, gave 0.101, 0.030 and 0.012. Even at 64 layers the finite stack is still detectably different from its limit.
:::

## 3.3 When the importance weights have finite variance

The cost of importance sampling is governed by the second moment $m_2(q)=E_q[(\pi_\beta/q)^2]$ [1, 2]. Its reciprocal approximates the fraction of draws that count, the effective-sample fraction of Kong [4].

::: {custom-style="Statement"}
**Proposition 3.3** (Gaussian second moment). For $\pi=N(\mu,\Sigma)$ and $q=N(\mu,S)$,
:::

::: {custom-style="Statement Equation"}
$m_2(q)=\frac{\text{det}\,S}{\sqrt{\text{det}\,\Sigma\ \text{det}(2S-\Sigma)}}\quad\text{if }2S\succ\Sigma,\qquad m_2(q)=\infty\text{ otherwise.}$ (3.1)
:::

::: {custom-style="Statement"}
For $\Sigma=\sigma^2I$ and $S=r^2\sigma^2I$ in $ℝ^D$, $m_2=\left(r^2/\sqrt{2r^2-1}\right)^D$ for $r>1/\sqrt2$, which exceeds one for every $r\ne1$.
:::

::: {custom-style="Statement Tag"}
Classical [1, 16].
:::

*Proof.* $m_2=\int N(\mu,\Sigma)^2/N(\mu,S)$ is a Gaussian integral whose quadratic form is $x^{\top}(2\Sigma^{-1}-S^{-1})x$. It converges exactly when $2\Sigma^{-1}\succ S^{-1}$, that is $2S\succ\Sigma$, and then evaluates to (3.1). The isotropic form follows by taking determinants. ∎

A proposal that is 1.5 times too wide in every coordinate therefore keeps a fraction $0.831^D$ of its draws: 0.83 in one dimension, 0.052 in 16 and 0.0027 in 32 (Figure 2b). Width errors compound across coordinates. A proposal that is too narrow by a factor $\sqrt2$ or more has infinite variance in every dimension.

::: {custom-style="Check"}
*Numerical check.* With two million draws, Monte Carlo estimates of $\chi^2$ were 0.2030, 0.2031, 1.181 and 0.2011 against the closed forms 0.2027, 0.2095, 1.183 and 0.2095 for $(\sigma,r\sigma)=(1,1.5)$, $(1,0.8)$, $(1,3)$ and $(2,1.6)$. The two narrow cases converge slowly, because their squared weights have infinite variance even though $m_2$ is finite.
:::

The archive density is a Gaussian mixture, not a Gaussian. The same threshold survives.

::: {custom-style="Statement"}
**Proposition 3.4** (width threshold for archive mixtures). Suppose the target factorises as $\pi(x)=\pi_1(u)\,N(v;0,\sigma^2)$ with $x=(u,v)$, $u\in ℝ^{D-1}$, and $\int\pi_1(u)^2e^{\Vert u-a\Vert^2/2s^2}\text{d}u<\infty$ for every $a$. Let $q=\sum_i\beta_i\varphi_s(\cdot-y_i)$ with every $\beta_i>0$. Then
:::

::: {custom-style="Statement Equation"}
$m_2(q)<\infty\ \text{if}\ s>\sigma/\sqrt2,\qquad m_2(q)=\infty\ \text{if}\ s<\sigma/\sqrt2$ (3.2)
:::

::: {custom-style="Statement"}
whatever the records and their weights are. At $s=\sigma/\sqrt2$ the answer depends on the records.
:::

::: {custom-style="Statement Tag"}
New in Part IV.
:::

*Proof.* If $s>\sigma/\sqrt2$, use $q\ge\beta_1\varphi_s(\cdot-y_1)$. Then $\pi^2/q$ is bounded by a constant times $\pi_1(u)^2e^{\Vert u-a\Vert^2/2s^2}$ times $e^{-v^2/\sigma^2+(v-b)^2/2s^2}$, where $(a,b)=y_1$. The first factor is integrable by hypothesis, and the second is integrable because $1/\sigma^2>1/2s^2$. If $s<\sigma/\sqrt2$, bound every component of $q$ by $(2\pi s^2)^{-D/2}e^{-(v-b_i)^2/2s^2}$. For $|v|$ larger than every $|b_i|$, $q$ is then at most a constant times $e^{-(|v|-b)^2/2s^2}$ with $b=\max_i|b_i|$. The $v$-integral of $e^{-v^2/\sigma^2+(|v|-b)^2/2s^2}$ diverges because $1/2s^2>1/\sigma^2$, and $\int\pi_1^2>0$. ∎

In the running example $\sigma=0.485$, so every archive proposal with $s<0.343$ has infinite-variance weights, however many records it has and wherever they are. The quadrature of Section 3.4 shows the consequence. Near the threshold, $m_2$ rises steeply: 35.6 at $s=0.367$, against 9.5 at the best width. Below it, finite-sample estimates are erratic.

::: {custom-style="Statement"}
**Theorem 3.5** (defensive mixtures). Let $q_\varepsilon=(1-\varepsilon)q+\varepsilon\rho$ with $0<\varepsilon<1$. Then every weight satisfies $\pi_\beta/q_\varepsilon\le1/(\varepsilon Z)$, and
:::

::: {custom-style="Statement Equation"}
$m_2(q_\varepsilon)\le\min\left\{\frac{m_2(q)}{1-\varepsilon},\ \frac{m_2(\rho)}{\varepsilon},\ \frac{1}{\varepsilon Z}\right\}$ (3.3)
:::

::: {custom-style="Statement Tag"}
Classical in substance, Hesterberg's defensive mixture [3] and Owen and Zhou [5]; the form with a Gibbs target uses $J\ge0$.
:::

*Proof.* $q_\varepsilon\ge(1-\varepsilon)q$ and $q_\varepsilon\ge\varepsilon\rho$, so $\pi/q_\varepsilon$ is at most $\pi/((1-\varepsilon)q)$ and at most $\pi/(\varepsilon\rho)=e^{-\beta J}/(\varepsilon Z)\le1/(\varepsilon Z)$. Multiply each bound by $\pi/q_\varepsilon$ and integrate against $q_\varepsilon$; for the last bound use $m_2(q_\varepsilon)=\int\pi\,(\pi/q_\varepsilon)$. ∎

A defensive component costs at most the factor $1/(1-\varepsilon)$ where the archive proposal is good. It caps the weights everywhere, including below the threshold of Proposition 3.4. The cap needs $J\ge0$, or a known lower bound of $J$ subtracted from it.

::: {custom-style="Statement"}
**Theorem 3.6** (finite-sample bounds). If $\pi_\beta$ has a density with respect to $q$ and $m_2(q)<\infty$, the self-normalised estimate from $n$ independent draws of $q$ satisfies, for every $f$ with $|f|\le1$,
:::

::: {custom-style="Statement Equation"}
$\left|E\,\hat I_n(f)-E_{\pi_\beta}f\right|\le\frac{12\,m_2(q)}{n},\qquad E\left(\hat I_n(f)-E_{\pi_\beta}f\right)^2\le\frac{4\,m_2(q)}{n}$ (3.4)
:::

::: {custom-style="Statement Tag"}
Classical, Agapiou, Papaspiliopoulos, Sanz-Alonso and Stuart [1, Theorem 2.1].
:::

::: {custom-style="Check"}
*Numerical check.* Over the 40 widths of Section 3.4, the largest weight of each defensive mixture never exceeded $1/(\varepsilon Z)$, which is 244.3 for $\varepsilon=0.1$ and 81.4 for $\varepsilon=0.3$, and (3.3) had 0 violations. For $P(x_1>0.5)$ at the best width, $s=1.17$, 2,000 and 1,000 replications gave mean squared errors of 0.0234 and 0.00214 for $n=100$ and 1,000, against the bounds 0.380 and 0.0380 of (3.4). The biases were 0.0224 and 0.0023, against 1.14 and 0.114.
:::

## 3.4 Exploration: choosing the width

Which width should the archive proposal have? We computed $m_2$ by quadrature for 40 widths from 0.05 to 3 on the running example, for the archive proposal and for defensive mixtures with $\varepsilon=0.1$ and 0.3 (Figure 2a).

The archive proposal has infinite second moment below $s=0.343$, as Proposition 3.4 says. Its best width is $s=1.17$, where $m_2=9.50$, so about one draw in ten counts; the measured mean effective fraction at $n=1000$ was 0.107. The base law alone, with no archive at all, gives $m_2=11.84$. With 40 records and an effective archive size of 2.7, the archive improves on the base law by only 20%, and only at a width more than twice the mode width of the target. Its best width is the one that most resembles the base law. Defensive mixtures cost nothing at the best width, 9.47 and 9.50, and turn the infinite region into a finite one: 111 and 37.5 at $s=0.05$.

The width also matters in practice, not just for the bounds. At $s=0.08$, below the threshold, 1,000 replications of the estimate with $n=1000$ had a bias of 0.359 and a mean squared error of 0.150. The estimator is consistent, but it had not yet converged, and its effective fraction of 0.026 gave no warning of the size of the error. At the wide width $s=2.5$, $m_2=19.9$ and the mean squared error with $n=1000$ was 0.0047.

The lesson for ASE is that the fine widths at which the stack resolves records are the wrong widths for estimation. A run that wants both should use different widths for the two jobs and should always include a defensive component.

![**Figure 2.** (a) The second moment $m_2=1+\chi^2$ of the importance weights for the archive proposal $p_s$ and two defensive mixtures, against the width $s$, on the double well. It is infinite to the left of the dotted line, $s=\sigma/\sqrt2=0.343$ (Proposition 3.4). The dashed line is the base law alone. (b) The fraction $1/m_2$ for a Gaussian proposal 1.5 times wider than a Gaussian target in every coordinate, against dimension (Proposition 3.3).](fig/width.png){width=100%}


# 4 Critic and density error

A weight $\rho e^{-\beta J}/q$ is never computed exactly. The loss comes from a critic, which may be a surrogate or a noisy measurement, and the proposal density may be evaluated on a truncated archive. Each error multiplies the weight by a factor. One lemma covers all of them.

::: {custom-style="Statement"}
**Lemma 4.1** (multiplicative weight error). Let $\mu$ be a probability law and $u>0$ a function with $c\le u\le c\,e^{\kappa}$ for some $c>0$ and $\kappa\ge0$. Let $\mu'$ be the law with density proportional to $u$ with respect to $\mu$. Then
:::

::: {custom-style="Statement Equation"}
$\text{TV}(\mu,\mu')\le\tanh(\kappa/4)$ (4.1)
:::

::: {custom-style="Statement"}
with equality for a two-point law with masses $p$ and $1-p$, where $p=1/(1+e^{\kappa/2})$, when $u$ takes the value $ce^{\kappa}$ on the first point and $c$ on the second.
:::

::: {custom-style="Statement Tag"}
New in Part IV as stated for general laws; Part II, Theorem 4.8(i), is the case of finitely many records with $\kappa=2\beta\varepsilon$.
:::

*Proof.* $\text{TV}(\mu,\mu')$ is the largest value of $\mu'(A)-\mu(A)$ over measurable sets $A$. Fix $A$ with $\mu(A)=p$. Then $\mu'(A)=X/(X+Y)$ with $X=\int_Au\,\text{d}\mu\le pce^{\kappa}$ and $Y=\int_{A^c}u\,\text{d}\mu\ge(1-p)c$. The ratio increases in $X$ and decreases in $Y$, so $\mu'(A)-p\le pe^{\kappa}/(pe^{\kappa}+1-p)-p$. This is maximised at $p=1/(1+e^{\kappa/2})$, where it equals $(e^{\kappa/2}-1)/(e^{\kappa/2}+1)=\tanh(\kappa/4)$. The two-point law attains every inequality. ∎

::: {custom-style="Statement"}
**Proposition 4.2** (bounded critic error). If the critic returns $\hat J$ with $|\hat J-J|\le\varepsilon$, the target it defines, $\hat\pi\propto\rho e^{-\beta\hat J}$, satisfies $\text{TV}(\pi_\beta,\hat\pi)\le\tanh(\beta\varepsilon/2)$. A self-normalised estimate that uses $\hat J$ converges to $E_{\hat\pi}f$, so its limiting bias is at most $\text{osc}(f)\tanh(\beta\varepsilon/2)$.
:::

::: {custom-style="Statement Tag"}
New in Part IV, extending Part II, Theorem 4.8, from record weights to target laws.
:::

*Proof.* $\hat\pi$ has density $e^{-\beta(\hat J-J)}$, up to a constant, with respect to $\pi_\beta$, and this factor lies in $[e^{-\beta\varepsilon},e^{\beta\varepsilon}]$. Apply Lemma 4.1 with $\kappa=2\beta\varepsilon$. For any $f$, $|E_\pi f-E_{\hat\pi}f|\le\text{osc}(f)\,\text{TV}$. ∎

::: {custom-style="Check"}
*Numerical check.* Over 4,000 random finite laws with bounded perturbations, the ratio of total variation to $\tanh(\beta\varepsilon/2)$ was at most 0.988. The two-point case gave 0.604368 against $\tanh(1.4)=0.604368$. On the double well, the critic error $0.1\sin3x_1\cos2x_2$ moved the target by 0.062 against the bound 0.197. Over 4,000 random laws and log-widths up to 4, Lemma 4.1 had a largest ratio of 0.9995.
:::

The bound is sharp, but only for an adversarial error that splits the target into two parts of the right sizes. A smooth error that changes sign often moves the target much less.

::: {custom-style="Statement"}
**Proposition 4.3** (Gaussian critic noise). Suppose each evaluation returns $J(x)+\sigma(x)\xi$ with standard normal $\xi$, averaged over $k$ independent evaluations, and the weight uses that average in place of $J$. Draws come from a proposal $q$ with $\pi_\beta\ll q$, and the tilted target below must have finite normaliser. Then the self-normalised estimate converges almost surely to $E_{\tilde\pi}f$, where
:::

::: {custom-style="Statement Equation"}
$\tilde\pi(x)\propto\rho(x)\,e^{-\beta J(x)+\beta^2\sigma(x)^2/2k}$ (4.2)
:::

::: {custom-style="Statement"}
In particular, constant $\sigma$ leaves the target unchanged, and any non-constant $\sigma$ tilts it towards noisier designs.
:::

::: {custom-style="Statement Tag"}
New in Part IV in this form; the moment identity is Part II, Proposition 4.7(i), and the argument is that of pseudo-marginal methods [6].
:::

*Proof.* Given $x$, the noisy weight has conditional mean $w(x)e^{\beta^2\sigma(x)^2/2k}$ by the Gaussian moment generating function. The strong law applied to the numerator and denominator of the estimate replaces each weight by its conditional mean. A constant factor cancels in the ratio. ∎

::: {custom-style="Check"}
*Numerical check.* With $\rho=N(0,1)$, $J=x^2/2$, $\beta=1$, $k=1$ and $\sigma(x)=0.5+0.5|x|$, four million draws from $\rho$ gave $E\,x^2=0.6659$, against 0.6654 for the tilted target (4.2) and 0.5 for $\pi_\beta$. With constant noise $\sigma=0.7$ the estimate was 0.50005.
:::

A surrogate critic whose error grows away from the data is the common case, and (4.2) says it pulls the estimate towards the regions it knows least. Averaging more evaluations divides the tilt exponent by $k$, but it does not remove it.

::: {custom-style="Statement"}
**Proposition 4.4** (truncated proposal densities). Suppose the proposal density $q$ is evaluated as $\hat q$ with $\hat q\le q\le\hat q\,e^{\kappa}$, for instance by summing only the $k$ nearest components of $p_s$. Then the estimate with weights $\pi_\beta/\hat q$, drawn from $q$, converges to the law proportional to $\pi_\beta\,q/\hat q$, which is within $\tanh(\kappa/4)$ of $\pi_\beta$ in total variation.
:::

::: {custom-style="Statement Tag"}
New in Part IV; the truncation certificates of Part II, Section 5, bound $\kappa$.
:::

*Proof.* Apply the strong law to the numerator and the denominator, then Lemma 4.1 with $u=q/\hat q\in[1,e^{\kappa}]$. ∎

::: {custom-style="Check"}
*Numerical check.* At the best width of Section 3.4, truncating $p_s$ to its 5, 10 and 20 nearest components gave log-widths of 141.8, 14.8 and 0.98 over the grid. The limiting laws were 0.379, 0.237 and 0.0070 from the target in total variation, against the bounds 1.000, 0.9988 and 0.240.
:::

Truncation is safe only when the omitted share is certified small everywhere the proposal draws. A nearest-component sum that is accurate where the records are dense can be wrong by a factor of $e^{140}$ in the gaps between them. Those gaps are exactly where the large weights live.


# 5 An error ledger

::: {custom-style="Statement"}
**Theorem 5.1** (error ledger). Let draws come from $q$, let the critic satisfy $|\hat J-J|\le\varepsilon$, and let the proposal density be evaluated as $\hat q$ with $\hat q\le q\le\hat q\,e^{\kappa}$. Let $\pi'$ be the law proportional to $\rho\,e^{-\beta\hat J}q/\hat q$, and $m_2'=E_q[(\pi'/q)^2]$. For every $f$ with $|f|\le1$,
:::

::: {custom-style="Statement Equation"}
$\left(E\left(\hat I_n(f)-E_{\pi_\beta}f\right)^2\right)^{1/2}\le2\tanh\left(\frac{2\beta\varepsilon+\kappa}{4}\right)+2\sqrt{\frac{m_2'}{n}}$ (5.1)
:::

::: {custom-style="Statement"}
The first term does not decrease with $n$. Once $2\sqrt{m_2'/n}$ is below it, more samples cannot reduce the bound; only a better critic or a better density evaluation can.
:::

::: {custom-style="Statement Tag"}
New in Part IV.
:::

*Proof.* The estimate is a self-normalised estimate of $\pi'$, so Theorem 3.6 bounds its root-mean-square deviation from $E_{\pi'}f$ by $2\sqrt{m_2'/n}$. The factor relating $\pi'$ to $\pi_\beta$ is $e^{-\beta(\hat J-J)}q/\hat q$. It lies in an interval of log-width $2\beta\varepsilon+\kappa$, so Lemma 4.1 gives $\text{TV}(\pi',\pi_\beta)\le\tanh((2\beta\varepsilon+\kappa)/4)$, and $|E_{\pi'}f-E_{\pi_\beta}f|\le\text{osc}(f)\,\text{TV}\le2\,\text{TV}$. Minkowski's inequality adds the two terms. ∎

For $0\le f\le1$ the oscillation is at most one, and the factor 2 in front of the first term of (5.1) becomes 1. The check uses that form.

Table: **Table 2.** The error ledger for $P(x_1>0.5)$ on the double well, at the best width $s=1.17$ with exact densities, $\kappa=0$. The critic error is $\varepsilon\,\text{sign}(\sin5x_1)$. Root-mean-square errors are over 1,000 replications, or 200 for $n=10{,}000$.

| $\varepsilon$ | $n$ | RMSE | bound (5.1) | critic term | sampling term | limiting bias |
|:--|:--|:--|:--|:--|:--|:--|
| 0 | 100 | 0.156 | 0.616 | 0 | 0.616 | 0 |
| 0 | 1,000 | 0.0487 | 0.195 | 0 | 0.195 | 0 |
| 0 | 10,000 | 0.0158 | 0.0616 | 0 | 0.0616 | 0 |
| 0.05 | 100 | 0.172 | 0.663 | 0.0997 | 0.564 | 0.0783 |
| 0.05 | 1,000 | 0.0920 | 0.278 | 0.0997 | 0.178 | 0.0783 |
| 0.05 | 10,000 | 0.0803 | 0.156 | 0.0997 | 0.0564 | 0.0783 |
| 0.2 | 100 | 0.278 | 0.917 | 0.380 | 0.537 | 0.264 |
| 0.2 | 1,000 | 0.267 | 0.550 | 0.380 | 0.170 | 0.264 |
| 0.2 | 10,000 | 0.264 | 0.434 | 0.380 | 0.0537 | 0.264 |

::: {custom-style="Check"}
*Numerical check.* The bound (5.1) had 0 violations in the 9 configurations of Table 2. Without critic error the error fell as $n^{-1/2}$, by factors of 0.31 and 0.32 per decade. With $\varepsilon=0.2$ it stayed between 0.264 and 0.278 from $n=100$ to 10,000, at the limiting bias 0.264. The critic term overstates that bias by a factor of 1.44.
:::

The ledger gives a rule for allocating evaluations (Figure 3). In the example, with $\varepsilon=0.05$, the sampling term falls below the critic term near $n=3{,}200$, and every evaluation beyond that point is wasted. In ADE terms, the archive weights, the proposal width and the critic are three separately accountable parts of one estimate, and each should be reported.

![**Figure 3.** Root-mean-square error of the self-normalised estimate of $P(x_1>0.5)$ against the number of draws, for three critic errors (solid), with the bound (5.1) (dashed) and the limiting bias (dotted). Once the critic is wrong, more draws converge to the wrong answer (Theorem 5.1).](fig/ledger.png){width=100%}


# 6 Discussion

## 6.1 What Part IV supplies to the rest of the book

Part V, on fusion and constraints, combines several local laws. Lemma 4.1 applies to every multiplicative factor such a fusion introduces, and Theorem 3.1 warns that a fused read confined to a hull cannot be weighted against a target outside it. Part VI, on evidence and computation, takes the ledger of Theorem 5.1 as the report every estimate should carry, and the kernel of Appendix A as its specification.

For the stack of Part III, the conclusion is a division of labour. The stack carries queries to outputs; it is a search operator. Estimation uses the archive density directly, at a width chosen for estimation, with a defensive component and fresh critic evaluations.

## 6.2 Diagnostics an estimate should report

Table: **Table 4.** Diagnostics reported with every estimate.

| Diagnostic | Source | Action when it is poor |
|:-------------------|:-------------------|:-------------------------------|
| declared base law $\rho$ and temperature $\beta$ | Definition 2.1 | no estimate without them |
| archive effective size $n_{\text{eff}}$ | Proposition 2.3 | never use the archive as the target |
| target mass outside the hull of the records read | Theorem 3.1 | never weight clean-top outputs |
| proposal width against $\sigma/\sqrt2$ in every Gaussian direction | Proposition 3.4 | widen, or add a defensive component |
| defensive share $\varepsilon$ and the cap $1/(\varepsilon Z)$ | Theorem 3.5 | report the cap with every estimate |
| critic error bound $\varepsilon$ or noise profile $\sigma(x)$ | Propositions 4.2, 4.3 | report the critic term; correct heteroscedastic tilt |
| truncation log-width $\kappa$ | Proposition 4.4 | evaluate more components |
| both terms of (5.1) | Theorem 5.1 | spend on the larger term |

## 6.3 What is not claimed

The results use identity maps and Gaussian components of one width. With masks or general maps, a read can leave the hull of the records (Part II, Proposition 3.5), so Theorem 3.1(i) fails as stated. Part (iii) still holds for the image of the read map, but that image has no simple description. Proposition 3.4 needs a target that factorises with a Gaussian factor. Without that structure the threshold is a heuristic, though the direction of the effect is general. The finite-sample bounds of Theorem 3.6 are worst-case and were loose by factors of 16 to 18 in the example. The width exploration uses one target with one archive, and its optimum is specific to them. Nothing here concerns the quality of designs found by search.

## 6.4 Open problems

1. **Densities of finite stacks.** Bound the density ratio between a finite stochastic stack and $p_{s_0}$, so that stack outputs could be weighted with a certified $\kappa$.
2. **Widths from the archive.** Estimate the width that minimises $m_2$ from the archive alone, without quadrature, and prove that the estimate is consistent.
3. **Sequential targets.** Analyse a run that raises $\beta$ across generations as a sequence of tempered targets, with Lemma 4.1 bounding the step between consecutive targets.
4. **Heteroscedastic correction.** Prove when the plug-in correction of Part II, Proposition 4.7(ii), removes the tilt (4.2) to first order, and bound what it leaves.
5. **Targets with maps.** Define the target of a run whose reads use masks, as a law on the glued space of Part I, and extend Theorem 3.1 to it.

## 6.5 Conclusion

A run estimates a declared Gibbs target only if its proposal has a known density and covers the target. The archive is a selection record, not a sample of the target. A clean top cannot be weighted at all. The archive density is an exact proposal, but only at widths above a threshold that the target's narrowest Gaussian direction sets. A defensive component makes every width safe. Every error in the weights, from critic bias to truncated densities, moves the estimate by a bounded amount that does not shrink with more draws. The ledger of Theorem 5.1 says when that amount, rather than the sampling error, decides the answer.


# 7 Register of numerical checks

Table 3 lists every numerical check in Part IV. The script `p4_checks.py` produced checks 1 to 15 and the width exploration, with seed 20261021, and `p4_extras.py` added the elite hulls, the threshold and the bound verdicts from the same results file. The kernel comparison of Appendix A is check 16. The checks test the implementations and illustrate the statements; the proofs establish them.

Table: **Table 3.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 2.3 | Gaussian case, 400,000 records | largest relative error 0.015 |
| 2 | Section 2.2 | archive as target, 40 and 4,000 records | TV 0.61 to 0.95; 0.19 |
| 3 | Theorem 3.1(i), (ii) | 200 clean-top stacks in $ℝ^5$ | distance to span 2.1 × 10⁻¹⁴ |
| 4 | Theorem 3.1(iii) | elite hulls | missing mass 0.795 with 8 records |
| 5 | Proposition 3.2 | direct sampler and finite stacks | KS 0.0071; stacks 0.101 to 0.012 |
| 6 | Proposition 3.3 | closed form against Monte Carlo | four cases; slow for narrow proposals |
| 7 | Proposition 3.4 | threshold on the double well | 0.343; first finite width 0.367 |
| 8 | Theorem 3.5 | weight caps and (3.3), 40 widths | 0 violations |
| 9 | Theorem 3.6 | bias and MSE, 6 configurations | 0 violations; MSE 0.0234 against 0.380 |
| 10 | Lemma 4.1 | 4,000 random laws | largest ratio 0.9995 |
| 11 | Proposition 4.2 | 4,000 laws; two points; double well | 0.988; equality; 0.062 against 0.197 |
| 12 | Proposition 4.3 | heteroscedastic and constant noise | 0.6659 against 0.6654; 0.50005 |
| 13 | Proposition 4.4 | truncation to 5, 10, 20 components | TV 0.379, 0.237, 0.0070 within bounds |
| 14 | Theorem 5.1 | ledger, 9 configurations | 0 violations |
| 15 | Section 3.4 | width exploration, 40 widths | best $s=1.17$, $m_2=9.50$; base law 11.84 |
| 16 | Appendix A | C# kernel against NumPy | 9 of 9 lines agree; largest relative difference 2.9 × 10⁻¹⁴ |

# References

::: {custom-style="Bibliography"}
[1] Agapiou, S., Papaspiliopoulos, O., Sanz-Alonso, D. and Stuart, A. M. (2017). Importance sampling: intrinsic dimension and computational cost. *Statistical Science* 32(3), 405–431. arXiv:1511.06196.

[2] Chatterjee, S. and Diaconis, P. (2018). The sample size required in importance sampling. *Annals of Applied Probability* 28(2), 1099–1135.

[3] Hesterberg, T. (1995). Weighted average importance sampling and defensive mixture distributions. *Technometrics* 37(2), 185–194.

[4] Kong, A. (1992). A note on importance sampling using standardized weights. Technical Report 348, Department of Statistics, University of Chicago.

[5] Owen, A. and Zhou, Y. (2000). Safe and effective importance sampling. *Journal of the American Statistical Association* 95(449), 135–143.

[6] Andrieu, C. and Roberts, G. O. (2009). The pseudo-marginal approach for efficient Monte Carlo computations. *Annals of Statistics* 37(2), 697–725.

[7] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[8] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[9] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[10] Ghosh, D. P. (2026d). *Horizontally Topological, Vertically Algebraic: The Two Axes of Autoregressive Sheaf Evolution. Part I: Sheaves on Covers and Representations of the Layer Order*. 18 October 2026.

[11] Ghosh, D. P. (2026e). *The Horizontal Layer: One Layer of Autoregressive Sheaf Evolution. Part II: Sheaf Attention, Gaussian Stalks, Locality and the Topology of Design Spaces*. 18 October 2026.

[12] Ghosh, D. P. (2026f). *The Vertical Stack: Layers of Autoregressive Sheaf Evolution. Part III: The Token Recurrence, Tangent Dynamics and Persistence across Layers*. 18 October 2026.

[13] Steele, G. L., Lea, D. and Flood, C. H. (2014). Fast splittable pseudorandom number generators. *Proceedings of OOPSLA 2014*, 453–472. ACM.

[14] Box, G. E. P. and Muller, M. E. (1958). A note on the generation of random normal deviates. *Annals of Mathematical Statistics* 29(2), 610–611.

[15] Silverman, B. W. (1986). *Density Estimation for Statistics and Data Analysis*. Chapman and Hall.

[16] Robert, C. P. and Casella, G. (2004). *Monte Carlo Statistical Methods*, 2nd edn. Springer.
:::

# Appendix A: an immutable C# reference kernel

The kernel holds an archive and a Gibbs target as immutable records. It computes the archive log density, draws exactly from $p_s$ (Proposition 3.2), and forms self-normalised estimates with their effective fractions and largest weight shares. It also gives the Gaussian second moment (3.1), the defensive cap of Theorem 3.5 and the bound of Lemma 4.1. The random stream is a SplitMix64 generator [13] with Box–Muller normals [14], held as a value: every draw returns the next generator. The kernel targets .NET 8 and uses only the base class library.

```csharp
{{file:cs/Targets.cs}}
```

The driver draws the 40-record archive of the running example from the stream. It prints the first record and two log densities, and estimates $P(x_1>0.5)$ with 2,000 draws at widths 0.2, 0.5 and 1. It then prints the closed forms of (3.1) and (3.3), the two-point equality of Lemma 4.1, and the largest ratio over 1,000 random laws. An independent NumPy script regenerates the same stream and recomputes every line (Table A1). The largest relative difference is 2.9 × 10⁻¹⁴, in the importance-sampling lines, where sums are taken in a different order.

Table: **Table A1.** C# kernel output against the NumPy recomputation.

| C# | NumPy | Relative difference |
|:------------------|:------------------|:----------|
{{cs_rows}}

# Appendix B: reproducibility

All results were produced with Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1, Matplotlib 3.11.2 and .NET SDK 8.0.131. The script `p4_checks.py` writes `p4_checks.json`, and `p4_extras.py` adds the elite hulls, the width threshold and the bound verdicts to it. Both use seed 20261021 and the shared primitives of Part III in `p3_core.py`. The script `fig_p4.py` draws the figures from the results file; panel (a) of Figure 1 recomputes the target on a grid. The C# project in `cs/` builds the kernel and its driver, and `cs_validate.py` compares the driver's output with NumPy and writes `cs_validate.json`. The document is converted to Word by Pandoc and post-processed for equation layout and schema order. A code archive accompanies this paper.
