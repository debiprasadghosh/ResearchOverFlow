# ASE Part IV: Targets and Estimation — code

Run in order: `p4_checks.py` (writes p4_checks.json), `p4_extras.py`, `fig_p4.py`; build `cs/` with .NET 8 and save its output as `cs/cs_out.txt`; `cs_validate.py`; `render4.py`; then
`pandoc paper.md -o raw.docx --reference-doc=ref.docx` and `postprocess.py raw.docx paper.docx`.
`p3_core.py` holds the shared Part III primitives.
