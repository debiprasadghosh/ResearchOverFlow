# 11 Mathematics of response fibres and certificates

The added computation separates three questions. Can two compatible models disagree? What range of answers remains possible? Can a proposed bound be checked without trusting the program that found it? This section develops the finite mathematics behind those questions. Response-function optimization and polynomial causal bounding have classical and recent precedents (Balke & Pearl, 1997; Duarte et al., 2024). The results below specialize those tools to ADC's declared district model and its execution interface.

## 11.1 Linear information within a response block

**Definition 11.1 (normalized response fibre).** Let a finite vector $q$ give probabilities of deterministic response types. Include normalization in an equality system $Aq=b$, and define

$$
K(b)=\{q:Aq=b,\ q\geq0\},\qquad
\mathbf1^\mathsf Tq=1.
\qquad\text{(11.1)}
$$

Normalization must be explicit or certified as implied by the equality rows. In Proposition 10.2, $A$, $b$ and the target coefficient vector $c$ are fixed after the observational law and the other identified factors have been supplied. They must be reconstructed if that input law changes. The query value is $c^\mathsf Tq$.

**Lemma 11.2 (row space and an interior fibre).** Suppose $K(b)$ contains a vector $q^\circ$ with every coordinate positive. Then $c^\mathsf Tq$ is constant on $K(b)$ if and only if $c$ belongs to the row space of $A$.

*Proof.* If $c=A^\mathsf T\lambda$, then $c^\mathsf Tq=\lambda^\mathsf Tb$ throughout the fibre. Conversely, if $c$ is outside that row space, orthogonality of row space and nullspace gives $\delta\in\ker A$ with $c^\mathsf T\delta\ne0$. The normalization row gives $\mathbf1^\mathsf T\delta=0$. For sufficiently small positive $\epsilon$, both $q^\circ+\epsilon\delta$ and $q^\circ-\epsilon\delta$ are positive and feasible. Their target values differ. ∎

For rational matrices, elimination supplies a rational nullspace basis and rational witnesses. Positivity is essential to the converse. The system $q_1+q_2+q_3=1$, $q_1+q_2=0$, $q\geq0$ has only $(0,0,1)$, so $q_1$ is constant even though $(1,0,0)$ is outside the two-row space. A boundary fibre requires its forced-zero support to be removed or its range to be computed directly. Zero width on one fibre still does not prove identification over a whole graph class.

## 11.2 More than one confounded district

Use the model class of Proposition 10.1: each bidirected district is a clique, one unrestricted latent response type is shared within each district, and different districts have independent latent variables. This class is denoted $\mathfrak M_{\mathrm{cl}}$. It retains the larger-clique scope already stated in Section 10. District factorization continues to hold because all children of each shared latent remain in one district. The original pairwise-primitive class of Definition 2.1 is separately labelled.

For a positive compatible observational law $p$, district factorization identifies $Q_p[D](v)$. Let $A_D$ be the response-consistency matrix whose row at $v$ indicates which district types reproduce $v_D$ from the declared parent values. Define the compact polytope

$$
K_D(p)=\{q_D\geq0:
A_Dq_D=Q_p[D],\ \mathbf1^\mathsf Tq_D=1\}.
\qquad\text{(11.2)}
$$

**Theorem 11.3 (product structure of a response fibre).** In $\mathfrak M_{\mathrm{cl}}$, the response-parameter fibre of a positive attainable law $p$ is

$$
\operatorname{obs}^{-1}(p)
=\prod_{D\in\mathcal D(G)}K_D(p).
\qquad\text{(11.3)}
$$

Every joint interventional cell is separately affine on this product. Every conditional interventional cell has a separately affine numerator and denominator; its denominator is positive throughout the fibre. Consequently both kinds of cell attain their sharp extrema at product vertices.

*Proof.* A model with observational law $p$ must reproduce each identified district kernel, so its blocks lie in the right-hand set. Conversely, choose one feasible block from every $K_D(p)$ and take independent district latents with those laws. Their observational factors multiply to $p$, proving the reverse inclusion.

Under an action, a district contributes the sum of $q_D(t)$ over types consistent with its non-target equations. Summing products of these district contributions over non-target assignments gives a joint interventional cell. Each block enters each product at most once, proving separate affinity. A conditional cell is the ratio of the corresponding outcome-and-condition joint mass to the condition mass. Both are separately affine. For the fixed action $X=x$ and condition $C=c$, Lemma 2.4 gives the uniform bound $P_x(c)\geq p(x,c)>0$. Theorems 8.2 and 8.3 therefore apply. Every vertex choice is a feasible model, so the bounds are sharp. ∎

The statement concerns response parameters; different parameter vectors may encode equivalent mechanisms. It includes singleton districts, whose response laws can differ in cross-input couplings even when their single-world kernels agree. The theorem does not identify those cross-world couplings.

This extends the one-confounded-district computation of Section 10.2 mathematically. It does not make multiple-district bounding one linear programme: the objective couples independent blocks multiplicatively. Allowing one arbitrary joint latent law across all blocks would change the model class and generally relax the bounds. Enumeration of all products of vertices can be expensive.

## 11.3 Why one district can supply a witness

**Theorem 11.4 (single-district witness existence).** If a joint interventional query is not identified on the positive observational laws of $\mathfrak M_{\mathrm{cl}}$, there is a witness pair whose models differ in one district response law only. Such a pair can be chosen with positive rational response laws.

*Proof.* Non-identification supplies two response models in one positive observational fibre whose query values differ. By Theorem 11.3 that fibre is a product. Change the first model into the second one block at a time. At least one adjacent pair changes the query. Their block difference lies in $\ker A_D$. Expanding that difference in a rational nullspace basis shows that some basis direction has nonzero query coefficient at the fixed other blocks.

With the other blocks variable, this coefficient is a polynomial divided by the positive normalizing sums used to parameterize their probability vectors. Its numerator is not identically zero because it is nonzero at the adjacent pair. Nonzero polynomials cannot vanish on the entire open set of positive weights. Choose positive rational weights in that open set, a positive rational base law for $D$, and a sufficiently small rational step in the selected null direction. The response-consistency equations and normalization are unchanged, while the query changes. Full support of the response laws makes every observational cell positive. ∎

This corrects the earlier suggestion that a witness might intrinsically require simultaneous changes in two districts. One-block changes suffice somewhere. At a particular base draw, however, the relevant coefficient can vanish, so a search using that draw can miss a witness. The constructed pair need not reproduce a separately supplied observational dataset: this theorem concerns global identification on the graph class. Bounding the fibre of a particular dataset still requires (11.2).

**Corollary 11.5 (a finite-grid retry bound).** Suppose there are $m$ districts. In each trial, generate each response probability vector by normalizing independent integer weights uniformly drawn from $\{1,\ldots,B\}$. Test every district nullspace direction and query cell. For a non-identified joint query, the miss probability in one trial is at most

$$
\begin{aligned}
\text{one trial: }&\min\{1,(m-1)/B\},\\
\text{independent }r\text{ trials: }&\min\{1,(m-1)/B\}^{\,r}.
\end{aligned}
\qquad\text{(11.4)}
$$

*Proof.* Select the nonzero direction coefficient from Theorem 11.4. Multiply by the normalizing sum of every other district. Each other weight block enters at most once, so the resulting nonzero polynomial has total degree at most $m-1$. A nonzero degree-$d$ polynomial vanishes on at most a $d/B$ fraction of a uniform product grid. To see this, induct on the number of variables: if its degree in the last variable is $k$, the leading coefficient has degree at most $d-k$, and fails with probability at most $(d-k)/B$; otherwise that univariate polynomial has at most $k$ roots. This is the classical polynomial-identity bound (Schwartz, 1980). Missing every tested direction requires this selected coefficient to vanish. Independent repetition gives the power bound. ∎

For the four-event non-identified cases in Section 10.1, a nontrivial district leaves at most three districts in total. With $B=9$ and three ideal independent trials, the per-query bound is therefore $8/729$. It is not a simultaneous bound for all queries, and it is not a probability claim about the fixed SplitMix64 seed used in the supplied census. The exact verifier makes returned witnesses sound; randomness concerns missed witnesses.

The new finite check enumerates the cancellation polynomial $(w_1-w_2)(w_3-w_4)$ on the four-weight grid. It vanishes at 1,377 of 6,561 points, a fraction 17/81, below the degree bound 2/9. This is an algebraic illustration of cancellation and retry, not another graph-identification census.

## 11.4 Bounds that can be checked independently

**Theorem 11.6 (primal and dual certificates).** Let (11.1) be nonempty and let $L,U$ be the extrema of $c^\mathsf Tq$. Vectors satisfying

$$
A^\mathsf T\lambda\leq c\leq A^\mathsf T\mu
\quad\Longrightarrow\quad
\lambda^\mathsf Tb\leq L\leq U\leq\mu^\mathsf Tb.
\qquad\text{(11.5)}
$$

If feasible $q_-,q_+$ attain the two displayed dual values, those values are the sharp endpoints. Such matching dual certificates exist for these finite bounded feasible linear programmes.

*Proof.* Multiply the componentwise inequalities by any $q\geq0$ and substitute $Aq=b$. Feasible primal points establish attainability when equality holds. Existence of matching dual optimizers is linear-programming strong duality; the objective is bounded because $q$ lies in a simplex (Boyd & Vandenberghe, 2004). ∎

A verifier checks equality, nonnegativity and componentwise inequalities using exact rationals. It need not trust the simplex pivot sequence or a language model's explanation. Floating-point solvers may propose the vectors; exact checks decide whether they certify the stated problem.

**Proposition 11.7 (certificate perturbation).** Let $\lambda,\mu$ satisfy (11.5). For a changed normalized feasible system $A'q=b'$, target $c'$, define

$$
\begin{aligned}
\rho_v&=\|\,c'-c-(A'-A)^\mathsf Tv\,\|_\infty,\\
\lambda^\mathsf Tb'-\rho_\lambda
&\leq c'^\mathsf Tq\leq\mu^\mathsf Tb'+\rho_\mu.
\end{aligned}
\qquad\text{(11.6)}
$$

*Proof.* Write $c'-A'^\mathsf T\lambda$ as the original nonnegative lower slack plus the residual inside the norm. Its dot product with a simplex vector is at least $-\rho_\lambda$. The upper inequality follows from the original nonpositive upper slack and the same argument. ∎

This is an arithmetic transport bound for a quantified change in coefficients. It does not license an unrecorded change of graph, latent class, event meaning or clock unit. In particular, the coefficient system of Proposition 10.2 can depend on the observational input. An old certificate is checked again or transported with the full matrix and objective residual.

**Corollary 11.8 (interval observational constraints).** Suppose $q$ remains normalized and nonnegative, and the evidence gives $\ell\leq Aq\leq u$. If $\alpha,\beta\geq0$ and

$$
\begin{aligned}
c-A^\mathsf T(\alpha-\beta)-\gamma\mathbf1&\geq0\\
\Longrightarrow\quad c^\mathsf Tq
&\geq\alpha^\mathsf T\ell-\beta^\mathsf Tu+\gamma.
\end{aligned}
\qquad\text{(11.7)}
$$

An upper certificate is obtained by applying the same statement to $-c$.

*Proof.* Multiply the componentwise inequality by $q$ and use the lower bounds with $\alpha$, the upper bounds with $\beta$ and normalization with $\gamma$. ∎

All constraints refer to one common $q$. The intervals do not independently duplicate its occurrences. Their statistical coverage, if estimated from samples, is a separate input assumption.

## 11.5 Conditional bounds as linear programmes

**Theorem 11.9 (conditional response programme).** On a normalized response polytope $Aq=b$, suppose a conditional target is $N(q)/D(q)=n^\mathsf Tq/(d^\mathsf Tq)$ and $D(q)\geq\eta>0$. Its sharp extrema are the extrema of $n^\mathsf Tz$ subject to

$$
Az=bt,\qquad d^\mathsf Tz=1,\qquad z\geq0,\ t\geq0.
\qquad\text{(11.8)}
$$

*Proof.* Set $z=q/D(q)$ and $t=1/D(q)$. The constraints follow directly. Conversely, the normalization row in $Az=bt$ gives $\mathbf1^\mathsf Tz=t$. A feasible point cannot have $t=0$, since then $z=0$ would contradict $d^\mathsf Tz=1$. Thus $q=z/t$ is feasible for the original problem, and its ratio is $n^\mathsf Tz$. The two transformations are inverse. The denominator bound keeps $t$ bounded. This is the Charnes–Cooper transformation specialized to the response fibre (Charnes & Cooper, 1962). ∎

For the one-confounded-district setting of Section 10.2, both joint masses of a conditional query are linear in the free block, so this theorem supplies sharp conditional bounds. For several blocks, Theorem 11.3 supplies a vertex characterization instead. Neither statement covers arbitrary rational objectives or unrestricted latent structures.

The new worked bow has observational cells $(3/10,1/5,1/10,2/5)$ in order $(x,y)=(0,0),(1,0),(0,1),(1,1)$. Its event probability under $do(X=1)$ ranges over $[2/5,4/5]$. With selection rows $P(S=1\mid Y=0)=1/4$, $P(S=1\mid Y=1)=3/4$, its selected-outcome probability ranges over $[2/3,12/13]$. Exact response vertices, the transformed exact simplex and an independent HiGHS solve agree.

[[FIGURE_V3]]

## 11.6 Decisions under structural ambiguity

**Theorem 11.10 (ambiguity radius).** Suppose a target ranges over an attained interval $[L,U]$ on one observational fibre. With the observational law known exactly, the minimax absolute error of a scalar answer is $(U-L)/2$, attained by $(L+U)/2$. No learner using only observational samples and independent randomization can have smaller worst-case expected absolute error over that fibre.

*Proof.* The two endpoint models have identical observational sample distributions. A randomized learner therefore has the same output law, say that of $Z$, under both. The triangle inequality gives $E|Z-L|+E|Z-U|\geq U-L$, so one endpoint risk is at least half the width. The deterministic midpoint is within that distance of every possible target value. ∎

The result concerns information available under the declared model class. Additional structural assumptions, experimental data or justified domain knowledge can change the fibre. Repeated observational sampling alone cannot remove its structural width. This separates sampling uncertainty from the uncertainty represented by Section 10's witness pairs.

**Proposition 11.11 (robust action decisions).** Let a finite set of actions have affine expected utilities $u_a(q)$ on one common response polytope. Their worst-case regrets are

$$
R(a)=\max_b\ \max_{q\in K}\{u_b(q)-u_a(q)\}.
\qquad\text{(11.9)}
$$

Each inner problem is a linear programme. An action is optimal throughout the fibre exactly when $R(a)=0$; a minimax-regret action minimizes these values.

*Proof.* For fixed $q$, regret is $\max_bu_b(q)-u_a(q)$. A maximum over a finite action set commutes with a supremum over $K$. Including $b=a$ makes regret nonnegative, and zero means no competitor is better at any feasible model. ∎

Thus a non-identified effect need not prevent a definite decision. On $p\in[1/4,3/4]$, utilities $u_0=p/2$ and $u_1=p/2+1/8$ each have width $1/4$, but their common-parameter difference is always $1/8$. Action 1 has zero regret. This is an affine utility example, not a new empirical claim about a clinical or engineering intervention.

**Proposition 11.12 (a limit on conditional utility comparisons).** A difference of separately linear fractional functions need not have vertex extrema. For $p\in[0,1]$,

$$
\begin{aligned}
g(p)&=\frac p{1+p}-\frac p2,\qquad g(0)=g(1)=0,\\
\max g&=\frac{3-2\sqrt2}{2}
\quad\text{at }p=\sqrt2-1.
\end{aligned}
\qquad\text{(11.10)}
$$

*Proof.* Differentiation gives $g'(p)=1/(1+p)^2-1/2$, positive before the stated point and negative after it. Substitution gives the maximum. Each term separately satisfies Theorem 8.3, while their difference does not retain its certified form. ∎

For example $g(1/2)=1/12>0$, so checking only the original vertices already fails. Equation (11.9) remains a valid definition for conditional utilities, but its inner problem is not generally an LP or a certified vertex problem. Joint endpoint optimization is required.

# 12 Neuroscience as a functional hypothesis

The mathematical results apply to declared event models. Neuroscience supplies evidence about abilities and possible computational roles. It does not establish that a brain represents a response polytope, computes ID or implements a mechanism sheaf. The proposed connection is a functional account that can be tested against behaviour and neural representations.

## 12.1 Acting and observing

Blaisdell et al. (2006) trained rats on causal arrangements including a common cause of a tone and food. Food expectation differed when the tone was produced by a lever press and when it was observed; a direct-cause condition supplied a comparison. The result supports sensitivity to the distinction between an event's usual source and an alternative source. It does not uniquely identify the animal's internal algorithm or prove execution of Pearl's calculus.

Sloman and Lagnado (2005) examine the same conceptual distinction in human judgement, while Lagnado and Sloman (2004, 2006) investigate how intervention and temporal information guide causal learning. The 2006 study shows that temporal order can dominate covariation and mislead when the order cue is misleading. ADC's clock theorem instead assumes a declared lag model and certifies its consequences. It does not learn those assumptions from chronology.

An exact common-cause illustration in the new kernel makes the distinction concrete. Let $U$ be fair and let cue $X$ and outcome $Y$ be independently flipped copies of $U$, each with flip probability $1/4$. Then $P(Y=1\mid X=1)=5/8$, while $P(Y=1\mid do(X=1))=1/2$. This is an illustrative SCM, not a fit to the animal data. A biological interpretation additionally needs a model of how the action produces the cue and of what information the subject has learned.

## 12.2 Physical time and neural sequence position

Eichenbaum (2014) reviews hippocampal cells active at successive moments of structured experiences and interprets them as temporal organization of memory. Buzsáki and Tingley (2018) offer a different account, emphasizing internally generated sequences and their rate of change rather than an instrument-like representation of space and time. These accounts motivate different decoder models. Neither supplies the calibrated world-time intervals required by Corollary 6.3.

Pfeiffer and Foster (2013) recorded hippocampal sequences depicting paths toward remembered goals before movement. Such sequences motivate a generator of candidate futures. The generated sequence itself is an internal computation. Its relation to a future environment intervention still requires an event model and a decoder contract.

**Lemma 12.1 (a calibrated temporal decoder).** Suppose a population or artificial latent decoder supplies $\hat\tau_i$ and certified errors $e_i\geq0$ in one physical unit, with $|\tau_i-\hat\tau_i|\leq e_i$. If

$$
\hat\tau_a-\hat\tau_b-e_a-e_b>0
\quad\text{for every }b\in Y\cup C,\ a\in A,
\qquad\text{(12.1)}
$$

then the strict orders needed by Theorem 6.1 hold. With its fixed-clock and nonnegative-lag assumptions, the action-deletion equality follows.

*Proof.* The left-hand expression is a lower bound for $\tau_a-\tau_b$. Apply the clock theorem to each pair. ∎

A zero margin is inconclusive for strict order. The new example has one decoded pair with margin 0 and a second with margin 7/20; only the second is certified. These are exact arithmetic illustrations. No neural decoder with these error bounds is reported. Sequence compression, replay speed and elapsed physical time remain different quantities.

## 12.3 What a causal memory must retain

A recent human study provides a closer functional connection. He et al. (2026) recorded hippocampal and cortical activity during two compositional inference tasks. Ripple-associated replay coordinated with medial prefrontal representations of inferred relational configurations and predicted efficient inference. This supports coordinated sequence generation and cortical representational updating. It does not establish mechanism replacement, causal-effect identification or the linear memory representation below.

Consider instead a precise engineering question: if a system consolidates response parameters into memory, which coordinates must it keep for a chosen family of causal queries? The parameters $q$ describe a model, rather than one token's state or one neural firing trajectory.

**Theorem 12.2 (minimal additional linear causal memory).** Suppose $Aq$ is retained, normalization is in its row space, and a query family has value vector $Cq$ on a simplex containing a full-support point. A linear memory $Tq$, together with $Aq$, preserves the query family exactly if and only if the kernel inclusion below holds. The minimum number of additional scalar coordinates is $k_{\min}$:

$$
\begin{aligned}
\ker\!\begin{bmatrix}A\\T\end{bmatrix}
&\subseteq\ker C,\\
k_{\min}
&=\operatorname{rank}\!\begin{bmatrix}A\\C\end{bmatrix}
-\operatorname{rank}A.
\end{aligned}
\qquad\text{(12.2)}
$$

*Proof.* Equal retained data differ by a vector in the displayed kernel. If the inclusion holds, all query values agree and hence factor through the retained data. If it fails, a violating direction can be added and subtracted at a small scale around a full-support point, giving two probability vectors with equal retained data and different queries. Row-space/nullspace duality turns the condition into inclusion of every query row in the row space of the stacked memory. At least the stated rank increment is needed. Retaining a basis of query rows modulo the row space of $A$ achieves it. ∎

In the bow example, observational response information has rank 4. Preserving both action probabilities raises the rank to 6 and needs 2 additional coordinates; preserving only their contrast needs 1. These counts refer to exact linear representations on the declared response simplex. They are not neuron counts or lower bounds for arbitrary nonlinear, finite-precision memories.

This gives a task-dependent consolidation principle: preserve the quotient information needed by the intended intervention queries. A memory sufficient for a preferred action contrast may be insufficient after the task changes to requiring each action probability separately. A neural implementation of this principle is a hypothesis about selective retention, not a consequence of ripple recordings.

## 12.4 Arbitration and testable hypotheses

Daw et al. (2005) develop a computational account of arbitration between controllers, balancing computational demands and uncertainty. ADC suggests a related design: use inexpensive event replacement when its structural certificate holds; otherwise use identification, bounded response optimization or additional information. Fibre width represents structural ambiguity, whereas an estimator's variance represents sampling uncertainty. Daw et al.'s account does not establish this particular decomposition in neural activity.

**Hypothesis H1 on temporal calibration.** In tasks with explicit event-time information, a model of decisions using calibrated time ranges will predict sensitivity to mixed date resolution better than a model that uses sequence position alone. Fix the task family and compare held-out action-deletion judgements. Failure to improve predictive fit under verified instruction comprehension would count against this proposed mapping. Lemma 12.1 remains a conditional mathematical statement regardless of the behavioural outcome.

**Hypothesis H2 on causal retention.** When two tasks share observations but require different intervention-query families, retention should preferentially preserve information relevant to the trained family. A computational test can first impose the linear memory budget of Theorem 12.2 and freeze a cross-task transfer protocol. A behavioural or neural study would additionally have to establish the participant's learned model class and exclude extra informative assumptions. Absence of query-specific retention under those controls would count against the biological interpretation.

The hypotheses concern what a representation preserves and how it is used. They make no claim that cortical layers are successive probability factors or that hippocampal sequence order is an intervention order. ASE inference depth, anatomical laminae, physical time and generated event order remain distinct.

# 13 An AI harness for causal computation

## 13.1 An authoritative problem and an untrusted proposal

An ADC harness has two inputs with different responsibilities. The authoritative problem supplies the event schema, graph and latent class, observational data, clock assumptions and query. A model may propose a derivation, witness or bound certificate. The verifier checks that proposal against the authoritative problem. This supports tool use without treating generated explanation as a proof.

**Definition 13.1 (certificate context).** A certificate context records the graph, latent-model class, observational-data version, query, decoder, clock unit, intervention scope and certificate-schema version. The deployed interface binds these fields to the problem contents. The reference prototype uses explicit version labels and checks exact equality before evaluating a packet.

[[TABLE_TOOL_RETURNS]]

The result categories describe different claims. A non-identification witness can accompany valid partial bounds and a robust action decision. An inconsistent clock is an input failure. An inconclusive clock is a failed shortcut, after which graphical reasoning may still succeed. A search that finds no witness is not thereby an identification proof.

**Theorem 13.2 (relative soundness of verified results).** Suppose the authoritative problem faithfully specifies the declared mathematical model class, and its primitive exact verifiers are correct. Accepting an identification derivation only by Theorem 4.5, a non-identification pair only by Theorem 3.4, an LP bound only by Theorems 11.6–11.9, and a clock deletion only by Corollary 6.3 gives sound results relative to that class. Reusing a result under an unequal certificate context is outside this guarantee.

*Proof.* Each accepted result has its corresponding semantic certificate. The relevant theorem proves its claim on the stated domain. Exact context matching preserves which domain and query that certificate concerns. Composition follows the induction of Theorem 4.5, retaining support and arithmetic premises. ∎

The theorem assumes the input meanings and the primitive checker; it is not formal verification of a software implementation or of a model extracted from natural language. Graph or unit errors can invalidate an otherwise correct calculation. Theorem 11.7 handles explicitly bounded coefficient changes; the ordinary cache path instead requires a matching context and a fresh check.

## 13.2 Computational interventions and world interventions

Geiger et al. (2021) align neural representations with variables in a high-level causal model and use interchange interventions to test the proposed abstraction. This is a relevant method for assessing Proposition 7.5. Meng et al. (2022) use activation restoration to trace factual computations and weight edits to alter associations in GPT. These are interventions on a computational model. They do not by themselves establish an intervention on the external event system represented by its text.

Here world names the declared system of interest, which may itself be software. The scope distinction is relative to the query: an intervention on a network can directly answer a question about that network while still requiring an abstraction argument for a question about its represented environment.

**Proposition 13.3 (three levels of an intervention answer).** Let $P^L_a$ be the law of a clamped latent computation, $d_\#P^L_a$ its decoded event law, $\widetilde P^E_a$ the event-replacement law, and $P^W_a$ the intended world-intervention law. If the first two discrepancies in

$$
\operatorname{TV}(d_\#P^L_a,\widetilde P^E_a)\leq\epsilon,
\qquad
\operatorname{TV}(\widetilde P^E_a,P^W_a)\leq\kappa
\qquad\text{(13.1)}
$$

are bounded as shown, and a reported event probability $z_B$ differs from the decoded probability by at most $\eta$, then

$$
|z_B-P^W_a(B)|\leq\eta+\epsilon+\kappa.
\qquad\text{(13.2)}
$$

*Proof.* For an event, a difference of probabilities is bounded by total variation. Apply the triangle inequality to the reported, decoded, replaced-event and world probabilities. ∎

Proposition 7.5 can supply $\epsilon$. Corollary 7.2 identifies replacement with the declared SCM intervention when its conditions hold. Equality of that SCM with the intended world intervention is additional semantic information; it must not be inferred from a successful activation patch. This separation also applies when an agent issues a tool call: computing a do-expression is different from executing an environment operation that realizes its assumed mechanism replacement.

## 13.3 How existing harness work fits

CLadder generates association, intervention and counterfactual questions with symbolic causal ground truth (Jin et al., 2023). Corr2Cause tests entailment of graph relations from conditional-independence statements under its closed-system and graph assumptions, including Markov-equivalence ambiguity (Jin et al., 2024). These are different tasks. The present ADC kernel addresses interventional probabilities and specified partial bounds; it does not supply a complete counterfactual-identification engine.

Kıcıman et al. (2024) study how language models can contribute causal arguments and contextual knowledge, while also documenting failures and motivating combination with causal methods. Zečević et al. (2023) propose a causal-parrot explanation of apparent competence. Their interpretation is a hypothesis about such systems, not a theorem that all future language-model architectures must fail. Theorem 11.10 supplies a narrower information limit: no method can resolve an observational fibre without additional information. A language model may contribute additional structural knowledge, which must be declared and assessed as such. The cited benchmark findings concern the models tested at publication and are not performance estimates for current frontier models.

ReAct provides an interleaved reasoning and tool-use pattern (Yao et al., 2023). ADC can occupy the tool position with typed results rather than a free-text verdict. SWE-agent shows the importance of the agent–computer interface in software engineering (Yang et al., 2024); the relevant design lesson here is to make valid inputs, results and failures explicit. Neither paper establishes ADC's causal correctness or a performance gain from using it.

The versioned lm-evaluation-harness release supplies a precedent for shared evaluation specifications (Gao et al., 2021). Inspect separates datasets, solvers, tools and scorers and records evaluation traces (UK AI Security Institute & Meridian Labs, n.d.). A proposed ADC integration puts model proposals in the solver, exact kernels in custom tools, and certificate verification and answer scoring in deterministic scorers. A reproducible trace documents execution; the mathematical certificate supplies the validity claim.

## 13.4 The executable prototype and new checks

The new immutable C# packet verifier implements the linear-bound branch. Its command-line interface takes an authoritative fixture and a separate proposed packet, then returns a structured status and certified endpoints when accepted. The fixture supplies the graph-class labels and exact matrix problem. Keeping that fixture outside the proposing agent's authority is a deployment requirement. The prototype tests context equality; it does not implement an access-control system.

The verifier checks dimensions, nonnegative normalized primal vectors, equality constraints and both dual inequalities. Matching primal and dual objectives produce the status SharpBounds; valid unmatched dual bounds produce OuterBounds. The companion schema and source specify the packet fields. Existing ID, IDC and clock kernels remain available, while their integration into a trained-agent runtime is proposed rather than benchmarked.

[[TABLE_V3_CHECKS]]

All 16 new C# summary lines agree with independent exact Python calculations. The two LP examples are also re-solved with HiGHS, and symbolic differentiation verifies the interior ratio-contrast maximum. The executable command interface passes 3 independent fixture calls. The 30 inherited summary lines and their result files reproduce the supplied computation; the full verification record distinguishes exact equality, arithmetic enclosure and floating-point LP cross-checks.

The dual fixture returns the effect interval $[2/5,4/5]$. Giving the observational cells simultaneous slabs of radius $1/100$ changes the sharp range to $[39/100,81/100]$, attained by the supplied feasible response laws. The perturbation example changes both an observation channel and the target coefficients: the old bound fails, whereas the residual correction contains the new range. These are exact finite checks of contracts, not training experiments or evidence of a biological implementation.

## 13.5 A frozen learned-agent comparison

Conjecture C3 remains untested. A useful evaluation would freeze graph families, model classes, data splits, event decoders, query weights, prompts and denominators before comparing four methods: event replacement, free-text causal answering, execution of identified expressions, and the proposed ADC harness with verified bounds and failure categories. Graph access and data must be matched. Report token, tool-call, exact-operation and elapsed-time budgets separately.

Stratify results by identified and non-identified queries, the last-in-district certificate, conditioning context and date resolution. For point-identified targets report interventional error. For partial targets report endpoint accuracy, containment, width and false point-identification claims. Score mathematical validity separately from extraction of the intended graph and event meanings. Include mutated query, data, latent-class, decoder, unit and intervention-scope contexts as tests of certificate reuse.

CLadder and Corr2Cause can contribute distinct task components; synthetic response fibres supply exact partial-identification targets. Inspect or another logged harness can orchestrate the runs, but a scorer must verify the actual certificate. The proposed halving of C3's error ratio remains a prediction. The deterministic prototype does not establish it.

# 14 Conclusion

ADC connects autoregressive event generation to declared causal semantics. Its horizontal mechanism sheaf records local equations and shared variables, while identification and probability algebra justify their causal use. Clock certificates and the last-in-district condition specify when a cheaper computation already answers the intended intervention.

The response-fibre analysis turns added computation into mathematical contracts. Independent district response laws form a product of polytopes on a positive observational fibre. This gives a single-district witness result, an ideal retry bound, sharp vertex characterizations and a linear-fractional route to conditional bounds. Primal and dual certificates make proposed bounds independently checkable. Fibre width determines an unavoidable scalar ambiguity radius, while shared-model utility comparisons can still certify an action. A task's causal query family also determines the extra rank needed by an exact linear memory.

The neuroscience supplies functional hypotheses about intervention sensitivity, temporal decoding, sequence generation and selective retention. The agent harness supplies a concrete boundary between proposals and verified mathematical results. The remaining empirical work is to test those mappings and learned-system benefits while retaining the model-class, decoder and precision assumptions on which the guarantees depend.
