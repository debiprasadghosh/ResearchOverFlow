Blaisdell, A. P., Sawa, K., Leising, K. J., & Waldmann, M. R. (2006). Causal reasoning in rats. *Science, 311*(5763), 1020–1022. https://doi.org/10.1126/science.1121872

Boyd, S., & Vandenberghe, L. (2004). *Convex optimization*. Cambridge University Press. https://web.stanford.edu/~boyd/cvxbook/

Buzsáki, G., & Tingley, D. (2018). Space and time: The hippocampus as a sequence generator. *Trends in Cognitive Sciences, 22*(10), 853–869. https://doi.org/10.1016/j.tics.2018.07.006

Daw, N. D., Niv, Y., & Dayan, P. (2005). Uncertainty-based competition between prefrontal and dorsolateral striatal systems for behavioral control. *Nature Neuroscience, 8*(12), 1704–1711. https://doi.org/10.1038/nn1560

Duarte, G., Finkelstein, N., Knox, D., Mummolo, J., & Shpitser, I. (2024). An automated approach to causal inference in discrete settings. *Journal of the American Statistical Association, 119*(547), 1778–1793. https://doi.org/10.1080/01621459.2023.2216909

Eichenbaum, H. (2014). Time cells in the hippocampus: A new dimension for mapping memories. *Nature Reviews Neuroscience, 15*(11), 732–744. https://doi.org/10.1038/nrn3827

Gao, L., Tow, J., Biderman, S., Black, S., DiPofi, A., Foster, C., Golding, L., Hsu, J., McDonell, K., Muennighoff, N., Phang, J., Reynolds, L., Tang, E., Thite, A., Wang, B., Wang, K., & Zou, A. (2021). *A framework for few-shot language model evaluation* (Version v0.0.1) [Computer software]. Zenodo. https://doi.org/10.5281/zenodo.5371629

Geiger, A., Lu, H., Icard, T., & Potts, C. (2021). Causal abstractions of neural networks. *Advances in Neural Information Processing Systems, 34*. https://papers.nips.cc/paper/2021/hash/4f5c422f4d49a5a807eda27434231040-Abstract.html

He, L., Wang, X., Zhang, J., Xiao, Z., Hu, X., Schwartenbeck, P., Bakermans, J., Behrens, T., & Liu, Y. (2026). Human hippocampal ripples coordinate planning sequences and compositional representations in neocortex. *Nature Neuroscience, 29*(7), 1711–1721. https://doi.org/10.1038/s41593-026-02291-3

Jin, Z., Chen, Y., Leeb, F., Gresele, L., Kamal, O., Lyu, Z., Blin, K., Gonzalez Adauto, F., Kleiman-Weiner, M., Sachan, M., & Schölkopf, B. (2023). CLadder: Assessing causal reasoning in language models. *Advances in Neural Information Processing Systems, 36*. https://doi.org/10.52202/075280-1353

Jin, Z., Liu, J., Lyu, Z., Poff, S., Sachan, M., Mihalcea, R., Diab, M., & Schölkopf, B. (2024). Can large language models infer causation from correlation? In *International Conference on Learning Representations*. https://arxiv.org/abs/2306.05836v3

Kıcıman, E., Ness, R., Sharma, A., & Tan, C. (2024). *Causal reasoning and large language models: Opening a new frontier for causality* [Preprint, version 3]. arXiv. https://arxiv.org/abs/2305.00050v3

Lagnado, D. A., & Sloman, S. A. (2004). The advantage of timely intervention. *Journal of Experimental Psychology: Learning, Memory, and Cognition, 30*(4), 856–876. https://doi.org/10.1037/0278-7393.30.4.856

Lagnado, D. A., & Sloman, S. A. (2006). Time as a guide to cause. *Journal of Experimental Psychology: Learning, Memory, and Cognition, 32*(3), 451–460. https://doi.org/10.1037/0278-7393.32.3.451

Meng, K., Bau, D., Andonian, A., & Belinkov, Y. (2022). Locating and editing factual associations in GPT. *Advances in Neural Information Processing Systems, 35*. https://proceedings.nips.cc/paper_files/paper/2022/file/6f1d43d5a82a37e89b0665b33bf3a182-Paper-Conference.pdf

Pfeiffer, B. E., & Foster, D. J. (2013). Hippocampal place-cell sequences depict future paths to remembered goals. *Nature, 497*(7447), 74–79. https://doi.org/10.1038/nature12112

Schwartz, J. T. (1980). Fast probabilistic algorithms for verification of polynomial identities. *Journal of the ACM, 27*(4), 701–717. https://doi.org/10.1145/322217.322225

Sloman, S. A., & Lagnado, D. A. (2005). Do we “do”? *Cognitive Science, 29*(1), 5–39. https://doi.org/10.1207/s15516709cog2901_2

UK AI Security Institute, & Meridian Labs. (n.d.). *Inspect* [Software documentation]. Retrieved October 30, 2026, from https://inspect.aisi.org.uk/

Yang, J., Jimenez, C. E., Wettig, A., Lieret, K., Yao, S., Narasimhan, K., & Press, O. (2024). SWE-agent: Agent-computer interfaces enable automated software engineering. *Advances in Neural Information Processing Systems, 37*. https://doi.org/10.52202/079017-1601

Yao, S., Zhao, J., Yu, D., Du, N., Shafran, I., Narasimhan, K., & Cao, Y. (2023). ReAct: Synergizing reasoning and acting in language models. In *International Conference on Learning Representations*. https://arxiv.org/abs/2210.03629v3

Zečević, M., Willig, M., Dhami, D. S., & Kersting, K. (2023). Causal parrots: Large language models may talk causality but are not causal. *Transactions on Machine Learning Research*. https://arxiv.org/abs/2308.13067v1
