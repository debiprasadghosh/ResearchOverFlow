"""Update the authoritative V3 Word paper with the sequential evidence extension."""
from __future__ import annotations
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
import copy,hashlib,json,re,subprocess,tempfile,unicodedata,zipfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from lxml import etree

ROOT=Path(__file__).resolve().parent;BASE=ROOT/'base_v3.docx'
DEST=ROOT/'deliverables';DEST.mkdir(exist_ok=True)
OUT=DEST/'Autoregressive_Do_Calculus_Sequential_Evidence_V4.docx'
v=json.loads((ROOT/'validation_v4.json').read_text());assert v['all_passed']
results=json.loads((ROOT/'out_v4/sequential_results.json').read_text());r=results['records']
fills={'RECOVERY_ERROR':r['noisy_recovery'][2],'MEMORY_RANK':r['memory_release'][0],
       'MEMORY_BEFORE':r['memory_release'][1],'MEMORY_AFTER':r['memory_release'][3],
       'NEW_CHECKS':results['record_count']}
md=(ROOT/'extension_v4.md').read_text()
for k,x in fills.items():md=md.replace('{{'+k+'}}',str(x))
assert not re.search(r'\{\{[A-Z_]+\}\}',md)
(ROOT/'extension_v4_filled.md').write_text(md)
doc=Document(BASE);body=doc.element.body;warnings=[]
M='http://schemas.openxmlformats.org/officeDocument/2006/math'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
def find(text,style=None):
    for p in doc.paragraphs:
        if p.text.startswith(text) and (style is None or p.style.name==style):return p
    raise KeyError(text)
def before(anchor,els):
    for e in els:anchor.addprevious(e)
def fragment(text):
    with tempfile.TemporaryDirectory() as td:
        p=Path(td);(p/'f.md').write_text(text)
        run=subprocess.run(['pandoc',str(p/'f.md'),'-f','markdown+tex_math_dollars-auto_identifiers',
            '-o',str(p/'f.docx'),f'--reference-doc={BASE}','--no-highlight'],capture_output=True,text=True,check=True)
        if run.stderr.strip():warnings.append(run.stderr)
        f=Document(p/'f.docx');els=[copy.deepcopy(e) for e in f.element.body if e.tag!=qn('w:sectPr')]
        for e in els:
            for b in list(e.iter(qn('w:bookmarkStart')))+list(e.iter(qn('w:bookmarkEnd'))):b.getparent().remove(b)
            for x in e.iter():
                rid=x.get('{'+R+'}id')
                if rid and rid in f.part.rels:
                    rel=f.part.rels[rid];assert rel.is_external
                    x.set('{'+R+'}id',doc.part.relate_to(rel.target_ref,rel.reltype,is_external=True))
        return els

find('Autoregressive Do Calculus','Title').text='Autoregressive Do Calculus\nwith Sequential Evidence'
find('Sharp bounds','Subtitle').text='Experimental choice and the precision of causal memory'
for p in doc.paragraphs:
    if p.style.name=='Date':p.text='Version 4 · 31 October 2026'
find('Autoregressive Do Calculus (ADC) is a finite discipline').text=(
 'Autoregressive Do Calculus (ADC) connects event generators to declared causal models, mechanism sheaves and checkable '
 'uncertainty statements. This paper develops its response-fibre mathematics, functional neuroscience hypotheses and causal-agent '
 'interface, then extends them to sequential evidence. In a fixed finite linear response model, retaining all reports in one '
 'evidence ledger makes sharp query ranges and worst-case action regret nonincreasing. An elementary confidence sequence '
 'preserves containment under adaptive allocation and stopping, assuming fresh stationary regime streams and correct intervention '
 'semantics. A two-model linear programme computes the worst query ambiguity remaining after an exact experiment, with a '
 'bounded-report extension. A complementary optimal-recovery theorem gives the exact minimax error of a scalar linear causal '
 'query from noisy linear memory. It equates indistinguishability of response models with a tradeoff between omitted information '
 'and noise amplification, and supplies an optimal affine decoder on a compact polytope. Exact evidence can release query-memory '
 'coordinates, but allowed measurements can be complementary: neither alone reduces worst-case width while the pair identifies '
 'the query. Even every perfect-intervention distribution can leave a cross-world coupling unresolved. These results refine the '
 'earlier product-fibre, witness, primal-dual and decoder contracts without extending their model classes implicitly. Neuroscience '
 'motivates testable roles for temporal calibration, selective retention and evidence acquisition; it does not establish neural '
 'execution of the algorithms. The inherited immutable C# interface is retained, and a new immutable Python ledger demonstrates '
 f'refinement checks. All {v["record_count"]} new deterministic records pass closed-form and independent LP checks, including '
 f'{v["highs_solves"]} HiGHS solves; clean-process replay is byte-identical. The inherited 46 C# records and their validation '
 'reports are preserved unchanged. Learned-agent benefits and biological mappings remain empirical hypotheses.')
kw=find('Keywords');kw.text='';kw.add_run('Keywords ').bold=True
kw.add_run('autoregressive generation; do-calculus; sequential evidence; response polytopes; optimal recovery; causal memory; experimental design; mechanism sheaves')
before(find('1.2 Contribution','Heading 2')._p,fragment(
 'Sequential evaluation adds a statistical and decision layer to causal identification. Hoeffding (1963) supplies finite-sample '
 'concentration, and Howard et al. (2021) develop time-uniform confidence sequences. Optimal recovery relates estimation difficulty '
 'to indistinguishable objects (Donoho, 1994). Section 14 specializes finite versions of these ideas to one response model, including '
 'its experimental channels and memory precision. Experimental identification and cross-world identification remain distinct '
 '(Shpitser & Pearl, 2007).'))
find('The response computations are developed into product-fibre structure').text=(
 'The response computations yield product-fibre structure, one-district witness existence, an ideal retry bound, bound certificates, '
 'conditional optimization, robust regret and a linear memory criterion. The sequential extension adds monotone evidence refinement, '
 'valid stopping under explicit sampling assumptions, query-directed experimental design and sharp bounded-noise recovery. A '
 'complementarity counterexample limits one-step acquisition policies. Each result records its model class, including the distinction '
 'between common-latent clique districts and the original pairwise-primitive setting.')
find('Sections 2 to 5 specify finite models').text=(
 'Sections 2 to 5 specify models, sheaves, query semantics and classical identification. Sections 6 to 8 develop clocks, replacement '
 'and credal precision. Sections 9 and 10 report earlier finite studies. Section 11 proves response-fibre and certificate results. '
 'Sections 12 and 13 develop neuroscience hypotheses and the agent interface. Section 14 adds sequential evidence, experimental '
 'choice, memory precision and acquisition hypotheses. Section 15 concludes. Appendix A collects assumptions; Appendix B records '
 'the source and reproduction routes.')

conclusion='''# 15 Conclusion

ADC connects autoregressive event generation to declared causal semantics. Its horizontal mechanism sheaf records local equations and shared variables, while identification and probability algebra justify their causal use. Clock certificates and the last-in-district condition specify when a cheaper computation answers the intended intervention. A decoder contract is still required when latent states stand for events.

The response-fibre analysis supplies witness, range and decision certificates. Its sequential extension keeps one model across reports, proves monotone refinement and states the sampling conditions needed for adaptive stopping. The two-model experiment programme asks which distinctions an allowed measurement leaves unresolved. Its recovery dual asks how accurately a retained memory can answer the chosen linear query. Exact rank, omitted information and stored precision have different responsibilities.

Complementary channels can defeat a one-step acquisition rule, and complete single-world evidence can still leave cross-world coupling uncertain. These limits define what an acquisition or consolidation policy must specify. They also prevent a valid arithmetic answer from being promoted into a stronger causal claim than its evidence supports.

The neuroscience roles and learned-agent comparisons remain hypotheses. The executable components demonstrate finite mathematical contracts; the remaining empirical work is to test representations, acquisition policies and learned decoders under the model, task and precision assumptions stated here.
'''
old=find('14 Conclusion','Heading 1')._p;app=find('Appendix A','Heading 1')._p
e=old
while e is not app:
    nxt=e.getnext();e.getparent().remove(e);e=nxt
before(app,fragment(md+'\n\n'+conclusion))

def caption(text,keep=True):
    p=doc.add_paragraph(text,style='Caption');p.paragraph_format.keep_with_next=keep
    p.paragraph_format.space_before=Pt(8);p.paragraph_format.space_after=Pt(6)
    for run in p.runs:run.font.size=Pt(10);run.font.italic=True;run.font.color.rgb=RGBColor(0,0,0)
    e=p._p;e.getparent().remove(e);return e
def style_table(t,widths):
    tp=t._tbl.tblPr
    for x in list(tp):tp.remove(x)
    for tag,attrs in [('tblW',{'w':str(sum(widths)),'type':'dxa'}),('jc',{'val':'center'})]:
        x=OxmlElement('w:'+tag)
        for k,val in attrs.items():x.set(qn('w:'+k),val)
        tp.append(x)
    b=OxmlElement('w:tblBorders')
    for side in ('top','left','bottom','right','insideH','insideV'):
        x=OxmlElement('w:'+side)
        for k,val in {'val':'single','sz':'4','color':'D9D9D9'}.items():x.set(qn('w:'+k),val)
        b.append(x)
    tp.append(b);x=OxmlElement('w:tblLayout');x.set(qn('w:type'),'fixed');tp.append(x)
    for g,width in zip(t._tbl.tblGrid.gridCol_lst,widths):g.set(qn('w:w'),str(width))
    for ri,row in enumerate(t.rows):
        pr=row._tr.get_or_add_trPr()
        for x in list(pr):pr.remove(x)
        pr.append(OxmlElement('w:cantSplit'))
        if ri==0:pr.append(OxmlElement('w:tblHeader'))
        for cell,width in zip(row.cells,widths):
            cp=cell._tc.get_or_add_tcPr()
            for x in list(cp):cp.remove(x)
            x=OxmlElement('w:tcW');x.set(qn('w:w'),str(width));x.set(qn('w:type'),'dxa');cp.append(x)
            x=OxmlElement('w:shd');x.set(qn('w:val'),'clear');x.set(qn('w:fill'),'EDF0F2' if ri==0 else 'FFFFFF');cp.append(x)
            margin=OxmlElement('w:tcMar')
            for side in ('top','left','bottom','right'):
                x=OxmlElement('w:'+side);x.set(qn('w:w'),'85');x.set(qn('w:type'),'dxa');margin.append(x)
            cp.append(margin);x=OxmlElement('w:vAlign');x.set(qn('w:val'),'center');cp.append(x)
            for p in cell.paragraphs:
                p.style=doc.styles['Body Text'];pf=p.paragraph_format
                pf.space_before=Pt(0);pf.space_after=Pt(2);pf.line_spacing=1.05;pf.keep_with_next=False
                for run in p.runs:run.font.size=Pt(10);run.font.bold=ri==0;run.font.color.rgb=RGBColor(0,0,0)

anchor=find('[[TABLE_V4_CHECKS]]')._p
before(anchor,[caption('Table 8 Sequential evidence and recovery checks')])
rows=[['Check','Size or values','Verified statement'],
      ['Nested bow evidence','Widths 2/5, 1/10, 1/25, 0','All four exact ranges and their regret bounds agree'],
      ['Refinement interface','8 candidate transitions','1 accepted; 7 context, parent, constraint or consistency failures rejected'],
      ['Complementary channels','Worst remaining widths 1, 1, 1, 0','Two-model LP matches the analytic counterexample'],
      ['Noisy causal memory','6 noise budgets; 2 channel designs','Exact LP risks equal the closed-form recovery bounds'],
      ['Query-memory release','2 coordinates reduced to 1','Exact ranks and independent matrix ranks agree'],
      ['Cross-world remainder','All 9 perfect-intervention regimes','Identical single-world tables; coupling probabilities 1 and 0'],
      ['New verification record',f'{v["record_count"]} records; {v["highs_solves"]} LP solves','All checks pass; clean-process output matches byte for byte']]
t=doc.add_table(rows=0,cols=3)
for row in rows:
    for cell,text in zip(t.add_row().cells,row):cell.text=text
style_table(t,[2600,2800,4248]);e=t._tbl;e.getparent().remove(e);before(anchor,[e]);anchor.getparent().remove(anchor)
for row in t.rows[:-1]:
    for cell in row.cells:
        for p in cell.paragraphs:p.paragraph_format.keep_with_next=True

figdir=ROOT/'figures';figdir.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(1,2,figsize=(9.0,3.45))
eps=np.linspace(0,.5,301)
axes[0].plot(eps,np.minimum(2*eps,.5),label='Two complementary channels',color='#315d75',lw=2)
axes[0].plot(eps,np.minimum(eps,.5),label='Direct target channel',color='#ad6e30',lw=1.8,ls='--')
axes[0].scatter([float(F(x)) for x in results['epsilon_grid']],[float(F(x)) for x in r['noisy_recovery']],s=18,color='#315d75',zorder=3)
axes[0].set(xlabel='Error budget per stored channel',ylabel='Minimax absolute query error',title='(a) Equal exact rank can hide different precision',ylim=(-.015,.53),xlim=(0,.5))
axes[0].legend(frameon=False,fontsize=7.5,loc='lower right');axes[0].grid(alpha=.15)
ys=list(map(lambda x:float(F(x)),r['experiment_width']))
axes[1].bar(range(4),ys,color=['#9a9fa3','#7394a6','#7394a6','#315d75'],width=.62)
axes[1].scatter([3],[0],color='#315d75',zorder=3)
for i,y in enumerate(ys):axes[1].text(i,y+.035,str(int(y)),ha='center',fontsize=9)
axes[1].set(xticks=range(4),xticklabels=['None','Channel 1','Channel 2','Both'],ylabel='Worst remaining query width',title='(b) Evidence can require joint acquisition',ylim=(-.03,1.2))
axes[1].grid(axis='y',alpha=.15);axes[1].set_axisbelow(True)
fig.tight_layout(w_pad=2.0)
figpath=figdir/'v4_evidence_recovery.png';fig.savefig(figpath,dpi=240,bbox_inches='tight');fig.savefig(figdir/'v4_evidence_recovery.svg',bbox_inches='tight');plt.close(fig)
anchor=find('[[FIGURE_V4]]')._p
p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.keep_with_next=True
p.add_run().add_picture(str(figpath),width=Inches(6.7));e=p._p;e.getparent().remove(e)
before(anchor,[e,caption('Figure 5 Experimental complementarity and the precision cost of causal memory',False)]);anchor.getparent().remove(anchor)

for t in doc.tables:
    if t.rows[0].cells[0].text.strip()=='Statement':
        additions=[
         ('14.2–14.3 Evidence refinement','Fixed response model and target; retained old constraints; nonempty intersections','Monotone sharp ranges and regret; outer-bound reuse'),
         ('14.4 and 14.10 Adaptive validity','Finite regime menu; fresh stationary streams; predictable allocation; valid radii','Simultaneous containment and regret validity at a finite adaptive stop'),
         ('14.5–14.6 Design and recovery','One compact response polytope; linear maps and scalar query; specified error box','Sharp two-model width and deterministic minimax recovery'),
         ('14.7–14.8 Memory and acquisition','Exact linear summaries on a full response simplex; fixed query family','Rank release and a counterexample to submodular query gain'),
         ('14.9 Cross-world remainder','The two specified positive binary models with the same allowed graph','Complete single-world data need not fix cross-world coupling')]
        for row in additions:
            for cell,text in zip(t.add_row().cells,row):cell.text=text
        style_table(t,[2300,3600,3748])

refs=find('References','Heading 1')
appendix=f'''## B.6 Sequential evidence additions

sequential_reference.py adds immutable response polytopes and evidence ledgers, exact Fraction elimination and active-constraint vertex enumeration. It does not alter the inherited C# project. The new suite reports {v['record_count']} deterministic records. validate_v4.py independently solves {v['lp_cases']} LP cases in both objective directions with HiGHS, giving {v['highs_solves']} solves within absolute tolerance $10^{{-9}}$. It also checks the analytic recovery curves, probability tables, confidence-budget sum, NumPy matrix ranks and interface failure categories.

A fresh Python process reproduces the new summary and result JSON byte for byte. All {v['inherited_files_unchanged']} inherited summary and mathematical-result files match their Version 3 manifest hashes. Their earlier validation and replay reports are retained; the original C# suites were not rerun in Version 4. The current new calculations used Python {v['runtime']['python']}, NumPy {v['runtime']['numpy']} and SciPy {v['runtime']['scipy']}. The binary64 radii illustrate the concentration formula; they are not an outward-rounded transcendental implementation.

The source archive includes the current Word base, builder, resolved extension, reading copy, new exact module, independent checker and complete results. It retains the earlier C# sources and validation records. No trained-agent comparison, new neural experiment or deployment of an evidence-acquisition policy is reported.
'''
before(refs._p,fragment(appendix))
for p in doc.paragraphs:
    if 'This revision used .NET SDK 8.0.427' in p.text:p.text=p.text.replace('This revision used','Version 3 used')
    if 'The verified environment was .NET SDK 8.0.131' in p.text:p.text=p.text.replace('The verified environment was','Version 2 reported its environment as')

newrefs=fragment((ROOT/'references_v4.md').read_text());entries=[];e=refs._p.getnext()
while e is not None and e.tag!=qn('w:sectPr'):
    nxt=e.getnext()
    if e.tag==qn('w:p') and ''.join(e.itertext()).strip():entries.append(e)
    e.getparent().remove(e);e=nxt
entries+=newrefs
def sortkey(e):return ''.join(c for c in unicodedata.normalize('NFD',''.join(e.itertext())) if unicodedata.category(c)!='Mn').casefold()
for e in sorted(entries,key=sortkey):body.insert(len(body)-1,e)

inrefs=False
for p in doc.paragraphs:
    if p.text=='References':inrefs=True;p.paragraph_format.page_break_before=True;continue
    if inrefs:
        p.style=doc.styles['Bibliography'];p.paragraph_format.left_indent=Inches(.22);p.paragraph_format.first_line_indent=Inches(-.22)
        p.paragraph_format.line_spacing=1.02;p.paragraph_format.space_after=Pt(5);p.paragraph_format.keep_together=True
    if re.match(r'^(Definition|Theorem|Proposition|Lemma|Corollary) \d+\.\d+ \(',p.text):p.paragraph_format.keep_with_next=True
    if p.text.startswith("For a coordinate after its regime"):p.paragraph_format.keep_with_next=True
    if p.text.startswith('Hypothesis H3'):p.paragraph_format.keep_together=True
    if p._p.find(qn('m:oMathPara')) is not None:p.paragraph_format.keep_together=True;p.paragraph_format.space_before=Pt(4);p.paragraph_format.space_after=Pt(7)
    if p.style.name.startswith(('Title','Subtitle','Heading')):
        for run in p.runs:run.font.color.rgb=RGBColor(0,0,0);run.font.underline=False
    if p.style.name=='Title':
        for x in list(p._p.iter(qn('w:pBdr'))):x.getparent().remove(x)
PPR=('pStyle keepNext keepLines pageBreakBefore framePr widowControl numPr suppressLineNumbers pBdr shd tabs suppressAutoHyphens '
     'kinsoku wordWrap overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi adjustRightInd snapToGrid spacing ind '
     'contextualSpacing mirrorIndents suppressOverlap jc textDirection textAlignment textboxTightWrap outlineLvl divId '
     'cnfStyle rPr sectPr pPrChange').split()
def reorder(parent,order):
    for e in sorted(list(parent),key=lambda e:order.index(etree.QName(e).localname) if etree.QName(e).localname in order else 99):parent.append(e)
for x in body.iter(qn('w:pPr')):reorder(x,PPR)
for x in body.iter(qn('m:dPr')):reorder(x,['begChr','sepChr','endChr','grow','shp','ctrlPr'])
for x in body.iter(qn('m:mcPr')):reorder(x,['count','mcJc'])
for x in body.iter(qn('m:rPr')):
    if x.find(qn('m:nor')) is not None:
        for e in x.findall(qn('m:sty'))+x.findall(qn('m:scr')):x.remove(e)
    reorder(x,['lit','nor','scr','sty','brk','aln'])
for rr in body.iter(qn('m:r')):
    if re.fullmatch(r'\(\d+\.\d+\)',rr.findtext(qn('m:t')) or ''):
        pr=rr.find(qn('m:rPr'))
        if pr is None:pr=OxmlElement('m:rPr');rr.insert(0,pr)
        for x in list(pr):pr.remove(x)
        x=OxmlElement('m:sty');x.set(qn('m:val'),'p');pr.append(x)
doc.core_properties.title='Autoregressive Do Calculus with Sequential Evidence'
doc.core_properties.subject='Sequential causal evidence experimental choice and memory precision'
doc.core_properties.modified=datetime(2026,10,31,tzinfo=timezone.utc)
doc.save(OUT);(ROOT/'pandoc_v4.log').write_text('\n'.join(warnings));assert not warnings,warnings
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    for n in z.namelist():
        if n.endswith('.xml'):etree.fromstring(z.read(n))
    x=etree.fromstring(z.read('word/document.xml'));text=' '.join(x.itertext())
    assert not re.search(r'\{\{[A-Z_]+\}\}|\[\[(TABLE|FIGURE)_|\bgenui\b',text)
    media={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/')}
with zipfile.ZipFile(BASE) as z:oldmedia={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/')}
assert oldmedia<=media
inventory=re.findall(r'^(Definition|Theorem|Proposition|Lemma|Corollary) (\d+\.\d+) \(','\n'.join(p.text for p in doc.paragraphs),re.M)
assert len(inventory)==len(set(inventory))==60
audit=dict(zip_and_xml_well_formed=True,full_schema_validation_claimed=False,old_figures_preserved=len(oldmedia),
           native_equations=len(x.findall('.//'+qn('m:oMath'))),tables=len(doc.tables),
           formal_statements=[a+' '+b for a,b in inventory],filled_values=fills)
(ROOT/'document_v4_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps(dict(path=str(OUT),formal_statements=len(inventory),tables=len(doc.tables),native_equations=audit['native_equations']),indent=2))
