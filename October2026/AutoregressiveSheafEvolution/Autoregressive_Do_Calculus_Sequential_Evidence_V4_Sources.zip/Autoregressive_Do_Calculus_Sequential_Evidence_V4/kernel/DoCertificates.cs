// ADC V3: exact certificates for response fibres, conditional bounds and typed tool results.
// Published values are immutable. Gaussian elimination uses only private scratch arrays.
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text.Json;

namespace Tcr;

public sealed record CertificateContext(string Graph, string LatentClass, string Data,
    string Query, string Decoder, string TimeUnit, string Scope, string Schema);
public sealed record BoundCertificate(CertificateContext Context,
    ImmutableArray<Q> LowerDual, ImmutableArray<Q> UpperDual,
    ImmutableArray<Q> LowerPrimal, ImmutableArray<Q> UpperPrimal);

public static class DoCertificates
{
    static Q[] Z(int n)=>Enumerable.Repeat(Q.Zero,n).ToArray();
    static Q Dot(IEnumerable<Q> a,IEnumerable<Q> b)=>a.Zip(b,(x,y)=>x*y).Aggregate(Q.Zero,(x,y)=>x+y);
    static Q[] Apply(Q[][] a,Q[] q)=>a.Select(row=>Dot(row,q)).ToArray();
    static Q[] TransposeApply(Q[][] a,Q[] v)=>Enumerable.Range(0,a[0].Length)
        .Select(j=>Dot(a.Select(r=>r[j]),v)).ToArray();
    static Q Abs(Q x)=>x.Sign<0?-x:x;
    static Q Inf(IEnumerable<Q> a)=>a.Select(Abs).Aggregate(Q.Max);
    static string[] Text(IEnumerable<Q> a)=>a.Select(q=>q.ToString()).ToArray();
    static string F(object o)=>o switch {
        bool b=>b?"1":"0",double d=>d.ToString("R",CultureInfo.InvariantCulture),
        IFormattable f=>f.ToString(null,CultureInfo.InvariantCulture),_=>o.ToString()??""};
    static void Emit(string key,params object[] a)=>Console.WriteLine(key+"\t"+string.Join(" ",a.Select(F)));

    static IEnumerable<int[]> Combinations(int n,int k)
    {
        IEnumerable<int[]> Go(int start,List<int> taken)
        {
            if(taken.Count==k){yield return taken.ToArray();yield break;}
            for(int j=start;j<=n-(k-taken.Count);j++)
            {taken.Add(j);foreach(var a in Go(j+1,taken))yield return a;taken.RemoveAt(taken.Count-1);}
        }
        return Go(0,new());
    }
    static Q[]? Solve(Q[][] a,Q[] b)
    {
        int n=b.Length;var t=a.Select((r,i)=>r.Append(b[i]).ToArray()).ToArray();
        for(int k=0;k<n;k++)
        {
            int pivot=Enumerable.Range(k,n-k).FirstOrDefault(i=>!t[i][k].IsZero,-1);
            if(pivot<0)return null;
            (t[k],t[pivot])=(t[pivot],t[k]);Q div=t[k][k];
            for(int j=k;j<=n;j++)t[k][j]/=div;
            for(int i=0;i<n;i++)if(i!=k)
            {Q f=t[i][k];for(int j=k;j<=n;j++)t[i][j]-=f*t[k][j];}
        }
        return t.Select(r=>r[n]).ToArray();
    }
    // Full-row-rank equality matrices only; the paper's general theorems are not limited to this enumerator.
    static ImmutableArray<ImmutableArray<Q>> Vertices(Q[][] a,Q[] p)
    {
        int m=a.Length,n=a[0].Length;
        if(Rref.Of(a,n).Pivots.Length!=m)throw new ArgumentException("independent equality rows required");
        var found=new Dictionary<string,ImmutableArray<Q>>();
        foreach(var basis in Combinations(n,m))
        {
            var x=Solve(a.Select(r=>basis.Select(j=>r[j]).ToArray()).ToArray(),p);
            if(x is null || x.Any(q=>q<Q.Zero))continue;
            var q=Z(n);for(int j=0;j<m;j++)q[basis[j]]=x[j];
            if(!Apply(a,q).SequenceEqual(p))throw new InvalidOperationException("bad vertex");
            found.TryAdd(string.Join(",",Text(q)),q.ToImmutableArray());
        }
        return found.Values.ToImmutableArray();
    }
    static (Q Lo,Q Hi) Range(IEnumerable<Q> values)
    {var v=values.ToArray();return(v.Min(),v.Max());}
    static Q[] Extremizer(ImmutableArray<ImmutableArray<Q>> vertices,Q[] c,bool upper)=>
        (upper?vertices.MaxBy(q=>Dot(c,q)):vertices.MinBy(q=>Dot(c,q))).ToArray();

    public static string VerifyBounds(CertificateContext expected,Q[][] a,Q[] p,Q[] c,BoundCertificate certificate)
    {
        if(certificate.Context!=expected)return "ContextMismatch";
        if(certificate.LowerDual.Length!=a.Length || certificate.UpperDual.Length!=a.Length ||
           certificate.LowerPrimal.Length!=c.Length || certificate.UpperPrimal.Length!=c.Length)
            return "DimensionFailure";
        bool Feasible(ImmutableArray<Q> q)=>q.All(x=>x>=Q.Zero) && q.Aggregate(Q.Zero,(x,y)=>x+y)==Q.One
            && Apply(a,q.ToArray()).SequenceEqual(p);
        if(!Feasible(certificate.LowerPrimal)||!Feasible(certificate.UpperPrimal))return "PrimalFailure";
        var low=TransposeApply(a,certificate.LowerDual.ToArray());
        var high=TransposeApply(a,certificate.UpperDual.ToArray());
        if(Enumerable.Range(0,c.Length).Any(i=>low[i]>c[i]||c[i]>high[i]))return "DualFailure";
        Q l=Dot(certificate.LowerDual,p),u=Dot(certificate.UpperDual,p);
        return Dot(c,certificate.LowerPrimal)==l && Dot(c,certificate.UpperPrimal)==u
            ?"SharpBounds":"OuterBounds";
    }

    // The first file is supplied by the trusted harness; only the second is a candidate certificate.
    public static void VerifyFiles(string fixturePath,string candidatePath)
    {
        try
        {
            using var f=JsonDocument.Parse(File.ReadAllText(fixturePath));
            using var b=JsonDocument.Parse(File.ReadAllText(candidatePath));
            Q ParseQ(string s)
            {var p=s.Split('/');if(p.Length>2||p.Any(string.IsNullOrWhiteSpace))throw new FormatException("integer or rational string required");
                return new(BigInteger.Parse(p[0],CultureInfo.InvariantCulture),
                p.Length==1?BigInteger.One:BigInteger.Parse(p[1],CultureInfo.InvariantCulture));}
            Q[] Row(JsonElement e)=>e.EnumerateArray().Select(x=>ParseQ(x.GetString()??"")).ToArray();
            CertificateContext Context(JsonElement e)=>new(e.GetProperty("graph").GetString()??"",
                e.GetProperty("latentClass").GetString()??"",e.GetProperty("data").GetString()??"",
                e.GetProperty("query").GetString()??"",e.GetProperty("decoder").GetString()??"",
                e.GetProperty("timeUnit").GetString()??"",e.GetProperty("scope").GetString()??"",
                e.GetProperty("schema").GetString()??"");
            var root=f.RootElement;var proposal=b.RootElement;
            var a=root.GetProperty("matrix").EnumerateArray().Select(Row).ToArray();
            var p=Row(root.GetProperty("p"));var c=Row(root.GetProperty("c"));
            if(a.Length==0||c.Length==0||p.Length!=a.Length||a.Any(row=>row.Length!=c.Length))
                throw new ArgumentException("invalid authoritative problem dimensions");
            var expected=Context(root.GetProperty("context"));
            var cert=new BoundCertificate(Context(proposal.GetProperty("context")),
                Row(proposal.GetProperty("lowerDual")).ToImmutableArray(),Row(proposal.GetProperty("upperDual")).ToImmutableArray(),
                Row(proposal.GetProperty("lowerPrimal")).ToImmutableArray(),Row(proposal.GetProperty("upperPrimal")).ToImmutableArray());
            string status=VerifyBounds(expected,a,p,c,cert);
            object result=status is "SharpBounds" or "OuterBounds"
                ?new {status,lower=Dot(cert.LowerDual,p).ToString(),upper=Dot(cert.UpperDual,p).ToString(),context=expected}
                :new {status,context=expected};
            Console.WriteLine(JsonSerializer.Serialize(result,new JsonSerializerOptions{PropertyNamingPolicy=JsonNamingPolicy.CamelCase}));
        }
        catch(Exception e) when(e is JsonException or FormatException or ArgumentException or InvalidOperationException or KeyNotFoundException or DivideByZeroException or IOException)
        {Console.WriteLine(JsonSerializer.Serialize(new {status="InputFailure",message=e.Message}));}
    }

    public static void Run(string dir)
    {
        // Type t = X + 2Y_0 + 4Y_1, with one common latent for the confounded pair.
        var a=Enumerable.Range(0,4).Select(v=>Enumerable.Range(0,8).Select(t=>{
            int x=t&1,y=(t>>(x+1))&1;return x+2*y==v?Q.One:Q.Zero;
        }).ToArray()).ToArray();
        Q[] p={Q.Of(3,10),Q.Of(1,5),Q.Of(1,10),Q.Of(2,5)};
        var c=Enumerable.Range(0,8).Select(t=>(Q)((t>>2)&1)).ToArray();
        var c0=Enumerable.Range(0,8).Select(t=>(Q)((t>>1)&1)).ToArray();
        var vertices=Vertices(a,p);
        var range=Range(vertices.Select(q=>Dot(c,q)));var range0=Range(vertices.Select(q=>Dot(c0,q)));
        Emit("response_vertices",vertices.Length,range.Lo,range.Hi,range0.Lo,range0.Hi);
        var qBase=Enumerable.Range(0,8).Select(t=>p[Array.FindIndex(a,row=>row[t]==Q.One)]/2).ToArray();
        var delta=Z(8);delta[4]=1;delta[0]=-1;Q eps=Q.Of(1,40);
        var qOther=qBase.Zip(delta,(x,y)=>x+eps*y).ToArray();
        var observationRow=a[2].Zip(a[3],(x,y)=>x+y).ToArray();
        var rr=Rref.Of(a,8);
        Emit("rowspace_witness",rr.Residual(observationRow).All(x=>x.IsZero),
            rr.Residual(c).All(x=>x.IsZero),Apply(a,qBase).SequenceEqual(Apply(a,qOther)),
            qOther.Min(),Abs(Dot(c,qOther)-Dot(c,qBase)));
        Q[] lower={0,0,0,1},upper={1,0,1,1};
        var qLo=Extremizer(vertices,c,false);var qHi=Extremizer(vertices,c,true);
        bool lowerOk=TransposeApply(a,lower).Zip(c,(x,y)=>x<=y).All(x=>x);
        bool upperOk=TransposeApply(a,upper).Zip(c,(x,y)=>x>=y).All(x=>x);
        Emit("dual_certificates",lowerOk,upperOk,Dot(c,qLo)==Dot(lower,p),Dot(c,qHi)==Dot(upper,p),
            Dot(lower,p),Dot(upper,p));

        var numerator=c.Select(x=>Q.Of(3,4)*x).ToArray();
        var denominator=c.Select(x=>Q.Of(1,4)+Q.Of(1,2)*x).ToArray();
        var selected=Range(vertices.Select(q=>Dot(numerator,q)/Dot(denominator,q)));
        var cc=a.Select((row,i)=>row.Append(-p[i]).ToArray()).Append(denominator.Append(Q.Zero).ToArray()).ToArray();
        Q[] rhs={0,0,0,0,1};var objective=numerator.Append(Q.Zero).ToArray();
        Q ccHi=ExactLp.Maximize(cc,rhs,objective)??throw new InvalidOperationException("infeasible CC");
        Q ccLo=-(ExactLp.Maximize(cc,rhs,objective.Select(x=>-x).ToArray())??throw new InvalidOperationException("infeasible CC"));
        Emit("conditional_cc",selected.Lo,selected.Hi,ccLo,ccHi,Vertices(cc,rhs).Length,
            vertices.Min(q=>Dot(denominator,q)));

        Q eta=Q.Of(1,100);
        var pLow=p.ToArray();pLow[0]+=eta;pLow[3]-=eta;
        var pHigh=p.ToArray();pHigh[0]+=eta;pHigh[1]-=eta;
        var slabLower=Extremizer(Vertices(a,pLow),c,false);
        var slabUpper=Extremizer(Vertices(a,pHigh),c,true);
        bool InSlabs(Q[] q)=>Apply(a,q).Zip(p,(x,y)=>Abs(x-y)<=eta).All(x=>x);
        Emit("interval_observations",p[3]-eta,Q.One-p[1]+eta,Dot(c,slabLower),Dot(c,slabUpper),
            InSlabs(slabLower)&&InSlabs(slabUpper));

        // A stochastic observation channel and a changed payoff exercise both residual terms.
        Q kappa=Q.Of(1,10);
        var ap=a.Select((row,i)=>Enumerable.Range(0,8).Select(j=>(1-kappa)*row[j]+kappa/4).ToArray()).ToArray();
        var pp=p.Select(x=>(1-kappa)*x+kappa/4).ToArray();
        var cp=c.Select(x=>(1-kappa)*x).ToArray();
        var da=ap.Zip(a,(r,s)=>r.Zip(s,(x,y)=>x-y).ToArray()).ToArray();
        var dc=cp.Zip(c,(x,y)=>x-y).ToArray();
        Q Rho(Q[] dual)=>Inf(dc.Zip(TransposeApply(da,dual),(x,y)=>x-y));
        Q rhoLo=Rho(lower),rhoHi=Rho(upper);
        Q safeLo=Dot(lower,pp)-rhoLo,safeHi=Dot(upper,pp)+rhoHi;
        var changed=Range(vertices.Select(q=>Dot(cp,q)));
        Emit("certificate_perturbation",rhoLo,rhoHi,safeLo,safeHi,changed.Lo,changed.Hi,
            range.Lo<=changed.Lo && changed.Hi<=range.Hi);

        Q[] p2={Q.Of(1,4),Q.Of(1,4),Q.Of(1,4),Q.Of(1,4)};
        var v2=Vertices(a,p2);var products=(from q in vertices from r in v2 select Dot(c,q)*Dot(c,r)).ToArray();
        var product=Range(products);var productSelected=Range(products.Select(f=>3*f/(1+2*f)));
        Emit("product_districts",products.Length,product.Lo,product.Hi,productSelected.Lo,productSelected.Hi);
        Q[] qs={Q.Of(1,4),Q.Of(3,4)};
        var u0=qs.Select(x=>x/2).ToArray();var u1=u0.Select(x=>x+Q.Of(1,8)).ToArray();
        Emit("decision_dominance",u0.Max()-u0.Min(),u1.Max()-u1.Min(),
            u1.Zip(u0,(x,y)=>x-y).Min(),Q.Of(1,8),Q.Zero);
        Q Contrast(Q x)=>x/(1+x)-x/2;
        Emit("ratio_contrast",Contrast(Q.Zero),Contrast(Q.One),Contrast(Q.Of(1,2)));
        Emit("ambiguity_radius",range.Lo,range.Hi,(range.Lo+range.Hi)/2,(range.Hi-range.Lo)/2);
        Q g1=Q.Of(2,5)-Q.Of(1,5)-Q.Of(1,10)-Q.Of(1,10);
        Q g2=Q.Of(9,10)-Q.Of(2,5)-Q.Of(1,20)-Q.Of(1,10);
        Emit("clock_decoder",g1,g1>Q.Zero,g2,g2>Q.Zero);
        // U fair, cue and outcome are independently flipped with probability 1/4.
        Q joint=Q.Of(1,2)*(Q.Of(3,4)*Q.Of(3,4)+Q.Of(1,4)*Q.Of(1,4));
        Emit("common_cause_seeing_do",joint/Q.Of(1,2),Q.Of(1,2),joint/Q.Of(1,2)-Q.Of(1,2));

        var context=new CertificateContext("g1","clique-response","p1","do-X1:Y1","d1","year","world","ADC-v3");
        var packet=new BoundCertificate(context,lower.ToImmutableArray(),upper.ToImmutableArray(),qLo.ToImmutableArray(),qHi.ToImmutableArray());
        var contexts=new[]{context with{Graph="g2"},context with{LatentClass="pairwise-only"},context with{Data="p2"},
            context with{Query="do-X0:Y1"},context with{Decoder="d2"},context with{TimeUnit="second"},
            context with{Scope="computation"},context with{Schema="other"}};
        var statuses=new List<object>{new {name="valid",status=VerifyBounds(context,a,p,c,packet)}};
        foreach(var (ctx,i) in contexts.Select((x,i)=>(x,i)))
            statuses.Add(new{name="context_"+i,status=VerifyBounds(ctx,a,p,c,packet)});
        var badDual=packet with{LowerDual=new Q[]{0,0,0,2}.ToImmutableArray()};
        var badPrimal=packet with{LowerPrimal=qLo.Select(x=>-x).ToImmutableArray()};
        var badDimension=packet with{LowerDual=ImmutableArray<Q>.Empty};
        string sd=VerifyBounds(context,a,p,c,badDual),sp=VerifyBounds(context,a,p,c,badPrimal),sz=VerifyBounds(context,a,p,c,badDimension);
        statuses.Add(new{name="bad_dual",status=sd});statuses.Add(new{name="bad_primal",status=sp});statuses.Add(new{name="bad_dimension",status=sz});
        Emit("typed_harness",VerifyBounds(context,a,p,c,packet)=="SharpBounds",
            contexts.Count(ctx=>VerifyBounds(ctx,a,p,c,packet)=="ContextMismatch"),
            sd=="DualFailure",sp=="PrimalFailure",sz=="DimensionFailure",statuses.Count);

        Q[][] boundary={new Q[]{1,1,1},new Q[]{1,1,0}};Q[] bp={1,0},bc={1,0,0};
        var bv=Vertices(boundary,bp);var br=Range(bv.Select(q=>Dot(bc,q)));
        Emit("boundary_rowspace",br.Lo,br.Hi,Rref.Of(boundary,3).Residual(bc).Any(x=>!x.IsZero));
        int rankA=Rref.Of(a,8).Pivots.Length;
        int rankBoth=Rref.Of(a.Concat(new[]{c0,c}).ToArray(),8).Pivots.Length;
        int rankContrast=Rref.Of(a.Append(c.Zip(c0,(x,y)=>x-y).ToArray()).ToArray(),8).Pivots.Length;
        Emit("causal_memory",rankA,rankBoth,rankBoth-rankA,rankContrast,rankContrast-rankA);
        int zeros=0,total=0;
        for(int w1=1;w1<=9;w1++)for(int w2=1;w2<=9;w2++)
        for(int w3=1;w3<=9;w3++)for(int w4=1;w4<=9;w4++)
        {total++;if((w1-w2)*(w3-w4)==0)zeros++;}
        Q miss=Q.Of(zeros,total),bound=Q.Of(2,9);
        Emit("witness_grid",total,zeros,miss,bound,miss*miss*miss,bound*bound*bound);

        var payload=new {
            typeOrder="t = X + 2 Y0 + 4 Y1",matrix=a.Select(Text).ToArray(),p=Text(p),c=Text(c),c0=Text(c0),
            vertices=vertices.Select(q=>Text(q)).ToArray(),baseQ=Text(qBase),otherQ=Text(qOther),delta=Text(delta),eps=eps.ToString(),
            lowerDual=Text(lower),upperDual=Text(upper),lowerPrimal=Text(qLo),upperPrimal=Text(qHi),
            numerator=Text(numerator),denominator=Text(denominator),
            ccMatrix=cc.Select(Text).ToArray(),ccRhs=Text(rhs),ccObjective=Text(objective),
            slab=new{eta=eta.ToString(),loPrimal=Text(slabLower),hiPrimal=Text(slabUpper)},
            perturbation=new{matrix=ap.Select(Text).ToArray(),p=Text(pp),c=Text(cp)},
            secondP=Text(p2),context,statuses
        };
        File.WriteAllText(Path.Combine(dir,"certificates.json"),JsonSerializer.Serialize(payload,
            new JsonSerializerOptions{PropertyNamingPolicy=JsonNamingPolicy.CamelCase,WriteIndented=true}));
    }
}
