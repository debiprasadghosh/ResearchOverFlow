"""Independent HiGHS, closed-form, semantic and clean-process checks of V4."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import hashlib,json,math,subprocess,sys,tempfile
import numpy as np
import scipy
from scipy.optimize import linprog

root=Path(__file__).resolve().parent
data=json.loads((root/'out_v4/sequential_results.json').read_text())
records=data['records'];checks=[]
def check(name,ok,detail=''):
    checks.append(dict(name=name,passed=bool(ok),detail=detail))
    assert ok,(name,detail)
def vf(x):return [F(y) for y in x]
def va(x):return np.array([[float(F(y)) for y in row] for row in x],dtype=float)
for case in data['lp_cases']:
    c=np.array([float(F(y)) for y in case['c']]);n=case['n']
    kwargs=dict(A_eq=va(case['equalities']),b_eq=np.array(list(map(float,vf(case['rhs'])))),
                A_ub=va(case['inequalities']),b_ub=np.array(list(map(float,vf(case['upper'])))),
                bounds=[(None,None)]*n,method='highs')
    low=linprog(c,**kwargs);high=linprog(-c,**kwargs)
    check('LP '+case['name'],low.success and high.success and abs(low.fun-float(F(case['lo'])))<1e-9 and abs(high.fun+float(F(case['hi'])))<1e-9)

eps=vf(data['epsilon_grid'])
check('closed form two-channel risk',vf(records['noisy_recovery'])==[min(2*x,F(1,2)) for x in eps])
check('closed form direct-channel risk',vf(records['direct_recovery'])==[min(x,F(1,2)) for x in eps])
check('synergy and experiment design',vf(records['experiment_width'])==[1,1,1,0] and vf(records['rank_synergy'])==[0,0,0,1])
check('actual report widths',vf(records['particular_reports'])==[F(2,3),F(2,3),0])
check('bow bounds from analytic interval',vf(records['nested_bow'])==vf(['2/5','4/5','11/20','13/20','29/50','31/50','3/5','3/5']))
old=records['old_endpoints'];check('old sharpness invalidation',old==[1,1,0,0])
regret=vf(records['monotone_regret']);check('analytic regret values',regret==vf(['3/10','1/10','3/20','0','3/25','0','1/10','0']))
check('regret monotonicity',all(regret[j+2]<=regret[j] for j in range(len(regret)-2)))
a=va(data['rank_matrices']['observational']);c0=va([data['rank_matrices']['c0']]);c1=va([data['rank_matrices']['c1']]);d=c1-c0
rank=lambda x:int(np.linalg.matrix_rank(x))
ar=rank(a);new=rank(np.vstack([a,d]));both=rank(np.vstack([a,c0,c1]))
check('independent memory ranks',vf(records['memory_release'])==[ar,both-ar,new,rank(np.vstack([a,d,c0,c1]))-new,rank(np.vstack([a,d,d]))-new])
check('ledger rejection categories',records['ledger_contracts']==['AcceptedRefinement','ContextMismatch','ContextMismatch','ParentMismatch','ParentMismatch','ConstraintMismatch','ConstraintMismatch','InconsistentEvidence'])
check('snapshot digests',vf(records['snapshot_digest'])==[1,1,1] and len(set(data['snapshot_digests']))==2)
spent,tail,delta=vf(records['confidence_budget'])
check('telescoping confidence budget',spent==delta*(1-F(1,1001)) and tail==delta/F(1001))
for n,r in data['radii'].items():
    n=int(n);rhs=float(delta)/(4*n*(n+1))
    check('Hoeffding allocation '+str(n),abs(2*math.exp(-2*n*r*r)-rhs)<=1e-12*rhs)
check('single-world record',vf(records['single_world_gap'])==[9,9,F(1,4),1,0])
for r in data['regime_tables']:
    x,y=r['x'],r['y']; expected=[F(0)]*4
    # The analytic law is independent uniformity of every non-clamped bit.
    xs=[0,1] if x is None else [x];ys=[0,1] if y is None else [y]
    for xx,yy in product(xs,ys):expected[xx+2*yy]=F(1,len(xs)*len(ys))
    check('regime '+str((x,y)),all(vf(z)==expected for z in r['laws']))
# Clean-process replay of the new exact module, with output directories disjoint.
with tempfile.TemporaryDirectory(prefix='adc_v4_replay_') as td:
    out=Path(td)/'out'
    result=subprocess.run([sys.executable,str(root/'sequential_reference.py'),str(out)],capture_output=True,check=True)
    check('clean process summary bytes',result.stdout==(root/'py_v4.txt').read_bytes())
    check('clean process result bytes',(out/'sequential_results.json').read_bytes()==(root/'out_v4/sequential_results.json').read_bytes())
    replay=dict(summary_sha256=hashlib.sha256(result.stdout).hexdigest(),
                result_sha256=hashlib.sha256((out/'sequential_results.json').read_bytes()).hexdigest())
manifest=json.loads((root/'inherited_manifest_v3.json').read_text())
inherited=['cs_results.txt','cs_v2.txt','cs_v3.txt']
for folder in ['output','out_v2','out_v3']:
    inherited.extend(str(p.relative_to(root)) for p in sorted((root/folder).iterdir()) if p.is_file())
for name in inherited:check('inherited hash '+name,hashlib.sha256((root/name).read_bytes()).hexdigest()==manifest[name])
result=dict(all_passed=all(c['passed'] for c in checks),record_count=data['record_count'],
            lp_cases=len(data['lp_cases']),highs_solves=2*len(data['lp_cases']),checks=checks,
            inherited_files_unchanged=len(inherited),inherited_suite_rerun_in_v4=False,
            replay=replay,runtime=dict(python=sys.version.split()[0],numpy=np.__version__,scipy=scipy.__version__))
(root/'validation_v4.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
