Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India

## Abstract

Autoregressive Do Calculus (ADC) is a finite discipline for connecting observational generators to declared causal queries. It combines mechanism sheaves, classical identification, clock certificates and dependency-preserving uncertainty calculations. This paper develops the mathematics of its response-function computations and connects it to functional neuroscience and agent harness design. For a positive observational law in a stated clique-response model, the response fibre is a product of district polytopes. Joint effects and conditional effects attain sharp extrema at product vertices. Every non-identified joint query in this class admits a witness pair differing in one district; coefficient cancellation explains missed base draws, and a polynomial identity argument bounds ideal independent retries. Primal and dual certificates allow bounds to be checked independently of the solver, including explicit residual allowances for changed coefficients and a linear-programming reduction for conditional targets. Fibre width determines an unavoidable scalar ambiguity radius. Shared-model utility comparisons can nevertheless certify an action, and a rank difference determines the extra coordinates needed by an exact linear causal memory. Behavioural intervention studies, hippocampal time and sequence accounts, and recent hippocampal--prefrontal inference findings motivate testable functional hypotheses; they do not establish a neural implementation of ADC. An executable C# interface checks separate authoritative problems and proposed bound packets, retaining graph, latent-class, data, query, decoder, unit and intervention-scope identities. Independent Python checks agree with all 46 C# summary records, and inherited result files reproduce byte for byte. The guarantees are relative to explicit model and decoder assumptions. Learned-agent performance and the biological mappings remain empirical questions.

**Keywords** autoregressive generation; do-calculus; response functions; partial identification; mechanism sheaves; neural sequences; causal memory; primal and dual certificates; agent harnesses

# 1 Introduction

An autoregressive generator can evaluate a chain of conditionals accurately and still answer an intervention incorrectly. Conditioning asks what follows among cases in which an event has a value. An intervention asks what follows when the mechanism producing that event is replaced. A hidden common cause can make the two laws different even when the observational distribution is known exactly.

ADC connects event generation to an established intervention calculus. Its input is a declared event model or graph, an observational law, a query, and any clock or precision constraints to be used. Its output is an identified expression with a derivation and an enclosure, or a qualified failure result. It does not discover causal arrows from the order of text, infer an exogenous law from local agreement, or treat a language-model token as a causal variable without a semantic map.

The horizontal structure supplies local mechanism contexts and shared variable identities. The autoregressive order supplies computational factors. A physical clock restricts possible ancestry. An interval describes admissible values rather than a probability of error. These objects interact through stated maps and hypotheses. Their distinction is the central design choice of ADC.

## 1.1 Literature survey

Pearl's calculus supplies the three graphical transformations of interventional probabilities (Pearl, 1995, 2009). Tian and Pearl (2002) identify district factors as products of observational conditionals in a topological order. Shpitser and Pearl give complete algorithms for joint and conditional interventional identification (2006a, 2006b). ADC uses those results with attribution. Its term calculus refers to a typed execution of them.

A categorical or sheaf reformulation is already part of the literature. Jacobs et al. (2019) distinguish string-diagram syntax from stochastic semantics and represent intervention by surgery. Fritz and Klingler (2023) establish a categorical d-separation criterion. Mahadevan's regime-indexed formulation applies chartwise causal rules and descends compatible equalities under explicit restriction and sheaf assumptions; the current revision makes no general identification-completeness claim for arbitrary sites (Mahadevan, 2025, revised 2026). These precedents preclude a claim that placing do-calculus beside sheaves is itself new.

Yvernes et al. (2026) characterize the equivalence of observational and interventional probability expressions through derivation graphs and give a procedure using at most four rule applications for that equivalence problem. Equivalence of such probability expressions and construction of an identification formula are distinct tasks. The latter also uses marginalization, products and conditioning. Section 4 supplies a finite example where an identified query has no rule-only route to an observational query with the same outcome.

The 2021 Gogioso--Pinzani paper cited in the proposal was withdrawn. Its withdrawal notice replaces its locale-of-inputs construction with spaces of input histories. We therefore use the later combinatorial and topological treatments as the relevant foundations for causal histories (Gogioso & Pinzani, 2022, 2023). The withdrawn paper is a historical reference, not a premise of any result below.

Ghosh (2026) separates mechanism relations, shared-circumstance counterfactuals, physical clocks, inference layers and interval dependencies. ADC extends that finite setting to general interventional identification. Credal networks supply sets of admissible probability specifications (Cozman, 2000), while temporal constraint networks supply exact date and lag projections (Dechter et al., 1991). Our ratio-extremum argument uses the convex-weight principle underlying linear fractional programming (Charnes & Cooper, 1962). The possibility that compatible probability marginals fail to extend is fundamental to sheaf approaches to contextuality (Abramsky & Brandenburger, 2011).

Partial identification already has an extensive computational foundation. Response-function methods give linear bounds in important cases (Balke & Pearl, 1997), and Duarte et al. (2024) formulate general discrete causal bounding as polynomial optimization. Our added analysis identifies a structured product of response fibres and supplies independently checkable certificates for its specified subproblems. It does not claim a new general theory of causal bounding.

Behavioural work distinguishes action from observation and studies temporal cues to causal learning (Blaisdell et al., 2006; Lagnado & Sloman, 2006). Hippocampal accounts distinguish experienced time, internally generated sequences and prospective paths (Buzsáki & Tingley, 2018; Eichenbaum, 2014; Pfeiffer & Foster, 2013). These motivate the functional hypotheses in Section 12. Their role is to constrain an interpretation, rather than prove the mathematical construction.

Causal language-model benchmarks and neural abstraction studies supply separate evaluation targets (Geiger et al., 2021; Jin et al., 2023, 2024). Agent work supplies a place for an executable causal tool (Yao et al., 2023; Yang et al., 2024). Section 13 distinguishes extraction, mathematical verification and transfer to the intended system of interest.

## 1.2 Contribution and status

The contribution is an execution discipline joining causal soundness, event-decoder validity, temporal certification and stated precision. Classical do-calculus, district factorization and ID/IDC completeness remain attributed results. The mechanism incidence sheaf records shared state variables; probability marginalization remains a generally weaker presheaf.

The response computations are developed into product-fibre structure, one-district witness existence, an ideal retry bound, primal and dual certificates, conditional bounding, robust regret and a task-dependent linear memory criterion. Each statement records its model class. In particular, the clique-common-latent class used for larger response districts is distinguished from the original pairwise-primitive setting.

The neuroscience connection is a set of functional hypotheses about acting, temporal decoding, sequence generation and retention. The harness connection has a small executable verifier and a proposed learned-agent evaluation. Neither supplies a new neural recording study or a trained-model performance result. Exact finite calculations check arithmetic and implementation contracts; biological and comparative performance claims retain their stated empirical status.

## 1.3 Structure

Sections 2 to 5 specify finite models, sheaves, query semantics and classical identification. Sections 6 to 8 develop clocks, event replacement and credal precision. Sections 9 and 10 report the inherited finite studies and their comparison outcomes. Section 11 proves the response-fibre and certificate results. Section 12 develops neuroscience hypotheses and a causal memory criterion. Section 13 specifies the harness and its new checks, and Section 14 concludes. Appendix A collects assumptions; Appendix B records the reference code and reproduction routes.

# 2 Finite models and typed queries

**Definition 2.1 (finite semi-Markovian event model).** Let $V = \{ V_{1},\ldots,V_{n}\}$ have finite state spaces. The directed part of $G$ is acyclic. A private exogenous variable may enter one mechanism, and a shared exogenous variable may enter the two endpoints of a bidirected edge. The exogenous primitives are mutually independent. A model $M$ fixes their laws and total functions

$$V_{i} = f_{i}\left( V_{pa(i)},U_{i} \right).\quad\quad(2.1)$$

The notation $U_{i}$ denotes all primitive exogenous inputs of that mechanism; the same primitive can occur in two such lists. A bidirected edge represents a possible hidden common cause, not mutual directed causation. Mechanisms may ignore inputs, so faithfulness is not assumed. A generation order $\pi$ is a permutation of the events. It is topological when every directed parent occurs earlier.

For $X \subseteq V$, a perfect intervention $do(X = x)$ replaces $f_{i}$ by the constant $x_{i}$ at its targets. Other mechanisms, variable meanings and exogenous laws are retained. In an ADMG, $G_{\bar{X}}$ removes incoming directed edges and bidirected edges incident to $X$. The graph $G_{\underline{Z}}$ removes outgoing directed edges from $Z$. Separation in an ADMG means m-separation, equivalently d-separation in its explicit latent-parent expansion.

**Lemma 2.2 (existence and coupling).** For a fixed exogenous assignment and intervention, a finite acyclic model has one endogenous solution. Two regimes retaining the exogenous primitives can be evaluated on the same assignment.

*Proof.* Visit nodes in topological order. A target is assigned its clamp; every other node has all parent values available and its total function supplies one value. Induction proves existence and uniqueness. Reusing the exogenous assignment supplies the stated coupling. ∎

**Definition 2.3 (query type).** A query is a disjoint triple $(Y,X,C)$ with a family of values $(y,x,c)$ and evaluation

$$q_{Y;X \mid C}^{M}(y;x,c) = P_{M}\left( Y = y \mid do(X = x),C = c \right).\quad\quad(2.2)$$

An action parameter and an observed condition occupy different fields. A query is observational when $X = \varnothing$. A conditional query also records the event whose probability normalizes it. Empty or uncertified normalizing mass is a domain failure, not a numerical value.

We assume a strictly positive observational joint law when using unrestricted tabular conditionals. This assumption has a useful finite consequence.

**Lemma 2.4 (support after a perfect intervention).** If $P_{M}(v) > 0$ for every observed joint assignment, then every assignment of the non-target events has positive probability under every perfect intervention.

*Proof.* Exogenous states that naturally generate $(X = x,V \smallsetminus X = v)$ still generate $v$ after clamping $X = x$, by Lemma 2.2. Their set is included in the intervened event. Therefore

$$P_{M}\left( v \mid do(x) \right) \geq P_{M}(v,x) > 0.\quad\quad(2.3)$$

Marginalization gives positive mass to every non-target conditioning assignment. ∎

A known positive law at one parameter value does not certify positivity throughout an uncertainty set. Section 8 separately requires positive denominators on the whole set being optimized.

# 3 Mechanism sheaves and law presheaves

## 3.1 A genuine horizontal sheaf

**Definition 3.1 (mechanism incidence sheaf).** For a fixed $M$, introduce a context point $c_{i}$ for each mechanism and a point for every endogenous or exogenous variable. Put $c_{i} \leq a$ when variable $a$ occurs in that complete mechanism scope. On the Alexandrov topology of upward closed sets, assign the relation

$$R_{i}^{M} = \{\left( v_{i},v_{pa(i)},u_{i} \right):v_{i} = f_{i}\left( v_{pa(i)},u_{i} \right)\}\quad\quad(3.1)$$

to $c_{i}$, the appropriate state space to each variable point, and coordinate projections to the incidence arrows. Sections are compatible tuples. This defines a sheaf of sets, denoted $\mathcal{S}_{M}$.

**Proposition 3.2 (state gluing).** Global sections of $\mathcal{S}_{M}$ are exactly the complete state assignments satisfying every mechanism. Replacing target relations gives the intervened solution sheaf.

*Proof.* Projection agreement identifies every entry of a context tuple with its shared variable value. Membership in $R_{i}^{M}$ is precisely its mechanism equation. Conversely, a solution fills each tuple and all its projections consistently. Gluing on open covers is componentwise union and is unique. Replacing a relation implements the clamp of Lemma 2.2. ∎

Stalks are data spaces. A token is an inference state, not a stalk. The probability law on exogenous states is additional model information. State gluing does not infer that law or a causal mechanism from an observational marginal.

## 3.2 Probability marginalization has weaker gluing

For a fixed action set $X$, define a presheaf on outcome subsets by

$$\mathcal{L}^{X}(A) = Ker\left( \mathcal{X}_{X},\Delta\left( \mathcal{X}_{A} \right) \right),\quad A \subseteq V \smallsetminus X,\quad\quad(3.2)$$

with pointwise marginalization as restriction. Here $\mathcal{X}_{A}$ is the product state space and $\Delta$ its probability simplex. A model supplies one compatible family of interventional marginals. Changing a conditioning set requires joint masses and normalization; it is not an outcome marginalization map.

**Proposition 3.3 (marginal laws need not form a sheaf).** Under covers by variable subsets, compatible probability marginals can have multiple joint extensions or no joint extension.

*Proof.* Uniform binary marginals for $A$ and $B$ extend both to independent fair bits and to $A = B$ with a fair common value. Thus uniqueness fails. For nonexistence, take uniform binary pair laws satisfying $A = B$, $B = C$ and $A \neq C$ on the three pair contexts. They agree on every singleton overlap, but the three relations cannot hold in one joint assignment. Hence no joint law realizes them all. ∎

ADC therefore keeps $\mathcal{S}_{M}$ and $\mathcal{L}^{X}$ separate. A conditional product or district factorization uses probabilistic assumptions in addition to overlap agreement. An unrestricted marginal presheaf cannot acquire a unique joint law merely by being called a sheaf.

## 3.3 Identification is a factorization on models

Let $\mathfrak{M}_{G}$ be the class of compatible models and let $obs(M) = P_{M}(V)$. This is a model space indexing the family $\mathcal{S}_{M}$; it is not the state-section space of one fixed $\mathcal{S}_{M}$.

**Theorem 3.4 (identification and observational fibres).** A query evaluation $q$ is identified on $\mathfrak{M}_{G}$ exactly when it is constant on each fibre of $obs$. Equivalently, there is a function $F$ on the attainable observational laws such that

$$q = F \circ obs.\quad\quad(3.3)$$

*Proof.* A factorization gives equal query values whenever the observational laws are equal. Conversely, define $F(p)$ to be $q(M)$ for any model with $obs(M) = p$. Constancy on the fibre makes this well defined. ∎

Two exact models with the same observational law and different target values refute such a factorization. This is a semantic witness. A graphical non-identification result and an explicitly supplied pair of models are different forms of certificate; an implementation should state which it carries.

## 3.4 Relation to ASE

ASE's latent cover base, variable context base, inference layer order and observation star remain distinct. The incidence space above models variable contexts. Physical time labels events; the generation order lists event variables; the evaluation order of a proof program lists arithmetic operations. None is the inference depth of ASE.

When a representation changes base, the old sheaf on the new base is $\Phi_{\ell}^{- 1}\mathcal{S}_{\ell}$, and a coefficient update must commute with restrictions. A token carries its vertical fibre diagram through such changes. ADC additionally requires any event decoder to preserve the meanings of clamps and observations. Units and coordinate meanings are declared before residuals or clock comparisons. Probability coordinates are dimensionless; clock constraints use one declared time unit.

# 4 Rules and certified derivations

## 4.1 The three inherited causal identities

Let $Y,X,Z,W$ be pairwise disjoint. Conditional equalities below are asserted on their defined support. The three rules retain their classical graph premises.

**Lemma 4.1 (observation insertion or deletion).** If $(Y\bot Z \mid X,W)_{G_{\bar{X}}}$, then

$$P\left( y \mid do(x),z,w \right) = P\left( y \mid do(x),w \right).\quad\quad(4.1)$$

*Proof.* The intervened model is Markov to its mutilated latent DAG. The separation premise gives conditional independence in that regime. Conditioning on fixed targets $X = x$ is redundant, yielding the equality. This is Pearl's first rule. ∎

**Lemma 4.2 (action and observation exchange).** If $(Y\bot Z \mid X,W)_{G_{\bar{X},\underline{Z}}}$, then

$$P\left( y \mid do(x,z),w \right) = P\left( y \mid do(x),z,w \right).\quad\quad(4.2)$$

*Proof.* Introduce independent regime indicators that select the ordinary mechanism or the clamp at $Z$. When $Z$ is conditioned on, an active path from an indicator must leave its target through an incoming arrow: otherwise that conditioned target is a blocking noncollider. Such paths are exactly the potential back-door connections tested after outgoing arrows from $Z$ are removed. The stated separation blocks them. Thus the conditional law of $Y$ given $X,Z,W$ is invariant between the observational and clamped regimes. In the latter, $Z = z$ is fixed, giving (4.2). This is the standard regime-indicator proof of Pearl's second rule. ∎

**Lemma 4.3 (action insertion or deletion).** Define $Z(W) = Z \smallsetminus {An}_{G_{\bar{X}}}(W)$. If $(Y\bot Z \mid X,W)_{G_{\bar{X},\overline{Z(W)}}}$, then

$$P\left( y \mid do(x,z),w \right) = P\left( y \mid do(x),w \right).\quad\quad(4.3)$$

*Proof.* Use the same regime indicators without conditioning on $Z$. For a target outside the ancestors of $W$, a collider at that target cannot be activated by $W$; incoming arrows there may therefore be removed in the separation test. Targets ancestral to $W$ retain their incoming arrows because selection through $W$ can matter. Any remaining active indicator-to-$Y$ path would yield an active path from a member of $Z$ to $Y$ in the displayed mutilated graph, by starting after the last removed incoming arrow if necessary. The premise excludes it. Invariance to the indicators proves the equality. This is Pearl's third rule, with its ancestor exception retained. ∎

These lemmas invoke classical causal soundness, not a new topos axiom. Their kernels and conditioning operations must be defined. Sheaf restriction does not erase their graph hypotheses.

## 4.2 A derivation needs probability algebra

**Definition 4.4 (ADC proof program).** An ADC program is a finite directed acyclic expression graph with typed kernels as values. Its leaves are observational laws or observational conditionals derived by certified normalization. Internal nodes perform a recorded application of Lemmas 4.1--4.3, marginalization, a justified conditional product, or division by a positive normalizing mass. A rule node carries its graph, mutilation, disjoint query sets and separation certificate. Bound variables and fixed action parameters are recorded explicitly.

A product node is justified by a chain rule, district factorization or another proved equality. It cannot turn unrelated marginals into a joint law. Reuse of a node preserves the identity of its parameters. A numerical interval relaxation may later forget that identity, but the proof program itself does not.

**Theorem 4.5 (program soundness).** If every leaf and node has its declared semantics and every graph and denominator premise holds, the program's output equals its stated causal query in every compatible model.

*Proof.* Induct over an evaluation order of the expression graph. Observational leaves have their declared values. Each causal rewrite preserves evaluation by Lemmas 4.1--4.3. Probability nodes preserve evaluation by their stated marginalization, product or conditioning identities. The output therefore equals the query. If all leaves are observational, its evaluation factors through $obs$ as in Theorem 3.4. ∎

**Proposition 4.6 (a rule-only graph is insufficient).** A query can be identified even though no path of the three causal rules alone reaches an observational query with that fixed outcome.

*Proof.* In the front-door graph $X \rightarrow Z \rightarrow Y$, $X \leftrightarrow Y$, start with $P\left( y \mid do(x) \right)$. Rule 2 cannot exchange $X$ because the bidirected path to $Y$ remains. Rule 1 cannot insert $Z$ because $Z \rightarrow Y$ remains active. Rule 3 cannot insert $Z$ for the same reason, or delete $X$ because its directed path to $Y$ remains. No initial rule-only move is licensed. Nevertheless the front-door expression

$$\sum_{z}^{}P(z \mid x)\sum_{x\prime}^{}P(y \mid x\prime,z)P(x\prime)\quad\quad(4.4)$$

identifies the query. The finite rule graph has 1 reachable query and no observational endpoint, while ID returns a valid expression. The sums and products in (4.4) supply operations absent from that graph. ∎

This corrects the proposed identification-as-a-path statement. A hypergraph of certified expressions or an expression DAG is sufficient syntax. The equivalence problem studied by Yvernes et al. (2026) can help choose equivalent starting queries, while ID or IDC performs identification.

# 5 Autoregressive factors and identification

## 5.1 District kernels

For a topological order, write $H_{i} = \{ V_{1},\ldots,V_{i - 1}\}$ and $p_{i} = P\left( v_{i} \mid h_{i} \right)$. A district is a connected component of the bidirected part of $G$.

**Theorem 5.1 (district factorization, Tian and Pearl).** For every district $D$,

$$Q\lbrack D\rbrack(v) = P_{V \smallsetminus D}\left( v_{D} \right) = \prod_{i:V_{i} \in D}^{}p_{i}\left( v_{i} \mid h_{i} \right).\quad\quad(5.1)$$

The joint law is the product of these district kernels: $P(v) = \prod_{D \in \mathcal{D}(G)}^{}Q\lbrack D\rbrack(v)$.

*Proof.* With external observed values held fixed, group the latent-variable factorization by districts. A shared exogenous primitive has both observed endpoints in one district, so the exogenous sums separate across those groups. Their product is $P(v)$. To recover a group's factors observationally, eliminate variables from the end of the topological order. At the final variable, summation normalizes its mechanism and its remaining district factor becomes the product of the corresponding factors in the preceding marginal. Dividing the full-prefix marginal by that preceding marginal gives $p_{i}$. Induction assigns each such conditional to its district and proves the first equality. This is the finite c-factor argument of Tian and Pearl (2002). ∎

An autoregressive model computes the $p_{i}$. Their causal use depends on the graph and order, rather than on the generator architecture. In recursive identification, the current kernel can already represent an intervention. Its prefix factors are then ratios of marginals of that current kernel. Reusing the original observational conditionals after changing the kernel is an incorrect shortcut.

## 5.2 Classical completeness and its scope

**Theorem 5.2 (inherited identification completeness).** In the nonparametric recursive semi-Markovian setting, ID identifies every identifiable joint interventional query. IDC supplies the corresponding complete conditional-query procedure. Their soundness and completeness are the classical results of Shpitser and Pearl (2006a, 2006b).

The reference implementation follows these algorithms. ID removes irrelevant ancestors, adds actions on irrelevant remaining variables, separates districts, extracts a district kernel or recurses within a larger district. Its failure record retains the active graph and district. IDC first tries Rule 2 to transfer conditioning variables to actions; otherwise it identifies the required joint and normalizes it.

Conditional identification is more general than identifying a joint and taking its ratio. For $X \rightarrow Z \rightarrow Y$ with $X \leftrightarrow Z$, the joint $P_{x}(z,y)$ is not generally identified, but

$$P_{x}(y \mid z) = P(y \mid z).\quad\quad(5.2)$$

Rule 2 moves $Z$ to an action, after which the mechanism of $Y$ is identified. The kernel and external oracle verify this example. Theorem 5.2 is invoked rather than reproved; ADC claims no enlargement of its identifiable-query class.

## 5.3 A carried non-identification witness

**Proposition 5.3 (a positive rational bow witness).** There are two binary models compatible with $X \rightarrow Y$, $X \leftrightarrow Y$, whose observational laws agree and are strictly positive, but whose intervention laws differ.

*Proof.* Let $U,N$ be independent fair bits and set $X = U$. In model A, put $Y = N$. In model B, put $Y = N$ when $X = U$, and $Y = X$ otherwise. Naturally $X = U$, so both observational laws assign $1/4$ to each $(x,y)$. Under $do(X = 1)$, model A has $P(Y = 1) = 1/2$. In B, half the exogenous states have $U = 1$ and retain fair $N$; the other half have $U = 0$ and produce $Y = 1$. Its probability is $3/4$. Under $do(X = 0)$ the corresponding probabilities are $1/2$ and $1/4$. Theorem 3.4 proves non-identification. ∎

A graph's arrows describe allowed inputs, so model A may ignore them. This construction uses no faithfulness assumption. The complete hedge theorem provides general graphical obstructions. The present kernel carries an ID failure trace for each failed query and an explicit model pair for this example; it does not claim to generate a rational witness pair for every possible hedge. Version 2 synthesises such pairs automatically for graphs whose districts are bidirected cliques (Section 10.1).

# 6 Clock certificates

## 6.1 No retroactive change to an earlier joint context

The clock is fixed across regimes. Clamping an event value does not reschedule events. Suppose each permitted causal edge $i \rightarrow j$ obeys $\tau_{j} - \tau_{i} \geq d_{ij} \geq 0$. Event dates and lag constraints are measured in a common unit. Exogenous common causes remain admissible; the hypothesis constrains directed ancestry.

**Theorem 6.1 (clocked prefix invariance).** Let $Y,X,C,A$ be disjoint. Suppose every event in $Y \cup C$ is strictly earlier than every event in $A$. In every model satisfying the clock hypothesis,

$$\begin{matrix}
P\left( y,c \mid do(x,a) \right) & = P\left( y,c \mid do(x) \right), \\
P\left( y \mid do(x,a),c \right) & = P\left( y \mid do(x),c \right).
\end{matrix}\quad\quad(6.1)$$

*Proof.* A directed path from $A$ to $Y \cup C$ would have nonnegative total lag and would make its endpoint no earlier than its starting point, contradicting the strict order. Thus no target in $A$ is an ancestor of $Y \cup C$. Couple the two regimes using the same exogenous assignment and the same clamps on $X$. Topological induction on ancestors of $Y \cup C$ gives identical values in both regimes. Their joint laws agree. Marginalize to $C$ and divide by its positive mass to obtain the conditional equality. ∎

The proof permits zero-lag edges. Positive minimum lags are stronger than necessary when the compared events are strictly ordered. Bidirected edges do not invalidate the argument: a perfect intervention leaves the common exogenous circumstances fixed.

**Proposition 6.2 (later conditioning can invalidate deletion).** Earlier outcomes alone do not justify deleting an action from a conditional query.

*Proof.* Let $Y,W$ be independent fair bits, and let $S = Y \oplus W \oplus N$, where $N$ is an independent Bernoulli bit with probability $1/4$. Give the events times $\tau_{Y} < \tau_{W} < \tau_{S}$. Then $P(Y = 1 \mid S = 1) = 1/2$, whereas $P\left( Y = 1 \mid do(W = 0),S = 1 \right) = 3/4$. The earlier marginal of $Y$ is invariant; selecting the later event $S$ changes the conditional question. ∎

If equal-time comparisons are admitted, zero-lag edges require care. A zero-lag edge $W \rightarrow Y$ can connect simultaneous events and a clamp can change $Y$. Strict query order in Theorem 6.1 avoids that case. With strictly positive directed lags, even a certified equality of times excludes directed ancestry between those events.

## 6.2 Finite date resolution

Write clock constraints as $\tau_{j} - \tau_{i} \leq c_{ij}$, with origin $\tau_{0} = 0$. Finite lower and upper dates connect every event to the origin. In a consistent network, shortest-path distances give exact attainable bounds (Dechter et al., 1991):

$$\tau_{v} \in \left\lbrack - d(v,0),d(0,v) \right\rbrack,\quad\quad\tau_{b} - \tau_{a} \geq - d(b,a).\quad\quad(6.2)$$

**Corollary 6.3 (certified action deletion).** If the clock network is consistent and $- d(a,b) > 0$ for every $b \in Y \cup C$, $a \in A$, then (6.1) holds for every compatible clock and every compatible causal model respecting nonnegative directed lags.

*Proof.* Equation (6.2) bounds $\tau_{a} - \tau_{b}$ from below by $- d(a,b)$. All required strict orders therefore hold throughout the feasible clock set. Apply Theorem 6.1 pointwise in that set. ∎

A negative cycle means the declared clock constraints are inconsistent. Failure to certify an order means that this clock argument is inconclusive; a graph-based rule can still justify deletion. For a fixed, complete causal graph, ancestry and do-calculus already decide the relevant causal premise. Clocks do not create a new class of identifiable effects. Their added role is a checkable order certificate, especially across a family of partially specified graphs that must all respect the same clock constraints.

Year and month reports are represented by closed hulls of their periods. This is a conservative convention for non-strict difference constraints and can leave endpoint distinctions undecided. Text order supplies no substitute for a missing clock certificate.

# 7 When event replacement is intervention

## 7.1 The whole prefix matters

Fix a positive observational law and a topological order, relabelled $V_{1},\ldots,V_{n}$. An event generator emits one token per declared event variable. Let $S = V_{s}$, $H = \{ V_{i}:i < s\}$ and $F = \{ V_{i}:i > s\}$. Replacing the event at position $s$ by $a$ and continuing with the observational conditionals produces

$${\widetilde{p}}_{a}(h,s,f) = p(h)\,\mathbf{1}_{\{ s = a\}}\, p(f \mid h,s = a).\quad\quad(7.1)$$

This law is defined by multiplying all non-clamped autoregressive factors. It is not, by definition, an interventional law.

**Theorem 7.1 (exact graphical exchange certificate).** In a topological order,

$$(F\bot S \mid H)_{G_{\underline{S}}}\quad \Leftrightarrow \quad{district}_{G}(S) \subseteq H \cup \{ S\}.\quad\quad(7.2)$$

Thus the entire continuation admits Rule 2 exchange precisely when the clamped event is the last member of its district in this order.

*Proof.* Suppose its district contains a future event. Choose a simple bidirected path from $S$ and stop at its first future vertex. Every internal vertex is earlier than $S$, hence belongs to $H$. Each is a collider on the path and is conditioned on. The path is m-active given $H$, so separation fails.

Conversely, suppose there is an m-active path from $S$ to some vertex in $F$ in $G_{\underline{S}}$. Stop at the first future vertex. All internal vertices belong to $H$ and must be colliders. The path cannot begin with $S \leftarrow h$: the earlier vertex $h$ would be a conditioned noncollider because that edge has a tail at $h$. Outgoing edges from $S$ have been removed, so the first edge is bidirected. At an earlier internal collider $h$, the next edge must have an arrowhead at $h$. It is either bidirected or $v \rightarrow h$. The latter would have an earlier $v$ by topological order, with a tail at $v$ on the path, making $v$ a conditioned noncollider. It is impossible on an active path. Induction makes every edge up to the first future vertex bidirected. That vertex belongs to the district of $S$, contradicting the right-hand condition. ∎

**Corollary 7.2 (certified event replacement).** Under the right-hand condition in (7.2), ${\widetilde{p}}_{a}$ equals $P_{M}\left( V \mid do(S = a) \right)$ in every compatible model with positive observational law.

*Proof.* Earlier events cannot descend from $S$ in a topological order, so their joint law is invariant under its clamp by the coupling of Lemma 2.2. Theorem 7.1 and Rule 2 give

$$P_{M}(f \mid h,S = a) = P_{M}\left( f \mid do(S = a),h \right).\quad\quad(7.3)$$

Multiply this conditional by the common prefix law $p(h)$ and the fixed target mass. The result is (7.1). ∎

The equivalence in Theorem 7.1 characterizes a graph test. Corollary 7.2 is a sufficient condition for equality of distributions. We do not assert that equality in a particular parameterized model requires that test: an allowed edge can be ignored, effects can cancel, or a projected outcome can agree while the full continuation does not.

## 7.2 Two distinct replacement failures

**Proposition 7.3 (order and district counterexamples).** A positive observational law does not make arbitrary generation order safe. Checking only direct hidden links from $S$ to the future is also insufficient.

*Proof.* First take $X$ fair and $Y = XxorN$ with independent $N \sim Bernoulli(1/4)$. The graph is $X \rightarrow Y$. Emit $Y$ before $X$ and force $X = 1$. The already emitted $Y$ remains fair, whereas $P\left( Y = 1 \mid do(X = 1) \right) = 3/4$. The total variation gap is $1/4$.

For the second claim, use order $(A,X,Y)$, no directed edges, and bidirected edges $A \leftrightarrow X$, $A \leftrightarrow Y$. Let all five primitive bits $U_{AX},U_{AY},N_{A},N_{X},N_{Y}$ be independent Bernoulli$(1/4)$ and put

$$\begin{matrix}
A & = U_{AX}xorU_{AY}xorN_{A}, \\
X & = U_{AX}xorN_{X},\quad\quad Y = U_{AY}xorN_{Y}.
\end{matrix}\quad\quad(7.4)$$

There is no direct $X \leftrightarrow Y$. However, conditioning on the full prefix $A$ opens the bidirected collider path. Exact enumeration gives a full-joint replacement gap of $3/64$ for $X = 1$. Both laws happen to have $P(Y = 1) = 3/8$. Equality of that one marginal therefore misses the continuation error. Every observational cell is positive because all private noises have both values in their support. ∎

![Front-door graph X to Z to Y with hidden X--Y confounding; and a graph with A bidirected to X and Y, whose conditioned A activates a collider path.](current_media/media/image1.png){width="6.45in" height="2.45in"}

Figure 1 Bidirected connectivity controls the prefix certificate

The example explains why "no hidden common cause with a later variable" is ambiguous. For continuation after an observed prefix, it is district connectivity that matters. A chain of hidden links through earlier conditioned events can be enough.

## 7.3 Approximate conditionals and structural error

Let $p_{i}\left( \cdot \mid h_{i} \right)$ be the true observational factors and ${\widehat{p}}_{i}$ their estimates. Use the same clamp in both generators. Suppose that, for every history that can occur before a non-clamped step,

$$TV\left( {\widehat{p}}_{i}\left( \cdot \mid h_{i} \right),p_{i}\left( \cdot \mid h_{i} \right) \right) \leq \delta_{i},\quad\quad 0 \leq \delta_{i} \leq 1.\quad\quad(7.5)$$

**Theorem 7.4 (two sources of causal error).** Let ${\widehat{p}}_{a}$ be estimated-factor replacement, ${\widetilde{p}}_{a}$ exact observational replacement and $p_{a}^{do}$ the true intervention. Set $\Delta = TV\left( {\widetilde{p}}_{a},p_{a}^{do} \right)$ and $\epsilon = 1 - \prod_{i \neq s}^{}\left( 1 - \delta_{i} \right)$. Then

$$\begin{matrix}
TV\left( {\widehat{p}}_{a},{\widetilde{p}}_{a} \right) & \leq \epsilon \leq \sum_{i \neq s}^{}\delta_{i}, \\
\max(0,\Delta - \epsilon) & \leq TV\left( {\widehat{p}}_{a},p_{a}^{do} \right) \leq \min(1,\Delta + \epsilon).
\end{matrix}\quad\quad(7.6)$$

*Proof.* Couple the two generators sequentially. When their histories agree, use a maximal coupling of their next conditional laws, agreeing with probability at least $1 - \delta_{i}$. The clamped values always agree. The probability that every non-clamped step agrees is at least the product in the definition of $\epsilon$. The coupling inequality proves the first bound, and the union bound gives the sum. The triangle inequality and its reverse give the second line. ∎

If observational conditional estimation is consistent so that $\epsilon \rightarrow 0$, the causal error of replacement converges to $\Delta$. This is its structural limiting error. It is not an unconditional error floor for every finite approximation: estimation errors can partially cancel structural error. Under Corollary 7.2, $\Delta = 0$, and (7.6) is a direct intervention guarantee.

For an identified expression with several divisions, a learned-model guarantee also needs denominator lower bounds. Accurate observational likelihood alone does not bound the conditioning ratios uniformly near zero. ADC therefore records a positivity certificate beside every normalization.

## 7.4 A decoder contract for latent generation

An ASE implementation may generate latent states rather than event values directly. Let its step kernels be $K_{i}\left( \cdot \mid z_{< i} \right)$ on finite latent spaces, with event decoders $d_{i}:\mathcal{Z}_{i} \rightarrow \mathcal{X}_{i}$. Write $d_{< i}$ for the componentwise prefix decoder.

**Proposition 7.5 (decoded event replacement).** Suppose that, at each non-clamped step and for every history reachable under the replacement procedure,

$$\left( d_{i} \right)_{\#}K_{i}\left( \cdot \mid z_{< i} \right) = p_{i}\left( \cdot \mid d_{< i}\left( z_{< i} \right) \right).\quad\quad(7.7)$$

At step $s$, replace the kernel by any kernel supported on $d_{s}^{- 1}\left( \{ a\} \right)$. The decoded joint law is then ${\widetilde{p}}_{a}$ of (7.1). Under Corollary 7.2 it is the true intervention. If the left and right sides of (7.7) differ by at most $\delta_{i}$ in total variation, the decoded laws obey Theorem 7.4.

*Proof.* Conditional on any decoded prefix, the latent prefixes form a mixture supported in its decoder fibre. Each component has the same next-event distribution by (7.7). Averaging retains $p_{i}$; the clamped step has decoded value $a$. Induction gives the product defining ${\widetilde{p}}_{a}$. In the approximate case, convexity of total variation bounds the mixture row by $\delta_{i}$, and sequential coupling gives (7.6). ∎

Equation (7.7) is a probabilistic commuting condition. Horizontal coordinate consistency alone does not imply it. In particular, choosing a latent vector or a word whose displayed value is $a$ does not certify the next-event kernels on its decoder fibre. This is the extra contract needed to connect an ASE representation to ADC's event semantics.

# 8 Credal precision and dependency preservation

## 8.1 Three different uncertainty sets

**Definition 8.1 (credal blocks).** Let $K = K_{1} \times \cdots \times K_{m}$, where each $K_{j}$ is a nonempty compact convex polytope of probability parameters. Entries within a block retain all simplex equalities and declared ties. Distinct blocks can vary independently. A scalar expression is separately affine when fixing all other blocks makes it an affine function of the remaining block.

Three operations must be distinguished. A graph-compatible credal set contains only laws attainable from the declared causal model class. A rectangular parameter relaxation may additionally contain laws violating graph constraints. Natural interval evaluation then performs another relaxation by allowing separate occurrences of the same numerical parameter to vary independently. The source of a wide answer cannot be diagnosed without saying which operation occurred.

**Theorem 8.2 (product vertex extrema).** A continuous separately affine expression on $K$ attains its minimum and maximum at product vertices.

*Proof.* Compactness gives a maximizing point. Fix every block except the first. An affine function on that first polytope has a maximizing vertex, so replace the first block without lowering the value. Repeat for every block. The resulting product vertex still maximizes the expression. Apply the same argument to its negative for the minimum. ∎

This is the standard finite multilinear principle used in credal optimization. A division-free expression is not automatically separately affine: reusing a Bernoulli parameter in $p(1 - p)$ creates degree two. On $\lbrack 0,1\rbrack$ its maximum $1/4$ is attained at $p = 1/2$, while both vertices give zero.

## 8.2 A ratio certificate

**Theorem 8.3 (separately linear fractional extrema).** Suppose $N$ and $D$ are separately affine on $K$ and $D > 0$ throughout $K$. The ratio $R = N/D$ attains both extrema at product vertices.

*Proof.* For one block write $\theta = \sum_{v}^{}\lambda_{v}v$ as a convex combination of its vertices, holding the others fixed. Affinity gives

$$R(\theta) = \sum_{v}^{}\frac{\lambda_{v}D(v)}{\sum_{w}^{}\lambda_{w}D(w)}\, R(v).\quad\quad(8.1)$$

The displayed coefficients are nonnegative and sum to one. Thus some vertex has ratio at least $R(\theta)$ and some has ratio at most it. Start from a global maximizer, which exists by compactness and denominator positivity, and move one block at a time to a maximizing vertex. Apply the same procedure to a minimizer. ∎

The denominator may depend on every block; it need not be constant. The required property is separate affinity of both parts after algebraic simplification, with the same declared blocks. Repeated syntax and nested ratios can obscure or destroy that property. For scalar boxes the kernel certifies it by expanding exact polynomials and checking that each variable has degree at most one. General simplex blocks require affinity in the entire block, not merely degree one in each entry.

Positive denominators alone do not suffice. The function

$$R(p) = \frac{p}{p^{2} + 1/4},\quad\quad p \in \lbrack 1/10,1\rbrack,\quad\quad(8.2)$$

has endpoint values $5/13$ and $4/5$ but reaches its maximum $1$ at $p = 1/2$. Its denominator is positive but quadratic in that block. Equation (8.2) marks the boundary of the ratio theorem rather than a failure of it.

## 8.3 An exact front-door calculation

For the binary front-door graph fix the action $X = 1$. Define independent scalar parameters

$$\begin{matrix}
p & = P(X = 1), & r & = P(Z = 1 \mid X = 1), \\
a_{u} & = P(Y = 1 \mid X = u,Z = 0), & b_{u} & = P(Y = 1 \mid X = u,Z = 1),\quad u \in \{ 0,1\}.
\end{matrix}\quad\quad(8.3)$$

The unused row $P(Z = 1 \mid X = 0)$ is fixed in $(0,1)$. Its value does not enter the target. The front-door effect is

$$F = (1 - r)\{(1 - p)a_{0} + pa_{1}\} + r\{(1 - p)b_{0} + pb_{1}\}.\quad\quad(8.4)$$

These observational parameters can range independently within positive intervals without violating this graph's observational model. To see this, let a hidden variable $U$ encode the natural value of $X$, set $X = U$, generate $Z$ from its two specified rows and generate $Y$ from the row indexed by $(U,Z)$. Independent finite noises realize every rational specification used here; a uniform noise realizes arbitrary real specifications. This constructs the required compatible models.

**Proposition 8.4 (sharp bounds with a selected outcome).** For positive boxes in the six parameters of (8.3), the exact bounds $F_{-},F_{+}$ are found by setting $a_{0},a_{1},b_{0},b_{1}$ all to their lower endpoints for the minimum and all to their upper endpoints for the maximum, checking the four corners of $(p,r)$ in each case. Add a child $S$ of $Y$, with independent positive rows $c = P(S = 1 \mid Y = 0)$ and $d = P(S = 1 \mid Y = 1)$. Then

$$\begin{matrix}
T & = P\left( Y = 1 \mid do(X = 1),S = 1 \right) = \frac{Fd}{Fd + (1 - F)c}, \\
T_{-} & = \frac{F_{-}d_{-}}{F_{-}d_{-} + \left( 1 - F_{-} \right)c_{+}}, \\
T_{+} & = \frac{F_{+}d_{+}}{F_{+}d_{+} + \left( 1 - F_{+} \right)c_{-}}.
\end{matrix}\quad\quad(8.5)$$

*Proof.* Equation (8.4) is separately affine and nondecreasing in each outcome-row parameter. Their endpoint choices are therefore simultaneous optimizers. The remaining bilinear function of $(p,r)$ reaches its extrema at their four corners. For (8.5), the numerator and denominator are separately affine in all eight parameters, and the denominator is at least $\min(c,d) > 0$. Theorem 8.3 applies. More specifically, differentiating the ratio shows it is nondecreasing in $F,d$ and nonincreasing in $c$. Its extrema are the displayed combinations, each attainable because the blocks are independent. ∎

This reduces a six-parameter search from $64$ corners to eight evaluations. The eight-parameter conditional expression has $256$ corners, but its two exact endpoints follow from those same bounds and two ratio evaluations. This is a specialized simplification, not a polynomial-time method for all identification formulas.

## 8.4 Graph compatibility precedes interval precision

**Proposition 8.5 (equivalent estimands can have different relaxed ranges).** Two observational expressions that identify the same query on a graph can have different exact ranges on a rectangular relaxation of the compatible laws.

*Proof.* Consider two independent binary events, so the causal graph has no edges. Fix $P(X = 1) = 1/2$, let $p_{0} = P(Y = 1 \mid X = 0) \in \lbrack 1/5,4/5\rbrack$ and $p_{1} = P(Y = 1 \mid X = 1) \in \lbrack 1/5,2/5\rbrack$. Graph compatibility imposes $p_{0} = p_{1}$. The two estimands $P(Y = 1)$ and $P(Y = 1 \mid X = 0)$ both equal the query $P\left( Y = 1 \mid do(X = x) \right)$ on compatible laws, and its compatible range is $\lbrack 1/5,2/5\rbrack$. On the unrestricted rectangle, their ranges are respectively

$$range\{\left( p_{0} + p_{1} \right)/2\} = \lbrack 1/5,3/5\rbrack,\quad range\{ p_{0}\} = \lbrack 1/5,4/5\rbrack.\quad\quad(8.6)$$

The difference is present before any occurrence-wise interval evaluation. ∎

Theorem 8.2 supplies an exact range for an expression on its declared product set. That set need not be the sharp causal uncertainty set. An answer should therefore name both its domain and its relaxation. In the front-door study the explicit construction above establishes compatibility, so this distinction introduces no hidden relaxation.

## 8.5 Occurrence counts do not order precision

**Proposition 8.6 (failure of a universal repeat-count ranking).** The number of occurrences of an uncertain parameter does not universally order the widths of natural interval evaluations of equal expressions.

*Proof.* On $p \in \lbrack 0,1\rbrack$, compare the polynomially equal forms

$$\begin{matrix}
E_{1} & = p(1 - p), \\
E_{2} & = \frac{1}{4} - \left( p - \frac{1}{2} \right)\left( p - \frac{1}{2} \right) + \frac{1}{100}(p - p).
\end{matrix}\quad\quad(8.7)$$

Natural interval arithmetic gives $E_{1} \in \lbrack 0,1\rbrack$. In the second form, $(p - 1/2)$ ranges over $\lbrack - 1/2,1/2\rbrack$, its occurrence-wise product over $\lbrack - 1/4,1/4\rbrack$, and the last term over $\lbrack - 1/100,1/100\rbrack$. Thus $E_{2} \in \lbrack - 1/100,51/100\rbrack$, with width $13/25 < 1$. The second form has four occurrences instead of two, yet a narrower interval. Their common exact range is $\lbrack 0,1/4\rbrack$. ∎

The counterexample refutes the unrestricted ranking. It does not preclude a useful heuristic on a prescribed normalized class. In the positive front-door expressions, three regroupings with different repetition patterns have exactly the same ideal interval bounds. Positive interval addition and multiplication distribute, so rearrangement alone provides no improvement there. Keeping $p$ and $1 - p$ tied, and retaining the shared parameter across mixtures, gives the improvement proved in Proposition 8.4.

Outward binary64 intervals add an arithmetic enclosure around the ideal interval calculation. The reference kernel uses exact rational-to-binary64 adjacent brackets and outward-rounded finite operations inherited from Ghosh (2026). A denominator crossing zero or an unsupported nonfinite result is rejected. Arithmetic enclosure, sharp optimization on a product set and sharp causal uncertainty remain three separate claims.

# 9 Exact finite checks and open comparisons

## 9.1 What was run

The C# implementation uses exact rational probabilities for the causal checks. Its public graph and kernel values are immutable; temporary arrays and lists are private scratch storage. A separate Python program recomputes the results using fractions, direct exogenous-state enumeration, its own set-based ID recursion and direct enumeration of m-active paths. Symbolic degrees are checked with SymPy. External y0 version 0.2.11 is used as an additional decision oracle for ID and the conditional example. It is not used to validate the numerical values of our formula expressions.

Table 1 Finite verification suite

  ------------------------------------------------------------------------------------------------------
  **Check**                        **Cases**   **Result**
  -------------------------------- ----------- ---------------------------------------------------------
  Joint ID decisions               449         438 identified; 11 failed; all external decisions agree

  Identified formula evaluations   65,632      Exact equality to mechanism replacement

  Prefix graph criterion           16,384      No discrepancy between separation and district tests

  Licensed rule bindings           1,372       10,976 exact value comparisons; all agree

  Interval clock narratives        128         1,552 of 1,920 pair orders certified; none false

  Credal effect boxes              40          All sharp bounds and outward enclosures pass

  Credal selected-outcome boxes    40          All 256-vertex ranges and sharp ratios agree

  Summary output agreement         21          Every C# line independently checked in Python
  ------------------------------------------------------------------------------------------------------

The five named models and twelve seeded random models have binary variables. Each random size from five through eight contributes three models. Directed edges respect the declared order and are independently proposed with probability $0.30$. Each graph has one to three bidirected edges. Private and shared noises have Bernoulli probabilities in $\{ 1/4,1/2,3/4\}$; each endogenous variable is the exclusive-or of its parents, incident shared noises and private noise. These choices ensure positivity and keep exact enumeration feasible. They are a finite test family, not a representative sample of all structural mechanisms.

Across the 449 joint queries, 438 were identified and 11 returned an ID failure. The identified expression values matched direct mechanism replacement on 65,632 global assignments, with zero mismatch. The C# current-kernel recursion and independent Python implementation agreed, as did all external joint decisions. The conditional-only example of Section 5 was also identified by both implementations and the oracle, although its required full joint was not identified. The explicit witness of Proposition 5.3 is independently checked; arbitrary witness-pair construction is not implemented.

Table 2 Named exact models with the action fixed at one

  -----------------------------------------------------------------------------------------
  **Model**          **ID**   **True do**   **Replacement**   **Full TV**   **Certified**
  ------------------ -------- ------------- ----------------- ------------- ---------------
  Back-door          Yes      5/8           5/8               0             Yes

  Front-door         Yes      9/16          1/2               1/8           No

  Bow                No       5/8           1/2               1/8           No

  Last in district   Yes      9/16          9/16              0             Yes

  Prefix collider    Yes      3/8           3/8               3/64          No
  -----------------------------------------------------------------------------------------

True do and replacement are the selected outcome probabilities at value one. Full TV compares the complete joint laws. Certified means the graph test of Theorem 7.1 holds. Graphs and parameter values are supplied in models.json.

The named front-door example is identified despite failing the clamp certificate. The indirect prefix-collider example preserves the selected $Y$ marginal while changing the joint. These results make it necessary to state whether an error concerns a target marginal or the whole generated continuation.

## 9.2 Exhaustive graph and rule checks

There are $2^{6}$ choices of ordered directed edges and $2^{6}$ choices of bidirected edges on four labelled vertices, giving $4,096$ ADMGs. At each of the four positions, the C# separation routine and the independent direct-path checker test (7.2). All 16,384 cases agree with the district criterion; 6,272 are certified and there are zero discrepancies.

For the causal rules, all $64$ ordered three-vertex ADMGs are tested. For each rule, choose distinct singleton outcome and transferred event; the third event is absent, an existing action or an observed condition. This gives $3,456$ rule-premise bindings in total. Rules 1, 2 and 3 license 222, 350 and 800 bindings respectively. Every licensed identity holds on all eight assignments in its positive rational test model: 10,976 exact comparisons in total. This is an implementation check supporting the inherited soundness, not a replacement for its general proof.

The rule-only front-door search visits just one query type and reaches no observational endpoint. ID succeeds. This independently confirms the syntax distinction in Proposition 4.6 without attributing a limitation to full do-calculus with probability algebra.

## 9.3 Clock resolution

The clock study has 128 narratives of six events, with strictly increasing hidden true dates. True increments are multiples of $1/48$ of an abstract year. Reports use either a whole-year closed hull or one of twelve equal month hulls; randomly supplied lower and upper lag constraints are chosen to include the truth. Narrative text order is independently shuffled. All 128 networks are consistent by construction.

Of 1,920 truly ordered pairs, the exact network certifies 1,552 (80.83%) with no false order. Mean event-window width changes from 0.7398 to 0.3663 abstract years. Text order reverses 993 pairs (51.72%). These are false chronological orders, not a measured rate of false causal answers. To turn such an order into an action-deletion error requires a query and an actual causal mechanism linking the events. The present study does not supply that semantic experiment.

## 9.4 Credal widths

The precision study uses 40 positive front-door boxes. Each active scalar parameter has a dyadic centre $k/16$, $k \in \{ 4,\ldots,11\}$, and radius $1/64$. The six-parameter effect is checked at all $64$ vertices. Adding the two selection rows gives $256$ vertices. Both the optimized endpoint formulas and the outward C# enclosures pass in every case.

Table 3 Ideal natural interval width divided by the exact compatible range

  --------------------------------------------------------------------------------------------------------
  **Target**          **Vertices**   **Median width ratio**   **Largest width ratio**   **Sharp checks**
  ------------------- -------------- ------------------------ ------------------------- ------------------
  Front-door effect   64             2.261                    3.015                     40/40

  Selected outcome    256            3.283                    6.103                     40/40
  --------------------------------------------------------------------------------------------------------

The medians compare ideal natural-interval widths with exact ranges on the same compatible boxes. They do not measure estimation variance. In these boxes the naive conditional intervals already lie inside $\lbrack 0,1\rbrack$, so probability clipping would leave these reported ratios unchanged. The three positive polynomial regroupings give identical ideal intervals in all 40 cases, although their syntax repeats the parameters differently.

![Every point lies above the equal-width line. Left: front-door effects. Right: selected-outcome ratios. Data are the exact rational intervals in precision.json.](current_media/media/image2.png){width="6.45in" height="2.8in"}

Figure 2 Exact and natural interval widths on all forty compatible boxes

The gain comes from preserving dependency constraints, including the simplex complement and the common mixing weights. There is no evidence here that selecting the expression with the fewest repeats improves precision. The separately affine degrees of the effect, the conditional numerator and the conditional denominator are all one in each scalar parameter, independently certified symbolically.

## 9.5 Status of the proposed comparisons

**C1 revised hypothesis on estimand choice.** The unrestricted claim that fewer repeated terms always narrow an interval is false by Proposition 8.6. On the positive front-door family, regrouping does not change the ideal enclosure. The proposal's predicted halving of excess width is therefore not established. A future heuristic must freeze a normalized expression class, admissible algebraic rewrites, parameter blocks and interval evaluator before testing any ranking. A structural certificate such as Theorem 8.3 takes precedence over a syntax score.

**C2 hypothesis on clock-aware causal answers.** The original pair-order study in Section 9.3 does not measure semantic causal errors. Section 10.4 performs that query-level test. Point dates give 950 invalid deletions among 38,400 queries (2.47%). This is below the predicted 5% and above the 1% contradiction threshold, so that part of the frozen comparison is inconclusive. Certified deletion retains 76.2% of deletions allowed by the true dates, with none invalid, meeting the retention prediction on this finite family. A chronological-order error and a failed causal equality remain distinct measurements.

**C3 conjecture on learned autoregressive models.** On a prespecified family of identified confounded queries, executing the identified expression from a trained generator's observational conditionals will have at most half the mean interventional total variation error of event replacement, at matched data, parameters and declared inference budget. Freeze the SCM distribution, graph access, train/test splits, estimator smoothing, denominator thresholds and query weights before training. Exclude a zero replacement-error baseline from the ratio test and report it separately. An uncertainty interval wholly above $0.5$ refutes the prediction; one crossing $0.5$ is inconclusive. No trained-model experiment is reported here. The exact replacement gap $\Delta$ is a limiting benchmark under observational consistency, as Theorem 7.4 specifies. Section 10.3 computes the exact limiting gap Δ for every position of every four-event ADMG in a fixed mechanism family.

## 9.6 Scope and limitations

The causal graph and event semantics are supplied. ADC does not identify them from prose, prove that a neural decoder preserves them, handle feedback or equilibrium interventions, or establish cross-world counterfactual identification. Its finite semi-Markovian model is narrower than an arbitrary sheaf or topos. The sheaf supplies shared variable consistency, while causal completeness comes from ID and IDC.

A failure trace and a synthesized pair of models are different certificates. Section 10.1 constructs pairs on the stated clique-response class, and Section 11 explains its one-district search. A credal range remains conditional on its uncertainty set. Multiple-district vertex enumeration can be exponential, and differences of conditional targets need not retain the vertex property. General latent structures and learned event-decoder validity require additional work.

Finally, the mechanism incidence sheaf has deliberately modest computational responsibilities. Removing its terminology leaves the probability and graph results meaningful. Its value within ASE is to keep mechanism scopes, shared coordinates and intervention replacements explicit when these calculations are embedded in a layered representation. That value must ultimately be tested by a decoder and task, rather than inferred from the name of the construction.

# 10 Exact response computations

The following four exact studies extend the base suite. Each turns a statement or stated computational limit into a reproducible calculation. The separate execution mode retains the original 21 summary records and is independently validated. Appendix B records the implementation and replay routes.

## 10.1 Exact non-identification witnesses

Theorem 3.4 makes a pair of models with equal observational laws and different query values a complete semantic certificate of non-identification. Section 5.3 supplied one such pair by hand. Response functions make the construction mechanical for a broad class (Balke & Pearl, 1997).

**Proposition 10.1 (witnesses from one district).** Let every district of $G$ be a bidirected clique, and let each district $D$ carry one latent variable whose values are the joint deterministic response types of its binary members, with law $q_{D}$. Fix the laws of the other districts. For each $v$ and $t$, write $a_{vt} = 1$ when type $t$ reproduces $v_{D}$ from $v$, and $c_{t}$ for the coefficient of $q_{D}(t)$ in the query value. If $\sum_{t}^{}a_{vt}\delta_{t} = 0$ for every $v$ and $c \cdot \delta \neq 0$, then $q_{D}$ and $q_{D} + \varepsilon\delta$, with $0 < \varepsilon < \min_{t}q_{D}(t)/\max_{t}\left| \delta_{t} \right|$, define two positive models with equal observational laws whose query values differ by $\varepsilon|c \cdot \delta|$.

*Proof.* By the factorisation of Theorem 5.1, each observational cell is the product of the other districts' fixed factors and $\sum_{t}^{}a_{vt}q_{D}(t)$. The fixed factors are positive and do not depend on $q_{D}$, so the perturbation leaves every cell unchanged. The query value is likewise linear in $q_{D}$ with coefficients $c_{t}$, and changes by $\varepsilon\, c \cdot \delta$. The bound on $\varepsilon$ keeps every type probability positive. Theorem 3.4 then proves non-identification. ∎

Summing the response-consistency rows over district assignments at fixed external parent values gives the normalization row. Thus a perturbation annihilating every such row also has total mass zero, as required for both probability laws.

For a two-member district the latent is the shared primitive of Definition 2.1. For a larger clique it is a common latent of the whole district, the usual latent-projection reading of a bidirected clique, and the class is broader than Definition 2.1's pairwise primitives. A witness proves non-identification in the class it belongs to. The kernel finds $\delta$ by exact rational row reduction of the matrix $\left( a_{vt} \right)$, testing each query cell against its row space. The other districts' laws are random positive rationals. If a draw happens to make all query rows dependent, the kernel retries with up to two further draws.

The study covers every graph on three and four ordered events whose districts are cliques and whose members have at most two parents, so that each member has at most 16 response types. That gives 40 and 840 graphs, and every nonempty disjoint action and outcome set, 42,480 joint queries in all (Table 4).

Table 4 Exact witness synthesis on clique-district graphs

  -----------------------------------------------------------------------------------------------------------------------------
  **Events**   **Graphs**   **Queries**   **Identified**   **Failures**   **Witnesses**   **False witnesses**   **Max types**
  ------------ ------------ ------------- ---------------- -------------- --------------- --------------------- ---------------
  3            40           480           409              71             71              0                     128

  4            840          42,000        34,989           7,011          7,011           0                     2,048
  -----------------------------------------------------------------------------------------------------------------------------

Every ID failure received an exact witness pair, and no identified query did. Of the witnesses, 7 needed a second random draw of the other districts. The witness district had two members in 3,094 pairs, three in 2,791 and four in 1,197. In 3,094 pairs every district of the graph has at most two members, so both models lie in the pairwise class of Definition 2.1. The smallest certified difference between the two query values was 1/130676.

The Python validator decodes the response types independently and checks each certificate exactly: the perturbation annihilates every observational cell, changes the query by the reported amount, and keeps the second model positive. For 351 pairs it also enumerates both complete models and compares their observational and interventional laws directly. Its own ID recursion agrees on all 42,480 decisions, and y0 agrees on all 2,484 queries it completed in a sample. A further 126 sampled queries stopped with an internal y0 error on graphs that contain a vertex without directed edges; they are excluded and reported, not counted as agreement.

Every failure in this finite census received a verified witness. Theorem 11.4 proves that a one-district witness exists for a non-identified joint query in this clique-response class. A fixed draw can make its direction coefficient vanish through cancellation. The finite retry routine is therefore distinguished from a general deterministic completeness guarantee; Section 11.3 gives its ideal random-sampling analysis.

## 10.2 Sharp bounds on observational fibres

Theorem 3.4 says a query is identified exactly when it is constant on each observational fibre. When it is not, the range of the query over a fibre is the sharpest statement the observational law supports. For one confounded district that range is a linear programme.

**Proposition 10.2 (fibre range with one confounded district).** Suppose exactly one district $D$ of $G$ has more than one member, $D$ is a clique, and the model class is that of Proposition 10.1. For a positive observational law $p$ of that class, the set of values of $P\left( Y = y \mid do(X = x) \right)$ over the fibre of $p$ is the interval between the minimum and maximum of $c \cdot q$ subject to $Aq = p$ and $q \geq 0$. Here $A$ and $c$ are determined by $p$ and $G$ alone.

*Proof.* By Theorem 5.1, $p$ is the product of $Q\lbrack D\rbrack$ and the singleton factors $Q\left\lbrack \{ i\} \right\rbrack$, all of which are identified. A singleton factor is unchanged by an intervention on other events and equals one at a target. The query is therefore a sum over assignments of identified singleton factors times $\sum_{t}^{}q_{D}(t)$ over types reproducing $v_{D}$ under the action, which is linear in $q_{D}$ with coefficients fixed by $p$. A law $q_{D}$ lies in the fibre exactly when it reproduces $Q\lbrack D\rbrack$, which after multiplying by the positive singleton factors is $Aq = p$. Any feasible $q_{D}$, combined with singleton response laws that reproduce their factors, is a model in the fibre. ∎

The kernel solves these programmes exactly over the rationals with a two-phase simplex method under Bland's rule (Bland, 1977). The study takes the bow and all 32 three-event graphs with exactly one confounded clique district, draws one random positive response model for each, and bounds $P\left( Y = 1 \mid do(X = x) \right)$ for every ordered pair of events and both action values. That gives 388 queries and 776 programmes.

All 332 identified queries gave zero width, and each bound equalled the value returned by ID. All 56 non-identified queries gave positive width; the smallest was 40/1953 and the mean 0.469. Every interval contained the generating model's value and lay inside the natural bounds $\left\lbrack P(x,y),\, P(x,y) + 1 - P(x) \right\rbrack$ (Manski, 1990). For the bow, the exact programme returned $\lbrack 7/37,\, 24/37\rbrack$, which equals the natural bounds, as expected for a single confounded pair. For the instrument graph $Z \rightarrow X \rightarrow Y$ with $X \leftrightarrow Y$, it returned $\lbrack 3/20,\, 51/80\rbrack$ against natural bounds $\lbrack 47/360,\, 247/360\rbrack$, the tightening that instrument inequalities provide (Balke & Pearl, 1997). Among the non-identified queries, 50 met the natural bounds exactly and 6 were strictly tighter (Figure 3a). The validator re-solves every programme with HiGHS in floating point and agrees within $10^{- 8}$.

A width of zero on one observational law does not prove identification, because the decision quantifies over all laws. The study uses the converse: an identified query must give zero width on every law, and a positive width on any law is a semantic non-identification witness.

## 10.3 A census of event-replacement gaps

Corollary 7.2 makes event replacement exact when the clamped event is last in its district. Section 7.2 showed two ways it fails. The census asks how often replacement errs when the certificate fails, in a fixed mechanism family.

It covers all 4,096 four-event ADMGs and all four positions, 16,384 cases. Each event is the exclusive-or of its parents, incident latent bits and a private bit. Private and latent bits have probability $1/4$ or $3/4$, drawn per graph; the fair value $1/2$ is excluded because it makes an event independent of its parents. Replacement uses the exact observational conditionals in the topological order, and the truth is computed by mechanism replacement.

The certificate held in 6,272 cases, and every one had zero total-variation gap. It failed in 10,112 cases, and every one had a positive gap: the median was 3/80, the largest 1/8 and the mean 0.0430. Among the failures, 3,280 had an identified joint intervention law. In all 9,552 identified cases, executing the ID expression reproduced the true interventional joint exactly, while replacement erred in each of those 3,280 uncertified cases (Figure 3b).

![Left: exact linear-programme bounds for the 56 non-identified queries against the natural bounds, with the generating model\'s value. Right: total-variation gaps of event replacement in the uncertified cases, split by whether the joint intervention law is identified.](current_media/media/image3.png){width="6.45in" height="3.0867858705161857in"}

Figure 3 Sharp fibre bounds and event-replacement gaps

In this family the certificate is not only sufficient but also sharp. No uncertified case escaped error through cancellation. This does not contradict the remark after Corollary 7.2: the exclusive-or mechanisms with non-fair noise are generic enough to transmit every open path, and ignored inputs or cancelling parameters can still produce exact replacement outside this family. For conjecture C3 the census fixes the floor that token replacement cannot beat even with perfect conditionals. In 32.4% of the uncertified cases the identified formula meets the truth exactly where replacement does not.

## 10.4 A semantic test of clock-licensed deletion

Section 9.5 states what a valid test of C2 must fix: the event and graph family, the deletion queries and the treatment of ties. The proposal's thresholds were frozen before this run. Forbidden deletions were predicted in at least 5% of queries, with contradiction below 1%. Certified deletion was predicted to keep at least half of the deletions that the true dates allow, with contradiction below a quarter. The protocol below was written into the kernel before its single run and was not tuned afterwards.

The test uses 256 narratives of six events. True dates increase in steps of $k/48$ year with $k \in \{ 1,\ldots,38\}$, so the generation order is topological. Each forward pair is a directed edge with probability $0.3$, with one to three bidirected edges. Mechanisms are exclusive-or with non-fair noise, as in Section 10.3. Every directed edge carries a true minimum lag rounded down to a quarter year, and with probability one half a maximum lag half a year above it. Other pairs carry such lag constraints with probability $0.3$. Dates are reported to the year with probability $0.7$ and otherwise to the month, and text order is shuffled.

A query deletes action $A$ from $P\left( y,c \mid do(a) \right)$, for outcome $Y$, action $A$ and an optional condition $C$. The point-date extractor deletes when $Y$ and $C$ precede $A$ by the start of their reported periods, with equal starts broken by text order. Certified deletion uses Corollary 6.3. A deletion is invalid when the joint law of $(Y,C)$ under either value of the action differs from its observational law, checked exactly.

Table 5 Frozen semantic test of clock-licensed action deletion

  ---------------------------------------------------------------------------------------------------------
  **Quantity**                                 **Count**   **Share**
  -------------------------------------------- ----------- ------------------------------------------------
  Queries                                      38,400      100%

  Point-date deletions                         14,080      36.7% of queries

  Invalid point-date deletions                 950         2.47% of queries; 6.7% of point-date deletions

  Point-date deletions decided by text order   3,123       20.7% of them invalid (645)

  Deletions allowed by the true dates          14,080      0 invalid

  Certified deletions                          10,733      76.2% of those the true dates allow; 0 invalid
  ---------------------------------------------------------------------------------------------------------

Certified deletion produced no invalid deletion and kept 76.2% of the deletions the true dates allow, so the second part of C2 holds with margin. Point dates produced invalid deletions in 2.47% of queries. That falls short of the predicted 5% but stays above the 1% contradiction threshold, so by the frozen rule the first part is neither confirmed nor refuted.

The source of the errors is instructive. Of the 950 invalid deletions, 645 came from ties broken by text order. The remaining 305 came from strict comparisons between the starts of periods of different lengths. A year-dated event starts on 1 January even when it occurred in November, so it can appear to precede a month-dated event that it actually follows. A period start is therefore not order-preserving once resolutions are mixed. Interval dates avoid both failures by construction.

## 10.5 What the extended studies establish

The four studies are exact computations on declared finite families. They show that the witness search, the fibre programmes and the replacement certificate behave as the propositions require on every case examined, and they record where the stated predictions held or fell short. They do not extend identification beyond ID and IDC, prove completeness of the witness search for arbitrary graphs, or measure a trained generator. Conjecture C3 still requires the learned-model experiment of Section 9.5.

# 11 Mathematics of response fibres and certificates

The added computation separates three questions. Can two compatible models disagree? What range of answers remains possible? Can a proposed bound be checked without trusting the program that found it? This section develops the finite mathematics behind those questions. Response-function optimization and polynomial causal bounding have classical and recent precedents (Balke & Pearl, 1997; Duarte et al., 2024). The results below specialize those tools to ADC's declared district model and its execution interface.

## 11.1 Linear information within a response block

**Definition 11.1 (normalized response fibre).** Let a finite vector $q$ give probabilities of deterministic response types. Include normalization in an equality system $Aq = b$, and define

$$K(b) = \{ q:Aq = b,\ q \geq 0\},\quad\quad\mathbf{1}^{\mathsf{T}}q = 1.\quad\quad(11.1)$$

Normalization must be explicit or certified as implied by the equality rows. In Proposition 10.2, $A$, $b$ and the target coefficient vector $c$ are fixed after the observational law and the other identified factors have been supplied. They must be reconstructed if that input law changes. The query value is $c^{\mathsf{T}}q$.

**Lemma 11.2 (row space and an interior fibre).** Suppose $K(b)$ contains a vector $q^{\circ}$ with every coordinate positive. Then $c^{\mathsf{T}}q$ is constant on $K(b)$ if and only if $c$ belongs to the row space of $A$.

*Proof.* If $c = A^{\mathsf{T}}\lambda$, then $c^{\mathsf{T}}q = \lambda^{\mathsf{T}}b$ throughout the fibre. Conversely, if $c$ is outside that row space, orthogonality of row space and nullspace gives $\delta \in \ker A$ with $c^{\mathsf{T}}\delta \neq 0$. The normalization row gives $\mathbf{1}^{\mathsf{T}}\delta = 0$. For sufficiently small positive $\epsilon$, both $q^{\circ} + \epsilon\delta$ and $q^{\circ} - \epsilon\delta$ are positive and feasible. Their target values differ. ∎

For rational matrices, elimination supplies a rational nullspace basis and rational witnesses. Positivity is essential to the converse. The system $q_{1} + q_{2} + q_{3} = 1$, $q_{1} + q_{2} = 0$, $q \geq 0$ has only $(0,0,1)$, so $q_{1}$ is constant even though $(1,0,0)$ is outside the two-row space. A boundary fibre requires its forced-zero support to be removed or its range to be computed directly. Zero width on one fibre still does not prove identification over a whole graph class.

## 11.2 More than one confounded district

Use the model class of Proposition 10.1: each bidirected district is a clique, one unrestricted latent response type is shared within each district, and different districts have independent latent variables. This class is denoted $\mathfrak{M}_{cl}$. It retains the larger-clique scope already stated in Section 10. District factorization continues to hold because all children of each shared latent remain in one district. The original pairwise-primitive class of Definition 2.1 is separately labelled.

For a positive compatible observational law $p$, district factorization identifies $Q_{p}\lbrack D\rbrack(v)$. Let $A_{D}$ be the response-consistency matrix whose row at $v$ indicates which district types reproduce $v_{D}$ from the declared parent values. Define the compact polytope

$$K_{D}(p) = \{ q_{D} \geq 0:A_{D}q_{D} = Q_{p}\lbrack D\rbrack,\ \mathbf{1}^{\mathsf{T}}q_{D} = 1\}.\quad\quad(11.2)$$

**Theorem 11.3 (product structure of a response fibre).** In $\mathfrak{M}_{cl}$, the response-parameter fibre of a positive attainable law $p$ is

$${obs}^{- 1}(p) = \prod_{D \in \mathcal{D}(G)}^{}K_{D}(p).\quad\quad(11.3)$$

Every joint interventional cell is separately affine on this product. Every conditional interventional cell has a separately affine numerator and denominator; its denominator is positive throughout the fibre. Consequently both kinds of cell attain their sharp extrema at product vertices.

*Proof.* A model with observational law $p$ must reproduce each identified district kernel, so its blocks lie in the right-hand set. Conversely, choose one feasible block from every $K_{D}(p)$ and take independent district latents with those laws. Their observational factors multiply to $p$, proving the reverse inclusion.

Under an action, a district contributes the sum of $q_{D}(t)$ over types consistent with its non-target equations. Summing products of these district contributions over non-target assignments gives a joint interventional cell. Each block enters each product at most once, proving separate affinity. A conditional cell is the ratio of the corresponding outcome-and-condition joint mass to the condition mass. Both are separately affine. For the fixed action $X = x$ and condition $C = c$, Lemma 2.4 gives the uniform bound $P_{x}(c) \geq p(x,c) > 0$. Theorems 8.2 and 8.3 therefore apply. Every vertex choice is a feasible model, so the bounds are sharp. ∎

The statement concerns response parameters; different parameter vectors may encode equivalent mechanisms. It includes singleton districts, whose response laws can differ in cross-input couplings even when their single-world kernels agree. The theorem does not identify those cross-world couplings.

This extends the one-confounded-district computation of Section 10.2 mathematically. It does not make multiple-district bounding one linear programme: the objective couples independent blocks multiplicatively. Allowing one arbitrary joint latent law across all blocks would change the model class and generally relax the bounds. Enumeration of all products of vertices can be expensive.

## 11.3 Why one district can supply a witness

**Theorem 11.4 (single-district witness existence).** If a joint interventional query is not identified on the positive observational laws of $\mathfrak{M}_{cl}$, there is a witness pair whose models differ in one district response law only. Such a pair can be chosen with positive rational response laws.

*Proof.* Non-identification supplies two response models in one positive observational fibre whose query values differ. By Theorem 11.3 that fibre is a product. Change the first model into the second one block at a time. At least one adjacent pair changes the query. Their block difference lies in $\ker A_{D}$. Expanding that difference in a rational nullspace basis shows that some basis direction has nonzero query coefficient at the fixed other blocks.

With the other blocks variable, this coefficient is a polynomial divided by the positive normalizing sums used to parameterize their probability vectors. Its numerator is not identically zero because it is nonzero at the adjacent pair. Nonzero polynomials cannot vanish on the entire open set of positive weights. Choose positive rational weights in that open set, a positive rational base law for $D$, and a sufficiently small rational step in the selected null direction. The response-consistency equations and normalization are unchanged, while the query changes. Full support of the response laws makes every observational cell positive. ∎

This corrects the earlier suggestion that a witness might intrinsically require simultaneous changes in two districts. One-block changes suffice somewhere. At a particular base draw, however, the relevant coefficient can vanish, so a search using that draw can miss a witness. The constructed pair need not reproduce a separately supplied observational dataset: this theorem concerns global identification on the graph class. Bounding the fibre of a particular dataset still requires (11.2).

**Corollary 11.5 (a finite-grid retry bound).** Suppose there are $m$ districts. In each trial, generate each response probability vector by normalizing independent integer weights uniformly drawn from $\{ 1,\ldots,B\}$. Test every district nullspace direction and query cell. For a non-identified joint query, the miss probability in one trial is at most

$$\begin{matrix}
\text{one trial: } & \min\{ 1,(m - 1)/B\}, \\
\text{independent }r\text{ trials: } & \min\{ 1,(m - 1)/B\}^{\, r}.
\end{matrix}\quad\quad(11.4)$$

*Proof.* Select the nonzero direction coefficient from Theorem 11.4. Multiply by the normalizing sum of every other district. Each other weight block enters at most once, so the resulting nonzero polynomial has total degree at most $m - 1$. A nonzero degree-$d$ polynomial vanishes on at most a $d/B$ fraction of a uniform product grid. To see this, induct on the number of variables: if its degree in the last variable is $k$, the leading coefficient has degree at most $d - k$, and fails with probability at most $(d - k)/B$; otherwise that univariate polynomial has at most $k$ roots. This is the classical polynomial-identity bound (Schwartz, 1980). Missing every tested direction requires this selected coefficient to vanish. Independent repetition gives the power bound. ∎

For the four-event non-identified cases in Section 10.1, a nontrivial district leaves at most three districts in total. With $B = 9$ and three ideal independent trials, the per-query bound is therefore $8/729$. It is not a simultaneous bound for all queries, and it is not a probability claim about the fixed SplitMix64 seed used in the supplied census. The exact verifier makes returned witnesses sound; randomness concerns missed witnesses.

The new finite check enumerates the cancellation polynomial $\left( w_{1} - w_{2} \right)\left( w_{3} - w_{4} \right)$ on the four-weight grid. It vanishes at 1,377 of 6,561 points, a fraction 17/81, below the degree bound 2/9. This is an algebraic illustration of cancellation and retry, not another graph-identification census.

## 11.4 Bounds that can be checked independently

**Theorem 11.6 (primal and dual certificates).** Let (11.1) be nonempty and let $L,U$ be the extrema of $c^{\mathsf{T}}q$. Vectors satisfying

$$A^{\mathsf{T}}\lambda \leq c \leq A^{\mathsf{T}}\mu\quad \Rightarrow \quad\lambda^{\mathsf{T}}b \leq L \leq U \leq \mu^{\mathsf{T}}b.\quad\quad(11.5)$$

If feasible $q_{-},q_{+}$ attain the two displayed dual values, those values are the sharp endpoints. Such matching dual certificates exist for these finite bounded feasible linear programmes.

*Proof.* Multiply the componentwise inequalities by any $q \geq 0$ and substitute $Aq = b$. Feasible primal points establish attainability when equality holds. Existence of matching dual optimizers is linear-programming strong duality; the objective is bounded because $q$ lies in a simplex (Boyd & Vandenberghe, 2004). ∎

A verifier checks equality, nonnegativity and componentwise inequalities using exact rationals. It need not trust the simplex pivot sequence or a language model's explanation. Floating-point solvers may propose the vectors; exact checks decide whether they certify the stated problem.

**Proposition 11.7 (certificate perturbation).** Let $\lambda,\mu$ satisfy (11.5). For a changed normalized feasible system $A\prime q = b\prime$, target $c\prime$, define

$$\begin{matrix}
\rho_{v} & = \parallel \, c\prime - c - (A\prime - A)^{\mathsf{T}}v\, \parallel_{\infty}, \\
\lambda^{\mathsf{T}}b\prime - \rho_{\lambda} & \leq c\prime^{\mathsf{T}}q \leq \mu^{\mathsf{T}}b\prime + \rho_{\mu}.
\end{matrix}\quad\quad(11.6)$$

*Proof.* Write $c\prime - A\prime^{\mathsf{T}}\lambda$ as the original nonnegative lower slack plus the residual inside the norm. Its dot product with a simplex vector is at least $- \rho_{\lambda}$. The upper inequality follows from the original nonpositive upper slack and the same argument. ∎

This is an arithmetic transport bound for a quantified change in coefficients. It does not license an unrecorded change of graph, latent class, event meaning or clock unit. In particular, the coefficient system of Proposition 10.2 can depend on the observational input. An old certificate is checked again or transported with the full matrix and objective residual.

**Corollary 11.8 (interval observational constraints).** Suppose $q$ remains normalized and nonnegative, and the evidence gives $\ell \leq Aq \leq u$. If $\alpha,\beta \geq 0$ and

$$\begin{matrix}
c - A^{\mathsf{T}}(\alpha - \beta) - \gamma\mathbf{1} & \geq 0 \\
 \Rightarrow \quad c^{\mathsf{T}}q & \geq \alpha^{\mathsf{T}}\ell - \beta^{\mathsf{T}}u + \gamma.
\end{matrix}\quad\quad(11.7)$$

An upper certificate is obtained by applying the same statement to $- c$.

*Proof.* Multiply the componentwise inequality by $q$ and use the lower bounds with $\alpha$, the upper bounds with $\beta$ and normalization with $\gamma$. ∎

All constraints refer to one common $q$. The intervals do not independently duplicate its occurrences. Their statistical coverage, if estimated from samples, is a separate input assumption.

## 11.5 Conditional bounds as linear programmes

**Theorem 11.9 (conditional response programme).** On a normalized response polytope $Aq = b$, suppose a conditional target is $N(q)/D(q) = n^{\mathsf{T}}q/\left( d^{\mathsf{T}}q \right)$ and $D(q) \geq \eta > 0$. Its sharp extrema are the extrema of $n^{\mathsf{T}}z$ subject to

$$Az = bt,\quad\quad d^{\mathsf{T}}z = 1,\quad\quad z \geq 0,\ t \geq 0.\quad\quad(11.8)$$

*Proof.* Set $z = q/D(q)$ and $t = 1/D(q)$. The constraints follow directly. Conversely, the normalization row in $Az = bt$ gives $\mathbf{1}^{\mathsf{T}}z = t$. A feasible point cannot have $t = 0$, since then $z = 0$ would contradict $d^{\mathsf{T}}z = 1$. Thus $q = z/t$ is feasible for the original problem, and its ratio is $n^{\mathsf{T}}z$. The two transformations are inverse. The denominator bound keeps $t$ bounded. This is the Charnes--Cooper transformation specialized to the response fibre (Charnes & Cooper, 1962). ∎

For the one-confounded-district setting of Section 10.2, both joint masses of a conditional query are linear in the free block, so this theorem supplies sharp conditional bounds. For several blocks, Theorem 11.3 supplies a vertex characterization instead. Neither statement covers arbitrary rational objectives or unrestricted latent structures.

The new worked bow has observational cells $(3/10,1/5,1/10,2/5)$ in order $(x,y) = (0,0),(1,0),(0,1),(1,1)$. Its event probability under $do(X = 1)$ ranges over $\lbrack 2/5,4/5\rbrack$. With selection rows $P(S = 1 \mid Y = 0) = 1/4$, $P(S = 1 \mid Y = 1) = 3/4$, its selected-outcome probability ranges over $\lbrack 2/3,12/13\rbrack$. Exact response vertices, the transformed exact simplex and an independent HiGHS solve agree.

![Analytic selected-outcome curve over the exact bow effect interval, and a ratio-contrast function with zero vertex values and a positive interior maximum.](current_media/media/image4.png){width="6.45in" height="2.85in"}

*Figure 4 Conditional response bounds and a limit of vertex-based comparisons*

## 11.6 Decisions under structural ambiguity

**Theorem 11.10 (ambiguity radius).** Suppose a target ranges over an attained interval $\lbrack L,U\rbrack$ on one observational fibre. With the observational law known exactly, the minimax absolute error of a scalar answer is $(U - L)/2$, attained by $(L + U)/2$. No learner using only observational samples and independent randomization can have smaller worst-case expected absolute error over that fibre.

*Proof.* The two endpoint models have identical observational sample distributions. A randomized learner therefore has the same output law, say that of $Z$, under both. The triangle inequality gives $E|Z - L| + E|Z - U| \geq U - L$, so one endpoint risk is at least half the width. The deterministic midpoint is within that distance of every possible target value. ∎

The result concerns information available under the declared model class. Additional structural assumptions, experimental data or justified domain knowledge can change the fibre. Repeated observational sampling alone cannot remove its structural width. This separates sampling uncertainty from the uncertainty represented by Section 10's witness pairs.

**Proposition 11.11 (robust action decisions).** Let a finite set of actions have affine expected utilities $u_{a}(q)$ on one common response polytope. Their worst-case regrets are

$$R(a) = \max_{b}\ \max_{q \in K}\{ u_{b}(q) - u_{a}(q)\}.\quad\quad(11.9)$$

Each inner problem is a linear programme. An action is optimal throughout the fibre exactly when $R(a) = 0$; a minimax-regret action minimizes these values.

*Proof.* For fixed $q$, regret is $\max_{b}u_{b}(q) - u_{a}(q)$. A maximum over a finite action set commutes with a supremum over $K$. Including $b = a$ makes regret nonnegative, and zero means no competitor is better at any feasible model. ∎

Thus a non-identified effect need not prevent a definite decision. On $p \in \lbrack 1/4,3/4\rbrack$, utilities $u_{0} = p/2$ and $u_{1} = p/2 + 1/8$ each have width $1/4$, but their common-parameter difference is always $1/8$. Action 1 has zero regret. This is an affine utility example, not a new empirical claim about a clinical or engineering intervention.

**Proposition 11.12 (a limit on conditional utility comparisons).** A difference of separately linear fractional functions need not have vertex extrema. For $p \in \lbrack 0,1\rbrack$,

$$\begin{matrix}
g(p) & = \frac{p}{1 + p} - \frac{p}{2},\quad\quad g(0) = g(1) = 0, \\
\max g & = \frac{3 - 2\sqrt{2}}{2}\quad\text{at }p = \sqrt{2} - 1.
\end{matrix}\quad\quad(11.10)$$

*Proof.* Differentiation gives $g\prime(p) = 1/(1 + p)^{2} - 1/2$, positive before the stated point and negative after it. Substitution gives the maximum. Each term separately satisfies Theorem 8.3, while their difference does not retain its certified form. ∎

For example $g(1/2) = 1/12 > 0$, so checking only the original vertices already fails. Equation (11.9) remains a valid definition for conditional utilities, but its inner problem is not generally an LP or a certified vertex problem. Joint endpoint optimization is required.

# 12 Neuroscience as a functional hypothesis

The mathematical results apply to declared event models. Neuroscience supplies evidence about abilities and possible computational roles. It does not establish that a brain represents a response polytope, computes ID or implements a mechanism sheaf. The proposed connection is a functional account that can be tested against behaviour and neural representations.

## 12.1 Acting and observing

Blaisdell et al. (2006) trained rats on causal arrangements including a common cause of a tone and food. Food expectation differed when the tone was produced by a lever press and when it was observed; a direct-cause condition supplied a comparison. The result supports sensitivity to the distinction between an event's usual source and an alternative source. It does not uniquely identify the animal's internal algorithm or prove execution of Pearl's calculus.

Sloman and Lagnado (2005) examine the same conceptual distinction in human judgement, while Lagnado and Sloman (2004, 2006) investigate how intervention and temporal information guide causal learning. The 2006 study shows that temporal order can dominate covariation and mislead when the order cue is misleading. ADC's clock theorem instead assumes a declared lag model and certifies its consequences. It does not learn those assumptions from chronology.

An exact common-cause illustration in the new kernel makes the distinction concrete. Let $U$ be fair and let cue $X$ and outcome $Y$ be independently flipped copies of $U$, each with flip probability $1/4$. Then $P(Y = 1 \mid X = 1) = 5/8$, while $P\left( Y = 1 \mid do(X = 1) \right) = 1/2$. This is an illustrative SCM, not a fit to the animal data. A biological interpretation additionally needs a model of how the action produces the cue and of what information the subject has learned.

## 12.2 Physical time and neural sequence position

Eichenbaum (2014) reviews hippocampal cells active at successive moments of structured experiences and interprets them as temporal organization of memory. Buzsáki and Tingley (2018) offer a different account, emphasizing internally generated sequences and their rate of change rather than an instrument-like representation of space and time. These accounts motivate different decoder models. Neither supplies the calibrated world-time intervals required by Corollary 6.3.

Pfeiffer and Foster (2013) recorded hippocampal sequences depicting paths toward remembered goals before movement. Such sequences motivate a generator of candidate futures. The generated sequence itself is an internal computation. Its relation to a future environment intervention still requires an event model and a decoder contract.

**Lemma 12.1 (a calibrated temporal decoder).** Suppose a population or artificial latent decoder supplies ${\widehat{\tau}}_{i}$ and certified errors $e_{i} \geq 0$ in one physical unit, with $\left| \tau_{i} - {\widehat{\tau}}_{i} \right| \leq e_{i}$. If

$${\widehat{\tau}}_{a} - {\widehat{\tau}}_{b} - e_{a} - e_{b} > 0\quad\text{for every }b \in Y \cup C,\ a \in A,\quad\quad(12.1)$$

then the strict orders needed by Theorem 6.1 hold. With its fixed-clock and nonnegative-lag assumptions, the action-deletion equality follows.

*Proof.* The left-hand expression is a lower bound for $\tau_{a} - \tau_{b}$. Apply the clock theorem to each pair. ∎

A zero margin is inconclusive for strict order. The new example has one decoded pair with margin 0 and a second with margin 7/20; only the second is certified. These are exact arithmetic illustrations. No neural decoder with these error bounds is reported. Sequence compression, replay speed and elapsed physical time remain different quantities.

## 12.3 What a causal memory must retain

A recent human study provides a closer functional connection. He et al. (2026) recorded hippocampal and cortical activity during two compositional inference tasks. Ripple-associated replay coordinated with medial prefrontal representations of inferred relational configurations and predicted efficient inference. This supports coordinated sequence generation and cortical representational updating. It does not establish mechanism replacement, causal-effect identification or the linear memory representation below.

Consider instead a precise engineering question: if a system consolidates response parameters into memory, which coordinates must it keep for a chosen family of causal queries? The parameters $q$ describe a model, rather than one token's state or one neural firing trajectory.

**Theorem 12.2 (minimal additional linear causal memory).** Suppose $Aq$ is retained, normalization is in its row space, and a query family has value vector $Cq$ on a simplex containing a full-support point. A linear memory $Tq$, together with $Aq$, preserves the query family exactly if and only if the kernel inclusion below holds. The minimum number of additional scalar coordinates is $k_{\min}$:

$$\begin{matrix}
\ker\begin{bmatrix}
A \\
T
\end{bmatrix} & \subseteq \ker C, \\
k_{\min} & = rank\begin{bmatrix}
A \\
C
\end{bmatrix} - rankA.
\end{matrix}\quad\quad(12.2)$$

*Proof.* Equal retained data differ by a vector in the displayed kernel. If the inclusion holds, all query values agree and hence factor through the retained data. If it fails, a violating direction can be added and subtracted at a small scale around a full-support point, giving two probability vectors with equal retained data and different queries. Row-space/nullspace duality turns the condition into inclusion of every query row in the row space of the stacked memory. At least the stated rank increment is needed. Retaining a basis of query rows modulo the row space of $A$ achieves it. ∎

In the bow example, observational response information has rank 4. Preserving both action probabilities raises the rank to 6 and needs 2 additional coordinates; preserving only their contrast needs 1. These counts refer to exact linear representations on the declared response simplex. They are not neuron counts or lower bounds for arbitrary nonlinear, finite-precision memories.

This gives a task-dependent consolidation principle: preserve the quotient information needed by the intended intervention queries. A memory sufficient for a preferred action contrast may be insufficient after the task changes to requiring each action probability separately. A neural implementation of this principle is a hypothesis about selective retention, not a consequence of ripple recordings.

## 12.4 Arbitration and testable hypotheses

Daw et al. (2005) develop a computational account of arbitration between controllers, balancing computational demands and uncertainty. ADC suggests a related design: use inexpensive event replacement when its structural certificate holds; otherwise use identification, bounded response optimization or additional information. Fibre width represents structural ambiguity, whereas an estimator's variance represents sampling uncertainty. Daw et al.'s account does not establish this particular decomposition in neural activity.

**Hypothesis H1 on temporal calibration.** In tasks with explicit event-time information, a model of decisions using calibrated time ranges will predict sensitivity to mixed date resolution better than a model that uses sequence position alone. Fix the task family and compare held-out action-deletion judgements. Failure to improve predictive fit under verified instruction comprehension would count against this proposed mapping. Lemma 12.1 remains a conditional mathematical statement regardless of the behavioural outcome.

**Hypothesis H2 on causal retention.** When two tasks share observations but require different intervention-query families, retention should preferentially preserve information relevant to the trained family. A computational test can first impose the linear memory budget of Theorem 12.2 and freeze a cross-task transfer protocol. A behavioural or neural study would additionally have to establish the participant's learned model class and exclude extra informative assumptions. Absence of query-specific retention under those controls would count against the biological interpretation.

The hypotheses concern what a representation preserves and how it is used. They make no claim that cortical layers are successive probability factors or that hippocampal sequence order is an intervention order. ASE inference depth, anatomical laminae, physical time and generated event order remain distinct.

# 13 An AI harness for causal computation

## 13.1 An authoritative problem and an untrusted proposal

An ADC harness has two inputs with different responsibilities. The authoritative problem supplies the event schema, graph and latent class, observational data, clock assumptions and query. A model may propose a derivation, witness or bound certificate. The verifier checks that proposal against the authoritative problem. This supports tool use without treating generated explanation as a proof.

**Definition 13.1 (certificate context).** A certificate context records the graph, latent-model class, observational-data version, query, decoder, clock unit, intervention scope and certificate-schema version. The deployed interface binds these fields to the problem contents. The reference prototype uses explicit version labels and checks exact equality before evaluating a packet.

*Table 6 Typed causal tool results*

  ----------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Result**                 **Required check**                                                          **Meaning**
  -------------------------- --------------------------------------------------------------------------- ---------------------------------------------------------
  Identified                 Valid ID/IDC derivation and defined normalizations                          One functional value on the declared model class

  Partially bounded          A sound optimization enclosure; matching feasible endpoints for sharpness   A range on the stated observational fibre

  Non-identified             Compatible models with equal observations and different query values        A carried semantic witness; bounds may also be supplied

  Clock inconclusive         Consistent constraints but no required strict margin                        This shortcut supplies no deletion certificate

  Input or context failure   Inconsistent constraints, invalid arithmetic domain or unequal context      The proposed result is not accepted for this problem
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------

The result categories describe different claims. A non-identification witness can accompany valid partial bounds and a robust action decision. An inconsistent clock is an input failure. An inconclusive clock is a failed shortcut, after which graphical reasoning may still succeed. A search that finds no witness is not thereby an identification proof.

**Theorem 13.2 (relative soundness of verified results).** Suppose the authoritative problem faithfully specifies the declared mathematical model class, and its primitive exact verifiers are correct. Accepting an identification derivation only by Theorem 4.5, a non-identification pair only by Theorem 3.4, an LP bound only by Theorems 11.6--11.9, and a clock deletion only by Corollary 6.3 gives sound results relative to that class. Reusing a result under an unequal certificate context is outside this guarantee.

*Proof.* Each accepted result has its corresponding semantic certificate. The relevant theorem proves its claim on the stated domain. Exact context matching preserves which domain and query that certificate concerns. Composition follows the induction of Theorem 4.5, retaining support and arithmetic premises. ∎

The theorem assumes the input meanings and the primitive checker; it is not formal verification of a software implementation or of a model extracted from natural language. Graph or unit errors can invalidate an otherwise correct calculation. Theorem 11.7 handles explicitly bounded coefficient changes; the ordinary cache path instead requires a matching context and a fresh check.

## 13.2 Computational interventions and world interventions

Geiger et al. (2021) align neural representations with variables in a high-level causal model and use interchange interventions to test the proposed abstraction. This is a relevant method for assessing Proposition 7.5. Meng et al. (2022) use activation restoration to trace factual computations and weight edits to alter associations in GPT. These are interventions on a computational model. They do not by themselves establish an intervention on the external event system represented by its text.

Here world names the declared system of interest, which may itself be software. The scope distinction is relative to the query: an intervention on a network can directly answer a question about that network while still requiring an abstraction argument for a question about its represented environment.

**Proposition 13.3 (three levels of an intervention answer).** Let $P_{a}^{L}$ be the law of a clamped latent computation, $d_{\#}P_{a}^{L}$ its decoded event law, ${\widetilde{P}}_{a}^{E}$ the event-replacement law, and $P_{a}^{W}$ the intended world-intervention law. If the first two discrepancies in

$$TV\left( d_{\#}P_{a}^{L},{\widetilde{P}}_{a}^{E} \right) \leq \epsilon,\quad\quad TV\left( {\widetilde{P}}_{a}^{E},P_{a}^{W} \right) \leq \kappa\quad\quad(13.1)$$

are bounded as shown, and a reported event probability $z_{B}$ differs from the decoded probability by at most $\eta$, then

$$\left| z_{B} - P_{a}^{W}(B) \right| \leq \eta + \epsilon + \kappa.\quad\quad(13.2)$$

*Proof.* For an event, a difference of probabilities is bounded by total variation. Apply the triangle inequality to the reported, decoded, replaced-event and world probabilities. ∎

Proposition 7.5 can supply $\epsilon$. Corollary 7.2 identifies replacement with the declared SCM intervention when its conditions hold. Equality of that SCM with the intended world intervention is additional semantic information; it must not be inferred from a successful activation patch. This separation also applies when an agent issues a tool call: computing a do-expression is different from executing an environment operation that realizes its assumed mechanism replacement.

## 13.3 How existing harness work fits

CLadder generates association, intervention and counterfactual questions with symbolic causal ground truth (Jin et al., 2023). Corr2Cause tests entailment of graph relations from conditional-independence statements under its closed-system and graph assumptions, including Markov-equivalence ambiguity (Jin et al., 2024). These are different tasks. The present ADC kernel addresses interventional probabilities and specified partial bounds; it does not supply a complete counterfactual-identification engine.

Kıcıman et al. (2024) study how language models can contribute causal arguments and contextual knowledge, while also documenting failures and motivating combination with causal methods. Zečević et al. (2023) propose a causal-parrot explanation of apparent competence. Their interpretation is a hypothesis about such systems, not a theorem that all future language-model architectures must fail. Theorem 11.10 supplies a narrower information limit: no method can resolve an observational fibre without additional information. A language model may contribute additional structural knowledge, which must be declared and assessed as such. The cited benchmark findings concern the models tested at publication and are not performance estimates for current frontier models.

ReAct provides an interleaved reasoning and tool-use pattern (Yao et al., 2023). ADC can occupy the tool position with typed results rather than a free-text verdict. SWE-agent shows the importance of the agent--computer interface in software engineering (Yang et al., 2024); the relevant design lesson here is to make valid inputs, results and failures explicit. Neither paper establishes ADC's causal correctness or a performance gain from using it.

The versioned lm-evaluation-harness release supplies a precedent for shared evaluation specifications (Gao et al., 2021). Inspect separates datasets, solvers, tools and scorers and records evaluation traces (UK AI Security Institute & Meridian Labs, n.d.). A proposed ADC integration puts model proposals in the solver, exact kernels in custom tools, and certificate verification and answer scoring in deterministic scorers. A reproducible trace documents execution; the mathematical certificate supplies the validity claim.

## 13.4 The executable prototype and new checks

The new immutable C# packet verifier implements the linear-bound branch. Its command-line interface takes an authoritative fixture and a separate proposed packet, then returns a structured status and certified endpoints when accepted. The fixture supplies the graph-class labels and exact matrix problem. Keeping that fixture outside the proposing agent's authority is a deployment requirement. The prototype tests context equality; it does not implement an access-control system.

The verifier checks dimensions, nonnegative normalized primal vectors, equality constraints and both dual inequalities. Matching primal and dual objectives produce the status SharpBounds; valid unmatched dual bounds produce OuterBounds. The companion schema and source specify the packet fields. Existing ID, IDC and clock kernels remain available, while their integration into a trained-agent runtime is proposed rather than benchmarked.

*Table 7 New exact certificate and interface checks*

  ----------------------------------------------------------------------------------------------------------------------------------
  **Computation**              **Finite size**           **Verified result**
  ---------------------------- ------------------------- ---------------------------------------------------------------------------
  Response fibre and duals     16 vertices               Effect range \[2/5, 4/5\]; both endpoints certified

  Conditional transformation   16 transformed vertices   Sharp selected range \[2/3, 12/13\]

  Two independent districts    256 vertex products       Joint range \[1/10, 3/5\]

  Certificate contexts         12 packets                1 sharp packet accepted; 8 context changes and 3 invalid packets rejected

  Retry cancellation grid      6,561 points              1,377 zeros; fraction 17/81 ≤ 2/9

  Linear causal memory         Ranks 4 and 6             2 additional coordinates for both effects; 1 for the contrast

  Ambiguity radius             One bow fibre             Midpoint 3/5; exact worst-case radius 1/5

  Executable tool interface    3                         Accepted valid fixture; rejected bad dual and stale scope
  ----------------------------------------------------------------------------------------------------------------------------------

All 16 new C# summary lines agree with independent exact Python calculations. The two LP examples are also re-solved with HiGHS, and symbolic differentiation verifies the interior ratio-contrast maximum. The executable command interface passes 3 independent fixture calls. The 30 inherited summary lines and their result files reproduce the supplied computation; the full verification record distinguishes exact equality, arithmetic enclosure and floating-point LP cross-checks.

The dual fixture returns the effect interval $\lbrack 2/5,4/5\rbrack$. Giving the observational cells simultaneous slabs of radius $1/100$ changes the sharp range to $\lbrack 39/100,81/100\rbrack$, attained by the supplied feasible response laws. The perturbation example changes both an observation channel and the target coefficients: the old bound fails, whereas the residual correction contains the new range. These are exact finite checks of contracts, not training experiments or evidence of a biological implementation.

## 13.5 A frozen learned-agent comparison

Conjecture C3 remains untested. A useful evaluation would freeze graph families, model classes, data splits, event decoders, query weights, prompts and denominators before comparing four methods: event replacement, free-text causal answering, execution of identified expressions, and the proposed ADC harness with verified bounds and failure categories. Graph access and data must be matched. Report token, tool-call, exact-operation and elapsed-time budgets separately.

Stratify results by identified and non-identified queries, the last-in-district certificate, conditioning context and date resolution. For point-identified targets report interventional error. For partial targets report endpoint accuracy, containment, width and false point-identification claims. Score mathematical validity separately from extraction of the intended graph and event meanings. Include mutated query, data, latent-class, decoder, unit and intervention-scope contexts as tests of certificate reuse.

CLadder and Corr2Cause can contribute distinct task components; synthetic response fibres supply exact partial-identification targets. Inspect or another logged harness can orchestrate the runs, but a scorer must verify the actual certificate. The proposed halving of C3's error ratio remains a prediction. The deterministic prototype does not establish it.

# 14 Conclusion

ADC connects autoregressive event generation to declared causal semantics. Its horizontal mechanism sheaf records local equations and shared variables, while identification and probability algebra justify their causal use. Clock certificates and the last-in-district condition specify when a cheaper computation already answers the intended intervention.

The response-fibre analysis turns added computation into mathematical contracts. Independent district response laws form a product of polytopes on a positive observational fibre. This gives a single-district witness result, an ideal retry bound, sharp vertex characterizations and a linear-fractional route to conditional bounds. Primal and dual certificates make proposed bounds independently checkable. Fibre width determines an unavoidable scalar ambiguity radius, while shared-model utility comparisons can still certify an action. A task's causal query family also determines the extra rank needed by an exact linear memory.

The neuroscience supplies functional hypotheses about intervention sensitivity, temporal decoding, sequence generation and selective retention. The agent harness supplies a concrete boundary between proposals and verified mathematical results. The remaining empirical work is to test those mappings and learned-system benefits while retaining the model-class, decoder and precision assumptions on which the guarantees depend.

# Appendix A Assumptions and claim boundaries

Table A1 Claim assumptions and limits

  -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Statement**                         **Required assumptions**                                                                            **What is certified**
  ------------------------------------- --------------------------------------------------------------------------------------------------- -------------------------------------------------------------------------------
  3.2 State gluing                      Fixed total mechanism relations on the incidence space                                              Solutions and local compatibility; no inferred probability law

  3.4 Identification                    Fixed model class and observational map                                                             Constancy on observational fibres

  4.1--4.5 Rules and programs           Correct mutilation, separation, typed probability algebra and defined support                       Semantic equality of each certified program

  5.1--5.2 Identification algorithms    Classical acyclic semi-Markovian setting; positive tabular support where divided                    Inherited joint ID and conditional IDC completeness

  6.1 and 6.3 Clock deletion            Fixed feasible clock; nonnegative directed lags; strict earlier order for outcomes and conditions   Invariance across compatible clocks and models

  7.1--7.2 Event replacement            Topological order; positive law; target last in its district                                        Whole-continuation exchange and intervention equality

  7.4--7.5 Approximation and decoding   Uniform row-TV bounds; decoder-fibre pushforward contract                                           Accumulated distribution error and decoded event semantics

  8.2 Product vertices                  Independent compact polytope blocks; separate affinity                                              Exact expression extrema on that product set

  8.3 Ratio vertices                    Same blocks; separately affine numerator and denominator; positive denominator                      Exact ratio extrema on that product set

  8.4 Specialized sharp bounds          Compatible positive front-door boxes and independent selection rows                                 Attainable causal range for the specified query

  10.1 Witness synthesis                Clique districts; one latent per district over response types; positive base laws                   Exact pair of models with equal observational laws and different query values

  10.2 Fibre bounds                     Exactly one confounded clique district; positive observational law in that class                    Sharp range of the query over the observational fibre

  11.2 Row-space criterion              A full-support feasible response law; normalization retained                                        Constancy on a fibre iff the objective is in the equality row space

  11.3 Product response fibre           Positive attainable law; independent common-latent clique districts                                 Sharp product-vertex extrema for joint and conditional cells

  11.4--11.5 Witness search             Same response class; joint query; ideal independent grid draws for probability bound                One-district witness existence and a per-query retry bound

  11.6--11.9 Bound certificates         Nonempty normalized response polytope; positive denominator for ratios                              Checked LP bounds, quantified perturbations and conditional extrema

  11.10--11.11 Ambiguity and choice     One observational fibre; affine utilities for the LP regret calculation                             Scalar minimax radius and robust action decisions

  12.1 Temporal decoder                 Physical-unit errors valid for all queried events; clock theorem assumptions                        A strict-order certificate from decoded time ranges

  12.2 Linear causal memory             Linear summaries and query family; full-support simplex; normalization retained                     Minimum extra rank for the chosen causal query family

  13.2--13.3 Harness and transfer       Authoritative model context; correct primitive verifiers; stated decoder/world error bounds         Relative certificate validity and an explicit answer-error budget
  -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Theorems 3.4, 4.5, 8.2 and 8.3 are elementary structural or optimization statements. Lemmas 4.1--4.3 and Theorems 5.1--5.2 are inherited causal results, included to specify ADC's semantics. The clock and generator consequences are proved in their finite setting; no claim of being the first formulation of every component is made.

# Appendix B Reference kernel and reproduction

## B.1 Immutable values and explicit failures

The reference code targets .NET 8 without third-party NuGet packages. Exact rationals are reduced pairs of arbitrary-precision integers. Ordered graph values contain immutable vertex and edge arrays. The current graph representation accepts at most twelve events; the executed suite uses at most eight. Query results contain a formula graph, its evaluated exact kernel and a recursion trace, or a failure record naming the active graph and district. IDC uses the same graph operations and kernel representation.

The formula language distinguishes observational joint data, marginalization, products and positive division. In every recursive call, district factors are extracted from prefix ratios of the current kernel. Exact parameter identity is retained in the symbolic precision calculation. Local mutation is confined to temporary storage; no graph, law, rational or interval value is changed after publication.

The arithmetic layer rejects a zero denominator, an interval divisor containing zero and unsupported nonfinite arithmetic. Clock inconsistency is returned separately from a successful but inconclusive order test. Non-identification is a property of the query and model class; these arithmetic or clock failures must not be mislabeled non-identification.

## B.2 Independent routes

C# ground truth sums latent-state densities over endogenous assignments, omitting the clamped target mechanisms. Python instead enumerates all exogenous noise assignments and solves the remaining mechanisms in order. C# separation uses moralization of the ancestral explicit latent DAG. Python enumerates m-active paths directly in the mixed graph. Both implement ID and IDC independently; y0 supplies a third decision route.

For interval checks, Python evaluates exact rational intervals and exact vertex values. It verifies containment using the exact rational value of each returned binary64 endpoint. The allowed excess width over the ideal interval calculation is at most $10^{- 12}\max(1,w)$, where $w$ is its ideal width. Exact causal identities use zero tolerance. Symbolic checks expand polynomials and confirm the degree certificate.

The verified environments are .NET SDK 8.0.427 with runtime 8.0.33, Python 3.12.14, SymPy 1.14.0 and y0 0.2.11. The source archive includes the C# project, the independent validator, input and result files, this manuscript, its Word builder, and a project note recording the status of C1--C3. The SDK and third-party dependency installations are not bundled.

## B.3 Reproduction contract

Build the C# project in release mode, run its executable with the output directory argument and capture the tab-separated summary. Run the independent validator in the same source directory with its listed Python dependencies. The supplied README gives the exact commands and package versions. The three deterministic random streams separately generate models, clocks and credal boxes.

A clean replay reproduces all summary lines and generated JSON and CSV result files byte for byte; the independent validator passes all 21 summary lines. The checks establish agreement for this declared finite suite. They do not constitute formal verification of arbitrary code paths, a generic hedge-witness generator or a learned-system evaluation. The Version 2 lines are checked by a separate validator described in B.4.

## B.4 Earlier response computations

The new studies live in DoNumerics.cs and run with the flag \--v2, which writes 9 summary lines and four result files: witnesses, fibre programmes, the replacement census and the clock-deletion narratives. Public values remain immutable records; row reduction and the simplex method use private scratch arrays. The default run is unchanged. In the Version 2 environment it reproduced the Version 1 summary and all five result files byte for byte, and the Version 1 validator passed again.

The validator validate_v2.py reuses the Version 1 validator's graph, ID and exogenous-enumeration routines and adds independent response-type decoding, exact witness certificates, complete enumeration for a sample of witness pairs, HiGHS re-solution of every programme, and exact replays of the three new random streams. It passed all 18 checks. The streams use seeds 20261030070 to 20261030073. The verified environment was .NET SDK 8.0.131, Python 3.13.16, SymPy 1.14.0, SciPy 1.18.1, NumPy 2.5.3 and y0 0.2.11.

## B.5 Certificate and harness additions

DoCertificates.cs supplies response-vertex enumeration, the conditional transformation, exact primal and dual checking, the coefficient-residual example, the memory ranks and the typed packet tests. The --v3 execution mode writes 16 summary records and certificates.json. The --verify-packet command takes two paths: an authoritative fixture and a separate candidate certificate. It returns a structured result. The companion JSON schema documents interchange fields; mathematical acceptance uses the C# checks.

validate_v3.py independently generates response types, solves exact bases with SymPy, checks every summary record, re-solves the LPs with HiGHS and verifies the three real command-line fixture calls. All 16 summary records and 3 interface calls pass. The verifier's 12 packet cases include an accepted sharp certificate, eight mismatched contexts, a bad dual, an infeasible primal and a dimension mismatch.

The original 21-record suite and the nine-record response suite were rerun and independently checked. All inherited summary and result files match the supplied files byte for byte. A separate fresh temporary project build reproduces the new summary and certificate JSON byte for byte. replay_v3_results.json records all 13 comparisons and SHA-256 hashes. This revision used .NET SDK 8.0.427 and runtime 8.0.33, Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, SymPy 1.14.0 and y0 0.2.11. Earlier environment versions in B.4 describe that supplied revision, rather than the current replay.

The source archive includes the V2 Word base, current builder and Markdown, all kernel sources and validators, results, tool fixtures and reproduction instructions. Installed SDKs and third-party dependency trees are excluded.

# References

Abramsky, S., & Brandenburger, A. (2011). The sheaf-theoretic structure of non-locality and contextuality. *New Journal of Physics, 13*, 113036. https://doi.org/10.1088/1367-2630/13/11/113036

Balke, A., & Pearl, J. (1997). Bounds on treatment effects from studies with imperfect compliance. *Journal of the American Statistical Association, 92*(439), 1171--1176. https://doi.org/10.1080/01621459.1997.10474074

Blaisdell, A. P., Sawa, K., Leising, K. J., & Waldmann, M. R. (2006). Causal reasoning in rats. *Science, 311*(5763), 1020--1022. https://doi.org/10.1126/science.1121872

Bland, R. G. (1977). New finite pivoting rules for the simplex method. *Mathematics of Operations Research, 2*(2), 103--107. https://doi.org/10.1287/moor.2.2.103

Boyd, S., & Vandenberghe, L. (2004). *Convex optimization*. Cambridge University Press. https://web.stanford.edu/\~boyd/cvxbook/

Buzsáki, G., & Tingley, D. (2018). Space and time: The hippocampus as a sequence generator. *Trends in Cognitive Sciences, 22*(10), 853--869. https://doi.org/10.1016/j.tics.2018.07.006

Charnes, A., & Cooper, W. W. (1962). Programming with linear fractional functionals. *Naval Research Logistics Quarterly, 9*(3--4), 181--186. https://doi.org/10.1002/nav.3800090303

Cozman, F. G. (2000). Credal networks. *Artificial Intelligence, 120*(2), 199--233. https://doi.org/10.1016/S0004-3702(00)00029-1

Daw, N. D., Niv, Y., & Dayan, P. (2005). Uncertainty-based competition between prefrontal and dorsolateral striatal systems for behavioral control. *Nature Neuroscience, 8*(12), 1704--1711. https://doi.org/10.1038/nn1560

Dechter, R., Meiri, I., & Pearl, J. (1991). Temporal constraint networks. *Artificial Intelligence, 49*(1--3), 61--95. https://doi.org/10.1016/0004-3702(91)90006-6

Duarte, G., Finkelstein, N., Knox, D., Mummolo, J., & Shpitser, I. (2024). An automated approach to causal inference in discrete settings. *Journal of the American Statistical Association, 119*(547), 1778--1793. https://doi.org/10.1080/01621459.2023.2216909

Eichenbaum, H. (2014). Time cells in the hippocampus: A new dimension for mapping memories. *Nature Reviews Neuroscience, 15*(11), 732--744. https://doi.org/10.1038/nrn3827

Fritz, T., & Klingler, A. (2023). The d-separation criterion in categorical probability. *Journal of Machine Learning Research, 24*(46), 1--49. https://jmlr.org/papers/v24/22-0916.html

Gao, L., Tow, J., Biderman, S., Black, S., DiPofi, A., Foster, C., Golding, L., Hsu, J., McDonell, K., Muennighoff, N., Phang, J., Reynolds, L., Tang, E., Thite, A., Wang, B., Wang, K., & Zou, A. (2021). *A framework for few-shot language model evaluation* (Version v0.0.1) \[Computer software\]. Zenodo. https://doi.org/10.5281/zenodo.5371629

Geiger, A., Lu, H., Icard, T., & Potts, C. (2021). Causal abstractions of neural networks. *Advances in Neural Information Processing Systems, 34*. https://papers.nips.cc/paper/2021/hash/4f5c422f4d49a5a807eda27434231040-Abstract.html

Ghosh, D. P. (2026). *Dependency preserving temporal causal computation: Horizontal sheaves, interval ranges and temporal smoothing*. https://doi.org/10.13140/RG.2.2.33732.18568

Gogioso, S., & Pinzani, N. (2021). *The sheaf-theoretic structure of definite causality* \[Withdrawn preprint\]. arXiv. https://arxiv.org/abs/2103.13771

Gogioso, S., & Pinzani, N. (2022). *The combinatorics of causality* \[Preprint, version 4, revised 2023\]. arXiv. https://arxiv.org/abs/2206.08911v4

Gogioso, S., & Pinzani, N. (2023). *The topology of causality* \[Preprint, version 2\]. arXiv. https://arxiv.org/abs/2303.07148v2

He, L., Wang, X., Zhang, J., Xiao, Z., Hu, X., Schwartenbeck, P., Bakermans, J., Behrens, T., & Liu, Y. (2026). Human hippocampal ripples coordinate planning sequences and compositional representations in neocortex. *Nature Neuroscience, 29*(7), 1711--1721. https://doi.org/10.1038/s41593-026-02291-3

Jacobs, B., Kissinger, A., & Zanasi, F. (2019). Causal inference by string diagram surgery. In *Foundations of Software Science and Computation Structures* (Vol. 11425, pp. 313--329). Springer. https://doi.org/10.1007/978-3-030-17127-8_18

Jin, Z., Chen, Y., Leeb, F., Gresele, L., Kamal, O., Lyu, Z., Blin, K., Gonzalez Adauto, F., Kleiman-Weiner, M., Sachan, M., & Schölkopf, B. (2023). CLadder: Assessing causal reasoning in language models. *Advances in Neural Information Processing Systems, 36*. https://doi.org/10.52202/075280-1353

Jin, Z., Liu, J., Lyu, Z., Poff, S., Sachan, M., Mihalcea, R., Diab, M., & Schölkopf, B. (2024). Can large language models infer causation from correlation? In *International Conference on Learning Representations*. https://arxiv.org/abs/2306.05836v3

Kıcıman, E., Ness, R., Sharma, A., & Tan, C. (2024). *Causal reasoning and large language models: Opening a new frontier for causality* \[Preprint, version 3\]. arXiv. https://arxiv.org/abs/2305.00050v3

Lagnado, D. A., & Sloman, S. A. (2004). The advantage of timely intervention. *Journal of Experimental Psychology: Learning, Memory, and Cognition, 30*(4), 856--876. https://doi.org/10.1037/0278-7393.30.4.856

Lagnado, D. A., & Sloman, S. A. (2006). Time as a guide to cause. *Journal of Experimental Psychology: Learning, Memory, and Cognition, 32*(3), 451--460. https://doi.org/10.1037/0278-7393.32.3.451

Mahadevan, S. (2025). *Intuitionistic j-do-calculus in topos causal models* \[Preprint, version 2, revised 2026\]. arXiv. https://arxiv.org/abs/2510.17944v2

Manski, C. F. (1990). Nonparametric bounds on treatment effects. *American Economic Review, 80*(2), 319--323.

Meng, K., Bau, D., Andonian, A., & Belinkov, Y. (2022). Locating and editing factual associations in GPT. *Advances in Neural Information Processing Systems, 35*. https://proceedings.nips.cc/paper_files/paper/2022/file/6f1d43d5a82a37e89b0665b33bf3a182-Paper-Conference.pdf

Pearl, J. (1995). Causal diagrams for empirical research. *Biometrika, 82*(4), 669--688. https://doi.org/10.1093/biomet/82.4.669

Pearl, J. (2009). *Causality: Models, reasoning, and inference* (2nd ed.). Cambridge University Press. https://doi.org/10.1017/CBO9780511803161

Pfeiffer, B. E., & Foster, D. J. (2013). Hippocampal place-cell sequences depict future paths to remembered goals. *Nature, 497*(7447), 74--79. https://doi.org/10.1038/nature12112

Schwartz, J. T. (1980). Fast probabilistic algorithms for verification of polynomial identities. *Journal of the ACM, 27*(4), 701--717. https://doi.org/10.1145/322217.322225

Shpitser, I., & Pearl, J. (2006a). Identification of conditional interventional distributions. In *Proceedings of the Twenty-Second Conference on Uncertainty in Artificial Intelligence* (pp. 437--444). AUAI Press. https://arxiv.org/abs/1206.6876

Shpitser, I., & Pearl, J. (2006b). Identification of joint interventional distributions in recursive semi-Markovian causal models. In *Proceedings of the Twenty-First AAAI Conference on Artificial Intelligence* (pp. 1219--1226). AAAI Press. https://ftp.cs.ucla.edu/pub/stat_ser/r327.pdf

Sloman, S. A., & Lagnado, D. A. (2005). Do we "do"? *Cognitive Science, 29*(1), 5--39. https://doi.org/10.1207/s15516709cog2901_2

Tian, J., & Pearl, J. (2002). A general identification condition for causal effects. In *Proceedings of the Eighteenth National Conference on Artificial Intelligence* (pp. 567--573). AAAI Press. https://cdn.aaai.org/AAAI/2002/AAAI02-085.pdf

UK AI Security Institute, & Meridian Labs. (n.d.). *Inspect* \[Software documentation\]. Retrieved October 30, 2026, from https://inspect.aisi.org.uk/

y0 contributors. (n.d.). *y0* (Version 0.2.11) \[Computer software\]. https://github.com/y0-causal-inference/y0

Yang, J., Jimenez, C. E., Wettig, A., Lieret, K., Yao, S., Narasimhan, K., & Press, O. (2024). SWE-agent: Agent-computer interfaces enable automated software engineering. *Advances in Neural Information Processing Systems, 37*. https://doi.org/10.52202/079017-1601

Yao, S., Zhao, J., Yu, D., Du, N., Shafran, I., Narasimhan, K., & Cao, Y. (2023). ReAct: Synergizing reasoning and acting in language models. In *International Conference on Learning Representations*. https://arxiv.org/abs/2210.03629v3

Yvernes, C., Devijver, E., Clausel, M., & Gaussier, E. (2026). Unveiling the structure of do-calculus reasoning via derivation graphs. In *Proceedings of the 43rd International Conference on Machine Learning* (Vol. 306, pp. 152645--152672). PMLR. https://proceedings.mlr.press/v306/yvernes26a.html

Zečević, M., Willig, M., Dhami, D. S., & Kersting, K. (2023). Causal parrots: Large language models may talk causality but are not causal. *Transactions on Machine Learning Research*. https://arxiv.org/abs/2308.13067v1
