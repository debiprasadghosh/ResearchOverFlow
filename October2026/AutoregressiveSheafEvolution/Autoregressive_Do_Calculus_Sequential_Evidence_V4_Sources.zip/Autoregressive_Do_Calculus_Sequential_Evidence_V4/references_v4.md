Donoho, D. L. (1994). Statistical estimation and optimal recovery. *The Annals of Statistics, 22*(1), 238–270. https://doi.org/10.1214/aos/1176325367

Hoeffding, W. (1963). Probability inequalities for sums of bounded random variables. *Journal of the American Statistical Association, 58*(301), 13–30. https://doi.org/10.1080/01621459.1963.10500830

Howard, S. R., Ramdas, A., McAuliffe, J., & Sekhon, J. (2021). Time-uniform, nonparametric, nonasymptotic confidence sequences. *The Annals of Statistics, 49*(2), 1055–1080. https://doi.org/10.1214/20-AOS1991

Shpitser, I., & Pearl, J. (2007). What counterfactuals can be tested. In *Proceedings of the Twenty-Third Conference on Uncertainty in Artificial Intelligence* (pp. 352–359). AUAI Press. https://ftp.cs.ucla.edu/pub/stat_ser/r344.pdf
