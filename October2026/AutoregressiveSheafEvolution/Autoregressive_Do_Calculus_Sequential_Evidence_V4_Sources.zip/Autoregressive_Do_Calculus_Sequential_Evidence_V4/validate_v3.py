"""Independent exact V3 checks, symbolic verification, HiGHS and the executable tool interface."""
from __future__ import annotations
import copy,itertools,json,math,os,subprocess,sys
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
import scipy,sympy as sp

ROOT=Path(__file__).resolve().parent
CS={l.split("\t")[0]:list(map(F,l.rstrip().split("\t")[1].split())) for l in (ROOT/"cs_v3.txt").read_text().splitlines()}
DATA=json.loads((ROOT/"out_v3/certificates.json").read_text())
checks=[]
def check(name,condition,detail=""):
    checks.append(dict(name=name,passed=bool(condition),detail=str(detail)))
    if not condition:raise AssertionError((name,detail))
def exact(name,expected):
    check(name,CS[name]==list(map(F,expected)),(CS[name],expected))
def frac(x):return F(int(x.p),int(x.q))
def dot(a,b):return sum((x*y for x,y in zip(a,b)),F(0))
def mv(a,q):return [dot(r,q) for r in a]
def atv(a,d):return [dot(col,d) for col in zip(*a)]
def vertices(a,b):
    """SymPy exact basis solves; C# uses its own Gaussian elimination."""
    m,n=len(a),len(a[0]);out=set()
    ma=sp.Matrix(a);mb=sp.Matrix(b)
    for basis in itertools.combinations(range(n),m):
        sub=ma[:,basis]
        if sub.det()==0:continue
        x=sub.inv()*mb
        if any(z<0 for z in x):continue
        q=[F(0)]*n
        for j,z in zip(basis,x):q[j]=frac(z)
        assert mv(a,q)==b
        out.add(tuple(q))
    return out
def highs(a,b,c):
    r=linprog(list(map(float,c)),A_eq=np.array(a,dtype=float),b_eq=np.array(b,dtype=float),bounds=(0,None),method="highs")
    assert r.success,r.message
    return r

# Generate deterministic potential response types from their semantic definition.
types=list(itertools.product((0,1),repeat=3))
a=[[F(int(x==v%2 and (y0 if x==0 else y1)==v//2)) for x,y0,y1 in types] for v in range(4)]
c=[F(y1) for x,y0,y1 in types];c0=[F(y0) for x,y0,y1 in types]
p=list(map(F,DATA["p"]))
# JSON uses the opposite bit significance to itertools.product; align by the declared type index.
indices=[x+2*y0+4*y1 for x,y0,y1 in types]
order=np.argsort(indices).tolist()
a=[[r[j] for j in order] for r in a];c=[c[j] for j in order];c0=[c0[j] for j in order]
assert a==[list(map(F,r)) for r in DATA["matrix"]]
vs=vertices(a,p)
assert vs=={tuple(map(F,r)) for r in DATA["vertices"]}
v1=[dot(c,q) for q in vs];v0=[dot(c0,q) for q in vs]
exact("response_vertices",[len(vs),min(v1),max(v1),min(v0),max(v0)])
row=[x+y for x,y in zip(a[2],a[3])]
ma=sp.Matrix(a)
inrow=lambda c:ma.rank()==ma.col_join(sp.Matrix([c])).rank()
qb,qo=list(map(F,DATA["baseQ"])),list(map(F,DATA["otherQ"]))
assert all(q>0 for q in qb+qo)
exact("rowspace_witness",[inrow(row),inrow(c),mv(a,qb)==mv(a,qo),min(qo),abs(dot(c,qo)-dot(c,qb))])
lo,hi=list(map(F,DATA["lowerDual"])),list(map(F,DATA["upperDual"]))
pl,pu=list(map(F,DATA["lowerPrimal"])),list(map(F,DATA["upperPrimal"]))
exact("dual_certificates",[all(x<=y for x,y in zip(atv(a,lo),c)),all(x>=y for x,y in zip(atv(a,hi),c)),
    dot(c,pl)==dot(lo,p),dot(c,pu)==dot(hi,p),dot(lo,p),dot(hi,p)])
assert abs(highs(a,p,c).fun-float(min(v1)))<1e-9
assert abs(highs(a,p,[-x for x in c]).fun+float(max(v1)))<1e-9

n=[F(3,4)*x for x in c];d=[F(1,4)+F(1,2)*x for x in c]
bmat=[r+[-b] for r,b in zip(a,p)]+[d+[F(0)]]
rhs=[F(0)]*4+[F(1)];objective=n+[F(0)]
assert bmat==[list(map(F,r)) for r in DATA["ccMatrix"]]
ccvs=vertices(bmat,rhs);target=[dot(n,q)/dot(d,q) for q in vs]
ccvals=[dot(objective,z) for z in ccvs]
assert all(t[-1]>0 for t in ccvs)
for t in ccvs:
    q=[x/t[-1] for x in t[:-1]]
    assert mv(a,q)==p and sum(q)==1
assert abs(highs(bmat,rhs,objective).fun-float(min(target)))<1e-9
assert abs(highs(bmat,rhs,[-x for x in objective]).fun+float(max(target)))<1e-9
exact("conditional_cc",[min(target),max(target),min(ccvals),max(ccvals),len(ccvs),min(dot(d,q) for q in vs)])
eta=F(1,100)
sl,sh=list(map(F,DATA["slab"]["loPrimal"])),list(map(F,DATA["slab"]["hiPrimal"]))
inslab=lambda q:all(abs(x-y)<=eta for x,y in zip(mv(a,q),p)) and all(x>=0 for x in q) and sum(q)==1
slab_a=a+[[-x for x in r] for r in a];slab_b=[x+eta for x in p]+[-x+eta for x in p]
slp=linprog(np.array(c,dtype=float),A_ub=np.array(slab_a,dtype=float),b_ub=np.array(slab_b,dtype=float),
            A_eq=np.ones((1,8)),b_eq=[1],bounds=(0,None),method="highs")
sup=linprog(-np.array(c,dtype=float),A_ub=np.array(slab_a,dtype=float),b_ub=np.array(slab_b,dtype=float),
            A_eq=np.ones((1,8)),b_eq=[1],bounds=(0,None),method="highs")
assert slp.success and sup.success
assert abs(slp.fun-float(dot(c,sl)))<1e-9 and abs(sup.fun+float(dot(c,sh)))<1e-9
exact("interval_observations",[p[3]-eta,1-p[1]+eta,dot(c,sl),dot(c,sh),inslab(sl) and inslab(sh)])

ap=[list(map(F,r)) for r in DATA["perturbation"]["matrix"]]
pp=list(map(F,DATA["perturbation"]["p"]));cp=list(map(F,DATA["perturbation"]["c"]))
da=[[x-y for x,y in zip(r,s)] for r,s in zip(ap,a)];dc=[x-y for x,y in zip(cp,c)]
rho=lambda dual:max(abs(x-y) for x,y in zip(dc,atv(da,dual)))
changed=vertices(ap,pp);changed_vals=[dot(cp,q) for q in changed]
assert changed==vs
rl,rh=rho(lo),rho(hi)
safe=(dot(lo,pp)-rl,dot(hi,pp)+rh)
assert safe[0]<=min(changed_vals)<=max(changed_vals)<=safe[1]
exact("certificate_perturbation",[rl,rh,*safe,min(changed_vals),max(changed_vals),
    min(v1)<=min(changed_vals) and max(changed_vals)<=max(v1)])
p2=[F(1,4)]*4;vs2=vertices(a,p2)
prods=[dot(c,q)*dot(c,r) for q,r in itertools.product(vs,vs2)]
selected=[3*f/(1+2*f) for f in prods]
exact("product_districts",[len(prods),min(prods),max(prods),min(selected),max(selected)])
qs=[F(1,4),F(3,4)]
payoffs=[[q/2 for q in qs],[q/2+F(1,8) for q in qs]]
regrets=[max(payoffs[b][i]-payoffs[a][i] for b in range(2) for i in range(2)) for a in range(2)]
exact("decision_dominance",[max(payoffs[0])-min(payoffs[0]),max(payoffs[1])-min(payoffs[1]),
    min(b-a for a,b in zip(*payoffs)),*regrets])
x=sp.Symbol("x",nonnegative=True)
g=x/(1+x)-x/2
exact("ratio_contrast",[frac(g.subs(x,t)) for t in (0,1,sp.Rational(1,2))])
root=sp.sqrt(2)-1;gmax=(3-2*sp.sqrt(2))/2
assert sp.simplify(sp.diff(g,x).subs(x,root))==0 and sp.simplify(g.subs(x,root)-gmax)==0
exact("ambiguity_radius",[min(v1),max(v1),(min(v1)+max(v1))/2,(max(v1)-min(v1))/2])
times=[F(1,5),F(2,5),F(9,10)];errors=[F(1,10),F(1,10),F(1,20)]
gaps=[times[j]-times[i]-errors[j]-errors[i] for i,j in ((0,1),(1,2))]
exact("clock_decoder",[gaps[0],gaps[0]>0,gaps[1],gaps[1]>0])
mass_obs=mass_cue=F(0)
for u,nx,ny in itertools.product((0,1),repeat=3):
    weight=F(1,2)*[F(3,4),F(1,4)][nx]*[F(3,4),F(1,4)][ny]
    mass_cue+=weight*int((u^nx)==1)
    mass_obs+=weight*int((u^nx)==1 and (u^ny)==1)
exact("common_cause_seeing_do",[mass_obs/mass_cue,F(1,2),mass_obs/mass_cue-F(1,2)])

def verify(expected,packet):
    if packet["context"]!=expected:return "ContextMismatch"
    ll,uu,ql,qu=([F(x) for x in packet[k]] for k in ("lowerDual","upperDual","lowerPrimal","upperPrimal"))
    if len(ll)!=4 or len(uu)!=4 or len(ql)!=8 or len(qu)!=8:return "DimensionFailure"
    feasible=lambda q:all(x>=0 for x in q) and sum(q)==1 and mv(a,q)==p
    if not feasible(ql) or not feasible(qu):return "PrimalFailure"
    if any(x>z or y<z for x,y,z in zip(atv(a,ll),atv(a,uu),c)):return "DualFailure"
    return "SharpBounds" if dot(c,ql)==dot(ll,p) and dot(c,qu)==dot(uu,p) else "OuterBounds"
packet={k:DATA[k] for k in ("context","lowerDual","upperDual","lowerPrimal","upperPrimal")}
context=copy.deepcopy(DATA["context"])
observed=[verify(context,packet)]
for field in context:
    ctx=dict(context);ctx[field]+="-changed";observed.append(verify(ctx,packet))
bad_dual=copy.deepcopy(packet);bad_dual["lowerDual"]=["0","0","0","2"]
bad_primal=copy.deepcopy(packet);bad_primal["lowerPrimal"]=[str(-v) for v in pl]
bad_dimension=copy.deepcopy(packet);bad_dimension["lowerDual"]=[]
observed += [verify(context,bad_dual),verify(context,bad_primal),verify(context,bad_dimension)]
assert observed==[r["status"] for r in DATA["statuses"]]
exact("typed_harness",[observed[0]=="SharpBounds",observed.count("ContextMismatch"),
    observed[-3]=="DualFailure",observed[-2]=="PrimalFailure",observed[-1]=="DimensionFailure",len(observed)])
ba=[[F(1)]*3,[F(1),F(1),F(0)]];bb=[F(1),F(0)];bc=[F(1),F(0),F(0)]
bvs=vertices(ba,bb);vals=[dot(bc,q) for q in bvs]
exact("boundary_rowspace",[min(vals),max(vals),sp.Matrix(ba).rank()!=sp.Matrix(ba).col_join(sp.Matrix([bc])).rank()])
rank_a=ma.rank();rank_both=ma.col_join(sp.Matrix([c0,c])).rank()
rank_contrast=ma.col_join(sp.Matrix([[x-y for x,y in zip(c,c0)]])).rank()
exact("causal_memory",[rank_a,rank_both,rank_both-rank_a,rank_contrast,rank_contrast-rank_a])
total=9**4;zeros=total-(9*8)**2;miss=F(zeros,total);bound=F(2,9)
exact("witness_grid",[total,zeros,miss,bound,miss**3,bound**3])
assert set(CS)=={r["name"] for r in checks}

# Execute the real two-input C# tool interface. The trusted fixture is separate from the candidate packet.
fixture={k:DATA[k] for k in ("context","matrix","p","c")}
toolroot=ROOT/"tool_fixtures";toolroot.mkdir(exist_ok=True)
(toolroot/"trusted.json").write_text(json.dumps(fixture,indent=2))
dotnet=os.environ.get("ADC_DOTNET","dotnet");dll=ROOT/"kernel/bin/Release/net8.0/Adc.dll"
cli=[]
for name,proposed,expected in [("valid",packet,"SharpBounds"),("bad_dual",bad_dual,"DualFailure"),
    ("stale",dict(packet,context=dict(context,scope="computation")),"ContextMismatch")]:
    path=toolroot/(name+".json");path.write_text(json.dumps(proposed,indent=2))
    result=json.loads(subprocess.check_output([dotnet,str(dll),"--verify-packet",str(toolroot/"trusted.json"),str(path)],text=True))
    assert result["status"]==expected,result
    if expected=="SharpBounds":assert (F(result["lower"]),F(result["upper"]))==(min(v1),max(v1))
    cli.append(dict(name=name,result=result,passed=True))
(ROOT/"tool_cli_results.json").write_text(json.dumps(cli,indent=2))
result={"all_passed":all(c["passed"] for c in checks),"summary_lines":len(CS),"checks":checks,
        "vertices":len(vs),"conditional_vertices":len(ccvs),"tool_packet_cases":len(observed),"cli_cases":len(cli),
        "symbolic_ratio_contrast_maximum":str(gmax),"symbolic_ratio_contrast_argmax":str(root),
        "runtime":{"python":sys.version.split()[0],"numpy":np.__version__,"scipy":scipy.__version__,"sympy":sp.__version__}}
(ROOT/"validation_v3.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({k:v for k,v in result.items() if k!="checks"},indent=2))
