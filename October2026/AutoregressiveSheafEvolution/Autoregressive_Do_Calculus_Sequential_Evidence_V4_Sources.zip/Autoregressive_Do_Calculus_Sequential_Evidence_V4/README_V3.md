# Autoregressive Do Calculus for Causal Agents

Version 3 · 30 October 2026 · Debi Prasad Ghosh

This archive accompanies the revised Word paper. Start here; `README_V1.md`
and `README_V2.md` describe the earlier revisions and their historical environments.

## Current paper and sources

- `deliverables/Autoregressive_Do_Calculus_Causal_Agents_V3.docx` is the current paper.
- `paper_current_v3.md` is a reading copy extracted from that Word file. The
  earlier `paper.md` and `paper_filled.md` do not include the complete V2 revision.
- `base_v2.docx` is the authoritative supplied Word base used by `build_v3.py`.
  The builder preserves its equations and three figures, corrects superseded
  passages and inserts the new sections from `extension_v3.md`.
- `extension_v3_filled.md`, `references_v3.md` and `figures/` contain resolved
  additions, the new bibliography entries and scientific figures.
- `kernel/` is a .NET 8 project with exact rational arithmetic, ID/IDC,
  interval clocks, response optimization and the new certificate interface.
- `PROJECT_NOTE_V3.md` records results, theorem scope and empirical status.
- `document_v3_audit.json`, `render_review_v3.json` and `MANIFEST_SHA256.json`
  record structure checks, final visual review and source hashes. XML checks
  establish well-formedness and package integrity, not full OOXML schema validation.

## Reproduce the computation

Use Python 3.12 and a .NET 8 SDK. The current run used Python 3.12.14,
SDK 8.0.427, runtime 8.0.33, SymPy 1.14.0, NumPy 2.3.5, SciPy 1.17.0
and y0 0.2.11. Install the Python requirements in a separate environment:

```bash
python -m pip install -r requirements_validation.txt
dotnet build kernel/Adc.csproj -c Release
dotnet kernel/bin/Release/net8.0/Adc.dll out_v1_replay > cs_v1_replay.txt
dotnet kernel/bin/Release/net8.0/Adc.dll out_v2_replay --v2 > cs_v2_replay.txt
dotnet kernel/bin/Release/net8.0/Adc.dll out_v3 --v3 > cs_v3.txt
python validate_adc.py
python validate_v2.py cs_v2_replay.txt out_v2_replay validation_v2_replayed.json
python validate_v3.py
python replay_v3.py
```

The original validator reads `cs_results.txt` and `output/`. The replay script
compares them with `cs_v1_replay.txt` and `out_v1_replay/`, and similarly compares
the V2 files. It also builds V3 in a fresh temporary project. Both reference
and replay outputs are included. `ADC_DOTNET` can specify an absolute .NET
executable path for the Python validators and replay script.

There are 21 original, nine V2 and 16 new C# summary records: 46 in total.
Every record passes independent Python checks. All 13 summary and result-file
comparisons in `replay_v3_results.json` are byte-identical. Solver cross-checks
using HiGHS are floating-point checks with their stated tolerances; rational
primal and dual checks are exact. Reproduction on different software versions
can change logs and environment fields even when mathematical outputs agree.

The project has no third-party NuGet dependencies. `nuget.config` clears
external feeds; an installed .NET 8 SDK supplies the required reference packs.
Public model and certificate values are immutable; local arrays used by
elimination and enumeration are private scratch storage.

## Invoke the causal certificate tool

```bash
dotnet kernel/bin/Release/net8.0/Adc.dll --verify-packet tool_fixtures/trusted.json tool_fixtures/valid.json
dotnet kernel/bin/Release/net8.0/Adc.dll --verify-packet tool_fixtures/trusted.json tool_fixtures/bad_dual.json
dotnet kernel/bin/Release/net8.0/Adc.dll --verify-packet tool_fixtures/trusted.json tool_fixtures/stale.json
```

These return `SharpBounds`, `DualFailure` and `ContextMismatch`, respectively.
The trusted fixture supplies context and the matrix problem. The candidate
supplies proposed primal and dual vectors. An agent must not control the
trusted fixture. The prototype checks labels and exact arithmetic; it does
not implement access control or content hashing. `adc_certificate.schema.json`
documents interchange fields, while C# performs the mathematical checks.
`tool_cli_results.json` records the three real executable calls; the main
suite additionally checks 12 packet cases.

## Rebuild the Word paper

Install `requirements_document.txt` and Pandoc. The current build used
Pandoc 3.1.3, python-docx 1.2.0 and native OMML equations.

```bash
python build_v3.py
```

Run this from any directory; file paths are relative to the builder. It requires
the included validated reports and result files. It creates the current Word
file and structure audit. LibreOffice rendering and full-page visual review
are required after rebuilding because fonts and Office versions can change
pagination. The current final render has 42 pages.

## Scope

Sections 11.3–11.5 concern the stated independent common-latent clique-response
class and joint queries. Larger clique districts are broader than the original
pairwise-latent class. Ideal random-draw guarantees do not become probability
claims for a deterministic seed. Multiple-district bounds use products of
vertices, not one global LP. The memory rank theorem covers exact linear
summaries, not neuron counts or arbitrary nonlinear compression.

Neuroscience interpretations H1 and H2 and the trained-agent comparison C3
remain hypotheses. This archive contains no new neural recording, transformer
training experiment or Inspect benchmark. The tool prototype is an executable
mathematical checker, not a deployed end-to-end agent harness.
