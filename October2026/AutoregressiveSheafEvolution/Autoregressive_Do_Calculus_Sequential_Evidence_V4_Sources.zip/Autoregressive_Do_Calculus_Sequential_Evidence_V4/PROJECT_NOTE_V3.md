# Results and claim status in Version 3

## Mathematical development

The revision adds 17 formal statements in Sections 11–13, bringing the paper
to 50 numbered definitions, lemmas, propositions, theorems and corollaries.
These include classical results with explicit attribution as well as deductions
for the stated ADC model. The paper does not claim these are all novel.

- The response fibre in the independent common-latent clique-district class
  is a product of district polytopes for a positive attainable observational law.
- Non-identification of a joint query has a witness differing in one district
  somewhere in that class. The pair need not lie over a separately given dataset.
- A selected null direction has a nonzero polynomial coefficient. Ideal
  independent uniform integer draws give a per-query miss bound. Fixed draws
  can cancel, correcting the earlier simultaneous-district explanation.
- Primal and dual LP certificates can be checked exactly; matrix and objective
  changes have an explicit residual allowance. Interval data retain one shared
  response vector. Conditional one-block bounds use the classical
  Charnes–Cooper transformation.
- Structural width gives the scalar minimax ambiguity radius. Shared-model
  affine utilities can certify an action even when each effect is not identified.
- Differences of conditional ratios need not have vertex extrema.
- The least additional exact linear memory for queries Cq, given Aq, is
  rank([A;C]) minus rank(A), with normalization and full-support premises.
- Harness soundness is relative to an authoritative model and correct primitive
  verifiers. Latent, decoded and intended-system intervention meanings remain
  separate, with a stated total-variation and numerical error budget.

## New computational checks

All 16 new C# records agree with independent Python calculations. Exact
response vertices and certificates are checked with Fraction and SymPy;
HiGHS independently re-solves the LP examples. Symbolic differentiation checks
the interior maximum of the conditional contrast. The examples establish:

- Bow range [2/5, 4/5], selected range [2/3, 12/13].
- Simultaneous observational slabs of radius 1/100 give [39/100, 81/100].
- The perturbed matrix/objective example invalidates the old bound; its residual
  correction contains the changed exact range.
- Two independent blocks give 256 vertex products and a sharp joint range
  [1/10, 3/5].
- The bow ambiguity midpoint is 3/5 with exact worst-case radius 1/5.
- Observation has response rank 4; both action probabilities raise it to 6,
  while their contrast raises it to 5.
- The cancellation polynomial is zero at 1,377 of 6,561 grid points. Its exact
  miss fraction 17/81 is below 2/9. This is a polynomial illustration, not a new
  graph census or a deterministic-seed probability claim.
- The packet suite accepts a sharp certificate and rejects eight changed
  contexts and three invalid packets. Three additional real CLI calls pass.

The original 21-record and V2 nine-record suites were rerun and independently
checked: 46 records in total. All 13 summary/result-file replay comparisons are
byte-identical; V3 was rebuilt separately in a fresh temporary project.

## Neuroscience and AI status

Acting versus observing, temporal cues, hippocampal time and sequence accounts,
prospective replay, controller arbitration and hippocampal–prefrontal updating
motivate functional roles. They do not prove implementation of a sheaf, LP or
do-calculus in a brain. H1 proposes calibrated time-range sensitivity; H2
proposes query-dependent causal retention. Both remain untested here.

The C# tool implements the linear-bound branch with separate authoritative
and candidate files. Inspect/ReAct integration, causal benchmarks and learned
decoders are specified as future work, not reported evaluations.

## Inherited comparison outcomes

- C1: unrestricted repeat-count precision ranking is refuted. Regrouping the
  tested positive expressions does not improve their ideal interval bounds.
- C2: invalid point-date deletions occur in 950/38,400 queries, 2.47%, between
  the 5% prediction and 1% contradiction threshold. This part is inconclusive.
  Certificate retention is 10,733/14,080, 76.2%, with no invalid deletion,
  meeting that part of the frozen prediction.
- C3: the learned-agent error-ratio prediction remains untested.

## Document quality

The current Word file retains editable native equations, original figures and
validated numerical values. The source audit checks ZIP integrity, XML
well-formedness, unique formal-statement labels, old image retention and no
unresolved placeholders. It does not assert complete OOXML schema validation.
The final 42-page render was reviewed page by page.
