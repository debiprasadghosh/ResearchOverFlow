"""Reproduce inherited outputs and a fresh-build V3 suite, recording exact byte comparisons."""
from __future__ import annotations
import hashlib,json,os,shutil,subprocess,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
dotnet=os.environ.get("ADC_DOTNET","dotnet")
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
def same(label,old,new):
    r={"file":label,"sha256":sha(old),"replay_sha256":sha(new),"identical":old.read_bytes()==new.read_bytes()}
    records.append(r);assert r["identical"],r
same("v1/cs_results.txt",ROOT/"cs_results.txt",ROOT/"cs_v1_replay.txt")
for p in sorted((ROOT/"output").iterdir()):
    if p.is_file():same("v1/"+p.name,p,ROOT/"out_v1_replay"/p.name)
same("v2/cs_v2.txt",ROOT/"cs_v2.txt",ROOT/"cs_v2_replay.txt")
for p in sorted((ROOT/"out_v2").iterdir()):
    if p.is_file():same("v2/"+p.name,p,ROOT/"out_v2_replay"/p.name)
with tempfile.TemporaryDirectory(prefix="adc_v3_replay_") as td:
    temp=Path(td);project=temp/"kernel";project.mkdir()
    for p in (ROOT/"kernel").iterdir():
        if p.is_file():shutil.copy2(p,project/p.name)
    log=subprocess.run([dotnet,"build",str(project/"Adc.csproj"),"-c","Release","--verbosity","minimal"],
                       capture_output=True,text=True,check=True)
    (ROOT/"fresh_build_v3.log").write_text(log.stdout+log.stderr)
    out=temp/"out";out.mkdir()
    run=subprocess.run([dotnet,str(project/"bin/Release/net8.0/Adc.dll"),str(out),"--v3"],
                       capture_output=True,check=True)
    assert not run.stderr,run.stderr
    (out/"cs_v3.txt").write_bytes(run.stdout)
    same("v3/cs_v3.txt",ROOT/"cs_v3.txt",out/"cs_v3.txt")
    same("v3/certificates.json",ROOT/"out_v3/certificates.json",out/"certificates.json")
report={"all_identical":all(r["identical"] for r in records),"files":records,
        "method":"supplied inherited outputs versus rerun; V3 rebuilt in a fresh temporary project"}
(ROOT/"replay_v3_results.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))
