# Autoregressive Do Calculus with Sequential Evidence

Version 4 · 31 October 2026 · Debi Prasad Ghosh

This revision extends the existing ADC paper. It adds Section 14 on sequential
evidence, experimental choice and causal-memory precision. Sections 2–13 and
their earlier results remain part of the paper. The conclusion is now Section 15.

## Start here

- `deliverables/Autoregressive_Do_Calculus_Sequential_Evidence_V4.docx`: current Word paper.
- `paper_current_v4.md`: reading copy extracted from the exact current Word file.
- `base_v3.docx`, `build_v4.py`: authoritative input and current Word builder.
- `extension_v4.md`, `extension_v4_filled.md`, `references_v4.md`: new manuscript material.
- `sequential_reference.py`: immutable finite response polytopes and ledgers;
  exact rational elimination and active-constraint enumeration.
- `validate_v4.py`: independent LP, closed-form, semantic, replay and inherited-file checks.
- `py_v4.txt`, `out_v4/sequential_results.json`, `validation_v4.json`:
  current summaries, full mathematical inputs/outputs and verification results.
- `figures/v4_evidence_recovery.png` and `.svg`: the new scientific figure.
- `document_v4_audit.json`, `render_review_v4.json`: Word structure and final visual review.
- `PROJECT_NOTE_V4.md`: theorem scope, corrections and empirical status.

`README_V1.md`, `README_V2.md` and `README_V3.md` describe the earlier revisions.
Earlier manuscript files do not include all later extensions; use the current
Word file or its current Markdown reading copy.

## Reproduce the new calculations

Use Python 3.12. The current environment was Python 3.12.14, NumPy 2.3.5 and
SciPy 1.17.0. Only the independent checker needs NumPy and SciPy; the exact
reference module uses the standard library.

```bash
python -m pip install -r requirements_v4.txt
python sequential_reference.py out_v4 > py_v4.txt
python validate_v4.py
```

Run these commands in this source directory. There are 13 new deterministic
summary records and 27 LP cases. HiGHS solves each LP in both objective directions,
54 solves in total, agreeing within absolute tolerance 1e-9. Fractions in the
reference module are exact; NumPy ranks and HiGHS are separate floating-point
cross-checks. The validator also compares against analytic recovery formulas,
the telescoping confidence budget and direct regime probability tables.

`validate_v4.py` runs the new reference module in a fresh Python process and
compares the summary and result JSON byte for byte. It also verifies 13 inherited
C# summary/result files against `inherited_manifest_v3.json`. The earlier 46 C#
records and their validation reports are preserved. Those C# suites were not
rerun in V4, and no new C# execution is claimed.

The fixed numerical confidence radii use ordinary binary64 logarithm and square
root. They illustrate the formula; a certified statistical deployment needs a
valid conservative or outward-rounded implementation. No Monte Carlo coverage
study, neural experiment or trained-agent benchmark is included.

## Use the immutable ledger API

`Polytope.simplex(n)` creates a probability simplex. `.exact(rows, rhs)` and
`.slab(rows, lower, upper)` return new immutable constraints. `.bounds(c)` returns
the exact finite minimum and maximum. Vertex enumeration is intended only for
these small reference problems.

A `Ledger` binds a semantic `Context`, the actual target coefficients, authorized
channel rows, a polytope, an evidence version and a parent digest. Its `.append`
method constructs a new snapshot from a registered regime. `verify_refinement`
checks semantic equality, the parent link, literal prefix retention of old
constraints and nonempty feasibility. Literal prefix retention is sufficient,
not necessary, for set inclusion. Hashes bind contents; they do not authenticate
an experiment, authorize an action or validate the scientific model.

The eight transition examples accept one refinement and reject seven context,
parent, constraint or consistency failures. Old sharpness witnesses are checked
again after evidence changes. A previously valid outer bound remains valid on a
certified subset even when its previous endpoint models become infeasible.

## Rebuild the Word paper

Install the packages in `requirements_document.txt` and Pandoc. Pandoc 3.1.3,
python-docx 1.2.0 and native editable OMML equations were used.

```bash
python build_v4.py
```

The current builder reads `base_v3.docx`, the new extension, references and
validated V4 outputs. It retains the earlier figures and equations. Its audit
checks package integrity, XML well-formedness, formal-statement uniqueness,
image preservation and placeholder resolution. It does not assert full OOXML
schema validation. Rebuilds require rendering and review because fonts and
Office versions can alter pagination and equation display.

## Mathematical and empirical scope

The sequential LP results require a fixed compact polytope in one response law,
fixed linear regime maps and a scalar linear target. Multiple unknown independent
districts generally produce nonlinear constraints; they are not silently merged.
The recovery theorem uses a deterministic coordinatewise bounded-error channel,
not an arbitrary stochastic-noise or conditional-query model.

The confidence theorem assumes a finite declared menu, fresh stationary regime
streams, predictable allocation and a true initial model. H1, H2 and the new H3
remain functional neuroscience hypotheses. C3 remains a learned-agent conjecture.
The C1 and C2 statuses from V3 are unchanged. No new empirical performance claim
is made.
