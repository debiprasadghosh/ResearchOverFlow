# Version 4 mathematical development and claim status

The continuation develops how ADC changes when another measurement or experiment
is added. Ten formal statements in Section 14 bring the paper to 60 numbered
definitions, lemmas, propositions, theorems and corollaries. This count includes
attributed classical facts and elementary deductions, not 60 novelty claims.

## Main results

1. One response law is retained across all reports. Nonempty nested feasible
   sets have nonincreasing sharp query width and worst-case regret.
2. Old outer bounds remain valid on a certified subset. Old sharpness requires
   rechecking the endpoint models. An arbitrary version-label change is not a
   refinement proof.
3. A conservative error-spending confidence sequence gives simultaneous
   containment under a finite menu of stationary regime streams and adaptive
   allocation. This supports a regret certificate at a finite adaptive stop.
4. The worst width after an exact experiment is an LP on two response models
   with identical predicted reports. Bounded report errors replace equality by
   a componentwise difference bound. Additional report restrictions must be
   included before that result is called sharp for the application.
5. The deterministic noisy-memory minimax error is half the largest query
   difference between indistinguishable models. Its dual balances omitted
   query information and amplification of the stored channel errors. An affine
   decoder attains the optimum on a nonempty compact polytope.
6. Exact measurements can reduce the rank of query information that memory
   must additionally preserve. Interval measurements require precision-aware
   analysis rather than unconditional deletion based on rank.
7. Two measurements may each have zero one-step worst-case-width gain while
   their pair identifies the target. Query-rank gain need not be submodular.
8. Every perfect-intervention distribution can agree while a cross-world
   coupling differs. The elementary example is not a new general theorem of
   counterfactual identification; the established literature is cited.

The optimal-recovery and confidence-sequence connections are explicitly credited
to existing work. The finite proofs state their own deterministic and sampling
assumptions. No universal statement about neural memories, nonlinear compression,
multiple unknown independent districts or conditional-ratio queries is inferred.

## Deterministic verification

The new exact reference module produces 13 summary records. An independent
checker solves 27 LP cases in both directions with HiGHS, 54 solves, and checks
the analytic recovery curves, semantic tables and rank calculations. It passes
every check. A fresh Python process reproduces the new JSON and summary bytes.
Thirteen inherited summary and mathematical-result files match V3 hashes.
The original C# suites were not rerun in this revision.

The bow intervals shrink from [2/5,4/5] to [11/20,13/20], then
[29/50,31/50], and finally the exact value 3/5. Its previous sharp endpoint
models become infeasible after refinement. The two-channel example has risk
min(2 epsilon,1/2), including unavoidable error 1/10 at channel error 1/20.
All nine perfect-intervention regimes agree in the counterfactual example,
while P(Y0=Y1) is one in one model and zero in the other.

## Empirical status

H1 temporal calibration, H2 query-dependent retention and H3 complementary
acquisition remain hypotheses. H3 includes a proposed controlled comparison
and a refuting outcome. The neuroscience literature motivates roles but does
not establish execution of the optimization programs in a brain.

C1's unrestricted repeat-count ranking remains refuted. C2's invalid-deletion
prediction remains inconclusive at 2.47%, while 76.2% certificate retention
meets its prediction with no invalid deletion on that finite family. C3's
trained-agent improvement prediction remains untested.

The new ledger is an immutable mathematical prototype. Content digests prove
which constraints are bound into a snapshot, not whether the data are true or
the agent is authorized to perform an experiment. The mathematical action
certificate concerns the declared causal model, not an automatically validated
external world.
