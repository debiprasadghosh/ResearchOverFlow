"""Revise the authoritative V2 Word file, preserving its mathematics, figures and results."""
from __future__ import annotations
import copy,hashlib,json,re,subprocess,tempfile,unicodedata,zipfile
from datetime import datetime,timezone
from fractions import Fraction as F
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from lxml import etree

ROOT=Path(__file__).resolve().parent
BASE=ROOT/"base_v2.docx"
DEST=ROOT/"deliverables";DEST.mkdir(exist_ok=True)
OUT=DEST/"Autoregressive_Do_Calculus_Causal_Agents_V3.docx"
V=json.loads((ROOT/"validation_v3.json").read_text())
V1=json.loads((ROOT/"validation_results.json").read_text())
V2=json.loads((ROOT/"validation_v2_replayed.json").read_text())
REPLAY=json.loads((ROOT/"replay_v3_results.json").read_text())
assert V["all_passed"] and V1["all_passed"] and V2["all_passed"] and REPLAY["all_identical"]
def read_cs(name):
    return {l.split("\t")[0]:l.rstrip().split("\t")[1].split() for l in (ROOT/name).read_text().splitlines()}
C=read_cs("cs_v3.txt");C1=read_cs("cs_results.txt");C2=read_cs("cs_v2.txt")
assert len(C)==V["summary_lines"]
fmt=lambda n:f"{int(n):,}"
fills={
    "GRID_ZEROS":fmt(C["witness_grid"][1]),"GRID_TOTAL":fmt(C["witness_grid"][0]),
    "GRID_MISS":C["witness_grid"][2],"GRID_BOUND":C["witness_grid"][3],
    "BOW_LO":C["response_vertices"][1],"BOW_HI":C["response_vertices"][2],
    "CC_LO":C["conditional_cc"][0],"CC_HI":C["conditional_cc"][1],
    "SEEING":C["common_cause_seeing_do"][0],"DOING":C["common_cause_seeing_do"][1],
    "CLOCK_ZERO":C["clock_decoder"][0],"CLOCK_POSITIVE":C["clock_decoder"][2],
    "RANK_A":C["causal_memory"][0],"RANK_BOTH":C["causal_memory"][1],
    "MEMORY_BOTH":C["causal_memory"][2],"MEMORY_CONTRAST":C["causal_memory"][4],
    "V3_LINES":len(C),"OLD_LINES":len(C1)+len(C2),"CLI_CASES":V["cli_cases"],
    "SLAB_LO":C["interval_observations"][0],"SLAB_HI":C["interval_observations"][1]
}
md=(ROOT/"extension_v3.md").read_text()
for k,v in fills.items():md=md.replace("{{"+k+"}}",str(v))
assert not re.search(r"\{\{[A-Z_]+\}\}",md)
(ROOT/"extension_v3_filled.md").write_text(md)
doc=Document(BASE);body=doc.element.body
W="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M="http://schemas.openxmlformats.org/officeDocument/2006/math"
R="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
warnings=[]
def fragment(text):
    with tempfile.TemporaryDirectory() as td:
        p=Path(td);(p/"f.md").write_text(text)
        run=subprocess.run(["pandoc",str(p/"f.md"),"-f","markdown+tex_math_dollars-auto_identifiers",
            "-o",str(p/"f.docx"),f"--reference-doc={BASE}","--no-highlight"],capture_output=True,text=True,check=True)
        if run.stderr.strip():warnings.append(run.stderr)
        f=Document(p/"f.docx")
        els=[copy.deepcopy(e) for e in f.element.body if e.tag!=qn("w:sectPr")]
        for e in els:
            for b in list(e.iter(qn("w:bookmarkStart")))+list(e.iter(qn("w:bookmarkEnd"))):b.getparent().remove(b)
            for x in e.iter():
                rid=x.get(f"{{{R}}}id")
                if rid and rid in f.part.rels:
                    rel=f.part.rels[rid]
                    if not rel.is_external:raise ValueError("unexpected internal fragment relationship")
                    x.set(f"{{{R}}}id",doc.part.relate_to(rel.target_ref,rel.reltype,is_external=True))
        return els
def find(start,style=None):
    for p in doc.paragraphs:
        t=p.text.replace("\xa0"," ").replace("\u2019","'")
        if t.startswith(start) and (style is None or p.style.name==style):return p
    raise KeyError(start)
def before(anchor,elements):
    for e in elements:anchor.addprevious(e)
def replace_md(p,text):
    els=fragment(text);assert len(els)==1
    p._p.getparent().replace(p._p,els[0])
def ppr(e):
    pr=e.find(qn("w:pPr"))
    if pr is None:pr=OxmlElement("w:pPr");e.insert(0,pr)
    return pr
def caption(text,keep=True):
    p=doc.add_paragraph(text,style="Caption");p.paragraph_format.keep_with_next=keep
    p.paragraph_format.space_before=Pt(8);p.paragraph_format.space_after=Pt(6)
    for r in p.runs:r.font.size=Pt(10);r.font.italic=True;r.font.color.rgb=RGBColor(0,0,0)
    e=p._p;e.getparent().remove(e);return e

# Updated front matter and research positioning.
find("Autoregressive Do Calculus","Title").text="Autoregressive Do Calculus for Causal Agents"
find("Clock certificates","Subtitle").text="Sharp bounds neural sequence hypotheses and verified tool use"
for p in doc.paragraphs:
    if p.style.name=="Date":p.text="Version 3 · 30 October 2026"
abstract=(
 "Autoregressive Do Calculus (ADC) is a finite discipline for connecting observational generators to declared causal queries. "
 "It combines mechanism sheaves, classical identification, clock certificates and dependency-preserving uncertainty calculations. "
 "This paper develops the mathematics of its response-function computations and connects it to functional neuroscience and agent "
 "harness design. For a positive observational law in a stated clique-response model, the response fibre is a product of district "
 "polytopes. Joint effects and conditional effects attain sharp extrema at product vertices. Every non-identified joint query in "
 "this class admits a witness pair differing in one district; coefficient cancellation explains missed base draws, and a polynomial "
 "identity argument bounds ideal independent retries. Primal and dual certificates allow bounds to be checked independently of the "
 "solver, including explicit residual allowances for changed coefficients and a linear-programming reduction for conditional targets. "
 "Fibre width determines an unavoidable scalar ambiguity radius. Shared-model utility comparisons can nevertheless certify an "
 "action, and a rank difference determines the extra coordinates needed by an exact linear causal memory. Behavioural intervention "
 "studies, hippocampal time and sequence accounts, and recent hippocampal–prefrontal inference findings motivate testable functional "
 "hypotheses; they do not establish a neural implementation of ADC. An executable C# interface checks separate authoritative problems "
 "and proposed bound packets, retaining graph, latent-class, data, query, decoder, unit and intervention-scope identities. Independent "
 f"Python checks agree with all {len(C1)+len(C2)+len(C)} C# summary records, and inherited result files reproduce byte for byte. "
 "The guarantees are relative to explicit model and decoder assumptions. Learned-agent performance and the biological mappings remain "
 "empirical questions.")
find("Autoregressive models provide observational conditionals").text=abstract
kw=find("Keywords")
kw.text=("Keywords autoregressive generation; do-calculus; response functions; partial identification; mechanism sheaves; "
         "neural sequences; causal memory; primal and dual certificates; agent harnesses")
kw.runs[0].font.bold=False
first=kw.runs[0]
# Bold only the label while keeping the rest plain.
kw.text="";kw.add_run("Keywords ").bold=True;kw.add_run("autoregressive generation; do-calculus; response functions; partial identification; "
    "mechanism sheaves; neural sequences; causal memory; primal and dual certificates; agent harnesses")

lit=(
 "Partial identification already has an extensive computational foundation. Response-function methods give linear bounds in "
 "important cases (Balke & Pearl, 1997), and Duarte et al. (2024) formulate general discrete causal bounding as polynomial "
 "optimization. Our added analysis identifies a structured product of response fibres and supplies independently checkable "
 "certificates for its specified subproblems. It does not claim a new general theory of causal bounding.\n\n"
 "Behavioural work distinguishes action from observation and studies temporal cues to causal learning (Blaisdell et al., 2006; "
 "Lagnado & Sloman, 2006). Hippocampal accounts distinguish experienced time, internally generated sequences and prospective "
 "paths (Buzsáki & Tingley, 2018; Eichenbaum, 2014; Pfeiffer & Foster, 2013). These motivate the functional hypotheses in Section 12. "
 "Their role is to constrain an interpretation, rather than prove the mathematical construction.\n\n"
 "Causal language-model benchmarks and neural abstraction studies supply separate evaluation targets (Geiger et al., 2021; "
 "Jin et al., 2023, 2024). Agent work supplies a place for an executable causal tool (Yao et al., 2023; Yang et al., 2024). "
 "Section 13 distinguishes extraction, mathematical verification and transfer to the intended system of interest.")
before(find("1.2 Contribution","Heading 2")._p,fragment(lit))
h12=find("1.2 Contribution","Heading 2")._p
h13=find("1.3 Structure","Heading 2")._p
e=h12.getnext()
while e is not h13:
    nxt=e.getnext();e.getparent().remove(e);e=nxt
contrib=(
 "The contribution is an execution discipline joining causal soundness, event-decoder validity, temporal certification and stated "
 "precision. Classical do-calculus, district factorization and ID/IDC completeness remain attributed results. The mechanism incidence "
 "sheaf records shared state variables; probability marginalization remains a generally weaker presheaf.\n\n"
 "The response computations are developed into product-fibre structure, one-district witness existence, an ideal retry bound, primal "
 "and dual certificates, conditional bounding, robust regret and a task-dependent linear memory criterion. Each statement records "
 "its model class. In particular, the clique-common-latent class used for larger response districts is distinguished from the original "
 "pairwise-primitive setting.\n\n"
 "The neuroscience connection is a set of functional hypotheses about acting, temporal decoding, sequence generation and retention. "
 "The harness connection has a small executable verifier and a proposed learned-agent evaluation. Neither supplies a new neural "
 "recording study or a trained-model performance result. Exact finite calculations check arithmetic and implementation contracts; "
 "biological and comparative performance claims retain their stated empirical status.")
before(h13,fragment(contrib))
find("Section 2 defines the model and query types.").text=(
 "Sections 2 to 5 specify finite models, sheaves, query semantics and classical identification. Sections 6 to 8 develop clocks, "
 "event replacement and credal precision. Sections 9 and 10 report the inherited finite studies and their comparison outcomes. "
 "Section 11 proves the response-fibre and certificate results. Section 12 develops neuroscience hypotheses and a causal memory "
 "criterion. Section 13 specifies the harness and its new checks, and Section 14 concludes. Appendix A collects assumptions; "
 "Appendix B records the reference code and reproduction routes.")
cd=list(map(int,C2["clock_deletion"]))
replace_md(find("C2 hypothesis on clock-aware causal answers."),
 f"**C2 hypothesis on clock-aware causal answers.** The original pair-order study in Section 9.3 does not measure semantic causal "
 f"errors. Section 10.4 performs that query-level test. Point dates give {fmt(cd[3])} invalid deletions among {fmt(cd[1])} queries "
 f"({100*cd[3]/cd[1]:.2f}%). This is below the predicted 5% and above the 1% contradiction threshold, so that part of the frozen "
 f"comparison is inconclusive. Certified deletion retains {100*cd[8]/cd[6]:.1f}% of deletions allowed by the true dates, with none invalid, "
 "meeting the retention prediction on this finite family. A chronological-order error and a failed causal equality remain distinct measurements.")
find("A failure trace is not an automatically synthesized pair of models.").text=(
 "A failure trace and a synthesized pair of models are different certificates. Section 10.1 constructs pairs on the stated clique-response "
 "class, and Section 11 explains its one-district search. A credal range remains conditional on its uncertainty set. Multiple-district "
 "vertex enumeration can be exponential, and differences of conditional targets need not retain the vertex property. General latent "
 "structures and learned event-decoder validity require additional work.")
find("This is an empirical completeness result for the witness search").text=(
 "Every failure in this finite census received a verified witness. Section 11.4 proves that a one-district witness exists for a "
 "non-identified joint query in this clique-response class. A fixed draw can make its direction coefficient vanish through cancellation. "
 "The finite retry routine is therefore distinguished from a general deterministic completeness guarantee; Section 11.3 gives its "
 "ideal random-sampling analysis.")
# Correct the cross-reference in this newly inserted explanation.
find("Every failure in this finite census").text=find("Every failure in this finite census").text.replace("Section 11.4 proves","Theorem 11.4 proves")
find("10 Extended do-numerics","Heading 1").text="10 Exact response computations"
find("Version 2 adds four exact studies.").text=(
 "The following four exact studies extend the base suite. Each turns a statement or stated computational limit into a reproducible "
 "calculation. The separate execution mode retains the original 21 summary records and is independently validated. Appendix B records "
 "the implementation and replay routes.")
# Normalization in the earlier witness construction follows from its complete consistency rows.
p=find("For a two-member district the latent")
before(p._p,fragment("Summing the response-consistency rows over district assignments at fixed external parent values gives the "
    "normalization row. Thus a perturbation annihilating every such row also has total mass zero, as required for both probability laws."))

# Replace the old conclusion with the new mathematical, neuroscience and harness development.
old=find("11 Conclusion","Heading 1")._p
app=find("Appendix A","Heading 1")._p
e=old
while e is not app:
    nxt=e.getnext();e.getparent().remove(e);e=nxt
before(app,fragment(md))

def style_table(t,widths,kind="generic"):
    tp=t._tbl.tblPr
    for x in list(tp):tp.remove(x)
    for tag,attrs in [("tblW",{"w":str(sum(widths)),"type":"dxa"}),("jc",{"val":"center"})]:
        x=OxmlElement("w:"+tag)
        for k,v in attrs.items():x.set(qn("w:"+k),v)
        tp.append(x)
    borders=OxmlElement("w:tblBorders")
    for side in ("top","left","bottom","right","insideH","insideV"):
        x=OxmlElement("w:"+side)
        for k,v in {"val":"single","sz":"4","color":"D9D9D9"}.items():x.set(qn("w:"+k),v)
        borders.append(x)
    tp.append(borders)
    x=OxmlElement("w:tblLayout");x.set(qn("w:type"),"fixed");tp.append(x)
    for g,w in zip(t._tbl.tblGrid.gridCol_lst,widths):g.set(qn("w:w"),str(w))
    for ri,row in enumerate(t.rows):
        trpr=row._tr.get_or_add_trPr()
        for x in list(trpr):trpr.remove(x)
        trpr.append(OxmlElement("w:cantSplit"))
        if ri==0:trpr.append(OxmlElement("w:tblHeader"))
        for ci,(cell,w) in enumerate(zip(row.cells,widths)):
            cp=cell._tc.get_or_add_tcPr()
            for x in list(cp):cp.remove(x)
            x=OxmlElement("w:tcW");x.set(qn("w:w"),str(w));x.set(qn("w:type"),"dxa");cp.append(x)
            x=OxmlElement("w:shd");x.set(qn("w:val"),"clear");x.set(qn("w:fill"),"EDF0F2" if ri==0 else "FFFFFF");cp.append(x)
            mar=OxmlElement("w:tcMar")
            for side in ("top","left","bottom","right"):
                x=OxmlElement("w:"+side);x.set(qn("w:w"),"85");x.set(qn("w:type"),"dxa");mar.append(x)
            cp.append(mar)
            x=OxmlElement("w:vAlign");x.set(qn("w:val"),"center");cp.append(x)
            for p in cell.paragraphs:
                p.style=doc.styles["Body Text"];pf=p.paragraph_format
                pf.space_before=Pt(0);pf.space_after=Pt(2);pf.line_spacing=1.05;pf.keep_with_next=False
                pf.alignment=(WD_ALIGN_PARAGRAPH.CENTER if kind=="census" or (ci>0 and kind=="numeric") else WD_ALIGN_PARAGRAPH.LEFT)
                for r in p.runs:r.font.size=Pt(10);r.font.bold=(ri==0);r.font.color.rgb=RGBColor(0,0,0)
def table_at(mark,rows,widths,title,kind="generic"):
    anchor=find(mark)._p
    before(anchor,[caption(title)])
    t=doc.add_table(rows=0,cols=len(widths))
    for row in rows:
        for cell,text in zip(t.add_row().cells,row):cell.text=str(text)
    style_table(t,widths,kind);e=t._tbl;e.getparent().remove(e);before(anchor,[e]);anchor.getparent().remove(anchor)

table_at("[[TABLE_TOOL_RETURNS]]",[
 ["Result","Required check","Meaning"],
 ["Identified","Valid ID/IDC derivation and defined normalizations","One functional value on the declared model class"],
 ["Partially bounded","A sound optimization enclosure; matching feasible endpoints for sharpness","A range on the stated observational fibre"],
 ["Non-identified","Compatible models with equal observations and different query values","A carried semantic witness; bounds may also be supplied"],
 ["Clock inconclusive","Consistent constraints but no required strict margin","This shortcut supplies no deletion certificate"],
 ["Input or context failure","Inconsistent constraints, invalid arithmetic domain or unequal context","The proposed result is not accepted for this problem"],
 ],[2150,3650,3848],"Table 6 Typed causal tool results")

table_at("[[TABLE_V3_CHECKS]]",[
 ["Computation","Finite size","Verified result"],
 ["Response fibre and duals",C["response_vertices"][0]+" vertices",f'Effect range [{fills["BOW_LO"]}, {fills["BOW_HI"]}]; both endpoints certified'],
 ["Conditional transformation",C["conditional_cc"][4]+" transformed vertices",f'Sharp selected range [{fills["CC_LO"]}, {fills["CC_HI"]}]'],
 ["Two independent districts",C["product_districts"][0]+" vertex products",f'Joint range [{C["product_districts"][1]}, {C["product_districts"][2]}]'],
 ["Certificate contexts",C["typed_harness"][-1]+" packets","1 sharp packet accepted; 8 context changes and 3 invalid packets rejected"],
 ["Retry cancellation grid",fmt(C["witness_grid"][0])+" points",f'{fmt(C["witness_grid"][1])} zeros; fraction {C["witness_grid"][2]} ≤ {C["witness_grid"][3]}'],
 ["Linear causal memory","Ranks "+C["causal_memory"][0]+" and "+C["causal_memory"][1],f'{fills["MEMORY_BOTH"]} additional coordinates for both effects; {fills["MEMORY_CONTRAST"]} for the contrast'],
 ["Ambiguity radius","One bow fibre",f'Midpoint {C["ambiguity_radius"][2]}; exact worst-case radius {C["ambiguity_radius"][3]}'],
 ["Executable tool interface",V["cli_cases"],"Accepted valid fixture; rejected bad dual and stale scope"],
 ],[2900,2100,4648],"Table 7 New exact certificate and interface checks")

# Compact the existing eight-column census header without changing any values.
for t in doc.tables:
    if t.rows[0].cells[0].text.strip()=="Events":
        for cell,text in zip(t.rows[0].cells,["Events","Graphs","Queries","Identified","Failures","Witnesses","False witnesses","Max types"]):cell.text=text
        style_table(t,[800,900,1300,1300,1000,1300,1700,1348],"census")
    elif t.rows[0].cells[0].text.strip()=="Statement":
        additions=[
            ("11.2 Row-space criterion","A full-support feasible response law; normalization retained","Constancy on a fibre iff the objective is in the equality row space"),
            ("11.3 Product response fibre","Positive attainable law; independent common-latent clique districts","Sharp product-vertex extrema for joint and conditional cells"),
            ("11.4–11.5 Witness search","Same response class; joint query; ideal independent grid draws for probability bound","One-district witness existence and a per-query retry bound"),
            ("11.6–11.9 Bound certificates","Nonempty normalized response polytope; positive denominator for ratios","Checked LP bounds, quantified perturbations and conditional extrema"),
            ("11.10–11.11 Ambiguity and choice","One observational fibre; affine utilities for the LP regret calculation","Scalar minimax radius and robust action decisions"),
            ("12.1 Temporal decoder","Physical-unit errors valid for all queried events; clock theorem assumptions","A strict-order certificate from decoded time ranges"),
            ("12.2 Linear causal memory","Linear summaries and query family; full-support simplex; normalization retained","Minimum extra rank for the chosen causal query family"),
            ("13.2–13.3 Harness and transfer","Authoritative model context; correct primitive verifiers; stated decoder/world error bounds","Relative certificate validity and an explicit answer-error budget")
        ]
        for values in additions:
            for cell,text in zip(t.add_row().cells,values):cell.text=text
        style_table(t,[2300,3600,3748])

# Analytic figure, with exact endpoints read from the new result file.
figdir=ROOT/"figures";figdir.mkdir(exist_ok=True)
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"axes.spines.top":False,"axes.spines.right":False,
                     "text.color":"black","axes.labelcolor":"black"})
fig,axes=plt.subplots(1,2,figsize=(6.45,2.85))
x=np.linspace(0,1,401);lo=float(F(fills["BOW_LO"]));hi=float(F(fills["BOW_HI"]))
axes[0].plot(x,3*x/(1+2*x),color="#244964",lw=1.8)
axes[0].axvspan(lo,hi,color="#dbe7ed",alpha=.7)
axes[0].scatter([lo,hi],[3*lo/(1+2*lo),3*hi/(1+2*hi)],color="#244964",s=25,zorder=5)
axes[0].set(xlabel="Unselected probability F",ylabel="Selected probability T",xlim=(0,1),ylim=(0,1),title="(a) Sharp conditional range")
axes[0].text(.05,.90,"2/3 to 12/13",fontsize=8.5)
pstar=np.sqrt(2)-1;g=lambda t:t/(1+t)-t/2
axes[1].plot(x,g(x),color="#244964",lw=1.8)
axes[1].scatter([0,1],[0,0],color="#5d6469",s=24,zorder=5)
axes[1].scatter([pstar],[g(pstar)],color="#ad6029",s=30,zorder=5)
axes[1].annotate("Interior maximum",(pstar,g(pstar)),(.53,.067),fontsize=8,
                 arrowprops={"arrowstyle":"->","lw":.8,"color":"#5d6469"})
axes[1].set(xlabel="Shared parameter p",ylabel="Difference of two ratios",xlim=(-.02,1.02),ylim=(-.004,.10),
            title="(b) Vertex checks can fail")
for ax in axes:ax.grid(axis="y",alpha=.18);ax.tick_params(labelsize=8)
fig.tight_layout(pad=.7,w_pad=2)
figpath=figdir/"v3_conditional_certificates.png";fig.savefig(figpath,dpi=240,facecolor="white");plt.close(fig)
anchor=find("[[FIGURE_V3]]")._p
p=doc.add_paragraph(style="Body Text");p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.keep_with_next=True
shape=p.add_run().add_picture(str(figpath),width=Inches(6.45))
shape._inline.docPr.set("descr","Analytic selected-outcome curve over the exact bow effect interval, and a ratio-contrast function with zero vertex values and a positive interior maximum.")
e=p._p;e.getparent().remove(e)
before(anchor,[e,caption("Figure 4 Conditional response bounds and a limit of vertex-based comparisons",False)])
anchor.getparent().remove(anchor)

# Add the current verification and executable-interface record.
refs=find("References","Heading 1")
appb=f"""
## B.5 Certificate and harness additions

DoCertificates.cs supplies response-vertex enumeration, the conditional transformation, exact primal and dual checking, the
coefficient-residual example, the memory ranks and the typed packet tests. The --v3 execution mode writes {len(C)} summary records
and certificates.json. The --verify-packet command takes two paths: an authoritative fixture and a separate candidate certificate.
It returns a structured result. The companion JSON schema documents interchange fields; mathematical acceptance uses the C# checks.

validate_v3.py independently generates response types, solves exact bases with SymPy, checks every summary record, re-solves the LPs
with HiGHS and verifies the three real command-line fixture calls. All {len(C)} summary records and {V["cli_cases"]} interface calls pass.
The verifier's {V["tool_packet_cases"]} packet cases include an accepted sharp certificate, eight mismatched contexts, a bad dual,
an infeasible primal and a dimension mismatch.

The original 21-record suite and the nine-record response suite were rerun and independently checked. All inherited summary
and result files match the supplied files byte for byte. A separate fresh temporary project build reproduces the new summary
and certificate JSON byte for byte. replay_v3_results.json records all {len(REPLAY["files"])} comparisons and SHA-256 hashes.
This revision used .NET SDK 8.0.427 and runtime 8.0.33, Python {V["runtime"]["python"]}, NumPy {V["runtime"]["numpy"]},
SciPy {V["runtime"]["scipy"]}, SymPy {V["runtime"]["sympy"]} and y0 0.2.11. Earlier environment versions in B.4 describe that
supplied revision, rather than the current replay.

The source archive includes the V2 Word base, current builder and Markdown, all kernel sources and validators, results,
tool fixtures and reproduction instructions. Installed SDKs and third-party dependency trees are excluded.
"""
before(refs._p,fragment(appb))
for p in doc.paragraphs:
    if p.text.startswith("The verified environment was .NET SDK 8.0.131"):
        p.text=p.text.replace("The verified environment was","The supplied Version 2 reported its environment as")
    if p.style.name=="Heading 2" and p.text=="B.4 Version 2 additions":p.text="B.4 Earlier response computations"

# Merge and alphabetize the bibliography, preserving all existing linked URLs and italics.
new_refs=fragment((ROOT/"references_v3.md").read_text())
entries=[];e=refs._p.getnext()
while e is not None and e.tag!=qn("w:sectPr"):
    nxt=e.getnext()
    if e.tag==qn("w:p") and "".join(e.itertext()).strip():entries.append(e)
    e.getparent().remove(e);e=nxt
entries+=new_refs
def refkey(e):
    s="".join(e.itertext())
    return "".join(c for c in unicodedata.normalize("NFD",s) if unicodedata.category(c)!="Mn").casefold()
for e in sorted(entries,key=refkey):body.insert(len(body)-1,e)
in_refs=False
for p in doc.paragraphs:
    if p.text=="References":in_refs=True;p.paragraph_format.page_break_before=True;continue
    if in_refs:
        p.style=doc.styles["Bibliography"]
        p.paragraph_format.left_indent=Inches(.22);p.paragraph_format.first_line_indent=Inches(-.22)
        p.paragraph_format.line_spacing=1.02;p.paragraph_format.space_after=Pt(5)
        p.paragraph_format.keep_together=True
    if re.match(r"^(Definition|Theorem|Proposition|Lemma|Corollary) \d+\.\d+",p.text):p.paragraph_format.keep_with_next=True
    if p._p.find(qn("m:oMathPara")) is not None:
        p.paragraph_format.keep_together=True
        p.paragraph_format.space_before=Pt(4);p.paragraph_format.space_after=Pt(7)
    if p._p.getprevious() is not None and p._p.getprevious().tag==qn("w:tbl"):p.paragraph_format.space_before=Pt(6)
    if p.style.name.startswith(("Title","Subtitle","Heading")):
        for r in p.runs:r.font.color.rgb=RGBColor(0,0,0);r.font.underline=False
for st in doc.styles:
    for x in list(st.element.iter(qn("w:pBdr"))):x.getparent().remove(x)
    for fonts in st.element.iter(qn("w:rFonts")):
        for a in list(fonts.attrib):
            if etree.QName(a).localname.lower().endswith("theme"):del fonts.attrib[a]
for name in ("Title","Subtitle","Heading 1","Heading 2","Heading 3"):
    doc.styles[name].font.name="Times New Roman";doc.styles[name].font.color.rgb=RGBColor(0,0,0)
    for c in doc.styles[name].element.iter(qn("w:color")):c.attrib.pop(qn("w:themeColor"),None)
    for x in list(doc.styles[name].element.findall(".//"+qn("w:rPr")+"/"+qn("w:spacing"))):x.getparent().remove(x)
for p in doc.paragraphs:
    if p.style.name=="Title":
        for x in list(p._p.iter(qn("w:pBdr"))):x.getparent().remove(x)
for sec in doc.sections:
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.left_margin=sec.right_margin=Inches(.9);sec.top_margin=sec.bottom_margin=Inches(.72)

PPR=("pStyle keepNext keepLines pageBreakBefore framePr widowControl numPr suppressLineNumbers pBdr shd tabs suppressAutoHyphens "
     "kinsoku wordWrap overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi adjustRightInd snapToGrid spacing ind "
     "contextualSpacing mirrorIndents suppressOverlap jc textDirection textAlignment textboxTightWrap outlineLvl divId "
     "cnfStyle rPr sectPr pPrChange").split()
def reorder(parent,order):
    for e in sorted(list(parent),key=lambda e:order.index(etree.QName(e).localname) if etree.QName(e).localname in order else 99):parent.append(e)
for x in body.iter(qn("w:pPr")):reorder(x,PPR)
for x in body.iter(f"{{{M}}}dPr"):reorder(x,["begChr","sepChr","endChr","grow","shp","ctrlPr"])
for x in body.iter(f"{{{M}}}mcPr"):reorder(x,["count","mcJc"])
for x in body.iter(f"{{{M}}}rPr"):
    if x.find(f"{{{M}}}nor") is not None:
        for e in x.findall(f"{{{M}}}sty")+x.findall(f"{{{M}}}scr"):x.remove(e)
    reorder(x,["lit","nor","scr","sty","brk","aln"])
for r in body.iter(f"{{{M}}}r"):
    if re.fullmatch(r"\(\d+\.\d+\)",r.findtext(f"{{{M}}}t") or ""):
        pr=r.find(f"{{{M}}}rPr")
        if pr is None:pr=etree.Element(f"{{{M}}}rPr");r.insert(0,pr)
        for x in list(pr):pr.remove(x)
        st=etree.SubElement(pr,f"{{{M}}}sty");st.set(f"{{{M}}}val","p")
doc.core_properties.title="Autoregressive Do Calculus for Causal Agents"
doc.core_properties.subject="Version 3 with response certificates neuroscience hypotheses and agent harness design"
doc.core_properties.author="Debi Prasad Ghosh"
doc.core_properties.modified=datetime(2026,10,30,tzinfo=timezone.utc)
doc.save(OUT)
(ROOT/"pandoc_v3.log").write_text("\n".join(warnings))
assert not warnings,warnings
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    for n in z.namelist():
        if n.endswith(".xml"):etree.fromstring(z.read(n))
    x=etree.fromstring(z.read("word/document.xml"))
    t=" ".join(x.itertext())
    assert not re.search(r"\{\{[A-Z_]+\}\}|\[\[(TABLE|FIGURE)_|\bgenui\b",t)
    media={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith("word/media/")}
with zipfile.ZipFile(BASE) as z:
    old_media={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith("word/media/")}
assert old_media<=media
inventory=re.findall(r"^(Definition|Theorem|Proposition|Lemma|Corollary) (\d+\.\d+) \(", "\n".join(p.text for p in doc.paragraphs),re.M)
assert len(inventory)==len(set(inventory))
audit={"zip_and_xml_valid":True,"old_images_preserved":len(old_media),"native_equations":len(x.findall(".//"+qn("m:oMath"))),
       "display_equations":len(x.findall(".//"+qn("m:oMathPara"))),"tables":len(doc.tables),
       "formal_statements":[f"{a} {b}" for a,b in inventory],"filled_values":fills}
(ROOT/"document_v3_audit.json").write_text(json.dumps(audit,indent=2)+"\n")
print(json.dumps({"path":str(OUT),"formal_statements":len(inventory),"native_equations":audit["native_equations"],"tables":len(doc.tables)},indent=2))
