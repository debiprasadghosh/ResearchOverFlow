"""Exact finite reference calculations for ADC sequential evidence. No random experiments."""
from __future__ import annotations
from dataclasses import dataclass, replace
from fractions import Fraction as Q
from itertools import combinations, product
from pathlib import Path
import hashlib, json, math, sys

Vector = tuple[Q, ...]
Matrix = tuple[Vector, ...]
def vec(x): return tuple(map(Q, x))
def mat(x): return tuple(map(vec, x))
def dot(a,b): return sum((x*y for x,y in zip(a,b)), Q(0))
def neg(a): return tuple(-x for x in a)

def reduce_rows(a, b, n):
    z=[list(r)+[v] for r,v in zip(a,b)]; row=0
    for col in range(n):
        pivot=next((i for i in range(row,len(z)) if z[i][col]),None)
        if pivot is None: continue
        z[row],z[pivot]=z[pivot],z[row]
        scale=z[row][col];z[row]=[x/scale for x in z[row]]
        for i in range(len(z)):
            if i!=row and z[i][col]:
                scale=z[i][col];z[i]=[x-scale*y for x,y in zip(z[i],z[row])]
        row+=1
        if row==len(z): break
    if any(all(x==0 for x in r[:n]) and r[n]!=0 for r in z):return None
    return mat(r[:n] for r in z[:row]),vec(r[n] for r in z[:row])

def rank(rows):
    rows=mat(rows)
    if not rows:return 0
    return len(reduce_rows(rows,[Q(0)]*len(rows),len(rows[0]))[0])

@dataclass(frozen=True)
class Polytope:
    n:int
    equalities:Matrix
    rhs:Vector
    inequalities:Matrix
    upper:Vector

    @staticmethod
    def simplex(n):
        g=mat([-int(i==j) for j in range(n)] for i in range(n))
        return Polytope(n,(vec([1]*n),),vec([1]),g,vec([0]*n))

    def exact(self,rows,rhs):
        return replace(self,equalities=self.equalities+mat(rows),rhs=self.rhs+vec(rhs))

    def slab(self,rows,lower,upper):
        rows=mat(rows);lower=vec(lower);upper=vec(upper)
        assert len(rows)==len(lower)==len(upper)
        assert all(len(r)==self.n for r in rows)
        assert all(a<=b for a,b in zip(lower,upper))
        return replace(self,inequalities=self.inequalities+rows+tuple(map(neg,rows)),
                       upper=self.upper+upper+neg(lower))

    def contains(self,q):
        return len(q)==self.n and all(dot(a,q)==b for a,b in zip(self.equalities,self.rhs)) and all(dot(a,q)<=b for a,b in zip(self.inequalities,self.upper))

    def vertices(self):
        reduced=reduce_rows(self.equalities,self.rhs,self.n)
        if reduced is None:return ()
        a,b=reduced;r=len(a);out=set()
        for inds in combinations(range(len(self.inequalities)),self.n-r):
            aa=a+tuple(self.inequalities[i] for i in inds)
            bb=b+tuple(self.upper[i] for i in inds)
            solution=reduce_rows(aa,bb,self.n)
            if solution is not None and len(solution[0])==self.n:
                q=solution[1]
                if self.contains(q):out.add(q)
        return tuple(sorted(out))

    def bounds(self,c):
        vertices=self.vertices()
        if not vertices:raise ValueError('InconsistentEvidence')
        values=[dot(c,q) for q in vertices]
        return min(values),max(values)

    def record(self,c):
        lo,hi=self.bounds(c)
        return dict(n=self.n,equalities=self.equalities,rhs=self.rhs,
                    inequalities=self.inequalities,upper=self.upper,c=vec(c),lo=lo,hi=hi)

def pair_problem(k,rows,h):
    n=k.n;rows=mat(rows);h=vec(h);zero=vec([0]*n)
    equalities=tuple(r+zero for r in k.equalities)+tuple(zero+r for r in k.equalities)
    inequalities=tuple(r+zero for r in k.inequalities)+tuple(zero+r for r in k.inequalities)
    p=Polytope(2*n,equalities,k.rhs+k.rhs,inequalities,k.upper+k.upper)
    return p.slab(tuple(r+neg(r) for r in rows),neg(vec(2*x for x in h)),vec(2*x for x in h))

@dataclass(frozen=True)
class Context:
    graph:str
    model_class:str
    decoder:str
    unit:str
    scope:str
    query:str

@dataclass(frozen=True)
class Ledger:
    context:Context
    target:Vector
    channels:tuple[tuple[str,Matrix],...]
    polytope:Polytope
    version:int=0
    parent_digest:str=''

    @property
    def digest(self):
        payload=encode(dict(context=self.context.__dict__,target=self.target,channels=self.channels,
                            polytope=self.polytope.__dict__,version=self.version,parent=self.parent_digest))
        return hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()

    def append(self,regime,lower,upper):
        rows=dict(self.channels)[regime]
        if not all(0<=Q(a)<=Q(b)<=1 for a,b in zip(lower,upper)):raise ValueError('ReportDomainFailure')
        return replace(self,polytope=self.polytope.slab(rows,lower,upper),version=self.version+1,parent_digest=self.digest)

def verify_refinement(old,new):
    if (old.context,old.target,old.channels)!=(new.context,new.target,new.channels):return 'ContextMismatch'
    if new.version!=old.version+1 or new.parent_digest!=old.digest:return 'ParentMismatch'
    a,b=old.polytope,new.polytope
    if a.n!=b.n or b.equalities[:len(a.equalities)]!=a.equalities or b.rhs[:len(a.rhs)]!=a.rhs:return 'ConstraintMismatch'
    if b.inequalities[:len(a.inequalities)]!=a.inequalities or b.upper[:len(a.upper)]!=a.upper:return 'ConstraintMismatch'
    if not b.vertices():return 'InconsistentEvidence'
    return 'AcceptedRefinement'

def encode(x):
    if isinstance(x,Q):return str(x)
    if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [encode(y) for y in x]
    return x

def run(out):
    root=Path(__file__).resolve().parent; out=Path(out);out.mkdir(exist_ok=True,parents=True)
    data=json.loads((root/'out_v3/certificates.json').read_text())
    a,p,c=mat(data['matrix']),vec(data['p']),vec(data['c'])
    qstar=vec(data['baseQ']);centre=dot(c,qstar)
    bow=Polytope.simplex(8).exact(a,p)
    records={};lp_cases=[]
    def bounds(label,k,c):
        d=k.record(c);lp_cases.append(dict(name=label,**d));return d['lo'],d['hi']
    nested=[bow,bow.slab([c],[centre-Q(1,20)],[centre+Q(1,20)]),
            bow.slab([c],[centre-Q(1,50)],[centre+Q(1,50)]),bow.exact([c],[centre])]
    records['nested_bow']=tuple(v for i,k in enumerate(nested) for v in bounds('nested_'+str(i),k,c))
    old_low,old_high=vec(data['lowerPrimal']),vec(data['upperPrimal'])
    records['old_endpoints']=(int(bow.contains(old_low)),int(bow.contains(old_high)),
                              int(nested[1].contains(old_low)),int(nested[1].contains(old_high)))
    regret=[];half=vec([Q(1,2)]*8);diff=tuple(x-y for x,y in zip(c,half))
    for i,k in enumerate(nested):
        lo,hi=bounds('regret_'+str(i),k,diff);regret.extend((max(Q(0),hi),max(Q(0),-lo)))
    records['monotone_regret']=tuple(regret)
    context=Context('bow','clique-common-latent','event-v1','probability','world','P_Y1_do_X1')
    old=Ledger(context,c,(('do_X1',(c,)),),bow);new=old.append('do_X1',[Q(11,20)],[Q(13,20)])
    candidates=[new,
        replace(new,context=replace(context,decoder='event-v2')),
        replace(new,target=neg(c)),
        replace(new,parent_digest='0'*64),
        replace(new,version=3),
        replace(new,polytope=replace(new.polytope,equalities=new.polytope.equalities[1:],rhs=new.polytope.rhs[1:])),
        replace(new,polytope=replace(new.polytope,upper=vec([-1])+new.polytope.upper[1:])),
        old.append('do_X1',[Q(0)],[Q(1,10)])]
    states=tuple(verify_refinement(old,x) for x in candidates)
    records['ledger_contracts']=states
    k=Polytope.simplex(3);target=vec([1,0,0]);one=mat([[1,1,0]]);two=mat([[0,1,0]])
    width=[]
    for label,m in [('none',()),('one',one),('two',two),('both',one+two)]:
        pair=pair_problem(k,m,[0]*len(m));dc=target+neg(target)
        lo,hi=bounds('width_'+label,pair,dc);width.append(hi)
    records['experiment_width']=tuple(width)
    epsilons=vec(['0','1/100','1/20','1/8','1/4','1/2']);risks=[];direct=[]
    for i,e in enumerate(epsilons):
        _,hi=bounds('recovery_'+str(i),pair_problem(k,one+two,[e,e]),target+neg(target));risks.append(hi/2)
        _,hi=bounds('direct_'+str(i),pair_problem(k,[target],[e]),target+neg(target));direct.append(hi/2)
    records['noisy_recovery']=tuple(risks)
    records['direct_recovery']=tuple(direct)
    c0=vec((j>>1)&1 for j in range(8));contrast=vec(x-y for x,y in zip(c,c0))
    ar=rank(a);cr=rank(a+(c0,c));newrank=rank(a+(contrast,))
    records['memory_release']=(ar,cr-ar,newrank,rank(a+(contrast,c0,c))-newrank,rank(a+(contrast,contrast))-newrank)
    gains=tuple(int(rank((vec([1,1,1]),)+m+(target,))==rank((vec([1,1,1]),)+m)) for m in ((),one,two,one+two))
    records['rank_synergy']=gains
    particular=[]
    for label,m,b in [('one',one,[Q(2,3)]),('two',two,[Q(1,3)]),('both',one+two,[Q(2,3),Q(1,3)])]:
        lo,hi=bounds('particular_'+label,k.exact(m,b),target);particular.append(hi-lo)
    records['particular_reports']=tuple(particular)
    delta=Q(1,20);budget=sum((delta/Q(n*(n+1)) for n in range(1,1001)),Q(0))
    records['confidence_budget']=(budget,delta-budget,delta)
    radii={str(n):math.sqrt(math.log(2*4*n*(n+1)/float(delta))/(2*n)) for n in (1,10,100,1000)}
    # Enumerate every perfect intervention, with fresh exogenous bits in each unit.
    regimes=[]
    for xs in (None,0,1):
        for ys in (None,0,1):
            laws=[]
            for model in (0,1):
                law=[Q(0)]*4
                for ux,uy in product((0,1),repeat=2):
                    x=ux if xs is None else xs
                    y=(uy if model==0 else uy^x) if ys is None else ys
                    law[x+2*y]+=Q(1,4)
                laws.append(tuple(law))
            regimes.append(dict(x=xs,y=ys,laws=laws))
    records['single_world_gap']=(len(regimes),sum(x['laws'][0]==x['laws'][1] for x in regimes),Q(1,4),Q(1),Q(0))
    # Fixed target and semantic context are explicitly bound into each snapshot digest.
    records['snapshot_digest']=(int(old.digest!=new.digest),int(old.digest==old.digest),int(verify_refinement(old,new)=='AcceptedRefinement'))
    expected={
        'nested_bow':vec(['2/5','4/5','11/20','13/20','29/50','31/50','3/5','3/5']),
        'old_endpoints':(1,1,0,0),'monotone_regret':vec(['3/10','1/10','3/20','0','3/25','0','1/10','0']),
        'ledger_contracts':('AcceptedRefinement','ContextMismatch','ContextMismatch','ParentMismatch','ParentMismatch','ConstraintMismatch','ConstraintMismatch','InconsistentEvidence'),
        'experiment_width':vec([1,1,1,0]),'noisy_recovery':tuple(min(2*x,Q(1,2)) for x in epsilons),
        'direct_recovery':tuple(min(x,Q(1,2)) for x in epsilons),'memory_release':(4,2,5,1,0),
        'rank_synergy':(0,0,0,1),'particular_reports':vec(['2/3','2/3','0']),
        'confidence_budget':vec(['50/1001','1/20020','1/20']),'single_world_gap':(9,9,Q(1,4),Q(1),Q(0)),
        'snapshot_digest':(1,1,1)}
    assert records==expected,(records,expected)
    result=dict(records=records,record_count=len(records),lp_cases=lp_cases,
                radii=radii,epsilon_grid=epsilons,regime_tables=regimes,
                rank_matrices=dict(observational=a,c0=c0,c1=c,contrast=contrast),
                snapshot_digests=(old.digest,new.digest),arithmetic='exact Fraction; radii alone use binary64')
    (out/'sequential_results.json').write_text(json.dumps(encode(result),indent=2)+'\n')
    print('\n'.join(key+'\t'+' '.join(map(str,value)) for key,value in records.items()))

if __name__=='__main__':run(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parent/'out_v4')
