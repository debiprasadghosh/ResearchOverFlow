# 14 Sequential evidence and causal memory

The preceding sections analyse a declared observational dataset. An agent also needs a rule for acquiring evidence and updating its answer. Three operations must be distinguished: learning another probability in the same causal model, changing that model, and changing the question. Only the first operation necessarily shrinks the old uncertainty set. This section makes that distinction precise, then connects experimental choice to the amount and precision of causal information that a memory must retain.

The optimization arguments are finite applications of linear programming and optimal recovery. The concentration argument uses a conservative union-bound construction rather than a new confidence-sequence method. Established work already connects recovery error to indistinguishability (Donoho, 1994) and provides substantially sharper sequential confidence methods (Howard et al., 2021). The contribution here is their explicit placement inside ADC's response model and evidence contract.

## 14.1 One response model across regimes

Fix a finite response vector $q$ in a known nonempty compact polytope $K_0$ contained in a probability simplex. A regime may be an observation channel or a specified perfect intervention followed by an observation. Its probability vector is $B_e q$, with $B_e$ fixed before the report is read. This linearity holds for one free response block when all other district factors are known and fixed, or for a declared single common-latent response model. It is not obtained by replacing several independent district laws with one unrestricted joint law.

For example, Section 11's bow has one response block, and both action probabilities are linear functionals of that block. With several unknown independent blocks, experimental probabilities are generally multilinear, and the feasible set need not be a polytope. The linear results below do not silently extend to that setting. Likewise, uncertainty in factors used to construct $B_e$ needs a justified outer model or the coefficient-residual analysis of Proposition 11.7.

**Definition 14.1 (an evidence ledger).** A ledger records the fixed response model, regime maps, units, and a sequence of reports $(e_s,\ell_s,u_s)$. Every report constrains the same vector $q$. The set after $t$ reports is

$$
K_t=K_0\cap\bigcap_{s\leq t}
\{q:\ell_s\leq B_{e_s}q\leq u_s\}.
\qquad\text{(14.1)}
$$

An exact report has equal endpoints. Repeated measurements intersect their constraints; they do not create independent copies of $q$. A report has probability units, a date report has clock units, and a latent-state residual has its declared coordinate units. Only quantities with the same meaning and units may share a row or bound. Changes of graph, latent class, decoder, intervention mechanism or population require a separately justified model transition.

**Proposition 14.2 (monotone refinement).** Suppose every $K_t$ is nonempty. For a fixed linear query $c^\mathsf Tq$, its sharp lower bounds are nondecreasing and its sharp upper bounds are nonincreasing. For a fixed finite family of affine utilities, each action's worst-case regret and the minimum worst-case regret are nonincreasing. An action optimal on $K_t$ remains optimal on every later set.

*Proof.* Each new constraint gives $K_{t+1}\subseteq K_t$. A minimum over a subset cannot decrease, and a maximum cannot increase. Apply this to the query and to every utility difference in (11.9). The minimum over actions of their nonincreasing regret values is nonincreasing. An action with zero regret retains zero regret because regret is nonnegative. ∎

The proposition compares exact feasible sets, rather than estimates obtained by refitting unrelated models. If the true response law is $q^\star$ and every report contains $B_e q^\star$, then $q^\star\in K_t$ for all $t$. If an intersection is empty, the ledger is inconsistent. This can result from a false structural assumption, a population change, a report error or a statistical coverage failure. It is not an identified causal answer.

**Corollary 14.3 (reuse after a certified refinement).** Suppose a previously checked outer bound concerns the same target and every old model constraint is retained. That bound remains an outer bound after adding evidence. A previous sharpness certificate remains sharp only if its endpoint models also satisfy the new constraints.

*Proof.* The first statement follows from set inclusion. A previous endpoint remains attainable exactly when it is still feasible. In an inequality LP, old dual multipliers can be extended by zero multipliers on the new rows; the same objective bound follows. ∎

Thus mathematical reuse can be broader than unconditional cache reuse. Section 13's context check remains the default. A refinement path may instead carry an explicit proof that the response coordinates, target and old constraints are unchanged. An arbitrary data-version change supplies no such proof.

## 14.2 Statistical reports at an adaptive stopping time

Pointwise confidence intervals do not automatically remain valid when an agent repeatedly checks them and decides when to stop. A simple construction suffices to demonstrate the missing contract. Suppose a finite declared menu has $M$ probability coordinates in total. Each regime has a fresh independent identically distributed stream of units from the same fixed response model. The policy chooses the next regime using only previously observed outcomes. Dependence among different coordinates of one unit is allowed.

For a coordinate after its regime's $n$ visits, let $\widehat b_{j,n}$ be the empirical average of its $[0,1]$ indicator and choose $0<\delta<1$. Put

$$
\begin{aligned}
r_n&=\sqrt{\frac{\log\{2Mn(n+1)/\delta\}}{2n}},\\
I_{j,n}&=[\widehat b_{j,n}-r_n,\widehat b_{j,n}+r_n]\cap[0,1].
\end{aligned}
\qquad\text{(14.2)}
$$

The implementation intersects all intervals issued so far for each coordinate. Counts are visits to that coordinate's regime, not global token counts or inference layers.

**Theorem 14.4 (simultaneous containment under adaptive allocation).** Under the stream and policy assumptions above, the intervals in (14.2) contain every declared coordinate at every visit with probability at least $1-\delta$. If $q^\star\in K_0$, intersecting their constraints gives

$$
\Pr\{q^\star\in K_t\ \text{for every }t\}\geq1-\delta.
\qquad\text{(14.3)}
$$

Consequently any sharp bounds computed from the ledger at an adaptively selected finite stopping time contain the corresponding fixed-model query value on the same event.

*Proof.* Regard each regime's fresh stream as generated before the policy begins, with future outcomes unavailable to the policy. For a fixed coordinate and visit count, Hoeffding's inequality (1963) gives failure probability at most $2\exp(-2nr_n^2)=\delta/\{Mn(n+1)\}$. Union over all coordinates and counts uses $\sum_{n\geq1}1/\{n(n+1)\}=1$. Adaptive allocation reveals prefixes of these streams and cannot invalidate their simultaneous event. On that event every true linear probability satisfies every retained constraint. Bounds at a stopping time therefore inherit containment. ∎

This is a conservative confidence sequence obtained by error spending. Howard et al. (2021) develop stronger general constructions; the elementary formula is used here because its entire coverage argument is visible. The theorem does not cover outcome-dependent selection within a unit, unrecorded nonstationarity, an unlimited newly invented regime menu, or incorrect intervention semantics. A claimed confidence level also requires certified outward evaluation of the logarithm and square root, or a valid conservative radius. The reference calculations below check fixed numerical radii, without claiming directed transcendental rounding.

If the initial set is also estimated with failure probability at most $\delta_0$, the combined containment failure is at most $\delta+\delta_0$. No independence between these coverage events is required.

Repeatedly intersecting point estimates would give artificial precision. Repeatedly intersecting valid intervals gives precision on the event that they jointly cover the same response law. This is the distinction needed when an AI harness turns a sequence of tool outputs into evidence.

## 14.3 Choosing an experiment by the ambiguity it leaves

Write $W(K;c)=\max_{q\in K}c^\mathsf Tq-\min_{q\in K}c^\mathsf Tq$. Suppose one allowed experiment returns an exact probability vector $Bq$, an idealization distinct from one sampled outcome. Its worst possible remaining query width is the maximum width of a fibre $K\cap\{Bq=z\}$ over attainable reports $z$.

**Theorem 14.5 (a two-model experiment programme).** For a nonempty compact response polytope $K$, that worst remaining width is the value of the LP

$$
\mathcal W(B;K,c)=
\max_{q,q'\in K}\{c^\mathsf T(q-q'):B(q-q')=0\}.
\qquad\text{(14.4)}
$$

*Proof.* Two models lie in the same reported fibre exactly when their $B$ images agree. In any fibre, maximizing their query difference gives its width. Conversely every feasible pair supplies an attainable common report. Compactness gives both maxima, proving equality. ∎

This turns one-step experimental design into a finite comparison: choose an admissible $B$ with the smallest value of (14.4), accounting separately for its cost. It does not learn which channels are physically available, and it does not prove that a one-step choice is optimal for a multistep budget. Sampling error must also be included before an actual experiment is planned.

For a bounded report $z=Bq+e$ with $|e_j|\leq h_j$, two models can produce a common report exactly when $|B(q-q')|\leq2h$. Replacing the equality in (14.4) by those inequalities therefore gives the sharp worst remaining width for this coordinatewise bounded-report channel. If reports additionally must satisfy other constraints, such as a particular multinomial table, the programme is an outer bound until those constraints are included.

## 14.4 The precision cost of causal memory

Theorem 12.2 determines the number of exact linear coordinates needed for a query family. It does not describe amplification of errors in those coordinates. A pair of nearly cancelling measurements can have adequate rank and poor numerical precision. The following result provides the missing quantitative statement for a scalar linear query.

**Theorem 14.6 (bounded-noise causal recovery).** Let $K$ be a nonempty compact polytope, let a memory retain $z=Mq+e$ with $|e|\leq h$ and $h\geq0$, and let the target be $c^\mathsf Tq$. Define minimax error over all deterministic decoders $f$ by $R^*=\inf_f\sup_{q\in K,\,|e|\leq h}|f(Mq+e)-c^\mathsf Tq|$. Then

$$
\begin{aligned}
R^*&=\frac12\max_{q,q'\in K}
\{c^\mathsf T(q-q'):|M(q-q')|\leq2h\}\\
R^*&=\min_{\lambda}\{h^\mathsf T|\lambda|
+\tfrac12W(K;c-M^\mathsf T\lambda)\}.
\end{aligned}
\qquad\text{(14.5)}
$$

An optimal affine decoder is $f(z)=\lambda^\mathsf Tz+\alpha$, where $\lambda$ minimizes the last line and $\alpha$ is the midpoint of the range of $(c-M^\mathsf T\lambda)^\mathsf Tq$ on $K$.

*Proof.* Any pair in the first programme admits the common report $z=\{Mq+Mq'\}/2$ with allowed errors. Every decoder then makes error at least half their target difference on one model. This proves the lower bound.

For any $\lambda$, the residual target has a range on $K$ of width $W(K;c-M^\mathsf T\lambda)$. Subtracting its midpoint bounds its magnitude by half that width. Memory noise contributes at most $h^\mathsf T|\lambda|$, giving the upper bound and the stated affine decoder.

Finally dualize the two inequalities $\pm M(q-q')\leq2h$ in the first programme. Their nonnegative multipliers have difference $\lambda$. Maximizing over the two copies of $K$ gives $W(K;c-M^\mathsf T\lambda)$; the least sum of the multipliers with that difference is $|\lambda|$. Linear-programming strong duality gives equality of the displayed values and a minimizing multiplier. ∎

This is a finite deterministic optimal-recovery result, related to the broader estimation and recovery framework of Donoho (1994). Its exact affine minimax conclusion is not a claim about arbitrary stochastic noise, nonlinear conditional queries or a trained neural decoder. If $K$ is the whole probability simplex, the residual width is simply the largest minus smallest entry of $c-M^\mathsf T\lambda$.

The formula separates two losses. The residual width is information omitted by the memory. The term $h^\mathsf T|\lambda|$ is sensitivity to its stored precision. At zero noise and with a full-support response simplex, zero error is equivalent to the row-space condition of Theorem 12.2, including its normalization coordinate. Adequate rank alone gives no small nonzero-noise guarantee.

An exact three-type example makes the distinction explicit. Let $K=\Delta_3$, $c=(1,0,0)^\mathsf T$, and retain the two channels $M_1q=q_1+q_2$ and $M_2q=q_2$. Their difference recovers $q_1$. If each channel has error at most $\varepsilon$, then

$$
R^*(\varepsilon)=\min\{2\varepsilon,1/2\}.
\qquad\text{(14.6)}
$$

The decoder $z_1-z_2$ proves the first upper bound, while the constant $1/2$ proves the second. For $\varepsilon\leq1/4$, the feasible difference $(4\varepsilon,-2\varepsilon,-2\varepsilon)$ gives the matching lower bound in (14.5). For larger errors, the pair difference $(1,-1/2,-1/2)$ gives the bound $1/2$. These differences lie in $\Delta_3-\Delta_3$. At $\varepsilon=1/20$, exact rank is sufficient but the unavoidable worst-case error is {{RECOVERY_ERROR}}.

## 14.5 Evidence can release memory but can require joint acquisition

**Corollary 14.7 (release of exact query memory).** Retain exact measurements $A_tq$, with normalization in their row space, for a fixed linear query family $Cq$. On the full response simplex the least additional linear memory is

$$
k_t=\operatorname{rank}\!\begin{bmatrix}A_t\\C\end{bmatrix}
-\operatorname{rank}A_t.
\qquad\text{(14.7)}
$$

Appending exact measurement rows cannot increase $k_t$. An earlier query memory can be replaced by a basis of query rows modulo the new measurement row space, provided the new exact measurements remain available.

*Proof.* Apply Theorem 12.2. Equivalently, $k_t$ is the dimension of the query row space minus its intersection with the retained measurement row space. That intersection can only grow as rows are appended. The old memory recovers $Cq$, so its required new basis coordinates can be computed before the old representation is discarded. ∎

Interval measurements need Theorem 14.6 rather than this exact-rank release rule. Newly required tasks can also enlarge the query family. In the bow, observation has rank {{MEMORY_RANK}} and preserving both action probabilities needs {{MEMORY_BEFORE}} additional coordinates. An exact measurement of their contrast reduces this to {{MEMORY_AFTER}}, while the contrast itself needs none. This is an information statement about retained measurements, not a neural capacity measurement.

**Proposition 14.8 (synergistic evidence).** Query-rank gain from allowed measurement sets need not be submodular, and one-step worst-case-width improvement can vanish for every individual measurement even when a pair identifies the query.

*Proof.* On $\Delta_3$, retain normalization and target $q_1$. Allow the two rows $B_1=(1,1,0)$ and $B_2=(0,1,0)$. Neither row with normalization spans $(1,0,0)$, but together their difference does. Query-rank gain is therefore $0,0,0,1$ on $\varnothing,\{1\},\{2\},\{1,2\}$, violating submodularity. Each single measurement has worst remaining width $1$: $B_1$ cannot distinguish $(1,0,0)$ from $(0,1,0)$, and $B_2$ cannot distinguish $(1,0,0)$ from $(0,0,1)$. Together they give width zero. ∎

These rows are legitimate observation channels for a three-category source. Their admissibility as particular interventions in an application requires a regime model. The example does not refute submodularity of other objectives such as selected log-determinant criteria. It shows that ADC's query-specific criterion needs its own scheduling analysis; a zero one-step gain does not justify stopping acquisition.

## 14.6 What even complete single-world data can leave unresolved

**Proposition 14.9 (a cross-world remainder).** Equality of every perfect-intervention distribution does not imply equality of every cross-world query, even for a positive binary model on the allowed graph $X\to Y$.

*Proof.* Let $U_X,U_Y$ be independent fair bits. In model A, set $X=U_X$ and $Y=U_Y$. In model B, set $X=U_X$ and $Y=U_Y\mathbin{\mathrm{xor}}X$. Both observational joint laws are uniform. Under $do(X=x)$, $Y$ is fair in both models. Under $do(Y=y)$, $X$ is fair in both. Joint clamps agree as well. These exhaust the perfect-intervention regimes. Yet $P(Y_0=Y_1)$ is $1$ in model A and $0$ in model B. ∎

The example is an elementary instance of the established distinction between experimental and counterfactual identification (Shpitser & Pearl, 2007). A known fixed response model can compute either quantity; learning its single-world regime laws need not recover the cross-input coupling. A memory proposal must therefore specify which family it promises to preserve. Storing causal effects is not automatically sufficient for individual counterfactual comparisons.

## 14.7 A stopping rule and an evidence-aware harness

**Corollary 14.10 (a valid decision at an adaptive stop).** On the simultaneous-containment event of Theorem 14.4, if an action $a_t$ has certified regret at most $\eta$ over nonempty $K_t$, its true fixed-model regret is at most $\eta$. This remains true at any finite adaptively chosen stopping time.

*Proof.* The true response law is one member of $K_t$. Its regret is bounded by the maximum used in the certificate. The containment event holds simultaneously in time, so choosing when to apply the statement does not change it. ∎

The harness can thus return a certified decision before it identifies every effect. Conversely, a small observed prediction error or a stable generated answer supplies no regret certificate. Intervention costs, feasibility and any utility model belong in the authoritative problem.

The additional reference module uses immutable records for a response polytope, reports and ledger transitions. It checks a semantic context separately from the evidence version. Its refinement verifier requires the old equality and inequality rows to be exact prefixes of the new constraints. This is a deliberately sufficient certificate of inclusion; other valid inclusions may require a more general proof. A target change, deleted row, changed old row, inconsistent report or wrong parent version is rejected. Content digests bind the stored rows and versions; they do not authenticate the truth of a report or confer experimental authority.

The C# bound verifier of Section 13 is retained unchanged. The new Python prototype demonstrates the refinement and design calculations; no new C# execution is claimed in this revision. Exact Fraction elimination and active-constraint enumeration are checked independently against HiGHS. The {{NEW_CHECKS}} new records include nested bow bounds, endpoint invalidation, context and prefix failures, the two-model width programmes, memory-rank release, noisy recovery, and all single-world regimes of the cross-world example. They are deterministic mathematical examples, rather than trained-agent, animal or human experiments.

[[TABLE_V4_CHECKS]]

[[FIGURE_V4]]

## 14.8 Neuroscience and consolidation consequences

The functional interpretation now has an explicit acquisition component. Acting-versus-observing sensitivity motivates distinct regime labels; neural sequence generation motivates candidate evaluations; consolidation concerns which query information survives. Equations (14.5) and (14.7) separate information content from retention precision. Two memories can have equal rank and different noise amplification, or preserve different intervention contrasts with the same number of coordinates.

These are proposed engineering roles for ASE's representations. The hippocampal and cortical findings reviewed in Section 12 do not establish a neural implementation of the LPs, an independent-stream sampling model or a row-space code. A biological account must also distinguish within-model uncertainty reduction from learning a new mechanism or changing the population. The latter changes $K_0$ and its semantics rather than merely appending a report.

**Hypothesis H3 on acquisition and retention.** With observations, task rewards and learned regime meanings held fixed, making two complementary evidence channels available should change acquisition and later retention in a query-dependent way, including cases with little one-channel benefit. A computational comparison can fix the channel menu, noise budget and query family, then compare one-step width choice, paired-channel lookahead and a prediction-error policy. H3 is contradicted if the prespecified query-dependent advantage fails under matched costs and verified channel learning. A neural or behavioural interpretation additionally requires those controls; Proposition 14.8 alone predicts no animal behaviour.

The three hypotheses remain empirical. The mathematical contribution is narrower and complete on its stated finite domain: an evidence ledger that keeps one response law, valid stopping guarantees under explicit sampling premises, a query-directed experimental LP, and a sharp precision criterion for causal memory.
