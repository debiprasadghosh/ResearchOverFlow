---
title: "Fusion and Constraints"
subtitle: "Combining local laws in Autoregressive Sheaf Evolution. Part V: products of experts, marginal extension, covariance intersection and feasibility"
author:
  - "Debi Prasad Ghosh"
  - "Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India"
date: "Defensible Intelligence series · Autoregressive Sheaf Evolution, Part V · 21 October 2026 · “Respect science. Import emotion.”"
abstract: |
  Parts I to IV of Autoregressive Sheaf Evolution (ASE) built a layer, a stack and the targets a run estimates. This paper, Part V of the book, combines local laws and imposes constraints. Three fusion operations are easily confused, and we separate them. A product of experts adds precisions. If its experts share a prior or common data, it counts that shared factor once per expert; with four experts it understated the covariance trace by 39%, and dividing the shared factor out restored the exact posterior. Covariance intersection is consistent for every cross-correlation and never failed in 400 trials, while the product of experts understated the true error in 196. In an exploration with correlated experts, its 90% ellipse covered 73.6% at correlation 0.9; covariance intersection covered 92.8%. Marginal extension on a cover differs from the product by exactly one copy of the separator marginal, so the product halves the separator variance in every case. On a 3-cycle, pairwise-consistent Gaussian marginals with correlation below $-1/2$ have no joint law at all: the obstruction is global, as Part I predicts for cycles. A product of experts can place its mean outside the convex hull of the expert means, which is a soft form of the map channel of Part III. In a constructed example, two feasible means fuse to an infeasible design. Linear constraints act by conditioning, and quadratic penalties converge to it at rate $1/\gamma$, with an explicit constant. Hard constraints are not bounded weight factors, so the error ledger of Part IV does not apply to them. We give the exact second moment of the restricted weights instead. Coordinate recombination keeps every child feasible for all feasible parents exactly when the feasible set is a box. For a simplex in $ℝ^{16}$, only 64% of children were feasible. There are 13 numerical checks and two explorations, and an immutable C# kernel matches an independent NumPy implementation on every output line.
---

# 1 Introduction

Autoregressive Diffusion Evolution (ADE) proposes designs by running tokens down a denoising stack whose layers read an archive of evaluated designs [7, 8]. Autoregressive Sheaf Evolution (ASE) generalises each read to an observation star with edge maps and scale-dependent covers [9]. Part I separated the horizontal and vertical axes [10]. Part II worked out one layer [11], and Part III a stack [12]. Part IV fixed the target and showed which proposals can be importance-weighted [13]. This paper, Part V of the book, combines local information and imposes constraints.

Combination happens throughout ASE. A layer combines records on an observation star. A cover combines charts on overlaps. A run may combine several critics, surrogates or design teams, and every engineering design must satisfy constraints that no single expert sees whole. Part II warned that products of experts and the marginal extension of V2 are different operations with different conclusions [11, Section 8.1]. Part IV warned that a fused read confined to a hull cannot be weighted against a target outside it [13, Section 6.1]. Part V makes both warnings exact. It also adds the correlation problem that neither part addressed: local experts in ASE are rarely independent, because they read the same archive.

## 1.1 Contributions

- **Fusion rules (Section 2).** The product of experts counts any shared factor once per expert (Proposition 2.3). Covariance intersection is consistent whatever the correlation (Proposition 2.4). The product of experts can move its mean outside the hull of the expert means in two or more dimensions, never in one (Proposition 2.5).
- **Marginal extension (Section 3).** On a two-clique cover, the product of the clique marginals is the marginal extension multiplied by one extra copy of the separator marginal. It halves the separator variance exactly (Theorem 3.1). On a cycle, pairwise consistency does not imply a joint law (Proposition 3.2).
- **Constraints (Section 4).** Linear equality constraints act by conditioning, and quadratic penalties converge to it at rate $1/\gamma$ (Propositions 4.1 and 4.2). Hard constraints change the second moment of importance weights by an exact factor (Proposition 4.3). Coordinate recombination preserves feasibility for all parents exactly when the feasible set is a box (Theorem 4.4). Convex reads keep convex constraints, but products of experts need not (Proposition 4.5).
- **Explorations (Section 5).** We measure the calibration of three fusion rules under correlated errors, and the feasibility of recombined children for three feasible sets in up to 16 dimensions.
- **Evidence.** There are 13 numerical checks besides the explorations (Table 3). An immutable C# kernel agrees with an independent NumPy implementation on every output line (Appendix A).

## 1.2 Scope and status of statements

Experts are Gaussian, given in information form. Constraints are linear equalities, or membership in a set. The paper proves statements about fusion and feasibility. It makes no claim about search performance, and the explorations are computations on declared synthetic examples.

Every statement in a shaded box ends with a provenance tag. *Classical* marks a known result restated in ASE notation. *Part I* to *Part IV* refer to [10] to [13]. *New in Part V* marks a statement proved here for the first time in this programme; each comes with a proof and a numerical check. All spaces are finite-dimensional and real.

## 1.3 Notation

Table: **Table 1.** Notation used throughout Part V.

| Symbol | Meaning |
|:--------------------------|:--------------------------------------------------|
| $(\mu_k,\Lambda_k)$ | mean and precision of expert $k$ |
| $\Lambda,\ \mu$ | precision and mean of a fused law |
| $P_a,\ P_b,\ \omega$ | error covariances and weight of covariance intersection |
| $A,\ S,\ B$ | the two private blocks and the separator of a two-clique cover |
| $p_{AS},\ p_{SB},\ p_S$ | clique and separator marginals |
| $K$ | feasible set |
| $A x=b,\ \gamma$ | linear constraint and penalty strength |
| $\pi_K,\ q_K$ | target and proposal restricted to $K$ and renormalised |
| $m_2$ | second moment of importance weights (Part IV) |


# 2 Fusion of local laws

::: {custom-style="Statement"}
**Definition 2.1** (Gaussian expert). An *expert* on $ℝ^D$ is a Gaussian factor $f_k(x)\propto\exp(-\tfrac12(x-\mu_k)^{\top}\Lambda_k(x-\mu_k))$ with a positive semidefinite precision $\Lambda_k$. A precision that is singular in some direction expresses ignorance there, as a coordinate mask does in Part II.
:::

::: {custom-style="Statement Tag"}
Classical; the information form of Part II, Section 4.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Proposition 2.2** (product of experts). If $\Lambda=\sum_k\Lambda_k$ is positive definite, then $\prod_kf_k$ is proportional to the Gaussian density with precision $\Lambda$ and mean $\mu=\Lambda^{-1}\sum_k\Lambda_k\mu_k$.
:::

::: {custom-style="Statement Tag"}
Classical [6].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* The sum of the exponents is a quadratic form with Hessian $\Lambda$ and linear term $\sum_k\Lambda_k\mu_k$; complete the square. ∎

::: {custom-style="Check"}
*Numerical check.* For 300 random products of 2 to 4 experts in dimensions 1 to 4, the log of the product minus the log of the fused Gaussian was constant across test points to 1.4 × 10⁻¹⁴.
:::

## 2.1 Shared evidence is counted once per expert

::: {custom-style="Statement"}
**Proposition 2.3** (double counting). Suppose expert $k$ is the posterior $f_0g_k$ formed from a shared factor $f_0$, such as a prior or a common archive, and a private factor $g_k$. The product of $K$ such experts is $f_0^Kg_1\cdots g_K$, whereas the posterior given all the information is $f_0g_1\cdots g_K$. With precisions $\Lambda_0$ and $\Lambda_k$, the product has precision $K\Lambda_0+\sum_k\Lambda_k$ instead of $\Lambda_0+\sum_k\Lambda_k$. Dividing $f_0^{K-1}$ out of the product restores the posterior exactly.
:::

::: {custom-style="Statement Tag"}
Classical in substance, the common-information problem of decentralised fusion [5].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Multiply the factorisations; division of Gaussian factors subtracts precisions and information vectors. ∎

A product of experts is therefore valid only when the experts are conditionally independent given the design. In ASE this fails by construction: every layer reads the same archive, so local reads share it. The precision of a naive product overstates what is known, and the error is the shared precision counted $K-1$ extra times.

::: {custom-style="Check"}
*Numerical check.* With a shared factor and four private factors in $ℝ^3$, the naive product had a covariance trace 0.611 times the exact one and a mean 0.401 from the exact mean. Dividing the shared factor out three times recovered the exact precision and mean to 1.3 × 10⁻¹⁵.
:::

The shared factor is not always known. When it is not, a rule that is safe for every correlation is needed.

::: {custom-style="Statement"}
**Proposition 2.4** (covariance intersection). Let $a$ and $b$ be unbiased estimates of $x$ with error covariances bounded by $P_a$ and $P_b$, and unknown cross-covariance. For $\omega\in[0,1]$ put $P_\omega=(\omega P_a^{-1}+(1-\omega)P_b^{-1})^{-1}$ and $c_\omega=P_\omega(\omega P_a^{-1}a+(1-\omega)P_b^{-1}b)$. Then the error covariance of $c_\omega$ is at most $P_\omega$, for every cross-covariance consistent with $P_a$ and $P_b$.
:::

::: {custom-style="Statement Tag"}
Classical, Julier and Uhlmann [4].
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* In 400 random pairs in $ℝ^2$, with cross-covariances $cL_aL_b^{\top}$ for Cholesky factors $L_a,L_b$ and $c$ uniform in $(-1,1)$, and $\omega$ chosen to minimise the trace, the claimed covariance $P_\omega$ dominated the true one in all 400. The naive product understated the true error covariance in 196 of them. The ratio of true to claimed trace reached 1.93 for the product and 0.9999 for covariance intersection.
:::

## 2.2 A product of experts leaves the hull

Part III, Proposition 3.7, listed four channels of novelty for a stack with identity maps. Reads lie in the hull of the records unless maps or masks move them out. A product of experts with unequal precisions is a soft version of a mask.

::: {custom-style="Statement"}
**Proposition 2.5** (fused means can leave the hull). In one dimension, the mean of a product of experts lies between the smallest and the largest expert mean. In two or more dimensions it need not lie in the convex hull of the expert means. For $\mu_1=(1,0)$, $\Lambda_1=\text{diag}(1,100)$, $\mu_2=(0,1)$ and $\Lambda_2=\text{diag}(100,1)$, the fused mean is $(1/101,1/101)$, while every point of the hull has coordinates summing to one.
:::

::: {custom-style="Statement Tag"}
New in Part V.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* In one dimension the fused mean is $\sum_k\lambda_k\mu_k/\sum_k\lambda_k$ with $\lambda_k\ge0$, a convex combination. For the example, $\Lambda=\text{diag}(101,101)$ and $\Lambda_1\mu_1+\Lambda_2\mu_2=(1,1)$. ∎

Each expert is precise about the coordinate on which the other is vague, and the product takes each coordinate from the expert that is sure of it. This is recombination, and it is what masked reads do in Part II, Proposition 3.5. The weights are matrices, not scalars, so the result is not a convex combination of the means.

::: {custom-style="Check"}
*Numerical check.* The example gave $(0.00990,0.00990)$. For 2,000 random triples of experts in $ℝ^2$ with condition numbers up to 50, a non-negative least-squares test placed the fused mean outside the hull of the three means in 1,095. In 2,000 one-dimensional triples it was never outside.
:::

![**Figure 1.** (a) Two experts, each certain of one coordinate, and their product, which lies outside the segment between their means (Proposition 2.5). Both means satisfy $x_1+x_2\ge0.5$; the product does not (Proposition 4.5). Ellipses are unit level sets of each precision. (b) The smallest eigenvalue of the correlation matrix of three variables with common pairwise correlation $r$. Below $r=-1/2$, no joint law has those pairwise marginals (Proposition 3.2).](fig/fusion.png){width=100%}


# 3 Marginal extension on covers

V2 glued local laws by junction-tree marginal extension [9, Section 16]. On a cover with two cliques $A\cup S$ and $S\cup B$ that overlap in a separator $S$, the extension of consistent marginals is $p=p_{AS}\,p_{SB}/p_S$: the law that has both marginals and makes $A$ and $B$ conditionally independent given $S$ [3]. A product of experts would instead multiply the clique marginals.

::: {custom-style="Statement"}
**Theorem 3.1** (a product of experts counts the separator twice). Let $p_{AS}$ and $p_{SB}$ be Gaussian marginals that agree on $S$, and let $p=p_{AS}\,p_{SB}/p_S$ be their extension. Treated as experts on the whole space, their product is
:::

::: {custom-style="Statement Equation"}
$q\propto p_{AS}\,p_{SB}=p\cdot p_S$ (3.1)
:::

::: {custom-style="Statement"}
So $q$ has the same conditional law of $(A,B)$ given $S$ as $p$, but its separator marginal is proportional to $p_S^2$. Its separator mean equals that of $p_S$, and its separator covariance is exactly half.
:::

::: {custom-style="Statement Tag"}
The extension is classical [3]; the comparison New in Part V.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (3.1) is the definition of $p$ rearranged. The factor $p_S$ depends only on $S$, so it leaves the conditional law given $S$ unchanged and multiplies the $S$-marginal of $p$, which is $p_S$, by $p_S$. The square of a Gaussian density with covariance $\Sigma_S$ is proportional to a Gaussian density with the same mean and covariance $\Sigma_S/2$. ∎

The separator is exactly where two charts of a cover agree. A fusion rule that multiplies charts doubles the confidence on that overlap, however large it is. Marginal extension divides by the separator once for each overlap of the junction tree. For a chain of $m$ cliques the product overcounts each of the $m-1$ separators once.

::: {custom-style="Check"}
*Numerical check.* For 300 random Gaussian laws with blocks of dimension 1 or 2, the extension reproduced both clique marginals to 2.7 × 10⁻¹⁵. The product's separator covariance was smaller by a factor between 1.9999999999999991 and 2.000000000000001, per dimension of the separator.
:::

Extension needs marginals that agree on the separators. On a tree of cliques, agreement on every separator suffices [3, 16]. On a cycle it does not.

::: {custom-style="Statement"}
**Proposition 3.2** (consistent pairs on a cycle with no joint law). Let three variables sit on the vertices of a triangle. Give each edge the bivariate law with unit variances and correlation $r$, so that every pair of edge laws agrees on the vertex they share. A joint law with these three edge marginals exists if and only if $-1/2\le r\le1$. For $r<-1/2$ there is none, Gaussian or otherwise.
:::

::: {custom-style="Statement Tag"}
Classical, the marginal problem [16]; the eigenvalue form is elementary.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Any joint law with these pairs has the correlation matrix with ones on the diagonal and $r$ elsewhere. Its eigenvalues are $1+2r$ and $1-r$, twice, so it is positive semidefinite exactly when $-1/2\le r\le1$. Conversely, for such $r$ the Gaussian law with that covariance has the required marginals. ∎

This is the probabilistic face of Part I's cycles. Agreement on every overlap is a local condition, a cocycle condition on edges. A global section can still fail to exist because of the loop, and no amount of local checking detects it. A fusion of three pairwise surrogates around a loop of design variables can therefore fail with no local symptom. The check is global: the assembled covariance must be positive semidefinite.

::: {custom-style="Check"}
*Numerical check.* The smallest eigenvalue was 0.200, 0.000, −0.200 and −0.800 for $r=-0.4$, −0.5, −0.6 and −0.9.
:::


# 4 Constraints

## 4.1 Equality constraints

::: {custom-style="Statement"}
**Proposition 4.1** (conditioning). For $x\sim N(\mu,\Sigma)$ and a constraint $Ax=b$ with $A\Sigma A^{\top}$ invertible, the conditional law has mean $\mu_c=\mu-\Sigma A^{\top}(A\Sigma A^{\top})^{-1}(A\mu-b)$, the point of the constraint set nearest to $\mu$ in the metric $\Sigma^{-1}$.
:::

::: {custom-style="Statement Tag"}
Classical [1, 2].
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Proposition 4.2** (penalties converge at rate $1/\gamma$). The law proportional to $N(\mu,\Sigma)\,e^{-\gamma\Vert Ax-b\Vert^2/2}$ has mean $\mu_\gamma$ with
:::

::: {custom-style="Statement Equation"}
$\Vert\mu_\gamma-\mu_c\Vert\le\frac{\Vert\Sigma A^{\top}\Vert\,\Vert(A\Sigma A^{\top})^{-1}\Vert^2\,\Vert A\mu-b\Vert}{\gamma}$ (4.1)
:::

::: {custom-style="Statement Tag"}
New in Part V in this form; the quadratic penalty method is classical [14, Chapter 17].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* The penalty is a Gaussian observation $b=Ax+\nu$ with noise covariance $I/\gamma$, so $\mu_\gamma=\mu-\Sigma A^{\top}(M+I/\gamma)^{-1}(A\mu-b)$ with $M=A\Sigma A^{\top}$. Then $M^{-1}-(M+\varepsilon I)^{-1}=\varepsilon M^{-1}(M+\varepsilon I)^{-1}$, whose norm is at most $\varepsilon\Vert M^{-1}\Vert^2$, with $\varepsilon=1/\gamma$. ∎

A penalty is a soft constraint whose error must be reported with it. Doubling $\gamma$ halves the violation, and nothing short of $\gamma=\infty$ removes it.

::: {custom-style="Check"}
*Numerical check.* In $ℝ^4$ with two random constraints, the conditional mean satisfied them to 6.7 × 10⁻¹⁶. For $\gamma=1$, 10, 100, 1,000 and 10,000, the distance to it was 0.791, 0.112, 0.0117, 0.00118 and 0.000118, against the bounds 3.72, 0.372, 0.0372, 0.00372 and 0.000372. The fitted slope on a log scale was −0.994.
:::

## 4.2 Hard constraints in estimation

A feasible set $K$ restricts the target to $\pi_K=\pi1_K/\pi(K)$. Its indicator is a multiplicative factor with log-width $\kappa=\infty$, so Lemma 4.1 of Part IV gives no bound, and the error ledger does not apply. Rejection does: draws from a proposal $q$ that land in $K$ are draws from $q_K=q1_K/q(K)$.

::: {custom-style="Statement"}
**Proposition 4.3** (restricted weights). The second moment of the weights of $\pi_K$ against $q_K$ is
:::

::: {custom-style="Statement Equation"}
$m_2(q_K;\pi_K)=\frac{q(K)}{\pi(K)^2}\int_K\frac{\pi^2}{q}\,\text{d}x\le\frac{q(K)\,m_2(q;\pi)}{\pi(K)^2}$ (4.2)
:::

::: {custom-style="Statement"}
and a fraction $q(K)$ of the proposals is accepted.
:::

::: {custom-style="Statement Tag"}
New in Part V.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* On $K$ the weight is $(\pi/q)\,q(K)/\pi(K)$. Square it, integrate against $q_K$, and extend the integral to the whole space for the bound. ∎

The bound shows why constraints are expensive. A constraint that the target mostly violates, with $\pi(K)$ small, inflates the cost by $1/\pi(K)^2$ unless the proposal concentrates on $K$ in the same proportion.

::: {custom-style="Check"}
*Numerical check.* For $\pi=N(0,1)$, $q=N(0,1.5^2)$ and $K=\{x>0.8\}$, (4.2) gives 1.2665. Monte Carlo from four million proposals gave 1.2670, with acceptance 0.297. The bound in (4.2) is 7.96, and the unrestricted second moment is 1.20.
:::

## 4.3 Recombination and feasibility

Recombination takes coordinates, or blocks of coordinates, from different parents. Part II showed that masked reads recombine. Proposition 2.5 shows that products of experts do. The question for constraints is when recombination of feasible parents gives a feasible child.

::: {custom-style="Statement"}
**Theorem 4.4** (recombination preserves feasibility exactly on boxes). Let $K\subseteq ℝ^D$ be non-empty, with coordinate projections $K_i$. Every child that takes each coordinate from one of two parents in $K$ lies in $K$, for all parents and all choices of coordinates, if and only if $K=K_1\times\cdots\times K_D$.
:::

::: {custom-style="Statement"}
The same holds for blocks of coordinates, such as the stalks of a cover, with $K$ a product over the blocks.
:::

::: {custom-style="Statement Tag"}
New in Part V.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* If $K$ is a product, each coordinate of a child lies in its $K_i$. Conversely, let $z$ have $z_i\in K_i$ for every $i$, and choose $x^{(i)}\in K$ with $x^{(i)}_i=z_i$. Put $c_1=x^{(1)}$. For $j\ge2$, let $c_j$ take coordinate $j$ from $x^{(j)}$ and every other coordinate from $c_{j-1}$. By hypothesis each $c_j\in K$, and $c_D=z$. Hence $K_1\times\cdots\times K_D\subseteq K$, and the reverse inclusion always holds. ∎

Uniform crossover [15] and masked reads are safe only for box constraints. Coupling constraints, such as a budget $\sum_ix_i\le1$ or a norm bound, make some children infeasible. How many depends on the set and the dimension (Section 5.2).

::: {custom-style="Statement"}
**Proposition 4.5** (convex reads stay feasible; products need not). If $K$ is convex and every record read by a layer lies in $K$, then every read with identity maps lies in $K$, and so does every output of a deterministic stack whose starting state lies in $K$. A product of experts whose means all lie in a convex $K$ can have its mean outside $K$.
:::

::: {custom-style="Statement Tag"}
The first statement follows from Part III, Proposition 3.7; the second is New in Part V.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Reads are convex combinations of records, and the output of a deterministic stack is a convex combination of its starting state and its reads (Part III, Theorem 3.1). For the second statement, take Proposition 2.5 with $K=\{x:x_1+x_2\ge0.5\}$. ∎

::: {custom-style="Check"}
*Numerical check.* In Proposition 2.5's example both means satisfy $x_1+x_2\ge0.5$, their midpoint does, and the product mean, with coordinate sum 0.0198, does not. For boxes, all of 40,000 recombined children were feasible in every dimension tested.
:::


# 5 Explorations

## 5.1 Which fusion rule is calibrated

Two experts in $ℝ^2$ have error covariances $\text{diag}(1,0.3)$ and $\text{diag}(0.3,1)$, with cross-covariance $cL_aL_b^{\top}$. For $c=0$, 0.3, 0.6 and 0.9 we drew 4,000 error pairs and recorded how often the fused error fell inside the 90% ellipse that each rule claims. The rules were the product of experts, covariance intersection, and the exact linear fusion that knows $c$ (Figure 2a).

The exact rule covered 0.895, 0.898, 0.897 and 0.899, as it should. The product covered 0.895 at $c=0$, where it is exact, and then 0.832, 0.775 and 0.736. Covariance intersection covered 0.990, 0.973, 0.949 and 0.928. It was conservative everywhere, most at $c=0$, where it gives up the information that the experts are independent.

The choice therefore depends on what is known. Use the exact rule, or the product with shared factors divided out (Proposition 2.3), when the common information is known. When it is not, use covariance intersection and report it as conservative. The plain product is safe only when the experts read disjoint evidence. In ASE that would require disjoint archives.

## 5.2 How often recombined children are feasible

For each set we drew 40,000 pairs of parents uniformly from it and formed children by uniform crossover (Figure 2b). For the unit box every child was feasible, as Theorem 4.4 says. For the unit ball the feasible share fell from 0.953 in two dimensions to 0.813 in six and 0.698 in sixteen. For the simplex $\{x\ge0,\sum_ix_i\le1\}$ it fell from 0.918 to 0.742 and 0.642. The C# kernel, with its own random stream, gave 0.734 for the simplex in six dimensions.

The losses grow with dimension but do not collapse, because a child keeps about half of each parent and only the coupled constraints fail. A run with coupled constraints should either repair children by conditioning (Proposition 4.1), or recombine only across blocks between which no constraint couples, the case Theorem 4.4 allows.

![**Figure 2.** (a) Coverage of the claimed 90% ellipse for three fusion rules, against the correlation of the experts' errors. (b) Share of feasible children of uniform crossover for parents drawn uniformly from a box, a ball and a simplex, against dimension (Theorem 4.4).](fig/calibration.png){width=100%}


# 6 Discussion

## 6.1 What Part V supplies to the book

Part VI, on evidence and computation, takes three things from this paper as specifications. Every fused law should name its fusion rule and its assumptions about correlation. Every constraint should be reported as hard, by conditioning or rejection, or soft, with its penalty and the bound (4.1). Every recombination operator should be checked against the product structure of the feasible set. The kernel of Appendix A implements the rules.

For the earlier parts, Proposition 2.5 adds fusion to the novelty channels of Part III as a soft form of the map channel. Theorem 3.1 settles the warning of Part II: a product of experts on a cover counts every overlap twice, while marginal extension does not. Proposition 3.2 gives Part I's cycles a probabilistic meaning: local agreement on a loop does not guarantee a global law.

## 6.2 Diagnostics a fusion should report

Table: **Table 2.** Diagnostics reported with every fusion and constraint.

| Diagnostic | Source | Action when it is poor |
|:-------------------|:-------------------|:-------------------------------|
| shared factors among experts | Proposition 2.3 | divide them out, or use covariance intersection |
| fusion rule and its correlation assumption | Proposition 2.4, Section 5.1 | report coverage, not only the claimed covariance |
| whether fused means left the hull of the expert means | Proposition 2.5 | treat as recombination; check constraints |
| separators of the cover and their multiplicity in the product | Theorem 3.1 | use marginal extension |
| positive semidefiniteness of glued covariances on cycles | Proposition 3.2 | do not glue; report the obstruction |
| constraint type, penalty $\gamma$ and the bound (4.1) | Propositions 4.1, 4.2 | condition, or raise $\gamma$ |
| acceptance $q(K)$ and $\pi(K)$ | Proposition 4.3 | move the proposal towards $K$ |
| product structure of the feasible set across recombined blocks | Theorem 4.4 | repair or restrict recombination |

## 6.3 What is not claimed

The statements concern Gaussian experts and linear or set constraints. Nonlinear constraints, non-Gaussian experts and learned surrogates with unknown error structure are outside them, although Theorem 4.4 and Proposition 3.2 do not need Gaussianity. Covariance intersection is conservative, not optimal; tighter consistent rules exist for structured correlations and are not studied here. The explorations use synthetic laws and sets. They measure calibration and feasibility, not design quality.

## 6.4 Open problems

1. **Shared archives.** Estimate the common information between two ASE reads from their shared records, so that Proposition 2.3 can be applied without knowing the shared factor in closed form.
2. **Cycles in covers.** Find the closest jointly consistent family to pairwise-consistent marginals on a cycle, and relate its distance to the frustration measures of Part I.
3. **Constraint-aware recombination.** Characterise the coarsest block partition across which a given constraint set is a product, and recombine only across it.
4. **Penalties and targets.** Combine Proposition 4.2 with the error ledger of Part IV, so that a soft constraint enters an estimate with a bounded, reported error.
5. **Non-Gaussian fusion.** Extend Proposition 2.5 and Theorem 3.1 to exponential-family experts, where products still add natural parameters.

## 6.5 Conclusion

Fusion in ASE is not one operation. A product of experts adds precisions and is exact only for experts with disjoint evidence. It counts shared archives and the separators of a cover once per factor, and it can move its mean outside the hull of the experts and outside a convex feasible set. Covariance intersection is safe when the correlation is unknown, at the price of conservatism. Marginal extension is exact on a tree of cliques and can fail with no local symptom on a cycle. Constraints act by conditioning, approximately by penalties at rate $1/\gamma$, or by rejection at an exact cost. Recombination keeps feasibility only across blocks between which no constraint couples. Part VI takes these as the contracts an implementation must report.


# 7 Register of numerical checks

Table 3 lists every numerical check in Part V. The script `p5_checks.py` produced checks 1 to 12 and both explorations with seed 20261023, and the kernel comparison of Appendix A is check 13. The checks test the implementations and illustrate the statements; the proofs establish them.

Table: **Table 3.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 2.2 | 300 random products | constant to 1.4 × 10⁻¹⁴ |
| 2 | Proposition 2.3 | four experts with a shared factor | trace ratio 0.611; corrected to 1.3 × 10⁻¹⁵ |
| 3 | Proposition 2.4 | 400 correlated pairs | 0 violations; product understated 196 |
| 4 | Proposition 2.5 | example; 2,000 triples; 2,000 in 1-D | $(0.0099,0.0099)$; 1,095 outside; 0 outside |
| 5 | Theorem 3.1 | 300 random laws | marginals to 2.7 × 10⁻¹⁵; separator ratio 2 |
| 6 | Proposition 3.2 | four correlations | smallest eigenvalue −0.8 at $r=-0.9$ |
| 7 | Proposition 4.1 | two constraints in $ℝ^4$ | residual 6.7 × 10⁻¹⁶ |
| 8 | Proposition 4.2 | five penalty strengths | 0 violations; slope −0.994 |
| 9 | Proposition 4.3 | identity against Monte Carlo | 1.2665 against 1.2670 |
| 10 | Theorem 4.4 | boxes, 8 dimensions | all children feasible |
| 11 | Proposition 4.5 | example | means and read feasible; product infeasible |
| 12 | Section 5 | calibration and recombination | product 0.736 at $c=0.9$; simplex 0.642 in $ℝ^{16}$ |
| 13 | Appendix A | C# kernel against NumPy | 9 of 9 lines agree |

# References

::: {custom-style="Bibliography"}
[1] Bar-Shalom, Y., Li, X. R. and Kirubarajan, T. (2001). *Estimation with Applications to Tracking and Navigation*. Wiley.

[2] Rasmussen, C. E. and Williams, C. K. I. (2006). *Gaussian Processes for Machine Learning*. MIT Press.

[3] Lauritzen, S. L. (1996). *Graphical Models*. Oxford University Press.

[4] Julier, S. J. and Uhlmann, J. K. (1997). A non-divergent estimation algorithm in the presence of unknown correlations. *Proceedings of the American Control Conference*, 2369–2373.

[5] Grime, S. and Durrant-Whyte, H. F. (1994). Data fusion in decentralized sensor networks. *Control Engineering Practice* 2(5), 849–863.

[6] Hinton, G. E. (2002). Training products of experts by minimizing contrastive divergence. *Neural Computation* 14(8), 1771–1800.

[7] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[8] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[9] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[10] Ghosh, D. P. (2026d). *Horizontally Topological, Vertically Algebraic: The Two Axes of Autoregressive Sheaf Evolution. Part I: Sheaves on Covers and Representations of the Layer Order*. 18 October 2026.

[11] Ghosh, D. P. (2026e). *The Horizontal Layer: One Layer of Autoregressive Sheaf Evolution. Part II: Sheaf Attention, Gaussian Stalks, Locality and the Topology of Design Spaces*. 18 October 2026.

[12] Ghosh, D. P. (2026f). *The Vertical Stack: Layers of Autoregressive Sheaf Evolution. Part III: The Token Recurrence, Tangent Dynamics and Persistence across Layers*. 18 October 2026.

[13] Ghosh, D. P. (2026g). *Targets and Estimation: What Autoregressive Sheaf Evolution Can Estimate. Part IV: Gibbs Targets, Proposal Laws, Importance Weights and Error Budgets*. 21 October 2026.

[14] Nocedal, J. and Wright, S. J. (2006). *Numerical Optimization*, 2nd edn. Springer.

[15] Syswerda, G. (1989). Uniform crossover in genetic algorithms. *Proceedings of the Third International Conference on Genetic Algorithms*, 2–9.

[16] Vorob'ev, N. N. (1962). Consistent families of measures and their extensions. *Theory of Probability and Its Applications* 7(2), 147–163.

[17] Steele, G. L., Lea, D. and Flood, C. H. (2014). Fast splittable pseudorandom number generators. *Proceedings of OOPSLA 2014*, 453–472. ACM.
:::

# Appendix A: an immutable C# reference kernel

The kernel represents experts in information form as immutable records. It implements the product of experts, the division of a shared factor, covariance intersection with a grid search for the weight, conditioning on linear constraints, the quadratic penalty and coordinate recombination. A Gauss–Jordan solver works on private copies of its inputs. The random stream is a SplitMix64 generator [17], held as a value. The kernel targets .NET 8 and uses only the base class library.

```csharp
// ASE Part V reference kernel: Gaussian fusion rules and linear constraints.
// Immutable values and pure functions; the solver works on private copies.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AsePartFive;

/// <summary>A dense real matrix stored row-major.</summary>
public sealed record Mat(int Rows, int Cols, Vec Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Mat Of(int r, int c, Func<int, int, double> f) =>
        new(r, c, Enumerable.Range(0, r * c).Select(k => f(k / c, k % c)).ToImmutableArray());

    public static Mat Identity(int n) => Of(n, n, (i, j) => i == j ? 1 : 0);
    public static Mat Diag(params double[] d) => Of(d.Length, d.Length, (i, j) => i == j ? d[i] : 0);
    public Mat T => Of(Cols, Rows, (i, j) => this[j, i]);
    public Mat Mul(Mat b) => Of(Rows, b.Cols,
        (i, j) => Enumerable.Range(0, Cols).Sum(k => this[i, k] * b[k, j]));
    public Vec Apply(Vec v) => Enumerable.Range(0, Rows)
        .Select(i => Enumerable.Range(0, Cols).Sum(k => this[i, k] * v[k])).ToImmutableArray();
    public Mat Add(Mat b, double s = 1) => Of(Rows, Cols, (i, j) => this[i, j] + s * b[i, j]);
    public Mat Scale(double s) => Of(Rows, Cols, (i, j) => s * this[i, j]);
    public double Trace => Enumerable.Range(0, Rows).Sum(i => this[i, i]);

    /// <summary>Solves this X = B by Gauss-Jordan elimination with partial pivoting.</summary>
    public Mat Solve(Mat b)
    {
        int n = Rows, m = b.Cols;
        var a = Enumerable.Range(0, n).Select(i => Enumerable.Range(0, n).Select(j => this[i, j])
            .Concat(Enumerable.Range(0, m).Select(j => b[i, j])).ToArray()).ToArray();
        for (int c = 0; c < n; c++)
        {
            int p = Enumerable.Range(c, n - c).OrderByDescending(r => Math.Abs(a[r][c])).First();
            (a[c], a[p]) = (a[p], a[c]);
            for (int r = 0; r < n; r++)
            {
                if (r == c) continue;
                double f = a[r][c] / a[c][c];
                for (int k = c; k < n + m; k++) a[r][k] -= f * a[c][k];
            }
        }
        return Of(n, m, (i, j) => a[i][n + j] / a[i][i]);
    }

    public Mat Inverse() => Solve(Identity(Rows));
    public Vec SolveVec(Vec v) => Solve(Of(v.Length, 1, (i, _) => v[i])).Data;
}

/// <summary>A Gaussian expert in information form: mean and precision.</summary>
public sealed record Expert(Vec Mean, Mat Precision);

public static class Fusion
{
    /// <summary>Product of experts (Proposition 2.2): precisions add, means are
    /// precision-weighted.</summary>
    public static Expert Product(ImmutableArray<Expert> es)
    {
        var l = es.Skip(1).Aggregate(es[0].Precision, (acc, e) => acc.Add(e.Precision));
        var h = es.Select(e => e.Precision.Apply(e.Mean))
                  .Aggregate((a, b) => a.Zip(b, (x, y) => x + y).ToImmutableArray());
        return new Expert(l.SolveVec(h), l);
    }

    /// <summary>Removes a factor that k experts share, counted k - 1 times too often
    /// (Proposition 2.3).</summary>
    public static Expert Divide(Expert fused, Expert shared, int extraCount)
    {
        var l = fused.Precision.Add(shared.Precision, -extraCount);
        var h = fused.Precision.Apply(fused.Mean)
            .Zip(shared.Precision.Apply(shared.Mean), (a, b) => a - extraCount * b)
            .ToImmutableArray();
        return new Expert(l.SolveVec(h), l);
    }

    /// <summary>Covariance intersection of two estimates (Proposition 2.4), with the
    /// weight chosen on a grid to minimise the trace of the fused covariance.</summary>
    public static (Vec Mean, Mat Covariance, double Omega) Intersect(
        Vec a, Mat pa, Vec b, Mat pb, int grid = 999)
    {
        Mat ia = pa.Inverse(), ib = pb.Inverse();
        double w = Enumerable.Range(1, grid).Select(i => i / (grid + 1.0))
            .OrderBy(x => ia.Scale(x).Add(ib, 1 - x).Inverse().Trace).First();
        var l = ia.Scale(w).Add(ib, 1 - w);
        var h = ia.Scale(w).Apply(a).Zip(ib.Scale(1 - w).Apply(b), (x, y) => x + y)
                  .ToImmutableArray();
        return (l.SolveVec(h), l.Inverse(), w);
    }

    /// <summary>Hard linear constraint A x = b by conditioning (Proposition 4.1).</summary>
    public static Vec Condition(Vec mu, Mat sigma, Mat a, Vec b)
    {
        var sat = sigma.Mul(a.T);
        var r = a.Apply(mu).Zip(b, (x, y) => x - y).ToImmutableArray();
        var c = sat.Apply(a.Mul(sat).SolveVec(r));
        return mu.Zip(c, (x, y) => x - y).ToImmutableArray();
    }

    /// <summary>Soft penalty exp(-gamma |A x - b|^2 / 2) (Proposition 4.2).</summary>
    public static Vec Penalise(Vec mu, Mat sigma, Mat a, Vec b, double gamma)
    {
        var l = sigma.Inverse().Add(a.T.Mul(a), gamma);
        var h = sigma.SolveVec(mu).Zip(a.T.Apply(b), (x, y) => x + gamma * y)
                     .ToImmutableArray();
        return l.SolveVec(h);
    }

    /// <summary>A child taking each coordinate from x where mask is true, else from y.</summary>
    public static Vec Recombine(Vec x, Vec y, ImmutableArray<bool> mask) =>
        x.Select((v, i) => mask[i] ? v : y[i]).ToImmutableArray();
}

/// <summary>SplitMix64 stream with uniform draws; each draw returns the next state.</summary>
public sealed record Rng(ulong State)
{
    public (double Value, Rng Next) Uniform()
    {
        ulong s = State + 0x9E3779B97F4A7C15UL, z = s;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
        return (((z ^ (z >> 31)) >> 11) * (1.0 / 9007199254740992.0), new Rng(s));
    }
}
```

The driver prints the example of Proposition 2.5, the naive and corrected products of four experts sharing a factor, a covariance intersection, a conditioned mean, and the distance of three penalised means from it. It ends with the feasible share of 20,000 recombined children of uniform simplex points in $ℝ^6$, drawn from its own stream. An independent NumPy script recomputes every line, building the exact posterior directly rather than by division (Table A1). Relative differences are reported where they are meaningful. For the penalty distances, which are small differences of nearly equal vectors, the absolute difference is reported; the largest is 2.3 × 10⁻¹³.

Table: **Table A1.** C# kernel output against the NumPy recomputation.

| C# | NumPy | Difference |
|:------------------|:------------------|:----------|
| `poe_mean 0.009900990099009901 0.009900990099009901` | `poe_mean 0.009900990099009901 0.009900990099009901` | identical |
| `naive_mean 0.5096979332273449 0.21271860095389508` | `naive_mean 0.5096979332273449 0.21271860095389508` | identical |
| `corrected_mean 0.5535914416709118 0.5138053998981152 20.2` | `corrected_mean 0.5535914416709119 0.5138053998981152 20.2` | 2.0 × 10⁻¹⁶ |
| `covariance_intersection 0.23076923076923073 0.23076923076923073 0.9230769230769229 0.5` | `covariance_intersection 0.23076923076923073 0.23076923076923073 0.9230769230769229 0.5` | identical |
| `condition 0.2205128205128205 -⁠0.36666666666666675 1.146153846153846 0.9999999999999998` | `condition 0.2205128205128205 -⁠0.36666666666666675 1.146153846153846 0.9999999999999998` | identical |
| `penalty_1 0.006876703800236604` | `penalty_1 0.006876703800236496` | 1.6 × 10⁻¹⁴ |
| `penalty_100 7.748398648293636E-⁠05` | `penalty_100 7.74839864834844e-⁠05` | 7.1 × 10⁻¹² |
| `penalty_10000 7.758240347570785E-⁠07` | `penalty_10000 7.758242648336553e-⁠07` | absolute 2.3 × 10⁻¹³ |
| `simplex_children_feasible 0.73435` | `simplex_children_feasible 0.73435` | identical |

# Appendix B: reproducibility

All results were produced with Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1, Matplotlib 3.11.2 and .NET SDK 8.0.131. The script `p5_checks.py` writes `p5_checks.json` with seed 20261023, and `fig_p5.py` draws the figures from it; the ellipses and the eigenvalue curve are analytic. The C# project in `cs/` builds the kernel and its driver, and `cs_validate.py` compares the driver's output with NumPy and writes `cs_validate.json`. The document is converted to Word by Pandoc and post-processed for equation layout and schema order. A code archive accompanies this paper.
