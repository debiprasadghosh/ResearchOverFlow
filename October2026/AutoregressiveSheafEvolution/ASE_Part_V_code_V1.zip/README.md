# ASE Part V code
Run p5_checks.py, fig_p5.py; build cs/ (.NET 8) and save output to cs/cs_out.txt; cs_validate.py; render4.py; pandoc paper.md -o raw.docx --reference-doc=ref.docx; postprocess.py raw.docx paper.docx.
