import subprocess, sys
from docx import Document
from docx.shared import Pt
subprocess.run(["pandoc", "book.md", "-o", "raw.docx", "--reference-doc=ref.docx", "--no-highlight", ], check=True)
d = Document("raw.docx")
d.core_properties.title = "Autoregressive Sheaf Evolution"; d.core_properties.author = "Debi Prasad Ghosh"
d.core_properties.subject = "A mathematics of layered design search, in six parts. First edition"
d.core_properties.keywords = "sheaf; diffusion; evolutionary search; importance sampling; fusion; certificates"
for p in d.paragraphs:
    if p.style.name == "Heading 1":
        p.paragraph_format.page_break_before = True
    if p.style.name == "Front Note":
        p.paragraph_format.space_after = Pt(6)
first = [p for p in d.paragraphs if p.style.name == "Front Note"]
if first: first[0].paragraph_format.page_break_before = True
d.save("layout.docx")
subprocess.run([sys.executable, "postprocess.py", "layout.docx", "ASE_Book.docx"], check=True)
