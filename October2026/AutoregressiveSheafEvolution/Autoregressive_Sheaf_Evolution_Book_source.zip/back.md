# Afterword: what the six parts establish and what remains

The book set out to make one sentence exact: an ASE stack is horizontally topological within each layer and vertically algebraic across layers. Part I gave the sentence its mathematics, as sheaves on covers and representations of the layer order. Parts II and III computed what the two axes do: a layer is a harmonic extension on an observation star, and a stack is a schedule acting on reads that, in the continuum limit, transports the archive density. Parts IV to VI asked what can be claimed from the results: which target a run estimates, how local laws may be fused and constrained, and what an implementation must report for a number to count as evidence.

Several results cut against first impressions, and they are worth restating together.

- **The archive is not the target.** A selected archive is a record of what was evaluated. Used as a target it was off by 0.61 or more in total variation in Part IV's example. It is a proposal, to be corrected by fresh evaluations.
- **A clean top re-selects.** In the continuum limit, a stack with identity maps and a clean top samples the archive itself (Part III, Proposition 3.6). Its outputs cannot be importance-weighted (Part IV, Theorem 3.1). Novelty comes only from the channels Part III lists and from fusion (Part V, Proposition 2.5).
- **Topology does not choose good schedules by itself.** Component persistence scales placed layers where few tokens make decisions. Hypothesis C3 was refuted in all 72 comparisons of an exploratory pilot. A curvature schedule computed from the archive was the best tested at equal numbers of layers.
- **Products of experts overcount.** They count shared archives once per expert and separators twice (Part V, Proposition 2.3 and Theorem 3.1).
- **Local agreement does not imply a global law.** On a cycle, pairwise-consistent marginals can have no joint law (Part V, Proposition 3.2), the probabilistic face of Part I's cohomology.
- **In-sample diagnostics cannot see infinite variance.** Selecting an importance width by in-sample effective size chose infinite-variance widths in most runs at moderate sample sizes (Part VI, Section 3.5).

## The hypotheses of the conversion proposal

The conversion proposal stated five falsifiable hypotheses with decision rules [S3, Sections 17–18]. Table B.1 records their status at the end of this edition. None has been tested confirmatorily. The proposal recommended C2 as the first experiment, on chain-structured objectives with equal evaluation budgets and a classical block-recombination control, and that recommendation stands.

Table: **Table B.1.** Status of hypotheses C1 to C5 after the six parts.

| Label | Prediction in the proposal | What the book established | Status |
|:--------|:------------------------|:------------------------------------|:--------------|
| C1 | adaptive geometry retains estimation quality: RMSE at most 1.5 times a fixed-cover comparator | defensive mixtures, the width threshold and the error ledger (Part IV, Theorems 3.5 and 5.1); adaptive covers not studied | open; prerequisites supplied |
| C2 | recombination halves costly evaluations on chain objectives | the mechanism and its ceiling (Part II, Proposition 3.5); feasibility only across product blocks (Part V, Theorem 4.4) | open; qualified; recommended first experiment |
| C3 | schedules from component persistence match twice as many cosine layers | refuted in all 72 comparisons of an exploratory transport pilot (Part III, Section 5.3) | refuted in exploration; confirmatory test pending |
| C4 | transport reduces physical re-selection by 30 points on a mirror-symmetric truss | orbit indexes and the failure of continuous canonicalisation (Part II, Proposition 6.10); clean-top re-selection (Part III, Proposition 3.6) | open; constrained |
| C5 | local reads use at most 10% of the archive with loss within 1% of ADE | per-layer and composite sensitivity bounds (Part II, Proposition 5.4; Part III, Theorem 4.2); nearest-record certificates certified little below a quarter of the archive (Part VI, Section 2.3) | open; certification at 10% doubtful in the tested setting |

## Work for the next edition

Three planned chapters are missing from this edition: Pareto orders and scalarisations, consistency of reads with adaptive fits, and versioned caches with release rules (Table F.1). The open problems at the end of each part list the mathematical questions the six parts leave behind. The most consequential are four:

- the convergence of stochastic stacks to the reverse-time equation of the archive mixture (Part III);
- a density, if any, whose score is the sheaf read with masks (Part III);
- sharper truncation certificates from index structure (Part VI);
- the confirmatory protocols for C1 to C5, with sample sizes and families declared in advance (Part VI).

The proposal ended with a decision rule that this book adopts. Failure of a performance hypothesis does not falsify the harmonic-extension identity or the inclusion of ADE. It decides where the extra modelling cost of ASE is justified. Null and adverse results belong in the book.

# Register of Results

The register lists every numbered definition, theorem, proposition, lemma, corollary, example and remark in the book, by part, with the name it carries in the text. It serves as the index of the book.

{{register}}

# Glossary

**ADE (Autoregressive Diffusion Evolution).** The search procedure that ASE generalises: tokens descend a denoising stack whose layers read an archive of evaluated designs through one Gaussian kernel.

**Archive density.** The mixture $p_s=\sum_i\beta_iN(y_i,s^2I)$ of the archived records at scale $s$ (Part III, Definition 2.1; Part IV, Definition 2.2).

**ASE (Autoregressive Sheaf Evolution).** ADE with local data spaces, compatibility maps and scale-dependent covers in place of one retrieval geometry.

**Barcode.** The decomposition of a representation of the layer order into interval modules. It is exact only with exact ranks (Part I, Section 4; Part III, Proposition 4.6).

**Base law.** The declared reference density $\rho$ against which $e^{-\beta J}$ defines the Gibbs target (Part IV, Definition 2.1).

**Certificate.** A computable bound on the error of a computed quantity, such as a stationarity residual or a truncation share. A numerical counterexample must carry one (Part VI, Proposition 4.1).

**Clean top.** A stack whose last scale is $s_0=0$, so that the output is the last read.

**Cover, nerve, Leray cover.** A finite family of open sets on a layer's base; the simplicial complex of their overlaps; a cover whose overlaps are acyclic, so that the nerve computes the cohomology (Part I, Section 3).

**Covariance intersection.** A fusion rule that is consistent for every cross-correlation of its inputs (Part V, Proposition 2.4).

**Defensive mixture.** A proposal $(1-\varepsilon)q+\varepsilon\rho$ whose importance weights are bounded by $1/(\varepsilon Z)$ (Part IV, Theorem 3.5).

**Error ledger.** The bound that splits the error of an importance estimate into a critic and density term and a sampling term (Part IV, Theorem 5.1).

**Gibbs target.** The law $\pi_\beta=\rho e^{-\beta J}/Z$ that a run estimates.

**Harmonic extension, sheaf attention, read.** The least-squares extension of observations from the leaves of an observation star to the token: $m=H^{-1}\sum_i\alpha_iQ_i^{\top}o_i$ (Part II, Section 3).

**Holonomy.** The composite of transports around a closed walk of an orthogonal sheaf. Its fixed space is the space of global sections (Part I, Theorem 3.12).

**Marginal extension.** The law $p_{AS}p_{SB}/p_S$ that glues consistent clique marginals across a separator (Part V, Section 3).

**Noise budget.** The fixed variance $s_0^2-\omega_\star^2s_T^2$ of the explicit noise reaching a stack's output (Part III, Theorem 3.2).

**Observation star.** A token vertex joined to one leaf per retrieved record, with edge maps on both sides (Part I, Definition 2.4; Part II, Section 2).

**Product of experts.** The product of Gaussian factors, which adds precisions. It is exact only for experts with disjoint evidence (Part V, Propositions 2.2 and 2.3).

**Second moment of the weights, $m_2$.** $E_q[(\pi/q)^2]=1+\chi^2(\pi\Vert q)$, which governs the cost of importance sampling (Part IV, Section 3.3).

**Separation identity.** The decomposition of a stack's output into a starting term, a convex combination of reads and a noise term (Part III, Theorem 3.1).

**Stalk, restriction map, section.** The data space on a cell of a cover; the linear map comparing data on a cell with data on a larger cell; an assignment of data to cells that agrees under every restriction (Part I, Section 3).

**Tangent, composite tangent.** The Jacobian of a layer, and the product of layer Jacobians along a token's path (Part III, Section 4).

# Works in this series

[S1] Ghosh, D. P. (2026). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[S2] Ghosh, D. P. (2026). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[S3] Ghosh, D. P. (2026). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[S4] Ghosh, D. P. (2026). *Separator Anchors for Sheaf Based Latent Reasoning*. Version 4, 20 October 2026.

[S5] Ghosh, D. P. (2026). *Sheaf Structured Generative Diffusion*. Version 2, October 2026.

[S6] Ghosh, D. P. (2026). *SheafFarm: Some Sheaf-Diffusion Algorithms are More Sheaf Than Others*. Version 2, October 2026.

# About the author

Debi Prasad Ghosh is the Founder and Principal Engineer of Debias Parametric Guru, Kolkata, India. He is an independent researcher. His Defensible Intelligence series, written under the motto “Respect science. Import emotion.”, treats falsifiability as a hard standard: mathematics over framework over expressivity.
