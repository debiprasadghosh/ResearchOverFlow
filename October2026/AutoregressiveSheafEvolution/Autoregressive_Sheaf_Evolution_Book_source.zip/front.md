::: {custom-style="Front Note"}
**Autoregressive Sheaf Evolution**

*Horizontally topological, vertically algebraic: a mathematics of layered design search*

First edition, 22 October 2026.

Defensible Intelligence series. “Respect science. Import emotion.”

© 2026 Debi Prasad Ghosh, Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India. All rights reserved.

The six parts of this book were first prepared as separate papers between 18 and 21 October 2026. They are reproduced here with their numbering, proofs, numerical checks and reference kernels intact. The front and back matter are new to this edition, and so is the correction to the register of hypotheses in Part VI.

The numerical results in this book were produced by the scripts and C# kernels described in the appendices of each part. They are checks of mathematics and exploratory computations on declared synthetic examples. No result in this book is a confirmatory test of search performance.
:::

# Preface

This book began with a reading of denoising diffusion as a search procedure. Autoregressive Diffusion Evolution (ADE) runs tokens down a denoising stack whose layers read an archive of evaluated designs [S1, S2]. Each layer forms a Gaussian-weighted average of the archived designs near the token and moves the token towards it. The archive grows as new designs are evaluated, and the loop repeats. ADE treats the design space as one Euclidean space with one retrieval geometry.

Engineering design spaces are rarely like that. Different parts of a design are described in different coordinates. Some records observe only some variables, symmetric designs have several representations, and branches of a design family must not be averaged. The conversion proposal of 18 October 2026 therefore replaced ADE's single retrieval geometry by local data spaces, compatibility maps and scale-dependent covers [S3]. It named the result Autoregressive Sheaf Evolution (ASE), stated its organising principle, *horizontally topological within each layer and vertically algebraic across layers*, and proposed a six-part book. This is that book.

## What the book does

Each part is a self-contained mathematical paper.

- **Part I, The Two Axes,** makes the organising principle exact. Within a layer, local data form a sheaf on a cover, and agreement and disagreement are measured by cohomology. Across layers, the journey of a token is a representation of the layer order, with barcodes. A fixed-base product packages both axes into one sheaf, and ADE is its trivial case.
- **Part II, The Horizontal Layer,** works out one layer. The ASE read is a harmonic extension on an observation star, and every deterministic ADE layer is a guaranteed-descent step. It recombines partial records, has local Gaussian laws, admits truncation certificates, and interacts with the topology of design spaces.
- **Part III, The Vertical Stack,** stacks the layers. A stack separates into a starting term, a convex combination of reads and noise with a fixed budget. In the continuum limit it transports the archive density, and its tangents expand exactly where the layer energy has negative curvature. An exploratory pilot refuted hypothesis C3.
- **Part IV, Targets and Estimation,** asks what a run can estimate. The target is a declared Gibbs law; the archive is a proposal, not a target; clean tops cannot be importance-weighted; archive proposals have a width threshold; and every error in the weights enters an error ledger.
- **Part V, Fusion and Constraints,** separates products of experts, covariance intersection and marginal extension, shows that pairwise-consistent laws on a cycle can have no global law, and characterises when recombination preserves feasibility.
- **Part VI, Evidence and Computation,** gives stable and certified reads, the arithmetic of evidence for ASE comparisons, and the contracts that make an implementation defensible.

## The standard applied

Every new statement in this book carries a proof and a numerical check, and every quantity it computes is reproduced by two independent implementations. One is a Python script; the other is an immutable C# kernel, written with records, immutable arrays and pure functions, that regenerates the same random inputs from a shared SplitMix64 stream. Statements are tagged by provenance, as *Classical*, as taken from the conversion proposal (*V2*) or the *Mathematics book*, or as new in the part where they first appear. Where an exploration contradicted a hypothesis, the contradiction is reported; where a bound was loose, the looseness is measured.

The book claims a mathematics, not a performance result. It does not show that ASE finds better designs than ADE or any other method. The hypotheses that would show it, C1 to C5 of the conversion proposal, are listed with their status in the Afterword. Four remain open, and one was refuted in exploration.

## How to read the book

The parts are meant to be read in order, but each can be read alone. Each part begins with a summary, which was the abstract of the original paper, and ends with its own references and appendices. Section, equation, table and figure numbers restart in each part. A reference such as "Proposition 3.5" means the statement in the same part. References across parts name the part, as in "Part II, Proposition 3.5". Each part's reference list is numbered independently.

The Register of Results at the end of the book lists every definition, theorem, proposition, lemma, corollary and example by part, with its name. It serves as an index. The Glossary defines the terms that recur across parts.

## Correspondence with the plan

The conversion proposal planned nineteen chapters in six parts [S3, Section 21]. Table F.1 shows where each planned chapter is treated. Three planned topics are not yet covered, and two are covered only in part. They are listed as gaps rather than hidden.

Table: **Table F.1.** The nineteen planned chapters and where this edition treats them.

| Planned chapter | Where treated | Coverage |
|:------------------------|:------------------------|:----------------|
| 1 Sheaves on covers | Part I, Sections 2–3 | full |
| 2 Representations of layer order | Part I, Sections 4–5 | full |
| 3 Sheaf attention | Part II, Sections 2–3 | full |
| 4 Gaussian models in a stalk | Part II, Section 4 | full |
| 5 Scale locality and covers | Part II, Section 5; Part VI, Section 2.3 | full |
| 6 Topology of design spaces | Part II, Section 6 | full |
| 7 The token recurrence | Part III, Sections 2–3 | full |
| 8 Tangent dynamics | Part III, Section 4 | full |
| 9 Persistence across layers | Part III, Section 5 | full |
| 10 Gibbs targets and local representations | Part IV, Section 2 | full |
| 11 Predictable geometry and weights | Part IV, Section 3 | full |
| 12 Consistency of sheaf reads | Part IV, Proposition 2.3, for fixed maps | partial: adaptive fits and uniform control not treated |
| 13 Concentration and penalties | Part V, Proposition 4.2 | partial: concentration of targets not treated |
| 14 Orders and global preferences | — | not treated: Pareto orders and scalarisations |
| 15 Fusion and marginal extension | Part V, Sections 2–3 | full |
| 16 Optimisation over compatible sections | Part V, Section 4 | partial: multipliers not treated |
| 17 Information and admission | Part IV, Section 3; Part VI, Section 3 | full for effective size and selection; free energy not treated |
| 18 Dependencies and release | Part VI, Section 4 | partial: versioned caches not treated |
| 19 Stable numerical kernels | Part VI, Section 2; Appendix A of every part | full |

## Notation common to all parts

Designs live in $ℝ^D$. Records $y_i$ carry prior weights $w_i$, and a layer at scale $s$ reads them through a Gaussian kernel. With identity maps, the read is $m(z,s)=\sum_i\alpha_iy_i$ with weights $\alpha_i\propto w_ie^{-\Vert z-y_i\Vert^2/2s^2}$. With edge maps $Q_i$ and observations $o_i$, it is the harmonic extension $m=H^{-1}\sum_i\alpha_iQ_i^{\top}o_i$ with $H=\sum_i\alpha_iQ_i^{\top}Q_i$. Layers are numbered from the bottom, $t=T$, to the top, $t=1$, and the output is $z_0$. A clean top has $s_0=0$. Each part lists its own notation in its first section.

## Acknowledgements

The book builds on the two ADE volumes and on the conversion proposal, and on the published mathematics cited in each part. Errors that remain are the author's.
