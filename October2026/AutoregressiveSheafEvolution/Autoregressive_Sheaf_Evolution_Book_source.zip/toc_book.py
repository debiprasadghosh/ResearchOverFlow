"""Static contents with page numbers (two passes): entries are level-1 and level-2 headings of book_body.md."""
import re, json, os
md = open("book_body.md", encoding="utf-8").read()
reg = md.index("# Register of Results")
ents = [(len(m[1]), m[2].strip()) for m in re.finditer(r"^(#{1,2}) (.+)$", md, re.M) if not (len(m[1]) == 2 and m.start() > reg)]
clean = lambda t: re.sub(r"[\\$*`]", "", t)
pages = json.load(open("pages.json")) if os.path.exists("pages.json") else {}
rows = ["# Contents", "", "| | |", "|:" + "-" * 80 + "|" + "-" * 9 + ":|"]
for i, (lvl, t) in enumerate(ents):
    rows.append(f"| {'**' + clean(t) + '**' if lvl == 1 else ' ' + clean(t)} | {pages.get(str(i), '000')} |")
open("toc.md", "w", encoding="utf-8").write("\n".join(rows) + "\n")
json.dump([clean(t) for _, t in ents], open("entries.json", "w"))
print(len(ents), "entries")
