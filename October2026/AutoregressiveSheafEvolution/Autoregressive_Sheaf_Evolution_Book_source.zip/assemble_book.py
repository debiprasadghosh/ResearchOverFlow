"""Assemble the six part papers, front matter and back matter into book.md."""
import os, re
H = os.path.dirname(os.path.abspath(__file__)); S = os.path.dirname(H)
PARTS = [("p1", "I"), ("p2", "II"), ("p3", "III"), ("p4", "IV"), ("p5", "V"), ("p6", "VI")]
KINDS = "Definition|Theorem|Proposition|Lemma|Corollary|Example|Remark|Counterexample"


def split_yaml(s):
    a = s.index("---"); b = s.index("\n---", a + 3)
    head, body = s[a + 3:b], s[b + 4:]
    title = re.search(r'^title: "(.*)"', head, re.M)[1]
    sub = re.search(r'^subtitle: "(.*)"', head, re.M)[1]
    abst = re.search(r"^abstract: \|\n((?:  .*\n?)+)", head, re.M)[1]
    return title, sub, re.sub(r"^  ", "", abst, flags=re.M).strip(), body


register = []; parts_md = []
for d, roman in PARTS:
    s = open(os.path.join(S, d, "paper.md"), encoding="utf-8").read()
    title, sub, abst, body = split_yaml(s)
    figdir = os.path.join(S, d, "fig")
    body = re.sub(r"\]\(fig/", "](" + figdir + "/", body)
    body = re.sub(r"^(#+) ", r"#\1 ", body, flags=re.M)                       # demote one level
    body = re.sub(r"^## References$", f"## References for Part {roman}", body, flags=re.M)
    body = re.sub(r"^## Appendix ([A-Z])", rf"## Appendix {roman}.\1", body, flags=re.M)
    # statements for the register
    for m in re.finditer(rf"\*\*({KINDS}) (\d+(?:\.\d+)*)\*\*\s*\(([^\n]*?)\)[\.\s]", body):
        name = re.sub(r"\s*\[[\d,\s–-]+\]", "", m[3]).strip()
        register.append((roman, m[1], m[2], name))
    parts_md.append(f"# Part {roman} · {title}\n\n::: {{custom-style=\"Subtitle\"}}\n{sub}\n:::\n\n"
                    f"**Summary of Part {roman}.** {abst}\n\n{body.strip()}\n")

seen = set(); rows = []
for r in register:
    if (r[0], r[1], r[2]) in seen:
        continue
    seen.add((r[0], r[1], r[2])); rows.append(r)
reg = []
for d, roman in PARTS:
    rr = [r for r in rows if r[0] == roman]
    reg.append(f"## Part {roman}\n\n| Statement | Name |\n|:--------------|:------------------------------------------|\n" +
               "\n".join(f"| {k} {n} | {nm.replace('|', '/')} |" for _, k, n, nm in rr) + "\n")
front = open(os.path.join(H, "front.md"), encoding="utf-8").read()
back = open(os.path.join(H, "back.md"), encoding="utf-8").read().replace("{{register}}", "\n".join(reg))
yaml = ('---\ntitle: "Autoregressive Sheaf Evolution"\nsubtitle: "Horizontally topological, vertically algebraic: '
        'a mathematics of layered design search, in six parts"\nauthor:\n  - "Debi Prasad Ghosh"\n'
        '  - "Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India"\n'
        'date: "Defensible Intelligence series · First edition · 22 October 2026 · “Respect science. Import emotion.”"\n---\n\n')
body = front + "\n\n" + "\n\n".join(parts_md) + "\n\n" + back
open(os.path.join(H, "book_body.md"), "w", encoding="utf-8").write(body)
toc = open(os.path.join(H, "toc.md"), encoding="utf-8").read() if os.path.exists(os.path.join(H, "toc.md")) else ""
body = body.replace("# Preface", toc + "\n# Preface", 1)
book = yaml + body
open(os.path.join(H, "book.md"), "w", encoding="utf-8").write(book)
print("words", len(book.split()), "statements", len(rows), {r: sum(1 for x in rows if x[0] == r) for _, r in PARTS})
