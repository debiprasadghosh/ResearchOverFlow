import json, subprocess, re
ents = json.load(open("entries.json"))
n = int(re.search(r"Pages:\s+(\d+)", subprocess.run(["pdfinfo", "ASE_Book.pdf"], capture_output=True, text=True).stdout)[1])
pg = [subprocess.run(["pdftotext", "-f", str(p), "-l", str(p), "-layout", "ASE_Book.pdf", "-"], capture_output=True, text=True).stdout for p in range(1, n + 1)]
norm = lambda s: re.sub(r"\s+", " ", s).strip()
lines = [[norm(l) for l in t.splitlines() if l.strip()] for t in pg]
start = next(i for i, ls in enumerate(lines) if ls[:3] and any(l == "Preface" for l in ls[:3]))
out = {}; cur = start
for i, e in enumerate(ents):
    key = norm(e)[:45]
    for p in range(cur, n):
        if any(l.startswith(key) for l in lines[p][:60]):
            out[str(i)] = p + 1; cur = p; break
    else:
        print("missing", e)
json.dump(out, open("pages.json", "w")); print(len(out), "found of", len(ents))
