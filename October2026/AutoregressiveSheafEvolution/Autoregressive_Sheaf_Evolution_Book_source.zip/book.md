---
title: "Autoregressive Sheaf Evolution"
subtitle: "Horizontally topological, vertically algebraic: a mathematics of layered design search, in six parts"
author:
  - "Debi Prasad Ghosh"
  - "Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India"
date: "Defensible Intelligence series · First edition · 22 October 2026 · “Respect science. Import emotion.”"
---

::: {custom-style="Front Note"}
**Autoregressive Sheaf Evolution**

*Horizontally topological, vertically algebraic: a mathematics of layered design search*

First edition, 22 October 2026.

Defensible Intelligence series. “Respect science. Import emotion.”

© 2026 Debi Prasad Ghosh, Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India. All rights reserved.

The six parts of this book were first prepared as separate papers between 18 and 21 October 2026. They are reproduced here with their numbering, proofs, numerical checks and reference kernels intact. The front and back matter are new to this edition, and so is the correction to the register of hypotheses in Part VI.

The numerical results in this book were produced by the scripts and C# kernels described in the appendices of each part. They are checks of mathematics and exploratory computations on declared synthetic examples. No result in this book is a confirmatory test of search performance.
:::

# Contents

| | |
|:--------------------------------------------------------------------------------|---------:|
| **Preface** | 6 |
|  What the book does | 6 |
|  The standard applied | 6 |
|  How to read the book | 7 |
|  Correspondence with the plan | 7 |
|  Notation common to all parts | 8 |
|  Acknowledgements | 8 |
| **Part I · Horizontally Topological, Vertically Algebraic** | 9 |
|  1 Introduction | 9 |
|  2 Finite posets and the bases of ASE | 12 |
|  3 The horizontal axis: sheaves on covers | 14 |
|  4 The vertical axis: representations of the layer order | 22 |
|  5 The product: one sheaf for the whole stack | 27 |
|  6 Register of numerical checks | 31 |
|  7 Discussion | 32 |
|  References for Part I | 33 |
|  Appendix I.A: an immutable C# reference kernel | 34 |
|  Appendix I.B: reproducibility | 37 |
| **Part II · The Horizontal Layer** | 38 |
|  1 Introduction | 38 |
|  2 The observation star and the layer contract | 40 |
|  3 Sheaf attention | 42 |
|  4 Gaussian models in a stalk | 49 |
|  5 Scale, locality and covers | 54 |
|  6 Topology of design spaces | 58 |
|  7 Register of numerical checks | 63 |
|  8 Discussion | 65 |
|  References for Part II | 66 |
|  Appendix II.A: an immutable C# reference kernel | 67 |
|  Appendix II.B: reproducibility | 71 |
| **Part III · The Vertical Stack** | 72 |
|  1 Introduction | 72 |
|  2 The stack and its schedule | 75 |
|  3 The token recurrence | 77 |
|  4 Tangent dynamics | 81 |
|  5 Persistence across layers | 85 |
|  6 Register of numerical checks | 92 |
|  7 Discussion | 93 |
|  References for Part III | 95 |
|  Appendix III.A: an immutable C# reference kernel | 95 |
|  Appendix III.B: reproducibility | 101 |
| **Part IV · Targets and Estimation** | 102 |
|  1 Introduction | 102 |
|  2 Targets | 104 |
|  3 Proposals | 105 |
|  4 Critic and density error | 109 |
|  5 An error ledger | 111 |
|  6 Discussion | 112 |
|  7 Register of numerical checks | 114 |
|  References for Part IV | 114 |
|  Appendix IV.A: an immutable C# reference kernel | 115 |
|  Appendix IV.B: reproducibility | 118 |
| **Part V · Fusion and Constraints** | 119 |
|  1 Introduction | 119 |
|  2 Fusion of local laws | 120 |
|  3 Marginal extension on covers | 122 |
|  4 Constraints | 124 |
|  5 Explorations | 125 |
|  6 Discussion | 126 |
|  7 Register of numerical checks | 128 |
|  References for Part V | 128 |
|  Appendix V.A: an immutable C# reference kernel | 129 |
|  Appendix V.B: reproducibility | 132 |
| **Part VI · Evidence and Computation** | 133 |
|  1 Introduction | 133 |
|  2 Computation | 134 |
|  3 Evidence | 136 |
|  4 Contracts of an ASE implementation | 138 |
|  5 Discussion | 140 |
|  6 Register of numerical checks | 141 |
|  References for Part VI | 142 |
|  Appendix VI.A: an immutable C# reference kernel | 142 |
|  Appendix VI.B: reproducibility | 145 |
| **Afterword: what the six parts establish and what remains** | 146 |
|  The hypotheses of the conversion proposal | 146 |
|  Work for the next edition | 147 |
| **Register of Results** | 148 |
| **Glossary** | 154 |
| **Works in this series** | 156 |
| **About the author** | 157 |

# Preface

This book began with a reading of denoising diffusion as a search procedure. Autoregressive Diffusion Evolution (ADE) runs tokens down a denoising stack whose layers read an archive of evaluated designs [S1, S2]. Each layer forms a Gaussian-weighted average of the archived designs near the token and moves the token towards it. The archive grows as new designs are evaluated, and the loop repeats. ADE treats the design space as one Euclidean space with one retrieval geometry.

Engineering design spaces are rarely like that. Different parts of a design are described in different coordinates. Some records observe only some variables, symmetric designs have several representations, and branches of a design family must not be averaged. The conversion proposal of 18 October 2026 therefore replaced ADE's single retrieval geometry by local data spaces, compatibility maps and scale-dependent covers [S3]. It named the result Autoregressive Sheaf Evolution (ASE), stated its organising principle, *horizontally topological within each layer and vertically algebraic across layers*, and proposed a six-part book. This is that book.

## What the book does

Each part is a self-contained mathematical paper.

- **Part I, The Two Axes,** makes the organising principle exact. Within a layer, local data form a sheaf on a cover, and agreement and disagreement are measured by cohomology. Across layers, the journey of a token is a representation of the layer order, with barcodes. A fixed-base product packages both axes into one sheaf, and ADE is its trivial case.
- **Part II, The Horizontal Layer,** works out one layer. The ASE read is a harmonic extension on an observation star, and every deterministic ADE layer is a guaranteed-descent step. It recombines partial records, has local Gaussian laws, admits truncation certificates, and interacts with the topology of design spaces.
- **Part III, The Vertical Stack,** stacks the layers. A stack separates into a starting term, a convex combination of reads and noise with a fixed budget. In the continuum limit it transports the archive density, and its tangents expand exactly where the layer energy has negative curvature. An exploratory pilot refuted hypothesis C3.
- **Part IV, Targets and Estimation,** asks what a run can estimate. The target is a declared Gibbs law; the archive is a proposal, not a target; clean tops cannot be importance-weighted; archive proposals have a width threshold; and every error in the weights enters an error ledger.
- **Part V, Fusion and Constraints,** separates products of experts, covariance intersection and marginal extension, shows that pairwise-consistent laws on a cycle can have no global law, and characterises when recombination preserves feasibility.
- **Part VI, Evidence and Computation,** gives stable and certified reads, the arithmetic of evidence for ASE comparisons, and the contracts that make an implementation defensible.

## The standard applied

Every new statement in this book carries a proof and a numerical check, and every quantity it computes is reproduced by two independent implementations. One is a Python script; the other is an immutable C# kernel, written with records, immutable arrays and pure functions, that regenerates the same random inputs from a shared SplitMix64 stream. Statements are tagged by provenance, as *Classical*, as taken from the conversion proposal (*V2*) or the *Mathematics book*, or as new in the part where they first appear. Where an exploration contradicted a hypothesis, the contradiction is reported; where a bound was loose, the looseness is measured.

The book claims a mathematics, not a performance result. It does not show that ASE finds better designs than ADE or any other method. The hypotheses that would show it, C1 to C5 of the conversion proposal, are listed with their status in the Afterword. Four remain open, and one was refuted in exploration.

## How to read the book

The parts are meant to be read in order, but each can be read alone. Each part begins with a summary, which was the abstract of the original paper, and ends with its own references and appendices. Section, equation, table and figure numbers restart in each part. A reference such as "Proposition 3.5" means the statement in the same part. References across parts name the part, as in "Part II, Proposition 3.5". Each part's reference list is numbered independently.

The Register of Results at the end of the book lists every definition, theorem, proposition, lemma, corollary and example by part, with its name. It serves as an index. The Glossary defines the terms that recur across parts.

## Correspondence with the plan

The conversion proposal planned nineteen chapters in six parts [S3, Section 21]. Table F.1 shows where each planned chapter is treated. Three planned topics are not yet covered, and two are covered only in part. They are listed as gaps rather than hidden.

Table: **Table F.1.** The nineteen planned chapters and where this edition treats them.

| Planned chapter | Where treated | Coverage |
|:------------------------|:------------------------|:----------------|
| 1 Sheaves on covers | Part I, Sections 2–3 | full |
| 2 Representations of layer order | Part I, Sections 4–5 | full |
| 3 Sheaf attention | Part II, Sections 2–3 | full |
| 4 Gaussian models in a stalk | Part II, Section 4 | full |
| 5 Scale locality and covers | Part II, Section 5; Part VI, Section 2.3 | full |
| 6 Topology of design spaces | Part II, Section 6 | full |
| 7 The token recurrence | Part III, Sections 2–3 | full |
| 8 Tangent dynamics | Part III, Section 4 | full |
| 9 Persistence across layers | Part III, Section 5 | full |
| 10 Gibbs targets and local representations | Part IV, Section 2 | full |
| 11 Predictable geometry and weights | Part IV, Section 3 | full |
| 12 Consistency of sheaf reads | Part IV, Proposition 2.3, for fixed maps | partial: adaptive fits and uniform control not treated |
| 13 Concentration and penalties | Part V, Proposition 4.2 | partial: concentration of targets not treated |
| 14 Orders and global preferences | — | not treated: Pareto orders and scalarisations |
| 15 Fusion and marginal extension | Part V, Sections 2–3 | full |
| 16 Optimisation over compatible sections | Part V, Section 4 | partial: multipliers not treated |
| 17 Information and admission | Part IV, Section 3; Part VI, Section 3 | full for effective size and selection; free energy not treated |
| 18 Dependencies and release | Part VI, Section 4 | partial: versioned caches not treated |
| 19 Stable numerical kernels | Part VI, Section 2; Appendix A of every part | full |

## Notation common to all parts

Designs live in $ℝ^D$. Records $y_i$ carry prior weights $w_i$, and a layer at scale $s$ reads them through a Gaussian kernel. With identity maps, the read is $m(z,s)=\sum_i\alpha_iy_i$ with weights $\alpha_i\propto w_ie^{-\Vert z-y_i\Vert^2/2s^2}$. With edge maps $Q_i$ and observations $o_i$, it is the harmonic extension $m=H^{-1}\sum_i\alpha_iQ_i^{\top}o_i$ with $H=\sum_i\alpha_iQ_i^{\top}Q_i$. Layers are numbered from the bottom, $t=T$, to the top, $t=1$, and the output is $z_0$. A clean top has $s_0=0$. Each part lists its own notation in its first section.

## Acknowledgements

The book builds on the two ADE volumes and on the conversion proposal, and on the published mathematics cited in each part. Errors that remain are the author's.


# Part I · Horizontally Topological, Vertically Algebraic

::: {custom-style="Subtitle"}
The two axes of Autoregressive Sheaf Evolution. Part I: sheaves on covers and representations of the layer order
:::

**Summary of Part I.** Autoregressive Sheaf Evolution (ASE) replaces the single Euclidean retrieval geometry of Autoregressive Diffusion Evolution (ADE) by local data spaces on every layer of a stack. Its organising principle is that each layer is horizontally topological and each token's journey is vertically algebraic. This paper, the first part of the ASE book, makes the principle precise, proves what it delivers and marks where it stops. The horizontal axis is a cellular data sheaf on the nerve of a layer cover. Its stalks are data spaces, not charts; its sections are compatible assignments; residuals are coboundaries; cohomology measures the edge data that no assignment explains. We prove residual bounds with declared units, a holonomy theorem for orthogonal sheaves that contains Harary's balance theorem, and a cohomology formula for coordinate sheaves on variable contexts. We also separate three obstructions that are easily conflated: linear H¹ classes, additive angle torsors and multiplicative sign holonomy. The vertical axis is a representation of the layer order. Every specified transport, tangent or homogenised affine diagram decomposes into interval modules. We show that a clean top produces births at the top, that homogenisation adds exactly one full bar, that exact bars usually survive while sensitivity contracts, and that layer cohomology has only full bars when the layers use nested Leray covers of one space. The central new result is vertical acyclicity: for every sheaf on the product of a base with the layer order, cohomology equals that of the bottom layer. The vertical axis therefore carries no cohomology, and its information lives in barcodes; the slogan becomes a theorem. A zigzag of layers is not acyclic. ADE is the trivial product with a separate observation star. Twenty numerical checks, and an immutable C# kernel that matches an independent NumPy implementation line for line, support every quantitative statement.

## 1 Introduction

Autoregressive Diffusion Evolution (ADE) treats an archive of evaluated designs as the memory of a denoising stack [16, 17]. A token starts at the bottom of a stack of layers $t=T,\ldots,1,0$. At each layer it reads the archive through a Gaussian kernel at scale $s_t$ and moves towards the read. In the scaled coordinate used by the conversion proposal [19, Proposition 6.2], with records $y_i$, prior weights $w_i$ and $s_t^2=(1-a_t)/a_t$,

::: {custom-style="Equation"}
$m_t(z)=\sum_i \alpha_i(z)\,y_i,\quad \alpha_i(z)\propto w_i\exp\left(-\frac{\|z-y_i\|^2}{2s_t^2}\right),\quad z_{t-1}=(1-\lambda_t)\,z_t+\lambda_t\,m_t(z_t)+\nu_t$ (1.1)
:::

where $\nu_t$ is the scaled noise increment. Every layer uses the same retrieval geometry: one Euclidean space, one distance and one global read.

The revised conversion proposal [19], cited below as V2, replaces that single geometry by local data spaces, compatibility maps and scale-dependent covers. It states the organising principle in one line: horizontal topology within each layer and vertical algebra across layers (Figure 1). This paper is Part I of the resulting six-part book, covering its first two chapters: sheaves on covers, and representations of the layer order. Its task is to make the principle mathematically precise, to prove what it delivers and to mark where it stops.

![**Figure 1.** The two axes. Each layer carries a cover at its scale, the nerve of the cover and a data sheaf on the nerve (left). A token visits one cell per layer; the data spaces of the visited cells and the maps between them form the token's vertical fibre diagram, a representation of the layer order (right). The small squares mark the stalk at the visited cell.](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p1/fig/stack.png){width=96%}

### 1.1 The principle as mathematics

*Horizontal.* A layer is a base with a finite cover. The nerve of the cover carries a cellular data sheaf. Stalks are data spaces attached to cells, and restriction maps say how the data on a cell are observed on an overlap. A section is a compatible assignment, a residual is a coboundary, and cohomology measures what cannot be made compatible.

*Vertical.* A token's journey produces a diagram of linear maps indexed by the layer order. Such a diagram is a representation of a finite linear order and decomposes into interval modules; its barcode is a complete invariant. The cohomology of the layers, compared across layers, forms another such representation.

*Product.* The two axes combine into one sheaf on the product of a base with the layer order. The main new theorem of this paper, Theorem 5.3, says that the cohomology of every such sheaf equals the cohomology of its bottom layer. Whatever the stack does above the bottom is invisible to the cohomology of the product and visible only to the representation theory of the layer order. Vertical algebra is therefore not a modelling preference: it is the only place where vertical information can be read.

### 1.2 Contributions

- **A typed vocabulary.** Four bases are kept distinct: the cover nerve, the context nerve, the layer order and the observation star (Definition 2.4). Stalks are data spaces, restrictions run from vertices to overlaps, and residuals carry declared units.
- **Horizontal results.** We show that the coboundary squares to zero exactly when every diamond of restriction maps commutes, which in degree one are the triangle compatibility identities (Proposition 3.5), and prove a residual sandwich with its Hodge split (Proposition 3.7). We also give nerves with coefficients, including a two-arc example in which the coefficients rather than the nerve carry the loop (Theorem 3.9, Example 3.10). For orthogonal sheaves we prove a holonomy theorem with a dimension formula and Harary's theorem as a corollary (Theorem 3.12, Corollary 3.13), and show that filled triangles are flat (Proposition 3.14). Three obstructions are separated (Proposition 3.16), and coordinate sheaves on contexts receive a cohomology formula (Proposition 3.19).
- **Vertical results.** Homogenisation adds exactly one full bar (Proposition 4.4), and a clean top produces births at the top (Proposition 4.5). The tangent rank equals the affine dimension of the records, so exact bars survive while effective rank contracts (Proposition 4.6). Leray covers give full bars in layer cohomology (Proposition 4.8). Component counts are stable under perturbation (Proposition 4.11).
- **The product.** We give a slice description of the fixed-base product (Proposition 5.1) and prove vertical acyclicity (Theorem 5.3). A zigzag counterexample shows that the theorem needs a least element (Remark 5.5). Moving tokens become fixed-base diagrams in Lagrangian coordinates (Proposition 5.7), and ADE is the trivial product (Proposition 5.9).
- **Evidence.** Twenty numerical checks reproduce every quantitative statement (Table 3), and an immutable C# kernel agrees line for line with an independent NumPy implementation (Appendix A).

### 1.3 Scope and status of statements

Part I is foundational. It makes no claim about search performance, sampling validity or engineering feasibility; those belong to Parts II to VI, and V2 lists the falsifiable hypotheses C1 to C5 that will test them. Every statement in a shaded box ends with a provenance tag. *Classical* means a known result restated in ASE notation. *V2* means a statement of the conversion proposal, sometimes with a new proof. *New in Part I* means a statement proved here for the first time in this programme. New statements carry proofs and numerical checks. All vector spaces are finite dimensional and real. The algebraic statements hold over any field; orthogonality, norms and eigenvalues use the real inner product.

### 1.4 Conventions and notation

Table: **Table 1.** Notation used throughout Part I.

| Symbol | Meaning |
|:--------------|:--------------------------------------------------------------|
| $t=T,\ldots,0$ | layers, traversed from the bottom ($T$) to the top ($0$) |
| $P$ | the layer order $T<T-1<\cdots<0$ with the Alexandrov topology of up-sets |
| $\uparrow t$ | the up-set $\{t,t-1,\ldots,0\}$, the smallest open set containing $t$ |
| $X_t,\ 𝒰_t,\ N_t$ | base, finite open cover and nerve at layer $t$ |
| $F(\sigma),\ r_{\sigma\tau}$ | stalk on the cell $\sigma$ and restriction for $\sigma\le\tau$ |
| $C^k,\ \delta,\ H^k$ | cochains, coboundary and cohomology |
| $W,\ L=\delta^{\top}W\delta$ | positive definite edge weights in declared units, sheaf Laplacian |
| $V_t,\ \rho_t$ | data space of the visited cell, vertical map $V_t\to V_{t-1}$ |
| $𝕀[b,d]$ | interval module born at layer $b$ and alive up to layer $d$, with $b\ge d$ |
| $\Phi_t,\ \Phi_t^{-1}$ | deterministic step $X\to X$ and inverse image of sheaves |
| $Q$ | a finite poset, usually the face poset of a nerve |

## 2 Finite posets and the bases of ASE

Every base in ASE is either a finite poset or is replaced by one for computation, usually the face poset of a nerve. Finite posets carry a topology in which sheaves become diagrams of vector spaces, so that all sheaf theory used in Part I reduces to linear algebra.

::: {custom-style="Statement"}
**Definition 2.1** (Alexandrov topology [2]). Let $(Q,\le)$ be a finite poset. A subset $U\subseteq Q$ is open when it is an up-set: $p\in U$ and $p\le q$ imply $q\in U$. The set $\uparrow p=\{q: q\ge p\}$ is the smallest open set containing $p$, and these sets form a basis.
:::

::: {custom-style="Statement Tag"}
Classical.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Proposition 2.2** (sheaves on a finite poset). Let $Q$ be a finite poset with its Alexandrov topology.
:::

::: {custom-style="Statement"}
\(i) The assignment $ℱ\mapsto F$, $F(p)=ℱ(\uparrow p)$, is an equivalence between sheaves of real vector spaces on $Q$ and functors $F:Q\to\text{Vect}$, where $Q$ has one arrow $p\to q$ whenever $p\le q$. The stalk at $p$ is $F(p)$, and the restriction for $p\le q$ is the map $F(p\le q):F(p)\to F(q)$.
:::

::: {custom-style="Statement"}
\(ii) Global sections are the limit: $\Gamma(Q;F)=\text{lim}_Q F=\{(x_p)\in\prod_p F(p): F(p\le q)\,x_p=x_q\}$.
:::

::: {custom-style="Statement"}
\(iii) Sheaf cohomology is the derived limit, $H^k(Q;F)\cong R^k\text{lim}_Q F$. It is computed by the cochain complex whose degree-$n$ term is the product of the spaces $F(p_n)$ over the strictly increasing chains $p_0<\cdots<p_n$, with differential
:::

::: {custom-style="Statement Equation"}
$(dx)(c)=\sum_{k=0}^{n}(-1)^k\,x(\partial_kc)+(-1)^{n+1}F(p_n\le p_{n+1})\,x(\partial_{n+1}c)$ (2.1)
:::

::: {custom-style="Statement"}
Here $c=(p_0<\cdots<p_{n+1})$ and $\partial_kc$ deletes $p_k$ from the chain.
:::

::: {custom-style="Statement Tag"}
Classical [8, 14, 25].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Every open cover of $\uparrow p$ contains $\uparrow p$ itself, because some member contains $p$ and is an up-set. The sheaf condition on basic open sets is therefore empty, and a sheaf is the same as a presheaf on the basis. Since $\uparrow q\subseteq\uparrow p$ exactly when $p\le q$, that basis category is $Q$. Gluing over the cover $\{\uparrow p\}_{p\in U}$ gives $ℱ(U)=\text{lim}_{p\in U}F(p)$, which proves (i) and, for $U=Q$, (ii). Sheaf cohomology is the right derived functor of global sections, here the derived limit. The Bousfield–Kan cosimplicial replacement computes derived limits [8], and normalisation keeps only strictly increasing chains, which gives (2.1). ∎

::: {custom-style="Statement"}
**Proposition 2.3** (cellular cohomology is sheaf cohomology). Let $K$ be a finite simplicial complex with face poset $𝒫(K)$ and let $F$ be a cellular sheaf on $K$ (Definition 3.2). The cohomology of the cellular cochain complex of Definition 3.4 is isomorphic to $R^k\text{lim}_{𝒫(K)}F$.
:::

::: {custom-style="Statement Tag"}
Classical [14, 29].
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* The complex (2.1) and the cellular complex were computed independently on three sheaves on a triangle. The constant sheaf on the hollow triangle gives $(1,1,0)$ against cellular $(1,1)$; a sign-twisted sheaf gives $(0,0,0)$ against $(0,0)$; the constant sheaf on the filled triangle gives $(1,0,0)$ against $(1,0,0)$.
:::

ASE uses four different bases. They are all finite posets, and they answer different questions. Confusing them is the most common source of wrong statements in the earlier drafts, so we fix them now.

::: {custom-style="Statement"}
**Definition 2.4** (the four bases of ASE). Each sheaf in an ASE implementation records which of the following bases it lives on.
:::

::: {custom-style="Statement"}
\(a) *Cover base.* At layer $t$, a finite open cover $𝒰_t$ of the region of $X_t$ visited by tokens, its nerve $N_t$ and the face poset of $N_t$. It describes spatial locality, and the horizontal data sheaves live on it.
:::

::: {custom-style="Statement"}
\(b) *Context base.* A family of variable subsets $S_1,\ldots,S_k\subseteq\{1,\ldots,D\}$, with its nerve (a simplex whenever the contexts share a variable) or its pairwise graph. It describes partial information and objective incidence. An incidence hypergraph is not automatically the nerve of an open cover of design space.
:::

::: {custom-style="Statement"}
\(c) *Layer order.* The chain $P$ of Table 1. It describes computation depth, and the vertical diagrams live on it.
:::

::: {custom-style="Statement"}
\(d) *Observation star.* At one layer, a token vertex joined to one leaf per retrieved record. The token stalk is the token frame, a leaf stalk is the record space and an edge stalk is a common observation space, reached from the token by $Q_i$ and from the record by $R_i$. The harmonic read of Part II is the harmonic extension of the record values over this star [19, Proposition 5.1]. The star is auxiliary and is never the cover nerve.
:::

::: {custom-style="Statement Tag"}
V2 Section 1, made a definition.
:::

::: {custom-style="Gap"}
&nbsp;
:::

![**Figure 2.** The four bases. (a) A cover by four disks and its nerve, with both triangles filled because their triple intersections are nonempty. (b) Three contexts that share the variable 1. (c) The layer order from the bottom $T$ to the top $0$. (d) The observation star of one token and seven retrieved records.](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p1/fig/bases.png){width=100%}

The distinction between (a) and (d) resolves an apparent paradox noted in V2. ADE has a one-vertex cover nerve at every layer, yet it reads a nontrivial archive. The nerve describes the base geometry; the star describes the observations attached to it (Proposition 5.9).


## 3 The horizontal axis: sheaves on covers

### 3.1 Layer covers and data sheaves

::: {custom-style="Statement"}
**Definition 3.1** (layer cover). Fix layers $t=T,\ldots,1,0$, traversed from bottom to top, a schedule $0<a_t\le a_{t-1}\le 1$ and the scale $s_t=\sqrt{(1-a_t)/a_t}$. Each layer has a base $X_t$ and a finite open cover $𝒰_t=\{U_i\}_{i\in I_t}$ of the region visited by its tokens. Its nerve $N_t$ has a simplex $\sigma\subseteq I_t$ whenever $U_\sigma=\bigcap_{i\in\sigma}U_i$ is nonempty. A cover diameter near $\kappa s_t$ is a resolution policy, not an existence theorem for a good cover.
:::

::: {custom-style="Statement Tag"}
V2 Definition 2.1.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Definition 3.2** (cellular data sheaf). A cellular sheaf $F$ on a simplicial complex $K$ assigns a finite-dimensional real vector space $F(\sigma)$, the stalk, to every simplex $\sigma$, and a linear map $r_{\sigma\tau}:F(\sigma)\to F(\tau)$ to every face relation $\sigma\le\tau$, such that $r_{\sigma\sigma}=I$ and $r_{\tau\rho}\,r_{\sigma\tau}=r_{\sigma\rho}$ whenever $\sigma\le\tau\le\rho$. The maps run from a vertex to its overlaps. A graph sheaf specifies only vertex and edge stalks. To extend it over a triangle $\tau$, one must give $F(\tau)$ and maps $r_{e\tau}$ satisfying, for each vertex $u$ of $\tau$ and the two edges $e,e'$ of $\tau$ through $u$,
:::

::: {custom-style="Statement Equation"}
$r_{e\tau}\,r_{ue}=r_{e'\tau}\,r_{ue'}$ (3.1)
:::

::: {custom-style="Statement Tag"}
V2 Definition 2.2, with the triangle identities made explicit [3, 5, 14].
:::

::: {custom-style="Gap"}
&nbsp;
:::

A stalk is the data space attached to one cell [27]. It need not be a chart coordinate system, and the restriction maps need not be invertible. A rectangular restriction models a partial observation. An affine coordinate transition requires an affine sheaf or a torsor (Section 3.5), and nonlinear coordinate changes require sheaves of nonlinear objects, which Part I does not treat. Orthogonal restrictions form a tractable subclass (Section 3.4); they do not define what a sheaf is.

::: {custom-style="Statement"}
**Remark 3.3** (units before residuals). Before overlap residuals are compared, every edge stalk carries declared units and a weight $W_e\succ 0$ that makes $\|c\|_{W_e}^2=c^{\top}W_ec$ dimensionless, for instance $W_e=\text{diag}(1/\sigma_j^2)$ with $\sigma_j$ the tolerance of component $j$. If the units of an edge stalk change by an invertible matrix $S_e$, so that $c\mapsto S_ec$, the weight must change to $S_e^{-\top}W_eS_e^{-1}$. With that convention the energy, its kernel and every bound of Propositions 3.7 and 3.8 are unchanged. Without it, mixing displacement, stress and dimensionless utilisation changes the energy and the resulting read.
:::

::: {custom-style="Statement Tag"}
V2 Section 2, made quantitative.
:::

::: {custom-style="Gap"}
&nbsp;
:::

### 3.2 Cochains, residuals and cohomology

::: {custom-style="Statement"}
**Definition 3.4** (cochains, coboundary, residual). Order the vertices of $K$. For a $(k+1)$-simplex $\tau=\{v_0<\cdots<v_{k+1}\}$, let $\tau_i$ be the face opposite $v_i$. Set $C^k(K;F)=\bigoplus_{\text{dim}\,\sigma=k}F(\sigma)$ and
:::

::: {custom-style="Statement Equation"}
$(\delta x)_\tau=\sum_{i=0}^{k+1}(-1)^i\,r_{\tau_i\tau}\,x_{\tau_i}$ (3.2)
:::

::: {custom-style="Statement"}
For an edge $e=\{u<v\}$ this reads $(\delta x)_e=r_{ve}x_v-r_{ue}x_u$. Cohomology is $H^k=\text{ker}\,\delta^k/\text{im}\,\delta^{k-1}$. A section is a vertex assignment $x\in C^0$ with $\delta x=0$, so $H^0$ is the space of sections. The residual of an arbitrary assignment $x$ is $\delta x\in C^1$.
:::

::: {custom-style="Statement Tag"}
Classical [14, 20].
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Proposition 3.5** (the coboundary needs compatibility; Euler identity). Let restriction maps be given only for codimension-one faces.
:::

::: {custom-style="Statement"}
\(i) $\delta^{k+1}\delta^k=0$ for every $k$ if and only if every diamond commutes: for every simplex $\rho$ and every face $\sigma$ of codimension two in $\rho$, with $\tau,\tau'$ the two faces between them, $r_{\tau\rho}\,r_{\sigma\tau}=r_{\tau'\rho}\,r_{\sigma\tau'}$. In degree one these are exactly the triangle identities (3.1).
:::

::: {custom-style="Statement"}
\(ii) The diamonds commute exactly when the codimension-one maps extend to a cellular sheaf. Hence $\delta^2=0$ characterises cellular sheaves among such data, and without it $H^1$ is undefined.
:::

::: {custom-style="Statement"}
\(iii) $\sum_k(-1)^k\,\text{dim}\,C^k=\sum_k(-1)^k\,\text{dim}\,H^k$. On a graph,
:::

::: {custom-style="Statement Equation"}
$\text{dim}\,H^0-\text{dim}\,H^1=\sum_v\text{dim}\,F(v)-\sum_e\text{dim}\,F(e)$ (3.3)
:::

::: {custom-style="Statement Tag"}
Classical in substance; (i) is the reason for V2's triangle requirement.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) Let $\rho$ have dimension $k+2$ and let $\sigma$ be the face of $\rho$ missing the vertices $v_i$ and $v_j$, with $i<j$. The block of $\delta^{k+1}\delta^k$ in row $\rho$ and column $\sigma$ comes from the two intermediate faces, each missing one of these vertices. The two routes carry the signs $(-1)^j(-1)^i$ and $(-1)^i(-1)^{j-1}$, which are opposite, so the block is $\pm(r_{\tau\rho}r_{\sigma\tau}-r_{\tau'\rho}r_{\sigma\tau'})$. Every block vanishes exactly when every diamond commutes. (ii) If the diamonds commute, define $r_{\sigma\rho}$ as the composite along any maximal chain of faces from $\sigma$ to $\rho$. Two such chains add the missing vertices in different orders, and adjacent transpositions of that order, which are diamond moves, connect them, so the composite is well defined and compatible. The converse is immediate. (iii) Rank–nullity in each degree. ∎

::: {custom-style="Check"}
*Numerical check.* On a filled triangle with random vertex stalks, edge stalks $ℝ^4$ and triangle stalk $ℝ^2$, built to satisfy (3.1), the largest entry of $\delta^1\delta^0$ is 0. After one vertex-to-edge map is replaced by a random matrix it is 1.78. The alternating sums of cochain and cohomology dimensions agree (−2 and −2).
:::

A residual is always a coboundary. A nonzero disagreement $\delta x$ is therefore never itself a nonzero cohomology class. Cohomology in degree one measures something else: edge data that no assignment can produce. The next proposition makes both statements quantitative.

::: {custom-style="Statement"}
**Proposition 3.6** (positive sheaf energy). Let $W=\bigoplus_eW_e$ be positive definite on $C^1$, with the units of Remark 3.3. The energy $E(x)=\frac{1}{2}\|\delta x\|_W^2=\frac{1}{2}x^{\top}Lx$, with $L=\delta^{\top}W\delta$, is positive semidefinite and $\text{ker}\,L=H^0$.
:::

::: {custom-style="Statement Tag"}
V2 Lemma 2.3; $L$ is the sheaf Laplacian [20].
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Proposition 3.7** (distance to consistency; Hodge split). Let $F$ be a graph sheaf, $P$ the orthogonal projection of $C^0$ onto $H^0$, and $\lambda_2$ and $\lambda_{\text{max}}$ the smallest positive and the largest eigenvalue of $L$. For every $x\in C^0$,
:::

::: {custom-style="Statement Equation"}
$\frac{\|\delta x\|_W}{\sqrt{\lambda_{\text{max}}}}\le\|x-Px\|\le\frac{\|\delta x\|_W}{\sqrt{\lambda_2}}$ (3.4)
:::

::: {custom-style="Statement"}
Moreover $C^1=\text{im}\,\delta\oplus\text{ker}(\delta^{\top}W)$, orthogonally for the inner product $W$, and $\text{ker}(\delta^{\top}W)\cong H^1$. For prescribed edge data $c\in C^1$, write $c=\delta y+h$ with $h\in\text{ker}(\delta^{\top}W)$. Then
:::

::: {custom-style="Statement Equation"}
$\text{min}_{x}\,\|\delta x-c\|_W=\|h\|_W$ (3.5)
:::

::: {custom-style="Statement"}
and the minimum is zero exactly when the class of $c$ in $H^1=C^1/\text{im}\,\delta$ vanishes.
:::

::: {custom-style="Statement Tag"}
Classical in substance [20]; stated here with units and the least-squares reading.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* The vector $x-Px$ is orthogonal to $\text{ker}\,L$, so it lies in the span of the eigenvectors of $L$ with positive eigenvalues. Since $\|\delta x\|_W^2=x^{\top}Lx=(x-Px)^{\top}L(x-Px)$, this quantity lies between $\lambda_2\|x-Px\|^2$ and $\lambda_{\text{max}}\|x-Px\|^2$. The $W$-orthogonal complement of $\text{im}\,\delta$ is $\{c:\langle\delta y,c\rangle_W=0\ \text{for all}\ y\}=\text{ker}(\delta^{\top}W)$. Its dimension is $\text{dim}\,C^1-\text{rank}\,\delta=\text{dim}\,H^1$ because a graph has no $2$-cells. The least-squares problem projects $c$ onto $\text{im}\,\delta$ and leaves $h$. ∎

::: {custom-style="Check"}
*Numerical check.* We used a connected graph with 8 vertices and 13 edges, stalks $ℝ^2$, and edge weights drawn uniformly from $[0.5,2]$. One sheaf is gauge-equivalent to the constant sheaf, with $H^0=2$ and $H^1=12$. The other has random orthogonal maps, with $H^0=0$ and $H^1=10$. For 500 random assignments per sheaf, (3.4) held without violation. The distance exceeded the lower bound by a factor of at least 1.07 and stayed below the upper bound by a factor of at most 0.72. The harmonic dimension equalled $H^1$ in both cases (12 and 10).
:::

::: {custom-style="Statement"}
**Proposition 3.8** (heat flow converges to compatible data). Let $D\succ 0$ be a mass matrix on $C^0$ and solve $D\dot x=-Lx$. Let $P_D$ be the $D$-orthogonal projection onto $H^0$ and $\gamma$ the smallest positive eigenvalue of $D^{-1/2}LD^{-1/2}$. Then
:::

::: {custom-style="Statement Equation"}
$\|x(\theta)-P_Dx(0)\|_D\le e^{-\gamma\theta}\,\|x(0)-P_Dx(0)\|_D$ (3.6)
:::

::: {custom-style="Statement"}
If $H^0=0$, every state flows to zero.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 9.1.
:::

::: {custom-style="Gap"}
&nbsp;
:::

The proof is in V2. The substitution $u=D^{1/2}x$ makes the generator symmetric. Consensus is optional in ASE: it removes every component outside $H^0$, which is the sheaf form of oversmoothing in deep sheaf networks [5, 7]. Section 3.4 shows that the number of dimensions that survive is the dimension of a holonomy-fixed subspace, not the stalk dimension.

### 3.3 Nerves with coefficients

::: {custom-style="Statement"}
**Theorem 3.9** (Čech data sheaf). Let $𝒮$ be a sheaf of real vector spaces on a space $X$ and $𝒰=\{U_i\}_{i\in I}$ a finite open cover with nerve $N$. Set $F_𝒮(\sigma)=𝒮(U_\sigma)$, with the restriction maps of $𝒮$. Then $F_𝒮$ is a cellular sheaf on $N$, its cochain complex is the alternating Čech complex of $𝒰$ with coefficients in $𝒮$, and
:::

::: {custom-style="Statement Equation"}
$H^k(N;F_𝒮)=\text{Ȟ}^k(𝒰;𝒮)$ (3.7)
:::

::: {custom-style="Statement"}
If $𝒰$ is a Leray cover for $𝒮$, that is $H^q(U_\sigma;𝒮)=0$ for all $q\ge 1$ and all $\sigma\in N$, then $H^k(N;F_𝒮)\cong H^k(X;𝒮)$. For the constant sheaf $ℝ$ and a good cover, $F_𝒮$ is the constant sheaf $ℝ$ on $N$, and the isomorphism is the nerve theorem in cohomology.
:::

::: {custom-style="Statement Tag"}
Classical [6, 9, 22]; packaged for ASE.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Compatibility is the functoriality of restriction in $𝒮$. The coboundary (3.2) is the Čech differential, written on ordered simplices, and alternating cochains are determined by their values there. Leray's theorem gives the isomorphism with sheaf cohomology [6, 9]. In a good cover every $U_\sigma$ is connected, so $𝒮(U_\sigma)=ℝ$ with identity restrictions. ∎

::: {custom-style="Statement"}
**Example 3.10** (two arcs). Cover the circle by two arcs $U_0,U_1$ whose intersection has two components $A$ and $B$ (Figure 3a). The nerve is a single edge, so $H^1(N;ℝ)=0$. The Čech data sheaf has $F(0)=F(1)=ℝ$ and $F(01)=ℝ^2$, one value per component, with both restrictions equal to $(1,1)^{\top}$. Its cohomology is $H^0=H^1=ℝ$, the cohomology of the circle. The cover is Leray, since every component of every intersection is an arc. The coefficients carry the loop that the nerve misses.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* Data sheaf $(1,1)$; plain nerve $(1,0)$.
:::

![**Figure 3.** A coarse cover whose nerve misses the loop. (a) Two arcs cover the circle; their overlap has two components $A$ and $B$. (b, c) Finer covers by three and six arcs, each refining the cover below it. (d) Bars of layer cohomology from the bottom (two arcs) to the top (six arcs). With the plain nerve, an $H^1$ bar is born at the middle layer; with the Čech data sheaf, the $H^1$ bar is full (Example 4.9).](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p1/fig/circle.png){width=100%}

The lesson for ASE is practical. A nerve summarises a layer's topology faithfully only when the cover is Leray, for instance when all intersections are connected and contractible. Otherwise the data sheaf must carry one stalk coordinate per component of each intersection.

### 3.4 Orthogonal sheaves and holonomy

::: {custom-style="Statement"}
**Definition 3.11** (orthogonal sheaf, transport, holonomy). Let $G=(V,E)$ be a connected graph and $F$ a graph sheaf with $F(v)=F(e)=ℝ^d$ and orthogonal restrictions $r_{ve}\in O(d)$. The transport along an edge $e$ from $u$ to $v$ is $T_{v\leftarrow u}=r_{ve}^{\top}r_{ue}$; the value $T_{v\leftarrow u}x_u$ is the unique value at $v$ that agrees with $x_u$ on $e$. For a closed walk $\gamma=(v_0,v_1,\ldots,v_\ell=v_0)$, the holonomy is $\text{Hol}(\gamma)=T_{v_0\leftarrow v_{\ell-1}}\cdots T_{v_1\leftarrow v_0}$. These matrices form the holonomy group $\text{Hol}(F,v_0)\subseteq O(d)$. A gauge transformation by $g_v,h_e\in O(d)$ replaces $r_{ve}$ by $h_e\,r_{ve}\,g_v^{\top}$; it changes every transport to $g_vT_{v\leftarrow u}g_u^{\top}$ and conjugates the holonomy group by $g_{v_0}$.
:::

::: {custom-style="Statement Tag"}
Classical in substance [30, 31].
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Theorem 3.12** (holonomy theorem). Let $F$ be an orthogonal sheaf on a connected graph $G$.
:::

::: {custom-style="Statement"}
\(i) Evaluation at $v_0$ is an isomorphism $H^0(G;F)\cong\text{Fix}\,\text{Hol}(F,v_0)=\{\xi: h\xi=\xi\ \text{for all}\ h\in\text{Hol}(F,v_0)\}$.
:::

::: {custom-style="Statement"}
\(ii) The holonomy group is generated by the holonomies of the $|E|-|V|+1$ fundamental cycles of any spanning tree.
:::

::: {custom-style="Statement"}
\(iii) The dimensions satisfy
:::

::: {custom-style="Statement Equation"}
$\text{dim}\,H^1=d\,(|E|-|V|)+\text{dim}\,H^0$ (3.8)
:::

::: {custom-style="Statement"}
\(iv) Both dimensions are gauge invariant.
:::

::: {custom-style="Statement Tag"}
New in Part I as stated; (i) is the flat-bundle statement in graph form.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Choose a spanning tree and gauge-fix along it: let $g_v$ be the transport from $v$ to $v_0$ along the tree path, so that every tree edge has identity transport. In this gauge the transport across a non-tree edge equals the holonomy of its fundamental cycle. Every closed walk is a product of fundamental cycles, because the fundamental group of a graph is free on them, which proves (ii). A section in this gauge is constant along the tree, $x_v=\xi$ for every $v$, and it closes across a non-tree edge exactly when the corresponding holonomy fixes $\xi$; this proves (i). Identity (3.3) with $\text{dim}\,C^0=d|V|$ and $\text{dim}\,C^1=d|E|$ gives (iii). Gauge transformations are sheaf isomorphisms, which gives (iv). ∎

Table: **Table 2.** Holonomy check on a connected graph with 7 vertices, 11 edges and 5 fundamental cycles. The fixed dimension is computed from the holonomies alone; $H^0$ and $H^1$ are computed from the coboundary; the last column is $d(|E|-|V|)+\text{dim}\,H^0$.

| Stalk | Edge maps | Fixed dimension | $H^0$ | $H^1$ | Right side of (3.8) |
|:----|:-------------------|:----------|:----|:----|:----------|
| $ℝ^2$ | gauge of the identity | 2 | 2 | 10 | 10 |
| $ℝ^2$ | random orthogonal | 0 | 0 | 8 | 8 |
| $ℝ^2$ | one reflected edge | 1 | 1 | 9 | 9 |
| $ℝ^3$ | gauge of the identity | 3 | 3 | 15 | 15 |
| $ℝ^3$ | random orthogonal | 0 | 0 | 12 | 12 |
| $ℝ^3$ | one edge rotated by 1.1 rad | 1 | 1 | 13 | 13 |

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Corollary 3.13** (Harary's balance theorem [21]). Let $d=1$ and $r_{ve}\in\{\pm1\}$, so that $F$ is a signed graph. Then $H^0\neq 0$ if and only if every cycle has a positive product of signs, if and only if the vertices admit a 2-colouring in which positive edges join equal colours and negative edges join different colours.
:::

::: {custom-style="Statement Tag"}
Classical; here a corollary of Theorem 3.12.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* In 600 random connected signed graphs with 8 vertices, 8 to 14 edges and negative signs with probability 0.25, $H^0=1$ held exactly when a balanced 2-colouring existed, in 600 of 600 graphs.
:::

::: {custom-style="Statement"}
**Proposition 3.14** (filled triangles are flat). Let $\tau=\{a,b,c\}$ be a 2-simplex with $F(\tau)=ℝ^d$, and let every restriction on $\tau$ and its faces be orthogonal and compatible. Then $T_{a\leftarrow c}\,T_{c\leftarrow b}\,T_{b\leftarrow a}=I$. Consequently an orthogonal sheaf on a 2-complex $K$ defines a representation $\pi_1(K,v_0)\to O(d)$, a local coefficient system in Steenrod's sense [31], whose fixed subspace is $H^0$.
:::

::: {custom-style="Statement Tag"}
New in Part I as stated.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* For an edge $e$ of $\tau$ with endpoints $p,q$, compatibility gives $r_{p\tau}=r_{e\tau}r_{pe}$, hence $r_{pe}=r_{e\tau}^{\top}r_{p\tau}$. Therefore $T_{q\leftarrow p}=r_{qe}^{\top}r_{pe}=r_{q\tau}^{\top}r_{e\tau}r_{e\tau}^{\top}r_{p\tau}=r_{q\tau}^{\top}r_{p\tau}$, and the product around $\tau$ telescopes to $I$. The fundamental group of a 2-complex is generated by edge loops modulo the boundaries of its 2-cells [22], so holonomy descends to $\pi_1$, and Theorem 3.12(i) identifies $H^0$. ∎

::: {custom-style="Check"}
*Numerical check.* For 200 random compatible orthogonal triangles with $d\in\{2,3,4\}$, the largest entry of $\text{Hol}-I$ around the boundary was 2.1 × 10⁻¹⁵.
:::

::: {custom-style="Statement"}
**Remark 3.15** (flat is not trivial). Flatness says that holonomy around every filled triangle is trivial. It does not say that holonomy around a non-contractible loop is trivial. A flat orthogonal sheaf has $H^0\cong\text{Fix}\,\rho(\pi_1)$, which can be smaller than $ℝ^d$, and under heat flow (Proposition 3.8) exactly that many dimensions survive. On a graph without 2-cells flatness is vacuous, and every orthogonal sheaf is flat in this sense.
:::

::: {custom-style="Statement Tag"}
V2 Section 9, made precise.
:::

::: {custom-style="Gap"}
&nbsp;
:::

### 3.5 Three obstructions

The circle supports three different local-to-global failures. Their coefficient systems and conclusions differ, and V2 corrected two earlier statements that conflated them. The next proposition places all three on the same nerve.

::: {custom-style="Statement"}
**Proposition 3.16** (three obstructions on one cycle). Let $N$ be the 3-cycle with vertices $0,1,2$ and edges $01,12,02$. It is the nerve of three arcs that cover the circle with connected pairwise overlaps and no triple intersection.
:::

::: {custom-style="Statement"}
\(a) *Linear class.* For the constant sheaf $ℝ$ on $N$, $H^0\cong H^1\cong ℝ$, and the class of edge data $c$ is the oriented sum $c_{01}+c_{12}-c_{02}$. With unit weights,
:::

::: {custom-style="Statement Equation"}
$\text{min}_{x}\,\|\delta x-c\|=\frac{|c_{01}+c_{12}-c_{02}|}{\sqrt 3}$ (3.9)
:::

::: {custom-style="Statement"}
\(b) *Additive obstruction (angles).* Real angle lifts $\theta_i$ on the three arcs differ on each overlap by a constant in $2\pi ℤ$. These differences form a Čech 1-cocycle of the constant sheaf $2\pi ℤ$ whose oriented sum is $2\pi$, one full turn. No choice of lifts, even after shifting each by an arbitrary real constant, makes every overlap difference vanish; the least residual is $2\pi/\sqrt 3$. The local lifts form a torsor for an additive sheaf, not a linear vector sheaf. The circle still has global coordinates $(\cos\theta,\sin\theta)$; the obstruction concerns a global real angle.
:::

::: {custom-style="Statement"}
\(c) *Multiplicative obstruction (signs).* Take lines at 0°, 60° and 120° with representatives $u_0,u_1,u_2$ and transition signs $s_{ij}=\text{sign}\langle u_i,u_j\rangle$. The product of signs around the cycle is $-1$. The real sheaf with restrictions $(1,s_{ij})$ has $H^0=H^1=0$. The obstruction to coherent nonzero representatives is the nonzero class of $s$ in $H^1(N;ℤ_2)$, that is, the holonomy $-1$. It is not a nonzero $H^1$ of the twisted real sheaf.
:::

::: {custom-style="Statement Tag"}
V2 Sections 10 and 11, unified; the residual in (b) is check 11 of the register [19]; (3.9) is new in Part I.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (a) In the edge order $(01,12,02)$, $\text{im}\,\delta$ is the plane orthogonal to $n=(1,1,-1)$, so the distance from $c$ to it is $|n\cdot c|/\sqrt 3$. (b) On an overlap, $\theta_j-\theta_i$ is continuous with values in $2\pi ℤ$, hence constant. Around the circle the angle increases by $2\pi$, so the oriented sum of the differences is $2\pi$. Changing the lifts by real constants adds a coboundary, which leaves the oriented sum unchanged; (3.9) then gives the residual. (c) A section satisfies $x_j=s_{ij}x_i$ on every edge, so after one loop $x_0=-x_0$. Hence $x_0=0$ and $H^0=0$. The coboundary is a $3\times 3$ matrix with trivial kernel, hence invertible, so $H^1=0$. Writing the signs additively in $ℤ_2$, their sum around the only cycle is $1$, so the class of $s$ in $H^1(N;ℤ_2)\cong ℤ_2$ is nonzero. ∎

::: {custom-style="Check"}
*Numerical check.* The least-squares residual for the angle cocycle is 3.6276, against $2\pi/\sqrt 3=3.6276$. The constant sheaf has $(H^0,H^1)=(1,1)$, the sign-twisted sheaf has $(0,0)$, and the computed holonomy is −1.
:::

::: {custom-style="Statement"}
**Example 3.17** (mode shapes and subspaces). An isolated real vibration eigenmode is a line, because $u$ and $-u$ describe the same physical mode. Tracking it across a family of structural models therefore produces case (c), with alignment tested in the mass inner product for mass-normalised modes. For repeated or nearly repeated eigenvalues the right object is the modal subspace. Frames in it are defined up to $O(k)$, transports are orthogonal $k\times k$ matrices, and holonomy can be any element of $O(k)$. The projector $UU^{\top}$ does not depend on the frame and always glues. The obstruction concerns frames, not subspaces, and a Grassmannian description replaces independent sign flips.
:::

::: {custom-style="Statement Tag"}
V2 Section 11.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Example 3.18** (a sheaf of sets with no global section). Take binary variables $x_1,x_2,x_3$ and the contexts $\{1,2\}$, $\{2,3\}$ and $\{1,3\}$. On each context the feasible local sections are the assignments with unequal bits. Every local set is nonempty, and every local section agrees on the shared variable with some section of each neighbouring context. Yet no global assignment satisfies all three inequalities. The coordinate sheaf on the same contexts has $H^1=0$ (Proposition 3.19), so no linear cohomology class detects the failure. This is the possibilistic form of contextuality [1] and the set-level analogue of the marginal extension problem [32]; Part V treats it.
:::

::: {custom-style="Statement Tag"}
V2 Section 16, as a sheaf of sets.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* Local feasible sets have sizes 2, 2 and 2; every local section extends to each neighbouring context; 0 of the 8 global assignments are feasible.
:::

### 3.6 Context sheaves

::: {custom-style="Statement"}
**Proposition 3.19** (coordinate sheaves on contexts). Let $S_1,\ldots,S_k\subseteq\{1,\ldots,D\}$ be nonempty contexts with union $J$, and let $n_j$ be the number of contexts containing the variable $j$. On the nerve of the contexts, where $\sigma$ is a simplex when $S_\sigma=\bigcap_{i\in\sigma}S_i$ is nonempty, define the coordinate sheaf $K(\sigma)=ℝ^{S_\sigma}$ with coordinate projections as restrictions. Then:
:::

::: {custom-style="Statement"}
\(i) $H^0\cong ℝ^{J}$, so a section is an assignment of every covered variable;
:::

::: {custom-style="Statement"}
\(ii) $H^k=0$ for all $k\ge 1$;
:::

::: {custom-style="Statement"}
\(iii) on the pairwise graph (the 1-skeleton of the nerve),
:::

::: {custom-style="Statement Equation"}
$\text{dim}\,H^1=\sum_{j\in J}\frac{(n_j-1)(n_j-2)}{2}$ (3.10)
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* The sheaf splits as $K=\bigoplus_{j\in J}K_j$, where $K_j(\sigma)=ℝ$ if $j\in S_\sigma$ and $0$ otherwise. Let $A_j$ be the set of contexts containing $j$. Every nonempty subset of $A_j$ is a simplex of the nerve, because its contexts share $j$. So the cochain complex of $K_j$ is the simplicial cochain complex of the full simplex on the $n_j$ vertices $A_j$. A full simplex is acyclic, which proves (i) and (ii). On the pairwise graph, $K_j$ sees the complete graph on $n_j$ vertices. That graph is connected and has $\binom{n_j}{2}-n_j+1=(n_j-1)(n_j-2)/2$ independent cycles. Summing over $j$ gives (3.10). ∎

On the pairwise graph, $H^1$ counts redundant agreement constraints on the same variable; it does not certify an inconsistency. Filling the triangles of the nerve removes those classes. A nonzero $H^1$ on a pairwise context graph is therefore never by itself evidence of an obstruction.

::: {custom-style="Check"}
*Numerical check.* In 300 random context families (4 to 7 variables, 3 to 6 contexts of size 2 or 3), (3.10) and statements (i) and (ii) held in every case. For the contexts $\{1,2\},\{1,3\},\{1,4\}$ of Figure 2b, the pairwise graph gives $(H^0,H^1)=(4,1)$ and the full nerve gives $(4,0)$. For the cycle $\{1,2\},\{2,3\},\{1,3\}$ of Example 3.18 the pairwise graph gives $(3,0)$.
:::

### 3.7 Changing the base: pullbacks and refinements

::: {custom-style="Statement"}
**Proposition 3.20** (inverse image along a simplicial map). Let $f:K\to L$ be a simplicial map and $G$ a cellular sheaf on $L$. Then $(f^{-1}G)(\sigma)=G(f(\sigma))$, with restrictions $G(f(\sigma)\le f(\tau))$, is a cellular sheaf on $K$. The map $f^{♯}:C^k(L;G)\to C^k(K;f^{-1}G)$ sends $y$ to the cochain with value $\varepsilon_\sigma\,y_{f(\sigma)}$ on $\sigma$ when $f$ is injective on $\sigma$, and $0$ when $f(\sigma)$ is degenerate. Here $\varepsilon_\sigma$ is the sign of the permutation that orders $f(\sigma)$. It satisfies $\delta f^{♯}=f^{♯}\delta$, and so induces maps $H^k(L;G)\to H^k(K;f^{-1}G)$.
:::

::: {custom-style="Statement Tag"}
Classical; the simplicial case of the inverse-image functoriality used by Russold [28].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Compatibility of $f^{-1}G$ is inherited from $G$ because $f$ preserves faces. In $(\delta f^{♯}y)_\tau$, the terms whose faces map degenerately cancel in pairs exactly as in simplicial cohomology [22]; the remaining terms reproduce $(f^{♯}\delta y)_\tau$. ∎

::: {custom-style="Check"}
*Numerical check.* A filled triangle was collapsed onto an edge, with vertex stalks $ℝ^2$, an edge stalk $ℝ^3$ and random restrictions on the edge. The commutation defects $\delta f^{♯}-f^{♯}\delta$ were 0 in degree 0 and 0 in degree 1, and the pulled-back sheaf was compatible with $\delta^1\delta^0=0$.
:::

::: {custom-style="Statement"}
**Proposition 3.21** (refinement). Let $𝒱=\{V_j\}$ refine $𝒰=\{U_i\}$, with a refinement map $\varphi$ such that $V_j\subseteq U_{\varphi(j)}$. Then $\varphi$ induces a simplicial map $N(𝒱)\to N(𝒰)$, and the restrictions $𝒮(U_{\varphi(\sigma)})\to 𝒮(V_\sigma)$ define a morphism $\varphi^{-1}F^{𝒰}_𝒮\to F^{𝒱}_𝒮$. The induced map $H^k(N(𝒰);F^{𝒰}_𝒮)\to H^k(N(𝒱);F^{𝒱}_𝒮)$ does not depend on the choice of $\varphi$, and it commutes with the maps to $H^k(X;𝒮)$.
:::

::: {custom-style="Statement Tag"}
Classical [6, 9]; Russold's topological-type step [28].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Nonempty intersections of the $V_j$ lie in the corresponding intersections of the $U_{\varphi(j)}$, which gives the simplicial map; the restriction maps of $𝒮$ give the morphism. Two refinement maps induce chain-homotopic cochain maps on Čech complexes, and both factor the canonical maps to sheaf cohomology [6, 9]. ∎

Different covers at successive layers do not by themselves provide vertical maps. Refinement maps, a common refinement or a fixed complex with changing coefficients do. Once such maps are specified, horizontal restrictions and vertical maps must commute on every square (Proposition 5.2).


## 4 The vertical axis: representations of the layer order

### 4.1 Representations and barcodes

::: {custom-style="Statement"}
**Definition 4.1** (representations of the layer order). A representation $V$ of $P$ consists of finite-dimensional spaces $V_t$, $t=T,\ldots,0$, and linear maps $\rho_t:V_t\to V_{t-1}$. For $a\ge b$ write $\rho_{a\to b}=\rho_{b+1}\circ\cdots\circ\rho_a:V_a\to V_b$, the identity when $a=b$. The rank invariant is $r(a,b)=\text{rank}\,\rho_{a\to b}$. For $T\ge b\ge d\ge 0$, the interval module $𝕀[b,d]$ is $ℝ$ at the layers $b,b-1,\ldots,d$, joined by identities, and $0$ elsewhere. It is born at layer $b$ and is alive up to layer $d$.
:::

::: {custom-style="Statement Tag"}
Classical.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Theorem 4.2** (interval decomposition). Every representation of $P$ decomposes as $V\cong\bigoplus 𝕀[b,d]^{m[b,d]}$. The multiset of intervals, the barcode, is unique and is a complete invariant up to isomorphism, and
:::

::: {custom-style="Statement Equation"}
$m[b,d]=r(b,d)-r(b+1,d)-r(b,d-1)+r(b+1,d-1)$ (4.1)
:::

::: {custom-style="Statement"}
with $r=0$ whenever an index leaves $\{T,\ldots,0\}$.
:::

::: {custom-style="Statement Tag"}
Classical [13, 15, 26, 34].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* The decomposition is Gabriel's theorem for the linearly oriented quiver of type A [15]; Crawley-Boevey extends it to pointwise finite-dimensional modules over the real line [13]. The rank $r(a,b)$ counts the intervals that contain both $a$ and $b$, and inclusion–exclusion over the four corners isolates those born exactly at $b$ and alive exactly up to $d$. ∎

::: {custom-style="Check"}
*Numerical check.* In 1,500 random chains with 3 to 6 layers, dimensions 1 to 4 and maps of random rank, every multiplicity from (4.1) was nonnegative and the bars reproduced every rank $r(a,b)$ exactly.
:::

### 4.2 Vertical fibre diagrams

::: {custom-style="Statement"}
**Definition 4.3** (token path and fibre diagrams). Let a token visit $x_t\in X_t$, and let $V_t$ be the data space attached to its visited cell. Linear vertical maps arise in three ways.
:::

::: {custom-style="Statement"}
\(a) *Transport diagrams:* specified linear maps $\rho_t:V_t\to V_{t-1}$, such as stalk maps induced by refinements or validated chart transports. This is the token's vertical fibre diagram.
:::

::: {custom-style="Statement"}
\(b) *Tangent diagrams:* the Jacobians $J_t=\partial z_{t-1}/\partial z_t$ of a smooth update along the realised path, with the noise held fixed.
:::

::: {custom-style="Statement"}
\(c) *Affine diagrams:* $z_{t-1}=A_tz_t+b_t$, made linear by homogenisation.
:::

::: {custom-style="Statement"}
A single stalk is one fibre; the whole journey is a sequence of stalks and maps, not one stalk. A state-dependent nonlinear update is not a linear representation and does not acquire a barcode merely by being layered.
:::

::: {custom-style="Statement Tag"}
V2 Definition 3.1, with the three sources separated.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Proposition 4.4** (homogenisation adds exactly one full bar). Let $\tilde A_t=\begin{pmatrix}A_t & b_t\\ 0 & 1\end{pmatrix}$ act on $ℝ^{D+1}$.
:::

::: {custom-style="Statement"}
\(i) The composite of the affine diagram is
:::

::: {custom-style="Statement Equation"}
$z_0=A_1A_2\cdots A_T\,z_T+\sum_{t=1}^{T}A_1\cdots A_{t-1}\,b_t$ (4.2)
:::

::: {custom-style="Statement"}
\(ii) The barcode of $(ℝ^{D+1},\tilde A_t)$ is the barcode of $(ℝ^{D},A_t)$ plus one interval $𝕀[T,0]$.
:::

::: {custom-style="Statement Tag"}
\(i) V2 Section 7 with matrix coefficients; (ii) new in Part I.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) Substitute each recurrence into the next. (ii) The vectors with last coordinate zero form a subrepresentation isomorphic to $(ℝ^D,A_t)$, and the quotient is $𝕀[T,0]$ because every $\tilde A_t$ preserves the last coordinate. The extension splits. Choose any $w_T$, set $w_{t-1}=A_tw_t+b_t$, and observe that the vectors $(w_t,1)$ span a subrepresentation isomorphic to $𝕀[T,0]$ and complementary to the first. Uniqueness of barcodes gives (ii). ∎

::: {custom-style="Check"}
*Numerical check.* For 200 random affine chains with $D=3$ and $T=8$, the direct recurrence, formula (4.2) and the homogenised product agreed to 3.6 × 10⁻¹⁵. In 500 random chains with rank-deficient $A_t$ and random offsets, the homogenised barcode equalled the linear barcode plus one full bar in 500 cases.
:::

The full bar is the affine direction: the trajectory of one point. Everything the offsets $b_t$ do is in where that trajectory goes, not in the barcode. A barcode of an affine diagram is therefore the barcode of its linear part, plus the one full bar.

### 4.3 Births at a clean top

::: {custom-style="Statement"}
**Proposition 4.5** (births at the top). Suppose $\text{dim}\,V_t=D$ for every $t$, every map below the top is invertible, and the top map $\rho_1:V_1\to V_0$ has rank $r$. Then
:::

::: {custom-style="Statement Equation"}
$V\cong 𝕀[T,0]^{r}\oplus 𝕀[T,1]^{D-r}\oplus 𝕀[0,0]^{D-r}$ (4.3)
:::

::: {custom-style="Statement Tag"}
V2 Section 13, with proof.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* The ranks are $r(a,b)=D$ for $b\ge 1$, $r(a,0)=r$ for $a\ge 1$, and $r(0,0)=D$. Formula (4.1) returns $m[T,0]=r$, $m[T,1]=D-r$ and $m[0,0]=D-r$, and every other multiplicity vanishes. ∎

Of the $D$ bars born at the bottom, $r$ reach the top and $D-r$ end one layer below it. The top also has $D-r$ bars of its own: output directions that no lower perturbation reaches. Counting only the bars born at the bottom, and calling the missing ones deaths, misreads the rank. For the Gaussian update with a clean top, $a_0=1$, V2 gives $\lambda_1=1$ and $J_1=C_1/s_1^2$, so $r=\text{rank}\,C_1$.

::: {custom-style="Check"}
*Numerical check.* With $D=4$, five layers and a top map of rank 2, formula (4.1) returned the bars $𝕀[T,0]^{ 2 }$, $𝕀[T,1]^{ 2 }$ and $𝕀[0,0]^{ 2 }$. The C# kernel reproduces the case $D=3$, four layers and top rank 1 (Appendix A).
:::

### 4.4 Exact bars and effective sensitivity

::: {custom-style="Statement"}
**Proposition 4.6** (exact versus effective rank of the Gaussian tangent). Within a fixed cell and star, assume orthogonal, locally constant transports and query-independent weights. Let $v_1,\ldots,v_n$ be the transported values, $\alpha_i>0$ their Gaussian posterior weights, $m=\sum_i\alpha_iv_i$, $C=\sum_i\alpha_i(v_i-m)(v_i-m)^{\top}$ and $J_t=(1-\lambda_t)I+(\lambda_t/s_t^2)\,C$ [19, Proposition 13.1].
:::

::: {custom-style="Statement"}
\(i) The range of $C$ is $\text{span}\{v_i-v_1\}$, so $\text{rank}\,C=\text{dim}\,\text{aff}\{v_1,\ldots,v_n\}\le\text{min}(D,n-1)$.
:::

::: {custom-style="Statement"}
\(ii) If one record has posterior mass at least $1-\varepsilon$ and $R$ is the diameter of the transported values, then
:::

::: {custom-style="Statement Equation"}
$\|C\|\le\varepsilon R^2$ (4.4)
:::

::: {custom-style="Statement"}
\(iii) If $\lambda_t<1$, every eigenvalue of $J_t$ lies in $[1-\lambda_t,\ 1-\lambda_t+\lambda_tR^2/(4s_t^2)]$, so $J_t$ is invertible. At a clean top, $\text{rank}\,J_1=\text{dim}\,\text{aff}\{v_i\}$. When the records affinely span $ℝ^D$, every exact bar of the tangent diagram is therefore full, however small $\varepsilon$ is.
:::

::: {custom-style="Statement"}
\(iv) For all matrices $A$ and $E$ and every $k$, $|\sigma_k(A+E)-\sigma_k(A)|\le\|E\|$. Hence the effective rank at tolerance $\tau$, the number of singular values above $\tau$, is unchanged by every perturbation with $\|E\|<\text{min}_k|\sigma_k(A)-\tau|$, while the exact rank of a rank-deficient matrix changes under arbitrarily small perturbations.
:::

::: {custom-style="Statement Tag"}
\(i) and the bar statement in (iii) new in Part I; (ii) and the eigenvalue bound V2 Section 13; (iv) Weyl [23].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) Since every $\alpha_i>0$, the range of $C$ is $\text{span}\{v_i-m\}$. Because $m$ is an affine combination of the $v_i$, this equals $\text{span}\{v_i-v_1\}$, the direction space of the affine hull. (ii) For every point $c$, $\sum_i\alpha_i(v_i-c)(v_i-c)^{\top}=C+(m-c)(m-c)^{\top}\succeq C$. Take $c=v_j$, the record of mass at least $1-\varepsilon$: the $j$-th term vanishes, and the others have total mass at most $\varepsilon$ and norm at most $R^2$. (iii) The eigenvalue bound is V2 Proposition 13.1; at the top $J_1=C_1/s_1^2$, and (i) applies. (iv) This is Weyl's inequality for singular values [23]. ∎

Re-selection of an archived record is therefore usually contraction of singular values, not literal death of an interval. Exact death occurs at rank loss or in the one-hot limit. A numerical threshold $\tau$ defines an effective rank, which must be reported together with its tolerance.

::: {custom-style="Check"}
*Numerical check (Proposition 4.6 (i)–(ii)).* In 400 random record sets in $ℝ^4$ with prescribed affine dimension 0 to 3 and random positive weights, $\text{rank}\,C$ equalled the affine dimension in 400 cases. Bound (4.4) held in 400 cases with $\varepsilon$ up to 0.3; the largest ratio $\|C\|/(\varepsilon R^2)$ was 0.991.
:::

To see both effects in a full stack, we ran 1,000 tokens through a 16-layer cosine schedule with $a_t=\cos^2(\pi t/32)$, $\eta=0$ and a clean top, on 30 records in three clusters in $ℝ^2$. The composite tangent $\partial z_0/\partial z_{15}$ was computed along each realised path. In exact arithmetic every composite has rank 2, by Proposition 4.6. At machine precision (tolerance $10^{-14}$) the rank was full for 96.9% of tokens. In each of the other 31 tokens at most 2 records kept a final weight above $10^{-8}$, the smallest eigenvalue of $C_1$ was at most 5.1 × 10⁻¹⁵, and the composite was numerically singular. In floating point, concentration on one or two records acts as rank loss, so even the exact rank is, numerically, an effective rank at a tiny tolerance. At practical tolerances the effective rank told a different story. At $\tau=10^{-3}$ it was 0, 1 or 2 for 11.9%, 44.0% and 44.1% of tokens. At $\tau=10^{-2}$ the shares were 26.5%, 60.6% and 12.9%. The median singular values at the top were 0.0353 and 6.4 × 10⁻⁴ (Figure 4). The exact bars survive while sensitivity contracts by one to three orders of magnitude, most sharply in the final step.

![**Figure 4.** Exact bars survive while sensitivity contracts. Median singular values of the composite tangent $\partial z_t/\partial z_{15}$ for 200 tokens as they climb a 16-layer cosine stack with a clean top. Dashed lines mark two effective-rank tolerances. The exact rank stays 2 for almost every token, while the effective rank depends on the tolerance.](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p1/fig/tangent.png){width=92%}

### 4.5 Persistence of layer cohomology

::: {custom-style="Statement"}
**Proposition 4.7** (layer cohomology is a representation of $P$). Suppose that for each $t$ there is a simplicial map $f_t:N_{t-1}\to N_t$, for instance from a refinement or an inclusion, and a sheaf morphism $\varphi_t:f_t^{-1}F_t\to F_{t-1}$. Then the composites
:::

::: {custom-style="Statement Equation"}
$H^k(N_t;F_t)\to H^k(N_{t-1};f_t^{-1}F_t)\to H^k(N_{t-1};F_{t-1})$ (4.5)
:::

::: {custom-style="Statement"}
make $t\mapsto H^k(N_t;F_t)$ a representation of $P$ for every $k$. It therefore has a barcode in every degree.
:::

::: {custom-style="Statement Tag"}
New packaging in Part I: a topological step followed by an algebraic step, in the sense of Russold [28].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* The first arrow is Proposition 3.20, and the second is functoriality of cohomology under sheaf morphisms. Composition is functorial, so the maps compose along $P$, and Theorem 4.2 applies. ∎

::: {custom-style="Statement"}
**Proposition 4.8** (Leray covers give full bars). Let $𝒮$ be a sheaf on a fixed space $X$, and let $𝒰_T,\ldots,𝒰_0$ be covers of $X$ such that each $𝒰_{t-1}$ refines $𝒰_t$ and every $𝒰_t$ is a Leray cover for $𝒮$. With Čech data sheaves and refinement maps, every vertical map $H^k(N_t;F_t)\to H^k(N_{t-1};F_{t-1})$ is an isomorphism, and the degree-$k$ barcode consists of $\text{dim}\,H^k(X;𝒮)$ copies of $𝕀[T,0]$.
:::

::: {custom-style="Statement Tag"}
New in Part I, as a corollary of Proposition 3.21.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* By Proposition 3.21 each refinement map commutes with the Leray isomorphisms to $H^k(X;𝒮)$, which are isomorphisms at every layer by Theorem 3.9. ∎

The consequence is diagnostic. Refinement alone never creates or destroys a bar. A birth or death in layer cohomology means that the covered region changed across layers, that a cover failed to be Leray, or that the coefficients changed. An implementation should record which of these occurred.

::: {custom-style="Statement"}
**Example 4.9** (a coarse cover that misses a loop; Figure 3). Cover the circle at the bottom by the two arcs of Example 3.10, in the middle by three arcs and at the top by six arcs, each cover refining the one below. With the plain nerve and constant coefficients, $H^1$ is $0$, $1$ and $1$, and a bar is born at the middle layer. That bar is an artefact of a non-Leray summary at the bottom. With the Čech data sheaf at the bottom, $H^1=ℝ$ at every layer and the bar is full, as Proposition 4.8 predicts.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* The covers, overlaps and refinement maps were computed from the arcs on a grid of 7,200 angles. The refinement maps were $(0,0,1)$ and $(0,0,1,1,2,2)$, and the induced cochain maps commuted with the coboundaries exactly. The bottom overlap had 2 components. Barcodes from (4.1): plain nerve $H^0$ full and $H^1$ born at the middle layer; data sheaf $H^0$ and $H^1$ both full.
:::

::: {custom-style="Statement"}
**Proposition 4.10** (nested ball nerves). Fix centres $y_i\in ℝ^D$ and radii $r_0\le\cdots\le r_T$, and let $N_t$ be the nerve of the open balls $B(y_i,r_t)$. Then $N_0\subseteq\cdots\subseteq N_T$, each $N_t$ is homotopy equivalent to the union of its balls, and the inclusions give $H^k(N_T)\to\cdots\to H^k(N_0)$ in the token direction. In degree zero these maps are injective. Every $H^0$ bar therefore reaches the top layer, and the number of bars born at layer $t-1$ is the increase $c(N_{t-1})-c(N_t)$ in the number of components.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 14.1.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* An intersection that is nonempty at a smaller radius stays nonempty at a larger one. Ball intersections are convex, so the nerve theorem applies [22]. The nerves share their vertices, so a function that is constant on the components of $N_t$ restricts to a function constant on the finer components of $N_{t-1}$, and distinct coarse functions differ at some vertex. Injective maps kill no bar, and (4.1) counts the births. ∎

For open balls an edge appears at centre distance strictly below $2r_t$; a convention at exact equality must be chosen and recorded. The nerve is homotopy equivalent to the union of the balls, not to the latent domain, unless the balls cover that domain.

::: {custom-style="Check"}
*Numerical check (Figure 5).* The archive has 36 records in three clusters of three sub-clusters, with radius $r_t=s_t$, that is $\kappa=1$, on the 16-layer cosine schedule. The component counts are 1 at layers 15 to 12, 3 at layers 11 to 9, 6 at layer 8 and 9 at layers 7 to 1. Births occur at layers 15, 11, 8 and 7 with multiplicities 1, 2, 3 and 3. Every vertical map is injective and every bar reaches layer 1. The clean top has radius zero and is excluded. This reproduces check 21 of the proposal register [18, 19].
:::

![**Figure 5.** $H^0$ barcode of a nested ball filtration. Left: an archive with structure at three scales. Right: bars in the token's direction, born when components split; the numbers above give the component count at each layer. Every bar reaches the top because the vertical maps are injective in degree zero (Proposition 4.10).](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p1/fig/barcode.png){width=100%}

::: {custom-style="Statement"}
**Proposition 4.11** (stability of component counts). Let $y,y'$ be configurations of $n$ points with $\text{max}_i\|y_i-y'_i\|\le\varepsilon$, and let $c_r(y)$ be the number of components of the graph with an edge whenever $\|y_i-y_j\|\le r$. Then
:::

::: {custom-style="Statement Equation"}
$c_{r+2\varepsilon}(y)\le c_r(y')\le c_{r-2\varepsilon}(y)$ (4.6)
:::

::: {custom-style="Statement Tag"}
New in Part I as stated; a component-level form of persistence stability [12].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* If $\|y'_i-y'_j\|\le r$, then $\|y_i-y_j\|\le r+2\varepsilon$ by the triangle inequality, so the graph of $y'$ at radius $r$ is contained in the graph of $y$ at $r+2\varepsilon$. Both graphs have the same vertices, and more edges give fewer components. The second inequality is symmetric. ∎

Births read from component counts are robust only away from thresholds. A schedule chosen from births should therefore be reported together with the $2\varepsilon$ margin of the archive's uncertainty.

::: {custom-style="Check"}
*Numerical check.* We drew 80 configurations of 40 points in $[0,10]^2$, with $\varepsilon$ from 0.02 to 0.4, and evaluated 15 radii each: 1,200 cases with 0 violations of (4.6).
:::

::: {custom-style="Statement"}
**Remark 4.12** (zigzags). If covers are learned, centres move or neighbourhoods are not nested, consecutive layers need not admit a map in either direction. A common refinement $𝒲$ gives $H^k(N_t)\to H^k(N(𝒲))\leftarrow H^k(N_{t-1})$. This is a zigzag module, which also decomposes into intervals [10]. Section 5 shows that a zigzag, unlike a chain, is not vertically acyclic.
:::

::: {custom-style="Statement Tag"}
V2 Section 14.
:::

::: {custom-style="Gap"}
&nbsp;
:::


## 5 The product: one sheaf for the whole stack

The two axes combine into one object: a sheaf on the product of a base with the layer order. This section describes such sheaves, computes their cohomology and draws the consequence for the principle.

::: {custom-style="Statement"}
**Proposition 5.1** (fixed-base product). Let $X$ be a topological space and give $P$ its Alexandrov topology.
:::

::: {custom-style="Statement"}
\(i) A set $W\subseteq X\times P$ is open exactly when every slice $W_t=\{x:(x,t)\in W\}$ is open and $W_t\subseteq W_{t'}$ whenever $t\le t'$ in $P$, that is, whenever $t'$ lies above $t$.
:::

::: {custom-style="Statement"}
\(ii) Sheaves $G$ on $X\times P$ correspond to diagrams $G_T\to G_{T-1}\to\cdots\to G_0$ of sheaves on $X$, through $G_t(U)=G(U\times\uparrow t)$; the vertical arrow is restriction along $U\times\uparrow(t-1)\subseteq U\times\uparrow t$. Conversely,
:::

::: {custom-style="Statement Equation"}
$G(W)=\{(s_t)_t\in\prod_tG_t(W_t):\ \rho_{t\to t'}(s_t)=\text{res}_{W_t}(s_{t'})\ \text{whenever}\ t\le t'\ \text{in}\ P\}$ (5.1)
:::

::: {custom-style="Statement Tag"}
V2 Proposition 3.2, with a new proof through slices; compare Russold's correspondence between linear diagrams of sheaves and sheaves of graded modules [28].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) Basic open sets $U\times V$, with $V$ an up-set, have open and monotone slices, and unions preserve both properties. Conversely, a set with open monotone slices equals $\bigcup_t W_t\times\uparrow t$. (ii) A cover of $U$ gives a cover of $U\times\uparrow t$, so each $G_t$ is a sheaf, and the inclusions give the vertical maps. Given a diagram, cover $W$ by the sets $W_t\times\uparrow t$. Two of them, with $t\le t'$, intersect in $W_t\times\uparrow t'$, and the gluing condition there is exactly the condition in (5.1). On $W=U\times\uparrow t_0$, (5.1) returns $G_{t_0}(U)$, because the sections above $t_0$ are determined by $s_{t_0}$. The two constructions are inverse up to natural isomorphism. ∎

::: {custom-style="Statement"}
**Proposition 5.2** (the finite case). For a finite poset $Q$, the product topology on $Q\times P$ is the Alexandrov topology of the product order. Sheaves on $Q\times P$ are functors $Q\times P\to\text{Vect}$, that is, layer sheaves $G_t:Q\to\text{Vect}$ with natural maps $G_t\Rightarrow G_{t-1}$. Naturality says that horizontal restrictions and vertical maps commute on every square (Figure 6b). A family of unrelated layer sheaves is not a sheaf on the product.
:::

::: {custom-style="Statement Tag"}
V2 Section 3, made precise.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Products of up-sets are up-sets of the product order, and every up-set is the union of the products $\uparrow q\times\uparrow t$ over its elements. Proposition 2.2 then identifies sheaves with functors, and a functor on a product of posets is a commuting diagram. ∎

::: {custom-style="Statement"}
**Theorem 5.3** (vertical acyclicity). Let $X$ be a topological space and $G$ a sheaf of real vector spaces on $X\times P$, with bottom layer $G_T$. For every $k\ge 0$, naturally in $G$,
:::

::: {custom-style="Statement Equation"}
$H^k(X\times P;\,G)\cong H^k(X;\,G_T)$ (5.2)
:::

::: {custom-style="Statement"}
In particular $\Gamma(X\times P;G)=\Gamma(X;G_T)$, and for a finite poset $Q$, $H^k(Q\times P;G)\cong H^k(Q;G_T)$.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Let $e$ send a sheaf $G$ on $X\times P$ to its bottom layer $G_T$, and let $\pi:X\times P\to X$ be the projection.

*Step 1: $e$ is exact.* The smallest open subset of $P$ containing $T$ is $\uparrow T=P$, so the sets $U\times P$ form a neighbourhood basis of $(x,T)$. Hence the stalk of $G_T$ at $x$ equals the stalk of $G$ at $(x,T)$, and exactness is tested on stalks.

*Step 2: $\pi^{-1}$ is an exact left adjoint of $e$.* Under Proposition 5.1, $\pi^{-1}F$ is the constant diagram $F\to F\to\cdots\to F$ with identity maps. A morphism from it to $(G_t)$ is a family $\varphi_t:F\to G_t$ with $\rho_t\varphi_t=\varphi_{t-1}$, which is determined by $\varphi_T$. Inverse images are exact.

*Step 3: $e$ preserves injectives,* because it has an exact left adjoint [33].

*Step 4: global sections factor through $e$.* $\Gamma(X\times P;G)=G(X\times\uparrow T)=G_T(X)$.

For an injective resolution $G\to I^{\bullet}$, Steps 1 and 3 make $e\,I^{\bullet}$ an injective resolution of $G_T$. Step 4 then gives $H^k(X\times P;G)=H^k\,\Gamma(X;e\,I^{\bullet})=H^k(X;G_T)$. ∎

For finite bases, the same result is a collapse of the Grothendieck spectral sequence [33] for $\text{lim}_{Q\times P}=\text{lim}_Q\circ\text{lim}_P$. The functor $\text{lim}_P$ is evaluation at the least element $T$, which is exact.

::: {custom-style="Check"}
*Numerical check.* Derived limits over $Q\times P$ were computed from (2.1) and compared with the cellular cohomology of the bottom layer. The base was a hollow triangle with three layers, in four hand-built stacks. With constant $ℝ^2$ and common random vertical maps the result was $(2,2,0,0)$. A twisted bottom under constant layers gave $(0,0,0,0)$, and a constant bottom under twisted layers gave $(1,1,0,0)$. A stack twisted at every layer, with scalar vertical maps, gave $(0,0,0,0)$. Each equals the bottom layer's cohomology. We also built 80 random stacks of subquotient sheaves on four complexes (hollow triangle; filled triangle with a pendant edge; a filled and a hollow triangle sharing an edge; four-cycle), with three layers and random twists. In 78 of them some upper layer had cohomology different from the bottom. The derived limits equalled the bottom cohomology in 80 of 80 stacks.
:::

![**Figure 6.** The product and what each invariant sees. (a) A sheaf on $Q\times P$ is a stack of layer sheaves joined by vertical maps. (b) Every square formed by a restriction and two vertical maps commutes. (c) The cohomology of the product is the bottom term of the persistence module $t\mapsto H^k(Q;G_t)$; the barcode of that module is the vertical invariant.](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p1/fig/product.png){width=100%}

::: {custom-style="Statement"}
**Corollary 5.4** (what the cohomology of a stack sees). Every global section of a stack is a bottom-layer section propagated upward, and every class in $H^k(X\times P;G)$ is determined at the bottom. Two stacks with the same bottom layer have isomorphic product cohomology, whatever happens above. The persistence module $t\mapsto H^k(X;G_t)$ of Proposition 4.7 has $H^k(X;G_T)$ as its bottom term, so its barcode carries strictly more information than the cohomology of the product.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

::: {custom-style="Gap"}
&nbsp;
:::

For instance, the stack with a constant bottom and twisted layers above has product cohomology $(1,1)$, the same as a stack that is constant throughout. In its persistence module, however, both classes die after the bottom layer, while in the constant stack they persist to the top. Vertical information is invisible to the cohomology of the product and visible to barcodes. This is the precise sense in which ASE is vertically algebraic.

::: {custom-style="Statement"}
**Remark 5.5** (orientation, cosheaves and zigzags). \(i) The theorem depends on the direction of the layer order. With the opposite orientation, where information flows from the top down, evaluation happens at the top. For cosheaves, which use colimits, the dual statement evaluates at the terminal layer. \(ii) Acyclicity is a property of a least element, not of layering as such. On the zigzag $a\le c\ge b$, put $G(a)=G(b)=ℝ$ and $G(c)=ℝ^2$, with both maps onto the same line. Then $R^0\text{lim}=ℝ$ and $R^1\text{lim}=ℝ$: the vertical axis carries a class, the direction of $G(c)$ that neither side reaches. Zigzag stacks (Remark 4.12) must therefore be analysed with zigzag barcodes rather than product cohomology.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* The derived limits of the zigzag are $(1,1,0)$.
:::

Moving tokens fit the same framework once the inverse image is typed correctly.

::: {custom-style="Statement"}
**Definition 5.6** (tower). A tower on $X$ consists of sheaves $F_t$ on $X$, deterministic steps $\Phi_t:X\to X$ and morphisms $\varphi_t:F_t\to\Phi_t^{-1}F_{t-1}$. Since $(\Phi_t^{-1}F_{t-1})_x=(F_{t-1})_{\Phi_t(x)}$, the morphism maps the stalk at $x$ into the stalk at $\Phi_t(x)$. Under a fixed noise realisation, the same description applies pathwise.
:::

::: {custom-style="Statement Tag"}
V2 Section 3.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Proposition 5.7** (Lagrangian coordinates). Let $\Psi_T=\text{id}$ and $\Psi_{t-1}=\Phi_t\circ\Psi_t$ be the flow from the bottom. The sheaves $G_t=\Psi_t^{-1}F_t$, with the maps $\Psi_t^{-1}\varphi_t:G_t\to\Psi_t^{-1}\Phi_t^{-1}F_{t-1}\cong G_{t-1}$, form a fixed-base diagram, hence a sheaf on $X\times P$. Its stalk diagram at $x$ is the vertical fibre diagram of the token that starts at $x$:
:::

::: {custom-style="Statement Equation"}
$(F_T)_{x}\to(F_{T-1})_{\Psi_{T-1}(x)}\to\cdots\to(F_0)_{\Psi_0(x)}$ (5.3)
:::

::: {custom-style="Statement"}
Consequently every tower satisfies $H^k(X\times P;G)\cong H^k(X;F_T)$.
:::

::: {custom-style="Statement Tag"}
New in Part I.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Inverse images compose, $(g\circ f)^{-1}\cong f^{-1}g^{-1}$, and have stalks $(f^{-1}F)_x=F_{f(x)}$ [24]. Since $\Psi_T=\text{id}$, $G_T=F_T$, and Theorem 5.3 applies. ∎

A moving token is therefore one stalk diagram of a fixed-base product, written in the coordinates of the bottom layer and labelled by where the token started. The typing matters: the morphism goes into $\Phi_t^{-1}F_{t-1}$, so the stalk at $x$ maps into the stalk at $\Phi_t(x)$. Different bases at different layers first require pullbacks to a common base, a specified correspondence or another explicit comparison.

::: {custom-style="Statement"}
**Remark 5.8** (two parameters are wild). Pairing the layer order with a second filtration, such as a scale within each layer, gives a representation of a product of two chains. Such multiparameter persistence modules admit no complete discrete invariant in general [11]. ASE therefore reads barcodes one parameter at a time and reports rank invariants otherwise.
:::

::: {custom-style="Statement Tag"}
Classical.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Proposition 5.9** (ADE is the trivial product). Take $X_t=ℝ^D$ and the one-element cover $𝒰_t=\{ℝ^D\}$ at every layer, so that every nerve is a single vertex, with constant stalk $ℝ^D$. Take as vertical maps the realised tangent or homogenised affine maps of the ADE update. Add, separately, an observation star at each layer with one leaf per record and identity restrictions. Then:
:::

::: {custom-style="Statement"}
\(i) every layer has $H^0=ℝ^D$ and $H^k=0$ for $k\ge 1$;
:::

::: {custom-style="Statement"}
\(ii) the product has $H^0=ℝ^D$ and no higher cohomology;
:::

::: {custom-style="Statement"}
\(iii) the harmonic read on the star equals the ADE Gaussian read at $q_t=\sqrt{a_t}\,z_t$ [19, Proposition 6.2];
:::

::: {custom-style="Statement"}
\(iv) all vertical structure lies in the fibre diagrams, whose barcodes obey Propositions 4.4 to 4.6.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 6.2, specialised.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* A one-vertex nerve has a cochain complex concentrated in degree zero, which gives (i); Theorem 5.3 gives (ii); (iii) is V2 Proposition 6.2; (iv) is Section 4. ∎

ADE is horizontally trivial and vertically algebraic. ASE adds horizontal topology without changing the vertical algebra. Every horizontal construction of Section 3 reduces to ADE when the cover has one element and the restrictions are identities, and every vertical statement of Section 4 applies to ADE unchanged.

## 6 Register of numerical checks

Table 3 lists every numerical check in Part I. Fourteen checks come from one script and six from a supplementary script. Both scripts write machine-readable results, and every number in this paper is read from those files when the document is built. The checks support the implementations and illustrate the statements; the proofs establish them.

Table: **Table 3.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 2.3 | derived limits against cellular cohomology | equal in 3 of 3 sheaves |
| 2 | Proposition 3.5 | $\delta^1\delta^0$ with compatible and incompatible maps | 0 and 1.78; Euler sums equal |
| 3 | Proposition 3.7 | residual sandwich, 2 sheaves, 500 assignments each | no violation; harmonic dimension equals $H^1$ |
| 4 | Example 3.10 | two arcs | data sheaf (1, 1); plain nerve (1, 0) |
| 5 | Theorem 3.12 | holonomy, 6 orthogonal sheaves | fixed dimension equals $H^0$; (3.8) in 6 of 6 |
| 6 | Corollary 3.13 | Harary balance, 600 signed graphs | 600 of 600 |
| 7 | Proposition 3.14 | flat triangles, 200 cases | largest defect 2.1 × 10⁻¹⁵ |
| 8 | Proposition 3.16 | three obstructions | residual 3.6276; (1, 1) and (0, 0); holonomy $-1$ |
| 9 | Example 3.18 | binary three-cycle | 0 global sections of 8 |
| 10 | Proposition 3.19 | context sheaves, 300 families | formula exact in every family |
| 11 | Proposition 3.20 | inverse-image cochain map | commutation defects 0 and 0 |
| 12 | Theorem 4.2 | 1,500 random chains | multiplicities nonnegative; ranks reconstructed |
| 13 | Proposition 4.4 | affine composites; homogenised barcodes | 3.6 × 10⁻¹⁵; 500 of 500 |
| 14 | Proposition 4.5 | births at the top | bars as predicted |
| 15 | Proposition 4.6 | covariance rank and bound (4.4) | 400 and 400 of 400 |
| 16 | Proposition 4.6 | 1,000 tokens on a cosine stack | numerically full rank 96.9%; effective rank depends on $\tau$ |
| 17 | Example 4.9 | circle covers | plain nerve $H^1$ born mid-stack; data sheaf full |
| 18 | Proposition 4.10 | archive filtration | births at 15, 11, 8, 7; all reach the top |
| 19 | Proposition 4.11 | 1,200 perturbation cases | 0 violations |
| 20 | Theorem 5.3, Remark 5.5 | 4 hand-built and 80 random stacks; zigzag | all equal the bottom; zigzag (1, 1, 0) |
| 21 | Appendix A | C# kernel against NumPy | 13 of 13 output lines identical |

## 7 Discussion

### 7.1 What Part I supplies to the rest of the book

Part II, the horizontal layer, builds the harmonic read on the observation star of Definition 2.4(d). Its normal equations are a harmonic extension problem with fixed boundary values, so Propositions 3.6 to 3.8 supply its residual, conditioning and consensus language. Section 3.5 organises the chapter on design-space topology: branches, angles, signs and subspaces are different coefficient systems. Proposition 3.19 explains why a pairwise context graph over-counts cycles, a point that matters when recombination is read from context overlaps.

Part III, the vertical stack, studies the token recurrence. The separation identity of V2 is the affine composite (4.2) for scalar coefficients, and Proposition 4.4 says that its barcode is the barcode of the linear part. The tangent chapter inherits the distinction between exact and effective rank (Propositions 4.5 and 4.6). The persistence chapter inherits Propositions 4.7 to 4.11 and the zigzag caveat.

Parts IV to VI concern targets, fusion and evidence. Theorem 5.3 has a negative consequence there: no statement about targets, laws or feasibility can be read from the cohomology of the product, because that cohomology sees only the bottom layer. Example 3.18 previews the marginal extension problem. The dependency order of V2 Section 16 is another finite Alexandrov space, to which Proposition 2.2 applies unchanged.

### 7.2 Diagnostics an implementation should report

Defensibility requires that every ASE run report the objects these results depend on:

- the base on which each sheaf lives (Definition 2.4);
- units and edge weights $W$ (Remark 3.3);
- per layer, $\text{dim}\,H^0$ together with the holonomy or $ℤ_2$ class where it applies (Theorem 3.12, Proposition 3.16);
- the residual bounds $\lambda_2$ and $\lambda_{\text{max}}$ (Proposition 3.7);
- the Leray status of every cover, at least whether intersections are connected (Theorem 3.9);
- barcodes together with their conventions: open or closed thresholds, and the tolerance $\tau$ of every effective rank (Propositions 4.6 and 4.10);
- which vertical maps were used: transport, tangent or affine (Definition 4.3).

### 7.3 Open problems

1. **Nonlinear stalks.** Modal subspaces live on Grassmannians and angles on circles. Linear cohomology must be replaced by nonabelian first cohomology, that is, by torsors and their classes. Which parts of Section 3 survive, with which bounds?
2. **Learned covers.** When covers are fitted to data, consecutive layers form a zigzag. Stability of zigzag barcodes under perturbation of the fitted covers is needed before births can guide schedules (hypothesis C3 of V2).
3. **Symmetry.** Mirror-symmetric designs (hypothesis C4) call for equivariant sheaves or sheaves on quotient stacks $[X/G]$. Novelty modulo symmetry should be measured on the quotient, and its relation to sections on $X$ needs a theorem.
4. **Two-parameter summaries.** Remark 5.8 rules out complete invariants for layer and scale together. Which rank-invariant summaries are stable and informative for schedules?
5. **Frustration bounds.** For an orthogonal sheaf with $H^0=0$, the smallest eigenvalue of $L$ measures how far the best assignment is from consistent. The Cheeger inequality for the connection Laplacian [4] relates it to a combinatorial frustration constant. An extension to weighted, rectangular and unit-scaled sheaves would give ASE a certified horizontal diagnostic.
6. **Stability of effective bars.** Proposition 4.6(iv) is pointwise. A perturbation theory for tangent barcodes under changes of the archive, in the language of interleavings [12], would turn effective rank into a stable statistic.

### 7.4 Conclusion

The principle *horizontally topological, vertically algebraic* now has a precise form in three parts. Horizontally, each layer carries a typed data sheaf whose sections, residuals, holonomy and cohomology are computable, with declared units and distinct bases. Vertically, every specified linear diagram along a token's path, and the cohomology of the layers themselves, decomposes into intervals whose births and deaths have exact meanings and effective counterparts. Joined, the two axes form a product whose cohomology is that of its bottom layer, so vertical information is necessarily algebraic. ADE is the special case in which the horizontal axis is trivial. Part II begins from the observation star and the harmonic read.

## References for Part I

::: {custom-style="Bibliography"}
[1] Abramsky, S. and Brandenburger, A. (2011). The sheaf-theoretic structure of non-locality and contextuality. *New Journal of Physics* 13, 113036.

[2] Alexandroff, P. (1937). Diskrete Räume. *Matematicheskii Sbornik (N.S.)* 2(44), 501–519.

[3] Ayzenberg, A., Gebhart, T., Magai, G. and Solomadin, G. (2025). Sheaf theory: from deep geometry to deep learning. arXiv:2502.15476.

[4] Bandeira, A. S., Singer, A. and Spielman, D. A. (2013). A Cheeger inequality for the graph connection Laplacian. *SIAM Journal on Matrix Analysis and Applications* 34(4), 1611–1630.

[5] Bodnar, C., Di Giovanni, F., Chamberlain, B. P., Liò, P. and Bronstein, M. M. (2022). Neural sheaf diffusion: a topological perspective on heterophily and oversmoothing in GNNs. *Advances in Neural Information Processing Systems* 35. arXiv:2202.04579.

[6] Bott, R. and Tu, L. W. (1982). *Differential Forms in Algebraic Topology*. Graduate Texts in Mathematics 82. Springer.

[7] Bourgerie, R., Girdzijauskas, Š. and Fodor, V. (2026). Deep neural sheaf diffusion. arXiv:2605.19021.

[8] Bousfield, A. K. and Kan, D. M. (1972). *Homotopy Limits, Completions and Localizations*. Lecture Notes in Mathematics 304. Springer.

[9] Bredon, G. E. (1997). *Sheaf Theory*, 2nd edn. Graduate Texts in Mathematics 170. Springer.

[10] Carlsson, G. and de Silva, V. (2010). Zigzag persistence. *Foundations of Computational Mathematics* 10(4), 367–405.

[11] Carlsson, G. and Zomorodian, A. (2009). The theory of multidimensional persistence. *Discrete & Computational Geometry* 42(1), 71–93.

[12] Cohen-Steiner, D., Edelsbrunner, H. and Harer, J. (2007). Stability of persistence diagrams. *Discrete & Computational Geometry* 37(1), 103–120.

[13] Crawley-Boevey, W. (2015). Decomposition of pointwise finite-dimensional persistence modules. *Journal of Algebra and Its Applications* 14(5), 1550066.

[14] Curry, J. (2014). *Sheaves, Cosheaves and Applications*. PhD thesis, University of Pennsylvania. arXiv:1303.3255.

[15] Gabriel, P. (1972). Unzerlegbare Darstellungen I. *Manuscripta Mathematica* 6, 71–103.

[16] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[17] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[18] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 1, 17 October 2026.

[19] Ghosh, D. P. (2026d). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[20] Hansen, J. and Ghrist, R. (2019). Toward a spectral theory of cellular sheaves. *Journal of Applied and Computational Topology* 3(4), 315–358.

[21] Harary, F. (1953). On the notion of balance of a signed graph. *Michigan Mathematical Journal* 2(2), 143–146.

[22] Hatcher, A. (2002). *Algebraic Topology*. Cambridge University Press.

[23] Horn, R. A. and Johnson, C. R. (2013). *Matrix Analysis*, 2nd edn. Cambridge University Press.

[24] Kashiwara, M. and Schapira, P. (1990). *Sheaves on Manifolds*. Grundlehren der mathematischen Wissenschaften 292. Springer.

[25] Mac Lane, S. and Moerdijk, I. (1992). *Sheaves in Geometry and Logic: A First Introduction to Topos Theory*. Universitext. Springer.

[26] Oudot, S. Y. (2015). *Persistence Theory: From Quiver Representations to Data Analysis*. Mathematical Surveys and Monographs 209. American Mathematical Society.

[27] Robinson, M. (2017). Sheaves are the canonical data structure for sensor integration. *Information Fusion* 36, 208–224.

[28] Russold, F. (2022). Persistent sheaf cohomology. arXiv:2204.13446.

[29] Shepard, A. D. (1985). *A Cellular Description of the Derived Category of a Stratified Space*. PhD thesis, Brown University.

[30] Singer, A. and Wu, H.-T. (2012). Vector diffusion maps and the connection Laplacian. *Communications on Pure and Applied Mathematics* 65(8), 1067–1144.

[31] Steenrod, N. E. (1943). Homology with local coefficients. *Annals of Mathematics* 44(4), 610–627.

[32] Vorob'ev, N. N. (1962). Consistent families of measures and their extensions. *Theory of Probability and Its Applications* 7(2), 147–163.

[33] Weibel, C. A. (1994). *An Introduction to Homological Algebra*. Cambridge Studies in Advanced Mathematics 38. Cambridge University Press.

[34] Zomorodian, A. and Carlsson, G. (2005). Computing persistent homology. *Discrete & Computational Geometry* 33(2), 249–274.
:::

## Appendix I.A: an immutable C# reference kernel

The kernel below computes the coboundary and the cohomology dimensions of a graph sheaf, and the barcode of a chain from its rank invariant. Values are immutable records; functions are pure, and the rank computation works on a private copy of its input. It targets .NET 8 and has no dependencies beyond the base class library.

```csharp
// ASE Part I reference kernel: graph data sheaves and barcodes of chains.
// Immutable values and pure functions; Rank works on a private copy.
using System;
using System.Collections.Immutable;
using System.Linq;

namespace AsePartOne;

/// <summary>A dense real matrix stored row-major.</summary>
public sealed record Matrix(int Rows, int Cols, ImmutableArray<double> Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Matrix Of(int rows, int cols, params double[] data) =>
        new(rows, cols, ImmutableArray.Create(data));

    public static Matrix Identity(int n) =>
        new(n, n, Enumerable.Range(0, n * n)
            .Select(k => k / n == k % n ? 1.0 : 0.0).ToImmutableArray());

    public Matrix Times(Matrix b) =>
        new(Rows, b.Cols, Enumerable.Range(0, Rows * b.Cols)
            .Select(k => Enumerable.Range(0, Cols)
                .Sum(j => this[k / b.Cols, j] * b[j, k % b.Cols]))
            .ToImmutableArray());

    /// <summary>Rank by Gaussian elimination, relative tolerance.</summary>
    public int Rank(double relTol = 1e-10)
    {
        var a = Data.ToArray();
        double scale = Math.Max(1.0, a.Select(Math.Abs).DefaultIfEmpty(0).Max());
        int rank = 0;
        for (int c = 0; c < Cols && rank < Rows; c++)
        {
            int p = Enumerable.Range(rank, Rows - rank)
                .OrderByDescending(r => Math.Abs(a[r * Cols + c])).First();
            if (Math.Abs(a[p * Cols + c]) <= relTol * scale) continue;
            for (int j = 0; j < Cols; j++)
                (a[p * Cols + j], a[rank * Cols + j]) =
                    (a[rank * Cols + j], a[p * Cols + j]);
            for (int r = rank + 1; r < Rows; r++)
            {
                double f = a[r * Cols + c] / a[rank * Cols + c];
                for (int j = c; j < Cols; j++)
                    a[r * Cols + j] -= f * a[rank * Cols + j];
            }
            rank++;
        }
        return rank;
    }
}

/// <summary>An oriented edge U -> V with restrictions from both stalks.</summary>
public sealed record Edge(int U, int V, Matrix FromU, Matrix FromV)
{
    public int Dim => FromU.Rows;
}

/// <summary>A data sheaf on a graph: vertex stalk dimensions and edges.</summary>
public sealed record GraphSheaf(ImmutableArray<int> VertexDims,
                                ImmutableArray<Edge> Edges)
{
    /// <summary>(delta x)_e = FromV x_V - FromU x_U.</summary>
    public Matrix Coboundary()
    {
        var col = VertexDims.Select((_, i) => VertexDims.Take(i).Sum())
            .ToImmutableArray();
        var row = Edges.Select((_, k) => Edges.Take(k).Sum(f => f.Dim))
            .ToImmutableArray();
        int rows = Edges.Sum(e => e.Dim), cols = VertexDims.Sum();
        double Entry(int r, int c)
        {
            int k = row.LastIndexOf(row.Last(o => o <= r));
            var e = Edges[k];
            int i = r - row[k];
            double Block(int v, Matrix m, double sign) =>
                c >= col[v] && c < col[v] + VertexDims[v]
                    ? sign * m[i, c - col[v]] : 0.0;
            return Block(e.V, e.FromV, 1.0) + Block(e.U, e.FromU, -1.0);
        }
        return new Matrix(rows, cols, Enumerable.Range(0, rows * cols)
            .Select(k => Entry(k / cols, k % cols)).ToImmutableArray());
    }

    /// <summary>dim H0 and dim H1 from the rank of delta.</summary>
    public (int H0, int H1) Cohomology()
    {
        int r = Coboundary().Rank();
        return (VertexDims.Sum() - r, Edges.Sum(e => e.Dim) - r);
    }
}

/// <summary>An interval [Birth, Death], positions from the bottom (1).</summary>
public sealed record Bar(int Birth, int Death, int Multiplicity);

public static class Barcodes
{
    /// <summary>Bars of V_1 -> ... -> V_n from the rank invariant:
    /// m(i, j) = r(i, j) - r(i-1, j) - r(i, j+1) + r(i-1, j+1).</summary>
    public static ImmutableArray<Bar> FromChain(ImmutableArray<int> dims,
                                                ImmutableArray<Matrix> maps)
    {
        int n = dims.Length;
        Matrix Composite(int i, int j) => Enumerable.Range(i - 1, j - i)
            .Aggregate(Matrix.Identity(dims[i - 1]), (m, k) => maps[k].Times(m));
        int R(int i, int j) =>
            i < 1 || j > n || i > j ? 0
            : i == j ? dims[i - 1]
            : Composite(i, j).Rank();
        return (from i in Enumerable.Range(1, n)
                from j in Enumerable.Range(i, n - i + 1)
                let mult = R(i, j) - R(i - 1, j) - R(i, j + 1) + R(i - 1, j + 1)
                where mult != 0
                select new Bar(i, j, mult)).ToImmutableArray();
    }
}
```

A small program builds seven cases: the constant and sign-twisted triangles, the three-line example, the coordinate sheaf of Figure 2b, an orthogonal four-cycle with reflection holonomy, the clean-top chain of Proposition 4.5 with $D=3$, and a chain with dimensions $2,3,2,2$. An independent NumPy implementation recomputes every printed line. Table 4 compares the two.

Table: **Table 4.** Output of the C# kernel and of the NumPy recomputation. Cohomology lines give $\text{dim}\,H^0$ and $\text{dim}\,H^1$; bar lines give birth position, death position and multiplicity, counted from the bottom (1) to the top.

| C# kernel | NumPy | Match |
|:-----------------|:-----------------|:--|
| `constant 1 1` | `constant 1 1` | yes |
| `twisted 0 0` | `twisted 0 0` | yes |
| `three_lines 0 0` | `three_lines 0 0` | yes |
| `contexts 4 1` | `contexts 4 1` | yes |
| `reflection_cycle 1 1` | `reflection_cycle 1 1` | yes |
| `bar 1 3 2` | `bar 1 3 2` | yes |
| `bar 1 4 1` | `bar 1 4 1` | yes |
| `bar 4 4 2` | `bar 4 4 2` | yes |
| `chain 1 2 1` | `chain 1 2 1` | yes |
| `chain 1 4 1` | `chain 1 4 1` | yes |
| `chain 2 2 1` | `chain 2 2 1` | yes |
| `chain 3 3 1` | `chain 3 3 1` | yes |
| `chain 4 4 1` | `chain 4 4 1` | yes |

## Appendix I.B: reproducibility

Two Python scripts write every number in this paper to machine-readable files. The main script runs fourteen checks with seed 20261018. The supplementary script runs six more, with seed 20261019: affine barcodes, random stacks with the zigzag, feasible sets, covariance rank, circle covers and the archive filtration. A third script recomputes the C# output, a fourth draws Figures 1 to 6 from the same files, and a fifth replays the random stream of the main script to diagnose the numerically rank-deficient tokens of Section 4.4. The document itself is generated from a source in which every quantity is a reference into those files, so no number was typed by hand. The computations used Python 3.13.16, NumPy 2.5.3, Matplotlib 3.11.2 and the .NET SDK 8.0.131. All scripts, results and the C# project accompany this paper.


# Part II · The Horizontal Layer

::: {custom-style="Subtitle"}
One layer of Autoregressive Sheaf Evolution. Part II: sheaf attention, Gaussian stalks, locality and the topology of design spaces
:::

**Summary of Part II.** Part I of Autoregressive Sheaf Evolution (ASE) fixed the two axes of a layer stack: sheaves on covers within a layer, and representations of the layer order across layers. This paper, Part II of the book, works out a single layer. A token reads an archive through an observation star. Each record is seen through an edge map, and the read is the harmonic extension of the observations to the token; we call this read sheaf attention. The read is a matrix-weighted combination of lifted records, and its weights are self-adjoint in the normal-matrix geometry and sum to the identity. When the normal matrix is singular, the read keeps the token's own value in the unresolved directions and is the nearest minimiser of the star energy. Under coordinate masks the read leaves the archive hull and can beat the best archived design on a linear cost, but never the best coordinatewise combination. For two observation spaces, principal angles determine its conditioning exactly; for coordinate masks, coverage does. The central new result is that sheaf attention is a majorise–minimise step. Every relaxed step $z+\lambda(m-z)$ with $0\le\lambda\le 2$ lowers the soft discrepancy energy by at least $\tfrac12\lambda(2-\lambda)\|z-m\|_H^2$, fixed points are exactly stationary points, and every deterministic ADE layer is such a step at its own scale. In a stalk, Tweedie's identity holds in preconditioned form. One imputation is a gradient step, and repeated imputation converges to the harmonic read. Mixtures of partial records are improper, while products are proper exactly under coverage. Selection tilting collapses coverage. Bounded measurement error moves the weights by at most $\tanh(\beta\varepsilon/2)$ in total variation, and this bound is sharp. For locality we give a posteriori truncation certificates for scalar and rectangular reads, an exact Jacobian with a covariance bound, and the classification of stationary points as attracting minima and repelling saddles. For topology we prove four results. Shared reads land in the gap between branches. Local angle reads jump only at antipodes. Nearest-image reads approximate orbit reads for any finite symmetry group, with an explicit bound. An index on canonical representatives is exact for reflection groups, but every continuous canonicalisation fails for sign and mirror symmetries with two or more antisymmetric directions. Thirty-four numerical checks, and an immutable C# kernel that matches an independent NumPy implementation, support every quantitative statement.

## 1 Introduction

Autoregressive Diffusion Evolution (ADE) reads an archive of evaluated designs through a Gaussian kernel at every layer of a denoising stack [12, 13]. Autoregressive Sheaf Evolution (ASE) replaces the single Euclidean retrieval geometry of ADE by local data spaces, compatibility maps and scale-dependent covers [14]. Part I made the organising principle precise: each layer is horizontally topological, and each token's journey through the layers is vertically algebraic [15]. It also separated four bases that are easily confused. One of them is the observation star, a token vertex joined to one leaf per retrieved record [15, Definition 2.4(d)]. This paper, Part II of the book, studies what happens on that star. It covers chapters 3 to 6 of the book plan: sheaf attention, Gaussian models in a stalk, scale locality and covers, and the topology of design spaces [14, Section 21].

A layer does one thing to a token. It reads records through maps and moves towards the read. With record observations $o_i=R_iy_i$, token-side edge maps $Q_i$, prior weights $w_i$ and scale $s$, the read is

::: {custom-style="Equation"}
$e_i(z)=\tfrac12\|Q_iz-o_i\|^2,\quad \alpha_i\propto w_i\,e^{-e_i(z)/s^2},\quad H=\sum_i\alpha_iQ_i^{\top}Q_i,\quad b=\sum_i\alpha_iQ_i^{\top}o_i,\quad m=H^{-1}b$ (1.1)
:::

when $H$ is invertible. With identity maps, (1.1) is the ADE read and also biased softmax attention [13, Proposition 5.1; 24]. With general maps, it is the harmonic extension of the observations from the leaves of the star to the token [14, Proposition 5.1]. We call (1.1), with the retention rule of Definition 2.2 for singular $H$, *sheaf attention*. Barbero and co-authors used the phrase earlier for a graph neural network layer that learns attention coefficients on a cellular sheaf [1, 4]. Ours is a different object: a read on an observation star, with fixed maps and weights computed from discrepancies.

![**Figure 1.** (a) The observation star of one token. Each edge carries an edge stalk $ℝ^{k_i}$, reached from the token by $Q_i$ and from the record by $R_i$. (b) Two records with complementary coordinate masks: the read takes $x_1$ from the first and $x_2$ from the second, and lands outside the archive hull. On the cost $-x_1-x_2$ both records score $-1.1$ and the read scores $-2.0$ (Proposition 3.5). (c) Two records whose observation spaces are lines at an angle $\theta$. A unit move of one observation moves the read by exactly $1/\sin\theta$, below the general bound of Proposition 3.7.](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p2/fig/star.png){width=100%}

### 1.1 Contributions

- **Sheaf attention as an operator (Section 3).** We give the Schur-complement form of the harmonic extension (Proposition 3.1) and the retention read for singular normal matrices (Proposition 3.2). Matrix weights are invariant under lifts and self-adjoint in the $H$-geometry (Proposition 3.3). We prove hulls, coordinate boxes, a crossover property and a coordinatewise ceiling (Corollary 3.4, Proposition 3.5), and the exact spectrum of two weighted projectors with two-sided conditioning bounds (Proposition 3.6). The central result is the majorise–minimise theorem (Theorem 3.10). It gives guaranteed descent for every relaxation $0\le\lambda\le 2$, and every deterministic ADE layer descends at its own scale (Corollary 3.12).
- **Gaussian stalks (Section 4).** Tweedie's identity holds in preconditioned form (Proposition 4.1). The chart posterior of the mathematics book and sheaf attention differ exactly off the chart (Proposition 4.2). Mixtures of partial records are improper, while products of experts are proper exactly under coverage (Proposition 4.3). One imputation is a gradient step, and repeated imputation is Cimmino's method converging to the harmonic read (Proposition 4.4). Selection tilting collapses coverage (Proposition 4.6). Bounded measurement error has a sharp $\tanh$ bound (Theorem 4.8).
- **Locality (Section 5).** We give a posteriori truncation certificates for transported reads, with certified radii, and for rectangular reads (Proposition 5.1, Corollary 5.2, Theorem 5.3). The Jacobian of the read is exact and has a covariance bound (Proposition 5.4). Stationary points are classified into attracting minima and repelling saddles (Corollary 5.5). Section 5.3 states the cost and index contracts that the certificates need.
- **Topology (Section 6).** Shared reads land in the gap between branches (Proposition 6.2). Local angle reads jump only at antipodes, by an exponentially small amount (Proposition 6.5). Nearest-image reads approximate all-image reads for every finite orthogonal group (Theorem 6.6), and projector reads are stable under measurement error (Proposition 6.8). Orbit indexes are exact for reflection groups, and every continuous canonicalisation fails for involutions with two or more antisymmetric directions (Proposition 6.10).
- **Evidence.** There are 34 numerical checks (Table 6): 20 from a main script and 14 from a supplementary script. An immutable C# kernel agrees with an independent NumPy implementation on every output line (Appendix A).

### 1.2 Scope and status of statements

Part II concerns one layer at one query. It makes no claim about search performance, sampling validity or the feasibility of proposed designs. The hypotheses C1 to C5 of V2 remain open, and nothing here tests them [14, Sections 17–18]. Every statement in a shaded box ends with a provenance tag. *Classical* marks a known result restated in ASE notation. *V2* marks a statement of the conversion proposal [14], sometimes with a new proof. *Mathematics book* marks a result retained from [13], with its number there. *New in Part II* marks a statement proved here for the first time in this programme; each comes with a proof and a numerical check. Unless stated otherwise, weights are frozen at the query. All spaces are finite-dimensional and real.

### 1.3 Conventions and notation

Table: **Table 1.** Notation used throughout Part II.

| Symbol | Meaning |
|:--------------|:--------------------------------------------------------------|
| $z\in ℝ^D$ | token state in the token frame |
| $y_i,\ R_i,\ o_i=R_iy_i$ | record value, record-side map and observation |
| $Q_i:ℝ^D\to ℝ^{k_i}$ | token-side edge map of record $i$ |
| $w_i,\ s$ | prior weight of record $i$ and the scale of the layer |
| $e_i,\ \alpha_i$ | discrepancy and attention weight (2.1) |
| $H,\ b,\ m$ | normal matrix, right side and read (2.2), (2.3) |
| $E_s$ | soft discrepancy energy (3.6) |
| $\kappa_j$ | coverage of coordinate $j$ under masks |
| $c_A$ | the largest $\lambda_{\text{max}}(Q_i^{\top}Q_i)$ over the records |
| $S,\ W,\ W_S,\ D_S$ | star, total archive weight, star weight and star kernel mass |
| $G,\ d_G$ | finite group of orthogonal symmetries and its orbit distance |
| $\langle g\rangle$ | the $\alpha$-weighted mean $\sum_i\alpha_ig_i$ |

## 2 The observation star and the layer contract

An ASE layer consumes a token, a versioned archive, declared edge maps and schedule coefficients. It produces a proposal together with its read, its star and numerical diagnostics [14, Section 4]. The read is computed on an auxiliary graph, the observation star. The cover nerve describes the base geometry, while the star describes the observations attached to it. ADE has a one-vertex nerve and a star with one leaf per record [15, Proposition 5.9].

::: {custom-style="Statement"}
**Definition 2.1** (observation star). At one layer, fix a token frame $ℝ^D$ and retrieved records $i=1,\ldots,n$ with values $y_i\in ℝ^{d_i}$, edge maps $Q_i:ℝ^D\to ℝ^{k_i}$ and $R_i:ℝ^{d_i}\to ℝ^{k_i}$, observations $o_i=R_iy_i$, prior weights $w_i>0$ and a scale $s>0$. The discrepancy and attention weight of record $i$ at the token $z$ are
:::

::: {custom-style="Statement Equation"}
$e_i(z)=\tfrac12\|Q_iz-o_i\|^2,\qquad \alpha_i(z)=\frac{w_i\exp(-e_i(z)/s^2)}{\sum_jw_j\exp(-e_j(z)/s^2)}$ (2.1)
:::

::: {custom-style="Statement"}
and the normal matrix and right side are
:::

::: {custom-style="Statement Equation"}
$H(z)=\sum_i\alpha_i(z)\,Q_i^{\top}Q_i,\qquad b(z)=\sum_i\alpha_i(z)\,Q_i^{\top}o_i$ (2.2)
:::

::: {custom-style="Statement Tag"}
V2 Section 4, made a definition.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Definition 2.2** (sheaf attention). The read at $z$ is
:::

::: {custom-style="Statement Equation"}
$m(z)=z+H^{\dagger}(b-Hz)$ (2.3)
:::

::: {custom-style="Statement"}
where $H^{\dagger}$ is the Moore–Penrose pseudo-inverse. If $H\succ 0$, then $m=H^{-1}b$. The eigenvectors of $H$ with eigenvalue zero span the unresolved directions, in which the read keeps the token's own value. In floating point, eigenvalues at most $\epsilon\,\text{max}(1,\lambda_{\text{max}}(H))$ are treated as zero, and the layer raises an unresolved flag. The kernel of Appendix A uses $\epsilon=10^{-10}$.
:::

::: {custom-style="Statement Tag"}
V2 Definition 4.1, with the retention rule of V2 Section 4 made explicit.
:::

::: {custom-style="Gap"}
&nbsp;
:::

The weights are frozen at the query. Each record contributes through its own observation space, so a record can contribute a strong subassembly without contributing anything else. A coordinate mask records what a record actually observed; an unobserved coordinate receives no invented value [14, Section 4]. Table 2 lists the map classes that recur below.

Table: **Table 2.** Classes of edge maps. Here $n$ is the number of records in the star; costs count arithmetic operations per read, with transports $Q_i^{\top}o_i$ and normal blocks $Q_i^{\top}Q_i$ stored with the records.

| Edge maps | Normal matrix | Read | Where the read lies | Cost per read |
|:----------------|:--------------|:----------------|:----------------|:----------------|
| identity | $H=I$ | $\sum_i\alpha_iy_i$, the ADE read | archive hull | $O(nD)$ |
| orthogonal transport | $H=I$ | $\sum_i\alpha_iQ_i^{\top}o_i$ | transported hull | $O(nD)$ |
| coordinate mask | diagonal coverage | coordinatewise weighted means | coordinate box | $O(\sum_ik_i+D)$ |
| partial isometry | $0\preceq H\preceq I$ | limit of repeated imputation | no hull in general | $O(nD^2+D^3)$ |
| general rectangular | $H\succeq 0$ | $z+H^{\dagger}(b-Hz)$ | no hull in general | $O(nD^2+D^3)$ |


## 3 Sheaf attention

### 3.1 The read is a harmonic extension

On the star, give the token vertex the stalk $ℝ^D$, the leaf of record $i$ the stalk $ℝ^{d_i}$ and the edge joining them the stalk $ℝ^{k_i}$. The coboundary of an assignment $(x_0,x_1,\ldots,x_n)$ is $(\delta x)_i=R_ix_i-Q_ix_0$, and fixed coefficients $c_i>0$ define the weighted sheaf Laplacian $L=\delta^{\top}C\delta$ [17]. Partition $L$ into the token block $t$ and the leaf block $\ell$.

::: {custom-style="Statement"}
**Proposition 3.1** (harmonic extension and its Schur complement). Suppose $G=\sum_ic_iQ_i^{\top}Q_i\succ 0$ and fix the leaves at $y=(y_1,\ldots,y_n)$.
:::

::: {custom-style="Statement"}
\(i) The unique minimiser of $\sum_ic_i\|Q_ix_0-R_iy_i\|^2$ over the token value is $x_0=G^{-1}\sum_ic_iQ_i^{\top}R_iy_i=-L_{tt}^{-1}L_{t\ell}\,y$. It is the harmonic extension of $y$: the token component of $L(x_0,y)$ vanishes.
:::

::: {custom-style="Statement"}
\(ii) The minimum value is the Schur-complement form
:::

::: {custom-style="Statement Equation"}
$\text{min}_{x_0}\sum_ic_i\|Q_ix_0-R_iy_i\|^2=y^{\top}(L_{\ell\ell}-L_{\ell t}L_{tt}^{-1}L_{t\ell})\,y$ (3.1)
:::

::: {custom-style="Statement Tag"}
\(i) V2 Proposition 5.1; (ii) Classical [17, 19].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* The energy is $(x_0,y)^{\top}L(x_0,y)$ with $L_{tt}=\sum_ic_iQ_i^{\top}Q_i=G$ and $L_{t\ell}\,y=-\sum_ic_iQ_i^{\top}R_iy_i$. It is a strictly convex quadratic in $x_0$, minimised where $L_{tt}x_0+L_{t\ell}y=0$, which is the harmonic condition at the token vertex. Substituting the minimiser gives the Schur complement. ∎

::: {custom-style="Check"}
*Numerical check.* In 300 random stars with general rectangular maps, the normal-equation read and $-L_{tt}^{-1}L_{t\ell}y$ agreed to 2.6 × 10⁻¹³. Among 15,000 random perturbations of size $10^{-3}$, 0 lowered the energy. In 300 further stars, the minimum value matched (3.1) to a relative 2.4 × 10⁻¹⁴.
:::

The retention rule of Definition 2.2 is needed whenever the retrieved records do not jointly observe every direction of the token frame. The next proposition says what it computes.

::: {custom-style="Statement"}
**Proposition 3.2** (the retention read). Freeze the weights at $z$ and let $M(x)=\sum_i\alpha_ie_i(x)$ be the frozen star energy. Then:
:::

::: {custom-style="Statement"}
\(i) $b\in\text{range}\,H$, so the minimisers of $M$ form the affine set $m+\text{ker}\,H$;
:::

::: {custom-style="Statement"}
\(ii) the read (2.3) is the minimiser of $M$ nearest to $z$;
:::

::: {custom-style="Statement"}
\(iii) for $\tau>0$, the token-anchored ridge read $m_\tau=(H+\tau I)^{-1}(b+\tau z)$ satisfies
:::

::: {custom-style="Statement Equation"}
$\|m_\tau-m\|\le\frac{\tau}{\lambda_r+\tau}\,\|m-z\|$ (3.2)
:::

::: {custom-style="Statement"}
where $\lambda_r$ is the smallest positive eigenvalue of $H$, so $m_\tau\to m$ as $\tau\to 0$;
:::

::: {custom-style="Statement"}
\(iv) if $H\succ 0$, then $m=H^{-1}b$.
:::

::: {custom-style="Statement Tag"}
New in Part II. V2 Section 4 states the rule.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) Every $\alpha_i$ is positive, so $\text{range}\,H=\sum_i\text{range}\,Q_i^{\top}$, which contains $b$. Since $M(x)=\tfrac12x^{\top}Hx-b^{\top}x+\text{const}$, its minimisers are the solutions of $Hx=b$. (ii) Because $b-Hz\in\text{range}\,H$, $Hm=Hz+HH^{\dagger}(b-Hz)=b$, so $m$ is a minimiser. Moreover $m-z=H^{\dagger}(b-Hz)\in\text{range}\,H=(\text{ker}\,H)^{\perp}$, which characterises the orthogonal projection of $z$ onto $m+\text{ker}\,H$. (iii) $m_\tau-z=(H+\tau I)^{-1}(b-Hz)$ and $m-z=H^{\dagger}(b-Hz)$. In an eigenbasis of $H$, the component along an eigenvalue $\lambda>0$ changes by the factor $\lambda/(\lambda+\tau)$, that is, by $\tau/(\lambda+\tau)\le\tau/(\lambda_r+\tau)$ of itself. The components along $\text{ker}\,H$ vanish in both. (iv) Here $H^{\dagger}=H^{-1}$. ∎

::: {custom-style="Check"}
*Numerical check.* In 300 stars whose maps observe a random proper subspace, the read agreed with an independently computed nearest minimiser, obtained from a least-squares solution projected along $\text{ker}\,H$, to a relative 2.1 × 10⁻⁸. The normal residual on resolved directions was 9.6 × 10⁻¹⁴. At $\tau/\lambda_r=10^{-2}$, $10^{-4}$ and $10^{-6}$, the largest values of $\|m_\tau-m\|/\|m-z\|$ were 0.009901, 9.999 × 10⁻⁵ and 1 × 10⁻⁶, so bound (3.2) is attained.
:::

*Engineering meaning.* The retention read never invents a value in a direction that no retrieved record observes; that direction keeps the token's own value. A ridge prior is the alternative V2 allows. Proposition 3.2 shows that the retention read is the vanishing-ridge limit, and that any positive $\tau$ is a declared prior that changes the read.

### 3.2 Matrix weights

::: {custom-style="Statement"}
**Proposition 3.3** (matrix weights). Let $G=\sum_ic_iQ_i^{\top}Q_i\succ 0$ and $A_i=G^{-1}c_iQ_i^{\top}Q_i$.
:::

::: {custom-style="Statement"}
\(i) $\sum_iA_i=I$.
:::

::: {custom-style="Statement"}
\(ii) Let $v_i$ be any lift of record $i$, that is, any vector with $Q_iv_i=Q_iQ_i^{\dagger}o_i$, the projection of $o_i$ onto $\text{range}\,Q_i$. Then
:::

::: {custom-style="Statement Equation"}
$m=\sum_iA_iv_i$ (3.3)
:::

::: {custom-style="Statement"}
and the read does not depend on the choice of lifts.
:::

::: {custom-style="Statement"}
\(iii) Each $A_i$ is self-adjoint in the inner product $\langle x,y\rangle_G=x^{\top}Gy$ and satisfies $0\preceq A_i\preceq I$ there. Equivalently, $A_i$ is similar to the positive semidefinite matrix $G^{-1/2}c_iQ_i^{\top}Q_iG^{-1/2}$, and its eigenvalues lie in $[0,1]$.
:::

::: {custom-style="Statement Tag"}
\(i) V2 check 5; (ii) and (iii) New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) Sum the definition. (ii) $Q_iQ_i^{\dagger}$ is the orthogonal projector onto $\text{range}\,Q_i$, and $Q_i^{\top}$ vanishes on the orthogonal complement of that range. Hence $Q_i^{\top}o_i=Q_i^{\top}Q_iQ_i^{\dagger}o_i=Q_i^{\top}Q_iv_i$, and $m=G^{-1}\sum_ic_iQ_i^{\top}Q_iv_i=\sum_iA_iv_i$. Adding a vector of $\text{ker}\,Q_i$ to $v_i$ does not change $Q_i^{\top}Q_iv_i$. (iii) $GA_i=c_iQ_i^{\top}Q_i$ is symmetric, which is $G$-self-adjointness. The matrices $B_i=G^{1/2}A_iG^{-1/2}=G^{-1/2}c_iQ_i^{\top}Q_iG^{-1/2}$ are positive semidefinite and sum to $I$, so $0\preceq B_i\preceq I$. ∎

With identity maps, $A_i=\alpha_iI$ and (3.3) is the convex read of ADE. In general, the read is a convex combination with operator-valued weights, convex in the geometry of $G$ rather than the Euclidean one.

::: {custom-style="Check"}
*Numerical check.* In 300 random stars, $\sum_iA_i=I$ held to 7.8 × 10⁻¹⁴ and (3.3) to 6.4 × 10⁻¹⁴. Adding random kernel components to every lift changed the read by at most 7.1 × 10⁻¹⁴. The smallest eigenvalue of any $B_i$ was −2.3 × 10⁻¹³, which is zero to rounding.
:::

### 3.3 Hulls, boxes and recombination

::: {custom-style="Statement"}
**Corollary 3.4** (transported hull and ceiling). If every $Q_i$ is square orthogonal, then $H=I$ and $m=\sum_i\alpha_iv_i$ with $v_i=Q_i^{\top}o_i$. The read lies in the convex hull of the transported records, and for every linear cost $c$, $c(m)\ge\text{min}_i\,c(v_i)$.
:::

::: {custom-style="Statement Tag"}
V2 Corollary 5.2; Mathematics book Corollary 6.1.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* In 200 random orthogonal stars, $m-\sum_i\alpha_iv_i$ was at most 1.3 × 10⁻¹⁵.
:::

::: {custom-style="Statement"}
**Proposition 3.5** (recombination and the coordinatewise ceiling). Let $Q_i=R_i$ select the coordinates $S_i$ of a full design, and let every coordinate have positive coverage $\kappa_j=\sum_{i:\,j\in S_i}\alpha_i$.
:::

::: {custom-style="Statement"}
\(i) $m_j=\kappa_j^{-1}\sum_{i:\,j\in S_i}\alpha_iy_{ij}$. Hence the read lies in the coordinate box spanned by the observed values, but not necessarily in the convex hull of the archived designs.
:::

::: {custom-style="Statement"}
\(ii) For two records with complementary masks $S$ and $S^c$, the read lies outside the segment joining $y_1$ and $y_2$ unless the two records agree on $S$ or on $S^c$.
:::

::: {custom-style="Statement"}
\(iii) For a linear cost $c(x)=\sum_ja_jx_j$, $c(m)\ge\sum_j\text{min}_{i:\,j\in S_i}a_jy_{ij}$. The read can beat the best archived design, but never the best coordinatewise combination of observed values.
:::

::: {custom-style="Statement Tag"}
\(i) V2 Proposition 5.3; (ii) and (iii) New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) $H$ is diagonal with entries $\kappa_j$, and the normal equations decouple coordinate by coordinate. (ii) A point of the segment is $(1-t)y_1+ty_2$. It agrees with the read on $S$ only if $t\,(y_2-y_1)_S=0$, and on $S^c$ only if $(1-t)(y_1-y_2)_{S^c}=0$. If both differences are nonzero, these force $t=0$ and $t=1$. (iii) By (i), each term $a_jm_j$ is a convex combination of the values $a_jy_{ij}$ with $j\in S_i$. ∎

::: {custom-style="Check"}
*Numerical check.* In 396 random masked stars in $ℝ^4$ (4 further stars had a coverage below $10^{-8}$ and were skipped), no read left its coordinate box, and 345 left the archive hull according to a linear-programming test. All 300 of 300 complementary pairs read outside their segment. In 400 masked stars with random linear costs, the floor of (iii) was never violated, and the read beat the best archived design in 15 of them (3.8%).
:::

*Engineering meaning.* Coordinate recombination breaks the ceiling of Corollary 3.4: a record contributes its strong subassembly without its weak ones (Figure 1b). This is the mechanism behind hypothesis C2 of V2. It creates candidates, not feasible designs: coupled loads, interfaces and global stability must be re-evaluated [14, Section 5]. Part (iii) bounds the gain, since recombination cannot extrapolate beyond the observed values of each coordinate.

### 3.4 Conditioning

The read is well conditioned when the observation spaces of the retrieved records meet at large angles. Principal angles between subspaces make this exact [3].

::: {custom-style="Statement"}
**Proposition 3.6** (two weighted subspaces). Let $P_1,P_2$ be orthogonal projectors onto subspaces $S_1,S_2\subseteq ℝ^D$ of dimensions $k_1\le k_2$, let $c_1,c_2>0$, and let $\theta_1,\ldots,\theta_{k_1}$ be the principal angles between $S_1$ and $S_2$.
:::

::: {custom-style="Statement"}
\(i) The spectrum of $c_1P_1+c_2P_2$ consists of $c_1+c_2$ once for each zero angle; $c_1$ once for each right angle; $c_2$ with multiplicity $k_2-n_0-n_m$, where $n_0$ counts the zero angles and $n_m$ the angles strictly between $0$ and $\pi/2$; for each $\theta_j\in(0,\pi/2)$ the pair
:::

::: {custom-style="Statement Equation"}
$\tfrac12\Big[(c_1+c_2)\pm\sqrt{(c_1+c_2)^2-4c_1c_2\sin^2\theta_j}\,\Big]$ (3.4)
:::

::: {custom-style="Statement"}
and $0$ for the remaining dimensions.
:::

::: {custom-style="Statement"}
\(ii) Suppose $S_1+S_2=ℝ^D$. Let $\theta_F$ be the smallest nonzero principal angle, or $\pi/2$ if every principal angle is zero, and let $h=2c_1c_2/(c_1+c_2)$. Then
:::

::: {custom-style="Statement Equation"}
$\tfrac12h\sin^2\theta_F\le\lambda_{\text{min}}(c_1P_1+c_2P_2)\le h\sin^2\theta_F$ (3.5)
:::

::: {custom-style="Statement"}
where the upper bound requires $\theta_F<\pi/2$. The constant $\tfrac12$ is sharp as $\theta_F\to 0$.
:::

::: {custom-style="Statement Tag"}
\(i) Classical: the two-subspace decomposition [16] made explicit; (ii) New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) By Halmos's theorem, $ℝ^D$ splits orthogonally into $S_1\cap S_2$, $S_1\cap S_2^{\perp}$, $S_1^{\perp}\cap S_2$, $S_1^{\perp}\cap S_2^{\perp}$ and a sum of two-dimensional subspaces invariant under both projectors. There is one such subspace for each principal angle in $(0,\pi/2)$, and on it $P_1$ and $P_2$ project onto two lines at that angle [16]. The first four summands contribute $c_1+c_2$, $c_1$, $c_2$ and $0$, with the stated multiplicities: zero angles count $S_1\cap S_2$, right angles count $S_1\cap S_2^{\perp}$ because $k_1\le k_2$, and the rest of $S_2$ lies in $S_1^{\perp}\cap S_2$. On each two-dimensional block the trace is $c_1+c_2$ and the determinant is $c_1c_2\sin^2\theta_j$, which gives (3.4). (ii) The smaller root of (3.4) equals $2c_1c_2\sin^2\theta/[(c_1+c_2)+\sqrt{(c_1+c_2)^2-4c_1c_2\sin^2\theta}\,]$. The denominator lies between $c_1+c_2$ and $2(c_1+c_2)$, so the root lies between $\tfrac12h\sin^2\theta$ and $h\sin^2\theta$, and it increases with $\theta$. Spanning excludes the eigenvalue $0$. The eigenvalues $c_1$, $c_2$ and $c_1+c_2$ are at least $\text{min}(c_1,c_2)\ge\tfrac12h$. Hence the lower bound holds, and the upper bound holds whenever a block exists. As $\theta\to 0$, the denominator tends to $2(c_1+c_2)$. ∎

::: {custom-style="Check"}
*Numerical check.* In 460 random spanning pairs, 190 of them with an interior angle, bound (3.5) was never violated. The ratio $\lambda_{\text{min}}/(h\sin^2\theta_F)$ ranged from 0.5000004 to 0.811. In 500 further pairs with 263 interior angles, the spectrum (i) matched the computed eigenvalues to 1.2 × 10⁻¹⁴.
:::

::: {custom-style="Statement"}
**Proposition 3.7** (amplification and coverage). Let $G=\sum_ic_iQ_i^{\top}Q_i\succ 0$ with fixed coefficients $c_i>0$, and let $m=G^{-1}\sum_ic_iQ_i^{\top}o_i$.
:::

::: {custom-style="Statement"}
\(i) The read moves with record $i$'s observation through $\partial m/\partial o_i=G^{-1}c_iQ_i^{\top}$, and $\|G^{-1}c_iQ_i^{\top}\|\le(c_i/\lambda_{\text{min}}(G))^{1/2}$.
:::

::: {custom-style="Statement"}
\(ii) For coordinate masks with $c_i=\alpha_i$, $\lambda_{\text{min}}(H)=\text{min}_j\,\kappa_j$.
:::

::: {custom-style="Statement"}
\(iii) For two lines in the plane with unit normals at an angle $\theta$ and $c_1=c_2=1$, a unit move of $o_1$ moves the read by exactly $1/\sin\theta$.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) Write $X=G^{-1}c_iQ_i^{\top}$. Then $XX^{\top}=c_i\,G^{-1}(c_iQ_i^{\top}Q_i)G^{-1}\preceq c_i\,G^{-1}GG^{-1}=c_iG^{-1}$, because $c_iQ_i^{\top}Q_i\preceq G$ and congruence preserves order. Hence $\|X\|^2\le c_i/\lambda_{\text{min}}(G)$. (ii) $H$ is diagonal with entries $\kappa_j$. (iii) Take $n_1=e_1$ and $n_2=(\cos\theta,\sin\theta)$. Then $G^{-1}n_1=(1,-\cot\theta)$, whose norm is $1/\sin\theta$. ∎

::: {custom-style="Check"}
*Numerical check.* In 400 random stars, (i) held for every record, with largest ratio 0.9991. In 300 masked stars, $\lambda_{\text{min}}(H)$ equalled the smallest coverage to 0. For two lines at $\theta=\pi/2,\pi/4,\pi/8,\pi/16$ and $\pi/32$, the displacement was 1.000, 1.414, 2.613, 5.126 and 10.202, against the bound (i) of 1.000, 1.848, 3.625, 7.214 and 14.411 (Figure 1c).
:::

*Engineering meaning.* Nearly parallel observation spaces make the read hypersensitive. Two gauges that measure almost the same combination of member forces locate the design poorly in the orthogonal direction. Coverage is the masked form of the same effect. A layer therefore reports $\lambda_{\text{min}}(H)$, or the smallest coverage, with every read, and a small value triggers the conditioning control of V2: enlarge the star, add a declared prior, or retain the token's value.

### 3.5 Residual and soft energy

::: {custom-style="Statement"}
**Proposition 3.8** (residual at the read). If $H\succ 0$, then $\sum_i\alpha_i\|Q_im-o_i\|^2=\sum_i\alpha_i\|o_i\|^2-b^{\top}H^{-1}b$. For square orthogonal maps, this equals $\text{tr}\,C$ with $C=\sum_i\alpha_i(v_i-m)(v_i-m)^{\top}$, the weighted spread of the transported records.
:::

::: {custom-style="Statement Tag"}
Classical least squares; the trace form is its orthogonal case.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* In 300 random orthogonal stars, the residual and $\text{tr}\,C$ agreed to 5.3 × 10⁻¹⁵.
:::

The read is also a step on an energy. With query-independent weights $w_i$ on a region where the star and maps are fixed, V2 defines the soft discrepancy energy

::: {custom-style="Equation"}
$E_s(z)=-s^2\log\sum_iw_i\exp(-e_i(z)/s^2)$ (3.6)
:::

::: {custom-style="Statement"}
**Proposition 3.9** (gradient and Hessian of the soft energy). Let $g_i=Q_i^{\top}(Q_iz-o_i)$, the gradient of $e_i$, and let $c_A=\text{max}_i\,\lambda_{\text{max}}(Q_i^{\top}Q_i)$. Then
:::

::: {custom-style="Statement Equation"}
$\nabla E_s(z)=H\,(z-m),\qquad \nabla^2E_s(z)=H-s^{-2}\,\text{Cov}_\alpha(g)\preceq H\preceq c_AI$ (3.7)
:::

::: {custom-style="Statement"}
where $\text{Cov}_\alpha(g)=\sum_i\alpha_i(g_i-\langle g\rangle)(g_i-\langle g\rangle)^{\top}$. The gradient identity holds with the retention read when $H$ is singular.
:::

::: {custom-style="Statement Tag"}
Gradient: V2 Proposition 6.1; Hessian: New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* $\nabla E_s=\sum_i\alpha_ig_i=Hz-b$, and $b=Hm$ by Proposition 3.2. Differentiating again, $\nabla g_i=Q_i^{\top}Q_i$ and $\nabla\alpha_i=-s^{-2}\alpha_i(g_i-\langle g\rangle)$, so $\nabla^2E_s=H-s^{-2}\sum_i\alpha_i(g_i-\langle g\rangle)g_i^{\top}$, which is the stated covariance form. ∎

::: {custom-style="Check"}
*Numerical check.* In 300 random stars, central differences matched the gradient to a relative 1.8 × 10⁻⁹. In 300 stars, finite differences of the gradient matched the Hessian to a relative 1.3 × 10⁻⁹.
:::

### 3.6 Sheaf mean shift

::: {custom-style="Statement"}
**Theorem 3.10** (sheaf attention is a majorise–minimise step). Fix $z$, and compute $\alpha$, $H$, $b$ and the read $m$ at $z$.
:::

::: {custom-style="Statement"}
\(i) For every $\lambda\in[0,2]$,
:::

::: {custom-style="Statement Equation"}
$E_s(z+\lambda(m-z))\le E_s(z)-\tfrac12\lambda(2-\lambda)\,\|z-m\|_H^2$ (3.8)
:::

::: {custom-style="Statement"}
with $\|x\|_H^2=x^{\top}Hx$, and with equality for every $\lambda$ when the star has a single record.
:::

::: {custom-style="Statement"}
\(ii) $m=z$ if and only if $\nabla E_s(z)=0$, also when $H$ is singular.
:::

::: {custom-style="Statement"}
\(iii) Let $z_{t+1}=z_t+\lambda_t(m(z_t)-z_t)$ with $\epsilon\le\lambda_t\le 2-\epsilon$ for some $\epsilon>0$. Then $E_s(z_t)$ is non-increasing, $\sum_t\|z_t-m(z_t)\|_{H(z_t)}^2<\infty$, and $\nabla E_s(z_t)\to 0$.
:::

::: {custom-style="Statement Tag"}
New in Part II; an instance of the majorise–minimise principle [21]. For identity maps and $\lambda=1$ it is the bound-optimisation and EM view of Gaussian mean shift [5, 6, 8, 11] and the concave–convex view of modern Hopfield retrieval [23, 26].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) The function $F(e)=-s^2\log\sum_iw_ie^{-e_i/s^2}$ is concave on $ℝ^n$, being $-s^2$ times a log-sum-exp of affine functions of $e$, and $\partial F/\partial e_i=\alpha_i$. The tangent inequality at $e(z)$ gives $F(e')\le F(e(z))+\sum_i\alpha_i(e'_i-e_i(z))$. Putting $e'=e(x)$ yields $E_s(x)\le E_s(z)+M(x)-M(z)$ with the frozen quadratic $M$ of Proposition 3.2. Since $m$ minimises $M$, $M(x)-M(m)=\tfrac12\|x-m\|_H^2$ for every $x$. For $x=z+\lambda(m-z)$ we have $x-m=(1-\lambda)(z-m)$, so $M(x)-M(z)=-\tfrac12\lambda(2-\lambda)\|z-m\|_H^2$. With one record, $F$ is affine and the tangent inequality is an equality. (ii) $\nabla E_s(z)=Hz-b$. If $m=z$, then $Hz=Hm=b$. Conversely, if $Hz=b$, then $m=z+H^{\dagger}\cdot 0=z$. (iii) Each $e_i\ge 0$, so $E_s\ge -s^2\log\sum_iw_i$ is bounded below. Summing (3.8), and using $\tfrac12\lambda_t(2-\lambda_t)\ge\tfrac12\epsilon(2-\epsilon)$, gives the finite sum. Finally, $\|\nabla E_s(z_t)\|^2=\|H_t(z_t-m_t)\|^2\le\|H_t\|\,\|z_t-m_t\|_{H_t}^2\le c_A\|z_t-m_t\|_{H_t}^2\to 0$. ∎

The theorem guarantees descent, not convergence of the iterates. Convergence of Gaussian mean-shift iterates needs further conditions even for identity maps [5]. The interval $[0,2]$ cannot be enlarged in general: for a single record (3.8) is an equality, and the energy rises for every $\lambda>2$. Over-relaxed steps with $1<\lambda<2$ remain guaranteed descent steps.

::: {custom-style="Check"}
*Numerical check.* In 3,000 random stars drawn equally from the four map classes, with random $\lambda\in(0,2)$, inequality (3.8) was never violated. The smallest ratio of actual to guaranteed decrease was 1.000000000000, so the bound is attained to rounding. For $\lambda\in(2.05,3)$, the energy rose in 1,942 of 3,000 trials (65%). In 40 runs of 400 read iterations, every energy sequence was non-increasing, the largest final gradient was 3.2 × 10⁻¹⁵, and 2 runs ended at a singular $H$, where the retention read applied.
:::

![**Figure 2.** Sheaf mean shift in the plane with two full records (dots) and three partial records, each observing one linear combination (lines), at $s=0.6$. (a) Contours of the soft energy and the read iteration from four starts. The stars are the three local minima. (b) The soft energy along the relaxed iteration from one start. It decreases monotonically for $\lambda=0.5$, $1$ and $1.5$, as Theorem 3.10 guarantees. At $\lambda=2.4$ it rises in 10 of 25 steps and never settles.](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p2/fig/meanshift.png){width=100%}

ADE is the special case with identity maps. The next statement restates the exact reduction of V2 in the present notation, so that Theorem 3.10 can be applied to it.

::: {custom-style="Statement"}
**Proposition 3.11** (ADE is the identity star). Take identity maps, the ADE archive weights, $s_t^2=(1-a_t)/a_t$ and $q_t=\sqrt{a_t}\,z_t$. With $0\le\eta\le 1$,
:::

::: {custom-style="Statement Equation"}
$\sigma_t^2=\eta^2\frac{1-a_{t-1}}{1-a_t}\Big(1-\frac{a_t}{a_{t-1}}\Big),\quad A_t=\sqrt{\frac{1-a_{t-1}-\sigma_t^2}{1-a_t}},\quad \lambda_t=1-A_t\sqrt{\frac{a_t}{a_{t-1}}}$ (3.9)
:::

::: {custom-style="Statement"}
the ADE update $q_{t-1}=A_tq_t+B_tm_t+\sigma_t\xi_t$, with $B_t=\sqrt{a_{t-1}}-A_t\sqrt{a_t}$, equals $z_{t-1}=(1-\lambda_t)z_t+\lambda_tm_t(z_t)+\sigma_t\xi_t/\sqrt{a_{t-1}}$ in the scaled coordinate.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 6.2.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* In 100 random archives and schedules, the two updates agreed to 2.3 × 10⁻¹⁵.
:::

::: {custom-style="Statement"}
**Corollary 3.12** (every deterministic ADE layer descends at its own scale). Let $\eta=0$ and $0<a_t<a_{t-1}\le 1$. Then $\lambda_t=1-\sqrt{a_t(1-a_{t-1})/(a_{t-1}(1-a_t))}$ satisfies $0<\lambda_t\le 1$, and the deterministic ADE layer satisfies
:::

::: {custom-style="Statement Equation"}
$E_{s_t}(z_{t-1})\le E_{s_t}(z_t)-\tfrac12\lambda_t(2-\lambda_t)\,\|z_t-m_t(z_t)\|^2$ (3.10)
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* With $\sigma_t=0$, the formula for $\lambda_t$ follows from (3.9). The ratio under the root is nonnegative, and it is below 1 exactly when $a_t<a_{t-1}$. Apply Theorem 3.10 with identity maps, for which $H=I$. ∎

The scale changes from layer to layer, so (3.10) compares two points on one energy and not energies of different layers. An ADE stack is a sequence of guaranteed-descent steps on a sequence of annealed energies.

::: {custom-style="Check"}
*Numerical check.* On the 16-layer cosine schedule with the bottom cut off at $a_{16}=10^{-4}$, the coefficients $\lambda_t$ ranged from 0.1793 to 1.0000. Along deterministic trajectories in 100 random archives (1,600 layer steps), (3.10) was never violated, and the smallest ratio of actual to guaranteed decrease was 1.000000000000.
:::

::: {custom-style="Statement"}
**Proposition 3.13** (the Euclidean energy step). For $0\le\lambda\le 2/c_A$,
:::

::: {custom-style="Statement Equation"}
$E_s(z-\lambda\nabla E_s(z))\le E_s(z)-\lambda(1-\tfrac12\lambda c_A)\|\nabla E_s(z)\|^2$ (3.11)
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* By (3.7), $\nabla^2E_s\preceq c_AI$ everywhere. Taylor's formula with integral remainder along the segment gives $E_s(z+d)\le E_s(z)+\nabla E_s(z)^{\top}d+\tfrac12c_A\|d\|^2$. Put $d=-\lambda\nabla E_s(z)$. ∎

::: {custom-style="Check"}
*Numerical check.* In 300 random stars with random $\lambda\in(0,2/c_A)$, inequality (3.11) was never violated; the smallest ratio of actual to guaranteed decrease was 1.00000.
:::

Table 3 collects the three updates of V2 and the guarantee that this section proves for each.

Table: **Table 3.** Layer updates and their guarantees. The noise term is omitted.

| Update | Formula | Interpretation | Guarantee |
|:----------------|:------------------|:-------------------|:-------------------|
| orthogonal transport | $z'=(1-\lambda)z+\lambda m$ | gradient step $z-\lambda\nabla E_s$, since $H=I$ | descent for $0<\lambda<2$ (Theorem 3.10) |
| harmonic interpolation | $z'=(1-\lambda)z+\lambda m$ | preconditioned step $z-\lambda H^{-1}\nabla E_s$ | descent for $0<\lambda<2$ (Theorem 3.10) |
| Euclidean energy step | $z'=z-\lambda H(z-m)$ | gradient step $z-\lambda\nabla E_s$ | descent for $0<\lambda<2/c_A$ (Proposition 3.13) |


## 4 Gaussian models in a stalk

ADE rests on a Gaussian observation model: the query is a noisy view of an archived design, and the read is a posterior mean [13, Chapter 3]. In ASE that model becomes local. It is attached to one stalk, and the records are seen through their maps. This section asks which of the Gaussian identities of ADE survive, and in what form.

### 4.1 Tweedie's identity and the chart posterior

::: {custom-style="Statement"}
**Proposition 4.1** (Tweedie's identity in a stalk).
:::

::: {custom-style="Statement"}
\(i) For square orthogonal maps, let $p_s(z)=\sum_iw_i\,N(z;v_i,s^2I)/\sum_iw_i$ with $v_i=Q_i^{\top}o_i$. Then $m(z)=z+s^2\nabla\log p_s(z)$.
:::

::: {custom-style="Statement"}
\(ii) For general maps, let $\tilde p_s(z)=\sum_iw_i\exp(-e_i(z)/s^2)$, which may have infinite mass. Then $H(z)(m(z)-z)=s^2\nabla\log\tilde p_s(z)$, and if $H\succ 0$,
:::

::: {custom-style="Statement Equation"}
$m(z)=z+s^2H(z)^{-1}\nabla\log\tilde p_s(z)$ (4.1)
:::

::: {custom-style="Statement Tag"}
\(i) Classical: Tweedie's formula [10], in the unscaled form of Mathematics book Proposition 3.3; (ii) New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Since $\log\tilde p_s=-E_s/s^2$, Proposition 3.9 gives $s^2\nabla\log\tilde p_s=-\nabla E_s=H(m-z)$, which is (ii). For square orthogonal maps $e_i=\tfrac12\|z-v_i\|^2$, so $\tilde p_s$ is proportional to $p_s$ and $H=I$. ∎

::: {custom-style="Check"}
*Numerical check.* In 200 random orthogonal stars, $z+s^2\nabla\log p_s$, with the gradient taken by central differences, matched the read to 9.8 × 10⁻¹⁰. Part (ii) is the gradient identity of Proposition 3.9, checked there.
:::

The preconditioned form (4.1) says that the read follows the score of the local density, rescaled by the inverse of the normal matrix. Only the gradient of a logarithm enters, so the identity holds even when $\tilde p_s$ cannot be normalised (Proposition 4.3).

The mathematics book also reads full designs through a chart, but from the other side: there the token is observed through the chart, while the records are complete [13, Proposition 3.8]. The two operators can be compared exactly.

::: {custom-style="Statement"}
**Proposition 4.2** (chart posterior and sheaf read). Let $U\in ℝ^{D\times k}$ have orthonormal columns, let $\Sigma$ be a positive diagonal $k\times k$ matrix and $A=\Sigma^{-1}U^{\top}$, and let the records be full designs $y_i$. Put $a=1/(1+s^2)$ and $q=\sqrt a\,Az$.
:::

::: {custom-style="Statement"}
\(i) The posterior mean of the full design under the chart observation $q$ [13, Proposition 3.8] is $m_{\text{chart}}=\sum_i\alpha_iy_i$, with $\alpha_i\propto w_i\exp(-\|Az-Ay_i\|^2/2s^2)$. These are exactly the weights of sheaf attention with $Q_i=A$ and $o_i=Ay_i$.
:::

::: {custom-style="Statement"}
\(ii) The sheaf read of the same observations is $m_{\text{sheaf}}=P_Am_{\text{chart}}+(I-P_A)z$, where $P_A=A^{\dagger}A$ is the orthogonal projector onto the row space of $A$. Hence
:::

::: {custom-style="Statement Equation"}
$m_{\text{chart}}-m_{\text{sheaf}}=(I-P_A)(m_{\text{chart}}-z)$ (4.2)
:::

::: {custom-style="Statement Tag"}
Mathematics book Proposition 3.8; the comparison is New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) The logit of [13, (3.7)] is $\|q-\sqrt a\,Ay_i\|^2/2(1-a)=a\|Az-Ay_i\|^2/2(1-a)$, and $a/(1-a)=1/s^2$. (ii) Here $H=A^{\top}A$ and, since the weights sum to one, $b=A^{\top}A\,m_{\text{chart}}$. Then $H^{\dagger}H=A^{\dagger}A=P_A$, so $m_{\text{sheaf}}=z+H^{\dagger}H(m_{\text{chart}}-z)=z+P_A(m_{\text{chart}}-z)$. ∎

::: {custom-style="Check"}
*Numerical check.* In 200 random charts, the two weight vectors agreed to 4.7 × 10⁻¹⁶, and (4.2) held to 4.1 × 10⁻¹⁵. The median distance between the two reads was 1.49.
:::

*Engineering meaning.* The two operators answer different questions. The chart posterior returns a convex combination of complete archived designs, and so it imports the records' coordinates off the chart. Sheaf attention keeps the token's coordinates off the chart, because it sees the records only through their maps. Which one is right depends on what the records carry. Complete designs make the posterior available. Partial observations leave sheaf attention as the only defensible read.

### 4.2 Two local laws

A local Gaussian model in a stalk can be built from the records in two ways, and the difference matters as soon as a record is partial.

::: {custom-style="Statement"}
**Proposition 4.3** (mixture and product). Freeze the weights $\alpha$ at the query.
:::

::: {custom-style="Statement"}
\(i) The record mixture $\mu_{\text{mix}}(dx)\propto\sum_iw_i\exp(-e_i(x)/s^2)\,dx$ has finite mass if and only if every $Q_i$ is injective.
:::

::: {custom-style="Statement"}
\(ii) The product of experts $\mu_{\text{prod}}(dx)\propto\prod_i\exp(-\alpha_ie_i(x)/s^2)\,dx=\exp(-M(x)/s^2)\,dx$ has finite mass if and only if $H\succ 0$, and then $\mu_{\text{prod}}=N(m,s^2H^{-1})$.
:::

::: {custom-style="Statement Tag"}
New in Part II; products of experts after [18].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) The $i$-th term is constant along $\text{ker}\,Q_i$ and Gaussian along $\text{range}\,Q_i^{\top}$, so its integral is finite if and only if $\text{ker}\,Q_i=\{0\}$. A finite sum of positive terms has finite integral if and only if each term does. (ii) By Proposition 3.2, $M(x)=M(m)+\tfrac12(x-m)^{\top}H(x-m)$. The Gaussian integral is finite if and only if $H\succ 0$, and its covariance is then $s^2H^{-1}$. ∎

::: {custom-style="Check"}
*Numerical check.* At $s=1$, on boxes of half-width 5, 10, 20 and 40, the mass of a full record in the plane was 6.283, 6.283, 6.283 and 6.283, which is $2\pi$ every time. The mass of a record observing one coordinate was 25.1, 50.2, 100.4 and 200.8, proportional to the box width. The product of two records observing complementary coordinates has $\lambda_{\text{min}}(H)=0.5$; the product of two records observing the same coordinate has $\lambda_{\text{min}}(H)=0$.
:::

*Engineering meaning.* A local law in ASE must say whether it is a mixture or a product. A mixture of partial records is not a probability law; it cannot be sampled or used as an importance proposal without a declared prior [14, Section 15]. A product is a law exactly when the records jointly cover the frame, and its covariance $s^2H^{-1}$ is the conditioning of Proposition 3.6 in probabilistic form.

::: {custom-style="Statement"}
**Proposition 4.4** (imputation, gradient steps and the harmonic read). Let every $Q_i$ be a partial isometry, $Q_iQ_i^{\top}=I$, and freeze $\alpha$ at $z$. Impute record $i$ from the token by $x_i(z)=Q_i^{\top}o_i+(I-Q_i^{\top}Q_i)z$, the point of $\{x:Q_ix=o_i\}$ nearest to $z$, and let $m_A=\sum_i\alpha_ix_i$.
:::

::: {custom-style="Statement"}
\(i) $m_A=z-\nabla E_s(z)$: one imputation is a unit gradient step.
:::

::: {custom-style="Statement"}
\(ii) If $H\succ 0$, then $m-z=H^{-1}(m_A-z)$ and $\|m-z\|\ge\|m_A-z\|$: the harmonic read is the preconditioned step, and it moves at least as far.
:::

::: {custom-style="Statement"}
\(iii) Repeated imputation with frozen weights, $x_{k+1}=\sum_i\alpha_i[Q_i^{\top}o_i+(I-Q_i^{\top}Q_i)x_k]$ with $x_0=z$, satisfies $\|x_k-m\|\le(1-\lambda_{\text{min}}(H))^k\|z-m\|$ and converges to the harmonic read.
:::

::: {custom-style="Statement Tag"}
New in Part II; (iii) is Cimmino's method of averaged projections [7] in the present notation.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) $m_A=b+(I-H)z=z-(Hz-b)$. (ii) $H(m-z)=b-Hz=m_A-z$. Each $Q_i^{\top}Q_i$ is an orthogonal projector, so $H\preceq I$ and, with $H\succ 0$, $H^{-1}\succeq I$. (iii) Since $m=b+(I-H)m$, we have $x_{k+1}-m=(I-H)(x_k-m)$, and $\|I-H\|=1-\lambda_{\text{min}}(H)$. ∎

::: {custom-style="Check"}
*Numerical check.* In 300 stars with masks and partial isometries, (i) held to 1.3 × 10⁻¹³, and (ii) to 1.6 × 10⁻⁹ on the 295 stars with condition number below $10^8$. The median distance between $m_A$ and $m$ was 0.949. In 200 further stars, the rate bound of (iii) held at $k=50$ in every case. On the 165 stars with $\lambda_{\text{min}}(H)>0.05$, 2,000 sweeps reached the read to 5.7 × 10⁻¹⁵.
:::

![**Figure 3.** (a) Two partial records whose observation sets are lines, with equal frozen weights. The imputations (squares) are the projections of the token onto the lines; their average is one gradient step (Proposition 4.4(i)), and repeated averaging converges to the harmonic read at the intersection (Proposition 4.4(iii)). (b) The smallest eigenvalue of $H$ against the selection strength $\beta$ for twelve masked records in $ℝ^4$, with an elite that observes two coordinates or all four (Proposition 4.6; register values). (c) Total variation between the weights before and after a bounded measurement error, against $\beta\varepsilon$, for 1,500 random trials drawn for the figure, with the sharp bound $\tanh(\beta\varepsilon/2)$ of Theorem 4.8.](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p2/fig/stalks.png){width=100%}

*Engineering meaning.* An imputation crossover fills a parent's missing coordinates from the current design. By Proposition 4.4 it takes one gradient step on the soft energy, and repeating it with fixed weights converges to the harmonic read. The harmonic read moves farther in poorly covered directions. That is where recombination acts, and also where conditioning matters.

### 4.3 Tilting

The mathematics book tilts a Gaussian by a linear loss and moves its mean by $-\beta\Sigma a$ [13, Theorem 4.4]. Two tilts arise in a stalk: of the local law, and of the record weights by selection.

::: {custom-style="Statement"}
**Proposition 4.5** (tilting the product law). If $H\succ 0$, tilting $\mu_{\text{prod}}=N(m,s^2H^{-1})$ by $e^{-\beta a^{\top}x}$ gives $N(m-\beta s^2H^{-1}a,\ s^2H^{-1})$. If $H$ is singular, the tilted measure has infinite mass for every $a$, and its mass on growing boxes grows exponentially when $a$ has a component in $\text{ker}\,H$.
:::

::: {custom-style="Statement Tag"}
Mathematics book Theorem 4.4 with $\Sigma=s^2H^{-1}$; the singular case is New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Complete the square [13, Theorem 4.4]. If $H$ is singular, write $x=x_r+x_k$ with $x_k\in\text{ker}\,H$. The tilted density factorises, and its factor on $\text{ker}\,H$ is $\exp(-\beta a_k^{\top}x_k)$, whose integral over $\text{ker}\,H$ is infinite whatever $a_k$ is. ∎

::: {custom-style="Check"}
*Numerical check.* In 100 random two-dimensional stalks, the tilted mean computed by quadrature matched the formula to a relative 8.4 × 10⁻¹⁴. For $H=\text{diag}(1,0)$ and $\beta=1$, with slope $0.5$ along the unobserved axis, the mass on boxes of half-width 5, 10, 20 and 40 was 63.6, 781, 1.16 × 10⁵ and 2.58 × 10⁹. With no slope there it was 26.2, 52.5, 104.9 and 209.9.
:::

A linear objective therefore moves the local mean along $H^{-1}a$, farthest where coverage is thin. In an unobserved direction it pushes without limit, so a tilted local proposal needs coverage, a declared prior or a step bound in every direction in which the objective has slope.

::: {custom-style="Statement"}
**Proposition 4.6** (selection tilting collapses coverage). Let $w_i=w_i^0e^{-\beta J_i}$, where $J$ has a unique minimiser $\iota$, the elite record, and gap $\Delta=\text{min}_{i\ne\iota}(J_i-J_\iota)>0$. For coordinate masks and every coordinate $j\notin S_\iota$,
:::

::: {custom-style="Statement Equation"}
$\lambda_{\text{min}}(H)\le\kappa_j\le e^{-\beta\Delta}\sum_{i\ne\iota}\frac{w_i^0}{w_\iota^0}\exp\Big(\frac{e_\iota(z)-e_i(z)}{s^2}\Big)$ (4.3)
:::

::: {custom-style="Statement"}
So $\lambda_{\text{min}}(H)\to 0$ exponentially as $\beta\to\infty$. In the limit the read is resolved only on $S_\iota$, and the token's value is kept elsewhere. If the elite observes every coordinate, then $H\to I$.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* $\kappa_j\le\sum_{i\ne\iota}\alpha_i\le\sum_{i\ne\iota}\alpha_i/\alpha_\iota$, and $\alpha_i/\alpha_\iota=(w_i^0/w_\iota^0)\,e^{-\beta(J_i-J_\iota)}\,e^{(e_\iota-e_i)/s^2}$. As $\beta\to\infty$, $\alpha$ tends to the indicator of $\iota$ and $H$ to $Q_\iota^{\top}Q_\iota$. ∎

::: {custom-style="Check"}
*Numerical check.* For twelve masked records in $ℝ^4$ at $s=1.5$, with an elite observing two coordinates, $\lambda_{\text{min}}(H)$ was 0.446, 0.261, 0.0154, 1.8 × 10⁻⁷, 2.6 × 10⁻²¹ and 5.5 × 10⁻⁶⁹ at $\beta=0,1,3,10,30$ and $100$. With an elite observing all four coordinates it was 0.551, 0.683, 0.970, 0.9999995, 1.000 and 1.000 (Figure 3b).
:::

*Engineering meaning.* Under strong selection, a partial elite is copied wherever it observed and the token is kept elsewhere, so recombination stops. Annealing $\beta$, or a coverage floor that keeps a minimum weight on records observing each coordinate, keeps recombination alive.

### 4.4 Measurement

::: {custom-style="Statement"}
**Proposition 4.7** (Gaussian measurement noise). (i) If the loss of a design is measured as the mean $S_k$ of $k$ independent $N(J+b,\sigma^2)$ judgements, then $E\,e^{-\beta S_k}=\exp(-\beta(J+b)+\beta^2\sigma^2/2k)$, so heteroscedastic noise changes the expected weights. (ii) The plug-in correction $\exp(-\beta S_k-\beta^2V/2k)$, with $V$ the sample variance, is biased upward. (iii) A shared error with correlation $\rho$ survives repetition: the residual factor tends to $e^{\beta^2\sigma^2\rho/2}$ as $k\to\infty$.
:::

::: {custom-style="Statement Tag"}
Mathematics book Propositions 4.8, 4.9 and 4.10, retained in a specified local measure.
:::

::: {custom-style="Gap"}
&nbsp;
:::

Proposition 4.7 concerns expected weights under Gaussian noise. An engineering critic, such as a surrogate model or a coarse analysis, is often known only to be within a tolerance. The next theorem covers that case.

::: {custom-style="Statement"}
**Theorem 4.8** (bounded measurement error). Let the losses be measured as $J_i+\delta_i$ with $|\delta_i|\le\varepsilon$, so that the weights become $\alpha'_i\propto\alpha_ie^{-\beta\delta_i}$.
:::

::: {custom-style="Statement"}
\(i) $\text{TV}(\alpha,\alpha')=\tfrac12\sum_i|\alpha'_i-\alpha_i|\le\tanh(\beta\varepsilon/2)$. Equality holds for two records with $\alpha=(p,1-p)$, $p=1/(1+e^{\beta\varepsilon})$ and $\delta=(-\varepsilon,\varepsilon)$.
:::

::: {custom-style="Statement"}
\(ii) For square orthogonal maps, $\|m'-m\|\le\tanh(\beta\varepsilon/2)\,\text{diam}\{v_i\}$.
:::

::: {custom-style="Statement"}
\(iii) For general maps with $H,H'\succ 0$, $\|m'-m\|\le\text{TV}(\alpha,\alpha')\,\text{diam}\{Q_i^{\top}r_i\}/\lambda_{\text{min}}(H')$, where $r_i=Q_im-o_i$.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) $\text{TV}(\alpha,\alpha')=\text{max}_A(\alpha'(A)-\alpha(A))$ over sets of records. Fix $A$ with $\alpha(A)=p$. Then $\alpha'(A)=X/(X+Y)$ with $X=\sum_{i\in A}\alpha_ie^{-\beta\delta_i}\le pe^{\beta\varepsilon}$ and $Y=\sum_{i\notin A}\alpha_ie^{-\beta\delta_i}\ge(1-p)e^{-\beta\varepsilon}$. The ratio increases in $X$ and decreases in $Y$, so with $u=e^{2\beta\varepsilon}$ we get $\alpha'(A)-p\le\varphi(p)$, where $\varphi(p)=pu/(pu+1-p)-p$. Setting the derivative of $\varphi$ to zero gives $p=1/(\sqrt u+1)$. At that point $\varphi=(\sqrt u-1)/(\sqrt u+1)$, which equals $\tanh(\beta\varepsilon/2)$. The two-point example attains this value. (ii) $m'-m=\sum_i(\alpha'_i-\alpha_i)v_i$. The positive and negative parts of $\alpha'-\alpha$ each have mass $\text{TV}$, so this is $\text{TV}$ times the difference of two convex combinations of the $v_i$. (iii) $\sum_i\alpha_iQ_i^{\top}r_i=Hm-b=0$. Hence $H'(m'-m)=b'-H'm=-\sum_i\alpha'_iQ_i^{\top}r_i=-\sum_i(\alpha'_i-\alpha_i)Q_i^{\top}r_i$, and the argument of (ii) applies. ∎

::: {custom-style="Check"}
*Numerical check.* In 2,000 random weight vectors, half of them with the extremal pattern $\delta_i=\pm\varepsilon$, (i) was never violated; the largest ratio to the bound was 0.9999985, and for (ii) it was 0.998. In 600 general stars, (iii) was never violated, with largest ratio 0.893. The two-point example at $\beta=2$ and $\varepsilon=0.7$ gave $\text{TV}=0.604368=\tanh(0.7)$.
:::

*Engineering meaning.* Theorem 4.8 sets the selection strength against the critic's error. If losses are misstated by at most $\varepsilon$, the read of a transported archive moves by at most $\tanh(\beta\varepsilon/2)$ of its diameter, about 10% when $\beta\varepsilon=0.2$. Equivalently, a tolerance $\nu$ on the relative displacement holds whenever $\beta\le 2\,\text{artanh}(\nu)/\varepsilon$. Unlike Proposition 4.7, the bound is worst case and assumes no distribution.


## 5 Scale, locality and covers

A layer at scale $s$ should touch only the records near the token. Two questions follow. How much does truncating the read to a star change it? And how sensitive is the read to the token itself? This section answers both, and states the index contract the answers need.

### 5.1 Truncation

::: {custom-style="Statement"}
**Proposition 5.1** (truncating a transported read). In one token frame with transported values $v_i$, weights $w_i$ and scale $s$, let $S=\{i:\|z-v_i\|\le\rho\}$ be a nonempty star with complement $F$. Let $D_S=\sum_{i\in S}w_i\exp(-\|z-v_i\|^2/2s^2)$ and $D_F$ be the star and far kernel masses, $W_S$ the star weight, $W$ the total archive weight and $R$ the diameter of the transported archive. Then the full read $m$ and the star read $m_S$ satisfy
:::

::: {custom-style="Statement Equation"}
$\|m-m_S\|\le R\,\frac{D_F}{D_S+D_F}\le R\,\text{min}\Big\{1,\ \frac{W-W_S}{D_S}\,e^{-\rho^2/2s^2}\Big\}$ (5.1)
:::

::: {custom-style="Statement"}
The right-hand side is computable from the star and the running total $W$, without visiting the far field.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 12.1; the a posteriori form is New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* The full read splits as $m=(D_Sm_S+D_Fm_F)/(D_S+D_F)$, so $m-m_S=D_F(m_F-m_S)/(D_S+D_F)$, and both conditional reads lie in the transported hull. Every far kernel is at most $w_ie^{-\rho^2/2s^2}$, so $D_F\le(W-W_S)e^{-\rho^2/2s^2}$, and $D_F/(D_S+D_F)\le\text{min}\{1,D_F/D_S\}$. ∎

::: {custom-style="Check"}
*Numerical check.* An archive of 400 records drawn uniformly in $[0,10]^2$ with weights in $[0.5,1.5]$ has diameter $R=13.31$. For $s=0.1$, $0.3$ and $1$, $\rho=2s$, $3s$ and $4s$, and 60 random queries each, neither bound in (5.1) was violated (0 and 0 violations). Table 4 lists the details.
:::

Table: **Table 4.** Truncating a transported read: 400 records in $[0,10]^2$, 60 queries per row. The last two columns give the largest ratio of the true error to the first bound in (5.1), and the median certificate as a fraction of $R$, where 1 means the certificate is vacuous.

| $s$ | $\rho/s$ | star share | largest error / bound | median certificate / $R$ |
|:--|:--|:--|:--|:--|
| 0.1 | 2 | 0.34% | 0.0104 | 1 |
| 0.1 | 3 | 0.42% | 0.0121 | 1 |
| 0.1 | 4 | 0.50% | 0.0074 | 1 |
| 0.3 | 2 | 1.24% | 0.0170 | 1 |
| 0.3 | 3 | 2.36% | 0.0014 | 1 |
| 0.3 | 4 | 4.10% | 0.0006 | 0.0534 |
| 1 | 2 | 10.58% | 0.0109 | 1 |
| 1 | 3 | 20.88% | 0.0099 | 0.163 |
| 1 | 4 | 33.90% | 0.0140 | 0.00396 |

::: {custom-style="Statement"}
**Corollary 5.2** (certified radius). For a tolerance $\eta>0$, grow the star until the right-hand side of (5.1) is at most $\eta R$. The radius reached certifies $\|m-m_S\|\le\eta R$ at that query, before any far record is read.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* At $\eta=10^{-3}$, on a grid of radii from $s$ to $8s$ in steps of $s/4$, the median certified radius was 5.875$s$, 5.00$s$ and 4.50$s$ at $s=0.1$, $0.3$ and $1$. The mean star shares were 1.0%, 6.4% and 42.9%, and every certified read was within $\eta R$ of the full read.
:::

![**Figure 4.** Truncation in an archive of 400 records drawn as in the check, recomputed for the figure with its own seed. (a) Median certificate (solid) and median true error (dotted), relative to the archive diameter, against the star radius for three scales. The certificate is conservative by several orders of magnitude, and no query's error exceeded its own certificate. (b) Mean share of the archive in the star, on a logarithmic scale; dots mark the median certified radius at $\eta=10^{-3}$.](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p2/fig/locality.png){width=100%}

The a priori radius $3s$ of hypothesis C5 [14, Section 18] is not certified at $\eta=10^{-3}$ in this archive. At $3s$, the median certificate is still vacuous for $s=0.1$ and $s=0.3$, although the true error was at most 0.012 of the first bound. The certificate is conservative because it charges every far record with the kernel at the boundary and every far read with the full diameter. Locality pays most at small scales, in the upper layers, where the certified star holds about 1% of the archive. It pays least at large scales, in the lower layers, where it holds over 40%.

::: {custom-style="Statement"}
**Theorem 5.3** (truncating a rectangular read). Let $S=\{i:e_i(z)\le\rho^2/2\}$ be nonempty, and let $H_S$, $b_S$ and $m_S$ be the normal matrix, right side and read of the star with renormalised weights. Suppose $H\succ 0$ and $H_S\succ 0$.
:::

::: {custom-style="Statement"}
\(i) $\|m-m_S\|\le(\|b-b_S\|+\|H-H_S\|\,\|m_S\|)/\lambda_{\text{min}}(H)$.
:::

::: {custom-style="Statement"}
\(ii) Let $D_S=\sum_{i\in S}w_ie^{-e_i(z)/s^2}$ and $\Phi_S=\text{min}\{1,(W-W_S)e^{-\rho^2/2s^2}/D_S\}$. Take archive constants $c_H\ge\text{max}_{i,j}\|Q_i^{\top}Q_i-Q_j^{\top}Q_j\|$ and $R_b\ge\text{diam}\{Q_i^{\top}o_i\}$. If $\lambda_{\text{min}}(H_S)>\Phi_Sc_H$, then
:::

::: {custom-style="Statement Equation"}
$\|m-m_S\|\le\frac{\Phi_S\,(R_b+c_H\|m_S\|)}{\lambda_{\text{min}}(H_S)-\Phi_Sc_H}$ (5.2)
:::

::: {custom-style="Statement"}
For square orthogonal maps, $c_H=0$ and $H_S=I$, and (5.2) reduces to (5.1).
:::

::: {custom-style="Statement Tag"}
\(i) V2 Section 12; (ii) New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) $H(m-m_S)=(b-b_S)-(H-H_S)m_S$. (ii) Let $F=D_F/(D_S+D_F)$ be the far posterior mass; as in Proposition 5.1, $F\le\Phi_S$. With the far conditional quantities $H_F$ and $b_F$, we have $H=(1-F)H_S+FH_F$ and $b=(1-F)b_S+Fb_F$, so $H-H_S=F(H_F-H_S)$ and $b-b_S=F(b_F-b_S)$. The matrix $H_F-H_S$ is the difference of two convex combinations of the $Q_i^{\top}Q_i$, so its norm is at most $c_H$; likewise $\|b_F-b_S\|\le R_b$. Weyl's inequality gives $\lambda_{\text{min}}(H)\ge\lambda_{\text{min}}(H_S)-Fc_H$ [19]. Substitute into (i). The resulting bound increases with $F$, so $F$ may be replaced by $\Phi_S$. ∎

::: {custom-style="Check"}
*Numerical check.* For (i), 400 stars of 30 records were truncated to their 12 heaviest records: there were 0 violations, and the largest ratio was 0.994. For (ii), two families of 16 archives of 300 records in $[0,10]^D$, $D=2$ to $4$, with full-rank or mixed-rank random maps, were queried 8 times each at $s=0.5$, $1$ and $2$ with $\rho=2s$ to $6s$. Of 1,257 tests, 723 certificates were finite and 534 vacuous, and no finite certificate was violated. The largest ratio of error to certificate was 0.017. At $s=0.5$ and $\rho=5s$, the star held on average 16% (full rank) and 20% (mixed rank) of the archive, and the median certificates were 1.6 × 10⁻³ $R_b$ and 5.7 × 10⁻⁴ $R_b$.
:::

Rectangular archives are less local than transported ones. A record whose map has a weak direction is near every token along that direction, so stars are larger at the same $\rho/s$. The certificate also needs the margin $\lambda_{\text{min}}(H_S)>\Phi_Sc_H$, which small stars rarely provide.

### 5.2 Sensitivity of the read

The Jacobian of the read controls how errors in one layer propagate to the next, which is the subject of Part III. For identity maps it is a covariance [13, Proposition 6.2]. For general maps it is a covariance between residuals and gradients, preconditioned by $H$.

::: {custom-style="Statement"}
**Proposition 5.4** (the Jacobian of sheaf attention). Let $H\succ 0$, and put $g_i=Q_i^{\top}(Q_iz-o_i)$ and $u_i=Q_i^{\top}(Q_im-o_i)$.
:::

::: {custom-style="Statement"}
\(i) $\sum_i\alpha_iu_i=0$, and
:::

::: {custom-style="Statement Equation"}
$Dm(z)=s^{-2}H^{-1}\sum_i\alpha_i\,u_i\,(g_i-\langle g\rangle)^{\top}$ (5.3)
:::

::: {custom-style="Statement"}
\(ii) For square orthogonal maps, $Dm=s^{-2}C$, with $C$ the weighted covariance of the transported records.
:::

::: {custom-style="Statement"}
\(iii) At a stationary point, $Dm=s^{-2}H^{-1}C_u$, with $C_u=\sum_i\alpha_iu_iu_i^{\top}$.
:::

::: {custom-style="Statement"}
\(iv) $\|Dm\|\le\|\text{Cov}_\alpha(u)\|^{1/2}\,\|\text{Cov}_\alpha(g)\|^{1/2}/(s^2\lambda_{\text{min}}(H))\le\text{diam}\{u_i\}\,\text{diam}\{g_i\}/(4s^2\lambda_{\text{min}}(H))$. The first inequality is an equality for square orthogonal maps.
:::

::: {custom-style="Statement Tag"}
\(ii) Mathematics book Proposition 6.2, in the scaled coordinate; (i), (iii) and (iv) New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) $\sum_i\alpha_iu_i=Hm-b=0$. Differentiate $m=H^{-1}b$ with $\nabla\alpha_i=-s^{-2}\alpha_i(g_i-\langle g\rangle)$: $dm=H^{-1}(db-dH\,m)=-H^{-1}\sum_id\alpha_i\,u_i$, which is (5.3). (ii) Here $H=I$ and $u_i=m-v_i=g_i-\langle g\rangle$. (iii) At $z=m$ we have $g_i=u_i$ and $\langle g\rangle=0$. (iv) For unit vectors $x$ and $y$, the Cauchy–Schwarz inequality gives $|\sum_i\alpha_i(x^{\top}u_i)((g_i-\langle g\rangle)^{\top}y)|\le(x^{\top}\text{Cov}_\alpha(u)\,x)^{1/2}(y^{\top}\text{Cov}_\alpha(g)\,y)^{1/2}$, using (i) for the first factor. The variance of a law on an interval of length $\ell$ is at most $\ell^2/4$ [2], which gives the second inequality. For square orthogonal maps, $Dm=s^{-2}C\succeq 0$, and both covariances equal $C$. ∎

::: {custom-style="Check"}
*Numerical check.* In 297 random stars (3 with condition number above $10^6$ were excluded), central differences matched (5.3) to 2.3 × 10⁻⁶ at worst and 1.5 × 10⁻¹⁰ in the median. Part (ii) held to 3.6 × 10⁻¹⁵ in 200 orthogonal stars, and (iii) to 3.5 × 10⁻¹⁴ at 59 stationary points. In 597 further stars, neither inequality of (iv) was violated. The ratio of $\|Dm\|$ to the first bound was 1 to within $10^{-15}$ on all 150 orthogonal stars, and $\sum_i\alpha_iu_i$ vanished to 9.2 × 10⁻¹⁵.
:::

::: {custom-style="Statement"}
**Corollary 5.5** (minima attract, saddles repel). Let $\zeta$ be a stationary point of $E_s$ with $H\succ 0$. Then $Dm(\zeta)=I-H^{-1}\nabla^2E_s(\zeta)$, and its eigenvalues are real and nonnegative. If $\nabla^2E_s(\zeta)\succ 0$, every eigenvalue $\mu$ satisfies $0\le\mu<1$, and the read iteration converges linearly near $\zeta$. If $\nabla^2E_s(\zeta)$ has a negative eigenvalue, then $Dm(\zeta)$ has an eigenvalue greater than $1$, and $\zeta$ repels the iteration.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* At $\zeta$, $\text{Cov}_\alpha(g)=C_u$, so (3.7) gives $\nabla^2E_s=H-s^{-2}C_u$, and Proposition 5.4(iii) gives $Dm=s^{-2}H^{-1}C_u=I-H^{-1}\nabla^2E_s$. This matrix is similar to $K=s^{-2}H^{-1/2}C_uH^{-1/2}\succeq 0$, so its eigenvalues are real and nonnegative. Moreover $I-K=H^{-1/2}\nabla^2E_sH^{-1/2}$ is congruent to $\nabla^2E_s$ and has the same inertia [19]. If $\nabla^2E_s\succ 0$, every eigenvalue of $K$ is below 1. If $\nabla^2E_s$ has a negative eigenvalue, $K$ has an eigenvalue above 1. ∎

::: {custom-style="Check"}
*Numerical check.* At 79 minima reached by 3,000 read iterations from random starts, the identity held to 1.7 × 10⁻¹⁴, and the largest spectral radius of $Dm$ was 0.894. At the saddle formed by two records observing $x_1=\pm1$ and one observing $x_2=0.5$, the leading eigenvalue was 4.0000 at $s=0.5$ and 1.5625 at $s=0.8$, which is $1/s^2$ in both cases.
:::

*Engineering meaning.* Near a stationary point, the read iteration is a quasi-Newton method whose Hessian model is $H$. It is fast where the records agree, because the residual spread $C_u$ is small. It is slow where they disagree, and it is repelled at saddles between modes. The relaxed step of Theorem 3.10 changes the local rate to $1-\lambda(1-\mu)$ for each eigenvalue $\mu$ of $Dm$. Over-relaxation with $\lambda>1$ therefore accelerates convergence when the eigenvalues of $Dm$ cluster near 1, which is the slow case.

### 5.3 Cost and index contracts

Table 2 gives the cost of one read. The certificates add $O(n)$ operations for a transported read, plus one smallest-eigenvalue computation, $O(D^3)$, for a rectangular read. They also impose an index contract (Table 5). The star must contain every record with $e_i(z)\le\rho^2/2$. For records that share a map $Q$, this is a range query of radius $\rho$ around $Qz$ in that map's observation space, so each chart needs its own index. Masked records need one index per mask pattern, built on the observed coordinates. An approximate nearest-neighbour index voids both certificates, unless its miss probability is accounted for separately.

Table: **Table 5.** The index contract of a certified read.

| Ingredient | Requirement | Used by |
|:----------------|:-----------------------------|:----------------|
| star | every record with $e_i(z)\le\rho^2/2$, by a complete range query per chart | (5.1), (5.2) |
| total weight $W$ | running sum over the archive, versioned with it | (5.1), (5.2) |
| constants $c_H$, $R_b$ | running maxima; they never decrease when records are appended | (5.2) |
| scale and radius | $s$ and $\rho/s$ stored with every read | reproducibility |
| map versions | stored per record and frozen for the token | all reads |


## 6 Topology of design spaces

Engineering design spaces are rarely a single Euclidean space. Discrete choices split them into branches. Angles live on circles. Mode shapes are lines or subspaces, defined only up to sign or rotation. Symmetric structures identify designs that are mirror images of each other. Part I separated the obstructions these create [15, Section 3.5]. This section studies what they do to the read.

### 6.1 Branches

::: {custom-style="Statement"}
**Proposition 6.1** (branch purity and branch-conditional reads). (i) If every cover element lies in one branch, and all maps, updates, noise models and decoders preserve branches, a token stays in its branch. (ii) With identity maps, let $\pi_b=\sum_{i\in b}\alpha_i$ be the weight of branch $b$ and $m_b$ the branch-conditional read, the read renormalised to the records of branch $b$. Then the shared read is $m=\sum_b\pi_bm_b$, and each $m_b$ lies in the hull of its own branch.
:::

::: {custom-style="Statement Tag"}
\(i) V2 Proposition 9.2; (ii) Mathematics book Theorem 3.10 and Proposition 5.16.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Proposition 6.2** (shared reads land in gaps). In one dimension, let the records of branch 1 lie in $[-w,0]$ and those of branch 2 in $[g,g+w]$, with gap $g>0$ and width $w>0$. If
:::

::: {custom-style="Statement Equation"}
$\frac{w}{g+w}<\pi_2<\frac{g}{g+w}$ (6.1)
:::

::: {custom-style="Statement"}
then the shared read lies in the gap $(0,g)$, where no design is feasible.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* $m=\pi_1m_1+\pi_2m_2$ with $m_1\in[-w,0]$ and $m_2\in[g,g+w]$. The smallest possible value is $-\pi_1w+\pi_2g$, which is positive when $\pi_2>w/(g+w)$. The largest is $\pi_2(g+w)$, which is below $g$ when $\pi_2<g/(g+w)$. ∎

::: {custom-style="Check"}
*Numerical check.* In 4,000 random two-branch archives with random queries and scales, no branch-conditional read left its branch. Condition (6.1) held in 1,792 cases, and the shared read landed in the gap in 1,792 of them. Overall, 2,164 shared reads landed in the gap, so (6.1) is sufficient but not necessary.
:::

::: {custom-style="Statement"}
**Proposition 6.3** (connectedness and atoms). (i) No continuous map from a connected latent space onto a disconnected set of designs exists. The nearest-point projection onto a union of intervals jumps at every gap midpoint and creates atoms at the gap ends. (ii) Projection, clipping, repair onto a boundary and inactive coordinates create atoms, so exact recurrence of a design has positive probability even when continuous variables are present.
:::

::: {custom-style="Statement Tag"}
Mathematics book Theorem 15.1 and Proposition 15.4.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Engineering meaning.* On a design space with a discrete topology choice and continuous sizing, the shared read proposes designs that belong to no branch whenever both branches carry weight. Branch-conditional reads, with an explicit branch choice and an exploration floor for unrepresented branches [14, Section 9], avoid the gap. Because the branch is chosen explicitly, they also avoid the decoder obstruction of Proposition 6.3(i).

![**Figure 5.** (a) Reads against the query for two branches, with $w=0.3$, $g=1.4$ and $s=0.45$. The shared read crosses the infeasible gap; the branch-conditional reads stay in their branches. The bar marks the queries at which (6.1) holds. (b) Twenty records near angle 0 at $s=0.5$. The read in the cut coordinate, which runs from 0 to $2\pi$, jumps as the query crosses the cut; the local displacement read is continuous (Proposition 6.5). (c) The all-image read against the nearest-image read for three finite groups, with the bound of Theorem 6.6, for 250 random archives per group drawn for the figure. (d) A record just left of the canonical half-space of the sign group is stored as its negative, far from a nearby query, so a canonical index misses it (Proposition 6.10(iv)).](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p2/fig/topology.png){width=100%}

### 6.2 Angles

An angle is stored as a coordinate with a cut, but it lives on a circle. V2 replaces the cut coordinate by local displacements $d_i=\text{wrap}(\theta_i-\theta)$ from the query, with $-\pi<d_i\le\pi$ [14, Section 10]. The read is then $r(\theta)=\theta+\sum_i\alpha_id_i$ with $\alpha_i\propto w_i\exp(-d_i^2/2s^2)$, taken modulo $2\pi$ [22].

::: {custom-style="Statement"}
**Proposition 6.4** (nearest-lift approximation). Let $|d_i|\le\pi-\delta$ for some $\delta>0$. Compare the weighted mean displacement using only the nearest lifts $d_i$ with the one using all lifts $d_i+2\pi k$ and their Gaussian factors. With $q=\exp(-2\pi\delta/s^2)<1$,
:::

::: {custom-style="Statement Equation"}
$|m_{\text{all}}-m_{\text{near}}|\le\frac{4\pi q(2-q)}{(1-q)^2}$ (6.2)
:::

::: {custom-style="Statement Tag"}
V2 Proposition 10.1.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* In 557 random configurations with $q<1/2$ and lifts up to $|k|=30$, (6.2) was never violated, and the largest ratio to the bound was 0.128.
:::

::: {custom-style="Statement"}
**Proposition 6.5** (the local angle read jumps only at antipodes). The local read $r$ is continuous on the circle except at the antipodes $\theta_k+\pi$ of the records. There it jumps by $2\pi\alpha_k$ modulo $2\pi$, and for every other record $j$,
:::

::: {custom-style="Statement Equation"}
$\alpha_k\le\frac{w_k}{w_j}\exp\Big(-\frac{\pi^2-d_j^2}{2s^2}\Big)$ (6.3)
:::

::: {custom-style="Statement"}
By contrast, the read in a cut coordinate $0\le\theta<2\pi$ jumps at the cut whenever records lie on both sides of it.
:::

::: {custom-style="Statement Tag"}
New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Each $d_i$ is continuous except where $\theta=\theta_i+\pi$, at which it jumps between $\pi$ and $-\pi$. Since $d_i^2$ is continuous, so are all the weights. Hence $r$ jumps only through the term $\alpha_kd_k$, by $2\pi\alpha_k$. At the antipode $|d_k|=\pi$, so $\alpha_k/\alpha_j=(w_k/w_j)\exp(-(\pi^2-d_j^2)/2s^2)$, and $\alpha_j\le 1$. In a cut coordinate, the coordinate distance to a record changes by $2\pi$ when the query crosses the cut, and so do the weights. ∎

::: {custom-style="Check"}
*Numerical check.* In 300 random configurations, the jump across an antipode, measured by a straddle of $\pm10^{-9}$, equalled $2\pi\alpha_k$ to 2.7 × 10⁻⁸, and (6.3) was never violated. For twenty records near $0.15$ and $-0.15$ at $s=0.5$, the cut-coordinate read jumped by 5.97 rad in the coordinate, or 0.31 rad on the circle, while the local read changed by 2.5 × 10⁻¹⁰ (Figure 5b).
:::

The local read therefore has discontinuities, but only where a record sits exactly opposite the query, and they are exponentially small whenever another record is nearer than the antipode. This is the precise sense in which local displacements repair the cut.

### 6.3 Signs and finite symmetry groups

A vibration mode is a line, not a vector: $u$ and $-u$ are the same mode. A mirror-symmetric structure identifies a design with its mirror image. Both are actions of a finite group of orthogonal maps, and one theorem covers them.

::: {custom-style="Statement"}
**Theorem 6.6** (nearest-image reads for a finite group). Let $G$ be a finite group of orthogonal matrices acting on records $y_i\in ℝ^D$ with weights $w_i$. The all-image read $m_{\text{all}}$ replaces each record by its $|G|$ images $gy_i$, each with weight $w_i$. The nearest-image read $m_{\text{near}}$ replaces each record by its image nearest to $z$. Let $\Delta^2$ be the smallest, over records, gap between the nearest and second-nearest squared image distances. Put $q=e^{-\Delta^2/2s^2}$ and $\varepsilon=(|G|-1)q/(1+(|G|-1)q)$. Then:
:::

::: {custom-style="Statement"}
\(i) $\|m_{\text{all}}-m_{\text{near}}\|\le 2\varepsilon\,\text{max}_i\|y_i\|$;
:::

::: {custom-style="Statement"}
\(ii) $m_{\text{all}}(gz)=g\,m_{\text{all}}(z)$ for every $g\in G$;
:::

::: {custom-style="Statement"}
\(iii) $m_{\text{near}}(gz)=g\,m_{\text{near}}(z)$ wherever the nearest images are unique.
:::

::: {custom-style="Statement Tag"}
New in Part II. The group $\{\pm I\}$ gives the sign alignment of V2 Section 11; the angle lifts of Proposition 6.4 are the analogue for the infinite group $2\pi ℤ$.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) Let $\pi_i$ be the kernel weight of the nearest image $n_i$ of record $i$, and $Z=\sum_i\pi_i$. Every other image has relative weight at most $q$, so the extra mass $Y$ satisfies $Y\le(|G|-1)qZ$. Then $m_{\text{all}}-m_{\text{near}}$ is a weighted sum of the vectors $gy_i-m_{\text{near}}$ over non-nearest images, with total weight $Y/(Z+Y)\le\varepsilon$. Each vector has norm at most $\|y_i\|+\|m_{\text{near}}\|\le 2\,\text{max}_i\|y_i\|$, because orthogonal maps preserve norms and $m_{\text{near}}$ is a convex combination of images. (ii) $\|gz-hy_i\|=\|z-g^{-1}hy_i\|$, so reindexing the images by $h=gh'$ maps the weighted image set at $z$ onto $g$ times itself. (iii) The image of $y_i$ nearest to $gz$ is $g$ times the image nearest to $z$. ∎

::: {custom-style="Check"}
*Numerical check.* For sign flips in $ℝ^6$, mirror reversal of the coordinates in $ℝ^6$ and the dihedral group of order 12 in $ℝ^2$, 500 random archives each gave no violation of (i). The largest ratios to the bound were 0.647, 0.639 and 0.386. Equivariance held to 4.6 × 10⁻¹⁵ for the all-image read and to 4.3 × 10⁻¹⁵ for the nearest-image read (Figure 5c).
:::

::: {custom-style="Statement"}
**Example 6.7** (sign transport, re-run). Take fifty unit vectors in $ℝ^6$ near a reference direction $u$, with random signs. At $s=2$, the raw read has norm 0.089 and cosine 0.942 with $u$, while the sign-aligned read has norm 0.859 and cosine 0.997. At $s=0.5$ they are 0.866 (0.993) and 0.879 (0.996), because a small scale already selects the nearest images.
:::

::: {custom-style="Statement Tag"}
V2 Section 11; this is a new random instance, so the numbers differ from the proposal's while the conclusion stands.
:::

::: {custom-style="Gap"}
&nbsp;
:::

### 6.4 Lines and subspaces

Repeated or nearly repeated eigenvalues define a modal subspace in which individual eigenvectors rotate freely. The stable object is the orthogonal projector onto the subspace, and the read is the weighted projector average $P_\alpha=\sum_i\alpha_iP_i$, whose top eigenvectors span the read subspace [14, Section 11].

::: {custom-style="Statement"}
**Proposition 6.8** (projector reads).
:::

::: {custom-style="Statement"}
\(i) For lines in the plane at angles $\phi_i$, measured from a reference direction with $\text{max}_i|\phi_i|=\psi$, let $\theta_P$ be the principal direction of $P_\alpha$ and $\theta_m$ the direction of the sign-aligned mean $\sum_i\alpha_i(\cos\phi_i,\sin\phi_i)$. With $\mu=\sum_i\alpha_i\phi_i$ and $\kappa_3=\sum_i\alpha_i(\phi_i-\mu)^3$,
:::

::: {custom-style="Statement Equation"}
$\theta_P-\theta_m=-\tfrac12\kappa_3+O(\psi^5)$ (6.4)
:::

::: {custom-style="Statement"}
\(ii) If $P_\alpha$ is perturbed to $P_\alpha+E$, and $\gamma=\lambda_k(P_\alpha)-\lambda_{k+1}(P_\alpha)>0$ is the gap below the top $k$ eigenvalues, then the read subspaces satisfy $\|\sin\Theta\|\le 2\|E\|/\gamma$.
:::

::: {custom-style="Statement"}
\(iii) Under the bounded measurement error of Theorem 4.8, $\|E\|\le\text{TV}(\alpha,\alpha')\,\text{max}_{i,j}\|P_i-P_j\|$, so $\|\sin\Theta\|\le 2\tanh(\beta\varepsilon/2)\,\text{max}_{i,j}\|P_i-P_j\|/\gamma$.
:::

::: {custom-style="Statement Tag"}
\(i) and (iii) New in Part II; (ii) Classical [9, 25].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) Write $\phi_i=\mu+\delta_i$ with $\sum_i\alpha_i\delta_i=0$. Expanding, $\sum_i\alpha_i\sin\delta_i=-\kappa_3/6+O(\psi^5)$ and $\sum_i\alpha_i\cos\delta_i=1+O(\psi^2)$, so $\theta_m=\mu-\kappa_3/6+O(\psi^5)$. Likewise $\sum_i\alpha_i\sin 2\delta_i=-\tfrac43\kappa_3+O(\psi^5)$, so $\theta_P=\mu+\tfrac12\text{atan2}(\sum_i\alpha_i\sin 2\delta_i,\sum_i\alpha_i\cos 2\delta_i)=\mu-\tfrac23\kappa_3+O(\psi^5)$. Subtract. (ii) If $\|E\|\ge\gamma/2$, the bound exceeds 1, and $\|\sin\Theta\|\le 1$ always. Otherwise, Weyl's inequality separates the perturbed top-$k$ eigenvalues from the remaining unperturbed spectrum by at least $\gamma-\|E\|\ge\gamma/2$. The Davis–Kahan $\sin\Theta$ theorem then gives $\|\sin\Theta\|\le\|E\|/(\gamma/2)$ [9, 25]. (iii) $E=\sum_i(\alpha'_i-\alpha_i)P_i$ is $\text{TV}$ times the difference of two convex combinations of projectors. That difference has norm at most $\text{max}_{i,j}\|P_i-P_j\|$, because the norm is convex. ∎

::: {custom-style="Check"}
*Numerical check.* In 400 random sets of lines with spread up to 0.48 rad, $|\theta_P-\theta_m+\kappa_3/2|/\psi^5$ was at most 0.307. In 400 random subspace perturbations, (ii) was never violated, with largest ratio 0.430. In 400 trials with bounded measurement error, both inequalities of (iii) held, with largest ratios 0.999 and 0.370.
:::

Sign alignment and projector averaging therefore agree to second order, and differ at third order by half the third central moment of the angles. When the records are skewed around the mean mode, the two reads disagree measurably. When the modal gap $\gamma$ closes, only the projector read keeps a stability guarantee.

### 6.5 Physical quotients

A reflected copy of an archived design is a new coordinate vector but often the same engineering design. Hypothesis C4 of V2 asks that novelty be reported modulo symmetry [14, Section 18].

::: {custom-style="Statement"}
**Definition 6.9** (orbit distance and novelty modulo symmetry). For a finite group $G$ of orthogonal matrices, the orbit distance is $d_G(x,y)=\text{min}_{g\in G}\|x-gy\|$. A candidate $x$ is coordinate-novel at tolerance $\tau$ if $\|x-y_i\|>\tau$ for every archived $y_i$, and orbit-novel if $d_G(x,y_i)>\tau$ for every $i$.
:::

::: {custom-style="Statement Tag"}
V2 Section 18, hypothesis C4, made a definition.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Proposition 6.10** (indexing modulo a finite group).
:::

::: {custom-style="Statement"}
\(i) $d_G$ is a metric on the orbit space $ℝ^D/G$, and orbit novelty implies coordinate novelty.
:::

::: {custom-style="Statement"}
\(ii) A range query of radius $\tau$ in $d_G$ is answered exactly by $|G|$ ordinary range queries of radius $\tau$ at the points $g^{-1}x$, followed by removal of duplicate records.
:::

::: {custom-style="Statement"}
\(iii) If $G$ is generated by reflections, let $𝒞$ be a closed fundamental chamber and $c(x)$ the unique point of the orbit $Gx$ in $𝒞$. Then $d_G(x,y)=\|c(x)-c(y)\|$, so one ordinary index on canonical representatives is exact.
:::

::: {custom-style="Statement"}
\(iv) Let $G=\{I,g\}$ with $g$ an involution whose $-1$ eigenspace has dimension at least 2. Then no continuous map $c$ on the set of points not fixed by $g$ satisfies $c(x)\in\{x,gx\}$ and $c(gx)=c(x)$. In particular, every index on canonical representatives has a seam across which near neighbours are missed. This applies to the sign group in $ℝ^D$ for $D\ge 2$, and to mirror reversal of a design with at least two mirrored pairs of coordinates.
:::

::: {custom-style="Statement Tag"}
\(i) and (ii) Classical; (iii) from [20, Section 1.12]; (iv) New in Part II.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) Orthogonality gives $\|x-gy\|=\|g^{-1}x-y\|$, hence symmetry, and the triangle inequality follows from $\|x-ghz\|\le\|x-gy\|+\|y-hz\|$. The minimum over a finite group is attained, so $d_G(x,y)=0$ only when $x$ and $y$ lie on one orbit. Orbit novelty implies coordinate novelty because $d_G\le\|\cdot\|$. (ii) $\|x-gy\|=\|g^{-1}x-y\|$. (iii) For $x,y\in 𝒞$ and $w\in G$, the conjugate of $wy$ in $𝒞$ is $y$, and $y-wy$ is a nonnegative combination of simple roots [20, Lemma and Theorem 1.12]. Since $x\in 𝒞$ has nonnegative inner product with every simple root, $\langle x,y-wy\rangle\ge 0$, so $\|x-wy\|^2-\|x-y\|^2=2\langle x,y-wy\rangle\ge 0$. Thus $d_G(x,y)=\|x-y\|$ on $𝒞$, and $d_G$ is constant on orbits. (iv) Write $x=x_s+x_a$ with $x_s$ in the $+1$ and $x_a$ in the $-1$ eigenspace of $g$. The points not fixed by $g$ are those with $x_a\ne 0$, a connected set because $x_a$ ranges over a space of dimension at least 2 with the origin removed. On it, $c(x)=x$ or $c(x)=gx$, and the choice is a continuous function into $\{1,-1\}$, hence constant. If $c(x)=x$ everywhere, then $c(gx)=gx\ne x=c(x)$; if $c(x)=gx$ everywhere, then $c(gx)=x\ne gx=c(x)$. For the sign group the $-1$ eigenspace is $ℝ^D$. For mirror reversal its dimension is the number of mirrored pairs. ∎

::: {custom-style="Check"}
*Numerical check.* For the dihedral group of order 12, a reflection group, $d_G$ and the canonical distance agreed to 2.0 × 10⁻¹⁵ on 2,000 random pairs. Queries were placed near random images of 500 archived designs, with noise of standard deviation 0.15. Over 2,000 queries, an index on a canonical half-space missed the true nearest orbit neighbour in 82 queries (4.1%) for sign flips in $ℝ^6$, and in 86 (4.3%) for mirror reversal in $ℝ^6$ (Figure 5d).
:::

*Engineering meaning.* Re-selection and novelty under symmetry should be measured with $d_G$, computed exactly by $|G|$ queries, or by a chamber index when the group is generated by reflections. Storing canonical orbit representatives, as hypothesis C4 suggests, is exact for a single mirrored pair of members. A symmetric truss with two or more mirrored pairs has no continuous canonical form, so a canonical index will occasionally report a reflected design as novel.


## 7 Register of numerical checks

Table 6 lists every numerical check in Part II. A main script produced 20 checks and a supplementary script 14. Both write machine-readable results, and every number in this paper is read from those files when the document is built. The checks test the implementations and illustrate the statements; the proofs establish them. Random archives are synthetic, so the ratios to bounds describe these constructions, not engineering archives in general.

Table: **Table 6.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 3.1 | harmonic extension, 300 stars | 2.6 × 10⁻¹³; 0 of 15,000 perturbations lower the energy |
| 2 | Proposition 3.1(ii) | Schur-complement minimum, 300 stars | relative 2.4 × 10⁻¹⁴ |
| 3 | Proposition 3.2 | retention read, 300 singular stars | nearest minimiser to 2.1 × 10⁻⁸; bound (3.2) attained |
| 4 | Proposition 3.3 | matrix weights, 300 stars | sum 7.8 × 10⁻¹⁴; lifts 7.1 × 10⁻¹⁴ |
| 5 | Corollary 3.4, Proposition 3.5 | hulls, boxes, crossovers | 0 box violations; 345 outside hull; 300 of 300 crossovers outside |
| 6 | Proposition 3.5(iii) | coordinatewise ceiling, 400 stars | 0 violations; 15 beat the best record |
| 7 | Proposition 3.6 | bounds (3.5), 460 pairs | 0 and 0 violations; ratio from 0.5000004 |
| 8 | Proposition 3.6(i) | spectrum (3.4), 500 pairs | 1.2 × 10⁻¹⁴ |
| 9 | Proposition 3.7 | amplification, coverage, two lines | largest ratio 0.9991; coverage exact; $1/\sin\theta$ exact |
| 10 | Proposition 3.8 | residual trace, 300 stars | 5.3 × 10⁻¹⁵ |
| 11 | Propositions 3.9, 4.1 | gradient and Tweedie identities | 1.8 × 10⁻⁹ and 9.8 × 10⁻¹⁰ |
| 12 | Propositions 3.9, 3.13 | Hessian and Euclidean step, 300 stars | Hessian 1.3 × 10⁻⁹; 0 violations |
| 13 | Theorem 3.10 | majorise–minimise, 3,000 stars, 40 runs | 0 violations; all runs monotone; rises beyond $\lambda=2$ in 65% |
| 14 | Proposition 3.11 | ADE recovery, 100 cases | 2.3 × 10⁻¹⁵ |
| 15 | Corollary 3.12 | ADE layers, 1,600 steps | 0 violations |
| 16 | Proposition 4.2 | chart posterior, 200 charts | (4.2) to 4.1 × 10⁻¹⁵ |
| 17 | Proposition 4.3 | properness | $2\pi$ for a full record; linear growth for a partial one |
| 18 | Proposition 4.4(i), (ii) | imputation, 300 stars | 1.3 × 10⁻¹³ and 1.6 × 10⁻⁹ |
| 19 | Proposition 4.4(iii) | Cimmino sweeps, 200 stars | 0 rate violations; 5.7 × 10⁻¹⁵ |
| 20 | Proposition 4.5 | tilted product law | 8.4 × 10⁻¹⁴; exponential mass growth with slope |
| 21 | Proposition 4.6 | selection tilt | $\lambda_{\text{min}}$ 5.5 × 10⁻⁶⁹ against 1.000 at $\beta=100$ |
| 22 | Theorem 4.8 | measurement, 2,000 and 600 trials | 0 violations; two-point case attains the bound |
| 23 | Proposition 5.1, Corollary 5.2 | truncation, 540 queries | 0 violations; certified radii 5.88$s$, 5.00$s$, 4.50$s$ |
| 24 | Theorem 5.3(i) | rectangular truncation, 400 stars | 0 violations; largest ratio 0.994 |
| 25 | Theorem 5.3(ii) | rectangular certificate, 1,257 tests | 723 finite, none violated; largest ratio 0.017 |
| 26 | Proposition 5.4(i)–(iii) | Jacobian, 297 stars | 2.3 × 10⁻⁶ worst; orthogonal 3.6 × 10⁻¹⁵ |
| 27 | Proposition 5.4(iv) | Jacobian bound, 597 stars | 0 violations; equality on orthogonal stars |
| 28 | Corollary 5.5 | stationary points | 79 minima with $\rho(Dm)\le$ 0.894; saddles at $1/s^2$ |
| 29 | Proposition 6.2 | branches, 4,000 archives | 1,792 of 1,792 in the gap |
| 30 | Propositions 6.4, 6.5 | angle lifts and antipodal jumps | 0 and 0 violations; cut jump 5.97 rad |
| 31 | Theorem 6.6 | nearest images, three groups | 0 violations in 1,500 trials |
| 32 | Example 6.7 | sign transport | read norm 0.089 raw against 0.859 aligned |
| 33 | Proposition 6.8 | projector reads, 400 and 400 trials | residual at most 0.307$\psi^5$; 0 violations |
| 34 | Proposition 6.10 | orbit indexes | reflection group 2.0 × 10⁻¹⁵; misses 4.1% and 4.3% |
| 35 | Appendix A | C# kernel against NumPy | 12 of 12 lines agree; 11 identical to 15 digits |

## 8 Discussion

### 8.1 What Part II supplies to the rest of the book

Part III, the vertical stack, studies the token recurrence. Its layer updates are those of Table 3, and Corollary 3.12 adds that every deterministic ADE layer is a guaranteed-descent step at its own scale. Proposition 5.4 gives the tangent map of one layer. Products of these maps along a token's path are the tangent fibre diagrams of Part I, and the eigenvalue description of Corollary 5.5 says which tangent directions contract at a converged layer. The Lipschitz bound of Proposition 5.4(iv), multiplied along a stack, is the end-to-end perturbation bound that V2 asks for before hypothesis C5 can be tested [14, Section 12].

Part IV, on targets and estimation, inherits the distinction between mixture and product laws (Proposition 4.3). A local law is a probability law only under the stated conditions, and only a proper law can serve as an importance proposal. Proposition 4.5 adds that a tilted proposal needs coverage in every direction of objective slope, and Theorem 4.8 gives a worst-case budget for critic error. The truncation certificates separate truncation error from estimation error in any consistency argument.

Part V, on fusion and constraints, must keep products of experts apart from the junction-tree marginal extension of V2 [14, Section 16], since they are different operations with different conclusions. The coordinatewise ceiling of Proposition 3.5(iii) bounds what recombination alone can achieve before constraints act. Part VI, on evidence and computation, takes the retention rule, the eigenvalue threshold, the certificates and the index contract of Table 5 as kernel specifications. Appendix A gives the first implementation.

### 8.2 Diagnostics a layer should report

Defensibility requires that every read carry the quantities its guarantees depend on (Table 7).

Table: **Table 7.** Diagnostics reported with every read.

| Diagnostic | Source | Action when it is poor |
|:-------------------|:-------------------|:-------------------------------|
| $\lambda_{\text{min}}(H)$ or the smallest coverage | Propositions 3.6, 3.7, 4.6 | enlarge the star, add a declared prior, or anneal $\beta$ |
| dimension of the unresolved space | Proposition 3.2 | report it; never invent values |
| guaranteed decrease, the right side of (3.8) | Theorem 3.10 | keep $0<\lambda<2$ |
| truncation certificate and star share | Proposition 5.1, Theorem 5.3 | grow the star or fall back to the full read |
| Jacobian bound | Proposition 5.4(iv) | flag sensitive reads |
| branch weights $\pi_b$ | Propositions 6.1, 6.2 | read per branch when (6.1) holds |
| largest antipodal weight | Proposition 6.5 | none while it is exponentially small |
| orbit distance $d_G$ to the archive | Proposition 6.10 | report orbit novelty, not coordinate novelty |

### 8.3 What is not claimed

The descent of Theorem 3.10 holds at one layer, for fixed records, maps and prior weights. It does not imply that the iterates converge, and it says nothing about search across layers. The prior weights are fixed at the query; learned or query-dependent maps and weights add terms to every derivative used here [14, Section 6]. The certificates assume a complete star and were conservative by two to six orders of magnitude in the experiments. None of hypotheses C1 to C5 is tested. In particular, the recombination results of Section 3.3 describe single reads, not search outcomes.

### 8.4 Open problems

1. **Convergence of iterates.** Prove that sheaf mean-shift iterates converge for rectangular maps under conditions comparable to those known for Gaussian mean shift [5].
2. **Sharper certificates.** Use second moments of the far field, or a hierarchical index, to tighten (5.1) and (5.2) by orders of magnitude without losing their a posteriori character.
3. **Compact symmetry groups.** Rotational symmetries of components form compact groups such as $SO(2)$ and $SO(3)$. Extend Theorem 6.6, with Haar averages in place of finite sums, and Proposition 6.10 to their orbit spaces.
4. **Adaptive maps.** Add the Jacobian terms of query-dependent maps to Proposition 5.4, and certify truncation when the maps themselves are uncertain.
5. **Selection against critic error.** Design annealing schedules for $\beta$ that respect the budget of Theorem 4.8 while keeping the coverage of Proposition 4.6, and test them within hypothesis C2.
6. **Grassmannian reads.** Compare the projector read with Karcher means on the Grassmannian, and determine when the third-order disagreement of Proposition 6.8(i) matters for mode tracking.

### 8.5 Conclusion

One layer of ASE is one operation: a read through maps on an observation star. Part II shows that this read is a harmonic extension, a matrix-weighted combination, a recombination operator with a provable ceiling, and a majorise–minimise step on the soft energy, of which every deterministic ADE layer is an instance. Its local laws, tilts and measurement errors obey exact statements, and so do its locality and sensitivity. On structured design spaces its failure modes are explicit and its repairs proved: gaps between branches, cuts in angles, signs and symmetries. Part III now stacks these layers.

## References for Part II

::: {custom-style="Bibliography"}
[1] Barbero, F., Bodnar, C., Sáez de Ocáriz Borde, H. and Liò, P. (2022). Sheaf attention networks. *NeurIPS 2022 Workshop on Symmetry and Geometry in Neural Representations*.

[2] Bhatia, R. and Davis, C. (2000). A better bound on the variance. *The American Mathematical Monthly* 107(4), 353–357.

[3] Björck, Å. and Golub, G. H. (1973). Numerical methods for computing angles between linear subspaces. *Mathematics of Computation* 27(123), 579–594.

[4] Bodnar, C., Di Giovanni, F., Chamberlain, B. P., Liò, P. and Bronstein, M. M. (2022). Neural sheaf diffusion: a topological perspective on heterophily and oversmoothing in GNNs. *Advances in Neural Information Processing Systems* 35. arXiv:2202.04579.

[5] Carreira-Perpiñán, M. Á. (2007). Gaussian mean-shift is an EM algorithm. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 29(5), 767–776.

[6] Cheng, Y. (1995). Mean shift, mode seeking, and clustering. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 17(8), 790–799.

[7] Cimmino, G. (1938). Calcolo approssimato per le soluzioni dei sistemi di equazioni lineari. *La Ricerca Scientifica ed il Progresso Tecnico nell'Economia Nazionale*, Serie II, 1, 326–333.

[8] Comaniciu, D. and Meer, P. (2002). Mean shift: a robust approach toward feature space analysis. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 24(5), 603–619.

[9] Davis, C. and Kahan, W. M. (1970). The rotation of eigenvectors by a perturbation. III. *SIAM Journal on Numerical Analysis* 7(1), 1–46.

[10] Efron, B. (2011). Tweedie's formula and selection bias. *Journal of the American Statistical Association* 106(496), 1602–1614.

[11] Fashing, M. and Tomasi, C. (2005). Mean shift is a bound optimization. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 27(3), 471–474.

[12] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[13] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[14] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[15] Ghosh, D. P. (2026d). *Horizontally Topological, Vertically Algebraic: The Two Axes of Autoregressive Sheaf Evolution. Part I: Sheaves on Covers and Representations of the Layer Order*. 18 October 2026.

[16] Halmos, P. R. (1969). Two subspaces. *Transactions of the American Mathematical Society* 144, 381–389.

[17] Hansen, J. and Ghrist, R. (2019). Toward a spectral theory of cellular sheaves. *Journal of Applied and Computational Topology* 3(4), 315–358.

[18] Hinton, G. E. (2002). Training products of experts by minimizing contrastive divergence. *Neural Computation* 14(8), 1771–1800.

[19] Horn, R. A. and Johnson, C. R. (2013). *Matrix Analysis*, 2nd edn. Cambridge University Press.

[20] Humphreys, J. E. (1990). *Reflection Groups and Coxeter Groups*. Cambridge Studies in Advanced Mathematics 29. Cambridge University Press.

[21] Hunter, D. R. and Lange, K. (2004). A tutorial on MM algorithms. *The American Statistician* 58(1), 30–37.

[22] Mardia, K. V. and Jupp, P. E. (2000). *Directional Statistics*. Wiley.

[23] Ramsauer, H., Schäfl, B., Lehner, J., Seidl, P., Widrich, M., Adler, T., Gruber, L., Holzleitner, M., Pavlović, M., Sandve, G. K., Greiff, V., Kreil, D., Kopp, M., Klambauer, G., Brandstetter, J. and Hochreiter, S. (2021). Hopfield networks is all you need. *International Conference on Learning Representations*. arXiv:2008.02217.

[24] Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, J., Jones, L., Gomez, A. N., Kaiser, Ł. and Polosukhin, I. (2017). Attention is all you need. *Advances in Neural Information Processing Systems* 30.

[25] Yu, Y., Wang, T. and Samworth, R. J. (2015). A useful variant of the Davis–Kahan theorem for statisticians. *Biometrika* 102(2), 315–323.

[26] Yuille, A. L. and Rangarajan, A. (2003). The concave-convex procedure. *Neural Computation* 15(4), 915–936.
:::

## Appendix II.A: an immutable C# reference kernel

The kernel computes sheaf attention with the retention rule, the soft energy, relaxed steps with their guaranteed decrease, the scalar truncation certificate, and all-image and nearest-image reads under a finite group. Values are immutable records and functions are pure; the symmetric eigensolver, a cyclic Jacobi method, works on a private copy of its input. The kernel targets .NET 8 and uses only the base class library.

```csharp
// ASE Part II reference kernel: sheaf attention on an observation star.
// Immutable values and pure functions; numerical routines use private copies.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AsePartTwo;

/// <summary>A dense real matrix stored row-major.</summary>
public sealed record Matrix(int Rows, int Cols, Vec Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Matrix Of(int rows, int cols, params double[] data) =>
        new(rows, cols, ImmutableArray.Create(data));

    public static Matrix Zero(int n) =>
        new(n, n, ImmutableArray.CreateRange(new double[n * n]));

    public Matrix Transpose() =>
        new(Cols, Rows, Enumerable.Range(0, Rows * Cols)
            .Select(k => this[k % Rows, k / Rows]).ToImmutableArray());

    public Matrix Times(Matrix b) =>
        new(Rows, b.Cols, Enumerable.Range(0, Rows * b.Cols)
            .Select(k => Enumerable.Range(0, Cols)
                .Sum(j => this[k / b.Cols, j] * b[j, k % b.Cols]))
            .ToImmutableArray());

    public Matrix Plus(Matrix b) =>
        this with { Data = Data.Zip(b.Data, (p, q) => p + q).ToImmutableArray() };

    public Matrix Scale(double s) =>
        this with { Data = Data.Select(x => s * x).ToImmutableArray() };

    public Vec Apply(Vec x) =>
        Enumerable.Range(0, Rows)
            .Select(r => Enumerable.Range(0, Cols).Sum(c => this[r, c] * x[c]))
            .ToImmutableArray();

    /// <summary>Eigenvalues and eigenvectors (columns) of a symmetric matrix,
    /// by cyclic Jacobi rotations on a private copy.</summary>
    public (Vec Values, Matrix Vectors) SymmetricEigen()
    {
        int n = Rows;
        var a = Data.ToArray();
        var v = new double[n * n];
        for (int i = 0; i < n; i++) v[i * n + i] = 1.0;
        void Rotate(double[] m, int i, int j, double c, double s)
        {
            (m[i], m[j]) = (c * m[i] - s * m[j], s * m[i] + c * m[j]);
        }
        for (int sweep = 0; sweep < 100; sweep++)
        {
            double off = 0.0;
            for (int p = 0; p < n; p++)
                for (int q = p + 1; q < n; q++) off += a[p * n + q] * a[p * n + q];
            if (off < 1e-300) break;
            for (int p = 0; p < n - 1; p++)
                for (int q = p + 1; q < n; q++)
                {
                    double apq = a[p * n + q];
                    if (apq == 0.0) continue;
                    double th = (a[q * n + q] - a[p * n + p]) / (2.0 * apq);
                    double t = th == 0.0 ? 1.0
                        : Math.Sign(th) / (Math.Abs(th) + Math.Sqrt(th * th + 1.0));
                    double c = 1.0 / Math.Sqrt(t * t + 1.0), s = t * c;
                    for (int k = 0; k < n; k++)
                    {
                        Rotate(a, k * n + p, k * n + q, c, s);
                        Rotate(v, k * n + p, k * n + q, c, s);
                    }
                    for (int k = 0; k < n; k++)
                        Rotate(a, p * n + k, q * n + k, c, s);
                }
        }
        return (Enumerable.Range(0, n).Select(i => a[i * n + i]).ToImmutableArray(),
                new Matrix(n, n, v.ToImmutableArray()));
    }
}

/// <summary>One leaf of the star: edge map Q, observation R y and log prior
/// weight.</summary>
public sealed record ObservedRecord(Matrix Q, Vec Observation, double LogWeight);

/// <summary>One read: weights, normal matrix H, right side b, the read value
/// and diagnostics.</summary>
public sealed record SheafRead(Vec Weights, Matrix Normal, Vec Rhs, Vec Value,
                               double MinEigenvalue, bool Unresolved);

public static class SheafAttention
{
    static double Discrepancy(ObservedRecord r, Vec z) =>
        0.5 * r.Q.Apply(z).Zip(r.Observation, (p, o) => (p - o) * (p - o)).Sum();

    static Vec Logits(Vec z, ImmutableArray<ObservedRecord> records, double s) =>
        records.Select(r => r.LogWeight - Discrepancy(r, z) / (s * s))
               .ToImmutableArray();

    static Vec Add(Vec x, Vec y) => x.Zip(y, (p, q) => p + q).ToImmutableArray();

    /// <summary>E_s(z) = -s^2 log sum_i w_i exp(-e_i(z) / s^2).</summary>
    public static double Energy(Vec z, ImmutableArray<ObservedRecord> records,
                                double s)
    {
        var l = Logits(z, records, s);
        double peak = l.Max();
        return -s * s * (peak + Math.Log(l.Sum(v => Math.Exp(v - peak))));
    }

    /// <summary>The read m = z + H^+ (b - H z): H^{-1} b when H is positive
    /// definite, and the token's own value in unresolved directions otherwise.
    /// </summary>
    public static SheafRead Read(Vec z, ImmutableArray<ObservedRecord> records,
                                 double s, double relTol = 1e-10)
    {
        if (z.IsDefaultOrEmpty || records.IsDefaultOrEmpty || !(s > 0))
            throw new ArgumentException("Invalid read input");
        var l = Logits(z, records, s);
        double peak = l.Max();
        var un = l.Select(v => Math.Exp(v - peak)).ToImmutableArray();
        var alpha = un.Select(v => v / un.Sum()).ToImmutableArray();
        int d = z.Length;
        var H = records.Select((r, i) => r.Q.Transpose().Times(r.Q).Scale(alpha[i]))
                       .Aggregate(Matrix.Zero(d), (x, y) => x.Plus(y));
        var b = records
            .Select((r, i) => r.Q.Transpose().Apply(r.Observation)
                .Select(v => alpha[i] * v).ToImmutableArray())
            .Aggregate(ImmutableArray.CreateRange(new double[d]), Add);
        var (values, vectors) = H.SymmetricEigen();
        double cut = relTol * Math.Max(1.0, values.Max());
        var res = b.Zip(H.Apply(z), (p, q) => p - q).ToImmutableArray();
        var coef = Enumerable.Range(0, d)
            .Select(k => values[k] <= cut ? 0.0
                : Enumerable.Range(0, d).Sum(j => vectors[j, k] * res[j])
                  / values[k])
            .ToImmutableArray();
        var m = Enumerable.Range(0, d)
            .Select(j => z[j]
                + Enumerable.Range(0, d).Sum(k => vectors[j, k] * coef[k]))
            .ToImmutableArray();
        return new SheafRead(alpha, H, b, m, values.Min(), values.Min() <= cut);
    }

    /// <summary>Damped step z + lambda (m - z); it lowers E_s
    /// for 0 &lt; lambda &lt; 2.</summary>
    public static Vec Step(Vec z, SheafRead read, double lambda) =>
        z.Zip(read.Value, (p, m) => (1 - lambda) * p + lambda * m)
         .ToImmutableArray();

    /// <summary>Guaranteed decrease lambda (2 - lambda) |z - m|_H^2 / 2.</summary>
    public static double GuaranteedDecrease(Vec z, SheafRead read, double lambda)
    {
        var d = z.Zip(read.Value, (p, m) => p - m).ToImmutableArray();
        double q = d.Zip(read.Normal.Apply(d), (p, h) => p * h).Sum();
        return 0.5 * lambda * (2 - lambda) * q;
    }

    /// <summary>Truncation certificate
    /// R min(1, (W - W_S) exp(-rho^2 / 2 s^2) / D_S).</summary>
    public static double TruncationCertificate(double diameter, double totalWeight,
                                               double starWeight, double starMass,
                                               double rho, double s) =>
        diameter * Math.Min(1.0, (totalWeight - starWeight)
                                 * Math.Exp(-rho * rho / (2 * s * s)) / starMass);
}

public static class SymmetricReads
{
    static double Dist2(Vec a, Vec b) =>
        a.Zip(b, (p, q) => (p - q) * (p - q)).Sum();

    static Vec Mean(Vec logits, ImmutableArray<Vec> points)
    {
        double peak = logits.Max();
        var w = logits.Select(v => Math.Exp(v - peak)).ToImmutableArray();
        return Enumerable.Range(0, points[0].Length)
            .Select(j => Enumerable.Range(0, points.Length)
                .Sum(i => w[i] * points[i][j]) / w.Sum())
            .ToImmutableArray();
    }

    /// <summary>Reads over all group images, and over the nearest image
    /// of each record.</summary>
    public static (Vec All, Vec Nearest) Read(
        Vec z, ImmutableArray<Vec> records, Vec logWeights,
        ImmutableArray<Matrix> group, double s)
    {
        double Logit(int i, Vec x) => logWeights[i] - Dist2(z, x) / (2 * s * s);
        var images = records
            .Select(y => group.Select(g => g.Apply(y)).ToImmutableArray())
            .ToImmutableArray();
        var all = images.SelectMany((im, i) => im.Select(x => (x, l: Logit(i, x))))
                        .ToImmutableArray();
        var near = images.Select(im => im.OrderBy(x => Dist2(z, x)).First())
                         .ToImmutableArray();
        return (Mean(all.Select(p => p.l).ToImmutableArray(),
                     all.Select(p => p.x).ToImmutableArray()),
                Mean(near.Select((x, i) => Logit(i, x)).ToImmutableArray(), near));
    }
}
```

A driver program exercises the kernel on four records in $ℝ^3$: a coordinate mask, a single coordinate, a partial isometry with two rows, and one general row. It prints a resolved read with three relaxed steps, an unresolved read at a small scale, both group reads under coordinate reversal, and a truncation certificate. An independent NumPy script recomputes every printed number (Table A1). Eleven of the twelve lines are identical to 15 significant digits. The remaining line is the error of a truncated read, a difference of two nearly equal means, and it agrees to a relative 4.9 × 10⁻¹¹.

Table: **Table A1.** C# kernel output against the NumPy recomputation.

| C# | NumPy | Agreement |
|:------------------|:------------------|:----------|
| `weights 0.241016436025006 0.057515393811793 0.227548893194127 0.473919276969073` | `weights 0.241016436025006 0.057515393811793 0.227548893194127 0.473919276969073` | identical |
| `read 0.281953995308634 0.254273818704948 1.29077076397341` | `read 0.281953995308634 0.254273818704948 1.29077076397341` | identical |
| `min_eig 0.279869429761896` | `min_eig 0.279869429761896` | identical |
| `energy -⁠0.510649695067559` | `energy -⁠0.510649695067559` | identical |
| `step_0.5 -⁠0.63401578950538 0.0909273905693453` | `step_0.5 -⁠0.63401578950538 0.0909273905693453` | identical |
| `step_1 -⁠0.724017789939947 0.121236520759127` | `step_1 -⁠0.724017789939947 0.121236520759127` | identical |
| `step_1.5 -⁠0.737460711347895 0.0909273905693453` | `step_1.5 -⁠0.737460711347895 0.0909273905693453` | identical |
| `unresolved 1` | `unresolved 1` | identical |
| `read_unresolved 5 5 2` | `read_unresolved 5 5 2` | identical |
| `image_all 0.964285126756415 0.302353815091537 -⁠0.355112498714437` | `image_all 0.964285126756415 0.302353815091537 -⁠0.355112498714437` | identical |
| `image_nearest 0.996072583335078 0.323466284437322 -⁠0.385329179640797` | `image_nearest 0.996072583335078 0.323466284437322 -⁠0.385329179640797` | identical |
| `truncation 9.25350490091602E-07 0.11487627529551` | `truncation 9.25350490045884e-07 0.11487627529551` | 4.9 × 10⁻¹¹ |

## Appendix II.B: reproducibility

All results were produced with Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1, Matplotlib 3.11.2 and .NET SDK 8.0.131. The script `p2_checks.py` runs the twenty main checks with seed 20261020 and writes `p2_checks.json`. The script `p2_extras.py` runs the fourteen supplementary checks with seed 20261021 and writes `p2_extras.json`. The script `fig_p2.py` draws the figures. Panels marked as recomputed use their own fixed seeds; all other plotted values are read from the result files. The C# project in `cs/` builds the kernel and its driver, and `cs_validate.py` compares the driver's output with NumPy and writes `cs_validate.json`. The document is assembled by `render.py`, which reads every quoted number from these files, converted to Word by Pandoc, and post-processed for equation layout and schema order. A code archive accompanies this paper.


# Part III · The Vertical Stack

::: {custom-style="Subtitle"}
Layers of Autoregressive Sheaf Evolution. Part III: the token recurrence, tangent dynamics and persistence across layers
:::

**Summary of Part III.** Part I of Autoregressive Sheaf Evolution (ASE) fixed the two axes of a layer stack, and Part II worked out one layer. This paper, Part III of the book, stacks the layers. In scaled coordinates, a stack with identity maps is the recurrence $z_{t-1}=(1-\lambda_t)z_t+\lambda_tm_t+\gamma_t\xi_t$, whose coefficients depend only on the scales and a noise parameter. We prove a noise budget: the explicit noise that reaches the output has exactly the law $N(0,(s_0^2-\omega_\star^2s_T^2)I)$. Hence the starting state carries weight at most $s_0/s_T$, a one-record stack is exactly calibrated for every schedule, and a clean top closes both channels. In precision coordinates $\tau=1/s$, a deterministic layer is a forward Euler step and the separation identity is a Riemann sum. The stack discretises the probability-flow equation $\text{d}z/\text{d}s=-s\nabla\log p_s$, which carries $p_{s_T}$ to $p_{s_0}$, and its local error comes only from the motion of the read. With a clean top, the continuum stack re-selects archived records with probabilities equal to their prior weights. A layer is a gradient step that expands exactly along directions of negative curvature of its energy. Every singular value of a composite tangent lies between products of layer eigenvalues, and the floor $s_0/s_T$ is attained in directions the archive does not span. At a clean top, the $k$-th singular value is the $k$-th eigenvalue of the top posterior covariance up to explicit factors. This explains the contraction reported in Part I, where the median expansion excess was 8.5. Stationary points change only where a tangent eigenvalue equals one. Thresholded ranks can give negative barcode multiplicities, as they did for 55% of Part I's tokens at tolerance $10^{-2}$. Component barcodes are filtrations, but mode counts are not in two dimensions: three equal records acquire a fourth mode at exactly $s=\text{side}/\sqrt6$. Token paths curve as fast as the read moves, $z''=-(1/s)\,\text{d}m/\text{d}s$. This yields an error model whose optimal layer density is proportional to $\sqrt g$, and a bound: under the model no $k$-layer schedule matches a $2k$-layer baseline unless the baseline's efficiency is below one half. An exploratory pilot refuted hypothesis C3 of the conversion proposal in all 72 comparisons. The error model ranked seven schedules almost perfectly, and a curvature schedule computed from the archive alone was the best at equal numbers of layers. The paper reports 21 numerical checks and the pilot, and an immutable C# kernel matches an independent NumPy implementation on every output line.

## 1 Introduction

Autoregressive Diffusion Evolution (ADE) proposes designs by running tokens down a denoising stack whose layers read an archive of evaluated designs [7, 8]. Autoregressive Sheaf Evolution (ASE) generalises each read to an observation star with edge maps and scale-dependent covers [9]. Part I separated the two axes of the stack: horizontally topological within a layer, vertically algebraic across layers [10]. Part II worked out one layer. Its read is a harmonic extension, and every deterministic ADE layer is a majorise–minimise step on the soft energy at its own scale [11]. This paper, Part III of the book, stacks the layers. It covers chapters 7 to 9 of the book plan: the token recurrence, tangent dynamics, and persistence across layers [9, Section 21].

A stack does three things. It mixes each token with the reads it collects, in proportions fixed by the schedule alone. It transports a population of tokens from a coarse density to a fine one. And it moves tangent vectors, contracting most directions and expanding a few. Each of these has an exact description, and each description says where in the schedule the layers matter. In the scaled coordinates of V2, a stack with identity maps is the recurrence

::: {custom-style="Equation"}
$z_{t-1}=(1-\lambda_t)\,z_t+\lambda_t\,m_t(z_t)+\gamma_t\,\xi_t,\qquad t=T,\ldots,1$ (1.1)
:::

with $m_t(z)=\sum_i\alpha_i(z,s_t)\,y_i$ the Gaussian read at scale $s_t$, independent standard normal increments $\xi_t$, and coefficients $\lambda_t,\gamma_t$ that depend only on the scales $s_0<s_1<\cdots<s_T$ and a noise parameter $\eta$ (Definition 2.1). The three descriptions are the following. Unrolling (1.1) separates the output into a starting term, a convex combination of reads, and a noise term with a fixed budget (Section 3.1). In precision coordinates $\tau=1/s$, a deterministic layer is a forward Euler step of the probability-flow equation of the archive density (Section 3.2). And the Jacobian of a layer is one minus a multiple of the Hessian of its energy, so that tangents expand exactly along directions of negative curvature (Section 4).

![**Figure 1.** (a) Weights of the reads in the output of an eight-layer geometric stack from $s_8=4$ to $s_0=0.1$ (Theorem 3.1). Noise moves weight towards the top layers and shrinks the weight $\omega_\star$ of the starting state. (b) The noise budget of the same stack (Theorem 3.2). The shares of the top variance $s_0^2$ carried by the starting state and by the explicit noise always sum to one. (c) A deterministic layer is a forward Euler step in the precision $\tau=1/s$ (Proposition 3.4). The shaded area is $\sum_t\Delta\tau_t\,m_t$, and the stack output is $z_0=s_0(z_T/s_T+\sum_t\Delta\tau_t\,m_t)$; the black curve is the read along the exact flow, recomputed for two records at $\pm1$ with weights 0.45 and 0.55.](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p3/fig/separation.png){width=100%}

### 1.1 Contributions

- **The token recurrence (Section 3).** We prove a noise budget: the explicit noise reaching the output is exactly $N(0,(s_0^2-\omega_\star^2s_T^2)I)$ (Theorem 3.2). Hence the starting state has weight at most $s_0/s_T$, a one-record stack is exactly calibrated for every schedule and every $\eta$, and a clean top closes both channels. In precision coordinates the separation identity is a Riemann sum (Proposition 3.4). The deterministic stack discretises the probability-flow equation $\text{d}z/\text{d}s=-s\nabla\log p_s$, which carries $p_{s_T}$ to $p_{s_0}$, with local error caused only by the motion of the read (Theorem 3.5). With a clean top, the continuum stack re-selects archived records with probabilities equal to their prior weights (Proposition 3.6), and novelty has exactly four channels (Proposition 3.7).
- **Tangent dynamics (Section 4).** A layer is a gradient step, and it expands exactly along directions of negative curvature of its energy (Proposition 4.1). Every singular value of a composite lies between products of layer eigenvalues. The deterministic floor $s_0/s_T$ is attained in directions the archive does not span (Theorem 4.2). With a clean top, the $k$-th singular value is pinned to the $k$-th eigenvalue of the top posterior covariance, up to the factor $1/(s_1s_T)$ and an expansion excess (Corollary 4.3). This explains the contraction reported in Part I. Stationary points can change number or type only where a tangent eigenvalue equals one, and they obey a Morse balance (Proposition 4.4). Thresholded ranks are not rank invariants and can give negative barcode multiplicities (Proposition 4.6).
- **Persistence across layers (Section 5).** Component barcodes are filtrations. Mode counts are monotone in one dimension, but not in two: for three equal records a fourth mode is born at exactly $s=\text{side}/\sqrt6$ (Example 5.3). Token paths curve only where the posterior is spread (Theorem 5.4). This gives an error model whose optimal layer density is proportional to $\sqrt{g}$, and a layer-halving bound (Proposition 5.5). An exploratory pilot refutes hypothesis C3 in all 72 of its comparisons, and the error model explains why (Section 5.3).
- **Evidence.** There are 21 numerical checks, 18 from a main script and 3 from a supplementary script, besides the pilot (Table 5). An immutable C# kernel agrees with an independent NumPy implementation on every output line (Appendix A).

### 1.2 Scope and status of statements

The exact statements concern identity edge maps, which give the ADE geometry. Most of them carry over unchanged to orthogonal transports, which replace each record by its transported value. General maps change the Jacobian of a read (Part II, Proposition 5.4) and the hull in which reads lie (Part II, Proposition 3.5). Where a statement needs identity maps, it says so. Prior weights are fixed. The paper proves statements about sampling and sensitivity of the stack; it makes no claim about search performance. Section 5.3 reports an exploratory pilot related to hypothesis C3 of V2 [9, Section 18]. It is not the confirmatory test that V2 specifies, and its outcome is labelled as exploratory throughout.

Every statement in a shaded box ends with a provenance tag. *Classical* marks a known result restated in ASE notation. *V2* marks a statement of the conversion proposal [9], sometimes with a new proof. *Mathematics book* marks a result retained from [8], with its number there. *Part I* and *Part II* refer to [10] and [11]. *New in Part III* marks a statement proved here for the first time in this programme; each comes with a proof and a numerical check. All spaces are finite-dimensional and real.

### 1.3 Conventions and notation

Layers are numbered from the bottom, $t=T$, to the top, $t=1$; the token enters layer $t$ as $z_t$ and leaves it as $z_{t-1}$, so $z_0$ is the output. The scale of layer $t$ is $s_t$. "Coarse" means large $s$ and "fine" means small $s$.

Table: **Table 1.** Notation used throughout Part III.

| Symbol | Meaning |
|:--------------------------|:--------------------------------------------------|
| $y_i,\ w_i,\ \beta_i$ | records, prior weights and normalised weights $\beta_i=w_i/\sum_jw_j$ |
| $s_0<s_1<\cdots<s_T$ | scales; a clean top has $s_0=0$ |
| $\eta,\ \lambda_t,\ \gamma_t$ | noise parameter, interpolation weight and scaled noise deviation (2.1) |
| $\alpha_i(z,s),\ m(z,s),\ C(z,s)$ | posterior weights, read and posterior covariance at scale $s$ |
| $p_s$ | archive density $\sum_i\beta_iN(y_i,s^2I)$ |
| $E_s$ | layer energy (2.3) |
| $\pi_t,\ \omega_t,\ \omega_\star$ | separation weights of Theorem 3.1 |
| $\tau=1/s,\ w=z/s$ | precision and precision-scaled state (Proposition 3.4) |
| $J_t,\ K$ | layer Jacobian and composite tangent $K=J_1\cdots J_T$ |
| $c_{t,k}$ | eigenvalues of $C$ at layer $t$, in decreasing order |
| $M_3$ | posterior third moment (5.1) |
| $R$ | diameter of the records |


## 2 The stack and its schedule

V2 converts ADE into scaled coordinates, in which every layer interpolates between the token and its read [9, Proposition 6.2]. The schedule enters only through the scales. We state the recurrence in that form, with the scale sequence as the primary object, because every identity below depends on the scales and on nothing else.

::: {custom-style="Statement"}
**Definition 2.1** (schedule and stack). Fix records $y_1,\ldots,y_n\in ℝ^D$ with prior weights $w_i>0$. A *schedule* consists of scales $0\le s_0<s_1<\cdots<s_T$ and a noise parameter $0\le\eta\le1$. Its coefficients are
:::

::: {custom-style="Statement Equation"}
$\gamma_t^2=\eta^2s_{t-1}^2\,\frac{s_t^2-s_{t-1}^2}{s_t^2},\qquad 1-\lambda_t=\frac{\sqrt{s_{t-1}^2-\gamma_t^2}}{s_t},\qquad t=1,\ldots,T$ (2.1)
:::

::: {custom-style="Statement"}
The *stack* is the recurrence (1.1), with $\xi_1,\ldots,\xi_T$ independent standard normal vectors, independent of the starting state $z_T$. The read of layer $t$ is $m_t(z)=m(z,s_t)$, where
:::

::: {custom-style="Statement Equation"}
$\alpha_i(z,s)=\frac{w_ie^{-\Vert z-y_i\Vert^2/2s^2}}{\sum_jw_je^{-\Vert z-y_j\Vert^2/2s^2}},\quad m(z,s)=\sum_i\alpha_iy_i,\quad C(z,s)=\sum_i\alpha_i(y_i-m)(y_i-m)^{\top}$ (2.2)
:::

::: {custom-style="Statement"}
The top is *clean* when $s_0=0$. The archive density at scale $s>0$ is $p_s=\sum_i\beta_iN(y_i,s^2I)$, and the layer energy is
:::

::: {custom-style="Statement Equation"}
$E_s(z)=-s^2\log\sum_iw_ie^{-\Vert z-y_i\Vert^2/2s^2}$ (2.3)
:::

::: {custom-style="Statement Tag"}
V2 Proposition 6.2 and Section 7, with the scale sequence made primary; (2.3) is the soft energy of Part II with identity maps.
:::

::: {custom-style="Gap"}
&nbsp;
:::

With identity maps, $E_s=-s^2\log p_s+\text{const}$, its gradient is $z-m$ and its Hessian is $I-C/s^2$ (Part II, Proposition 3.9). The read (2.2) is sheaf attention with identity edge maps (Part II, Definition 2.2).

::: {custom-style="Statement"}
**Proposition 2.2** (coefficients and variance bookkeeping). Let $r_t=s_{t-1}/s_t$.
:::

::: {custom-style="Statement"}
\(i) $0\le\gamma_t^2\le s_{t-1}^2(1-r_t^2)$ and $1-r_t\le\lambda_t\le1-r_t^2$. In particular $0\le\lambda_t\le1$, and $\lambda_t$ increases with $\eta$, from $1-r_t$ at $\eta=0$ to $1-r_t^2$ at $\eta=1$.
:::

::: {custom-style="Statement"}
\(ii) $(1-\lambda_t)^2s_t^2+\gamma_t^2=s_{t-1}^2$.
:::

::: {custom-style="Statement"}
\(iii) If $s_t^2=(1-a_t)/a_t$ for signal levels $1\ge a_0\ge a_1\ge\cdots\ge a_T>0$, then $\gamma_t=\sigma_t/\sqrt{a_{t-1}}$ and $\lambda_t=1-A_t\sqrt{a_t/a_{t-1}}$, where $\sigma_t$ and $A_t$ are the coefficients (19.2) of the Mathematics book.
:::

::: {custom-style="Statement"}
\(iv) At a clean top, $\lambda_1=1$ and $\gamma_1=0$, so $z_0=m_1(z_1)$.
:::

::: {custom-style="Statement Tag"}
\(i), (ii) New in Part III in this form; (iii) Mathematics book Propositions 19.2 and 19.3, V2 Proposition 6.2; (iv) V2 Corollary 7.2.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) $\gamma_t^2=\eta^2s_{t-1}^2(1-r_t^2)$, so the radicand in (2.1) is $s_{t-1}^2\,(1-\eta^2(1-r_t^2))$, which lies between $s_{t-1}^2r_t^2$ and $s_{t-1}^2$ and decreases in $\eta$. Taking the square root and dividing by $s_t$ gives $r_t^2\le1-\lambda_t\le r_t$. (ii) Square the second identity in (2.1). (iii) Substitute $s^2=(1-a)/a$: $\gamma_t^2=\eta^2\frac{1-a_{t-1}}{a_{t-1}}\cdot\frac{a_{t-1}-a_t}{a_{t-1}(1-a_t)}=\sigma_t^2/a_{t-1}$, and $\sqrt{s_{t-1}^2-\gamma_t^2}/s_t=\sqrt{(1-a_{t-1}-\sigma_t^2)\,a_t/((1-a_t)\,a_{t-1})}=A_t\sqrt{a_t/a_{t-1}}$. (iv) Here $r_1=0$. ∎

Identity (ii) is the defining property of the family of Song, Meng and Ermon [18]: if the read were the true record, a layer would map noise of scale $s_t$ to noise of scale $s_{t-1}$. Theorem 3.2 below sums it over a stack.

::: {custom-style="Check"}
*Numerical check.* In 500 random schedules with 2 to 20 layers, scales between 0.02 and 30, a clean top in one case in four and random $\eta$, identity (ii) held to a relative 1.2 × 10⁻¹⁵, every $\lambda_t$ lay in the unit interval, and the coefficients of (iii) matched (19.2) to 3.3 × 10⁻¹³.
:::

::: {custom-style="Statement"}
**Proposition 2.3** (a stack is ADE in scaled coordinates). Let $s_t^2=(1-a_t)/a_t$ and $q_t=\sqrt{a_t}\,z_t$. For every realisation of the noise, the stack (1.1) with identity maps reproduces $T$ consecutive ADE proposal steps (19.1) of the Mathematics book, with the same retrieval weights at every layer and noise $\sigma_t\xi_t$.
:::

::: {custom-style="Statement Tag"}
V2 Proposition 6.2, applied layer by layer.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* The weights agree because $\Vert q_t-\sqrt{a_t}y_i\Vert^2/(1-a_t)=\Vert z_t-y_i\Vert^2/s_t^2$. Dividing the ADE step $q_{t-1}=A_tq_t+B_tm_t+\sigma_t\xi_t$ by $\sqrt{a_{t-1}}$ and using Proposition 2.2(iii) gives (1.1) for one layer, and the layers compose. ∎

The ADE bottom $a_T=0$ has $s_T=\infty$, so a stack in scaled coordinates needs a positive cutoff $a_T>0$ [9, Section 8]. The cutoff is where the starting state enters, and Section 3.3 shows that it is one of the channels of novelty.

::: {custom-style="Check"}
*Numerical check.* In 200 random stacks with 2 to 16 layers, random levels, a clean top in about half of them and random $\eta$, the scaled stack and the ADE recursion in $q$ agreed to a relative 1.8 × 10⁻¹³ along the same noise paths.
:::

## 3 The token recurrence

### 3.1 Separation and the noise budget

Unrolling (1.1) separates what the schedule does from what the reads do.

::: {custom-style="Statement"}
**Theorem 3.1** (separation). Let realised reads $m_t$ and increments $\nu_t$ satisfy $z_{t-1}=(1-\lambda_t)z_t+\lambda_tm_t+\nu_t$ with $0\le\lambda_t\le1$. With $\pi_t=\prod_{u=1}^{t-1}(1-\lambda_u)$, $\omega_t=\lambda_t\pi_t$ and $\omega_\star=\prod_{u=1}^{T}(1-\lambda_u)$,
:::

::: {custom-style="Statement Equation"}
$z_0=\omega_\star z_T+\sum_{t=1}^{T}\omega_tm_t+\sum_{t=1}^{T}\pi_t\nu_t,\qquad \omega_\star+\sum_{t=1}^{T}\omega_t=1$ (3.1)
:::

::: {custom-style="Statement Tag"}
V2 Theorem 7.1.
:::

::: {custom-style="Gap"}
&nbsp;
:::

The weights depend only on the schedule, but the identity is pathwise: later reads depend on earlier ones through the queries, so (3.1) is an accounting identity, not a decomposition into independent effects [9, Section 7].

::: {custom-style="Check"}
*Numerical check.* Along 300 realised paths in dimensions 1 to 4, with up to 16 layers and random $\eta$, the right side of (3.1) reproduced the output to a relative 5.2 × 10⁻¹⁶, and the weights summed to one within 4.4 × 10⁻¹⁶.
:::

For the coefficients (2.1), the noise term of (3.1) is $N=\sum_t\pi_t\gamma_t\xi_t$. Its size is fixed by the two end scales.

::: {custom-style="Statement"}
**Theorem 3.2** (the noise budget). For every schedule,
:::

::: {custom-style="Statement Equation"}
$\sum_{t=1}^{T}\pi_t^2\gamma_t^2=s_0^2-\omega_\star^2s_T^2$ (3.2)
:::

::: {custom-style="Statement"}
Consequently:
:::

::: {custom-style="Statement"}
\(i) $\omega_\star\le s_0/s_T$, with equality if and only if $\eta=0$ or $s_0=0$;
:::

::: {custom-style="Statement"}
\(ii) whatever the reads, the explicit noise $N$ has the law $N(0,(s_0^2-\omega_\star^2s_T^2)\,I)$, and it vanishes at a clean top;
:::

::: {custom-style="Statement"}
\(iii) if every read equals one point $y$, as for a one-record archive, and $z_T\sim N(y,s_T^2I)$, then $z_0\sim N(y,s_0^2I)$, for every schedule, every $\eta$ and every number of layers.
:::

::: {custom-style="Statement Tag"}
New in Part III.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Since $\pi_{t+1}=(1-\lambda_t)\pi_t$, Proposition 2.2(ii) gives $\pi_t^2\gamma_t^2=\pi_t^2s_{t-1}^2-\pi_{t+1}^2s_t^2$. The sum telescopes to $\pi_1^2s_0^2-\pi_{T+1}^2s_T^2$, with $\pi_1=1$ and $\pi_{T+1}=\omega_\star$. (i) The left side of (3.2) is nonnegative. If $\eta>0$ and $s_0>0$, its first term is $\gamma_1^2=\eta^2s_0^2(1-s_0^2/s_1^2)>0$; otherwise every $\gamma_t\pi_t$ vanishes, since $\eta=0$ or, at a clean top, $\gamma_1=0$ and $\pi_t=0$ for $t\ge2$. (ii) $N$ is a fixed linear combination of independent standard normal vectors. (iii) By (3.1) and $\sum_t\omega_t=1-\omega_\star$, $z_0-y=\omega_\star(z_T-y)+N$, a sum of independent centred Gaussians with variances $\omega_\star^2s_T^2$ and $s_0^2-\omega_\star^2s_T^2$ per coordinate. ∎

The noise channel can thus deposit at most the top variance $s_0^2$ in the output, and a schedule only decides how that budget is split between the starting state and fresh noise (Figure 1b). The calibration (iii) is exact for every finite stack, but only for one record. With several records the reads move with the token, and calibration becomes a continuum statement (Theorem 3.5).

::: {custom-style="Check"}
*Numerical check.* In 500 random schedules, (3.2) held to a relative 2.7 × 10⁻¹⁶. With an oracle read $y=1.5$, twelve geometric layers from $s_T=10$ to $s_0=0.3$ and 200,000 tokens, the output standard deviation was 0.2997, 0.2998 and 0.3007 for $\eta=0$, 0.5 and 1, against $s_0=0.3$.
:::

::: {custom-style="Statement"}
**Corollary 3.3** (deterministic weights). For $\eta=0$, $1-\lambda_t=s_{t-1}/s_t$, $\pi_t=s_0/s_{t-1}$ and
:::

::: {custom-style="Statement Equation"}
$\omega_t=s_0\left(\frac{1}{s_{t-1}}-\frac{1}{s_t}\right),\qquad \omega_\star=\frac{s_0}{s_T}$ (3.3)
:::

::: {custom-style="Statement"}
with the product form of $\pi_t$ used at a clean top. For the limiting sixteen-layer cosine schedule $s_t=\tan(\pi t/32)$, the reads of layers 2, 3, 4, 5 and 6 to 16 carry the weights 0.5049, 0.1705, 0.0869, 0.0535 and 0.1843 in the query $z_1$.
:::

::: {custom-style="Statement Tag"}
V2 Corollary 7.2 and the table of V2 Section 8.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* In 300 random deterministic schedules, (3.3) held to 2.2 × 10⁻¹⁶ and $\omega_\star=s_0/s_T$ to 5.6 × 10⁻¹⁷. The recomputed cosine weights were 0.5049, 0.1705, 0.0869, 0.0535 and 0.1843, as in V2.
:::

### 3.2 The deterministic stack is a discretised transport

::: {custom-style="Statement"}
**Proposition 3.4** (precision coordinates). Let $\eta=0$ and $s_{t-1}>0$. With the precision $\tau_t=1/s_t$ and $w_t=z_t/s_t$, layer $t$ of (1.1) is
:::

::: {custom-style="Statement Equation"}
$w_{t-1}=w_t+(\tau_{t-1}-\tau_t)\,m_t(z_t)$ (3.4)
:::

::: {custom-style="Statement"}
the forward Euler step for $\text{d}w/\text{d}\tau=m$. Equivalently, $z_{t-1}=z_t+(s_{t-1}-s_t)(z_t-m_t)/s_t$, the forward Euler step for
:::

::: {custom-style="Statement Equation"}
$\frac{\text{d}z}{\text{d}s}=\frac{z-m(z,s)}{s}$ (3.5)
:::

::: {custom-style="Statement"}
and this step solves (3.5) exactly when the read is frozen at $m_t$ over the step. Summing (3.4) gives (3.3) as a left Riemann sum: $z_0=s_0\left(z_T/s_T+\sum_t(\tau_{t-1}-\tau_t)\,m_t\right)$.
:::

::: {custom-style="Statement Tag"}
(3.4) New in Part III; the Euler form Mathematics book Proposition 19.6, as a fractional score step, and Karras et al. [14], who list DDIM as Euler's method for $\sigma(t)=t$; the frozen-read form is first-order DPM-Solver, which equals DDIM [15].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Divide the deterministic layer by $s_{t-1}$ and use $(1-\lambda_t)/s_{t-1}=1/s_t$ and $\lambda_t/s_{t-1}=1/s_{t-1}-1/s_t$. With $m$ frozen, (3.5) is linear with solution $z(s)=m+(s/s_t)(z_t-m)$, which at $s=s_{t-1}$ is the layer. Summing (3.4) from $t=T$ to 1 and multiplying by $s_0$ gives the last formula. ∎

Figure 1c shows (3.4) for two records. The weights of Theorem 3.1 are the widths $s_0\Delta\tau_t$ of the Riemann sum, and the read curve that the sum approximates is the read along the exact flow of (3.5).

::: {custom-style="Statement"}
**Theorem 3.5** (the deterministic stack discretises a transport). Use identity maps and $s_0>0$.
:::

::: {custom-style="Statement"}
\(i) $m(z,s)-z=s^2\nabla\log p_s(z)$, so (3.5) is the probability-flow equation $\text{d}z/\text{d}s=-s\nabla\log p_s(z)$.
:::

::: {custom-style="Statement"}
\(ii) The densities satisfy $\partial_sp_s=s\Delta p_s$, and for $0<s<s'$ the flow map $\Phi_{s'\to s}$ of (3.5) pushes $p_{s'}$ forward to $p_s$.
:::

::: {custom-style="Statement"}
\(iii) If $z(\cdot)$ solves (3.5) with $z(s_t)=z_t$, the local error of the layer is
:::

::: {custom-style="Statement Equation"}
$z(s_{t-1})-z_{t-1}=s_{t-1}\int_{\tau_t}^{\tau_{t-1}}\left(m(z(\tau),1/\tau)-m_t\right)\text{d}\tau,\qquad \Vert z(s_{t-1})-z_{t-1}\Vert\le\frac{1}{2}(s_t-s_{t-1})^2\,\text{max}\,\Vert z''\Vert$ (3.6)
:::

::: {custom-style="Statement"}
with the maximum over the step: the error is caused only by the motion of the read.
:::

::: {custom-style="Statement"}
\(iv) As the largest step tends to zero with $s_0$ and $s_T$ fixed, the stack output tends to $\Phi_{s_T\to s_0}(z_T)$, uniformly on compact sets and at first order. If $z_T\sim p_{s_T}$, the law of the output tends to $p_{s_0}$.
:::

::: {custom-style="Statement Tag"}
\(i) Classical, Tweedie's formula [6] (Part II, Proposition 4.1); (ii) classical [19, 14]; (iii) New in Part III; (iv) classical [12].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) Differentiate $p_s$: $\nabla p_s=\sum_i\beta_iN(z;y_i,s^2I)(y_i-z)/s^2$, so $\nabla\log p_s=(m-z)/s^2$. (ii) Each $N(y_i,s^2I)$ satisfies $\partial_s=s\Delta$, since its variance is $s^2$. With the velocity $v=-s\nabla\log p_s$, $\nabla\cdot(p_sv)=-s\Delta p_s=-\partial_sp_s$, so $p_s$ solves the continuity equation of the flow. The velocity is smooth with $\Vert Dv\Vert\le(1+R^2/4s^2)/s$ (Part II, Proposition 5.4), so the flow exists globally for $s\ge s_0$ and transports densities [19]. (iii) In precision coordinates the exact flow satisfies $w(\tau_{t-1})=w(\tau_t)+\int m\,\text{d}\tau$, while (3.4) uses $m_t$; subtract and multiply by $s_{t-1}$. The norm bound is Taylor's theorem with integral remainder for the Euler step in $s$. (iv) The right side of (3.5) is smooth with bounded derivatives on $s\ge s_0$, so Euler's method converges at first order [12]; uniform convergence of the maps on compacts gives convergence of the pushed-forward laws. ∎

With $\eta>0$ the stack discretises a reverse-time stochastic equation instead [1, 19], and the same limit is observed numerically (Figure 2b), but we do not prove it here.

::: {custom-style="Check"}
*Numerical check.* In 300 random layers, the layer, the Euler step and the score form (19.5) agreed to 4.0 × 10⁻¹⁵. For six records in one dimension, 40,000 tokens drawn from $p_{20}$ and geometric stacks down to $s_0=0.3$, the Kolmogorov–Smirnov distance to $p_{s_0}$ fell from 0.093 with 4 layers to 0.025, 0.0098 and 0.0064 with 16, 64 and 256 layers, against a sampling floor of 0.0041. With $\eta=1$ the values were 0.132, 0.034, 0.0113 and 0.0052. A Gaussian start with the ADE variance $1+s_T^2$ instead of $p_{s_T}$ raised the 256-layer distance to 0.0097.
:::

![**Figure 2.** (a) Outputs of deterministic stacks with 4 and 64 geometric layers from $s_T=20$ to $s_0=0.3$, for 40,000 tokens drawn from $p_{20}$, against the density $p_{s_0}$ of six weighted records (recomputed with a fixed seed). (b) Kolmogorov–Smirnov distance to $p_{s_0}$ against the number of layers, for $\eta=0$ and $\eta=1$ (Theorem 3.5). (c) With a clean top, 256 geometric layers down to $s_1=0.01$ re-select the records with frequencies equal to their prior weights (Proposition 3.6).](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p3/fig/transport.png){width=100%}

### 3.3 Re-selection and the channels of novelty

::: {custom-style="Statement"}
**Proposition 3.6** (a clean top re-selects). Let $s_0=0$ and let the records be distinct.
:::

::: {custom-style="Statement"}
\(i) For every $\eta$ and every path, $z_0=m_1(z_1)$ lies in the convex hull of the records.
:::

::: {custom-style="Statement"}
\(ii) If $z_1\sim p_{s_1}$, then as $s_1\to0$ the output tends almost surely to the record from whose component $z_1$ was drawn. The law of $z_0$ tends to $\sum_i\beta_i\delta_{y_i}$.
:::

::: {custom-style="Statement"}
\(iii) Hence a stack in the continuum limit of Theorem 3.5, closed by a clean top, samples the archive itself: it re-selects records with probabilities equal to their prior weights and produces no new design.
:::

::: {custom-style="Statement Tag"}
\(i) V2 Corollary 7.2; (ii) and (iii) New in Part III.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) Proposition 2.2(iv). (ii) Write $z_1=y_J+s_1\varepsilon$ with $P(J=i)=\beta_i$ and $\varepsilon\sim N(0,I)$. For $i\ne J$, $\alpha_i/\alpha_J=(w_i/w_J)\exp(-(\Vert y_J-y_i\Vert^2+2s_1\varepsilon^{\top}(y_J-y_i))/2s_1^2)$, which tends to zero almost surely, so $m_1(z_1)\to y_J$. (iii) Apply (ii) to the limit law $p_{s_1}$ of Theorem 3.5(iv). ∎

::: {custom-style="Check"}
*Numerical check.* For the six records of Figure 2, 40,000 tokens from $p_{20}$ and 256 geometric layers down to $s_1=0.01$ followed by a clean top, 100.0% of the outputs lay within $10^{-6}$ of a record. The largest difference between a re-selection frequency and its prior weight was 0.0040, about twice the binomial standard error of the largest weight.
:::

V2 lists noise, the starting state, and transformed or recombined reads as distinct sources of novelty [9, Section 7]. Theorems 3.1 and 3.2 make the list exhaustive for identity maps and give each channel its size.

::: {custom-style="Statement"}
**Proposition 3.7** (the channels of novelty). Use identity maps and write $H=\text{conv}\{y_1,\ldots,y_n\}$.
:::

::: {custom-style="Statement"}
\(i) *Starting state.* $z_0-N$ lies in $\text{conv}(\{z_T\}\cup H)$, with weight $\omega_\star\le s_0/s_T$ on $z_T$.
:::

::: {custom-style="Statement"}
\(ii) *Noise.* $N$ has the law $N(0,(s_0^2-\omega_\star^2s_T^2)I)$ (Theorem 3.2).
:::

::: {custom-style="Statement"}
\(iii) *Blending.* The reads lie in $H$, and a read is a record only in the limit of a concentrated posterior; at a clean top the blending of the last read is the only channel left, and it closes as $s_1\to0$ (Proposition 3.6).
:::

::: {custom-style="Statement"}
\(iv) *Maps.* Non-identity maps can place reads outside $H$; coordinate masks do so whenever records disagree on complementary coordinates (Part II, Proposition 3.5). Discretisation error is not a channel: it moves outputs within $\text{conv}(\{z_T\}\cup H)$.
:::

::: {custom-style="Statement Tag"}
New in Part III; the list of channels is V2 Section 7.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) In (3.1) every $\omega_t\ge0$, every read lies in $H$ and the weights of $z_T$ and the reads sum to one; Theorem 3.2(i) bounds $\omega_\star$. (ii) Theorem 3.2(ii). (iii) Proposition 3.6. (iv) Part II, Proposition 3.5, and (i) for any schedule. ∎

::: {custom-style="Check"}
*Numerical check.* A linear program found the output of each of 200 deterministic stacks with identity maps inside $\text{conv}(\{z_T\}\cup H)$; there were 0 exceptions. With random coordinate masks in $ℝ^3$, 156 of 200 outputs lay outside that hull.
:::


## 4 Tangent dynamics

Along a realised path, with the noise held fixed, the derivative of the output with respect to the starting state is the product of the layer Jacobians. These products are the tangent fibre diagrams of Part I, and their exact barcodes and effective ranks were compared there [10, Section 4.4]. This section bounds their singular values, locates where they contract and expand, and shows why thresholded ranks cannot replace exact ones.

### 4.1 One layer

::: {custom-style="Statement"}
**Proposition 4.1** (a layer is a gradient step). Use identity maps and $s_t>0$. Without noise, layer $t$ is the gradient step $z\mapsto z-\lambda_t\nabla E_{s_t}(z)$, and its Jacobian is
:::

::: {custom-style="Statement Equation"}
$J_t(z)=(1-\lambda_t)I+\lambda_t\,C(z,s_t)/s_t^2=I-\lambda_t\nabla^2E_{s_t}(z)$ (4.1)
:::

::: {custom-style="Statement"}
It is symmetric, with eigenvalues $1-\lambda_t+\lambda_tc/s_t^2$ for the eigenvalues $c$ of $C$, all in $[1-\lambda_t,\ 1-\lambda_t+\lambda_tR^2/4s_t^2]$. If $\lambda_t>0$, the layer expands along an eigenvector $u$ of $C$ if and only if $c>s_t^2$, that is, if and only if $u$ is a direction of negative curvature of $E_{s_t}$ at $z$. In every direction orthogonal to the affine span of the records it multiplies by exactly $1-\lambda_t$.
:::

::: {custom-style="Statement Tag"}
The Jacobian and its bound V2 Proposition 13.1 and Part II Proposition 5.4; the gradient form Part II Proposition 3.9 and Corollary 3.12; the expansion criterion New in Part III.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* $\nabla E_s=z-m$ and $\nabla^2E_s=I-C/s^2$ (Part II, Proposition 3.9), so $(1-\lambda)z+\lambda m=z-\lambda\nabla E_s$ and (4.1) follows. The variance of the records along a unit vector is at most $R^2/4$. An eigenvalue exceeds one exactly when $\lambda(c/s^2-1)>0$. The range of $C$ is the direction space of the affine span of the records (Part I, Proposition 4.6(i)), so $Cu=0$ for $u$ orthogonal to it. ∎

::: {custom-style="Check"}
*Numerical check.* In 300 random layers in dimensions 1 to 4, (4.1) matched central differences to a relative 6.8 × 10⁻¹⁰, and the eigenvalue bounds had 0 violations.
:::

### 4.2 Composite tangents

::: {custom-style="Statement"}
**Theorem 4.2** (floor, ceiling and volume). Use identity maps. Along a realised path, with the noise fixed, let $K=J_1J_2\cdots J_T$ be the Jacobian of $z_0$ with respect to $z_T$.
:::

::: {custom-style="Statement"}
\(i) $\prod_t\lambda_{\text{min}}(J_t)\le\sigma_{\text{min}}(K)\le\sigma_{\text{max}}(K)\le\prod_t\lambda_{\text{max}}(J_t)$.
:::

::: {custom-style="Statement"}
\(ii) $\sigma_{\text{min}}(K)\ge\omega_\star$, which is $s_0/s_T$ when $\eta=0$. If $u$ is orthogonal to the affine span of the records, then $Ku=\omega_\star u$, so the floor is attained whenever the records do not affinely span $ℝ^D$.
:::

::: {custom-style="Statement"}
\(iii) With $c_{t,k}$ the eigenvalues of $C$ at layer $t$,
:::

::: {custom-style="Statement Equation"}
$\log|\text{det}\,K|=\sum_{t=1}^{T}\sum_{k=1}^{D}\log\left(1-\lambda_t+\lambda_tc_{t,k}/s_t^2\right)\ge D\log\omega_\star$ (4.2)
:::

::: {custom-style="Statement Tag"}
New in Part III; V2 Section 13 gives the bound for one layer.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* The noise enters additively, so the Jacobian of a noisy layer is (4.1) evaluated on the noisy path. (i) Each $J_t$ is symmetric positive semidefinite, so its singular values are its eigenvalues, and $\sigma_{\text{min}}(AB)\ge\sigma_{\text{min}}(A)\sigma_{\text{min}}(B)$ and $\sigma_{\text{max}}(AB)\le\sigma_{\text{max}}(A)\sigma_{\text{max}}(B)$ [13]. (ii) $\lambda_{\text{min}}(J_t)\ge1-\lambda_t$ and $\prod_t(1-\lambda_t)=\omega_\star$; Corollary 3.3 gives the deterministic value. For $u$ orthogonal to the affine span, $J_tu=(1-\lambda_t)u$ at every layer by Proposition 4.1. (iii) The determinant is multiplicative, and every factor is at least $1-\lambda_t$. ∎

In scaled coordinates a deterministic stack can therefore contract a tangent by at most the schedule ratio $s_0/s_T$. The reads only ever push singular values up from that floor, and they push hardest near branch decisions (Figure 3a).

::: {custom-style="Check"}
*Numerical check.* In 300 random stacks in dimensions 2 to 4 with 6 to 20 layers, half of them with a clean top, (i) had 0 and 0 violations and (4.2) held to a relative 2.1 × 10⁻¹⁵. The deterministic floor had 0 violations; the ratio $\sigma_{\text{min}}(K)/(s_0/s_T)$ had median 1.065 and minimum 1.000000, attained in the 20 stacks whose records did not affinely span the space, where $Ku=\omega_\star u$ held to 5.3 × 10⁻¹⁴. In 100 noisy stacks the floor $\omega_\star$ had 0 violations. Central differences matched $K$ to a relative 1.8 × 10⁻⁹.
:::

::: {custom-style="Statement"}
**Corollary 4.3** (contraction beyond the schedule happens at the top). Let $\eta=0$ and $s_0=0$, and let $c_{1,1}\ge\cdots\ge c_{1,D}$ be the eigenvalues of the top posterior covariance $C(z_1,s_1)$. Then for every $k$
:::

::: {custom-style="Statement Equation"}
$\frac{c_{1,k}}{s_1s_T}\le\sigma_k(K)\le\frac{c_{1,k}}{s_1s_T}\,X,\qquad X=\prod_{t=2}^{T}\frac{\lambda_{\text{max}}(J_t)}{1-\lambda_t}\ge1$ (4.3)
:::

::: {custom-style="Statement"}
and the rank of $K$ is the rank of $C(z_1,s_1)$, the affine dimension of the records when every weight is positive. The expansion excess $X$ equals one only if every posterior covariance below the top vanishes.
:::

::: {custom-style="Statement Tag"}
New in Part III; the rank statement is Part I Proposition 4.6.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* At a clean top $J_1=C(z_1,s_1)/s_1^2$, whose $k$-th singular value is $c_{1,k}/s_1^2$. For $B=J_2\cdots J_T$, $\sigma_k(J_1)\sigma_{\text{min}}(B)\le\sigma_k(J_1B)\le\sigma_k(J_1)\Vert B\Vert$ [13]. Theorem 4.2 gives $\sigma_{\text{min}}(B)\ge\prod_{t\ge2}(1-\lambda_t)=s_1/s_T$ and $\Vert B\Vert\le\prod_{t\ge2}\lambda_{\text{max}}(J_t)=(s_1/s_T)X$. $B$ is invertible, so $\text{rank}\,K=\text{rank}\,J_1$. ∎

Part I ran 1,000 tokens through a sixteen-layer cosine stack with a clean top, starting from layer 15, and found median singular values 0.0353 and $6.4\times10^{-4}$ for the composite [10, Section 4.4]. For that schedule $s_1s_{15}=\tan(\pi/32)\tan(15\pi/32)=1$, so (4.3) says that each singular value is the corresponding eigenvalue of the top posterior covariance, multiplied by a factor between 1 and $X$. Replaying the same archive and tokens confirms it (Figure 3b). The contraction Part I observed is the concentration of the top read, inflated by the expansion of the layers below.

::: {custom-style="Check"}
*Numerical check.* In the 150 clean-top stacks of the previous check, (4.3) had 0 lower and 0 upper violations. On Part I's experiment, replayed from its random stream, both sides held for 1,000 of 1,000 tokens. The median singular values were 0.0353 and 6.41 × 10⁻⁴, the median top eigenvalues 6.13 × 10⁻³ and 1.86 × 10⁻⁴, and the median ratios $\sigma_k/c_{1,k}$ were 6.44 and 3.07. The excess $X$ had median 8.5 and 90th percentile 31.8.
:::

![**Figure 3.** (a) Largest and smallest singular values of the composite $K_{T\to t}$ for 40 tokens climbing a sixteen-layer geometric stack from $s_T=20$ to $s_0=0.05$ over three clusters of ten records in $ℝ^2$ (recomputed with a fixed seed). No singular value falls below the floor $s_t/s_T$ (Theorem 4.2). (b) The experiment of Part I, replayed: singular values of the composite against the eigenvalues of the top posterior covariance. Every point lies above the bound of Corollary 4.3, here $\sigma_k=c_{1,k}$ because $s_1s_{15}=1$. (c) The largest eigenvalue of $C_t/s_t^2$ along 300 of those paths. A layer expands where the curve exceeds one (Proposition 4.1). Over all 1,000 tokens, no layer above layer 8 expanded; from there to the top, 18% to 37% of the tokens expanded at each layer, and 73% expanded at some layer.](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p3/fig/tangent.png){width=100%}

### 4.3 Fixed points, Morse index and bifurcations

At a fixed scale, the fixed points of the read are the stationary points of $E_s$. Their type, and the scales at which they appear and disappear, are what a mode-based barcode would record.

::: {custom-style="Statement"}
**Proposition 4.4** (fixed points, Morse index and bifurcations). Use identity maps and fix $s>0$.
:::

::: {custom-style="Statement"}
\(i) $m(z^\star,s)=z^\star$ if and only if $\nabla E_s(z^\star)=0$. Every layer at scale $s$ with $\lambda>0$ then fixes $z^\star$, and the number of its expanding directions equals the Morse index of $E_s$ at $z^\star$. Nondegenerate minima of $E_s$, the modes of $p_s$, attract.
:::

::: {custom-style="Statement"}
\(ii) (Morse balance) If every stationary point of $E_s$ is nondegenerate, then $\sum_k(-1)^kN_k=1$, where $N_k$ is the number of stationary points of index $k$.
:::

::: {custom-style="Statement"}
\(iii) (bifurcations) If 1 is not an eigenvalue of $C(z^\star,\varsigma)/\varsigma^2$ at a stationary point $z^\star$ for the scale $\varsigma$, then for $s$ near $\varsigma$ there is exactly one stationary point near $z^\star$; it depends smoothly on $s$ and keeps its index. Stationary points can therefore appear, disappear or change type only at scales where a stationary point has a tangent eigenvalue $c/s^2=1$, the expansion threshold of Proposition 4.1.
:::

::: {custom-style="Statement"}
\(iv) For two records of equal weight at distance $d$, the midpoint is a stationary point with $C/s^2=d^2/4s^2$, and the pitchfork occurs at $s=d/2$. For three equal records at the vertices of an equilateral triangle with side $\ell$, the centroid has $C=(\ell^2/6)\,I$ at every scale, so it changes type at $s=\ell/\sqrt6$.
:::

::: {custom-style="Statement Tag"}
\(i) Part II Corollary 5.5, with Proposition 4.1; (ii) classical, the Poincaré–Hopf theorem [16]; (iii) classical, the implicit function theorem, with the identification of the threshold New in Part III; (iv) the pitchfork V2 Proposition 14.2, the centroid New in Part III.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) $\nabla E_s=z-m$. At $z^\star$, the eigenvalues of $J$ are $1-\lambda+\lambda c/s^2$, and the Hessian $I-C/s^2$ has a negative eigenvalue exactly when $c>s^2$. At a nondegenerate minimum every $c<s^2$, so $J$ has spectral radius below one. (ii) On a large ball, $\nabla E_s=z-m$ points outward because $m$ stays in the hull of the records. The Poincaré–Hopf theorem gives $\sum\text{sign}\,\text{det}\,\nabla^2E_s=\chi(\text{ball})=1$, and the sign is $(-1)^k$ at a point of index $k$ [16]. (iii) Apply the implicit function theorem to $F(z,s)=m(z,s)-z$, whose $z$-derivative $C/s^2-I$ is invertible at $(z^\star,\varsigma)$; the eigenvalues vary continuously and cannot cross one along the branch. (iv) At the midpoint the two weights are equal, so $C=(d/2)^2$ along the line of the records and zero across it. At the centroid the three weights are equal, and the second moment of the vertices about the centroid is $(r^2/2)I$, with circumradius $r=\ell/\sqrt3$. ∎

::: {custom-style="Statement"}
**Example 4.5** (pitchfork and fold). For records at $\pm1$ with equal weights, there are three stationary points for $s<1$ and one for $s>1$. With weights in the ratio 7 to 3, the symmetry breaks and the pitchfork becomes a fold: the lighter record's mode and the saddle between the records meet and vanish together (Figure 4a).
:::

::: {custom-style="Check"}
*Numerical check.* In 60 random archives in $ℝ^2$, Newton's method from 285 starts found 184 stationary points: 120 minima, 62 saddles and 2 maxima of $E_s$. The number of expanding directions equalled the Morse index of a finite-difference Hessian of $\log p_s$ at all 184, and the Morse balance held in 60 of 60 archives. For records at $\pm1$, the counts at $s=0.8$, 0.9 and 0.99 were 3 and at 1.01, 1.1 and 1.3 were 1, and the midpoint tangent at $s=1$ was 1.0000. With weights 7 to 3 the fold lay at $s=0.7368$, where the two merging points had tangent eigenvalues 1.0009 and 0.9991.
:::

### 4.4 Exact and effective rank

Part I showed that the exact barcode of a Gaussian tangent diagram is usually full, while sensitivity contracts by orders of magnitude [10, Proposition 4.6]. It is tempting to repair this by computing barcodes from thresholded ranks. That repair fails.

::: {custom-style="Statement"}
**Proposition 4.6** (thresholded ranks are not rank invariants). For a chain of linear maps and a tolerance $\tau>0$, let $r_\tau(a,b)$ be the number of singular values of the composite from layer $a$ to layer $b$ that exceed $\tau$.
:::

::: {custom-style="Statement"}
\(i) $r_\tau$ can increase under composition. For $J_1=\text{diag}(10,0.05)$, $J_2=\text{diag}(0.05,10)$ and $\tau=0.1$, $r_\tau(2,1)=r_\tau(1,0)=1$ but $r_\tau(2,0)=2$.
:::

::: {custom-style="Statement"}
\(ii) Even for contractions, $r_\tau$ violates Sylvester's inequality $r(a,c)\ge r(a,b)+r(b,c)-\text{dim}\,V_b$. For $J_1=J_2=0.7\,I_2$ and $\tau=0.6$, $r_\tau(2,1)=r_\tau(1,0)=2$ but $r_\tau(2,0)=0$.
:::

::: {custom-style="Statement"}
\(iii) In both examples, formula (4.1) of Part I returns negative multiplicities: $m[2,1]=m[1,0]=-1$ in (i) and $m[1,1]=-2$ in (ii). Exact ranks never do (Part I, Theorem 4.2).
:::

::: {custom-style="Statement Tag"}
New in Part III; exact ranks Part I Theorem 4.2 [10].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) $J_2J_1=0.5\,I$. (ii) $J_2J_1=0.49\,I$. (iii) Substitute into Part I (4.1): in (i), $m[2,1]=r(2,1)-r(2,0)=-1$ and $m[1,0]=r(1,0)-r(2,0)=-1$; in (ii), $m[1,1]=2-r(2,1)-r(1,0)+r(2,0)=-2$. For exact ranks, every chain decomposes into intervals, and the multiplicities are counts. ∎

A thresholded "effective barcode" is therefore not a barcode. The defensible report has two parts: the exact barcode, which is a complete invariant and usually trivial, and the singular-value profile of the composites, which is stable under perturbation (Part I, Proposition 4.6(iv)) and is bounded by Theorem 4.2 and Corollary 4.3.

::: {custom-style="Check"}
*Numerical check.* Formula (4.1) of Part I returned the multiplicities stated in (iii). Among 2,000 random chains of three maps on $ℝ^3$ with log-normal singular values, half of the maps losing rank exactly, 1,989 had a negative multiplicity at $\tau=1$, and none with exact ranks. Along the 1,000 realised sixteen-layer tangent diagrams of Part I's experiment, thresholded ranks gave negative multiplicities for 552 tokens at $\tau=10^{-2}$ and 259 at $\tau=10^{-3}$. At a relative tolerance of $10^{-14}$, 9 tokens still did; these are the numerically singular tokens of Part I, for which even the exact rank is, in floating point, a thresholded one.
:::


## 5 Persistence across layers

Part I described two vertical persistence modules: the tangent fibre diagram of a token, and the cohomology of layer covers along a filtration [10, Sections 4.4–4.5]. Section 4.4 showed that the first must be read with exact ranks. This section asks which scale summaries of the archive form filtrations at all, since only those have barcodes, and then asks where in the scale range the layers of a stack actually matter. The second question is the subject of hypothesis C3 of V2.

### 5.1 Which scale summaries are filtrations

::: {custom-style="Statement"}
**Proposition 5.1** (component barcodes). Fix the records and open balls $B(y_i,r)$.
:::

::: {custom-style="Statement"}
\(i) For radii $r_0\le\cdots\le r_T$ the ball nerves are nested, and in the token direction the degree-zero maps are injective; every bar reaches the top (Part I, Proposition 4.10).
:::

::: {custom-style="Statement"}
\(ii) The number of components at radius $r$ is $n$ minus the number of merge heights $h_j<2r$, where $h_1\le\cdots\le h_{n-1}$ are the merge heights of single-linkage clustering of the records. In the token direction a bar is born at each merge radius $h_j/2$.
:::

::: {custom-style="Statement"}
\(iii) For two records at distance $d$ the merge radius $d/2$ is the pitchfork scale of Proposition 4.4(iv).
:::

::: {custom-style="Statement Tag"}
\(i) Part I Proposition 4.10; (ii) classical [3]; (iii) V2 Proposition 14.2.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (ii) Two open balls of radius $r$ meet exactly when their centres are closer than $2r$, so the components of their union are the components of the graph that joins records at distance below $2r$. Single linkage merges components exactly at those thresholds. (iii) Proposition 4.4(iv). ∎

Components are thus a filtration whose barcode the archive determines once and for all. Modes of $p_s$ are a different matter.

::: {custom-style="Statement"}
**Proposition 5.2** (in one dimension modes are only born in the token direction). For $D=1$ and positive weights, the number of modes of $p_s$ does not increase with $s$.
:::

::: {custom-style="Statement Tag"}
Classical [17, 2].
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* For 150 random one-dimensional archives of 3 to 9 records with random weights, the mode count on 30 geometric scales from 0.05 to 5 never increased; there were 0 exceptions.
:::

::: {custom-style="Statement"}
**Example 5.3** (in two dimensions a mode is born as the scale grows). Place three records of equal weight at the vertices of an equilateral triangle with unit side. Then $p_s$ has three modes for $s<1/\sqrt6\approx0.4082$, four for $1/\sqrt6<s<0.4267$, and one for larger $s$. In units of the circumradius the two transitions are $\sqrt2/2$ and 0.7391, as found by Carreira-Perpiñán and Williams [5]. At $s=1/\sqrt6$ the tangent at the centroid reaches the expansion threshold in both directions at once (Proposition 4.4(iv)): the three saddles, approaching from the sides, pass through the centroid and leave towards the vertices, and the centroid turns from a minimum of the density into a mode. At $s\approx0.4267$ each vertex mode meets a saddle in a fold. The Morse balance holds throughout: $3-3+1=4-3+0=1-0+0=1$.
:::

::: {custom-style="Statement Tag"}
The mode counts Carreira-Perpiñán and Williams [5], who credit the example to Duistermaat, see also [4]; the mechanism and the exact first transition New in Part III.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* Mode finding by the read iteration from a 41 by 41 grid gave three modes up to $s=0.4075$, four from 0.41 to 0.425 and one from 0.4275, in steps of 0.0025. Newton's method from 2,116 starts at twelve scales confirmed the counts of minima, saddles and maxima, with balance 1 at every scale. Bisection placed the fold at 0.42674, that is 0.7391 circumradii, and the centroid switch at 0.40825.
:::

So in two dimensions the mode count is not monotone in $s$, the mode sets of successive layers do not form a filtration, and inclusion–exclusion on mode counts does not produce a barcode. The component barcode of the same three records is unaffected: the balls merge once, at $r=1/2$. V2 reported agreement between component counts and mode counts of 76% in one dimension and 80% in two, and called it a proxy rather than a theorem [9, Section 14]. For 30 random archives of 8 equal records in the unit square and 16 scales from 0.03 to 0.6, with radius equal to scale, the counts agreed in 393 of 480 pairs (81.9%).

![**Figure 4.** (a) Stationary points of $E_s$ for records at $\pm1$: with equal weights a pitchfork at $s=1$, with weights 7 to 3 a fold at $s\approx0.737$ (Example 4.5). Grey points are saddles, where a layer expands. (b) Three equal records at the vertices of a unit triangle, with contours of $p_s$, modes, saddles and the density minimum at three scales. Between $s=1/\sqrt6$ and 0.4267 the centroid is a fourth mode (Example 5.3). (c) Counts of modes and saddles against $s$; the dotted line marks $s=1/\sqrt6$.](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p3/fig/modes.png){width=100%}

### 5.2 Where layers matter

Theorem 3.5(iii) locates the error of a layer in the motion of the read along its step. The next theorem says how fast the read moves.

::: {custom-style="Statement"}
**Theorem 5.4** (curvature of token paths). Use identity maps. Along a solution of (3.5), with $\alpha_i$, $m$ and $C$ evaluated at $(z(s),s)$, let
:::

::: {custom-style="Statement Equation"}
$M_3=\sum_i\alpha_i\Vert y_i-m\Vert^2\,(y_i-m)$ (5.1)
:::

::: {custom-style="Statement"}
\(i) The path curves as fast as the read moves:
:::

::: {custom-style="Statement Equation"}
$z''=\frac{C(z-m)-M_3}{s^4}=-\frac{1}{s}\,\frac{\text{d}m}{\text{d}s}$ (5.2)
:::

::: {custom-style="Statement"}
\(ii) If one record has posterior mass at least $1-\varepsilon$ and $R$ is the diameter of the records, then
:::

::: {custom-style="Statement Equation"}
$\Vert z''\Vert\le\frac{\varepsilon\left(R^2\Vert z-m\Vert+(1+\varepsilon^2)R^3\right)}{s^4}$ (5.3)
:::

::: {custom-style="Statement"}
\(iii) Hence, by (3.6), a layer whose step keeps the posterior concentrated on one record is exact up to $O(\varepsilon)$: token paths are straight lines except where the posterior is spread over several records.
:::

::: {custom-style="Statement Tag"}
New in Part III.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) Differentiating $z'=(z-m)/s$ gives $z''=(z'-m')/s-(z-m)/s^2=-m'/s$, where $m'=\text{d}m/\text{d}s=(C/s^2)z'+\partial_sm$. Differentiating the softmax gives $\partial_s\alpha_i=(2/s^3)\alpha_i(e_i-\langle e\rangle)$ with $e_i=\tfrac12\Vert z-y_i\Vert^2$, so $\partial_sm=(2/s^3)\sum_i\alpha_i(e_i-\langle e\rangle)(y_i-m)$. Expanding $e_i$ about $m$, $e_i-\langle e\rangle=-(z-m)^{\top}(y_i-m)+\tfrac12(\Vert y_i-m\Vert^2-\langle\Vert y-m\Vert^2\rangle)$, hence $\partial_sm=(M_3-2C(z-m))/s^3$ and $m'=(M_3-C(z-m))/s^3$. (ii) $\Vert C\Vert\le\varepsilon R^2$ by Part I, Proposition 4.6(ii). For the dominant record $j$, $\Vert y_j-m\Vert\le\varepsilon R$, and $\Vert y_i-m\Vert\le R$ for every $i$, so $\Vert M_3\Vert\le(\varepsilon R)^3+\varepsilon R^3$. (iii) Insert (5.3) in (3.6). ∎

::: {custom-style="Check"}
*Numerical check.* At 120 points on finely resolved flows in $ℝ^2$, second differences of the paths matched (5.2) to a median relative 8.1 × 10⁻⁵ (largest 1.2 × 10⁻³, set by the reference flow), and the two forms of (5.2) agreed to 1.6 × 10⁻¹⁶ of the scale of (5.3). In 4,000 random configurations, (5.3) had 0 violations; the largest ratio to the bound was 1.0000 and the median 0.025.
:::

Along the exact flow the token at scale $s$ has the law $p_s$ (Theorem 3.5(ii)). The mean curvature $g(s)=E_{z\sim p_s}\Vert z''\Vert$ can therefore be estimated from the archive alone, by sampling $p_s$ and evaluating (5.2), without running any flow.

::: {custom-style="Statement"}
**Proposition 5.5** (an error model and the layer-halving bound). For positive scales $s_1<\cdots<s_k$, replace $\text{max}\,\Vert z''\Vert$ in (3.6) by $g$ and sum the local errors:
:::

::: {custom-style="Statement Equation"}
$ℰ(s_1,\ldots,s_k)=\sum_{t=2}^{k}\frac{1}{2}(s_t-s_{t-1})\int_{s_{t-1}}^{s_t}g(s)\,\text{d}s$ (5.4)
:::

::: {custom-style="Statement"}
\(i) For a layer density $\rho$ with $\int\rho\,\text{d}s=k-1$, the continuum form $\tfrac12\int g/\rho\,\text{d}s$ of (5.4) is minimised by $\rho\propto\sqrt{g}$, with minimum
:::

::: {custom-style="Statement Equation"}
$ℰ_{\text{min}}(k)=\frac{1}{2(k-1)}\left(\int_{s_1}^{s_k}\sqrt{g(s)}\,\text{d}s\right)^2$ (5.5)
:::

::: {custom-style="Statement"}
\(ii) Call $e=ℰ_{\text{min}}/ℰ$ the efficiency of a schedule. Under the model, a $k$-layer schedule can match a $2k$-layer baseline only if the baseline's efficiency is at most $(k-1)/(2k-1)$, which is less than one half.
:::

::: {custom-style="Statement Tag"}
\(i) Classical in form, the equidistribution of local error [12]; (ii) New in Part III.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) By the Cauchy–Schwarz inequality, $\left(\int\sqrt{g}\right)^2=\left(\int\sqrt{g/\rho}\,\sqrt{\rho}\right)^2\le\int(g/\rho)\int\rho$, with equality if and only if $\rho\propto\sqrt{g}$. (ii) A $k$-layer schedule has $ℰ\ge ℰ_{\text{min}}(k)$, while a $2k$-layer baseline of efficiency $e$ has $ℰ=ℰ_{\text{min}}(2k)/e$. By (5.5), $ℰ_{\text{min}}(k)\le ℰ_{\text{min}}(2k)/e$ if and only if $e\le(k-1)/(2k-1)$. ∎

The model ignores how later layers propagate an error, which Theorem 4.2 shows can contract or expand it, and it replaces the worst case by the mean. It is a model, not a bound. Its value is that it makes the question behind C3 quantitative. Halving the number of layers at equal quality is impossible for first-order layers unless the baseline wastes more than half of its layers, and whether a schedule wastes layers is measured by $e$.


### 5.3 An exploratory pilot of hypothesis C3

V2 states hypothesis C3 as follows: a $k$-layer schedule chosen from component persistence scales matches a $2k$-layer cosine schedule within 2% in declared output loss and novel-output share, on frozen multimodal families in dimensions 2, 4 and 8, with shared endpoint and cutoff rules; a $k$-layer geometric schedule is the control for layer thinning [9, Section 18]. The confirmatory test needs the optimisation families and output losses of V2. In the transport setting of Theorem 3.5, however, the quality of a schedule can be measured exactly, against the continuum flow from the same starting tokens. We ran that comparison as an exploratory pilot. The metrics and the decision rule were fixed in the script before the first run. After a trial on one archive, we replaced a flow-based estimate of the curvature density by the archive-only estimate described below and added the mass-weighted barcode schedule. Every schedule that was run is reported.

**Families and shared rules.** In each dimension $D\in\{2,4,8\}$ we froze 20 archives of 27 records in three nested levels of clusters, with spreads 4, 1 and 0.25 before normalising to unit pooled deviation per coordinate, and log prior weights with standard deviation 0.5. Every schedule has a clean top, $s_0=0$, the coarse start $s_k$ equal to twice the largest merge radius, and a common finest positive scale $s_1$. With a *fine top*, $s_1$ is half the smallest merge radius, so the last read resolves every record. With a *coarse top*, $s_1$ is the median merge radius. 1,000 tokens per archive were drawn from $p_{s_k}$ and shared by all schedules, so every comparison is paired. The reference output of a token is the clean-top read at $s_1$ of the exact flow (3.5), integrated by the classical Runge–Kutta method in $\log s$ with step 0.004; halving the step moved the reference outputs by at most 9.2 × 10⁻⁹ nearest-neighbour distances.

Table: **Table 2.** Schedules in the pilot. All share $s_0=0$, $s_1$ and $s_k$; the rules place the $k-2$ interior scales.

| Schedule | Interior scales | Role |
|:---------------|:------------------------------------|:-----------------------|
| cosine | $\arctan s$ uniformly spaced | the C3 baseline, at $2k$ layers |
| geometric | $\log s$ uniformly spaced | the C3 control for thinning |
| EDM, $\rho=7$ | $s^{1/7}$ uniformly spaced [14] | a common sampler schedule |
| barcode, quantiles | merge radii at evenly spaced ranks | the C3 schedule |
| barcode, longest bars | the $k-2$ largest merge radii | a second reading of C3 |
| barcode, mass-weighted | quantiles of merge radii weighted by the prior mass that splits there | added after the trial |
| curvature | density proportional to $\sqrt g$, with $g$ from 300 draws of $p_s$ at 160 scales | Proposition 5.5, archive only |

**Metrics.** The *path loss* is the mean distance between a schedule's output and the reference output, in units of the median nearest-neighbour distance $d_{nn}$ of the records. The *novel-output share* is the share of outputs farther than $10^{-3}d_{nn}$ from every record. For C3 we compared each barcode schedule with $k$ layers against cosine with $2k$ layers, for $k=4$, 8, 16 and 32. Degradation is the ratio of archive-mean losses minus one, and the novelty difference is in percentage points; both carry paired bootstrap 95% intervals over the archives, with 10,000 resamples. A comparison *supports* C3 if the loss interval lies below +2% and the novelty interval within ±2 points. It *refutes* C3 if the loss interval lies above +2% or the novelty interval lies outside ±2 points. Otherwise it is *inconclusive*.

Table: **Table 3.** Path loss pooled over $D=2$, 4 and 8, by schedule and number of layers $k$, with a fine top; the median efficiency $e$ of Proposition 5.5 at $k=16$; and the loss at $k=16$ with a coarse top.

| Schedule | $k=4$ | 8 | 16 | 32 | 64 | $e$ | coarse top |
|:----------------------|:------|:------|:------|:------|:------|:-----|:----------|
| cosine | 1.434 | 0.588 | 0.264 | 0.121 | 0.058 | 0.93 | 0.225 |
| geometric | 2.388 | 0.948 | 0.438 | 0.212 | 0.103 | 0.70 | 0.262 |
| EDM, $\rho=7$ | 1.854 | 0.754 | 0.348 | 0.168 | 0.077 | 0.82 | 0.241 |
| barcode, quantiles | 3.624 | 2.517 | 1.208 | 0.483 | 0.121 | 0.27 | 0.652 |
| barcode, longest bars | 1.899 | 1.060 | 0.953 | 0.483 | 0.121 | 0.34 | 0.652 |
| barcode, mass-weighted | 2.154 | 1.068 | 0.739 | 0.483 | 0.121 | 0.42 | 0.652 |
| curvature, $\rho\propto\sqrt g$ | 1.404 | 0.554 | 0.252 | 0.117 | 0.058 | 1.00 | 0.215 |

Table: **Table 4.** The C3 comparison with a fine top: the barcode schedule with quantile placement and $k$ layers against cosine with $2k$ layers. Intervals are paired bootstrap 95% intervals. The last two columns give the degradation of the same barcode schedule against geometric with $k$ layers, and of the curvature schedule with $k$ layers against cosine with $2k$ layers.

| $D$ | $k$ | loss degradation, % | novelty difference, points | verdict | against geometric, % | curvature against cosine, % |
|:--|:--|:----------------|:----------------|:--------|:----------|:----------|
| 2 | 4 | +535 (+483, +586) | −4.7 (−6.8, −2.8) | refuted | +31 | +131 |
| 2 | 8 | +874 (+767, +972) | −5.6 (−7.8, −3.7) | refuted | +138 | +105 |
| 2 | 16 | +926 (+809, +1061) | −5.9 (−7.6, −4.3) | refuted | +138 | +122 |
| 2 | 32 | +833 (+733, +945) | −4.2 (−5.4, −3.2) | refuted | +120 | +111 |
| 4 | 4 | +511 (+475, +549) | −19.6 (−23.7, −15.5) | refuted | +74 | +134 |
| 4 | 8 | +851 (+759, +951) | −13.9 (−17.0, −10.9) | refuted | +186 | +113 |
| 4 | 16 | +866 (+761, +993) | −8.1 (−9.9, −6.3) | refuted | +199 | +97 |
| 4 | 32 | +630 (+561, +703) | −3.7 (−4.4, −2.9) | refuted | +128 | +87 |
| 8 | 4 | +496 (+461, +534) | −18.8 (−21.5, −16.0) | refuted | +67 | +155 |
| 8 | 8 | +829 (+759, +904) | −10.5 (−12.7, −8.3) | refuted | +195 | +116 |
| 8 | 16 | +907 (+804, +1033) | −4.3 (−5.7, −2.8) | refuted | +223 | +103 |
| 8 | 32 | +681 (+561, +837) | −1.7 (−2.3, −1.2) | refuted | +145 | +100 |

**Results.** All 72 comparisons of a barcode schedule with $k$ layers against cosine with $2k$ layers refuted C3: three readings of the barcode rule, three dimensions, four layer counts and two top rules. Table 4 shows the quantile reading with a fine top. Loss degradations ranged from +154% to +926%, so the loss criterion alone was decisive; the novelty interval also lay outside ±2 points in 11 of the 12 rows of Table 4. The quantile barcode was worse than geometric spacing with the same number of layers in all 12 fine-top comparisons. In this setting, therefore, choosing scales by topology did worse than thinning the layers. At 32 and 64 layers the three barcode schedules coincide, because every merge radius is then used.

The error model of Proposition 5.5 accounts for the outcome (Figure 5d). Across the seven schedules, the model ranked the observed losses with a median Spearman correlation of 1.00 with a fine top and 0.96 with a coarse top, and the correlation was positive for every archive and layer count. At $k=16$ the median efficiencies were 0.27, 0.34 and 0.42 for the three barcode schedules, 0.70 for geometric, 0.82 for EDM, 0.93 for cosine and 1.00 for the curvature schedule. The reason is visible in Figure 5a. Merge radii crowd the fine scales, where most merges join neighbouring records and affect only the few tokens near them. The curvature of a typical path lies at intermediate and coarse scales, where whole clusters separate and every token takes a branch. The mass-weighted reading moves layers towards those scales and improves on the quantile reading, but not enough.

Because the efficiency of cosine spacing exceeds one half, Proposition 5.5(ii) predicts that no schedule can match it with half the layers. The data agree. Halving the layers of cosine itself multiplied its pooled loss by 2.06 to 2.23. Even the curvature schedule with $k$ layers had between +87% and +155% more loss than cosine with $2k$, so it too fails C3. At equal numbers of layers, however, it was the best schedule: it had the lowest pooled loss at every layer count with both top rules, and the lowest loss in 28 of 30 cells by dimension, the other two going to cosine. In a post hoc paired comparison with cosine at equal $k$, its loss was lower with an interval excluding zero in 17 of 30 comparisons and higher in 0. The differences ranged from −9.0% to +4.8%.

Novelty needs a caveat. With a fine top, the share of novel outputs of the reference transport was 2.6%, 6.0% and 8.4% in dimensions 2, 4 and 8. Cosine with 64 layers still produced 7.6%, 12.0% and 13.8% novel outputs, against 2.8%, 6.7% and 9.3% for geometric spacing. Cosine spacing ends with a long step to the finest scale, and the final read then blends neighbouring records. Matching the novelty share of cosine with $2k$ layers is therefore not the same as matching the transport, and the novelty half of C3 should be stated against the continuum reference.

**Verdict.** In this exploratory transport setting, C3 is refuted for every reading of the barcode rule that we tried. Component persistence scales place layers where few tokens make decisions. The pilot suggests replacing C3 by two statements that the theory supports and that a confirmatory study can test. The first is that the efficiency $e$, computed from the archive alone, predicts the ranking of schedules. The second is that a schedule with density proportional to $\sqrt g$ is non-inferior to the cosine schedule with the same number of layers. Neither is established here. Both belong in the confirmatory protocol, with the output losses of V2 in place of the transport metric.

![**Figure 5.** The schedule pilot. (a) For one archive in $ℝ^2$: the square root of the curvature density $g$, the 26 merge radii, and the scales of the seven schedules with eight layers. Most merge radii are fine, while most curvature lies at coarse scales. (b) Path loss against the number of layers, pooled over $D=2$, 4 and 8, with a fine top. (c) The C3 comparison: loss of the quantile barcode schedule and of the curvature schedule with $k$ layers, divided by the loss of cosine with $2k$ layers, with bootstrap 95% intervals; the dashed line is the 2% margin. (d) For every archive and $k=8$, 16 and 32, the error model (5.4) of each schedule against its path loss, both relative to cosine with the same $k$.](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p3/fig/schedules.png){width=100%}


## 6 Register of numerical checks

Table 5 lists every numerical check in Part III. A main script produced 18 checks and a supplementary script 3; the pilot of Section 5.3 and the kernel comparison of Appendix A complete the list. All scripts write machine-readable results, and every number in this paper is read from those files when the document is built. The checks test the implementations and illustrate the statements; the proofs establish them. Random archives are synthetic, so ratios to bounds describe these constructions, not engineering archives in general.

Table: **Table 5.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 2.2 | coefficients, 500 schedules | bookkeeping 1.2 × 10⁻¹⁵; (19.2) to 3.3 × 10⁻¹³ |
| 2 | Proposition 2.3 | ADE recovery, 200 stacks | 1.8 × 10⁻¹³ |
| 3 | Theorem 3.1 | separation, 300 paths | 5.2 × 10⁻¹⁶ |
| 4 | Theorem 3.2 | noise budget, 500 schedules; oracle | 2.7 × 10⁻¹⁶; output deviation within 0.3% of $s_0$ |
| 5 | Corollary 3.3 | deterministic weights, cosine table | 2.2 × 10⁻¹⁶; V2 table reproduced |
| 6 | Proposition 3.4 | Euler and score forms, 300 layers | 4.0 × 10⁻¹⁵ |
| 7 | Theorem 3.5 | continuum limit, 40,000 tokens | KS 0.093 to 0.0064 from 4 to 256 layers |
| 8 | Proposition 3.6 | clean-top re-selection | 100.0% on records; frequencies within 0.0040 |
| 9 | Proposition 3.7 | hulls, 200 and 200 stacks | 0 identity outputs outside; 156 masked outputs outside |
| 10 | Proposition 4.1 | layer Jacobian, 300 layers | 6.8 × 10⁻¹⁰; 0 bound violations |
| 11 | Theorem 4.2 | composites, 300 and 100 stacks | 0 violations; floor attained; volume 2.1 × 10⁻¹⁵ |
| 12 | Corollary 4.3 | clean-top sandwich; Part I replayed | 0 and 0 violations; 1,000 of 1,000 tokens |
| 13 | Proposition 4.4(i), (ii) | Morse index and balance, 60 archives | 184 of 184 points; 60 balanced |
| 14 | Proposition 4.4(iii), Example 4.5 | pitchfork and fold | tangent 1.0000; fold at 0.7368 |
| 15 | Proposition 4.6 | thresholded ranks, 2,000 chains; Part I | 1,989 negative; exact 0; 552 tokens at $10^{-2}$ |
| 16 | Proposition 5.2 | one-dimensional modes, 150 archives | 0 increases |
| 17 | Example 5.3 | triangle counts and Morse balance | four modes from 0.41 to 0.425; fold 0.4267 |
| 18 | Section 5.1 | components against modes, 480 pairs | 81.9% agree |
| 19 | Theorem 5.4(i) | path curvature, 120 points | median 8.1 × 10⁻⁵; forms 1.6 × 10⁻¹⁶ |
| 20 | Theorem 5.4(ii) | curvature bound, 4,000 cases | 0 violations; largest ratio 1.0000 |
| 21 | Proposition 5.5 | efficiency against loss, pilot | median Spearman 1.00 and 0.96; positive in every archive |
| 22 | Section 5.3 | C3 pilot, 60 archives | 72 of 72 barcode comparisons refuted; curvature schedule best at every layer count |
| 23 | Appendix A | C# kernel against NumPy | 18 of 18 lines agree; 16 identical to 15 digits |

## 7 Discussion

### 7.1 What Part III supplies to the rest of the book

Part IV, on targets and estimation, needs the law of the proposals. Theorem 3.5 identifies it in the continuum limit: a deterministic stack with identity maps proposes from $p_{s_0}$, the archive density at the top scale. Its discretisation error is controlled by the curvature of Theorem 5.4. With a clean top, Proposition 3.6 says the stack proposes from the archive itself. The noise budget fixes the exact Gaussian part of any stochastic stack. These are the facts an importance weight or a Gibbs target must be built on.

Part V, on fusion and constraints, needs end-to-end sensitivities. Theorem 4.2 gives two-sided bounds for every singular value of a composite. Corollary 4.3 shows that at a clean top the composite is the top posterior covariance up to explicit factors, so the sensitivity of an output design to its starting query is decided by how concentrated the last read is. Part VI, on evidence and computation, takes the diagnostics of Table 6 and the kernel of Appendix A as specifications.

For the hypotheses of V2, the pilot of Section 5.3 bears on C3, and Proposition 5.5 gives it a quantitative form: whether a schedule can halve its layers depends on the efficiency of the baseline, which the archive alone determines.

### 7.2 Diagnostics a stack should report

Table: **Table 6.** Diagnostics reported with every stack.

| Diagnostic | Source | Action when it is poor |
|:-------------------|:-------------------|:-------------------------------|
| weight $\omega_\star$ and the noise budget split | Theorem 3.2 | report both shares of $s_0^2$ |
| eigenvalues of the top posterior covariance and the excess $X$ | Corollary 4.3 | report with every sensitivity claim |
| layers where $c>s^2$ along each path | Proposition 4.1 | flag branch decisions; never threshold them away |
| exact barcode and singular-value profile | Proposition 4.6 | never report a thresholded barcode |
| component barcode, not mode counts, in two or more dimensions | Proposition 5.1, Example 5.3 | use modes only as a proxy, with its agreement rate |
| curvature density $g$ and schedule efficiency $e$ | Proposition 5.5 | move layers to where $\sqrt g$ is large |
| re-selection share and the size of each novelty channel | Propositions 3.6, 3.7 | state which channel produced each novel output |

### 7.3 What is not claimed

The exact statements use identity edge maps; masks and general maps change the Jacobian of a read and break the transport interpretation of Theorem 3.5, whose read is no longer a score. The continuum results are limits, with first-order rates, not finite-layer guarantees. The stochastic stack, $\eta>0$, is observed to converge but is not proved to. The error model of Proposition 5.5 omits error propagation and is tested only empirically. The pilot is exploratory: it uses a transport metric instead of the optimisation outcomes of V2, and it does not settle C3. No statement here concerns search performance.

### 7.4 Open problems

1. **Stochastic stacks.** Prove convergence, with a rate, of the stack with $\eta>0$ to the reverse-time equation of the archive mixture, whose score is known exactly.
2. **Transport with maps.** Find the density, if any, whose score is the sheaf read with masks or rectangular maps, so that Theorem 3.5 extends beyond identity maps.
3. **Propagation-aware schedules.** Weight the curvature density by the composite tangents of Theorem 4.2, and compare with second-order layers that spend two reads per step.
4. **Mode zigzags.** Describe the births and deaths of modes across scales in two and more dimensions as a zigzag module, using the eigenvalue-one crossings of Proposition 4.4.
5. **A stable sensitivity summary.** Find a summary of numerical sensitivity along a tangent diagram that is stable under perturbation and consistent with rank invariants.
6. **C3 in the optimisation setting.** Run the confirmatory C3 protocol of V2, with output loss on the design objective, and add the curvature schedule as a declared comparator.

### 7.5 Conclusion

A stack of ASE layers is a schedule acting on reads. The schedule fixes how outputs mix starting state, reads and noise, and it fixes the noise budget. In the continuum limit the deterministic stack transports the coarse archive density to the fine one, and a clean top turns it into a weighted re-selection of the archive. Tangents never contract below the schedule's own ratio except at the top read, and they expand exactly where the energy has negative curvature, which is also where modes are born, die and change type. Components form a filtration across layers; modes do not, and thresholded ranks do not either. Token paths curve only where the posterior is spread, which tells a schedule where its layers matter. An exploratory pilot refuted hypothesis C3 in all 72 comparisons, because merge radii crowd the fine scales, while a curvature schedule computed from the archive alone was the best of seven at equal numbers of layers. Part IV now turns from the stack to the targets it serves.

## References for Part III

::: {custom-style="Bibliography"}
[1] Anderson, B. D. O. (1982). Reverse-time diffusion equation models. *Stochastic Processes and their Applications* 12(3), 313–326.

[2] Babaud, J., Witkin, A. P., Baudin, M. and Duda, R. O. (1986). Uniqueness of the Gaussian kernel for scale-space filtering. *IEEE Transactions on Pattern Analysis and Machine Intelligence* 8(1), 26–33.

[3] Carlsson, G. (2009). Topology and data. *Bulletin of the American Mathematical Society* 46(2), 255–308.

[4] Carreira-Perpiñán, M. Á. and Williams, C. K. I. (2003a). On the number of modes of a Gaussian mixture. In *Scale Space Methods in Computer Vision*, Lecture Notes in Computer Science 2695, 625–640. Springer.

[5] Carreira-Perpiñán, M. Á. and Williams, C. K. I. (2003b). An isotropic Gaussian mixture can have more modes than components. Technical report EDI-INF-RR-0185, School of Informatics, University of Edinburgh.

[6] Efron, B. (2011). Tweedie's formula and selection bias. *Journal of the American Statistical Association* 106(496), 1602–1614.

[7] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[8] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[9] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[10] Ghosh, D. P. (2026d). *Horizontally Topological, Vertically Algebraic: The Two Axes of Autoregressive Sheaf Evolution. Part I: Sheaves on Covers and Representations of the Layer Order*. 18 October 2026.

[11] Ghosh, D. P. (2026e). *The Horizontal Layer: One Layer of Autoregressive Sheaf Evolution. Part II: Sheaf Attention, Gaussian Stalks, Locality and the Topology of Design Spaces*. 18 October 2026.

[12] Hairer, E., Nørsett, S. P. and Wanner, G. (1993). *Solving Ordinary Differential Equations I: Nonstiff Problems*, 2nd revised edn. Springer Series in Computational Mathematics 8. Springer.

[13] Horn, R. A. and Johnson, C. R. (1991). *Topics in Matrix Analysis*. Cambridge University Press.

[14] Karras, T., Aittala, M., Aila, T. and Laine, S. (2022). Elucidating the design space of diffusion-based generative models. *Advances in Neural Information Processing Systems* 35. arXiv:2206.00364.

[15] Lu, C., Zhou, Y., Bao, F., Chen, J., Li, C. and Zhu, J. (2022). DPM-Solver: a fast ODE solver for diffusion probabilistic model sampling in around 10 steps. *Advances in Neural Information Processing Systems* 35. arXiv:2206.00927.

[16] Milnor, J. W. (1965). *Topology from the Differentiable Viewpoint*. University Press of Virginia.

[17] Silverman, B. W. (1981). Using kernel density estimates to investigate multimodality. *Journal of the Royal Statistical Society, Series B* 43(1), 97–99.

[18] Song, J., Meng, C. and Ermon, S. (2021). Denoising diffusion implicit models. *International Conference on Learning Representations*. arXiv:2010.02502.

[19] Song, Y., Sohl-Dickstein, J., Kingma, D. P., Kumar, A., Ermon, S. and Poole, B. (2021). Score-based generative modeling through stochastic differential equations. *International Conference on Learning Representations*. arXiv:2011.13456.
:::

## Appendix III.A: an immutable C# reference kernel

The kernel computes schedule coefficients from scales or signal levels, the separation weights and the noise budget, runs a stack with identity maps along a given noise path, and multiplies the layer Jacobians into the composite tangent. It also gives the composite's singular values, the product bounds of Theorem 4.2, the volume (4.2), the expanding directions of a layer and the path curvature (5.2). Values are immutable records and functions are pure; the symmetric eigensolver, a cyclic Jacobi method, works on a private copy of its input. The kernel targets .NET 8 and uses only the base class library.

```csharp
// ASE Part III reference kernel: the vertical stack of identity-map layers.
// Immutable values and pure functions; numerical routines use private copies.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AsePartThree;

/// <summary>A dense real matrix stored row-major.</summary>
public sealed record Matrix(int Rows, int Cols, Vec Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Matrix Identity(int n) =>
        new(n, n, Enumerable.Range(0, n * n)
            .Select(k => k / n == k % n ? 1.0 : 0.0).ToImmutableArray());

    public Matrix Transpose() =>
        new(Cols, Rows, Enumerable.Range(0, Rows * Cols)
            .Select(k => this[k % Rows, k / Rows]).ToImmutableArray());

    public Matrix Times(Matrix b) =>
        new(Rows, b.Cols, Enumerable.Range(0, Rows * b.Cols)
            .Select(k => Enumerable.Range(0, Cols)
                .Sum(j => this[k / b.Cols, j] * b[j, k % b.Cols]))
            .ToImmutableArray());

    public Matrix Combine(double a, Matrix b, double c) =>
        this with { Data = Data.Zip(b.Data, (p, q) => a * p + c * q)
                               .ToImmutableArray() };

    /// <summary>Eigenvalues (ascending) of a symmetric matrix, by cyclic
    /// Jacobi rotations on a private copy.</summary>
    public Vec SymmetricEigenvalues()
    {
        int n = Rows;
        var a = Data.ToArray();
        for (int sweep = 0; sweep < 100; sweep++)
        {
            double off = 0.0;
            for (int p = 0; p < n; p++)
                for (int q = p + 1; q < n; q++) off += a[p * n + q] * a[p * n + q];
            if (off < 1e-300) break;
            for (int p = 0; p < n - 1; p++)
                for (int q = p + 1; q < n; q++)
                {
                    double apq = a[p * n + q];
                    if (apq == 0.0) continue;
                    double th = (a[q * n + q] - a[p * n + p]) / (2.0 * apq);
                    double t = th == 0.0 ? 1.0
                        : Math.Sign(th) / (Math.Abs(th) + Math.Sqrt(th * th + 1.0));
                    double c = 1.0 / Math.Sqrt(t * t + 1.0), s = t * c;
                    for (int k = 0; k < n; k++)
                        (a[k * n + p], a[k * n + q]) =
                            (c * a[k * n + p] - s * a[k * n + q],
                             s * a[k * n + p] + c * a[k * n + q]);
                    for (int k = 0; k < n; k++)
                        (a[p * n + k], a[q * n + k]) =
                            (c * a[p * n + k] - s * a[q * n + k],
                             s * a[p * n + k] + c * a[q * n + k]);
                }
        }
        return Enumerable.Range(0, n).Select(i => a[i * n + i]).OrderBy(v => v)
                         .ToImmutableArray();
    }
}

/// <summary>Scales s_0 (top, possibly 0) &lt; s_1 &lt; ... &lt; s_T and the
/// noise parameter eta in [0, 1]. Index t of the derived arrays is layer t;
/// entry 0 is unused.</summary>
public sealed record Schedule(Vec Scales, double Eta)
{
    public int Layers => Scales.Length - 1;

    /// <summary>Signal levels a_0 &gt;= ... &gt;= a_T to s_t = sqrt((1-a_t)/a_t).
    /// </summary>
    public static Schedule FromLevels(Vec levels, double eta) =>
        new(levels.Select(a => Math.Sqrt((1 - a) / a)).ToImmutableArray(), eta);

    double Gamma2(int t)
    {
        double lo = Scales[t - 1], hi = Scales[t];
        return Eta * Eta * lo * lo * (hi * hi - lo * lo) / (hi * hi);
    }

    public Vec NoiseStd => Enumerable.Range(0, Layers + 1)
        .Select(t => t == 0 ? 0.0 : Math.Sqrt(Gamma2(t))).ToImmutableArray();

    public Vec Lambda => Enumerable.Range(0, Layers + 1)
        .Select(t => t == 0 ? 0.0
            : 1 - Math.Sqrt(Math.Max(Scales[t - 1] * Scales[t - 1] - Gamma2(t), 0))
                  / Scales[t])
        .ToImmutableArray();

    /// <summary>pi_t, omega_t = lambda_t pi_t and omega_* (V2 Theorem 7.1).
    /// </summary>
    public (Vec Pi, Vec Omega, double OmegaStar) Separation()
    {
        var lam = Lambda;
        var pi = Enumerable.Range(0, Layers + 1)
            .Select(t => t == 0 ? 0.0
                : Enumerable.Range(1, t - 1)
                    .Aggregate(1.0, (p, u) => p * (1 - lam[u])))
            .ToImmutableArray();
        var omega = pi.Select((p, t) => lam[t] * p).ToImmutableArray();
        double star = Enumerable.Range(1, Layers)
            .Aggregate(1.0, (p, u) => p * (1 - lam[u]));
        return (pi, omega, star);
    }

    /// <summary>The explicit noise variance sum_t pi_t^2 gamma_t^2 and its
    /// closed form s_0^2 - omega_*^2 s_T^2 (Theorem 3.2).</summary>
    public (double Sum, double ClosedForm) NoiseBudget()
    {
        var (pi, _, star) = Separation();
        var sig = NoiseStd;
        double sum = Enumerable.Range(1, Layers)
            .Sum(t => pi[t] * pi[t] * sig[t] * sig[t]);
        double sT = Scales[Layers];
        return (sum, Scales[0] * Scales[0] - star * star * sT * sT);
    }
}

/// <summary>Records y_i with log prior weights; identity edge maps.</summary>
public sealed record Archive(ImmutableArray<Vec> Records, Vec LogWeights);

/// <summary>Posterior weights, read m = sum alpha_i y_i and covariance C.</summary>
public sealed record Read(Vec Weights, Vec Mean, Matrix Covariance);

/// <summary>One layer of a realised path: the state it received, its read and
/// its Jacobian (1 - lambda) I + lambda C / s^2.</summary>
public sealed record LayerStep(int Layer, Vec State, Read Read, Matrix Jacobian);

public sealed record StackRun(Vec Output, ImmutableArray<LayerStep> Steps,
                              Matrix Composite);

public static class Reads
{
    public static Read At(Vec z, Archive a, double s)
    {
        var l = a.Records.Select((y, i) => a.LogWeights[i]
            - y.Zip(z, (p, q) => (p - q) * (p - q)).Sum() / (2 * s * s)).ToArray();
        double peak = l.Max();
        var w = l.Select(v => Math.Exp(v - peak)).ToArray();
        var alpha = w.Select(v => v / w.Sum()).ToImmutableArray();
        int d = z.Length;
        var m = Enumerable.Range(0, d)
            .Select(j => a.Records.Select((y, i) => alpha[i] * y[j]).Sum())
            .ToImmutableArray();
        var cov = Enumerable.Range(0, d * d)
            .Select(k => a.Records.Select((y, i) =>
                alpha[i] * (y[k / d] - m[k / d]) * (y[k % d] - m[k % d])).Sum())
            .ToImmutableArray();
        return new Read(alpha, m, new Matrix(d, d, cov));
    }
}

public static class Stack
{
    /// <summary>Runs z_{t-1} = (1 - lambda_t) z_t + lambda_t m_t + gamma_t xi_t
    /// from t = T to 1, with noise[t - 1] for layer t, and multiplies the layer
    /// Jacobians along the realised path.</summary>
    public static StackRun Run(Vec zT, Archive a, Schedule sch,
                               ImmutableArray<Vec> noise)
    {
        var lam = sch.Lambda;
        var sig = sch.NoiseStd;
        int d = zT.Length;
        var init = (z: zT, steps: ImmutableArray<LayerStep>.Empty,
                    k: Matrix.Identity(d));
        var final = Enumerable.Range(1, sch.Layers).Reverse().Aggregate(init,
            (acc, t) =>
            {
                double s = sch.Scales[t];
                var read = Reads.At(acc.z, a, s);
                var jac = Matrix.Identity(d).Combine(1 - lam[t], read.Covariance,
                                                     lam[t] / (s * s));
                var next = Enumerable.Range(0, d)
                    .Select(j => (1 - lam[t]) * acc.z[j] + lam[t] * read.Mean[j]
                                 + (sig[t] > 0 ? sig[t] * noise[t - 1][j] : 0.0))
                    .ToImmutableArray();
                return (next, acc.steps.Add(new LayerStep(t, acc.z, read, jac)),
                        jac.Times(acc.k));
            });
        return new StackRun(final.z, final.steps, final.k);
    }

    /// <summary>The right side of the separation identity, recomputed from the
    /// recorded reads: omega_* z_T + sum omega_t m_t + sum pi_t gamma_t xi_t.
    /// </summary>
    public static Vec Separate(Vec zT, StackRun run, Schedule sch,
                               ImmutableArray<Vec> noise)
    {
        var (pi, omega, star) = sch.Separation();
        var sig = sch.NoiseStd;
        return Enumerable.Range(0, zT.Length)
            .Select(j => star * zT[j]
                + run.Steps.Sum(st => omega[st.Layer] * st.Read.Mean[j]
                    + (sig[st.Layer] > 0
                        ? pi[st.Layer] * sig[st.Layer] * noise[st.Layer - 1][j]
                        : 0.0)))
            .ToImmutableArray();
    }
}

public static class Tangent
{
    /// <summary>Singular values, descending, from the eigenvalues of K^T K.
    /// </summary>
    public static Vec SingularValues(Matrix k) =>
        k.Transpose().Times(k).SymmetricEigenvalues()
         .Select(v => Math.Sqrt(Math.Max(v, 0))).Reverse().ToImmutableArray();

    /// <summary>Products of the smallest and largest layer eigenvalues, which
    /// bracket every singular value of the composite (Theorem 4.2).</summary>
    public static (double Floor, double Ceiling) ProductBounds(StackRun run) =>
        run.Steps.Aggregate((f: 1.0, c: 1.0), (acc, st) =>
        {
            var ev = st.Jacobian.SymmetricEigenvalues();
            return (acc.f * ev[0], acc.c * ev[ev.Length - 1]);
        });

    /// <summary>log |det K| as a sum over layers and eigenvalues (4.2).</summary>
    public static double LogVolume(StackRun run) =>
        run.Steps.Sum(st => st.Jacobian.SymmetricEigenvalues()
                                .Sum(v => Math.Log(Math.Abs(v))));

    /// <summary>Directions a layer expands: eigenvalues of C / s^2 above one.
    /// At a stationary point this is the Morse index of E_s (Proposition 4.4).
    /// </summary>
    public static int ExpandingDirections(Matrix covariance, double s,
                                          double tol = 1e-9) =>
        covariance.SymmetricEigenvalues().Count(v => v / (s * s) > 1 + tol);

    /// <summary>Path curvature z'' = (C (z - m) - M_3) / s^4 along the
    /// probability-flow ODE (5.2).</summary>
    public static Vec PathCurvature(Vec z, Archive a, double s)
    {
        var r = Reads.At(z, a, s);
        int d = z.Length;
        var dz = z.Zip(r.Mean, (p, q) => p - q).ToImmutableArray();
        return Enumerable.Range(0, d).Select(j =>
        {
            double cz = Enumerable.Range(0, d)
                .Sum(k => r.Covariance[j, k] * dz[k]);
            double m3 = a.Records.Select((y, i) => r.Weights[i]
                * y.Zip(r.Mean, (p, q) => (p - q) * (p - q)).Sum()
                * (y[j] - r.Mean[j])).Sum();
            return (cz - m3) / Math.Pow(s, 4);
        }).ToImmutableArray();
    }
}
```

A driver program prints the coefficients, weights and noise budget of a five-layer schedule with $\eta=0.5$, and the cosine weights of Corollary 3.3. On five records in $ℝ^2$ it prints a noisy path with its separation residual, a deterministic path with its composite tangent, bounds and volume, and a clean-top path with the lower bounds of Corollary 4.3. It ends with the expanding directions at the midpoint of two records below and above the pitchfork, and one path curvature. An independent NumPy script recomputes every printed number (Table A1). Of the 18 lines, 16 are identical to 15 significant digits, and the largest relative difference is 7.5 × 10⁻¹⁵.

Table: **Table A1.** C# kernel output against the NumPy recomputation.

| C# | NumPy | Agreement |
|:------------------|:------------------|:----------|
| `lambda 0.478892027150869 0.466937550707538 0.450090916605299 0.461996131298747 0.483655715870616` | `lambda 0.478892027150869 0.466937550707538 0.450090916605299 0.461996131298747 0.483655715870616` | identical |
| `noise_std 0.082065180664829 0.142140750861797 0.24 0.404344914260809 0.700355068677469` | `noise_std 0.082065180664829 0.142140750861797 0.24 0.404344914260809 0.700355068677469` | identical |
| `omega 0.478892027150869 0.243324880496343 0.125027646654521 0.0705724249474152 0.0397482877336629` | `omega 0.478892027150869 0.243324880496343 0.125027646654521 0.0705724249474152 0.0397482877336629` | identical |
| `omega_star 0.0424347330171889` | `omega_star 0.0424347330171889` | identical |
| `noise_budget 0.0237936409038391 0.0237936409038391` | `noise_budget 0.0237936409038391 0.0237936409038391` | identical |
| `cosine_weights_in_z1 0.504850278267635 0.170467077485452 0.0869033624848896 0.0535148263882985 0.184264455373725` | `cosine_weights_in_z1 0.504850278267632 0.170467077485453 0.0869033624848901 0.0535148263882989 0.184264455373726` | 7.5 × 10⁻¹⁵ |
| `noisy_output 1.13486043021531 0.29740584091565` | `noisy_output 1.13486043021531 0.297405840915649` | 3.4 × 10⁻¹⁵ |
| `separation_residual 5.55111512312578E-⁠17` | `separation_residual 5.55111512312578e-⁠17` | identical |
| `det_output 1.03022772158288 0.211688570761887` | `det_output 1.03022772158288 0.211688570761887` | identical |
| `singular_values 0.152079322795113 0.0948754910152018` | `singular_values 0.152079322795113 0.0948754910152018` | identical |
| `product_bounds 0.0932892365787706 0.154665221333038` | `product_bounds 0.0932892365787706 0.154665221333038` | identical |
| `schedule_floor 0.0666666666666667` | `schedule_floor 0.0666666666666667` | identical |
| `log_volume -⁠4.23854290165247 -⁠4.23854290165247` | `log_volume -⁠4.23854290165247 -⁠4.23854290165247` | identical |
| `clean_output 0.999991163357577 0.200002938121634` | `clean_output 0.999991163357577 0.200002938121634` | identical |
| `clean_singular_values 2.15271154910683E-⁠05 7.14070985730758E-⁠06` | `clean_singular_values 2.15271154910683e-⁠05 7.14070985730758e-⁠06` | identical |
| `clean_lower 8.12315543324309E-⁠06 3.58566573690938E-⁠06` | `clean_lower 8.12315543324309e-⁠06 3.58566573690938e-⁠06` | identical |
| `expanding 1 0` | `expanding 1 0` | identical |
| `curvature 0.782418601066224 -⁠0.523414726301979` | `curvature 0.782418601066224 -⁠0.523414726301979` | identical |

## Appendix III.B: reproducibility

All results were produced with Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1, Matplotlib 3.11.2 and .NET SDK 8.0.131. The script `p3_checks.py` runs the 18 main checks with seed 20261022 and writes `p3_checks.json`. The script `p3_extras.py` runs the 3 supplementary checks, including the replay of Part I's experiment from its own random stream, and writes `p3_extras.json`. The script `p3_explore.py` runs the pilot of Section 5.3 with seed 20261024 and writes `p3_explore.json`. The shared primitives are in `p3_core.py`. The script `fig_p3.py` draws the figures; panels marked as recomputed use their own fixed seeds, and all other plotted values are read from the result files. The C# project in `cs/` builds the kernel and its driver, and `cs_validate.py` compares the driver's output with NumPy and writes `cs_validate.json`. The document is assembled by `render.py`, which reads every quoted number from these files, converted to Word by Pandoc and post-processed for equation layout and schema order. A code archive accompanies this paper.


# Part IV · Targets and Estimation

::: {custom-style="Subtitle"}
What Autoregressive Sheaf Evolution can estimate. Part IV: Gibbs targets, proposal laws, importance weights and error budgets
:::

**Summary of Part IV.** Parts I to III of Autoregressive Sheaf Evolution (ASE) described what a layer stack computes. This paper, Part IV of the book, asks what it can estimate. The target is a Gibbs law $\pi_\beta\propto\rho\,e^{-\beta J}$ on designs, with a declared base law $\rho$ and loss $J$. A weighted archive estimates only the smoothed target $\pi_\beta*N(0,s^2I)$, and only as fast as its weights allow: in a two-dimensional double well, 40 records had an effective size of 2.7 and missed the target by 0.61 in total variation at the best width. The archive should therefore be a proposal, not a target. We prove that a clean-top stack cannot be one. Its outputs lie in the convex hull of the records it reads. When those records span fewer than $D$ dimensions, its law is singular and no importance weight exists. Reading the 8 best of 40 records left 79.5% of the target outside the hull. The archive density $p_s$ itself is exactly samplable with a known density, so estimation should draw from it directly rather than run a finite stack. For Gaussian mixtures, the second moment of the importance weights is finite when the width exceeds $\sigma/\sqrt2$, for the narrowest Gaussian direction $\sigma$ of the target, and infinite when it is below. A defensive component removes the infinity with the bound $1/(\varepsilon Z)$. Bounded critic error $\varepsilon$ moves the target by at most $\tanh(\beta\varepsilon/2)$ in total variation, and the bound is attained. Heteroscedastic Gaussian critic noise tilts the target by $e^{\beta^2\sigma(x)^2/2k}$; homoscedastic noise does not. Truncated proposal densities obey the same lemma with their log ratio. An error ledger combines these terms with the finite-sample bound of Agapiou and co-authors. In 9 configurations it was never exceeded, and it showed the error settling at the critic bias, not at the sampling error. There are 16 numerical checks and a width exploration, and an immutable C# kernel matches an independent NumPy implementation on every output line.

## 1 Introduction

Autoregressive Diffusion Evolution (ADE) proposes designs by running tokens down a denoising stack whose layers read an archive of evaluated designs [7, 8]. Autoregressive Sheaf Evolution (ASE) generalises each read to an observation star with edge maps and scale-dependent covers [9]. Part I separated the two axes of the stack [10]. Part II worked out one layer [11]. Part III stacked the layers and identified the law of the proposals: in the continuum limit, a deterministic stack with identity maps proposes from the archive density $p_{s_0}$, and a clean top re-selects archived records [12]. This paper, Part IV of the book, turns from the stack to the targets it serves. It asks which law a run is meant to sample, what an archive estimates, which proposals can be importance-weighted, and how errors in the critic and in the proposal density enter an estimate.

The questions matter because ADE and ASE are search procedures that are easily read as samplers. An archive weighted by $e^{-\beta J}$ looks like a sample from a Gibbs law, and a stack that transports one density to another looks like a generative model. Neither reading is automatic. Each needs a declared target, a proposal with a known density and full support, and an account of every source of error. Part IV supplies these for the identity-map geometry, and it records where the archive and the stack fail as estimators.

### 1.1 Contributions

- **Targets (Section 2).** We fix the Gibbs target $\pi_\beta\propto\rho\,e^{-\beta J}$ with a declared base law $\rho$. A weighted archive converges to the smoothed target $\pi_\beta*N(0,s^2I)$, not to $\pi_\beta$ (Proposition 2.3). Smoothing and a small effective archive size together make the archive a poor estimator of the target, so ASE should treat it as a proposal.
- **Proposals (Section 3).** A clean-top stack proposes only inside the convex hull of the records it reads. Its law is singular when they span fewer than $D$ dimensions, so it cannot be importance-weighted (Theorem 3.1). The archive density $p_s$ is exactly samplable with an explicit density (Proposition 3.2). For Gaussian mixtures we give the width threshold below which the weights have infinite second moment, whatever the records (Proposition 3.4). Defensive mixtures remove that infinity at a bounded cost (Theorem 3.5). A width scan on a double well locates the best proposal and compares it with the base law.
- **Critic and density error (Section 4).** One lemma covers every multiplicative weight error: if the log error spans an interval of width $\kappa$, the limiting law moves by at most $\tanh(\kappa/4)$ in total variation, and the bound is attained (Lemma 4.1). It gives the effect of bounded critic error (Proposition 4.2) and of truncated proposal densities (Proposition 4.4). Gaussian critic noise tilts the target exactly when it is heteroscedastic (Proposition 4.3).
- **An error ledger (Section 5).** Theorem 5.1 bounds the root-mean-square error of a self-normalised estimate by a critic term that does not shrink and a sampling term that does. It tells a run when to spend evaluations on the critic rather than on more samples.
- **Evidence.** There are 16 numerical checks besides the width exploration (Table 3). An immutable C# kernel agrees with an independent NumPy implementation on every output line (Appendix A).

### 1.2 Scope and status of statements

Statements use identity edge maps unless they say otherwise, and Gaussian components of a common width. Masks and general maps change the hull in which reads lie (Part II, Proposition 3.5), and Section 6.3 says what that does to the results. The paper proves statements about estimation; it makes no claim about search performance. The width exploration of Section 3.4 is a computation on one declared example, not a benchmark.

Every statement in a shaded box ends with a provenance tag. *Classical* marks a known result restated in ASE notation. *Part I*, *Part II* and *Part III* refer to [10], [11] and [12]. *New in Part IV* marks a statement proved here for the first time in this programme; each comes with a proof and a numerical check. All spaces are finite-dimensional and real, and all densities are with respect to Lebesgue measure.

### 1.3 Notation

Table: **Table 1.** Notation used throughout Part IV.

| Symbol | Meaning |
|:--------------------------|:--------------------------------------------------|
| $J\ge0,\ \rho,\ \beta$ | loss of a design, declared base law, inverse temperature |
| $\pi_\beta,\ Z$ | Gibbs target $\rho e^{-\beta J}/Z$ and its normaliser (Definition 2.1) |
| $y_i,\ w_i$ | archived records and their weights |
| $p_s$ | archive density $\sum_i\beta_iN(y_i,s^2I)$, $\beta_i=w_i/\sum_jw_j$ |
| $\varphi_s$ | the density of $N(0,s^2I)$ |
| $q,\ q_\varepsilon$ | proposal density and defensive mixture $(1-\varepsilon)q+\varepsilon\rho$ |
| $m_2(q)$ | second moment $E_q[(\pi_\beta/q)^2]=1+\chi^2(\pi_\beta\Vert q)$ |
| $\hat I_n(f)$ | self-normalised importance-sampling estimate from $n$ draws |
| $\text{TV}$ | total-variation distance |
| $\kappa$ | log-width of a multiplicative weight error (Lemma 4.1) |


## 2 Targets

### 2.1 The Gibbs target

ADE weights records by $e^{-\beta J}$ and calls the result a selection pressure [7]. A selection pressure is not yet a target. To estimate anything, a run must name the law it is estimating and the reference against which $e^{-\beta J}$ is a density.

::: {custom-style="Statement"}
**Definition 2.1** (Gibbs target). Let $J\ge0$ be a measurable loss on $ℝ^D$ and $\rho$ a declared probability density on $ℝ^D$, the base law. For $\beta>0$ with $Z=\int\rho\,e^{-\beta J}\,\text{d}x$, the *Gibbs target* is $\pi_\beta=\rho\,e^{-\beta J}/Z$. A run *estimates* $E_{\pi_\beta}f$ for declared test functions $f$.
:::

::: {custom-style="Statement Tag"}
Classical; the base law is the Mathematics book's reference measure [8], made explicit.
:::

::: {custom-style="Gap"}
&nbsp;
:::

The base law is a modelling choice with consequences. With $\rho$ uniform on a box, the target is the familiar Boltzmann law of the loss; with a Gaussian $\rho$, it is a posterior whose prior is $\rho$ and whose likelihood is $e^{-\beta J}$. Two runs with different $\rho$ estimate different targets, even with the same loss and temperature.

**The running example.** Throughout, $D=2$, $J(x)=(x_1^2-1)^2+\tfrac12x_2^2$, $\rho=N(0,4I)$ and $\beta=4$. The target has two modes, near $x_1=\pm1$, and it factorises: its $x_2$ factor is $N(0,\sigma^2)$ with $\sigma^2=1/(2(1/8+2))$, so $\sigma=0.485$. Quadrature on a grid of $961\times961$ points over $[-6,6]^2$ gives $Z=0.04093$, $E\,x_1^2=0.9004$ and $P(x_1>0.5)=0.4763$. The archive has 40 records drawn from $\rho$ and weighted by $e^{-\beta J}$, as Proposition 2.3 prescribes for records drawn from the base law.

### 2.2 What a weighted archive estimates

::: {custom-style="Statement"}
**Definition 2.2** (archive density). For records $y_1,\ldots,y_n$ with weights $w_i>0$ and a width $s>0$, the archive density is $p_s=\sum_i\beta_i\varphi_s(\cdot-y_i)$ with $\beta_i=w_i/\sum_jw_j$. Its effective size is $n_{\text{eff}}=(\sum_iw_i)^2/\sum_iw_i^2$.
:::

::: {custom-style="Statement Tag"}
Part III, Definition 2.1; the effective size is Kong's [4].
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Proposition 2.3** (a weighted archive estimates the smoothed target). Let $y_1,y_2,\ldots$ be independent draws from a density $q$ that is positive wherever $\rho$ is, and let $w_i=\rho(y_i)e^{-\beta J(y_i)}/q(y_i)$. Then for every $s>0$ and every $x$, almost surely,
:::

::: {custom-style="Statement Equation"}
$p_s(x)\to(\pi_\beta*\varphi_s)(x)\qquad\text{as }n\to\infty$ (2.1)
:::

::: {custom-style="Statement"}
For $D=1$, $\rho=N(0,1)$ and $J(x)=x^2/2$, the limit is the density of $N(0,1/(1+\beta)+s^2)$.
:::

::: {custom-style="Statement Tag"}
Classical, the strong law for self-normalised importance weights [16] applied to a kernel estimate [15].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* By the strong law, $n^{-1}\sum_iw_i\varphi_s(x-y_i)\to\int q\,(\rho e^{-\beta J}/q)\,\varphi_s(x-\cdot)=Z\,(\pi_\beta*\varphi_s)(x)$ and $n^{-1}\sum_iw_i\to Z>0$. Take the ratio. In the Gaussian case $\pi_\beta=N(0,1/(1+\beta))$, and convolution with $\varphi_s$ adds $s^2$ to the variance. ∎

::: {custom-style="Check"}
*Numerical check.* In the Gaussian case with $\beta=1$ and 400,000 records, the archive density matched the limit at nine points in $[-2,2]$ to a largest relative error of 0.0148, 0.0101 and 0.0024 for $s=0.1$, 0.3 and 1.
:::

So an archive used as a target carries two errors: the smoothing bias of $\varphi_s$, which shrinks with $s$, and the sampling error of the weights, which grows as $s$ shrinks and is governed by $n_{\text{eff}}$, not by $n$. Selection makes the second error severe. The 40 records of the running example have $n_{\text{eff}}=2.7$. As a target, their archive density was off by 0.61 to 0.95 in total variation for widths from 0.05 to 1. It put the probability of $x_1>0.5$ between 0.65 and 0.85, against 0.476. With 4,000 records from the same base law the total variation fell to 0.19, and the probability estimates to 0.455 and 0.471 at widths 0.2 and 0.05. An archive is a record of what was evaluated, shaped by selection. The rest of this paper therefore uses it as a proposal and corrects it with fresh evaluations of $J$.


## 3 Proposals

### 3.1 A clean top cannot propose for estimation

::: {custom-style="Statement"}
**Theorem 3.1** (support of clean-top proposals). Use identity maps and a clean top, $s_0=0$, with any noise parameter and any number of layers. Let $H$ be the convex hull of the records read at the top layer.
:::

::: {custom-style="Statement"}
\(i) Every output lies in $H$.
:::

::: {custom-style="Statement"}
\(ii) If the records read at the top span an affine subspace of dimension less than $D$, the law of the output is concentrated on a Lebesgue-null set. It is singular with respect to $\pi_\beta$, and no importance weight $\text{d}\pi_\beta/\text{d}\mu$ exists.
:::

::: {custom-style="Statement"}
\(iii) For every law $\mu$ supported on $H$, $\text{TV}(\mu,\pi_\beta)\ge\pi_\beta(H^{\text{c}})$, where $H^{\text{c}}$ is the complement of $H$. No reweighting of clean-top outputs can estimate $E_{\pi_\beta}f$ for all bounded $f$ to better than this.
:::

::: {custom-style="Statement Tag"}
\(i) Part III, Proposition 3.6(i); (ii) and (iii) New in Part IV.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (i) At a clean top the output is the read $m_1(z_1)$, a convex combination of the records read there. (ii) The output lies in the affine span of those records, a proper affine subspace, which has Lebesgue measure zero. $\pi_\beta$ has a density, so it gives that set measure zero, while $\mu$ gives it measure one. (iii) Take the set $H^{\text{c}}$: $\mu$ gives it measure zero and $\pi_\beta$ gives it $\pi_\beta(H^{\text{c}})$. ∎

ADE practice reads an elite subset of the archive at the finest layers. Theorem 3.1 says what that costs an estimator (Figure 1). In the running example, the convex hull of all 40 records misses less than $10^{-8}$ of the target. The hull of the 16 best records misses 0.19 of it, and the hull of the 8 best misses 0.795. All 8 of those records lie near the right-hand mode, so inside their hull the probability of $x_1>0.5$ is 0.952, against 0.476 overall. With 4 records the hull is still a polygon of positive area in $ℝ^2$. In higher dimensions, fewer than $D+1$ elite records make the law singular.

::: {custom-style="Check"}
*Numerical check.* For 200 random stacks in $ℝ^5$ reading four records, with random noise parameters, nine geometric layers and a clean top, every output lay in the affine span of the records to within 2.1 × 10⁻¹⁴. Target masses outside the hulls in the running example were computed by quadrature: 0.797, 0.795, 0.189 and 4.4 × 10⁻⁹ for the 4, 8, 16 and 40 best records.
:::

![**Figure 1.** (a) The double-well target, its 40 records and their convex hull. (b) The 8 records with the largest weights, all near the right-hand mode, and their hull. (c) The target mass outside the hull of the $k$ best records, which a clean top that reads only those records can never propose (Theorem 3.1).](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p4/fig/support.png){width=100%}

### 3.2 The archive density is an exact proposal

::: {custom-style="Statement"}
**Proposition 3.2** (exact proposals). Draw an index $I$ with $P(I=i)=\beta_i$ and set $x=y_I+s\,\xi$ with $\xi\sim N(0,I)$. Then $x$ has the law $p_s$ exactly, and its density is computable at every point. A deterministic stack with identity maps, started from $p_{s_T}$, has the law $p_{s_0}$ only in the continuum limit; for a finite stack the output density is not available in closed form.
:::

::: {custom-style="Statement Tag"}
The sampler is classical; the comparison with the stack uses Part III, Theorem 3.5.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* The first statement is the definition of a mixture. The second is Part III, Theorem 3.5(iv), which gives convergence of laws as the largest step tends to zero, and no finite-step identity. ∎

So for estimation the stack is not needed. Its proposal law is, at best, a law that can be sampled exactly and more cheaply by Proposition 3.2. The stack's value lies elsewhere: it carries a particular query to a particular output, the property used for search, recombination and the sensitivities of Part III. An estimator built on stack outputs must either take the continuum limit on trust or estimate a density it does not have. Part IV takes the direct route.

::: {custom-style="Check"}
*Numerical check.* For the six weighted records of Part III, Figure 2, with $s_0=0.3$ and $s_T=20$, 40,000 direct draws had a Kolmogorov–Smirnov distance of 0.0071 to an independent sample of $p_{s_0}$. The 95% critical value is 0.0096. Deterministic geometric stacks with 4, 16 and 64 layers, started from 40,000 draws of $p_{s_T}$, gave 0.101, 0.030 and 0.012. Even at 64 layers the finite stack is still detectably different from its limit.
:::

### 3.3 When the importance weights have finite variance

The cost of importance sampling is governed by the second moment $m_2(q)=E_q[(\pi_\beta/q)^2]$ [1, 2]. Its reciprocal approximates the fraction of draws that count, the effective-sample fraction of Kong [4].

::: {custom-style="Statement"}
**Proposition 3.3** (Gaussian second moment). For $\pi=N(\mu,\Sigma)$ and $q=N(\mu,S)$,
:::

::: {custom-style="Statement Equation"}
$m_2(q)=\frac{\text{det}\,S}{\sqrt{\text{det}\,\Sigma\ \text{det}(2S-\Sigma)}}\quad\text{if }2S\succ\Sigma,\qquad m_2(q)=\infty\text{ otherwise.}$ (3.1)
:::

::: {custom-style="Statement"}
For $\Sigma=\sigma^2I$ and $S=r^2\sigma^2I$ in $ℝ^D$, $m_2=\left(r^2/\sqrt{2r^2-1}\right)^D$ for $r>1/\sqrt2$, which exceeds one for every $r\ne1$.
:::

::: {custom-style="Statement Tag"}
Classical [1, 16].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* $m_2=\int N(\mu,\Sigma)^2/N(\mu,S)$ is a Gaussian integral whose quadratic form is $x^{\top}(2\Sigma^{-1}-S^{-1})x$. It converges exactly when $2\Sigma^{-1}\succ S^{-1}$, that is $2S\succ\Sigma$, and then evaluates to (3.1). The isotropic form follows by taking determinants. ∎

A proposal that is 1.5 times too wide in every coordinate therefore keeps a fraction $0.831^D$ of its draws: 0.83 in one dimension, 0.052 in 16 and 0.0027 in 32 (Figure 2b). Width errors compound across coordinates. A proposal that is too narrow by a factor $\sqrt2$ or more has infinite variance in every dimension.

::: {custom-style="Check"}
*Numerical check.* With two million draws, Monte Carlo estimates of $\chi^2$ were 0.2030, 0.2031, 1.181 and 0.2011 against the closed forms 0.2027, 0.2095, 1.183 and 0.2095 for $(\sigma,r\sigma)=(1,1.5)$, $(1,0.8)$, $(1,3)$ and $(2,1.6)$. The two narrow cases converge slowly, because their squared weights have infinite variance even though $m_2$ is finite.
:::

The archive density is a Gaussian mixture, not a Gaussian. The same threshold survives.

::: {custom-style="Statement"}
**Proposition 3.4** (width threshold for archive mixtures). Suppose the target factorises as $\pi(x)=\pi_1(u)\,N(v;0,\sigma^2)$ with $x=(u,v)$, $u\in ℝ^{D-1}$, and $\int\pi_1(u)^2e^{\Vert u-a\Vert^2/2s^2}\text{d}u<\infty$ for every $a$. Let $q=\sum_i\beta_i\varphi_s(\cdot-y_i)$ with every $\beta_i>0$. Then
:::

::: {custom-style="Statement Equation"}
$m_2(q)<\infty\ \text{if}\ s>\sigma/\sqrt2,\qquad m_2(q)=\infty\ \text{if}\ s<\sigma/\sqrt2$ (3.2)
:::

::: {custom-style="Statement"}
whatever the records and their weights are. At $s=\sigma/\sqrt2$ the answer depends on the records.
:::

::: {custom-style="Statement Tag"}
New in Part IV.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* If $s>\sigma/\sqrt2$, use $q\ge\beta_1\varphi_s(\cdot-y_1)$. Then $\pi^2/q$ is bounded by a constant times $\pi_1(u)^2e^{\Vert u-a\Vert^2/2s^2}$ times $e^{-v^2/\sigma^2+(v-b)^2/2s^2}$, where $(a,b)=y_1$. The first factor is integrable by hypothesis, and the second is integrable because $1/\sigma^2>1/2s^2$. If $s<\sigma/\sqrt2$, bound every component of $q$ by $(2\pi s^2)^{-D/2}e^{-(v-b_i)^2/2s^2}$. For $|v|$ larger than every $|b_i|$, $q$ is then at most a constant times $e^{-(|v|-b)^2/2s^2}$ with $b=\max_i|b_i|$. The $v$-integral of $e^{-v^2/\sigma^2+(|v|-b)^2/2s^2}$ diverges because $1/2s^2>1/\sigma^2$, and $\int\pi_1^2>0$. ∎

In the running example $\sigma=0.485$, so every archive proposal with $s<0.343$ has infinite-variance weights, however many records it has and wherever they are. The quadrature of Section 3.4 shows the consequence. Near the threshold, $m_2$ rises steeply: 35.6 at $s=0.367$, against 9.5 at the best width. Below it, finite-sample estimates are erratic.

::: {custom-style="Statement"}
**Theorem 3.5** (defensive mixtures). Let $q_\varepsilon=(1-\varepsilon)q+\varepsilon\rho$ with $0<\varepsilon<1$. Then every weight satisfies $\pi_\beta/q_\varepsilon\le1/(\varepsilon Z)$, and
:::

::: {custom-style="Statement Equation"}
$m_2(q_\varepsilon)\le\min\left\{\frac{m_2(q)}{1-\varepsilon},\ \frac{m_2(\rho)}{\varepsilon},\ \frac{1}{\varepsilon Z}\right\}$ (3.3)
:::

::: {custom-style="Statement Tag"}
Classical in substance, Hesterberg's defensive mixture [3] and Owen and Zhou [5]; the form with a Gibbs target uses $J\ge0$.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* $q_\varepsilon\ge(1-\varepsilon)q$ and $q_\varepsilon\ge\varepsilon\rho$, so $\pi/q_\varepsilon$ is at most $\pi/((1-\varepsilon)q)$ and at most $\pi/(\varepsilon\rho)=e^{-\beta J}/(\varepsilon Z)\le1/(\varepsilon Z)$. Multiply each bound by $\pi/q_\varepsilon$ and integrate against $q_\varepsilon$; for the last bound use $m_2(q_\varepsilon)=\int\pi\,(\pi/q_\varepsilon)$. ∎

A defensive component costs at most the factor $1/(1-\varepsilon)$ where the archive proposal is good. It caps the weights everywhere, including below the threshold of Proposition 3.4. The cap needs $J\ge0$, or a known lower bound of $J$ subtracted from it.

::: {custom-style="Statement"}
**Theorem 3.6** (finite-sample bounds). If $\pi_\beta$ has a density with respect to $q$ and $m_2(q)<\infty$, the self-normalised estimate from $n$ independent draws of $q$ satisfies, for every $f$ with $|f|\le1$,
:::

::: {custom-style="Statement Equation"}
$\left|E\,\hat I_n(f)-E_{\pi_\beta}f\right|\le\frac{12\,m_2(q)}{n},\qquad E\left(\hat I_n(f)-E_{\pi_\beta}f\right)^2\le\frac{4\,m_2(q)}{n}$ (3.4)
:::

::: {custom-style="Statement Tag"}
Classical, Agapiou, Papaspiliopoulos, Sanz-Alonso and Stuart [1, Theorem 2.1].
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* Over the 40 widths of Section 3.4, the largest weight of each defensive mixture never exceeded $1/(\varepsilon Z)$, which is 244.3 for $\varepsilon=0.1$ and 81.4 for $\varepsilon=0.3$, and (3.3) had 0 violations. For $P(x_1>0.5)$ at the best width, $s=1.17$, 2,000 and 1,000 replications gave mean squared errors of 0.0234 and 0.00214 for $n=100$ and 1,000, against the bounds 0.380 and 0.0380 of (3.4). The biases were 0.0224 and 0.0023, against 1.14 and 0.114.
:::

### 3.4 Exploration: choosing the width

Which width should the archive proposal have? We computed $m_2$ by quadrature for 40 widths from 0.05 to 3 on the running example, for the archive proposal and for defensive mixtures with $\varepsilon=0.1$ and 0.3 (Figure 2a).

The archive proposal has infinite second moment below $s=0.343$, as Proposition 3.4 says. Its best width is $s=1.17$, where $m_2=9.50$, so about one draw in ten counts; the measured mean effective fraction at $n=1000$ was 0.107. The base law alone, with no archive at all, gives $m_2=11.84$. With 40 records and an effective archive size of 2.7, the archive improves on the base law by only 20%, and only at a width more than twice the mode width of the target. Its best width is the one that most resembles the base law. Defensive mixtures cost nothing at the best width, 9.47 and 9.50, and turn the infinite region into a finite one: 111 and 37.5 at $s=0.05$.

The width also matters in practice, not just for the bounds. At $s=0.08$, below the threshold, 1,000 replications of the estimate with $n=1000$ had a bias of 0.359 and a mean squared error of 0.150. The estimator is consistent, but it had not yet converged, and its effective fraction of 0.026 gave no warning of the size of the error. At the wide width $s=2.5$, $m_2=19.9$ and the mean squared error with $n=1000$ was 0.0047.

The lesson for ASE is that the fine widths at which the stack resolves records are the wrong widths for estimation. A run that wants both should use different widths for the two jobs and should always include a defensive component.

![**Figure 2.** (a) The second moment $m_2=1+\chi^2$ of the importance weights for the archive proposal $p_s$ and two defensive mixtures, against the width $s$, on the double well. It is infinite to the left of the dotted line, $s=\sigma/\sqrt2=0.343$ (Proposition 3.4). The dashed line is the base law alone. (b) The fraction $1/m_2$ for a Gaussian proposal 1.5 times wider than a Gaussian target in every coordinate, against dimension (Proposition 3.3).](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p4/fig/width.png){width=100%}


## 4 Critic and density error

A weight $\rho e^{-\beta J}/q$ is never computed exactly. The loss comes from a critic, which may be a surrogate or a noisy measurement, and the proposal density may be evaluated on a truncated archive. Each error multiplies the weight by a factor. One lemma covers all of them.

::: {custom-style="Statement"}
**Lemma 4.1** (multiplicative weight error). Let $\mu$ be a probability law and $u>0$ a function with $c\le u\le c\,e^{\kappa}$ for some $c>0$ and $\kappa\ge0$. Let $\mu'$ be the law with density proportional to $u$ with respect to $\mu$. Then
:::

::: {custom-style="Statement Equation"}
$\text{TV}(\mu,\mu')\le\tanh(\kappa/4)$ (4.1)
:::

::: {custom-style="Statement"}
with equality for a two-point law with masses $p$ and $1-p$, where $p=1/(1+e^{\kappa/2})$, when $u$ takes the value $ce^{\kappa}$ on the first point and $c$ on the second.
:::

::: {custom-style="Statement Tag"}
New in Part IV as stated for general laws; Part II, Theorem 4.8(i), is the case of finitely many records with $\kappa=2\beta\varepsilon$.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* $\text{TV}(\mu,\mu')$ is the largest value of $\mu'(A)-\mu(A)$ over measurable sets $A$. Fix $A$ with $\mu(A)=p$. Then $\mu'(A)=X/(X+Y)$ with $X=\int_Au\,\text{d}\mu\le pce^{\kappa}$ and $Y=\int_{A^c}u\,\text{d}\mu\ge(1-p)c$. The ratio increases in $X$ and decreases in $Y$, so $\mu'(A)-p\le pe^{\kappa}/(pe^{\kappa}+1-p)-p$. This is maximised at $p=1/(1+e^{\kappa/2})$, where it equals $(e^{\kappa/2}-1)/(e^{\kappa/2}+1)=\tanh(\kappa/4)$. The two-point law attains every inequality. ∎

::: {custom-style="Statement"}
**Proposition 4.2** (bounded critic error). If the critic returns $\hat J$ with $|\hat J-J|\le\varepsilon$, the target it defines, $\hat\pi\propto\rho e^{-\beta\hat J}$, satisfies $\text{TV}(\pi_\beta,\hat\pi)\le\tanh(\beta\varepsilon/2)$. A self-normalised estimate that uses $\hat J$ converges to $E_{\hat\pi}f$, so its limiting bias is at most $\text{osc}(f)\tanh(\beta\varepsilon/2)$.
:::

::: {custom-style="Statement Tag"}
New in Part IV, extending Part II, Theorem 4.8, from record weights to target laws.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* $\hat\pi$ has density $e^{-\beta(\hat J-J)}$, up to a constant, with respect to $\pi_\beta$, and this factor lies in $[e^{-\beta\varepsilon},e^{\beta\varepsilon}]$. Apply Lemma 4.1 with $\kappa=2\beta\varepsilon$. For any $f$, $|E_\pi f-E_{\hat\pi}f|\le\text{osc}(f)\,\text{TV}$. ∎

::: {custom-style="Check"}
*Numerical check.* Over 4,000 random finite laws with bounded perturbations, the ratio of total variation to $\tanh(\beta\varepsilon/2)$ was at most 0.988. The two-point case gave 0.604368 against $\tanh(1.4)=0.604368$. On the double well, the critic error $0.1\sin3x_1\cos2x_2$ moved the target by 0.062 against the bound 0.197. Over 4,000 random laws and log-widths up to 4, Lemma 4.1 had a largest ratio of 0.9995.
:::

The bound is sharp, but only for an adversarial error that splits the target into two parts of the right sizes. A smooth error that changes sign often moves the target much less.

::: {custom-style="Statement"}
**Proposition 4.3** (Gaussian critic noise). Suppose each evaluation returns $J(x)+\sigma(x)\xi$ with standard normal $\xi$, averaged over $k$ independent evaluations, and the weight uses that average in place of $J$. Draws come from a proposal $q$ with $\pi_\beta\ll q$, and the tilted target below must have finite normaliser. Then the self-normalised estimate converges almost surely to $E_{\tilde\pi}f$, where
:::

::: {custom-style="Statement Equation"}
$\tilde\pi(x)\propto\rho(x)\,e^{-\beta J(x)+\beta^2\sigma(x)^2/2k}$ (4.2)
:::

::: {custom-style="Statement"}
In particular, constant $\sigma$ leaves the target unchanged, and any non-constant $\sigma$ tilts it towards noisier designs.
:::

::: {custom-style="Statement Tag"}
New in Part IV in this form; the moment identity is Part II, Proposition 4.7(i), and the argument is that of pseudo-marginal methods [6].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Given $x$, the noisy weight has conditional mean $w(x)e^{\beta^2\sigma(x)^2/2k}$ by the Gaussian moment generating function. The strong law applied to the numerator and denominator of the estimate replaces each weight by its conditional mean. A constant factor cancels in the ratio. ∎

::: {custom-style="Check"}
*Numerical check.* With $\rho=N(0,1)$, $J=x^2/2$, $\beta=1$, $k=1$ and $\sigma(x)=0.5+0.5|x|$, four million draws from $\rho$ gave $E\,x^2=0.6659$, against 0.6654 for the tilted target (4.2) and 0.5 for $\pi_\beta$. With constant noise $\sigma=0.7$ the estimate was 0.50005.
:::

A surrogate critic whose error grows away from the data is the common case, and (4.2) says it pulls the estimate towards the regions it knows least. Averaging more evaluations divides the tilt exponent by $k$, but it does not remove it.

::: {custom-style="Statement"}
**Proposition 4.4** (truncated proposal densities). Suppose the proposal density $q$ is evaluated as $\hat q$ with $\hat q\le q\le\hat q\,e^{\kappa}$, for instance by summing only the $k$ nearest components of $p_s$. Then the estimate with weights $\pi_\beta/\hat q$, drawn from $q$, converges to the law proportional to $\pi_\beta\,q/\hat q$, which is within $\tanh(\kappa/4)$ of $\pi_\beta$ in total variation.
:::

::: {custom-style="Statement Tag"}
New in Part IV; the truncation certificates of Part II, Section 5, bound $\kappa$.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Apply the strong law to the numerator and the denominator, then Lemma 4.1 with $u=q/\hat q\in[1,e^{\kappa}]$. ∎

::: {custom-style="Check"}
*Numerical check.* At the best width of Section 3.4, truncating $p_s$ to its 5, 10 and 20 nearest components gave log-widths of 141.8, 14.8 and 0.98 over the grid. The limiting laws were 0.379, 0.237 and 0.0070 from the target in total variation, against the bounds 1.000, 0.9988 and 0.240.
:::

Truncation is safe only when the omitted share is certified small everywhere the proposal draws. A nearest-component sum that is accurate where the records are dense can be wrong by a factor of $e^{140}$ in the gaps between them. Those gaps are exactly where the large weights live.


## 5 An error ledger

::: {custom-style="Statement"}
**Theorem 5.1** (error ledger). Let draws come from $q$, let the critic satisfy $|\hat J-J|\le\varepsilon$, and let the proposal density be evaluated as $\hat q$ with $\hat q\le q\le\hat q\,e^{\kappa}$. Let $\pi'$ be the law proportional to $\rho\,e^{-\beta\hat J}q/\hat q$, and $m_2'=E_q[(\pi'/q)^2]$. For every $f$ with $|f|\le1$,
:::

::: {custom-style="Statement Equation"}
$\left(E\left(\hat I_n(f)-E_{\pi_\beta}f\right)^2\right)^{1/2}\le2\tanh\left(\frac{2\beta\varepsilon+\kappa}{4}\right)+2\sqrt{\frac{m_2'}{n}}$ (5.1)
:::

::: {custom-style="Statement"}
The first term does not decrease with $n$. Once $2\sqrt{m_2'/n}$ is below it, more samples cannot reduce the bound; only a better critic or a better density evaluation can.
:::

::: {custom-style="Statement Tag"}
New in Part IV.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* The estimate is a self-normalised estimate of $\pi'$, so Theorem 3.6 bounds its root-mean-square deviation from $E_{\pi'}f$ by $2\sqrt{m_2'/n}$. The factor relating $\pi'$ to $\pi_\beta$ is $e^{-\beta(\hat J-J)}q/\hat q$. It lies in an interval of log-width $2\beta\varepsilon+\kappa$, so Lemma 4.1 gives $\text{TV}(\pi',\pi_\beta)\le\tanh((2\beta\varepsilon+\kappa)/4)$, and $|E_{\pi'}f-E_{\pi_\beta}f|\le\text{osc}(f)\,\text{TV}\le2\,\text{TV}$. Minkowski's inequality adds the two terms. ∎

For $0\le f\le1$ the oscillation is at most one, and the factor 2 in front of the first term of (5.1) becomes 1. The check uses that form.

Table: **Table 2.** The error ledger for $P(x_1>0.5)$ on the double well, at the best width $s=1.17$ with exact densities, $\kappa=0$. The critic error is $\varepsilon\,\text{sign}(\sin5x_1)$. Root-mean-square errors are over 1,000 replications, or 200 for $n=10{,}000$.

| $\varepsilon$ | $n$ | RMSE | bound (5.1) | critic term | sampling term | limiting bias |
|:--|:--|:--|:--|:--|:--|:--|
| 0 | 100 | 0.156 | 0.616 | 0 | 0.616 | 0 |
| 0 | 1,000 | 0.0487 | 0.195 | 0 | 0.195 | 0 |
| 0 | 10,000 | 0.0158 | 0.0616 | 0 | 0.0616 | 0 |
| 0.05 | 100 | 0.172 | 0.663 | 0.0997 | 0.564 | 0.0783 |
| 0.05 | 1,000 | 0.0920 | 0.278 | 0.0997 | 0.178 | 0.0783 |
| 0.05 | 10,000 | 0.0803 | 0.156 | 0.0997 | 0.0564 | 0.0783 |
| 0.2 | 100 | 0.278 | 0.917 | 0.380 | 0.537 | 0.264 |
| 0.2 | 1,000 | 0.267 | 0.550 | 0.380 | 0.170 | 0.264 |
| 0.2 | 10,000 | 0.264 | 0.434 | 0.380 | 0.0537 | 0.264 |

::: {custom-style="Check"}
*Numerical check.* The bound (5.1) had 0 violations in the 9 configurations of Table 2. Without critic error the error fell as $n^{-1/2}$, by factors of 0.31 and 0.32 per decade. With $\varepsilon=0.2$ it stayed between 0.264 and 0.278 from $n=100$ to 10,000, at the limiting bias 0.264. The critic term overstates that bias by a factor of 1.44.
:::

The ledger gives a rule for allocating evaluations (Figure 3). In the example, with $\varepsilon=0.05$, the sampling term falls below the critic term near $n=3{,}200$, and every evaluation beyond that point is wasted. In ADE terms, the archive weights, the proposal width and the critic are three separately accountable parts of one estimate, and each should be reported.

![**Figure 3.** Root-mean-square error of the self-normalised estimate of $P(x_1>0.5)$ against the number of draws, for three critic errors (solid), with the bound (5.1) (dashed) and the limiting bias (dotted). Once the critic is wrong, more draws converge to the wrong answer (Theorem 5.1).](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p4/fig/ledger.png){width=100%}


## 6 Discussion

### 6.1 What Part IV supplies to the rest of the book

Part V, on fusion and constraints, combines several local laws. Lemma 4.1 applies to every multiplicative factor such a fusion introduces, and Theorem 3.1 warns that a fused read confined to a hull cannot be weighted against a target outside it. Part VI, on evidence and computation, takes the ledger of Theorem 5.1 as the report every estimate should carry, and the kernel of Appendix A as its specification.

For the stack of Part III, the conclusion is a division of labour. The stack carries queries to outputs; it is a search operator. Estimation uses the archive density directly, at a width chosen for estimation, with a defensive component and fresh critic evaluations.

### 6.2 Diagnostics an estimate should report

Table: **Table 4.** Diagnostics reported with every estimate.

| Diagnostic | Source | Action when it is poor |
|:-------------------|:-------------------|:-------------------------------|
| declared base law $\rho$ and temperature $\beta$ | Definition 2.1 | no estimate without them |
| archive effective size $n_{\text{eff}}$ | Proposition 2.3 | never use the archive as the target |
| target mass outside the hull of the records read | Theorem 3.1 | never weight clean-top outputs |
| proposal width against $\sigma/\sqrt2$ in every Gaussian direction | Proposition 3.4 | widen, or add a defensive component |
| defensive share $\varepsilon$ and the cap $1/(\varepsilon Z)$ | Theorem 3.5 | report the cap with every estimate |
| critic error bound $\varepsilon$ or noise profile $\sigma(x)$ | Propositions 4.2, 4.3 | report the critic term; correct heteroscedastic tilt |
| truncation log-width $\kappa$ | Proposition 4.4 | evaluate more components |
| both terms of (5.1) | Theorem 5.1 | spend on the larger term |

### 6.3 What is not claimed

The results use identity maps and Gaussian components of one width. With masks or general maps, a read can leave the hull of the records (Part II, Proposition 3.5), so Theorem 3.1(i) fails as stated. Part (iii) still holds for the image of the read map, but that image has no simple description. Proposition 3.4 needs a target that factorises with a Gaussian factor. Without that structure the threshold is a heuristic, though the direction of the effect is general. The finite-sample bounds of Theorem 3.6 are worst-case and were loose by factors of 16 to 18 in the example. The width exploration uses one target with one archive, and its optimum is specific to them. Nothing here concerns the quality of designs found by search.

### 6.4 Open problems

1. **Densities of finite stacks.** Bound the density ratio between a finite stochastic stack and $p_{s_0}$, so that stack outputs could be weighted with a certified $\kappa$.
2. **Widths from the archive.** Estimate the width that minimises $m_2$ from the archive alone, without quadrature, and prove that the estimate is consistent.
3. **Sequential targets.** Analyse a run that raises $\beta$ across generations as a sequence of tempered targets, with Lemma 4.1 bounding the step between consecutive targets.
4. **Heteroscedastic correction.** Prove when the plug-in correction of Part II, Proposition 4.7(ii), removes the tilt (4.2) to first order, and bound what it leaves.
5. **Targets with maps.** Define the target of a run whose reads use masks, as a law on the glued space of Part I, and extend Theorem 3.1 to it.

### 6.5 Conclusion

A run estimates a declared Gibbs target only if its proposal has a known density and covers the target. The archive is a selection record, not a sample of the target. A clean top cannot be weighted at all. The archive density is an exact proposal, but only at widths above a threshold that the target's narrowest Gaussian direction sets. A defensive component makes every width safe. Every error in the weights, from critic bias to truncated densities, moves the estimate by a bounded amount that does not shrink with more draws. The ledger of Theorem 5.1 says when that amount, rather than the sampling error, decides the answer.


## 7 Register of numerical checks

Table 3 lists every numerical check in Part IV. The script `p4_checks.py` produced checks 1 to 15 and the width exploration, with seed 20261021, and `p4_extras.py` added the elite hulls, the threshold and the bound verdicts from the same results file. The kernel comparison of Appendix A is check 16. The checks test the implementations and illustrate the statements; the proofs establish them.

Table: **Table 3.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 2.3 | Gaussian case, 400,000 records | largest relative error 0.015 |
| 2 | Section 2.2 | archive as target, 40 and 4,000 records | TV 0.61 to 0.95; 0.19 |
| 3 | Theorem 3.1(i), (ii) | 200 clean-top stacks in $ℝ^5$ | distance to span 2.1 × 10⁻¹⁴ |
| 4 | Theorem 3.1(iii) | elite hulls | missing mass 0.795 with 8 records |
| 5 | Proposition 3.2 | direct sampler and finite stacks | KS 0.0071; stacks 0.101 to 0.012 |
| 6 | Proposition 3.3 | closed form against Monte Carlo | four cases; slow for narrow proposals |
| 7 | Proposition 3.4 | threshold on the double well | 0.343; first finite width 0.367 |
| 8 | Theorem 3.5 | weight caps and (3.3), 40 widths | 0 violations |
| 9 | Theorem 3.6 | bias and MSE, 6 configurations | 0 violations; MSE 0.0234 against 0.380 |
| 10 | Lemma 4.1 | 4,000 random laws | largest ratio 0.9995 |
| 11 | Proposition 4.2 | 4,000 laws; two points; double well | 0.988; equality; 0.062 against 0.197 |
| 12 | Proposition 4.3 | heteroscedastic and constant noise | 0.6659 against 0.6654; 0.50005 |
| 13 | Proposition 4.4 | truncation to 5, 10, 20 components | TV 0.379, 0.237, 0.0070 within bounds |
| 14 | Theorem 5.1 | ledger, 9 configurations | 0 violations |
| 15 | Section 3.4 | width exploration, 40 widths | best $s=1.17$, $m_2=9.50$; base law 11.84 |
| 16 | Appendix A | C# kernel against NumPy | 9 of 9 lines agree; largest relative difference 2.9 × 10⁻¹⁴ |

## References for Part IV

::: {custom-style="Bibliography"}
[1] Agapiou, S., Papaspiliopoulos, O., Sanz-Alonso, D. and Stuart, A. M. (2017). Importance sampling: intrinsic dimension and computational cost. *Statistical Science* 32(3), 405–431. arXiv:1511.06196.

[2] Chatterjee, S. and Diaconis, P. (2018). The sample size required in importance sampling. *Annals of Applied Probability* 28(2), 1099–1135.

[3] Hesterberg, T. (1995). Weighted average importance sampling and defensive mixture distributions. *Technometrics* 37(2), 185–194.

[4] Kong, A. (1992). A note on importance sampling using standardized weights. Technical Report 348, Department of Statistics, University of Chicago.

[5] Owen, A. and Zhou, Y. (2000). Safe and effective importance sampling. *Journal of the American Statistical Association* 95(449), 135–143.

[6] Andrieu, C. and Roberts, G. O. (2009). The pseudo-marginal approach for efficient Monte Carlo computations. *Annals of Statistics* 37(2), 697–725.

[7] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[8] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[9] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[10] Ghosh, D. P. (2026d). *Horizontally Topological, Vertically Algebraic: The Two Axes of Autoregressive Sheaf Evolution. Part I: Sheaves on Covers and Representations of the Layer Order*. 18 October 2026.

[11] Ghosh, D. P. (2026e). *The Horizontal Layer: One Layer of Autoregressive Sheaf Evolution. Part II: Sheaf Attention, Gaussian Stalks, Locality and the Topology of Design Spaces*. 18 October 2026.

[12] Ghosh, D. P. (2026f). *The Vertical Stack: Layers of Autoregressive Sheaf Evolution. Part III: The Token Recurrence, Tangent Dynamics and Persistence across Layers*. 18 October 2026.

[13] Steele, G. L., Lea, D. and Flood, C. H. (2014). Fast splittable pseudorandom number generators. *Proceedings of OOPSLA 2014*, 453–472. ACM.

[14] Box, G. E. P. and Muller, M. E. (1958). A note on the generation of random normal deviates. *Annals of Mathematical Statistics* 29(2), 610–611.

[15] Silverman, B. W. (1986). *Density Estimation for Statistics and Data Analysis*. Chapman and Hall.

[16] Robert, C. P. and Casella, G. (2004). *Monte Carlo Statistical Methods*, 2nd edn. Springer.
:::

## Appendix IV.A: an immutable C# reference kernel

The kernel holds an archive and a Gibbs target as immutable records. It computes the archive log density, draws exactly from $p_s$ (Proposition 3.2), and forms self-normalised estimates with their effective fractions and largest weight shares. It also gives the Gaussian second moment (3.1), the defensive cap of Theorem 3.5 and the bound of Lemma 4.1. The random stream is a SplitMix64 generator [13] with Box–Muller normals [14], held as a value: every draw returns the next generator. The kernel targets .NET 8 and uses only the base class library.

```csharp
// ASE Part IV reference kernel: targets, proposals and self-normalised importance sampling.
// Immutable values and pure functions; the random stream is itself a value.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AsePartFour;

/// <summary>SplitMix64 stream with Box-Muller normals; each draw returns the next state.</summary>
public sealed record Rng(ulong State)
{
    public (ulong Value, Rng Next) NextU64()
    {
        ulong s = State + 0x9E3779B97F4A7C15UL, z = s;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
        return (z ^ (z >> 31), new Rng(s));
    }

    public (double Value, Rng Next) Uniform()
    {
        var (v, n) = NextU64();
        return ((v >> 11) * (1.0 / 9007199254740992.0), n);
    }

    public (double Value, Rng Next) Normal()
    {
        var (u1, r1) = Uniform();
        var (u2, r2) = r1.Uniform();
        return (Math.Sqrt(-2 * Math.Log(1 - u1)) * Math.Cos(2 * Math.PI * u2), r2);
    }

    /// <summary>Index drawn with probabilities proportional to exp(logWeights), by inversion.</summary>
    public (int Value, Rng Next) Categorical(Vec logWeights)
    {
        var p = Num.Softmax(logWeights);
        var (u, n) = Uniform();
        double acc = 0;
        for (int i = 0; i < p.Length; i++)
        {
            acc += p[i];
            if (u < acc) return (i, n);
        }
        return (p.Length - 1, n);
    }
}

/// <summary>Records y_i with log prior weights: the archive density p_s is
/// sum_i beta_i N(y_i, s^2 I) with beta = softmax(log weights).</summary>
public sealed record Archive(ImmutableArray<Vec> Records, Vec LogWeights)
{
    public int Dim => Records[0].Length;

    public double LogDensity(Vec x, double s)
    {
        double lz = Num.LogSumExp(LogWeights), d = Dim;
        var terms = Records.Select((y, i) => LogWeights[i] - lz
            - Num.SqDist(x, y) / (2 * s * s) - d / 2 * Math.Log(2 * Math.PI * s * s))
            .ToImmutableArray();
        return Num.LogSumExp(terms);
    }

    /// <summary>Exact draw from p_s: pick a record, add N(0, s^2 I) (Proposition 3.2).</summary>
    public (Vec Value, Rng Next) Sample(Rng rng, double s)
    {
        var (i, r) = rng.Categorical(LogWeights);
        var x = ImmutableArray.CreateBuilder<double>(Dim);
        for (int j = 0; j < Dim; j++)
        {
            double e; (e, r) = r.Normal();
            x.Add(Records[i][j] + s * e);
        }
        return (x.MoveToImmutable(), r);
    }
}

/// <summary>Gibbs target pi(x) proportional to rho(x) exp(-beta J(x)), with an
/// isotropic Gaussian base rho = N(0, rhoSd^2 I).</summary>
public sealed record GibbsTarget(Func<Vec, double> Loss, double Beta, double RhoSd)
{
    public double LogRho(Vec x) => -x.Sum(v => v * v) / (2 * RhoSd * RhoSd)
        - x.Length / 2.0 * Math.Log(2 * Math.PI * RhoSd * RhoSd);

    public double LogUnnormalised(Vec x) => LogRho(x) - Beta * Loss(x);
}

/// <summary>Result of a self-normalised importance-sampling run.</summary>
public sealed record SnisResult(double Estimate, double EssFraction, double MaxWeightShare);

public static class Estimation
{
    /// <summary>Self-normalised importance sampling from log target and log proposal values.</summary>
    public static SnisResult Snis(Vec logTarget, Vec logProposal, Vec f)
    {
        var lw = logTarget.Zip(logProposal, (a, b) => a - b).ToImmutableArray();
        var w = Num.Softmax(lw);
        double est = w.Zip(f, (a, b) => a * b).Sum();
        double ess = 1.0 / w.Sum(v => v * v) / w.Length;
        return new SnisResult(est, ess, w.Max());
    }

    /// <summary>Proposition 3.3: 1 + chi^2 for N(0, sp^2) against N(0, sq^2) in each of
    /// d independent coordinates; infinite unless 2 sq^2 &gt; sp^2.</summary>
    public static double GaussianSecondMoment(double sp, double sq, int d) =>
        2 * sq * sq <= sp * sp ? double.PositiveInfinity
            : Math.Pow(sq * sq / (sp * Math.Sqrt(2 * sq * sq - sp * sp)), d);

    /// <summary>Theorem 3.5: weight bound 1/(eps Z) of the defensive mixture
    /// (1 - eps) q + eps rho, when the loss is non-negative.</summary>
    public static double DefensiveBound(double eps, double z) => 1.0 / (eps * z);

    /// <summary>Lemma 4.1 and Proposition 4.2: total-variation bound when every
    /// multiplicative weight error lies in an interval of log-width kappa.</summary>
    public static double TvBound(double kappa) => Math.Tanh(kappa / 4);

    public static double Tv(Vec a, Vec b) => 0.5 * a.Zip(b, (p, q) => Math.Abs(p - q)).Sum();

    /// <summary>Reweights a finite law by exp(logFactor) and renormalises.</summary>
    public static Vec Reweight(Vec p, Vec logFactor) =>
        Num.Softmax(p.Zip(logFactor, (a, l) => Math.Log(a) + l).ToImmutableArray());
}

public static class Num
{
    public static double LogSumExp(Vec v)
    {
        double m = v.Max();
        return m + Math.Log(v.Sum(x => Math.Exp(x - m)));
    }

    public static Vec Softmax(Vec v)
    {
        double l = LogSumExp(v);
        return v.Select(x => Math.Exp(x - l)).ToImmutableArray();
    }

    public static double SqDist(Vec a, Vec b) => a.Zip(b, (p, q) => (p - q) * (p - q)).Sum();
}
```

The driver draws the 40-record archive of the running example from the stream. It prints the first record and two log densities, and estimates $P(x_1>0.5)$ with 2,000 draws at widths 0.2, 0.5 and 1. It then prints the closed forms of (3.1) and (3.3), the two-point equality of Lemma 4.1, and the largest ratio over 1,000 random laws. An independent NumPy script regenerates the same stream and recomputes every line (Table A1). The largest relative difference is 2.9 × 10⁻¹⁴, in the importance-sampling lines, where sums are taken in a different order.

Table: **Table A1.** C# kernel output against the NumPy recomputation.

| C# | NumPy | Relative difference |
|:------------------|:------------------|:----------|
| `archive_first -⁠2.150366452324182 3.9118177744495974 -⁠83.1403405161534` | `archive_first -⁠2.150366452324182 3.9118177744495974 -⁠83.1403405161534` | identical |
| `log_density -⁠1.4305810462040323 -⁠2.653402509957455` | `log_density -⁠1.4305810462040323 -⁠2.653402509957455` | identical |
| `snis_s0.2 0.5461594991310338 0.18589072295334283 0.018416986842595354` | `snis_s0.2 0.546159499131037 0.18589072295334055 0.018416986842595486` | 1.2 × 10⁻¹⁴ |
| `snis_s0.5 0.4846694034530794 0.3126645960102915 0.004843615353757474` | `snis_s0.5 0.48466940345307685 0.3126645960102941 0.004843615353757456` | 8.3 × 10⁻¹⁵ |
| `snis_s1 0.4674468112763878 0.16701244963873316 0.008426280730225904` | `snis_s1 0.4674468112763937 0.16701244963872838 0.008426280730226023` | 2.9 × 10⁻¹⁴ |
| `gauss_second_moment 1.2026755886059097 19.159136649841205 Infinity` | `gauss_second_moment 1.2026755886059097 19.159136649841205 inf` | identical |
| `defensive_bound 40 13.333333333333334` | `defensive_bound 40.0 13.333333333333334` | identical |
| `two_atom 0.6043677771171634 0.6043677771171636` | `two_atom 0.6043677771171634 0.6043677771171636` | identical |
| `lemma_worst_ratio 0.999995125250873` | `lemma_worst_ratio 0.9999951252508726` | 3.3 × 10⁻¹⁶ |

## Appendix IV.B: reproducibility

All results were produced with Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1, Matplotlib 3.11.2 and .NET SDK 8.0.131. The script `p4_checks.py` writes `p4_checks.json`, and `p4_extras.py` adds the elite hulls, the width threshold and the bound verdicts to it. Both use seed 20261021 and the shared primitives of Part III in `p3_core.py`. The script `fig_p4.py` draws the figures from the results file; panel (a) of Figure 1 recomputes the target on a grid. The C# project in `cs/` builds the kernel and its driver, and `cs_validate.py` compares the driver's output with NumPy and writes `cs_validate.json`. The document is converted to Word by Pandoc and post-processed for equation layout and schema order. A code archive accompanies this paper.


# Part V · Fusion and Constraints

::: {custom-style="Subtitle"}
Combining local laws in Autoregressive Sheaf Evolution. Part V: products of experts, marginal extension, covariance intersection and feasibility
:::

**Summary of Part V.** Parts I to IV of Autoregressive Sheaf Evolution (ASE) built a layer, a stack and the targets a run estimates. This paper, Part V of the book, combines local laws and imposes constraints. Three fusion operations are easily confused, and we separate them. A product of experts adds precisions. If its experts share a prior or common data, it counts that shared factor once per expert; with four experts it understated the covariance trace by 39%, and dividing the shared factor out restored the exact posterior. Covariance intersection is consistent for every cross-correlation and never failed in 400 trials, while the product of experts understated the true error in 196. In an exploration with correlated experts, its 90% ellipse covered 73.6% at correlation 0.9; covariance intersection covered 92.8%. Marginal extension on a cover differs from the product by exactly one copy of the separator marginal, so the product halves the separator variance in every case. On a 3-cycle, pairwise-consistent Gaussian marginals with correlation below $-1/2$ have no joint law at all: the obstruction is global, as Part I predicts for cycles. A product of experts can place its mean outside the convex hull of the expert means, which is a soft form of the map channel of Part III. In a constructed example, two feasible means fuse to an infeasible design. Linear constraints act by conditioning, and quadratic penalties converge to it at rate $1/\gamma$, with an explicit constant. Hard constraints are not bounded weight factors, so the error ledger of Part IV does not apply to them. We give the exact second moment of the restricted weights instead. Coordinate recombination keeps every child feasible for all feasible parents exactly when the feasible set is a box. For a simplex in $ℝ^{16}$, only 64% of children were feasible. There are 13 numerical checks and two explorations, and an immutable C# kernel matches an independent NumPy implementation on every output line.

## 1 Introduction

Autoregressive Diffusion Evolution (ADE) proposes designs by running tokens down a denoising stack whose layers read an archive of evaluated designs [7, 8]. Autoregressive Sheaf Evolution (ASE) generalises each read to an observation star with edge maps and scale-dependent covers [9]. Part I separated the horizontal and vertical axes [10]. Part II worked out one layer [11], and Part III a stack [12]. Part IV fixed the target and showed which proposals can be importance-weighted [13]. This paper, Part V of the book, combines local information and imposes constraints.

Combination happens throughout ASE. A layer combines records on an observation star. A cover combines charts on overlaps. A run may combine several critics, surrogates or design teams, and every engineering design must satisfy constraints that no single expert sees whole. Part II warned that products of experts and the marginal extension of V2 are different operations with different conclusions [11, Section 8.1]. Part IV warned that a fused read confined to a hull cannot be weighted against a target outside it [13, Section 6.1]. Part V makes both warnings exact. It also adds the correlation problem that neither part addressed: local experts in ASE are rarely independent, because they read the same archive.

### 1.1 Contributions

- **Fusion rules (Section 2).** The product of experts counts any shared factor once per expert (Proposition 2.3). Covariance intersection is consistent whatever the correlation (Proposition 2.4). The product of experts can move its mean outside the hull of the expert means in two or more dimensions, never in one (Proposition 2.5).
- **Marginal extension (Section 3).** On a two-clique cover, the product of the clique marginals is the marginal extension multiplied by one extra copy of the separator marginal. It halves the separator variance exactly (Theorem 3.1). On a cycle, pairwise consistency does not imply a joint law (Proposition 3.2).
- **Constraints (Section 4).** Linear equality constraints act by conditioning, and quadratic penalties converge to it at rate $1/\gamma$ (Propositions 4.1 and 4.2). Hard constraints change the second moment of importance weights by an exact factor (Proposition 4.3). Coordinate recombination preserves feasibility for all parents exactly when the feasible set is a box (Theorem 4.4). Convex reads keep convex constraints, but products of experts need not (Proposition 4.5).
- **Explorations (Section 5).** We measure the calibration of three fusion rules under correlated errors, and the feasibility of recombined children for three feasible sets in up to 16 dimensions.
- **Evidence.** There are 13 numerical checks besides the explorations (Table 3). An immutable C# kernel agrees with an independent NumPy implementation on every output line (Appendix A).

### 1.2 Scope and status of statements

Experts are Gaussian, given in information form. Constraints are linear equalities, or membership in a set. The paper proves statements about fusion and feasibility. It makes no claim about search performance, and the explorations are computations on declared synthetic examples.

Every statement in a shaded box ends with a provenance tag. *Classical* marks a known result restated in ASE notation. *Part I* to *Part IV* refer to [10] to [13]. *New in Part V* marks a statement proved here for the first time in this programme; each comes with a proof and a numerical check. All spaces are finite-dimensional and real.

### 1.3 Notation

Table: **Table 1.** Notation used throughout Part V.

| Symbol | Meaning |
|:--------------------------|:--------------------------------------------------|
| $(\mu_k,\Lambda_k)$ | mean and precision of expert $k$ |
| $\Lambda,\ \mu$ | precision and mean of a fused law |
| $P_a,\ P_b,\ \omega$ | error covariances and weight of covariance intersection |
| $A,\ S,\ B$ | the two private blocks and the separator of a two-clique cover |
| $p_{AS},\ p_{SB},\ p_S$ | clique and separator marginals |
| $K$ | feasible set |
| $A x=b,\ \gamma$ | linear constraint and penalty strength |
| $\pi_K,\ q_K$ | target and proposal restricted to $K$ and renormalised |
| $m_2$ | second moment of importance weights (Part IV) |


## 2 Fusion of local laws

::: {custom-style="Statement"}
**Definition 2.1** (Gaussian expert). An *expert* on $ℝ^D$ is a Gaussian factor $f_k(x)\propto\exp(-\tfrac12(x-\mu_k)^{\top}\Lambda_k(x-\mu_k))$ with a positive semidefinite precision $\Lambda_k$. A precision that is singular in some direction expresses ignorance there, as a coordinate mask does in Part II.
:::

::: {custom-style="Statement Tag"}
Classical; the information form of Part II, Section 4.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Proposition 2.2** (product of experts). If $\Lambda=\sum_k\Lambda_k$ is positive definite, then $\prod_kf_k$ is proportional to the Gaussian density with precision $\Lambda$ and mean $\mu=\Lambda^{-1}\sum_k\Lambda_k\mu_k$.
:::

::: {custom-style="Statement Tag"}
Classical [6].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* The sum of the exponents is a quadratic form with Hessian $\Lambda$ and linear term $\sum_k\Lambda_k\mu_k$; complete the square. ∎

::: {custom-style="Check"}
*Numerical check.* For 300 random products of 2 to 4 experts in dimensions 1 to 4, the log of the product minus the log of the fused Gaussian was constant across test points to 1.4 × 10⁻¹⁴.
:::

### 2.1 Shared evidence is counted once per expert

::: {custom-style="Statement"}
**Proposition 2.3** (double counting). Suppose expert $k$ is the posterior $f_0g_k$ formed from a shared factor $f_0$, such as a prior or a common archive, and a private factor $g_k$. The product of $K$ such experts is $f_0^Kg_1\cdots g_K$, whereas the posterior given all the information is $f_0g_1\cdots g_K$. With precisions $\Lambda_0$ and $\Lambda_k$, the product has precision $K\Lambda_0+\sum_k\Lambda_k$ instead of $\Lambda_0+\sum_k\Lambda_k$. Dividing $f_0^{K-1}$ out of the product restores the posterior exactly.
:::

::: {custom-style="Statement Tag"}
Classical in substance, the common-information problem of decentralised fusion [5].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Multiply the factorisations; division of Gaussian factors subtracts precisions and information vectors. ∎

A product of experts is therefore valid only when the experts are conditionally independent given the design. In ASE this fails by construction: every layer reads the same archive, so local reads share it. The precision of a naive product overstates what is known, and the error is the shared precision counted $K-1$ extra times.

::: {custom-style="Check"}
*Numerical check.* With a shared factor and four private factors in $ℝ^3$, the naive product had a covariance trace 0.611 times the exact one and a mean 0.401 from the exact mean. Dividing the shared factor out three times recovered the exact precision and mean to 1.3 × 10⁻¹⁵.
:::

The shared factor is not always known. When it is not, a rule that is safe for every correlation is needed.

::: {custom-style="Statement"}
**Proposition 2.4** (covariance intersection). Let $a$ and $b$ be unbiased estimates of $x$ with error covariances bounded by $P_a$ and $P_b$, and unknown cross-covariance. For $\omega\in[0,1]$ put $P_\omega=(\omega P_a^{-1}+(1-\omega)P_b^{-1})^{-1}$ and $c_\omega=P_\omega(\omega P_a^{-1}a+(1-\omega)P_b^{-1}b)$. Then the error covariance of $c_\omega$ is at most $P_\omega$, for every cross-covariance consistent with $P_a$ and $P_b$.
:::

::: {custom-style="Statement Tag"}
Classical, Julier and Uhlmann [4].
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* In 400 random pairs in $ℝ^2$, with cross-covariances $cL_aL_b^{\top}$ for Cholesky factors $L_a,L_b$ and $c$ uniform in $(-1,1)$, and $\omega$ chosen to minimise the trace, the claimed covariance $P_\omega$ dominated the true one in all 400. The naive product understated the true error covariance in 196 of them. The ratio of true to claimed trace reached 1.93 for the product and 0.9999 for covariance intersection.
:::

### 2.2 A product of experts leaves the hull

Part III, Proposition 3.7, listed four channels of novelty for a stack with identity maps. Reads lie in the hull of the records unless maps or masks move them out. A product of experts with unequal precisions is a soft version of a mask.

::: {custom-style="Statement"}
**Proposition 2.5** (fused means can leave the hull). In one dimension, the mean of a product of experts lies between the smallest and the largest expert mean. In two or more dimensions it need not lie in the convex hull of the expert means. For $\mu_1=(1,0)$, $\Lambda_1=\text{diag}(1,100)$, $\mu_2=(0,1)$ and $\Lambda_2=\text{diag}(100,1)$, the fused mean is $(1/101,1/101)$, while every point of the hull has coordinates summing to one.
:::

::: {custom-style="Statement Tag"}
New in Part V.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* In one dimension the fused mean is $\sum_k\lambda_k\mu_k/\sum_k\lambda_k$ with $\lambda_k\ge0$, a convex combination. For the example, $\Lambda=\text{diag}(101,101)$ and $\Lambda_1\mu_1+\Lambda_2\mu_2=(1,1)$. ∎

Each expert is precise about the coordinate on which the other is vague, and the product takes each coordinate from the expert that is sure of it. This is recombination, and it is what masked reads do in Part II, Proposition 3.5. The weights are matrices, not scalars, so the result is not a convex combination of the means.

::: {custom-style="Check"}
*Numerical check.* The example gave $(0.00990,0.00990)$. For 2,000 random triples of experts in $ℝ^2$ with condition numbers up to 50, a non-negative least-squares test placed the fused mean outside the hull of the three means in 1,095. In 2,000 one-dimensional triples it was never outside.
:::

![**Figure 1.** (a) Two experts, each certain of one coordinate, and their product, which lies outside the segment between their means (Proposition 2.5). Both means satisfy $x_1+x_2\ge0.5$; the product does not (Proposition 4.5). Ellipses are unit level sets of each precision. (b) The smallest eigenvalue of the correlation matrix of three variables with common pairwise correlation $r$. Below $r=-1/2$, no joint law has those pairwise marginals (Proposition 3.2).](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p5/fig/fusion.png){width=100%}


## 3 Marginal extension on covers

V2 glued local laws by junction-tree marginal extension [9, Section 16]. On a cover with two cliques $A\cup S$ and $S\cup B$ that overlap in a separator $S$, the extension of consistent marginals is $p=p_{AS}\,p_{SB}/p_S$: the law that has both marginals and makes $A$ and $B$ conditionally independent given $S$ [3]. A product of experts would instead multiply the clique marginals.

::: {custom-style="Statement"}
**Theorem 3.1** (a product of experts counts the separator twice). Let $p_{AS}$ and $p_{SB}$ be Gaussian marginals that agree on $S$, and let $p=p_{AS}\,p_{SB}/p_S$ be their extension. Treated as experts on the whole space, their product is
:::

::: {custom-style="Statement Equation"}
$q\propto p_{AS}\,p_{SB}=p\cdot p_S$ (3.1)
:::

::: {custom-style="Statement"}
So $q$ has the same conditional law of $(A,B)$ given $S$ as $p$, but its separator marginal is proportional to $p_S^2$. Its separator mean equals that of $p_S$, and its separator covariance is exactly half.
:::

::: {custom-style="Statement Tag"}
The extension is classical [3]; the comparison New in Part V.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* (3.1) is the definition of $p$ rearranged. The factor $p_S$ depends only on $S$, so it leaves the conditional law given $S$ unchanged and multiplies the $S$-marginal of $p$, which is $p_S$, by $p_S$. The square of a Gaussian density with covariance $\Sigma_S$ is proportional to a Gaussian density with the same mean and covariance $\Sigma_S/2$. ∎

The separator is exactly where two charts of a cover agree. A fusion rule that multiplies charts doubles the confidence on that overlap, however large it is. Marginal extension divides by the separator once for each overlap of the junction tree. For a chain of $m$ cliques the product overcounts each of the $m-1$ separators once.

::: {custom-style="Check"}
*Numerical check.* For 300 random Gaussian laws with blocks of dimension 1 or 2, the extension reproduced both clique marginals to 2.7 × 10⁻¹⁵. The product's separator covariance was smaller by a factor between 1.9999999999999991 and 2.000000000000001, per dimension of the separator.
:::

Extension needs marginals that agree on the separators. On a tree of cliques, agreement on every separator suffices [3, 16]. On a cycle it does not.

::: {custom-style="Statement"}
**Proposition 3.2** (consistent pairs on a cycle with no joint law). Let three variables sit on the vertices of a triangle. Give each edge the bivariate law with unit variances and correlation $r$, so that every pair of edge laws agrees on the vertex they share. A joint law with these three edge marginals exists if and only if $-1/2\le r\le1$. For $r<-1/2$ there is none, Gaussian or otherwise.
:::

::: {custom-style="Statement Tag"}
Classical, the marginal problem [16]; the eigenvalue form is elementary.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Any joint law with these pairs has the correlation matrix with ones on the diagonal and $r$ elsewhere. Its eigenvalues are $1+2r$ and $1-r$, twice, so it is positive semidefinite exactly when $-1/2\le r\le1$. Conversely, for such $r$ the Gaussian law with that covariance has the required marginals. ∎

This is the probabilistic face of Part I's cycles. Agreement on every overlap is a local condition, a cocycle condition on edges. A global section can still fail to exist because of the loop, and no amount of local checking detects it. A fusion of three pairwise surrogates around a loop of design variables can therefore fail with no local symptom. The check is global: the assembled covariance must be positive semidefinite.

::: {custom-style="Check"}
*Numerical check.* The smallest eigenvalue was 0.200, 0.000, −0.200 and −0.800 for $r=-0.4$, −0.5, −0.6 and −0.9.
:::


## 4 Constraints

### 4.1 Equality constraints

::: {custom-style="Statement"}
**Proposition 4.1** (conditioning). For $x\sim N(\mu,\Sigma)$ and a constraint $Ax=b$ with $A\Sigma A^{\top}$ invertible, the conditional law has mean $\mu_c=\mu-\Sigma A^{\top}(A\Sigma A^{\top})^{-1}(A\mu-b)$, the point of the constraint set nearest to $\mu$ in the metric $\Sigma^{-1}$.
:::

::: {custom-style="Statement Tag"}
Classical [1, 2].
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Statement"}
**Proposition 4.2** (penalties converge at rate $1/\gamma$). The law proportional to $N(\mu,\Sigma)\,e^{-\gamma\Vert Ax-b\Vert^2/2}$ has mean $\mu_\gamma$ with
:::

::: {custom-style="Statement Equation"}
$\Vert\mu_\gamma-\mu_c\Vert\le\frac{\Vert\Sigma A^{\top}\Vert\,\Vert(A\Sigma A^{\top})^{-1}\Vert^2\,\Vert A\mu-b\Vert}{\gamma}$ (4.1)
:::

::: {custom-style="Statement Tag"}
New in Part V in this form; the quadratic penalty method is classical [14, Chapter 17].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* The penalty is a Gaussian observation $b=Ax+\nu$ with noise covariance $I/\gamma$, so $\mu_\gamma=\mu-\Sigma A^{\top}(M+I/\gamma)^{-1}(A\mu-b)$ with $M=A\Sigma A^{\top}$. Then $M^{-1}-(M+\varepsilon I)^{-1}=\varepsilon M^{-1}(M+\varepsilon I)^{-1}$, whose norm is at most $\varepsilon\Vert M^{-1}\Vert^2$, with $\varepsilon=1/\gamma$. ∎

A penalty is a soft constraint whose error must be reported with it. Doubling $\gamma$ halves the violation, and nothing short of $\gamma=\infty$ removes it.

::: {custom-style="Check"}
*Numerical check.* In $ℝ^4$ with two random constraints, the conditional mean satisfied them to 6.7 × 10⁻¹⁶. For $\gamma=1$, 10, 100, 1,000 and 10,000, the distance to it was 0.791, 0.112, 0.0117, 0.00118 and 0.000118, against the bounds 3.72, 0.372, 0.0372, 0.00372 and 0.000372. The fitted slope on a log scale was −0.994.
:::

### 4.2 Hard constraints in estimation

A feasible set $K$ restricts the target to $\pi_K=\pi1_K/\pi(K)$. Its indicator is a multiplicative factor with log-width $\kappa=\infty$, so Lemma 4.1 of Part IV gives no bound, and the error ledger does not apply. Rejection does: draws from a proposal $q$ that land in $K$ are draws from $q_K=q1_K/q(K)$.

::: {custom-style="Statement"}
**Proposition 4.3** (restricted weights). The second moment of the weights of $\pi_K$ against $q_K$ is
:::

::: {custom-style="Statement Equation"}
$m_2(q_K;\pi_K)=\frac{q(K)}{\pi(K)^2}\int_K\frac{\pi^2}{q}\,\text{d}x\le\frac{q(K)\,m_2(q;\pi)}{\pi(K)^2}$ (4.2)
:::

::: {custom-style="Statement"}
and a fraction $q(K)$ of the proposals is accepted.
:::

::: {custom-style="Statement Tag"}
New in Part V.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* On $K$ the weight is $(\pi/q)\,q(K)/\pi(K)$. Square it, integrate against $q_K$, and extend the integral to the whole space for the bound. ∎

The bound shows why constraints are expensive. A constraint that the target mostly violates, with $\pi(K)$ small, inflates the cost by $1/\pi(K)^2$ unless the proposal concentrates on $K$ in the same proportion.

::: {custom-style="Check"}
*Numerical check.* For $\pi=N(0,1)$, $q=N(0,1.5^2)$ and $K=\{x>0.8\}$, (4.2) gives 1.2665. Monte Carlo from four million proposals gave 1.2670, with acceptance 0.297. The bound in (4.2) is 7.96, and the unrestricted second moment is 1.20.
:::

### 4.3 Recombination and feasibility

Recombination takes coordinates, or blocks of coordinates, from different parents. Part II showed that masked reads recombine. Proposition 2.5 shows that products of experts do. The question for constraints is when recombination of feasible parents gives a feasible child.

::: {custom-style="Statement"}
**Theorem 4.4** (recombination preserves feasibility exactly on boxes). Let $K\subseteq ℝ^D$ be non-empty, with coordinate projections $K_i$. Every child that takes each coordinate from one of two parents in $K$ lies in $K$, for all parents and all choices of coordinates, if and only if $K=K_1\times\cdots\times K_D$.
:::

::: {custom-style="Statement"}
The same holds for blocks of coordinates, such as the stalks of a cover, with $K$ a product over the blocks.
:::

::: {custom-style="Statement Tag"}
New in Part V.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* If $K$ is a product, each coordinate of a child lies in its $K_i$. Conversely, let $z$ have $z_i\in K_i$ for every $i$, and choose $x^{(i)}\in K$ with $x^{(i)}_i=z_i$. Put $c_1=x^{(1)}$. For $j\ge2$, let $c_j$ take coordinate $j$ from $x^{(j)}$ and every other coordinate from $c_{j-1}$. By hypothesis each $c_j\in K$, and $c_D=z$. Hence $K_1\times\cdots\times K_D\subseteq K$, and the reverse inclusion always holds. ∎

Uniform crossover [15] and masked reads are safe only for box constraints. Coupling constraints, such as a budget $\sum_ix_i\le1$ or a norm bound, make some children infeasible. How many depends on the set and the dimension (Section 5.2).

::: {custom-style="Statement"}
**Proposition 4.5** (convex reads stay feasible; products need not). If $K$ is convex and every record read by a layer lies in $K$, then every read with identity maps lies in $K$, and so does every output of a deterministic stack whose starting state lies in $K$. A product of experts whose means all lie in a convex $K$ can have its mean outside $K$.
:::

::: {custom-style="Statement Tag"}
The first statement follows from Part III, Proposition 3.7; the second is New in Part V.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Reads are convex combinations of records, and the output of a deterministic stack is a convex combination of its starting state and its reads (Part III, Theorem 3.1). For the second statement, take Proposition 2.5 with $K=\{x:x_1+x_2\ge0.5\}$. ∎

::: {custom-style="Check"}
*Numerical check.* In Proposition 2.5's example both means satisfy $x_1+x_2\ge0.5$, their midpoint does, and the product mean, with coordinate sum 0.0198, does not. For boxes, all of 40,000 recombined children were feasible in every dimension tested.
:::


## 5 Explorations

### 5.1 Which fusion rule is calibrated

Two experts in $ℝ^2$ have error covariances $\text{diag}(1,0.3)$ and $\text{diag}(0.3,1)$, with cross-covariance $cL_aL_b^{\top}$. For $c=0$, 0.3, 0.6 and 0.9 we drew 4,000 error pairs and recorded how often the fused error fell inside the 90% ellipse that each rule claims. The rules were the product of experts, covariance intersection, and the exact linear fusion that knows $c$ (Figure 2a).

The exact rule covered 0.895, 0.898, 0.897 and 0.899, as it should. The product covered 0.895 at $c=0$, where it is exact, and then 0.832, 0.775 and 0.736. Covariance intersection covered 0.990, 0.973, 0.949 and 0.928. It was conservative everywhere, most at $c=0$, where it gives up the information that the experts are independent.

The choice therefore depends on what is known. Use the exact rule, or the product with shared factors divided out (Proposition 2.3), when the common information is known. When it is not, use covariance intersection and report it as conservative. The plain product is safe only when the experts read disjoint evidence. In ASE that would require disjoint archives.

### 5.2 How often recombined children are feasible

For each set we drew 40,000 pairs of parents uniformly from it and formed children by uniform crossover (Figure 2b). For the unit box every child was feasible, as Theorem 4.4 says. For the unit ball the feasible share fell from 0.953 in two dimensions to 0.813 in six and 0.698 in sixteen. For the simplex $\{x\ge0,\sum_ix_i\le1\}$ it fell from 0.918 to 0.742 and 0.642. The C# kernel, with its own random stream, gave 0.734 for the simplex in six dimensions.

The losses grow with dimension but do not collapse, because a child keeps about half of each parent and only the coupled constraints fail. A run with coupled constraints should either repair children by conditioning (Proposition 4.1), or recombine only across blocks between which no constraint couples, the case Theorem 4.4 allows.

![**Figure 2.** (a) Coverage of the claimed 90% ellipse for three fusion rules, against the correlation of the experts' errors. (b) Share of feasible children of uniform crossover for parents drawn uniformly from a box, a ball and a simplex, against dimension (Theorem 4.4).](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p5/fig/calibration.png){width=100%}


## 6 Discussion

### 6.1 What Part V supplies to the book

Part VI, on evidence and computation, takes three things from this paper as specifications. Every fused law should name its fusion rule and its assumptions about correlation. Every constraint should be reported as hard, by conditioning or rejection, or soft, with its penalty and the bound (4.1). Every recombination operator should be checked against the product structure of the feasible set. The kernel of Appendix A implements the rules.

For the earlier parts, Proposition 2.5 adds fusion to the novelty channels of Part III as a soft form of the map channel. Theorem 3.1 settles the warning of Part II: a product of experts on a cover counts every overlap twice, while marginal extension does not. Proposition 3.2 gives Part I's cycles a probabilistic meaning: local agreement on a loop does not guarantee a global law.

### 6.2 Diagnostics a fusion should report

Table: **Table 2.** Diagnostics reported with every fusion and constraint.

| Diagnostic | Source | Action when it is poor |
|:-------------------|:-------------------|:-------------------------------|
| shared factors among experts | Proposition 2.3 | divide them out, or use covariance intersection |
| fusion rule and its correlation assumption | Proposition 2.4, Section 5.1 | report coverage, not only the claimed covariance |
| whether fused means left the hull of the expert means | Proposition 2.5 | treat as recombination; check constraints |
| separators of the cover and their multiplicity in the product | Theorem 3.1 | use marginal extension |
| positive semidefiniteness of glued covariances on cycles | Proposition 3.2 | do not glue; report the obstruction |
| constraint type, penalty $\gamma$ and the bound (4.1) | Propositions 4.1, 4.2 | condition, or raise $\gamma$ |
| acceptance $q(K)$ and $\pi(K)$ | Proposition 4.3 | move the proposal towards $K$ |
| product structure of the feasible set across recombined blocks | Theorem 4.4 | repair or restrict recombination |

### 6.3 What is not claimed

The statements concern Gaussian experts and linear or set constraints. Nonlinear constraints, non-Gaussian experts and learned surrogates with unknown error structure are outside them, although Theorem 4.4 and Proposition 3.2 do not need Gaussianity. Covariance intersection is conservative, not optimal; tighter consistent rules exist for structured correlations and are not studied here. The explorations use synthetic laws and sets. They measure calibration and feasibility, not design quality.

### 6.4 Open problems

1. **Shared archives.** Estimate the common information between two ASE reads from their shared records, so that Proposition 2.3 can be applied without knowing the shared factor in closed form.
2. **Cycles in covers.** Find the closest jointly consistent family to pairwise-consistent marginals on a cycle, and relate its distance to the frustration measures of Part I.
3. **Constraint-aware recombination.** Characterise the coarsest block partition across which a given constraint set is a product, and recombine only across it.
4. **Penalties and targets.** Combine Proposition 4.2 with the error ledger of Part IV, so that a soft constraint enters an estimate with a bounded, reported error.
5. **Non-Gaussian fusion.** Extend Proposition 2.5 and Theorem 3.1 to exponential-family experts, where products still add natural parameters.

### 6.5 Conclusion

Fusion in ASE is not one operation. A product of experts adds precisions and is exact only for experts with disjoint evidence. It counts shared archives and the separators of a cover once per factor, and it can move its mean outside the hull of the experts and outside a convex feasible set. Covariance intersection is safe when the correlation is unknown, at the price of conservatism. Marginal extension is exact on a tree of cliques and can fail with no local symptom on a cycle. Constraints act by conditioning, approximately by penalties at rate $1/\gamma$, or by rejection at an exact cost. Recombination keeps feasibility only across blocks between which no constraint couples. Part VI takes these as the contracts an implementation must report.


## 7 Register of numerical checks

Table 3 lists every numerical check in Part V. The script `p5_checks.py` produced checks 1 to 12 and both explorations with seed 20261023, and the kernel comparison of Appendix A is check 13. The checks test the implementations and illustrate the statements; the proofs establish them.

Table: **Table 3.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 2.2 | 300 random products | constant to 1.4 × 10⁻¹⁴ |
| 2 | Proposition 2.3 | four experts with a shared factor | trace ratio 0.611; corrected to 1.3 × 10⁻¹⁵ |
| 3 | Proposition 2.4 | 400 correlated pairs | 0 violations; product understated 196 |
| 4 | Proposition 2.5 | example; 2,000 triples; 2,000 in 1-D | $(0.0099,0.0099)$; 1,095 outside; 0 outside |
| 5 | Theorem 3.1 | 300 random laws | marginals to 2.7 × 10⁻¹⁵; separator ratio 2 |
| 6 | Proposition 3.2 | four correlations | smallest eigenvalue −0.8 at $r=-0.9$ |
| 7 | Proposition 4.1 | two constraints in $ℝ^4$ | residual 6.7 × 10⁻¹⁶ |
| 8 | Proposition 4.2 | five penalty strengths | 0 violations; slope −0.994 |
| 9 | Proposition 4.3 | identity against Monte Carlo | 1.2665 against 1.2670 |
| 10 | Theorem 4.4 | boxes, 8 dimensions | all children feasible |
| 11 | Proposition 4.5 | example | means and read feasible; product infeasible |
| 12 | Section 5 | calibration and recombination | product 0.736 at $c=0.9$; simplex 0.642 in $ℝ^{16}$ |
| 13 | Appendix A | C# kernel against NumPy | 9 of 9 lines agree |

## References for Part V

::: {custom-style="Bibliography"}
[1] Bar-Shalom, Y., Li, X. R. and Kirubarajan, T. (2001). *Estimation with Applications to Tracking and Navigation*. Wiley.

[2] Rasmussen, C. E. and Williams, C. K. I. (2006). *Gaussian Processes for Machine Learning*. MIT Press.

[3] Lauritzen, S. L. (1996). *Graphical Models*. Oxford University Press.

[4] Julier, S. J. and Uhlmann, J. K. (1997). A non-divergent estimation algorithm in the presence of unknown correlations. *Proceedings of the American Control Conference*, 2369–2373.

[5] Grime, S. and Durrant-Whyte, H. F. (1994). Data fusion in decentralized sensor networks. *Control Engineering Practice* 2(5), 849–863.

[6] Hinton, G. E. (2002). Training products of experts by minimizing contrastive divergence. *Neural Computation* 14(8), 1771–1800.

[7] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[8] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[9] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[10] Ghosh, D. P. (2026d). *Horizontally Topological, Vertically Algebraic: The Two Axes of Autoregressive Sheaf Evolution. Part I: Sheaves on Covers and Representations of the Layer Order*. 18 October 2026.

[11] Ghosh, D. P. (2026e). *The Horizontal Layer: One Layer of Autoregressive Sheaf Evolution. Part II: Sheaf Attention, Gaussian Stalks, Locality and the Topology of Design Spaces*. 18 October 2026.

[12] Ghosh, D. P. (2026f). *The Vertical Stack: Layers of Autoregressive Sheaf Evolution. Part III: The Token Recurrence, Tangent Dynamics and Persistence across Layers*. 18 October 2026.

[13] Ghosh, D. P. (2026g). *Targets and Estimation: What Autoregressive Sheaf Evolution Can Estimate. Part IV: Gibbs Targets, Proposal Laws, Importance Weights and Error Budgets*. 21 October 2026.

[14] Nocedal, J. and Wright, S. J. (2006). *Numerical Optimization*, 2nd edn. Springer.

[15] Syswerda, G. (1989). Uniform crossover in genetic algorithms. *Proceedings of the Third International Conference on Genetic Algorithms*, 2–9.

[16] Vorob'ev, N. N. (1962). Consistent families of measures and their extensions. *Theory of Probability and Its Applications* 7(2), 147–163.

[17] Steele, G. L., Lea, D. and Flood, C. H. (2014). Fast splittable pseudorandom number generators. *Proceedings of OOPSLA 2014*, 453–472. ACM.
:::

## Appendix V.A: an immutable C# reference kernel

The kernel represents experts in information form as immutable records. It implements the product of experts, the division of a shared factor, covariance intersection with a grid search for the weight, conditioning on linear constraints, the quadratic penalty and coordinate recombination. A Gauss–Jordan solver works on private copies of its inputs. The random stream is a SplitMix64 generator [17], held as a value. The kernel targets .NET 8 and uses only the base class library.

```csharp
// ASE Part V reference kernel: Gaussian fusion rules and linear constraints.
// Immutable values and pure functions; the solver works on private copies.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AsePartFive;

/// <summary>A dense real matrix stored row-major.</summary>
public sealed record Mat(int Rows, int Cols, Vec Data)
{
    public double this[int r, int c] => Data[r * Cols + c];

    public static Mat Of(int r, int c, Func<int, int, double> f) =>
        new(r, c, Enumerable.Range(0, r * c).Select(k => f(k / c, k % c)).ToImmutableArray());

    public static Mat Identity(int n) => Of(n, n, (i, j) => i == j ? 1 : 0);
    public static Mat Diag(params double[] d) => Of(d.Length, d.Length, (i, j) => i == j ? d[i] : 0);
    public Mat T => Of(Cols, Rows, (i, j) => this[j, i]);
    public Mat Mul(Mat b) => Of(Rows, b.Cols,
        (i, j) => Enumerable.Range(0, Cols).Sum(k => this[i, k] * b[k, j]));
    public Vec Apply(Vec v) => Enumerable.Range(0, Rows)
        .Select(i => Enumerable.Range(0, Cols).Sum(k => this[i, k] * v[k])).ToImmutableArray();
    public Mat Add(Mat b, double s = 1) => Of(Rows, Cols, (i, j) => this[i, j] + s * b[i, j]);
    public Mat Scale(double s) => Of(Rows, Cols, (i, j) => s * this[i, j]);
    public double Trace => Enumerable.Range(0, Rows).Sum(i => this[i, i]);

    /// <summary>Solves this X = B by Gauss-Jordan elimination with partial pivoting.</summary>
    public Mat Solve(Mat b)
    {
        int n = Rows, m = b.Cols;
        var a = Enumerable.Range(0, n).Select(i => Enumerable.Range(0, n).Select(j => this[i, j])
            .Concat(Enumerable.Range(0, m).Select(j => b[i, j])).ToArray()).ToArray();
        for (int c = 0; c < n; c++)
        {
            int p = Enumerable.Range(c, n - c).OrderByDescending(r => Math.Abs(a[r][c])).First();
            (a[c], a[p]) = (a[p], a[c]);
            for (int r = 0; r < n; r++)
            {
                if (r == c) continue;
                double f = a[r][c] / a[c][c];
                for (int k = c; k < n + m; k++) a[r][k] -= f * a[c][k];
            }
        }
        return Of(n, m, (i, j) => a[i][n + j] / a[i][i]);
    }

    public Mat Inverse() => Solve(Identity(Rows));
    public Vec SolveVec(Vec v) => Solve(Of(v.Length, 1, (i, _) => v[i])).Data;
}

/// <summary>A Gaussian expert in information form: mean and precision.</summary>
public sealed record Expert(Vec Mean, Mat Precision);

public static class Fusion
{
    /// <summary>Product of experts (Proposition 2.2): precisions add, means are
    /// precision-weighted.</summary>
    public static Expert Product(ImmutableArray<Expert> es)
    {
        var l = es.Skip(1).Aggregate(es[0].Precision, (acc, e) => acc.Add(e.Precision));
        var h = es.Select(e => e.Precision.Apply(e.Mean))
                  .Aggregate((a, b) => a.Zip(b, (x, y) => x + y).ToImmutableArray());
        return new Expert(l.SolveVec(h), l);
    }

    /// <summary>Removes a factor that k experts share, counted k - 1 times too often
    /// (Proposition 2.3).</summary>
    public static Expert Divide(Expert fused, Expert shared, int extraCount)
    {
        var l = fused.Precision.Add(shared.Precision, -extraCount);
        var h = fused.Precision.Apply(fused.Mean)
            .Zip(shared.Precision.Apply(shared.Mean), (a, b) => a - extraCount * b)
            .ToImmutableArray();
        return new Expert(l.SolveVec(h), l);
    }

    /// <summary>Covariance intersection of two estimates (Proposition 2.4), with the
    /// weight chosen on a grid to minimise the trace of the fused covariance.</summary>
    public static (Vec Mean, Mat Covariance, double Omega) Intersect(
        Vec a, Mat pa, Vec b, Mat pb, int grid = 999)
    {
        Mat ia = pa.Inverse(), ib = pb.Inverse();
        double w = Enumerable.Range(1, grid).Select(i => i / (grid + 1.0))
            .OrderBy(x => ia.Scale(x).Add(ib, 1 - x).Inverse().Trace).First();
        var l = ia.Scale(w).Add(ib, 1 - w);
        var h = ia.Scale(w).Apply(a).Zip(ib.Scale(1 - w).Apply(b), (x, y) => x + y)
                  .ToImmutableArray();
        return (l.SolveVec(h), l.Inverse(), w);
    }

    /// <summary>Hard linear constraint A x = b by conditioning (Proposition 4.1).</summary>
    public static Vec Condition(Vec mu, Mat sigma, Mat a, Vec b)
    {
        var sat = sigma.Mul(a.T);
        var r = a.Apply(mu).Zip(b, (x, y) => x - y).ToImmutableArray();
        var c = sat.Apply(a.Mul(sat).SolveVec(r));
        return mu.Zip(c, (x, y) => x - y).ToImmutableArray();
    }

    /// <summary>Soft penalty exp(-gamma |A x - b|^2 / 2) (Proposition 4.2).</summary>
    public static Vec Penalise(Vec mu, Mat sigma, Mat a, Vec b, double gamma)
    {
        var l = sigma.Inverse().Add(a.T.Mul(a), gamma);
        var h = sigma.SolveVec(mu).Zip(a.T.Apply(b), (x, y) => x + gamma * y)
                     .ToImmutableArray();
        return l.SolveVec(h);
    }

    /// <summary>A child taking each coordinate from x where mask is true, else from y.</summary>
    public static Vec Recombine(Vec x, Vec y, ImmutableArray<bool> mask) =>
        x.Select((v, i) => mask[i] ? v : y[i]).ToImmutableArray();
}

/// <summary>SplitMix64 stream with uniform draws; each draw returns the next state.</summary>
public sealed record Rng(ulong State)
{
    public (double Value, Rng Next) Uniform()
    {
        ulong s = State + 0x9E3779B97F4A7C15UL, z = s;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
        return (((z ^ (z >> 31)) >> 11) * (1.0 / 9007199254740992.0), new Rng(s));
    }
}
```

The driver prints the example of Proposition 2.5, the naive and corrected products of four experts sharing a factor, a covariance intersection, a conditioned mean, and the distance of three penalised means from it. It ends with the feasible share of 20,000 recombined children of uniform simplex points in $ℝ^6$, drawn from its own stream. An independent NumPy script recomputes every line, building the exact posterior directly rather than by division (Table A1). Relative differences are reported where they are meaningful. For the penalty distances, which are small differences of nearly equal vectors, the absolute difference is reported; the largest is 2.3 × 10⁻¹³.

Table: **Table A1.** C# kernel output against the NumPy recomputation.

| C# | NumPy | Difference |
|:------------------|:------------------|:----------|
| `poe_mean 0.009900990099009901 0.009900990099009901` | `poe_mean 0.009900990099009901 0.009900990099009901` | identical |
| `naive_mean 0.5096979332273449 0.21271860095389508` | `naive_mean 0.5096979332273449 0.21271860095389508` | identical |
| `corrected_mean 0.5535914416709118 0.5138053998981152 20.2` | `corrected_mean 0.5535914416709119 0.5138053998981152 20.2` | 2.0 × 10⁻¹⁶ |
| `covariance_intersection 0.23076923076923073 0.23076923076923073 0.9230769230769229 0.5` | `covariance_intersection 0.23076923076923073 0.23076923076923073 0.9230769230769229 0.5` | identical |
| `condition 0.2205128205128205 -⁠0.36666666666666675 1.146153846153846 0.9999999999999998` | `condition 0.2205128205128205 -⁠0.36666666666666675 1.146153846153846 0.9999999999999998` | identical |
| `penalty_1 0.006876703800236604` | `penalty_1 0.006876703800236496` | 1.6 × 10⁻¹⁴ |
| `penalty_100 7.748398648293636E-⁠05` | `penalty_100 7.74839864834844e-⁠05` | 7.1 × 10⁻¹² |
| `penalty_10000 7.758240347570785E-⁠07` | `penalty_10000 7.758242648336553e-⁠07` | absolute 2.3 × 10⁻¹³ |
| `simplex_children_feasible 0.73435` | `simplex_children_feasible 0.73435` | identical |

## Appendix V.B: reproducibility

All results were produced with Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1, Matplotlib 3.11.2 and .NET SDK 8.0.131. The script `p5_checks.py` writes `p5_checks.json` with seed 20261023, and `fig_p5.py` draws the figures from it; the ellipses and the eigenvalue curve are analytic. The C# project in `cs/` builds the kernel and its driver, and `cs_validate.py` compares the driver's output with NumPy and writes `cs_validate.json`. The document is converted to Word by Pandoc and post-processed for equation layout and schema order. A code archive accompanies this paper.


# Part VI · Evidence and Computation

::: {custom-style="Subtitle"}
Making Autoregressive Sheaf Evolution checkable. Part VI: stable and certified reads, the arithmetic of evidence, and the contracts of an implementation
:::

**Summary of Part VI.** Parts I to V of Autoregressive Sheaf Evolution (ASE) proved what a layer, a stack, an estimate and a fusion compute. This paper, Part VI and the last part of the book, asks what it takes to compute them reliably and to claim anything from the results. On computation, unshifted exponentials failed in 57% of reads at scale 0.03 and in 99.8% at 0.003, while shifted ones agreed with an extended-precision reference to $1.7\times10^{-14}$. We give a certificate for reads restricted to the $k$ nearest records. It was never violated in 1,200 reads, but it is honest only where the omitted mass is genuinely small: it certified an omitted share of 0.035 at $k=512$ of 2,000, and almost nothing at $k=8$. Reordering a sum stays within Higham's bound, which fixes the tolerance a cross-language comparison may use. On evidence, we restate four classical rules in ASE terms: paired sample sizes, Holm's correction, selection optimism, and the limits of in-sample diagnostics. Part III's pilot made 72 comparisons; under the null, an uncorrected family of that size errs with probability 0.975. Choosing the best of seven schedules on the same data inflates the winner by 1.35 standard errors on average. We prove that the in-sample estimate of the weight second moment never exceeds the number of draws, so no finite sample can reveal infinite variance. An exploration on Part IV's double well shows the consequence. Selecting the importance width by in-sample effective size picked a width with infinite-variance weights in 54.5% of runs with 100 draws per width and 69.5% with 500, while reporting a second moment of 2.5 and 5.1 against a true optimum of 9.5. The paper closes the book with the contracts an ASE implementation must report, a register of the evidence of all six parts, and the status of hypotheses C1 to C5. There are 8 numerical checks and one exploration, and an immutable C# kernel matches an independent NumPy implementation on every output line.

## 1 Introduction

Autoregressive Sheaf Evolution (ASE) generalises the reads of Autoregressive Diffusion Evolution (ADE) to observation stars with edge maps and scale-dependent covers [7, 8, 9]. Five parts of this book have built its mathematics. Part I separated the horizontal and vertical axes [10]. Part II worked out one layer [11] and Part III a stack [12]. Part IV fixed the target of a run [13], and Part V the rules for fusion and constraints [14]. Each part ended by passing obligations forward. Part II asked Part VI to turn its retention rule, certificates and index contract into kernel specifications. Part III passed on the diagnostics of a stack, Part IV the error ledger of an estimate, and Part V the contracts of fusion. This paper, Part VI, discharges those obligations and asks two final questions. What does it take to compute ASE quantities reliably? And what does it take to claim anything from the results?

The two questions are linked. A number computed unreliably is not evidence, and a reliable number is not evidence either if it was selected from many. The series has met both failures. In the Separator Anchors paper, an undamped Newton solver produced an apparent violation of a proved bound in 247 of 400 trials; a stationarity certificate exposed it as a solver failure [15]. In Part III, a pilot made 72 comparisons, and its verdict needed a declared decision rule to mean anything [12, Section 5.3]. Part VI makes such lessons into rules.

### 1.1 Contributions

- **Computation (Section 2).** Shifted exponentials are necessary at the fine scales where ASE resolves records (Proposition 2.2). A read over the $k$ nearest records carries a certificate on its omitted share and its error (Proposition 2.3). Summation order bounds the disagreement between correct implementations (Proposition 2.4).
- **Evidence (Section 3).** Paired sample sizes, family-wise correction and selection optimism, stated for ASE comparisons (Propositions 3.1 to 3.3). The in-sample estimate of the weight second moment is at most the number of draws, so infinite variance is invisible in sample (Proposition 3.4). An exploration measures what selecting by that estimate does.
- **Contracts (Section 4).** A consolidated list of what every layer, stack, estimate and fusion must report. A rule for numerical counterexamples (Proposition 4.1). A register of the evidence of all six parts, and the status of the hypotheses of V2.
- **Evidence.** There are 8 numerical checks and one exploration (Table 4). An immutable C# kernel agrees with an independent NumPy implementation on every output line (Appendix A).

### 1.2 Scope and status of statements

The computational statements concern IEEE double precision and the Gaussian read with identity maps. The evidential statements are classical results of numerical analysis and statistics, restated for ASE. Their value here is in the specific consequences, which are checked. Every statement in a shaded box ends with a provenance tag. *Classical* marks a known result restated in ASE notation. *Part I* to *Part V* refer to [10] to [14]. *New in Part VI* marks a statement proved here for the first time in this programme; each comes with a proof and a numerical check.


## 2 Computation

### 2.1 Cost

::: {custom-style="Statement"}
**Proposition 2.1** (cost of reads). With $n$ records in $ℝ^D$, a full Gaussian read costs $O(nD)$ operations per token and layer, and a stack of $T$ layers $O(TnD)$ per token. A read over the $k$ nearest records costs $O(kD)$ plus the cost of finding them. With an index whose query cost is sublinear in $n$, the read becomes sublinear too, but only if the certificate of Proposition 2.3 is small enough to accept.
:::

::: {custom-style="Statement Tag"}
Classical accounting; the index contract is Part II, Section 5.3.
:::

::: {custom-style="Gap"}
&nbsp;
:::

The full read is linear in the archive, like attention over a context. Every saving comes from reading fewer records. Every saving therefore needs a statement of what the omitted records could have changed.

### 2.2 Shifted exponentials

::: {custom-style="Statement"}
**Proposition 2.2** (stable reads). Compute the logits $\ell_i=\log w_i-\Vert z-y_i\Vert^2/2s^2$, subtract their maximum, exponentiate and normalise. In exact arithmetic this gives the posterior weights of the read. In floating point, no term overflows, the largest term is exactly one, and the computed weights have small relative error. Without the shift, every term underflows to zero once all logits fall below about $-745$, and the read is $0/0$.
:::

::: {custom-style="Statement Tag"}
Classical; Blanchard, Higham and Higham give the error analysis [1].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Subtracting a constant from every logit multiplies every weight by the same factor, which normalisation removes. After the shift the largest exponent is $0$ and the others are at most $0$. The smallest positive double is about $e^{-745}$. ∎

Fine scales are not an edge case in ASE: the top layers of a stack run at $s$ much smaller than the spacing of the records, and a clean top takes $s_1\to0$ (Part III, Proposition 3.6). The logits scale as $1/s^2$, so the unshifted read fails exactly where the stack makes its decisions.

::: {custom-style="Check"}
*Numerical check.* For 500 random reads of 50 records in $ℝ^3$ at each scale, the unshifted read failed in 0, 4.8, 57.4, 96.2 and 99.8% of cases at $s=1$, 0.1, 0.03, 0.01 and 0.003. The shifted read agreed with an extended-precision reference to 1.7 × 10⁻¹⁴ relative to the record scale, at every scale.
:::

### 2.3 Certified truncation

::: {custom-style="Statement"}
**Proposition 2.3** (a certificate for nearest-record reads). Let the read use only the $k$ records nearest to $z$, and let $d_{(k+1)}$ be the distance to the nearest omitted record. Put $L_K=\log\sum_{i\le k}e^{\ell_i}$ over the kept records and
:::

::: {custom-style="Statement Equation"}
$L_O=\log(n-k)+\max_i\log w_i-\frac{d_{(k+1)}^2}{2s^2},\qquad\varepsilon=\frac{1}{1+e^{L_K-L_O}}$ (2.1)
:::

::: {custom-style="Statement"}
Then the posterior share of the omitted records is at most $\varepsilon$, and the truncated read differs from the full read by at most $\varepsilon\,\text{diam}\{y_i\}$.
:::

::: {custom-style="Statement Tag"}
New in Part VI in this nearest-record form; Part II, Section 5, gives certificates for stars.
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* Each omitted logit is at most $\max_i\log w_i-d_{(k+1)}^2/2s^2$, so the omitted mass is at most $e^{L_O}$. The omitted share $O/(K+O)$ increases in $O$, which gives $\varepsilon$. The full read is $(1-\varepsilon')m_K+\varepsilon'm_O$, where $\varepsilon'\le\varepsilon$ is the true share and $m_K,m_O$ are the reads over the kept and omitted records. Both lie in the hull of the records, so the difference from $m_K$ is $\varepsilon'\Vert m_O-m_K\Vert\le\varepsilon\,\text{diam}$. ∎

The certificate also feeds Part IV. A proposal density evaluated on the $k$ nearest components satisfies Proposition 4.4 of Part IV with $\kappa=\log(1/(1-\varepsilon))$.

::: {custom-style="Check"}
*Numerical check.* With 2,000 records in $ℝ^4$, scale 0.5 and 300 random queries for each $k$, the certificate was never violated. The certified omitted share had medians 0.999, 0.991, 0.884 and 0.035 for $k=8$, 32, 128 and 512. The largest actual error was 0.036, 0.019, 0.010 and 0.0021 of the certified bound.
:::

The certificate is valid but crude. Its worst case puts all the omitted records at the nearest omitted distance, so it certifies almost nothing until $k$ is a sizeable fraction of the archive; here, at a quarter of the archive, it certified an omitted share of 3.5%. The actual errors were about 28 to 480 times smaller than the bound. A sharper certificate needs a bound on how many records lie in each shell around the query, which is what a spatial index can supply (open problem 2).

### 2.4 Summation order

::: {custom-style="Statement"}
**Proposition 2.4** (implementations may disagree, within a bound). Any recursive summation of $x_1,\ldots,x_n$ in floating point with unit roundoff $u$ differs from the exact sum by at most $\gamma_{n-1}\sum_i|x_i|$, where $\gamma_m=mu/(1-mu)$. Two correct implementations that sum in different orders therefore differ by at most $2\gamma_{n-1}\sum_i|x_i|$.
:::

::: {custom-style="Statement Tag"}
Classical, Higham [3, Section 4.2].
:::

::: {custom-style="Gap"}
&nbsp;
:::

This is the rule behind every cross-language comparison in the series. NumPy and C# sum in different orders, so their outputs cannot be expected to agree to the last digit. They should agree to within the bound, scaled by the sum of absolute values, not the result. When the result is a small difference of large terms, as in the penalty distances of Part V, an absolute tolerance is the right one.

::: {custom-style="Check"}
*Numerical check.* For 200 sums of 10,000 terms with magnitudes spread over many orders, a randomly permuted recursive sum differed from the exactly rounded sum by at most 0.0026 of the bound.
:::

![**Figure 1.** (a) Share of reads in which unshifted exponentials underflow, against the scale; shifted reads never fail (Proposition 2.2). (b) For reads over the $k$ nearest of 2,000 records: the certified omitted share (median) and the largest ratio of the actual error to its certified bound (Proposition 2.3).](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p6/fig/computation.png){width=100%}


## 3 Evidence

### 3.1 Paired comparisons and their size

Every comparison in the series, of schedules, proposals or fusion rules, is paired: both arms see the same archives, tokens or draws. Pairing removes the shared variation, and the sample size follows from the variation that remains.

::: {custom-style="Statement"}
**Proposition 3.1** (paired sample size). To detect a mean paired difference $\delta>0$ with standard deviation $\sigma_d$ by a one-sided test at level $\alpha$ with power $1-\beta$, about
:::

::: {custom-style="Statement Equation"}
$n=\left\lceil\frac{(z_{1-\alpha}+z_{1-\beta})^2\sigma_d^2}{\delta^2}\right\rceil$ (3.1)
:::

::: {custom-style="Statement"}
pairs are needed, with $z_p$ the standard normal quantile. A non-inferiority test with margin $\delta$ uses the same formula.
:::

::: {custom-style="Statement Tag"}
Classical.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* For $\delta=0.02$, $\sigma_d=0.06$, $\alpha=0.05$ and power 0.8, (3.1) gives 56 pairs. In 20,000 simulated studies, a one-sided paired $t$-test with 56 pairs had power 0.788 and size 0.049. The normal formula slightly overstates the power of the $t$-test at this size.
:::

### 3.2 Many comparisons

::: {custom-style="Statement"}
**Proposition 3.2** (family-wise error). If $m$ independent null comparisons are each tested at level $\alpha$, at least one rejects with probability $1-(1-\alpha)^m$. Holm's step-down procedure, which compares the $r$-th smallest $p$-value with $\alpha/(m-r+1)$ and stops at the first failure, controls this probability at $\alpha$ for any dependence among the tests.
:::

::: {custom-style="Statement Tag"}
Classical, Holm [4].
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* With $m=72$, the size of Part III's pilot, 20,000 simulated families of null $p$-values had a family-wise error of 0.975 without correction, as the formula says, and 0.049 with Holm's procedure.
:::

Part III's pilot did not test 72 null hypotheses and reject some. It declared a decision rule with intervals in advance, and every comparison fell outside the margin. The verdict is robust to correction for that reason. A future study that reports the best of many comparisons should state its family and correct for it.

### 3.3 Choosing the best

::: {custom-style="Statement"}
**Proposition 3.3** (selection optimism). If $m$ candidates have equal true value and independent estimates with standard error $\sigma$, the estimate of the selected best exceeds the truth by $\sigma\,E\max(Z_1,\ldots,Z_m)$ on average, where the $Z_j$ are standard normal. This is at most $\sigma\sqrt{2\log m}$.
:::

::: {custom-style="Statement Tag"}
Classical.
:::

::: {custom-style="Gap"}
&nbsp;
:::

::: {custom-style="Check"}
*Numerical check.* With 200,000 simulations, the mean maximum was 0.564, 1.351 and 2.160 for $m=2$, 7 and 40, against the bounds 1.18, 1.97 and 2.72.
:::

Part III compared seven schedules and Part IV scanned 40 widths. A winner chosen among seven on the same data looks better than it is by 1.35 standard errors on average, even when all seven are equal. Its value must be confirmed on fresh data, which is why Part III proposed the curvature schedule for a confirmatory test rather than declaring it best.

### 3.4 What in-sample diagnostics cannot see

Part IV showed that importance weights from an archive proposal have infinite second moment below a width threshold. A natural repair is to measure the second moment in sample and choose the width that minimises it. That repair fails.

::: {custom-style="Statement"}
**Proposition 3.4** (infinite variance is invisible in sample). For any positive weights $w_1,\ldots,w_n$, the in-sample second-moment estimate satisfies
:::

::: {custom-style="Statement Equation"}
$1\le\hat m_2=\frac{n\sum_iw_i^2}{\left(\sum_iw_i\right)^2}\le n$ (3.2)
:::

::: {custom-style="Statement"}
So no sample of size $n$ can report a second moment above $n$, whatever the true $m_2$ is, including $m_2=\infty$. When $m_2=\infty$, the heavy tail that makes it infinite is rarely sampled, and $\hat m_2$ is usually small.
:::

::: {custom-style="Statement Tag"}
New in Part VI as stated; the inequalities are elementary, and the effective sample size $n/\hat m_2$ is Kong's [5].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* By the Cauchy–Schwarz inequality $(\sum_iw_i)^2\le n\sum_iw_i^2$, which gives the lower bound. For positive weights $\sum_iw_i^2\le(\sum_iw_i)^2$, which gives the upper bound. ∎

### 3.5 Exploration: choosing an importance width in sample

We repeated Part IV's width scan as a selection procedure. For each of 200 runs, we drew $n$ points at each of the 40 widths from Part IV's archive proposal on the double well. We computed $\hat m_2$ for each width and selected the width with the smallest value. We then looked up the true $m_2$ of the selected width from Part IV's quadrature (Figure 2).

With $n=100$ draws per width, the selected width had infinite true second moment in 54.5% of runs. With $n=500$ the share rose to 69.5%; with $n=2000$ it fell to 5.5%. The selected widths reported median in-sample values of 2.46, 5.07 and 9.01. The smallest true second moment over all widths is 9.50, so the winners looked better than any width actually is. With 500 draws the procedure was worse than with 100. More draws made the narrow widths look better, because their tails were still unsampled while their bulk looked well matched. Only at 2,000 draws did the tails appear often enough to reveal them. The median selected width was then 1.17, the true optimum.

The remedy is not more care in sample. It is a declared rule that does not depend on the sample: here, the threshold of Part IV, Proposition 3.4, or a defensive component that makes every width safe. Where no such rule exists, selection must be confirmed on held-out draws, at a sample size planned in advance.

![**Figure 2.** Selecting the importance width by in-sample effective size, in 200 runs for each number of draws per width. (a) Share of runs in which the selected width had infinite true second moment. (b) Median in-sample $\hat m_2$ of the selected width, against the smallest true $m_2$ over all widths (dashed).](/tmp/claude-0/-home-claude/cd2892aa-5f27-5f75-9994-b975dfc1c6d9/scratchpad/p6/fig/selection.png){width=100%}


## 4 Contracts of an ASE implementation

### 4.1 What every computation reports

Table 1 consolidates the diagnostics that Parts II to V asked an implementation to report. It is the specification against which an implementation is defensible. Each row names the part that requires it.

Table: **Table 1.** The reporting contract of an ASE implementation.

| Object | Must report | Source |
|:----------------|:------------------------------------------|:------------------|
| layer | smallest coverage or $\lambda_{\text{min}}(H)$; unresolved dimension; guaranteed decrease; Jacobian bound; branch weights | Part II, Table 7 |
| read | shifted computation; truncation certificate $\varepsilon$ and $k$ | Propositions 2.2, 2.3 |
| stack | starting-state weight and noise budget; top posterior eigenvalues; expanding layers; exact barcodes; curvature density and efficiency | Part III, Table 6 |
| estimate | base law and temperature; archive effective size; hull mass; width against the threshold; defensive share; both ledger terms | Part IV, Table 4 |
| fusion | rule and correlation assumption; shared factors; separator multiplicity; positive semidefiniteness on cycles | Part V, Table 2 |
| constraint | type, penalty and bound; acceptance; product structure across recombined blocks | Part V, Table 2 |
| comparison | family of tests and correction; pairing; sample size planned by (3.1); held-out confirmation of any selection | Section 3 |

### 4.2 Numerical counterexamples

::: {custom-style="Statement"}
**Proposition 4.1** (a counterexample must carry its certificate). Suppose a theorem bounds a quantity $Q(z^{\text{*}})\le B$ at an exact solution $z^{\text{*}}$, and $Q$ is $L$-Lipschitz. A computed $\hat z$ with a certificate $\Vert\hat z-z^{\text{*}}\Vert\le c$ establishes a violation only if $Q(\hat z)-B>Lc$. Without a certificate, a measured $Q(\hat z)>B$ establishes nothing about the theorem.
:::

::: {custom-style="Statement Tag"}
New in Part VI as a rule; the certificate for strongly convex reads is Separator Anchors, Version 3, Section 15.2 [15].
:::

::: {custom-style="Gap"}
&nbsp;
:::

*Proof.* $Q(z^{\text{*}})\ge Q(\hat z)-Lc>B$. Without $c$, the gap between $\hat z$ and $z^{\text{*}}$ is unbounded, and so is the gap between $Q(\hat z)$ and $Q(z^{\text{*}})$. ∎

The rule is simple, and the series needed it. An undamped Newton solver reported 247 apparent violations of a proved bound in 400 trials; every one of them failed its certificate [15]. A defensible numerical result reports the certificate with the number.

### 4.3 Cross-language validation

Every part of the book ran an immutable C# kernel against an independent NumPy implementation. The protocol that emerged has four rules.

1. **Same inputs.** Both languages generate their random inputs from the same SplitMix64 stream [6] with the same Box–Muller transform, so they see bit-identical data.
2. **Different algorithms.** The second implementation uses different numerical routines where it can, such as LAPACK solves instead of Gauss–Jordan elimination, so that agreement is evidence about the mathematics, not about a shared bug.
3. **Tolerances from Proposition 2.4.** Relative differences of $10^{-9}$ for ordinary quantities, absolute ones for small differences of large terms, and wider ones for finite differences, stated in advance.
4. **Certificates before verdicts.** No disagreement and no violation is reported without the certificate of Proposition 4.1.

### 4.4 The evidence of the book

Table: **Table 2.** Numerical evidence across the six parts. Kernel lines are compared between C# and NumPy.

| Part | Subject | Checks | Explorations | Kernel lines agreeing |
|:----|:--------------|:------|:----------------|:--------|
| I | the two axes | 20 | none | all |
| II | the horizontal layer | 34 | none | all |
| III | the vertical stack | 21 | C3 pilot, 72 comparisons | 18 of 18 |
| IV | targets and estimation | 16 | width scan, 40 widths | 9 of 9 |
| V | fusion and constraints | 13 | calibration; recombination | 9 of 9 |
| VI | evidence and computation | 8 | width selection in sample | 7 of 7 |

All of these are checks of mathematics, plus exploratory computations on synthetic examples. None is a confirmatory test of a hypothesis about engineering search. Table 3 records what the six parts established about the hypotheses of V2.

Table: **Table 3.** Status of the hypotheses of the conversion proposal V2 after the six parts.

| Label | Subject | What the book established | Status |
|:--------|:------------|:------------------------------------|:--------------|
| C1 | adaptive geometry retains estimation quality: RMSE at most 1.5 times a fixed-cover comparator | defensive mixtures, the width threshold and the error ledger (Part IV, Theorems 3.5 and 5.1); adaptive covers themselves not studied | open; prerequisites supplied |
| C2 | recombination halves costly evaluations on chain objectives | the mechanism and its ceiling (Part II, Proposition 3.5); feasibility only across product blocks (Part V, Theorem 4.4) | open; qualified; V2's recommended first experiment |
| C3 | schedules from component persistence match twice as many cosine layers | refuted in all 72 comparisons of an exploratory transport pilot (Part III, Section 5.3); replacement statements proposed | refuted in exploration; confirmatory test pending |
| C4 | transport reduces physical re-selection by 30 points on a mirror-symmetric truss | orbit indexes and the failure of continuous canonicalisation (Part II, Proposition 6.10); clean-top re-selection (Part III, Proposition 3.6) | open; constrained |
| C5 | local reads use at most 10% of the archive with loss within 1% of ADE | per-layer and composite bounds (Part II, Proposition 5.4; Part III, Theorem 4.2); the nearest-record certificate certified little below a quarter of the archive in Section 2.3 | open; certification at 10% doubtful in the tested setting |


## 5 Discussion

### 5.1 What the book claims

The six parts establish a mathematics of ASE. A layer is a harmonic extension on an observation star. A stack is a schedule acting on reads, and in the continuum limit it transports densities. A run estimates a declared Gibbs target only through a proposal with a known density and coverage. Fusion is several operations, each with its own assumptions. Part VI adds that each of these is computable reliably only with shifted reads and certificates, and that results become evidence only with planned, paired, corrected and confirmed comparisons. The book does not claim that ASE finds better designs than ADE or any other method. That claim belongs to confirmatory experiments, which the contracts of Section 4 make possible to run and to audit.

### 5.2 What is not claimed

The computational statements assume double precision and the Gaussian read with identity maps. The truncation certificate is valid but loose, and sharper ones need index structure. The evidential rules are classical and are restated, not improved. Table 3 records hypotheses, not results: one exploratory refutation and four open questions, as V2 states them [9, Sections 17–18].

### 5.3 Open problems

1. **Confirmatory protocols.** Write and register the confirmatory tests of C2 to C5, with sample sizes from (3.1), the families of Proposition 3.2 and held-out confirmation.
2. **Sharper certificates.** Bound the omitted mass of a nearest-record read by counts of records in distance shells around the query, which a spatial index can provide, and measure the gain over (2.1).
3. **Diagnostics for heavy tails.** Find a diagnostic, beyond the threshold of Part IV, that detects infinite-variance weights with a stated error rate from a finite sample, or prove that none can without assumptions on the target.
4. **Reproducible reductions.** Specify summation orders for kernels so that independent implementations agree bit for bit where that is needed for audit.
5. **Adaptive covers.** Prove consistency of reads with fitted maps and covers, which C1 needs and Parts I to V do not supply.

### 5.4 Conclusion

The book began by reading denoising evolution as layered and horizontally topological. It ends with a list of what an implementation must report. The two are connected. Every theorem of Parts I to V has hypotheses, such as declared maps, a base law, a known proposal density, independent experts or convex constraints. Every hypothesis is either reported by the implementation or it is an assumption the reader cannot check. Part VI asks that each one be reported, together with the certificate of every computed number and the planned family of every comparison. Respect for the science is the obligation to make each claim checkable.


## 6 Register of numerical checks

Table 4 lists every numerical check in Part VI. The script `p6_checks.py` produced checks 1 to 7 and the exploration, with seed 20261024; the exploration reads Part IV's results file for the true second moments. The kernel comparison of Appendix A is check 8.

Table: **Table 4.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 2.2 | 2,500 reads at five scales | naive failure up to 99.8%; stable to 1.7 × 10⁻¹⁴ |
| 2 | Proposition 2.3 | 1,200 truncated reads | 0 violations; error at most 0.036 of the bound |
| 3 | Proposition 2.4 | 200 permuted sums | at most 0.0026 of the bound |
| 4 | Proposition 3.1 | 20,000 simulated studies | 56 pairs; power 0.788; size 0.049 |
| 5 | Proposition 3.2 | 20,000 null families of 72 | 0.975 uncorrected; 0.049 Holm |
| 6 | Proposition 3.3 | 200,000 simulations | 1.351 for seven candidates |
| 7 | Proposition 3.4, Section 3.5 | width selection, 600 runs | 54.5%, 69.5% and 5.5% infinite |
| 8 | Appendix A | C# kernel against NumPy | 7 of 7 lines agree |

## References for Part VI

::: {custom-style="Bibliography"}
[1] Blanchard, P., Higham, D. J. and Higham, N. J. (2021). Accurate computation of the log-sum-exp and softmax functions. *IMA Journal of Numerical Analysis* 41(4), 2311–2330.

[2] Box, G. E. P. and Muller, M. E. (1958). A note on the generation of random normal deviates. *Annals of Mathematical Statistics* 29(2), 610–611.

[3] Higham, N. J. (2002). *Accuracy and Stability of Numerical Algorithms*, 2nd edn. SIAM.

[4] Holm, S. (1979). A simple sequentially rejective multiple test procedure. *Scandinavian Journal of Statistics* 6(2), 65–70.

[5] Kong, A. (1992). A note on importance sampling using standardized weights. Technical Report 348, Department of Statistics, University of Chicago.

[6] Steele, G. L., Lea, D. and Flood, C. H. (2014). Fast splittable pseudorandom number generators. *Proceedings of OOPSLA 2014*, 453–472. ACM.

[7] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[8] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[9] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[10] Ghosh, D. P. (2026d). *Horizontally Topological, Vertically Algebraic: The Two Axes of Autoregressive Sheaf Evolution. Part I*. 18 October 2026.

[11] Ghosh, D. P. (2026e). *The Horizontal Layer: One Layer of Autoregressive Sheaf Evolution. Part II*. 18 October 2026.

[12] Ghosh, D. P. (2026f). *The Vertical Stack: Layers of Autoregressive Sheaf Evolution. Part III*. 18 October 2026.

[13] Ghosh, D. P. (2026g). *Targets and Estimation: What Autoregressive Sheaf Evolution Can Estimate. Part IV*. 21 October 2026.

[14] Ghosh, D. P. (2026h). *Fusion and Constraints: Combining Local Laws in Autoregressive Sheaf Evolution. Part V*. 21 October 2026.

[15] Ghosh, D. P. (2026i). *Separator Anchors for Sheaf Based Latent Reasoning*. Version 4, 20 October 2026.
:::

## Appendix VI.A: an immutable C# reference kernel

The kernel computes the shifted Gaussian read and the nearest-record read with its certificate (2.1). It also gives the paired sample size (3.1) from two normal quantiles, Holm's procedure, and a Monte Carlo estimate of the expected maximum of Proposition 3.3. The random stream is a SplitMix64 generator [6] with Box–Muller normals [2], held as a value. The kernel targets .NET 8 and uses only the base class library.

```csharp
// ASE Part VI reference kernel: stable and certified reads, and the arithmetic of evidence.
// Immutable values and pure functions; the random stream is itself a value.
using System;
using System.Collections.Immutable;
using System.Linq;
using Vec = System.Collections.Immutable.ImmutableArray<double>;

namespace AsePartSix;

/// <summary>A read with its certificate: the bound on the omitted posterior share and on
/// the distance from the full read (Proposition 2.3).</summary>
public sealed record CertifiedRead(Vec Mean, double OmittedShareBound, double ErrorBound, int Used);

public static class Reads
{
    static double LogSumExp(Vec v)
    {
        double m = v.Max();
        return m + Math.Log(v.Sum(x => Math.Exp(x - m)));
    }

    static double SqDist(Vec a, Vec b) => a.Zip(b, (p, q) => (p - q) * (p - q)).Sum();

    static Vec Weighted(ImmutableArray<Vec> ys, Vec logits)
    {
        double l = LogSumExp(logits);
        var a = logits.Select(x => Math.Exp(x - l)).ToArray();
        return Enumerable.Range(0, ys[0].Length)
            .Select(j => ys.Select((y, i) => a[i] * y[j]).Sum()).ToImmutableArray();
    }

    /// <summary>The Gaussian read with identity maps, by shifted exponentials (Proposition 2.2).</summary>
    public static Vec Stable(Vec z, ImmutableArray<Vec> ys, Vec logW, double s) =>
        Weighted(ys, ys.Select((y, i) => logW[i] - SqDist(z, y) / (2 * s * s)).ToImmutableArray());

    /// <summary>The read over the k nearest records, with the certificate of Proposition 2.3.</summary>
    public static CertifiedRead Truncated(Vec z, ImmutableArray<Vec> ys, Vec logW, double s, int k)
    {
        var order = Enumerable.Range(0, ys.Length).OrderBy(i => SqDist(z, ys[i])).ToArray();
        var near = order.Take(k).ToImmutableArray();
        var logits = near.Select(i => logW[i] - SqDist(z, ys[i]) / (2 * s * s)).ToImmutableArray();
        double kept = LogSumExp(logits);
        double omitted = Math.Log(ys.Length - k) + logW.Max()
                         - SqDist(z, ys[order[k]]) / (2 * s * s);
        double share = 1 / (1 + Math.Exp(kept - omitted));
        int d = ys[0].Length;
        double diam = Math.Sqrt(Enumerable.Range(0, d).Sum(j =>
        {
            double lo = ys.Min(y => y[j]), hi = ys.Max(y => y[j]);
            return (hi - lo) * (hi - lo);
        }));
        return new CertifiedRead(Weighted(near.Select(i => ys[i]).ToImmutableArray(), logits),
                                 share, share * diam, k);
    }
}

public static class Evidence
{
    /// <summary>Paired sample size for a one-sided test of mean difference delta with
    /// standard deviation sd, from the two normal quantiles (Proposition 3.1).</summary>
    public static int PairedSampleSize(double zAlpha, double zPower, double delta, double sd) =>
        (int)Math.Ceiling(Math.Pow(zAlpha + zPower, 2) * sd * sd / (delta * delta));

    /// <summary>Holm's step-down procedure: which hypotheses are rejected at level alpha
    /// (Proposition 3.2).</summary>
    public static ImmutableArray<bool> Holm(Vec pValues, double alpha)
    {
        int m = pValues.Length;
        var order = Enumerable.Range(0, m).OrderBy(i => pValues[i]).ToArray();
        var reject = new bool[m];
        for (int r = 0; r < m; r++)
        {
            if (pValues[order[r]] > alpha / (m - r)) break;
            reject[order[r]] = true;
        }
        return reject.ToImmutableArray();
    }

    /// <summary>Monte Carlo mean of the largest of m standard normals (Proposition 3.3).</summary>
    public static (double Mean, Rng Next) ExpectedMax(Rng rng, int m, int reps)
    {
        double sum = 0;
        for (int t = 0; t < reps; t++)
        {
            double best = double.NegativeInfinity;
            for (int i = 0; i < m; i++) { double z; (z, rng) = rng.Normal(); best = Math.Max(best, z); }
            sum += best;
        }
        return (sum / reps, rng);
    }
}

/// <summary>SplitMix64 stream with Box-Muller normals; each draw returns the next state.</summary>
public sealed record Rng(ulong State)
{
    public (double Value, Rng Next) Uniform()
    {
        ulong s = State + 0x9E3779B97F4A7C15UL, z = s;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
        return (((z ^ (z >> 31)) >> 11) * (1.0 / 9007199254740992.0), new Rng(s));
    }

    public (double Value, Rng Next) Normal()
    {
        var (u1, r1) = Uniform();
        var (u2, r2) = r1.Uniform();
        return (Math.Sqrt(-2 * Math.Log(1 - u1)) * Math.Cos(2 * Math.PI * u2), r2);
    }
}
```

The driver draws 400 records in $ℝ^3$ from the stream. It prints a read at $s=0.01$, where unshifted exponentials underflow, and a full read at $s=0.5$. It prints two truncated reads with their errors and certificates, the sample size for the example of Section 3.1, Holm's decisions for six $p$-values, and the expected maximum of seven normals from 20,000 draws. An independent NumPy script recomputes every line (Table A1).

Table: **Table A1.** C# kernel output against the NumPy recomputation.

| C# | NumPy | Difference |
|:------------------|:------------------|:----------|
| `stable_read_s0.01 0.4613901137167646 -⁠0.332889959914273 0.9515194366354485` | `stable_read_s0.01 0.4613901137167646 -⁠0.332889959914273 0.9515194366354485` | identical |
| `full_read 0.28715041715329664 -⁠0.21488019805735492 0.6396744770734353` | `full_read 0.28715041715329637 -⁠0.21488019805735484 0.6396744770734355` | 9.7 × 10⁻¹⁶ |
| `truncated_k16 0.16188214750227864 0.9815241536281465 9.789641588692731` | `truncated_k16 0.16188214750227864 0.9815241536281465 9.789641588692731` | identical |
| `truncated_k64 0.033516990610762534 0.8714392485873461 8.691663754228767` | `truncated_k64 0.03351699061076273 0.8714392485873461 8.691663754228767` | 5.8 × 10⁻¹⁵ |
| `sample_size 56` | `sample_size 56.0` | identical |
| `holm 1 0 1 0 1 0` | `holm 1.0 0.0 1.0 0.0 1.0 0.0` | identical |
| `expected_max_7 1.3513553704976282` | `expected_max_7 1.3513553704976282` | identical |

## Appendix VI.B: reproducibility

All results were produced with Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1, Matplotlib 3.11.2 and .NET SDK 8.0.131. The script `p6_checks.py` writes `p6_checks.json` with seed 20261024. It reads Part IV's `p4_checks.json` for the true second moments of the width scan and regenerates Part IV's archive from Part IV's seed. The script `fig_p6.py` draws the figures from the results file. The C# project in `cs/` builds the kernel and its driver, and `cs_validate.py` compares the driver's output with NumPy and writes `cs_validate.json`. The document is converted to Word by Pandoc and post-processed for equation layout and schema order. A code archive accompanies this paper.


# Afterword: what the six parts establish and what remains

The book set out to make one sentence exact: an ASE stack is horizontally topological within each layer and vertically algebraic across layers. Part I gave the sentence its mathematics, as sheaves on covers and representations of the layer order. Parts II and III computed what the two axes do: a layer is a harmonic extension on an observation star, and a stack is a schedule acting on reads that, in the continuum limit, transports the archive density. Parts IV to VI asked what can be claimed from the results: which target a run estimates, how local laws may be fused and constrained, and what an implementation must report for a number to count as evidence.

Several results cut against first impressions, and they are worth restating together.

- **The archive is not the target.** A selected archive is a record of what was evaluated. Used as a target it was off by 0.61 or more in total variation in Part IV's example. It is a proposal, to be corrected by fresh evaluations.
- **A clean top re-selects.** In the continuum limit, a stack with identity maps and a clean top samples the archive itself (Part III, Proposition 3.6). Its outputs cannot be importance-weighted (Part IV, Theorem 3.1). Novelty comes only from the channels Part III lists and from fusion (Part V, Proposition 2.5).
- **Topology does not choose good schedules by itself.** Component persistence scales placed layers where few tokens make decisions. Hypothesis C3 was refuted in all 72 comparisons of an exploratory pilot. A curvature schedule computed from the archive was the best tested at equal numbers of layers.
- **Products of experts overcount.** They count shared archives once per expert and separators twice (Part V, Proposition 2.3 and Theorem 3.1).
- **Local agreement does not imply a global law.** On a cycle, pairwise-consistent marginals can have no joint law (Part V, Proposition 3.2), the probabilistic face of Part I's cohomology.
- **In-sample diagnostics cannot see infinite variance.** Selecting an importance width by in-sample effective size chose infinite-variance widths in most runs at moderate sample sizes (Part VI, Section 3.5).

## The hypotheses of the conversion proposal

The conversion proposal stated five falsifiable hypotheses with decision rules [S3, Sections 17–18]. Table B.1 records their status at the end of this edition. None has been tested confirmatorily. The proposal recommended C2 as the first experiment, on chain-structured objectives with equal evaluation budgets and a classical block-recombination control, and that recommendation stands.

Table: **Table B.1.** Status of hypotheses C1 to C5 after the six parts.

| Label | Prediction in the proposal | What the book established | Status |
|:--------|:------------------------|:------------------------------------|:--------------|
| C1 | adaptive geometry retains estimation quality: RMSE at most 1.5 times a fixed-cover comparator | defensive mixtures, the width threshold and the error ledger (Part IV, Theorems 3.5 and 5.1); adaptive covers not studied | open; prerequisites supplied |
| C2 | recombination halves costly evaluations on chain objectives | the mechanism and its ceiling (Part II, Proposition 3.5); feasibility only across product blocks (Part V, Theorem 4.4) | open; qualified; recommended first experiment |
| C3 | schedules from component persistence match twice as many cosine layers | refuted in all 72 comparisons of an exploratory transport pilot (Part III, Section 5.3) | refuted in exploration; confirmatory test pending |
| C4 | transport reduces physical re-selection by 30 points on a mirror-symmetric truss | orbit indexes and the failure of continuous canonicalisation (Part II, Proposition 6.10); clean-top re-selection (Part III, Proposition 3.6) | open; constrained |
| C5 | local reads use at most 10% of the archive with loss within 1% of ADE | per-layer and composite sensitivity bounds (Part II, Proposition 5.4; Part III, Theorem 4.2); nearest-record certificates certified little below a quarter of the archive (Part VI, Section 2.3) | open; certification at 10% doubtful in the tested setting |

## Work for the next edition

Three planned chapters are missing from this edition: Pareto orders and scalarisations, consistency of reads with adaptive fits, and versioned caches with release rules (Table F.1). The open problems at the end of each part list the mathematical questions the six parts leave behind. The most consequential are four:

- the convergence of stochastic stacks to the reverse-time equation of the archive mixture (Part III);
- a density, if any, whose score is the sheaf read with masks (Part III);
- sharper truncation certificates from index structure (Part VI);
- the confirmatory protocols for C1 to C5, with sample sizes and families declared in advance (Part VI).

The proposal ended with a decision rule that this book adopts. Failure of a performance hypothesis does not falsify the harmonic-extension identity or the inclusion of ADE. It decides where the extra modelling cost of ASE is justified. Null and adverse results belong in the book.

# Register of Results

The register lists every numbered definition, theorem, proposition, lemma, corollary, example and remark in the book, by part, with the name it carries in the text. It serves as the index of the book.

## Part I

| Statement | Name |
|:--------------|:------------------------------------------|
| Definition 2.1 | Alexandrov topology |
| Proposition 2.2 | sheaves on a finite poset |
| Proposition 2.3 | cellular cohomology is sheaf cohomology |
| Definition 2.4 | the four bases of ASE |
| Definition 3.1 | layer cover |
| Definition 3.2 | cellular data sheaf |
| Remark 3.3 | units before residuals |
| Definition 3.4 | cochains, coboundary, residual |
| Proposition 3.5 | the coboundary needs compatibility; Euler identity |
| Proposition 3.6 | positive sheaf energy |
| Proposition 3.7 | distance to consistency; Hodge split |
| Proposition 3.8 | heat flow converges to compatible data |
| Theorem 3.9 | Čech data sheaf |
| Example 3.10 | two arcs |
| Definition 3.11 | orthogonal sheaf, transport, holonomy |
| Theorem 3.12 | holonomy theorem |
| Corollary 3.13 | Harary's balance theorem |
| Proposition 3.14 | filled triangles are flat |
| Remark 3.15 | flat is not trivial |
| Proposition 3.16 | three obstructions on one cycle |
| Example 3.17 | mode shapes and subspaces |
| Example 3.18 | a sheaf of sets with no global section |
| Proposition 3.19 | coordinate sheaves on contexts |
| Proposition 3.20 | inverse image along a simplicial map |
| Proposition 3.21 | refinement |
| Definition 4.1 | representations of the layer order |
| Theorem 4.2 | interval decomposition |
| Definition 4.3 | token path and fibre diagrams |
| Proposition 4.4 | homogenisation adds exactly one full bar |
| Proposition 4.5 | births at the top |
| Proposition 4.6 | exact versus effective rank of the Gaussian tangent |
| Proposition 4.7 | layer cohomology is a representation of $P$ |
| Proposition 4.8 | Leray covers give full bars |
| Example 4.9 | a coarse cover that misses a loop; Figure 3 |
| Proposition 4.10 | nested ball nerves |
| Proposition 4.11 | stability of component counts |
| Remark 4.12 | zigzags |
| Proposition 5.1 | fixed-base product |
| Proposition 5.2 | the finite case |
| Theorem 5.3 | vertical acyclicity |
| Corollary 5.4 | what the cohomology of a stack sees |
| Remark 5.5 | orientation, cosheaves and zigzags |
| Definition 5.6 | tower |
| Proposition 5.7 | Lagrangian coordinates |
| Remark 5.8 | two parameters are wild |
| Proposition 5.9 | ADE is the trivial product |

## Part II

| Statement | Name |
|:--------------|:------------------------------------------|
| Definition 2.1 | observation star |
| Definition 2.2 | sheaf attention |
| Proposition 3.1 | harmonic extension and its Schur complement |
| Proposition 3.2 | the retention read |
| Proposition 3.3 | matrix weights |
| Corollary 3.4 | transported hull and ceiling |
| Proposition 3.5 | recombination and the coordinatewise ceiling |
| Proposition 3.6 | two weighted subspaces |
| Proposition 3.7 | amplification and coverage |
| Proposition 3.8 | residual at the read |
| Proposition 3.9 | gradient and Hessian of the soft energy |
| Theorem 3.10 | sheaf attention is a majorise–minimise step |
| Proposition 3.11 | ADE is the identity star |
| Corollary 3.12 | every deterministic ADE layer descends at its own scale |
| Proposition 3.13 | the Euclidean energy step |
| Proposition 4.1 | Tweedie's identity in a stalk |
| Proposition 4.2 | chart posterior and sheaf read |
| Proposition 4.3 | mixture and product |
| Proposition 4.4 | imputation, gradient steps and the harmonic read |
| Proposition 4.5 | tilting the product law |
| Proposition 4.6 | selection tilting collapses coverage |
| Proposition 4.7 | Gaussian measurement noise |
| Theorem 4.8 | bounded measurement error |
| Proposition 5.1 | truncating a transported read |
| Corollary 5.2 | certified radius |
| Theorem 5.3 | truncating a rectangular read |
| Proposition 5.4 | the Jacobian of sheaf attention |
| Corollary 5.5 | minima attract, saddles repel |
| Proposition 6.1 | branch purity and branch-conditional reads |
| Proposition 6.2 | shared reads land in gaps |
| Proposition 6.3 | connectedness and atoms |
| Proposition 6.4 | nearest-lift approximation |
| Proposition 6.5 | the local angle read jumps only at antipodes |
| Theorem 6.6 | nearest-image reads for a finite group |
| Example 6.7 | sign transport, re-run |
| Proposition 6.8 | projector reads |
| Definition 6.9 | orbit distance and novelty modulo symmetry |
| Proposition 6.10 | indexing modulo a finite group |

## Part III

| Statement | Name |
|:--------------|:------------------------------------------|
| Definition 2.1 | schedule and stack |
| Proposition 2.2 | coefficients and variance bookkeeping |
| Proposition 2.3 | a stack is ADE in scaled coordinates |
| Theorem 3.1 | separation |
| Theorem 3.2 | the noise budget |
| Corollary 3.3 | deterministic weights |
| Proposition 3.4 | precision coordinates |
| Theorem 3.5 | the deterministic stack discretises a transport |
| Proposition 3.6 | a clean top re-selects |
| Proposition 3.7 | the channels of novelty |
| Proposition 4.1 | a layer is a gradient step |
| Theorem 4.2 | floor, ceiling and volume |
| Corollary 4.3 | contraction beyond the schedule happens at the top |
| Proposition 4.4 | fixed points, Morse index and bifurcations |
| Example 4.5 | pitchfork and fold |
| Proposition 4.6 | thresholded ranks are not rank invariants |
| Proposition 5.1 | component barcodes |
| Proposition 5.2 | in one dimension modes are only born in the token direction |
| Example 5.3 | in two dimensions a mode is born as the scale grows |
| Theorem 5.4 | curvature of token paths |
| Proposition 5.5 | an error model and the layer-halving bound |

## Part IV

| Statement | Name |
|:--------------|:------------------------------------------|
| Definition 2.1 | Gibbs target |
| Definition 2.2 | archive density |
| Proposition 2.3 | a weighted archive estimates the smoothed target |
| Theorem 3.1 | support of clean-top proposals |
| Proposition 3.2 | exact proposals |
| Proposition 3.3 | Gaussian second moment |
| Proposition 3.4 | width threshold for archive mixtures |
| Theorem 3.5 | defensive mixtures |
| Theorem 3.6 | finite-sample bounds |
| Lemma 4.1 | multiplicative weight error |
| Proposition 4.2 | bounded critic error |
| Proposition 4.3 | Gaussian critic noise |
| Proposition 4.4 | truncated proposal densities |
| Theorem 5.1 | error ledger |

## Part V

| Statement | Name |
|:--------------|:------------------------------------------|
| Definition 2.1 | Gaussian expert |
| Proposition 2.2 | product of experts |
| Proposition 2.3 | double counting |
| Proposition 2.4 | covariance intersection |
| Proposition 2.5 | fused means can leave the hull |
| Theorem 3.1 | a product of experts counts the separator twice |
| Proposition 3.2 | consistent pairs on a cycle with no joint law |
| Proposition 4.1 | conditioning |
| Proposition 4.2 | penalties converge at rate $1/\gamma$ |
| Proposition 4.3 | restricted weights |
| Theorem 4.4 | recombination preserves feasibility exactly on boxes |
| Proposition 4.5 | convex reads stay feasible; products need not |

## Part VI

| Statement | Name |
|:--------------|:------------------------------------------|
| Proposition 2.1 | cost of reads |
| Proposition 2.2 | stable reads |
| Proposition 2.3 | a certificate for nearest-record reads |
| Proposition 2.4 | implementations may disagree, within a bound |
| Proposition 3.1 | paired sample size |
| Proposition 3.2 | family-wise error |
| Proposition 3.3 | selection optimism |
| Proposition 3.4 | infinite variance is invisible in sample |
| Proposition 4.1 | a counterexample must carry its certificate |


# Glossary

**ADE (Autoregressive Diffusion Evolution).** The search procedure that ASE generalises: tokens descend a denoising stack whose layers read an archive of evaluated designs through one Gaussian kernel.

**Archive density.** The mixture $p_s=\sum_i\beta_iN(y_i,s^2I)$ of the archived records at scale $s$ (Part III, Definition 2.1; Part IV, Definition 2.2).

**ASE (Autoregressive Sheaf Evolution).** ADE with local data spaces, compatibility maps and scale-dependent covers in place of one retrieval geometry.

**Barcode.** The decomposition of a representation of the layer order into interval modules. It is exact only with exact ranks (Part I, Section 4; Part III, Proposition 4.6).

**Base law.** The declared reference density $\rho$ against which $e^{-\beta J}$ defines the Gibbs target (Part IV, Definition 2.1).

**Certificate.** A computable bound on the error of a computed quantity, such as a stationarity residual or a truncation share. A numerical counterexample must carry one (Part VI, Proposition 4.1).

**Clean top.** A stack whose last scale is $s_0=0$, so that the output is the last read.

**Cover, nerve, Leray cover.** A finite family of open sets on a layer's base; the simplicial complex of their overlaps; a cover whose overlaps are acyclic, so that the nerve computes the cohomology (Part I, Section 3).

**Covariance intersection.** A fusion rule that is consistent for every cross-correlation of its inputs (Part V, Proposition 2.4).

**Defensive mixture.** A proposal $(1-\varepsilon)q+\varepsilon\rho$ whose importance weights are bounded by $1/(\varepsilon Z)$ (Part IV, Theorem 3.5).

**Error ledger.** The bound that splits the error of an importance estimate into a critic and density term and a sampling term (Part IV, Theorem 5.1).

**Gibbs target.** The law $\pi_\beta=\rho e^{-\beta J}/Z$ that a run estimates.

**Harmonic extension, sheaf attention, read.** The least-squares extension of observations from the leaves of an observation star to the token: $m=H^{-1}\sum_i\alpha_iQ_i^{\top}o_i$ (Part II, Section 3).

**Holonomy.** The composite of transports around a closed walk of an orthogonal sheaf. Its fixed space is the space of global sections (Part I, Theorem 3.12).

**Marginal extension.** The law $p_{AS}p_{SB}/p_S$ that glues consistent clique marginals across a separator (Part V, Section 3).

**Noise budget.** The fixed variance $s_0^2-\omega_\star^2s_T^2$ of the explicit noise reaching a stack's output (Part III, Theorem 3.2).

**Observation star.** A token vertex joined to one leaf per retrieved record, with edge maps on both sides (Part I, Definition 2.4; Part II, Section 2).

**Product of experts.** The product of Gaussian factors, which adds precisions. It is exact only for experts with disjoint evidence (Part V, Propositions 2.2 and 2.3).

**Second moment of the weights, $m_2$.** $E_q[(\pi/q)^2]=1+\chi^2(\pi\Vert q)$, which governs the cost of importance sampling (Part IV, Section 3.3).

**Separation identity.** The decomposition of a stack's output into a starting term, a convex combination of reads and a noise term (Part III, Theorem 3.1).

**Stalk, restriction map, section.** The data space on a cell of a cover; the linear map comparing data on a cell with data on a larger cell; an assignment of data to cells that agrees under every restriction (Part I, Section 3).

**Tangent, composite tangent.** The Jacobian of a layer, and the product of layer Jacobians along a token's path (Part III, Section 4).

# Works in this series

[S1] Ghosh, D. P. (2026). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[S2] Ghosh, D. P. (2026). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[S3] Ghosh, D. P. (2026). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[S4] Ghosh, D. P. (2026). *Separator Anchors for Sheaf Based Latent Reasoning*. Version 4, 20 October 2026.

[S5] Ghosh, D. P. (2026). *Sheaf Structured Generative Diffusion*. Version 2, October 2026.

[S6] Ghosh, D. P. (2026). *SheafFarm: Some Sheaf-Diffusion Algorithms are More Sheaf Than Others*. Version 2, October 2026.

# About the author

Debi Prasad Ghosh is the Founder and Principal Engineer of Debias Parametric Guru, Kolkata, India. He is an independent researcher. His Defensible Intelligence series, written under the motto “Respect science. Import emotion.”, treats falsifiability as a hard standard: mathematics over framework over expressivity.
