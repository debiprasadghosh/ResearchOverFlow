<!-- BLOCK claims -->
## 4.3 Persistent assertions and changing applicability

**Definition 4.5 (scope and strength of a stored claim).** Write a bound claim as $(\kappa,K,\tau,I)$, asserting $\tau(M)\in I$ for every $M\in K$. The semantic context $\kappa$ fixes event meanings, interventions, coordinates, units and operator versions. For the same context and query, certified inclusion $K'\subseteq K$ and interval inclusion $I\subseteq J$ justify the weaker served claim $(\kappa,K',\tau,J)$. This is a sufficient entailment rule, rather than a complete comparison of all logically equivalent claims.

The archive preserves what was asserted under its original premises. A changed applicability decision is a new record that cites the old one. The old record is not edited from “sharp” to “outer”; a new service record states that only an outer guarantee has been established for the new snapshot. A subsequently discovered false input is also recorded explicitly. Immutability supplies an audit history, not permanent truth or permanent applicability.

Interval widening alone does not repair a changed context. If the old scope contains only a model with query value one and the new scope only a model with value zero, widening $[1,1]$ to $[0.9,1]$ is still false in the new scope. A safe weakening requires inclusion or another checked transport argument. A generic gist, prose summary or nearby embedding is not automatically such an argument.

<!-- BLOCK forgetting -->
## 5.3 Weakening certificates when premises are discarded

Forgetting an evidence constraint enlarges the set of models that the retained information allows. This differs from adding consistent evidence. Let $R$ index retained rows and $J$ deleted rows of $Aq\leq b$ on the same response simplex, and let $K_R=\{q\in\Delta_n:A_Rq\leq b_R\}$ be nonempty. The rows must remain semantically aligned; an unavailable row receives no multiplier in a current certificate.

**Theorem 5.6 (a certified cost of dropping premises).** Let $\lambda\geq0$ be an old multiplier vector, and let $B_{\mathrm{old}}=B_\lambda(c;A,b)$. Set

$$\Gamma_J=\max_i\sum_{j\in J}\lambda_j(A_{ji}-b_j),\qquad [x]_+=\max(0,x).$$

For every $q\in K_R$,

$$c^{\mathsf T}q\leq B_{\lambda_R}(c;A_R,b_R)\leq B_{\mathrm{old}}+[\Gamma_J]_+.$$

The nonnegative surcharge can be attained. A simpler, possibly looser surcharge is $\sum_{j\in J}\lambda_j[\max_iA_{ji}-b_j]_+$.

*Proof.* The first inequality is Theorem 5.4 on the retained rows. Put $r=c-A^{\mathsf T}\lambda$ and $v=A_J^{\mathsf T}\lambda_J$. The difference between the repaired and old certificates is

$$-\lambda_J^{\mathsf T}b_J+\max_i(r_i+v_i)-\max_i r_i\leq\max_i(v_i-\lambda_J^{\mathsf T}b_J)=\Gamma_J.$$

Replacing this by its positive part gives a nonnegative allowance. Bounding a maximum of sums by the sum of the coordinatewise maxima gives the simpler surcharge. For sharpness, take $q\in\Delta_2$, $c=(1,0)$, one row $q_1\leq1/5$ and $\lambda=1$. The old certificate is $1/5$; dropping the row gives upper endpoint one and surcharge $4/5$, attaining the bound. ∎

This formula gives a query-dependent price for permanently losing a premise. Evicting its text from the language context is different: if its authoritative record and proof remain retrievable, the premise has not been logically discarded. A low surcharge can guide retention, but it does not establish a generally optimal cache policy. Constraints may be complementary, and retaining only one query's cheap certificate can harm other queries.

**Corollary 5.7 (a portfolio of valid certificates).** Suppose finitely many checked intervals $[L_j,U_j]$ each enclose the same query on the same current nonempty model set. Their intersection

$$[\max_j L_j,\ \min_j U_j]$$

is a valid enclosure, and adding another valid certificate cannot widen it.

*Proof.* Every feasible query value belongs to every interval and therefore to their intersection. The maximum lower endpoint cannot decrease and the minimum upper endpoint cannot increase when another interval is added. ∎

Old certificates with different scopes may be combined only after each has been justified on the current set. An empty intersection contradicts the declared joint premises; it is not automatically proof that the physical system is impossible. The source of the contradiction must be checked. Portfolio improvement tightens an outer enclosure and does not change the exact query range on an unchanged model set.

**Observation 5.8 (width does not order refinement durability).** Theorem 5.1 preserves every valid outer interval, including a valid point interval. It makes no comparison between the biological durability of coarse and precise memories. Moreover, failure of one stored optimizer does not establish loss of sharpness. In the inherited upper-endpoint census, $1,258+2,676=3,934$ of 6,000 endpoints remained unchanged, or 65.6%, although the selected witness survived only 21.0%. The lower-endpoint persistence rate is 65.1%. These are different objects and different denominators of interest. Section 10.5 treats preferential cortical coarsening as a hypothesis requiring evidence beyond these logical facts.

<!-- BLOCK drift -->
## 6.4 Certificate repair with bounded numerical reconstruction error

Stored coefficients can be reconstructed approximately without pretending that a drifting representation is an unchanged record. The semantics still have to match; numerical error bounds cannot certify a change in what an event or intervention means.

**Theorem 6.8 (a certificate under bounded coefficient drift).** Let the current true model set be the nonempty $K(A,b)$ of Section 5.2, with query $c^{\mathsf T}q$. Let reconstructed coefficients satisfy, for every row $j$,

$$\|A_j-\widetilde A_j\|_\infty\leq a_j,\qquad |b_j-\widetilde b_j|\leq d_j,\qquad \|c-\widetilde c\|_\infty\leq e,$$

where all radii are nonnegative and the rows use the same declared coordinates and compatible units. For any checked $\lambda\geq0$,

$$c^{\mathsf T}q\leq B_\lambda(\widetilde c;\widetilde A,\widetilde b)+e+\sum_j\lambda_j(a_j+d_j)\qquad(q\in K(A,b)).$$

*Proof.* Since $q$ is a probability vector, $(\widetilde A_j-A_j)q\leq a_j$, so $\widetilde A_jq\leq\widetilde b_j+a_j+d_j$. Also $c^{\mathsf T}q\leq\widetilde c^{\mathsf T}q+e$. Apply Theorem 5.4 with the enlarged reconstructed right-hand side, then collect the added multiplier terms. ∎

The lower bound follows by applying the theorem to $-c$, with its own nonnegative multipliers. The allowance is a probability or utility error in the query's stated unit; it cannot be combined with unnormalized representation distances. The result permits a real numerical tolerance contract. It does not infer coefficient radii from neural similarity, average decoding error or representational drift alone.

For example, reconstruct the row $q_1\leq1/5$ as $q_1\leq19/100$, with $d_1=1/100$ and all other errors zero. With $\lambda=1$ the uncorrected certificate is $19/100$, which is too small for the true set. The corrected certificate is exactly $1/5$. A false numerical memory becomes usable through a checked allowance, rather than through a claim that its content never changed. Large multipliers amplify coefficient uncertainty, suggesting that retention should account for certificate sensitivity as well as record size and access frequency.

<!-- BLOCK summary -->
## 9.4 What a semantic summary must preserve

**Proposition 9.4 (the enclosure forced by a summary).** Let a summary map $\sigma$ assign the same memory code $s$ to possibly different nonempty model sets $K$. Define its concretization by

$$\mathcal K_s=\bigcup_{\sigma(K)=s}K.$$

For a bounded scalar query $\tau$, any interval returned from $s$ alone that is valid for every represented set must contain the interval hull of $\tau(\mathcal K_s)$. That hull is the least such closed interval.

*Proof.* Each model in the union belongs to some represented set, so uniform validity requires its query value to lie in the returned interval. Its closed interval hull must also lie there. Conversely the hull contains all those values and is valid for every represented set. ∎

This is a sound-abstraction statement in the sense of Cousot and Cousot (1977). If a summary merges the diagonal and square of Proposition 9.3, the difference must receive the wider interval. A relational summary retaining $a=b$ need not lose that contrast at all. Thus consolidation can preserve useful dependencies; losing them is a property of the chosen summary and future task family, not a consequence of moving information to cortex. Theorem 9.2 requires a sufficient frontier for its declared outputs and does not predict dependency loss when that requirement is satisfied.

<!-- BLOCK neuroscience -->
## 10.5 Protected claims and revisable cortical memory

IDC's immutability is a rule for an engineered assertion history. No evidence shows that neocortex stores an append-only audit graph or computes interval do-calculus. The functional analogy is narrower: preserve a claim's meaning and applicability while allowing later records, new contexts and more conservative guarantees. Biological content can change, and the history of every previous assertion is not known to persist. Definition 4.5 separates this engineering contract from literal synaptic permanence.

**Supersession and extinction.** Bouton's (2004) review describes extinction as context-sensitive new learning, with renewal and spontaneous recovery showing that earlier learning can remain available. This motivates separate context-indexed records rather than a single globally overwritten association. It does not show that all learning updates preserve the old content. Reconsolidation in the amygdala after retrieval (Nader et al., 2000) is direct evidence against a blanket immutability claim. Neither result is specifically evidence for an append-only neocortical store, and absent behavioral recovery alone cannot distinguish erasure from failed retrieval.

**Protected substrates.** Yang et al. (2009) tracked mouse cortical dendritic spines and found long-lived structural stability, including a surviving subset of learning-associated spines. Stable structure can coexist with continuing plasticity. Gogolla et al. (2009) manipulated perineuronal nets in the amygdala and altered the susceptibility of subsequently acquired fear memories to erasure by extinction. This supports a role for extracellular structure in limiting plasticity in that paradigm; it is not a cortical certificate experiment. Tsien's (2013) proposal that net-hole patterns store very long-term memories remains a hypothesis. These findings and proposals motivate protected retention mechanisms without locating individual accepted claims or proving that their information is preserved exactly.

**Schemas and coarse claims.** Winocur and Moscovitch's (2011) transformation account distinguishes detailed episodic remembering from semantic or gist-like representations. Tse et al. (2007) found that an established associative schema can support rapid assimilation and hippocampal independence in a rat task. A gist corresponds to an IDC outer approximation only if a concretization has been specified and shown to contain the represented possibilities, as Proposition 9.4 requires. It is not automatically a numerical interval. All valid outer bounds survive consistent refinement, irrespective of width. The census therefore motivates studying the cost of retaining witnesses and certificates; it does not prove that coarse memories must consolidate better.

**Relations and episodes.** The stored upper optimizer survived 21.0% of the inherited refinements, while the old upper endpoint remained exact in 65.6%. After the observational law changed, reused multipliers produced valid repaired bounds throughout the declared family and exact endpoint pairs in 95.5% and 80.4% of the two change regimes. These are algorithmic outcomes on response polytopes, not retention rates in brains. A feasible witness is one candidate model, not literally an episode; a multiplier vector certifies a constraint combination, not literally a cortical relation. The testable analogy is that reusable relational structure may be retained more effectively than a particular instance. Theorem 5.6 quantifies one artificial cost of discarding that structure, and Theorem 6.8 makes numerical reconstruction error explicit. Reuse requires the multiplier's row references, current constraint data and checked assumptions.

**Meaning under representational drift.** Driscoll et al. (2017) observed changing neuronal activity patterns over weeks in mouse posterior parietal cortex despite stable learned behavior, with information readable at the population level over shorter cross-day spans. This motivates evaluating preserved task meaning rather than equating a memory with permanently assigned cells. It does not establish a perfect cross-time decoder or immutable semantic content. IDC likewise distinguishes a digest, storage address and decoder from the proposition they are meant to support. A changed encoding needs a semantic extraction check; a bounded numeric error can use Theorem 6.8 only when its radii have been justified independently.

**Frontiers and joint information.** Kitamura et al. (2017) found early formation and later functional maturation of prefrontal engrams in a mouse contextual-fear paradigm, with hippocampal support. The remote prefrontal memory remained context specific, while hippocampal engrams could become silent to natural retrieval. This is evidence of circuit reorganization, not a demonstration that an exact sufficient frontier has replaced all history or that hippocampal traces are erased. Proposition 9.3 predicts a loss of dependency-sensitive answers only if the retained summary discards the relevant joint constraints. A cortex that preserves those constraints is compatible with the theory.

The earlier N1–N3 hypotheses concern reuse, replay and usefulness. The following H-series states four additional biological predictions. For each, freeze the task, delay, scoring scale, power and a minimum effect $\Delta>0$ before data collection. An upper confidence endpoint below the specified minimum refutes that quantitative prediction; an interval crossing it is inconclusive. Null results challenge the stated mapping under those controls, rather than proving a universal alternative memory mechanism.

**Hypothesis H1 (constraints outlast episodes).** At matched initial learning and measurement reliability, delayed transfer of a learned relational constraint to new instances will decline less than recall of the particular training instances, by at least a prespecified $\Delta_R$. Match exposure, reward, retrieval demand and initial performance, and report both raw scores and the delayed-minus-initial contrast. Equal durability within a prespecified equivalence band contradicts this strict relational advantage. This tests the multiplier-versus-instance analogy; it does not identify an episode with a feasible response vector.

**Hypothesis H2 (coarse claims resist interference).** At matched initial performance, coarse claims will show at least $\Delta_C$ less additional forgetting than finely specified claims after logically consistent interfering evidence, relative to no-interference controls. Keep both original claims valid as outer assertions at the follow-up test and calibrate retrieval difficulty; otherwise ordinary differences in tolerance or the loss of a sharpness label can mimic a memory effect. Equal forgetting within the registered equivalence band refutes this advantage. Theorem 5.1 alone predicts no such difference.

**Hypothesis H3 (superseded relations remain contextually recoverable).** After updating a learned causal relation, reinstating the original context will recover the old relation by at least $\Delta_S$ more than a neutral context, under matched cues and verified learning of both relations. Freeze the renewal measure and positive retrieval controls. An upper confidence endpoint below $\Delta_S$ refutes the registered recovery prediction. Absence of recovery does not by itself prove that the old trace was overwritten, because access can fail even when some information remains.

**Hypothesis H4 (dependency loss exceeds marginal loss under schematic consolidation).** In a task designed to encourage separate schematic summaries, consolidation will produce at least $\Delta_J$ more decline on judgments requiring a learned joint dependency than on matched judgments of each marginal quantity. Compare sleep or delayed retention with an appropriate control and include an explicit relational-rehearsal condition predicted to protect the joint information. Match baseline difficulty and marginal retention. Equivalent decline refutes the proposed selective loss. If the relation is retained, the predicted loss need not occur; frontier sufficiency is conditional on the future queries being supported.

These are prospective tests, with no new human or animal results reported. The engineering proposal is to protect accepted records, append corrections under context contracts, preserve useful constraints and retain selected witnesses when their sharpness benefit justifies their cost. Kirkpatrick et al.'s (2017) elastic weight consolidation supplies a soft parameter-protection analogy. It does not implement a write-protected record store or guarantee exact preservation; Proposition 11.4 makes that distinction explicit.

<!-- BLOCK components -->
The six components have different acceptance and storage responsibilities. They are proposed interfaces; the implemented interval kernels do not yet constitute an end-to-end learned harness.

**Table 3 Components of the proposed IDC harness**

| Component | Retained authority or proposed action | Required boundary |
|:--|:--|:--|
| Semantic registry | Graph, meanings, interventions, units and evidence snapshots | Context changes create explicit new snapshots |
| Proposal policy | Candidate operation, cached record or acquisition | Proposals have no certificate authority |
| Primitive checker | Graph premises, multiplier signs and arithmetic | Accept only the declared claim under current premises |
| Operation store | Accepted records, dependencies, proofs and scopes | Append corrections and service decisions |
| Interval engine | Solve, repair and transport bounds with Algorithms 1–4 | Return a checked certificate with each bound |
| Scheduler | Select a route and compare guarantees with the request | Stop only when precision or decision requirements hold |

<!-- BLOCK request -->
The request fixes a query, context contract and acceptance predicate, such as absolute error, a threshold sign or regret tolerance. The following route order is a proposal for implementation, not a measured optimal scheduling rule.

1. **Resolve a snapshot.** Fix event meanings, causal regime, response coordinates, evidence and units. A feasible witness can establish nonemptiness. A checked infeasibility certificate permits “inconsistent”; failure to find a model permits only “unverified” or further work. Pin the snapshot for the computation.

2. **Try a semantic match.** Reuse a record only under an identical contract or a checked equivalence. Embedding similarity may retrieve candidates but cannot approve them. Exact equality of numerical arrays does not establish an unchanged intervention or population.

3. **Try refinement service.** If current evidence gives a certified nonempty subset, return the old interval as an outer guarantee when that already meets the request. If sharpness is required, check the relevant stored witnesses. A failed witness check does not prove an endpoint moved; Algorithm 2 can test the old face or solve again.

4. **Repair or transport.** For new numerical constraints in the same semantics, align multipliers with current rows, check their signs and evaluate the full residual maximum in (9). Removed rows cannot carry old multipliers. For a changed query use (12), or (15) when a certified model-set displacement is also available. Equations (9) and Theorem 6.8 give sound outer bounds under their premises; exactness still needs a matching witness. Changed meanings require a new semantic argument.

5. **Check the actual request.** Stop once the precision, threshold or regret certificate suffices. For action selection compare utilities jointly on the common model set with Algorithm 4. The inherited census certified signs in 7.5% of states against 3.2% for separate intervals, a workload result rather than a universal factor. Otherwise perform only the justified further checking, solving or evidence acquisition chosen by the scheduler.

6. **Commit and append.** Return the achieved guarantee with its snapshot and dependencies. If the request requires the latest registry state, compare versions at commit and revalidate affected claims after a change. Append the new service record. Retain historical assertions and their scopes, and keep arithmetic exactness, enclosure validity and endpoint sharpness distinct.

The census provides a concrete reason to try these routes. Witness reuse avoided 21.5% of endpoint solves. After the mass-0.05 change, repaired bounds were valid throughout the family and exact in 80.4%, while 41.7% of old numerical bounds were false. The more complete face test raised simplex pivots by 13.5%. These are inherited finite algorithm measurements. Only a timed harness comparison can establish whether retrieval, checking and reuse save end-to-end time.

<!-- BLOCK runtime -->
## 11.4 Snapshot checks and protected symbolic records

**Definition 11.2 (a request snapshot).** A request snapshot binds the semantic context, evidence version, query, operator versions and acceptance predicate. A terminal certificate identifies that snapshot. An “as of” request can return its pinned version; a latest-state request must compare its required version with the registry at commit. A version difference alone is neither an inclusion proof nor a numerical error bound.

**Theorem 11.3 (sound service under an adaptive route policy).** Assume correct primitive checkers and input semantics, complete dependencies, and a nonempty model set for the terminal snapshot. Let any policy adaptively propose a finite sequence of retrievals, transports, repairs and solves. If every admitted claim is checked for that snapshot or transported by a valid implication, and a terminal answer is returned only after its acceptance predicate is certified, the answer satisfies the requested contract on that snapshot.

*Proof.* Apply Theorem 4.3 to the accepted dependency graph. Each retrieval or transport has a checked contract, and each newly computed claim follows from correct primitives. Thus the terminal certificate is valid for every model in the pinned set. Its certified predicate supplies the requested precision or decision property. The policy's choices do not enter this correctness argument. The commit check prevents a pinned result from being silently presented as a result for a different latest snapshot. ∎

The theorem is a safety statement. It does not imply termination, low cost, correct graph extraction or a useful learned scheduler. Repeatedly rejected proposals can consume unbounded time. Acquisition of new evidence creates a new snapshot and requires the appropriate feasibility and transport checks. A protected operation store can coexist with editable model weights because the authority of a record is in its checked scope and proof.

**Proposition 11.4 (soft parameter protection is not immutability).** A finite quadratic penalty on a stored parameter need not leave that parameter unchanged when a new task is optimized. For

$$\mathcal L(\theta)=\tfrac12(\theta-1)^2+\tfrac{\lambda F}{2}(\theta-0)^2,\qquad 0\leq\lambda F<\infty,$$

the unique minimizer is $\theta=(1+\lambda F)^{-1}>0$, although the protected old value is zero.

*Proof.* The derivative is $(\theta-1)+\lambda F\theta$, and the second derivative is $1+\lambda F>0$. Solving the first-order condition gives the displayed nonzero minimizer. ∎

Elastic weight consolidation uses importance-weighted quadratic protection (Kirkpatrick et al., 2017); the proposition illustrates the finite-penalty principle, not its empirical failure rate. Exact accepted-record persistence needs a storage rule. A continually learned proposal policy or semantic decoder needs a separate validation and drift contract.

Anthropic's 2026 long-running application account separates generation from evaluation and discusses the cost of orchestration and repeated evaluation (Anthropic, 2026). These are useful harness design precedents. Its evaluators, including subjective judgments, are not substitutes for an exact causal primitive checker. Together with Agent Lightning and SWE-agent, the comparison locates IDC's proposed addition: a mathematical acceptance contract for when a retained result may replace recomputation. The four interval algorithms and the inherited census are implemented; the six-component harness, learned scheduler and end-to-end speed-up remain proposals tested by C1–C5.

<!-- BLOCK newchecks -->
## 12.11 New exact examples and provenance of this revision

Version 3 adds small exact-arithmetic examples for premise deletion, repaired coefficient drift, certificate intersection, summary-dependent contrasts and finite quadratic protection. A separate checker also rebuilds the distinction between witness survival and endpoint persistence from the supplied census records. It does not regenerate the original C# simulations or the inherited pivot counts.

Dropping $q_1\leq1/5$ raises the certified upper bound from $1/5$ to one, attaining Theorem 5.6's surcharge $4/5$. Reconstructing the same right-hand side as $19/100$ and adding its certified radius $1/100$ recovers the valid bound $1/5$ by Theorem 6.8. With $\lambda F=9$, Proposition 11.4's protected parameter moves from zero to $1/10$. These are specified algebraic examples, not learned-model experiments. Their general conclusions come from the proofs.

The supplied Version 2 manuscript, C# kernel, exported records and validation results remain unchanged in the source bundle. New result files are produced in two clean Python processes and compared exactly. The current Word builder uses the included Version 2 file directly; it does not depend on an unavailable earlier manuscript. No new agent benchmark, latency measurement, training run or biological experiment is reported.
