---
subtitle: Persistent claims, revisable memory and verified reuse
title: Certified Causal Memory with Interval Do Calculus
---

Debi Prasad Ghosh

Version 3, 1 November 2026

Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India

## Abstract

Interval Do Calculus (IDC) is a proposed certification layer for reusing computations in Autoregressive Do Calculus. Incoming and outgoing graph cuts define different causal operations, while numerical bounds require a fixed query and a nonempty admissible model set. This revision develops certified causal memory: accepted assertions retain their original scopes, and new records express supersession, transport or weaker guarantees. A premise-deletion theorem bounds the cost of discarding constraints, a coefficient-drift theorem repairs bounds reconstructed with certified numerical error, and a summary theorem states which query enclosure a compressed memory must preserve. The results complement the existing refinement, witness, multiplier, transport and decision-stopping contracts. The inherited exact C# census is retained: a selected upper optimizer survives 21.0% of evidence refinements, but the upper endpoint itself remains unchanged in 65.6%. After the mass-0.05 data change, multiplier repair is valid throughout the declared family and exact in 80.4%, while 41.7% of old numerical bounds are false. More complete endpoint checking can cost more simplex pivots, so none of these rates establishes wall-time acceleration. New Section 10.5 compares protected claims with extinction, stable spines, perineuronal nets, schemas, representational drift and systems consolidation, and states four falsifiable H-series predictions. Gist is an outer approximation only under a justified concretization; refinement validity alone does not favor coarse memories. The expanded six-component harness pins request snapshots and separates proposal from checked acceptance. Its safety contract is independent of the learned route policy, while finite soft weight penalties do not make records immutable. New exact examples support the added formulas without rerunning the inherited census. The biological mapping, learned scheduler and end-to-end speed-up remain untested proposals.

Keywords interval do calculus; causal memory; certificate reuse; evidence refinement; memory consolidation; representational drift; sheaf compatibility; adaptive AI harness

# 1 Introduction

Interval Do Calculus can accelerate Autoregressive Do Calculus when it allows a previously checked result to answer a later question at the required precision. The storage mechanism preserves the computation. The interval certificate establishes when its result remains usable. This distinction matters because an old numerical answer may become obsolete while a structural identity, a coarse bound or an optimisation certificate remains useful.

In a decoder model, a key and value cache retains attention states for an already processed prefix. The corresponding object in a causal interpreter is a typed intermediate computation with its premises and dependencies. Efficient sharing of key and value blocks is established in language model serving (Kwon et al., 2023). The proposed causal cache has a stronger semantic obligation: the graph, intervention, event meanings and available evidence must still justify the reused claim.

The motivating proposal assigns an upper boundary to removing arrows entering a node and a lower boundary to removing arrows leaving it. That proposal contains a useful structural idea, but the ordering needs an additional hypothesis. The two mutilations remove different mechanisms. Neither edge inclusion nor graphical position orders their outcome probabilities. We first make this issue precise, then develop an interval layer that ADC can implement without altering the soundness conditions of classical causal inference.

The main result is a set of sufficient reuse contracts. A claim valid over a model set survives restriction to a nonempty subset. A sharp endpoint survives exactly when an attaining model remains feasible. A linear certificate can also be repaired directly after some numerical changes. The resulting bounds can be enough for a decision even when the causal probability is not point identified. Thus the speed mechanism includes avoiding both repeated work and unnecessary precision. The proposal continues the dependency-preserving computation and certified cache-reuse programme of Ghosh (2026c, 2026d).

## 1.1 Literature survey

Pearl's do calculus transforms interventional and observational expressions under graphical separation premises (Pearl, 2012). Shpitser and Pearl (2008) characterize identification across a hierarchy of causal queries. Edge interventions require transmitted values and recursive substitution, rather than merely a graph with missing arrows (Shpitser & Tchetgen Tchetgen, 2016). Partial identification by response models and constrained optimisation has substantial precedent, including Balke and Pearl (1997) and Duarte et al. (2024). We use these foundations; the term IDC here denotes an interval extension and must be distinguished from the established IDC algorithm for conditional identification.

Sound enclosure propagation follows the logic of abstract interpretation (Cousot & Cousot, 1977). Dependency tracking and task reuse are central to incremental build systems (Mokhov et al., 2018). Our construction specializes those ideas to a causal interpreter whose cached records include intervention regimes, separation tests and optimisation certificates. Ghosh (2026a) supplies ADC's response fibres and sequential evidence contract; Ghosh (2026b) separates value certificates, operation licences and latent execution, and characterizes sufficient finite continuation memory.

Neuroscience offers computational precedents for selective reuse. The successor representation stores predictions that support some forms of revaluation more readily than others (Momennejad et al., 2017). Prioritized replay models allocate memory access according to behavioral benefit (Mattar & Daw, 2018), and recurrent planning models connect the decision to simulate with prefrontal and hippocampal dynamics (Jensen et al., 2024). Human sleep research supplies evidence for encoding-related retention tags (Denis et al., 2026). These findings motivate testable design hypotheses; they do not establish a neural implementation of do calculus.

Agent systems already expose useful execution boundaries. SWE-agent studies the interface between a model and its computational environment (Yang et al., 2024). Agent Lightning separates agent execution from reinforcement training (Luo et al., 2025), and its subsequent harness work treats runtime behavior as part of the learning system (He et al., 2026). Engineering work on context compaction and persistent progress records addresses continuation across finite context windows (Anthropic, 2025a, 2025b). IDC adds mathematical conditions under which a retained result can substitute for recomputation.

## 1.2 Contribution

We define two distinct interval objects, prove their relationship to graph surgery and do-calculus rewrites, and specify an immutable causal computation graph. We then prove refinement reuse, endpoint persistence, direct multiplier repair, query transport, decision stopping and dependency-local recomputation. We formulate a horizontal sheaf audit with additional global causal constraints, and show why endpoint summaries alone cannot support arbitrary future operations. The neuroscience mapping and learned scheduling policy remain hypotheses. All mathematical results are stated with their assumptions and proved; several are elementary specializations of established order, convexity and program semantics arguments. We claim an explicit integration for ADC, rather than a new general theory of causal identification, linear duality or biological memory.

Version 2 implements these contracts. Section 12.5 gives four algorithms, and Sections 12.6 to 12.10 report exact censuses that test Lemma 2.2, Proposition 2.3, Theorems 5.1, 5.2 and 5.4, Proposition 6.2 and Theorem 7.3 on finite families. Two short propositions, 12.1 and 12.2, explain what the census shows about refinement repair and joint decisions. The censuses measure behaviour of the stated algorithms; they are not benchmarks of an agent.

Version 3 adds Definitions 4.5 and 11.2, Theorems 5.6, 6.8 and 11.3, Corollary 5.7, Observation 5.8 and Propositions 9.4 and 11.4. Their ingredients are established order, support-function, abstraction and program-safety arguments specialized to the IDC memory contract. Section 10.5 adds four biological predictions H1--H4; earlier N1--N3 and computational C1--C5 retain their separate roles. The original algorithms and census are inherited results, not new harness or biological experiments.

## 1.3 Structure

Sections 2--3 define interventions, interval objects and evidence. Sections 4--7 develop persistent assertions, refinement, controlled weakening, coefficient drift, transport and decision stopping. Sections 8--9 state the horizontal and retained-memory contracts. Section 10 develops the neuroscience analogy, including the new Section 10.5 and H1--H4. Section 11 specifies six harness components, request routing, scheduler learning and snapshot checks. Section 12 distinguishes the inherited exact census from the new worked examples. Sections 13--14 retain prospective computational tests and discuss limitations; Appendices A--B give assumptions and reproduction.

# 2 Causal surgeries and ordered responses

## 2.1 A graph cut needs a mechanism

Fix a finite acyclic structural causal model with endogenous variables indexed by a directed acyclic graph and a declared joint distribution of exogenous variables. An unobserved common cause may be represented explicitly. Every intervention below specifies which structural assignments change and which exogenous distribution is retained. Statements about conditional probabilities apply only where their denominators are positive.

**Definition 2.1 (incoming clamp and outgoing replacement).** An incoming clamp at $X$ replaces its structural assignment by $X: = x_{1}$ and is denoted $r_{in}\left( x_{1} \right)$. Its manipulated graph is $G_{\overline{X}}$. An outgoing replacement $r_{out}\left( x_{0} \right)$ substitutes $x_{0}$ for the $X$ argument in every child's structural assignment, retaining the ordinary assignment for $X$. Its effective graph has no outgoing arrows from $X$. A surgery record contains the substituted value, affected mechanisms and outcome query, not only an edge mask.

The underlined graph in Rule 2 is a separation test graph. Treating it as a distribution-generating regime requires the additional replacement semantics of Definition 2.1. We use a baseline transmitted value because it permits a precise comparison with a node intervention. Other replacements, including independent random inputs or changed child functions, define different regimes.

**Lemma 2.2 (baseline transmission).** For a singleton target $X$ and any collection $Y$ of endogenous variables excluding $X$, the joint outcome under $r_{out}\left( x_{0} \right)$ equals the joint outcome under $do\left( X = x_{0} \right)$, when the remaining assignments and exogenous state are identical.

*Proof.* Order the endogenous variables topologically. A variable other than $X$ receives the same parent arguments under both regimes: each occurrence of $X$ is replaced by $x_{0}$, and every other parent agrees by induction. Its structural assignment and exogenous argument are unchanged. Induction gives pointwise agreement of the entire vector excluding $X$. Taking its distribution proves the claim. The original $X$ itself need not agree, so adding observations of that variable changes the statement. $▫$

**Proposition 2.3 (cuts do not order probabilities).** A fixed causal graph does not imply that an incoming-clamp response is greater than an outgoing-baseline response.

*Proof.* Let $X$ be binary with graph $X \rightarrow Y$, active value one and baseline zero. The mechanism $Y = X$ gives incoming and outgoing outcome means one and zero. The mechanism $Y = 1 - X$ gives zero and one on the same graph. Both are acyclic models. Hence a graph-level ordering cannot hold for this model class. $▫$

The graph surgeries also need not be comparable by edge inclusion. Removing both classes of edges produces a common subgraph of the incoming-cut and outgoing-cut graphs; each is a subgraph of the original. This structural diamond does not induce a numerical order on causal answers.

## 2.2 A valid interval across interventions

**Definition 2.4 (ordered regime interval).** Let $Y$ be a real outcome with finite expectation, let $Y_{0} = Y_{x_{0}}$ and $Y_{1} = Y_{x_{1}}$, and suppose the declared model class implies $Y_{0} \leq Y_{1}$ almost surely. Define

$$I_{regime}(M) = \left\lbrack \mu_{0}(M),\mu_{1}(M) \right\rbrack,\quad\quad\mu_{j}(M) = \mathbb{E}_{M}\left\lbrack Y_{j} \right\rbrack.\quad\quad\ \ \ \ (1)$$

The order assumption may follow from monotone structural mechanisms or be postulated directly for the potential outcomes. It must be justified in the application. A protective action, for example, may naturally order an adverse outcome in the opposite direction.

**Theorem 2.5 (causal response sandwich).** Under Definition 2.4, the outgoing-baseline and incoming-clamp means are the ordered endpoints in (1). Independently selecting the active regime with probability $\lambda$ and the baseline regime otherwise gives

$$\mu_{\lambda} = (1 - \lambda)\mu_{0} + \lambda\mu_{1},\quad\quad 0 \leq \lambda \leq 1.\quad\quad\ \ \ \ (2)$$

Consequently this family of expected responses fills the whole interval (1).

*Proof.* Lemma 2.2 identifies the baseline-transmission outcome with $Y_{0}$. The assumed pointwise order implies the expectation order. Conditioning on the independent regime selector gives (2). The affine map of the unit interval has image exactly $\left\lbrack \mu_{0},\mu_{1} \right\rbrack$, including the degenerate case. $▫$

This theorem concerns an explicitly randomized choice between two whole regimes. It does not show that arbitrarily deleting more edges, or replacing different outgoing edges at unrelated rates, yields intermediate responses. Without an order premise, the same mixture fills the interval between the minimum and maximum of the two means, but the labels incoming upper and outgoing lower are unavailable.

# 3 Intervals over admissible causal models

## 3.1 Query ambiguity and regime variation

**Definition 3.1 (query enclosure).** Fix a context $\kappa$, a nonempty admissible causal model set $\mathcal{K}$, and a scalar query $\tau$. Its sharp interval hull is

$$I\left( \tau;\mathcal{K} \right) = \left\lbrack \inf_{M \in \mathcal{K}}\tau(M),\ \sup_{M \in \mathcal{K}}\tau(M) \right\rbrack.\quad\quad\ \ \ \ (3)$$

An outer interval contains this hull. A sharpness certificate also establishes endpoint attainability when the extrema are claimed to be attained.

A probability query has values in $\lbrack 0,1\rbrack$. A utility query has its declared utility unit. Interval width is a numerical range; it is not a confidence level. When evidence bounds come from sampling, their simultaneous statistical coverage is an additional premise. If $\mathcal{K}$ is empty, the interpreter reports inconsistent premises rather than a numerically identified answer.

Equation (3) concerns uncertainty about one fixed query. Equation (1) concerns variation across specified interventions in one fixed model. They can be combined by taking an envelope over both models and regimes. Under uniform ordering throughout $\mathcal{K}$, the robust envelope of the mixtures in (2) is

$$\left\lbrack \inf_{M \in \mathcal{K}}\mu_{0}(M),\ \sup_{M \in \mathcal{K}}\mu_{1}(M) \right\rbrack.\quad\quad\ \ \ \ (4)$$

Its width combines model ambiguity and regime variation. It must not be interpreted as the uncertainty width of a single intervention. The sharp range of a contrast $\mu_{1} - \mu_{0}$ requires joint optimisation over the same model, because the two responses share mechanisms and exogenous laws.

## 3.2 The three inherited rules

For pairwise disjoint variable sets $A,X,Y,W$, write $P_{a}$ for the law after setting $A = a$. Pearl's rules retain their classical conditions (Pearl, 2012):

$$P_{a}(y \mid x,w) = P_{a}(y \mid w)\quad\text{if }(Y\bot X \mid A,W)_{G_{\overline{A}}}.\quad\quad\ \ \ \ (5)$$

$$P_{a}\left( y \mid do(x),w \right) = P_{a}(y \mid x,w)\quad\text{if }(Y\bot X \mid A,W)_{G_{\overline{A}\underline{X}}}.\quad\quad\ \ \ \ (6)$$

$$P_{a}\left( y \mid do(x),w \right) = P_{a}(y \mid w)\quad\text{if }(Y\bot X \mid A,W)_{G_{\overline{A}\overline{X(W)}}}.\quad\quad\ \ \ \ (7)$$

Here $X(W) = X \smallsetminus An(W)_{G_{\overline{A}}}$. In a latent model these conditions are evaluated in the appropriate full latent graph, or through a justified equivalent graphical representation. The order of autoregressive computation supplies none of these separation premises.

**Proposition 3.2 (range invariance under certified rewrites).** If expressions $f$ and $g$ have the same value in every model of a fixed nonempty $\mathcal{K}$, their sharp interval hulls on $\mathcal{K}$ are equal. In particular, a finite derivation using (5) to (7) and justified probability algebra preserves the hull.

*Proof.* The sets of attained values coincide pointwise, so their infima and suprema coincide. Each licensed derivation step establishes the required pointwise equality, and finite composition preserves it. $▫$

Additional computation may tighten a numerical outer enclosure by exploiting identities or dependencies. It cannot reduce the exact hull on an unchanged model set. Genuine reduction of that hull requires new constraints or a revised query. This separates a solver improvement from information acquisition.

## 3.3 A common response space

**Definition 3.3 (finite response model and evidence snapshot).** Let $q$ be a probability vector over a declared finite set of deterministic response types. With $\Delta_{n} = \{ q \geq 0:\mathbf{1}^{\top}q = 1\}$, define

$$K_{t} = \{ q \in \Delta_{n}:A_{t}q \leq b_{t},\ E_{t}q = f_{t}\},\quad\quad\tau_{c}(q) = c^{\top}q.\quad\quad\ \ \ \ (8)$$

Every row records its source, regime, variable meanings and units. An evidence refinement adds valid rows or tightens existing bounds while preserving the same coordinates and target meanings, and requires $K_{t + 1} \neq \varnothing$.

Linearity in (8) is valid for a declared common-latent response model, or one unknown response block with other factors fixed. Several independently varying latent districts generally produce multilinear constraints and targets. Replacing their product structure by one unrestricted joint response law can change the causal model. The set-based reuse results below still apply to general nonempty model sets, but the linear certificate formulas require (8) or a certified outer relaxation of it.

Conditional probabilities may give a ratio of linear forms. A positive denominator permits a linear fractional transformation or validated ratio bounds. A denominator interval containing zero cannot be repaired by simply dividing endpoint numbers. We focus on linear queries to state the strongest reusable formulas without silently extending them to arbitrary rational expressions.

# 4 Immutable operations and shared execution

## 4.1 The record and its validity contract

**Definition 4.1 (immutable operation record).** A record contains a context key, operator and version, ordered operand identifiers, output expression, numerical enclosure, certificate, premise dependencies and validity scope. It also records whether the claim is a graph identity, an equality on a specified law, an outer bound or a sharp bound. Accepted records are immutable. A corrected computation creates a new record referencing the relevant predecessors.

The context key binds semantic objects, including the graph and latent class, intervention replacement, event interpretation, query, population, units and evaluator. A content digest supports lookup and change detection. It does not establish truth, authenticity or a causal interpretation. Graph cuts with different transmitted values require different regime identities even when their adjacency masks coincide.

**Table 1 Reusable objects and their contracts**

  -----------------------------------------------------------------------------------------------------------------------
  **Stored object**          **Premise that permits reuse**                         **Work that may be avoided**
  -------------------------- ------------------------------------------------------ -------------------------------------
  Separation certificate     Same graph semantics and separation statement          Another graphical search

  Causal expression          Same query or a certified equivalence                  Another identification derivation

  Exact table                Same law and input meanings                            Repeated table construction

  Outer interval             Same target on a certified subset of models            Another bound solve

  Sharp interval             Outer validity and surviving endpoint witnesses        Another exact endpoint solve

  Optimisation multipliers   Validity checked or repaired for current constraints   Solver search for a new certificate

  Decision certificate       Same actions and utility semantics                     Unnecessary numerical refinement
  -----------------------------------------------------------------------------------------------------------------------

**Definition 4.2 (operation graph).** Let $D$ be a finite directed acyclic graph of records. Leaves are authoritative inputs or checked imported claims. An internal node is a deterministic partial operation on its parent values with a declared precondition. Its dependency set includes numerical operands and semantic premises. Repeated references share a node; a different textual derivation is merged only through a justified identity.

This construction supports structural sharing between branches. The incoming-clamp branch and outgoing-baseline branch may share unchanged mechanisms, graph metadata or observation tables while retaining distinct intervention nodes. Sharing does not identify the two causal quantities.

## 4.2 Correctness and cost

**Theorem 4.3 (sound memoized execution).** Assume every leaf has its declared meaning, every primitive operation is correct under its checked precondition, and a cache hit either has the identical contract and inputs or carries a checked transport proof. Executing $D$ with cache hits gives the same exact values, or sound enclosures, as executing its specified operations from the leaves.

*Proof.* Take a topological order of $D$. The statement holds at the leaves. At an uncached node, the inductive parent claims and checked precondition justify the primitive operation. At a cached node, its contract or transport proof establishes the same claim for the current parents. Induction reaches every requested output. For interval primitives the induction uses containment rather than equality. $▫$

The theorem is relative to the input semantics and trusted checker. A language model extracting the wrong graph from prose can produce a correctly executed answer to the wrong question. Equality of output numbers in one dataset also does not establish a graph-universal operation licence, as the counterexamples in Ghosh (2026b) show.

**Corollary 4.4 (prefix recomputation cost).** Suppose a chain adds one fixed-cost deterministic operation per step, every earlier result stays cached, and lookup and append costs are bounded. Rebuilding every prefix through step $n$ performs $n(n + 1)/2$ operation evaluations. Incremental execution evaluates $n$ operations.

*Proof.* The prefix lengths sum to $1 + \cdots + n$. Incremental execution evaluates each distinct node once. $▫$

The corollary counts primitive evaluations. A causal optimisation can have a large and variable cost, and memory access can grow with the number of dependencies. Cache eviction may cause additional evaluations. Thus the result is not a universal quadratic improvement in wall time or an assertion that attention over retained states becomes constant cost.

## 4.3 Persistent assertions and changing applicability

**Definition 4.5 (scope and strength of a stored claim).** Write a bound claim as $(\kappa,K,\tau,I)$, asserting $\tau(M) \in I$ for every $M \in K$. The semantic context $\kappa$ fixes event meanings, interventions, coordinates, units and operator versions. For the same context and query, certified inclusion $K\prime \subseteq K$ and interval inclusion $I \subseteq J$ justify the weaker served claim $(\kappa,K\prime,\tau,J)$. This is a sufficient entailment rule, rather than a complete comparison of all logically equivalent claims.

The archive preserves what was asserted under its original premises. A changed applicability decision is a new record that cites the old one. The old record is not edited from "sharp" to "outer"; a new service record states that only an outer guarantee has been established for the new snapshot. A subsequently discovered false input is also recorded explicitly. Immutability supplies an audit history, not permanent truth or permanent applicability.

Interval widening alone does not repair a changed context. If the old scope contains only a model with query value one and the new scope only a model with value zero, widening $\lbrack 1,1\rbrack$ to $\lbrack 0.9,1\rbrack$ is still false in the new scope. A safe weakening requires inclusion or another checked transport argument. A generic gist, prose summary or nearby embedding is not automatically such an argument.

# 5 Reuse under sequential evidence

## 5.1 Outer bounds and sharp endpoints

**Theorem 5.1 (refinement reuse).** Let $\varnothing \neq K\prime \subseteq K$ and let $\lbrack L,U\rbrack$ enclose a fixed query $\tau$ on $K$. Then the same interval encloses $\tau$ on $K\prime$. If extrema exist, the sharp lower endpoint cannot decrease and the sharp upper endpoint cannot increase.

*Proof.* Every member of $K\prime$ belongs to $K$, so the old inequalities hold on $K\prime$. Taking a minimum over a subset cannot decrease it; taking a maximum cannot increase it. $▫$

This is the set-theoretic reuse contract already present in ADC's sequential evidence formulation (Ghosh, 2026a). Its computational use is to allow immediate service from an old enclosure while a tighter solve remains optional. A valid old interval can be retained with the label outer bound after its old sharpness status has been lost.

**Theorem 5.2 (endpoint persistence).** Suppose $K$ and $K\prime$ are nonempty compact sets with $K\prime \subseteq K$, and $\tau$ is continuous. An old endpoint remains sharp exactly when at least one old attaining model for that endpoint lies in $K\prime$.

*Proof.* If an old attaining model survives, Theorem 5.1 bounds all new values on one side while that model attains equality. Conversely, compactness of $K\prime$ and continuity guarantee attainment there. If the old endpoint remains sharp, its new attaining model belongs to $K$ and is therefore an old attaining model that survives. $▫$

For application we take both sets to be nonempty compact polytopes, so the attainment condition is automatic for a linear query. Checking one stored witness is a sufficient shortcut, but its failure does not prove the endpoint has changed: a different old attaining model may survive.

**Corollary 5.3 (witness shortcut).** For compact polytopes $K\prime \subseteq K$, if the stored lower and upper optimizers remain feasible, both old endpoints remain sharp. Testing only the added or tightened rows suffices when the retained constraints and coordinate interpretation are already certified.

*Proof.* Apply the sufficient direction of Theorem 5.2 separately to the two witnesses. $▫$

## 5.2 Direct repair of linear certificates

Absorb equality constraints into pairs of inequalities and write a current nonempty polytope as $K(A,b) = \{ q \in \Delta_{n}:Aq \leq b\}$. Let $\lambda$ have one nonnegative component per inequality row.

**Theorem 5.4 (multiplier repair).** For any $\lambda \geq 0$, define

$$B_{\lambda}(c;A,b) = \lambda^{\top}b + \max_{i}\{ c_{i} - \left( A^{\top}\lambda \right)_{i}\}.\quad\quad\ \ \ \ (9)$$

Then $c^{\top}q \leq B_{\lambda}(c;A,b)$ for every $q \in K(A,b)$. Hence independently chosen nonnegative multipliers $\lambda_{+}$ and $\lambda_{-}$ give the outer interval

$$\left\lbrack - B_{\lambda_{-}}( - c;A,b),\ B_{\lambda_{+}}(c;A,b) \right\rbrack.\quad\quad\ \ \ \ (10)$$

*Proof.* For feasible $q$, write $c^{\top}q = \lambda^{\top}Aq + \left( c - A^{\top}\lambda \right)^{\top}q$. The first term is at most $\lambda^{\top}b$ by nonnegativity of $\lambda$. The second is a convex combination of residual coordinates and is therefore at most their maximum. Apply the same argument to $- c$ for the lower bound. $▫$

Equation (9) does not require $\lambda$ to solve the current dual problem. A multiplier from an earlier solve can propose a new certificate whose validity is checked by the displayed arithmetic. The maximum residual supplies the free normalization multiplier in the usual dual. Taking the infimum of (9) over nonnegative multipliers recovers the exact upper endpoint by finite linear programming duality. Thus repair is sound immediately, although it may be conservative.

For a refinement, old rows retain their meanings and added rows receive zero multipliers. For changed numerical rows in the same declared response space, use the new $A,b,c$ in (9). This remains valid even without set inclusion. A removed or reinterpreted row cannot retain a multiplier as though its old assertion were still available; the multiplier vector must first be aligned to the current constraints. No coefficient calculation transports a changed physical meaning by itself.

The C# kernel retains free multipliers $\nu$ on equality rows $Eq = f$. This is equivalent to the nonnegative convention in (9): replace each equality by $Eq \leq f$ and $- Eq \leq - f$, with multipliers $\lbrack\nu\rbrack_{+}$ and $\lbrack - \nu\rbrack_{+}$. Equality multipliers therefore need not have a nonnegative sign. The new drift bound applies after this canonical expansion; for shared symmetric errors its equality-row sensitivity uses $|\nu|$.

**Proposition 5.5 (repair and witnesses certify exactness).** If a feasible $q_{*}$ satisfies $c^{\top}q_{*} = B_{\lambda}(c;A,b)$, that value is the sharp upper endpoint. The analogous equality for $- c$ certifies the lower endpoint.

*Proof.* Theorem 5.4 gives an upper bound; the feasible point attains it. No larger or smaller upper endpoint is possible. $▫$

The repair cost is a sparse matrix-vector product, a dot product and a coordinate maximum, apart from input checking. It avoids solver search, not all arithmetic. Exact rational calculations or outward-rounded validated arithmetic are required for rigorous certificates; an unchecked floating-point residual is not an exact inequality proof.

## 5.3 Weakening certificates when premises are discarded

Forgetting an evidence constraint enlarges the set of models that the retained information allows. This differs from adding consistent evidence. Let $R$ index retained rows and $J$ deleted rows of $Aq \leq b$ on the same response simplex, and let $K_{R} = \{ q \in \Delta_{n}:A_{R}q \leq b_{R}\}$ be nonempty. The rows must remain semantically aligned; an unavailable row receives no multiplier in a current certificate.

**Theorem 5.6 (a certified cost of dropping premises).** Let $\lambda \geq 0$ be an old multiplier vector, and let $B_{old} = B_{\lambda}(c;A,b)$. Set

$$\Gamma_{J} = \max_{i}\sum_{j \in J}^{}\lambda_{j}\left( A_{ji} - b_{j} \right),\quad\quad\lbrack x\rbrack_{+} = \max(0,x).$$

For every $q \in K_{R}$,

$$c^{\mathsf{T}}q \leq B_{\lambda_{R}}\left( c;A_{R},b_{R} \right) \leq B_{old} + \left\lbrack \Gamma_{J} \right\rbrack_{+}.$$

The nonnegative surcharge can be attained. A simpler, possibly looser surcharge is $\sum_{j \in J}^{}\lambda_{j}\left\lbrack \max_{i}A_{ji} - b_{j} \right\rbrack_{+}$.

*Proof.* The first inequality is Theorem 5.4 on the retained rows. Put $r = c - A^{\mathsf{T}}\lambda$ and $v = A_{J}^{\mathsf{T}}\lambda_{J}$. The difference between the repaired and old certificates is

$$- \lambda_{J}^{\mathsf{T}}b_{J} + \max_{i}\left( r_{i} + v_{i} \right) - \max_{i}r_{i} \leq \max_{i}\left( v_{i} - \lambda_{J}^{\mathsf{T}}b_{J} \right) = \Gamma_{J}.$$

Replacing this by its positive part gives a nonnegative allowance. Bounding a maximum of sums by the sum of the coordinatewise maxima gives the simpler surcharge. For sharpness, take $q \in \Delta_{2}$, $c = (1,0)$, one row $q_{1} \leq 1/5$ and $\lambda = 1$. The old certificate is $1/5$; dropping the row gives upper endpoint one and surcharge $4/5$, attaining the bound. ∎

This formula gives a query-dependent price for permanently losing a premise. Evicting its text from the language context is different: if its authoritative record and proof remain retrievable, the premise has not been logically discarded. A low surcharge can guide retention, but it does not establish a generally optimal cache policy. Constraints may be complementary, and retaining only one query's cheap certificate can harm other queries.

**Corollary 5.7 (a portfolio of valid certificates).** Suppose finitely many checked intervals $\left\lbrack L_{j},U_{j} \right\rbrack$ each enclose the same query on the same current nonempty model set. Their intersection

$$\left\lbrack \max_{j}L_{j},\ \min_{j}U_{j} \right\rbrack$$

is a valid enclosure, and adding another valid certificate cannot widen it.

*Proof.* Every feasible query value belongs to every interval and therefore to their intersection. The maximum lower endpoint cannot decrease and the minimum upper endpoint cannot increase when another interval is added. ∎

Old certificates with different scopes may be combined only after each has been justified on the current set. An empty intersection contradicts the declared joint premises; it is not automatically proof that the physical system is impossible. The source of the contradiction must be checked. Portfolio improvement tightens an outer enclosure and does not change the exact query range on an unchanged model set.

**Observation 5.8 (width does not order refinement durability).** Theorem 5.1 preserves every valid outer interval, including a valid point interval. It makes no comparison between the biological durability of coarse and precise memories. Moreover, failure of one stored optimizer does not establish loss of sharpness. In the inherited upper-endpoint census, $1,258 + 2,676 = 3,934$ of 6,000 endpoints remained unchanged, or 65.6%, although the selected witness survived only 21.0%. The lower-endpoint persistence rate is 65.1%. These are different objects and different denominators of interest. Section 10.5 treats preferential cortical coarsening as a hypothesis requiring evidence beyond these logical facts.

# 6 Transport to nearby queries and model sets

## 6.1 Query changes on a common response space

**Lemma 6.1 (simplex residual range).** For $q \in \Delta_{n}$ and $d \in \mathbb{R}^{n}$,

$$\min_{i}d_{i} \leq d^{\top}q \leq \max_{i}d_{i}.\quad\quad\ \ \ \ (11)$$

Both bounds are attainable on the simplex.

*Proof.* The scalar is a convex combination of the coordinates of $d$. A simplex vertex at a minimizing or maximizing coordinate attains the corresponding endpoint. $▫$

**Proposition 6.2 (cheap query transport).** If $\lbrack L,U\rbrack$ encloses $c^{\top}q$ on $K \subseteq \Delta_{n}$, then for $c\prime = c + d$ it follows that

$$c\prime^{\top}q \in \left\lbrack L + \min_{i}d_{i},\ U + \max_{i}d_{i} \right\rbrack\quad(q \in K).\quad\quad\ \ \ \ (12)$$

The same transported interval applies on any nonempty subset of $K$.

*Proof.* Add the inequalities for the old query to (11), then apply Theorem 5.1 for a subset. $▫$

The transported interval may be wider than a fresh joint optimisation because the extrema of the two summands may occur at different models. It is useful when its cheap bound already answers the next query. It is also exact for a constant residual $d = a\mathbf{1}$, where the new query is the old one plus $a$.

## 6.2 Quantified displacement of admissible models

Define $osc(c) = \max_{i}c_{i} - \min_{i}c_{i}$. For nonempty compact subsets of the same probability simplex, define the directed distance

$$h_{1}(K\prime,K) = \sup_{q\prime \in K\prime}\inf_{q \in K} \parallel q\prime - q \parallel_{1}.\quad\quad\ \ \ \ (13)$$

This is a one-sided coverage condition: every new model lies close to some old model. It is an additional certified input, not a consequence of two datasets looking similar.

**Lemma 6.3 (oscillation bound).** For probability vectors $p,q$,

$$\left| c^{\top}(q - p) \right| \leq \frac{1}{2}osc(c) \parallel q - p \parallel_{1}.\quad\quad\ \ \ \ (14)$$

*Proof.* Subtract the midpoint of the largest and smallest coordinates from $c$. The subtraction does not change its dot product with $q - p$, whose coordinates sum to zero. The resulting coefficient vector has infinity norm $osc(c)/2$. Apply the dual norm inequality. $▫$

**Theorem 6.4 (query and model transport).** Suppose $\lbrack L,U\rbrack$ encloses $c^{\top}q$ on nonempty compact $K \subseteq \Delta_{n}$, $K\prime \subseteq \Delta_{n}$ is nonempty compact, $h_{1}(K\prime,K) \leq \delta$, and $c\prime = c + d$. Put $\eta = osc(c)\delta/2$. Then

$$c\prime^{\top}q\prime \in \left\lbrack L + \min_{i}d_{i} - \eta,\ U + \max_{i}d_{i} + \eta \right\rbrack\quad(q\prime \in K\prime).\quad\quad\ \ \ \ (15)$$

*Proof.* For each $q\prime$, compactness provides $q \in K$ at distance at most $\delta$. Decompose $c\prime^{\top}q\prime = c^{\top}q + c^{\top}(q\prime - q) + d^{\top}q\prime$. Bound the three terms using the old interval, Lemma 6.3 and Lemma 6.1. $▫$

**Proposition 6.5 (the transport constant is sharp).** The coefficient $1/2$ in (14) cannot be uniformly reduced. For any nonconstant $c$, choose indices $i,j$ attaining its maximum and minimum, set $p = e_{j}$ and $q = (1 - \alpha)e_{j} + \alpha e_{i}$. Then equality holds in (14) for every $0 \leq \alpha \leq 1$.

*Proof.* The left side is $\alpha osc(c)$ and the distance is $2\alpha$. $▫$

The theorem is invariant to adding a constant to $c$, which is appropriate because normalized response vectors agree on constant queries. For a general data vector without normalization, this improvement over an infinity-norm bound is unavailable. When an exact response-set distance is difficult to certify, Theorem 5.4 may provide a cheaper route from current constraints. The two results solve different transport problems and need not be applied together.

## 6.3 A family of queries can share one optimizer

For a feasible $q_{*}$ in a compact convex set $K$, define its normal cone by $N_{K}\left( q_{*} \right) = \{ v:v^{\top}\left( q - q_{*} \right) \leq 0\text{ for all }q \in K\}$. A query vector belongs to this cone exactly when $q_{*}$ maximizes that query. Thus a cache can index a certified family of directions, rather than only one coefficient vector.

**Theorem 6.6 (normal cone certificate).** Let $K = K(A,b)$ be nonempty, let $q_{*} \in K$, let $I$ index its active inequality rows, and let $Z = \{ i:q_{*i} = 0\}$. Then

$$N_{K}\left( q_{*} \right) = \left\{ A_{I}^{\top}\lambda + \nu\mathbf{1} - \sum_{i \in Z}^{}\zeta_{i}e_{i}:\lambda \geq 0,\ \zeta_{i} \geq 0,\ \nu \in \mathbb{R} \right\}.\quad\quad\ \ \ \ (16)$$

*Proof.* For a displayed vector, dotting with $q - q_{*}$ makes every active-row term nonpositive, the normalization term zero, and every negative-coordinate term nonpositive. This proves inclusion in the normal cone. Conversely, for $v \in N_{K}\left( q_{*} \right)$, the feasible point $q_{*}$ solves the bounded linear maximization of $v^{\top}q$. Linear programming duality gives $v = A^{\top}\lambda + \nu\mathbf{1} - \zeta$ with nonnegative $\lambda,\zeta$ and zero duality gap at $q_{*}$. The nonnegative complementary slack terms must each vanish, so only active rows and zero coordinates can carry positive multipliers. This is the displayed representation. $▫$

**Corollary 6.7 (exact reuse across query directions).** A checked representation (16) for a new vector $c\prime$ certifies its upper endpoint as $c\prime^{\top}q_{*}$. If $K\prime \subseteq K$ and $q_{*}$ remains feasible in $K\prime$, that endpoint also remains exact on $K\prime$.

*Proof.* Theorem 6.6 gives maximality on $K$. Subset validity and the surviving witness give maximality on $K\prime$. $▫$

Finding the representation can itself require a solve. Once proposed, however, its equality, multiplier signs and active rows can be checked directly. The result therefore supplies a reusable certificate domain; it does not promise constant-cost membership in an arbitrary high-dimensional normal cone.

## 6.4 Certificate repair with bounded numerical reconstruction error

Stored coefficients can be reconstructed approximately without pretending that a drifting representation is an unchanged record. The semantics still have to match; numerical error bounds cannot certify a change in what an event or intervention means.

**Theorem 6.8 (a certificate under bounded coefficient drift).** Let the current true model set be the nonempty $K(A,b)$ of Section 5.2, with query $c^{\mathsf{T}}q$. Let reconstructed coefficients satisfy, for every row $j$,

$$\parallel A_{j} - {\widetilde{A}}_{j} \parallel_{\infty} \leq a_{j},\quad\quad\left| b_{j} - {\widetilde{b}}_{j} \right| \leq d_{j},\quad\quad \parallel c - \widetilde{c} \parallel_{\infty} \leq e,$$

where all radii are nonnegative and the rows use the same declared coordinates and compatible units. For any checked $\lambda \geq 0$,

$$c^{\mathsf{T}}q \leq B_{\lambda}\left( \widetilde{c};\widetilde{A},\widetilde{b} \right) + e + \sum_{j}^{}\lambda_{j}\left( a_{j} + d_{j} \right)\quad\quad\left( q \in K(A,b) \right).$$

*Proof.* Since $q$ is a probability vector, $\left( {\widetilde{A}}_{j} - A_{j} \right)q \leq a_{j}$, so ${\widetilde{A}}_{j}q \leq {\widetilde{b}}_{j} + a_{j} + d_{j}$. Also $c^{\mathsf{T}}q \leq {\widetilde{c}}^{\mathsf{T}}q + e$. Apply Theorem 5.4 with the enlarged reconstructed right-hand side, then collect the added multiplier terms. ∎

The lower bound follows by applying the theorem to $- c$, with its own nonnegative multipliers. The allowance is a probability or utility error in the query's stated unit; it cannot be combined with unnormalized representation distances. The result permits a real numerical tolerance contract. It does not infer coefficient radii from neural similarity, average decoding error or representational drift alone.

For example, reconstruct the row $q_{1} \leq 1/5$ as $q_{1} \leq 19/100$, with $d_{1} = 1/100$ and all other errors zero. With $\lambda = 1$ the uncorrected certificate is $19/100$, which is too small for the true set. The corrected certificate is exactly $1/5$. A false numerical memory becomes usable through a checked allowance, rather than through a claim that its content never changed. Large multipliers amplify coefficient uncertainty, suggesting that retention should account for certificate sensitivity as well as record size and access frequency.

# 7 Stopping when a decision is already certified

## 7.1 Precision and action comparisons

**Proposition 7.1 (interval precision).** If a scalar query is known to lie in $\lbrack L,U\rbrack$, its midpoint has absolute error at most $(U - L)/2$. No scalar based only on that interval can improve this worst-case guarantee when both endpoints remain possible.

*Proof.* The midpoint is equidistant from the endpoints. For any scalar $z$, the triangle inequality gives $U - L \leq |U - z| + |z - L|$, so one endpoint is at least half the width away. $▫$

A requested absolute error $\varepsilon$ therefore permits stopping once a sound enclosure has width at most $2\varepsilon$. This is a numerical precision rule. It does not turn a structurally nonidentified query into a point-identified one.

**Definition 7.2 (regret on a common model set).** For a finite action set $\mathcal{A}$ and utilities $V_{a}$ in the same unit, define

$$R_{K}(a) = \sup_{M \in K}\left\{ \max_{b \in \mathcal{A}}V_{b}(M) - V_{a}(M) \right\}.\quad\quad\ \ \ \ (17)$$

For affine utilities on a response polytope, $R_{K}(a) = \max_{b}\sup_{q \in K}\left( V_{b}(q) - V_{a}(q) \right)$. Each inner problem is linear and preserves shared parameters. Independent interval subtraction gives a valid but potentially weak outer bound.

**Theorem 7.3 (decision stopping).** If a certificate establishes $R_{K}(a) \leq \varepsilon$, action $a$ is within $\varepsilon$ of the best available action in every model in $K$. The certificate remains valid on every nonempty subset of $K$. If a lower bound on $V_{a} - V_{b}$ is nonnegative for every competitor $b$, action $a$ is optimal throughout $K$.

*Proof.* The definition bounds each model's utility loss. Restricting the supremum to a subset preserves the bound. The final condition states the required pointwise comparisons directly. $▫$

For action search, a candidate with certified upper utility below another candidate's certified lower utility can be discarded. This pruning concerns the declared maximization task. It is not a general permission to delete a causal model or to use an upper-bound pruning rule in a minimization problem.

## 7.2 A ceiling on further internal computation

**Theorem 7.4 (computation benefit ceiling).** Suppose the available action set and its true utilities remain fixed during an additional internal computation. If the current action $a$ has certified regret at most $\varepsilon$ and the computation incurs deterministic cost $\kappa \geq \varepsilon$ in the same utility unit, no action chosen after that computation can improve net utility over executing $a$ immediately, in any admissible model.

*Proof.* Whatever additional action $b$ is selected, $V_{b}(M) - V_{a}(M) \leq \varepsilon$ for every $M$. Therefore $V_{b}(M) - \kappa \leq V_{a}(M)$. The argument holds for every realized choice of a randomized computation as well. $▫$

This is a sufficient stopping condition, not an optimal general metareasoning policy. It excludes computations that create new external actions, change the world, benefit later tasks or acquire data whose future value is outside the stated utility. A low cost does not prove that more computation is worthwhile. The result supplies a ceiling that a scheduler can use without computing the exact value of computation.

For probabilistic evidence, every stopping certificate also needs the declared simultaneous coverage event. A convenient contract assumes that with probability at least $1 - \alpha$ the true response law belongs to all snapshots. On that event all the deterministic reuse and stopping claims hold simultaneously, including at an adaptively chosen stopping step. Repeated fixed-time intervals do not automatically supply this event; time-uniform methods or explicit error spending are required (Howard et al., 2021).

# 8 Horizontal sheaf data and dependency locality

## 8.1 Keep the indexing structures separate

A physical causal graph records possible causal ancestry. A horizontal context base records which local descriptions overlap. An operation graph records computational dependence. An evidence order records which snapshots refine which others. A physical clock can constrain the first graph, but operation order does not become physical time. A layer representation of a learned model is another declared index and cannot be substituted for any of these structures.

Stalks are data spaces. A token or reasoning state carries values and a vertical diagram through computational stages; it is not itself a stalk. Maps between changed bases require a specified base map and the appropriate inverse-image construction, with commuting squares where two routes claim the same restriction. The present paper does not infer those maps from spatial proximity. Units and coordinate meanings are fixed before residuals are computed.

**Definition 8.1 (horizontal compatibility model).** Let a declared finite sheaf have local data spaces $V_{i}$ and restriction maps to overlaps. In a graph presentation its compatible section space is

$$S = \{\left( s_{i} \right):\rho_{i,ij}s_{i} = \rho_{j,ij}s_{j}\text{ for every overlap }ij\}.\quad\quad\ \ \ \ (18)$$

Higher-dimensional presentations also require the usual composition identities. Local admissibility sets $C_{i} \subseteq V_{i}$ and global causal constraints $C_{causal}$ define

$$K_{S} = S \cap \prod_{i}^{}C_{i} \cap C_{causal}.\quad\quad\ \ \ \ (19)$$

Equation (19) defines the actual feasible section set; its nonemptiness is checked separately. A marginal table on each context may satisfy every pairwise overlap equation and still lack a global probabilistic or causal realization. Thus a compatible linear section and an admissible response model are different claims. When response coordinates $q$ induce local data through maps $s_{i} = T_{i}q$, those maps and the causal constraints preserve the common parameter identity.

**Proposition 8.2 (local compatibility does not license a causal rewrite).** Satisfying (18) alone cannot establish that a proposed adjustment or action-observation exchange is valid.

*Proof.* Local tables obtained by marginalizing one observational joint law satisfy the overlap equalities. The same law can be evaluated by an invalid adjustment formula whose graph premise fails. Compatibility therefore holds independently of whether that formula identifies the intervention. A condition absent from (18) cannot be inferred from it. $▫$

## 8.2 Exactly which updates are local

**Theorem 8.3 (dependency-local recomputation).** Let $D$ satisfy Definition 4.2 and Theorem 4.3, with complete declared dependencies. After changing a set of input or premise nodes $C$, every node outside the forward reachable set of $C$ retains the same specified computation and claim. Recomputing or revalidating only reachable requested nodes is sufficient, provided every changed dependency is included in $C$.

*Proof.* A node outside that reachable set has no changed predecessor. Induction in topological order leaves its operands and premises unchanged, hence its deterministic operation and checked claim unchanged. Every potentially affected path lies inside the reachable set and is covered by the stipulated revalidation. $▫$

This is semantic locality in a computation graph. A small geographical or horizontal neighborhood need not be a small dependency neighborhood. A graph edit may invalidate many separation certificates; conditioning on a new variable can change tables across multiple contexts. The sheaf organizes matching local data, while the dependency graph determines the safe recomputation boundary.

# 9 Retained frontiers and sufficient memory

## 9.1 A frontier can replace an execution prefix

**Definition 9.1 (retained frontier).** For fixed requested outputs in $D$, a retained frontier is a set of validated nodes that intersects every path from an omitted input or omitted intermediate node to those outputs. Each frontier node retains its current value or sound enclosure, type, contract and proof reference. Any separate semantic premises needed by downstream nodes are retained as inputs too.

**Theorem 9.2 (frontier sufficiency).** Under the pure-operation assumptions of Theorem 4.3, execution from a retained frontier produces the same specified downstream exact values, or sound downstream enclosures, as execution from the full graph. The omitted history need not be loaded into active memory.

*Proof.* Treat frontier claims and retained premises as the leaves of the downstream subgraph. Every path from an omitted computation reaches a retained node before an output, so no downstream operator has an unavailable dependency. Apply Theorem 4.3 to this subgraph. With sound but coarser frontier intervals, containment is preserved although the final enclosure need not equal a freshly tightened one. $▫$

An audit archive may retain the complete proof history while active memory retains only the frontier. The theorem permits this separation without requiring biological memory or a neural hidden state to store a literal operation log. A new output family can require a different frontier, and any later rechecking must still be able to obtain the referenced premises and proofs.

## 9.2 Endpoint summaries lose dependencies

**Proposition 9.3 (intervals alone are insufficient continuation state).** Identical marginal intervals for two quantities do not determine the sharp interval of their difference.

*Proof.* Let $K_{1} = \{(a,b):a = b,\ 0 \leq a \leq 1\}$ and $K_{2} = \lbrack 0,1\rbrack^{2}$. In both sets, the marginal ranges of $a$ and $b$ are $\lbrack 0,1\rbrack$. On $K_{1}$ the difference is identically zero; on $K_{2}$ it ranges over $\lbrack - 1,1\rbrack$. A memory consisting only of the two marginal intervals cannot distinguish these continuation answers. Both examples admit ordinary joint probability realizations of two event marginals. $▫$

Expression identities, shared variable identifiers and constraints must therefore remain available when future operations may combine stored quantities. A neural policy can use a compact embedding to retrieve records, but the embedding's similarity score does not establish semantic identity. Numerical cache keys and operation proof keys also differ: identical numbers may arise under different causal regimes.

For a finite deterministic interpreter, Ghosh (2026b) gives the exact continuation criterion: two states may share a sufficient memory code only if every allowed future operation sequence has the same legality and observable outputs from both. The corresponding quotient is sufficient, and inequivalent states require different codes. This is a finite-state minimization result, not evidence that learned continuous vectors automatically realize that quotient.

## 9.3 Retention as a constrained optimisation

For a declared additive workload model, assign record $j$ a future reuse probability $p_{j}$, saved computational cost $g_{j}$, maintenance cost $v_{j}$ and size $s_{j}$. An illustrative retention objective is

$$\max_{x_{j} \in \{ 0,1\}}\sum_{j}^{}x_{j}\left( p_{j}g_{j} - v_{j} \right)\quad\text{subject to }\sum_{j}^{}s_{j}x_{j} \leq B.\quad\quad\ \ \ \ (20)$$

Equation (20) is a knapsack model under its stated additivity assumption. Dependencies can create complementary records, so real reuse value need not be additive or submodular. Selecting only the most frequently accessed records has no general optimality guarantee. A valid policy must also retain a sufficient frontier or accept that missing nodes will be recomputed from available authoritative inputs.

## 9.4 What a semantic summary must preserve

**Proposition 9.4 (the enclosure forced by a summary).** Let a summary map $\sigma$ assign the same memory code $s$ to possibly different nonempty model sets $K$. Define its concretization by

$$\mathcal{K}_{s} = \bigcup_{\sigma(K) = s}K.$$

For a bounded scalar query $\tau$, any interval returned from $s$ alone that is valid for every represented set must contain the interval hull of $\tau\left( \mathcal{K}_{s} \right)$. That hull is the least such closed interval.

*Proof.* Each model in the union belongs to some represented set, so uniform validity requires its query value to lie in the returned interval. Its closed interval hull must also lie there. Conversely the hull contains all those values and is valid for every represented set. ∎

This is a sound-abstraction statement in the sense of Cousot and Cousot (1977). If a summary merges the diagonal and square of Proposition 9.3, the difference must receive the wider interval. A relational summary retaining $a = b$ need not lose that contrast at all. Thus consolidation can preserve useful dependencies; losing them is a property of the chosen summary and future task family, not a consequence of moving information to cortex. Theorem 9.2 requires a sufficient frontier for its declared outputs and does not predict dependency loss when that requirement is satisfied.

# 10 Neuroscience as a constrained computational analogy

## 10.1 Cached predictions and context changes

Momennejad et al. (2017) found behavioral evidence consistent with a successor representation that supports reward revaluation more readily than some changes in transition structure. The computational analogy is a cache whose reusable predictions depend on a transition model. For IDC, a changed utility vector can often use (12), while a changed causal mechanism requires a new validity argument. This is an analogy between update contracts; a successor representation is not an intervention certificate, and human choices do not reveal exact response polytopes.

**Hypothesis N1 (context-sensitive reuse).** In tasks with matched numerical outcomes, changing the generative context will reduce the behavioral reuse advantage more than a change that can be evaluated from an unchanged transition representation. The informative comparison holds outcome familiarity and perceptual difficulty as constant as possible. Finding equal transfer after structurally consequential and purely evaluative changes would weaken this proposed mapping. It would not refute the mathematical reuse theorems.

## 10.2 Selective replay and the value of more computation

Mattar and Daw (2018) model memory access by the improvement in future choices, with need and gain contributing to replay priority. Theorem 7.4 supplies a different, worst-case ceiling for a formal interpreter: if an action's certified regret is already small, the maximum possible improvement from further internal computation is small. The mathematical ceiling requires known utility bounds. We do not assume that the brain calculates that certificate or that replay benefit is determined by interval width alone.

Jensen et al. (2024) develop a recurrent agent that learns when to perform policy rollouts and relate its planning to human response times and reanalysed rat replay. This supports studying computation as a selected action with a cost. For the IDC harness, the learned choice is whether to retrieve, repair, solve or stop. Its correctness is supplied by the checker; the network's role is to select promising computations. The neural mapping remains an experimentally constrained interpretation, not a derivation of the checker from cortical circuitry.

**Hypothesis N2 (decision-relevant uncertainty).** After controlling for uncertainty magnitude and task difficulty, additional planning or replay will be more strongly related to uncertainty that can change the preferred action than to uncertainty in a decision-irrelevant outcome. A model comparison should include response time and replay measures where available. A width-only account that predicts equally well under held-out decision reversals would weaken the proposed decision-margin interpretation.

## 10.3 Consolidation and retention tags

Denis et al. (2026) associate encoding-related theta activity with the later sleep-dependent retention of episodic material and with subsequent slow-oscillation and spindle coupling. The result motivates retention tags set before replay. An IDC analogue is a record's predicted future utility, sensitivity and verification cost. Neither the reported association nor the analogy establishes that theta encodes causal validity, a mathematical interval or a cryptographic identifier. The proposed tag is a design variable for the artificial system.

**Hypothesis N3 (retention depends on future use).** When a task explicitly changes which relations will be needed later, selective retention should depend on prospective usefulness beyond exposure frequency. The artificial counterpart compares policies with the same storage budget and access history but different future-query contracts. Failure of usefulness-sensitive retention to improve the prespecified future task would refute that implementation hypothesis. A biological test additionally needs an independently specified measure of anticipated usefulness.

## 10.4 Biological memory is revisable

Nader et al. (2000) showed that reactivated fear memories can require protein synthesis for reconsolidation. This places a limit on the immutable-storage analogy: a biological memory can be altered after retrieval. Our immutability requirement is an engineering rule for accepted symbolic records. It permits a later record to supersede an earlier claim, while preserving what was previously asserted and why. We do not propose immutable synapses, permanent truth labels or a one-to-one location for each certificate.

**Table 2 Neuroscience evidence and the proposed artificial counterpart**

  ----------------------------------------------------------------------------------------------------------------------
  **Evidence or model**               **Proposed IDC counterpart**               **Claim that remains unestablished**
  ----------------------------------- ------------------------------------------ ---------------------------------------
  Differential revaluation            Reuse depends on what changed              Neural separation certificates

  Prioritized replay                  Allocate computation by decision benefit   Replay computes sharp causal bounds

  Recurrent planning control          Choose whether to simulate or stop         A cortical implementation of ADC

  Encoding and sleep retention tags   Store anticipated reuse value              Theta represents formal validity

  Reconsolidation after retrieval     Supersede and revalidate claims            Biological engrams are immutable logs
  ----------------------------------------------------------------------------------------------------------------------

## 10.5 Protected claims and revisable cortical memory

IDC's immutability is a rule for an engineered assertion history. No evidence shows that neocortex stores an append-only audit graph or computes interval do-calculus. The functional analogy is narrower: preserve a claim's meaning and applicability while allowing later records, new contexts and more conservative guarantees. Biological content can change, and the history of every previous assertion is not known to persist. Definition 4.5 separates this engineering contract from literal synaptic permanence.

**Supersession and extinction.** Bouton's (2004) review describes extinction as context-sensitive new learning, with renewal and spontaneous recovery showing that earlier learning can remain available. This motivates separate context-indexed records rather than a single globally overwritten association. It does not show that all learning updates preserve the old content. Reconsolidation in the amygdala after retrieval (Nader et al., 2000) is direct evidence against a blanket immutability claim. Neither result is specifically evidence for an append-only neocortical store, and absent behavioral recovery alone cannot distinguish erasure from failed retrieval.

**Protected substrates.** Yang et al. (2009) tracked mouse cortical dendritic spines and found long-lived structural stability, including a surviving subset of learning-associated spines. Stable structure can coexist with continuing plasticity. Gogolla et al. (2009) manipulated perineuronal nets in the amygdala and altered the susceptibility of subsequently acquired fear memories to erasure by extinction. This supports a role for extracellular structure in limiting plasticity in that paradigm; it is not a cortical certificate experiment. Tsien's (2013) proposal that net-hole patterns store very long-term memories remains a hypothesis. These findings and proposals motivate protected retention mechanisms without locating individual accepted claims or proving that their information is preserved exactly.

**Schemas and coarse claims.** Winocur and Moscovitch's (2011) transformation account distinguishes detailed episodic remembering from semantic or gist-like representations. Tse et al. (2007) found that an established associative schema can support rapid assimilation and hippocampal independence in a rat task. A gist corresponds to an IDC outer approximation only if a concretization has been specified and shown to contain the represented possibilities, as Proposition 9.4 requires. It is not automatically a numerical interval. All valid outer bounds survive consistent refinement, irrespective of width. The census therefore motivates studying the cost of retaining witnesses and certificates; it does not prove that coarse memories must consolidate better.

**Relations and episodes.** The stored upper optimizer survived 21.0% of the inherited refinements, while the old upper endpoint remained exact in 65.6%. After the observational law changed, reused multipliers produced valid repaired bounds throughout the declared family and exact endpoint pairs in 95.5% and 80.4% of the two change regimes. These are algorithmic outcomes on response polytopes, not retention rates in brains. A feasible witness is one candidate model, not literally an episode; a multiplier vector certifies a constraint combination, not literally a cortical relation. The testable analogy is that reusable relational structure may be retained more effectively than a particular instance. Theorem 5.6 quantifies one artificial cost of discarding that structure, and Theorem 6.8 makes numerical reconstruction error explicit. Reuse requires the multiplier's row references, current constraint data and checked assumptions.

**Meaning under representational drift.** Driscoll et al. (2017) observed changing neuronal activity patterns over weeks in mouse posterior parietal cortex despite stable learned behavior, with information readable at the population level over shorter cross-day spans. This motivates evaluating preserved task meaning rather than equating a memory with permanently assigned cells. It does not establish a perfect cross-time decoder or immutable semantic content. IDC likewise distinguishes a digest, storage address and decoder from the proposition they are meant to support. A changed encoding needs a semantic extraction check; a bounded numeric error can use Theorem 6.8 only when its radii have been justified independently.

**Frontiers and joint information.** Kitamura et al. (2017) found early formation and later functional maturation of prefrontal engrams in a mouse contextual-fear paradigm, with hippocampal support. The remote prefrontal memory remained context specific, while hippocampal engrams could become silent to natural retrieval. This is evidence of circuit reorganization, not a demonstration that an exact sufficient frontier has replaced all history or that hippocampal traces are erased. Proposition 9.3 predicts a loss of dependency-sensitive answers only if the retained summary discards the relevant joint constraints. A cortex that preserves those constraints is compatible with the theory.

The earlier N1--N3 hypotheses concern reuse, replay and usefulness. The following H-series states four additional biological predictions. For each, freeze the task, delay, scoring scale, power and a minimum effect $\Delta > 0$ before data collection. An upper confidence endpoint below the specified minimum refutes that quantitative prediction; an interval crossing it is inconclusive. Null results challenge the stated mapping under those controls, rather than proving a universal alternative memory mechanism.

**Hypothesis H1 (constraints outlast episodes).** At matched initial learning and measurement reliability, delayed transfer of a learned relational constraint to new instances will decline less than recall of the particular training instances, by at least a prespecified $\Delta_{R}$. Match exposure, reward, retrieval demand and initial performance, and report both raw scores and the delayed-minus-initial contrast. Equal durability within a prespecified equivalence band contradicts this strict relational advantage. This tests the multiplier-versus-instance analogy; it does not identify an episode with a feasible response vector.

**Hypothesis H2 (coarse claims resist interference).** At matched initial performance, coarse claims will show at least $\Delta_{C}$ less additional forgetting than finely specified claims after logically consistent interfering evidence, relative to no-interference controls. Keep both original claims valid as outer assertions at the follow-up test and calibrate retrieval difficulty; otherwise ordinary differences in tolerance or the loss of a sharpness label can mimic a memory effect. Equal forgetting within the registered equivalence band refutes this advantage. Theorem 5.1 alone predicts no such difference.

**Hypothesis H3 (superseded relations remain contextually recoverable).** After updating a learned causal relation, reinstating the original context will recover the old relation by at least $\Delta_{S}$ more than a neutral context, under matched cues and verified learning of both relations. Freeze the renewal measure and positive retrieval controls. An upper confidence endpoint below $\Delta_{S}$ refutes the registered recovery prediction. Absence of recovery does not by itself prove that the old trace was overwritten, because access can fail even when some information remains.

**Hypothesis H4 (dependency loss exceeds marginal loss under schematic consolidation).** In a task designed to encourage separate schematic summaries, consolidation will produce at least $\Delta_{J}$ more decline on judgments requiring a learned joint dependency than on matched judgments of each marginal quantity. Compare sleep or delayed retention with an appropriate control and include an explicit relational-rehearsal condition predicted to protect the joint information. Match baseline difficulty and marginal retention. Equivalent decline refutes the proposed selective loss. If the relation is retained, the predicted loss need not occur; frontier sufficiency is conditional on the future queries being supported.

These are prospective tests, with no new human or animal results reported. The engineering proposal is to protect accepted records, append corrections under context contracts, preserve useful constraints and retain selected witnesses when their sharpness benefit justifies their cost. Kirkpatrick et al.'s (2017) elastic weight consolidation supplies a soft parameter-protection analogy. It does not implement a write-protected record store or guarantee exact preservation; Proposition 11.4 makes that distinction explicit.

# 11 An AI harness for certified reuse

## 11.1 Separate proposal from acceptance

The proposed harness contains a semantic registry, a proposal policy, a primitive checker, a persistent operation store, an interval engine and a scheduler. The registry supplies authoritative event definitions, graphs, intervention meanings and unit conventions. The policy proposes the next expression, operation, cached record or experiment. The checker decides which declared claims follow. The interval engine repairs or solves bounds, and the scheduler compares the result with the current precision or decision request.

The six components have different acceptance and storage responsibilities. They are proposed interfaces; the implemented interval kernels do not yet constitute an end-to-end learned harness.

**Table 3 Components of the proposed IDC harness**

  -------------------------------------------------------------------------------------------------------------------------------------------
  **Component**       **Retained authority or proposed action**                      **Required boundary**
  ------------------- -------------------------------------------------------------- --------------------------------------------------------
  Semantic registry   Graph, meanings, interventions, units and evidence snapshots   Context changes create explicit new snapshots

  Proposal policy     Candidate operation, cached record or acquisition              Proposals have no certificate authority

  Primitive checker   Graph premises, multiplier signs and arithmetic                Accept only the declared claim under current premises

  Operation store     Accepted records, dependencies, proofs and scopes              Append corrections and service decisions

  Interval engine     Solve, repair and transport bounds with Algorithms 1--4        Return a checked certificate with each bound

  Scheduler           Select a route and compare guarantees with the request         Stop only when precision or decision requirements hold
  -------------------------------------------------------------------------------------------------------------------------------------------

SWE-agent demonstrates the practical importance of a designed model-computer interface (Yang et al., 2024). Here the interface returns typed claims, premise failures and unresolved obligations. A failed certificate does not prove that its numerical answer is false in the current world; it proves that the requested licence has not been established by that packet. Unsupported operations retain an unverified status.

![The proposal policy selects records or operations. A context check separates exact reuse, evidence refinement and numerical repair. A certificate and a sufficient decision margin permit return. A failed margin triggers only the required additional work. Accepted results append to the persistent operation graph.](./media/image1.png){width="6.35in" height="3.7600732720909886in"}

**Figure 1 Certified reuse in the proposed ADC harness**\
The proposal policy selects records or operations. A context check separates exact reuse, evidence refinement and numerical repair. A certificate and a sufficient decision margin permit return. A failed margin triggers only the required additional work. Accepted results append to the persistent operation graph.

## 11.2 A precise execution policy

The request fixes a query, context contract and acceptance predicate, such as absolute error, a threshold sign or regret tolerance. The following route order is a proposal for implementation, not a measured optimal scheduling rule.

1.  **Resolve a snapshot.** Fix event meanings, causal regime, response coordinates, evidence and units. A feasible witness can establish nonemptiness. A checked infeasibility certificate permits "inconsistent"; failure to find a model permits only "unverified" or further work. Pin the snapshot for the computation.

2.  **Try a semantic match.** Reuse a record only under an identical contract or a checked equivalence. Embedding similarity may retrieve candidates but cannot approve them. Exact equality of numerical arrays does not establish an unchanged intervention or population.

3.  **Try refinement service.** If current evidence gives a certified nonempty subset, return the old interval as an outer guarantee when that already meets the request. If sharpness is required, check the relevant stored witnesses. A failed witness check does not prove an endpoint moved; Algorithm 2 can test the old face or solve again.

4.  **Repair or transport.** For new numerical constraints in the same semantics, align multipliers with current rows, check their signs and evaluate the full residual maximum in (9). Removed rows cannot carry old multipliers. For a changed query use (12), or (15) when a certified model-set displacement is also available. Equations (9) and Theorem 6.8 give sound outer bounds under their premises; exactness still needs a matching witness. Changed meanings require a new semantic argument.

5.  **Check the actual request.** Stop once the precision, threshold or regret certificate suffices. For action selection compare utilities jointly on the common model set with Algorithm 4. The inherited census certified signs in 7.5% of states against 3.2% for separate intervals, a workload result rather than a universal factor. Otherwise perform only the justified further checking, solving or evidence acquisition chosen by the scheduler.

6.  **Commit and append.** Return the achieved guarantee with its snapshot and dependencies. If the request requires the latest registry state, compare versions at commit and revalidate affected claims after a change. Append the new service record. Retain historical assertions and their scopes, and keep arithmetic exactness, enclosure validity and endpoint sharpness distinct.

The census provides a concrete reason to try these routes. Witness reuse avoided 21.5% of endpoint solves. After the mass-0.05 change, repaired bounds were valid throughout the family and exact in 80.4%, while 41.7% of old numerical bounds were false. The more complete face test raised simplex pivots by 13.5%. These are inherited finite algorithm measurements. Only a timed harness comparison can establish whether retrieval, checking and reuse save end-to-end time.

Anthropic (2025a) discusses context compaction, structured notes and retrieval for finite agent contexts. Its long-running agent account emphasizes persistent progress artifacts and checking the current environment before continuing (Anthropic, 2025b). A causal harness can apply those principles while keeping formal records outside the language context. A prose summary helps navigation; the authoritative operands and certificates remain in the operation store. Clearing a tool transcript does not justify discarding a premise needed for later verification.

## 11.3 Learning the scheduler

Agent Lightning separates execution trajectories from training transitions (Luo et al., 2025). The 2026 harness revision further motivates learning with the actual runtime in view (He et al., 2026). For IDC, transitions can record the selected cache route, premise outcome, achieved width, solver cost and accepted decision. These references motivate an execution-training interface; they do not establish the correctness or efficiency of our proposed interval cache.

A learned scheduler can minimize expected cost subject to a checked acceptance condition. Its available operations include Retrieve, VerifyRefinement, CheckWitness, RepairCertificate, SolveBound, AcquireEvidence and Stop. A reward for using fewer words is insufficient: it may encourage bypassing a certificate or moving work into an expensive tool. The training objective should account separately for elapsed time, primitive operations, memory, solver calls and external measurements. All accepted results still pass the same checker.

**Proposition 11.1 (a simple cache benefit condition).** In a declared workload model, let a request cost $C_{s}$ when solved fresh, have serviceable cache-hit probability $p$, lookup cost $C_{l}$, hit-validation cost $C_{v}$ and amortized maintenance cost $C_{m}$. Assume a miss still costs $C_{s}$. Caching reduces expected cost exactly when

$$p\left( C_{s} - C_{v} \right) > C_{l} + C_{m}.\quad\quad\ \ \ \ (21)$$

*Proof.* The expected cached cost is $C_{l} + pC_{v} + (1 - p)C_{s} + C_{m}$. Subtract it from $C_{s}$. $▫$

This model makes the uncertainty about speed explicit. Verification may dominate a small primitive operation. An interval cache may also add overhead when nearly every request changes its semantics. Benchmarking must compare full costs under identical acceptance requirements, including compilation and checking amortization.

**Table 4 Required statuses at the harness boundary**

  ---------------------------------------------------------------------------------------------------------------
  **Status**              **Mathematical content**                   **Permitted continuation**
  ----------------------- ------------------------------------------ --------------------------------------------
  Exact value             A checked equality in its declared scope   Reuse under the same scope

  Sharp interval          Valid bounds with attaining witnesses      Return or transport with a sharpness check

  Outer interval          All admissible values are enclosed         Decide if sufficient or refine

  Unresolved order        Two regimes lack a proved comparison       Preserve both regimes separately

  Unverified operation    No accepted licence for this packet        Seek a proof or another route

  Inconsistent premises   The declared feasible set is empty         Diagnose or revise the evidence contract
  ---------------------------------------------------------------------------------------------------------------

## 11.4 Snapshot checks and protected symbolic records

**Definition 11.2 (a request snapshot).** A request snapshot binds the semantic context, evidence version, query, operator versions and acceptance predicate. A terminal certificate identifies that snapshot. An "as of" request can return its pinned version; a latest-state request must compare its required version with the registry at commit. A version difference alone is neither an inclusion proof nor a numerical error bound.

**Theorem 11.3 (sound service under an adaptive route policy).** Assume correct primitive checkers and input semantics, complete dependencies, and a nonempty model set for the terminal snapshot. Let any policy adaptively propose a finite sequence of retrievals, transports, repairs and solves. If every admitted claim is checked for that snapshot or transported by a valid implication, and a terminal answer is returned only after its acceptance predicate is certified, the answer satisfies the requested contract on that snapshot.

*Proof.* Apply Theorem 4.3 to the accepted dependency graph. Each retrieval or transport has a checked contract, and each newly computed claim follows from correct primitives. Thus the terminal certificate is valid for every model in the pinned set. Its certified predicate supplies the requested precision or decision property. The policy's choices do not enter this correctness argument. The commit check prevents a pinned result from being silently presented as a result for a different latest snapshot. ∎

The theorem is a safety statement. It does not imply termination, low cost, correct graph extraction or a useful learned scheduler. Repeatedly rejected proposals can consume unbounded time. Acquisition of new evidence creates a new snapshot and requires the appropriate feasibility and transport checks. A protected operation store can coexist with editable model weights because the authority of a record is in its checked scope and proof.

**Proposition 11.4 (soft parameter protection is not immutability).** A finite quadratic penalty on a stored parameter need not leave that parameter unchanged when a new task is optimized. For

$$\mathcal{L}(\theta) = \frac{1}{2}(\theta - 1)^{2} + \frac{\lambda F}{2}(\theta - 0)^{2},\quad\quad 0 \leq \lambda F < \infty,$$

the unique minimizer is $\theta = (1 + \lambda F)^{- 1} > 0$, although the protected old value is zero.

*Proof.* The derivative is $(\theta - 1) + \lambda F\theta$, and the second derivative is $1 + \lambda F > 0$. Solving the first-order condition gives the displayed nonzero minimizer. ∎

Elastic weight consolidation uses importance-weighted quadratic protection (Kirkpatrick et al., 2017); the proposition illustrates the finite-penalty principle, not its empirical failure rate. Exact accepted-record persistence needs a storage rule. A continually learned proposal policy or semantic decoder needs a separate validation and drift contract.

Anthropic's 2026 long-running application account separates generation from evaluation and discusses the cost of orchestration and repeated evaluation (Anthropic, 2026). These are useful harness design precedents. Its evaluators, including subjective judgments, are not substitutes for an exact causal primitive checker. Together with Agent Lightning and SWE-agent, the comparison locates IDC's proposed addition: a mathematical acceptance contract for when a retained result may replace recomputation. The four interval algorithms and the inherited census are implemented; the six-component harness, learned scheduler and end-to-end speed-up remain proposals tested by C1--C5.

# 12 Exact analytical examples and a numerical census

## 12.1 An interval that survives without point identification

Let $X,Y$ be binary with unrestricted confounding, consistency and observational masses $P(X = 1,Y = 1) = 2/5$ and $P(X = 0) = 1/2$. The unobserved treated outcome in the untreated group has probability $\theta \in \lbrack 0,1\rbrack$. Therefore

$$P\left( Y_{1} = 1 \right) = \frac{2}{5} + \frac{1}{2}\theta \in \left\lbrack \frac{2}{5},\frac{9}{10} \right\rbrack.\quad\quad\ \ \ \ (22)$$

The missing outcomes can be assigned zero or one throughout that group without changing the observed outcomes, so both endpoints are attainable in this model class. A new valid report $\theta \in \lbrack 3/5,2/3\rbrack$ gives $\lbrack 7/10,11/15\rbrack$. The old interval remains an outer bound. If the decision threshold is $13/20$, the new lower endpoint already certifies exceeding it. No point estimate or extra decimal places are needed.

The report on $\theta$ is additional information about a potential-outcome subgroup. It is not obtainable merely by rereading the original observational table. An experiment or structural assumption that supplies it must be identified in a real application.

## 12.2 Repair after an enlarged model set

Let $q \in \Delta_{3}$. Originally, $q_{1} \leq 1/2$ and the query is $q_{1}$, with upper bound $1/2$. Replace that constraint by $q_{1} \leq 3/5$ and change the query to $q_{1} + q_{2}/10$. The new set is larger, so refinement reuse of the old upper value is invalid.

Take the multiplier one on the current row $A = (1,0,0)$. Equation (9) gives $3/5 + 1/10 = 7/10$. Reusing the old multiplier has produced a valid, conservative answer. Taking instead $\lambda = 9/10$ gives

$$B_{9/10} = \frac{9}{10} \cdot \frac{3}{5} + \max\{\frac{1}{10},\frac{1}{10},0\} = \frac{16}{25}.\quad\quad\ \ \ \ (23)$$

The feasible vector $q = (3/5,2/5,0)$ attains $16/25$, so Proposition 5.5 certifies sharpness. This example separates three facts: the old numerical upper bound is obsolete, its multiplier can still be useful, and a checked repair can become exact without being justified by set inclusion.

## 12.3 Shared uncertainty can cancel in a decision

Let $q_{1} \in \lbrack 0,1\rbrack$ and utilities be $V_{a} = q_{1} + 1/10$ and $V_{b} = q_{1}$. Their separate intervals overlap, yet

$$V_{a} - V_{b} = \frac{1}{10},\quad\quad R_{K}(a) = 0.\quad\quad\ \ \ \ (24)$$

The shared parameter cancels. Action $a$ is optimal despite complete uncertainty in $q_{1}$. Loading more history or refining either marginal utility cannot improve this particular choice. If the utility meanings or available actions change, the decision certificate needs revalidation.

## 12.4 Context changes can destroy a cache hit

Suppose an old snapshot constrains a probability $p$ to $\lbrack 0,1/5\rbrack$, while a replacement population model constrains the corresponding numerical parameter to $\lbrack 4/5,1\rbrack$. The sets are disjoint. Theorem 5.1 does not apply. A cache indexed only by the expression's textual spelling can return a false bound. Retaining immutable old records remains useful for audit, but the current context must select a newly justified record.

These constructions are worked proofs, not benchmark observations. Their fractions are specified by the examples and derived algebraically. They provide reviewable cases for an eventual implementation without implying any measured speedup.

## 12.5 Algorithms

Each algorithm returns a claim together with the data that let a separate checker accept it.

**Algorithm 1 (certified exact bound).** *Input:* rows $Eq = f$ and $Aq \leq b$ on the response simplex, and a query $c$. *Output:* $\left( U,q_{*},\lambda \right)$.

\(1\) Keep normalization and data equalities as equalities, add slacks only to inequalities, and introduce artificial variables for phase one. (2) Run a two-phase simplex method with Bland's rule in exact rational arithmetic. (3) Read the witness $q_{*}$ from the final basis. (4) Solve $B^{\mathsf{T}}y = c_{B}$ exactly on the optimal basis $B$. Check that every reduced cost is nonpositive and that $y^{\mathsf{T}}b = c^{\mathsf{T}}q_{*}$. (5) Return $U = c^{\mathsf{T}}q_{*}$, the witness and the multipliers without the normalisation row. Inequality multipliers are then nonnegative, and (9) evaluated at $\lambda$ equals $U$.

The returned triple certifies itself through Proposition 5.5. A checker needs only feasibility of $q_{*}$, the attained value and one evaluation of (9). It need not trust the solver.

**Algorithm 2 (service after an evidence refinement).** *Input:* a stored record $\left( U,q_{*},\lambda \right)$ for $K$ and a certified refinement $K\prime \subseteq K$.

\(1\) Return $U$ immediately as an outer bound (Theorem 5.1). (2) If $q_{*}$ satisfies the added rows, $U$ is sharp on $K\prime$ (Corollary 5.3) and no solve is needed. (3) Otherwise test, by phase one only, whether $K\prime \cap \{ c^{\mathsf{T}}q = U\}$ is nonempty. If it is, $U$ remains sharp with a new witness (Theorem 5.2). (4) Otherwise run Algorithm 1 on $K\prime$.

**Algorithm 3 (repair after changed data).** *Input:* stored multipliers $\lambda$ and new rows $(A\prime,b\prime)$ in the same response coordinates, aligned row by row. (1) Evaluate (9) at $\lambda$ to obtain a valid outer bound. (2) If it meets the requested tolerance, return it labelled *outer*. (3) Otherwise, or if sharpness is required, run Algorithm 1.

**Algorithm 4 (decision certificate).** For two actions with linear utilities, run Algorithm 1 on the contrast $c_{1} - c_{0}$ in both directions. Certify the action whose contrast interval excludes zero. Marginal intervals are used only as a fallback outer bound.

**Proposition 12.1 (zero multipliers reproduce the old endpoint).** Let $\lambda$ be the multipliers returned by Algorithm 1 for $K$ and let $K\prime$ add rows. Then (9) evaluated on $K\prime$ with $(\lambda,0)$ equals $U(K)$. Multiplier repair alone cannot tighten a bound after a pure refinement; any improvement needs new multipliers or a surviving witness argument.

*Proof.* The added rows contribute zero to $\lambda^{\mathsf{T}}b$ and to $A^{\mathsf{T}}\lambda$. The remaining expression is (9) on $K$, which equals $U(K)$ by step (5) of Algorithm 1. ∎

**Proposition 12.2 (the joint contrast is never wider).** For linear $c_{1},c_{0}$ on a common set $K$,

$$\left\lbrack \min_{K}\left( c_{1} - c_{0} \right)^{\mathsf{T}}q,\ \max_{K}\left( c_{1} - c_{0} \right)^{\mathsf{T}}q \right\rbrack \subseteq \left\lbrack \min_{K}c_{1}^{\mathsf{T}}q - \max_{K}c_{0}^{\mathsf{T}}q,\ \max_{K}c_{1}^{\mathsf{T}}q - \min_{K}c_{0}^{\mathsf{T}}q \right\rbrack.\quad\quad\ \ \ \ (25)$$

Every sign decision certified by marginal subtraction is therefore certified by Algorithm 4.

*Proof.* For each $q \in K$, $c_{1}^{\mathsf{T}}q - c_{0}^{\mathsf{T}}q$ lies between the right-hand endpoints. Taking the extrema over $q$ preserves the inclusion. ∎

## 12.6 Graph surgery on a finite DAG family

The first census uses all 1,024 DAGs on five binary events that respect one fixed order. Each graph receives three positive models whose conditional probabilities are drawn from tenths or hundredths, the family of Ghosh (2026b). For every event $X$ and value $x_{0}$, the census builds the outgoing baseline replacement of Definition 2.1 and compares it with $do\left( X = x_{0} \right)$. There are 30,720 regimes per grid. The marginal law of all events other than $X$ was identical in every regime, as Lemma 2.2 requires. The full joint law differed in every regime, because the replacement keeps the observational mechanism of $X$.

For every ordered pair in which $X$ is an ancestor of $Y$ (18,939 model-level queries per grid), the census compares $P\left( Y = 1 \mid do(X = 1) \right)$ with $P\left( Y = 1 \mid do(X = 0) \right)$. On the hundredths grid the active value gave the larger response in 9,484 queries, the smaller in 9,360 and an equal response in 95. On the tenths grid the counts were 9,008, 8,775 and 1,156. In 4,717 of the 6,313 graph-level pairs (74.7%; tenths 70.2%), both orders occurred among the three models of the same graph. Proposition 2.3 is therefore the typical case in this family, not a constructed exception: the graph fixes neither direction.

## 12.7 Sequential evidence on an instrumental-variable polytope

The second census uses the binary instrumental-variable model with instrument $Z$, treatment $X$ and outcome $Y$ (Balke & Pearl, 1997). It has 16 response types, four for $X$ as a function of $Z$ and four for $Y$ as a function of $X$. Six observed cells $P(x,y \mid z)$ and normalisation give seven independent equality rows. Each of 1,000 instances draws a true response law with integer weights from 0 to 4, so the polytope is nonempty and contains the truth. Six reports then follow. Each report bounds the total mass of a random group of response types by an interval around its true value, with half-widths $k/40$ for $k \in \{ 0,1,2,3\}$. Every report is a valid refinement in the sense of Definition 3.3. The query is $P\left( Y_{1} = 1 \right)$, linear in the response law.

The old interval enclosed the new sharp interval in all 6,000 refinements (Theorem 5.1). Table 5 shows what happened to each sharp endpoint. A stored witness that survived always certified an unchanged endpoint, as Corollary 5.3 requires. The converse failed often: 5,261 of the 9,421 lost witnesses (55.8%) left the endpoint unchanged, because another optimizer on the same face survived. This is the gap between the sufficient witness shortcut and the exact condition of Theorem 5.2. Proposition 12.1 held in all 6,000 refinements: repairing with zero multipliers on the added rows reproduced the old upper endpoint exactly.

Table 6 compares solver work. Reusing surviving witnesses avoided 2,579 of 12,000 endpoint solves (21.5%) and 20.7% of simplex pivots. The exact face test of Algorithm 2 settled all 5,261 unchanged endpoints with phase one alone and correctly sent the 4,160 moved endpoints to a full solve. Its cold-start phase one, however, cost more pivots than it saved: total pivots rose by 13.5% over the fresh policy. A test that answers more questions exactly is not automatically cheaper. A warm-started dual simplex method is the natural remedy and remains to be measured. Pivot counts are properties of this implementation and Bland's rule, not wall time.

**Table 5 Sharp endpoints after one valid evidence report**

  -----------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Endpoint**   **Refinements**   **Stored witness feasible**   **Witness lost, endpoint unchanged**   **Endpoint moved**   **Witness feasible, endpoint moved**
  -------------- ----------------- ----------------------------- -------------------------------------- -------------------- --------------------------------------
  Upper          6,000             1,258 (21.0%)                 2,676 (44.6%)                          2,066 (34.4%)        0

  Lower          6,000             1,321 (22.0%)                 2,585 (43.1%)                          2,094 (34.9%)        0
  -----------------------------------------------------------------------------------------------------------------------------------------------------------------

**Table 6 Solver work over 6,000 refinements (pivots include the 2,000 initial solves shared by all policies)**

  -------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Policy**                                                  **Full endpoint solves**   **Phase-one face tests**   **Simplex pivots**   **Change in pivots**
  ----------------------------------------------------------- -------------------------- -------------------------- -------------------- ----------------------
  Fresh solve at every step                                   12,000                     0                          342,809              ---

  Reuse surviving witnesses (Algorithm 2, steps 1--2 and 4)   9,421                      0                          271,713              -20.7%

  Add the face test (Algorithm 2, all steps)                  4,160                      9,421                      389,008              +13.5%
  -------------------------------------------------------------------------------------------------------------------------------------------------------------

![Stacked bars for upper and lower endpoints showing witness survival, unchanged endpoints and moved endpoints; grouped bars showing exact and near-exact repair rates.](./media/image2.png){width="6.4in" height="2.519149168853893in"}

**Figure 2 Endpoint reuse after refinement and multiplier repair after changed data**\
Left: fate of the sharp upper and lower endpoints of P(Y_1 = 1) after each of 6,000 valid evidence reports. Right: outcome of evaluating (9) with the stored multipliers after the observed law changes, for 1,000 instances at each change size. Exact census; not a benchmark.

## 12.8 Repair after changed data and query transport

For each instance, the step-0 multipliers of both endpoints were reused after the observed law changed (Algorithm 3). The change moves mass $0.01$ or $0.05$ between two response types of the true law, so the new polytope is not a subset of the old one and Theorem 5.1 does not apply. Table 7 reports the result. Every repaired bound was valid, as Theorem 5.4 guarantees. With the smaller change 95.5% were exact; with the larger change 80.4% were exact and 98.8% were within $0.05$. At the same time the old numerical bounds had become false in 39.5% and 41.7% of instances. This is the separation claimed in Section 12.2, now at scale: an obsolete bound can carry multipliers that still certify the new one.

For query transport, each instance perturbed every coefficient of the query by $- 1/20$, $0$ or $1/20$. The transported interval (12) contained the fresh sharp interval in all 1,000 cases. It was never exact, and on average it was 1.149 times as wide as the fresh interval. Transport is a cheap outer certificate, not a substitute for a solve when precision matters.

**Table 7 Multiplier repair of both endpoints after changed data**

  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Change in the observed law**      **Laws**   **Repaired bound valid**   **Repaired bound exact**   **Excess at most 0.01**   **Excess at most 0.05**   **Old numerical bound now false**
  ----------------------------------- ---------- -------------------------- -------------------------- ------------------------- ------------------------- -----------------------------------
  Mass 0.01 moved between two types   1,000      100.0%                     95.5%                      99.8%                     100.0%                    39.5%

  Mass 0.05 moved between two types   1,000      100.0%                     80.4%                      82.7%                     98.8%                     41.7%
  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 12.9 Decisions certified by the joint contrast

At each of the 7,000 evidence states, Algorithm 4 compared treating ($X = 1$) with not treating, using the contrast $P\left( Y_{1} = 1 \right) - P\left( Y_{0} = 1 \right)$. The joint contrast interval excluded zero in 524 states (7.5%); marginal subtraction did so in 222 (3.2%). In 302 states only the joint certificate decided, and in no state did marginal subtraction decide alone, as (25) requires. By the last report, 195 instances were decided jointly and 98 by marginal subtraction; the joint certificate decided strictly earlier in 136. Shared response types cancel in the contrast, as in Section 12.3.

## 12.10 Validation

Version 2's independent Python program checks every supplied census line. For each of the 7,000 evidence states, it re-certifies the C# upper and lower endpoints exactly from exported feasible attaining witnesses and its own evaluation of (9), with nonnegative inequality multipliers. Other bounds were compared with SciPy's HiGHS solver within $1.4 \times 10^{- 15}$. It independently recomputed face feasibility and the surgery census. The supplied validation reports 12 passing checks. Version 3 preserves those outputs without a fresh full validator or compiler run; Section 12.11 identifies the calculations newly performed here. Pivot counts remain C# implementation measurements without independent validation.

These are finite calculations on declared families. They show what the theorems and algorithms do there; the thresholds of hypotheses C1 to C3 remain prospective tests on frozen workloads.

## 12.11 New exact examples and provenance of this revision

Version 3 adds small exact-arithmetic examples for premise deletion, repaired coefficient drift, certificate intersection, summary-dependent contrasts and finite quadratic protection. A separate checker also rebuilds the distinction between witness survival and endpoint persistence from the supplied census records. It does not regenerate the original C# simulations or the inherited pivot counts.

Dropping $q_{1} \leq 1/5$ raises the certified upper bound from $1/5$ to one, attaining Theorem 5.6's surcharge $4/5$. Reconstructing the same right-hand side as $19/100$ and adding its certified radius $1/100$ recovers the valid bound $1/5$ by Theorem 6.8. With $\lambda F = 9$, Proposition 11.4's protected parameter moves from zero to $1/10$. These are specified algebraic examples, not learned-model experiments. Their general conclusions come from the proofs.

The supplied Version 2 manuscript, C# kernel, exported records and validation results remain unchanged in the source bundle. New result files are produced in two clean Python processes and compared exactly. The current Word builder uses the included Version 2 file directly; it does not depend on an unavailable earlier manuscript. No new agent benchmark, latency measurement, training run or biological experiment is reported.

# 13 Falsifiable computational hypotheses

## 13.1 A matched comparison

The implementation study should freeze a response-model family, causal query set, evidence-update distribution, precision contract and utility scale before evaluation. It should include exact repeats, certified refinements, changed query coefficients, changed populations and altered intervention meanings. Compare full recomputation, exact memoization without interval reuse, and the full IDC harness. All methods must return claims meeting the same mathematical contract; a wider answer is acceptable only when that contract permits it.

Separate correctness tests from performance hypotheses. A false accepted certificate is an implementation failure under the checker assumptions, rather than an allowed accuracy tradeoff. Report exact-value error, interval containment, sharpness claims, incorrect context matches and inconsistency handling. Performance reports include total elapsed time, solver time, certificate-checking time, memory traffic, stored bytes and tool calls. Compilation cost and the cost of acquiring new evidence are included or explicitly amortized over a declared horizon.

**Hypothesis C1 (refinement reuse saves solver work).** On a frozen workload dominated by added valid evidence rows, the full harness will use at least 20 percent less total solver time than exact memoization alone, while meeting identical output contracts. A prespecified confidence interval for the saving entirely below 20 percent refutes this quantitative prediction; an interval crossing the threshold is inconclusive. Wall time is reported separately because checking overhead may erase solver savings.

*Census note.* On the workload of Section 12.7, witness reuse removed 21.5% of endpoint solves and 20.7% of pivots. The exact face test removed more full solves but raised pivots by 13.5%. Solver calls are therefore not a proxy for solver time, and C1 must be scored in measured time.

**Hypothesis C2 (repair is useful beyond identical contexts).** For a frozen family of numerical row and query changes with fixed response semantics, checked multiplier repair will meet the request tolerance without a new solver call on at least one quarter of requests. A confidence interval entirely below one quarter refutes the prediction. The family and tolerance must be fixed before examining repair outcomes.

*Census note.* In Section 12.8, stored multipliers met a tolerance of 0.01 without a solve in 99.8% and 82.7% of the two change families. This is consistent with C2 for those families. It does not test C2, whose request family must be frozen in advance.

**Hypothesis C3 (decision stopping exceeds width stopping).** At matched worst-case regret tolerance, direct common-model utility comparisons will require fewer bound refinements than a policy that insists on the same small marginal width for every action. A confidence interval showing no reduction refutes the directional prediction. Workloads should include shared uncertainty and decision reversals, so the test does not reduce to constant utility offsets alone.

*Census note.* In Section 12.9 the joint contrast decided 195 instances by the last report against 98 for marginal subtraction, and never decided later. C3 concerns refinement counts at matched regret tolerance, which this census does not vary.

**Hypothesis C4 (retained dependencies matter).** Removing shared parameter identities while retaining marginal intervals will increase either returned widths or the number of additional computations on dependency-sensitive tasks. If outputs and costs remain equivalent on a held-out task family designed to distinguish the continuations in Proposition 9.3, the claimed implementation benefit is unsupported. Any unsafe narrowing is scored as an error, not a speed gain.

**Hypothesis C5 (semantic scope prevents stale reuse).** A cache with the full context contract will reject changed-regime and changed-population matches that a numerical or text-only key accepts. The test must mutate meaning while preserving array shapes and sometimes numerical outputs. Any accepted stale claim refutes the relevant implementation's context checking. A null difference between policies on a sufficiently discriminating frozen mutation set would refute the predicted practical advantage.

These are prospective predictions. The percentages in C1 and C2 are design thresholds, not measured effects or literature estimates. No result in this paper assumes that they will hold.

## 13.2 A construction engineering instance

For an engineering application, the registry can distinguish design revision, loading regime, material population, inspection time and intervention. A cached causal estimate about a maintenance action may survive additional inspection evidence within one model. It cannot automatically move between a changed plant, a different action definition or a revised mechanism of failure. Engineering simulation, causal effect estimation and code compliance are separate claims with their own checkers.

The most useful initial demonstration is deliberately small: one response block, two actions, sequential bounded observations and a fixed decision tolerance. It can test exact cache hits, surviving witnesses, multiplier repair and shared-parameter decisions before any learned scheduler is trained. This order makes the correctness boundary concrete and leaves model extraction and domain validation as explicit further work.

# 14 Discussion and conclusion

The proposed speed mechanism has a precise boundary. Immutable storage makes accepted operations persistent and shareable. IDC makes a coarse result usable when it has a valid scope and is already sufficient for a requested continuation. Neither graph surgery nor the existence of an interval guarantees faster inference. A difficult identification derivation, large response space, expensive verifier or low reuse rate can dominate the cost.

The most reusable object is not always an answer. A structural identity can survive numerical updates; an outer bound can survive a refinement; an old optimizer can certify unchanged sharpness; and multipliers can be useful after their old numerical bound becomes false. Keeping these roles separate permits broader safe reuse than a cache of final answers while preventing numerical coincidences from becoming causal rules.

The horizontal topology contributes declared overlaps and parameter identity. Its restrictions do not replace global causal feasibility, and its local neighborhoods do not by themselves determine computational locality. The operation graph carries the latter dependence. The evidence order supplies the subset relation needed for monotone reuse. A physical clock and a learned layer order retain their separate roles.

Neuroscience motivates selective access, contextual recovery, protected plasticity and circuit reorganization, while reconsolidation and representational drift limit literal immutability. Theorem 5.1 preserves outer bounds at every precision; it does not establish a biological advantage for coarse memories. Losing one witness differs from losing endpoint sharpness. Section 10.5 therefore treats preferential retention of constraints, coarse claims, contextual supersession and selective dependency loss as four prospective predictions. A sufficient relational frontier need not lose joint structure.

The next implementation should expose the six-component certificate interface and snapshot commit check before training a route policy. Its target is a measured reduction in redundant work under an unchanged correctness contract. The inherited census supplies algorithmic cases, including useful witness reuse, effective multiplier repair and a more complete test that costs extra pivots. The new mathematics bounds weakening and reconstruction error; it does not establish a neural storage mechanism or end-to-end acceleration. Those remain tests for the proposed harness and H-series biological mapping.

# Appendix A Assumptions and proof obligations

**Table 8 Assumptions attached to the principal results**

  ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
  **Result**             **Required assumptions**                                                           **What it does not establish**
  ---------------------- ---------------------------------------------------------------------------------- -----------------------------------------------------------
  Theorem 2.5            Defined regimes and ordered potential outcomes                                     Ordering from edge deletion alone

  Proposition 3.2        Pointwise equality on one common model set                                         Identification by numerical coincidence

  Theorem 4.3            Correct primitives and complete semantic contracts                                 Correct extraction of the intended world model

  Theorems 5.1 and 5.2   Nonempty subset relation and endpoint attainment                                   Reuse after an arbitrary version change

  Theorem 5.4            A normalized response polytope and nonnegative multipliers                         A linear model for independent latent blocks

  Theorem 6.4            Same coordinates and certified directed distance                                   Transport across changed event meanings

  Theorem 7.4            Fixed actions and utilities with a declared computation cost                       The future value of learning for other tasks

  Theorems 8.3 and 9.2   Complete dependencies and pure specified operations                                Spatial locality or arbitrary neural compression

  Theorem 5.6            Aligned retained rows, nonnegative multipliers and a nonempty retained model set   Free deletion of premises without weakening the claim

  Theorem 6.8            Certified coefficient radii, fixed meanings, units and response coordinates        Error radii inferred from neural similarity alone

  Theorem 11.3           Correct checkers, complete dependencies and a checked terminal snapshot            Termination, low cost or a learned harness implementation
  ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

Theorem 5.2 is used with compact new sets throughout the algorithm. In a noncompact new set, an unchanged infimum or supremum might be approached without a surviving attaining model; the witness equivalence would then require reformulation. No result relies on such unattained sharpness.

An implementation must check dimension and coordinate alignment, nonnegativity and normalization, the sign of every inequality multiplier, denominator support, graph separation premises and exact or validated arithmetic. These are the mathematical obligations of the declared operators. They do not include proving that an observed association is causal or that an informal intervention description has been correctly encoded.

For probabilistic reports, source-specific coverage and dependence across reports enter the evidence contract. A repeated occurrence of one observation remains one shared constraint. A solver's inability to find a feasible point does not alone prove inconsistency unless its infeasibility certificate is checked. Likewise, a wide repaired bound is a legitimate coarse result and does not refute the target query.

The manuscript's examples require only the displayed finite arithmetic. The formal statements establish conditional correctness and potential shortcuts. Sections 12.5 to 12.10 report exact finite computations and pivot counts. No wall-time improvement, trained latent representation, neural localization or biological equivalence has been demonstrated here.

# Appendix B Reproduction

The current source bundle includes `base_v2.docx`, `additions_v3.md`, `build_v3.py`, `check_v3.py` and the new result file `checks_v3.json`, with the supplied Version 2 sources in `inherited_v2/`. From the bundle root, run `python check_v3.py` for the new exact examples and exported endpoint tallies, and `python build_v3.py` for the updated Word paper. The builder requires python-docx, lxml and Pandoc; the checker uses the standard library. A synchronized Markdown copy and extracted figures accompany the Word file. The current builder needs no earlier manuscript outside the bundle.

The inherited .NET 8 kernel and original outputs remain available. Inside `inherited_v2/`, its documented census command is `dotnet run -c Release --project kernel -- out --idc > cs_idc.txt`, followed by `python validate_idc.py cs_idc.txt out/iv_records.json validation_idc.json`. These describe the historical reproduction path, not a run newly claimed by Version 3. The inherited builder refers to earlier manuscript inputs and is retained for provenance; `build_v3.py` is the supported build for this revision. Public C# values are immutable records, while simplex tableaux are local scratch data.

Version 3's new exact result JSON is generated in two clean processes and compared byte for byte. The inherited source and result files are preserved unchanged. Rendering remains necessary after rebuilding because fonts and Office versions can alter pagination. No agent benchmark, latency experiment, training run or biological experiment is added.

# References

Anthropic. (2025a, September 29). *Effective context engineering for AI agents*. https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents

Anthropic. (2025b, November 26). *Effective harnesses for long-running agents*. https://www.anthropic.com/engineering/effective-harnesses-for-long-running-agents

Anthropic. (2026, March 24). *Harness design for long-running application development*. https://www.anthropic.com/engineering/harness-design-long-running-apps

Balke, A., & Pearl, J. (1997). Bounds on treatment effects from studies with imperfect compliance. *Journal of the American Statistical Association, 92*(439), 1171--1176. https://doi.org/10.1080/01621459.1997.10474074

Bouton, M. E. (2004). Context and behavioral processes in extinction. *Learning & Memory, 11*(5), 485--494. https://doi.org/10.1101/lm.78804

Cousot, P., & Cousot, R. (1977). Abstract interpretation: A unified lattice model for static analysis of programs by construction or approximation of fixpoints. In *Proceedings of the 4th ACM SIGACT SIGPLAN Symposium on Principles of Programming Languages* (pp. 238--252). https://doi.org/10.1145/512950.512973

Denis, D., Chen, Z., Kaur, M., Clayden, B., Schreiner, T., & Cairney, S. A. (2026). Theta oscillations tag episodic memories for sleep-dependent consolidation. *PLOS Biology, 24*(8), e3003938. https://doi.org/10.1371/journal.pbio.3003938

Driscoll, L. N., Pettit, N. L., Minderer, M., Chettih, S. N., & Harvey, C. D. (2017). Dynamic reorganization of neuronal activity patterns in parietal cortex. *Cell, 170*(5), 986--999.e16. https://doi.org/10.1016/j.cell.2017.07.021

Duarte, G., Finkelstein, N., Knox, D., Mummolo, J., & Shpitser, I. (2024). An automated approach to causal inference in discrete settings. *Journal of the American Statistical Association, 119*(547), 1778--1793. https://doi.org/10.1080/01621459.2023.2216909

Ghosh, D. (2026a). *Autoregressive Do Calculus with Sequential Evidence*. https://doi.org/10.13140/RG.2.2.24386.75209

Ghosh, D. (2026b). *Operation Certificates for Latent Causal Reasoning* (Version 2). Author manuscript.

Ghosh, D. (2026c). *Dependency Preserving Temporal Causal Computation: Horizontal sheaves, interval ranges and temporal smoothing*. https://doi.org/10.13140/RG.2.2.33732.18568

Ghosh, D. (2026d). *Certified Cache and Temperature Reuse for Selective Adaptive Optimisation*. https://doi.org/10.13140/RG.2.2.15650.80326

Gogolla, N., Caroni, P., Lüthi, A., & Herry, C. (2009). Perineuronal nets protect fear memories from erasure. *Science, 325*(5945), 1258--1261. https://doi.org/10.1126/science.1174146

He, Z., Zhang, S., Zhou, Z., Yang, Y., Kang, Y., Zhang, Y., Qiu, L. K., Tsui, T. Y., Xu, J., & Luo, C. (2026). *Agent Lightning v1.0: Towards harnessed agentic RL*. arXiv. https://arxiv.org/abs/2608.17528

Howard, S. R., Ramdas, A., McAuliffe, J., & Sekhon, J. (2021). Time-uniform, nonparametric, nonasymptotic confidence sequences. *The Annals of Statistics, 49*(2), 1055--1080. https://doi.org/10.1214/20-AOS1991

Jensen, K. T., Hennequin, G., & Mattar, M. G. (2024). A recurrent network model of planning explains hippocampal replay and human behavior. *Nature Neuroscience, 27*, 1340--1348. https://doi.org/10.1038/s41593-024-01675-7

Kirkpatrick, J., Pascanu, R., Rabinowitz, N., Veness, J., Desjardins, G., Rusu, A. A., Milan, K., Quan, J., Ramalho, T., Grabska-Barwinska, A., Hassabis, D., Clopath, C., Kumaran, D., & Hadsell, R. (2017). Overcoming catastrophic forgetting in neural networks. *Proceedings of the National Academy of Sciences, 114*(13), 3521--3526. https://doi.org/10.1073/pnas.1611835114

Kitamura, T., Ogawa, S. K., Roy, D. S., Okuyama, T., Morrissey, M. D., Smith, L. M., Redondo, R. L., & Tonegawa, S. (2017). Engrams and circuits crucial for systems consolidation of a memory. *Science, 356*(6333), 73--78. https://doi.org/10.1126/science.aam6808

Kwon, W., Li, Z., Zhuang, S., Sheng, Y., Zheng, L., Yu, C. H., Gonzalez, J. E., Zhang, H., & Stoica, I. (2023). Efficient memory management for large language model serving with PagedAttention. In *Proceedings of the 29th Symposium on Operating Systems Principles* (pp. 611--626). https://doi.org/10.1145/3600006.3613165

Luo, X., Zhang, Y., He, Z., Wang, Z., Zhao, S., Li, D., Qiu, L. K., & Yang, Y. (2025). *Agent Lightning: Train ANY AI agents with reinforcement learning*. arXiv. https://arxiv.org/abs/2508.03680

Mattar, M. G., & Daw, N. D. (2018). Prioritized memory access explains planning and hippocampal replay. *Nature Neuroscience, 21*(11), 1609--1617. https://doi.org/10.1038/s41593-018-0232-z

Mokhov, A., Mitchell, N., & Peyton Jones, S. (2018). Build systems à la carte. *Proceedings of the ACM on Programming Languages, 2*(ICFP), Article 79. https://doi.org/10.1145/3236774

Momennejad, I., Russek, E. M., Cheong, J. H., Botvinick, M. M., Daw, N. D., & Gershman, S. J. (2017). The successor representation in human reinforcement learning. *Nature Human Behaviour, 1*, 680--692. https://doi.org/10.1038/s41562-017-0180-8

Nader, K., Schafe, G. E., & LeDoux, J. E. (2000). Fear memories require protein synthesis in the amygdala for reconsolidation after retrieval. *Nature, 406*, 722--726. https://doi.org/10.1038/35021052

Pearl, J. (2012). Do-calculus revisited. In *Proceedings of the 28th Conference on Uncertainty in Artificial Intelligence* (pp. 4--11). https://ftp.cs.ucla.edu/pub/stat_ser/r402.pdf

Shpitser, I., & Pearl, J. (2008). Complete identification methods for the causal hierarchy. *Journal of Machine Learning Research, 9*, 1941--1979. https://jmlr.org/papers/v9/shpitser08a.html

Shpitser, I., & Tchetgen Tchetgen, E. J. (2016). Causal inference with a graphical hierarchy of interventions. *The Annals of Statistics, 44*(6), 2433--2466. https://doi.org/10.1214/15-AOS1411

Tse, D., Langston, R. F., Kakeyama, M., Bethus, I., Spooner, P. A., Wood, E. R., Witter, M. P., & Morris, R. G. M. (2007). Schemas and memory consolidation. *Science, 316*(5821), 76--82. https://doi.org/10.1126/science.1135935

Tsien, R. Y. (2013). Very long-term memories may be stored in the pattern of holes in the perineuronal net. *Proceedings of the National Academy of Sciences, 110*(30), 12456--12461. https://doi.org/10.1073/pnas.1310158110

Winocur, G., & Moscovitch, M. (2011). Memory transformation and systems consolidation. *Journal of the International Neuropsychological Society, 17*(5), 766--780. https://doi.org/10.1017/S1355617711000683

Yang, G., Pan, F., & Gan, W.-B. (2009). Stably maintained dendritic spines are associated with lifelong memories. *Nature, 462*(7275), 920--924. https://doi.org/10.1038/nature08577

Yang, J., Jimenez, C. E., Wettig, A., Lieret, K., Yao, S., Narasimhan, K., & Press, O. (2024). SWE-agent: Agent-computer interfaces enable automated software engineering. *Advances in Neural Information Processing Systems, 37*. https://arxiv.org/abs/2405.15793
