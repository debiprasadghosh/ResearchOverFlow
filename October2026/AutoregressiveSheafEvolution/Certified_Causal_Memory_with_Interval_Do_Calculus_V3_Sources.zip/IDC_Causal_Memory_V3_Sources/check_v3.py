"""Exact examples for IDC V3; standard library only, no full census rerun.

The inherited endpoint tallies are reconstructed from the supplied exported
records. No model is fitted, no C# kernel run and no pivot count regenerated.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product,combinations
import json

ROOT=Path(__file__).resolve().parent
checks=[]
def check(name,ok):
    checks.append({"name":name,"passed":bool(ok)})
    if not ok:raise AssertionError(name)
def dot(a,b):return sum((x*y for x,y in zip(a,b)),F(0))
def bound(c,rows,rhs,lam):
    return dot(lam,rhs)+max(c[i]-sum(lam[j]*rows[j][i] for j in range(len(rows))) for i in range(len(c)))
def interval2(rows,rhs):
    lo,hi=F(0),F(1)
    for (a0,a1),b in zip(rows,rhs):
        slope=a0-a1; intercept=a1
        if slope>0:hi=min(hi,(b-intercept)/slope)
        elif slope<0:lo=max(lo,(b-intercept)/slope)
        elif intercept>b:raise ValueError("empty")
    if lo>hi:raise ValueError("empty")
    return lo,hi
def upper2(c,rows,rhs):
    lo,hi=interval2(rows,rhs)
    return max(dot(c,[x,1-x]) for x in (lo,hi))

c=[F(1),F(0)];A=[[F(1),F(0)]];b=[F(1,5)];lam=[F(1)]
old=bound(c,A,b,lam);new=bound(c,[],[],[])
surcharge=max(lam[0]*(a-b[0]) for a in A[0])
check("old endpoint 1/5",old==F(1,5))
check("dropping premise gives one",new==1)
check("premise-deletion surcharge is tight",surcharge==F(4,5) and old+surcharge==new)
deletion_cases=0
for lo,hi in product([F(0),F(1,5),F(1,2),F(1)],repeat=2):
    if lo>hi:continue
    rows=[[F(1),F(0)],[F(-1),F(0)]];rhs=[hi,-lo]
    for lam in product([F(0),F(1,2),F(1),F(3)],repeat=2):
        before=bound(c,rows,rhs,lam)
        for mask in range(4):
            J=[j for j in range(2) if mask>>j&1];R=[j for j in range(2) if j not in J]
            rr=[rows[j] for j in R];bb=[rhs[j] for j in R];ll=[lam[j] for j in R]
            after=bound(c,rr,bb,ll)
            gamma=max(sum((lam[j]*(rows[j][i]-rhs[j]) for j in J),F(0)) for i in range(2))
            if not (upper2(c,rr,bb)<=after<=before+max(F(0),gamma)):
                raise AssertionError("deletion grid")
            deletion_cases+=1
check("deletion bound on rational grid",deletion_cases==640)

# A falsely reconstructed coefficient is repaired by its certified radius.
reconstructed=bound(c,A,[F(19,100)],[F(1)])
check("uncorrected reconstructed bound is 19/100",reconstructed==F(19,100))
check("coefficient radius repairs the bound",reconstructed+F(1,100)==F(1,5))
for sign in [F(-1),F(1)]:
    equality_multiplier=sign
    free=equality_multiplier*F(1,2)+max(sign-equality_multiplier,F(0))
    expanded=bound([sign,F(0)],[[F(1),F(0)],[F(-1),F(0)]],[F(1,2),F(-1,2)],
                   [max(equality_multiplier,F(0)),max(-equality_multiplier,F(0))])
    check(f"free equality multiplier {sign} equals canonical expansion",free==expanded==sign*F(1,2))
drift_cases=0
for rhs0 in [F(0),F(1,5),F(1,2),F(1)]:
    for da0,da1,db,dc0,dc1 in product([F(-1,100),F(0),F(1,100)],repeat=5):
        At=[[F(1)+da0,da1]];bt=[rhs0+db];ct=[F(1)+dc0,dc1]
        for l in [F(0),F(1,2),F(1),F(3)]:
            raw=bound(ct,At,bt,[l])
            allowance=max(abs(dc0),abs(dc1))+l*(max(abs(da0),abs(da1))+abs(db))
            if upper2(c,A,[rhs0])>raw+allowance:raise AssertionError("coefficient drift grid")
            drift_cases+=1
check("drift repair on 3888 rational cases",drift_cases==3888)

portfolio=[(F(0),F(1)),(F(1,5),F(9,10)),(F(3,10),F(4,5))]
intersection=(max(x[0] for x in portfolio),min(x[1] for x in portfolio))
check("certificate intersection",intersection==(F(3,10),F(4,5)))
check("intersection contains current range",intersection[0]<=F(2,5)<=F(3,5)<=intersection[1])
check("blind widening does not repair new scope",not(F(9,10)<=F(0)<=F(1)))
diag=[(F(0),F(0)),(F(1),F(1))]
square=list(product([F(0),F(1)],repeat=2))
marg=lambda pts,i:(min(p[i] for p in pts),max(p[i] for p in pts))
contrast=lambda pts:(min(a-b for a,b in pts),max(a-b for a,b in pts))
check("marginal summaries agree",all(marg(diag,i)==marg(square,i) for i in range(2)))
check("relational summary retains exact contrast",contrast(diag)==(0,0))
check("merged summary needs wider contrast",contrast(diag+square)==(-1,1))
for importance in [F(0),F(1),F(9),F(99)]:
    theta=1/(1+importance)
    check(f"finite penalty {importance} has a nonzero optimum",theta>0 and (theta-1)+importance*theta==0)
check("reported EWC example",1/(1+F(9))==F(1,10))

# Reconstruct counts using only the newly added constraint per step. Old rows
# remain unchanged; original feasibility and exact certificates are inherited.
records=json.loads((ROOT/"inherited_v2/out/iv_records.json").read_text())
totals={"refinements":0,"upper_witness_survives":0,"lower_witness_survives":0,
        "upper_endpoint_unchanged":0,"lower_endpoint_unchanged":0,
        "upper_lost_witness_same_endpoint":0,"lower_lost_witness_same_endpoint":0}
for rec in records:
    for prev,cur in zip(rec["steps"],rec["steps"][1:]):
        totals["refinements"]+=1
        mask=cur["mask"];lo,hi=F(cur["lo"]),F(cur["hi"])
        for side,key,wkey in [("upper","U1","xU"),("lower","L1","xL")]:
            mass=sum((F(v) for i,v in enumerate(prev[wkey]) if mask>>i&1),F(0))
            survived=lo<=mass<=hi
            unchanged=F(prev[key])==F(cur[key])
            totals[side+"_witness_survives"]+=survived
            totals[side+"_endpoint_unchanged"]+=unchanged
            totals[side+"_lost_witness_same_endpoint"]+=(not survived) and unchanged
            if survived and not unchanged:raise AssertionError("surviving witness changed endpoint")
expected={"refinements":6000,"upper_witness_survives":1258,"lower_witness_survives":1321,
          "upper_endpoint_unchanged":3934,"lower_endpoint_unchanged":3906,
          "upper_lost_witness_same_endpoint":2676,"lower_lost_witness_same_endpoint":2585}
check("endpoint tallies reconstructed from exports",totals==expected)
check("upper persistence rounds to 65.6%",f'{100*totals["upper_endpoint_unchanged"]/6000:.1f}'=="65.6")
check("lower persistence is 65.1%",F(100*totals["lower_endpoint_unchanged"],6000)==F(651,10))
check("witness reuse removes 2579 solves",totals["upper_witness_survives"]+totals["lower_witness_survives"]==2579)
result={"scope":"New exact algebraic examples and derived inherited tallies; no full census, compiler, agent, training or biological run.",
        "all_passed":all(c["passed"] for c in checks),"checks":checks,
        "results":{"deletion_old_upper":"1/5","deletion_new_upper":"1","deletion_surcharge":"4/5",
                   "drift_uncorrected":"19/100","drift_allowance":"1/100","drift_corrected":"1/5",
                   "deletion_grid_cases":deletion_cases,"drift_grid_cases":drift_cases,
                   "ewc_new_value":"1/10","inherited_endpoint_tallies":totals}}
(ROOT/"checks_v3.json").write_text(json.dumps(result,indent=2)+"\n")
print(f"{len(checks)} checks passed; {deletion_cases} premise-deletion and {drift_cases} drift cases; inherited endpoint tallies reconstructed.")
