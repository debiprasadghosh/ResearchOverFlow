# Certified Causal Memory with Interval Do Calculus

Version 3 · 1 November 2026 · Debi Prasad Ghosh

Subtitle: Persistent claims, revisable memory and verified reuse

## What changed

- New Section 10.5 develops six constrained neuroscience analogies and four
  prospective predictions H1–H4. Earlier N1–N3 and computational C1–C5 remain.
- Theorem 5.6 gives a certified allowance for dropping constraint premises;
  Corollary 5.7 combines independently valid interval certificates.
- Theorem 6.8 controls certificate reconstruction under declared coefficient
  errors. No semantic meaning is inferred from numerical proximity.
- Proposition 9.4 states the least query enclosure that a summary must support.
- Theorem 11.3 states the safety contract of adaptive request routing with a
  pinned snapshot and commit check; Proposition 11.4 shows why a finite soft
  weight penalty is not immutable storage.
- Section 11 now specifies six component interfaces, six request steps, current
  harness precedents, scoped statuses and the implemented/proposed boundary.
- Algorithm 1 now correctly distinguishes equality rows, inequality slacks and
  phase-one artificial variables. The unchanged kernel's free equality
  multipliers are related to the paper's canonical nonnegative convention.
- Adding the component table renumbers original Tables 3–7 as Tables 4–8.

## Two distinctions that matter

1. Theorem 5.1 preserves every valid outer interval on a certified nonempty
   refinement, independent of width. It does not prove coarse biological
   memories are more durable. That remains H2, with controls against tolerance
   and logical-validity confounds.
2. A selected upper witness survives 21.0% of the inherited refinements, while
   the upper endpoint stays unchanged in 65.6%. Other optimizers can survive.
   Neither figure is a biological retention rate.

The original C# census and its validation logs are inherited, not rerun here.
All 24 new exact checks pass, including 640 premise-deletion cases and 3,888
coefficient-drift cases on rational grids. The new checker reconstructs the
endpoint tallies from the supplied exports and checks the specified algebraic
examples. Its JSON was generated twice in clean processes and compared exactly.
No teacher, student, agent benchmark, latency study or biological experiment is run.

## Files

- `Certified_Causal_Memory_with_Interval_Do_Calculus_V3.docx`: current Word paper.
- `paper_v3.md`, `media/`: synchronized Markdown and its two figures.
- `base_v2.docx`: byte-identical authoritative supplied Version 2 manuscript.
- `additions_v3.md`, `build_v3.py`: new text and self-contained Word edit builder.
- `check_v3.py`, `checks_v3.json`: new exact examples and reconstructed tallies.
- `audit_v3.py`, `qa_v3.json`: structural and provenance checks; not full XSD validation.
- `source_notes_v3.md`: added literature and the scope of each inference.
- `inherited_v2/`: unchanged supplied C# kernel, records, sources and validation.

## Rebuild the current revision

The checker needs Python 3's standard library. The Word builder needs python-docx,
lxml and Pandoc. From this directory:

```bash
python check_v3.py
python build_v3.py
pandoc Certified_Causal_Memory_with_Interval_Do_Calculus_V3.docx --standalone --wrap=none --extract-media=. -o paper_v3.md
python audit_v3.py
```

Render and inspect the rebuilt Word file before relying on its pagination.
Equations remain native editable Word equations. The build is content
reproducible; file timestamps and ZIP metadata need not reproduce byte for byte.

The historical .NET 8 reproduction commands are documented in
`inherited_v2/README_V2.md`. The old builder references earlier manuscript inputs
outside its own bundle. Use `build_v3.py`, which reads the included `base_v2.docx`.
New proofs do not imply that the full harness or learned scheduler is implemented.

## Interpretation

Immutability is an engineering assertion-history rule. It is not a claim that
neurons keep a complete audit log. Perineuronal-net evidence from amygdala is
identified as such; Tsien's net-hole account is identified as a hypothesis.
Extinction recovery does not establish universal non-erasure, and absent
recovery does not alone establish overwriting. Relations can survive
consolidation; dependency loss is conditional on the retained summary.
