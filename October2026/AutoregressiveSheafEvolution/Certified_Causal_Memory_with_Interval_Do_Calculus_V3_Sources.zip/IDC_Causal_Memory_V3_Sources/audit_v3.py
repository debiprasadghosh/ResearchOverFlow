"""Structural QA and provenance for IDC V3. Not full OOXML XSD validation."""
from pathlib import Path,PurePosixPath
from zipfile import ZipFile
import ast,hashlib,json,posixpath,re
from lxml import etree
from docx import Document
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parent
DOC=ROOT/"Certified_Causal_Memory_with_Interval_Do_Calculus_V3.docx"
NS={"w":"http://schemas.openxmlformats.org/wordprocessingml/2006/main","m":"http://schemas.openxmlformats.org/officeDocument/2006/math"}
checks=[]
def check(name,ok):
    checks.append({"name":name,"passed":bool(ok)})
    if not ok:raise AssertionError(name)
d=Document(DOC);base=Document(ROOT/"base_v2.docx")
with ZipFile(DOC) as z,ZipFile(ROOT/"base_v2.docx") as old:
    check("Word ZIP CRC",z.testzip() is None)
    names=set(z.namelist());roots={n:etree.fromstring(z.read(n)) for n in names if n.endswith((".xml",".rels"))}
    check("all XML parts parse",len(roots)>10)
    missing=[]
    for n,r in roots.items():
        if not n.endswith(".rels"):continue
        owner=PurePosixPath(n).parent.parent if n!="_rels/.rels" else PurePosixPath("")
        for rel in r:
            if rel.get("TargetMode")=="External":continue
            target=rel.get("Target","")
            resolved=posixpath.normpath(str(owner/target)) if not target.startswith("/") else target.lstrip("/")
            if resolved not in names:missing.append([n,target])
    check("all internal relationships resolve",not missing)
    r=roots["word/document.xml"]
    oldr=etree.fromstring(old.read("word/document.xml"))
    nmath=len(r.xpath(".//m:oMath",namespaces=NS));ndisplay=len(r.xpath(".//m:oMathPara",namespaces=NS))
    check("new math remains native",nmath>len(oldr.xpath(".//m:oMath",namespaces=NS)) and ndisplay>len(oldr.xpath(".//m:oMathPara",namespaces=NS)))
    for name in old.namelist():
        if name.startswith("word/media/"):check("unchanged figure "+name,z.read(name)==old.read(name))
    check("two figure slots retained",len(d.inline_shapes)==2)
    check("paragraph properties precede content",all(not p.findall(qn("w:pPr")) or p[0].tag==qn("w:pPr") for p in r.iter(qn("w:p"))))
    cm=roots["word/comments.xml"];ids={p.get(qn("w:id")) for p in cm}
    references=[]
    for tag in ("commentRangeStart","commentRangeEnd","commentReference"):
        references.append({p.get(qn("w:id")) for p in r.iter(qn("w:"+tag))})
    check("four review comments have anchors",len(ids)==4 and all(v==ids for v in references))
    text=" ".join(r.xpath(".//w:t/text()",namespaces=NS))
    check("no TeX fallback in visible text",re.search(r"\\(?:rm|mathrm|lambda|Gamma|mathsf|leq|tfrac)\b",text) is None)
    check("algorithm slack description corrected","Keep normalization and data equalities as equalities" in text and "Add slack variables to the inequality rows and the normalisation row" not in text)
check("author and affiliation preserved",d.paragraphs[2].text==base.paragraphs[2].text and d.paragraphs[4].text==base.paragraphs[4].text)
check("title updated",d.paragraphs[0].text=="Certified Causal Memory with Interval Do Calculus")
check("eight tables",len(d.tables)==8)
def celltexts(t):return [["".join(c._tc.xpath(".//w:t/text() | .//m:t/text()")) for c in row.cells] for row in t.rows]
for i,oldtable in enumerate(base.tables):
    ni=i if i<2 else i+1
    current=celltexts(d.tables[ni]);before=celltexts(oldtable)
    check(f"inherited table {i+1} data retained",current[:len(before)]==before)
check("six component rows",len(d.tables[2].rows)==7)
check("three assumption rows added",len(d.tables[-1].rows)==len(base.tables[-1].rows)+3)
captions=[p.text for p in d.paragraphs if p.style.name=="Caption" and re.match(r"Table \d+ ",p.text)]
check("table captions in sequence",[int(re.match(r"Table (\d+)",p).group(1)) for p in captions]==list(range(1,9)))
styles={s.style_id for s in d.styles}
check("all paragraph and character styles defined",all(e.get(qn("w:val")) in styles for e in d.element.iter() if e.tag in (qn("w:pStyle"),qn("w:rStyle"))))
check("title subtitle and headings black",all(s.font.color.rgb is not None and str(s.font.color.rgb)=="000000" for s in d.styles if s.name in ("Title","Subtitle","Heading 1","Heading 2")))
for tag,order in {"rPr":["lit","nor","scr","sty","brk","aln"],"dPr":["begChr","sepChr","endChr","grow","shp","ctrlPr"]}.items():
    ix={qn("m:"+name):i for i,name in enumerate(order)}
    check("math "+tag+" schema order",all([ix.get(c.tag,99) for c in pr]==sorted(ix.get(c.tag,99) for c in pr) for pr in d.element.iter(qn("m:"+tag))))
md=(ROOT/"paper_v3.md").read_text()
for name in ("H1","H2","H3","H4"):
    check("new prediction "+name,"Hypothesis "+name in md)
check("new neuroscience section present","10.5 Protected claims and revisable cortical memory" in md)
check("earlier N and C series retained",all("Hypothesis "+name in md for name in ("N1","N2","N3","C1","C2","C3","C4","C5")))
images=re.findall(r"!\[[^\]]*\]\(([^)]+)\)",md)
check("Markdown figure paths resolve",len(images)==2 and all((ROOT/p).is_file() for p in images))
for name in ("build_v3.py","check_v3.py","audit_v3.py"):ast.parse((ROOT/name).read_text())
check("current Python sources parse",True)
exact=json.loads((ROOT/"checks_v3.json").read_text())
check("24 exact checks pass",exact["all_passed"] and len(exact["checks"])==24)
check("authoritative base matches supplied archive copy",(ROOT/"base_v2.docx").read_bytes()==(ROOT/"inherited_v2/Interval_Do_Calculus_for_Reusable_ADC_V2.docx").read_bytes())
files={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/"inherited_v2").rglob("*")) if p.is_file()}
result={"scope":"Structural and provenance checks, not full XSD validation or a fresh inherited census run.",
        "all_passed":all(c["passed"] for c in checks),"checks":checks,
        "native_equations":nmath,"native_display_equations":ndisplay,"tables":8,"figures":2,"review_comments":4,
        "inherited_file_sha256":files}
(ROOT/"qa_v3.json").write_text(json.dumps(result,indent=2)+"\n")
print(f"{len(checks)} structural/source checks passed; {nmath} native equations, {ndisplay} displays.")
