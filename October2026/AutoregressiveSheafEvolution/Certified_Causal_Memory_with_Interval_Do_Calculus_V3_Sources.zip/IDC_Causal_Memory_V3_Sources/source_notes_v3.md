# Added literature and inference boundaries

Sources checked on 1 November 2026. Bibliographic metadata and empirical claims
were checked against journal, author or PubMed records. Review and hypothesis
articles are identified by their role.

| Reference | Primary or authoritative record | What the revision uses |
|---|---|---|
| Bouton (2004) | https://doi.org/10.1101/lm.78804 | Review's account of context-sensitive extinction; not evidence for a complete assertion history |
| Yang, Pan and Gan (2009) | https://www.nature.com/articles/nature08577 | Longitudinal cortical spine stability with continuing plasticity |
| Gogolla et al. (2009) | https://pubmed.ncbi.nlm.nih.gov/19729657/ | Manipulation of perineuronal nets in amygdala and extinction susceptibility; not a neocortical certificate study |
| Tsien (2013) | https://pubmed.ncbi.nlm.nih.gov/23832785/ and https://doi.org/10.1073/pnas.1310158110 | Original net-hole storage hypothesis, explicitly not established mechanism |
| Winocur and Moscovitch (2011) | https://pubmed.ncbi.nlm.nih.gov/21729403/ | Transformation account and its distinctions between episodic and semantic memory |
| Tse et al. (2007) | https://pubmed.ncbi.nlm.nih.gov/17412951/ | Rat schema experiment and rapid assimilation; no proof that gist is a numeric interval |
| Driscoll et al. (2017) | https://pmc.ncbi.nlm.nih.gov/articles/PMC5718200/ and https://doi.org/10.1016/j.cell.2017.07.021 | Population-level function with changing cellular activity; no perfect immutable cross-time decoder |
| Kitamura et al. (2017) | https://pmc.ncbi.nlm.nih.gov/articles/PMC5493329/ | Prefrontal engram maturation, hippocampal support and context-specific remote memory |
| Kirkpatrick et al. (2017) | https://arxiv.org/abs/1612.00796 and https://doi.org/10.1073/pnas.1611835114 | Importance-weighted quadratic parameter protection; not a write-protected record store |
| Anthropic (2026) | https://www.anthropic.com/engineering/harness-design-long-running-apps | Generator/evaluator separation and orchestration costs; no formal causal checker guarantee |

Nader et al. (2000), Agent Lightning, SWE-agent and the two 2025 Anthropic guides
were already cited in the supplied paper. The 2026 Agent Lightning primary record
was checked at https://arxiv.org/abs/2608.17528. Existing formal citations retain
their original scope. No empirical result is inferred from an analogy alone.

The inherited census is not literature evidence about the brain. The 65.6%
upper-endpoint persistence value is derived from 3,934 unchanged endpoints among
6,000 exported refinements; it differs from 1,258 selected witnesses remaining
feasible. New proofs are elementary applications of support bounds, set inclusion,
sound abstraction and checked execution rather than claims of new general
duality or neuroscience theorems.
