"""Build IDC V3 by editing the supplied V2 Word paper.

Inputs are bundled locally. Existing equations, figures and census data are
retained. A new component table renumbers old Tables 3-7 as Tables 4-8.
Requires python-docx, lxml and Pandoc. No solver, agent or compiler is run.
"""
from pathlib import Path
import argparse,copy,re,subprocess,tempfile,zipfile
from lxml import etree
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parent
SRC=ROOT/"base_v2.docx"
TITLE="Certified Causal Memory with Interval Do Calculus"
NAME="Certified_Causal_Memory_with_Interval_Do_Calculus_V3.docx"
W="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M="http://schemas.openxmlformats.org/officeDocument/2006/math"
NS={"w":W,"m":M}

def main(out):
    d=Document(SRC);body=d.element.body
    blocks=dict(re.findall(r"<!-- BLOCK (\w+) -->\s*(.*?)(?=<!-- BLOCK |\Z)",(ROOT/"additions_v3.md").read_text(),re.S))
    def txt(p):return p.text.replace("’","'").replace("\xa0"," ")
    def find(prefix):
        matches=[p for p in d.paragraphs if txt(p).startswith(prefix)]
        if len(matches)!=1:raise ValueError((prefix,len(matches)))
        return matches[0]
    def frag(md):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td);(td/"f.md").write_text(md,encoding="utf-8")
            subprocess.run(["pandoc",str(td/"f.md"),"-f","markdown+tex_math_dollars-auto_identifiers-fancy_lists", "-o",str(td/"f.docx"),f"--reference-doc={SRC}"],check=True)
            f=Document(td/"f.docx")
            els=[copy.deepcopy(e) for e in f.element.body if e.tag!=qn("w:sectPr")]
            for e in els:
                for b in list(e.iter(qn("w:bookmarkStart")))+list(e.iter(qn("w:bookmarkEnd"))):b.getparent().remove(b)
                for el in e.iter():
                    for key in (qn("r:id"),qn("r:embed")):
                        rid=el.get(key)
                        if rid and rid in f.part.rels:
                            rel=f.part.rels[rid]
                            if rel.is_external:el.set(key,d.part.relate_to(rel.target_ref,rel.reltype,is_external=True))
        return els
    def before(p,els):
        e=p._p if hasattr(p,"_p") else p
        for node in els:e.addprevious(node)
    def after(p,els):
        e=p._p if hasattr(p,"_p") else p
        for node in els:e.addnext(node);e=node
    def replace(prefix,md):
        p=find(prefix);before(p,frag(md));body.remove(p._p)
    def plain(prefix,text):
        p=find(prefix)
        for e in list(p._p):
            if e.tag!=qn("w:pPr"):p._p.remove(e)
        p.add_run(text)
    # Renumber inherited table captions and their textual references first.
    for t in d.element.iter(qn("w:t")):
        if t.text:t.text=re.sub(r"\bTable ([3-7])\b",lambda m:"Table "+str(int(m.group(1))+1),t.text)

    plain("Interval Do Calculus for Reusable",TITLE)
    plain("Certified memory and adaptive computation", "Persistent claims, revisable memory and verified reuse")
    plain("Version 2, 1 November 2026","Version 3, 1 November 2026")
    replace("Autoregressive causal reasoning becomes expensive", """Interval Do Calculus (IDC) is a proposed certification layer for reusing computations in Autoregressive Do Calculus. Incoming and outgoing graph cuts define different causal operations, while numerical bounds require a fixed query and a nonempty admissible model set. This revision develops certified causal memory: accepted assertions retain their original scopes, and new records express supersession, transport or weaker guarantees. A premise-deletion theorem bounds the cost of discarding constraints, a coefficient-drift theorem repairs bounds reconstructed with certified numerical error, and a summary theorem states which query enclosure a compressed memory must preserve. The results complement the existing refinement, witness, multiplier, transport and decision-stopping contracts. The inherited exact C# census is retained: a selected upper optimizer survives 21.0% of evidence refinements, but the upper endpoint itself remains unchanged in 65.6%. After the mass-0.05 data change, multiplier repair is valid throughout the declared family and exact in 80.4%, while 41.7% of old numerical bounds are false. More complete endpoint checking can cost more simplex pivots, so none of these rates establishes wall-time acceleration. New Section 10.5 compares protected claims with extinction, stable spines, perineuronal nets, schemas, representational drift and systems consolidation, and states four falsifiable H-series predictions. Gist is an outer approximation only under a justified concretization; refinement validity alone does not favor coarse memories. The expanded six-component harness pins request snapshots and separates proposal from checked acceptance. Its safety contract is independent of the learned route policy, while finite soft weight penalties do not make records immutable. New exact examples support the added formulas without rerunning the inherited census. The biological mapping, learned scheduler and end-to-end speed-up remain untested proposals.""")
    plain("Keywords", "Keywords interval do calculus; causal memory; certificate reuse; evidence refinement; memory consolidation; representational drift; sheaf compatibility; adaptive AI harness")
    after(find("Version 2 implements these contracts."),frag("Version 3 adds Definitions 4.5 and 11.2, Theorems 5.6, 6.8 and 11.3, Corollary 5.7, Observation 5.8 and Propositions 9.4 and 11.4. Their ingredients are established order, support-function, abstraction and program-safety arguments specialized to the IDC memory contract. Section 10.5 adds four biological predictions H1–H4; earlier N1–N3 and computational C1–C5 retain their separate roles. The original algorithms and census are inherited results, not new harness or biological experiments."))
    replace("Sections 2 and 3 define surgeries", "Sections 2–3 define interventions, interval objects and evidence. Sections 4–7 develop persistent assertions, refinement, controlled weakening, coefficient drift, transport and decision stopping. Sections 8–9 state the horizontal and retained-memory contracts. Section 10 develops the neuroscience analogy, including the new Section 10.5 and H1–H4. Section 11 specifies six harness components, request routing, scheduler learning and snapshot checks. Section 12 distinguishes the inherited exact census from the new worked examples. Sections 13–14 retain prospective computational tests and discuss limitations; Appendices A–B give assumptions and reproduction.")
    before(find("5 Reuse under sequential"),frag(blocks["claims"]))
    before(find("6 Transport to nearby"),frag(blocks["forgetting"]))
    after(find("For a refinement, old rows retain their meanings"),frag(r"The C# kernel retains free multipliers $\nu$ on equality rows $Eq=f$. This is equivalent to the nonnegative convention in (9): replace each equality by $Eq\leq f$ and $-Eq\leq-f$, with multipliers $[\nu]_+$ and $[-\nu]_+$. Equality multipliers therefore need not have a nonnegative sign. The new drift bound applies after this canonical expansion; for shared symmetric errors its equality-row sensitivity uses $|\nu|$."))
    before(find("7 Stopping when"),frag(blocks["drift"]))
    before(find("10 Neuroscience as"),frag(blocks["summary"]))
    before(find("11 An AI harness"),frag(blocks["neuroscience"]))
    # Add the component table without removing the inherited interface account.
    after(find("The proposed harness contains a semantic registry"),frag(blocks["components"]))
    start=find("For a request consisting of context")
    end=find("Anthropic (2025a) discusses context compaction")
    e=start._p
    while e is not None and e is not end._p:
        nxt=e.getnext();body.remove(e);e=nxt
    before(end,frag(blocks["request"]))
    before(find("12 Exact analytical examples"),frag(blocks["runtime"]))
    before(find("13 Falsifiable computational"),frag(blocks["newchecks"]))
    for t in d.element.iter(qn("w:t")):
        if t.text:
            t.text=t.text.replace("Add slack variables to the inequality rows and the normalisation row, giving standard form.","Keep normalization and data equalities as equalities, add slacks only to inequalities, and introduce artificial variables for phase one.")
    # Preserve the earlier empirical record while identifying its provenance.
    replace("An independent Python program checks every census line", r"Version 2's independent Python program checks every supplied census line. For each of the 7,000 evidence states, it re-certifies the C# upper and lower endpoints exactly from exported feasible attaining witnesses and its own evaluation of (9), with nonnegative inequality multipliers. Other bounds were compared with SciPy's HiGHS solver within $1.4\times10^{-15}$. It independently recomputed face feasibility and the surgery census. The supplied validation reports 12 passing checks. Version 3 preserves those outputs without a fresh full validator or compiler run; Section 12.11 identifies the calculations newly performed here. Pivot counts remain C# implementation measurements without independent validation.")
    replace("Neuroscience supports studying selective access", "Neuroscience motivates selective access, contextual recovery, protected plasticity and circuit reorganization, while reconsolidation and representational drift limit literal immutability. Theorem 5.1 preserves outer bounds at every precision; it does not establish a biological advantage for coarse memories. Losing one witness differs from losing endpoint sharpness. Section 10.5 therefore treats preferential retention of constraints, coarse claims, contextual supersession and selective dependency loss as four prospective predictions. A sufficient relational frontier need not lose joint structure.")
    replace("The first implementation should expose the certificate interface", "The next implementation should expose the six-component certificate interface and snapshot commit check before training a route policy. Its target is a measured reduction in redundant work under an unchanged correctness contract. The inherited census supplies algorithmic cases, including useful witness reuse, effective multiplier repair and a more complete test that costs extra pivots. The new mathematics bounds weakening and reconstruction error; it does not establish a neural storage mechanism or end-to-end acceleration. Those remain tests for the proposed harness and H-series biological mapping.")
    # Replace the old external manuscript build dependency with a bundled base.
    replace("The source bundle contains the C# project", """The current source bundle includes `base_v2.docx`, `additions_v3.md`, `build_v3.py`, `check_v3.py` and the new result file `checks_v3.json`, with the supplied Version 2 sources in `inherited_v2/`. From the bundle root, run `python check_v3.py` for the new exact examples and exported endpoint tallies, and `python build_v3.py` for the updated Word paper. The builder requires python-docx, lxml and Pandoc; the checker uses the standard library. A synchronized Markdown copy and extracted figures accompany the Word file. The current builder needs no earlier manuscript outside the bundle.

The inherited .NET 8 kernel and original outputs remain available. Inside `inherited_v2/`, its documented census command is `dotnet run -c Release --project kernel -- out --idc > cs_idc.txt`, followed by `python validate_idc.py cs_idc.txt out/iv_records.json validation_idc.json`. These describe the historical reproduction path, not a run newly claimed by Version 3. The inherited builder refers to earlier manuscript inputs and is retained for provenance; `build_v3.py` is the supported build for this revision. Public C# values are immutable records, while simplex tableaux are local scratch data.

Version 3's new exact result JSON is generated in two clean processes and compared byte for byte. The inherited source and result files are preserved unchanged. Rendering remains necessary after rebuilding because fonts and Office versions can alter pagination. No agent benchmark, latency experiment, training run or biological experiment is added.""")

    refs=find("References")
    added=[
      "Anthropic. (2026, March 24). *Harness design for long-running application development*. https://www.anthropic.com/engineering/harness-design-long-running-apps",
      "Bouton, M. E. (2004). Context and behavioral processes in extinction. *Learning & Memory, 11*(5), 485–494. https://doi.org/10.1101/lm.78804",
      "Driscoll, L. N., Pettit, N. L., Minderer, M., Chettih, S. N., & Harvey, C. D. (2017). Dynamic reorganization of neuronal activity patterns in parietal cortex. *Cell, 170*(5), 986–999.e16. https://doi.org/10.1016/j.cell.2017.07.021",
      "Gogolla, N., Caroni, P., Lüthi, A., & Herry, C. (2009). Perineuronal nets protect fear memories from erasure. *Science, 325*(5945), 1258–1261. https://doi.org/10.1126/science.1174146",
      "Kirkpatrick, J., Pascanu, R., Rabinowitz, N., Veness, J., Desjardins, G., Rusu, A. A., Milan, K., Quan, J., Ramalho, T., Grabska-Barwinska, A., Hassabis, D., Clopath, C., Kumaran, D., & Hadsell, R. (2017). Overcoming catastrophic forgetting in neural networks. *Proceedings of the National Academy of Sciences, 114*(13), 3521–3526. https://doi.org/10.1073/pnas.1611835114",
      "Kitamura, T., Ogawa, S. K., Roy, D. S., Okuyama, T., Morrissey, M. D., Smith, L. M., Redondo, R. L., & Tonegawa, S. (2017). Engrams and circuits crucial for systems consolidation of a memory. *Science, 356*(6333), 73–78. https://doi.org/10.1126/science.aam6808",
      "Tse, D., Langston, R. F., Kakeyama, M., Bethus, I., Spooner, P. A., Wood, E. R., Witter, M. P., & Morris, R. G. M. (2007). Schemas and memory consolidation. *Science, 316*(5821), 76–82. https://doi.org/10.1126/science.1135935",
      "Tsien, R. Y. (2013). Very long-term memories may be stored in the pattern of holes in the perineuronal net. *Proceedings of the National Academy of Sciences, 110*(30), 12456–12461. https://doi.org/10.1073/pnas.1310158110",
      "Winocur, G., & Moscovitch, M. (2011). Memory transformation and systems consolidation. *Journal of the International Neuropsychological Society, 17*(5), 766–780. https://doi.org/10.1017/S1355617711000683",
      "Yang, G., Pan, F., & Gan, W.-B. (2009). Stably maintained dendritic spines are associated with lifelong memories. *Nature, 462*(7275), 920–924. https://doi.org/10.1038/nature08577",
    ]
    # Sort reference paragraphs as intact OOXML, preserving inherited italics.
    allrefs=[]
    for p in list(refs._p.itersiblings()):
        if p.tag==qn("w:p"):
            allrefs.append(p);body.remove(p)
    for s in added:allrefs.extend(frag(s))
    allrefs.sort(key=lambda p:"".join(p.xpath(".//w:t/text()")))
    after(refs,allrefs)

    # Missing character styles from fragment insertion are defined explicitly.
    ids={s.style_id for s in d.styles}
    if "FirstParagraph" not in ids:
        s=d.styles.add_style("First Paragraph",WD_STYLE_TYPE.PARAGRAPH);s.base_style=d.styles["Normal"]
    if "VerbatimChar" not in ids:
        s=d.styles.add_style("Verbatim Char",WD_STYLE_TYPE.CHARACTER);s.font.name="Courier New";s.font.size=Pt(9.5)
    if "CommentReference" not in ids:
        s=d.styles.add_style("Comment Reference",WD_STYLE_TYPE.CHARACTER);s.font.superscript=True
    # Source typography remains 11.5 pt and 1.1 spacing; all headings are black.
    for s in d.styles:
        if s.type==1:
            s.font.color.rgb=RGBColor(0,0,0)
            rf=s.element.find(".//"+qn("w:rFonts"))
            if rf is not None:
                for key in list(rf.attrib):
                    if key.endswith("Theme"):del rf.attrib[key]
    reference_mode=False
    for p in d.paragraphs:
        if p.text=="References":reference_mode=True;continue
        if reference_mode:
            p.style=d.styles["Normal"];p.alignment=WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.left_indent=Inches(.25);p.paragraph_format.first_line_indent=Inches(-.25)
            p.paragraph_format.space_after=Pt(4);p.paragraph_format.line_spacing=1.08;p.paragraph_format.keep_together=True
            for r in p.runs:r.font.size=Pt(10.5)
        if p.style.name in ("Title","Subtitle") or p.style.name.startswith("Heading"):
            for r in p.runs:r.font.color.rgb=RGBColor(0,0,0)
        if p.text.startswith(("Figure 1 ","Figure 2 ")):p.paragraph_format.keep_together=True
        if p.text.startswith("Table 3 Components"):
            p.style=d.styles["Caption"];p.paragraph_format.keep_with_next=True
    # The new components table is the third table in document order.
    assert len(d.tables)==8
    t=d.tables[2];t.autofit=False
    widths=[1950,3705,3705]
    pr=t._tbl.find(qn("w:tblPr"))
    borders=pr.find(qn("w:tblBorders"))
    if borders is None:borders=OxmlElement("w:tblBorders");pr.append(borders)
    for side in ("top","left","bottom","right","insideH","insideV"):
        el=OxmlElement("w:"+side);el.set(qn("w:val"),"single");el.set(qn("w:sz"),"4");el.set(qn("w:color"),"D9D9D9");borders.append(el)
    for gc,width in zip(t._tbl.tblGrid.gridCol_lst,widths):gc.set(qn("w:w"),str(width))
    for ri,row in enumerate(t.rows):
        rp=row._tr.get_or_add_trPr();rp.append(OxmlElement("w:cantSplit"))
        if ri==0:rp.append(OxmlElement("w:tblHeader"))
        for ci,cell in enumerate(row.cells):
            cell.width=Inches(widths[ci]/1440);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            cp=cell._tc.get_or_add_tcPr();sh=OxmlElement("w:shd");sh.set(qn("w:fill"),"E8EDF1" if ri==0 else "FFFFFF");cp.append(sh)
            mar=OxmlElement("w:tcMar")
            for tag,sz in (("top",85),("bottom",85),("left",80),("right",80)):
                el=OxmlElement("w:"+tag);el.set(qn("w:w"),str(sz));el.set(qn("w:type"),"dxa");mar.append(el)
            cp.append(mar)
            for p in cell.paragraphs:
                p.style=d.styles["Body Text"];p.alignment=WD_ALIGN_PARAGRAPH.LEFT
                p.paragraph_format.space_after=Pt(2);p.paragraph_format.line_spacing=1.05
                for run in p.runs:run.font.size=Pt(10);run.bold=(ri==0)
    assumptions=d.tables[-1]
    for cells in [
      ("Theorem 5.6","Aligned retained rows, nonnegative multipliers and a nonempty retained model set","Free deletion of premises without weakening the claim"),
      ("Theorem 6.8","Certified coefficient radii, fixed meanings, units and response coordinates","Error radii inferred from neural similarity alone"),
      ("Theorem 11.3","Correct checkers, complete dependencies and a checked terminal snapshot","Termination, low cost or a learned harness implementation"),
    ]:
        row=assumptions.add_row()
        row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
        for cell,text in zip(row.cells,cells):
            cell.text=text;cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            for p in cell.paragraphs:
                p.paragraph_format.space_after=Pt(3);p.paragraph_format.line_spacing=1.05
                for r in p.runs:r.font.size=Pt(10)

    # Pandoc emits some OMML properties in non-schema order.
    orders={"m:rPr":["lit","nor","scr","sty","brk","aln"],"m:dPr":["begChr","sepChr","endChr","grow","shp","ctrlPr"]}
    for tag,order in orders.items():
        order={qn("m:"+v):i for i,v in enumerate(order)}
        for el in d.element.iter(qn(tag)):
            kids=list(el)
            if tag=="m:rPr" and el.find(qn("m:nor")) is not None:kids=[c for c in kids if c.tag not in (qn("m:sty"),qn("m:scr"))]
            for c in list(el):el.remove(c)
            for c in sorted(kids,key=lambda c:order.get(c.tag,99)):el.append(c)
    for x in d.element.iter(qn("m:t")):
        if x.text=="\\":x.text="∖"
    d.core_properties.title=TITLE+", Version 3"
    d.core_properties.subject="Persistent claims, protected memory, coefficient drift and certified causal reuse"
    d.core_properties.last_modified_by="Revision review"
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        raw=Path(td)/"raw.docx";d.save(raw);comments(raw,out)
    print(out)

def comments(source,target):
    with zipfile.ZipFile(source) as z:files={n:z.read(n) for n in z.namelist()}
    root=etree.fromstring(files["word/document.xml"])
    cm=etree.fromstring(files["word/comments.xml"]) if "word/comments.xml" in files else etree.Element(qn("w:comments"),nsmap={"w":W})
    nextid=max([int(c.get(qn("w:id"))) for c in cm]+[-1])+1
    notes=[
      ("Observation 5.8 (width does not order refinement durability)","V3 distinction: 21.0% is survival of the selected upper optimizer. The upper endpoint persists in 65.6% because other optimizers can survive. Refinement preserves every valid outer interval, regardless of width."),
      ("Hypothesis H2 (coarse claims resist interference)","V3 biological prediction: this is not implied by the outer-bound theorem. Matching logical validity and retrieval difficulty prevents tolerance differences from being mistaken for memory durability."),
      ("Definition 11.2 (a request snapshot)","V3 harness extension: snapshot and commit checks are a proposed interface. Existing exact algorithms and historical census results do not establish an implemented learned harness or wall-time improvement."),
      ("Keep normalization and data equalities as equalities", "V3 algorithm clarification: slack variables apply only to inequalities. Equality rows and normalization remain equalities; phase one introduces artificial variables. The unchanged kernel uses this distinction and permits free equality multipliers."),
    ]
    for k,(needle,text) in enumerate(notes,nextid):
        ps=[p for p in root.xpath(".//w:p",namespaces=NS) if needle in "".join(p.xpath(".//w:t/text()",namespaces=NS))]
        if len(ps)!=1:raise ValueError((needle,len(ps)))
        p=ps[0];start=OxmlElement("w:commentRangeStart");start.set(qn("w:id"),str(k));p.insert(1 if len(p) and p[0].tag==qn("w:pPr") else 0,start)
        end=OxmlElement("w:commentRangeEnd");end.set(qn("w:id"),str(k));p.append(end)
        r=OxmlElement("w:r");rp=OxmlElement("w:rPr");sty=OxmlElement("w:rStyle");sty.set(qn("w:val"),"CommentReference");rp.append(sty);r.append(rp)
        ref=OxmlElement("w:commentReference");ref.set(qn("w:id"),str(k));r.append(ref);p.append(r)
        c=etree.SubElement(cm,qn("w:comment"));c.set(qn("w:id"),str(k));c.set(qn("w:author"),"Revision review")
        cp=etree.SubElement(c,qn("w:p"));rr=etree.SubElement(cp,qn("w:r"));tt=etree.SubElement(rr,qn("w:t"));tt.text=text
    rels=etree.fromstring(files["word/_rels/document.xml.rels"]);typ="http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"
    if not any(x.get("Type")==typ for x in rels):
        ids={x.get("Id") for x in rels};n=1
        while f"rId{n}" in ids:n+=1
        x=etree.SubElement(rels,"{http://schemas.openxmlformats.org/package/2006/relationships}Relationship");x.set("Id",f"rId{n}");x.set("Type",typ);x.set("Target","comments.xml")
    ct=etree.fromstring(files["[Content_Types].xml"])
    if not any(x.get("PartName")=="/word/comments.xml" for x in ct):
        x=etree.SubElement(ct,"{http://schemas.openxmlformats.org/package/2006/content-types}Override");x.set("PartName","/word/comments.xml");x.set("ContentType","application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml")
    for name,x in [("word/document.xml",root),("word/comments.xml",cm),("word/_rels/document.xml.rels",rels),("[Content_Types].xml",ct)]:files[name]=etree.tostring(x,xml_declaration=True,encoding="UTF-8",standalone=True)
    with zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED) as z:
        for n,data in files.items():z.writestr(n,data)

if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("--output",type=Path,default=ROOT/NAME);args=ap.parse_args();main(args.output)
