# 12 Mathematics of dependency preserving computation

The computations of Section 11 raise three mathematical questions. Which equalities are discarded when an interval grows? When does a range admit a cheap exact computation? What information about an unseen future can a symmetric read recover? This section answers these questions for explicit finite models. The uncertainty sets are sets of possible values, not probability laws. A narrow interval is not a posterior credible interval unless a separate probabilistic argument supplies that interpretation.

## 12.1 Shared quantities and occurrence constraints

**Definition 12.1 (dependency preserving uncertainty diagram).** Assign units to the uncertain quantities and require every operation to respect them. Let $B=\prod_{i=1}^{m}[l_i,u_i]$ contain one coordinate for each independently uncertain quantity. Unfold a finite scalar expression into a tree. If quantity $i$ occurs at leaves in a set $O_i$, introduce a coordinate $z_o$ at every such leaf. The occurrence box and its tied subset are

$$
\begin{aligned}
B_{\mathrm{occ}}&=\prod_i\prod_{o\in O_i}[l_i,u_i],\\
\Delta_B&=\{z\in B_{\mathrm{occ}}:z_o=z_{o'}\text{ whenever }o,o'\in O_i\}.
\end{aligned}
\qquad\text{(12.1)}
$$

The tree expression on $B_{\mathrm{occ}}$, together with these equality constraints and any additional declared parameter relations, is the uncertainty diagram. It preserves dependencies when its feasible assignments retain every declared equality. For a counterfactual, shared exogenous circumstances and shared mechanism parameters have the same identity in both worlds. Unrelated uncertainties receive separate coordinates.

This construction has the same incidence interpretation as Definition 2.2. A context contains the graph of an elementary operation; variable points identify occurrences of the same quantity. Compatible sections satisfy both the arithmetic relations and the identities. Splitting a shared variable point into independent copies removes a compatibility condition and enlarges the set of feasible assignments. An interval enclosure of that enlarged set changes the numerical relaxation; it does not change the declared structural causal model.

**Theorem 12.2 (exactness after occurrence independence).** Consider an expression tree using addition, subtraction, multiplication and division. Assume that each interval denominator encountered by natural interval evaluation excludes zero. In ideal real interval arithmetic, the result is exactly the range of the unfolded expression on $B_{\mathrm{occ}}$. Consequently it contains the range on $\Delta_B$.

*Proof.* A leaf has its prescribed interval as its exact range. Suppose the assertion holds for the two children of an operation. Their occurrence coordinates are disjoint, so every pair of values in their two ranges is simultaneously attainable. The range of the parent is therefore the range of that operation on the Cartesian product of the two child intervals. For addition and subtraction, its extrema are the familiar endpoint sums and differences. For multiplication and division away from zero, extrema are among the four endpoint combinations. The operation is continuous on the relevant rectangle, so its image is an interval and contains every value between the extrema. These are exactly the natural interval formulas. Induction proves equality at the root. Finally $\Delta_B\subseteq B_{\mathrm{occ}}$, proving inclusion of the tied range. ∎

The theorem concerns these elementary expression trees, not arbitrary interval algorithms or arbitrary nonlinear functions. Outward rounding can enlarge the ideal result further. Proposition 11.3 is a special case: stepwise abduction can discard identities involving the evidence, exogenous variables and parameters. Calling this simply a change to independent causal worlds is too narrow; the actual operation is the loss of declared occurrence equalities.

**Proposition 12.3 (tied parameters can create interior extrema).** Multi-affinity in separate edge gains does not imply that extrema occur at endpoints of an underlying parameter that ties those gains.

*Proof.* On a two-edge path, set the gains to $\theta$ and $1-\theta$, with $0\leq\theta\leq1$. The response is $\theta(1-\theta)$, whose exact range is $[0,1/4]$. Both parameter endpoints give zero and the maximum occurs at $\theta=1/2$. Treating the two gains as independent coordinates in $[0,1]^2$ instead gives the range $[0,1]$. The response is multi-affine in the two edge coordinates but quadratic after their relation is substituted. ∎

Thus Proposition 11.1 applies to a box in independently varying edge coordinates. Shared learned parameters, conservation laws or geometric chart relations may replace that box by a constrained subset. A box remains an enclosure, but its corners need not solve the constrained problem.

**Proposition 12.4 (unbounded inflation from a shared prefix).** There is no finite universal upper bound on the ratio of the width of natural interval forward substitution to the positive exact width of an acyclic intervention response.

*Proof.* Let a source perturbation be one. Pass it through a gain $a\in[-1,1]$, copy that result into two branches with fixed gains $+1$ and $-1$, add the branches, and pass their sum through $b\in[-1,1]$. Add a direct source-to-output gain $\zeta\in[-\varepsilon,\varepsilon]$, where $\varepsilon>0$. The exact response is

$$
p(a,b,\zeta)=ab-ab+\zeta=\zeta,
\qquad
\operatorname{range}p=[-\varepsilon,\varepsilon].
\qquad\text{(12.2)}
$$

Natural interval forward substitution adds two copies of $[-1,1]$ to obtain $[-2,2]$. Multiplication by $[-1,1]$ leaves this interval unchanged, and addition of $\zeta$ gives $[-2-\varepsilon,2+\varepsilon]$. The ideal width ratio is $(4+2\varepsilon)/(2\varepsilon)=1+2/\varepsilon$, which diverges as $\varepsilon\downarrow0$. The construction is a finite DAG with six vertices and seven edges. ∎

The kernel checks ratios of 201 at $\varepsilon=1/100$ and 2,000,001 at $\varepsilon=1/1{,}000{,}000$; floating-point enclosures add only rounding slack. These are explicit cancellation examples, not a claim about the frequency of such cases. The modest maximum in Table 2 cannot supply a general worst-case guarantee. Algebraic collection after specializing the fixed gains eliminates the cancellation here, but that observation does not make greedy factorization universally exact.

## 12.2 A sign criterion and an exact complexity barrier

Call the union of the directed source-to-terminal paths the route core. Remove edges whose gain interval is identically zero. Suppose each remaining gain is written $g_e=\sigma_e a_e$, with fixed $\sigma_e\in\{-1,1\}$ and independent amplitudes $a_e\in[\underline a_e,\overline a_e]\subseteq[0,\infty)$. A formal path sign is the product of its $\sigma_e$, including when an admissible amplitude happens to be zero.

**Theorem 12.5 (sign coherence and exact forward ranges).** Assume the route core is nonempty. The following conditions are equivalent:

**Condition 1.** Every directed source-to-terminal path has the same formal sign $\tau$.

**Condition 2.** There are vertex signs $\eta_v\in\{-1,1\}$, with $\eta_s=1$, such that every route-core edge $v\to w$ has $\sigma_{vw}=\eta_v\eta_w$.

Under these conditions, if $p(a)$ is the nonnegative-amplitude path sum, the exact signed response range is

$$
\operatorname{hull}\{\tau p(\underline a),\tau p(\overline a)\}.
\qquad\text{(12.3)}
$$

Natural interval forward substitution returns this range in ideal interval arithmetic.

*Proof.* Assume condition 1. Fix a vertex $v$ on a source-to-terminal path and any directed suffix from $v$ to the terminal. Every source-to-$v$ prefix can be appended to this suffix: a repeated vertex would create a directed cycle. All resulting complete paths have the same sign, so all prefixes to $v$ have the same sign. Define $\eta_v$ to be that sign and $\eta_s=1$. Extending a prefix by an edge gives $\eta_w=\eta_v\sigma_{vw}$, which is condition 2. Conversely, the product of $\eta_v\eta_w$ along any complete path telescopes to $\eta_s\eta_t=\eta_t$, proving condition 1.

For the range statement, transform the propagated response by $\widetilde r_v=\eta_v r_v$. Every transformed edge gain is $a_e\geq0$. Proposition 11.2 gives exact lower and upper responses from the two amplitude endpoints. Returning to $r_t=\eta_t\widetilde r_t$ gives (12.3). At each original node, all signed summands have the same prescribed sign, so sign reversal commutes with the endpoint computation; the original forward interval pass has the same result. ∎

The vertex signs are the scalar sign gauge of a balanced signed graph (Harary, 1953), restricted here to a directed route core. They make all edge signs positive; they do not make different causal route gains equal. The theorem therefore does not impose the invalid causal commutation rejected by Lemma 3.1. Its condition is sufficient for interval exactness, not necessary: a read-once polynomial such as $ab-cd$ can also have an exact natural interval range.

The positive result has a sharp computational limit. General polynomial complexity alone would not establish hardness for the restricted path polynomials of this paper. The next construction does.

**Theorem 12.6 (NP-hardness of an exact acyclic response range).** Computing the exact range of a scalar source-to-terminal response over independent gain intervals is NP-hard, even on a four-layer DAG in which every source-to-terminal path has three edges. In the family constructed below, deciding whether the maximum exceeds a supplied integer threshold is NP-complete.

*Proof.* Reduce weighted MAX-CUT with nonnegative integer weights, using its classical NP-completeness (Karp, 1972). Let $H=(W,F)$ be an undirected graph with edge weights $a_e$. Form four layers: a source $s$, one vertex node $v_i$ for each $i\in W$, one edge node $w_e$ for each $e\in F$, and terminal $t$. Put the uncertain gain $x_i\in[-1,1]$ on $s\to v_i$. Orient each undirected edge arbitrarily, say $e=(i,j)$, and put fixed gains $+a_e$ on $v_i\to w_e$ and $-a_e$ on $v_j\to w_e$. Put an uncertain gain $y_e\in[-1,1]$ on $w_e\to t$. The response to a unit source is

$$
p(x,y)=\sum_{e=(i,j)\in F}a_e y_e(x_i-x_j).
\qquad\text{(12.4)}
$$

For a fixed $x$, maximizing over $y$ gives $\sum_e a_e|x_i-x_j|$. Alternatively, Proposition 11.1 moves a global maximizer to $x_i,y_e\in\{-1,1\}$. At such a vertex, $|x_i-x_j|$ equals two exactly on edges crossing the cut defined by the signs of $x$. Hence

$$
\max p=2\,\operatorname{MaxCut}(H,a),
\qquad
\min p=-2\,\operatorname{MaxCut}(H,a).
\qquad\text{(12.5)}
$$

The minimum follows by reversing all $y_e$. The construction has polynomial size and preserves polynomial bit length. An exact response-range algorithm would solve weighted MAX-CUT. For the threshold problem in this family, corner signs provide a polynomial certificate, and the resulting integer response can be evaluated in polynomial time. The problem is therefore also in NP. ∎

Here “exceeds a supplied integer threshold” uses a strict inequality; replacing it by “is at least” gives the same decision complexity by shifting an integer threshold. The kernel and an independent NumPy enumeration verify (12.5) for all 74 simple graphs on two, three and four labeled vertices. The triangle gives $[-4,4]$. This finite check illustrates the reduction; the proof covers arbitrary nonnegative integer weights and graph sizes.

For every fixed gain choice, the causal model in the reduction still has a unique solution, and its complete linear mechanism sheaf still has $H^1=0$ by Theorem 4.4. Pointwise solvability and vanishing cohomology do not make optimization over an uncertainty family easy. Unless P equals NP, no general polynomial-time exact factorization method can remove this difficulty.

## 12.3 The amount of future information in a harmonic read

The reciprocity result of Theorem 7.1 gives a qualitative obstruction. For scalar graph smoothing, positivity strengthens it to a quantitative information statement. Let $L$ be the Laplacian of a connected undirected graph with positive edge weights, let $G=\operatorname{diag}(g_1,\ldots,g_n)$ with every $g_i>0$, and put $K(w)=(G+wL)^{-1}G$.

**Theorem 12.7 (positive reversible harmonic read).** For $n\geq2$ and $w>0$, every entry of $K(w)$ is strictly positive,

$$
\begin{aligned}
K(w)\mathbf1&=\mathbf1,\qquad g_iK_{ij}(w)=g_jK_{ji}(w),\\
\lim_{w\to\infty}K_{ij}(w)&=\frac{g_j}{\sum_k g_k}.
\end{aligned}
\qquad\text{(12.6)}
$$

Each diagonal entry strictly decreases with $w$. If block $i$ is the earliest event and all the other input blocks are later, the total future weight $1-K_{ii}(w)$ strictly increases from zero to $1-g_i/\sum_k g_k$.

*Proof.* Write $H=G+wL$. It is symmetric positive definite. If $Hz=b\geq0$ and $z_i<0$ is a minimum, then $(Hz)_i=g_i z_i+w\sum_j a_{ij}(z_i-z_j)<0$, a contradiction. Thus $H^{-1}\geq0$. For $b=e_j$, a zero component would force all its neighbors to be zero; connectivity propagates this to $j$, contradicting $(Hz)_j=1$. Therefore $H^{-1}$ and $K=H^{-1}G$ are strictly positive. Since $H\mathbf1=G\mathbf1$, the rows of $K$ sum to one. Symmetry of $H^{-1}$ proves detailed balance.

Differentiating the inverse gives

$$
\frac{dK_{ii}}{dw}
=-g_i(H^{-1}e_i)^\top L(H^{-1}e_i)<0.
\qquad\text{(12.7)}
$$

Equality would require $H^{-1}e_i$ to be constant on the connected graph. Multiplying by $H$ would then make $e_i$ a multiple of $G\mathbf1$, impossible when $n\geq2$. Finally whiten $L$ as $G^{-1/2}LG^{-1/2}$. Its nullspace is spanned by $G^{1/2}\mathbf1$. The resolvent tends to the orthogonal projection onto this nullspace. Multiplication by $G^{-1/2}$ and $G^{1/2}$ yields the limit in (12.6). At $w=0$, $K=I$, proving the remaining endpoints. ∎

This theorem uses a scalar graph Laplacian with positive weights. It is not a positivity theorem for arbitrary sheaf restrictions, matrix-valued transports or signed connection Laplacians. Those can have a different order structure.

For the path and $G=I$, the whole first row is explicit. The formula is a specialization of tridiagonal inverse theory (Usmani, 1994), derived directly here to expose its temporal meaning.

**Theorem 12.8 (first row and unseen tail of the path resolvent).** For $T\geq1$, $w>0$ and $K=(I+wL_T)^{-1}$, define

$$
\rho=\frac{1+2w-\sqrt{1+4w}}{2w}
=\frac{\sqrt{1+4w}-1}{\sqrt{1+4w}+1},
\qquad 0<\rho<1.
\qquad\text{(12.8)}
$$

Then, for $1\leq j\leq T$,

$$
K_{1j}=\frac{(1-\rho)(\rho^{j-1}+\rho^{2T-j})}{1-\rho^{2T}}.
\qquad\text{(12.9)}
$$

If observations $1,\ldots,m+1$ are available, with $0\leq m\leq T-1$, the total weight on unseen observations is

$$
q_{T,m}=\sum_{j=m+2}^{T}K_{1j}
=\frac{\rho^{m+1}-\rho^{2T-m-1}}{1-\rho^{2T}}.
\qquad\text{(12.10)}
$$

In particular,

$$
\begin{aligned}
1-K_{11}&=\frac{\rho-\rho^{2T-1}}{1-\rho^{2T}}\longrightarrow\rho,\\
K_{1T}&=\frac{(1-\rho^2)\rho^{T-1}}{1-\rho^{2T}}.
\end{aligned}
\qquad\text{(12.11)}
$$

*Proof.* Equation (12.8) gives $w=\rho/(1-\rho)^2$. A column solving the homogeneous interior equation of $I+wL_T$ satisfies $-wv_{j-1}+(1+2w)v_j-wv_{j+1}=0$, whose characteristic roots are $\rho$ and $\rho^{-1}$. The numerator in (12.9) combines the two solutions and satisfies the right endpoint condition $v_{T+1}=v_T$. Summing its entries gives one. All components of $(I+wL_T)v$ except possibly the first are zero; their total is $\mathbf1^\top v=1$, so the first is one. Thus $v$ is the first inverse column; symmetry gives the first row. For $T=1$, (12.9) directly equals one. Summing the two geometric series beyond $m+1$ gives (12.10). Setting $m=0$ and $j=T$ gives (12.11). ∎

**Theorem 12.9 (sharp prefix minimax error).** Fix the observed prefix in Theorem 12.8. Suppose the unseen scalar observations vary independently in $[a,b]$, with diameter $D=b-a>0$. Set $S=\sum_{j=1}^{m+1}K_{1j}y_j$. The full smoother's earliest output has exactly the conditional range

$$
[S+a q_{T,m},\,S+b q_{T,m}].
\qquad\text{(12.12)}
$$

Among all deterministic estimates depending only on that prefix, the minimum worst-case absolute error relative to the full smoother is

$$
\mathcal R_{T,m}=\frac{D}{2}q_{T,m}.
\qquad\text{(12.13)}
$$

*Proof.* All weights are positive. The smallest and largest permitted full outputs are attained by setting every unseen observation to $a$ and to $b$, respectively, and continuity gives the intermediate values. A prefix-only estimate must return the same number for those two completions. Its distance from at least one endpoint is at least half their separation. The midpoint of (12.12) attains this bound for every admissible completion. ∎

The target in this theorem is a retrospective smoother, not the true physical state. A causal predictor may deliberately have another target. Mechanism or clock constraints can also restrict the set of future completions and reduce the minimax radius. The theorem is exact for the stated independent completion box.

**Corollary 12.10 (a uniform lookahead budget).** For every admissible $T,m$,

$$
0\leq \mathcal R_{T,m}\leq \frac{D}{2}\rho^{m+1},
\qquad
\sup_{T\geq m+1}\mathcal R_{T,m}=\frac{D}{2}\rho^{m+1}.
\qquad\text{(12.14)}
$$

Consequently a horizon-uniform absolute-error guarantee $\varepsilon$ is possible exactly when $\rho^{m+1}\leq2\varepsilon/D$, using the minimax midpoint estimate.

*Proof.* In (12.10), $\rho^{2T-m-1}\geq \rho^{m+1}\rho^{2T}$, so $q_{T,m}\leq\rho^{m+1}$. For fixed $m$, taking $T\to\infty$ makes $q_{T,m}\to\rho^{m+1}$. Apply Theorem 12.9. ∎

At unit weight $\rho=(3-\sqrt5)/2$. With no lookahead, the limiting minimax error is {{RISK0}} times the data diameter. For $T=4$, the exact errors as $m=0,1,2,3$ are $D(4/21,1/14,1/42,0)$. A guarantee of $0.01D$ for every horizon needs at least four later observations: the bounds at $m=3$ and $m=4$ are respectively {{RISK3}}$D$ and {{RISK4}}$D$. These decimal displays are rounded from rational brackets for $\sqrt5$ in the result file.

[[FIGURE4]]

**Proposition 12.11 (individual future weights need not increase).** Although the total future weight in Theorem 12.7 and the endpoint weight in Proposition 11.4 increase with $w$, an individual off-diagonal entry need not do so.

*Proof.* For a four-vertex path, direct inversion gives

$$
K_{12}(w)=\frac{w(1+3w+w^2)}{1+6w+10w^2+4w^3}.
\qquad\text{(12.15)}
$$

At $w=10$ this is $1310/5061>1/4$, whereas its limit as $w\to\infty$ is $1/4$. Hence it cannot be nondecreasing. It also starts at zero and is positive for $w>0$, so it cannot be nonincreasing. ∎

For the constant scalar sheaf on a path, $H^1=0$ because the path has no cycle. Nevertheless every off-diagonal harmonic weight is positive and the prefix risk above is nonzero. Thus absence of a cohomological obstruction does not certify nonanticipation. Cohomology, arithmetic enclosure and information access answer different questions.

## 12.4 Feasible clocks and checkable certificates

The interval clock calculation is a projection of one feasible set, not independent narrowing of unrelated dates. Write every constraint as $\tau_j-\tau_i\leq c_{ij}$, with origin $\tau_0=0$. Assume finite lower and upper dates for every event, so all-pairs distances are finite when the system is consistent.

**Theorem 12.12 (clock feasibility and attainable distance bounds).** A finite difference-constraint system is feasible if and only if its distance graph has no negative cycle. In a feasible system its shortest-path distances give the exact attainable bounds

$$
-d(b,a)\leq\tau_b-\tau_a\leq d(a,b),
\qquad
-d(v,0)\leq\tau_v\leq d(0,v).
\qquad\text{(12.16)}
$$

A feasible clock certifies consistency. A negative cycle, listed with its original constraint weights, certifies inconsistency.

*Proof.* Summing the inequalities around a negative cycle would give $0<0$, so no feasible clock can exist. Conversely, add a virtual source with zero-cost edges to all vertices. In the absence of a negative cycle, shortest distances from that source satisfy every edge inequality; subtracting the origin value makes $\tau_0=0$.

Every path from $a$ to $b$ bounds $\tau_b-\tau_a$ by its total cost, proving the upper distance bound; reverse the vertices for the lower bound. To prove attainment, fix any anchor $a$ and set $\pi_j^a=d(a,j)-d(a,0)$. The shortest-path triangle inequality gives $\pi_j^a-\pi_i^a\leq c_{ij}$, and $\pi_0^a=0$. Since $d(a,a)=0$, this feasible clock attains $\pi_b^a-\pi_a^a=d(a,b)$. The clock anchored at $b$ attains the lower bound. Taking an endpoint to be the origin gives the date windows. The two proposed certificates can be checked directly by substitution and cycle summation. ∎

This is the classical minimal-network result for simple temporal problems (Dechter et al., 1991), with explicit attainment witnesses. Each window is an exact marginal projection. Their Cartesian product need not be feasible: $\tau_1=\tau_2\in[0,1]$ gives two windows $[0,1]$, but the corner $(0,1)$ violates equality. Keeping only the windows loses a dependency in exactly the sense of Definition 12.1.

**Proposition 12.13 (uncertain constraint coefficients).** Suppose the upper bound on each difference constraint is independently uncertain, $c_e\in[\underline c_e,\overline c_e]$. Let $F(c)$ denote its feasible clock set. Then

$$
F(\underline c)\subseteq F(c)\subseteq F(\overline c).
\qquad\text{(12.17)}
$$

Some admissible coefficient choice is feasible exactly when $F(\overline c)$ is nonempty. Every admissible choice is feasible exactly when $F(\underline c)$ is nonempty; in that case a single clock works for all choices. If the upper system is inconsistent, all choices are inconsistent. If the lower is inconsistent and the upper is consistent, both feasible and infeasible choices occur.

*Proof.* Increasing any upper bound weakens a constraint, proving the inclusions. Both endpoint vectors belong to the coefficient box. These inclusions and endpoint membership give all the quantifier statements. ∎

These coefficient uncertainties are distinct from the unknown event times represented by date intervals. A useful robust inconsistency certificate is a cycle $C$ with $\sum_{e\in C}(c_e+\varepsilon_e)<0$: it remains negative under every perturbation $|\delta c_e|\leq\varepsilon_e$. The kernel example has original cycle cost $-1$ and total allowance $1/2$, leaving an upper cost $-1/2$.

**Proposition 12.14 (when point-date quantization creates a violation).** Write true times as $\tau_i=p_i+r_i$, with representative dates $p_i$ and residuals $0\leq r_i\leq w_i$. Suppose the true gap $g=\tau_j-\tau_i$ satisfies $L\leq g\leq U$. The representative gap violates the lower bound exactly when $r_j-r_i>g-L$, and violates the upper bound exactly when $r_i-r_j>U-g$.

*Proof.* Since $p_j-p_i=g+r_i-r_j$, subtract $L$ or $U$ and rearrange the strict inequalities. ∎

For example, $\tau_i=0.1$, $\tau_j=0.9$ and $L=0.5$ are feasible, while using the common start-of-year representative $p_i=p_j=0$ creates a false lower-lag violation. Point representatives can also happen to be feasible; positive period width does not by itself make every point calculation wrong. What fails is conservativity for every time in the reported period.

Calendar periods are usually half-open. The kernel uses their closed hulls, which contain the actual periods and are therefore conservative for non-strict difference constraints. An endpoint-only distinction can remain undecided in this representation. A complete treatment of strict calendar boundaries would require strict inequalities or an explicit boundary convention. The zero false interval contradictions in the 2,000-narrative study follow from the construction: each true clock belongs to its reported date hull and satisfies every generated lag. The order-certification rate is a useful measurement of that synthetic family; consistency itself is guaranteed by its design.

## 12.5 What an arithmetic certificate actually proves

Exact formulas, exact range algorithms and sound floating-point realization are separate requirements. The numerical work can distinguish them without claiming that line-by-line agreement verifies an unrestricted software API. Interval and verified numerical methods provide the general foundation (Moore et al., 2009; Rump, 2010).

**Lemma 12.15 (a dyadic budget for exact vertex evaluation).** Consider a path polynomial with at most $P$ monomials, each of length at most $h$. Suppose each vertex gain has form $a_e/2^q$, with $a_e$ an integer, $|a_e|\leq M$ and $q\geq0$. Let $C=\max(M,2^q)$. If

$$
P C^h<2^{53},
\qquad qh\leq1074,
\qquad\text{(12.18)}
$$

then evaluating the expanded path products and their sum in binary64 is exact, including every intermediate product and partial sum.

*Proof.* Put every path product on the common grid $2^{-qh}$. A product with $k\leq h$ factors has scaled numerator of magnitude at most $M^k2^{q(h-k)}\leq C^h$. The same bound holds for partial products after scaling them to this grid. Every partial sum has scaled numerator magnitude at most $P C^h$. These integers have fewer than 54 significant binary digits and their grid exponent is no smaller than $-1074$, so all the exact intermediate values are representable in binary64. The magnitude bound also excludes overflow. Correctly rounded multiplication and addition must return these representable exact results. ∎

For all 600 models of Table 2 one may take $q=3$, $M=14$, $h=6$ and $P=32$, since a seven-node ordered DAG has at most $2^5$ source-to-terminal paths. Thus $PC^h=240{,}945{,}152<2^{28}<2^{53}$ and $qh=18$. This proves exactness of every binary64 vertex oracle in that study, including the cases not covered by its 487 explicit rational repetitions. It does not prove that floating-point vertex enumeration is exact for general inputs.

The rational conversion in the earlier kernel required a correction. A dyadic rational need not be representable as a binary64 point, and converting its arbitrary-precision numerator and denominator separately can overflow before their ratio is taken. Moreover a containment predicate must compare with the rational itself, not its rounded approximation.

**Theorem 12.16 (adjacent binary64 brackets of an exact rational).** For a positive rational $q$ not exceeding the largest finite binary64 number, set

$$
e=\lfloor\log_2q\rfloor,\qquad
h=2^{\max(e-52,-1074)},\qquad
k=\lfloor q/h\rfloor.
\qquad\text{(12.19)}
$$

Compute the quotient and remainder by integer arithmetic. If the remainder is zero, return $[kh,kh]$. Otherwise return $[kh,(k+1)h]$. These are adjacent finite binary64 brackets containing $q$. Zero is exact and negative inputs are handled by reflection. Rationals beyond the finite range have no enclosure with two finite endpoints.

*Proof.* Above the subnormal range, $h$ is the binary64 spacing in the binade containing $q$; below it, $h=2^{-1074}$ is the subnormal spacing. The integer $k$ is less than $2^{53}$ and therefore converts exactly to binary64. Scaling by the specified power of two gives the exact representable number $kh$. Integer division proves $kh\leq q<(k+1)h$, with equality at the left exactly when the remainder is zero. At a binade boundary, $(k+1)h$ is the first value of the next binade and remains the successor of $kh$. Since $q$ does not exceed the largest finite number, a nonzero remainder cannot require an endpoint above that number. The corresponding statement for negative rationals follows by order-reversing reflection. ∎

The implementation obtains the binary exponent by exact integer bit lengths and a comparison, not a floating-point logarithm. It obtains the upper bracket with the next representable number. In particular, $2^{-1024}$ is representable, but the earlier conversion of its denominator $2^{1024}$ overflowed and returned the point zero. The earlier approximate containment predicate accepted that false enclosure. The new exact predicate rejects it. The smaller $2^{-1075}$ instead requires the bracket $[0,2^{-1074}]$. For $2^{2000}/(2^{2000}+1)$, integer bracketing returns the predecessor of one and one, avoiding an indeterminate ratio of two floating-point infinities. Nine independent rational checks cover these and other boundary cases.

**Proposition 12.17 (soundness of returned elementary intervals).** Assume correctly rounded binary64 elementary arithmetic with gradual underflow, finite ordered input endpoints, and a denominator interval excluding zero for division. If each endpoint operation is rounded outward by one predecessor or successor step and the routine returns finite ordered endpoints, the returned interval contains the exact real range of the elementary operation. Composition preserves containment of the occurrence-independent range, and therefore of every declared tied subset.

*Proof.* For any exact finite scalar result whose nearest-rounded value is finite, its predecessor and successor bracket that result. A returned finite interval excludes the overflow cases. Addition and subtraction use their exact endpoint extrema. Multiplication and division away from zero have extrema at the four corners. Correct rounding is monotone; taking the minimum and maximum of the rounded corner results and then widening brackets every exact corner result. Induction over the expression tree proves containment, and Theorem 12.2 supplies the final subset inclusion. ∎

The corrected finite-endpoint interval constructor rejects NaN, infinity and reversed endpoints. An overflow or an outward step beyond the finite format is an explicit rejection, not a certified numerical answer. This is a soundness statement for results that return, not a completeness claim for all real-valued expressions. The exact rational vertex routine also requires multi-affinity; both vertex routines now reject a non-multi-affine polynomial and reject the unsupported signed-mask dimension before enumeration. The single-event smoother returns $K=[1]$ and determinant one.

## 12.6 Consequences for a causal horizontal ASE layer

The results specify a computation policy for the existing mechanism sheaf. First, declare calibrated units and the identity of each uncertain parameter before forming residuals or intervals. A shared quantity is a shared variable point; its value is not duplicated merely because two contexts read it. Second, distinguish an exact range from an outward enclosure. A sign-coherence certificate permits the two-endpoint computation of Theorem 12.5; a small independent edge box permits exact vertex enumeration; otherwise a documented factorization or constrained relaxation gives an enclosure.

Third, attach a temporal access contract to the read. A retrospective harmonic smoother may use the complete history. A prefix read uses only permitted observations, and Theorem 12.9 quantifies the unavoidable discrepancy from that retrospective target under a declared completion box. Fourth, retain the constraint graph and certificate when returning a clock window; the windows alone forget correlations. A negative cycle is an explanation of infeasibility, while a feasible clock is a witness of consistency.

These are horizontal computations on local information and its overlaps. Physical clock order remains separate from the ASE layer order and the other bases of Section 9. A token still carries a vertical fibre diagram; a stalk remains a data space. Changes of base still use the sheaf inverse image $\Phi_t^{-1}$ and commuting squares. Neither a tighter interval nor a successful numerical check relaxes those representation requirements.

The executed evidence comprises the original 71 independently checked output lines and 27 additional lines, for 98 in total. A separate exact Python calculation checks 15 weighted resolvent cases. All checks pass. Section 12 supplies the proofs; the finite checks establish that the reported implementations and examples agree under their stated contracts.

[[TABLE6]]
