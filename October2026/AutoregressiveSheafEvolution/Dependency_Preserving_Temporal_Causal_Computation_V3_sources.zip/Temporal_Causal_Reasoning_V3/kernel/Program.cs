// Driver: exact constructions, outward enclosures and separately identified floating-point summaries.
// Lines are "name<TAB>values"; validate.py recomputes each line independently.
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Globalization;
using System.IO;
using System.Linq;
using Tcr;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
var outDir = args.Length > 0 ? args[0] : ".";
Directory.CreateDirectory(outDir);
string Fmt(object x) => x switch
{
    double d => d.ToString("R", CultureInfo.InvariantCulture),
    bool b => b ? "1" : "0",
    string str => str,
    System.Collections.IEnumerable e => string.Join(" ", e.Cast<object>().Select(Fmt)),
    _ => x.ToString() ?? ""
};
void Out(string name, params object[] v) => Console.WriteLine(name + "\t" + string.Join(" ", v.Select(Fmt)));
ImmutableArray<Q> Vq(params Q[] q) => q.ToImmutableArray();
var noDo = ImmutableDictionary<int, Q>.Empty;

// ---------------------------------------------------------------- Section 10.1: the diamond
var bD = QMat.Of(4, 4, (i, j) => (i, j) switch { (1, 0) => 2, (2, 0) => 1, (3, 1) => 3, (3, 2) => 4, _ => Q.Zero });
var scm = new LinearScm(bD);
var u0 = Vq(1, 0, 0, 0);
Out("diamond_factual", scm.Solve(u0, noDo).ToArray());
Out("diamond_do_x2_eq_3", scm.Solve(u0, noDo.Add(1, 3)).ToArray());
Out("diamond_do_x1_eq_2", scm.Solve(u0, noDo.Add(0, 2)).ToArray());
var r0 = scm.Resolvent(Array.Empty<int>()); var r2 = scm.Resolvent(new[] { 1 });
Out("diamond_routes_and_total", bD[3, 1] * bD[1, 0], bD[3, 2] * bD[2, 0], r0[3, 0]);
Out("diamond_R_last_row", Enumerable.Range(0, 4).Select(j => r0[3, j]).ToArray());
Out("diamond_RD_last_row_do2", Enumerable.Range(0, 4).Select(j => r2[3, j]).ToArray());
Out("diamond_RDPC_last_row_do2", Enumerable.Range(0, 4).Select(j => j == 1 ? Q.Zero : r2[3, j]).ToArray());
bool pathEq = Enumerable.Range(0, 16).All(k => r0[k / 4, k % 4] == scm.PathSum(Array.Empty<int>())[k / 4, k % 4])
    && Enumerable.Range(0, 16).All(k => r2[k / 4, k % 4] == scm.PathSum(new[] { 1 })[k / 4, k % 4]);
Out("diamond_inverse_equals_pathsum", pathEq);
// Theorem 6.1 difference identity for do(x2 = 3)
{
    var x = scm.Solve(u0, noDo); var xd = scm.Solve(u0, noDo.Add(1, 3));
    var dvec = Vq(0, 3, 0, 0);
    var rhs = Enumerable.Range(0, 4).Select(i => Enumerable.Range(0, 4).Aggregate(Q.Zero, (s, j) => s + r2[i, j] * (j == 1 ? dvec[j] - x[j] : Q.Zero))).ToArray();
    Out("diamond_difference_identity", Enumerable.Range(0, 4).All(i => xd[i] - x[i] == rhs[i]));
}
// Theorem 8.1 numbers
{
    Q eta = Q.Of(1, 100), w1 = Q.Of(2, 100);
    Q mech0 = Enumerable.Range(0, 4).Aggregate(Q.Zero, (s, j) => s + r0[3, j] * eta);
    Q post0 = Enumerable.Range(0, 4).Select(j => r0[3, j]).Aggregate(Q.Max) * w1;
    Q mech2 = Enumerable.Range(0, 4).Aggregate(Q.Zero, (s, j) => s + r2[3, j] * (j == 1 ? Q.Zero : eta));
    Q post2 = Enumerable.Range(0, 4).Where(j => j != 1).Select(j => r2[3, j]).Aggregate(Q.Max) * w1;
    Out("bound_no_intervention", mech0, post0, mech0 + post0);
    Out("bound_do_node2", mech2, post2, mech2 + post2);
}
// Clock (Theorem 3.2, Corollary 3.3)
{
    var edges = ImmutableArray.Create<(int, int, Q)>((0, 1, 2), (0, 2, 1), (1, 3, 3), (2, 3, 4));
    var c1 = Clock.Earliest(4, edges, Vq(0, 0, 0, 0), Vq(0, 3, 2, 8));
    Out("clock_earliest", c1.E.ToArray()); Out("clock_feasible_h8", c1.Feasible);
    var c2 = Clock.Earliest(4, edges, Vq(0, 0, 0, 0), Vq(0, 3, 2, 4));
    Out("clock_feasible_h4", c2.Feasible); Out("clock_witness_h4", c2.Witness.Select(v => v + 1).ToArray());
    // the same contradiction as a negative cycle of the temporal network
    var stn = Stn.Build(4, Enumerable.Range(0, 4).Select(v => (v + 1, Q.Zero, new[] { Q.Zero, 3, 2, 4 }[v])),
        edges.Select(e => (e.Item1 + 1, e.Item2 + 1, e.Item3, (Q?)null)));
    var cyc = stn.NegativeCycle();
    var cycLen = cyc.Zip(cyc.Skip(1), (i, j) => stn.Cons.Where(c => c.I == i && c.J == j).Select(c => c.C).Aggregate(Q.Min)).Aggregate(Q.Zero, (s, c) => s + c);
    Out("stn_diamond_h4_consistent", Stn.Consistent(stn.Distances())); Out("stn_negative_cycle", string.Join(">", cyc), cycLen);
    // upper lags: a window on x4 tightened by lags in both directions
    var stn2 = Stn.Build(4, new[] { (1, Q.Zero, Q.Zero), (2, Q.Zero, (Q)3), (3, Q.Zero, (Q)2), (4, Q.Zero, (Q)8) },
        new[] { (1, 2, (Q)2, (Q?)Q.Of(5, 2)), (1, 3, (Q)1, (Q?)Q.Of(3, 2)), (2, 4, (Q)3, (Q?)4), (3, 4, (Q)4, (Q?)Q.Of(9, 2)) });
    var d2 = stn2.Distances();
    Out("stn_diamond_upper_lags_consistent", Stn.Consistent(d2));
    Out("stn_diamond_upper_lags_windows", Enumerable.Range(1, 4).SelectMany(v => { var w = Stn.Window(d2, v); return new object[] { w.Lo, w.Hi }; }).ToArray());
}

// ---------------------------------------------------------------- exact finite checks of Sections 2, 5, 7, 9, 10
{
    // Proposition 2.4: C = A xor B
    var rel = (from a in new[] { 0, 1 } from b in new[] { 0, 1 } select (a, b, c: a ^ b)).ToList();
    int pAB = rel.Select(t => (t.a, t.b)).Distinct().Count(), pAC = rel.Select(t => (t.a, t.c)).Distinct().Count(), pBC = rel.Select(t => (t.b, t.c)).Distinct().Count();
    int accepted = (from a in new[] { 0, 1 } from b in new[] { 0, 1 } from c in new[] { 0, 1 }
                    where rel.Any(t => t.a == a && t.b == b) && rel.Any(t => t.a == a && t.c == c) && rel.Any(t => t.b == b && t.c == c) select 1).Count();
    Out("xor_pairwise_projection_sizes", pAB, pAC, pBC); Out("xor_binary_closure_vs_relation", accepted, rel.Count);
    // Theorem 5.3: models A (Y = X) and B (Y = U), X = U, U fair
    Q half = Q.Of(1, 2);
    var obsA = new[] { (0, 0), (1, 1) }; var obsB = new[] { (0, 0), (1, 1) };
    Q pY0doA = 1; Q pY0doB = half;   // do(X=0): A gives Y = 0; B gives Y = U
    Out("thm53_same_observational_support", obsA.SequenceEqual(obsB)); Out("thm53_P_Y0_do_X0_A_B", pY0doA, pY0doB);
    // Proposition 5.5: C (Y = UY) and D (Y = UY xor X); all four interventional regimes agree
    Q PY(int model, int? doX, int? doY, int y) => (from ux in new[] { 0, 1 } from uy in new[] { 0, 1 }
        let xx = doX ?? ux let yy = doY ?? (model == 0 ? uy : uy ^ xx) where yy == y select Q.Of(1, 4)).Aggregate(Q.Zero, (s, p) => s + p);
    bool allAgree = new int?[] { null, 0, 1 }.All(dx => new int?[] { null, 0, 1 }.All(dy => PY(0, dx, dy, 1) == PY(1, dx, dy, 1)));
    // evidence X = 0, Y = 0 gives UY = 0 in both; counterfactual under do(X = 1)
    Out("prop55_interventions_agree", allAgree); Out("prop55_counterfactual_Y_C_D", 0, 0 ^ 1);
    // Section 7.1 example
    var k2 = Smoother.K(2, 1);
    Out("smoother_T2_w1", k2[0, 0], k2[0, 1], k2[1, 0], k2[1, 1]);
    // Section 10.2
    Q a102 = 2, x102 = 1, y102 = 4, d102 = 3;
    Out("cf_10_2_counterfactual_population", y102 + a102 * (d102 - x102), a102 * d102);
    // Section 10.3: constancy on encoded parent fibres
    bool idFails = !new[] { 0, 1 }.GroupBy(x => 0).All(g => g.Select(x => x).Distinct().Count() == 1);   // h_X collapses {0,1}; encoded child Y = X differs
    bool parityOk = Enumerable.Range(0, 4).GroupBy(x => x % 2).All(g => g.Select(x => x % 2).Distinct().Count() == 1);
    Out("compression_identity_fails_parity_holds", idFails, parityOk);
}

// ---------------------------------------------------------------- Theorem 4.4 in exact arithmetic
{
    var inputs = ImmutableArray.Create(
        ImmutableArray.Create<(int, Q)>((4, 1)),
        ImmutableArray.Create<(int, Q)>((0, 2), (5, 1)),
        ImmutableArray.Create<(int, Q)>((0, 1), (6, 1)),
        ImmutableArray.Create<(int, Q)>((1, 3), (2, 4), (7, 1)));
    var h = IncidenceSheaf.Cohomology(4, 4, inputs);
    Out("cohomology_diamond", h.C0, h.C1, h.Rank, h.H0, h.H1, h.Vertices, h.EdgesN, h.ConstantH1);
    var rng = new Rng(20261030); int count = 0, h0ok = 0, h1zero = 0, maxBetti = 0, withCycles = 0; long bettiSum = 0;
    for (int m = 0; m < 300; m++)
    {
        int n, q, shared; (n, rng) = rng.Int(2, 9); (shared, rng) = rng.Int(0, 2); q = n + shared;
        var inp = new List<ImmutableArray<(int, Q)>>();
        for (int v = 0; v < n; v++)
        {
            var list = new List<(int, Q)>();
            for (int w = 0; w < v; w++) { double p; (p, rng) = rng.Uniform(); if (p < 0.4) { int k; (k, rng) = rng.Int(-8, 8); list.Add((w, Q.Of(k, 4))); } }
            list.Add((n + v, 1));
            for (int s = 0; s < shared; s++) { double p; (p, rng) = rng.Uniform(); if (p < 0.5) { int k; (k, rng) = rng.Int(-8, 8); list.Add((n + n + s, Q.Of(k, 4))); } }
            inp.Add(list.ToImmutableArray());
        }
        var hh = IncidenceSheaf.Cohomology(n, q, inp.ToImmutableArray());
        count++; if (hh.H0 == q) h0ok++; if (hh.H1 == 0) h1zero++;
        maxBetti = Math.Max(maxBetti, hh.ConstantH1); bettiSum += hh.ConstantH1; if (hh.ConstantH1 > 0) withCycles++;
    }
    Out("cohomology_random_models", count, h0ok, h1zero, withCycles, maxBetti, (double)bettiSum / count);
}

// ---------------------------------------------------------------- Section 11.1: interval gains and symbolic path polynomials
{
    // the diamond with interval gains; symbols 0:a(2<-1) 1:c(3<-1) 2:b(4<-2) 3:d(4<-3)
    var dag = new SymbolicDag(4, ImmutableArray.Create((1, 0), (2, 0), (3, 1), (3, 2)));
    var box = new Dictionary<int, (Q, Q)> { [0] = (Q.Of(3, 2), Q.Of(5, 2)), [1] = (Q.Of(1, 2), Q.Of(3, 2)), [2] = (Q.Of(5, 2), Q.Of(7, 2)), [3] = (Q.Of(7, 2), Q.Of(9, 2)) };
    var f = dag.Forward(0)[3]; var p = f.ToPoly();
    var ex = Vertex.Range(p, v => box[v]);
    Out("diamond_path_polynomial", p.ToString());
    Out("diamond_interval_forward", f.Eval(v => Iv.Of(box[v].Item1, box[v].Item2)));
    Out("diamond_interval_exact", ex.Lo, ex.Hi);
    // shared prefix: 0:a(2<-1) 1:b(3<-2) 2:c(4<-2) 3:d(4<-3)
    var sp = new SymbolicDag(4, ImmutableArray.Create((1, 0), (2, 1), (3, 1), (3, 2)));
    var bx = new Dictionary<int, (Q, Q)> { [0] = (Q.Of(1, 2), Q.Of(3, 2)), [1] = (-1, 1), [2] = (1, 2), [3] = (1, 2) };
    var fs = sp.Forward(0)[3]; var ps = fs.ToPoly(); var es = Vertex.Range(ps, v => bx[v]);
    Iv Ivb(int v) => Iv.Of(bx[v].Item1, bx[v].Item2);
    Out("prefix_path_polynomial", ps.ToString());
    Out("prefix_interval_forward", fs.Eval(Ivb)); Out("prefix_interval_expanded", Expr.Expanded(ps).Eval(Ivb));
    Out("prefix_interval_horner", Expr.Horner(ps).Eval(Ivb)); Out("prefix_interval_exact", es.Lo, es.Hi);
    Out("prefix_occurrences_forward_horner", fs.MaxOccurrence(ps.Vars), Expr.Horner(ps).MaxOccurrence(ps.Vars));
}

// random DAG study
{
    using var csv = new StreamWriter(Path.Combine(outDir, "dag_study.csv"));
    csv.WriteLine("regime,instance,edges,paths,forward_ratio,expanded_ratio,horner_ratio,exact_lo,exact_hi");
    foreach (var (regime, kLo, kHi, seed) in new[] { ("mixed", -8, 8, 20261101UL), ("positive", 4, 12, 20261102UL) })
    {
        var rng = new Rng(seed); int n = 7, accepted = 0, tries = 0, multilinear = 0, contained = 0, qchecked = 0, qagree = 0;
        var fr = new List<double>(); var er = new List<double>(); var hr = new List<double>(); var nE = new List<int>(); var nP = new List<long>();
        while (accepted < 300)
        {
            tries++;
            var edges = new List<(int, int)>(); var gain = new List<(Q, Q)>();
            for (int v = 1; v < n; v++) for (int w = 0; w < v; w++)
            {
                double pr; (pr, rng) = rng.Uniform(); if (pr >= 0.45) continue;
                int k; (k, rng) = rng.Int(kLo, kHi); edges.Add((v, w)); gain.Add((Q.Of(k, 8) - Q.Of(1, 4), Q.Of(k, 8) + Q.Of(1, 4)));
            }
            var dag = new SymbolicDag(n, edges.ToImmutableArray());
            long paths = dag.PathCount(0, n - 1); if (paths < 2) continue;
            var f = dag.Forward(0)[n - 1]; var p = f.ToPoly(); var vars = p.Vars.ToArray();
            if (vars.Length > 14) continue;
            accepted++;
            if (p.MaxDegreeInAnyVar <= 1) multilinear++;
            Iv X(int v) => Iv.Of(gain[v].Item1, gain[v].Item2);
            var exact = Vertex.RangeD(p, v => (gain[v].Item1.ToDouble(), gain[v].Item2.ToDouble()));
            if (vars.Length <= 9)
            {
                qchecked++; var eq = Vertex.Range(p, v => gain[v]);
                if (eq.Lo.ToDouble() == exact.Lo && eq.Hi.ToDouble() == exact.Hi) qagree++;
            }
            var (fi, ei, hi) = (f.Eval(X), Expr.Expanded(p).Eval(X), Expr.Horner(p).Eval(X));
            if (new[] { fi, ei, hi }.All(iv => iv.Lo <= exact.Lo && iv.Hi >= exact.Hi)) contained++;
            double wid = exact.Hi - exact.Lo;
            fr.Add(fi.Width / wid); er.Add(ei.Width / wid); hr.Add(hi.Width / wid); nE.Add(vars.Length); nP.Add(paths);
            csv.WriteLine($"{regime},{accepted},{vars.Length},{paths},{fi.Width / wid:R},{ei.Width / wid:R},{hi.Width / wid:R},{exact.Lo:R},{exact.Hi:R}");
        }
        double Med(List<double> x) { var s = x.OrderBy(t => t).ToArray(); return 0.5 * (s[(s.Length - 1) / 2] + s[s.Length / 2]); }
        double Sharp(List<double> x) => x.Count(t => t <= 1 + 1e-9) / (double)x.Count;
        Out($"dag_{regime}_counts", accepted, tries, multilinear, contained, qchecked, qagree, nE.Average(), nP.Average(), nP.Max());
        Out($"dag_{regime}_forward", Med(fr), fr.Average(), fr.Max(), Sharp(fr));
        Out($"dag_{regime}_expanded", Med(er), er.Average(), er.Max(), Sharp(er));
        Out($"dag_{regime}_horner", Med(hr), hr.Average(), hr.Max(), Sharp(hr));
    }
}

// ---------------------------------------------------------------- Section 11.2: counterfactual intervals
{
    // symbols 0:a 1:x 2:y ; d = 3
    var bx = new Dictionary<int, (Q, Q)> { [0] = (Q.Of(19, 10), Q.Of(21, 10)), [1] = (Q.Of(19, 20), Q.Of(21, 20)), [2] = (Q.Of(39, 10), Q.Of(41, 10)) };
    Iv X(int v) => Iv.Of(bx[v].Item1, bx[v].Item2);
    Expr a = new Expr.V(0), x = new Expr.V(1), y = new Expr.V(2), three = new Expr.C(3), one = new Expr.C(1);
    var single = Expr.Add(y, Expr.Mul(a, Expr.Add(three, Expr.Neg(x))));
    var stepwise = Expr.Add(Expr.Mul(a, three), x, Expr.Add(y, Expr.Neg(Expr.Mul(Expr.Add(a, one), x))));
    var p = single.ToPoly(); bool same = p.Equal(stepwise.ToPoly());
    var ex = Vertex.Range(p, v => bx[v]);
    Out("cf_interval_forms_equal", same);
    Out("cf_interval_exact", ex.Lo, ex.Hi);
    Out("cf_interval_single_use", single.Eval(X));
    Out("cf_interval_stepwise", stepwise.Eval(X));
    Out("cf_interval_expanded", Expr.Expanded(p).Eval(X));
    Out("cf_interval_population_mean", Expr.Mul(a, three).Eval(X));
    // resampled circumstances: U and eps from independent copies of the evidence box
    var resampled = Expr.Add(Expr.Mul(a, three), new Expr.V(3), Expr.Add(new Expr.V(4), Expr.Neg(Expr.Mul(Expr.Add(new Expr.V(5), one), new Expr.V(6)))));
    Out("cf_interval_decoupled_worlds", resampled.Eval(v => v switch { 3 => X(1), 4 => X(2), 5 => X(0), 6 => X(1), _ => X(v) }));
}

// ---------------------------------------------------------------- Section 11.3: symbolic anticipation of the harmonic read
foreach (int t in new[] { 2, 3, 4, 5, 6, 8 })
{
    var det = Smoother.Det(t); var coef = det.Coefficients(0);
    Q K1T(Q w) => Enumerable.Range(0, t - 1).Aggregate(Q.One, (s, _) => s * w) / det.Eval(_ => w);
    bool agree = new[] { Q.One, Q.Of(1, 2), (Q)2 }.All(w => Smoother.K(t, w)[0, t - 1] == K1T(w) && Smoother.K(t, w)[t - 1, 0] == K1T(w));
    var k1 = Smoother.K(t, 1);
    // K_1T(w) = 1 / sum_j c_(T-1-j) w^(-j): every term is nonincreasing in w, so K_1T is
    // nondecreasing and its exact range over [1/2, 2] is [K_1T(1/2), K_1T(2)].
    bool monotoneForm = coef.All(c => c.Sign >= 0) && coef.Length == t;
    Out($"smoother_T{t}", string.Join(",", coef), agree, K1T(1), Q.One - k1[0, 0], K1T(Q.Of(1, 2)), K1T(2), monotoneForm, coef[t - 1]);
}
{
    // Fibonacci identities at w = 1: det(I + L_T) = F_2T, K_1T = 1/F_2T, 1 - K_11 = F_(2T-2)/F_2T
    var fib = new List<Q> { 0, 1 }; while (fib.Count < 70) fib.Add(fib[^1] + fib[^2]);
    bool ok = Enumerable.Range(2, 29).All(t =>
    {
        var k = Smoother.K(t, 1);
        return Smoother.Det(t).Eval(_ => 1) == fib[2 * t] && k[0, t - 1] == Q.One / fib[2 * t] && Q.One - k[0, 0] == fib[2 * t - 2] / fib[2 * t];
    });
    var k30 = Smoother.K(30, 1);
    Out("smoother_fibonacci_T2_to_30", ok, (Q.One - k30[0, 0]).ToDouble(), (3 - Math.Sqrt(5)) / 2, k30[0, 29].ToDouble());
}

// ---------------------------------------------------------------- Section 11.4: year-granularity dates
{
    var rng = new Rng(20261103); int narratives = 2000, n = 6;
    int pointFalse = 0, stnConsistent = 0, stnTruthInside = 0, sameYearPairs = 0, sameYearCertified = 0, orderWrong = 0, pointTies = 0, pairs = 0, certifiedAll = 0;
    Q widthDeclared = 0, widthMinimal = 0;
    for (int s = 0; s < narratives; s++)
    {
        var tau = new Q[n + 1]; int k0; (k0, rng) = rng.Int(0, 143); tau[1] = 2000 + Q.Of(k0, 48);
        for (int v = 2; v <= n; v++) { int k; (k, rng) = rng.Int(0, 38); tau[v] = tau[v - 1] + Q.Of(k, 48); }
        var lags = new List<(int, int, Q, Q?)>();
        for (int v = 2; v <= n; v++) for (int w = 1; w < v; w++)
        {
            double pr; (pr, rng) = rng.Uniform(); if (pr >= 0.5) continue;
            Q lag = tau[v] - tau[w], dmin = Q.Floor(lag * 4) / 4; double pu; (pu, rng) = rng.Uniform();
            lags.Add((w, v, dmin, pu < 0.5 ? dmin + Q.Of(1, 2) : (Q?)null));
        }
        var dates = new List<(int, Q, Q)>(); var point = new Q[n + 1];
        for (int v = 1; v <= n; v++)
        {
            double pm; (pm, rng) = rng.Uniform();
            if (pm < 0.7) { var yv = Q.Floor(tau[v]); dates.Add((v, yv, yv + 1)); point[v] = yv; }
            else { var mo = Q.Floor(tau[v] * 12) / 12; dates.Add((v, mo, mo + Q.Of(1, 12))); point[v] = mo; }
        }
        bool pointOk = lags.All(l => point[l.Item2] - point[l.Item1] >= l.Item3 && (l.Item4 is not Q mx || point[l.Item2] - point[l.Item1] <= mx));
        if (!pointOk) pointFalse++;
        var stn = Stn.Build(n, dates, lags); var dist = stn.Distances();
        if (!Stn.Consistent(dist)) continue;
        stnConsistent++;
        if (Enumerable.Range(1, n).All(v => { var w = Stn.Window(dist, v); return w.Lo <= tau[v] && tau[v] <= w.Hi; })) stnTruthInside++;
        for (int v = 1; v <= n; v++) { widthDeclared += dates[v - 1].Item3 - dates[v - 1].Item2; var w = Stn.Window(dist, v); widthMinimal += w.Hi - w.Lo; }
        for (int a = 1; a <= n; a++) for (int b = a + 1; b <= n; b++)
        {
            if (tau[a] == tau[b]) continue;
            pairs++;
            bool certAB = Stn.MinGap(dist, a, b) is Q g1 && g1.Sign > 0, certBA = Stn.MinGap(dist, b, a) is Q g2 && g2.Sign > 0;
            if ((certAB && tau[b] < tau[a]) || (certBA && tau[a] < tau[b])) orderWrong++;
            if (certAB || certBA) certifiedAll++;
            if (point[a] == point[b]) pointTies++;
            if (dates[a - 1].Item2 == dates[b - 1].Item2 && dates[a - 1].Item3 == dates[b - 1].Item3)
            { sameYearPairs++; if (certAB || certBA) sameYearCertified++; }
        }
    }
    Out("year_study_narratives_point_false_contradictions", narratives, pointFalse);
    Out("year_study_interval_consistent_truth_inside", stnConsistent, stnTruthInside);
    Out("year_study_pairs_certified_wrong", pairs, certifiedAll, orderWrong, pointTies);
    Out("year_study_identical_boxes_certified", sameYearPairs, sameYearCertified);
    Out("year_study_mean_width_declared_minimal", (widthDeclared / (narratives * n)).ToDouble(), (widthMinimal / (narratives * n)).ToDouble());
}

// ---------------------------------------------------------------- Section 11.5: the multiplicative mask of Yang et al. (2026), Eq. (9)
{
    int lc = 2, nq = 3, L = lc + nq, target = lc + 1;   // 0-based positions; target = second query token
    double M(int i, int j) => (i < lc && j < lc) || (i >= lc && j < lc) || (i >= lc && j >= lc && j <= i) ? 0.0 : double.NegativeInfinity;
    double Ind(bool b) => b ? 1.0 : 0.0;
    var mult = Enumerable.Range(0, L * L).Select(k => M(k / L, k % L) * Ind(k / L != target) * Ind(k % L != target)).ToArray();
    var assign = Enumerable.Range(0, L * L).Select(k => k / L == target || k % L == target ? double.NegativeInfinity : M(k / L, k % L)).ToArray();
    double[] Softmax(double[] row) { double m = row.Max(); var e = row.Select(z => Math.Exp(z - m)).ToArray(); double s = e.Sum(); return e.Select(z => z / s).ToArray(); }
    int nanLogits = mult.Count(double.IsNaN);
    int keptOpen = Enumerable.Range(0, L * L).Count(k => (k / L == target || k % L == target) && mult[k] == 0.0);
    var rowsMult = Enumerable.Range(0, L).Select(i => Softmax(mult.Skip(i * L).Take(L).ToArray())).ToArray();
    var rowsAssign = Enumerable.Range(0, L).Select(i => Softmax(assign.Skip(i * L).Take(L).ToArray())).ToArray();
    Out("mask_eq9_nan_logits_open_entries", nanLogits, keptOpen);
    Out("mask_eq9_nan_rows", rowsMult.Count(r => r.Any(double.IsNaN)));
    Out("mask_eq9_weight_last_query_on_target", rowsMult[L - 1][target]);
    Out("mask_assign_nan_rows_weight_on_target", rowsAssign.Count(r => r.Any(double.IsNaN)), rowsAssign[L - 1][target]);
    // a finite fill value (a common implementation of -inf) turns Eq. (9) into reopening
    const double fill = -1e9;
    double Mf(int i, int j) => double.IsNegativeInfinity(M(i, j)) ? fill : 0.0;
    var multF = Enumerable.Range(0, L * L).Select(k => Mf(k / L, k % L) * Ind(k / L != target) * Ind(k % L != target)).ToArray();
    int reopened = Enumerable.Range(0, L * L).Count(k => M(k / L, k % L) < 0 && multF[k] == 0.0);
    var rowsF = Enumerable.Range(0, L).Select(i => Softmax(multF.Skip(i * L).Take(L).ToArray())).ToArray();
    Out("mask_eq9_finite_fill_reopened_weights", reopened, rowsF[L - 1][target], rowsF[target][L - 1], rowsF[0][target]);
}

// Version 3 exact checks of the additional mathematical statements.
V3Checks.Run((name, values) => Out(name, values));
