// Finite exact constructions for Section 12. They illustrate the proofs; they are not learning benchmarks.
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Numerics;

namespace Tcr;

public static class V3Checks
{
    static Q Pow(Q x, int n) => Enumerable.Range(0, n).Aggregate(Q.One, (a, _) => a * x);
    static bool Throws<T>(Action f) where T : Exception { try { f(); return false; } catch (T) { return true; } }
    public static void Run(Action<string, object[]> emit)
    {
        void Out(string name, params object[] values) => emit("v3_" + name, values);
        var cases = new (string Name, Q Value)[] {
            ("subnormal_exact", new Q(1, BigInteger.One << 1024)),
            ("half_min_subnormal", new Q(1, BigInteger.One << 1075)),
            ("min_subnormal", new Q(1, BigInteger.One << 1074)),
            ("one_third", Q.Of(1,3)),
            ("huge_near_one", new Q(BigInteger.One << 2000, (BigInteger.One << 2000) + 1)),
            ("negative_tiny", new Q(-1, BigInteger.One << 1075)),
            ("midpoint_above_one", new Q((BigInteger.One << 53) + 1, BigInteger.One << 53)),
            ("normal_boundary", new Q((BigInteger.One << 53) - 1, BigInteger.One << 1075)),
            ("max_finite", Q.FromDouble(double.MaxValue))
        };
        foreach (var (name, q) in cases)
        {
            var a = Iv.Of(q);
            Out("bracket_" + name, a.Lo, a.Hi, a.Contains(q), a.Lo == a.Hi || Math.BitIncrement(a.Lo) == a.Hi);
        }
        var small = cases[0].Value;
        Out("old_dyadic_shortcut", small.ToDouble(), Iv.Point(0).Contains(small), 0.0 <= small.ToDouble() && small.ToDouble() <= 0.0);
        Out("interval_rejection", Throws<OverflowException>(() => Iv.Of(new Q(BigInteger.One << 1024, 1))),
            Throws<ArgumentOutOfRangeException>(() => Iv.Point(double.NaN)),
            Throws<ArgumentOutOfRangeException>(() => new Iv(2, 1)),
            Throws<ArgumentOutOfRangeException>(() => { _ = Iv.Point(double.MaxValue) * Iv.Point(2); }));
        var nonlinear = Poly.Var(0) * Poly.Var(0);
        var many = Enumerable.Range(0, 63).Select(Poly.Var).Aggregate(Poly.Zero, (a,b) => a+b);
        Out("vertex_guards", Throws<ArgumentException>(() => Vertex.Range(nonlinear, _ => (Q.Zero,Q.One))),
            Throws<ArgumentException>(() => Vertex.RangeD(nonlinear, _ => (0.0,1.0))),
            Throws<ArgumentOutOfRangeException>(() => Vertex.Range(many, _ => (Q.Zero,Q.One))),
            Throws<ArgumentOutOfRangeException>(() => Vertex.RangeD(many, _ => (0.0,1.0))));
        Out("single_time_smoother", Smoother.K(1, 1)[0,0], Smoother.Det(1).Eval(_ => 1));

        int graphs = 0, reductionOk = 0;
        for (int n = 2; n <= 4; n++)
        {
            var all = (from i in Enumerable.Range(0,n) from j in Enumerable.Range(i+1,n-i-1) select (i,j)).ToArray();
            for (int graph = 0; graph < (1 << all.Length); graph++)
            {
                var edges = all.Where((_,k) => (graph & (1 << k)) != 0).ToArray();
                int maxCut = 0, maximum = int.MinValue, minimum = int.MaxValue;
                for (int xm = 0; xm < (1 << n); xm++)
                {
                    var x = Enumerable.Range(0,n).Select(i => ((xm >> i)&1)==0 ? -1 : 1).ToArray();
                    maxCut = Math.Max(maxCut, edges.Count(e => x[e.i] != x[e.j]));
                    for (int ym = 0; ym < (1 << edges.Length); ym++)
                    {
                        // The four-layer DAG: source, vertex variables, edge nodes, sink.
                        var r = new int[n + edges.Length + 2]; r[0] = 1;
                        for (int i = 0; i < n; i++) r[i+1] = x[i] * r[0];
                        for (int e = 0; e < edges.Length; e++) r[n+1+e] = r[edges[e].i+1] - r[edges[e].j+1];
                        for (int e = 0; e < edges.Length; e++) r[^1] += (((ym >> e)&1)==0 ? -1 : 1) * r[n+1+e];
                        maximum = Math.Max(maximum, r[^1]); minimum = Math.Min(minimum, r[^1]);
                    }
                }
                graphs++; if (maximum == 2*maxCut && minimum == -2*maxCut) reductionOk++;
            }
        }
        Out("maxcut_reduction", graphs, reductionOk);
        Out("triangle_response_range", -4, 4);

        var dag = new SymbolicDag(6, ImmutableArray.Create((1,0),(2,1),(3,1),(4,2),(4,3),(5,4),(5,0)));
        foreach (Q eps in new[] { Q.Of(1,100), Q.Of(1,1000000) })
        {
            (Q,Q) Box(int k) => k switch { 0 or 5 => (-1,1), 1 or 3 or 4 => (1,1), 2 => (-1,-1), 6 => (-eps,eps), _ => throw new Exception() };
            var expression = dag.Forward(0)[5]; var exact = Vertex.Range(expression.ToPoly(), Box);
            var outer = expression.Eval(k => Iv.Of(Box(k).Item1, Box(k).Item2));
            Out(eps == Q.Of(1,100) ? "cancellation_100" : "cancellation_million", exact.Lo, exact.Hi,
                outer.Lo, outer.Hi, Q.One + 2/eps);
        }
        Out("tied_parameter_values", Q.Zero, Q.Of(1,4), Q.Zero);

        var rng = new Rng(2026103003UL); int signedModels = 0, cornerExact = 0, signedEnclosed = 0;
        for (int instance = 0; instance < 16; instance++)
        {
            const int n = 5; var signs = new int[n]; signs[0] = 1;
            for (int i = 1; i < n; i++) { int k; (k,rng)=rng.Int(0,1); signs[i]=k==0?-1:1; }
            var edges = new List<(int,int)>(); var gain = new List<(Q,Q)>(); var sigma = new List<int>();
            for (int v = 1; v < n; v++) for (int w = 0; w < v; w++)
            {
                bool keep = w == v-1;
                if (!keep) { double u; (u,rng)=rng.Uniform(); keep=u<0.4; }
                if (!keep) continue;
                int k; (k,rng)=rng.Int(1,4); Q a=Q.Of(k,4),b=Q.Of(k+1,4); int sg=signs[v]*signs[w];
                edges.Add((v,w)); sigma.Add(sg); gain.Add(sg>0?(a,b):(-b,-a));
            }
            var sd = new SymbolicDag(n,edges.ToImmutableArray()); var expr=sd.Forward(0)[n-1];var poly=expr.ToPoly();
            var ex=Vertex.Range(poly,k=>gain[k]);
            Q c0=poly.Eval(k=>sigma[k]>0?gain[k].Item1:gain[k].Item2), c1=poly.Eval(k=>sigma[k]>0?gain[k].Item2:gain[k].Item1);
            if(ex.Lo==Q.Min(c0,c1)&&ex.Hi==Q.Max(c0,c1))cornerExact++;
            var iv=expr.Eval(k=>Iv.Of(gain[k].Item1,gain[k].Item2));
            if(iv.Contains(ex.Lo)&&iv.Contains(ex.Hi))signedEnclosed++;
            signedModels++;
        }
        Out("sign_coherent_models",signedModels,cornerExact,signedEnclosed);

        int pathCases=0, pathOk=0, tailCases=0,tailOk=0;
        foreach(Q r in new[]{Q.Of(1,4),Q.Of(1,3),Q.Of(1,2),Q.Of(2,3),Q.Of(3,4)})
        for(int t=1;t<=12;t++)
        {
            Q w=r/((1-r)*(1-r));var k=Smoother.K(t,w);bool ok=true;
            for(int j=1;j<=t;j++)
            {
                Q formula=(1-r)*(Pow(r,j-1)+Pow(r,2*t-j))/(1-Pow(r,2*t));
                ok &= formula==k[0,j-1];
            }
            pathCases++;if(ok)pathOk++;
            for(int m=0;m<t;m++)
            {
                Q tail=Enumerable.Range(m+1,t-m-1).Aggregate(Q.Zero,(a,j)=>a+k[0,j]);
                Q formula=(Pow(r,m+1)-Pow(r,2*t-m-1))/(1-Pow(r,2*t));
                tailCases++;if(tail==formula)tailOk++;
            }
        }
        Out("path_closed_form",pathCases,pathOk,tailCases,tailOk);
        var k4=Smoother.K(4,1);
        Out("minimax_T4_w1",(1-k4[0,0])/2,(k4[0,2]+k4[0,3])/2,k4[0,3]/2,Q.Zero);
        Out("nonmonotone_future_entry",Smoother.K(4,10)[0,1],Q.Of(1,4));

        var tied=Stn.Build(2,new[]{(1,(Q)0,(Q)1),(2,(Q)0,(Q)1)},new[]{(1,2,(Q)0,(Q?)(Q)0)});
        var dt=tied.Distances();var t1=Stn.Window(dt,1);var t2=Stn.Window(dt,2);
        Out("clock_marginals",t1.Lo,t1.Hi,t2.Lo,t2.Hi,0);
        var low=new Stn(2,ImmutableArray.Create((0,1,(Q)0),(1,0,Q.Of(-1,2))));
        var high=new Stn(2,ImmutableArray.Create((0,1,(Q)1),(1,0,Q.Of(-1,2))));
        Out("clock_uncertain_corners",Stn.Consistent(low.Distances()),Stn.Consistent(high.Distances()));
        Out("clock_cycle_margin",(Q)(-1),Q.Of(1,2),Q.Of(-1,2));
        var dates=Stn.Build(2,new[]{(1,(Q)0,(Q)1),(2,(Q)0,(Q)1)},new[]{(1,2,Q.Of(1,2),(Q?)(Q)1)});
        Out("point_date_false_contradiction",Q.Of(4,5),Q.Of(4,5),Q.Zero,Q.Of(1,2),Stn.Consistent(dates.Distances()));
        var bad=low.Distances();
        Out("inconsistent_clock_rejected",Throws<InvalidOperationException>(()=>Stn.Window(bad,1)),Throws<InvalidOperationException>(()=>Stn.MinGap(bad,0,1)));
    }
}
