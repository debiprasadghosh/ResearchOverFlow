"""Edit the supplied V2 in place, preserving native mathematics and its three figures."""
from __future__ import annotations
import copy, hashlib, json, math, re, subprocess, tempfile, zipfile
from datetime import datetime, timezone
from fractions import Fraction as F
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from lxml import etree

ROOT=Path(__file__).resolve().parent
SRC=ROOT/"base_v2.docx"
OUT=ROOT/"output/Dependency_Preserving_Temporal_Causal_Computation_V3.docx"
V=json.loads((ROOT/"v3_results.json").read_text())
LEGACY=json.loads((ROOT/"validation_original_v3.json").read_text())
assert V["all_passed"] and LEGACY["all_passed"]
assert V["total_Csharp_lines"]==98 and V["additional_Csharp_lines"]==27
doc=Document(SRC)
body=doc.element.body
M="http://schemas.openxmlformats.org/officeDocument/2006/math"
R="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
W="http://schemas.openxmlformats.org/wordprocessingml/2006/main"

def find(start,style=None):
    for p in doc.paragraphs:
        if p.text.replace("\xa0"," ").startswith(start) and (style is None or p.style.name==style):return p
    raise KeyError(start)

def fragment(md):
    with tempfile.TemporaryDirectory() as td:
        p=Path(td);(p/"f.md").write_text(md,encoding="utf-8")
        subprocess.run(["pandoc","f.md","-f","markdown+tex_math_dollars-auto_identifiers",
                        "-o","f.docx",f"--reference-doc={SRC}","--no-highlight"],cwd=p,check=True)
        f=Document(p/"f.docx")
        els=[copy.deepcopy(e) for e in f.element.body if e.tag!=qn("w:sectPr")]
        for e in els:
            for b in list(e.iter(qn("w:bookmarkStart")))+list(e.iter(qn("w:bookmarkEnd"))):b.getparent().remove(b)
            for x in e.iter():
                rid=x.get(f"{{{R}}}id")
                if rid and rid in f.part.rels:
                    rel=f.part.rels[rid]
                    if rel.is_external:x.set(f"{{{R}}}id",doc.part.relate_to(rel.target_ref,rel.reltype,is_external=True))
                    else:raise ValueError("unexpected internal relationship in text fragment")
    return els

def replace_with_md(p,md):
    els=fragment(md)
    assert len(els)==1 and els[0].tag==qn("w:p")
    parent=p._p.getparent();parent.replace(p._p,els[0])
    return els[0]

def before(anchor,els):
    for e in els:anchor.addprevious(e)

def after(anchor,els):
    for e in els:anchor.addnext(e);anchor=e
    return anchor

def literal_replace(p,old,new):
    for t in p._p.iter(qn("w:t")):
        if t.text and old in t.text:
            t.text=t.text.replace(old,new);return
    raise KeyError(old)

def append_text(p,text):
    p.add_run(text)

def ppr(e):
    x=e.find(qn("w:pPr"))
    if x is None:x=OxmlElement("w:pPr");e.insert(0,x)
    return x

def caption(s,keep_next=True):
    e=fragment(s)[0];pr=ppr(e)
    for x in list(pr):pr.remove(x)
    st=OxmlElement("w:pStyle");st.set(qn("w:val"),"Caption");pr.append(st)
    if keep_next:pr.append(OxmlElement("w:keepNext"))
    sp=OxmlElement("w:spacing")
    for k,v in {"before":"140","after":"100","line":"245","lineRule":"auto"}.items():sp.set(qn("w:"+k),v)
    pr.append(sp)
    for run in e.findall(qn("w:r")):
        rpr=run.find(qn("w:rPr"))
        if rpr is None:rpr=OxmlElement("w:rPr");run.insert(0,rpr)
        s_=OxmlElement("w:sz");s_.set(qn("w:val"),"20");rpr.append(s_)
        rpr.append(OxmlElement("w:i"))
    return e

def style_table(table,widths):
    tbl=table._tbl;tp=tbl.tblPr
    for x in list(tp):tp.remove(x)
    for tag,attrs in [("tblW",{"w":str(sum(widths)),"type":"dxa"}),("jc",{"val":"center"})]:
        x=OxmlElement("w:"+tag)
        for k,v in attrs.items():x.set(qn("w:"+k),v)
        tp.append(x)
    borders=OxmlElement("w:tblBorders")
    for side in ("top","left","bottom","right","insideH","insideV"):
        x=OxmlElement("w:"+side)
        for k,v in {"val":"single","sz":"4","color":"D9D9D9"}.items():x.set(qn("w:"+k),v)
        borders.append(x)
    tp.append(borders)
    lay=OxmlElement("w:tblLayout");lay.set(qn("w:type"),"fixed");tp.append(lay)
    for gc,w in zip(tbl.tblGrid.gridCol_lst,widths):gc.set(qn("w:w"),str(w))
    for ri,row in enumerate(table.rows):
        trpr=row._tr.get_or_add_trPr()
        for x in list(trpr):trpr.remove(x)
        trpr.append(OxmlElement("w:cantSplit"))
        if ri==0:trpr.append(OxmlElement("w:tblHeader"))
        for cell,w in zip(row.cells,widths):
            cp=cell._tc.get_or_add_tcPr()
            for x in list(cp):cp.remove(x)
            tcw=OxmlElement("w:tcW");tcw.set(qn("w:w"),str(w));tcw.set(qn("w:type"),"dxa");cp.append(tcw)
            sh=OxmlElement("w:shd");sh.set(qn("w:val"),"clear");sh.set(qn("w:fill"),"EDF0F2" if ri==0 else "FFFFFF");cp.append(sh)
            mar=OxmlElement("w:tcMar")
            for side in ("top","left","bottom","right"):
                x=OxmlElement("w:"+side);x.set(qn("w:w"),"85");x.set(qn("w:type"),"dxa");mar.append(x)
            cp.append(mar)
            va=OxmlElement("w:vAlign");va.set(qn("w:val"),"center");cp.append(va)
            for p in cell.paragraphs:
                p.style=doc.styles["Body Text"]
                pf=p.paragraph_format;pf.space_before=Pt(0);pf.space_after=Pt(2);pf.line_spacing=1.05;pf.keep_with_next=False
                for r in p.runs:r.font.size=Pt(10);r.font.bold=(ri==0)

def new_table(rows,widths):
    t=doc.add_table(rows=0,cols=len(widths))
    for row in rows:
        cells=t.add_row().cells
        for cell,s in zip(cells,row):cell.text=str(s)
    style_table(t,widths);e=t._tbl;e.getparent().remove(e);return e

def picture(path,cap):
    p=doc.add_paragraph(style="Body Text");p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next=True
    sh=p.add_run().add_picture(str(path),width=Inches(6.45))
    sh._inline.docPr.set("descr","Analytic sharp prefix risk for path smoothing at unit weight, by history length and lookahead.")
    e=p._p;e.getparent().remove(e)
    return [e,caption(cap,False)]

# Analytic figure. Curves are formulas, not fitted or measured data.
root5=(float(F(V["exact_analytic_checks"]["unit_rho_bounds"][0]))+
       float(F(V["exact_analytic_checks"]["unit_rho_bounds"][1])))/2
rho=root5
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9.5,"axes.spines.top":False,"axes.spines.right":False,
                     "axes.labelcolor":"#172d42","text.color":"#172d42","axes.edgecolor":"#85919d"})
fig,ax=plt.subplots(1,2,figsize=(6.45,3.0),layout="constrained")
for m,col in [(0,"#173f64"),(1,"#348d91"),(4,"#b3673b")]:
    ts=np.arange(m+1,41);q=(rho**(m+1)-rho**(2*ts-m-1))/(1-rho**(2*ts))
    ax[0].plot(ts,100*q/2,color=col,lw=1.9,label=f"{m} later observations")
    ax[0].axhline(50*rho**(m+1),color=col,ls=":",lw=.9,alpha=.7)
ax[0].set(xlabel="History length T",ylabel="Sharp risk (% of data diameter)",title="(a) Finite histories")
ax[0].set_xlim(1,40);ax[0].set_ylim(0,21);ax[0].grid(axis="y",alpha=.2);ax[0].legend(frameon=False,fontsize=8.5,loc="center right")
ms=np.arange(0,9);r=50*rho**(ms+1)
ax[1].semilogy(ms,r,color="#173f64",marker="o",ms=4,lw=1.8)
ax[1].axhline(1,color="#b3673b",lw=1.2,ls="--",label="1% guarantee")
ax[1].scatter([4],[r[4]],s=45,color="#b3673b",zorder=5)
ax[1].annotate("First m = 4",(4,r[4]),xytext=(4.1,1.8),fontsize=8.5,
               arrowprops={"arrowstyle":"->","color":"#b3673b","lw":.8})
ax[1].set(xlabel="Later observations available m",ylabel="Uniform risk (% of data diameter)",title="(b) Every history length",xticks=ms)
ax[1].grid(axis="y",alpha=.2);ax[1].legend(frameon=False,fontsize=8.5,loc="upper right")
figpath=ROOT/"figures/prefix_minimax_risk.png";figpath.parent.mkdir(exist_ok=True)
fig.savefig(figpath,dpi=230,facecolor="white");plt.close(fig)

# Front matter and local scope corrections.
find("Temporal Causal Reasoning","Title").text="Dependency Preserving\nTemporal Causal Computation"
find("Mechanism gluing","Subtitle").text="Horizontal sheaves, interval ranges and temporal smoothing"
find("Version 2","Date").text="Version 3 · 30 October 2026"
abstract=find("Temporal causal reasoning can be placed")
abstract.text=("Temporal causal reasoning can be represented within the horizontal topology of Autoregressive Sheaf Evolution "
 "by placing complete mechanism relations on overlapping event contexts. Stalks remain data spaces, while physical time remains "
 "distinct from inference depth. We construct interventions by mechanism replacement and counterfactuals by sharing exogenous "
 "circumstances across worlds. Exact path formulas, temporal feasibility certificates, stability bounds and an intervention "
 "preserving compression criterion follow. The added computation is developed mathematically through occurrence constraints: "
 "natural interval evaluation solves a relaxation in which repeated quantities are independently copied. This explains counterfactual "
 "overestimation and yields a family with unbounded interval width inflation. Sign coherence gives an exact forward range after a "
 "scalar gauge change, while a direct reduction from weighted MAX-CUT proves exact response-range optimization NP-hard even for "
 "four-layer acyclic models. For positive scalar graph smoothing we prove positivity, reversibility and monotonic growth of total "
 "future weight. A closed form for the entire first row of the path resolvent gives a sharp minimax error for any prefix-only estimate "
 "of its retrospective output, and an exact lookahead budget. Clock projections receive attainable shortest-path witnesses and robust "
 "cycle certificates. Finally we prove a dyadic exactness budget for the gain study and replace an unsound rational-conversion "
 "shortcut with adjacent binary64 brackets and exact containment. Independent Python checks pass all 98 C# output lines, with "
 "additional exact checks of 15 weighted resolvents. The finite studies verify constructions and arithmetic contracts; comparative "
 "learning performance remains the subject of three falsifiable conjectures.")
append_text(find("Keywords"),"; dependency constraints; minimax prefix error; sign coherence; verified arithmetic")
contrib=find("The mathematical development has four main consequences.")
literal_replace(contrib,"The mathematical development has four main consequences.","The mathematical development has five main consequences.")
literal_replace(contrib,"A fifth consequence, added in this version, is computational.","A fifth consequence is computational.")
append_text(contrib," Section 12 develops this fifth consequence into exact range criteria, a complexity barrier, sharp temporal "
 "information bounds and arithmetic certificates. It adds one definition and sixteen proved statements to the earlier development.")
status=find("The paper includes proofs of its stated results.")
literal_replace(status,"claims in Section 12","claims in Section 13")
append_text(status," The reductions and specialized formulas of Section 12 are proved directly. Their classical antecedents are "
 "credited; they are not claims of literature-wide priority.")
find("Section 2 defines the horizontal model.").text=(
 "Sections 2 to 5 construct the mechanism sheaf, clocks, interventions and counterfactuals. Sections 6 to 9 develop path "
 "formulas, temporal access, stability and integration with ASE. Section 10 supplies exact examples; Section 11 reports interval "
 "and symbolic computations. Section 12 develops the mathematics of those computations. Section 13 states the remaining questions "
 "and falsifiable comparisons, and Section 14 concludes. Appendix A collects assumptions; Appendix B gives the corrected reference "
 "kernel; Appendix C records its validation and reproduction protocol.")
append_text(find("The distinction between filtering and smoothing")," The additional analysis uses interval verification "
 "(Moore et al., 2009; Rump, 2010), signed-graph balance (Harary, 1953), classical complexity reductions (Karp, 1972) and "
 "tridiagonal inversion (Usmani, 1994). The proofs below state their specialized scope.")
for p in doc.paragraphs:
    if "Suppose a representation change has a continuous base map" in p.text:
        literal_replace(p,"Suppose a representation change has a continuous base map",
                         "A representation change has a continuous base map")
replace_with_md(find("The preceding sections are exact statements about declared models."),
 "The preceding sections are exact statements about declared models. An implementation receives gains, dates and lags known "
 "only to some resolution. This section treats that resolution with interval arithmetic and exact rational computation. The corrected "
 "immutable C# kernel is described in Appendix B. Its finite interval results enclose the same expression on the same data under "
 "the arithmetic contract proved in Section 12.5; unsupported nonfinite results are rejected. An independent Python program "
 "recomputes the original 71 output lines, using exact fractions and SymPy for identities and matrices, rational interval arithmetic "
 "for enclosures, and vertex enumeration for ranges. All pass. Section 12 adds 27 checked output lines. These are exact constructions "
 "or enclosures under specified synthetic models, rather than measurements of trained-system performance.")
append_text(find("Proposition 11.1")," Here the gains are independent edge coordinates; a tied parameterization needs the "
 "additional constraints of Proposition 12.3.")
append_text(find("Proposition 11.2")," Exactness here refers to ideal real interval arithmetic; outward rounding may add slack.")
p=find("To measure how much the form matters")
append_text(p," Lemma 12.15 now proves the dyadic claim for all 600 models by a bit budget, rather than relying only on "
 "the 487 explicit rational repetitions.")
p=find("The exact range is always available")
append_text(p," Theorem 12.6 establishes NP-hardness directly for this path-response family. Theorem 12.5 gives an additional "
 "exact regime, and Proposition 12.4 rules out a universal finite relative-width bound for forward substitution.")
prop=find("Proposition 11.3")
replace_with_md(prop,r"**Proposition 11.3 (stepwise interval evaluation forgets occurrence ties).** Suppose a counterfactual "
 r"calculation is expressed using addition, subtraction, multiplication and division with every interval denominator excluding zero. "
 r"In ideal interval arithmetic, unfolding the stepwise calculation into an expression tree and replacing each repeated leaf "
 r"quantity by an independent copy gives exactly the range represented by natural interval evaluation. It contains the range "
 r"with the evidence, mechanisms and circumstances tied as declared, and can be strictly larger.")
proof=doc.paragraphs[[p.text.startswith("Proposition 11.3") for p in doc.paragraphs].index(True)+1]
replace_with_md(proof,"*Proof.* Apply the expression-tree induction of Theorem 12.2. The tied assignments form a subset "
 "of the occurrence box, while the example gives strict inclusion. This numerical relaxation need not correspond solely to "
 "making causal worlds independent: shared evidence and parameter identities can also be forgotten. ∎")
p=find("In the example the circumstance")
append_text(p," This diagnoses the interval relaxation; it does not alter the SCM or supply a new cross-world law.")
p=find("Proposition 11.4")
literal_replace(p,"Then","For T ≥ 2 the following formulas hold.")
p=find("The kernel derived")
literal_replace(p,"At unit weight the earliest estimate takes about 38.2% of its weight from later observations, however long the history.",
 "At unit weight the future share is 1/3 for two events and approaches 38.2% as the history length grows.")
append_text(p," For T = 1, K = [1], the determinant is one and future weight is zero; strict monotonicity is inapplicable.")
literal_replace(find("A start-of-period date is sound only"),
    "A start-of-period date is sound only when the period has zero width.",
    "A start-of-period representative can happen to be feasible, but does not conservatively represent every time in a period of positive width.")
append_text(find("Theorem 3.2 handles exact dates")," The calculations use closed hulls of calendar periods; "
 "Section 12.4 specifies the resulting endpoint convention and quantization criterion.")

# Insert new native mathematics before the old open-questions section.
anchor=find("12 Open questions","Heading 1")
md=(ROOT/"math_extension.md").read_text()
A=V["exact_analytic_checks"]
for key,val in {"RISK0":A["unit_minimax_limit"],
                "RISK3":float(F(A["unit_m3_risk_bounds"][0])),
                "RISK4":float(F(A["unit_m4_risk_bounds"][0]))}.items():
    md=md.replace("{{"+key+"}}",f"{val:.9f}")
(ROOT/"math_extension_filled.md").write_text(md)
new=fragment(md)
new_heading=None
for e in new:
    txt="".join(e.itertext())
    visible="".join(e.iter(qn("w:t"))[0].itertext()) if False else "".join(x.text or "" for x in e.iter(qn("w:t")))
    if visible=="[[FIGURE4]]":
        before(anchor._p,picture(figpath,"Figure 4. Analytic sharp error relative to the full path smoother at unit weight. "
          "(a) Finite-history error with m later observations; dotted lines show the uniform limits. "
          "(b) Uniform error falls geometrically; m = 4 is the first lookahead meeting a 1% guarantee. "
          "All errors are normalized by the future-data diameter."))
    elif visible=="[[TABLE6]]":
        groups=[
          ("Rational-to-binary64 brackets",9,"Exact rational containment and adjacent-endpoint checks","12.16"),
          ("Conversion and domain guards",3,"Old failure, finite intervals, multi-affine vertex domains","12.15–12.17"),
          ("Single-event smoother",1,"Exact determinant and inverse","11.4"),
          ("MAX-CUT construction",2,"All 74 graphs; triangle range","12.6"),
          ("Cancellation families",2,"Exact widths and outward enclosures","12.4"),
          ("Tied gains and sign gauges",2,"Interior extremum; 16 sign-coherent models","12.3, 12.5"),
          ("Path row, tails and prefix risk",3,"60 matrices, 390 tails, minimax values and nonmonotone entry","12.8–12.11"),
          ("Clock and quantization cases",5,"Fraction shortest paths, inequalities and exact cycle costs","12.12–12.14")]
        assert sum(g[1] for g in groups)==27
        before(anchor._p,[caption("Table 6. Independent checks of the 27 added C# output lines. Every group passes. "
                 "The 15 additional weighted-resolvent cases are separate Python exact calculations."),
           new_table([("Group","Lines","Recomputation","Statement")]+groups,[2400,650,4898,1700])])
    else:
        anchor._p.addprevious(e)
        if visible.startswith("12 Mathematics"):new_heading=e

# Keep the earlier open questions and the three performance conjectures.
anchor.text="13 Open questions and falsifiable conjectures"
find("12.1 Mathematical questions","Heading 2").text="13.1 Mathematical questions"
find("12.2 Proposed comparative claims","Heading 2").text="13.2 Proposed comparative claims"
find("13 Conclusion","Heading 1").text="14 Conclusion"
p=find("A fifth question concerns sharp enclosures")
replace_with_md(p,"A fifth question is the efficient treatment of constrained parameter families and route structures "
 "outside the exact regimes. Theorem 12.5 gives sign-coherent forward ranges, Proposition 12.4 gives unbounded relative "
 "inflation, and Theorem 12.6 excludes a general polynomial-time exact range algorithm unless P equals NP. Useful remaining "
 "targets include exact methods for restricted route cores, constrained single-use parameterizations and adaptive "
 "dependency retention with certified absolute, rather than universal relative, error bounds.")
p=find("These are proposed engineering comparisons.")
append_text(p," The computational theorems of Section 12 likewise do not establish these performance claims.")
p=find("The interval computations make three")
replace_with_md(p,"The computation has three distinct sources of uncertainty: model uncertainty, loss of declared "
 "dependencies in a numerical relaxation, and floating-point error. Occurrence constraints explain the second, while "
 "adjacent rational brackets and exact containment control the third. Sign coherence gives an efficient exact gain range; "
 "the four-layer reduction proves a general complexity barrier. For the scalar path smoother, a closed form quantifies "
 "both the total future weight and the sharp error of a prefix-only substitute. The future share approaches 38.2% at unit "
 "weight as history length grows, while a uniform 1% discrepancy guarantee requires four later observations.")
p=find("The resulting research program has a concrete next artifact:")
replace_with_md(p,"The next implementation is a typed causal horizontal layer that retains shared parameter identities, "
 "returns a range with an explicit exactness or enclosure certificate, and separates a permitted-prefix read from a "
 "retrospective smoother. Clock answers carry a feasible assignment or a negative cycle. Such a layer can then be "
 "evaluated under the three frozen comparisons of Section 13; the exact constructions and successful arithmetic checks "
 "alone do not establish a learned-system advantage.")

# Extend the assumptions inventory locally.
ta=next(t for t in doc.tables if t.cell(0,0).text=="Statement")
for row in ta.rows:
    if row.cells[0].text=="Proposition 11.1":row.cells[1].text="Finite acyclic model; independent edge gains in a box"
    if row.cells[0].text=="Proposition 11.3":
        row.cells[1].text="Elementary expression tree; denominator intervals avoid zero; ideal interval arithmetic"
        row.cells[2].text="Exact occurrence-independent range; enclosure of declared tied assignments"
    if row.cells[0].text=="Proposition 11.4":
        row.cells[1].text="Scalar path; w > 0; T ≥ 2 for strict monotonicity"
        row.cells[2].text="Endpoint anticipation, Fibonacci values at unit weight; T = 1 handled separately"
for row in [
 ("Theorem 12.2","Elementary expression tree and independent occurrence leaves; denominators avoid zero","Exact range of the relaxed expression, not necessarily of the tied model"),
 ("Theorem 12.5","Acyclic route core; independent nonnegative amplitudes and coherent fixed signs","Vertex sign gauge and exact forward range"),
 ("Theorem 12.6","Four-layer linear DAG; independent interval gains; integer fixed weights","Exact gain-range optimization is NP-hard"),
 ("Theorems 12.7–12.9; Corollary 12.10","Positive scalar graph Laplacian; path specialization; independent future box for risk","Positive reversible read, explicit tails, sharp prefix risk and lookahead budget"),
 ("Theorem 12.12; Propositions 12.13–12.14","Closed difference constraints; finite date bounds; independent coefficient box when invoked","Attainable clock bounds, robust feasibility and quantization criterion"),
 ("Lemma 12.15; Theorem 12.16; Proposition 12.17","Dyadic bit budget or exact integer bracketing; correctly rounded binary64 with gradual underflow","Exact study oracle and sound finite returned interval enclosures")]:
    cells=ta.add_row().cells
    for cell,txt in zip(cells,row):cell.text=txt
style_table(ta,[1900,4298,3450])

# Update the embedded source listings, retaining all four from V2.
bp=find("The kernel targets .NET 8")
bp.text=("The kernel targets .NET 8 and uses only the base class library. Values are immutable records and readonly structs; "
 "local scratch arrays implement elimination and shortest paths. Q represents exact rationals over arbitrary-precision integers. "
 "Q.ToDouble is an approximation, while Q.FromDouble decodes a finite binary64 datum exactly. Iv accepts finite ordered "
 "endpoints, brackets rationals by exact integer division and compares containment exactly. Elementary operations widen endpoints "
 "outward and reject unsupported nonfinite results. Poly and Expr retain the symbolic and expression-tree distinctions of "
 "Section 11. Stn computes rational shortest paths and negative cycles; its bound accessors reject an inconsistent network. "
 "Both vertex routines require multi-affinity and a supported mask dimension. SplitMix64 supplies the reproducible random stream. "
 "The four listings below are the corrected files. Program.cs and V3Checks.cs, the build project and both Python validators "
 "accompany the paper. Table 5 describes the original 71 lines; Table 6 describes the 27 added lines, giving 98 checked lines. "
 "Appendix C distinguishes the checks from the proofs and documents the conversion correction.")
for p in doc.paragraphs:
    if p.style.name!="Source Code":continue
    prev=p._p.getprevious()
    name="".join(x.text or "" for x in prev.iter(qn("w:t")))
    assert name in ("Exact.cs","Symbolic.cs","Causal.cs","Temporal.cs"),name
    p.text=(ROOT/"kernel"/name).read_text().rstrip()
    for r in p.runs:r.font.name="Liberation Mono";r.font.size=Pt(8.5);r.font.color.rgb=RGBColor(0,0,0)
    p.paragraph_format.space_before=Pt(0);p.paragraph_format.space_after=Pt(0)
    p.paragraph_format.line_spacing=.95
    p.paragraph_format.widow_control=True
    from docx.text.paragraph import Paragraph
    Paragraph(prev,doc._body).paragraph_format.keep_with_next=True

# Let the long code appendix follow the assumptions table without an almost-empty page.
pr=ppr(find("Appendix B The interval","Heading 1")._p)
for x in list(pr.findall(qn("w:pageBreakBefore"))):pr.remove(x)

# Reproduction appendix before references.
refs=find("References","Heading 1")
app=fragment(r"""# Appendix C Verification and reproduction

The supplied Version 2 was first rebuilt without changes. Its 71 output lines reproduced byte for byte, and its independent validator passed all 71. The corrected kernel then generated 98 output lines. Its first 71 lines pass the original validator; the additional 27 pass the extended validator. The only changes in the earlier lines are five interval endpoint displays, narrowed by the corrected rational conversion. The values rounded in the original tables are unchanged.

The extended validator uses exact rational comparisons for all nine conversion brackets, a separate bilinear NumPy enumeration for the 74 MAX-CUT graphs, rational corner enumeration for the 16 signed models, and independent SymPy inverses for 60 path cases and 390 tail identities. Fraction shortest paths and direct inequalities reproduce the new clock cases. Fifteen additional exact weighted-path calculations verify positivity, row sums, detailed balance and the diagonal derivative. Rational brackets for $\sqrt5$ establish the displayed lookahead thresholds without relying on decimal rounding.

The proofs and checks have different scopes. Theorem 12.6 proves hardness for arbitrary instances; enumerating 74 small graphs does not prove hardness. Lemma 12.15 proves the 600-model dyadic budget; finite output agreement alone would not establish it. The interval proof assumes the stated binary64 semantics and valid inputs; the finite boundary cases do not verify every possible API call. No training or benchmark comparison is inferred from these checks.

The source archive includes kernel files, the original and extended validators, the complete result JSON and text files, the 600-model CSV, the figure generator and document builder, and the unchanged input manuscript and source archive. It records .NET SDK 8.0.427 and runtime 8.0.33, Python 3.12.14, NumPy 2.3.5 and SymPy 1.14.0. Only the corrected source files are required for a fresh kernel run; no third-party .NET packages are used. Python dependencies and a .NET 8 SDK are listed in the reproduction instructions.

To reproduce, run the C# project in Release configuration with a chosen output directory; redirect its standard output to a text file. Run the extended Python validator against that output, then run the original validator against the extracted first 71 lines. Run the document builder after both result files report success. The README supplies the relative commands and directory layout, and the manifest records SHA-256 digests for the delivered sources and results.
""")
before(refs._p,app)

# New primary references in their alphabetical neighborhoods.
after(find("Hansen, J., & Ghrist")._p,fragment(
 "Harary, F. (1953). On the notion of balance of a signed graph. *Michigan Mathematical Journal, 2*(2), 143–146. "
 "https://doi.org/10.1307/mmj/1028989917"))
after(find("IEEE. (2019)")._p,fragment(
 "Karp, R. M. (1972). Reducibility among combinatorial problems. In R. E. Miller, J. W. Thatcher, & J. D. Bohlinger (Eds.), "
 "*Complexity of computer computations* (pp. 85–103). Plenum Press. https://doi.org/10.1007/978-1-4684-2001-2_9"))
after(find("Rubenstein, P. K.")._p,fragment(
 "Rump, S. M. (2010). Verification methods: Rigorous results using floating-point arithmetic. *Acta Numerica, 19*, 287–449. "
 "https://doi.org/10.1017/S096249291000005X"))
after(find("Särkkä, S. (2013)")._p,fragment(
 "Usmani, R. A. (1994). Inversion of a tridiagonal Jacobi matrix. *Linear Algebra and Its Applications, 212–213*, 413–414. "
 "https://doi.org/10.1016/0024-3795(94)90414-6"))

# Point-of-change comments make the substantial additions and corrections reviewable.
if hasattr(doc,"add_comment"):
    from docx.text.paragraph import Paragraph
    p=Paragraph(new_heading,doc._body)
    doc.add_comment(p.runs[:1],"Version 3 adds the mathematics of the executed computation in Section 12. "
       "Earlier sections and all three original figures are retained; the open questions and conclusion move to Sections 13 and 14.",
       author="Editorial note",initials="EN")
    p=find("Proposition 11.3")
    doc.add_comment(p.runs[:1],"The earlier statement is narrowed to elementary expression trees. The relaxation forgets "
       "all repeated-quantity ties; it need not be solely a decoupling of causal worlds. Theorem 12.2 supplies the proof.",
       author="Editorial note",initials="EN")
    p=find("The rational conversion in the earlier kernel")
    doc.add_comment(p.runs[:1],"The exact-rational boundary cases revealed an unsound dyadic conversion shortcut and an "
       "approximate containment test. Theorem 12.16 and the corrected Exact.cs replace both.",
       author="Editorial note",initials="EN")

# Consistent headings, OMML property order, upright equation labels.
for name in ("Title","Subtitle","Heading 1","Heading 2","Heading 3"):
    doc.styles[name].font.color.rgb=RGBColor(0,0,0)
PPR=("pStyle keepNext keepLines pageBreakBefore framePr widowControl numPr suppressLineNumbers pBdr shd tabs suppressAutoHyphens "
     "kinsoku wordWrap overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi adjustRightInd snapToGrid spacing ind "
     "contextualSpacing mirrorIndents suppressOverlap jc textDirection textAlignment textboxTightWrap outlineLvl divId "
     "cnfStyle rPr sectPr pPrChange").split()
def reorder(parent,order):
    for x in sorted(list(parent),key=lambda e:order.index(etree.QName(e).localname) if etree.QName(e).localname in order else 99):
        parent.append(x)
for x in body.iter(qn("w:pPr")):reorder(x,PPR)
for x in body.iter(f"{{{M}}}dPr"):reorder(x,["begChr","sepChr","endChr","grow","shp","ctrlPr"])
for x in body.iter(f"{{{M}}}mcPr"):reorder(x,["count","mcJc"])
for x in body.iter(f"{{{M}}}rPr"):
    if x.find(f"{{{M}}}nor") is not None:
        for a in x.findall(f"{{{M}}}sty")+x.findall(f"{{{M}}}scr"):x.remove(a)
    reorder(x,["lit","nor","scr","sty","brk","aln"])
for r in body.iter(f"{{{M}}}r"):
    if re.fullmatch(r"\(\d+(\.\d+)?\)",r.findtext(f"{{{M}}}t") or ""):
        pr=r.find(f"{{{M}}}rPr")
        if pr is not None:
            for a in list(pr):pr.remove(a)
            sty=etree.SubElement(pr,f"{{{M}}}sty");sty.set(f"{{{M}}}val","p")
doc.core_properties.title="Dependency Preserving Temporal Causal Computation"
doc.core_properties.subject="Horizontal sheaves, interval ranges and temporal smoothing; Version 3"
doc.core_properties.modified=datetime.now(timezone.utc)
OUT.parent.mkdir(exist_ok=True);doc.save(OUT)

# Structural checks preserve all original image bytes and earlier native equations.
with zipfile.ZipFile(SRC) as z:oldmedia={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith("word/media/")}
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    for n in z.namelist():
        if n.endswith(".xml") or n.endswith(".rels"):etree.fromstring(z.read(n))
    newmedia={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith("word/media/")}
    assert oldmedia<=newmedia
    xml=z.read("word/document.xml").decode()
    assert "[[FIGURE4]]" not in xml and "{{RISK" not in xml
outdoc=Document(OUT)
summary={"output":str(OUT),"paragraphs":len(outdoc.paragraphs),"tables":len(outdoc.tables),
 "native_equations":len(list(outdoc.element.body.iter(f"{{{M}}}oMath"))),
 "images":len(outdoc.inline_shapes),"original_images_retained":len(oldmedia),
 "added_proved_statements":16,"added_definitions":1,"Csharp_output_lines":V["total_Csharp_lines"],
 "Csharp_all_passed":V["all_passed"] and LEGACY["all_passed"]}
(ROOT/"build_report.json").write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
