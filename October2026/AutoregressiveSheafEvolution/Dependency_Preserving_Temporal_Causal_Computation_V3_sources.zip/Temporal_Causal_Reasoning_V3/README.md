# Dependency Preserving Temporal Causal Computation

Version 3 · 30 October 2026

This archive accompanies the revised Word paper. It retains the supplied Version 2, extends its mathematics with one definition and sixteen proved statements, and corrects the finite interval kernel.

## Reproduce the computation

Run from this directory. The tested environment was .NET SDK 8.0.427 / runtime 8.0.33, Python 3.12.14, NumPy 2.3.5 and SymPy 1.14.0. The C# project targets .NET 8 and has no third-party NuGet dependencies.

    python -m pip install -r requirements.txt
    dotnet build kernel/Tcr.csproj --configuration Release --nologo
    dotnet kernel/bin/Release/net8.0/Tcr.dll output > kernel/cs_out_v3.txt
    python validate_v3.py
    python v2_sources/validation/validate.py cs_original_lines_v3.txt validation_original_v3.json

The extended validator requires kernel/cs_out_v3.txt, writes v3_results.json, and extracts the original 71 lines to cs_original_lines_v3.txt. The original validator then checks those lines independently. Both JSON results must have all_passed: true.

All 98 C# output lines and the 600-model CSV reproduced byte for byte after a fresh build. The file final_replay.json records the replay. The file baseline_replay.json records the unchanged V2 replay; its 71 lines also reproduced byte for byte.

## Rebuild the Word document

Install Pandoc (tested: 3.1.3), then run:

    python build_v3.py

The builder edits base_v2.docx, imports the new mathematics from math_extension.md, and fills its displayed numerical thresholds from the validated result JSON. It preserves all three original figures and their image bytes, adds the analytic prefix-risk figure, updates the four embedded C# listings, and writes output/Dependency_Preserving_Temporal_Causal_Computation_V3.docx.

Equations are native editable Word mathematics (OMML). A full Markdown export and extracted media are included as a second source representation. LibreOffice was used to render and inspect every final page; renderer software is not bundled.

## Mathematical additions

Section 12 contains:

- A dependency preserving uncertainty diagram and an exact characterization of natural interval evaluation after occurrence independence.
- A tied-parameter counterexample and an acyclic family with unbounded relative interval-width inflation.
- A sign-coherence criterion, its vertex gauge, and an exact forward range.
- A direct weighted MAX-CUT reduction proving exact response-range optimization NP-hard on four-layer DAGs.
- Positivity, reversibility and diagonal monotonicity for positive scalar graph resolvents.
- An exact first-row path formula, unseen-tail formula, sharp prefix minimax risk, and uniform lookahead budget.
- A counterexample to monotonicity of individual off-diagonal weights.
- Attainable temporal-network bounds, robust uncertain-coefficient certificates, and a point-date quantization criterion.
- A dyadic bit-budget proof, exact rational-to-binary64 bracketing, and soundness of finite returned elementary intervals.

The paper credits classical foundations and does not assert literature-wide priority. Finite numerical checks illustrate and verify implementations; the written proofs establish the general conditional statements.

## Corrections to the computation

Exact.cs now brackets rationals by integer division on the binary64 grid. The earlier dyadic shortcut failed, for example, at the representable value 2^-1024 because converting its denominator to binary64 overflowed. The earlier approximate containment test also falsely accepted zero as an enclosure. Both operations now use exact rational comparisons.

Finite intervals reject NaN, infinity, reversed endpoints and unsupported nonfinite results. Vertex enumeration rejects non-multi-affine polynomials and unsupported mask dimensions. The one-event smoother returns the identity and determinant one. Temporal bound queries reject inconsistent networks. The earliest-clock routine uses one incoming-edge lookup, predecessor appends and one reversal, so its witness construction has the linear scalar-operation bound of Corollary 3.3.

These are scoped soundness contracts, not a claim that every invalid public API input has a separately verified diagnostic.

Five earlier interval endpoint displays become slightly narrower after rational bracketing. The original numerical tables are unchanged at their printed precision. All original validator checks still pass.

## Results and sources

- kernel/: corrected C# files, project and NuGet configuration; primary and replayed output.
- validate_v3.py: independent extended validator.
- v2_sources/validation/validate.py: unchanged original validator.
- v3_results.json and validation_original_v3.json: per-line checks and exact analytic checks.
- output/dag_study.csv: all 600 generated gain cases.
- v2_replay/: original replay output and its validation result.
- base_v2.docx: unchanged input manuscript.
- input/Temporal_Causal_Reasoning_V2_sources.zip: unchanged input source archive.
- build_v3.py, math_extension.md and math_extension_filled.md: editable document sources and figure generation.
- article.md and article_media/: integrated Markdown export and its figures.
- verification_report.json: document structure, reproduction and page-review records.
- manifest.json: SHA-256 digests for included files, excluding the manifest itself.

The three engineering performance conjectures remain untested. The synthetic date study is consistent by construction; its order-certification rate describes that generated family. A point-date representative can happen to satisfy constraints without conservatively representing the complete reported period. Calendar calculations use closed hulls of periods.
