---
author: Debi Prasad Ghosh
date: Version 3 · 30 October 2026
subtitle: Horizontal sheaves, interval ranges and temporal smoothing
title: |
  Dependency Preserving\
  Temporal Causal Computation
---

Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India

## Abstract

Temporal causal reasoning can be represented within the horizontal
topology of Autoregressive Sheaf Evolution by placing complete mechanism
relations on overlapping event contexts. Stalks remain data spaces,
while physical time remains distinct from inference depth. We construct
interventions by mechanism replacement and counterfactuals by sharing
exogenous circumstances across worlds. Exact path formulas, temporal
feasibility certificates, stability bounds and an intervention
preserving compression criterion follow. The added computation is
developed mathematically through occurrence constraints: natural
interval evaluation solves a relaxation in which repeated quantities are
independently copied. This explains counterfactual overestimation and
yields a family with unbounded interval width inflation. Sign coherence
gives an exact forward range after a scalar gauge change, while a direct
reduction from weighted MAX-CUT proves exact response-range optimization
NP-hard even for four-layer acyclic models. For positive scalar graph
smoothing we prove positivity, reversibility and monotonic growth of
total future weight. A closed form for the entire first row of the path
resolvent gives a sharp minimax error for any prefix-only estimate of
its retrospective output, and an exact lookahead budget. Clock
projections receive attainable shortest-path witnesses and robust cycle
certificates. Finally we prove a dyadic exactness budget for the gain
study and replace an unsound rational-conversion shortcut with adjacent
binary64 brackets and exact containment. Independent Python checks pass
all 98 C# output lines, with additional exact checks of 15 weighted
resolvents. The finite studies verify constructions and arithmetic
contracts; comparative learning performance remains the subject of three
falsifiable conjectures.

**Keywords** temporal causal reasoning; cellular sheaves; structural
causal models; counterfactuals; harmonic extension; causal abstraction;
Autoregressive Sheaf Evolution; interval arithmetic; symbolic
computation; simple temporal networks; dependency constraints; minimax
prefix error; sign coherence; verified arithmetic

# 1 Introduction

ASE supplies a language for comparing locally represented information
across overlapping contexts. Causal reasoning adds a requirement that
compatibility alone does not express: a mechanism says which variables
determine another variable and what remains invariant when an external
action replaces one mechanism. We place those mechanisms in the
horizontal context structure. An inference layer may refine estimates of
an entire event history, but moving through layers does not advance
physical time or constitute an intervention.

The central construction is deliberately explicit. A mechanism context
contains a child event variable, its parents and its exogenous inputs.
Its stalk is the set of tuples satisfying the mechanism. Restrictions
project those tuples to shared variables. Gluing therefore assembles one
assignment satisfying every represented mechanism. A perfect
intervention replaces selected local relations while preserving the
meanings and identities of the remaining variables. A counterfactual
additionally preserves the exogenous circumstances across the factual
and hypothetical worlds.

This construction supports both retrospective reasoning over a complete
narrative and nonanticipating computation from a growing history. Those
tasks use different information. Later evidence can legitimately change
an estimate of an earlier latent cause during abduction or smoothing. It
does not follow that a future physical event causes a past physical
event. Conversely, an online prediction cannot use later evidence merely
because a graph mask appears triangular. We formalize the distinction
through prefix restrictions and a reciprocity theorem for harmonic
reads.

## 1.1 Literature survey

Yang et al. (2026) motivate the present question by replacing narrative
order with an explicit event structure. Their TCR-Agent extracts a graph
and performs graph edits; TCR-Former combines event anchors, a mixed
attention mask and temporal information. The attached version is the
source examined here. The useful architectural idea is to make event
relationships explicit rather than relying on the order of sentences.
Its reported benchmark gains are not used as evidence for the present
sheaf construction. Section 11 also examines, as interval data, the
year-only timestamps of its first-stage training data.

Some printed formulas require a more precise causal interpretation. In
Section 2.2 of that manuscript, the prose refers to cutting incoming
edges, whereas Equation 4 deletes outgoing edges in its cut operation.
Section 3.3 describes removing both incoming and outgoing attention
connections. Equation 9 multiplies an additive mask by indicators,
although multiplication does not implement assignment to negative
infinity and can leave an undefined product. These are ambiguities in
the written specification, not findings about its unexamined
implementation. We use explicit mechanism replacement and entrywise mask
assignment below.

Structural causal models give the semantics of intervention and
counterfactual reasoning (Pearl, 2009; Bongers et al., 2021). Directed
constraint networks already distinguish symmetric compatibility from the
asymmetry of causal generation (Dechter & Pearl, 1991). Temporal
constraint networks provide a separate theory of date and lag
feasibility (Dechter et al., 1991). These sources motivate keeping a
clock constraint, a causal mechanism and an inference dependency as
separate objects.

Sheaf models organize local data and restrictions (Robinson, 2016).
Cellular sheaf Laplacians provide quadratic consistency energies and
harmonic extensions (Hansen & Ghrist, 2019). The global section
viewpoint also clarifies why local agreement need not provide a global
explanation (Abramsky & Brandenburger, 2011). Those foundations do not
assign causal meaning to an arbitrary restriction map. We use them to
represent declared mechanisms and to state precisely what their
compatibility establishes.

The distinction between filtering and smoothing is standard in state
estimation (Särkkä, 2013). Causal abstraction asks when changing a
representation preserves intervention predictions (Rubenstein et al.,
2017; Beckers & Halpern, 2019). Our latent compression criterion is a
variablewise, mechanism level specialization of that question. The ASE
book supplies the four base distinctions, observation stars and vertical
fibre diagrams used here (Ghosh, 2026). Persistent sheaf cohomology
concerns comparisons between sheaves and bases; it does not by itself
identify physical causation (Russold, 2022). The additional analysis
uses interval verification (Moore et al., 2009; Rump, 2010),
signed-graph balance (Harary, 1953), classical complexity reductions
(Karp, 1972) and tridiagonal inversion (Usmani, 1994). The proofs below
state their specialized scope.

## 1.2 Contributions and status

The mathematical development has five main consequences. First, a
mechanism incidence sheaf supports exact interventions and shared
circumstance counterfactuals. Second, temporal order and commuting
restriction maps impose different conditions: distinct causal routes
need not commute, while alternate coordinate descriptions of the same
restriction must. Third, global symmetric harmonic smoothing has a
precise obstruction to one way dependence. Fourth, local errors and
latent compression can be assessed against intervention semantics rather
than reconstruction accuracy alone. A fifth consequence is
computational. Interval data on gains, circumstances, weights and dates
can be propagated with certified enclosures, but only if the evaluation
keeps the dependencies that the causal construction declares (Section
11). Section 12 develops this fifth consequence into exact range
criteria, a complexity barrier, sharp temporal information bounds and
arithmetic certificates. It adds one definition and sixteen proved
statements to the earlier development.

The paper includes proofs of its stated results. Topological recursion,
truncated factorization, inverse matrix path sums, rank nullity and
posterior pushforward contraction are established foundations, restated
with attribution and adapted to this construction. The reciprocity
application, complete mechanism sheaf calculation and combined stability
statement are developed explicitly here. These formulations are not
assertions of literature wide priority. The three proposed comparative
performance claims in Section 13 are conjectures, with fixed outcomes
that would contradict them. The numerical statements of Section 11 are
exact computations or certified enclosures under stated synthetic
models. The reductions and specialized formulas of Section 12 are proved
directly. Their classical antecedents are credited; they are not claims
of literature-wide priority.

## 1.3 Structure

Sections 2 to 5 construct the mechanism sheaf, clocks, interventions and
counterfactuals. Sections 6 to 9 develop path formulas, temporal access,
stability and integration with ASE. Section 10 supplies exact examples;
Section 11 reports interval and symbolic computations. Section 12
develops the mathematics of those computations. Section 13 states the
remaining questions and falsifiable comparisons, and Section 14
concludes. Appendix A collects assumptions; Appendix B gives the
corrected reference kernel; Appendix C records its validation and
reproduction protocol.

# 2 Event contexts and their sheaf

## 2.1 Events mechanisms and declared assumptions

**Definition 2.1 (finite temporal structural model).** Let
$V = \{ 1,\ldots,n\}$ be a finite set of endogenous event variables with
a directed acyclic parent graph. Choose a topological numbering, so
$w \in pa(v)$ implies $w < v$. Let $X_{v}$ be a nonempty state space,
let $U_{j}$ be nonempty exogenous state spaces indexed by $j \in J$, and
let $J_{v} \subseteq J$. A mechanism is a total function

$$f_{v}:\prod_{w \in pa(v)}^{}X_{w} \times \prod_{j \in J_{v}}^{}U_{j} \rightarrow X_{v},\quad\quad x_{v} = f_{v}\left( x_{pa(v)},u_{J_{v}} \right).\quad\quad(2.1)$$

Several mechanisms may use the same exogenous variable. A joint law
$\mu$ on $U = \prod_{j}^{}U_{j}$ may also correlate different exogenous
coordinates. Neither independence nor causal sufficiency is assumed
unless stated. For probability results the spaces are standard Borel and
the functions are measurable. For the linear and stability results the
states have finite dimensional calibrated coordinates.

An event is a declared variable at a declared physical occasion, such as
the pressure at a particular time or the completion of a particular
operation. A persistent physical variable is unrolled into several event
variables when its history matters. A lagged feedback system can
therefore give an acyclic finite event graph even though the underlying
machine contains a feedback loop. Instantaneous cyclic equations require
separate solvability assumptions and are outside the basic theorem.

The following hypotheses have distinct roles. H1 is the finite acyclic
functional model of Definition 2.1. H2 requires a declared clock and
feasible lag constraints when a temporal claim is made. H3 fixes the
exogenous circumstances and unmodified mechanisms under a perfect
intervention. H4 requires complete mechanism scopes, including explicit
boundary parents. H5 requires valid restriction maps and commuting
representation changes. H6 supplies the Lipschitz and error assumptions
only when an approximation bound is invoked. These are conditions of a
model; their mathematical consistency does not establish their truth
about an observed system.

## 2.2 The horizontal incidence space

**Definition 2.2 (mechanism sheaf).** Introduce one variable point for
every $X_{v}$ and $U_{j}$, and one context point $c_{v}$ for every
mechanism. Let $P_{H}$ be the height one poset with $c_{v} \leq a$ when
variable $a$ belongs to the scope

$$S_{v} = \{ X_{v}\} \cup \{ X_{w}:w \in pa(v)\} \cup \{ U_{j}:j \in J_{v}\}.\quad\quad(2.2)$$

Give $P_{H}$ the Alexandrov topology of upward closed sets. Assign the
state space to a variable point and assign to $c_{v}$ the relation

$$R_{v} = \{\left( x_{v},x_{pa(v)},u_{J_{v}} \right):x_{v} = f_{v}\left( x_{pa(v)},u_{J_{v}} \right)\}.\quad\quad(2.3)$$

The map from $R_{v}$ to each incident variable space is coordinate
projection. This functor
$\mathcal{S}_{M}:P_{H} \rightarrow \mathbf{S}\mathbf{e}\mathbf{t}$ is a
sheaf on the finite Alexandrov space. Concretely, sections over an open
set are compatible tuples over its points; compatible sections on an
open cover have a unique componentwise union.

The basic open set above $c_{v}$ contains that mechanism and its
variable points. Two such opens meet at their shared variable points.
Thus horizontal overlaps say which event or exogenous quantities must
agree. They do not force one mechanism to act as a coordinate
transformation into another. A stalk is a data space, here sometimes a
set of admissible tuples rather than a vector space. A token is a moving
inference state and is not a stalk.

This definition uses a genuine, finite topological space, even when the
stalks are nonlinear. Additional topological structure on continuous
stalks and continuity of the projections can be imposed. It is not
needed for the set level gluing theorem. Linear sheaf cohomology will be
used only after a linear coefficient model has actually been specified.

**Proposition 2.3 (global sections are mechanism solutions).** There is
a canonical bijection

$$\Gamma\left( P_{H},\mathcal{S}_{M} \right) \cong \{(x,u):x_{v} = f_{v}\left( x_{pa(v)},u_{J_{v}} \right)\text{ for every }v\}.\quad\quad(2.4)$$

*Proof.* A global section gives one value at every variable point and a
tuple in every $R_{v}$. Projection agreement forces the entries of each
local tuple to equal the values at the corresponding variable points.
Membership in $R_{v}$ is then exactly the mechanism equation.
Conversely, a solution fills every relation tuple with its own
coordinates and satisfies every projection agreement. The two
constructions are inverse. ∎

The proposition is a representation theorem. It does not say that
observed values necessarily extend to a global section. Observations add
conditions to the solution set and can be contradictory. It also does
not make a probability distribution from a collection of compatible
values. The law on exogenous states is additional information.

## 2.3 Why complete contexts matter

A local model must carry its missing parents as boundary inputs. For
$Y = f(X,U)$, a context containing only $Y$ cannot retain the
conditional mechanism without either keeping an interface for $(X,U)$ or
declaring a marginalization law. Projecting away $X$ and $U$ gives the
set of possible $Y$ values, which is a different object. An ancestral
collection of endogenous variables contains its own endogenous parents;
it provides one convenient way to avoid missing boundaries, but it can
make local contexts large.

**Proposition 2.4 (pairwise projections can lose a causal mechanism).**
For binary parents $A,B$ and child $C$, the relation $C = A \oplus B$
cannot be represented by imposing only binary relations on the same
three variable spaces while preserving all its pairwise projections.

*Proof.* The relation has four triples. Each of its three pairwise
projections is the full binary square. Any binary constraint satisfied
by every valid triple must therefore accept every pair. The conjunction
of such constraints accepts all eight triples, including the four
invalid ones. A ternary relation or an additional internal variable is
necessary. ∎

Independent fair parents make every pair marginal independent in this
example, while the child is determined jointly by its parents. Pairwise
correlation is therefore insufficient even to expose this declared
mechanism. Higher order contexts carry mathematical content; they are
not merely an alternative drawing of a graph.

# 3 Physical clocks and directed paths

## 3.1 Causal paths are not coordinate restrictions

The arrows in a causal graph identify inputs of a function. The arrows
in the mechanism sheaf project a local relation to a shared variable.
Confusing these two kinds of arrow can exclude valid models.

**Lemma 3.1 (a causal diamond need not commute).** A linear causal model
on a directed diamond need not define a functor from its reachability
poset if every causal edge is interpreted as its scalar gain.

*Proof.* Consider

$$x_{2} = ax_{1} + u_{2},\quad x_{3} = cx_{1} + u_{3},\quad x_{4} = bx_{2} + dx_{3} + u_{4}.\quad\quad(3.1)$$

The two directed routes from $1$ to $4$ have gains $ba$ and $dc$. A
reachability poset has one arrow from $1$ to $4$, so functoriality would
force $ba = dc$. Structural causality imposes no such equality: the
total derivative at fixed exogenous values is $ba + dc$. Choosing
$a = 2,b = 3,c = 1,d = 4$ gives gains $6$ and $4$, with total effect
$10$. ∎

In the mechanism sheaf, restrictions from the context of $x_{4}$ merely
project its admissible tuple to $x_{2},x_{3},x_{4},u_{4}$. They impose
neither equality of the route gains nor equality of distinct causal
effects. Commuting squares remain mandatory whenever two maps represent
the same coordinate restriction or the same change of representation.
They are not a requirement that physically distinct routes have
identical effects.

![Exact diagram of causal mechanisms and horizontal relation
projections](article_media/media/rId29.png){width="6.45in"
height="3.3237674978127734in"}

*Figure 1. Left: distinct causal routes contribute separate gains to the
total response. Right: a mechanism context projects to shared variables.
The context is a relation, and its projections are compatibility maps.
The two panels depict different kinds of arrow.*

## 3.2 Temporal feasibility is an additional constraint

Suppose each event has a time
$\tau_{v} \in \left\lbrack l_{v},h_{v} \right\rbrack$, with finite real
lower and upper bounds. For each causal edge $w \rightarrow v$,
prescribe a nonnegative minimum lag $d_{wv}$ and require
$\tau_{v} \geq \tau_{w} + d_{wv}$. All quantities in this paragraph have
one declared time unit. A topological sorting checks graph acyclicity,
while the following calculation checks whether the dates and lags can
jointly hold.

**Theorem 3.2 (earliest feasible clock).** Process the DAG in
topological order and define

$$e_{v} = \max\left\{ l_{v},\ \max_{w \in pa(v)}\left( e_{w} + d_{wv} \right) \right\},\quad\quad(3.2)$$

with the parent maximum omitted at roots. The clock constraints are
feasible if and only if $e_{v} \leq h_{v}$ for every $v$. When feasible,
$e$ is the componentwise least feasible clock.

*Proof.* In any feasible assignment, a root time is at least its lower
bound. Inductively, if all parent times are at least their computed
$e_{w}$, the child time must be at least every $e_{w} + d_{wv}$ and at
least $l_{v}$. Hence every feasible clock is componentwise at least $e$.
If some $e_{v} > h_{v}$, none is feasible. Otherwise the defining maxima
ensure all lower bounds and lag inequalities, and the assumed
inequalities ensure all upper bounds; thus $e$ itself is feasible. ∎

This is the acyclic lower lag specialization of temporal constraint
propagation, not a replacement for general temporal constraint networks
(Dechter et al., 1991). Upper lag relations, disjunctions and interval
overlap predicates may require a richer constraint solver. Section 11.5
treats upper lags and dates of finite resolution with exact minimal
networks.

**Corollary 3.3 (a temporal contradiction has a path witness).** If the
test fails at $v$, some directed path $r ⤳ v$, possibly of length zero,
satisfies $l_{r} + \sum_{e \in r ⤳ v}^{}d_{e} > h_{v}$. A maximizing
predecessor pointer at each update recovers such a witness. The test and
pointer construction take $O\left( |V| + |E| \right)$ scalar operations.

*Proof.* Repeatedly expand a maximizing parent in (3.2). Acyclicity
makes the expansion terminate at a lower bound. The resulting path
realizes the computed maximum. Each edge is inspected once in the
forward pass. ∎

An earlier time does not establish a causal edge. Feasibility only says
that the declared edges are compatible with the declared temporal
evidence. Conversely, a graph extractor must not repair inconsistent
dates merely by relabeling them in a topological order. The
inconsistency should remain an explicit modeling question.

# 4 Interventions and horizontal gluing

## 4.1 Replacing a mechanism

**Definition 4.1 (perfect intervention).** For $D \subseteq V$ and
values $d_{v} \in X_{v}$, the intervention
$do\left( X_{D} = d_{D} \right)$ replaces $f_{v}$ by the constant
$d_{v}$ for $v \in D$. All other functions, variable meanings and
exogenous circumstances remain fixed. On the same incidence base,
replace $R_{v}$ at each target by

$$R_{v}^{D,d} = \{\left( x_{v},x_{pa(v)},u_{J_{v}} \right):x_{v} = d_{v}\}.\quad\quad(4.1)$$

Its former parent and exogenous input coordinates remain as unused
interface entries. This keeps a common base for comparing worlds. They
no longer determine that child. In the structural causal graph, this is
represented by removing incoming influences to the target; downstream
mechanisms still read the target value. Removing the variable or its
outgoing effects is a different operation.

**Theorem 4.2 (interventional gluing).** Under H1, H3 and H4, for every
$u \in U$ and every perfect intervention, the intervened mechanism sheaf
has exactly one global section with exogenous component $u$. Its
endogenous component is the usual recursive interventional solution
$g^{D,d}(u)$. Hence projection to $U$ is a bijection from the full
global section set to $U$.

*Proof.* Visit the endogenous variables in topological order. At a
target, set $x_{v} = d_{v}$. At every other node all parent values have
already been assigned, so totality of $f_{v}$ gives one value. Fill the
mechanism relation tuples with these values. Every tuple satisfies its
local relation and its entries agree on every overlap, hence Proposition
2.3 gives a global section. Any other section with the same $u$ has the
same target values; induction through the same order forces equality at
every remaining node. ∎

The proof uses causal mechanisms supplied to the model. It provides
neither a procedure for identifying those mechanisms from text nor a
guarantee that the extracted graph is correct. A system that lacks a
mechanism may report a set of possible sections or an unknown answer.
Inventing a total function solely to recover uniqueness would change the
scientific claim.

**Corollary 4.3 (descendant locality).** Couple the factual and
intervened solutions using the same $u$. Their values agree outside $D$
and its descendants. For several changed mechanisms, agreement holds
outside their combined descendant closure.

*Proof.* A node outside the closure is not a target and has no parent
inside the closure. Its mechanism and exogenous inputs are unchanged.
Topological induction gives the same parent values and therefore the
same output. ∎

This is a statement about coupled physical solutions. Posterior beliefs
about a nondescendant can change after observing a descendant. That
inference does not contradict the corollary, which fixes $u$ and
compares mechanisms.

## 4.2 A cohomology calculation with a restrictive interpretation

For linear models, the same global section constraints have a cellular
graph realization. We compute cohomology on this explicitly specified
graph base. Its vertices are all variable points and all mechanism
points. Each incidence is an edge with stalk equal to that variable
space. The restriction from a variable vertex is the identity; the
restriction from a mechanism vertex is the corresponding projection. Use
the relation $x_{v} = \sum_{w}^{}B_{vw}x_{w} + \sum_{j}^{}C_{vj}u_{j}$
as a vector subspace at the mechanism vertex. Affine models use their
difference or tangent coefficient spaces; an affine feasible set is not
itself a vector space.

**Theorem 4.4 (cohomology of a complete linear mechanism sheaf).** Let
every mechanism be a total linear function on its complete parent and
exogenous input spaces, with an acyclic endogenous graph. Write
$q = \sum_{j}^{}\dim U_{j}$. For the cellular incidence sheaf just
described,

$$\dim H^{0} = q,\quad\quad H^{1} = 0.\quad\quad(4.2)$$

The same dimensions hold for the homogeneous difference sheaf of an
affine model with fixed perfect interventions, retaining the unused
input interfaces as in Definition 4.1.

*Proof.* By Theorem 4.2, the space of linear solutions is parametrized
bijectively and linearly by $u$. Thus its dimension, and hence
$\dim H^{0}$, is $q$. At mechanism $v$, the relation is the graph of a
function, so its dimension is the sum of its input dimensions. The sum
of the dimensions of the incident edge stalks is that input sum plus
$\dim X_{v}$. Therefore the graph sheaf Euler characteristic is

$$\dim C^{0} - \dim C^{1} = \sum_{v}^{}\dim X_{v} + q - \sum_{v}^{}\dim X_{v} = q.\quad\quad(4.3)$$

A graph has no degree two cochains. Rank nullity gives
$\dim H^{0} - \dim H^{1} = q$, proving the claim. After a fixed
intervention, the homogeneous child variation is zero at a target, but
the local relation still has all former input coordinates free. The
dimension count is unchanged, and recursive uniqueness still
parametrizes all global variations by the exogenous ones. ∎

The incidence graph may contain cycles. A scalar four node causal
diamond with one scalar disturbance per node has twelve variable or
mechanism vertices and twelve incidence edges. Its constant coefficient
graph sheaf has one ordinary cycle. The mechanism coefficient sheaf
instead has $\dim H^{0} = 4$ and $H^{1} = 0$, because its stalk
dimensions and projections encode the functions. This calculation is
exact, not a numerical experiment.

Vanishing first cohomology in this construction does not certify causal
direction, observed data fit or interventional identification. It
follows from the complete functional model that was supplied. Additional
observation constraints can change the coefficient system and its
obstructions. Nonlinear relations require set level reasoning unless a
justified linearization is explicitly introduced.

# 5 Counterfactuals and identification

## 5.1 Sharing circumstances across worlds

An intervention distribution and an evidence conditioned counterfactual
use different exogenous laws. The former propagates the population law
$\mu$ through a replaced mechanism. The latter first uses factual
evidence to update beliefs about the circumstances of the particular
case. Replacing that posterior by a fresh population draw asks a
different question.

**Definition 5.1 (paired counterfactual sheaf).** Take a factual copy
and an intervened copy of every endogenous variable and mechanism
context, but share their exogenous variable points. The resulting sheaf
has global sections

$$\mathcal{C}_{D,d} = \{(x,x\prime,u):x = g(u),\ x\prime = g^{D,d}(u)\}.\quad\quad(5.1)$$

Equivalently, its global section set is the fibre product of the two
solution sets over $U$. Sharing the exogenous points imposes equality of
circumstances, rather than equality of the endogenous values changed by
intervention. This is a fibre product of solution diagrams, not a claim
that an endogenous time trajectory is a stalk.

**Theorem 5.2 (counterfactual semantics).** Assume the standard Borel
and measurability conditions of Definition 2.1. Let factual evidence be
a measurable random variable $E = E\left( g(U),U \right)$, and let
$q_{e}$ be a regular conditional law of $U$ given $E = e$, defined for
almost every evidence value. Then the counterfactual law for this model
is

$$\begin{matrix}
\mathcal{L}\left( X^{D,d} \mid E = e \right) & = \left( g^{D,d} \right)_{\text{\#}}q_{e}, \\
\mathbb{E}\left\lbrack \varphi\left( X^{D,d} \right) \mid E = e \right\rbrack & = \int\varphi\left( g^{D,d}(u) \right)q_{e}(du).
\end{matrix}\quad\quad(5.2)$$

for every bounded measurable $\varphi$. The paired sheaf provides the
shared circumstance coupling underlying this formula.

*Proof.* Theorem 4.2 gives one factual and one intervened solution for
every $u$, hence exactly one paired section. The intervention retains
$u$ by Definition 4.1. Conditional expectation of the measurable
function $\varphi\left( g^{D,d}(U) \right)$ given the factual evidence
is its integral against the regular conditional law. ∎

This is the standard abduction, action and prediction semantics,
expressed through local mechanism relations (Pearl, 2009). A regular
conditional law is determined only almost surely; evidence outside its
justified domain requires an additional observation model or a stated
convention. The sheaf does not supply a unique posterior at an arbitrary
impossible observation.

## 5.2 Observational agreement does not identify an intervention

**Theorem 5.3 (observational sheaf information is insufficient).** No
rule based only on an observational joint law, its local context
restrictions and a compatible ordering of event times can identify all
perfect intervention distributions in models allowing hidden common
causes.

*Proof.* Let $U$ be a fair bit and let the event $X$ precede $Y$. Model
A has $X = U$, $Y = X$. Model B has $X = U$, $Y = U$, so the exogenous
variable is shared. Both observational laws assign probability $1/2$ to
each of $(0,0)$ and $(1,1)$. Thus every observable context marginal,
restriction diagram built solely from those marginals, and invariant of
that diagram is the same. Under $do(X = 0)$, Model A has $Y = 0$ with
probability one, while Model B retains a fair $Y$. A rule receiving the
same observational input cannot return both correct answers. ∎

The theorem does not identify the two full mechanism sheaves: their
declared mechanisms differ. It identifies their observable data. A
mechanism sheaf can organize a supplied causal explanation; it cannot
certify that explanation merely because its observable restrictions
agree.

**Theorem 5.4 (identification from parent contexts under causal
sufficiency).** Suppose all endogenous states are finite, the causal DAG
is known, the exogenous variables associated with different nodes are
independent, and the observational joint law is strictly positive.
Suppose a context law is available for every child and its complete
endogenous parent set. Then these context laws identify every perfect
intervention distribution through

$$k_{v}\left( x_{v} \mid x_{pa(v)} \right) = \frac{p\left( x_{v},x_{pa(v)} \right)}{p\left( x_{pa(v)} \right)},\quad\quad(5.3)$$

$$p^{D,d}(x) = \prod_{v \in D}^{}\mathbf{1}\{ x_{v} = d_{v}\}\prod_{v \notin D}^{}k_{v}\left( x_{v} \mid x_{pa(v)} \right).\quad\quad(5.4)$$

*Proof.* Independent node disturbances in an acyclic model give the
causal factorization
$p(x) = \prod_{v}^{}k_{v}\left( x_{v} \mid x_{pa(v)} \right)$. Strict
positivity makes each context ratio well defined for every parent
assignment, including those reached after intervention. Mechanism
replacement removes the factors at the targets and clamps their values.
Sampling the remaining conditional kernels in topological order produces
(5.4), so it is normalized and is the interventional law. Every factor
is determined by the supplied context laws. ∎

Equation (5.4) is the classical truncated factorization formula, not a
conclusion from overlap consistency alone. Unknown directions,
unrepresented confounders or zero probability parent configurations
invalidate the stated identification argument. Local context coverage
can reduce the data interface needed for this formula, but does not
eliminate its assumptions.

## 5.3 Interventional laws still do not determine all counterfactuals

**Proposition 5.5 (cross world coupling is additional information).**
Even all perfect intervention distributions can agree while an evidence
conditioned counterfactual differs.

*Proof.* Let $U_{X},U_{Y}$ be independent fair bits and put $X = U_{X}$.
In Model C let $Y = U_{Y}$; in Model D let $Y = U_{Y} \oplus X$.
Observationally, $X$ and $Y$ are independent fair bits in both models.
Intervening on $X$ leaves a fair $Y$ in both, intervening on $Y$ leaves
a fair $X$, and intervening on both fixes the same point. Thus all
perfect interventions agree. Given factual evidence $X = 0,Y = 0$, both
models imply $U_{Y} = 0$. Under $do(X = 1)$, Model C then gives $Y = 0$
and Model D gives $Y = 1$. ∎

The population response kernels average away how the same disturbance
acts across different parent values. A counterfactual asks about that
coupling. The paired sheaf retains it when functional mechanisms are
specified, and should report it as underdetermined when only the kernels
are available.

# 6 Finite path formulas

## 6.1 A linear intervention resolvent

Use calibrated scalar coordinates for clarity; block vector coordinates
give the same formulas with conformable matrices. Let $x = Bx + u$,
where $B$ is strictly lower triangular in the chosen topological order.
Let $P$ be diagonal with $P_{vv} = 0$ on intervention targets and $1$
elsewhere. A vector $d$ extends the target values arbitrarily outside
$D$; only $(I - P)d$ is used.

**Theorem 6.1 (finite intervention path formula).** Define

$$R_{D} = (I - PB)^{- 1} = \sum_{k = 0}^{n - 1}(PB)^{k}.\quad\quad(6.1)$$

The factual and intervened solutions satisfy

$$x^{D} = R_{D}\left\lbrack Pu + (I - P)d \right\rbrack,\quad\quad x^{D} - x = R_{D}(I - P)(d - x).\quad\quad(6.2)$$

Each entry of $R_{D}$ is a sum of directed path gains, with incoming
steps to intervention targets removed. In particular, distinct routes
add rather than being identified.

*Proof.* Left multiplication by $P$ only zeros rows, so $PB$ is strictly
lower triangular and $(PB)^{n} = 0$. Multiplying the finite geometric
series by $I - PB$ gives the identity. The intervened equations are
$x^{D} = PBx^{D} + Pu + (I - P)d$, proving the first formula. Subtract
$x = Bx + u$, use $P(Bx + u) = Px$, and rearrange to obtain
$(I - PB)\left( x^{D} - x \right) = (I - P)(d - x)$. Expanding a matrix
product sums the gains along paths of the indicated length. ∎

The inverse in (6.1) is a matrix inverse used to solve structural
equations. It is unrelated to the sheaf inverse image $\Phi^{- 1}$ used
for a change of base. The symbols must not be used interchangeably.

**Corollary 6.2 (local computation after an intervention).** Once the
factual solution is cached, the coupled intervened solution can be
obtained by replacing target values and reevaluating only descendants in
topological order. No unaffected node needs to be recomputed. For scalar
unit cost mechanisms this takes
$O\left( \left| V_{A} \right| + \left| E_{A} \right| \right)$ operations
on the affected subgraph $A$.

*Proof.* Corollary 4.3 preserves all other values. Reevaluate each
affected mechanism once after its affected parents. The same induction
as in Theorem 4.2 proves equality with a complete solve. ∎

An edge with zero realized sensitivity can make an actual numerical
change smaller than its graph descendant closure. The closure is a safe
dependency set. Declaring a smaller set requires a mechanism argument,
not merely equality of old values.

## 6.2 Magnitude and topology answer different questions

Acyclicity makes the path series finite but does not make it small. A
chain of $m$ gains of magnitude $a > 1$ has end to end gain $a^{m}$. Its
matrix is nilpotent, with spectral radius zero, even as its finite
horizon amplification grows. Thus the existence of a topological order
is not a numerical stability certificate. Section 8 bounds that
amplification with a nonnegative path matrix.

Two different summaries are useful. Reachability says which entries of
the response must vanish. The path gain matrix quantifies the entries
that can remain. Cancellation can make a reachable total response zero,
so a zero measured derivative does not establish the absence of a causal
route. This is another reason not to infer the causal topology directly
from one attention matrix or one local Jacobian.

# 7 Harmonic reasoning and temporal direction

## 7.1 A reciprocity obstruction

Horizontal consistency energies are useful for reconciling conflicting
event descriptions. A simultaneous reconciliation is ordinarily a
smoothing operation: evidence from later observations may change earlier
estimates. We first show why imposing a causal looking edge orientation
on a symmetric quadratic does not remove that behavior.

Let $z = \left( z_{1},\ldots,z_{T} \right)$ be event time blocks, let
$G = diag\left( G_{1},\ldots,G_{T} \right) \succ 0$ be a block diagonal
observation metric, and let $L = \delta^{T}W\delta \succcurlyeq 0$ be a
linear sheaf consistency matrix. Consider the regularized harmonic
estimate

$$\begin{matrix}
\widehat{z}(y) & = \arg\min_{z}\left\{ \frac{1}{2} \parallel z - y \parallel_{G}^{2} + \frac{1}{2}z^{T}Lz \right\} = Ky, \\
K & = (G + L)^{- 1}G.
\end{matrix}\quad\quad(7.1)$$

Call the linear estimator nonanticipating if its output through block
$t$ depends only on the input through $t$. Equivalently, $K_{ij} = 0$
for $j > i$.

**Theorem 7.1 (reciprocity obstruction for a global harmonic read).** If
the estimator in (7.1) is nonanticipating in its event blocks, then $K$
is block diagonal. In fact, any $G$ self adjoint block lower triangular
operator with block diagonal $G \succ 0$ is block diagonal.

*Proof.* For (7.1),

$$GK = G(G + L)^{- 1}G = K^{T}G.\quad\quad(7.2)$$

For a general operator with this identity, blocks satisfy
$G_{i}K_{ij} = K_{ji}^{T}G_{j}$. If $i < j$, nonanticipation makes
$K_{ij} = 0$. Invertibility of $G_{j}$ then gives $K_{ji} = 0$. Both off
diagonal blocks of every pair vanish. ∎

The theorem concerns the dependency of this estimator on its observation
input. It does not prohibit directed causal models, nonlinear attention
or sequential filters. It also does not prohibit using a harmonic
smoother during abduction over a completed narrative. It says that a
single globally symmetric read on these event blocks cannot
simultaneously have nonzero directed cross time response and this strict
online dependency property.

For the energy
$\frac{1}{2} \parallel z - y \parallel^{2} + \frac{1}{2}\left( z_{2} - z_{1} \right)^{2}$,
the estimate is

$$K = \frac{1}{3}\begin{pmatrix}
2 & 1 \\
1 & 2
\end{pmatrix}.\quad\quad(7.3)$$

The estimate of the earlier variable depends on the later observation
with coefficient $1/3$. Calling the residual $z_{2} - z_{1}$ a directed
edge changes no entry of that symmetric solution operator.

## 7.2 Prefix restrictions and masks

Let $r_{t}$ restrict a full event representation to its prefix through
physical time $t$. This prefix is chosen by event identity and clock,
not by where sentences or learnable anchor slots happen to appear.
Prefixes need not be totally ordered within a simultaneous event group;
such groups can be treated as blocks.

**Proposition 7.2 (equivalent forms of nonanticipation).** A map $F$ is
nonanticipating precisely when, for every $t$, there is a map
$F^{\lbrack t\rbrack}$ satisfying

$$r_{t}F = F^{\lbrack t\rbrack}r_{t}.\quad\quad(7.4)$$

Compositions of such maps are nonanticipating. For a linear map, (7.4)
is equivalent both to block lower triangularity and to preservation of
every future perturbation subspace $N_{t} = \ker r_{t}$.

*Proof.* Existence of $F^{\lbrack t\rbrack}$ makes equal input prefixes
give equal output prefixes. Conversely, if that equality property holds,
define $F^{\lbrack t\rbrack}$ using any extension of the prefix; the
result is independent of the extension. Substitution proves closure
under composition. In the linear case, future only input perturbations
cannot affect a prefix exactly when $r_{t}FN_{t} = 0$, or
$F\left( N_{t} \right) \subseteq N_{t}$. In coordinates this zeros every
block above the diagonal. ∎

The invariant subspaces here consist of unseen future perturbations. The
subspace of vectors supported only in the past is generally not
invariant, since a past perturbation can propagate into the future. This
distinction matters when attaching temporal flags to a vertical fibre
diagram.

**Corollary 7.3 (an adapted attention layer).** Suppose all query
features at time $t$, all eligible keys and values, every attention bias
and every normalization input are functions only of the permitted
history through $t$. Suppose the read excludes later events. Then the
layer satisfies (7.4). A stack of such layers does so as well.

*Proof.* Every operation producing the output prefix has the same value
for two inputs with equal prefixes. Proposition 7.2 then applies to each
layer and its composition. ∎

This sufficient condition includes the feature extractor. A triangular
mask on event anchors cannot establish online nonanticipation when every
anchor first reads a bidirectionally encoded complete text. That full
narrative access may be appropriate for retrospective reasoning; it must
simply be described as such. Anchor index order, physical event order
and text order are three distinct orderings.

For logits $a_{ij}$ and an admissible key set $A_{i}$, the additive mask
should be defined entrywise:

$$M_{ij} = \left\{ \begin{matrix}
0 & j \in A_{i}, \\
 - \infty & j \notin A_{i},
\end{matrix} \right.\ \quad\quad\alpha_{ij} = \frac{\exp\left( a_{ij} \right)\mathbf{1}\{ j \in A_{i}\}}{\sum_{k \in A_{i}}^{}\exp\left( a_{ik} \right)}.\quad\quad(7.5)$$

At least one key or a separately specified empty read is required.
Multiplication of an additive mask by zero is not an exclusion
operation. A mask constrains computational access; it does not by itself
replace a structural equation or implement a counterfactual posterior.

## 7.3 A causally eligible harmonic frontier

One way to retain horizontal harmonic operations in an online protocol
is to freeze the accepted past and solve only for the current frontier.
Build the current observation star from that past, the present exogenous
or observation inputs, and declared boundaries. Later observations may
be used in a separate retrospective inference pass.

**Proposition 7.4 (frontier reads and fixed star descent).** For a fixed
permitted history $h$, let the frontier maps $Q_{i}$, values $o_{i}(h)$,
positive priors $w_{i}$ and scale $s > 0$ be fixed. In declared
Euclidean coordinates define

$$e_{i}(z) = \frac{1}{2} \parallel Q_{i}z - o_{i}(h) \parallel^{2},\quad E_{s}(z) = - s^{2}\log\sum_{i}^{}w_{i}\exp\left\lbrack - e_{i}(z)/s^{2} \right\rbrack,\quad\quad(7.6)$$

$$\alpha_{i}(z) = \frac{w_{i}\exp\left\lbrack - e_{i}(z)/s^{2} \right\rbrack}{\sum_{j}^{}w_{j}\exp\left\lbrack - e_{j}(z)/s^{2} \right\rbrack},\quad H = \sum_{i}^{}\alpha_{i}Q_{i}^{T}Q_{i},\quad b = \sum_{i}^{}\alpha_{i}Q_{i}^{T}o_{i}(h).\quad\quad(7.7)$$

Let $m = H^{\dagger}b + P_{\ker H}z$ be the retention read. For
$0 < \lambda < 2$,

$$E_{s}(z) - E_{s}\left( z + \lambda(m - z) \right) \geq \lambda(1 - \lambda/2) \parallel m - z \parallel_{H}^{2}.\quad\quad(7.8)$$

If star construction and initialization depend only on permitted
history, a fixed number of these updates gives a nonanticipating
frontier estimate.

*Proof.* Freeze the weights at the current query. The log sum
variational identity, or Jensen's inequality, gives a tangent majorant
$Q_{z}(x) = \sum_{i}^{}\alpha_{i}(z)e_{i}(x) + c_{z}$ with
$E_{s}(x) \leq Q_{z}(x)$ and equality at $x = z$. Its quadratic part has
normal matrix $H$, and $Hm = b$. Retention fixes the unresolved
component, so
$Q_{z}(x) - Q_{z}(m) = \frac{1}{2} \parallel x - m \parallel_{H}^{2}$.
Evaluating at $x = z$ and $x = z + \lambda(m - z)$ gives the majorant
reduction $\lambda(1 - \lambda/2) \parallel m - z \parallel_{H}^{2}$,
and hence (7.8). All inputs of the finite frontier computation are
permitted history functions, so Proposition 7.2 proves nonanticipation.
∎

This is ASE's fixed star majorization argument applied to an eligible
temporal frontier, not a new general descent theorem. It says nothing
about a common decreasing energy as physical time advances and the star
changes. A nonanticipating stopping rule may also be used, provided all
decisions depend only on the permitted history and a well defined finite
output is returned.

Soft consistency alone does not force an exact mechanism equality. Exact
structural execution uses Theorem 4.2; a frontier approximation must
either impose required equalities as hard conditions or report and bound
their residuals. Residuals acquire meaning only after units, metrics and
coordinate maps have been declared.

# 8 Stability of a counterfactual answer

## 8.1 Propagating local mechanism error

The gluing theorem is exact. An implementation additionally needs to
know how local approximation errors affect the final counterfactual. We
use scalar coordinates with absolute value, or block coordinates with
chosen norms, and sum those block norms. All constants below are taken
after calibration; otherwise gains between variables with different
units cannot be compared numerically.

Let $M$ and $\widetilde{M}$ share a finite parent DAG, exogenous
coordinate spaces and a fixed intervention. Suppose that, for
nonintervened nodes,

$$\parallel f_{v}(x,u) - f_{v}(y,v\prime) \parallel \leq \sum_{w}^{}A_{vw} \parallel x_{w} - y_{w} \parallel + \sum_{j}^{}C_{vj} \parallel u_{j} - v\prime_{j} \parallel ,\quad\quad(8.1)$$

where $A,C$ have nonnegative entries, $A_{vw} = 0$ outside parent edges,
and $\parallel f_{v} - {\widetilde{f}}_{v} \parallel \leq \eta_{v}$
uniformly on the domain used. We compare the two models on that common
domain and require that every hybrid argument used in (8.1) lies there.
Global bounds on the full state spaces are a sufficient condition. Let
$\eta_{v} = 0$ on targets with identical clamp values; differing clamps
may be included through their own $\eta_{v}$.

**Theorem 8.1 (mechanism and abduction error bound).** Define the
nonnegative finite path matrix

$$R_{A} = (I - PA)^{- 1} = \sum_{k = 0}^{n - 1}(PA)^{k}.\quad\quad(8.2)$$

For exogenous inputs $u,v\prime$, the vector of endogenous block errors
obeys

$$e \leq R_{A}\eta + R_{A}PC\,|u - v\prime|,\quad\quad(8.3)$$

where $|u - v\prime|$ denotes the vector of exogenous block distances.
Let $S$ select the reported output blocks. If factual abduction yields
laws $q,\widetilde{q}$ on the common exogenous space with finite first
moments, then the resulting counterfactual laws satisfy

$$\begin{matrix}
 & W_{1}\left( \left( Sg^{D} \right)_{\text{\#}}q,\left( S{\widetilde{g}}^{D} \right)_{\text{\#}}\widetilde{q} \right) \\
 & \quad \leq \parallel SR_{A}\eta \parallel_{1} + \parallel SR_{A}PC \parallel_{1}W_{1}\left( q,\widetilde{q} \right).
\end{matrix}\quad\quad(8.4)$$

Here the matrix norm is the induced column sum norm, and both
Wasserstein distances use the declared sums of block distances.

*Proof.* At an unchanged intervention target, the output difference is
zero. At another node, insert and subtract $f_{v}$ evaluated at the
approximate model's parent values and exogenous input. Equation (8.1)
and the uniform mechanism error give
$e \leq PAe + PC|u - v\prime| + \eta$. Since $PA$ is nilpotent, repeated
substitution terminates and proves (8.3). Couple $u \sim q$ and
$v\prime \sim \widetilde{q}$ by any joint law. The two coupled outputs
provide a candidate coupling of their pushforward laws. Multiply (8.3)
by the output selection, sum block norms and take expectations. The
exogenous term is at most
$\parallel SR_{A}PC \parallel_{1}\mathbb{E} \parallel u - v\prime \parallel_{1}$.
Infimizing over couplings, or using couplings arbitrarily close to the
infimum, proves (8.4). ∎

This separates two errors that a small horizontal residual does not
separate: an incorrect response mechanism and an incorrect posterior
over the factual circumstances. The theorem assumes the intervention
target and parent topology are correct. A missing edge, a changed
intervention meaning or a different exogenous ontology requires an
additional comparison model; it is not automatically covered by $\eta$.

**Corollary 8.2 (posterior contraction for a fixed model).** For a fixed
measurable counterfactual solution map,

$$TV\left( \left( g^{D} \right)_{\text{\#}}q,\left( g^{D} \right)_{\text{\#}}\widetilde{q} \right) \leq TV\left( q,\widetilde{q} \right).\quad\quad(8.5)$$

*Proof.* Every output event has an exogenous preimage. The difference in
its two probabilities is bounded by the supremum over all exogenous
events. ∎

Equation (8.5) controls posterior changes with the mechanism fixed. It
does not replace (8.4) when the mechanism changes. Two nearby
deterministic outputs can have total variation distance one when
represented by distinct point masses, which is why a Wasserstein
distance is useful for the latter comparison.

## 8.2 Precision can be allocated along causal paths

For a scalar output selected by row $s$, let
$a_{v} = \left( sR_{A} \right)_{v}$. The mechanism contribution is
$\sum_{v}^{}a_{v}\eta_{v}$. A local tolerance at a node with large
$a_{v}$ has a larger downstream effect. This gives a principled reason
to refine some contexts more than others. It also gives a simple
stopping criterion: a requested output tolerance is established only
when the propagated mechanism allowance and posterior allowance fit
within it.

These coefficients are computed from conservative local Lipschitz
bounds, not from a fitted attention weight alone. If a local bound is
valid only near one trajectory, the claimed certificate must ensure that
the approximate trajectory and all compared parent tuples remain in that
neighborhood. Otherwise the domain assumption of Theorem 8.1 has not
been verified.

# 9 Integration with ASE and latent reasoning

## 9.1 Keeping the bases and clocks distinct

ASE distinguishes a latent cover base, a variable context base, the
inference layer order and the query dependent observation star. The
present mechanism incidence space is a declared model of the variable
context base. It may coexist with a cover of continuous latent space; it
does not automatically equal that cover or its nerve. Physical event
time labels variables inside the horizontal problem. It is not the
inference layer coordinate.

  -------------------------------------------------------------------------
  **Object**    **Role in the present         **Required distinction**
                construction**                
  ------------- ----------------------------- -----------------------------
  Latent cover  Overlapping coordinate        A learned region is not
                regions used by an encoder or automatically a mechanism
                local read                    context

  Variable      Mechanism relations and their Causal edge gains are not
  context base  shared event and exogenous    restriction maps
                variables                     

  Inference     Successive computations or    Layer advancement is not
  layer order   representation changes        physical time advancement

  Observation   Records eligible for one      A query's retrieval graph is
  star          token's harmonic read         not the causal DAG

  Physical      Dates and lags attached to    Chronology alone does not
  event clock   event variables               establish causation
  -------------------------------------------------------------------------

**Proposition 9.1 (restriction of an intervention).** Let
$A \subseteq V$ be ancestral, retain all its mechanism scopes and
required exogenous points, and restrict a full solution to that
submodel. Restricting after an intervention on $D$ gives the same
endogenous result as solving the submodel with intervention on
$D \cap A$ at the corresponding clamp values.

*Proof.* Every endogenous parent of a node in $A$ is also in $A$. Thus
all mechanisms used to compute that submodel are present, and no target
outside $A$ is an ancestor of its nodes. The recursive assignments, with
shared $u$, coincide node by node. ∎

For a nonancestral context, the statement requires retained boundary
values and their intervention dependent changes. Dropping the parent of
$Y = X$ and then intervening on that omitted $X$ is an immediate failure
case. The remedy is an explicit interface, not an arbitrary extra causal
edge between contexts.

## 9.2 Commuting inference changes

Let $\ell = 0,\ldots,L$ count inference steps. This counter describes
computation and need not match the layer numbering of the ASE book. A
representation change has a continuous base map
$\Phi_{\ell}:P_{\ell + 1} \rightarrow P_{\ell}$. The old sheaf on the
new base is the inverse image $\Phi_{\ell}^{- 1}\mathcal{S}_{\ell}$. A
valid coefficient update is a sheaf morphism

$$T_{\ell}:\Phi_{\ell}^{- 1}\mathcal{S}_{\ell} \rightarrow \mathcal{S}_{\ell + 1}.\quad\quad(9.1)$$

For finite Alexandrov bases, the stalk of the inverse image at $p$ is
the old stalk at $\Phi_{\ell}(p)$. Naturality requires every restriction
square to commute:

$$r_{pq}^{\ell + 1}\, T_{\ell,p} = T_{\ell,q}\, r_{\Phi_{\ell}(p)\Phi_{\ell}(q)}^{\ell},\quad\quad p \leq q.\quad\quad(9.2)$$

**Proposition 9.2 (a compatible layer update preserves sections).** A
map satisfying (9.1) and (9.2) sends a pulled back compatible section to
a compatible section on the new base. This fact alone does not imply
physical causal correctness or online nonanticipation.

*Proof.* For a section $s$, apply (9.2) to $s_{\Phi_{\ell}(p)}$. Its old
restriction is $s_{\Phi_{\ell}(q)}$, so the new stalk values
$T_{\ell,p}s_{\Phi_{\ell}(p)}$ satisfy every new restriction. To see the
limitation, an internally consistent sheaf can encode either
observationally equivalent model in Theorem 5.3. Likewise, a consistent
joint estimate can use the symmetric smoother of (7.3), whose earlier
output depends on later evidence. ∎

A token traversing these inference layers carries a vertical fibre
diagram of data spaces and maps. Barcodes apply when the relevant
diagram is linear, or after a justified linearization. They do not
encode the meanings of interventions unless those meanings are retained
as additional structure. For an online linear implementation,
Proposition 7.2 requires preservation of the future perturbation flag at
every layer. Ordinary interval bars of an unlabelled layer diagram
forget that flag.

Inference refinement can therefore be studied vertically while temporal
mechanisms remain horizontal. A backward inferential update is
permissible in a retrospective task; a perfect intervention remains a
change to the selected horizontal relations. This separation is
compatible with ASE's vertical acyclicity result and does not attach a
new causal interpretation to total stack cohomology.

## 9.3 When a latent compression preserves interventions

Implicit reasoning in continuous latents is useful only if the retained
coordinates preserve the response distinctions needed by the task. A
reconstruction loss cannot establish that property on its own. The
following elementary factorization criterion supplies an exact target.
We state it for finite state spaces so that measurable quotient issues
do not obscure the causal requirement.

**Theorem 9.3 (local criterion for exact causal compression).** Let
$h_{v}:X_{v} \twoheadrightarrow Z_{v}$ be surjective maps and keep the
exogenous coordinates unchanged. There exist abstract local mechanisms
${\bar{f}}_{v}$ satisfying

$$h_{v}f_{v}\left( x_{pa(v)},u \right) = {\bar{f}}_{v}\left( h_{pa(v)}x_{pa(v)},u \right)\quad\quad(9.3)$$

for every parent tuple and exogenous input if and only if, for each $v$,
the left side has the same value for any two parent tuples with the same
encoded parent tuple. Under this condition, for every perfect
intervention,

$$h\left( g^{D,d}(u) \right) = {\bar{g}}^{D,h(d)}(u).\quad\quad(9.4)$$

The pointwise encoders and their maps on mechanism tuples define a
morphism of the corresponding sheaf diagrams on the common incidence
base.

*Proof.* Necessity follows because the right side of (9.3) depends only
on encoded parents and $u$. For sufficiency, lift an abstract parent
tuple through the surjective parent maps and define ${\bar{f}}_{v}$ to
be the encoded child produced by that lift. The stated constancy makes
the definition independent of the lift. At an intervention target,
encoding the clamp gives the abstract clamp. At every other node,
topological induction and (9.3) give equal encoded outputs. This proves
(9.4). Mapping each relation tuple coordinatewise sends it into the
abstract relation and commutes with every coordinate projection, which
gives the sheaf morphism. ∎

The theorem is a local, variablewise criterion within causal abstraction
theory (Rubenstein et al., 2017; Beckers & Halpern, 2019). More general
abstractions can combine variables or restrict the intervention family.
For continuous spaces the same set level factorization holds, but
measurability or continuity of the descended functions must be
justified, for example by an appropriate quotient property. A
discontinuous choice of representatives does not automatically provide a
continuous latent mechanism.

**Corollary 9.4 (approximate compression allowance).** Suppose abstract
mechanisms have nonnegative parent Lipschitz matrix $\bar{A}$ on a
common calibrated domain and the defect in (9.3) is at most
$\varepsilon_{v}$ at each nonintervened node. Let target encodings be
exact. With the same exogenous input,

$$\parallel h\left( g^{D,d} \right) - {\bar{g}}^{D,h(d)} \parallel_{blocks} \leq \left( I - P\bar{A} \right)^{- 1}P\varepsilon.\quad\quad(9.5)$$

Here the left side denotes the vector of block distances and the
inequality is componentwise.

*Proof.* Compare the encoded concrete output with the abstract mechanism
evaluated at its encoded concrete parents, then compare those parents
with the abstract solution parents. The local defect and Lipschitz
inequality give $e \leq P\bar{A}e + P\varepsilon$. The finite path
expansion proves (9.5). ∎

Counterfactual prediction also needs the correct abducted law. Theorem
9.3 preserves the forward map for a shared $u$, and hence its
pushforward for a shared posterior. It does not prove that compressing
factual evidence preserves that posterior. A sufficient separate
condition is conditional sufficiency, $U\bot E \mid h_{E}(E)$, under
which the full and encoded evidence yield the same posterior almost
surely. If this fails, Section 8 supplies a place to account for
posterior error, provided an actual bound is available.

The criterion gives a direct interpretation for a Sep Latent style
architecture. Separate latent coordinates can represent event content,
exogenous circumstances, clock information and evidence provenance.
Local decoders must satisfy (9.3), or report the defect used in (9.5).
Spatial separation of latent fields alone does not establish these
equations. Invertible coordinate changes preserve mechanism distinctions
automatically when every mechanism is transformed with them; lossy
compression has the stronger obligation expressed by the theorem.

# 10 Exact examples and an execution protocol

## 10.1 A four event diamond

Consider the calibrated model

$$x_{1} = u_{1},\quad x_{2} = 2x_{1} + u_{2},\quad x_{3} = x_{1} + u_{3},\quad x_{4} = 3x_{2} + 4x_{3} + u_{4}.\quad\quad(10.1)$$

Let $u = (1,0,0,0)$. The factual section is $(1,2,1,10)$. Intervening
with $do\left( x_{2} = 3 \right)$ gives $(1,3,1,13)$. The first and
third variables are unchanged because they lie outside the target's
descendant closure. Intervening instead with
$do\left( x_{1} = 2 \right)$ gives $(2,4,2,20)$. The two routes from the
first variable contribute $6$ and $4$ to its total gain of $10$.

Assign lower time bounds $(0,0,0,0)$ and edge lags
$d_{12} = 2,d_{13} = 1,d_{24} = 3,d_{34} = 4$. Equation (3.2) gives
earliest times $(0,2,1,5)$. Upper bounds $(0,3,2,8)$ permit this clock.
Changing the fourth upper bound to $4$ produces a contradiction; the
path $1 \rightarrow 2 \rightarrow 4$, or
$1 \rightarrow 3 \rightarrow 4$, requires time at least $5$. Rearranging
a narrative cannot repair that inequality.

For this model, $A = |B| = B$ and $C = I$. Without intervention, the
last row of $(I - A)^{- 1}$ is $(10,3,4,1)$. Uniform mechanism errors of
at most $0.01$ at every node give an output allowance of $0.18$. If the
exogenous posterior error is at most $0.02$ in the declared $W_{1}$
metric, its output contribution is at most $10(0.02) = 0.20$. The
combined bound is $0.38$.

With an exact intervention at node 2, its mechanism error is zero. The
last row of $R_{A}$ becomes $(4,3,4,1)$, while the last row of $R_{A}PC$
is $(4,0,4,1)$. The mechanism contribution is then $0.09$, and the
posterior contribution is at most $4(0.02) = 0.08$, giving $0.17$. These
are exact evaluations of a conservative inequality, not measured errors
or benchmark results. Section 11.1 recomputes all of these values in
exact arithmetic.

![Analytic local mechanism error contributions before and after an
intervention](article_media/media/rId56.png){width="6.45in"
height="3.0204133858267714in"}

*Figure 2. Exact contributions to the output mechanism allowance in the
diamond. Every active mechanism has error bound 0.01 in calibrated
units. The intervention at node 2 is exact, so it contributes no
mechanism error and removes the route through that node from upstream
disturbance propagation. The plot evaluates Theorem 8.1; it contains no
sampled data.*

## 10.2 Abduction with a shared confounder

Let $X = U$ and $Y = aX + U + \epsilon$, with independent centered
disturbances $U,\epsilon$. Then
$\mathbb{E}\lbrack Y \mid X = x\rbrack = (a + 1)x$, while
$\mathbb{E}\left\lbrack Y \mid do(X = d) \right\rbrack = ad$. The
observational association combines the direct gain with a shared cause.

For a factual observation $X = x,Y = y$, the exact structural
circumstances are $U = x$ and $\epsilon = y - (a + 1)x$. Keeping those
circumstances under $do(X = d)$ gives

$$Y^{do(X = d)} = y + a(d - x).\quad\quad(10.2)$$

For example, $a = 2,x = 1,y = 4,d = 3$ gives counterfactual output $8$,
while the population intervention mean is $6$. The difference is the
retained circumstances of the observed case. Deleting text connections
or resampling the disturbances does not perform this calculation. When
observations are noisy, an observation likelihood replaces exact
inversion and produces the posterior in Theorem 5.2.

## 10.3 A representation failure

Let $X \in \{ 0,1\}$ and $Y = X$, with $h_{X}(0) = h_{X}(1) = 0$ and
$h_{Y}$ the identity. The same abstract parent value would have to
produce both encoded child values, so (9.3) fails. No abstract local
deterministic mechanism on those encoded states can preserve both
interventions on $X$.

A nontrivial success is $X \in \{ 0,1,2,3\}$ and $Y = X\ mod\ 2$, with
$h_{X}(X) = X\ mod\ 2$ and $h_{Y}$ the identity. The abstract mechanism
is $\bar{Y} = \bar{X}$. Every intervention on the original $X$ maps to
its parity clamp and preserves the reported output. The discarded
distinction is irrelevant to this mechanism and this output, although
another downstream mechanism could make it relevant again.

## 10.4 An execution protocol for a causal horizontal layer

An implementation can follow the steps below without conflating
compatibility with identification.

1.  Parse event identities, possible time intervals, candidate parents,
    mechanism types and evidence provenance. Preserve uncertainty about
    an edge rather than silently treating every extracted edge as
    established.
2.  Declare the task as retrospective explanation, online prediction,
    population intervention or evidence conditioned counterfactual. This
    determines the permitted information and the exogenous law.
3.  Check graph acyclicity and the appropriate temporal constraints.
    Retain the path witness for an infeasible clock. Retain missing
    mechanism inputs as boundary variables.
4.  Construct complete local relation stalks and coordinate projection
    maps. Use higher order factors when required. Declare units before
    any residual or weight is formed.
5.  For a counterfactual, abduct the factual exogenous posterior using
    an explicit observation model. Clone endogenous variables and share
    the exogenous coordinates.
6.  Replace the target relations and recursively solve the affected
    subgraph. Use eligible harmonic frontier reads only as declared
    approximations, with hard equality checks where required.
7.  Validate horizontal restrictions and every layer representation
    square. If an online result is claimed, validate the separate prefix
    dependency condition through feature extraction, retrieval and
    normalization.
8.  Report the answer with its model assumptions, intervention meaning,
    identification status and any propagated error bound. If several
    admissible mechanisms produce different answers, return the
    resulting range or an unknown answer.

Removing a mechanism factor as a software shortcut can leave a child
unconstrained. Removing an attention edge can leave the original
structural equation unchanged. The execution record therefore needs the
replaced equation, not only a new graph image or mask.

# 11 Interval numerics and symbolic certificates

The preceding sections are exact statements about declared models. An
implementation receives gains, dates and lags known only to some
resolution. This section treats that resolution with interval arithmetic
and exact rational computation. The corrected immutable C# kernel is
described in Appendix B. Its finite interval results enclose the same
expression on the same data under the arithmetic contract proved in
Section 12.5; unsupported nonfinite results are rejected. An independent
Python program recomputes the original 71 output lines, using exact
fractions and SymPy for identities and matrices, rational interval
arithmetic for enclosures, and vertex enumeration for ranges. All pass.
Section 12 adds 27 checked output lines. These are exact constructions
or enclosures under specified synthetic models, rather than measurements
of trained-system performance.

## 11.1 The examples recomputed exactly

The kernel recomputes every numerical example of Sections 2 to 10 in
rational arithmetic (Table 1). Each value agrees with the text. Two
identities are checked as identities, not single values: the inverse
(6.1) equals its finite path sum before and after the intervention at
node 2, and the difference formula (6.2) holds exactly for
$do\left( x_{2} = 3 \right)$. The cohomology of Section 4.2 is computed
as an exact rank of the coboundary matrix rather than through the Euler
characteristic. For 300 further random acyclic linear models with two to
nine endogenous nodes, rational gains and up to two shared exogenous
inputs, every model gave $\dim H^{0} = q$ and $H^{1} = 0$. The constant
coefficient sheaf on the same incidence graphs had a nonzero first Betti
number in 208 of these models, up to 20. Cycles in the incidence graph
therefore coexist with vanishing mechanism cohomology, as Theorem 4.4
states.

*Table 1. Exact recomputation of the paper's examples by the C# kernel.*

  -----------------------------------------------------------------------------------------
  **Quantity**                             **Section**   **Exact value**
  ---------------------------------------- ------------- ----------------------------------
  Factual section;                         10.1          (1, 2, 1, 10); (1, 3, 1, 13); (2,
  $do\left( x_{2} = 3 \right)$;                          4, 2, 20)
  $do\left( x_{1} = 2 \right)$                           

  Route gains and total effect             3.1, 10.1     6 and 4; 10

  Earliest clock; witness when $h_{4} = 4$ 3.2, 10.1     (0, 2, 1, 5); path 1 → 2 → 4

  Last rows of $R$, $R_{D}$ and $R_{D}PC$  8.1, 10.1     (10, 3, 4, 1); (4, 3, 4, 1); (4,
  for $do\left( x_{2} \right)$                           0, 4, 1)

  Inverse equals path sum; difference      6.1           both hold exactly
  formula (6.2)                                          

  Error allowance, mechanism + posterior = 10.1          9/50 + 1/5 = 19/50; after
  total                                                  $do\left( x_{2} \right)$: 9/100 +
                                                         2/25 = 17/100

  Counterfactual and population            10.2          8 and 6
  intervention mean                                      

  Harmonic read $K$ at unit weight         7.1           rows (2/3, 1/3) and (1/3, 2/3)

  $C = A \oplus B$: pairwise projection    2.3           4, 4, 4; 8 against 4
  sizes; triples admitted by pairwise                    
  relations                                              

  Models A and B:                          5.2           1, 1/2
  $P\left( Y = 0 \mid do(X = 0) \right)$                 

  Models C and D: interventions;           5.3           agree in all nine regimes; 0 and 1
  counterfactual $Y$                                     

  Diamond incidence sheaf: $\dim C^{0}$,   4.2           16, 12, 12, 4, 0; 1
  $\dim C^{1}$, rank, $\dim H^{0}$,                      
  $\dim H^{1}$; constant sheaf $H^{1}$                   

  Compression criterion (9.3): identity    10.3          fails; holds
  encoding; parity encoding                              
  -----------------------------------------------------------------------------------------

## 11.2 Interval gains and path polynomials

Suppose each nonintervened gain $B_{vw}$ is known only to lie in an
interval
$\left\lbrack {\underline{B}}_{vw},{\overline{B}}_{vw} \right\rbrack$.
The quantity of interest is the range of an entry of $R_{D}$ over the
box of admissible gains. Two facts make this range computable.

**Proposition 11.1 (path polynomials are multilinear).** For a finite
acyclic model, each entry $\left( R_{D} \right)_{vw}$ is a polynomial in
the gains in which every gain has degree at most one and every
coefficient is $0$ or $1$. Over a box of gains its minimum and maximum
are attained at vertices of the box. Here the gains are independent edge
coordinates; a tied parameterization needs the additional constraints of
Proposition 12.3.

*Proof.* By Theorem 6.1 the entry is the sum, over directed paths from
$w$ to $v$ in the graph of $PB$, of the products of their gains. A
directed path in an acyclic graph visits each node at most once and so
uses each edge at most once. Distinct paths between the same endpoints
have distinct edge sets, so each monomial occurs once. A function that
is affine in each coordinate separately attains its extremes over an
interval of that coordinate at an endpoint. Moving an extremizer to an
endpoint one coordinate at a time does not change its value and ends at
a vertex. ∎

**Proposition 11.2 (nonnegative gains are enclosed exactly).** If every
gain interval contains only nonnegative numbers, interval forward
substitution $r_{s} = 1$, $r_{v} = \sum_{w}^{}B_{vw}r_{w}$ in
topological order returns exactly
$\left\lbrack R_{D}\left( \underline{B} \right)_{vs},\ R_{D}\left( \overline{B} \right)_{vs} \right\rbrack$,
the range of Proposition 11.1. The same holds for any expression of the
entry built from sums and products with nonnegative coefficients.
Exactness here refers to ideal real interval arithmetic; outward
rounding may add slack.

*Proof.* Inductively, every computed $r_{w}$ equals
$\left\lbrack R_{D}\left( \underline{B} \right)_{ws},\ R_{D}\left( \overline{B} \right)_{ws} \right\rbrack$,
an interval of nonnegative numbers. For nonnegative intervals
$\lbrack a,b\rbrack \cdot \lbrack c,d\rbrack = \lbrack ac,bd\rbrack$,
and sums add endpoints. The lower endpoint is therefore computed from
lower gains only and the upper endpoint from upper gains only. Both are
attained at the corresponding vertices, so the enclosure equals the
range. ∎

With gains of both signs the form of the expression matters. Interval
arithmetic treats every occurrence of a quantity as independent, so a
gain used twice can widen the result; this is the dependency problem of
interval analysis (Moore et al., 2009). In the shared-prefix model
$x_{2} = ax_{1}$, $x_{3} = bx_{2}$, $x_{4} = cx_{2} + dx_{3}$, the
response of $x_{4}$ to $x_{1}$ is $ac + abd$. With
$a \in \lbrack 1/2,3/2\rbrack$, $b \in \lbrack - 1,1\rbrack$ and
$c,d \in \lbrack 1,2\rbrack$, forward substitution evaluates
$c \cdot a + d \cdot (b \cdot a)$ with $a$ twice and returns
$\lbrack - 2.5,\ 6\rbrack$. The factorized form $a(c + bd)$ uses each
gain once and returns the exact range $\lbrack - 3/2,\ 6\rbrack$. The
diamond of Section 10.1 has no shared edge between its routes. Its
polynomial $ab + cd$ is single-use, and with gains of width one around
$(2,3,1,4)$ forward substitution returns the exact range
$\lbrack 11/2,\ 31/2\rbrack$.

To measure how much the form matters, the kernel generated 300 random
acyclic models on seven nodes for each of two gain regimes. Each model
had at least two directed paths from the first to the last node and at
most 14 gains on those paths. Gains were intervals of width $1/2$
centered on multiples of $1/8$, with centers in $\lbrack - 1,1\rbrack$
for the sign-indefinite regime and in $\lbrack 1/2,3/2\rbrack$ for the
nonnegative regime. The models had on average 4.1 paths and 6.8 relevant
gains, and at most 13 paths. Exact ranges came from vertex enumeration.
Here every vertex value is a short dyadic sum and is exact in double
precision; a rational recomputation confirmed this for all 487 models
with at most nine gains. Every enclosure contained the exact range, and
every path polynomial was multilinear (Table 2). With nonnegative gains
all three forms were exact up to outward rounding, as Proposition 11.2
requires. With sign-indefinite gains, forward substitution was exact in
52.7% of models, 7.4% too wide on average and up to 1.79 times too wide.
The expanded path sum was worse. A greedy Horner form, which repeatedly
factors out the gain shared by the most monomials, was best but still
not always exact (Figure 3b). Lemma 12.15 now proves the dyadic claim
for all 600 models by a bit budget, rather than relying only on the 487
explicit rational repetitions.

*Table 2. Enclosures of the source-to-sink total effect in 300 random
acyclic models per regime. Width ratios are to the exact range; exact
means a ratio of at most* $1 + 10^{- 9}$*.*

  ------------------------------------------------------------------------------------------------
  **Gain regime**            **Interval      **Exact        **Mean      **Median**   **Largest**
                             form**          enclosures**   width                    
                                                            ratio**                  
  -------------------------- --------------- -------------- ----------- ------------ -------------
  in $\lbrack - 1,1\rbrack$  forward         52.7%          1.074       1.000        1.788
                             substitution                                            

  in $\lbrack - 1,1\rbrack$  expanded path   36.3%          1.147       1.059        2.684
                             sum                                                     

  in $\lbrack - 1,1\rbrack$  greedy Horner   63.7%          1.048       1.000        1.729
                             form                                                    

  in                         forward         100.0%         1.000       1.000        1.000
  $\lbrack 1/2,3/2\rbrack$   substitution                                            

  in                         expanded path   100.0%         1.000       1.000        1.000
  $\lbrack 1/2,3/2\rbrack$   sum                                                     

  in                         greedy Horner   100.0%         1.000       1.000        1.000
  $\lbrack 1/2,3/2\rbrack$   form                                                    
  ------------------------------------------------------------------------------------------------

The exact range is always available from Proposition 11.1, at the cost
of $2^{m}$ evaluations for $m$ gains. Computing the exact range of a
polynomial over a box is NP-hard in general (Kreinovich et al., 1998),
so the vertex method is practical only for small path sets. A certified
implementation should report which form produced an enclosure and
whether that form is known to be exact. Two-terminal series-parallel
route structures give a sufficient condition: series composition
multiplies and parallel composition adds, so their path polynomials have
a form in which every gain occurs once, and interval evaluation of that
form is exact. Theorem 12.6 establishes NP-hardness directly for this
path-response family. Theorem 12.5 gives an additional exact regime, and
Proposition 12.4 rules out a universal finite relative-width bound for
forward substitution.

## 11.3 Counterfactual intervals and the shared circumstance

Return to Section 10.2 with interval data
$a \in \lbrack 1.9,2.1\rbrack$, $x \in \lbrack 0.95,1.05\rbrack$,
$y \in \lbrack 3.9,4.1\rbrack$ and $d = 3$. In the form (10.2),
$y + a(d - x)$, each quantity occurs once, so interval evaluation gives
the exact range $\lbrack 7.605,\ 8.405\rbrack$, of width 0.80 (Moore et
al., 2009). Executing abduction, action and prediction as separate
interval steps gives $U \in x$, $\epsilon \in y - (a + 1)x$ and
$Y\prime \in ad + U + \epsilon = \lbrack 7.295,\ 8.695\rbrack$, of width
1.40. The expanded polynomial $y + 3a - ax$ gives
$\lbrack 7.395,\ 8.595\rbrack$. The three expressions are algebraically
identical; the kernel and SymPy both confirm the identity.

**Proposition 11.3 (stepwise interval evaluation forgets occurrence
ties).** Suppose a counterfactual calculation is expressed using
addition, subtraction, multiplication and division with every interval
denominator excluding zero. In ideal interval arithmetic, unfolding the
stepwise calculation into an expression tree and replacing each repeated
leaf quantity by an independent copy gives exactly the range represented
by natural interval evaluation. It contains the range with the evidence,
mechanisms and circumstances tied as declared, and can be strictly
larger.

*Proof.* Apply the expression-tree induction of Theorem 12.2. The tied
assignments form a subset of the occurrence box, while the example gives
strict inclusion. This numerical relaxation need not correspond solely
to making causal worlds independent: shared evidence and parameter
identities can also be forgotten. ∎

In the example the circumstance $U = x$ appears in both worlds. The
stepwise evaluation lets the factual $x$ and the shared $U$ vary
independently, which is the loss of coupling that Proposition 5.5 warns
about, now appearing as the dependency problem. The kernel confirms that
the stepwise enclosure equals the enclosure with explicitly decoupled
copies. Even so, the exact counterfactual range is disjoint from the
population intervention mean $\lbrack 5.7,\ 6.3\rbrack$ under these
data, so the difference between the two questions in Section 10.2
survives the stated uncertainty (Figure 3a). This diagnoses the interval
relaxation; it does not alter the SCM or supply a new cross-world law.

![](article_media/media/image1.png){width="6.45in"
height="2.6721423884514435in"}

*Figure 3. (a) The counterfactual of Section 10.2 under interval data,
evaluated in four algebraically equivalent orders; numbers give interval
widths and the dotted line marks the point counterfactual 8. Only the
single-use form attains the exact range. (b) Width of three enclosures
of the total effect relative to the exact range in the sign-indefinite
regime, grouped by the number of directed paths; dots are means and
lines reach the largest ratio. With nonnegative gains every form is
exact (dashed line).*

## 11.4 The anticipation of a symmetric read in closed form

Theorem 7.1 shows that a symmetric harmonic read on event blocks cannot
be nonanticipating. Symbolic computation gives the size of its
anticipation for the path energy
$\frac{1}{2} \parallel z - y \parallel^{2} + \frac{w}{2}\sum_{t}^{}\left( z_{t + 1} - z_{t} \right)^{2}$
on $T$ scalar blocks.

**Proposition 11.4 (anticipation of the path smoother).** Let
$K(w) = \left( I + wL_{T} \right)^{- 1}$, where $L_{T}$ is the path
Laplacian and $w > 0$. For T ≥ 2 the following formulas hold.

$$K_{1T}(w) = K_{T1}(w) = \frac{w^{T - 1}}{p_{T}(w)},\quad\quad p_{T}(w) = \det\left( I + wL_{T} \right) = \sum_{k = 0}^{T - 1}c_{k}w^{k},\quad\quad(11.1)$$

with nonnegative integer coefficients, $c_{0} = 1$ and $c_{T - 1} = T$.
Hence $K_{1T}$ is strictly increasing in $w$ and tends to $1/T$ as
$w \rightarrow \infty$. At unit weight,

$$p_{T}(1) = F_{2T},\quad\quad K_{1T}(1) = \frac{1}{F_{2T}},\quad\quad 1 - K_{11}(1) = \frac{F_{2T - 2}}{F_{2T}} \rightarrow \varphi^{- 2} = \frac{3 - \sqrt{5}}{2},\quad\quad(11.2)$$

where $F_{k}$ are the Fibonacci numbers and $\varphi$ is the golden
ratio.

*Proof.* The matrix is tridiagonal with off-diagonal entries $- w$.
Deleting row $T$ and column $1$ leaves a triangular matrix with diagonal
$- w$, so the $(T,1)$ cofactor is $w^{T - 1}$; symmetry gives the
$(1,T)$ entry. The coefficient $c_{k}$ is the sum of the $k \times k$
principal minors of $L_{T}$, which are nonnegative because $L_{T}$ is
positive semidefinite. Further $c_{T} = \det L_{T} = 0$, and by the
matrix tree theorem each $(T - 1) \times (T - 1)$ principal minor equals
the number of spanning trees of the path, which is one, so
$c_{T - 1} = T$. Dividing by $w^{T - 1}$ gives
$1/K_{1T} = \sum_{k}^{}c_{k}w^{k - T + 1}$, a constant $T$ plus terms
that strictly decrease, including $w^{1 - T}$; this gives monotonicity
and the limit. At $w = 1$ the diagonal is $(2,3,\ldots,3,2)$. The
leading minors with diagonal $(2,3,\ldots,3)$ satisfy $a_{0} = 1$,
$a_{1} = 2$ and $a_{k} = 3a_{k - 1} - a_{k - 2}$, so
$a_{k} = F_{2k + 1}$. Expanding along the last row gives
$p_{T}(1) = 2a_{T - 1} - a_{T - 2} = F_{2T}$. The $(1,1)$ cofactor is
$a_{T - 1} = F_{2T - 1}$ by symmetry, which gives the last identity. ∎

The kernel derived $p_{T}$ symbolically for the values of $T$ in Table 3
and checked (11.1) against exact inverses at $w \in \{ 1/2,1,2\}$. It
checked (11.2) exactly for every $T$ from 2 to 30; SymPy confirms both
and the sign of the derivative. At unit weight the future share is 1/3
for two events and approaches 38.2% as the history length grows. Its
direct dependence on the last observation, $1/F_{2T}$, decays
geometrically but never vanishes. Because $K_{1T}$ is monotone, an
interval of weights gives an exact interval of anticipation, shown in
the last column. A consistency weight therefore cannot make this read
online; it only changes how much of the future the read uses. For T = 1,
K = \[1\], the determinant is one and future weight is zero; strict
monotonicity is inapplicable.

*Table 3. Symbolic anticipation of the path smoother. The last column is
the exact range of* $K_{1T}$ *for weights in* $\lbrack 1/2,2\rbrack$*.*

  -------------------------------------------------------------------------------------------------------
  $T$   **Coefficients**           $K_{1T}(1)$   $1 - K_{11}(1)$   $K_{1T}$ **for**
        $c_{0},\ldots,c_{T - 1}$                                   $w \in \lbrack 1/2,2\rbrack$
        **of** $p_{T}$                                             
  ----- -------------------------- ------------- ----------------- --------------------------------------
  2     1, 2                       1/3           1/3               $\lbrack 1/4,\ 2/5\rbrack$

  3     1, 4, 3                    1/8           3/8               $\lbrack 1/15,\ 4/21\rbrack$

  4     1, 6, 10, 4                1/21          8/21              $\lbrack 1/56,\ 8/85\rbrack$

  5     1, 8, 21, 20, 5            1/55          21/55             $\lbrack 1/209,\ 16/341\rbrack$

  6     1, 10, 36, 56, 35, 6       1/144         55/144            $\lbrack 1/780,\ 32/1365\rbrack$

  8     1, 14, 78, 220, 330, 252,  1/987         377/987           $\lbrack 1/10864,\ 128/21845\rbrack$
        84, 8                                                      
  -------------------------------------------------------------------------------------------------------

## 11.5 Dates with finite resolution

Theorem 3.2 handles exact dates and minimum lags. Text often gives a
date only to the year or the month, and lags can also have upper limits.
A year-only date is an interval of one year, not the instant at its
start. Yang et al. (2026, Appendix F.4.1) convert year-only times to
floating-point years with zero fractional part and normalize them to
$\lbrack 0,1\rbrack$. That encoding keeps a representative point and
discards the width. We do not evaluate their model; we examine what each
encoding implies for the clock constraints of Section 3.2. The
calculations use closed hulls of calendar periods; Section 12.4
specifies the resulting endpoint convention and quantization criterion.

Interval dates with lower and upper lags are difference constraints
$t_{j} - t_{i} \leq c$. They are consistent exactly when the distance
graph has no negative cycle, and all-pairs shortest distances $d(i,j)$
give the minimal network (Dechter et al., 1991). With an origin node $0$
at time zero, the tightest window for event $v$ is
$\left\lbrack - d(v,0),\ d(0,v) \right\rbrack$, and event $a$ certainly
precedes $b$ when $- d(b,a) > 0$. The kernel computes these distances
exactly in rational arithmetic by the Floyd--Warshall recursion. For the
diamond of Section 10.1 with upper bound $4$ on the fourth date, the
network has the negative cycle
$t_{4} \rightarrow t_{2} \rightarrow t_{1} \rightarrow t_{0} \rightarrow t_{4}$
of length $- 1$, the same contradiction as the witness of Corollary 3.3.
With upper bound $8$ and maximum lags $5/2$, $3/2$, $4$ and $9/2$ on the
four edges, the windows of events 2 to 4 tighten to
$\lbrack 2,5/2\rbrack$, $\lbrack 1,3/2\rbrack$ and $\lbrack 5,6\rbrack$.

The kernel then generated 2,000 synthetic narratives of six events. True
times lie on a grid of $1/48$ year, with successive gaps up to $38/48$
year. Each pair of events is joined by a declared lag with probability
$1/2$. Its minimum is the true lag rounded down to a quarter year, and
half of these lags also have a maximum half a year above the minimum.
Each date is reported to the year with probability $0.7$ and otherwise
to the month. Every declared constraint is true of the true times. Table
4 compares the two encodings. Treating the start of each period as an
exact date produced a lag contradiction in 93.2% of narratives, although
every narrative is consistent. With interval dates all networks were
consistent and contained the true times, as they must. The minimal
networks ordered 82.0% of the pairs of distinct times with no wrong
order. Among pairs sharing the same reported date interval, the lags
ordered 42.8%, which no comparison of reported dates can do.

A start-of-period representative can happen to be feasible, but does not
conservatively represent every time in a period of positive width.
Interval dates combine resolution and lag constraints into windows, and
consistency and order then become checkable claims. Step 3 of the
protocol in Section 10.4 should therefore check temporal constraints
against interval dates rather than representative points.

*Table 4. Start-of-period point dates against interval dates in 2,000
synthetic narratives of six events.*

  -----------------------------------------------------------------------
  **Quantity**               **Start-of-period   **Interval dates and
                             point dates**       minimal network**
  -------------------------- ------------------- ------------------------
  Narratives with a lag      1,864 of 2,000      0 of 2,000
  contradiction (all         (93.2%)             
  constraints are true)                          

  True times inside the      not applicable      2,000 of 2,000
  computed windows                               narratives

  Pairs of distinct times    ties in 4,580 of    24,391 of 29,732
  with a certified order     29,732 pairs        (82.0%); 0 wrong

  Pairs sharing the same     indistinguishable   1,841 of 4,298 ordered
  reported date interval                         by lags (42.8%)

  Mean window width (years)  0.724 as reported   0.427
  -----------------------------------------------------------------------

## 11.6 Multiplicative masks in floating point

Section 1.1 noted that Equation 9 of Yang et al. (2026) multiplies an
additive mask by indicators. The kernel evaluated that formula on a mask
of the form of their Equation 6, with two text tokens and three event
queries, cutting the second query. Under IEEE 754 arithmetic the product
$- \infty \cdot 0$ is undefined (IEEE, 2019). Four logits became NaN,
and four of the five softmax rows were undefined. The five entries in
the target's row and column that were already $0$ stayed $0$, so the
last query still gave the target weight 0.2. If $- \infty$ is
represented by a large finite negative number, as implementations often
do, the products are $0$ and four previously excluded entries reopen.
The target then reads a later query with weight 0.2, and a text token
reads the target with weight 1/3. Entrywise assignment as in (7.5) gives
the target weight 0 in every other row; the target's own row becomes
empty and needs the separately specified empty read. These are
consequences of the printed formula. The authors' code was not examined.

# 12 Mathematics of dependency preserving computation

The computations of Section 11 raise three mathematical questions. Which
equalities are discarded when an interval grows? When does a range admit
a cheap exact computation? What information about an unseen future can a
symmetric read recover? This section answers these questions for
explicit finite models. The uncertainty sets are sets of possible
values, not probability laws. A narrow interval is not a posterior
credible interval unless a separate probabilistic argument supplies that
interpretation.

## 12.1 Shared quantities and occurrence constraints

**Definition 12.1 (dependency preserving uncertainty diagram).** Assign
units to the uncertain quantities and require every operation to respect
them. Let $B = \prod_{i = 1}^{m}\left\lbrack l_{i},u_{i} \right\rbrack$
contain one coordinate for each independently uncertain quantity. Unfold
a finite scalar expression into a tree. If quantity $i$ occurs at leaves
in a set $O_{i}$, introduce a coordinate $z_{o}$ at every such leaf. The
occurrence box and its tied subset are

$$\begin{matrix}
B_{occ} & = \prod_{i}^{}{\prod_{o \in O_{i}}^{}\left\lbrack l_{i},u_{i} \right\rbrack}, \\
\Delta_{B} & = \{ z \in B_{occ}:z_{o} = z_{o\prime}\text{ whenever }o,o\prime \in O_{i}\}.
\end{matrix}\quad\quad(12.1)$$

The tree expression on $B_{occ}$, together with these equality
constraints and any additional declared parameter relations, is the
uncertainty diagram. It preserves dependencies when its feasible
assignments retain every declared equality. For a counterfactual, shared
exogenous circumstances and shared mechanism parameters have the same
identity in both worlds. Unrelated uncertainties receive separate
coordinates.

This construction has the same incidence interpretation as Definition
2.2. A context contains the graph of an elementary operation; variable
points identify occurrences of the same quantity. Compatible sections
satisfy both the arithmetic relations and the identities. Splitting a
shared variable point into independent copies removes a compatibility
condition and enlarges the set of feasible assignments. An interval
enclosure of that enlarged set changes the numerical relaxation; it does
not change the declared structural causal model.

**Theorem 12.2 (exactness after occurrence independence).** Consider an
expression tree using addition, subtraction, multiplication and
division. Assume that each interval denominator encountered by natural
interval evaluation excludes zero. In ideal real interval arithmetic,
the result is exactly the range of the unfolded expression on $B_{occ}$.
Consequently it contains the range on $\Delta_{B}$.

*Proof.* A leaf has its prescribed interval as its exact range. Suppose
the assertion holds for the two children of an operation. Their
occurrence coordinates are disjoint, so every pair of values in their
two ranges is simultaneously attainable. The range of the parent is
therefore the range of that operation on the Cartesian product of the
two child intervals. For addition and subtraction, its extrema are the
familiar endpoint sums and differences. For multiplication and division
away from zero, extrema are among the four endpoint combinations. The
operation is continuous on the relevant rectangle, so its image is an
interval and contains every value between the extrema. These are exactly
the natural interval formulas. Induction proves equality at the root.
Finally $\Delta_{B} \subseteq B_{occ}$, proving inclusion of the tied
range. ∎

The theorem concerns these elementary expression trees, not arbitrary
interval algorithms or arbitrary nonlinear functions. Outward rounding
can enlarge the ideal result further. Proposition 11.3 is a special
case: stepwise abduction can discard identities involving the evidence,
exogenous variables and parameters. Calling this simply a change to
independent causal worlds is too narrow; the actual operation is the
loss of declared occurrence equalities.

**Proposition 12.3 (tied parameters can create interior extrema).**
Multi-affinity in separate edge gains does not imply that extrema occur
at endpoints of an underlying parameter that ties those gains.

*Proof.* On a two-edge path, set the gains to $\theta$ and $1 - \theta$,
with $0 \leq \theta \leq 1$. The response is $\theta(1 - \theta)$, whose
exact range is $\lbrack 0,1/4\rbrack$. Both parameter endpoints give
zero and the maximum occurs at $\theta = 1/2$. Treating the two gains as
independent coordinates in $\lbrack 0,1\rbrack^{2}$ instead gives the
range $\lbrack 0,1\rbrack$. The response is multi-affine in the two edge
coordinates but quadratic after their relation is substituted. ∎

Thus Proposition 11.1 applies to a box in independently varying edge
coordinates. Shared learned parameters, conservation laws or geometric
chart relations may replace that box by a constrained subset. A box
remains an enclosure, but its corners need not solve the constrained
problem.

**Proposition 12.4 (unbounded inflation from a shared prefix).** There
is no finite universal upper bound on the ratio of the width of natural
interval forward substitution to the positive exact width of an acyclic
intervention response.

*Proof.* Let a source perturbation be one. Pass it through a gain
$a \in \lbrack - 1,1\rbrack$, copy that result into two branches with
fixed gains $+ 1$ and $- 1$, add the branches, and pass their sum
through $b \in \lbrack - 1,1\rbrack$. Add a direct source-to-output gain
$\zeta \in \lbrack - \varepsilon,\varepsilon\rbrack$, where
$\varepsilon > 0$. The exact response is

$$p(a,b,\zeta) = ab - ab + \zeta = \zeta,\quad\quad rangep = \lbrack - \varepsilon,\varepsilon\rbrack.\quad\quad(12.2)$$

Natural interval forward substitution adds two copies of
$\lbrack - 1,1\rbrack$ to obtain $\lbrack - 2,2\rbrack$. Multiplication
by $\lbrack - 1,1\rbrack$ leaves this interval unchanged, and addition
of $\zeta$ gives $\lbrack - 2 - \varepsilon,2 + \varepsilon\rbrack$. The
ideal width ratio is
$(4 + 2\varepsilon)/(2\varepsilon) = 1 + 2/\varepsilon$, which diverges
as $\varepsilon \downarrow 0$. The construction is a finite DAG with six
vertices and seven edges. ∎

The kernel checks ratios of 201 at $\varepsilon = 1/100$ and 2,000,001
at $\varepsilon = 1/1,000,000$; floating-point enclosures add only
rounding slack. These are explicit cancellation examples, not a claim
about the frequency of such cases. The modest maximum in Table 2 cannot
supply a general worst-case guarantee. Algebraic collection after
specializing the fixed gains eliminates the cancellation here, but that
observation does not make greedy factorization universally exact.

## 12.2 A sign criterion and an exact complexity barrier

Call the union of the directed source-to-terminal paths the route core.
Remove edges whose gain interval is identically zero. Suppose each
remaining gain is written $g_{e} = \sigma_{e}a_{e}$, with fixed
$\sigma_{e} \in \{ - 1,1\}$ and independent amplitudes
$a_{e} \in \left\lbrack {\underline{a}}_{e},{\overline{a}}_{e} \right\rbrack \subseteq \lbrack 0,\infty)$.
A formal path sign is the product of its $\sigma_{e}$, including when an
admissible amplitude happens to be zero.

**Theorem 12.5 (sign coherence and exact forward ranges).** Assume the
route core is nonempty. The following conditions are equivalent:

**Condition 1.** Every directed source-to-terminal path has the same
formal sign $\tau$.

**Condition 2.** There are vertex signs $\eta_{v} \in \{ - 1,1\}$, with
$\eta_{s} = 1$, such that every route-core edge $v \rightarrow w$ has
$\sigma_{vw} = \eta_{v}\eta_{w}$.

Under these conditions, if $p(a)$ is the nonnegative-amplitude path sum,
the exact signed response range is

$$hull\{\tau p\left( \underline{a} \right),\tau p\left( \overline{a} \right)\}.\quad\quad(12.3)$$

Natural interval forward substitution returns this range in ideal
interval arithmetic.

*Proof.* Assume condition 1. Fix a vertex $v$ on a source-to-terminal
path and any directed suffix from $v$ to the terminal. Every
source-to-$v$ prefix can be appended to this suffix: a repeated vertex
would create a directed cycle. All resulting complete paths have the
same sign, so all prefixes to $v$ have the same sign. Define $\eta_{v}$
to be that sign and $\eta_{s} = 1$. Extending a prefix by an edge gives
$\eta_{w} = \eta_{v}\sigma_{vw}$, which is condition 2. Conversely, the
product of $\eta_{v}\eta_{w}$ along any complete path telescopes to
$\eta_{s}\eta_{t} = \eta_{t}$, proving condition 1.

For the range statement, transform the propagated response by
${\widetilde{r}}_{v} = \eta_{v}r_{v}$. Every transformed edge gain is
$a_{e} \geq 0$. Proposition 11.2 gives exact lower and upper responses
from the two amplitude endpoints. Returning to
$r_{t} = \eta_{t}{\widetilde{r}}_{t}$ gives (12.3). At each original
node, all signed summands have the same prescribed sign, so sign
reversal commutes with the endpoint computation; the original forward
interval pass has the same result. ∎

The vertex signs are the scalar sign gauge of a balanced signed graph
(Harary, 1953), restricted here to a directed route core. They make all
edge signs positive; they do not make different causal route gains
equal. The theorem therefore does not impose the invalid causal
commutation rejected by Lemma 3.1. Its condition is sufficient for
interval exactness, not necessary: a read-once polynomial such as
$ab - cd$ can also have an exact natural interval range.

The positive result has a sharp computational limit. General polynomial
complexity alone would not establish hardness for the restricted path
polynomials of this paper. The next construction does.

**Theorem 12.6 (NP-hardness of an exact acyclic response range).**
Computing the exact range of a scalar source-to-terminal response over
independent gain intervals is NP-hard, even on a four-layer DAG in which
every source-to-terminal path has three edges. In the family constructed
below, deciding whether the maximum exceeds a supplied integer threshold
is NP-complete.

*Proof.* Reduce weighted MAX-CUT with nonnegative integer weights, using
its classical NP-completeness (Karp, 1972). Let $H = (W,F)$ be an
undirected graph with edge weights $a_{e}$. Form four layers: a source
$s$, one vertex node $v_{i}$ for each $i \in W$, one edge node $w_{e}$
for each $e \in F$, and terminal $t$. Put the uncertain gain
$x_{i} \in \lbrack - 1,1\rbrack$ on $s \rightarrow v_{i}$. Orient each
undirected edge arbitrarily, say $e = (i,j)$, and put fixed gains
$+ a_{e}$ on $v_{i} \rightarrow w_{e}$ and $- a_{e}$ on
$v_{j} \rightarrow w_{e}$. Put an uncertain gain
$y_{e} \in \lbrack - 1,1\rbrack$ on $w_{e} \rightarrow t$. The response
to a unit source is

$$p(x,y) = \sum_{e = (i,j) \in F}^{}a_{e}y_{e}\left( x_{i} - x_{j} \right).\quad\quad(12.4)$$

For a fixed $x$, maximizing over $y$ gives
$\sum_{e}^{}a_{e}\left| x_{i} - x_{j} \right|$. Alternatively,
Proposition 11.1 moves a global maximizer to
$x_{i},y_{e} \in \{ - 1,1\}$. At such a vertex,
$\left| x_{i} - x_{j} \right|$ equals two exactly on edges crossing the
cut defined by the signs of $x$. Hence

$$\max p = 2\, MaxCut(H,a),\quad\quad\min p = - 2\, MaxCut(H,a).\quad\quad(12.5)$$

The minimum follows by reversing all $y_{e}$. The construction has
polynomial size and preserves polynomial bit length. An exact
response-range algorithm would solve weighted MAX-CUT. For the threshold
problem in this family, corner signs provide a polynomial certificate,
and the resulting integer response can be evaluated in polynomial time.
The problem is therefore also in NP. ∎

Here "exceeds a supplied integer threshold" uses a strict inequality;
replacing it by "is at least" gives the same decision complexity by
shifting an integer threshold. The kernel and an independent NumPy
enumeration verify (12.5) for all 74 simple graphs on two, three and
four labeled vertices. The triangle gives $\lbrack - 4,4\rbrack$. This
finite check illustrates the reduction; the proof covers arbitrary
nonnegative integer weights and graph sizes.

For every fixed gain choice, the causal model in the reduction still has
a unique solution, and its complete linear mechanism sheaf still has
$H^{1} = 0$ by Theorem 4.4. Pointwise solvability and vanishing
cohomology do not make optimization over an uncertainty family easy.
Unless P equals NP, no general polynomial-time exact factorization
method can remove this difficulty.

## 12.3 The amount of future information in a harmonic read

The reciprocity result of Theorem 7.1 gives a qualitative obstruction.
For scalar graph smoothing, positivity strengthens it to a quantitative
information statement. Let $L$ be the Laplacian of a connected
undirected graph with positive edge weights, let
$G = diag\left( g_{1},\ldots,g_{n} \right)$ with every $g_{i} > 0$, and
put $K(w) = (G + wL)^{- 1}G$.

**Theorem 12.7 (positive reversible harmonic read).** For $n \geq 2$ and
$w > 0$, every entry of $K(w)$ is strictly positive,

$$\begin{matrix}
K(w)\mathbf{1} & = \mathbf{1},\quad\quad g_{i}K_{ij}(w) = g_{j}K_{ji}(w), \\
\lim_{w \rightarrow \infty}K_{ij}(w) & = \frac{g_{j}}{\sum_{k}^{}g_{k}}.
\end{matrix}\quad\quad(12.6)$$

Each diagonal entry strictly decreases with $w$. If block $i$ is the
earliest event and all the other input blocks are later, the total
future weight $1 - K_{ii}(w)$ strictly increases from zero to
$1 - g_{i}/\sum_{k}^{}g_{k}$.

*Proof.* Write $H = G + wL$. It is symmetric positive definite. If
$Hz = b \geq 0$ and $z_{i} < 0$ is a minimum, then
$(Hz)_{i} = g_{i}z_{i} + w\sum_{j}^{}a_{ij}\left( z_{i} - z_{j} \right) < 0$,
a contradiction. Thus $H^{- 1} \geq 0$. For $b = e_{j}$, a zero
component would force all its neighbors to be zero; connectivity
propagates this to $j$, contradicting $(Hz)_{j} = 1$. Therefore
$H^{- 1}$ and $K = H^{- 1}G$ are strictly positive. Since
$H\mathbf{1} = G\mathbf{1}$, the rows of $K$ sum to one. Symmetry of
$H^{- 1}$ proves detailed balance.

Differentiating the inverse gives

$$\frac{dK_{ii}}{dw} = - g_{i}\left( H^{- 1}e_{i} \right)^{\top}L\left( H^{- 1}e_{i} \right) < 0.\quad\quad(12.7)$$

Equality would require $H^{- 1}e_{i}$ to be constant on the connected
graph. Multiplying by $H$ would then make $e_{i}$ a multiple of
$G\mathbf{1}$, impossible when $n \geq 2$. Finally whiten $L$ as
$G^{- 1/2}LG^{- 1/2}$. Its nullspace is spanned by $G^{1/2}\mathbf{1}$.
The resolvent tends to the orthogonal projection onto this nullspace.
Multiplication by $G^{- 1/2}$ and $G^{1/2}$ yields the limit in (12.6).
At $w = 0$, $K = I$, proving the remaining endpoints. ∎

This theorem uses a scalar graph Laplacian with positive weights. It is
not a positivity theorem for arbitrary sheaf restrictions, matrix-valued
transports or signed connection Laplacians. Those can have a different
order structure.

For the path and $G = I$, the whole first row is explicit. The formula
is a specialization of tridiagonal inverse theory (Usmani, 1994),
derived directly here to expose its temporal meaning.

**Theorem 12.8 (first row and unseen tail of the path resolvent).** For
$T \geq 1$, $w > 0$ and $K = \left( I + wL_{T} \right)^{- 1}$, define

$$\rho = \frac{1 + 2w - \sqrt{1 + 4w}}{2w} = \frac{\sqrt{1 + 4w} - 1}{\sqrt{1 + 4w} + 1},\quad\quad 0 < \rho < 1.\quad\quad(12.8)$$

Then, for $1 \leq j \leq T$,

$$K_{1j} = \frac{(1 - \rho)\left( \rho^{j - 1} + \rho^{2T - j} \right)}{1 - \rho^{2T}}.\quad\quad(12.9)$$

If observations $1,\ldots,m + 1$ are available, with
$0 \leq m \leq T - 1$, the total weight on unseen observations is

$$q_{T,m} = \sum_{j = m + 2}^{T}K_{1j} = \frac{\rho^{m + 1} - \rho^{2T - m - 1}}{1 - \rho^{2T}}.\quad\quad(12.10)$$

In particular,

$$\begin{matrix}
1 - K_{11} & = \frac{\rho - \rho^{2T - 1}}{1 - \rho^{2T}} \rightarrow \rho, \\
K_{1T} & = \frac{\left( 1 - \rho^{2} \right)\rho^{T - 1}}{1 - \rho^{2T}}.
\end{matrix}\quad\quad(12.11)$$

*Proof.* Equation (12.8) gives $w = \rho/(1 - \rho)^{2}$. A column
solving the homogeneous interior equation of $I + wL_{T}$ satisfies
$- wv_{j - 1} + (1 + 2w)v_{j} - wv_{j + 1} = 0$, whose characteristic
roots are $\rho$ and $\rho^{- 1}$. The numerator in (12.9) combines the
two solutions and satisfies the right endpoint condition
$v_{T + 1} = v_{T}$. Summing its entries gives one. All components of
$\left( I + wL_{T} \right)v$ except possibly the first are zero; their
total is $\mathbf{1}^{\top}v = 1$, so the first is one. Thus $v$ is the
first inverse column; symmetry gives the first row. For $T = 1$, (12.9)
directly equals one. Summing the two geometric series beyond $m + 1$
gives (12.10). Setting $m = 0$ and $j = T$ gives (12.11). ∎

**Theorem 12.9 (sharp prefix minimax error).** Fix the observed prefix
in Theorem 12.8. Suppose the unseen scalar observations vary
independently in $\lbrack a,b\rbrack$, with diameter $D = b - a > 0$.
Set $S = \sum_{j = 1}^{m + 1}K_{1j}y_{j}$. The full smoother's earliest
output has exactly the conditional range

$$\left\lbrack S + aq_{T,m},\, S + bq_{T,m} \right\rbrack.\quad\quad(12.12)$$

Among all deterministic estimates depending only on that prefix, the
minimum worst-case absolute error relative to the full smoother is

$$\mathcal{R}_{T,m} = \frac{D}{2}q_{T,m}.\quad\quad(12.13)$$

*Proof.* All weights are positive. The smallest and largest permitted
full outputs are attained by setting every unseen observation to $a$ and
to $b$, respectively, and continuity gives the intermediate values. A
prefix-only estimate must return the same number for those two
completions. Its distance from at least one endpoint is at least half
their separation. The midpoint of (12.12) attains this bound for every
admissible completion. ∎

The target in this theorem is a retrospective smoother, not the true
physical state. A causal predictor may deliberately have another target.
Mechanism or clock constraints can also restrict the set of future
completions and reduce the minimax radius. The theorem is exact for the
stated independent completion box.

**Corollary 12.10 (a uniform lookahead budget).** For every admissible
$T,m$,

$$0 \leq \mathcal{R}_{T,m} \leq \frac{D}{2}\rho^{m + 1},\quad\quad\sup_{T \geq m + 1}\mathcal{R}_{T,m} = \frac{D}{2}\rho^{m + 1}.\quad\quad(12.14)$$

Consequently a horizon-uniform absolute-error guarantee $\varepsilon$ is
possible exactly when $\rho^{m + 1} \leq 2\varepsilon/D$, using the
minimax midpoint estimate.

*Proof.* In (12.10), $\rho^{2T - m - 1} \geq \rho^{m + 1}\rho^{2T}$, so
$q_{T,m} \leq \rho^{m + 1}$. For fixed $m$, taking
$T \rightarrow \infty$ makes $q_{T,m} \rightarrow \rho^{m + 1}$. Apply
Theorem 12.9. ∎

At unit weight $\rho = \left( 3 - \sqrt{5} \right)/2$. With no
lookahead, the limiting minimax error is 0.190983006 times the data
diameter. For $T = 4$, the exact errors as $m = 0,1,2,3$ are
$D(4/21,1/14,1/42,0)$. A guarantee of $0.01D$ for every horizon needs at
least four later observations: the bounds at $m = 3$ and $m = 4$ are
respectively 0.010643118$D$ and 0.004065309$D$. These decimal displays
are rounded from rational brackets for $\sqrt{5}$ in the result file.

![Analytic sharp prefix risk for path smoothing at unit weight, by
history length and
lookahead.](article_media/media/image2.png){width="6.45in"
height="3.0010115923009626in"}

*Figure 4. Analytic sharp error relative to the full path smoother at
unit weight. (a) Finite-history error with m later observations; dotted
lines show the uniform limits. (b) Uniform error falls geometrically; m
= 4 is the first lookahead meeting a 1% guarantee. All errors are
normalized by the future-data diameter.*

**Proposition 12.11 (individual future weights need not increase).**
Although the total future weight in Theorem 12.7 and the endpoint weight
in Proposition 11.4 increase with $w$, an individual off-diagonal entry
need not do so.

*Proof.* For a four-vertex path, direct inversion gives

$$K_{12}(w) = \frac{w\left( 1 + 3w + w^{2} \right)}{1 + 6w + 10w^{2} + 4w^{3}}.\quad\quad(12.15)$$

At $w = 10$ this is $1310/5061 > 1/4$, whereas its limit as
$w \rightarrow \infty$ is $1/4$. Hence it cannot be nondecreasing. It
also starts at zero and is positive for $w > 0$, so it cannot be
nonincreasing. ∎

For the constant scalar sheaf on a path, $H^{1} = 0$ because the path
has no cycle. Nevertheless every off-diagonal harmonic weight is
positive and the prefix risk above is nonzero. Thus absence of a
cohomological obstruction does not certify nonanticipation. Cohomology,
arithmetic enclosure and information access answer different questions.

## 12.4 Feasible clocks and checkable certificates

The interval clock calculation is a projection of one feasible set, not
independent narrowing of unrelated dates. Write every constraint as
$\tau_{j} - \tau_{i} \leq c_{ij}$, with origin $\tau_{0} = 0$. Assume
finite lower and upper dates for every event, so all-pairs distances are
finite when the system is consistent.

**Theorem 12.12 (clock feasibility and attainable distance bounds).** A
finite difference-constraint system is feasible if and only if its
distance graph has no negative cycle. In a feasible system its
shortest-path distances give the exact attainable bounds

$$- d(b,a) \leq \tau_{b} - \tau_{a} \leq d(a,b),\quad\quad - d(v,0) \leq \tau_{v} \leq d(0,v).\quad\quad(12.16)$$

A feasible clock certifies consistency. A negative cycle, listed with
its original constraint weights, certifies inconsistency.

*Proof.* Summing the inequalities around a negative cycle would give
$0 < 0$, so no feasible clock can exist. Conversely, add a virtual
source with zero-cost edges to all vertices. In the absence of a
negative cycle, shortest distances from that source satisfy every edge
inequality; subtracting the origin value makes $\tau_{0} = 0$.

Every path from $a$ to $b$ bounds $\tau_{b} - \tau_{a}$ by its total
cost, proving the upper distance bound; reverse the vertices for the
lower bound. To prove attainment, fix any anchor $a$ and set
$\pi_{j}^{a} = d(a,j) - d(a,0)$. The shortest-path triangle inequality
gives $\pi_{j}^{a} - \pi_{i}^{a} \leq c_{ij}$, and $\pi_{0}^{a} = 0$.
Since $d(a,a) = 0$, this feasible clock attains
$\pi_{b}^{a} - \pi_{a}^{a} = d(a,b)$. The clock anchored at $b$ attains
the lower bound. Taking an endpoint to be the origin gives the date
windows. The two proposed certificates can be checked directly by
substitution and cycle summation. ∎

This is the classical minimal-network result for simple temporal
problems (Dechter et al., 1991), with explicit attainment witnesses.
Each window is an exact marginal projection. Their Cartesian product
need not be feasible: $\tau_{1} = \tau_{2} \in \lbrack 0,1\rbrack$ gives
two windows $\lbrack 0,1\rbrack$, but the corner $(0,1)$ violates
equality. Keeping only the windows loses a dependency in exactly the
sense of Definition 12.1.

**Proposition 12.13 (uncertain constraint coefficients).** Suppose the
upper bound on each difference constraint is independently uncertain,
$c_{e} \in \left\lbrack {\underline{c}}_{e},{\overline{c}}_{e} \right\rbrack$.
Let $F(c)$ denote its feasible clock set. Then

$$F\left( \underline{c} \right) \subseteq F(c) \subseteq F\left( \overline{c} \right).\quad\quad(12.17)$$

Some admissible coefficient choice is feasible exactly when
$F\left( \overline{c} \right)$ is nonempty. Every admissible choice is
feasible exactly when $F\left( \underline{c} \right)$ is nonempty; in
that case a single clock works for all choices. If the upper system is
inconsistent, all choices are inconsistent. If the lower is inconsistent
and the upper is consistent, both feasible and infeasible choices occur.

*Proof.* Increasing any upper bound weakens a constraint, proving the
inclusions. Both endpoint vectors belong to the coefficient box. These
inclusions and endpoint membership give all the quantifier statements. ∎

These coefficient uncertainties are distinct from the unknown event
times represented by date intervals. A useful robust inconsistency
certificate is a cycle $C$ with
$\sum_{e \in C}^{}\left( c_{e} + \varepsilon_{e} \right) < 0$: it
remains negative under every perturbation
$\left| \delta c_{e} \right| \leq \varepsilon_{e}$. The kernel example
has original cycle cost $- 1$ and total allowance $1/2$, leaving an
upper cost $- 1/2$.

**Proposition 12.14 (when point-date quantization creates a
violation).** Write true times as $\tau_{i} = p_{i} + r_{i}$, with
representative dates $p_{i}$ and residuals $0 \leq r_{i} \leq w_{i}$.
Suppose the true gap $g = \tau_{j} - \tau_{i}$ satisfies
$L \leq g \leq U$. The representative gap violates the lower bound
exactly when $r_{j} - r_{i} > g - L$, and violates the upper bound
exactly when $r_{i} - r_{j} > U - g$.

*Proof.* Since $p_{j} - p_{i} = g + r_{i} - r_{j}$, subtract $L$ or $U$
and rearrange the strict inequalities. ∎

For example, $\tau_{i} = 0.1$, $\tau_{j} = 0.9$ and $L = 0.5$ are
feasible, while using the common start-of-year representative
$p_{i} = p_{j} = 0$ creates a false lower-lag violation. Point
representatives can also happen to be feasible; positive period width
does not by itself make every point calculation wrong. What fails is
conservativity for every time in the reported period.

Calendar periods are usually half-open. The kernel uses their closed
hulls, which contain the actual periods and are therefore conservative
for non-strict difference constraints. An endpoint-only distinction can
remain undecided in this representation. A complete treatment of strict
calendar boundaries would require strict inequalities or an explicit
boundary convention. The zero false interval contradictions in the
2,000-narrative study follow from the construction: each true clock
belongs to its reported date hull and satisfies every generated lag. The
order-certification rate is a useful measurement of that synthetic
family; consistency itself is guaranteed by its design.

## 12.5 What an arithmetic certificate actually proves

Exact formulas, exact range algorithms and sound floating-point
realization are separate requirements. The numerical work can
distinguish them without claiming that line-by-line agreement verifies
an unrestricted software API. Interval and verified numerical methods
provide the general foundation (Moore et al., 2009; Rump, 2010).

**Lemma 12.15 (a dyadic budget for exact vertex evaluation).** Consider
a path polynomial with at most $P$ monomials, each of length at most
$h$. Suppose each vertex gain has form $a_{e}/2^{q}$, with $a_{e}$ an
integer, $\left| a_{e} \right| \leq M$ and $q \geq 0$. Let
$C = \max\left( M,2^{q} \right)$. If

$$PC^{h} < 2^{53},\quad\quad qh \leq 1074,\quad\quad(12.18)$$

then evaluating the expanded path products and their sum in binary64 is
exact, including every intermediate product and partial sum.

*Proof.* Put every path product on the common grid $2^{- qh}$. A product
with $k \leq h$ factors has scaled numerator of magnitude at most
$M^{k}2^{q(h - k)} \leq C^{h}$. The same bound holds for partial
products after scaling them to this grid. Every partial sum has scaled
numerator magnitude at most $PC^{h}$. These integers have fewer than 54
significant binary digits and their grid exponent is no smaller than
$- 1074$, so all the exact intermediate values are representable in
binary64. The magnitude bound also excludes overflow. Correctly rounded
multiplication and addition must return these representable exact
results. ∎

For all 600 models of Table 2 one may take $q = 3$, $M = 14$, $h = 6$
and $P = 32$, since a seven-node ordered DAG has at most $2^{5}$
source-to-terminal paths. Thus $PC^{h} = 240,945,152 < 2^{28} < 2^{53}$
and $qh = 18$. This proves exactness of every binary64 vertex oracle in
that study, including the cases not covered by its 487 explicit rational
repetitions. It does not prove that floating-point vertex enumeration is
exact for general inputs.

The rational conversion in the earlier kernel required a correction. A
dyadic rational need not be representable as a binary64 point, and
converting its arbitrary-precision numerator and denominator separately
can overflow before their ratio is taken. Moreover a containment
predicate must compare with the rational itself, not its rounded
approximation.

**Theorem 12.16 (adjacent binary64 brackets of an exact rational).** For
a positive rational $q$ not exceeding the largest finite binary64
number, set

$$e = \lfloor\log_{2}q\rfloor,\quad\quad h = 2^{\max(e - 52, - 1074)},\quad\quad k = \lfloor q/h\rfloor.\quad\quad(12.19)$$

Compute the quotient and remainder by integer arithmetic. If the
remainder is zero, return $\lbrack kh,kh\rbrack$. Otherwise return
$\left\lbrack kh,(k + 1)h \right\rbrack$. These are adjacent finite
binary64 brackets containing $q$. Zero is exact and negative inputs are
handled by reflection. Rationals beyond the finite range have no
enclosure with two finite endpoints.

*Proof.* Above the subnormal range, $h$ is the binary64 spacing in the
binade containing $q$; below it, $h = 2^{- 1074}$ is the subnormal
spacing. The integer $k$ is less than $2^{53}$ and therefore converts
exactly to binary64. Scaling by the specified power of two gives the
exact representable number $kh$. Integer division proves
$kh \leq q < (k + 1)h$, with equality at the left exactly when the
remainder is zero. At a binade boundary, $(k + 1)h$ is the first value
of the next binade and remains the successor of $kh$. Since $q$ does not
exceed the largest finite number, a nonzero remainder cannot require an
endpoint above that number. The corresponding statement for negative
rationals follows by order-reversing reflection. ∎

The implementation obtains the binary exponent by exact integer bit
lengths and a comparison, not a floating-point logarithm. It obtains the
upper bracket with the next representable number. In particular,
$2^{- 1024}$ is representable, but the earlier conversion of its
denominator $2^{1024}$ overflowed and returned the point zero. The
earlier approximate containment predicate accepted that false enclosure.
The new exact predicate rejects it. The smaller $2^{- 1075}$ instead
requires the bracket $\left\lbrack 0,2^{- 1074} \right\rbrack$. For
$2^{2000}/\left( 2^{2000} + 1 \right)$, integer bracketing returns the
predecessor of one and one, avoiding an indeterminate ratio of two
floating-point infinities. Nine independent rational checks cover these
and other boundary cases.

**Proposition 12.17 (soundness of returned elementary intervals).**
Assume correctly rounded binary64 elementary arithmetic with gradual
underflow, finite ordered input endpoints, and a denominator interval
excluding zero for division. If each endpoint operation is rounded
outward by one predecessor or successor step and the routine returns
finite ordered endpoints, the returned interval contains the exact real
range of the elementary operation. Composition preserves containment of
the occurrence-independent range, and therefore of every declared tied
subset.

*Proof.* For any exact finite scalar result whose nearest-rounded value
is finite, its predecessor and successor bracket that result. A returned
finite interval excludes the overflow cases. Addition and subtraction
use their exact endpoint extrema. Multiplication and division away from
zero have extrema at the four corners. Correct rounding is monotone;
taking the minimum and maximum of the rounded corner results and then
widening brackets every exact corner result. Induction over the
expression tree proves containment, and Theorem 12.2 supplies the final
subset inclusion. ∎

The corrected finite-endpoint interval constructor rejects NaN, infinity
and reversed endpoints. An overflow or an outward step beyond the finite
format is an explicit rejection, not a certified numerical answer. This
is a soundness statement for results that return, not a completeness
claim for all real-valued expressions. The exact rational vertex routine
also requires multi-affinity; both vertex routines now reject a
non-multi-affine polynomial and reject the unsupported signed-mask
dimension before enumeration. The single-event smoother returns
$K = \lbrack 1\rbrack$ and determinant one.

## 12.6 Consequences for a causal horizontal ASE layer

The results specify a computation policy for the existing mechanism
sheaf. First, declare calibrated units and the identity of each
uncertain parameter before forming residuals or intervals. A shared
quantity is a shared variable point; its value is not duplicated merely
because two contexts read it. Second, distinguish an exact range from an
outward enclosure. A sign-coherence certificate permits the two-endpoint
computation of Theorem 12.5; a small independent edge box permits exact
vertex enumeration; otherwise a documented factorization or constrained
relaxation gives an enclosure.

Third, attach a temporal access contract to the read. A retrospective
harmonic smoother may use the complete history. A prefix read uses only
permitted observations, and Theorem 12.9 quantifies the unavoidable
discrepancy from that retrospective target under a declared completion
box. Fourth, retain the constraint graph and certificate when returning
a clock window; the windows alone forget correlations. A negative cycle
is an explanation of infeasibility, while a feasible clock is a witness
of consistency.

These are horizontal computations on local information and its overlaps.
Physical clock order remains separate from the ASE layer order and the
other bases of Section 9. A token still carries a vertical fibre
diagram; a stalk remains a data space. Changes of base still use the
sheaf inverse image $\Phi_{t}^{- 1}$ and commuting squares. Neither a
tighter interval nor a successful numerical check relaxes those
representation requirements.

The executed evidence comprises the original 71 independently checked
output lines and 27 additional lines, for 98 in total. A separate exact
Python calculation checks 15 weighted resolvent cases. All checks pass.
Section 12 supplies the proofs; the finite checks establish that the
reported implementations and examples agree under their stated
contracts.

*Table 6. Independent checks of the 27 added C# output lines. Every
group passes. The 15 additional weighted-resolvent cases are separate
Python exact calculations.*

  ---------------------------------------------------------------------------------------
  **Group**              **Lines**   **Recomputation**                    **Statement**
  ---------------------- ----------- ------------------------------------ ---------------
  Rational-to-binary64   9           Exact rational containment and       12.16
  brackets                           adjacent-endpoint checks             

  Conversion and domain  3           Old failure, finite intervals,       12.15--12.17
  guards                             multi-affine vertex domains          

  Single-event smoother  1           Exact determinant and inverse        11.4

  MAX-CUT construction   2           All 74 graphs; triangle range        12.6

  Cancellation families  2           Exact widths and outward enclosures  12.4

  Tied gains and sign    2           Interior extremum; 16 sign-coherent  12.3, 12.5
  gauges                             models                               

  Path row, tails and    3           60 matrices, 390 tails, minimax      12.8--12.11
  prefix risk                        values and nonmonotone entry         

  Clock and quantization 5           Fraction shortest paths,             12.12--12.14
  cases                              inequalities and exact cycle costs   
  ---------------------------------------------------------------------------------------

# 13 Open questions and falsifiable conjectures

## 13.1 Mathematical questions

The basic construction is finite and acyclic. Extending it to
instantaneous cyclic mechanisms requires existence, uniqueness and
intervention stability hypotheses. A cyclic graph alone supplies none of
them, as the SCM literature makes precise (Bongers et al., 2021). The
appropriate sheaf can still represent the equations, but Theorem 4.2
must be replaced by a genuine solvability result.

A second question concerns partially observed boundaries. When local
mechanism contexts omit shared causes, one needs conditions under which
their laws identify the desired intervention despite that omission.
General marginal gluing is insufficient. Theorem 5.4 supplies one
causally sufficient case; confounded contexts require additional
identification assumptions, experimental information or a set of
possible answers.

A third question is efficient causal compression in continuous latent
spaces. The exact condition (9.3) is stated for all local inputs. A
useful theory should derive a controlled intervention domain on which
finitely many certificates establish a uniform defect, while handling
chart changes and nontrivial global topology. Pointwise agreement on
observed parent tuples cannot justify unseen interventions without a
regularity argument.

The fourth question is what to retain from the vertical fibre diagram.
Ordinary layer bars, temporal prefix flags and intervention response
maps summarize different objects. A practical invariant should report
their joint restrictions without pretending that one barcode is a
complete invariant of a two dimensional diagram. The constructions of
persistent sheaf cohomology offer a starting point for these comparisons
(Russold, 2022).

A fifth question is the efficient treatment of constrained parameter
families and route structures outside the exact regimes. Theorem 12.5
gives sign-coherent forward ranges, Proposition 12.4 gives unbounded
relative inflation, and Theorem 12.6 excludes a general polynomial-time
exact range algorithm unless P equals NP. Useful remaining targets
include exact methods for restricted route cores, constrained single-use
parameterizations and adaptive dependency retention with certified
absolute, rather than universal relative, error bounds.

## 13.2 Proposed comparative claims

**Conjecture E1 (verified intervention reasoning).** On a frozen
collection of synthetic finite SCM narratives with common extracted
event and mechanism proposals, a system that uses explicit relation
replacement and shared exogenous counterfactuals will have at most half
the counterfactual error rate of an otherwise matched system that uses
event attention pruning alone. Freeze the questions, scoring, model,
prompts and inference budget before comparison. Include confounding,
branching and the coupling ambiguity of Proposition 5.5. The comparator
must be allowed to return unknown when the supplied information is
insufficient. A confidence interval entirely above the error ratio $0.5$
contradicts the stated quantitative prediction; an interval crossing it
is inconclusive. When the comparator error is zero, report absolute
errors and treat the ratio prediction as untestable on that set.

**Conjecture E2 (causal latent compression).** Under equal latent
dimension, training data and inference cost, adding a mechanism
commutation loss for (9.3) will reduce held out intervention RMSE to at
most $0.8$ of a reconstruction only latent baseline, while increasing
factual reconstruction RMSE by no more than $0.05$ times its baseline
value. Freeze the intervention family and normalized output metrics
before training. A confidence interval entirely outside either claimed
bound contradicts that part of the prediction. A reconstruction
improvement alone does not support the intervention claim. These ratios
require positive baseline errors; a zero baseline requires a separately
prespecified absolute criterion.

**Conjecture E3 (interval clocks).** On a frozen collection of
narratives whose dates are given to year or month resolution, with
questions that require ordering, lag or window reasoning, a system that
represents dates as intervals and answers from the minimal network of
Section 11.5 will make at most half the temporal-boundary errors of an
otherwise matched system that maps each date to the start of its period.
Both systems may answer unknown when the minimal network leaves an order
undetermined, and unknown is scored separately from a wrong order.
Freeze the narratives, questions, scoring and extraction before
comparison. A confidence interval for the error ratio entirely above
$0.5$ contradicts the prediction; one crossing it is inconclusive. Table
4 is a synthetic consistency check, not evidence for this claim.

These are proposed engineering comparisons. No experiment in this paper
establishes them. The exact statements in Sections 2 to 9 remain
conditional mathematical results regardless of whether any comparative
gain occurs. The computational theorems of Section 12 likewise do not
establish these performance claims.

# 14 Conclusion

Temporal causal reasoning fits within ASE's horizontal structure when
local stalks represent complete mechanism relations and overlaps
identify shared variables. Perfect interventions replace target
relations. Counterfactuals couple two mechanism diagrams through shared
exogenous circumstances and an explicit factual posterior. The inference
layer order remains a separate axis.

The strongest constraints on implementation are specific. Different
directed paths contribute separate gains and should not be forced to
commute. A symmetric global harmonic estimate is a smoother and cannot
also supply a nontrivial strictly nonanticipating linear read on the
same event blocks. Zero first cohomology of the complete linear
mechanism sheaf follows from its functional construction and cannot
identify the causal explanation. Latent compression preserves
interventions only when its local mechanism squares factor, or when
their defects are bounded on the intervention domain.

The computation has three distinct sources of uncertainty: model
uncertainty, loss of declared dependencies in a numerical relaxation,
and floating-point error. Occurrence constraints explain the second,
while adjacent rational brackets and exact containment control the
third. Sign coherence gives an efficient exact gain range; the
four-layer reduction proves a general complexity barrier. For the scalar
path smoother, a closed form quantifies both the total future weight and
the sharp error of a prefix-only substitute. The future share approaches
38.2% at unit weight as history length grows, while a uniform 1%
discrepancy guarantee requires four later observations.

The next implementation is a typed causal horizontal layer that retains
shared parameter identities, returns a range with an explicit exactness
or enclosure certificate, and separates a permitted-prefix read from a
retrospective smoother. Clock answers carry a feasible assignment or a
negative cycle. Such a layer can then be evaluated under the three
frozen comparisons of Section 13; the exact constructions and successful
arithmetic checks alone do not establish a learned-system advantage.

# Appendix A Assumptions behind the main statements

  -------------------------------------------------------------------------
  **Statement**   **Conditions used**             **Conclusion supplied**
  --------------- ------------------------------- -------------------------
  Theorem 3.2     Finite DAG, finite time         Clock feasibility and the
                  intervals, fixed nonnegative    least feasible clock
                  minimum lags                    

  Theorem 4.2     Total functional mechanisms,    One intervened global
                  complete scopes, fixed          section for each
                  exogenous state, perfect        exogenous state
                  replacement                     

  Theorem 4.4     Complete linear mechanism       Dimension of degree zero
                  incidence graph sheaf, finite   sections and vanishing
                  dimensional spaces, acyclic     first cohomology
                  generation                      

  Theorem 5.2     Measurable solutions on         A counterfactual
                  standard Borel spaces and a     pushforward conditional
                  justified factual conditional   on evidence
                  law                             

  Theorem 5.4     Known causally sufficient DAG,  Identification of perfect
                  independent node disturbances,  intervention laws from
                  finite positive observational   parent contexts
                  law                             

  Theorem 7.1     Global symmetric quadratic,     No off diagonal temporal
                  positive block diagonal         response in that
                  observation metric, linear      estimator
                  nonanticipation                 

  Proposition 7.4 Fixed permitted history and     Fixed star energy
                  star, positive scale, fixed     decrease and finite step
                  linear maps and priors          prefix dependence

  Theorem 8.1     Shared topology and             Propagated mechanism and
                  intervention, uniform local     posterior error allowance
                  errors and Lipschitz bounds on  
                  a common domain                 

  Theorem 9.3     Surjective variablewise         Exact local causal
                  encoders and constancy on       abstraction and commuting
                  encoded parent fibres           interventions

  Proposition     Finite acyclic model;           Multilinear path
  11.1            independent edge gains in a box polynomials; exact range
                                                  at box vertices

  Proposition     Nonnegative gain intervals,     Interval forward
  11.2            exact interval arithmetic       substitution returns the
                                                  exact range

  Proposition     Elementary expression tree;     Exact
  11.3            denominator intervals avoid     occurrence-independent
                  zero; ideal interval arithmetic range; enclosure of
                                                  declared tied assignments

  Proposition     Scalar path; w \> 0; T ≥ 2 for  Endpoint anticipation,
  11.4            strict monotonicity             Fibonacci values at unit
                                                  weight; T = 1 handled
                                                  separately

  Theorem 12.2    Elementary expression tree and  Exact range of the
                  independent occurrence leaves;  relaxed expression, not
                  denominators avoid zero         necessarily of the tied
                                                  model

  Theorem 12.5    Acyclic route core; independent Vertex sign gauge and
                  nonnegative amplitudes and      exact forward range
                  coherent fixed signs            

  Theorem 12.6    Four-layer linear DAG;          Exact gain-range
                  independent interval gains;     optimization is NP-hard
                  integer fixed weights           

  Theorems        Positive scalar graph           Positive reversible read,
  12.7--12.9;     Laplacian; path specialization; explicit tails, sharp
  Corollary 12.10 independent future box for risk prefix risk and lookahead
                                                  budget

  Theorem 12.12;  Closed difference constraints;  Attainable clock bounds,
  Propositions    finite date bounds; independent robust feasibility and
  12.13--12.14    coefficient box when invoked    quantization criterion

  Lemma 12.15;    Dyadic bit budget or exact      Exact study oracle and
  Theorem 12.16;  integer bracketing; correctly   sound finite returned
  Proposition     rounded binary64 with gradual   interval enclosures
  12.17           underflow                       
  -------------------------------------------------------------------------

The word causal in these conclusions refers to the declared structural
model. External validation of an extracted mechanism is a separate
obligation. Cohomology tests compatibility of the coefficient system
that was actually built. A causal mask tests access permissions that
were actually implemented. Neither diagnostic supplies the other's
missing assumptions.

# Appendix B The interval and symbolic kernel

The kernel targets .NET 8 and uses only the base class library. Values
are immutable records and readonly structs; local scratch arrays
implement elimination and shortest paths. Q represents exact rationals
over arbitrary-precision integers. Q.ToDouble is an approximation, while
Q.FromDouble decodes a finite binary64 datum exactly. Iv accepts finite
ordered endpoints, brackets rationals by exact integer division and
compares containment exactly. Elementary operations widen endpoints
outward and reject unsupported nonfinite results. Poly and Expr retain
the symbolic and expression-tree distinctions of Section 11. Stn
computes rational shortest paths and negative cycles; its bound
accessors reject an inconsistent network. Both vertex routines require
multi-affinity and a supported mask dimension. SplitMix64 supplies the
reproducible random stream. The four listings below are the corrected
files. Program.cs and V3Checks.cs, the build project and both Python
validators accompany the paper. Table 5 describes the original 71 lines;
Table 6 describes the 27 added lines, giving 98 checked lines. Appendix
C distinguishes the checks from the proofs and documents the conversion
correction.

*Table 5. Independent recomputation of the 71 kernel output lines.*

  ------------------------------------------------------------------------------------
  **Group**           **Lines**   **Independent recomputation**        **Agreement**
  ------------------- ----------- ------------------------------------ ---------------
  Examples of         24          fractions and SymPy inverses, path   all
  Sections 2 to 10                sums and enumeration                 

  Incidence sheaf     2           SymPy exact ranks of the same        all
  cohomology                      coboundary and incidence matrices    

  Path polynomials    17          SymPy expansion, exact rational      all
  and interval forms              interval arithmetic, NumPy vertex    
                                  enumeration, replicated random       
                                  stream                               

  Counterfactual      7           SymPy identity, exact rational       all
  intervals                       interval arithmetic, vertex          
                                  enumeration                          

  Symbolic smoother   7           SymPy determinants, adjugates,       all
                                  derivative signs and Fibonacci       
                                  numbers                              

  Temporal networks   9           Python Floyd--Warshall over          all
                                  fractions on the replicated          
                                  narratives                           

  Masks               5           NumPy IEEE arithmetic                all
  ------------------------------------------------------------------------------------

**Exact.cs**

    // Exact arithmetic for the temporal causal sheaf: rationals over BigInteger, outward-rounded
    // intervals over double, and exact rank by Gaussian elimination over the rationals. Values are immutable.
    using System;
    using System.Collections.Immutable;
    using System.Linq;
    using System.Numerics;

    namespace Tcr;

    /// <summary>An exact rational number in lowest terms with positive denominator.</summary>
    public readonly record struct Q : IComparable<Q>
    {
        public BigInteger Num { get; }
        public BigInteger Den { get; }

        public Q(BigInteger num, BigInteger den)
        {
            if (den.IsZero) throw new DivideByZeroException("zero denominator");
            if (den.Sign < 0) { num = -num; den = -den; }
            var g = BigInteger.GreatestCommonDivisor(num, den);
            if (!g.IsOne && !g.IsZero) { num /= g; den /= g; }
            Num = num; Den = num.IsZero ? BigInteger.One : den;
        }

        public static readonly Q Zero = new(0, 1), One = new(1, 1);
        public static implicit operator Q(int k) => new(k, 1);
        public static Q Of(long p, long q = 1) => new(p, q);
        public static Q operator +(Q a, Q b) => new(a.Num * b.Den + b.Num * a.Den, a.Den * b.Den);
        public static Q operator -(Q a, Q b) => new(a.Num * b.Den - b.Num * a.Den, a.Den * b.Den);
        public static Q operator -(Q a) => new(-a.Num, a.Den);
        public static Q operator *(Q a, Q b) => new(a.Num * b.Num, a.Den * b.Den);
        public static Q operator /(Q a, Q b) => new(a.Num * b.Den, a.Den * b.Num);
        public static bool operator <(Q a, Q b) => a.CompareTo(b) < 0;
        public static bool operator >(Q a, Q b) => a.CompareTo(b) > 0;
        public static bool operator <=(Q a, Q b) => a.CompareTo(b) <= 0;
        public static bool operator >=(Q a, Q b) => a.CompareTo(b) >= 0;
        public int CompareTo(Q o) => (Num * o.Den).CompareTo(o.Num * Den);
        public bool IsZero => Num.IsZero;
        public int Sign => Num.Sign;
        public static Q Max(Q a, Q b) => a >= b ? a : b;
        public static Q Min(Q a, Q b) => a <= b ? a : b;
        public static Q Floor(Q a) => new(BigInteger.Divide(a.Num - (a.Num.Sign < 0 ? a.Den - 1 : 0), a.Den), 1);
        /// <summary>Approximation for display and bounded dyadic studies, not a certificate predicate.</summary>
        public double ToDouble() => (double)Num / (double)Den;
        /// <summary>The exact rational value of a finite IEEE binary64 datum.</summary>
        public static Q FromDouble(double x)
        {
            if (!double.IsFinite(x)) throw new ArgumentOutOfRangeException(nameof(x), "finite datum required");
            ulong bits = unchecked((ulong)BitConverter.DoubleToInt64Bits(x));
            int e = (int)((bits >> 52) & 0x7ff);
            ulong fraction = bits & 0x000fffffffffffffUL;
            BigInteger n = e == 0 ? fraction : fraction | (1UL << 52);
            if ((bits >> 63) != 0) n = -n;
            int power = e == 0 ? -1074 : e - 1023 - 52;
            return power >= 0 ? new(n << power, BigInteger.One) : new(n, BigInteger.One << -power);
        }
        public override string ToString() => Den.IsOne ? Num.ToString() : $"{Num}/{Den}";
    }

    /// <summary>A closed interval [Lo, Hi] of reals. Every operation rounds outward by one unit in the
    /// last place at each endpoint, so the result encloses the exact real range of the operation on
    /// the exact endpoints.</summary>
    public readonly record struct Iv
    {
        public double Lo { get; }
        public double Hi { get; }
        /// <summary>This kernel supports finite closed endpoints and rejects invalid or overflowing results.</summary>
        public Iv(double lo, double hi)
        {
            if (!double.IsFinite(lo) || !double.IsFinite(hi) || lo > hi)
                throw new ArgumentOutOfRangeException(nameof(lo), "ordered finite interval endpoints required");
            Lo = lo; Hi = hi;
        }
        public static Iv Point(double x) => new(x, x);
        static double Dn(double x) => Math.BitDecrement(x);
        static double Up(double x) => Math.BitIncrement(x);

        /// <summary>Adjacent binary64 brackets of an exact rational, by integer division on the
        /// appropriate binary grid. Handles subnormals without converting either BigInteger to double.</summary>
        public static Iv Of(Q q)
        {
            if (q.Den.Sign <= 0) throw new ArgumentException("valid rational required");
            if (q.IsZero) return Point(0);
            if (q.Sign < 0) return -Of(-q);
            if (q > Q.FromDouble(double.MaxValue)) throw new OverflowException("no finite binary64 enclosure");
            int power;
            if (q < Q.FromDouble(Math.ScaleB(1.0, -1022))) power = -1074;
            else
            {
                int e = checked((int)(q.Num.GetBitLength() - q.Den.GetBitLength()));
                bool below = e >= 0 ? q.Num < (q.Den << e) : (q.Num << -e) < q.Den;
                if (below) e--;
                power = e - 52;
            }
            BigInteger numerator = q.Num, denominator = q.Den;
            if (power < 0) numerator <<= -power; else denominator <<= power;
            BigInteger k = BigInteger.DivRem(numerator, denominator, out var remainder);
            double lo = Math.ScaleB((double)k, power);
            return new(lo, remainder.IsZero ? lo : Math.BitIncrement(lo));
        }
        public static Iv Of(Q lo, Q hi) => lo > hi ? throw new ArgumentException("reversed rational interval") : new(Of(lo).Lo, Of(hi).Hi);
        public static Iv operator +(Iv a, Iv b) => new(Dn(a.Lo + b.Lo), Up(a.Hi + b.Hi));
        public static Iv operator -(Iv a, Iv b) => new(Dn(a.Lo - b.Hi), Up(a.Hi - b.Lo));
        public static Iv operator -(Iv a) => new(-a.Hi, -a.Lo);
        public static Iv operator *(Iv a, Iv b)
        {
            var p = new[] { a.Lo * b.Lo, a.Lo * b.Hi, a.Hi * b.Lo, a.Hi * b.Hi };
            return new(Dn(p.Min()), Up(p.Max()));
        }
        public static Iv operator /(Iv a, Iv b)
        {
            if (b.Lo <= 0 && b.Hi >= 0) throw new ArgumentException("divisor interval contains zero");
            var p = new[] { a.Lo / b.Lo, a.Lo / b.Hi, a.Hi / b.Lo, a.Hi / b.Hi };
            return new(Dn(p.Min()), Up(p.Max()));
        }
        public double Width => Hi - Lo;
        public bool Contains(Q q) => q.Den.Sign <= 0 ? throw new ArgumentException("valid rational required")
            : Q.FromDouble(Lo) <= q && q <= Q.FromDouble(Hi);
        public static Iv Hull(Iv a, Iv b) => new(Math.Min(a.Lo, b.Lo), Math.Max(a.Hi, b.Hi));
        public override string ToString() => $"{Lo:R} {Hi:R}";
    }

    /// <summary>A dense rational matrix held as an immutable row-major array.</summary>
    public sealed record QMat(int Rows, int Cols, ImmutableArray<Q> A)
    {
        public Q this[int i, int j] => A[i * Cols + j];
        public static QMat Of(int r, int c, Func<int, int, Q> f) =>
            new(r, c, Enumerable.Range(0, r * c).Select(k => f(k / c, k % c)).ToImmutableArray());
        public static QMat Identity(int n) => Of(n, n, (i, j) => i == j ? Q.One : Q.Zero);
        public QMat Mul(QMat b) => Of(Rows, b.Cols, (i, j) =>
            Enumerable.Range(0, Cols).Aggregate(Q.Zero, (s, k) => s + this[i, k] * b[k, j]));
        public QMat Sub(QMat b) => Of(Rows, Cols, (i, j) => this[i, j] - b[i, j]);
        public QMat Scale(Q s) => Of(Rows, Cols, (i, j) => s * this[i, j]);

        /// <summary>Exact rank by Gaussian elimination over the rationals (scratch copy only).</summary>
        public int Rank()
        {
            var m = A.ToArray(); int rank = 0;
            for (int col = 0; col < Cols && rank < Rows; col++)
            {
                int piv = Enumerable.Range(rank, Rows - rank).FirstOrDefault(r => !m[r * Cols + col].IsZero, -1);
                if (piv < 0) continue;
                for (int j = 0; j < Cols; j++) (m[rank * Cols + j], m[piv * Cols + j]) = (m[piv * Cols + j], m[rank * Cols + j]);
                for (int r = 0; r < Rows; r++)
                {
                    if (r == rank || m[r * Cols + col].IsZero) continue;
                    var f = m[r * Cols + col] / m[rank * Cols + col];
                    for (int j = col; j < Cols; j++) m[r * Cols + j] = m[r * Cols + j] - f * m[rank * Cols + j];
                }
                rank++;
            }
            return rank;
        }

        /// <summary>Exact inverse by Gauss-Jordan elimination (throws if singular).</summary>
        public QMat Inverse()
        {
            int n = Rows; var m = new Q[n, 2 * n];
            for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) { m[i, j] = this[i, j]; m[i, n + j] = i == j ? Q.One : Q.Zero; }
            for (int c = 0; c < n; c++)
            {
                int p = Enumerable.Range(c, n - c).First(r => !m[r, c].IsZero);
                for (int j = 0; j < 2 * n; j++) (m[c, j], m[p, j]) = (m[p, j], m[c, j]);
                var inv = Q.One / m[c, c];
                for (int j = 0; j < 2 * n; j++) m[c, j] = m[c, j] * inv;
                for (int r = 0; r < n; r++)
                {
                    if (r == c || m[r, c].IsZero) continue;
                    var f = m[r, c];
                    for (int j = 0; j < 2 * n; j++) m[r, j] = m[r, j] - f * m[c, j];
                }
            }
            return Of(n, n, (i, j) => m[i, n + j]);
        }
    }

    /// <summary>SplitMix64 counter stream; the k-th draw depends only on the seed and k.</summary>
    public readonly record struct Rng(ulong State)
    {
        public (ulong, Rng) Next()
        {
            ulong s = State + 0x9E3779B97F4A7C15UL, z = s;
            z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
            z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
            return (z ^ (z >> 31), new Rng(s));
        }
        public (double, Rng) Uniform() { var (u, r) = Next(); return ((u >> 11) * (1.0 / 9007199254740992.0), r); }
        /// <summary>Integer uniform on [lo, hi] by the top 53 bits (bias below 2^-40 for small ranges).</summary>
        public (int, Rng) Int(int lo, int hi) { var (u, r) = Uniform(); return (lo + (int)Math.Floor(u * (hi - lo + 1)), r); }
    }

**Symbolic.cs**

    // Symbolic computation: exact multivariate polynomials over the rationals, expression trees whose
    // interval evaluation exposes the dependency problem, and a greedy Horner factorisation that
    // reduces repeated occurrences of a variable.
    using System;
    using System.Collections.Generic;
    using System.Collections.Immutable;
    using System.Linq;

    namespace Tcr;

    /// <summary>A monomial as a sorted list of (variable, power) pairs.</summary>
    public sealed record Mono(ImmutableArray<(int Var, int Pow)> Factors)
    {
        public static readonly Mono Unit = new(ImmutableArray<(int, int)>.Empty);
        public static Mono Of(int v) => new(ImmutableArray.Create((v, 1)));
        public string Key => string.Join("*", Factors.Select(f => $"{f.Var}^{f.Pow}"));
        public int Degree(int v) => Factors.Where(f => f.Var == v).Select(f => f.Pow).DefaultIfEmpty(0).Single();
        public Mono Times(Mono o) => new(Factors.Concat(o.Factors).GroupBy(f => f.Var)
            .Select(g => (g.Key, g.Sum(f => f.Pow))).OrderBy(f => f.Key).ToImmutableArray());
        public Mono Without(int v) => new(Factors.Select(f => f.Var == v ? (f.Var, f.Pow - 1) : f)
            .Where(f => f.Item2 > 0).ToImmutableArray());
        public bool Equals(Mono? o) => o is not null && Key == o.Key;
        public override int GetHashCode() => Key.GetHashCode();
    }

    /// <summary>A polynomial: an immutable map from monomials to nonzero rational coefficients.</summary>
    public sealed record Poly(ImmutableDictionary<Mono, Q> Terms)
    {
        public static readonly Poly Zero = new(ImmutableDictionary<Mono, Q>.Empty);
        public static Poly Const(Q c) => c.IsZero ? Zero : new(ImmutableDictionary<Mono, Q>.Empty.Add(Mono.Unit, c));
        public static Poly Var(int v) => new(ImmutableDictionary<Mono, Q>.Empty.Add(Mono.Of(v), Q.One));
        public static Poly operator +(Poly a, Poly b) => new(b.Terms.Aggregate(a.Terms, (d, t) =>
        {
            var c = (d.TryGetValue(t.Key, out var x) ? x : Q.Zero) + t.Value;
            return c.IsZero ? d.Remove(t.Key) : d.SetItem(t.Key, c);
        }));
        public static Poly operator *(Poly a, Poly b) => a.Terms.SelectMany(s => b.Terms.Select(t =>
            new Poly(ImmutableDictionary<Mono, Q>.Empty.Add(s.Key.Times(t.Key), s.Value * t.Value))))
            .Aggregate(Zero, (x, y) => x + y);
        public static Poly operator -(Poly a, Poly b) => a + b * Const(-1);
        public IEnumerable<int> Vars => Terms.Keys.SelectMany(m => m.Factors.Select(f => f.Var)).Distinct().OrderBy(v => v);
        public int MaxDegreeInAnyVar => Terms.Keys.SelectMany(m => m.Factors.Select(f => f.Pow)).DefaultIfEmpty(0).Max();
        public Q Eval(Func<int, Q> x) => Terms.Aggregate(Q.Zero, (s, t) =>
            s + t.Key.Factors.Aggregate(t.Value, (p, f) => Enumerable.Range(0, f.Pow).Aggregate(p, (pp, _) => pp * x(f.Var))));
        public double EvalD(Func<int, double> x) => Terms.Sum(t =>
            t.Key.Factors.Aggregate(t.Value.ToDouble(), (p, f) => p * Math.Pow(x(f.Var), f.Pow)));
        /// <summary>Univariate coefficient list, lowest power first.</summary>
        public ImmutableArray<Q> Coefficients(int v)
        {
            int d = Terms.Keys.Select(m => m.Degree(v)).DefaultIfEmpty(0).Max();
            return Enumerable.Range(0, d + 1).Select(k => Terms.Where(t => t.Key.Degree(v) == k)
                .Aggregate(Q.Zero, (s, t) => s + t.Value)).ToImmutableArray();
        }
        public bool Equal(Poly o) => (this - o).Terms.Count == 0;
        public override string ToString() => Terms.Count == 0 ? "0" : string.Join(" + ", Terms
            .OrderBy(t => t.Key.Key).Select(t => $"{t.Value}" + (t.Key.Factors.Length == 0 ? "" : "·" + t.Key.Key)));
    }

    /// <summary>An expression tree. Interval evaluation treats every occurrence of a variable as
    /// independent, which is why the form of an expression changes the width of its enclosure.</summary>
    public abstract record Expr
    {
        public sealed record C(Q Value) : Expr;
        public sealed record V(int Index) : Expr;
        public sealed record Sum(ImmutableArray<Expr> Items) : Expr;
        public sealed record Prod(ImmutableArray<Expr> Items) : Expr;

        public static Expr Add(params Expr[] e) => e.Length == 1 ? e[0] : new Sum(e.ToImmutableArray());
        public static Expr Mul(params Expr[] e) => e.Length == 1 ? e[0] : new Prod(e.ToImmutableArray());
        public static Expr Neg(Expr e) => Mul(new C(-1), e);

        public Iv Eval(Func<int, Iv> x) => this switch
        {
            C c => Iv.Of(c.Value),
            V v => x(v.Index),
            Sum s => s.Items.Skip(1).Aggregate(s.Items[0].Eval(x), (a, e) => a + e.Eval(x)),
            Prod p => p.Items.Skip(1).Aggregate(p.Items[0].Eval(x), (a, e) => a * e.Eval(x)),
            _ => throw new InvalidOperationException()
        };
        public Q EvalQ(Func<int, Q> x) => this switch
        {
            C c => c.Value, V v => x(v.Index),
            Sum s => s.Items.Aggregate(Q.Zero, (a, e) => a + e.EvalQ(x)),
            Prod p => p.Items.Aggregate(Q.One, (a, e) => a * e.EvalQ(x)),
            _ => throw new InvalidOperationException()
        };
        public Poly ToPoly() => this switch
        {
            C c => Poly.Const(c.Value), V v => Poly.Var(v.Index),
            Sum s => s.Items.Aggregate(Poly.Zero, (a, e) => a + e.ToPoly()),
            Prod p => p.Items.Aggregate(Poly.Const(Q.One), (a, e) => a * e.ToPoly()),
            _ => throw new InvalidOperationException()
        };
        /// <summary>Number of leaves naming each variable (a tree size, counting shared subtrees once per use).</summary>
        public int Occurrences(int v) => this switch
        {
            V x => x.Index == v ? 1 : 0, C => 0,
            Sum s => s.Items.Sum(e => e.Occurrences(v)), Prod p => p.Items.Sum(e => e.Occurrences(v)),
            _ => 0
        };
        public int MaxOccurrence(IEnumerable<int> vars) => vars.Select(Occurrences).DefaultIfEmpty(0).Max();

        /// <summary>The expanded form: a sum of monomials, each a product of its variables.</summary>
        public static Expr Expanded(Poly p) => p.Terms.Count == 0 ? new C(Q.Zero) : Add(p.Terms.OrderBy(t => t.Key.Key)
            .Select(t => MonoExpr(t.Key, t.Value)).ToArray());
        static Expr MonoExpr(Mono m, Q c)
        {
            var vs = m.Factors.SelectMany(f => Enumerable.Repeat<Expr>(new V(f.Var), f.Pow)).ToList();
            if (vs.Count == 0) return new C(c);
            if (c != Q.One) vs.Insert(0, new C(c));
            return Mul(vs.ToArray());
        }

        /// <summary>Greedy Horner factorisation: repeatedly pull out the variable shared by the most
        /// monomials. The result is algebraically identical to the polynomial.</summary>
        public static Expr Horner(Poly p)
        {
            if (p.Terms.Count <= 1) return Expanded(p);
            var best = p.Vars.Select(v => (v, n: p.Terms.Keys.Count(m => m.Degree(v) > 0)))
                .OrderByDescending(t => t.n).ThenBy(t => t.v).First();
            if (best.n < 2) return Expanded(p);
            var with = new Poly(p.Terms.Where(t => t.Key.Degree(best.v) > 0)
                .ToImmutableDictionary(t => t.Key.Without(best.v), t => t.Value));
            var rest = new Poly(p.Terms.Where(t => t.Key.Degree(best.v) == 0).ToImmutableDictionary());
            var head = Mul(new V(best.v), Horner(with));
            return rest.Terms.Count == 0 ? head : Add(head, Horner(rest));
        }
    }

    /// <summary>Exact range of a multilinear polynomial over a box, by enumeration of the vertices.
    /// A multilinear function is affine in each variable separately, so its extremes over a box are
    /// attained at vertices.</summary>
    public static class Vertex
    {
        public static (Q Lo, Q Hi) Range(Poly p, Func<int, (Q Lo, Q Hi)> box)
        {
            var vars = p.Vars.ToArray();
            if (p.MaxDegreeInAnyVar > 1) throw new ArgumentException("polynomial is not multilinear");
            if (vars.Length >= 63) throw new ArgumentOutOfRangeException(nameof(p), "signed 64-bit vertex mask supports at most 62 variables");
            Q lo = Q.Zero, hi = Q.Zero; bool first = true;
            for (long mask = 0; mask < 1L << vars.Length; mask++)
            {
                var pick = vars.Select((v, i) => (v, ((mask >> i) & 1) == 0 ? box(v).Lo : box(v).Hi)).ToDictionary(t => t.v, t => t.Item2);
                var val = p.Eval(v => pick[v]);
                if (first) { lo = hi = val; first = false; } else { lo = Q.Min(lo, val); hi = Q.Max(hi, val); }
            }
            return (lo, hi);
        }

        /// <summary>The same enumeration in double arithmetic, exact when every vertex value is a
        /// short dyadic sum (asserted by the caller).</summary>
        public static (double Lo, double Hi) RangeD(Poly p, Func<int, (double Lo, double Hi)> box)
        {
            if (p.MaxDegreeInAnyVar > 1) throw new ArgumentException("polynomial is not multilinear");
            var vars = p.Vars.ToArray(); var idx = vars.Select((v, i) => (v, i)).ToDictionary(t => t.v, t => t.i);
            if (vars.Length >= 63) throw new ArgumentOutOfRangeException(nameof(p), "signed 64-bit vertex mask supports at most 62 variables");
            var terms = p.Terms.Select(t => (c: t.Value.ToDouble(), f: t.Key.Factors.Select(f => idx[f.Var]).ToArray())).ToArray();
            double lo = double.PositiveInfinity, hi = double.NegativeInfinity; var x = new double[vars.Length];
            for (long mask = 0; mask < 1L << vars.Length; mask++)
            {
                for (int i = 0; i < vars.Length; i++) x[i] = ((mask >> i) & 1) == 0 ? box(vars[i]).Lo : box(vars[i]).Hi;
                double val = 0;
                foreach (var (c, f) in terms) { double m = c; foreach (var k in f) m *= x[k]; val += m; }
                lo = Math.Min(lo, val); hi = Math.Max(hi, val);
            }
            return (lo, hi);
        }
    }

**Causal.cs**

    // The paper's constructions in exact arithmetic: linear structural models, perfect interventions,
    // path resolvents, the error allowance of Theorem 8.1, the incidence sheaf cohomology of
    // Theorem 4.4, the symmetric smoother of Section 7.1 and the interval studies of Section 11.
    using System;
    using System.Collections.Generic;
    using System.Collections.Immutable;
    using System.Linq;

    namespace Tcr;

    /// <summary>A linear structural model x = Bx + u in a topological order (B strictly lower triangular).</summary>
    public sealed record LinearScm(QMat B)
    {
        public int N => B.Rows;

        /// <summary>Recursive solution with perfect interventions (target -> clamp).</summary>
        public ImmutableArray<Q> Solve(ImmutableArray<Q> u, ImmutableDictionary<int, Q> doMap) =>
            Enumerable.Range(0, N).Aggregate(ImmutableArray<Q>.Empty, (x, v) => x.Add(doMap.TryGetValue(v, out var d)
                ? d : Enumerable.Range(0, v).Aggregate(u[v], (s, w) => s + B[v, w] * x[w])));

        /// <summary>R_D = (I - P B)^{-1} with P zeroing the target rows (Theorem 6.1).</summary>
        public QMat Resolvent(IEnumerable<int> targets)
        {
            var t = targets.ToHashSet();
            var pb = QMat.Of(N, N, (i, j) => t.Contains(i) ? Q.Zero : B[i, j]);
            return QMat.Identity(N).Sub(pb).Inverse();
        }

        /// <summary>The same resolvent as a sum over directed paths of (P B)^k, k = 0..n-1.</summary>
        public QMat PathSum(IEnumerable<int> targets)
        {
            var t = targets.ToHashSet();
            var pb = QMat.Of(N, N, (i, j) => t.Contains(i) ? Q.Zero : B[i, j]);
            var (acc, pw) = (QMat.Identity(N), QMat.Identity(N));
            for (int k = 1; k < N; k++) { pw = pw.Mul(pb); acc = QMat.Of(N, N, (i, j) => acc[i, j] + pw[i, j]); }
            return acc;
        }
    }

    /// <summary>A DAG whose edge gains are symbols. Edge e = (child, parent) is symbol e.</summary>
    public sealed record SymbolicDag(int N, ImmutableArray<(int Child, int Parent)> Edges)
    {
        /// <summary>Forward-substitution expression for the response of every node to a unit input
        /// at <paramref name="source"/>: r_v = sum over parents w of g_(v,w) r_w. Shared subtrees are
        /// reused, exactly as interval forward substitution reuses computed node intervals.</summary>
        public ImmutableArray<Expr> Forward(int source)
        {
            var r = new Expr[N];
            for (int v = 0; v < N; v++)
            {
                if (v == source) { r[v] = new Expr.C(Q.One); continue; }
                var terms = Edges.Select((e, i) => (e, i)).Where(t => t.e.Child == v && r[t.e.Parent] is not Expr.C { Value.IsZero: true })
                    .Select(t => r[t.e.Parent] is Expr.C { Value: var one } && one == Q.One ? new Expr.V(t.i) : Expr.Mul(new Expr.V(t.i), r[t.e.Parent]))
                    .ToArray();
                r[v] = terms.Length == 0 ? new Expr.C(Q.Zero) : Expr.Add(terms);
            }
            return r.ToImmutableArray();
        }

        /// <summary>Number of directed paths from source to target.</summary>
        public long PathCount(int s, int t)
        {
            var c = new long[N]; c[s] = 1;
            for (int v = s + 1; v < N; v++) c[v] = Edges.Where(e => e.Child == v).Sum(e => c[e.Parent]);
            return c[t];
        }
    }

    /// <summary>Incidence-graph realisation of the linear mechanism sheaf (Section 4.2).</summary>
    public static class IncidenceSheaf
    {
        /// <summary>Mechanism v has endogenous parents with gains and exogenous inputs with gains.
        /// Returns (dim C0, dim C1, rank of the coboundary, dim H0, dim H1, graph vertices, graph
        /// edges, first Betti number of the constant sheaf).</summary>
        public static (int C0, int C1, int Rank, int H0, int H1, int Vertices, int EdgesN, int ConstantH1) Cohomology(
            int n, int q, ImmutableArray<ImmutableArray<(int Var, Q Gain)>> inputs)
        {
            // variable points: 0..n-1 endogenous, n..n+q-1 exogenous; mechanism stalks follow.
            var mechOffset = new int[n]; int c0 = n + q;
            for (int v = 0; v < n; v++) { mechOffset[v] = c0; c0 += inputs[v].Length; }
            var rows = new List<Q[]>();
            for (int v = 0; v < n; v++)
            {
                var row = new Q[c0]; Array.Fill(row, Q.Zero); row[v] = Q.One;              // child edge
                for (int k = 0; k < inputs[v].Length; k++) row[mechOffset[v] + k] = -inputs[v][k].Gain;
                rows.Add(row);
                for (int k = 0; k < inputs[v].Length; k++)                                  // input edges
                {
                    var r = new Q[c0]; Array.Fill(r, Q.Zero);
                    r[inputs[v][k].Var] = Q.One; r[mechOffset[v] + k] = -Q.One; rows.Add(r);
                }
            }
            var delta = new QMat(rows.Count, c0, rows.SelectMany(r => r).ToImmutableArray());
            int rank = delta.Rank();
            int vertices = n + q + n, edgesN = rows.Count;
            // constant sheaf: incidence matrix of the same graph
            var inc = new List<Q[]>();
            for (int v = 0; v < n; v++)
                foreach (var a in inputs[v].Select(t => t.Var).Prepend(v))
                {
                    var r = new Q[vertices]; Array.Fill(r, Q.Zero); r[a] = Q.One; r[n + q + v] = -Q.One; inc.Add(r);
                }
            int incRank = new QMat(inc.Count, vertices, inc.SelectMany(r => r).ToImmutableArray()).Rank();
            return (c0, rows.Count, rank, c0 - rank, rows.Count - rank, vertices, edgesN, edgesN - incRank);
        }
    }

    /// <summary>The regularised harmonic read of Section 7.1 on a path of T scalar event blocks:
    /// K(w) = (I + w L)^{-1}, with L the path Laplacian.</summary>
    public static class Smoother
    {
        public static QMat K(int t, Q w) => t < 1 || w.Sign < 0 ? throw new ArgumentOutOfRangeException()
            : QMat.Of(t, t, (i, j) => i == j ? Q.One + w * (t == 1 ? 0 : i == 0 || i == t - 1 ? 1 : 2)
                : Math.Abs(i - j) == 1 ? -w : Q.Zero).Inverse();

        /// <summary>det(I + wL) as a polynomial in the symbol 0 = w, by the tridiagonal recurrence.</summary>
        public static Poly Det(int t)
        {
            if (t < 1) throw new ArgumentOutOfRangeException(nameof(t));
            if (t == 1) return Poly.Const(Q.One);
            var w = Poly.Var(0); var one = Poly.Const(Q.One);
            Poly Diag(int i) => one + w * Poly.Const(i == 0 || i == t - 1 ? 1 : 2);
            var (p2, p1) = (one, Diag(0));
            for (int i = 1; i < t; i++) (p2, p1) = (p1, Diag(i) * p1 - w * w * p2);
            return p1;
        }
    }

**Temporal.cs**

    // Clocks: the earliest-clock recursion of Theorem 3.2 and its path witness, and the simple
    // temporal network (difference constraints) with interval dates, upper lags and exact minimal
    // networks by Floyd-Warshall over the rationals (Dechter, Meiri and Pearl, 1991).
    using System;
    using System.Collections.Generic;
    using System.Collections.Immutable;
    using System.Linq;

    namespace Tcr;

    public static class Clock
    {
        /// <summary>Theorem 3.2 with predecessor pointers. Returns the earliest clock, feasibility and,
        /// if infeasible, the witness path ending at the first violating node.</summary>
        public static (ImmutableArray<Q> E, bool Feasible, ImmutableArray<int> Witness) Earliest(
            int n, ImmutableArray<(int From, int To, Q Lag)> edges, ImmutableArray<Q> lo, ImmutableArray<Q> hi)
        {
            var e = new Q[n]; var pred = new int[n];
            var incoming = edges.ToLookup(x => x.To);
            for (int v = 0; v < n; v++)
            {
                (e[v], pred[v]) = (lo[v], -1);
                foreach (var ed in incoming[v])
                    if (e[ed.From] + ed.Lag > e[v]) (e[v], pred[v]) = (e[ed.From] + ed.Lag, ed.From);
            }
            int bad = Enumerable.Range(0, n).FirstOrDefault(v => e[v] > hi[v], -1);
            var path = new List<int>();
            for (int v = bad; v >= 0; v = pred[v]) path.Add(v);
            path.Reverse();
            return (e.ToImmutableArray(), bad < 0, path.ToImmutableArray());
        }
    }

    /// <summary>A simple temporal network over event times t_1..t_n and the origin t_0 = 0.
    /// Constraint (i, j, c) means t_j - t_i &lt;= c.</summary>
    public sealed record Stn(int N, ImmutableArray<(int I, int J, Q C)> Cons)
    {
        public static Stn Build(int n, IEnumerable<(int Ev, Q Lo, Q Hi)> dates,
            IEnumerable<(int From, int To, Q MinLag, Q? MaxLag)> lags)
        {
            var c = new List<(int, int, Q)>();
            foreach (var (ev, l, h) in dates) { c.Add((0, ev, h)); c.Add((ev, 0, -l)); }
            foreach (var (f, t, mn, mx) in lags) { c.Add((t, f, -mn)); if (mx is Q m) c.Add((f, t, m)); }
            return new(n + 1, c.ToImmutableArray());
        }

        /// <summary>All-pairs shortest distances; null entries are +infinity.</summary>
        public Q?[,] Distances()
        {
            var d = new Q?[N, N];
            for (int i = 0; i < N; i++) d[i, i] = Q.Zero;
            foreach (var (i, j, c) in Cons) if (d[i, j] is not Q x || c < x) d[i, j] = c;
            for (int k = 0; k < N; k++) for (int i = 0; i < N; i++) for (int j = 0; j < N; j++)
                if (d[i, k] is Q a && d[k, j] is Q b && (d[i, j] is not Q x || a + b < x)) d[i, j] = a + b;
            return d;
        }
        public static bool Consistent(Q?[,] d) => Enumerable.Range(0, d.GetLength(0)).All(i => d[i, i] is Q x && x.Sign >= 0);

        /// <summary>Minimal-network bounds of t_v: [-d(v,0), d(0,v)].</summary>
        public static (Q Lo, Q Hi) Window(Q?[,] d, int v) => !Consistent(d)
            ? throw new InvalidOperationException("inconsistent temporal network")
            : (-(d[v, 0] ?? throw new InvalidOperationException()), d[0, v] ?? throw new InvalidOperationException());

        /// <summary>Lower bound of t_b - t_a in the minimal network, i.e. -d(b, a).</summary>
        public static Q? MinGap(Q?[,] d, int a, int b) => !Consistent(d)
            ? throw new InvalidOperationException("inconsistent temporal network")
            : d[b, a] is Q x ? -x : null;

        /// <summary>A negative cycle as a node list, by Bellman-Ford from a virtual source.</summary>
        public ImmutableArray<int> NegativeCycle()
        {
            var dist = Enumerable.Repeat(Q.Zero, N).ToArray(); var pred = Enumerable.Repeat(-1, N).ToArray(); int last = -1;
            for (int it = 0; it < N; it++)
            {
                last = -1;
                foreach (var (i, j, c) in Cons) if (dist[i] + c < dist[j]) { dist[j] = dist[i] + c; pred[j] = i; last = j; }
            }
            if (last < 0) return ImmutableArray<int>.Empty;
            int y = last; for (int k = 0; k < N; k++) y = pred[y];
            var cyc = new List<int> { y };
            for (int v = pred[y]; v != y; v = pred[v]) cyc.Insert(0, v);
            cyc.Insert(0, y);
            return cyc.ToImmutableArray();
        }
    }

# Appendix C Verification and reproduction

The supplied Version 2 was first rebuilt without changes. Its 71 output
lines reproduced byte for byte, and its independent validator passed all
71. The corrected kernel then generated 98 output lines. Its first 71
lines pass the original validator; the additional 27 pass the extended
validator. The only changes in the earlier lines are five interval
endpoint displays, narrowed by the corrected rational conversion. The
values rounded in the original tables are unchanged.

The extended validator uses exact rational comparisons for all nine
conversion brackets, a separate bilinear NumPy enumeration for the 74
MAX-CUT graphs, rational corner enumeration for the 16 signed models,
and independent SymPy inverses for 60 path cases and 390 tail
identities. Fraction shortest paths and direct inequalities reproduce
the new clock cases. Fifteen additional exact weighted-path calculations
verify positivity, row sums, detailed balance and the diagonal
derivative. Rational brackets for $\sqrt{5}$ establish the displayed
lookahead thresholds without relying on decimal rounding.

The proofs and checks have different scopes. Theorem 12.6 proves
hardness for arbitrary instances; enumerating 74 small graphs does not
prove hardness. Lemma 12.15 proves the 600-model dyadic budget; finite
output agreement alone would not establish it. The interval proof
assumes the stated binary64 semantics and valid inputs; the finite
boundary cases do not verify every possible API call. No training or
benchmark comparison is inferred from these checks.

The source archive includes kernel files, the original and extended
validators, the complete result JSON and text files, the 600-model CSV,
the figure generator and document builder, and the unchanged input
manuscript and source archive. It records .NET SDK 8.0.427 and runtime
8.0.33, Python 3.12.14, NumPy 2.3.5 and SymPy 1.14.0. Only the corrected
source files are required for a fresh kernel run; no third-party .NET
packages are used. Python dependencies and a .NET 8 SDK are listed in
the reproduction instructions.

To reproduce, run the C# project in Release configuration with a chosen
output directory; redirect its standard output to a text file. Run the
extended Python validator against that output, then run the original
validator against the extracted first 71 lines. Run the document builder
after both result files report success. The README supplies the relative
commands and directory layout, and the manifest records SHA-256 digests
for the delivered sources and results.

# References

Abramsky, S., & Brandenburger, A. (2011). The sheaf theoretic structure
of non locality and contextuality. *New Journal of Physics, 13*, 113036.
https://doi.org/10.1088/1367-2630/13/11/113036. Author manuscript:
https://arxiv.org/abs/1102.0264

Beckers, S., & Halpern, J. Y. (2019). Abstracting causal models.
*Proceedings of the AAAI Conference on Artificial Intelligence, 33*(1),
2678--2685. https://doi.org/10.1609/aaai.v33i01.33012678

Bongers, S., Forré, P., Peters, J., & Mooij, J. M. (2021). Foundations
of structural causal models with cycles and latent variables. *The
Annals of Statistics, 49*(5), 2885--2915.
https://doi.org/10.1214/21-AOS2064

Dechter, R., & Pearl, J. (1991). Directed constraint networks: A
relational framework for causal modeling. *Proceedings of the 12th
International Joint Conference on Artificial Intelligence*.
https://ijcai.org/proceedings/1991/171

Dechter, R., Meiri, I., & Pearl, J. (1991). Temporal constraint
networks. *Artificial Intelligence, 49*(1--3), 61--95.
https://doi.org/10.1016/0004-3702(91)90006-6

Ghosh, D. P. (2026). *Autoregressive Sheaf Evolution A mathematics of
layered design search in six parts* (Fourth revision, 22 October 2026).
Research monograph. Part I Sections 2--5 and 8; Part II Sections 2--3
and 9; Part V Section 14.

Hansen, J., & Ghrist, R. (2019). Toward a spectral theory of cellular
sheaves. *Journal of Applied and Computational Topology, 3*, 315--358.
https://doi.org/10.1007/s41468-019-00038-7

Harary, F. (1953). On the notion of balance of a signed graph. *Michigan
Mathematical Journal, 2*(2), 143--146.
https://doi.org/10.1307/mmj/1028989917

IEEE. (2019). *IEEE standard for floating-point arithmetic* (IEEE Std
754-2019). https://doi.org/10.1109/IEEESTD.2019.8766229

Karp, R. M. (1972). Reducibility among combinatorial problems. In R. E.
Miller, J. W. Thatcher, & J. D. Bohlinger (Eds.), *Complexity of
computer computations* (pp. 85--103). Plenum Press.
https://doi.org/10.1007/978-1-4684-2001-2_9

Kreinovich, V., Lakeyev, A., Rohn, J., & Kahl, P. (1998). *Computational
complexity and feasibility of data processing and interval
computations*. Kluwer Academic Publishers.
https://doi.org/10.1007/978-1-4757-2793-7

Moore, R. E., Kearfott, R. B., & Cloud, M. J. (2009). *Introduction to
interval analysis*. Society for Industrial and Applied Mathematics.
https://doi.org/10.1137/1.9780898717716

Pearl, J. (2009). Causal inference in statistics: An overview.
*Statistics Surveys, 3*, 96--146. Author publication record:
https://bayes.cs.ucla.edu/csl_papers.html, report R-350.

Robinson, M. (2016). *Sheaves are the canonical datastructure for sensor
integration*. arXiv:1603.01446. https://arxiv.org/abs/1603.01446

Rubenstein, P. K., Weichwald, S., Bongers, S., Mooij, J. M., Janzing,
D., Grosse-Wentrup, M., & Schölkopf, B. (2017). Causal consistency of
structural equation models. *Proceedings of the 33rd Conference on
Uncertainty in Artificial Intelligence*, 151--160.
https://proceedings.mlr.press/r15/rubenstein-17a.html

Rump, S. M. (2010). Verification methods: Rigorous results using
floating-point arithmetic. *Acta Numerica, 19*, 287--449.
https://doi.org/10.1017/S096249291000005X

Russold, F. (2022). *Persistent sheaf cohomology*. arXiv:2204.13446.
https://arxiv.org/abs/2204.13446

Särkkä, S. (2013). *Bayesian filtering and smoothing*. Cambridge
University Press. Author publication page:
https://users.aalto.fi/\~ssarkka/

Usmani, R. A. (1994). Inversion of a tridiagonal Jacobi matrix. *Linear
Algebra and Its Applications, 212--213*, 413--414.
https://doi.org/10.1016/0024-3795(94)90414-6

Yang, Z., Luo, W., Chen, Y., & Ou, S. (2026). *From document layout to
causal topology: An end-to-end architecture for temporal causal
reasoning*. arXiv:2610.34094v1, 25 October 2026.
https://arxiv.org/abs/2610.34094. Version examined: the supplied 34 page
PDF, especially Sections 2.2, 3.1.2 and 3.3 and Appendix F.4.1.
Conference publication status is not required for the present arguments.
