"""Independent exact verification of the added C# output and analytic consequences."""
from pathlib import Path
from fractions import Fraction as F
import itertools, json, math, sys
import numpy as np
import sympy as sp
P=Path(__file__).resolve().parent
lines=(P/'kernel/cs_out_v3.txt').read_text().splitlines()
cs={line.split('\t')[0]:line.split('\t')[1].split() for line in lines}
added={k:v for k,v in cs.items() if k.startswith('v3_')};checks=[]
def check(name,ok,detail=''):
    checks.append(dict(name=name,passed=bool(ok),detail=str(detail)))
def exact(name,expected):
    key='v3_'+name;check(key,[F(x) for x in added[key]]==list(map(F,expected)))
def matrat(m):return sp.Matrix([[sp.Rational(x.numerator,x.denominator) if isinstance(x,F) else x for x in row] for row in m])
def pathlap(n):return sp.zeros(1) if n==1 else sp.Matrix(n,n,lambda i,j:(1 if i in (0,n-1) else 2) if i==j else (-1 if abs(i-j)==1 else 0))

values={'subnormal_exact':F(1,2**1024),'half_min_subnormal':F(1,2**1075),'min_subnormal':F(1,2**1074),
        'one_third':F(1,3),'huge_near_one':F(2**2000,2**2000+1),'negative_tiny':F(-1,2**1075),
        'midpoint_above_one':F(2**53+1,2**53),'normal_boundary':F(2**53-1,2**1075),
        'max_finite':F(sys.float_info.max)}
for name,q in values.items():
    row=added['v3_bracket_'+name];lo,hi=map(float,row[:2])
    check('v3_bracket_'+name,F(lo)<=q<=F(hi) and row[2:]==['1','1'] and (lo==hi or math.nextafter(lo,math.inf)==hi))
exact('old_dyadic_shortcut',[0,0,1]);exact('interval_rejection',[1]*4);exact('vertex_guards',[1]*4)
exact('single_time_smoother',[1,1])

graphs=0;ok=0
for n in range(2,5):
    possible=list(itertools.combinations(range(n),2));X=np.array(list(itertools.product((-1,1),repeat=n)),dtype=np.int64)
    for bits in itertools.product((0,1),repeat=len(possible)):
        edges=[e for e,b in zip(possible,bits) if b];C=np.zeros((len(edges),n),dtype=np.int64)
        for e,(a,b) in enumerate(edges):C[e,a]=1;C[e,b]=-1
        Y=np.array(list(itertools.product((-1,1),repeat=len(edges))),dtype=np.int64).reshape(-1,len(edges)) if edges else np.empty((1,0),dtype=np.int64)
        objective=Y@C@X.T;maxcut=max(sum(row[a]!=row[b] for a,b in edges) for row in X)
        graphs+=1;ok+=int(objective.max()==2*maxcut and objective.min()==-2*maxcut)
exact('maxcut_reduction',[graphs,ok]);exact('triangle_response_range',[-4,4])
for name,den in [('cancellation_100',100),('cancellation_million',1000000)]:
    row=added['v3_'+name];eps=F(1,den);lo,hi=map(float,row[2:4])
    expected=[-eps,eps,1+2/eps]
    check('v3_'+name,[F(row[0]),F(row[1]),F(row[4])]==expected and F(lo)<=-2-eps and F(hi)>=2+eps)
exact('tied_parameter_values',[0,F(1,4),0])

class Rng:
    def __init__(self,s):self.s=s
    def uniform(self):
        self.s=(self.s+0x9E3779B97F4A7C15)&0xffffffffffffffff;z=self.s
        z=((z^(z>>30))*0xBF58476D1CE4E5B9)&0xffffffffffffffff
        z=((z^(z>>27))*0x94D049BB133111EB)&0xffffffffffffffff
        z^=z>>31;return (z>>11)/2**53
    def integer(self,a,b):return a+math.floor(self.uniform()*(b-a+1))
rng=Rng(2026103003);corners_ok=0
for instance in range(16):
    signs=[1]+[-1 if rng.integer(0,1)==0 else 1 for _ in range(4)];edges=[];boxes=[];sig=[]
    for v in range(1,5):
        for w in range(v):
            keep=(w==v-1)
            if not keep:keep=rng.uniform()<.4
            if not keep:continue
            k=rng.integer(1,4);a,b=F(k,4),F(k+1,4);s=signs[v]*signs[w]
            edges.append((v,w));boxes.append((a,b) if s>0 else (-b,-a));sig.append(s)
    def evaluate(g):
        r=[F(1)]+[F(0)]*4
        for v in range(1,5):r[v]=sum((g[k]*r[w] for k,(child,w) in enumerate(edges) if child==v),F(0))
        return r[-1]
    evaluated=[evaluate([boxes[k][b] for k,b in enumerate(bits)]) for bits in itertools.product((0,1),repeat=len(edges))]
    c0=evaluate([b[0] if s>0 else b[1] for b,s in zip(boxes,sig)])
    c1=evaluate([b[1] if s>0 else b[0] for b,s in zip(boxes,sig)])
    corners_ok+=int((min(evaluated),max(evaluated))==(min(c0,c1),max(c0,c1)))
exact('sign_coherent_models',[16,corners_ok,16])

path_cases=path_ok=tail_cases=tail_ok=0
for r in map(F,['1/4','1/3','1/2','2/3','3/4']):
    w=r/(1-r)**2
    for n in range(1,13):
        K=(sp.eye(n)+sp.Rational(w.numerator,w.denominator)*pathlap(n)).inv()
        row=[F(K[0,j]) for j in range(n)]
        expected=[(1-r)*(r**j+r**(2*n-j-1))/(1-r**(2*n)) for j in range(n)]
        path_cases+=1;path_ok+=int(row==expected)
        for m in range(n):
            tail_cases+=1;tail_ok+=int(sum(row[m+1:],F(0))==(r**(m+1)-r**(2*n-m-1))/(1-r**(2*n)))
exact('path_closed_form',[path_cases,path_ok,tail_cases,tail_ok])
K4=(sp.eye(4)+pathlap(4)).inv()
exact('minimax_T4_w1',[sum((F(K4[0,j]) for j in range(m+1,4)),F(0))/2 for m in range(4)])
K10=(sp.eye(4)+10*pathlap(4)).inv();exact('nonmonotone_future_entry',[F(K10[0,1]),F(1,4)])
def distances(n,edges):
    d=[[None]*n for _ in range(n)]
    for i in range(n):d[i][i]=F(0)
    for i,j,c in edges:
        c=F(c)
        if d[i][j] is None or c<d[i][j]:d[i][j]=c
    for k in range(n):
        for i in range(n):
            for j in range(n):
                if d[i][k] is None or d[k][j] is None:continue
                v=d[i][k]+d[k][j]
                if d[i][j] is None or v<d[i][j]:d[i][j]=v
    return d
def consistent(d):return all(d[i][i]>=0 for i in range(len(d)))
tied_edges=[(0,1,1),(1,0,0),(0,2,1),(2,0,0),(1,2,0),(2,1,0)]
dt=distances(3,tied_edges)
corner_feasible=all([0,0,1][j]-[0,0,1][i]<=c for i,j,c in tied_edges)
exact('clock_marginals',[-dt[1][0],dt[0][1],-dt[2][0],dt[0][2],int(corner_feasible)])
low=distances(2,[(0,1,0),(1,0,F(-1,2))]);high=distances(2,[(0,1,1),(1,0,F(-1,2))])
exact('clock_uncertain_corners',[int(consistent(low)),int(consistent(high))])
cycle_sum=F(-1);allowance=F(1,2);exact('clock_cycle_margin',[cycle_sum,allowance,cycle_sum+allowance])
dated_edges=[(0,1,1),(1,0,0),(0,2,1),(2,0,0),(2,1,F(-1,2)),(1,2,1)]
true_times=[F(0),F(1,10),F(9,10)]
assert all(true_times[j]-true_times[i]<=c for i,j,c in dated_edges)
exact('point_date_false_contradiction',[true_times[2]-true_times[1],F(4,5),0,F(1,2),int(consistent(distances(3,dated_edges)))])
exact('inconsistent_clock_rejected',[int(not consistent(low))]*2)
assert set(added)=={c['name'] for c in checks},set(added)-{c['name'] for c in checks}

# A separate finite exact check of the weighted graph resolvent theorem.
weighted_cases=weighted_pass=0
for n in range(2,7):
    L=pathlap(n);G=sp.diag(*range(1,n+1));last=None
    for w in [sp.Rational(1,4),sp.Integer(1),sp.Integer(4)]:
        H=G+w*L;K=H.inv()*G;a=1-K[0,0]
        derivative=-(H.inv()*L*H.inv()*G)[0,0]
        good=(K*sp.ones(n,1)==sp.ones(n,1) and G*K==K.T*G and all(x>0 for x in K)
              and derivative<0 and (last is None or a>last))
        weighted_cases+=1;weighted_pass+=int(bool(good));last=a
assert weighted_pass==weighted_cases

# Rational bracketing of sqrt(5) certifies the reported rounded lookahead values.
d=10**40;k=math.isqrt(5*d*d);sqrt_lo,sqrt_hi=F(k,d),F(k+1,d)
rlo,rhi=(3-sqrt_hi)/2,(3-sqrt_lo)/2
assert rlo**4>F(1,50)>rhi**5
extras={'maxcut_graphs':graphs,'maxcut_agree':ok,'sign_coherent_models':16,'sign_coherent_exact':corners_ok,
        'path_cases':path_cases,'tail_cases':tail_cases,'weighted_resolvent_cases':weighted_cases,
        'unit_rho_bounds':[str(rlo),str(rhi)],'unit_minimax_limit':float((rlo+rhi)/4),
        'unit_m3_risk_bounds':[str(rlo**4/2),str(rhi**4/2)],
        'unit_m4_risk_bounds':[str(rlo**5/2),str(rhi**5/2)],
        'minimum_uniform_lookahead_for_one_percent':4,
        'vertex_dyadic_numerator_bound':32*14**6,'vertex_dyadic_significant_bits':(32*14**6).bit_length(),
        'vertex_dyadic_grid_exponent':18}
result={'checks':checks,'all_passed':all(c['passed'] for c in checks),'additional_Csharp_lines':len(added),'total_Csharp_lines':len(cs),
        'exact_analytic_checks':extras,'python':sys.version.split()[0],'sympy':sp.__version__,'numpy':np.__version__}
(P/'v3_results.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
assert result['all_passed'],[c for c in checks if not c['passed']]
(P/'cs_original_lines_v3.txt').write_text('\n'.join(line for line in lines if not line.startswith('v3_'))+'\n')
