---
title: "Evidence and Computation"
subtitle: "Making Autoregressive Sheaf Evolution checkable. Part VI: stable and certified reads, the arithmetic of evidence, and the contracts of an implementation"
author:
  - "Debi Prasad Ghosh"
  - "Founder and Principal Engineer, Debias Parametric Guru, Kolkata, India"
date: "Defensible Intelligence series · Autoregressive Sheaf Evolution, Part VI · 21 October 2026 · “Respect science. Import emotion.”"
abstract: |
  Parts I to V of Autoregressive Sheaf Evolution (ASE) proved what a layer, a stack, an estimate and a fusion compute. This paper, Part VI and the last part of the book, asks what it takes to compute them reliably and to claim anything from the results. On computation, unshifted exponentials failed in 57% of reads at scale 0.03 and in 99.8% at 0.003, while shifted ones agreed with an extended-precision reference to $1.7\times10^{-14}$. We give a certificate for reads restricted to the $k$ nearest records. It was never violated in 1,200 reads, but it is honest only where the omitted mass is genuinely small: it certified an omitted share of 0.035 at $k=512$ of 2,000, and almost nothing at $k=8$. Reordering a sum stays within Higham's bound, which fixes the tolerance a cross-language comparison may use. On evidence, we restate four classical rules in ASE terms: paired sample sizes, Holm's correction, selection optimism, and the limits of in-sample diagnostics. Part III's pilot made 72 comparisons; under the null, an uncorrected family of that size errs with probability 0.975. Choosing the best of seven schedules on the same data inflates the winner by 1.35 standard errors on average. We prove that the in-sample estimate of the weight second moment never exceeds the number of draws, so no finite sample can reveal infinite variance. An exploration on Part IV's double well shows the consequence. Selecting the importance width by in-sample effective size picked a width with infinite-variance weights in 54.5% of runs with 100 draws per width and 69.5% with 500, while reporting a second moment of 2.5 and 5.1 against a true optimum of 9.5. The paper closes the book with the contracts an ASE implementation must report, a register of the evidence of all six parts, and the status of hypotheses C1 to C5. There are 8 numerical checks and one exploration, and an immutable C# kernel matches an independent NumPy implementation on every output line.
---

# 1 Introduction

Autoregressive Sheaf Evolution (ASE) generalises the reads of Autoregressive Diffusion Evolution (ADE) to observation stars with edge maps and scale-dependent covers [7, 8, 9]. Five parts of this book have built its mathematics. Part I separated the horizontal and vertical axes [10]. Part II worked out one layer [11] and Part III a stack [12]. Part IV fixed the target of a run [13], and Part V the rules for fusion and constraints [14]. Each part ended by passing obligations forward. Part II asked Part VI to turn its retention rule, certificates and index contract into kernel specifications. Part III passed on the diagnostics of a stack, Part IV the error ledger of an estimate, and Part V the contracts of fusion. This paper, Part VI, discharges those obligations and asks two final questions. What does it take to compute ASE quantities reliably? And what does it take to claim anything from the results?

The two questions are linked. A number computed unreliably is not evidence, and a reliable number is not evidence either if it was selected from many. The series has met both failures. In the Separator Anchors paper, an undamped Newton solver produced an apparent violation of a proved bound in 247 of 400 trials; a stationarity certificate exposed it as a solver failure [15]. In Part III, a pilot made 72 comparisons, and its verdict needed a declared decision rule to mean anything [12, Section 5.3]. Part VI makes such lessons into rules.

## 1.1 Contributions

- **Computation (Section 2).** Shifted exponentials are necessary at the fine scales where ASE resolves records (Proposition 2.2). A read over the $k$ nearest records carries a certificate on its omitted share and its error (Proposition 2.3). Summation order bounds the disagreement between correct implementations (Proposition 2.4).
- **Evidence (Section 3).** Paired sample sizes, family-wise correction and selection optimism, stated for ASE comparisons (Propositions 3.1 to 3.3). The in-sample estimate of the weight second moment is at most the number of draws, so infinite variance is invisible in sample (Proposition 3.4). An exploration measures what selecting by that estimate does.
- **Contracts (Section 4).** A consolidated list of what every layer, stack, estimate and fusion must report. A rule for numerical counterexamples (Proposition 4.1). A register of the evidence of all six parts, and the status of the hypotheses of V2.
- **Evidence.** There are 8 numerical checks and one exploration (Table 4). An immutable C# kernel agrees with an independent NumPy implementation on every output line (Appendix A).

## 1.2 Scope and status of statements

The computational statements concern IEEE double precision and the Gaussian read with identity maps. The evidential statements are classical results of numerical analysis and statistics, restated for ASE. Their value here is in the specific consequences, which are checked. Every statement in a shaded box ends with a provenance tag. *Classical* marks a known result restated in ASE notation. *Part I* to *Part V* refer to [10] to [14]. *New in Part VI* marks a statement proved here for the first time in this programme; each comes with a proof and a numerical check.


# 2 Computation

## 2.1 Cost

::: {custom-style="Statement"}
**Proposition 2.1** (cost of reads). With $n$ records in $ℝ^D$, a full Gaussian read costs $O(nD)$ operations per token and layer, and a stack of $T$ layers $O(TnD)$ per token. A read over the $k$ nearest records costs $O(kD)$ plus the cost of finding them. With an index whose query cost is sublinear in $n$, the read becomes sublinear too, but only if the certificate of Proposition 2.3 is small enough to accept.
:::

::: {custom-style="Statement Tag"}
Classical accounting; the index contract is Part II, Section 5.3.
:::

The full read is linear in the archive, like attention over a context. Every saving comes from reading fewer records. Every saving therefore needs a statement of what the omitted records could have changed.

## 2.2 Shifted exponentials

::: {custom-style="Statement"}
**Proposition 2.2** (stable reads). Compute the logits $\ell_i=\log w_i-\Vert z-y_i\Vert^2/2s^2$, subtract their maximum, exponentiate and normalise. In exact arithmetic this gives the posterior weights of the read. In floating point, no term overflows, the largest term is exactly one, and the computed weights have small relative error. Without the shift, every term underflows to zero once all logits fall below about $-745$, and the read is $0/0$.
:::

::: {custom-style="Statement Tag"}
Classical; Blanchard, Higham and Higham give the error analysis [1].
:::

*Proof.* Subtracting a constant from every logit multiplies every weight by the same factor, which normalisation removes. After the shift the largest exponent is $0$ and the others are at most $0$. The smallest positive double is about $e^{-745}$. ∎

Fine scales are not an edge case in ASE: the top layers of a stack run at $s$ much smaller than the spacing of the records, and a clean top takes $s_1\to0$ (Part III, Proposition 3.6). The logits scale as $1/s^2$, so the unshifted read fails exactly where the stack makes its decisions.

::: {custom-style="Check"}
*Numerical check.* For 500 random reads of 50 records in $ℝ^3$ at each scale, the unshifted read failed in 0, 4.8, 57.4, 96.2 and 99.8% of cases at $s=1$, 0.1, 0.03, 0.01 and 0.003. The shifted read agreed with an extended-precision reference to 1.7 × 10⁻¹⁴ relative to the record scale, at every scale.
:::

## 2.3 Certified truncation

::: {custom-style="Statement"}
**Proposition 2.3** (a certificate for nearest-record reads). Let the read use only the $k$ records nearest to $z$, and let $d_{(k+1)}$ be the distance to the nearest omitted record. Put $L_K=\log\sum_{i\le k}e^{\ell_i}$ over the kept records and
:::

::: {custom-style="Statement Equation"}
$L_O=\log(n-k)+\max_i\log w_i-\frac{d_{(k+1)}^2}{2s^2},\qquad\varepsilon=\frac{1}{1+e^{L_K-L_O}}$ (2.1)
:::

::: {custom-style="Statement"}
Then the posterior share of the omitted records is at most $\varepsilon$, and the truncated read differs from the full read by at most $\varepsilon\,\text{diam}\{y_i\}$.
:::

::: {custom-style="Statement Tag"}
New in Part VI in this nearest-record form; Part II, Section 5, gives certificates for stars.
:::

*Proof.* Each omitted logit is at most $\max_i\log w_i-d_{(k+1)}^2/2s^2$, so the omitted mass is at most $e^{L_O}$. The omitted share $O/(K+O)$ increases in $O$, which gives $\varepsilon$. The full read is $(1-\varepsilon')m_K+\varepsilon'm_O$, where $\varepsilon'\le\varepsilon$ is the true share and $m_K,m_O$ are the reads over the kept and omitted records. Both lie in the hull of the records, so the difference from $m_K$ is $\varepsilon'\Vert m_O-m_K\Vert\le\varepsilon\,\text{diam}$. ∎

The certificate also feeds Part IV. A proposal density evaluated on the $k$ nearest components satisfies Proposition 4.4 of Part IV with $\kappa=\log(1/(1-\varepsilon))$.

::: {custom-style="Check"}
*Numerical check.* With 2,000 records in $ℝ^4$, scale 0.5 and 300 random queries for each $k$, the certificate was never violated. The certified omitted share had medians 0.999, 0.991, 0.884 and 0.035 for $k=8$, 32, 128 and 512. The largest actual error was 0.036, 0.019, 0.010 and 0.0021 of the certified bound.
:::

The certificate is valid but crude. Its worst case puts all the omitted records at the nearest omitted distance, so it certifies almost nothing until $k$ is a sizeable fraction of the archive; here, at a quarter of the archive, it certified an omitted share of 3.5%. The actual errors were about 28 to 480 times smaller than the bound. A sharper certificate needs a bound on how many records lie in each shell around the query, which is what a spatial index can supply (open problem 2).

## 2.4 Summation order

::: {custom-style="Statement"}
**Proposition 2.4** (implementations may disagree, within a bound). Any recursive summation of $x_1,\ldots,x_n$ in floating point with unit roundoff $u$ differs from the exact sum by at most $\gamma_{n-1}\sum_i|x_i|$, where $\gamma_m=mu/(1-mu)$. Two correct implementations that sum in different orders therefore differ by at most $2\gamma_{n-1}\sum_i|x_i|$.
:::

::: {custom-style="Statement Tag"}
Classical, Higham [3, Section 4.2].
:::

This is the rule behind every cross-language comparison in the series. NumPy and C# sum in different orders, so their outputs cannot be expected to agree to the last digit. They should agree to within the bound, scaled by the sum of absolute values, not the result. When the result is a small difference of large terms, as in the penalty distances of Part V, an absolute tolerance is the right one.

::: {custom-style="Check"}
*Numerical check.* For 200 sums of 10,000 terms with magnitudes spread over many orders, a randomly permuted recursive sum differed from the exactly rounded sum by at most 0.0026 of the bound.
:::

![**Figure 1.** (a) Share of reads in which unshifted exponentials underflow, against the scale; shifted reads never fail (Proposition 2.2). (b) For reads over the $k$ nearest of 2,000 records: the certified omitted share (median) and the largest ratio of the actual error to its certified bound (Proposition 2.3).](fig/computation.png){width=100%}


# 3 Evidence

## 3.1 Paired comparisons and their size

Every comparison in the series, of schedules, proposals or fusion rules, is paired: both arms see the same archives, tokens or draws. Pairing removes the shared variation, and the sample size follows from the variation that remains.

::: {custom-style="Statement"}
**Proposition 3.1** (paired sample size). To detect a mean paired difference $\delta>0$ with standard deviation $\sigma_d$ by a one-sided test at level $\alpha$ with power $1-\beta$, about
:::

::: {custom-style="Statement Equation"}
$n=\left\lceil\frac{(z_{1-\alpha}+z_{1-\beta})^2\sigma_d^2}{\delta^2}\right\rceil$ (3.1)
:::

::: {custom-style="Statement"}
pairs are needed, with $z_p$ the standard normal quantile. A non-inferiority test with margin $\delta$ uses the same formula.
:::

::: {custom-style="Statement Tag"}
Classical.
:::

::: {custom-style="Check"}
*Numerical check.* For $\delta=0.02$, $\sigma_d=0.06$, $\alpha=0.05$ and power 0.8, (3.1) gives 56 pairs. In 20,000 simulated studies, a one-sided paired $t$-test with 56 pairs had power 0.788 and size 0.049. The normal formula slightly overstates the power of the $t$-test at this size.
:::

## 3.2 Many comparisons

::: {custom-style="Statement"}
**Proposition 3.2** (family-wise error). If $m$ independent null comparisons are each tested at level $\alpha$, at least one rejects with probability $1-(1-\alpha)^m$. Holm's step-down procedure, which compares the $r$-th smallest $p$-value with $\alpha/(m-r+1)$ and stops at the first failure, controls this probability at $\alpha$ for any dependence among the tests.
:::

::: {custom-style="Statement Tag"}
Classical, Holm [4].
:::

::: {custom-style="Check"}
*Numerical check.* With $m=72$, the size of Part III's pilot, 20,000 simulated families of null $p$-values had a family-wise error of 0.975 without correction, as the formula says, and 0.049 with Holm's procedure.
:::

Part III's pilot did not test 72 null hypotheses and reject some. It declared a decision rule with intervals in advance, and every comparison fell outside the margin. The verdict is robust to correction for that reason. A future study that reports the best of many comparisons should state its family and correct for it.

## 3.3 Choosing the best

::: {custom-style="Statement"}
**Proposition 3.3** (selection optimism). If $m$ candidates have equal true value and independent estimates with standard error $\sigma$, the estimate of the selected best exceeds the truth by $\sigma\,E\max(Z_1,\ldots,Z_m)$ on average, where the $Z_j$ are standard normal. This is at most $\sigma\sqrt{2\log m}$.
:::

::: {custom-style="Statement Tag"}
Classical.
:::

::: {custom-style="Check"}
*Numerical check.* With 200,000 simulations, the mean maximum was 0.564, 1.351 and 2.160 for $m=2$, 7 and 40, against the bounds 1.18, 1.97 and 2.72.
:::

Part III compared seven schedules and Part IV scanned 40 widths. A winner chosen among seven on the same data looks better than it is by 1.35 standard errors on average, even when all seven are equal. Its value must be confirmed on fresh data, which is why Part III proposed the curvature schedule for a confirmatory test rather than declaring it best.

## 3.4 What in-sample diagnostics cannot see

Part IV showed that importance weights from an archive proposal have infinite second moment below a width threshold. A natural repair is to measure the second moment in sample and choose the width that minimises it. That repair fails.

::: {custom-style="Statement"}
**Proposition 3.4** (infinite variance is invisible in sample). For any positive weights $w_1,\ldots,w_n$, the in-sample second-moment estimate satisfies
:::

::: {custom-style="Statement Equation"}
$1\le\hat m_2=\frac{n\sum_iw_i^2}{\left(\sum_iw_i\right)^2}\le n$ (3.2)
:::

::: {custom-style="Statement"}
So no sample of size $n$ can report a second moment above $n$, whatever the true $m_2$ is, including $m_2=\infty$. When $m_2=\infty$, the heavy tail that makes it infinite is rarely sampled, and $\hat m_2$ is usually small.
:::

::: {custom-style="Statement Tag"}
New in Part VI as stated; the inequalities are elementary, and the effective sample size $n/\hat m_2$ is Kong's [5].
:::

*Proof.* By the Cauchy–Schwarz inequality $(\sum_iw_i)^2\le n\sum_iw_i^2$, which gives the lower bound. For positive weights $\sum_iw_i^2\le(\sum_iw_i)^2$, which gives the upper bound. ∎

## 3.5 Exploration: choosing an importance width in sample

We repeated Part IV's width scan as a selection procedure. For each of 200 runs, we drew $n$ points at each of the 40 widths from Part IV's archive proposal on the double well. We computed $\hat m_2$ for each width and selected the width with the smallest value. We then looked up the true $m_2$ of the selected width from Part IV's quadrature (Figure 2).

With $n=100$ draws per width, the selected width had infinite true second moment in 54.5% of runs. With $n=500$ the share rose to 69.5%; with $n=2000$ it fell to 5.5%. The selected widths reported median in-sample values of 2.46, 5.07 and 9.01. The smallest true second moment over all widths is 9.50, so the winners looked better than any width actually is. With 500 draws the procedure was worse than with 100. More draws made the narrow widths look better, because their tails were still unsampled while their bulk looked well matched. Only at 2,000 draws did the tails appear often enough to reveal them. The median selected width was then 1.17, the true optimum.

The remedy is not more care in sample. It is a declared rule that does not depend on the sample: here, the threshold of Part IV, Proposition 3.4, or a defensive component that makes every width safe. Where no such rule exists, selection must be confirmed on held-out draws, at a sample size planned in advance.

![**Figure 2.** Selecting the importance width by in-sample effective size, in 200 runs for each number of draws per width. (a) Share of runs in which the selected width had infinite true second moment. (b) Median in-sample $\hat m_2$ of the selected width, against the smallest true $m_2$ over all widths (dashed).](fig/selection.png){width=100%}


# 4 Contracts of an ASE implementation

## 4.1 What every computation reports

Table 1 consolidates the diagnostics that Parts II to V asked an implementation to report. It is the specification against which an implementation is defensible. Each row names the part that requires it.

Table: **Table 1.** The reporting contract of an ASE implementation.

| Object | Must report | Source |
|:----------------|:------------------------------------------|:------------------|
| layer | smallest coverage or $\lambda_{\text{min}}(H)$; unresolved dimension; guaranteed decrease; Jacobian bound; branch weights | Part II, Table 7 |
| read | shifted computation; truncation certificate $\varepsilon$ and $k$ | Propositions 2.2, 2.3 |
| stack | starting-state weight and noise budget; top posterior eigenvalues; expanding layers; exact barcodes; curvature density and efficiency | Part III, Table 6 |
| estimate | base law and temperature; archive effective size; hull mass; width against the threshold; defensive share; both ledger terms | Part IV, Table 4 |
| fusion | rule and correlation assumption; shared factors; separator multiplicity; positive semidefiniteness on cycles | Part V, Table 2 |
| constraint | type, penalty and bound; acceptance; product structure across recombined blocks | Part V, Table 2 |
| comparison | family of tests and correction; pairing; sample size planned by (3.1); held-out confirmation of any selection | Section 3 |

## 4.2 Numerical counterexamples

::: {custom-style="Statement"}
**Proposition 4.1** (a counterexample must carry its certificate). Suppose a theorem bounds a quantity $Q(z^{\text{*}})\le B$ at an exact solution $z^{\text{*}}$, and $Q$ is $L$-Lipschitz. A computed $\hat z$ with a certificate $\Vert\hat z-z^{\text{*}}\Vert\le c$ establishes a violation only if $Q(\hat z)-B>Lc$. Without a certificate, a measured $Q(\hat z)>B$ establishes nothing about the theorem.
:::

::: {custom-style="Statement Tag"}
New in Part VI as a rule; the certificate for strongly convex reads is Separator Anchors, Version 3, Section 15.2 [15].
:::

*Proof.* $Q(z^{\text{*}})\ge Q(\hat z)-Lc>B$. Without $c$, the gap between $\hat z$ and $z^{\text{*}}$ is unbounded, and so is the gap between $Q(\hat z)$ and $Q(z^{\text{*}})$. ∎

The rule is simple, and the series needed it. An undamped Newton solver reported 247 apparent violations of a proved bound in 400 trials; every one of them failed its certificate [15]. A defensible numerical result reports the certificate with the number.

## 4.3 Cross-language validation

Every part of the book ran an immutable C# kernel against an independent NumPy implementation. The protocol that emerged has four rules.

1. **Same inputs.** Both languages generate their random inputs from the same SplitMix64 stream [6] with the same Box–Muller transform, so they see bit-identical data.
2. **Different algorithms.** The second implementation uses different numerical routines where it can, such as LAPACK solves instead of Gauss–Jordan elimination, so that agreement is evidence about the mathematics, not about a shared bug.
3. **Tolerances from Proposition 2.4.** Relative differences of $10^{-9}$ for ordinary quantities, absolute ones for small differences of large terms, and wider ones for finite differences, stated in advance.
4. **Certificates before verdicts.** No disagreement and no violation is reported without the certificate of Proposition 4.1.

## 4.4 The evidence of the book

Table: **Table 2.** Numerical evidence across the six parts. Kernel lines are compared between C# and NumPy.

| Part | Subject | Checks | Explorations | Kernel lines agreeing |
|:----|:--------------|:------|:----------------|:--------|
| I | the two axes | 20 | none | all |
| II | the horizontal layer | 34 | none | all |
| III | the vertical stack | 21 | C3 pilot, 72 comparisons | 18 of 18 |
| IV | targets and estimation | 16 | width scan, 40 widths | 9 of 9 |
| V | fusion and constraints | 13 | calibration; recombination | 9 of 9 |
| VI | evidence and computation | 8 | width selection in sample | 7 of 7 |

All of these are checks of mathematics, plus exploratory computations on synthetic examples. None is a confirmatory test of a hypothesis about engineering search. Table 3 records what the six parts established about the hypotheses of V2.

Table: **Table 3.** Status of the hypotheses of the conversion proposal V2 after the six parts.

| Label | Subject | What the book established | Status |
|:--------|:------------|:------------------------------------|:--------------|
| C1 | as stated in V2 | no part addressed it directly | open |
| C2 | recombination | the mechanism and its ceiling (Part II, Proposition 3.5); feasibility only across product blocks (Part V, Theorem 4.4) | open; qualified |
| C3 | schedules from component persistence | refuted in all 72 comparisons of an exploratory transport pilot (Part III, Section 5.3); replacement statements proposed | refuted in exploration; confirmatory test pending |
| C4 | symmetry | orbit indexes and the failure of continuous canonicalisation (Part II, Proposition 6.10); quotients (Part I, open problem 3) | open; constrained |
| C5 | end-to-end perturbation | the per-layer bound (Part II, Proposition 5.4) and composite bounds (Part III, Theorem 4.2) | bound available; untested |


# 5 Discussion

## 5.1 What the book claims

The six parts establish a mathematics of ASE. A layer is a harmonic extension on an observation star. A stack is a schedule acting on reads, and in the continuum limit it transports densities. A run estimates a declared Gibbs target only through a proposal with a known density and coverage. Fusion is several operations, each with its own assumptions. Part VI adds that each of these is computable reliably only with shifted reads and certificates, and that results become evidence only with planned, paired, corrected and confirmed comparisons. The book does not claim that ASE finds better designs than ADE or any other method. That claim belongs to confirmatory experiments, which the contracts of Section 4 make possible to run and to audit.

## 5.2 What is not claimed

The computational statements assume double precision and the Gaussian read with identity maps. The truncation certificate is valid but loose, and sharper ones need index structure. The evidential rules are classical and are restated, not improved. Table 3 records hypotheses, not results: one exploratory refutation and four open questions.

## 5.3 Open problems

1. **Confirmatory protocols.** Write and register the confirmatory tests of C2 to C5, with sample sizes from (3.1), the families of Proposition 3.2 and held-out confirmation.
2. **Sharper certificates.** Bound the omitted mass of a nearest-record read by counts of records in distance shells around the query, which a spatial index can provide, and measure the gain over (2.1).
3. **Diagnostics for heavy tails.** Find a diagnostic, beyond the threshold of Part IV, that detects infinite-variance weights with a stated error rate from a finite sample, or prove that none can without assumptions on the target.
4. **Reproducible reductions.** Specify summation orders for kernels so that independent implementations agree bit for bit where that is needed for audit.
5. **C1.** State its relation to the results of Parts I to V and design its test.

## 5.4 Conclusion

The book began by reading denoising evolution as layered and horizontally topological. It ends with a list of what an implementation must report. The two are connected. Every theorem of Parts I to V has hypotheses, such as declared maps, a base law, a known proposal density, independent experts or convex constraints. Every hypothesis is either reported by the implementation or it is an assumption the reader cannot check. Part VI asks that each one be reported, together with the certificate of every computed number and the planned family of every comparison. Respect for the science is the obligation to make each claim checkable.


# 6 Register of numerical checks

Table 4 lists every numerical check in Part VI. The script `p6_checks.py` produced checks 1 to 7 and the exploration, with seed 20261024; the exploration reads Part IV's results file for the true second moments. The kernel comparison of Appendix A is check 8.

Table: **Table 4.** Register of numerical checks.

| No | Statement | Check | Outcome |
|:--|:----------|:-----------------------|:-----------------------|
| 1 | Proposition 2.2 | 2,500 reads at five scales | naive failure up to 99.8%; stable to 1.7 × 10⁻¹⁴ |
| 2 | Proposition 2.3 | 1,200 truncated reads | 0 violations; error at most 0.036 of the bound |
| 3 | Proposition 2.4 | 200 permuted sums | at most 0.0026 of the bound |
| 4 | Proposition 3.1 | 20,000 simulated studies | 56 pairs; power 0.788; size 0.049 |
| 5 | Proposition 3.2 | 20,000 null families of 72 | 0.975 uncorrected; 0.049 Holm |
| 6 | Proposition 3.3 | 200,000 simulations | 1.351 for seven candidates |
| 7 | Proposition 3.4, Section 3.5 | width selection, 600 runs | 54.5%, 69.5% and 5.5% infinite |
| 8 | Appendix A | C# kernel against NumPy | 7 of 7 lines agree |

# References

::: {custom-style="Bibliography"}
[1] Blanchard, P., Higham, D. J. and Higham, N. J. (2021). Accurate computation of the log-sum-exp and softmax functions. *IMA Journal of Numerical Analysis* 41(4), 2311–2330.

[2] Box, G. E. P. and Muller, M. E. (1958). A note on the generation of random normal deviates. *Annals of Mathematical Statistics* 29(2), 610–611.

[3] Higham, N. J. (2002). *Accuracy and Stability of Numerical Algorithms*, 2nd edn. SIAM.

[4] Holm, S. (1979). A simple sequentially rejective multiple test procedure. *Scandinavian Journal of Statistics* 6(2), 65–70.

[5] Kong, A. (1992). A note on importance sampling using standardized weights. Technical Report 348, Department of Statistics, University of Chicago.

[6] Steele, G. L., Lea, D. and Flood, C. H. (2014). Fast splittable pseudorandom number generators. *Proceedings of OOPSLA 2014*, 453–472. ACM.

[7] Ghosh, D. P. (2026a). *Autoregressive Diffusion Evolution: Engineering Methods and Mathematical Foundations*. Second revised edition. DOI 10.13140/RG.2.2.10048.29444.

[8] Ghosh, D. P. (2026b). *Mathematics of Autoregressive Diffusion Evolution: Theorems, Lemmas, Proofs and Conjectures, Organised by Field*. First edition, 17 October 2026.

[9] Ghosh, D. P. (2026c). *Autoregressive Sheaf Evolution (ASE)*. Conversion proposal, version 2, 18 October 2026.

[10] Ghosh, D. P. (2026d). *Horizontally Topological, Vertically Algebraic: The Two Axes of Autoregressive Sheaf Evolution. Part I*. 18 October 2026.

[11] Ghosh, D. P. (2026e). *The Horizontal Layer: One Layer of Autoregressive Sheaf Evolution. Part II*. 18 October 2026.

[12] Ghosh, D. P. (2026f). *The Vertical Stack: Layers of Autoregressive Sheaf Evolution. Part III*. 18 October 2026.

[13] Ghosh, D. P. (2026g). *Targets and Estimation: What Autoregressive Sheaf Evolution Can Estimate. Part IV*. 21 October 2026.

[14] Ghosh, D. P. (2026h). *Fusion and Constraints: Combining Local Laws in Autoregressive Sheaf Evolution. Part V*. 21 October 2026.

[15] Ghosh, D. P. (2026i). *Separator Anchors for Sheaf Based Latent Reasoning*. Version 4, 20 October 2026.
:::

# Appendix A: an immutable C# reference kernel

The kernel computes the shifted Gaussian read and the nearest-record read with its certificate (2.1). It also gives the paired sample size (3.1) from two normal quantiles, Holm's procedure, and a Monte Carlo estimate of the expected maximum of Proposition 3.3. The random stream is a SplitMix64 generator [6] with Box–Muller normals [2], held as a value. The kernel targets .NET 8 and uses only the base class library.

```csharp
{{file:cs/Evidence.cs}}
```

The driver draws 400 records in $ℝ^3$ from the stream. It prints a read at $s=0.01$, where unshifted exponentials underflow, and a full read at $s=0.5$. It prints two truncated reads with their errors and certificates, the sample size for the example of Section 3.1, Holm's decisions for six $p$-values, and the expected maximum of seven normals from 20,000 draws. An independent NumPy script recomputes every line (Table A1).

Table: **Table A1.** C# kernel output against the NumPy recomputation.

| C# | NumPy | Difference |
|:------------------|:------------------|:----------|
{{cs_rows}}

# Appendix B: reproducibility

All results were produced with Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1, Matplotlib 3.11.2 and .NET SDK 8.0.131. The script `p6_checks.py` writes `p6_checks.json` with seed 20261024. It reads Part IV's `p4_checks.json` for the true second moments of the width scan and regenerates Part IV's archive from Part IV's seed. The script `fig_p6.py` draws the figures from the results file. The C# project in `cs/` builds the kernel and its driver, and `cs_validate.py` compares the driver's output with NumPy and writes `cs_validate.json`. The document is converted to Word by Pandoc and post-processed for equation layout and schema order. A code archive accompanies this paper.
