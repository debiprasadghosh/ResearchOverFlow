# ASE Part VI code
Run p6_checks.py (needs ../p4/p4_checks.json), fig_p6.py; build cs/ (.NET 8) and save output to cs/cs_out.txt; cs_validate.py; render4.py; pandoc paper.md -o raw.docx --reference-doc=ref.docx; postprocess.py raw.docx paper.docx.
