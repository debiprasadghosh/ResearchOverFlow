using System.Diagnostics;
using System.Text.Json;
using MvmIntervals;

var results = new Dictionary<string, object>(); var sw = Stopwatch.StartNew(); var t = Stopwatch.StartNew();
void Log(string k, object v) { results[k] = v; var s = JsonSerializer.Serialize(v); Console.WriteLine($"{k}: {(s.Length > 1800 ? s[..1800] + "..." : s)}  [{t.Elapsed.TotalSeconds:F1}s]"); t.Restart(); }

Log("axial", Axial.Run());
var dom = new List<object>();
foreach (var rho in new[] { 0.0, 0.3, 0.6, 0.9 })
    foreach (var M in new[] { 2, 3, 4, 5, 6, 8, 10, 12, 16, 20 })
    {
        var p = Dominance.PM(M, rho == 0 ? Iv.Point(0) : Normal.Dec(rho));
        dom.Add(new { rho, M, lo = p.Lo, hi = p.Hi, width = p.Width });
    }
Log("dominance", dom);
var mc = new List<object>();
foreach (var (rho, M) in new[] { (0.3, 5), (0.6, 8), (0.9, 20) }) mc.Add(new { rho, M, mc = Dominance.Mc(M, rho, 2_000_000, 20261102UL + (ulong)M) });
Log("dominance_mc", mc);
// Monte Carlo diagnostic of the exact expected cache hits (20,000 independent 300-proposal streams)
{
    int streams = 20000, N = 300; double sumRaw = 0, sumCan = 0; var locker = new object();
    Parallel.For(0, streams, k =>
    {
        var r = new SplitMix(777UL + (ulong)k * 9973UL); var seenRaw = new HashSet<int>(); var seenCan = new HashSet<string>(); int hr = 0, hc = 0;
        string[] slotName = { "", "aluminium400", "aluminium600", "aluminium800", "steel400", "steel600", "steel800" };
        for (int i = 0; i < N; i++)
        {
            int[] f = new int[6]; for (int j = 0; j < 6; j++) f[j] = r.Below(j % 3 == 2 ? 3 : 2);
            int raw = ((((f[0] * 2 + f[1]) * 3 + f[2]) * 2 + f[3]) * 2 + f[4]) * 3 + f[5];
            string S(int on, int m, int a) => on == 0 ? "" : slotName[1 + m * 3 + a];
            var names = new[] { S(f[0], f[1], f[2]), S(f[3], f[4], f[5]) }.Where(x => x != "").OrderBy(x => x, StringComparer.Ordinal);
            var can = string.Join("+", names);
            if (!seenRaw.Add(raw)) hr++; if (!seenCan.Add(can)) hc++;
        }
        lock (locker) { sumRaw += hr; sumCan += hc; }
    });
    Log("hits_mc", new { streams, N, raw = sumRaw / streams, canonical = sumCan / streams });
}
results["runtime"] = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription; results["seconds"] = sw.Elapsed.TotalSeconds;
File.WriteAllText("results.json", JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"written {sw.Elapsed.TotalSeconds:F1}s");
