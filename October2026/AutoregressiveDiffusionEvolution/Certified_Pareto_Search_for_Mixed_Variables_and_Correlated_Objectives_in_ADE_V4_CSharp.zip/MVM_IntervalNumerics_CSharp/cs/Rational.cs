using System.Numerics;
namespace MvmIntervals;

/// <summary>Exact rational with BigInteger numerator and positive denominator, always reduced.</summary>
public readonly record struct Q(BigInteger N, BigInteger D) : IComparable<Q>
{
    public static Q Of(BigInteger n, BigInteger d)
    {
        if (d.IsZero) throw new DivideByZeroException();
        if (d.Sign < 0) { n = -n; d = -d; }
        var g = BigInteger.GreatestCommonDivisor(n, d); if (g.IsZero) g = 1;
        return new(n / g, d / g);
    }
    public static implicit operator Q(long k) => new(k, 1);
    public static Q operator +(Q a, Q b) => Of(a.N * b.D + b.N * a.D, a.D * b.D);
    public static Q operator -(Q a, Q b) => Of(a.N * b.D - b.N * a.D, a.D * b.D);
    public static Q operator -(Q a) => new(-a.N, a.D);
    public static Q operator *(Q a, Q b) => Of(a.N * b.N, a.D * b.D);
    public static Q operator /(Q a, Q b) => Of(a.N * b.D, a.D * b.N);
    public int CompareTo(Q o) => (N * o.D).CompareTo(o.N * D);
    public static bool operator <(Q a, Q b) => a.CompareTo(b) < 0;
    public static bool operator >(Q a, Q b) => a.CompareTo(b) > 0;
    public static bool operator <=(Q a, Q b) => a.CompareTo(b) <= 0;
    public static bool operator >=(Q a, Q b) => a.CompareTo(b) >= 0;
    public static Q Max(Q a, Q b) => a >= b ? a : b;
    public static Q Min(Q a, Q b) => a <= b ? a : b;
    public Q Abs() => N.Sign < 0 ? -this : this;
    public Q Pow(int k) { Q r = 1; for (int i = 0; i < k; i++) r = r * this; return r; }
    public bool IsZero => N.IsZero;
    /// <summary>Rigorous double enclosure: floor of |N| 2^s / D in BigInteger, outward step, exact power-of-two scaling.</summary>
    public Iv Enclose()
    {
        if (N.IsZero) return Iv.Point(0);
        if (N.Sign < 0) return -(new Q(-N, D)).Enclose();
        int s = 60 - (int)(N.GetBitLength() - D.GetBitLength());
        BigInteger num = s >= 0 ? N << s : N, den = s >= 0 ? D : D << -s;
        var fl = BigInteger.Divide(num, den);
        return new Iv(Math.ScaleB(Math.BitDecrement((double)fl), -s), Math.ScaleB(Math.BitIncrement((double)(fl + 1)), -s));
    }
    public double ToDouble() => Enclose().Mid;
    public override string ToString() => D.IsOne ? N.ToString() : $"{N}/{D}";
}
