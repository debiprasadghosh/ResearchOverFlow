namespace MvmIntervals;

/// <summary>Exact rational reconstruction of the two-member axial example (Section 4) and the audits of Sections 5.4-5.7.</summary>
public static class Axial
{
    public sealed record Member(string Mat, int Area);
    public sealed record Rec(string Key, Q[]? F, Q V);
    static readonly Dictionary<string, (int E, int S, int Rho)> Mats = new() { ["aluminium"] = (70000, 100, 2700), ["steel"] = (200000, 150, 7850) };
    static readonly Member?[] Options = new Member?[] { null }.Concat(Mats.Keys.SelectMany(m => new[] { 400, 600, 800 }.Select(a => (Member?)new Member(m, a)))).ToArray();
    public static string Canon(IEnumerable<Member?> ms) => string.Join("+", ms.Where(m => m is not null).Select(m => $"{m!.Mat}{m.Area}").OrderBy(s => s, StringComparer.Ordinal));
    static Rec Response(Member?[] slots)
    {
        var ms = slots.Where(m => m is not null).Select(m => m!).ToList(); var key = Canon(slots);
        if (ms.Count == 0) return new Rec(key, null, 10);
        Q ea = 0, mass = 0; foreach (var m in ms) { ea = ea + (long)Mats[m.Mat].E * m.Area; mass = mass + Q.Of((long)Mats[m.Mat].Rho * m.Area * 2000, 1_000_000_000); }
        var u = Q.Of(120000L * 2000, 1) / ea;
        Q v = Q.Max(0, u / Q.Of(3, 2) - 1);
        Q worst = ms.Select(m => (Q)Mats[m.Mat].E * u / (Q)(2000L * Mats[m.Mat].S) - 1).Max();
        v = v + Q.Max(0, worst);
        return new Rec(key, new[] { mass, u }, v);
    }
    public static bool Pareto(Q[] a, Q[] b) { bool le = true, lt = false; for (int m = 0; m < a.Length; m++) { if (a[m] > b[m]) le = false; if (a[m] < b[m]) lt = true; } return le && lt; }
    static bool CDom(Rec a, Rec b)
    {
        if (a.V.IsZero && !b.V.IsZero) return true;
        if (!a.V.IsZero && !b.V.IsZero) return a.V < b.V;
        return a.V.IsZero && b.V.IsZero && Pareto(a.F!, b.F!);
    }
    static bool ADom(Rec a, Rec b, Q lam) => Pareto(a.F!.Select(f => f + lam * a.V).ToArray(), b.F!.Select(f => f + lam * b.V).ToArray());
    static bool MDom(Rec a, Rec b, Q lam) => Pareto(a.F!.Select(f => f + lam * a.V * (1 + f.Abs())).ToArray(), b.F!.Select(f => f + lam * b.V * (1 + f.Abs())).ToArray());

    public sealed record Res(int Configs, int Feasible, int Front, int Vectors, bool StrictOrder, string LambdaStar, double[] LambdaStarEncl, string SufficientBound, double SufficientOverStar,
        int DisagreeAtStar, int DisagreeJustAbove, Dictionary<string, int> MultDisagree, int UnsupportedCount, string[] Unsupported, string[] TauThresholds, string TauMin,
        string HvExact, double[] HvEncl, string HvSupported, double[] HvLossEncl, string[] IgdSupported, List<object> Theorem7, double[] BetaFor5Pct,
        string RecurrenceRaw, string RecurrenceCanon, List<object> Hits, int CanonicalKeys, int RawTuples);

    public static Res Run()
    {
        // configurations: unordered pairs of slot options
        var recs = new List<Rec>();
        for (int i = 0; i < Options.Length; i++) for (int j = i; j < Options.Length; j++) recs.Add(Response(new[] { Options[i], Options[j] }));
        int configs = recs.Select(r => r.Key).Distinct().Count();
        var feas = recs.Where(r => r.V.IsZero).ToList();
        var front = feas.Where(r => !feas.Any(g => Pareto(g.F!, r.F!))).ToList();
        var vecs = front.Select(r => r.F!).GroupBy(f => $"{f[0]}|{f[1]}").Select(g => g.First()).OrderBy(f => f[0]).ToList();
        // strict partial order on the 27 evaluated records (empty configuration has no response and is excluded)
        var ev = recs.Where(r => r.F is not null).ToList(); bool strict = true;
        foreach (var a in ev) { if (CDom(a, a)) strict = false; foreach (var b in ev) foreach (var c in ev) if (CDom(a, b) && CDom(b, c) && !CDom(a, c)) strict = false; }
        // Proposition 10: exact additive threshold
        Q lamStar = 0, dv = Q.Of(1_000_000, 1), B = 0;
        foreach (var a in ev) foreach (var b in ev)
        {
            if (a.V < b.V) for (int m = 0; m < 2; m++) lamStar = Q.Max(lamStar, (a.F![m] - b.F![m]) / (b.V - a.V));
            if (a.V.CompareTo(b.V) != 0) dv = Q.Min(dv, (a.V - b.V).Abs());
            for (int m = 0; m < 2; m++) B = Q.Max(B, (a.F![m] - b.F![m]).Abs());
        }
        int Disagree(Func<Rec, Rec, bool> rel) { int k = 0; foreach (var a in ev) foreach (var b in ev) if (!ReferenceEquals(a, b) && CDom(a, b) != rel(a, b)) k++; return k; }
        var just = lamStar * Q.Of(1_000_000_001, 1_000_000_000);
        int atStar = Disagree((a, b) => ADom(a, b, lamStar)), above = Disagree((a, b) => ADom(a, b, just));
        var mult = new Dictionary<string, int>();
        foreach (var lam in new Q[] { 0, 1, 10, 1000, 1_000_000_000 }) mult[lam.ToString()] = Disagree((a, b) => MDom(a, b, lam));
        // normalised front, supported points, achievement thresholds
        Q[] ideal = { vecs.Min(v => v[0]), vecs.Min(v => v[1]) }, nadir = { vecs.Max(v => v[0]), vecs.Max(v => v[1]) };
        Q[] Norm(Q[] f) => new[] { (f[0] - ideal[0]) / (nadir[0] - ideal[0]), (f[1] - ideal[1]) / (nadir[1] - ideal[1]) };
        var nv = vecs.Select(Norm).ToList(); int n = nv.Count;
        bool Supported(int i)
        {
            Q lo = 0, hi = 1;
            for (int j = 0; j < n; j++)
            {
                if (j == i) continue; var d1 = nv[j][0] - nv[i][0]; var d2 = nv[j][1] - nv[i][1]; var k = d1 - d2;
                if (k > 0) lo = Q.Max(lo, -d2 / k); else if (k < 0) hi = Q.Min(hi, -d2 / k); else if (-d2 > 0) return false;
            }
            return lo <= hi && !(lo.IsZero && hi.IsZero) && !(lo.CompareTo(1) == 0 && hi.CompareTo(1) == 0);
        }
        var unsup = Enumerable.Range(0, n).Where(i => !Supported(i)).ToList();
        Q[] a0 = { Q.Of(-1, 10), Q.Of(-1, 10) };
        Q[] Weights(Q[] y) { var w = new[] { 1 / (y[0] - a0[0]), 1 / (y[1] - a0[1]) }; var s = w[0] + w[1]; return new[] { w[0] / s, w[1] / s }; }
        var taus = new string[n]; Q? tauMin = null;
        for (int i = 0; i < n; i++)
        {
            var w = Weights(nv[i]); var c = w[0] * (nv[i][0] - a0[0]); Q? thr = null;
            for (int j = 0; j < n; j++)
            {
                if (j == i) continue;
                var br = Q.Max(w[0] * (nv[j][0] - a0[0]), w[1] * (nv[j][1] - a0[1])) - c;
                var S = w[0] * (nv[j][0] - nv[i][0]) + w[1] * (nv[j][1] - nv[i][1]);
                if (br <= 0) throw new InvalidOperationException("unexpected tie");
                if (S < 0) { var t = br / (-S); thr = thr is null || t < thr.Value ? t : thr; }
            }
            taus[i] = thr?.ToString() ?? "none"; if (thr is not null) tauMin = tauMin is null || thr.Value < tauMin.Value ? thr : tauMin;
        }
        // hypervolume with reference (11/10, 11/10)
        Q Hv(IEnumerable<Q[]> pts) { Q hv = 0, prev = Q.Of(11, 10); foreach (var p in pts.OrderBy(p => p[0])) { hv = hv + (Q.Of(11, 10) - p[0]) * (prev - p[1]); prev = p[1]; } return hv; }
        var hv = Hv(nv); var hvS = Hv(Enumerable.Range(0, n).Where(i => !unsup.Contains(i)).Select(i => nv[i]));
        // IGD+ of the supported subset: only the unsupported point has a positive distance
        var supPts = Enumerable.Range(0, n).Where(i => !unsup.Contains(i)).Select(i => nv[i]).ToList();
        Q igdSq = 0; var igd = Iv.Point(0);
        foreach (var z in nv) { var best = supPts.Select(p => Q.Max(0, p[0] - z[0]).Pow(2) + Q.Max(0, p[1] - z[1]).Pow(2)).Min(); igdSq = igdSq + best; igd = igd + best.Enclose().Max0().Sqrt(); }
        igd = igd / (double)n;
        // Theorem 7 on the front designs (uniform reference over the 12 feasible designs), target = the unsupported vector
        int tgt = unsup[0]; var wT = Weights(nv[tgt]); Q tau = Q.Of(1, 100);
        var g = front.Select(r => { var y = Norm(r.F!); return Q.Max(wT[0] * (y[0] - a0[0]), wT[1] * (y[1] - a0[1])) + tau * (wT[0] * (y[0] - a0[0]) + wT[1] * (y[1] - a0[1])); }).ToList();
        var gmin = g.Min(); int nmin = g.Count(x => x.CompareTo(gmin) == 0); var gap = g.Where(x => x > gmin).Select(x => x - gmin).Min();
        var th7 = new List<object>();
        foreach (double beta in new[] { 10.0, 50, 200, 1000, 2000 })
        {
            var rest = Iv.Point(0); foreach (var x in g.Where(x => x > gmin)) rest = rest + (-beta * (x - gmin).Enclose()).Exp();
            var mass = rest / ((double)nmin + rest); var bound = (Iv.Point(front.Count - nmin) / (double)nmin) * (-beta * gap.Enclose()).Exp();
            th7.Add(new { beta, nonminimal = new[] { mass.Lo, mass.Hi }, bound13 = new[] { bound.Lo, bound.Hi } });
        }
        var betaNeed = (Iv.Point(20.0 * (front.Count - nmin) / nmin)).Log() / gap.Enclose();       // bound (13) <= 0.05
        // recurrence and expected cache hits for i.i.d. proposals
        var slot = new List<(Member?, Q)> { (null, Q.Of(1, 2)) }; foreach (var m in Options.Skip(1)) slot.Add((m, Q.Of(1, 12)));
        var canP = new Dictionary<string, Q>();
        foreach (var (s1, p1) in slot) foreach (var (s2, p2) in slot) { var k = Canon(new[] { s1, s2 }); canP[k] = (canP.TryGetValue(k, out var old) ? old : 0) + p1 * p2; }
        var rawP = Enumerable.Repeat(Q.Of(1, 144), 144).ToList();
        Q Rec2(IEnumerable<Q> ps) { Q s = 0; foreach (var p in ps) s = s + p * p; return s; }
        Q Hits(List<Q> ps, int N) { Q s = N; foreach (var p in ps) s = s - (1 - (1 - p).Pow(N)); return s; }
        var hits = new List<object>();
        foreach (int N in new[] { 15, 50, 100, 300 })
        { var hr = Hits(rawP, N).Enclose(); var hc = Hits(canP.Values.ToList(), N).Enclose(); hits.Add(new { N, raw = new[] { hr.Lo, hr.Hi }, canonical = new[] { hc.Lo, hc.Hi } }); }
        return new Res(configs, feas.Count, front.Count, vecs.Count, strict, lamStar.ToString(), new[] { lamStar.Enclose().Lo, lamStar.Enclose().Hi }, (B / dv).ToString(), ((B / dv) / lamStar).ToDouble(),
            atStar, above, mult, unsup.Count, unsup.Select(i => $"({vecs[i][0]}, {vecs[i][1]})").ToArray(), taus, tauMin?.ToString() ?? "none",
            hv.ToString(), new[] { hv.Enclose().Lo, hv.Enclose().Hi }, hvS.ToString(), new[] { (hv - hvS).Enclose().Lo, (hv - hvS).Enclose().Hi },
            new[] { igdSq.ToString(), $"{igd.Lo:R}", $"{igd.Hi:R}" }, th7, new[] { betaNeed.Lo, betaNeed.Hi },
            Rec2(rawP).ToString(), Rec2(canP.Values).ToString(), hits, canP.Count, 144);
    }
}
