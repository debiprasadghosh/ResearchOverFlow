namespace MvmIntervals;

/// <summary>Proposition 8: probability that one of two independent objective vectors Pareto-dominates the other when the
/// M objectives are equicorrelated Gaussians with correlation rho in [0,1):
/// p_M(rho) = 2 * int phi(t) Phi(c t)^M dt, c = sqrt(rho/(1-rho)). Certified by the composite midpoint rule on [-12, 12]
/// with interval second-derivative remainders; |tail| &lt;= 2 Phi(-12).</summary>
public static class Dominance
{
    public static Iv PM(int M, Iv rho, int cells = 24000)
    {
        if (rho.Hi == 0) return Iv.Point(Math.ScaleB(1.0, 1 - M));
        var c = (rho / (1.0 - rho)).Sqrt(); double a = -12, b = 12, h = (b - a) / cells; var sum = Iv.Point(0);
        D2 F(Iv x)
        {
            var t = D2.Var(x); var p = (c * t).Phi(); var pw = new D2(Iv.Point(1), Iv.Point(0), Iv.Point(0));
            for (int k = 0; k < M; k++) pw = pw * p;
            return t.Pdf() * pw;
        }
        for (int i = 0; i < cells; i++)
        {
            double lo = a + i * h, hi = (i == cells - 1) ? b : a + (i + 1) * h;
            var w = Iv.Point(hi) - Iv.Point(lo); var mid = 0.5 * (Iv.Point(lo) + Iv.Point(hi));
            sum = sum + w * F(mid).V + (w.Sqr() * w) * F(new Iv(lo, hi)).DD / 24.0;
        }
        var tail = Normal.Cdf(Iv.Point(-12));
        return 2.0 * (sum + new Iv(0, 2 * tail.Hi));
    }
    /// <summary>Monte Carlo diagnostic of the same probability.</summary>
    public static double Mc(int M, double rho, int n, ulong seed)
    {
        var r = new SplitMix(seed); int hit = 0; double sr = Math.Sqrt(rho), sq = Math.Sqrt(1 - rho);
        for (int i = 0; i < n; i++)
        {
            double tx = r.Normal(), ty = r.Normal(); bool le = true, ge = true;
            for (int m = 0; m < M; m++) { double x = sr * tx + sq * r.Normal(), y = sr * ty + sq * r.Normal(); if (x > y) le = false; if (x < y) ge = false; }
            if (le || ge) hit++;
        }
        return (double)hit / n;
    }
}
