import json, math, numpy as np, matplotlib
from fractions import Fraction as Q
from itertools import combinations_with_replacement, product
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'font.family': 'DejaVu Sans'})
NAVY = '#213f63'; RUST = '#b5612f'; GREY = '#9aa3aa'; DARK = '#444444'; GOLD = '#c39a2f'; TEAL = '#2f7f86'
R = json.load(open('../cs/results.json')); S = json.load(open('../num/sym.json'))

# exact axial records (same model as Appendix A)
MAT = {'steel': (200000, 150, 7850), 'aluminium': (70000, 100, 2700)}
OPT = [None] + [(m, a) for m in MAT for a in (400, 600, 800)]
def canon(ms): return tuple(sorted(m for m in ms if m is not None))
def resp(ms):
    ms = canon(ms)
    if not ms: return None, Q(10)
    ea = sum(MAT[m][0] * a for m, a in ms); u = Q(120000 * 2000, ea)
    mass = sum(Q(MAT[m][2] * a * 2000, 10 ** 9) for m, a in ms)
    v = max(Q(0), u / Q(3, 2) - 1) + max(Q(0), max(Q(MAT[m][0]) * u / Q(2000 * MAT[m][1]) - 1 for m, a in ms))
    return (mass, u), v
recs = [resp(canon(c)) for c in combinations_with_replacement(OPT, 2)]
ev = [(f, v) for f, v in recs if f is not None]
dom = lambda a, b: all(x <= y for x, y in zip(a, b)) and any(x < y for x, y in zip(a, b))
feas = [f for f, v in ev if v == 0]
vecs = sorted(set(f for f in feas if not any(dom(g, f) for g in feas)))
ideal = (vecs[0][0], min(v[1] for v in vecs)); nadir = (vecs[-1][0], max(v[1] for v in vecs))
nv = [tuple(float((f[m] - ideal[m]) / (nadir[m] - ideal[m])) for m in range(2)) for f in vecs]

# ---------- Figure 2
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.7))
cols = {0.0: DARK, 0.3: GOLD, 0.6: TEAL, 0.9: RUST}
for rho in (0.0, 0.3, 0.6, 0.9):
    d = [x for x in R['dominance'] if x['rho'] == rho]
    ax[0].semilogy([x['M'] for x in d], [x['hi'] for x in d], 'o-', color=cols[rho], ms=3.5, lw=1.2, label=f'ρ = {rho}')
for m in R['dominance_mc']:
    ax[0].plot([m['M']], [m['mc']], 'x', color='black', ms=6, mew=1)
ax[0].plot([], [], 'x', color='black', label='Monte Carlo, 2×10⁶ pairs')
ax[0].axhline(0.01, color=GREY, ls=':', lw=0.8)
ax[0].set_xlabel('Objectives M'); ax[0].set_ylabel('Pr(the pair is comparable)')
ax[0].set_title('A  Correlation preserves rank information', fontsize=9.5); ax[0].legend(fontsize=6.4, frameon=False, loc='lower left')
unsup = [i for i, s in enumerate(S['supported']) if s is None]
xs = [p[0] for p in nv]; ys = [p[1] for p in nv]
sup = [p for i, p in enumerate(nv) if i not in unsup]
ax[1].plot([p[0] for p in sup], [p[1] for p in sup], '-', color=GREY, lw=1, label='Supported hull')
ax[1].plot([p[0] for p in sup], [p[1] for p in sup], 'o', color=NAVY, ms=4.5, label='Supported vectors')
for i in unsup:
    y = nv[i]; ax[1].plot([y[0]], [y[1]], 's', color=RUST, ms=6, label='Unsupported vector')
    a = -0.1; w = np.array([1 / (y[0] - a), 1 / (y[1] - a)]); w /= w.sum(); c = w[0] * (y[0] - a)
    # level set of the unaugmented achievement function through y: an L-shaped corner
    ax[1].plot([y[0], y[0], 1.05], [1.05, y[1], y[1]], '--', color=RUST, lw=1, label='Achievement level set')
ax[1].set_xlabel('Normalised mass'); ax[1].set_ylabel('Normalised extension')
ax[1].set_xlim(-0.05, 1.08); ax[1].set_ylim(-0.05, 1.08)
ax[1].set_title('B  Axial front: one unsupported vector', fontsize=9.5); ax[1].legend(fontsize=6.4, frameon=False, loc='upper right')
plt.tight_layout(); plt.savefig('fig2.png', dpi=300); plt.close()

# ---------- Figure 3
def cdom(A, B):
    fa, va = A; fb, vb = B
    if va == 0 and vb > 0: return True
    if va > 0 and vb > 0: return va < vb
    return va == 0 and vb == 0 and dom(fa, fb)
def dis(rel):
    return sum(1 for A, B in product(ev, repeat=2) if A is not B and cdom(A, B) != rel(A, B))
lams = [Q(0)] + [Q(10) ** k for k in range(-2, 0)] + [Q(round(10 ** (e / 4) * 1000), 1000) for e in range(0, 17)]
add = [dis(lambda A, B, l=l: dom(tuple(A[0][m] + l * A[1] for m in range(2)), tuple(B[0][m] + l * B[1] for m in range(2)))) for l in lams]
mul = [dis(lambda A, B, l=l: dom(tuple(A[0][m] + l * A[1] * (1 + abs(A[0][m])) for m in range(2)), tuple(B[0][m] + l * B[1] * (1 + abs(B[0][m])) for m in range(2)))) for l in lams]
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.6))
lx = [max(float(l), 3e-3) for l in lams]
ax[0].plot(lx, add, 'o-', color=NAVY, ms=3, lw=1.2, label='Additive penalty')
ax[0].plot(lx, mul, 's-', color=RUST, ms=3, lw=1.2, label='Multiplicative penalty (3)')
ax[0].axvline(float(S['additive_lambda_star_float']), color=NAVY, ls='--', lw=0.8); ax[0].axvline(float(S['prop2_sufficient_float']), color=GREY, ls=':', lw=0.8)
ax[0].text(float(S['additive_lambda_star_float']) * 0.8, 120, 'λ* = 202.0', rotation=90, fontsize=6.6, color=NAVY, ha='right')
ax[0].text(float(S['prop2_sufficient_float']) * 1.15, 120, 'bound 2366', rotation=90, fontsize=6.6, color=DARK, ha='left')
ax[0].set_xscale('log'); ax[0].set_xlabel('Penalty coefficient λ'); ax[0].set_ylabel('Pairs ordered differently')
ax[0].set_title('A  Penalty audit on 27 evaluated records', fontsize=9.5); ax[0].legend(fontsize=6.4, frameon=False, loc='lower left', bbox_to_anchor=(0.0, 0.12))
th = R['axial']['Theorem7']; gap = float(S['theorem7_gap_float'])
betas = np.logspace(0, 3.6, 200)
gnum = None
ax[1].loglog([t['beta'] for t in th], [t['nonminimal'][1] for t in th], 'o', color=NAVY, ms=4, label='Certified nonminimal mass')
ax[1].loglog(betas, np.minimum(11 * np.exp(-betas * gap), 20), '--', color=RUST, lw=1.1, label='Bound (13)')
ax[1].axvline(R['axial']['BetaFor5Pct'][1], color=GREY, ls=':', lw=0.8); ax[1].axhline(0.05, color=GREY, ls=':', lw=0.8)
ax[1].set_ylim(1e-5, 30); ax[1].set_xlabel('Inverse temperature β'); ax[1].set_ylabel('Mass off the minimiser')
ax[1].set_title('B  Theorem 7 needs β ≈ 1/Δ', fontsize=9.5); ax[1].legend(fontsize=6.4, frameon=False, loc='lower left')
plt.tight_layout(); plt.savefig('fig3.png', dpi=300); plt.close()

# ---------- Figure 4: expected cache hits for i.i.d. proposals
raw_p = [Q(1, 144)] * 144
slot = [(None, Q(1, 2))] + [((m, a_), Q(1, 12)) for m in MAT for a_ in (400, 600, 800)]
canp = {}
for (s1, p1), (s2, p2) in product(slot, repeat=2):
    k = canon([s1, s2]); canp[k] = canp.get(k, Q(0)) + p1 * p2
cp = [float(p) for p in canp.values()]
Ns = np.arange(1, 301)
hr = [N - sum(1 - (1 - 1 / 144) ** N for _ in range(1)) * 144 for N in Ns]
hc = [N - sum(1 - (1 - p) ** N for p in cp) for N in Ns]
fig, ax = plt.subplots(1, 1, figsize=(4.2, 2.7))
ax.plot(Ns, hr, color=NAVY, lw=1.4, label='Raw decoded tuple (144 keys)')
ax.plot(Ns, hc, color=RUST, lw=1.4, label='Canonical design (28 keys)')
ax.plot([300], [254.6], 'o', color=NAVY, ms=5, mfc='white', label='Reported ADE stream, raw')
ax.plot([300], [279.1], 's', color=RUST, ms=5, mfc='white', label='Reported ADE stream, canonical')
ax.set_xlabel('Proposals N'); ax.set_ylabel('Expected cache hits'); ax.legend(fontsize=6.4, frameon=False, loc='upper left')
plt.tight_layout(); plt.savefig('fig4.png', dpi=300); plt.close()
print('ok')
