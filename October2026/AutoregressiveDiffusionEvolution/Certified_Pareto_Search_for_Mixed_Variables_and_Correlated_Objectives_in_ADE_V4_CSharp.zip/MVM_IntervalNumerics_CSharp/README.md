# Mixed Variables, Many Objectives V4: exact rational and validated interval numerics

- cs/: .NET 8 C# program (no packages). `dotnet run -c Release` writes results.json (about 13 s).
  Rational.cs (BigInteger rationals with rigorous enclosures), Axial.cs (exact axial example, order check,
  Proposition 9 penalty audit, Proposition 10 support intervals and achievement thresholds, hypervolume, IGD+,
  Theorem 7 masses, Proposition 11 cache hits), Dominance.cs (Proposition 8, certified quadrature and Monte Carlo),
  Interval.cs, Normal.cs (validated phi/Phi, second-order interval AD), Rng.cs.
- num/sym.py: SymPy 1.14 / mpmath 1.3 / Python fractions cross-checks -> sym.json.
- fig/figs.py: Figures 2-4.
- build/: fragment sources and the docx assembly script.
Assumption: Math.Exp and Math.Log are accurate to within four ulps (results are widened accordingly).
