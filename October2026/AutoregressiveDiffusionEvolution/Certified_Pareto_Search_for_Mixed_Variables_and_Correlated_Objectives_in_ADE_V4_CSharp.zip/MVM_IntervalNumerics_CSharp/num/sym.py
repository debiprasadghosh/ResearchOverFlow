"""Exact/symbolic checks for Mixed Variables, Many Objectives V4 (SymPy 1.14, mpmath 1.3, fractions)."""
from fractions import Fraction as Q
from itertools import combinations_with_replacement, product
import sympy as sp, mpmath as mp, json, math
mp.mp.dps = 40; out = {}

# ---------------- axial enumeration (exact)
MAT = {'steel': (200000, 150, 7850), 'aluminium': (70000, 100, 2700)}
OPT = [None] + [(m, a) for m in MAT for a in (400, 600, 800)]
def canon(ms): return tuple(sorted(m for m in ms if m is not None))
def resp(ms):
    ms = canon(ms)
    if not ms: return None, Q(10)
    ea = sum(MAT[m][0] * a for m, a in ms); u = Q(120000 * 2000, ea)
    mass = sum(Q(MAT[m][2] * a * 2000, 10 ** 9) for m, a in ms)
    v = max(Q(0), u / Q(3, 2) - 1) + max(Q(0), max(Q(MAT[m][0]) * u / Q(2000 * MAT[m][1]) - 1 for m, a in ms))
    return (mass, u), v
configs = [canon(c) for c in combinations_with_replacement(OPT, 2)]
recs = [(c,) + resp(c) for c in configs]
feas = [(c, f) for c, f, v in recs if v == 0]
dom = lambda a, b: all(x <= y for x, y in zip(a, b)) and any(x < y for x, y in zip(a, b))
front = [(c, f) for c, f in feas if not any(dom(g, f) for _, g in feas)]
vecs = sorted(set(f for _, f in front))
out['axial_counts'] = [len(configs), len(feas), len(front), len(vecs)]
ideal = (min(v[0] for v in vecs), min(v[1] for v in vecs)); nadir = (max(v[0] for v in vecs), max(v[1] for v in vecs))
norm = lambda f: tuple((f[m] - ideal[m]) / (nadir[m] - ideal[m]) for m in range(2))
nv = [norm(v) for v in vecs]
out['ideal'] = [str(x) for x in ideal]; out['nadir'] = [str(x) for x in nadir]

# supported points: y is supported iff it minimises some positive weighted sum (exact LP on a finite set, 2 objectives)
def supported(i):
    # y_i minimises w*f1 + (1-w)*f2 for some w in (0,1) iff the feasible w-interval is nonempty
    lo, hi = Q(0), Q(1)
    for j, z in enumerate(nv):
        if j == i: continue
        d1, d2 = z[0] - nv[i][0], z[1] - nv[i][1]   # need w d1 + (1-w) d2 >= 0  <=> w (d1 - d2) >= -d2
        k = d1 - d2
        if k > 0: lo = max(lo, -d2 / k)
        elif k < 0: hi = min(hi, -d2 / k)
        elif -d2 > 0: return None
    return (lo, hi) if lo <= hi and not (lo == hi == 0) and not (lo == hi == 1) else None
sup = [supported(i) for i in range(len(nv))]
out['supported'] = [None if s is None else [str(s[0]), str(s[1])] for s in sup]
out['n_unsupported'] = sum(1 for s in sup if s is None)

# augmented achievement: omega propto 1/(y - a), a = (-1/10,-1/10); exact tau threshold for unique minimisation
a = (Q(-1, 10), Q(-1, 10))
taus = []
for i, y in enumerate(nv):
    w = [1 / (y[m] - a[m]) for m in range(2)]; s = sum(w); w = [x / s for x in w]
    c = w[0] * (y[0] - a[0])
    thr = None
    for j, z in enumerate(nv):
        if j == i: continue
        br = max(w[m] * (z[m] - a[m]) for m in range(2)) - c
        S = sum(w[m] * (z[m] - y[m]) for m in range(2))
        assert br > 0
        if S < 0:
            t = br / (-S); thr = t if thr is None or t < thr else thr
    taus.append(thr)
out['tau_thresholds'] = [None if t is None else str(t) for t in taus]
out['tau_min'] = str(min(t for t in taus if t is not None))
out['tau_min_float'] = float(min(t for t in taus if t is not None))

# Theorem 7 on the axial front: preference for the most unsupported vector, tau = 1/100, uniform reference over 12 designs
def achieve(i, tau=Q(1, 100)):
    y = nv[i]; w = [1 / (y[m] - a[m]) for m in range(2)]; s = sum(w); w = [x / s for x in w]
    g = [max(w[m] * (norm(f)[m] - a[m]) for m in range(2)) + tau * sum(w[m] * (norm(f)[m] - a[m]) for m in range(2)) for _, f in front]
    return g
target = next(i for i, s in enumerate(sup) if s is None)
g = achieve(target); gmin = min(g); mins = [k for k, x in enumerate(g) if x == gmin]
gap = min(x - gmin for x in g if x > gmin)
out['theorem7_target_vector'] = [str(vecs[target][0]), str(vecs[target][1])]
out['theorem7_minimiser_count'] = len(mins); out['theorem7_gap'] = str(gap); out['theorem7_gap_float'] = float(gap)
pstar = Q(len(mins), len(front))
for beta in (10, 50, 200):
    num = sum(mp.e ** (-beta * mp.mpf(float(x - gmin))) for x in g if x > gmin)
    tot = len(mins) + num
    out[f'theorem7_beta{beta}'] = {'nonminimal_mass': mp.nstr(num / tot, 15), 'bound13': mp.nstr((1 - pstar) / pstar * mp.e ** (-beta * mp.mpf(float(gap))), 15)}

# ---------------- penalty audit on the 27 evaluated records (empty configuration has no response)
ev = [(c, f, v) for c, f, v in recs if f is not None]
lam_star = Q(0); dv = None; Bf = Q(0)
for (c1, f1, v1), (c2, f2, v2) in product(ev, repeat=2):
    if v1 < v2:
        for m in range(2):
            r = (f1[m] - f2[m]) / (v2 - v1)
            lam_star = max(lam_star, r)
    if v1 != v2: dv = abs(v1 - v2) if dv is None else min(dv, abs(v1 - v2))
    for m in range(2): Bf = max(Bf, abs(f1[m] - f2[m]))
out['additive_lambda_star'] = str(lam_star); out['additive_lambda_star_float'] = float(lam_star)
out['prop2_sufficient_bound'] = str(Bf / dv); out['prop2_sufficient_float'] = float(Bf / dv)
out['violation_gap'] = str(dv); out['n_evaluated'] = len(ev); out['n_infeasible_evaluated'] = sum(1 for e in ev if e[2] > 0)
# does the additive relation then equal constrained dominance on the evaluated set? count disagreements at lambda = 2*lam_star
def cdom(A, B):
    _, fa, va = A; _, fb, vb = B
    if va == 0 and vb > 0: return True
    if va > 0 and vb > 0: return va < vb
    return va == 0 and vb == 0 and dom(fa, fb)
def adom(A, B, lam):
    _, fa, va = A; _, fb, vb = B
    return dom(tuple(fa[m] + lam * va for m in range(2)), tuple(fb[m] + lam * vb for m in range(2)))
def mdom(A, B, lam):
    _, fa, va = A; _, fb, vb = B
    return dom(tuple(fa[m] + lam * va * (1 + abs(fa[m])) for m in range(2)), tuple(fb[m] + lam * vb * (1 + abs(fb[m])) for m in range(2)))
for lam in (lam_star * 2, Bf / dv * 2):
    dis = sum(1 for A, B in product(ev, repeat=2) if A is not B and cdom(A, B) != adom(A, B, lam))
    out[f'additive_disagreements_lam{float(lam):.4g}'] = dis
ties = {}
for c, f, v in ev:
    if v > 0: ties[v] = ties.get(v, 0) + 1
out['tied_positive_violation_groups'] = sum(1 for k in ties.values() if k > 1)
mult = {}
for lam in (Q(0), Q(1), Q(10), Q(1000), Q(10 ** 9)):
    mult[str(lam)] = sum(1 for A, B in product(ev, repeat=2) if A is not B and cdom(A, B) != mdom(A, B, lam))
out['multiplicative_disagreements'] = mult

# ---------------- recurrence and cache hits for i.i.d. proposals
raw_p = [Q(1, 144)] * 144
slot = [(None, Q(1, 2))] + [((m, a_), Q(1, 12)) for m in MAT for a_ in (400, 600, 800)]
canp = {}
for (s1, p1), (s2, p2) in product(slot, repeat=2):
    k = canon([s1, s2]); canp[k] = canp.get(k, Q(0)) + p1 * p2
out['canonical_keys'] = len(canp); out['canonical_sum'] = str(sum(canp.values()))
out['recurrence_raw'] = str(sum(p * p for p in raw_p)); out['recurrence_canonical'] = str(sum(p * p for p in canp.values()))
def hits(ps, N): return N - sum(1 - (1 - p) ** N for p in ps)
for N in (15, 50, 300):
    out[f'hits_N{N}'] = {'raw': float(hits(raw_p, N)), 'canonical': float(hits(list(canp.values()), N))}

# ---------------- hypervolume of the exact axial front in normalised coordinates, reference (11/10, 11/10)
r = (Q(11, 10), Q(11, 10)); pts = sorted(nv)
hv = Q(0); prev2 = r[1]
for p in pts:
    hv += (r[0] - p[0]) * (prev2 - p[1]); prev2 = p[1]
out['hv_exact'] = str(hv); out['hv_float'] = float(hv)
sup_pts = sorted(nv[i] for i in range(len(nv)) if sup[i] is not None)
hv2 = Q(0); prev2 = r[1]
for p in sup_pts:
    hv2 += (r[0] - p[0]) * (prev2 - p[1]); prev2 = p[1]
out['hv_supported_only'] = str(hv2); out['hv_supported_float'] = float(hv2)
# IGD+ (15) of the supported subset against the full front (exact squared terms; sqrt numeric)
def igdp(A, Z):
    tot = mp.mpf(0)
    for z in Z:
        tot += min(mp.sqrt(sum(mp.mpf(float(max(Q(0), aa[m] - z[m]) ** 2)) for m in range(2))) for aa in A)
    return tot / len(Z)
out['igdplus_supported'] = mp.nstr(igdp(sup_pts, nv), 15)
out['hv_mc_se_bound_3d'] = mp.nstr(mp.mpf('1.331') / (2 * mp.sqrt(200000)), 8)

# ---------------- equicorrelated dominance probability (Proposition 8)
rho, t = sp.symbols('rho t', positive=True)
p2 = sp.Rational(1, 2) + sp.asin(rho) / sp.pi; p3 = sp.Rational(1, 4) + 3 * sp.asin(rho) / (2 * sp.pi)
def pM(M, r_):
    if r_ == 0: return mp.mpf(2) ** (1 - M)
    c = mp.sqrt(mp.mpf(r_) / (1 - mp.mpf(r_)))
    return 2 * mp.quad(lambda x: mp.npdf(x) * mp.ncdf(c * x) ** M, [-mp.inf, 0, mp.inf])
out['pM_check_M2'] = [mp.nstr(pM(2, r_) - mp.mpf(sp.N(p2.subs(rho, r_), 40)), 5) for r_ in ('0.3', '0.6', '0.9')]
out['pM_check_M3'] = [mp.nstr(pM(3, r_) - mp.mpf(sp.N(p3.subs(rho, r_), 40)), 5) for r_ in ('0.3', '0.6', '0.9')]
out['pM_table'] = {r_: {M: mp.nstr(pM(M, r_), 12) for M in (2, 3, 5, 8, 12, 20)} for r_ in ('0', '0.3', '0.6', '0.9')}
json.dump(out, open('sym.json', 'w'), indent=1); print(json.dumps(out, indent=1))
