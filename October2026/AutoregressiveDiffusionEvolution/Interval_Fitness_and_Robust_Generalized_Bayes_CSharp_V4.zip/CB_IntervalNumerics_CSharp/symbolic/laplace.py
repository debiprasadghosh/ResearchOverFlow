import sympy as sp, mpmath as mp, json, itertools
mp.mp.dps=40
out={}
U=sp.symbols('u')
quart=sp.expand((11-U**2)**2+U-7)          # u + v^2 - 7 with v = 11 - u^2
out['quartic']=str(quart); out['factor']=str(sp.factor(quart))
cubic=sp.factor(quart/(U-3)); out['cubic']=str(sp.expand(cubic))
roots=[sp.Integer(3)]+sorted([r for r in sp.Poly(sp.expand(cubic),U).nroots(n=40)],key=lambda r:-r)
# order as in the paper: (3,2), (-2.8,3.1), (-3.8,-3.3), (3.6,-1.8)
pts=[]
for r in roots:
    uu=sp.Float(r,40); vv=11-uu**2
    pts.append((uu,vv))
order=[0,None,None,None]
def near(p,q): return abs(float(p[0])-q[0])<0.3 and abs(float(p[1])-q[1])<0.3
targets=[(3,2),(-2.8,3.1),(-3.8,-3.3),(3.6,-1.8)]
P=[next(p for p in pts if near(p,t)) for t in targets]
out['minima_unscaled']=[[str(sp.N(p[0],20)),str(sp.N(p[1],20))] for p in P]
# shares rho_r ∝ nu(z_r)/sqrt(det H_r), z=(u,v)/4, H = 32 A^T A, det = 1024 (4uv-1)^2
w=[sp.exp(-(p[0]**2+p[1]**2)/32)/abs(4*p[0]*p[1]-1) for p in P]
S=sum(w); rho=[x/S for x in w]
out['shares']=[str(sp.N(x,15)) for x in rho]
# Second-order Laplace constants. In scaled coordinates z, J(z*+x) = 1/2 x^T H x + T(x) + Q(x) exactly.
x1,x2,w1,w2,e=sp.symbols('x1 x2 w1 w2 e')
def J(z1,z2): return (16*z1**2+4*z2-11)**2+(4*z1+16*z2**2-7)**2
res=[]
for (uu,vv),rr in zip(P,rho):
    z1,z2=uu/4,vv/4
    poly=sp.Poly(sp.expand(J(z1+x1,z2+x2)),x1,x2)
    terms={k:c for k,c in zip(poly.monoms(),poly.coeffs())}
    def part(deg): return sum(c*x1**i*x2**j for (i,j),c in terms.items() if i+j==deg)
    Hq=part(2); T=part(3); Q=part(4)
    Hm=sp.Matrix([[sp.diff(Hq,x1,2),sp.diff(Hq,x1,x2)],[sp.diff(Hq,x1,x2),sp.diff(Hq,x2,2)]])
    Sig=Hm.inv(); L=Sig.cholesky()
    sub={x1:L[0,0]*w1+L[0,1]*w2, x2:L[1,0]*w1+L[1,1]*w2}
    def E(expr):
        pl=sp.Poly(sp.expand(expr.subs(sub,simultaneous=True)),w1,w2); s=0
        for (i,j),c in zip(pl.monoms(),pl.coeffs()):
            if i%2 or j%2: continue
            s+=c*sp.factorial2(i-1)*sp.factorial2(j-1)
        return s
    g1,g2=z1,z2            # nu(z*+x)/nu(z*) = exp(-g.x - |x|^2/2)
    gx=g1*x1+g2*x2
    a2=T**2/2-Q+gx*T+gx**2/2-(x1**2+x2**2)/2      # epsilon^2 coefficient (T, Q carry their exact coefficients)
    a1=-T-gx
    Ea2=E(a2)
    N2=E(Hq*a2)+E(T*a1)+E(Q)                       # Hq = 1/2 x^T H x
    c=N2-Ea2
    res.append((rr,Ea2,c))
dbar=sum(r*d for r,d,_ in res); cbar=sum(r*c for r,_,c in res)
out['d_r']=[str(sp.N(d,12)) for _,d,_ in res]; out['c_r']=[str(sp.N(c,12)) for *_,c in res]
out['c_mixture']=str(sp.N(cbar,15))
out['mass_dev_coeffs']=[str(sp.N(r*(d-dbar),12)) for r,d,_ in res]
out['max_mass_dev_coeff']=str(sp.N(max(abs(r*(d-dbar)) for r,d,_ in res),15))
# Compare with Table 3
tab={4:(3.9660e-4,1.0036011),16:(9.7355e-5,1.0008805),64:(2.4231e-5,1.0002189),256:(6.0511e-6,1.0000547)}
out['table3_scaled']={b:[m*b,(v-1)*b] for b,(m,v) in tab.items()}
json.dump(out,open('laplace.json','w'),indent=1); print(json.dumps(out,indent=1))
