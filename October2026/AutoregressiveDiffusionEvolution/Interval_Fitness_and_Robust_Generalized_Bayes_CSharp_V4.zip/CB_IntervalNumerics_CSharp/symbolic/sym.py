import sympy as sp, json, mpmath as mp
mp.mp.dps=40
out={}
R=sp.Rational
# (5) variational identity on a 3-point space
b=sp.symbols('beta',positive=True)
mu=[R(1,5),R(3,10),R(1,2)]; J=[0,1,R(5,2)]; rho=[R(1,3),R(1,3),R(1,3)]
Z=sum(m*sp.exp(-b*j) for m,j in zip(mu,J)); pi=[m*sp.exp(-b*j)/Z for m,j in zip(mu,J)]
lhs=sum(r*j for r,j in zip(rho,J))+sum(r*sp.log(r/m) for r,m in zip(rho,mu))/b
rhs=sum(r*sp.log(r/p) for r,p in zip(rho,pi))/b-sp.log(Z)/b
out['eq5_identity']=bool(sp.simplify(sp.expand_log(lhs-rhs,force=True))==0)
# confounding example
pe=R(1,2); sA={'e':R(9,10),'h':R(1,10)}; s={'e':R(9,10),'h':R(1,5)}
A=(pe*sA['e']*s['e']+pe*sA['h']*s['h'])/(pe*sA['e']+pe*sA['h'])
Bv=(pe*(1-sA['e'])*s['e']+pe*(1-sA['h'])*s['h'])/(pe*(1-sA['e'])+pe*(1-sA['h']))
out['confounding']=[str(A),str(Bv),str(pe*s['e']+pe*s['h'])]
# (7)
u,r=sp.symbols('u r',positive=True)
crit=sp.solve(sp.diff(u**r*sp.exp(-b*u),u),u); out['eq7_argmax']=str(crit); out['eq7_max']=str(sp.simplify((u**r*sp.exp(-b*u)).subs(u,crit[0])))
# (8)
m,eps=sp.symbols('m epsilon',positive=True)
out['eq8_example']=str((m/(eps*m+1-eps)).subs({m:R(1,4),eps:R(1,5)}))
# Table 2 atomic
Za=R(1,4)+R(3,4)*sp.exp(-R(7,10)); out['tab2_Z']=str(sp.N(Za,10)); out['tab2_mean']=str(sp.N(R(3,4)*sp.exp(-R(7,10))/Za,10))
# (11), D=1
s2,mm=sp.symbols('s2 mm',positive=True); y=sp.symbols('y',real=True)
nu=sp.exp(-y**2/2)/sp.sqrt(2*sp.pi); q=sp.exp(-(y-mm)**2/(2*s2))/sp.sqrt(2*sp.pi*s2)
I=sp.integrate(sp.simplify(nu**2/q).subs({s2:R(4,5),mm:R(3,10)}),(y,-sp.oo,sp.oo))
out['eq11_D1']=str(sp.N(I,15)); out['eq11_formula']=str(sp.N(R(4,5)/sp.sqrt(2*R(4,5)-1)*sp.exp(R(9,100)/(2*R(4,5)-1)),15))
# exponent coefficient of y^2 in log(nu^2/q): -1 + 1/(2 s2) -> >=0 iff s2<=1/2
out['eq10_quadratic_coeff']=str(sp.simplify(sp.expand(sp.log(sp.simplify(nu**2/q))).coeff(y,2)))
# Theorem 2 counts
Bc,d,Zv=10,R(1,10),sp.Float('0.02719187',30)
NF=2*Bc*(1+d/3)*sp.log(80)/(d**2*Zv); out['thm2_N_float']=str(sp.N(NF,12))
out['azuma_c_B']=str(sp.N(2*Bc**2*sp.log(80)/(d**2*Zv**2),12)); out['azuma_c_2B']=str(sp.N(2*(2*Bc)**2*sp.log(80)/(d**2*Zv**2),12))
out['azuma_c_B_4tail']=str(sp.N(2*Bc**2*sp.log(80)/(d**2*Zv**2),12))
# Bernoulli example
out['bernoulli']=[str(sp.N(sp.exp(-R(1,2)),8)),str(sp.N((1+sp.exp(-1))/2,8))]
# (14) Tweedie for Gaussian target N(0,v)
a,v,qq=sp.symbols('a v q',positive=True)
p=sp.exp(-qq**2/(2*(a*v+1-a))); mden=sp.sqrt(a)*v*qq/(a*v+1-a)
out['eq14_tweedie']=bool(sp.simplify(sp.diff(sp.log(p),qq)-(sp.sqrt(a)*mden-qq)/(1-a))==0)
# Singular audit: mu=N(0,1), J=y^2, beta=1/2, P=0.1 mu + 0.9 delta_0.5, e=1/2 for |y|<1 else 1
Pin=sp.erf(1/sp.sqrt(2))      # P(|Y|<1)
Ee=R(1,2)*Pin+(1-Pin)
out['audit_expected_included']=str(sp.N(200000*(R(9,10)*R(1,2)+R(1,10)*Ee),10))
out['audit_expected_positive']=str(sp.N(200000*R(1,10)*Ee,10))
# asymptotic variance of the ratio: E[(W(J-1/2))^2]/Z^2 with W = delta*10*exp(-J/2)/e on continuous branch
t=sp.symbols('t',real=True); phi=sp.exp(-t**2/2)/sp.sqrt(2*sp.pi)
g=100*sp.exp(-t**2)*(t**2-R(1,2))**2*phi
inner=sp.integrate(g/R(1,2),(t,-1,1))+2*sp.integrate(g,(t,1,sp.oo))   # E_mu[100 e^{-y^2}(y^2-1/2)^2/e]
EW2=R(1,10)*inner; Zs=1/sp.sqrt(2)
av=sp.simplify(EW2/Zs**2); out['audit_asym_var']=str(sp.N(av,12)); out['audit_sd_2e5']=str(sp.N(sp.sqrt(av/200000),8))
json.dump(out,open('sym.json','w'),indent=1); print(json.dumps(out,indent=1))
