Causal Bayes V4: validated interval numerics (Sections 9.4-9.7, Appendix C)

cs/        .NET 8 console project. Build: dotnet build -c Release; run: dotnet bin/Release/net8.0/Cb.dll (about 90 s).
           Writes results.json and singular_replicates.json.
symbolic/  sym.py: SymPy checks of (5), (7), (8), (10), (11), (14), the confounding example, Theorem 2 counts,
           the Bernoulli example and the singular-audit expectations.
           laplace.py: exact Himmelblau minimizers, Laplace shares and the second-order constants of Proposition 2.
figures/   figs.py regenerates Figures 2 and 3 (paths assume the original build tree: ../cs and ../num).
