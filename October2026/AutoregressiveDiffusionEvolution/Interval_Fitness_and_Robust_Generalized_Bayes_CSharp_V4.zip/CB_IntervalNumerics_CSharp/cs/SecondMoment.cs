namespace CbIntervals;

/// <summary>Validated one-dimensional integral (10): E_q W^2 = int nu^2/q exp(-2 beta J) with nu = N(0,1),
/// q = N(m, s2) and J(y) = y^4. Interior: midpoint rule with an interval enclosure of g''.
/// Tails: E = log g is concave beyond L, so int_L^inf e^E <= e^{E(L)} / (-E'(L)).</summary>
public static class SecondMoment
{
    public sealed record Row(double S2, double Beta, double M, double Lo, double Hi, double L, int Cells);

    static (Iv E, Iv E1, Iv E2) Expo(Iv y, double s2, double m, double beta)
    {
        Iv d = y - m;
        Iv E = -y.Sqr() + d.Sqr() / (2 * s2) - 2 * beta * y.Sqr().Sqr();
        Iv E1 = -2.0 * y + d / s2 - 8 * beta * (y * y.Sqr());
        Iv E2 = Iv.Point(-2 + 1 / s2) - 24 * beta * y.Sqr();
        return (E, E1, E2);
    }

    public static Row Run(double s2, double beta, double m = 0.3, double L = 14, int cells = 1_000_000)
    {
        Iv c = Iv.Point(s2).Sqrt() / (2.0 * new Iv(Math.BitDecrement(Math.PI), Math.BitIncrement(Math.PI))).Sqrt();
        double h = 2 * L / cells; Iv sum = Iv.Point(0);
        for (int k = 0; k < cells; k++)
        {
            double a = -L + k * h, b = a + h; Iv X = new(a, b), mid = Iv.Point(0.5 * (a + b));
            var (Em, _, _) = Expo(mid, s2, m, beta); var (EX, E1, E2) = Expo(X, s2, m, beta);
            Iv g2 = (E2 + E1.Sqr()) * EX.Exp();
            sum += Iv.Point(h) * Em.Exp() + Iv.Point(h * h * h / 24) * g2;
        }
        foreach (double edge in new[] { L, -L })
        {
            var (E, E1, _) = Expo(Iv.Point(edge), s2, m, beta);
            // concavity beyond the edge: -2 + 1/s2 - 24 beta y^2 < 0 for |y| >= L
            if (-2 + 1 / s2 - 24 * beta * L * L >= 0) throw new InvalidOperationException("Tail not concave");
            Iv slope = edge > 0 ? -E1 : E1;
            if (slope.Lo <= 0) throw new InvalidOperationException("Tail not decreasing");
            sum += new Iv(0, (E.Exp() / slope).Hi);
        }
        Iv res = c * sum;
        return new(s2, beta, m, res.Lo, res.Hi, L, cells);
    }
}
