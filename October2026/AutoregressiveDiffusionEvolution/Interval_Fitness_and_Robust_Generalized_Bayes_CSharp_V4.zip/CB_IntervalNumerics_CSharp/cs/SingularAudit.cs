namespace CbIntervals;

/// <summary>Singular continuous-reference check of Section 9.1: mu = N(0,1), J = y^2, beta = 0.5,
/// P = 0.1 mu + 0.9 delta_0.5, inclusion 0.5 for |y| < 1 and 1 otherwise. The atom is target-null.</summary>
public static class SingularAudit
{
    public sealed record Result(int Attempts, int Included, int Positive, double Estimate, double MaxW, bool BoundHolds, int Undecided, double MinAbsYUndecided);

    public static Result Run(int seed, int n = 200_000, double beta = 0.5, double eps = 0.1, double atom = 0.5)
    {
        var rnd = new Random(seed); double N() => Math.Sqrt(-2 * Math.Log(1 - rnd.NextDouble())) * Math.Cos(2 * Math.PI * rnd.NextDouble());
        double B = 1 / (eps * 0.5), sw = 0, swj = 0, maxW = 0, minY = double.PositiveInfinity; int inc = 0, pos = 0, und = 0; bool ok = true;
        Iv logR = -(Iv.Point(eps).Log());
        for (int i = 0; i < n; i++)
        {
            double y = rnd.NextDouble() < eps ? N() : atom;
            double e = Math.Abs(y) < 1 ? 0.5 : 1.0;
            if (rnd.NextDouble() >= e) continue;
            inc++;
            if (y == atom) continue;                                       // derivative d mu / dP is zero at the atom
            pos++;
            Iv W = (logR - Iv.Point(beta) * Iv.Point(y * y) - Iv.Point(e).Log()).Exp();
            maxW = Math.Max(maxW, W.Hi);
            // W <= B is attained at y = 0, so an enclosure can straddle B there: count those as undecided, not as violations.
            if (W.Lo > B) ok = false; else if (W.Hi > B) { und++; minY = Math.Min(minY, Math.Abs(y)); }
            sw += W.Mid; swj += W.Mid * y * y;
        }
        return new(n, inc, pos, swj / sw, maxW, ok, und, und > 0 ? minY : 0);
    }
}
