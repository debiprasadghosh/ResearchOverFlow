namespace CbIntervals;

/// <summary>Validated quadrature for the Himmelblau Gibbs target pi_beta proportional to exp(-beta J) nu,
/// with J(z) = h(4z) and nu = N(0, I2). Each box integral is enclosed by the midpoint value plus an
/// interval Hessian remainder: int_Q g = A g(c) + (1/2) int s^T H(xi_s) s ds.</summary>
public static class Gibbs
{
    public sealed record Derivs(Iv F, Iv F1, Iv F2, Iv F11, Iv F22, Iv F12, Iv N, Iv N11, Iv N22, Iv N12, Iv J);
    public sealed record Result(double Beta, Iv Z, Iv N, Iv MeanLoss, long Boxes, double Half);
    static readonly Iv TwoPi = 2.0 * new Iv(Math.BitDecrement(Math.PI), Math.BitIncrement(Math.PI));

    /// <summary>Value, gradient and Hessian enclosures of f = exp(-beta J) nu and n = J f on a box.</summary>
    public static Derivs Eval(Iv z1, Iv z2, double beta)
    {
        Iv u = 4.0 * z1, v = 4.0 * z2;
        Iv P = u.Sqr() + v - 11.0, Q = u + v.Sqr() - 7.0;
        Iv J = P.Sqr() + Q.Sqr();
        Iv Ju = 4.0 * (u * P) + 2.0 * Q, Jv = 2.0 * P + 4.0 * (v * Q);
        Iv Juu = 4.0 * P + 8.0 * u.Sqr() + 2.0, Jvv = 4.0 * Q + 8.0 * v.Sqr() + 2.0, Juv = 4.0 * u + 4.0 * v;
        Iv J1 = 4.0 * Ju, J2 = 4.0 * Jv, J11 = 16.0 * Juu, J22 = 16.0 * Jvv, J12 = 16.0 * Juv;
        Iv G = -(beta * J) - 0.5 * (z1.Sqr() + z2.Sqr());
        Iv f = G.Exp() / TwoPi;
        Iv G1 = -(beta * J1) - z1, G2 = -(beta * J2) - z2;
        Iv G11 = -(beta * J11) - 1.0, G22 = -(beta * J22) - 1.0, G12 = -(beta * J12);
        Iv f1 = f * G1, f2 = f * G2, f11 = f * (G11 + G1.Sqr()), f22 = f * (G22 + G2.Sqr()), f12 = f * (G12 + G1 * G2);
        Iv n = J * f;
        Iv n11 = J11 * f + 2.0 * (J1 * f1) + J * f11, n22 = J22 * f + 2.0 * (J2 * f2) + J * f22, n12 = J12 * f + J1 * f2 + J2 * f1 + J * f12;
        return new(f, f1, f2, f11, f22, f12, n, n11, n22, n12, J);
    }

    sealed record Box(double X, double Y, double H, Iv Zi, Iv Ni);

    static Box Integrate(double x, double y, double h, double beta)
    {
        var whole = Eval(new Iv(x - h / 2, x + h / 2), new Iv(y - h / 2, y + h / 2), beta);
        var mid = Eval(Iv.Point(x), Iv.Point(y), beta);
        Iv area = Iv.Point(h) * Iv.Point(h);
        Iv m2 = area * Iv.Point(h * h) / Iv.Point(12.0);          // int s_i^2 ds = A h^2 / 12
        Iv mx = area * Iv.Point(h * h) / Iv.Point(16.0);          // int |s1 s2| ds = A h^2 / 16
        Iv pm = new(-1, 1);
        Iv zi = area * mid.F + 0.5 * (whole.F11 * m2 + whole.F22 * m2) + (whole.F12 * pm) * mx;
        Iv ni = area * mid.N + 0.5 * (whole.N11 * m2 + whole.N22 * m2) + (whole.N12 * pm) * mx;
        // A direct value enclosure is also valid; keep the tighter of the two.
        Iv zd = area * whole.F, nd = area * whole.N;
        return new(x, y, h, new(Math.Max(zi.Lo, zd.Lo), Math.Min(zi.Hi, zd.Hi)), new(Math.Max(ni.Lo, nd.Lo), Math.Min(ni.Hi, nd.Hi)));
    }

    public static (Result result, IReadOnlyList<(double x, double y, double h, Iv J, Iv Zi)> boxes) Run(double beta, double relTol, double L = 8.0, int start = 64, long maxBoxes = 4_000_000)
    {
        double h0 = 2 * L / start;
        var pq = new PriorityQueue<Box, double>();
        Iv Z = Iv.Point(0), N = Iv.Point(0); long count = 0;
        for (int i = 0; i < start; i++) for (int j = 0; j < start; j++)
        {
            var b = Integrate(-L + (i + 0.5) * h0, -L + (j + 0.5) * h0, h0, beta);
            pq.Enqueue(b, -(b.Zi.Width + b.Ni.Width / 10)); count++;
        }
        // Tail outside the square: nu mass at most phi(L)/2 by the Mills ratio; J exp(-beta J) <= 1/(e beta).
        double tail = Math.BitIncrement(Math.Exp(-L * L / 2) / Math.Sqrt(2 * Math.PI) / 2 * 1.000001);
        Iv zTail = new(0, tail), nTail = new(0, tail / (Math.E * beta) * 1.000001);
        double SumW() { double s = 0; foreach (var (b, _) in pq.UnorderedItems) s += b.Zi.Width + b.Ni.Width / 10; return s; }
        double target = relTol, check = 0;
        while (count < maxBoxes)
        {
            if (count >= check)
            {
                var (zs, ns) = Sum(pq); var mean = (ns + nTail) / (zs + zTail);
                if (mean.Width <= relTol * mean.Mid) break;
                check = count * 1.25 + 1000;
            }
            var bx = pq.Dequeue(); double q = bx.H / 4, hh = bx.H / 2;
            foreach (var (dx, dy) in new[] { (-q, -q), (-q, q), (q, -q), (q, q) })
            { var c = Integrate(bx.X + dx, bx.Y + dy, hh, beta); pq.Enqueue(c, -(c.Zi.Width + c.Ni.Width / 10)); }
            count += 3;
        }
        var (zsum, nsum) = Sum(pq);
        Iv Zt = zsum + zTail, Nt = nsum + nTail;
        var boxes = pq.UnorderedItems.Select(t => (t.Element.X, t.Element.Y, t.Element.H,
            Eval(new Iv(t.Element.X - t.Element.H / 2, t.Element.X + t.Element.H / 2), new Iv(t.Element.Y - t.Element.H / 2, t.Element.Y + t.Element.H / 2), beta).J, t.Element.Zi)).ToList();
        return (new Result(beta, Zt, Nt, Nt / Zt, count, h0), boxes);
    }

    static (Iv, Iv) Sum(PriorityQueue<Box, double> pq)
    {
        Iv z = Iv.Point(0), n = Iv.Point(0);
        foreach (var (b, _) in pq.UnorderedItems) { z += b.Zi; n += b.Ni; }
        return (z, n);
    }

    /// <summary>Certified upper bound on pi_beta(J >= delta): boxes not certified below delta, plus the tail.</summary>
    public static double UpperTailProbability(IReadOnlyList<(double x, double y, double h, Iv J, Iv Zi)> boxes, Result r, double delta, double L = 8.0)
    {
        double tail = Math.BitIncrement(Math.Exp(-L * L / 2) / Math.Sqrt(2 * Math.PI) / 2 * 1.000001);
        Iv s = new(0, tail);
        foreach (var (_, _, _, J, Zi) in boxes) if (J.Hi >= delta) s += new Iv(0, Zi.Hi);
        return (s / r.Z).Hi;
    }

    /// <summary>Certified lower bound on nu(J <= c): sum of nu-mass lower bounds over boxes with J upper bound <= c.</summary>
    public static double NuMassBelow(IReadOnlyList<(double x, double y, double h, Iv J, Iv Zi)> boxes, double c)
    {
        Iv s = Iv.Point(0);
        foreach (var (x, y, h, J, _) in boxes)
        {
            if (J.Hi > c) continue;
            Iv z1 = new(x - h / 2, x + h / 2), z2 = new(y - h / 2, y + h / 2);
            Iv phi = (-0.5 * (z1.Sqr() + z2.Sqr())).Exp() / TwoPi;
            s += Iv.Point(h) * Iv.Point(h) * new Iv(phi.Lo, phi.Lo);
        }
        return s.Lo;
    }
}

public static class Quadrants
{
    /// <summary>Certified target mass of each open quadrant (+,+), (-,+), (-,-), (+,-) in scaled coordinates.
    /// The initial grid has a line at 0, so every square lies in one closed quadrant; the axes have measure zero.
    /// The unknown tail outside the square is added to every quadrant as [0, tail].</summary>
    public static Iv[] Masses(IReadOnlyList<(double x, double y, double h, Iv J, Iv Zi)> boxes, Gibbs.Result r, double L = 8.0)
    {
        double tail = Math.BitIncrement(Math.Exp(-L * L / 2) / Math.Sqrt(2 * Math.PI) / 2 * 1.000001);
        var s = Enumerable.Repeat(new Iv(0, tail), 4).ToArray();
        foreach (var (x, y, _, _, Zi) in boxes)
        {
            int k = x > 0 ? (y > 0 ? 0 : 3) : (y > 0 ? 1 : 2);
            s[k] += Zi;
        }
        return s.Select(m => new Iv(Math.Max(0, (m / r.Z).Lo), Math.Min(1, (m / r.Z).Hi))).ToArray();
    }
}
