using System.Diagnostics;
using System.Text.Json;
using CbIntervals;

var results = new Dictionary<string, object>();
var sw = Stopwatch.StartNew();

// 1. Certified minimizers and Laplace shares
var sh = Minima.Run();
results["minima"] = sh.Roots; results["shares"] = sh.Rho.Select(r => new { lo = r.Lo, hi = r.Hi }).ToList();
Console.WriteLine(JsonSerializer.Serialize(results["minima"])); Console.WriteLine(JsonSerializer.Serialize(results["shares"]));

// 2. Certified quadrature: beta = 0.1 for Theorem 2 and the 9.2 reference, beta = 4 and 16 for Table 3
var gibbs = new List<object>();
foreach (double beta in new[] { 0.1, 4.0, 16.0 })
{
    var t = Stopwatch.StartNew(); var (r, boxes) = Gibbs.Run(beta, 1e-9, maxBoxes: beta < 1 ? 4_000_000 : 6_000_000);
    var q = Quadrants.Masses(boxes, r);
    var dev = q.Select((m, k) => new { lo = m.Lo - sh.Rho[k].Hi, hi = m.Hi - sh.Rho[k].Lo }).ToList();
    Iv scaled = Iv.Point(beta) * r.MeanLoss;
    gibbs.Add(new { beta, Zlo = r.Z.Lo, Zhi = r.Z.Hi, meanLo = r.MeanLoss.Lo, meanHi = r.MeanLoss.Hi, scaledLo = scaled.Lo, scaledHi = scaled.Hi,
        quadrants = q.Select(m => new { lo = m.Lo, hi = m.Hi }).ToList(), deviation = dev, r.Boxes, seconds = t.Elapsed.TotalSeconds });
    Console.WriteLine($"beta={beta} Z=[{r.Z.Lo:R},{r.Z.Hi:R}] betaE=[{scaled.Lo:R},{scaled.Hi:R}] {t.Elapsed.TotalSeconds:F1}s");
    Console.WriteLine(JsonSerializer.Serialize(dev));
    if (beta == 0.1)
    {
        // Theorem 2 with the certified lower bound z0 <= Z: smallest N with 4 exp(-N d^2 z0 / (2B(1 + d/3))) <= 0.05
        double B = 10, d = 0.1;
        Iv need = 2.0 * B * (1.0 + Iv.Point(d) / 3.0) * Iv.Point(80).Log() / (Iv.Point(d) * Iv.Point(d) * Iv.Point(r.Z.Lo));
        results["theorem2"] = new { z0 = r.Z.Lo, nLower = need.Lo, nUpper = need.Hi, certifiedN = (long)Math.Ceiling(need.Hi) };
        Console.WriteLine(JsonSerializer.Serialize(results["theorem2"]));
    }
}
results["gibbs"] = gibbs;

// 3. Certified second moments (10) with quartic loss
var sm = new List<SecondMoment.Row> { SecondMoment.Run(0.8, 0.0) };
foreach (double s2 in new[] { 0.3, 0.5, 0.8 }) foreach (double beta in new[] { 0.25, 0.5, 1.0 }) sm.Add(SecondMoment.Run(s2, beta));
results["secondMoment"] = sm; foreach (var x in sm) Console.WriteLine(x);

// 4. Singular audit, seed 20261029 and 200 seeds
results["singular"] = SingularAudit.Run(20261029);
var reps = new SingularAudit.Result[200];
Parallel.For(0, 200, k => reps[k] = SingularAudit.Run(k + 1));
double M(Func<SingularAudit.Result, double> f) => reps.Average(f);
double Sd(Func<SingularAudit.Result, double> f) { double m = M(f); return Math.Sqrt(reps.Sum(r => (f(r) - m) * (f(r) - m)) / (reps.Length - 1)); }
results["singularReplication"] = new { seeds = 200, estMean = M(r => r.Estimate), estSd = Sd(r => r.Estimate), incMean = M(r => r.Included), incSd = Sd(r => r.Included),
    posMean = M(r => r.Positive), posSd = Sd(r => r.Positive), maxW = reps.Max(r => r.MaxW), noViolation = reps.All(r => r.BoundHolds), undecided = reps.Sum(r => r.Undecided), maxAbsYUndecided = reps.Where(r => r.Undecided > 0).Select(r => r.MinAbsYUndecided).DefaultIfEmpty(0).Max() };
Console.WriteLine(JsonSerializer.Serialize(results["singular"])); Console.WriteLine(JsonSerializer.Serialize(results["singularReplication"]));
File.WriteAllText("singular_replicates.json", JsonSerializer.Serialize(reps));
results["runtime"] = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription;
results["seconds"] = sw.Elapsed.TotalSeconds;
File.WriteAllText("results.json", JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine("written");
