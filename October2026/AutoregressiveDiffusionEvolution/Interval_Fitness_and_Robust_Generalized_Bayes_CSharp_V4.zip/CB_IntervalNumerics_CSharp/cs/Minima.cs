namespace CbIntervals;

/// <summary>Interval Newton certificates for the four global minimizers of the scaled Himmelblau loss (23).
/// In unscaled coordinates u = 4 z1, v = 4 z2, J = 0 exactly when v = 11 - u^2 and u is a root of
/// (u - 3)(u^3 + 3u^2 - 13u - 38). A quartic has at most four real roots, so four certified roots are all minimizers.</summary>
public static class Minima
{
    public sealed record Root(double ULo, double UHi, double VLo, double VHi, double JHi, double DetALo, double DetAHi, int Steps);
    public sealed record Shares(IReadOnlyList<Root> Roots, IReadOnlyList<Iv> Rho);

    static Iv F(Iv u) => ((u + 3.0) * u - 13.0) * u - 38.0;               // Horner form of the cubic
    static Iv dF(Iv u) => (3.0 * u + 6.0) * u - 13.0;

    /// <summary>Interval Newton with the inclusion test N(X) inside int(X), which proves a unique root in X.</summary>
    public static (Iv box, int steps) Certify(double guess, double radius = 1e-3)
    {
        Iv X = new(guess - radius, guess + radius); int steps = 0; bool proved = false;
        for (; steps < 60; steps++)
        {
            double m = X.Mid; Iv N = Iv.Point(m) - F(Iv.Point(m)) / dF(X);
            if (N.Inside(X)) proved = true;
            Iv Y = new(Math.Max(N.Lo, X.Lo), Math.Min(N.Hi, X.Hi));
            if (Y.Lo > Y.Hi) throw new InvalidOperationException("No root in box");
            if (proved && Y.Width >= X.Width) { X = Y; break; }
            X = Y;
        }
        if (!proved) throw new InvalidOperationException("Inclusion not proved");
        return (X, steps);
    }

    static Iv Jun(Iv u, Iv v) => (u.Sqr() + v - 11.0).Sqr() + (u + v.Sqr() - 7.0).Sqr();

    public static Shares Run()
    {
        var roots = new List<(Iv u, int steps)> { (Iv.Point(3), 0) };
        foreach (double g in new[] { -2.805118, -3.779310, 3.584428 }) roots.Add(Certify(g));
        var outRoots = new List<Root>(); var w = new List<Iv>();
        foreach (var (u, steps) in roots)
        {
            Iv v = 11.0 - u.Sqr();
            Iv detA = 4.0 * (u * v) - 1.0;                                 // det of rows (2u,1),(1,2v)
            if (detA.Contains(0)) throw new InvalidOperationException("Hessian not certified definite");
            outRoots.Add(new(u.Lo, u.Hi, v.Lo, v.Hi, Jun(u, v).Hi, detA.Lo, detA.Hi, steps));
            // rho_r proportional to nu(z_r)/sqrt(det H_r) with z = (u, v)/4 and det H_r = 1024 detA^2
            w.Add((-(u.Sqr() + v.Sqr()) / 32.0).Exp() / detA.Abs());
        }
        Iv S = w.Aggregate(Iv.Point(0), (a, b) => a + b);
        return new(outRoots, w.Select(x => x / S).ToList());
    }
}
