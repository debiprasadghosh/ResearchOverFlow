import json, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans'})
BLUE='#2a5b84'; BROWN='#a0602a'; GREY='#c3c9ce'; DARK='#555555'
R=json.load(open('../cs/results.json')); L=json.load(open('../num/laplace.json')); S=json.load(open('../num/sym.json'))
coef=[float(x) for x in L['mass_dev_coeffs']]; cbar=float(L['c_mixture'])
tab={4:(3.9660e-4,1.0036011),16:(9.7355e-5,1.0008805),64:(2.4231e-5,1.0002189),256:(6.0511e-6,1.0000547)}
cols=[BLUE,BROWN,DARK,'#7a9cc0']; names=['(3, 2)','(−2.81, 3.13)','(−3.78, −3.28)','(3.58, −1.85)']
fig,ax=plt.subplots(1,2,figsize=(6.7,2.75))
bb=np.logspace(np.log10(3),np.log10(300),100)
for k in range(4):
    ax[0].plot(bb,np.abs(coef[k])/bb,color=cols[k],lw=1,label=f'Minimum {names[k]}')
    for g in R['gibbs']:
        if g['beta']<1: continue
        d=g['deviation'][k]; lo,hi=abs(d['lo']),abs(d['hi'])
        ax[0].plot([g['beta']]*2,[min(lo,hi),max(lo,hi)],color=cols[k],lw=4,solid_capstyle='butt')
ax[0].plot(list(tab),[v[0] for v in tab.values()],'x',color='black',ms=5,label='Table 3, largest deviation')
ax[0].set_xscale('log'); ax[0].set_yscale('log'); ax[0].set_xlabel(r'Inverse temperature $\beta$'); ax[0].set_ylabel('|Target mass − Laplace share|')
ax[0].legend(fontsize=6.3,frameon=False,loc='lower left')
for g in R['gibbs']:
    if g['beta']<1: continue
    b=g['beta']; ax[1].plot([b]*2,[(g['scaledLo']-1)*b,(g['scaledHi']-1)*b],color=BLUE,lw=5,solid_capstyle='butt')
ax[1].plot([],[],color=BLUE,lw=5,label='Certified enclosure')
ax[1].plot(list(tab),[(v[1]-1)*b for b,v in tab.items()],'x',color='black',ms=5,label='Table 3')
ax[1].axhline(cbar,color=BROWN,lw=1,ls='--',label=f'Second-order constant {cbar:.6f}')
ax[1].set_xscale('log'); ax[1].set_ylim(0.0135,0.0150); ax[1].set_xlabel(r'Inverse temperature $\beta$'); ax[1].set_ylabel(r'$\beta\,(\beta\,\pi_\beta J - 1)$')
ax[1].legend(fontsize=7,frameon=False,loc='upper right')
plt.tight_layout(); plt.savefig('fig2.png',dpi=300); plt.close()
# Figure 3
fig,ax=plt.subplots(1,2,figsize=(6.7,2.6))
sm=R['secondMoment']
for k,s2 in enumerate([0.3,0.5,0.8]):
    rows=[r for r in sm if r['S2']==s2 and r['Beta']>0]
    ax[0].plot([r['Beta'] for r in rows],[(r['Lo']+r['Hi'])/2 for r in rows],'o-',color=[BROWN,DARK,BLUE][k],ms=4,label=f'$s^2={s2}$')
r0=[r for r in sm if r['Beta']==0][0]; ax[0].plot([0],[(r0['Lo']+r0['Hi'])/2],'s',color=BLUE,ms=5)
ax[0].annotate('β = 0: (11) for s² = 0.8;\ninfinite for s² ≤ 0.5',(0.01,1.19),(0.45,0.92),fontsize=7,arrowprops=dict(arrowstyle='-',lw=0.5))
ax[0].set_xlabel(r'Inverse temperature $\beta$ with $J=y^4$'); ax[0].set_ylabel(r'Certified $\mathbb{E}_q W^2$'); ax[0].legend(fontsize=7,frameon=False,loc='lower left')
reps=json.load(open('../cs/singular_replicates.json')); est=np.array([r['Estimate'] for r in reps])
ax[1].hist(est,bins=22,color=GREY,density=True,label='200 C# seeds')
sd=float(S['audit_sd_2e5']); xs=np.linspace(0.485,0.515,200); ax[1].plot(xs,np.exp(-(xs-0.5)**2/(2*sd**2))/(sd*np.sqrt(2*np.pi)),color=BLUE,lw=1.2,label=f'Exact asymptotic SD {sd:.5f}')
ax[1].axvline(0.5,color='black',ls='--',lw=1); ax[1].axvline(0.498095,color=BROWN,lw=1.2,label='Python seed, Section 9.1')
ax[1].set_xlabel('Estimated target mean loss'); ax[1].set_ylabel('Density'); ax[1].legend(fontsize=6.5,frameon=True,framealpha=1,edgecolor='none',loc='upper left')
ax[1].set_ylim(0,ax[1].get_ylim()[1]*1.35)
plt.tight_layout(); plt.savefig('fig3.png',dpi=300); plt.close()
