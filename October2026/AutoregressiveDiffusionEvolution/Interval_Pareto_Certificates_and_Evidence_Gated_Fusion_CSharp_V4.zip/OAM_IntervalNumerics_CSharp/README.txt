Objectives as Modalities V4: validated interval numerics (Sections 9.4-9.6, Appendix C)

cs/        .NET 8 console project. Build: dotnet build -c Release; run: dotnet bin/Release/net8.0/Oam.dll (about 25 s).
           Writes results.json and reuse_replicates.json.
symbolic/  sym.py: SymPy checks of the scale identity, Chebyshev and weighted-sum minimizers, the mixture gate by
           symbolic integration, ranks, (12), pruned IGD, (14), the cosine schedule, payload, the completed square of
           Section 9.5 and Proposition 4. The mpmath reference curve is appended to sym.json.
figures/   figs.py regenerates Figures 3 and 4 (paths assume the original build tree: ../cs).
