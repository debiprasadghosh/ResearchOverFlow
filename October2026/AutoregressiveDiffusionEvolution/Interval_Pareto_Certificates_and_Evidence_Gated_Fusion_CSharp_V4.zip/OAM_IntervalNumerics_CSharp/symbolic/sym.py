import sympy as sp, json
R=sp.Rational; out={}
u=sp.symbols('u',nonnegative=True)
# (5): nominal (1/2,1/2), scales (1, 41/5)
lam=[R(1,2),R(1,2)]; s=[1,R(41,5)]
C=sum(l/si for l,si in zip(lam,s)); lp=[l/(si*C) for l,si in zip(lam,s)]
out['eq5']=[str(lp[0]),str(lp[1]),str(C),[float(lp[0]),float(lp[1]),float(C)]]
# Chebyshev minimizers on (u,1-u^2) with z=0
def cheb_root(l1,l2,s2=1):
    r=sp.solve(sp.Eq(l1*u,l2*(1-u**2)/s2),u); return [x for x in r if x.is_nonnegative][0]
out['cheb_scales_11']=str(cheb_root(R(1,2),R(1,2))); out['cheb_scales_11_f']=float(cheb_root(R(1,2),R(1,2)))
r82=cheb_root(R(1,2),R(1,2),R(41,5)); out['cheb_scales_1_8.2']=str(sp.nsimplify(r82)); out['cheb_scales_1_8.2_f']=float(r82)
rows={}
for us in [R(1,4),R(1,2),R(3,4)]:
    v=[us,1-us**2]; w=[1/x for x in v]; tot=sum(w); l=[x/tot for x in w]
    rows[str(us)]=dict(lam=[str(x) for x in l],root=str(cheb_root(l[0],l[1])),ws_left=str(l[1]),ws_right=str(l[0]))
out['cheb_reach']=rows
# mixture gate (Table 2): components N(-1,0.05), N(1,0.5), a=1/2, q=2/5
a,q=R(1,2),R(2,5); comps=[(-1,R(1,20)),(1,R(1,2))]
def ev(c,v): var=a*v+1-a; return sp.exp(-(q-sp.sqrt(a)*c)**2/(2*var))/sp.sqrt(2*sp.pi*var)
def mn(c,v): return c+sp.sqrt(a)*v*(q-sp.sqrt(a)*c)/(a*v+1-a)
L=[ev(*c) for c in comps]; M=[mn(*c) for c in comps]
g=[x/sum(L) for x in L]
out['gate_mean']=str(sp.N(sum(gi*mi for gi,mi in zip(g,M)),20)); out['fixed_mean']=str(sp.N(sum(M)/2,20))
out['gates']=[str(sp.N(x,15)) for x in g]
# direct symbolic integration of mixture numerator/denominator on the real line
y=sp.symbols('y',real=True)
def dens(c,v): return sp.exp(-(y-c)**2/(2*v))/sp.sqrt(2*sp.pi*v)
K=sp.exp(-(q-sp.sqrt(a)*y)**2/(2*(1-a)))/sp.sqrt(2*sp.pi*(1-a))
mix=(dens(*comps[0])+dens(*comps[1]))/2
num=sp.integrate(sp.expand(y*K*mix),(y,-sp.oo,sp.oo)); den=sp.integrate(sp.expand(K*mix),(y,-sp.oo,sp.oo))
out['gate_mean_integral']=str(sp.N(num/den,20))
# ranks of the six vectors and rectangle identity
V=[(0,0),(0,1),(1,0),(1,1),(R(1,2),R(1,2)),(R(7,10),R(7,10))]
def dom(p,r): return all(x<=y for x,y in zip(p,r)) and any(x<y for x,y in zip(p,r))
rk=[]; rest=list(range(6)); lev=0; rk=[None]*6
while rest:
    f=[i for i in rest if not any(dom(V[j],V[i]) for j in rest)]
    for i in f: rk[i]=lev
    rest=[i for i in rest if i not in f]; lev+=1
out['ranks']=rk; out['rectangle']=[rk[0]+rk[3],rk[1]+rk[2]]
# reference-rank chain definition (Sec 5.2) uses chains; (12) finite example
b=10; m=[R(1,5),R(3,10),R(1,2)]; outside=(m[1]*sp.exp(-b)+m[2]*sp.exp(-2*b))/(m[0]+m[1]*sp.exp(-b)+m[2]*sp.exp(-2*b))
out['eq12']=[str(sp.N(outside,6)),str(sp.N(sp.exp(-b)/m[0],6))]
out['igd_pruned']=str(sp.N(sp.sqrt(1+R(1,20)**2),10))
# (14)
out['eq14']=[50+230*5,50+71*16,50+1150*1]
t,T=sp.symbols('t T',positive=True)
at=(1+sp.cos(sp.pi*t/T))/2
out['cosine_noise_identity']=bool(sp.simplify(1-at-sp.sin(sp.pi*t/(2*T))**2)==0)
out['payload']=[8*(10+2+2)+1,(8*(10+2+2)+1)*1200,(8*(1000+5+2)+1)*10**5]
# Section 9.2 reference: target ∝ exp(-2 S_lambda) on [-2,2], S = l(x+1)^2+(1-l)(x-1)^2; mean of G1=(x+1)^2
x=sp.symbols('x',real=True); l=sp.symbols('l',nonnegative=True)
S=l*(x+1)**2+(1-l)*(x-1)**2
out['S_completed_square']=str(sp.simplify(sp.expand(S-((x+2*l-1)**2+4*l*(1-l)))))   # 0 means S=(x+2l-1)^2+4l(1-l)
ref={}
for k in range(11):
    lv=R(k,10); f=sp.exp(-2*(x+2*lv-1)**2)
    Zl=sp.integrate(f,(x,-2,2)); Nl=sp.integrate((x+1)**2*f,(x,-2,2))
    ref[str(float(lv))]=str(sp.N(Nl/Zl,20))
out['reuse_reference']=ref
# Sharp total-variation bound for a perturbed tilt: maximize p k/(pk+1-p) - p over p
p,k=sp.symbols('p k',positive=True)
fp=p*k/(p*k+1-p)-p
pstar=1/(1+sp.sqrt(k))
out['tv_argmax_derivative_zero']=bool(sp.simplify(sp.diff(fp,p).subs(p,pstar))==0)
out['tv_second_derivative']=str(sp.factor(sp.diff(fp,p,2)))
fmax=sp.simplify(fp.subs(p,pstar))
c=sp.symbols('c',positive=True)
out['tv_max']=str(sp.simplify(fmax.subs(k,sp.exp(2*c)).rewrite(sp.tanh)))
out['tv_is_tanh_c']=bool(sp.simplify((fmax.subs(k,sp.exp(2*c))-sp.tanh(c/2)).rewrite(sp.exp))==0)
cases={}
for bh in [R(1,100),R(1,10),R(1,2),1,2]:
    cases[str(bh)]=[float(sp.tanh(bh/2)),float(sp.Min(1,(sp.exp(2*bh)-1)/2))]
out['tv_compare']=cases
json.dump(out,open('sym.json','w'),indent=1); print(json.dumps(out,indent=1))
