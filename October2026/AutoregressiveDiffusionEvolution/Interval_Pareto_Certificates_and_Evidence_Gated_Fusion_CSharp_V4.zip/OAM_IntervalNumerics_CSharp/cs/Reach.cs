namespace OamIntervals;

/// <summary>Interval branch and bound over u in [0, 1] on the concave front (u, 1 - u^2) with zero reference.
/// Boxes whose lower bound exceeds a verified upper bound on the minimum are discarded; the survivors contain every minimizer.</summary>
public static class Reach
{
    public sealed record Result(string Kind, double L1, double L2, double Scale2, double HullLo, double HullHi, int Survivors, int Boxes, bool LeftEnd, bool RightEnd, double MaxEndpointDistance);

    static Iv Cheb(Iv u, double l1, double l2, double s2)
    {
        Iv a = l1 * u, b = l2 * (1.0 - u.Sqr()) / s2;
        return new(Math.Max(a.Lo, b.Lo), Math.Max(a.Hi, b.Hi));
    }
    static Iv Sum(Iv u, double l1, double l2, double s2) => l1 * u + l2 * (1.0 - u.Sqr()) / s2;

    public static Result Run(string kind, double l1, double l2, double s2 = 1, double tol = 1e-12)
    {
        Func<Iv, Iv> f = kind == "chebyshev" ? u => Cheb(u, l1, l2, s2) : u => Sum(u, l1, l2, s2);
        var work = new Stack<Iv>(); work.Push(new Iv(0, 1)); var keep = new List<Iv>(); int boxes = 0;
        double ub = Math.Min(f(Iv.Point(0)).Hi, f(Iv.Point(1)).Hi);
        while (work.Count > 0)
        {
            var X = work.Pop(); boxes++;
            Iv val = f(X); if (val.Lo > ub) continue;
            ub = Math.Min(ub, f(Iv.Point(X.Mid)).Hi);
            if (X.Width <= tol) { keep.Add(X); continue; }
            work.Push(new Iv(X.Mid, X.Hi)); work.Push(new Iv(X.Lo, X.Mid));
        }
        keep = keep.Where(X => f(X).Lo <= ub).ToList();
        return new(kind, l1, l2, s2, keep.Min(x => x.Lo), keep.Max(x => x.Hi), keep.Count, boxes,
            keep.Any(x => x.Lo == 0), keep.Any(x => x.Hi == 1), keep.Max(x => Math.Min(x.Hi, 1 - x.Lo)));
    }
}
