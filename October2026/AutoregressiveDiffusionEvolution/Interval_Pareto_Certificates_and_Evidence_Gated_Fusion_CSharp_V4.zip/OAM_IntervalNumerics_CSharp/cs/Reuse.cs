namespace OamIntervals;

/// <summary>Section 9.2: certified reference curve and a multi-seed rerun of the adaptive, selectively observed archive.
/// x in [-2, 2], uniform reference, G1 = (x + 1)^2, G2 = (x - 1)^2, beta = 2, S = l G1 + (1 - l) G2 = (x + 2l - 1)^2 + 4l(1 - l).</summary>
public static class Reuse
{
    public sealed record RefRow(double Lambda, double Lo, double Hi);
    public sealed record Run(int Seed, int Included, double MaxErrCorrected, double MaxErrUncorrected, double SupErrCorrected101, double[] Corrected11, double[] Uncorrected11);

    /// <summary>Validated midpoint quadrature of exp(-2 t^2) and (x + 1)^2 exp(-2 t^2), t = x + 2l - 1, on [-2, 2].</summary>
    public static RefRow Reference(double lam, int cells = 200_000)
    {
        double h = 4.0 / cells, sh = 2 * lam - 1; Iv Z = Iv.Point(0), N = Iv.Point(0);
        Iv H3 = Iv.Point(h) * Iv.Point(h) * Iv.Point(h) / 24.0;
        for (int k = 0; k < cells; k++)
        {
            double a = -2 + k * h; Iv X = new(a, a + h), m = Iv.Point(a + h / 2);
            (Iv f, Iv g) Val(Iv x) { Iv t = x + sh; Iv f = (-2.0 * t.Sqr()).Exp(); return (f, (x + 1.0).Sqr() * f); }
            var (fm, gm) = Val(m);
            Iv tX = X + sh, fX = (-2.0 * tX.Sqr()).Exp(), f1 = -4.0 * tX * fX, f2 = (16.0 * tX.Sqr() - 4.0) * fX, x1 = X + 1.0;
            Iv g2 = 2.0 * fX + 4.0 * x1 * f1 + x1.Sqr() * f2;
            Z += Iv.Point(h) * fm + H3 * f2; N += Iv.Point(h) * gm + H3 * g2;
        }
        Iv r = N / Z; return new(lam, r.Lo, r.Hi);
    }

    public static Run Simulate(int seed, double[] ref11, double[] ref101, int blocks = 100, int per = 1000)
    {
        var rnd = new Random(seed); double Nrm() => Math.Sqrt(-2 * Math.Log(1 - rnd.NextDouble())) * Math.Cos(2 * Math.PI * rnd.NextDouble());
        const double s = 0.35, beta = 2; double m = 0;
        var xs = new List<double>(); var lr = new List<double>(); var le = new List<double>();   // included records only
        for (int b = 0; b < blocks; b++)
        {
            // normalizing constant of the truncated normal by Simpson's rule (smooth integrand; diagnostic accuracy ~1e-13)
            int n = 4000; double hh = 4.0 / n, zt = 0;
            for (int k = 0; k <= n; k++) { double x = -2 + k * hh, w = k == 0 || k == n ? 1 : (k % 2 == 1 ? 4 : 2); zt += w * Math.Exp(-0.5 * (x - m) * (x - m) / (s * s)); }
            zt *= hh / 3 / (s * Math.Sqrt(2 * Math.PI));
            for (int i = 0; i < per; i++)
            {
                double x;
                if (rnd.NextDouble() < 0.2) x = -2 + 4 * rnd.NextDouble();
                else { do x = m + s * Nrm(); while (x < -2 || x > 2); }
                double p = 0.2 * 0.25 + 0.8 * Math.Exp(-0.5 * (x - m) * (x - m) / (s * s)) / (s * Math.Sqrt(2 * Math.PI) * zt);
                double e = 0.4 + 0.6 * Math.Min(1, Math.Abs(x) / 2);
                if (rnd.NextDouble() < e) { xs.Add(x); lr.Add(Math.Log(0.25 / p)); le.Add(Math.Log(e)); }
            }
            double lb = b % 2 == 0 ? 0.9 : 0.1;
            m = Math.Clamp(Estimate(xs, lr, le, lb, beta, true, x => x), -1.3, 1.3);
        }
        var corr = new double[11]; var unc = new double[11]; double ec = 0, eu = 0, sup = 0;
        for (int k = 0; k <= 10; k++)
        {
            double l = k / 10.0;
            corr[k] = Estimate(xs, lr, le, l, beta, true, x => (x + 1) * (x + 1));
            unc[k] = Estimate(xs, lr, le, l, beta, false, x => (x + 1) * (x + 1));
            ec = Math.Max(ec, Math.Abs(corr[k] - ref11[k])); eu = Math.Max(eu, Math.Abs(unc[k] - ref11[k]));
        }
        for (int k = 0; k <= 100; k++) sup = Math.Max(sup, Math.Abs(Estimate(xs, lr, le, k / 100.0, beta, true, x => (x + 1) * (x + 1)) - ref101[k]));
        return new(seed, xs.Count, ec, eu, sup, corr, unc);
    }

    static double Estimate(List<double> xs, List<double> lr, List<double> le, double l, double beta, bool corrected, Func<double, double> h)
    {
        int n = xs.Count; var lw = new double[n]; double mx = double.NegativeInfinity;
        for (int i = 0; i < n; i++)
        {
            double x = xs[i], S = l * (x + 1) * (x + 1) + (1 - l) * (x - 1) * (x - 1);
            lw[i] = -beta * S + (corrected ? lr[i] - le[i] : 0); mx = Math.Max(mx, lw[i]);
        }
        double sw = 0, sh = 0; for (int i = 0; i < n; i++) { double w = Math.Exp(lw[i] - mx); sw += w; sh += w * h(xs[i]); }
        return sh / sw;
    }
}
