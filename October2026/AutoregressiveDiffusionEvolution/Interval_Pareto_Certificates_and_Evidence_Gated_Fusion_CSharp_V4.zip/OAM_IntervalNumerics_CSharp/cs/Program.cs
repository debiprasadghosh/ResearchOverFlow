using System.Text.Json;
using System.Diagnostics;
using OamIntervals;

var results = new Dictionary<string, object>(); var sw = Stopwatch.StartNew();
results["gate"] = Fusion.Run(); Console.WriteLine(JsonSerializer.Serialize(results["gate"]));

var reach = new List<Reach.Result>();
foreach (var (l1, l2) in new[] { (15.0 / 19, 4.0 / 19), (3.0 / 5, 2.0 / 5), (7.0 / 19, 12.0 / 19) })
{ reach.Add(Reach.Run("chebyshev", l1, l2)); reach.Add(Reach.Run("sum", l1, l2)); }
reach.Add(Reach.Run("chebyshev", 0.5, 0.5)); reach.Add(Reach.Run("chebyshev", 0.5, 0.5, 8.2)); reach.Add(Reach.Run("sum", 0.5, 0.5));
results["reach"] = reach; foreach (var r in reach) Console.WriteLine(r);

var ref11 = Enumerable.Range(0, 11).Select(k => Reuse.Reference(k / 10.0)).ToList();
var ref101 = Enumerable.Range(0, 101).Select(k => Reuse.Reference(k / 100.0, 40_000)).ToList();
results["reference"] = ref11; results["reference101MaxWidth"] = ref101.Max(r => r.Hi - r.Lo);
foreach (var r in ref11) Console.WriteLine(r);
double[] mid11 = ref11.Select(r => 0.5 * (r.Lo + r.Hi)).ToArray(), mid101 = ref101.Select(r => 0.5 * (r.Lo + r.Hi)).ToArray();
results["reuseSeed"] = Reuse.Simulate(20261030, mid11, mid101);
Console.WriteLine(JsonSerializer.Serialize(results["reuseSeed"]));
var runs = new Reuse.Run[200];
Parallel.For(0, 200, k => runs[k] = Reuse.Simulate(k + 1, mid11, mid101));
double M(Func<Reuse.Run, double> f) => runs.Average(f);
double Q(Func<Reuse.Run, double> f, double p) { var v = runs.Select(f).OrderBy(t => t).ToArray(); return v[(int)Math.Round(p * (v.Length - 1))]; }
results["reuseReplication"] = new
{
    seeds = runs.Length, includedMean = M(r => r.Included), includedMin = runs.Min(r => r.Included), includedMax = runs.Max(r => r.Included),
    corrMedian = Q(r => r.MaxErrCorrected, 0.5), corr90 = Q(r => r.MaxErrCorrected, 0.9), corrMax = runs.Max(r => r.MaxErrCorrected),
    uncMedian = Q(r => r.MaxErrUncorrected, 0.5), uncMin = runs.Min(r => r.MaxErrUncorrected), uncMax = runs.Max(r => r.MaxErrUncorrected),
    supMedian = Q(r => r.SupErrCorrected101, 0.5), supMax = runs.Max(r => r.SupErrCorrected101),
    corrMeanCurve = Enumerable.Range(0, 11).Select(k => M(r => r.Corrected11[k])).ToArray(),
    corrSdCurve = Enumerable.Range(0, 11).Select(k => { double m = M(r => r.Corrected11[k]); return Math.Sqrt(runs.Sum(r => (r.Corrected11[k] - m) * (r.Corrected11[k] - m)) / 199); }).ToArray(),
    uncMeanCurve = Enumerable.Range(0, 11).Select(k => M(r => r.Uncorrected11[k])).ToArray()
};
Console.WriteLine(JsonSerializer.Serialize(results["reuseReplication"]));
File.WriteAllText("reuse_replicates.json", JsonSerializer.Serialize(runs.Select(r => new { r.Seed, r.Included, r.MaxErrCorrected, r.MaxErrUncorrected, r.SupErrCorrected101 })));
results["runtime"] = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription; results["seconds"] = sw.Elapsed.TotalSeconds;
File.WriteAllText("results.json", JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"written {sw.Elapsed.TotalSeconds:F1}s");
