namespace OamIntervals;

/// <summary>Certified closed forms for the evidence-gated Gaussian mixture of Section 9.1 (Theorem 2).</summary>
public static class Fusion
{
    public sealed record Gate(double GateLo0, double GateHi0, double GateLo1, double GateHi1, double MeanLo, double MeanHi, double FixedLo, double FixedHi);
    static readonly Iv Pi = new(Math.BitDecrement(Math.PI), Math.BitIncrement(Math.PI));

    public static Gate Run(double a = 0.5, double q = 0.4)
    {
        var comps = new[] { (c: -1.0, v: 0.05), (c: 1.0, v: 0.5) };
        Iv sa = Iv.Point(a).Sqrt(), Q = Iv.Point(q);
        var L = new Iv[2]; var M = new Iv[2];
        for (int j = 0; j < 2; j++)
        {
            var (c, v) = comps[j];
            Iv vr = sa.Sqr() * v + (1.0 - Iv.Point(a));                    // a v + 1 - a, with a = (sqrt a)^2 kept as an interval
            Iv r = Q - sa * c;
            L[j] = (-(r.Sqr()) / (2.0 * vr)).Exp() / (2.0 * Pi * vr).Sqrt();
            M[j] = Iv.Point(c) + sa * v * r / vr;
        }
        Iv S = L[0] + L[1], g0 = L[0] / S, g1 = L[1] / S;
        // g0 + g1 = 1 exactly; intersect each gate with 1 minus the other to tighten
        g0 = new(Math.Max(g0.Lo, 1 - g1.Hi), Math.Min(g0.Hi, 1 - g1.Lo));
        Iv mean = g0 * M[0] + g1 * M[1], fixedMean = 0.5 * (M[0] + M[1]);
        return new(g0.Lo, g0.Hi, g1.Lo, g1.Hi, mean.Lo, mean.Hi, fixedMean.Lo, fixedMean.Hi);
    }
}
