namespace EdeIntervals;

/// <summary>SplitMix64 with Box-Muller normals (deterministic and dependency-free).</summary>
public sealed class SplitMix(ulong s)
{
    ulong state = s; double? spare;
    public ulong Next() { ulong z = state += 0x9E3779B97F4A7C15UL; z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL; z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL; return z ^ (z >> 31); }
    public double U() => ((Next() >> 11) + 0.5) * (1.0 / 9007199254740992.0);
    public double Normal()
    {
        if (spare is double v) { spare = null; return v; }
        double u1 = U(), u2 = U(), r = Math.Sqrt(-2 * Math.Log(u1));
        spare = r * Math.Sin(2 * Math.PI * u2); return r * Math.Cos(2 * Math.PI * u2);
    }
    public int Below(int k) => (int)(Next() % (ulong)k);
}
