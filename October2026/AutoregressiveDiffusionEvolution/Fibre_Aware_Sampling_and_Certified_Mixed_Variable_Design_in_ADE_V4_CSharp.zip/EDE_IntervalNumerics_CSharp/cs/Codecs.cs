namespace EdeIntervals;

/// <summary>Certified codec constants and probability-record quantities.</summary>
public static class Codecs
{
    /// <summary>m_q = E max of q standard normals = int q z phi(z) Phi(z)^(q-1) dz: composite midpoint rule on [-10,10]
    /// with interval second-derivative remainder, plus |tails| &lt;= q phi(10).</summary>
    public static Iv Mq(int q, int cells = 20000)
    {
        double a = -10, b = 10, h = (b - a) / cells; var sum = Iv.Point(0);
        D2 F(Iv x)
        {
            var z = D2.Var(x); var p = z.Phi(); var pw = new D2(Iv.Point(1), Iv.Point(0), Iv.Point(0));
            for (int k = 0; k < q - 1; k++) pw = pw * p;
            return (double)q * (z * z.Pdf() * pw);
        }
        for (int i = 0; i < cells; i++)
        {
            double lo = a + i * h, hi = (i == cells - 1) ? b : a + (i + 1) * h;
            var w = Iv.Point(hi) - Iv.Point(lo); var mid = 0.5 * (Iv.Point(lo) + Iv.Point(hi));
            sum = sum + w * F(mid).V + (w.Sqr() * w) * F(new Iv(lo, hi)).DD / 24.0;
        }
        var tail = (double)q * Normal.Pdf(Iv.Point(10));
        return sum + new Iv(-2 * tail.Hi, 2 * tail.Hi);
    }
    public sealed record Level(int J, double[] Lower, double[] Rep, double[] Upper, bool Inside, double Margin);
    /// <summary>Equiprobable ordered levels: thresholds b_j = Phi^{-1}(j/n) and representatives (2) certified interior.</summary>
    public static List<Level> Ordered(int n)
    {
        var b = new Iv[n + 1];
        for (int j = 1; j < n; j++) b[j] = Normal.Quantile(Iv.Point(j) / (double)n);
        var res = new List<Level>();
        for (int j = 0; j < n; j++)
        {
            var pl = j == 0 ? Iv.Point(0) : Normal.Pdf(b[j]); var pu = j == n - 1 ? Iv.Point(0) : Normal.Pdf(b[j + 1]);
            var rep = (pl - pu) * (double)n;     // p_j = 1/n exactly
            double lo = j == 0 ? double.NegativeInfinity : b[j].Hi, hi = j == n - 1 ? double.PositiveInfinity : b[j + 1].Lo;
            bool inside = lo < rep.Lo && rep.Hi < hi;
            res.Add(new Level(j, j == 0 ? new[] { double.MinValue, double.MinValue } : new[] { b[j].Lo, b[j].Hi }, new[] { rep.Lo, rep.Hi },
                j == n - 1 ? new[] { double.MaxValue, double.MaxValue } : new[] { b[j + 1].Lo, b[j + 1].Hi }, inside, Math.Min(rep.Lo - lo, hi - rep.Hi)));
        }
        return res;
    }
    public static readonly Iv A = (2.0 / Normal.Pi).Sqrt();                 // sqrt(2/pi)
    public static readonly Iv P = 1.0 / (1.0 + Iv.Point(-2).Exp());          // Pr(Z > 0) under (13)
    /// <summary>Proposition 10: n times the asymptotic variance of the raw-weight estimate of P with proposal N(m,1).</summary>
    public static Iv AVarDesign(Iv m)
    {
        var phim = Normal.Cdf(m); var e4 = Iv.Point(-4).Exp(); var den = ((1.0 + Iv.Point(-2).Exp()) / 2.0).Sqr();
        return (m.Sqr()).Exp() * ((1.0 - P).Sqr() * Normal.Upper(m) + e4 * P.Sqr() * phim) / den;
    }
    /// <summary>Proposition 9: almost-sure limit of the estimator that re-evaluates rho/q at the snapped value +-a.</summary>
    public static (Iv lim, Iv avar) SnappedLimit()
    {
        var qpos = Normal.Cdf(Iv.Point(2)); var qneg = Normal.Upper(Iv.Point(2));   // Pr(z<=0) = 1 - Phi(2)
        var wp = (2.0 - 2.0 * A).Exp(); var wn = (2.0 * A).Exp();                   // e^{-2a+2}, e^{-2} e^{2a+2}
        var ew = qpos * wp + qneg * wn; var lim = qpos * wp / ew;
        var av = (qpos * wp.Sqr() * (1.0 - lim).Sqr() + qneg * wn.Sqr() * lim.Sqr()) / ew.Sqr();
        return (lim, av);
    }
    public sealed record Mc(int N, int Reps, double[] RawMeanSd, double[] WrongMeanSd, double[] SecondMeanSd, int ExactEqual, double[] RawEst, double[] WrongEst);
    public static Mc Simulate(int n, int reps, ulong seed)
    {
        var raw = new double[reps]; var wrong = new double[reps]; var sec = new double[reps]; int eq = 0; double a = Math.Sqrt(2 / Math.PI);
        Parallel.For(0, reps, rep =>
        {
            var r = new SplitMix(seed + (ulong)rep * 6151UL);
            double sw = 0, swx = 0, sws = 0, swz2 = 0, ww = 0, wwx = 0;
            for (int i = 0; i < n; i++)
            {
                double z = 2 + r.Normal(); bool x = z > 0; double s = x ? a : -a;
                double w = Math.Exp((x ? 0 : -2) - 2 * z + 2);
                sw += w; if (x) swx += w; if (s > 0) sws += w; swz2 += w * z * z;
                double wr = Math.Exp((x ? 0 : -2) - 2 * s + 2); ww += wr; if (x) wwx += wr;
            }
            raw[rep] = swx / sw; wrong[rep] = wwx / ww; sec[rep] = swz2 / sw;
            if (swx / sw == sws / sw) Interlocked.Increment(ref eq);
        });
        double[] MS(double[] v) { double m = v.Average(); return new[] { m, Math.Sqrt(v.Sum(e => (e - m) * (e - m)) / (v.Length - 1)) }; }
        return new Mc(n, reps, MS(raw), MS(wrong), MS(sec), eq, raw, wrong);
    }
}
