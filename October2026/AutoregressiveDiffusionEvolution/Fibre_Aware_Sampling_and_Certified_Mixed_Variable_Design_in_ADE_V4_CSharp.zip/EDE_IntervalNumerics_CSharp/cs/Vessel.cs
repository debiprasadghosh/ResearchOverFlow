namespace EdeIntervals;

/// <summary>Proposition 8: validated global solution of the mixed pressure-vessel benchmark of Section 4. Every decimal
/// coefficient is enclosed, so the certificate refers to the declared decimal problem. For each gauge pair the reduced
/// cost c(r) = cost(t_s, t_h, r, l*(r)) on [r200, u] is minimized by interval branch and bound; stationary points of the
/// quartic (19) are isolated by interval Newton.</summary>
public static class Vessel
{
    static Iv Dec(double x) => Normal.Dec(x);
    static readonly Iv C1 = Dec(0.6224), C2 = Dec(1.7781), C3 = Dec(3.1661), C4 = Dec(19.84), G1 = Dec(0.0193), G2 = Dec(0.00954), Pi = Normal.Pi;
    const double V = 1296000.0;
    static Iv Vol(Iv r, Iv l) => Pi * r.Sqr() * (l + 4.0 * r / 3.0);
    /// <summary>Radius with volume V at length L, by certified bisection (volume increasing in r).</summary>
    public static Iv RadiusFor(double L)
    {
        double lo = 10, hi = 200;
        for (int i = 0; i < 200; i++)
        {
            double m = 0.5 * (lo + hi); if (m == lo || m == hi) break; var v = Vol(Iv.Point(m), Iv.Point(L));
            if (v.Hi < V) lo = m; else if (v.Lo > V) hi = m; else break;
        }
        return new Iv(lo, hi);
    }
    static Iv LExpr(double r) { var ri = Iv.Point(r); return V / (Pi * ri.Sqr()) - 4.0 * ri / 3.0; }
    /// <summary>Enclosure of l*(r) = max(10, V/(pi r^2) - 4r/3) over [a,b], using monotonicity of the expression.</summary>
    static Iv LStar(double a, double b) { var lo = LExpr(b).Lo; var hi = LExpr(a).Hi; return new Iv(Math.Max(10, lo), Math.Max(10, hi)); }
    public static Iv Cost(Iv ts, Iv th, Iv r, Iv l) => C1 * ts * r * l + C2 * th * r.Sqr() + C3 * ts.Sqr() * l + C4 * ts.Sqr() * r;
    static Iv Reduced(Iv ts, Iv th, double a, double b) => Cost(ts, th, new Iv(a, b), LStar(a, b));

    public sealed record Pair(int Ks, int Kh, double[] Min, int Boxes, int Roots, int Undecided);
    public sealed record Design(double Ts, double Th, double R, double L, double[] Cost, double[] ShellSlack, double[] HeadSlack, double[] VolumeSlack);
    public sealed record Res(double[] R200, double[] R10, int Nonempty, int Empty, int UndecidedPairs, double[] Global, int[] BestPair, double[] RunnerUp, int[] RunnerUpPair,
        int PairsWithin1Pct, int RefinedPairs, Design Verified, int TotalRoots, int[] RootHistogram, int RootUndecided, int TotalBoxes, List<Pair> Pairs, double Seconds);

    static (int roots, int undecided) Roots(Iv ts, Iv th, double a, double b)
    {
        var A = C1 * ts * V / Pi; var B = C2 * th - 4.0 / 3.0 * C1 * ts; var C = C3 * ts.Sqr() * V / Pi; var D = (C4 - 4.0 / 3.0 * C3) * ts.Sqr();
        Iv P(Iv r) => 2.0 * B * r.Sqr().Sqr() + D * r.Sqr() * r - A * r - 2.0 * C;
        Iv Pd(Iv r) => 8.0 * B * r.Sqr() * r + 3.0 * D * r.Sqr() - A;
        int roots = 0, und = 0; var stack = new Stack<(double, double)>(); stack.Push((a, b));
        while (stack.Count > 0)
        {
            var (lo, hi) = stack.Pop(); var X = new Iv(lo, hi);
            var px = P(X); if (px.Lo > 0 || px.Hi < 0) continue;
            var dx = Pd(X);
            if (dx.Lo > 0 || dx.Hi < 0)
            {
                double m = 0.5 * (lo + hi); var N = Iv.Point(m) - P(Iv.Point(m)) / dx;
                if (N.Lo > lo && N.Hi < hi) { roots++; continue; }               // N(X) in int X: exactly one root
                double nlo = Math.Max(lo, N.Lo), nhi = Math.Min(hi, N.Hi);
                if (nlo > nhi) continue;                                         // no root
                if (nhi - nlo < 0.5 * (hi - lo)) { stack.Push((nlo, nhi)); continue; }
            }
            if (hi - lo < 1e-12 * hi) { und++; continue; }
            double mid = 0.5 * (lo + hi); stack.Push((lo, mid)); stack.Push((mid, hi));
        }
        return (roots, und);
    }

    /// <summary>Interval branch and bound for one gauge pair: returns (lower bound, upper bound, boxes) for the minimum of the
    /// reduced cost on [r200, u]. Upper bounds come from exact reduced costs at radii certified inside [r200.Hi, u.Lo];
    /// boxes are pruned against min(own incumbent, external bound) and become leaves when their cost width is below relTol.</summary>
    static (double lb, double ub, int boxes) Minimize(int ks, int kh, Iv r200, double ulo, double uhi, double external, double relTol)
    {
        var ts = Iv.Point(ks / 16.0); var th = Iv.Point(kh / 16.0);
        double ub = double.MaxValue;
        void Try(double r) { if (r >= r200.Hi && r <= ulo) ub = Math.Min(ub, Reduced(ts, th, r, r).Hi); }
        Try(r200.Hi); Try(ulo); Try(0.5 * (r200.Hi + ulo));
        double lb = double.MaxValue; int boxes = 0;
        var stack = new Stack<(double, double)>(); stack.Push((r200.Lo, uhi));
        while (stack.Count > 0)
        {
            var (lo, hi) = stack.Pop(); boxes++;
            var c = Reduced(ts, th, lo, hi);
            if (c.Lo > Math.Min(ub, external)) continue;
            double mid = 0.5 * (lo + hi); Try(mid);
            if (c.Width <= relTol * c.Lo || mid <= lo || mid >= hi) { lb = Math.Min(lb, c.Lo); continue; }
            stack.Push((lo, mid)); stack.Push((mid, hi));
        }
        return (lb, ub, boxes);
    }

    public static Res Run()
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var r200 = RadiusFor(200); var r10 = RadiusFor(10);
        var pairs = new List<Pair>(); int nonempty = 0, empty = 0, und = 0;
        var jobs = new List<(int, int, double, double)>();
        for (int ks = 1; ks <= 99; ks++)
            for (int kh = 1; kh <= 99; kh++)
            {
                var ts = Iv.Point(ks / 16.0); var th = Iv.Point(kh / 16.0);
                var u1 = ts / G1; var u2 = th / G2;
                var u = new Iv(Math.Min(200, Math.Min(u1.Lo, u2.Lo)), Math.Min(200, Math.Min(u1.Hi, u2.Hi)));
                if (u.Hi < r200.Lo) { empty++; continue; }
                if (u.Lo > r200.Hi) nonempty++; else { und++; }
                jobs.Add((ks, kh, u.Lo, u.Hi));
            }
        var res = new Pair[jobs.Count]; var boxesTotal = 0;
        // pass 1: every pair, minimum enclosed to relative width about 1e-6 using the pair's own incumbent
        Parallel.For(0, jobs.Count, j =>
        {
            var (ks, kh, ulo, uhi) = jobs[j];
            var (lb, ub, boxes) = Minimize(ks, kh, r200, ulo, uhi, double.MaxValue, 1e-6);
            var (nr, nu) = Roots(Iv.Point(ks / 16.0), Iv.Point(kh / 16.0), r200.Lo, Math.Min(uhi, r10.Hi));
            res[j] = new Pair(ks, kh, new[] { lb, ub }, boxes, nr, nu);
            Interlocked.Add(ref boxesTotal, boxes);
        });
        pairs = res.ToList();
        var best = pairs.OrderBy(p => p.Min[1]).First();
        double gLo = pairs.Min(p => p.Min[0]), gHi = 0; int refinedPairs = 0;
        var others = pairs.Where(p => p != best).OrderBy(p => p.Min[0]).ToList(); var runner = others.First();
        int within = pairs.Count(p => p.Min[0] <= best.Min[1] * 1.01);
        // explicit verified design for the best pair: radius just inside the shell bound, length just above volume
        var tsB = best.Ks / 16.0; var thB = best.Kh / 16.0;
        double rf = tsB / 0.0193; while ((G1 * Iv.Point(rf)).Hi > tsB || (G2 * Iv.Point(rf)).Hi > thB) rf = Math.BitDecrement(rf);
        double lf = LExpr(rf).Mid; while (Vol(Iv.Point(rf), Iv.Point(lf)).Lo < V) lf = Math.BitIncrement(lf);
        var cf = Cost(Iv.Point(tsB), Iv.Point(thB), Iv.Point(rf), Iv.Point(lf));
        var design = new Design(tsB, thB, rf, lf, new[] { cf.Lo, cf.Hi }, new[] { (tsB - G1 * rf).Lo, (tsB - G1 * rf).Hi }, new[] { (thB - G2 * rf).Lo, (thB - G2 * rf).Hi },
            new[] { (Vol(Iv.Point(rf), Iv.Point(lf)) - V).Lo, (Vol(Iv.Point(rf), Iv.Point(lf)) - V).Hi });
        if (!(rf >= 10 && rf <= 200 && lf >= 10 && lf <= 200)) throw new InvalidOperationException("verified design outside box");
        // pass 2: global bound with pruning against the verified upper bound, tight leaf tolerance
        double U = Math.Min(best.Min[1], cf.Hi); double L = double.MaxValue; int refined = 0;
        foreach (var p in pairs.Where(p => p.Min[0] <= U))
        {
            var jb = jobs.First(x => x.Item1 == p.Ks && x.Item2 == p.Kh);
            var (lb2, ub2, bx) = Minimize(p.Ks, p.Kh, r200, jb.Item3, jb.Item4, U, 1e-12); refined++;
            L = Math.Min(L, Math.Min(lb2, ub2)); U = Math.Min(U, ub2);
        }
        gLo = L; refinedPairs = refined; gHi = U;
        var hist = new int[5]; foreach (var p in pairs) hist[Math.Min(p.Roots, 4)]++;
        return new Res(new[] { r200.Lo, r200.Hi }, new[] { r10.Lo, r10.Hi }, nonempty, empty, und, new[] { gLo, gHi }, new[] { best.Ks, best.Kh },
            runner.Min, new[] { runner.Ks, runner.Kh }, within, refinedPairs, design, pairs.Sum(p => p.Roots), hist, pairs.Sum(p => p.Undecided), boxesTotal, pairs, sw.Elapsed.TotalSeconds);
    }
}
