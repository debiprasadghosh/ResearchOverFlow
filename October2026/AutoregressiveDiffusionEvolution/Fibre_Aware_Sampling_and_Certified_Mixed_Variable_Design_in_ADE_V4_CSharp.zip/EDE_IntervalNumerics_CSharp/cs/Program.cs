using System.Diagnostics;
using System.Text.Json;
using EdeIntervals;

var results = new Dictionary<string, object>(); var sw = Stopwatch.StartNew(); var t = Stopwatch.StartNew();
void Log(string k, object v) { results[k] = v; var s = JsonSerializer.Serialize(v); Console.WriteLine($"{k}: {(s.Length > 1500 ? s[..1500] + "..." : s)}  [{t.Elapsed.TotalSeconds:F1}s]"); t.Restart(); }
double[] E(Iv x) => new[] { x.Lo, x.Hi };

// validated normal function spot checks against the series/continued-fraction switch at |x| = 3
Log("phi_checks", new { at3series = E(Normal.Cdf(Iv.Point(3))), at3mills = E(1.0 - Normal.Pdf(Iv.Point(3)) * Normal.Mills(Iv.Point(3))),
    at2 = E(Normal.Cdf(Iv.Point(2))), tail21 = E(Normal.Pdf(3.0 / (Normal.Sqrt2 * Normal.Dec(0.1))) * Normal.Mills(3.0 / (Normal.Sqrt2 * Normal.Dec(0.1)))),
    tail4 = E(Normal.Cdf(-3.0 / (Normal.Sqrt2 * Normal.Dec(0.5)))) });
Log("mq", new[] { 2, 3, 4, 5, 6, 8, 12, 16, 24, 32 }.Select(q => { var m = Codecs.Mq(q); return new { q, lo = m.Lo, hi = m.Hi, width = m.Width }; }).ToList());
var lv = Codecs.Ordered(16);
Log("ordered16", new { allInside = lv.All(l => l.Inside), minMargin = lv.Min(l => l.Margin), levels = lv });
Log("binary", new { P = E(Codecs.P), Ez = E(Codecs.A * ((Iv.Point(2).Exp() - 1.0) / (Iv.Point(2).Exp() + 1.0))), a = E(Codecs.A), snappedSecond = E(Codecs.A.Sqr()) });
Log("avar_design", Enumerable.Range(0, 31).Select(i => { var m = i * 0.1; var v = Codecs.AVarDesign(Normal.Dec(m)); return new { m, lo = v.Lo, hi = v.Hi }; }).ToList());
var (lim, av) = Codecs.SnappedLimit();
Log("snapped", new { limit = E(lim), avar = E(av), bias = E(lim - Codecs.P), se400k = Math.Sqrt(av.Hi / 400000) });
Log("estimator_mc", Codecs.Simulate(400_000, 200, 20261102UL));
Log("vessel", Vessel.Run());
results["runtime"] = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription; results["seconds"] = sw.Elapsed.TotalSeconds;
File.WriteAllText("results.json", JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"written {sw.Elapsed.TotalSeconds:F1}s");
