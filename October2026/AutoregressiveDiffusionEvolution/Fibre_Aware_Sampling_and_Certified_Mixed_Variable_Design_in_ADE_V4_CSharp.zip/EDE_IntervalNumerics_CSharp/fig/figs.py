import json, math, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'font.family': 'DejaVu Sans'})
NAVY = '#213f63'; RUST = '#b5612f'; GREY = '#9aa3aa'; DARK = '#444444'; GOLD = '#c39a2f'; TEAL = '#2f7f86'
R = json.load(open('../cs/results.json')); S = json.load(open('../num/sym.json'))
V = 1296000.0

# ---------- Figure 2: validated pressure-vessel solution
Vs = R['vessel']; cstar = Vs['Global'][1]
grid = np.full((99, 99), np.nan)
for p in Vs['Pairs']:
    grid[p['Kh'] - 1, p['Ks'] - 1] = max(p['Min'][0] - cstar, 1e-3)
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.75))
im = ax[0].imshow(np.log10(grid), origin='lower', extent=(0.5, 99.5, 0.5, 99.5), cmap='viridis_r', aspect='auto', vmin=-3, vmax=5)
ks, kh = Vs['BestPair']; ax[0].plot(ks, kh, marker='*', color=RUST, ms=10, mec='white', mew=0.6)
rk, rh = Vs['RunnerUpPair']; ax[0].plot(rk, rh, marker='o', color='white', ms=4, mec=DARK, mew=0.6)
cb = fig.colorbar(im, ax=ax[0], fraction=0.05, pad=0.02); cb.set_label('log₁₀(lower bound − c*)', fontsize=7.5); cb.ax.tick_params(labelsize=7)
ax[0].set_xlabel('Shell gauge index kₛ'); ax[0].set_ylabel('Head gauge index kₕ')
ax[0].set_xlim(8.5, 45.5); ax[0].set_ylim(3.5, 40.5)
ax[0].set_title('A  Certified pair minima', fontsize=9.5)
def r_for(L):
    lo, hi = 10.0, 200.0
    for _ in range(200):
        m = 0.5 * (lo + hi)
        if math.pi * m * m * (L + 4 * m / 3) < V: lo = m
        else: hi = m
    return lo
r200 = r_for(200)
def cost(ts, th, r):
    l = max(10.0, V / (math.pi * r * r) - 4 * r / 3)
    return 0.6224 * ts * r * l + 1.7781 * th * r * r + 3.1661 * ts * ts * l + 19.84 * ts * ts * r
for (a, b), col, ls in (((ks, kh), RUST, '-'), ((rk, rh), NAVY, '--'), ((ks, kh + 1), GOLD, '-.'), ((ks + 2, kh), GREY, ':')):
    ts, th = a / 16, b / 16; u = min(200, ts / 0.0193, th / 0.00954)
    if u < r200: continue
    rr = np.linspace(r200, u, 400)
    ax[1].plot(rr, [cost(ts, th, r) for r in rr], ls, color=col, lw=1.3, label=f'kₛ = {a}, kₕ = {b}')
ax[1].plot([Vs['Verified']['R']], [cstar], '*', color=RUST, ms=9, mec='white', mew=0.6)
ax[1].set_xlabel('Radius r'); ax[1].set_ylabel('Reduced cost c(r)'); ax[1].set_ylim(5900, 7600)
ax[1].set_title('B  Optimum at the shell bound', fontsize=9.5); ax[1].legend(fontsize=6.6, frameon=False, loc='upper right')
plt.tight_layout(); plt.savefig('fig2.png', dpi=300); plt.close()

# ---------- Figure 3: probability records
mc = R['estimator_mc']; P = 1 / (1 + math.exp(-2)); lim = R['snapped']['limit'][0]
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.6))
raw = np.array(mc['RawEst']); wrong = np.array(mc['WrongEst'])
bins = np.linspace(0.870, 0.935, 66)
ax[0].hist(raw, bins=bins, color=NAVY, alpha=0.75, label='Raw weights')
ax[0].hist(wrong, bins=bins, color=RUST, alpha=0.75, label='Ratio at snapped value')
ax[0].axvline(P, color=NAVY, ls='--', lw=1); ax[0].axvline(lim, color=RUST, ls='--', lw=1)
ax[0].text(P, ax[0].get_ylim()[1] * 0.95, ' target 0.8808', fontsize=6.6, color=NAVY, va='top')
ax[0].text(lim, ax[0].get_ylim()[1] * 0.95, 'limit 0.9288 ', fontsize=6.6, color=RUST, va='top', ha='right')
ax[0].set_xlabel('Estimate of Pr(Z > 0), n = 400,000'); ax[0].set_ylabel('Replicates')
ax[0].set_title('A  Snapped density ratio converges elsewhere', fontsize=9.5); ax[0].legend(fontsize=6.6, frameon=False, loc='center', bbox_to_anchor=(0.55, 0.55))
av = R['avar_design']
ax[1].semilogy([x['m'] for x in av], [x['hi'] for x in av], color=NAVY, lw=1.4)
ax[1].axvline(2, color=GREY, ls=':', lw=0.8)
ax[1].set_xlabel('Proposal mean m in N(m, 1)'); ax[1].set_ylabel('n × asymptotic variance')
ax[1].set_title('B  Cost of a shifted proposal', fontsize=9.5)
plt.tight_layout(); plt.savefig('fig3.png', dpi=300); plt.close()

# ---------- Figure 4: codec constants
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.6))
mq = R['mq']; qs = np.array([m['q'] for m in mq]); vals = np.array([0.5 * (m['lo'] + m['hi']) for m in mq])
ax[0].plot(qs, vals, 'o-', color=NAVY, ms=4, lw=1.2, label='Certified mₑ')
qq = np.linspace(2, 32, 200); ax[0].plot(qq, np.sqrt(2 * np.log(qq)), '--', color=RUST, lw=1, label='√(2 log q)')
ax[0].set_xscale('log', base=2); ax[0].set_xticks([2, 4, 8, 16, 32], ['2', '4', '8', '16', '32'])
ax[0].set_xlabel('Categories q'); ax[0].set_ylabel('E max of q normals')
ax[0].set_title('A  Argmax representative scale', fontsize=9.5)
h, l = ax[0].get_legend_handles_labels(); ax[0].legend(h, ['Certified m(q)', '√(2 log q)'], fontsize=6.8, frameon=False, loc='upper left')
lv = R['ordered16']['levels']
for j, L in enumerate(lv):
    rep = 0.5 * (L['Rep'][0] + L['Rep'][1]); ax[1].plot([rep], [j], 'o', color=RUST, ms=3.5)
    lo = L['Lower'][0] if L['Lower'][0] > -1e300 else -2.6; hi = L['Upper'][1] if L['Upper'][1] < 1e300 else 2.6
    ax[1].plot([lo, hi], [j, j], '-', color=NAVY, lw=1.2)
ax[1].plot([], [], '-', color=NAVY, label='Certified threshold interval'); ax[1].plot([], [], 'o', color=RUST, ms=3.5, label='Certified representative (2)')
ax[1].set_xlim(-2.6, 2.6); ax[1].set_xlabel('Latent coordinate'); ax[1].set_ylabel('Level j')
ax[1].set_title('B  Sixteen ordered levels round-trip', fontsize=9.5); ax[1].legend(fontsize=6.4, frameon=False, loc='upper left')
plt.tight_layout(); plt.savefig('fig4.png', dpi=300); plt.close()
print('ok')
