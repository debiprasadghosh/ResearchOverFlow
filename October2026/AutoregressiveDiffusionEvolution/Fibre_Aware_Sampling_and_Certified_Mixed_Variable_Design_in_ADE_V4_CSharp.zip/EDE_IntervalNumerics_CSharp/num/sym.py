"""Exact/symbolic checks for Embedding and De-embedding Part I V4 (SymPy 1.14, mpmath 1.3)."""
import sympy as sp, mpmath as mp, json, itertools
mp.mp.dps = 40; R = sp.Rational; out = {}
z, m = sp.symbols('z m', real=True)
phi = sp.exp(-z ** 2 / 2) / sp.sqrt(2 * sp.pi)
Phi = lambda x: (1 + sp.erf(x / sp.sqrt(2))) / 2

# ---- m_q = E max of q standard normals (high-precision quadrature, not interval)
def mq(q):
    f = lambda x: q * x * mp.npdf(x) * mp.ncdf(x) ** (q - 1)
    return mp.quad(f, [-mp.inf, -5, 0, 5, mp.inf])
out['m_q'] = {q: mp.nstr(mq(q), 20) for q in (2, 3, 4, 5, 6, 16)}
out['m2_exact'] = str(sp.nsimplify(1 / sp.sqrt(sp.pi))); out['m3_exact'] = '3/(2*sqrt(pi))'
out['m3_check'] = mp.nstr(mq(3) - 3 / (2 * mp.sqrt(mp.pi)), 5)

# ---- (13): binary target under beta = 2
a = sp.sqrt(2 / sp.pi); P = 1 / (1 + sp.exp(-2))
Zn = sp.integrate(phi * sp.exp(-2), (z, -sp.oo, 0)) + sp.integrate(phi, (z, 0, sp.oo))
EZ = (sp.integrate(z * phi * sp.exp(-2), (z, -sp.oo, 0)) + sp.integrate(z * phi, (z, 0, sp.oo))) / Zn
EZ2 = (sp.integrate(z ** 2 * phi * sp.exp(-2), (z, -sp.oo, 0)) + sp.integrate(z ** 2 * phi, (z, 0, sp.oo))) / Zn
out['eq13'] = [str(sp.simplify(sp.integrate(phi, (z, 0, sp.oo)) / Zn - P)), str(sp.simplify(EZ - a * sp.tanh(1)).rewrite(sp.exp).simplify()), str(sp.simplify(EZ2))]
out['eq13_values'] = [mp.nstr(mp.mpf(sp.N(P, 40)), 15), mp.nstr(mp.mpf(sp.N(a * sp.tanh(1), 40)), 15)]

# ---- Proposition 10: asymptotic variance of the raw-weight SNIS estimate of Pr(Z>0), proposal N(m,1)
w_num = sp.exp(-2 * sp.Heaviside(-z))   # tilt
q_den = sp.exp(-(z - m) ** 2 / 2) / sp.sqrt(2 * sp.pi)
ratio2 = sp.simplify(phi ** 2 / q_den)
out['rho2_over_q'] = str(sp.simplify(ratio2 / (sp.exp(m ** 2) * sp.exp(-(z + m) ** 2 / 2) / sp.sqrt(2 * sp.pi))))
avar = sp.exp(m ** 2) * ((1 - P) ** 2 * (1 - Phi(m)) + sp.exp(-4) * P ** 2 * Phi(m)) / ((1 + sp.exp(-2)) / 2) ** 2
out['avar_design_formula'] = 'exp(m^2)[(1-P)^2(1-Phi(m)) + e^{-4} P^2 Phi(m)] / ((1+e^{-2})/2)^2'
# direct numerical check of the formula at m = 2 with mpmath
mm = 2
def integrand_num(x):
    t = mp.e ** (-2) if x <= 0 else 1
    w = t * mp.npdf(x) / mp.npdf(x, mm)
    hh = (1 if x > 0 else 0) - mp.mpf(1) / (1 + mp.e ** -2)
    return w ** 2 * hh ** 2 * mp.npdf(x, mm)
num = mp.quad(integrand_num, [-mp.inf, 0, mp.inf]); den = ((1 + mp.e ** -2) / 2) ** 2
av2 = sp.N(avar.subs(m, 2), 30)
out['avar_m2'] = mp.nstr(mp.mpf(av2), 15); out['avar_m2_quad'] = mp.nstr(num / den, 15)
se = mp.sqrt(mp.mpf(av2) / 400000)
Pv = mp.mpf(1) / (1 + mp.e ** -2)
out['se_design_n400000'] = mp.nstr(se, 8); out['z_0.87847'] = mp.nstr((mp.mpf('0.87847') - Pv) / se, 6)
out['avar_m0'] = mp.nstr(mp.mpf(sp.N(avar.subs(m, 0), 30)), 12)
# second moment estimator (h = z^2, target value 1), proposal N(2,1)
def integrand2(x):
    t = mp.e ** (-2) if x <= 0 else 1
    w = t * mp.npdf(x) / mp.npdf(x, 2)
    return w ** 2 * (x * x - 1) ** 2 * mp.npdf(x, 2)
av_sm = mp.quad(integrand2, [-mp.inf, -2, 0, 2, mp.inf]) / den
out['avar_second_moment_m2'] = mp.nstr(av_sm, 12); se2 = mp.sqrt(av_sm / 400000)
out['se_second_moment'] = mp.nstr(se2, 8); out['z_0.99559'] = mp.nstr((mp.mpf('0.99559') - 1) / se2, 6)

# ---- Proposition 9: limit of the estimator that re-evaluates the density ratio at the snapped value
s = sp.sqrt(2 / sp.pi)
Q_pos = Phi(2)        # proposal N(2,1): Pr(z>0) = Phi(2)
lim = Q_pos * sp.exp(-2 * s + 2) / (Q_pos * sp.exp(-2 * s + 2) + (1 - Q_pos) * sp.exp(-2) * sp.exp(2 * s + 2))
out['snapped_limit'] = mp.nstr(mp.mpf(sp.N(lim, 40)), 15)
out['snapped_bias'] = mp.nstr(mp.mpf(sp.N(lim - P, 40)), 10)
# its asymptotic s.e. (two-valued weights): delta method
wp = sp.exp(-2 * s + 2); wn = sp.exp(-2) * sp.exp(2 * s + 2)
Ew = Q_pos * wp + (1 - Q_pos) * wn; L = Q_pos * wp / Ew
av_wrong = (Q_pos * wp ** 2 * (1 - L) ** 2 + (1 - Q_pos) * wn ** 2 * L ** 2) / Ew ** 2
se_w = mp.sqrt(mp.mpf(sp.N(av_wrong, 30)) / 400000)
out['snapped_se'] = mp.nstr(se_w, 8); out['z_0.92752'] = mp.nstr((mp.mpf('0.92752') - mp.mpf(sp.N(lim, 30))) / se_w, 6)

# ---- union projection atoms, monte carlo s.e.
out['union_atoms'] = str(R(1, 10) * 4)
out['union_se_400000'] = mp.nstr(mp.sqrt(mp.mpf('0.4') * mp.mpf('0.6') / 400000), 8)
out['z_0.40006'] = mp.nstr((mp.mpf('0.40006') - mp.mpf('0.4')) / mp.sqrt(mp.mpf('0.24') / 400000), 6)

# ---- modulo q = 6: conditional mean of category 0 (words 000 and 110), and probabilities
words = list(itertools.product([0, 1], repeat=3))
cat = {wd: int(''.join(map(str, wd)), 2) % 6 for wd in words}
probs = [sum(1 for wd in words if cat[wd] == c) for c in range(6)]
mean0 = [sp.Rational(sum((1 if wd[i] else -1) for wd in words if cat[wd] == 0), probs[0]) * a for i in range(3)]
out['mod6_probs_over_8'] = probs; out['mod6_mean_cat0'] = [str(sp.simplify(x)) for x in mean0]

# ---- count thermometer with m = 15: representatives and their redecoded counts
mth = 15
reps = [a * (2 * R(k, mth) - 1) for k in range(mth + 1)]
out['thermo_redecoded'] = [int(mth if x > 0 else 0) for x in reps]
out['thermo_interior_changed'] = sum(1 for k in range(1, mth) if out['thermo_redecoded'][k] != k)

# ---- exploration bound (1 - eps/q)^N <= delta
for eps_, q_, dl in ((R(1, 10), 6, R(1, 100)), (R(1, 10), 16, R(1, 100)), (R(1, 20), 16, R(1, 1000))):
    N = mp.log(mp.mpf(dl.p) / dl.q) / mp.log(1 - mp.mpf(eps_.p) / eps_.q / q_)
    out[f'explore_eps{eps_}_q{q_}_delta{dl}'] = [mp.nstr(N, 12), int(mp.ceil(N))]
# probit crossing probability at gap 3, sigma 0.1
out['probit_gap3_sigma0.1'] = mp.nstr(mp.ncdf(-3 / (mp.sqrt(2) * mp.mpf('0.1'))), 12)
out['probit_gap3_sigma0.5'] = mp.nstr(mp.ncdf(-3 / (mp.sqrt(2) * mp.mpf('0.5'))), 12)

# ---- pressure vessel: high-precision recomputation at the reported optimum corner
mp.mp.dps = 50
ts, th = mp.mpf(13) / 16, mp.mpf(7) / 16
r = ts / mp.mpf('0.0193'); V = mp.mpf(1296000)
l = V / (mp.pi * r * r) - 4 * r / 3
c = mp.mpf('0.6224') * ts * r * l + mp.mpf('1.7781') * th * r * r + mp.mpf('3.1661') * ts * ts * l + mp.mpf('19.84') * ts * ts * r
out['pv_corner'] = {'r': mp.nstr(r, 25), 'l': mp.nstr(l, 25), 'cost': mp.nstr(c, 25), 'head_slack': mp.nstr(th - mp.mpf('0.00954') * r, 20)}
json.dump(out, open('sym.json', 'w'), indent=1); print(json.dumps(out, indent=1))
