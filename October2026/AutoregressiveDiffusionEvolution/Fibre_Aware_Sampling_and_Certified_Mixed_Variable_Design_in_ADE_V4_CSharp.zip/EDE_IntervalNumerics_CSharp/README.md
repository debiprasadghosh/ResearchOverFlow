# Embedding and De-embedding Part I V4: validated interval numerics

- cs/: .NET 8 C# program (no packages). `dotnet run -c Release` writes results.json (about 25 s).
  Interval.cs (outward rounding), Normal.cs (validated phi, Phi, Mills ratio, quantiles; second-order interval AD),
  Codecs.cs (m_q, ordered levels, Propositions 9-10, estimator diagnostic), Vessel.cs (Proposition 8: certified
  pressure-vessel optimum, interval Newton root isolation, verified feasible design), Rng.cs.
- num/sym.py: SymPy 1.14 / mpmath 1.3 exact and symbolic checks -> sym.json.
- fig/figs.py: Figures 2-4 from cs/results.json and num/sym.json.
- build/: fragment sources and the docx assembly script.
Assumption: Math.Exp and Math.Log are accurate to within four ulps (results are widened accordingly).
