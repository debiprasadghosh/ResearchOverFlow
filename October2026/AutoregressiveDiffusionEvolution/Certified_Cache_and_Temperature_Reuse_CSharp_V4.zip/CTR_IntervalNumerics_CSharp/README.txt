Caches, Temperature and Reuse V4: validated interval numerics (Sections 8.4-8.7, Appendix C)

symbolic/  sym.py: SymPy checks of (6), (8), (9), (11), (12), (15), (17), the audit target,
           the limit of Proposition 7, the budget overshoot formula and resource counts.
           alloc.py: grid diagnostic for the five inclusion rules; writes alloc.json (run first).
cs/        .NET 8 console project. Build: dotnet build -c Release
           Run from cs/: dotnet bin/Release/net8.0/Ctr.dll ../symbolic/alloc.json   (about 80 s)
           Writes results.json and audit_replicates.json.
figures/   figs.py regenerates Figures 2 and 3 (expects ../cs and ../num paths as in the build tree;
           adjust the two paths at the top if run from this archive).
