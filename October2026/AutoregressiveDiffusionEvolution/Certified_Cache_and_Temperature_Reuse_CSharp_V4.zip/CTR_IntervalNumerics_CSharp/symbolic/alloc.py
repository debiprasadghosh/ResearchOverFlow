import numpy as np, json
from scipy.optimize import brentq
h=0.004; g=np.arange(-8+h/2,8,h); Y1,Y2=np.meshgrid(g,g,indexing='ij'); J=Y1**2+Y2**2
phi=np.exp(-J/2)/(2*np.pi); s2=0.35**2; gq=np.exp(-J/(2*s2))/(2*np.pi*s2)
p=0.75*gq+0.25*phi; f=np.exp(-J/2)*phi; W=f/p; G=W*(J-1); A=h*h; Z=0.5
print('Z check',(f.sum()*A), 'EJ', (J*f).sum()*A/(f.sum()*A), 'p mass',p.sum()*A)
egate=np.where(np.abs(Y1)>1,1.0,0.25)
rho=(egate*p).sum()*A
def V(e): return (G**2/e*p).sum()*A/Z**2
def oracle(floor):
    def budget(gm): return (np.clip(gm*np.abs(G),floor,1)*p).sum()*A-rho
    gm=brentq(budget,1e-6,1e6,xtol=1e-14); return gm,np.clip(gm*np.abs(G),floor,1)
out={'rho_gate':rho}
rules={'complete':np.ones_like(J),'gate':egate,'uniform':np.full_like(J,rho)}
for fl in (0.25,0.05):
    gm,e=oracle(fl); rules[f'oracle_{fl}']=e; out[f'gamma_{fl}']=gm
for k,e in rules.items():
    out[k]={'budget':(e*p).sum()*A,'asym_var':V(e),'sd_1e5':np.sqrt(V(e)/1e5)}
# omitted-correction limit for gate under this fixed proposal (target e*f) -- independent of p
out['omit_limit_grid']=(egate*J*f).sum()/(egate*f).sum()
json.dump(out,open('alloc.json','w'),indent=1); print(json.dumps(out,indent=1))
