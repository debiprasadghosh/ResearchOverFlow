import sympy as sp, json
out={}
a,b,eta,s,v,D=sp.symbols('a b eta s v D',positive=True)
# --- Prop 1 / eq (6)
vt=(1-b)*(1-a/b)/(1-a); sig2=eta**2*vt; c2=1-b-sig2
out['eq6_forms_equal']=bool(sp.simplify(c2*s+sig2-((1-b)*s+sig2*(1-s)))==0)
# second-moment expansion with random residual eps (mean mu, var v per coordinate) and xi
mu=sp.symbols('mu',real=True)
s_expr=v+mu**2
out['centered_minus_second']=str(sp.factor((c2*s_expr+sig2)-(c2*v+sig2)))   # = c^2 mu^2
ex={a:sp.Rational(3,10),b:sp.Rational(3,5)}
rows={}
for name,e2 in [('0',0),('0.5',sp.Rational(1,4)),('1',1),('1.4cap',None)]:
    sg=sig2.subs(ex).subs(eta,1)*(e2 if e2 is not None else 0)
    if e2 is None: sg=sp.Min(sp.Rational(196,100)*vt.subs(ex),sp.Rational(999,1000)**2*(1-ex[b]))
    cc=1-ex[b]-sg; sv=sp.Rational(56,100); vv=sp.Rational(4,10)
    rows[name]=dict(sigma2=str(sp.nsimplify(sg)),second=str(sp.nsimplify(cc*sv+sg)),second_f=float(cc*sv+sg),centered=str(sp.nsimplify(cc*vv+sg)),centered_f=float(cc*vv+sg))
out['eq6_table']=rows
# --- Prop 2 / eq (8),(9)
x=sp.Matrix(sp.symbols('x1:4',real=True)); y=sp.Matrix(sp.symbols('y1:4',real=True))
H=lambda p,q: -((p-sp.sqrt(a)*q).dot(p-sp.sqrt(a)*q))/(2*(1-a))
out['eq8_log_ratio']=bool(sp.simplify(H(x,y)-H(y,x)-(y.dot(y)-x.dot(x))/2)==0)
out['eq9_diag']=bool(sp.simplify(H(y,y)+(1-sp.sqrt(a))/(2*(1+sp.sqrt(a)))*y.dot(y))==0)
# --- Theorem 2 / eq (11): grouping, symbolic over 3 members
w=sp.symbols('w1:4',positive=True); vv_=sp.symbols('v1:4',real=True); Hk=sp.symbols('Hk',positive=True)
wG=sum(w); vG=sum(wi*vi for wi,vi in zip(w,vv_))/wG
out['eq11_num']=bool(sp.simplify(Hk*wG*vG-sum(Hk*wi*vi for wi,vi in zip(w,vv_)))==0)
# --- (12) sharpness: scalar case, perturbations of the worst sign attain the bound
N,Z,eN,eZ=sp.symbols('N Z epsN epsZ',positive=True)
mt=(N+eN)/(Z-eZ); m=N/Z
out['eq12_attained']=bool(sp.simplify((mt-m)-(eN+m*eZ)/(Z-eZ))==0)
# --- Prop 5 / eq (15): Bernoulli inclusion
X,e=sp.symbols('X e',positive=True)
EH=e*X/e; EH2=e*(X/e)**2
out['eq15_conditional_var']=str(sp.simplify(EH2-EH**2))
out['eq15_example']=str((EH2-EH**2).subs({X:1,e:sp.Rational(1,4)}))
# --- optimal inclusion: minimize G^2/e + zeta e
G,z=sp.symbols('G zeta',positive=True)
sol=sp.solve(sp.diff(G**2/e+z*e,e),e)
out['oracle_stationary']=str(sol)
# --- (17) bounds for the audit: alpha0=1/4, e0=1/4, beta=1/2
al,e0,be=sp.Rational(1,4),sp.Rational(1,4),sp.Rational(1,2)
out['eq17_V']=str(1/(al*e0)); out['eq17_VJ']=str(sp.N(1/(al*e0*sp.E*be),12)); out['W_bound']=str(1/al)
# --- Audit target: nu=N(0,I2), J=|y|^2, beta=1/2 -> N(0,I/2), E J = 1
t=sp.symbols('t',real=True)
gauss=sp.exp(-t**2)/sp.sqrt(sp.pi)      # density of N(0,1/2)
EJ=2*sp.integrate(t**2*gauss,(t,-sp.oo,sp.oo)); out['audit_EJ']=str(sp.simplify(EJ))
# --- exact limit of the estimator that omits inclusion correction:
#     it targets e(y) f(y) with e = 1 if |y1|>1 else 1/4
P_out=sp.simplify(2*sp.integrate(gauss,(t,1,sp.oo)))
M_out=sp.simplify(2*sp.integrate(t**2*gauss,(t,1,sp.oo)))
E1=sp.Rational(1,2)
num=sp.Rational(1,4)*E1+sp.Rational(3,4)*M_out; den=sp.Rational(1,4)+sp.Rational(3,4)*P_out
lim=sp.simplify(num/den+sp.Rational(1,2))
out['omit_limit_closed']=str(lim); out['omit_limit']=str(sp.N(lim,15))
out['P_abs_y1_gt_1_target']=str(sp.N(P_out,15)); out['M_out']=str(sp.simplify(M_out))
# observation rate under target and under nu for reference
out['obs_rate_target']=str(sp.N(sp.Rational(1,4)+sp.Rational(3,4)*P_out,12))
out['obs_rate_nu']=str(sp.N(sp.Rational(1,4)+sp.Rational(3,4)*sp.erfc(1/sp.sqrt(2)),12))
# --- budget overshoot of the no-op stop: calls with B budget, n0 prompts, T stages
def calls_noop(B,n0,T):
    c=n0
    while c<B: c+=T          # candidate continues after exhaustion
    return c
def calls_strict(B,n0,T): return max(n0,B)
mx=0
for T in range(1,33):
    for n0 in range(0,20):
        for B in range(n0,n0+5*T+1):
            ov=calls_noop(B,n0,T)-B; mx=max(mx,ov-(T-1))
            assert ov==((T-(B-n0)%T)%T)
out['overshoot_formula_checked']=True; out['overshoot_max_minus_Tm1']=mx
out['overshoot_example_B19']=calls_noop(19,8,4)-19
# --- resource formulas
n0_,R_,T_=64,1536,16
out['visits']=R_*n0_+R_*(R_-1)//2; out['kernel_evals']=T_*(n0_+R_)**2; out['ratio']=float(sp.Rational(out['kernel_evals'],out['visits']))
out['payload']=[8*1600*(2+4)+1600, 8*1600*16]
json.dump(out,open('sym.json','w'),indent=1); print(json.dumps(out,indent=1))
