import json, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans'})
BLUE='#2a5b84'; BROWN='#a0602a'; GREY='#c3c9ce'; DARK='#555555'
R=json.load(open('../cs/results.json')); A=json.load(open('../num/alloc.json')); S=json.load(open('../num/sym.json'))
reps=json.load(open('../cs/audit_replicates.json'))
# Figure 2
fig,ax=plt.subplots(1,2,figsize=(6.7,2.7))
occ=R['occupancy']; eq=R['occupancyEqualNorm']; x=np.arange(3); w=0.26
ax[0].bar(x-w,[o['CertifiedFloatRelErrBound'] for o in occ],w,color=BLUE,label='Recurrence (7), certified bound')
ax[0].bar(x,[o['TransposedErrLower'] for o in occ],w,color=BROWN,label='Transposed update, certified error')
ax[0].bar(x+w,[o['TransposedErrUpper'] for o in eq],w,color=GREY,label='Transposed, equal norms, bound')
ax[0].set_yscale('log'); ax[0].set_xticks(x,[f"{o['A']:g}" for o in occ]); ax[0].set_xlabel('Signal level $a$'); ax[0].set_ylabel('Max relative error vs exact sum')
ax[0].set_ylim(1e-15,1e9); ax[0].legend(fontsize=6.8,frameon=False,loc='upper center',ncol=1)
c=[r['Corrected'] for r in reps]; o=[r['Omitted'] for r in reps]; m=[r['Complete'] for r in reps]
bins=np.linspace(0.98,1.45,95)
ax[1].hist(m,bins=bins,color=GREY,label='Complete responses'); ax[1].hist(c,bins=bins,color=BLUE,alpha=0.85,label='Inclusion corrected'); ax[1].hist(o,bins=bins,color=BROWN,alpha=0.85,label='Inclusion omitted')
ax[1].axvline(1,color='black',ls='--',lw=1); ax[1].axvline(float(S['omit_limit']),color='black',ls=':',lw=1)
ax[1].text(1.0,ax[1].get_ylim()[1]*0.92,' exact 1',fontsize=7); ax[1].text(float(S['omit_limit']),ax[1].get_ylim()[1]*0.92,' limit 1.42303 ',fontsize=7,ha='right')
ax[1].set_xlabel('Estimated mean loss (200 seeds)'); ax[1].set_ylabel('Seeds'); ax[1].legend(fontsize=6.8,frameon=False,loc='center')
plt.tight_layout(); plt.savefig('fig2.png',dpi=300); plt.close()
# Figure 3
h=0.02; g=np.arange(-3+h/2,3,h); Y1,Y2=np.meshgrid(g,g,indexing='ij'); J=Y1**2+Y2**2
phi=np.exp(-J/2)/(2*np.pi); s2=0.35**2; gq=np.exp(-J/(2*s2))/(2*np.pi*s2); p=0.75*gq+0.25*phi; W=np.exp(-J/2)*phi/p; G=W*(J-1)
e=np.clip(A['gamma_0.25']*np.abs(G),0.25,1)
fig,ax=plt.subplots(1,2,figsize=(6.7,2.8),gridspec_kw={'width_ratios':[1,1.25]})
im=ax[0].imshow(e.T,origin='lower',extent=[-3,3,-3,3],cmap='Blues',vmin=0.2,vmax=1); cb=fig.colorbar(im,ax=ax[0],fraction=0.046,pad=0.04); cb.set_label('Oracle $e^*(y)$',fontsize=8)
for v in (-1,1): ax[0].axvline(v,color=BROWN,lw=1)
ax[0].contour(g,g,J.T,[1],colors='black',linewidths=0.6,linestyles=':')
ax[0].set_xlabel('$y_1$'); ax[0].set_ylabel('$y_2$'); ax[0].set_aspect('equal'); ax[0].spines[['top','right']].set_visible(True)
names=['complete','gate','uniform','oracle_0.25','oracle_0.05']; lab=['Every\nattempt','Gate\n(Sec. 8.3)','Uniform','Oracle\nfloor 0.25','Oracle\nfloor 0.05']
meas={r['Name']:r for r in R['allocation']}; xx=np.arange(5)
ax[1].bar(xx-0.18,[A[n]['sd_1e5'] for n in names],0.36,color=GREY,label='Predicted from variance integral')
ax[1].bar(xx+0.18,[meas[n]['Sd'] for n in names],0.36,color=BLUE,label='Measured, 200 C# seeds')
ax[1].set_xticks(xx,lab,fontsize=6.8); ax[1].set_ylabel('SD of estimate, $n=10^5$'); ax[1].legend(fontsize=7,frameon=False,loc='upper left'); ax[1].set_ylim(0,0.0085)
plt.tight_layout(); plt.savefig('fig3.png',dpi=300); plt.close()
