using System.Diagnostics;
using System.Text.Json;
using CtrIntervals;

var results = new Dictionary<string, object>();
var sw = Stopwatch.StartNew();

// 1. Occupancy caches: 205 three-dimensional points, 5 initial and 200 appended
var Y = Occupancy.Points(20261029, 205, 3);
results["occupancy"] = new[] { 0.146, 0.5, 0.916 }.Select(a => Occupancy.Run(Y, 5, a)).ToList();
var S = Occupancy.Sphere(20261029, 205, 3, 1.3);
results["occupancyEqualNorm"] = new[] { 0.146, 0.5, 0.916 }.Select(a => Occupancy.Run(S, 5, a)).ToList();
results["balance"] = new[] { 0.146, 0.5, 0.916 }.Select(a => Occupancy.DetailedBalance(Y, a, 400, 7)).ToList();
Console.WriteLine(JsonSerializer.Serialize(results["occupancy"])); Console.WriteLine(JsonSerializer.Serialize(results["occupancyEqualNorm"]));
Console.WriteLine(JsonSerializer.Serialize(results["balance"])); Console.WriteLine($"{sw.Elapsed.TotalSeconds:F1}s");

// 2. Certified Gibbs quadrature for the scaled Himmelblau target
var gibbs = new List<object>();
foreach (double beta in new[] { 0.05, 0.1, 0.4 })
{
    var t = Stopwatch.StartNew(); var (r, _) = Gibbs.Run(beta, 1e-6);
    gibbs.Add(new { beta, Zlo = r.Z.Lo, Zhi = r.Z.Hi, meanLo = r.MeanLoss.Lo, meanHi = r.MeanLoss.Hi, r.Boxes, seconds = t.Elapsed.TotalSeconds });
    Console.WriteLine($"beta={beta} E[J]=[{r.MeanLoss.Lo:R},{r.MeanLoss.Hi:R}] {t.Elapsed.TotalSeconds:F1}s");
}
results["gibbs"] = gibbs;

// 3. Selective-evaluation audit: seed 20261029 and seeds 1..200
results["audit"] = Audit.Run(20261029);
Console.WriteLine(JsonSerializer.Serialize(results["audit"]));
var reps = new Audit.Result[200];
Parallel.For(0, 200, k => reps[k] = Audit.Run(k + 1));
double M(Func<Audit.Result, double> f) => reps.Average(f);
double Sd(Func<Audit.Result, double> f) { double m = M(f); return Math.Sqrt(reps.Sum(r => (f(r) - m) * (f(r) - m)) / (reps.Length - 1)); }
results["auditReplication"] = new
{
    seeds = reps.Length, corrMean = M(r => r.Corrected), corrSd = Sd(r => r.Corrected),
    omitMean = M(r => r.Omitted), omitSd = Sd(r => r.Omitted), compMean = M(r => r.Complete), compSd = Sd(r => r.Complete),
    obsMean = M(r => r.Observed), obsSd = Sd(r => r.Observed), essMin = reps.Min(r => r.Ess), essMax = reps.Max(r => r.Ess),
    maxW = reps.Max(r => r.MaxW), maxV = reps.Max(r => r.MaxV), maxVJ = reps.Max(r => r.MaxVJ), allBounds = reps.All(r => r.BoundsHold),
    within2Sd = reps.Count(r => Math.Abs(r.Corrected - 1.0) <= 2 * Sd(q => q.Corrected))
};
Console.WriteLine(JsonSerializer.Serialize(results["auditReplication"]));
File.WriteAllText("audit_replicates.json", JsonSerializer.Serialize(reps));

// 4. Inclusion rules under a fixed proposal (parameters from the grid computation in alloc.json)
var al = JsonDocument.Parse(File.ReadAllText(args.Length > 0 ? args[0] : "../num/alloc.json")).RootElement;
double rho = al.GetProperty("rho_gate").GetDouble();
var rules = new[]
{
    new Allocation.Rule("complete", 0, 0, 1), new Allocation.Rule("gate", 0, 0, 0), new Allocation.Rule("uniform", 0, 0, rho),
    new Allocation.Rule("oracle_0.25", al.GetProperty("gamma_0.25").GetDouble(), 0.25, 0),
    new Allocation.Rule("oracle_0.05", al.GetProperty("gamma_0.05").GetDouble(), 0.05, 0)
};
results["allocation"] = rules.Select(r => { var x = Allocation.Run(r, 200, 100_000); Console.WriteLine(x); return x; }).ToList();
results["runtime"] = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription;
results["seconds"] = sw.Elapsed.TotalSeconds;
File.WriteAllText("results.json", JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine("written");
