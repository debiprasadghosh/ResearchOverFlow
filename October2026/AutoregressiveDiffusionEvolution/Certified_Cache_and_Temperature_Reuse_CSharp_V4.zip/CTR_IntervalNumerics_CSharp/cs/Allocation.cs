namespace CtrIntervals;

/// <summary>Monte Carlo check of the asymptotic variance of five inclusion rules under the fixed proposal
/// 0.75 N(0, 0.35^2 I) + 0.25 N(0, I). The oracle rule uses the hidden G = W (J - 1) and is a design benchmark only.</summary>
public static class Allocation
{
    public sealed record Rule(string Name, double Gamma, double Floor, double Uniform);
    public sealed record Result(string Name, int Seeds, double Mean, double Sd, double MeanObservedFraction);
    const double Log2Pi = 1.8378770664093453;

    public static double Estimate(Rule r, int seed, int n, out double frac)
    {
        var rnd = new Random(seed); double N() => Math.Sqrt(-2 * Math.Log(1 - rnd.NextDouble())) * Math.Cos(2 * Math.PI * rnd.NextDouble());
        const double s = 0.35, alpha = 0.25, beta = 0.5; double sw = 0, swj = 0; int obs = 0;
        for (int i = 0; i < n; i++)
        {
            double y1, y2;
            if (rnd.NextDouble() < alpha) { y1 = N(); y2 = N(); } else { y1 = s * N(); y2 = s * N(); }
            double J = y1 * y1 + y2 * y2;
            double phi = Math.Exp(-Log2Pi - 0.5 * J), g = Math.Exp(-Log2Pi - 2 * Math.Log(s) - 0.5 * J / (s * s));
            double W = Math.Exp(-beta * J) * phi / (alpha * phi + (1 - alpha) * g);
            double e = r.Name switch
            {
                "complete" => 1.0,
                "gate" => Math.Abs(y1) > 1 ? 1.0 : 0.25,
                "uniform" => r.Uniform,
                _ => Math.Clamp(r.Gamma * Math.Abs(W * (J - 1)), r.Floor, 1.0)
            };
            if (rnd.NextDouble() < e) { obs++; double v = W / e; sw += v; swj += v * J; }
        }
        frac = (double)obs / n; return swj / sw;
    }

    public static Result Run(Rule r, int seeds, int n)
    {
        var est = new double[seeds]; double fr = 0;
        Parallel.For(0, seeds, k => { est[k] = Estimate(r, 1000 + k, n, out double f); lock (est) fr += f; });
        double m = est.Average(), sd = Math.Sqrt(est.Sum(t => (t - m) * (t - m)) / (seeds - 1));
        return new(r.Name, seeds, m, sd, fr / seeds);
    }
}
