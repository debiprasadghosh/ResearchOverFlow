namespace CtrIntervals;

/// <summary>Selective-evaluation audit of Section 8.3 with interval-certified bounds (17).</summary>
public static class Audit
{
    public sealed record Result(int Attempts, int Observed, double Corrected, double Omitted, double Complete, double Ess,
        double MaxW, double MaxV, double MaxVJ, bool BoundsHold);

    static double LogAddExp(double p, double q) { double m = Math.Max(p, q); return m + Math.Log(Math.Exp(p - m) + Math.Exp(q - m)); }
    const double Log2Pi = 1.8378770664093453;

    /// <summary>Adaptive run: mean update mu <- 0.9 mu + 0.02 tanh(Y) after each draw.</summary>
    public static Result Run(int seed, int n = 100_000, double beta = 0.5, double alpha = 0.25, double s = 0.35)
    {
        var rnd = new Random(seed); double N() => Math.Sqrt(-2 * Math.Log(1 - rnd.NextDouble())) * Math.Cos(2 * Math.PI * rnd.NextDouble());
        double m1 = 0.8, m2 = -0.8;
        var lw = new double[n]; var le = new double[n]; var J = new double[n]; var obs = new bool[n];
        int observed = 0; double maxW = 0, maxV = 0, maxVJ = 0; bool ok = true;
        double bV = 1 / (alpha * 0.25), bVJ = 1 / (alpha * 0.25 * Math.E * beta), bW = 1 / alpha;
        for (int i = 0; i < n; i++)
        {
            double y1, y2;
            if (rnd.NextDouble() < alpha) { y1 = N(); y2 = N(); } else { y1 = m1 + s * N(); y2 = m2 + s * N(); }
            double lp = -Log2Pi - 0.5 * (y1 * y1 + y2 * y2);
            double lg = -Log2Pi - Math.Log(s * s) - 0.5 * ((y1 - m1) * (y1 - m1) + (y2 - m2) * (y2 - m2)) / (s * s);
            double lq = LogAddExp(Math.Log(alpha) + lp, Math.Log(1 - alpha) + lg);
            double e = Math.Abs(y1) > 1 ? 1.0 : 0.25;
            obs[i] = rnd.NextDouble() < e; if (obs[i]) observed++;
            J[i] = y1 * y1 + y2 * y2; lw[i] = -beta * J[i] + lp - lq; le[i] = Math.Log(e);
            // Certified checks of (17) for the recorded log weights
            Iv W = Iv.Point(lw[i]).Exp(), V = Iv.Point(lw[i] - le[i]).Exp();
            maxW = Math.Max(maxW, W.Hi);
            if (obs[i]) { maxV = Math.Max(maxV, V.Hi); maxVJ = Math.Max(maxVJ, (V * Iv.Point(J[i])).Hi); ok &= V.Hi <= bV && (V * Iv.Point(J[i])).Hi <= bVJ; }
            ok &= W.Hi <= bW;
            m1 = 0.9 * m1 + 0.02 * Math.Tanh(y1); m2 = 0.9 * m2 + 0.02 * Math.Tanh(y2);
        }
        double Est(Func<int, bool> use, Func<int, double> logw, out double ess)
        {
            double mx = double.NegativeInfinity; for (int i = 0; i < n; i++) if (use(i)) mx = Math.Max(mx, logw(i));
            double sw = 0, sw2 = 0, swj = 0;
            for (int i = 0; i < n; i++) if (use(i)) { double w = Math.Exp(logw(i) - mx); sw += w; sw2 += w * w; swj += w * J[i]; }
            ess = sw * sw / sw2; return swj / sw;
        }
        double corr = Est(i => obs[i], i => lw[i] - le[i], out double ess);
        double omit = Est(i => obs[i], i => lw[i], out _);
        double comp = Est(_ => true, i => lw[i], out _);
        return new(n, observed, corr, omit, comp, ess, maxW, maxV, maxVJ, ok);
    }
}
