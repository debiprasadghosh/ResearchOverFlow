namespace CtrIntervals;

/// <summary>Validated occupancy caches u_j = sum_i H_a(y_j, y_i) for the unnormalised kernel (2).
/// The first kernel argument is always the query.</summary>
public static class Occupancy
{
    public sealed record Row(double A, int Points, double FloatRelErr, double CertifiedFloatRelErrBound,
        double MaxEnclosureRelWidth, bool AllOverlap, double TransposedErrLower, double TransposedErrUpper, int TransposedCertifiedWrong);

    public static Iv LogH(double[] x, double[] y, double a)
    {
        Iv sa = Iv.Point(a).Sqrt(), sq = Iv.Point(0);
        for (int k = 0; k < x.Length; k++) sq += (Iv.Point(x[k]) - sa * Iv.Point(y[k])).Sqr();
        return -(sq / (2.0 * (1.0 - Iv.Point(a))));
    }
    public static Iv H(double[] x, double[] y, double a) => LogH(x, y, a).Exp();
    static double Hf(double[] x, double[] y, double a)
    {
        double s = 0, r = Math.Sqrt(a); for (int k = 0; k < x.Length; k++) { double t = x[k] - r * y[k]; s += t * t; }
        return Math.Exp(-s / (2 * (1 - a)));
    }

    public static double[][] Points(int seed, int n, int d)
    {
        var rnd = new Random(seed); double N() => Math.Sqrt(-2 * Math.Log(1 - rnd.NextDouble())) * Math.Cos(2 * Math.PI * rnd.NextDouble());
        return Enumerable.Range(0, n).Select(_ => Enumerable.Range(0, d).Select(_ => N()).ToArray()).ToArray();
    }

    /// <summary>Recurrence (7) in interval and float arithmetic, a transposed update, and fresh batch sums.</summary>
    public static Row Run(double[][] Y, int init, double a)
    {
        int n = Y.Length;
        var U = new List<Iv>(); var Uf = new List<double>(); var Ut = new List<Iv>();
        for (int j = 0; j < init; j++)
        {
            Iv s = Iv.Point(0); double sf = 0;
            for (int i = 0; i < init; i++) { s += H(Y[j], Y[i], a); sf += Hf(Y[j], Y[i], a); }
            U.Add(s); Uf.Add(sf); Ut.Add(s);
        }
        for (int m = init; m < n; m++)
        {
            var x = Y[m];
            for (int j = 0; j < m; j++)
            {
                U[j] += H(Y[j], x, a); Uf[j] += Hf(Y[j], x, a);
                Ut[j] += H(x, Y[j], a);                                // wrong argument order
            }
            Iv s = Iv.Point(0), st = Iv.Point(0); double sf = 0;
            for (int i = 0; i <= m; i++) { s += H(x, Y[i], a); sf += Hf(x, Y[i], a); st += H(Y[i], x, a); }
            U.Add(s); Uf.Add(sf); Ut.Add(st);
        }
        double relErr = 0, relBound = 0, relW = 0, tLo = 0, tHi = 0; bool overlap = true; int wrong = 0;
        for (int j = 0; j < n; j++)
        {
            Iv batch = Iv.Point(0); double bf = 0;
            for (int i = 0; i < n; i++) { batch += H(Y[j], Y[i], a); bf += Hf(Y[j], Y[i], a); }
            overlap &= batch.Overlaps(U[j]);
            relErr = Math.Max(relErr, Math.Abs(Uf[j] - bf) / bf);
            relBound = Math.Max(relBound, Math.Max(Math.Abs(Uf[j] - batch.Lo), Math.Abs(batch.Hi - Uf[j])) / batch.Lo);
            relW = Math.Max(relW, U[j].Width / U[j].Lo);
            // Certified bounds on |transposed - exact| / exact
            double lo = Math.Max(0, Math.Max(Ut[j].Lo - batch.Hi, batch.Lo - Ut[j].Hi)) / batch.Hi;
            double hi = Math.Max(Math.Abs(Ut[j].Hi - batch.Lo), Math.Abs(batch.Hi - Ut[j].Lo)) / batch.Lo;
            if (lo > 0) wrong++;
            tLo = Math.Max(tLo, lo); tHi = Math.Max(tHi, hi);
        }
        return new(a, n, relErr, relBound, relW, overlap, tLo, tHi, wrong);
    }

    /// <summary>Equal-norm control: points on a sphere make the transposed update exact.</summary>
    public static double[][] Sphere(int seed, int n, int d, double radius)
        => Points(seed, n, d).Select(p => { double r = Math.Sqrt(p.Sum(t => t * t)); return p.Select(t => radius * t / r).ToArray(); }).ToArray();

    public sealed record Balance(int Pairs, double MaxWidth, bool AllContainZero, double DiagMaxWidth, bool DiagContainsZero);

    /// <summary>Encloses log H(x,y) - log H(y,x) - (|y|^2 - |x|^2)/2 and the diagonal identity (9).</summary>
    public static Balance DetailedBalance(double[][] Y, double a, int pairs, int seed)
    {
        var rnd = new Random(seed); double mw = 0, dw = 0; bool ok = true, dok = true;
        for (int p = 0; p < pairs; p++)
        {
            var x = Y[rnd.Next(Y.Length)]; var y = Y[rnd.Next(Y.Length)];
            Iv nx = Iv.Point(0), ny = Iv.Point(0); for (int k = 0; k < x.Length; k++) { nx += Iv.Point(x[k]).Sqr(); ny += Iv.Point(y[k]).Sqr(); }
            Iv r = LogH(x, y, a) - LogH(y, x, a) - (ny - nx) / 2.0;
            mw = Math.Max(mw, r.Width); ok &= r.Lo <= 0 && r.Hi >= 0;
            Iv sa = Iv.Point(a).Sqrt();
            Iv dd = LogH(y, y, a) + (1.0 - sa) / (2.0 * (1.0 + sa)) * ny;
            dw = Math.Max(dw, dd.Width); dok &= dd.Lo <= 0 && dd.Hi >= 0;
        }
        return new(pairs, mw, ok, dw, dok);
    }
}
