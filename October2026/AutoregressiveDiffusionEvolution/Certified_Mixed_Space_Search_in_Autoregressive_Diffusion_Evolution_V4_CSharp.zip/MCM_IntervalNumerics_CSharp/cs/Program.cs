using System.Text.Json;
using System.Text.Json.Serialization;
using McmIntervals;

var sw = System.Diagnostics.Stopwatch.StartNew();
var res = new Dictionary<string, object>();
void Log(string k, object v) { res[k] = v; Console.WriteLine($"{k}: {JsonSerializer.Serialize(v)}"); }
Log("constants", Constants.All());
Log("fronts", new[] { 1, 2, 3, 4, 8, 16, 32, 64, 128, 256 }.Select(Fronts.Run).ToList());
Log("band", new[] { 0.25, 0.2, 0.1, 0.05, 0.02, 0.01 }.Select(d => Band.At(d, 1 << 21)).ToList());
Log("band_ratio_fine", new[] { 0.25, 0.1, 0.05, 0.02, 0.01, 0.001, 1e-4 }.Select(d => { var r = Band.Mass(Iv.Point(-1), Iv.Point(d)) / Band.Mass(Iv.Point(1), Iv.Point(d)); return new { delta = d, ratio = new[] { r.Lo, r.Hi } }; }).ToList());
Log("codim", new[] { 0.5, 0.1, 1e-2, 1e-3, 1e-4, 1e-6 }.Select(Codim.At).ToList());
Log("vessel", Vessel.Run());
Log("sampling", Sampling.Run(100_000, 200, 20261102UL));
res["runtime"] = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription;
res["seconds"] = sw.Elapsed.TotalSeconds;
var opt = new JsonSerializerOptions { WriteIndented = true, NumberHandling = JsonNumberHandling.AllowNamedFloatingPointLiterals };
File.WriteAllText("results.json", JsonSerializer.Serialize(res, opt));
Console.WriteLine($"done {sw.Elapsed.TotalSeconds:F1} s");
