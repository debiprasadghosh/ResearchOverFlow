namespace McmIntervals;

/// <summary>Seeded diagnostic of Theorem 6 on worked example 1. Draw i uses the defensive mixture
/// q_i = eps phi + (1 - eps) N(mu_i, sigma_i^2), with (mu_i, sigma_i) refitted every 1000 draws from past weighted draws,
/// so q_i is F_{i-1}-measurable and q_i &gt;= eps p. Estimates use the actual mixture density of each draw.</summary>
public static class Sampling
{
    const double P0 = 0.3, Eps = 0.1;
    static readonly double B = Normal.Quantile(Iv.Point(0.3)).Mid;
    static double Phi(double z) => Normal.Cdf(z).Mid;
    static double Pdf(double z) => Math.Exp(-0.5 * z * z) / Math.Sqrt(2 * Math.PI);
    static double Decode(double z) => z <= B ? 0 : 1 + 2 * (Phi(z) - P0) / (1 - P0);
    static double W(double x) { double j = (x - 2.2) * (x - 2.2) + (x != 0 ? 0.5 : 0); return Math.Exp(-2 * j); }
    public sealed record Rep(double Atom, double Mean, double EliteAtom, double EliteMean, double PriorAtom, double PriorMean, double MaxWeight);
    static Rep One(int n, ulong seed)
    {
        var r = new SplitMix(seed); double mu = 0, sig = 1;
        var z = new double[n]; var a = new double[n]; var x = new double[n];
        double sA = 0, sAH = 0, sAX = 0, sMu = 0, sMu2 = 0, maxA = 0;
        for (int i = 0; i < n; i++)
        {
            if (i > 0 && i % 1000 == 0 && sA > 0) { mu = sMu / sA; sig = Math.Clamp(Math.Sqrt(Math.Max(sMu2 / sA - mu * mu, 0)), 0.05, 3); }
            double zi = r.U() < Eps ? r.Normal() : mu + sig * r.Normal();
            double q = Eps * Pdf(zi) + (1 - Eps) * Pdf((zi - mu) / sig) / sig;
            double xi = Decode(zi); double ai = Pdf(zi) * W(xi) / q;
            z[i] = zi; a[i] = ai; x[i] = xi; maxA = Math.Max(maxA, ai);
            sA += ai; sAH += zi <= B ? ai : 0; sAX += ai * xi; sMu += ai * zi; sMu2 += ai * zi * zi;
        }
        // elite records: the 1% with the largest raw weights, self-normalised (a selection, not the draw stream of Theorem 6)
        var idx = Enumerable.Range(0, n).OrderByDescending(i => a[i]).Take(n / 100).ToArray();
        double eA = idx.Sum(i => a[i]), eH = idx.Sum(i => z[i] <= B ? a[i] : 0), eX = idx.Sum(i => a[i] * x[i]);
        // non-adaptive prior proposal with the same budget
        var r2 = new SplitMix(seed ^ 0x5DEECE66DUL); double pA = 0, pH = 0, pX = 0;
        for (int i = 0; i < n; i++) { double zi = r2.Normal(), xi = Decode(zi), wi = W(xi); pA += wi; pH += zi <= B ? wi : 0; pX += wi * xi; }
        return new Rep(sAH / sA, sAX / sA, eH / eA, eX / eA, pH / pA, pX / pA, maxA);
    }
    public sealed record Result(int N, int Reps, double B, double MeanAtom, double SdAtom, double MeanMean, double SdMean, double EliteAtom, double EliteMean,
        double PriorSdAtom, double PriorSdMean, double MaxWeight, double[] AtomEst, double[] MeanEst);
    public static Result Run(int n, int reps, ulong seed)
    {
        var rs = new Rep[reps];
        Parallel.For(0, reps, k => rs[k] = One(n, seed + (ulong)k * 7919UL));
        double M(Func<Rep, double> f) => rs.Average(f);
        double S(Func<Rep, double> f) { double m = M(f); return Math.Sqrt(rs.Sum(x => (f(x) - m) * (f(x) - m)) / (reps - 1)); }
        return new Result(n, reps, B, M(x => x.Atom), S(x => x.Atom), M(x => x.Mean), S(x => x.Mean), M(x => x.EliteAtom), M(x => x.EliteMean),
            S(x => x.PriorAtom), S(x => x.PriorMean), rs.Max(x => x.MaxWeight), rs.Select(x => x.Atom).ToArray(), rs.Select(x => x.Mean).ToArray());
    }
}
