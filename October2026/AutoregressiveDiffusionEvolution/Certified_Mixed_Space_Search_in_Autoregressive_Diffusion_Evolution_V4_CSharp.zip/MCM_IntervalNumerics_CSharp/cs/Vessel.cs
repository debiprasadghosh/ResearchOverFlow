namespace McmIntervals;

/// <summary>Propositions 11.1 and 11.2: interval certificate for the mixed pressure vessel (16)-(17).
/// For each gauge pair the reduced cost f(r) = A/r + B r^2 + C/r^2 + D r on [r200, min(cap, r10)] is minimised by interval
/// branch-and-bound with a mean-value form and monotonicity tests. Every decimal coefficient is an exact rational enclosed outward;
/// pi is enclosed by the two doubles adjacent to Math.PI.</summary>
public static class Vessel
{
    static Iv Dq(long n, long d) => Q.Of(n, d).Enclose();
    static readonly Iv C1 = Dq(6224, 10000), C2 = Dq(17781, 10000), C3 = Dq(31661, 10000), C4 = Dq(1984, 100);
    static readonly Iv V = Iv.Point(1296000), VP = V / Normal.Pi;
    static readonly Iv FourThirds = 4.0 / Iv.Point(3);
    /// <summary>Root of pi (L r^2 + 4 r^3/3) = V by interval Newton (the left side increases in r &gt; 0).</summary>
    public static Iv RadiusAtLength(double L, double lo, double hi)
    {
        Iv Fn(Iv r) => Normal.Pi * (L * r.Sqr() + FourThirds * r.Sqr() * r) - V;
        Iv dF(Iv r) => Normal.Pi * (2.0 * L * r + 4.0 * r.Sqr());
        var x = new Iv(lo, hi);
        if (Fn(Iv.Point(lo)).Hi >= 0 || Fn(Iv.Point(hi)).Lo <= 0) throw new ArithmeticException("radius not bracketed");
        for (int it = 0; it < 100; it++)
        {
            double m = x.Mid; var y = x.Intersect(Iv.Point(m) - Fn(Iv.Point(m)) / dF(x));
            if (y.Width >= 0.999 * x.Width) { x = y; break; }
            x = y;
        }
        return x;
    }
    public static readonly Iv R200 = RadiusAtLength(200, 40, 41), R10 = RadiusAtLength(10, 65, 66);
    public sealed record Coef(Iv A, Iv B, Iv C, Iv D);
    public static Coef Coeffs(Iv ts, Iv th) => new(C1 * ts * VP, C2 * th - FourThirds * C1 * ts, C3 * ts.Sqr() * VP, (C4 - FourThirds * C3) * ts.Sqr());
    public static Iv F(Coef k, Iv r) => k.A / r + k.B * r.Sqr() + k.C / r.Sqr() + k.D * r;
    public static Iv dF(Coef k, Iv r) => -(k.A / r.Sqr()) + 2.0 * k.B * r - 2.0 * k.C / (r.Sqr() * r) + k.D;
    public static Iv Cost(Iv ts, Iv th, Iv r, Iv l) => C1 * ts * r * l + C2 * th * r.Sqr() + C3 * ts.Sqr() * l + C4 * ts.Sqr() * r;
    public sealed record Pair(int Ks, int Kh, double[] Min, double[] ArgMin, string Where, int Boxes, double Cap);
    /// <summary>Certified minimum of the cost over all feasible designs with gauges (ks, kh), or null when infeasible.</summary>
    public static Pair? Solve(int ks, int kh, double tol = 2e-13)
    {
        var ts = Iv.Point(ks / 16.0); var th = Iv.Point(kh / 16.0);
        var capS = Q.Of(625L * ks, 193).Enclose(); var capH = Q.Of(6250L * kh, 954).Enclose();
        var cap = new Iv(Math.Min(200, Math.Min(capS.Lo, capH.Lo)), Math.Min(200, Math.Min(capS.Hi, capH.Hi)));
        if (cap.Hi < R200.Lo) return null;
        if (cap.Lo <= R200.Hi) throw new ArithmeticException($"undecided feasibility for ({ks},{kh})");
        var k = Coeffs(ts, th);
        double a = R200.Lo, b = Math.Min(cap.Hi, R10.Hi);            // lower-bound domain (a superset of the feasible radii)
        double fa = R200.Hi, fb = Math.Min(cap.Lo, R10.Lo);           // every r in [fa, fb] is feasible with l = l*(r)
        string where = cap.Lo < R10.Lo ? "cap" : "r10";
        double best = double.PositiveInfinity, arg = double.NaN;
        void Try(double r) { r = Math.Clamp(r, fa, fb); var v = F(k, Iv.Point(r)).Hi; if (v < best) { best = v; arg = r; } }
        Try(fa); Try(fb); Try(0.5 * (fa + fb));
        var stack = new Stack<(double lo, double hi)>(); stack.Push((a, b));
        var leaves = new List<(double lo, double hi, double lb)>(); int boxes = 0;
        while (stack.Count > 0)
        {
            var (lo, hi) = stack.Pop(); boxes++; if (boxes > 2_000_000) throw new InvalidOperationException("box limit");
            var R = new Iv(lo, hi); var d = dF(k, R); double lb;
            if (d.Lo > 0) lb = F(k, Iv.Point(lo)).Lo;
            else if (d.Hi < 0) lb = F(k, Iv.Point(hi)).Lo;
            else { double m = R.Mid; var mv = F(k, Iv.Point(m)) + d * (R - m); lb = Math.Max(mv.Lo, F(k, R).Lo); Try(m); }
            if (d.Lo > 0) Try(lo); else if (d.Hi < 0) Try(hi);
            if (lb > best) continue;
            if (best - lb <= tol * Math.Abs(best) || hi - lo < 1e-13 * hi) { leaves.Add((lo, hi, lb)); continue; }
            double mid = 0.5 * (lo + hi); stack.Push((lo, mid)); stack.Push((mid, hi));
        }
        double lower = leaves.Where(x => x.lb <= best).Min(x => x.lb);
        var argBox = leaves.Where(x => x.lb <= best).ToList();
        double alo = argBox.Min(x => x.lo), ahi = argBox.Max(x => x.hi);
        if (Math.Abs(arg - fb) < 1e-9 * fb && ahi >= fb - 1e-9) where = where == "cap" ? "thickness cap" : "length 10"; else if (Math.Abs(arg - fa) < 1e-9 * fa) where = "length 200"; else where = "stationary";
        return new Pair(ks, kh, new[] { lower, best }, new[] { alo, ahi }, where, boxes, cap.Mid);
    }
    public sealed record Summary(double[] R200, double[] R10, int PairsCapAtLeast40, int FeasiblePairs, double[] CStar, double CStarWidth, int TotalBoxes,
        List<Pair> Top, int Within05, int Within1, int Within2, double[] Relaxation, double[] RelaxKappa, double[] Gap, double[] OptLength, double[] OptSlope, Dictionary<string, int> WhereCounts, int SingleBox, int MaxBoxesPerPair, List<double[]> AllPairs, double Seconds);
    public static Summary Run()
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        int cap40 = 0; var pairs = new List<Pair>();
        var all = new List<(int, int)>(); for (int ks = 1; ks <= 99; ks++) for (int kh = 1; kh <= 99; kh++) all.Add((ks, kh));
        var res = new Pair?[all.Count];
        Parallel.For(0, all.Count, i => res[i] = Solve(all[i].Item1, all[i].Item2));
        foreach (var (ks, kh) in all)
        {
            var c = Q.Min(Q.Min(200, Q.Of(625L * ks, 193)), Q.Of(6250L * kh, 954)); if (c >= 40) cap40++;
        }
        pairs.AddRange(res.Where(p => p is not null)!);
        var lo = pairs.Min(p => p.Min[0]); var hi = pairs.Min(p => p.Min[1]);
        var top = pairs.OrderBy(p => p.Min[1]).Take(10).ToList();
        int W(double f) => pairs.Count(p => p.Min[0] <= hi * (1 + f));
        // Proposition 11.2: continuous relaxation, ts = 0.0193 r, th = 0.00954 r, cost = const + kappa r^3 on the volume branch
        var al = Dq(193, 10000); var ga = Dq(954, 100000);
        var kap = C2 * ga + C4 * al.Sqr() - FourThirds * (C1 * al + C3 * al.Sqr());
        var rel = (C1 * al + C3 * al.Sqr()) * VP + kap * R200.Pow(3);
        var relCheck = Cost(al * R200, ga * R200, R200, Iv.Point(200));
        var relI = rel.Intersect(relCheck);
        // optimum pair details: length and slope at the thickness cap of (13, 7)
        var r137 = Q.Of(8125, 193).Enclose(); var k137 = Coeffs(Iv.Point(13 / 16.0), Iv.Point(7 / 16.0));
        var len = VP / r137.Sqr() - FourThirds * r137; var slope = dF(k137, r137);
        var cs = new Iv(lo, hi);
        return new Summary(new[] { R200.Lo, R200.Hi }, new[] { R10.Lo, R10.Hi }, cap40, pairs.Count, new[] { lo, hi }, hi - lo, pairs.Sum(p => p.Boxes), top,
            W(0.005), W(0.01), W(0.02), new[] { relI.Lo, relI.Hi }, new[] { kap.Lo, kap.Hi }, new[] { (cs - relI).Lo, (cs - relI).Hi },
            new[] { len.Lo, len.Hi }, new[] { slope.Lo, slope.Hi }, pairs.GroupBy(p => p.Where).ToDictionary(g => g.Key, g => g.Count()), pairs.Count(p => p.Boxes == 1), pairs.Max(p => p.Boxes),
            pairs.Select(p => new double[] { p.Ks, p.Kh, p.Min[0], p.Min[1], Array.IndexOf(new[] { "thickness cap", "stationary", "length 200", "length 10" }, p.Where) }).ToList(), sw.Elapsed.TotalSeconds);
    }
}
