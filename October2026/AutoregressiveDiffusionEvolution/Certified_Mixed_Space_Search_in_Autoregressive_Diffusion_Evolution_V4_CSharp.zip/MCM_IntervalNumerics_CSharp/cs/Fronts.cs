namespace McmIntervals;

/// <summary>Proposition 8.1: efficient components of x -> (x, g(x)), g(x) = 1 - x + a sin^2(K pi x) on [0, 1].
/// Local minima m_k are isolated by interval Newton on g' with g'' &gt; 0; the crossings c_k with g(c_k) = g(m_{k-1})
/// by bisection with certified signs on the strictly decreasing branch.</summary>
public static class Fronts
{
    static readonly Iv A = Q.Of(3, 10).Enclose();
    static Iv G(Iv x, int k) { var s = ((double)k * Normal.Pi * x).Sin(); return 1.0 - x + A * s.Sqr(); }
    static Iv G1(Iv x, int k) => -1.0 + A * (double)k * Normal.Pi * ((2.0 * k) * Normal.Pi * x).Sin();
    static Iv G2(Iv x, int k) => 2.0 * A * (double)(k * k) * Normal.Pi.Sqr() * ((2.0 * k) * Normal.Pi * x).Cos();
    public sealed record Component(double[] Start, double[] End, bool StartOpen);
    public sealed record Result(int K, double AKPi, int Components, double[] Measure, double ScaledMeasure, List<Component> Parts, double MaxEndpointWidth);

    static Iv Minimum(int k, int K)
    {
        var x = new Iv((double)k / K, (k + 1.2 / (2 * Math.PI)) / K);   // phase 2K pi (x - k/K) in [0, 1.2]
        if (G1(Iv.Point(x.Lo), K).Hi >= 0 || G1(Iv.Point(x.Hi), K).Lo <= 0 || G2(x, K).Lo <= 0) throw new ArithmeticException("minimum not isolated");
        for (int it = 0; it < 80; it++)
        {
            double m = x.Mid; var n = Iv.Point(m) - G1(Iv.Point(m), K) / G2(x, K); var y = x.Intersect(n);
            if (y.IsEmpty) throw new ArithmeticException("empty Newton step");
            if (y.Width >= x.Width) { x = y; break; }
            x = y;
        }
        return x;
    }
    static Iv Crossing(Iv level, double lo, double hi, int K)
    {
        if ((G(Iv.Point(lo), K) - level).Lo <= 0 || (G(Iv.Point(hi), K) - level).Hi >= 0) throw new ArithmeticException("crossing not bracketed");
        for (int it = 0; it < 200; it++)
        {
            double m = 0.5 * (lo + hi); if (m <= lo || m >= hi) break;
            var v = G(Iv.Point(m), K) - level;
            if (v.Lo > 0) lo = m; else if (v.Hi < 0) hi = m; else break;
        }
        return new Iv(lo, hi);
    }
    public static Result Run(int K)
    {
        var akpi = A * (double)K * Normal.Pi;
        var parts = new List<Component>();
        if (akpi.Hi < 1)
        {   // g' <= -1 + a K pi < 0: g strictly decreasing, every point efficient
            parts.Add(new Component(new[] { 0.0, 0.0 }, new[] { 1.0, 1.0 }, false));
            return new Result(K, akpi.Mid, 1, new[] { 1.0, 1.0 }, Math.Sqrt(K) * Math.PI * Math.Sqrt(0.3), parts, 0);
        }
        if (akpi.Lo <= 1) throw new ArithmeticException("borderline a K pi");
        var mins = Enumerable.Range(0, K).Select(k => Minimum(k, K)).ToArray();
        var measure = mins[0] - 0.0; parts.Add(new Component(new[] { 0.0, 0.0 }, new[] { mins[0].Lo, mins[0].Hi }, false));
        double maxW = mins[0].Width;
        for (int k = 1; k <= K; k++)
        {
            var mPrev = mins[k - 1];
            var level = G(mPrev, K);                                   // encloses g(m_{k-1}) since mPrev encloses m_{k-1}
            var top = (2.0 * (k - 1) + 1.0) / (2.0 * K) + 1e-9 / K;    // just past the local maximum (2k-1)/(2K) - x0
            double startHi = (k < K) ? mins[k].Lo : 1.0;
            var c = Crossing(level, top - (mPrev.Hi - (double)(k - 1) / K), startHi, K);
            var end = k < K ? mins[k] : Iv.Point(1);
            parts.Add(new Component(new[] { c.Lo, c.Hi }, new[] { end.Lo, end.Hi }, true));
            measure = measure + (end - c); maxW = Math.Max(maxW, Math.Max(c.Width, end.Width));
        }
        return new Result(K, akpi.Mid, parts.Count, new[] { measure.Lo, measure.Hi }, measure.Mid * Math.Sqrt(K) * Math.PI * Math.Sqrt(0.3), parts, maxW);
    }
}
