namespace McmIntervals;

/// <summary>Validated enclosures of the worked-example constants of Sections 2 to 7. Decimal data enter as exact
/// rationals enclosed outward; Phi uses the validated erf series and continued fraction of Normal.</summary>
public static class Constants
{
    static Iv Dq(long n, long d) => Q.Of(n, d).Enclose();
    public sealed record Item(string Key, double[] Value, double Width);
    static Item It(string k, Iv v) => new(k, new[] { v.Lo, v.Hi }, v.Width);

    /// <summary>Worked example 1: the tilted atom (2) and the tilted design mean.</summary>
    public static (Iv atom, Iv mean, Iv integral) Atom()
    {
        var atomW = Dq(3, 10) * (-Dq(968, 100)).Exp();                                    // 0.3 exp(-2 * 2.2^2)
        var half = Iv.Point(0.5);
        var integral = half * Normal.Sqrt2Pi * (Normal.Cdf(Dq(16, 10)) - Normal.Cdf(-Dq(24, 10)));   // int_1^3 exp(-2 (x-2.2)^2) dx
        var em1 = Iv.Point(-1).Exp();
        var cont = Dq(35, 100) * em1 * integral;
        var z = atomW + cont;
        var first = Dq(22, 10) * integral + ((-Dq(288, 100)).Exp() - (-Dq(128, 100)).Exp()) / 4.0;
        return (atomW / z, Dq(35, 100) * em1 * first / z, integral);
    }
    /// <summary>Selected-coordinate mean m_q = q int z phi(z) Phi(z)^{q-1} dz on [-10, 10]; the omitted tails have
    /// absolute value at most 2 q phi(10).</summary>
    public static Iv ArgmaxMean(int q, int cells = 160, int order = 11)
    {
        var r = TayQuad.Integrate(t => (double)q * (t * t.Pdf() * t.Phi().Pow(q - 1)), -10, 10, cells, order);
        var tail = 2.0 * q * Normal.Pdf(Iv.Point(10)).Hi;
        return new Iv(r.Value[0], r.Value[1]) + new Iv(-tail, tail);
    }
    /// <summary>Modified Bessel function I_nu(1) by its series; terms after k = 20 sum to less than twice the first omitted one.</summary>
    public static Iv BesselI1(int nu)
    {
        var s = Iv.Point(0); var term = Iv.Point(1);
        for (int j = 1; j <= nu; j++) term = term / (2.0 * j);                     // (1/2)^nu / nu!
        for (int k = 0; k <= 20; k++)
        {
            if (k > 0) term = term / (4.0 * k * (k + nu));
            s = s + term;
        }
        var next = term / (4.0 * 21 * (21 + nu));
        return s + new Iv(0, 2.0 * next.Hi);
    }
    public static List<Item> All()
    {
        var res = new List<Item>();
        var (atom, mean, integral) = Atom();
        res.Add(It("tilted_atom", atom)); res.Add(It("tilted_mean_design", mean)); res.Add(It("atom_integral", integral));
        // cross-check of the Gaussian integral by Taylor-model quadrature (independent of the Phi closed form)
        var a = Dq(22, 10);
        var qd = TayQuad.Integrate(t => { var u = t - Tay.Const(a, t.Order); return ((-2.0) * (u * u)).Exp(); }, 1, 3, 32);
        res.Add(new Item("atom_integral_quadrature", qd.Value, qd.Width));
        var b = Iv.Point(0.5); var phi = Normal.Pdf(b); var pPos = Normal.Upper(b); var pNeg = Normal.Cdf(b);
        var mPos = phi / pPos; var mNeg = -(phi / pNeg);
        res.Add(It("rep_positive", mPos)); res.Add(It("rep_negative", mNeg));
        var lhs = 5.0 - 8.0 * phi;
        var rhs = 1.0 - (pNeg * mNeg.Sqr() + pPos * mPos.Sqr()) + (pNeg * (mNeg + 2.0).Sqr() + pPos * (mPos - 2.0).Sqr());
        res.Add(It("risk_lhs", lhs)); res.Add(It("risk_rhs", rhs));
        foreach (int q in new[] { 2, 3, 4, 5, 6, 8, 10, 12, 16 }) res.Add(It($"m_{q}", ArgmaxMean(q)));
        res.Add(It("m_2_exact", 1.0 / Normal.Pi.Sqrt())); res.Add(It("m_3_exact", 1.5 / Normal.Pi.Sqrt()));
        var pi = Normal.Pi;
        res.Add(It("binary_gap", 1.0 - 2.0 / pi));
        var e2 = Iv.Point(2).Exp();
        res.Add(It("binary_tilted_mean", (2.0 / pi).Sqrt() * (e2 - 1.0) / (e2 + 1.0)));
        res.Add(It("nonconvex_mass", 2.0 * Normal.Cdf(Iv.Point(-1))));
        var i0 = BesselI1(0); var i1 = BesselI1(1);
        res.Add(It("I0_1", i0)); res.Add(It("I1_1", i1));
        res.Add(It("density_ratio", e2)); res.Add(It("mean_cos", -(i1 / i0)));
        res.Add(It("limit_density_at_0", (-1.0 * Iv.Point(1)).Exp() / (2.0 * pi * i0)));
        res.Add(It("limit_density_at_pi", Iv.Point(1).Exp() / (2.0 * pi * i0)));
        return res;
    }
}
