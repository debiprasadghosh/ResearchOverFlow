namespace McmIntervals;

/// <summary>Corollary 10.2 illustration under the planar standard normal prior with equal configuration weights:
/// configuration A has the circle residual r^2 - 1 (k = 1), configuration B the point residual (x, y) (k = 2).
/// Since r^2 is exponential with mean 2, P_A = e^{-1/2} (expm1(delta/2) - expm1(-delta/2)) and P_B = -expm1(-delta^2/2).</summary>
public static class Codim
{
    public sealed record Row(double Delta, double[] PA, double[] PB, double[] WeightB, double[] WeightB99, double[] ScaledWeightB);
    public static Row At(double delta)
    {
        var d = Iv.Point(delta); var eh = Iv.Point(-0.5).Exp();
        var pa = eh * ((d / 2.0).Expm1Small() - (-(d / 2.0)).Expm1Small());
        var pb = -((-(d.Sqr()) / 2.0).Expm1Small());
        var wb = pb / (pa + pb); var wb99 = 99.0 * pb / (pa + 99.0 * pb);
        var scaled = wb / (Iv.Point(0.5).Exp() * d / 2.0);       // ratio to the leading prediction e^{1/2} delta / 2 from (15)
        return new Row(delta, new[] { pa.Lo, pa.Hi }, new[] { pb.Lo, pb.Hi }, new[] { wb.Lo, wb.Hi }, new[] { wb99.Lo, wb99.Hi }, new[] { scaled.Lo, scaled.Hi });
    }
}
