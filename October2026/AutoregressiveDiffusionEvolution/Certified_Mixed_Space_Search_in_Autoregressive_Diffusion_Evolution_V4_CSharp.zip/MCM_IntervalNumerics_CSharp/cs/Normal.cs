namespace McmIntervals;

/// <summary>Validated standard normal density and distribution function.
/// |x| &lt;= 3: alternating Taylor series of erf with a next-term remainder.
/// |x| &gt; 3: the Mills ratio R(x) = (1 - Phi(x))/phi(x) lies between successive convergents of Laplace's continued
/// fraction 1/(x + 1/(x + 2/(x + 3/(x + ...)))), a classical property for x &gt; 0.</summary>
public static class Normal
{
    public static readonly Iv Pi = new(Math.BitDecrement(Math.PI), Math.BitIncrement(Math.PI));
    public static readonly Iv Sqrt2Pi = (2.0 * Pi).Sqrt();
    public static readonly Iv Sqrt2 = Iv.Point(2).Sqrt();
    public static Iv Dec(double x) => new(Math.BitDecrement(x), Math.BitIncrement(x));
    public static Iv Pdf(Iv x) => (-(x.Sqr()) / 2.0).Exp() / Sqrt2Pi;
    static Iv ErfSeries(Iv t)
    {
        // erf(t) = 2/sqrt(pi) sum (-1)^n t^(2n+1) / (n! (2n+1)); terms decrease for n > t^2
        var t2 = t.Sqr(); var pow = t; var fact = Iv.Point(1); var s = Iv.Point(0);
        const int N = 70;
        for (int n = 0; n <= N; n++)
        {
            if (n > 0) { pow = pow * t2; fact = fact * (double)n; }
            var term = pow / (fact * (2.0 * n + 1));
            s = (n % 2 == 0) ? s + term : s - term;
        }
        var next = (pow * t2).Abs() / (fact * (double)(N + 1) * (2.0 * (N + 1) + 1));
        s = s + new Iv(-next.Hi, next.Hi);
        return 2.0 * s / Pi.Sqrt();
    }
    /// <summary>Enclosure of the Mills ratio for x &gt;= 3 (x an interval with Lo &gt; 0).</summary>
    public static Iv Mills(Iv x, int n = 60)
    {
        Iv Conv(int k) { var t = x; for (int j = k; j >= 1; j--) t = x + (double)j / t; return 1.0 / t; }
        return Iv.Hull(Conv(n), Conv(n + 1));
    }
    public static Iv Cdf(Iv x)
    {
        if (x.Hi <= 3 && x.Lo >= -3) return (0.5 + 0.5 * ErfSeries(x / Sqrt2)).Max0();
        if (x.Lo > 3) return 1.0 - Pdf(x) * Mills(x);
        if (x.Hi < -3) return Pdf(x) * Mills(-x);
        // straddling intervals: use monotonicity
        return new Iv(Cdf(Iv.Point(x.Lo)).Lo, Cdf(Iv.Point(x.Hi)).Hi);
    }
    public static Iv Cdf(double x) => Cdf(Iv.Point(x));
    /// <summary>Upper tail 1 - Phi(x) without cancellation.</summary>
    public static Iv Upper(Iv x) => x.Lo > 3 ? Pdf(x) * Mills(x) : 1.0 - Cdf(x);
    /// <summary>Quantile enclosure by certified bisection: Phi(lo) &lt; p &lt; Phi(hi).</summary>
    public static Iv Quantile(Iv p, double lo = -10, double hi = 10)
    {
        for (int it = 0; it < 200 && hi - lo > 1e-14 * Math.Max(1, Math.Abs(lo)); it++)
        {
            double mid = 0.5 * (lo + hi); var c = Cdf(mid);
            if (c.Hi < p.Lo) lo = mid; else if (c.Lo > p.Hi) hi = mid;
            else
            {   // undecidable at mid: move outward from mid until each side is decided
                double e = 1e-15 * Math.Max(1, Math.Abs(mid)); double nlo = lo, nhi = hi;
                for (int k = 0; k < 60 && mid - e > lo; k++, e *= 2) if (Cdf(mid - e).Hi < p.Lo) { nlo = mid - e; break; }
                e = 1e-15 * Math.Max(1, Math.Abs(mid));
                for (int k = 0; k < 60 && mid + e < hi; k++, e *= 2) if (Cdf(mid + e).Lo > p.Hi) { nhi = mid + e; break; }
                lo = nlo; hi = nhi; break;
            }
        }
        return new Iv(lo, hi);
    }
}

/// <summary>Second-order interval automatic differentiation.</summary>
public readonly record struct D2(Iv V, Iv D, Iv DD)
{
    public static D2 Var(Iv x) => new(x, Iv.Point(1), Iv.Point(0));
    public static D2 operator +(D2 a, D2 b) => new(a.V + b.V, a.D + b.D, a.DD + b.DD);
    public static D2 operator *(D2 a, D2 b) => new(a.V * b.V, a.D * b.V + a.V * b.D, a.DD * b.V + 2.0 * (a.D * b.D) + a.V * b.DD);
    public static D2 operator *(double s, D2 a) => new(s * a.V, s * a.D, s * a.DD);
    public static D2 operator *(Iv s, D2 a) => new(s * a.V, s * a.D, s * a.DD);
    public D2 Exp() { var e = V.Exp(); return new(e, e * D, e * (DD + D.Sqr())); }
    /// <summary>Phi(u): value from the validated Cdf; Phi' = phi, Phi'' = -u phi.</summary>
    public D2 Phi() { var p = Normal.Pdf(V); return new(Normal.Cdf(V), p * D, p * (DD - V * D.Sqr())); }
    public D2 Pdf() { var p = Normal.Pdf(V); return new(p, -(V * p) * D, p * ((V.Sqr() - 1.0) * D.Sqr() - V * DD)); }
}
