namespace McmIntervals;

/// <summary>Truncated Taylor series with interval coefficients c_k = f^(k)(x0)/k!, evaluated in interval arithmetic.
/// Evaluated at an interval x0 = X, coefficient k encloses f^(k)(xi)/k! for every xi in X (Lagrange remainder).</summary>
public sealed class Tay
{
    public Iv[] C { get; }
    Tay(Iv[] c) { C = c; }
    public int Order => C.Length - 1;
    public static Tay Var(Iv x0, int n) { var c = Zeros(n); c[0] = x0; if (n >= 1) c[1] = Iv.Point(1); return new(c); }
    public static Tay Const(Iv v, int n) { var c = Zeros(n); c[0] = v; return new(c); }
    static Iv[] Zeros(int n) => Enumerable.Repeat(Iv.Point(0), n + 1).ToArray();
    public static Tay operator +(Tay a, Tay b) => new(a.C.Zip(b.C, (x, y) => x + y).ToArray());
    public static Tay operator -(Tay a, Tay b) => new(a.C.Zip(b.C, (x, y) => x - y).ToArray());
    public static Tay operator *(Iv s, Tay a) => new(a.C.Select(x => s * x).ToArray());
    public static Tay operator *(double s, Tay a) => Iv.Point(s) * a;
    public static Tay operator *(Tay a, Tay b)
    {
        int n = a.Order; var c = Zeros(n);
        for (int k = 0; k <= n; k++) { var s = Iv.Point(0); for (int j = 0; j <= k; j++) s = s + a.C[j] * b.C[k - j]; c[k] = s; }
        return new(c);
    }
    public Tay Pow(int k) { var r = Const(Iv.Point(1), Order); for (int i = 0; i < k; i++) r = r * this; return r; }
    /// <summary>g = exp(f): g_0 = exp(f_0), k g_k = sum_{j=1..k} j f_j g_{k-j}.</summary>
    public Tay Exp()
    {
        int n = Order; var g = Zeros(n); g[0] = C[0].Exp();
        for (int k = 1; k <= n; k++) { var s = Iv.Point(0); for (int j = 1; j <= k; j++) s = s + (double)j * (C[j] * g[k - j]); g[k] = s / (double)k; }
        return new(g);
    }
    /// <summary>Normal density composed with f.</summary>
    public Tay Pdf() => (Iv.Point(1) / Normal.Sqrt2Pi) *((-0.5) * (this * this)).Exp();
    /// <summary>Phi(f): Phi_0 from the validated Cdf; (Phi o f)' = phi(f) f' gives k Phi_k = sum_{j=1..k} j f_j p_{k-j}.</summary>
    public Tay Phi()
    {
        int n = Order; var p = Pdf().C; var g = Zeros(n); g[0] = Normal.Cdf(C[0]);
        for (int k = 1; k <= n; k++) { var s = Iv.Point(0); for (int j = 1; j <= k; j++) s = s + (double)j * (C[j] * p[k - j]); g[k] = s / (double)k; }
        return new(g);
    }
}

/// <summary>Validated quadrature: on each cell, the degree-N Taylor polynomial about the exact midpoint is integrated exactly
/// and the Lagrange remainder c_{N+1}(X) t^{N+1}, with N + 1 even, is integrated against t^{N+1} &gt;= 0.</summary>
public static class TayQuad
{
    public sealed record Result(double[] Value, double Width, int Cells, int Order);
    public static Result Integrate(Func<Tay, Tay> f, double a, double b, int cells, int order = 11)
    {
        if (order % 2 == 0) throw new ArgumentException("order must be odd so that the remainder power is even");
        var parts = new Iv[cells];
        Parallel.For(0, cells, i =>
        {
            double lo = a + (b - a) * i / cells, hi = i == cells - 1 ? b : a + (b - a) * (i + 1) / cells;
            var h = (Iv.Point(hi) - Iv.Point(lo)) / 2.0; var mid = (Iv.Point(lo) + Iv.Point(hi)) / 2.0;
            var cm = f(Tay.Var(mid, order)).C; var cx = f(Tay.Var(new Iv(lo, hi), order + 1)).C;
            var s = Iv.Point(0); var hp = h;                                   // hp = h^{k+1}
            for (int k = 0; k <= order; k++) { if (k % 2 == 0) s = s + 2.0 * cm[k] * hp / (double)(k + 1); hp = hp * h; }
            s = s + 2.0 * cx[order + 1] * hp / (double)(order + 2);          // hp = h^{order+2}
            parts[i] = s;
        });
        var tot = Iv.Point(0); foreach (var p in parts) tot = tot + p;
        return new Result(new[] { tot.Lo, tot.Hi }, tot.Width, cells, order);
    }
}
