namespace McmIntervals;

/// <summary>Worked example 2 at finite tolerance. Planar prior with radial profile g(r) = (1 - 4 (r-1)^2)^2 on |r - 1| &lt;= 1/2,
/// residual h2 = e^x (x^2 + y^2 - 1). For direction cos(theta) = c the band |h2| &lt;= delta is the radial interval
/// [r_-, r_+] with e^{r c}(r^2 - 1) = -delta, +delta (h2 increases in r on the annulus for delta &lt;= 1/4), and its
/// angular mass is P(r_+) - P(r_-), P' = r g. Roots are enclosed by interval Newton, uniformly for c in an interval.</summary>
public static class Band
{
    // P(1 + u) = u + u^2/2 - 8u^3/3 - 2u^4 + 16u^5/5 + 8u^6/3
    static Iv P(Iv r)
    {
        var u = r - 1.0;
        var c = new[] { Iv.Point(0), Iv.Point(1), Iv.Point(0.5), -(8.0 / Iv.Point(3)), Iv.Point(-2), 16.0 / Iv.Point(5), 8.0 / Iv.Point(3) };
        var s = c[6]; for (int k = 5; k >= 0; k--) s = s * u + c[k];
        return s;
    }
    static Iv F(Iv r, Iv c, Iv rhs) => (r * c).Exp() * (r.Sqr() - 1.0) - rhs;
    static Iv dF(Iv r, Iv c) => (r * c).Exp() * (c * (r.Sqr() - 1.0) + 2.0 * r);
    static Iv Root(Iv c, Iv rhs, Iv x)
    {
        if (dF(x, c).Lo <= 0) throw new ArithmeticException("not monotone");
        if (F(Iv.Point(x.Lo), c, rhs).Hi >= 0 || F(Iv.Point(x.Hi), c, rhs).Lo <= 0) throw new ArithmeticException("root not bracketed");
        for (int it = 0; it < 100; it++)
        {
            double m = x.Mid; var n = Iv.Point(m) - F(Iv.Point(m), c, rhs) / dF(x, c); var y = x.Intersect(n);
            if (y.IsEmpty) throw new ArithmeticException("empty");
            if (y.Width >= 0.999 * x.Width) { x = y; break; }
            x = y;
        }
        return x;
    }
    public static Iv Mass(Iv c, Iv delta) => P(Root(c, delta, new Iv(1, 1.5))) - P(Root(c, -delta, new Iv(0.5, 1)));
    public sealed record Row(double Delta, double[] Ratio, double[] MeanCos, double[] Mass0, int Cells);
    /// <summary>Density ratio p_delta(pi)/p_delta(0) and mean cosine of the band-conditioned angular law. By symmetry the
    /// mean cosine is int_0^pi m c dtheta / int_0^pi m dtheta; with n equal cells the common width pi/n cancels, and each
    /// cell contributes enclosures of the ranges of m c and m over a hull of that cell.</summary>
    public static Row At(double delta, int cells)
    {
        var d = Iv.Point(delta); var pi = Normal.Pi;
        var m0 = Mass(Iv.Point(1), d); var ratio = Mass(Iv.Point(-1), d) / m0;
        var num = new Iv[cells]; var den = new Iv[cells];
        Parallel.For(0, cells, i =>
        {
            var th = new Iv((pi * (double)i / cells).Lo, (pi * (double)(i + 1) / cells).Hi);
            var c = th.Cos(); var m = Mass(c, d);
            num[i] = m * c; den[i] = m;
        });
        var sN = Iv.Point(0); var sD = Iv.Point(0);
        for (int i = 0; i < cells; i++) { sN = sN + num[i]; sD = sD + den[i]; }
        var mc = sN / sD;
        return new Row(delta, new[] { ratio.Lo, ratio.Hi }, new[] { mc.Lo, mc.Hi }, new[] { m0.Lo, m0.Hi }, cells);
    }
}
