"""Symbolic and high-precision checks for the Mixed Spaces companion V4 (SymPy 1.14, mpmath 1.3)."""
import json
from fractions import Fraction as F
import sympy as sp
import mpmath as mp

mp.mp.dps = 40
out = {}
z, b, t, c, d, u = sp.symbols('z b t c delta u', real=True)

# ---- Theorem 4: selected-coordinate means m_q
phi = lambda x: mp.npdf(x)
def mq(q):
    return mp.quad(lambda x: q * x * mp.npdf(x) * mp.ncdf(x) ** (q - 1), [-mp.inf, -5, 0, 5, mp.inf])
out['m_q'] = {str(q): mp.nstr(mq(q), 20) for q in (2, 3, 4, 5, 6, 8, 10, 12, 16)}
out['m_2_exact'] = '1/sqrt(pi)'
out['m_3_exact'] = '3/(2 sqrt(pi))'
out['m_4_closed'] = mp.nstr(3 / mp.sqrt(mp.pi) * (mp.mpf(1) / 2 + mp.asin(mp.mpf(1) / 3) / mp.pi), 20)
out['m_3_check'] = mp.nstr(mq(3) - 3 / (2 * mp.sqrt(mp.pi)), 5)

# ---- Worked example 1 (decimal data exact)
r = sp.Rational
I = sp.sqrt(2 * sp.pi) / 2 * (sp.erf(r(8, 10) * sp.sqrt(2)) / 2 + sp.erf(r(12, 10) * sp.sqrt(2)) / 2)  # int_1^3 e^{-2(x-2.2)^2}
atomw = r(3, 10) * sp.exp(-r(968, 100)); cont = r(35, 100) * sp.exp(-1) * I
out['atom'] = str(sp.N(atomw / (atomw + cont), 25))
first = r(22, 10) * I + (sp.exp(-r(288, 100)) - sp.exp(-r(128, 100))) / 4
out['tilted_mean_design'] = str(sp.N(r(35, 100) * sp.exp(-1) * first / (atomw + cont), 25))
out['atom_integral'] = str(sp.N(I, 25))

# ---- Theorem 2 identity for representatives -2, +2 at a general threshold b
Phi_b, phi_b = sp.symbols('Phi_b phi_b', positive=True)
mneg, mpos = -phi_b / Phi_b, phi_b / (1 - Phi_b)
rhs = 1 - (Phi_b * mneg ** 2 + (1 - Phi_b) * mpos ** 2) + Phi_b * (mneg + 2) ** 2 + (1 - Phi_b) * (mpos - 2) ** 2
out['risk_identity_rhs_minus_lhs'] = str(sp.simplify(rhs - (5 - 8 * phi_b)))

# ---- Proposition 10.3: ball second moments in R^k
for k in (1, 2, 3):
    rr = sp.symbols('rr', positive=True)
    # E[t_1^2] over the ball = E|t|^2 / k, radial density k r^{k-1}/delta^k
    m2 = sp.integrate(rr ** 2 * k * rr ** (k - 1) / d ** k, (rr, 0, d)) / k
    out[f'ball_second_moment_k{k}'] = str(sp.simplify(m2))

# ---- Worked example 2 at finite delta: series of the band mass in delta
N = 5
a = sp.symbols('a1:%d' % (N + 1))
rser = 1 + sum(a[i] * t ** (i + 1) for i in range(N))
eq = sp.series(sp.exp(rser * c) * (rser ** 2 - 1) - t, t, 0, N + 1).removeO()
sol = {}
for i in range(N):
    co = sp.expand(eq.coeff(t, i + 1)).subs(sol)
    s_ = sp.solve(co, a[i])[0]; sol[a[i]] = sp.simplify(s_)
rt = sp.expand(rser.subs(sol))
P = u + u ** 2 / 2 - r(8, 3) * u ** 3 - 2 * u ** 4 + r(16, 5) * u ** 5 + r(8, 3) * u ** 6
mass = sp.series(P.subs(u, rt - 1).subs(t, d) - P.subs(u, rt - 1).subs(t, -d), d, 0, 5).removeO()
M1 = sp.simplify(mass.coeff(d, 1)); M3 = sp.simplify(mass.coeff(d, 3)); M2 = sp.simplify(mass.coeff(d, 2))
out['band_M1'] = str(M1); out['band_M2'] = str(M2); out['band_M3'] = str(sp.factor(M3))
ratio_coef = sp.simplify(M3.subs(c, -1) / M1.subs(c, -1) - M3.subs(c, 1) / M1.subs(c, 1))
out['band_ratio_delta2_coef_relative'] = str(ratio_coef)
out['band_ratio_delta2_coef_absolute'] = mp.nstr(mp.e ** 2 * mp.mpf(str(sp.N(ratio_coef, 40))), 20)
f1 = sp.lambdify(c, M1, 'mpmath'); f3 = sp.lambdify(c, M3, 'mpmath')
J = lambda f, w: mp.quad(lambda th: f(mp.cos(th)) * w(th), [0, mp.pi])
J1, Jc1 = J(f1, lambda th: 1), J(f1, mp.cos)
J3, Jc3 = J(f3, lambda th: 1), J(f3, mp.cos)
out['band_meancos_limit'] = mp.nstr(Jc1 / J1, 20)
out['band_meancos_bessel'] = mp.nstr(-mp.besseli(1, 1) / mp.besseli(0, 1), 20)
out['band_meancos_delta2_coef'] = mp.nstr((Jc3 * J1 - Jc1 * J3) / J1 ** 2, 20)
out['band_density_ratio_limit'] = mp.nstr(mp.e ** 2, 20)
# exact finite-delta values at high precision for comparison with the interval enclosures
def mass_hp(cc, dd):
    cc = mp.mpf(cc); dd = mp.mpf(dd)
    rp = mp.findroot(lambda x: mp.e ** (x * cc) * (x * x - 1) - dd, 1 + dd / 2)
    rm = mp.findroot(lambda x: mp.e ** (x * cc) * (x * x - 1) + dd, 1 - dd / 2)
    Pf = lambda x: (lambda uu: uu + uu ** 2 / 2 - mp.mpf(8) / 3 * uu ** 3 - 2 * uu ** 4 + mp.mpf(16) / 5 * uu ** 5 + mp.mpf(8) / 3 * uu ** 6)(x - 1)
    return Pf(rp) - Pf(rm)
out['band_ratio_hp'] = {str(dd): mp.nstr(mass_hp(-1, dd) / mass_hp(1, dd), 16) for dd in ('0.25', '0.1', '0.05', '0.01', '0.001')}

# ---- Corollary 10.2 example: expansions of the two band probabilities
PA = sp.exp(-r(1, 2)) * 2 * sp.sinh(d / 2); PB = 1 - sp.exp(-d ** 2 / 2)
out['PA_series'] = str(sp.series(PA, d, 0, 5)); out['PB_series'] = str(sp.series(PB, d, 0, 5))
out['weightB_series'] = str(sp.series(PB / (PA + PB), d, 0, 3))

# ---- Proposition 8.1: front components for g = 1 - x + a sin^2(K pi x)
aa = mp.mpf(3) / 10
def front(K):
    K = int(K); g = lambda x: 1 - x + aa * mp.sin(K * mp.pi * x) ** 2
    x0 = mp.asin(1 / (aa * K * mp.pi)) / (2 * K * mp.pi)
    m0 = x0; top = mp.mpf(1) / (2 * K) - x0
    lo, hi = top, mp.mpf(1) / K + x0; gm = g(m0)
    for _ in range(200):
        mid = (lo + hi) / 2
        if g(mid) > gm: lo = mid
        else: hi = mid
    c1 = (lo + hi) / 2
    meas = x0 + (K - 1) * (mp.mpf(1) / K + x0 - c1) + (1 - (c1 + mp.mpf(K - 1) / K))
    return x0, c1, meas
fr = {}
for K in (2, 3, 4, 8, 16, 64, 256, 4096, 65536):
    x0, c1, meas = front(K)
    fr[str(K)] = {'x0': mp.nstr(x0, 16), 'c1': mp.nstr(c1, 16), 'measure': mp.nstr(meas, 16), 'scaled': mp.nstr(meas * mp.pi * mp.sqrt(aa * K), 12)}
out['fronts'] = fr
out['x0_K4_closed'] = 'asin(1/(1.2 pi))/(8 pi)'

# ---- Pressure vessel: exact optimum value, radii, relaxation, pi bracket
V = 1296000; pi = sp.pi
c1_, c2_, c3_, c4_ = r(6224, 10000), r(17781, 10000), r(31661, 10000), r(1984, 100)
R = sp.symbols('R', positive=True)
def fred(ts, th):
    A = c1_ * ts * V / pi; B = c2_ * th - r(4, 3) * c1_ * ts; C = c3_ * ts ** 2 * V / pi; D = (c4_ - r(4, 3) * c3_) * ts ** 2
    return A / R + B * R ** 2 + C / R ** 2 + D * R
f137 = fred(r(13, 16), r(7, 16)); rc = r(8125, 193)
cstar = sp.simplify(f137.subs(R, rc))
out['cstar_closed'] = str(cstar); out['cstar_40'] = str(sp.N(cstar, 40))
out['cstar_slope_at_cap'] = str(sp.N(sp.diff(f137, R).subs(R, rc), 20))
out['cstar_length'] = str(sp.N(V / (pi * rc ** 2) - r(4, 3) * rc, 25))
f147 = fred(r(14, 16), r(7, 16)); out['second_pair_value'] = str(sp.N(f147.subs(R, r(8750, 193)), 25))
r200 = sp.nsolve(pi * (200 * R ** 2 + r(4, 3) * R ** 3) - V, R, 40.3, prec=40)
r10 = sp.nsolve(pi * (10 * R ** 2 + r(4, 3) * R ** 3) - V, R, 65.2, prec=40)
out['r200'] = str(r200); out['r10'] = str(r10)
al, ga = r(193, 10000), r(954, 100000)
kap = c2_ * ga + c4_ * al ** 2 - r(4, 3) * (c1_ * al + c3_ * al ** 2)
out['relax_kappa_exact'] = str(kap); out['relax_kappa'] = str(sp.N(kap, 20))
crel = (c1_ * al + c3_ * al ** 2) * V / pi + kap * r200 ** 3
out['relaxation'] = str(sp.N(crel, 30)); out['integrality_gap'] = str(sp.N(sp.N(cstar, 40) - crel, 20))
out['relative_gap'] = str(sp.N((sp.N(cstar, 40) - crel) / crel, 10))
def atan_iv(q, n=16):
    s = sum((F((-1) ** k, (2 * k + 1) * q ** (2 * k + 1)) for k in range(n)), F(0)); tt = F((-1) ** n, (2 * n + 1) * q ** (2 * n + 1))
    return min(s, s + tt), max(s, s + tt)
a5, b5 = atan_iv(5); a239, b239 = atan_iv(239)
plo, phi_ = 16 * a5 - 4 * b239, 16 * b5 - 4 * a239
out['machin_width'] = mp.nstr(mp.mpf(phi_.numerator) / phi_.denominator - mp.mpf(plo.numerator) / plo.denominator, 6)
out['machin_contains_pi'] = bool(mp.mpf(plo.numerator) / plo.denominator < mp.pi < mp.mpf(phi_.numerator) / phi_.denominator)
out['paper_bracket'] = ['1211942867/200000', '60597143351/10000000']
json.dump(out, open('sym.json', 'w'), indent=1)
print(json.dumps(out, indent=1))
