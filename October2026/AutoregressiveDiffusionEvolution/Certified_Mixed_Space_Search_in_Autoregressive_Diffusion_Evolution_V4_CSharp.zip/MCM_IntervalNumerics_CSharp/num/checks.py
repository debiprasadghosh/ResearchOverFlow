"""Deterministic and seeded checks accompanying the mathematical results."""
import json, math
import numpy as np
from scipy.integrate import quad
from scipy.special import ndtr, i0, i1
from certificate import certify

phi = lambda z: math.exp(-z*z/2)/math.sqrt(2*math.pi)
b, beta = .5, 2.
prob = np.array([ndtr(b), ndtr(-b)])
means = np.array([-phi(b)/prob[0], phi(b)/prob[1]])
representatives = np.array([-2., 2.])
lhs = 5-8*phi(b)
rhs = 1-np.dot(prob,means*means)+np.dot(prob,(means-representatives)**2)
assert abs(lhs-rhs) < 1e-14
atom=.3*math.exp(-2*2.2**2)
continuous=.35*quad(lambda x: math.exp(-2*((x-2.2)**2+.5)),1,3)[0]
mq={str(q):quad(lambda z: z*q*phi(z)*ndtr(z)**(q-1),-12,12,
               epsabs=1e-12)[0] for q in (3,6,16)}
leak = 2*ndtr(-1.)
assert abs(leak-.31731050786291415)<1e-14
assert sum(np.array([1,1,0])+np.array([1,0,1])+np.array([0,1,1])>1.5)==3

rng=np.random.default_rng(20261018)
def dominates(a,b):
    fa,va=a;fb,vb=b
    if va==0 and vb>0:return True
    if va>0 and vb==0:return False
    if va>0:return va<vb
    return bool(np.all(fa<=fb) and np.any(fa<fb))
def draw():
    return (rng.integers(0,5,size=2),float(rng.choice([0,0,.3,1])))
for _ in range(100000):
    a,b,c=draw(),draw(),draw()
    assert not dominates(a,a)
    assert not(dominates(a,b) and dominates(b,c)) or dominates(a,c)
front_checks=0
for trial in range(1000):
    ds=[draw() for _ in range(12)]
    if trial % 10 == 0:
        ds=[(f,max(.3,v)) for f,v in ds]
    front=[i for i,x in enumerate(ds) if not any(dominates(y,x) for y in ds)]
    feas=[i for i,x in enumerate(ds) if x[1]==0]
    if feas:
        expected=[i for i in feas if not any(dominates(ds[j],ds[i]) for j in feas)]
    else:
        v=min(x[1] for x in ds);expected=[i for i,x in enumerate(ds) if x[1]==v]
    assert front==expected
    front_checks+=1

out=dict(threshold_means=means.tolist(),risk_identity_lhs=lhs,
         risk_identity_rhs=rhs,atom_mass=atom/(atom+continuous),argmax_means=mq,
         binary_z2_gap=1-2/math.pi,
         binary_tilted_z=math.sqrt(2/math.pi)*math.tanh(1),
         nonconvex_fibre_bias=leak,
         equality_density_ratio=math.exp(2),
         equality_mean_cos=-float(i1(1)/i0(1)),
         order_triples=100000,front_sets=front_checks,
         certificate=certify())
print(json.dumps(out,indent=2))
