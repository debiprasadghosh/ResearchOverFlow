"""Exact rational certificate for the declared mixed pressure vessel."""
from fractions import Fraction as Q
import json


def require(condition):
    if not condition:
        raise ArithmeticError("Certificate condition failed")


def atan_interval(q, n=16):
    s = sum((Q((-1)**k, (2*k+1)*q**(2*k+1))
             for k in range(n)), Q(0))
    t = Q((-1)**n, (2*n+1)*q**(2*n+1))
    return min(s, s+t), max(s, s+t)


def pi_interval():
    a, b = atan_interval(5)
    c, d = atan_interval(239)
    return 16*a-4*d, 16*b-4*c


PI_LO, PI_HI = pi_interval()
V = Q(1296000)
TARGET = Q("6059.7143350")
UPPER = Q("6059.7143351")


def cost(ts, th, r, length):
    return (Q("0.6224")*ts*r*length
            + Q("1.7781")*th*r*r
            + Q("3.1661")*ts*ts*length
            + Q("19.84")*ts*ts*r)


def lower(ts, th, a, b):
    length = max(Q(10), V/(PI_HI*b*b)-4*b/3)
    return cost(ts, th, a, length)


def feasible_upper():
    ts, th = Q(13, 16), Q(7, 16)
    r = ts/Q("0.0193")
    # PI_LO gives a length at least as large as the true required one.
    needed = V/(PI_LO*r*r)-4*r/3
    scale = 10**12
    u = needed*scale
    length = Q(-(-u.numerator//u.denominator), scale)
    require(10 <= r <= 200 and 10 <= length <= 200)
    require(ts >= Q("0.0193")*r)
    require(th >= Q("0.00954")*r)
    require(PI_LO*(r*r*length+4*r*r*r/3) >= V)
    value = cost(ts, th, r, length)
    require(value <= UPPER)
    return r, length, value


def certify():
    # All r <= 40 are infeasible even at maximum length 200.
    require(PI_HI*(40**2*200+Q(4, 3)*40**3) < V)
    pairs = boxes = depth = 0
    for ks in range(1, 100):
        for kh in range(1, 100):
            ts, th = Q(ks, 16), Q(kh, 16)
            hi = min(Q(200), ts/Q("0.0193"),
                     th/Q("0.00954"))
            if hi < 40:
                continue
            pairs += 1
            stack = [(Q(40), hi, 0)]
            while stack:
                a, b, level = stack.pop()
                boxes += 1
                depth = max(depth, level)
                if lower(ts, th, a, b) >= TARGET:
                    continue
                if level >= 80:
                    raise RuntimeError("Unresolved box: no certificate")
                m = (a+b)/2
                stack.extend([(a, m, level+1), (m, b, level+1)])
    r, length, value = feasible_upper()
    require(UPPER-TARGET == Q("0.0000001"))
    return dict(pairs=pairs, boxes=boxes, max_depth=depth,
                lower=str(TARGET), upper=str(UPPER),
                radius_approx=float(r), length_approx=float(length),
                cost_approx=float(value),
                pi_width_approx=float(PI_HI-PI_LO))


if __name__ == "__main__":
    print(json.dumps(certify(), indent=2))
