import json, math, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'font.family': 'DejaVu Sans'})
NAVY = '#213f63'; RUST = '#b5612f'; GREY = '#9aa3aa'; DARK = '#444444'; GOLD = '#c39a2f'; TEAL = '#2f7f86'
R = json.load(open('../cs/results.json')); S = json.load(open('../num/sym.json'))

# ---------- Figure 2: certified front components (K = 4) and band convergence
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.7))
K = 4; x = np.linspace(0, 1, 4001); g = 1 - x + 0.3 * np.sin(K * np.pi * x) ** 2
fr = [f for f in R['fronts'] if f['K'] == 4][0]
ax[0].plot(x, g, color=GREY, lw=1.0, label='Dominated')
for p in fr['Parts']:
    a_, b_ = p['Start'][1], p['End'][0]; xs = np.linspace(a_, b_, 300)
    ax[0].plot(xs, 1 - xs + 0.3 * np.sin(K * np.pi * xs) ** 2, color=NAVY, lw=2.4)
ax[0].plot([], [], color=NAVY, lw=2.4, label='Efficient (certified ends)')
for p in fr['Parts'][1:]:
    xc = p['Start'][0]; ax[0].plot([xc], [1 - xc + 0.3 * math.sin(K * math.pi * xc) ** 2], 'o', mfc='white', mec=RUST, ms=4)
ax[0].set_xlabel('First objective x'); ax[0].set_ylabel('Second objective')
ax[0].set_title('A  Five efficient components, K = 4', fontsize=9.5); ax[0].legend(fontsize=6.6, frameon=False, loc='upper right')
b = R['band']; dl = np.array([r['Delta'] for r in b])
rl = np.array([abs(math.exp(2) - 0.5 * (r['Ratio'][0] + r['Ratio'][1])) for r in b])
mc_lim = float(S['band_meancos_limit']); mcv = np.array([abs(0.5 * (r['MeanCos'][0] + r['MeanCos'][1]) - mc_lim) for r in b])
mcw = np.array([0.5 * (r['MeanCos'][1] - r['MeanCos'][0]) for r in b])
dd = np.logspace(-2.1, -0.55, 50)
ax[1].loglog(dl, rl / math.exp(2), 'o', color=NAVY, ms=4, label='Density ratio, relative')
ax[1].loglog(dd, abs(float(S['band_ratio_delta2_coef_absolute'])) / math.exp(2) * dd ** 2, '-', color=NAVY, lw=0.8)
ax[1].errorbar(dl, mcv, yerr=mcw, fmt='s', color=RUST, ms=3.5, capsize=2, label='Mean cosine')
ax[1].loglog(dd, float(S['band_meancos_delta2_coef']) * dd ** 2, '-', color=RUST, lw=0.8)
ax[1].text(0.0085, 2.5e-2, 'lines: δ² terms of\nProposition 10.3', fontsize=6.6, color=DARK)
ax[1].set_xlabel('Band tolerance δ'); ax[1].set_ylabel('Distance from the limit law')
ax[1].set_title('B  Band law converges at order δ²', fontsize=9.5); ax[1].legend(fontsize=6.6, frameon=False, loc='lower right')
fig.tight_layout(); fig.savefig('fig2.png', dpi=300); plt.close(fig)

# ---------- Figure 3: pressure-vessel certified per-pair minima and reduced cost near the optimum
v = R['vessel']; allp = np.array(v['AllPairs'])
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.8))
Kmax = 40; M = np.full((Kmax, Kmax), np.nan)
for ks, kh, lo, hi, w in allp:
    if ks <= Kmax and kh <= Kmax: M[int(kh) - 1, int(ks) - 1] = lo
im = ax[0].imshow(M, origin='lower', extent=(0.5, Kmax + 0.5, 0.5, Kmax + 0.5), norm=LogNorm(vmin=6000, vmax=np.nanmax(M)), cmap='cividis_r', aspect='auto')
ax[0].plot([13], [7], marker='*', color=RUST, ms=9, mec='white', mew=0.6)
ax[0].text(14.5, 8.6, '(13, 7): 6059.714335048', fontsize=6.6, color=DARK)
ax[0].text(1.5, 28, 'infeasible:\nshell cap\nbelow r₂₀₀', fontsize=6.6, color=DARK)
ax[0].text(14, 2.0, 'infeasible: head cap below r₂₀₀', fontsize=6.6, color=DARK)
ax[0].set_xlabel('Shell gauge k_s (t_s = k_s/16)'); ax[0].set_ylabel('Head gauge k_h (t_h = k_h/16)')
ax[0].set_title('A  Certified minimum cost per gauge pair', fontsize=9.5)
cb = fig.colorbar(im, ax=ax[0], fraction=0.05, pad=0.02); cb.ax.tick_params(labelsize=7)
V = 1296000; c1, c2, c3, c4 = 0.6224, 1.7781, 3.1661, 19.84
def f(ks, kh, r):
    ts, th = ks / 16, kh / 16; A = c1 * ts * V / math.pi; B = c2 * th - 4 / 3 * c1 * ts; C = c3 * ts ** 2 * V / math.pi; D = (c4 - 4 / 3 * c3) * ts ** 2
    return A / r + B * r ** 2 + C / r ** 2 + D * r
r200 = float(S['r200'])
for (ks, kh), col in (((13, 7), NAVY), ((14, 7), RUST), ((13, 8), TEAL), ((16, 8), GOLD)):
    cap = min(200, ks / 16 / 0.0193, kh / 16 / 0.00954); rr = np.linspace(r200, cap, 300)
    ax[1].plot(rr, f(ks, kh, rr), color=col, lw=1.4, label=f'({ks}, {kh})'); ax[1].plot([cap], [f(ks, kh, cap)], 'o', color=col, ms=3.5)
ax[1].axhline(float(S['relaxation']), color=GREY, ls='--', lw=0.8); ax[1].text(41, 5925, 'continuous relaxation 5885.33', fontsize=6.6, color=DARK)
ax[1].set_xlabel('Radius r on the volume branch'); ax[1].set_ylabel('Reduced cost f(r)')
ax[1].set_title('B  Minima sit at the thickness caps', fontsize=9.5); ax[1].legend(fontsize=6.6, frameon=False, loc='upper right', title='Gauge pair', title_fontsize=6.6)
ax[1].set_ylim(5800, 7400)
fig.tight_layout(); fig.savefig('fig3.png', dpi=300); plt.close(fig)
print('ok')
