# Mathematical Companion for Mixed Spaces V4: validated interval computations

- `cs/`: C# (.NET 8, no packages). `dotnet run -c Release` writes `results.json` (about 80 s).
  Interval.cs, Rational.cs, Normal.cs, Taylor.cs (Taylor-model quadrature), Constants.cs (Table 2),
  Sampling.cs (Table 3), Fronts.cs (Proposition 8.1, Table 4), Band.cs (Proposition 10.3, Table 5),
  Codim.cs (Table 6), Vessel.cs (Propositions 11.1-11.2, Table 7), Program.cs, Rng.cs.
- `num/sym.py`: SymPy 1.14 / mpmath 1.3 checks (writes sym.json). `certificate.py`, `checks.py`: Appendices A and B
  extracted from the V3 paper, with their outputs from this run.
- `fig/figs.py`: Figures 2 and 3 from results.json and sym.json.

Assumptions: one-ulp outward rounding after IEEE 754 +, -, *, /, sqrt; Math.Exp, Log, Sin, Cos taken accurate to
four ulps (not used by the pressure-vessel certificate); Laplace continued-fraction convergents bracket the Mills ratio.
Sampling results are seeded diagnostics, not certificates.
