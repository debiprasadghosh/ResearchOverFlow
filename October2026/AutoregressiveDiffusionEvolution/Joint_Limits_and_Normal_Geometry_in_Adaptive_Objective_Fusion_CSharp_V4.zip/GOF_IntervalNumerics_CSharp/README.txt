Geometry of Fusion V4: validated interval numerics (Sections 13.4-13.7, Appendix C)

cs/        .NET 8 console project. Build: dotnet build -c Release; run: dotnet bin/Release/net8.0/Gof.dll (about 41 s).
           Writes results.json and reuse_replicates.json.
symbolic/  sym.py: SymPy/mpmath checks of the identities in Section 13.4, kappa of Proposition 9, 20-digit L1 values,
           Lambert-W modes and the Tracy-Widom depth predictions.
figures/   figs.py regenerates Figures 3 and 4 (paths assume the original build tree: ../cs and ../num).
