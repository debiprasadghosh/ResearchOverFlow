namespace GofIntervals;

/// <summary>Strict-coordinate chain depth below an upper corner for uniform reference samples (Theorem 3 check).</summary>
public static class Depth
{
    public static int Chain(double[] x, double[] y, double ux, double uy)
    {
        var idx = Enumerable.Range(0, x.Length).Where(i => x[i] <= ux && y[i] <= uy).OrderBy(i => x[i]).ThenByDescending(i => y[i]).ToArray();
        var tails = new List<double>();
        foreach (int i in idx)
        {
            int k = tails.BinarySearch(y[i]); if (k < 0) k = ~k; else { while (k > 0 && tails[k - 1] == y[i]) k--; }   // bisect_left
            if (k == tails.Count) tails.Add(y[i]); else tails[k] = y[i];
        }
        return tails.Count;
    }
    public static double[] Run(int seed, int n, (double, double)[] corners)
    {
        var r = new Random(seed); var x = new double[n]; var y = new double[n];
        for (int i = 0; i < n; i++) { x[i] = r.NextDouble(); y[i] = r.NextDouble(); }
        return corners.Select(c => Chain(x, y, c.Item1, c.Item2) / Math.Sqrt(n)).ToArray();
    }
}
