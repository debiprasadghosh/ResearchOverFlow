namespace GofIntervals;

/// <summary>Certified L1 distance between the finite-temperature tangential marginal and its zero-set limit for
/// S(s, v) = (1 + s^2)|v| on [-1, 1]^2 with reference phi(s) phi(v). With c = 1 + s^2 and b = beta c,
/// the normal integral is (2 phi(0) / b) (1 - D(b)), where D(b) = e^{-b} + int_0^b e^{-t}(1 - e^{-t^2/(2b^2)}) dt
/// is decreasing in c. Then p_beta = p_inf (1 - D) / (1 - Dbar) and L1 = int p_inf |Dbar - D| / (1 - Dbar).</summary>
public static class ZeroSet
{
    public sealed record Row(double Beta, double L1Lo, double L1Hi, double DbarLo, double DbarHi, int SCells, int TCells);

    /// <summary>Validated enclosure of D(b) by the midpoint rule with an interval second-derivative remainder.</summary>
    public static Iv D(double b, int cells)
    {
        Iv B = Iv.Point(b), k = 1.0 / (2.0 * B.Sqr());
        double h = b / cells; Iv H = Iv.Point(h), H3 = H * H * H / 24.0, sum = Iv.Point(0);
        for (int j = 0; j < cells; j++)
        {
            double lo = j * h, hi = (j + 1) * h; Iv m = Iv.Point(0.5 * (lo + hi)), X = new(lo, Math.Min(hi, b));
            Iv gm = (-m).Exp() * (1.0 - (-(k * m.Sqr())).Exp());
            Iv e1 = (-X).Exp(), e2 = (-X - k * X.Sqr()).Exp(), d = 1.0 + 2.0 * k * X;
            Iv g2 = e1 - (d.Sqr() - 2.0 * k) * e2;                      // second derivative of e^{-t} - e^{-t - k t^2}
            sum += H * gm + H3 * g2;
        }
        return (-B).Exp() + sum;
    }

    public static Row Run(double beta, int sCells = 4000, int tCells = 20000)
    {
        double ds = 1.0 / sCells;
        var Dk = new Iv[sCells + 1];
        Parallel.For(0, sCells + 1, k => { double s = k * ds; Dk[k] = D(beta * (1 + s * s), tCells); });
        Iv invSqrt2Pi = 1.0 / (2.0 * new Iv(Math.BitDecrement(Math.PI), Math.BitIncrement(Math.PI))).Sqrt();
        // per-cell enclosures of f_inf = phi(s)/c and of D (monotone: D(cell) between its endpoint values)
        var F = new Iv[sCells]; var Dc = new Iv[sCells]; Iv Z = Iv.Point(0), ZD = Iv.Point(0);
        for (int k = 0; k < sCells; k++)
        {
            Iv S = new(k * ds, (k + 1) * ds);
            Iv f = invSqrt2Pi * (-0.5 * S.Sqr()).Exp() / (1.0 + S.Sqr());
            F[k] = Iv.Point(ds) * f;                                        // encloses the cell integral of f_inf
            Dc[k] = new(Math.Min(Dk[k].Lo, Dk[k + 1].Lo), Math.Max(Dk[k].Hi, Dk[k + 1].Hi));
            Z += F[k]; ZD += F[k] * Dc[k];
        }
        // Dbar: the exact value lies in [min over cells of ZD/Z]; use the hull ZD/Z, intersected with [min D, max D]
        Iv Dbar = ZD / Z;
        Iv L = Iv.Point(0);
        for (int k = 0; k < sCells; k++) L += F[k] * (Dbar - Dc[k]).Abs();
        L = L / Z / (1.0 - Dbar);
        return new(beta, L.Lo, L.Hi, Dbar.Lo, Dbar.Hi, sCells, tCells);
    }
}
