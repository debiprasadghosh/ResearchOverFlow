namespace GofIntervals;

/// <summary>Certified gates for point-mass heads, Chebyshev branch and bound with a strictly lower reference,
/// and interval Newton enclosures of the latent modes (13).</summary>
public static class Small
{
    public sealed record GateRow(double A, double G0Lo, double G0Hi, double G1Lo, double G1Hi);
    public static GateRow Gate(double a, double q = 0.4)
    {
        double[] c = { -1, 1 }, lam = { 0.3, 0.7 };
        Iv sa = Iv.Point(a).Sqrt(), oneMinus = 1.0 - Iv.Point(a);
        var L = c.Select((cj, j) => lam[j] * (-((Iv.Point(q) - sa * cj).Sqr()) / (2.0 * oneMinus)).Exp()).ToArray();
        Iv S = L[0] + L[1], g0 = L[0] / S, g1 = L[1] / S;
        return new(a, Math.Max(g0.Lo, 1 - g1.Hi), Math.Min(g0.Hi, 1 - g1.Lo), Math.Max(g1.Lo, 1 - g0.Hi), Math.Min(g1.Hi, 1 - g0.Lo));
    }

    public sealed record ReachRow(double Target, double L1, double HullLo, double HullHi, int Boxes);
    public static ReachRow Reach(double target, double z = -0.05, double tol = 1e-12)
    {
        double w1 = 1 / (target - z), w2 = 1 / (1 - target * target - z), l1 = w1 / (w1 + w2), l2 = w2 / (w1 + w2);
        Iv f(Iv u) { Iv a = l1 * (u - z), b = l2 * (1.0 - u.Sqr() - z); return new(Math.Max(a.Lo, b.Lo), Math.Max(a.Hi, b.Hi)); }
        var work = new Stack<Iv>(); work.Push(new Iv(0, 1)); var keep = new List<Iv>(); int boxes = 0;
        double ub = Math.Min(f(Iv.Point(0)).Hi, f(Iv.Point(1)).Hi);
        while (work.Count > 0)
        {
            var X = work.Pop(); boxes++; if (f(X).Lo > ub) continue;
            ub = Math.Min(ub, f(Iv.Point(X.Mid)).Hi);
            if (X.Width <= tol) { keep.Add(X); continue; }
            work.Push(new Iv(X.Mid, X.Hi)); work.Push(new Iv(X.Lo, X.Mid));
        }
        keep = keep.Where(X => f(X).Lo <= ub).ToList();
        return new(target, l1, keep.Min(x => x.Lo), keep.Max(x => x.Hi), boxes);
    }

    public sealed record ModeRow(double Beta, double WLo, double WHi, double ZLo, double ZHi, int Steps);
    /// <summary>Lambert W(x) by interval Newton on w e^w - x; certified when the Newton image lies inside the box.</summary>
    public static ModeRow Mode(double beta, double c = 1)
    {
        double x = 4 * beta * c, w0 = Math.Log(x) - Math.Log(Math.Log(x));
        for (int i = 0; i < 60; i++) w0 -= (w0 * Math.Exp(w0) - x) / (Math.Exp(w0) * (1 + w0));
        Iv X = new(w0 - 1e-9, w0 + 1e-9); int steps = 0; bool proved = false;
        for (; steps < 30; steps++)
        {
            double m = X.Mid; Iv M = Iv.Point(m);
            Iv N = M - (M * M.Exp() - x) / (X.Exp() * (1.0 + X));
            if (N.Inside(X)) proved = true;
            Iv Y = new(Math.Max(N.Lo, X.Lo), Math.Min(N.Hi, X.Hi));
            if (proved && Y.Width >= X.Width) break;
            X = Y;
        }
        if (!proved) throw new InvalidOperationException("Newton inclusion not proved");
        return new(beta, X.Lo, X.Hi, -X.Hi / 2, -X.Lo / 2, steps);
    }
}
