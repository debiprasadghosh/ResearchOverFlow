using System.Diagnostics;
using System.Text.Json;
using GofIntervals;

var results = new Dictionary<string, object>(); var sw = Stopwatch.StartNew();
results["gates"] = new[] { 0.9, 0.5, 0.1, 0.001 }.Select(a => Small.Gate(a)).ToList();
results["reach"] = new[] { 0.25, 0.5, 0.75 }.Select(t => Small.Reach(t)).ToList();
results["modes"] = new[] { 10.0, 100, 1000, 1e6 }.Select(b => Small.Mode(b)).ToList();
foreach (var k in new[] { "gates", "reach", "modes" }) Console.WriteLine(JsonSerializer.Serialize(results[k]));

var zs = new List<ZeroSet.Row>();
foreach (double b in new[] { 5.0, 20, 80 }) { var t = Stopwatch.StartNew(); var r = ZeroSet.Run(b); zs.Add(r); Console.WriteLine($"{r} {t.Elapsed.TotalSeconds:F1}s"); }
results["zeroSet"] = zs;

var refs = new List<Reuse.Ref>();
foreach (double w in Enumerable.Range(0, 19).Select(k => 0.05 + 0.05 * k)) foreach (double b in new[] { 2.0, 5, 10 }) refs.Add(Reuse.Reference(w, b));
results["reuseRefMaxWidth"] = refs.Max(r => r.Hi - r.Lo);
results["reuseRefs"] = refs;
Console.WriteLine($"refs max width {refs.Max(r => r.Hi - r.Lo):E2}");
results["reuseSeed"] = Reuse.Simulate(20261031, refs);
var runs = new Reuse.Run[200]; Parallel.For(0, 200, k => runs[k] = Reuse.Simulate(k + 1, refs));
double Q(IEnumerable<double> v, double p) { var a = v.OrderBy(t => t).ToArray(); return a[(int)Math.Round(p * (a.Length - 1))]; }
results["reuseReplication"] = new
{
    seeds = 200, observedMean = runs.Average(r => r.Observed), observedMin = runs.Min(r => r.Observed), observedMax = runs.Max(r => r.Observed),
    median = Enumerable.Range(0, 3).Select(s => Q(runs.Select(r => r.SupErr[s]), 0.5)).ToArray(),
    p10 = Enumerable.Range(0, 3).Select(s => Q(runs.Select(r => r.SupErr[s]), 0.1)).ToArray(),
    p90 = Enumerable.Range(0, 3).Select(s => Q(runs.Select(r => r.SupErr[s]), 0.9)).ToArray(),
    rankOfPython = new[] { 0.0392823, 0.0087848, 0.0038872 }.Select((v, s) => runs.Count(r => r.SupErr[s] < v) / 200.0).ToArray()
};
Console.WriteLine(JsonSerializer.Serialize(results["reuseSeed"])); Console.WriteLine(JsonSerializer.Serialize(results["reuseReplication"]));
File.WriteAllText("reuse_replicates.json", JsonSerializer.Serialize(runs));

var corners = new[] { (1.0, 1.0), (0.5, 0.5), (1.0, 0.25) };
var depth = new List<object>();
foreach (int n in new[] { 1000, 10000, 100000 })
{
    var d = new double[200][]; Parallel.For(0, 200, k => d[k] = Depth.Run(5000 + k, n, corners));
    depth.Add(new { n, mean = Enumerable.Range(0, 3).Select(j => d.Average(r => r[j])).ToArray(), median = Enumerable.Range(0, 3).Select(j => Q(d.Select(r => r[j]), 0.5)).ToArray(),
        sd = Enumerable.Range(0, 3).Select(j => { double m = d.Average(r => r[j]); return Math.Sqrt(d.Sum(r => (r[j] - m) * (r[j] - m)) / 199); }).ToArray() });
}
results["depth"] = depth; Console.WriteLine(JsonSerializer.Serialize(depth));
results["runtime"] = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription; results["seconds"] = sw.Elapsed.TotalSeconds;
File.WriteAllText("results.json", JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"written {sw.Elapsed.TotalSeconds:F1}s");
