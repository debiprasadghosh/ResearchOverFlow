namespace GofIntervals;

/// <summary>Section 13.1 adaptive reuse: uniform reference on [0, 1], F = (x, 1 - x^2), zero-reference Chebyshev loss
/// T = max(w x, (1 - w)(1 - x^2)), 19 weights times beta in {2, 5, 10}. Certified references split at the kink.</summary>
public static class Reuse
{
    public sealed record Ref(double W, double Beta, double Lo, double Hi);

    static Iv Integrate(Func<Iv, (Iv f, Iv f2)> g, Func<Iv, Iv> val, double a, double b, int cells)
    {
        if (b <= a) return Iv.Point(0);
        double h = (b - a) / cells; Iv s = Iv.Point(0), H = Iv.Point(h), H3 = H * H * H / 24.0;
        for (int k = 0; k < cells; k++)
        {
            double lo = a + k * h, hi = k == cells - 1 ? b : lo + h;
            s += H * val(Iv.Point(0.5 * (lo + hi))) + H3 * g(new Iv(lo, hi)).f2;
        }
        return s;
    }

    public static Ref Reference(double w, double beta, int cells = 20000)
    {
        // kink: (1 - w) x^2 + w x - (1 - w) = 0
        Iv W = Iv.Point(w), om = 1.0 - W;
        Iv xs = (-W + (W.Sqr() + 4.0 * om.Sqr()).Sqrt()) / (2.0 * om);
        // left of the kink the second branch is active, right of it the first
        (Iv f, Iv f2) Left(Iv x) { Iv e = (-beta * (om * (1.0 - x.Sqr()))).Exp(); Iv d1 = 2 * beta * om * x; return (e, (2 * beta * om + d1.Sqr()) * e); }
        (Iv f, Iv f2) Right(Iv x) { Iv e = (-beta * (W * x)).Exp(); return (e, (beta * w) * (beta * w) * e); }
        (Iv f, Iv f2) LeftX(Iv x) { var (e, e2) = Left(x); Iv d1 = 2 * beta * om * x * e; return (x * e, x * e2 + 2.0 * d1); }
        (Iv f, Iv f2) RightX(Iv x) { var (e, e2) = Right(x); return (x * e, x * e2 - 2.0 * (beta * w) * e); }
        double a = xs.Lo, b = xs.Hi;
        Iv Z = Integrate(Left, x => Left(x).f, 0, a, cells) + Integrate(Right, x => Right(x).f, b, 1, cells);
        Iv N = Integrate(LeftX, x => LeftX(x).f, 0, a, cells) + Integrate(RightX, x => RightX(x).f, b, 1, cells);
        Iv gap = new(0, b - a);                                          // integrand at most 1 and x at most 1 on the kink box
        Z += gap; N += gap;
        Iv r = N / Z; return new(w, beta, r.Lo, r.Hi);
    }

    // ---- sampling utilities (diagnostic floating point) ----
    static double Gamma(Random r, double a)
    {
        if (a < 1) return Gamma(r, a + 1) * Math.Pow(r.NextDouble(), 1 / a);
        double d = a - 1.0 / 3, c = 1 / Math.Sqrt(9 * d);
        while (true)
        {
            double x, v; do { x = Math.Sqrt(-2 * Math.Log(1 - r.NextDouble())) * Math.Cos(2 * Math.PI * r.NextDouble()); v = 1 + c * x; } while (v <= 0);
            v = v * v * v; double u = r.NextDouble();
            if (Math.Log(u) < 0.5 * x * x + d - d * v + d * Math.Log(v)) return d * v;
        }
    }
    static double LogGamma(double x)
    {
        double[] g = { 676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059, 12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7 };
        if (x < 0.5) return Math.Log(Math.PI / Math.Sin(Math.PI * x)) - LogGamma(1 - x);
        x -= 1; double a = 0.99999999999980993, t = x + 7.5;
        for (int i = 0; i < 8; i++) a += g[i] / (x + i + 1);
        return 0.5 * Math.Log(2 * Math.PI) + (x + 0.5) * Math.Log(t) - t + Math.Log(a);
    }

    public sealed record Run(int Seed, int Observed, double[] SupErr);

    public static Run Simulate(int seed, IReadOnlyList<Ref> refs, int n = 20000)
    {
        var rnd = new Random(seed); var xs = new double[n]; var lq = new double[n]; var le = new double[n]; var inc = new bool[n];
        double mean = 0.5; int obs = 0;
        for (int i = 0; i < n; i++)
        {
            double a0 = 1 + 6 * mean, b0 = 1 + 6 * (1 - mean), x;
            if (rnd.NextDouble() < 0.2) x = rnd.NextDouble(); else { double g1 = Gamma(rnd, a0), g2 = Gamma(rnd, b0); x = g1 / (g1 + g2); }
            double lb = (a0 - 1) * Math.Log(x) + (b0 - 1) * Math.Log(1 - x) - (LogGamma(a0) + LogGamma(b0) - LogGamma(a0 + b0));
            double q0 = 0.2 + 0.8 * Math.Exp(lb), e = 0.25 + 0.75 * x;
            inc[i] = rnd.NextDouble() < e; if (inc[i]) obs++;
            xs[i] = x; lq[i] = Math.Log(q0); le[i] = Math.Log(e);
            mean += (x - mean) / (i + 2);
        }
        var sizes = new[] { 1000, 5000, 20000 }; var sup = new double[3];
        for (int si = 0; si < 3; si++)
        {
            int m = sizes[si];
            foreach (var rf in refs)
            {
                double sw = 0, swx = 0, mx = double.NegativeInfinity; var lw = new double[m];
                for (int i = 0; i < m; i++) if (inc[i]) { double T = Math.Max(rf.W * xs[i], (1 - rf.W) * (1 - xs[i] * xs[i])); lw[i] = -rf.Beta * T - lq[i] - le[i]; mx = Math.Max(mx, lw[i]); }
                for (int i = 0; i < m; i++) if (inc[i]) { double wt = Math.Exp(lw[i] - mx); sw += wt; swx += wt * xs[i]; }
                sup[si] = Math.Max(sup[si], Math.Abs(swx / sw - 0.5 * (rf.Lo + rf.Hi)));
            }
        }
        return new(seed, obs, sup);
    }
}
