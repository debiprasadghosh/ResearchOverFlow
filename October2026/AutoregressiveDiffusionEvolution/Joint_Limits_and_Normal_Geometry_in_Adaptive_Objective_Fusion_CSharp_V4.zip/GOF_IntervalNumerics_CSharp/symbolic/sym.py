import sympy as sp, mpmath as mp, json
mp.mp.dps=30; R=sp.Rational; out={}
# endpoint selection with scales: loss at u=0 is lam2/s2*1 (G2=1/s2), at u=1 is lam1/s1; select u=1 iff lam1/s1 < (1-lam1)/s2
l,s1,s2=sp.symbols('l s1 s2',positive=True)
thr=sp.solve(sp.Eq(l/s1,(1-l)/s2),l)[0]; out['endpoint_threshold']=str(sp.simplify(thr))   # P(lam1 < thr) = thr
# U = 2 sqrt(v1 v2)
v1,v2=sp.symbols('v1 v2',positive=True); U=2*sp.sqrt(v1*v2)
out['U_product']=str(sp.simplify(sp.diff(U,v1)*sp.diff(U,v2)))
# (12) constants
k,p=sp.symbols('k p',positive=True); r=sp.symbols('r',positive=True)
out['eq12_gamma_identity']=str(sp.simplify(sp.integrate(sp.exp(-r)*sp.diff(r**(k/p),r),(r,0,sp.oo))))
H=sp.Matrix([[3,1],[1,2]]); x1,x2=sp.symbols('x1 x2',real=True)
Cg=sp.integrate(sp.integrate(sp.exp(-(sp.Matrix([x1,x2]).T*H*sp.Matrix([x1,x2]))[0]/2),(x1,-sp.oo,sp.oo)),(x2,-sp.oo,sp.oo))
out['eq12_gauss']=[str(sp.simplify(Cg)),str(sp.simplify(2*sp.pi/sp.sqrt(H.det())))]
c=sp.symbols('c',positive=True); u=sp.symbols('u',real=True)
out['fig2_C_s']=str(sp.integrate(sp.exp(-c*sp.Abs(u)),(u,-sp.oo,sp.oo)))
# Lambert-W latent mode (13), c = 1
modes={}
for b in [10,100,1000,10**6]:
    w=mp.lambertw(4*b).real; z=-w/2
    asym=-mp.log(b)/2+mp.log(mp.log(b))/2-mp.log(4)/2
    modes[str(b)]=[mp.nstr(z,15),mp.nstr(asym,15),mp.nstr(z-asym,6)]
out['latent_modes']=modes
# cosine scales for T = 16
T=16; sig=[mp.sin(mp.pi*t/(2*T)) for t in range(1,T)]
out['n_sigma_ge']=sum(1 for s in sig if s>=1/mp.sqrt(2)-mp.mpf('1e-25')); out['n_sigma_gt']=sum(1 for s in sig if s>1/mp.sqrt(2)+mp.mpf('1e-25'))
t,TT=sp.symbols('t T',positive=True)
out['ratio_identity']=bool(sp.simplify(sp.sin(sp.pi*2*t/(2*TT))-2*sp.cos(sp.pi*t/(2*TT))*sp.sin(sp.pi*t/(2*TT)))==0)
out['candidates']=[(1200-50)//(kk+1) for kk in (4,15,0)]
# cone example, IGD, frozen rank
eps=R(1,10); out['cone']=[[str(a+eps*(a+b)),str(b+eps*(a+b))] for a,b in [(0,1),(R(1,100),0)]]
Kq=sp.symbols('K',positive=True); out['cone_bound_check']=str(sp.solve(sp.Eq((1+eps)/eps,Kq),Kq))
out['igd']=str(sp.N(sp.sqrt(1+R(1,400)),10))
bb=8; out['frozen']=[str(sp.N(R(3,5)*sp.exp(-bb)/(R(2,5)+R(3,5)*sp.exp(-bb)),8)),str(sp.N(sp.exp(-bb)/R(2,5),8))]
# NMI null bias example
out['nmi_bias_B8_n1200']=float(49/(2*1200*mp.log(8)))
# Second-order zero-set correction for S=(1+s^2)|v| on [-1,1]^2, Gaussian reference phi(s)phi(v):
# Z(s) ∝ phi(s) (2/c)(1 + f''(0)/(f(0) beta^2 c^2) + ...) with f = phi, f''(0)/f(0) = -1
pinf=lambda s: mp.npdf(s)/(1+s*s)
Zi=mp.quad(pinf,[-1,0,1]); m2=mp.quad(lambda s: pinf(s)/(1+s*s)**2,[-1,0,1])/Zi
kappa=mp.quad(lambda s: pinf(s)*abs(1/(1+s*s)**2-m2),[-1,-mp.sqrt(1/mp.sqrt(m2)-1),0,mp.sqrt(1/mp.sqrt(m2)-1),1])/Zi
out['kappa']=mp.nstr(kappa,12); out['m2']=mp.nstr(m2,12)
out['l1_pred']={b:mp.nstr(kappa/b**2,8) for b in (5,20,80)}
# exact L1 by high-precision quadrature (diagnostic)
def l1(b):
    D=lambda c: 1-mp.quad(lambda tt: mp.exp(-tt-tt*tt/(2*(b*c)**2)),[0,b*c])
    f=lambda s: pinf(s)*(1-D(1+s*s))
    Zb=mp.quad(f,[-1,0,1])
    return mp.quad(lambda s: abs(f(s)/Zb-pinf(s)/Zi),[-1,-0.5,0,0.5,1])
mp.mp.dps=20
out['l1_mp']={b:mp.nstr(l1(b),10) for b in (5,20,80)}
# LIS (Baik–Deift–Johansson) finite-n correction: mean depth ≈ 2 sqrt(m) - 1.7711 m^(1/6), m = n v1 v2
tw_mean=mp.mpf('-1.7710868074')
corr={}
for n in (10**3,10**4,10**5):
    corr[n]={str(v):mp.nstr((2*mp.sqrt(n*v[0]*v[1])+tw_mean*(n*v[0]*v[1])**(mp.mpf(1)/6))/mp.sqrt(n),8) for v in [(1,1),(0.5,0.5),(1,0.25)]}
out['lis_corrected_mean']=corr
json.dump(out,open('sym.json','w'),indent=1); print(json.dumps(out,indent=1))
