namespace DwgIntervals;

/// <summary>Proposition 9: order sensitivity of G layer maps T_j = I - eta H_j, enumerated over all G! orders
/// with interval matrix-vector products. Reference order: identity (H_1 applied first).</summary>
public static class Order
{
    public const int G = 8, K = 4;
    public static double[][,] Hessians(ulong seed)
    {
        var rng = new SplitMix(seed); var vals = new[] { -1.0, -0.5, 0.0, 0.5, 1.0 };
        var hs = new double[G][,];
        for (int g = 0; g < G; g++)
        {
            var r = new double[K, K];
            for (int i = 0; i < K; i++) for (int j = 0; j < K; j++) r[i, j] = vals[rng.Below(5)];
            var h = new double[K, K];
            for (int i = 0; i < K; i++) for (int j = 0; j < K; j++)
            { double s = i == j ? 0.25 : 0; for (int l = 0; l < K; l++) s += r[l, i] * r[l, j]; h[i, j] = s; }   // dyadic, exact
            hs[g] = h;
        }
        return hs;
    }
    static Iv[] Apply(double[,] h, double eta, Iv[] x)
    {
        var y = new Iv[K];
        for (int i = 0; i < K; i++) { var s = x[i]; for (int j = 0; j < K; j++) s = s - (eta * h[i, j]) * x[j]; y[i] = s; }  // eta dyadic: eta*h exact
        return y;
    }
    static Iv Norm(Iv[] v) { var s = Iv.Point(0); foreach (var e in v) s = s + e.Sqr(); return s.Max0().Sqrt(); }
    static double Frob(double[,] a) { var s = Iv.Point(0); foreach (var e in a) s = s + Iv.Point(e).Sqr(); return s.Max0().Sqrt().Hi; }
    static double[,] Comm(double[,] a, double[,] b)
    {
        var c = new double[K, K];
        for (int i = 0; i < K; i++) for (int j = 0; j < K; j++) { double s = 0; for (int l = 0; l < K; l++) s += a[i, l] * b[l, j] - b[i, l] * a[l, j]; c[i, j] = s; } // dyadic exact
        return c;
    }
    static IEnumerable<int[]> Perms(int[] a, int k = 0)
    {
        if (k == a.Length) { yield return (int[])a.Clone(); yield break; }
        for (int i = k; i < a.Length; i++) { (a[k], a[i]) = (a[i], a[k]); foreach (var p in Perms(a, k + 1)) yield return p; (a[k], a[i]) = (a[i], a[k]); }
    }
    public sealed record Row(double Eta, double[] MaxDev, double[] MaxDevOverEta2, double BoundOverEta2, double SharpBoundOverEta2, double Remainder3);
    public sealed record Res(List<Row> Rows, double[] SecondOrderCoef, double CommutatorSumFrob, double[] NormX, int Orders);
    public static Res Run(ulong seed)
    {
        var hs = Hessians(seed);
        var x = new[] { 1.0, -0.5, 0.25, 1.0 }.Select(Iv.Point).ToArray();
        var perms = Perms(Enumerable.Range(0, G).ToArray()).ToList();
        // exact second-order coefficient: max over orders of || sum_{flipped pairs i<j} [H_i,H_j] x ||
        var comm = new double[G, G][,];
        for (int i = 0; i < G; i++) for (int j = 0; j < G; j++) comm[i, j] = Comm(hs[i], hs[j]);
        double commSum = 0; for (int i = 0; i < G; i++) for (int j = i + 1; j < G; j++) commSum += Frob(comm[i, j]);
        var secs = new List<Iv>();
        foreach (var p in perms)
        {
            var pos = new int[G]; for (int r = 0; r < G; r++) pos[p[r]] = r;
            var v = new Iv[K]; for (int i = 0; i < K; i++) v[i] = Iv.Point(0);
            for (int i = 0; i < G; i++) for (int j = i + 1; j < G; j++)
                if (pos[j] < pos[i])
                    for (int a = 0; a < K; a++) for (int b = 0; b < K; b++) v[a] = v[a] + comm[i, j][a, b] * x[b];
            secs.Add(Norm(v));
        }
        var second = new Iv(secs.Max(q => q.Lo), secs.Max(q => q.Hi));
        double[] hn = hs.Select(Frob).ToArray(); var nx = Norm(x);
        var rows = new List<Row>();
        for (int e = 2; e <= 16; e++)
        {
            double eta = Math.ScaleB(1.0, -e);
            Iv[] Run1(int[] p) { var y = x; foreach (var g in p) y = Apply(hs[g], eta, y); return y; }
            var refv = Run1(Enumerable.Range(0, G).ToArray());
            var devs = new Iv[perms.Count];
            Parallel.For(0, perms.Count, i => { var y = Run1(perms[i]); var d = new Iv[K]; for (int a = 0; a < K; a++) d[a] = y[a] - refv[a]; devs[i] = Norm(d); });
            double lo = devs.Max(d => d.Lo), hi = devs.Max(d => d.Hi);
            // rigorous bound: eta^2 * sum_{i<j} ||[H_i,H_j]|| ||x|| + 2 R3 ||x||, R3 = prod(1+eta h_i) - 1 - eta e1 - eta^2 e2
            var prod = Iv.Point(1); var e1 = Iv.Point(0); var e2 = Iv.Point(0);
            for (int i = 0; i < G; i++) { var t = eta * Iv.Point(hn[i]); e2 = e2 + e1 * t; e1 = e1 + t; prod = prod * (1.0 + t); }
            var r3 = (prod - 1.0 - e1 - e2).Max0();
            var bound = (eta * eta) * Iv.Point(commSum) * nx + 2.0 * r3 * nx;
            double e2v = eta * eta;
            rows.Add(new Row(eta, new[] { lo, hi }, new[] { (Iv.Point(lo) / e2v).Lo, (Iv.Point(hi) / e2v).Hi }, (bound / e2v).Hi, ((eta * eta) * Iv.Point(second.Hi) / e2v + 2.0 * r3 * nx / e2v).Hi, r3.Hi));
        }
        return new Res(rows, new[] { second.Lo, second.Hi }, commSum, new[] { nx.Lo, nx.Hi }, perms.Count);
    }
}
