namespace DwgIntervals;

/// <summary>Second-order interval automatic differentiation: value, first and second derivative enclosures.</summary>
public readonly record struct D2(Iv V, Iv D, Iv DD)
{
    public static D2 Var(Iv x) => new(x, Iv.Point(1), Iv.Point(0));
    public static D2 operator +(D2 a, D2 b) => new(a.V + b.V, a.D + b.D, a.DD + b.DD);
    public static D2 operator -(D2 a, D2 b) => new(a.V - b.V, a.D - b.D, a.DD - b.DD);
    public static D2 operator -(double s, D2 a) => new(s - a.V, -a.D, -a.DD);
    public static D2 operator -(D2 a) => new(-a.V, -a.D, -a.DD);
    public static D2 operator *(double s, D2 a) => new(s * a.V, s * a.D, s * a.DD);
    public D2 Exp() { var e = V.Exp(); return new(e, e * D, e * (DD + D.Sqr())); }
    public D2 Log() => new(V.Log(), D / V, (DD * V - D.Sqr()) / V.Sqr());
}

/// <summary>Certified enclosure of (2) through its one-dimensional form
/// E[N_nd] = n/(M-1)! * int_0^inf (1-e^{-t})^{n-1} t^{M-1} e^{-t} dt  (product of M uniforms = e^{-Gamma(M,1)}).
/// Composite midpoint rule on [t0,T] with interval second-derivative remainder h^3 f''(X)/24 per cell;
/// [0,t0] and [T,inf) are bounded by monotone envelopes.</summary>
public static class Quadrature
{
    static D2 Phi(D2 t, int n, int M)
    {
        var g = (double)(n - 1) * (1.0 - (-t).Exp()).Log();
        var p = M > 1 ? g + (double)(M - 1) * t.Log() : g;
        return p - t;
    }
    public sealed record Result(int M, double[] Enclosure, double Width, double HeadBound, double TailBound, int Cells);
    public static Result Run(int n, int M, double t0, double T, int cells)
    {
        double fact = 1; for (int k = 2; k < M; k++) fact *= k;            // exact for M <= 21
        var cst = Iv.Point(n) / Iv.Point(fact);
        double h = (T - t0) / cells;
        var sum = Iv.Point(0);
        for (int i = 0; i < cells; i++)
        {
            double a = t0 + i * h, b = (i == cells - 1) ? T : t0 + (i + 1) * h;
            var w = Iv.Point(b) - Iv.Point(a);
            var m = 0.5 * (Iv.Point(a) + Iv.Point(b));                      // enclosure of the true midpoint
            // midpoint value: f at an enclosure of the exact midpoint, remainder uses the full cell
            var fm = Phi(D2.Var(m), n, M).Exp();
            var fX = Phi(D2.Var(new Iv(a, b)), n, M).Exp();
            // f(m) encloses f at the exact real midpoint, since m encloses it; remainder w^3 f''(xi)/24 with xi in the cell
            var val = w * fm.V + (w.Sqr() * w) * fX.DD / 24.0;
            sum = sum + val;
        }
        // head: f increasing-envelope on [0,t0]: (1-e^{-t})^{n-1} t^{M-1} <= value at t0 and e^{-t} <= 1
        var head = Iv.Point(t0) * cst * ((double)(n - 1) * (1.0 - Iv.Point(-t0).Exp()).Log() + (M > 1 ? (double)(M - 1) * Iv.Point(t0).Log() : Iv.Point(0))).Exp();
        // tail: (1-e^{-t})^{n-1} <= 1 so integral <= n/(M-1)! Gamma(M,T) = n e^{-T} sum_{k<M} T^k/k!
        var gsum = Iv.Point(0); var term = Iv.Point(1);
        for (int k = 0; k < M; k++) { if (k > 0) term = term * T / (double)k; gsum = gsum + term; }
        var tail = Iv.Point(n) * Iv.Point(-T).Exp() * gsum;
        var tot = cst * sum + new Iv(0, head.Hi) + new Iv(0, tail.Hi);
        return new Result(M, new[] { tot.Lo, tot.Hi }, tot.Width, head.Hi, tail.Hi, cells);
    }
}

