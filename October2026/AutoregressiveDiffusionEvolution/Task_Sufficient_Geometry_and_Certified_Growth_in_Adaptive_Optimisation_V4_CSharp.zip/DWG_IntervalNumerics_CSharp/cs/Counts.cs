using System.Numerics;
namespace DwgIntervals;

/// <summary>Exact nonnegative rational with BigInteger parts (always reduced).</summary>
public readonly record struct Q(BigInteger N, BigInteger D)
{
    public static Q Of(BigInteger n, BigInteger d) { var g = BigInteger.GreatestCommonDivisor(n, d); if (d.Sign < 0) g = -g; return new(n / g, d / g); }
    public static Q operator +(Q a, Q b) => Of(a.N * b.D + b.N * a.D, a.D * b.D);
    public static Q operator -(Q a, Q b) => Of(a.N * b.D - b.N * a.D, a.D * b.D);
    public static Q operator /(Q a, BigInteger k) => Of(a.N, a.D * k);
    public static Q operator *(Q a, BigInteger k) => Of(a.N * k, a.D);
    /// <summary>Rigorous double enclosure: floor of N*2^s/D in BigInteger (about 60 bits), outward step, exact ScaleB.</summary>
    public Iv Enclose()
    {
        if (N.IsZero) return Iv.Point(0);
        if (N.Sign < 0) { var p = new Q(-N, D).Enclose(); return -p; }
        int s = 60 - (int)(N.GetBitLength() - D.GetBitLength());
        BigInteger num = s >= 0 ? N << s : N, den = s >= 0 ? D : D << -s;
        var fl = BigInteger.Divide(num, den);
        double lo = Math.BitDecrement((double)fl), hi = Math.BitIncrement((double)(fl + 1));
        return new Iv(Math.ScaleB(lo, -s), Math.ScaleB(hi, -s));   // power-of-two scaling is exact in range
    }
    public override string ToString() => $"{N}/{D}";
}

public static class Counts
{
    /// <summary>H_r(n) of (1), exact.</summary>
    public static Q H(int r, int n)
    {
        var h = Enumerable.Repeat(new Q(1, 1), n + 1).ToArray();
        for (int k = 0; k < r; k++)
        {
            var acc = new Q(0, 1); var nh = new Q[n + 1]; nh[0] = new Q(0, 1);
            for (int i = 1; i <= n; i++) { acc = acc + h[i] / i; nh[i] = acc; }
            h = nh;
        }
        return h[n];
    }
    /// <summary>Alternating representation sum_j (-1)^{j-1} C(n,j) j^{1-M}, exact.</summary>
    public static Q Alt(int n, int M)
    {
        var s = new Q(0, 1); BigInteger c = 1;
        for (int j = 1; j <= n; j++)
        {
            c = c * (n - j + 1) / j;
            var term = Q.Of(c, BigInteger.Pow(j, M - 1));
            s = (j % 2 == 1) ? s + term : s - term;
        }
        return s;
    }
    /// <summary>The same alternating sum evaluated in outward-rounded double intervals.</summary>
    public static Iv AltInterval(int n, int M)
    {
        var s = Iv.Point(0); var c = Iv.Point(1);
        for (int j = 1; j <= n; j++)
        {
            c = c * (double)(n - j + 1) / (double)j;
            var pw = Iv.Point(1); for (int k = 0; k < M - 1; k++) pw = pw * (double)j;
            var term = c / pw;
            s = (j % 2 == 1) ? s + term : s - term;
        }
        return s;
    }
    public sealed record Row(int M, string Fraction, double[] FracEncl, bool AltExactEqual, double[] AltIv, double AltIvWidth, bool AltIvContains,
                             double[] UnionLower, double[] MeanLower, double[] Upper);
    public static List<Row> Run(int n)
    {
        var rows = new List<Row>();
        foreach (int M in new[] { 2, 3, 5, 8, 12, 16, 20, 22, 24, 28, 32, 40 })
        {
            var e = Counts.H(M - 1, n); var f = Q.Of(e.N, e.D * n);
            var alt = Alt(n, M); bool eq = alt.N == e.N && alt.D == e.D;
            var ai = AltInterval(n, M); var ee = e.Enclose();
            var union = new Q(1, 1) - Q.Of((BigInteger)n * (n - 1), BigInteger.Pow(2, M));
            var meanLo = e - new Q(n - 1, 1);
            var up = Q.Of((e - new Q(1, 1)).N, (e - new Q(1, 1)).D * (n - 1));
            Iv Pos(Q q) => q.N.Sign <= 0 ? Iv.Point(0) : q.Enclose();
            rows.Add(new Row(M, f.Enclose().Mid.ToString("R"), new[] { f.Enclose().Lo, f.Enclose().Hi }, eq, new[] { ai.Lo, ai.Hi }, ai.Width,
                ai.Contains(ee.Lo) && ai.Contains(ee.Hi), new[] { Pos(union).Lo, Pos(union).Hi }, new[] { Pos(meanLo).Lo, Pos(meanLo).Hi }, new[] { up.Enclose().Lo, up.Enclose().Hi }));
        }
        return rows;
    }
}
