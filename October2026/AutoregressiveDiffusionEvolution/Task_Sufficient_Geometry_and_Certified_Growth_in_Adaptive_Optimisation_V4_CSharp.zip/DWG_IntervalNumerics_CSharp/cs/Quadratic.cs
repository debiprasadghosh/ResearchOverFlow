namespace DwgIntervals;

/// <summary>Proposition 10: certified optima and remaining gaps for the quadratic family (13)-(15) at the supplied
/// manuscript's sizes d = 1024 (Hadamard chart), k = 40, M = 200, eight clusters. All data are dyadic, so B_j, U and
/// tau are exact doubles; preferences are exact quotients w/sum(w) of stored doubles, enclosed by intervals.</summary>
public static class Quadratic
{
    public const int D = 1024, Kd = 40, M = 200, Clusters = 8;
    public sealed record Data(double[][,] B, double[][] Bv, double Tau, int[] Cluster, double[] Offset);
    static double U(int i, int c) => (System.Numerics.BitOperations.PopCount((uint)(i & c)) % 2 == 0 ? 1.0 : -1.0) / 32.0;

    public static Data Make(ulong seed)
    {
        var rng = new SplitMix(seed); var vals = new[] { -1.0, -0.5, 0.0, 0.5, 1.0 };
        var A = new double[Clusters][,]; var bc = new double[Clusters][];
        for (int c = 0; c < Clusters; c++)
        {
            A[c] = new double[Kd, Kd]; bc[c] = new double[Kd];
            for (int i = 0; i < Kd; i++) { bc[c][i] = vals[rng.Below(5)]; for (int j = 0; j < Kd; j++) A[c][i, j] = vals[rng.Below(5)] / 4.0; }
        }
        var B = new double[M][,]; var bv = new double[M][]; var cl = new int[M]; var off = new double[M];
        for (int m = 0; m < M; m++)
        {
            int c = m % Clusters; cl[m] = c; off[m] = 1e6 * (m + 1);
            var r = new double[Kd, Kd];
            for (int i = 0; i < Kd; i++) for (int j = 0; j < Kd; j++) r[i, j] = A[c][i, j] + vals[rng.Below(5)] / 16.0;
            var b = new double[Kd, Kd];
            for (int i = 0; i < Kd; i++) for (int j = 0; j < Kd; j++) { double s = 0; for (int l = 0; l < Kd; l++) s += r[l, i] * r[l, j]; b[i, j] = s; } // exact: dyadic, < 2^53 scale
            B[m] = b; bv[m] = new double[Kd];
            for (int i = 0; i < Kd; i++) bv[m][i] = bc[c][i] + vals[rng.Below(5)] / 8.0;
        }
        return new Data(B, bv, 0.25, cl, off);
    }

    public sealed record Pref(Iv[] Lam);
    public sealed record Sol(Iv[,] H, Iv[] b, Iv Tau, double[] Zt, Iv[] Z, double Eps);

    public static Sol Solve(Data dt, Iv[] lam)
    {
        var H = new Iv[Kd, Kd]; var b = new Iv[Kd]; var tau = Iv.Point(0);
        for (int i = 0; i < Kd; i++) { b[i] = Iv.Point(0); for (int j = 0; j < Kd; j++) H[i, j] = Iv.Point(0); }
        for (int m = 0; m < M; m++)
        {
            if (lam[m].Hi == 0) continue;
            tau = tau + lam[m] * dt.Tau;
            for (int i = 0; i < Kd; i++) { b[i] = b[i] + lam[m] * dt.Bv[m][i]; for (int j = 0; j < Kd; j++) H[i, j] = H[i, j] + lam[m] * dt.B[m][i, j]; }
        }
        for (int i = 0; i < Kd; i++) H[i, i] = H[i, i] + tau;
        // approximate solve by Cholesky of the midpoint matrix, one refinement step
        var Hm = new double[Kd, Kd]; for (int i = 0; i < Kd; i++) for (int j = 0; j < Kd; j++) Hm[i, j] = H[i, j].Mid;
        var L = Chol(Hm); var bm = b.Select(x => x.Mid).ToArray();
        var zt = CholSolve(L, bm);
        var res = new double[Kd]; for (int i = 0; i < Kd; i++) { double s = bm[i]; for (int j = 0; j < Kd; j++) s -= Hm[i, j] * zt[j]; res[i] = s; }
        var dz = CholSolve(L, res); for (int i = 0; i < Kd; i++) zt[i] += dz[i];
        // certified: r = b - H zt (interval, covers the exact preference); lambda_min(H) >= tau since sum lambda_j B_j is PSD
        var r2 = Iv.Point(0);
        for (int i = 0; i < Kd; i++) { var s = b[i]; for (int j = 0; j < Kd; j++) s = s - H[i, j] * zt[j]; r2 = r2 + s.Sqr(); }
        double eps = (r2.Max0().Sqrt() / tau).Hi;
        var Z = zt.Select(v => new Iv(Math.BitDecrement(v - eps), Math.BitIncrement(v + eps))).ToArray();  // Euclidean ball within this box
        return new Sol(H, b, tau, zt, Z, eps);
    }
    /// <summary>Numerator of (15) via the cancellation-free identity S(x) - S(x*) = (z-z*)' H (z-z*)/2 + tau |r|^2 / 2.</summary>
    public static Iv Excess(Sol s, Iv[] z, Iv rho)
    {
        var e = new Iv[Kd]; for (int i = 0; i < Kd; i++) e[i] = z[i] - s.Z[i];
        var q = Iv.Point(0);
        for (int i = 0; i < Kd; i++) { var v = Iv.Point(0); for (int j = 0; j < Kd; j++) v = v + s.H[i, j] * e[j]; q = q + e[i] * v; }
        return (0.5 * q.Max0() + 0.5 * s.Tau * rho).Max0();
    }
    public sealed record Design(string Name, Iv[] Z, Iv Rho, double[] Zd);

    static double[,] Chol(double[,] a)
    {
        int n = a.GetLength(0); var l = new double[n, n];
        for (int j = 0; j < n; j++)
        {
            double s = a[j, j]; for (int k = 0; k < j; k++) s -= l[j, k] * l[j, k]; l[j, j] = Math.Sqrt(s);
            for (int i = j + 1; i < n; i++) { double t = a[i, j]; for (int k = 0; k < j; k++) t -= l[i, k] * l[j, k]; l[i, j] = t / l[j, j]; }
        }
        return l;
    }
    static double[] CholSolve(double[,] l, double[] b)
    {
        int n = b.Length; var y = new double[n];
        for (int i = 0; i < n; i++) { double s = b[i]; for (int k = 0; k < i; k++) s -= l[i, k] * y[k]; y[i] = s / l[i, i]; }
        var x = new double[n];
        for (int i = n - 1; i >= 0; i--) { double s = y[i]; for (int k = i + 1; k < n; k++) s -= l[k, i] * x[k]; x[i] = s / l[i, i]; }
        return x;
    }

    static Design FromZ(string name, double[] z) => new(name, z.Select(Iv.Point).ToArray(), Iv.Point(0), z);
    static Design FromFull(string name, double[] x)
    {
        var z = new Iv[Kd]; var nz = Iv.Point(0);
        for (int c = 0; c < Kd; c++) { var s = Iv.Point(0); for (int i = 0; i < D; i++) s = s + U(i, c) * Iv.Point(x[i]); z[c] = s; nz = nz + s.Sqr(); }
        var nx = Iv.Point(0); foreach (var v in x) nx = nx + Iv.Point(v).Sqr();
        return new(name, z, (nx - nz).Max0(), z.Select(v => v.Mid).ToArray());
    }

    public sealed record SetResult(string Set, int Size, double[] MeanGap48, double[] MaxGap48, double[] MaxGapVertices, double[] MeanGapVertices, double[] DirMid, double[] VertMid, double MaxWidth);
    public sealed record Res(int Prefs, double MaxEps, double[] MinRefExcess, List<SetResult> Sets, double NaiveMaxRelErr, double[] RangeAllGaps, double Seconds);

    public static Res Run(ulong seed)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var dt = Make(seed); var rng = new SplitMix(seed ^ 0xABCDEF);
        Iv[] Normalize(double[] w) { var s = Iv.Point(0); foreach (var v in w) s = s + Iv.Point(v); return w.Select(v => Iv.Point(v) / s).ToArray(); }
        var dir = Enumerable.Range(0, 48).Select(_ => Normalize(Enumerable.Range(0, M).Select(_ => -Math.Log(rng.U())).ToArray())).ToList();
        var vert = Enumerable.Range(0, M).Select(j => Enumerable.Range(0, M).Select(i => Iv.Point(i == j ? 1 : 0)).ToArray()).ToList();
        var eq = Normalize(Enumerable.Repeat(1.0, M).ToArray());
        var clus = Enumerable.Range(0, Clusters).Select(c => Normalize(Enumerable.Range(0, M).Select(i => dt.Cluster[i] == c ? 1.0 : 0.0).ToArray())).ToList();

        var solEq = Solve(dt, eq);
        var comp = FromZ("equal-weight optimum", solEq.Zt);
        var designs = new List<Design> { FromZ("reference", new double[Kd]), comp,
            FromZ("0.5 x compromise", solEq.Zt.Select(v => 0.5 * v).ToArray()), FromZ("1.5 x compromise", solEq.Zt.Select(v => 1.5 * v).ToArray()) };
        for (int r = 0; r < 20; r++)
        {
            var x = new double[D];
            for (int i = 0; i < D; i++) x[i] = 0.01 * rng.Normal();
            for (int c = 0; c < Kd; c++) { double zc = solEq.Zt[c] + 0.3 * rng.Normal(); for (int i = 0; i < D; i++) x[i] += U(i, c) * zc; }
            designs.Add(FromFull($"random {r}", x));
        }
        var clusterOpt = clus.Select((l, c) => FromZ($"cluster {c} optimum", Solve(dt, l).Zt)).ToList();
        var sets = new (string name, List<Design> S)[] {
            ("reference + compromise", designs.Take(2).ToList()),
            ("+ scaled + 20 random", designs.ToList()),
            ("reference + compromise + 8 cluster optima", designs.Take(2).Concat(clusterOpt).ToList()) };

        var allPrefs = dir.Concat(vert).ToList();
        var sols = new Sol[allPrefs.Count];
        Parallel.For(0, allPrefs.Count, i => sols[i] = Solve(dt, allPrefs[i]));
        double maxEps = sols.Max(s => s.Eps);
        var refEx = sols.Select(s => Excess(s, designs[0].Z, designs[0].Rho)).ToArray();
        var minRef = new[] { refEx.Min(e => e.Lo), refEx.Min(e => e.Hi) };
        if (minRef[0] <= 0) throw new InvalidOperationException("reference denominator not certified positive");
        var results = new List<SetResult>(); double gLo = double.MaxValue, gHi = double.MinValue;
        foreach (var (name, S) in sets)
        {
            var g = new Iv[allPrefs.Count];
            Parallel.For(0, allPrefs.Count, p =>
            {
                Iv best = new(double.MaxValue, double.MaxValue);
                foreach (var x in S) { var ex = Excess(sols[p], x.Z, x.Rho); best = new Iv(Math.Min(best.Lo, ex.Lo), Math.Min(best.Hi, ex.Hi)); }
                g[p] = best / refEx[p];
            });
            Iv Mean(IEnumerable<Iv> v) { var a = v.ToArray(); var s = Iv.Point(0); foreach (var e in a) s = s + e; return s / (double)a.Length; }
            var gd = g.Take(48).ToArray(); var gv = g.Skip(48).ToArray();
            foreach (var e in g) { gLo = Math.Min(gLo, e.Lo); gHi = Math.Max(gHi, e.Hi); }
            var m48 = Mean(gd); var mv = Mean(gv);
            results.Add(new SetResult(name, S.Count, new[] { m48.Lo, m48.Hi }, new[] { gd.Max(e => e.Lo), gd.Max(e => e.Hi) },
                new[] { gv.Max(e => e.Lo), gv.Max(e => e.Hi) }, new[] { mv.Lo, mv.Hi }, gd.Select(e => e.Mid).ToArray(), gv.Select(e => e.Mid).ToArray(), g.Max(e => e.Width)));
        }
        // naive double evaluation with offsets c_j = 1e6 (j+1): S(x) - S(x*) directly, compromise design
        double maxRel = 0;
        for (int p = 0; p < 48; p++)
        {
            double Sx(double[] z) { double s = 0; for (int m = 0; m < M; m++) { double lm = allPrefs[p][m].Mid, q = 0; for (int i = 0; i < Kd; i++) { double v = 0; for (int j = 0; j < Kd; j++) v += dt.B[m][i, j] * z[j]; q += z[i] * (0.5 * v + 0.125 * z[i]) - dt.Bv[m][i] * z[i]; } s += lm * (q + dt.Offset[m]); } return s; }
            double naive = Sx(comp.Zd) - Sx(sols[p].Zt);
            var cert = Excess(sols[p], comp.Z, comp.Rho);
            maxRel = Math.Max(maxRel, Math.Abs(naive - cert.Mid) / cert.Mid);
        }
        return new Res(48, maxEps, minRef, results, maxRel, new[] { gLo, gHi }, sw.Elapsed.TotalSeconds);
    }
}
