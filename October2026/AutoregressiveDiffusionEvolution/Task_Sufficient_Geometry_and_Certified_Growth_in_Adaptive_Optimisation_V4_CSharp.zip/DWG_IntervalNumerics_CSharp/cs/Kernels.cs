namespace DwgIntervals;

/// <summary>Proposition 7: second-moment effective-size fraction rho = (E K)^2 / E K^2 for the kernel (4) with
/// Y ~ N(0, sigma^2 I_d) and a fixed independent query. log rho = -d kappa(c) - 2 s |q|^2 [1/(1+2c) - 1/(1+4c)],
/// s = 1/(2(1-a)), c = s a sigma^2, kappa(c) = log(1+2c) - log(1+4c)/2.</summary>
public static class Kernels
{
    public static Iv Dec(double x) => new(Math.BitDecrement(x), Math.BitIncrement(x));   // encloses a decimal literal
    public static Iv C(Iv a, Iv sigma) => a * sigma.Sqr() / (2.0 * (1.0 - a));
    public static Iv Kappa(Iv c) => (1.0 + 2.0 * c).Log() - 0.5 * (1.0 + 4.0 * c).Log();
    public static Iv LogRho(int d, Iv a, Iv sigma, Iv q2)
    {
        var s = 1.0 / (2.0 * (1.0 - a)); var c = s * a * sigma.Sqr();
        return -(double)d * Kappa(c) - 2.0 * s * q2 * (1.0 / (1.0 + 2.0 * c) - 1.0 / (1.0 + 4.0 * c));
    }
    public sealed record Cert(string Case, int Dim, double[] C, double[] Kappa, double[] LogRho, double[] Log10Rho);
    public static List<Cert> Certificates()
    {
        var l10 = Iv.Point(10).Log(); var list = new List<Cert>();
        void Add(string name, int d, Iv a, Iv sg, Iv q2)
        {
            var c = C(a, sg); var lr = LogRho(d, a, sg, q2);
            list.Add(new Cert(name, d, new[] { c.Lo, c.Hi }, new[] { Kappa(c).Lo, Kappa(c).Hi }, new[] { lr.Lo, lr.Hi }, new[] { (lr / l10).Lo, (lr / l10).Hi }));
        }
        Add("raw, q = 1", 1000, Dec(0.6), Dec(1.2), Iv.Point(1000));
        Add("raw, q = 0", 1000, Dec(0.6), Dec(1.2), Iv.Point(0));
        Add("chart k = 16, q = 0", 16, Dec(0.6), Iv.Point(1), Iv.Point(0));
        Add("chart k = 40, q = 0", 40, Dec(0.6), Iv.Point(1), Iv.Point(0));
        Add("chart k = 16, a = 0.1", 16, Dec(0.1), Iv.Point(1), Iv.Point(0));
        Add("raw, a = 0.01", 1000, Dec(0.01), Dec(1.2), Iv.Point(0));
        return list;
    }
    /// <summary>Largest dimension d with rho >= rho0 at q = 0: d <= log(1/rho0)/kappa(c); certified floor.</summary>
    public static (int lo, int hi) MaxDim(Iv c, Iv log1rho0) { var r = log1rho0 / Kappa(c); return ((int)Math.Floor(r.Lo), (int)Math.Floor(r.Hi)); }

    // ---- Monte Carlo diagnostic (not a certificate): ESS/n of normalized kernel weights, independent query
    public sealed record Mc(string Case, int Dim, int N, int Reps, double MeanEssFrac, double SeEssFrac, double MeanMaxWeight);
    public static Mc Simulate(string name, int d, double a, double sigma, double qval, int n, int reps, ulong seed)
    {
        double[] ess = new double[reps], mx = new double[reps];
        Parallel.For(0, reps, rep =>
        {
            var rng = new SplitMix(seed + (ulong)rep * 0x9E3779B97F4A7C15UL);
            var lk = new double[n]; double sa = Math.Sqrt(a);
            for (int i = 0; i < n; i++)
            {
                double s2 = 0;
                for (int j = 0; j < d; j++) { double y = sigma * rng.Normal(); double r = qval - sa * y; s2 += r * r; }
                lk[i] = -s2 / (2 * (1 - a));
            }
            double m = lk.Max(), s1 = 0, s2w = 0;
            foreach (var v in lk) { double w = Math.Exp(v - m); s1 += w; s2w += w * w; }
            ess[rep] = s1 * s1 / s2w / n; mx[rep] = 1.0 / s1;
        });
        double mean = ess.Average(), se = Math.Sqrt(ess.Select(e => (e - mean) * (e - mean)).Sum() / (reps - 1) / reps);
        return new Mc(name, d, n, reps, mean, se, mx.Average());
    }
}

/// <summary>SplitMix64 with Box-Muller normals (deterministic and dependency-free).</summary>
public sealed class SplitMix(ulong s)
{
    ulong state = s; double? spare;
    public ulong Next() { ulong z = state += 0x9E3779B97F4A7C15UL; z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL; z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL; return z ^ (z >> 31); }
    public double U() => ((Next() >> 11) + 0.5) * (1.0 / 9007199254740992.0);
    public double Normal()
    {
        if (spare is double v) { spare = null; return v; }
        double u1 = U(), u2 = U(), r = Math.Sqrt(-2 * Math.Log(u1));
        spare = r * Math.Sin(2 * Math.PI * u2); return r * Math.Cos(2 * Math.PI * u2);
    }
    public int Below(int k) => (int)(Next() % (ulong)k);
}
