using System.Diagnostics;
using System.Numerics;
using System.Text.Json;
using DwgIntervals;

var results = new Dictionary<string, object>(); var sw = Stopwatch.StartNew(); var t = Stopwatch.StartNew();
void Log(string k, object v) { results[k] = v; Console.WriteLine($"{k}: {JsonSerializer.Serialize(v)}  [{t.Elapsed.TotalSeconds:F1}s]"); t.Restart(); }

// 1. Exact counts, alternating sums, probability brackets (Proposition 6)
Log("counts", Counts.Run(200));
// 2. Certified one-dimensional quadrature of (2)
var quad = new List<object>();
foreach (int M in new[] { 2, 3, 5, 8, 12, 20 })
{
    var q = Quadrature.Run(200, M, 0.5, 100.0, 400_000); var ex = Counts.H(M - 1, 200).Enclose();
    quad.Add(new { q.M, q.Enclosure, q.Width, RelWidth = q.Width / ex.Mid, ContainsExact = q.Enclosure[0] <= ex.Lo && ex.Hi <= q.Enclosure[1], Exact = ex.Mid, q.HeadBound, q.TailBound, q.Cells });
}
Log("quadrature", quad);
// 3. Kernel effective size (Proposition 7)
Log("rho", Kernels.Certificates());
var l10 = Iv.Point(10).Log();
Log("maxdim_rho_0.1", new[] { 0.01, 0.05, 0.1, 0.25, 0.5, 0.75, 1.08 }.Select(c => { var r = Kernels.MaxDim(Kernels.Dec(c), l10); return new { c, r.lo, r.hi }; }).ToList());
var mc = new List<Kernels.Mc>();
foreach (int n in new[] { 200, 2000, 20000, 200000, 2000000 }) mc.Add(Kernels.Simulate("chart k=16", 16, 0.6, 1.0, 0.0, n, n >= 2000000 ? 60 : 200, 20261101UL + (ulong)n));
mc.Add(Kernels.Simulate("raw d=1000, q=1", 1000, 0.6, 1.2, 1.0, 200, 400, 777UL));
mc.Add(Kernels.Simulate("raw d=1000, q=0", 1000, 0.6, 1.2, 0.0, 200, 400, 778UL));
Log("mc", mc);
// 4. Partitioned-layer cost (Proposition 8), exact integers
var cost = new List<object>();
foreach (int L in new[] { 1, 2, 4, 8, 16, 32, 64, 200 })
    foreach (var (p, qd) in new[] { (0, 1), (1, 20), (1, 5), (1, 2), (9, 10) })
    {
        var num = 2 * qd + (L - 1) * p; // cost = num/qd
        cost.Add(new { L, phi = $"{p}/{qd}", cost = $"{num}/{qd}", candidates = (int)(BigInteger.Parse("1900") * qd / num), cheaperThanK5 = num < 5 * qd });
    }
Log("cost", cost);
// 5. Order sensitivity (Proposition 9)
Log("order", Order.Run(20261101UL));
// 6. Certified quadratic family (Proposition 10)
Log("quadratic", Quadratic.Run(20261101UL));
// 7. Hoeffding sample sizes with selection over m candidates
var hf = new List<object>();
foreach (var (eps, delta) in new[] { (0.05, 0.05), (0.02, 0.05), (0.05, 0.01) })
    foreach (int m in new[] { 1, 10, 100, 1000 })
    {
        var v = (Kernels.Dec(m) / Kernels.Dec(delta)).Log() / (2.0 * Kernels.Dec(eps).Sqr());
        hf.Add(new { eps, delta, m, enclosure = new[] { v.Lo, v.Hi }, N = Math.Ceiling(v.Lo) == Math.Ceiling(v.Hi) ? (int)Math.Ceiling(v.Hi) : -1 });
    }
Log("hoeffding", hf);
results["runtime"] = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription; results["seconds"] = sw.Elapsed.TotalSeconds;
File.WriteAllText("results.json", JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"written {sw.Elapsed.TotalSeconds:F1}s");
