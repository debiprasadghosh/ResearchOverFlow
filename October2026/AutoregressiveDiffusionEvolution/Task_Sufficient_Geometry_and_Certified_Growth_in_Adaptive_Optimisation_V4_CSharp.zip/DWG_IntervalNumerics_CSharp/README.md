# Deep, Wide and Growing V4: validated interval numerics

- cs/: .NET 8 C# program (no packages). `dotnet run -c Release` writes results.json (about 50 s, mostly the Monte Carlo diagnostic).
  Interval.cs (outward rounding), Counts.cs (BigInteger rationals, Proposition 6), Quadrature.cs (certified integral (19)),
  Kernels.cs (Proposition 7), Order.cs (Proposition 9, all 8! orders), Quadratic.cs (Proposition 10, d=1024, k=40, M=200).
- num/sym.py: SymPy 1.14 / mpmath 1.3 exact and symbolic checks -> sym.json.
- fig/figs.py: Figures 2-5 from cs/results.json and num/sym.json.
- build/: fragment sources and the docx assembly script.
Assumption: Math.Exp and Math.Log are accurate to within four ulps (results are widened accordingly).
