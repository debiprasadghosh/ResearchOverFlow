import json, numpy as np, matplotlib
from fractions import Fraction as F
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'font.family': 'DejaVu Sans'})
TEAL = '#1b5a6e'; RUST = '#a8532c'; GREY = '#9aa3aa'; DARK = '#444444'; GOLD = '#c39a2f'
R = json.load(open('../cs/results.json')); S = json.load(open('../num/sym.json'))
n = 200

# ---------- Figure 2: brackets and cancellation
h = [F(1)] * (n + 1); Hs = {1: F(1)}
for r in range(1, 40):
    acc = F(0); nh = [F(0)] * (n + 1)
    for i in range(1, n + 1): acc += h[i] / i; nh[i] = acc
    h = nh; Hs[r + 1] = h[n]          # Hs[M] = H_{M-1}(n)
Ms = np.arange(2, 41)
union = [max(0.0, float(1 - F(n * (n - 1), 2 ** int(M)))) for M in Ms]
meanlo = [max(0.0, float(Hs[int(M)] - (n - 1))) for M in Ms]
upper = [float((Hs[int(M)] - 1) / (n - 1)) for M in Ms]
frac = [float(Hs[int(M)] / n) for M in Ms]
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.6))
ax[0].fill_between(Ms, meanlo, upper, color=TEAL, alpha=0.15, lw=0)
ax[0].plot(Ms, upper, '-', color=TEAL, lw=1.4, label='Upper (E N − 1)/(n − 1)')
ax[0].plot(Ms, meanlo, '-', color=RUST, lw=1.4, label='Lower E N − n + 1')
ax[0].plot(Ms, union, '--', color=DARK, lw=1, label='Union bound')
ax[0].set_xlabel('Number of objectives, M'); ax[0].set_ylabel('Pr(all n = 200 nondominated)')
ax[0].set_title('A. Exact bracket under the product law', fontsize=9.5)
ax[0].legend(fontsize=6.6, frameon=False, loc='center right')
rows = R['counts']
ax[1].semilogy([r['M'] for r in rows], [r['AltIvWidth'] for r in rows], 'o-', color=RUST, ms=4, lw=1.2, label='Interval width, alternating sum')
ax[1].semilogy([r['M'] for r in rows], [n * float(r['Fraction']) for r in rows], 's-', color=TEAL, ms=3.5, lw=1.2, label='Exact value E N (rational)')
ax[1].set_xlabel('Number of objectives, M'); ax[1].set_ylabel('Magnitude')
ax[1].set_title('B. Intervals expose cancellation', fontsize=9.5)
ax[1].legend(fontsize=6.6, frameon=False, loc='upper right')
plt.tight_layout(); plt.savefig('fig2.png', dpi=300); plt.close()

# ---------- Figure 3: effective-size fraction
def logrho(d, c): return -d * (np.log1p(2 * c) - 0.5 * np.log1p(4 * c))
ds = np.arange(1, 1001)
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.6))
for c, col, ls in ((0.01, GREY, '-'), (0.05, GOLD, '-'), (0.25, TEAL, '-'), (0.75, TEAL, '--'), (1.08, RUST, '-')):
    ax[0].plot(ds, logrho(ds, c) / np.log(10), ls, color=col, lw=1.3, label=f'c = {c}')
ax[0].set_xscale('log'); ax[0].set_ylim(-140, 2); ax[0].set_xlabel('Key dimension d'); ax[0].set_ylabel('log₁₀ ρ  (q = 0)')
ax[0].set_title('A. Second-moment size decays in d', fontsize=9.5)
ax[0].legend(fontsize=6.6, frameon=False, loc='lower left')
mc = [m for m in R['mc'] if m['Case'].startswith('chart')]
rho16 = float(S['rho_chart16'])
ax[1].errorbar([m['N'] for m in mc], [m['MeanEssFrac'] for m in mc], yerr=[2 * m['SeEssFrac'] for m in mc], fmt='o-', color=TEAL, ms=4, lw=1.2, capsize=3, label='Chart k = 16: ESS/n (Monte Carlo)')
ax[1].axhline(rho16, color=TEAL, ls='--', lw=1, label=f'Certified ρ = 0.64⁸ = {rho16:.5f}')
raw = [m for m in R['mc'] if m['Case'].startswith('raw')]
ax[1].plot([200], [raw[0]['MeanEssFrac']], 'v', color=RUST, ms=6, label='Raw d = 1000 at n = 200 (ρ < 10⁻¹³⁶)')
ax[1].set_xscale('log'); ax[1].set_yscale('log'); ax[1].set_ylim(3e-3, 0.12)
ax[1].set_xlabel('Records n'); ax[1].set_ylabel('Effective-size fraction')
ax[1].set_title('B. Finite-n diagnostic approaches ρ', fontsize=9.5)
ax[1].legend(fontsize=6.4, frameon=False, loc='lower left')
plt.tight_layout(); plt.savefig('fig3.png', dpi=300); plt.close()

# ---------- Figure 4: partitioned layer cost and order sensitivity
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.6))
Ls = np.arange(1, 201)
for (p, q), col in (((1, 20), GOLD), ((1, 5), TEAL), ((1, 2), RUST), ((9, 10), DARK)):
    cnt = [(1900 * q) // (2 * q + (L - 1) * p) for L in Ls]
    ax[0].plot(Ls, cnt, color=col, lw=1.3, label=f'φ = {p}/{q}')
ax[0].axhline(380, color=GREY, ls='--', lw=1, label='Five full evaluations (380)')
ax[0].axvline(16, color=GREY, ls=':', lw=0.8)
ax[0].set_xscale('log'); ax[0].set_yscale('log'); ax[0].set_xlabel('Layers L partitioning M = 200 responses'); ax[0].set_ylabel('Affordable candidates')
ax[0].set_title('A. Cost depends on layers, not M', fontsize=9.5)
ax[0].legend(fontsize=6.4, frameon=False, loc='lower left')
rows = R['order']['Rows']; eta = [r['Eta'] for r in rows]
ax[1].plot(eta, [0.5 * sum(r['MaxDevOverEta2']) for r in rows], 'o-', color=TEAL, ms=3.5, lw=1.2, label='Certified max deviation / η²')
ax[1].plot(eta, [r['SharpBoundOverEta2'] for r in rows], '-', color=RUST, lw=1.2, label='Bound (23) / η²')
ax[1].plot(eta, [r['BoundOverEta2'] for r in rows], '--', color=DARK, lw=1, label='Pairwise bound (24) / η²')
c2 = 0.5 * sum(R['order']['SecondOrderCoef'])
ax[1].axhline(c2, color=GREY, ls=':', lw=1, label=f'Leading coefficient {c2:.2f}')
ax[1].set_xscale('log', base=2); ax[1].set_yscale('log'); ax[1].set_ylim(1, 2e5)
ax[1].set_xlabel('Step size η'); ax[1].set_ylabel('Deviation / η²')
ax[1].set_title('B. Layer-order sensitivity, 8! orders', fontsize=9.5)
ax[1].legend(fontsize=6.2, frameon=False, loc='upper left')
plt.tight_layout(); plt.savefig('fig4.png', dpi=300); plt.close()

# ---------- Figure 5: certified gaps per preference
Q = R['quadratic']['Sets']
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.6))
labs = ['Reference + compromise', '+ scaled + 20 random', 'Reference + compromise + 8 cluster optima']
cols = [RUST, GOLD, TEAL]; lss = ['-', ':', '-']
for s, lab, col, ls in zip(Q, labs, cols, lss):
    ax[0].plot(np.arange(1, 49), sorted(s['DirMid'], reverse=True), ls, color=col, lw=1.4, label=lab)
    ax[1].plot(np.arange(1, 201), sorted(s['VertMid'], reverse=True), ls, color=col, lw=1.4, label=lab)
ax[0].set_ylim(0, 1.05); ax[1].set_ylim(0, 1.05)
ax[0].set_xlabel('Dirichlet preference (sorted)'); ax[0].set_ylabel(r'Certified gap $g_\lambda$')
ax[0].text(24, 0.5, 'All three reporting sets\ncoincide on these preferences', ha='center', fontsize=7, color=DARK)
ax[0].set_title('A. 48 broad preferences', fontsize=9.5)
ax[1].set_xlabel('Single-response preference (sorted)'); ax[1].set_title('B. 200 extreme preferences', fontsize=9.5)
ax[1].legend(fontsize=6.4, frameon=False, loc='center left', bbox_to_anchor=(0.02, 0.62))
plt.tight_layout(); plt.savefig('fig5.png', dpi=300); plt.close()
print('ok')
