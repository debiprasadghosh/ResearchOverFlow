"""Exact/symbolic checks for Deep, Wide and Growing V4 (SymPy 1.14, mpmath 1.3)."""
import sympy as sp, mpmath as mp, json, itertools
mp.mp.dps = 40; R = sp.Rational; out = {}

# ---- Proposition 1 recursion (exact rationals) and alternating-sum identity (Proposition 6)
def H(r, n):
    h = [R(1)] * (n + 1)          # h[i] = H_0(i), i>=1
    for _ in range(r):
        acc = R(0); nh = [R(0)] * (n + 1)
        for i in range(1, n + 1):
            acc += h[i] / i; nh[i] = acc
        h = nh
    return h[n]
def alt(n, M):
    return sum((-1) ** (j - 1) * sp.binomial(n, j) * R(1, j ** (M - 1)) for j in range(1, n + 1))
n = 200
Ms = [2, 3, 5, 8, 12, 20]
fr = {}; agree = True
for M in Ms:
    e = H(M - 1, n); agree &= (e == alt(n, M)); fr[M] = mp.nstr(mp.mpf(e.p) / e.q / n, 12)
out['fractions_n200'] = fr; out['alt_equals_recursion'] = bool(agree)
# small symbolic cases of (2): n=3, M=2,3 by direct integration
u1, u2, u3, p, t = sp.symbols('u1 u2 u3 p t', positive=True)
I2 = 3 * sp.integrate(sp.integrate((1 - u1 * u2) ** 2, (u1, 0, 1)), (u2, 0, 1))
I3 = 3 * sp.integrate(sp.integrate(sp.integrate((1 - u1 * u2 * u3) ** 2, (u1, 0, 1)), (u2, 0, 1)), (u3, 0, 1))
out['integral2_n3'] = [str(I2), str(H(1, 3)), str(I3), str(H(2, 3))]
# one-dimensional representation: product of M uniforms has density (-log p)^{M-1}/(M-1)!
Mg = 3
I1d = sp.integrate(3 * (1 - p) ** 2 * (-sp.log(p)) ** (Mg - 1) / sp.factorial(Mg - 1), (p, 0, 1))
out['integral1d_n3_M3'] = str(sp.nsimplify(sp.simplify(I1d)))
# probability bracket (Proposition 6b) for n=200
br = []
for M in [8, 12, 16, 20, 22, 24, 28, 32, 40]:
    e = H(M - 1, n)
    lo = sp.Max(0, 1 - R(n * (n - 1), 2 ** M), e - n + 1)
    hi = (e - 1) / (n - 1)
    br.append([M, float(lo), float(hi)])
out['bracket_n200'] = br
out['M_union_ge_099'] = next(M for M in range(1, 80) if 1 - R(n * (n - 1), 2 ** M) >= R(99, 100))
out['M_union_ge_05'] = next(M for M in range(1, 80) if 1 - R(n * (n - 1), 2 ** M) >= R(1, 2))
# n=2 exactness of the union bound: P(N=2)=1-2*2^{-M}
out['lattice'] = [int(sp.binomial(h + 200 - 1, 199)) for h in (1, 2, 3)] + [int(sp.binomial(h + 7, 7)) for h in (2, 3, 4)]

# ---- Proposition 7: second-moment effective-size fraction of Gaussian kernels
a, s, sg, c, d, Q = sp.symbols('a s sigma c d Q', positive=True)
w, qq = sp.symbols('w q', real=True)
v = a * sg ** 2
# one-coordinate MGF check: E exp(-s (q-W)^2), W~N(0,v)
mgf = sp.integrate(sp.exp(-s * (qq - w) ** 2) * sp.exp(-w ** 2 / (2 * v)) / sp.sqrt(2 * sp.pi * v), (w, -sp.oo, sp.oo), conds='none')
target = (1 + 2 * s * v) ** sp.Rational(-1, 2) * sp.exp(-s * qq ** 2 / (1 + 2 * s * v))
out['mgf_check'] = bool(sp.simplify(sp.simplify(mgf / target) - 1) == 0)
kappa = sp.log(1 + 2 * c) - sp.log(1 + 4 * c) / 2
out['kappa_series'] = str(sp.series(kappa, c, 0, 4).removeO())
out['kappa_positive_derivative'] = str(sp.simplify(sp.diff(kappa, c)))
def logrho(dd, aa, sig, q2):
    aa = mp.mpf(aa); sig = mp.mpf(sig); ss = 1 / (2 * (1 - aa)); cc = ss * aa * sig ** 2
    return -dd * mp.log(1 + 2 * cc) + dd / 2 * mp.log(1 + 4 * cc) - 2 * ss * q2 * (1 / (1 + 2 * cc) - 1 / (1 + 4 * cc))
out['logrho_raw_q1'] = mp.nstr(logrho(1000, '0.6', '1.2', 1000), 15)
out['logrho_raw_q0'] = mp.nstr(logrho(1000, '0.6', '1.2', 0), 15)
out['logrho_chart16'] = mp.nstr(logrho(16, '0.6', '1', 0), 15)
out['rho_chart16'] = mp.nstr(mp.e ** logrho(16, '0.6', '1', 0), 15)
out['c_raw'] = mp.nstr(mp.mpf('0.6') * mp.mpf('1.44') / (2 * mp.mpf('0.4')), 10)

# ---- Proposition 8: partitioned layers cost
phi, L, K = sp.symbols('phi L K', nonnegative=True)
Ml = sp.symbols('M', positive=True)
cost = sp.expand(L * phi + L * (1 - phi) * (Ml / L) / Ml + 1)
out['layer_cost'] = str(sp.simplify(cost))
out['phi_threshold_L16_K5'] = str(sp.solve(sp.Eq(2 + 15 * phi, 5), phi)[0])
counts = {}
for LL in (16, 200):
    for ph in (R(0), R(1, 2), R(9, 10)):
        C = 2 + (LL - 1) * ph
        counts[f'L{LL}_phi{ph}'] = [str(C), int(sp.floor(R(1900) / C))]
out['layer_counts'] = counts

# ---- (8) commutator example exactly
H1 = sp.Matrix([[2, 1], [1, 2]]); H2 = sp.diag(1, 3); x = sp.Matrix([1, 2]); eta = R(1, 10)
I = sp.eye(2)
dv = (I - eta * H2) * (I - eta * H1) * x - (I - eta * H1) * (I - eta * H2) * x
out['comm_diff'] = [str(e) for e in dv]; out['comm_norm'] = str(sp.nsimplify(dv.norm()))
# Proposition 9 second-order term: product expansion for 3 symbolic noncommuting matrices
A1, A2, A3 = sp.symbols('A1 A2 A3', commutative=False); e = sp.symbols('eta')
prod = sp.expand((1 - e * A3) * (1 - e * A2) * (1 - e * A1))
prod2 = sp.expand((1 - e * A1) * (1 - e * A2) * (1 - e * A3))
out['order_diff_eta2'] = str(sp.expand(prod - prod2).coeff(e, 2))

# ---- Proposition 10: cancellation-free gap identity (symbolic, k=2 generic)
z1, z2, r1, zs1, zs2 = sp.symbols('z1 z2 r1 zs1 zs2', real=True)
h11, h12, h22, tau, cc0 = sp.symbols('h11 h12 h22 tau c0', real=True)
Hm = sp.Matrix([[h11, h12], [h12, h22]]); z = sp.Matrix([z1, z2]); b = Hm * sp.Matrix([zs1, zs2])
S = (z.T * Hm * z)[0] / 2 - (b.T * z)[0] + cc0 + tau / 2 * r1 ** 2
Sopt = S.subs({z1: zs1, z2: zs2, r1: 0})
e_ = z - sp.Matrix([zs1, zs2])
ident = (e_.T * Hm * e_)[0] / 2 + tau / 2 * r1 ** 2
out['gap_identity'] = bool(sp.expand(S - Sopt - ident) == 0)

# ---- Hoeffding sample sizes with selection over m harnesses
hs = {}
for eps_, delta_ in ((R(1, 20), R(1, 20)), (R(1, 50), R(1, 20)), (R(1, 20), R(1, 100))):
    for m_ in (1, 10, 100):
        val = mp.log(mp.mpf(m_) / (mp.mpf(delta_.p) / delta_.q)) / (2 * (mp.mpf(eps_.p) / eps_.q) ** 2)
        hs[f'eps{eps_}_delta{delta_}_m{m_}'] = [mp.nstr(val, 12), int(mp.ceil(val))]
out['hoeffding'] = hs
json.dump(out, open('sym.json', 'w'), indent=1); print(json.dumps(out, indent=1))
