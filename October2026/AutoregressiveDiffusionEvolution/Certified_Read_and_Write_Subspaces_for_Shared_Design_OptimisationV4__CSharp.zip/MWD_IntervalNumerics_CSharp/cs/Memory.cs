namespace MwdIntervals;

/// <summary>Proposition 8 and the random-span law (Proposition 9): certified closed forms and Monte Carlo diagnostics.</summary>
public static class Memory
{
    /// <summary>n * asymptotic variance of the finite-memory chart mean, Proposition 8:
    /// exp(a q^2/(1+a)) / sqrt(1-a^2) * [1 - 2 a rho^2/(1+a) + a rho^2 q^2 (1-a)^2/(1+a)^2].</summary>
    public static Iv AVar(Iv a, Iv rho, Iv q)
    {
        var onePa = 1.0 + a; var r2 = rho.Sqr(); var q2 = q.Sqr();
        var br = 1.0 - 2.0 * a * r2 / onePa + a * r2 * q2 * (1.0 - a).Sqr() / onePa.Sqr();
        return (a * q2 / onePa).Exp() / (1.0 - a.Sqr()).Sqrt() * br;
    }
    public static Iv Dec(double x) => new(Math.BitDecrement(x), Math.BitIncrement(x));
    public sealed record Mc(int N, int Reps, double Mean, double Sd, double PredSd, double[] OneRepEnclosure, double OneRepWidth, double[] Estimates);
    public static Mc Simulate(int n, int reps, ulong seed)
    {
        const double rho = 0.8, sa = 0.8, a = 0.64, q = 1.0; var est = new double[reps];
        Iv[] encl = new Iv[1];
        Parallel.For(0, reps, rep =>
        {
            var r = new SplitMix(seed + (ulong)rep * 7919UL);
            var y1 = new double[n]; var y2 = new double[n]; var lw = new double[n];
            for (int i = 0; i < n; i++) { y1[i] = r.Normal(); y2[i] = rho * y1[i] + Math.Sqrt(1 - rho * rho) * r.Normal(); double e = q - sa * y1[i]; lw[i] = -e * e / (2 * (1 - a)); }
            double m = lw.Max(), num = 0, den = 0;
            for (int i = 0; i < n; i++) { double w = Math.Exp(lw[i] - m); num += w * y2[i]; den += w; }
            est[rep] = num / den;
            if (rep == 0)
            {   // validated evaluation of (2) for the stored records of this replicate (log-sum-exp in intervals)
                var ni = Iv.Point(0); var di = Iv.Point(0); var ia = Iv.Point(0.64);
                for (int i = 0; i < n; i++)
                {
                    var e = 1.0 - Iv.Point(0.8) * Iv.Point(y1[i]);       // the stored kernel uses the doubles 0.8, 0.64
                    var w = (-(e.Sqr()) / (2.0 * (1.0 - ia)) - m).Exp();
                    ni = ni + w * Iv.Point(y2[i]); di = di + w;
                }
                encl[0] = ni / di;
            }
        });
        double mean = est.Average(), sd = Math.Sqrt(est.Sum(e => (e - mean) * (e - mean)) / (reps - 1));
        var pv = AVar(Dec(0.64), Dec(0.8), Iv.Point(1));
        return new Mc(n, reps, mean, sd, Math.Sqrt(pv.Mid / n), new[] { encl[0].Lo, encl[0].Hi }, encl[0].Width, est);
    }
    public sealed record SpanMc(int D, int N, int K, int Reps, double Mean, double Sd, double ExactMean, double ExactSd);
    public static SpanMc Span(int d, int n, int k, int reps, ulong seed)
    {
        var e = new double[reps];
        Parallel.For(0, reps, rep =>
        {
            var r = new SplitMix(seed + (ulong)rep * 104729UL);
            var pts = Enumerable.Range(0, n).Select(_ => Enumerable.Range(0, d).Select(_ => r.Normal()).ToArray()).ToArray();
            var mu = Enumerable.Range(0, d).Select(i => pts.Average(p => p[i])).ToArray();
            var q = Spectral.Mgs(pts.Select(p => p.Select((v, i) => v - mu[i]).ToArray()), 1e-8);
            double s = 0; foreach (var col in q) for (int i = 0; i < k; i++) s += col[i] * col[i];   // target = first k axes
            e[rep] = s / k;
        });
        double mean = e.Average(), sd = Math.Sqrt(e.Sum(x => (x - mean) * (x - mean)) / (reps - 1));
        int rr = Math.Min(n - 1, d);
        double em = (double)rr / d, ev = 2.0 * k * rr * (d - rr) * (d - k) / ((double)d * d * (d - 1) * (d + 2)) / (k * k);
        return new SpanMc(d, n, k, reps, mean, sd, em, Math.Sqrt(ev));
    }
}
