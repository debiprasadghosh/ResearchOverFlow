namespace MwdIntervals;

/// <summary>Dense and cyclic-chain companion families with d = 1024, a 40-dimensional active space spanned by
/// Sylvester-Hadamard columns scaled by 1/32 (exactly orthonormal), M = 200 objectives in eight groups of 25.
/// Charts: top six left singular vectors of eight adjoint gradients, as in the supplied experiment.
/// Since the embedding V is exactly orthonormal, U_i'U_j equals the product of the 40-coordinate charts identically.</summary>
public static class Charts
{
    public const int Act = 40, M = 200, Groups = 8, K = 6, S = 8;
    public sealed record Obj(int Group, int[] Coords, double[,] B, double[] C, double[][] Chart, double[] Sig, int Rank);

    static readonly double[] Vals = { -1.0, -0.5, 0.0, 0.5, 1.0 };
    public static List<Obj> Build(bool chain, ulong seed)
    {
        var rng = new SplitMix(seed); var objs = new List<Obj>();
        for (int j = 0; j < M; j++)
        {
            int g = j / 25;
            int[] coords = chain ? Enumerable.Range(5 * g, 5).Concat(Enumerable.Range(5 * ((g + 1) % Groups), 5)).ToArray() : Enumerable.Range(0, Act).ToArray();
            int m = coords.Length;
            var r = new double[m, m]; for (int a = 0; a < m; a++) for (int b = 0; b < m; b++) r[a, b] = Vals[rng.Below(5)];
            var B = new double[m, m];   // dyadic: R'R/64 + I/8, exact in double
            for (int a = 0; a < m; a++) for (int b = 0; b < m; b++) { double s = a == b ? 0.125 : 0; for (int t = 0; t < m; t++) s += r[t, a] * r[t, b] / 64.0; B[a, b] = s; }
            var c = Enumerable.Range(0, m).Select(_ => rng.Normal()).ToArray();
            // gradients at eight Gaussian designs, written in the 40 active coordinates
            var grads = new double[S][];
            for (int s = 0; s < S; s++)
            {
                var z = Enumerable.Range(0, m).Select(_ => rng.Normal()).ToArray();
                var gl = new double[m]; for (int a = 0; a < m; a++) { double v = 0; for (int b = 0; b < m; b++) v += B[a, b] * (z[b] - c[b]); gl[a] = v; }
                var full = new double[Act]; for (int a = 0; a < m; a++) full[coords[a]] = gl[a];
                grads[s] = full;
            }
            var (u, sig, rank) = Spectral.LeftSingular(grads, K);
            objs.Add(new Obj(g, coords, B, c, u, sig, rank));
        }
        return objs;
    }
    static double PowerIteration(double[][] u, double[][] w, int iters = 20)
    {
        int k = u.Length, l = w.Length; var m = new double[k, l];
        for (int i = 0; i < k; i++) for (int j = 0; j < l; j++) m[i, j] = Spectral.Dot(u[i], w[j]);
        var v = Enumerable.Repeat(1.0 / Math.Sqrt(l), l).ToArray(); double est = 0;
        for (int it = 0; it < iters; it++)
        {
            var mv = new double[k]; for (int i = 0; i < k; i++) for (int j = 0; j < l; j++) mv[i] += m[i, j] * v[j];
            est = Math.Sqrt(mv.Sum(x => x * x));
            var nv = new double[l]; for (int j = 0; j < l; j++) for (int i = 0; i < k; i++) nv[j] += m[i, j] * mv[i];
            double nn = Math.Sqrt(nv.Sum(x => x * x)); if (nn == 0) return est; v = nv.Select(x => x / nn).ToArray();
        }
        return est;
    }
    public sealed record Family(string Name, double[][] GroupMaxKappa, double[] KappaRangeWithin, double[] KappaRangeNeighbour, double[] KappaRangeFar,
        double MaxDefect, int Pairs, int PowerUnder1e3, double PowerMaxUnder, double[] RH, double MeanRH, double MinRH, double[] RankCounts, double Seconds, float[] PairKappa, float[] PairPower, double MaxKappaWidth);

    public static Family Run(bool chain, ulong seed)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var objs = Build(chain, seed);
        // certified orthonormality defect eta: eigenvalues of U'U within [1-eta, 1+eta]
        var defects = new double[M];
        Parallel.For(0, M, j => { var e = Spectral.Eigen(Spectral.Cross(objs[j].Chart, objs[j].Chart)); defects[j] = Math.Max(1 - e[0].Lo, e[^1].Hi - 1); });
        // certified overlaps for every pair
        var kap = new Iv[M, M]; var pw = new double[M, M];
        var pairs = new List<(int, int)>(); for (int i = 0; i < M; i++) for (int j = i + 1; j < M; j++) pairs.Add((i, j));
        Parallel.ForEach(pairs, p => { var (i, j) = p; kap[i, j] = Spectral.Norm2(Spectral.Cross(objs[i].Chart, objs[j].Chart)); pw[i, j] = PowerIteration(objs[i].Chart, objs[j].Chart); });
        var gm = new double[Groups][]; for (int g = 0; g < Groups; g++) gm[g] = new double[Groups];
        double[] within = { 1, 0 }, neigh = { 1, 0 }, far = { 1, 0 }; int under = 0; double maxUnder = 0;
        foreach (var (i, j) in pairs)
        {
            int gi = objs[i].Group, gj = objs[j].Group; var kv = kap[i, j];
            gm[gi][gj] = Math.Max(gm[gi][gj], kv.Hi); gm[gj][gi] = gm[gi][gj];
            int dist = Math.Min((gi - gj + Groups) % Groups, (gj - gi + Groups) % Groups);
            var tgt = gi == gj ? within : dist == 1 ? neigh : far; tgt[0] = Math.Min(tgt[0], kv.Lo); tgt[1] = Math.Max(tgt[1], kv.Hi);
            double u = kv.Lo - pw[i, j]; if (u > 1e-3) under++; maxUnder = Math.Max(maxUnder, u);
        }
        // certified curvature capture (13) for each objective's own Hessian (H = V B V', V exactly orthonormal)
        var rh = new double[2 * M];
        Parallel.For(0, M, j =>
        {
            var o = objs[j]; int m = o.Coords.Length;
            var Bi = new Iv[m, m]; for (int a = 0; a < m; a++) for (int b = 0; b < m; b++) Bi[a, b] = Iv.Point(o.B[a, b]);
            var ev = Spectral.Eigen(Bi); var top = Iv.Point(0); for (int t = 0; t < K; t++) top = top + ev[m - 1 - t];
            var num = Iv.Point(0);
            foreach (var col in o.Chart)
            {
                var z = o.Coords.Select(cidx => Iv.Point(col[cidx])).ToArray();
                for (int a = 0; a < m; a++) { var s = Iv.Point(0); for (int b = 0; b < m; b++) s = s + o.B[a, b] * z[b]; num = num + z[a] * s; }
            }
            var r = num / top; rh[2 * j] = r.Lo; rh[2 * j + 1] = r.Hi;
        });
        var mids = Enumerable.Range(0, M).Select(j => 0.5 * (rh[2 * j] + rh[2 * j + 1])).ToArray();
        var ranks = new double[S + 1]; foreach (var o in objs) ranks[o.Rank]++;
        return new Family(chain ? "chain" : "dense", gm, within, neigh, far, defects.Max(), pairs.Count, under, maxUnder, mids, mids.Average(),
            Enumerable.Range(0, M).Min(j => rh[2 * j]), ranks, sw.Elapsed.TotalSeconds, pairs.Select(p => (float)kap[p.Item1, p.Item2].Mid).ToArray(), pairs.Select(p => (float)pw[p.Item1, p.Item2]).ToArray(), pairs.Max(p => kap[p.Item1, p.Item2].Width));
    }
    /// <summary>The paper's counterexample: U = [e1,e2], W = [(e1+e3)/sqrt2, (e3-e1)/sqrt2].</summary>
    public static object Counterexample()
    {
        double h = 1 / Math.Sqrt(2);
        var u = new[] { new[] { 1.0, 0, 0, 0 }, new[] { 0, 1.0, 0, 0 } };
        var w = new[] { new[] { h, 0, h, 0 }, new[] { -h, 0, h, 0 } };
        var k = Spectral.Norm2(Spectral.Cross(u, w));
        return new { power = PowerIteration(u, w), certified = new[] { k.Lo, k.Hi } };
    }
    /// <summary>Proposition 10: certified singular values of a gradient matrix G (columns) from the eigenvalues of the
    /// augmented symmetric matrix [[0, G],[G', 0]], whose eigenvalues are +-sigma_i and zeros; no squaring of G.</summary>
    public static Iv[] SingularValues(double[][] g)
    {
        int s = g.Length, d = g[0].Length, n = d + s; var a = new Iv[n, n];
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) a[i, j] = Iv.Point(0);
        for (int c = 0; c < s; c++) for (int r = 0; r < d; r++) { a[d + c, r] = Iv.Point(g[c][r]); a[r, d + c] = a[d + c, r]; }
        var e = Spectral.Eigen(a, 1e-15, 400);
        return e.Reverse().Take(s).Select(x => new Iv(Math.Max(0, x.Lo), Math.Max(0, x.Hi))).ToArray();
    }
}
