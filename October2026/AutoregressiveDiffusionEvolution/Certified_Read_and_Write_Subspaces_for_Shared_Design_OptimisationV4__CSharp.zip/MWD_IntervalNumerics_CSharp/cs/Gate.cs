namespace MwdIntervals;

/// <summary>Gate study for (10). Constraint g(x) = h(U'x) + eps sin(v'x) - c with h = log-sum-exp (1-Lipschitz in the
/// Euclidean norm), d = 1000, k = 6. Write charts W_i = cos(theta_i) U O_i + sin(theta_i) N_i, so every principal
/// cosine equals cos(theta_i). Three gates are compared against the certified sign of g at the new design.</summary>
public static class Gate
{
    const int D = 1000, Kc = 6, Charts = 50;
    static Iv Lse(Iv[] z) { double m = z.Max(t => t.Mid); var s = Iv.Point(0); foreach (var t in z) s = s + (t - m).Exp(); return s.Log() + m; }
    static Iv[] Proj(double[][] u, double[] x) => u.Select(col => { var s = Iv.Point(0); for (int i = 0; i < D; i++) s = s + Iv.MulPP(col[i], x[i]); return s; }).ToArray();
    static Iv[] ProjIv(double[][] u, Iv[] x) => u.Select(col => { var s = Iv.Point(0); for (int i = 0; i < D; i++) s = s + col[i] * x[i]; return s; }).ToArray();
    static Iv NormIv(Iv[] v) { var s = Iv.Point(0); foreach (var e in v) s = s + e.Sqr(); return s.Max0().Sqrt(); }
    static Iv DotIv(double[] a, double[] b) { var s = Iv.Point(0); for (int i = 0; i < a.Length; i++) s = s + Iv.MulPP(a[i], b[i]); return s; }

    public sealed record Bin(double Kappa, int Moves, int Violating, int[] Accept, int[] FalseAccept, int[] SafeAccepted, int Safe);
    public sealed record Res(int Moves, int Undecided, double Eps, double[] NormV, double MaxEtaW, double MaxKappaErr, int[] Accept, int[] FalseAccept, int[] SafeAccepted, int Safe, int Violating, int RepairMoves, int[] FalseAcceptRepair, List<Bin> Bins, double Seconds);

    public static Res Run(ulong seed, int movesPerChart)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew(); var rng = new SplitMix(seed); const double eps = 0.05;
        double[] Gauss(int n) => Enumerable.Range(0, n).Select(_ => rng.Normal()).ToArray();
        var U = Spectral.Mgs(Enumerable.Range(0, Kc).Select(_ => Gauss(D)));
        var v0 = Gauss(D); double vn = Math.Sqrt(Spectral.Dot(v0, v0)); var v = v0.Select(x => x / vn).ToArray();
        var normV = DotIv(v, v).Max0().Sqrt();
        var W = new double[Charts][][]; var kap = new Iv[Charts]; var eta = new double[Charts]; var thetaCos = new double[Charts];
        for (int c = 0; c < Charts; c++)
        {
            double ct = c / (double)(Charts - 1), st = Math.Sqrt(Math.Max(0, 1 - ct * ct)); thetaCos[c] = ct;
            var O = Spectral.Mgs(Enumerable.Range(0, Kc).Select(_ => Gauss(Kc)));
            var N = Spectral.Mgs(U.Concat(Enumerable.Range(0, Kc).Select(_ => Gauss(D)))).Skip(Kc).ToArray();
            W[c] = Enumerable.Range(0, Kc).Select(a => Enumerable.Range(0, D).Select(i => { double s = 0; for (int b = 0; b < Kc; b++) s += U[b][i] * O[a][b]; return ct * s + st * N[a][i]; }).ToArray()).ToArray();
            kap[c] = Spectral.Norm2(Spectral.Cross(U, W[c]));
            var e = Spectral.Eigen(Spectral.Cross(W[c], W[c])); eta[c] = Math.Max(1 - e[0].Lo, e[^1].Hi - 1);
        }
        double maxKappaErr = Enumerable.Range(0, Charts).Max(c => Math.Max(Math.Abs(kap[c].Hi - thetaCos[c]), Math.Abs(kap[c].Lo - thetaCos[c])));
        int total = Charts * movesPerChart;
        var acc = new int[3]; var fa = new int[3]; var sa = new int[3]; var faRep = new int[3]; int safe = 0, viol = 0, und = 0, rep = 0;
        var bins = new List<Bin>(); var locker = new object();
        var seeds = Enumerable.Range(0, Charts).Select(c => rng.Next()).ToArray();
        Parallel.For(0, Charts, c =>
        {
            var r = new SplitMix(seeds[c]); var bAcc = new int[3]; var bFa = new int[3]; var bSa = new int[3]; var bFaRep = new int[3]; int bSafe = 0, bViol = 0, bUnd = 0, bRep = 0;
            double kHi = kap[c].Hi / Math.Sqrt(1 - eta[c]);   // Proposition 7 correction
            kHi = Math.BitIncrement(kHi);
            for (int mv = 0; mv < movesPerChart; mv++)
            {
                var x = Enumerable.Range(0, D).Select(_ => 0.3 * r.Normal()).ToArray();
                var gx = Lse(Proj(U, x)) + eps * DotIv(v, x).Sin();
                double delta = 0.5 * r.U(); double cLim = gx.Mid + delta;
                var gOld = gx - cLim;                                          // validated old interval, about -delta
                double s = r.U(); var coef = Enumerable.Range(0, Kc).Select(_ => r.Normal()).ToArray(); double cn = Math.Sqrt(coef.Sum(t => t * t));
                var step = new double[D]; for (int a = 0; a < Kc; a++) { double ca = s * coef[a] / cn; for (int i = 0; i < D; i++) step[i] += ca * W[c][a][i]; }
                bool repair = r.U() < 0.3; var rv = new double[D];
                if (repair) { var q = Enumerable.Range(0, D).Select(_ => r.Normal() / Math.Sqrt(D)).ToArray(); for (int b = 0; b < Kc; b++) { double zb = r.Normal() / Math.Sqrt(Kc); for (int i = 0; i < D; i++) q[i] += zb * U[b][i]; } double qn = Math.Sqrt(q.Sum(t => t * t)); for (int i = 0; i < D; i++) rv[i] = 0.4 * s * q[i] / qn; }   // about half its energy in span(U)
                var xnew = new double[D]; for (int i = 0; i < D; i++) xnew[i] = x[i] + step[i] + rv[i];
                // truth: certified sign of g at the stored new design
                var gNew = Lse(Proj(U, xnew)) + eps * DotIv(v, xnew).Sin() - cLim;
                bool isViol = gNew.Lo > 0, isSafe = gNew.Hi <= 0;
                if (!isViol && !isSafe) { bUnd++; continue; }
                // actual displacement as stored, in intervals
                var dlt = new Iv[D]; for (int i = 0; i < D; i++) dlt[i] = Iv.Point(xnew[i]) - Iv.Point(x[i]);
                var nomNorm = NormIv(step.Select(Iv.Point).ToArray());
                bool A = kap[c].Mid <= 0.15 && gOld.Hi <= 0;                                  // overlap threshold, uncertified
                var bNom = (kHi + eps * normV.Hi) * nomNorm;                                   // Proposition 2 with nominal move only
                bool Bg = (gOld + bNom).Hi <= 0;
                var bTot = NormIv(ProjIv(U, dlt)) + eps * normV * NormIv(dlt);                // complete displacement
                bool Cg = (gOld + bTot).Hi <= 0;
                bool[] g3 = { A, Bg, Cg };
                if (isViol) bViol++; else bSafe++; if (repair) bRep++;
                for (int t = 0; t < 3; t++) if (g3[t]) { bAcc[t]++; if (isViol) { bFa[t]++; if (repair) bFaRep[t]++; } else bSa[t]++; }
            }
            lock (locker)
            {
                for (int t = 0; t < 3; t++) { acc[t] += bAcc[t]; fa[t] += bFa[t]; sa[t] += bSa[t]; faRep[t] += bFaRep[t]; }
                safe += bSafe; viol += bViol; und += bUnd; rep += bRep;
                bins.Add(new Bin(thetaCos[c], movesPerChart, bViol, bAcc, bFa, bSa, bSafe));
            }
        });
        return new Res(total, und, eps, new[] { normV.Lo, normV.Hi }, eta.Max(), maxKappaErr, acc, fa, sa, safe, viol, rep, faRep, bins.OrderBy(b => b.Kappa).ToList(), sw.Elapsed.TotalSeconds);
    }
}
