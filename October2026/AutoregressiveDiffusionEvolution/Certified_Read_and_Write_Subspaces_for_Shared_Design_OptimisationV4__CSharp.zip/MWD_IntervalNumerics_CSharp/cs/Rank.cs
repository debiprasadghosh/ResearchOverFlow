namespace MwdIntervals;

/// <summary>Proposition 10: rank information from adjoint gradients with a declared error bound ||E||_2 <= nu.</summary>
public static class Rank
{
    public sealed record Row(string Case, double Nu, double[][] Sigma, int CertifiedLowerRank, int NumericalRank, int UndecidedAt1e6);
    public static List<Row> Run(ulong seed)
    {
        var rng = new SplitMix(seed); const int d = 40, s = 8; var rows = new List<Row>();
        var vals = new[] { -1.0, -0.5, 0.0, 0.5, 1.0 };
        // full-rank quadratic ridge, rank-one quadratic, and quartic sampled on one axis
        var r = new double[d, d]; for (int a = 0; a < d; a++) for (int b = 0; b < d; b++) r[a, b] = vals[rng.Below(5)];
        var B = new double[d, d]; for (int a = 0; a < d; a++) for (int b = 0; b < d; b++) { double v = a == b ? 0.125 : 0; for (int t = 0; t < d; t++) v += r[t, a] * r[t, b] / 64.0; B[a, b] = v; }
        var cvec = Enumerable.Range(0, d).Select(_ => rng.Normal()).ToArray();
        var zs = Enumerable.Range(0, s).Select(_ => Enumerable.Range(0, d).Select(_ => rng.Normal()).ToArray()).ToArray();
        var cases = new (string, double[][])[]
        {
            ("quadratic, B full rank", zs.Select(z => Enumerable.Range(0, d).Select(a => Enumerable.Range(0, d).Sum(b => B[a, b] * z[b])).ToArray()).ToArray()),
            ("(c'z)^2, rank one", zs.Select(z => { double t = 2 * Spectral.Dot(cvec, z); return cvec.Select(x => t * x).ToArray(); }).ToArray()),
            ("sum z^4 on one axis", zs.Select(z => { var g = new double[d]; g[0] = 4 * z[0] * z[0] * z[0]; return g; }).ToArray())
        };
        foreach (var (name, g0) in cases)
            foreach (double nu in new[] { 0.0, 1e-9, 1e-6, 1e-3 })
            {
                var g = g0.Select(col => col.Select(x => x + nu * (2 * rng.U() - 1) / Math.Sqrt(d * s)).ToArray()).ToArray();   // ||E||_F <= nu
                var sig = Charts.SingularValues(g);
                int certLower = sig.Count(x => x.Lo > nu);
                int numRank = Spectral.LeftSingular(g, s).rank;
                int und = sig.Count(x => x.Contains(1e-6));
                rows.Add(new Row(name, nu, sig.Select(x => new[] { x.Lo, x.Hi }).ToArray(), certLower, numRank, und));
            }
        return rows;
    }
}
