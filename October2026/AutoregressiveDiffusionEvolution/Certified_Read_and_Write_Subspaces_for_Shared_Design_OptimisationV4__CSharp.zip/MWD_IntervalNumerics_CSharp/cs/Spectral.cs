namespace MwdIntervals;

/// <summary>Proposition 6: certified eigenvalue counts of symmetric interval matrices by interval LDL' inertia,
/// and eigenvalue enclosures by certified bisection. Only the lower triangle is read, so the certificate covers
/// every symmetric matrix whose lower-triangle entries lie in the given intervals.</summary>
public static class Spectral
{
    /// <summary>Number of eigenvalues below t, certified for every member; null if some pivot interval contains zero.</summary>
    public static int? CountBelow(Iv[,] a, double t)
    {
        int n = a.GetLength(0); var l = new Iv[n, n]; var dg = new Iv[n]; int neg = 0;
        for (int j = 0; j < n; j++)
        {
            var s = a[j, j] - t;
            for (int m = 0; m < j; m++) s = s - l[j, m].Sqr() * dg[m];
            if (s.Lo <= 0 && s.Hi >= 0) return null;
            dg[j] = s; if (s.Hi < 0) neg++;
            for (int i = j + 1; i < n; i++)
            {
                var u = a[i, j];
                for (int m = 0; m < j; m++) u = u - l[i, m] * l[j, m] * dg[m];
                l[i, j] = u / s;
            }
        }
        return neg;
    }
    /// <summary>Gershgorin hull of all eigenvalues of every member.</summary>
    public static (double lo, double hi) Gershgorin(Iv[,] a)
    {
        int n = a.GetLength(0); double lo = double.MaxValue, hi = double.MinValue;
        for (int i = 0; i < n; i++)
        {
            var r = Iv.Point(0); for (int j = 0; j < n; j++) if (j != i) r = r + (i > j ? a[i, j] : a[j, i]).Abs();
            lo = Math.Min(lo, (a[i, i] - r.Hi).Lo); hi = Math.Max(hi, (a[i, i] + r.Hi).Hi);
        }
        return (lo, hi);
    }
    /// <summary>Enclosures of all eigenvalues, ascending. Counts use the congruent matrix X'(A - tI)X, where X holds
    /// approximate eigenvectors of mid(A) and is certified nonsingular (Sylvester's law of inertia); this keeps the
    /// interval LDL' pivots close to lambda_i - t. Each [lo,hi] satisfies count(lo) &lt;= i and count(hi) &gt;= i+1.</summary>
    public static Iv[] Eigen(Iv[,] a, double relTol = 1e-13, int maxIter = 200)
    {
        int n = a.GetLength(0); var (glo, ghi) = Gershgorin(a);
        var mid = new double[n, n]; for (int i = 0; i < n; i++) for (int j = 0; j <= i; j++) { mid[i, j] = a[i, j].Mid; mid[j, i] = mid[i, j]; }
        var x = Jacobi(mid).vecs;                                    // x[c] is column c
        var g = new Iv[n, n]; var ax = new Iv[n, n]; var bx = new Iv[n, n];
        for (int i = 0; i < n; i++) for (int c = 0; c < n; c++) { var s = Iv.Point(0); for (int k = 0; k < n; k++) s = s + (i >= k ? a[i, k] : a[k, i]) * x[c][k]; ax[i, c] = s; }
        for (int r = 0; r < n; r++) for (int c = 0; c <= r; c++)
        {
            var s = Iv.Point(0); var u = Iv.Point(0);
            for (int k = 0; k < n; k++) { s = s + x[r][k] * ax[k, c]; u = u + Iv.MulPP(x[r][k], x[c][k]); }
            bx[r, c] = s; bx[c, r] = s; g[r, c] = u; g[c, r] = u;
        }
        if (Gershgorin(g).lo <= 0) throw new InvalidOperationException("approximate eigenvector matrix not certified nonsingular");
        int? Count(double t)
        {
            var m = new Iv[n, n]; for (int r = 0; r < n; r++) for (int c = 0; c <= r; c++) { m[r, c] = bx[r, c] - t * g[r, c]; m[c, r] = m[r, c]; }
            return CountBelow(m, 0.0);
        }
        double span = Math.Max(Math.Abs(glo), Math.Abs(ghi)) + 1e-300;
        glo -= 1e-12 * span + 1e-300; ghi += 1e-12 * span + 1e-300;
        var res = new Iv[n];
        for (int i = 0; i < n; i++)
        {
            double lo = glo, hi = ghi;
            for (int it = 0; it < maxIter && hi - lo > relTol * span; it++)
            {
                double t = 0.5 * (lo + hi); int? c = null;
                foreach (var f in new[] { 0.5, 0.45, 0.55, 0.4, 0.6 }) { t = lo + f * (hi - lo); c = Count(t); if (c != null) break; }
                if (c == null) break;
                if (c.Value >= i + 1) hi = t; else lo = t;
            }
            res[i] = new Iv(lo, hi);
        }
        return res;
    }
    /// <summary>Gram matrix X'Y (columns) as an interval matrix from double data.</summary>
    public static Iv[,] Cross(double[][] x, double[][] y)
    {
        var g = new Iv[x.Length, y.Length];
        for (int i = 0; i < x.Length; i++) for (int j = 0; j < y.Length; j++)
        { var s = Iv.Point(0); var xi = x[i]; var yj = y[j]; for (int t = 0; t < xi.Length; t++) s = s + Iv.MulPP(xi[t], yj[t]); g[i, j] = s; }
        return g;
    }
    public static Iv[,] AtA(Iv[,] m)
    {
        int r = m.GetLength(0), c = m.GetLength(1); var g = new Iv[c, c];
        for (int i = 0; i < c; i++) for (int j = 0; j <= i; j++) { var s = Iv.Point(0); for (int t = 0; t < r; t++) s = s + m[t, i] * m[t, j]; g[i, j] = s; g[j, i] = s; }
        return g;
    }
    /// <summary>Certified spectral norm enclosure of an interval matrix via the top eigenvalue of M'M.</summary>
    public static Iv Norm2(Iv[,] m) { var e = Eigen(AtA(m)); var top = e[^1]; return new Iv(Math.Max(0, top.Lo), top.Hi).Max0().Sqrt(); }

    // ---- double-precision helpers (not certified; certificates are computed afterwards)
    public static (double[] vals, double[][] vecs) Jacobi(double[,] s0)
    {
        int n = s0.GetLength(0); var a = (double[,])s0.Clone(); var v = new double[n, n]; for (int i = 0; i < n; i++) v[i, i] = 1;
        for (int sweep = 0; sweep < 100; sweep++)
        {
            double off = 0; for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++) off += a[i, j] * a[i, j];
            if (off < 1e-30) break;
            for (int p = 0; p < n; p++) for (int q = p + 1; q < n; q++)
            {
                if (Math.Abs(a[p, q]) < 1e-300) continue;
                double th = (a[q, q] - a[p, p]) / (2 * a[p, q]), t = Math.Sign(th == 0 ? 1 : th) / (Math.Abs(th) + Math.Sqrt(th * th + 1)), c = 1 / Math.Sqrt(t * t + 1), s = t * c;
                for (int k = 0; k < n; k++) { double akp = a[k, p], akq = a[k, q]; a[k, p] = c * akp - s * akq; a[k, q] = s * akp + c * akq; }
                for (int k = 0; k < n; k++) { double apk = a[p, k], aqk = a[q, k]; a[p, k] = c * apk - s * aqk; a[q, k] = s * apk + c * aqk; }
                for (int k = 0; k < n; k++) { double vkp = v[k, p], vkq = v[k, q]; v[k, p] = c * vkp - s * vkq; v[k, q] = s * vkp + c * vkq; }
            }
        }
        var idx = Enumerable.Range(0, n).OrderByDescending(i => a[i, i]).ToArray();
        return (idx.Select(i => a[i, i]).ToArray(), idx.Select(i => Enumerable.Range(0, n).Select(k => v[k, i]).ToArray()).ToArray());
    }
    /// <summary>Left singular vectors (columns as arrays) of G given as columns, top `want` with sigma above tolerance.
    /// One-sided (Hestenes) Jacobi SVD, accurate to about machine precision relative to ||G||, like a library SVD.</summary>
    public static (double[][] u, double[] sig, int rank) LeftSingular(double[][] gcols, int want, double rtol = 1e-10, double atol = 1e-12)
    {
        int s = gcols.Length; var c = gcols.Select(x => (double[])x.Clone()).ToArray();
        for (int sweep = 0; sweep < 60; sweep++)
        {
            bool rot = false;
            for (int p = 0; p < s; p++) for (int q = p + 1; q < s; q++)
            {
                double al = Dot(c[p], c[p]), be = Dot(c[q], c[q]), ga = Dot(c[p], c[q]);
                if (Math.Abs(ga) <= 1e-15 * Math.Sqrt(al * be) || ga == 0) continue;
                rot = true;
                double ze = (be - al) / (2 * ga), t = Math.Sign(ze == 0 ? 1 : ze) / (Math.Abs(ze) + Math.Sqrt(1 + ze * ze)), cs = 1 / Math.Sqrt(1 + t * t), sn = cs * t;
                for (int i = 0; i < c[p].Length; i++) { double x = c[p][i], y = c[q][i]; c[p][i] = cs * x - sn * y; c[q][i] = sn * x + cs * y; }
            }
            if (!rot) break;
        }
        var nrm = c.Select(x => Math.Sqrt(Dot(x, x))).ToArray();
        var idx = Enumerable.Range(0, s).OrderByDescending(i => nrm[i]).ToArray();
        var sig = idx.Select(i => nrm[i]).ToArray();
        double thr = Math.Max(atol, rtol * sig[0]); int rank = sig.Count(x => x > thr);
        int k = Math.Min(want, rank);
        var u = idx.Take(k).Select(i => c[i].Select(x => x / nrm[i]).ToArray()).ToArray();
        return (u, sig, rank);
    }
    public static double Dot(double[] a, double[] b) { double s = 0; for (int i = 0; i < a.Length; i++) s += a[i] * b[i]; return s; }
    /// <summary>Modified Gram-Schmidt on columns, dropping columns below tol after orthogonalization.</summary>
    public static double[][] Mgs(IEnumerable<double[]> cols, double tol = 1e-10)
    {
        var q = new List<double[]>();
        foreach (var c0 in cols)
        {
            var c = (double[])c0.Clone(); double n0 = Math.Sqrt(Dot(c, c));
            for (int rep = 0; rep < 2; rep++) foreach (var b in q) { double p = Dot(b, c); for (int i = 0; i < c.Length; i++) c[i] -= p * b[i]; }
            double nn = Math.Sqrt(Dot(c, c)); if (nn <= tol * Math.Max(1, n0)) continue;
            for (int i = 0; i < c.Length; i++) c[i] /= nn; q.Add(c);
        }
        return q.ToArray();
    }
}
