using System.Diagnostics;
using System.Text.Json;
using MwdIntervals;

var results = new Dictionary<string, object>(); var sw = Stopwatch.StartNew(); var t = Stopwatch.StartNew();
void Log(string k, object v) { results[k] = v; var s = JsonSerializer.Serialize(v); Console.WriteLine($"{k}: {(s.Length > 1500 ? s[..1500] + "..." : s)}  [{t.Elapsed.TotalSeconds:F1}s]"); t.Restart(); }

Log("counterexample", Charts.Counterexample());
Log("dense", Charts.Run(false, 20261101UL));
Log("chain", Charts.Run(true, 20261102UL));
Log("rank", Rank.Run(20261103UL));
Log("gate", Gate.Run(20261104UL, 2000));
// Proposition 8: certified n*Var at the paper's example and over a grid of queries
Log("avar_example", new { a = 0.64, rho = 0.8, q = 1, enclosure = new[] { Memory.AVar(Memory.Dec(0.64), Memory.Dec(0.8), Iv.Point(1)).Lo, Memory.AVar(Memory.Dec(0.64), Memory.Dec(0.8), Iv.Point(1)).Hi } });
var grid = new List<object>();
foreach (var a in new[] { 0.36, 0.64, 0.9 })
    for (int i = 0; i <= 40; i++)
    {
        double q = i * 0.1; var v = Memory.AVar(Memory.Dec(a), Memory.Dec(0.8), Memory.Dec(q));
        grid.Add(new { a, q, lo = v.Lo, hi = v.Hi, n001 = Math.Ceiling(v.Hi / 1e-4) });
    }
Log("avar_grid", grid);
Log("memory_mc", Memory.Simulate(200_000, 400, 20261105UL));
Log("span_mc", new[] { Memory.Span(80, 20, 6, 20000, 20261106UL), Memory.Span(1000, 200, 6, 400, 20261107UL) });
results["runtime"] = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription; results["seconds"] = sw.Elapsed.TotalSeconds;
File.WriteAllText("results.json", JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"written {sw.Elapsed.TotalSeconds:F1}s");
