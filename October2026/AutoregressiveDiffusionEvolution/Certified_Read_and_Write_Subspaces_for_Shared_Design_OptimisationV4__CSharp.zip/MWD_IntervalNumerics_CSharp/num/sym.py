"""Exact/symbolic checks for Many Windows One Design V4 (SymPy 1.14, mpmath 1.3)."""
import sympy as sp, mpmath as mp, json
mp.mp.dps = 30; R = sp.Rational; out = {}
y1, y2, q, w = sp.symbols('y1 y2 q w', real=True)
rho, a = sp.symbols('rho a', positive=True)

# ---- (6): posterior mean and variance of the unobserved coordinate (Gaussian conditioning)
S = sp.Matrix([[1, rho, rho * sp.sqrt(a)], [rho, 1, rho * sp.sqrt(a)], [rho * sp.sqrt(a), rho * sp.sqrt(a), 1]])
# order (Y1, Y2, Q): Cov(Y1,Q)=sqrt(a), fix entry
S[0, 2] = S[2, 0] = sp.sqrt(a)
mean2 = sp.simplify(S[1, 2] / S[2, 2] * q)
var2 = sp.simplify(S[1, 1] - S[1, 2] ** 2 / S[2, 2])
out['eq6_mean'] = str(mean2); out['eq6_var'] = str(var2)
out['eq6_values'] = [str(mean2.subs({rho: R(4, 5), a: R(16, 25), q: 1})), str(var2.subs({rho: R(4, 5), a: R(16, 25)}))]

# ---- Proposition 8: asymptotic variance of the finite-memory chart mean (self-normalized)
# K(y1) = exp(-c (q - sqrt(a) y1)^2), c = 1/(2(1-a)); prior y1 ~ N(0,1), y2 | y1 ~ N(rho y1, 1 - rho^2)
c = sp.symbols('c', positive=True)
def tilt(cc):
    prec = 1 + 2 * cc * a
    mu = 2 * cc * sp.sqrt(a) * q / prec
    s2 = 1 / prec
    Z = prec ** sp.Rational(-1, 2) * sp.exp(-cc * q ** 2 / prec)
    return mu, s2, Z
# check the tilt normalizer symbolically by direct integration
cc = sp.symbols('cc', positive=True)
Zint = sp.integrate(sp.exp(-cc * (q - sp.sqrt(a) * y1) ** 2) * sp.exp(-y1 ** 2 / 2) / sp.sqrt(2 * sp.pi), (y1, -sp.oo, sp.oo), conds='none')
out['tilt_normalizer_ok'] = bool(sp.simplify(Zint / tilt(cc)[2] - 1) == 0)
c1 = 1 / (2 * (1 - a)); c2 = 1 / (1 - a)
mu1, s21, Z1 = tilt(c1); mu2, s22, Z2 = tilt(c2)
m = sp.simplify(rho * mu1)
out['finite_memory_limit_mean'] = str(m)
EK2dev = Z2 * ((1 - rho ** 2) + rho ** 2 * s22 + (rho * mu2 - m) ** 2)
avar = sp.simplify(EK2dev / Z1 ** 2)
out['avar_formula'] = str(avar)
vals = {rho: R(4, 5), a: R(16, 25), q: 1}
av = sp.nsimplify(sp.simplify(avar.subs(vals)))
out['avar_exact'] = str(av); out['avar_value'] = mp.nstr(mp.mpf(sp.N(av, 40)), 15)
se = mp.sqrt(mp.mpf(sp.N(av, 40)) / 200000)
out['se_n200000'] = mp.nstr(se, 10); out['z_reported_0.64108'] = mp.nstr((mp.mpf('0.64108') - mp.mpf('0.64')) / se, 6)
# small-check: a -> exact prior case q = 0
out['avar_q0'] = str(sp.simplify(avar.subs({q: 0})))

# ---- Proposition 9: variance of random-span captured energy (Haar projection moments)
d, r, k = sp.symbols('d r k', positive=True)
al, be = sp.symbols('alpha beta')
sol = sp.solve([sp.Eq(al * d ** 2 + 2 * be * d, r ** 2), sp.Eq(al * d + be * (d ** 2 + d), r)], [al, be], dict=True)[0]
alpha_, beta_ = sp.factor(sol[al]), sp.factor(sol[be])
var_tr = sp.factor(alpha_ * k ** 2 + 2 * beta_ * k - (r * k / d) ** 2)
out['haar_alpha'] = str(alpha_); out['haar_beta'] = str(beta_); out['var_trace'] = str(var_tr)
v80 = var_tr.subs({d: 80, r: 19, k: 6}) / 36
out['span_mean_80_19_6'] = str(R(19, 80)); out['span_var_80_19_6'] = str(sp.nsimplify(v80))
sd = mp.sqrt(mp.mpf(sp.N(v80, 40)))
out['span_sd'] = mp.nstr(sd, 10); out['span_se_200'] = mp.nstr(sd / mp.sqrt(200), 10)
out['span_z_reported'] = mp.nstr((mp.mpf('0.24108') - mp.mpf(19) / 80) / (sd / mp.sqrt(200)), 6)
# k = 1 check against Beta(r/2,(d-r)/2) variance
beta_var = (r / 2) * ((d - r) / 2) / ((d / 2) ** 2 * (d / 2 + 1))
out['k1_matches_beta'] = bool(sp.simplify(var_tr.subs(k, 1) - beta_var) == 0)
v_1000 = var_tr.subs({d: 1000, r: 199, k: 6}) / 36
out['span_mean_1000_199'] = str(R(199, 1000)); out['span_sd_1000_199_6'] = mp.nstr(mp.sqrt(mp.mpf(sp.N(v_1000, 40))), 10)

# ---- existing numbers
th = sp.symbols('theta')
out['prop2_example'] = [str(sp.Abs(sp.cos(t)) * 1) for t in (0, sp.pi / 3, sp.pi / 2)]
out['cost_15'] = str(2 + 199 * R(1, 2))
H = sp.diag(5, 1, 1); s = sp.symbols('s', real=True)
U = sp.Matrix([[1, 0], [0, sp.cos(s)], [0, sp.sin(s)]])
out['RH_tied'] = str(sp.simplify((U.T * H * U).trace() / 6))
x = sp.Matrix([1, 2]); T1 = lambda v: sp.Matrix([v[1], v[1]]); T2 = lambda v: sp.Matrix([v[0], v[0]])
out['T1T2'] = [str(list(T1(T2(x)))), str(list(T2(T1(x))))]
Uc = sp.Matrix([[1], [0], [0]]); X0 = sp.eye(3)
out['lemma1_cov'] = str((sp.eye(3) - Uc * Uc.T) * X0 * (sp.eye(3) - Uc * Uc.T).T + Uc * Uc.T)
M = sp.Matrix([[1, -1], [0, 0]]) / sp.sqrt(2)
out['power_counterexample'] = [str(list(M * sp.Matrix([1, 1]))), str(sp.sqrt(max((M.T * M).eigenvals().keys())))]
json.dump(out, open('sym.json', 'w'), indent=1); print(json.dumps(out, indent=1))
# simplified closed form of Proposition 8
simple = sp.exp(a * q ** 2 / (1 + a)) / sp.sqrt(1 - a ** 2) * (1 - 2 * a * rho ** 2 / (1 + a) + a * rho ** 2 * q ** 2 * (1 - a) ** 2 / (1 + a) ** 2)
out['avar_simplified_ok'] = all(abs(complex(sp.N((avar - simple).subs({a: aa, q: qq, rho: rr}), 30))) < 1e-25 for aa, qq, rr in ((R(16, 25), 1, R(4, 5)), (R(3, 10), 2, R(1, 2)), (R(9, 10), R(1, 10), R(99, 100)), (R(1, 2), 3, R(1, 3))))
out['avar_simplified_symbolic'] = bool(sp.simplify(sp.expand(avar - simple).subs(a, R(16, 25))) == 0)
json.dump(out, open('sym.json', 'w'), indent=1); print(out['avar_simplified_ok'], out['avar_simplified_symbolic'])
