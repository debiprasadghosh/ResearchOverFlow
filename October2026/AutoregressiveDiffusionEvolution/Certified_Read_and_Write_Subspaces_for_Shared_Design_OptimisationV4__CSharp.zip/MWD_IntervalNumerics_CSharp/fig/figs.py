import json, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'font.family': 'DejaVu Sans'})
TEAL = '#1b5a6e'; RUST = '#a8532c'; GREY = '#9aa3aa'; DARK = '#444444'; GOLD = '#c39a2f'
R = json.load(open('../cs/results.json')); S = json.load(open('../num/sym.json'))

# ---------- Figure 2: certified overlaps and power iteration
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.7))
G = np.array(R['chain']['GroupMaxKappa'])
im = ax[0].imshow(G, cmap='Blues', vmin=0, vmax=1)
for i in range(8):
    for j in range(8):
        v = G[i, j]; ax[0].text(j, i, '0' if v < 1e-100 else f'{v:.2f}', ha='center', va='center', fontsize=5.6, color='white' if v > 0.6 else DARK)
ax[0].set_xticks(range(8), [str(g + 1) for g in range(8)]); ax[0].set_yticks(range(8), [str(g + 1) for g in range(8)])
ax[0].set_xlabel('Group'); ax[0].set_ylabel('Group'); ax[0].set_title('A. Chain: certified max overlap', fontsize=9.5)
ax[0].spines[:].set_visible(False)
for fam, col, lab in (('dense', RUST, 'Dense'), ('chain', TEAL, 'Chain')):
    k = np.array(R[fam]['PairKappa']); p = np.array(R[fam]['PairPower'])
    ax[1].scatter(k, p, s=1.5, color=col, alpha=0.35, lw=0, label=f'{lab}, 19,900 pairs', rasterized=True)
ax[1].plot([0, 1], [0, 1], color=DARK, lw=0.8, ls='--', label='Certified value')
ax[1].set_xlim(0, 1.02); ax[1].set_ylim(0, 1.02)
ax[1].set_xlabel('Certified overlap κ'); ax[1].set_ylabel('Power iteration, 20 steps')
ax[1].set_title('B. A fixed start underestimates', fontsize=9.5)
lg = ax[1].legend(fontsize=6.6, frameon=False, loc='upper left', markerscale=6)
plt.tight_layout(); plt.savefig('fig2.png', dpi=300); plt.close()

# ---------- Figure 3: gate study
B = R['gate']['Bins']; kap = np.array([b['Kappa'] for b in B])
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.6))
labs = ['Overlap threshold 0.15', 'Nominal-move bound', 'Complete displacement (10)']
cols = [RUST, GOLD, TEAL]; mk = ['o', 's', '^']
for t in range(3):
    fa = np.array([b['FalseAccept'][t] for b in B]); n = np.array([b['Moves'] for b in B])
    ax[0].plot(kap, 100 * fa / n, mk[t] + '-', color=cols[t], ms=3, lw=1, label=labs[t])
    sa = np.array([b['SafeAccepted'][t] / b['Safe'] for b in B])
    ax[1].plot(kap, 100 * sa, mk[t] + '-', color=cols[t], ms=3, lw=1, label=labs[t])
ax[0].set_xlabel('Write overlap κ = cos θ'); ax[0].set_ylabel('Violating moves accepted (%)')
ax[0].set_title('A. False acceptances', fontsize=9.5); ax[0].legend(fontsize=6.4, frameon=False, loc='center right'); ax[0].set_ylim(-0.05, 1.75)
ax[1].set_xlabel('Write overlap κ = cos θ'); ax[1].set_ylabel('Safe moves accepted (%)')
ax[1].set_title('B. Acceptance of safe moves', fontsize=9.5); ax[1].set_ylim(0, 102)
plt.tight_layout(); plt.savefig('fig3.png', dpi=300); plt.close()

# ---------- Figure 4: certified singular values and curvature capture
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.6))
rows = [r for r in R['rank'] if r['Case'].startswith('(c')]
for r, col, mk_ in zip(rows, [DARK, GOLD, TEAL, RUST], ['o', 's', '^', 'D']):
    hi = np.array([s[1] for s in r['Sigma']]); nu = r['Nu']
    ax[0].semilogy(np.arange(1, 9), np.maximum(hi, 1e-16), mk_ + '-', color=col, ms=3.5, lw=1, label=f'ν = {nu:g}' if nu else 'ν = 0')
    if nu: ax[0].axhline(nu, color=col, lw=0.7, ls=':')
ax[0].set_xlabel('Index i'); ax[0].set_ylabel('Certified upper bound on σᵢ')
ax[0].set_title('A. Rank-one ridge, noisy adjoints', fontsize=9.5); ax[0].legend(fontsize=6.4, frameon=False, loc='upper right', ncol=2)
bins = np.linspace(0.65, 1.0, 36)
ax[1].hist(R['dense']['RH'], bins=bins, color=RUST, alpha=0.75, label='Dense, mean %.3f' % R['dense']['MeanRH'])
ax[1].hist(R['chain']['RH'], bins=bins, color=TEAL, alpha=0.75, label='Chain, mean %.3f' % R['chain']['MeanRH'])
ax[1].set_xlabel(r'Certified curvature capture $R_H$, (13)'); ax[1].set_ylabel('Objectives')
ax[1].set_title('B. Six-dimensional adjoint charts', fontsize=9.5); ax[1].legend(fontsize=6.6, frameon=False, loc='upper left')
plt.tight_layout(); plt.savefig('fig4.png', dpi=300); plt.close()

# ---------- Figure 5: finite-memory retrieval
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.6))
grid = R['avar_grid']
for a, col in ((0.36, GOLD), (0.64, TEAL), (0.9, RUST)):
    g = [x for x in grid if x['a'] == a]
    ax[0].semilogy([x['q'] for x in g], [x['hi'] for x in g], '-', color=col, lw=1.4, label=f'a = {a}')
ax[0].axvline(1, color=GREY, ls=':', lw=0.8)
ax[0].set_xlabel('Query q'); ax[0].set_ylabel('n × asymptotic variance')
ax[0].set_title('A. Records needed grow with the query', fontsize=9.5); ax[0].legend(fontsize=6.6, frameon=False, loc='upper left')
mc = R['memory_mc']; est = np.array(mc['Estimates'])
ax[1].hist(est, bins=28, density=True, color=TEAL, alpha=0.7, label='400 replicates, n = 200,000')
xs = np.linspace(est.min() - 0.002, est.max() + 0.002, 200); sd = mc['PredSd']
ax[1].plot(xs, np.exp(-(xs - 0.64) ** 2 / (2 * sd * sd)) / (sd * np.sqrt(2 * np.pi)), color=RUST, lw=1.3, label='Proposition 8 normal law')
ax[1].axvline(0.64108, color=DARK, ls='--', lw=1, label='Reported 0.64108')
ax[1].set_xlabel('Finite-memory chart mean'); ax[1].set_ylabel('Density')
ax[1].set_title('B. Sampling, not rounding, explains 0.64108', fontsize=9.5)
ax[1].legend(fontsize=6.0, frameon=False, loc='upper left'); ax[1].set_ylim(0, 330)
plt.tight_layout(); plt.savefig('fig5.png', dpi=300); plt.close()
print('ok')
