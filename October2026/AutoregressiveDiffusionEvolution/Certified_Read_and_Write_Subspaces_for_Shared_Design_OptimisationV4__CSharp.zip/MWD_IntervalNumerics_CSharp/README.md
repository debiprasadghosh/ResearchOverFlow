# Many Windows One Design V4: validated interval numerics

- cs/: .NET 8 C# program (no packages). `dotnet run -c Release` writes results.json (about 2.5 min).
  Interval.cs (outward rounding), Spectral.cs (Proposition 6: certified inertia counts and eigenvalue enclosures),
  Charts.cs (dense/chain companion families, certified overlaps, defects, curvature capture, singular values),
  Rank.cs (Proposition 8), Gate.cs (gate study, Section 4.6), Memory.cs (Propositions 9 and 10 with diagnostics), Rng.cs.
- num/sym.py: SymPy 1.14 / mpmath 1.3 exact and symbolic checks -> sym.json.
- fig/figs.py: Figures 2-5 from cs/results.json and num/sym.json.
- build/: fragment sources and the docx assembly script.
Assumption: Math.Exp, Math.Log and Math.Sin are accurate to within four ulps (results are widened accordingly).
