using System.Diagnostics;
using System.Text.Json;
using NsmIntervals;

var results = new Dictionary<string, object>(); var sw = Stopwatch.StartNew();
results["spea"] = Spea.Run(); Console.WriteLine(JsonSerializer.Serialize(results["spea"]));
results["escape"] = Escape.Run(); Console.WriteLine(JsonSerializer.Serialize(results["escape"]));
results["compression"] = Compression.Run(20261031); foreach (var r in (List<Compression.Row>)results["compression"]) Console.WriteLine(r);
var t = Stopwatch.StartNew(); results["retention"] = Retention.Run(); Console.WriteLine($"{JsonSerializer.Serialize(results["retention"])} {t.Elapsed.TotalSeconds:F1}s");
t.Restart(); var rf = ArchiveDemo.Reference(); results["archiveRef"] = rf; Console.WriteLine($"{rf} {t.Elapsed.TotalSeconds:F1}s");
t.Restart(); var runs = new ArchiveDemo.Run[200]; Parallel.For(0, 200, k => runs[k] = ArchiveDemo.Simulate(k + 1, rf));
double Q(IEnumerable<double> v, double p) { var a = v.OrderBy(x => x).ToArray(); return a[(int)Math.Round(p * (a.Length - 1))]; }
results["archiveDemo"] = new
{
    seeds = 200, observedMean = runs.Average(r => r.Observed),
    full1 = new[] { runs.Average(r => r.FullErr1), Q(runs.Select(r => r.FullErr1), 0.9) }, full2 = new[] { runs.Average(r => r.FullErr2), Q(runs.Select(r => r.FullErr2), 0.9) },
    arch1 = new[] { runs.Average(r => r.ArchiveErr1), Q(runs.Select(r => r.ArchiveErr1), 0.9) }, arch2 = new[] { runs.Average(r => r.ArchiveErr2), Q(runs.Select(r => r.ArchiveErr2), 0.9) },
    archIw1 = new[] { runs.Average(r => r.ArchiveIwErr1), Q(runs.Select(r => r.ArchiveIwErr1), 0.9) }, archIw2 = new[] { runs.Average(r => r.ArchiveIwErr2), Q(runs.Select(r => r.ArchiveIwErr2), 0.9) }
};
Console.WriteLine($"{JsonSerializer.Serialize(results["archiveDemo"])} {t.Elapsed.TotalSeconds:F1}s");
File.WriteAllText("archive_replicates.json", JsonSerializer.Serialize(runs));
results["runtime"] = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription; results["seconds"] = sw.Elapsed.TotalSeconds;
File.WriteAllText("results.json", JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"written {sw.Elapsed.TotalSeconds:F1}s");
