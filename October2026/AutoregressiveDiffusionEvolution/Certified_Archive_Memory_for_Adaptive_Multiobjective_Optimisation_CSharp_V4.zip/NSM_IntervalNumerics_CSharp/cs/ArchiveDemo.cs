namespace NsmIntervals;

/// <summary>Theorem 2 demonstration. Design y in [0,1]^2, F1 = y1, F2 = g - sqrt(y1 g), g = 1 + 9 y2 (a two-variable ZDT1).
/// Fixed target pi ∝ exp(-beta S) on the uniform reference, S = (F1 + F2)/2, beta = 4. The proposal is a defensive mixture:
/// with probability eps a uniform draw, otherwise a uniform box of half-width h around an archive record chosen by SPEA2-fitness
/// attention. The working archive has capacity K and SPEA2 environmental selection. Observation probability e(y) = 0.5 + 0.5 y1.</summary>
public static class ArchiveDemo
{
    public sealed record Ref(double Lo1, double Hi1, double Lo2, double Hi2);
    public sealed record Run(int Seed, int Observed, double FullErr1, double FullErr2, double ArchiveErr1, double ArchiveErr2, double ArchiveIwErr1, double ArchiveIwErr2);

    static double S(double y1, double y2) { double g = 1 + 9 * y2; return 0.5 * (y1 + g - Math.Sqrt(y1 * g)); }

    /// <summary>Certified reference means of y1 and y2. With y1 = u^2 and g = v^2 (v = sqrt(1 + 9 y2)), S = (u^2 + v^2 - u v)/2
    /// and dy1 dy2 = (4 u v / 9) du dv on u in [0,1], v in [1, sqrt 10]. Each cell integral is enclosed by the midpoint value
    /// plus an interval Hessian remainder; the sliver between the floating-point and true upper limit of v is bounded separately.</summary>
    public static Ref Reference(double beta = 4, int cells = 2000)
    {
        double V = Math.BitDecrement(Math.Sqrt(10)), Vhi = Math.BitIncrement(Math.BitIncrement(Math.Sqrt(10)));
        double hu = 1.0 / cells, hv = (V - 1) / cells;
        Iv A = Iv.Point(hu) * Iv.Point(hv), mu = A * Iv.Point(hu) * Iv.Point(hu) / 12.0, mv = A * Iv.Point(hv) * Iv.Point(hv) / 12.0, mx = A * Iv.Point(hu) * Iv.Point(hv) / 16.0;
        Iv pm = new(-1, 1);
        var acc = new Iv[3]; for (int k = 0; k < 3; k++) acc[k] = Iv.Point(0); var lockObj = new object();
        Parallel.For(0, cells, a =>
        {
            var loc = new Iv[3]; for (int k = 0; k < 3; k++) loc[k] = Iv.Point(0);
            for (int b = 0; b < cells; b++)
            {
                double u0 = a * hu, v0 = 1 + b * hv, v1 = b == cells - 1 ? V : 1 + (b + 1) * hv;
                Iv U = new(u0, u0 + hu), Vv = new(v0, v1), uc = Iv.Point(u0 + hu / 2), vc = Iv.Point(0.5 * (v0 + v1));
                for (int k = 0; k < 3; k++)
                {
                    var (fc, _, _, _) = Parts(uc, vc, beta, k); var (_, fuu, fvv, fuv) = Parts(U, Vv, beta, k);
                    loc[k] += A * fc + 0.5 * (fuu * mu + fvv * mv) + (fuv * pm) * mx;
                }
            }
            lock (lockObj) for (int k = 0; k < 3; k++) acc[k] += loc[k];
        });
        Iv sliver = new(0, 2.0 * (Vhi - V));                               // integrand at most 2 on the unit-wide sliver in u
        Iv Z = acc[0] + sliver, N1 = acc[1] + sliver, N2 = acc[2] + sliver;
        Iv m1 = N1 / Z, m2 = N2 / Z; return new(m1.Lo, m1.Hi, m2.Lo, m2.Hi);
    }

    /// <summary>Value and second derivatives of w(u,v) e^{-beta S} for w = 4uv/9 times 1, u^2 or (v^2 - 1)/9.</summary>
    static (Iv f, Iv fuu, Iv fvv, Iv fuv) Parts(Iv u, Iv v, double beta, int kind)
    {
        Iv S = 0.5 * (u.Sqr() + v.Sqr() - u * v), E = (-(beta * S)).Exp();
        Iv Su = u - 0.5 * v, Sv = v - 0.5 * u;
        Iv Eu = -beta * Su * E, Ev = -beta * Sv * E;
        Iv Euu = (beta * beta * Su.Sqr() - beta) * E, Evv = (beta * beta * Sv.Sqr() - beta) * E, Euv = (beta * beta * (Su * Sv) + 0.5 * beta) * E;
        Iv w, wu, wv, wuu, wvv, wuv;
        if (kind == 0) { w = 4.0 * u * v / 9.0; wu = 4.0 * v / 9.0; wv = 4.0 * u / 9.0; wuu = Iv.Point(0); wvv = Iv.Point(0); wuv = Iv.Point(4.0 / 9.0); }
        else if (kind == 1) { w = 4.0 * (u * u.Sqr()) * v / 9.0; wu = 12.0 * u.Sqr() * v / 9.0; wv = 4.0 * (u * u.Sqr()) / 9.0; wuu = 24.0 * u * v / 9.0; wvv = Iv.Point(0); wuv = 12.0 * u.Sqr() / 9.0; }
        else { Iv v3 = v * v.Sqr(); w = 4.0 * u * (v3 - v) / 81.0; wu = 4.0 * (v3 - v) / 81.0; wv = 4.0 * u * (3.0 * v.Sqr() - 1.0) / 81.0; wuu = Iv.Point(0); wvv = 24.0 * u * v / 81.0; wuv = 4.0 * (3.0 * v.Sqr() - 1.0) / 81.0; }
        Iv f = w * E;
        Iv fuu = wuu * E + 2.0 * wu * Eu + w * Euu, fvv = wvv * E + 2.0 * wv * Ev + w * Evv, fuv = wuv * E + wu * Ev + wv * Eu + w * Euv;
        return (f, fuu, fvv, fuv);
    }

    static double[] Fitness(List<(double f1, double f2)> F)
    {
        int n = F.Count; var S_ = new int[n]; var R = new double[n];
        bool Dom(int i, int j) => F[i].f1 <= F[j].f1 && F[i].f2 <= F[j].f2 && (F[i].f1 < F[j].f1 || F[i].f2 < F[j].f2);
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) if (Dom(i, j)) S_[i]++;
        for (int j = 0; j < n; j++) for (int i = 0; i < n; i++) if (Dom(i, j)) R[j] += S_[i];
        var fit = new double[n];
        for (int i = 0; i < n; i++)
        {
            double best = double.PositiveInfinity;
            for (int j = 0; j < n; j++) if (j != i) best = Math.Min(best, Math.Sqrt(Math.Pow(F[i].f1 - F[j].f1, 2) + Math.Pow(F[i].f2 - F[j].f2, 2)));
            fit[i] = R[i] + (n > 1 ? 1 / (best + 2) : 0);
        }
        return fit;
    }

    /// <summary>SPEA2 environmental selection to capacity K: nondominated first, overflow by lexicographic distance
    /// truncation, underflow filled by increasing fitness.</summary>
    static List<int> Select(List<(double f1, double f2)> F, int K)
    {
        int n = F.Count; if (n <= K) return Enumerable.Range(0, n).ToList();
        var fit = Fitness(F); var keep = Enumerable.Range(0, n).Where(i => fit[i] < 1).ToList();
        if (keep.Count <= K)
        {
            foreach (int i in Enumerable.Range(0, n).Where(i => fit[i] >= 1).OrderBy(i => fit[i]).ThenBy(i => i)) { if (keep.Count == K) break; keep.Add(i); }
            return keep;
        }
        double Dist(int i, int j) => Math.Sqrt(Math.Pow(F[i].f1 - F[j].f1, 2) + Math.Pow(F[i].f2 - F[j].f2, 2));
        while (keep.Count > K)
        {
            int worst = -1; double[]? wkey = null;
            foreach (int i in keep)
            {
                var key = keep.Where(j => j != i).Select(j => Dist(i, j)).OrderBy(t => t).ToArray();
                bool smaller = wkey == null;
                if (!smaller) for (int t = 0; t < key.Length; t++) { if (key[t] < wkey![t]) { smaller = true; break; } if (key[t] > wkey[t]) break; }
                if (smaller) { worst = i; wkey = key; }
            }
            keep.Remove(worst);
        }
        return keep;
    }

    public static Run Simulate(int seed, Ref rf, int n = 5000, int K = 20, double eps = 0.2, double half = 0.1, double beta = 4, double searchBeta = 5)
    {
        var rnd = new Random(seed);
        var arch = new List<(double y1, double y2, double f1, double f2)>();
        var logs = new List<(double y1, double y2, double logW)>();              // observed records with full-log weights
        int observed = 0;
        for (int i = 0; i < n; i++)
        {
            // predictable proposal law from the current archive
            double[] pi = Array.Empty<double>();
            if (arch.Count > 0)
            {
                var fit = Fitness(arch.Select(r => (r.f1, r.f2)).ToList()); double mx = fit.Max(); double mn = fit.Min();
                var lw = fit.Select(f => -searchBeta * (f - mn) / Math.Max(mx - mn, 1e-12)).ToArray();
                double s = lw.Sum(Math.Exp); pi = lw.Select(l => Math.Exp(l) / s).ToArray();
            }
            double y1, y2;
            if (arch.Count == 0 || rnd.NextDouble() < eps) { y1 = rnd.NextDouble(); y2 = rnd.NextDouble(); }
            else
            {
                double u = rnd.NextDouble(), c = 0; int k = 0; for (; k < pi.Length - 1; k++) { c += pi[k]; if (u < c) break; }
                double lo1 = Math.Max(0, arch[k].y1 - half), hi1 = Math.Min(1, arch[k].y1 + half), lo2 = Math.Max(0, arch[k].y2 - half), hi2 = Math.Min(1, arch[k].y2 + half);
                y1 = lo1 + (hi1 - lo1) * rnd.NextDouble(); y2 = lo2 + (hi2 - lo2) * rnd.NextDouble();
            }
            double q = arch.Count == 0 ? 1.0 : eps;
            if (arch.Count > 0)
                for (int k = 0; k < arch.Count; k++)
                {
                    double lo1 = Math.Max(0, arch[k].y1 - half), hi1 = Math.Min(1, arch[k].y1 + half), lo2 = Math.Max(0, arch[k].y2 - half), hi2 = Math.Min(1, arch[k].y2 + half);
                    if (y1 >= lo1 && y1 <= hi1 && y2 >= lo2 && y2 <= hi2) q += (1 - eps) * pi[k] / ((hi1 - lo1) * (hi2 - lo2));
                }
            double e = 0.5 + 0.5 * y1;
            if (rnd.NextDouble() >= e) continue;
            observed++;
            double g = 1 + 9 * y2, f1 = y1, f2 = g - Math.Sqrt(y1 * g);
            logs.Add((y1, y2, -beta * S(y1, y2) - Math.Log(q) - Math.Log(e)));
            arch.Add((y1, y2, f1, f2));
            if (arch.Count > K) { var sel = Select(arch.Select(r => (r.f1, r.f2)).ToList(), K); arch = sel.Select(j => arch[j]).ToList(); }
        }
        (double, double) Est(IEnumerable<(double y1, double y2, double lw)> recs)
        {
            var l = recs.ToList(); double mx = l.Max(r => r.lw), sw = 0, s1 = 0, s2 = 0;
            foreach (var r in l) { double w = Math.Exp(r.lw - mx); sw += w; s1 += w * r.y1; s2 += w * r.y2; }
            return (s1 / sw, s2 / sw);
        }
        double r1 = 0.5 * (rf.Lo1 + rf.Hi1), r2 = 0.5 * (rf.Lo2 + rf.Hi2);
        var full = Est(logs);
        var arc = Est(arch.Select(r => (r.y1, r.y2, -beta * S(r.y1, r.y2))));                // archive-only attention, uniform base mass
        var keepIds = new HashSet<(double, double)>(arch.Select(r => (r.y1, r.y2)));
        var arcIw = Est(logs.Where(r => keepIds.Contains((r.y1, r.y2))));                     // retained records with their full-log weights
        return new(seed, observed, Math.Abs(full.Item1 - r1), Math.Abs(full.Item2 - r2), Math.Abs(arc.Item1 - r1), Math.Abs(arc.Item2 - r2), Math.Abs(arcIw.Item1 - r1), Math.Abs(arcIw.Item2 - r2));
    }
}
