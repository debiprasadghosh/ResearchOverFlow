namespace NsmIntervals;

/// <summary>Exhaustive certification of Theorem 1 on every multiset archive of size 2 to 6 drawn from the grid {0,1,2}^2,
/// with k = 1 density. Strengths are exact integers; densities and fitness differences are interval-certified.</summary>
public static class Spea
{
    public sealed record Result(int Archives, long DominancePairs, double MinFitnessGapLo, bool AllPassed, string FirstFailure);

    public static (int[] R, int[] S, Iv[] Delta) Scores(int[][] f)
    {
        int n = f.Length; var dom = new bool[n, n];
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) dom[i, j] = f[i][0] <= f[j][0] && f[i][1] <= f[j][1] && (f[i][0] < f[j][0] || f[i][1] < f[j][1]);
        var S = new int[n]; for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) if (dom[i, j]) S[i]++;
        var R = new int[n]; for (int j = 0; j < n; j++) for (int i = 0; i < n; i++) if (dom[i, j]) R[j] += S[i];
        var D = new Iv[n];
        for (int i = 0; i < n; i++)
        {
            int best = int.MaxValue;                                   // squared distances are exact integers on the grid
            for (int j = 0; j < n; j++) if (j != i) best = Math.Min(best, (f[i][0] - f[j][0]) * (f[i][0] - f[j][0]) + (f[i][1] - f[j][1]) * (f[i][1] - f[j][1]));
            D[i] = best == 0 ? Iv.Point(0.5) : 1.0 / (Iv.Point(best).Sqrt() + 2.0);   // exact at duplicates
        }
        return (R, S, D);
    }

    public static Result Run()
    {
        var pts = new List<int[]>(); for (int a = 0; a < 3; a++) for (int b = 0; b < 3; b++) pts.Add(new[] { a, b });
        int archives = 0; long pairs = 0; double minGap = double.PositiveInfinity; bool ok = true; string fail = "";
        void Chk(bool c, string what) { if (!c && ok) fail = what; ok &= c; }
        void Rec(List<int> chosen, int start, int size)
        {
            if (chosen.Count == size)
            {
                archives++; var f = chosen.Select(i => pts[i]).ToArray(); var (R, S, D) = Scores(f); int n = f.Length;
                for (int j = 0; j < n; j++)
                {
                    bool nd = !Enumerable.Range(0, n).Any(i => f[i][0] <= f[j][0] && f[i][1] <= f[j][1] && (f[i][0] < f[j][0] || f[i][1] < f[j][1]));
                    Chk(nd == (R[j] == 0), "R0"); Chk(nd || R[j] >= 1, "R1"); Chk(D[j].Lo > 0 && D[j].Hi <= 0.5, $"delta {D[j]}");
                    Iv fit = Iv.Point(R[j]) + D[j]; Chk(nd ? D[j].Hi <= 0.5 : fit.Lo > 1, $"fit {fit} nd={nd}");   // R = 0 exactly on the front, so the fitness is delta itself
                }
                for (int i = 0; i < n; i++) for (int j = 0; j < n; j++)
                    if (f[i][0] <= f[j][0] && f[i][1] <= f[j][1] && (f[i][0] < f[j][0] || f[i][1] < f[j][1]))
                    {
                        pairs++; Chk(R[j] >= R[i] + S[i], "mono");
                        Iv gap = (Iv.Point(R[j]) + D[j]) - (Iv.Point(R[i]) + D[i]); Chk(gap.Lo > 0, "gap"); minGap = Math.Min(minGap, gap.Lo);
                    }
                return;
            }
            for (int k = start; k < pts.Count; k++) { chosen.Add(k); Rec(chosen, k, size); chosen.RemoveAt(chosen.Count - 1); }
        }
        for (int size = 2; size <= 6; size++) Rec(new List<int>(), 0, size);
        return new(archives, pairs, minGap, ok, fail);
    }
}
