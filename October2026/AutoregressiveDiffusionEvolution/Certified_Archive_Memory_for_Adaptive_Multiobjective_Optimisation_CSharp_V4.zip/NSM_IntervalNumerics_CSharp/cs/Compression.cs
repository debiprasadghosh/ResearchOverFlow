namespace NsmIntervals;

/// <summary>Certified readouts for the approximate-compression example of Section 6.3 and the two bounds:
/// (8): r + 2 B_Y min(1, e^{2Lr} - 1), and Proposition 6: r + diam(Z) tanh(L r / 2).</summary>
public static class Compression
{
    public sealed record Row(int Bins, double A, double Radius, double ErrLo, double ErrHi, double Bound8, double BoundSharp, double Diam);

    static Iv Readout(double[] y, Iv[] logw, double q, double a)
    {
        Iv sa = Iv.Point(a).Sqrt(), om = 1.0 - Iv.Point(a);
        var lg = new Iv[y.Length]; double mx = double.NegativeInfinity;
        for (int i = 0; i < y.Length; i++) { lg[i] = logw[i] - (Iv.Point(q) - sa * y[i]).Sqr() / (2.0 * om); mx = Math.Max(mx, lg[i].Hi); }
        Iv num = Iv.Point(0), den = Iv.Point(0);
        for (int i = 0; i < y.Length; i++) { Iv w = (lg[i] - mx).Exp(); num += w * y[i]; den += w; }
        Iv r = num / den; return new(Math.Max(r.Lo, y.Min()), Math.Min(r.Hi, y.Max()));
    }

    public static List<Row> Run(int seed, int n = 2000, double q = 0.3)
    {
        var rnd = new Random(seed); var y = Enumerable.Range(0, n).Select(_ => -1 + 2 * rnd.NextDouble()).OrderBy(t => t).ToArray();
        var lw = y.Select(t => -2.0 * Iv.Point(t).Sqr()).ToArray();
        var rows = new List<Row>();
        foreach (int bins in new[] { 4, 8, 16, 32 })
        {
            var cl = y.Select(t => Math.Min((int)((t + 1) * bins / 2), bins - 1)).ToArray();
            var centers = new List<double>(); var masses = new List<Iv>(); double r = 0;
            for (int c = 0; c < bins; c++)
            {
                var idx = Enumerable.Range(0, n).Where(i => cl[i] == c).ToArray(); if (idx.Length == 0) continue;
                double center = idx.Average(i => y[i]); centers.Add(center); r = Math.Max(r, idx.Max(i => Math.Abs(y[i] - center)));
                Iv m = Iv.Point(0); foreach (int i in idx) m += lw[i].Exp(); masses.Add(m.Log());
            }
            double diam = centers.Max() - centers.Min();
            foreach (double a in new[] { 0.2, 0.8, 0.98 })
            {
                Iv m1 = Readout(y, lw, q, a), m2 = Readout(centers.ToArray(), masses.ToArray(), q, a);
                Iv err = (m1 - m2).Abs();
                double L = Math.Sqrt(a) * (q + Math.Sqrt(a)) / (1 - a);
                double b8 = r + 2 * Math.Min(1, Math.Exp(Math.Min(2 * L * r, 50)) - 1);
                double bs = r + diam * Math.Tanh(L * r / 2);
                rows.Add(new(bins, a, r, err.Lo, err.Hi, b8, bs, diam));
            }
        }
        return rows;
    }
}
