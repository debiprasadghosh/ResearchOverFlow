namespace NsmIntervals;

/// <summary>Proposition 7: for independent Bernoulli(rho) retention of a fixed weighted log,
/// E[N/D; D > 0] = int_0^inf E[N e^{-tD}] dt, and E[N e^{-tD}] = sum_i x_i w_i e^{-t w_i/rho} prod_{j != i}(1 - rho + rho e^{-t w_j/rho}).
/// The integrand is completely monotone, hence convex: midpoint sums bound the integral below and trapezoid sums above.</summary>
public static class Retention
{
    public sealed record Result(double Lo, double Hi, double Full, double TailBound, double McMean, double McSe, int McReps);

    static Iv G(double t, Iv[] x, Iv[] w, Iv rho)
    {
        int n = x.Length; var f = new Iv[n]; Iv logP = Iv.Point(0);
        for (int j = 0; j < n; j++) { f[j] = 1.0 - rho + rho * (-(Iv.Point(t) * w[j] / rho)).Exp(); logP += f[j].Log(); }
        Iv s = Iv.Point(0);
        for (int i = 0; i < n; i++) s += x[i] * w[i] * (-(Iv.Point(t) * w[i] / rho)).Exp() * (logP - f[i].Log()).Exp();
        return s;
    }

    public static Result Run(int cells = 40000, double T = 0.5, int reps = 200000, int seed = 20261031)
    {
        int n = 1001; double r = 0.2; Iv rho = Iv.Point(r);
        var x = Enumerable.Range(0, n).Select(i => Iv.Point(i) / 1000.0).ToArray();
        var w = x.Select(xi => (-3.0 * xi).Exp()).ToArray();
        double h = T / cells; Iv lo = Iv.Point(0), hi = Iv.Point(0);
        var gEnd = new Iv[cells + 1];
        Parallel.For(0, cells + 1, k => gEnd[k] = G(k * h, x, w, rho));
        var gMid = new Iv[cells];
        Parallel.For(0, cells, k => gMid[k] = G((k + 0.5) * h, x, w, rho));
        for (int k = 0; k < cells; k++) { lo += Iv.Point(h) * gMid[k]; hi += Iv.Point(h) * 0.5 * (gEnd[k] + gEnd[k + 1]); }
        // tail beyond T: prod_{j != i} f_j(t) <= prod_{j != i} f_j(T) and int_T^inf e^{-t w_i/rho} dt = rho/w_i e^{-T w_i/rho}
        Iv tail = Iv.Point(0); { Iv logP = Iv.Point(0); var f = new Iv[n];
            for (int j = 0; j < n; j++) { f[j] = 1.0 - rho + rho * (-(Iv.Point(T) * w[j] / rho)).Exp(); logP += f[j].Log(); }
            for (int i = 0; i < n; i++) tail += x[i] * rho * (-(Iv.Point(T) * w[i] / rho)).Exp() * (logP - f[i].Log()).Exp(); }
        Iv full = Iv.Point(0), den = Iv.Point(0); for (int i = 0; i < n; i++) { full += w[i] * x[i]; den += w[i]; }
        // Monte Carlo diagnostic
        var means = new double[16]; var sq = new double[16]; int per = reps / 16;
        Parallel.For(0, 16, b =>
        {
            var rnd = new Random(seed + b); double s = 0, s2 = 0;
            for (int k = 0; k < per; k++)
            {
                double N = 0, D = 0; for (int i = 0; i < n; i++) if (rnd.NextDouble() < r) { double wi = Math.Exp(-3.0 * i / 1000.0); N += wi * i / 1000.0; D += wi; }
                double v = D > 0 ? N / D : 0; s += v; s2 += v * v;
            }
            means[b] = s; sq[b] = s2;
        });
        double m = means.Sum() / (per * 16), var = sq.Sum() / (per * 16) - m * m;
        return new(lo.Lo, (hi + tail).Hi, (full / den).Mid, tail.Hi, m, Math.Sqrt(var / (per * 16)), per * 16);
    }
}
