namespace NsmIntervals;

/// <summary>Proposition 8: escape mass of the ZDT2 endpoint region under the uniform reference on [0,1]^4,
/// rho = int_0^1 s(x)^3/6 dx with s(x) = (sqrt(1 + 4x^2) - 1)/6. The integrand increases, so Riemann sums bracket rho.</summary>
public static class Escape
{
    public sealed record Result(double RhoLo, double RhoHi, double ExpectedHitBoundHi, long N95, double Eps);
    static Iv F(Iv x) { Iv s = ((1.0 + 4.0 * x.Sqr()).Sqrt() - 1.0) / 6.0; return s * s.Sqr() / 6.0; }
    public static Result Run(int cells = 1_000_000, double eps = 0.1)
    {
        double h = 1.0 / cells; Iv lo = Iv.Point(0), hi = Iv.Point(0);
        for (int k = 0; k < cells; k++) { lo += Iv.Point(h) * F(Iv.Point(k * h)); hi += Iv.Point(h) * F(Iv.Point((k + 1) * h)); }
        Iv rho = new(lo.Lo, hi.Hi), p = Iv.Point(eps) * rho;
        Iv bound = 1.0 / p;
        // smallest n with (1 - eps rho)^n <= 0.05, certified with the lower end of rho: n >= log 0.05 / log(1 - eps rho)
        Iv need = Iv.Point(0.05).Log() / (1.0 - new Iv(p.Lo, p.Lo)).Log();
        return new(rho.Lo, rho.Hi, bound.Hi, (long)Math.Ceiling(need.Hi), eps);
    }
}
