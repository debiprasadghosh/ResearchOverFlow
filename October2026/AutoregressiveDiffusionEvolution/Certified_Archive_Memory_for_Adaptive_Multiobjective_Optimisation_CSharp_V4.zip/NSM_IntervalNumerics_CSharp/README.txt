Niches, Strength and Memory V4: validated interval numerics (Sections 11.3-11.7, Appendix C)

cs/        .NET 8 console project. Build: dotnet build -c Release; run: dotnet bin/Release/net8.0/Nsm.dll (about 38 s).
           Writes results.json and archive_replicates.json.
symbolic/  sym.py: SymPy/mpmath checks (counts, merge weights, elite mean, sharp TV factor, Proposition 8 closed form,
           delta-method bias, 20-digit Proposition 7). zdt2_sigmoid.py: diagnostic escape mass under the sigmoid reference.
figures/   figs.py regenerates Figures 3 and 4 (paths assume the original build tree: ../cs and ../num).
