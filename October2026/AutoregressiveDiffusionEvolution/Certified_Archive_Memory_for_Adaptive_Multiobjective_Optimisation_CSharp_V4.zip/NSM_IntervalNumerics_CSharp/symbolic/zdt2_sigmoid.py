import numpy as np, json
from scipy.stats import norm
# x = sigmoid(2z), z ~ N(0,1). CDF F(x) = Phi(logit(x)/2). Escape: x2+x3+x4 < s(x1) = (sqrt(1+4x1^2)-1)/6
h=2e-6; grid=np.arange(0,0.25+h,h)
F=lambda x: norm.cdf(np.log(x/(1-x))/2) if np.isscalar(x) else norm.cdf(np.log(np.clip(x,1e-300,None)/(1-x))/2)
# density on grid by differencing the CDF over cells (exact cell masses)
edges=np.arange(0,0.25+2*h,h); cdf=np.where(edges>0,norm.cdf(np.log(np.clip(edges,1e-300,None)/(1-edges))/2),0.0)
mass=np.diff(cdf)                      # mass of x in [k h,(k+1) h)
m2=np.convolve(mass,mass)[:len(mass)]; m3=np.convolve(m2,mass)[:len(mass)]
S_cdf_upper=np.cumsum(m3)              # P(S < (k+3) h) roughly; use index shift bounds
def PS(s, upper):
    k=int(np.floor(s/h)); k=min(k,len(m3)-1)
    # cells: S lies in [i h, (i+3) h) for convolution index i; lower bound counts i+3<=k, upper counts i<=k
    return S_cdf_upper[k] if upper else (S_cdf_upper[k-3] if k>=3 else 0.0)
z=np.linspace(-9,9,20001); dz=z[1]-z[0]; x1=1/(1+np.exp(-2*z)); s=(np.sqrt(1+4*x1**2)-1)/6
lo=sum(norm.pdf(zz)*PS(ss,False) for zz,ss in zip(z,s))*dz; hi=sum(norm.pdf(zz)*PS(ss,True) for zz,ss in zip(z,s))*dz
out={'rho_sigmoid_lo':lo,'rho_sigmoid_hi':hi,'P_x_below_0.05':float(norm.cdf(np.log(0.05/0.95)/2))}
print(out); json.dump(out,open('zdt2_sigmoid.json','w'),indent=1)
