import sympy as sp, mpmath as mp, json, numpy as np
mp.mp.dps=30; R=sp.Rational; out={}
out['eq2']=[int(sp.binomial(h+m-1,m-1)) for m,h in [(2,99),(3,12),(5,5)]]
# Lemma 1 example
v=sp.Matrix([-1,0]); w=sp.Matrix([1,0]); t=(v.T*w)[0]
out['lemma1']=[str((v-t*w).norm()),str((v-sp.Max(0,t)*w).norm())]
# merge weights
out['merge']=[str(sp.N(sp.exp(R(-11,10))+sp.exp(R(2,5)),10)),str(sp.N(2*sp.exp(R(-11,10)),10))]
# Proposition 3: mean of the K smallest of n uniforms has expectation (K+1)/(2(n+1))
k,n=sp.symbols('k n',positive=True,integer=True)
out['elite_mean_formula']='(K+1)/(2(n+1))'; out['elite_mean_64_1e5']=float(R(65,2*100001))
# (9) gradient of log K
a=sp.symbols('a',positive=True); q,y=sp.symbols('q y',real=True)
logK=-(q-sp.sqrt(a)*y)**2/(2*(1-a))
out['eq9_grad']=str(sp.simplify(sp.diff(logK,y)))
# Theorem 5 numbers
out['escape_95']=int(mp.ceil(mp.log(0.05)/mp.log(1-0.1*0.02)))
# Sharp compression TV: weights ratio in [e^{-c}, e^{c}] -> TV <= tanh(c/2); compare with min(1, e^{2c}-1)
p,K_=sp.symbols('p K',positive=True); f=p*K_/(p*K_+1-p)-p; ps=1/(1+sp.sqrt(K_))
c=sp.symbols('c',positive=True)
out['tv_sharp_check']=bool(sp.simplify((sp.simplify(f.subs(p,ps))-(sp.sqrt(K_)-1)/(sp.sqrt(K_)+1)))==0)
out['tv_sharp_tanh']=bool(sp.simplify(((sp.sqrt(sp.exp(2*c))-1)/(sp.sqrt(sp.exp(2*c))+1)-sp.tanh(c/2)).rewrite(sp.exp))==0)
# ZDT2 endpoint escape mass under the uniform reference on [0,1]^4:
#   (x2+x3+x4)/3 < t(x1) = (sqrt(1+4x1^2)-1)/18;  S=x2+x3+x4 < 3t <= (sqrt5-1)/6 < 1 so P(S<s)=s^3/6
x=sp.symbols('x',positive=True)
s3=(sp.sqrt(1+4*x**2)-1)/6
rho=sp.integrate(sp.expand(s3**3/6),(x,0,1))
rho_s=sp.simplify(rho); out['zdt2_rho_exact']=str(rho_s); out['zdt2_rho']=str(sp.N(rho_s,20))
rv=float(rho_s); eps=0.1
out['zdt2_expected_hit_bound']=1/(eps*rv); out['zdt2_95']=int(np.ceil(np.log(0.05)/np.log(1-eps*rv)))
# Retention: exact E[N/D] by Laplace identity vs delta method; base_x = linspace(0,1,1001), w = e^{-3x}, rho=0.2
xs=[mp.mpf(i)/1000 for i in range(1001)]; ws=[mp.e**(-3*xi) for xi in xs]; r=mp.mpf('0.2')
N=sum(wi*xi for wi,xi in zip(ws,xs)); D=sum(ws); m=N/D
out['full_ratio']=mp.nstr(m,12)
var_term=sum(wi**2*(m-xi) for wi,xi in zip(ws,xs))*(1-r)/r/D**2
out['delta_bias']=mp.nstr(var_term,10); out['delta_mean']=mp.nstr(m+var_term,12)
mp.mp.dps=20
def g(tt):
    # E[ N_hat exp(-t D_hat) ] with N_hat = sum J w x / r, D_hat = sum J w / r
    lf=[mp.log(1-r+r*mp.e**(-tt*wi/r)) for wi in ws]; L=sum(lf)
    return sum(xi*wi*mp.e**(-tt*wi/r)*mp.e**(L-lfi) for xi,wi,lfi in zip(xs,ws,lf))
E=mp.quad(g,[0,0.005,0.02,0.05,0.2,1,3])
out['exact_ratio_mp']=mp.nstr(E,12)
json.dump(out,open('sym.json','w'),indent=1); print(json.dumps(out,indent=1))
