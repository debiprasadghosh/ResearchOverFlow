import json, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans'})
BLUE='#2a5b84'; BROWN='#a0602a'; GREY='#c3c9ce'; DARK='#555555'
R=json.load(open('../cs/results.json')); S=json.load(open('../num/sym.json'))
fig,ax=plt.subplots(1,2,figsize=(6.7,3.3))
C=R['compression']; cols={0.2:BLUE,0.8:BROWN,0.98:DARK}
for a in (0.2,0.8,0.98):
    rows=[c for c in C if c['A']==a]; r=[c['Radius'] for c in rows]
    ax[0].plot(r,[(c['ErrLo']+c['ErrHi'])/2 for c in rows],'o-',color=cols[a],ms=4,lw=1,label=f'Certified error, a = {a}')
    ax[0].plot(r,[c['BoundSharp'] for c in rows],'--',color=cols[a],lw=1)
    ax[0].plot(r,[c['Bound8'] for c in rows],':',color=cols[a],lw=1)
ax[0].plot([],[],'--',color='black',lw=1,label='Proposition 6'); ax[0].plot([],[],':',color='black',lw=1,label='Bound (8)')
ax[0].set_xscale('log'); ax[0].set_yscale('log'); ax[0].set_xlabel('Cluster radius r'); ax[0].set_ylabel('Readout error |m − m̃|')
from matplotlib.ticker import NullFormatter, FixedLocator
ax[0].xaxis.set_minor_formatter(NullFormatter()); ax[0].xaxis.set_major_locator(FixedLocator([0.035,0.07,0.14,0.27])); ax[0].set_xticklabels(['0.035','0.07','0.14','0.27'])
fig.legend(*ax[0].get_legend_handles_labels(),fontsize=6.8,frameon=False,loc='lower left',ncol=3,bbox_to_anchor=(0.02,0.0))
ax[0].set_ylim(1e-5,10)
T=R['retention']; full=T['Full']
pts=[('Full\nlog',full,0,GREY),('Exact\nretained',(T['Lo']+T['Hi'])/2,(T['Hi']-T['Lo'])/2,BLUE),('Delta\nmethod',float(S['delta_mean']),0,BROWN),
     ('C#\n200k reps',T['McMean'],2*T['McSe'],DARK),('Python\n2k reps',0.2813689,2*T['McSe']*np.sqrt(100),DARK)]
for k,(lab,v,e,c) in enumerate(pts): ax[1].errorbar(k,v,yerr=e if e>0 else None,fmt='o',color=c,ms=5,capsize=3)
ax[1].set_xticks(range(len(pts)),[p[0] for p in pts],fontsize=7); ax[1].set_ylabel('Self-normalized ratio'); ax[1].axhline(full,color=GREY,lw=0.8,ls=':')
ax[1].ticklabel_format(axis='y',useOffset=False)
plt.tight_layout(rect=(0,0.1,1,1)); plt.savefig('fig3.png',dpi=300); plt.close()
reps=json.load(open('../cs/archive_replicates.json'))
fig,ax=plt.subplots(1,2,figsize=(6.7,2.7))
for k,(key,title) in enumerate([('1','Target mean of y₁'),('2','Target mean of y₂')]):
    data=[[r['FullErr'+key] for r in reps],[r['ArchiveIwErr'+key] for r in reps],[r['ArchiveErr'+key] for r in reps]]
    bp=ax[k].boxplot(data,widths=0.55,patch_artist=True,flierprops=dict(marker='.',ms=3))
    for b,c in zip(bp['boxes'],[BLUE,BROWN,GREY]): b.set_facecolor(c); b.set_alpha(0.8)
    for m in bp['medians']: m.set_color('black')
    ax[k].set_xticks([1,2,3],['Full corrected\nlog','Archive with\nlog weights','Archive-only\nattention'],fontsize=7)
    ax[k].set_yscale('log'); ax[k].set_title(title,fontsize=9); ax[k].set_ylabel('Absolute error (200 seeds)')
plt.tight_layout(); plt.savefig('fig4.png',dpi=300); plt.close()
