# Two Hundred Load Cases, One Cost V4: validated interval numerics

- cs/: .NET 8 C# program (no packages). `dotnet run -c Release` writes results.json (about 70 s).
  Truncation.cs (Proposition 9 continued-fraction moments, series and implementation error studies, Proposition 10 leakage),
  Loadcase.cs (convex companions, barrier + KKT polish, Proposition 11 / Corollary 8 certificates, Proposition 12 screening),
  Program.cs (Table 1 example certified, Monte Carlo replicates), Interval.cs, Normal.cs, Rng.cs.
- num/sym.py: SymPy 1.14 / mpmath 1.3 series, leakage limit and exact checks -> sym.json.
- fig/figs.py: Figures 2-3.
- build/: fragment sources and the docx assembly script.
Assumptions: Math.Exp and Math.Log accurate to within four ulps (results widened); successive convergents of Laplace's
continued fraction bracket the Mills ratio and its tails (classical property).
