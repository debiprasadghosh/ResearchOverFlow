"""Exact/symbolic checks for Two Hundred Load Cases, One Cost V4 (SymPy 1.14, mpmath 1.3)."""
import sympy as sp, mpmath as mp, json
mp.mp.dps = 50; out = {}
u, t = sp.symbols('u t', positive=True)

# ---- asymptotic series (8)-(9): Mills ratio R(t) ~ sum (-1)^k (2k-1)!! t^{-(2k+1)}
K = 8
Rser = sum((-1) ** k * sp.factorial2(2 * k - 1) * u ** (2 * k + 1) for k in range(K))   # u = 1/t
Lam = sp.series(1 / Rser, u, 0, 13).removeO()           # Lambda(-t) = 1/R(t)
Var = sp.series(1 - (1 / Rser) * (1 / Rser - 1 / u), u, 0, 13).removeO()
out['Lambda_series'] = str(sp.expand(Lam)); out['Var_series'] = str(sp.expand(Var))
lam_coeffs = [sp.expand(Lam * u).coeff(u, k) for k in range(0, 13)]
var_coeffs = [sp.expand(Var).coeff(u, k) for k in range(0, 13)]
out['Lambda_coeffs_t_power'] = {str(1 - k): str(c) for k, c in enumerate(lam_coeffs) if c != 0}
out['Var_coeffs_t_power'] = {str(-k): str(c) for k, c in enumerate(var_coeffs) if c != 0}
out['paper_series_match'] = bool(lam_coeffs[0] == 1 and lam_coeffs[2] == 1 and lam_coeffs[4] == -2 and lam_coeffs[6] == 10 and lam_coeffs[8] == -74 and lam_coeffs[10] == 706
                                 and var_coeffs[2] == 1 and var_coeffs[4] == -6 and var_coeffs[6] == 50 and var_coeffs[8] == -518)

# ---- high-precision truncated moments and series errors at the paper's grid
def lam_var(alpha):
    alpha = mp.mpf(alpha)
    L = mp.npdf(alpha) / mp.ncdf(alpha)
    return L, 1 - L * (L + alpha)
def series(t_):
    q = 1 / mp.mpf(t_)
    return (t_ + q - 2 * q ** 3 + 10 * q ** 5 - 74 * q ** 7 + 706 * q ** 9, q * q - 6 * q ** 4 + 50 * q ** 6 - 518 * q ** 8)
mp.mp.dps = 120
errs = {}
for tt in (10, 50, 51, 80, 1000):
    L, V = lam_var(-tt); sL, sV = series(tt)
    errs[str(tt)] = {'Lambda': mp.nstr(L, 25), 'Var': mp.nstr(V, 25), 'rel_err_Lambda_series': mp.nstr((sL - L) / L, 6), 'rel_err_Var_series': mp.nstr((sV - V) / V, 6)}
out['deep_tail'] = errs
mp.mp.dps = 50

# ---- moment-closure leakage (Proposition 10)
def leak(alpha):
    L, V = lam_var(alpha); return 1 - mp.ncdf((mp.mpf(alpha) + L) / mp.sqrt(V))
out['leak_alpha0'] = mp.nstr(leak(0), 15)
out['leak_exact_alpha0'] = 'Phi(-sqrt(2/pi)/sqrt(1-2/pi))'
mp.mp.dps = 120
out['leak_grid'] = {str(a): mp.nstr(leak(a), 12) for a in (-1000, -100, -20, -5, -2, -1, 0, 1, 2, 3, 5)}
out['leak_limit'] = mp.nstr(1 - mp.ncdf(1), 15)
# argument expansion (alpha + Lambda)/sqrt(V) as t -> infinity
arg = sp.series((1 / Rser - 1 / u) / sp.sqrt(Var), u, 0, 7).removeO()
out['leak_argument_series'] = str(sp.expand(arg))
mp.mp.dps = 50

# ---- Table 1 checks: correlated half-space example
x = sp.Matrix([sp.Rational(3, 10), -sp.Rational(1, 5)]); S = sp.Matrix([[1, sp.Rational(3, 5)], [sp.Rational(3, 5), sp.Rational(4, 5)]])
a = sp.Matrix([1, 2]); g0 = sp.Rational(1, 2); dl = sp.Rational(1, 10)
v2 = (a.T * S * a)[0]; out['v2'] = str(v2)
al = (-dl - g0) / sp.sqrt(v2); out['alpha'] = str(sp.nsimplify(al)); out['alpha_float'] = float(al)
alm = mp.mpf(sp.N(al, 50)); L = mp.npdf(alm) / mp.ncdf(alm); Vu = 1 - L * (L + alm)
qa = [mp.mpf(sp.N(e, 50)) for e in (S * a) / sp.sqrt(v2)]
mH = [mp.mpf(sp.N(x[i], 50)) - qa[i] * L for i in range(2)]
SH = [[mp.mpf(sp.N(S[i, j], 50)) - qa[i] * qa[j] * (1 - Vu) for j in range(2)] for i in range(2)]
out['mH'] = [mp.nstr(m_, 12) for m_ in mH]; out['SigmaH'] = [[mp.nstr(e, 12) for e in r] for r in SH]
p = mp.ncdf(alm); out['event_prob'] = mp.nstr(p, 12); out['expected_event_count'] = mp.nstr(400000 * p, 10)
out['z_event_count'] = mp.nstr((162917 - 400000 * p) / mp.sqrt(400000 * p * (1 - p)), 6)
ne = 162917
out['z_mean_components'] = [mp.nstr((mp.mpf(r) - mH[i]) / mp.sqrt(SH[i][i] / ne), 6) for i, r in enumerate(('-0.516663', '-1.019587'))]
# ---- Proposition 3 examples and screening bounds
for r_ in (3, 5):
    Lr = mp.npdf(r_) / mp.ncdf(r_); out[f'move_ratio{r_}'] = mp.nstr(Lr, 12); out[f'bound_ratio{r_}'] = mp.nstr(2 * mp.npdf(r_), 12)
# ---- convex example (Corollary 8)
out['convex_true_gap'] = str(sp.sqrt(2) - sp.Rational(6, 5)); out['convex_bound'] = str(sp.Rational(5, 6) * sp.Rational(7, 25))
out['convex_values'] = [float(sp.sqrt(2) - sp.Rational(6, 5)), float(sp.Rational(5, 6) * sp.Rational(7, 25))]
# ---- projected write and projection order (exact)
out['projected_write'] = 'cost -1 vs archive min 0'
def proj(xv, nrm, rhs):
    gap = sp.Max(0, rhs - (nrm.T * xv)[0]); return xv + gap * nrm / (nrm.T * nrm)[0]
x0 = sp.Matrix([-1, -1]); n1 = sp.Matrix([1, 0]); n2 = sp.Matrix([1, 1])
out['order_ab'] = str(list(proj(proj(x0, n1, 0), n2, 1))); out['order_ba'] = str(list(proj(proj(x0, n2, 1), n1, 0)))
# ---- feasible-radius lemma (Proposition 11): eps |y|^2 <= m + |h| |y|
e, hh, mm = sp.symbols('epsilon h m', positive=True)
yv = sp.symbols('y', positive=True)
roots = sp.solve(sp.Eq(e * yv ** 2 - hh * yv - mm, 0), yv)
out['radius_root'] = str([r_ for r_ in roots if sp.simplify(r_.subs({e: 1, hh: 1, mm: 1})) > 0][0])
json.dump(out, open('sym.json', 'w'), indent=1); print(json.dumps(out, indent=1))
