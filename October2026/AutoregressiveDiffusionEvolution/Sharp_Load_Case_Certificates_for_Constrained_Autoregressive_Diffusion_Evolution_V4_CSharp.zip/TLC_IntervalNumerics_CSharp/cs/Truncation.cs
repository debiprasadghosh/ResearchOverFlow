namespace TlcIntervals;

/// <summary>Proposition 9: validated inverse Mills ratio and truncated variance for U ~ N(0,1) conditioned on U &lt;= alpha.
/// For alpha = -t &lt; -1: Lambda = t + T1 and Var = T1 (T2 - T1), where T_k = k/(t + (k+1)/(t + ...)) are tails of Laplace's
/// continued fraction; successive convergents of each tail bracket it (classical property of this positive S-fraction).
/// For alpha &gt;= -1: Lambda = phi/Phi and Var = 1 - Lambda (Lambda + alpha) with the validated Phi.</summary>
public static class Truncation
{
    static Iv TailConv(Iv t, int k, int n) { var v = t; for (int j = n; j > k; j--) v = t + (double)j / v; return (double)k / v; }
    public static Iv Tail(Iv t, int k, int n = 4000) => Iv.Hull(TailConv(t, k, n), TailConv(t, k, n + 1));
    public static (Iv lam, Iv var) Moments(double alpha)
    {
        if (alpha < -1)
        {
            var t = Iv.Point(-alpha); var t1 = Tail(t, 1); var t2 = Tail(t, 2);
            return (t + t1, t1 * (t2 - t1));
        }
        var a = Iv.Point(alpha); var lam = Normal.Pdf(a) / Normal.Cdf(a);
        return (lam, 1.0 - lam * (lam + a));
    }
    /// <summary>Asymptotic series (8)-(9), evaluated in interval arithmetic (exact integer coefficients).</summary>
    public static (Iv lam, Iv var) Series(double t, bool extended = false)
    {
        var q = 1.0 / Iv.Point(t); var q2 = q.Sqr();
        var lam = Iv.Point(t) + q * (1.0 + q2 * (-2.0 + q2 * (10.0 + q2 * (-74.0 + q2 * (706.0 + (extended ? -8162.0 * q2 : Iv.Point(0)))))));
        var v = q2 * (1.0 + q2 * (-6.0 + q2 * (50.0 + q2 * (-518.0 + (extended ? 6354.0 * q2 : Iv.Point(0))))));
        return (lam, v);
    }
    /// <summary>Emulation of the Appendix A implementation: an accurately rounded Lambda, then the variance 1 - L(L + alpha)
    /// in double precision for alpha &gt;= switchAt, and the series below it.</summary>
    public static double PaperVariance(double alpha, double switchAt)
    {
        if (alpha < switchAt) { double q = -1 / alpha; return q * q - 6 * Math.Pow(q, 4) + 50 * Math.Pow(q, 6) - 518 * Math.Pow(q, 8); }
        double lam = Moments(alpha).lam.Mid;
        return 1 - lam * (lam + alpha);
    }
    /// <summary>Proposition 10: probability that the moment-matched Gaussian N(-Lambda, Var) leaves the half-space U &lt;= alpha.</summary>
    public static Iv Leak(double alpha)
    {
        var (lam, v) = Moments(alpha);
        var z = (Iv.Point(alpha) + lam) / v.Max0().Sqrt();
        return Normal.Upper(z);
    }
    /// <summary>Largest certified relative error of the emulated implementation over a dense grid, for several switch points.</summary>
    public static List<object> SwitchStudy()
    {
        var alphas = new List<double>();
        for (int k = 0; k <= 3000; k++) alphas.Add(-Math.Pow(1000.0 / 1.0, k / 3000.0));          // -1 ... -1000
        for (int k = 0; k <= 200; k++) alphas.Add(-1 + 6.0 * k / 200);                               // -1 ... 5
        var vs = alphas.Select(a => (a, Moments(a).var)).ToList(); var res = new List<object>();
        foreach (double sw in new[] { -20.0, -25, -30, -35, -38, -40, -42, -45, -50, -60 })
        {
            double worst = 0, at = 0;
            foreach (var (a, v) in vs)
            { var e = (Iv.Point(PaperVariance(a, sw)) - v) / v; double m = Math.Max(Math.Abs(e.Lo), Math.Abs(e.Hi)); if (m > worst) { worst = m; at = a; } }
            res.Add(new { switchAt = sw, maxRelErr = worst, at, maxCertWidth = vs.Max(x => x.Item2.Width / x.Item2.Mid) });
        }
        return res;
    }
    public sealed record Row(double Alpha, double[] Lambda, double[] Var, double RelWidthVar, double[] SeriesRelErrVar, double[] SeriesRelErrLam, double PaperRelErr50, double PaperRelErr40, double[] Leak);
    public static List<Row> Grid()
    {
        var rows = new List<Row>();
        var alphas = new List<double> { 5, 3, 2, 1, 0, -1, -2, -2.9, -3.1, -5 };
        for (int k = 0; k <= 60; k++) alphas.Add(-Math.Round(5 * Math.Pow(200, k / 60.0), 6));   // -5 ... -1000
        alphas.AddRange(new[] { -10.0, -40, -49.999, -50, -50.001, -51, -80, -1000 });
        foreach (var al in alphas.Distinct().OrderByDescending(a => a))
        {
            var (lam, v) = Moments(al); double[] se = { double.NaN, double.NaN }, sl = { double.NaN, double.NaN };
            if (al <= -5) { var (sLam, sV) = Series(-al); var ev = (sV - v) / v; var el = (sLam - lam) / lam; se = new[] { ev.Lo, ev.Hi }; sl = new[] { el.Lo, el.Hi }; }
            double Rel(double pv) { var e = (Iv.Point(pv) - v) / v; return Math.Max(Math.Abs(e.Lo), Math.Abs(e.Hi)); }
            var lk = Leak(al);
            rows.Add(new Row(al, new[] { lam.Lo, lam.Hi }, new[] { v.Lo, v.Hi }, v.Width / v.Mid, se, sl, Rel(PaperVariance(al, -50)), Rel(PaperVariance(al, -40)), new[] { lk.Lo, lk.Hi }));
        }
        return rows;
    }
}
