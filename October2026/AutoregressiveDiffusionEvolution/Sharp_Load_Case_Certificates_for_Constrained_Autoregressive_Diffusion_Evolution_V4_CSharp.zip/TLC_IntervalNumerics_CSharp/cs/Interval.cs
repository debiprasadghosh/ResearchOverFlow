namespace TlcIntervals;

/// <summary>Closed interval with outward rounding. Add, subtract, multiply, divide and square root are
/// correctly rounded in IEEE 754, so a one-ulp outward step encloses the exact result. Math.Exp is not
/// guaranteed correctly rounded; its result is widened by four ulps, an assumption stated in the paper.</summary>
public readonly record struct Iv(double Lo, double Hi)
{
    public static Iv Point(double x) => new(x, x);
    static double Dn(double x) => Math.BitDecrement(x);
    static double Up(double x) => Math.BitIncrement(x);
    static double Dn4(double x) => Dn(Dn(Dn(Dn(x))));
    static double Up4(double x) => Up(Up(Up(Up(x))));
    public double Mid => 0.5 * (Lo + Hi);
    public double Width => Hi - Lo;
    public double Mag => Math.Max(Math.Abs(Lo), Math.Abs(Hi));
    public bool Overlaps(Iv o) => Lo <= o.Hi && o.Lo <= Hi;

    public static Iv operator +(Iv a, Iv b) => new(Dn(a.Lo + b.Lo), Up(a.Hi + b.Hi));
    public static Iv operator -(Iv a, Iv b) => new(Dn(a.Lo - b.Hi), Up(a.Hi - b.Lo));
    public static Iv operator -(Iv a) => new(-a.Hi, -a.Lo);
    public static Iv operator *(Iv a, Iv b)
    {
        double p1 = a.Lo * b.Lo, p2 = a.Lo * b.Hi, p3 = a.Hi * b.Lo, p4 = a.Hi * b.Hi;
        return new(Dn(Math.Min(Math.Min(p1, p2), Math.Min(p3, p4))), Up(Math.Max(Math.Max(p1, p2), Math.Max(p3, p4))));
    }
    public static Iv operator /(Iv a, Iv b)
    {
        if (b.Lo <= 0 && b.Hi >= 0) throw new DivideByZeroException("Denominator interval contains zero");
        double q1 = a.Lo / b.Lo, q2 = a.Lo / b.Hi, q3 = a.Hi / b.Lo, q4 = a.Hi / b.Hi;
        return new(Dn(Math.Min(Math.Min(q1, q2), Math.Min(q3, q4))), Up(Math.Max(Math.Max(q1, q2), Math.Max(q3, q4))));
    }
    public static Iv operator *(double s, Iv a) => Point(s) * a;
    public static Iv operator +(Iv a, double s) => a + Point(s);
    public static Iv operator -(Iv a, double s) => a - Point(s);
    public static Iv operator -(double s, Iv a) => Point(s) - a;
    public static Iv operator +(double s, Iv a) => Point(s) + a;
    public static Iv operator *(Iv a, double s) => a * Point(s);
    public static Iv operator /(Iv a, double s) => a / Point(s);
    public static Iv operator /(double s, Iv a) => Point(s) / a;

    /// <summary>Enclosure of the exact product of two doubles.</summary>
    public static Iv MulPP(double a, double b) { double p = a * b; return new(Dn(p), Up(p)); }
    /// <summary>sin with |sin'| <= 1: Math.Sin at the midpoint widened by four ulps (assumption as for Exp) plus the radius.</summary>
    public Iv Sin()
    {
        double m = Mid, r = Math.Max(Up(Hi - m), Up(m - Lo)), s = Math.Sin(m);
        return new(Math.Max(-1, Dn(Dn4(s) - r)), Math.Min(1, Up(Up4(s) + r)));
    }
    public Iv Sqr() => (Lo, Hi) switch
    {
        ( >= 0, _) => new(Dn(Lo * Lo), Up(Hi * Hi)),
        (_, <= 0) => new(Dn(Hi * Hi), Up(Lo * Lo)),
        _ => new(0.0, Up(Math.Max(Lo * Lo, Hi * Hi)))
    };
    public Iv Sqrt() => Lo < 0 ? throw new ArgumentOutOfRangeException(nameof(Lo)) : new(Math.Max(0, Dn(Math.Sqrt(Lo))), Up(Math.Sqrt(Hi)));
    public Iv Exp() => new(Math.Max(0, Dn4(Math.Exp(Lo))), Up4(Math.Exp(Hi)));
    public Iv Log() => Lo <= 0 ? throw new ArgumentOutOfRangeException(nameof(Lo)) : new(Dn4(Math.Log(Lo)), Up4(Math.Log(Hi)));   // same four-ulp assumption as Exp
    public Iv Abs() => Lo >= 0 ? this : Hi <= 0 ? -this : new(0, Math.Max(-Lo, Hi));
    public bool Contains(double x) => Lo <= x && x <= Hi;
    public bool Inside(Iv o) => o.Lo < Lo && Hi < o.Hi;
    public Iv Max0() => new(Math.Max(0, Lo), Math.Max(0, Hi));
    public static Iv Hull(Iv a, Iv b) => new(Math.Min(a.Lo, b.Lo), Math.Max(a.Hi, b.Hi));
}
