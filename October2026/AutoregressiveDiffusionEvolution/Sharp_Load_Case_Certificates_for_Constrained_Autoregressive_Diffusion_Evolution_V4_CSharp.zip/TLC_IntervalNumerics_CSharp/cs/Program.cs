using System.Diagnostics;
using System.Text.Json;
using TlcIntervals;

var jopt = new JsonSerializerOptions { WriteIndented = true, NumberHandling = System.Text.Json.Serialization.JsonNumberHandling.AllowNamedFloatingPointLiterals };
var results = new Dictionary<string, object>(); var sw = Stopwatch.StartNew(); var t = Stopwatch.StartNew();
void Log(string k, object v) { results[k] = v; var s = JsonSerializer.Serialize(v, jopt).Replace("\n", "").Replace("  ", ""); Console.WriteLine($"{k}: {(s.Length > 1800 ? s[..1800] + "..." : s)}  [{t.Elapsed.TotalSeconds:F1}s]"); t.Restart(); }
double[] E(Iv x) => new[] { x.Lo, x.Hi };

// Proposition 9: certified truncated moments on a grid, series errors, emulated implementation error, leakage
Log("truncation", Truncation.Grid());
Log("switch_study", Truncation.SwitchStudy());
Log("tail_widths", new[] { 1.0001, 3, 10, 50, 1000 }.Select(tt => { var a = Truncation.Tail(Iv.Point(tt), 1); var b = Truncation.Tail(Iv.Point(tt), 2); return new { t = tt, T1 = E(a), T2 = E(b) }; }).ToList());
// Section 3.3 examples
Log("screen_examples", new[] { 3.0, 5.0 }.Select(r => new { ratio = r, move = E(Truncation.Moments(r).lam), bound = E(2.0 * Normal.Pdf(Iv.Point(r))) }).ToList());
// Table 1 correlated half-space example, certified
{
    var v = (Iv.Point(33) / 5.0).Sqrt(); var alpha = -0.6 * Normal.Dec(1) / v;
    alpha = (-(Normal.Dec(0.1) + 0.5)) / v;
    var lam = Normal.Pdf(alpha) / Normal.Cdf(alpha); var vu = 1.0 - lam * (lam + alpha);
    var Sa = new[] { 1.0 + 2 * Normal.Dec(0.6), Normal.Dec(0.6) + 2 * Normal.Dec(0.8) };   // Sigma a with a = (1,2)
    var q = Sa.Select(s => s / v).ToArray(); var x0 = new[] { Normal.Dec(0.3), -Normal.Dec(0.2) };
    var m = new[] { x0[0] - q[0] * lam, x0[1] - q[1] * lam };
    var S11 = Iv.Point(1) - q[0].Sqr() * (1.0 - vu); var S22 = Normal.Dec(0.8) - q[1].Sqr() * (1.0 - vu); var S12 = Normal.Dec(0.6) - q[0] * q[1] * (1.0 - vu);
    var p = Normal.Cdf(alpha);
    Log("halfspace_example", new { alpha = E(alpha), mean = new[] { E(m[0]), E(m[1]) }, cov = new[] { E(S11), E(S12), E(S22) }, eventProb = E(p) });
    // Monte Carlo replicates of the reported simulation design (diagnostic)
    int reps = 200, n = 400000; var z1 = new double[reps]; var z2 = new double[reps]; var cnt = new double[reps];
    double m1 = m[0].Mid, m2 = m[1].Mid, s11 = S11.Mid, s22 = S22.Mid;
    Parallel.For(0, reps, k =>
    {
        var r = new SplitMix(20261018UL + (ulong)k * 104729UL); double a1 = 0, a2 = 0; int c = 0;
        double l11 = 1, l21 = 0.6, l22 = Math.Sqrt(0.8 - 0.36);
        for (int i = 0; i < n; i++)
        {
            double e1 = r.Normal(), e2 = r.Normal(); double y1 = 0.3 + l11 * e1, y2 = -0.2 + l21 * e1 + l22 * e2;
            if (0.5 + (y1 - 0.3) + 2 * (y2 + 0.2) <= -0.1) { a1 += y1; a2 += y2; c++; }
        }
        z1[k] = (a1 / c - m1) / Math.Sqrt(s11 / c); z2[k] = (a2 / c - m2) / Math.Sqrt(s22 / c); cnt[k] = c;
    });
    Log("halfspace_mc", new { reps, n, meanCount = cnt.Average(), sdZ1 = Math.Sqrt(z1.Select(x => x * x).Average()), sdZ2 = Math.Sqrt(z2.Select(x => x * x).Average()),
        fracAbsZ2Above3 = z2.Count(x => Math.Abs(x) >= 3.04) / (double)reps, fracAbsZ1Above3 = z1.Count(x => Math.Abs(x) >= 3.04) / (double)reps, z1, z2 });
}
// Proposition 11 certificates and the screening study
foreach (var chain in new[] { true, false })
{
    var (cert, screen) = Loadcase.Run(chain, chain ? 20261102UL : 20261103UL);
    Log(chain ? "cert_chain" : "cert_dense", cert); Log(chain ? "screen_chain" : "screen_dense", screen);
}
results["runtime"] = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription; results["seconds"] = sw.Elapsed.TotalSeconds;
File.WriteAllText("results.json", JsonSerializer.Serialize(results, jopt));
Console.WriteLine($"written {sw.Elapsed.TotalSeconds:F1}s");
