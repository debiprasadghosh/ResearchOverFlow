namespace TlcIntervals;

/// <summary>Proposition 11 and the screening study: a convex companion of the synthetic load-case problems with D = 1024,
/// an exactly orthonormal 40-column Sylvester-Hadamard active basis A, M = 200 load-case constraints
/// r_j(x) = 1 + z'Q_j z/2 + h_j'z + eps |x|^2 &lt;= 3/2 (z = A'x, eps = 1/1024) and cost c = b'z with |b| = 1.
/// Since A'A = I exactly, |x| = |z| for x = Az and every gradient lies in range(A); all work is done in 40 coordinates.</summary>
public static class Loadcase
{
    public const int Da = 40, M = 200, D = 1024; public const double Eps = 1.0 / 1024;
    public sealed record Problem(string Name, double[][,] Q, double[][] H, double[] B, double[] QFrob);
    static readonly double[] Vals = { -1.0, -0.5, 0.0, 0.5, 1.0 };
    public static Problem Make(bool chain, ulong seed)
    {
        var rng = new SplitMix(seed); var Q = new double[M][,]; var H = new double[M][]; var fro = new double[M];
        for (int j = 0; j < M; j++)
        {
            int g = j / 25; var idx = chain ? Enumerable.Range(5 * g, 5).Concat(Enumerable.Range(5 * ((g + 1) % 8), 5)).ToArray() : Enumerable.Range(0, Da).ToArray();
            int m = idx.Length; var r = new double[m, m]; for (int a = 0; a < m; a++) for (int c = 0; c < m; c++) r[a, c] = Vals[rng.Below(5)];
            var q = new double[Da, Da];
            for (int a = 0; a < m; a++) for (int c = 0; c < m; c++) { double s = 0; for (int k = 0; k < m; k++) s += r[k, a] * r[k, c]; q[idx[a], idx[c]] = s / (2.0 * m); }   // dyadic, exact
            Q[j] = q; H[j] = new double[Da]; foreach (var a in idx) H[j][a] = Vals[rng.Below(5)] / 8.0;
            var f = Iv.Point(0); for (int a = 0; a < Da; a++) for (int c = 0; c < Da; c++) f = f + Iv.MulPP(q[a, c], q[a, c]); fro[j] = f.Max0().Sqrt().Hi;
        }
        var b = Enumerable.Range(0, Da).Select(_ => rng.Normal()).ToArray(); double bn = Math.Sqrt(b.Sum(x => x * x)); b = b.Select(x => x / bn).ToArray();
        return new Problem(chain ? "chain" : "dense", Q, H, b, fro);
    }
    // ---- double-precision helpers
    static double[] Mv(double[,] q, double[] z) { var y = new double[Da]; for (int a = 0; a < Da; a++) { double s = 0; for (int c = 0; c < Da; c++) s += q[a, c] * z[c]; y[a] = s; } return y; }
    static double Dot(double[] a, double[] b) { double s = 0; for (int i = 0; i < a.Length; i++) s += a[i] * b[i]; return s; }
    public static double G(Problem p, int j, double[] z) => 0.5 * Dot(z, Mv(p.Q[j], z)) + Dot(p.H[j], z) + Eps * Dot(z, z) - 0.5;
    // ---- interval residual of constraint j at a design given by exact z (and extra orthogonal energy perp2 = |x_perp|^2)
    public static Iv GIv(Problem p, int j, Iv[] z, Iv perp2)
    {
        var q = p.Q[j]; var quad = Iv.Point(0); var lin = Iv.Point(0); var nz = Iv.Point(0);
        for (int a = 0; a < Da; a++)
        {
            var s = Iv.Point(0); for (int c = 0; c < Da; c++) if (q[a, c] != 0) s = s + q[a, c] * z[c];
            quad = quad + z[a] * s; lin = lin + p.H[j][a] * z[a]; nz = nz + z[a].Sqr();
        }
        return 0.5 * quad + lin + Eps * (nz + perp2) - 0.5;
    }
    /// <summary>Log-barrier Newton method in the active coordinates (double precision; certified afterwards).</summary>
    public static (double[] z, double t) Solve(Problem p)
    {
        var z = new double[Da]; double t = 1;
        for (int outer = 0; outer < 60 && M / t > 1e-9; outer++, t *= 4)
            for (int it = 0; it < 80; it++)
            {
                var grad = p.B.Select(v => t * v).ToArray(); var hess = new double[Da, Da];
                for (int j = 0; j < M; j++)
                {
                    double g = G(p, j, z); var dg = Mv(p.Q[j], z); for (int a = 0; a < Da; a++) dg[a] += p.H[j][a] + 2 * Eps * z[a];
                    for (int a = 0; a < Da; a++) { grad[a] += dg[a] / (-g); for (int c = 0; c < Da; c++) hess[a, c] += dg[a] * dg[c] / (g * g) + (p.Q[j][a, c] + (a == c ? 2 * Eps : 0)) / (-g); }
                }
                var step = SolveSpd(hess, grad.Select(v => -v).ToArray()); double dec = -Dot(grad, step);
                if (dec < 1e-26) break;
                double s = 1; double F0 = Barrier(p, z, t);
                while (true)
                {
                    var zn = z.Select((v, i) => v + s * step[i]).ToArray();
                    if (Enumerable.Range(0, M).All(j => G(p, j, zn) < 0) && Barrier(p, zn, t) <= F0 - 0.25 * s * dec) { z = zn; break; }
                    s *= 0.5; if (s < 1e-14) { break; }
                }
                if (s < 1e-14) break;
            }
        return (z, t / 4);
    }
    /// <summary>Newton iterations on the KKT system b + sum lambda_j grad g_j = 0, g_A(z) = 0 for a fixed active set.</summary>
    static (double[] z, double[] lam) Polish(Problem p, double[] z0, double[] lam0, int[] act)
    {
        var z = (double[])z0.Clone(); var lam = (double[])lam0.Clone(); int na = act.Length, n = Da + na;
        for (int it = 0; it < 8; it++)
        {
            var F = new double[n]; var J = new double[n, n];
            for (int a = 0; a < Da; a++) F[a] = p.B[a];
            for (int i = 0; i < na; i++)
            {
                int j = act[i]; var dg = Mv(p.Q[j], z); for (int a = 0; a < Da; a++) dg[a] += p.H[j][a] + 2 * Eps * z[a];
                for (int a = 0; a < Da; a++) { F[a] += lam[i] * dg[a]; J[a, Da + i] = dg[a]; J[Da + i, a] = dg[a]; for (int c = 0; c < Da; c++) J[a, c] += lam[i] * (p.Q[j][a, c] + (a == c ? 2 * Eps : 0)); }
                F[Da + i] = G(p, j, z);
            }
            var step = Lu(J, F.Select(v => -v).ToArray());
            for (int a = 0; a < Da; a++) z[a] += step[a]; for (int i = 0; i < na; i++) lam[i] += step[Da + i];
            if (step.Max(Math.Abs) < 1e-15) break;
        }
        return (z, lam);
    }
    static double[] Lu(double[,] a0, double[] b0)
    {
        int n = b0.Length; var a = (double[,])a0.Clone(); var b = (double[])b0.Clone();
        for (int k = 0; k < n; k++)
        {
            int piv = k; for (int i = k + 1; i < n; i++) if (Math.Abs(a[i, k]) > Math.Abs(a[piv, k])) piv = i;
            if (piv != k) { for (int c = 0; c < n; c++) (a[k, c], a[piv, c]) = (a[piv, c], a[k, c]); (b[k], b[piv]) = (b[piv], b[k]); }
            for (int i = k + 1; i < n; i++) { double f = a[i, k] / a[k, k]; if (f == 0) continue; for (int c = k; c < n; c++) a[i, c] -= f * a[k, c]; b[i] -= f * b[k]; }
        }
        var x = new double[n]; for (int i = n - 1; i >= 0; i--) { double s = b[i]; for (int c = i + 1; c < n; c++) s -= a[i, c] * x[c]; x[i] = s / a[i, i]; }
        return x;
    }
    static double Barrier(Problem p, double[] z, double t) { double f = t * Dot(p.B, z); for (int j = 0; j < M; j++) f -= Math.Log(-G(p, j, z)); return f; }
    static double[] SolveSpd(double[,] a, double[] b)
    {
        int n = b.Length; var l = new double[n, n];
        for (int j = 0; j < n; j++) { double s = a[j, j]; for (int k = 0; k < j; k++) s -= l[j, k] * l[j, k]; l[j, j] = Math.Sqrt(s); for (int i = j + 1; i < n; i++) { double u = a[i, j]; for (int k = 0; k < j; k++) u -= l[i, k] * l[j, k]; l[i, j] = u / l[j, j]; } }
        var y = new double[n]; for (int i = 0; i < n; i++) { double s = b[i]; for (int k = 0; k < i; k++) s -= l[i, k] * y[k]; y[i] = s / l[i, i]; }
        var x = new double[n]; for (int i = n - 1; i >= 0; i--) { double s = y[i]; for (int k = i + 1; k < n; k++) s -= l[k, i] * x[k]; x[i] = s / l[i, i]; }
        return x;
    }
    public sealed record Cert(string Name, string Multipliers, double Theta, int NegativeLambda, double[] Cost, double[] GapBound, double[] CostStar, double[] MaxResidual, double ResidualNorm, double RadiusR, double Complementarity, int ActiveCount, int NearActive, double Seconds);
    public sealed record Screen(double Rho, int Trials, double MeanCertified, double MeanHeuristicSkipped, int HeuristicMisses, int CertifiedMisses, double MeanViolated);
    /// <summary>Proposition 11 certificate (Corollary 8 with an explicit feasible radius), then the screening study of Theorem 7.</summary>
    public static (Cert cert, List<Screen> screen) Run(bool chain, ulong seed)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew(); var p = Make(chain, seed);
        var (z, t) = Solve(p);
        // KKT polish on the barrier's active set, then a convex shrink toward the strictly feasible origin (g(0) = -1/2)
        var lb0 = Enumerable.Range(0, M).Select(j => 1.0 / (t * -G(p, j, z))).ToArray(); double lm0 = lb0.Max();
        var actP = Enumerable.Range(0, M).Where(j => lb0[j] > 1e-6 * lm0).ToArray();
        var (zp, lp) = Polish(p, z, actP.Select(j => lb0[j]).ToArray(), actP);
        for (int drop = 0; drop < 10 && lp.Any(v => v < 0); drop++)
        {   // remove the most negative multiplier from the working set and polish again
            int worst = Array.IndexOf(lp, lp.Min()); actP = actP.Where((_, i) => i != worst).ToArray();
            (zp, lp) = Polish(p, z, actP.Select(j => lb0[j]).ToArray(), actP);
        }
        double theta = 1e-15; double[] zs = zp;
        while (theta < 1e-6) { zs = zp.Select(v => (1 - theta) * v).ToArray(); var zsi = zs.Select(Iv.Point).ToArray(); if (Enumerable.Range(0, M).All(j => GIv(p, j, zsi, Iv.Point(0)).Hi <= 0)) break; theta *= 4; }
        var lamPol = new double[M]; for (int i = 0; i < actP.Length; i++) lamPol[actP[i]] = Math.Max(0, lp[i]);
        var zBarrier = z; z = zs;
        var zi = z.Select(Iv.Point).ToArray();
        var g = Enumerable.Range(0, M).Select(j => GIv(p, j, zi, Iv.Point(0))).ToArray();
        if (g.Any(x => x.Hi > 0)) throw new InvalidOperationException("not certified feasible");
        var lamBar = lb0;      // barrier multipliers (any nonnegative choice gives a valid certificate)
        // feasible radius: eps |y|^2 <= 1/2 + |h_j| |y| for every feasible y (Q_j PSD), so |y| <= (|h| + sqrt(|h|^2 + 2 eps)) / (2 eps)
        var rho = Enumerable.Range(0, M).Select(j => { var hn = Iv.Point(0); foreach (var v in p.H[j]) hn = hn + Iv.Point(v).Sqr(); hn = hn.Sqrt(); return ((hn + (hn.Sqr() + 2.0 * Eps).Sqrt()) / (2.0 * Eps)).Hi; }).Min();
        var zn = Iv.Point(0); foreach (var e in zi) zn = zn + e.Sqr(); var R = Iv.Point(rho) + zn.Sqrt();
        double[] Grad(int j) { var d = Mv(p.Q[j], z); for (int a = 0; a < Da; a++) d[a] += p.H[j][a] + 2 * Eps * z[a]; return d; }
        (Iv gap, Iv rn, Iv comp) Certify(double[] lam)
        {
            var r = p.B.Select(Iv.Point).ToArray();
            for (int j = 0; j < M; j++)
            {
                if (lam[j] == 0) continue;
                for (int a = 0; a < Da; a++)
                { var s = Iv.Point(p.H[j][a]) + 2.0 * Eps * zi[a]; for (int c = 0; c < Da; c++) if (p.Q[j][a, c] != 0) s = s + p.Q[j][a, c] * zi[c]; r[a] = r[a] + lam[j] * s; }
            }
            var rn = Iv.Point(0); foreach (var e in r) rn = rn + e.Sqr(); rn = rn.Max0().Sqrt();
            var comp = Iv.Point(0); for (int j = 0; j < M; j++) if (lam[j] != 0) comp = comp - lam[j] * g[j];
            return (R * rn + comp, rn, comp);
        }
        // least-squares multipliers on the barrier's active set (any nonnegative choice gives a valid certificate)
        double lmax = lamBar.Max(); var act = Enumerable.Range(0, M).Where(j => lamBar[j] > 1e-6 * lmax).ToArray();
        var Gc = act.Select(Grad).ToArray(); int na = act.Length; var nm = new double[na, na]; var rhs = new double[na];
        for (int i = 0; i < na; i++) { rhs[i] = -Dot(Gc[i], p.B); for (int k = 0; k < na; k++) nm[i, k] = Dot(Gc[i], Gc[k]); }
        var lsq = SolveSpd(nm, rhs);
        var lamLs = new double[M]; for (int i = 0; i < na; i++) lamLs[act[i]] = lsq[i];
        var cands = new List<(string, double[])> { ("barrier", lamBar), ("KKT polish", lamPol) };
        if (lsq.All(v => v >= 0)) cands.Add(("least squares", lamLs));
        var best = cands.Select(c => (c.Item1, Certify(c.Item2))).OrderBy(c => c.Item2.gap.Hi).First();
        var (gap, rn, comp) = best.Item2; var lam = cands.First(c => c.Item1 == best.Item1).Item2;
        var cost = Iv.Point(0); for (int a = 0; a < Da; a++) cost = cost + Iv.MulPP(p.B[a], z[a]);
        var cstar = new Iv((cost - gap).Lo, cost.Hi);
        int active = na; int near = g.Count(x => x.Hi > -0.1);
        var cert = new Cert(p.Name, best.Item1, theta, lp.Count(v => v < 0), new[] { cost.Lo, cost.Hi }, new[] { gap.Lo, gap.Hi }, new[] { cstar.Lo, cstar.Hi }, new[] { g.Max(x => x.Lo), g.Max(x => x.Hi) }, rn.Hi, R.Hi, comp.Hi, active, near, sw.Elapsed.TotalSeconds);
        // ---- screening at the certified design y = A z with stored exact residual enclosures g
        var screens = new List<Screen>(); var rng = new SplitMix(seed ^ 0x5151);
        foreach (double rad in new[] { 1e-4, 1e-3, 3e-3, 1e-2, 3e-2, 0.1, 0.3, 1, 2, 4 })
        {
            int trials = 400; double cert0 = 0, skip = 0, viol = 0; int hm = 0, cm = 0;
            for (int tr = 0; tr < trials; tr++)
            {
                // uniform direction in R^1024: 40 active components and the norm of the 984 orthogonal ones
                var dz = Enumerable.Range(0, Da).Select(_ => rng.Normal()).ToArray(); double perp = 0; for (int k = 0; k < D - Da; k++) { double v = rng.Normal(); perp += v * v; }
                double nrm = Math.Sqrt(dz.Sum(v => v * v) + perp); dz = dz.Select(v => v * rad / nrm).ToArray(); double perp2 = perp * rad * rad / (nrm * nrm);
                var zz = z.Select((v, i) => Iv.Point(v) + Iv.Point(dz[i])).ToArray();
                for (int j = 0; j < M; j++)
                {
                    // Theorem 7 with B_j = (|Q_j| + 2 eps)(|y| + rho) + |h_j| on the ball of radius rho around y
                    var hn = Iv.Point(0); foreach (var v in p.H[j]) hn = hn + Iv.Point(v).Sqr();
                    var Bj = (Iv.Point(p.QFrob[j]) + 2.0 * Eps) * (zn.Sqrt() + rad) + hn.Sqrt();
                    bool certified = (g[j] + Bj * rad).Hi <= 0;
                    bool skipped = g[j].Hi < -0.1;                               // source working-set heuristic
                    var gn = GIv(p, j, zz, Iv.Point(perp2)); bool violated = gn.Lo > 0;
                    if (certified) cert0++; if (skipped) skip++; if (violated) viol++;
                    if (skipped && violated) hm++; if (certified && violated) cm++;
                }
            }
            screens.Add(new Screen(rad, trials, cert0 / trials, skip / trials, hm, cm, viol / trials));
        }
        return (cert, screens);
    }
}
