import json, math, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'font.family': 'DejaVu Sans'})
NAVY = '#213f63'; RUST = '#b5612f'; GREY = '#9aa3aa'; DARK = '#444444'; GOLD = '#c39a2f'; TEAL = '#2f7f86'
R = json.load(open('../cs/results.json')); S = json.load(open('../num/sym.json'))
tr = R['truncation']

# ---------- Figure 2: tail accuracy and moment-closure leakage
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.6))
deep = [x for x in tr if x['Alpha'] <= -5 and isinstance(x['SeriesRelErrVar'][0], float) and not math.isnan(x['SeriesRelErrVar'][0])]
deep = sorted(deep, key=lambda x: -x['Alpha'])
tt = [-x['Alpha'] for x in deep]
ax[0].loglog(tt, [max(abs(x['SeriesRelErrVar'][0]), abs(x['SeriesRelErrVar'][1])) for x in deep], '-', color=RUST, lw=1.3, label='Series (9), four terms')
direct = []
for x in deep:
    a = x['Alpha']; lam = 0.5 * (x['Lambda'][0] + x['Lambda'][1]); v = 0.5 * (x['Var'][0] + x['Var'][1])
    direct.append(abs((1 - lam * (lam + a)) - v) / v)
ax[0].loglog(tt, np.maximum(direct, 1e-17), '.', color=NAVY, ms=3, label='Direct 1 − Λ(Λ + α) in double')
ax[0].axvline(50, color=GREY, ls=':', lw=0.8); ax[0].axhline(3.4e-10, color=GREY, ls='--', lw=0.6)
ax[0].text(52, 1e-3, 'switch 50', fontsize=6.6, color=DARK)
ax[0].set_xlabel('Tail depth t = −α'); ax[0].set_ylabel('Relative error of the variance')
ax[0].set_title('A  Certified error of two computations', fontsize=9.5); ax[0].legend(fontsize=6.4, frameon=False, loc='lower left')
ax[0].set_ylim(1e-17, 1)
al = [x['Alpha'] for x in tr]; lk = [x['Leak'][1] for x in tr]
order = np.argsort(al); al = np.array(al)[order]; lk = np.array(lk)[order]
ax[1].plot(al, lk, '-', color=NAVY, lw=1.4)
ax[1].axhline(float(S['leak_limit']), color=RUST, ls='--', lw=1, label='Limit 1 − Φ(1) = 0.1587')
ax[1].plot([0], [float(S['leak_alpha0'])], 'o', color=RUST, ms=4)
ax[1].text(-0.9, 0.08, '0.0928 at α = 0', fontsize=6.6, color=DARK, ha='right')
ax[1].set_xscale('symlog', linthresh=1); ax[1].set_xlim(-1000, 5); ax[1].set_xticks([-1000, -100, -10, -1, 0, 5], ['−1000', '−100', '−10', '−1', '0', '5'])
ax[1].set_xlabel('Standardised boundary α'); ax[1].set_ylabel('Mass outside the half-space')
ax[1].set_title('B  Moment closure leaks probability', fontsize=9.5); ax[1].legend(fontsize=6.6, frameon=False, loc='lower left')
plt.tight_layout(); plt.savefig('fig2.png', dpi=300); plt.close()

# ---------- Figure 3: screening and the correlated simulation
fig, ax = plt.subplots(1, 2, figsize=(6.8, 2.6))
for key, col, mk in (('screen_chain', NAVY, 'o'), ('screen_dense', RUST, 's')):
    sc = R[key]
    ax[0].semilogx([s['Rho'] for s in sc], [s['MeanCertified'] for s in sc], mk + '-', color=col, ms=3.5, lw=1.2, label=f"{key.split('_')[1].capitalize()}: certified by (16)")
    ax[0].semilogx([s['Rho'] for s in sc], [s['MeanHeuristicSkipped'] for s in sc], ':', color=col, lw=1, label=f"{key.split('_')[1].capitalize()}: skipped by −0.1 rule")
ax[0].set_xlabel('Step radius ρ'); ax[0].set_ylabel('Load cases not re-solved (of 200)')
ax[0].set_title('A  Certified versus heuristic screening', fontsize=9.5); ax[0].legend(fontsize=6.0, frameon=False, loc='center left')
z2 = np.array(R['halfspace_mc']['z2'])
ax[1].hist(z2, bins=24, density=True, color=TEAL, alpha=0.7, label='200 C# replicates')
xs = np.linspace(-4, 4, 200); ax[1].plot(xs, np.exp(-xs ** 2 / 2) / np.sqrt(2 * np.pi), color=DARK, lw=1, label='Standard normal')
ax[1].axvline(-3.04, color=RUST, ls='--', lw=1.2, label='Reported, z = −3.04')
ax[1].set_xlabel('Standardised error, second mean component'); ax[1].set_ylabel('Density')
ax[1].set_title('B  Reported simulation is unusual', fontsize=9.5); ax[1].legend(fontsize=6.4, frameon=False, loc='upper right')
plt.tight_layout(); plt.savefig('fig3.png', dpi=300); plt.close()
print('ok')
