ADE V4 validated interval numerics (Sections 7.4-7.7, Appendix C)

cs/        .NET 8 console project. Build: dotnet build -c Release; run: dotnet bin/Release/net8.0/Ade.dll
           Writes results.json, replicates.json, testvectors.json and ddim_cells_07.json (about 100 s).
symbolic/  sym.py (Propositions 1-3, eqs 11, 13, 16, 19), sym2.py (Proposition 4),
           xcheck.py (float midpoint diagnostic), xlang.py (NumPy/SymPy values against C# enclosures).
           Run xlang.py after the C# program, from the symbolic folder with ../cs/testvectors.json present.
figures/   figs.py regenerates Figures 2-4 from the C# outputs.
