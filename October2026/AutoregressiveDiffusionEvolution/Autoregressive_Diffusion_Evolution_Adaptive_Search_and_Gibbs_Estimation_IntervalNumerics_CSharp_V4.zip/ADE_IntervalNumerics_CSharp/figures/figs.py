import json, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.collections import PatchCollection
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans'})
BLUE='#2a5b84'; BROWN='#a0602a'; GREY='#c3c9ce'; DARK='#555555'
R=json.load(open('../cs/results.json'))
# Figure 2: DDIM certified map
cells=json.load(open('../cs/ddim_cells_07.json'))
fig,ax=plt.subplots(1,2,figsize=(6.7,2.75))
cols={1:'#a9c4dc',-1:'#e3c19f',0:'#555555'}
for sgn in (1,-1,0):
    ps=[Rectangle((c['A0'],c['B0']),c['A1']-c['A0'],c['B1']-c['B0']) for c in cells if c['Sign']==sgn]
    ax[0].add_collection(PatchCollection(ps,facecolor=cols[sgn],edgecolor='none'))
a=np.linspace(0.0001,0.99,2000); r=np.sqrt(a)
# curve eta_crit(a,b)=0.7 solved for b
from scipy.optimize import brentq
bs=[]
for ai in a:
    f=lambda b: 2*b*(1+np.sqrt(ai))/((1+np.sqrt(b))*(np.sqrt(b)+np.sqrt(ai)))-0.49
    try: bs.append(brentq(f,ai+1e-12,0.999999))
    except ValueError: bs.append(np.nan)
ax[0].plot(a,bs,color='black',lw=1.0,label=r'$\eta_{crit}(a,b)=0.7$')
ax[0].plot([0.01,0.99],[0.01,0.99],color=DARK,lw=0.6,ls=':')
ax[0].plot(0.25,0.49,'o',ms=4,color='black'); ax[0].annotate('Section 4.2 example',(0.25,0.49),(0.04,0.72),fontsize=7.5,arrowprops=dict(arrowstyle='-',lw=0.5))
ax[0].set_xlim(0,1); ax[0].set_ylim(0,1); ax[0].set_xlabel('Current signal level $a$'); ax[0].set_ylabel('Next signal level $b$')
from matplotlib.patches import Patch
ax[0].legend(handles=[Patch(color=cols[1],label='Certified $A+B>1$'),Patch(color=cols[-1],label='Certified $A+B<1$'),Patch(color=cols[0],label='Undecided at depth 9'),ax[0].lines[0]],fontsize=7,loc='lower right',frameon=False)
m=R['ddim']; eta=[d['Eta'] for d in m]; tri=0.98**2/2
e=np.array([d['AreaExpand'] for d in m])/tri; c=np.array([d['AreaContract'] for d in m])/tri; u=np.array([d['AreaUndecided'] for d in m])/tri
x=np.arange(len(eta)); ax[1].bar(x,e,color=cols[1],label='Expansion'); ax[1].bar(x,u,bottom=e,color=cols[0],label='Undecided'); ax[1].bar(x,c,bottom=e+u,color=cols[-1],label='Contraction')
ax[1].set_xticks(x,[f'{v:g}' for v in eta]); ax[1].set_xlabel(r'DDIM noise parameter $\eta$'); ax[1].set_ylabel('Fraction of $(a,b)$ triangle'); ax[1].set_ylim(0,1.0)
ax[1].legend(fontsize=7,frameon=False,loc='lower left')
plt.tight_layout(); plt.savefig('fig2_ddim.png',dpi=300); plt.close()
# Figure 3: Gibbs
g=R['gibbs']; beta=np.array([d['beta'] for d in g]); lo=np.array([d['meanLo'] for d in g]); hi=np.array([d['meanHi'] for d in g])
fig,ax=plt.subplots(1,2,figsize=(6.7,2.75))
mid=(lo+hi)/2; ax[0].plot(beta,mid,'-',color=BLUE,lw=1.2,label=r'Certified $\mathbb{E}_{\pi_\beta}J$ (width $<2\times10^{-4}$)')
ax[0].plot(beta,mid,'o',color=BLUE,ms=3.5)
ax[0].plot([0.1,0.1],[10.74,10.87],'s',color=BROWN,ms=4,label='Reported corrected (layer, shared)')
ax[0].plot([0.1,0.1],[7.64,6.69],'v',color=DARK,ms=4,label='Reported uncorrected')
ax[0].set_xscale('log'); ax[0].set_yscale('log'); ax[0].set_xlabel(r'Inverse temperature $\beta$'); ax[0].set_ylabel('Mean scaled Himmelblau loss')
ax[0].legend(fontsize=7,frameon=False,loc='lower left')
for d in g:
    for k,cc in zip([1,5,20],['#9bb8d3','#2a5b84','#0f2a44']): pass
deltas=[1,5,20]; shades=['#9bb8d3',BLUE,'#0f2a44']
for k,(dl,sh) in enumerate(zip(deltas,shades)):
    tb=[next(c for c in d['concentration'] if c['delta']==dl) for d in g]
    ax[1].plot(beta,[t['theorem1Bound'] for t in tb],'--',color=sh,lw=1); ax[1].plot(beta,[t['certifiedUpper'] for t in tb],'-',color=sh,lw=1.2,label=fr'$\delta={dl}$')
ax[1].axhline(1,color=DARK,lw=0.6,ls=':'); ax[1].set_xscale('log'); ax[1].set_yscale('log')
ax[1].set_xlabel(r'Inverse temperature $\beta$'); ax[1].set_ylabel(r'Bound on $\pi_\beta(J\geq\delta)$')
ax[1].plot([],[],'--',color='black',lw=1,label='Theorem 1 bound (10)'); ax[1].plot([],[],'-',color='black',lw=1.2,label='Certified upper bound')
ax[1].legend(fontsize=6.5,frameon=False,loc='lower left',ncol=1)
plt.tight_layout(); plt.savefig('fig3_gibbs.png',dpi=300); plt.close()
# Figure 4: replication
reps=json.load(open('../cs/replicates.json'))
fig,ax=plt.subplots(1,2,figsize=(6.7,2.5))
cv=np.array([r['Corrected'] for r in reps]); cm=np.array([r['CondMeanCorrected'] for r in reps])
ax[0].hist(cv,bins=25,color=GREY); ax[0].axvline(5/12,color='black',ls='--',lw=1,label='Exact 5/12'); ax[0].axvline(0.415006,color=BROWN,lw=1.2,label='Python seed (Table 3)'); ax[0].axvline(R['audit']['Corrected'],color=BLUE,lw=1.2,label='C# seed 20261028')
ax[0].set_xlabel('Corrected mean loss'); ax[0].set_ylabel('Seeds'); ax[0].set_ylim(0,ax[0].get_ylim()[1]*1.55); ax[0].legend(fontsize=7,frameon=True,framealpha=1,edgecolor='none',loc='upper left')
ax[1].hist(cm,bins=25,color=GREY); ax[1].axvline(0.19861453057,color='black',ls='--',lw=1,label='Exact 0.198615'); ax[1].axvline(0.199716,color=BROWN,lw=1.2,label='Python seed (Table 3)')
ax[1].set_xlabel(r'Corrected conditional mean, $a=0.6,\ x=0.4$'); ax[1].set_ylabel('Seeds'); ax[1].set_ylim(0,ax[1].get_ylim()[1]*1.45); ax[1].legend(fontsize=7,frameon=True,framealpha=1,edgecolor='none',loc='upper left')
plt.tight_layout(); plt.savefig('fig4_replication.png',dpi=300); plt.close()
