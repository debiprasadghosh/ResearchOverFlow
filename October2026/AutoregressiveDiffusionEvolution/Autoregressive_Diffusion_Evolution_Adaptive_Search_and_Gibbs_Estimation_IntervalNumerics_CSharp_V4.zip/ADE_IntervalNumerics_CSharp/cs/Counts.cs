namespace AdeIntervals;

/// <summary>Brute-force key-visit counts for shared retrieval (16) and the layer-view policy (19).</summary>
public static class Counts
{
    public static long Shared(int n0, int T, int K) { long v = 0, size = n0; for (int r = 0; r < K * T; r++) { v += size; size++; } return v; }

    public static long Layer(int n0, int T, int K, bool appendBeforeFreeze)
    {
        var layers = Enumerable.Range(0, T + 1).Select(_ => new List<int>()).ToArray();
        for (int t = 1; t <= T; t++) layers[t].AddRange(Enumerable.Range(0, n0));
        int next = n0, previousOutput = -1; long visits = 0;
        for (int k = 1; k <= K; k++)
        for (int t = T; t >= 1; t--)
        {
            if (t == T && k > 1 && appendBeforeFreeze && !layers[T].Contains(previousOutput)) layers[T].Add(previousOutput);
            visits += layers[t].Count;                                    // frozen read view
            if (t == T && k > 1 && !appendBeforeFreeze && !layers[T].Contains(previousOutput)) layers[T].Add(previousOutput);
            int id = next++;
            if (t - 1 > 0) layers[t - 1].Add(id); else previousOutput = id;
        }
        return visits;
    }
}
