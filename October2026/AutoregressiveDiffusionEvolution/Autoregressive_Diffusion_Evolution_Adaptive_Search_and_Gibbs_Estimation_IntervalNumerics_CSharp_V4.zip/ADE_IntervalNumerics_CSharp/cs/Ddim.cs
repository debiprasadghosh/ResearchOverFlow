namespace AdeIntervals;

/// <summary>Certified map of the sign of A + B - 1 for the DDIM step (3) at fixed eta, compared with the
/// symbolic threshold eta_crit^2 = 2b(1 + sqrt a)/((1 + sqrt b)(sqrt b + sqrt a)).</summary>
public static class Ddim
{
    public sealed record MapResult(double Eta, long Boxes, double AreaExpand, double AreaContract, double AreaUndecided, long Contradictions, int MaxDepth);
    public sealed record Cell(double A0, double A1, double B0, double B1, int Sign);

    // 1 - b - sigma^2 >= 0 is proved symbolically, so clipping its enclosure at zero is sound.
    public static Iv Excess(Iv a, Iv b, double eta)
    {
        Iv sig2 = eta * eta * ((1.0 - b) * (1.0 - a / b) / (1.0 - a));
        Iv A = ((1.0 - b - sig2).Max0() / (1.0 - a)).Max0().Sqrt();   // ratio >= 0 by the same factorization
        return A * (1.0 - a.Sqrt()) + b.Sqrt() - 1.0;
    }
    public static Iv ThresholdGap(Iv a, Iv b, double eta)
    {
        Iv r = a.Sqrt(), s = b.Sqrt();
        Iv crit = 2.0 * (b * (1.0 + r)) / ((1.0 + s) * (s + r));
        return crit - Iv.Point(eta * eta);       // positive means expansion predicted
    }

    public static (MapResult, IReadOnlyList<Cell>) Map(double eta, double lo = 0.01, double hi = 0.99, int maxDepth = 9)
    {
        var cells = new List<Cell>(); long boxes = 0, contra = 0; double ae = 0, ac = 0, au = 0;
        void Rec(double a0, double a1, double b0, double b1, int depth)
        {
            if (b1 <= a0) return;                                  // entirely below the diagonal
            boxes++;
            bool valid = b0 > a1;                                  // strictly above the diagonal
            if (valid)
            {
                Iv a = new(a0, a1), b = new(b0, b1);
                Iv e = Excess(a, b, eta), g = ThresholdGap(a, b, eta);
                int se = e.Lo > 0 ? 1 : e.Hi < 0 ? -1 : 0, sg = g.Lo > 0 ? 1 : g.Hi < 0 ? -1 : 0;
                if (se != 0 && sg != 0 && se != sg) contra++;
                if (se != 0) { double area = (a1 - a0) * (b1 - b0); if (se > 0) ae += area; else ac += area; cells.Add(new(a0, a1, b0, b1, se)); return; }
            }
            if (depth >= maxDepth) { double area = (a1 - a0) * (b1 - b0) * (valid ? 1 : 0.5); au += area; cells.Add(new(a0, a1, b0, b1, 0)); return; }
            double am = 0.5 * (a0 + a1), bm = 0.5 * (b0 + b1);
            Rec(a0, am, b0, bm, depth + 1); Rec(am, a1, b0, bm, depth + 1); Rec(a0, am, bm, b1, depth + 1); Rec(am, a1, bm, b1, depth + 1);
        }
        Rec(lo, hi, lo, hi, 0);
        return (new MapResult(eta, boxes, ae, ac, au, contra, maxDepth), cells);
    }
}
