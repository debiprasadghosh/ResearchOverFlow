namespace AdeIntervals;

/// <summary>Validated enclosures of the Gaussian retrieval (2) and its attention form (5).</summary>
public static class Retrieval
{
    public sealed record Row(double A, double Beta, double FloatDiff, double DirectWidth, double ExpandedWidth, bool Overlap);

    static Iv[] Read(double[] x, double[][] Y, double[] J, double a, double beta, bool expanded)
    {
        int n = Y.Length, d = x.Length; var logit = new Iv[n];
        Iv sa = Iv.Point(a).Sqrt(), oneMinus = 1.0 - Iv.Point(a);
        for (int j = 0; j < n; j++)
        {
            Iv l = -(Iv.Point(beta) * Iv.Point(J[j]));
            if (!expanded)
            {
                Iv sq = Iv.Point(0); for (int k = 0; k < d; k++) sq += (Iv.Point(x[k]) - sa * Iv.Point(Y[j][k])).Sqr();
                l -= sq / (2.0 * oneMinus);
            }
            else
            {
                Iv dot = Iv.Point(0), nrm = Iv.Point(0);
                for (int k = 0; k < d; k++) { dot += Iv.Point(x[k]) * Iv.Point(Y[j][k]); nrm += Iv.Point(Y[j][k]).Sqr(); }
                l += sa / oneMinus * dot - Iv.Point(a) * nrm / (2.0 * oneMinus);
            }
            logit[j] = l;
        }
        double shift = logit.Max(t => t.Hi);
        var w = logit.Select(t => (t - shift).Exp()).ToArray();
        Iv den = w.Aggregate(Iv.Point(0), (s, t) => s + t);
        return Enumerable.Range(0, d).Select(k =>
        {
            Iv num = Iv.Point(0); for (int j = 0; j < n; j++) num += w[j] * Iv.Point(Y[j][k]);
            // Each coordinate of the weighted mean lies in the hull of the values; intersect with it.
            Iv r = num / den; double mn = Y.Min(y => y[k]), mx = Y.Max(y => y[k]);
            return new Iv(Math.Max(r.Lo, mn), Math.Min(r.Hi, mx));
        }).ToArray();
    }

    static double[] FloatRead(double[] x, double[][] Y, double[] J, double a, double beta, bool expanded)
    {
        int n = Y.Length, d = x.Length; var l = new double[n];
        for (int j = 0; j < n; j++)
        {
            if (!expanded) { double sq = 0; for (int k = 0; k < d; k++) { double t = x[k] - Math.Sqrt(a) * Y[j][k]; sq += t * t; } l[j] = -beta * J[j] - sq / (2 * (1 - a)); }
            else { double dot = 0, nr = 0; for (int k = 0; k < d; k++) { dot += x[k] * Y[j][k]; nr += Y[j][k] * Y[j][k]; } l[j] = Math.Sqrt(a) / (1 - a) * dot - beta * J[j] - a * nr / (2 * (1 - a)); }
        }
        double m = l.Max(); var w = l.Select(t => Math.Exp(t - m)).ToArray(); double s = w.Sum();
        return Enumerable.Range(0, d).Select(k => Enumerable.Range(0, n).Sum(j => w[j] * Y[j][k]) / s).ToArray();
    }

    public static object TestVectors(int seed)
    {
        var rnd = new Random(seed); double N() => Math.Sqrt(-2 * Math.Log(1 - rnd.NextDouble())) * Math.Cos(2 * Math.PI * rnd.NextDouble());
        var Y = Enumerable.Range(0, 71).Select(_ => Enumerable.Range(0, 5).Select(_ => N()).ToArray()).ToArray();
        var J = Y.Select(y => y.Sum(t => t * t)).ToArray(); var x = Enumerable.Range(0, 5).Select(_ => N()).ToArray();
        var reads = new List<object>();
        foreach (double a in new[] { 1e-4, 0.01, 0.3, 0.7, 0.99, 0.9999 })
        foreach (double beta in new[] { 0.0, 1.0, 10.0 })
        {
            var d = Read(x, Y, J, a, beta, false);
            reads.Add(new { a, beta, lo = d.Select(t => t.Lo).ToArray(), hi = d.Select(t => t.Hi).ToArray() });
        }
        var coeffs = new List<object>();
        foreach (double a in new[] { 0.01, 0.1, 0.25, 0.5, 0.8 })
        foreach (double b in new[] { 0.3, 0.49, 0.9, 0.99 })
        foreach (double eta in new[] { 0.0, 0.5, 0.7, 1.0 })
        {
            if (b <= a) continue;
            Iv ia = Iv.Point(a), ib = Iv.Point(b);
            Iv sig2 = eta * eta * ((1.0 - ib) * (1.0 - ia / ib) / (1.0 - ia));
            Iv A = ((1.0 - ib - sig2).Max0() / (1.0 - ia)).Max0().Sqrt(); Iv B = ib.Sqrt() - A * ia.Sqrt();
            coeffs.Add(new { a, b, eta, Alo = A.Lo, Ahi = A.Hi, Blo = B.Lo, Bhi = B.Hi, s2lo = sig2.Lo, s2hi = sig2.Hi });
        }
        return new { Y, J, x, reads, coeffs };
    }

    public static IReadOnlyList<Row> Run(int seed)
    {
        var rnd = new Random(seed); double N() => Math.Sqrt(-2 * Math.Log(1 - rnd.NextDouble())) * Math.Cos(2 * Math.PI * rnd.NextDouble());
        var Y = Enumerable.Range(0, 71).Select(_ => Enumerable.Range(0, 5).Select(_ => N()).ToArray()).ToArray();
        var J = Y.Select(y => y.Sum(t => t * t)).ToArray(); var x = Enumerable.Range(0, 5).Select(_ => N()).ToArray();
        var rows = new List<Row>();
        foreach (double a in new[] { 1e-4, 0.01, 0.3, 0.7, 0.99, 0.9999 })
        foreach (double beta in new[] { 0.0, 1.0, 10.0 })
        {
            var d = Read(x, Y, J, a, beta, false); var e = Read(x, Y, J, a, beta, true);
            var fd = FloatRead(x, Y, J, a, beta, false); var fe = FloatRead(x, Y, J, a, beta, true);
            rows.Add(new(a, beta, fd.Zip(fe, (p, q) => Math.Abs(p - q)).Max(), d.Max(t => t.Width), e.Max(t => t.Width), d.Zip(e, (p, q) => p.Overlaps(q)).All(t => t)));
        }
        return rows;
    }
}
