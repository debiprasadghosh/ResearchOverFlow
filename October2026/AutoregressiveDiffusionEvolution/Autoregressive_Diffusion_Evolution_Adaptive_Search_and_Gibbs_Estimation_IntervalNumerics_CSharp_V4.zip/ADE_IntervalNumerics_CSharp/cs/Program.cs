using System.Diagnostics;
using System.Text.Json;
using AdeIntervals;

var results = new Dictionary<string, object>();
var opts = new JsonSerializerOptions { WriteIndented = true, IncludeFields = true };

// 1. Validated Gibbs quadrature on the Himmelblau target
var gibbs = new List<object>();
foreach (double beta in new[] { 0.05, 0.1, 0.2, 0.4, 1.0 })
{
    var sw = Stopwatch.StartNew(); var (r, boxes) = Gibbs.Run(beta, 1e-6); sw.Stop();
    var conc = new List<object>();
    foreach (double delta in new[] { 1.0, 5.0, 20.0 })
    {
        double nuLow = Gibbs.NuMassBelow(boxes, delta / 2);
        double bound = Math.Exp(-beta * delta / 2) / nuLow;              // Theorem 1 with certified denominator
        double upper = Gibbs.UpperTailProbability(boxes, r, delta);
        conc.Add(new { delta, nuMassLower = nuLow, theorem1Bound = bound, certifiedUpper = upper });
    }
    gibbs.Add(new { beta, Zlo = r.Z.Lo, Zhi = r.Z.Hi, meanLo = r.MeanLoss.Lo, meanHi = r.MeanLoss.Hi, r.Boxes, seconds = sw.Elapsed.TotalSeconds, concentration = conc });
    Console.WriteLine($"beta={beta} Z=[{r.Z.Lo:R},{r.Z.Hi:R}] E[J]=[{r.MeanLoss.Lo:R},{r.MeanLoss.Hi:R}] boxes={r.Boxes} {sw.Elapsed.TotalSeconds:F1}s");
}
results["gibbs"] = gibbs;

// 2. Certified DDIM expansion map
var maps = new List<object>();
foreach (double eta in new[] { 0.0, 0.3, 0.5, 0.7, 0.85, 1.0 })
{
    var (m, cells) = Ddim.Map(eta);
    maps.Add(m);
    if (eta == 0.7) File.WriteAllText("ddim_cells_07.json", JsonSerializer.Serialize(cells));
    Console.WriteLine($"eta={eta} expand={m.AreaExpand:F4} contract={m.AreaContract:F4} undecided={m.AreaUndecided:F5} contradictions={m.Contradictions} boxes={m.Boxes}");
}
results["ddim"] = maps;
var ex = Ddim.Excess(Iv.Point(0.25), Iv.Point(0.49), 0.7);
results["ddim_example"] = new { lo = ex.Lo, hi = ex.Hi };

// 3. Validated retrieval identity
results["retrieval"] = Retrieval.Run(20261028);
foreach (var row in (IReadOnlyList<Retrieval.Row>)results["retrieval"]) Console.WriteLine(row);

File.WriteAllText("testvectors.json", JsonSerializer.Serialize(Retrieval.TestVectors(20261028)));

// 4. Visit counts
results["counts"] = new { shared = Counts.Shared(64, 16, 96), layerCorrected = Counts.Layer(64, 16, 96, true), layerLiteral = Counts.Layer(64, 16, 96, false) };
Console.WriteLine(JsonSerializer.Serialize(results["counts"]));

// 5. Analytic audit rerun
results["audit"] = Audit.Run(20261028);
Console.WriteLine(JsonSerializer.Serialize(results["audit"]));
// 6. Seed replication of the audit (System.Random streams; not the NumPy stream of Table 3)
var reps = Enumerable.Range(1, 200).Select(sd => Audit.Run(sd)).ToList();
double Mean(IEnumerable<double> v) => v.Average();
double Sd(IEnumerable<double> v) { var l = v.ToList(); double m = l.Average(); return Math.Sqrt(l.Sum(t => (t - m) * (t - m)) / (l.Count - 1)); }
results["replication"] = new
{
    seeds = reps.Count,
    corrMean = Mean(reps.Select(r => r.Corrected)), corrSd = Sd(reps.Select(r => r.Corrected)),
    corrMin = reps.Min(r => r.Corrected), corrMax = reps.Max(r => r.Corrected),
    rawMean = Mean(reps.Select(r => r.Raw)), rawSd = Sd(reps.Select(r => r.Raw)),
    condMean = Mean(reps.Select(r => r.CondMeanCorrected)), condSd = Sd(reps.Select(r => r.CondMeanCorrected)),
    condRawMean = Mean(reps.Select(r => r.CondMeanRaw)),
    essMin = reps.Min(r => r.Ess), essMax = reps.Max(r => r.Ess),
    maxW = reps.Max(r => r.MaxW), maxWJ = reps.Max(r => r.MaxWJ),
    allBounds = reps.All(r => r.AllWBelowBound && r.AllWJBelowBound),
    within2Sd = reps.Count(r => Math.Abs(r.Corrected - r.ExactMean) <= 2 * Sd(reps.Select(q => q.Corrected)))
};
Console.WriteLine(JsonSerializer.Serialize(results["replication"]));
File.WriteAllText("replicates.json", JsonSerializer.Serialize(reps.Select(r => new { r.Corrected, r.Raw, r.CondMeanCorrected, r.Ess })));
results["runtime"] = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription;
File.WriteAllText("results.json", JsonSerializer.Serialize(results, opts));
Console.WriteLine("written");
