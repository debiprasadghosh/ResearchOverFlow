namespace AdeIntervals;

/// <summary>Cross-language rerun of the analytic audit of Section 7.2 with interval-certified weight bounds.</summary>
public static class Audit
{
    public sealed record Result(int Draws, double Corrected, double Raw, double CondMeanCorrected, double CondMeanRaw, double Ess, double MaxW, double MaxWJ,
        bool AllWBelowBound, bool AllWJBelowBound, double ExactMean, double ExactCondMean);

    static double LogN(double y, double m, double s2) => -0.5 * (Math.Log(2 * Math.PI * s2) + (y - m) * (y - m) / s2);
    static double LogAddExp(double p, double q) { double m = Math.Max(p, q); return m + Math.Log(Math.Exp(p - m) + Math.Exp(q - m)); }

    public static Result Run(int seed, int n = 50_000, double beta = 0.7, double eps = 0.2)
    {
        var rnd = new Random(seed); double Nrm() => Math.Sqrt(-2 * Math.Log(1 - rnd.NextDouble())) * Math.Cos(2 * Math.PI * rnd.NextDouble());
        double mu = 0.8; var y = new double[n]; var lq = new double[n];
        for (int i = 0; i < n; i++)
        {
            y[i] = rnd.NextDouble() < eps ? Nrm() : mu + 0.3 * Nrm();
            lq[i] = LogAddExp(Math.Log(eps) + LogN(y[i], 0, 1), Math.Log(1 - eps) + LogN(y[i], mu, 0.09));
            mu = 0.8 * mu + 0.02 * Math.Tanh(y[i]);                       // predictable update after the draw
        }
        var lw = Enumerable.Range(0, n).Select(i => -beta * y[i] * y[i] + LogN(y[i], 0, 1) - lq[i]).ToArray();
        double mx = lw.Max(); var w = lw.Select(t => Math.Exp(t - mx)).ToArray(); double sw = w.Sum();
        double corr = Enumerable.Range(0, n).Sum(i => w[i] * y[i] * y[i]) / sw;
        var rw = y.Select(t => Math.Exp(-beta * t * t)).ToArray(); double raw = Enumerable.Range(0, n).Sum(i => rw[i] * y[i] * y[i]) / rw.Sum();
        double a = 0.6, x = 0.4; double K(double t) => Math.Exp(-(x - Math.Sqrt(a) * t) * (x - Math.Sqrt(a) * t) / (2 * (1 - a)));
        double cc = Enumerable.Range(0, n).Sum(i => w[i] * K(y[i]) * y[i]) / Enumerable.Range(0, n).Sum(i => w[i] * K(y[i]));
        double cr = Enumerable.Range(0, n).Sum(i => rw[i] * K(y[i]) * y[i]) / Enumerable.Range(0, n).Sum(i => rw[i] * K(y[i]));
        double ess = sw * sw / w.Sum(t => t * t);
        // Interval-certified unnormalised weights W_i = exp(lw_i), and bounds 1/eps and 1/(eps e beta) from (13).
        double bW = 1 / eps, bWJ = 1 / (eps * Math.E * beta); bool okW = true, okWJ = true; double maxW = 0, maxWJ = 0;
        for (int i = 0; i < n; i++)
        {
            Iv W = Iv.Point(lw[i]).Exp(); maxW = Math.Max(maxW, W.Hi); maxWJ = Math.Max(maxWJ, (W * Iv.Point(y[i] * y[i])).Hi);
            okW &= W.Hi <= bW; okWJ &= (W * Iv.Point(y[i] * y[i])).Hi <= bWJ;
        }
        double v = 1 / (1 + 2 * beta);
        return new(n, corr, raw, cc, cr, ess, maxW, maxWJ, okW, okWJ, v, Math.Sqrt(a) * v * x / (a * v + 1 - a));
    }
}
