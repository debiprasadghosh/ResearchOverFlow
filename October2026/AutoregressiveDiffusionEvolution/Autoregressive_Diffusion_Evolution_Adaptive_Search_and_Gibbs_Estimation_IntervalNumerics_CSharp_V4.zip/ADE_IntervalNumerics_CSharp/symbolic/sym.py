import sympy as sp, json
out={}
a,b,eta,x,y,beta,D=sp.symbols('a b eta x y beta D',positive=True)
# Prop 1: expansion of Gaussian exponent
X,Yv=sp.symbols('X Y',real=True)
lhs=-(X-sp.sqrt(a)*Yv)**2/(2*(1-a)); rhs=sp.sqrt(a)/(1-a)*X*Yv - a*Yv**2/(2*(1-a)) - X**2/(2*(1-a))
out['P1_expansion']=sp.simplify(lhs-rhs)==0
# Prop 2 and coefficient identities; parameterize b = a + (1-a) s
s=sp.symbols('s',positive=True)
bb=a+(1-a)*s
sig2=eta**2*(1-bb)*(1-a/bb)/(1-a)
slack=sp.factor(sp.simplify((1-bb-sig2)))
out['P2_1-b-sigma2']=str(slack)
# (1-a/b)/(1-a) <= 1  <=>  ab <= b ... symbolic gap
out['P2_ratio_gap']=str(sp.factor(sp.simplify(1-(1-a/b)/(1-a))))
A=sp.sqrt((1-b-eta**2*(1-b)*(1-a/b)/(1-a))/(1-a)); B=sp.sqrt(b)-A*sp.sqrt(a)
ex={a:sp.Rational(1,4),b:sp.Rational(49,100),eta:sp.Rational(7,10)}
out['P2_example_A_B_sum']=[str(sp.nsimplify(A.subs(ex))),str(sp.nsimplify(B.subs(ex))),str(sp.nsimplify((A+B).subs(ex)))]
r_,s_=sp.symbols('r s_',positive=True)   # r=sqrt(a), s=sqrt(b)
etac2=2*s_**2*(1+r_)/((1+s_)*(s_+r_)); out['eta_crit_example']=str(sp.sqrt(etac2.subs({r_:sp.Rational(1,2),s_:sp.Rational(7,10)})).evalf(12))
# verify threshold: A+B=1 at eta_crit symbolically (substitute a=r^2,b=s^2)
Ar=sp.sqrt((1-s_**2-sp.Symbol('e2')*(1-s_**2)*(1-r_**2/s_**2)/(1-r_**2))/(1-r_**2))
eq=sp.simplify((Ar*(1-r_)+s_-1).subs(sp.Symbol('e2'),etac2))
out['eta_crit_root_check']=str(sp.simplify(sp.nsimplify(eq.subs({r_:sp.Rational(1,3),s_:sp.Rational(4,5)}))))
# Prop 3 limit a->0
xv,yv,w=sp.symbols('x y w',real=True)
term=sp.exp((2*sp.sqrt(a)*xv*yv-a*yv**2)/(2*(1-a)))
out['P3_limit']=str(sp.limit(term,a,0))
# Analytic audit: nu=N(0,1), J=y^2
v=1/(1+2*beta); out['audit_v']=str(v.subs(beta,sp.Rational(7,10)))
yy=sp.symbols('yy',real=True); tgt=sp.exp(-beta*yy**2-yy**2/2)
EJ=sp.simplify(sp.integrate(yy**2*tgt,(yy,-sp.oo,sp.oo))/sp.integrate(tgt,(yy,-sp.oo,sp.oo)))
out['audit_EJ']=str(EJ); out['audit_EJ_0.7']=str(sp.nsimplify(EJ.subs(beta,sp.Rational(7,10))))
# conditional mean under target with Gaussian kernel: posterior of y given x=sqrt(a)y+sqrt(1-a)noise, prior N(0,v)
av=sp.Rational(3,5); vv=sp.Rational(5,12); xq=sp.Rational(2,5)
cm=sp.sqrt(av)*vv*xq/(av*vv+1-av); out['audit_condmean']=str(sp.N(cm,10))
num=sp.integrate(yy*sp.exp(-yy**2/(2*vv))*sp.exp(-(xq-sp.sqrt(av)*yy)**2/(2*(1-av))),(yy,-sp.oo,sp.oo))
den=sp.integrate(sp.exp(-yy**2/(2*vv))*sp.exp(-(xq-sp.sqrt(av)*yy)**2/(2*(1-av))),(yy,-sp.oo,sp.oo))
out['audit_condmean_integral']=str(sp.N(sp.simplify(num/den),10))
# (11) derivative identity for this Gaussian family
Eb=EJ; out['eq11_dE_dbeta']=str(sp.simplify(sp.diff(Eb,beta)))
VarJ=sp.simplify(sp.integrate(yy**4*tgt,(yy,-sp.oo,sp.oo))/sp.integrate(tgt,(yy,-sp.oo,sp.oo))-EJ**2)
out['eq11_check']=bool(sp.simplify(sp.diff(Eb,beta)+VarJ)==0)
# (13) bound with eps0=0.2, beta=0.7
u=sp.symbols('u',positive=True); mx=sp.maximum(u*sp.exp(-beta*u),u,sp.Interval(0,sp.oo)); out['ue_max']=str(mx)
out['eq13_bound']=str(sp.N(1/(sp.Rational(1,5)*sp.E*sp.Rational(7,10)),10))
# counts (16) and (19)
n0,T,K=64,16,96; R=K*T
out['V_shared']=R*n0+R*(R-1)//2; out['V_layer']=T*n0*K+T*K*(K-1)//2+(T-1)*K
out['storage']=[8*1600*(2+2),8*2000*(1000+200+1)]
# Theorem 1 symbolic: concentration bound for Gaussian audit
print(json.dumps({k:(bool(v) if isinstance(v,bool) else v) for k,v in out.items()},indent=1,default=str))
json.dump(out,open('sym.json','w'),indent=1,default=str)
