import json, numpy as np, sympy as sp
tv=json.load(open('../cs/testvectors.json'))
Y=np.array(tv['Y']); J=np.array(tv['J']); x=np.array(tv['x'])
out={'reads':0,'reads_inside':0,'coeffs':0,'coeffs_inside':0,'exact_inside':0,'max_read_width':0}
for r in tv['reads']:
    a,b=r['a'],r['beta']
    for form in ('direct','expanded'):
        if form=='direct': l=-b*J-((x-np.sqrt(a)*Y)**2).sum(1)/(2*(1-a))
        else: l=np.sqrt(a)/(1-a)*Y@x-b*J-a*(Y*Y).sum(1)/(2*(1-a))
        w=np.exp(l-l.max()); m=(w[:,None]*Y).sum(0)/w.sum()
        out['reads']+=1; out['reads_inside']+=int(np.all((np.array(r['lo'])<=m)&(m<=np.array(r['hi']))))
    out['max_read_width']=max(out['max_read_width'],float(np.max(np.array(r['hi'])-np.array(r['lo']))))
for c in tv['coeffs']:
    a,b,eta=c['a'],c['b'],c['eta']
    s2=eta**2*(1-b)*(1-a/b)/(1-a); A=np.sqrt((1-b-s2)/(1-a)); B=np.sqrt(b)-A*np.sqrt(a)
    out['coeffs']+=1; out['coeffs_inside']+=int(c['Alo']<=A<=c['Ahi'] and c['Blo']<=B<=c['Bhi'] and c['s2lo']<=s2<=c['s2hi'])
    # exact real values of the coefficients for the binary64 inputs, at 40 digits
    ea,eb,ee=[sp.Rational(v) for v in (a,b,eta)]
    S2=ee**2*(1-eb)*(1-ea/eb)/(1-ea); EA=sp.sqrt((1-eb-S2)/(1-ea)); EB=sp.sqrt(eb)-EA*sp.sqrt(ea)
    fa,fb=sp.N(EA,40),sp.N(EB,40)
    out['exact_inside']+=int(bool(sp.Rational(c['Alo'])<=fa<=sp.Rational(c['Ahi']) and sp.Rational(c['Blo'])<=fb<=sp.Rational(c['Bhi'])))
json.dump(out,open('xlang.json','w'),indent=1); print(out)
