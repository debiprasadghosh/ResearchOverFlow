import numpy as np, json
h=0.002; g=np.arange(-8+h/2,8,h)
out={}
for beta in [0.05,0.1,0.2,0.4,1.0]:
    Z=0.0; N=0.0
    for i in range(0,len(g),500):
        U,V=np.meshgrid(g[i:i+500],g,indexing='ij'); u=4*U; v=4*V
        J=(u*u+v-11)**2+(u+v*v-7)**2
        f=np.exp(-beta*J-(U*U+V*V)/2)/(2*np.pi)
        Z+=f.sum()*h*h; N+=(J*f).sum()*h*h
    out[beta]=(Z,N/Z); print(beta,Z,N/Z)
json.dump(out,open('xcheck.json','w'))
