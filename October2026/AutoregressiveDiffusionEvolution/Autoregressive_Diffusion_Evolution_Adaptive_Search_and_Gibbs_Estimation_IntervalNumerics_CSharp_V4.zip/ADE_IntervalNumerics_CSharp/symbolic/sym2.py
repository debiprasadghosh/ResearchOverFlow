import sympy as sp, json
r,s,e2=sp.symbols('r s e2',positive=True)      # r=sqrt(a), s=sqrt(b), e2=eta^2, 0<r<s<1
sig2=e2*(1-s**2)*(1-r**2/s**2)/(1-r**2)
A2=(1-s**2-sig2)/(1-r**2)
D=sp.together(A2-((1-s)/(1-r))**2)             # A+B-1 has the sign of D (both sides of A>(1-s)/(1-r) nonnegative)
c1=-sp.diff(D,e2)
etac2=2*s**2*(1+r)/((1+s)*(s+r))
out={}
out['D_linear_in_eta2']=bool(sp.simplify(sp.diff(D,e2,2))==0)
out['c1']=str(sp.factor(c1))
out['factorization_check']=bool(sp.simplify(D-c1*(etac2-e2))==0)
out['one_minus_etac2']=str(sp.factor(1-etac2))
out['etac2_at_r0']=str(sp.simplify(etac2.subs(r,0)))
out['etac2_limit_s_to_1']=str(sp.limit(etac2,s,1))
out['etac2_limit_r_to_s']=str(sp.simplify(etac2.subs(r,s)))
# monotonicity in r at fixed s: derivative sign
out['d_etac2_dr']=str(sp.factor(sp.diff(etac2,r)))
out['d_etac2_ds']=str(sp.factor(sp.diff(etac2,s)))
ex={r:sp.Rational(1,2),s:sp.Rational(7,10)}
out['example_etac']=str(sp.sqrt(etac2.subs(ex)).evalf(15))
out['example_excess_eta07']=str(sp.nsimplify((sp.sqrt(A2)*(1-r)+s-1).subs(ex).subs(e2,sp.Rational(49,100))))
# Area of expansion region in the (a,b) triangle for each eta, by numerical integration (for comparison with intervals)
import mpmath as mp
def area(eta):
    f=lambda a: mp.quad(lambda b: 1 if 2*b*(1+mp.sqrt(a))/((1+mp.sqrt(b))*(mp.sqrt(b)+mp.sqrt(a)))>eta**2 else 0,[max(a,0.01),0.99]) if a<0.99 else 0
    return float(mp.quad(f,[0.01,0.99]))
mp.mp.dps=15
out['expand_area_mp']={str(eta):area(eta) for eta in [0.7,0.85]}
json.dump(out,open('sym2.json','w'),indent=1); print(json.dumps(out,indent=1))
