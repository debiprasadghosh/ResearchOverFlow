"""Exhaustive checks of every finite claim in the paper, plus extensions."""
import itertools as it
import numpy as np

F = range(3)
sites = [(a, b) for a in F for b in F]          # ball i = 3a+b+1
H = np.array([[1]*9, [a for a, b in sites], [b for a, b in sites]]) % 3
inv = {1: 1, 2: 2}

# ---------- classical two-pan protocol ----------
def weigh(L, R, ball, sgn):
    m = lambda S: sum(1 + (sgn if x == ball else 0) for x in S)
    d = m(L) - m(R)
    return '>' if d > 0 else '<' if d < 0 else '='

def two_pan(ball, sgn):
    r1 = weigh({1, 2, 3}, {4, 5, 6}, ball, sgn)
    if r1 == '=':
        r2 = weigh({1, 2, 7}, {3, 8, 9}, ball, sgn)
        r3 = weigh({8}, {9}, ball, sgn)
        return (r1, r2, r3)
    flip = {'>': '<', '<': '>', '=': '='}
    # right-heavy: mirror by swapping the first-round pans
    r2 = weigh({1, 4, 7}, {2, 5, 8}, ball, sgn)
    probe = {'>': 1, '<': 2, '=': 3}[r2] if r1 == '>' else {'>': 2, '<': 1, '=': 3}[r2]
    # after right-heavy first weighing candidates are 1L,2L,3L,4H,5H,6H
    r3 = weigh({probe}, {7}, ball, sgn)
    return (r1, r2, r3)

paths = {}
for ball in range(1, 10):
    for sgn in (1, -1):
        paths.setdefault(two_pan(ball, sgn), []).append((ball, sgn))
assert len(paths) == 18 and all(len(v) == 1 for v in paths.values())
# check the decoding rule stated in Table 1 for left-heavy branch
for (r1, r2, r3), [(ball, sgn)] in paths.items():
    if r1 == '>':
        exp = {('>', '>'): (1, 1), ('>', '='): (5, -1), ('<', '>'): (2, 1),
               ('<', '='): (4, -1), ('=', '>'): (3, 1), ('=', '='): (6, -1)}[(r2, r3)]
        assert exp == (ball, sgn)
print('two-pan: 18 distinct decision paths; Table 1 decoding confirmed')

# the balanced branch in detail: what does {1,2,7} v {3,8,9} return?
br = {}
for ball in (7, 8, 9):
    for sgn in (1, -1):
        br.setdefault(weigh({1, 2, 7}, {3, 8, 9}, ball, sgn), []).append((ball, sgn))
print('balanced branch second weighing:', br)

# original proposal {1,2,7} v {4,8,9} after left-heavy
br2 = {}
for ball, sgn in [(1, 1), (2, 1), (3, 1), (4, -1), (5, -1), (6, -1)]:
    br2.setdefault(weigh({1, 2, 7}, {4, 8, 9}, ball, sgn), []).append((ball, sgn))
print('original second weighing after left-heavy:', br2)

# ---------- three-pan protocol ----------
rows = [{1, 2, 3}, {4, 5, 6}, {7, 8, 9}]
cols = [{1, 4, 7}, {2, 5, 8}, {3, 6, 9}]
def three(groups, ball, sgn):
    m = [sum(1 + (sgn if x == ball else 0) for x in g) for g in groups]
    return tuple(m)
labs = {(three(rows, b, s), three(cols, b, s)) for b in range(1, 10) for s in (1, -1)}
assert len(labs) == 18
print('three-pan: 18 distinct row/column labels; ball 8 light ->',
      three(rows, 8, -1), three(cols, 8, -1))

# weak orderings of three labelled loads
orders = set()
for v in it.product(range(3), repeat=3):
    orders.add(tuple(sorted(range(3), key=lambda i: v[i])) + tuple(
        (v[i] > v[j]) - (v[i] < v[j]) for i in range(3) for j in range(3)))
patterns = {tuple((v[i] > v[j]) - (v[i] < v[j]) for i in range(3) for j in range(3))
            for v in it.product(range(3), repeat=3)}
print('weak orderings of 3 loads:', len(patterns))

# ---------- finite-field code checks ----------
assert not ((H @ H.T) % 3).any()
allv = np.array(list(it.product(F, repeat=9)))
ker = allv[((allv @ H.T) % 3 == 0).all(1)]
row = np.array([(np.array(c) @ H) % 3 for c in it.product(F, repeat=3)])
rowset = {tuple(r) for r in row}
w = lambda v: int((np.asarray(v) != 0).sum())
outside = [v for v in ker if tuple(v) not in rowset]
print('|row|=', len(rowset), '|ker|=', len(ker),
      'min row wt=', min(w(r) for r in row if w(r)),
      'min ker\\row wt=', min(w(v) for v in outside))
# weight distribution of ker(H) (the [9,6,3]_3 code)
from collections import Counter
print('ker weight enumerator:', sorted(Counter(w(v) for v in ker).items()))
print('row weight enumerator:', sorted(Counter(w(v) for v in row).items()))
# are all weight-3 kernel words supported on affine lines?
lines = set()
for p in sites:
    for d in [(0, 1), (1, 0), (1, 1), (1, 2)]:
        lines.add(frozenset(((p[0] + k*d[0]) % 3, (p[1] + k*d[1]) % 3) for k in F))
supp3 = {frozenset(sites[i] for i in np.nonzero(v)[0]) for v in ker if w(v) == 3}
print('affine lines:', len(lines), 'weight-3 supports:', len(supp3), 'equal:', supp3 == lines)

# ---------- syndromes ----------
h = lambda a, b: np.array([1, a, b])
restricted = {tuple((e*h(a, b)) % 3): (a, b, e) for a, b in sites for e in (1, 2)}
assert len(restricted) == 18 and (0, 0, 0) not in restricted
full = {tuple(np.concatenate([(x*h(a, b)) % 3, (-z*h(a, b)) % 3])): (a, b, x, z)
        for a, b in sites for x in F for z in F if (x, z) != (0, 0)}
assert len(full) == 72 and (0,)*6 not in full
print('restricted 18 + full 72 syndromes unique and nonzero')

# multi-site shift with a valid single-shift syndrome (Section 5.1 claim)
s = (h(0, 0) + h(0, 1)) % 3
print('X_00 X_01 syndrome', tuple(s), '-> decoded as', restricted.get(tuple(s)))


# ===== explore.py =====
