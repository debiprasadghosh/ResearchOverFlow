"""Extensions: nonadaptive two-pan scheme, statevector test of coarse
instruments (restricted and full), exact code-capacity polynomials,
coupling counts, and a search for a [[9,5,3]]_3 stabilizer code."""
import itertools as it
import numpy as np
from collections import Counter, defaultdict
from fractions import Fraction

rng = np.random.default_rng(20261011)
F = range(3)
sites = [(a, b) for a in F for b in F]
H = np.array([[1]*9, [a for a, b in sites], [b for a, b in sites]]) % 3
w = lambda v: int((np.asarray(v) % 3 != 0).sum())

# ============ (a) nonadaptive three-weighing two-pan scheme ============
# ball i -> placement vector in {-1,0,1}^3 (left=+1, right=-1, off=0).
vecs = [v for v in it.product((-1, 0, 1), repeat=3) if any(v)]
reps = []                       # one of each +-pair
for v in vecs:
    if tuple(-x for x in v) not in reps:
        reps.append(v)
found = None
for combo in it.combinations(reps, 9):
    for signs in it.product((1, -1), repeat=9):
        M = np.array([np.array(v)*s for v, s in zip(combo, signs)])
        if (M.sum(0) == 0).all():     # equal numbers on each pan per weighing
            found = M
            break
    if found is not None:
        break
assert found is not None
outs = {tuple(s*found[i]) for i in range(9) for s in (1, -1)}
assert len(outs) == 18 and (0, 0, 0) not in outs
print('nonadaptive two-pan scheme (rows = balls 1..9; columns = weighings):')
for i, r in enumerate(found):
    print(' ball', i+1, r)
for k in range(3):
    print(' weighing', k+1, 'L=', [i+1 for i in range(9) if found[i, k] == 1],
          'R=', [i+1 for i in range(9) if found[i, k] == -1])

# ============ (b) Pauli algebra over F3 ============
def synd_full(x, z):           # (Z-check block, X-check block)
    return tuple(np.concatenate([(H @ x) % 3, (-(H @ z)) % 3]))

def synd_restricted(x):
    return tuple((H @ x) % 3)

# coupling counts for the circuit realizations
supp = [w(r) for r in H]
print('\nrow supports', supp, 'restricted single pass', sum(supp),
      'full single pass', 2*sum(supp))
print('two-register (S0,S1)+(S0,S2):', supp[0]+supp[1]+supp[0]+supp[2])
print('full row/col instruments via (S0,S1,T0,T1)+(S0,S2,T0,T2):',
      2*(supp[0]+supp[1]+supp[0]+supp[2]))

# ============ (c) full-model coarse row/column instruments ============
def f_row(s, coord):
    """s = (sx0,sx1,sx2,sz0,sz1,sz2); coord=1 for row, 2 for column.
    Uses only (sx0, sx_coord, sz0, sz_coord)."""
    x0, xc, z0, zc = s[0], s[coord], s[3], s[3+coord]
    if (x0, xc, z0, zc) == (0, 0, 0, 0):
        return 'null'
    if (x0 == 0 and xc != 0) or (z0 == 0 and zc != 0):
        return 'reject'
    ax = xc * x0 % 3 if x0 else None     # x0^{-1} = x0 in F3
    az = zc * z0 % 3 if z0 else None
    if ax is not None and az is not None and ax != az:
        return 'reject'
    a = ax if ax is not None else az
    return (x0, (-z0) % 3, a)

all_s4 = Counter()
for v in it.product(F, repeat=4):
    s = (v[0], v[1], 0, v[2], v[3], 0)
    lab = f_row(s, 1)
    all_s4['valid' if isinstance(lab, tuple) else lab] += 1
print('\nrow instrument on 81 sub-syndromes:', dict(all_s4),
      '-> labels: 24 valid + null + reject = 26')

# joint acceptance <=> valid single-site syndrome
valid = {}
for (a, b) in sites:
    for x in F:
        for z in F:
            if (x, z) == (0, 0):
                continue
            X = np.zeros(9, int); Z = np.zeros(9, int)
            i = 3*a + b; X[i] = x; Z[i] = z
            valid[synd_full(X, Z)] = (a, b, x, z)
ok = 0
for s in it.product(F, repeat=6):
    r, c = f_row(s, 1), f_row(s, 2)
    acc_err = isinstance(r, tuple) and isinstance(c, tuple)
    acc_null = r == 'null' and c == 'null'
    if s in valid:
        a, b, x, z = valid[s]
        assert acc_err and r == (x, z, a) and c == (x, z, b)
        ok += 1
    elif s == (0,)*6:
        assert acc_null
    else:
        assert not acc_err and not acc_null, s
print('full-model instruments: all 729 syndromes classified; 72 recovered, 656 rejected')

# ============ (d) statevector test ============
n, dim = 9, 3**9
om = np.exp(2j*np.pi/3)
grid = np.indices((3,)*9).reshape(9, -1).T      # basis labels j_0..j_8

def apply_X(psi, xvec):
    t = psi.reshape((3,)*9)
    for i, e in enumerate(xvec):
        if e % 3:
            t = np.roll(t, e % 3, axis=i)        # |j> -> |j+e>
    return t.reshape(-1)

def zphase(zvec):
    return om ** ((grid @ (np.asarray(zvec) % 3)) % 3)

def apply_Z(psi, zvec):
    return psi * zphase(zvec)

SZ = ((grid @ H.T) % 3)                     # Z-check syndrome of |j>
SZkey = SZ @ np.array([9, 3, 1])
def to_k(psi):   # coordinates in X-eigenbasis |k~>, X|k~> = w^k |k~>
    return (np.fft.ifftn(psi.reshape((3,)*9)) * 3**4.5).reshape(-1)
def from_k(c):
    return (np.fft.fftn(c.reshape((3,)*9)) / 3**4.5).reshape(-1)
SXkey = SZkey   # same function of the label vector (k instead of j)

def keys_to_s(kz, kx):
    return tuple(int(t) for t in (kz//9, kz//3 % 3, kz % 3, kx//9, kx//3 % 3, kx % 3))

def instrument_full(psi, labelfn, zonly=False):
    res = defaultdict(lambda: np.zeros(dim, complex))
    for kz in range(27):
        part = np.where(SZkey == kz, psi, 0)
        if np.linalg.norm(part) < 1e-12: continue
        if zonly:
            s = keys_to_s(kz, 0)[:3]
            res[labelfn(s)] += part
            continue
        c = to_k(part)
        for kx in range(27):
            cp = np.where(SXkey == kx, c, 0)
            if np.linalg.norm(cp) < 1e-12: continue
            res[labelfn(keys_to_s(kz, kx))] += cp  # stored in k-basis
    if not zonly:
        res = {k: from_k(v) for k, v in res.items()}
    return dict(res)

def encode(checks_full):
    psi = rng.normal(size=dim) + 1j*rng.normal(size=dim)
    psi = np.where(SZkey == 0, psi, 0)
    if checks_full:
        c = to_k(psi); psi = from_k(np.where(SXkey == 0, c, 0))
    return psi / np.linalg.norm(psi)

# restricted code: random encoded state entangled with nothing (pure check)
psi = encode(False)

def fR(s):   # paper's definition (uses all three for null/reject)
    if s == (0, 0, 0): return 'none'
    if s[0] == 0: return 'reject'
    return (s[0], s[1]*s[0] % 3)
def fC(s):
    if s == (0, 0, 0): return 'none'
    if s[0] == 0: return 'reject'
    return (s[0], s[2]*s[0] % 3)

worst = 1.0
for (a, b) in sites:
    for e in (1, 2):
        X = np.zeros(9, int); X[3*a+b] = e
        phi = apply_X(psi, X)
        r = instrument_full(phi, fR, zonly=True); assert len(r) == 1
        (lr, st), = r.items()
        c = instrument_full(st, fC, zonly=True); assert len(c) == 1
        (lc, st2), = c.items()
        assert lr == (e, a) and lc == (e, b)
        rec = apply_X(st2, (-X) % 3)
        worst = min(worst, abs(np.vdot(psi, rec)))
print('\nrestricted statevector: 18/18 shifts labelled and recovered, min fidelity', round(worst, 12))

# full code: random logical state, all 72 single-qutrit Paulis

psi = encode(True)
rowlab = lambda s: f_row(s, 1)
collab = lambda s: f_row(s, 2)
worst = 1.0
for (a, b) in sites:
    for x in F:
        for z in F:
            if (x, z) == (0, 0): continue
            X = np.zeros(9, int); Z = np.zeros(9, int); X[3*a+b] = x; Z[3*a+b] = z
            phi = apply_X(apply_Z(psi, Z), X)          # E = X^x Z^z
            r = instrument_full(phi, rowlab); assert len(r) == 1
            (lr, st), = r.items()
            c = instrument_full(st, collab); assert len(c) == 1
            (lc, st2), = c.items()
            assert lr == (x, z, a) and lc == (x, z, b), (lr, lc, a, b, x, z)
            rec = apply_Z(apply_X(st2, (-X) % 3), (-Z) % 3)
            worst = min(worst, abs(np.vdot(psi, rec)))
print('full statevector: 72/72 Paulis labelled by two 26-outcome instruments, min fidelity',
      round(worst, 12))

# ============ (e) exact code-capacity polynomials ============
# full [[9,3,3]]_3 with minimum-weight lookup decoder
stab = []
for u in it.product(F, repeat=3):
    for v in it.product(F, repeat=3):
        stab.append(((np.array(u) @ H) % 3, (np.array(v) @ H) % 3))
leader = {}
for wt in range(0, 10):
    for S in it.combinations(range(9), wt):
        for xz in it.product([(x, z) for x in F for z in F if (x, z) != (0, 0)], repeat=wt):
            X = np.zeros(9, int); Z = np.zeros(9, int)
            for i, (x, z) in zip(S, xz):
                X[i], Z[i] = x, z
            s = synd_full(X, Z)
            if s not in leader:
                leader[s] = (X, Z)
    if len(leader) == 729:
        maxw = wt
        break
print('\nall 729 syndromes have leaders of weight <=', maxw,
      Counter(int(((X % 3 != 0) | (Z % 3 != 0)).sum()) for X, Z in leader.values()))
A = Counter()
for X, Z in leader.values():
    for gx, gz in stab:
        A[int((((X + gx) % 3 != 0) | ((Z + gz) % 3 != 0)).sum())] += 1
print('correctable Paulis by weight A_w:', sorted(A.items()))
import math
for k in range(10):
    print('  w=%d correctable %d of %d' % (k, A[k], math.comb(9, k)*8**k))

def pL_full(p):
    return 1 - sum(A[k]*(p/8)**k*(1-p)**(9-k) for k in range(10))
c2 = Fraction(math.comb(9, 2)*64 - A[2], 64)
print('leading term p_L ~ %s p^2  (= %.4f p^2)' % (c2, float(c2)))

# restricted code under shift noise
lead_r = {}
for wt in range(0, 10):
    for S in it.combinations(range(9), wt):
        for es in it.product((1, 2), repeat=wt):
            X = np.zeros(9, int)
            for i, e in zip(S, es): X[i] = e
            s = synd_restricted(X)
            if s not in lead_r: lead_r[s] = X
    if len(lead_r) == 27: break
Ar = Counter(w(X) for X in lead_r.values())
print('restricted leaders by weight', sorted(Ar.items()))
c2r = Fraction(math.comb(9, 2)*4 - Ar[2], 4)
print('restricted leading term p_L ~ %s p^2 (= %.4f p^2)' % (c2r, float(c2r)))
def pL_r(p):
    return 1 - sum(Ar[k]*(p/2)**k*(1-p)**(9-k) for k in range(10))
for p in (1e-4, 1e-3, 1e-2, 3e-2, 1e-1):
    print('  p=%.0e  full p_L=%.4e  restricted p_L=%.4e  unencoded qutrit p=%.0e' % (p, pL_full(p), pL_r(p), p))
# pseudo-threshold: p_L(p) = p
from scipy.optimize import brentq
pt_full = brentq(lambda p: pL_full(p) - p, 1e-4, 0.5)
pt_r = brentq(lambda p: pL_r(p) - (1-(1-p)**6), 1e-4, 0.95)
pt_f3 = brentq(lambda p: pL_full(p) - (1-(1-p)**3), 1e-4, 0.6)
print('crossing vs one bare qutrit: full %.4f ; vs 3 bare qutrits: full %.4f ; restricted vs 6 bare qutrits (shift noise) %.4f' % (pt_full, pt_f3, pt_r))
np.save('/home/claude/work/A_full.npy', np.array([A[k] for k in range(10)]))
np.save('/home/claude/work/A_restr.npy', np.array([Ar[k] for k in range(10)]))
