import itertools as it, numpy as np
F=range(3); sites=[(a,b) for a in F for b in F]
H=np.array([[1]*9,[a for a,b in sites],[b for a,b in sites]])
h=lambda a,b: np.array([1,a,b])
valid={}
for (a,b) in sites:
  for x in F:
    for z in F:
      if (x,z)!=(0,0): valid[tuple(np.concatenate([(x*h(a,b))%3,(-z*h(a,b))%3]))]=(a,b,x,z)
# single trit readout fault from zero syndrome
zero=np.zeros(6,int); acc=0; tot=0
for i in range(6):
  for d in (1,2):
    s=zero.copy(); s[i]=d; tot+=1; acc+= tuple(s) in valid
print('zero syndrome, single trit fault -> valid label:',acc,'of',tot)
# single trit fault on top of a true single-site error
mis=rej=0; N=0
for s0 in valid:
  for i in range(6):
    for d in (1,2):
      s=np.array(s0); s[i]=(s[i]+d)%3; N+=1
      t=tuple(s)
      if t in valid: mis+=1
      elif any(t): rej+=1
      else: pass
print('true error + one trit fault:',N,'cases; miscorrect',mis,'; rejected(invalid)',rej,'; looks clean',N-mis-rej)
# restricted
vr={tuple((e*h(a,b))%3) for a,b in sites for e in (1,2)}
mis=rej=cl=0
for s0 in vr:
  for i in range(3):
    for d in (1,2):
      s=list(s0); s[i]=(s[i]+d)%3; t=tuple(s)
      if t in vr: mis+=1
      elif any(t): rej+=1
      else: cl+=1
print('restricted: error+trit fault: miscorrect',mis,'rejected',rej,'clean',cl)
acc=sum(tuple(v) in vr for i in range(3) for d in (1,2) for v in [np.eye(3,dtype=int)[i]*d])
print('restricted zero+fault valid',acc,'of 6')
# [[9,5,3]] weights
M=np.load('code9.npy'); X,Z=M[:4],M[4:]
wts=[int(((X[k]!=0)|(Z[k]!=0)).sum()) for k in range(4)]
print('[[9,5,3]] generator weights',wts,'sum',sum(wts))
# nonadaptive two-pan with 3 v 3 in each weighing
vecs=[v for v in it.product((-1,0,1),repeat=3) if any(v)]
reps=[]
for v in vecs:
  if tuple(-x for x in v) not in reps: reps.append(v)
best=None
for combo in it.combinations(reps,9):
  for signs in it.product((1,-1),repeat=9):
    M2=np.array([np.array(v)*s for v,s in zip(combo,signs)])
    if (M2.sum(0)==0).all() and ((M2==1).sum(0)==3).all():
      best=M2;break
  if best is not None: break
for k in range(3):
  print(' weighing',k+1,'L=',[i+1 for i in range(9) if best[i,k]==1],'R=',[i+1 for i in range(9) if best[i,k]==-1])
outs={tuple(s*best[i]) for i in range(9) for s in (1,-1)}
print('distinct',len(outs),(0,0,0) in outs)
for i in range(9): print(i+1,best[i])
