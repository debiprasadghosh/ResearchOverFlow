"""Search for nondegenerate [[n, n-4, 3]]_3 stabilizer codes (n = 9, 10).
Each qutrit j contributes a column pair (x_j, z_j) in F3^4 spanning a line
L_j of PG(3,3).  Distance >= 3 (nondegenerate) <=> lines pairwise disjoint.
Generators commute <=> sum_j (x_j z_j^T - z_j x_j^T) = 0, i.e. the signed
Pluecker vectors sum to zero (the sign is det of the basis change)."""
import itertools as it
import numpy as np
import sys

rng = np.random.default_rng(1)
pts = [np.array(v) for v in it.product(range(3), repeat=4) if any(v)]
# canonical projective points
def canon(v):
    v = np.array(v) % 3
    i = np.nonzero(v)[0][0]
    return tuple((v * (1 if v[i] == 1 else 2)) % 3)
P = sorted({canon(v) for v in pts})
assert len(P) == 40
lines = {}
for u, v in it.combinations(P, 2):
    span = frozenset(canon((a*np.array(u) + b*np.array(v)) % 3)
                     for a in range(3) for b in range(3) if (a, b) != (0, 0))
    if span not in lines:
        lines[span] = (np.array(u), np.array(v))
L = list(lines.items())
assert len(L) == 130
def pl(u, v):
    M = np.outer(u, v) - np.outer(v, u)
    return np.array([M[i, j] for i in range(4) for j in range(i+1, 4)]) % 3
PL = [pl(u, v) for _, (u, v) in L]
disjoint = np.array([[len(a & b) == 0 for b, _ in L] for a, _ in L])

def search(n, tries=200000):
    for t in range(tries):
        order = rng.permutation(130)
        chosen = []
        for i in order:
            if all(disjoint[i, j] for j in chosen):
                chosen.append(i)
            if len(chosen) == n:
                break
        if len(chosen) < n:
            continue
        for signs in it.product((1, 2), repeat=n - 1):
            sv = (sum(s * PL[c] for s, c in zip((1,) + signs, chosen))) % 3
            if not sv.any():
                return chosen, (1,) + signs
    return None

def verify(chosen, signs):
    cols = []
    for c, s in zip(chosen, signs):
        u, v = L[c][1]
        cols.append((u, (s * v) % 3))     # det scaling by s
    n = len(cols)
    X = np.array([c[0] for c in cols]).T % 3
    Z = np.array([c[1] for c in cols]).T % 3
    sym = (X @ Z.T - Z @ X.T) % 3
    assert not sym.any()
    # syndromes of all weight-1 and weight-2 Paulis are nonzero
    def syn(x, z):  # symplectic product of each generator with (x,z)
        return tuple((X @ z - Z @ x) % 3)
    seen = set()
    for i in range(n):
        for a in range(3):
            for b in range(3):
                if (a, b) == (0, 0): continue
                x = np.zeros(n, int); z = np.zeros(n, int); x[i] = a; z[i] = b
                s = syn(x, z); assert any(s); seen.add(s)
    assert len(seen) == 8 * n
    for i, j in it.combinations(range(n), 2):
        for a, b, c, d in it.product(range(3), repeat=4):
            if (a, b) == (0, 0) or (c, d) == (0, 0): continue
            x = np.zeros(n, int); z = np.zeros(n, int)
            x[i], z[i], x[j], z[j] = a, b, c, d
            assert any(syn(x, z))
    return X, Z

for n in (10, 9):
    r = search(n)
    if r is None:
        print(n, 'not found'); continue
    X, Z = verify(*r)
    print('[[%d,%d,3]]_3 found; stabilizer generator rows (x | z):' % (n, n - 4))
    for k in range(4):
        print(' ', ''.join(map(str, X[k])), '|', ''.join(map(str, Z[k])))
    np.save('/home/claude/work/code%d.npy' % n, np.vstack([X, Z]))
