"""Synthetic numerical tests for the revised Neuro-Markov paper.
Run: OPENBLAS_NUM_THREADS=1 python neuro_markov_experiments.py
Requires numpy, scipy, matplotlib. No biological data are used.
"""
from pathlib import Path
import json, csv, platform
import numpy as np
from scipy.stats import t
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT=Path(__file__).resolve().parent
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
rows=[]
def record(exp,condition,metric,values):
    a=np.asarray(values); m=float(a.mean()); se=float(a.std(ddof=1)/np.sqrt(len(a)))
    h=float(t.ppf(.975,len(a)-1)*se)
    rows.append(dict(experiment=exp,condition=condition,metric=metric,n_seeds=len(a),mean=m,ci_low=m-h,ci_high=m+h))
    return m,h
def residual(x,z):
    z=np.column_stack([np.ones(len(x)),z]);return x-z@np.linalg.lstsq(z,x,rcond=None)[0]
def cmi(c,e,z):
    r=np.corrcoef(residual(c,z),residual(e,z))[0,1]
    return -.5*np.log(max(1-r*r,1e-15))

# E1: Gaussian model. A is an imperfect mediator, not a copy of C.
vals={k:[] for k in ['intact_AW','intact_SGAW','bypass_025','bypass_05','omit_W','noisy_A','gain_2']}
for seed in range(100):
    r=np.random.default_rng(seed); n=6000
    c=r.normal(size=n);w=r.normal(size=n)
    s=c+.5*w+.4*r.normal(size=n);g=.8*s+.3*r.normal(size=n)
    a=.7*g+.4*s+.2*w+.5*r.normal(size=n); noise=.5*r.normal(size=n)
    e=a+.8*w+noise
    for key,z,y in [('intact_AW',np.c_[a,w],e),('intact_SGAW',np.c_[s,g,a,w],e),
       ('bypass_025',np.c_[a,w],e+.25*c),('bypass_05',np.c_[a,w],e+.5*c),
       ('omit_W',a[:,None],e),('noisy_A',np.c_[a+.5*r.normal(size=n),w],e),
       ('gain_2',np.c_[2*a,w],2*a+.8*w+noise)]: vals[key].append(cmi(c,y,z))
for k,v in vals.items():record('E1',k,'Gaussian_CMI_nats',v)
fig,ax=plt.subplots(figsize=(8,3.5));keys=list(vals);ax.bar(range(len(keys)),[np.mean(vals[k]) for k in keys],color='#29618c');ax.set_xticks(range(len(keys)),['A W','S G A W','Bypass .25','Bypass .50','Omit W','Noisy A','Gain x2'],rotation=25);ax.set_ylabel('Gaussian conditional MI in nats');fig.tight_layout();fig.savefig(OUT/'screening.png',dpi=220);plt.close(fig)

# E2: same noisy estimate, different thresholds. Hold has a cost.
thresholds=np.linspace(.35,1.3,20); curves=[]
for seed in range(30):
    r=np.random.default_rng(1000+seed);n=20000
    u=r.uniform(-1.5,1.5,n); w=r.uniform(.6,1.4,n)
    true=u*w; pred=true+.25*r.normal(size=n);safe=np.abs(true)<=1
    curve=[]
    for th in thresholds:
        rel=np.abs(pred)<=th
        harm=rel&~safe;hold=~rel&safe
        curve.append([rel.mean(),harm.mean(),hold.mean(),(10*harm+.5*hold).mean(),harm.sum()/max(rel.sum(),1)])
    curves.append(curve)
    for name,rel in [('predictive',np.abs(pred)<=.8),('sign_inverted',np.abs(pred)>=.8),('always_release',np.ones(n,bool)),('always_hold',np.zeros(n,bool))]:
        harm=rel&~safe;hold=~rel&safe
        for metric,v in [('release_rate',rel.mean()),('harm_per_opportunity',harm.mean()),('safe_hold_rate',hold.mean()),('cost',float((10*harm+.5*hold).mean()))]:
            # collect per seed below
            globals().setdefault('gate_'+name+'_'+metric,[]).append(v)
for name in ['predictive','sign_inverted','always_release','always_hold']:
    for metric in ['release_rate','harm_per_opportunity','safe_hold_rate','cost']:
        record('E2',name,metric,globals()['gate_'+name+'_'+metric])
curves=np.array(curves);mean=curves.mean(axis=0)
fig,axs=plt.subplots(1,2,figsize=(8,3.3));axs[0].plot(mean[:,0],mean[:,1],'o-',color='#29618c');axs[0].set(xlabel='Release fraction',ylabel='Harm per opportunity');axs[1].plot(thresholds,mean[:,3],'o-',color='#ad512e');axs[1].set(xlabel='Threshold on absolute predicted outcome',ylabel='Expected cost');fig.tight_layout();fig.savefig(OUT/'gate.png',dpi=220);plt.close(fig)

# E3: delayed LMS, same released outcomes and candidate draws per condition.
learn={}; trajectory={}
beta=np.array([.8,-.6,.4,.2,-.3]);K=4;T=8000;eta=.01
for delay in [0,5,20]:
    for mode in ['indexed','current','pooled']:
        scores=[];paths=[]
        for seed in range(30):
            r=np.random.default_rng(2000+seed);x=r.normal(size=(T,K,5));selected=r.integers(K,size=T)
            rel=r.random(T)<.6; chosen=x[np.arange(T),selected]
            y=chosen@beta+.1*r.normal(size=T);theta=np.zeros(5);p=[]
            for now in range(T):
                old=now-delay
                if old>=0 and rel[old]:
                    if mode=='indexed':z=chosen[old]
                    elif mode=='current':z=chosen[now]
                    else:z=x[old].mean(axis=0)
                    theta+=eta*(y[old]-theta@z)*z
                if now%100==0:p.append(float(np.sum((theta-beta)**2)))
            scores.append(float(np.sum((theta-beta)**2)));paths.append(p)
        learn[(delay,mode)]=scores;trajectory[(delay,mode)]=np.mean(paths,axis=0)
        record('E3',f'{mode}_delay_{delay}','excess_prediction_MSE',scores)
fig,ax=plt.subplots(figsize=(8,3.3))
for mode in ['indexed','current','pooled']:ax.plot(np.arange(0,T,100),trajectory[(20,mode)],label=mode)
ax.set(xlabel='Trial',ylabel='Noise free excess MSE',yscale='log');ax.legend();fig.tight_layout();fig.savefig(OUT/'learning.png',dpi=220);plt.close(fig)

# E4: valid labeled observation, not spurious attribution to the released action.
for mode in ['released_only','released_plus_valid_observation']:
    scores=[]
    for seed in range(100):
        r=np.random.default_rng(3000+seed);x=r.normal(size=(100,5));mask=r.random(100)<.3
        y=x@beta+.2*r.normal(size=100)
        xx=x[mask] if mode=='released_only' else x;yy=y[mask] if mode=='released_only' else y
        theta=np.linalg.lstsq(xx,yy,rcond=None)[0];scores.append(np.sum((theta-beta)**2))
    record('E4',mode,'excess_prediction_MSE',scores)

# E5: delayed endpoint requires a sufficient output trajectory.
dyn={k:[] for k in ['snapshot','trajectory','trajectory_bypass']}
for seed in range(100):
    r=np.random.default_rng(4000+seed);n=6000;c=r.normal(size=n);w=r.normal(size=n)
    a0=.7*c+.5*r.normal(size=n);a1=.8*c+.4*r.normal(size=n)
    e=a0+a1+.3*w+.5*r.normal(size=n)
    dyn['snapshot'].append(cmi(c,e,np.c_[a0,w]));dyn['trajectory'].append(cmi(c,e,np.c_[a0,a1,w]));dyn['trajectory_bypass'].append(cmi(c,e+.5*c,np.c_[a0,a1,w]))
for k,v in dyn.items():record('E5',k,'Gaussian_CMI_nats',v)
fig,ax=plt.subplots(figsize=(7,3));ax.bar(['Snapshot','Output trajectory','Trajectory plus bypass'],[np.mean(dyn[k]) for k in dyn],color='#29618c');ax.set_ylabel('Gaussian conditional MI in nats');fig.tight_layout();fig.savefig(OUT/'dynamic.png',dpi=220);plt.close(fig)

with open(OUT/'summary.csv','w') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
(OUT/'results.json').write_text(json.dumps({'summary':rows,'screening_raw':vals,'dynamic_raw':dyn,'learning_raw':{str(k):v for k,v in learn.items()},'gate_curves':curves.tolist(),'python':platform.python_version(),'numpy':np.__version__},indent=2))
print(json.dumps(rows,indent=2))
