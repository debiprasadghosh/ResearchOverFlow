"""Independent numerical invariants and population-reference checks."""
import json
from pathlib import Path
import numpy as np
r=json.loads((Path(__file__).parent/'results.json').read_text())
assert r['learning_raw']["(0, 'indexed')"] == r['learning_raw']["(0, 'current')"]
rows=r['summary']
for row in rows:
    assert np.isfinite([row['mean'],row['ci_low'],row['ci_high']]).all()
    assert row['ci_low'] <= row['mean'] <= row['ci_high']
def get(e,c,m):
    return next(v['mean'] for v in rows if (v['experiment'],v['condition'],v['metric'])==(e,c,m))
for c in ['predictive','sign_inverted','always_release','always_hold']:
    assert abs(get('E2',c,'cost')-10*get('E2',c,'harm_per_opportunity')-.5*get('E2',c,'safe_hold_rate'))<1e-12
# Independent Gaussian population reference. Monte Carlo estimates need not
# cover this reference in every nominal 95 percent interval.
v=(.96*.4)**2+(.7*.3)**2+.5**2
conditional_var=v/(.96**2+v)
for c,g in [('bypass_025',.25),('bypass_05',.5)]:
    target=.5*np.log1p(g*g*conditional_var/.5**2)
    measured=get('E1',c,'Gaussian_CMI_nats')
    assert abs(target-measured)<.004
    print(c,'population CMI',target,'Monte Carlo mean',measured)
assert get('E1','intact_AW','Gaussian_CMI_nats')<.0002
assert get('E5','trajectory','Gaussian_CMI_nats')<.0002
print('PASS: finite results, interval ordering, zero-delay identity, gate-cost identities and Gaussian population references')
